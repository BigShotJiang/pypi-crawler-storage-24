"""Global hotkey listener via pynput."""

import logging
from collections.abc import Callable

from pynput import keyboard, mouse

logger = logging.getLogger(__name__)

# Map config strings to pynput buttons
# mouse.Button.x1/x2 are Windows-only; use getattr to avoid crash on Linux/macOS
MOUSE_BUTTON_MAP = {
    "left": mouse.Button.left,
    "right": mouse.Button.right,
    "middle": mouse.Button.middle,
}
if getattr(mouse.Button, "x1", None):
    MOUSE_BUTTON_MAP["mouse4"] = mouse.Button.x1
if getattr(mouse.Button, "x2", None):
    MOUSE_BUTTON_MAP["mouse5"] = mouse.Button.x2


class HotkeyListener:
    """Listens for push-to-talk hotkey events."""

    def __init__(
        self,
        hotkey: str,
        on_press: Callable[[], None],
        on_release: Callable[[], None],
    ) -> None:
        self._hotkey = hotkey.lower()
        self._on_press = on_press
        self._on_release = on_release
        self._listener: mouse.Listener | keyboard.Listener | None = None
        self._pressed = False

    def start(self) -> None:
        """Start listening in a background thread."""
        if self._hotkey in MOUSE_BUTTON_MAP:
            self._start_mouse_listener()
        else:
            self._start_keyboard_listener()

    def stop(self) -> None:
        """Stop the listener."""
        if self._listener is not None:
            self._listener.stop()
            self._listener = None

    def _start_mouse_listener(self) -> None:
        target_button = MOUSE_BUTTON_MAP[self._hotkey]

        def on_click(x: int, y: int, button: mouse.Button, pressed: bool) -> None:
            try:
                if button != target_button:
                    return
            except (NotImplementedError, ValueError):
                # pynput can't convert some exotic mouse events on Windows
                return
            try:
                if pressed and not self._pressed:
                    self._pressed = True
                    logger.debug(f"Hotkey pressed: {self._hotkey}")
                    self._on_press()
                elif not pressed and self._pressed:
                    self._pressed = False
                    logger.debug(f"Hotkey released: {self._hotkey}")
                    self._on_release()
            except Exception:
                logger.error("Error in hotkey callback", exc_info=True)
                self._pressed = False

        self._listener = mouse.Listener(on_click=on_click)
        self._listener.daemon = True
        self._listener.start()
        logger.info(f"Mouse hotkey listener started: {self._hotkey}")

    def _start_keyboard_listener(self) -> None:
        # Parse keyboard combo (e.g. "ctrl+shift+d" -> "<ctrl>+<shift>+d")
        try:
            if "+" not in self._hotkey:
                hotkey_str = f"<{self._hotkey}>"
            else:
                # Wrap modifier keys in angle brackets for pynput
                parts = []
                for part in self._hotkey.split("+"):
                    p = part.strip()
                    if p in ("ctrl", "shift", "alt", "cmd", "super"):
                        parts.append(f"<{p}>")
                    else:
                        parts.append(p)
                hotkey_str = "+".join(parts)
            hotkey_combo = keyboard.HotKey.parse(hotkey_str)
        except ValueError:
            hotkey_combo = None

        if hotkey_combo is None:
            logger.error(f"Could not parse keyboard hotkey: {self._hotkey}")
            return

        # Track which combo keys are currently held
        combo_keys = set(hotkey_combo)
        held_keys: set = set()

        def on_activate() -> None:
            if not self._pressed:
                self._pressed = True
                logger.debug(f"Hotkey pressed: {self._hotkey}")
                self._on_press()

        hotkey = keyboard.HotKey(hotkey_combo, on_activate)

        def on_key_press(key: keyboard.Key | keyboard.KeyCode) -> None:
            canonical = self._listener.canonical(key)
            if canonical in combo_keys:
                held_keys.add(canonical)
            hotkey.press(canonical)

        def on_key_release(key: keyboard.Key | keyboard.KeyCode) -> None:
            canonical = self._listener.canonical(key)
            held_keys.discard(canonical)
            hotkey.release(canonical)
            # Only fire release when a combo key is lifted while recording
            if self._pressed and canonical in combo_keys:
                self._pressed = False
                logger.debug(f"Hotkey released: {self._hotkey}")
                self._on_release()

        self._listener = keyboard.Listener(on_press=on_key_press, on_release=on_key_release)
        self._listener.daemon = True
        self._listener.start()
        logger.info(f"Keyboard hotkey listener started: {self._hotkey}")
