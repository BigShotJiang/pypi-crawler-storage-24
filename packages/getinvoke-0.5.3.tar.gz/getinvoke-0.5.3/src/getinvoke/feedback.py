"""Audio feedback cues (beeps/chirps)."""

import logging
import platform
import threading

logger = logging.getLogger(__name__)

_IS_WINDOWS = platform.system() == "Windows"


def _beep(freq: int, duration_ms: int) -> None:
    """Play a beep at given frequency and duration."""
    if _IS_WINDOWS:
        import winsound

        winsound.Beep(freq, duration_ms)
    else:
        try:
            import numpy as np
            import sounddevice as sd

            t = np.linspace(0, duration_ms / 1000, int(16000 * duration_ms / 1000), endpoint=False)
            wave = (np.sin(2 * np.pi * freq * t) * 0.3 * 32767).astype(np.int16)
            sd.play(wave, samplerate=16000, blocking=True)
        except Exception:
            pass  # Silent fallback on non-Windows without audio


def _beep_async(freq: int, duration_ms: int) -> None:
    """Play beep in a thread to avoid blocking."""
    threading.Thread(target=_beep, args=(freq, duration_ms), daemon=True).start()


def play_start_beep() -> None:
    """Short high tick — recording started."""
    _beep_async(1200, 60)


def play_stop_beep() -> None:
    """Silent — no sound needed on release."""
    pass


def play_success_chirp() -> None:
    """Rising two-tone chirp — done, clipboard ready."""

    def _chirp() -> None:
        _beep(880, 80)
        _beep(1320, 120)

    threading.Thread(target=_chirp, daemon=True).start()


def play_error_buzz() -> None:
    """Low descending buzz — error."""

    def _buzz() -> None:
        _beep(300, 150)
        _beep(200, 250)

    threading.Thread(target=_buzz, daemon=True).start()
