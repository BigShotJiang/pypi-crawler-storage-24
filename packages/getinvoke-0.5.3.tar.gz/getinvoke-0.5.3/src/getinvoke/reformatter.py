"""LLM reformatting — OpenRouter, Claude CLI, or any local LLM (Ollama, LM Studio, etc.)."""

from __future__ import annotations

import asyncio
import logging
import os
from typing import TYPE_CHECKING

import httpx

from getinvoke.config import settings
from getinvoke.modes import get_system_prompt

if TYPE_CHECKING:
    from getinvoke.context import ProjectMetadata

logger = logging.getLogger(__name__)


async def reformat_dictation(
    raw_text: str,
    project_context: str = "",
    mode: str | None = None,
    metadata: ProjectMetadata | None = None,
) -> str:
    """Reformat raw transcription via configured backend. Falls back to raw text on any failure."""
    active_mode = mode or settings.MODE
    system_prompt = get_system_prompt(active_mode)

    # Build user message with rich context (metadata) or legacy one-line summary
    user_message = raw_text
    if metadata:
        from getinvoke.context import format_context_for_llm

        context_block = format_context_for_llm(metadata)
        if context_block:
            user_message = f"{context_block}\n\n{raw_text}"
    elif project_context:
        summary = _summarize_context(project_context)
        user_message = f"[Project context: {summary}]\n\n{raw_text}"

    backend = settings.REFORMATTER_BACKEND.lower()

    # "none" = skip LLM entirely, return raw transcription (fastest path)
    if backend == "none":
        logger.info("Reformatter disabled, returning raw transcription")
        return raw_text

    logger.info(f"Reformatting via {backend} (mode: {active_mode})")

    if backend == "claude-cli":
        return await _reformat_via_claude_cli(system_prompt, user_message, raw_text)
    elif backend == "ollama":
        return await _reformat_via_local_llm(system_prompt, user_message, raw_text)
    else:
        return await _reformat_via_openrouter(system_prompt, user_message, raw_text)


async def _reformat_via_openrouter(system_prompt: str, user_message: str, raw_text: str) -> str:
    """Reformat via OpenRouter API."""
    if not settings.OPENROUTER_API_KEY:
        logger.warning("No OpenRouter API key set, returning raw transcription")
        return raw_text

    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            response = await client.post(
                "https://openrouter.ai/api/v1/chat/completions",
                headers={
                    "Authorization": f"Bearer {settings.OPENROUTER_API_KEY}",
                    "Content-Type": "application/json",
                    "HTTP-Referer": "https://getinvoke.dev",
                    "X-Title": "Invoke",
                },
                json={
                    "model": settings.DICTATION_MODEL,
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_message},
                    ],
                    "temperature": 0.3,
                    "max_tokens": 2000,
                },
            )
            response.raise_for_status()
            data = response.json()
            result = data["choices"][0]["message"]["content"].strip()

            if not result:
                logger.warning("OpenRouter returned empty response, falling back to raw text")
                return raw_text
            return result

    except httpx.TimeoutException:
        logger.error("OpenRouter API timed out, returning raw transcription")
        return raw_text
    except httpx.HTTPStatusError as e:
        # Don't log full response body — it may reflect the request including auth headers
        logger.error(f"OpenRouter API error {e.response.status_code}")
        return raw_text
    except Exception as e:
        logger.error(f"OpenRouter error: {e}")
        return raw_text


async def _reformat_via_claude_cli(system_prompt: str, user_message: str, raw_text: str) -> str:
    """Reformat via Claude Code CLI (claude -p)."""
    prompt = f"{system_prompt}\n\n{user_message}"

    try:
        # Clear CLAUDECODE env var so claude CLI doesn't think it's nested
        env = {k: v for k, v in os.environ.items() if k != "CLAUDECODE"}

        proc = await asyncio.create_subprocess_exec(
            settings.CLAUDE_CLI_PATH,
            "-p",
            "--model",
            settings.CLAUDE_CLI_MODEL,
            stdin=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
        )
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(input=prompt.encode("utf-8")),
            timeout=30.0,
        )

        if proc.returncode != 0:
            logger.error(f"Claude CLI exited {proc.returncode}: {stderr.decode().strip()}")
            return raw_text

        result = stdout.decode("utf-8").strip()
        if not result:
            logger.warning("Claude CLI returned empty response, falling back to raw text")
            return raw_text
        return result

    except asyncio.TimeoutError:
        logger.error("Claude CLI timed out, returning raw transcription")
        return raw_text
    except FileNotFoundError:
        logger.error(
            f"Claude CLI not found at '{settings.CLAUDE_CLI_PATH}'. Install Claude Code or set CLAUDE_CLI_PATH."
        )
        return raw_text
    except Exception as e:
        logger.error(f"Claude CLI error: {e}")
        return raw_text


async def _reformat_via_local_llm(system_prompt: str, user_message: str, raw_text: str) -> str:
    """Reformat via local LLM — supports Ollama and OpenAI-compatible servers (LM Studio, vLLM, etc.)."""
    base_url = settings.OLLAMA_URL.rstrip("/")
    model = settings.OLLAMA_MODEL
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_message},
    ]

    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            # Try Ollama-native API first
            try:
                response = await client.post(
                    f"{base_url}/api/chat",
                    json={
                        "model": model,
                        "messages": messages,
                        "stream": False,
                        "options": {"temperature": 0.3},
                    },
                )
                response.raise_for_status()
                data = response.json()
                result = data["message"]["content"].strip()
                if not result:
                    logger.warning("Local LLM returned empty response, falling back to raw text")
                    return raw_text
                return result
            except (httpx.HTTPStatusError, KeyError, TypeError, IndexError):
                # Not an Ollama server or unexpected response — try OpenAI-compatible format
                logger.info("Ollama API not available, trying OpenAI-compatible format")

            # OpenAI-compatible API (LM Studio, vLLM, LocalAI, text-generation-webui, etc.)
            response = await client.post(
                f"{base_url}/v1/chat/completions",
                json={
                    "model": model,
                    "messages": messages,
                    "temperature": 0.3,
                    "max_tokens": 2000,
                },
            )
            response.raise_for_status()
            data = response.json()
            result = data["choices"][0]["message"]["content"].strip()
            if not result:
                logger.warning("Local LLM returned empty response, falling back to raw text")
                return raw_text
            return result

    except httpx.ConnectError:
        logger.error(f"Cannot connect to local LLM at {base_url}. Is your LLM server running?")
        return raw_text
    except httpx.TimeoutException:
        logger.error("Local LLM timed out, returning raw transcription")
        return raw_text
    except Exception as e:
        logger.error(f"Local LLM error: {e}")
        return raw_text


def _summarize_context(context: str) -> str:
    """Extract a one-line summary (project name + tech stack) from context files."""
    lines = context.split("\n")
    project_name = ""
    tech_hints = []

    for line in lines[:50]:
        stripped = line.strip()

        if '"name"' in stripped:
            try:
                project_name = stripped.split('"name"')[1].split('"')[1]
            except (IndexError, KeyError):
                pass

        for keyword, label in [
            ("TypeScript", "TypeScript"),
            ("typescript", "TypeScript"),
            ("Python", "Python"),
            ("python", "Python"),
            ("React", "React"),
            ("Next.js", "Next.js"),
            ("Node", "Node"),
            ("Rust", "Rust"),
            ("Go ", "Go"),
            ("golang", "Go"),
        ]:
            if keyword in line and label not in tech_hints:
                tech_hints.append(label)

    # For CLAUDE.md / .cursorrules, grab the first meaningful non-header line
    for marker in ("[CLAUDE.md]", "[.cursorrules]", "[.windsurfrules]"):
        if marker in context:
            for line in lines:
                if line.startswith(marker) or line.startswith("#"):
                    continue
                if line.strip() and len(line.strip()) > 10:
                    summary = line.strip()[:150]
                    if project_name:
                        return f"{project_name} — {summary}"
                    return summary

    parts = []
    if project_name:
        parts.append(project_name)
    if tech_hints:
        parts.append("/".join(tech_hints[:3]))
    return " — ".join(parts) if parts else "unknown project"
