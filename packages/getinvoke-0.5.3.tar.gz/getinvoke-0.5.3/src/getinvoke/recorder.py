"""Push-to-talk audio capture via sounddevice."""

import io
import logging
import threading

import numpy as np
import sounddevice as sd
from scipy.io import wavfile
from scipy.signal import resample_poly

logger = logging.getLogger(__name__)

WHISPER_RATE = 16000  # Whisper expects 16kHz
CHANNELS = 1
DTYPE = "int16"


def _get_device_sample_rate(device: str | int | None) -> int:
    """Get a working sample rate for the device, preferring 16kHz."""
    for rate in [16000, 44100, 48000]:
        try:
            sd.check_input_settings(device=device, samplerate=rate, channels=CHANNELS, dtype=DTYPE)
            return rate
        except sd.PortAudioError:
            continue
    # Fallback: use the device's default
    info = sd.query_devices(device, kind="input")
    return int(info["default_samplerate"])


class Recorder:
    """Thread-safe push-to-talk audio recorder."""

    def __init__(self, device: str | int | None = None) -> None:
        # sounddevice needs int index, not string — string triggers name matching
        if device is not None and isinstance(device, str) and device.isdigit():
            device = int(device)
        self._device = device
        self._frames: list[np.ndarray] = []
        self._stream: sd.InputStream | None = None
        self._lock = threading.Lock()
        self._recording = threading.Event()
        self._capture_rate: int = WHISPER_RATE

    def start_recording(self) -> None:
        """Start capturing audio."""
        with self._lock:
            self._frames = []
            self._recording.set()
            self._capture_rate = _get_device_sample_rate(self._device)
            self._stream = sd.InputStream(
                samplerate=self._capture_rate,
                channels=CHANNELS,
                dtype=DTYPE,
                device=self._device,
                callback=self._audio_callback,
            )
            self._stream.start()
        logger.info(f"Recording started (capture rate: {self._capture_rate}Hz)")

    def stop_recording(self) -> bytes:
        """Stop capturing and return WAV bytes at 16kHz (resampled if needed)."""
        with self._lock:
            self._recording.clear()
            if self._stream is not None:
                self._stream.stop()
                self._stream.close()
                self._stream = None

            if not self._frames:
                logger.warning("No audio frames captured")
                return b""

            audio = np.concatenate(self._frames, axis=0)
            self._frames = []

        # Resample to 16kHz if device used a different rate
        if self._capture_rate != WHISPER_RATE:
            from math import gcd

            g = gcd(WHISPER_RATE, self._capture_rate)
            audio = resample_poly(audio.flatten(), WHISPER_RATE // g, self._capture_rate // g).astype(np.int16)
            logger.debug(f"Resampled {self._capture_rate}Hz → {WHISPER_RATE}Hz")

        # Convert to WAV bytes
        buf = io.BytesIO()
        wavfile.write(buf, WHISPER_RATE, audio)
        wav_bytes = buf.getvalue()
        duration = len(audio) / WHISPER_RATE
        logger.info(f"Recording stopped: {duration:.1f}s, {len(wav_bytes)} bytes")
        return wav_bytes

    @property
    def is_recording(self) -> bool:
        return self._recording.is_set()

    def _audio_callback(self, indata: np.ndarray, frames: int, time_info: object, status: object) -> None:
        if status:
            logger.warning(f"Audio callback status: {status}")
        if self._recording.is_set():
            self._frames.append(indata.copy())


def list_devices() -> list[dict]:
    """List available audio input devices."""
    devices = sd.query_devices()
    inputs = []
    for i, dev in enumerate(devices):
        if dev["max_input_channels"] > 0:
            inputs.append({"index": i, "name": dev["name"], "channels": dev["max_input_channels"]})
    return inputs
