"""Project context engine — reads project files, git state, and directory structure."""

import json
import logging
import subprocess
import tomllib
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)

# Files to search for, in priority order
CONTEXT_FILES = [
    # AI assistant configs (highest value)
    "CLAUDE.md",
    ".cursorrules",
    ".windsurfrules",
    "AGENTS.md",
    "copilot-instructions.md",
    ".github/copilot-instructions.md",
    # Project identity
    "README.md",
    "package.json",
    "pyproject.toml",
    "Cargo.toml",
    "go.mod",
    "Gemfile",
    "composer.json",
    "pom.xml",
    # Structure hints
    "tsconfig.json",
    "docker-compose.yml",
    ".env.example",
]

MAX_CONTEXT_LENGTH = 4000
_MAX_FILE_MANIFEST = 100
_MAX_VOCAB = 50

# Per-session caches: {project_root: value}
_context_cache: dict[str, str] = {}
_metadata_cache: dict[str, "ProjectMetadata"] = {}


# --- Stack detection config ---

_STACK_FROM_FILES: dict[str, str] = {
    "tsconfig.json": "TypeScript",
    "package.json": "Node",
    "next.config.js": "Next.js",
    "next.config.ts": "Next.js",
    "next.config.mjs": "Next.js",
    "vite.config.ts": "Vite",
    "vite.config.js": "Vite",
    "tailwind.config.js": "Tailwind",
    "tailwind.config.ts": "Tailwind",
    "pyproject.toml": "Python",
    "setup.py": "Python",
    "Cargo.toml": "Rust",
    "go.mod": "Go",
    "Gemfile": "Ruby",
    "composer.json": "PHP",
    "pom.xml": "Java",
}

_STACK_FROM_DEPS: dict[str, str] = {
    "react": "React",
    "react-dom": "React",
    "next": "Next.js",
    "vue": "Vue",
    "nuxt": "Nuxt",
    "svelte": "Svelte",
    "express": "Express",
    "fastify": "Fastify",
    "tailwindcss": "Tailwind",
    "fastapi": "FastAPI",
    "flask": "Flask",
    "django": "Django",
}

_CONVENTION_MAP: dict[str, str] = {
    "TypeScript": "camelCase/PascalCase",
    "Node": "camelCase/PascalCase",
    "React": "camelCase/PascalCase",
    "Next.js": "camelCase/PascalCase",
    "Python": "snake_case/PascalCase",
    "FastAPI": "snake_case/PascalCase",
    "Rust": "snake_case/PascalCase",
    "Go": "camelCase/PascalCase",
    "Ruby": "snake_case/PascalCase",
    "PHP": "camelCase/PascalCase",
    "Java": "camelCase/PascalCase",
}

_STACK_VOCAB: dict[str, list[str]] = {
    "React": [
        "useState",
        "useEffect",
        "useRef",
        "useMemo",
        "useCallback",
        "useContext",
        "useReducer",
        "onClick",
        "onChange",
        "onSubmit",
        "className",
        "JSX",
        "props",
        "setState",
    ],
    "Next.js": [
        "getServerSideProps",
        "getStaticProps",
        "getStaticPaths",
        "NextPage",
        "NextApiRequest",
        "middleware",
    ],
    "TypeScript": [
        "interface",
        "enum",
        "readonly",
        "keyof",
        "typeof",
        "Partial",
        "Omit",
        "Pick",
        "Record",
    ],
    "Python": [
        "FastAPI",
        "pytest",
        "async",
        "await",
        "dataclass",
        "pydantic",
        "SQLAlchemy",
    ],
    "Node": ["Express", "middleware", "router", "endpoint"],
    "Vue": ["ref", "reactive", "computed", "defineProps", "defineEmits"],
}

_SKIP_DIRS = {
    ".git",
    "node_modules",
    "__pycache__",
    ".venv",
    "venv",
    ".next",
    ".nuxt",
    "dist",
    "build",
    ".tox",
    ".eggs",
    "target",
    ".pytest_cache",
    ".ruff_cache",
    ".mypy_cache",
    "coverage",
    "htmlcov",
    ".terraform",
}


@dataclass
class ProjectMetadata:
    """Structured project info for code-aware reformatting."""

    name: str = ""
    stack: list[str] = field(default_factory=list)
    conventions: str = ""
    dependencies: list[str] = field(default_factory=list)
    file_manifest: list[str] = field(default_factory=list)
    active_file: str | None = None
    ai_instructions: str = ""


def extract_project_metadata(
    cwd: str, active_file: str | None = None, use_cache: bool = True
) -> ProjectMetadata | None:
    """Extract structured project metadata for code-aware features.

    Returns None if no project root found.
    """
    cwd_path = Path(cwd)
    if not cwd_path.exists():
        return None

    project_root = _find_project_root(cwd_path)
    if not project_root:
        return None

    root_str = str(project_root)
    if use_cache and root_str in _metadata_cache:
        cached = _metadata_cache[root_str]
        # Update active file (changes per-dictation, not per-project)
        cached.active_file = active_file
        return cached

    name = ""
    dependencies: list[str] = []
    stack: list[str] = []

    # Parse package.json
    pkg_path = project_root / "package.json"
    if pkg_path.exists():
        try:
            pkg = json.loads(pkg_path.read_text(encoding="utf-8"))
            name = pkg.get("name", "")
            for dep_key in ("dependencies", "devDependencies"):
                for dep in pkg.get(dep_key, {}):
                    if dep not in dependencies:
                        dependencies.append(dep)
        except (json.JSONDecodeError, OSError):
            pass

    # Parse pyproject.toml
    pyproj_path = project_root / "pyproject.toml"
    if pyproj_path.exists():
        try:
            data = tomllib.loads(pyproj_path.read_text(encoding="utf-8"))
            if not name:
                name = data.get("project", {}).get("name", "")
            for dep in data.get("project", {}).get("dependencies", []):
                # PEP 508: "package>=1.0" → "package"
                dep_name = dep.split("[")[0].split(">")[0].split("<")[0].split("=")[0].split("!")[0].strip()
                if dep_name and dep_name not in dependencies:
                    dependencies.append(dep_name)
        except (ValueError, OSError):
            pass

    # Detect stack from files
    for filename, tech in _STACK_FROM_FILES.items():
        if (project_root / filename).exists() and tech not in stack:
            stack.append(tech)

    # Detect stack from dependencies
    for dep in dependencies:
        dep_lower = dep.lower()
        if dep_lower in _STACK_FROM_DEPS:
            tech = _STACK_FROM_DEPS[dep_lower]
            if tech not in stack:
                stack.append(tech)

    # Infer naming conventions from primary stack
    conventions = ""
    for tech in stack:
        if tech in _CONVENTION_MAP:
            conventions = _CONVENTION_MAP[tech]
            break

    # File manifest
    file_manifest = _collect_file_manifest(project_root)

    # AI instructions (first meaningful line from config files)
    ai_instructions = ""
    for config_file in ("CLAUDE.md", ".cursorrules", ".windsurfrules"):
        cfg_path = project_root / config_file
        if cfg_path.exists():
            try:
                for line in cfg_path.read_text(encoding="utf-8").split("\n"):
                    stripped = line.strip()
                    if stripped and not stripped.startswith("#") and len(stripped) > 10:
                        ai_instructions = stripped[:150]
                        break
            except OSError:
                pass
            if ai_instructions:
                break

    metadata = ProjectMetadata(
        name=name,
        stack=stack,
        conventions=conventions,
        dependencies=dependencies,
        file_manifest=file_manifest,
        active_file=active_file,
        ai_instructions=ai_instructions,
    )
    _metadata_cache[root_str] = metadata
    logger.debug(f"Metadata for {name or root_str}: stack={stack}, {len(file_manifest)} files")
    return metadata


def format_context_for_llm(metadata: ProjectMetadata) -> str:
    """Format metadata as a compact context block for the reformatter LLM."""
    parts = []

    # Project line
    project_parts = []
    if metadata.name:
        project_parts.append(f"Project: {metadata.name}")
    if metadata.stack:
        project_parts.append(f"Stack: {', '.join(metadata.stack[:5])}")
    if metadata.conventions:
        project_parts.append(f"Conventions: {metadata.conventions}")
    if project_parts:
        parts.append(f"[{' | '.join(project_parts)}]")

    # Active file
    if metadata.active_file:
        parts.append(f"[Active file: {metadata.active_file}]")

    # File manifest (compact)
    if metadata.file_manifest:
        files_str = ", ".join(metadata.file_manifest[:60])
        if len(metadata.file_manifest) > 60:
            files_str += f", ... ({len(metadata.file_manifest) - 60} more)"
        parts.append(f"[Files: {files_str}]")

    # Dependencies (compact)
    if metadata.dependencies:
        deps_str = ", ".join(metadata.dependencies[:30])
        if len(metadata.dependencies) > 30:
            deps_str += f", ... ({len(metadata.dependencies) - 30} more)"
        parts.append(f"[Deps: {deps_str}]")

    # AI instructions
    if metadata.ai_instructions:
        parts.append(f"[Instructions: {metadata.ai_instructions}]")

    return "\n".join(parts)


def generate_project_vocabulary(metadata: ProjectMetadata) -> list[str]:
    """Generate Whisper hotwords from project metadata for recognition boost."""
    vocab: set[str] = set()

    # Project name
    if metadata.name and len(metadata.name) > 2:
        vocab.add(metadata.name)

    # Dependency names
    for dep in metadata.dependencies:
        if len(dep) > 2:
            vocab.add(dep)

    # File stems (skip generic names)
    _generic_stems = {"index", "main", "test", "setup", "config", "utils", "helpers", "types", "app"}
    for filepath in metadata.file_manifest:
        stem = Path(filepath).stem
        if len(stem) > 3 and stem.lower() not in _generic_stems:
            vocab.add(stem)

    # Stack-specific terms
    for tech in metadata.stack:
        for term in _STACK_VOCAB.get(tech, []):
            vocab.add(term)

    return sorted(vocab)[:_MAX_VOCAB]


def _collect_file_manifest(root: Path) -> list[str]:
    """Collect flat list of relative file paths, capped at _MAX_FILE_MANIFEST."""
    files: list[str] = []

    def _walk(path: Path, depth: int) -> None:
        if depth > 3 or len(files) >= _MAX_FILE_MANIFEST:
            return
        try:
            entries = sorted(path.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
        except PermissionError:
            return
        for entry in entries:
            if len(files) >= _MAX_FILE_MANIFEST:
                return
            if entry.is_dir():
                if entry.name not in _SKIP_DIRS and not entry.name.startswith("."):
                    _walk(entry, depth + 1)
            elif entry.is_file():
                rel = str(entry.relative_to(root)).replace("\\", "/")
                files.append(rel)

    _walk(root, 0)
    return files


def load_project_context(cwd: str, use_cache: bool = True) -> str:
    """Extract project context from files, git state, and directory tree.

    Caches per project root within the session. Invalidated on CWD change.
    """
    cwd_path = Path(cwd)
    if not cwd_path.exists():
        return ""

    project_root = _find_project_root(cwd_path)
    if not project_root:
        return ""

    root_str = str(project_root)
    if use_cache and root_str in _context_cache:
        logger.debug(f"Context cache hit for {root_str}")
        return _context_cache[root_str]

    parts = []

    # Static context files
    for filename in CONTEXT_FILES:
        filepath = project_root / filename
        if filepath.exists():
            content = _read_truncated(filepath)
            if content:
                parts.append(f"[{filename}]\n{content}")

    # Git log (last 5 commits)
    git_log = _git_command(project_root, ["log", "--oneline", "-5"])
    if git_log:
        parts.append(f"[git log]\n{git_log}")

    # Git diff stat (what's currently changed)
    git_diff = _git_command(project_root, ["diff", "--stat"])
    if git_diff:
        parts.append(f"[git diff --stat]\n{git_diff}")

    # Directory tree (depth 2)
    tree = _directory_tree(project_root, max_depth=2)
    if tree:
        parts.append(f"[directory tree]\n{tree}")

    if not parts:
        return ""

    combined = "\n\n".join(parts)
    if len(combined) > MAX_CONTEXT_LENGTH:
        combined = combined[:MAX_CONTEXT_LENGTH] + "\n...(truncated)"

    _context_cache[root_str] = combined
    return combined


def invalidate_cache(cwd: str | None = None) -> None:
    """Clear context and metadata caches. If cwd given, only clear that project."""
    if cwd is None:
        _context_cache.clear()
        _metadata_cache.clear()
    else:
        project_root = _find_project_root(Path(cwd))
        if project_root:
            root_str = str(project_root)
            _context_cache.pop(root_str, None)
            _metadata_cache.pop(root_str, None)


def _find_project_root(path: Path) -> Path | None:
    """Walk up from path to find nearest directory containing a context file."""
    current = path
    home = Path.home()

    while current != current.parent and current != home:
        for filename in CONTEXT_FILES:
            if (current / filename).exists():
                return current
        current = current.parent

    # Check home directory itself
    for filename in CONTEXT_FILES:
        if (home / filename).exists():
            return home

    return None


def _read_truncated(filepath: Path, max_chars: int = 2000) -> str:
    """Read a file, truncating to max_chars."""
    try:
        text = filepath.read_text(encoding="utf-8", errors="replace")
        if len(text) > max_chars:
            return text[:max_chars] + "\n...(truncated)"
        return text
    except (OSError, PermissionError):
        return ""


def _git_command(project_root: Path, args: list[str]) -> str:
    """Run a git command in the project root. Returns stdout or empty string."""
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=project_root,
            capture_output=True,
            text=True,
            timeout=5,
        )
        if result.returncode == 0:
            return result.stdout.strip()
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        pass
    return ""


def _directory_tree(root: Path, max_depth: int = 2) -> str:
    """Generate a depth-limited directory tree listing."""
    lines = []

    def _walk(path: Path, prefix: str, depth: int) -> None:
        if depth > max_depth:
            return
        try:
            entries = sorted(path.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
        except PermissionError:
            return

        # Limit entries per level to avoid huge trees
        dirs = [e for e in entries if e.is_dir() and e.name not in _SKIP_DIRS and not e.name.startswith(".")]
        files = [e for e in entries if e.is_file()]

        # Show max 15 files at root, 10 at deeper levels
        max_files = 15 if depth == 0 else 10
        shown_files = files[:max_files]
        hidden_files = len(files) - len(shown_files)

        for d in dirs:
            lines.append(f"{prefix}{d.name}/")
            _walk(d, prefix + "  ", depth + 1)

        for f in shown_files:
            lines.append(f"{prefix}{f.name}")

        if hidden_files > 0:
            lines.append(f"{prefix}... ({hidden_files} more files)")

    _walk(root, "", 0)
    return "\n".join(lines[:80])  # Cap total lines
