"""Cross-platform clipboard access."""

import logging
import time

import pyperclip

logger = logging.getLogger(__name__)


def copy(text: str) -> bool:
    """Copy text to system clipboard. Returns True on success."""
    try:
        pyperclip.copy(text)
        logger.info(f"Copied {len(text)} chars to clipboard")
        return True
    except pyperclip.PyperclipException as e:
        logger.error(f"Clipboard error: {e}")
        return False


def paste() -> bool:
    """Simulate Ctrl+V to paste clipboard contents at cursor. Returns True on success."""
    try:
        from pynput.keyboard import Controller, Key

        kb = Controller()
        # Small delay to ensure clipboard is ready and hotkey is fully released
        time.sleep(0.05)
        kb.press(Key.ctrl)
        kb.press("v")
        kb.release("v")
        kb.release(Key.ctrl)
        logger.info("Auto-pasted via Ctrl+V")
        return True
    except Exception as e:
        logger.error(f"Auto-paste error: {e}")
        return False
