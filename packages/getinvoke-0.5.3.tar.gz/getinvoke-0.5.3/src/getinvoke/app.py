"""GUI app — thin wrapper that wires InvokeEngine to the GUI frontend."""

import logging

from getinvoke.engine import InvokeEngine

logger = logging.getLogger(__name__)


class GuiFrontend:
    """Frontend that uses pystray tray icon + tkinter overlay."""

    def __init__(self) -> None:
        # Lazy imports — only loaded when GUI is actually used
        from getinvoke.overlay import RecordingOverlay
        from getinvoke.tray import TrayApp

        self._tray = TrayApp(on_quit=self._on_quit_requested, on_mode_change=self._on_mode_change)
        self._overlay = RecordingOverlay()
        self._engine: InvokeEngine | None = None
        self._quit_callback = None

    def set_engine(self, engine: InvokeEngine) -> None:
        """Wire up the engine reference (needed for quit callback + license manager)."""
        self._engine = engine
        self._tray._on_quit = engine.request_quit

    def start(self) -> None:
        self._tray.start()
        self._overlay.start()

        # Pass license info to tray
        if self._engine:
            self._tray.set_license_manager(self._engine.license_manager)

    def stop(self) -> None:
        self._overlay.stop()
        self._tray.stop()

    def on_state_change(self, state: str) -> None:
        self._tray.set_state(state)

    def on_recording_started(self) -> None:
        self._overlay.show_recording()

    def on_recording_stopped(self, duration: float) -> None:
        pass  # Overlay handles its own timer

    def on_processing(self) -> None:
        self._overlay.show_processing()

    def on_result(self, raw: str, reformatted: str, duration_ms: int) -> None:
        self._tray.set_tooltip(f"'{reformatted[:50]}...'")
        self._overlay.show_done(reformatted[:50])

    def on_error(self, message: str) -> None:
        self._overlay.show_error(message)

    def notify(self, message: str, title: str) -> None:
        self._tray.notify(message, title)

    def on_first_run(self) -> None:
        from getinvoke.wizard import run_wizard

        run_wizard()

    def on_license_needed(self, message: str) -> bool:
        from getinvoke.license_gui import show_activation_dialog

        if self._engine:
            return show_activation_dialog(self._engine.license_manager, message=message)
        return False

    def _on_quit_requested(self) -> None:
        if self._engine:
            self._engine.request_quit()

    def _on_mode_change(self, mode: str) -> None:
        logger.info(f"Mode changed to: {mode}")
        self._tray.set_tooltip(f"Mode: {mode}")


class InvokeApp:
    """The main GUI application — creates engine + GUI frontend."""

    def __init__(self) -> None:
        self._frontend = GuiFrontend()
        self._engine = InvokeEngine(self._frontend)
        self._frontend.set_engine(self._engine)

    def run(self) -> None:
        """Start the app — blocks until quit."""
        self._engine.run()
