"""Dictation history — SQLite storage with auto-purge."""

import logging
import sqlite3
from datetime import datetime, timedelta

from getinvoke.config import settings

logger = logging.getLogger(__name__)

_conn: sqlite3.Connection | None = None


def init_db() -> None:
    """Initialize the history database."""
    global _conn
    if not settings.HISTORY_ENABLED:
        return

    db_path = settings.db_path
    db_path.parent.mkdir(parents=True, exist_ok=True)

    _conn = sqlite3.connect(str(db_path), check_same_thread=False)
    _conn.execute("""
        CREATE TABLE IF NOT EXISTS history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            raw_text TEXT NOT NULL,
            reformatted TEXT NOT NULL,
            mode TEXT NOT NULL DEFAULT 'claude-code',
            cwd TEXT,
            duration_ms INTEGER
        )
    """)
    _conn.execute("CREATE INDEX IF NOT EXISTS idx_history_ts ON history(timestamp)")
    _conn.commit()

    # Purge old entries
    _purge_old_entries()
    logger.info(f"History database initialized at {db_path}")


def close_db() -> None:
    """Close the database connection."""
    global _conn
    if _conn is not None:
        _conn.close()
        _conn = None


def save_entry(
    raw_text: str,
    reformatted: str,
    mode: str,
    cwd: str | None = None,
    duration_ms: int | None = None,
) -> None:
    """Save a dictation entry to history."""
    if _conn is None:
        return

    try:
        _conn.execute(
            "INSERT INTO history (timestamp, raw_text, reformatted, mode, cwd, duration_ms) VALUES (?, ?, ?, ?, ?, ?)",
            (datetime.now().isoformat(), raw_text, reformatted, mode, cwd, duration_ms),
        )
        _conn.commit()
    except sqlite3.Error as e:
        logger.error(f"Failed to save history entry: {e}")


def get_recent(limit: int = 20) -> list[dict]:
    """Get recent history entries."""
    if _conn is None:
        return []

    try:
        cursor = _conn.execute(
            "SELECT id, timestamp, raw_text, reformatted, mode, cwd, duration_ms FROM history ORDER BY id DESC LIMIT ?",
            (limit,),
        )
        rows = cursor.fetchall()
        return [
            {
                "id": r[0],
                "timestamp": r[1],
                "raw_text": r[2],
                "reformatted": r[3],
                "mode": r[4],
                "cwd": r[5],
                "duration_ms": r[6],
            }
            for r in rows
        ]
    except sqlite3.Error as e:
        logger.error(f"Failed to query history: {e}")
        return []


def search(query: str, limit: int = 20) -> list[dict]:
    """Search history by text content."""
    if _conn is None:
        return []

    try:
        cursor = _conn.execute(
            "SELECT id, timestamp, raw_text, reformatted, mode, cwd, duration_ms "
            "FROM history WHERE raw_text LIKE ? OR reformatted LIKE ? ORDER BY id DESC LIMIT ?",
            (f"%{query}%", f"%{query}%", limit),
        )
        rows = cursor.fetchall()
        return [
            {
                "id": r[0],
                "timestamp": r[1],
                "raw_text": r[2],
                "reformatted": r[3],
                "mode": r[4],
                "cwd": r[5],
                "duration_ms": r[6],
            }
            for r in rows
        ]
    except sqlite3.Error as e:
        logger.error(f"Failed to search history: {e}")
        return []


def count() -> int:
    """Get total number of history entries."""
    if _conn is None:
        return 0
    try:
        cursor = _conn.execute("SELECT COUNT(*) FROM history")
        return cursor.fetchone()[0]
    except sqlite3.Error:
        return 0


def _purge_old_entries() -> None:
    """Remove entries older than retention period."""
    if _conn is None:
        return

    cutoff = (datetime.now() - timedelta(days=settings.HISTORY_RETENTION_DAYS)).isoformat()
    try:
        result = _conn.execute("DELETE FROM history WHERE timestamp < ?", (cutoff,))
        if result.rowcount > 0:
            _conn.commit()
            logger.info(f"Purged {result.rowcount} old history entries")
    except sqlite3.Error as e:
        logger.error(f"Failed to purge history: {e}")
