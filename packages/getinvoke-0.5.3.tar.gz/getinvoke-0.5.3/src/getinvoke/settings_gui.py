"""Settings GUI — tkinter tabbed editor launched from tray menu."""

import logging
import tkinter as tk
from tkinter import messagebox, ttk

logger = logging.getLogger(__name__)


def open_settings(on_save: callable = None) -> None:
    """Open the settings window. Non-blocking (runs in own thread)."""
    import threading

    def _run() -> None:
        try:
            app = SettingsWindow(on_save=on_save)
            app.mainloop()
        except Exception as e:
            logger.error(f"Settings GUI error: {e}")

    threading.Thread(target=_run, daemon=True).start()


class SettingsWindow(tk.Tk):
    """Tabbed settings editor."""

    def __init__(self, on_save: callable = None) -> None:
        super().__init__()
        self.withdraw()  # Hide until fully styled to prevent white flash
        self._on_save = on_save
        self.title("Invoke Settings")
        self.geometry("540x520")
        self.resizable(False, False)
        self.configure(bg="#1a1a1e")

        # Center
        self.update_idletasks()
        x = (self.winfo_screenwidth() - 540) // 2
        y = (self.winfo_screenheight() - 520) // 2
        self.geometry(f"+{x}+{y}")

        # Style
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TFrame", background="#1a1a1e")
        style.configure("TLabel", background="#1a1a1e", foreground="#e0e0e0", font=("Segoe UI", 10))
        style.configure("TNotebook", background="#1a1a1e")
        style.configure("TNotebook.Tab", font=("Segoe UI", 9), padding=(12, 4))
        style.configure("TButton", font=("Segoe UI", 10))
        style.configure("Green.TButton", font=("Segoe UI", 10, "bold"))
        style.configure("TCheckbutton", background="#1a1a1e", foreground="#e0e0e0", font=("Segoe UI", 10))
        style.configure("TCombobox", font=("Segoe UI", 10))
        style.configure("TRadiobutton", background="#1a1a1e", foreground="#e0e0e0", font=("Segoe UI", 10))

        # Use the live singleton — already running correctly, no slow re-init
        from getinvoke.config import settings as live_settings

        self._live = live_settings

        # Notebook (tabs)
        notebook = ttk.Notebook(self)
        notebook.pack(fill="both", expand=True, padx=12, pady=(12, 0))

        self._build_general_tab(notebook)
        self._build_transcription_tab(notebook)
        self._build_reformatter_tab(notebook)
        self._build_history_tab(notebook)
        self._build_advanced_tab(notebook)
        self._build_license_tab(notebook)

        # Bottom buttons
        btn_frame = ttk.Frame(self)
        btn_frame.pack(fill="x", padx=12, pady=12)
        ttk.Button(btn_frame, text="Cancel", command=self.destroy).pack(side="right", padx=(8, 0))
        ttk.Button(btn_frame, text="Save", command=self._save, style="Green.TButton").pack(side="right")

        self.deiconify()  # Show now that all widgets are styled

    @staticmethod
    def _ensure_in_options(value: str, options: list[str]) -> list[str]:
        """Ensure value is in options list so readonly combos don't show blank."""
        if value and value not in options:
            options = [value] + options
        return options

    def _build_general_tab(self, notebook: ttk.Notebook) -> None:
        tab = ttk.Frame(notebook)
        notebook.add(tab, text="General")

        # Mode
        ttk.Label(tab, text="Output Mode:").grid(row=0, column=0, sticky="w", padx=12, pady=(12, 4))
        from getinvoke.modes import MODES, list_modes

        mode_names = [m.name for m in list_modes()]
        mode_names = self._ensure_in_options(self._live.MODE, mode_names)
        self._mode_var = tk.StringVar(value=self._live.MODE)
        mode_combo = ttk.Combobox(tab, textvariable=self._mode_var, values=mode_names, state="readonly", width=20)
        mode_combo.set(self._live.MODE)
        mode_combo.grid(row=0, column=1, sticky="w", padx=12, pady=(12, 4))

        # Mode description (updates on selection)
        self._mode_desc_var = tk.StringVar()
        mode_desc_label = ttk.Label(tab, textvariable=self._mode_desc_var, foreground="#888888", wraplength=480)
        mode_desc_label.grid(row=1, column=0, columnspan=2, sticky="w", padx=12, pady=(0, 8))

        def _update_mode_desc(*_args) -> None:
            name = self._mode_var.get()
            mode = MODES.get(name)
            if mode:
                self._mode_desc_var.set(mode.description)
            else:
                self._mode_desc_var.set("")

        self._mode_var.trace_add("write", _update_mode_desc)
        _update_mode_desc()  # Set initial description

        # Pipeline explanation
        ttk.Label(
            tab,
            text="All modes use: Voice → Whisper (local) → AI reformatter → Clipboard",
            foreground="#5FC8C8",
            wraplength=480,
        ).grid(row=2, column=0, columnspan=2, sticky="w", padx=12, pady=(0, 8))

        # Hotkey
        ttk.Label(tab, text="Hotkey:").grid(row=3, column=0, sticky="w", padx=12, pady=4)
        hotkey_options = ["mouse5", "mouse4", "ctrl+shift+d"]
        self._hotkey_var = tk.StringVar(value=self._live.HOTKEY)
        ttk.Combobox(tab, textvariable=self._hotkey_var, values=hotkey_options, width=20).grid(
            row=3, column=1, sticky="w", padx=12, pady=4
        )

        # Auto-paste
        self._autopaste_var = tk.BooleanVar(value=self._live.AUTO_PASTE)
        ttk.Checkbutton(tab, text="Auto-paste at cursor", variable=self._autopaste_var).grid(
            row=4, column=0, columnspan=2, sticky="w", padx=12, pady=4
        )

    def _build_transcription_tab(self, notebook: ttk.Notebook) -> None:
        tab = ttk.Frame(notebook)
        notebook.add(tab, text="Transcription")

        # Whisper model
        ttk.Label(tab, text="Whisper Model:").grid(row=0, column=0, sticky="w", padx=12, pady=(12, 4))
        model_options = ["distil-large-v3", "large-v3", "medium", "small", "base", "tiny"]
        self._model_var = tk.StringVar(value=self._live.WHISPER_MODEL)
        ttk.Combobox(tab, textvariable=self._model_var, values=model_options, width=20).grid(
            row=0, column=1, sticky="w", padx=12, pady=(12, 4)
        )

        # Device
        ttk.Label(tab, text="Device:").grid(row=1, column=0, sticky="w", padx=12, pady=4)
        device_options = self._ensure_in_options(self._live.WHISPER_DEVICE, ["auto", "cuda", "cpu"])
        self._device_var = tk.StringVar(value=self._live.WHISPER_DEVICE)
        device_combo = ttk.Combobox(
            tab, textvariable=self._device_var, values=device_options, state="readonly", width=20
        )
        device_combo.set(self._live.WHISPER_DEVICE)
        device_combo.grid(row=1, column=1, sticky="w", padx=12, pady=4)

        # Audio device (loaded async to avoid blocking UI)
        ttk.Label(tab, text="Audio Device:").grid(row=2, column=0, sticky="w", padx=12, pady=4)
        self._audio_var = tk.StringVar(value="Loading...")
        self._audio_combo = ttk.Combobox(
            tab, textvariable=self._audio_var, values=["Loading..."], state="readonly", width=35
        )
        self._audio_combo.set("Loading...")
        self._audio_combo.grid(row=2, column=1, sticky="w", padx=12, pady=4)

        import threading

        def _load_devices():
            try:
                from getinvoke.recorder import list_devices

                devices = list_devices()
            except Exception as e:
                logger.warning(f"Failed to list audio devices: {e}")
                devices = []
            device_names = ["default"] + [f"[{d['index']}] {d['name']}" for d in devices]
            current = f"[{self._live.AUDIO_DEVICE}]" if self._live.AUDIO_DEVICE else "default"
            audio_val = "default"
            for name in device_names:
                if current in name:
                    audio_val = name
                    break
            self.after(0, lambda: self._populate_audio_combo(device_names, audio_val))

        threading.Thread(target=_load_devices, daemon=True).start()

        # Language
        ttk.Label(tab, text="Language:").grid(row=3, column=0, sticky="w", padx=12, pady=4)
        lang_options = ["en", "auto", "es", "fr", "de", "zh", "ja", "ko", "pt", "ru"]
        current_lang = getattr(self._live, "LANGUAGE", "en")
        self._lang_var = tk.StringVar(value=current_lang)
        ttk.Combobox(tab, textvariable=self._lang_var, values=lang_options, width=20).grid(
            row=3, column=1, sticky="w", padx=12, pady=4
        )

    def _build_reformatter_tab(self, notebook: ttk.Notebook) -> None:
        tab = ttk.Frame(notebook)
        notebook.add(tab, text="AI Processing")

        # Explanation
        ttk.Label(
            tab,
            text="After Whisper transcribes your speech, an AI can clean it up, remove\n"
            "filler words, and format it for your coding tool. Choose a backend below.",
            foreground="#888888",
            wraplength=480,
        ).grid(row=0, column=0, columnspan=2, sticky="w", padx=12, pady=(12, 4))

        # Backend
        ttk.Label(tab, text="AI Backend:").grid(row=1, column=0, sticky="w", padx=12, pady=(8, 4))
        backend_options = self._ensure_in_options(
            self._live.REFORMATTER_BACKEND, ["openrouter", "claude-cli", "ollama", "none"]
        )
        self._backend_var = tk.StringVar(value=self._live.REFORMATTER_BACKEND)
        backend_combo = ttk.Combobox(
            tab, textvariable=self._backend_var, values=backend_options, state="readonly", width=20
        )
        backend_combo.set(self._live.REFORMATTER_BACKEND)
        backend_combo.grid(row=1, column=1, sticky="w", padx=12, pady=(8, 4))

        # Backend description (updates on selection)
        _backend_descs = {
            "openrouter": "Cloud API — uses Claude via OpenRouter (~$0.001/dictation)",
            "claude-cli": "Uses your local Claude Code CLI — no extra API key needed",
            "ollama": "Local LLM (Ollama, LM Studio, etc.) — free, no internet required",
            "none": "AI off — raw Whisper transcription goes straight to clipboard",
        }
        self._backend_desc_var = tk.StringVar()
        ttk.Label(tab, textvariable=self._backend_desc_var, foreground="#5FC8C8", wraplength=480).grid(
            row=2, column=0, columnspan=2, sticky="w", padx=12, pady=(0, 4)
        )

        # Validation warning
        self._backend_warn_var = tk.StringVar()
        ttk.Label(tab, textvariable=self._backend_warn_var, foreground="#E67E80", wraplength=480).grid(
            row=3, column=0, columnspan=2, sticky="w", padx=12, pady=(0, 8)
        )

        def _update_backend_desc(*_args) -> None:
            b = self._backend_var.get().lower()
            self._backend_desc_var.set(_backend_descs.get(b, ""))
            # Show warning if openrouter with no key
            if b == "openrouter" and not self._apikey_var.get().strip():
                self._backend_warn_var.set("API key required — get one at openrouter.ai/keys")
            else:
                self._backend_warn_var.set("")

        self._backend_var.trace_add("write", _update_backend_desc)

        # OpenRouter
        ttk.Label(tab, text="OpenRouter API Key:").grid(row=4, column=0, sticky="w", padx=12, pady=4)
        self._apikey_var = tk.StringVar(value=self._live.OPENROUTER_API_KEY)
        api_entry = ttk.Entry(tab, textvariable=self._apikey_var, width=38, show="*")
        api_entry.grid(row=4, column=1, sticky="w", padx=12, pady=4)
        # Update warning when key changes
        self._apikey_var.trace_add("write", _update_backend_desc)

        ttk.Label(tab, text="Dictation Model:").grid(row=5, column=0, sticky="w", padx=12, pady=4)
        self._dictmodel_var = tk.StringVar(value=self._live.DICTATION_MODEL)
        ttk.Entry(tab, textvariable=self._dictmodel_var, width=38).grid(row=5, column=1, sticky="w", padx=12, pady=4)

        # Ollama
        ttk.Label(tab, text="Local LLM URL:").grid(row=6, column=0, sticky="w", padx=12, pady=4)
        self._ollama_url_var = tk.StringVar(value=self._live.OLLAMA_URL)
        ttk.Entry(tab, textvariable=self._ollama_url_var, width=38).grid(row=6, column=1, sticky="w", padx=12, pady=4)

        ttk.Label(tab, text="Local LLM Model:").grid(row=7, column=0, sticky="w", padx=12, pady=4)
        self._ollama_model_var = tk.StringVar(value=self._live.OLLAMA_MODEL)
        ttk.Entry(tab, textvariable=self._ollama_model_var, width=38).grid(row=7, column=1, sticky="w", padx=12, pady=4)

        _update_backend_desc()  # Set initial state

    def _build_history_tab(self, notebook: ttk.Notebook) -> None:
        tab = ttk.Frame(notebook)
        notebook.add(tab, text="History")

        # Enabled
        self._hist_enabled_var = tk.BooleanVar(value=self._live.HISTORY_ENABLED)
        ttk.Checkbutton(tab, text="Enable dictation history", variable=self._hist_enabled_var).grid(
            row=0, column=0, columnspan=2, sticky="w", padx=12, pady=(12, 4)
        )

        # Retention
        ttk.Label(tab, text="Retention (days):").grid(row=1, column=0, sticky="w", padx=12, pady=4)
        self._retention_var = tk.StringVar(value=str(self._live.HISTORY_RETENTION_DAYS))
        ttk.Entry(tab, textvariable=self._retention_var, width=10).grid(row=1, column=1, sticky="w", padx=12, pady=4)

        # Clear history button
        def _clear_history() -> None:
            from getinvoke import history

            history.init_db()
            count = history.count()
            if messagebox.askyesno("Clear History", f"Delete all {count} history entries?"):
                import sqlite3

                conn = sqlite3.connect(str(self._live.db_path))
                conn.execute("DELETE FROM history")
                conn.commit()
                conn.close()
                messagebox.showinfo("History Cleared", "All history entries deleted.")

        ttk.Button(tab, text="Clear History", command=_clear_history).grid(
            row=2, column=0, sticky="w", padx=12, pady=(16, 4)
        )

    def _build_advanced_tab(self, notebook: ttk.Notebook) -> None:
        tab = ttk.Frame(notebook)
        notebook.add(tab, text="Advanced")

        # Log level
        ttk.Label(tab, text="Log Level:").grid(row=0, column=0, sticky="w", padx=12, pady=(12, 4))
        log_options = self._ensure_in_options(self._live.LOG_LEVEL, ["DEBUG", "INFO", "WARNING", "ERROR"])
        self._loglevel_var = tk.StringVar(value=self._live.LOG_LEVEL)
        loglevel_combo = ttk.Combobox(
            tab, textvariable=self._loglevel_var, values=log_options, state="readonly", width=20
        )
        loglevel_combo.set(self._live.LOG_LEVEL)
        loglevel_combo.grid(row=0, column=1, sticky="w", padx=12, pady=(12, 4))

        # Custom vocabulary
        ttk.Label(tab, text="Custom Vocabulary:").grid(row=1, column=0, sticky="nw", padx=12, pady=4)
        self._vocab_var = tk.StringVar(value=self._live.CUSTOM_VOCAB)
        ttk.Entry(tab, textvariable=self._vocab_var, width=38).grid(row=1, column=1, sticky="w", padx=12, pady=4)
        ttk.Label(tab, text="Comma-separated terms (e.g. KeyGrip,FastAPI,pynput)", foreground="#888888").grid(
            row=2, column=0, columnspan=2, sticky="w", padx=12, pady=(0, 4)
        )

    def _populate_audio_combo(self, device_names: list[str], audio_val: str) -> None:
        """Callback to populate audio combo after async device enumeration."""
        try:
            self._audio_combo.configure(values=device_names)
            self._audio_combo.set(audio_val)
            self._audio_var.set(audio_val)
        except tk.TclError:
            pass  # Window was closed before devices loaded

    def _build_license_tab(self, notebook: ttk.Notebook) -> None:
        tab = ttk.Frame(notebook)
        notebook.add(tab, text="License")

        # Placeholder while license loads async
        ttk.Label(tab, text="License Status:").grid(row=0, column=0, sticky="w", padx=12, pady=(12, 4))
        self._license_status_display = ttk.Label(tab, text="Loading...", foreground="#888888")
        self._license_status_display.grid(row=0, column=1, sticky="w", padx=12, pady=(12, 4))

        self._license_email_label_name = ttk.Label(tab, text="")
        self._license_email_label_name.grid(row=1, column=0, sticky="w", padx=12, pady=4)
        self._license_email_label_val = ttk.Label(tab, text="", foreground="#888888")
        self._license_email_label_val.grid(row=1, column=1, sticky="w", padx=12, pady=4)

        ttk.Label(tab, text="License Key:").grid(row=2, column=0, sticky="w", padx=12, pady=(16, 4))
        self._license_key_var = tk.StringVar()
        ttk.Entry(tab, textvariable=self._license_key_var, width=38, show="*").grid(
            row=2, column=1, sticky="w", padx=12, pady=(16, 4)
        )

        self._license_btn_frame = ttk.Frame(tab)
        self._license_btn_frame.grid(row=3, column=0, columnspan=2, sticky="w", padx=12, pady=4)

        self._license_status_var = tk.StringVar()
        ttk.Label(tab, textvariable=self._license_status_var, foreground="#888888").grid(
            row=4, column=0, columnspan=2, sticky="w", padx=12, pady=(8, 0)
        )

        self._license_tab = tab

        # Load license info in background
        import threading

        threading.Thread(target=self._load_license_async, daemon=True).start()

    def _load_license_async(self) -> None:
        """Load license info off the UI thread."""
        from getinvoke.license import LicenseManager

        lm = LicenseManager()
        status = lm.check()
        self.after(0, lambda: self._populate_license_tab(lm, status))

    def _populate_license_tab(self, lm, status) -> None:
        """Populate license tab on UI thread after async load."""
        try:
            from getinvoke.license import LicenseStatus

            status_text = {
                LicenseStatus.TRIAL: f"Trial — {lm.trial_days_left} days left",
                LicenseStatus.ACTIVE: "Active",
                LicenseStatus.EXPIRED_TRIAL: "Trial Expired",
                LicenseStatus.INVALID: "Invalid — re-activation required",
                LicenseStatus.GRACE: "Active (offline grace period)",
            }
            status_color = "#22c55e" if status in (LicenseStatus.ACTIVE, LicenseStatus.TRIAL) else "#E67E80"

            self._license_status_display.configure(text=status_text.get(status, "Unknown"), foreground=status_color)

            if lm.customer_email:
                self._license_email_label_name.configure(text="Email:")
                self._license_email_label_val.configure(text=lm.customer_email)

            self._license_key_var.set(lm.license_key)

            def _activate() -> None:
                key = self._license_key_var.get().strip()
                if not key:
                    self._license_status_var.set("Enter a license key first.")
                    return
                self._license_status_var.set("Activating...")

                import threading

                def _do():
                    success, msg = lm.activate(key)
                    self.after(0, lambda: self._on_activate_done(success, msg))

                threading.Thread(target=_do, daemon=True).start()

            def _deactivate() -> None:
                import threading

                def _do():
                    success, msg = lm.deactivate()
                    self.after(0, lambda: self._on_deactivate_done(success, msg))

                threading.Thread(target=_do, daemon=True).start()

            ttk.Button(self._license_btn_frame, text="Activate", command=_activate, style="Green.TButton").pack(
                side="left"
            )
            if status == LicenseStatus.ACTIVE:
                ttk.Button(self._license_btn_frame, text="Deactivate", command=_deactivate).pack(
                    side="left", padx=(8, 0)
                )
        except tk.TclError:
            pass  # Window closed

    def _on_activate_done(self, success: bool, msg: str) -> None:
        self._license_status_var.set(msg)
        if success:
            self._license_status_display.configure(text="Active", foreground="#22c55e")

    def _on_deactivate_done(self, success: bool, msg: str) -> None:
        self._license_status_var.set(msg)
        if success:
            self._license_status_display.configure(text="Deactivated", foreground="#E67E80")

    def _save(self) -> None:
        """Save all settings to config.json and update the live singleton."""
        try:
            live = self._live

            # General
            live.MODE = self._mode_var.get()
            live.HOTKEY = self._hotkey_var.get()
            live.AUTO_PASTE = self._autopaste_var.get()

            # Transcription
            live.WHISPER_MODEL = self._model_var.get()
            live.WHISPER_DEVICE = self._device_var.get()
            audio = self._audio_var.get()
            if audio in ("default", "Loading..."):
                live.AUDIO_DEVICE = None
            else:
                live.AUDIO_DEVICE = audio.split("]")[0].strip("[")
            live.LANGUAGE = self._lang_var.get()

            # Reformatter
            live.REFORMATTER_BACKEND = self._backend_var.get()
            live.OPENROUTER_API_KEY = self._apikey_var.get()
            live.DICTATION_MODEL = self._dictmodel_var.get()
            live.OLLAMA_URL = self._ollama_url_var.get()
            live.OLLAMA_MODEL = self._ollama_model_var.get()

            # History
            live.HISTORY_ENABLED = self._hist_enabled_var.get()
            try:
                live.HISTORY_RETENTION_DAYS = int(self._retention_var.get())
            except ValueError:
                pass

            # Advanced
            live.LOG_LEVEL = self._loglevel_var.get()
            live.CUSTOM_VOCAB = self._vocab_var.get()

            # Write to disk
            live.save()

            logger.info(f"Settings saved to {live.config_file}")

            if self._on_save:
                self._on_save()
        except Exception as e:
            logger.error(f"Failed to save settings: {e}")
            from tkinter import messagebox

            messagebox.showerror("Save Error", f"Failed to save settings:\n{e}")
            return

        self.destroy()
