"""Allow running as `python -m getinvoke`."""

from getinvoke.cli import main

main()
