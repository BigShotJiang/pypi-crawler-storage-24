"""Tests for license management module."""

import json
from datetime import datetime, timedelta
from unittest.mock import MagicMock, patch

from getinvoke.license import (
    GRACE_DAYS,
    PRODUCT_ID_INVOKE,
    PRODUCT_ID_INVOKE_PLUS,
    TRIAL_DAYS,
    UPDATE_ELIGIBILITY_DAYS,
    LicenseManager,
    LicenseStatus,
)


def _make_manager(tmp_path, data=None):
    """Create a LicenseManager with a custom config dir."""
    with patch("getinvoke.license.settings") as mock_settings:
        mock_settings.config_dir = tmp_path
        lm = LicenseManager()
        if data is not None:
            lm._data = data
            lm._save()
        return lm


def test_first_launch_creates_trial(tmp_path):
    """No license.json → trial state."""
    lm = _make_manager(tmp_path)
    status = lm.check()
    assert status == LicenseStatus.TRIAL
    assert lm.trial_days_left > 0
    assert (tmp_path / "license.json").exists()


def test_trial_active_within_7_days(tmp_path):
    """Trial started 3 days ago → allowed."""
    data = {"trial_started": (datetime.now() - timedelta(days=3)).isoformat(), "status": "trial"}
    lm = _make_manager(tmp_path, data)
    status = lm.check()
    assert status == LicenseStatus.TRIAL
    assert lm.trial_days_left == TRIAL_DAYS - 3


def test_trial_expired_after_7_days(tmp_path):
    """Trial started 8 days ago → blocked."""
    data = {"trial_started": (datetime.now() - timedelta(days=8)).isoformat(), "status": "trial"}
    lm = _make_manager(tmp_path, data)
    status = lm.check()
    assert status == LicenseStatus.EXPIRED_TRIAL


def test_activate_success(tmp_path):
    """Mock API → active state, instance_id saved."""
    lm = _make_manager(tmp_path, {"trial_started": datetime.now().isoformat(), "status": "trial"})

    mock_response = MagicMock()
    mock_response.json.return_value = {
        "activated": True,
        "license_key": {"id": 1, "status": "active", "key": "test-key"},
        "instance": {"id": "inst-123", "name": "test-machine"},
        "meta": {"store_id": 314146, "product_id": 887386, "customer_email": "test@example.com"},
    }

    with patch("getinvoke.license.httpx.post", return_value=mock_response):
        success, msg = lm.activate("test-key")

    assert success
    assert lm.status == LicenseStatus.ACTIVE
    assert lm.customer_email == "test@example.com"

    assert lm.tier == "invoke"

    # Verify persisted
    saved = json.loads((tmp_path / "license.json").read_text())
    assert saved["instance_id"] == "inst-123"
    assert saved["status"] == "active"
    assert saved["product_id"] == 887386


def test_activate_wrong_product(tmp_path):
    """Mock API with wrong product_id → rejected."""
    lm = _make_manager(tmp_path, {"trial_started": datetime.now().isoformat(), "status": "trial"})

    mock_response = MagicMock()
    mock_response.json.return_value = {
        "activated": True,
        "license_key": {"id": 1, "status": "active", "key": "test-key"},
        "instance": {"id": "inst-123", "name": "test-machine"},
        "meta": {"store_id": 314146, "product_id": 99999, "customer_email": "test@example.com"},
    }

    with patch("getinvoke.license.httpx.post", return_value=mock_response):
        success, msg = lm.activate("test-key")

    assert not success
    assert "different product" in msg


def test_validate_online_success(tmp_path):
    """Mock API → updates last_validated."""
    old_validated = (datetime.now() - timedelta(days=10)).isoformat()
    data = {
        "license_key": "test-key",
        "instance_id": "inst-123",
        "status": "active",
        "last_validated": old_validated,
    }
    lm = _make_manager(tmp_path, data)

    mock_response = MagicMock()
    mock_response.json.return_value = {
        "valid": True,
        "license_key": {"status": "active"},
    }

    with patch("getinvoke.license.httpx.post", return_value=mock_response):
        status = lm.check()

    assert status == LicenseStatus.ACTIVE
    saved = json.loads((tmp_path / "license.json").read_text())
    # last_validated should be updated (newer than old)
    assert saved["last_validated"] > old_validated


def test_validate_offline_within_grace(tmp_path):
    """No network, last validated 10 days ago → allowed."""
    data = {
        "license_key": "test-key",
        "instance_id": "inst-123",
        "status": "active",
        "last_validated": (datetime.now() - timedelta(days=10)).isoformat(),
    }
    lm = _make_manager(tmp_path, data)

    with patch("getinvoke.license.httpx.post", side_effect=Exception("no network")):
        status = lm.check()

    assert status == LicenseStatus.GRACE


def test_validate_offline_past_grace(tmp_path):
    """No network, last validated 35 days ago → blocked."""
    data = {
        "license_key": "test-key",
        "instance_id": "inst-123",
        "status": "active",
        "last_validated": (datetime.now() - timedelta(days=GRACE_DAYS + 5)).isoformat(),
    }
    lm = _make_manager(tmp_path, data)

    with patch("getinvoke.license.httpx.post", side_effect=Exception("no network")):
        status = lm.check()

    assert status == LicenseStatus.INVALID


def test_deactivate(tmp_path):
    """Deactivate removes instance, resets state."""
    data = {
        "license_key": "test-key",
        "instance_id": "inst-123",
        "status": "active",
        "trial_started": datetime.now().isoformat(),
        "last_validated": datetime.now().isoformat(),
    }
    lm = _make_manager(tmp_path, data)

    mock_response = MagicMock()
    mock_response.json.return_value = {"deactivated": True}

    with patch("getinvoke.license.httpx.post", return_value=mock_response):
        success, msg = lm.deactivate()

    assert success
    assert lm.status == LicenseStatus.EXPIRED_TRIAL
    saved = json.loads((tmp_path / "license.json").read_text())
    assert "instance_id" not in saved


def test_tier_invoke(tmp_path):
    """Product ID 887386 → invoke tier."""
    data = {"status": "active", "product_id": PRODUCT_ID_INVOKE}
    lm = _make_manager(tmp_path, data)
    assert lm.tier == "invoke"


def test_tier_invoke_plus(tmp_path):
    """Product ID 887402 → invoke_plus tier."""
    data = {"status": "active", "product_id": PRODUCT_ID_INVOKE_PLUS}
    lm = _make_manager(tmp_path, data)
    assert lm.tier == "invoke_plus"


def test_tier_trial(tmp_path):
    """No product_id → trial tier."""
    lm = _make_manager(tmp_path)
    assert lm.tier == "trial"


def test_updates_eligible_invoke_plus_always(tmp_path):
    """Invoke+ gets lifetime updates regardless of activation date."""
    data = {
        "status": "active",
        "product_id": PRODUCT_ID_INVOKE_PLUS,
        "activated_at": (datetime.now() - timedelta(days=999)).isoformat(),
        "last_validated": datetime.now().isoformat(),
    }
    lm = _make_manager(tmp_path, data)
    lm._status = LicenseStatus.ACTIVE
    assert lm.updates_eligible is True


def test_updates_eligible_invoke_within_year(tmp_path):
    """Invoke tier within 1 year → eligible."""
    data = {
        "status": "active",
        "product_id": PRODUCT_ID_INVOKE,
        "activated_at": (datetime.now() - timedelta(days=100)).isoformat(),
        "last_validated": datetime.now().isoformat(),
    }
    lm = _make_manager(tmp_path, data)
    lm._status = LicenseStatus.ACTIVE
    assert lm.updates_eligible is True


def test_updates_not_eligible_invoke_past_year(tmp_path):
    """Invoke tier past 1 year → not eligible."""
    data = {
        "status": "active",
        "product_id": PRODUCT_ID_INVOKE,
        "activated_at": (datetime.now() - timedelta(days=UPDATE_ELIGIBILITY_DAYS + 10)).isoformat(),
        "last_validated": datetime.now().isoformat(),
    }
    lm = _make_manager(tmp_path, data)
    lm._status = LicenseStatus.ACTIVE
    assert lm.updates_eligible is False


def test_updates_eligible_trial(tmp_path):
    """Trial users get updates (need them to evaluate)."""
    lm = _make_manager(tmp_path)
    lm._status = LicenseStatus.TRIAL
    assert lm.updates_eligible is True
