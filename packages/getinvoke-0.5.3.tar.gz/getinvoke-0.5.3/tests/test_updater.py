"""Tests for auto-updater module."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from getinvoke.updater import UpdateInfo, _parse_version, check_for_update, is_pip_installed


def test_parse_version():
    """Should parse version strings into tuples."""
    assert _parse_version("0.2.0") == (0, 2, 0)
    assert _parse_version("v0.3.0") == (0, 3, 0)
    assert _parse_version("1.0.0") == (1, 0, 0)
    assert _parse_version("invalid") == (0,)


def test_check_no_update():
    """Mock API returns current version → None."""
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.raise_for_status = MagicMock()
    mock_response.json.return_value = {
        "tag_name": "v0.2.0",
        "assets": [{"name": "invoke-setup-0.2.0.exe", "browser_download_url": "https://example.com/dl"}],
    }

    with (
        patch("getinvoke.updater.httpx.get", return_value=mock_response),
        patch("getinvoke.updater.__version__", "0.2.0"),
    ):
        result = check_for_update()
    assert result is None


def test_check_has_update():
    """Mock API returns newer version → UpdateInfo."""
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.raise_for_status = MagicMock()
    mock_response.json.return_value = {
        "tag_name": "v0.3.0",
        "assets": [
            {
                "name": "invoke-setup-0.3.0.exe",
                "browser_download_url": "https://github.com/zmroth/invoke/releases/download/v0.3.0/invoke-setup-0.3.0.exe",
            }
        ],
    }

    with (
        patch("getinvoke.updater.httpx.get", return_value=mock_response),
        patch("getinvoke.updater.__version__", "0.2.0"),
    ):
        result = check_for_update()

    assert result is not None
    assert result.version == "0.3.0"
    # pip installs get empty download_url; PyInstaller builds get the .exe URL
    if is_pip_installed():
        assert result.download_url == ""
    else:
        assert "invoke-setup-0.3.0.exe" in result.download_url


def test_check_network_error():
    """Should return None on network error."""
    with patch("getinvoke.updater.httpx.get", side_effect=Exception("no network")):
        result = check_for_update()
    assert result is None


@pytest.mark.asyncio
async def test_download_writes_file(tmp_path):
    """Mock download → file exists at expected path (PyInstaller builds only)."""
    from getinvoke.updater import download_update

    info = UpdateInfo(
        version="0.3.0",
        download_url="https://github.com/zmroth/invoke/releases/download/v0.3.0/invoke-setup-0.3.0.exe",
        asset_name="invoke-setup-0.3.0.exe",
    )

    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.raise_for_status = MagicMock()
    mock_response.content = b"x" * 2_000_000  # Fake installer bytes

    mock_client = AsyncMock()
    mock_client.get.return_value = mock_response
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)

    with (
        patch("getinvoke.updater.httpx.AsyncClient", return_value=mock_client),
        patch("getinvoke.updater.settings") as mock_settings,
        patch("getinvoke.updater.is_pip_installed", return_value=False),
    ):
        mock_settings.config_dir = tmp_path
        result = await download_update(info)

    assert result is not None
    assert result.exists()
    assert result.name == "invoke-setup-0.3.0.exe"


def test_apply_on_exit_launches_installer(tmp_path):
    """Should call subprocess.Popen with correct args."""
    import getinvoke.updater as updater_mod

    installer = tmp_path / "invoke-setup-0.3.0.exe"
    installer.write_bytes(b"fake")
    updater_mod.pending_update = installer

    with patch("getinvoke.updater.subprocess.Popen") as mock_popen:
        updater_mod.apply_pending_update()

    mock_popen.assert_called_once()
    args = mock_popen.call_args[0][0]
    assert str(installer) in args[0]
    assert "/VERYSILENT" in args
