"""Tests for dictation history."""

from unittest.mock import patch

from getinvoke import history


def test_init_and_save(tmp_path):
    """Should create database and save entries."""
    db_path = tmp_path / "test.db"
    with patch("getinvoke.history.settings") as mock_settings:
        mock_settings.HISTORY_ENABLED = True
        mock_settings.HISTORY_RETENTION_DAYS = 30
        mock_settings.db_path = db_path

        history.init_db()
        assert db_path.exists()

        history.save_entry(
            raw_text="uh fix the bug",
            reformatted="Fix the bug.",
            mode="claude-code",
            cwd="/home/user/project",
            duration_ms=1500,
        )

        entries = history.get_recent(10)
        assert len(entries) == 1
        assert entries[0]["raw_text"] == "uh fix the bug"
        assert entries[0]["reformatted"] == "Fix the bug."
        assert entries[0]["mode"] == "claude-code"
        assert entries[0]["duration_ms"] == 1500

        history.close_db()


def test_search(tmp_path):
    """Should find entries by text search."""
    db_path = tmp_path / "test.db"
    with patch("getinvoke.history.settings") as mock_settings:
        mock_settings.HISTORY_ENABLED = True
        mock_settings.HISTORY_RETENTION_DAYS = 30
        mock_settings.db_path = db_path

        history.init_db()

        history.save_entry("add a button", "Add a button.", "claude-code")
        history.save_entry("fix the database", "Fix the database.", "cursor")
        history.save_entry("run the tests", "Run the tests.", "raw")

        results = history.search("database")
        assert len(results) == 1
        assert "database" in results[0]["raw_text"]

        results = history.search("the")
        assert len(results) == 2  # "fix the database" and "run the tests"

        history.close_db()


def test_count(tmp_path):
    """Should return correct entry count."""
    db_path = tmp_path / "test.db"
    with patch("getinvoke.history.settings") as mock_settings:
        mock_settings.HISTORY_ENABLED = True
        mock_settings.HISTORY_RETENTION_DAYS = 30
        mock_settings.db_path = db_path

        history.init_db()

        assert history.count() == 0
        history.save_entry("test", "test", "raw")
        assert history.count() == 1
        history.save_entry("test2", "test2", "raw")
        assert history.count() == 2

        history.close_db()


def test_disabled_history():
    """Should be a no-op when history is disabled."""
    with patch("getinvoke.history.settings") as mock_settings:
        mock_settings.HISTORY_ENABLED = False

        history.init_db()
        history.save_entry("test", "test", "raw")
        assert history.get_recent() == []
        assert history.count() == 0
        history.close_db()
