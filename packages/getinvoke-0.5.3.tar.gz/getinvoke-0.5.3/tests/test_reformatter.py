"""Tests for reformatter module."""

from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from getinvoke.reformatter import _summarize_context, reformat_dictation


def test_summarize_context_package_json():
    """Should extract project name and tech hints from package.json."""
    context = '[package.json]\n{\n  "name": "my-app",\n  "dependencies": {\n    "react": "^18.0.0"\n  }\n}'
    summary = _summarize_context(context)
    assert "my-app" in summary


def test_summarize_context_pyproject():
    """Should detect Python from pyproject.toml."""
    context = '[pyproject.toml]\n[project]\nname = "mylib"\nrequires-python = ">=3.11"'
    summary = _summarize_context(context)
    assert "Python" in summary


def test_summarize_context_claude_md():
    """Should grab first meaningful line from CLAUDE.md."""
    context = "[CLAUDE.md]\n# My Project\n\nThis is a TypeScript monorepo for building APIs."
    summary = _summarize_context(context)
    assert "TypeScript monorepo" in summary


def test_summarize_context_cursorrules():
    """Should grab first meaningful line from .cursorrules."""
    context = "[.cursorrules]\n# Rules\n\nThis is a Next.js project with Tailwind CSS."
    summary = _summarize_context(context)
    assert "Next.js" in summary


def test_summarize_context_empty():
    """Should return 'unknown project' for empty context."""
    assert _summarize_context("") == "unknown project"


@pytest.mark.asyncio
async def test_reformat_openrouter_success():
    """Should call OpenRouter API and return reformatted text."""
    mock_response = MagicMock()
    mock_response.json.return_value = {"choices": [{"message": {"content": "Clean prompt text"}}]}
    mock_response.raise_for_status = MagicMock()

    with patch("getinvoke.reformatter.settings") as mock_settings:
        mock_settings.REFORMATTER_BACKEND = "openrouter"
        mock_settings.OPENROUTER_API_KEY = "test-key"
        mock_settings.DICTATION_MODEL = "test/model"
        mock_settings.MODE = "claude-code"

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            result = await reformat_dictation("uh fix the bug in the thing")
            assert result == "Clean prompt text"


@pytest.mark.asyncio
async def test_reformat_no_api_key_falls_back():
    """Should return raw text when no API key is set."""
    with patch("getinvoke.reformatter.settings") as mock_settings:
        mock_settings.REFORMATTER_BACKEND = "openrouter"
        mock_settings.OPENROUTER_API_KEY = ""
        mock_settings.MODE = "claude-code"

        result = await reformat_dictation("raw text here")
        assert result == "raw text here"


@pytest.mark.asyncio
async def test_reformat_with_context():
    """Should prepend context summary to the user message."""
    mock_response = MagicMock()
    mock_response.json.return_value = {"choices": [{"message": {"content": "Contextualized prompt"}}]}
    mock_response.raise_for_status = MagicMock()

    with patch("getinvoke.reformatter.settings") as mock_settings:
        mock_settings.REFORMATTER_BACKEND = "openrouter"
        mock_settings.OPENROUTER_API_KEY = "test-key"
        mock_settings.DICTATION_MODEL = "test/model"
        mock_settings.MODE = "claude-code"

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            context = '[package.json]\n{"name": "my-app"}'
            result = await reformat_dictation("fix the tests", context)
            assert result == "Contextualized prompt"

            # Verify context was included in the API call
            call_args = mock_client.post.call_args
            messages = call_args.kwargs["json"]["messages"]
            user_msg = messages[1]["content"]
            assert "[Project context:" in user_msg


@pytest.mark.asyncio
async def test_reformat_with_mode_override():
    """Should use the specified mode's system prompt."""
    mock_response = MagicMock()
    mock_response.json.return_value = {"choices": [{"message": {"content": "Cursor prompt"}}]}
    mock_response.raise_for_status = MagicMock()

    with patch("getinvoke.reformatter.settings") as mock_settings:
        mock_settings.REFORMATTER_BACKEND = "openrouter"
        mock_settings.OPENROUTER_API_KEY = "test-key"
        mock_settings.DICTATION_MODEL = "test/model"
        mock_settings.MODE = "claude-code"

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            result = await reformat_dictation("fix the tests", mode="cursor")
            assert result == "Cursor prompt"

            # Verify the system prompt is for cursor mode
            call_args = mock_client.post.call_args
            messages = call_args.kwargs["json"]["messages"]
            system_msg = messages[0]["content"]
            assert "Cursor" in system_msg


@pytest.mark.asyncio
async def test_reformat_ollama_success():
    """Should call Ollama API and return reformatted text."""
    mock_response = MagicMock()
    mock_response.json.return_value = {"message": {"content": "Ollama result"}}
    mock_response.raise_for_status = MagicMock()

    with patch("getinvoke.reformatter.settings") as mock_settings:
        mock_settings.REFORMATTER_BACKEND = "ollama"
        mock_settings.OLLAMA_URL = "http://localhost:11434"
        mock_settings.OLLAMA_MODEL = "llama3.2"
        mock_settings.MODE = "raw"

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            result = await reformat_dictation("clean this up", mode="raw")
            assert result == "Ollama result"


@pytest.mark.asyncio
async def test_reformat_none_backend():
    """Should return raw text immediately when backend is 'none'."""
    with patch("getinvoke.reformatter.settings") as mock_settings:
        mock_settings.REFORMATTER_BACKEND = "none"
        mock_settings.MODE = "claude-code"
        result = await reformat_dictation("uh fix the bug in the thing")
        assert result == "uh fix the bug in the thing"


@pytest.mark.asyncio
async def test_reformat_with_metadata():
    """Should use rich metadata context instead of legacy one-line summary."""
    from getinvoke.context import ProjectMetadata

    mock_response = MagicMock()
    mock_response.json.return_value = {"choices": [{"message": {"content": "Rich context result"}}]}
    mock_response.raise_for_status = MagicMock()

    metadata = ProjectMetadata(
        name="keygrip",
        stack=["TypeScript", "React"],
        conventions="camelCase/PascalCase",
        dependencies=["react", "next"],
        file_manifest=["src/api/routes.ts", "src/components/App.tsx"],
        active_file="src/api/routes.ts",
    )

    with patch("getinvoke.reformatter.settings") as mock_settings:
        mock_settings.REFORMATTER_BACKEND = "openrouter"
        mock_settings.OPENROUTER_API_KEY = "test-key"
        mock_settings.DICTATION_MODEL = "test/model"
        mock_settings.MODE = "claude-code"

        with patch("httpx.AsyncClient") as mock_client_cls:
            mock_client = AsyncMock()
            mock_client.post.return_value = mock_response
            mock_client.__aenter__ = AsyncMock(return_value=mock_client)
            mock_client.__aexit__ = AsyncMock(return_value=False)
            mock_client_cls.return_value = mock_client

            result = await reformat_dictation("add a use effect hook", metadata=metadata)
            assert result == "Rich context result"

            # Verify rich context was included
            call_args = mock_client.post.call_args
            messages = call_args.kwargs["json"]["messages"]
            user_msg = messages[1]["content"]
            assert "Project: keygrip" in user_msg
            assert "Stack: TypeScript, React" in user_msg
            assert "Files:" in user_msg
            assert "Active file:" in user_msg
