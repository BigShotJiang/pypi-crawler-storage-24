"""Shared test fixtures."""

import pytest


@pytest.fixture(autouse=True)
def _clean_env(monkeypatch):
    """Ensure tests don't leak env vars."""
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)
    monkeypatch.delenv("REFORMATTER_BACKEND", raising=False)
    monkeypatch.delenv("WHISPER_MODEL", raising=False)
