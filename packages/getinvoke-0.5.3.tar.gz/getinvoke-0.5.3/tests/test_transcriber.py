"""Tests for transcriber module."""

from unittest.mock import MagicMock, patch

from getinvoke.transcriber import transcribe


def test_transcribe_cuda_fallback():
    """Should fall back to CPU if CUDA inference fails with missing library."""
    # Create a mock model that fails on first transcribe (CUDA), works on second (CPU)
    mock_model = MagicMock()
    call_count = 0

    def fake_transcribe(source, **kwargs):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            raise RuntimeError("Library cublas64_12.dll is not found or cannot be loaded")
        # Second call (after CPU reload) succeeds
        seg = MagicMock()
        seg.text = "hello world"
        return iter([seg]), MagicMock()

    mock_model.transcribe.side_effect = fake_transcribe

    with (
        patch("getinvoke.transcriber._model", mock_model),
        patch("getinvoke.transcriber._reload_model_on_cpu") as mock_reload,
    ):
        # After reload, the module-level _model is still our mock,
        # so the second transcribe call hits fake_transcribe again
        result = transcribe(b"\x00" * 1000)
        assert result == "hello world"
        mock_reload.assert_called_once()


def test_transcribe_non_cuda_error_reraises():
    """Should re-raise RuntimeErrors that aren't CUDA-related."""
    mock_model = MagicMock()
    mock_model.transcribe.side_effect = RuntimeError("some other error")

    with patch("getinvoke.transcriber._model", mock_model):
        try:
            transcribe(b"\x00" * 1000)
            assert False, "Should have raised RuntimeError"
        except RuntimeError as e:
            assert "some other error" in str(e)


def test_transcribe_uses_language_setting():
    """Should pass language setting to Whisper when not 'auto'."""
    mock_model = MagicMock()
    seg = MagicMock()
    seg.text = "test"
    mock_model.transcribe.return_value = (iter([seg]), MagicMock())

    with (
        patch("getinvoke.transcriber._model", mock_model),
        patch("getinvoke.transcriber.settings") as mock_settings,
    ):
        mock_settings.LANGUAGE = "es"
        mock_settings.CUSTOM_VOCAB = ""
        mock_settings.hotwords = []
        transcribe(b"\x00" * 1000)
        call_kwargs = mock_model.transcribe.call_args[1]
        assert call_kwargs["language"] == "es"


def test_transcribe_auto_language_omits_param():
    """Should omit language param when set to 'auto' for Whisper auto-detect."""
    mock_model = MagicMock()
    seg = MagicMock()
    seg.text = "test"
    mock_model.transcribe.return_value = (iter([seg]), MagicMock())

    with (
        patch("getinvoke.transcriber._model", mock_model),
        patch("getinvoke.transcriber.settings") as mock_settings,
    ):
        mock_settings.LANGUAGE = "auto"
        mock_settings.CUSTOM_VOCAB = ""
        mock_settings.hotwords = []
        transcribe(b"\x00" * 1000)
        call_kwargs = mock_model.transcribe.call_args[1]
        assert "language" not in call_kwargs
