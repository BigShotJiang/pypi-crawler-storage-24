# Build script for Invoke Windows installer
# Run from the repo root: powershell -ExecutionPolicy Bypass -File installer/build.ps1

param(
    [switch]$SkipInstaller,  # Only build PyInstaller, skip Inno Setup
    [switch]$Clean           # Clean build artifacts first
)

$ErrorActionPreference = "Stop"
$RepoRoot = Split-Path -Parent $PSScriptRoot

Write-Host "=== Invoke Build Script ===" -ForegroundColor Cyan
Write-Host "Repo root: $RepoRoot"

# Ensure we're in the repo root
Set-Location $RepoRoot

# Clean previous builds
if ($Clean) {
    Write-Host "`n--- Cleaning previous builds ---" -ForegroundColor Yellow
    if (Test-Path "dist") { Remove-Item -Recurse -Force "dist" }
    if (Test-Path "build") { Remove-Item -Recurse -Force "build" }
    Write-Host "Cleaned."
}

# Check prerequisites
Write-Host "`n--- Checking prerequisites ---" -ForegroundColor Yellow

# Python
$python = Get-Command python -ErrorAction SilentlyContinue
if (-not $python) {
    Write-Host "ERROR: Python not found in PATH" -ForegroundColor Red
    exit 1
}
Write-Host "Python: $(python --version)"

# PyInstaller
try {
    python -m PyInstaller --version 2>$null | Out-Null
    Write-Host "PyInstaller: $(python -m PyInstaller --version)"
} catch {
    Write-Host "Installing PyInstaller..."
    pip install pyinstaller
}

# Inno Setup
$iscc = Get-Command iscc -ErrorAction SilentlyContinue
if (-not $iscc) {
    $isccPath = "C:\Program Files (x86)\Inno Setup 6\ISCC.exe"
    if (Test-Path $isccPath) {
        $iscc = $isccPath
    } else {
        Write-Host "WARNING: Inno Setup not found. Installer step will be skipped." -ForegroundColor Yellow
        $SkipInstaller = $true
    }
} else {
    $iscc = $iscc.Source
}

# Install the package in the current environment
Write-Host "`n--- Installing package ---" -ForegroundColor Yellow
pip install -e ".[dev]" --quiet

# Step 1: PyInstaller
Write-Host "`n--- Building with PyInstaller ---" -ForegroundColor Yellow
python -m PyInstaller installer/invoke.spec --noconfirm --clean

if (-not (Test-Path "dist/invoke/invoke.exe")) {
    Write-Host "ERROR: PyInstaller build failed — invoke.exe not found" -ForegroundColor Red
    exit 1
}

Write-Host "PyInstaller build complete: dist/invoke/" -ForegroundColor Green

# Quick smoke test
Write-Host "`n--- Smoke test ---" -ForegroundColor Yellow
try {
    $output = & "dist/invoke/invoke-cli.exe" health 2>&1
    Write-Host $output
    Write-Host "Smoke test passed!" -ForegroundColor Green
} catch {
    Write-Host "WARNING: Smoke test failed (may need audio device)" -ForegroundColor Yellow
}

# Step 2: Inno Setup installer
if (-not $SkipInstaller) {
    Write-Host "`n--- Building installer with Inno Setup ---" -ForegroundColor Yellow

    # Check for icon file
    if (-not (Test-Path "installer/invoke.ico")) {
        Write-Host "WARNING: installer/invoke.ico not found. Installer will use default icon." -ForegroundColor Yellow
    }

    & $iscc "installer/invoke.iss"

    $installerPath = Get-ChildItem "dist/invoke-setup-*.exe" | Select-Object -First 1
    if ($installerPath) {
        $size = [math]::Round($installerPath.Length / 1MB, 1)
        Write-Host "`nInstaller built: $($installerPath.FullName) ($size MB)" -ForegroundColor Green
    } else {
        Write-Host "ERROR: Installer not found in dist/" -ForegroundColor Red
        exit 1
    }
} else {
    Write-Host "`n--- Skipping Inno Setup (--SkipInstaller) ---" -ForegroundColor Yellow
}

Write-Host "`n=== Build complete ===" -ForegroundColor Cyan
