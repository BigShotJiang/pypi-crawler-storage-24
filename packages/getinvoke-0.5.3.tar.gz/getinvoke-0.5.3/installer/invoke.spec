# -*- mode: python ; coding: utf-8 -*-
"""PyInstaller spec file for Invoke.

Usage:
    cd invoke/
    pyinstaller installer/invoke.spec
"""

import sys
from pathlib import Path

from PyInstaller.utils.hooks import collect_data_files

block_cipher = None

ROOT = Path(SPECPATH).parent
SRC = ROOT / "src"

# Collect data files that PyInstaller misses
datas = []
datas += collect_data_files("faster_whisper")  # Includes assets/silero_vad_v6.onnx (VAD model)
datas += collect_data_files("_sounddevice_data")  # PortAudio DLLs

a = Analysis(
    [str(SRC / "getinvoke" / "__main__.py")],
    pathex=[str(SRC)],
    binaries=[],
    datas=datas,
    hiddenimports=[
        # pynput platform backends
        "pynput.keyboard._win32",
        "pynput.mouse._win32",
        # pystray platform backend
        "pystray._win32",
        # sounddevice/PortAudio
        "sounddevice",
        "_sounddevice_data",
        # faster-whisper / ctranslate2
        "faster_whisper",
        "ctranslate2",
        # tkinter (for wizard, settings, overlay)
        "tkinter",
        "tkinter.ttk",
        # click CLI
        "click",
        # other deps
        "httpx",
        "pyperclip",
        "dotenv",
        "PIL",
        "scipy.signal",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # Exclude PyTorch — we use CTranslate2 directly; CUDA DLLs bundled via CI
        "torch",
        "torchvision",
        "torchaudio",
        # Test / dev tools
        "pytest",
        "ruff",
        "setuptools",
        "pip",
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="invoke",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=False,  # GUI app — no console window
    icon=str(ROOT / "installer" / "invoke.ico") if (ROOT / "installer" / "invoke.ico").exists() else None,
)

# Also build a console version for CLI usage
exe_cli = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="invoke-cli",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=True,  # Console app for CLI commands
    icon=str(ROOT / "installer" / "invoke.ico") if (ROOT / "installer" / "invoke.ico").exists() else None,
)

coll = COLLECT(
    exe,
    exe_cli,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="invoke",
)
