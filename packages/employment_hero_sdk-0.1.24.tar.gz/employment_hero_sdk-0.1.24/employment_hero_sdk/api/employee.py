from datetime import datetime
from typing import Any, Dict, List, Optional
from .base import EmploymentHeroBase
from ..models import AuUnstructuredEmployeeModel
from ..models import AdditionalEarningsModel, AdditionalEarningsInputModel

class Employee(EmploymentHeroBase):
    """
    Employee API Wrapper.
    With a business parent, its URL becomes:
      {parent_path}/employee
    For example: /v2/business/{business_id}/employee
    """
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.model = AuUnstructuredEmployeeModel(**self.data)

    @property
    def full_name(self) -> str:
        return f"{self.model.firstName} {self.model.surname}".strip()

    async def grant_access_async(self, email: str, name: str) -> Dict[str, Any]:
        """Example method to grant access to an employee."""
        url = self._build_url(resource_id=self.data.get("id"), suffix="access")
        payload = {
            "email": email,
            "name": name,
            "suppressNotificationEmails": False
        }
        response = await self.client._request("POST", url, json=payload)
        return response.json()
    
    def list_additional_earnings(self) -> List[AdditionalEarningsModel]:
        url = self._build_url(resource_id=self.data.get("id"), suffix="additional-earnings")
        response = self.client._request("GET", url)
        return [AdditionalEarningsModel(**item) for item in response.json()]
    
    def create_additional_earning(
        self, 
        amount: float, 
        maximum_amount_paid: float, 
        pay_category_id: int,
        location_id: Optional[int] = None,
        expiry_date: Optional[datetime] = None, 
        notes: str = '',
        units: float = 1.0,
        super_rate: Optional[float] = None,
        override_super_rate: bool = False
    ) -> AdditionalEarningsModel:
        if not location_id:
            for location in self.location():
                if location.fullyQualifiedName == self.model.primaryLocation:
                    location_id = int(location.id)
                    break
                
        if not location_id:
            raise ValueError(f"Location not found for employee {self.model.id}")
        
        additional_earnings_input_model = AdditionalEarningsInputModel(
            id=None,
            employeeId=self.model.id,
            locationId=location_id,
            payCategoryId=pay_category_id,
            amount=amount,
            maximumAmountPaid=maximum_amount_paid,
            expiryDate=expiry_date,
            notes=notes,
            units=units,
            superRate=super_rate,
            overrideSuperRate=override_super_rate
        )
        url = self._build_url(resource_id=self.data.get("id"), suffix="additional-earnings")
        response = self.client._request("POST", url, json=additional_earnings_input_model.model_dump(exclude_none=True))
        return AdditionalEarningsModel(**response.json())
    
    def update_additional_earning(
        self, 
        additional_earning_id: int, 
        amount: Optional[float] = None, 
        maximum_amount_paid: Optional[float] = None, 
        expiry_date: Optional[datetime] = None, 
        location_id: Optional[int] = None,
        pay_category_id: Optional[int] = None,
        notes: Optional[str] = None,
        units: Optional[float] = None,
        super_rate: Optional[float] = None,
        override_super_rate: Optional[bool] = None
    ) -> AdditionalEarningsModel:
        additional_earnings_input_model = AdditionalEarningsInputModel(
            id=additional_earning_id,
            employeeId=self.model.id,
            locationId=location_id,
            payCategoryId=pay_category_id,
            amount=amount,
            maximumAmountPaid=maximum_amount_paid,
            expiryDate=expiry_date,
            notes=notes,
            units=units,
            superRate=super_rate,
            overrideSuperRate=override_super_rate
        )
        url = self._build_url(resource_id=self.data.get("id"), suffix=f"additional-earnings/{additional_earning_id}")
        response = self.client._request("PUT", url, json=additional_earnings_input_model.model_dump(exclude_none=True))
        return AdditionalEarningsModel(**response.json())
    
    def delete_additional_earning(self, additional_earning_id: int) -> None:
        url = self._build_url(resource_id=self.data.get("id"), suffix=f"additional-earnings/{additional_earning_id}")
        self.client._request("DELETE", url)