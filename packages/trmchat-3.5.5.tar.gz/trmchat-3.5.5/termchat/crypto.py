"""E2E encryption using X25519 + AES-256-GCM."""
from __future__ import annotations

import base64
import os
from pathlib import Path

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey, X25519PublicKey
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF

from termchat.config import CONFIG_DIR

KEYS_DIR = CONFIG_DIR / "keys"
ENC_PREFIX = "ENC:"


def _ensure_keys_dir() -> Path:
    KEYS_DIR.mkdir(parents=True, exist_ok=True)
    return KEYS_DIR


def generate_keypair(username: str) -> tuple[bytes, bytes]:
    """Generate X25519 keypair. Returns (private_key_bytes, public_key_bytes)."""
    private_key = X25519PrivateKey.generate()
    public_key = private_key.public_key()

    priv_bytes = private_key.private_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PrivateFormat.Raw,
        encryption_algorithm=serialization.NoEncryption(),
    )
    pub_bytes = public_key.public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )

    # Save private key
    key_dir = _ensure_keys_dir()
    key_file = key_dir / f"{username}.key"
    key_file.write_bytes(priv_bytes)
    os.chmod(str(key_file), 0o600)

    return priv_bytes, pub_bytes


def load_private_key(username: str) -> X25519PrivateKey | None:
    """Load private key from disk."""
    key_file = KEYS_DIR / f"{username}.key"
    if not key_file.exists():
        return None
    priv_bytes = key_file.read_bytes()
    return X25519PrivateKey.from_private_bytes(priv_bytes)


def get_public_key_b64(username: str) -> str | None:
    """Get base64-encoded public key for a user."""
    private_key = load_private_key(username)
    if not private_key:
        return None
    pub_bytes = private_key.public_key().public_bytes(
        encoding=serialization.Encoding.Raw,
        format=serialization.PublicFormat.Raw,
    )
    return base64.b64encode(pub_bytes).decode()


def has_keypair(username: str) -> bool:
    """Check if keypair exists for user."""
    return (KEYS_DIR / f"{username}.key").exists()


def _derive_shared_key(private_key: X25519PrivateKey, peer_public_b64: str) -> bytes:
    """Derive shared AES key from ECDH."""
    peer_pub_bytes = base64.b64decode(peer_public_b64)
    peer_public = X25519PublicKey.from_public_bytes(peer_pub_bytes)
    shared_secret = private_key.exchange(peer_public)

    # Derive 256-bit key using HKDF
    return HKDF(
        algorithm=hashes.SHA256(),
        length=32,
        salt=None,
        info=b"termchat-e2e-v1",
    ).derive(shared_secret)


def encrypt_message(content: str, my_username: str, peer_public_b64: str) -> str:
    """Encrypt a message for a peer. Returns ENC:<base64> string."""
    private_key = load_private_key(my_username)
    if not private_key or not peer_public_b64:
        return content  # Can't encrypt, send plaintext

    key = _derive_shared_key(private_key, peer_public_b64)
    nonce = os.urandom(12)
    aesgcm = AESGCM(key)
    ciphertext = aesgcm.encrypt(nonce, content.encode("utf-8"), None)

    # Pack: nonce (12 bytes) + ciphertext
    payload = nonce + ciphertext
    return ENC_PREFIX + base64.b64encode(payload).decode()


def decrypt_message(content: str, my_username: str, peer_public_b64: str) -> str:
    """Decrypt a message from a peer. Returns plaintext."""
    if not content.startswith(ENC_PREFIX):
        return content  # Not encrypted

    private_key = load_private_key(my_username)
    if not private_key or not peer_public_b64:
        return "[dim]\\[encrypted][/]"

    try:
        payload = base64.b64decode(content[len(ENC_PREFIX):])
        nonce = payload[:12]
        ciphertext = payload[12:]

        key = _derive_shared_key(private_key, peer_public_b64)
        aesgcm = AESGCM(key)
        plaintext = aesgcm.decrypt(nonce, ciphertext, None)
        return plaintext.decode("utf-8")
    except Exception:
        return "[dim]\\[encrypted - cannot decrypt][/]"


def is_encrypted(content: str) -> bool:
    """Check if a message is encrypted."""
    return content.startswith(ENC_PREFIX)
