
{
    "version": "1.6.0",
    "target": "default",
    "variant": "cpu"
}
