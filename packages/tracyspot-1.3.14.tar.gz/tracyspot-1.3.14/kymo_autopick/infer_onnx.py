from __future__ import annotations

import os
from pathlib import Path
from typing import Sequence

import numpy as np

from .io import ensure_time_axis, percentile_normalize

_SESSION_CACHE: dict[tuple[str, tuple[str, ...]], object] = {}


def _default_providers(ort) -> list[str]:
    available = set(ort.get_available_providers())
    preferred = ["CUDAExecutionProvider", "CPUExecutionProvider"]
    return [p for p in preferred if p in available] or ["CPUExecutionProvider"]


def _parse_positive_int_env(name: str) -> int:
    raw = os.environ.get(name, "").strip()
    if not raw:
        return 0
    try:
        val = int(raw)
    except Exception:
        return 0
    return val if val > 0 else 0


def _session_options_from_env(ort):
    # Explicitly setting thread counts disables ORT's default thread affinity.
    intra = _parse_positive_int_env("TRACY_ORT_INTRA_THREADS")
    if intra <= 0:
        intra = _parse_positive_int_env("TRACY_ORT_THREADS")
    inter = _parse_positive_int_env("TRACY_ORT_INTER_THREADS")

    if intra <= 0 and inter <= 0:
        return None

    opts = ort.SessionOptions()
    if intra > 0:
        opts.intra_op_num_threads = int(intra)
    if inter > 0:
        opts.inter_op_num_threads = int(inter)
    return opts


def get_onnx_session(onnx_path: str | Path, providers: Sequence[str] | None = None):
    try:
        import onnxruntime as ort  # type: ignore
    except Exception as exc:
        raise RuntimeError("onnxruntime is required for ONNX inference") from exc

    path = str(Path(onnx_path).expanduser().resolve())
    providers_tuple = tuple(providers) if providers else tuple(_default_providers(ort))
    key = (path, providers_tuple)
    sess = _SESSION_CACHE.get(key)
    if sess is None:
        sess_opts = _session_options_from_env(ort)
        sess = ort.InferenceSession(path, sess_options=sess_opts, providers=list(providers_tuple))
        _SESSION_CACHE[key] = sess
    return sess


def _run_outputs_on_tx_norm(
    tx_norm: np.ndarray,
    onnx_path: str | Path,
    *,
    providers: Sequence[str] | None = None,
    align_factor: int = 8,
) -> list[np.ndarray]:
    if tx_norm.ndim != 2:
        raise ValueError(f"Expected normalized (T, X) image, got shape {tx_norm.shape!r}")
    tx_norm = np.asarray(tx_norm, dtype=np.float32)
    orig_t, orig_x = tx_norm.shape

    pad_t = 0
    pad_x = 0
    if align_factor and align_factor > 1:
        pad_t = int((align_factor - (orig_t % align_factor)) % align_factor)
        pad_x = int((align_factor - (orig_x % align_factor)) % align_factor)
    if pad_t or pad_x:
        tx_norm = np.pad(tx_norm, ((0, pad_t), (0, pad_x)), mode="edge")

    inp = tx_norm[None, None, :, :].astype(np.float32)

    session = get_onnx_session(onnx_path, providers=providers)
    input_name = session.get_inputs()[0].name
    raw_outs = session.run(None, {input_name: inp})

    outs: list[np.ndarray] = []
    for out in raw_outs:
        arr = np.asarray(out)
        if arr.ndim != 4:
            raise ValueError(f"Expected ONNX output with shape [N,C,T,X], got {arr.shape!r}")
        chw = np.asarray(arr[0], dtype=np.float32)
        if pad_t or pad_x:
            chw = chw[:, :orig_t, :orig_x]
        outs.append(chw)
    return outs


def _run_logits_on_tx_norm(
    tx_norm: np.ndarray,
    onnx_path: str | Path,
    *,
    providers: Sequence[str] | None = None,
    align_factor: int = 8,
) -> np.ndarray:
    outs = _run_outputs_on_tx_norm(tx_norm, onnx_path, providers=providers, align_factor=align_factor)
    if not outs:
        raise RuntimeError("ONNX model returned no outputs")
    return outs[0]


def infer_logits_onnx(
    kymo_array: np.ndarray,
    onnx_path: str | Path,
    *,
    time_axis: str = "y",
    providers: Sequence[str] | None = None,
    align_factor: int = 8,
) -> np.ndarray:
    arr = np.asarray(kymo_array)
    if arr.ndim != 2:
        raise ValueError(f"Expected 2D kymograph input, got shape {arr.shape!r}")

    tx = ensure_time_axis(arr, time_axis=time_axis)
    tx_norm = percentile_normalize(tx)
    return _run_logits_on_tx_norm(tx_norm, onnx_path, providers=providers, align_factor=align_factor)


def infer_logits_and_embeddings_onnx(
    kymo_array: np.ndarray,
    onnx_path: str | Path,
    *,
    time_axis: str = "y",
    providers: Sequence[str] | None = None,
    align_factor: int = 8,
) -> tuple[np.ndarray, np.ndarray | None]:
    """Return segmentation logits and optional embedding map from ONNX.

    Returns:
        logits: [C, T, X]
        embeddings: [D, T, X] or None when model has a single output
    """

    arr = np.asarray(kymo_array)
    if arr.ndim != 2:
        raise ValueError(f"Expected 2D kymograph input, got shape {arr.shape!r}")

    tx = ensure_time_axis(arr, time_axis=time_axis)
    tx_norm = percentile_normalize(tx)
    outs = _run_outputs_on_tx_norm(tx_norm, onnx_path, providers=providers, align_factor=align_factor)
    if not outs:
        raise RuntimeError("ONNX model returned no outputs")
    logits = outs[0]
    embeddings = outs[1] if len(outs) > 1 else None
    return logits, embeddings


def softmax_np(logits: np.ndarray, axis: int = 0) -> np.ndarray:
    shifted = logits - np.max(logits, axis=axis, keepdims=True)
    ex = np.exp(shifted)
    return ex / np.sum(ex, axis=axis, keepdims=True)


def infer_prob_move_onnx(
    kymo_array: np.ndarray,
    onnx_path: str | Path,
    *,
    time_axis: str = "y",
    moving_class: int = 1,
    providers: Sequence[str] | None = None,
    dual_polarity: bool = False,
    dark_weight: float = 1.0,
) -> np.ndarray:
    arr = np.asarray(kymo_array)
    if arr.ndim != 2:
        raise ValueError(f"Expected 2D kymograph input, got shape {arr.shape!r}")

    tx = ensure_time_axis(arr, time_axis=time_axis)
    tx_norm = percentile_normalize(tx)

    logits = _run_logits_on_tx_norm(tx_norm, onnx_path, providers=providers)
    probs = softmax_np(logits, axis=0)
    if not (0 <= moving_class < probs.shape[0]):
        raise ValueError(f"moving_class={moving_class} out of range for logits with {probs.shape[0]} classes")
    prob_move = probs[moving_class].astype(np.float32)

    if dual_polarity:
        tx_inv = 1.0 - tx_norm
        logits_inv = _run_logits_on_tx_norm(tx_inv, onnx_path, providers=providers)
        probs_inv = softmax_np(logits_inv, axis=0)
        prob_move_inv = probs_inv[moving_class].astype(np.float32)
        w = float(max(0.0, dark_weight))
        if w == 0.0:
            pass
        elif w >= 1.0:
            prob_move = np.maximum(prob_move, prob_move_inv)
        else:
            prob_move = np.maximum(prob_move, w * prob_move_inv + (1.0 - w) * prob_move)

    # Return in same orientation as input.
    if (time_axis or "y").lower() == "x":
        prob_move = prob_move.T
    return prob_move.astype(np.float32)


def infer_prob_move_and_embeddings_onnx(
    kymo_array: np.ndarray,
    onnx_path: str | Path,
    *,
    time_axis: str = "y",
    moving_class: int = 1,
    providers: Sequence[str] | None = None,
) -> tuple[np.ndarray, np.ndarray | None]:
    """Return moving-class probability and optional embedding map.

    Returns:
        prob_move: [T, X] (same orientation as input)
        embeddings: [D, T, X] in input orientation (or None)
    """

    logits, embeddings = infer_logits_and_embeddings_onnx(
        kymo_array,
        onnx_path,
        time_axis=time_axis,
        providers=providers,
    )
    probs = softmax_np(logits, axis=0)
    if not (0 <= moving_class < probs.shape[0]):
        raise ValueError(f"moving_class={moving_class} out of range for logits with {probs.shape[0]} classes")
    prob_move = probs[moving_class].astype(np.float32)

    if (time_axis or "y").lower() == "x":
        prob_move = prob_move.T
        if embeddings is not None:
            embeddings = np.transpose(np.asarray(embeddings, dtype=np.float32), (0, 2, 1))
    elif embeddings is not None:
        embeddings = np.asarray(embeddings, dtype=np.float32)

    return prob_move.astype(np.float32), embeddings
