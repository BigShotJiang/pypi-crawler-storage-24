"""
Unified database management CLI.

All database operations under one command group:
    cli database prepare         # One-shot: sync everything, verify integrity
    cli database diff            # Compare environments (schema, indexes, data volumes)
    cli database sync-schema     # Apply missing indexes, constraints, triggers
    cli database sync-data       # Copy factory data safely from prod to dev
    cli database migrate         # Run migrations, check status
    cli database backfill        # Apply migrations from prod missing in dev
    cli database verify          # Validate DB state (integrity, referential, parity)
    cli database discover        # Find good factory candidates for data sync
    cli database status          # Overall database health summary
    cli database roles           # Role management
    cli database roles-setup     # Apply least-privilege roles/grants
    cli database audit           # Permission auditing
    cli database seed            # Run seed data scripts
"""

import asyncio
import json
import os
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Sequence

import asyncpg
import typer
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.syntax import Syntax
from rich.table import Table
from typing_extensions import Annotated

from cli.console import console, dim, error, info, success, warning
from cli.guard import require_write
from cli.context import get_connection
from infra.auth_principal_targets import get_runtime_targets_with_database_access
from infra.settings import Settings, switch_environment

# Import existing sync utilities
from cli.commands.sync.models import (
    SyncDiff,
)
from cli.commands.sync.queries import (
    fetch_constraints,
    fetch_indexes,
    fetch_materialized_views,
    fetch_sequences,
    fetch_triggers,
)
from cli.commands.sync.ddl import (
    generate_add_constraint_ddl,
    generate_index_ddl,
    generate_index_ddl_concurrent,
    generate_matview_ddl,
    generate_sequence_ddl,
    generate_trigger_ddl,
)

# =============================================================================
# Constants


async def _get_admin_connection(settings: Settings):
    """
    Get a system-admin database connection.

    Preferred path:
    - IAM auth using a dedicated admin service account

    Fallback path:
    - postgres via password auth
    """
    from infra.database import Database

    ip_type = "PRIVATE" if settings.use_private_ip else "PUBLIC"

    admin_iam_user = settings.effective_alloydb_admin_iam_user
    admin_impersonate_sa = settings.effective_alloydb_admin_impersonate_sa
    if admin_iam_user and admin_impersonate_sa:
        db = Database(
            instance_uri=settings.alloydb_instance_uri,
            database=settings.db_name,
            user=admin_iam_user,
            use_iam_auth=True,
            ip_type=ip_type,
            impersonate_sa=admin_impersonate_sa,
        )
        await db.connect()
        return db

    admin_password = os.getenv("ALLOYDB_PSW_PROD", "")
    if not admin_password:
        raise RuntimeError(
            "Admin credentials not configured.\n"
            "Set ALLOYDB_ADMIN_IAM_USER_* and ALLOYDB_ADMIN_IMPERSONATE_SA_* "
            "for IAM admin access, or set ALLOYDB_PSW_PROD for postgres password auth.\n"
        )

    db = Database(
        instance_uri=settings.alloydb_instance_uri,
        database=settings.db_name,
        user="postgres",
        password=admin_password,
        use_iam_auth=False,
        ip_type=ip_type,
    )

    await db.connect()
    return db


async def _set_owner_role(conn) -> bool:
    """
    Set role to buildai_owner for DDL operations.

    Returns True if successful, False if role doesn't exist or permission denied.
    """
    try:
        await conn.execute("SET ROLE buildai_owner")
        return True
    except Exception as e:
        if "does not exist" in str(e).lower() or "permission denied" in str(e).lower():
            return False
        raise


# =============================================================================

REPO_ROOT = Path(__file__).resolve().parents[4]
MIGRATIONS_DIR = REPO_ROOT / "migrations"
MIGRATIONS_TABLE = "public._migrations"
SEEDS_DIR = REPO_ROOT / "seeds"

# Table dependency ordering for safe data operations
TABLE_DEPENDENCY_ORDER = [
    # Level 0: No dependencies (root tables)
    "observations.embedding_spaces",
    "operations.device_models",
    "operations.organizations",
    "core.asset_types",
    # Level 1: Depends on Level 0
    "core.factories",
    "operations.devices",
    # Level 2: Depends on Level 1
    "core.workers",
    # Level 3: Depends on Level 2
    "core.sessions",
    # Level 4: Depends on Level 3
    "core.streams",
    # Level 5: Depends on Level 4
    "core.clips",
    # Level 6: Depends on Level 5
    "core.frames",
    "core.assets",
    "observations.emb_siglip2_ego100k_frame_default",
    "observations.emb_qwen_holistic_v1",
    "observations.clip_descriptions",
]

# =============================================================================
# Data Models
# =============================================================================


@dataclass
class DatabaseStatus:
    """Overall database health status."""

    environment: str
    database_name: str
    connected: bool = False
    # Schema parity
    indexes_synced: int = 0
    indexes_total: int = 0
    constraints_synced: int = 0
    constraints_total: int = 0
    triggers_synced: int = 0
    triggers_total: int = 0
    # Migrations
    migrations_applied: int = 0
    migrations_total: int = 0
    migrations_pending: int = 0
    # Data
    factories_count: int = 0
    clips_count: int = 0
    frames_count: int = 0
    embeddings_count: int = 0

    @property
    def is_healthy(self) -> bool:
        """Check if database is healthy for testing."""
        return (
            self.connected
            and self.migrations_pending == 0
            and self.factories_count > 0
            and self.clips_count > 0
        )

    @property
    def health_status(self) -> str:
        """Return health status string."""
        if not self.connected:
            return "DISCONNECTED"
        if self.migrations_pending > 0:
            return "MIGRATIONS PENDING"
        if self.factories_count == 0 or self.clips_count == 0:
            return "NO DATA"
        return "READY FOR TESTING"


@dataclass
class CopyPlan:
    """Plan for copying data from source to target."""

    source_env: str
    target_env: str
    tables: list[str]
    factory_id: str | None = None
    limit: int | None = None
    include_embeddings: bool = False
    row_counts: dict[str, int] = field(default_factory=dict)


@dataclass
class FactoryCandidate:
    """A factory candidate for data sync."""

    uuid: str
    name: str | None
    clip_count: int
    frame_count: int
    has_embeddings: bool
    worker_count: int


# =============================================================================
# Helper Functions
# =============================================================================


def _validate_sync_direction(
    source: str, target: str, operation: str, allow_prod_write: bool = False
) -> None:
    """Validate that the sync direction is allowed."""
    target_is_prod = target.lower() in ("prod", "production")

    if target_is_prod:
        if operation == "data":
            raise typer.BadParameter(
                "Data writes to production are BLOCKED. Use `cli promote` for migrations instead."
            )
        if operation == "schema" and not allow_prod_write:
            raise typer.BadParameter("Schema writes to production require --allow-prod-write flag.")


async def _get_table_row_count(
    conn: asyncpg.Connection, table: str, where_clause: str | None = None
) -> int:
    """Get row count for a table with optional filter."""
    if where_clause:
        # Use parameterized query for safety
        query = f"SELECT COUNT(*) FROM {table} WHERE {where_clause}"
    else:
        query = f"SELECT COUNT(*) FROM {table}"
    result = await conn.fetchval(query)
    return result or 0


async def _compute_diff(
    source_env: str,
    target_env: str,
    schemas: Sequence[str] | None = None,
    include_indexes: bool = True,
    include_constraints: bool = True,
    include_triggers: bool = True,
    include_matviews: bool = True,
    include_sequences: bool = True,
) -> SyncDiff:
    """Compute schema diff between two environments."""
    diff = SyncDiff(source_env=source_env, target_env=target_env)
    schema_list = list(schemas) if schemas else None

    # Fetch from source
    source_settings = switch_environment(source_env)
    async with get_connection(source_settings) as source_conn:
        source_indexes = await fetch_indexes(source_conn, schema_list) if include_indexes else []
        source_constraints = (
            await fetch_constraints(source_conn, schema_list) if include_constraints else []
        )
        source_triggers = await fetch_triggers(source_conn, schema_list) if include_triggers else []
        source_matviews = (
            await fetch_materialized_views(source_conn, schema_list) if include_matviews else []
        )
        source_sequences = (
            await fetch_sequences(source_conn, schema_list) if include_sequences else []
        )

    # Fetch from target
    target_settings = switch_environment(target_env)
    async with get_connection(target_settings) as target_conn:
        target_indexes = await fetch_indexes(target_conn, schema_list) if include_indexes else []
        target_constraints = (
            await fetch_constraints(target_conn, schema_list) if include_constraints else []
        )
        target_triggers = await fetch_triggers(target_conn, schema_list) if include_triggers else []
        target_matviews = (
            await fetch_materialized_views(target_conn, schema_list) if include_matviews else []
        )
        target_sequences = (
            await fetch_sequences(target_conn, schema_list) if include_sequences else []
        )

    # Compare by full_name
    def _compare(source_items: list, target_items: list) -> tuple[list, list]:
        source_by_name = {getattr(i, "full_name"): i for i in source_items}
        target_by_name = {getattr(i, "full_name"): i for i in target_items}
        source_names = set(source_by_name.keys())
        target_names = set(target_by_name.keys())
        missing = [source_by_name[n] for n in sorted(source_names - target_names)]
        extra = [target_by_name[n] for n in sorted(target_names - source_names)]
        return missing, extra

    if include_indexes:
        diff.indexes_missing_in_target, diff.indexes_extra_in_target = _compare(
            source_indexes, target_indexes
        )
    if include_constraints:
        diff.constraints_missing, diff.constraints_extra = _compare(
            source_constraints, target_constraints
        )
    if include_triggers:
        diff.triggers_missing, diff.triggers_extra = _compare(source_triggers, target_triggers)
    if include_matviews:
        diff.matviews_missing, diff.matviews_extra = _compare(source_matviews, target_matviews)
    if include_sequences:
        diff.sequences_missing, diff.sequences_extra = _compare(source_sequences, target_sequences)

    return diff


async def _get_migration_status(conn: asyncpg.Connection) -> tuple[set[str], list[Path]]:
    """Get applied migrations and all migration files."""
    # Ensure migrations table exists
    await conn.execute(f"""
        CREATE TABLE IF NOT EXISTS {MIGRATIONS_TABLE} (
            id SERIAL PRIMARY KEY,
            filename TEXT UNIQUE NOT NULL,
            applied_at TIMESTAMPTZ DEFAULT NOW()
        )
    """)

    applied = await conn.fetch(f"SELECT filename FROM {MIGRATIONS_TABLE}")
    applied_set = {row["filename"] for row in applied}

    migration_files = sorted(MIGRATIONS_DIR.glob("*.sql")) if MIGRATIONS_DIR.exists() else []

    return applied_set, migration_files


async def _discover_factories(
    conn: asyncpg.Connection,
    count: int = 3,
    min_clips: int = 100,
    max_clips: int = 10000,
    require_embeddings: bool = False,
) -> list[FactoryCandidate]:
    """Find good factory candidates for data sync."""
    query = """
        WITH factory_stats AS (
            SELECT
                f.id,
                f.name,
                COUNT(DISTINCT c.id) as clip_count,
                COUNT(DISTINCT fr.id) as frame_count,
                COUNT(DISTINCT w.id) as worker_count,
                EXISTS(
                    SELECT 1 FROM observations.emb_siglip2_ego100k_frame_default e
                    JOIN core.frames fr2 ON e.entity_id = fr2.id
                    JOIN core.clips c2 ON fr2.clip_id = c2.id
                    WHERE c2.factory_id = f.id
                    LIMIT 1
                ) as has_embeddings
            FROM core.factories f
            LEFT JOIN core.clips c ON c.factory_id = f.id AND c.deleted_at IS NULL
            LEFT JOIN core.frames fr ON fr.clip_id = c.id
            LEFT JOIN core.workers w ON w.factory_id = f.id
            GROUP BY f.id, f.name
        )
        SELECT * FROM factory_stats
        WHERE clip_count >= $1 AND clip_count <= $2
    """

    params = [min_clips, max_clips]

    if require_embeddings:
        query += " AND has_embeddings = true"

    query += " ORDER BY clip_count DESC LIMIT $" + str(len(params) + 1)
    params.append(count)

    rows = await conn.fetch(query, *params)

    return [
        FactoryCandidate(
            uuid=str(row["id"]),
            name=row["name"],
            clip_count=row["clip_count"],
            frame_count=row["frame_count"],
            has_embeddings=row["has_embeddings"],
            worker_count=row["worker_count"],
        )
        for row in rows
    ]


def _build_factory_copy_plan(
    factory_id: str,
    include_embeddings: bool = False,
) -> list[tuple[str, str | None, list[Any]]]:
    """
    Build a list of (table, where_clause, params) tuples for factory-filtered copy.

    Uses parameterized queries for safety.
    """
    plan: list[tuple[str, str | None, list[Any]]] = []

    # Reference data (always copy all)
    plan.append(("observations.embedding_spaces", None, []))

    # Factory-specific core tables
    plan.append(("core.factories", "id = $1", [factory_id]))
    plan.append(("core.workers", "factory_id = $1", [factory_id]))
    plan.append(("core.sessions", "factory_id = $1", [factory_id]))
    plan.append(("core.streams", "factory_id = $1", [factory_id]))
    plan.append(("core.clips", "factory_id = $1", [factory_id]))

    # Clip-dependent tables
    clip_subquery = "clip_id IN (SELECT id FROM core.clips WHERE factory_id = $1)"
    plan.append(("core.frames", clip_subquery, [factory_id]))

    # Frame embeddings (if requested)
    if include_embeddings:
        frame_subquery = f"entity_id IN (SELECT id FROM core.frames WHERE {clip_subquery})"
        plan.append(
            ("observations.emb_siglip2_ego100k_frame_default", frame_subquery, [factory_id])
        )

    return plan


async def _safe_copy_table_data(
    source_conn: asyncpg.Connection,
    target_conn: asyncpg.Connection,
    table: str,
    where_clause: str | None = None,
    params: list[Any] | None = None,
    limit: int | None = None,
    factory_id: str | None = None,
) -> int:
    """
    Safely copy data from source to target table.

    Uses:
    - Parameterized queries (no SQL injection)
    - Targeted DELETE instead of TRUNCATE CASCADE
    - Transaction wrapping done at caller level

    Returns:
        Number of rows copied
    """
    schema_name, table_name = table.split(".")
    params = params or []

    # Step 1: Targeted DELETE of existing data for this factory
    # Instead of TRUNCATE CASCADE which deletes unrelated data
    if factory_id and table in (
        "core.factories",
        "core.workers",
        "core.sessions",
        "core.streams",
        "core.clips",
    ):
        delete_where = where_clause
        await target_conn.execute(f"DELETE FROM {table} WHERE {delete_where}", *params)
    elif factory_id and table == "core.frames":
        # Delete frames belonging to clips from this factory
        await target_conn.execute(
            f"DELETE FROM {table} WHERE clip_id IN (SELECT id FROM core.clips WHERE factory_id = $1)",
            factory_id,
        )
    elif factory_id and table == "observations.emb_siglip2_ego100k_frame_default":
        # Delete embeddings for frames of clips from this factory
        await target_conn.execute(
            f"""DELETE FROM {table}
                WHERE entity_id IN (
                    SELECT id FROM core.frames WHERE clip_id IN (
                        SELECT id FROM core.clips WHERE factory_id = $1
                    )
                )""",
            factory_id,
        )
    elif table == "observations.embedding_spaces":
        # Reference data - don't delete, just upsert
        pass

    # Step 2: Build and execute SELECT query
    query = f"SELECT * FROM {table}"
    if where_clause:
        query += f" WHERE {where_clause}"
    if limit:
        query += f" LIMIT {limit}"

    rows = await source_conn.fetch(query, *params)
    if not rows:
        return 0

    # Step 3: Insert into target using COPY protocol
    columns = list(rows[0].keys())
    records = [tuple(row[col] for col in columns) for row in rows]

    # For embedding_spaces, use ON CONFLICT to handle duplicates
    if table == "observations.embedding_spaces":
        for record in records:
            placeholders = ", ".join(f"${i + 1}" for i in range(len(columns)))
            cols_str = ", ".join(columns)
            # Insert or skip on conflict
            await target_conn.execute(
                f"INSERT INTO {table} ({cols_str}) VALUES ({placeholders}) ON CONFLICT DO NOTHING",
                *record,
            )
        return len(records)

    await target_conn.copy_records_to_table(
        table_name,
        schema_name=schema_name,
        records=records,
        columns=columns,
    )

    return len(rows)


# =============================================================================
# Typer App
# =============================================================================

app = typer.Typer(
    name="database",
    help="Unified database management commands",
    no_args_is_help=True,
)


# =============================================================================
# Commands
# =============================================================================


@app.command()
def status(ctx: typer.Context) -> None:
    """
    Show overall database health summary.

    Displays:
    - Schema parity (indexes, constraints, triggers)
    - Migration status
    - Data volumes (factories, clips, frames, embeddings)
    - Overall health assessment
    """
    settings: Settings = ctx.obj["settings"]

    async def run() -> None:
        status_obj = DatabaseStatus(
            environment=settings.app_env.value,
            database_name=settings.db_name,
        )

        try:
            async with get_connection(settings) as conn:
                status_obj.connected = True

                # Get migration status
                applied_set, migration_files = await _get_migration_status(conn)
                status_obj.migrations_applied = len(applied_set)
                status_obj.migrations_total = len(migration_files)
                status_obj.migrations_pending = len(migration_files) - len(applied_set)

                # Get data volumes
                status_obj.factories_count = await _get_table_row_count(conn, "core.factories")
                status_obj.clips_count = await _get_table_row_count(
                    conn, "core.clips", "deleted_at IS NULL"
                )
                status_obj.frames_count = await _get_table_row_count(conn, "core.frames")
                status_obj.embeddings_count = await _get_table_row_count(
                    conn, "observations.emb_siglip2_ego100k_frame_default"
                )

        except Exception as e:
            error(f"Connection failed: {e}")

        # Display status
        console.print()
        console.print(
            Panel(
                f"[bold]Environment:[/bold] {status_obj.environment} ({status_obj.database_name})",
                title="Database Status",
            )
        )
        console.print()

        # Migrations table
        table = Table(title="Migrations")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", justify="right")
        table.add_row("Applied", str(status_obj.migrations_applied))
        table.add_row("Total", str(status_obj.migrations_total))
        table.add_row(
            "Pending",
            f"[red]{status_obj.migrations_pending}[/red]"
            if status_obj.migrations_pending > 0
            else "[green]0[/green]",
        )
        console.print(table)
        console.print()

        # Data table
        table = Table(title="Data Volumes")
        table.add_column("Entity", style="cyan")
        table.add_column("Count", justify="right")
        table.add_row("Factories", f"{status_obj.factories_count:,}")
        table.add_row("Clips", f"{status_obj.clips_count:,}")
        table.add_row("Frames", f"{status_obj.frames_count:,}")
        table.add_row("Embeddings", f"{status_obj.embeddings_count:,}")
        console.print(table)
        console.print()

        # Health assessment
        health = status_obj.health_status
        if health == "READY FOR TESTING":
            success(f"Health: {health}")
        else:
            warning(f"Health: {health}")

    asyncio.run(run())


@app.command()
def diff(
    ctx: typer.Context,
    source: Annotated[str, typer.Option("--source", "-s", help="Source environment")] = "prod",
    target: Annotated[str, typer.Option("--target", "-t", help="Target environment")] = "dev",
    schema_only: Annotated[
        bool, typer.Option("--schema-only", help="Only show schema differences")
    ] = False,
    data_only: Annotated[
        bool, typer.Option("--data-only", help="Only show data volume differences")
    ] = False,
    output_format: Annotated[
        str, typer.Option("--format", "-f", help="Output format: table, json, markdown")
    ] = "table",
) -> None:
    """
    Compare environments (schema, indexes, data volumes).

    Shows differences between source and target databases including:
    - Missing indexes, constraints, triggers, matviews
    - Migration discrepancies
    - Data volume comparison
    """

    async def run() -> None:
        info(f"Comparing {source} -> {target}...")
        console.print()

        results: dict[str, Any] = {"source": source, "target": target}

        if not data_only:
            # Schema diff
            schema_diff = await _compute_diff(source, target)
            results["schema"] = schema_diff.to_dict()

            if output_format == "table":
                if schema_diff.is_empty():
                    success("Schema: No differences")
                else:
                    summary = schema_diff.summary()
                    table = Table(title="Schema Differences")
                    table.add_column("Object Type", style="cyan")
                    table.add_column(f"Missing in {target}", justify="right", style="red")
                    table.add_column(f"Extra in {target}", justify="right", style="yellow")

                    if summary["indexes_missing"] or summary["indexes_extra"]:
                        table.add_row(
                            "Indexes",
                            str(summary["indexes_missing"]),
                            str(summary["indexes_extra"]),
                        )
                    if summary["constraints_missing"] or summary["constraints_extra"]:
                        table.add_row(
                            "Constraints",
                            str(summary["constraints_missing"]),
                            str(summary["constraints_extra"]),
                        )
                    if summary["triggers_missing"] or summary["triggers_extra"]:
                        table.add_row(
                            "Triggers",
                            str(summary["triggers_missing"]),
                            str(summary["triggers_extra"]),
                        )
                    if summary["matviews_missing"] or summary["matviews_extra"]:
                        table.add_row(
                            "Materialized Views",
                            str(summary["matviews_missing"]),
                            str(summary["matviews_extra"]),
                        )

                    console.print(table)

            # Migration diff
            source_settings = switch_environment(source)
            target_settings = switch_environment(target)

            async with get_connection(source_settings) as source_conn:
                source_applied, _ = await _get_migration_status(source_conn)

            async with get_connection(target_settings) as target_conn:
                target_applied, migration_files = await _get_migration_status(target_conn)

            missing_in_target = source_applied - target_applied
            extra_in_target = target_applied - source_applied

            results["migrations"] = {
                "source_applied": len(source_applied),
                "target_applied": len(target_applied),
                "missing_in_target": list(sorted(missing_in_target)),
                "extra_in_target": list(sorted(extra_in_target)),
            }

            if output_format == "table":
                console.print()
                if missing_in_target:
                    warning(f"Migrations in {source} but not in {target}: {len(missing_in_target)}")
                    for m in sorted(missing_in_target)[:5]:
                        console.print(f"  - {m}")
                    if len(missing_in_target) > 5:
                        dim(f"  ... and {len(missing_in_target) - 5} more")
                else:
                    success("Migrations: In sync")

        if not schema_only:
            console.print()
            # Data volume comparison
            source_settings = switch_environment(source)
            target_settings = switch_environment(target)

            data_comparison = {}

            async with get_connection(source_settings) as source_conn:
                data_comparison["source"] = {
                    "clips": await _get_table_row_count(
                        source_conn, "core.clips", "deleted_at IS NULL"
                    ),
                    "frames": await _get_table_row_count(source_conn, "core.frames"),
                    "embeddings": await _get_table_row_count(
                        source_conn, "observations.emb_siglip2_ego100k_frame_default"
                    ),
                }

            async with get_connection(target_settings) as target_conn:
                data_comparison["target"] = {
                    "clips": await _get_table_row_count(
                        target_conn, "core.clips", "deleted_at IS NULL"
                    ),
                    "frames": await _get_table_row_count(target_conn, "core.frames"),
                    "embeddings": await _get_table_row_count(
                        target_conn, "observations.emb_siglip2_ego100k_frame_default"
                    ),
                }

            results["data"] = data_comparison

            if output_format == "table":
                table = Table(title="Data Volumes")
                table.add_column("Entity", style="cyan")
                table.add_column(source, justify="right")
                table.add_column(target, justify="right")
                table.add_column("Ratio", justify="right", style="dim")

                for entity in ["clips", "frames", "embeddings"]:
                    s_val = data_comparison["source"][entity]
                    t_val = data_comparison["target"][entity]
                    ratio = f"{t_val / s_val * 100:.2f}%" if s_val > 0 else "N/A"
                    table.add_row(
                        entity.capitalize(),
                        f"{s_val:,}",
                        f"{t_val:,}",
                        ratio,
                    )

                console.print(table)

        if output_format == "json":
            console.print(json.dumps(results, indent=2, default=str))

    asyncio.run(run())


@app.command("sync-schema")
def sync_schema(
    ctx: typer.Context,
    source: Annotated[str, typer.Option("--source", "-s", help="Source environment")] = "prod",
    target: Annotated[str, typer.Option("--target", "-t", help="Target environment")] = "dev",
    indexes: Annotated[bool, typer.Option("--indexes", help="Apply missing indexes")] = False,
    constraints: Annotated[
        bool, typer.Option("--constraints", help="Apply missing constraints")
    ] = False,
    triggers: Annotated[bool, typer.Option("--triggers", help="Apply missing triggers")] = False,
    all_objects: Annotated[bool, typer.Option("--all", help="Apply all missing objects")] = False,
    concurrent: Annotated[
        bool, typer.Option("--concurrent", help="Use CONCURRENTLY for indexes")
    ] = False,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", "-n", help="Show DDL without executing")
    ] = False,
    yes: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation prompt")] = False,
) -> None:
    """
    Apply missing schema objects from source to target.

    Examples:
        cli database sync-schema --all          # Apply everything
        cli database sync-schema --indexes      # Just indexes
        cli database sync-schema --dry-run      # Preview DDL
    """

    if not dry_run:
        require_write(ctx, "Database schema sync")

    async def run() -> None:
        _validate_sync_direction(source, target, "schema")

        if not any([indexes, constraints, triggers, all_objects]):
            error("Specify object type: --indexes, --constraints, --triggers, or --all")
            raise typer.Exit(1)

        info(f"Computing diff: {source} -> {target}...")
        schema_diff = await _compute_diff(
            source,
            target,
            include_indexes=indexes or all_objects,
            include_constraints=constraints or all_objects,
            include_triggers=triggers or all_objects,
            include_matviews=all_objects,
            include_sequences=all_objects,
        )

        objects_to_apply: list[Any] = []
        ddl_statements: list[str] = []

        if indexes or all_objects:
            for idx in schema_diff.indexes_missing_in_target:
                objects_to_apply.append(idx)
                if concurrent:
                    ddl_statements.append(generate_index_ddl_concurrent(idx))
                else:
                    ddl_statements.append(generate_index_ddl(idx))

        if constraints or all_objects:
            for c in schema_diff.constraints_missing:
                objects_to_apply.append(c)
                ddl_statements.append(generate_add_constraint_ddl(c))

        if triggers or all_objects:
            for t in schema_diff.triggers_missing:
                objects_to_apply.append(t)
                ddl_statements.append(generate_trigger_ddl(t))

        if all_objects:
            for mv in schema_diff.matviews_missing:
                objects_to_apply.append(mv)
                ddl_statements.append(generate_matview_ddl(mv))

            for seq in schema_diff.sequences_missing:
                objects_to_apply.append(seq)
                ddl_statements.append(generate_sequence_ddl(seq))

        if not objects_to_apply:
            success(f"No objects to apply. {target} is in sync with {source}.")
            return

        console.print()
        info(f"Found {len(objects_to_apply)} object(s) to apply")

        if dry_run:
            info("DDL statements (dry run):")
            for stmt in ddl_statements:
                console.print(Syntax(stmt, "sql", theme="monokai"))
                console.print()
            return

        if not yes:
            target_is_prod = target.lower() in ("prod", "production")
            if target_is_prod:
                warning("You are about to modify PRODUCTION!")
            if not typer.confirm(f"Apply {len(objects_to_apply)} object(s) to {target}?"):
                info("Cancelled.")
                return

        info(f"Applying {len(objects_to_apply)} object(s) to {target}...")
        target_settings = switch_environment(target)

        succeeded = 0
        failed = 0

        async with get_connection(target_settings) as conn:
            for obj, stmt in zip(objects_to_apply, ddl_statements):
                obj_name = getattr(obj, "full_name", str(obj))
                try:
                    await conn.execute(stmt)
                    success(f"  Applied: {obj_name}")
                    succeeded += 1
                except Exception as e:
                    error(f"  Failed {obj_name}: {e}")
                    failed += 1

        console.print()
        if failed == 0:
            success(f"All {succeeded} object(s) applied successfully.")
        else:
            warning(f"Completed: {succeeded} succeeded, {failed} failed.")

    asyncio.run(run())


@app.command("sync-data")
def sync_data(
    ctx: typer.Context,
    factory: Annotated[
        str | None, typer.Option("--factory", "-f", help="Factory UUID to copy")
    ] = None,
    discover: Annotated[
        bool, typer.Option("--discover", help="Auto-discover and prompt for factory selection")
    ] = False,
    limit: Annotated[int | None, typer.Option("--limit", "-l", help="Max rows per table")] = None,
    include_embeddings: Annotated[
        bool, typer.Option("--include-embeddings", help="Include embedding tables (large!)")
    ] = False,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", "-n", help="Show plan without executing")
    ] = False,
    yes: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation prompt")] = False,
) -> None:
    """
    Copy factory data safely from prod to dev.

    Safety features:
    - Transaction wrapping (all succeed or all rollback)
    - Targeted DELETE instead of TRUNCATE CASCADE
    - Parameterized queries (no SQL injection)
    - Production writes BLOCKED

    Examples:
        cli database sync-data --factory abc123
        cli database sync-data --discover       # Interactive selection
        cli database sync-data --factory abc123 --include-embeddings
    """

    if not dry_run:
        require_write(ctx, "Database data sync")

    async def run() -> None:
        _validate_sync_direction("prod", "dev", "data", allow_prod_write=False)

        selected_factory = factory

        # Discover mode
        if discover or not factory:
            info("Discovering factory candidates...")
            prod_settings = switch_environment("prod")
            async with get_connection(prod_settings) as conn:
                candidates = await _discover_factories(conn, count=5)

            if not candidates:
                error("No suitable factories found.")
                raise typer.Exit(1)

            table = Table(title="Factory Candidates")
            table.add_column("#", style="cyan", justify="right")
            table.add_column("UUID", style="white")
            table.add_column("Name", style="dim")
            table.add_column("Clips", justify="right")
            table.add_column("Frames", justify="right")
            table.add_column("Embeddings", justify="center")

            for i, c in enumerate(candidates, 1):
                table.add_row(
                    str(i),
                    c.uuid[:8] + "...",
                    c.name or "-",
                    f"{c.clip_count:,}",
                    f"{c.frame_count:,}",
                    "[green]Yes[/green]" if c.has_embeddings else "[dim]No[/dim]",
                )

            console.print(table)
            console.print()

            if not factory:
                choice = typer.prompt("Select factory (1-5)", type=int, default=1)
                if choice < 1 or choice > len(candidates):
                    error("Invalid selection")
                    raise typer.Exit(1)
                selected_factory = candidates[choice - 1].uuid
                info(f"Selected: {selected_factory}")

        if not selected_factory:
            error("No factory specified. Use --factory <uuid> or --discover")
            raise typer.Exit(1)

        # Build copy plan
        table_filters = _build_factory_copy_plan(selected_factory, include_embeddings)
        table_list = [t for t, _, _ in table_filters]

        plan = CopyPlan(
            source_env="prod",
            target_env="dev",
            tables=table_list,
            factory_id=selected_factory,
            limit=limit,
            include_embeddings=include_embeddings,
        )

        # Get source row counts
        info("Analyzing source data...")
        prod_settings = switch_environment("prod")
        async with get_connection(prod_settings) as source_conn:
            for table_name, where_clause, params in table_filters:
                try:
                    if where_clause:
                        query = f"SELECT COUNT(*) FROM {table_name} WHERE {where_clause}"
                        count = await source_conn.fetchval(query, *params)
                    else:
                        count = await _get_table_row_count(source_conn, table_name)
                    plan.row_counts[table_name] = count or 0
                except Exception as e:
                    warning(f"Could not count {table_name}: {e}")
                    plan.row_counts[table_name] = 0

        # Show plan
        console.print()
        table = Table(title="Data Copy Plan: prod -> dev")
        table.add_column("Table", style="cyan")
        table.add_column("Source Rows", justify="right")

        for tbl in plan.tables:
            table.add_row(tbl, f"{plan.row_counts.get(tbl, 0):,}")

        console.print(table)
        console.print()
        dim(f"Factory: {selected_factory}")
        if limit:
            dim(f"Row limit: {limit} per table")

        if dry_run:
            info("Dry run complete. No data was copied.")
            return

        total_rows = sum(plan.row_counts.values())
        if not yes:
            if not typer.confirm(f"Copy ~{total_rows:,} rows to dev?", default=False):
                info("Cancelled.")
                return

        # Execute copy with transaction
        info("Copying data from prod to dev...")
        dev_settings = switch_environment("dev")
        prod_settings = switch_environment("prod")

        copied_total = 0
        errors_count = 0

        async with get_connection(prod_settings) as source_conn:
            async with get_connection(dev_settings) as target_conn:
                # Wrap in transaction for atomicity
                async with target_conn.transaction():
                    with Progress(
                        SpinnerColumn(),
                        TextColumn("[progress.description]{task.description}"),
                        console=console,
                    ) as progress:
                        for table_name, where_clause, params in table_filters:
                            task = progress.add_task(f"Copying {table_name}...", total=None)

                            try:
                                copied = await _safe_copy_table_data(
                                    source_conn=source_conn,
                                    target_conn=target_conn,
                                    table=table_name,
                                    where_clause=where_clause,
                                    params=params,
                                    limit=limit,
                                    factory_id=selected_factory,
                                )
                                copied_total += copied
                                progress.update(
                                    task,
                                    description=f"[green]Copied {table_name}: {copied:,} rows[/green]",
                                )
                            except Exception as e:
                                progress.update(
                                    task,
                                    description=f"[red]Failed {table_name}: {e}[/red]",
                                )
                                errors_count += 1
                                # Re-raise to rollback transaction
                                raise

                            progress.remove_task(task)

        console.print()
        if errors_count == 0:
            success(f"Copied {copied_total:,} rows across {len(table_list)} tables.")

            # Post-copy validation
            info("Validating copied data...")
            async with get_connection(dev_settings) as conn:
                dev_clips = await conn.fetchval(
                    "SELECT COUNT(*) FROM core.clips WHERE factory_id = $1",
                    selected_factory,
                )
                dev_frames = await conn.fetchval(
                    """SELECT COUNT(*) FROM core.frames f
                       JOIN core.clips c ON f.clip_id = c.id
                       WHERE c.factory_id = $1""",
                    selected_factory,
                )
                success(f"  Verified: {dev_clips} clips, {dev_frames} frames in dev")
        else:
            error(f"Copy failed with {errors_count} error(s). Transaction rolled back.")
            raise typer.Exit(1)

    asyncio.run(run())


@app.command()
def migrate(
    ctx: typer.Context,
    target: Annotated[str | None, typer.Argument(help="Migration file or 'all'")] = None,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Show without executing")] = False,
    timeout: Annotated[int, typer.Option("--timeout", help="Statement timeout in seconds")] = 3600,
) -> None:
    """
    Run database migrations.

    Examples:
        cli database migrate                  # Show pending migrations
        cli database migrate all              # Run all pending
        cli database migrate 001_create.sql   # Run specific migration
    """
    if target is not None and not dry_run:
        require_write(ctx, "Database migrations")
    settings: Settings = ctx.obj["settings"]

    async def run() -> None:
        if not MIGRATIONS_DIR.exists():
            error(f"Migrations directory not found: {MIGRATIONS_DIR}")
            raise typer.Exit(1)

        async with get_connection(settings) as conn:
            await conn.execute(
                "SELECT set_config('buildai.app_env', $1, false)",
                settings.app_env.value,
            )
            applied_set, migration_files = await _get_migration_status(conn)
            pending = [f for f in migration_files if f.name not in applied_set]

            if target is None:
                # Show status
                env_name = "prod" if settings.is_production else "dev"
                console.print(f"\n[bold]Migration Status[/bold] ({env_name})\n")
                console.print(
                    f"Total: {len(migration_files)}, Applied: {len(applied_set)}, "
                    f"Pending: {len(pending)}\n"
                )

                if pending:
                    console.print("[yellow]Pending migrations:[/yellow]")
                    for f in pending[:10]:
                        console.print(f"  - {f.name}")
                    if len(pending) > 10:
                        dim(f"  ... and {len(pending) - 10} more")
                else:
                    success("All migrations applied")
                return

            # Determine which to run
            if target == "all":
                to_run = pending
            else:
                matches = [f for f in migration_files if target in f.name]
                if not matches:
                    error(f"Migration not found: {target}")
                    raise typer.Exit(1)
                to_run = matches

            if not to_run:
                success("No migrations to run")
                return

            if dry_run:
                console.print("[yellow]Dry run - would apply:[/yellow]")
                for f in to_run:
                    console.print(f"  - {f.name}")
                return

            if settings.is_production:
                warning(f"About to run {len(to_run)} migration(s) in PRODUCTION")
                if not typer.confirm("Continue?"):
                    raise typer.Abort()

            # Run migrations
            for mig_file in to_run:
                info(f"Running {mig_file.name}...")

                try:
                    sql = mig_file.read_text()

                    if timeout == 0:
                        await conn.execute("SET statement_timeout = '0'")
                    else:
                        await conn.execute(f"SET statement_timeout = '{timeout}s'")

                    await conn.execute(sql, timeout=None)
                    await conn.execute(
                        f"INSERT INTO {MIGRATIONS_TABLE} (filename) VALUES ($1) ON CONFLICT DO NOTHING",
                        mig_file.name,
                    )
                    success(f"  Applied {mig_file.name}")

                except Exception as e:
                    error(f"Migration failed: {mig_file.name}")
                    error(str(e))
                    raise typer.Exit(1)

            success(f"Applied {len(to_run)} migration(s)")

    asyncio.run(run())


@app.command()
def backfill(
    ctx: typer.Context,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", "-n", help="Show without executing")
    ] = False,
) -> None:
    """
    Apply migrations from prod that are missing in dev.

    This fixes the "migrations in prod but not dev" situation by
    downloading and applying migration SQL from production.
    """

    if not dry_run:
        require_write(ctx, "Database migration backfill")

    async def run() -> None:
        info("Checking migration parity...")

        prod_settings = switch_environment("prod")
        dev_settings = switch_environment("dev")

        async with get_connection(prod_settings) as prod_conn:
            prod_applied, _ = await _get_migration_status(prod_conn)

        async with get_connection(dev_settings) as dev_conn:
            dev_applied, migration_files = await _get_migration_status(dev_conn)

        missing_in_dev = prod_applied - dev_applied

        if not missing_in_dev:
            success("Dev has all migrations from prod")
            return

        # Find the actual migration files
        migrations_to_apply = []
        for f in migration_files:
            if f.name in missing_in_dev:
                migrations_to_apply.append(f)

        # Check for migrations that are in prod but not in our files
        in_prod_not_in_files = missing_in_dev - {f.name for f in migration_files}
        if in_prod_not_in_files:
            warning(f"Migrations in prod but not in repo: {in_prod_not_in_files}")
            warning("These may have been applied directly to prod. Manual intervention needed.")

        if not migrations_to_apply:
            warning("No migration files found to apply")
            return

        console.print()
        info(f"Found {len(migrations_to_apply)} migration(s) to backfill:")
        for f in migrations_to_apply:
            console.print(f"  - {f.name}")

        if dry_run:
            info("Dry run complete.")
            return

        if not typer.confirm("Apply these migrations to dev?"):
            info("Cancelled.")
            return

        async with get_connection(dev_settings) as conn:
            for mig_file in sorted(migrations_to_apply, key=lambda f: f.name):
                info(f"Applying {mig_file.name}...")
                try:
                    sql = mig_file.read_text()
                    await conn.execute(sql)
                    await conn.execute(
                        f"INSERT INTO {MIGRATIONS_TABLE} (filename) VALUES ($1) ON CONFLICT DO NOTHING",
                        mig_file.name,
                    )
                    success(f"  Applied {mig_file.name}")
                except Exception as e:
                    error(f"Failed: {e}")
                    raise typer.Exit(1)

        success(f"Backfilled {len(migrations_to_apply)} migration(s)")

    asyncio.run(run())


@app.command()
def verify(
    ctx: typer.Context,
    fix: Annotated[bool, typer.Option("--fix", help="Attempt to fix issues")] = False,
) -> None:
    """
    Validate database state.

    Checks:
    - Migration parity (dev vs prod)
    - Schema object parity (indexes, constraints)
    - Referential integrity (no orphaned records)
    - Role assignments
    - Data completeness
    """
    settings: Settings = ctx.obj["settings"]
    issues: list[str] = []

    async def run() -> None:
        nonlocal issues

        info(f"Verifying database state ({settings.app_env.value})...")
        console.print()

        async with get_connection(settings) as conn:
            # Check 1: Migrations
            info("Checking migrations...")
            applied_set, migration_files = await _get_migration_status(conn)
            pending = len(migration_files) - len(applied_set)

            if pending == 0:
                success(f"  Migrations: {len(applied_set)} applied, 0 pending")
            else:
                error(f"  Migrations: {pending} pending")
                issues.append(f"{pending} pending migrations")

            # Check 2: Required roles
            info("Checking roles...")
            required_roles = ["buildai_owner", "buildai_admin", "buildai_readonly"]
            existing = await conn.fetch(
                "SELECT rolname FROM pg_roles WHERE rolname = ANY($1)", required_roles
            )
            existing_names = {r["rolname"] for r in existing}

            for role in required_roles:
                if role in existing_names:
                    success(f"  Role exists: {role}")
                else:
                    error(f"  Missing role: {role}")
                    issues.append(f"Missing role: {role}")

            # Check 3: Data presence
            info("Checking data...")
            factories = await _get_table_row_count(conn, "core.factories")
            clips = await _get_table_row_count(conn, "core.clips", "deleted_at IS NULL")

            if factories > 0:
                success(f"  Factories: {factories}")
            else:
                warning("  Factories: 0 (no data)")
                issues.append("No factories in database")

            if clips > 0:
                success(f"  Clips: {clips:,}")
            else:
                warning("  Clips: 0 (no data)")
                issues.append("No clips in database")

            # Check 4: Orphaned records
            info("Checking referential integrity...")
            orphaned_frames = await conn.fetchval("""
                SELECT COUNT(*) FROM core.frames f
                LEFT JOIN core.clips c ON f.clip_id = c.id
                WHERE c.id IS NULL
            """)
            if orphaned_frames == 0:
                success("  No orphaned frames")
            else:
                error(f"  Orphaned frames: {orphaned_frames}")
                issues.append(f"{orphaned_frames} orphaned frames")

        console.print()

        # Summary
        if issues:
            error(f"Found {len(issues)} issue(s):")
            for issue in issues:
                console.print(f"  - {issue}")

            if fix:
                warning("Auto-fix not implemented for all issues.")
                console.print("Manual steps:")
                console.print("  - Migrations: cli database migrate all")
                console.print("  - Roles: cli database roles")
                console.print("  - Data: cli database sync-data --discover")
        else:
            success("All checks passed!")

    asyncio.run(run())


@app.command()
def discover(
    ctx: typer.Context,
    count: Annotated[int, typer.Option("--count", "-c", help="Number of factories")] = 3,
    min_clips: Annotated[int, typer.Option("--min-clips", help="Minimum clip count")] = 100,
    max_clips: Annotated[int, typer.Option("--max-clips", help="Maximum clip count")] = 10000,
    require_embeddings: Annotated[
        bool, typer.Option("--require-embeddings", help="Only factories with embeddings")
    ] = False,
) -> None:
    """
    Find good factory candidates for data sync.

    Selection criteria:
    - Clip count in reasonable range
    - Complete hierarchy (workers, sessions, clips, frames)
    - Has embeddings (optional)
    """
    settings: Settings = ctx.obj["settings"]

    async def run() -> None:
        info(f"Discovering factories in {settings.app_env.value}...")

        async with get_connection(settings) as conn:
            candidates = await _discover_factories(
                conn,
                count=count,
                min_clips=min_clips,
                max_clips=max_clips,
                require_embeddings=require_embeddings,
            )

        if not candidates:
            warning("No suitable factories found with the given criteria.")
            return

        table = Table(title="Factory Candidates")
        table.add_column("UUID", style="cyan")
        table.add_column("Name")
        table.add_column("Clips", justify="right")
        table.add_column("Frames", justify="right")
        table.add_column("Workers", justify="right")
        table.add_column("Embeddings", justify="center")

        for c in candidates:
            table.add_row(
                c.uuid,
                c.name or "-",
                f"{c.clip_count:,}",
                f"{c.frame_count:,}",
                str(c.worker_count),
                "[green]Yes[/green]" if c.has_embeddings else "[dim]No[/dim]",
            )

        console.print(table)
        console.print()
        dim("Use: cli database sync-data --factory <uuid>")

    asyncio.run(run())


@app.command()
def roles(ctx: typer.Context) -> None:
    """Show database roles and their members."""
    settings: Settings = ctx.obj["settings"]

    async def run() -> None:
        async with get_connection(settings) as conn:
            roles_query = """
                SELECT
                    r.rolname AS role,
                    r.rolsuper AS is_superuser,
                    r.rolcreaterole AS can_create_role,
                    r.rolcreatedb AS can_create_db,
                    ARRAY_AGG(DISTINCT m.rolname) FILTER (WHERE m.rolname IS NOT NULL) AS member_of
                FROM pg_roles r
                LEFT JOIN pg_auth_members am ON r.oid = am.member
                LEFT JOIN pg_roles m ON am.roleid = m.oid
                WHERE r.rolname NOT LIKE 'pg_%'
                  AND r.rolname NOT IN ('rds_iam', 'rds_superuser', 'rdsadmin', 'cloudsqlsuperuser')
                GROUP BY r.rolname, r.rolsuper, r.rolcreaterole, r.rolcreatedb
                ORDER BY r.rolname
            """
            roles_data = await conn.fetch(roles_query)

            table = Table(title="Database Roles")
            table.add_column("Role", style="cyan")
            table.add_column("Super", justify="center")
            table.add_column("Create Role", justify="center")
            table.add_column("Create DB", justify="center")
            table.add_column("Member Of", style="dim")

            for role in roles_data:
                member_of = ", ".join(role["member_of"]) if role["member_of"] else "-"
                table.add_row(
                    role["role"],
                    "[green]Yes[/green]" if role["is_superuser"] else "-",
                    "[green]Yes[/green]" if role["can_create_role"] else "-",
                    "[green]Yes[/green]" if role["can_create_db"] else "-",
                    member_of,
                )

            console.print(table)

    asyncio.run(run())


@app.command("roles-setup")
def roles_setup(
    ctx: typer.Context,
    dry_run: Annotated[bool, typer.Option("--dry-run", help="Show SQL without executing")] = False,
    as_admin: Annotated[
        bool,
        typer.Option(
            "--as-admin",
            help="Connect as postgres user via password auth (requires ALLOYDB_PSW_PROD)",
        ),
    ] = False,
    yes: Annotated[
        bool, typer.Option("--yes", "-y", help="Skip confirmation for production")
    ] = False,
) -> None:
    """
    Apply least-privilege role and grant setup.

    Uses scripts/ops/create-db-roles-leastpriv.sql.
    """
    settings: Settings = ctx.obj["settings"]

    if not dry_run:
        require_write(ctx, "Database role setup")

    sql_path = REPO_ROOT / "scripts" / "ops" / "create-db-roles-leastpriv.sql"

    if not sql_path.exists():
        error(f"SQL file not found: {sql_path}")
        raise typer.Exit(1)

    sql_content = sql_path.read_text()

    if dry_run:
        info("SQL to execute:")
        console.print(Syntax(sql_content, "sql", theme="monokai", line_numbers=False))
        return

    if settings.is_production and not yes:
        warning("This will modify PRODUCTION database roles!")
        if not typer.confirm("Are you sure you want to continue?"):
            raise typer.Abort()

    async def run() -> None:
        db = None
        connection_context = None
        using_owner_role = False

        try:
            if as_admin:
                info("Connecting as postgres (password auth)...")
                db = await _get_admin_connection(settings)
                conn = db.conn
            else:
                connection_context = get_connection(settings)
                conn = await connection_context.__aenter__()
                using_owner_role = await _set_owner_role(conn)
                if using_owner_role:
                    dim("Using role: buildai_owner")
                else:
                    dim("Role buildai_owner not available, using default permissions")

            await conn.execute(sql_content)
            success("Role setup completed.")

        except Exception as e:
            error(f"Role setup failed: {e}")
            raise typer.Exit(1)

        finally:
            if using_owner_role:
                try:
                    await conn.execute("RESET ROLE")
                except Exception:
                    pass

            if db is not None:
                await db.close()
            elif connection_context is not None:
                await connection_context.__aexit__(None, None, None)

    asyncio.run(run())


@app.command()
def audit(
    ctx: typer.Context,
    fix: Annotated[bool, typer.Option("--fix", help="Attempt to fix issues")] = False,
) -> None:
    """
    Audit AlloyDB permissions and configuration.

    Checks:
    - GCP IAM roles
    - AlloyDB users exist
    - PostgreSQL roles granted correctly
    """
    if fix:
        require_write(ctx, "AlloyDB permission fixes")
    settings: Settings = ctx.obj["settings"]
    project_id = settings.gcp_project_id
    region = settings.gcp_region

    info("Auditing AlloyDB permissions...")
    console.print()

    cluster = "buildai-production" if settings.is_production else "buildai-development"

    # Check IAM roles
    info("Checking GCP IAM roles...")
    runtime_targets = get_runtime_targets_with_database_access()
    required_roles = ["roles/alloydb.client", "roles/alloydb.databaseUser"]

    iam_table = Table(title="IAM Role Audit")
    iam_table.add_column("Service Account", style="cyan")
    iam_table.add_column("DB Login", style="magenta")
    iam_table.add_column("alloydb.client", justify="center")
    iam_table.add_column("alloydb.databaseUser", justify="center")

    iam_issues = []

    for target in runtime_targets:
        sa_email = target.gcp_service_account_email
        db_login = target.alloydb_iam_user
        if sa_email is None or db_login is None:
            continue
        sa_name = sa_email.split("@", 1)[0]
        row = [sa_name, db_login]

        for role in required_roles:
            try:
                result = subprocess.run(
                    [
                        "gcloud",
                        "projects",
                        "get-iam-policy",
                        project_id,
                        "--flatten=bindings[].members",
                        f"--filter=bindings.role:{role} AND bindings.members:serviceAccount:{sa_email}",
                        "--format=value(bindings.role)",
                    ],
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                if result.stdout.strip():
                    row.append("[green]Yes[/green]")
                else:
                    row.append("[red]No[/red]")
                    iam_issues.append((sa_email, role))
            except Exception:
                row.append("[yellow]?[/yellow]")

        iam_table.add_row(*row)

    console.print(iam_table)
    console.print()

    if iam_issues and fix:
        info("Fixing IAM roles...")
        for sa_email, role in iam_issues:
            try:
                subprocess.run(
                    [
                        "gcloud",
                        "projects",
                        "add-iam-policy-binding",
                        project_id,
                        f"--member=serviceAccount:{sa_email}",
                        f"--role={role}",
                        "--condition=None",
                        "--quiet",
                    ],
                    capture_output=True,
                    timeout=60,
                )
                success(f"  Added {role} to {sa_email}")
            except Exception as e:
                error(f"  Failed: {e}")

    # List AlloyDB users
    info(f"AlloyDB users in cluster: {cluster}")
    try:
        result = subprocess.run(
            [
                "gcloud",
                "alloydb",
                "users",
                "list",
                f"--cluster={cluster}",
                f"--region={region}",
                f"--project={project_id}",
                "--format=value(name.basename())",
            ],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0:
            actual_users = {line.strip() for line in result.stdout.splitlines() if line.strip()}
            users_table = Table(title="AlloyDB IAM User Audit")
            users_table.add_column("Runtime", style="cyan")
            users_table.add_column("DB Login", style="magenta")
            users_table.add_column("Present", justify="center")

            missing_users: list[str] = []
            for target in runtime_targets:
                db_login = target.alloydb_iam_user
                if db_login is None:
                    continue
                present = db_login in actual_users
                users_table.add_row(
                    target.service_slug,
                    db_login,
                    "[green]Yes[/green]" if present else "[red]No[/red]",
                )
                if not present:
                    missing_users.append(db_login)

            console.print(users_table)
            console.print()
            if "backend-services" in actual_users:
                warning("Shared runtime DB login still exists: backend-services")
            if missing_users:
                warning("Missing AlloyDB IAM users: " + ", ".join(sorted(set(missing_users))))
        else:
            error(f"Failed: {result.stderr}")
    except Exception as e:
        error(f"Failed: {e}")


@app.command()
def seed(
    ctx: typer.Context,
    target: Annotated[str, typer.Argument(help="Seed category: shared, development, all")] = "all",
    dry_run: Annotated[
        bool, typer.Option("--dry-run", "-n", help="Show without executing")
    ] = False,
) -> None:
    """
    Run seed data scripts.

    SAFETY: Development seeds are BLOCKED in production.

    Examples:
        cli database seed shared        # Shared seeds only
        cli database seed development   # Dev seeds (blocked in prod)
        cli database seed all           # All applicable seeds
    """
    if not dry_run:
        require_write(ctx, "Database seeding")
    settings: Settings = ctx.obj["settings"]

    if target not in ["shared", "development", "all"]:
        error(f"Invalid target: {target}. Use: shared, development, or all")
        raise typer.Exit(1)

    # SAFETY: Block development seeds in production
    if settings.is_production and target in ["development", "all"]:
        error("Development seeds are BLOCKED in production!")
        dim("Use 'cli database seed shared' for production reference data.")
        raise typer.Exit(1)

    # Collect seed files
    seed_files: list[tuple[str, Path]] = []

    def get_seed_files(category: str) -> list[Path]:
        seed_dir = SEEDS_DIR / category
        return sorted(seed_dir.glob("*.sql")) if seed_dir.exists() else []

    if target in ["shared", "all"]:
        for f in get_seed_files("shared"):
            seed_files.append(("shared", f))

    if target in ["development", "all"]:
        for f in get_seed_files("development"):
            seed_files.append(("development", f))

    if not seed_files:
        warning(f"No seed files found for target: {target}")
        return

    info(f"Seeds to run ({len(seed_files)} files):")
    for category, f in seed_files:
        console.print(f"  [cyan]{category}[/cyan]/{f.name}")

    if dry_run:
        dim("Dry run - no changes made")
        return

    async def run() -> None:
        async with get_connection(settings) as conn:
            for category, seed_file in seed_files:
                console.print(f"\n[cyan]Running[/cyan] {category}/{seed_file.name}...")

                sql = seed_file.read_text()

                try:
                    async with conn.transaction():
                        await conn.execute(sql)
                    success(f"  {seed_file.name}")
                except Exception as e:
                    error(f"  {seed_file.name}: {e}")
                    raise typer.Exit(1)

        console.print()
        success(f"All {len(seed_files)} seed files completed")

    asyncio.run(run())


@app.command()
def prepare(
    ctx: typer.Context,
    factory_count: Annotated[
        int, typer.Option("--factory-count", help="Number of factories to sync")
    ] = 1,
    skip_schema: Annotated[bool, typer.Option("--skip-schema", help="Skip schema sync")] = False,
    skip_data: Annotated[bool, typer.Option("--skip-data", help="Skip data sync")] = False,
    skip_migrations: Annotated[
        bool, typer.Option("--skip-migrations", help="Skip migration backfill")
    ] = False,
    dry_run: Annotated[
        bool, typer.Option("--dry-run", "-n", help="Show plan without executing")
    ] = False,
    yes: Annotated[bool, typer.Option("--yes", "-y", help="Skip confirmation prompts")] = False,
) -> None:
    """
    One-shot command to make dev DB trustworthy.

    Steps performed:
    1. Backfill any migrations from prod not in dev
    2. Apply missing schema objects (indexes, constraints, triggers)
    3. Discover good factory candidates
    4. Copy factory data safely (with transactions + validation)
    5. Verify referential integrity
    6. Report final status

    Examples:
        cli database prepare                    # Full preparation
        cli database prepare --dry-run          # Preview what would happen
        cli database prepare --skip-data        # Schema only
        cli database prepare --factory-count 3  # Sync 3 factories
    """
    if not dry_run:
        require_write(ctx, "Database preparation")
    settings: Settings = ctx.obj["settings"]

    if settings.is_production:
        error("Cannot run prepare on production!")
        raise typer.Exit(1)

    async def run() -> None:
        info("Preparing development database...")
        console.print()

        steps_planned = []
        if not skip_migrations:
            steps_planned.append("Backfill migrations")
        if not skip_schema:
            steps_planned.append("Sync schema objects")
        if not skip_data:
            steps_planned.append(f"Copy data from {factory_count} factory(ies)")
        steps_planned.append("Verify integrity")

        info(f"Plan: {', '.join(steps_planned)}")
        console.print()

        if dry_run:
            # Step 1: Check migration backfill needs
            if not skip_migrations:
                info("[DRY RUN] Would check migration parity...")
                prod_settings = switch_environment("prod")
                dev_settings = switch_environment("dev")

                async with get_connection(prod_settings) as prod_conn:
                    prod_applied, _ = await _get_migration_status(prod_conn)

                async with get_connection(dev_settings) as dev_conn:
                    dev_applied, _ = await _get_migration_status(dev_conn)

                missing = prod_applied - dev_applied
                if missing:
                    warning(f"  Would backfill {len(missing)} migration(s)")
                else:
                    success("  Migrations already in sync")

            # Step 2: Check schema sync needs
            if not skip_schema:
                info("[DRY RUN] Would check schema parity...")
                diff = await _compute_diff("prod", "dev")
                summary = diff.summary()
                total_missing = (
                    summary["indexes_missing"]
                    + summary["constraints_missing"]
                    + summary["triggers_missing"]
                )
                if total_missing > 0:
                    warning(f"  Would apply {total_missing} schema object(s)")
                else:
                    success("  Schema already in sync")

            # Step 3: Check data sync
            if not skip_data:
                info("[DRY RUN] Would discover and copy factory data...")
                prod_settings = switch_environment("prod")
                async with get_connection(prod_settings) as conn:
                    candidates = await _discover_factories(conn, count=factory_count)
                if candidates:
                    for c in candidates:
                        console.print(f"    - {c.uuid[:8]}... ({c.clip_count:,} clips)")
                else:
                    warning("  No suitable factories found")

            info("Dry run complete.")
            return

        if not yes:
            if not typer.confirm("Proceed with database preparation?"):
                info("Cancelled.")
                return

        # Step 1: Backfill migrations
        if not skip_migrations:
            info("Step 1: Backfilling migrations...")
            prod_settings = switch_environment("prod")
            dev_settings = switch_environment("dev")

            async with get_connection(prod_settings) as prod_conn:
                prod_applied, _ = await _get_migration_status(prod_conn)

            async with get_connection(dev_settings) as dev_conn:
                dev_applied, migration_files = await _get_migration_status(dev_conn)

                missing = prod_applied - dev_applied
                if missing:
                    to_apply = [f for f in migration_files if f.name in missing]
                    for mig in sorted(to_apply, key=lambda f: f.name):
                        info(f"  Applying {mig.name}...")
                        sql = mig.read_text()
                        await dev_conn.execute(sql)
                        await dev_conn.execute(
                            f"INSERT INTO {MIGRATIONS_TABLE} (filename) VALUES ($1) ON CONFLICT DO NOTHING",
                            mig.name,
                        )
                    success(f"  Backfilled {len(to_apply)} migration(s)")
                else:
                    success("  Migrations already in sync")

        # Step 2: Sync schema
        if not skip_schema:
            info("Step 2: Syncing schema objects...")
            diff = await _compute_diff("prod", "dev")

            objects_to_apply: list[Any] = []
            ddl_statements: list[str] = []

            for idx in diff.indexes_missing_in_target:
                objects_to_apply.append(idx)
                ddl_statements.append(generate_index_ddl(idx))

            for c in diff.constraints_missing:
                objects_to_apply.append(c)
                ddl_statements.append(generate_add_constraint_ddl(c))

            for t in diff.triggers_missing:
                objects_to_apply.append(t)
                ddl_statements.append(generate_trigger_ddl(t))

            if objects_to_apply:
                dev_settings = switch_environment("dev")
                async with get_connection(dev_settings) as conn:
                    for obj, stmt in zip(objects_to_apply, ddl_statements):
                        obj_name = getattr(obj, "full_name", str(obj))
                        try:
                            await conn.execute(stmt)
                            success(f"    Applied: {obj_name}")
                        except Exception as e:
                            warning(f"    Skipped {obj_name}: {e}")
                success(f"  Applied {len(objects_to_apply)} schema object(s)")
            else:
                success("  Schema already in sync")

        # Step 3: Copy data
        if not skip_data:
            info("Step 3: Copying factory data...")
            prod_settings = switch_environment("prod")
            dev_settings = switch_environment("dev")

            async with get_connection(prod_settings) as prod_conn:
                candidates = await _discover_factories(prod_conn, count=factory_count)

            if candidates:
                for candidate in candidates:
                    info(
                        f"  Copying factory {candidate.uuid[:8]}... ({candidate.clip_count:,} clips)"
                    )
                    table_filters = _build_factory_copy_plan(
                        candidate.uuid, include_embeddings=False
                    )

                    async with get_connection(prod_settings) as source_conn:
                        async with get_connection(dev_settings) as target_conn:
                            async with target_conn.transaction():
                                for table_name, where_clause, params in table_filters:
                                    try:
                                        copied = await _safe_copy_table_data(
                                            source_conn=source_conn,
                                            target_conn=target_conn,
                                            table=table_name,
                                            where_clause=where_clause,
                                            params=params,
                                            factory_id=candidate.uuid,
                                        )
                                        dim(f"    {table_name}: {copied:,} rows")
                                    except Exception as e:
                                        error(f"    Failed {table_name}: {e}")
                                        raise

                success(f"  Copied data from {len(candidates)} factory(ies)")
            else:
                warning("  No suitable factories found")

        # Step 4: Verify
        info("Step 4: Verifying integrity...")
        dev_settings = switch_environment("dev")
        async with get_connection(dev_settings) as conn:
            # Check orphaned records
            orphaned = await conn.fetchval("""
                SELECT COUNT(*) FROM core.frames f
                LEFT JOIN core.clips c ON f.clip_id = c.id
                WHERE c.id IS NULL
            """)
            if orphaned == 0:
                success("  No orphaned records")
            else:
                warning(f"  {orphaned} orphaned frame(s)")

            # Final counts
            factories = await _get_table_row_count(conn, "core.factories")
            clips = await _get_table_row_count(conn, "core.clips", "deleted_at IS NULL")
            frames = await _get_table_row_count(conn, "core.frames")

        console.print()
        success("Database preparation complete!")
        console.print(f"  Factories: {factories}")
        console.print(f"  Clips: {clips:,}")
        console.print(f"  Frames: {frames:,}")

    asyncio.run(run())
