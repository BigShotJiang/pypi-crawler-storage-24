use arrayvec::ArrayVec;

use crate::bitboard::nw_for_board;
use crate::board::{Board, STANDARD_COLS, STANDARD_ROWS};
use crate::color::Color;
use crate::outcome::GameOutcome;
use crate::pieces::{Piece, PieceType};
use crate::position::Position;
use crate::r#move::{Move, MoveFlags};

#[derive(Clone)]
struct MoveHistoryEntry {
    mv: Move,
    captured: Option<Piece>,
    castling_rights: CastlingRights,
    en_passant: Option<Position>,
    halfmove_clock: u32,
}

#[derive(Clone)]
pub struct Game<const NW: usize> {
    board: Board<NW>,
    turn: Color,
    move_history: Vec<MoveHistoryEntry>,

    castling_rights: CastlingRights,
    castling_enabled: bool,

    en_passant: Option<Position>,

    halfmove_clock: u32,
    fullmove_number: u32,

    white_king_pos: Position,
    black_king_pos: Position,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash)]
pub struct CastlingRights {
    white_kingside: bool,
    white_queenside: bool,
    black_kingside: bool,
    black_queenside: bool,
}

#[hotpath::measure_all]
impl Default for CastlingRights {
    fn default() -> Self {
        Self::new()
    }
}

#[hotpath::measure_all]
impl CastlingRights {
    pub fn new() -> Self {
        CastlingRights {
            white_kingside: true,
            white_queenside: true,
            black_kingside: true,
            black_queenside: true,
        }
    }

    pub fn none() -> Self {
        CastlingRights {
            white_kingside: false,
            white_queenside: false,
            black_kingside: false,
            black_queenside: false,
        }
    }

    pub fn has_kingside(&self, color: Color) -> bool {
        match color {
            Color::White => self.white_kingside,
            Color::Black => self.black_kingside,
        }
    }

    pub fn has_queenside(&self, color: Color) -> bool {
        match color {
            Color::White => self.white_queenside,
            Color::Black => self.black_queenside,
        }
    }
}

#[hotpath::measure_all]
impl<const NW: usize> Game<NW> {
    pub fn new(
        width: usize,
        height: usize,
        fen: &str,
        castling_enabled: bool,
    ) -> Result<Self, String> {
        let parts: ArrayVec<&str, 6> = fen.split(' ').collect();

        if parts.is_empty() {
            return Err("Empty FEN string".to_string());
        }

        // FEN must have exactly 6 parts: position, turn, castling, en_passant, halfmove, fullmove
        if parts.len() != 6 {
            return Err(format!(
                "Invalid FEN: expected 6 parts, got {}",
                parts.len()
            ));
        }

        let board = Board::new(width, height, parts[0])?;

        // Turn
        let turn = match parts[1] {
            "w" => Color::White,
            "b" => Color::Black,
            _ => return Err("Invalid turn in FEN".to_string()),
        };

        // Castling rights
        let mut castling_rights = CastlingRights::none();
        if castling_enabled {
            for c in parts[2].chars() {
                match c {
                    'K' => castling_rights.white_kingside = true,
                    'Q' => castling_rights.white_queenside = true,
                    'k' => castling_rights.black_kingside = true,
                    'q' => castling_rights.black_queenside = true,
                    '-' => {}
                    _ => return Err("Invalid castling rights in FEN".to_string()),
                }
            }
        }

        // En passant
        let en_passant = if parts[3] != "-" {
            Some(Position::from_algebraic(parts[3])?)
        } else {
            None
        };

        // Halfmove clock
        let halfmove_clock = parts[4]
            .parse()
            .map_err(|_| "Invalid halfmove clock in FEN".to_string())?;

        // Fullmove number
        let fullmove_number = parts[5]
            .parse()
            .map_err(|_| "Invalid fullmove number in FEN".to_string())?;

        // Find king positions
        let white_king_pos = board
            .find_king(Color::White)
            .ok_or("No white king found in FEN position".to_string())?;
        let black_king_pos = board
            .find_king(Color::Black)
            .ok_or("No black king found in FEN position".to_string())?;

        Ok(Game {
            board,
            turn,
            move_history: Vec::new(),
            castling_rights,
            castling_enabled,
            en_passant,
            halfmove_clock,
            fullmove_number,
            white_king_pos,
            black_king_pos,
        })
    }

    pub fn width(&self) -> usize {
        self.board.width()
    }

    pub fn height(&self) -> usize {
        self.board.height()
    }

    pub fn get_piece(&self, pos: &Position) -> Option<Piece> {
        self.board.get_piece(pos)
    }

    pub fn set_piece(&mut self, pos: &Position, piece: Option<Piece>) {
        self.board.set_piece(pos, piece)
    }

    pub fn board(&self) -> &Board<NW> {
        &self.board
    }

    pub fn board_mut(&mut self) -> &mut Board<NW> {
        &mut self.board
    }

    pub fn turn(&self) -> Color {
        self.turn
    }

    pub fn fullmove_number(&self) -> u32 {
        self.fullmove_number
    }

    pub fn halfmove_clock(&self) -> u32 {
        self.halfmove_clock
    }

    pub fn move_count(&self) -> usize {
        self.move_history.len()
    }

    pub fn move_history(&self) -> Vec<Move> {
        self.move_history.iter().map(|e| e.mv).collect()
    }

    pub fn castling_enabled(&self) -> bool {
        self.castling_enabled
    }

    pub fn castling_rights(&self) -> &CastlingRights {
        &self.castling_rights
    }

    pub fn board_clear(&mut self) {
        self.board.clear();
    }

    /// Returns: whether the move was successfully made
    pub fn make_move(&mut self, mv: &Move) -> bool {
        // Validate the move is from a piece of the correct color
        let piece = match self.board.get_piece(&mv.src) {
            Some(p) if p.color == self.turn => p,
            _ => return false,
        };

        // Check if the move is legal
        if !self.is_legal_move(mv) {
            return false;
        }

        self.apply_move(mv, &piece);
        true
    }

    /// Apply a move that is already known to be legal. Skips legality checking.
    /// Caller must guarantee the move came from `legal_moves()` or equivalent.
    pub fn make_move_unchecked(&mut self, mv: &Move) {
        let piece = self
            .board
            .get_piece(&mv.src)
            .expect("no piece at move source");
        self.apply_move(mv, &piece);
    }

    fn apply_move(&mut self, mv: &Move, piece: &Piece) {
        // Store state for unmake
        let captured = self.board.get_piece(&mv.dst);
        let old_castling = self.castling_rights;
        let old_en_passant = self.en_passant;
        let old_halfmove = self.halfmove_clock;

        // Make the move on the board
        self.board.remove_piece(&mv.src, piece);
        if let Some(ref cap) = captured {
            self.board.remove_piece(&mv.dst, cap);
        }

        // Handle promotion
        let placed_piece = if mv.flags.contains(MoveFlags::PROMOTION) {
            Piece::new(mv.promotion.unwrap_or(PieceType::Queen), piece.color)
        } else {
            *piece
        };
        self.board.place_piece(&mv.dst, &placed_piece);

        // Update king position if a king moved
        if piece.piece_type == PieceType::King {
            match piece.color {
                Color::White => self.white_king_pos = mv.dst,
                Color::Black => self.black_king_pos = mv.dst,
            }
        }

        // Handle en passant capture
        if mv.flags.contains(MoveFlags::EN_PASSANT) {
            let captured_pawn_pos = Position::new(mv.dst.col, mv.src.row);
            let ep_piece = Piece::new(PieceType::Pawn, piece.color.opposite());
            self.board.remove_piece(&captured_pawn_pos, &ep_piece);
        }

        // Handle castling
        if mv.flags.contains(MoveFlags::CASTLE) {
            let rook = Piece::new(PieceType::Rook, piece.color);
            let (rook_from, rook_to) = if mv.dst.col > mv.src.col {
                // Kingside
                (
                    Position::new(self.board.width() - 1, mv.src.row),
                    Position::new(mv.dst.col - 1, mv.dst.row),
                )
            } else {
                // Queenside
                (
                    Position::new(0, mv.src.row),
                    Position::new(mv.dst.col + 1, mv.dst.row),
                )
            };

            self.board.remove_piece(&rook_from, &rook);
            self.board.place_piece(&rook_to, &rook);
        }

        // Update castling rights
        self.update_castling_rights(mv, piece);

        // Update en passant square
        self.en_passant = None;
        if piece.piece_type == PieceType::Pawn && (mv.dst.row as i32 - mv.src.row as i32).abs() == 2
        {
            // Set en passant square immediately after double pawn push
            let ep_row = (mv.src.row + mv.dst.row) / 2;
            self.en_passant = Some(Position::new(mv.src.col, ep_row));
        }

        // Update clocks
        if piece.piece_type == PieceType::Pawn || captured.is_some() {
            self.halfmove_clock = 0;
        } else {
            self.halfmove_clock += 1;
        }

        if self.turn == Color::Black {
            self.fullmove_number += 1;
        }

        // Store move in history
        self.move_history.push(MoveHistoryEntry {
            mv: *mv,
            captured,
            castling_rights: old_castling,
            en_passant: old_en_passant,
            halfmove_clock: old_halfmove,
        });

        // Switch turns (always, even if the game is over)
        self.turn = self.turn.opposite();
    }

    pub fn unmake_move(&mut self) -> bool {
        if let Some(entry) = self.move_history.pop() {
            let mv = entry.mv;
            let captured = entry.captured;
            let old_castling = entry.castling_rights;
            let old_en_passant = entry.en_passant;
            let old_halfmove = entry.halfmove_clock;

            // Switch turn back
            self.turn = self.turn.opposite();

            // Remove the piece from its destination
            let dst_piece = self
                .board
                .get_piece(&mv.dst)
                .expect("no piece at move dst during unmake");
            self.board.remove_piece(&mv.dst, &dst_piece);

            // Restore original piece to source
            let original_piece = if mv.flags.contains(MoveFlags::PROMOTION) {
                Piece::new(PieceType::Pawn, self.turn)
            } else {
                dst_piece
            };
            self.board.place_piece(&mv.src, &original_piece);

            // Restore king position if a king moved
            if original_piece.piece_type == PieceType::King {
                match original_piece.color {
                    Color::White => self.white_king_pos = mv.src,
                    Color::Black => self.black_king_pos = mv.src,
                }
            }

            // Restore captured piece
            if let Some(cap) = captured {
                self.board.place_piece(&mv.dst, &cap);
            }

            // Handle en passant
            if mv.flags.contains(MoveFlags::EN_PASSANT) {
                let captured_pawn_pos = Position::new(mv.dst.col, mv.src.row);
                let ep_piece = Piece::new(PieceType::Pawn, self.turn.opposite());
                self.board.place_piece(&captured_pawn_pos, &ep_piece);
            }

            // Handle castling
            if mv.flags.contains(MoveFlags::CASTLE) {
                let rook = Piece::new(PieceType::Rook, self.turn);
                let (rook_from, rook_to) = if mv.dst.col > mv.src.col {
                    // Kingside
                    (
                        Position::new(self.board.width() - 1, mv.src.row),
                        Position::new(mv.dst.col - 1, mv.dst.row),
                    )
                } else {
                    // Queenside
                    (
                        Position::new(0, mv.src.row),
                        Position::new(mv.dst.col + 1, mv.dst.row),
                    )
                };

                self.board.remove_piece(&rook_to, &rook);
                self.board.place_piece(&rook_from, &rook);
            }

            // Restore state
            self.castling_rights = old_castling;
            self.en_passant = old_en_passant;
            self.halfmove_clock = old_halfmove;

            if self.turn == Color::Black {
                self.fullmove_number -= 1;
            }

            true
        } else {
            false
        }
    }

    fn update_castling_rights(&mut self, mv: &Move, piece: &Piece) {
        // King moves
        if piece.piece_type == PieceType::King {
            match piece.color {
                Color::White => {
                    self.castling_rights.white_kingside = false;
                    self.castling_rights.white_queenside = false;
                }
                Color::Black => {
                    self.castling_rights.black_kingside = false;
                    self.castling_rights.black_queenside = false;
                }
            }
        }

        // Rook moves or captures
        let size = self.board.width();
        if piece.piece_type == PieceType::Rook {
            if mv.src.row == 0 && mv.src.col == 0 {
                self.castling_rights.white_queenside = false;
            } else if mv.src.row == 0 && mv.src.col == size - 1 {
                self.castling_rights.white_kingside = false;
            } else if mv.src.row == size - 1 && mv.src.col == 0 {
                self.castling_rights.black_queenside = false;
            } else if mv.src.row == size - 1 && mv.src.col == size - 1 {
                self.castling_rights.black_kingside = false;
            }
        }

        // Rook captures
        if mv.dst.row == 0 && mv.dst.col == 0 {
            self.castling_rights.white_queenside = false;
        } else if mv.dst.row == 0 && mv.dst.col == size - 1 {
            self.castling_rights.white_kingside = false;
        } else if mv.dst.row == size - 1 && mv.dst.col == 0 {
            self.castling_rights.black_queenside = false;
        } else if mv.dst.row == size - 1 && mv.dst.col == size - 1 {
            self.castling_rights.black_kingside = false;
        }
    }

    pub fn is_legal_move(&mut self, mv: &Move) -> bool {
        // Basic validation
        if let Some(piece) = self.board.get_piece(&mv.src) {
            if piece.color != self.turn {
                return false;
            }

            // Check if move is in legal moves list
            let legal = self.legal_moves_for_position(&mv.src);
            legal.iter().any(|m| m.src == mv.src && m.dst == mv.dst)
        } else {
            false
        }
    }

    /// Test whether a pseudo-legal move is actually legal (doesn't leave own king in check).
    /// Temporarily makes the move on the board, checks, then unmakes.
    fn is_pseudo_legal_move_legal(&mut self, mv: &Move, piece: &Piece) -> bool {
        let width = self.board.width();
        let opponent = piece.color.opposite();

        let captured =
            if mv.flags.contains(MoveFlags::CAPTURE) && !mv.flags.contains(MoveFlags::EN_PASSANT) {
                let dst_idx = mv.dst.to_index(width);
                let pt = self.board.piece_type_at(dst_idx).unwrap();
                Some(Piece::new(pt, opponent))
            } else {
                None
            };

        // Make the move on the board
        self.board.remove_piece(&mv.src, piece);
        if let Some(ref cap) = captured {
            self.board.remove_piece(&mv.dst, cap);
        }
        let placed_piece = if mv.flags.contains(MoveFlags::PROMOTION) {
            Piece::new(mv.promotion.unwrap_or(PieceType::Queen), piece.color)
        } else {
            *piece
        };
        self.board.place_piece(&mv.dst, &placed_piece);

        // Update king position if a king moved
        let old_king_pos = if piece.piece_type == PieceType::King {
            let old = match piece.color {
                Color::White => self.white_king_pos,
                Color::Black => self.black_king_pos,
            };
            match piece.color {
                Color::White => self.white_king_pos = mv.dst,
                Color::Black => self.black_king_pos = mv.dst,
            }
            Some(old)
        } else {
            None
        };

        // Handle en passant capture
        let ep_captured = if mv.flags.contains(MoveFlags::EN_PASSANT) {
            let ep_pos = Position::new(mv.dst.col, mv.src.row);
            let ep_piece = Piece::new(PieceType::Pawn, opponent);
            self.board.remove_piece(&ep_pos, &ep_piece);
            Some((ep_pos, ep_piece))
        } else {
            None
        };

        let in_check = self.is_in_check(piece.color);

        // Unmake: restore board state
        if let Some((ep_pos, ep_piece)) = ep_captured {
            self.board.place_piece(&ep_pos, &ep_piece);
        }
        if let Some(old) = old_king_pos {
            match piece.color {
                Color::White => self.white_king_pos = old,
                Color::Black => self.black_king_pos = old,
            }
        }
        self.board.remove_piece(&mv.dst, &placed_piece);
        if let Some(ref cap) = captured {
            self.board.place_piece(&mv.dst, cap);
        }
        self.board.place_piece(&mv.src, piece);

        !in_check
    }

    pub fn legal_moves(&mut self) -> Vec<Move> {
        let mut moves = Vec::new();
        let mut pseudo_legal = Vec::new();

        let color = self.turn;
        let width = self.board.width();
        for idx in self.board.color_bb(color).iter_ones() {
            let pt = self.board.piece_type_at(idx).unwrap();
            let pos = Position::from_index(idx, width);
            let piece = Piece::new(pt, color);

            pseudo_legal.clear();
            self.generate_pseudo_legal_moves_for_piece_into(&pos, &piece, &mut pseudo_legal);

            for mv in pseudo_legal.iter() {
                if self.is_pseudo_legal_move_legal(mv, &piece) {
                    moves.push(*mv);
                }
            }
        }

        moves
    }

    pub fn psuedo_legal_moves(&self) -> Vec<Move> {
        let mut moves = Vec::new();

        for (pos, piece) in self.board.pieces_iter(self.turn) {
            self.generate_pseudo_legal_moves_for_piece_into(&pos, &piece, &mut moves);
        }

        moves
    }

    pub fn legal_moves_for_position(&mut self, src: &Position) -> Vec<Move> {
        let mut moves = Vec::new();

        if let Some(piece) = self.board.get_piece(src) {
            if piece.color != self.turn {
                return moves;
            }

            let mut pseudo_legal = Vec::new();
            self.generate_pseudo_legal_moves_for_piece_into(src, &piece, &mut pseudo_legal);

            for mv in pseudo_legal {
                if self.is_pseudo_legal_move_legal(&mv, &piece) {
                    moves.push(mv);
                }
            }
        }

        moves
    }

    fn generate_pseudo_legal_moves_for_piece_into(
        &self,
        src: &Position,
        piece: &Piece,
        moves: &mut Vec<Move>,
    ) {
        match piece.piece_type {
            PieceType::Pawn => self.generate_psuedo_legal_pawn_moves_into(src, piece, moves),
            PieceType::Knight => self.generate_psuedo_legal_knight_moves_into(src, piece, moves),
            PieceType::Bishop => self.generate_psuedo_legal_bishop_moves_into(src, piece, moves),
            PieceType::Rook => self.generate_psuedo_legal_rook_moves_into(src, piece, moves),
            PieceType::Queen => self.generate_psuedo_legal_queen_moves_into(src, piece, moves),
            PieceType::King => self.generate_psuedo_legal_king_moves_into(src, piece, moves),
        }
    }

    fn generate_psuedo_legal_pawn_moves_into(
        &self,
        src: &Position,
        piece: &Piece,
        moves: &mut Vec<Move>,
    ) {
        let occupied = self.board.occupied();
        let own_color = self.board.color_bb(piece.color);
        let width = self.board.width();
        let height = self.board.height();

        let direction: i32 = if piece.color == Color::White { 1 } else { -1 };

        let start_row = if piece.color == Color::White {
            1
        } else {
            height - 2
        };

        let promo_row = if piece.color == Color::White {
            height - 2
        } else {
            1
        };

        // Single push
        let dst_row = (src.row as i32 + direction) as usize;

        if dst_row < height {
            let idx = dst_row * width + src.col;

            if !occupied.get(idx) {
                let dst_position = Position::new(src.col, dst_row);

                if src.row == promo_row {
                    for piece_type in &[
                        PieceType::Queen,
                        PieceType::Rook,
                        PieceType::Bishop,
                        PieceType::Knight,
                    ] {
                        moves.push(Move::from_position_with_promotion(
                            *src,
                            dst_position,
                            MoveFlags::PROMOTION,
                            *piece_type,
                        ));
                    }
                } else {
                    moves.push(Move::from_position(*src, dst_position, MoveFlags::empty()));
                }
            }
        }

        // Double push from starting position
        if src.row == start_row {
            let to_row = (src.row as i32 + 2 * direction) as usize;
            let between_row = (src.row as i32 + direction) as usize;
            let to_idx = to_row * width + src.col;
            let between_idx = between_row * width + src.col;

            if !occupied.get(to_idx) && !occupied.get(between_idx) {
                moves.push(Move::from_position(
                    *src,
                    Position::new(src.col, to_row),
                    MoveFlags::DOUBLE_PUSH,
                ));
            }
        }

        // Captures
        for col_offset in &[-1i32, 1i32] {
            let dst_col = (src.col as i32 + col_offset) as usize;
            let dst_row = (src.row as i32 + direction) as usize;

            if dst_col < width && dst_row < height {
                let idx = dst_row * width + dst_col;

                // Regular capture: occupied by enemy
                if occupied.get(idx) && !own_color.get(idx) {
                    let dst_position = Position::new(dst_col, dst_row);

                    if src.row == promo_row {
                        for piece_type in &[
                            PieceType::Queen,
                            PieceType::Rook,
                            PieceType::Bishop,
                            PieceType::Knight,
                        ] {
                            moves.push(Move::from_position_with_promotion(
                                *src,
                                dst_position,
                                MoveFlags::CAPTURE | MoveFlags::PROMOTION,
                                *piece_type,
                            ));
                        }
                    } else {
                        moves.push(Move::from_position(
                            *src,
                            Position::new(dst_col, dst_row),
                            MoveFlags::CAPTURE,
                        ));
                    }
                }

                // En passant
                if let Some(ep) = self.en_passant {
                    let dst_position = Position::new(dst_col, dst_row);

                    if ep == dst_position {
                        moves.push(Move::from_position(
                            *src,
                            dst_position,
                            MoveFlags::CAPTURE | MoveFlags::EN_PASSANT,
                        ));
                    }
                }
            }
        }
    }

    fn generate_psuedo_legal_knight_moves_into(
        &self,
        src: &Position,
        piece: &Piece,
        moves: &mut Vec<Move>,
    ) {
        let own_color = self.board.color_bb(piece.color);
        let occupied = self.board.occupied();
        let width = self.board.width();
        let height = self.board.height();

        let offsets = [
            (-2, -1),
            (-2, 1),
            (-1, -2),
            (-1, 2),
            (1, -2),
            (1, 2),
            (2, -1),
            (2, 1),
        ];

        for (col_offset, row_offset) in &offsets {
            let dst_col = (src.col as i32 + col_offset) as usize;
            let dst_row = (src.row as i32 + row_offset) as usize;

            if dst_col < width && dst_row < height {
                let idx = dst_row * width + dst_col;

                if own_color.get(idx) {
                    continue;
                }

                let to = Position::new(dst_col, dst_row);

                if occupied.get(idx) {
                    moves.push(Move::from_position(*src, to, MoveFlags::CAPTURE));
                } else {
                    moves.push(Move::from_position(*src, to, MoveFlags::empty()));
                }
            }
        }
    }

    fn generate_sliding_moves_into(
        &self,
        src: &Position,
        piece: &Piece,
        directions: &[(i32, i32)],
        moves: &mut Vec<Move>,
    ) {
        let occupied = self.board.occupied();
        let own_color = self.board.color_bb(piece.color);
        let width = self.board.width();
        let height = self.board.height();

        for (col_dir, row_dir) in directions {
            let mut distance = 1;

            loop {
                let dst_col = (src.col as i32 + col_dir * distance) as usize;
                let dst_row = (src.row as i32 + row_dir * distance) as usize;

                if dst_col >= width || dst_row >= height {
                    break;
                }

                let idx = dst_row * width + dst_col;

                if occupied.get(idx) {
                    if !own_color.get(idx) {
                        let dst_position = Position::new(dst_col, dst_row);
                        moves.push(Move::from_position(*src, dst_position, MoveFlags::CAPTURE));
                    }

                    break;
                } else {
                    let dst_position = Position::new(dst_col, dst_row);
                    moves.push(Move::from_position(*src, dst_position, MoveFlags::empty()));
                }

                distance += 1;
            }
        }
    }

    fn generate_psuedo_legal_bishop_moves_into(
        &self,
        src: &Position,
        piece: &Piece,
        moves: &mut Vec<Move>,
    ) {
        let directions = [(1, 1), (1, -1), (-1, 1), (-1, -1)];
        self.generate_sliding_moves_into(src, piece, &directions, moves)
    }

    fn generate_psuedo_legal_rook_moves_into(
        &self,
        src: &Position,
        piece: &Piece,
        moves: &mut Vec<Move>,
    ) {
        let directions = [(0, 1), (0, -1), (1, 0), (-1, 0)];
        self.generate_sliding_moves_into(src, piece, &directions, moves)
    }

    fn generate_psuedo_legal_queen_moves_into(
        &self,
        src: &Position,
        piece: &Piece,
        moves: &mut Vec<Move>,
    ) {
        let directions = [
            (0, 1),
            (0, -1),
            (1, 0),
            (-1, 0),
            (1, 1),
            (1, -1),
            (-1, 1),
            (-1, -1),
        ];
        self.generate_sliding_moves_into(src, piece, &directions, moves)
    }

    fn generate_psuedo_legal_king_moves_into(
        &self,
        src: &Position,
        piece: &Piece,
        moves: &mut Vec<Move>,
    ) {
        let own_color = self.board.color_bb(piece.color);
        let occupied = self.board.occupied();
        let width = self.board.width();
        let height = self.board.height();

        // Regular moves
        for col_offset in -1..=1i32 {
            for row_offset in -1..=1i32 {
                if col_offset == 0 && row_offset == 0 {
                    continue;
                }

                let dst_col = (src.col as i32 + col_offset) as usize;
                let dst_row = (src.row as i32 + row_offset) as usize;

                if dst_col < width && dst_row < height {
                    let idx = dst_row * width + dst_col;

                    if own_color.get(idx) {
                        continue;
                    }

                    let dst_position = Position::new(dst_col, dst_row);

                    if occupied.get(idx) {
                        moves.push(Move::from_position(*src, dst_position, MoveFlags::CAPTURE));
                    } else {
                        moves.push(Move::from_position(*src, dst_position, MoveFlags::empty()));
                    }
                }
            }
        }

        // Castling (only if enabled and for 8x8 boards)
        if self.castling_enabled && width == 8 && height == 8 && !self.is_in_check(piece.color) {
            let row = if piece.color == Color::White { 0 } else { 7 };

            // Kingside
            if ((piece.color == Color::White && self.castling_rights.white_kingside)
                || (piece.color == Color::Black && self.castling_rights.black_kingside))
                && !occupied.get(row * 8 + 5)
                && !occupied.get(row * 8 + 6)
            {
                // Check if squares are not attacked
                let mut can_castle = true;

                for col in 5..=6 {
                    if self.is_square_attacked(&Position::new(col, row), piece.color.opposite()) {
                        can_castle = false;
                        break;
                    }
                }

                if can_castle {
                    moves.push(Move::from_position(
                        *src,
                        Position::new(6, row),
                        MoveFlags::CASTLE,
                    ));
                }
            }

            // Queenside
            if ((piece.color == Color::White && self.castling_rights.white_queenside)
                || (piece.color == Color::Black && self.castling_rights.black_queenside))
                && !occupied.get(row * 8 + 1)
                && !occupied.get(row * 8 + 2)
                && !occupied.get(row * 8 + 3)
            {
                // Check if squares are not attacked
                let mut can_castle = true;

                for col in 2..=4 {
                    if self.is_square_attacked(&Position::new(col, row), piece.color.opposite()) {
                        can_castle = false;
                        break;
                    }
                }

                if can_castle {
                    moves.push(Move::from_position(
                        *src,
                        Position::new(2, row),
                        MoveFlags::CASTLE,
                    ));
                }
            }
        }
    }

    fn is_square_attacked(&self, square: &Position, by_color: Color) -> bool {
        let width = self.board.width();
        let height = self.board.height();
        let occupied = self.board.occupied();
        let enemy = self.board.color_bb(by_color);
        let sq_col = square.col as i32;
        let sq_row = square.row as i32;

        // 1. Pawn attacks
        let pawn_dir: i32 = if by_color == Color::White { -1 } else { 1 };
        let pawn_row = (sq_row + pawn_dir) as usize;
        if pawn_row < height {
            let pawns = self.board.piece_type_bb(PieceType::Pawn) & enemy;
            for col_offset in [-1i32, 1i32] {
                let pawn_col = (sq_col + col_offset) as usize;
                if pawn_col < width {
                    let idx = pawn_row * width + pawn_col;
                    if pawns.get(idx) {
                        return true;
                    }
                }
            }
        }

        // 2. Knight attacks
        let knights = self.board.piece_type_bb(PieceType::Knight) & enemy;
        if !knights.is_empty() {
            for (col_off, row_off) in [
                (-2, -1),
                (-2, 1),
                (-1, -2),
                (-1, 2),
                (1, -2),
                (1, 2),
                (2, -1),
                (2, 1),
            ] {
                let nc = (sq_col + col_off) as usize;
                let nr = (sq_row + row_off) as usize;
                if nc < width && nr < height {
                    let idx = nr * width + nc;
                    if knights.get(idx) {
                        return true;
                    }
                }
            }
        }

        // 3. King attacks
        let kings = self.board.piece_type_bb(PieceType::King) & enemy;
        if !kings.is_empty() {
            for col_off in -1..=1i32 {
                for row_off in -1..=1i32 {
                    if col_off == 0 && row_off == 0 {
                        continue;
                    }
                    let kc = (sq_col + col_off) as usize;
                    let kr = (sq_row + row_off) as usize;
                    if kc < width && kr < height {
                        let idx = kr * width + kc;
                        if kings.get(idx) {
                            return true;
                        }
                    }
                }
            }
        }

        // 4. Sliding attacks — rooks/queens along ranks and files
        let rooks_queens = (self.board.piece_type_bb(PieceType::Rook)
            | self.board.piece_type_bb(PieceType::Queen))
            & enemy;
        if !rooks_queens.is_empty() {
            for (col_dir, row_dir) in [(0i32, 1i32), (0, -1), (1, 0), (-1, 0)] {
                let mut d = 1;
                loop {
                    let c = (sq_col + col_dir * d) as usize;
                    let r = (sq_row + row_dir * d) as usize;
                    if c >= width || r >= height {
                        break;
                    }
                    let idx = r * width + c;
                    if rooks_queens.get(idx) {
                        return true;
                    }
                    if occupied.get(idx) {
                        break;
                    }
                    d += 1;
                }
            }
        }

        // 5. Sliding attacks — bishops/queens along diagonals
        let bishops_queens = (self.board.piece_type_bb(PieceType::Bishop)
            | self.board.piece_type_bb(PieceType::Queen))
            & enemy;
        if !bishops_queens.is_empty() {
            for (col_dir, row_dir) in [(1i32, 1i32), (1, -1), (-1, 1), (-1, -1)] {
                let mut d = 1;
                loop {
                    let c = (sq_col + col_dir * d) as usize;
                    let r = (sq_row + row_dir * d) as usize;
                    if c >= width || r >= height {
                        break;
                    }
                    let idx = r * width + c;
                    if bishops_queens.get(idx) {
                        return true;
                    }
                    if occupied.get(idx) {
                        break;
                    }
                    d += 1;
                }
            }
        }

        false
    }

    fn is_in_check(&self, color: Color) -> bool {
        let king_pos = match color {
            Color::White => self.white_king_pos,
            Color::Black => self.black_king_pos,
        };
        self.is_square_attacked(&king_pos, color.opposite())
    }

    pub fn is_check(&self) -> bool {
        self.is_in_check(self.turn)
    }

    fn has_any_legal_move(&mut self) -> bool {
        let mut pseudo_legal = Vec::new();
        let color = self.turn;
        let width = self.board.width();
        for idx in self.board.color_bb(color).iter_ones() {
            let pt = self.board.piece_type_at(idx).unwrap();
            let pos = Position::from_index(idx, width);
            let piece = Piece::new(pt, color);

            pseudo_legal.clear();
            self.generate_pseudo_legal_moves_for_piece_into(&pos, &piece, &mut pseudo_legal);

            for mv in pseudo_legal.iter() {
                if self.is_pseudo_legal_move_legal(mv, &piece) {
                    return true;
                }
            }
        }
        false
    }

    pub fn is_checkmate(&mut self) -> bool {
        self.is_check() && !self.has_any_legal_move()
    }

    pub fn is_stalemate(&mut self) -> bool {
        !self.is_check() && !self.has_any_legal_move()
    }

    pub fn is_over(&mut self) -> bool {
        self.halfmove_clock >= 150 || self.is_insufficient_material() || !self.has_any_legal_move()
    }

    pub fn en_passant_square(&self) -> Option<Position> {
        self.en_passant
    }

    pub fn has_legal_en_passant(&mut self) -> bool {
        if let Some(ep_square) = self.en_passant {
            // Check if any pawn can legally capture en passant
            // Look for pawns of the current player that can attack the en passant square
            let pawn_row = if self.turn == Color::White { 4 } else { 3 }; // 5th row (index 4) for white, 4th row (index 3) for black

            // Check squares to the left and right of the en passant square
            for col_offset in [-1i32, 1i32] {
                let pawn_col = ep_square.col as i32 + col_offset;
                if pawn_col >= 0 && pawn_col < self.board.width() as i32 {
                    let pawn_pos = Position::new(pawn_col as usize, pawn_row);
                    if let Some(piece) = self.board.get_piece(&pawn_pos) {
                        if piece.piece_type == PieceType::Pawn && piece.color == self.turn {
                            // Test in-place: apply ep capture, check, then undo
                            let captured_pawn_pos = Position::new(ep_square.col, pawn_pos.row);
                            let captured_pawn = Piece::new(PieceType::Pawn, self.turn.opposite());

                            self.board.remove_piece(&pawn_pos, &piece);
                            self.board.remove_piece(&captured_pawn_pos, &captured_pawn);
                            self.board.place_piece(&ep_square, &piece);

                            let in_check = self.is_in_check(self.turn);

                            // Restore
                            self.board.remove_piece(&ep_square, &piece);
                            self.board.place_piece(&captured_pawn_pos, &captured_pawn);
                            self.board.place_piece(&pawn_pos, &piece);

                            if !in_check {
                                return true;
                            }
                        }
                    }
                }
            }
        }
        false
    }

    /// Parse a LAN move string, with game context to set proper flags (castling, en passant, etc.)
    /// The `from_lan()` method on Move itself lacks game context.
    pub fn move_from_lan(&self, lan: &str) -> Result<Move, String> {
        let base_move = Move::from_lan(lan, self.board.width(), self.board.height())?;

        let piece = self.board.get_piece(&base_move.src);
        if piece.is_none() {
            return Err("No piece at source square".to_string());
        }
        let piece = piece.unwrap();

        let mut flags = base_move.flags;

        // Check for capture
        if self.board.get_piece(&base_move.dst).is_some() {
            flags |= MoveFlags::CAPTURE;
        }

        // Check for castling (king moving 2 squares)
        if piece.piece_type == PieceType::King {
            let col_diff = (base_move.dst.col as i32 - base_move.src.col as i32).abs();
            if col_diff == 2 {
                flags |= MoveFlags::CASTLE;
            }
        }

        // Check for en passant
        if piece.piece_type == PieceType::Pawn {
            if let Some(ep_square) = self.en_passant {
                if base_move.dst == ep_square {
                    flags |= MoveFlags::CAPTURE | MoveFlags::EN_PASSANT;
                }
            }

            // Check for double push
            let row_diff = (base_move.dst.row as i32 - base_move.src.row as i32).abs();
            if row_diff == 2 {
                flags |= MoveFlags::DOUBLE_PUSH;
            }
        }

        Ok(Move {
            src: base_move.src,
            dst: base_move.dst,
            flags,
            promotion: base_move.promotion,
        })
    }

    pub fn outcome(&mut self) -> Option<GameOutcome> {
        if self.halfmove_clock >= 150 {
            return Some(GameOutcome::FiftyMoveRule);
        }

        if self.is_insufficient_material() {
            return Some(GameOutcome::InsufficientMaterial);
        }

        if self.has_any_legal_move() {
            return None;
        }

        // No legal moves: checkmate or stalemate
        if self.is_check() {
            if self.turn == Color::White {
                Some(GameOutcome::BlackWin)
            } else {
                Some(GameOutcome::WhiteWin)
            }
        } else {
            Some(GameOutcome::Stalemate)
        }
    }

    pub fn is_insufficient_material(&self) -> bool {
        let white = self.board.color_bb(Color::White);
        let black = self.board.color_bb(Color::Black);

        let pawns = self.board.piece_type_bb(PieceType::Pawn);
        let rooks = self.board.piece_type_bb(PieceType::Rook);
        let queens = self.board.piece_type_bb(PieceType::Queen);
        let bishops = self.board.piece_type_bb(PieceType::Bishop);
        let knights = self.board.piece_type_bb(PieceType::Knight);

        // If either side has pawns, queens, or rooks, there's sufficient material
        if !(pawns | rooks | queens).is_empty() {
            return false;
        }

        // Now we only have kings, bishops, and knights
        let white_bishops = (bishops & white).count();
        let white_knights = (knights & white).count();
        let black_bishops = (bishops & black).count();
        let black_knights = (knights & black).count();

        let white_minor_pieces = white_bishops + white_knights;
        let black_minor_pieces = black_bishops + black_knights;

        // If only bishops and knights remain, check for insufficient material
        // Special case: if both sides only have bishops (no knights), and all bishops are on the same color, it's insufficient
        if white_knights == 0 && black_knights == 0 && (white_bishops > 0 || black_bishops > 0) {
            // Check if all bishops on the board are on the same color
            if self.are_all_bishops_on_same_color() {
                return true;
            }
        }

        // Check for other insufficient material cases:
        match (white_minor_pieces, black_minor_pieces) {
            // K vs K
            (0, 0) => true,
            // K vs K+B or K vs K+N
            (0, 1) => true,
            (1, 0) => true,
            // Any other combination can potentially mate
            _ => false,
        }
    }

    fn are_all_bishops_on_same_color(&self) -> bool {
        let bishops = self.board.piece_type_bb(PieceType::Bishop);
        let mut first_color: Option<usize> = None;
        let w = self.board.width();

        // Check square colors of all bishops (both white and black)
        for idx in bishops.iter_ones() {
            // A square is light if (col + row) is even
            let col = idx % w;
            let row = idx / w;
            let square_color = (col + row) % 2;
            match first_color {
                None => first_color = Some(square_color),
                Some(c) if c != square_color => return false,
                _ => {}
            }
        }

        // If there are no bishops, return false; otherwise all matched
        first_color.is_some()
    }

    pub fn to_fen(&mut self) -> String {
        let mut fen = self.board.to_fen();

        // Turn
        fen.push(' ');
        fen.push(if self.turn == Color::White { 'w' } else { 'b' });

        // Castling rights
        fen.push(' ');
        let has_any = self.castling_rights.white_kingside
            || self.castling_rights.white_queenside
            || self.castling_rights.black_kingside
            || self.castling_rights.black_queenside;

        if !has_any {
            fen.push('-');
        } else {
            if self.castling_rights.white_kingside {
                fen.push('K');
            }
            if self.castling_rights.white_queenside {
                fen.push('Q');
            }
            if self.castling_rights.black_kingside {
                fen.push('k');
            }
            if self.castling_rights.black_queenside {
                fen.push('q');
            }
        }

        // En passant (only include if there are legal en passant moves)
        fen.push(' ');
        if self.has_legal_en_passant() {
            if let Some(ep) = self.en_passant {
                fen.push_str(&ep.to_algebraic());
            } else {
                fen.push('-');
            }
        } else {
            fen.push('-');
        }

        // Halfmove clock
        fen.push(' ');
        fen.push_str(&self.halfmove_clock.to_string());

        // Fullmove number
        fen.push(' ');
        fen.push_str(&self.fullmove_number.to_string());

        fen
    }
}

/// Type alias for a standard 8x8 game
pub type StandardGame = Game<{ nw_for_board(STANDARD_COLS as u8, STANDARD_ROWS as u8) }>;

#[hotpath::measure_all]
impl StandardGame {
    pub fn standard() -> Self {
        Self::new(
            8,
            8,
            "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1",
            true,
        )
        .expect("Failed to create standard game")
    }
}

#[hotpath::measure_all]
impl<const NW: usize> std::fmt::Display for Game<NW> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "Game(current_player: {})\n{}", self.turn(), self.board)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    type StdGame = Game<{ nw_for_board(STANDARD_COLS as u8, STANDARD_ROWS as u8) }>;

    #[test]
    fn test_standard_game_creation() {
        let game = StdGame::standard();
        assert_eq!(game.board().width(), 8);
        assert_eq!(game.board().height(), 8);
        assert_eq!(game.turn(), Color::White);
        assert_eq!(game.fullmove_number(), 1);
        assert_eq!(game.halfmove_clock(), 0);
    }

    #[test]
    fn test_standard_game_initial_position() {
        let mut game = StdGame::standard();
        let fen = game.to_fen();
        assert_eq!(
            fen,
            "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"
        );
    }

    #[test]
    fn test_standard_game_king_tracking() {
        let game = StdGame::standard();

        assert_eq!(game.white_king_pos, Position::new(4, 0));
        assert_eq!(game.black_king_pos, Position::new(4, 7));
    }

    #[test]
    fn test_standard_game_rook_attack_patterns() {
        let mut game = StdGame::standard();
        game.board.clear();

        // Need kings on the board for a valid position
        game.board.set_piece(
            &Position::new(0, 0),
            Some(Piece::new(PieceType::King, Color::White)),
        );
        game.board.set_piece(
            &Position::new(7, 7),
            Some(Piece::new(PieceType::King, Color::Black)),
        );
        game.white_king_pos = Position::new(0, 0);
        game.black_king_pos = Position::new(7, 7);

        let rook = Piece::new(PieceType::Rook, Color::White);
        let rook_pos = Position::new(4, 4); // e5
        game.board.set_piece(&rook_pos, Some(rook));

        // Rook can attack along rows and cols (is_square_attacked checks if White attacks the square)
        assert!(game.is_square_attacked(&Position::new(4, 1), Color::White)); // e2
        assert!(game.is_square_attacked(&Position::new(4, 7), Color::White)); // e8
        assert!(game.is_square_attacked(&Position::new(1, 4), Color::White)); // b5
        assert!(game.is_square_attacked(&Position::new(7, 4), Color::White)); // h5

        // Cannot attack diagonally (only rook on board besides kings)
        assert!(!game.is_square_attacked(&Position::new(5, 5), Color::White)); // f6

        // Test blocked path
        let blocker = Piece::new(PieceType::Pawn, Color::Black);
        game.board.set_piece(&Position::new(4, 6), Some(blocker)); // e7

        assert!(!game.is_square_attacked(&Position::new(4, 7), Color::White)); // e8 (blocked)
        assert!(game.is_square_attacked(&Position::new(4, 6), Color::White)); // e7 (can capture)
    }

    #[test]
    fn test_standard_game_bishop_attack_patterns() {
        let mut game = StdGame::standard();
        game.board.clear();

        // Need kings on the board for a valid position
        game.board.set_piece(
            &Position::new(0, 2),
            Some(Piece::new(PieceType::King, Color::White)),
        );
        game.board.set_piece(
            &Position::new(7, 0),
            Some(Piece::new(PieceType::King, Color::Black)),
        );
        game.white_king_pos = Position::new(0, 2);
        game.black_king_pos = Position::new(7, 0);

        let bishop = Piece::new(PieceType::Bishop, Color::White);
        let bishop_pos = Position::new(4, 4); // e5
        game.board.set_piece(&bishop_pos, Some(bishop));

        // Bishop can attack diagonally
        assert!(game.is_square_attacked(&Position::new(0, 0), Color::White)); // a1
        assert!(game.is_square_attacked(&Position::new(7, 7), Color::White)); // h8
        assert!(game.is_square_attacked(&Position::new(1, 7), Color::White)); // b8
        assert!(game.is_square_attacked(&Position::new(7, 1), Color::White)); // h2

        // Cannot attack along rows/cols (only bishop+kings, kings are far away)
        assert!(!game.is_square_attacked(&Position::new(4, 1), Color::White)); // e2

        // Test blocked path
        let blocker = Piece::new(PieceType::Pawn, Color::Black);
        game.board.set_piece(&Position::new(6, 6), Some(blocker)); // g7

        assert!(!game.is_square_attacked(&Position::new(7, 7), Color::White)); // h8 (blocked)
        assert!(game.is_square_attacked(&Position::new(6, 6), Color::White)); // g7 (can capture)
    }

    #[test]
    fn test_standard_game_fen_parsing_valid_en_passant() {
        // Test with a valid en passant scenario
        let valid_ep_fen = "rnbqkbnr/ppp1pppp/8/3pP3/8/8/PPPP1PPP/RNBQKBNR w KQkq d6 0 3";
        let mut game = StdGame::new(8, 8, valid_ep_fen, true).expect("Failed to parse FEN");

        assert_eq!(game.to_fen(), valid_ep_fen);
        assert_eq!(game.turn(), Color::White);
        assert_eq!(game.fullmove_number(), 3);
        assert_eq!(game.halfmove_clock(), 0);
    }

    #[test]
    fn test_standard_game_fen_parsing_invalid_en_passant() {
        let invalid_ep_fen = "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq e3 0 1";
        let mut game = StdGame::new(8, 8, invalid_ep_fen, true).expect("Failed to parse FEN");

        // Note: en passant square e3 is ignored because there's no enemy pawn that can capture
        assert_eq!(
            game.to_fen(),
            "rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR b KQkq - 0 1"
        );
        assert_eq!(game.turn(), Color::Black);
        assert_eq!(game.fullmove_number(), 1);
        assert_eq!(game.halfmove_clock(), 0);
    }

    #[test]
    fn test_standard_game_move_making_basic() {
        let mut game = StdGame::standard();

        // Make a simple pawn move
        let e4_move =
            Move::from_position(Position::new(4, 1), Position::new(4, 3), MoveFlags::empty());
        let success = game.make_move(&e4_move);
        assert!(success, "Move should be successful");

        // Verify the move was made
        assert_eq!(game.board.get_piece(&Position::new(4, 1)), None);
        assert_eq!(
            game.board
                .get_piece(&Position::new(4, 3))
                .expect("Expected piece at position e4 after move")
                .piece_type,
            PieceType::Pawn
        );
    }

    #[test]
    fn test_custom_game_board_sizes() {
        // Create custom FENs for different board sizes
        let fen_6x6 = "rnbkqr/pppppp/6/6/PPPPPP/RNBKQR w - - 0 1";

        let mut game: Game<{ nw_for_board(6, 6) }> =
            Game::new(6, 6, fen_6x6, true).expect("Failed to create 6x6 game");
        assert_eq!(game.board().width(), 6);
        assert_eq!(game.board().height(), 6);

        assert_eq!(
            game.board()
                .get_piece(&game.white_king_pos)
                .unwrap()
                .piece_type,
            PieceType::King
        );
        assert_eq!(
            game.board()
                .get_piece(&game.black_king_pos)
                .unwrap()
                .piece_type,
            PieceType::King
        );

        // Check that tracked positions match actual king positions
        // Should be able to generate FEN
        let fen = game.to_fen();
        assert!(!fen.is_empty());
    }

    #[test]
    fn test_custom_game_piece_placement() {
        let fen_6x6 = "rnbkqr/pppppp/6/6/PPPPPP/RNBKQR w - - 0 1";
        let game: Game<{ nw_for_board(6, 6) }> =
            Game::new(6, 6, fen_6x6, true).expect("Failed to create 6x6 game");
        let white_pieces = game.board().pieces(Color::White);
        let black_pieces = game.board().pieces(Color::Black);

        // Should have pieces placed
        assert!(!white_pieces.is_empty());
        assert!(!black_pieces.is_empty());

        // Should have exactly one king each
        let white_kings: Vec<_> = white_pieces
            .iter()
            .filter(|(_, piece)| piece.piece_type == PieceType::King)
            .collect();
        let black_kings: Vec<_> = black_pieces
            .iter()
            .filter(|(_, piece)| piece.piece_type == PieceType::King)
            .collect();

        assert_eq!(white_kings.len(), 1);
        assert_eq!(black_kings.len(), 1);
    }

    #[test]
    fn test_standard_game_is_square_attacked_basic() {
        let mut game = StdGame::standard();
        game.board.clear();

        // Place a white rook at e5
        let rook = Piece::new(PieceType::Rook, Color::White);
        game.board.set_piece(&Position::new(4, 4), Some(rook)); // e5

        // The rook should attack squares along its row and col
        assert!(game.is_square_attacked(&Position::new(4, 0), Color::White)); // e1
        assert!(game.is_square_attacked(&Position::new(0, 4), Color::White)); // a5
        assert!(!game.is_square_attacked(&Position::new(5, 5), Color::White)); // f6 (diagonal)

        // Place a black king at e8
        let king = Piece::new(PieceType::King, Color::Black);
        game.board.set_piece(&Position::new(4, 7), Some(king)); // e8

        // The king should be attacked by the rook
        assert!(game.is_square_attacked(&Position::new(4, 7), Color::White));
    }

    #[test]
    fn test_standard_game_outcome_checkmate_white_wins() {
        // Scholar's mate - white wins
        // 1. e4 e5, 2. Bc4 Nc6, 3. Qh5 Nf6??, 4. Qxf7#
        let mut game = StdGame::standard();

        game.make_move(&Move::from_lan("e2e4", 8, 8).unwrap());
        game.make_move(&Move::from_lan("e7e5", 8, 8).unwrap());
        game.make_move(&Move::from_lan("f1c4", 8, 8).unwrap());
        game.make_move(&Move::from_lan("b8c6", 8, 8).unwrap());
        game.make_move(&Move::from_lan("d1h5", 8, 8).unwrap());
        game.make_move(&Move::from_lan("g8f6", 8, 8).unwrap());
        game.make_move(&Move::from_lan("h5f7", 8, 8).unwrap());

        assert!(game.is_checkmate());
        let outcome = game.outcome();
        assert_eq!(outcome, Some(GameOutcome::WhiteWin));
    }

    #[test]
    fn test_standard_game_outcome_checkmate_black_wins() {
        // Fool's mate - black wins
        let mut game = StdGame::standard();

        game.make_move(&Move::from_lan("f2f3", 8, 8).unwrap());
        game.make_move(&Move::from_lan("e7e5", 8, 8).unwrap());
        game.make_move(&Move::from_lan("g2g4", 8, 8).unwrap());
        game.make_move(&Move::from_lan("d8h4", 8, 8).unwrap());

        assert!(game.is_checkmate());
        let outcome = game.outcome();
        assert_eq!(outcome, Some(GameOutcome::BlackWin));
    }

    #[test]
    fn test_standard_game_outcome_stalemate() {
        // White king on a8, black queen on b6, black king on c7
        let fen = "K7/8/1q6/8/8/8/8/2k5 w - - 0 1";
        let mut game = StdGame::new(8, 8, fen, false).expect("Failed to parse stalemate FEN");

        assert!(
            !game.is_check(),
            "King should not be in check for stalemate"
        );
        let moves = game.legal_moves();
        assert!(
            moves.is_empty(),
            "King should have no legal moves for stalemate"
        );
        assert!(game.is_stalemate());
        let outcome = game.outcome();
        assert_eq!(outcome, Some(GameOutcome::Stalemate));
    }

    #[test]
    fn test_standard_game_outcome_insufficient_material() {
        let mut game = StdGame::standard();
        game.board.clear();

        // King vs King - insufficient material
        game.board.set_piece(
            &Position::new(4, 0),
            Some(Piece::new(PieceType::King, Color::White)),
        );
        game.board.set_piece(
            &Position::new(4, 7),
            Some(Piece::new(PieceType::King, Color::Black)),
        );

        assert!(game.is_insufficient_material());
        assert!(game.is_over());
        let outcome = game.outcome();
        assert_eq!(outcome, Some(GameOutcome::InsufficientMaterial));
    }

    #[test]
    fn test_standard_game_outcome_insufficient_material_bishop() {
        let mut game = StdGame::standard();
        game.board.clear();

        // King + Bishop vs King - insufficient material
        game.board.set_piece(
            &Position::new(4, 0),
            Some(Piece::new(PieceType::King, Color::White)),
        );
        game.board.set_piece(
            &Position::new(2, 2),
            Some(Piece::new(PieceType::Bishop, Color::White)),
        );
        game.board.set_piece(
            &Position::new(4, 7),
            Some(Piece::new(PieceType::King, Color::Black)),
        );

        assert!(game.is_insufficient_material());
        assert!(game.is_over());
        let outcome = game.outcome();
        assert_eq!(outcome, Some(GameOutcome::InsufficientMaterial));
    }

    #[test]
    fn test_standard_game_outcome_fifty_move_rule() {
        let mut game = StdGame::standard();
        game.board.clear();

        // Set up a simple position with just kings and a rook
        game.board.set_piece(
            &Position::new(4, 0),
            Some(Piece::new(PieceType::King, Color::White)),
        );
        game.board.set_piece(
            &Position::new(0, 0),
            Some(Piece::new(PieceType::Rook, Color::White)),
        );
        game.board.set_piece(
            &Position::new(4, 7),
            Some(Piece::new(PieceType::King, Color::Black)),
        );

        // Manually set halfmove clock to trigger fifty-move rule (150 half-moves = 75 full moves)
        game.halfmove_clock = 150;

        assert!(game.is_over());
        let outcome = game.outcome();
        assert_eq!(outcome, Some(GameOutcome::FiftyMoveRule));
    }

    #[test]
    fn test_standard_game_halfmove_clock_reset_on_pawn_move() {
        let mut game = StdGame::standard();

        // Make some non-pawn moves to increase halfmove clock
        game.make_move(&Move::from_lan("g1f3", 8, 8).unwrap());
        game.make_move(&Move::from_lan("g8f6", 8, 8).unwrap());
        game.make_move(&Move::from_lan("f3g1", 8, 8).unwrap());
        game.make_move(&Move::from_lan("f6g8", 8, 8).unwrap());

        assert_eq!(game.halfmove_clock, 4);

        // Make a pawn move - should reset halfmove clock
        game.make_move(&Move::from_lan("e2e4", 8, 8).unwrap());
        assert_eq!(game.halfmove_clock, 0);
    }

    #[test]
    fn test_standard_game_halfmove_clock_reset_on_capture() {
        let mut game = StdGame::standard();

        // Set up a position where a capture is possible
        game.make_move(&Move::from_lan("e2e4", 8, 8).unwrap());
        game.make_move(&Move::from_lan("d7d5", 8, 8).unwrap());

        assert_eq!(game.halfmove_clock, 0); // Both were pawn moves

        // Make some knight moves to increase halfmove clock
        game.make_move(&Move::from_lan("g1f3", 8, 8).unwrap());
        game.make_move(&Move::from_lan("b8c6", 8, 8).unwrap());
        assert_eq!(game.halfmove_clock, 2);

        // Make a capture - should reset halfmove clock
        game.make_move(&Move::from_lan("e4d5", 8, 8).unwrap()); // Capture pawn
        assert_eq!(game.halfmove_clock, 0);
    }

    #[test]
    fn test_standard_game_castling_rights_methods() {
        let mut game = StdGame::standard();

        // Initial position should have all castling rights
        assert!(game.castling_rights().has_kingside(Color::White));
        assert!(game.castling_rights().has_queenside(Color::White));
        assert!(game.castling_rights().has_kingside(Color::Black));
        assert!(game.castling_rights().has_queenside(Color::Black));

        // Move white king
        game.make_move(&Move::from_lan("e2e3", 8, 8).unwrap());
        game.make_move(&Move::from_lan("e7e6", 8, 8).unwrap());
        game.make_move(&Move::from_lan("e1e2", 8, 8).unwrap());

        // White should lose all castling rights
        assert!(!game.castling_rights().has_kingside(Color::White));
        assert!(!game.castling_rights().has_queenside(Color::White));
        // Black should still have both
        assert!(game.castling_rights().has_kingside(Color::Black));
        assert!(game.castling_rights().has_queenside(Color::Black));
    }

    #[test]
    fn test_standard_game_castling_rights_rook_move() {
        let mut game = StdGame::standard();

        // Clear path for rook movement
        game.board_clear();
        game.board.set_piece(
            &Position::new(4, 0),
            Some(Piece::new(PieceType::King, Color::White)),
        );
        game.board.set_piece(
            &Position::new(4, 7),
            Some(Piece::new(PieceType::King, Color::Black)),
        );
        game.board.set_piece(
            &Position::new(0, 0),
            Some(Piece::new(PieceType::Rook, Color::White)),
        );
        game.board.set_piece(
            &Position::new(7, 0),
            Some(Piece::new(PieceType::Rook, Color::White)),
        );

        // Move queenside rook
        game.make_move(&Move::from_lan("a1a2", 8, 8).unwrap());

        // Should lose queenside castling only
        assert!(game.castling_rights().has_kingside(Color::White));
        assert!(!game.castling_rights().has_queenside(Color::White));
    }
}
