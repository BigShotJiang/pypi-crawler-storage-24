from __future__ import annotations

import threading
import json
import os
from pathlib import Path
import platform
import sys
import time

from textual.app import App, ComposeResult
from textual.widgets import Header, Footer, Input, RichLog, OptionList, Static
from textual.containers import Vertical
from rich.panel import Panel
from rich.markdown import Markdown
from rich.rule import Rule
from rich.text import Text

from .config import (
    load_config,
    save_config,
    apply_model,
    resolve_model,
    list_all_models,
    get_model_display_name,
)
from .llm_client import LLMClient
from .mcp_manager import MCPManager, MCPServerConfig
import logging

logging.getLogger('fastmcp').setLevel(logging.WARNING)


class MomcpTUI(App):

    CSS_PATH = None

    BINDINGS = [
        ("q", "quit", "退出"),
    ]

    def __init__(self) -> None:
        super().__init__()
        self.config = load_config()
        self.llm_client = LLMClient(self.config.llm)
        self.messages: list[dict[str, str]] = []
        self.commands = [
            {"name": "/help", "desc": "显示帮助"},
            {"name": "/exit", "desc": "退出系统"},
            {"name": "/model", "desc": "显示当前模型"},
            {"name": "/model list", "desc": "列出预设的所有模型"},
            {"name": "/model set NAME", "desc": "设置模型（NAME 为具体型号，如 deepseek-chat）"},
            {"name": "/api_key", "desc": "查看 API KEY 状态"},
            {
                "name": "/api_key set KEY",
                "desc": "设置并保存 API KEY",
            },
            {"name": "/allow", "desc": "管理文件访问白名单"},
            {"name": "/allow list", "desc": "查看白名单路径"},
            {"name": "/allow add PATH", "desc": "新增白名单路径"},
            {"name": "/tool list", "desc": "列出当前支持的 MCP 工具"},
            {"name": "/web status", "desc": "查看百度搜索 MCP KEY 是否已配置"},
            {"name": "/web set KEY", "desc": "设置百度搜索 MCP API KEY"},
        ]
        self._command_items: list[str] = []
        self._waiting_for_api_key: bool = False
        self._waiting_for_username: bool = False
        self._waiting_anim_step: int = 0
        self._waiting_timer = None
        self.mcp = MCPManager()
        self._mcp_thread_started = False

    def compose(self) -> ComposeResult:
        yield Header(show_clock=True)
        with Vertical():
            self.chat_log = RichLog(highlight=True, markup=True)
            self.chat_log.write(
                Panel(
                    "欢迎使用 momcp\n"
                    "当前已接入大模型基础对话，后续会逐步加入 MCP 工具。",
                    title="系统",
                    border_style="cyan",
                )
            )
            yield self.chat_log
            self.command_list = OptionList()
            self.command_list.display = False
            yield self.command_list

            self.status = Static("")
            self.status.display = False
            yield self.status

            self.stream_preview = Static("")
            self.stream_preview.display = False
            yield self.stream_preview

            self.chat_input = Input(placeholder="在这里输入指令，按 Enter 发送……")
            yield self.chat_input
        yield Footer()

    def on_mount(self) -> None:
        self.chat_input.focus()
        if not self._mcp_thread_started:
            self._mcp_thread_started = True
            threading.Thread(target=self.mcp.start_loop_in_thread, daemon=True).start()

        for name, raw in (self.config.mcp.servers or {}).items():
            server_type = raw.get("type") or "stdio"
            env = dict(raw.get("env") or {})

            if server_type == "streamableHttp":
                url = raw.get("url")
                headers = raw.get("headers") or {}
                self.mcp.register_server(
                    MCPServerConfig(
                        name=name,
                        type="streamableHttp",
                        url=url,
                        headers=headers,
                        env=env,
                    )
                )
                continue

            cmd = raw.get("command")
            args = raw.get("args") or []
            if cmd:
                if name == "momcp":
                    cmd = sys.executable
                final_args = list(args)
                if name == "momcp" and "-m" in final_args and "momcp_tui.mcp_servers.server" in final_args:
                    root = os.getcwd()
                    if "--root" not in final_args:
                        final_args.extend(["--root", root])
                    for p in self._normalized_allowed_paths():
                        final_args.extend(["--allow", p])
                
                # 合并环境变量：优先使用配置文件中的设置
                default_env = {
                    "MCP_LOG_LEVEL": "WARNING",
                    "RUST_LOG": "warn",
                    "LOGLEVEL": "WARN",
                }
                # 将默认值与用户配置合并，用户配置优先级更高
                merged_env = {**default_env, **env}
                env = merged_env
                
                self.mcp.register_server(
                    MCPServerConfig(
                        name=name,
                        type="stdio",
                        command=cmd,
                        args=final_args,
                        env=env,
                    )
                )
        if not self.config.user_name.strip():
            self._waiting_for_username = True
            self.chat_input.placeholder = "请输入您的用户名，按 Enter 保存"
            self.chat_log.write(
                Panel(
                    "欢迎使用 momcp！\n首次使用请设置您的用户名，该名称将显示在您的消息气泡上。",
                    title="设置用户名",
                    border_style="cyan",
                )
            )

    def on_input_changed(self, event: Input.Changed) -> None:
        if event.input is not self.chat_input:
            return
        value = event.value

        if not value.startswith("/"):
            self.command_list.display = False
            self._command_items = []
            return

        prefix = value.strip()
        if hasattr(self.command_list, "clear_options"):
            self.command_list.clear_options()
        elif hasattr(self.command_list, "clear"):
            self.command_list.clear()

        matched = [
            cmd for cmd in self.commands if cmd["name"].startswith(prefix)
        ] or self.commands

        self._command_items = [cmd["name"] for cmd in matched]

        for cmd in matched:
            label = f'{cmd["name"]} — {cmd["desc"]}'
            self.command_list.add_option(label)

        self.command_list.index = 0
        self.command_list.display = True

    def on_input_submitted(self, message: Input.Submitted) -> None:
        content = message.value.strip()

        if self._waiting_for_username:
            self._waiting_for_username = False
            self.chat_input.placeholder = "在这里输入指令，按 Enter 发送……"
            self.chat_input.value = ""
            if not content:
                self.chat_log.write(
                    Panel(
                        "用户名不能为空，请重新输入。",
                        title="设置用户名",
                        border_style="yellow",
                    )
                )
                self._waiting_for_username = True
                return
            self.config.user_name = content.strip()
            save_config(self.config)
            self.chat_log.write(
                Panel(
                    f"用户名已设置为：{self.config.user_name}",
                    title="设置完成",
                    border_style="green",
                )
            )
            return

        if self._waiting_for_api_key:
            self._waiting_for_api_key = False
            self.chat_input.placeholder = "在这里输入指令，按 Enter 发送……"
            self.chat_input.value = ""
            if content.lower() == "/cancel":
                self.chat_log.write(
                    Panel(
                        "已取消 API KEY 配置。",
                        title="已取消",
                        border_style="yellow",
                    )
                )
                return
            provider = self.config.llm.provider
            self.config.llm.set_api_key(provider, content)
            save_config(self.config)
            series_name = get_model_display_name(provider)
            masked = content[:4] + "..." if len(content) > 4 else "***"
            self.chat_log.write(
                Panel(
                    f"已保存 API KEY（前缀：{masked}），已与 {series_name} 系列绑定。",
                    title="API KEY 已配置",
                    border_style="green",
                )
            )
            return

        if not content:
            return

        template_names = [c["name"] for c in self.commands]
        if content.startswith("/") and content not in template_names:
            if self.command_list.display:
                self.command_list.display = False
            self.chat_input.value = ""
            self._handle_command(content)
            return

        # 下拉框可见时，用下拉框选中的命令
        if self.command_list.display and self._command_items:
            index = getattr(self.command_list, "index", 0) or 0
            index = max(0, min(index, len(self._command_items) - 1))
            cmd = self._command_items[index]
            self.chat_input.value = ""
            self.command_list.display = False
            self._handle_command(cmd)
            return

        # 以 / 开头的视为命令，不走 LLM
        if content.startswith("/"):
            self._handle_command(content)
            self.chat_input.value = ""
            return
        # 显示用户消息为“气泡”，标题显示用户名
        user_title = self.config.user_name.strip() or "用户"
        self.chat_log.write(
            Panel(
                content,
                title=user_title,
                border_style="green",
                expand=False,
            )
        )
        self.chat_input.value = ""

        # 追加到对话历史
        self.messages.append({"role": "user", "content": content})

        self._start_waiting()
        self.chat_input.disabled = True
        threading.Thread(target=self._request_llm_reply_stream, daemon=True).start()

    def _start_waiting(self) -> None:
        self._waiting_anim_step = 0
        self.status.display = True
        self.status.update("正在等待模型回复")
        if self._waiting_timer is None:
            self._waiting_timer = self.set_interval(0.3, self._tick_waiting)

    def _stop_waiting(self) -> None:
        self.status.display = False
        self.status.update("")
        if self._waiting_timer is not None:
            self._waiting_timer.stop()
            self._waiting_timer = None

    def _tick_waiting(self) -> None:
        dots = "." * ((self._waiting_anim_step % 3) + 1)
        self._waiting_anim_step += 1
        self.status.update(f"正在等待模型回复{dots}")

    def _request_llm_reply_stream(self) -> None:
        tools: list[dict] = []
        tool_messages: list[dict] = list(self.messages)
        tool_name_map: dict[str, tuple[str, str]] = {}  # function_name -> (server, tool)
        last_user_text = ""
        for m in reversed(self.messages):
            if m.get("role") == "user":
                last_user_text = (m.get("content") or "").strip()
                break

        if self.config.mcp.servers:
            for server_name in sorted(self.config.mcp.servers.keys()):
                try:
                    for t in self.mcp.list_tools(server_name):
                        tool = t.get("name", "")
                        if not tool:
                            continue
                        fn_name = f"{server_name}__{tool}"
                        tool_name_map[fn_name] = (server_name, tool)
                        tools.append(
                            {
                                "type": "function",
                                "function": {
                                    "name": fn_name,
                                    "description": t.get("description", "") or "",
                                    "parameters": t.get("inputSchema") or {"type": "object", "properties": {}},
                                },
                            }
                        )
                except Exception:
                    continue

        if tools:
            allowed = self._normalized_allowed_paths()
            if allowed:
                allowed_hint = "\n".join(f"- {p}" for p in allowed)
            else:
                allowed_hint = "- （未设置额外白名单；仅允许访问启动 root 目录）"
            env_hint = self._runtime_env_hint()
            current_time = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
            tool_messages = [
                {
                    "role": "system",
                    "content": (
                        f"你的名字是小Mo，一个可以调用 MCP 工具的助手。关注现在时间：{current_time}\n"
                        f"当前用户是{self.config.user_name}，语气以温柔亲切为主，回复中可包含用户名字\n"
                        "\n"
                        "【重要原则】\n"
                        "1. 仅在用户明确要求创建/编辑文档、保存内容到文件时，才使用 Word 文档工具\n"
                        "2. 对于普通问题如查询信息、解释概念、聊天等，直接回答即可，不要调用任何工具\n"
                        "3. 只有当用户请求列目录/读写文件/编辑代码/联网搜索/抓取网页等操作时，才调用相应工具\n"
                        "4. 不要在用户未要求的情况下主动创建文档或保存内容\n"
                        "\n"
                        "【工具使用场景】\n"
                        f"- 气象工具：当用户需要获取天气预报、空气质量、气候信息等，需要询问用户的地区并结合当前时间{current_time}与时区信息\n"
                        "- Word 文档工具：仅当用户明确说'创建一个 Word 文档'、'保存到 docx 文件'、'生成报告文档'、'编辑文档'等\n"
                        "- 文件工具：当用户需要操作本地文件如读取、写入、删除、列目录时\n"
                        "- 代码工具：当用户需要修改代码文件时\n"
                        "- 百度搜索：当用户需要获取实时信息、新闻、最新资料时\n"
                        "\n"
                        "【禁止行为】\n"
                        "- 不要为每个回复都创建 Word 文档\n"
                        "- 不要假设用户想要保存内容到文件\n"
                        "- 不要在用户只是询问信息时调用文件工具\n"
                        "\n"
                        "注意：文件工具只允许访问启动 root 目录及白名单目录。\n"
                        "运行环境信息（用于路径/命令判断）：\n"
                        f"{env_hint}\n"
                        "关于百度 ai_search 性能：\n"
                        "- 该工具的 model 参数不为空时，会触发搜索 + 百度大模型总结，通常更慢。\n"
                        "- 默认请先做基础搜索（model 置空），再由当前对话模型根据搜索结果总结。\n"
                        "- 只有当用户明确要求用千帆/ERNIE/百度大模型总结时才设置 model。\n"
                        "当前白名单目录：\n"
                        f"{allowed_hint}\n"
                    ),
                },
                *tool_messages,
            ]

        if tools:
            try:
                final_content = ""
                final_reasoning = ""
                for _ in range(12): 
                    r = self.llm_client.chat_tools(tool_messages, tools)
                    tool_calls = r.get("tool_calls") or []
                    if tool_calls:
                        tool_messages.append({"role": "assistant", "content": None, "tool_calls": tool_calls})
                        for call in tool_calls:
                            fn = (call.get("function") or {})
                            fn_name = fn.get("name", "")
                            args_str = fn.get("arguments", "") or "{}"
                            server_tool = tool_name_map.get(fn_name)
                            if not server_tool:
                                tool_messages.append(
                                    {
                                        "role": "tool",
                                        "tool_call_id": call.get("id", ""),
                                        "content": f"未找到工具：{fn_name}",
                                    }
                                )
                                continue
                            server_name, tool_name = server_tool
                            try:
                                args = json.loads(args_str) if args_str else {}
                            except Exception as exc:  # noqa: BLE001
                                tool_messages.append(
                                    {
                                        "role": "tool",
                                        "tool_call_id": call.get("id", ""),
                                        "content": f"工具参数 JSON 解析失败：{exc}",
                                    }
                                )
                                continue
                            try:
                                args = self._rewrite_mcp_args_for_speed(server_name, tool_name, args, last_user_text)
                                out = self.mcp.call_tool(server_name, tool_name, args)
                                tool_messages.append(
                                    {
                                        "role": "tool",
                                        "tool_call_id": call.get("id", ""),
                                        "content": json.dumps(out, ensure_ascii=False),
                                    }
                                )
                            except Exception as exc:  # noqa: BLE001
                                tool_messages.append(
                                    {
                                        "role": "tool",
                                        "tool_call_id": call.get("id", ""),
                                        "content": f"工具调用失败：{exc}",
                                    }
                                )
                        continue

                    final_content = (r.get("content") or "") if isinstance(r, dict) else ""
                    final_reasoning = (r.get("reasoning") or "") if isinstance(r, dict) else ""
                    break

                buf = ""
                for ch in final_content:
                    buf += ch
                    self.call_from_thread(self._on_llm_stream_update, buf)
                    time.sleep(0.01)
                self.call_from_thread(self._on_llm_stream_done, final_content, final_reasoning)
            except Exception as exc:  # noqa: BLE001
                self.call_from_thread(self._on_llm_error, str(exc))
            return

        content = ""
        reasoning = ""
        try:
            for event in self.llm_client.chat_stream(tool_messages):
                if event.get("done"):
                    break
                content += event.get("content_delta", "")
                reasoning += event.get("reasoning_delta", "")
                self.call_from_thread(self._on_llm_stream_update, content)
        except Exception as exc:  # noqa: BLE001
            self.call_from_thread(self._on_llm_error, str(exc))
            return
        self.call_from_thread(self._on_llm_stream_done, content, reasoning)

    def _on_llm_stream_update(self, content: str) -> None:
        model_title = get_model_display_name(self.config.llm.provider)
        self.stream_preview.display = True
        self.stream_preview.update(
            Panel(
                Markdown(content or "", code_theme="monokai", inline_code_lexer="python"),
                title=f"{model_title}",
                border_style="magenta",
                expand=False,
            )
        )

    def _on_llm_error(self, error: str) -> None:
        self._stop_waiting()
        self.stream_preview.display = False
        self.stream_preview.update("")
        self.chat_input.disabled = False
        self.chat_input.focus()

        model_title = get_model_display_name(self.config.llm.provider)
        self.chat_log.write(
            Panel(
                f"调用大模型出错：{error}",
                title=model_title,
                border_style="red",
                expand=False,
            )
        )

    def _on_llm_stream_done(self, content: str, reasoning: str) -> None:
        self._stop_waiting()
        self.stream_preview.display = False
        self.stream_preview.update("")
        self.chat_input.disabled = False
        self.chat_input.focus()

        reply = content or ""
        self.messages.append({"role": "assistant", "content": reply})
        model_title = get_model_display_name(self.config.llm.provider)
        self.chat_log.write(
            Panel(
                Markdown(reply, code_theme="monokai", inline_code_lexer="python"),
                title=model_title,
                border_style="magenta",
                expand=False,
            )
        )

        if reasoning.strip():
            self.chat_log.write(Rule("思考", style="dim"))
            self.chat_log.write(
                Markdown(reasoning.strip(), code_theme="monokai", inline_code_lexer="python")
            )
            self.chat_log.write(Rule(style="dim"))

    def _handle_command(self, raw: str) -> None:
        parts = raw.lstrip("/").split()
        if not parts:
            return
        cmd, *args = parts

        if cmd in ("help", "?"):
            self.chat_log.write(
                Panel(
                    "\n".join(
                        [
                            "可用命令：",
                            "/help                显示帮助",
                            "/exit                退出系统",
                            "/model               显示当前模型",
                            "/model list          列出预设的所有模型",
                            "/model set NAME      设置模型（NAME 为具体型号，如 deepseek-chat）",
                            "/api_key             查看是否已配置 API KEY",
                            "/api_key set KEY     设置并保存 API KEY",
                            "/allow list          查看文件访问白名单",
                            "/allow add PATH      新增白名单路径",
                            "/tool list           列出 MCP 工具（需要先在配置中声明 servers）",
                            "/web status          查看百度搜索 MCP KEY 状态",
                            "/web set KEY         设置百度搜索 MCP API KEY",
                        ]
                    ),
                    title="命令帮助",
                    border_style="cyan",
                )
            )
            return

        if cmd in ("exit", "quit"):
            self.exit()
            return

        if cmd in ("web",):
            server = (self.config.mcp.servers or {}).get("aisearch-mcp-server") or {}
            headers = server.get("headers") or {}
            auth = (headers.get("Authorization") or "").strip() if isinstance(headers, dict) else ""
            if not args or args[0] == "status":
                ok = bool(auth)
                msg = "已配置。" if ok else "未配置。"
                hint = (
                    "可前往 https://console.bce.baidu.com/qianfan/ais/console/apiKey 免费获取。\n"
                    "然后使用 /web set KEY 进行设置。"
                    if not ok
                    else ""
                )
                self.chat_log.write(
                    Panel(
                        f"百度 ai_search Authorization：{msg}\n{hint}".strip(),
                        title="百度搜索 MCP",
                        border_style="cyan",
                    )
                )
                return
            if args[0] == "set" and len(args) >= 2:
                token = " ".join(args[1:]).strip()
                if not token:
                    self.chat_log.write(
                        Panel("KEY 不能为空。", title="错误", border_style="red")
                    )
                    return
                auth_val = token if token.lower().startswith("bearer ") else f"Bearer {token}"
                if not self.config.mcp.servers:
                    self.config.mcp.servers = {}
                if "aisearch-mcp-server" not in self.config.mcp.servers:
                    self.config.mcp.servers["aisearch-mcp-server"] = {
                        "type": "streamableHttp",
                        "description": "搜索实时信息，支持使用大模型进行总结回复。",
                        "url": "https://qianfan.baidubce.com/v2/ai_search/mcp",
                        "headers": {"Authorization": ""},
                    }
                s = self.config.mcp.servers["aisearch-mcp-server"]
                s_headers = dict(s.get("headers") or {})
                s_headers["Authorization"] = auth_val
                s["headers"] = s_headers
                save_config(self.config)
                try:
                    if self.mcp.is_connected("aisearch-mcp-server"):
                        self.mcp.disconnect("aisearch-mcp-server")
                except Exception:
                    pass
                masked = auth_val[:20] + "..." if len(auth_val) > 20 else auth_val
                self.chat_log.write(
                    Panel(
                        f"已写入百度 ai_search Authorization（前缀）：{masked}",
                        title="已设置",
                        border_style="green",
                    )
                )
                return

        if cmd in ("model", "m"):
            if not args:
                self.chat_log.write(
                    Panel(
                        f"当前模型：{self.config.llm.model}\n"
                        f"base_url：{self.config.llm.base_url}",
                        title="模型信息",
                        border_style="cyan",
                    )
                )
                return
            if args[0] == "list":
                lines: list[str] = []
                for label, _provider, models_str in list_all_models():
                    lines.append(f"{label}：{models_str}")
                self.chat_log.write(
                    Panel(
                        "\n".join(lines),
                        title="预设模型列表",
                        border_style="cyan",
                    )
                )
                return
            if args[0] == "set" and len(args) >= 2:
                model_name = args[1]
                if not resolve_model(model_name):
                    self.chat_log.write(
                        Panel(
                            f"未知的模型型号：{model_name}\n"
                            "请使用 /model list 查看可用型号。",
                            title="错误",
                            border_style="red",
                        )
                    )
                    return
                apply_model(self.config, model_name)
                self.llm_client.cfg.provider = self.config.llm.provider
                self.llm_client.cfg.base_url = self.config.llm.base_url
                self.llm_client.cfg.model = self.config.llm.model
                save_config(self.config)
                self.chat_log.write(
                    Panel(
                        f"已切换到：{self.config.llm.model}\n"
                        f"base_url：{self.config.llm.base_url}",
                        title="模型已更新",
                        border_style="green",
                    )
                )
                # API KEY 与系列绑定，同系列下所有型号共用
                has_key = bool(self.config.llm.get_api_key())
                if not has_key:
                    self._waiting_for_api_key = True
                    series_name = get_model_display_name(self.config.llm.provider)
                    self.chat_input.placeholder = "请在此输入 API KEY，按 Enter 保存（/cancel 取消）"
                    self.chat_log.write(
                        Panel(
                            f"当前系列（{series_name}）尚未配置 API KEY。\n"
                            f"API KEY 将与 {series_name} 系列绑定，该系列下所有型号均可使用。\n"
                            "请在下方输入框中输入您的 API KEY，按 Enter 保存。\n"
                            "输入 /cancel 可取消。",
                            title="请配置 API KEY",
                            border_style="yellow",
                        )
                    )
                return

        if cmd in ("api_key", "key"):
            if not args or args[0] == "status":
                has_key = bool(self.config.llm.get_api_key())
                series_name = get_model_display_name(self.config.llm.provider)
                msg = f"当前系列（{series_name}）：已配置 API KEY。" if has_key else f"当前系列（{series_name}）：尚未配置 API KEY。"
                self.chat_log.write(
                    Panel(
                        msg,
                        title="API KEY 状态",
                        border_style="cyan",
                    )
                )
                return
            if args[0] == "set" and len(args) >= 2:
                new_key = args[1]
                self.config.llm.set_api_key(self.config.llm.provider, new_key)
                save_config(self.config)
                masked = new_key[:4] + "..." if len(new_key) > 4 else "***"
                self.chat_log.write(
                    Panel(
                        f"已更新 API KEY（前缀：{masked}）。\n"
                        "API KEY 已写入配置文件。",
                        title="API KEY 已更新",
                        border_style="yellow",
                    )
                )
                return

        if cmd in ("allow", "whitelist"):
            if not args or args[0] == "list":
                paths = self._normalized_allowed_paths()
                if not paths:
                    body = "白名单为空。当前仅允许访问启动 root 目录。"
                else:
                    body = "\n".join(paths)
                self.chat_log.write(
                    Panel(body, title="文件访问白名单", border_style="cyan")
                )
                return
            if args[0] == "add" and len(args) >= 2:
                raw_path = " ".join(args[1:]).strip()
                if not raw_path:
                    self.chat_log.write(
                        Panel("请输入要加入白名单的路径。", title="错误", border_style="red")
                    )
                    return
                normalized = str(Path(raw_path).expanduser().resolve())
                current = self._normalized_allowed_paths()
                if normalized in current:
                    self.chat_log.write(
                        Panel(
                            f"该路径已在白名单中：\n{normalized}",
                            title="已存在",
                            border_style="yellow",
                        )
                    )
                    return
                self.config.mcp.allowed_paths.append(normalized)
                save_config(self.config)
                self.chat_log.write(
                    Panel(
                        f"已加入白名单：\n{normalized}\n\n提示：重启后对 MCP 文件工具生效。",
                        title="已添加",
                        border_style="green",
                    )
                )
                return

        if cmd in ("tool", "tools"):
            if not args or args[0] == "list":
                lines: list[str] = []
                if not self.config.mcp.servers:
                    lines.append("未配置 MCP servers。请在配置文件的 [mcp.servers.*] 下配置。")
                else:
                    for server_name in sorted(self.config.mcp.servers.keys()):
                        lines.append(f"【{server_name}】")
                        try:
                            tools = self.mcp.list_tools(server_name)
                            for t in tools:
                                tname = t.get("name", "")
                                desc = t.get("description", "")
                                lines.append(f"- {tname}  {desc}")
                        except Exception as exc:  # noqa: BLE001
                            lines.append(f"（列举工具失败）{exc}")
                self.chat_log.write(
                    Panel("\n".join(lines), title="MCP 工具列表", border_style="cyan")
                )
                return
            self.chat_log.write(
                Panel(
                    "仅支持 /tool list。\n具体工具调用请直接用自然语言对话，由大模型自动选择并调用 MCP 工具。",
                    title="提示",
                    border_style="yellow",
                )
            )
            return

    def _normalized_allowed_paths(self) -> list[str]:
        out: list[str] = []
        seen: set[str] = set()
        for p in (self.config.mcp.allowed_paths or []):
            try:
                normalized = str(Path(p).expanduser().resolve())
            except Exception:
                continue
            if normalized in seen:
                continue
            seen.add(normalized)
            out.append(normalized)
        return out

    def _runtime_env_hint(self) -> str:
        system = platform.system()
        display_os = {"Darwin": "macOS", "Windows": "Windows", "Linux": "Linux"}.get(system, system)

        details: list[str] = []
        if system == "Darwin":
            mac_ver = platform.mac_ver()[0] or "unknown"
            details.append(f"- OS: {display_os} {mac_ver} (Darwin {platform.release()})")
        elif system == "Windows":
            details.append(f"- OS: {display_os} {platform.release()} ({platform.version()})")
        elif system == "Linux":
            distro = "unknown"
            ver = ""
            try:
                os_release = Path("/etc/os-release")
                if os_release.exists():
                    raw = os_release.read_text(encoding="utf-8", errors="replace")
                    kv: dict[str, str] = {}
                    for line in raw.splitlines():
                        if not line or "=" not in line:
                            continue
                        k, v = line.split("=", 1)
                        kv[k.strip()] = v.strip().strip('"')
                    distro = kv.get("NAME") or kv.get("ID") or distro
                    ver = kv.get("VERSION_ID") or ""
            except Exception:
                pass
            suffix = f" {ver}" if ver else ""
            details.append(f"- OS: {display_os} ({distro}{suffix}) (kernel {platform.release()})")
        else:
            details.append(f"- OS: {display_os} {platform.release()} ({platform.version()})")

        shell = os.environ.get("SHELL") or os.environ.get("ComSpec") or "unknown"
        details.append(f"- Shell: {shell}")
        details.append(f"- CWD: {os.getcwd()}")
        details.append("- Path style: macOS/Linux use '/', Windows may use 'C:\\\\...'.")
        return "\n".join(details)

    def _rewrite_mcp_args_for_speed(self, server_name: str, tool_name: str, args: dict, last_user_text: str) -> dict:
        """
        针对特定 MCP（如百度 ai_search）做轻量参数改写以提升速度与稳定性。
        - 默认不触发百度侧 LLM 总结（model="")，除非用户明确要求。
        - 默认收敛返回条数（resource_type_filter）。
        """
        if server_name == "aisearch-mcp-server":
            want_baidu_llm = any(k in (last_user_text or "") for k in ["千帆", "ERNIE", "百度大模型", "用百度总结", "用千帆总结", "用ERNIE总结"])
            if not want_baidu_llm:
                args = dict(args)
                args["model"] = ""
                args.setdefault("resource_type_filter", [{"type": "web", "top_k": 5}])
                args.setdefault("instruction", "返回简洁的结果列表，包含标题、链接、摘要。")
        return args


def run() -> None:
    app = MomcpTUI()
    app.run()


if __name__ == "__main__":
    run()

