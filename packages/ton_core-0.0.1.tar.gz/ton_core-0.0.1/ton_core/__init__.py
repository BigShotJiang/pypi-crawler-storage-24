"""
ton-core: Alias package for pytoniq-core.

This package re-exports everything from pytoniq-core,
allowing you to use `ton_core` as a drop-in replacement.

Original package: https://github.com/yungwine/pytoniq-core
"""

from pytoniq_core import *  # noqa: F401, F403