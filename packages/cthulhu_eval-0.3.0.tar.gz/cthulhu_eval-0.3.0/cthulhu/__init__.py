# -*- coding : utf-8 -*-

__name__ = "cthulhu"
__title__ = "cthulhu-eval"
__version__ = "0.3.0"
__licence__ = "MIT"
__doc__ = "HTR / OCR models evaluation agnostic Python package."
