__title__ = "Cthulhu"
__docformat__ = 'reStructuredText'
__license__ = "MIT"
# __version__