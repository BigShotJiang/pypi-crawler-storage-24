import unittest

from cthulhu.Cthulhu import Cthulhu


class testKamiClient(unittest.TestCase):
    def setUp(self) -> None:
        self.maxDiff = None

        self.reference = "Six semaines plus tard, Claude peignait un matin dans un flot de soleil qui tombait par la baie vitrée de l'atelier."
        self.prediction = "Six semaiNEs plus tard, lCCaude peignait un MA dans un flotille de soleil qui tombait baie vitrée de l'atelier."

        self.gt_alto = "datatest/lectaurep_set/image_gt_page1/FRAN_0187_16402_L-0_alto.xml"
        self.gt_page = "datatest/lectaurep_set/image_gt_page1/FRAN_0187_16402_L-0_page.xml"
        self.gt_txt  = "datatest/lectaurep_set/image_gt_page1/FRAN_0187_16402_L-0_gt.txt"

    def test_sentences(self):
        k = Cthulhu(
            [self.reference, self.prediction],
            truncate=True,
            percent=True,
            round_digits=".001",
        )
        self.assertEqual(
            k.scores.board,
            {
                "levensthein_distance_char": 20,
                "levensthein_distance_words": 6,
                "hamming_distance": "Ø",
                "wer": 28.571,
                "cer": 17.241,
                "wacc": 71.428,
                "wer_hunt": 23.809,
                "mer": 16.528,
                "cil": 20.775,
                "cip": 79.224,
                "hits": 101,
                "substitutions": 5,
                "deletions": 10,
                "insertions": 5,
                "rouge_1": {"precision": 78.947, "recall": 71.428, "f1": 75.0},
                "rouge_2": {"precision": 50.0, "recall": 45.0, "f1": 47.368},
                "rouge_l": {"precision": 78.947, "recall": 71.428, "f1": 75.0},
            },
        )

    def test_xml_alto_parses_text(self):
        """_XMLParser extracts non-empty content from an ALTO file."""
        from cthulhu.parser.parser_xml import _XMLParser

        parser = _XMLParser(self.gt_alto)
        self.assertEqual(parser.fmt, "alto")
        self.assertGreater(len(parser.sentences), 0)
        self.assertGreater(len(parser.content), 0)

    def test_xml_page_parses_text(self):
        """_XMLParser extracts non-empty content from a PAGE-XML file."""
        from cthulhu.parser.parser_xml import _XMLParser

        parser = _XMLParser(self.gt_page)
        self.assertEqual(parser.fmt, "page")
        self.assertGreater(len(parser.sentences), 0)
        self.assertGreater(len(parser.content), 0)

    def test_xml_and_txt_inputs(self):
        """Cthulhu accepts [xml_path, txt_path] and computes scores."""
        k = Cthulhu([self.gt_alto, self.gt_txt], truncate=True, percent=True)
        self.assertIn("cer", k.scores.board)

    def test_sentences_with_transforms(self):
        """Transforms board contains expected keys."""
        k = Cthulhu(
            [self.reference, self.prediction],
            apply_transforms="XP",
            truncate=True,
            percent=True,
        )
        board = k.scores.board
        self.assertIn("default", board)
        self.assertIn("remove_diacritics", board)
        self.assertIn("remove_punctuation", board)
        self.assertIn("all_transforms", board)
        self.assertIn("Length_reference", board)
