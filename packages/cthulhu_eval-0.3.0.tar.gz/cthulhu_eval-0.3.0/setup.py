# -*- coding : utf-8 -*-

from os import path
import io
import re
import setuptools

here = path.abspath(path.dirname(__file__))

# Read metadata directly from __init__.py to avoid importing the package
def _read_meta(key):
    init = path.join(here, "cthulhu", "__init__.py")
    with io.open(init, encoding="utf-8") as f:
        match = re.search(rf'^{key}\s*=\s*["\']([^"\']+)["\']', f.read(), re.M)
    if not match:
        raise RuntimeError(f"{key} not found in cthulhu/__init__.py")
    return match.group(1)

try:
    with io.open(path.join(here, 'README.md'), encoding='utf-8') as f:
        long_description = f.read()
except Exception:
    long_description = "HTR / OCR models evaluation agnostic Python package."

install_requires = [
    "python-Levenshtein>=0.21",
    "termcolor>=1.1.0",
    "Unidecode>=1.3",
]

CLASSIFIERS = [
    "Programming Language :: Python :: 3.9",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "License :: OSI Approved :: MIT License",
    "Operating System :: OS Independent",
]

setuptools.setup(
    name=_read_meta("__title__"),
    version=_read_meta("__version__"),
    author="Lucas Terriel, Alix Chagué",
    author_email="lucas.terriel@inria.fr, alix.chague@inria.fr",
    license=_read_meta("__licence__"),
    description="HTR / OCR models evaluation agnostic Python package.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=setuptools.find_packages(exclude=("tests", "datatest")),
    python_requires=">=3.9",
    install_requires=install_requires,
    classifiers=CLASSIFIERS,
    keywords=[
        "HTR", "OCR", "evaluation", "metrics",
        "handwritten text recognition", "optical character recognition",
    ],
)
