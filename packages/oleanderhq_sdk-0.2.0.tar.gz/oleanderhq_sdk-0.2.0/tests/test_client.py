"""Tests for the oleander Python SDK.

Integration tests (list_spark_jobs, query) run only when OLEANDER_API_KEY is set.
"""

from __future__ import annotations

import os

import pytest

import oleander_sdk.client as client_module
from oleander_sdk import (
    GlueWorkerType,
    Oleander,
    OleanderHttpError,
    OleanderOptions,
    RunNotFoundError,
    SparkCluster,
    SparkClusterType,
    SparkJobSubmitOptions,
    SparkMachineType,
)


# ---------------------------------------------------------------------------
# Unit tests
# ---------------------------------------------------------------------------


class TestOleanderConstructor:
    def test_throws_when_api_key_missing_and_env_unset(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.delenv("OLEANDER_API_KEY", raising=False)
        with pytest.raises(ValueError, match="Oleander requires a non-empty api_key"):
            Oleander()

    def test_accepts_api_key(self) -> None:
        oleander = Oleander(api_key="test-key")
        assert oleander is not None

    def test_uses_env_api_key(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("OLEANDER_API_KEY", "env-key")
        oleander = Oleander()
        assert oleander._api_key == "env-key"

    def test_constructor_api_key_takes_precedence(self, monkeypatch: pytest.MonkeyPatch) -> None:
        monkeypatch.setenv("OLEANDER_API_KEY", "env-key")
        oleander = Oleander(api_key="explicit-key")
        assert oleander._api_key == "explicit-key"

    def test_custom_base_url(self) -> None:
        oleander = Oleander(api_key="k", base_url="https://custom.example.com/")
        assert oleander._base_url == "https://custom.example.com"


class TestOleanderOptions:
    def test_parses_valid_options(self) -> None:
        opts = OleanderOptions(api_key="k", base_url="https://x.com")
        assert opts.api_key == "k"
        assert opts.base_url == "https://x.com"

    def test_allows_optional_api_key(self) -> None:
        opts = OleanderOptions()
        assert opts.api_key is None


class TestSubmitOptionsSchema:
    def test_parses_minimal_options_with_defaults(self) -> None:
        opts = SparkJobSubmitOptions(
            namespace="ns",
            name="job",
            entrypoint="main.py",
        )
        assert opts.cluster == "oleander"
        assert opts.namespace == "ns"
        assert opts.name == "job"
        assert opts.entrypoint == "main.py"
        assert opts.script_name == "main.py"
        assert opts.args == []
        assert opts.spark_conf == []
        assert opts.packages == []
        assert opts.driver_machine_type == SparkMachineType.SPARK_1_B
        assert opts.executor_numbers == 2
        assert opts.number_of_workers == 1

    def test_accepts_legacy_script_name_alias(self) -> None:
        opts = SparkJobSubmitOptions(
            namespace="ns",
            name="job",
            script_name="legacy.py",
        )
        assert opts.entrypoint == "legacy.py"
        assert opts.script_name == "legacy.py"

    def test_rejects_missing_required_fields(self) -> None:
        with pytest.raises(Exception):
            SparkJobSubmitOptions(namespace="ns", name="j")  # type: ignore[call-arg]
        with pytest.raises(Exception):
            SparkJobSubmitOptions(namespace="ns", script_name="x.py")  # type: ignore[call-arg]


class TestSparkJobSubmission:
    async def test_submit_spark_job_uses_v2_oleander_payload(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        oleander = Oleander(api_key="test-key", base_url="https://api.example.com")
        captured: dict[str, object] = {}

        async def fake_get_spark_cluster(name: str) -> SparkCluster:
            assert name == "oleander"
            return SparkCluster(
                name="oleander",
                type=SparkClusterType.OLEANDER,
                properties={},
            )

        async def fake_request(
            method: str,
            path: str,
            *,
            json: dict | None = None,
            params: dict[str, str] | None = None,
            content_type: bool = True,
            run_id: str | None = None,
        ) -> dict:
            captured.update(
                {
                    "method": method,
                    "path": path,
                    "json": json,
                    "params": params,
                    "content_type": content_type,
                    "run_id": run_id,
                }
            )
            return {"runId": "run-123"}

        monkeypatch.setattr(oleander, "get_spark_cluster", fake_get_spark_cluster)
        monkeypatch.setattr(oleander, "_request", fake_request)

        result = await oleander.submit_spark_job(
            SparkJobSubmitOptions(
                namespace="ns",
                name="job",
                entrypoint="main.py",
            )
        )

        assert result.run_id == "run-123"
        assert captured == {
            "method": "POST",
            "path": "/api/v2/spark/jobs",
            "json": {
                "cluster": "oleander",
                "namespace": "ns",
                "name": "job",
                "jobTags": [],
                "runTags": [],
                "properties": {
                    "entrypoint": "main.py",
                    "entrypointArguments": [],
                    "driverMachineType": "spark.1.b",
                    "executorMachineType": "spark.1.b",
                    "executorNumbers": 2,
                    "sparkConf": [],
                    "packages": [],
                },
            },
            "params": None,
            "content_type": True,
            "run_id": None,
        }

    async def test_submit_spark_job_builds_glue_payload(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        oleander = Oleander(api_key="test-key", base_url="https://api.example.com")
        captured: dict[str, object] = {}

        async def fake_get_spark_cluster(name: str) -> SparkCluster:
            assert name == "glue-prod"
            return SparkCluster(
                name="glue-prod",
                type=SparkClusterType.GLUE,
                properties={"controllerRoleArn": "arn:aws:iam::123456789012:role/test"},
            )

        async def fake_request(
            method: str,
            path: str,
            *,
            json: dict | None = None,
            params: dict[str, str] | None = None,
            content_type: bool = True,
            run_id: str | None = None,
        ) -> dict:
            captured["json"] = json
            return {"runId": "run-456"}

        monkeypatch.setattr(oleander, "get_spark_cluster", fake_get_spark_cluster)
        monkeypatch.setattr(oleander, "_request", fake_request)

        result = await oleander.submit_spark_job(
            SparkJobSubmitOptions(
                cluster="glue-prod",
                namespace="ns",
                name="job",
                entrypoint="glue-job",
                args=["--source", "s3://bucket/path"],
                spark_conf=["spark.sql.shuffle.partitions=8"],
                worker_type=GlueWorkerType.G_1X,
                number_of_workers=3,
                enable_auto_scaling=True,
                timeout_minutes=15,
                execution_class="FLEX",
                execution_iam_policy='{"Version":"2012-10-17"}',
            )
        )

        assert result.run_id == "run-456"
        assert captured["json"] == {
            "cluster": "glue-prod",
            "namespace": "ns",
            "name": "job",
            "jobTags": [],
            "runTags": [],
            "properties": {
                "jobName": "glue-job",
                "entrypointArguments": {"--source": "s3://bucket/path"},
                "sparkConf": ["spark.sql.shuffle.partitions=8"],
                "workerType": "G.1X",
                "numberOfWorkers": 3,
                "enableAutoScaling": True,
                "timeoutMinutes": 15,
                "executionClass": "FLEX",
                "executionRoleSessionPolicy": '{"Version":"2012-10-17"}',
            },
        }


class TestHttpErrors:
    async def test_get_run_404_raises_run_not_found(
        self,
        monkeypatch: pytest.MonkeyPatch,
    ) -> None:
        class FakeResponse:
            def __init__(self, status_code: int, body: object) -> None:
                self.status_code = status_code
                self._body = body

            def json(self) -> object:
                return self._body

        class FakeAsyncClient:
            def __init__(self, *args: object, **kwargs: object) -> None:
                pass

            async def __aenter__(self) -> "FakeAsyncClient":
                return self

            async def __aexit__(self, exc_type, exc, tb) -> None:
                return None

            async def request(
                self,
                method: str,
                url: str,
                *,
                headers: dict[str, str] | None = None,
                json: dict | None = None,
            ) -> FakeResponse:
                assert method == "GET"
                assert url == "https://api.example.com/api/v2/runs/run-123"
                assert headers == {"Authorization": "Bearer test-key"}
                assert json is None
                return FakeResponse(
                    404,
                    {
                        "error": "Run not found",
                        "details": "runId=run-123",
                    },
                )

        monkeypatch.setattr(client_module.httpx, "AsyncClient", FakeAsyncClient)

        oleander = Oleander(api_key="test-key", base_url="https://api.example.com")

        with pytest.raises(RunNotFoundError) as exc_info:
            await oleander.get_run("run-123")

        err = exc_info.value
        assert isinstance(err, OleanderHttpError)
        assert err.status == 404
        assert err.method == "GET"
        assert err.path == "/api/v2/runs/run-123"
        assert err.url == "https://api.example.com/api/v2/runs/run-123"
        assert err.run_id == "run-123"
        assert err.api_error == "Run not found"
        assert err.api_details == "runId=run-123"
        assert str(err) == "Run not found"


# ---------------------------------------------------------------------------
# Integration tests — only run when OLEANDER_API_KEY is set
# ---------------------------------------------------------------------------

_has_api_key = bool(os.environ.get("OLEANDER_API_KEY"))
skip_without_key = pytest.mark.skipif(not _has_api_key, reason="OLEANDER_API_KEY not set")


@skip_without_key
class TestListSparkJobsIntegration:
    async def test_returns_shape(self) -> None:
        from oleander_sdk import ListSparkJobsOptions

        oleander = Oleander()
        result = await oleander.list_spark_jobs(ListSparkJobsOptions(limit=5, offset=0))
        assert isinstance(result.scripts, list)
        assert isinstance(result.has_more, bool)


@skip_without_key
class TestQueryIntegration:
    async def test_returns_shape(self) -> None:
        from oleander_sdk import QueryOptions

        oleander = Oleander()
        result = await oleander.query(
            "SELECT * FROM oleander.default.flowers LIMIT 10",
            QueryOptions(save=False),
        )
        assert result.success is True
        assert result.results is not None
        assert result.row_count is not None
        assert result.execution_time is not None
        assert result.saved_table_name is None
