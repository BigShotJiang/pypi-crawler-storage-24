"""Pydantic models for the oleander SDK."""

from __future__ import annotations

from enum import Enum
from typing import Any, Optional

from pydantic import AliasChoices, BaseModel, ConfigDict, Field


class OleanderModel(BaseModel):
    model_config = ConfigDict(populate_by_name=True)


# ---------------------------------------------------------------------------
# Spark machine types
# ---------------------------------------------------------------------------

class SparkMachineType(str, Enum):
    SPARK_1_C = "spark.1.c"
    SPARK_2_C = "spark.2.c"
    SPARK_4_C = "spark.4.c"
    SPARK_8_C = "spark.8.c"
    SPARK_16_C = "spark.16.c"
    SPARK_1_B = "spark.1.b"
    SPARK_2_B = "spark.2.b"
    SPARK_4_B = "spark.4.b"
    SPARK_8_B = "spark.8.b"
    SPARK_16_B = "spark.16.b"
    SPARK_1_M = "spark.1.m"
    SPARK_2_M = "spark.2.m"
    SPARK_4_M = "spark.4.m"
    SPARK_8_M = "spark.8.m"
    SPARK_16_M = "spark.16.m"


class GlueWorkerType(str, Enum):
    G_1X = "G.1X"
    G_2X = "G.2X"
    G_4X = "G.4X"
    G_8X = "G.8X"
    G_025X = "G.025X"


class SparkClusterType(str, Enum):
    OLEANDER = "oleander"
    EMR_SERVERLESS = "emr-serverless"
    GLUE = "glue"


# ---------------------------------------------------------------------------
# API error
# ---------------------------------------------------------------------------

class ApiErrorBody(OleanderModel):
    error: Optional[str] = None
    details: Optional[str] = None


# ---------------------------------------------------------------------------
# Constructor options
# ---------------------------------------------------------------------------

DEFAULT_BASE_URL = "https://oleander.dev"


class OleanderOptions(OleanderModel):
    api_key: Optional[str] = None
    base_url: str = DEFAULT_BASE_URL


# ---------------------------------------------------------------------------
# Query
# ---------------------------------------------------------------------------

class QueryOptions(OleanderModel):
    save: bool = False


class QueryResultColumns(OleanderModel):
    columns: list[str]
    column_types: list[str]
    rows: list[list[Any]]


class LakeQueryResult(OleanderModel):
    success: bool
    results: Optional[QueryResultColumns] = None
    row_count: Optional[int] = None
    execution_time: Optional[str] = None
    saved_table_name: Optional[str] = None
    error: Optional[str] = None
    details: Optional[str] = None
    query: Optional[str] = None


# ---------------------------------------------------------------------------
# Spark job list
# ---------------------------------------------------------------------------

class GetSparkClusterOptions(OleanderModel):
    name: str = Field(min_length=1)


class SparkCluster(OleanderModel):
    name: str
    type: SparkClusterType
    properties: Any


class SparkJobListPage(OleanderModel):
    scripts: list[str]
    continuation_token: Optional[str] = Field(None, alias="continuationToken")


class ListSparkJobsOptions(OleanderModel):
    limit: int = Field(default=20, gt=0)
    offset: int = Field(default=0, ge=0)


class ListSparkJobsResult(OleanderModel):
    scripts: list[str]
    has_more: bool


# ---------------------------------------------------------------------------
# Spark job submit
# ---------------------------------------------------------------------------

class SparkJobSubmitOptions(OleanderModel):
    cluster: str = "oleander"
    namespace: str = Field(min_length=1)
    name: str = Field(min_length=1)
    entrypoint: str = Field(
        min_length=1,
        validation_alias=AliasChoices("entrypoint", "script_name"),
    )
    args: list[str] = Field(default_factory=list)
    py_files: Optional[str] = None
    main_class: Optional[str] = None
    spark_conf: list[str] = Field(default_factory=list)
    packages: list[str] = Field(default_factory=list)
    execution_iam_policy: Optional[str] = None
    driver_machine_type: SparkMachineType = SparkMachineType.SPARK_1_B
    executor_machine_type: SparkMachineType = SparkMachineType.SPARK_1_B
    executor_numbers: int = Field(default=2, ge=1, le=20)
    job_tags: list[str] = Field(default_factory=list)
    run_tags: list[str] = Field(default_factory=list)
    worker_type: Optional[GlueWorkerType] = None
    number_of_workers: int = Field(default=1, ge=1)
    enable_auto_scaling: Optional[bool] = None
    timeout_minutes: Optional[int] = None
    execution_class: Optional[str] = None

    @property
    def script_name(self) -> str:
        return self.entrypoint


class SubmitSparkJobAndWaitOptions(SparkJobSubmitOptions):
    poll_interval_ms: int = Field(default=10_000, gt=0)
    timeout_ms: int = Field(default=600_000, gt=0)


class SparkJobRun(OleanderModel):
    run_id: str = Field(alias="runId")


# ---------------------------------------------------------------------------
# Run status
# ---------------------------------------------------------------------------

RunState = str

TERMINAL_STATES: set[str] = {"COMPLETE", "FAIL", "ABORT"}


class RunTag(OleanderModel):
    key: str
    value: str
    source: Optional[str] = None


class RunJobInfo(OleanderModel):
    id: str
    name: str
    namespace: str


class RunPipelineInfo(OleanderModel):
    id: str
    name: str
    namespace: str


class RunResponse(OleanderModel):
    id: str
    state: Optional[str] = None
    started_at: Optional[str] = None
    queued_at: Optional[str] = None
    scheduled_at: Optional[str] = None
    ended_at: Optional[str] = None
    duration: Optional[float] = None
    error: Optional[Any] = None
    tags: list[RunTag]
    job: RunJobInfo
    pipeline: RunPipelineInfo
