"""Error types for the oleander Python SDK."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional

from .models import ApiErrorBody


@dataclass(frozen=True)
class ParsedApiError:
    message: str
    error: Optional[str] = None
    details: Optional[str] = None


class OleanderError(Exception):
    """Base SDK error."""


class OleanderHttpError(OleanderError):
    """Raised for non-2xx HTTP responses."""

    def __init__(
        self,
        *,
        status: int,
        method: str,
        path: str,
        url: str,
        body: Any,
        api_error: Optional[str] = None,
        api_details: Optional[str] = None,
        message: Optional[str] = None,
    ) -> None:
        resolved_message = (
            message
            or api_error
            or api_details
            or f"HTTP {status} for {method} {path}"
        )
        super().__init__(resolved_message)
        self.status = status
        self.method = method
        self.path = path
        self.url = url
        self.body = body
        self.api_error = api_error
        self.api_details = api_details


class RunNotFoundError(OleanderHttpError):
    """Raised when ``get_run`` returns a 404 for a specific run ID."""

    def __init__(self, run_id: str, **kwargs: Any) -> None:
        super().__init__(**kwargs)
        self.run_id = run_id


def parse_api_error_body(
    body: Any,
    status: int,
    method: str,
    path: str,
) -> ParsedApiError:
    try:
        parsed = ApiErrorBody.model_validate(body)
    except Exception:
        return ParsedApiError(message=f"HTTP {status} for {method} {path}")

    return ParsedApiError(
        message=parsed.error or parsed.details or f"HTTP {status} for {method} {path}",
        error=parsed.error,
        details=parsed.details,
    )
