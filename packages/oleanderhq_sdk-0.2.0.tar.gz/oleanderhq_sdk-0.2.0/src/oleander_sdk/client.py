"""Oleander API client."""

from __future__ import annotations

import asyncio
import os
import time
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any, Optional
from urllib.parse import urlencode

import httpx

from .errors import OleanderHttpError, RunNotFoundError, parse_api_error_body
from .models import (
    DEFAULT_BASE_URL,
    GetSparkClusterOptions,
    LakeQueryResult,
    ListSparkJobsOptions,
    ListSparkJobsResult,
    OleanderOptions,
    QueryOptions,
    RunResponse,
    RunState,
    SparkCluster,
    SparkClusterType,
    SparkJobListPage,
    SparkJobRun,
    SparkJobSubmitOptions,
    SubmitSparkJobAndWaitOptions,
    TERMINAL_STATES,
)


def _build_glue_arguments(args: list[str]) -> dict[str, str]:
    result: dict[str, str] = {}
    for i in range(0, len(args), 2):
        key = args[i]
        try:
            value = args[i + 1]
        except IndexError as exc:
            raise ValueError(f"Missing value for argument: {key}") from exc
        result[key] = value
    return result


def _omit_none_values(values: Mapping[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in values.items() if value is not None}


@dataclass
class SubmitAndWaitResult:
    """Result returned by :meth:`Oleander.submit_spark_job_and_wait`."""

    run_id: str
    state: RunState
    run: RunResponse


class Oleander:
    """Oleander API client.

    Mirrors the TypeScript SDK for query, Spark job listing, and Spark job
    submission.
    """

    def __init__(
        self,
        *,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
    ) -> None:
        opts = OleanderOptions(
            api_key=api_key,
            **({"base_url": base_url} if base_url is not None else {}),
        )

        resolved_key = (opts.api_key or "").strip() or os.environ.get(
            "OLEANDER_API_KEY", ""
        )
        if not resolved_key:
            raise ValueError(
                "Oleander requires a non-empty api_key (or set OLEANDER_API_KEY)"
            )

        self._api_key = resolved_key
        self._base_url = (opts.base_url or DEFAULT_BASE_URL).strip().rstrip("/")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _headers(self, *, content_type: bool = True) -> dict[str, str]:
        h: dict[str, str] = {"Authorization": f"Bearer {self._api_key}"}
        if content_type:
            h["Content-Type"] = "application/json"
        return h

    def _create_http_error(
        self,
        method: str,
        path: str,
        status: int,
        body: Any,
        *,
        run_id: Optional[str] = None,
    ) -> OleanderHttpError:
        parsed = parse_api_error_body(body, status, method, path)
        init = {
            "status": status,
            "method": method,
            "path": path,
            "url": f"{self._base_url}{path}",
            "body": body,
            "api_error": parsed.error,
            "api_details": parsed.details,
            "message": parsed.message,
        }
        if status == 404 and run_id:
            return RunNotFoundError(run_id, **init)
        return OleanderHttpError(**init)

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: Optional[dict[str, Any]] = None,
        params: Optional[dict[str, str]] = None,
        content_type: bool = True,
        run_id: Optional[str] = None,
    ) -> dict[str, Any]:
        request_path = path
        if params:
            request_path = f"{path}?{urlencode(params)}"

        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.request(
                method,
                f"{self._base_url}{request_path}",
                headers=self._headers(content_type=content_type),
                json=json,
            )
        try:
            body = resp.json()
        except Exception:
            body = {}
        if resp.status_code >= 400:
            raise self._create_http_error(
                method,
                request_path,
                resp.status_code,
                body,
                run_id=run_id,
            )
        if isinstance(body, dict):
            return body
        return body

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    async def query(
        self,
        sql: str,
        options: Optional[QueryOptions] = None,
    ) -> LakeQueryResult:
        """Execute a lake query (mirrors ``oleander query``)."""
        q = (sql or "").strip()
        if not q:
            raise ValueError("Query is required")
        opts = options or QueryOptions()

        raw = await self._request(
            "POST",
            "/api/v1/warehouse/query",
            json={"query": q, "autoSaveByHash": opts.save},
        )

        result = LakeQueryResult.model_validate(raw)
        if not result.success and result.error:
            raise RuntimeError(result.details or result.error)
        return result

    async def get_spark_cluster(
        self,
        options: str | GetSparkClusterOptions,
    ) -> SparkCluster:
        """Get Spark cluster information."""
        if isinstance(options, GetSparkClusterOptions):
            cluster_name = options.name
        else:
            cluster_name = options

        name = (cluster_name or "").strip()
        if not name:
            raise ValueError("Cluster name is required")

        if name == "oleander":
            return SparkCluster(
                name="oleander",
                type=SparkClusterType.OLEANDER,
                properties={},
            )

        raw = await self._request(
            "GET",
            f"/api/v2/spark/clusters/{name}",
            content_type=False,
        )
        return SparkCluster.model_validate(raw)

    async def list_spark_jobs(
        self,
        options: Optional[ListSparkJobsOptions] = None,
    ) -> ListSparkJobsResult:
        """List spark jobs (mirrors ``oleander spark jobs list``).

        Uses limit/offset pagination; pages through the API internally.
        """
        opts = options or ListSparkJobsOptions()
        limit, offset = opts.limit, opts.offset

        all_scripts: list[str] = []
        continuation_token: Optional[str] = None

        while True:
            params: Optional[dict[str, str]] = None
            if continuation_token:
                params = {"continuationToken": continuation_token}

            raw = await self._request(
                "GET",
                "/api/v1/spark/scripts",
                params=params,
                content_type=False,
            )

            page = SparkJobListPage.model_validate(raw)
            all_scripts.extend(page.scripts)
            continuation_token = page.continuation_token
            if not continuation_token or len(all_scripts) >= offset + limit:
                break

        sliced = all_scripts[offset : offset + limit]
        has_more = bool(continuation_token) or len(all_scripts) > offset + limit
        return ListSparkJobsResult(scripts=sliced, has_more=has_more)

    async def submit_spark_job(
        self,
        options: SparkJobSubmitOptions,
    ) -> SparkJobRun:
        """Submit a spark job (mirrors ``oleander spark jobs submit``).

        Returns the run ID; use :meth:`get_run` or
        :meth:`submit_spark_job_and_wait` to poll status.
        """
        cluster = await self.get_spark_cluster(options.cluster)

        if cluster.type == SparkClusterType.OLEANDER:
            properties = {
                "entrypoint": options.entrypoint,
                "entrypointArguments": options.args,
                "driverMachineType": options.driver_machine_type.value,
                "executorMachineType": options.executor_machine_type.value,
                "executorNumbers": options.executor_numbers,
                "sparkConf": options.spark_conf,
                "packages": options.packages,
            }
        elif cluster.type == SparkClusterType.EMR_SERVERLESS:
            properties = _omit_none_values(
                {
                    "entrypoint": options.entrypoint,
                    "entrypointArguments": options.args,
                    "pyFiles": options.py_files,
                    "mainClass": options.main_class,
                    "sparkConf": options.spark_conf,
                    "packages": options.packages,
                    "executionIamPolicy": options.execution_iam_policy,
                }
            )
        elif cluster.type == SparkClusterType.GLUE:
            properties = _omit_none_values(
                {
                    "jobName": options.entrypoint,
                    "entrypointArguments": _build_glue_arguments(options.args),
                    "sparkConf": options.spark_conf,
                    "workerType": (
                        options.worker_type.value
                        if options.worker_type is not None
                        else None
                    ),
                    "numberOfWorkers": options.number_of_workers,
                    "enableAutoScaling": options.enable_auto_scaling,
                    "timeoutMinutes": options.timeout_minutes,
                    "executionClass": options.execution_class,
                    "executionRoleSessionPolicy": options.execution_iam_policy,
                }
            )
        else:
            raise ValueError(f"Unsupported cluster type: {cluster.type}")

        raw = await self._request(
            "POST",
            "/api/v2/spark/jobs",
            json={
                "cluster": options.cluster,
                "namespace": options.namespace.strip(),
                "name": options.name.strip(),
                "jobTags": options.job_tags,
                "runTags": options.run_tags,
                "properties": properties,
            },
        )
        return SparkJobRun.model_validate(raw)

    async def get_run(self, run_id: str) -> RunResponse:
        """Get run status (used for polling after submit)."""
        if not run_id or not run_id.strip():
            raise ValueError("run_id is required")

        raw = await self._request(
            "GET",
            f"/api/v2/runs/{run_id}",
            content_type=False,
            run_id=run_id,
        )
        return RunResponse.model_validate(raw)

    async def submit_spark_job_and_wait(
        self,
        options: SubmitSparkJobAndWaitOptions,
    ) -> SubmitAndWaitResult:
        """Submit a spark job and wait until the run reaches a terminal state
        (COMPLETE, FAIL, ABORT).
        """
        submit_opts = SparkJobSubmitOptions(
            **options.model_dump(exclude={"poll_interval_ms", "timeout_ms"})
        )
        result = await self.submit_spark_job(submit_opts)
        run_id = result.run_id
        poll_interval_s = options.poll_interval_ms / 1000.0
        timeout_s = options.timeout_ms / 1000.0
        started = time.monotonic()

        while time.monotonic() - started < timeout_s:
            run = await self.get_run(run_id)
            state = run.state or ""
            if state in TERMINAL_STATES:
                return SubmitAndWaitResult(run_id=run_id, state=state, run=run)
            await asyncio.sleep(poll_interval_s)

        run = await self.get_run(run_id)
        raise TimeoutError(
            f"Timeout waiting for run {run_id} (state: {run.state or 'unknown'})"
        )
