"""Canopy Viewer - NiceGUI app for creating canopy figures from JSON config."""
