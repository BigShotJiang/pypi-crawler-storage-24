# Static assets for Canopy Viewer

Place the following image files in this folder:

- `logo.png` - Logo displayed at top center
- `simple_map.png` - Simple map figure type
- `diff_map.png` - Difference map figure type
- `time_series.png` - Time series figure type
- `static.png` - Static (scatter) figure type
- `distribution.png` - Distribution figure type
- `latitudinal.png` - Latitudinal figure type
