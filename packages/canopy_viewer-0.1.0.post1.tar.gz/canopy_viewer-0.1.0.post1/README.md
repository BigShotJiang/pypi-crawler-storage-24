# Canopy Viewer

NiceGUI app for creating canopy figures from JSON config. Select fields, configure options, and generate maps, time series, distributions, and more.

## Installation

**pip** (recommended):

```bash
pip install canopy-viewer
```

**UV**:

```bash
uv pip install canopy-viewer
```

**From source** (development):

```bash
pip install -e .
```

## Run

```bash
canopy-viewer
```

Or:

```bash
python -m main
```

Opens a native window with a sidebar for field selection and figure options.
