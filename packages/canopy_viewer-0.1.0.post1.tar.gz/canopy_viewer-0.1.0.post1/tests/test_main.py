"""Unit tests for main module helpers (e.g. _validate_run_request)."""
from unittest.mock import MagicMock, patch

import pytest

from main import _validate_run_request


class TestValidateRunRequest:
    """Unit tests for _validate_run_request."""

    @pytest.fixture(autouse=True)
    def mock_canopy(self):
        """Mock canopy import so tests run without the package."""
        with patch.dict("sys.modules", {"canopy": MagicMock()}):
            yield

    def test_empty_fields_returns_error(self):
        assert _validate_run_request([], "time_series", {}) == "Please select at least one field."

    def test_no_figure_returns_error(self):
        assert _validate_run_request(
            ["/path/file.nc"], "", {}
        ) == "Please select a valid figure type."

    def test_invalid_figure_returns_error(self):
        # map_simple requires 1 field, map_diff requires 2
        assert _validate_run_request(
            ["a.nc", "b.nc"], "map_simple", {"layer": "x"}
        ) == "Please select a valid figure type."
        assert _validate_run_request(
            ["a.nc"], "map_diff", {"layer": "x"}
        ) == "Please select a valid figure type."

    def test_map_simple_requires_layer(self):
        assert _validate_run_request(
            ["/path/file.nc"], "map_simple", {}
        ) == "Please specify a layer for the map (e.g. the variable name in your data)."

    def test_map_diff_requires_layer(self):
        assert _validate_run_request(
            ["a.nc", "b.nc"], "map_diff", {}
        ) == "Please specify a layer for the map (e.g. the variable name in your data)."

    def test_map_simple_with_layer_succeeds(self):
        assert _validate_run_request(
            ["/path/file.nc"], "map_simple", {"layer": "temperature"}
        ) is None

    def test_map_diff_with_layer_succeeds(self):
        assert _validate_run_request(
            ["a.nc", "b.nc"], "map_diff", {"layer": "var"}
        ) is None

    def test_time_series_succeeds(self):
        assert _validate_run_request(
            ["/path/file.nc"], "time_series", {}
        ) is None

    def test_static_succeeds(self):
        assert _validate_run_request(
            ["a.nc", "b.nc"], "static", {}
        ) is None

    def test_distribution_succeeds(self):
        assert _validate_run_request(
            ["/path/file.nc"], "distribution", {}
        ) is None

    def test_latitudinal_plot_succeeds(self):
        assert _validate_run_request(
            ["/path/file.nc"], "latitudinal_plot", {}
        ) is None

    def test_canopy_import_error_returned(self):
        """When canopy fails to import, error message is returned."""
        import builtins

        orig_import = builtins.__import__

        def failing_import(name, *args, **kwargs):
            if name == "canopy":
                raise ImportError("No module named 'canopy'")
            return orig_import(name, *args, **kwargs)

        with patch.object(builtins, "__import__", failing_import):
            result = _validate_run_request(
                ["/path/file.nc"], "time_series", {}
            )
        assert result is not None
        assert "Canopy package" in result or "canopy" in result.lower()
