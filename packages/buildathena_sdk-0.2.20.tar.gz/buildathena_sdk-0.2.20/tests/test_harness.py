"""Tests for the harness input handling.

Verifies that the harness correctly reconstructs OutputHandles from
storage-reference dicts when passing inputs between blocks in the same run.
"""

from unittest.mock import AsyncMock, patch
from uuid import uuid4

import pytest

from athena import RegisteredArtifact
from athena._generated_schemas import ArtifactRef
from athena.harness import _execute_task, _load_block
from athena.output_handle import OutputHandle
from athena.storage import MemoryStorageBackend


@pytest.fixture
def memory_storage() -> MemoryStorageBackend:
    """Create an in-memory storage backend for testing."""
    return MemoryStorageBackend()


class TestHarnessStorageRefInputs:
    """Tests for harness handling of storage-reference inputs from upstream blocks."""

    @pytest.mark.asyncio
    async def test_storage_ref_input_reconstructs_output_handle(
        self, memory_storage: MemoryStorageBackend
    ) -> None:
        """Test that storage-ref inputs are reconstructed as OutputHandles with loaded data."""
        # Simulate what an upstream block does: materialize data to storage
        upstream_data = [1, 2, 3, 4, 5]
        upstream_handle = OutputHandle.from_data(
            upstream_data, name="dataset", schema_type="dataset"
        )
        content_hash = await upstream_handle.materialize(memory_storage)

        # Build the task dict as the daemon would send it
        # (storage_key + content_hash, no artifact_id)
        task = {
            "block_path": "fake_block.py",
            "block_id": "fake_block",
            "config": {},
            "inputs": {
                "dataset": {
                    "storage_key": upstream_handle.storage_key,
                    "content_hash": content_hash,
                    "schema_type": "dataset",
                    "name": "dataset",
                },
            },
            "run_id": str(uuid4()),
            "step_id": "test_step_0",
        }

        # Create a simple block that reads the input and returns it
        captured_inputs: dict = {}

        async def fake_block(ctx):
            captured_inputs["dataset"] = ctx.inputs["dataset"]
            return {}

        fake_block.__athena_block__ = type(  # pyright: ignore[reportFunctionMemberAccess]
            "BlockSpec", (), {"name": "FakeBlock", "inputs": [], "outputs": []}
        )()

        with patch("athena.harness._load_block", return_value=(fake_block, None)):
            await _execute_task(AsyncMock(), "http://fake:8000", task, memory_storage)

        # The block should receive the actual data, not the raw dict
        assert captured_inputs["dataset"] == [1, 2, 3, 4, 5]

    @pytest.mark.asyncio
    async def test_storage_ref_input_without_storage_passes_handle(self) -> None:
        """Test that storage-ref inputs still create OutputHandle even without storage."""
        task = {
            "block_path": "fake_block.py",
            "block_id": "fake_block",
            "config": {},
            "inputs": {
                "dataset": {
                    "storage_key": "some/path",
                    "content_hash": "abc123",
                    "schema_type": "dataset",
                    "name": "dataset",
                },
            },
            "run_id": str(uuid4()),
            "step_id": "test_step_0",
        }

        captured_inputs: dict = {}

        async def fake_block(ctx):
            # Without storage, the handle exists but has no data
            val = ctx.inputs["dataset"]
            captured_inputs["type"] = type(val).__name__
            captured_inputs["is_materialized"] = val.is_materialized
            return {}

        fake_block.__athena_block__ = type(  # pyright: ignore[reportFunctionMemberAccess]
            "BlockSpec", (), {"name": "FakeBlock", "inputs": [], "outputs": []}
        )()

        with patch("athena.harness._load_block", return_value=(fake_block, None)):
            # Pass storage=None to simulate missing storage
            await _execute_task(AsyncMock(), "http://fake:8000", task, None)

        # Should be an OutputHandle, even without loaded data
        assert captured_inputs["type"] == "OutputHandle"
        assert captured_inputs["is_materialized"] is True

    @pytest.mark.asyncio
    async def test_canonical_artifact_pointer_input_reconstructs_artifact_ref(self) -> None:
        """Canonical artifact pointers should still reconstruct ArtifactRef inputs."""
        artifact_id = uuid4()
        task = {
            "block_path": "fake_block.py",
            "block_id": "fake_block",
            "config": {},
            "inputs": {
                "ref": {
                    "__artifact_ref__": True,
                    "artifact_id": str(artifact_id),
                    "schema_type": "model",
                    "name": "trained_model",
                },
            },
            "run_id": str(uuid4()),
            "step_id": "test_step_0",
        }

        captured_inputs: dict = {}

        async def fake_block(ctx):
            val = ctx.inputs["ref"]
            captured_inputs["type"] = type(val).__name__
            captured_inputs["artifact_id"] = val.artifact_id
            return {}

        fake_block.__athena_block__ = type(  # pyright: ignore[reportFunctionMemberAccess]
            "BlockSpec", (), {"name": "FakeBlock", "inputs": [], "outputs": []}
        )()

        with patch("athena.harness._load_block", return_value=(fake_block, None)):
            await _execute_task(AsyncMock(), "http://fake:8000", task, None)

        assert captured_inputs["type"] == "ArtifactRef"
        assert captured_inputs["artifact_id"] == artifact_id

    @pytest.mark.asyncio
    async def test_legacy_artifact_pointer_dict_no_longer_reconstructs_artifact_ref(self) -> None:
        """Bare artifact_id dicts should pass through as plain dicts."""
        artifact_id = uuid4()
        task = {
            "block_path": "fake_block.py",
            "block_id": "fake_block",
            "config": {},
            "inputs": {
                "ref": {
                    "artifact_id": str(artifact_id),
                    "schema_type": "model",
                    "name": "trained_model",
                },
            },
            "run_id": str(uuid4()),
            "step_id": "test_step_0",
        }

        captured_inputs: dict = {}

        async def fake_block(ctx):
            captured_inputs["type"] = type(ctx.inputs["ref"]).__name__
            captured_inputs["value"] = ctx.inputs["ref"]
            return {}

        fake_block.__athena_block__ = type(  # pyright: ignore[reportFunctionMemberAccess]
            "BlockSpec", (), {"name": "FakeBlock", "inputs": [], "outputs": []}
        )()

        with patch("athena.harness._load_block", return_value=(fake_block, None)):
            await _execute_task(AsyncMock(), "http://fake:8000", task, None)

        assert captured_inputs["type"] == "dict"
        assert captured_inputs["value"] == {
            "artifact_id": str(artifact_id),
            "schema_type": "model",
            "name": "trained_model",
        }

    @pytest.mark.asyncio
    async def test_storage_ref_wins_when_artifact_id_is_also_present(
        self, memory_storage: MemoryStorageBackend
    ) -> None:
        """Mixed refs should still reconstruct OutputHandle for same-run fast path."""
        upstream_handle = OutputHandle.from_data({"value": 42}, name="dataset")
        content_hash = await upstream_handle.materialize(memory_storage)
        artifact_id = uuid4()

        task = {
            "block_path": "fake_block.py",
            "block_id": "fake_block",
            "config": {},
            "inputs": {
                "dataset": {
                    "artifact_id": str(artifact_id),
                    "storage_key": upstream_handle.storage_key,
                    "content_hash": content_hash,
                    "schema_type": "dataset",
                    "name": "dataset",
                },
            },
            "run_id": str(uuid4()),
            "step_id": "test_step_0",
        }

        captured_inputs: dict = {}

        async def fake_block(ctx):
            val = ctx.inputs["dataset"]
            captured_inputs["type"] = type(val).__name__
            captured_inputs["value"] = val
            return {}

        fake_block.__athena_block__ = type(  # pyright: ignore[reportFunctionMemberAccess]
            "BlockSpec", (), {"name": "FakeBlock", "inputs": [], "outputs": []}
        )()

        with patch("athena.harness._load_block", return_value=(fake_block, None)):
            await _execute_task(AsyncMock(), "http://fake:8000", task, memory_storage)

        assert captured_inputs["type"] == "dict"
        assert captured_inputs["value"] == {"value": 42}

    @pytest.mark.asyncio
    async def test_pickle_fallback_emits_warning(
        self, memory_storage: MemoryStorageBackend
    ) -> None:
        """Test that non-JSON-serializable outputs emit a pickle warning."""
        import warnings

        task = {
            "block_path": "fake_block.py",
            "block_id": "fake_block",
            "config": {},
            "inputs": {},
            "run_id": str(uuid4()),
            "step_id": "test_step_0",
        }

        # Return something that isn't JSON-serializable (like a set)
        async def fake_block(_ctx):
            return {"data": {1, 2, 3}}

        fake_block.__athena_block__ = type(  # pyright: ignore[reportFunctionMemberAccess]
            "BlockSpec", (), {"name": "FakeBlock", "inputs": [], "outputs": []}
        )()

        with (
            patch("athena.harness._load_block", return_value=(fake_block, None)),
            warnings.catch_warnings(record=True) as w,
        ):
            warnings.simplefilter("always")
            await _execute_task(AsyncMock(), "http://fake:8000", task, memory_storage)

        # Should have emitted a pickle fallback warning
        pickle_warnings = [x for x in w if "pickle" in str(x.message).lower()]
        assert len(pickle_warnings) == 1
        assert "set" in str(pickle_warnings[0].message)

    @pytest.mark.asyncio
    async def test_plain_dict_input_passes_through(self) -> None:
        """Test that plain dicts (no artifact_id, no storage_key) pass through as-is."""
        task = {
            "block_path": "fake_block.py",
            "block_id": "fake_block",
            "config": {},
            "inputs": {
                "params": {"learning_rate": 0.01, "epochs": 100},
            },
            "run_id": str(uuid4()),
            "step_id": "test_step_0",
        }

        captured_inputs: dict = {}

        async def fake_block(ctx):
            captured_inputs["params"] = ctx.inputs["params"]
            return {}

        fake_block.__athena_block__ = type(  # pyright: ignore[reportFunctionMemberAccess]
            "BlockSpec", (), {"name": "FakeBlock", "inputs": [], "outputs": []}
        )()

        with patch("athena.harness._load_block", return_value=(fake_block, None)):
            await _execute_task(AsyncMock(), "http://fake:8000", task, None)

        assert captured_inputs["params"] == {"learning_rate": 0.01, "epochs": 100}

    @pytest.mark.asyncio
    async def test_output_handle_preserves_mime_type(
        self, memory_storage: MemoryStorageBackend
    ) -> None:
        """Test that materialized OutputHandles keep MIME metadata in worker output refs."""
        task = {
            "block_path": "fake_block.py",
            "block_id": "fake_block",
            "config": {},
            "inputs": {},
            "run_id": str(uuid4()),
            "step_id": "test_step_0",
        }

        async def fake_block(_ctx):
            return {
                "image": OutputHandle.from_data(
                    b"fake-image-bytes",
                    name="preview.png",
                    schema_type="samples",
                    mime_type="image/png",
                    format="pickle",
                )
            }

        fake_block.__athena_block__ = type(  # pyright: ignore[reportFunctionMemberAccess]
            "BlockSpec", (), {"name": "FakeBlock", "inputs": [], "outputs": []}
        )()

        with patch("athena.harness._load_block", return_value=(fake_block, None)):
            outputs = await _execute_task(AsyncMock(), "http://fake:8000", task, memory_storage)

        assert outputs["image"]["mime_type"] == "image/png"

    @pytest.mark.asyncio
    async def test_registered_artifact_data_output_is_serialized_directly(
        self, memory_storage: MemoryStorageBackend
    ) -> None:
        """RegisteredArtifact data outputs should round-trip as published refs."""
        artifact_id = uuid4()
        task = {
            "block_path": "fake_block.py",
            "block_id": "fake_block",
            "config": {},
            "inputs": {},
            "run_id": str(uuid4()),
            "step_id": "test_step_0",
        }

        async def fake_block(_ctx):
            return {
                "metrics": RegisteredArtifact(
                    ref=ArtifactRef(
                        artifact_id=artifact_id,
                        schema_type="metrics",
                        name="metrics",
                    ),
                    content_hash="abc123",
                    storage_key="abc123",
                    format="json",
                    mime_type="application/json",
                    metadata={"epoch": 1},
                ).as_data()
            }

        fake_block.__athena_block__ = type(  # pyright: ignore[reportFunctionMemberAccess]
            "BlockSpec", (), {"name": "FakeBlock", "inputs": [], "outputs": []}
        )()

        with patch("athena.harness._load_block", return_value=(fake_block, None)):
            outputs = await _execute_task(AsyncMock(), "http://fake:8000", task, memory_storage)

        assert outputs["metrics"]["artifact_id"] == str(artifact_id)
        assert outputs["metrics"]["content_hash"] == "abc123"
        assert outputs["metrics"]["storage_key"] == "abc123"
        assert outputs["metrics"]["format"] == "json"

    @pytest.mark.asyncio
    async def test_bare_registered_artifact_output_fails_fast(
        self, memory_storage: MemoryStorageBackend
    ) -> None:
        """Blocks must choose explicit downstream delivery for registered artifacts."""
        task = {
            "block_path": "fake_block.py",
            "block_id": "fake_block",
            "config": {},
            "inputs": {},
            "run_id": str(uuid4()),
            "step_id": "test_step_0",
        }

        async def fake_block(_ctx):
            return {
                "metrics": RegisteredArtifact(
                    ref=ArtifactRef(
                        artifact_id=uuid4(),
                        schema_type="metrics",
                        name="metrics",
                    ),
                    content_hash="abc123",
                    storage_key="abc123",
                    format="json",
                )
            }

        fake_block.__athena_block__ = type(  # pyright: ignore[reportFunctionMemberAccess]
            "BlockSpec", (), {"name": "FakeBlock", "inputs": [], "outputs": []}
        )()

        with (
            patch("athena.harness._load_block", return_value=(fake_block, None)),
            pytest.raises(
                ValueError,
                match="Blocks must return artifact.as_ref\\(\\) or artifact.as_data\\(\\)",
            ),
        ):
            await _execute_task(AsyncMock(), "http://fake:8000", task, memory_storage)


def test_load_block_requires_function_name(tmp_path) -> None:
    block_path = tmp_path / "blocks.py"
    block_path.write_text(
        "\n".join(
            [
                "from athena.decorators import block",
                "",
                "@block(name='Fancy Block')",
                "def real_block(ctx):",
                "    return {}",
            ]
        )
    )

    block_func, _config_class = _load_block(str(block_path), "real_block")

    assert block_func.__name__ == "real_block"


def test_load_block_does_not_fallback_to_display_name(tmp_path) -> None:
    block_path = tmp_path / "blocks.py"
    block_path.write_text(
        "\n".join(
            [
                "from athena.decorators import block",
                "",
                "@block(name='Fancy Block')",
                "def real_block(ctx):",
                "    return {}",
            ]
        )
    )

    with pytest.raises(AttributeError, match="Block 'Fancy Block' not found"):
        _load_block(str(block_path), "Fancy Block")
