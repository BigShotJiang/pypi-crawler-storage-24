import os
import pytest


@pytest.fixture
def db_env(tmp_path, monkeypatch):
    """Point the database to a temp SQLite file."""
    db_path = str(tmp_path / "test.db")
    monkeypatch.setenv("OM_DATABASE_URL", f"sqlite:///{db_path}")
    # Force reload of db module with new env
    import importlib
    import openmailer.db as db_mod
    new_engine = db_mod._get_engine(f"sqlite:///{db_path}")
    monkeypatch.setattr(db_mod, "engine", new_engine)
    monkeypatch.setattr(db_mod, "SessionLocal",
                        db_mod.sessionmaker(bind=new_engine, autoflush=False, autocommit=False))
    db_mod.Base.metadata.create_all(bind=new_engine)
    return db_path


def test_email_log_persistence(db_env):
    import openmailer.db as db_mod
    from openmailer.models import EmailLog

    session = db_mod.SessionLocal()
    log = EmailLog(sender="me@x.com", to="you@x.com", subject="Test", status="sent", backend="smtp.x.com")
    session.add(log)
    session.commit()

    results = session.query(EmailLog).all()
    assert len(results) == 1
    assert results[0].to == "you@x.com"
    assert results[0].status == "sent"
    session.close()


def test_multiple_logs(db_env):
    import openmailer.db as db_mod
    from openmailer.models import EmailLog

    session = db_mod.SessionLocal()
    for i in range(5):
        session.add(EmailLog(sender="s@x.com", to=f"r{i}@x.com", subject=f"Subj {i}", status="sent"))
    session.commit()

    count = session.query(EmailLog).count()
    assert count == 5

    failed = session.query(EmailLog).filter(EmailLog.status == "failed").count()
    assert failed == 0
    session.close()
