"""Tests for new client features: suppression, logs, dead letters, webhooks integration."""
import pytest
from unittest.mock import patch
from openmailer.client import OpenMailerClient


@pytest.fixture
def client(temp_db):
    cfg = {"host": "h", "port": 25, "username": "u", "password": "p", "use_tls": False}
    return OpenMailerClient(config=cfg, dry_run=True, pool=False, persist=True)


def test_suppress_and_check(client):
    client.suppress("block@test.com")
    suppressed = client.get_suppression_list()
    assert any(e["email"] == "block@test.com" for e in suppressed)


def test_unsuppress(client):
    client.suppress("temp@test.com")
    client.unsuppress("temp@test.com")
    suppressed = client.get_suppression_list()
    assert not any(e["email"] == "temp@test.com" for e in suppressed)


def test_suppressed_email_is_blocked(client):
    client.suppress("blocked@test.com")
    result = client.send_email(to="blocked@test.com", subject="Hi", html_body="<p>Hi</p>")
    assert result["status"] == "suppressed"


def test_get_logs_empty(client):
    logs = client.get_logs()
    assert logs == []


def test_get_logs_after_send(client):
    client.send_email(to="log@test.com", subject="Log", html_body="<p>Hi</p>")
    logs = client.get_logs()
    assert len(logs) >= 1
    assert logs[0]["to"] == "log@test.com"


def test_get_logs_filter_status(client):
    client.send_email(to="ok@test.com", subject="OK", html_body="<p>Hi</p>")
    # dry_run saves with status from localmode, not "sent" — check that filter works
    logs_failed = client.get_logs(status="failed")
    logs_all = client.get_logs()
    assert len(logs_failed) <= len(logs_all)


def test_get_pending_count(client):
    assert client.get_pending_count() == 0


def test_get_dead_letters_empty(client):
    assert client.get_dead_letters() == []


def test_get_health_status(client):
    status = client.get_health_status()
    assert isinstance(status, dict)


def test_get_analytics(client):
    metrics = client.get_analytics()
    assert isinstance(metrics, dict)


def test_webhook_fires_on_send(temp_db):
    cfg = {"host": "h", "port": 25, "username": "u", "password": "p", "use_tls": False}
    client = OpenMailerClient(
        config=cfg, dry_run=True, pool=False,
        webhooks={"on_send": "https://example.com/hook"}
    )
    with patch("openmailer.webhooks.requests.post") as mock_post:
        client.send_email(to="wh@test.com", subject="WH", html_body="<p>Hi</p>")
        mock_post.assert_called_once()
        payload = mock_post.call_args[1]["json"]
        assert payload["event"] == "on_send"
        assert payload["to"] == "wh@test.com"


def test_close(client):
    client.close()
    assert client._pools == {}
