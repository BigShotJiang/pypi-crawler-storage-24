import pytest
from openmailer.smtp_pool import SMTPPool, SMTPConnection


class FakeSMTP:
    """Stub for smtplib.SMTP used in pool tests."""

    def __init__(self, host, port):
        self.host = host
        self.port = port
        self.tls = False
        self.logged_in = False
        self.closed = False

    def starttls(self):
        self.tls = True

    def login(self, user, password):
        self.logged_in = True

    def send_message(self, msg):
        pass

    def noop(self):
        if self.closed:
            raise Exception("closed")
        return (250, b"OK")

    def quit(self):
        self.closed = True


@pytest.fixture
def mock_smtp(monkeypatch):
    import smtplib
    monkeypatch.setattr(smtplib, "SMTP", FakeSMTP)


def test_pool_acquire_release(mock_smtp):
    pool = SMTPPool("h", 25, "u", "p", False, max_size=3)
    conn = pool.acquire()
    assert conn is not None
    pool.release(conn)
    # Should reuse the same connection
    conn2 = pool.acquire()
    assert conn2 is conn
    pool.close_all()


def test_pool_send(mock_smtp):
    pool = SMTPPool("h", 25, "u", "p", False)
    result = pool.send(None)
    assert result["status"] == "sent"
    # Connection should be back in the pool
    assert len(pool._pool) == 1
    pool.close_all()
    assert len(pool._pool) == 0


def test_pool_max_size(mock_smtp):
    pool = SMTPPool("h", 25, "u", "p", False, max_size=2)
    c1 = pool.acquire()
    c2 = pool.acquire()
    c3 = pool.acquire()
    pool.release(c1)
    pool.release(c2)
    pool.release(c3)
    # Only max_size=2 should be kept
    assert len(pool._pool) == 2
    pool.close_all()
