import pytest
from datetime import datetime, timedelta
from openmailer.queue_manager import QueueManager
import openmailer.db as db_mod
from openmailer.models import QueueJob


@pytest.fixture
def qm(temp_db):
    return QueueManager(max_retries=3, backoff_factor=1, max_backoff=60)


def test_add_and_pop(qm):
    qm.add({"to": "a@b.com", "subject": "Hi", "template": "<p>Hi</p>"})
    job = qm.pop()
    assert job is not None
    assert job["to"] == "a@b.com"
    assert job["subject"] == "Hi"
    assert job["id"] is not None


def test_pop_empty_returns_none(qm):
    assert qm.pop() is None


def test_mark_sent(qm):
    qm.add({"to": "x@y.com", "subject": "S"})
    job = qm.pop()
    qm.mark_sent(job["id"])

    db = db_mod.SessionLocal()
    row = db.query(QueueJob).filter(QueueJob.id == job["id"]).first()
    assert row.status == "sent"
    db.close()


def test_mark_failed_retries(qm):
    qm.add({"to": "fail@y.com", "subject": "F"})
    job = qm.pop()
    qm.mark_failed(job["id"], Exception("SMTP error"))

    db = db_mod.SessionLocal()
    row = db.query(QueueJob).filter(QueueJob.id == job["id"]).first()
    assert row.status == "retrying"
    assert row.retry_count == 1
    assert row.last_error == "SMTP error"
    assert row.next_retry_at is not None
    db.close()


def test_mark_failed_dead_after_max_retries(qm):
    qm.add({"to": "dead@y.com", "subject": "D"})

    for i in range(3):
        job = qm.pop()
        assert job is not None, f"pop() returned None on attempt {i}"
        qm.mark_failed(job["id"], Exception(f"Error {i}"))
        # Make next_retry_at in the past so pop() picks it up
        db = db_mod.SessionLocal()
        row = db.query(QueueJob).filter(QueueJob.id == job["id"]).first()
        if row and row.next_retry_at:
            row.next_retry_at = datetime.utcnow() - timedelta(seconds=1)
            db.commit()
        db.close()

    db = db_mod.SessionLocal()
    row = db.query(QueueJob).filter(QueueJob.to == "dead@y.com").first()
    assert row.status == "dead"
    assert row.retry_count == 3
    db.close()


def test_get_dead_letters(qm):
    qm.add({"to": "dead2@y.com", "subject": "DL"})

    for i in range(3):
        job = qm.pop()
        qm.mark_failed(job["id"], Exception("fail"))
        db = db_mod.SessionLocal()
        row = db.query(QueueJob).filter(QueueJob.id == job["id"]).first()
        if row and row.next_retry_at:
            row.next_retry_at = datetime.utcnow() - timedelta(seconds=1)
            db.commit()
        db.close()

    dead = qm.get_dead_letters()
    assert len(dead) == 1
    assert dead[0]["to"] == "dead2@y.com"


def test_get_pending_count(qm):
    assert qm.get_pending_count() == 0
    qm.add({"to": "p1@y.com", "subject": "P"})
    qm.add({"to": "p2@y.com", "subject": "P"})
    assert qm.get_pending_count() == 2


def test_clear(qm):
    qm.add({"to": "cl@y.com", "subject": "C"})
    assert qm.get_pending_count() == 1
    qm.clear()
    assert qm.get_pending_count() == 0


def test_load(qm):
    qm.add({"to": "l1@y.com", "subject": "L1"})
    qm.add({"to": "l2@y.com", "subject": "L2"})
    jobs = qm.load()
    assert len(jobs) == 2
    assert {j["to"] for j in jobs} == {"l1@y.com", "l2@y.com"}


def test_context_and_attachments_roundtrip(qm):
    qm.add({
        "to": "ctx@y.com",
        "subject": "Ctx",
        "template": "<p>{{ name }}</p>",
        "context": {"name": "Alice"},
        "attachments": ["/tmp/a.pdf"],
        "priority": "high",
        "track_open": True,
    })
    job = qm.pop()
    assert job["context"] == {"name": "Alice"}
    assert job["attachments"] == ["/tmp/a.pdf"]
    assert job["priority"] == "high"
    assert job["track_open"] is True
