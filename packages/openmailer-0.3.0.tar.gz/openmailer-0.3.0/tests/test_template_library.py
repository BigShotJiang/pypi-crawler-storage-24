import os
import pytest
from openmailer.template_engine import render_template, render_file_template, list_templates


def test_render_inline():
    result = render_template("<p>Hello {{ name }}</p>", {"name": "World"})
    assert "Hello World" in result


def test_render_file_template(tmp_path):
    tpl = tmp_path / "greet.html"
    tpl.write_text("<h1>Hi {{ user }}!</h1>")
    result = render_file_template("greet.html", {"user": "Alice"}, template_dirs=[str(tmp_path)])
    assert "Hi Alice!" in result


def test_render_file_template_missing_dir():
    with pytest.raises(FileNotFoundError):
        render_file_template("nope.html", {}, template_dirs=["/nonexistent_dir_xyz"])


def test_list_templates(tmp_path):
    (tmp_path / "a.html").write_text("")
    (tmp_path / "b.j2").write_text("")
    (tmp_path / "c.txt").write_text("")
    (tmp_path / "readme.md").write_text("")  # should be excluded

    result = list_templates(template_dirs=[str(tmp_path)])
    assert "a.html" in result
    assert "b.j2" in result
    assert "c.txt" in result
    assert "readme.md" not in result


def test_list_templates_nested(tmp_path):
    sub = tmp_path / "invoices"
    sub.mkdir()
    (sub / "receipt.html").write_text("")

    result = list_templates(template_dirs=[str(tmp_path)])
    assert os.path.join("invoices", "receipt.html") in result
