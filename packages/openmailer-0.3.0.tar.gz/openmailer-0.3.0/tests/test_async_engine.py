import pytest
from email.message import EmailMessage
from openmailer.async_engine import async_send_email_smtp, async_send_bulk


@pytest.fixture
def dummy_message():
    msg = EmailMessage()
    msg["From"] = "sender@test.com"
    msg["To"] = "recipient@test.com"
    msg["Subject"] = "Async Test"
    msg.set_content("Hello async")
    return msg


@pytest.mark.asyncio
async def test_async_send_imports_error(dummy_message, monkeypatch):
    """When aiosmtplib is not installed, async_send should raise ImportError."""
    import openmailer.async_engine as ae
    monkeypatch.setattr(ae, "_HAS_AIOSMTPLIB", False)
    with pytest.raises(ImportError, match="aiosmtplib"):
        await async_send_email_smtp("h", 25, "u", "p", False, dummy_message)


@pytest.mark.asyncio
async def test_async_send_success(dummy_message, monkeypatch):
    """When aiosmtplib is available, sends and returns status=sent."""
    import openmailer.async_engine as ae
    monkeypatch.setattr(ae, "_HAS_AIOSMTPLIB", True)

    # Mock aiosmtplib.send
    async def fake_send(*a, **kw):
        pass

    import types
    fake_module = types.ModuleType("aiosmtplib")
    fake_module.send = fake_send
    monkeypatch.setattr(ae, "aiosmtplib", fake_module)

    result = await async_send_email_smtp("h", 25, "u", "p", False, dummy_message)
    assert result["status"] == "sent"
