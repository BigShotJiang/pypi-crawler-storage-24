import pytest
import os
from email.message import EmailMessage
from openmailer.dkim_signer import DKIMSigner


def test_dkim_requires_dkimpy(monkeypatch):
    """DKIMSigner should raise ImportError if dkimpy is not installed."""
    import openmailer.dkim_signer as ds
    monkeypatch.setattr(ds, "_HAS_DKIM", False)
    with pytest.raises(ImportError, match="dkimpy"):
        DKIMSigner(private_key_path="/tmp/k.pem", selector="mail", domain="x.com")


def test_dkim_requires_domain(monkeypatch):
    import openmailer.dkim_signer as ds
    monkeypatch.setattr(ds, "_HAS_DKIM", True)
    monkeypatch.delenv("DKIM_DOMAIN", raising=False)
    with pytest.raises(ValueError, match="domain"):
        DKIMSigner(private_key_path="/tmp/k.pem", selector="mail", domain=None)


def test_dkim_requires_key_file(monkeypatch):
    import openmailer.dkim_signer as ds
    monkeypatch.setattr(ds, "_HAS_DKIM", True)
    with pytest.raises(FileNotFoundError, match="private key"):
        DKIMSigner(private_key_path="/nonexistent/k.pem", selector="mail", domain="x.com")


def test_dkim_sign_with_mock(monkeypatch, tmp_path):
    """Test sign() with a mocked dkim module."""
    import openmailer.dkim_signer as ds
    import types

    # Create a fake key file
    key_file = tmp_path / "test.pem"
    key_file.write_text("FAKE-KEY-DATA")

    # Mock the dkim module
    fake_dkim = types.ModuleType("dkim")
    fake_dkim.sign = lambda msg, sel, dom, key, include_headers=None: b"DKIM-Signature: fake\r\n"
    monkeypatch.setattr(ds, "_HAS_DKIM", True)
    monkeypatch.setattr(ds, "dkim", fake_dkim)

    signer = DKIMSigner(private_key_path=str(key_file), selector="mail", domain="example.com")

    msg = EmailMessage()
    msg["From"] = "sender@example.com"
    msg["To"] = "rcpt@example.com"
    msg["Subject"] = "DKIM Test"
    msg.set_content("Hello")

    signed = signer.sign(msg)
    assert signed.startswith(b"DKIM-Signature: fake\r\n")
