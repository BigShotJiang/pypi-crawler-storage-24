import os
import pytest

@pytest.fixture(scope="session", autouse=True)
def setup_env():
    os.environ["SMTP_HOST"] = "smtp.example.com"
    os.environ["SMTP_PORT"] = "587"
    os.environ["SMTP_USERNAME"] = "test@example.com"
    os.environ["SMTP_PASSWORD"] = "dummy-password"
    os.environ["SMTP_USE_TLS"] = "true"
    os.environ["SMTP_RATE_LIMIT"] = "10"


@pytest.fixture
def temp_db(tmp_path, monkeypatch):
    """Create a fresh SQLite database in a temp directory for each test."""
    db_path = str(tmp_path / "test.db")
    db_url = f"sqlite:///{db_path}"
    monkeypatch.setenv("OM_DATABASE_URL", db_url)

    import openmailer.db as db_mod

    new_engine = db_mod._get_engine(db_url)
    new_session = db_mod.sessionmaker(bind=new_engine, autoflush=False, autocommit=False)
    monkeypatch.setattr(db_mod, "engine", new_engine)
    monkeypatch.setattr(db_mod, "SessionLocal", new_session)

    # Patch SessionLocal in all modules that import it at module level
    import openmailer.queue_manager as qm_mod
    import openmailer.suppression as sup_mod
    import openmailer.client as cli_mod
    monkeypatch.setattr(qm_mod, "SessionLocal", new_session)
    monkeypatch.setattr(sup_mod, "SessionLocal", new_session)
    monkeypatch.setattr(cli_mod, "SessionLocal", new_session)

    db_mod.Base.metadata.create_all(bind=new_engine)

    return db_url
