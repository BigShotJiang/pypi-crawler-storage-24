import pytest
from openmailer.suppression import SuppressionList, classify_bounce


@pytest.fixture
def sl(temp_db):
    return SuppressionList()


def test_suppress_and_check(sl):
    assert not sl.is_suppressed("bad@test.com")
    sl.suppress("bad@test.com", reason="hard_bounce")
    assert sl.is_suppressed("bad@test.com")


def test_suppress_case_insensitive(sl):
    sl.suppress("MiXeD@TeSt.CoM")
    assert sl.is_suppressed("mixed@test.com")
    assert sl.is_suppressed("MIXED@TEST.COM")


def test_suppress_idempotent(sl):
    sl.suppress("dup@test.com")
    sl.suppress("dup@test.com")
    assert sl.count() == 1


def test_unsuppress(sl):
    sl.suppress("remove@test.com")
    assert sl.is_suppressed("remove@test.com")
    sl.unsuppress("remove@test.com")
    assert not sl.is_suppressed("remove@test.com")


def test_list_all(sl):
    sl.suppress("a@test.com", reason="hard_bounce")
    sl.suppress("b@test.com", reason="complaint")
    entries = sl.list_all()
    assert len(entries) == 2
    emails = {e["email"] for e in entries}
    assert emails == {"a@test.com", "b@test.com"}


def test_count(sl):
    assert sl.count() == 0
    sl.suppress("c@test.com")
    assert sl.count() == 1


def test_classify_bounce_hard():
    for code in ["550", "551", "552", "553", "554"]:
        assert classify_bounce(code) == "hard_bounce"


def test_classify_bounce_soft():
    for code in ["421", "450", "451", "452"]:
        assert classify_bounce(code) == "soft_bounce"


def test_classify_bounce_none():
    assert classify_bounce("250") is None
    assert classify_bounce("220") is None
    assert classify_bounce("xxx") is None
