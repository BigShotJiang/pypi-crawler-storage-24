import pytest
import json
from unittest.mock import patch, MagicMock
from openmailer.webhooks import WebhookManager


def test_fire_no_hooks():
    wm = WebhookManager()
    # Should not raise even with no hooks configured
    wm.fire("on_send", {"to": "a@b.com"})


def test_fire_matching_event():
    wm = WebhookManager(hooks={"on_send": "https://example.com/hook"})
    with patch("openmailer.webhooks.requests.post") as mock_post:
        wm.fire("on_send", {"to": "test@x.com", "subject": "Hi"})
        mock_post.assert_called_once()
        call_kwargs = mock_post.call_args
        assert call_kwargs[1]["json"]["event"] == "on_send"
        assert call_kwargs[1]["json"]["to"] == "test@x.com"
        assert "timestamp" in call_kwargs[1]["json"]


def test_fire_non_matching_event():
    wm = WebhookManager(hooks={"on_send": "https://example.com/hook"})
    with patch("openmailer.webhooks.requests.post") as mock_post:
        wm.fire("on_fail", {"to": "test@x.com"})
        mock_post.assert_not_called()


def test_fire_with_custom_headers():
    wm = WebhookManager(
        hooks={"on_bounce": "https://example.com/hook"},
        headers={"Authorization": "Bearer tok123"}
    )
    with patch("openmailer.webhooks.requests.post") as mock_post:
        wm.fire("on_bounce", {"to": "bounce@x.com"})
        call_kwargs = mock_post.call_args
        assert call_kwargs[1]["headers"]["Authorization"] == "Bearer tok123"


def test_fire_exception_is_swallowed():
    wm = WebhookManager(hooks={"on_send": "https://example.com/hook"})
    with patch("openmailer.webhooks.requests.post", side_effect=ConnectionError("down")):
        # Should not raise
        wm.fire("on_send", {"to": "a@b.com"})


def test_fire_custom_timeout():
    wm = WebhookManager(hooks={"on_send": "https://example.com/hook"}, timeout=10)
    with patch("openmailer.webhooks.requests.post") as mock_post:
        wm.fire("on_send", {"to": "a@b.com"})
        call_kwargs = mock_post.call_args
        assert call_kwargs[1]["timeout"] == 10
