from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="openmailer",
    version="0.3.0",
    description="Open-source email automation and delivery engine",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Mohamed Sesay",
    author_email="msesay@dee-empire.com",
    url="https://github.com/Devops-Bot-Official/OpenMailer.git",
    license="MIT",
    packages=find_packages(),
    install_requires=[
        "jinja2",
        "rich",
        "pyyaml",
        "requests",
        "python-dotenv",
        "sqlalchemy",
    ],
    extras_require={
        "vault": ["hvac"],
        "aws": ["boto3"],
        "azure": ["azure-identity", "azure-keyvault-secrets"],
        "dkim": ["dkimpy"],
        "async": ["aiosmtplib"],
        "all": ["dkimpy", "aiosmtplib"],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent"
    ],
    python_requires=">=3.7",
)

