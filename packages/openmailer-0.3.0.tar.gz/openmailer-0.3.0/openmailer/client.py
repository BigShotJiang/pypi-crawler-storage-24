import re
import os
import time
from jinja2 import meta, Environment
from typing import Optional, Dict
from email.message import EmailMessage

from openmailer.smtp_engine import send_email_smtp
from openmailer.message_builder import build_email_message
from openmailer.template_engine import render_template, render_file_template
from openmailer.localmode import handle_local_send
from openmailer.queue_manager import QueueManager
from openmailer.logger import log_event
from openmailer.rate_limiter import RateLimiter
from openmailer.secrets import get_smtp_config
from openmailer.health_monitor import HealthMonitor
from openmailer.analytics import Analytics
from openmailer.smtp_pool import SMTPPool
from openmailer.db import SessionLocal, init_db
from openmailer.models import EmailLog
from openmailer.suppression import SuppressionList, classify_bounce
from openmailer.webhooks import WebhookManager

EMAIL_REGEX = r"^[\w\.-]+@[\w\.-]+\.\w+$"
MAX_ATTACHMENT_MB = 10

##  main
class OpenMailerClient:
    def __init__(self, config=None, dry_run=False, pool=True, persist=True,
                 webhooks=None, webhook_headers=None, dkim=None):
        self.dry_run = dry_run
        self.queue = QueueManager()
        self.health = HealthMonitor()
        self.analytics = Analytics()
        self.suppression = SuppressionList()
        self.webhooks = WebhookManager(hooks=webhooks, headers=webhook_headers)
        self.use_pool = pool and not dry_run
        self.persist = persist
        self._dkim_signer = None

        if config is None:
            config = get_smtp_config()

        if isinstance(config, dict):
            self.backends = [config]
        elif isinstance(config, list):
            self.backends = config
        else:
            raise ValueError("Invalid config format")

        self.limiters = {
            b["host"]: RateLimiter(b.get("rate_limit", 20))
            for b in self.backends
        }

        # Build connection pools per backend
        self._pools = {}
        if self.use_pool:
            for b in self.backends:
                self._pools[b["host"]] = SMTPPool(
                    host=b["host"], port=b["port"],
                    username=b["username"], password=b["password"],
                    use_tls=b["use_tls"]
                )

        # Initialize database tables
        if self.persist:
            try:
                init_db()
            except Exception:
                self.persist = False

        # DKIM signer (optional)
        if dkim:
            from openmailer.dkim_signer import DKIMSigner
            self._dkim_signer = DKIMSigner(**dkim)

    def _log_to_db(self, sender, to, subject, status, backend=None, error=None):
        if not self.persist:
            return
        try:
            db = SessionLocal()
            entry = EmailLog(
                sender=sender, to=to, subject=subject,
                status=status, backend=backend, error=error
            )
            db.add(entry)
            db.commit()
            db.close()
        except Exception:
            pass

    def _validate_email(self, email: str):
        if not re.match(EMAIL_REGEX, email):
            raise ValueError(f"Invalid email address: {email}")

    def _validate_attachments(self, attachments):
        for file in attachments or []:
            if not os.path.isfile(file):
                raise FileNotFoundError(f"Attachment not found: {file}")
            if os.path.getsize(file) > MAX_ATTACHMENT_MB * 1024 * 1024:
                raise ValueError(f"Attachment too large: {file} exceeds {MAX_ATTACHMENT_MB}MB")

    def _validate_template_vars(self, template_str, context):
        env = Environment()
        parsed = env.parse(template_str)
        required_vars = meta.find_undeclared_variables(parsed)
        missing = required_vars - set(context or {})
        if missing:
            print(f"⚠️ Warning: Missing template variables: {', '.join(missing)}")

    def send_email(
        self,
        to,
        subject,
        html_body=None,
        template_name=None,
        context=None,
        attachments=None,
        report_mode=False,
        schedule=None,
        priority="normal",
        track_open=False,
        headers: Optional[Dict[str, str]] = None
    ):
        self._validate_email(to)
        self._validate_attachments(attachments)

        # Check suppression list
        if self.suppression.is_suppressed(to):
            log_event(to, "suppressed", self.backends[0]["host"])
            if report_mode:
                return {"success": [], "failed": [{"to": to, "error": "suppressed"}]}
            return {"status": "suppressed", "to": to}

        if template_name and not html_body:
            body = render_file_template(template_name, context or {})
        elif html_body:
            self._validate_template_vars(html_body, context)
            body = render_template(html_body, context or {})
        else:
            raise ValueError("Provide either html_body or template_name")

        if track_open:
            tracking_pixel = f'<img src="https://yourdomain.com/track/open/{to}" width="1" height="1" style="display:none">'
            body += tracking_pixel

        if schedule:
            self.queue.add({
                "to": to,
                "subject": subject,
                "template": html_body,
                "context": context,
                "attachments": attachments,
                "priority": priority,
                "track_open": track_open,
                "schedule": schedule
            })
            log_event(to, "scheduled", self.backends[0]["host"])
            return {"status": "scheduled", "to": to}

        # Build the From address with display name if configured
        backend = self.backends[0]
        from_email = backend.get("from_email") or backend["username"]
        from_name = backend.get("from_name")
        from_addr = f"{from_name} <{from_email}>" if from_name else from_email

        message = build_email_message(
            from_email=from_addr,
            to_email=to,
            subject=subject,
            html_body=body,
            attachments=attachments,
            headers=headers
        )

        last_error = "No backends configured"
        for backend in self.backends:
            try:
                if self.dry_run:
                    log_event(to, "dry-run", backend["host"])
                    self._log_to_db(from_addr, to, subject, "sent", backend["host"])
                    self.webhooks.fire("on_send", {
                        "to": to, "subject": subject, "backend": backend["host"]
                    })
                    if report_mode:
                        return {"success": [{"to": to}], "failed": []}
                    return handle_local_send(message, to)

                self.limiters[backend["host"]].wait()

                if self.use_pool and backend["host"] in self._pools:
                    result = self._pools[backend["host"]].send(message)
                else:
                    result = send_email_smtp(
                        smtp_host=backend["host"],
                        smtp_port=backend["port"],
                        username=backend["username"],
                        password=backend["password"],
                        use_tls=backend["use_tls"],
                        message=message
                    )

                self.health.record_success(backend["host"])
                self.analytics.record("sent", backend["host"])
                log_event(to, "sent", backend["host"])
                self._log_to_db(from_addr, to, subject, "sent", backend["host"])
                self.webhooks.fire("on_send", {
                    "to": to, "subject": subject, "backend": backend["host"]
                })

                if report_mode:
                    return {"success": [{"to": to}], "failed": []}
                return result

            except Exception as e:
                err_str = str(e)
                self.health.record_failure(backend["host"], e)
                self.analytics.record("failed", backend["host"])
                log_event(to, "failed", f"{backend['host']}: {err_str}")
                self._log_to_db(from_addr, to, subject, "failed", backend["host"], err_str)
                self.webhooks.fire("on_fail", {
                    "to": to, "subject": subject, "backend": backend["host"],
                    "error": err_str
                })

                # Auto-suppress on hard bounce
                bounce_type = classify_bounce(err_str[:3])
                if bounce_type == "hard_bounce":
                    self.suppression.suppress(to, reason="hard_bounce")
                    self.webhooks.fire("on_bounce", {
                        "to": to, "bounce_type": "hard_bounce",
                        "backend": backend["host"]
                    })

                last_error = err_str

        self.queue.add({
            "to": to,
            "subject": subject,
            "template": html_body,
            "context": context,
            "attachments": attachments,
            "priority": priority,
            "track_open": track_open
        })

        if report_mode:
            return {"success": [], "failed": [{"to": to, "error": last_error}]}
        raise Exception(f"❌ All backends failed to send email to {to}: {last_error}")

    def send_bulk(self, recipients, subject, html_body, context_fn=None, attachments=None):
        report = {
            "status": "pending",
            "success": [],
            "failed": []
        }

        for to in recipients:
            try:
                context = context_fn(to) if context_fn else {}
                result = self.send_email(
                    to=to,
                    subject=subject,
                    html_body=html_body,
                    context=context,
                    attachments=attachments,
                    report_mode=True
                )
                report["success"].extend(result["success"])
                report["failed"].extend(result["failed"])
            except Exception as e:
                report["failed"].append({"to": to, "error": str(e)})

        if report["success"] and not report["failed"]:
            report["status"] = "success"
        elif report["failed"] and not report["success"]:
            report["status"] = "failed"
        else:
            report["status"] = "partial"

        return report

    def feedback_to_sender(self, sender_email, report, subject="OpenMailer Delivery Report"):
        success_count = len(report["success"])
        failed_count = len(report["failed"])
        error_list = "".join(
            f"<li>{item['to']}: {item.get('error', 'Unknown error')}</li>"
            for item in report["failed"]
        )

        html = f"""
        <html>
        <body>
          <h2>Delivery Report: {report['status'].upper()}</h2>
          <p><strong>Success:</strong> {success_count}</p>
          <p><strong>Failed:</strong> {failed_count}</p>
          <ul>{error_list}</ul>
        </body>
        </html>
        """

        self.send_email(
            to=sender_email,
            subject=subject,
            html_body=html
        )

    def retry_all(self):
        """Process pending jobs from the queue with exponential backoff."""
        while True:
            job = self.queue.pop()
            if not job:
                break
            try:
                self.send_email(
                    to=job["to"],
                    subject=job["subject"],
                    html_body=job["template"],
                    context=job.get("context"),
                    attachments=job.get("attachments"),
                    track_open=job.get("track_open", False)
                )
                self.queue.mark_sent(job["id"])
                self.analytics.record("retry", self.backends[0]["host"])
            except Exception as e:
                self.queue.mark_failed(job["id"], e)
                log_event(job["to"], "retry-failed", self.backends[0]["host"])
                self.analytics.record("retry-failed", self.backends[0]["host"])

    def get_dead_letters(self):
        """Return all jobs that exceeded max retries."""
        return self.queue.get_dead_letters()

    def get_pending_count(self):
        """Return count of pending/retrying jobs in queue."""
        return self.queue.get_pending_count()

    def suppress(self, email, reason="manual"):
        """Add an email to the suppression list."""
        self.suppression.suppress(email, reason)

    def unsuppress(self, email):
        """Remove an email from the suppression list."""
        self.suppression.unsuppress(email)

    def get_suppression_list(self):
        """Return all suppressed emails."""
        return self.suppression.list_all()

    def get_logs(self, limit=50, status=None):
        """Query email send logs from the database."""
        if not self.persist:
            return []
        db = SessionLocal()
        try:
            query = db.query(EmailLog).order_by(EmailLog.sent_at.desc())
            if status:
                query = query.filter(EmailLog.status == status)
            rows = query.limit(limit).all()
            return [
                {"id": r.id, "sender": r.sender, "to": r.to,
                 "subject": r.subject, "status": r.status,
                 "backend": r.backend, "error": r.error,
                 "sent_at": r.sent_at.isoformat() if r.sent_at else None}
                for r in rows
            ]
        finally:
            db.close()

    def get_health_status(self):
        return self.health.get_health()

    def get_analytics(self):
        return self.analytics.get_metrics()

    def close(self):
        """Close all SMTP connection pools."""
        for pool in self._pools.values():
            pool.close_all()
        self._pools.clear()




