# openmailer/suppression.py
from openmailer.db import SessionLocal, init_db
from openmailer.models import SuppressedEmail


class SuppressionList:
    """Manages a list of suppressed email addresses (bounces, complaints)."""

    def __init__(self):
        try:
            init_db()
        except Exception:
            pass

    def is_suppressed(self, email):
        db = SessionLocal()
        try:
            return db.query(SuppressedEmail).filter(
                SuppressedEmail.email == email.lower()
            ).first() is not None
        finally:
            db.close()

    def suppress(self, email, reason="hard_bounce"):
        db = SessionLocal()
        try:
            existing = db.query(SuppressedEmail).filter(
                SuppressedEmail.email == email.lower()
            ).first()
            if not existing:
                entry = SuppressedEmail(email=email.lower(), reason=reason)
                db.add(entry)
                db.commit()
        finally:
            db.close()

    def unsuppress(self, email):
        db = SessionLocal()
        try:
            db.query(SuppressedEmail).filter(
                SuppressedEmail.email == email.lower()
            ).delete(synchronize_session=False)
            db.commit()
        finally:
            db.close()

    def list_all(self):
        db = SessionLocal()
        try:
            entries = db.query(SuppressedEmail).all()
            return [
                {"email": e.email, "reason": e.reason,
                 "created_at": e.created_at.isoformat() if e.created_at else None}
                for e in entries
            ]
        finally:
            db.close()

    def count(self):
        db = SessionLocal()
        try:
            return db.query(SuppressedEmail).count()
        finally:
            db.close()


# SMTP bounce code classification
HARD_BOUNCE_CODES = {"550", "551", "552", "553", "554"}
SOFT_BOUNCE_CODES = {"421", "450", "451", "452"}


def classify_bounce(smtp_code):
    """Classify an SMTP response code as hard_bounce, soft_bounce, or None."""
    code = str(smtp_code)[:3]
    if code in HARD_BOUNCE_CODES:
        return "hard_bounce"
    if code in SOFT_BOUNCE_CODES:
        return "soft_bounce"
    return None
