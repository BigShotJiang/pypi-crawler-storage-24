# openmailer/template_engine.py
import os
from jinja2 import Template, Environment, FileSystemLoader, TemplateNotFound

# Default template directory: ~/.openmailer/templates/
_default_template_dir = os.path.join(os.path.expanduser("~"), ".openmailer", "templates")


def render_template(template_str, context):
    """Render an inline template string with the given context."""
    return Template(template_str).render(**context)


def render_file_template(name, context, template_dirs=None):
    """Load a template by filename from the template directory and render it.

    Searches ``template_dirs`` in order (defaults to ``~/.openmailer/templates/``).
    Supports Jinja2 template inheritance ({% extends %}, {% block %}).

    Args:
        name: Template filename, e.g. ``"welcome.html"`` or ``"invoices/receipt.html"``.
        context: Dict of variables to inject.
        template_dirs: Optional list of directories to search.

    Returns:
        Rendered HTML string.
    """
    dirs = template_dirs or [_default_template_dir]
    dirs = [d for d in dirs if os.path.isdir(d)]

    if not dirs:
        raise FileNotFoundError(
            f"No template directories found. Create {_default_template_dir} "
            "or pass template_dirs=[]."
        )

    env = Environment(loader=FileSystemLoader(dirs))
    template = env.get_template(name)
    return template.render(**context)


def list_templates(template_dirs=None):
    """Return a list of available template filenames."""
    dirs = template_dirs or [_default_template_dir]
    templates = []
    for d in dirs:
        if not os.path.isdir(d):
            continue
        for root, _, files in os.walk(d):
            for f in files:
                if f.endswith((".html", ".jinja2", ".j2", ".txt")):
                    relpath = os.path.relpath(os.path.join(root, f), d)
                    templates.append(relpath)
    return sorted(templates)