from sqlalchemy import Column, String, Boolean, DateTime, Integer, Text, Float
from datetime import datetime
import uuid

from openmailer.base import Base


def generate_uuid():
    return str(uuid.uuid4())


class ApiKey(Base):
    __tablename__ = "api_keys"

    id = Column(String, primary_key=True, default=generate_uuid)
    key = Column(String, unique=True, index=True, nullable=False)
    label = Column(String, nullable=True)
    permissions = Column(String, default="send:email")
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    expires_at = Column(DateTime, nullable=True)


class EmailLog(Base):
    __tablename__ = "email_logs"

    id = Column(String, primary_key=True, default=generate_uuid)
    sender = Column(String, nullable=True)
    to = Column(String, nullable=False)
    subject = Column(String, nullable=True)
    status = Column(String, default="sent")
    backend = Column(String, nullable=True)
    error = Column(Text, nullable=True)
    sent_at = Column(DateTime, default=datetime.utcnow)


class QueueJob(Base):
    __tablename__ = "queue_jobs"

    id = Column(String, primary_key=True, default=generate_uuid)
    to = Column(String, nullable=False)
    subject = Column(String, nullable=True)
    template = Column(Text, nullable=True)
    context_json = Column(Text, nullable=True)
    attachments_json = Column(Text, nullable=True)
    priority = Column(String, default="normal")
    track_open = Column(Boolean, default=False)
    status = Column(String, default="pending", index=True)
    retry_count = Column(Integer, default=0)
    max_retries = Column(Integer, default=5)
    next_retry_at = Column(DateTime, nullable=True)
    last_error = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class SuppressedEmail(Base):
    __tablename__ = "suppressed_emails"

    id = Column(String, primary_key=True, default=generate_uuid)
    email = Column(String, unique=True, index=True, nullable=False)
    reason = Column(String, default="hard_bounce")
    created_at = Column(DateTime, default=datetime.utcnow)


class SMTPCredential(Base):
    __tablename__ = "smtp_credentials"

    id = Column(String, primary_key=True, default=generate_uuid)
    label = Column(String, nullable=True)
    host = Column(String, nullable=False)
    port = Column(Integer, default=587)
    username = Column(String, nullable=False, unique=True)
    password = Column(String, nullable=False)
    use_tls = Column(Boolean, default=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)