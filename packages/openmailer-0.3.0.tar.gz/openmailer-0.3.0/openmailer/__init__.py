# Core OpenMailer package init

__version__ = "0.3.0"

from openmailer.client import OpenMailerClient
from openmailer.suppression import SuppressionList
from openmailer.webhooks import WebhookManager