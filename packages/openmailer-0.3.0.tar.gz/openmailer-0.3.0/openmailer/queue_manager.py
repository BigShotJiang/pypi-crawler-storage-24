import json
from datetime import datetime, timedelta
import random

from openmailer.db import SessionLocal, init_db
from openmailer.models import QueueJob


class QueueManager:
    """SQLite-backed thread-safe email queue with exponential backoff."""

    def __init__(self, max_retries=5, backoff_factor=2, max_backoff=3600):
        self.max_retries = max_retries
        self.backoff_factor = backoff_factor
        self.max_backoff = max_backoff
        try:
            init_db()
        except Exception:
            pass

    def add(self, job):
        db = SessionLocal()
        try:
            entry = QueueJob(
                to=job["to"],
                subject=job.get("subject"),
                template=job.get("template"),
                context_json=json.dumps(job.get("context")) if job.get("context") else None,
                attachments_json=json.dumps(job.get("attachments")) if job.get("attachments") else None,
                priority=job.get("priority", "normal"),
                track_open=job.get("track_open", False),
                max_retries=self.max_retries,
            )
            db.add(entry)
            db.commit()
        finally:
            db.close()

    def pop(self):
        """Get the next pending job that is ready for retry."""
        db = SessionLocal()
        try:
            now = datetime.utcnow()
            job = (
                db.query(QueueJob)
                .filter(QueueJob.status.in_(["pending", "retrying"]))
                .filter(
                    (QueueJob.next_retry_at == None) | (QueueJob.next_retry_at <= now)
                )
                .order_by(QueueJob.created_at)
                .first()
            )
            if not job:
                return None

            job.status = "processing"
            db.commit()

            result = {
                "id": job.id,
                "to": job.to,
                "subject": job.subject,
                "template": job.template,
                "context": json.loads(job.context_json) if job.context_json else None,
                "attachments": json.loads(job.attachments_json) if job.attachments_json else None,
                "priority": job.priority,
                "track_open": job.track_open,
                "retry_count": job.retry_count,
            }
            return result
        finally:
            db.close()

    def mark_sent(self, job_id):
        db = SessionLocal()
        try:
            job = db.query(QueueJob).filter(QueueJob.id == job_id).first()
            if job:
                job.status = "sent"
                job.updated_at = datetime.utcnow()
                db.commit()
        finally:
            db.close()

    def mark_failed(self, job_id, error):
        """Mark a job as failed and schedule retry with exponential backoff."""
        db = SessionLocal()
        try:
            job = db.query(QueueJob).filter(QueueJob.id == job_id).first()
            if not job:
                return

            job.retry_count += 1
            job.last_error = str(error)
            job.updated_at = datetime.utcnow()

            if job.retry_count >= job.max_retries:
                job.status = "dead"
            else:
                job.status = "retrying"
                delay = min(
                    self.backoff_factor * (2 ** job.retry_count) + random.uniform(0, 1),
                    self.max_backoff
                )
                job.next_retry_at = datetime.utcnow() + timedelta(seconds=delay)

            db.commit()
        finally:
            db.close()

    def get_pending_count(self):
        db = SessionLocal()
        try:
            return db.query(QueueJob).filter(
                QueueJob.status.in_(["pending", "retrying"])
            ).count()
        finally:
            db.close()

    def get_dead_letters(self):
        db = SessionLocal()
        try:
            jobs = db.query(QueueJob).filter(QueueJob.status == "dead").all()
            return [
                {"id": j.id, "to": j.to, "subject": j.subject,
                 "error": j.last_error, "retries": j.retry_count}
                for j in jobs
            ]
        finally:
            db.close()

    def clear(self):
        db = SessionLocal()
        try:
            db.query(QueueJob).filter(
                QueueJob.status.in_(["pending", "retrying", "processing"])
            ).delete(synchronize_session=False)
            db.commit()
        finally:
            db.close()

    def load(self):
        """Return all pending/retrying jobs as dicts (for backward compat)."""
        db = SessionLocal()
        try:
            jobs = db.query(QueueJob).filter(
                QueueJob.status.in_(["pending", "retrying"])
            ).all()
            return [
                {"to": j.to, "subject": j.subject, "template": j.template,
                 "priority": j.priority, "status": j.status}
                for j in jobs
            ]
        finally:
            db.close()
