# openmailer/webhooks.py
import requests
import time
from typing import Optional, Dict


class WebhookManager:
    """Fire HTTP webhook callbacks on email events.

    Args:
        hooks: Dict mapping event names to URLs, e.g.::

            {
                "on_send": "https://example.com/hooks/email-sent",
                "on_fail": "https://example.com/hooks/email-failed",
                "on_bounce": "https://example.com/hooks/email-bounced",
            }

        headers: Optional dict of extra HTTP headers (e.g. auth tokens).
        timeout: Request timeout in seconds (default 5).
    """

    def __init__(self, hooks=None, headers=None, timeout=5):
        self.hooks = hooks or {}
        self.headers = headers or {}
        self.timeout = timeout

    def fire(self, event, payload):
        """Fire a webhook for the given event.

        Args:
            event: One of ``"on_send"``, ``"on_fail"``, ``"on_bounce"``.
            payload: Dict with event data (to, subject, backend, error, etc.).
        """
        url = self.hooks.get(event)
        if not url:
            return

        data = {
            "event": event,
            "timestamp": time.time(),
            **payload,
        }

        try:
            requests.post(url, json=data, headers=self.headers,
                          timeout=self.timeout)
        except Exception:
            pass  # Webhooks are fire-and-forget
