# openmailer/db.py
import os
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker
from openmailer.base import Base

# Default SQLite database path: ~/.openmailer/openmailer.db
_default_db_dir = os.path.join(os.path.expanduser("~"), ".openmailer")
_default_db_path = os.path.join(_default_db_dir, "openmailer.db")

DATABASE_URL = os.getenv("OM_DATABASE_URL", f"sqlite:///{_default_db_path}")


def _get_engine(url=None):
    url = url or DATABASE_URL

    # Ensure directory exists for SQLite
    if url.startswith("sqlite"):
        db_path = url.replace("sqlite:///", "")
        if db_path and db_path != ":memory:":
            os.makedirs(os.path.dirname(db_path) or ".", exist_ok=True)

    engine = create_engine(url, echo=False)

    # Enable WAL mode and foreign keys for SQLite
    if url.startswith("sqlite"):
        @event.listens_for(engine, "connect")
        def _set_sqlite_pragma(dbapi_conn, connection_record):
            cursor = dbapi_conn.cursor()
            cursor.execute("PRAGMA journal_mode=WAL")
            cursor.execute("PRAGMA foreign_keys=ON")
            cursor.close()

    return engine


engine = _get_engine()
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


def init_db():
    """Create all tables if they don't exist."""
    Base.metadata.create_all(bind=engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

