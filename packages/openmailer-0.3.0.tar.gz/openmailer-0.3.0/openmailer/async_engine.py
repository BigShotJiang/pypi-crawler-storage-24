# openmailer/async_engine.py
import asyncio

_HAS_AIOSMTPLIB = False
aiosmtplib = None
try:
    import aiosmtplib
    _HAS_AIOSMTPLIB = True
except ImportError:
    pass


async def async_send_email_smtp(smtp_host, smtp_port, username, password,
                                 use_tls, message):
    """Send an email asynchronously via aiosmtplib.

    Requires ``aiosmtplib``: ``pip install openmailer[async]``
    """
    if not _HAS_AIOSMTPLIB:
        raise ImportError(
            "aiosmtplib is required for async sending. "
            "Install it with: pip install openmailer[async]"
        )

    await aiosmtplib.send(
        message,
        hostname=smtp_host,
        port=smtp_port,
        username=username,
        password=password,
        start_tls=use_tls,
    )
    return {"status": "sent"}


async def async_send_bulk(client, recipients, subject, html_body,
                           context_fn=None, attachments=None,
                           concurrency=10):
    """Send bulk emails with async concurrency.

    Args:
        client: An ``OpenMailerClient`` instance (used for config/validation).
        recipients: List of email addresses.
        subject: Email subject.
        html_body: HTML template string.
        context_fn: Optional callable ``(email) -> dict`` for per-recipient context.
        attachments: Optional list of file paths.
        concurrency: Max parallel sends (default 10).

    Returns:
        Report dict with ``success``, ``failed``, and ``status`` keys.
    """
    from openmailer.template_engine import render_template
    from openmailer.message_builder import build_email_message

    semaphore = asyncio.Semaphore(concurrency)
    report = {"success": [], "failed": []}

    backend = client.backends[0]
    from_email = backend.get("from_email") or backend["username"]
    from_name = backend.get("from_name")
    from_addr = f"{from_name} <{from_email}>" if from_name else from_email

    async def _send_one(to):
        async with semaphore:
            try:
                context = context_fn(to) if context_fn else {}
                body = render_template(html_body, context)
                message = build_email_message(
                    from_email=from_addr, to_email=to,
                    subject=subject, html_body=body,
                    attachments=attachments
                )

                for be in client.backends:
                    try:
                        await async_send_email_smtp(
                            smtp_host=be["host"], smtp_port=be["port"],
                            username=be["username"], password=be["password"],
                            use_tls=be["use_tls"], message=message
                        )
                        report["success"].append({"to": to})
                        return
                    except Exception:
                        continue

                report["failed"].append({"to": to, "error": "All backends failed"})
            except Exception as e:
                report["failed"].append({"to": to, "error": str(e)})

    await asyncio.gather(*[_send_one(to) for to in recipients])

    if report["success"] and not report["failed"]:
        report["status"] = "success"
    elif report["failed"] and not report["success"]:
        report["status"] = "failed"
    else:
        report["status"] = "partial"

    return report
