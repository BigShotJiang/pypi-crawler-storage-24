# openmailer/dkim_signer.py
import os

_HAS_DKIM = False
dkim = None
try:
    import dkim
    _HAS_DKIM = True
except ImportError:
    pass


class DKIMSigner:
    """Signs outgoing emails with DKIM headers.

    Requires the ``dkimpy`` package: ``pip install openmailer[dkim]``

    Args:
        private_key_path: Path to the PEM private key file.
        selector: DKIM selector (e.g. ``"mail"``).
        domain: Signing domain (e.g. ``"example.com"``).
    """

    def __init__(self, private_key_path=None, selector=None, domain=None):
        if not _HAS_DKIM:
            raise ImportError(
                "dkimpy is required for DKIM signing. "
                "Install it with: pip install openmailer[dkim]"
            )

        self.selector = selector or os.getenv("DKIM_SELECTOR", "mail")
        self.domain = domain or os.getenv("DKIM_DOMAIN")
        key_path = private_key_path or os.getenv("DKIM_PRIVATE_KEY_PATH")

        if not self.domain:
            raise ValueError("DKIM domain is required (set DKIM_DOMAIN or pass domain=)")
        if not key_path or not os.path.isfile(key_path):
            raise FileNotFoundError(
                f"DKIM private key not found: {key_path}. "
                "Generate one with: openssl genrsa -out dkim_private.pem 2048"
            )

        with open(key_path, "rb") as f:
            self.private_key = f.read()

    def sign(self, message):
        """Sign an EmailMessage and return the bytes with DKIM-Signature header.

        Args:
            message: An ``email.message.EmailMessage`` instance.

        Returns:
            Signed message as bytes.
        """
        msg_bytes = message.as_bytes()
        sig = dkim.sign(
            msg_bytes,
            self.selector.encode(),
            self.domain.encode(),
            self.private_key,
            include_headers=[
                b"From", b"To", b"Subject", b"Date",
                b"MIME-Version", b"Content-Type",
            ],
        )
        return sig + msg_bytes
