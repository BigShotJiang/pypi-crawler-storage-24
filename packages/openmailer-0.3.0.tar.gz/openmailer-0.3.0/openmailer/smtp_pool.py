# openmailer/smtp_pool.py
import smtplib
import threading
import time


class SMTPConnection:
    """Wraps a single SMTP connection with metadata."""

    def __init__(self, host, port, username, password, use_tls):
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.use_tls = use_tls
        self._conn = None
        self.created_at = time.monotonic()

    def connect(self):
        self._conn = smtplib.SMTP(self.host, self.port)
        if self.use_tls:
            self._conn.starttls()
        self._conn.login(self.username, self.password)
        return self

    def send_message(self, message):
        self._conn.send_message(message)

    def is_alive(self):
        try:
            status = self._conn.noop()
            return status[0] == 250
        except Exception:
            return False

    def close(self):
        try:
            self._conn.quit()
        except Exception:
            pass


class SMTPPool:
    """Reusable SMTP connection pool for a single backend.

    Maintains up to ``max_size`` idle connections. Connections older than
    ``max_age`` seconds are discarded and replaced.
    """

    def __init__(self, host, port, username, password, use_tls,
                 max_size=5, max_age=300):
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.use_tls = use_tls
        self.max_size = max_size
        self.max_age = max_age

        self._pool = []
        self._lock = threading.Lock()

    def _make_conn(self):
        return SMTPConnection(
            self.host, self.port, self.username,
            self.password, self.use_tls
        ).connect()

    def acquire(self):
        """Get a live SMTP connection (from pool or newly created)."""
        with self._lock:
            while self._pool:
                conn = self._pool.pop()
                age = time.monotonic() - conn.created_at
                if age < self.max_age and conn.is_alive():
                    return conn
                conn.close()
        return self._make_conn()

    def release(self, conn):
        """Return a connection to the pool for reuse."""
        with self._lock:
            age = time.monotonic() - conn.created_at
            if len(self._pool) < self.max_size and age < self.max_age:
                self._pool.append(conn)
            else:
                conn.close()

    def send(self, message):
        """Acquire a connection, send, and release it back."""
        conn = self.acquire()
        try:
            conn.send_message(message)
            self.release(conn)
            return {"status": "sent"}
        except Exception:
            conn.close()
            raise

    def close_all(self):
        """Close all idle connections in the pool."""
        with self._lock:
            for conn in self._pool:
                conn.close()
            self._pool.clear()
