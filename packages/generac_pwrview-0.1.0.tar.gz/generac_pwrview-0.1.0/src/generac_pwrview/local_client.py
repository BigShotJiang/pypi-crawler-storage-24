"""Async local client for Generac PWRview / Neurio devices."""

from __future__ import annotations

from typing import Any

import aiohttp

from .exceptions import PWRviewConnectionError, PWRviewResponseError
from .models import LocalChannel, LocalSample, parse_timestamp


def _parse_local_sample(data: dict[str, Any]) -> LocalSample:
    """Parse the local /current-sample response into a LocalSample model."""
    channels: list[LocalChannel] = []
    for ch in data.get("channels", []):
        channels.append(
            LocalChannel(
                channel_type=ch.get("type", ""),
                power=ch.get("p_W"),
                energy_imported=ch.get("eImp_Ws"),
                energy_exported=ch.get("eExp_Ws"),
                voltage=ch.get("v_V"),
            )
        )
    return LocalSample(
        timestamp=parse_timestamp(data.get("timestamp")),
        channels=channels,
    )


class PWRviewLocalClient:
    """Async client for local Generac PWRview / Neurio device access.

    No authentication required — connects directly to the device on the LAN.

    Usage:
        # Standalone — client manages its own session
        async with PWRviewLocalClient(host="192.168.1.100") as client:
            sample = await client.get_current_sample()

        # With injected session (e.g. Home Assistant)
        client = PWRviewLocalClient(host="192.168.1.100", session=session)
        sample = await client.get_current_sample()
    """

    def __init__(
        self,
        host: str,
        session: aiohttp.ClientSession | None = None,
    ) -> None:
        self._host = host
        self._session = session
        self._owns_session = session is None

    async def __aenter__(self) -> PWRviewLocalClient:
        if self._owns_session:
            self._session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, *args: object) -> None:
        if self._owns_session and self._session:
            await self._session.close()
            self._session = None

    def _get_session(self) -> aiohttp.ClientSession:
        """Return the active session, creating one if needed."""
        if self._session is None:
            self._session = aiohttp.ClientSession()
            self._owns_session = True
        return self._session

    async def get_current_sample(self) -> LocalSample:
        """Get the current power/energy sample from the local device."""
        session = self._get_session()
        url = f"http://{self._host}/current-sample"

        try:
            async with session.get(url) as resp:
                if resp.status != 200:
                    text = await resp.text()
                    raise PWRviewResponseError(
                        f"Local device returned status {resp.status}: {text}"
                    )
                data = await resp.json()
                return _parse_local_sample(data)
        except aiohttp.ClientError as err:
            raise PWRviewConnectionError(
                f"Cannot connect to local device at {self._host}: {err}"
            ) from err
