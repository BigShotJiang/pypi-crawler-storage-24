"""Response models for the Generac PWRview API."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime


def parse_timestamp(value: str | None) -> datetime | None:
    """Parse an ISO 8601 timestamp string to a datetime object."""
    if value is None:
        return None
    return datetime.fromisoformat(value)


@dataclass(frozen=True, slots=True)
class SensorInfo:
    """A sensor discovered via the cloud API."""

    sensor_id: str
    serial_number: str
    ip_address: str | None


@dataclass(frozen=True, slots=True)
class LocationInfo:
    """A location containing one or more sensors."""

    name: str
    sensors: list[SensorInfo]


@dataclass(frozen=True, slots=True)
class UserInfo:
    """User account information with associated locations."""

    locations: list[LocationInfo]


@dataclass(frozen=True, slots=True)
class LiveSample:
    """A single live power/energy reading from the cloud API."""

    timestamp: datetime | None
    consumption_power: int | None  # W
    generation_power: int | None  # W
    net_power: int | None  # W
    consumption_energy: int | None  # Ws
    generation_energy: int | None  # Ws
    net_energy: int | None  # Ws


@dataclass(frozen=True, slots=True)
class Stats:
    """Aggregated energy statistics for a time period."""

    start: datetime | None
    end: datetime | None
    consumption_energy: int | None  # Ws
    generation_energy: int | None  # Ws
    imported_energy: int | None  # Ws
    exported_energy: int | None  # Ws


@dataclass(frozen=True, slots=True)
class ChannelSample:
    """Per-channel data from a full sample."""

    channel_type: str
    power: int | None  # W
    reactive_power: int | None  # VAR
    voltage: float | None  # V
    energy_imported: int | None  # Ws
    energy_exported: int | None  # Ws


@dataclass(frozen=True, slots=True)
class Sample:
    """A full sample with per-channel breakdowns."""

    timestamp: datetime | None
    channel_samples: list[ChannelSample]


@dataclass(frozen=True, slots=True)
class LocalChannel:
    """Per-channel data from a local device reading."""

    channel_type: str  # CONSUMPTION, GENERATION, NET, PHASE_A_CONSUMPTION, etc.
    power: int | None  # W (p_W)
    energy_imported: int | None  # Ws (eImp_Ws)
    energy_exported: int | None  # Ws (eExp_Ws)
    voltage: float | None  # V (v_V)


@dataclass(frozen=True, slots=True)
class LocalSample:
    """A current sample from a local device."""

    timestamp: datetime | None
    channels: list[LocalChannel]
