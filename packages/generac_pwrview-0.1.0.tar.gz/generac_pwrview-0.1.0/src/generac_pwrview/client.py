"""Async cloud client for the Generac PWRview / Neurio API."""

from __future__ import annotations

from base64 import b64encode
from typing import Any

import aiohttp

from .exceptions import PWRviewAuthError, PWRviewConnectionError, PWRviewResponseError
from .models import (
    ChannelSample,
    LiveSample,
    LocationInfo,
    Sample,
    SensorInfo,
    Stats,
    UserInfo,
    parse_timestamp,
)

BASE_URL = "https://api.neur.io/v1"
TOKEN_URL = f"{BASE_URL}/oauth2/token"


def _parse_user_info(data: dict[str, Any]) -> UserInfo:
    """Parse the /users/current API response into a UserInfo model."""
    locations: list[LocationInfo] = []
    for loc in data.get("locations", []):
        sensors: list[SensorInfo] = []
        for sensor in loc.get("sensors", []):
            sensors.append(
                SensorInfo(
                    sensor_id=sensor["sensorId"],
                    serial_number=sensor.get("serialNumber", ""),
                    ip_address=sensor.get("ipAddress"),
                )
            )
        locations.append(LocationInfo(name=loc.get("name", ""), sensors=sensors))
    return UserInfo(locations=locations)


def _parse_live_sample(data: dict[str, Any]) -> LiveSample:
    """Parse a live sample API response into a LiveSample model."""
    return LiveSample(
        timestamp=parse_timestamp(data.get("timestamp")),
        consumption_power=data.get("consumptionPower"),
        generation_power=data.get("generationPower"),
        net_power=data.get("netPower"),
        consumption_energy=data.get("consumptionEnergy"),
        generation_energy=data.get("generationEnergy"),
        net_energy=data.get("netEnergy"),
    )


def _parse_stats(data: dict[str, Any]) -> Stats:
    """Parse a stats API response entry into a Stats model."""
    return Stats(
        start=parse_timestamp(data.get("start")),
        end=parse_timestamp(data.get("end")),
        consumption_energy=data.get("consumptionEnergy"),
        generation_energy=data.get("generationEnergy"),
        imported_energy=data.get("importedEnergy"),
        exported_energy=data.get("exportedEnergy"),
    )


def _parse_sample(data: dict[str, Any]) -> Sample:
    """Parse a full sample API response entry into a Sample model."""
    channel_samples: list[ChannelSample] = []
    for ch in data.get("channelSamples", []):
        channel_samples.append(
            ChannelSample(
                channel_type=ch.get("channelType", ""),
                power=ch.get("power"),
                reactive_power=ch.get("reactivePower"),
                voltage=ch.get("voltage"),
                energy_imported=ch.get("energyImported"),
                energy_exported=ch.get("energyExported"),
            )
        )
    return Sample(
        timestamp=parse_timestamp(data.get("timestamp")),
        channel_samples=channel_samples,
    )


class PWRviewClient:
    """Async client for the Generac PWRview / Neurio cloud API.

    Handles OAuth2 client-credentials authentication internally.
    Transparently re-authenticates when the token expires.

    Usage:
        # Standalone — client manages its own session
        async with PWRviewClient(api_key="...", api_secret="...") as client:
            user = await client.get_user_information()

        # With injected session (e.g. Home Assistant)
        client = PWRviewClient(api_key="...", api_secret="...", session=session)
        user = await client.get_user_information()
    """

    def __init__(
        self,
        api_key: str,
        api_secret: str,
        session: aiohttp.ClientSession | None = None,
    ) -> None:
        self._api_key = api_key
        self._api_secret = api_secret
        self._session = session
        self._owns_session = session is None
        self._token: str | None = None

    async def __aenter__(self) -> PWRviewClient:
        if self._owns_session:
            self._session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, *args: object) -> None:
        if self._owns_session and self._session:
            await self._session.close()
            self._session = None

    def _get_session(self) -> aiohttp.ClientSession:
        """Return the active session, creating one if needed."""
        if self._session is None:
            self._session = aiohttp.ClientSession()
            self._owns_session = True
        return self._session

    async def _authenticate(self) -> None:
        """Acquire an OAuth2 access token using client credentials."""
        session = self._get_session()
        credentials = b64encode(f"{self._api_key}:{self._api_secret}".encode()).decode()

        headers = {"Authorization": f"Basic {credentials}"}
        payload = {"grant_type": "client_credentials"}

        try:
            async with session.post(TOKEN_URL, data=payload, headers=headers) as resp:
                if resp.status == 401:
                    raise PWRviewAuthError("Invalid API credentials")
                if resp.status == 403:
                    raise PWRviewAuthError("API credentials rejected")
                if resp.status != 200:
                    text = await resp.text()
                    raise PWRviewResponseError(
                        f"Token request failed with status {resp.status}: {text}"
                    )
                data = await resp.json()
                self._token = data["access_token"]
        except aiohttp.ClientError as err:
            raise PWRviewConnectionError(f"Cannot connect to PWRview API: {err}") from err

    async def _ensure_token(self) -> str:
        """Return a valid token, authenticating if necessary."""
        if self._token is None:
            await self._authenticate()
        if self._token is None:
            raise PWRviewAuthError("Authentication did not produce a token")
        return self._token

    async def _request(self, method: str, url: str, **kwargs: Any) -> Any:
        """Make an authenticated API request with automatic token refresh."""
        session = self._get_session()
        token = await self._ensure_token()
        headers = {"Authorization": f"Bearer {token}"}

        try:
            async with session.request(method, url, headers=headers, **kwargs) as resp:
                if resp.status == 401:
                    # Token expired — re-authenticate and retry once
                    self._token = None
                    await self._authenticate()
                    headers = {"Authorization": f"Bearer {self._token}"}
                    async with session.request(
                        method, url, headers=headers, **kwargs
                    ) as retry_resp:
                        if retry_resp.status in (401, 403):
                            raise PWRviewAuthError("Authentication failed after token refresh")
                        if retry_resp.status != 200:
                            text = await retry_resp.text()
                            raise PWRviewResponseError(
                                f"API request failed with status {retry_resp.status}: {text}"
                            )
                        return await retry_resp.json()

                if resp.status == 403:
                    raise PWRviewAuthError("API access forbidden")
                if resp.status != 200:
                    text = await resp.text()
                    raise PWRviewResponseError(
                        f"API request failed with status {resp.status}: {text}"
                    )
                return await resp.json()
        except aiohttp.ClientError as err:
            raise PWRviewConnectionError(f"Cannot connect to PWRview API: {err}") from err

    async def get_user_information(self) -> UserInfo:
        """Get the current user's account information including sensors."""
        data = await self._request("GET", f"{BASE_URL}/users/current")
        return _parse_user_info(data)

    async def get_live_sample(self, sensor_id: str) -> LiveSample:
        """Get the most recent live sample from a sensor."""
        data = await self._request(
            "GET",
            f"{BASE_URL}/samples/live/last",
            params={"sensorId": sensor_id},
        )
        return _parse_live_sample(data)

    async def get_stats(
        self,
        sensor_id: str,
        start: str,
        granularity: str,
        end: str,
    ) -> list[Stats]:
        """Get aggregated energy statistics for a time period."""
        data = await self._request(
            "GET",
            f"{BASE_URL}/samples/stats",
            params={
                "sensorId": sensor_id,
                "start": start,
                "granularity": granularity,
                "end": end,
            },
        )
        return [_parse_stats(entry) for entry in data]

    async def get_samples(
        self,
        sensor_id: str,
        start: str,
        granularity: str,
        end: str,
        *,
        full: bool = False,
    ) -> list[Sample]:
        """Get historical samples for a sensor.

        When full=True, includes per-channel voltage and phase data.
        """
        endpoint = f"{BASE_URL}/samples/full" if full else f"{BASE_URL}/samples"
        data = await self._request(
            "GET",
            endpoint,
            params={
                "sensorId": sensor_id,
                "start": start,
                "granularity": granularity,
                "end": end,
            },
        )
        return [_parse_sample(entry) for entry in data]
