"""Exceptions for the Generac PWRview API client."""


class PWRviewError(Exception):
    """Base exception for all PWRview errors."""


class PWRviewConnectionError(PWRviewError):
    """Cannot reach the API or local device."""


class PWRviewAuthError(PWRviewError):
    """Invalid credentials or expired token that cannot be refreshed."""


class PWRviewResponseError(PWRviewError):
    """Unexpected or malformed API response."""
