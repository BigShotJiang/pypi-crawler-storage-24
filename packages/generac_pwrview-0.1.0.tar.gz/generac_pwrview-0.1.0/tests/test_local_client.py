"""Tests for PWRviewLocalClient (local device API)."""

from datetime import datetime

import aiohttp
import pytest
from aioresponses import aioresponses

from generac_pwrview import (
    PWRviewConnectionError,
    PWRviewLocalClient,
    PWRviewResponseError,
)

HOST = "192.168.1.100"
LOCAL_URL = f"http://{HOST}/current-sample"

LOCAL_SAMPLE_RESPONSE = {
    "sensorId": "0x0013A20040B65FAD",
    "timestamp": "2024-01-15T10:30:00Z",
    "channels": [
        {
            "type": "PHASE_A_CONSUMPTION",
            "ch": 1,
            "eImp_Ws": 27000000,
            "eExp_Ws": 0,
            "p_W": 750,
            "q_VAR": 50,
            "v_V": 121.3,
        },
        {
            "type": "PHASE_B_CONSUMPTION",
            "ch": 2,
            "eImp_Ws": 28000000,
            "eExp_Ws": 0,
            "p_W": 800,
            "q_VAR": 45,
            "v_V": 120.8,
        },
        {
            "type": "CONSUMPTION",
            "ch": 3,
            "eImp_Ws": 55000000,
            "eExp_Ws": 0,
            "p_W": 1550,
            "q_VAR": 95,
            "v_V": 121.05,
        },
    ],
}


async def test_get_current_sample(mock_aiohttp: aioresponses) -> None:
    """get_current_sample returns parsed LocalSample with channels."""
    mock_aiohttp.get(LOCAL_URL, payload=LOCAL_SAMPLE_RESPONSE)

    async with PWRviewLocalClient(host=HOST) as client:
        sample = await client.get_current_sample()

        assert isinstance(sample.timestamp, datetime)
        assert len(sample.channels) == 3

        phase_a = sample.channels[0]
        assert phase_a.channel_type == "PHASE_A_CONSUMPTION"
        assert phase_a.power == 750
        assert phase_a.energy_imported == 27000000
        assert phase_a.energy_exported == 0
        assert phase_a.voltage == 121.3

        consumption = sample.channels[2]
        assert consumption.channel_type == "CONSUMPTION"
        assert consumption.power == 1550


async def test_get_current_sample_missing_fields(mock_aiohttp: aioresponses) -> None:
    """get_current_sample handles channels with missing optional fields."""
    mock_aiohttp.get(
        LOCAL_URL,
        payload={
            "timestamp": "2024-01-15T10:30:00Z",
            "channels": [
                {
                    "type": "NET",
                }
            ],
        },
    )

    async with PWRviewLocalClient(host=HOST) as client:
        sample = await client.get_current_sample()
        assert len(sample.channels) == 1
        ch = sample.channels[0]
        assert ch.channel_type == "NET"
        assert ch.power is None
        assert ch.energy_imported is None
        assert ch.energy_exported is None
        assert ch.voltage is None


async def test_local_connection_error(mock_aiohttp: aioresponses) -> None:
    """Client raises PWRviewConnectionError when device is unreachable."""
    mock_aiohttp.get(LOCAL_URL, exception=aiohttp.ClientConnectionError("refused"))

    async with PWRviewLocalClient(host=HOST) as client:
        with pytest.raises(PWRviewConnectionError, match="Cannot connect"):
            await client.get_current_sample()


async def test_local_server_error(mock_aiohttp: aioresponses) -> None:
    """Client raises PWRviewResponseError on non-200 response."""
    mock_aiohttp.get(LOCAL_URL, status=500, body="Error")

    async with PWRviewLocalClient(host=HOST) as client:
        with pytest.raises(PWRviewResponseError, match="status 500"):
            await client.get_current_sample()


async def test_injected_session_not_closed(mock_aiohttp: aioresponses) -> None:
    """Local client with injected session does not close it on exit."""
    mock_aiohttp.get(LOCAL_URL, payload=LOCAL_SAMPLE_RESPONSE)

    session = aiohttp.ClientSession()
    try:
        client = PWRviewLocalClient(host=HOST, session=session)
        async with client:
            await client.get_current_sample()
        assert not session.closed
    finally:
        await session.close()


async def test_owned_session_closed(mock_aiohttp: aioresponses) -> None:
    """Local client without injected session closes its own on exit."""
    mock_aiohttp.get(LOCAL_URL, payload=LOCAL_SAMPLE_RESPONSE)

    client = PWRviewLocalClient(host=HOST)
    async with client:
        await client.get_current_sample()
        session = client._session
        assert session is not None
    assert client._session is None
