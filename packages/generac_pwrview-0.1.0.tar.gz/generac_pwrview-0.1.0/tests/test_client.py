"""Tests for PWRviewClient (cloud API)."""

import re
from datetime import datetime

import aiohttp
import pytest
from aioresponses import aioresponses

from generac_pwrview import (
    PWRviewAuthError,
    PWRviewClient,
    PWRviewConnectionError,
    PWRviewResponseError,
)

TOKEN_URL = "https://api.neur.io/v1/oauth2/token"
USER_URL = "https://api.neur.io/v1/users/current"
LIVE_LAST_URL = re.compile(r"https://api\.neur\.io/v1/samples/live/last\b")
STATS_URL = re.compile(r"https://api\.neur\.io/v1/samples/stats\b")
SAMPLES_URL = re.compile(r"https://api\.neur\.io/v1/samples\b(?!/)")
SAMPLES_FULL_URL = re.compile(r"https://api\.neur\.io/v1/samples/full\b")

TOKEN_RESPONSE = {"access_token": "test-token-123"}

SENSOR_ID = "0x0013A20040B65FAD"

USER_INFO_RESPONSE = {
    "status": "active",
    "locations": [
        {
            "name": "Home",
            "sensors": [
                {
                    "sensorId": SENSOR_ID,
                    "serialNumber": "SN12345",
                    "ipAddress": "192.168.1.100",
                    "sensorType": "neurio",
                }
            ],
        }
    ],
}

LIVE_SAMPLE_RESPONSE = {
    "timestamp": "2024-01-15T10:30:00Z",
    "consumptionPower": 1500,
    "generationPower": 500,
    "netPower": 1000,
    "consumptionEnergy": 5400000,
    "generationEnergy": 1800000,
    "netEnergy": 3600000,
}

STATS_RESPONSE = [
    {
        "start": "2024-01-15T00:00:00Z",
        "end": "2024-01-16T00:00:00Z",
        "consumptionEnergy": 86400000,
        "generationEnergy": 43200000,
        "importedEnergy": 54000000,
        "exportedEnergy": 10800000,
    }
]

FULL_SAMPLE_RESPONSE = [
    {
        "timestamp": "2024-01-15T10:30:00Z",
        "channelSamples": [
            {
                "channelType": "CONSUMPTION",
                "power": 1500,
                "reactivePower": -398,
                "voltage": 120.5,
                "energyImported": 5400000,
                "energyExported": 0,
            },
            {
                "channelType": "GENERATION",
                "power": 500,
                "reactivePower": 900,
                "voltage": 121.0,
                "energyImported": 0,
                "energyExported": 1800000,
            },
        ],
    }
]


# --- Token acquisition tests ---


async def test_authenticate_success(mock_aiohttp: aioresponses) -> None:
    """Client acquires a token on first API call."""
    mock_aiohttp.post(TOKEN_URL, payload=TOKEN_RESPONSE)
    mock_aiohttp.get(USER_URL, payload=USER_INFO_RESPONSE)

    async with PWRviewClient(api_key="key", api_secret="secret") as client:
        user = await client.get_user_information()
        assert len(user.locations) == 1
        assert user.locations[0].name == "Home"


async def test_authenticate_invalid_credentials(mock_aiohttp: aioresponses) -> None:
    """Client raises PWRviewAuthError on 401 from token endpoint."""
    mock_aiohttp.post(TOKEN_URL, status=401)

    async with PWRviewClient(api_key="bad", api_secret="creds") as client:
        with pytest.raises(PWRviewAuthError, match="Invalid API credentials"):
            await client.get_user_information()


async def test_authenticate_forbidden(mock_aiohttp: aioresponses) -> None:
    """Client raises PWRviewAuthError on 403 from token endpoint."""
    mock_aiohttp.post(TOKEN_URL, status=403)

    async with PWRviewClient(api_key="bad", api_secret="creds") as client:
        with pytest.raises(PWRviewAuthError, match="credentials rejected"):
            await client.get_user_information()


async def test_authenticate_server_error(mock_aiohttp: aioresponses) -> None:
    """Client raises PWRviewResponseError on 500 from token endpoint."""
    mock_aiohttp.post(TOKEN_URL, status=500, body="Internal Server Error")

    async with PWRviewClient(api_key="key", api_secret="secret") as client:
        with pytest.raises(PWRviewResponseError, match="status 500"):
            await client.get_user_information()


async def test_authenticate_connection_error(mock_aiohttp: aioresponses) -> None:
    """Client raises PWRviewConnectionError when token endpoint is unreachable."""
    mock_aiohttp.post(TOKEN_URL, exception=aiohttp.ClientConnectionError("refused"))

    async with PWRviewClient(api_key="key", api_secret="secret") as client:
        with pytest.raises(PWRviewConnectionError, match="Cannot connect"):
            await client.get_user_information()


# --- Token refresh tests ---


async def test_token_refresh_on_401(mock_aiohttp: aioresponses) -> None:
    """Client transparently re-authenticates when API returns 401."""
    # Initial auth succeeds
    mock_aiohttp.post(TOKEN_URL, payload=TOKEN_RESPONSE)
    # First API call returns 401 (token expired)
    mock_aiohttp.get(USER_URL, status=401)
    # Re-auth succeeds with new token
    mock_aiohttp.post(TOKEN_URL, payload={"access_token": "refreshed-token"})
    # Retry succeeds
    mock_aiohttp.get(USER_URL, payload=USER_INFO_RESPONSE)

    async with PWRviewClient(api_key="key", api_secret="secret") as client:
        user = await client.get_user_information()
        assert user.locations[0].sensors[0].sensor_id == SENSOR_ID


async def test_token_refresh_fails_after_retry(mock_aiohttp: aioresponses) -> None:
    """Client raises PWRviewAuthError when retry also returns 401."""
    mock_aiohttp.post(TOKEN_URL, payload=TOKEN_RESPONSE)
    mock_aiohttp.get(USER_URL, status=401)
    mock_aiohttp.post(TOKEN_URL, payload={"access_token": "new-token"})
    mock_aiohttp.get(USER_URL, status=401)

    async with PWRviewClient(api_key="key", api_secret="secret") as client:
        with pytest.raises(PWRviewAuthError, match="after token refresh"):
            await client.get_user_information()


async def test_403_on_api_call_raises_auth_error(mock_aiohttp: aioresponses) -> None:
    """Client raises PWRviewAuthError on 403 from API endpoint."""
    mock_aiohttp.post(TOKEN_URL, payload=TOKEN_RESPONSE)
    mock_aiohttp.get(USER_URL, status=403)

    async with PWRviewClient(api_key="key", api_secret="secret") as client:
        with pytest.raises(PWRviewAuthError, match="forbidden"):
            await client.get_user_information()


# --- API method tests ---


async def test_get_user_information(mock_aiohttp: aioresponses) -> None:
    """get_user_information returns parsed UserInfo with sensors."""
    mock_aiohttp.post(TOKEN_URL, payload=TOKEN_RESPONSE)
    mock_aiohttp.get(USER_URL, payload=USER_INFO_RESPONSE)

    async with PWRviewClient(api_key="key", api_secret="secret") as client:
        user = await client.get_user_information()
        assert len(user.locations) == 1
        loc = user.locations[0]
        assert loc.name == "Home"
        assert len(loc.sensors) == 1
        sensor = loc.sensors[0]
        assert sensor.sensor_id == SENSOR_ID
        assert sensor.serial_number == "SN12345"
        assert sensor.ip_address == "192.168.1.100"


async def test_get_user_information_missing_optional_fields(
    mock_aiohttp: aioresponses,
) -> None:
    """get_user_information handles missing optional fields gracefully."""
    mock_aiohttp.post(TOKEN_URL, payload=TOKEN_RESPONSE)
    mock_aiohttp.get(
        USER_URL,
        payload={
            "locations": [
                {
                    "sensors": [
                        {"sensorId": "sensor1"},
                    ],
                }
            ],
        },
    )

    async with PWRviewClient(api_key="key", api_secret="secret") as client:
        user = await client.get_user_information()
        sensor = user.locations[0].sensors[0]
        assert sensor.serial_number == ""
        assert sensor.ip_address is None


async def test_get_live_sample(mock_aiohttp: aioresponses) -> None:
    """get_live_sample returns parsed LiveSample with datetime timestamp."""
    mock_aiohttp.post(TOKEN_URL, payload=TOKEN_RESPONSE)
    mock_aiohttp.get(LIVE_LAST_URL, payload=LIVE_SAMPLE_RESPONSE)

    async with PWRviewClient(api_key="key", api_secret="secret") as client:
        sample = await client.get_live_sample(SENSOR_ID)
        assert isinstance(sample.timestamp, datetime)
        assert sample.consumption_power == 1500
        assert sample.generation_power == 500
        assert sample.net_power == 1000
        assert sample.consumption_energy == 5400000
        assert sample.generation_energy == 1800000
        assert sample.net_energy == 3600000


async def test_get_stats(mock_aiohttp: aioresponses) -> None:
    """get_stats returns list of parsed Stats with datetime timestamps."""
    mock_aiohttp.post(TOKEN_URL, payload=TOKEN_RESPONSE)
    mock_aiohttp.get(STATS_URL, payload=STATS_RESPONSE)

    async with PWRviewClient(api_key="key", api_secret="secret") as client:
        stats = await client.get_stats(
            SENSOR_ID, "2024-01-15T00:00:00Z", "days", "2024-01-16T00:00:00Z"
        )
        assert len(stats) == 1
        assert isinstance(stats[0].start, datetime)
        assert isinstance(stats[0].end, datetime)
        assert stats[0].consumption_energy == 86400000
        assert stats[0].generation_energy == 43200000
        assert stats[0].imported_energy == 54000000
        assert stats[0].exported_energy == 10800000


async def test_get_samples_full(mock_aiohttp: aioresponses) -> None:
    """get_samples with full=True returns parsed Samples with channels."""
    mock_aiohttp.post(TOKEN_URL, payload=TOKEN_RESPONSE)
    mock_aiohttp.get(SAMPLES_FULL_URL, payload=FULL_SAMPLE_RESPONSE)

    async with PWRviewClient(api_key="key", api_secret="secret") as client:
        samples = await client.get_samples(
            SENSOR_ID,
            "2024-01-15T10:00:00Z",
            "minutes",
            "2024-01-15T10:30:00Z",
            full=True,
        )
        assert len(samples) == 1
        assert isinstance(samples[0].timestamp, datetime)
        assert len(samples[0].channel_samples) == 2

        consumption = samples[0].channel_samples[0]
        assert consumption.channel_type == "CONSUMPTION"
        assert consumption.power == 1500
        assert consumption.reactive_power == -398
        assert consumption.voltage == 120.5
        assert consumption.energy_imported == 5400000
        assert consumption.energy_exported == 0


async def test_get_samples_not_full(mock_aiohttp: aioresponses) -> None:
    """get_samples with full=False uses the /samples endpoint."""
    mock_aiohttp.post(TOKEN_URL, payload=TOKEN_RESPONSE)
    mock_aiohttp.get(SAMPLES_URL, payload=FULL_SAMPLE_RESPONSE)

    async with PWRviewClient(api_key="key", api_secret="secret") as client:
        samples = await client.get_samples(
            SENSOR_ID,
            "2024-01-15T10:00:00Z",
            "minutes",
            "2024-01-15T10:30:00Z",
        )
        assert len(samples) == 1


# --- Session management tests ---


async def test_injected_session_not_closed(mock_aiohttp: aioresponses) -> None:
    """Client with injected session does not close it on exit."""
    mock_aiohttp.post(TOKEN_URL, payload=TOKEN_RESPONSE)
    mock_aiohttp.get(USER_URL, payload=USER_INFO_RESPONSE)

    session = aiohttp.ClientSession()
    try:
        client = PWRviewClient(api_key="key", api_secret="secret", session=session)
        async with client:
            await client.get_user_information()
        # Session should still be open after client context exits
        assert not session.closed
    finally:
        await session.close()


async def test_owned_session_closed(mock_aiohttp: aioresponses) -> None:
    """Client without injected session closes its own session on exit."""
    mock_aiohttp.post(TOKEN_URL, payload=TOKEN_RESPONSE)
    mock_aiohttp.get(USER_URL, payload=USER_INFO_RESPONSE)

    client = PWRviewClient(api_key="key", api_secret="secret")
    async with client:
        await client.get_user_information()
        session = client._session
        assert session is not None
    # Session should be closed after context exits
    assert client._session is None


# --- API error response tests ---


async def test_api_server_error(mock_aiohttp: aioresponses) -> None:
    """Client raises PWRviewResponseError on 500 from API endpoint."""
    mock_aiohttp.post(TOKEN_URL, payload=TOKEN_RESPONSE)
    mock_aiohttp.get(USER_URL, status=500, body="Server Error")

    async with PWRviewClient(api_key="key", api_secret="secret") as client:
        with pytest.raises(PWRviewResponseError, match="status 500"):
            await client.get_user_information()


async def test_api_connection_error(mock_aiohttp: aioresponses) -> None:
    """Client raises PWRviewConnectionError when API endpoint is unreachable."""
    mock_aiohttp.post(TOKEN_URL, payload=TOKEN_RESPONSE)
    mock_aiohttp.get(USER_URL, exception=aiohttp.ClientConnectionError("timeout"))

    async with PWRviewClient(api_key="key", api_secret="secret") as client:
        with pytest.raises(PWRviewConnectionError):
            await client.get_user_information()
