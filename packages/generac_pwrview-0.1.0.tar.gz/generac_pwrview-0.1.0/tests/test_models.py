"""Tests for response model construction and immutability."""

from datetime import UTC, datetime

import pytest

from generac_pwrview import (
    ChannelSample,
    LiveSample,
    LocalChannel,
    LocalSample,
    LocationInfo,
    Sample,
    SensorInfo,
    Stats,
    UserInfo,
)
from generac_pwrview.models import parse_timestamp


class TestParseTimestamp:
    """Tests for the parse_timestamp utility."""

    def test_parses_iso_string(self) -> None:
        result = parse_timestamp("2024-01-15T10:30:00Z")
        assert isinstance(result, datetime)

    def test_parses_with_timezone(self) -> None:
        result = parse_timestamp("2024-01-15T10:30:00+00:00")
        assert result is not None
        assert result.tzinfo is not None

    def test_returns_none_for_none(self) -> None:
        assert parse_timestamp(None) is None


class TestSensorInfo:
    def test_construction(self) -> None:
        sensor = SensorInfo(
            sensor_id="abc123",
            serial_number="SN456",
            ip_address="192.168.1.1",
        )
        assert sensor.sensor_id == "abc123"
        assert sensor.serial_number == "SN456"
        assert sensor.ip_address == "192.168.1.1"

    def test_optional_ip(self) -> None:
        sensor = SensorInfo(sensor_id="abc", serial_number="SN", ip_address=None)
        assert sensor.ip_address is None

    def test_frozen(self) -> None:
        sensor = SensorInfo(sensor_id="abc", serial_number="SN", ip_address=None)
        with pytest.raises(AttributeError):
            sensor.sensor_id = "xyz"  # type: ignore[misc]


class TestLocationInfo:
    def test_construction(self) -> None:
        loc = LocationInfo(name="Home", sensors=[])
        assert loc.name == "Home"
        assert loc.sensors == []


class TestUserInfo:
    def test_construction(self) -> None:
        user = UserInfo(locations=[])
        assert user.locations == []


class TestLiveSample:
    def test_construction_with_all_fields(self) -> None:
        ts = datetime(2024, 1, 15, 10, 30, tzinfo=UTC)
        sample = LiveSample(
            timestamp=ts,
            consumption_power=1500,
            generation_power=500,
            net_power=1000,
            consumption_energy=5400000,
            generation_energy=1800000,
            net_energy=3600000,
        )
        assert sample.timestamp == ts
        assert sample.consumption_power == 1500

    def test_nullable_fields(self) -> None:
        sample = LiveSample(
            timestamp=None,
            consumption_power=None,
            generation_power=None,
            net_power=None,
            consumption_energy=None,
            generation_energy=None,
            net_energy=None,
        )
        assert sample.timestamp is None
        assert sample.consumption_power is None


class TestStats:
    def test_construction(self) -> None:
        start = datetime(2024, 1, 15, tzinfo=UTC)
        end = datetime(2024, 1, 16, tzinfo=UTC)
        stats = Stats(
            start=start,
            end=end,
            consumption_energy=86400000,
            generation_energy=43200000,
            imported_energy=54000000,
            exported_energy=10800000,
        )
        assert stats.start == start
        assert stats.end == end
        assert stats.consumption_energy == 86400000


class TestChannelSample:
    def test_construction(self) -> None:
        ch = ChannelSample(
            channel_type="CONSUMPTION",
            power=1500,
            reactive_power=-398,
            voltage=120.5,
            energy_imported=5400000,
            energy_exported=0,
        )
        assert ch.channel_type == "CONSUMPTION"
        assert ch.power == 1500
        assert ch.reactive_power == -398
        assert ch.voltage == 120.5


class TestSample:
    def test_construction(self) -> None:
        sample = Sample(
            timestamp=datetime(2024, 1, 15, tzinfo=UTC),
            channel_samples=[],
        )
        assert sample.channel_samples == []


class TestLocalChannel:
    def test_construction(self) -> None:
        ch = LocalChannel(
            channel_type="PHASE_A_CONSUMPTION",
            power=750,
            energy_imported=27000000,
            energy_exported=0,
            voltage=121.3,
        )
        assert ch.channel_type == "PHASE_A_CONSUMPTION"
        assert ch.power == 750


class TestLocalSample:
    def test_construction(self) -> None:
        sample = LocalSample(
            timestamp=datetime(2024, 1, 15, tzinfo=UTC),
            channels=[],
        )
        assert sample.channels == []
