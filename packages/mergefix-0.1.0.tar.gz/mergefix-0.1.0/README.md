# mergefix

**AI-powered git merge conflict resolver — resolve conflicts in seconds, not minutes.**

mergefix reads your conflict markers, understands what both sides were trying to do, and produces the correct merged result — preserving intent from both branches.

```
$ mergefix
Scanning for conflict markers…

→ src/auth.py  (2 conflicts)

  Conflict 1/2
  ours:   HEAD
  theirs: feature/oauth

  ✓ Resolution:
    def authenticate(user, provider=None):
        if provider == "oauth":
            return oauth_login(user)
        return password_login(user)

  Conflict 2/2
  ours:   HEAD
  theirs: feature/oauth

  ✓ Resolution:
    SUPPORTED_PROVIDERS = ["password", "oauth", "sso"]

Diff:
  --- a/src/auth.py
  +++ b/src/auth.py
  @@ -8,8 +8,8 @@
  -<<<<<<< HEAD
  -    return password_login(user)
  -=======
  -    ...
  ->>>>>>> feature/oauth
  +    def authenticate(user, provider=None):
  +        if provider == "oauth":
  +            ...

Apply resolutions to src/auth.py? [Y/n]  y
  ✓ Applied

✅ All 1 file(s) resolved.
Run `git diff` to review changes, then `git add` to mark as resolved.
```

## Install

```bash
pip install mergefix
```

Set your API key (or use Ollama for free local resolution):

```bash
export ANTHROPIC_API_KEY=your-key   # Claude (default)
export OPENAI_API_KEY=your-key      # or OpenAI
# or use --provider ollama           # local, no API key needed
```

## Usage

```bash
# Resolve all conflicted files in current directory
mergefix

# Resolve a specific file
mergefix src/auth.py

# Preview resolutions without writing
mergefix --preview

# Apply all without prompting (scripting/CI use)
mergefix --yes

# Keep original files as .orig backups
mergefix --backup

# Use local Ollama (free, no API key)
mergefix --provider ollama

# Use OpenAI
mergefix --provider openai

# Custom model
mergefix --provider claude --model claude-haiku-4-5-20251001
```

## How It Works

1. **Finds** all files with `<<<<<<<` conflict markers in the current directory
2. For each conflict block, **extracts** ours, theirs, and (if present) the common base
3. Sends the conflict + surrounding context to the LLM with a structured prompt
4. The AI **preserves intent from both sides** — it doesn't just pick one
5. Shows you a colorized diff **before** writing anything
6. **Writes** the resolved file on confirmation (or with `--yes` for automation)

### Context-Aware Resolution

mergefix doesn't blindly pick a side. It:
- Includes lines **before and after** the conflict so the AI understands the code context
- Provides **commit messages** from each branch (when available) so the AI understands *why* each change was made
- Handles **diff3-style** (3-way) conflicts with the common ancestor

## What mergefix Does Well

- **Additive changes**: Feature A adds a function, Feature B adds another → keep both
- **Same line, different values**: Config changes, version bumps → AI picks the right one
- **Refactoring meets feature**: One side renamed a function while another added to it
- **Import conflicts**: Merges import lists cleanly
- **Documentation conflicts**: Merges docstring changes from both sides

## Integration

```bash
# After git merge or git rebase hits conflicts:
git merge feature/branch
# Lots of conflicts...

mergefix --yes          # auto-resolve all
git diff                # review the AI's choices
git add .               # mark as resolved
git commit
```

## Providers

| Provider | Command | Notes |
|----------|---------|-------|
| Claude (default) | `--provider claude` | Best results; requires `ANTHROPIC_API_KEY` |
| OpenAI | `--provider openai` | Requires `OPENAI_API_KEY` |
| Ollama | `--provider ollama` | Free, runs locally; no API key needed |

```bash
# Default models
mergefix --provider claude    # claude-haiku-4-5-20251001
mergefix --provider openai    # gpt-4o-mini
mergefix --provider ollama    # qwen2.5:1.5b

# Override model
mergefix --provider claude --model claude-sonnet-4-6
```

## Developer Workflow Integration

mergefix fits into the AI-powered git workflow:

```bash
# 1. Morning: generate standup from yesterday's commits
standup-ai ~/projects/myapp

# 2. Rebase or merge, hit conflicts
git rebase main
mergefix --yes              # AI resolves all conflicts
git rebase --continue

# 3. Review staged changes before committing
critiq                      # AI code review

# 4. Generate commit message
gpr --commit-run

# 5. Generate PR description
gpr

# 6. At release: generate CHANGELOG
changelog-ai --from v0.1.0 --prepend CHANGELOG.md
```

## Related Tools

- [critiq](https://github.com/faw21/critiq) — AI code reviewer: catch issues before you push
- [critiq-vscode](https://github.com/faw21/critiq-vscode) — VS Code extension for critiq
- [gpr](https://github.com/faw21/gpr) — AI commit messages + PR descriptions
- [gitbrief](https://github.com/faw21/gitbrief) — git-history-aware context packer for LLMs
- [standup-ai](https://github.com/faw21/standup-ai) — daily standup from git commits
- [prcat](https://github.com/faw21/prcat) — AI reviewer for teammates' pull requests
- [changelog-ai](https://github.com/faw21/changelog-ai) — AI-generated CHANGELOG
- [git-chronicle](https://github.com/faw21/chronicle) — AI git history narrator

## License

MIT
