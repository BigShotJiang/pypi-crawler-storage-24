from pullapprove.diff import DiffCode, DiffFile, iterate_diff_parts


def test_diff_hunk_context_line():
    # Technically there is a space missing here on the empty line
    diff = """diff --git a/LICENSE b/LICENSE
index fdddb29..314ba5d 100644
--- a/LICENSE
+++ b/LICENSE
@@ -6,7 +6,7 @@ binary, for any purpose, commercial or non-commercial, and by any
 means.

 In jurisdictions that recognize copyright laws, the author or authors
-of this software dedicate any and all copyright interest in the
+of this software dedicate any and all copyright interest! in the
 software to the public domain. We make this dedication for the benefit
 of the public at large and to the detriment of our heirs and
 successors. We intend this dedication to be an overt act of"""

    # Make sure the line with "binary" is seen
    lines = list(iterate_diff_parts(diff))

    # Filter down to the DiffCode objects so we can inspect the actual lines
    code_lines = [line for line in lines if isinstance(line, DiffCode)]

    # We should have parsed the trailing context that appears on the same
    # line as the hunk header ("binary, for any purpose ...")
    assert any(
        "binary, for any purpose" in code_line.content for code_line in code_lines
    ), "The first context line that trails the hunk header was not captured."


def test_diff_binary_file():
    """Binary file markers and replacement characters in diff content don't cause issues."""
    diff = (
        "diff --git a/image.png b/image.png\n"
        "Binary files /dev/null and b/image.png differ\n"
        "diff --git a/README.md b/README.md\n"
        "index abc1234..def5678 100644\n"
        "--- a/README.md\n"
        "+++ b/README.md\n"
        "@@ -1,3 +1,3 @@\n"
        " hello\n"
        "-old line\n"
        "+new line\n"
        " world"
    )

    parts = list(iterate_diff_parts(diff))
    files = [p for p in parts if isinstance(p, DiffFile)]
    code_lines = [p for p in parts if isinstance(p, DiffCode)]

    assert len(files) == 2
    assert files[0].new_path == "image.png"
    assert files[1].new_path == "README.md"

    # The binary marker line is skipped; only README.md code lines are parsed
    assert len(code_lines) == 4
    assert any(c.content == "new line" and c.is_addition() for c in code_lines)


def test_diff_with_replacement_characters():
    """Lines containing Unicode replacement characters (from errors='replace') are handled."""
    diff = (
        "diff --git a/data.bin b/data.bin\n"
        "index 0000000..1111111 100644\n"
        "--- a/data.bin\n"
        "+++ b/data.bin\n"
        "@@ -0,0 +1,2 @@\n"
        "+\ufffd\ufffd\ufffd binary content\n"
        "+more \ufffd data"
    )

    parts = list(iterate_diff_parts(diff))
    code_lines = [p for p in parts if isinstance(p, DiffCode)]

    assert len(code_lines) == 2
    assert "\ufffd" in code_lines[0].content
    assert code_lines[0].is_addition()
    assert code_lines[1].is_addition()
