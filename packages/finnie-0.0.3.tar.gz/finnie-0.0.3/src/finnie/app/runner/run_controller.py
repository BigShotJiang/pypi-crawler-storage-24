#! -*- coding: utf-8 -*-
"""Run controller for a single agent query.

This module owns the lifecycle of a single ``query_handler`` call:
* Logging and basic request metadata
* Wiring session / tools / events together
* Handling cancellation, errors and finalisation

Execution is handled exclusively via the LangGraph path, including:
* LangGraph-native command handling
* Session persistence (save/load history + compressed summary)
* Graceful cancellation via middleware
* Middleware integration (Bootstrap + MemoryCompaction)
"""

from __future__ import annotations

import asyncio
import json
import logging
from dataclasses import dataclass
from typing import Any, AsyncIterator, Optional
from uuid import uuid4

from .event_bridge import EventBridge
from .query_error_dump import write_query_error_dump
from .session_factory import LangGraphSessionContext, SessionFactory
from .tool_registry import ToolRegistry
from ..channels.schema import DEFAULT_CHANNEL

logger = logging.getLogger(__name__)


@dataclass
class RunContext:
    """Lightweight context for a single run."""

    run_id: str
    session_id: Optional[str]
    user_id: Optional[str]
    channel: str


class RunController:
    """Control the lifecycle of a single agent run."""

    def __init__(
        self,
        *,
        session_factory: SessionFactory,
        tool_registry: ToolRegistry,
        event_bridge: EventBridge,
    ) -> None:
        self._session_factory = session_factory
        self._tool_registry = tool_registry
        self._event_bridge = event_bridge

    async def run(
        self,
        *,
        msgs,
        request: Any,
    ) -> AsyncIterator[tuple[Any, bool]]:
        """Execute a single agent run as an async generator.

        Always dispatches to the LangGraph execution path.
        """
        run_ctx = RunContext(
            run_id=str(uuid4()),
            session_id=request.session_id,
            user_id=request.user_id,
            channel=getattr(request, "channel", DEFAULT_CHANNEL),
        )

        logger.info(
            "Handle agent query (run_id=%s):\n%s",
            run_ctx.run_id,
            json.dumps(
                {
                    "session_id": run_ctx.session_id,
                    "user_id": run_ctx.user_id,
                    "channel": run_ctx.channel,
                    "msgs_len": len(msgs) if msgs else 0,
                    "msgs_str": str(msgs)[:300] + "...",
                },
                ensure_ascii=False,
                indent=2,
            ),
        )

        async for msg, last in self._run_langgraph(
            msgs=msgs, request=request, run_ctx=run_ctx
        ):
            yield msg, last

    # ------------------------------------------------------------------
    # LangGraph path
    # ------------------------------------------------------------------

    async def _run_langgraph(
        self,
        *,
        msgs,
        request: Any,
        run_ctx: RunContext,
    ) -> AsyncIterator[tuple[Any, bool]]:
        """New LangGraph agent execution path (three-stage).

        Stage 1: Prepare context (model + tools + prompt + history)
        Stage 2: Pre-checks (command interception, file preprocessing)
        Stage 3: Execute ReAct agent via graph.astream_events

        PR5: Commands are now handled natively; session state is persisted.
        """
        from ...agents.langgraph.command_handler import (
            LangGraphCommandHandler,
            is_command,
        )
        from ...agents.langgraph.event_bridge import LangGraphEventBridge
        from ...agents.langgraph.message_converter import msgs_to_langchain
        from ...agents.utils import process_file_and_media_blocks_in_message

        chat = None
        lg_context: LangGraphSessionContext | None = None

        try:
            # ── Stage 2: Pre-checks ──
            last_msg = msgs[-1] if isinstance(msgs, list) else msgs
            query = (
                last_msg.get_text_content()
                if hasattr(last_msg, "get_text_content")
                else None
            )

            # File / media pre-processing (before command check to handle
            # file uploads even in command context)
            if msgs is not None:
                await process_file_and_media_blocks_in_message(msgs)

            # ── Stage 1: Prepare context ──
            mcp_clients = await self._tool_registry.get_mcp_clients()
            lg_context = (
                await self._session_factory.create_langgraph_context(
                    msgs=msgs,
                    request=request,
                    mcp_clients=mcp_clients,
                )
            )
            chat = lg_context.chat

            # ── Command interception (PR5: native handling) ──
            if query and is_command(query):
                logger.info(
                    "LangGraph path: handling command '%s' natively", query,
                )
                cmd_handler = LangGraphCommandHandler(
                    history_messages=lg_context.history_messages,
                    middleware=lg_context.middleware,
                    session_store=lg_context.session_store,
                    session_id=lg_context.session_id or run_ctx.run_id,
                    user_id=lg_context.user_id,
                    channel=lg_context.channel,
                    memory_manager=(
                        self._session_factory._memory_manager
                    ),
                )
                result_msg = await cmd_handler.handle(query)
                yield result_msg, True
                return

            # ── Stage 3: Execute Agent ──
            # Convert incoming Msg objects to LangChain messages
            lc_messages = msgs_to_langchain(
                msgs if isinstance(msgs, list) else [msgs]
            )
            # Prepend history (loaded from session store)
            all_messages = lg_context.history_messages + lc_messages

            bridge = LangGraphEventBridge(emit_tool_events=True)

            async for msg, last in bridge.stream(
                lg_context.graph,
                all_messages,
                config={
                    "configurable": {
                        "thread_id": lg_context.session_id or run_ctx.run_id,
                    },
                },
            ):
                yield msg, last

            # After streaming completes, update history with the full
            # conversation (input + output) for session persistence.
            if bridge.final_output_messages:
                lg_context.history_messages = bridge.final_output_messages

        except asyncio.CancelledError:
            # PR5: graceful cancel via middleware
            if lg_context and lg_context.middleware:
                lg_context.middleware.cancel()
            raise
        except Exception as exc:  # pylint: disable=broad-except
            debug_dump_path = write_query_error_dump(
                request=request,
                exc=exc,
                locals_=locals(),
            )
            path_hint = f"\n(Details:  {debug_dump_path})" if debug_dump_path else ""
            logger.exception(
                "Error in LangGraph query handler: %s%s", exc, path_hint,
            )
            if debug_dump_path:
                setattr(exc, "debug_dump_path", debug_dump_path)
                if hasattr(exc, "add_note"):
                    exc.add_note(f"(Details:  {debug_dump_path})")
                suffix = f"\n(Details:  {debug_dump_path})"
                exc.args = (
                    (f"{exc.args[0]}{suffix}" if exc.args else suffix.strip()),
                ) + exc.args[1:]
            raise
        finally:
            # PR5: Save LangGraph session state
            if lg_context is not None:
                try:
                    await self._session_factory.save_langgraph_session_state(
                        lg_context,
                    )
                except Exception:
                    logger.exception("Failed to save LangGraph session state")

            if chat is not None:
                await self._session_factory.update_chat(chat)

