# -*- coding: utf-8 -*-
"""Session persistence with filename sanitization.

Windows filenames cannot contain: \\ / : * ? " < > |
"""

from __future__ import annotations

import json
import logging
import os
import re
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


# Characters forbidden in Windows filenames
_UNSAFE_FILENAME_RE = re.compile(r'[\\/:*?"<>|]')


def sanitize_filename(name: str) -> str:
    """Replace illegal filename chars and strip path traversal hints."""
    # Strip path separators to prevent directory traversal
    name = name.replace("..", ".")
    name = name.replace("/", ".")
    return _UNSAFE_FILENAME_RE.sub("--", name)


class SafeSession:
    """Filesystem-backed session persistence for legacy agent state."""

    def __init__(self, save_dir: str | Path) -> None:
        self.save_dir = str(save_dir)
        os.makedirs(self.save_dir, exist_ok=True)

    def _get_save_path(
        self,
        session_id: str,
        user_id: str | None,
    ) -> str:
        """Return a filesystem-safe save path."""
        os.makedirs(self.save_dir, exist_ok=True)
        safe_sid = sanitize_filename(session_id)
        safe_uid = sanitize_filename(user_id) if user_id else ""
        if safe_uid:
            file_name = f"{safe_uid}_{safe_sid}.json"
        else:
            file_name = f"{safe_sid}.json"
        return os.path.join(self.save_dir, file_name)

    async def save_session_state(
        self,
        *,
        session_id: str | None,
        user_id: str | None,
        agent: Any,
    ) -> None:
        """Save agent state to JSON."""
        if not session_id or agent is None:
            return

        payload = self._build_state_payload(agent)
        if payload is None:
            return

        path = Path(self._get_save_path(session_id, user_id))
        temp_path = path.with_suffix(path.suffix + ".tmp")

        try:
            with open(temp_path, "w", encoding="utf-8") as file:
                json.dump(payload, file, ensure_ascii=False, indent=2)
            temp_path.replace(path)
        except Exception:  # pylint: disable=broad-except
            logger.exception("Failed to save session state to %s", path)

    async def load_session_state(
        self,
        *,
        session_id: str | None,
        user_id: str | None,
        agent: Any,
    ) -> None:
        """Load agent state from JSON if it exists."""
        if not session_id or agent is None:
            return

        path = Path(self._get_save_path(session_id, user_id))
        if not path.exists():
            return

        try:
            with open(path, "r", encoding="utf-8") as file:
                payload = json.load(file)
        except Exception:  # pylint: disable=broad-except
            logger.exception("Failed to load session state from %s", path)
            return

        if isinstance(payload, dict):
            state = payload.get("agent", payload)
        else:
            state = payload

        loader = getattr(agent, "load_state_dict", None)
        if not callable(loader):
            return

        try:
            loader(state)
        except Exception:  # pylint: disable=broad-except
            logger.exception("Failed to load state_dict into agent")

    def _build_state_payload(self, agent: Any) -> dict | None:
        dumper = getattr(agent, "state_dict", None)
        if not callable(dumper):
            return None

        try:
            return {"agent": dumper()}
        except Exception:  # pylint: disable=broad-except
            logger.exception("Failed to build state_dict from agent")
            return None
