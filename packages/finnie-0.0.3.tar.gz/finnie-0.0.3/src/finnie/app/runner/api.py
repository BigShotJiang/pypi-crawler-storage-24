# -*- coding: utf-8 -*-
"""Chat management API."""

from __future__ import annotations
import json
import logging
import os
from dataclasses import dataclass

from typing import Any, Optional
from uuid import uuid4
from fastapi import APIRouter, Depends, HTTPException, Query, Request

from ...agents.langgraph.message_converter import (
    langchain_to_msgs,
    msg_to_langchain,
)
from ...agents.langgraph.session_store import LangGraphSessionStore
from ..schemas import Message
from .manager import ChatManager
from .models import (
    ChatSpec,
    ChatHistory,
)


logger = logging.getLogger(__name__)

router = APIRouter(prefix="/chats", tags=["chats"])


@dataclass
class _LegacyMessagePayload:
    role: str
    content: Any


def _extract_legacy_message(item: Any) -> _LegacyMessagePayload | None:
    raw: Any = None
    if isinstance(item, (list, tuple)) and len(item) == 2:
        raw = item[0]
    elif isinstance(item, dict):
        raw = item

    if not isinstance(raw, dict):
        return None

    return _LegacyMessagePayload(
        role=raw.get("role", "assistant"),
        content=raw.get("content", ""),
    )


def _legacy_state_to_messages(state: Any) -> list[Message]:
    if not isinstance(state, dict):
        return []

    memory_state = state.get("agent", {}).get("memory", {})
    if not isinstance(memory_state, dict):
        return []

    memory_content = memory_state.get("content", [])
    if not isinstance(memory_content, list):
        return []

    messages: list[Message] = []
    for item in memory_content:
        payload = _extract_legacy_message(item)
        if payload is None:
            continue

        try:
            converted = msg_to_langchain(payload)
        except Exception:  # pylint: disable=broad-except
            logger.exception("Failed to parse legacy message payload")
            continue

        if isinstance(converted, list):
            messages.extend(langchain_to_msgs(converted))
        else:
            messages.extend(langchain_to_msgs([converted]))
    return messages


def get_chat_manager(request: Request) -> ChatManager:
    """Get the chat manager from app state.

    Args:
        request: FastAPI request object

    Returns:
        ChatManager instance

    Raises:
        HTTPException: If manager is not initialized
    """
    mgr = getattr(request.app.state, "chat_manager", None)
    if mgr is None:
        raise HTTPException(
            status_code=503,
            detail="Chat manager not initialized",
        )
    return mgr


def get_session(request: Request) -> Any:
    """Get the session from app state.

    Args:
        request: FastAPI request object

    Returns:
        Session persistence instance

    Raises:
        HTTPException: If session is not initialized
    """
    runner = getattr(request.app.state, "runner", None)
    if runner is None:
        raise HTTPException(
            status_code=503,
            detail="Session not initialized",
        )
    return runner.session


@router.get("", response_model=list[ChatSpec])
async def list_chats(
    user_id: Optional[str] = Query(None, description="Filter by user ID"),
    channel: Optional[str] = Query(None, description="Filter by channel"),
    mgr: ChatManager = Depends(get_chat_manager),
):
    """List all chats with optional filters.

    Args:
        user_id: Optional user ID to filter chats
        channel: Optional channel name to filter chats
        mgr: Chat manager dependency
    """
    return await mgr.list_chats(user_id=user_id, channel=channel)


@router.post("", response_model=ChatSpec)
async def create_chat(
    request: ChatSpec,
    mgr: ChatManager = Depends(get_chat_manager),
):
    """Create a new chat.

    Server generates chat_id (UUID) automatically.

    Args:
        request: Chat creation request
        mgr: Chat manager dependency

    Returns:
        Created chat spec with UUID
    """
    chat_id = str(uuid4())
    spec = ChatSpec(
        id=chat_id,
        name=request.name,
        session_id=request.session_id,
        user_id=request.user_id,
        channel=request.channel,
        meta=request.meta,
    )
    return await mgr.create_chat(spec)


@router.post("/batch-delete", response_model=dict)
async def batch_delete_chats(
    chat_ids: list[str],
    mgr: ChatManager = Depends(get_chat_manager),
):
    """Delete chats by chat IDs.

    Args:
        chat_ids: List of chat IDs
        mgr: Chat manager dependency
    Returns:
        True if deleted, False if failed

    """
    deleted = await mgr.delete_chats(chat_ids=chat_ids)
    return {"deleted": deleted}


@router.get("/{chat_id}", response_model=ChatHistory)
async def get_chat(
    chat_id: str,
    mgr: ChatManager = Depends(get_chat_manager),
    session: Any = Depends(get_session),
):
    """Get detailed information about a specific chat by UUID.

    Tries LangGraph session format first (.langgraph.json), then falls
    back to legacy AgentScope format (.json).

    Args:
        chat_id: Chat UUID
        mgr: Chat manager dependency
        session: Session dependency

    Returns:
        ChatHistory with messages

    Raises:
        HTTPException: If chat not found (404)
    """
    chat_spec = await mgr.get_chat(chat_id)
    if not chat_spec:
        raise HTTPException(
            status_code=404,
            detail=f"Chat not found: {chat_id}",
        )

    # 1) Prefer LangGraph session files
    save_dir = getattr(session, "save_dir", None)
    if save_dir:
        store = LangGraphSessionStore(save_dir=save_dir)
        messages, _ = store.load(
            session_id=chat_spec.session_id,
            user_id=chat_spec.user_id,
        )
        if messages:
            return ChatHistory(messages=langchain_to_msgs(messages))

        # New-format file exists but no valid content: stop at empty history.
        # pylint: disable=protected-access
        if store._get_path(chat_spec.session_id, chat_spec.user_id).exists():
            return ChatHistory(messages=[])

    # 2) Legacy fallback ({uid}_{sid}.json)
    # pylint: disable=protected-access
    session_path = session._get_save_path(
        chat_spec.session_id,
        chat_spec.user_id,
    )

    # Validate that session_path is within the allowed save directory
    # to prevent path traversal attacks
    real_path = os.path.realpath(session_path)
    real_save_dir = os.path.realpath(session.save_dir)
    if not real_path.startswith(real_save_dir + os.sep):
        raise HTTPException(
            status_code=400,
            detail="Invalid session path",
        )

    # --- Try LangGraph format first (.langgraph.json) ---
    langgraph_path = session_path.replace(".json", ".langgraph.json")
    if os.path.exists(langgraph_path):
        try:
            messages = _load_langgraph_history(langgraph_path)
            return ChatHistory(messages=messages)
        except Exception:
            pass  # fall through to legacy format

    # --- Fallback: legacy AgentScope format (.json) ---
    try:
        with open(session_path, "r", encoding="utf-8") as file:
            state = json.load(file)
    except Exception:  # pylint: disable=broad-except
        return ChatHistory(messages=[])
    return ChatHistory(messages=_legacy_state_to_messages(state))


def _load_langgraph_history(path: str) -> list:
    """Load LangGraph session file and convert to frontend Message format.

    Args:
        path: Path to the .langgraph.json file

    Returns:
        List of Message dicts compatible with ChatHistory schema
    """
    from langchain_core.messages import (
        AIMessage,
        HumanMessage,
        SystemMessage,
        ToolMessage,
        messages_from_dict,
    )

    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    raw_messages = data.get("messages", [])
    if not raw_messages:
        return []

    lc_messages = messages_from_dict(raw_messages)
    results: list = []

    for msg in lc_messages:
        if isinstance(msg, HumanMessage):
            role = "user"
        elif isinstance(msg, SystemMessage):
            role = "system"
        elif isinstance(msg, ToolMessage):
            role = "tool"
        else:
            role = "assistant"

        content_text = msg.content if isinstance(msg.content, str) else ""
        content_blocks: list = []

        # AIMessage may have tool_calls
        if isinstance(msg, AIMessage) and msg.tool_calls:
            for tc in msg.tool_calls:
                args = tc.get("args", {})
                if isinstance(args, dict):
                    arguments = json.dumps(args, ensure_ascii=False)
                else:
                    arguments = str(args)
                content_blocks.append({
                    "type": "data",
                    "data": {
                        "name": tc.get("name", ""),
                        "call_id": tc.get("id", ""),
                        "arguments": arguments,
                    },
                })

        # ToolMessage carries tool output
        if isinstance(msg, ToolMessage):
            output = msg.content if isinstance(msg.content, str) else json.dumps(msg.content, ensure_ascii=False)
            content_blocks.append({
                "type": "data",
                "data": {
                    "name": getattr(msg, "name", ""),
                    "call_id": getattr(msg, "tool_call_id", ""),
                    "output": output,
                },
            })

        # Text content
        if content_text:
            content_blocks.append({"type": "text", "text": content_text})

        # Handle list content (e.g. multimodal blocks)
        if isinstance(msg.content, list):
            for block in msg.content:
                if isinstance(block, dict):
                    if block.get("type") == "text":
                        content_blocks.append({"type": "text", "text": block.get("text", "")})
                    elif block.get("type") == "thinking":
                        content_blocks.append({"type": "text", "text": block.get("thinking", "")})
                elif isinstance(block, str):
                    content_blocks.append({"type": "text", "text": block})

        results.append({
            "role": role,
            "content": content_blocks if content_blocks else [{"type": "text", "text": ""}],
        })

    return results


@router.put("/{chat_id}", response_model=ChatSpec)
async def update_chat(
    chat_id: str,
    spec: ChatSpec,
    mgr: ChatManager = Depends(get_chat_manager),
):
    """Update an existing chat.

    Args:
        chat_id: Chat UUID
        spec: Updated chat specification
        mgr: Chat manager dependency

    Returns:
        Updated chat spec

    Raises:
        HTTPException: If chat_id mismatch (400) or not found (404)
    """
    if spec.id != chat_id:
        raise HTTPException(
            status_code=400,
            detail="chat_id mismatch",
        )

    # Check if exists
    existing = await mgr.get_chat(chat_id)
    if not existing:
        raise HTTPException(
            status_code=404,
            detail=f"Chat not found: {chat_id}",
        )

    updated = await mgr.update_chat(spec)
    return updated


@router.delete("/{chat_id}", response_model=dict)
async def delete_chat(
    chat_id: str,
    mgr: ChatManager = Depends(get_chat_manager),
):
    """Delete a chat by UUID.

    Note: This only deletes the chat spec (UUID mapping).
    Session state file is NOT deleted.

    Args:
        chat_id: Chat UUID
        mgr: Chat manager dependency

    Returns:
        True if deleted, False if failed

    Raises:
        HTTPException: If chat not found (404)
    """
    deleted = await mgr.delete_chats(chat_ids=[chat_id])
    if not deleted:
        raise HTTPException(
            status_code=404,
            detail=f"Chat not found: {chat_id}",
        )
    return {"deleted": True}
