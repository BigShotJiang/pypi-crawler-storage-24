#! -*- coding: utf-8 -*-
"""Event bridge for streaming agent events back to runtime.

This module isolates the streaming implementation from the core runner
so that future loop implementations can swap out the underlying mechanism
without changing external behaviour.

PR4 additions:
* ``stream_langgraph_run`` — delegate to ``LangGraphEventBridge``
"""

from __future__ import annotations

import logging
from typing import Any, AsyncIterator, Optional, Sequence

logger = logging.getLogger(__name__)


class EventBridge:
    """Bridge between the agent execution loop and runtime events.

    Only the LangGraph streaming path is supported.
    """

    async def stream_langgraph_run(
        self,
        *,
        graph: Any,
        messages: Sequence[Any],
        config: Optional[dict] = None,
        emit_tool_events: bool = False,
    ) -> AsyncIterator[tuple[Any, bool]]:
        """Stream a LangGraph agent run as ``(Msg, is_last)`` tuples.

        Delegates to ``LangGraphEventBridge`` from the langgraph package
        so that the Runner layer can use a unified ``EventBridge`` API
        regardless of the backend.
        """
        from ...agents.langgraph.event_bridge import LangGraphEventBridge

        bridge = LangGraphEventBridge(emit_tool_events=emit_tool_events)
        async for msg, last in bridge.stream(graph, messages, config=config):
            yield msg, last
