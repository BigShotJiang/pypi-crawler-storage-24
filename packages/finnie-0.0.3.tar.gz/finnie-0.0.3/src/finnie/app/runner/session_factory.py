#! -*- coding: utf-8 -*-
"""Session factory for constructing per-run session context.

Responsibilities:
* Load historical session state
* Build environment context and system prompt
* Construct agent context (LangGraph path)
* Manage chat objects via the chat manager
"""

from __future__ import annotations

import logging
import os
from dataclasses import dataclass, field
from typing import Any, List, Optional

from .session import SafeSession
from .utils import build_env_context
from ..channels.schema import DEFAULT_CHANNEL
from ...config import load_config
from ...constant import (
    MEMORY_COMPACT_KEEP_RECENT,
    MEMORY_COMPACT_RATIO,
    WORKING_DIR,
)

logger = logging.getLogger(__name__)


@dataclass
class SessionContext:
    """Lightweight container for per-run session state."""

    session_id: Optional[str]
    user_id: Optional[str]
    channel: str
    env_context: str
    agent: Any  # legacy — retained for type compat
    chat: Any | None = None


@dataclass
class LangGraphSessionContext:
    """Container for the LangGraph agent path (PR4+PR5).

    Unlike ``SessionContext`` which carries a ``FinnieAgent``, this holds
    a compiled LangGraph graph, pre-assembled messages, middleware, and
    a session store for persistence.
    """

    session_id: Optional[str]
    user_id: Optional[str]
    channel: str
    env_context: str
    graph: Any  # CompiledStateGraph
    config: Any  # FinnieGraphConfig
    chat: Any | None = None
    history_messages: list = field(default_factory=list)
    # PR5 additions
    middleware: Any | None = None  # FinnieMiddleware
    session_store: Any | None = None  # LangGraphSessionStore
    compressed_summary: str = ""


class SessionFactory:
    """Factory responsible for assembling session / agent context."""

    def __init__(
        self,
        *,
        session: SafeSession,
        memory_manager: Any | None,
        chat_manager: Any | None,
    ) -> None:
        self._session = session
        self._memory_manager = memory_manager
        self._chat_manager = chat_manager

    # ------------------------------------------------------------------
    # LangGraph path (PR4 + PR5)
    # ------------------------------------------------------------------

    async def create_langgraph_context(
        self,
        *,
        msgs,
        request: Any,
        mcp_clients: List[Any],
    ) -> LangGraphSessionContext:
        """Build a ``LangGraphSessionContext`` — the new three-stage path.

        Stage 1 (this method): assemble model + tools + prompt + history
        and build the compiled graph.  No FinnieAgent is created.

        PR5: Also loads session history, creates middleware, and wires
        up the session store for persistence.
        """
        from ...agents.langgraph import (
            FinnieGraphConfig,
            build_finnie_graph,
        )
        from ...agents.langgraph.middleware import FinnieMiddleware
        from ...agents.langgraph.model_factory import create_chat_model
        from ...agents.langgraph.session_store import LangGraphSessionStore
        from ...agents.langgraph.tools import (
            create_memory_search_langchain_tool,
            load_active_skills_as_tools,
            load_builtin_tools,
            mcp_clients_to_langchain_tools,
        )
        from ...agents.prompt import build_system_prompt_from_working_dir

        session_id = request.session_id
        user_id = request.user_id
        channel = getattr(request, "channel", DEFAULT_CHANNEL)

        env_context = build_env_context(
            session_id=session_id,
            user_id=user_id,
            channel=channel,
            working_dir=str(WORKING_DIR),
        )

        app_config = load_config()
        max_iters = app_config.agents.running.max_iters
        max_input_length = app_config.agents.running.max_input_length

        # ── Model ──
        model = create_chat_model()

        # ── Tools ──
        tools: list = load_builtin_tools()
        tools.extend(load_active_skills_as_tools())

        # MCP tools
        if mcp_clients:
            try:
                mcp_tools = await mcp_clients_to_langchain_tools(mcp_clients)
                tools.extend(mcp_tools)
                logger.info("Registered %d MCP tools for LangGraph", len(mcp_tools))
            except Exception:
                logger.exception("Failed to convert MCP tools for LangGraph")

        # memory_search tool
        enable_mm = os.getenv("ENABLE_MEMORY_MANAGER", "").lower() != "false"
        if enable_mm and self._memory_manager is not None:
            # Wire LangChain model into MemoryManager so it uses
            # ChatModel.ainvoke() instead of AgentScope ReActAgent.
            self._memory_manager.langchain_chat_model = model
            tools.append(
                create_memory_search_langchain_tool(self._memory_manager),
            )

        # ── System prompt ──
        sys_prompt = build_system_prompt_from_working_dir()
        if env_context:
            sys_prompt = env_context + "\n\n" + sys_prompt

        # ── Session store & load history (PR5) ──
        session_store = LangGraphSessionStore(
            save_dir=self._session.save_dir,
        )
        history_messages, compressed_summary = session_store.load(
            session_id=session_id,
            user_id=user_id,
        )

        # ── Middleware (PR5) ──
        memory_compact_threshold = int(max_input_length * MEMORY_COMPACT_RATIO)
        middleware = FinnieMiddleware(
            working_dir=WORKING_DIR,
            language=app_config.agents.language,
            memory_manager=(
                self._memory_manager if enable_mm else None
            ),
            memory_compact_threshold=memory_compact_threshold,
            max_input_length=max_input_length,
            keep_recent=MEMORY_COMPACT_KEEP_RECENT,
            compressed_summary=compressed_summary,
            channel=channel,
            session_id=session_id or "",
        )

        # ── Build graph ──
        graph_config = FinnieGraphConfig(
            model=model,
            tools=tools,
            system_prompt=sys_prompt,
            max_iterations=max_iters,
            middleware=middleware,
        )
        graph = build_finnie_graph(graph_config)

        # ── Chat object ──
        chat = None
        name = "New Chat"
        if msgs:
            content = msgs[0].get_text_content()
            if content:
                name = content[:10]
            else:
                name = "Media Message"

        if self._chat_manager is not None:
            chat = await self._chat_manager.get_or_create_chat(
                session_id,
                user_id,
                channel,
                name=name,
            )

        return LangGraphSessionContext(
            session_id=session_id,
            user_id=user_id,
            channel=channel,
            env_context=env_context,
            graph=graph,
            config=graph_config,
            chat=chat,
            history_messages=history_messages,
            middleware=middleware,
            session_store=session_store,
            compressed_summary=compressed_summary,
        )

    # ------------------------------------------------------------------
    # Shared helpers
    # ------------------------------------------------------------------

    async def save_langgraph_session_state(
        self,
        context: LangGraphSessionContext,
        final_messages: list | None = None,
    ) -> None:
        """Persist LangGraph session state after a run completes (PR5)."""
        if context.session_store is None or context.session_id is None:
            return

        messages_to_save = final_messages or context.history_messages
        compressed_summary = (
            context.middleware.compressed_summary
            if context.middleware
            else context.compressed_summary
        )

        context.session_store.save(
            session_id=context.session_id,
            user_id=context.user_id,
            messages=messages_to_save,
            compressed_summary=compressed_summary,
        )

    async def update_chat(self, chat: Any | None) -> None:
        """Persist chat metadata if a chat object exists."""
        if self._chat_manager is None or chat is None:
            return
        await self._chat_manager.update_chat(chat)
