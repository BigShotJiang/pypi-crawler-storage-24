# -*- coding: utf-8 -*-
"""Self-built SSE event schema — replaces agentscope_runtime Event/Message/Content system.

Provides:
  - ResponseEvent  — response lifecycle (created → in_progress → completed/failed)
  - MessageEvent   — message lifecycle (in_progress → completed)
  - ContentEvent   — content delta/completed (streaming token carrier)
  - SequenceCounter — simple incrementing sequence number generator

SSE wire format is identical to agentscope_runtime so the frontend needs
no changes:
  data: {"object":"response","status":"created","sequence_number":0,...}\n\n
  data: {"object":"message","status":"in_progress","sequence_number":2,...}\n\n
  data: {"object":"content","status":"in_progress","sequence_number":3,"delta":true,"text":"你",...}\n\n
  ...

No dependency on agentscope or agentscope_runtime.
"""

from __future__ import annotations

import json
from typing import Any, List, Optional
from uuid import uuid4

from pydantic import BaseModel, Field

from .message_types import RunStatus, MessageType


# ---------------------------------------------------------------------------
# SSE Event models
# ---------------------------------------------------------------------------

class ResponseEvent(BaseModel):
    """Response lifecycle event (maps to object='response')."""

    object: str = "response"
    id: str = Field(default_factory=lambda: str(uuid4()))
    status: str = RunStatus.Created
    sequence_number: int = 0
    session_id: str = ""
    output: List[Any] = Field(default_factory=list)
    error: Optional[Any] = None

    model_config = {"extra": "allow"}


class MessageEvent(BaseModel):
    """Message lifecycle event (maps to object='message')."""

    object: str = "message"
    id: str = Field(default_factory=lambda: str(uuid4()))
    status: str = RunStatus.InProgress
    sequence_number: int = 0
    type: str = MessageType.MESSAGE
    role: str = "assistant"
    content: List[Any] = Field(default_factory=list)
    metadata: Optional[Any] = None
    error: Optional[Any] = None

    model_config = {"extra": "allow"}


class ContentEvent(BaseModel):
    """Content delta/completed event (maps to object='content').

    For streaming text tokens: delta=True, type='text', text='token'.
    For data (tool calls): type='data', data={...}.
    """

    object: str = "content"
    status: str = RunStatus.InProgress
    sequence_number: int = 0
    type: str = "text"
    delta: bool = False
    text: str = ""
    # For non-text content (data, image, file, etc.)
    data: Optional[Any] = None
    image_url: Optional[str] = None
    file_url: Optional[str] = None
    filename: Optional[str] = None
    video_url: Optional[str] = None
    msg_id: Optional[str] = None
    index: Optional[int] = None
    error: Optional[Any] = None

    model_config = {"extra": "allow"}


# ---------------------------------------------------------------------------
# Sequence counter
# ---------------------------------------------------------------------------

class SequenceCounter:
    """Simple incrementing counter, replaces SequenceNumberGenerator."""

    def __init__(self) -> None:
        self._seq = 0

    def next(self) -> int:
        val = self._seq
        self._seq += 1
        return val

    def stamp(self, event: BaseModel) -> BaseModel:
        """Set sequence_number on event and return it."""
        event.sequence_number = self.next()
        return event
