# -*- coding: utf-8 -*-
"""Finnie Agents Module.

This module provides agent utilities for building AI agents with tools,
skills, and memory management.

The LangGraph-based agent is now the sole execution path; the legacy
``FinnieAgent`` (AgentScope ``ReActAgent`` subclass) has been removed.
"""
