# -*- coding: utf-8 -*-
"""Bidirectional conversion between Finnie internal ``Message`` and LangChain messages.

This module bridges the Finnie internal message world (used by Channel /
Runner layers) and the LangChain message world (used by the LangGraph agent).

Supported block types:
    TextBlock      ↔  str content
    ThinkingBlock  ↔  AIMessage additional_kwargs["thinking"]
    ToolUseBlock   ↔  AIMessage tool_calls
    ToolResultBlock↔  ToolMessage
    ImageBlock     ↔  {"type": "image_url", "image_url": {"url": ...}}
    AudioBlock     ↔  stored in additional_kwargs (no native LangChain type)
    VideoBlock     ↔  stored in additional_kwargs (no native LangChain type)
    FileBlock      ↔  stored in additional_kwargs (Finnie extension)

The input-side functions (``msg_to_langchain``, ``msgs_to_langchain``) accept
**any object with ``.content`` and ``.role`` attributes** (duck-typing), so
they work with both the legacy AgentScope ``Msg`` and the new internal
``Message`` from ``finnie.app.schemas``.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any, List, Sequence, Union

from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)

from ...app.schemas.message_types import Message

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Msg → BaseMessage
# ---------------------------------------------------------------------------

_ROLE_TO_CLS = {
    "user": HumanMessage,
    "assistant": AIMessage,
    "system": SystemMessage,
}


def msg_to_langchain(msg: Any) -> Union[BaseMessage, List[BaseMessage]]:
    """Convert a single message to one or more LangChain messages.

    Accepts any object with ``.content`` and ``.role`` attributes (duck-typing),
    including both legacy AgentScope ``Msg`` and internal ``Message``.

    A single message may contain mixed block types (text + tool_use +
    tool_result + thinking + image …).  We split them into separate
    LangChain messages where the protocol requires it (e.g. tool_calls
    must be an ``AIMessage``, tool_results must be ``ToolMessage``).

    Returns:
        A single ``BaseMessage`` when the message maps to exactly one, or a
        ``list[BaseMessage]`` when it needs to be expanded.
    """
    # Simple string content
    if isinstance(msg.content, str):
        cls = _ROLE_TO_CLS.get(msg.role, AIMessage)
        return cls(content=msg.content)

    # Block-list content — partition into groups
    results: list[BaseMessage] = []
    text_parts: list[str] = []
    thinking_parts: list[str] = []
    image_parts: list[dict] = []
    tool_calls: list[dict] = []
    extra_kwargs: dict = {}

    for block in msg.content:
        if not isinstance(block, dict):
            # Pydantic content objects (ImageContent, TextContent, …)
            if hasattr(block, "model_dump"):
                block = block.model_dump(exclude_none=True)
            elif hasattr(block, "dict"):
                block = block.dict(exclude_none=True)
            else:
                continue
        btype = block.get("type", "")

        if btype == "text":
            # Flush any accumulated thinking as a separate AI message
            _flush_thinking(results, thinking_parts)
            text_parts.append(block.get("text", ""))

        elif btype == "thinking":
            # Flush text first
            _flush_text(results, text_parts, msg.role, image_parts)
            thinking_parts.append(block.get("thinking", ""))

        elif btype == "tool_use":
            # Flush text/thinking first
            _flush_text(results, text_parts, msg.role, image_parts)
            _flush_thinking(results, thinking_parts)
            tool_calls.append(
                {
                    "name": block.get("name", ""),
                    "args": block.get("input", {}),
                    "id": block.get("id", ""),
                }
            )

        elif btype == "tool_result":
            # Flush everything first
            _flush_text(results, text_parts, msg.role, image_parts)
            _flush_thinking(results, thinking_parts)
            _flush_tool_calls(results, tool_calls)

            output = block.get("output", "")
            if isinstance(output, (list, dict)):
                output = json.dumps(output, ensure_ascii=False)
            results.append(
                ToolMessage(
                    content=str(output),
                    tool_call_id=block.get("id", ""),
                    name=block.get("name", ""),
                )
            )

        elif btype == "image":
            # Support both formats:
            # 1. {"source": {"type": "url", "url": "..."}} (internal)
            # 2. {"image_url": "..."} (Pydantic ImageContent)
            source = block.get("source", {})
            url = _source_to_url(source) if source else ""
            if not url:
                url = block.get("image_url", "")
            if url:
                # Resolve local paths to base64 data URIs
                if url.startswith("file://"):
                    url = _file_uri_to_data_uri(
                        url, source if source else {},
                    )
                elif url.startswith("/api/files/"):
                    url = _local_api_file_to_data_uri(
                        url, source if source else {},
                    )
                image_parts.append(
                    {"type": "image_url", "image_url": {"url": url}}
                )

        elif btype == "file":
            # Convert file block to text description (LLM-readable) and
            # also keep the raw block in additional_kwargs for downstream use.
            source = block.get("source", {})
            file_path = block.get("path", "") or _source_to_url(source) or ""
            file_name = block.get("name") or block.get("filename") or file_path
            if file_name or file_path:
                text_parts.append(
                    f"[File: '{file_name}' at {file_path}]"
                    if file_path
                    else f"[File: '{file_name}']"
                )
            extra_kwargs.setdefault("file_blocks", []).append(block)

        elif btype in ("audio", "video"):
            # No native LangChain representation — store in extra_kwargs
            extra_kwargs.setdefault(f"{btype}_blocks", []).append(block)

        else:
            text_parts.append(str(block))

    # Flush remaining
    _flush_text(results, text_parts, msg.role, image_parts, extra_kwargs)
    _flush_thinking(results, thinking_parts)
    _flush_tool_calls(results, tool_calls)

    if not results:
        cls = _ROLE_TO_CLS.get(msg.role, AIMessage)
        return cls(content="")

    return results[0] if len(results) == 1 else results


def msgs_to_langchain(msgs: Sequence[Any]) -> list[BaseMessage]:
    """Convert a sequence of message objects to a flat list of LangChain messages."""
    result: list[BaseMessage] = []
    for m in msgs:
        converted = msg_to_langchain(m)
        if isinstance(converted, list):
            result.extend(converted)
        else:
            result.append(converted)
    return result


# ---------------------------------------------------------------------------
# BaseMessage → Msg
# ---------------------------------------------------------------------------


def langchain_to_msg(message: BaseMessage) -> Message:
    """Convert a single LangChain ``BaseMessage`` back to an internal ``Message``.

    This is needed by the EventBridge to yield ``(Message, is_last)`` tuples
    that the Channel / Runner layers expect.
    """
    role = _langchain_role(message)
    blocks: list[dict] = []

    # --- ToolMessage ---
    if isinstance(message, ToolMessage):
        blocks.append(
            {
                "type": "tool_result",
                "id": message.tool_call_id or "",
                "name": getattr(message, "name", "") or "",
                "output": message.content or "",
            }
        )
        return Message(role="user", content=blocks)

    # --- AIMessage with tool_calls ---
    if isinstance(message, AIMessage) and message.tool_calls:
        # There might be text content before the tool calls
        if message.content:
            _append_text_or_multimodal(blocks, message.content)
        # Add thinking if present
        thinking = (message.additional_kwargs or {}).get("thinking")
        if thinking:
            blocks.append({"type": "thinking", "thinking": thinking})
        # Add tool_calls
        for tc in message.tool_calls:
            blocks.append(
                {
                    "type": "tool_use",
                    "id": tc.get("id", ""),
                    "name": tc.get("name", ""),
                    "input": tc.get("args", {}),
                }
            )
        return Message(role="assistant", content=blocks)

    # --- Regular message ---
    content = message.content

    # Check for thinking in additional_kwargs
    thinking = (message.additional_kwargs or {}).get("thinking")

    if thinking and not content:
        blocks.append({"type": "thinking", "thinking": thinking})
        return Message(role=role, content=blocks)

    if thinking and content:
        blocks.append({"type": "thinking", "thinking": thinking})
        _append_text_or_multimodal(blocks, content)
        return Message(role=role, content=blocks)

    # Simple text or multimodal
    if isinstance(content, str):
        return Message(role=role, content=[{"type": "text", "text": content}])

    # List content (LangChain multimodal format)
    if isinstance(content, list):
        for part in content:
            if isinstance(part, str):
                blocks.append({"type": "text", "text": part})
            elif isinstance(part, dict):
                _langchain_part_to_block(blocks, part)
        return Message(role=role, content=blocks if blocks else [])

    return Message(role=role, content=[{"type": "text", "text": str(content) if content else ""}])


def langchain_to_msgs(messages: Sequence[BaseMessage]) -> list[Message]:
    """Convert a list of LangChain messages to internal ``Message`` objects."""
    return [langchain_to_msg(m) for m in messages]


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _source_to_url(source: dict) -> str:
    """Convert an image/audio source dict to a URL string.

    For ``file://`` URLs and local ``/api/files/`` paths, the local
    file is read and returned as a ``data:`` URI so that LLM providers
    (which cannot access local file-system paths) can still receive the
    image content.
    """
    src_type = source.get("type", "")
    if src_type == "url":
        url = source.get("url", "")
        if url.startswith("file://"):
            return _file_uri_to_data_uri(url, source)
        if url.startswith("/api/files/"):
            return _local_api_file_to_data_uri(url, source)
        return url
    if src_type == "base64":
        media_type = source.get("media_type", "application/octet-stream")
        data = source.get("data", "")
        return f"data:{media_type};base64,{data}"
    return ""


def _file_uri_to_data_uri(file_url: str, source: dict) -> str:
    """Read a ``file://`` URI and return a ``data:`` base64 URI."""
    import base64
    import mimetypes
    from urllib.parse import unquote
    from urllib.request import url2pathname

    try:
        # file:///path/to/img.png → /path/to/img.png
        local_path = url2pathname(unquote(file_url[7:]))  # strip "file://"
        if not os.path.isfile(local_path):
            logger.warning("_file_uri_to_data_uri: file not found: %s", local_path)
            return file_url  # fallback to original

        media_type = source.get("media_type", "")
        if not media_type:
            media_type = mimetypes.guess_type(local_path)[0] or "application/octet-stream"

        with open(local_path, "rb") as f:
            data = base64.b64encode(f.read()).decode("ascii")

        return f"data:{media_type};base64,{data}"
    except Exception as e:
        logger.warning("_file_uri_to_data_uri failed for %s: %s", file_url, e)
        return file_url


def _local_api_file_to_data_uri(api_url: str, source: dict) -> str:
    """Resolve a ``/api/files/<name>`` path to a ``data:`` base64 URI.

    These URLs are returned by the local upload endpoint and point to
    files stored in ``UPLOADS_DIR``.
    """
    import base64
    import mimetypes

    try:
        from ...constant import UPLOADS_DIR

        # /api/files/abc123.png → abc123.png
        filename = api_url.split("/api/files/", 1)[-1]
        if not filename or ".." in filename or filename.startswith("/"):
            return api_url

        local_path = str((UPLOADS_DIR / filename).resolve())
        if not os.path.isfile(local_path):
            logger.warning(
                "_local_api_file_to_data_uri: file not found: %s", local_path,
            )
            return api_url

        media_type = source.get("media_type", "")
        if not media_type:
            media_type = mimetypes.guess_type(local_path)[0] or "application/octet-stream"

        with open(local_path, "rb") as f:
            data = base64.b64encode(f.read()).decode("ascii")

        return f"data:{media_type};base64,{data}"
    except Exception as e:
        logger.warning("_local_api_file_to_data_uri failed for %s: %s", api_url, e)
        return api_url


def _flush_text(
    results: list[BaseMessage],
    text_parts: list[str],
    role: str,
    image_parts: list[dict],
    extra_kwargs: dict | None = None,
) -> None:
    """Flush accumulated text (and image) parts as a single message."""
    if not text_parts and not image_parts:
        return

    content: str | list
    if image_parts:
        # Multimodal: mix text + images
        parts: list[dict] = []
        if text_parts:
            parts.append({"type": "text", "text": "\n".join(text_parts)})
        parts.extend(image_parts)
        content = parts
    else:
        content = "\n".join(text_parts)

    cls = _ROLE_TO_CLS.get(role, AIMessage)
    kwargs = {}
    if extra_kwargs:
        kwargs["additional_kwargs"] = dict(extra_kwargs)
    results.append(cls(content=content, **kwargs))
    text_parts.clear()
    image_parts.clear()
    if extra_kwargs is not None:
        extra_kwargs.clear()


def _flush_thinking(
    results: list[BaseMessage],
    thinking_parts: list[str],
) -> None:
    """Flush accumulated thinking parts as an AIMessage."""
    if not thinking_parts:
        return
    results.append(
        AIMessage(
            content="",
            additional_kwargs={"thinking": "\n".join(thinking_parts)},
        )
    )
    thinking_parts.clear()


def _flush_tool_calls(
    results: list[BaseMessage],
    tool_calls: list[dict],
) -> None:
    """Flush accumulated tool_calls as an AIMessage."""
    if not tool_calls:
        return
    results.append(AIMessage(content="", tool_calls=list(tool_calls)))
    tool_calls.clear()


def _langchain_role(message: BaseMessage) -> str:
    """Map a LangChain message type to a role string."""
    if isinstance(message, HumanMessage):
        return "user"
    if isinstance(message, SystemMessage):
        return "system"
    if isinstance(message, ToolMessage):
        return "user"
    return "assistant"


def _append_text_or_multimodal(blocks: list[dict], content) -> None:
    """Append text or multimodal content parts to blocks list."""
    if isinstance(content, str):
        if content:
            blocks.append({"type": "text", "text": content})
    elif isinstance(content, list):
        for part in content:
            if isinstance(part, str):
                blocks.append({"type": "text", "text": part})
            elif isinstance(part, dict):
                _langchain_part_to_block(blocks, part)


def _langchain_part_to_block(blocks: list[dict], part: dict) -> None:
    """Convert a single LangChain content part dict to an internal block."""
    ptype = part.get("type", "")
    if ptype == "text":
        blocks.append({"type": "text", "text": part.get("text", "")})
    elif ptype == "image_url":
        url = part.get("image_url", {}).get("url", "")
        if url.startswith("data:"):
            # data URI → Base64Source
            try:
                header, data = url.split(",", 1)
                media_type = header.split(":")[1].split(";")[0]
                blocks.append(
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "media_type": media_type,
                            "data": data,
                        },
                    }
                )
            except (ValueError, IndexError):
                blocks.append(
                    {
                        "type": "image",
                        "source": {"type": "url", "url": url},
                    }
                )
        else:
            blocks.append(
                {"type": "image", "source": {"type": "url", "url": url}}
            )
    else:
        # Fallback: store as text
        blocks.append({"type": "text", "text": str(part)})
