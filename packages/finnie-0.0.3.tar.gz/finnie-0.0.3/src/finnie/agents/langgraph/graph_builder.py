# -*- coding: utf-8 -*-
"""Build a LangGraph ReAct agent graph from FinnieGraphConfig.

This is the single entry point for constructing the compiled graph.
It wraps ``create_agent`` from ``langchain.agents`` and applies
Finnie-specific settings (system prompt, recursion limit, middleware).

Example:
    >>> from finnie.agents.langgraph import build_finnie_graph, FinnieGraphConfig
    >>> config = FinnieGraphConfig(model=model, tools=[...])
    >>> graph = build_finnie_graph(config)
    >>> result = graph.invoke({"messages": [("user", "hello")]})
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from langchain.agents import create_agent

if TYPE_CHECKING:
    from langgraph.graph.state import CompiledStateGraph

    from .config import FinnieGraphConfig


def build_finnie_graph(
    config: "FinnieGraphConfig",
) -> "CompiledStateGraph":
    """Build and compile a LangGraph ReAct agent.

    Args:
        config: Finnie graph configuration containing model, tools,
            system prompt, iteration limits, and optional middleware.

    Returns:
        A compiled LangGraph state graph, ready for ``.invoke()``
        or ``.astream_events()``.
    """
    graph = create_agent(
        model=config.model,
        tools=list(config.tools),
        system_prompt=config.system_prompt or None,
        middleware=[config.middleware] if config.middleware else (),
    )
    return graph
