# -*- coding: utf-8 -*-
"""LangGraph-based agent implementation for Finnie.

This package provides the LangGraph migration path, coexisting with
the original AgentScope-based agent until the migration is complete.
"""

from .config import FinnieGraphConfig
from .event_bridge import LangGraphEventBridge
from .graph_builder import build_finnie_graph
from .message_converter import (
    langchain_to_msg,
    langchain_to_msgs,
    msg_to_langchain,
    msgs_to_langchain,
)
from .model_factory import create_chat_model

__all__ = [
    "FinnieGraphConfig",
    "LangGraphEventBridge",
    "build_finnie_graph",
    "create_chat_model",
    "langchain_to_msg",
    "langchain_to_msgs",
    "msg_to_langchain",
    "msgs_to_langchain",
]
