# -*- coding: utf-8 -*-
"""LangGraph session persistence — save/load LangChain messages to JSON.

This module provides the same session persistence semantics as
``SafeJSONSession`` but for LangChain ``BaseMessage`` objects instead
of AgentScope ``Msg`` objects.  It reuses the same directory and file
naming scheme so old and new sessions coexist.

Stored format per session::

    {
        "messages": [
            {"type": "human", "content": "...", ...},
            {"type": "ai",    "content": "...", "tool_calls": [...], ...},
            ...
        ],
        "compressed_summary": "..."
    }
"""

from __future__ import annotations

import json
import logging
import os
import re
from pathlib import Path
from typing import Any, Sequence

from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
    messages_from_dict,
    messages_to_dict,
)

logger = logging.getLogger(__name__)

# Characters forbidden in Windows filenames
_UNSAFE_FILENAME_RE = re.compile(r'[\\/:*?"<>|]')


def _sanitize(name: str) -> str:
    return _UNSAFE_FILENAME_RE.sub("--", name)


class LangGraphSessionStore:
    """JSON-file session store for LangGraph messages.

    Mirrors ``SafeJSONSession`` but operates on LangChain messages.
    Files are stored as ``{user_id}_{session_id}.langgraph.json``
    to avoid collision with the AgentScope session files.
    """

    def __init__(self, save_dir: str | Path) -> None:
        self._save_dir = Path(save_dir)
        self._save_dir.mkdir(parents=True, exist_ok=True)

    def _get_path(self, session_id: str, user_id: str | None) -> Path:
        safe_sid = _sanitize(session_id)
        safe_uid = _sanitize(user_id) if user_id else ""
        if safe_uid:
            filename = f"{safe_uid}_{safe_sid}.langgraph.json"
        else:
            filename = f"{safe_sid}.langgraph.json"
        return self._save_dir / filename

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load(
        self,
        session_id: str,
        user_id: str | None = None,
    ) -> tuple[list[BaseMessage], str]:
        """Load session history and compressed summary from disk.

        Returns:
            Tuple of (messages, compressed_summary).
            If no session file exists, returns ([], "").
        """
        path = self._get_path(session_id, user_id)
        if not path.exists():
            return [], ""

        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)

            raw_messages = data.get("messages", [])
            messages = messages_from_dict(raw_messages)
            compressed_summary = data.get("compressed_summary", "")

            logger.debug(
                "Loaded %d messages from %s", len(messages), path.name,
            )
            return messages, compressed_summary
        except Exception:
            logger.exception("Failed to load session from %s", path)
            return [], ""

    def save(
        self,
        session_id: str,
        user_id: str | None,
        messages: Sequence[BaseMessage],
        compressed_summary: str = "",
    ) -> None:
        """Persist session messages and compressed summary to disk."""
        path = self._get_path(session_id, user_id)
        try:
            data = {
                "messages": messages_to_dict(list(messages)),
                "compressed_summary": compressed_summary,
            }
            # Atomic write: write to tmp then rename
            tmp_path = path.with_suffix(".tmp")
            with open(tmp_path, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            tmp_path.replace(path)
            logger.debug(
                "Saved %d messages to %s", len(messages), path.name,
            )
        except Exception:
            logger.exception("Failed to save session to %s", path)

    def clear(
        self,
        session_id: str,
        user_id: str | None = None,
    ) -> None:
        """Delete the session file."""
        path = self._get_path(session_id, user_id)
        if path.exists():
            path.unlink()
            logger.debug("Cleared session file %s", path.name)
