# -*- coding: utf-8 -*-
"""LangGraph Middleware — implemented as agent middleware.

This module provides ``FinnieMiddleware`` which integrates:
* **Bootstrap**: first-interaction guidance injection
* **Memory Compaction**: automatic context compression when token limit is near
* **Graceful Cancel**: check a cancel flag before each LLM call

These correspond 1:1 with the AgentScope hooks in
``agents/hooks/bootstrap.py`` and ``agents/hooks/memory_compaction.py``.

The middleware is passed as the ``middleware`` parameter to
``create_agent`` (from ``langchain.agents``), which calls it before
every LLM invocation — the same hook point as AgentScope's
``pre_reasoning``.
"""

from __future__ import annotations

import asyncio
import logging
import os
from pathlib import Path
from typing import TYPE_CHECKING, Any, Sequence

from langchain.agents.middleware import AgentMiddleware
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    RemoveMessage,
    SystemMessage,
    ToolMessage,
)
from langgraph.graph.message import REMOVE_ALL_MESSAGES

from ..utils.tool_message_utils import _truncate_text as _truncate_text_impl
from .message_sanitizer import sanitize_tool_messages

if TYPE_CHECKING:
    from ..memory import MemoryManager

logger = logging.getLogger(__name__)

_DEFAULT_MAX_TOOL_OUTPUT_LENGTH = 10000


def _count_tokens_estimate(messages: Sequence[BaseMessage]) -> int:
    """Quick token estimate: 1 token ≈ 4 chars.

    This mirrors the fallback in ``safe_count_str_tokens`` and avoids
    importing the full tokenizer on every call.
    """
    total = 0
    for m in messages:
        content = m.content
        if isinstance(content, str):
            total += len(content) // 4
        elif isinstance(content, list):
            for part in content:
                if isinstance(part, str):
                    total += len(part) // 4
                elif isinstance(part, dict):
                    total += len(str(part)) // 4
    return total


def _truncate_tool_outputs(
    messages: list[BaseMessage],
    max_length: int | None = None,
) -> list[BaseMessage]:
    """Truncate long ToolMessage content in-place (layer 1).

    For each ``ToolMessage`` whose content exceeds *max_length*, replace it
    with a head+tail truncation (same algorithm as AgentScope path).
    """
    if max_length is None:
        max_length = int(
            os.environ.get(
                "MAX_FORMATTER_TEXT_LENGTH",
                _DEFAULT_MAX_TOOL_OUTPUT_LENGTH,
            ),
        )

    for msg in messages:
        if not isinstance(msg, ToolMessage):
            continue
        content = msg.content
        if isinstance(content, str) and len(content) > max_length:
            msg.content = _truncate_text_impl(content, max_length)
        elif isinstance(content, list):
            for i, part in enumerate(content):
                if isinstance(part, str) and len(part) > max_length:
                    content[i] = _truncate_text_impl(part, max_length)
                elif isinstance(part, dict):
                    text = part.get("text", "")
                    if isinstance(text, str) and len(text) > max_length:
                        part["text"] = _truncate_text_impl(text, max_length)
    return messages


def _enforce_token_budget(
    messages: list[BaseMessage],
    max_input_length: int,
) -> list[BaseMessage]:
    """Drop oldest non-system messages when total tokens exceed budget (layer 2).

    Iterates from newest to oldest; once the running total exceeds
    *max_input_length* the remaining older messages are discarded.

    Always preserves ``SystemMessage`` messages regardless of position.
    """
    # Separate system messages (always kept)
    sys_msgs: list[BaseMessage] = []
    non_sys: list[BaseMessage] = []
    for m in messages:
        if isinstance(m, SystemMessage):
            sys_msgs.append(m)
        else:
            non_sys.append(m)

    # Walk from newest → oldest, accumulate token budget
    budget = max_input_length - _count_tokens_estimate(sys_msgs)
    if budget <= 0:
        logger.warning(
            "System messages alone exceed max_input_length (%d), "
            "returning only system messages + last message",
            max_input_length,
        )
        return sys_msgs + (non_sys[-1:] if non_sys else [])

    kept: list[BaseMessage] = []
    running = 0
    for msg in reversed(non_sys):
        msg_tokens = _count_tokens_estimate([msg])
        if running + msg_tokens > budget:
            logger.info(
                "Token budget reached (~%d / %d tokens). "
                "Dropping %d older message(s).",
                running,
                max_input_length,
                len(non_sys) - len(kept),
            )
            break
        running += msg_tokens
        kept.append(msg)

    kept.reverse()
    return sys_msgs + kept


class FinnieMiddleware(AgentMiddleware):
    """Unified middleware for Bootstrap, Memory Compaction, and Cancel.

    Inherits from ``AgentMiddleware`` so it can be passed directly in
    the ``middleware`` sequence of ``create_agent``.

    Usage::

        mw = FinnieMiddleware(...)
        graph = create_agent(model=..., tools=..., middleware=[mw])
    """

    # AgentMiddleware expects a `tools` attribute (Sequence[BaseTool]).
    tools: Sequence = ()

    def __init__(
        self,
        *,
        working_dir: Path,
        language: str = "zh",
        memory_manager: "MemoryManager | None" = None,
        memory_compact_threshold: int = 90000,
        max_input_length: int = 131072,
        keep_recent: int = 3,
        compressed_summary: str = "",
        channel: str = "",
        session_id: str = "",
    ) -> None:
        self._working_dir = working_dir
        self._language = language
        self._memory_manager = memory_manager
        self._compact_threshold = memory_compact_threshold
        self._max_input_length = max_input_length
        self._keep_recent = keep_recent
        self._cancelled = False
        self._bootstrap_done = False
        self._compressed_summary = compressed_summary
        self._channel = channel
        self._session_id = session_id

    # -- Public API --------------------------------------------------------

    @property
    def compressed_summary(self) -> str:
        return self._compressed_summary

    @compressed_summary.setter
    def compressed_summary(self, value: str) -> None:
        self._compressed_summary = value

    def cancel(self) -> None:
        """Signal cancellation — the next ``abefore_model`` will raise."""
        self._cancelled = True

    async def abefore_model(self, state: Any, runtime: Any = None) -> dict[str, Any] | None:
        """Called before every LLM invocation inside the ReAct loop.

        This implements the ``AgentMiddleware.abefore_model`` hook.

        Returns:
            A state update dict. When memory compaction occurs the
            ``messages`` key is overwritten (permanently updating the
            graph state).  Otherwise ``llm_input_messages`` is returned
            so the LLM receives the modified messages without mutating
            the graph state.
        """
        messages: list[BaseMessage] = list(state.get("messages", []))

        # 1. Cancel check
        if self._cancelled:
            raise asyncio.CancelledError("Agent interrupted by user")

        # 2. Truncate long tool outputs (layer 1)
        messages = _truncate_tool_outputs(messages)

        # 3. Sanitize orphan tool messages (ensure tool_calls ↔ ToolMessage pairing)
        messages = sanitize_tool_messages(messages)

        # 4. Bootstrap guidance (first interaction only)
        messages = self._maybe_inject_bootstrap(messages)

        # 5. Memory compaction (if token count exceeds threshold)
        compacted, messages = await self._maybe_compact(messages)

        if compacted:
            # Compaction happened — permanently replace messages in state
            # and prepend summary into the new reduced message list.
            messages = self._maybe_prepend_summary(messages)
            return {"messages": [RemoveMessage(id=REMOVE_ALL_MESSAGES), *messages]}

        # 6. Prepend compressed summary (if exists) — only for LLM input
        messages = self._maybe_prepend_summary(messages)

        # 7. Enforce token budget hard cutoff (layer 2)
        messages = _enforce_token_budget(messages, self._max_input_length)

        # 8. Re-sanitize after budget trimming (trimming may create new orphans)
        messages = sanitize_tool_messages(messages)

        # No compaction — use llm_input_messages so graph state stays intact
        return {"llm_input_messages": messages}

    # -- Bootstrap ---------------------------------------------------------

    def _maybe_inject_bootstrap(
        self,
        messages: list[BaseMessage],
    ) -> list[BaseMessage]:
        """Inject bootstrap guidance into first user message if applicable."""
        if self._bootstrap_done:
            return messages

        bootstrap_path = self._working_dir / "BOOTSTRAP.md"
        bootstrap_flag = self._working_dir / ".bootstrap_completed"

        if bootstrap_flag.exists() or not bootstrap_path.exists():
            self._bootstrap_done = True
            return messages

        # Check if this is the first user interaction
        user_msgs = [m for m in messages if isinstance(m, HumanMessage)]
        assistant_msgs = [m for m in messages if isinstance(m, AIMessage)]
        if not user_msgs or assistant_msgs:
            return messages

        try:
            from ..prompt import build_bootstrap_guidance

            guidance = build_bootstrap_guidance(self._language)
            if not guidance:
                self._bootstrap_done = True
                return messages

            # Prepend guidance to the first user message
            result = []
            injected = False
            for m in messages:
                if not injected and isinstance(m, HumanMessage):
                    new_content = f"{guidance}\n\n{m.content}" if isinstance(m.content, str) else m.content
                    result.append(HumanMessage(content=new_content))
                    injected = True
                else:
                    result.append(m)

            # Mark bootstrap as completed
            bootstrap_flag.touch()
            self._bootstrap_done = True
            logger.info("Bootstrap guidance injected into first user message")
            return result
        except Exception:
            logger.exception("Failed to inject bootstrap guidance")
            self._bootstrap_done = True
            return messages

    # -- Compressed Summary ------------------------------------------------

    def _maybe_prepend_summary(
        self,
        messages: list[BaseMessage],
    ) -> list[BaseMessage]:
        """Prepend compressed summary as a context message if available."""
        if not self._compressed_summary:
            return messages

        # Check if summary is already prepended (avoid duplicates)
        for m in messages:
            if isinstance(m, HumanMessage) and "<previous-summary>" in (
                m.content if isinstance(m.content, str) else ""
            ):
                return messages

        summary_msg = HumanMessage(
            content=(
                f"<previous-summary>\n"
                f"{self._compressed_summary}\n"
                f"</previous-summary>\n"
                f"The above is a summary of our previous conversation. "
                f"Use it as context to maintain continuity."
            ),
        )

        # Insert after system messages, before other messages
        sys_count = sum(1 for m in messages if isinstance(m, SystemMessage))
        return messages[:sys_count] + [summary_msg] + messages[sys_count:]

    # -- Memory Compaction -------------------------------------------------

    async def _maybe_compact(
        self,
        messages: list[BaseMessage],
    ) -> tuple[bool, list[BaseMessage]]:
        """Compact messages if token count exceeds threshold.

        Returns:
            A tuple ``(compacted, messages)`` where *compacted* is True
            when compaction actually happened.
        """
        if self._memory_manager is None:
            return False, messages

        # Separate system messages
        sys_msgs: list[BaseMessage] = []
        rest: list[BaseMessage] = []
        for m in messages:
            if isinstance(m, SystemMessage):
                sys_msgs.append(m)
            else:
                rest.append(m)

        if len(rest) <= self._keep_recent:
            return False, messages

        # Estimate tokens for compactable portion
        compactable = rest[: -self._keep_recent] if self._keep_recent > 0 else rest
        recent = rest[-self._keep_recent:] if self._keep_recent > 0 else []

        token_count = _count_tokens_estimate(compactable)
        if token_count <= self._compact_threshold:
            return False, messages

        logger.info(
            "Memory compaction triggered: ~%d tokens (threshold: %d), "
            "compacting %d messages, keeping %d recent",
            token_count,
            self._compact_threshold,
            len(compactable),
            len(recent),
        )

        try:
            # Convert LangChain messages to internal Message for MemoryManager
            from .message_converter import langchain_to_msgs

            internal_msgs = langchain_to_msgs(compactable)

            # Start async summary task
            self._memory_manager.add_async_summary_task(
                messages=internal_msgs,
                channel=self._channel,
                session_id=self._session_id,
            )

            # Compact memory
            compact_content = await self._memory_manager.compact_memory(
                messages_to_summarize=internal_msgs,
                previous_summary=self._compressed_summary,
            )

            self._compressed_summary = compact_content
            logger.info("Memory compacted. Summary: %s...", compact_content[:100])

            # Rebuild: sys_msgs + recent (summary will be prepended by caller)
            return True, sys_msgs + recent

        except Exception:
            logger.exception("Memory compaction failed, continuing with full history")
            return False, messages
