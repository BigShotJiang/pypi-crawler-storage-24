# -*- coding: utf-8 -*-
"""LangGraph EventBridge — streams LangGraph events as ``(Message, is_last)`` tuples.

This module is a **drop-in replacement** for the AgentScope-based
``EventBridge`` in ``app/runner/event_bridge.py``.  It consumes the
``astream_events`` (v2) stream from a compiled LangGraph graph and
yields ``(Message, is_last)`` tuples with exactly the same semantics the
Channel / Runner layers expect.

Event mapping (LangGraph v2 → Message):
    on_chat_model_stream   → Message(role="assistant", text chunk)   [is_last=False]
    on_tool_start          → (optionally logged, not yielded)
    on_tool_end            → Message(role="user", ToolResultBlock)   [is_last=False]
    on_chain_end(LangGraph)→ final Message from output messages      [is_last=True]

Usage:
    >>> bridge = LangGraphEventBridge()
    >>> async for msg, last in bridge.stream(graph, messages):
    ...     channel.send(msg, is_last=last)
"""

from __future__ import annotations

import logging
import warnings
from typing import TYPE_CHECKING, Any, AsyncIterator, Optional, Sequence

from ...app.schemas.message_types import Message

from .message_converter import langchain_to_msg

if TYPE_CHECKING:
    from langchain_core.messages import BaseMessage

logger = logging.getLogger(__name__)


class LangGraphEventBridge:
    """Bridge LangGraph ``astream_events`` to ``(Message, is_last)`` tuples.

    This keeps the external contract identical to the original
    ``EventBridge.stream_agent_run`` so that Channels, RunController
    and session-saving logic need **zero** changes.
    """

    def __init__(
        self,
        *,
        emit_tool_events: bool = False,
        stream_version: str = "v2",
    ) -> None:
        """
        Args:
            emit_tool_events: If ``True``, tool start/end events are
                also yielded as Msg.  Defaults to ``False`` (only LLM
                stream tokens and the final message are emitted).
            stream_version: astream_events version. ``"v2"`` recommended.
        """
        self._emit_tool_events = emit_tool_events
        self._stream_version = stream_version
        # PR5: capture final output messages for session persistence
        self.final_output_messages: list = []

    async def stream(
        self,
        graph: Any,
        messages: Sequence[Any],
        config: Optional[dict] = None,
    ) -> AsyncIterator[tuple[Message, bool]]:
        """Stream a LangGraph agent run, yielding ``(Message, is_last)`` tuples.

        This is the main entry point — analogous to the old
        ``EventBridge.stream_agent_run(agent=..., msgs=...)``.

        Args:
            graph: A compiled LangGraph graph (``CompiledStateGraph``).
            messages: The input messages — either LangChain ``BaseMessage``
                list or ``("role", "content")`` tuples.
            config: Optional ``RunnableConfig`` dict, e.g.
                ``{"configurable": {"thread_id": "..."}}``.

        Yields:
            ``(Message, is_last)`` — an internal ``Message`` and a bool indicating
            whether this is the final message of the run.
        """
        final_result: dict | None = None
        text_buffer: list[str] = []

        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", category=DeprecationWarning)

            async for event in graph.astream_events(
                {"messages": list(messages)},
                config=config or {},
                version=self._stream_version,
            ):
                kind = event.get("event", "")

                # ── LLM streaming token ──
                if kind == "on_chat_model_stream":
                    chunk = event.get("data", {}).get("chunk")
                    if chunk is None:
                        continue

                    content = getattr(chunk, "content", None)
                    if content and isinstance(content, str):
                        text_buffer.append(content)
                        yield Message(
                            role="assistant",
                            content=[{"type": "text", "text": content}],
                        ), False

                    # Handle thinking blocks in streaming
                    thinking = (
                        getattr(chunk, "additional_kwargs", {}) or {}
                    ).get("thinking")
                    if thinking:
                        yield Message(
                            role="assistant",
                            content=[
                                {"type": "thinking", "thinking": thinking}
                            ],
                        ), False

                # ── Tool execution events ──
                elif kind == "on_tool_start" and self._emit_tool_events:
                    tool_name = event.get("name", "unknown")
                    tool_input = event.get("data", {}).get("input", {})
                    yield Message(
                        role="assistant",
                        content=[
                            {
                                "type": "tool_use",
                                "id": event.get("run_id", ""),
                                "name": tool_name,
                                "input": tool_input
                                if isinstance(tool_input, dict)
                                else {"input": str(tool_input)},
                            }
                        ],
                    ), False

                elif kind == "on_tool_end" and self._emit_tool_events:
                    tool_output = event.get("data", {}).get("output", "")
                    if hasattr(tool_output, "content"):
                        tool_output = tool_output.content
                    yield Message(
                        role="user",
                        content=[
                            {
                                "type": "tool_result",
                                "id": event.get("run_id", ""),
                                "name": event.get("name", ""),
                                "output": str(tool_output),
                            }
                        ],
                    ), False

                # ── Graph execution complete ──
                elif kind == "on_chain_end" and event.get("name") == "LangGraph":
                    output = event.get("data", {}).get("output", {})
                    final_messages = output.get("messages", [])
                    if final_messages:
                        final_result = final_messages[-1]
                        # PR5: capture all output messages for persistence
                        self.final_output_messages = list(final_messages)

        # ── Yield final message ──
        if final_result is not None:
            final_msg = langchain_to_msg(final_result)
            yield final_msg, True
        else:
            # Fallback: assemble from buffer
            full_text = "".join(text_buffer) if text_buffer else ""
            yield Message(
                role="assistant",
                content=[{"type": "text", "text": full_text}],
            ), True

    async def stream_agent_run(
        self,
        *,
        graph: Any,
        messages: Sequence[Any],
        config: Optional[dict] = None,
    ) -> AsyncIterator[tuple[Message, bool]]:
        """Alias matching the old ``EventBridge.stream_agent_run`` signature.

        This exists for compatibility so ``RunController`` can call the
        same method name whether using the old or new bridge.
        """
        async for msg, last in self.stream(graph, messages, config=config):
            yield msg, last
