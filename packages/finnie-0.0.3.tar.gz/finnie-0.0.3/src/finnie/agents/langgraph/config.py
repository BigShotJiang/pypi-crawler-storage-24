# -*- coding: utf-8 -*-
"""Configuration dataclass for the LangGraph-based Finnie agent."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Optional, Sequence

if TYPE_CHECKING:
    from langchain_core.language_models import BaseChatModel
    from langchain_core.tools import BaseTool

    from .middleware import FinnieMiddleware


@dataclass
class FinnieGraphConfig:
    """All parameters needed to build and run a Finnie LangGraph agent.

    Attributes:
        model: A LangChain-compatible chat model instance.
        tools: Sequence of LangChain tools to bind to the agent.
        system_prompt: The system prompt injected as the first message.
        max_iterations: Maximum ReAct loop iterations (maps to
            ``recursion_limit`` in LangGraph).
        middleware: Optional FinnieMiddleware instance for hooks (PR5).
    """

    model: "BaseChatModel"
    tools: Sequence["BaseTool"] = field(default_factory=list)
    system_prompt: str = ""
    max_iterations: int = 50
    middleware: Optional["FinnieMiddleware"] = None
