# -*- coding: utf-8 -*-
"""LangChain-compatible wrapper for the memory_search tool.

Uses the same factory pattern as the original: accepts a
``MemoryManager`` instance and returns a bound tool.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from langchain_core.tools import StructuredTool

if TYPE_CHECKING:
    from ...memory.memory_manager import MemoryManager


def create_memory_search_langchain_tool(
    memory_manager: "MemoryManager",
) -> StructuredTool:
    """Create a LangChain tool for semantic memory search.

    Args:
        memory_manager: A ``MemoryManager`` instance to delegate searches to.

    Returns:
        A ``StructuredTool`` that wraps ``memory_manager.memory_search()``.
    """

    async def _arun(
        query: str,
        max_results: int = 5,
        min_score: float = 0.1,
    ) -> str:
        """Search MEMORY.md and memory/*.md files semantically.

        Use this tool before answering questions about prior work, decisions,
        dates, people, preferences, or todos. Returns top relevant snippets
        with file paths and line numbers.

        Args:
            query: The semantic search query.
            max_results: Maximum number of results (default 5).
            min_score: Minimum similarity score (default 0.1).
        """
        if memory_manager is None:
            return "Error: Memory manager is not enabled."

        try:
            resp = await memory_manager.memory_search(
                query=query,
                max_results=max_results,
                min_score=min_score,
            )
            # memory_manager.memory_search returns ToolResponse (agentscope)
            # until PR6 migrates MemoryManager. Duck-type extract text.
            try:
                blocks = resp.content
                texts = [b["text"] for b in blocks if isinstance(b, dict) and "text" in b]
                return "\n".join(texts) if texts else str(resp)
            except (AttributeError, TypeError):
                return str(resp)
        except Exception as e:
            return f"Error: Memory search failed due to\n{e}"

    def _run(
        query: str,
        max_results: int = 5,
        min_score: float = 0.1,
    ) -> str:
        raise NotImplementedError("memory_search is async-only")

    return StructuredTool.from_function(
        func=_run,
        coroutine=_arun,
        name="memory_search",
        description=(
            "Search MEMORY.md and memory/*.md files semantically. "
            "Use before answering questions about prior work, decisions, "
            "dates, people, preferences, or todos."
        ),
    )
