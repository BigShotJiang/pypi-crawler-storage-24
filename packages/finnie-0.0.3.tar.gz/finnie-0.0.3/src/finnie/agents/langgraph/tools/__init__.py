# -*- coding: utf-8 -*-
"""LangChain-compatible tool wrappers for the LangGraph agent.

This package wraps Finnie's existing tool implementations as LangChain
``BaseTool`` instances so they can be used with ``create_agent``.

Usage:
    >>> from finnie.agents.langgraph.tools import load_builtin_tools
    >>> tools = load_builtin_tools()
"""

from .builtins import load_builtin_tools
from .mcp import mcp_clients_to_langchain_tools
from .memory import create_memory_search_langchain_tool
from .skills import load_active_skills_as_tools

__all__ = [
    "load_builtin_tools",
    "load_active_skills_as_tools",
    "create_memory_search_langchain_tool",
    "mcp_clients_to_langchain_tools",
]
