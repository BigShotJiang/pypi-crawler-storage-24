# -*- coding: utf-8 -*-
"""Adapter that converts Finnie skill directories into LangChain tools.

Each skill directory contains a ``SKILL.md`` with YAML frontmatter
(``name``, ``description``) and markdown body (the skill instructions).

When the LLM "calls" a skill tool, the tool returns the SKILL.md body
so the LLM can follow the instructions in subsequent reasoning steps.
This mirrors how AgentScope's ``register_agent_skill`` works — it
injects the skill content as instructions for the agent.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Optional

import frontmatter
from langchain_core.tools import StructuredTool

from ...skills_manager import (
    get_active_skills_dir,
    list_available_skills,
)

logger = logging.getLogger(__name__)


def _parse_skill_md(skill_dir: Path) -> tuple[str, str, str]:
    """Parse SKILL.md in a skill directory.

    Returns:
        Tuple of ``(name, description, body)`` where *body* is the
        markdown content after the YAML frontmatter.
    """
    skill_md = skill_dir / "SKILL.md"
    if not skill_md.is_file():
        raise FileNotFoundError(f"SKILL.md not found in {skill_dir}")

    post = frontmatter.load(str(skill_md))
    name: str = post.metadata.get("name", skill_dir.name)
    description: str = post.metadata.get("description", f"Skill: {name}")
    body: str = post.content.strip()
    return name, description, body


def _read_skill_references(skill_dir: Path) -> str:
    """Read all reference files in a skill's references/ directory.

    Returns a concatenated string of all reference file contents,
    or empty string if no references directory exists.
    """
    refs_dir = skill_dir / "references"
    if not refs_dir.is_dir():
        return ""

    parts: list[str] = []
    for ref_file in sorted(refs_dir.rglob("*")):
        if ref_file.is_file():
            try:
                content = ref_file.read_text(encoding="utf-8")
                rel = ref_file.relative_to(refs_dir)
                parts.append(f"--- {rel} ---\n{content}")
            except Exception:
                continue
    return "\n\n".join(parts)


def skill_dir_to_langchain_tool(skill_dir: Path) -> Optional[StructuredTool]:
    """Convert a single Finnie skill directory into a LangChain tool.

    Args:
        skill_dir: Path to the skill directory (must contain SKILL.md).

    Returns:
        A ``StructuredTool`` instance, or ``None`` if parsing fails.
    """
    try:
        name, description, body = _parse_skill_md(skill_dir)
    except Exception as e:
        logger.warning("Skipping skill %s: %s", skill_dir.name, e)
        return None

    # Combine skill body with reference materials
    references = _read_skill_references(skill_dir)
    full_content = body
    if references:
        full_content += f"\n\n## Reference Materials\n\n{references}"

    def _run(query: str = "") -> str:
        """Return the skill instructions for the agent to follow."""
        return full_content

    async def _arun(query: str = "") -> str:
        return full_content

    return StructuredTool.from_function(
        func=_run,
        coroutine=_arun,
        name=name,
        description=description,
    )


def load_active_skills_as_tools() -> list[StructuredTool]:
    """Load all active skills from ``~/.finnie/active_skills/`` as LangChain tools.

    Returns:
        List of ``StructuredTool`` instances (one per skill directory).
    """
    skills_dir = get_active_skills_dir()
    available = list_available_skills()
    tools: list[StructuredTool] = []

    for skill_name in available:
        skill_dir = skills_dir / skill_name
        if not skill_dir.exists():
            continue
        tool = skill_dir_to_langchain_tool(skill_dir)
        if tool is not None:
            tools.append(tool)
            logger.debug("Loaded skill as LangChain tool: %s", skill_name)

    return tools
