# -*- coding: utf-8 -*-
"""Custom in-memory storage independent from AgentScope memory types."""

from __future__ import annotations

from typing import Any

from ...app.schemas.message_types import Message
from .marks import MemoryMark


class FinnieInMemoryMemory:
    """Simple in-memory message store with mark support."""

    def __init__(self) -> None:
        self.content: list[tuple[Any, list[str]]] = []
        self._compressed_summary = ""

    async def add(self, msg: Any, mark: str | None = None) -> None:
        marks = [mark] if mark else []
        self.content.append((msg, marks))

    async def add_batch(self, messages: list[Any]) -> None:
        for msg in messages:
            await self.add(msg)

    async def get_memory(
        self,
        mark: str | None = None,
        exclude_mark: str | None = MemoryMark.COMPRESSED.value,
        prepend_summary: bool = True,
        **_kwargs,
    ) -> list[Any]:
        """Get messages filtered by marks."""
        filtered = [
            (msg, marks)
            for msg, marks in self.content
            if mark is None or mark in marks
        ]
        if exclude_mark is not None:
            filtered = [
                (msg, marks)
                for msg, marks in filtered
                if exclude_mark not in marks
            ]

        messages = [msg for msg, _ in filtered]
        if prepend_summary and self._compressed_summary:
            summary_msg = Message(
                role="user",
                content=[
                    {
                        "type": "text",
                        "text": (
                            "<previous-summary>\n"
                            f"{self._compressed_summary}\n"
                            "</previous-summary>\n"
                            "The above is a summary of our previous conversation. "
                            "Use it as context to maintain continuity."
                        ),
                    },
                ],
            )
            return [summary_msg, *messages]
        return messages

    async def update_messages_mark(
        self,
        new_mark: str,
        msg_ids: list[str],
    ) -> int:
        """Add a mark to messages identified by ``msg_ids``."""
        updated = 0
        target_ids = set(msg_ids)
        for msg, marks in self.content:
            msg_id = getattr(msg, "id", None)
            if msg_id in target_ids and new_mark not in marks:
                marks.append(new_mark)
                updated += 1
        return updated

    async def update_compressed_summary(self, summary: str) -> None:
        self._compressed_summary = summary or ""

    def get_compressed_summary(self) -> str:
        return self._compressed_summary

    def state_dict(self) -> dict[str, Any]:
        serialized = []
        for msg, marks in self.content:
            if hasattr(msg, "model_dump"):
                msg_data = msg.model_dump()
            elif hasattr(msg, "dict"):
                msg_data = msg.dict()
            elif isinstance(msg, dict):
                msg_data = msg
            else:
                msg_data = {
                    "role": getattr(msg, "role", "assistant"),
                    "content": getattr(msg, "content", ""),
                }
            serialized.append([msg_data, list(marks)])

        return {
            "content": serialized,
            "_compressed_summary": self._compressed_summary,
        }

    def load_state_dict(self, state_dict: dict[str, Any], strict: bool = True) -> None:
        """Load state data with backward compatibility."""
        if strict and "content" not in state_dict:
            raise KeyError("Missing 'content' key in memory state_dict.")

        loaded: list[tuple[Any, list[str]]] = []
        for item in state_dict.get("content", []):
            msg_dict: dict[str, Any] | None = None
            marks: list[str] = []

            if isinstance(item, (tuple, list)) and len(item) == 2:
                maybe_msg, maybe_marks = item
                if isinstance(maybe_msg, dict):
                    msg_dict = maybe_msg
                if isinstance(maybe_marks, list):
                    marks = [str(mark) for mark in maybe_marks]
            elif isinstance(item, dict):
                msg_dict = item

            if msg_dict is None:
                continue

            loaded.append((self._dict_to_message(msg_dict), marks))

        self.content = loaded
        self._compressed_summary = state_dict.get("_compressed_summary", "")

    def _dict_to_message(self, msg_dict: dict[str, Any]) -> Message:
        role = msg_dict.get("role", "assistant")
        content = msg_dict.get("content", "")

        if isinstance(content, str):
            content_blocks: list[dict[str, Any]] = [
                {"type": "text", "text": content},
            ]
        elif isinstance(content, list):
            content_blocks = [
                block if isinstance(block, dict) else {"type": "text", "text": str(block)}
                for block in content
            ]
        else:
            content_blocks = [{"type": "text", "text": str(content)}]

        return Message(
            role=role,
            content=content_blocks,
            id=str(msg_dict.get("id") or Message().id),
            metadata=msg_dict.get("metadata"),
        )
