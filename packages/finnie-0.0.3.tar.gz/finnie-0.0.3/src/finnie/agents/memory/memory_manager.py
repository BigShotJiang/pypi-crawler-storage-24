# -*- coding: utf-8 -*-
"""Memory manager independent from AgentScope runtime types."""

from __future__ import annotations

import asyncio
import datetime
import json
import logging
import os
import platform
from pathlib import Path
from typing import TYPE_CHECKING, Any

from ...config.utils import load_config
from ...constant import MEMORY_COMPACT_RATIO

if TYPE_CHECKING:
    from langchain_core.language_models import BaseChatModel as LCBaseChatModel

logger = logging.getLogger(__name__)


try:
    from reme import ReMeFb

    _REME_AVAILABLE = True
except ImportError:
    logger.warning("reme not found!")
    _REME_AVAILABLE = False

    class ReMeFb:  # type: ignore
        """Fallback base class when reme is unavailable."""

        async def start(self):
            return None

        async def close(self):
            return None

        async def memory_search(
            self,
            query: str,
            max_results: int = 5,
            min_score: float = 0.1,
        ) -> str:
            return ""

        async def memory_get(
            self,
            path: str,
            offset: int | None = None,
            limit: int | None = None,
        ) -> str:
            return ""


class MemoryManager(ReMeFb):
    """Memory manager for compaction/summarization/search."""

    def __init__(
        self,
        *args,
        working_dir: str,
        **kwargs,
    ):
        if not _REME_AVAILABLE:
            raise RuntimeError("reme package not installed.")

        config = load_config()
        max_input_length = config.agents.running.max_input_length
        self._memory_compact_threshold = int(
            max_input_length * MEMORY_COMPACT_RATIO * 0.9,
        )

        (
            embedding_api_key,
            embedding_base_url,
            embedding_model_name,
            embedding_dimensions,
            embedding_cache_enabled,
            embedding_max_cache_size,
            embedding_max_input_length,
            embedding_max_batch_size,
        ) = self.get_emb_envs()

        vector_enabled = bool(embedding_api_key)
        if vector_enabled:
            logger.info("Vector search enabled.")
        else:
            logger.warning(
                "Vector search disabled. Configure embedding env vars to enable it.",
            )

        fts_enabled = os.environ.get("FTS_ENABLED", "true").lower() == "true"
        working_path: Path = Path(working_dir)

        memory_store_backend = os.environ.get("MEMORY_STORE_BACKEND", "auto")
        if memory_store_backend == "auto":
            memory_backend = "local" if platform.system() == "Windows" else "chroma"
        else:
            memory_backend = memory_store_backend

        super().__init__(
            *args,
            working_dir=working_dir,
            enable_logo=False,
            log_to_console=False,
            llm_api_key="",
            llm_base_url="",
            embedding_api_key=embedding_api_key,
            embedding_base_url=embedding_base_url,
            default_llm_config={},
            default_embedding_model_config={
                "model_name": embedding_model_name,
                "dimensions": embedding_dimensions,
                "enable_cache": embedding_cache_enabled,
                "max_cache_size": embedding_max_cache_size,
                "max_input_length": embedding_max_input_length,
                "max_batch_size": embedding_max_batch_size,
            },
            default_file_store_config={
                "backend": memory_backend,
                "store_name": "finnie",
                "vector_enabled": vector_enabled,
                "fts_enabled": fts_enabled,
            },
            default_file_watcher_config={
                "watch_paths": [
                    str(working_path / "MEMORY.md"),
                    str(working_path / "memory.md"),
                    str(working_path / "memory"),
                ],
            },
            **kwargs,
        )

        global_config = load_config()
        self.language = "zh" if global_config.agents.language == "zh" else ""
        self.summary_tasks: list[asyncio.Task] = []

        # Compatibility attributes: old path may still set them.
        self.chat_model = None
        self.formatter = None
        self.langchain_chat_model: "LCBaseChatModel | None" = None

    @staticmethod
    def _safe_int(value: str | None, default: int) -> int:
        if value is None:
            return default
        try:
            return int(value)
        except ValueError:
            logger.warning("Invalid int value '%s', using default %d", value, default)
            return default

    @staticmethod
    def get_emb_envs():
        embedding_api_key = os.environ.get("EMBEDDING_API_KEY", "")
        embedding_base_url = os.environ.get(
            "EMBEDDING_BASE_URL",
            "https://dashscope.aliyuncs.com/compatible-mode/v1",
        )
        embedding_model_name = os.environ.get(
            "EMBEDDING_MODEL_NAME",
            "text-embedding-v4",
        )
        embedding_dimensions = MemoryManager._safe_int(
            os.environ.get("EMBEDDING_DIMENSIONS"),
            1024,
        )
        embedding_cache_enabled = (
            os.environ.get("EMBEDDING_CACHE_ENABLED", "true").lower() == "true"
        )
        embedding_max_cache_size = MemoryManager._safe_int(
            os.environ.get("EMBEDDING_MAX_CACHE_SIZE"),
            2000,
        )
        embedding_max_input_length = MemoryManager._safe_int(
            os.environ.get("EMBEDDING_MAX_INPUT_LENGTH"),
            8192,
        )
        embedding_max_batch_size = MemoryManager._safe_int(
            os.environ.get("EMBEDDING_MAX_BATCH_SIZE"),
            10,
        )
        return (
            embedding_api_key,
            embedding_base_url,
            embedding_model_name,
            embedding_dimensions,
            embedding_cache_enabled,
            embedding_max_cache_size,
            embedding_max_input_length,
            embedding_max_batch_size,
        )

    def update_emb_envs(self):
        (
            embedding_api_key,
            embedding_base_url,
            embedding_model_name,
            embedding_dimensions,
            embedding_cache_enabled,
            embedding_max_cache_size,
            embedding_max_input_length,
            embedding_max_batch_size,
        ) = self.get_emb_envs()

        if embedding_api_key:
            os.environ["REME_EMBEDDING_API_KEY"] = embedding_api_key
        if embedding_base_url:
            os.environ["REME_EMBEDDING_BASE_URL"] = embedding_base_url

        self.default_embedding_model.model_name = embedding_model_name
        self.default_embedding_model.dimensions = embedding_dimensions
        self.default_embedding_model.enable_cache = embedding_cache_enabled
        self.default_embedding_model.max_cache_size = embedding_max_cache_size
        self.default_embedding_model.max_input_length = embedding_max_input_length
        self.default_embedding_model.max_batch_size = embedding_max_batch_size

    async def start(self):
        try:
            return await super().start()
        except Exception as exc:
            logger.exception("Failed to start memory manager: %s", exc)
            raise

    async def close(self):
        try:
            return await super().close()
        except Exception as exc:
            logger.exception("Failed to close memory manager: %s", exc)
            raise

    def _extract_message_text(self, message: Any) -> str:
        content = getattr(message, "content", "")

        if isinstance(content, str):
            return content

        if not isinstance(content, list):
            return str(content)

        parts: list[str] = []
        for block in content:
            if not isinstance(block, dict):
                parts.append(str(block))
                continue

            block_type = block.get("type", "")
            if block_type == "text":
                parts.append(str(block.get("text", "")))
            elif block_type == "thinking":
                parts.append(str(block.get("thinking", "")))
            elif block_type == "tool_use":
                name = block.get("name", "")
                tool_input = block.get("input", {})
                parts.append(
                    f"[tool_use] {name} "
                    f"{json.dumps(tool_input, ensure_ascii=False)}",
                )
            elif block_type == "tool_result":
                output = block.get("output", "")
                if isinstance(output, (list, dict)):
                    output = json.dumps(output, ensure_ascii=False)
                parts.append(f"[tool_result] {output}")
            elif block_type in ("image", "audio", "video", "file"):
                source = block.get("source", {})
                parts.append(f"[{block_type}] {source.get('url', '')}")

        return "\n".join(part for part in parts if part)

    async def _invoke_llm(
        self,
        system_prompt: str,
        user_message: str,
    ) -> str:
        if self.langchain_chat_model is None:
            return user_message[:3000]

        from langchain_core.messages import HumanMessage, SystemMessage

        result = await self.langchain_chat_model.ainvoke(
            [
                SystemMessage(content=system_prompt),
                HumanMessage(content=user_message),
            ],
        )
        return result.content if isinstance(result.content, str) else str(result.content)

    async def _invoke_llm_with_tools(
        self,
        system_prompt: str,
        user_message: str,
    ) -> str:
        if self.langchain_chat_model is None:
            return await self._invoke_llm(system_prompt, user_message)

        from langchain.agents import create_agent

        from ..langgraph.tools.builtins import (
            edit_file as lc_edit_file,
            read_file as lc_read_file,
            write_file as lc_write_file,
        )

        graph = create_agent(
            model=self.langchain_chat_model,
            tools=[lc_read_file, lc_write_file, lc_edit_file],
            system_prompt=system_prompt,
        )
        result = await graph.ainvoke({"messages": [("user", user_message)]})
        final_msg = result["messages"][-1]
        return final_msg.content if isinstance(final_msg.content, str) else str(final_msg.content)

    async def compact_memory(
        self,
        messages_to_summarize: list[Any] | None = None,
        turn_prefix_messages: list[Any] | None = None,
        previous_summary: str = "",
    ) -> str:
        self.update_emb_envs()

        summarize_msgs = messages_to_summarize or []
        prefix_msgs = turn_prefix_messages or []
        if not summarize_msgs and not prefix_msgs:
            return ""

        summarize_text = "\n\n".join(
            self._extract_message_text(msg) for msg in summarize_msgs
        )
        prefix_text = "\n\n".join(
            self._extract_message_text(msg) for msg in prefix_msgs
        )

        prompt_parts = []
        if previous_summary:
            prompt_parts.append(f"Previous summary:\n{previous_summary}")
        if summarize_text:
            prompt_parts.append(f"Conversation to summarize:\n{summarize_text}")
        if prefix_text:
            prompt_parts.append(f"Recent context:\n{prefix_text}")

        prompt = "\n\n".join(prompt_parts).strip()
        if not prompt:
            return previous_summary

        summary = await self._invoke_llm(
            system_prompt=(
                "Summarize conversation context for future continuity. "
                "Keep decisions, commitments, todos, and constraints."
            ),
            user_message=prompt,
        )
        return summary.strip()

    def _next_version(self, memory_dir: Path, prefix: str) -> int:
        """Find the next available version number for a given filename prefix.

        Scans existing files matching ``{prefix}_v{N}.md`` and returns N+1.
        """
        max_ver = 0
        for f in memory_dir.glob(f"{prefix}_v*.md"):
            stem = f.stem  # e.g. "2026-03-05_console_sess123_v2"
            parts = stem.rsplit("_v", 1)
            if len(parts) == 2:
                try:
                    max_ver = max(max_ver, int(parts[1]))
                except ValueError:
                    continue
        return max_ver + 1

    async def summary_memory(
        self,
        messages: list[Any],
        date: str,
        channel: str = "",
        session_id: str = "",
    ) -> str:
        self.update_emb_envs()

        text = "\n\n".join(self._extract_message_text(msg) for msg in messages)
        if not text.strip():
            return ""

        prompt = (
            f"Date: {date}\nChannel: {channel}\nSession: {session_id}\n\n"
            f"Please summarize this conversation and extract important "
            f"long-term memory candidates:\n{text}"
        )
        try:
            result = await self._invoke_llm_with_tools(
                system_prompt="You are a helpful assistant.",
                user_message=prompt,
            )
            logger.info("Memory Summary Result:\n%s", result)

            # Persist summary to ~/.finnie/memory/ so file_watcher can
            # index it and memory_search can retrieve it later.
            if result.strip():
                memory_dir = Path(self.working_dir) / "memory"
                memory_dir.mkdir(parents=True, exist_ok=True)

                # Build filename: {date}_{channel}_{session_id}_v{N}.md
                parts = [date]
                if channel:
                    parts.append(channel)
                if session_id:
                    # Truncate long session ids for readable filenames
                    parts.append(session_id[:13])
                prefix = "_".join(parts)
                ver = self._next_version(memory_dir, prefix)
                filename = f"{prefix}_v{ver}.md"

                filepath = memory_dir / filename
                filepath.write_text(result, encoding="utf-8")
                logger.info("Memory summary persisted to %s", filepath)

            return result
        except Exception as exc:
            logger.exception("Failed to generate memory summary: %s", exc)
            return ""

    async def await_summary_tasks(self) -> str:
        result = ""
        for task in self.summary_tasks:
            if task.done():
                exc = task.exception()
                if exc is not None:
                    logger.exception("Summary task failed: %s", exc)
                    result += f"Summary task failed: {exc}\n"
                else:
                    done = task.result()
                    logger.info("Summary task completed: %s", done)
                    result += f"Summary task completed: {done}\n"
            else:
                try:
                    done = await task
                    logger.info("Summary task completed: %s", done)
                    result += f"Summary task completed: {done}\n"
                except Exception as exc:
                    logger.exception("Summary task failed: %s", exc)
                    result += f"Summary task failed: {exc}\n"

        self.summary_tasks.clear()
        return result

    def add_async_summary_task(
        self,
        messages: list[Any],
        date: str = "",
        channel: str = "",
        session_id: str = "",
    ):
        remaining_tasks = []
        for task in self.summary_tasks:
            if task.done():
                exc = task.exception()
                if exc is not None:
                    logger.exception("Summary task failed: %s", exc)
                else:
                    logger.info("Summary task completed: %s", task.result())
            else:
                remaining_tasks.append(task)
        self.summary_tasks = remaining_tasks

        self.summary_tasks.append(
            asyncio.create_task(
                self.summary_memory(
                    messages=messages,
                    date=date or datetime.datetime.now().strftime("%Y-%m-%d"),
                    channel=channel,
                    session_id=session_id,
                ),
            ),
        )

    async def memory_search(
        self,
        query: str,
        max_results: int = 5,
        min_score: float = 0.1,
    ) -> str:
        if not query:
            return "Error: No query provided."

        if isinstance(max_results, int):
            max_results = min(max(max_results, 1), 100)
        else:
            max_results = 5

        if isinstance(min_score, float):
            min_score = min(max(min_score, 0.001), 0.999)
        else:
            min_score = 0.1

        return await super().memory_search(
            query=query,
            max_results=max_results,
            min_score=min_score,
        )

    async def memory_get(
        self,
        path: str,
        offset: int | None = None,
        limit: int | None = None,
    ) -> str:
        return await super().memory_get(
            path=path,
            offset=offset,
            limit=limit,
        )
