# -*- coding: utf-8 -*-
"""Memory mark constants for memory compaction state."""

from enum import Enum


class MemoryMark(str, Enum):
    """Marks used to annotate memory items."""

    COMPRESSED = "COMPRESSED"
    TOOL_RESULT = "TOOL_RESULT"
