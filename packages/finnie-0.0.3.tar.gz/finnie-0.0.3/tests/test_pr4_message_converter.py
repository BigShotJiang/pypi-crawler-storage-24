# -*- coding: utf-8 -*-
"""PR4 tests: message_converter roundtrip — internal Message ↔ LangChain BaseMessage.

Covers: text, thinking, tool_use, tool_result, image, file.
"""

import pytest
from unittest.mock import MagicMock

from langchain_core.messages import (
    AIMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)

from finnie.agents.langgraph.message_converter import (
    langchain_to_msg,
    langchain_to_msgs,
    msg_to_langchain,
    msgs_to_langchain,
)
from finnie.app.schemas.message_types import Message


# ---------------------------------------------------------------------------
# Helper: create a duck-typed message (simulates both Msg and internal Message)
# ---------------------------------------------------------------------------

def _make_msg(content, role="user"):
    """Create a minimal message-like object with .content and .role."""
    msg = MagicMock()
    msg.content = content
    msg.role = role
    return msg


# ===========================================================================
# msg_to_langchain tests (input side — accepts duck-typed objects)
# ===========================================================================

class TestMsgToLangchain:
    """Test converting message objects → LangChain BaseMessage."""

    def test_simple_text_user(self):
        msg = _make_msg("你好", role="user")
        lc = msg_to_langchain(msg)
        assert isinstance(lc, HumanMessage)
        assert lc.content == "你好"

    def test_simple_text_assistant(self):
        msg = _make_msg("我是Finnie", role="assistant")
        lc = msg_to_langchain(msg)
        assert isinstance(lc, AIMessage)
        assert lc.content == "我是Finnie"

    def test_simple_text_system(self):
        msg = _make_msg("你是AI助手", role="system")
        lc = msg_to_langchain(msg)
        assert isinstance(lc, SystemMessage)
        assert lc.content == "你是AI助手"

    def test_tool_use_block(self):
        msg = _make_msg(
            [
                {"type": "tool_use", "id": "call_1", "name": "get_time", "input": {}},
            ],
            role="assistant",
        )
        result = msg_to_langchain(msg)
        if isinstance(result, list):
            result = result[0]
        assert isinstance(result, AIMessage)
        assert len(result.tool_calls) == 1
        assert result.tool_calls[0]["name"] == "get_time"
        assert result.tool_calls[0]["id"] == "call_1"

    def test_tool_result_block(self):
        msg = _make_msg(
            [
                {
                    "type": "tool_result",
                    "id": "call_1",
                    "name": "get_time",
                    "output": "2025-03-04 15:00:00",
                },
            ],
            role="user",
        )
        result = msg_to_langchain(msg)
        if isinstance(result, list):
            result = result[0]
        assert isinstance(result, ToolMessage)
        assert result.content == "2025-03-04 15:00:00"
        assert result.tool_call_id == "call_1"

    def test_thinking_block(self):
        msg = _make_msg(
            [{"type": "thinking", "thinking": "让我想想..."}],
            role="assistant",
        )
        result = msg_to_langchain(msg)
        if isinstance(result, list):
            result = result[0]
        assert isinstance(result, AIMessage)
        assert result.additional_kwargs.get("thinking") == "让我想想..."

    def test_image_block(self):
        msg = _make_msg(
            [
                {"type": "text", "text": "看这张图"},
                {
                    "type": "image",
                    "source": {"type": "url", "url": "https://example.com/a.png"},
                },
            ],
            role="user",
        )
        result = msg_to_langchain(msg)
        if isinstance(result, list):
            result = result[0]
        assert isinstance(result, HumanMessage)
        assert isinstance(result.content, list)
        image_parts = [p for p in result.content if p.get("type") == "image_url"]
        assert len(image_parts) == 1
        assert image_parts[0]["image_url"]["url"] == "https://example.com/a.png"

    def test_file_block(self):
        msg = _make_msg(
            [
                {"type": "text", "text": "Here is the file:"},
                {"type": "file", "name": "report.pdf", "path": "/tmp/report.pdf"},
            ],
            role="user",
        )
        result = msg_to_langchain(msg)
        if isinstance(result, list):
            result = result[0]
        assert isinstance(result, HumanMessage)
        content = result.content if isinstance(result.content, str) else str(result.content)
        assert "report.pdf" in content

    def test_empty_content(self):
        msg = _make_msg([], role="assistant")
        result = msg_to_langchain(msg)
        if isinstance(result, list):
            result = result[0]
        assert isinstance(result, AIMessage)


# ===========================================================================
# langchain_to_msg tests (output side — returns internal Message)
# ===========================================================================

class TestLangchainToMsg:
    """Test converting LangChain BaseMessage → internal Message."""

    def test_human_message(self):
        lc = HumanMessage(content="你好")
        msg = langchain_to_msg(lc)
        assert isinstance(msg, Message)
        assert msg.role == "user"
        # Content should be a list with a text block
        assert isinstance(msg.content, list)
        assert any(
            isinstance(b, dict) and b.get("type") == "text" and b.get("text") == "你好"
            for b in msg.content
        )

    def test_ai_message(self):
        lc = AIMessage(content="我是Finnie")
        msg = langchain_to_msg(lc)
        assert isinstance(msg, Message)
        assert msg.role == "assistant"
        assert isinstance(msg.content, list)

    def test_system_message(self):
        lc = SystemMessage(content="你是AI助手")
        msg = langchain_to_msg(lc)
        assert isinstance(msg, Message)
        assert msg.role == "system"

    def test_tool_message(self):
        lc = ToolMessage(content="2025-03-04 15:00:00", tool_call_id="call_1", name="get_time")
        msg = langchain_to_msg(lc)
        assert isinstance(msg, Message)
        assert msg.role == "user"
        assert isinstance(msg.content, list)
        assert msg.content[0]["type"] == "tool_result"
        assert msg.content[0]["id"] == "call_1"
        assert msg.content[0]["output"] == "2025-03-04 15:00:00"

    def test_ai_message_with_tool_calls(self):
        lc = AIMessage(
            content="",
            tool_calls=[
                {"name": "shell", "args": {"cmd": "ls"}, "id": "tc_1"},
            ],
        )
        msg = langchain_to_msg(lc)
        assert isinstance(msg, Message)
        assert msg.role == "assistant"
        tool_use_blocks = [b for b in msg.content if isinstance(b, dict) and b.get("type") == "tool_use"]
        assert len(tool_use_blocks) == 1
        assert tool_use_blocks[0]["name"] == "shell"
        assert tool_use_blocks[0]["id"] == "tc_1"

    def test_ai_message_with_thinking(self):
        lc = AIMessage(
            content="答案是42",
            additional_kwargs={"thinking": "让我推理一下..."},
        )
        msg = langchain_to_msg(lc)
        assert isinstance(msg, Message)
        thinking_blocks = [b for b in msg.content if isinstance(b, dict) and b.get("type") == "thinking"]
        text_blocks = [b for b in msg.content if isinstance(b, dict) and b.get("type") == "text"]
        assert len(thinking_blocks) == 1
        assert thinking_blocks[0]["thinking"] == "让我推理一下..."
        assert len(text_blocks) == 1
        assert text_blocks[0]["text"] == "答案是42"

    def test_multimodal_message(self):
        lc = HumanMessage(
            content=[
                {"type": "text", "text": "看这张图"},
                {"type": "image_url", "image_url": {"url": "https://example.com/a.png"}},
            ],
        )
        msg = langchain_to_msg(lc)
        assert isinstance(msg, Message)
        assert msg.role == "user"
        image_blocks = [b for b in msg.content if isinstance(b, dict) and b.get("type") == "image"]
        assert len(image_blocks) == 1

    def test_empty_content(self):
        lc = AIMessage(content="")
        msg = langchain_to_msg(lc)
        assert isinstance(msg, Message)
        assert isinstance(msg.content, list)


# ===========================================================================
# Roundtrip tests
# ===========================================================================

class TestRoundtrip:
    """Test that LangChain → Message → LangChain preserves structure."""

    def test_text_roundtrip(self):
        original = HumanMessage(content="测试文本")
        msg = langchain_to_msg(original)
        back = msg_to_langchain(msg)
        if isinstance(back, list):
            back = back[0]
        assert isinstance(back, HumanMessage)
        # Content may be string or list, but text should be preserved
        content = back.content
        if isinstance(content, list):
            text = "".join(b.get("text", "") for b in content if isinstance(b, dict))
        else:
            text = content
        assert "测试文本" in text

    def test_tool_calls_roundtrip(self):
        original = AIMessage(
            content="",
            tool_calls=[
                {"name": "get_time", "args": {}, "id": "tc_1"},
            ],
        )
        msg = langchain_to_msg(original)
        back = msg_to_langchain(msg)
        if isinstance(back, list):
            # Find the AIMessage with tool_calls
            ai_msgs = [m for m in back if isinstance(m, AIMessage) and m.tool_calls]
            assert len(ai_msgs) >= 1
            back = ai_msgs[0]
        assert isinstance(back, AIMessage)
        assert len(back.tool_calls) == 1
        assert back.tool_calls[0]["name"] == "get_time"

    def test_tool_result_roundtrip(self):
        original = ToolMessage(content="result data", tool_call_id="call_1", name="my_tool")
        msg = langchain_to_msg(original)
        back = msg_to_langchain(msg)
        if isinstance(back, list):
            tool_msgs = [m for m in back if isinstance(m, ToolMessage)]
            assert len(tool_msgs) >= 1
            back = tool_msgs[0]
        assert isinstance(back, ToolMessage)
        assert back.content == "result data"
        assert back.tool_call_id == "call_1"

    def test_thinking_roundtrip(self):
        original = AIMessage(
            content="",
            additional_kwargs={"thinking": "深度思考中..."},
        )
        msg = langchain_to_msg(original)
        back = msg_to_langchain(msg)
        if isinstance(back, list):
            back = back[0]
        assert isinstance(back, AIMessage)
        assert back.additional_kwargs.get("thinking") == "深度思考中..."

    def test_image_roundtrip(self):
        original = HumanMessage(
            content=[
                {"type": "text", "text": "这是什么？"},
                {"type": "image_url", "image_url": {"url": "https://example.com/img.jpg"}},
            ],
        )
        msg = langchain_to_msg(original)
        back = msg_to_langchain(msg)
        if isinstance(back, list):
            back = back[0]
        assert isinstance(back, HumanMessage)
        assert isinstance(back.content, list)
        image_parts = [p for p in back.content if isinstance(p, dict) and p.get("type") == "image_url"]
        assert len(image_parts) >= 1


# ===========================================================================
# Batch conversion tests
# ===========================================================================

class TestBatchConversion:
    """Test msgs_to_langchain and langchain_to_msgs."""

    def test_msgs_to_langchain(self):
        msg1 = _make_msg("你好", role="user")
        msg2 = _make_msg("你好！", role="assistant")
        result = msgs_to_langchain([msg1, msg2])
        assert len(result) == 2
        assert isinstance(result[0], HumanMessage)
        assert isinstance(result[1], AIMessage)

    def test_langchain_to_msgs(self):
        lc1 = HumanMessage(content="你好")
        lc2 = AIMessage(content="你好！")
        result = langchain_to_msgs([lc1, lc2])
        assert len(result) == 2
        assert all(isinstance(m, Message) for m in result)
        assert result[0].role == "user"
        assert result[1].role == "assistant"
