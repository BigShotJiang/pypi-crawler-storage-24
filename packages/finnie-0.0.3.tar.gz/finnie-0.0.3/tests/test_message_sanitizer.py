# -*- coding: utf-8 -*-
"""Tests for message_sanitizer and message_converter file-block handling."""

import pytest
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage

from finnie.agents.langgraph.message_sanitizer import sanitize_tool_messages


# ===================================================================
# sanitize_tool_messages
# ===================================================================


class TestSanitizeToolMessages:
    """Tests for orphan tool message cleanup."""

    def test_no_tool_messages_unchanged(self):
        """Plain conversation should pass through unchanged."""
        msgs = [
            SystemMessage(content="You are helpful."),
            HumanMessage(content="Hello"),
            AIMessage(content="Hi there!"),
        ]
        result = sanitize_tool_messages(msgs)
        assert len(result) == 3
        assert result[0].content == "You are helpful."
        assert result[1].content == "Hello"
        assert result[2].content == "Hi there!"

    def test_properly_paired_unchanged(self):
        """Correctly paired tool_call + ToolMessage should stay intact."""
        msgs = [
            HumanMessage(content="Search for cats"),
            AIMessage(
                content="",
                tool_calls=[{"id": "call_1", "name": "search", "args": {"q": "cats"}}],
            ),
            ToolMessage(content="Found 10 results", tool_call_id="call_1"),
            AIMessage(content="I found 10 results about cats."),
        ]
        result = sanitize_tool_messages(msgs)
        assert len(result) == 4

    def test_orphan_tool_message_removed(self):
        """ToolMessage without matching AIMessage.tool_calls should be removed."""
        msgs = [
            HumanMessage(content="Hello"),
            ToolMessage(content="orphan result", tool_call_id="call_999"),
            AIMessage(content="Hi"),
        ]
        result = sanitize_tool_messages(msgs)
        assert len(result) == 2
        assert isinstance(result[0], HumanMessage)
        assert isinstance(result[1], AIMessage)

    def test_orphan_tool_call_stripped(self):
        """AIMessage.tool_calls without matching ToolMessage should be stripped."""
        msgs = [
            HumanMessage(content="Do something"),
            AIMessage(
                content="Let me try",
                tool_calls=[{"id": "call_1", "name": "do_thing", "args": {}}],
            ),
            AIMessage(content="I couldn't do it."),
        ]
        result = sanitize_tool_messages(msgs)
        assert len(result) == 3
        # The AIMessage should keep its text content but lose tool_calls
        ai_msg = result[1]
        assert isinstance(ai_msg, AIMessage)
        assert ai_msg.content == "Let me try"
        assert not ai_msg.tool_calls

    def test_orphan_tool_call_no_content_removed(self):
        """AIMessage with only orphan tool_calls and no content should be removed."""
        msgs = [
            HumanMessage(content="Do something"),
            AIMessage(
                content="",
                tool_calls=[{"id": "call_1", "name": "do_thing", "args": {}}],
            ),
            AIMessage(content="Never mind."),
        ]
        result = sanitize_tool_messages(msgs)
        assert len(result) == 2
        assert isinstance(result[0], HumanMessage)
        assert isinstance(result[1], AIMessage)
        assert result[1].content == "Never mind."

    def test_mixed_valid_and_orphan_tool_calls(self):
        """AIMessage with both valid and orphan tool_calls: keep valid, strip orphan."""
        msgs = [
            HumanMessage(content="Do two things"),
            AIMessage(
                content="",
                tool_calls=[
                    {"id": "call_1", "name": "search", "args": {}},
                    {"id": "call_2", "name": "calculate", "args": {}},
                ],
            ),
            ToolMessage(content="search result", tool_call_id="call_1"),
            # call_2 has no ToolMessage response
            AIMessage(content="Done"),
        ]
        result = sanitize_tool_messages(msgs)
        assert len(result) == 4
        # AIMessage should only have call_1 (call_2 stripped)
        ai_msg = result[1]
        assert isinstance(ai_msg, AIMessage)
        assert len(ai_msg.tool_calls) == 1
        assert ai_msg.tool_calls[0]["id"] == "call_1"
        # ToolMessage for call_1 kept
        assert isinstance(result[2], ToolMessage)
        # Final AIMessage kept
        assert isinstance(result[3], AIMessage)
        assert result[3].content == "Done"

    def test_multiple_paired_tool_calls(self):
        """Multiple properly paired calls in one AIMessage."""
        msgs = [
            HumanMessage(content="Do three things"),
            AIMessage(
                content="",
                tool_calls=[
                    {"id": "call_1", "name": "a", "args": {}},
                    {"id": "call_2", "name": "b", "args": {}},
                    {"id": "call_3", "name": "c", "args": {}},
                ],
            ),
            ToolMessage(content="r1", tool_call_id="call_1"),
            ToolMessage(content="r2", tool_call_id="call_2"),
            ToolMessage(content="r3", tool_call_id="call_3"),
            AIMessage(content="All done"),
        ]
        result = sanitize_tool_messages(msgs)
        assert len(result) == 6  # All kept

    def test_token_budget_trim_scenario(self):
        """Simulate token budget trimming that drops AIMessage but keeps ToolMessage."""
        # This simulates: budget trim dropped the AIMessage with tool_calls
        # but left the ToolMessage behind
        msgs = [
            SystemMessage(content="System"),
            ToolMessage(content="orphan after trim", tool_call_id="call_old"),
            HumanMessage(content="New question"),
            AIMessage(content="Answer"),
        ]
        result = sanitize_tool_messages(msgs)
        assert len(result) == 3
        assert isinstance(result[0], SystemMessage)
        assert isinstance(result[1], HumanMessage)
        assert isinstance(result[2], AIMessage)

    def test_empty_messages(self):
        """Empty list should return empty list."""
        assert sanitize_tool_messages([]) == []

    def test_preserves_message_metadata(self):
        """AIMessage metadata (additional_kwargs, response_metadata) should be preserved."""
        msgs = [
            HumanMessage(content="test"),
            AIMessage(
                content="thinking...",
                tool_calls=[
                    {"id": "call_1", "name": "search", "args": {}},
                    {"id": "call_orphan", "name": "bad", "args": {}},
                ],
                additional_kwargs={"thinking": "deep thought"},
                id="msg_123",
            ),
            ToolMessage(content="result", tool_call_id="call_1"),
        ]
        result = sanitize_tool_messages(msgs)
        ai_msg = result[1]
        assert ai_msg.additional_kwargs.get("thinking") == "deep thought"
        assert ai_msg.id == "msg_123"
        assert len(ai_msg.tool_calls) == 1


# ===================================================================
# message_converter file block handling
# ===================================================================


class TestFileBlockConversion:
    """Tests for file block → text conversion in message_converter."""

    def _make_msg(self, content, role="assistant"):
        """Create a minimal Msg-like object."""
        from unittest.mock import MagicMock

        msg = MagicMock()
        msg.content = content
        msg.role = role
        return msg

    def test_file_block_produces_text(self):
        """File block should produce a text description in the LangChain message."""
        from finnie.agents.langgraph.message_converter import msg_to_langchain

        msg = self._make_msg(
            [
                {"type": "text", "text": "Here is the file:"},
                {
                    "type": "file",
                    "name": "report.pdf",
                    "path": "/tmp/report.pdf",
                },
            ],
            role="user",
        )
        result = msg_to_langchain(msg)
        # Should be a single HumanMessage with combined text
        if isinstance(result, list):
            content = " ".join(
                m.content if isinstance(m.content, str) else str(m.content)
                for m in result
            )
        else:
            content = result.content if isinstance(result.content, str) else str(result.content)
        assert "report.pdf" in content
        assert "/tmp/report.pdf" in content

    def test_file_block_preserved_in_kwargs(self):
        """File block data should also be stored in additional_kwargs."""
        from finnie.agents.langgraph.message_converter import msg_to_langchain

        msg = self._make_msg(
            [
                {
                    "type": "file",
                    "name": "data.csv",
                    "path": "/tmp/data.csv",
                },
            ],
            role="user",
        )
        result = msg_to_langchain(msg)
        if isinstance(result, list):
            result = result[0]
        kwargs = result.additional_kwargs or {}
        assert "file_blocks" in kwargs
        assert kwargs["file_blocks"][0]["name"] == "data.csv"

    def test_audio_video_unchanged(self):
        """Audio/video blocks should still go to additional_kwargs (with text)."""
        from finnie.agents.langgraph.message_converter import msg_to_langchain

        msg = self._make_msg(
            [
                {"type": "text", "text": "Here are media files:"},
                {"type": "audio", "source": {"type": "url", "url": "http://a.mp3"}},
                {"type": "video", "source": {"type": "url", "url": "http://v.mp4"}},
            ],
            role="assistant",
        )
        result = msg_to_langchain(msg)
        if isinstance(result, list):
            result = result[0]
        kwargs = result.additional_kwargs or {}
        assert "audio_blocks" in kwargs
        assert "video_blocks" in kwargs
