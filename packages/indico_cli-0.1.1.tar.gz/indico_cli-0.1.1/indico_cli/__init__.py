"""Indico CLI - Command line interface for Indico event management systems."""

__version__ = "0.1.1"
