"""Core runtime helpers."""
