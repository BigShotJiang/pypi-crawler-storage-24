"""Dictionary definitions for the term spaceframe."""

__all__ = ["__version__", "spaceframe"]

__version__ = "0.0.2"


def spaceframe() -> dict[str, object]:
    """Return dictionary-style definitions for the term ``spaceframe``."""
    return {
        "word": "spaceframe",
        "part_of_speech": "noun",
        "definitions": [
            "A rigid three-dimensional framework made from interconnected struts or members.",
            "A lightweight structural system that distributes loads through a geometric lattice.",
            "A next generation manufacturing execution system.",
        ],
    }
