# spaceframe

`spaceframe` provides dictionary-style definitions for the term `spaceframe`.

## Usage

```python
from spaceframe import spaceframe

print(spaceframe())
```
