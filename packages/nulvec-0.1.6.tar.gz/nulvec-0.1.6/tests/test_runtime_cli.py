from __future__ import annotations

import json
from pathlib import Path

import pytest

from nulvec.cli import main
from nulvec.machine import append_event


def _configure_runtime(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setenv("NULVEC_HOME", str(tmp_path / "nulvec-home"))
    monkeypatch.setenv("GIT_CONFIG_GLOBAL", str(tmp_path / "gitconfig"))
    monkeypatch.setenv("NULVEC_SHELL_RC", str(tmp_path / ".zshrc"))


def _run_cli(monkeypatch: pytest.MonkeyPatch, argv: list[str]) -> int:
    monkeypatch.setattr("sys.argv", argv)
    with pytest.raises(SystemExit) as exc_info:
        main()
    return int(exc_info.value.code)


def test_config_show_and_logs_json(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    tmp_path: Path,
):
    _configure_runtime(monkeypatch, tmp_path)
    monkeypatch.chdir(tmp_path)

    assert _run_cli(monkeypatch, ["nulvec", "install"]) == 0
    capsys.readouterr()

    append_event(
        {
            "event": "skill_install_scan",
            "action": "block",
            "summary": {"scanned_files": 1, "blocked": 1, "suspicious": 0},
        }
    )

    assert _run_cli(monkeypatch, ["nulvec", "config", "show", "--json"]) == 0
    config_payload = json.loads(capsys.readouterr().out)
    assert config_payload["integrations"]["git"]["mode"] == "shim+hooks"
    assert config_payload["integrations"]["clawhub"]["mode"] == "nulvec-skill-install"
    assert config_payload["integrations"]["mcp"]["mode"] == "stdio-proxy"

    assert _run_cli(monkeypatch, ["nulvec", "logs", "--json", "--limit", "1"]) == 0
    logs_payload = json.loads(capsys.readouterr().out)
    assert len(logs_payload) == 1
    assert logs_payload[0]["event"] == "skill_install_scan"
    assert logs_payload[0]["recorded_at"]
