"""Tests for .pth file scanning — Python startup execution attacks."""

from __future__ import annotations

import tempfile
from pathlib import Path

import nulvec
from nulvec.models import Severity, ThreatType

FIXTURE_DIR = Path(__file__).parent / "fixtures"


def test_pth_exec_blocked():
    """The LiteLLM 1.82.8 attack payload must be caught and blocked."""
    result = nulvec.scan(FIXTURE_DIR / "litellm_1828_attack.pth")
    assert result.blocked
    assert result.threats[0].type == ThreatType.SUPPLY_CHAIN_EXEC
    assert result.threats[0].severity == Severity.CRITICAL
    assert result.threats[0].confidence == 1.0
    assert "subprocess" in result.threats[0].extracted_content


def test_legitimate_pth_clean(tmp_path: Path):
    """A .pth file with only directory paths should be clean."""
    path = tmp_path / "mypackage.pth"
    path.write_text("/usr/local/lib/python3.11/site-packages/mypackage\n")
    result = nulvec.scan(path)
    assert result.clean


def test_pth_eval_blocked(tmp_path: Path):
    """A .pth file using eval() should be blocked."""
    path = tmp_path / "evil.pth"
    path.write_text("import sys; eval('print(1)')\n")
    result = nulvec.scan(path)
    assert result.blocked
    assert result.threats[0].type == ThreatType.SUPPLY_CHAIN_EXEC


def test_pth_base64_blocked(tmp_path: Path):
    """A .pth file referencing base64 should be blocked."""
    path = tmp_path / "sneaky.pth"
    path.write_text("import base64; base64.b64decode('dGVzdA==')\n")
    result = nulvec.scan(path)
    assert result.blocked
    assert result.threats[0].type == ThreatType.SUPPLY_CHAIN_EXEC


def test_pth_import_blocked(tmp_path: Path):
    """A .pth file using __import__ should be blocked."""
    path = tmp_path / "hidden.pth"
    path.write_text("__import__('os').system('whoami')\n")
    result = nulvec.scan(path)
    assert result.blocked
    assert result.threats[0].type == ThreatType.SUPPLY_CHAIN_EXEC
