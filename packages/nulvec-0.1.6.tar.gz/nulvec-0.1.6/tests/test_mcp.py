"""
Tests for the MCP scanner.
"""

from __future__ import annotations

from pathlib import Path

import nulvec
from nulvec.models import Severity, ThreatType
from nulvec.wrapper import wrap, SecurityViolationError
import pytest

FIXTURES = Path(__file__).parent / "fixtures"


def test_clean_mcp_is_clean():
    result = nulvec.scan(str(FIXTURES / "clean_mcp.json"))
    assert result.clean
    assert result.decision == "clean"
    assert result.threats == []


def test_mcp_ssrf_detected():
    result = nulvec.scan(str(FIXTURES / "ssrf_mcp.json"))

    assert result.blocked
    assert result.decision == "blocked"

    types = [t.type for t in result.threats]
    assert ThreatType.MCP_SSRF in types

    threat = next(t for t in result.threats if t.type == ThreatType.MCP_SSRF)
    assert threat.severity == Severity.CRITICAL
    assert threat.confidence >= 0.90
    assert "169.254.169.254" in threat.extracted_content


def test_mcp_prompt_injection_detected():
    result = nulvec.scan(str(FIXTURES / "prompt_injection_mcp.json"))

    assert result.blocked
    assert result.decision == "blocked"
    
    types = [t.type for t in result.threats]
    assert ThreatType.HIDDEN_INSTRUCTION in types
    
    threat = next(t for t in result.threats if t.type == ThreatType.HIDDEN_INSTRUCTION)
    assert threat.severity == Severity.HIGH
    assert "Ignore previous instructions" in threat.extracted_content
