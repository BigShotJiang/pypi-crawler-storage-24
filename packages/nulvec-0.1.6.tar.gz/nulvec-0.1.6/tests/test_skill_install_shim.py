from __future__ import annotations

import json
from pathlib import Path

import pytest

from nulvec.cli import main


FIXTURES = Path(__file__).parent / "fixtures"


def _configure_runtime(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> Path:
    nulvec_home = tmp_path / "nulvec-home"
    git_config = tmp_path / "gitconfig"
    shell_rc = tmp_path / ".zshrc"
    monkeypatch.setenv("NULVEC_HOME", str(nulvec_home))
    monkeypatch.setenv("GIT_CONFIG_GLOBAL", str(git_config))
    monkeypatch.setenv("NULVEC_SHELL_RC", str(shell_rc))
    return nulvec_home


def _run_cli(monkeypatch: pytest.MonkeyPatch, argv: list[str]) -> int:
    monkeypatch.setattr("sys.argv", argv)
    with pytest.raises(SystemExit) as exc_info:
        main()
    return int(exc_info.value.code)


def test_skill_install_allows_clean_artifact(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    tmp_path: Path,
):
    nulvec_home = _configure_runtime(monkeypatch, tmp_path)
    monkeypatch.chdir(tmp_path)

    assert _run_cli(monkeypatch, ["nulvec", "install"]) == 0
    capsys.readouterr()

    destination = nulvec_home / "skills" / "web-research"
    assert _run_cli(
        monkeypatch,
        ["nulvec", "skill", "install", str(FIXTURES / "clean_skill.md"), "--name", "web-research"],
    ) == 0

    assert (destination / "SKILL.md").exists()

    approved_hashes = json.loads((nulvec_home / "cache" / "approved_hashes.json").read_text())
    assert len(approved_hashes) == 1

    second_destination = tmp_path / "second-skill-copy"
    assert _run_cli(
        monkeypatch,
        [
            "nulvec",
            "skill",
            "install",
            str(FIXTURES / "clean_skill.md"),
            "--dest",
            str(second_destination),
        ],
    ) == 0

    assert (second_destination / "SKILL.md").exists()
    approved_hashes = json.loads((nulvec_home / "cache" / "approved_hashes.json").read_text())
    assert len(approved_hashes) == 1
    assert "approved hash cache hit" in capsys.readouterr().err


def test_skill_install_blocks_malicious_artifact(
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
    tmp_path: Path,
):
    nulvec_home = _configure_runtime(monkeypatch, tmp_path)
    monkeypatch.chdir(tmp_path)

    assert _run_cli(monkeypatch, ["nulvec", "install"]) == 0
    capsys.readouterr()

    destination = nulvec_home / "skills" / "blocked-skill"
    assert _run_cli(
        monkeypatch,
        ["nulvec", "skill", "install", str(FIXTURES / "exfil_skill.md"), "--name", "blocked-skill"],
    ) == 1

    assert not destination.exists()
    approved_hashes = json.loads((nulvec_home / "cache" / "approved_hashes.json").read_text())
    assert approved_hashes == {}

    error_output = capsys.readouterr().err
    assert "blocked skill install" in error_output
