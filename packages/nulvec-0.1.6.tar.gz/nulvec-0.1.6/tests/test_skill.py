"""
Tests for the SKILL.md scanner.

Fixtures use the ClawHavoc attack pattern from the ClawHub incident.
All tests run against local fixture files — no network required.
"""

from __future__ import annotations

from pathlib import Path

import nulvec
from nulvec.models import Severity, ThreatType

FIXTURES = Path(__file__).parent / "fixtures"


def test_clean_skill_is_clean():
    result = nulvec.scan(str(FIXTURES / "clean_skill.md"))
    assert result.clean
    assert result.decision == "clean"
    assert result.threats == []


def test_clawhavoc_pipe_to_shell_detected():
    """The canonical ClawHavoc pattern: curl piped into bash."""
    result = nulvec.scan(str(FIXTURES / "clawhavoc_skill.md"))

    assert result.blocked
    assert result.decision == "blocked"

    types = [t.type for t in result.threats]
    assert ThreatType.SKILL_MALWARE in types

    threat = next(t for t in result.threats if t.type == ThreatType.SKILL_MALWARE)
    assert threat.severity == Severity.CRITICAL
    assert threat.confidence >= 0.95
    assert "curl" in threat.extracted_content.lower()
    assert "192.168" in threat.extracted_content or "bash" in threat.extracted_content.lower()


def test_clawhavoc_bare_ip_detected():
    """Bare/private IP URL is flagged even without pipe-to-shell."""
    result = nulvec.scan(str(FIXTURES / "clawhavoc_skill.md"))
    types = [t.type for t in result.threats]
    # Either SKILL_MALWARE (pipe-to-shell) or bare IP should be present
    assert ThreatType.SKILL_MALWARE in types


def test_exfiltration_skill_detected():
    """Credential exfiltration pattern — reads SSH keys, env vars, sends them out."""
    result = nulvec.scan(str(FIXTURES / "exfil_skill.md"))

    assert result.blocked
    types = [t.type for t in result.threats]
    assert ThreatType.EXFILTRATION_ATTEMPT in types or ThreatType.SKILL_MALWARE in types

    # At least one CRITICAL threat
    severities = [t.severity for t in result.threats]
    assert Severity.CRITICAL in severities


def test_scan_result_fields():
    result = nulvec.scan(str(FIXTURES / "clean_skill.md"))
    assert result.scanner == "skill"
    assert result.modality == "skill"
    assert result.scan_duration_ms > 0
    assert result.scan_id != ""
    assert result.input_hash != ""
    assert result.scanned_at is not None
