from __future__ import annotations

import os
import subprocess
from pathlib import Path

import pytest

from nulvec.cli import main


def test_install_hook_local_scope(monkeypatch: pytest.MonkeyPatch, capsys: pytest.CaptureFixture[str], tmp_path: Path):
    subprocess.run(["git", "init"], cwd=tmp_path, check=True, capture_output=True, text=True)
    monkeypatch.chdir(tmp_path)
    monkeypatch.setattr(
        "sys.argv",
        ["nulvec", "install-hook", "--scope", "local", "--block-on", "critical"],
    )

    with pytest.raises(SystemExit) as exc_info:
        main()

    assert exc_info.value.code == 0

    post_checkout = tmp_path / ".git" / "hooks" / "post-checkout"
    post_merge = tmp_path / ".git" / "hooks" / "post-merge"

    assert post_checkout.exists()
    assert post_merge.exists()
    assert os.access(post_checkout, os.X_OK)
    assert os.access(post_merge, os.X_OK)
    hook_script = post_checkout.read_text()
    assert "HOOK_NAME=\"post-checkout\"" in hook_script
    assert "BLOCK_ON=\"critical\"" in hook_script
    assert "ACTION=\"warn\"" in hook_script

    output = capsys.readouterr().out
    assert "Installed hook:" in output
