"""
Stage 2: Deep Inspection — runs only on SUSPICIOUS inputs from Stage 1.

Target: <200ms end-to-end.
Dispatches to the appropriate full scanner module.
Result is a complete ScanResult with threats, confidence, and evidence.

In production this is enqueued as a Celery task for async processing.
For MVP (sync mode), it runs inline and blocks until complete.
"""

from __future__ import annotations

import time
from pathlib import Path

from nulvec.models import ScanResult, Severity, Threat, ThreatType
from nulvec.stage1.triage import TriageResult
from nulvec.scanners import code as code_scanner
from nulvec.scanners import image as image_scanner
from nulvec.scanners import mcp as mcp_scanner
from nulvec.scanners import pdf as pdf_scanner
from nulvec.scanners import skill as skill_scanner


# Modality → scanner mapping
_SCANNERS = {
    "code":  code_scanner.scan,
    "image": image_scanner.scan,
    "pdf":   pdf_scanner.scan,
    "skill": skill_scanner.scan,
    "mcp":   mcp_scanner.scan,
}

# Extensions → modality
_IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tiff", ".tif"}
_PDF_EXTS   = {".pdf"}
_SKILL_EXTS = {".md", ".markdown"}
_CODE_EXTS  = {".py", ".js", ".ts", ".go", ".rb", ".sh", ".bash", ".pth"}
_MCP_EXTS   = {".json"}


def deep_scan(
    file_path: str | Path,
    modality: str,
    triage_result: TriageResult,
) -> ScanResult:
    """
    Run full deep inspection on a file flagged as SUSPICIOUS by Stage 1.

    Returns a ScanResult with stage=2.
    If no scanner exists for the modality, returns the triage suspicion
    as a low-confidence threat so it isn't silently dropped.
    """
    path = Path(file_path)
    start = time.monotonic()

    scanner_fn = _scanners_for(modality, path)

    if scanner_fn is None:
        # No deep scanner for this modality yet — return triage finding
        duration_ms = (time.monotonic() - start) * 1000
        threat = Threat(
            type=ThreatType.HIDDEN_INSTRUCTION,
            severity=Severity.MEDIUM,
            confidence=0.5,
            description=(
                f"Stage 1 flagged this {modality} file but no Stage 2 scanner "
                f"exists yet. Triage reason: {triage_result.reason}"
            ),
            extracted_content=triage_result.reason,
            location="stage1_triage",
        )
        return ScanResult(
            file_path=str(path),
            scanner=modality,
            modality=modality,
            threats=[threat],
            stage=2,
            scan_duration_ms=round(duration_ms, 2),
        )

    result = scanner_fn(path)
    result.stage = 2

    # If Stage 1 caught a specific content anomaly (not just "needs inspection")
    # but Stage 2 couldn't confirm it, preserve as a low-confidence finding.
    # Do NOT add a fallback when Stage 1's reason is a routing signal
    # (i.e. image/pdf are always routed to Stage 2 regardless of content).
    _ROUTING_REASONS = {
        "image requires Stage 2 OCR and steganography inspection",
        "PDF requires Stage 2 text extraction to detect hidden content",
        ".pth file requires Stage 2 inspection for executable code detection",
    }
    if not result.threats and triage_result.reason not in _ROUTING_REASONS:
        result.threats.append(
            Threat(
                type=ThreatType.HIDDEN_INSTRUCTION,
                severity=Severity.LOW,
                confidence=0.35,
                description=f"Stage 1 heuristic flag (not confirmed by deep scan): {triage_result.reason}",
                extracted_content=triage_result.reason,
                location="stage1_triage",
            )
        )

    return result


def _scanners_for(modality: str, path: Path):
    """Return the scanner function for this modality, or None."""
    if modality in _SCANNERS:
        return _SCANNERS[modality]

    # Fall back to extension-based detection
    ext = path.suffix.lower()
    if ext in _IMAGE_EXTS:
        return image_scanner.scan
    if ext in _PDF_EXTS:
        return pdf_scanner.scan
    if ext in _SKILL_EXTS:
        return skill_scanner.scan
    if ext in _CODE_EXTS:
        return code_scanner.scan
    if ext in _MCP_EXTS:
        return mcp_scanner.scan

    return None
