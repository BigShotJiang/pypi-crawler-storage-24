"""
HTML-first compliance artifact generation for local scan results.
"""

from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from html import escape
import json
from pathlib import Path
from typing import Any, Sequence

from nulvec.models import ScanResult


QUESTIONNAIRE_TEMPLATES = ("generic", "sig_lite", "caiq", "vsa")


def generate_threat_report(
    scans: Sequence[ScanResult],
    output_path: str | Path,
    *,
    questionnaire_template: str = "generic",
) -> str:
    """
    Generate an HTML compliance artifact from scan results.

    If a `.pdf` path is provided, the output is rewritten to `.html` to avoid
    implying native PDF generation that does not exist yet.
    """
    report = build_compliance_report(scans)
    html = render_compliance_artifact_html(report)
    path = _normalize_output_path(output_path)
    path.write_text(html, encoding="utf-8")
    return str(path.resolve())


def build_compliance_report(scans: Sequence[ScanResult], *, evidence_limit: int = 25) -> dict[str, Any]:
    records = [_scan_to_record(scan) for scan in scans]
    decision_counts = Counter(record["decision"] for record in records)
    modality_counts = Counter(record["modality"] for record in records)
    threat_counts = Counter()
    severity_counts = Counter()
    total_latency = 0

    for record in records:
        total_latency += record["latency_ms"]
        for threat in record["threats"]:
            threat_counts[threat["type"]] += 1
            severity_counts[threat["severity"]] += 1

    gaps = [
        "Policy version is not yet persisted on local scan results.",
        "Policy action and matched rules are not yet persisted on local scan results.",
        "This artifact is evidence-bearing but not externally cryptographically verified.",
    ]
    report = {
        "generated_at": _iso_now(),
        "reporting_period": {
            "start": min((record["scanned_at"] for record in records), default=None),
            "end": max((record["scanned_at"] for record in records), default=None),
        },
        "summary": {
            "total_scans": len(records),
            "blocked": decision_counts.get("blocked", 0),
            "suspicious": decision_counts.get("suspicious", 0),
            "clean": decision_counts.get("clean", 0),
            "threats_detected": sum(threat_counts.values()),
            "average_latency_ms": round(total_latency / len(records), 1) if records else 0.0,
            "by_modality": dict(modality_counts),
            "by_threat_type": dict(threat_counts),
            "by_severity": dict(severity_counts),
        },
        "honesty_notes": [
            "This export reflects only the scan results provided to the CLI command.",
            "Framework references are intentionally conservative and partial.",
            "The HTML artifact can be printed to PDF, but the CLI does not generate native PDF output.",
        ],
        "gaps": gaps,
        "questionnaire_exports": {
            template: _build_questionnaire_export(template, records, gaps)
            for template in QUESTIONNAIRE_TEMPLATES
        },
        "evidence": records[:evidence_limit],
    }
    return report


def render_compliance_artifact_html(report: dict[str, Any]) -> str:
    summary = report["summary"]
    modality_items = "".join(
        f"<li>{escape(key)}: {count}</li>"
        for key, count in summary["by_modality"].items()
    ) or "<li>No modality evidence available.</li>"
    threat_items = "".join(
        f"<li>{escape(key)}: {count}</li>"
        for key, count in summary["by_threat_type"].items()
    ) or "<li>No detected threats in this export.</li>"
    honesty_items = "".join(f"<li>{escape(item)}</li>" for item in report["honesty_notes"])
    gap_items = "".join(f"<li>{escape(item)}</li>" for item in report["gaps"])

    questionnaire = report["questionnaire_exports"]["generic"]
    questionnaire_items = "".join(
        (
            "<li>"
            f"<strong>{escape(answer['prompt'])}</strong><br />"
            f"{escape(answer['answer'])}"
            "</li>"
        )
        for answer in questionnaire["answers"]
    )

    evidence_cards = []
    for record in report["evidence"]:
        threat_cards = "".join(
            (
                "<li>"
                f"<strong>{escape(threat['severity'].upper())}</strong> {escape(threat['type'])}"
                f" <span class='muted'>{escape(str(threat.get('location') or 'location unavailable'))}</span><br />"
                f"{escape(threat['description'])}<pre>{escape(_truncate(threat['extracted_content'], 220))}</pre>"
                "</li>"
            )
            for threat in record["threats"]
        ) or "<li>No threat evidence recorded.</li>"
        metadata_items = "".join(
            f"<li><strong>{escape(str(key))}:</strong> {escape(_stringify(value))}</li>"
            for key, value in sorted(record["metadata"].items())
        ) or "<li>No scanner metadata recorded.</li>"
        evidence_cards.append(
            "<section class='scan-card'>"
            f"<div class='scan-header'><h3>{escape(record['file_name'])}</h3><span class='badge badge-{escape(record['decision'])}'>{escape(record['decision'].upper())}</span></div>"
            f"<p class='muted'>{escape(record['modality'].upper())} · stage {record['stage']} · {record['latency_ms']} ms · {escape(record['scanned_at'])}</p>"
            f"<p class='muted'>hash {escape(record['input_hash'][:12] if record['input_hash'] else 'n/a')}</p>"
            "<div class='columns'>"
            f"<div><h4>Threat Evidence</h4><ul>{threat_cards}</ul></div>"
            f"<div><h4>Scanner Metadata</h4><ul>{metadata_items}</ul></div>"
            "</div>"
            "</section>"
        )

    return (
        "<!DOCTYPE html>"
        "<html lang='en'>"
        "<head>"
        "<meta charset='utf-8' />"
        "<meta name='viewport' content='width=device-width, initial-scale=1' />"
        "<title>Nulvec Compliance Evidence Artifact</title>"
        "<style>"
        "body{font-family:ui-sans-serif,system-ui,-apple-system,sans-serif;margin:0;background:#f5f1ea;color:#1c1b19;line-height:1.5;}"
        ".page{max-width:1100px;margin:0 auto;padding:40px 24px 64px;}"
        ".hero{background:#17191d;color:#f7f0e8;padding:28px;border-radius:18px;margin-bottom:24px;}"
        ".grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin:20px 0 28px;}"
        ".card,.scan-card{background:#fffaf3;border:1px solid rgba(23,25,29,.08);border-radius:16px;padding:18px;box-shadow:0 8px 30px rgba(23,25,29,.05);}"
        ".scan-card{margin-bottom:16px;}"
        ".scan-header{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;}"
        ".badge{display:inline-flex;padding:4px 8px;border-radius:999px;font-size:12px;font-weight:700;letter-spacing:.05em;}"
        ".badge-blocked{background:#f4d8cf;color:#8f3518;}"
        ".badge-suspicious{background:#f5e4b8;color:#8a6200;}"
        ".badge-clean{background:#d9e8df;color:#335244;}"
        ".columns{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:16px;}"
        ".muted{color:rgba(28,27,25,.64);}"
        "pre{white-space:pre-wrap;background:#f1ece4;border-radius:10px;padding:10px;font-size:12px;overflow-wrap:anywhere;}"
        "ul,ol{padding-left:20px;}"
        "</style>"
        "</head>"
        "<body><div class='page'>"
        "<section class='hero'>"
        "<h1>Nulvec Compliance Evidence Artifact</h1>"
        "<p>Generated from real scan results. This artifact reports what was scanned, what was detected, and what is still missing from the evidence model.</p>"
        f"<p>Generated {escape(report['generated_at'])} · reporting window {escape(str(report['reporting_period']['start'] or 'n/a'))} to {escape(str(report['reporting_period']['end'] or 'n/a'))}</p>"
        "</section>"
        "<section class='grid'>"
        f"<div class='card'><h4>Total scans</h4><div>{summary['total_scans']}</div></div>"
        f"<div class='card'><h4>Blocked</h4><div>{summary['blocked']}</div></div>"
        f"<div class='card'><h4>Warned</h4><div>{summary['suspicious']}</div></div>"
        f"<div class='card'><h4>Clean</h4><div>{summary['clean']}</div></div>"
        f"<div class='card'><h4>Threats</h4><div>{summary['threats_detected']}</div></div>"
        f"<div class='card'><h4>Avg latency</h4><div>{summary['average_latency_ms']:.1f} ms</div></div>"
        "</section>"
        "<section class='columns'>"
        f"<div class='card'><h2>Modalities</h2><ul>{modality_items}</ul></div>"
        f"<div class='card'><h2>Threat Breakdown</h2><ul>{threat_items}</ul></div>"
        "</section>"
        "<section><h2>Honesty Notes</h2><ul>"
        f"{honesty_items}"
        "</ul></section>"
        "<section><h2>Known Gaps</h2><ul>"
        f"{gap_items}"
        "</ul></section>"
        "<section><h2>Questionnaire Preview</h2><ol>"
        f"{questionnaire_items}"
        "</ol></section>"
        "<section><h2>Evidence</h2>"
        f"{''.join(evidence_cards) or '<div class=\"card\">No scan evidence available.</div>'}"
        "</section>"
        "</div></body></html>"
    )


def render_questionnaire_markdown(report: dict[str, Any], *, template: str = "generic") -> str:
    export = report["questionnaire_exports"][template]
    lines = [
        f"# {export['title']}",
        "",
        export["disclaimer"],
        "",
    ]
    for index, answer in enumerate(export["answers"], start=1):
        lines.append(f"{index}. {answer['prompt']}")
        lines.append(f"   Answer: {answer['answer']}")
        lines.append(f"   Evidence: {'; '.join(answer['evidence_points']) or 'No direct evidence points recorded.'}")
        lines.append("")
    return "\n".join(lines).strip() + "\n"


def _scan_to_record(scan: ScanResult) -> dict[str, Any]:
    return {
        "scan_id": scan.scan_id,
        "file_name": Path(scan.file_path).name,
        "modality": scan.modality,
        "decision": scan.decision,
        "stage": scan.stage,
        "latency_ms": scan.latency_ms,
        "confidence": scan.confidence,
        "scanned_at": scan.scanned_at.isoformat(),
        "input_hash": scan.input_hash,
        "metadata": scan.metadata or {},
        "threats": [
            {
                "type": threat.type.value,
                "severity": threat.severity.value,
                "confidence": threat.confidence,
                "description": threat.description,
                "extracted_content": threat.extracted_content,
                "location": threat.location,
            }
            for threat in scan.threats
        ],
    }


def _build_questionnaire_export(template: str, records: Sequence[dict[str, Any]], gaps: Sequence[str]) -> dict[str, Any]:
    summary_counts = Counter(record["decision"] for record in records)
    modalities = ", ".join(sorted({record["modality"] for record in records})) or "none"
    answers = [
        {
            "prompt": "How do you validate agent inputs before use?",
            "answer": (
                f"Nulvec scanned {len(records)} input(s) across {modalities} in this export and recorded a clean, suspicious, or blocked decision for each one."
                if records
                else "No scan evidence is available in this export yet."
            ),
            "evidence_points": [f"blocked={summary_counts.get('blocked', 0)}", f"suspicious={summary_counts.get('suspicious', 0)}", f"clean={summary_counts.get('clean', 0)}"],
        },
        {
            "prompt": "What evidence is retained?",
            "answer": "Each record in this export includes a timestamp, input hash, decision, modality, latency, and any threat evidence captured by the scanner.",
            "evidence_points": ["timestamped records", "input hashes", "threat excerpts", "scanner metadata"],
        },
        {
            "prompt": "What limitations remain?",
            "answer": "; ".join(gaps),
            "evidence_points": list(gaps),
        },
    ]
    if template != "generic":
        answers.insert(
            0,
            {
                "prompt": "What is the scope of this export?",
                "answer": (
                    f"This is a Nulvec-authored {template.replace('_', ' ').upper()}-aligned response pack populated from actual scan results. "
                    "It is not a completed official questionnaire submission."
                ),
                "evidence_points": ["template alignment note"],
            },
        )
    return {
        "template": template,
        "title": _questionnaire_title(template),
        "disclaimer": _questionnaire_disclaimer(template),
        "answers": answers,
    }


def _questionnaire_title(template: str) -> str:
    if template == "generic":
        return "Generic Security Questionnaire Export"
    if template == "sig_lite":
        return "SIG Lite-Aligned Export"
    if template == "caiq":
        return "CAIQ-Aligned Export"
    return "Vendor Security Assessment Export"


def _questionnaire_disclaimer(template: str) -> str:
    if template == "generic":
        return "Generated from the supplied scan results. Review before external sharing."
    return (
        f"Generated from the supplied scan results as a {template.replace('_', ' ').upper()}-aligned response pack. "
        "Review and complete customer-specific gaps before sharing."
    )


def _normalize_output_path(output_path: str | Path) -> Path:
    path = Path(output_path)
    if path.suffix.lower() == ".pdf":
        return path.with_suffix(".html")
    if path.suffix:
        return path
    return path.with_suffix(".html")


def _truncate(value: str, limit: int) -> str:
    if len(value) <= limit:
        return value
    return value[: limit - 1] + "…"


def _stringify(value: Any) -> str:
    if isinstance(value, str):
        return value
    return json.dumps(value, sort_keys=True)


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()
