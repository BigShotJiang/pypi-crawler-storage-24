"""
Image scanner — detects adversarial content hidden in images.

Attacks detected:
  1. Image scaling attack (Trail of Bits, 2025)
     Text invisible at full resolution that becomes readable after pipeline
     downscaling. Common in multimodal agent pipelines that resize inputs.

  2. LSB steganographic injection (basic)
     Payload hidden in the least-significant bits of pixel channels.
"""

from __future__ import annotations

import difflib
import time
from pathlib import Path
from typing import Optional

from PIL import Image

from nulvec.models import ScanResult, Severity, Threat, ThreatType
from nulvec.utils import ocr_text, normalize_text, is_adversarial_instruction


# Scales to probe for the image scaling attack.
# 0.5x is the canonical Trail of Bits finding; we probe others too.
PROBE_SCALES = [0.75, 0.5, 0.25]

# Minimum number of new words at a downscaled resolution to flag as suspicious.
NEW_WORDS_THRESHOLD = 6


def scan(file_path: str | Path) -> ScanResult:
    """Scan an image file for adversarial injections."""
    path = Path(file_path)
    start = time.monotonic()
    threats: list[Threat] = []

    img = Image.open(path).convert("RGB")

    # ── 1. Image scaling attack ──────────────────────────────────────────
    scaling_threat = _detect_scaling_attack(img)
    if scaling_threat:
        threats.append(scaling_threat)

    # ── 2. LSB steganography (basic) ────────────────────────────────────
    lsb_threat = _detect_lsb_payload(img)
    if lsb_threat:
        threats.append(lsb_threat)

    duration_ms = (time.monotonic() - start) * 1000

    return ScanResult(
        file_path=str(path),
        scanner="image",
        modality="image",
        threats=threats,
        scan_duration_ms=round(duration_ms, 2),
        metadata={
            "width": img.width,
            "height": img.height,
            "format": img.format or path.suffix.lstrip(".").upper(),
        },
    )


def _detect_scaling_attack(img: Image.Image) -> Optional[Threat]:
    """
    Run OCR at full resolution and at each probe scale.
    Text that appears at a downscaled resolution but NOT at full resolution
    is a signature of the image scaling attack class.
    """
    full_text = normalize_text(ocr_text(img))
    full_words = set(full_text.split())

    best_new_text = ""
    best_scale = 1.0
    max_new_words = 0

    for scale in PROBE_SCALES:
        new_w = max(1, int(img.width * scale))
        new_h = max(1, int(img.height * scale))
        downscaled = img.resize((new_w, new_h), Image.LANCZOS)
        scaled_text = normalize_text(ocr_text(downscaled))
        scaled_words = set(scaled_text.split())

        # Words present at this scale but absent at full resolution
        new_words = scaled_words - full_words
        if len(new_words) > max_new_words:
            max_new_words = len(new_words)
            best_new_text = scaled_text
            best_scale = scale

    if max_new_words < NEW_WORDS_THRESHOLD:
        return None

    # Only flag if the new content looks like an adversarial instruction
    if not is_adversarial_instruction(best_new_text):
        return None

    confidence = min(0.99, 0.5 + (max_new_words / 50))
    return Threat(
        type=ThreatType.SCALING_ATTACK,
        severity=Severity.CRITICAL,
        confidence=round(confidence, 3),
        description=(
            f"Hidden text emerged at {best_scale}× scale that is absent "
            f"at full resolution — image scaling attack pattern."
        ),
        extracted_content=best_new_text[:500],
        location=f"{best_scale}x scale",
    )


def _detect_lsb_payload(img: Image.Image) -> Optional[Threat]:
    """
    Basic LSB (least-significant bit) steganography detection.

    Checks whether the LSB plane of the red channel has a statistical
    distribution inconsistent with natural images (near-uniform → injected).
    This is a heuristic; a proper steganalysis tool (stegoveritas) gives
    higher accuracy but requires heavier dependencies.
    """
    pixels = list(img.getdata())
    if len(pixels) < 1000:
        return None

    # Sample up to 50k pixels for speed
    sample = pixels[:50_000]
    red_lsbs = [p[0] & 1 for p in sample]
    ones_ratio = sum(red_lsbs) / len(red_lsbs)

    # Natural images: LSB ratio should be close to 0.5 with noise.
    # LSB injection: ratio is often very close to exactly 0.5 (uniform random).
    lsb_deviation = abs(ones_ratio - 0.5)

    # Flag only when deviation is suspiciously low (injected) not natural variance
    if lsb_deviation > 0.08:
        return None

    confidence = round(1.0 - (lsb_deviation / 0.08) * 0.4, 3)
    return Threat(
        type=ThreatType.STEGANOGRAPHIC,
        severity=Severity.HIGH,
        confidence=confidence,
        description=(
            "Red channel LSB plane shows near-uniform distribution "
            "(deviation from 0.5: {:.4f}), consistent with LSB steganographic injection.".format(
                lsb_deviation
            )
        ),
        extracted_content=f"LSB ones ratio: {ones_ratio:.4f} over {len(sample):,} sampled pixels",
        location="red channel LSB plane",
    )
