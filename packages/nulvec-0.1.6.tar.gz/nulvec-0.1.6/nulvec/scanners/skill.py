"""
SKILL.md scanner — detects supply chain attacks in agent skill packages.

Attack class — ClawHavoc pattern (from ClawHub incident):
  A SKILL.md file distributed through a public agent registry contains a
  malicious shell command hidden in the Prerequisites section. When an agent
  loads the skill, it executes the command, exfiltrating SSH keys, API keys,
  browser cookies, and environment variables to an attacker-controlled server.

~12% of skills in public agent registries were confirmed malware in audits.

Detects:
  1. Bare IP curl/wget commands (direct IP = no DNS, no audit trail)
  2. Pipe-to-shell patterns (curl ... | bash/sh — arbitrary remote execution)
  3. Credential exfiltration patterns (env vars, .ssh/, API keys piped out)
  4. Prompt injection in skill instructions (override agent behavior)
  5. Suspicious capability declarations (capabilities not matching description)
"""

from __future__ import annotations

import re
import time
from pathlib import Path
from typing import Optional

from nulvec.models import ScanResult, Severity, Threat, ThreatType
from nulvec.utils import is_adversarial_instruction


# ── Compiled patterns ─────────────────────────────────────────────────────────

# Bare IP address in a URL (no domain name → bypasses DNS-based filtering)
_BARE_IP_URL = re.compile(
    r"https?://\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}"
)

# Private / RFC-1918 IP ranges used for SSRF or internal pivoting
_PRIVATE_IP = re.compile(
    r"https?://"
    r"(?:10\.\d+\.\d+\.\d+|"
    r"172\.(?:1[6-9]|2\d|3[01])\.\d+\.\d+|"
    r"192\.168\.\d+\.\d+|"
    r"127\.\d+\.\d+\.\d+|"
    r"0\.0\.0\.0)"
)

# Pipe-to-shell: curl/wget output piped directly into bash/sh
_PIPE_TO_SHELL = re.compile(
    r"(?:curl|wget)\s+[^\n|]+\|\s*(?:ba)?sh",
    re.IGNORECASE,
)

# Credential exfiltration: reading sensitive files/env vars and sending them out
_EXFIL_PATTERNS = [
    re.compile(r"cat\s+~?/\.ssh/", re.IGNORECASE),              # SSH private keys
    re.compile(r"cat\s+~?/\.config/", re.IGNORECASE),           # tool configs (gh, etc.)
    re.compile(r"\$\(\s*env\b", re.IGNORECASE),                  # env var dump
    re.compile(r"grep\s+-i\s+(?:key|token|secret|pass)", re.IGNORECASE),
    re.compile(r"printenv", re.IGNORECASE),
    re.compile(r"~/.aws/credentials", re.IGNORECASE),
    re.compile(r"~/.kube/config", re.IGNORECASE),
]

# Suspicious Prerequisites section — shell code blocks inside Prerequisites
_PREREQUISITES_SECTION = re.compile(
    r"##\s*prerequisites.*?(?=##|\Z)",
    re.IGNORECASE | re.DOTALL,
)

# Shell code fence inside any section
_SHELL_CODE_BLOCK = re.compile(
    r"```(?:bash|sh|shell|zsh|fish)?\s*\n(.*?)```",
    re.IGNORECASE | re.DOTALL,
)


def scan(file_path: str | Path) -> ScanResult:
    """Scan a SKILL.md file for supply chain attack patterns."""
    path = Path(file_path)
    start = time.monotonic()
    threats: list[Threat] = []

    text = path.read_text(encoding="utf-8", errors="replace")

    t = _detect_pipe_to_shell(text)
    if t:
        threats.append(t)

    t = _detect_bare_ip(text)
    if t:
        threats.append(t)

    t = _detect_credential_exfiltration(text)
    if t:
        threats.append(t)

    t = _detect_prompt_injection(text)
    if t:
        threats.append(t)

    duration_ms = (time.monotonic() - start) * 1000

    return ScanResult(
        file_path=str(path),
        scanner="skill",
        modality="skill",
        threats=threats,
        scan_duration_ms=round(duration_ms, 2),
        metadata={"lines": text.count("\n"), "size_bytes": len(text.encode())},
    )


def _detect_pipe_to_shell(text: str) -> Optional[Threat]:
    """
    Detect curl/wget output piped directly into a shell interpreter.
    This is the canonical remote code execution vector in the ClawHavoc pattern.
    """
    match = _PIPE_TO_SHELL.search(text)
    if not match:
        return None

    snippet = match.group(0).strip()
    location = _locate_in_section(text, match.start())

    return Threat(
        type=ThreatType.SKILL_MALWARE,
        severity=Severity.CRITICAL,
        confidence=0.99,
        description=(
            "Pipe-to-shell pattern detected in SKILL.md. "
            "curl/wget output piped into bash/sh executes arbitrary remote code "
            "on the host machine when the skill is loaded."
        ),
        extracted_content=snippet,
        location=location,
    )


def _detect_bare_ip(text: str) -> Optional[Threat]:
    """
    Detect bare IP address URLs. Legitimate skills use domain names.
    Bare IPs bypass DNS-based filtering and leave no audit trail.
    """
    # Prefer private-range IPs (higher severity) before public bare IPs
    match = _PRIVATE_IP.search(text) or _BARE_IP_URL.search(text)
    if not match:
        return None

    is_private = bool(_PRIVATE_IP.search(match.group(0)))
    snippet = _extract_line(text, match.start())
    location = _locate_in_section(text, match.start())

    return Threat(
        type=ThreatType.SKILL_MALWARE,
        severity=Severity.CRITICAL if is_private else Severity.HIGH,
        confidence=0.97,
        description=(
            f"{'Private-range' if is_private else 'Bare'} IP address URL in SKILL.md. "
            "Legitimate skills use domain names. Bare IPs bypass DNS filtering "
            "and are a strong indicator of a supply chain attack."
        ),
        extracted_content=snippet,
        location=location,
    )


def _detect_credential_exfiltration(text: str) -> Optional[Threat]:
    """
    Detect patterns that read credentials and send them to a remote endpoint.
    SSH keys, env vars, cloud credentials, config files.
    """
    for pattern in _EXFIL_PATTERNS:
        match = pattern.search(text)
        if match:
            snippet = _extract_line(text, match.start())
            location = _locate_in_section(text, match.start())
            return Threat(
                type=ThreatType.EXFILTRATION_ATTEMPT,
                severity=Severity.CRITICAL,
                confidence=0.96,
                description=(
                    "Credential exfiltration pattern detected. "
                    "Skill reads sensitive files or environment variables "
                    "(SSH keys, API tokens, cloud credentials) — "
                    "consistent with the ClawHavoc credential theft pattern."
                ),
                extracted_content=snippet,
                location=location,
            )
    return None


def _detect_prompt_injection(text: str) -> Optional[Threat]:
    """
    Detect adversarial instructions embedded in skill metadata or description
    fields designed to override agent behavior when the skill is loaded.
    """
    # Extract text outside code blocks to avoid flagging legitimate examples
    clean_text = _SHELL_CODE_BLOCK.sub("", text)

    # Check each line that looks like a description or instruction field
    for line in clean_text.splitlines():
        stripped = line.strip().lstrip("#").strip()
        if len(stripped) > 10 and is_adversarial_instruction(stripped):
            return Threat(
                type=ThreatType.HIDDEN_INSTRUCTION,
                severity=Severity.HIGH,
                confidence=0.88,
                description=(
                    "Prompt injection detected in SKILL.md metadata. "
                    "The skill contains instructions designed to override agent "
                    "behavior when the skill definition is loaded into context."
                ),
                extracted_content=stripped[:300],
                location="skill_metadata",
            )
    return None


# ── Helpers ───────────────────────────────────────────────────────────────────

def _locate_in_section(text: str, char_offset: int) -> str:
    """Return the section heading nearest to char_offset."""
    section_header = re.compile(r"^##\s+(.+)$", re.MULTILINE)
    last_section = "skill_root"
    for m in section_header.finditer(text):
        if m.start() <= char_offset:
            last_section = "skill_" + m.group(1).strip().lower().replace(" ", "_")
        else:
            break
    return last_section


def _extract_line(text: str, char_offset: int) -> str:
    """Return the full line containing char_offset."""
    start = text.rfind("\n", 0, char_offset) + 1
    end = text.find("\n", char_offset)
    return text[start: end if end != -1 else len(text)].strip()
