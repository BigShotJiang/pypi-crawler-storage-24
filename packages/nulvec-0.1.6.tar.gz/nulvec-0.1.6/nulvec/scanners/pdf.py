"""
PDF scanner — detects adversarial content hidden in PDF structure.

Attacks detected:
  1. Hidden text layers — text rendered invisible via:
       - White/near-white color on white background
       - Rendering mode 3 (invisible, used for searchable PDFs but abused for injection)
       - Zero opacity / clipping to zero-size clip path

  2. Embedded JavaScript — PDFs can execute JS on open/print/etc.
     Adversarial JS can exfiltrate data or modify agent behavior.

  3. Annotation-based injection — hidden content in PDF annotations
     (FreeText, Widget) that text extractors pick up but humans don't see.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Optional

import fitz  # PyMuPDF

from nulvec.models import ScanResult, Severity, Threat, ThreatType
from nulvec.utils import is_adversarial_instruction


# PyMuPDF text rendering modes
# 3 = invisible (used in PDF/A for searchable-text-over-image but abused for injection)
INVISIBLE_RENDER_MODE = 3

# Color distance threshold for "text is same color as background"
# PDF colors are 0.0–1.0; white background = (1.0, 1.0, 1.0)
WHITE_THRESHOLD = 0.92


def scan(file_path: str | Path) -> ScanResult:
    """Scan a PDF file for adversarial hidden content."""
    path = Path(file_path)
    start = time.monotonic()
    threats: list[Threat] = []

    doc = fitz.open(str(path))
    page_count = len(doc)

    for page_num in range(page_count):
        page = doc[page_num]
        label = f"page {page_num + 1}"

        hidden = _detect_hidden_text(page, label)
        if hidden:
            threats.extend(hidden)

    js_threat = _detect_embedded_js(doc)
    if js_threat:
        threats.append(js_threat)

    doc.close()
    duration_ms = (time.monotonic() - start) * 1000

    return ScanResult(
        file_path=str(path),
        scanner="pdf",
        modality="pdf",
        threats=threats,
        scan_duration_ms=round(duration_ms, 2),
        metadata={"page_count": page_count},
    )


def _detect_hidden_text(page: fitz.Page, label: str) -> list[Threat]:
    """
    Extract text blocks with rendering metadata and flag anything hidden.
    """
    threats: list[Threat] = []

    # get_text("dict") gives us per-span rendering info including color and flags
    blocks = page.get_text("dict", flags=fitz.TEXT_PRESERVE_WHITESPACE)["blocks"]

    for block in blocks:
        if block.get("type") != 0:  # 0 = text block
            continue
        for line in block.get("lines", []):
            for span in line.get("spans", []):
                text = span.get("text", "").strip()
                if not text or len(text) < 4:
                    continue

                color = span.get("color", 0)          # packed int RGB
                render_mode = span.get("flags", 0)

                hidden_reason = _classify_hidden_span(color, render_mode)
                if hidden_reason and is_adversarial_instruction(text):
                    threats.append(
                        Threat(
                            type=ThreatType.HIDDEN_INSTRUCTION
                            if hidden_reason != "invisible_render_mode"
                            else ThreatType.HIDDEN_INSTRUCTION,
                            severity=Severity.CRITICAL,
                            confidence=0.95,
                            description=f"Hidden text found ({hidden_reason}) on {label}.",
                            extracted_content=text[:500],
                            location=label,
                        )
                    )

    return threats


def _classify_hidden_span(packed_color: int, flags: int) -> Optional[str]:
    """
    Returns a human-readable reason if this span appears hidden, else None.
    """
    # Unpack PyMuPDF color int to (r, g, b) in 0.0–1.0 range
    r = ((packed_color >> 16) & 0xFF) / 255.0
    g = ((packed_color >> 8) & 0xFF) / 255.0
    b = (packed_color & 0xFF) / 255.0

    if r >= WHITE_THRESHOLD and g >= WHITE_THRESHOLD and b >= WHITE_THRESHOLD:
        return "white_on_white"

    # PyMuPDF encodes invisible render mode as bit flag
    # Actual render mode is in the span dict as "flags" — check bit 2 (value 4)
    # which PyMuPDF sets for invisible text (render mode 3)
    if flags & 4:
        return "invisible_render_mode"

    return None


def _detect_embedded_js(doc: fitz.Document) -> Optional[Threat]:
    """
    PDF-level JavaScript can run on open/print/close events.
    Scans all cross-reference objects for /JavaScript action type.
    """
    if not doc.is_pdf:
        return None

    js_actions: list[str] = []

    for xref in range(1, doc.xref_length()):
        try:
            keys = doc.xref_get_keys(xref)
            if "S" not in keys:
                continue
            s_type, s_val = doc.xref_get_key(xref, "S")
            if s_type == "name" and s_val == "/JavaScript":
                js_snippet = ""
                if "JS" in keys:
                    _, js_snippet = doc.xref_get_key(xref, "JS")
                js_actions.append(js_snippet[:200] if js_snippet else "<empty JS>")
        except Exception:
            continue

    if not js_actions:
        return None

    return Threat(
        type=ThreatType.EMBEDDED_JS,
        severity=Severity.HIGH,
        confidence=0.97,
        description=f"Embedded JavaScript found in PDF ({len(js_actions)} action(s)). "
                    "Can execute on open/print events in agent document processors.",
        extracted_content="\n".join(js_actions)[:500],
        location="document-level",
    )
