"""
Deep Scanner for Model Context Protocol (MCP) and JSON payloads.

Detects:
1. SSRF attempts (internal IP / metadata access)
2. Credential Exfiltration
3. Prompt Injections hidden in JSON fields
"""

from __future__ import annotations

import json
import re
from pathlib import Path

from nulvec.models import ScanResult, Threat, ThreatType, Severity
from nulvec.utils import is_adversarial_instruction

# ── SSRF Patterns ─────────────────────────────────────────────────────────────
_SSRF_PATTERNS = [
    re.compile(r"169\.254\.169\.254", re.IGNORECASE),          # AWS/GCP/Azure Metadata
    re.compile(r"metadata\.google\.internal", re.IGNORECASE),  # GCP Metadata
    re.compile(r"10\.\d{1,3}\.\d{1,3}\.\d{1,3}"),              # Typical VPC internal
    re.compile(r"192\.168\.\d{1,3}\.\d{1,3}"),                 # Typical LAN internal
]

# ── Exfiltration Patterns ─────────────────────────────────────────────────────
_EXFIL_PATTERNS = [
    re.compile(r"curl.*?-d.*?@~/.*?(?:\.ssh|\.aws|\.kube)", re.IGNORECASE),
    re.compile(r"(?:wget|curl).*?\?(?:data|key|token|auth)=.*?\$(?:\w+)", re.IGNORECASE),
]

def scan(path: Path) -> ScanResult:
    """Run full deep inspection on an MCP/JSON payload."""
    result = ScanResult(
        file_path=str(path),
        scanner="mcp",
        modality="mcp",
        stage=2,
    )

    try:
        content = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        result.threats.append(
            Threat(
                type=ThreatType.HIDDEN_INSTRUCTION,
                severity=Severity.LOW,
                confidence=0.5,
                description="Failed to read file contents.",
                extracted_content="",
                location="file_read",
            )
        )
        return result

    # 1. SSRF Detection
    for pattern in _SSRF_PATTERNS:
        match = pattern.search(content)
        if match:
            result.threats.append(
                Threat(
                    type=ThreatType.MCP_SSRF,
                    severity=Severity.CRITICAL,
                    confidence=0.95,
                    description="SSRF pattern detected targeting internal/metadata IP.",
                    extracted_content=match.group(0),
                    location="mcp_payload",
                )
            )

    # 2. Credential Exfiltration Detection
    for pattern in _EXFIL_PATTERNS:
        match = pattern.search(content)
        if match:
            result.threats.append(
                Threat(
                    type=ThreatType.EXFILTRATION_ATTEMPT,
                    severity=Severity.CRITICAL,
                    confidence=0.95,
                    description="Detected piped credential exfiltration pattern.",
                    extracted_content=match.group(0),
                    location="mcp_payload",
                )
            )

    # 3. Prompt Injection Detection
    # If valid JSON, inspect values; otherwise scan lines
    try:
        payload = json.loads(content)
        _scan_dict_for_injection(payload, result)
    except json.JSONDecodeError:
        # Fallback to line scanning
        lines = [l.strip() for l in content.splitlines() if len(l.strip()) > 10]
        for line in lines[:500]: # bounded lookup
            if is_adversarial_instruction(line):
                result.threats.append(
                    Threat(
                        type=ThreatType.HIDDEN_INSTRUCTION,
                        severity=Severity.HIGH,
                        confidence=0.85,
                        description="Adversarial prompt injection pattern in JSON string payload.",
                        extracted_content=line[:100],
                        location="mcp_payload",
                    )
                )

    return result

def _scan_dict_for_injection(data: dict | list | str | int | float | bool | None, result: ScanResult) -> None:
    """Recursively scan JSON values for adversarial instructions."""
    if isinstance(data, dict):
        for k, v in data.items():
            _scan_dict_for_injection(v, result)
    elif isinstance(data, list):
        for item in data:
            _scan_dict_for_injection(item, result)
    elif isinstance(data, str) and len(data) > 10:
        if is_adversarial_instruction(data):
            result.threats.append(
                Threat(
                    type=ThreatType.HIDDEN_INSTRUCTION,
                    severity=Severity.HIGH,
                    confidence=0.85,
                    description="Adversarial prompt injection pattern inside MCP JSON key.",
                    extracted_content=data[:100],
                    location="mcp_json_value",
                )
            )
