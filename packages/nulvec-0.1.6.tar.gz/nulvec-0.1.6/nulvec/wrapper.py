"""
Nulvec Agent Middleware.

Provides `wrap()` to intercept inputs to AI agents and external tools (like MCP).
"""

from __future__ import annotations

import json
import logging
from typing import Any, Callable

from nulvec.scanner import scan_content  # type: ignore
from nulvec.models import ScanResult  # type: ignore

logger = logging.getLogger(__name__)

class SecurityViolationError(Exception):
    """Raised when Nulvec blocks an adversarial input."""
    def __init__(self, message: str, scan_result: ScanResult):
        super().__init__(message)
        self.scan_result = scan_result


def wrap(agent_or_tool: Any, strict: bool = True) -> Any:
    """
    Wrap an agent, tool, or callable to scan its inputs/outputs.

    Args:
        agent_or_tool: The object or function to wrap.
        strict: If True, blocks on CRITICAL or HIGH.
                If False, logs the threat but allows execution.
                
    Returns:
        A wrapped version of the agent/tool that intercepts calls.
    """
    
    # If it's a simple callable function
    if callable(agent_or_tool) and not hasattr(agent_or_tool, "invoke"):
        def wrapped_func(*args: Any, **kwargs: Any) -> Any:
            # We assume the output of the function is what the agent receives
            result = agent_or_tool(*args, **kwargs)
            _enforce_scan(result, strict)
            return result
        return wrapped_func

    # Wrap LangChain tools or objects with an `invoke` method
    if hasattr(agent_or_tool, "invoke"):
        original_invoke = getattr(agent_or_tool, "invoke")
        
        def safe_invoke(*args: Any, **kwargs: Any) -> Any:
            result = original_invoke(*args, **kwargs)
            _enforce_scan(result, strict)
            return result
            
        # Monkey patch the invoke method
        setattr(agent_or_tool, "invoke", safe_invoke)
        return agent_or_tool

    # If unsupported, return unmodified for now
    logger.warning("nulvec.wrap: Unsupported agent/tool format. Returning unmodified.")
    return agent_or_tool


def _enforce_scan(payload: Any, strict: bool) -> None:
    """
    Scan a payload returning from a tool/API before the agent reads it.
    """
    if payload is None:
        return
        
    text_content = ""
    if isinstance(payload, str):
        text_content = payload
    elif isinstance(payload, dict) or isinstance(payload, list):
        try:
            text_content = json.dumps(payload)
        except Exception:
            text_content = str(payload)
    else:
        text_content = str(payload)

    # Empty payload is safe
    if not text_content.strip():
        return

    try:
        result = scan_content(text_content, filename="payload.json", modality_hint="mcp")
    except Exception as e:
        logger.error(f"Nulvec scan failed during wrap intercept: {e}")
        return

    if result.decision == "blocked":
        msg = f"Nulvec blocked agent input! Detected threats: {[t.type.value for t in result.threats]}"
        if strict:
            raise SecurityViolationError(msg, result)
        else:
            logger.warning(f"STRICT=False -> {msg}")
