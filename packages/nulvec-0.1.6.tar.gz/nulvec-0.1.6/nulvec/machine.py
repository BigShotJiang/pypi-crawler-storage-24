from __future__ import annotations

import json
import os
import shutil
import stat
import subprocess
import sys
import time
from pathlib import Path
from typing import Any


HOOK_FILENAMES = ("post-checkout", "post-merge")
DEFAULT_BLOCK_ON = "high"
DEFAULT_ACTION = "warn"
PATH_BLOCK_START = "# >>> nulvec >>>"
PATH_BLOCK_END = "# <<< nulvec <<<"
SUPPORTED_INTEGRATIONS = {
    "git": {
        "supported": True,
        "mode": "shim+hooks",
        "notes": "Git clone and simple pull flows are intercepted by the shim; hooks remain as a fallback repo scan layer.",
    },
    "clawhub": {
        "supported": True,
        "mode": "nulvec-skill-install",
        "notes": "Protected via `nulvec skill install`; clawhub shim intercepts `clawhub install` automatically.",
    },
    "mcp": {
        "supported": True,
        "mode": "stdio-proxy",
        "notes": "MCP client configs patched to route traffic through nulvec mcp-proxy automatically.",
    },
}
MCP_CLIENT_CONFIGS = {
    "claude_desktop": {"name": "Claude Desktop"},
    "cursor": {"name": "Cursor"},
}


def nulvec_home() -> Path:
    override = _env_path("NULVEC_HOME")
    if override:
        return override

    xdg_home = _env_path("XDG_CONFIG_HOME")
    if xdg_home:
        return xdg_home / "nulvec"

    return Path.home() / ".config" / "nulvec"


def policy_path() -> Path:
    return nulvec_home() / "policy.json"


def log_path() -> Path:
    return nulvec_home() / "events.jsonl"


def cache_dir() -> Path:
    return nulvec_home() / "cache"


def approved_hashes_path() -> Path:
    return cache_dir() / "approved_hashes.json"


def skill_install_root() -> Path:
    return nulvec_home() / "skills"


def git_template_dir() -> Path:
    return nulvec_home() / "git-template"


def git_template_hooks_dir() -> Path:
    return git_template_dir() / "hooks"


def shim_bin_dir() -> Path:
    return nulvec_home() / "bin"


def git_shim_path() -> Path:
    return shim_bin_dir() / "git"


def clawhub_shim_path() -> Path:
    return shim_bin_dir() / "clawhub"


def claude_desktop_config_path() -> Path:
    return Path.home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json"


def cursor_mcp_config_path() -> Path:
    return Path.home() / ".cursor" / "mcp.json"


def shell_rc_path() -> Path:
    override = _env_path("NULVEC_SHELL_RC")
    if override:
        return override

    shell = os.getenv("SHELL", "")
    if "zsh" in shell:
        return Path.home() / ".zshrc"
    if "bash" in shell:
        return Path.home() / ".bashrc"
    return Path.home() / ".profile"


def load_policy() -> dict[str, Any]:
    path = policy_path()
    if not path.exists():
        return default_policy()
    return json.loads(path.read_text(encoding="utf-8"))


def write_policy(policy: dict[str, Any]) -> Path:
    path = policy_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(policy, indent=2) + "\n", encoding="utf-8")
    return path


def default_policy(block_on: str = DEFAULT_BLOCK_ON, action: str = DEFAULT_ACTION) -> dict[str, Any]:
    return {
        "version": 1,
        "installed_at": int(time.time()),
        "log_file": str(log_path()),
        "integrations": {
            "git": {
                "enabled": True,
                "mode": "shim+hooks",
                "block_on": block_on,
                "action": action,
                "real_binary": None,
            },
            "clawhub": {
                "enabled": True,
                "mode": "nulvec-skill-install",
                "block_on": "high",
                "action": "block",
            },
            "mcp": {
                "enabled": True,
                "mode": "stdio-proxy",
                "block_on": "high",
                "action": "block",
            },
        },
    }


def install_machine(block_on: str, action: str, cwd: Path | None = None) -> dict[str, Any]:
    home = nulvec_home()
    home.mkdir(parents=True, exist_ok=True)
    git_template_hooks_dir().mkdir(parents=True, exist_ok=True)
    shim_bin_dir().mkdir(parents=True, exist_ok=True)
    cache_dir().mkdir(parents=True, exist_ok=True)
    skill_install_root().mkdir(parents=True, exist_ok=True)
    log_path().touch(exist_ok=True)

    policy = load_policy()
    real_git = discover_real_git_binary(policy)
    policy["integrations"]["git"]["enabled"] = True
    policy["integrations"]["git"]["mode"] = "shim+hooks"
    policy["integrations"]["git"]["block_on"] = block_on
    policy["integrations"]["git"]["action"] = action
    policy["integrations"]["git"]["real_binary"] = real_git
    policy["integrations"]["clawhub"]["enabled"] = True
    policy["integrations"]["clawhub"]["mode"] = "nulvec-skill-install"
    policy["integrations"]["mcp"]["enabled"] = True
    policy["integrations"]["mcp"]["mode"] = "stdio-proxy"
    write_policy(policy)
    if not approved_hashes_path().exists():
        write_approved_hashes({})

    installed_template_hooks = install_managed_hooks(
        git_template_hooks_dir(),
        block_on=block_on,
        action=action,
        backup_existing=False,
    )
    _git_output(["config", "--global", "init.templateDir", str(git_template_dir())], cwd=cwd)
    shim_path = write_git_shim()
    clawhub_shim = write_clawhub_shim()
    rc_path = ensure_shell_path_activation()
    mcp_clients = install_mcp_client_configs()

    local_hooks: list[Path] = []
    current_repo = current_repo_root(cwd)
    if current_repo is not None:
        local_hooks = install_managed_hooks(
            local_hooks_dir(current_repo),
            block_on=block_on,
            action=action,
            backup_existing=True,
        )

    return {
        "install_dir": str(home),
        "policy_file": str(policy_path()),
        "log_file": str(log_path()),
        "skill_install_root": str(skill_install_root()),
        "approved_hashes_file": str(approved_hashes_path()),
        "git_template_dir": str(git_template_dir()),
        "git_shim": str(shim_path),
        "clawhub_shim": str(clawhub_shim),
        "shell_rc": str(rc_path),
        "real_git_binary": real_git,
        "template_hooks": [str(path) for path in installed_template_hooks],
        "local_hooks": [str(path) for path in local_hooks],
        "current_repo": str(current_repo) if current_repo else None,
        "mcp_clients": mcp_clients,
    }


def install_hook(scope: str, block_on: str, action: str, cwd: Path | None = None) -> list[Path]:
    if scope == "local":
        repo_root = current_repo_root(cwd)
        if repo_root is None:
            raise RuntimeError("Not inside a git repository.")
        hooks_dir = local_hooks_dir(repo_root)
        backup_existing = True
    else:
        hooks_dir = global_hooks_dir(cwd)
        backup_existing = False

    return install_managed_hooks(hooks_dir, block_on=block_on, action=action, backup_existing=backup_existing)


def install_managed_hooks(
    hooks_dir: Path,
    *,
    block_on: str,
    action: str,
    backup_existing: bool,
) -> list[Path]:
    hooks_dir.mkdir(parents=True, exist_ok=True)
    installed: list[Path] = []

    for hook_name in HOOK_FILENAMES:
        hook_path = hooks_dir / hook_name
        backup_path = hook_path.with_name(f"{hook_name}.nulvec-orig")

        if backup_existing and hook_path.exists() and not _is_managed_hook(hook_path) and not backup_path.exists():
            hook_path.rename(backup_path)

        hook_path.write_text(_hook_script(hook_name, block_on, action), encoding="utf-8")
        hook_path.chmod(hook_path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        installed.append(hook_path)

    return installed


def status_report(cwd: Path | None = None) -> dict[str, Any]:
    policy_exists = policy_path().exists()
    policy = load_policy() if policy_exists else default_policy()
    current_repo = current_repo_root(cwd)
    template_configured = _git_output(["config", "--global", "--get", "init.templateDir"], cwd=cwd, check=False)
    resolved_git = shutil.which("git")

    local_hooks = {
        hook_name: _hook_status(local_hooks_dir(current_repo) / hook_name) if current_repo else "not-in-repo"
        for hook_name in HOOK_FILENAMES
    }
    template_hooks = {
        hook_name: _hook_status(git_template_hooks_dir() / hook_name)
        for hook_name in HOOK_FILENAMES
    }
    mcp_clients = mcp_client_status()

    return {
        "install_dir": str(nulvec_home()),
        "installed": policy_exists,
        "policy_file": str(policy_path()),
        "policy_exists": policy_exists,
        "log_file": str(log_path()),
        "current_repo": str(current_repo) if current_repo else None,
        "git": {
            "shim_path": str(git_shim_path()),
            "shim_exists": git_shim_path().exists(),
            "shell_rc": str(shell_rc_path()),
            "shell_rc_managed": _shell_rc_has_path_block(),
            "resolved_git": resolved_git,
            "shim_active": resolved_git == str(git_shim_path()) if resolved_git else False,
            "real_binary": policy["integrations"]["git"].get("real_binary"),
            "template_dir_expected": str(git_template_dir()),
            "template_dir_configured": template_configured or None,
            "template_hooks": template_hooks,
            "local_hooks": local_hooks,
            "block_on": policy["integrations"]["git"]["block_on"],
            "action": policy["integrations"]["git"]["action"],
        },
        "clawhub": {
            "install_root": str(skill_install_root()),
            "install_root_exists": skill_install_root().exists(),
            "approved_hashes_file": str(approved_hashes_path()),
            "approved_hash_count": len(load_approved_hashes()),
            "shim_path": str(clawhub_shim_path()),
            "shim_exists": clawhub_shim_path().exists(),
            "block_on": policy["integrations"]["clawhub"]["block_on"],
            "action": policy["integrations"]["clawhub"]["action"],
        },
        "mcp": {
            "mode": policy["integrations"]["mcp"]["mode"],
            "block_on": policy["integrations"]["mcp"]["block_on"],
            "action": policy["integrations"]["mcp"]["action"],
            "clients": mcp_clients,
        },
        "integrations": {
            name: {
                **SUPPORTED_INTEGRATIONS[name],
                **policy["integrations"].get(name, {}),
            }
            for name in SUPPORTED_INTEGRATIONS
        },
    }


def doctor_report(cwd: Path | None = None) -> dict[str, Any]:
    status = status_report(cwd)
    checks: list[dict[str, str]] = []

    checks.append(_check(
        "python_binary",
        Path(sys.executable).exists(),
        f"Python runtime found at {sys.executable}",
        "Python runtime for the shim is missing",
    ))
    checks.append(_check(
        "git_binary",
        shutil.which("git") is not None,
        "git is on PATH",
        "git is not on PATH; install git to enable clone and pull protection",
    ))
    checks.append(_check(
        "install_dir",
        Path(status["install_dir"]).exists(),
        f"Install directory exists at {status['install_dir']}",
        f"Install directory missing at {status['install_dir']}; run `nulvec install`",
    ))
    checks.append(_check(
        "policy_file",
        status["policy_exists"],
        f"Policy file found at {status['policy_file']}",
        "Policy file is missing; run `nulvec install`.",
    ))
    checks.append(_check(
        "git_shim",
        status["git"]["shim_exists"],
        f"Git shim exists at {status['git']['shim_path']}",
        "Git shim file is missing; run `nulvec install` again.",
    ))
    checks.append(_check(
        "clawhub_shim",
        status["clawhub"]["shim_exists"],
        f"Clawhub shim exists at {status['clawhub']['shim_path']}",
        "Clawhub shim is missing; run `nulvec install` again.",
    ))
    checks.append(_check(
        "shell_rc",
        status["git"]["shell_rc_managed"],
        f"Shell profile includes Nulvec PATH activation in {status['git']['shell_rc']}",
        f"Shell profile is missing the Nulvec PATH activation block; run `nulvec install` or manually add {shim_bin_dir()} to PATH in {status['git']['shell_rc']}",
    ))
    checks.append({
        "name": "git_shim_active",
        "status": "pass" if status["git"]["shim_active"] else "warn",
        "detail": (
            f"`git` currently resolves to the Nulvec shim at {status['git']['shim_path']}"
            if status["git"]["shim_active"]
            else "Current shell has not picked up the Nulvec git shim yet; open a new shell or run: source "
            + status["git"]["shell_rc"]
        ),
    })
    checks.append(_check(
        "skill_install_root",
        status["clawhub"]["install_root_exists"],
        f"Skill install root exists at {status['clawhub']['install_root']}",
        "Skill install root is missing; run `nulvec install` again.",
    ))
    checks.append(_check(
        "approved_hashes_file",
        Path(status["clawhub"]["approved_hashes_file"]).exists(),
        f"Approved hash cache exists at {status['clawhub']['approved_hashes_file']}",
        "Approved hash cache is missing; run `nulvec install` again.",
    ))
    checks.append(_check(
        "git_template_dir",
        status["git"]["template_dir_configured"] == status["git"]["template_dir_expected"],
        f"git init.templateDir points to {status['git']['template_dir_expected']}",
        "git init.templateDir is not configured for Nulvec; run `nulvec install` again.",
    ))

    mcp_clients = status["mcp"].get("clients", {})
    any_patched = any(c.get("status") in {"patched", "partial"} for c in mcp_clients.values())
    checks.append({
        "name": "mcp_proxy",
        "status": "pass" if any_patched else "warn",
        "detail": (
            "At least one MCP client config is patched to route traffic through nulvec mcp-proxy."
            if any_patched
            else (
                "No MCP client configs were found or patched. "
                "If you use Claude Desktop or Cursor, ensure they are installed and run `nulvec install` again."
            )
        ),
    })

    current_repo = status["current_repo"]
    if current_repo:
        protected = all(value == "managed" for value in status["git"]["local_hooks"].values())
        checks.append(_check(
            "current_repo_hooks",
            protected,
            f"Current repository {current_repo} has Nulvec hooks installed.",
            f"Current repository {current_repo} is not fully protected; run `nulvec install-hook --scope local`.",
        ))
    else:
        checks.append({
            "name": "current_repo_hooks",
            "status": "warn",
            "detail": "Not running inside a git repository; local hook status skipped.",
        })

    failed = any(item["status"] == "fail" for item in checks)
    warned = any(item["status"] == "warn" for item in checks)
    return {
        "checks": checks,
        "summary": {
            "failed": failed,
            "warned": warned,
            "passed": not failed,
        },
    }


def append_event(event: dict[str, Any]) -> None:
    path = log_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    record = dict(event)
    record.setdefault("recorded_at", int(time.time()))
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record) + "\n")


def current_repo_root(cwd: Path | None = None) -> Path | None:
    root = _git_output(["rev-parse", "--show-toplevel"], cwd=cwd, check=False)
    return Path(root) if root else None


def local_hooks_dir(cwd: Path | None = None) -> Path:
    path = _git_output(["rev-parse", "--git-path", "hooks"], cwd=cwd)
    return Path(path)


def global_hooks_dir(cwd: Path | None = None) -> Path:
    existing = _git_output(["config", "--global", "--get", "core.hooksPath"], cwd=cwd, check=False)
    if existing:
        return Path(existing).expanduser()

    hooks_dir = nulvec_home() / "git-hooks"
    _git_output(["config", "--global", "core.hooksPath", str(hooks_dir)], cwd=cwd)
    return hooks_dir


def _git_output(args: list[str], cwd: Path | None = None, check: bool = True) -> str:
    try:
        git_binary = discover_real_git_binary(load_policy() if policy_path().exists() else None)
    except RuntimeError:
        git_binary = "git"

    completed = subprocess.run(
        [git_binary, *args],
        cwd=cwd,
        check=False,
        capture_output=True,
        text=True,
    )
    if completed.returncode != 0:
        if check:
            stderr = completed.stderr.strip() or completed.stdout.strip() or "git command failed"
            raise RuntimeError(stderr)
        return ""
    return completed.stdout.strip()


def _hook_script(hook_name: str, block_on: str, action: str) -> str:
    return f"""#!/bin/sh
# Installed by nulvec

HOOK_NAME="{hook_name}"
BLOCK_ON="{block_on}"
ACTION="{action}"
ORIG_HOOK="$0.nulvec-orig"
PYTHON_BIN="{sys.executable}"

if [ -n "$NULVEC_HOOK_ACTIVE" ]; then
  if [ -x "$ORIG_HOOK" ]; then
    exec "$ORIG_HOOK" "$@"
  fi
  exit 0
fi

if [ ! -x "$PYTHON_BIN" ]; then
  if [ -x "$ORIG_HOOK" ]; then
    exec "$ORIG_HOOK" "$@"
  fi
  exit 0
fi

export NULVEC_HOOK_ACTIVE=1
REPO_ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"

"$PYTHON_BIN" -m nulvec.cli _git-hook-run "$HOOK_NAME" "$REPO_ROOT" "$BLOCK_ON" "$ACTION"
hook_status=$?

if [ -x "$ORIG_HOOK" ]; then
  "$ORIG_HOOK" "$@"
  orig_status=$?
else
  orig_status=0
fi

if [ "$hook_status" -ne 0 ]; then
  exit "$hook_status"
fi

exit "$orig_status"
"""


def _is_managed_hook(path: Path) -> bool:
    if not path.exists():
        return False
    try:
        return "Installed by nulvec" in path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return False


def _hook_status(path: Path) -> str:
    if not path.exists():
        return "missing"
    if _is_managed_hook(path):
        return "managed"
    return "custom"


def _check(name: str, ok: bool, success_detail: str, failure_detail: str) -> dict[str, str]:
    return {
        "name": name,
        "status": "pass" if ok else "fail",
        "detail": success_detail if ok else failure_detail,
    }


def _env_path(name: str) -> Path | None:
    raw = os.getenv(name)
    if not raw:
        return None
    return Path(raw).expanduser()


def load_approved_hashes() -> dict[str, Any]:
    path = approved_hashes_path()
    if not path.exists():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def write_approved_hashes(hashes: dict[str, Any]) -> Path:
    path = approved_hashes_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(hashes, indent=2) + "\n", encoding="utf-8")
    return path


def discover_real_git_binary(policy: dict[str, Any] | None = None) -> str:
    configured = None
    if policy:
        configured = policy.get("integrations", {}).get("git", {}).get("real_binary")
        if configured and Path(configured).exists():
            return configured

    current = shutil.which("git")
    shim = git_shim_path()
    if current and Path(current).resolve() != shim.resolve():
        return current

    path_entries = [
        entry for entry in os.getenv("PATH", "").split(os.pathsep)
        if entry and Path(entry).resolve() != shim_bin_dir().resolve()
    ]
    path_override = os.pathsep.join(path_entries)
    completed = subprocess.run(
        ["which", "git"],
        check=False,
        capture_output=True,
        text=True,
        env={**os.environ, "PATH": path_override},
    )
    resolved = completed.stdout.strip()
    if resolved:
        return resolved
    raise RuntimeError("Unable to locate the real git binary.")


def discover_real_clawhub_binary() -> str | None:
    """Return the path to the real clawhub binary, bypassing the nulvec shim."""
    shim = clawhub_shim_path()
    current = shutil.which("clawhub")
    if current and Path(current).resolve() != shim.resolve():
        return current

    path_entries = [
        entry for entry in os.getenv("PATH", "").split(os.pathsep)
        if entry and Path(entry).resolve() != shim_bin_dir().resolve()
    ]
    path_override = os.pathsep.join(path_entries)
    completed = subprocess.run(
        ["which", "clawhub"],
        check=False,
        capture_output=True,
        text=True,
        env={**os.environ, "PATH": path_override},
    )
    resolved = completed.stdout.strip()
    return resolved if resolved else None


def write_git_shim() -> Path:
    path = git_shim_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        f"""#!/bin/sh
# Installed by nulvec
PYTHON_BIN="{sys.executable}"

if [ -x "$PYTHON_BIN" ]; then
  exec "$PYTHON_BIN" -m nulvec.cli _git-shim "$@"
fi

if command -v nulvec >/dev/null 2>&1; then
  exec nulvec _git-shim "$@"
fi

echo "Error: nulvec runtime is unavailable. Rerun `nulvec install`." >&2
exit 1
""",
        encoding="utf-8",
    )
    path.chmod(path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return path


def write_clawhub_shim() -> Path:
    """Write a clawhub shim that intercepts 'clawhub install' and routes it through nulvec scanning."""
    path = clawhub_shim_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        f"""#!/bin/sh
# Installed by nulvec
PYTHON_BIN="{sys.executable}"

if [ -x "$PYTHON_BIN" ]; then
  exec "$PYTHON_BIN" -m nulvec.cli _clawhub-shim "$@"
fi

if command -v nulvec >/dev/null 2>&1; then
  exec nulvec _clawhub-shim "$@"
fi

echo "Error: nulvec runtime is unavailable. Rerun `nulvec install`." >&2
exit 1
""",
        encoding="utf-8",
    )
    path.chmod(path.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
    return path


def _mcp_client_config_path(client_id: str) -> Path | None:
    if client_id == "claude_desktop":
        return claude_desktop_config_path()
    if client_id == "cursor":
        return cursor_mcp_config_path()
    return None


def _is_nulvec_proxied_entry(entry: dict[str, Any]) -> bool:
    """Return True if an MCP server entry is already proxied through nulvec mcp-proxy."""
    args = list(entry.get("args", []))
    # python -m nulvec.cli mcp-proxy -- ...
    if len(args) >= 3 and args[0] == "-m" and args[1] == "nulvec.cli" and args[2] == "mcp-proxy":
        return True
    # nulvec mcp-proxy -- ...
    if len(args) >= 1 and args[0] == "mcp-proxy":
        return True
    return False


def _proxy_mcp_server_entry(entry: dict[str, Any]) -> dict[str, Any]:
    """Wrap an MCP server entry to route through nulvec mcp-proxy."""
    if _is_nulvec_proxied_entry(entry):
        return entry
    original_cmd = entry.get("command", "")
    original_args = list(entry.get("args", []))
    return {
        **entry,
        "command": sys.executable,
        "args": ["-m", "nulvec.cli", "mcp-proxy", "--", original_cmd, *original_args],
    }


def patch_mcp_client_config(config_path: Path) -> dict[str, Any]:
    """Patch an MCP client config file to route all servers through nulvec mcp-proxy."""
    if not config_path.exists():
        return {"patched": False, "servers_patched": 0, "error": "config not found"}

    try:
        config = json.loads(config_path.read_text(encoding="utf-8"))
    except Exception as exc:
        return {"patched": False, "servers_patched": 0, "error": str(exc)}

    servers = config.get("mcpServers", {})
    if not servers:
        return {"patched": True, "servers_patched": 0, "error": None}

    patched_count = 0
    new_servers = {}
    for name, entry in servers.items():
        if _is_nulvec_proxied_entry(entry):
            new_servers[name] = entry
        else:
            new_servers[name] = _proxy_mcp_server_entry(entry)
            patched_count += 1

    if patched_count > 0:
        new_config = {**config, "mcpServers": new_servers}
        config_path.write_text(json.dumps(new_config, indent=2) + "\n", encoding="utf-8")

    return {"patched": True, "servers_patched": patched_count, "error": None}


def install_mcp_client_configs() -> dict[str, Any]:
    """Patch all known MCP client configs. Returns per-client results."""
    results: dict[str, Any] = {}
    for client_id, client_info in MCP_CLIENT_CONFIGS.items():
        config_path = _mcp_client_config_path(client_id)
        if config_path is None:
            results[client_id] = {"name": client_info["name"], "status": "unsupported", "error": None}
            continue
        result = patch_mcp_client_config(config_path)
        results[client_id] = {
            "name": client_info["name"],
            "config_path": str(config_path),
            "status": "patched" if result["patched"] else "not_found",
            **result,
        }
    return results


def mcp_client_status() -> dict[str, Any]:
    """Return current status of each supported MCP client config."""
    clients: dict[str, Any] = {}
    for client_id, client_info in MCP_CLIENT_CONFIGS.items():
        config_path = _mcp_client_config_path(client_id)
        if config_path is None:
            clients[client_id] = {"name": client_info["name"], "status": "unsupported"}
            continue
        if not config_path.exists():
            clients[client_id] = {
                "name": client_info["name"],
                "status": "not_found",
                "config_path": str(config_path),
            }
            continue
        try:
            config = json.loads(config_path.read_text(encoding="utf-8"))
            servers = config.get("mcpServers", {})
            proxied = sum(1 for e in servers.values() if _is_nulvec_proxied_entry(e))
            total = len(servers)
            if total == 0 or proxied == total:
                client_status = "patched"
            elif proxied > 0:
                client_status = "partial"
            else:
                client_status = "unpatched"
            clients[client_id] = {
                "name": client_info["name"],
                "status": client_status,
                "config_path": str(config_path),
                "servers_total": total,
                "servers_proxied": proxied,
            }
        except Exception as exc:
            clients[client_id] = {
                "name": client_info["name"],
                "status": "error",
                "config_path": str(config_path),
                "error": str(exc),
            }
    return clients


def ensure_shell_path_activation() -> Path:
    rc_path = shell_rc_path()
    rc_path.parent.mkdir(parents=True, exist_ok=True)
    existing = rc_path.read_text(encoding="utf-8") if rc_path.exists() else ""
    block = (
        f"{PATH_BLOCK_START}\n"
        f'export PATH="{shim_bin_dir()}:$PATH"\n'
        f"{PATH_BLOCK_END}\n"
    )

    if PATH_BLOCK_START in existing and PATH_BLOCK_END in existing:
        updated = _replace_path_block(existing, block)
    else:
        prefix = "" if not existing or existing.endswith("\n") else "\n"
        updated = existing + prefix + block

    rc_path.write_text(updated, encoding="utf-8")
    return rc_path


def _shell_rc_has_path_block() -> bool:
    path = shell_rc_path()
    if not path.exists():
        return False
    content = path.read_text(encoding="utf-8")
    return PATH_BLOCK_START in content and PATH_BLOCK_END in content


def _replace_path_block(existing: str, block: str) -> str:
    start = existing.index(PATH_BLOCK_START)
    end = existing.index(PATH_BLOCK_END) + len(PATH_BLOCK_END)
    suffix = existing[end:]
    if suffix.startswith("\n"):
        suffix = suffix[1:]
    prefix = existing[:start].rstrip("\n")
    if prefix:
        prefix += "\n"
    return prefix + block + (suffix if not suffix else "\n" + suffix.lstrip("\n"))
