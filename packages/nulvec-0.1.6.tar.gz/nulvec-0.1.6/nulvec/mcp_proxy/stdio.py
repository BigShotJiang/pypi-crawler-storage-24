from __future__ import annotations

import json
import subprocess
import sys
import threading
from typing import Any, BinaryIO

from nulvec.machine import append_event, load_policy
from nulvec.models import ScanResult, Severity
from nulvec.scanner import scan_content


SEVERITY_ORDER = {
    Severity.LOW.value: 0,
    Severity.MEDIUM.value: 1,
    Severity.HIGH.value: 2,
    Severity.CRITICAL.value: 3,
}


def run_stdio_proxy(server_command: list[str]) -> int:
    if server_command and server_command[0] == "--":
        server_command = server_command[1:]
    if not server_command:
        print("Error: mcp-proxy requires a real server command after `--`.", file=sys.stderr)
        return 1

    process = subprocess.Popen(
        server_command,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )

    assert process.stdin is not None
    assert process.stdout is not None
    assert process.stderr is not None

    stdin_thread = threading.Thread(
        target=_copy_raw_stream,
        args=(sys.stdin.buffer, process.stdin),
        daemon=True,
    )
    stderr_thread = threading.Thread(
        target=_copy_raw_stream,
        args=(process.stderr, sys.stderr.buffer),
        daemon=True,
    )
    stdin_thread.start()
    stderr_thread.start()

    try:
        for framing, payload in _iter_messages(process.stdout):
            forwarded = _handle_server_message(payload, framing, sys.stdout.buffer)
            if not forwarded and process.poll() is not None:
                break
    finally:
        if process.stdout:
            process.stdout.close()

    stdin_thread.join(timeout=0.2)
    stderr_thread.join(timeout=0.2)
    return process.wait()


def _copy_raw_stream(source: BinaryIO, destination: BinaryIO) -> None:
    try:
        while True:
            reader = getattr(source, "read1", source.read)
            chunk = reader(4096)
            if not chunk:
                break
            destination.write(chunk)
            destination.flush()
    finally:
        try:
            destination.close()
        except Exception:
            pass


def _iter_messages(stream: BinaryIO):
    while True:
        first_line = stream.readline()
        if not first_line:
            break

        if first_line.lower().startswith(b"content-length:"):
            length = int(first_line.split(b":", 1)[1].strip())
            while True:
                header_line = stream.readline()
                if not header_line or header_line in {b"\r\n", b"\n"}:
                    break
            payload = stream.read(length)
            if not payload:
                break
            yield "framed", payload
            continue

        yield "line", first_line.rstrip(b"\r\n")


def _handle_server_message(payload: bytes, framing: str, output: BinaryIO) -> bool:
    result = scan_content(payload, filename="payload.json", modality_hint="mcp")
    policy = load_policy().get("integrations", {}).get("mcp", {})
    action = policy.get("action", "block")
    block_on = policy.get("block_on", Severity.HIGH.value)
    blocked = _is_blocked(result, block_on) and action == "block"

    if result.threats:
        append_event(
            {
                "event": "mcp_proxy_scan",
                "action": action,
                "block_on": block_on,
                "summary": _scan_summary(result),
            }
        )

    if blocked:
        replacement = _blocked_response(payload, result)
        if replacement is None:
            print("[nulvec] blocked MCP payload with no request id to respond to.", file=sys.stderr)
            return True
        _emit_message(output, replacement, framing)
        return True

    if result.threats and action == "warn":
        print(
            f"[nulvec] warning: MCP payload matched {len(result.threats)} threat(s) but policy action is WARN.",
            file=sys.stderr,
        )

    _emit_message(output, payload, framing)
    return True


def _emit_message(output: BinaryIO, payload: bytes, framing: str) -> None:
    if framing == "framed":
        header = f"Content-Length: {len(payload)}\r\n\r\n".encode("utf-8")
        output.write(header)
        output.write(payload)
    else:
        output.write(payload + b"\n")
    output.flush()


def _blocked_response(original_payload: bytes, result: ScanResult) -> bytes | None:
    try:
        original = json.loads(original_payload.decode("utf-8", errors="replace"))
    except json.JSONDecodeError:
        return None

    response: dict[str, Any] = {
        "jsonrpc": "2.0",
        "error": {
            "code": -32098,
            "message": "Blocked by Nulvec",
            "data": {
                "threats": [threat.type.value for threat in result.threats],
                "evidence": [threat.extracted_content[:160] for threat in result.threats[:3]],
            },
        },
    }
    if isinstance(original, dict) and "id" in original:
        response["id"] = original["id"]
    return json.dumps(response).encode("utf-8")


def _scan_summary(result: ScanResult) -> dict[str, Any]:
    return {
        "scanned_files": 1,
        "blocked": 1 if result.blocked else 0,
        "suspicious": 1 if result.decision == "suspicious" else 0,
        "clean": 1 if result.clean else 0,
    }


def _is_blocked(result: ScanResult, block_on: str) -> bool:
    threshold = SEVERITY_ORDER[block_on]
    for threat in result.threats:
        if SEVERITY_ORDER[threat.severity.value] >= threshold:
            return True
    return False
