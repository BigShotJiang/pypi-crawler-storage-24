"""MCP proxy helpers for Nulvec."""
