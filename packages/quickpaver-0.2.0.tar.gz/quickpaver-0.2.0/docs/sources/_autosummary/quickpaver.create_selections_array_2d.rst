﻿..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

quickpaver.create\_selections\_array\_2d
========================================

.. currentmodule:: quickpaver

.. autofunction:: create_selections_array_2d