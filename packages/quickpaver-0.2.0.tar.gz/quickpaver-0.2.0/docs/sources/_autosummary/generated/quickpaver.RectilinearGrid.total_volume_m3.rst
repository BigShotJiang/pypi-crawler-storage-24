..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

quickpaver.RectilinearGrid.total\_volume\_m3
============================================

.. currentmodule:: quickpaver

.. autoproperty:: RectilinearGrid.total_volume_m3