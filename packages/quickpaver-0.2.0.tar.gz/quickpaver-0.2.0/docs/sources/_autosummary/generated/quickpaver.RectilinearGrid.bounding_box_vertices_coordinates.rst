..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

quickpaver.RectilinearGrid.bounding\_box\_vertices\_coordinates
===============================================================

.. currentmodule:: quickpaver

.. autoproperty:: RectilinearGrid.bounding_box_vertices_coordinates