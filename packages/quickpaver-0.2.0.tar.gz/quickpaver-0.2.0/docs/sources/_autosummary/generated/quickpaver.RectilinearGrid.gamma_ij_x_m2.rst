..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

quickpaver.RectilinearGrid.gamma\_ij\_x\_m2
===========================================

.. currentmodule:: quickpaver

.. autoproperty:: RectilinearGrid.gamma_ij_x_m2