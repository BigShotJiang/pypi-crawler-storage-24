..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

quickpaver.RectilinearGrid.make\_spatial\_permutation\_matrices
===============================================================

.. currentmodule:: quickpaver

.. automethod:: RectilinearGrid.make_spatial_permutation_matrices