..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

quickpaver.RectilinearGrid.non\_rot\_center\_coords
===================================================

.. currentmodule:: quickpaver

.. autoproperty:: RectilinearGrid.non_rot_center_coords