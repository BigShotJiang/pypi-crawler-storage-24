..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

quickpaver.RectilinearGrid.n\_grid\_cells
=========================================

.. currentmodule:: quickpaver

.. autoproperty:: RectilinearGrid.n_grid_cells