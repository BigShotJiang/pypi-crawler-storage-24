﻿..
   Template for the html class rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/class.rst

quickpaver.RectilinearGrid
==========================

.. currentmodule:: quickpaver

.. autoclass:: RectilinearGrid

   
   .. automethod:: __init__
   

   
   .. rubric:: Properties

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~RectilinearGrid.bounding_box_vertices_coordinates
      
      ~RectilinearGrid.bounds
      
      ~RectilinearGrid.center_coords
      
      ~RectilinearGrid.center_coords_2d
      
      ~RectilinearGrid.dims
      
      ~RectilinearGrid.gamma_ij_x_m2
      
      ~RectilinearGrid.gamma_ij_y_m2
      
      ~RectilinearGrid.gamma_ij_z_m2
      
      ~RectilinearGrid.grid_cell_volume_m3
      
      ~RectilinearGrid.indices
      
      ~RectilinearGrid.n_grid_cells
      
      ~RectilinearGrid.non_rot_center_coords
      
      ~RectilinearGrid.non_rot_center_coords_2d
      
      ~RectilinearGrid.origin
      
      ~RectilinearGrid.origin_coords
      
      ~RectilinearGrid.shape
      
      ~RectilinearGrid.total_volume_m3
      
      ~RectilinearGrid.x_extent
      
      ~RectilinearGrid.x_indices
      
      ~RectilinearGrid.xmax
      
      ~RectilinearGrid.xmin
      
      ~RectilinearGrid.y_extent
      
      ~RectilinearGrid.y_indices
      
      ~RectilinearGrid.ymax
      
      ~RectilinearGrid.ymin
      
      ~RectilinearGrid.z_extent
      
      ~RectilinearGrid.z_indices
      
      ~RectilinearGrid.zmax
      
      ~RectilinearGrid.zmin
      
   

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~RectilinearGrid.make_spatial_gradient_matrices
      
      ~RectilinearGrid.make_spatial_permutation_matrices
      
   

   