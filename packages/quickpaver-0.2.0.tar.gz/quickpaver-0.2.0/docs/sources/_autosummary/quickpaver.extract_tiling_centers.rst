﻿..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

quickpaver.extract\_tiling\_centers
===================================

.. currentmodule:: quickpaver

.. autofunction:: extract_tiling_centers