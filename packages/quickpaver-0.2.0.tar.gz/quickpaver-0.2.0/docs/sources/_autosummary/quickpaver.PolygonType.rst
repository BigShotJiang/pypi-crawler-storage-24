﻿..
   Template for the html class rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/class.rst

quickpaver.PolygonType
======================

.. currentmodule:: quickpaver

.. autoclass:: PolygonType

   
   .. automethod:: __init__
   

   
   .. rubric:: Properties

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~PolygonType.TRIANGLE
      
      ~PolygonType.RECTANGLE
      
      ~PolygonType.HEXAGON
      
   

   
   .. rubric:: Methods

   .. autosummary::
      :nosignatures:
      :toctree: generated

      
      ~PolygonType.to_list
      
      ~PolygonType.encode
      
      ~PolygonType.replace
      
      ~PolygonType.split
      
      ~PolygonType.rsplit
      
      ~PolygonType.join
      
      ~PolygonType.capitalize
      
      ~PolygonType.casefold
      
      ~PolygonType.title
      
      ~PolygonType.center
      
      ~PolygonType.count
      
      ~PolygonType.expandtabs
      
      ~PolygonType.find
      
      ~PolygonType.partition
      
      ~PolygonType.index
      
      ~PolygonType.ljust
      
      ~PolygonType.lower
      
      ~PolygonType.lstrip
      
      ~PolygonType.rfind
      
      ~PolygonType.rindex
      
      ~PolygonType.rjust
      
      ~PolygonType.rstrip
      
      ~PolygonType.rpartition
      
      ~PolygonType.splitlines
      
      ~PolygonType.strip
      
      ~PolygonType.swapcase
      
      ~PolygonType.translate
      
      ~PolygonType.upper
      
      ~PolygonType.startswith
      
      ~PolygonType.endswith
      
      ~PolygonType.removeprefix
      
      ~PolygonType.removesuffix
      
      ~PolygonType.isascii
      
      ~PolygonType.islower
      
      ~PolygonType.isupper
      
      ~PolygonType.istitle
      
      ~PolygonType.isspace
      
      ~PolygonType.isdecimal
      
      ~PolygonType.isdigit
      
      ~PolygonType.isnumeric
      
      ~PolygonType.isalpha
      
      ~PolygonType.isalnum
      
      ~PolygonType.isidentifier
      
      ~PolygonType.isprintable
      
      ~PolygonType.zfill
      
      ~PolygonType.format
      
      ~PolygonType.format_map
      
      ~PolygonType.maketrans
      
   

   