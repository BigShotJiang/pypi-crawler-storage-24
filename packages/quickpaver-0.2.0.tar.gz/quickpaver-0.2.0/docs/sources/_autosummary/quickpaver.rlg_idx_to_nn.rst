﻿..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

quickpaver.rlg\_idx\_to\_nn
===========================

.. currentmodule:: quickpaver

.. autofunction:: rlg_idx_to_nn