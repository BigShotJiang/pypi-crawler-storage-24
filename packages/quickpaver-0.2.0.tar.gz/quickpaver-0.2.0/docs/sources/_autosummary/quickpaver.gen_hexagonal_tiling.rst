﻿..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

quickpaver.gen\_hexagonal\_tiling
=================================

.. currentmodule:: quickpaver

.. autofunction:: gen_hexagonal_tiling