﻿..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

quickpaver.rlg\_nn\_to\_idx
===========================

.. currentmodule:: quickpaver

.. autofunction:: rlg_nn_to_idx