﻿..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

quickpaver.load\_france\_and\_corsica\_contour
==============================================

.. currentmodule:: quickpaver

.. autofunction:: load_france_and_corsica_contour