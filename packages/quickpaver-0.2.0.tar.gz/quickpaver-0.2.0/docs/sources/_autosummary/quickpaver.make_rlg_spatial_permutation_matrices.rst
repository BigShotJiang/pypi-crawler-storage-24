﻿..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

quickpaver.make\_rlg\_spatial\_permutation\_matrices
====================================================

.. currentmodule:: quickpaver

.. autofunction:: make_rlg_spatial_permutation_matrices