﻿..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

quickpaver.get\_polygon\_selection\_with\_dilation\_2d
======================================================

.. currentmodule:: quickpaver

.. autofunction:: get_polygon_selection_with_dilation_2d