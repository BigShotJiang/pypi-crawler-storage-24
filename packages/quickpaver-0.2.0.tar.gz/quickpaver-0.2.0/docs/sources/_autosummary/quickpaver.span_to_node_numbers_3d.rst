﻿..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

quickpaver.span\_to\_node\_numbers\_3d
======================================

.. currentmodule:: quickpaver

.. autofunction:: span_to_node_numbers_3d