﻿..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

quickpaver.get\_rlg\_perm\_mat
==============================

.. currentmodule:: quickpaver

.. autofunction:: get_rlg_perm_mat