﻿..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

quickpaver.gen\_rectangular\_tiling
===================================

.. currentmodule:: quickpaver

.. autofunction:: gen_rectangular_tiling