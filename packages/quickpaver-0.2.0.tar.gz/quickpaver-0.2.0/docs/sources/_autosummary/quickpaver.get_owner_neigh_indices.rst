﻿..
   Template for the html base rendering

   Modified from
   https://github.com/sphinx-doc/sphinx/tree/master/sphinx/ext/autosummary/templates/autosummary/base.rst

quickpaver.get\_owner\_neigh\_indices
=====================================

.. currentmodule:: quickpaver

.. autofunction:: get_owner_neigh_indices