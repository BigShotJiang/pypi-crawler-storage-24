# idlemaxx

Awesome package

## Contributing

**Prerequisites:** install [`just`](https://github.com/casey/just) (`brew install just`), then clone the repo.

```sh
just setup   # installs uv, gh, syncs Python env, installs pre-commit hooks
just test    # run the test suite
```

Open a PR; CI automatically runs `pre-commit`, `pytest`, and a package `build` check. All checks must pass before merge.

## Releasing

Versioning is automatic via git tags — there is no version file to update manually.

From a clean `main` branch:

```sh
just release v0.1.0
```

The script validates that you're on `main` with a clean working tree and that the latest CI run succeeded, then tags and pushes. The publish workflow runs sequentially:

```
build → TestPyPI → PyPI
```

If any step fails the workflow stops before publishing to PyPI.

## Goals

IdleMaxx is an OSRS-inspired idle/incremental game built in Python. It started as an exploration of data modeling for a game — a concrete, interesting domain to experiment with software design. It's not a clone of OSRS: it takes inspiration from the skill-based progression and idle mechanics, but diverges intentionally. Combat is idle — you equip gear, enter a combat area, and the simulation runs without real-time input. There is no PvP.

Primarily a personal project and a game to play with friends. Long-term, the goal is for it to be publicly installable by anyone via PyPI and playable locally out of the box, with multiplayer via Discord as a first-class feature.

- **Learn by building** — The project is as much about exploring software design (data modeling, architecture, tooling) as it is about the game itself.
- **Playable with friends** — The Discord bot frontend is a first-class goal, not an afterthought.
- **Installable and accessible** — Anyone should be able to `pip install idlemaxx` and start playing.
- **Continuously improvable** — The game's scope should grow organically over time, without accumulating technical debt that makes changes painful.

See [ROADMAP.md](ROADMAP.md) for planned features.
