from collections.abc import Sequence
import datetime
from enum import Enum
import random
from dataclasses import dataclass, field
import uuid

from sqlalchemy import create_engine, select, text
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import Session

from idlemaxx.models.combat import (
    ARMOR_STATS,
    FOOD_STATS,
    WEAPON_STATS,
    CombatArea,
    EquipmentSlot,
    Monster,
)
from idlemaxx.models.models import (
    IdlemaxBase,
    Character,
    CharacterActivity,
    CharacterActivityQueue,
    CharacterActivityXpReward,
    CharacterActivityItemReward,
    CharacterActivityMaterialConsumed,
    CharacterCombatSession,
    CharacterCombatSessionKill,
    CharacterCombatSessionKillLoot,
    CharacterEquipment,
    CharacterSkill,
    Skill,
    now_utc,
    Activity,
    ActivityCategory,
    level_from_xp,
    xp_for_level,
    Item,
    CharacterItem,
    Trade,
    TradeOffer,
    TradeOfferItem,
    TradeStatus,
)

QUEUE_LIMIT = 3
AUTO_EAT_THRESHOLD = 0.4
DEATH_RECOVERY_HOURS = 24


@dataclass
class ActivityEstimate:
    possible_actions: int | None  # None = unlimited (no materials constrain it)
    total_items: dict[Item, int] = field(default_factory=dict)
    total_xp: dict[Skill, int] = field(default_factory=dict)


@dataclass
class ActivityReward:
    actions_completed: int
    xp_gained: dict[Skill, int] = field(default_factory=dict)
    items_gained: dict[Item, int] = field(default_factory=dict)
    materials_consumed: dict[Item, int] = field(default_factory=dict)


@dataclass
class KillRecord:
    monster: Monster
    xp_gained: dict[Skill, int] = field(default_factory=dict)
    loot: dict[Item, int] = field(default_factory=dict)


class CombatEventKind(Enum):
    PLAYER_ATTACK = "player_attack"
    MONSTER_ATTACK = "monster_attack"
    PLAYER_EAT = "player_eat"
    MONSTER_KILLED = "monster_killed"
    PLAYER_DIED = "player_died"
    FLED = "fled"


@dataclass
class CombatLogEvent:
    kind: CombatEventKind
    time: float
    monster: Monster
    monster_index: int
    damage: int = 0
    hit: bool = True
    player_hp: int = 0
    player_max_hp: int = 0
    monster_hp: int = 0
    food_item: Item | None = None
    heal_amount: int = 0
    loot: dict[Item, int] = field(default_factory=dict)


@dataclass
class CombatResult:
    kills: list[KillRecord] = field(default_factory=list)
    survived: bool = True
    died_at: datetime.datetime | None = None
    recovery_deadline: datetime.datetime | None = None
    xp_gained: dict[Skill, int] = field(default_factory=dict)
    items_lost: dict[Item, int] = field(default_factory=dict)
    log: list[CombatLogEvent] = field(default_factory=list)


class Game:
    def __init__(self, db_url: str = "sqlite:///idlemaxx.db") -> None:
        engine = create_engine(db_url)
        IdlemaxBase.metadata.create_all(engine)
        with engine.connect() as conn:
            try:
                conn.execute(text("ALTER TABLE characters ADD COLUMN discord_user_id VARCHAR"))
                conn.commit()
            except OperationalError:
                pass
            cols = [row[1] for row in conn.execute(text("PRAGMA table_info(character_activities)"))]
            if "last_rewarded_at" not in cols:
                conn.execute(text("ALTER TABLE character_activities ADD COLUMN last_rewarded_at DATETIME"))
            if "actions_rewarded" not in cols:
                conn.execute(
                    text("ALTER TABLE character_activities ADD COLUMN actions_rewarded INTEGER NOT NULL DEFAULT 0")
                )
            combat_cols = [row[1] for row in conn.execute(text("PRAGMA table_info(character_combat_sessions)"))]
            if "kills_rewarded" not in combat_cols:
                conn.execute(
                    text("ALTER TABLE character_combat_sessions ADD COLUMN kills_rewarded INTEGER NOT NULL DEFAULT 0")
                )
            if "last_rewarded_at" not in combat_cols:
                conn.execute(text("ALTER TABLE character_combat_sessions ADD COLUMN last_rewarded_at DATETIME"))
            conn.commit()
        self._session = Session(engine)

    def _get_character_skill(self, character: Character, skill: Skill) -> CharacterSkill:
        character_skill = self._session.scalars(
            select(CharacterSkill)
            .where(CharacterSkill.character_id == character.id)
            .where(CharacterSkill.skill == skill)
        ).one_or_none()
        if not character_skill:
            character_skill = CharacterSkill(character.id, skill, 0)
            character.skills.append(character_skill)
        return character_skill

    def _get_character_item(self, character: Character, item: Item) -> CharacterItem:
        character_item = self._session.scalars(
            select(CharacterItem).where(CharacterItem.character_id == character.id).where(CharacterItem.item == item)
        ).one_or_none()
        if not character_item:
            character_item = CharacterItem(character.id, item, quantity=0)
            character.items.append(character_item)
        return character_item

    def create_character(self, name: str, discord_user_id: str | None = None) -> Character:
        character = Character(name, discord_user_id=discord_user_id)
        for skill in Skill:
            start_xp = xp_for_level(10) if skill == Skill.HITPOINTS else 0
            character.skills.append(CharacterSkill(character.id, skill, start_xp))
        self._session.add(character)
        self._session.commit()
        return character

    def delete_character(self, character: Character) -> None:
        self._session.delete(character)
        self._session.commit()

    def get_character_by_discord_id(self, discord_user_id: str) -> Character | None:
        character = self._session.scalars(
            select(Character).where(Character.discord_user_id == discord_user_id)
        ).one_or_none()
        if character is not None:
            self._sync(character)
            self._sync_combat(character)
        return character

    def get_character_by_name(self, name: str) -> Character:
        character = self._session.scalars(select(Character).where(Character.name == name)).one()
        self._sync(character)
        self._sync_combat(character)
        return character

    def list_characters(self) -> Sequence[Character]:
        return self._session.scalars(select(Character)).all()

    def activity_categories(self) -> list[ActivityCategory]:
        return list(dict.fromkeys(a.value.category for a in Activity))

    def activities_for_category(self, category: ActivityCategory) -> list[Activity]:
        return [a for a in Activity if a.value.category == category]

    def _material_action_limit(self, character: Character, activity: Activity) -> int | None:
        """Returns the max actions completable from current inventory, or None if the activity has no materials."""
        data = activity.value
        if not data.materials:
            return None
        return min(self._get_character_item(character, mat.item).quantity // mat.quantity for mat in data.materials)

    def estimate_activity(self, character: Character, activity: Activity) -> ActivityEstimate:
        data = activity.value
        possible = self._material_action_limit(character, activity)
        if possible is None:
            return ActivityEstimate(possible_actions=None)
        return ActivityEstimate(
            possible_actions=possible,
            total_items={r.item: r.quantity * possible for r in data.item_rewards},
            total_xp={r.skill: r.xp * possible for r in data.skill_rewards},
        )

    def start_activity(
        self,
        character: Character,
        activity: Activity,
        action_limit: int | None = None,
        _started_at: datetime.datetime | None = None,
    ) -> CharacterActivity:
        existing = self._session.scalars(
            select(CharacterActivity)
            .where(CharacterActivity.character_id == character.id)
            .where(CharacterActivity.ended_at.is_(None))
        ).one_or_none()
        if existing:
            raise Exception(f"{character.name} is already doing {existing.activity.name}")

        for skill_requirement in activity.skill_requirements:
            character_skill = self._get_character_skill(character, skill_requirement.skill)
            character_skill_level = level_from_xp(character_skill.experience)
            if character_skill_level < skill_requirement.required_level:
                raise Exception(
                    f"Requires {skill_requirement.skill.value} level {skill_requirement.required_level}, "
                    f"but you only have {character_skill_level}"
                )

        character_activity = CharacterActivity(character.id, activity, action_limit=action_limit)
        if _started_at is not None:
            character_activity.started_at = _started_at
        self._session.add(character_activity)
        self._session.commit()
        return character_activity

    def get_queue_limit(self, character: Character) -> int:
        return QUEUE_LIMIT

    def get_activity_queue(self, character: Character) -> list[CharacterActivityQueue]:
        return [item for item in character.activity_queue if item.started_at is None]

    def remove_from_queue(self, character: Character, item: CharacterActivityQueue) -> None:
        character.activity_queue.remove(item)
        self._session.commit()

    def _dequeue_next(self, character: Character, started_at: datetime.datetime) -> CharacterActivityQueue | None:
        pending = self.get_activity_queue(character)
        if not pending:
            return None
        item = pending[0]
        item.started_at = started_at
        return item

    def queue_activity(
        self,
        character: Character,
        activity: Activity,
        action_limit: int | None = None,
    ) -> None:
        if character.current_activity is None:
            self.start_activity(character, activity, action_limit=action_limit)
            return
        queue = self.get_activity_queue(character)
        if len(queue) >= self.get_queue_limit(character):
            raise Exception(f"Activity queue is full (limit: {self.get_queue_limit(character)})")
        for skill_requirement in activity.skill_requirements:
            character_skill = self._get_character_skill(character, skill_requirement.skill)
            character_skill_level = level_from_xp(character_skill.experience)
            if character_skill_level < skill_requirement.required_level:
                raise Exception(
                    f"Requires {skill_requirement.skill.value} level {skill_requirement.required_level}, "
                    f"but you only have {character_skill_level}"
                )
        item = CharacterActivityQueue(character.id, activity, action_limit)
        character.activity_queue.append(item)
        self._session.commit()

    def _apply_rewards(
        self,
        character: Character,
        ca: CharacterActivity,
        actions_completed: int,
    ) -> ActivityReward:
        reward = ActivityReward(actions_completed=actions_completed)

        for mat in ca.activity.materials:
            item = self._get_character_item(character, mat.item)
            consumed = actions_completed * mat.quantity
            item.quantity -= consumed
            reward.materials_consumed[mat.item] = consumed
            ca.materials_consumed.append(CharacterActivityMaterialConsumed(ca.id, mat.item, consumed))

        for skill_reward in ca.activity.skill_rewards:
            character_skill = self._get_character_skill(character, skill_reward.skill)
            xp = skill_reward.xp * actions_completed
            character_skill.experience += xp
            reward.xp_gained[skill_reward.skill] = xp
            ca.xp_rewards.append(CharacterActivityXpReward(ca.id, skill_reward.skill, xp))

        for item_reward in ca.activity.item_rewards:
            character_item = self._get_character_item(character, item_reward.item)
            quantity = item_reward.quantity * actions_completed
            character_item.quantity += quantity
            reward.items_gained[item_reward.item] = quantity
            ca.item_rewards.append(CharacterActivityItemReward(ca.id, item_reward.item, quantity))

        return reward

    def _aggregate_activity_reward(self, ca: CharacterActivity) -> ActivityReward:
        """Sum all reward rows written to this activity into one ActivityReward."""
        xp: dict[Skill, int] = {}
        items: dict[Item, int] = {}
        mats: dict[Item, int] = {}
        for row in ca.xp_rewards:
            xp[row.skill] = xp.get(row.skill, 0) + row.xp_gained
        for row in ca.item_rewards:
            items[row.item] = items.get(row.item, 0) + row.quantity
        for row in ca.materials_consumed:
            mats[row.item] = mats.get(row.item, 0) + row.quantity
        return ActivityReward(
            actions_completed=ca.actions_rewarded,
            xp_gained=xp,
            items_gained=items,
            materials_consumed=mats,
        )

    def _sync(self, character: Character) -> list[ActivityReward]:
        """Advance game state: pay out rewards since last sync, advance queue if limit was hit.

        Leaves the final active activity open (ended_at stays None). Only closes an activity
        when chaining to the next queued one. Safe to call with no active activity (returns []).
        """
        ca = self._session.scalars(
            select(CharacterActivity)
            .where(CharacterActivity.character_id == character.id)
            .where(CharacterActivity.ended_at.is_(None))
        ).one_or_none()

        if not ca:
            return []

        current_time = now_utc()
        rewards: list[ActivityReward] = []

        while True:
            segment_start = ca.last_rewarded_at or ca.started_at
            elapsed = (current_time - segment_start).total_seconds()
            time_actions = elapsed / ca.activity.action_time

            mat_limit = self._material_action_limit(character, ca.activity)
            remaining_action_limit = (ca.action_limit - ca.actions_rewarded) if ca.action_limit is not None else None

            candidates: list[float] = [time_actions]
            if mat_limit is not None:
                candidates.append(float(mat_limit))
            if remaining_action_limit is not None:
                candidates.append(float(remaining_action_limit))

            new_actions = int(min(candidates))
            total_actions = ca.actions_rewarded + new_actions
            chain_time = ca.started_at + datetime.timedelta(seconds=total_actions * ca.activity.action_time)

            action_limit_hit = remaining_action_limit is not None and new_actions >= remaining_action_limit
            mat_limit_hit = mat_limit is not None and new_actions >= mat_limit
            limit_was_binding = action_limit_hit or mat_limit_hit

            if new_actions > 0:
                reward = self._apply_rewards(character, ca, new_actions)
                ca.actions_rewarded = total_actions
                rewards.append(reward)

            if limit_was_binding and new_actions > 0 and chain_time < current_time:
                next_item = self._dequeue_next(character, chain_time)
                if next_item is None:
                    # No queue — leave activity open; /end will close it
                    break
                ca.ended_at = chain_time
                new_ca = CharacterActivity(character.id, next_item.activity, action_limit=next_item.action_limit)
                new_ca.started_at = chain_time
                self._session.add(new_ca)
                ca = new_ca
            else:
                if new_actions > 0:
                    # Action-aligned boundary — not wall clock
                    ca.last_rewarded_at = segment_start + datetime.timedelta(
                        seconds=new_actions * ca.activity.action_time
                    )
                break

        self._session.commit()
        return rewards

    def end_activity(self, character: Character) -> list[ActivityReward]:
        original_ca = self._session.scalars(
            select(CharacterActivity)
            .where(CharacterActivity.character_id == character.id)
            .where(CharacterActivity.ended_at.is_(None))
        ).one_or_none()

        if not original_ca:
            return []

        session_start = original_ca.started_at

        # Flush all pending rewards and advance queue through any completed activities
        self._sync(character)

        ca = self._session.scalars(
            select(CharacterActivity)
            .where(CharacterActivity.character_id == character.id)
            .where(CharacterActivity.ended_at.is_(None))
        ).one_or_none()

        if not ca:
            return []

        current_time = now_utc()

        # Apply any final rewards since the last sync checkpoint
        segment_start = ca.last_rewarded_at or ca.started_at
        elapsed = (current_time - segment_start).total_seconds()
        time_actions = elapsed / ca.activity.action_time

        mat_limit = self._material_action_limit(character, ca.activity)
        remaining_action_limit = (ca.action_limit - ca.actions_rewarded) if ca.action_limit is not None else None

        candidates: list[float] = [time_actions]
        if mat_limit is not None:
            candidates.append(float(mat_limit))
        if remaining_action_limit is not None:
            candidates.append(float(remaining_action_limit))

        new_actions = int(min(candidates))
        if new_actions > 0:
            self._apply_rewards(character, ca, new_actions)
            ca.actions_rewarded += new_actions

        ca.ended_at = current_time

        # Start next queued item as active
        pending = self.get_activity_queue(character)
        if pending:
            next_item = pending[0]
            next_item.started_at = current_time
            new_ca = CharacterActivity(character.id, next_item.activity, action_limit=next_item.action_limit)
            new_ca.started_at = current_time
            self._session.add(new_ca)

        self._session.commit()

        # Return aggregated rewards for every activity in this session, oldest-first
        all_cas = self._session.scalars(
            select(CharacterActivity)
            .where(CharacterActivity.character_id == character.id)
            .where(CharacterActivity.started_at >= session_start)
            .where(CharacterActivity.ended_at.is_not(None))
            .order_by(CharacterActivity.started_at)
        ).all()
        return [self._aggregate_activity_reward(a) for a in all_cas]

    # --- Trading ---

    def get_trade(self, trade_id: uuid.UUID) -> Trade | None:
        return self._session.scalars(select(Trade).where(Trade.id == trade_id)).one_or_none()

    def get_current_offer(self, trade: Trade) -> TradeOffer:
        if not trade.offers:
            raise ValueError("Trade has no offers")
        return trade.offers[-1]

    def get_pending_trades(self, character: Character) -> list[Trade]:
        """Trades where it is currently character's turn to respond."""
        return list(
            self._session.scalars(
                select(Trade).where(Trade.status == TradeStatus.PENDING).where(Trade.current_turn_id == character.id)
            ).all()
        )

    def get_outgoing_trades(self, character: Character) -> list[Trade]:
        """Pending trades where character is waiting on the other party."""
        return list(
            self._session.scalars(
                select(Trade)
                .where(Trade.status == TradeStatus.PENDING)
                .where((Trade.initiator_id == character.id) | (Trade.counterparty_id == character.id))
                .where(Trade.current_turn_id != character.id)
            ).all()
        )

    def _validate_offer_items(self, proposer: Character, proposer_items: dict[Item, int]) -> None:
        """Validate quantities > 0 and proposer owns enough of each item they are offering."""
        for item, qty in proposer_items.items():
            if qty <= 0:
                raise ValueError(f"Quantity for {item.value} must be greater than 0")
            owned = self._get_character_item(proposer, item).quantity
            if owned < qty:
                raise ValueError(f"Insufficient {item.value}: offering {qty} but only own {owned}")

    def _validate_item_quantities(self, items: dict[Item, int]) -> None:
        """Validate all quantities > 0 (no ownership check)."""
        for item, qty in items.items():
            if qty <= 0:
                raise ValueError(f"Quantity for {item.value} must be greater than 0")

    def _build_offer(
        self,
        trade: Trade,
        proposed_by: Character,
        initiator_items: dict[Item, int],
        counterparty_items: dict[Item, int],
    ) -> TradeOffer:
        offer = TradeOffer(trade_id=trade.id, proposed_by_id=proposed_by.id)
        for item, qty in initiator_items.items():
            offer.items.append(
                TradeOfferItem(
                    trade_offer_id=offer.id,
                    offered_by_id=trade.initiator_id,
                    item=item,
                    quantity=qty,
                )
            )
        for item, qty in counterparty_items.items():
            offer.items.append(
                TradeOfferItem(
                    trade_offer_id=offer.id,
                    offered_by_id=trade.counterparty_id,
                    item=item,
                    quantity=qty,
                )
            )
        trade.offers.append(offer)
        return offer

    def create_trade(
        self,
        initiator: Character,
        counterparty: Character,
        initiator_items: dict[Item, int],
        counterparty_items: dict[Item, int],
    ) -> Trade:
        if initiator.id == counterparty.id:
            raise ValueError("Cannot trade with yourself")
        if not initiator_items and not counterparty_items:
            raise ValueError("At least one side of the trade must have items")
        self._validate_offer_items(initiator, initiator_items)
        self._validate_item_quantities(counterparty_items)

        trade = Trade(
            initiator_id=initiator.id,
            counterparty_id=counterparty.id,
            current_turn_id=counterparty.id,
        )
        self._session.add(trade)
        self._build_offer(trade, initiator, initiator_items, counterparty_items)
        self._session.commit()
        return trade

    def counter_trade(
        self,
        trade: Trade,
        proposer: Character,
        initiator_items: dict[Item, int],
        counterparty_items: dict[Item, int],
    ) -> TradeOffer:
        if trade.status != TradeStatus.PENDING:
            raise ValueError("Trade is no longer pending")
        if trade.current_turn_id != proposer.id:
            raise ValueError("It is not your turn")
        if not initiator_items and not counterparty_items:
            raise ValueError("At least one side of the trade must have items")

        if proposer.id == trade.initiator_id:
            self._validate_offer_items(proposer, initiator_items)
            self._validate_item_quantities(counterparty_items)
        else:
            self._validate_item_quantities(initiator_items)
            self._validate_offer_items(proposer, counterparty_items)

        trade.current_turn_id = trade.counterparty_id if proposer.id == trade.initiator_id else trade.initiator_id

        offer = self._build_offer(trade, proposer, initiator_items, counterparty_items)
        self._session.commit()
        return offer

    def accept_trade(self, trade: Trade, accepter: Character) -> None:
        if trade.status != TradeStatus.PENDING:
            raise ValueError("Trade is no longer pending")
        if trade.current_turn_id != accepter.id:
            raise ValueError("It is not your turn")

        offer = self.get_current_offer(trade)

        initiator_items: dict[Item, int] = {}
        counterparty_items: dict[Item, int] = {}
        for oi in offer.items:
            if oi.offered_by_id == trade.initiator_id:
                initiator_items[oi.item] = oi.quantity
            else:
                counterparty_items[oi.item] = oi.quantity

        initiator = self._session.get(Character, trade.initiator_id)
        counterparty = self._session.get(Character, trade.counterparty_id)
        assert initiator is not None and counterparty is not None

        errors: list[str] = []
        for item, qty in initiator_items.items():
            owned = self._get_character_item(initiator, item).quantity
            if owned < qty:
                errors.append(f"{initiator.name} lacks {item.value}: needs {qty}, has {owned}")
        for item, qty in counterparty_items.items():
            owned = self._get_character_item(counterparty, item).quantity
            if owned < qty:
                errors.append(f"{counterparty.name} lacks {item.value}: needs {qty}, has {owned}")
        if errors:
            raise ValueError("Trade cannot be completed:\n" + "\n".join(errors))

        for item, qty in initiator_items.items():
            self._get_character_item(initiator, item).quantity -= qty
            self._get_character_item(counterparty, item).quantity += qty
        for item, qty in counterparty_items.items():
            self._get_character_item(counterparty, item).quantity -= qty
            self._get_character_item(initiator, item).quantity += qty

        trade.status = TradeStatus.ACCEPTED
        self._session.commit()

    def reject_trade(self, trade: Trade, rejector: Character) -> None:
        if trade.status != TradeStatus.PENDING:
            raise ValueError("Trade is no longer pending")
        if rejector.id not in (trade.initiator_id, trade.counterparty_id):
            raise ValueError("You are not a party to this trade")
        trade.status = TradeStatus.REJECTED
        self._session.commit()

    # -------------------------------------------------------------------------
    # Equipment
    # -------------------------------------------------------------------------

    def get_equipment(self, character: Character) -> dict[EquipmentSlot, CharacterEquipment]:
        return {eq.slot: eq for eq in character.equipment}

    def equip_item(self, character: Character, item: Item) -> CharacterEquipment:
        """Equip a weapon or armor piece from inventory. Checks level requirements."""
        if item in WEAPON_STATS:
            stats = WEAPON_STATS[item]
            slot = EquipmentSlot.WEAPON
            attack_level = level_from_xp(self._get_character_skill(character, Skill.ATTACK).experience)
            if attack_level < stats.attack_req:
                raise Exception(f"Requires Attack level {stats.attack_req}, but you only have {attack_level}")
        elif item in ARMOR_STATS:
            stats = ARMOR_STATS[item]
            slot = stats.slot
            defense_level = level_from_xp(self._get_character_skill(character, Skill.DEFENSE).experience)
            if defense_level < stats.defense_req:
                raise Exception(f"Requires Defense level {stats.defense_req}, but you only have {defense_level}")
        else:
            raise Exception(f"{item.value} is not a weapon or armor piece")

        inv = self._get_character_item(character, item)
        if inv.quantity < 1:
            raise Exception(f"You don't have a {item.value} in your inventory")

        self.unequip_slot(character, slot)

        inv.quantity -= 1
        eq = CharacterEquipment(character.id, slot, item, quantity=1)
        character.equipment.append(eq)
        self._session.add(eq)
        self._session.commit()
        return eq

    def equip_food(self, character: Character, item: Item, quantity: int) -> CharacterEquipment:
        """Equip food from inventory into the FOOD slot."""
        if item not in FOOD_STATS:
            raise Exception(f"{item.value} is not a food item")
        if quantity < 1:
            raise Exception("Quantity must be at least 1")

        inv = self._get_character_item(character, item)
        if inv.quantity < quantity:
            raise Exception(f"You only have {inv.quantity} {item.value}")

        self.unequip_slot(character, EquipmentSlot.FOOD)

        inv.quantity -= quantity
        eq = CharacterEquipment(character.id, EquipmentSlot.FOOD, item, quantity=quantity)
        character.equipment.append(eq)
        self._session.add(eq)
        self._session.commit()
        return eq

    def unequip_slot(self, character: Character, slot: EquipmentSlot) -> CharacterEquipment | None:
        """Remove item from equipment slot and return it to inventory."""
        equipment = self.get_equipment(character)
        if slot not in equipment:
            return None
        eq = equipment[slot]
        inv = self._get_character_item(character, eq.item)
        inv.quantity += eq.quantity
        character.equipment.remove(eq)
        self._session.delete(eq)
        self._session.commit()
        return eq

    # -------------------------------------------------------------------------
    # Combat lifecycle
    # -------------------------------------------------------------------------

    def get_active_combat(self, character: Character) -> CharacterCombatSession | None:
        return self._session.scalars(
            select(CharacterCombatSession)
            .where(CharacterCombatSession.character_id == character.id)
            .where(CharacterCombatSession.ended_at.is_(None))
        ).one_or_none()

    def enter_combat(self, character: Character, area: CombatArea) -> CharacterCombatSession:
        if self.get_active_combat(character) is not None:
            raise Exception(f"{character.name} is already in combat")
        if character.current_activity is not None:
            raise Exception(f"{character.name} is busy with an activity; end it before entering combat")
        session = CharacterCombatSession(character.id, area)
        character.combat_sessions.append(session)
        self._session.add(session)
        self._session.commit()
        return session

    def _sync_combat(self, character: Character) -> None:
        """Apply combat kills earned since the last sync checkpoint. Handles death automatically."""
        session = self.get_active_combat(character)
        if session is None:
            return

        now = now_utc()
        elapsed = (now - session.started_at).total_seconds()
        result = self._simulate_combat(session, character, elapsed_override=elapsed, write_food=False)

        new_kills = result.kills[session.kills_rewarded :]
        for kill in new_kills:
            kill_record = CharacterCombatSessionKill(
                session.id,
                kill.monster,
                kill.xp_gained.get(Skill.ATTACK, 0),
                kill.xp_gained.get(Skill.STRENGTH, 0),
                kill.xp_gained.get(Skill.HITPOINTS, 0),
            )
            self._session.add(kill_record)
            for item, qty in kill.loot.items():
                inv = self._get_character_item(character, item)
                inv.quantity += qty
                self._session.add(CharacterCombatSessionKillLoot(kill_record.id, item, qty))
            for skill, xp in kill.xp_gained.items():
                self._get_character_skill(character, skill).experience += xp

        session.kills_rewarded += len(new_kills)
        session.last_rewarded_at = now

        if not result.survived and result.died_at is not None:
            session.died_at = result.died_at
            session.ended_at = result.died_at
            for item, qty in result.items_lost.items():
                inv = self._get_character_item(character, item)
                inv.quantity = max(0, inv.quantity - qty)
            result.recovery_deadline = result.died_at + datetime.timedelta(hours=DEATH_RECOVERY_HOURS)

        self._session.commit()

    def end_combat(self, character: Character) -> CombatResult | None:
        """Close the active combat session and return a result built from DB kill records."""
        # _sync_combat already ran via get_character_by_* — apply any final kills since last sync
        self._sync_combat(character)

        session = self.get_active_combat(character)
        if session is None:
            # Death was detected during sync — find the most recently ended session that died
            session = self._session.scalars(
                select(CharacterCombatSession)
                .where(CharacterCombatSession.character_id == character.id)
                .where(CharacterCombatSession.died_at.is_not(None))
                .order_by(CharacterCombatSession.died_at.desc())
            ).first()
            if session is None:
                return None
            # Write correct food quantity for the death scenario
            assert session.died_at is not None
            elapsed = (session.died_at - session.started_at).total_seconds()
            self._simulate_combat(session, character, elapsed_override=elapsed, write_food=True)
        else:
            session.ended_at = now_utc()
            assert session.ended_at is not None
            elapsed = (session.ended_at - session.started_at).total_seconds()
            self._simulate_combat(session, character, elapsed_override=elapsed, write_food=True)
        self._session.commit()

        kills = [
            KillRecord(
                monster=k.monster,
                xp_gained={
                    Skill.ATTACK: k.xp_attack,
                    Skill.STRENGTH: k.xp_strength,
                    Skill.HITPOINTS: k.xp_hitpoints,
                },
                loot={loot.item: loot.quantity for loot in k.loot},
            )
            for k in session.kills
        ]
        result = CombatResult(kills=kills, survived=session.died_at is None, died_at=session.died_at)
        for kill in kills:
            for skill, xp in kill.xp_gained.items():
                result.xp_gained[skill] = result.xp_gained.get(skill, 0) + xp
        if session.died_at is not None:
            result.recovery_deadline = session.died_at + datetime.timedelta(hours=DEATH_RECOVERY_HOURS)
        return result

    # -------------------------------------------------------------------------
    # Combat simulation
    # -------------------------------------------------------------------------

    @staticmethod
    def _player_max_hit(strength_level: int, strength_bonus: int) -> int:
        effective = strength_level + 8
        return int(0.5 + effective * (strength_bonus + 64) / 640)

    @staticmethod
    def _accuracy(attacker_level: int, attacker_bonus: int, defender_level: int, defender_bonus: int) -> float:
        attack_roll = (attacker_level + 8) * (attacker_bonus + 64)
        defense_roll = (defender_level + 9) * (defender_bonus + 64)
        if attack_roll > defense_roll:
            return 1.0 - (defense_roll + 2) / (2 * attack_roll + 2)
        return attack_roll / (2 * defense_roll + 2)

    def _simulate_combat(
        self,
        session: CharacterCombatSession,
        character: Character,
        elapsed_override: float | None = None,
        write_food: bool = True,
    ) -> CombatResult:
        rng = random.Random(str(session.id))

        attack_level = level_from_xp(self._get_character_skill(character, Skill.ATTACK).experience)
        strength_level = level_from_xp(self._get_character_skill(character, Skill.STRENGTH).experience)
        defense_level = level_from_xp(self._get_character_skill(character, Skill.DEFENSE).experience)
        hitpoints_level = level_from_xp(self._get_character_skill(character, Skill.HITPOINTS).experience)
        max_hp = hitpoints_level

        equipment = self.get_equipment(character)

        weapon_slot = equipment.get(EquipmentSlot.WEAPON)
        if weapon_slot and weapon_slot.item in WEAPON_STATS:
            weapon = WEAPON_STATS[weapon_slot.item]
            attack_speed = weapon.attack_speed
            attack_bonus = weapon.attack_bonus
            strength_bonus = weapon.strength_bonus
        else:
            attack_speed = 2.4
            attack_bonus = 0
            strength_bonus = 0

        total_defense_bonus = sum(
            ARMOR_STATS[eq.item].defense_bonus
            for slot, eq in equipment.items()
            if slot != EquipmentSlot.FOOD and eq.item in ARMOR_STATS
        )

        food_slot = equipment.get(EquipmentSlot.FOOD)
        food_remaining = food_slot.quantity if food_slot else 0
        food_heal = FOOD_STATS[food_slot.item].heal_amount if food_slot and food_slot.item in FOOD_STATS else 0

        area = session.area
        elapsed = (
            elapsed_override
            if elapsed_override is not None
            else (session.ended_at - session.started_at).total_seconds()  # type: ignore[operator]
        )

        current_hp = max_hp
        monster = self._pick_monster(area, rng)
        monster_hp = monster.hitpoints
        next_player_action = 0.0
        next_monster_attack = 0.0
        monster_index = 0

        result = CombatResult()
        pending_atk_xp = 0
        pending_str_xp = 0
        pending_hp_xp = 0

        while True:
            next_event = min(next_player_action, next_monster_attack)
            if next_event > elapsed:
                break

            if next_player_action <= next_monster_attack:
                if food_remaining > 0 and current_hp < AUTO_EAT_THRESHOLD * max_hp:
                    current_hp = min(max_hp, current_hp + food_heal)
                    food_remaining -= 1
                    result.log.append(
                        CombatLogEvent(
                            kind=CombatEventKind.PLAYER_EAT,
                            time=next_player_action,
                            monster=monster,
                            monster_index=monster_index,
                            food_item=food_slot.item if food_slot else None,
                            heal_amount=food_heal,
                            player_hp=current_hp,
                            player_max_hp=max_hp,
                            monster_hp=monster_hp,
                        )
                    )
                else:
                    acc = self._accuracy(attack_level, attack_bonus, monster.defense, 0)
                    max_hit = self._player_max_hit(strength_level, strength_bonus)
                    hit = rng.random() < acc
                    damage = rng.randint(0, max_hit) if hit else 0

                    monster_hp -= damage
                    pending_atk_xp += int(1.5 * damage)
                    pending_str_xp += int(1.5 * damage)
                    pending_hp_xp += damage

                    result.log.append(
                        CombatLogEvent(
                            kind=CombatEventKind.PLAYER_ATTACK,
                            time=next_player_action,
                            monster=monster,
                            monster_index=monster_index,
                            damage=damage,
                            hit=hit,
                            player_hp=current_hp,
                            player_max_hp=max_hp,
                            monster_hp=max(0, monster_hp),
                        )
                    )

                    if monster_hp <= 0:
                        kill_atk = pending_atk_xp
                        kill_str = pending_str_xp
                        kill_hp = pending_hp_xp

                        loot = self._roll_loot(monster, rng)
                        kill = KillRecord(
                            monster=monster,
                            xp_gained={
                                Skill.ATTACK: kill_atk,
                                Skill.STRENGTH: kill_str,
                                Skill.HITPOINTS: kill_hp,
                            },
                            loot=loot,
                        )
                        result.kills.append(kill)
                        for skill, xp in kill.xp_gained.items():
                            result.xp_gained[skill] = result.xp_gained.get(skill, 0) + xp

                        result.log.append(
                            CombatLogEvent(
                                kind=CombatEventKind.MONSTER_KILLED,
                                time=next_player_action,
                                monster=monster,
                                monster_index=monster_index,
                                player_hp=current_hp,
                                player_max_hp=max_hp,
                                loot=loot,
                            )
                        )

                        pending_atk_xp = 0
                        pending_str_xp = 0
                        pending_hp_xp = 0
                        monster_index += 1
                        monster = self._pick_monster(area, rng)
                        monster_hp = monster.hitpoints

                next_player_action += attack_speed

            else:
                acc = self._accuracy(monster.strength, monster.strength_bonus, defense_level, total_defense_bonus)
                monster_max_hit = self._player_max_hit(monster.strength, monster.strength_bonus)
                hit = rng.random() < acc
                damage = rng.randint(0, monster_max_hit) if hit else 0

                current_hp -= damage
                result.log.append(
                    CombatLogEvent(
                        kind=CombatEventKind.MONSTER_ATTACK,
                        time=next_monster_attack,
                        monster=monster,
                        monster_index=monster_index,
                        damage=damage,
                        hit=hit,
                        player_hp=max(0, current_hp),
                        player_max_hp=max_hp,
                        monster_hp=monster_hp,
                    )
                )

                if current_hp <= 0:
                    result.survived = False
                    result.died_at = session.started_at + datetime.timedelta(seconds=next_event)
                    for skill, pending in (
                        (Skill.ATTACK, pending_atk_xp),
                        (Skill.STRENGTH, pending_str_xp),
                        (Skill.HITPOINTS, pending_hp_xp),
                    ):
                        if pending:
                            result.xp_gained[skill] = result.xp_gained.get(skill, 0) + pending
                    result.log.append(
                        CombatLogEvent(
                            kind=CombatEventKind.PLAYER_DIED,
                            time=next_monster_attack,
                            monster=monster,
                            monster_index=monster_index,
                            player_hp=0,
                            player_max_hp=max_hp,
                            monster_hp=monster_hp,
                        )
                    )
                    if food_slot and write_food:
                        food_slot.quantity = food_remaining
                    return result

                next_monster_attack += monster.attack_speed

        for skill, pending in (
            (Skill.ATTACK, pending_atk_xp),
            (Skill.STRENGTH, pending_str_xp),
            (Skill.HITPOINTS, pending_hp_xp),
        ):
            if pending:
                result.xp_gained[skill] = result.xp_gained.get(skill, 0) + pending

        result.log.append(
            CombatLogEvent(
                kind=CombatEventKind.FLED,
                time=elapsed,
                monster=monster,
                monster_index=monster_index,
                player_hp=current_hp,
                player_max_hp=max_hp,
                monster_hp=monster_hp,
            )
        )

        if food_slot and write_food:
            food_slot.quantity = food_remaining

        return result

    @staticmethod
    def _pick_monster(area: CombatArea, rng: random.Random) -> Monster:
        entries = area.monsters
        total_weight = sum(e.weight for e in entries)
        roll = rng.randint(1, total_weight)
        cumulative = 0
        for entry in entries:
            cumulative += entry.weight
            if roll <= cumulative:
                return entry.monster
        return entries[-1].monster

    @staticmethod
    def _roll_loot(monster: Monster, rng: random.Random) -> dict[Item, int]:
        loot: dict[Item, int] = {}
        for entry in monster.loot_table:
            qty = entry.roll(rng)
            if qty > 0:
                loot[entry.item] = loot.get(entry.item, 0) + qty
        return loot

    # -------------------------------------------------------------------------
    # Death recovery
    # -------------------------------------------------------------------------

    def get_pending_death_recovery(self, character: Character) -> CharacterCombatSession | None:
        """Returns the most recent session where the character died and recovery is still possible."""
        deadline = now_utc() - datetime.timedelta(hours=DEATH_RECOVERY_HOURS)
        return self._session.scalars(
            select(CharacterCombatSession)
            .where(CharacterCombatSession.character_id == character.id)
            .where(CharacterCombatSession.died_at.is_not(None))
            .where(CharacterCombatSession.items_recovered.is_(False))
            .where(CharacterCombatSession.died_at > deadline)
            .order_by(CharacterCombatSession.died_at.desc())
        ).first()

    def recover_items(self, character: Character, session: CharacterCombatSession) -> dict[Item, int]:
        """Restore equipped items to inventory if within 24h of death."""
        deadline = now_utc() - datetime.timedelta(hours=DEATH_RECOVERY_HOURS)
        can_recover = session.died_at is not None and session.died_at > deadline

        recovered: dict[Item, int] = {}
        for eq in list(character.equipment):
            recovered[eq.item] = recovered.get(eq.item, 0) + eq.quantity
            if can_recover:
                inv = self._get_character_item(character, eq.item)
                inv.quantity += eq.quantity
            character.equipment.remove(eq)
            self._session.delete(eq)

        session.items_recovered = True
        self._session.commit()
        return recovered if can_recover else {}
