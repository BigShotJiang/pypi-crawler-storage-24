import datetime
import uuid

from sqlalchemy.orm import DeclarativeBase, Mapped, MappedAsDataclass, mapped_column

from idlemaxx.models.utils import now_utc


class IdlemaxBase(MappedAsDataclass, DeclarativeBase):
    __abstract__ = True
    id: Mapped[uuid.UUID] = mapped_column(default_factory=uuid.uuid4, primary_key=True, init=False)
    created_at: Mapped[datetime.datetime] = mapped_column(default_factory=now_utc, init=False)
    updated_at: Mapped[datetime.datetime] = mapped_column(default_factory=now_utc, onupdate=now_utc, init=False)
