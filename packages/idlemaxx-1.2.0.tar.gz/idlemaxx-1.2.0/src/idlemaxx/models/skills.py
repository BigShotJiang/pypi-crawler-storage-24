from enum import Enum


class Skill(Enum):
    MINING = "mining"
    WOODCUTTING = "woodcutting"
    FISHING = "fishing"
    SMITHING = "smithing"
    COOKING = "cooking"
    FLETCHING = "fletching"
    ATTACK = "attack"
    STRENGTH = "strength"
    DEFENSE = "defense"
    HITPOINTS = "hitpoints"
