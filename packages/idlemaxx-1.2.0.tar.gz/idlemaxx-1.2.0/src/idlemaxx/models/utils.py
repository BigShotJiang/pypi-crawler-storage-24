import datetime


def now_utc() -> datetime.datetime:
    return datetime.datetime.now(tz=datetime.UTC).replace(tzinfo=None)


def xp_for_level(level: int) -> int:
    total = 0
    for i in range(1, level):
        total += int(i + 300 * 2 ** (i / 7.0))
    return total // 4


def level_from_xp(xp: int) -> int:
    level = 1
    while xp_for_level(level + 1) <= xp:
        level += 1
    return level
