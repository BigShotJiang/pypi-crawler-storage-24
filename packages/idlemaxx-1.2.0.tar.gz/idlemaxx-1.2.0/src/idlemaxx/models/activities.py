from dataclasses import dataclass, field
from enum import Enum

from idlemaxx.models.items import Item
from idlemaxx.models.skills import Skill


@dataclass
class ActivitySkillRequirement:
    skill: Skill
    required_level: int


@dataclass
class ActivityMaterial:
    item: Item
    quantity: int


@dataclass
class ActivitySkillReward:
    skill: Skill
    xp: int


@dataclass
class ActivityItemReward:
    item: Item
    quantity: int


@dataclass
class ActivityCategoryData:
    display_name: str
    icon: str
    abbreviation: str


class ActivityCategory(Enum):
    WOODCUTTING = ActivityCategoryData(display_name="Woodcutting", icon="🪓", abbreviation="wc")
    MINING = ActivityCategoryData(display_name="Mining", icon="💎", abbreviation="min")
    FISHING = ActivityCategoryData(display_name="Fishing", icon="🎣", abbreviation="fish")
    SMITHING = ActivityCategoryData(display_name="Smithing", icon="🔨", abbreviation="smith")
    COOKING = ActivityCategoryData(display_name="Cooking", icon="🍳", abbreviation="cook")
    FLETCHING = ActivityCategoryData(display_name="Fletching", icon="🏹", abbreviation="fletch")

    @property
    def display_name(self) -> str:
        return self.value.display_name

    @property
    def icon(self) -> str:
        return self.value.icon

    @property
    def abbreviation(self) -> str:
        return self.value.abbreviation


@dataclass
class ActivityData:
    name: str
    action_time: float
    category: ActivityCategory
    skill_requirements: list[ActivitySkillRequirement] = field(default_factory=list)
    materials: list[ActivityMaterial] = field(default_factory=list)
    skill_rewards: list[ActivitySkillReward] = field(default_factory=list)
    item_rewards: list[ActivityItemReward] = field(default_factory=list)


class Activity(Enum):
    # Woodcutting
    CHOP_REGULAR_TREE = ActivityData(
        name="chop_tree",
        action_time=0.5,
        category=ActivityCategory.WOODCUTTING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.WOODCUTTING, required_level=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.WOODCUTTING, xp=25),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.REGULAR_LOG, quantity=1),
        ],
    )
    CHOP_OAK = ActivityData(
        name="chop_oak",
        action_time=1,
        category=ActivityCategory.WOODCUTTING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.WOODCUTTING, required_level=15),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.WOODCUTTING, xp=37),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.OAK_LOG, quantity=1),
        ],
    )
    CHOP_WILLOW = ActivityData(
        name="chop_willow",
        action_time=1.5,
        category=ActivityCategory.WOODCUTTING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.WOODCUTTING, required_level=30),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.WOODCUTTING, xp=67),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.WILLOW_LOG, quantity=1),
        ],
    )
    CHOP_MAPLE = ActivityData(
        name="chop_maple",
        action_time=2,
        category=ActivityCategory.WOODCUTTING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.WOODCUTTING, required_level=45),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.WOODCUTTING, xp=100),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.MAPLE_LOG, quantity=1),
        ],
    )
    CHOP_YEW = ActivityData(
        name="chop_yew",
        action_time=3,
        category=ActivityCategory.WOODCUTTING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.WOODCUTTING, required_level=60),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.WOODCUTTING, xp=175),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.YEW_LOG, quantity=1),
        ],
    )
    CHOP_MAGIC = ActivityData(
        name="chop_magic",
        action_time=4,
        category=ActivityCategory.WOODCUTTING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.WOODCUTTING, required_level=75),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.WOODCUTTING, xp=250),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.MAGIC_LOG, quantity=1),
        ],
    )
    CHOP_REDWOOD = ActivityData(
        name="chop_redwood",
        action_time=5,
        category=ActivityCategory.WOODCUTTING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.WOODCUTTING, required_level=90),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.WOODCUTTING, xp=380),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.REDWOOD_LOG, quantity=2),
        ],
    )
    # Mining
    MINE_TIN = ActivityData(
        name="mine_tin",
        action_time=1,
        category=ActivityCategory.MINING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.MINING, required_level=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.MINING, xp=17),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.TIN_ORE, quantity=1),
        ],
    )
    MINE_COPPER = ActivityData(
        name="mine_copper",
        action_time=1,
        category=ActivityCategory.MINING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.MINING, required_level=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.MINING, xp=17),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.COPPER_ORE, quantity=1),
        ],
    )
    MINE_IRON = ActivityData(
        name="mine_iron",
        action_time=1.5,
        category=ActivityCategory.MINING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.MINING, required_level=15),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.MINING, xp=35),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.IRON_ORE, quantity=1),
        ],
    )
    MINE_COAL = ActivityData(
        name="mine_coal",
        action_time=2,
        category=ActivityCategory.MINING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.MINING, required_level=30),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.MINING, xp=50),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.COAL, quantity=1),
        ],
    )
    MINE_MITHRIL = ActivityData(
        name="mine_mithril",
        action_time=4,
        category=ActivityCategory.MINING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.MINING, required_level=55),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.MINING, xp=80),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.MITHRIL_ORE, quantity=1),
        ],
    )
    MINE_ADAMANTITE = ActivityData(
        name="mine_adamantite",
        action_time=5,
        category=ActivityCategory.MINING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.MINING, required_level=70),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.MINING, xp=95),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.ADAMANTITE_ORE, quantity=1),
        ],
    )
    MINE_RUNITE = ActivityData(
        name="mine_runite",
        action_time=6,
        category=ActivityCategory.MINING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.MINING, required_level=85),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.MINING, xp=125),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.RUNITE_ORE, quantity=1),
        ],
    )
    # Fishing
    FISH_SHRIMP = ActivityData(
        name="fish_shrimp",
        action_time=0.5,
        category=ActivityCategory.FISHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FISHING, required_level=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FISHING, xp=10),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.RAW_SHRIMP, quantity=1),
        ],
    )
    FISH_TROUT = ActivityData(
        name="fish_trout",
        action_time=2,
        category=ActivityCategory.FISHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FISHING, required_level=20),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FISHING, xp=50),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.RAW_TROUT, quantity=1),
        ],
    )
    FISH_SALMON = ActivityData(
        name="fish_salmon",
        action_time=3,
        category=ActivityCategory.FISHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FISHING, required_level=30),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FISHING, xp=70),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.RAW_SALMON, quantity=1),
        ],
    )
    FISH_LOBSTER = ActivityData(
        name="fish_lobster",
        action_time=4,
        category=ActivityCategory.FISHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FISHING, required_level=40),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FISHING, xp=90),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.RAW_LOBSTER, quantity=1),
        ],
    )
    FISH_SWORDFISH = ActivityData(
        name="fish_swordfish",
        action_time=5,
        category=ActivityCategory.FISHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FISHING, required_level=50),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FISHING, xp=100),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.RAW_SWORDFISH, quantity=1),
        ],
    )
    FISH_SHARK = ActivityData(
        name="fish_shark",
        action_time=7,
        category=ActivityCategory.FISHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FISHING, required_level=76),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FISHING, xp=110),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.RAW_SHARK, quantity=1),
        ],
    )
    # Smithing — bars
    SMITH_BRONZE_BAR = ActivityData(
        name="smith_bronze_bar",
        action_time=5,
        category=ActivityCategory.SMITHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.SMITHING, required_level=1),
        ],
        materials=[
            ActivityMaterial(item=Item.COPPER_ORE, quantity=1),
            ActivityMaterial(item=Item.TIN_ORE, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.SMITHING, xp=6),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.BRONZE_BAR, quantity=1),
        ],
    )
    SMITH_IRON_BAR = ActivityData(
        name="smith_iron_bar",
        action_time=6,
        category=ActivityCategory.SMITHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.SMITHING, required_level=15),
        ],
        materials=[
            ActivityMaterial(item=Item.IRON_ORE, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.SMITHING, xp=12),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.IRON_BAR, quantity=1),
        ],
    )
    SMITH_STEEL_BAR = ActivityData(
        name="smith_steel_bar",
        action_time=7,
        category=ActivityCategory.SMITHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.SMITHING, required_level=30),
        ],
        materials=[
            ActivityMaterial(item=Item.IRON_ORE, quantity=1),
            ActivityMaterial(item=Item.COAL, quantity=2),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.SMITHING, xp=17),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.STEEL_BAR, quantity=1),
        ],
    )
    SMITH_MITHRIL_BAR = ActivityData(
        name="smith_mithril_bar",
        action_time=9,
        category=ActivityCategory.SMITHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.SMITHING, required_level=50),
        ],
        materials=[
            ActivityMaterial(item=Item.MITHRIL_ORE, quantity=1),
            ActivityMaterial(item=Item.COAL, quantity=4),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.SMITHING, xp=30),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.MITHRIL_BAR, quantity=1),
        ],
    )
    SMITH_ADAMANTITE_BAR = ActivityData(
        name="smith_adamantite_bar",
        action_time=10,
        category=ActivityCategory.SMITHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.SMITHING, required_level=70),
        ],
        materials=[
            ActivityMaterial(item=Item.ADAMANTITE_ORE, quantity=1),
            ActivityMaterial(item=Item.COAL, quantity=6),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.SMITHING, xp=37),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.ADAMANTITE_BAR, quantity=1),
        ],
    )
    SMITH_RUNITE_BAR = ActivityData(
        name="smith_runite_bar",
        action_time=12,
        category=ActivityCategory.SMITHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.SMITHING, required_level=85),
        ],
        materials=[
            ActivityMaterial(item=Item.RUNITE_ORE, quantity=1),
            ActivityMaterial(item=Item.COAL, quantity=8),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.SMITHING, xp=50),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.RUNITE_BAR, quantity=1),
        ],
    )
    # Smithing — arrowheads
    SMITH_BRONZE_ARROWHEADS = ActivityData(
        name="smith_bronze_arrowheads",
        action_time=3,
        category=ActivityCategory.SMITHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.SMITHING, required_level=5),
        ],
        materials=[
            ActivityMaterial(item=Item.BRONZE_BAR, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.SMITHING, xp=12),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.BRONZE_ARROWHEAD, quantity=15),
        ],
    )
    SMITH_IRON_ARROWHEADS = ActivityData(
        name="smith_iron_arrowheads",
        action_time=3,
        category=ActivityCategory.SMITHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.SMITHING, required_level=20),
        ],
        materials=[
            ActivityMaterial(item=Item.IRON_BAR, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.SMITHING, xp=25),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.IRON_ARROWHEAD, quantity=15),
        ],
    )
    SMITH_STEEL_ARROWHEADS = ActivityData(
        name="smith_steel_arrowheads",
        action_time=4,
        category=ActivityCategory.SMITHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.SMITHING, required_level=35),
        ],
        materials=[
            ActivityMaterial(item=Item.STEEL_BAR, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.SMITHING, xp=37),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.STEEL_ARROWHEAD, quantity=15),
        ],
    )
    SMITH_MITHRIL_ARROWHEADS = ActivityData(
        name="smith_mithril_arrowheads",
        action_time=5,
        category=ActivityCategory.SMITHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.SMITHING, required_level=55),
        ],
        materials=[
            ActivityMaterial(item=Item.MITHRIL_BAR, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.SMITHING, xp=50),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.MITHRIL_ARROWHEAD, quantity=15),
        ],
    )
    SMITH_ADAMANTITE_ARROWHEADS = ActivityData(
        name="smith_adamantite_arrowheads",
        action_time=6,
        category=ActivityCategory.SMITHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.SMITHING, required_level=70),
        ],
        materials=[
            ActivityMaterial(item=Item.ADAMANTITE_BAR, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.SMITHING, xp=62),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.ADAMANTITE_ARROWHEAD, quantity=15),
        ],
    )
    SMITH_RUNITE_ARROWHEADS = ActivityData(
        name="smith_runite_arrowheads",
        action_time=7,
        category=ActivityCategory.SMITHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.SMITHING, required_level=85),
        ],
        materials=[
            ActivityMaterial(item=Item.RUNITE_BAR, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.SMITHING, xp=75),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.RUNITE_ARROWHEAD, quantity=15),
        ],
    )
    # Smithing — scimitars (2 bars each)
    SMITH_BRONZE_SCIMITAR = ActivityData(
        name="smith_bronze_scimitar",
        action_time=6,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=1)],
        materials=[ActivityMaterial(item=Item.BRONZE_BAR, quantity=2)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=25)],
        item_rewards=[ActivityItemReward(item=Item.BRONZE_SCIMITAR, quantity=1)],
    )
    SMITH_IRON_SCIMITAR = ActivityData(
        name="smith_iron_scimitar",
        action_time=7,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=15)],
        materials=[ActivityMaterial(item=Item.IRON_BAR, quantity=2)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=37)],
        item_rewards=[ActivityItemReward(item=Item.IRON_SCIMITAR, quantity=1)],
    )
    SMITH_STEEL_SCIMITAR = ActivityData(
        name="smith_steel_scimitar",
        action_time=8,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=30)],
        materials=[ActivityMaterial(item=Item.STEEL_BAR, quantity=2)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=50)],
        item_rewards=[ActivityItemReward(item=Item.STEEL_SCIMITAR, quantity=1)],
    )
    SMITH_MITHRIL_SCIMITAR = ActivityData(
        name="smith_mithril_scimitar",
        action_time=9,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=50)],
        materials=[ActivityMaterial(item=Item.MITHRIL_BAR, quantity=2)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=75)],
        item_rewards=[ActivityItemReward(item=Item.MITHRIL_SCIMITAR, quantity=1)],
    )
    SMITH_ADAMANTITE_SCIMITAR = ActivityData(
        name="smith_adamantite_scimitar",
        action_time=10,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=70)],
        materials=[ActivityMaterial(item=Item.ADAMANTITE_BAR, quantity=2)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=93)],
        item_rewards=[ActivityItemReward(item=Item.ADAMANTITE_SCIMITAR, quantity=1)],
    )
    SMITH_RUNITE_SCIMITAR = ActivityData(
        name="smith_runite_scimitar",
        action_time=12,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=85)],
        materials=[ActivityMaterial(item=Item.RUNITE_BAR, quantity=2)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=112)],
        item_rewards=[ActivityItemReward(item=Item.RUNITE_SCIMITAR, quantity=1)],
    )
    # Smithing — helmets (2 bars each)
    SMITH_BRONZE_HELMET = ActivityData(
        name="smith_bronze_helmet",
        action_time=6,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=1)],
        materials=[ActivityMaterial(item=Item.BRONZE_BAR, quantity=2)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=25)],
        item_rewards=[ActivityItemReward(item=Item.BRONZE_HELMET, quantity=1)],
    )
    SMITH_IRON_HELMET = ActivityData(
        name="smith_iron_helmet",
        action_time=7,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=15)],
        materials=[ActivityMaterial(item=Item.IRON_BAR, quantity=2)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=37)],
        item_rewards=[ActivityItemReward(item=Item.IRON_HELMET, quantity=1)],
    )
    SMITH_STEEL_HELMET = ActivityData(
        name="smith_steel_helmet",
        action_time=8,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=30)],
        materials=[ActivityMaterial(item=Item.STEEL_BAR, quantity=2)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=50)],
        item_rewards=[ActivityItemReward(item=Item.STEEL_HELMET, quantity=1)],
    )
    SMITH_MITHRIL_HELMET = ActivityData(
        name="smith_mithril_helmet",
        action_time=9,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=50)],
        materials=[ActivityMaterial(item=Item.MITHRIL_BAR, quantity=2)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=75)],
        item_rewards=[ActivityItemReward(item=Item.MITHRIL_HELMET, quantity=1)],
    )
    SMITH_ADAMANTITE_HELMET = ActivityData(
        name="smith_adamantite_helmet",
        action_time=10,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=70)],
        materials=[ActivityMaterial(item=Item.ADAMANTITE_BAR, quantity=2)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=93)],
        item_rewards=[ActivityItemReward(item=Item.ADAMANTITE_HELMET, quantity=1)],
    )
    SMITH_RUNITE_HELMET = ActivityData(
        name="smith_runite_helmet",
        action_time=12,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=85)],
        materials=[ActivityMaterial(item=Item.RUNITE_BAR, quantity=2)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=112)],
        item_rewards=[ActivityItemReward(item=Item.RUNITE_HELMET, quantity=1)],
    )
    # Smithing — bodies (5 bars each)
    SMITH_BRONZE_BODY = ActivityData(
        name="smith_bronze_body",
        action_time=12,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=1)],
        materials=[ActivityMaterial(item=Item.BRONZE_BAR, quantity=5)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=62)],
        item_rewards=[ActivityItemReward(item=Item.BRONZE_BODY, quantity=1)],
    )
    SMITH_IRON_BODY = ActivityData(
        name="smith_iron_body",
        action_time=14,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=15)],
        materials=[ActivityMaterial(item=Item.IRON_BAR, quantity=5)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=93)],
        item_rewards=[ActivityItemReward(item=Item.IRON_BODY, quantity=1)],
    )
    SMITH_STEEL_BODY = ActivityData(
        name="smith_steel_body",
        action_time=16,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=30)],
        materials=[ActivityMaterial(item=Item.STEEL_BAR, quantity=5)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=125)],
        item_rewards=[ActivityItemReward(item=Item.STEEL_BODY, quantity=1)],
    )
    SMITH_MITHRIL_BODY = ActivityData(
        name="smith_mithril_body",
        action_time=18,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=50)],
        materials=[ActivityMaterial(item=Item.MITHRIL_BAR, quantity=5)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=187)],
        item_rewards=[ActivityItemReward(item=Item.MITHRIL_BODY, quantity=1)],
    )
    SMITH_ADAMANTITE_BODY = ActivityData(
        name="smith_adamantite_body",
        action_time=20,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=70)],
        materials=[ActivityMaterial(item=Item.ADAMANTITE_BAR, quantity=5)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=232)],
        item_rewards=[ActivityItemReward(item=Item.ADAMANTITE_BODY, quantity=1)],
    )
    SMITH_RUNITE_BODY = ActivityData(
        name="smith_runite_body",
        action_time=24,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=85)],
        materials=[ActivityMaterial(item=Item.RUNITE_BAR, quantity=5)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=280)],
        item_rewards=[ActivityItemReward(item=Item.RUNITE_BODY, quantity=1)],
    )
    # Smithing — legs (3 bars each)
    SMITH_BRONZE_LEGS = ActivityData(
        name="smith_bronze_legs",
        action_time=9,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=1)],
        materials=[ActivityMaterial(item=Item.BRONZE_BAR, quantity=3)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=37)],
        item_rewards=[ActivityItemReward(item=Item.BRONZE_LEGS, quantity=1)],
    )
    SMITH_IRON_LEGS = ActivityData(
        name="smith_iron_legs",
        action_time=10,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=15)],
        materials=[ActivityMaterial(item=Item.IRON_BAR, quantity=3)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=55)],
        item_rewards=[ActivityItemReward(item=Item.IRON_LEGS, quantity=1)],
    )
    SMITH_STEEL_LEGS = ActivityData(
        name="smith_steel_legs",
        action_time=11,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=30)],
        materials=[ActivityMaterial(item=Item.STEEL_BAR, quantity=3)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=75)],
        item_rewards=[ActivityItemReward(item=Item.STEEL_LEGS, quantity=1)],
    )
    SMITH_MITHRIL_LEGS = ActivityData(
        name="smith_mithril_legs",
        action_time=12,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=50)],
        materials=[ActivityMaterial(item=Item.MITHRIL_BAR, quantity=3)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=112)],
        item_rewards=[ActivityItemReward(item=Item.MITHRIL_LEGS, quantity=1)],
    )
    SMITH_ADAMANTITE_LEGS = ActivityData(
        name="smith_adamantite_legs",
        action_time=13,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=70)],
        materials=[ActivityMaterial(item=Item.ADAMANTITE_BAR, quantity=3)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=140)],
        item_rewards=[ActivityItemReward(item=Item.ADAMANTITE_LEGS, quantity=1)],
    )
    SMITH_RUNITE_LEGS = ActivityData(
        name="smith_runite_legs",
        action_time=15,
        category=ActivityCategory.SMITHING,
        skill_requirements=[ActivitySkillRequirement(skill=Skill.SMITHING, required_level=85)],
        materials=[ActivityMaterial(item=Item.RUNITE_BAR, quantity=3)],
        skill_rewards=[ActivitySkillReward(skill=Skill.SMITHING, xp=168)],
        item_rewards=[ActivityItemReward(item=Item.RUNITE_LEGS, quantity=1)],
    )
    # Cooking
    COOK_SHRIMP = ActivityData(
        name="cook_shrimp",
        action_time=1,
        category=ActivityCategory.COOKING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.COOKING, required_level=1),
        ],
        materials=[
            ActivityMaterial(item=Item.RAW_SHRIMP, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.COOKING, xp=30),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.COOKED_SHRIMP, quantity=1),
        ],
    )
    COOK_TROUT = ActivityData(
        name="cook_trout",
        action_time=1.5,
        category=ActivityCategory.COOKING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.COOKING, required_level=15),
        ],
        materials=[
            ActivityMaterial(item=Item.RAW_TROUT, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.COOKING, xp=70),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.COOKED_TROUT, quantity=1),
        ],
    )
    COOK_SALMON = ActivityData(
        name="cook_salmon",
        action_time=2,
        category=ActivityCategory.COOKING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.COOKING, required_level=25),
        ],
        materials=[
            ActivityMaterial(item=Item.RAW_SALMON, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.COOKING, xp=90),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.COOKED_SALMON, quantity=1),
        ],
    )
    COOK_LOBSTER = ActivityData(
        name="cook_lobster",
        action_time=2.5,
        category=ActivityCategory.COOKING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.COOKING, required_level=40),
        ],
        materials=[
            ActivityMaterial(item=Item.RAW_LOBSTER, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.COOKING, xp=120),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.COOKED_LOBSTER, quantity=1),
        ],
    )
    COOK_SWORDFISH = ActivityData(
        name="cook_swordfish",
        action_time=3,
        category=ActivityCategory.COOKING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.COOKING, required_level=45),
        ],
        materials=[
            ActivityMaterial(item=Item.RAW_SWORDFISH, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.COOKING, xp=140),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.COOKED_SWORDFISH, quantity=1),
        ],
    )
    COOK_SHARK = ActivityData(
        name="cook_shark",
        action_time=4,
        category=ActivityCategory.COOKING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.COOKING, required_level=80),
        ],
        materials=[
            ActivityMaterial(item=Item.RAW_SHARK, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.COOKING, xp=210),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.COOKED_SHARK, quantity=1),
        ],
    )
    # Fletching — unstrung bows
    FLETCH_SHORTBOW = ActivityData(
        name="fletch_shortbow",
        action_time=1,
        category=ActivityCategory.FLETCHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FLETCHING, required_level=5),
        ],
        materials=[
            ActivityMaterial(item=Item.REGULAR_LOG, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FLETCHING, xp=5),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.UNSTRUNG_SHORTBOW, quantity=1),
        ],
    )
    FLETCH_OAK_SHORTBOW = ActivityData(
        name="fletch_oak_shortbow",
        action_time=1.5,
        category=ActivityCategory.FLETCHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FLETCHING, required_level=20),
        ],
        materials=[
            ActivityMaterial(item=Item.OAK_LOG, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FLETCHING, xp=16),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.UNSTRUNG_OAK_SHORTBOW, quantity=1),
        ],
    )
    FLETCH_WILLOW_SHORTBOW = ActivityData(
        name="fletch_willow_shortbow",
        action_time=2,
        category=ActivityCategory.FLETCHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FLETCHING, required_level=35),
        ],
        materials=[
            ActivityMaterial(item=Item.WILLOW_LOG, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FLETCHING, xp=33),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.UNSTRUNG_WILLOW_SHORTBOW, quantity=1),
        ],
    )
    FLETCH_MAPLE_SHORTBOW = ActivityData(
        name="fletch_maple_shortbow",
        action_time=2.5,
        category=ActivityCategory.FLETCHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FLETCHING, required_level=50),
        ],
        materials=[
            ActivityMaterial(item=Item.MAPLE_LOG, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FLETCHING, xp=58),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.UNSTRUNG_MAPLE_SHORTBOW, quantity=1),
        ],
    )
    FLETCH_YEW_SHORTBOW = ActivityData(
        name="fletch_yew_shortbow",
        action_time=3,
        category=ActivityCategory.FLETCHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FLETCHING, required_level=65),
        ],
        materials=[
            ActivityMaterial(item=Item.YEW_LOG, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FLETCHING, xp=67),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.UNSTRUNG_YEW_SHORTBOW, quantity=1),
        ],
    )
    FLETCH_MAGIC_SHORTBOW = ActivityData(
        name="fletch_magic_shortbow",
        action_time=3.5,
        category=ActivityCategory.FLETCHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FLETCHING, required_level=80),
        ],
        materials=[
            ActivityMaterial(item=Item.MAGIC_LOG, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FLETCHING, xp=83),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.UNSTRUNG_MAGIC_SHORTBOW, quantity=1),
        ],
    )
    # Fletching — arrow shafts
    FLETCH_ARROW_SHAFT = ActivityData(
        name="fletch_arrow_shaft",
        action_time=0.5,
        category=ActivityCategory.FLETCHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FLETCHING, required_level=1),
        ],
        materials=[
            ActivityMaterial(item=Item.REGULAR_LOG, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FLETCHING, xp=5),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.ARROW_SHAFT, quantity=15),
        ],
    )
    FLETCH_OAK_ARROW_SHAFT = ActivityData(
        name="fletch_oak_arrow_shaft",
        action_time=0.7,
        category=ActivityCategory.FLETCHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FLETCHING, required_level=15),
        ],
        materials=[
            ActivityMaterial(item=Item.OAK_LOG, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FLETCHING, xp=7),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.OAK_ARROW_SHAFT, quantity=15),
        ],
    )
    FLETCH_WILLOW_ARROW_SHAFT = ActivityData(
        name="fletch_willow_arrow_shaft",
        action_time=0.9,
        category=ActivityCategory.FLETCHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FLETCHING, required_level=30),
        ],
        materials=[
            ActivityMaterial(item=Item.WILLOW_LOG, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FLETCHING, xp=9),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.WILLOW_ARROW_SHAFT, quantity=15),
        ],
    )
    FLETCH_MAPLE_ARROW_SHAFT = ActivityData(
        name="fletch_maple_arrow_shaft",
        action_time=1.1,
        category=ActivityCategory.FLETCHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FLETCHING, required_level=45),
        ],
        materials=[
            ActivityMaterial(item=Item.MAPLE_LOG, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FLETCHING, xp=11),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.MAPLE_ARROW_SHAFT, quantity=15),
        ],
    )
    FLETCH_YEW_ARROW_SHAFT = ActivityData(
        name="fletch_yew_arrow_shaft",
        action_time=1.3,
        category=ActivityCategory.FLETCHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FLETCHING, required_level=60),
        ],
        materials=[
            ActivityMaterial(item=Item.YEW_LOG, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FLETCHING, xp=13),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.YEW_ARROW_SHAFT, quantity=15),
        ],
    )
    FLETCH_MAGIC_ARROW_SHAFT = ActivityData(
        name="fletch_magic_arrow_shaft",
        action_time=1.5,
        category=ActivityCategory.FLETCHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FLETCHING, required_level=75),
        ],
        materials=[
            ActivityMaterial(item=Item.MAGIC_LOG, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FLETCHING, xp=15),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.MAGIC_ARROW_SHAFT, quantity=15),
        ],
    )
    # Fletching — arrows
    FLETCH_BRONZE_ARROW = ActivityData(
        name="fletch_bronze_arrow",
        action_time=0.5,
        category=ActivityCategory.FLETCHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FLETCHING, required_level=1),
        ],
        materials=[
            ActivityMaterial(item=Item.ARROW_SHAFT, quantity=1),
            ActivityMaterial(item=Item.FEATHER, quantity=1),
            ActivityMaterial(item=Item.BRONZE_ARROWHEAD, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FLETCHING, xp=1),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.BRONZE_ARROW, quantity=1),
        ],
    )
    FLETCH_IRON_ARROW = ActivityData(
        name="fletch_iron_arrow",
        action_time=0.5,
        category=ActivityCategory.FLETCHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FLETCHING, required_level=15),
        ],
        materials=[
            ActivityMaterial(item=Item.OAK_ARROW_SHAFT, quantity=1),
            ActivityMaterial(item=Item.FEATHER, quantity=1),
            ActivityMaterial(item=Item.IRON_ARROWHEAD, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FLETCHING, xp=2),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.IRON_ARROW, quantity=1),
        ],
    )
    FLETCH_STEEL_ARROW = ActivityData(
        name="fletch_steel_arrow",
        action_time=0.5,
        category=ActivityCategory.FLETCHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FLETCHING, required_level=30),
        ],
        materials=[
            ActivityMaterial(item=Item.WILLOW_ARROW_SHAFT, quantity=1),
            ActivityMaterial(item=Item.FEATHER, quantity=1),
            ActivityMaterial(item=Item.STEEL_ARROWHEAD, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FLETCHING, xp=5),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.STEEL_ARROW, quantity=1),
        ],
    )
    FLETCH_MITHRIL_ARROW = ActivityData(
        name="fletch_mithril_arrow",
        action_time=0.5,
        category=ActivityCategory.FLETCHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FLETCHING, required_level=45),
        ],
        materials=[
            ActivityMaterial(item=Item.MAPLE_ARROW_SHAFT, quantity=1),
            ActivityMaterial(item=Item.FEATHER, quantity=1),
            ActivityMaterial(item=Item.MITHRIL_ARROWHEAD, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FLETCHING, xp=7),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.MITHRIL_ARROW, quantity=1),
        ],
    )
    FLETCH_ADAMANTITE_ARROW = ActivityData(
        name="fletch_adamantite_arrow",
        action_time=0.5,
        category=ActivityCategory.FLETCHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FLETCHING, required_level=60),
        ],
        materials=[
            ActivityMaterial(item=Item.YEW_ARROW_SHAFT, quantity=1),
            ActivityMaterial(item=Item.FEATHER, quantity=1),
            ActivityMaterial(item=Item.ADAMANTITE_ARROWHEAD, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FLETCHING, xp=10),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.ADAMANTITE_ARROW, quantity=1),
        ],
    )
    FLETCH_RUNITE_ARROW = ActivityData(
        name="fletch_runite_arrow",
        action_time=0.5,
        category=ActivityCategory.FLETCHING,
        skill_requirements=[
            ActivitySkillRequirement(skill=Skill.FLETCHING, required_level=75),
        ],
        materials=[
            ActivityMaterial(item=Item.MAGIC_ARROW_SHAFT, quantity=1),
            ActivityMaterial(item=Item.FEATHER, quantity=1),
            ActivityMaterial(item=Item.RUNITE_ARROWHEAD, quantity=1),
        ],
        skill_rewards=[
            ActivitySkillReward(skill=Skill.FLETCHING, xp=12),
        ],
        item_rewards=[
            ActivityItemReward(item=Item.RUNITE_ARROW, quantity=1),
        ],
    )

    @property
    def category(self) -> ActivityCategory:
        return self.value.category

    @property
    def action_time(self) -> float:
        return self.value.action_time

    @property
    def skill_requirements(self) -> list[ActivitySkillRequirement]:
        return self.value.skill_requirements

    @property
    def skill_rewards(self) -> list[ActivitySkillReward]:
        return self.value.skill_rewards

    @property
    def item_rewards(self) -> list[ActivityItemReward]:
        return self.value.item_rewards

    @property
    def materials(self) -> list[ActivityMaterial]:
        return self.value.materials

    @classmethod
    def from_name(cls, name: str) -> "Activity":
        for activity in cls:
            if activity.value.name == name:
                return activity
        raise ValueError(f"No activity named {name}")
