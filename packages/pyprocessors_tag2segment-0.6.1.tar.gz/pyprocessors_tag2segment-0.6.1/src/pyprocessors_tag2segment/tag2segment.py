from typing import cast

from pydantic import BaseModel, Field
from pymultirole_plugins.v1.processor import ProcessorBase, ProcessorParameters
from pymultirole_plugins.v1.schema import Document, Sentence


class Tag2SegmentParameters(ProcessorParameters):
    """Parameters for the Tag2Segment processor.

    This processor creates text segments from annotations. Annotations matching the specified
    labels are used as segment boundaries (beginning-of-segment markers). Optionally, the
    segmentation annotations can be removed and/or captured as segment metadata.
    """

    segmentation_labels: list[str] = Field(
        None,
        description="List of annotation label names to use as beginning-of-segment markers. "
        "If empty, all annotations are used as segment boundaries.",
        json_schema_extra={"extra": "label"},
    )
    remove_segmentation_annotations: bool = Field(
        False,
        description="If True, remove the annotations that were used for segmentation from the document.",
    )
    annotations_as_metadata: bool = Field(
        False,
        description="If True, capture each segmentation annotation as metadata on the resulting segment. "
        "The metadata key is the annotation label and the value is the annotated text.",
    )


class Tag2SegmentProcessor(ProcessorBase):
    """Create segments from annotations.

    This processor takes documents with annotations and uses those annotations as segment
    boundaries. Each annotation matching the configured labels marks the beginning of a new
    segment. The resulting segments replace the document's existing sentence segmentation.
    """

    def process(self, documents: list[Document], parameters: ProcessorParameters) -> list[Document]:
        params: Tag2SegmentParameters = cast(Tag2SegmentParameters, parameters)
        segmentation_labels = params.segmentation_labels or []
        for document in documents:
            sentences = []
            if document.annotations:
                if len(segmentation_labels) == 0:
                    segmentation_annots = [a for a in document.annotations if a.status != "KO"]
                    kept_annots = [] if params.remove_segmentation_annotations else document.annotations
                else:
                    segmentation_annots = [
                        a for a in document.annotations if a.labelName in segmentation_labels and a.status != "KO"
                    ]
                    kept_annots = (
                        [a for a in document.annotations if a.labelName not in segmentation_labels]
                        if params.remove_segmentation_annotations
                        else document.annotations
                    )
                sorted_annots = sorted(segmentation_annots, key=lambda a: a.start)
                if sorted_annots:
                    start = 0
                    sentences = []
                    metadata = None
                    for a in sorted_annots:
                        i = a.start
                        if i > start:
                            sentences.append(Sentence(start=start, end=i - 1, metadata=metadata))
                            start = i
                        metadata = {a.label: document.text[a.start : a.end]} if params.annotations_as_metadata else None
                    if i < len(document.text):
                        sentences.append(Sentence(start=i, end=len(document.text), metadata=metadata))
                    document.annotations = kept_annots
            if len(sentences) == 0:
                sentences.append(Sentence(start=0, end=len(document.text)))
            document.sentences = sentences
        return documents

    @classmethod
    def get_model(cls) -> type[BaseModel]:
        return Tag2SegmentParameters
