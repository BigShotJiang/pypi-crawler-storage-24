"""Main CyberFlage orchestration class."""

from __future__ import annotations

from typing import Any

from .alerts.manager import AlertManager
from .core.decision_engine import DecisionEngine
from .dashboard.server import DashboardServer
from .deception.engine import DeceptionEngine
from .network.monitor import NetworkMonitor
from .persistence.manager import PersistenceManager


class CyberFlage:
    """Orchestrates scanning, decisioning, deception, alerts, and persistence."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        self.decision_engine = DecisionEngine(config)
        self.network_monitor = NetworkMonitor(config)
        self.deception_engine = DeceptionEngine(config)
        self.alert_manager = AlertManager(config)
        self.persistence_manager = PersistenceManager(config)
        self.dashboard_server = DashboardServer(config)

    def start_dashboard(self) -> None:
        """Start optional dashboard when enabled."""
        self.dashboard_server.start()

    def run_once(self) -> dict[str, Any]:
        """Run one complete processing cycle."""
        signals = self.network_monitor.scan()
        level = self.decision_engine.ingest_signals(signals)
        action = self.deception_engine.evaluate(level)
        self.alert_manager.dispatch(level, action)

        state = {
            "signals": [signal.name for signal in signals],
            "risk_score": self.decision_engine.risk_manager.score,
            "level": level,
            "action": action,
        }
        self.persistence_manager.save(state)
        return state
