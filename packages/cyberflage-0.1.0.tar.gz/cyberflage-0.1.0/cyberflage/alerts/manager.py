"""Alert dispatch manager."""

from __future__ import annotations

import logging
from typing import Any


class AlertManager:
    """Dispatches alert messages using logging."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config
        self.logger = logging.getLogger("cyberflage.alerts")
        if not self.logger.handlers:
            logging.basicConfig(level=logging.INFO)

    def dispatch(self, level: str, message: str) -> None:
        """Log alert with severity mapped from level."""
        level_map = {
            "LOW": logging.INFO,
            "MEDIUM": logging.WARNING,
            "HIGH": logging.ERROR,
            "CRITICAL": logging.CRITICAL,
        }
        self.logger.log(level_map.get(level, logging.INFO), "[%s] %s", level, message)
