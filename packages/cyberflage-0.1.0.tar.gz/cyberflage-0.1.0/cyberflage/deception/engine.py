"""Deception response engine."""

from __future__ import annotations

from typing import Any


class DeceptionEngine:
    """Generates operational deception actions from risk level."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config

    def evaluate(self, level: str) -> str:
        """Return an action message for given level."""
        messages = {
            "LOW": "Continue passive monitoring.",
            "MEDIUM": "Increase decoy visibility.",
            "HIGH": "Deploy active deception traps.",
            "CRITICAL": "Escalate to full deception protocol.",
        }
        return messages.get(level, messages["LOW"])
