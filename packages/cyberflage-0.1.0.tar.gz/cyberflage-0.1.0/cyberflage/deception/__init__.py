"""Deception engine components."""
