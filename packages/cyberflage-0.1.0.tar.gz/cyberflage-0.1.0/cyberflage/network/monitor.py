"""Network monitor with safe stub behavior."""

from __future__ import annotations

from typing import Any

from ..core.signals import Signal

try:
    import psutil
except Exception:  # pragma: no cover
    psutil = None


class NetworkMonitor:
    """Collects local telemetry and emits signals."""

    def __init__(self, config: dict[str, Any]) -> None:
        self.config = config

    def scan(self) -> list[Signal]:
        """Return current signals based on safe local checks."""
        signals: list[Signal] = []
        if psutil is None:
            return signals

        cpu_percent = float(psutil.cpu_percent(interval=0.0))
        if cpu_percent > 90.0:
            signals.append(Signal(name="high_cpu", weight=10.0, metadata={"cpu_percent": cpu_percent}))
        return signals
