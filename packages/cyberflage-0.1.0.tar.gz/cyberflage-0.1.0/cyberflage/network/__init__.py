"""Network monitoring components."""
