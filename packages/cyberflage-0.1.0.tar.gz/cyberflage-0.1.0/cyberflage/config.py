"""Configuration helpers for CyberFlage."""

from __future__ import annotations

from copy import deepcopy
from typing import Any

DEFAULT_CONFIG: dict[str, Any] = {
    "thresholds": {"MEDIUM": 30.0, "HIGH": 60.0, "CRITICAL": 85.0},
    "risk": {"decay_factor": 0.98},
    "persistence": {"state_file": "cyberflage_state.json"},
    "dashboard": {"enabled": False, "host": "127.0.0.1", "port": 5000},
    "alerts": {"channel": "logging"},
}


def _merge(base: dict[str, Any], overrides: dict[str, Any]) -> dict[str, Any]:
    merged = deepcopy(base)
    for key, value in overrides.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _merge(merged[key], value)
        else:
            merged[key] = value
    return merged


def build_config(overrides: dict[str, Any] | None) -> dict[str, Any]:
    """Build a runtime config from safe defaults and optional overrides."""
    if overrides is None:
        return deepcopy(DEFAULT_CONFIG)
    return _merge(DEFAULT_CONFIG, overrides)
