"""JSON state persistence manager."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class PersistenceManager:
    """Persists latest runtime state to a JSON file."""

    def __init__(self, config: dict[str, Any]) -> None:
        file_name = str(config.get("persistence", {}).get("state_file", "cyberflage_state.json"))
        self.state_path = Path(file_name)

    def save(self, state: dict[str, Any]) -> None:
        """Persist provided state to disk."""
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        self.state_path.write_text(json.dumps(state, indent=2), encoding="utf-8")
