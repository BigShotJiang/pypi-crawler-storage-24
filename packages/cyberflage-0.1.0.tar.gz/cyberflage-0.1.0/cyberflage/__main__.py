"""CLI entrypoint for the cyberflage package."""

from __future__ import annotations

import argparse
import json
from typing import Any

from .app import CyberFlage
from .config import build_config


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(description="Run CyberFlage.")
    parser.add_argument(
        "--config",
        type=str,
        default=None,
        help="JSON string with configuration overrides.",
    )
    parser.add_argument(
        "--run-once",
        action="store_true",
        help="Run a single detection cycle and exit.",
    )
    return parser.parse_args()


def main() -> int:
    """Run CyberFlage from CLI."""
    args = parse_args()
    overrides: dict[str, Any] | None = None

    if args.config:
        try:
            parsed = json.loads(args.config)
        except json.JSONDecodeError as exc:
            raise SystemExit(f"Invalid JSON for --config: {exc}") from exc
        if not isinstance(parsed, dict):
            raise SystemExit("--config must be a JSON object.")
        overrides = parsed

    app = CyberFlage(build_config(overrides))
    if args.run_once:
        app.run_once()
    else:
        app.start_dashboard()
        app.run_once()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
