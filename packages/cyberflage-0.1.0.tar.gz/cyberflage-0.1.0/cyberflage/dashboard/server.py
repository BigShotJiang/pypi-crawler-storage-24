"""Optional dashboard server."""

from __future__ import annotations

from typing import Any

try:
    from flask import Flask
except Exception:  # pragma: no cover
    Flask = None


class DashboardServer:
    """Starts a simple dashboard only when enabled and Flask is available."""

    def __init__(self, config: dict[str, Any]) -> None:
        dashboard = config.get("dashboard", {})
        self.enabled = bool(dashboard.get("enabled", False))
        self.host = str(dashboard.get("host", "127.0.0.1"))
        self.port = int(dashboard.get("port", 5000))
        self.app = Flask(__name__) if self.enabled and Flask is not None else None

    def start(self) -> None:
        """Start dashboard server or no-op."""
        if not self.enabled or self.app is None:
            return

        @self.app.get("/health")
        def health() -> dict[str, str]:
            return {"status": "ok"}

        self.app.run(host=self.host, port=self.port)
