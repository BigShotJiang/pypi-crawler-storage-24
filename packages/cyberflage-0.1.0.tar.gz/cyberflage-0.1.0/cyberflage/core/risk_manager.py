"""Risk score manager."""

from __future__ import annotations

from .signals import Signal


class RiskManager:
    """Accumulates weighted signals and maintains a clamped score."""

    def __init__(self, decay_factor: float = 1.0) -> None:
        self._score = 0.0
        self._decay_factor = max(0.0, min(1.0, decay_factor))

    def add_signal(self, signal: Signal) -> None:
        """Add a signal weight to current score."""
        self._score += float(signal.weight)
        self._score = max(0.0, min(100.0, self._score))

    def decay(self) -> None:
        """Apply configured decay to score."""
        self._score *= self._decay_factor
        self._score = max(0.0, min(100.0, self._score))

    @property
    def score(self) -> float:
        """Current score clamped to 0-100."""
        return max(0.0, min(100.0, self._score))
