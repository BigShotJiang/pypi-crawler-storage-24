"""Decision engine mapping score to action levels."""

from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from .risk_manager import RiskManager
from .signals import Signal


class DecisionEngine:
    """Ingests signals and computes action level."""

    def __init__(self, config: dict[str, Any]) -> None:
        risk_cfg = config.get("risk", {})
        self.risk_manager = RiskManager(decay_factor=float(risk_cfg.get("decay_factor", 1.0)))
        self.thresholds = config.get("thresholds", {})

    def ingest_signals(self, signals: Iterable[Signal]) -> str:
        """Ingest signals, update score, and return current action level."""
        self.risk_manager.decay()
        for signal in signals:
            self.risk_manager.add_signal(signal)
        return self.action_level()

    def action_level(self) -> str:
        """Return LOW, MEDIUM, HIGH, or CRITICAL based on thresholds."""
        score = self.risk_manager.score
        medium = float(self.thresholds.get("MEDIUM", 30.0))
        high = float(self.thresholds.get("HIGH", 60.0))
        critical = float(self.thresholds.get("CRITICAL", 85.0))
        if score >= critical:
            return "CRITICAL"
        if score >= high:
            return "HIGH"
        if score >= medium:
            return "MEDIUM"
        return "LOW"
