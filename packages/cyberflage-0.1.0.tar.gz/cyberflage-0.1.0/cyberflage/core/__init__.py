"""Core decision and risk components."""
