# CyberFlage

Modular, production-ready Python package for cybersecurity signal processing and deception orchestration.

## Installation

```bash
pip install -e .
```

## Public API

```python
from cyberflage import CyberFlage, build_config

app = CyberFlage(build_config(None))
result = app.run_once()
print(result)
```

## CLI

```bash
python -m cyberflage --run-once
python -m cyberflage --config "{\"thresholds\":{\"HIGH\":55,\"CRITICAL\":80}}" --run-once
```
