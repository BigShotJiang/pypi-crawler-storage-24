"""
Main trader class combining all trading functionality

Author: WUBOYUAN
Contact: wuboyuan92@126.com
"""

import os
from typing import Optional

from .client import BinanceClient
from .spot import SpotTrading
from .futures import FuturesTrading
from .orders import OrderManager
from .market import MarketData


class BinanceTrader:
    """Main Binance trading interface"""
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        api_secret: Optional[str] = None,
        testnet: bool = False,
        config_file: Optional[str] = None
    ):
        """
        Initialize Binance Trader
        
        Args:
            api_key: Binance API key (or set BINANCE_API_KEY env var)
            api_secret: Binance API secret (or set BINANCE_API_SECRET env var)
            testnet: Use testnet environment
            config_file: Path to config JSON file
        """
        # Load from config file if provided
        if config_file and os.path.exists(config_file):
            import json
            with open(config_file, 'r') as f:
                config = json.load(f)
                api_key = api_key or config.get('api_key')
                api_secret = api_secret or config.get('api_secret')
                testnet = testnet or config.get('testnet', False)
        
        # Load from environment variables
        self.api_key = api_key or os.getenv('BINANCE_API_KEY')
        self.api_secret = api_secret or os.getenv('BINANCE_API_SECRET')
        self.testnet = testnet
        
        # Initialize client
        self.client = BinanceClient(
            api_key=self.api_key,
            api_secret=self.api_secret,
            testnet=self.testnet
        )
        
        # Initialize trading modules
        self.spot = SpotTrading(self.client)
        self.futures = FuturesTrading(self.client)
        self.orders = OrderManager(self.client)
        self.market = MarketData(self.client)
    
    def get_balance(self) -> dict:
        """Get account balance"""
        return self.client.get('/api/v3/account', signed=True)
    
    def get_account_info(self) -> dict:
        """Get detailed account information"""
        return self.client.get('/api/v3/account', signed=True)
    
    def test_connectivity(self) -> bool:
        """Test API connectivity"""
        try:
            self.client.get('/api/v3/ping')
            return True
        except Exception:
            return False
    
    def get_server_time(self) -> dict:
        """Get Binance server time"""
        return self.client.get('/api/v3/time')
