from setuptools import setup, find_packages

setup(
    name='pytobi', 
    version='0.2',
    packages=find_packages(),
    install_requires=[
        'requests',
    ],
    author='Paras',
    description='Best library to check Instagram applications',
    url='https://t.me/Aotpy',
    classifiers=[
        'Programming Language :: Python :: 3',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)