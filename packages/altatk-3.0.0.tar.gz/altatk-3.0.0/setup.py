import re
from setuptools import setup, find_packages
from pathlib import Path

# Read version without importing the package (avoids ModuleNotFoundError in isolated builds)
_version_file = Path(__file__).parent / "kin_tokenizer" / "params.py"
_version_match = re.search(r'^VERSION\s*=\s*["\']([^"\']+)["\']', _version_file.read_text(), re.M)
VERSION = _version_match.group(1) if _version_match else "0.0.0"

# Read long description
long_description = (Path(__file__).parent / "README.md").read_text(encoding="utf-8")

setup(
    name="altatk",
    version=VERSION,
    author="Yali Labs",
    author_email="yalilabs24@gmail.com",
    description="ALTA tokenizer for encoding and decoding Kinyarwanda language text",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Nschadrack/Kin-Tokenizer",
    project_urls={
        # "Bug Tracker": "https://github.com/Nschadrack/Kin-Tokenizer/issues",
        "Source Code": "https://github.com/Nschadrack/Kin-Tokenizer",
    },
    license="MIT",
    packages=find_packages(exclude=["tests", "tests.*", "merger", "merger.*"]),
    keywords=[
        "tokenizer",
        "kinyarwanda",
        "bpe",
        "byte-pair-encoding",
        "nlp",
        "ALTA Model",
        "alta",
    ],
    classifiers=[
        "Development Status :: 4 - Beta",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
        "Operating System :: OS Independent",
        "License :: OSI Approved :: MIT License",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Topic :: Text Processing :: Linguistic",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
    python_requires=">=3.9",
    install_requires=[
        "regex>=2024.7.24",
        "requests>=2.32.3",
        "numpy>=1.24.0",
        "alta-acceleration>=0.3.0",
    ],
    extras_require={
        "training": ["wandb"],
        "dev": ["maturin>=1.0,<2.0", "wandb", "pytest"],
    },
    package_data={
        "kin_tokenizer": [
            "data/*.json",
            "data/*.pkl",
        ],
    },
    include_package_data=True,
)
