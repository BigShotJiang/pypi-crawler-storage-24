"""Shell execution tool."""

import logging
import os
import subprocess
from typing import Annotated

from arcade_tdk import ToolContext, tool

from cade_mcp_local.config import DEFAULT_TIMEOUT, get_project_root
from cade_mcp_local.errors import (
    CommandExecutionError,
    CommandTimeoutError,
    PathNotFoundError,
)
from cade_mcp_local.utils import resolve_path

log = logging.getLogger(__name__)


@tool(
    name="Bash",
    desc=(
        "Execute a shell command or bash script on the local system. "
        "Supports pipes, redirects, loops, and all bash features."
    ),
)
def bash_tool(
    context: ToolContext,
    script: Annotated[str, "Bash command or script to execute."],
    cwd: Annotated[
        str | None,
        "Working directory for the script (relative to project root).",
    ] = None,
    timeout: Annotated[int, "Timeout in seconds."] = DEFAULT_TIMEOUT,
    env: Annotated[
        dict[str, str] | None,
        "Additional environment variables to set.",
    ] = None,
) -> Annotated[dict, "Output of the bash execution."]:
    """Execute a bash command or script using /bin/bash -c."""
    if cwd:
        working_dir = resolve_path(cwd)
        if not working_dir.is_dir():
            raise PathNotFoundError(cwd, f"Working directory not found: {cwd}")
    else:
        working_dir = get_project_root()

    full_env = os.environ.copy()
    if env:
        full_env.update(env)

    try:
        result = subprocess.run(
            ["/bin/bash", "-c", script],
            cwd=str(working_dir),
            capture_output=True,
            text=True,
            timeout=timeout if timeout > 0 else None,
            env=full_env,
        )

        return {
            "stdout": result.stdout or "",
            "stderr": result.stderr or "",
            "exit_code": result.returncode,
            "success": result.returncode == 0,
        }

    except subprocess.TimeoutExpired:
        raise CommandTimeoutError(script[:50], timeout)
    except FileNotFoundError:
        raise CommandExecutionError("bash", "Bash not found at /bin/bash")
    except Exception as e:
        log.error(f"Bash execution failed: {e}")
        raise CommandExecutionError(script[:50], str(e))
