"""Local MCP tools for filesystem, git, search, shell, and context operations.

These tools operate ONLY on the local filesystem and system where the cade process
is running. Use these tools when you need to read, write, search, or execute
commands on the same machine as the running cade process.
"""

from cade_mcp_local.tools.context import search_recent_context_tool
from cade_mcp_local.tools.tool_results import retrieve_tool_result_tool
from cade_mcp_local.tools.tool_schemas import tool_schema_tool
from cade_mcp_local.tools.filesystem import (
    edit_tool,
    list_files_tool,
    read_file_tool,
    write_file_tool,
)
from cade_mcp_local.tools.git import (
    get_current_branch_name,
    get_status,
    git_tool,
)
from cade_mcp_local.tools.search import search_tool
from cade_mcp_local.tools.shell import bash_tool

__all__ = [
    # Filesystem
    "list_files_tool",
    "read_file_tool",
    "write_file_tool",
    "edit_tool",
    # Git
    "git_tool",
    "get_current_branch_name",
    "get_status",
    # Search
    "search_tool",
    # Shell
    "bash_tool",
    # Context
    "search_recent_context_tool",
    # Tool Results
    "retrieve_tool_result_tool",
    # Tool Schemas
    "tool_schema_tool",
]
