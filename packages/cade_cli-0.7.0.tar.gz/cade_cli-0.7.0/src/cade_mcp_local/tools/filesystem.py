"""Filesystem tools for reading, writing, and editing files."""

import difflib
import logging
import pathlib
from enum import Enum
from typing import Annotated, Any, Literal

from arcade_tdk import ToolContext, tool

from cade_mcp_local.config import (
    MAX_LIST_DEPTH,
    MAX_LIST_RESULTS,
    MAX_PREVIEW_BYTES,
    get_project_root,
)
from cade_mcp_local.errors import (
    FileOperationError,
    InvalidInputError,
    PathNotFoundError,
    PathSecurityError,
)
from cade_mcp_local.utils import make_relative, resolve_path, should_ignore

log = logging.getLogger(__name__)


def _read_text_file(file_path: pathlib.Path) -> str:
    """Read a text file, attempting common encodings."""
    encodings = ["utf-8", "latin-1", "cp1252"]
    for encoding in encodings:
        try:
            return file_path.read_text(encoding=encoding)
        except UnicodeDecodeError:
            continue

    # Fallback: read as binary and decode with replacement
    log.warning(
        f"Could not decode {file_path} with standard encodings, using replacement"
    )
    return file_path.read_bytes().decode("utf-8", errors="replace")


def _write_text_file(file_path: pathlib.Path, content: str) -> None:
    """Write text content to a file, ensuring it's within project root."""
    project_root = get_project_root()
    resolved = file_path.resolve()

    # Security check: must be within project root
    try:
        resolved.relative_to(project_root)
    except ValueError:
        raise PathSecurityError(str(file_path), "outside project root")

    # Create parent directories if needed
    resolved.parent.mkdir(parents=True, exist_ok=True)
    resolved.write_text(content, encoding="utf-8")


def _generate_diff(
    original: str,
    new: str,
    filename: str = "file",
    context_lines: int = 3,
) -> str:
    """Generate unified diff between two strings."""
    diff = difflib.unified_diff(
        original.splitlines(),
        new.splitlines(),
        fromfile=f"a/{filename}",
        tofile=f"b/{filename}",
        n=context_lines,
        lineterm="",
    )
    return "\n".join(diff)


@tool(
    name="ListFiles",
    desc="List files in a directory (recursively up to a depth limit). Local filesystem only.",
)
def list_files_tool(
    context: ToolContext,
    directory: Annotated[
        str,
        "Directory path to list (relative to project root). Defaults to current directory.",
    ] = ".",
    recursive: Annotated[bool, "Whether to list files recursively."] = True,
    depth: Annotated[
        int,
        "Maximum depth for listing files. 0 means no depth limit.",
    ] = MAX_LIST_DEPTH,
) -> Annotated[dict[str, Any], "List of files and optional message."]:
    """List files and directories within a specified path."""
    if not 0 <= depth <= MAX_LIST_DEPTH:
        raise InvalidInputError("depth", f"must be between 0 and {MAX_LIST_DEPTH}")

    base_path = resolve_path(directory)
    if not base_path.is_dir():
        raise PathNotFoundError(directory, f"Not a directory: {directory}")

    project_root = get_project_root()
    listed_paths: list[str] = []

    if not recursive:
        for item in base_path.iterdir():
            if should_ignore(item):
                continue
            listed_paths.append(make_relative(item, project_root))
            if len(listed_paths) >= MAX_LIST_RESULTS:
                break
    else:
        # BFS traversal with depth tracking
        queue: list[tuple[pathlib.Path, int]] = [
            (child, 0) for child in base_path.iterdir() if not should_ignore(child)
        ]

        while queue and len(listed_paths) < MAX_LIST_RESULTS:
            current, current_depth = queue.pop(0)

            if current_depth > depth:
                continue

            listed_paths.append(make_relative(current, project_root))

            if current.is_dir() and current_depth < depth:
                for child in current.iterdir():
                    if not should_ignore(child):
                        queue.append((child, current_depth + 1))

    listed_paths.sort()

    message = "Files listed successfully."
    if len(listed_paths) >= MAX_LIST_RESULTS:
        message = f"Truncated at {MAX_LIST_RESULTS} entries."

    return {"files": listed_paths, "message": message}


@tool(
    name="ReadFile",
    desc="Read the entire content of a text file. Local filesystem only.",
)
def read_file_tool(
    context: ToolContext,
    file_path_arg: Annotated[str, "Path to the file to read (relative or absolute)."],
) -> Annotated[dict[str, Any], "File content and message."]:
    """Read content of a specified file."""
    file_path = resolve_path(file_path_arg)

    if not file_path.is_file():
        raise PathNotFoundError(file_path_arg)

    try:
        size = file_path.stat().st_size

        if size > MAX_PREVIEW_BYTES:
            log.warning(f"File {file_path_arg} exceeds limit, truncating")
            with file_path.open("rb") as f:
                start = f.read(MAX_PREVIEW_BYTES // 2).decode(
                    "utf-8", errors="replace"
                )
                f.seek(max(0, size - MAX_PREVIEW_BYTES // 2))
                end = f.read().decode("utf-8", errors="replace")
            content = f"{start}\n... (truncated, {size} bytes total) ...\n{end}"
            return {"content": content, "message": "File truncated due to size."}

        content = _read_text_file(file_path)
        return {"content": content, "message": "File read successfully."}

    except OSError as e:
        raise FileOperationError("read", file_path_arg, str(e))


@tool(
    name="WriteFile",
    desc="Write content to a file, creating/overwriting or appending. Local filesystem only.",
)
def write_file_tool(
    context: ToolContext,
    file_path_arg: Annotated[str, "Path of the file to write."],
    content: Annotated[str, "The complete content to write into the file."],
    mode: Annotated[
        Literal["overwrite", "append"],
        "How to write: 'overwrite' to replace, 'append' to add to end.",
    ] = "overwrite",
) -> Annotated[dict[str, Any], "Result of the write operation."]:
    """Write content to a file."""
    resolved = resolve_path(file_path_arg)

    try:
        if mode == "append" and resolved.exists():
            existing = _read_text_file(resolved)
            content = existing + content

        _write_text_file(resolved, content)
        return {"success": True, "message": f"Successfully wrote to {file_path_arg}"}

    except PathSecurityError:
        raise
    except Exception as e:
        raise FileOperationError("write", file_path_arg, str(e))


class EditMode(str, Enum):
    """Edit operation mode."""

    REPLACE = "replace"
    INSERT = "insert"


class InsertPosition(str, Enum):
    """Where to insert relative to the target line."""

    BEFORE = "before"
    AFTER = "after"


@tool(
    name="Edit",
    desc=(
        "Edit a file by replacing text or inserting at a line number. "
        "mode='replace': find old_string and replace with new_string. "
        "mode='insert': insert content at line_number (1-indexed, 0=end)."
    ),
)
def edit_tool(
    context: ToolContext,
    file_path_arg: Annotated[str, "Path to the file to edit."],
    mode: Annotated[EditMode, "Edit mode: replace or insert."] = EditMode.REPLACE,
    # replace mode params
    old_string: Annotated[
        str,
        "Exact text to find and replace (mode=replace). Must match including whitespace.",
    ] = "",
    new_string: Annotated[str, "Replacement text (mode=replace)."] = "",
    expected_count: Annotated[
        int | None,
        "Expected replacement count; fails if mismatch (mode=replace).",
    ] = None,
    # insert mode params
    line_number: Annotated[
        int, "Line to insert at, 1-indexed. 0 = end of file (mode=insert)."
    ] = 0,
    content: Annotated[str, "Text to insert (mode=insert)."] = "",
    position: Annotated[
        InsertPosition, "Insert before or after the line (mode=insert)."
    ] = InsertPosition.BEFORE,
) -> Annotated[dict[str, Any], "Edit result with diff."]:
    """Edit a file by replacing text or inserting at a line number."""
    resolved = resolve_path(file_path_arg)

    if not resolved.is_file():
        raise PathNotFoundError(file_path_arg)

    if mode == EditMode.REPLACE:
        return _edit_replace(resolved, file_path_arg, old_string, new_string, expected_count)
    elif mode == EditMode.INSERT:
        return _edit_insert(resolved, file_path_arg, line_number, content, position)
    else:
        raise InvalidInputError("mode", f"Unknown mode: {mode}")


def _edit_replace(
    resolved: pathlib.Path,
    file_path_arg: str,
    old_string: str,
    new_string: str,
    expected_count: int | None,
) -> dict[str, Any]:
    """Find-and-replace edit mode."""
    try:
        original = _read_text_file(resolved)
    except Exception as e:
        raise FileOperationError("read", file_path_arg, str(e))

    count = original.count(old_string)

    if count == 0:
        preview = old_string[:100] + ("..." if len(old_string) > 100 else "")
        return {
            "success": False,
            "error": "old_string not found in file",
            "old_string_preview": preview,
            "file_size": len(original),
            "suggestion": "Check whitespace, indentation, and exact character match",
        }

    if expected_count is not None and count != expected_count:
        return {
            "success": False,
            "error": f"Expected {expected_count} occurrences but found {count}",
            "actual_count": count,
        }

    new_content = original.replace(old_string, new_string)
    diff = _generate_diff(original, new_content, file_path_arg)

    try:
        _write_text_file(resolved, new_content)
    except Exception as e:
        raise FileOperationError("write", file_path_arg, str(e))

    return {
        "success": True,
        "message": f"Successfully edited {file_path_arg}",
        "replacements": count,
        "diff": diff or "(no visible diff)",
    }


def _edit_insert(
    resolved: pathlib.Path,
    file_path_arg: str,
    line_number: int,
    content: str,
    position: InsertPosition,
) -> dict[str, Any]:
    """Line-insert edit mode."""
    try:
        original = _read_text_file(resolved)
    except Exception as e:
        raise FileOperationError("read", file_path_arg, str(e))

    lines = original.splitlines(keepends=True)

    # Ensure content ends with newline
    insert_content = content if content.endswith("\n") else content + "\n"

    if line_number == 0:
        # Append at end
        if lines and not lines[-1].endswith("\n"):
            lines[-1] += "\n"
        lines.append(insert_content)
    elif line_number < 0 or line_number > len(lines) + 1:
        raise InvalidInputError(
            "line_number",
            f"{line_number} out of range (file has {len(lines)} lines)",
        )
    else:
        idx = line_number - 1
        if position == InsertPosition.BEFORE:
            lines.insert(idx, insert_content)
        else:
            lines.insert(idx + 1, insert_content)

    new_content = "".join(lines)
    diff = _generate_diff(original, new_content, file_path_arg)

    try:
        _write_text_file(resolved, new_content)
    except Exception as e:
        raise FileOperationError("write", file_path_arg, str(e))

    return {
        "success": True,
        "message": f"Successfully inserted content at line {line_number}",
        "diff": diff,
    }
