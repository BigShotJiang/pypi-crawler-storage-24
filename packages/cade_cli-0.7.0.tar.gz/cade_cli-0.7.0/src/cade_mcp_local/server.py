"""MCP server setup for local tools.

This module creates and configures the MCP server with all local tools.
These tools operate ONLY on the local filesystem and system where the cade
process is running.
"""

# Suppress arcade_mcp_server DEBUG logs (e.g. "Added tool: X") before the library loads.
# When run via stdio subprocess, parent may also pass LOGURU_LEVEL in env.
import os

os.environ.setdefault("LOGURU_LEVEL", "WARNING")

from arcade_mcp_server import MCPApp

from cade_mcp_local.tools import (
    bash_tool,
    edit_tool,
    git_tool,
    list_files_tool,
    read_file_tool,
    retrieve_tool_result_tool,
    search_recent_context_tool,
    search_tool,
    tool_schema_tool,
    write_file_tool,
)

# Server instructions explaining when to use Local tools
SERVER_INSTRUCTIONS = """
Local tools operate ONLY on the local filesystem and system where the cade process
is running. Use these tools when you need to:

- Read, write, or edit files on the same machine as the running cade process
- Search code in the local project directory
- Execute shell commands or bash scripts locally
- Check git status, diff, log, or branches of the local repository
- Search compacted context backups stored locally

Do NOT use these tools for operations on remote systems, cloud resources, or
external services. For those, use the appropriate remote/cloud tools instead.
"""


def create_app() -> MCPApp:
    """Create and configure the MCP application with all local tools."""
    app = MCPApp("Local", "stdio", log_level="info")

    # Set server instructions
    app.instructions = SERVER_INSTRUCTIONS

    # Filesystem tools
    app.add_tool(list_files_tool)
    app.add_tool(read_file_tool)
    app.add_tool(write_file_tool)
    app.add_tool(edit_tool)

    # Shell tool
    app.add_tool(bash_tool)

    # Search tool (consolidated: ripgrep with grep fallback)
    app.add_tool(search_tool)

    # Git tool (consolidated: status, diff, log, branch)
    app.add_tool(git_tool)

    # Context tools
    app.add_tool(search_recent_context_tool)

    # Tool result retrieval (consolidated: full, search, summarize, lines, json, list)
    app.add_tool(retrieve_tool_result_tool)

    # Tool schema tool (consolidated: list + get)
    app.add_tool(tool_schema_tool)

    return app


# Global app instance for the entry point
app = create_app()
