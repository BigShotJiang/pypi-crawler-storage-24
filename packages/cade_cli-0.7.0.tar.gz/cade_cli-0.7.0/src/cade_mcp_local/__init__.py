"""Local MCP server for Cade CLI.

This package provides local filesystem, git, search, and shell tools
served via the MCP (Model Context Protocol) over stdio.

Usage:
    # As a command-line tool (entry point)
    $ cade-mcp-local

    # As a Python module
    $ python -m cade_mcp_local

    # Programmatically
    from cade_mcp_local import main
    main()
"""

from cade_mcp_local.config import (
    DEFAULT_IGNORE_PATTERNS,
    DEFAULT_TIMEOUT,
    MAX_LIST_DEPTH,
    MAX_LIST_RESULTS,
    MAX_PREVIEW_BYTES,
    get_project_root,
    reset_config,
)
from cade_mcp_local.errors import (
    CommandExecutionError,
    CommandTimeoutError,
    FileOperationError,
    GitOperationError,
    InvalidInputError,
    PathNotFoundError,
    PathSecurityError,
    SearchError,
)
from cade_mcp_local.server import app, create_app


def main() -> None:
    """Run the MCP server.

    This is the entry point for the `cade-mcp-local` command.
    """
    app.run()


__all__ = [
    # Entry point
    "main",
    "app",
    "create_app",
    # Configuration
    "get_project_root",
    "reset_config",
    "DEFAULT_IGNORE_PATTERNS",
    "DEFAULT_TIMEOUT",
    "MAX_LIST_DEPTH",
    "MAX_LIST_RESULTS",
    "MAX_PREVIEW_BYTES",
    # Errors
    "PathNotFoundError",
    "PathSecurityError",
    "InvalidInputError",
    "CommandTimeoutError",
    "CommandExecutionError",
    "GitOperationError",
    "SearchError",
    "FileOperationError",
]

__version__ = "0.7.0"
