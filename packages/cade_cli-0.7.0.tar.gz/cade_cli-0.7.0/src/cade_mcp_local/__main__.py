"""Allow running as: python -m cade_mcp_local"""

from cade_mcp_local import main

if __name__ == "__main__":
    main()
