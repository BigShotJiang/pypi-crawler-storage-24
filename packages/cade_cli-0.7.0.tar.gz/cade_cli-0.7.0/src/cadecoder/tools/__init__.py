"""Tools module for AI agent capabilities.

This module provides MCP tool management for both local and external servers.

Architecture:
    cadecoder/tools/
    └── manager.py         # All tool management (MCPToolManager, CompositeToolManager)

    mcp_servers/           # MCP server implementations (top-level)
    └── local/             # Local tools MCP server (filesystem, shell, search, git)
        ├── server.py      # Stdio MCP server entry point
        ├── filesystem.py  # File operations
        ├── shell.py       # Shell/bash execution
        ├── search.py      # Grep/ripgrep search
        └── git.py         # Git operations
"""

from cadecoder.tools.manager import (
    CompositeToolManager,
    MCPAuthType,
    MCPOAuthTokens,
    MCPServerConfig,
    MCPToolManager,
    MCPTransportType,
    ToolAuthorizationRequired,
    ToolManager,
)

__all__ = [
    # Managers
    "ToolManager",
    "MCPToolManager",
    "CompositeToolManager",
    # MCP
    "MCPServerConfig",
    "MCPAuthType",
    "MCPOAuthTokens",
    "MCPTransportType",
    # Exceptions
    "ToolAuthorizationRequired",
]
