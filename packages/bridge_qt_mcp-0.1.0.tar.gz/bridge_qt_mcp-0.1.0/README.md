# bridge-qt-mcp

[MCP](https://modelcontextprotocol.io/) server for **QtBridge (桥通)** — bridge finite element analysis software.

This MCP server exposes 348 tools that allow AI assistants (Claude Desktop, Claude Code, etc.) to directly control the QtBridge software for bridge modeling, analysis, and design verification.

## Features

- **348 tools** auto-generated from the `qtmodel` Python API
  - `mdb_*` (234 tools) — Modeling: nodes, elements, materials, sections, loads, tendons, construction stages
  - `odb_*` (89 tools) — Results: reactions, deformations, stresses, visualization
  - `cdb_*` (25 tools) — Design checks: concrete, steel box, steel truss, anti-overturn
- Zero configuration — all tools are auto-discovered from the `qtmodel` package
- Full parameter schemas with types, defaults, and descriptions from docstrings

## Prerequisites

- **QtBridge (桥通) software** must be running (provides HTTP API at `localhost:55125`)
- Python >= 3.10

## Installation

```bash
pip install bridge-qt-mcp
```

Or install from source:

```bash
git clone https://github.com/Inface0443/pyqt.git
cd pyqt
pip install -e .
```

## Configuration

### Claude Desktop

Add to your Claude Desktop config file:

- **Windows**: `%APPDATA%\Claude\claude_desktop_config.json`
- **macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "bridge-qt": {
      "command": "bridge-qt-mcp"
    }
  }
}
```

### Claude Code

```bash
claude mcp add bridge-qt -- bridge-qt-mcp
```

### Cursor / Other MCP Clients

Use stdio transport with command `bridge-qt-mcp`.

## Usage Examples

Once connected, you can ask Claude to interact with QtBridge directly:

**Modeling:**
> "Create 10 nodes at coordinates (0,0,0) to (9,0,0) with 1m spacing, then connect them with beam elements using C50 concrete."

**Results:**
> "Get the support reactions at nodes 500, 502, 488 for construction stage 9, and export them to an Excel file."

**Visualization:**
> "Plot the bending moment diagram for the operational stage with load case '成桥(合计)'."

**Design Checks:**
> "Run the concrete structure verification for the default structure group."

## Tool Naming Convention

Tools follow the pattern `{module}_{method_name}`:

| Prefix | Module | Description |
|--------|--------|-------------|
| `mdb_` | Model Database | Pre-processing: create/modify model |
| `odb_` | Output Database | Post-processing: query results |
| `cdb_` | Check Database | Design verification |

### Common Tools

| Tool | Description |
|------|-------------|
| `mdb_add_nodes` | Add nodes by coordinates |
| `mdb_add_element` | Add a single element |
| `mdb_add_material` | Define material properties |
| `mdb_add_section` | Define cross-section |
| `mdb_add_construction_stage` | Define construction stage |
| `mdb_do_solve` | Run analysis |
| `odb_get_reaction` | Get support reactions |
| `odb_get_deformation` | Get node displacements |
| `odb_get_element_force` | Get element internal forces |
| `odb_get_element_stress` | Get element stresses |
| `odb_plot_beam_element_force` | Plot beam force diagram |
| `cdb_solve_concrete_check` | Run concrete verification |

## Development

```bash
# Clone the repo
git clone https://github.com/Inface0443/pyqt.git
cd pyqt

# Install in development mode
pip install -e .

# Run the server directly
bridge-qt-mcp
# or
python -m qtmodel.mcp_server
```

## qtmodel Python API

This package also provides the `qtmodel` Python library for scripting QtBridge directly:

```python
from qtmodel import mdb, odb, cdb

# Add nodes
mdb.add_nodes(node_data=[[1, 0, 0, 0], [2, 1, 0, 0], [3, 2, 0, 0]])

# Add beam elements
mdb.add_element(index=1, ele_type=1, node_ids=[1, 2], mat_id=1, sec_id=1)
mdb.add_element(index=2, ele_type=1, node_ids=[2, 3], mat_id=1, sec_id=1)

# Run analysis
mdb.do_solve()

# Get results
import json
reactions = json.loads(odb.get_reaction(ids=[1, 3], stage_id=1))
print(reactions)
```

See the [full API documentation](https://github.com/Inface0443/pyqt) for details.

## License

MIT
