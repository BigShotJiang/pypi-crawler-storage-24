"""
桥通软件 MCP 服务器
自动将 qtmodel 的所有 API 暴露为 MCP 工具，供 Claude Desktop / Claude Code 等客户端调用。

用法:
    bridge-qt-mcp                     # pip install 后直接运行
    python -m qtmodel.mcp_server      # 或作为模块运行
"""

import json
import inspect
import logging
import asyncio
from typing import Any, get_type_hints, Union

from mcp.server import Server
from mcp.types import Tool, TextContent
from mcp.server.stdio import stdio_server

from qtmodel.mdb import Mdb
from qtmodel.odb import Odb
from qtmodel.cdb import Cdb

# ---------------------------------------------------------------------------
# 日志
# ---------------------------------------------------------------------------
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("bridge-mcp")

# ---------------------------------------------------------------------------
# 类型转换: Python type hint -> JSON Schema
# ---------------------------------------------------------------------------

def _python_type_to_json_schema(tp) -> dict:
    """将 Python 类型注解转换为 JSON Schema 片段。"""
    if tp is inspect.Parameter.empty or tp is Any:
        return {}

    origin = getattr(tp, "__origin__", None)

    # Optional[X] = Union[X, None]
    if origin is Union:
        args = [a for a in tp.__args__ if a is not type(None)]
        if len(args) == 1:
            return _python_type_to_json_schema(args[0])
        return {}

    # list[X]
    if origin is list:
        inner = tp.__args__[0] if tp.__args__ else Any
        return {"type": "array", "items": _python_type_to_json_schema(inner)}

    # tuple[X, ...]
    if origin is tuple:
        if tp.__args__:
            return {
                "type": "array",
                "items": _python_type_to_json_schema(tp.__args__[0]),
            }
        return {"type": "array"}

    # dict[K, V]
    if origin is dict:
        return {"type": "object"}

    # 基本类型
    if tp is int:
        return {"type": "integer"}
    if tp is float:
        return {"type": "number"}
    if tp is str:
        return {"type": "string"}
    if tp is bool:
        return {"type": "boolean"}

    return {}


def _build_input_schema(method) -> dict:
    """根据方法签名自动生成 JSON Schema（inputSchema）。"""
    sig = inspect.signature(method)
    try:
        hints = get_type_hints(method)
    except Exception:
        hints = {}

    properties: dict[str, Any] = {}
    required: list[str] = []

    for name, param in sig.parameters.items():
        if name in ("self", "cls"):
            continue

        prop = {}
        tp = hints.get(name, param.annotation)
        schema_part = _python_type_to_json_schema(tp)
        prop.update(schema_part)

        # 从 docstring 中抽取参数描述
        doc = inspect.getdoc(method) or ""
        for line in doc.splitlines():
            stripped = line.strip()
            if stripped.startswith(f"{name}:") or stripped.startswith(f"{name} :"):
                desc = stripped.split(":", 1)[1].strip()
                prop["description"] = desc
                break

        if param.default is not inspect.Parameter.empty:
            prop["default"] = param.default
        else:
            required.append(name)

        properties[name] = prop

    schema: dict[str, Any] = {
        "type": "object",
        "properties": properties,
    }
    if required:
        schema["required"] = required
    return schema


# ---------------------------------------------------------------------------
# 工具注册表：自动扫描 Mdb / Odb / Cdb 的公开静态方法
# ---------------------------------------------------------------------------

class ToolRegistry:
    """扫描门面类，构建 tool_name -> (callable, Tool) 的映射。"""

    def __init__(self):
        self._tools: dict[str, tuple[callable, Tool]] = {}
        self._register_class(Mdb, prefix="mdb")
        self._register_class(Odb, prefix="odb")
        self._register_class(Cdb, prefix="cdb")
        logger.info("Registered %d MCP tools", len(self._tools))

    @property
    def summary(self) -> dict[str, int]:
        counts: dict[str, int] = {}
        for name in self._tools:
            prefix = name.split("_", 1)[0]
            counts[prefix] = counts.get(prefix, 0) + 1
        return counts

    def _register_class(self, cls, prefix: str):
        """遍历类的所有公开方法并注册为工具。"""
        for name in sorted(dir(cls)):
            if name.startswith("_"):
                continue
            method = getattr(cls, name)
            if not callable(method):
                continue
            if not isinstance(inspect.getattr_static(cls, name), staticmethod):
                continue

            tool_name = f"{prefix}_{name}"
            doc = inspect.getdoc(method) or f"{prefix}.{name}"
            description = doc.split("\n")[0].strip()
            if len(description) < 5:
                description = f"{prefix}.{name}()"

            try:
                input_schema = _build_input_schema(method)
            except Exception:
                input_schema = {"type": "object", "properties": {}}

            tool = Tool(
                name=tool_name,
                description=f"[{prefix.upper()}] {description}",
                inputSchema=input_schema,
            )
            self._tools[tool_name] = (method, tool)

    def list_tools(self) -> list[Tool]:
        return [t for _, t in self._tools.values()]

    def get_method(self, tool_name: str):
        entry = self._tools.get(tool_name)
        return entry[0] if entry else None


# ---------------------------------------------------------------------------
# MCP 服务器
# ---------------------------------------------------------------------------

def create_server() -> tuple[Server, ToolRegistry]:
    server = Server("bridge-qt-mcp")
    registry = ToolRegistry()

    @server.list_tools()
    async def handle_list_tools() -> list[Tool]:
        return registry.list_tools()

    @server.call_tool()
    async def handle_call_tool(name: str, arguments: dict | None) -> list[TextContent]:
        method = registry.get_method(name)
        if method is None:
            return [TextContent(type="text", text=f"Error: unknown tool '{name}'")]

        arguments = arguments or {}
        try:
            result = method(**arguments)
            if result is None:
                text = "OK"
            elif isinstance(result, str):
                try:
                    parsed = json.loads(result)
                    text = json.dumps(parsed, ensure_ascii=False, indent=2)
                except (json.JSONDecodeError, TypeError):
                    text = result
            else:
                text = json.dumps(result, ensure_ascii=False, indent=2)
        except Exception as e:
            text = f"Error: {type(e).__name__}: {e}"

        return [TextContent(type="text", text=text)]

    return server, registry


# ---------------------------------------------------------------------------
# 入口
# ---------------------------------------------------------------------------

async def main():
    server, registry = create_server()
    summary = registry.summary
    logger.info(
        "bridge-qt-mcp started — %d tools (mdb:%d, odb:%d, cdb:%d)",
        sum(summary.values()),
        summary.get("mdb", 0),
        summary.get("odb", 0),
        summary.get("cdb", 0),
    )
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


def main_sync():
    """Synchronous entry point for console_scripts."""
    asyncio.run(main())


if __name__ == "__main__":
    main_sync()
