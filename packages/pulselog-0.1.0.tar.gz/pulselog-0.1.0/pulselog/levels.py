from __future__ import annotations

from enum import IntEnum


class Level(IntEnum):
    """Log severity levels, compatible with stdlib logging values."""

    DEBUG = 10
    INFO = 20
    WARNING = 30
    ERROR = 40
    CRITICAL = 50

    @classmethod
    def from_str(cls, s: str) -> Level:
        """Parse a level from a string, case-insensitive.

        Args:
            s: Level name, e.g. "info", "WARNING".

        Returns:
            Corresponding Level enum member.

        Raises:
            ValueError: If the string doesn't match any known level.
        """
        upper = s.upper().strip()
        try:
            return cls[upper]
        except KeyError:
            valid = ", ".join(m.name for m in cls)
            raise ValueError(
                f"Unknown log level {s!r}. Valid levels: {valid}"
            ) from None
