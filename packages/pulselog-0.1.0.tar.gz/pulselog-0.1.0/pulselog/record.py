from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from pulselog.levels import Level


@dataclass
class LogRecord:
    """Immutable snapshot of a single log event.

    Attributes:
        level:     Severity level.
        msg:       Log message string.
        timestamp: Unix timestamp (seconds) when the record was created.
        extra:     Arbitrary key/value metadata supplied by the caller.
        tag:       Active tag label at the time of logging, or None.
    """

    level: Level
    msg: str
    timestamp: float = field(default_factory=time.time)
    extra: Dict[str, Any] = field(default_factory=dict)
    tag: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        """Serialize to a JSON-serializable dict.

        Returns:
            Dict with string keys and JSON-safe values.
        """
        return {
            "level": self.level.name,
            "msg": self.msg,
            "timestamp": self.timestamp,
            "extra": self.extra,
            "tag": self.tag,
        }
