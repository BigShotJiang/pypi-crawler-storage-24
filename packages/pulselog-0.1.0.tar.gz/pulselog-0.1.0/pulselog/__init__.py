from __future__ import annotations

from pulselog.logger import Logger

__version__ = "0.1.0"
__all__ = ["Logger", "__version__"]
