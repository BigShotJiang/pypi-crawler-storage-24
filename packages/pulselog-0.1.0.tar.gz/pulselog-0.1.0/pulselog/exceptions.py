from __future__ import annotations


class PulseLogError(Exception):
    """Base exception for all pulselog errors."""


class InvalidStatusError(PulseLogError):
    """Raised when a checkpoint status value is not one of the allowed values."""
