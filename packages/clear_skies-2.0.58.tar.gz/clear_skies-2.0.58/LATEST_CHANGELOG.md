## [2.0.58] - 2026-03-25

### Fixed
- Cors should check the request url

