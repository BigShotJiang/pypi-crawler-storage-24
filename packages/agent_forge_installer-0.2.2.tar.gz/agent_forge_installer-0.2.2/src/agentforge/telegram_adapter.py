#!/usr/bin/env python3
"""AgentForge Telegram Adapter — polls Telegram, invokes Claude Code CLI.

This is the main bot process. It uses extracted modules for:
- HTTP: agentforge.http_client
- Routing: agentforge.message_router
- Claude invocation: agentforge.claude_runner
- Voice: agentforge.voice
"""

import json
import logging
import os
import queue
import random
import signal
import sqlite3
import subprocess
import sys
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

from agentforge.http_client import http_get, http_post_json
from agentforge.config_models import AgentRuntimeConfig, ValidationError, load_agent_runtime_config, load_command_config
from agentforge.message_router import (
    get_thread_config,
    get_project_topic_config,
    get_agent_thread_config,
    parse_mention,
    build_topic_context,
)
from agentforge.claude_runner import (
    ClaudeCodeLimitError,
    InvokeResult,
    RateLimitError,
    format_claude_code_limit_user_message,
    invoke_claude,
)
from agentforge.approval_gates import ApprovalGates
from agentforge.claude_usage import ClaudeUsageError, get_claude_oauth_usage, parse_usage_reset
from agentforge.config_store import RuntimeConfigStore
from agentforge.rate_limiter import RateLimiter
from agentforge.conversation_store import ConversationStore
from agentforge.voice import transcribe_voice_note

MONTREAL = ZoneInfo("America/Montreal")

AGENTFORGE_ROOT = os.environ.get("AGENTFORGE_ROOT", os.path.expanduser("~"))
AGENT_DIR = os.environ.get("AGENT_DIR")  # Per-agent dir, e.g. agents/archie/ — new architecture
CONFIG_PATH = Path(AGENTFORGE_ROOT) / "bot" / "config.json"
ENV_PATH = Path(AGENTFORGE_ROOT) / ".env"

WORKING_MESSAGES = [
    "⏳ Je travaille là-dessus, je te reviens…",
    "⏳ On it.",
    "⏳ Je m'en occupe.",
    "⏳ Laisse-moi regarder ça.",
    "⏳ En cours…",
    "⏳ Je creuse ça.",
    "⏳ Ça s'en vient.",
    "⏳ Working on it…",
    "⏳ Je cogite.",
    "⏳ Une seconde.",
    "⏳ Sur le coup.",
    "⏳ Let me check that.",
    "⏳ J'y travaille.",
    "⏳ En train de réfléchir…",
    "⏳ Donne-moi un moment.",
    "⏳ Je m'y mets.",
    "⏳ Hold on…",
    "⏳ Je fouille ça.",
    "⏳ Deux secondes.",
    "⏳ On the case.",
]

STARTUP_MESSAGES = [
    "✅ Je suis de retour.",
    "✅ Back online.",
    "✅ Me revoilà.",
    "✅ Rebooted and ready.",
    "✅ Je suis là, qu'est-ce que j'ai manqué ?",
    "✅ Redémarrage complété. Prête.",
    "✅ Back in business.",
    "✅ Online. Qu'est-ce qui se passe ?",
    "✅ Je reviens de nulle part, mais je suis là.",
    "✅ Restart réussi. À vos ordres.",
    "✅ Hello again.",
    "✅ C'est reparti.",
    "✅ J'ai survécu au redémarrage.",
    "✅ Ready when you are.",
    "✅ De retour sur mes pattes.",
    "✅ Relancée. On reprend ?",
    "✅ Je suis vivante.",
    "✅ Up and running.",
    "✅ Boop — je suis là.",
    "✅ Redémarrée avec succès. Bonjour !",
]


def _verify_telegram_bot_identity(
    api_base: str,
    expected_username: str,
    *,
    http_get_fn=http_get,
) -> bool:
    """Return True when identity is verified or unverifiable; False on mismatch."""
    expected = expected_username.strip().lstrip("@")
    if not expected:
        return True

    try:
        payload = http_get_fn(f"{api_base}/getMe", timeout=10)
    except Exception as exc:
        logging.warning(f"Could not verify Telegram bot identity: {exc}")
        return True

    if not payload.get("ok"):
        description = payload.get("description", "unknown error")
        logging.warning(f"Could not verify Telegram bot identity: {description}")
        return True

    actual = str(payload.get("result", {}).get("username", "")).strip().lstrip("@")
    if not actual:
        logging.warning("Could not verify Telegram bot identity: missing username in getMe response.")
        return True

    if actual.lower() != expected.lower():
        logging.error(f"Telegram token mismatch: expected @{expected} but token belongs to @{actual}.")
        return False

    logging.info(f"  ✓ Telegram token verified for @{actual}")
    return True


class ClawdiaBot:
    def __init__(self, config_path: str | None = None):
        if config_path:
            path = Path(config_path)
        elif AGENT_DIR:
            path = Path(AGENT_DIR) / "config.json"
        else:
            path = CONFIG_PATH
        self._config_path = path
        self._config_store = RuntimeConfigStore(
            path,
            normalizer=self._normalize_config,
            log_warning=logging.warning,
        )
        self.config = self._config_store.get_config()
        self.bot_name = self.config.get("bot_name", "assistant")
        self._load_env()
        self.token = os.environ.get(self.config["telegram"]["token_env_var"], "")
        if not self.token:
            logging.error(
                f"Telegram token not found in env var "
                f"{self.config['telegram']['token_env_var']}"
            )
            sys.exit(1)
        self.api_base = f"https://api.telegram.org/bot{self.token}"
        expected_bot = self.config.get("telegram", {}).get("bot_username", "")
        if not _verify_telegram_bot_identity(self.api_base, expected_bot):
            sys.exit(1)
        self._build_api_bases()
        self.offset = self._load_offset()
        self.db = self._init_db()
        self.db_lock = threading.Lock()
        self.agent_queues: dict[str, queue.Queue] = {}
        self.agent_workers: dict[str, threading.Thread] = {}
        limits_cfg = self.config.get("rate_limits", {})
        self.rate_limiter = RateLimiter(
            max_per_minute=int(limits_cfg.get("max_per_minute", 10)),
            max_per_hour=int(limits_cfg.get("max_per_hour", 60)),
            max_concurrent_sessions=int(limits_cfg.get("max_concurrent_sessions", 2)),
        )
        self.running = True
        self._last_retry_check = 0.0
        self.approval_gates = ApprovalGates(root=AGENTFORGE_ROOT)
        signal.signal(signal.SIGTERM, self._shutdown)
        signal.signal(signal.SIGINT, self._shutdown)
        self._register_commands()
        # Pre-start one worker per known agent
        self._ensure_agent_worker(self.bot_name)
        for tid, tcfg in self.config.get("threads", {}).items():
            if tid == "default":
                continue
            agent_name = tcfg.get("name", self.bot_name) or self.bot_name
            self._ensure_agent_worker(agent_name)

    # ------------------------------------------------------------------
    # Initialization helpers
    # ------------------------------------------------------------------

    def _load_env(self):
        """Source .env file into environment."""
        if ENV_PATH.exists():
            for line in ENV_PATH.read_text().splitlines():
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, val = line.split("=", 1)
                    os.environ[key.strip()] = val.strip()

    def _normalize_config(self, raw: dict) -> dict:
        """Normalize a per-agent config.json (new format) into the legacy structure.

        When AGENT_DIR is set the config has a flat structure:
            {"name": "archie", "telegram": {...}, "claude": {...}, "context": {...}}
        This is converted to the internal representation expected by ClawdiaBot.
        Legacy configs (with bot_name, threads, memory keys) pass through unchanged.
        """
        if "bot_name" in raw or "threads" in raw:
            return raw  # already in legacy format

        try:
            raw = AgentRuntimeConfig.model_validate(raw).model_dump()
        except ValidationError as exc:
            raise ValueError(f"Invalid config at {self._config_path}: {exc}") from exc

        name = raw.get("name", "assistant")
        db_path = str(Path(AGENTFORGE_ROOT) / "data" / "conversations.db")
        ctx = raw.get("context", {})
        normalized = {
            "bot_name": name,
            "telegram": raw.get("telegram", {}),
            "claude": raw.get("claude", {}),
            "context": ctx,
            "memory": {"db_path": db_path},
            # Include agent name in default thread so _build_system_prompt_context
            # resolves to agents/<name>/soul.md and memory.md
            "threads": {
                "default": {
                    "name": name,
                    "model": raw.get("claude", {}).get("model", "haiku"),
                    "context_messages": ctx.get("messages", 10),
                }
            },
            "commands": {},
        }
        return normalized

    def _discover_filesystem_commands(self) -> dict[str, dict]:
        """Discover slash commands from commands/ dirs on the filesystem.

        Looks in:
          1. {AGENTFORGE_ROOT}/commands/*/
          2. {AGENTFORGE_ROOT}/agents/shared/commands/*/

        Each command dir must contain task.sh.  Optional config.json may provide:
            {"description": "...", "visible": true}

        Returns a mapping of "/cmd_name" → {"script": "commands/cmd_name/task.sh",
                                             "description": "...", "source": "fs"}.
        """
        commands: dict[str, dict] = {}
        search_dirs = [
            Path(AGENTFORGE_ROOT) / "commands",
            Path(AGENTFORGE_ROOT) / "agents" / "shared" / "commands",
        ]
        for base in search_dirs:
            if not base.is_dir():
                continue
            for cmd_dir in sorted(base.iterdir()):
                if not cmd_dir.is_dir():
                    continue
                task_sh = cmd_dir / "task.sh"
                if not task_sh.exists():
                    continue
                # Telegram commands must be [a-z0-9_] only — convert hyphens to underscores
                cmd_name = "/" + cmd_dir.name.lower().replace("-", "_")
                cfg_path = cmd_dir / "config.json"
                description = ""
                visible = True
                if cfg_path.exists():
                    try:
                        cfg = load_command_config(cfg_path)
                        description = cfg.description
                        visible = cfg.visible
                    except ValidationError as exc:
                        logging.warning(f"Skipping invalid command config {cfg_path}: {exc}")
                        continue
                    except Exception as exc:
                        logging.warning(f"Skipping unreadable command config {cfg_path}: {exc}")
                        continue
                if not visible:
                    continue
                # Relative path from AGENTFORGE_ROOT for the script key
                try:
                    rel = str(task_sh.relative_to(AGENTFORGE_ROOT))
                except ValueError:
                    rel = str(task_sh)
                commands[cmd_name] = {
                    "script": rel,
                    "description": description,
                    "source": "fs",
                }
        return commands

    def _build_api_bases(self):
        """Build per-thread and per-agent API base URLs for multi-bot tokens."""
        self.thread_api_bases: dict[str, str] = {}
        self.agent_api_bases: dict[str, str] = {}
        for tid, tcfg in self.config.get("threads", {}).items():
            if tid == "default":
                continue
            env_var = tcfg.get("token_env_var")
            if env_var:
                agent_token = os.environ.get(env_var, "")
                if agent_token:
                    self.thread_api_bases[tid] = f"https://api.telegram.org/bot{agent_token}"
                    name = tcfg.get("name")
                    if name:
                        self.agent_api_bases[name] = f"https://api.telegram.org/bot{agent_token}"

    # Built-in commands registered automatically on every instance.
    # These appear in the Telegram autocomplete menu alongside any instance-local commands.
    BUILTIN_COMMANDS = {
        "/status": "État du système (bot, CPU/disk, crons, cc-usage)",
    }

    @staticmethod
    def _format_cron_line(line: str) -> str:
        """Convert a raw crontab line into a human-readable summary.

        Input:  '55 9 * * * export HOME=... && /path/to/morning_brief.sh >> ...'
        Output: 'morning_brief — daily 09:55'
        """
        import re as _re
        parts = line.split()
        if len(parts) < 6:
            return line

        minute, hour, dom, month, dow = parts[:5]

        # Extract script name from the command (last *.sh before '>>')
        cmd = " ".join(parts[5:])
        script_match = _re.search(r'(\w+)\.sh', cmd)
        name = script_match.group(1).replace("_", " ") if script_match else cmd[:30]

        # Build human-readable schedule
        if dom == "*" and month == "*":
            if dow == "*":
                schedule = "daily"
            elif dow == "0":
                schedule = "Sun"
            elif dow == "1":
                schedule = "Mon"
            elif dow == "2":
                schedule = "Tue"
            elif dow == "3":
                schedule = "Wed"
            elif dow == "4":
                schedule = "Thu"
            elif dow == "5":
                schedule = "Fri"
            elif dow == "6":
                schedule = "Sat"
            else:
                schedule = f"dow={dow}"
        else:
            schedule = f"{dom}/{month}"

        try:
            time_str = f"{int(hour):02d}:{int(minute):02d}"
        except ValueError:
            time_str = f"{hour}:{minute}"

        return f"{name} — {schedule} {time_str}"

    def _builtin_status(self) -> str:
        """Return a status report: bot uptime, CPU/disk, cron schedule, and cc usage."""
        lines = []

        # --- Bot uptime ---
        try:
            uptime_proc = subprocess.run(
                ["systemctl", "--user", "show", "agentforge.service",
                 "--property=ActiveEnterTimestamp", "--value"],
                capture_output=True, text=True, timeout=5,
            )
            ts = uptime_proc.stdout.strip()
            if ts and ts != "n/a":
                from datetime import timezone
                start = datetime.strptime(ts, "%a %Y-%m-%d %H:%M:%S %Z").replace(tzinfo=timezone.utc)
                delta = datetime.now(timezone.utc) - start
                h, rem = divmod(int(delta.total_seconds()), 3600)
                m = rem // 60
                lines.append(f"🤖 Bot uptime: {h}h{m:02d}m")
            else:
                lines.append("🤖 Bot: running (uptime unknown)")
        except Exception:
            lines.append("🤖 Bot: running")

        # --- CPU & disk ---
        try:
            cpu_proc = subprocess.run(
                ["top", "-bn1"],
                capture_output=True, text=True, timeout=5,
            )
            for line in cpu_proc.stdout.splitlines():
                if "Cpu(s)" in line or "%Cpu" in line:
                    # Extract idle % → compute used %
                    import re
                    m = re.search(r"(\d+[\.,]\d+)\s*id", line)
                    if m:
                        idle = float(m.group(1).replace(",", "."))
                        used = round(100 - idle, 1)
                        lines.append(f"🖥  CPU: {used}% used")
                    break
        except Exception:
            pass

        try:
            df_proc = subprocess.run(
                ["df", "-h", AGENTFORGE_ROOT],
                capture_output=True, text=True, timeout=5,
            )
            df_lines = df_proc.stdout.strip().splitlines()
            if len(df_lines) >= 2:
                parts = df_lines[1].split()
                if len(parts) >= 5:
                    lines.append(f"💾 Disk: {parts[2]} used / {parts[1]} ({parts[4]})")
        except Exception:
            pass

        # --- Cron schedule ---
        try:
            cron_proc = subprocess.run(
                ["crontab", "-l"],
                capture_output=True, text=True, timeout=5,
            )
            cron_lines = [
                l for l in cron_proc.stdout.splitlines()
                if l.strip() and not l.startswith("#")
            ]
            if cron_lines:
                lines.append("\n⏰ Crons:")
                for cl in cron_lines:
                    lines.append(f"  {self._format_cron_line(cl)}")
        except Exception:
            pass

        try:
            self._append_claude_usage_summary(lines)
        except Exception as e:
            logging.debug(f"Usage summary failed: {e}")

        return "\n".join(lines) if lines else "✅ Système opérationnel."

    def _append_claude_usage_summary(self, lines: list[str]) -> None:
        try:
            payload = get_claude_oauth_usage(root=AGENTFORGE_ROOT)
        except ClaudeUsageError as exc:
            logging.debug(f"Real Claude usage unavailable, falling back to local estimate: {exc}")
            self._append_estimated_claude_usage(lines)
            return

        self._append_real_claude_usage(lines, payload)

    def _append_real_claude_usage(self, lines: list[str], payload: dict) -> None:
        now = datetime.now(ZoneInfo("America/Toronto"))
        lines.append("\n📊 Claude Code (données réelles)")

        for key, label in (
            ("five_hour", "Session 5h :"),
            ("seven_day", "Semaine :"),
            ("seven_day_opus", "Opus semaine :"),
            ("seven_day_sonnet", "Sonnet semaine :"),
        ):
            window = payload.get(key)
            if not isinstance(window, dict):
                continue

            utilization = float(window.get("utilization", 0.0))
            reset_at = parse_usage_reset(window.get("resets_at"))
            reset_label = self._format_usage_reset_label(reset_at, now)
            filled = max(0, min(10, round(utilization / 10)))
            bar = "▓" * filled + "░" * (10 - filled)
            lines.append(f"{label} (reset {reset_label})")
            lines.append(f"  {bar} {utilization:.0f}%")
            lines.append("")

        if lines[-1] == "":
            lines.pop()

    def _format_usage_reset_label(
        self,
        reset_at: datetime | None,
        now: datetime,
    ) -> str:
        if reset_at is None:
            return "inconnu"

        local = reset_at.astimezone(ZoneInfo("America/Toronto"))
        delta = local - now
        if 0 < delta.total_seconds() <= 12 * 3600:
            total_minutes = int(delta.total_seconds() // 60)
            hours, minutes = divmod(total_minutes, 60)
            return f"dans {hours}h{minutes:02d}"

        day_names_fr = ["lun", "mar", "mer", "jeu", "ven", "sam", "dim"]
        return f"{day_names_fr[local.weekday()]} {local.strftime('%Hh%M')}"

    def _append_estimated_claude_usage(self, lines: list[str]) -> None:
        from datetime import datetime as _dt, timedelta as _td

        _day_names_fr = ["lun", "mar", "mer", "jeu", "ven", "sam", "dim"]

        def _bar_block(label: str, cost: float, budget: float,
                       reset_str: str, fraction: float) -> list[str]:
            actual_pct = (cost / budget * 100) if budget else 0.0
            expected_pct = fraction * 100
            delta_pct = actual_pct - expected_pct
            filled = max(0, min(10, round(actual_pct / 10)))
            bar = "▓" * filled + "░" * (10 - filled)
            block = [
                f"{label} (reset {reset_str})",
                f"  {bar} {actual_pct:.0f}%",
                f"             ↑ {expected_pct:.0f}% attendu",
            ]
            if delta_pct > 0:
                block.append(f"  → +{delta_pct:.0f}% d'avance sur le rythme")
            elif delta_pct < 0:
                block.append(f"  → {delta_pct:.0f}% sous le rythme")
            else:
                block.append("  → dans le rythme")
            return block

        now = _dt.now()
        claude_cfg = self.config.get("claude", {})

        cost_5h, oldest_5h = self.store.get_window_cost(hours=5)
        budget_5h = float(claude_cfg.get("window_5h_budget_usd", 5.0))
        if oldest_5h:
            oldest_5h_dt = _dt.strptime(oldest_5h, "%Y-%m-%d %H:%M:%S")
            reset_5h_dt = oldest_5h_dt + _td(hours=5)
            reset_5h_str = f"à {reset_5h_dt.strftime('%Hh%M')}"
            elapsed_5h = (now - oldest_5h_dt).total_seconds()
            fraction_5h = min(elapsed_5h / (5 * 3600), 1.0)
        else:
            reset_5h_str = "dans 5h00"
            fraction_5h = 0.0

        cost_7d, oldest_7d = self.store.get_window_cost(hours=168)
        budget_7d = float(claude_cfg.get("weekly_budget_usd", 20.0))
        if oldest_7d:
            oldest_7d_dt = _dt.strptime(oldest_7d, "%Y-%m-%d %H:%M:%S")
            reset_7d_dt = oldest_7d_dt + _td(hours=168)
            reset_day_fr = _day_names_fr[reset_7d_dt.weekday()]
            reset_7d_str = f"{reset_day_fr} à {reset_7d_dt.strftime('%Hh%M')}"
            elapsed_7d = (now - oldest_7d_dt).total_seconds()
            fraction_7d = min(elapsed_7d / (168 * 3600), 1.0)
        else:
            reset_7d_str = "dans 7j"
            fraction_7d = 0.0

        lines.append("\n📊 Claude Code (estimation locale)")
        lines.extend(_bar_block("Fenêtre 5h :", cost_5h, budget_5h, reset_5h_str, fraction_5h))
        lines.append("")
        lines.extend(_bar_block("Fenêtre semaine :", cost_7d, budget_7d, reset_7d_str, fraction_7d))

    def _dispatch_builtin(self, cmd_key: str) -> str | None:
        """Handle built-in slash commands. Returns output string or None."""
        if cmd_key == "/status":
            return self._builtin_status()
        return None

    def _register_commands(self):
        """Register slash commands with Telegram via setMyCommands API.

        Merges built-in commands with instance-local commands from config.json,
        then pushes the list to Telegram so the native autocomplete menu works.

            "commands": {
                "/brief": {"script": "commands/brief.sh", "description": "Morning brief immédiat"},
                ...
            }
        """
        tg_commands = []

        # 1. Built-in commands (always registered)
        for cmd, description in self.BUILTIN_COMMANDS.items():
            tg_commands.append({"command": cmd.lstrip("/"), "description": description})

        # 2. Filesystem commands (commands/ and agents/shared/commands/)
        fs_commands = self._discover_filesystem_commands()
        for cmd, cfg in fs_commands.items():
            description = cfg.get("description", "")
            if description:
                tg_commands.append({"command": cmd.lstrip("/"), "description": description})

        # 3. Instance-local commands from config.json (legacy / override)
        commands_cfg = self.config.get("commands", {})
        for cmd, cfg in commands_cfg.items():
            if not cmd.startswith("/"):
                continue
            description = cfg.get("description", "")
            if description:
                # Only add if not already registered from filesystem
                if not any(c["command"] == cmd.lstrip("/") for c in tg_commands):
                    tg_commands.append({"command": cmd.lstrip("/"), "description": description})

        if not tg_commands:
            return

        # Register commands for multiple scopes:
        # - default (private chats, no scope param)
        # - all_group_chats (covers supergroups where the bot lives)
        # - per-chat for each explicitly allowed chat (most reliable for supergroups)
        scopes: list[dict] = [
            {},  # default scope — private chats
            {"scope": {"type": "all_group_chats"}},
        ]
        allowed_chat_ids = self.config.get("telegram", {}).get("allowed_chat_ids", [])
        for cid in allowed_chat_ids:
            scopes.append({"scope": {"type": "chat", "chat_id": int(cid)}})

        registered = 0
        for extra in scopes:
            try:
                payload = {"commands": tg_commands, **extra}
                result = http_post_json(f"{self.api_base}/setMyCommands", payload)
                if result.get("ok"):
                    registered += 1
                else:
                    scope_label = extra.get("scope", {}).get("type", "default")
                    logging.warning(
                        f"setMyCommands({scope_label}) failed: {result.get('description', result)}"
                    )
            except Exception as e:
                logging.warning(f"Could not register slash commands: {e}")

        if registered:
            logging.info(
                f"Registered {len(tg_commands)} slash command(s) across {registered}/{len(scopes)} scope(s)."
            )

    def _dispatch_command(self, text: str, chat_id: str, thread_id) -> str | None:
        """If text is a slash command, execute it and return output.

        Checks built-in commands first, then instance-local scripts from config.json.
        Returns the output string, or None if the text is not a known command.
        """
        if not text.startswith("/"):
            return None

        # Parse command name and optional args ("/brief" or "/search foo bar")
        parts = text.split(None, 1)
        cmd_key = parts[0].lower()
        cmd_args = parts[1] if len(parts) > 1 else ""

        if cmd_key in {"/search", "/deepsearch"}:
            return self._start_search_job(cmd_key, cmd_args, chat_id, thread_id)

        # 1. Built-in commands
        builtin_result = self._dispatch_builtin(cmd_key)
        if builtin_result is not None:
            return builtin_result

        # 2. Filesystem commands (commands/ and agents/shared/commands/)
        all_commands = self._discover_filesystem_commands()
        # 3. Merge with instance-local commands from config.json
        for k, v in self.config.get("commands", {}).items():
            if k not in all_commands:
                all_commands[k] = v

        cfg = all_commands.get(cmd_key)
        if cfg is None:
            return None

        script_rel = cfg.get("script")
        if not script_rel:
            return None

        script_path = Path(AGENTFORGE_ROOT) / script_rel
        if not script_path.exists():
            return f"⚠️ Script introuvable : `{script_rel}`"

        try:
            env = os.environ.copy()
            env["AGENTFORGE_ROOT"] = AGENTFORGE_ROOT
            if AGENT_DIR:
                env["AGENT_DIR"] = AGENT_DIR
                env["AGENT_NAME"] = self.bot_name
            env["CMD_ARGS"] = cmd_args
            proc = subprocess.run(
                [str(script_path)] + (cmd_args.split() if cmd_args else []),
                capture_output=True,
                text=True,
                timeout=60,
                env=env,
            )
            output = (proc.stdout + proc.stderr).strip()
            if not output:
                return f"✅ `{cmd_key}` exécuté (pas de sortie)."
            # Detect JSON output with inline keyboard
            if output.startswith("{"):
                try:
                    parsed = json.loads(output)
                    if isinstance(parsed, dict) and "text" in parsed:
                        return parsed
                except (json.JSONDecodeError, ValueError):
                    pass
            return output
        except subprocess.TimeoutExpired:
            return f"⏱ `{cmd_key}` timeout après 60s."
        except Exception as e:
            return f"❌ Erreur lors de l'exécution de `{cmd_key}` : {e}"

    def _start_search_job(self, cmd_key: str, query: str, chat_id: str, thread_id) -> str:
        query = (query or "").strip()
        if not query:
            return f"Usage: `{cmd_key} <query>`"

        depth = "deep" if cmd_key == "/deepsearch" else "quick"
        thread_cfg = get_thread_config(thread_id, self.config)
        agent_name = thread_cfg.get("name", self.bot_name)
        ack = f"🔍 Recherche en cours sur : {query}"

        def run_job() -> None:
            try:
                from agentforge.search.models import SearchRequest
                from agentforge.search.pipeline import run_search

                request = SearchRequest(
                    query=query,
                    sources=["brave"],
                    depth=depth,
                    max_results_per_source=15 if depth == "deep" else 8,
                )
                report, report_path = run_search(
                    request=request,
                    root=AGENTFORGE_ROOT,
                    config=self.config,
                    thread_cfg=thread_cfg,
                    mode="recherche",
                )
                summary = report.summary.strip()
                completion = (
                    f"✅ Recherche terminée: {query}\n\n"
                    f"{summary}\n\n"
                    f"Rapport: {report_path}"
                )
                self._send_message(chat_id, completion, thread_id, agent_name=agent_name)
            except Exception as exc:
                self._send_message(
                    chat_id,
                    f"❌ Recherche échouée: {exc}",
                    thread_id,
                    agent_name=agent_name,
                )

        threading.Thread(target=run_job, daemon=True).start()
        return ack

    def _load_offset(self) -> int:
        state_path = (Path(AGENT_DIR) / "data" / "state.json") if AGENT_DIR else (Path(AGENTFORGE_ROOT) / "data" / "state.json")
        if state_path.exists():
            state = json.loads(state_path.read_text())
            return state.get("telegram_offset", 0)
        return 0

    def _save_offset(self):
        state_path = (Path(AGENT_DIR) / "data" / "state.json") if AGENT_DIR else (Path(AGENTFORGE_ROOT) / "data" / "state.json")
        state_path.parent.mkdir(parents=True, exist_ok=True)
        state = {}
        if state_path.exists():
            state = json.loads(state_path.read_text())
        state["telegram_offset"] = self.offset
        state_path.write_text(json.dumps(state, indent=2))

    def _init_db(self) -> sqlite3.Connection:
        db_path = self.config["memory"]["db_path"]
        self.store = ConversationStore(db_path)
        return self.store.connection

    # ------------------------------------------------------------------
    # Main polling loop
    # ------------------------------------------------------------------

    def poll(self):
        logging.info("AgentForge Telegram adapter started — polling...")
        self._notify_startup()
        while self.running:
            try:
                self._refresh_runtime_config()
                updates = self._get_updates()
                for update in updates:
                    self._handle_update(update)
                if time.time() - self._last_retry_check > 60:
                    self._process_pending_retries()
                    self._last_retry_check = time.time()
                self._process_agent_tasks()
            except KeyboardInterrupt:
                break
            except Exception as e:
                logging.error(f"Poll error: {e}", exc_info=True)
                time.sleep(5)
            time.sleep(self.config["telegram"]["poll_interval_seconds"])

    def _refresh_runtime_config(self) -> None:
        config, changed = self._config_store.reload_if_needed()
        if not changed:
            return

        self.config = config
        self._build_api_bases()
        self._register_commands()
        logging.info(f"Hot-reloaded runtime config from {self._config_path}")

    def _notify_startup(self):
        try:
            from importlib.metadata import version as pkg_version
            try:
                v = pkg_version("agent-forge-installer")
            except Exception:
                v = "unknown"
            private_chat_id = str(self.config["telegram"]["private_chat_id"])
            msg = f"{random.choice(STARTUP_MESSAGES)} _(v{v})_"
            self._send_message(private_chat_id, msg)
        except Exception as e:
            logging.warning(f"Startup notification failed: {e}")

    def _get_updates(self) -> list:
        try:
            data = http_get(
                f"{self.api_base}/getUpdates",
                params={
                    "offset": self.offset,
                    "timeout": 30,
                    "allowed_updates": json.dumps(["message", "callback_query"]),
                },
                timeout=35,
            )
            if not data.get("ok"):
                logging.error(f"Telegram API error: {data}")
                return []
            return data.get("result", [])
        except Exception as e:
            logging.error(f"Failed to get updates: {e}")
            return []

    # ------------------------------------------------------------------
    # Message handling
    # ------------------------------------------------------------------

    def _handle_update(self, update):
        self.offset = update["update_id"] + 1
        self._save_offset()

        # Handle inline button callbacks
        if update.get("callback_query"):
            self._handle_callback_query(update["callback_query"])
            return

        msg = update.get("message")
        if not msg:
            return

        chat_id = str(msg["chat"]["id"])
        allowed = self.config["telegram"].get("allowed_chat_ids", [])
        if allowed and chat_id not in [str(c) for c in allowed]:
            logging.warning(f"Ignoring message from unauthorized chat {chat_id}")
            return

        allow_bot_messages = self.config.get("telegram", {}).get("allow_bot_messages", False)
        if msg.get("from", {}).get("is_bot") and not allow_bot_messages:
            return

        message_id = str(msg["message_id"])
        thread_id = msg.get("message_thread_id")

        # Topic routing: only respond if this agent is the default for this thread,
        # or if the agent is explicitly @mentioned in the message.
        if not self._should_respond_to_thread(msg, thread_id):
            return
        session_id = f"tg-{chat_id}-t{thread_id}" if thread_id else f"tg-{chat_id}"
        user_name = msg.get("from", {}).get("first_name", "User")
        thread_cfg = get_thread_config(thread_id, self.config)

        # Determine message content
        user_text = self._extract_message_text(msg, chat_id, thread_id)
        if user_text is None:
            return

        # Prepend reply context if replying to a message
        reply_to = msg.get("reply_to_message")
        if reply_to and reply_to.get("text"):
            user_text = f"[En réponse à : « {reply_to['text']} »]\n\n{user_text}"

        # Project topic routing
        project_cfg = get_project_topic_config(thread_id, self.config)
        if project_cfg:
            target_agent, user_text = parse_mention(user_text, project_cfg)
            thread_cfg = get_agent_thread_config(target_agent, self.config)
            thread_cfg["context_messages"] = 20
            thread_cfg["topic_context"] = build_topic_context(project_cfg, target_agent)

        logging.info(
            f"[{session_id}] thread={thread_id} model={thread_cfg.get('model')} "
            f"{user_name}: {user_text[:100]}"
        )

        agent_name = thread_cfg.get("name", self.bot_name) or self.bot_name
        allowed_rate, reason = self.rate_limiter.allow(chat_id, agent_name)
        if not allowed_rate:
            self._send_message(chat_id, f"⏱ {reason}", thread_id, agent_name=agent_name)
            return

        # Slash command dispatch — intercept before sending to Claude
        command_response = self._dispatch_command(user_text, chat_id, thread_id)
        if command_response is not None:
            response_text = command_response["text"] if isinstance(command_response, dict) else command_response
            is_error = isinstance(response_text, str) and any(
                response_text.startswith(p) for p in ("⚠️", "❌", "⏱")
            )

            self._set_reaction(chat_id, message_id, "⚠️" if is_error else "✅", thread_id, agent_name)
            if isinstance(command_response, dict):
                self._send_message(
                    chat_id,
                    command_response["text"],
                    thread_id,
                    agent_name=agent_name,
                    reply_markup=command_response.get("reply_markup"),
                )
            else:
                self._send_message(chat_id, command_response, thread_id, agent_name=agent_name)

            if is_error:
                # Save the command and error to conversation history so Claude
                # has context if the user follows up immediately.
                self._save_message(
                    session_id, "user", user_text,
                    chat_id, message_id,
                    thread_id=thread_id, agent_name=agent_name,
                )
                self._save_message(
                    session_id, "assistant", response_text,
                    chat_id, None,
                    thread_id=thread_id, agent_name=agent_name,
                )
                # Auto-relaunch Claude with the error as context so it can
                # react immediately (suggest a fix, explain the issue, etc.)
                error_prompt = (
                    f"La commande slash `{user_text}` a échoué avec l'erreur suivante :\n"
                    f"{response_text}\n\n"
                    f"Analyse l'erreur et propose une solution ou explique le problème."
                )
                self._enqueue_task({
                    "session_id": session_id,
                    "user_text": error_prompt,
                    "thread_cfg": thread_cfg,
                    "chat_id": chat_id,
                    "thread_id": thread_id,
                })
            return

        self._save_message(
            session_id,
            "user",
            user_text,
            chat_id,
            message_id,
            thread_id=thread_id,
            agent_name=thread_cfg.get("name", self.bot_name),
        )
        self._enqueue_task({
            "session_id": session_id,
            "user_text": user_text,
            "thread_cfg": thread_cfg,
            "chat_id": chat_id,
            "thread_id": thread_id,
        })

    def _should_respond_to_thread(self, msg, thread_id) -> bool:
        """Return True if this agent should respond to the given message.

        Rules (in order):
        1. Private chat → always respond.
        2. Agent is @mentioned in the message → respond.
        3. This thread is in the agent's default_for_threads list → respond.
        4. default_for_threads not configured → respond to everything (backward compat).
        5. Otherwise → ignore.
        """
        if msg.get("chat", {}).get("type") == "private":
            return True
        if self._is_mentioned(msg):
            return True
        default_threads = self.config.get("telegram", {}).get("default_for_threads")
        if default_threads is None:
            return True  # Not configured → respond to everything
        return thread_id in default_threads

    def _is_mentioned(self, msg) -> bool:
        """Return True if this agent's name is @mentioned in the message."""
        import re
        text = msg.get("text", "") or ""
        agent_name = getattr(self, "bot_name", "") or self.config.get("bot_name", "")
        if not agent_name:
            return False
        return bool(re.search(rf"@{re.escape(agent_name)}\b", text, re.IGNORECASE))

    def _extract_message_text(self, msg, chat_id, thread_id) -> str | None:
        """Extract text content from a Telegram message. Returns None for unsupported types."""
        if msg.get("text"):
            return msg["text"]
        elif msg.get("voice"):
            text = transcribe_voice_note(msg["voice"], self.api_base, self.token)
            if text is None:
                self._send_message(
                    chat_id,
                    "🎤 Transcription non disponible ou audio incompréhensible.",
                    thread_id,
                )
                return None
            self._send_message(chat_id, f"🎤 _{text}_", thread_id)
            return text
        elif msg.get("photo"):
            self._send_message(chat_id, "📷 Je ne supporte pas encore les images.", thread_id)
            return None
        elif msg.get("document") or msg.get("video") or msg.get("sticker"):
            self._send_message(chat_id, "📎 Je ne supporte pas encore ce type de fichier.", thread_id)
            return None
        return None

    # ------------------------------------------------------------------
    # Worker queue system
    # ------------------------------------------------------------------

    def _ensure_agent_worker(self, agent_name: str):
        if agent_name not in self.agent_queues:
            q: queue.Queue = queue.Queue()
            self.agent_queues[agent_name] = q
            t = threading.Thread(target=self._worker, args=(agent_name, q), daemon=True)
            t.start()
            self.agent_workers[agent_name] = t
            logging.info(f"Started worker for agent: {agent_name}")

    def _enqueue_task(self, task: dict):
        agent_name = task.get("thread_cfg", {}).get("name", self.bot_name) or self.bot_name
        self._ensure_agent_worker(agent_name)
        self.agent_queues[agent_name].put(task)
        logging.info(
            f"[{task.get('session_id', '?')}] Enqueued for agent={agent_name} "
            f"(queue size={self.agent_queues[agent_name].qsize()})"
        )

    def _worker(self, agent_name: str, task_queue: queue.Queue):
        """Dispatch loop — spawns one thread per task for parallel execution."""
        logging.info(f"Worker thread started for agent: {agent_name}.")
        while True:
            try:
                task = task_queue.get()
            except Exception:
                continue
            if task is None:
                logging.info(f"Worker {agent_name} received shutdown sentinel — exiting.")
                task_queue.task_done()
                break
            t = threading.Thread(
                target=self._invoke_and_respond,
                args=(task, task_queue),
                daemon=True,
            )
            t.start()

    def _invoke_and_respond(self, task: dict, task_queue: queue.Queue):
        """Run a single Claude invocation and send the response."""
        session_id = task["session_id"]
        user_text = task["user_text"]
        thread_cfg = task["thread_cfg"]
        chat_id = task["chat_id"]
        thread_id = task["thread_id"]
        worker_agent = thread_cfg.get("name", self.bot_name) or self.bot_name
        is_agent_task = bool(task.get("is_agent_task"))
        policy = self.approval_gates.evaluate_command(user_text)
        autonomy_level = self._resolve_autonomy_level(thread_cfg)

        if policy.status == "blocked":
            self.approval_gates.record_auto_decision(
                status="blocked",
                actor_label=worker_agent,
                chat_id=chat_id,
                thread_id=thread_id,
                command_text=user_text,
                reason=policy.reason,
            )
            self._send_message(
                chat_id,
                (
                    "⛔ Command blocked by safety policy before execution.\n"
                    f"Rule: `{policy.reason}`"
                ),
                thread_id,
                agent_name=worker_agent,
            )
            task_queue.task_done()
            return

        if policy.status == "approval_required":
            if is_agent_task and autonomy_level >= 3:
                self.approval_gates.record_auto_decision(
                    status="auto_approved",
                    actor_label=worker_agent,
                    chat_id=chat_id,
                    thread_id=thread_id,
                    command_text=user_text,
                    reason=f"autonomy_{autonomy_level}",
                )
            else:
                decision = self.approval_gates.request_and_wait(
                    chat_id=chat_id,
                    thread_id=thread_id,
                    command_text=user_text,
                    actor_label=worker_agent,
                    send_message_fn=lambda cid, text, tid, reply_markup=None: self._send_message(
                        cid,
                        text,
                        tid,
                        agent_name=worker_agent,
                        reply_markup=reply_markup,
                    ),
                )
                if decision.status != "approved":
                    reason = "timed out" if decision.status == "timeout" else "denied"
                    self._send_message(
                        chat_id,
                        f"⏸ Operation {reason}; execution skipped.",
                        thread_id,
                        agent_name=worker_agent,
                    )
                    task_queue.task_done()
                    return
        self.rate_limiter.session_start(worker_agent)

        stop_typing = self._start_typing_loop(chat_id, thread_id, agent_name=worker_agent)

        result_holder: list[InvokeResult | None] = [None]
        error_holder: list[Exception | None] = [None]
        done_event = threading.Event()

        def run_claude():
            try:
                limit = thread_cfg.get("context_messages", self.config.get("memory", {}).get("context_messages", self.config.get("context", {}).get("messages", 10)))
                hours = thread_cfg.get("context_hours")
                recent = self._get_recent_messages(session_id, limit, hours=hours)
                result_holder[0] = invoke_claude(
                    session_id=session_id,
                    user_text=user_text,
                    thread_cfg=thread_cfg,
                    config=self.config,
                    recent_messages=recent,
                    root=AGENTFORGE_ROOT,
                )
            except Exception as e:
                error_holder[0] = e
            finally:
                done_event.set()

        claude_thread = threading.Thread(target=run_claude, daemon=True)
        claude_thread.start()
        done_event.wait()
        stop_typing.set()
        self.rate_limiter.session_end(worker_agent)

        if error_holder[0] is not None:
            self._handle_worker_error(error_holder[0], task, chat_id, thread_id, worker_agent, task_queue)
            return

        invoke_result: InvokeResult = result_holder[0]
        response = invoke_result.text
        self._save_message(
            session_id, "assistant", response,
            chat_id, None,
            thread_id=thread_id, agent_name=worker_agent,
        )
        self._save_usage(invoke_result, worker_agent)
        self._send_message(chat_id, response, thread_id, agent_name=worker_agent)
        self._log_action(worker_agent, "telegram_send", "telegram", response[:100].replace("\n", " "))
        logging.info(f"[{session_id}] Invoke complete: {response[:100]}")
        task_queue.task_done()

    def _handle_worker_error(self, error, task, chat_id, thread_id, agent_name, task_queue):
        """Handle errors from Claude invocation in worker."""
        if isinstance(error, ClaudeCodeLimitError):
            message = format_claude_code_limit_user_message(error.restore_at)
            self._send_message(chat_id, message, thread_id, agent_name=agent_name)
        elif isinstance(error, RateLimitError):
            retry_attempt = task.get("_retry_attempt", 0)
            if retry_attempt >= 3:
                message = "⚠️ Rate limit persistant après 3 tentatives. Réessaie manuellement."
            else:
                self._save_pending_retry(task, error.retry_after_seconds)
                message = "⏸ Rate limit Anthropic atteint. Réessaie plus tard."
            self._send_message(chat_id, message, thread_id, agent_name=agent_name)
        else:
            message = "Sorry, I encountered an error. Please try again."
            self._send_message(chat_id, message, thread_id, agent_name=agent_name)
        task_queue.task_done()

    # ------------------------------------------------------------------
    # Telegram helpers
    # ------------------------------------------------------------------

    def _get_api_base(self, thread_id=None, agent_name=None) -> str:
        if agent_name and agent_name in self.agent_api_bases:
            return self.agent_api_bases[agent_name]
        if thread_id:
            return self.thread_api_bases.get(str(thread_id), self.api_base)
        return self.api_base

    def _send_typing(self, chat_id, thread_id=None, agent_name=None):
        try:
            payload = {"chat_id": chat_id, "action": "typing"}
            if thread_id:
                payload["message_thread_id"] = thread_id
            http_post_json(f"{self._get_api_base(thread_id, agent_name)}/sendChatAction", payload)
        except Exception:
            pass

    def _start_typing_loop(self, chat_id, thread_id, agent_name=None) -> threading.Event:
        stop_event = threading.Event()

        def loop():
            while not stop_event.wait(5):
                self._send_typing(chat_id, thread_id, agent_name)

        self._send_typing(chat_id, thread_id, agent_name)
        t = threading.Thread(target=loop, daemon=True)
        t.start()
        return stop_event

    def _send_message(self, chat_id, text, thread_id=None, agent_name=None, reply_markup=None):
        max_len = self.config.get("telegram", {}).get("max_message_length", 4096)
        chunks = [text[i : i + max_len] for i in range(0, len(text), max_len)]
        api_base = self._get_api_base(thread_id, agent_name)
        for i, chunk in enumerate(chunks):
            try:
                payload = {"chat_id": chat_id, "text": chunk}
                if thread_id:
                    payload["message_thread_id"] = thread_id
                # Only attach reply_markup to the last chunk
                if reply_markup and i == len(chunks) - 1:
                    payload["reply_markup"] = reply_markup
                http_post_json(f"{api_base}/sendMessage", payload)
            except Exception as e:
                if api_base != self.api_base:
                    logging.warning(f"Agent token failed ({e}), falling back to main token")
                    try:
                        http_post_json(f"{self.api_base}/sendMessage", payload)
                    except Exception as e2:
                        logging.error(f"Failed to send message (fallback also failed): {e2}")
                else:
                    logging.error(f"Failed to send message: {e}")

    def _handle_callback_query(self, cb: dict):
        """Handle an inline keyboard button press."""
        cb_id = cb.get("id", "")
        data = cb.get("data", "")
        msg = cb.get("message", {})
        chat_id = str(msg.get("chat", {}).get("id", ""))
        thread_id = msg.get("message_thread_id")

        # Answer the callback immediately (removes Telegram's loading spinner)
        try:
            http_post_json(f"{self.api_base}/answerCallbackQuery", {"callback_query_id": cb_id})
        except Exception as e:
            logging.warning(f"answerCallbackQuery failed: {e}")

        if not data or not chat_id:
            return

        allowed = self.config["telegram"].get("allowed_chat_ids", [])
        if allowed and chat_id not in [str(c) for c in allowed]:
            return

        logging.info(f"[callback] chat={chat_id} thread={thread_id} data={data!r}")
        actor_id = str(cb.get("from", {}).get("id", ""))
        gate_result = self.approval_gates.resolve_callback(data, actor_id=actor_id)
        if gate_result is not None:
            if gate_result.status == "handled":
                decision_label = "approved" if gate_result.reason == "approve" else "denied"
                self._send_message(chat_id, f"Decision recorded: {decision_label}.", thread_id)
            elif gate_result.status in {"not_found", "invalid"}:
                self._send_message(chat_id, "Approval request expired or invalid.", thread_id)
            return

        # Route the callback data as a slash command
        response = self._dispatch_command(data, chat_id, thread_id)
        if response is None:
            return

        thread_cfg = get_thread_config(thread_id, self.config)
        agent_name = thread_cfg.get("name", self.bot_name)
        if isinstance(response, dict):
            self._send_message(
                chat_id,
                response["text"],
                thread_id,
                agent_name=agent_name,
                reply_markup=response.get("reply_markup"),
            )
        else:
            self._send_message(chat_id, response, thread_id, agent_name=agent_name)

    def _set_reaction(self, chat_id, message_id, emoji, thread_id=None, agent_name=None):
        try:
            api_base = self._get_api_base(thread_id, agent_name)
            http_post_json(f"{api_base}/setMessageReaction", {
                "chat_id": chat_id,
                "message_id": int(message_id),
                "reaction": [{"type": "emoji", "emoji": emoji}],
            })
        except Exception as e:
            logging.warning(f"Could not set reaction: {e}")

    # ------------------------------------------------------------------
    # Database operations
    # ------------------------------------------------------------------

    def _save_message(
        self,
        session_id,
        role,
        content,
        chat_id=None,
        message_id=None,
        *,
        thread_id=None,
        agent_name=None,
    ):
        metadata = {}
        if thread_id is not None:
            metadata["channel"] = str(thread_id)
        if agent_name:
            metadata["agent"] = agent_name
        self.store.save_message(
            session_id,
            role,
            content,
            source="telegram",
            telegram_chat_id=chat_id,
            telegram_message_id=message_id,
            metadata=metadata or None,
        )

    def _get_recent_messages(self, session_id, limit, hours=None) -> list[tuple[str, str, str]]:
        return self.store.get_recent_messages(session_id, limit, hours=hours)

    # ------------------------------------------------------------------
    # Retry system
    # ------------------------------------------------------------------

    def _save_pending_retry(self, task, retry_after_seconds=3600):
        now = datetime.now(MONTREAL)
        retry_after = (now + timedelta(seconds=retry_after_seconds)).strftime("%Y-%m-%d %H:%M:%S")
        with self.db_lock:
            self.db.execute(
                """
                INSERT INTO pending_retries
                (session_id, user_text, thread_cfg, chat_id, thread_id, created_at, retry_after, attempts)
                VALUES (?, ?, ?, ?, ?, ?, ?, 1)
                """,
                (
                    task["session_id"],
                    task["user_text"],
                    json.dumps(task["thread_cfg"]),
                    task["chat_id"],
                    str(task["thread_id"]) if task["thread_id"] is not None else None,
                    now.strftime("%Y-%m-%d %H:%M:%S"),
                    retry_after,
                ),
            )
            self.db.commit()

    def _process_pending_retries(self):
        now = datetime.now(MONTREAL).strftime("%Y-%m-%d %H:%M:%S")
        with self.db_lock:
            cur = self.db.execute(
                """
                SELECT id, session_id, user_text, thread_cfg, chat_id, thread_id, attempts
                FROM pending_retries WHERE retry_after <= ?
                """,
                (now,),
            )
            rows = cur.fetchall()
        for row in rows:
            rid, session_id, user_text, thread_cfg_json, chat_id, thread_id, attempts = row
            thread_cfg = json.loads(thread_cfg_json)
            thread_id_val = int(thread_id) if thread_id else None
            with self.db_lock:
                self.db.execute("DELETE FROM pending_retries WHERE id = ?", (rid,))
                self.db.commit()
            logging.info(f"[{session_id}] Re-queuing rate-limited message (attempt {attempts + 1})")
            self._send_message(chat_id, "🔄 Rate limit expiré — je reprends ta question…", thread_id_val)
            self._enqueue_task({
                "session_id": session_id,
                "user_text": user_text,
                "thread_cfg": thread_cfg,
                "chat_id": chat_id,
                "thread_id": thread_id_val,
                "_retry_attempt": attempts,
            })

    # ------------------------------------------------------------------
    # Inter-agent tasks
    # ------------------------------------------------------------------

    def _process_agent_tasks(self):
        task_dir = Path(AGENTFORGE_ROOT) / "data" / "agent_tasks"
        if not task_dir.exists():
            return
        for task_file in sorted(task_dir.glob("*.json")):
            try:
                task_data = json.loads(task_file.read_text())
                target = task_data.get("target_agent", "")
                from_agent = task_data.get("from_agent", "system")
                message = task_data.get("message", "")
                hop_count = int(task_data.get("hop_count", 0))
                thread_id = task_data.get("thread_id")
                if not target or not message or not thread_id:
                    logging.warning(f"Skipping malformed agent task file: {task_file}")
                    task_file.unlink(missing_ok=True)
                    continue
                if hop_count >= 5:
                    logging.warning(f"Skipping agent task with excessive hop count: {task_file}")
                    task_file.unlink(missing_ok=True)
                    continue
                task_file.unlink(missing_ok=True)
                chat_id = str(self.config["telegram"]["group_chat_id"])
                session_id = f"tg-{chat_id}-t{thread_id}"
                thread_cfg = get_thread_config(thread_id, self.config)
                user_text = f"[Message de {from_agent}]\n\n{message}"
                logging.info(f"[{session_id}] Agent task from {from_agent} → {target}: {message[:80]}")
                self._save_message(
                    session_id,
                    "user",
                    user_text,
                    chat_id,
                    None,
                    thread_id=thread_id,
                    agent_name=thread_cfg.get("name", self.bot_name),
                )
                self._enqueue_task({
                    "session_id": session_id,
                    "user_text": user_text,
                    "thread_cfg": thread_cfg,
                    "chat_id": chat_id,
                    "thread_id": thread_id,
                    "is_agent_task": True,
                    "from_agent": from_agent,
                    "hop_count": hop_count,
                    "notify_message_id": task_data.get("notify_message_id"),
                })
            except Exception as e:
                logging.error(f"Failed to process agent task {task_file}: {e}")
                try:
                    task_file.unlink(missing_ok=True)
                except Exception:
                    pass

    # ------------------------------------------------------------------
    # Misc
    # ------------------------------------------------------------------

    def _log_action(self, agent, action_type, target, details=""):
        try:
            subprocess.Popen(
                [str(Path(AGENTFORGE_ROOT) / "scripts" / "log_action.sh"), agent, action_type, target, details],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                cwd=AGENTFORGE_ROOT,
                env={
                    **os.environ,
                    "HOME": AGENTFORGE_ROOT,
                    "PATH": f"{AGENTFORGE_ROOT}/.local/bin:" + os.environ.get("PATH", "/usr/bin:/bin"),
                },
            )
        except Exception as e:
            logging.warning(f"log_action failed: {e}")

    def _save_usage(self, result: InvokeResult, agent_name: str) -> None:
        if result.cost_usd is None and result.input_tokens is None:
            return
        try:
            self.store.save_usage(
                agent_name=agent_name,
                model=result.model or "unknown",
                input_tokens=result.input_tokens or 0,
                output_tokens=result.output_tokens or 0,
                cache_write_tokens=result.cache_write_tokens or 0,
                cache_read_tokens=result.cache_read_tokens or 0,
                cost_usd=result.cost_usd or 0.0,
            )
        except Exception as e:
            logging.warning(f"Failed to save usage: {e}")

    def _shutdown(self, signum, frame):
        logging.info("Shutting down gracefully...")
        self.running = False

    def _resolve_autonomy_level(self, thread_cfg: dict) -> int:
        raw = (
            thread_cfg.get("autonomy_level")
            or thread_cfg.get("autonomy")
            or self.config.get("autonomy_level")
            or self.config.get("context", {}).get("autonomy_level")
            or 2
        )
        try:
            level = int(raw)
        except (TypeError, ValueError):
            level = 2
        return max(0, min(4, level))


if __name__ == "__main__":
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        handlers=[
            logging.FileHandler(str(Path(AGENTFORGE_ROOT) / "logs" / "telegram.log")),
            logging.StreamHandler(),
        ],
    )
    bot = ClawdiaBot()
    bot.poll()
