# AgentForge — Operational Guide

This file is the first thing injected into your context on every invocation. Keep it lean.

## Your Environment

- `$AGENTFORGE_ROOT` — root of the AgentForge installation (e.g. `/home/agentforge/AgentForge/`)
- `$AGENT_NAME` — your name (e.g. `archie`, `clawdia`, `architect`)
- `$AGENT_DIR` — your personal directory (e.g. `$AGENTFORGE_ROOT/agents/archie/`)

## Writing to Your Files

**Memory** (durable facts, persist across restarts):
```
$AGENT_DIR/memory.md
```

**Daily log** (today's notes, ephemeral):
```
$AGENT_DIR/daily/YYYY-MM-DD.md
```
Append, don't overwrite. Format: `[HH:MM] Note content`.

**Logs** (actions, errors):
```
$AGENT_DIR/logs/
```

## Scripts Available

All scripts are in `$AGENTFORGE_ROOT/scripts/`. Call them with the full path.

| Script | Usage |
|---|---|
| `telegram_send.sh <agent> "<message>"` | Send Telegram message to the user of `<agent>` |
| `log_action.sh <agent> <type> <target> [details]` | Log an action |
| `agent_task.sh <agent> "<task>"` | Create a task for another agent |
| `healthcheck.sh` | Run system health check |

Example:
```bash
$AGENTFORGE_ROOT/scripts/telegram_send.sh "$AGENT_NAME" "Hello from $AGENT_NAME"
```

## Shared Context

- **Shared rules** (instance-specific, read for context): `$AGENTFORGE_ROOT/agents/shared/CLAUDE.md`
- **Shared facts** (timezone, user prefs, etc.): `$AGENTFORGE_ROOT/agents/shared/memory.md`
- **Obsidian vault**: `$AGENTFORGE_ROOT/vault/`

## Architecture Notes

- The Architect (`agents/architect/`) administers the system. For infra questions, read `agents/architect/memory.md`.
- Each agent has its own Telegram bot token, context, and cron tasks.
- The heartbeat cron runs every minute and dispatches scheduled tasks based on each agent's `cron/` config.

## Parallel Invocations

Multiple messages may be processed simultaneously. If the recent conversation history shows a user message with no assistant response immediately before the current message, that message is being handled in a parallel invocation — its response is not yet available. **Answer the current message independently** without waiting for or referencing the missing response.
