"""In-memory inbound rate limiting helpers."""

from __future__ import annotations

import threading
import time
from collections import defaultdict


class RateLimiter:
    """Enforce per-chat throughput and per-agent concurrency limits."""

    def __init__(
        self,
        *,
        max_per_minute: int = 10,
        max_per_hour: int = 60,
        max_concurrent_sessions: int = 2,
        clock=None,
    ) -> None:
        self.max_per_minute = max_per_minute
        self.max_per_hour = max_per_hour
        self.max_concurrent_sessions = max_concurrent_sessions
        self._clock = clock or time.time
        self._lock = threading.Lock()
        self._minute_buckets: dict[str, list[float]] = defaultdict(list)
        self._hour_buckets: dict[str, list[float]] = defaultdict(list)
        self._active_sessions: dict[str, int] = defaultdict(int)

    def allow(self, chat_id: str, agent_name: str) -> tuple[bool, str]:
        now = self._clock()
        with self._lock:
            minute = [t for t in self._minute_buckets[chat_id] if now - t < 60]
            hour = [t for t in self._hour_buckets[chat_id] if now - t < 3600]
            self._minute_buckets[chat_id] = minute
            self._hour_buckets[chat_id] = hour

            if self._active_sessions[agent_name] >= self.max_concurrent_sessions:
                return False, "Trop de sessions en cours pour cet agent. Réessaie dans un instant."
            if len(minute) >= self.max_per_minute:
                return False, "Tu envoies trop de messages trop vite. Attends une minute."
            if len(hour) >= self.max_per_hour:
                return False, "Limite horaire atteinte. Réessaie plus tard."

            minute.append(now)
            hour.append(now)
            return True, "ok"

    def session_start(self, agent_name: str) -> None:
        with self._lock:
            self._active_sessions[agent_name] += 1

    def session_end(self, agent_name: str) -> None:
        with self._lock:
            self._active_sessions[agent_name] = max(0, self._active_sessions[agent_name] - 1)
