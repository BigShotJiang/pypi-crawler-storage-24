"""Monitoring utilities for service health and Sentry heartbeat pinging."""

from __future__ import annotations

import json
import os
import subprocess
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _utc_iso(value: datetime | None) -> str | None:
    if value is None:
        return None
    return value.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _parse_log_timestamp(line: str) -> datetime | None:
    if not line.startswith("["):
        return None
    end = line.find("]")
    if end <= 1:
        return None
    raw = line[1:end]
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(raw, fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue
    return None


def _latest_log_timestamp(path: Path, marker: str) -> datetime | None:
    if not path.exists():
        return None
    lines = path.read_text(encoding="utf-8", errors="ignore").splitlines()
    for line in reversed(lines):
        if marker not in line:
            continue
        parsed = _parse_log_timestamp(line)
        if parsed is not None:
            return parsed
    return None


def _datetime_from_stat(path: Path) -> datetime | None:
    if not path.exists():
        return None
    return datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc)


def _latest_agent_action_timestamps(path: Path) -> dict[str, datetime]:
    latest: dict[str, datetime] = {}
    if not path.exists():
        return latest

    for line in path.read_text(encoding="utf-8", errors="ignore").splitlines():
        parsed = _parse_log_timestamp(line)
        if parsed is None:
            continue
        _, _, remainder = line.partition("]")
        agent_name, _, _ = remainder.partition("|")
        agent_name = agent_name.strip()
        if not agent_name or agent_name == "heartbeat":
            continue
        previous = latest.get(agent_name)
        if previous is None or parsed > previous:
            latest[agent_name] = parsed
    return latest


def _next_run_from_schedule(schedule: str, after: datetime | None) -> datetime | None:
    """Compute next run time for simple cron expressions without external deps."""
    from datetime import timedelta

    now = after or _utc_now()
    parts = schedule.split()
    if len(parts) != 5:
        return None

    minute_part, hour_part, dom_part, month_part, dow_part = parts

    # Handle "*/N" pattern for minute-based intervals
    if minute_part.startswith("*/") and hour_part == "*":
        try:
            interval = int(minute_part[2:])
            # Round up to next multiple of interval
            current_minute = now.minute
            minutes_past = current_minute % interval
            delta_minutes = (interval - minutes_past) if minutes_past != 0 else interval
            return (now + timedelta(minutes=delta_minutes)).replace(second=0, microsecond=0)
        except ValueError:
            pass

    # Handle fixed hour/minute (e.g. "0 23 * * 0" = weekly Sunday 23:00)
    if minute_part.isdigit() and hour_part.isdigit():
        target_minute = int(minute_part)
        target_hour = int(hour_part)
        candidate = now.replace(hour=target_hour, minute=target_minute, second=0, microsecond=0)
        if candidate <= now:
            candidate = candidate + timedelta(days=1)
        # Handle day-of-week constraint
        if dow_part.isdigit():
            target_dow = int(dow_part)  # 0 = Sunday
            days_ahead = (target_dow - candidate.weekday() - 1) % 7
            if days_ahead:
                candidate = candidate + timedelta(days=days_ahead)
        return candidate

    return None


def _default_agent_cron_jobs(root_path: Path | None = None) -> list[dict[str, Any]]:
    heartbeat_log = (root_path / "logs" / "heartbeat.log") if root_path else None
    heartbeat_last_run = _utc_iso(
        _latest_log_timestamp(heartbeat_log, "Heartbeat starting")
        if heartbeat_log
        else None
    )
    heartbeat_schedule = "*/30 * * * *"
    heartbeat_last_dt = (
        _latest_log_timestamp(heartbeat_log, "Heartbeat starting")
        if heartbeat_log
        else None
    )
    heartbeat_next = _utc_iso(_next_run_from_schedule(heartbeat_schedule, heartbeat_last_dt))

    consolidation_schedule = "0 23 * * 0"
    consolidation_next = _utc_iso(_next_run_from_schedule(consolidation_schedule, None))

    return [
        {
            "id": "memory-consolidation",
            "name": "Memory consolidation",
            "schedule": consolidation_schedule,
            "scope": "agent",
            "description": "Weekly consolidation merges daily learnings into memory.md.",
            "last_run_at": None,
            "next_run_at": consolidation_next,
        },
        {
            "id": "heartbeat-runtime",
            "name": "Heartbeat runtime",
            "schedule": heartbeat_schedule,
            "scope": "system",
            "description": "Global heartbeat runner that can trigger proactive work touching agent memory.",
            "last_run_at": heartbeat_last_run,
            "next_run_at": heartbeat_next,
        },
    ]


def _collect_agent_names(root_path: Path, config: dict[str, Any]) -> list[str]:
    names: set[str] = set()
    for thread_id, thread_cfg in config.get("threads", {}).items():
        if thread_id == "default":
            continue
        name = str(thread_cfg.get("name", "")).strip()
        if name:
            names.add(name)

    agents_dir = root_path / "agents"
    if agents_dir.exists():
        for child in agents_dir.iterdir():
            if child.is_dir() and not child.name.startswith("."):
                names.add(child.name)

    return sorted(names)


def _agent_thread_index(config: dict[str, Any]) -> dict[str, dict[str, Any]]:
    index: dict[str, dict[str, Any]] = {}
    for thread_id, thread_cfg in config.get("threads", {}).items():
        if thread_id == "default":
            continue
        name = str(thread_cfg.get("name", "")).strip()
        if name:
            index[name] = {
                "thread_id": str(thread_id),
                "model": thread_cfg.get("model"),
                "context_messages": thread_cfg.get("context_messages"),
            }
    return index


def _agent_file_info(root_path: Path, agent_name: str, file_name: str) -> dict[str, Any]:
    path = root_path / "agents" / agent_name / file_name
    info: dict[str, Any] = {
        "path": f"agents/{agent_name}/{file_name}",
        "exists": path.exists(),
        "modified_at": None,
        "size_bytes": None,
    }
    if path.exists():
        stat = path.stat()
        info["modified_at"] = _utc_iso(datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc))
        info["size_bytes"] = stat.st_size
    return info


def _agent_daily_notes(root_path: Path, agent_name: str) -> list[dict[str, Any]]:
    daily_dir = root_path / "agents" / agent_name / "daily"
    if not daily_dir.exists():
        return []

    notes: list[dict[str, Any]] = []
    for note_path in sorted(daily_dir.glob("*.md"), reverse=True):
        stat = note_path.stat()
        notes.append(
            {
                "name": note_path.name,
                "path": f"agents/{agent_name}/daily/{note_path.name}",
                "modified_at": _utc_iso(datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc)),
                "size_bytes": stat.st_size,
            }
        )
    return notes


def _latest_agent_file_activity(root_path: Path, agent_name: str, daily_notes: list[dict[str, Any]]) -> datetime | None:
    candidates = [
        _datetime_from_stat(root_path / "agents" / agent_name / "soul.md"),
        _datetime_from_stat(root_path / "agents" / agent_name / "memory.md"),
    ]
    if daily_notes:
        latest_daily = root_path / "agents" / agent_name / "daily" / daily_notes[0]["name"]
        candidates.append(_datetime_from_stat(latest_daily))
    present = [value for value in candidates if value is not None]
    if not present:
        return None
    return max(present)


def list_agent_runtime_details(*, root: str | Path, config: dict[str, Any]) -> list[dict[str, Any]]:
    root_path = Path(root)
    action_timestamps = _latest_agent_action_timestamps(root_path / "logs" / "actions.log")
    thread_index = _agent_thread_index(config)
    details: list[dict[str, Any]] = []

    for agent_name in _collect_agent_names(root_path, config):
        thread_cfg = thread_index.get(agent_name, {})
        files = {
            "soul": _agent_file_info(root_path, agent_name, "soul.md"),
            "memory": _agent_file_info(root_path, agent_name, "memory.md"),
        }
        daily_notes = _agent_daily_notes(root_path, agent_name)
        action_heartbeat = action_timestamps.get(agent_name)
        file_activity = _latest_agent_file_activity(root_path, agent_name, daily_notes)
        last_heartbeat = action_heartbeat or file_activity

        status = "ok"
        reasons: list[str] = []
        if not files["soul"]["exists"]:
            status = "warning"
            reasons.append("missing soul.md")
        if not files["memory"]["exists"]:
            status = "warning"
            reasons.append("missing memory.md")
        if last_heartbeat is None:
            status = "warning"
            reasons.append("no heartbeat recorded")

        if not reasons:
            reason = "last action log" if action_heartbeat is not None else "filesystem activity"
        else:
            reason = ", ".join(reasons)

        details.append(
            {
                "id": agent_name,
                "name": agent_name,
                "thread_id": thread_cfg.get("thread_id"),
                "model": thread_cfg.get("model"),
                "context_messages": thread_cfg.get("context_messages"),
                "last_heartbeat_at": _utc_iso(last_heartbeat),
                "status": status,
                "reason": reason,
                "has_soul": files["soul"]["exists"],
                "has_memory": files["memory"]["exists"],
                "daily_note_count": len(daily_notes),
                "files": files,
                "daily_notes": daily_notes,
                "cron_jobs": _default_agent_cron_jobs(root_path),
            }
        )

    return details


def collect_agent_heartbeats(*, root: str | Path, config: dict[str, Any]) -> dict[str, Any]:
    now = _utc_now()
    details = list_agent_runtime_details(root=root, config=config)
    return {
        "checked_at": _utc_iso(now),
        "agents": [
            {
                "id": agent["id"],
                "name": agent["name"],
                "thread_id": agent["thread_id"],
                "model": agent["model"],
                "context_messages": agent["context_messages"],
                "last_heartbeat_at": agent["last_heartbeat_at"],
                "status": agent["status"],
                "reason": agent["reason"],
                "has_soul": agent["has_soul"],
                "has_memory": agent["has_memory"],
                "daily_note_count": agent["daily_note_count"],
            }
            for agent in details
        ],
    }


def _process_running(pattern: str) -> bool:
    try:
        proc = subprocess.run(
            ["pgrep", "-f", pattern],
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError:
        return False
    return proc.returncode == 0


def _service_status(
    *,
    service_id: str,
    label: str,
    status: str,
    last_check_at: datetime | None,
    expected_interval_seconds: int,
    reason: str,
) -> dict[str, Any]:
    now = _utc_now()
    is_late = False
    if last_check_at is not None and expected_interval_seconds > 0:
        age = (now - last_check_at).total_seconds()
        is_late = age > expected_interval_seconds * 2
    if status == "ok" and is_late:
        status = "error"
        reason = f"late_check: {reason}"

    return {
        "id": service_id,
        "name": label,
        "status": status,
        "last_check_at": _utc_iso(last_check_at),
        "expected_interval_seconds": expected_interval_seconds,
        "is_late": is_late,
        "reason": reason,
    }


def collect_monitoring_status(*, root: str | Path, config: dict[str, Any]) -> dict[str, Any]:
    """Compute global and per-service health for the monitoring dashboard."""
    root_path = Path(root)
    now = _utc_now()

    heartbeat_interval_min = int(config.get("heartbeat", {}).get("interval_minutes", 60))
    services: list[dict[str, Any]] = []

    heartbeat_log = root_path / "logs" / "heartbeat.log"
    heartbeat_last = _latest_log_timestamp(heartbeat_log, "Heartbeat starting")
    services.append(
        _service_status(
            service_id="cron",
            label="Cron heartbeat",
            status="ok" if heartbeat_last else "error",
            last_check_at=heartbeat_last,
            expected_interval_seconds=max(heartbeat_interval_min, 1) * 60,
            reason="heartbeat log check",
        )
    )

    telegram_ok = _process_running("telegram_adapter.py")
    services.append(
        _service_status(
            service_id="telegram-adapter",
            label="Telegram adapter",
            status="ok" if telegram_ok else "error",
            last_check_at=now if telegram_ok else None,
            expected_interval_seconds=60,
            reason="process check",
        )
    )

    services.append(
        _service_status(
            service_id="api-server",
            label="API server",
            status="ok",
            last_check_at=now,
            expected_interval_seconds=60,
            reason="request served by API",
        )
    )

    has_threads = any(thread_id != "default" for thread_id in config.get("threads", {}))
    services.append(
        _service_status(
            service_id="agent-runtime",
            label="Agent runtime",
            status="ok" if has_threads else "error",
            last_check_at=now if has_threads else None,
            expected_interval_seconds=heartbeat_interval_min * 60,
            reason="thread config presence",
        )
    )

    configured = config.get("monitoring", {}).get("services", [])
    for raw in configured:
        service_id = str(raw.get("id", "")).strip()
        if not service_id:
            continue
        if any(s["id"] == service_id for s in services):
            continue
        log_path = root_path / str(raw.get("log_path", "logs/heartbeat.log"))
        marker = str(raw.get("marker", "Heartbeat starting"))
        expected = int(raw.get("expected_interval_seconds", 300))
        last = _latest_log_timestamp(log_path, marker)
        services.append(
            _service_status(
                service_id=service_id,
                label=str(raw.get("name", service_id)),
                status="ok" if last else "error",
                last_check_at=last,
                expected_interval_seconds=max(expected, 1),
                reason=f"log marker '{marker}'",
            )
        )

    global_status = "ok" if all(service["status"] == "ok" for service in services) else "error"

    return {
        "status": global_status,
        "checked_at": _utc_iso(now),
        "services": services,
    }


def sentry_monitor_url(config: dict[str, Any]) -> str:
    monitoring_cfg = config.get("monitoring", {})
    env_var = str(monitoring_cfg.get("sentry_monitor_url_env_var", "SENTRY_MONITOR_URL"))
    return os.environ.get(env_var, "").strip()


def send_sentry_heartbeat(*, monitor_url: str, ok: bool, body: dict[str, Any] | None = None) -> tuple[bool, str]:
    """Send an aggregate heartbeat to Sentry cron monitor URL."""
    if not monitor_url:
        return False, "missing_monitor_url"

    status_value = "ok" if ok else "error"
    separator = "&" if "?" in monitor_url else "?"
    target_url = f"{monitor_url}{separator}status={urllib.parse.quote(status_value)}"

    payload = json.dumps(body or {}).encode("utf-8")
    request = urllib.request.Request(
        target_url,
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=10) as response:
            if 200 <= response.status < 300:
                return True, f"http_{response.status}"
            return False, f"http_{response.status}"
    except urllib.error.URLError as exc:
        return False, f"network_error:{exc}"
