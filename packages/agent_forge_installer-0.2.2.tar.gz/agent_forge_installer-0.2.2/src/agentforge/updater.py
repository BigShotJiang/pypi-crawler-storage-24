"""AgentForge updater — check, apply, and rollback updates."""

from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from agentforge import __version__
from agentforge.migrations import (
    get_pending_migrations,
    read_version_state,
    run_migrations,
    write_version_state,
)

logger = logging.getLogger(__name__)

# PyPI JSON API — no auth needed
PYPI_URL = "https://pypi.org/pypi/agent-forge-installer/json"


def _resolve_root() -> Path:
    return Path(os.environ.get("AGENTFORGE_ROOT", "/home/clawdia"))


def _pip_executable() -> str:
    """Find pip in the current venv or system."""
    root = _resolve_root()
    venv_pip = root / ".venv" / "bin" / "pip"
    if venv_pip.exists():
        return str(venv_pip)
    return sys.executable + " -m pip"


def _parse_version(v: str) -> tuple[int, ...]:
    """Parse a version string into a tuple for comparison."""
    parts = v.replace("-", ".").split(".")
    result = []
    for p in parts:
        try:
            result.append(int(p))
        except ValueError:
            break
    return tuple(result) if result else (0,)


def check_update(channel: str = "stable") -> dict[str, Any]:
    """Check PyPI for the latest version.

    Returns dict with:
        - current_version: str
        - latest_version: str
        - update_available: bool
        - release_url: str (if available)
    """
    current = __version__
    result = {
        "current_version": current,
        "latest_version": current,
        "update_available": False,
        "release_url": "",
        "error": None,
    }

    try:
        # Use urllib (stdlib) to avoid dependency on requests
        import urllib.request
        import urllib.error

        req = urllib.request.Request(PYPI_URL, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode())

        latest = data.get("info", {}).get("version", current)
        result["latest_version"] = latest
        result["release_url"] = data.get("info", {}).get("project_url", "")

        if _parse_version(latest) > _parse_version(current):
            result["update_available"] = True

    except Exception as e:
        result["error"] = str(e)
        logger.warning(f"Failed to check PyPI for updates: {e}")

    return result


def apply_update(
    *,
    channel: str = "stable",
    skip_restart: bool = False,
) -> dict[str, Any]:
    """Apply an update: pip upgrade + migrations + optional restart.

    Returns dict with update results.
    """
    root = _resolve_root()
    state = read_version_state(root)
    old_version = __version__

    result = {
        "old_version": old_version,
        "new_version": old_version,
        "migrations_applied": [],
        "restarted": False,
        "rolled_back": False,
        "error": None,
    }

    # Step 1: Backup current wheel info for rollback
    _backup_current_version(root, old_version)

    # Step 2: pip install --upgrade
    logger.info("Upgrading agentforge via pip...")
    try:
        pip_cmd = _pip_executable()
        if " -m " in pip_cmd:
            cmd = pip_cmd.split() + ["install", "--upgrade", "agent-forge-installer"]
        else:
            cmd = [pip_cmd, "install", "--upgrade", "agent-forge-installer"]

        proc = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            timeout=120,
        )
        if proc.returncode != 0:
            raise RuntimeError(f"pip upgrade failed:\n{proc.stderr}")
        logger.info("  ✓ pip upgrade completed")
    except Exception as e:
        result["error"] = f"pip upgrade failed: {e}"
        logger.error(result["error"])
        return result

    # Step 3: Reload version after upgrade
    # We need to re-import to get the new version
    try:
        import importlib
        import agentforge
        importlib.reload(agentforge)
        new_version = agentforge.__version__
    except Exception:
        new_version = old_version  # couldn't detect, assume same
    result["new_version"] = new_version

    # Step 4: Run pending migrations
    logger.info("Running migrations...")
    try:
        applied = run_migrations(root)
        result["migrations_applied"] = applied
        if applied:
            logger.info(f"  ✓ {len(applied)} migration(s) applied")
        else:
            logger.info("  No pending migrations")
    except Exception as e:
        result["error"] = f"Migration failed: {e}"
        logger.error(result["error"])
        # Don't auto-rollback pip — user should decide
        return result

    # Step 5: Update version tracking
    now = datetime.now(timezone.utc).isoformat()
    state = read_version_state(root)
    state["previous_version"] = old_version
    state["installed_version"] = new_version
    state["last_update"] = now
    state["update_channel"] = channel
    write_version_state(root, state)

    # Step 6: Post-update healthcheck
    healthy = _post_update_healthcheck(root)
    if not healthy:
        logger.warning("Post-update healthcheck failed!")
        result["error"] = "Post-update healthcheck failed. Consider `agentforge update --rollback`"
        return result

    # Step 7: Restart service (if running under systemd)
    if not skip_restart:
        restarted = _restart_service()
        result["restarted"] = restarted

    logger.info(f"Update complete: {old_version} → {new_version}")
    return result


def rollback(root: Path | None = None) -> dict[str, Any]:
    """Rollback to the previous version."""
    if root is None:
        root = _resolve_root()

    state = read_version_state(root)
    prev_version = state.get("previous_version")
    result = {
        "rolled_back": False,
        "from_version": state.get("installed_version", __version__),
        "to_version": prev_version,
        "error": None,
    }

    if not prev_version:
        result["error"] = "No previous version recorded — cannot rollback"
        return result

    # Check if we have a backup wheel
    backup_dir = root / "data" / "backups"
    backup_wheels = list(backup_dir.glob(f"agentforge-{prev_version}*")) if backup_dir.exists() else []

    logger.info(f"Rolling back from {result['from_version']} to {prev_version}...")

    try:
        pip_cmd = _pip_executable()
        if backup_wheels:
            # Install from backed-up wheel
            wheel_path = str(backup_wheels[0])
            if " -m " in pip_cmd:
                cmd = pip_cmd.split() + ["install", "--force-reinstall", wheel_path]
            else:
                cmd = [pip_cmd, "install", "--force-reinstall", wheel_path]
        else:
            # Install specific version from PyPI
            if " -m " in pip_cmd:
                cmd = pip_cmd.split() + ["install", f"agent-forge-installer=={prev_version}"]
            else:
                cmd = [pip_cmd, "install", f"agent-forge-installer=={prev_version}"]

        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if proc.returncode != 0:
            raise RuntimeError(f"pip rollback failed:\n{proc.stderr}")

        # Update state
        state["installed_version"] = prev_version
        state["previous_version"] = None  # can't double-rollback
        state["last_update"] = datetime.now(timezone.utc).isoformat()
        write_version_state(root, state)

        result["rolled_back"] = True
        logger.info(f"  ✓ Rolled back to {prev_version}")

        # Restart service
        _restart_service()

    except Exception as e:
        result["error"] = f"Rollback failed: {e}"
        logger.error(result["error"])

    return result


def _backup_current_version(root: Path, version: str) -> None:
    """Backup current version's wheel for rollback."""
    backup_dir = root / "data" / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)

    # Clean old backups (keep only N-1)
    existing = sorted(backup_dir.glob("agentforge-*"))
    for old in existing:
        try:
            old.unlink()
        except OSError:
            pass

    # Try to find current installed wheel and copy it
    try:
        import agentforge
        pkg_dir = Path(agentforge.__file__).parent
        # Look for dist-info
        site_packages = pkg_dir.parent
        dist_infos = list(site_packages.glob(f"agentforge-{version}*.dist-info"))
        if dist_infos:
            # Create a marker file (full wheel backup is complex, we rely on PyPI)
            marker = backup_dir / f"agentforge-{version}.marker"
            marker.write_text(json.dumps({
                "version": version,
                "backed_up_at": datetime.now(timezone.utc).isoformat(),
                "dist_info": str(dist_infos[0]),
            }))
    except Exception as e:
        logger.debug(f"Could not backup wheel: {e}")


def _post_update_healthcheck(root: Path) -> bool:
    """Verify the installation is healthy after an update."""
    checks_passed = True

    # Check 1: Can we import agentforge?
    try:
        import importlib
        import agentforge
        importlib.reload(agentforge)
        logger.info("  ✓ agentforge importable")
    except Exception as e:
        logger.error(f"  ✗ Cannot import agentforge: {e}")
        checks_passed = False

    # Check 2: Can we load config?
    config_path = root / "bot" / "config.json"
    if config_path.exists():
        try:
            json.loads(config_path.read_text())
            logger.info("  ✓ config.json valid")
        except Exception as e:
            logger.error(f"  ✗ config.json invalid: {e}")
            checks_passed = False

    # Check 3: Is version.json valid?
    try:
        state = read_version_state(root)
        if state.get("installed_version"):
            logger.info("  ✓ version.json valid")
        else:
            logger.warning("  ⚠ version.json missing installed_version")
    except Exception as e:
        logger.error(f"  ✗ version.json error: {e}")
        checks_passed = False

    # Check 4: SQLite database accessible?
    db_path = root / "data" / "conversations.db"
    if db_path.exists():
        try:
            import sqlite3
            conn = sqlite3.connect(str(db_path))
            conn.execute("SELECT count(*) FROM conversations")
            conn.close()
            logger.info("  ✓ conversations.db accessible")
        except Exception as e:
            logger.error(f"  ✗ conversations.db error: {e}")
            checks_passed = False

    return checks_passed


def _restart_service(name: str = "agentforge") -> bool:
    """Restart the systemd user service if it's running."""
    try:
        # Check if service exists and is active
        check = subprocess.run(
            ["systemctl", "--user", "is-active", f"{name}.service"],
            capture_output=True, text=True,
        )
        if check.stdout.strip() == "active":
            logger.info(f"Restarting {name} service...")
            result = subprocess.run(
                ["systemctl", "--user", "restart", f"{name}.service"],
                capture_output=True, text=True,
            )
            if result.returncode == 0:
                logger.info(f"  ✓ {name} service restarted")
                return True
            else:
                logger.warning(f"  ⚠ Failed to restart: {result.stderr}")
        else:
            logger.info(f"  Service {name} not active, skipping restart")
    except FileNotFoundError:
        logger.debug("systemctl not found, skipping restart")
    return False
