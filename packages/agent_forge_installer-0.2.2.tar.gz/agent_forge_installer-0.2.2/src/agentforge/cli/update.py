"""agentforge update — check, apply, and rollback updates."""

from __future__ import annotations

import logging
import os
import sys
from pathlib import Path

logger = logging.getLogger(__name__)


def _resolve_root() -> Path:
    return Path(os.environ.get("AGENTFORGE_ROOT", "/home/clawdia"))


def update_check(channel: str = "stable") -> None:
    """Check for available updates."""
    from agentforge.updater import check_update
    from agentforge import __version__
    from agentforge.migrations import get_pending_migrations

    root = _resolve_root()

    print(f"Current version: {__version__}")
    print(f"Channel: {channel}")
    print()

    # Check PyPI
    result = check_update(channel=channel)
    if result["error"]:
        print(f"⚠ Could not reach PyPI: {result['error']}")
    elif result["update_available"]:
        print(f"✓ Update available: {result['latest_version']}")
        print(f"  Run `agentforge update` to apply")
    else:
        print(f"✓ You're on the latest version")

    # Check pending migrations
    pending = get_pending_migrations(root)
    if pending:
        print(f"\n{len(pending)} pending migration(s):")
        for m in pending:
            print(f"  • {m['id']}: {m['description']}")
    print()


def update_apply(
    *,
    channel: str = "stable",
    skip_restart: bool = False,
    yes: bool = False,
) -> None:
    """Apply available updates."""
    from agentforge.updater import check_update, apply_update
    from agentforge import __version__

    logging.basicConfig(level=logging.INFO, format="%(message)s")

    # Check first
    check = check_update(channel=channel)

    if check["error"]:
        print(f"⚠ Could not reach PyPI: {check['error']}")
        print("Proceeding with migrations only...")
    elif not check["update_available"]:
        # Still run migrations (might have pending ones from a manual install)
        from agentforge.migrations import get_pending_migrations
        root = _resolve_root()
        pending = get_pending_migrations(root)
        if not pending:
            print(f"✓ Already on latest version ({__version__}), no pending migrations")
            return
        print(f"No package update available, but {len(pending)} migration(s) pending")

    if not yes and check.get("update_available"):
        print(f"\nUpdate: {check['current_version']} → {check['latest_version']}")
        try:
            answer = input("Apply update? [y/N] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\nAborted.")
            return
        if answer not in ("y", "yes"):
            print("Aborted.")
            return

    print()
    result = apply_update(channel=channel, skip_restart=skip_restart)

    if result["error"]:
        print(f"\n✗ Update error: {result['error']}")
        sys.exit(1)
    else:
        print(f"\n✓ Update complete: {result['old_version']} → {result['new_version']}")
        if result["migrations_applied"]:
            print(f"  Migrations applied: {', '.join(result['migrations_applied'])}")
        if result["restarted"]:
            print(f"  Service restarted")


def update_rollback() -> None:
    """Rollback to the previous version."""
    from agentforge.updater import rollback
    from agentforge.migrations import read_version_state

    logging.basicConfig(level=logging.INFO, format="%(message)s")

    root = _resolve_root()
    state = read_version_state(root)

    prev = state.get("previous_version")
    if not prev:
        print("✗ No previous version recorded — nothing to rollback to")
        sys.exit(1)

    print(f"Rolling back: {state.get('installed_version', '?')} → {prev}")
    try:
        answer = input("Proceed? [y/N] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        print("\nAborted.")
        return
    if answer not in ("y", "yes"):
        print("Aborted.")
        return

    result = rollback(root)

    if result["error"]:
        print(f"\n✗ Rollback error: {result['error']}")
        sys.exit(1)
    else:
        print(f"\n✓ Rolled back to {result['to_version']}")


def update_auto_enable(*, interval_hours: int = 24, auto_apply: bool = False) -> None:
    """Enable auto-update checking via systemd timer."""
    root = _resolve_root()
    service_dir = Path.home() / ".config" / "systemd" / "user"
    service_dir.mkdir(parents=True, exist_ok=True)

    venv_bin = root / ".venv" / "bin"
    if not venv_bin.exists():
        venv_bin = Path(os.environ.get("VIRTUAL_ENV", root / ".venv")) / "bin"

    mode = "--yes" if auto_apply else "--check"
    description = "AgentForge Auto-Update" + (" (auto-apply)" if auto_apply else " (check only)")

    # Service
    service_content = f"""\
[Unit]
Description={description}
After=network-online.target

[Service]
Type=oneshot
WorkingDirectory={root}
ExecStart={venv_bin}/agentforge update {mode}
EnvironmentFile={root}/.env
Environment=AGENTFORGE_ROOT={root}
"""
    service_file = service_dir / "agentforge-update.service"
    service_file.write_text(service_content)

    # Timer
    timer_content = f"""\
[Unit]
Description=AgentForge Auto-Update Timer

[Timer]
OnCalendar=*-*-* 06:00:00
RandomizedDelaySec={interval_hours * 60}
Persistent=true

[Install]
WantedBy=timers.target
"""
    timer_file = service_dir / "agentforge-update.timer"
    timer_file.write_text(timer_content)

    print(f"Created {service_file}")
    print(f"Created {timer_file}")
    print()
    print("Enable with:")
    print("  systemctl --user daemon-reload")
    print("  systemctl --user enable --now agentforge-update.timer")
    print()
    if auto_apply:
        print("⚠ Auto-apply is enabled — updates will be applied automatically")
    else:
        print("Updates will be checked daily. You'll be notified via the bot.")


def update_auto_disable() -> None:
    """Disable auto-update checking."""
    import subprocess

    try:
        subprocess.run(
            ["systemctl", "--user", "disable", "--now", "agentforge-update.timer"],
            capture_output=True, text=True,
        )
        print("✓ Auto-update timer disabled")
    except FileNotFoundError:
        print("systemctl not found")

    # Clean up files
    service_dir = Path.home() / ".config" / "systemd" / "user"
    for f in ["agentforge-update.service", "agentforge-update.timer"]:
        path = service_dir / f
        if path.exists():
            path.unlink()
            print(f"  Removed {path}")


def update_status() -> None:
    """Show current update status and version tracking info."""
    from agentforge import __version__
    from agentforge.migrations import read_version_state, get_pending_migrations

    root = _resolve_root()
    state = read_version_state(root)

    print(f"AgentForge Update Status")
    print(f"{'=' * 40}")
    print(f"Package version:    {__version__}")
    print(f"Tracked version:    {state.get('installed_version', 'unknown')}")
    print(f"Previous version:   {state.get('previous_version', 'none')}")
    print(f"Update channel:     {state.get('update_channel', 'stable')}")
    print(f"Last update:        {state.get('last_update', 'never')}")
    print(f"Applied migrations: {len(state.get('applied_migrations', []))}")

    pending = get_pending_migrations(root)
    if pending:
        print(f"\nPending migrations: {len(pending)}")
        for m in pending:
            print(f"  • {m['id']}: {m['description']}")

    # Check rollback availability
    if state.get("previous_version"):
        print(f"\nRollback available → {state['previous_version']}")
    else:
        print(f"\nNo rollback available")
