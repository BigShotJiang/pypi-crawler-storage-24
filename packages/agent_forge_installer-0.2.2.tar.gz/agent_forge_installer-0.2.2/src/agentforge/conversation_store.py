"""Shared SQLite conversation storage for Telegram and HTTP API access."""

from __future__ import annotations

import json
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from threading import Lock
from typing import Any, Callable
from zoneinfo import ZoneInfo

MONTREAL = ZoneInfo("America/Montreal")


def _default_now() -> datetime:
    return datetime.now(MONTREAL)


@dataclass
class ConversationMessage:
    id: int
    session_id: str
    timestamp: str
    role: str
    content: str
    source: str
    telegram_chat_id: str | None
    telegram_message_id: str | None
    metadata: dict[str, Any]
    parent_message_id: int | None = None
    thread_reply_count: int = 0

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "session_id": self.session_id,
            "timestamp": self.timestamp,
            "role": self.role,
            "content": self.content,
            "source": self.source,
            "telegram_chat_id": self.telegram_chat_id,
            "telegram_message_id": self.telegram_message_id,
            "metadata": self.metadata,
            "parent_message_id": self.parent_message_id,
            "thread_reply_count": self.thread_reply_count,
        }


class ConversationStore:
    """Thread-safe wrapper around the shared conversations SQLite database."""

    def __init__(
        self,
        db_path: str,
        *,
        connection: sqlite3.Connection | None = None,
        now_fn: Callable[[], datetime] | None = None,
    ) -> None:
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._connection = connection or sqlite3.connect(db_path, check_same_thread=False)
        self._connection.row_factory = sqlite3.Row
        self._lock = Lock()
        self._now_fn = now_fn or _default_now
        self.init_db()

    @property
    def connection(self) -> sqlite3.Connection:
        return self._connection

    def init_db(self) -> None:
        with self._lock:
            self._connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS conversations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    timestamp TEXT NOT NULL DEFAULT (datetime('now')),
                    role TEXT NOT NULL CHECK(role IN ('user', 'assistant', 'system')),
                    content TEXT NOT NULL,
                    source TEXT NOT NULL DEFAULT 'telegram',
                    telegram_chat_id TEXT,
                    telegram_message_id TEXT,
                    metadata TEXT
                );
                CREATE TABLE IF NOT EXISTS usage_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL DEFAULT (datetime('now')),
                    agent_name TEXT NOT NULL,
                    model TEXT NOT NULL,
                    input_tokens INTEGER NOT NULL DEFAULT 0,
                    output_tokens INTEGER NOT NULL DEFAULT 0,
                    cache_write_tokens INTEGER NOT NULL DEFAULT 0,
                    cache_read_tokens INTEGER NOT NULL DEFAULT 0,
                    cost_usd REAL NOT NULL DEFAULT 0.0
                );
                CREATE INDEX IF NOT EXISTS idx_usage_log_timestamp
                    ON usage_log(timestamp);
                CREATE INDEX IF NOT EXISTS idx_usage_log_agent
                    ON usage_log(agent_name);
                CREATE TABLE IF NOT EXISTS pending_retries (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    session_id TEXT NOT NULL,
                    user_text TEXT NOT NULL,
                    thread_cfg TEXT NOT NULL,
                    chat_id TEXT NOT NULL,
                    thread_id TEXT,
                    created_at TEXT NOT NULL,
                    retry_after TEXT NOT NULL,
                    attempts INTEGER DEFAULT 0
                );
                CREATE INDEX IF NOT EXISTS idx_conversations_session
                    ON conversations(session_id);
                CREATE INDEX IF NOT EXISTS idx_conversations_timestamp
                    ON conversations(timestamp);
                CREATE INDEX IF NOT EXISTS idx_conversations_source
                    ON conversations(source);
                """
            )
            cur = self._connection.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='conversations_fts'"
            )
            if not cur.fetchone():
                self._connection.executescript(
                    """
                    CREATE VIRTUAL TABLE conversations_fts USING fts5(
                        content, content='conversations', content_rowid='id'
                    );
                    CREATE TRIGGER IF NOT EXISTS conversations_ai
                        AFTER INSERT ON conversations BEGIN
                        INSERT INTO conversations_fts(rowid, content)
                            VALUES (new.id, new.content);
                    END;
                    CREATE TRIGGER IF NOT EXISTS conversations_ad
                        AFTER DELETE ON conversations BEGIN
                        INSERT INTO conversations_fts(conversations_fts, rowid, content)
                            VALUES('delete', old.id, old.content);
                    END;
                    """
                )
            self._connection.commit()
        self._ensure_thread_columns()

    def _ensure_thread_columns(self) -> None:
        """Add thread support columns to conversations if they don't exist yet."""
        with self._lock:
            existing = {row[1] for row in self._connection.execute("PRAGMA table_info(conversations)").fetchall()}
            if "parent_message_id" not in existing:
                self._connection.execute(
                    "ALTER TABLE conversations ADD COLUMN parent_message_id INTEGER REFERENCES conversations(id)"
                )
                self._connection.execute(
                    "CREATE INDEX IF NOT EXISTS idx_conversations_parent ON conversations(parent_message_id)"
                )
                self._connection.commit()

    def save_message(
        self,
        session_id: str,
        role: str,
        content: str,
        *,
        source: str = "telegram",
        telegram_chat_id: str | None = None,
        telegram_message_id: str | None = None,
        metadata: dict[str, Any] | None = None,
        timestamp: str | None = None,
        parent_message_id: int | None = None,
    ) -> ConversationMessage:
        ts = timestamp or self._now_fn().strftime("%Y-%m-%d %H:%M:%S")
        encoded_metadata = json.dumps(metadata) if metadata is not None else None
        with self._lock:
            cur = self._connection.execute(
                """
                INSERT INTO conversations
                (session_id, timestamp, role, content, source, telegram_chat_id, telegram_message_id, metadata, parent_message_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    session_id,
                    ts,
                    role,
                    content,
                    source,
                    telegram_chat_id,
                    telegram_message_id,
                    encoded_metadata,
                    parent_message_id,
                ),
            )
            self._connection.commit()
            message_id = int(cur.lastrowid)
        return ConversationMessage(
            id=message_id,
            session_id=session_id,
            timestamp=ts,
            role=role,
            content=content,
            source=source,
            telegram_chat_id=telegram_chat_id,
            telegram_message_id=telegram_message_id,
            metadata=metadata or {},
            parent_message_id=parent_message_id,
            thread_reply_count=0,
        )

    def get_recent_messages(
        self, session_id: str, limit: int, hours: int | None = None
    ) -> list[tuple[str, str, str]]:
        if hours is not None:
            cutoff = (self._now_fn() - timedelta(hours=hours)).strftime("%Y-%m-%d %H:%M:%S")
            with self._lock:
                rows = self._connection.execute(
                    """
                    SELECT role, content, timestamp FROM conversations
                    WHERE session_id = ? AND timestamp >= ?
                    ORDER BY id DESC
                    """,
                    (session_id, cutoff),
                ).fetchall()
        else:
            cutoff = (self._now_fn() - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S")
            with self._lock:
                rows = self._connection.execute(
                    """
                    SELECT role, content, timestamp FROM conversations
                    WHERE session_id = ? AND timestamp >= ?
                    ORDER BY id DESC LIMIT ?
                    """,
                    (session_id, cutoff, limit),
                ).fetchall()
                if len(rows) < min(limit, 3):
                    rows = self._connection.execute(
                        """
                        SELECT role, content, timestamp FROM conversations
                        WHERE session_id = ?
                        ORDER BY id DESC LIMIT ?
                        """,
                        (session_id, max(limit, 3)),
                    ).fetchall()
        ordered = list(reversed(rows))
        return [(row["role"], row["content"], row["timestamp"]) for row in ordered]

    def list_messages(
        self,
        *,
        channel_id: str,
        limit: int = 50,
        before: str | None = None,
    ) -> list[ConversationMessage]:
        params: list[Any] = [
            f"api-channel-{channel_id}",
            f"%-t{channel_id}",
            channel_id,
        ]
        before_clause = ""
        if before:
            before_clause = "AND c.timestamp < ?"
            params.append(before)
        params.append(limit)
        query = f"""
            SELECT c.id, c.session_id, c.timestamp, c.role, c.content, c.source,
                   c.telegram_chat_id, c.telegram_message_id, c.metadata, c.parent_message_id,
                   (SELECT COUNT(*) FROM conversations r WHERE r.parent_message_id = c.id) AS thread_reply_count
            FROM conversations c
            WHERE (
                c.session_id = ?
                OR c.session_id LIKE ?
                OR json_extract(c.metadata, '$.channel') = ?
            )
            AND c.parent_message_id IS NULL
            {before_clause}
            ORDER BY c.timestamp DESC, c.id DESC
            LIMIT ?
        """
        with self._lock:
            rows = self._connection.execute(query, params).fetchall()
        return [self._row_to_message(row) for row in rows]

    def get_message_by_id(self, message_id: int) -> ConversationMessage | None:
        """Return a single message by its primary key, or None if not found."""
        with self._lock:
            row = self._connection.execute(
                "SELECT c.id, c.session_id, c.timestamp, c.role, c.content, c.source, "
                "c.telegram_chat_id, c.telegram_message_id, c.metadata, c.parent_message_id, "
                "0 AS thread_reply_count FROM conversations c WHERE c.id = ?",
                (message_id,),
            ).fetchone()
        return self._row_to_message(row) if row else None

    def list_thread_messages(self, parent_message_id: int) -> list[ConversationMessage]:
        """Return all reply messages for a given parent message, ordered oldest-first."""
        query = """
            SELECT c.id, c.session_id, c.timestamp, c.role, c.content, c.source,
                   c.telegram_chat_id, c.telegram_message_id, c.metadata, c.parent_message_id,
                   0 AS thread_reply_count
            FROM conversations c
            WHERE c.parent_message_id = ?
            ORDER BY c.timestamp ASC, c.id ASC
        """
        with self._lock:
            rows = self._connection.execute(query, (parent_message_id,)).fetchall()
        return [self._row_to_message(row) for row in rows]

    def save_usage(
        self,
        *,
        agent_name: str,
        model: str,
        input_tokens: int = 0,
        output_tokens: int = 0,
        cache_write_tokens: int = 0,
        cache_read_tokens: int = 0,
        cost_usd: float = 0.0,
        timestamp: str | None = None,
    ) -> None:
        ts = timestamp or self._now_fn().strftime("%Y-%m-%d %H:%M:%S")
        with self._lock:
            self._connection.execute(
                """
                INSERT INTO usage_log
                (timestamp, agent_name, model, input_tokens, output_tokens,
                 cache_write_tokens, cache_read_tokens, cost_usd)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (ts, agent_name, model,
                 input_tokens, output_tokens,
                 cache_write_tokens, cache_read_tokens,
                 cost_usd),
            )
            self._connection.commit()

    def get_monthly_cost(self) -> float:
        """Return total cost for the current calendar month."""
        now = self._now_fn()
        month_start = now.strftime("%Y-%m-01 00:00:00")
        with self._lock:
            row = self._connection.execute(
                "SELECT SUM(cost_usd) FROM usage_log WHERE timestamp >= ?",
                (month_start,),
            ).fetchone()
        return row[0] or 0.0

    def get_window_cost(self, hours: int = 5) -> tuple[float, str | None]:
        """Return (cost, oldest_timestamp) for usage in the last N hours.

        oldest_timestamp is an ISO string (``%Y-%m-%d %H:%M:%S``) or None if
        no usage exists in the window.
        """
        cutoff = (self._now_fn() - timedelta(hours=hours)).strftime("%Y-%m-%d %H:%M:%S")
        with self._lock:
            row = self._connection.execute(
                "SELECT SUM(cost_usd), MIN(timestamp) FROM usage_log WHERE timestamp >= ?",
                (cutoff,),
            ).fetchone()
        return (row[0] or 0.0, row[1])

    def get_usage_summary(self, *, days: int = 7) -> dict:
        """Return aggregated cost/token stats for the last N days."""
        cutoff = (self._now_fn() - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")
        with self._lock:
            row = self._connection.execute(
                """
                SELECT
                    COUNT(*) AS invocations,
                    SUM(cost_usd) AS total_cost,
                    SUM(input_tokens) AS total_input,
                    SUM(output_tokens) AS total_output,
                    SUM(cache_write_tokens) AS total_cache_write,
                    SUM(cache_read_tokens) AS total_cache_read
                FROM usage_log
                WHERE timestamp >= ?
                """,
                (cutoff,),
            ).fetchone()
            per_agent = self._connection.execute(
                """
                SELECT agent_name, SUM(cost_usd) AS cost
                FROM usage_log
                WHERE timestamp >= ?
                GROUP BY agent_name
                ORDER BY cost DESC
                """,
                (cutoff,),
            ).fetchall()
        return {
            "days": days,
            "invocations": row["invocations"] or 0,
            "total_cost": row["total_cost"] or 0.0,
            "total_input": row["total_input"] or 0,
            "total_output": row["total_output"] or 0,
            "total_cache_write": row["total_cache_write"] or 0,
            "total_cache_read": row["total_cache_read"] or 0,
            "per_agent": [(r["agent_name"], r["cost"] or 0.0) for r in per_agent],
        }

    def _row_to_message(self, row: sqlite3.Row) -> ConversationMessage:
        raw_metadata = row["metadata"]
        if isinstance(raw_metadata, bytes):
            raw_metadata = raw_metadata.decode()
        metadata = json.loads(raw_metadata) if raw_metadata else {}
        col_names = row.keys()
        parent_message_id = row["parent_message_id"] if "parent_message_id" in col_names else None
        thread_reply_count = row["thread_reply_count"] if "thread_reply_count" in col_names else 0
        return ConversationMessage(
            id=row["id"],
            session_id=row["session_id"],
            timestamp=row["timestamp"],
            role=row["role"],
            content=row["content"],
            source=row["source"],
            telegram_chat_id=row["telegram_chat_id"],
            telegram_message_id=row["telegram_message_id"],
            metadata=metadata,
            parent_message_id=parent_message_id,
            thread_reply_count=thread_reply_count,
        )
