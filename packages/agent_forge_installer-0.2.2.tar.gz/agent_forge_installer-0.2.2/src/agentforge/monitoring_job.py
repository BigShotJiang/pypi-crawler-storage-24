"""Run a single monitoring check and send one Sentry heartbeat ping."""

from __future__ import annotations

import json
import os
from pathlib import Path

from agentforge.api_server import _load_runtime_config
from agentforge.monitoring import collect_monitoring_status, send_sentry_heartbeat, sentry_monitor_url


def run_monitoring_job(*, config_path: str | None = None) -> int:
    root = Path(os.environ.get("AGENTFORGE_ROOT", "/home/clawdia"))
    config = _load_runtime_config(config_path)
    snapshot = collect_monitoring_status(root=root, config=config)
    monitor_url = sentry_monitor_url(config)

    heartbeat_sent = False
    heartbeat_result = "missing_monitor_url"
    if monitor_url:
        heartbeat_sent, heartbeat_result = send_sentry_heartbeat(
            monitor_url=monitor_url,
            ok=snapshot["status"] == "ok",
            body={"checked_at": snapshot["checked_at"], "service_count": len(snapshot["services"])}
        )

    report = {
        "status": snapshot["status"],
        "checked_at": snapshot["checked_at"],
        "heartbeat_sent": heartbeat_sent,
        "heartbeat_result": heartbeat_result,
        "services": snapshot["services"],
    }
    print(json.dumps(report, indent=2))

    if snapshot["status"] != "ok":
        return 1
    return 0


def main() -> None:
    raise SystemExit(run_monitoring_job())


if __name__ == "__main__":
    main()
