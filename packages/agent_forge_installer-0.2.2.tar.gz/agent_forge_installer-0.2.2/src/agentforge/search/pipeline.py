from __future__ import annotations

import argparse
import asyncio
import json
import os
from dataclasses import asdict

from agentforge.search.collectors.brave import BraveCollector
from agentforge.search.models import SearchReport, SearchRequest, SearchResult
from agentforge.search.synthesizer import SearchSynthesizer
from agentforge.search.vault_writer import VaultWriter


async def _collect_results(request: SearchRequest) -> list[SearchResult]:
    collectors = []
    for source in request.sources:
        if source == "brave":
            collectors.append(BraveCollector())
    if not collectors:
        return []

    gathered = await asyncio.gather(
        *(collector.collect(request.query, request.max_results_per_source) for collector in collectors),
        return_exceptions=True,
    )
    results: list[SearchResult] = []
    for item in gathered:
        if isinstance(item, Exception):
            continue
        results.extend(item)
    return results


def run_search(
    *,
    request: SearchRequest,
    root: str,
    config: dict,
    thread_cfg: dict,
    mode: str = "recherche",
) -> tuple[SearchReport, str]:
    raw_results = asyncio.run(_collect_results(request))
    report = SearchSynthesizer().synthesize(
        request,
        raw_results,
        root=root,
        config=config,
        thread_cfg=thread_cfg,
    )
    path = VaultWriter(root).write_report(report, mode=mode)
    return report, path


def _main() -> int:
    parser = argparse.ArgumentParser(description="AgentForge search pipeline (Phase 1 MVP)")
    parser.add_argument("query", help="Search query")
    parser.add_argument("--depth", choices=["quick", "deep"], default="quick")
    parser.add_argument("--source", action="append", default=["brave"])
    parser.add_argument("--max-results", type=int, default=10)
    args = parser.parse_args()

    root = os.environ.get("AGENTFORGE_ROOT", "/home/clawdia")
    config = {"claude": {"model": "sonnet", "max_budget_usd": 5.0}}
    thread_cfg = {"model": "opus" if args.depth == "deep" else "sonnet"}
    request = SearchRequest(
        query=args.query,
        sources=args.source,
        depth=args.depth,
        max_results_per_source=args.max_results,
    )
    report, path = run_search(
        request=request,
        root=root,
        config=config,
        thread_cfg=thread_cfg,
        mode="recherche",
    )
    print(
        json.dumps(
            {
                "text": f"🔎 Search completed for '{args.query}'.\n{report.summary}\n\nSaved: {path}",
                "path": path,
                "query": args.query,
                "results_count": len(report.results),
            },
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
