from __future__ import annotations

from abc import ABC, abstractmethod

from agentforge.search.models import SearchResult


class BaseCollector(ABC):
    @property
    @abstractmethod
    def source_name(self) -> str: ...

    @abstractmethod
    async def collect(self, query: str, max_results: int) -> list[SearchResult]: ...
