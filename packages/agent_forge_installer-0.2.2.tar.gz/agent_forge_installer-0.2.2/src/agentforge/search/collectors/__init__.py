"""Search collectors."""

from .brave import BraveCollector

__all__ = ["BraveCollector"]
