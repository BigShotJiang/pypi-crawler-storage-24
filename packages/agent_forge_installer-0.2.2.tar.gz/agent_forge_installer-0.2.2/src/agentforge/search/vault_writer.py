from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path

from agentforge.search.models import SearchReport


def _slugify(value: str) -> str:
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", value).strip("-").lower()
    return slug[:60] or "search"


class VaultWriter:
    def __init__(self, root: str) -> None:
        self.root = Path(root)

    def write_report(self, report: SearchReport, mode: str = "recherche") -> str:
        now = datetime.now(timezone.utc)
        date_str = now.strftime("%Y-%m-%d")
        if mode == "veille":
            out_dir = self.root / "vault" / "Veille"
            filename = f"{date_str}.md"
        else:
            out_dir = self.root / "vault" / "Recherche"
            filename = f"{date_str}-{_slugify(report.query)}.md"
        out_dir.mkdir(parents=True, exist_ok=True)
        path = out_dir / filename

        lines = [
            "---",
            f"type: {mode}",
            f'query: "{report.query}"',
            f"date: {date_str}",
            f"sources: [{', '.join(report.sources_used)}]",
            "---",
            "",
            f"# Recherche : {report.query}",
            "",
            "## Sommaire executif",
            report.summary.strip() or "- No summary generated.",
            "",
            "## Sources",
        ]
        for idx, item in enumerate(report.results, start=1):
            lines.extend(
                [
                    f"### {idx}. {item.title}",
                    f"- URL: {item.url}",
                    f"- Source: {item.source}",
                    f"- Extrait: {item.snippet}",
                    "",
                ]
            )
        path.write_text("\n".join(lines).strip() + "\n", encoding="utf-8")
        return str(path)
