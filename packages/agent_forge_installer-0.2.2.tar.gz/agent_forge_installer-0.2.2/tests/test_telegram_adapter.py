from __future__ import annotations

import queue
import threading
from datetime import datetime, timezone

from agentforge.claude_runner import InvokeResult, RateLimitError
from agentforge.rate_limiter import RateLimiter
from agentforge.claude_usage import ClaudeUsageError
from agentforge.telegram_adapter import ClawdiaBot
from agentforge.approval_gates import ApprovalGates


class _DummyQueue:
    def __init__(self) -> None:
        self.done_calls = 0

    def task_done(self) -> None:
        self.done_calls += 1


def _make_bot() -> ClawdiaBot:
    bot = object.__new__(ClawdiaBot)
    bot.config = {
        "claude": {"model": "sonnet"},
        "bot_name": "clawdia",
        "memory": {"context_messages": 5},
        "telegram": {"max_message_length": 4096, "allowed_chat_ids": []},
    }
    bot.bot_name = "clawdia"
    bot.agent_api_bases = {}
    bot.api_base = "https://example.test"
    bot.approval_gates = ApprovalGates(root="/tmp", timeout_seconds=1)
    bot._get_recent_messages = lambda *args, **kwargs: []
    bot._save_usage = lambda *args, **kwargs: None
    bot._save_message = lambda *args, **kwargs: None
    bot._log_action = lambda *args, **kwargs: None
    bot._save_pending_retry = lambda *args, **kwargs: None
    bot._handle_worker_error = ClawdiaBot._handle_worker_error.__get__(bot, ClawdiaBot)
    bot.rate_limiter = RateLimiter(max_per_minute=10, max_per_hour=60, max_concurrent_sessions=2)
    bot._append_claude_usage_summary = ClawdiaBot._append_claude_usage_summary.__get__(bot, ClawdiaBot)
    bot._append_real_claude_usage = ClawdiaBot._append_real_claude_usage.__get__(bot, ClawdiaBot)
    bot._append_estimated_claude_usage = ClawdiaBot._append_estimated_claude_usage.__get__(bot, ClawdiaBot)
    bot._format_usage_reset_label = ClawdiaBot._format_usage_reset_label.__get__(bot, ClawdiaBot)
    bot._builtin_status = ClawdiaBot._builtin_status.__get__(bot, ClawdiaBot)
    return bot


def test_should_respond_to_thread_allows_private_chats() -> None:
    bot = _make_bot()
    bot.config["telegram"]["default_for_threads"] = []

    assert bot._should_respond_to_thread({"chat": {"type": "private"}}, 999) is True


def test_should_respond_to_thread_allows_mentions() -> None:
    bot = _make_bot()
    bot.config["telegram"]["default_for_threads"] = []

    assert (
        bot._should_respond_to_thread(
            {"chat": {"type": "supergroup"}, "text": "ping @clawdia"},
            999,
        )
        is True
    )


def test_should_respond_to_thread_allows_configured_default_thread() -> None:
    bot = _make_bot()
    bot.config["telegram"]["default_for_threads"] = [957]

    assert bot._should_respond_to_thread({"chat": {"type": "supergroup"}}, 957) is True
    assert bot._should_respond_to_thread({"chat": {"type": "supergroup"}}, 961) is False


def test_should_respond_to_thread_defaults_to_back_compat_when_unconfigured() -> None:
    bot = _make_bot()

    assert bot._should_respond_to_thread({"chat": {"type": "supergroup"}}, 961) is True


def test_worker_invokes_directly(monkeypatch) -> None:
    """Each message is dispatched to _invoke_and_respond directly (no plan phase)."""
    bot = _make_bot()
    invoked: list[dict] = []
    task_queue: queue.Queue = queue.Queue()

    def fake_invoke_and_respond(task, tq):
        invoked.append(task)
        tq.task_done()

    bot._invoke_and_respond = fake_invoke_and_respond

    task = {
        "session_id": "sess-1",
        "user_text": "hello",
        "thread_cfg": {"name": "clawdia"},
        "chat_id": "chat",
        "thread_id": 123,
    }
    task_queue.put(task)
    task_queue.put(None)

    bot._worker("clawdia", task_queue)

    assert len(invoked) == 1
    assert invoked[0]["user_text"] == "hello"


def test_handle_worker_error_sends_message() -> None:
    bot = _make_bot()
    sent_messages: list[str] = []
    task_queue = _DummyQueue()
    bot._send_message = lambda chat_id, text, thread_id=None, agent_name=None, reply_markup=None: sent_messages.append(text)

    bot._handle_worker_error(
        RuntimeError("boom"),
        {},
        "chat",
        123,
        "clawdia",
        task_queue,
    )

    assert sent_messages == ["Sorry, I encountered an error. Please try again."]
    assert task_queue.done_calls == 1


def test_builtin_status_uses_real_claude_usage(monkeypatch) -> None:
    bot = _make_bot()

    class _Store:
        def get_window_cost(self, hours: int):
            raise AssertionError("estimated usage should not be used when real data is available")

    bot.store = _Store()

    def fake_run(*_args, **_kwargs):
        raise RuntimeError("skip system commands")

    monkeypatch.setattr("agentforge.telegram_adapter.subprocess.run", fake_run)
    monkeypatch.setattr(
        "agentforge.telegram_adapter.get_claude_oauth_usage",
        lambda root=None: {
            "five_hour": {"utilization": 32.0, "resets_at": "2026-03-25T14:53:00Z"},
            "seven_day": {"utilization": 83.0, "resets_at": "2026-03-29T17:59:00Z"},
            "seven_day_sonnet": {"utilization": 71.0, "resets_at": "2026-03-29T17:59:00Z"},
        },
    )

    status = bot._builtin_status()

    assert "📊 Claude Code (données réelles)" in status
    assert "Session 5h :" in status
    assert "Semaine :" in status
    assert "Sonnet semaine :" in status
    assert "32%" in status
    assert "83%" in status
    assert "71%" in status


def test_builtin_status_falls_back_to_estimated_usage(monkeypatch) -> None:
    bot = _make_bot()

    class _Store:
        def get_window_cost(self, hours: int):
            if hours == 5:
                return (4.0, "2026-03-25 08:00:00")
            if hours == 168:
                return (10.0, "2026-03-20 08:00:00")
            raise AssertionError(hours)

    bot.store = _Store()

    def fake_run(*_args, **_kwargs):
        raise RuntimeError("skip system commands")

    monkeypatch.setattr("agentforge.telegram_adapter.subprocess.run", fake_run)

    def fake_get_usage(root=None):
        raise ClaudeUsageError("oauth unavailable")

    monkeypatch.setattr("agentforge.telegram_adapter.get_claude_oauth_usage", fake_get_usage)

    status = bot._builtin_status()

    assert "📊 Claude Code (estimation locale)" in status
    assert "Fenêtre 5h :" in status
    assert "Fenêtre semaine :" in status


def test_format_usage_reset_label_uses_toronto_timezone() -> None:
    bot = _make_bot()
    now = datetime(2026, 3, 25, 10, 0, tzinfo=timezone.utc)
    reset_at = datetime(2026, 3, 25, 12, 30, tzinfo=timezone.utc)

    label = bot._format_usage_reset_label(reset_at, now)

    assert label == "dans 2h30"


def test_handle_worker_error_rate_limit_uses_generic_retry_later_message() -> None:
    bot = _make_bot()
    sent_messages: list[str] = []
    saved_retries: list[tuple[dict[str, int], int]] = []
    task_queue = _DummyQueue()
    bot._send_message = lambda chat_id, text, thread_id=None, agent_name=None, reply_markup=None: sent_messages.append(text)
    bot._save_pending_retry = lambda task, retry_after_seconds=3600: saved_retries.append(
        (task, retry_after_seconds)
    )

    task = {"_retry_attempt": 0}
    bot._handle_worker_error(
        RateLimitError(retry_after_seconds=90),
        task,
        "chat",
        123,
        "clawdia",
        task_queue,
    )

    assert saved_retries == [(task, 90)]
    assert len(sent_messages) == 1
    assert sent_messages[0].startswith("⏸ Rate limit Anthropic atteint.")
    assert task_queue.done_calls == 1


def test_callback_query_resolves_pending_approval(monkeypatch) -> None:
    bot = _make_bot()
    sent_messages: list[str] = []
    bot._send_message = lambda chat_id, text, thread_id=None, agent_name=None, reply_markup=None: sent_messages.append(text)
    monkeypatch.setattr("agentforge.telegram_adapter.http_post_json", lambda *args, **kwargs: {"ok": True})

    # Seed a pending approval by issuing an approval request in a worker thread.
    t = threading.Thread(
        target=lambda: bot.approval_gates.request_and_wait(
            chat_id="123",
            thread_id=456,
            command_text="rm -rf /tmp/demo",
            actor_label="archie",
            send_message_fn=lambda *args, **kwargs: None,
        ),
        daemon=True,
    )
    t.start()
    pending = None
    for _ in range(100):
        with bot.approval_gates._lock:  # noqa: SLF001
            if bot.approval_gates._pending:  # noqa: SLF001
                pending = next(iter(bot.approval_gates._pending.values()))  # noqa: SLF001
                break
        threading.Event().wait(0.01)

    assert pending is not None
    bot._handle_callback_query(
        {
            "id": "cb-1",
            "data": f"approval:{pending.request_id}:approve",
            "from": {"id": 42},
            "message": {"chat": {"id": 123}, "message_thread_id": 456},
        }
    )
    t.join(timeout=2)
    assert any("Decision recorded: approved." in m for m in sent_messages)


def test_handle_update_sends_friendly_rate_limit_message() -> None:
    bot = _make_bot()
    sent_messages: list[str] = []
    bot.config["telegram"]["allowed_chat_ids"] = ["123"]
    bot.rate_limiter = RateLimiter(max_per_minute=0, max_per_hour=60, max_concurrent_sessions=2)
    bot._send_message = lambda chat_id, text, thread_id=None, agent_name=None, reply_markup=None: sent_messages.append(text)
    bot._save_offset = lambda: None
    bot._extract_message_text = lambda msg, chat_id, thread_id: "hello"
    bot._dispatch_command = lambda *args, **kwargs: None
    bot._save_message = lambda *args, **kwargs: None
    bot._enqueue_task = lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("should not enqueue"))

    update = {
        "update_id": 1,
        "message": {
            "message_id": 10,
            "chat": {"id": 123},
            "from": {"first_name": "Martin", "is_bot": False},
            "text": "hello",
        },
    }

    bot._handle_update(update)

    assert sent_messages == ["⏱ Tu envoies trop de messages trop vite. Attends une minute."]


def test_dispatch_command_search_routes_to_background_job() -> None:
    bot = _make_bot()
    calls: list[tuple[str, str, str, int]] = []
    bot._start_search_job = (
        lambda cmd_key, query, chat_id, thread_id: calls.append((cmd_key, query, chat_id, thread_id)) or "ack"
    )

    result = bot._dispatch_command("/search latest agentforge release", "chat-1", 42)

    assert result == "ack"
    assert calls == [("/search", "latest agentforge release", "chat-1", 42)]
