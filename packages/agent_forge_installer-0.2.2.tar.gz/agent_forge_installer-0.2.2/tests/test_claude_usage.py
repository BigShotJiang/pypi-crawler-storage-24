from __future__ import annotations

import json

import pytest

from agentforge.claude_usage import (
    ClaudeUsageError,
    fetch_claude_oauth_usage,
    get_claude_oauth_token,
    parse_usage_reset,
)


def test_get_claude_oauth_token_reads_home_credentials(tmp_path) -> None:
    home = tmp_path / "home"
    creds_dir = home / ".claude"
    creds_dir.mkdir(parents=True)
    (creds_dir / ".credentials.json").write_text(
        json.dumps({"accessToken": "token-home"}),
        encoding="utf-8",
    )

    token = get_claude_oauth_token(home_dir=home)

    assert token == "token-home"


def test_get_claude_oauth_token_falls_back_to_agentforge_root(tmp_path) -> None:
    root = tmp_path / "root"
    creds_dir = root / ".claude"
    creds_dir.mkdir(parents=True)
    (creds_dir / ".credentials.json").write_text(
        json.dumps({"access_token": "token-root"}),
        encoding="utf-8",
    )

    token = get_claude_oauth_token(root=root, home_dir=tmp_path / "missing-home")

    assert token == "token-root"


def test_get_claude_oauth_token_raises_when_missing(tmp_path) -> None:
    with pytest.raises(ClaudeUsageError):
        get_claude_oauth_token(root=tmp_path / "root", home_dir=tmp_path / "home")


def test_fetch_claude_oauth_usage_passes_headers() -> None:
    captured: dict[str, object] = {}

    def fake_get(url: str, headers: dict[str, str], timeout: int) -> dict:
        captured["url"] = url
        captured["headers"] = headers
        captured["timeout"] = timeout
        return {"five_hour": {"utilization": 32.0, "resets_at": "2026-03-25T14:53:00Z"}}

    payload = fetch_claude_oauth_usage("secret-token", timeout=12, http_get_json_fn=fake_get)

    assert payload["five_hour"]["utilization"] == 32.0
    assert captured["headers"] == {
        "Authorization": "Bearer secret-token",
        "anthropic-beta": "oauth-2025-04-20",
    }
    assert captured["timeout"] == 12


def test_parse_usage_reset_handles_iso_z() -> None:
    parsed = parse_usage_reset("2026-03-25T14:53:00Z")

    assert parsed is not None
    assert parsed.isoformat() == "2026-03-25T14:53:00+00:00"
