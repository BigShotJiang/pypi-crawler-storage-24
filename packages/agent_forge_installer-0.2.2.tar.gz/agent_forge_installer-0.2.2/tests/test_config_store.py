from __future__ import annotations

import json

from agentforge.config_store import RuntimeConfigStore


def test_runtime_config_store_reload_safe_change(tmp_path) -> None:
    path = tmp_path / "config.json"
    path.write_text(json.dumps({"telegram": {"token_env_var": "TOKEN", "allowed_chat_ids": ["1"]}, "claude": {"model": "sonnet"}}))

    store = RuntimeConfigStore(path, normalizer=lambda raw: raw, debounce_seconds=0)

    path.write_text(json.dumps({"telegram": {"token_env_var": "TOKEN", "allowed_chat_ids": ["1"]}, "claude": {"model": "opus"}}))

    config, changed = store.reload_if_needed()

    assert changed is True
    assert config["claude"]["model"] == "opus"


def test_runtime_config_store_blocks_unsafe_telegram_changes(tmp_path) -> None:
    path = tmp_path / "config.json"
    path.write_text(json.dumps({"telegram": {"token_env_var": "TOKEN", "allowed_chat_ids": ["1"]}, "claude": {"model": "sonnet"}}))
    warnings: list[str] = []

    store = RuntimeConfigStore(
        path,
        normalizer=lambda raw: raw,
        debounce_seconds=0,
        log_warning=warnings.append,
    )

    path.write_text(json.dumps({"telegram": {"token_env_var": "NEW_TOKEN", "allowed_chat_ids": ["2"]}, "claude": {"model": "opus"}}))

    config, changed = store.reload_if_needed()

    assert changed is True
    assert config["claude"]["model"] == "opus"
    assert config["telegram"]["token_env_var"] == "TOKEN"
    assert config["telegram"]["allowed_chat_ids"] == ["1"]
    assert warnings


def test_runtime_config_store_keeps_previous_config_on_invalid_json(tmp_path) -> None:
    path = tmp_path / "config.json"
    path.write_text(json.dumps({"telegram": {"token_env_var": "TOKEN", "allowed_chat_ids": ["1"]}, "claude": {"model": "sonnet"}}))
    warnings: list[str] = []

    store = RuntimeConfigStore(
        path,
        normalizer=lambda raw: raw,
        debounce_seconds=0,
        log_warning=warnings.append,
    )

    path.write_text("{invalid json")

    config, changed = store.reload_if_needed()

    assert changed is False
    assert config["claude"]["model"] == "sonnet"
    assert warnings
