"""Tests for agentforge.memory_manager — conversation DB operations."""

import os
import sqlite3

import pytest

from agentforge import memory_manager


@pytest.fixture(autouse=True)
def isolate_db(tmp_root):
    """Ensure memory_manager uses a temp DB for every test."""
    db_path = str(tmp_root / "data" / "conversations.db")
    memory_manager.DB_PATH = db_path
    memory_manager.init_db()
    yield db_path


def _insert_messages(db_path, messages):
    """Helper: insert (role, content) tuples into the DB."""
    conn = sqlite3.connect(db_path)
    for role, content in messages:
        conn.execute(
            "INSERT INTO conversations (session_id, role, content) VALUES (?, ?, ?)",
            ("test-session", role, content),
        )
    conn.commit()
    conn.close()


class TestInitDb:
    def test_creates_tables(self, isolate_db):
        conn = sqlite3.connect(isolate_db)
        tables = [
            r[0]
            for r in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()
        ]
        conn.close()
        assert "conversations" in tables
        assert "conversations_fts" in tables

    def test_idempotent(self, isolate_db):
        # calling init_db again should not raise
        memory_manager.init_db()


class TestSearch:
    def test_search_finds_match(self, isolate_db, capsys):
        _insert_messages(isolate_db, [
            ("user", "deploy the agentforge project"),
            ("assistant", "done, agentforge is deployed"),
            ("user", "how is the weather today"),
        ])
        memory_manager.search("agentforge")
        out = capsys.readouterr().out
        assert "agentforge" in out.lower()
        # Should NOT match the weather message
        assert "weather" not in out

    def test_search_no_results(self, isolate_db, capsys):
        memory_manager.search("nonexistent_xyz")
        out = capsys.readouterr().out
        assert "No results" in out


class TestRecent:
    def test_recent_returns_last_n(self, isolate_db, capsys):
        _insert_messages(isolate_db, [
            ("user", f"message {i}") for i in range(10)
        ])
        memory_manager.recent(3)
        out = capsys.readouterr().out
        # Should show messages 7, 8, 9 (last 3)
        assert "message 7" in out
        assert "message 9" in out

    def test_recent_empty_db(self, isolate_db, capsys):
        memory_manager.recent(5)
        out = capsys.readouterr().out
        assert "No messages" in out


class TestStats:
    def test_stats_output(self, isolate_db, capsys):
        _insert_messages(isolate_db, [
            ("user", "hello"),
            ("assistant", "hi"),
        ])
        memory_manager.stats()
        out = capsys.readouterr().out
        assert "Total messages: 2" in out
        assert "user" in out
        assert "assistant" in out
