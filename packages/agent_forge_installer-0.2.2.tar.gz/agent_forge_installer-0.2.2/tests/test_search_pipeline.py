from __future__ import annotations

from pathlib import Path

from agentforge.search.models import SearchReport, SearchRequest, SearchResult
from agentforge.search.vault_writer import VaultWriter
from agentforge.search import pipeline


def test_vault_writer_creates_research_report(tmp_path: Path) -> None:
    report = SearchReport(
        query="agentforge release notes",
        summary="- Important update\n- Action items",
        results=[
            SearchResult(
                title="Release 1",
                url="https://example.com/1",
                snippet="Snippet",
                source="brave",
            )
        ],
        sources_used=["brave"],
    )
    path = VaultWriter(str(tmp_path)).write_report(report, mode="recherche")
    data = Path(path).read_text()
    assert "Sommaire executif" in data
    assert "https://example.com/1" in data
    assert "vault/Recherche" in path


def test_run_search_uses_collectors_and_writes_report(monkeypatch, tmp_path: Path) -> None:
    async def fake_collect_results(request):  # type: ignore[no-untyped-def]
        return [
            SearchResult(
                title="Result",
                url="https://example.com",
                snippet="snippet",
                source="brave",
            )
        ]

    class _Synth:
        def synthesize(self, request, raw_results, *, root, config, thread_cfg):  # type: ignore[no-untyped-def]
            return SearchReport(
                query=request.query,
                summary="summary",
                results=raw_results,
                sources_used=request.sources,
            )

    monkeypatch.setattr("agentforge.search.pipeline._collect_results", fake_collect_results)
    monkeypatch.setattr("agentforge.search.pipeline.SearchSynthesizer", lambda: _Synth())
    req = SearchRequest(query="q", sources=["brave"], depth="quick")
    report, report_path = pipeline.run_search(
        request=req,
        root=str(tmp_path),
        config={"claude": {"model": "sonnet"}},
        thread_cfg={"model": "sonnet"},
    )

    assert report.summary == "summary"
    assert Path(report_path).exists()
