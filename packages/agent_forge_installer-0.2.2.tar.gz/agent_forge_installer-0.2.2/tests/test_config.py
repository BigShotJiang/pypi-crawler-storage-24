"""Tests for agentforge.config — AgentForgeConfig loading and validation."""

import json
import os

import pytest

from agentforge.config import (
    AgentConfig,
    AgentForgeConfig,
    ConfigError,
    CronConfig,
    get_config,
    reset_config,
)


class TestAgentForgeConfig:
    """Test AgentForgeConfig.from_dict()."""

    def test_valid_config(self, sample_config_dict):
        cfg = AgentForgeConfig.from_dict(sample_config_dict)
        assert cfg.telegram.token == "test-token-123"
        assert cfg.telegram.allowed_chat_ids == [-100123456]
        assert cfg.claude.model == "sonnet"
        assert cfg.claude.max_budget_usd == 0.5
        assert cfg.heartbeat.interval_minutes == 60
        assert cfg.logging.sheets_id == "test-sheet-id"
        assert "11" in cfg.threads
        assert cfg.threads["11"]["name"] == "clawdia"

    def test_missing_allowed_chat_ids(self, sample_config_dict):
        sample_config_dict["telegram"]["allowed_chat_ids"] = []
        with pytest.raises(ConfigError, match="allowed_chat_ids"):
            AgentForgeConfig.from_dict(sample_config_dict)

    def test_missing_model(self, sample_config_dict):
        del sample_config_dict["claude"]["model"]
        with pytest.raises(ConfigError, match="claude.model"):
            AgentForgeConfig.from_dict(sample_config_dict)

    def test_defaults_for_optional_fields(self):
        minimal = {
            "telegram": {"allowed_chat_ids": [1]},
            "claude": {"model": "haiku"},
        }
        cfg = AgentForgeConfig.from_dict(minimal)
        assert cfg.claude.max_budget_usd == 0.5
        assert cfg.heartbeat.interval_minutes == 60
        assert cfg.heartbeat.max_budget_usd == 0.1
        assert cfg.logging.sheets_id == ""
        assert cfg.threads == {}

    def test_budget_converted_to_float(self, sample_config_dict):
        sample_config_dict["claude"]["max_budget_usd"] = "1.5"
        cfg = AgentForgeConfig.from_dict(sample_config_dict)
        assert cfg.claude.max_budget_usd == 1.5
        assert isinstance(cfg.claude.max_budget_usd, float)


class TestConfigLoad:
    """Test AgentForgeConfig.load() from file."""

    def test_load_from_path(self, config_file):
        cfg = AgentForgeConfig.load(config_file)
        assert cfg.claude.model == "sonnet"

    def test_load_from_env(self, config_file):
        os.environ["AGENTFORGE_CONFIG"] = config_file
        try:
            cfg = AgentForgeConfig.load()
            assert cfg.claude.model == "sonnet"
        finally:
            os.environ.pop("AGENTFORGE_CONFIG", None)

    def test_load_from_root(self, config_file, tmp_root):
        # config_file is already at tmp_root/bot/config.json
        # AGENTFORGE_ROOT is set by tmp_root fixture
        cfg = AgentForgeConfig.load()
        assert cfg.claude.model == "sonnet"

    def test_load_nonexistent_file(self):
        with pytest.raises(FileNotFoundError):
            AgentForgeConfig.load("/nonexistent/config.json")


class TestSingleton:
    """Test get_config / reset_config singleton."""

    def test_singleton_returns_same_instance(self, config_file):
        reset_config()
        c1 = get_config(config_file)
        c2 = get_config()
        assert c1 is c2

    def test_reset_allows_reload(self, config_file, tmp_root, sample_config_dict):
        reset_config()
        c1 = get_config(config_file)
        assert c1.claude.model == "sonnet"

        # Modify config and reload
        sample_config_dict["claude"]["model"] = "opus"
        (tmp_root / "bot" / "config.json").write_text(json.dumps(sample_config_dict))
        reset_config()
        c2 = get_config(config_file)
        assert c2.claude.model == "opus"
        assert c1 is not c2


class TestAgentRuntimeConfig:
    def test_agent_config_defaults(self, tmp_root):
        agent_dir = tmp_root / "agents" / "archie"
        agent_dir.mkdir(parents=True)
        (agent_dir / "config.json").write_text(
            json.dumps(
                {
                    "name": "archie",
                    "telegram": {
                        "allowed_chat_ids": ["1"],
                        "private_chat_id": "1",
                    },
                    "claude": {"model": "sonnet"},
                }
            )
        )
        cfg = AgentConfig.from_dir(str(agent_dir))
        assert cfg.context.messages == 20
        assert cfg.context.hours == 24
        assert cfg.telegram.poll_interval_seconds == 2

    def test_agent_config_invalid_type_raises(self, tmp_root):
        agent_dir = tmp_root / "agents" / "archie"
        agent_dir.mkdir(parents=True)
        (agent_dir / "config.json").write_text(
            json.dumps(
                {
                    "name": "archie",
                    "telegram": {"allowed_chat_ids": ["1"], "private_chat_id": "1"},
                    "claude": {"model": "sonnet"},
                    "context": {"messages": "not-an-int", "hours": 24},
                }
            )
        )
        with pytest.raises(ConfigError, match="Invalid config"):
            AgentConfig.from_dir(str(agent_dir))


class TestCronConfig:
    def test_cron_config_defaults(self, tmp_root):
        cron_dir = tmp_root / "agents" / "archie" / "cron" / "heartbeat"
        cron_dir.mkdir(parents=True)
        (cron_dir / "config.json").write_text(json.dumps({}))
        cfg = CronConfig.from_dir(str(cron_dir))
        assert cfg.enabled is True
        assert cfg.model == "haiku"
        assert cfg.interval_minutes == 0

    def test_cron_config_invalid_type_raises(self, tmp_root):
        cron_dir = tmp_root / "agents" / "archie" / "cron" / "heartbeat"
        cron_dir.mkdir(parents=True)
        (cron_dir / "config.json").write_text(json.dumps({"interval_minutes": "abc"}))
        with pytest.raises(ConfigError, match="Invalid cron config"):
            CronConfig.from_dir(str(cron_dir))
