"""Tag Generator: LLM-based and keyword-based semantic tagging."""

from __future__ import annotations

import logging
import re
import time
from typing import TYPE_CHECKING, Callable, Protocol, runtime_checkable

from ..patterns import DEFAULT_TEMPORAL_PATTERNS
from ..types import (
    FactSignal,
    KeywordTagConfig,
    LLMProvider,
    TagGeneratorConfig,
    TagResult,
)
from .llm_utils import normalize_tag, parse_llm_json
from .telemetry import TelemetryLedger
from .tag_canonicalizer import TagCanonicalizer

logger = logging.getLogger(__name__)

TAG_GENERATOR_PROMPT_DETAILED = """\
You are a semantic tagger for conversation segments. Given a piece of conversation,
generate {min_tags}-{max_tags} short, lowercase tags that capture the key topics.

Rules:
- Prefer specific tags over generic ones. A good tag should narrow down WHICH
  conversation this came from, not just what broad category it falls into.
  Single-word tags are fine when already specific ("database", "teeth", "fitness").
  But when a single word is too broad and could match many unrelated conversations,
  qualify it with a hyphenated compound: "reservation-timing" not "timing",
  "cycle-tracking" not "tracking", "transit-schedule" not "schedule".
  Ask yourself: "Would this tag match conversations about completely different topics?"
  If yes, make it more specific.
- STRONGLY prefer reusing existing tags over creating new ones. Before inventing
  ANY new tag, check whether an existing tag already covers that topic — even if
  the wording is slightly different. Use "teeth" not "dental" if "teeth" exists.
  Use "data-visualization" not "data-visualization-tools" or "visualization-techniques".
  Do NOT create variants by appending -tips, -tools, -techniques, -strategies, -options,
  -resources, -planning, -management, etc. to an existing tag stem.
  A new tag is only justified when the topic is genuinely absent from the existing list.
- When the text introduces a genuinely NEW topic not covered by any existing tag,
  create a new tag. Do NOT force-fit unrelated text into existing tags.
- Only add the tag "rule" when the user gives the assistant an explicit standing
  instruction about response style — phrases like "always ...", "never ...",
  "from now on ...", "don't sugarcoat", "be honest with me".
  Do NOT tag as "rule": personal opinions ("I hate running"), feelings ("I'm
  overwhelmed"), desires ("I want to learn X"), questions, or topic switches.
- Set "temporal" to true when the query references a specific time position in
  the conversation — "the first thing we discussed", "at the beginning",
  "early on", "going way back", "when we first started". False for general
  queries, even if they reference the past ("remind me about X" is NOT temporal
  — it's looking for a topic, not a time position).

  temporal: true examples (references conversation position):
  - "Going back to the very first thing we discussed"
  - "What did we decide at the beginning?"
  - "Early on we talked about X — has that changed?"
  - "When we first started, what was the architecture?"

  temporal: false examples (topic recall, not time-positioned):
  - "Remind me what we said about auth" (looking for a topic)
  - "What was the middleware pattern?" (specific topic)
  - "Summarize everything" (broad, not temporal)
- Generate 2-5 related_tags: alternate words someone might use when referring back
  to these same concepts later (e.g. if tagging a discussion about "materialized views",
  related_tags might include "caching", "precomputed", "feed-optimization").
  These help future recall when the user uses different vocabulary.
- Messages may contain channel metadata (e.g. "[Telegram NAME ...]", "[WhatsApp ...]",
  "[Discord ...]", "[message_id: NNN]", timestamps, sender info). Ignore all metadata
  formatting — tag only the actual conversational content within the message.
- Do NOT generate tags about the communication medium, channel, group, or server
  (e.g. "messaging", "threading", "chat", "telegram-group",
  "discord-server", "slack-channel", "texting", "communication", "conversation").
  These describe WHERE or HOW the conversation happens, not WHAT it is about. Tag only the
  substantive topics being discussed.
- For very short or trivial messages (greetings, reactions, single-word responses,
  emoji), return only the tags that genuinely apply — it is acceptable to return
  fewer than {min_tags} tags when the content does not warrant more.
- Tag the concrete subject being discussed, not the conversational framing.
  "What do you think of trees?" → tag "trees" or "nature", NOT "introspection"
  or "cognition". The question format ("what do you think", "how do you feel",
  "tell me about") is framing — the subject is what matters for retrieval.
  Even if the assistant's response is philosophical or reflective, always include
  at least one tag for the concrete noun or topic the user asked about.
- Tag both what the conversation is about AND what the user reveals about
  their own life, experiences, or situation — even if mentioned in passing.
- Extract facts about the user's life, experiences, preferences, plans, and world.
  For each fact, classify:
  - "fact_type": "personal" (user's life/identity/preferences), "experience" (assistant-provided info the user engaged with), or "world" (facts about other people, places, things in the user's world)
  - "subject": who — use the actual name when conversation metadata identifies the sender (e.g. if metadata shows sender "Bob", the subject is "Bob", not "user"). When no name is available, use "user". For people mentioned but not speaking, use their name.
  - "verb": the exact action verb from the conversation (e.g. "led", "ordered", "prefers", "lives in")
  - "object": what (specific noun phrase — preserve ALL numbers, names, dates, amounts)
  - "status": one of: active, completed, planned, abandoned, recurring
  - "what": one full sentence capturing the complete fact with ALL specifics preserved.
    WRONG: "User has a personal best time." RIGHT: "User has a personal best 5K time of 27:12."
    WRONG: "User paid a parking ticket." RIGHT: "User paid a $40 parking ticket."
  Extract the FACT behind the question, not the conversational act.
  WRONG: "user asks about Cairo restaurants" RIGHT: "user wants to try authentic Egyptian food in Cairo"
  DO NOT extract: mere asks, mentions, discusses, requests for information.
  Only extract facts with genuine substance. Skip greetings and filler.
  When a pronoun refers to a named person mentioned earlier, resolve it: "Emily (user's college roommate)".
- Return JSON only: {{"tags": ["tag1", "tag2"], "primary": "tag1", "temporal": false, "related_tags": ["alt1", "alt2"], "facts": [{{"subject": "user", "verb": "...", "object": "...", "status": "...", "fact_type": "personal|experience|world", "what": "..."}}]}}
- The "primary" tag is the single most relevant tag
- No markdown fences, no extra text
"""

TAG_GENERATOR_PROMPT_COMPACT = """\
You are a semantic tagger. Generate {min_tags}-{max_tags} short, lowercase tags for the key topics.

Rules:
- Prefer single-word tags ("database", "fitness"). Hyphenate only when ambiguous ("machine-learning").
- STRONGLY prefer reusing existing tags. Do NOT create near-synonyms or variants
  (e.g. "data-visualization-tools" when "data-visualization" exists). A new tag is
  only justified when the topic is genuinely absent from the existing list.
- Set "temporal" to true when the query references a time position ("the first thing", "at the beginning", "early on").
- Ignore channel metadata in messages (e.g. "[Telegram ...]", "[message_id: NNN]"). Tag only actual content.
- Do NOT generate tags about the communication medium itself (e.g. "messaging", "threading", "chat"). Tag substantive topics only.
- For very short/trivial messages, return fewer than {min_tags} tags if the content does not warrant more.
- Tag the concrete subject, not conversational framing. "What do you think of trees?" → "trees", NOT "introspection".
- Tag both what the conversation is about AND what the user reveals about
  their own life, experiences, or situation — even if mentioned in passing.
- Extract facts: {{"subject": "user", "verb": "exact action verb", "object": "noun phrase with ALL specifics", "status": "active|completed|planned|abandoned|recurring", "fact_type": "personal|experience|world", "what": "full sentence with ALL specifics"}}
  For "subject": use the actual sender name from conversation metadata when available, not "user".
  Use the real verb (e.g. "led", "ordered", "prefers"). Extract the fact behind the question, not the conversational act.
  DO NOT extract mere asks/mentions/discusses. Preserve ALL numbers, names, dates, amounts.
- Generate 2-5 related_tags: alternate words for future recall.
- Return JSON only: {{"tags": ["tag1", "tag2"], "primary": "tag1", "temporal": false, "related_tags": ["alt1", "alt2"], "facts": [...]}}
- No markdown fences, no extra text
"""

# Optimised for smaller models (Qwen3-30B-A3B, Phi-4, etc.) that struggle with
# long multi-section prompts.  Tagging instructions are lean; fact extraction
# uses proven V8 rules with positive framing and concrete examples.
TAG_GENERATOR_PROMPT_SMALL_MODEL = """\
You are a semantic tagger and fact extractor. Given a conversation segment:
1. Generate {min_tags}-{max_tags} short, lowercase tags for the key topics.
2. Extract personal facts about the user.

=== TAGGING RULES ===
- Prefer specific tags ("reservation-timing" not "timing").
- Reuse existing tags when possible.  Do NOT create near-synonyms.
- Set "temporal" to true ONLY when the query references a time position in the conversation ("the first thing we discussed", "at the beginning").
- Ignore channel metadata. Do NOT tag the communication medium ("chat", "messaging").
- Tag the concrete subject, not conversational framing.

=== FACT EXTRACTION RULES ===
- Extract facts where the user reveals something about themselves: achievements, plans, preferences, habits, relationships, activities, opinions.
- Copy all numbers exactly: dates, prices, times, quantities.
- If the user asks a question, extract the personal fact BEHIND the question.
  Example: "What do you think of my new car?" → fact: user has a new car.
  Example: "Can you help me train for the marathon?" → fact: user is training for a marathon.
- Skip ONLY pure information requests with no personal revelation.
- For each fact: subject (use actual sender name from metadata when available, not "user"), verb (exact action verb), object (with ALL numbers preserved), status (active/completed/planned), fact_type (personal/experience/world), what (one full sentence with all specifics).
  WRONG: "User has a personal best time." RIGHT: "User has a personal best 5K time of 27:12."
- Populate who/when/where/why when the conversation mentions them. Leave "" if not mentioned.

=== OUTPUT ===
Return JSON only:
{{"tags": ["tag1", "tag2"], "primary": "tag1", "temporal": false, "related_tags": ["alt1"], "facts": [{{"subject": "user", "verb": "...", "object": "...", "status": "...", "fact_type": "personal", "what": "...", "who": "", "when": "", "where": "", "why": ""}}]}}
No markdown fences, no extra text.
"""

TAG_GENERATOR_PROMPTS = {
    "detailed": TAG_GENERATOR_PROMPT_DETAILED,
    "compact": TAG_GENERATOR_PROMPT_COMPACT,
    "small_model": TAG_GENERATOR_PROMPT_SMALL_MODEL,
    "qwen3": TAG_GENERATOR_PROMPT_SMALL_MODEL,
}


@runtime_checkable
class TagGenerator(Protocol):
    def generate_tags(
        self, text: str, existing_tags: list[str] | None = None,
        context_turns: list[str] | None = None,
    ) -> TagResult: ...


def _compile_temporal_patterns(patterns: list[str]) -> list[re.Pattern]:
    compiled = []
    for pattern in patterns:
        try:
            compiled.append(re.compile(pattern, re.IGNORECASE))
        except re.error:
            logger.warning(f"Invalid temporal_pattern regex, skipping: {pattern}")
    return compiled


def detect_temporal_heuristic(text: str, patterns: list[re.Pattern]) -> bool:
    for pattern in patterns:
        if pattern.search(text):
            return True
    return False


class LLMTagGenerator:

    def __init__(
        self,
        llm_provider: LLMProvider,
        config: TagGeneratorConfig,
        canonicalizer: TagCanonicalizer | None = None,
        telemetry_ledger: TelemetryLedger | None = None,
        embed_fn_factory: "Callable[[], Callable[[list[str]], list[list[float]]] | None] | None" = None,
        cost_tracker=None,  # deprecated, ignored — legacy parameter
    ) -> None:
        self.llm = llm_provider
        self.config = config
        self._tag_vocabulary: dict[str, int] = {}
        self._canonicalizer = canonicalizer
        self._telemetry = telemetry_ledger
        self._embed_fn_factory = embed_fn_factory
        self._temporal_patterns = _compile_temporal_patterns(config.temporal_patterns)

    def generate_tags(
        self, text: str, existing_tags: list[str] | None = None,
        context_turns: list[str] | None = None,
    ) -> TagResult:
        prompt = self._build_prompt(text, existing_tags, context_turns=context_turns)

        prompt_template = TAG_GENERATOR_PROMPTS.get(
            self.config.prompt_mode, TAG_GENERATOR_PROMPT_DETAILED
        )
        system = prompt_template.format(
            min_tags=self.config.min_tags,
            max_tags=self.config.max_tags,
        )

        # Disable thinking mode for models that support it (e.g. qwen3)
        if self.config.disable_thinking:
            prompt = "/no_think\n" + prompt

        try:
            t0 = time.time()
            response, _usage = self.llm.complete(
                system=system,
                user=prompt,
                max_tokens=self.config.max_tokens,
            )
            duration_ms = (time.time() - t0) * 1000
            self._log_usage(duration_ms=duration_ms, usage=_usage)
            result = self._parse_response(response)
        except Exception as e:
            logger.warning(f"LLM tag generation failed: {e}")
            result = TagResult(
                tags=["_general"],
                primary="_general",
                source="fallback",
            )

        # Deterministic override: catch temporal queries the LLM missed
        if self.config.temporal_heuristic_enabled and not result.temporal and detect_temporal_heuristic(text, self._temporal_patterns):
            logger.debug("Temporal heuristic override: LLM missed temporal, heuristic caught it")
            result.temporal = True

        return result

    def _select_relevant_store_tags(
        self, text: str, store_tags: list[str], limit: int = 30,
        similarity_threshold: float = 0.25,
    ) -> list[str]:
        """Select store tags most relevant to *text* using embedding similarity,
        then fill remaining slots with high-usage tags.

        Strategy: embed the text and all store tags, take those above
        *similarity_threshold* (up to *limit*). If fewer than *limit* tags
        qualify, pad with the highest-usage tags (which come first in
        *store_tags* since the caller orders by usage_count DESC).

        Falls back entirely to usage-count ordering when no embedding
        function is available.
        """
        if not store_tags:
            return []

        embed_fn: Callable | None = None
        if self._embed_fn_factory is not None:
            try:
                embed_fn = self._embed_fn_factory()
            except Exception:
                embed_fn = None

        if embed_fn is None:
            return store_tags[:limit]

        try:
            import numpy as np

            # Truncate text for embedding (first 500 chars is plenty for topic signal)
            snippet = text[:500]
            all_texts = [snippet] + store_tags
            vectors = embed_fn(all_texts)
            text_vec = np.array(vectors[0])
            tag_vecs = np.array(vectors[1:])

            # Cosine similarity
            norms = np.linalg.norm(tag_vecs, axis=1)
            norms[norms == 0] = 1.0
            text_norm = np.linalg.norm(text_vec)
            if text_norm == 0:
                return store_tags[:limit]
            similarities = tag_vecs @ text_vec / (norms * text_norm)

            # Take tags above threshold, ranked by similarity
            above = [(float(similarities[i]), i) for i in range(len(store_tags))
                     if similarities[i] >= similarity_threshold]
            above.sort(reverse=True)
            selected_indices = [i for _, i in above[:limit]]
            selected_set = set(selected_indices)

            # Fill remaining slots with highest-usage tags (preserve caller order)
            for i in range(len(store_tags)):
                if len(selected_indices) >= limit:
                    break
                if i not in selected_set:
                    selected_indices.append(i)
                    selected_set.add(i)

            return [store_tags[i] for i in selected_indices]
        except Exception:
            logger.debug("Embed-based tag selection failed, falling back to usage-count", exc_info=True)
            return store_tags[:limit]

    def _build_prompt(self, text: str, existing_tags: list[str] | None = None, context_turns: list[str] | None = None) -> str:
        """Build the tagging prompt with vocabulary hint.

        Splits tags into recent session tags (highest reuse priority) and
        store tags (secondary, selected by embedding relevance to the text).
        This encourages the LLM to converge on the same tags within a session
        rather than inventing synonyms.
        """
        parts = []

        # Recent session tags (from vocabulary tracker) — highest reuse priority
        session_tags = sorted(
            self._tag_vocabulary.keys(),
            key=lambda t: self._tag_vocabulary.get(t, 0),
            reverse=True,
        )

        # Store/external tags (passed in by caller)
        store_tags = existing_tags or []

        # Select store tags relevant to this text (embed-based when available)
        session_set = set(session_tags)
        candidates = [t for t in store_tags if t not in session_set]
        extra_store = self._select_relevant_store_tags(text, candidates, limit=30)

        if session_tags:
            parts.append(
                f"Existing tags (reuse when the topic genuinely matches, "
                f"but create new tags for new topics): {', '.join(session_tags)}"
            )
        if extra_store:
            parts.append(f"Other known tags: {', '.join(extra_store)}")

        # Inject recent conversation context when provided
        if context_turns:
            parts.append("")
            parts.append("Recent conversation context:")
            for j in range(0, len(context_turns) - 1, 2):
                parts.append(f"User: {context_turns[j]}")
                if j + 1 < len(context_turns):
                    parts.append(f"Assistant: {context_turns[j + 1]}")
            parts.append("")

        parts.append(f"Tag this conversation (return {self.config.min_tags}-{self.config.max_tags} tags):")
        parts.append("")

        # Truncate text to avoid overwhelming the model
        max_chars = 4000
        if len(text) > max_chars:
            text = text[:max_chars] + "\n[...truncated]"
        parts.append(text)

        return "\n".join(parts)

    def _parse_response(self, response: str) -> TagResult:
        data = parse_llm_json(response)

        tags = data.get("tags", [])
        primary = data.get("primary", "")
        temporal = bool(data.get("temporal", False))

        if not tags:
            return TagResult(
                tags=["_general"],
                primary="_general",
                source="fallback",
            )

        tags = self._normalize_tags(tags)
        if primary:
            primary = self._normalize_tag(primary)
            if primary not in tags:
                tags.insert(0, primary)
        else:
            primary = tags[0]

        # Enforce min/max
        tags = tags[:self.config.max_tags]

        # Parse and normalize related_tags
        related_tags_raw = data.get("related_tags", [])
        if isinstance(related_tags_raw, list):
            related_tags = self._normalize_tags(related_tags_raw)
            # Deduplicate: remove any that overlap with primary tags
            tag_set = set(tags)
            related_tags = [t for t in related_tags if t not in tag_set]
        else:
            related_tags = []

        # Parse fact signals (D1)
        raw_facts = data.get("facts", [])
        fact_signals: list[FactSignal] = []
        if isinstance(raw_facts, list):
            for f in raw_facts:
                if isinstance(f, dict) and f.get("subject") and f.get("object"):
                    fact_signals.append(FactSignal(
                        subject=f.get("subject", ""),
                        verb=f.get("verb", f.get("role", "")),
                        object=f.get("object", ""),
                        status=f.get("status", "active"),
                        fact_type=f.get("fact_type", "personal"),
                        what=f.get("what", ""),
                    ))

        # Update vocabulary
        for tag in tags:
            self._tag_vocabulary[tag] = self._tag_vocabulary.get(tag, 0) + 1

        return TagResult(
            tags=tags,
            primary=primary,
            source="llm",
            temporal=temporal,
            related_tags=related_tags,
            fact_signals=fact_signals,
        )

    def _normalize_tag(self, tag: str) -> str:
        tag = normalize_tag(tag)
        if self._canonicalizer:
            tag = self._canonicalizer.canonicalize(tag)
        return tag

    def _normalize_tags(self, tags: list) -> list[str]:
        seen: set[str] = set()
        result: list[str] = []
        for tag in tags:
            if not isinstance(tag, str):
                continue
            normalized = self._normalize_tag(tag)
            if normalized and normalized not in seen:
                seen.add(normalized)
                result.append(normalized)
        return result

    def load_vocabulary(self, tag_counts: dict[str, int]) -> None:
        self._tag_vocabulary.update(tag_counts)

    def _log_usage(self, duration_ms: float = 0.0, usage: dict | None = None) -> None:
        if not self._telemetry:
            return
        if usage is None:
            usage = getattr(self.llm, "last_usage", {})
        if not usage:
            return
        input_tokens = usage.get("input_tokens", 0) or usage.get("prompt_tokens", 0)
        output_tokens = usage.get("output_tokens", 0) or usage.get("completion_tokens", 0)
        if input_tokens or output_tokens:
            self._telemetry.log(
                component="tagger",
                model=getattr(self.llm, "model", ""),
                input_tokens=input_tokens,
                output_tokens=output_tokens,
                duration_ms=duration_ms,
                detail="generate_tags",
            )


class KeywordTagGenerator:

    def __init__(self, config: KeywordTagConfig) -> None:
        self.config = config
        self._compiled_patterns: dict[str, list[re.Pattern]] = {}
        self._initialize()

    def _initialize(self) -> None:
        for tag, patterns in self.config.tag_patterns.items():
            self._compiled_patterns[tag] = []
            for pattern in patterns:
                try:
                    self._compiled_patterns[tag].append(
                        re.compile(pattern, re.IGNORECASE)
                    )
                except re.error:
                    logger.warning(f"Invalid regex pattern for tag '{tag}': {pattern}")

    def generate_tags(
        self, text: str, existing_tags: list[str] | None = None,
        context_turns: list[str] | None = None,
    ) -> TagResult:
        text_lower = text.lower()
        matched_tags: set[str] = set()

        # Keyword matching
        for tag, keywords in self.config.tag_keywords.items():
            if any(kw.lower() in text_lower for kw in keywords):
                matched_tags.add(tag)

        # Pattern matching
        for tag, patterns in self._compiled_patterns.items():
            for pattern in patterns:
                if pattern.search(text):
                    matched_tags.add(tag)
                    break

        if not matched_tags:
            return TagResult(
                tags=["_general"],
                primary="_general",
                source="fallback",
            )

        tags = sorted(matched_tags)
        primary = tags[0]

        return TagResult(
            tags=tags,
            primary=primary,
            source="keyword",
        )


def build_tag_generator(
    config: TagGeneratorConfig,
    llm_provider: LLMProvider | None = None,
    canonicalizer: TagCanonicalizer | None = None,
    telemetry_ledger: TelemetryLedger | None = None,
    embed_fn_factory: "Callable[[], Callable[[list[str]], list[list[float]]] | None] | None" = None,
    cost_tracker=None,  # deprecated, ignored — re-exported for existing callers
) -> TagGenerator:
    if config.type == "llm" and llm_provider is not None:
        return LLMTagGenerator(
            llm_provider=llm_provider, config=config,
            canonicalizer=canonicalizer, telemetry_ledger=telemetry_ledger,
            embed_fn_factory=embed_fn_factory,
        )

    if config.type == "embedding":
        from .embedding_tag_generator import EmbeddingTagGenerator
        # Use embed_fn from factory if available (shared EmbeddingProvider)
        _embed_fn = embed_fn_factory() if embed_fn_factory else None
        return EmbeddingTagGenerator(config=config, embed_fn=_embed_fn)

    if config.keyword_fallback:
        return KeywordTagGenerator(config=config.keyword_fallback)

    # Default: empty keyword config
    return KeywordTagGenerator(config=KeywordTagConfig())
