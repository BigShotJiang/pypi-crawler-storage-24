"""xcstrings translate and info commands."""

from __future__ import annotations

import asyncio
from pathlib import Path
from typing import Annotated, Optional

import typer
from rich.table import Table

from localizerx.cli.utils import console, create_progress
from localizerx.config import (
    GEMINI_MODELS,
    Config,
    get_cache_dir,
    load_config,
)
from localizerx.io.xcstrings import read_xcstrings, write_xcstrings
from localizerx.parser.model import Translation
from localizerx.translator.base import TranslationRequest
from localizerx.translator.gemini_adapter import GeminiTranslator
from localizerx.utils.context import extract_app_context_string
from localizerx.utils.locale import (
    get_language_name,
    parse_language_list,
    validate_language_code,
)


def translate(
    path: Annotated[
        Optional[Path],
        typer.Argument(
            help="Path to .xcstrings file or directory (auto-detected if omitted)",
        ),
    ] = None,
    to: Annotated[
        Optional[str],
        typer.Option(
            "--to",
            "-t",
            help=(
                "Target languages (comma-separated, e.g., 'fr,es,de')."
                " Omit to use defaults from config."
            ),
        ),
    ] = None,
    src: Annotated[
        str,
        typer.Option(
            "--src",
            "-s",
            help="Source language",
        ),
    ] = "en",
    dry_run: Annotated[
        bool,
        typer.Option(
            "--dry-run",
            "-n",
            help="Show what would be translated without making changes",
        ),
    ] = False,
    preview: Annotated[
        bool,
        typer.Option(
            "--preview",
            "-p",
            help="Show proposed translations before applying",
        ),
    ] = False,
    overwrite: Annotated[
        bool,
        typer.Option(
            "--overwrite",
            help="Overwrite existing translations",
        ),
    ] = False,
    backup: Annotated[
        bool,
        typer.Option(
            "--backup",
            "-b",
            help="Create backup before writing changes",
        ),
    ] = False,
    config_path: Annotated[
        Optional[Path],
        typer.Option(
            "--config",
            "-c",
            help="Path to configuration file",
        ),
    ] = None,
    batch_size: Annotated[
        Optional[int],
        typer.Option(
            "--batch-size",
            help="Number of strings per API call",
            min=1,
            max=100,
        ),
    ] = None,
    model: Annotated[
        Optional[str],
        typer.Option(
            "--model",
            "-m",
            help="Gemini model to use (see 'localizerx models' for list)",
        ),
    ] = None,
    temperature: Annotated[
        Optional[float],
        typer.Option(
            "--temperature",
            "-T",
            help="Sampling temperature (0.0–2.0). Lower = more deterministic.",
            min=0.0,
            max=2.0,
        ),
    ] = None,
    custom_prompt: Annotated[
        Optional[str],
        typer.Option(
            "--custom-prompt",
            "--instructions",
            help="Custom instructions for translation (e.g., 'Do not translate proper names')",
        ),
    ] = None,
    no_app_context: Annotated[
        bool,
        typer.Option(
            "--no-app-context",
            help=(
                "Disable automatic app context extraction (name, subtitle, description) "
                "from metadata or project files."
            ),
        ),
    ] = False,
    refresh: Annotated[
        bool,
        typer.Option(
            "--refresh",
            help="Automatically add translations for new strings and delete stale strings.",
        ),
    ] = False,
    remove: Annotated[
        Optional[str],
        typer.Option(
            "--remove",
            "-r",
            help="Languages to remove (comma-separated, e.g., 'fr,de').",
        ),
    ] = None,
) -> None:
    """Translate an .xcstrings file to target languages.

    If --to is omitted, uses default_targets from config.
    """
    _run_translate(
        path=path,
        to=to,
        src=src,
        dry_run=dry_run,
        preview=preview,
        overwrite=overwrite,
        backup=backup,
        config_path=config_path,
        batch_size=batch_size,
        model=model,
        temperature=temperature,
        custom_prompt=custom_prompt,
        no_app_context=no_app_context,
        refresh=refresh,
        remove=remove,
    )


def _run_translate(
    path: Path | None,
    to: str | None,
    src: str,
    dry_run: bool,
    preview: bool,
    overwrite: bool,
    backup: bool,
    config_path: Path | None,
    batch_size: int | None,
    model: str | None,
    temperature: float | None,
    custom_prompt: str | None,
    no_app_context: bool,
    refresh: bool,
    remove: str | None = None,
) -> None:
    """Core translation logic."""
    # Load configuration
    config = load_config(config_path)

    # Parse target languages (use config defaults if not specified)
    target_langs = []
    if to:
        target_langs = parse_language_list(to)
    elif not remove:
        target_langs = config.default_targets.copy()
        if target_langs:
            console.print(
                f"[dim]Using default targets from config ({len(target_langs)} languages)[/dim]"
            )

    # Parse languages to remove
    remove_langs = []
    if remove:
        remove_langs = parse_language_list(remove)

    if not target_langs and not remove_langs:
        console.print("[red]Error:[/red] No target languages or languages to remove specified")
        console.print("Use --to or --remove option")
        raise typer.Exit(1)

    # Validate languages
    invalid_langs = [
        lang for lang in target_langs + remove_langs if not validate_language_code(lang)
    ]
    if invalid_langs:
        codes = ", ".join(invalid_langs)
        console.print(f"[yellow]Warning:[/yellow] Unrecognized language codes: {codes}")

    # Validate model
    if model and model not in GEMINI_MODELS:
        console.print(
            f"[yellow]Warning:[/yellow] Unknown model '{model}'. "
            "Use 'localizerx models' to see available models."
        )

    # Auto-detect xcstrings files if path not provided
    if path is None:
        search_path = Path.cwd()
        files = _find_xcstrings_files(search_path)
        if not files:
            console.print("[red]Error:[/red] No .xcstrings files found in current directory")
            raise typer.Exit(1)

        # If multiple files found, prompt user to select
        if len(files) > 1:
            files = _prompt_file_selection(files)
            if not files:
                console.print("[yellow]Cancelled[/yellow]")
                raise typer.Exit(0)
    else:
        # Validate path exists
        if not path.exists():
            console.print(f"[red]Error:[/red] Path does not exist: {path}")
            raise typer.Exit(1)
        files = _find_xcstrings_files(path)
        if not files:
            console.print(f"[red]Error:[/red] No .xcstrings files found at {path}")
            raise typer.Exit(1)

    console.print(f"Found {len(files)} .xcstrings file(s)")
    console.print(f"Source: {get_language_name(src)} ({src})")
    if target_langs:
        target_display = ", ".join(f"{get_language_name(lang)} ({lang})" for lang in target_langs)
        console.print(f"Targets: {target_display}")
    if remove_langs:
        remove_display = ", ".join(f"{get_language_name(lang)} ({lang})" for lang in remove_langs)
        console.print(f"Remove: [red]{remove_display}[/red]")
    console.print()

    # Process each file
    for file_path in files:
        _process_file(
            file_path=file_path,
            source_lang=src,
            target_langs=target_langs,
            remove_langs=remove_langs,
            config=config,
            dry_run=dry_run,
            preview=preview,
            overwrite=overwrite,
            backup=backup,
            batch_size=batch_size,
            model=model,
            temperature=temperature,
            custom_prompt=custom_prompt,
            no_app_context=no_app_context,
            refresh=refresh,
        )


def _find_xcstrings_files(path: Path) -> list[Path]:
    """Find all .xcstrings files in path."""
    if path.is_file():
        if path.suffix == ".xcstrings":
            return [path]
        return []

    return sorted(path.rglob("*.xcstrings"))


def _prompt_file_selection(files: list[Path]) -> list[Path]:
    """Prompt user to select which files to translate."""
    console.print(f"Found {len(files)} .xcstrings file(s):\n")

    for i, f in enumerate(files, 1):
        # Show relative path from cwd for readability
        try:
            rel_path = f.relative_to(Path.cwd())
        except ValueError:
            rel_path = f
        console.print(f"  [cyan]{i}[/cyan]. {rel_path}")

    console.print("\n  [cyan]a[/cyan]. All files")
    console.print()

    choice = typer.prompt("Select file(s) to translate (number, comma-separated, or 'a' for all)")
    choice = choice.strip().lower()

    if choice == "a":
        return files

    # Parse selection
    selected = []
    try:
        for part in choice.split(","):
            part = part.strip()
            if "-" in part:
                # Range like "1-3"
                start, end = map(int, part.split("-"))
                for i in range(start, end + 1):
                    if 1 <= i <= len(files):
                        selected.append(files[i - 1])
            else:
                idx = int(part)
                if 1 <= idx <= len(files):
                    selected.append(files[idx - 1])
    except ValueError:
        console.print("[red]Error:[/red] Invalid selection")
        return []

    # Remove duplicates while preserving order
    seen = set()
    unique = []
    for f in selected:
        if f not in seen:
            seen.add(f)
            unique.append(f)

    return unique


def _process_file(
    file_path: Path,
    source_lang: str,
    target_langs: list[str],
    remove_langs: list[str],
    config: Config,
    dry_run: bool,
    preview: bool,
    overwrite: bool,
    backup: bool,
    batch_size: int | None,
    model: str | None,
    temperature: float | None,
    custom_prompt: str | None,
    no_app_context: bool,
    refresh: bool,
) -> None:
    """Process a single xcstrings file."""
    console.print(f"[bold]Processing:[/bold] {file_path}")

    # Read file
    catalog = read_xcstrings(file_path)
    console.print(f"  Found {len(catalog.strings)} string(s)")

    # Remove languages if requested
    languages_actually_removed = []
    if remove_langs:
        for lang in remove_langs:
            removed_from_any = False
            for entry in catalog.strings.values():
                if lang in entry.translations:
                    del entry.translations[lang]
                    removed_from_any = True
            if removed_from_any:
                languages_actually_removed.append(lang)

        if languages_actually_removed:
            console.print(
                f"  [yellow]Removed {len(languages_actually_removed)} language(s)[/yellow]"
            )

    # Collect entries to translate per language
    translation_tasks: dict[str, list[tuple[str, str, str | None, dict | None]]] = {}

    stale_keys = []
    if refresh:
        for key, entry in catalog.strings.items():
            if entry.extraction_state == "stale":
                stale_keys.append(key)

        for key in stale_keys:
            del catalog.strings[key]

        if stale_keys:
            console.print(f"  [yellow]Removed {len(stale_keys)} stale string(s)[/yellow]")

    for target_lang in target_langs:
        entries_to_translate = []
        for key, entry in catalog.strings.items():
            if not entry.needs_translation:
                continue

            # In refresh mode, only target "new" strings
            if refresh and entry.extraction_state != "new":
                continue

            # Skip if translation exists and not overwriting
            if target_lang in entry.translations and not overwrite:
                continue

            entries_to_translate.append(
                (key, entry.source_text, entry.comment, entry.source_variations)
            )

        if entries_to_translate:
            translation_tasks[target_lang] = entries_to_translate

    if not translation_tasks:
        if (refresh and stale_keys) or languages_actually_removed:
            if dry_run:
                console.print("  [yellow]Dry run - no changes made[/yellow]")
                return
            write_xcstrings(catalog, file_path, backup=backup)
            console.print(f"  [green]Saved {file_path}[/green]")
        else:
            console.print("  [green]All strings already translated[/green]")
        return

    # Show summary
    for lang, entries in translation_tasks.items():
        console.print(f"  {get_language_name(lang)}: {len(entries)} string(s) to translate")

    if dry_run:
        console.print("  [yellow]Dry run - no changes made[/yellow]")
        _show_dry_run_table(translation_tasks)
        return

    # Perform translation
    asyncio.run(
        _translate_file(
            catalog=catalog,
            file_path=file_path,
            source_lang=source_lang,
            translation_tasks=translation_tasks,
            config=config,
            preview=preview,
            backup=backup,
            batch_size=batch_size,
            model=model,
            temperature=temperature,
            custom_prompt=custom_prompt,
            no_app_context=no_app_context,
        )
    )


def _show_dry_run_table(tasks: dict[str, list[tuple[str, str, str | None, dict | None]]]) -> None:
    """Show table of strings that would be translated."""
    table = Table(title="Strings to Translate")
    table.add_column("Key", style="cyan")
    table.add_column("Source Text", style="white")
    table.add_column("Languages", style="green")

    # Collect all unique entries
    entries: dict[str, tuple[str, set[str]]] = {}
    for lang, items in tasks.items():
        for key, text, _, _ in items:
            if key not in entries:
                entries[key] = (text, set())
            entries[key][1].add(lang)

    for key, (text, langs) in list(entries.items())[:20]:
        display_text = text[:50] + "..." if len(text) > 50 else text
        table.add_row(key[:40], display_text, ", ".join(sorted(langs)))

    if len(entries) > 20:
        table.add_row("...", f"({len(entries) - 20} more)", "")

    console.print(table)


async def _translate_file(
    catalog,
    file_path: Path,
    source_lang: str,
    translation_tasks: dict[str, list[tuple[str, str, str | None, dict | None]]],
    config: Config,
    preview: bool,
    backup: bool,
    batch_size: int | None,
    model: str | None,
    temperature: float | None,
    custom_prompt: str | None,
    no_app_context: bool,
) -> None:
    """Perform translations and update catalog."""
    cache_dir = get_cache_dir(config)
    actual_batch_size = batch_size or config.translator.batch_size
    actual_model = model or config.translator.model
    actual_temperature = temperature if temperature is not None else config.translator.temperature
    actual_custom_instructions = custom_prompt or config.translator.custom_instructions

    app_context = None
    if config.translator.use_app_context and not no_app_context:
        app_context = extract_app_context_string(source_lang)
        if app_context:
            console.print("[dim]Using extracted app context for translations[/dim]")

    thinking_level = getattr(config.translator, "thinking_level", "0")
    thinking_config = (
        {"thinkingLevel": thinking_level} if thinking_level not in ("0", "none", "") else None
    )

    async with GeminiTranslator(
        thinking_config=thinking_config,
        model=actual_model,
        batch_size=actual_batch_size,
        max_retries=config.translator.max_retries,
        cache_dir=cache_dir,
        temperature=actual_temperature,
        custom_instructions=actual_custom_instructions,
        app_context=app_context,
    ) as translator:
        all_translations: dict[str, dict[str, tuple[str, dict[str, str] | None]]] = (
            {}
        )  # key -> {lang: (translation, plural_forms)}

        for target_lang, entries in translation_tasks.items():
            console.print(f"  Translating to {get_language_name(target_lang)}...")

            requests = []
            for key, text, comment, source_variations in entries:
                # Extract plural forms if present
                plural_forms = None
                if source_variations and "plural" in source_variations:
                    plural_forms = {}
                    for form_name, form_data in source_variations["plural"].items():
                        if "stringUnit" in form_data:
                            plural_forms[form_name] = form_data["stringUnit"].get("value", "")

                requests.append(
                    TranslationRequest(
                        key=key, text=text, comment=comment, plural_forms=plural_forms
                    )
                )

            with create_progress() as progress:
                task = progress.add_task(f"    {target_lang}", total=len(requests))

                results = await translator.translate_batch(requests, source_lang, target_lang)

                for result in results:
                    if result.success:
                        if result.key not in all_translations:
                            all_translations[result.key] = {}
                        all_translations[result.key][target_lang] = (
                            result.translated,
                            result.translated_plurals,
                        )
                    progress.advance(task)

        # Show preview if requested
        if preview:
            _show_preview_table(all_translations, catalog)
            if not typer.confirm("Apply these translations?"):
                console.print("  [yellow]Cancelled[/yellow]")
                return

        # Update catalog
        for key, translations in all_translations.items():
            if key in catalog.strings:
                for lang, (value, translated_plurals) in translations.items():
                    # Build variations structure if we have plural translations
                    variations = None
                    if translated_plurals:
                        variations = {"plural": {}}
                        for form_name, form_value in translated_plurals.items():
                            variations["plural"][form_name] = {
                                "stringUnit": {"state": "translated", "value": form_value}
                            }

                    catalog.strings[key].translations[lang] = Translation(
                        value=value, variations=variations
                    )

        # Write file
        write_xcstrings(catalog, file_path, backup=backup)
        console.print(f"  [green]Saved {file_path}[/green]")


def _show_preview_table(
    translations: dict[str, dict[str, tuple[str, dict[str, str] | None]]], catalog
) -> None:
    """Show preview of translations."""
    table = Table(title="Translation Preview")
    table.add_column("Key", style="cyan")
    table.add_column("Source", style="white")
    table.add_column("Language", style="yellow")
    table.add_column("Translation", style="green")

    count = 0
    for key, lang_translations in translations.items():
        source = catalog.strings[key].source_text if key in catalog.strings else ""
        source_display = source[:30] + "..." if len(source) > 30 else source

        for lang, (trans, plurals) in lang_translations.items():
            if plurals:
                # Show plural forms preview
                plural_preview = ", ".join(
                    f"{k}: {v[:20]}..." if len(v) > 20 else f"{k}: {v}" for k, v in plurals.items()
                )
                trans_display = f"[plurals: {plural_preview[:40]}...]"
            else:
                trans_display = trans[:40] + "..." if len(trans) > 40 else trans
            table.add_row(key[:25], source_display, lang, trans_display)
            count += 1
            if count >= 30:
                break
        if count >= 30:
            break

    if len(translations) > 30:
        table.add_row("...", "", "", f"({sum(len(t) for t in translations.values()) - 30} more)")

    console.print(table)


def info(
    path: Annotated[
        Path,
        typer.Argument(help="Path to .xcstrings file", exists=True),
    ],
) -> None:
    """Show information about an .xcstrings file."""
    if path.suffix != ".xcstrings":
        console.print("[red]Error:[/red] Not an .xcstrings file")
        raise typer.Exit(1)

    catalog = read_xcstrings(path)

    console.print(f"[bold]File:[/bold] {path}")
    console.print(f"[bold]Source Language:[/bold] {catalog.source_language}")
    console.print(f"[bold]Total Strings:[/bold] {len(catalog.strings)}")

    # Count translations per language
    lang_counts: dict[str, int] = {}
    for entry in catalog.strings.values():
        for lang in entry.translations:
            lang_counts[lang] = lang_counts.get(lang, 0) + 1

    if lang_counts:
        console.print("\n[bold]Translations:[/bold]")
        table = Table()
        table.add_column("Language", style="cyan")
        table.add_column("Translated", style="green")
        table.add_column("Coverage", style="yellow")

        total = len(catalog.strings)
        for lang, count in sorted(lang_counts.items()):
            pct = (count / total * 100) if total > 0 else 0
            table.add_row(
                f"{get_language_name(lang)} ({lang})",
                str(count),
                f"{pct:.1f}%",
            )

        console.print(table)
    else:
        console.print("\n[yellow]No translations found[/yellow]")
