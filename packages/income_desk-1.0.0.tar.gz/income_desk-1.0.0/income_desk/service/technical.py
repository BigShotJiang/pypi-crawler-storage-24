"""TechnicalService: technical indicators and ORB computation."""

from __future__ import annotations

from typing import TYPE_CHECKING

import pandas as pd

from income_desk.models.technicals import ORBData, TechnicalSnapshot

if TYPE_CHECKING:
    from income_desk.broker.base import MarketDataProvider
    from income_desk.data.service import DataService


class TechnicalService:
    """Compute technical indicators and Opening Range Breakout levels."""

    def __init__(
        self,
        data_service: DataService | None = None,
        market_data: MarketDataProvider | None = None,
    ) -> None:
        self.data_service = data_service
        self._market_data = market_data

    def _get_ohlcv(self, ticker: str, ohlcv: pd.DataFrame | None) -> pd.DataFrame:
        if ohlcv is not None:
            return ohlcv
        if self.data_service is None:
            raise ValueError(
                "Either provide ohlcv DataFrame or initialize TechnicalService with a DataService"
            )
        return self.data_service.get_ohlcv(ticker)

    def snapshot(
        self, ticker: str, ohlcv: pd.DataFrame | None = None, debug: bool = False
    ) -> TechnicalSnapshot:
        """Compute technical indicators for a single instrument."""
        df = self._get_ohlcv(ticker, ohlcv)
        from income_desk.features.technicals import compute_technicals

        result = compute_technicals(df, ticker)

        if debug:
            rsi_zone = "overbought" if result.rsi.is_overbought else ("oversold" if result.rsi.is_oversold else "neutral")
            macd_desc = "bullish crossover" if result.macd.is_bullish_crossover else ("bearish crossover" if result.macd.is_bearish_crossover else "neutral")
            bb_position = "above upper" if result.current_price > result.bollinger.upper else ("below lower" if result.current_price < result.bollinger.lower else "within bands")
            result.commentary.extend([
                f"Technical snapshot for {ticker} at ${result.current_price:.2f}",
                f"RSI: {result.rsi.value:.1f} ({rsi_zone})",
                f"ATR: {result.atr:.2f} ({result.atr_pct:.2f}%)",
                f"MACD histogram: {result.macd.histogram:.4f} ({macd_desc})",
                f"Bollinger: {bb_position} (bandwidth {result.bollinger.bandwidth:.2f}%)",
                f"Signals: {', '.join(s.name + '=' + s.direction for s in result.signals[:5])}",
            ])

        return result

    def orb(
        self,
        ticker: str,
        intraday: pd.DataFrame | None = None,
        daily_atr: float | None = None,
    ) -> ORBData:
        """Compute Opening Range Breakout from intraday data.

        Args:
            ticker: Instrument ticker.
            intraday: Intraday OHLCV DataFrame (1m/5m bars).
                      If None, fetches via yfinance.
            daily_atr: Optional daily ATR for context. Auto-computed if
                       data_service available and daily_atr is None.
        """
        from income_desk.features.orb import compute_orb

        # Try broker intraday candles first, then yfinance fallback
        if intraday is None and self._market_data is not None:
            try:
                broker_df = self._market_data.get_intraday_candles(ticker, "5m")
                if not broker_df.empty:
                    intraday = broker_df
            except Exception:
                pass  # fall through to yfinance

        if intraday is None:
            import yfinance as yf

            intraday = yf.download(ticker, period="1d", interval="5m", progress=False)
            if intraday.empty:
                raise ValueError(f"No intraday data available for {ticker}")
            if isinstance(intraday.columns, pd.MultiIndex):
                intraday.columns = intraday.columns.get_level_values(0)

        if daily_atr is None and self.data_service is not None:
            try:
                from income_desk.features.technicals import compute_atr

                ohlcv = self.data_service.get_ohlcv(ticker)
                atr_series = compute_atr(
                    ohlcv["High"], ohlcv["Low"], ohlcv["Close"], 14
                )
                if not atr_series.empty and not pd.isna(atr_series.iloc[-1]):
                    daily_atr = float(atr_series.iloc[-1])
            except Exception:
                pass  # ATR is optional context; don't fail ORB over it

        return compute_orb(intraday, ticker, daily_atr=daily_atr)
