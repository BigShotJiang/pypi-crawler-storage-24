"""
Tests for the arithmetic operators on Field.
The tests check that the binary operations are properly called
by comparing the returned Field's dataframe's values with the
explicit numpy operations. It also tests that the appropriate
exceptions are raised when the operands are incompatible and
when the grid types / indices do not match
"""

TEST_DATA_LONLAT_NAME = 'anpp_spain_1990_2010.out.gz'

import canopy as cp
import numpy as np
import pytest
import random

def test_sum_many_many():

    f_L = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    f_R = f_L
    f = f_L + f_R
    
    assert np.allclose(f.data.values, np.add(f_L.data.values, f_R.data.values))


def test_sub_many_many():

    f_L = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    f_R = f_L
    f = f_L - f_R
    
    assert np.allclose(f.data.values, np.subtract(f_L.data.values, f_R.data.values))


def test_mul_many_many():

    f_L = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    f_R = f_L
    f = f_L * f_R
    
    assert np.allclose(f.data.values, np.multiply(f_L.data.values, f_R.data.values))


@pytest.mark.filterwarnings("ignore:divide by zero:RuntimeWarning")
@pytest.mark.filterwarnings("ignore:invalid value:RuntimeWarning")
def test_div_many_many():

    f_L = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    f_R = f_L
    f = f_L / f_R
    v = np.divide(f_L.data.values, f_R.data.values)

    assert np.allclose(f.data.values, v, equal_nan=True)


def test_sum_1_many():

    f_R = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    f_L = f_R['Total']
    f = f_L + f_R
    
    assert np.allclose(f.data.values, np.add(f_L.data.values, f_R.data.values))


def test_sub_1_many():

    f_R = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    f_L = f_R['Total']
    f = f_L - f_R
    
    assert np.allclose(f.data.values, np.subtract(f_L.data.values, f_R.data.values))


def test_mul_1_many():

    f_R = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    f_L = f_R['Total']
    f = f_L * f_R
    
    assert np.allclose(f.data.values, np.multiply(f_L.data.values, f_R.data.values))


@pytest.mark.filterwarnings("ignore:divide by zero:RuntimeWarning")
@pytest.mark.filterwarnings("ignore:invalid value:RuntimeWarning")
def test_div_1_many():

    f_R = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    f_L = f_R['Total']
    f = f_L / f_R
    v = np.divide(f_L.data.values, f_R.data.values)

    assert np.allclose(f.data.values, v, equal_nan=True)


def test_sum_many_1():

    f_L = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    f_R = f_L['Total']
    f = f_L + f_R
    
    assert np.allclose(f.data.values, np.add(f_L.data.values, f_R.data.values))


def test_sub_many_1():

    f_L = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    f_R = f_L['Total']
    f = f_L - f_R
    
    assert np.allclose(f.data.values, np.subtract(f_L.data.values, f_R.data.values))


def test_mul_many_1():

    f_L = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    f_R = f_L['Total']
    f = f_L * f_R
    
    assert np.allclose(f.data.values, np.multiply(f_L.data.values, f_R.data.values))


@pytest.mark.filterwarnings("ignore:divide by zero:RuntimeWarning")
@pytest.mark.filterwarnings("ignore:invalid value:RuntimeWarning")
def test_div_many_1():

    f_L = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    f_R = f_L['Total']
    f = f_L / f_R
    v = np.divide(f_L.data.values, f_R.data.values)

    assert np.allclose(f.data.values, v, equal_nan=True)


def test_sum_scalar_left():

    f_L = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    scalar = random.random()
    f = f_L + scalar
    
    assert np.allclose(f.data.values, np.add(f_L.data.values, scalar))


def test_sub_scalar_left():

    f_L = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    scalar = random.random()
    f = f_L - scalar
    
    assert np.allclose(f.data.values, np.subtract(f_L.data.values, scalar))


def test_mul_scalar_left():

    f_L = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    scalar = random.random()
    f = f_L * scalar
    
    assert np.allclose(f.data.values, np.multiply(f_L.data.values, scalar))


@pytest.mark.filterwarnings("ignore:divide by zero:RuntimeWarning")
@pytest.mark.filterwarnings("ignore:invalid value:RuntimeWarning")
def test_div_scalar_left():

    f_L = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    scalar = random.random()
    f = f_L / scalar
    
    assert np.allclose(f.data.values, np.divide(f_L.data.values, scalar))


def test_sum_scalar_right():

    f_L = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    scalar = random.random()
    f = scalar + f_L
    
    assert np.allclose(f.data.values, np.add(scalar, f_L.data.values))


def test_sub_scalar_right():

    f_L = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    scalar = random.random()
    f = scalar - f_L
    
    assert np.allclose(f.data.values, np.subtract(scalar, f_L.data.values))


def test_mul_scalar_right():

    f_L = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    scalar = random.random()
    f = scalar * f_L
    
    assert np.allclose(f.data.values, np.multiply(scalar, f_L.data.values))


@pytest.mark.filterwarnings("ignore:divide by zero:RuntimeWarning")
@pytest.mark.filterwarnings("ignore:invalid value:RuntimeWarning")
def test_div_scalar_right():

    f_L = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    scalar = random.random()
    f = scalar / f_L
    
    assert np.allclose(f.data.values, np.divide(scalar, f_L.data.values))


def test_bad_broadcast():

    f_L = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    f_R = f_L[f_L.layers[:3]]

    with pytest.raises(ValueError, match=r'operands could not be broadcast together'):
        _ = f_L + f_R


def test_different_grids():

    f_L = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    f_R = cp.Field(f_L.data, cp.core.grid.create_grid('sites'))

    with pytest.raises(ValueError, match=r'Field grids are of different type.'):
        _ = f_L + f_R


def test_different_indices():

    f_L = cp.load_test_data(TEST_DATA_LONLAT_NAME)
    df = f_L.data.reset_index()
    df['lon'] += 0.1
    df['lat'] += 0.1
    df = df.set_index(['lon', 'lat', 'time'])
    grid = cp.core.grid.get_grid('lonlat').from_frame(df, dlon = f_L.grid.dlon, dlat = f_L.grid.dlat)
    f_R = cp.Field(df, grid)

    with pytest.raises(ValueError, match=r'Indices do not match.'):
        _ = f_L + f_R
