import json
import os
from dataclasses import dataclass
from types import MappingProxyType
from canopy.core.field import Field


class _TestDataRegistry:
    """Read-only mapping of test data with a readable repr."""

    def __init__(self, data):
        self._data = MappingProxyType(data)

    def __repr__(self):
        lines = []
        for fname, info in self._data.items():
            lines.append(f"  {fname}:")
            lines.append(f"    description: {info.description}")
            lines.append(f"    file_format: {info.file_format}")
            lines.append(f"    grid_type: {info.grid_type}")
            lines.append(f"    source: {info.source}")
        return "Test data:\n" + "\n".join(lines)

    def __getitem__(self, key):
        return self._data[key]

    def __iter__(self):
        return iter(self._data)

    def __len__(self):
        return len(self._data)

    def keys(self):
        return self._data.keys()

    def items(self):
        return self._data.items()

    def values(self):
        return self._data.values()


@dataclass
class TestDataInfo:
    description: str = ""
    file_format: str = ""
    grid_type: str = ""
    source: str = ""

_test_data_info = {}


def _load_test_data_registry():

    with open(f'{os.path.dirname(__file__)}/registry.json') as f:
        test_data = json.load(f)
    for fname, data in test_data.items():
        td = TestDataInfo(description=data['description'],
                          file_format=data['file_format'],
                          grid_type=data['grid_type'],
                          source=data['source']
                          )
        _test_data_info[fname] = td


def load_test_data(fname: str) -> Field:
    '''Load a test data field

    Parameters
    ----------
    fname : str | None
        The name of the data file to load.

    Returns
    -------
        A Field object derived from the data file.
    '''
    path = f'{os.path.dirname(__file__)}'
    tdi = _test_data_info[fname]
    field = Field.from_file(f'{path}/{fname}', file_format=tdi.file_format, grid_type=tdi.grid_type, source=tdi.source)

    return field


def list_test_data():
    return _TestDataRegistry(_test_data_info)


_load_test_data_registry()


