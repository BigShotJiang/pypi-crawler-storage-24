import numpy as np
import pandas as pd
from typing import Dict, Tuple, Any, Callable
from canopy.core.frameops import check_indices_match

# Since indices are the same, the dataframes have the same number of rows.
# Therefore the only way they can be combined is if they have the same
# number of columns OR one of them has only 1 column (numpy broadcasting)

def _check_operands(op1: pd.DataFrame | float, op2: pd.DataFrame | float) -> None:

    if isinstance(op1, pd.DataFrame) and isinstance(op2, pd.DataFrame):
        check_indices_match(op1, op2)
    elif isinstance(op1, pd.DataFrame) and not isinstance(op2, float):
        raise ValueError(f"Operand {op2} must be a DataFrame or a scalar")
    elif isinstance(op2, pd.DataFrame) and not isinstance(op1, float):
        raise ValueError(f"Operand {op1} must be a DataFrame or a scalar")
    elif not isinstance(op1, pd.DataFrame) and not isinstance(op2, pd.DataFrame):
        raise ValueError("At least one of the operands must be a DataFrame.")


def _get_values(op1: pd.DataFrame | float, op2 = pd.DataFrame | float) -> Tuple[np.ndarray | float, np.ndarray | float]:

    values: Tuple = tuple()
    for operand in (op1, op2):
        if isinstance(operand, pd.DataFrame):
            values += (operand.values, )
        else:
            values += (float(operand), )

    return values


def _get_index(op1: pd.DataFrame | float, op2 = pd.DataFrame | float) -> pd.Index:

    if isinstance(op1, pd.DataFrame):
        return op1.index
    elif isinstance(op2, pd.DataFrame):
        return op2.index
    else:
        raise ValueError("At least one of the operands must be a DataFrame.")


def binary_operation(op1: pd.DataFrame | float, op2: pd.DataFrame | float, operation: str) -> pd.DataFrame:

    b_ops: Dict[str, Callable] = {
            "+": np.add,
            "-": np.subtract,
            "*": np.multiply,
            "/": np.divide,
    }

    _check_operands(op1, op2)

    val1, val2 = _get_values(op1, op2)

    index = _get_index(op1, op2)

    df = pd.DataFrame(b_ops[operation](val1, val2), index=index)

    return df

