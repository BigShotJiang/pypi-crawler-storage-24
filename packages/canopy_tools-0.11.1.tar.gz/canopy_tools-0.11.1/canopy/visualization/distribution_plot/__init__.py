"""Distribution plot visualization."""

from canopy.visualization.distribution_plot.distribution_plot import make_distribution_plot

__all__ = ["make_distribution_plot"]
