"""Map visualization module."""

from canopy.visualization.map.simple_map import make_simple_map
from canopy.visualization.map.diff_map import make_diff_map

# Define public API of map module
__all__ = ["make_simple_map", "make_diff_map"]
