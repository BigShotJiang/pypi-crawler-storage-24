"""Shared helpers for make_simple_map and make_diff_map."""

import warnings
from pathlib import Path
from typing import Optional, List, Any, Union

import cartopy.crs as ccrs
import cartopy.feature as feature
import jenkspy
import matplotlib.colors as colors
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from matplotlib.patches import Rectangle

import canopy as cp
from canopy.visualization.multiple_figs import setup_figure_and_axes
from canopy.visualization.visualization_helpers import get_color_palette, make_dark_mode, save_figure_png
from canopy.visualization.map.projections import projections

def plot_map(
    xx: np.ndarray,
    yy: np.ndarray,
    raster: np.ndarray,
    labels: Union[bool, list],
    output_file: Optional[str],
    cb_label: str,
    title: Optional[str],
    unit: str,
    n_classes: int,
    bins: np.ndarray,
    palette: Optional[str],
    custom_palette: Optional[str],
    orientation: str,
    extend: str,
    proj: str,
    dark_mode: bool,
    stats_annotation: bool,
    x_fig: float,
    y_fig: float,
    nonsig_mask: Optional[np.ndarray],
    hist: bool,
    subfig=None,
) -> plt.Figure:
    """
    Creates and saves a map plot.
    """
    # Check if raster is 2D
    if not isinstance(raster, np.ndarray) or raster.ndim != 2:
        raise ValueError("raster must be a 2D NumPy array")
    
    # Extend palette if needed
    if extend != "neither":
        if extend == "both":
            n_classes += 2
        else:
            n_classes += 1

    # Create a colormap based on the provided palette
    palette, palette_dict = get_color_palette(n_classes, palette=palette, custom_palette=custom_palette)
    cmap = colors.ListedColormap(palette)
    
    # Discretize the data into bins
    norm = colors.BoundaryNorm(boundaries=bins, ncolors=n_classes, extend=extend)
    
    # Create histogram
    if hist is True and output_file:
        _plot_palette_hist(raster, output_file, cb_label, unit, bins, palette, dark_mode)

    # Create the figure and axis with projection
    fig, ax = setup_figure_and_axes(subfig=subfig, x_fig=x_fig, y_fig=y_fig, 
                                    projection=projections[proj], constrained_layout=True)

    # Plot data
    filled = ax.pcolormesh(xx, yy, raster, cmap=cmap, norm=norm, shading='auto',
                           transform=ccrs.PlateCarree())

    # Add title, map features, colorbar, and colorbar label
    if title:
        ax.set_title(title, fontsize="xx-large", pad=15)

    ax, gridlines = _add_map_features(ax)

    if labels is False: # Quantitative map
        cbar = _add_colorbar_quant(fig, ax, filled, bins, orientation, extend)
        cbar_label = f"{cb_label} (in {unit})" if unit != "[no units]" else cb_label
        cbar.set_label(cbar_label, fontsize=16, labelpad=10)
        cbar.ax.xaxis.set_label_position('top')

    else:               # Qualitative map
        cbar = _add_colorbar_quali(fig, ax, filled, bins, orientation, labels)

    # Add statistics annotation
    if stats_annotation:
        # Compute mean and std of non-NaN values
        mean_val = np.nanmean(raster)
        std_val = np.nanstd(raster)
        stat_text = f"Mean: {mean_val:.2f} {unit}\nσ: {std_val:.2f} {unit}"

        # Add text in axes coordinates (bottom left)
        ax.text(0.02, 0.02, stat_text, transform=ax.transAxes, fontsize=12, 
                verticalalignment='bottom', horizontalalignment='left',
                bbox=dict(facecolor='white', alpha=0.5, edgecolor='black'))

    if nonsig_mask is not None:
        ax.contourf(xx, yy, nonsig_mask, levels=[0.5, 1.5], hatches=['///'], alpha=0, transform=ccrs.PlateCarree())

    # Dark mode
    if dark_mode:
        fig, ax = make_dark_mode(fig, ax, cbar=cbar, gridlines=gridlines)
    
    return fig


def _plot_palette_hist(
    raster: np.ndarray,
    output_file: str,
    cb_label: str,
    unit: str,
    bins: np.ndarray,
    palette: List[Any],
    dark_mode: bool,
) -> None:
    """
    Creates and saves an histogram plot of the raster compared to the palette choosen.
    """
    # Make 2d raster, 1d
    flattened_raster = raster.flatten()

    fig = plt.figure(constrained_layout=True)
    ax = fig.add_subplot(1, 1, 1)

    # Dark mode
    if dark_mode is True:
        fig, ax = make_dark_mode(fig, ax)

    # Add colored rectangles for each bin
    for i in range(len(bins) - 1):
        ax.add_patch(Rectangle((bins[i], 0), bins[i + 1] - bins[i], 1, 
                     color=palette[i], alpha=0.3, transform=ax.get_xaxis_transform()))
    
    ax.set_xticks(bins)
    ax.set_xticklabels(_format_numbers(bins))

    # Create the histogram
    sns.histplot(flattened_raster, kde=False, ax=ax)

    # Add labels
    ax.set_ylabel("Frequency", fontsize="large")
    title = f"{cb_label} (in {unit})" if unit != "[no units]" else cb_label
    ax.set_title(title, fontsize=16)

    output_path = Path(output_file)
    output_file_modified = output_path.with_stem(output_path.stem + "_hist")
    save_figure_png(output_file_modified)

    plt.close()


def _add_map_features(ax: Any) -> tuple[Any, Any]:
    """
    Add land, coastlines, and gridlines to the map.
    """
    # Draw land and ocean
    ax.add_feature(feature.LAND, facecolor="silver")
    ax.coastlines(linewidth=0.5, color='black')
    # Gridlines labels
    gridlines = ax.gridlines(draw_labels={"top": True, "left": True, "right": False, "bottom": False})

    return ax, gridlines


def _add_colorbar_quant(
    fig: plt.Figure,
    ax: Any,
    filled: Any,
    bins: np.ndarray,
    orientation: str,
    extend: str,
) -> Any:
    """
    Add a quantitative colorbar to the map.
    """    
    cbar = fig.colorbar(filled, ax=ax, orientation=orientation, ticks=bins, shrink=0.7, pad=0.01, extend=extend)
    cbar.set_ticklabels(_format_numbers(bins))
    
    return cbar


def _add_colorbar_quali(
    fig: plt.Figure,
    ax: Any,
    filled: Any,
    bins: np.ndarray,
    orientation: str,
    labels: dict,
) -> Any:
    """
    Add a qualitative colorbar to the map.
    """
    cbar = fig.colorbar(filled, ax=ax, orientation=orientation, shrink=0.7, pad=0.03)
    midpoints = (bins[:-1] + bins[1:]) / 2
    tick_labels = [labels.get(i, '') for i in range(len(bins) - 1)]
    cbar.set_ticks(midpoints)
    cbar.set_ticklabels(tick_labels)
    # Hide the colorbar edges ticks
    cbar.ax.xaxis.set_ticks_position('none')
    
    return cbar


def _format_numbers(numbers: np.ndarray) -> List[str]:
    """
    Format bin values for better readability
    """
    formatted_numbers = []
    for value in numbers:
        if value == 0:
            formatted_numbers.append('0')
        elif abs(value) > 999 or abs(value) < 0.01:
            # Use scientific notation for values > 999 or < 0.01
            formatted_numbers.append(f'{value:.1e}')
        else:
            # Round rest values to 2 decimal places
            rounded_value = round(value, 2)
            if rounded_value.is_integer():
                formatted_numbers.append(f'{int(rounded_value)}')
            else:
                formatted_numbers.append(f'{rounded_value:.2f}')
    
    return formatted_numbers


# ---------------------------------------------------------------------------
# Data preparation helpers
# ---------------------------------------------------------------------------

def get_metadata(
    field: Union[cp.Field, Any],
    cb_label: Optional[str],
    unit: Optional[str],
) -> tuple[str, str]:
    """
    Safely retrieve metadata (name and units) from a Field or Raster object.
    Returns (cb_label, unit), using provided values if metadata is not available.
    """
    try:
        if not cb_label and getattr(field, 'metadata', None) and field.metadata['name'] != "[no name]":
            cb_label = field.metadata['name']
        if hasattr(field, 'metadata'):
            unit = unit or field.metadata['units']
    except AttributeError as e:
        if "'Raster' object has no attribute 'metadata'" in str(e):
            print("can't retrieve metadata from raster")
            cb_label, unit = "Unknown"
        else:
            raise
    return cb_label, unit


def safe_red_time(field: Union[cp.Field, Any], timeop: str) -> Union[cp.Field, Any]:
    """
    Safely apply reduce_time to a Field, or return the object if not available (e.g., Raster).
    Handles AttributeError and ValueError for unsupported frequency.
    """
    try:
        return field.reduce_time(timeop, inplace=False)
    except AttributeError as e:
        if "'Raster' object has no attribute 'reduce_time'" in str(e):
            return field
        else:
            raise
    except ValueError as e:
        if str(e) == "Data must have yearly or monthly frequency.":
            return field
        else:
            raise


def safe_make_raster(field: Union[cp.Field, Any], layer: str) -> Any:
    """
    Safely create a raster from a Field or return the object if it is already a Raster.
    Handles AttributeError if the object has no 'data' attribute (i.e., is already a Raster).
    """
    try:
        return cp.make_raster(field, layer)
    except AttributeError as e:
        if "'Raster' object has no attribute 'data'" in str(e):
            return field
        raise


def calculate_bins(
    raster: np.ndarray,
    n_classes: int,
    classification: Union[List[float], str],
    force_zero: bool = False,
    diff_map: bool = False,
) -> np.ndarray:
    """
    Calculate bin edges based on the maximum value and desired scales.
    """
    def center_zero(bins): # take the closest bin to zero and force it to be zero
        bins = np.array(bins)
        bins[np.argmin(np.abs(bins))] = 0
        return bins

    max_val = np.nanmax(raster)
    min_val = np.nanmin(raster)

    if max_val == 0:
        raise ValueError("Maximum value is 0, raster likely empty.")
    if diff_map and n_classes % 2 != 0:
        raise ValueError("with diff_map, n_classes should be an even number.")

    if isinstance(classification, list):
        bin_edges = np.array(classification)

    elif classification == "linear":
        # Linear classification
        scale = 10 ** np.floor(np.log10(max_val))  # Find the largest power of 10 less than or equal to max_value
        bin_max = scale * np.ceil(max_val / scale)  # Round up to the nearest multiple of scale
        if bin_max - max_val > scale / 2:
            bin_max -= scale / 2  # Adjust by subtracting half the scale
        
        bin_edges = np.linspace(min_val, bin_max, n_classes + 1)

    elif classification == "quantile":
        bin_edges = np.nanpercentile(raster, np.linspace(0, 100, n_classes + 1))
        # Ensure strictly increasing bin edges by nudging duplicates
        bin_edges = bin_edges.astype(float)
        data_range = max_val - min_val
        # Choose an epsilon relative to data range; fall back to a tiny constant if range is 0
        eps = 1e-12 if data_range == 0 or not np.isfinite(data_range) else max(1e-12, 1e-9 * data_range)
        adjusted = False
        for i in range(1, len(bin_edges)):
            if not np.isfinite(bin_edges[i-1]):
                continue
            if not np.isfinite(bin_edges[i]) or bin_edges[i] <= bin_edges[i-1]:
                bin_edges[i] = bin_edges[i-1] + eps
                adjusted = True
        if adjusted:
            warnings.warn(
                "Edges were adjusted slightly to ensure monotonicity.", UserWarning
            )

    elif classification == "jenks":
        flat = raster[np.isfinite(raster)].flatten()
        bin_edges = jenkspy.jenks_breaks(flat, n_classes)

    elif classification == "std":
        mean = np.nanmean(raster)
        std = np.nanstd(raster)
        if n_classes % 2 != 0:
            raise ValueError("n_classes should be even for 'std' classification.")
        half = n_classes // 2
        bin_edges = [mean + i * std for i in range(-half, half + 1)]

    else:
        raise ValueError("Invalid classification. Use 'linear', 'quantile', 'jenks', 'std', or a list.")

    if diff_map and force_zero:
        bin_edges = center_zero(bin_edges)
    if force_zero:
        bin_edges[0] = 0

    return np.array(bin_edges)
