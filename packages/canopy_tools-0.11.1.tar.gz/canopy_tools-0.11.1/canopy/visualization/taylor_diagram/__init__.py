"""Taylor diagram visualization."""

from canopy.visualization.taylor_diagram.taylor_diagram import make_taylor_diagram

__all__ = ["make_taylor_diagram"]
