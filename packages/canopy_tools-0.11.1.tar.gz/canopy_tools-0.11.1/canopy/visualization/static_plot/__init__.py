"""Static plot visualization (scatter, hist, kde)."""

from canopy.visualization.static_plot.static_plot import make_static_plot

__all__ = ["make_static_plot"]
