"""Line plot visualizations (time series, latitudinal)."""

from canopy.visualization.line_plot.time_series import make_time_series
from canopy.visualization.line_plot.latitudinal_plot import make_latitudinal_plot

__all__ = ["make_time_series", "make_latitudinal_plot"]
