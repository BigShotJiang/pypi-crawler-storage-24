"""Shared helpers for line plot visualizations (time series, latitudinal)."""

from typing import Optional, Tuple, List, Any

import matplotlib.pyplot as plt
from matplotlib.axes import Axes
from matplotlib.lines import Line2D
import seaborn as sns

MAX_GRIDCELLS = 20


def var_case_matrix(
    n_fields: int,
    n_layers: int,
    grid_not_reduced: bool,
    reverse_hue_style: bool,
) -> Tuple[Optional[str], Optional[str]]:
    """Return (hue_var, style_var) from case matrix."""
    case = (n_fields > 1, n_layers > 1, grid_not_reduced)
    hue, style = None, None

    match case:
        case (False, False, False):
            pass
        case (False, False, True):
            hue = "gridcell"
        case (False, True, False):
            hue = "layer"
        case (False, True, True):
            hue, style = ("layer", "gridcell") if not reverse_hue_style else ("gridcell", "layer")
        case (True, False, False):
            hue = "field_label"
        case (True, False, True):
            hue, style = ("field_label", "gridcell") if not reverse_hue_style else ("gridcell", "field_label")
        case (True, True, False):
            hue, style = ("field_label", "layer") if not reverse_hue_style else ("layer", "field_label")

    return hue, style


def get_n_hue_classes(
    hue_var: Optional[str],
    time_series: List[Any],
    n_fields: int,
    n_layers: int,
    max_gridcells: int = MAX_GRIDCELLS,
) -> int:
    """Estimate the number of classes for the line colour (hue) based on the case matrix."""
    match hue_var:
        case "gridcell":
            n_classes = min(max_gridcells, sum(ts.shape[1] for ts in time_series) // max(1, n_fields))
        case "layer":
            n_classes = n_layers
        case "field_label":
            n_classes = n_fields
        case _:
            n_classes = 1

    return max(1, n_classes)


def apply_legend_style(
    plot: Axes,
    legend_style: str,
    max_labels_per_col: int,
    move_legend: bool,
    rolling_size: Optional[int] = None,
    hue_var: Optional[str] = None,
    style_var: Optional[str] = None,
) -> None:
    """Apply the selected legend style to the figure."""
    if legend_style == 'hidden':
        plot.legend().set_visible(False)
        return

    handles, labels = plot.get_legend_handles_labels()
    num_labels = len(labels)
    if num_labels == 0:
        return

    if rolling_size:
        dummy = Line2D([0], [0], color='none', linestyle='none', marker='none')
        dash = Line2D([0], [0], color='black', linestyle='--', linewidth=2)
        solid = Line2D([0], [0], color='black', linestyle='-', linewidth=2)
        handles = [dummy] + list(handles) + [dummy, dash, solid]
        labels = ['Line colour'] + list(labels) + ['Line style', 'Original data', f'Rolling mean (year={rolling_size})']
        num_labels = len(labels)
    ncols = max(1, (num_labels + max_labels_per_col - 1) // max_labels_per_col)

    if legend_style == 'default':
        var_names = {'layer', 'field_label', 'gridcell'}
        rename = {hue_var: "Line colour", style_var: "Line style"} if (hue_var or style_var) else {}
        drop = var_names - rename.keys()
        new_labels = [rename.get(l, None if l in drop else l) for l in labels]
        new_handles = [h for h, lbl in zip(handles, new_labels) if lbl is not None]
        new_labels = [l for l in new_labels if l is not None]
        if new_handles:
            plot.legend(handles=new_handles, labels=new_labels, loc='best', frameon=False, fontsize=14, ncols=ncols)

    elif legend_style == 'highlighted':
        plot.legend(handlelength=0, handletextpad=0, labelcolor='linecolor', loc='best',
                    frameon=False, fontsize=14, ncols=ncols)

    elif legend_style == 'end-of-line':
        plot.legend().set_visible(False)
        lines = plot.get_lines()
        for idx, col in enumerate(plot.get_legend().get_texts()):
            label = col.get_text()
            x_data = lines[idx].get_xdata()
            y_data = lines[idx].get_ydata()
            if len(x_data) > 0 and len(y_data) > 0:
                plt.text(x_data[-1], y_data[-1], ' ' + label, color=lines[idx].get_color(),
                         verticalalignment='center', fontsize=14)
    else:
        raise ValueError("Invalid legend_style. Choose from 'default', 'highlighted', 'end-of-line', or 'hidden'.")

    if move_legend is True:
        sns.move_legend(plot, "center left", bbox_to_anchor=(1, 0.85), ncols=ncols)
