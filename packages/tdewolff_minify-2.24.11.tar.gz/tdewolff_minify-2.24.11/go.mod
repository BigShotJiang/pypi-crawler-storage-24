module github.com/tdewolff/minify/bindings/js

go 1.25.8

require (
	github.com/tdewolff/minify/v2 v2.24.10
	github.com/tdewolff/parse/v2 v2.8.11
)
