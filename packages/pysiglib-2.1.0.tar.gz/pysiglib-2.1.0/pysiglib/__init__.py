# Copyright 2025 Daniil Shmelev
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# =========================================================================

from .load_siglib import SYSTEM, BUILT_WITH_CUDA, BUILT_WITH_AVX
from .words import words_of_length, words, lyndon_words_of_length, lyndon_words, is_lyndon, word_to_idx, idx_to_word
from .sig_length import sig_length, log_sig_length
from .sig import sig_combine, sig
from .sig_backprop import sig_backprop, sig_combine_backprop
from .sig_coef import extract_sig_coef, sig_coef
from .sig_coef_backprop import sig_coef_backprop
from .log_sig import set_cache_dir, prepare_log_sig, clear_cache, sig_to_log_sig, log_sig
from .log_sig_backprop import sig_to_log_sig_backprop
from .sig_kernel import sig_kernel, sig_kernel_gram
from .sig_kernel_backprop import sig_kernel_backprop, sig_kernel_gram_backprop
from .sig_metrics import sig_score, expected_sig_score, sig_mmd
from .transform_path import transform_path
from .transform_path_backprop import transform_path_backprop
from .static_kernels import Context, StaticKernel, LinearKernel, ScaledLinearKernel, RBFKernel

signature = sig

import pysiglib.torch_api

__version__ = "2.1.0"
