"""Tests for LangChain waveStreamer tools (TEST-22 through TEST-30)."""

from unittest.mock import MagicMock, patch

import pytest
from langchain_core.tools import BaseTool


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_client():
    """Return a MagicMock that stands in for the WaveStreamer SDK client."""
    return MagicMock()


@pytest.fixture
def toolkit(mock_client):
    """Create a WaveStreamerToolkit with a mocked WaveStreamer client."""
    with patch("langchain_wavestreamer.tools.WaveStreamer") as MockWS:
        MockWS.return_value = mock_client
        # Keep the static method accessible on the class
        MockWS.resolution_protocol_from_question = MagicMock(
            return_value={
                "criterion": "test",
                "source_of_truth": "test",
                "deadline": "2026-12-31T00:00:00Z",
                "resolver": "admin",
                "edge_cases": "",
            }
        )
        from langchain_wavestreamer.tools import WaveStreamerToolkit

        tk = WaveStreamerToolkit(base_url="http://test", api_key="sk_test")
        # Stash the patched class so tests can inspect static-method calls
        tk._MockWS = MockWS
        yield tk


@pytest.fixture
def tools(toolkit):
    """Return the list of tools from the toolkit."""
    return toolkit.get_tools()


def _tool_by_name(tools, name: str) -> BaseTool:
    """Helper to find a tool by name."""
    for t in tools:
        if t.name == name:
            return t
    raise KeyError(f"Tool {name!r} not found")


# ---------------------------------------------------------------------------
# TEST-22: RegisterAgentTool calls SDK register() with correct params
# ---------------------------------------------------------------------------

class TestRegisterAgent:
    def test_calls_register_with_params(self, toolkit, mock_client):
        mock_client.register.return_value = {
            "api_key": "sk_new_key",
            "user": {
                "name": "TestBot",
                "points": 5000,
                "tier": "analyst",
                "referral_code": "REF123",
            },
        }
        tool = _tool_by_name(toolkit.get_tools(), "register_agent")
        result = tool.invoke({"name": "TestBot", "model": "gpt-4o"})

        mock_client.register.assert_called_once_with(
            "TestBot",
            model="gpt-4o",
            referral_code="",
            persona_archetype="",
            risk_profile="",
            role="",
            domain_focus="",
            philosophy="",
        )
        assert "sk_new_key" in result
        assert "TestBot" in result

    def test_returns_error_on_failure(self, toolkit, mock_client):
        mock_client.register.side_effect = Exception("name taken")
        tool = _tool_by_name(toolkit.get_tools(), "register_agent")
        result = tool.invoke({"name": "Dup", "model": "gpt-4o"})
        assert "Registration failed" in result

    def test_passes_optional_fields(self, toolkit, mock_client):
        mock_client.register.return_value = {
            "api_key": "sk_k",
            "user": {"name": "X", "points": 5000, "tier": "analyst", "referral_code": ""},
        }
        tool = _tool_by_name(toolkit.get_tools(), "register_agent")
        tool.invoke({
            "name": "X",
            "model": "claude-sonnet-4-5",
            "referral_code": "ABC",
            "persona_archetype": "contrarian",
            "risk_profile": "aggressive",
            "role": "predictor,debater",
            "domain_focus": "ai-policy",
            "philosophy": "Always bet against consensus",
        })
        mock_client.register.assert_called_once_with(
            "X",
            model="claude-sonnet-4-5",
            referral_code="ABC",
            persona_archetype="contrarian",
            risk_profile="aggressive",
            role="predictor,debater",
            domain_focus="ai-policy",
            philosophy="Always bet against consensus",
        )


# ---------------------------------------------------------------------------
# TEST-23: PlacePredictionTool fetches question, builds resolution_protocol
# ---------------------------------------------------------------------------

class TestPlacePrediction:
    REASONING = (
        "EVIDENCE: Multiple benchmarks show improvement. "
        "ANALYSIS: The trend indicates a clear upward trajectory in model performance. "
        "COUNTER-EVIDENCE: Some benchmarks show saturation in certain tasks. "
        "BOTTOM LINE: Overall positive outlook for the next generation of models."
    )

    def _setup_question(self, mock_client):
        mock_client.get_question.return_value = {
            "question": {
                "id": "q1",
                "question": "Will GPT-5 ship?",
                "status": "open",
            }
        }

    def test_probability_path(self, toolkit, mock_client):
        self._setup_question(mock_client)
        tool = _tool_by_name(toolkit.get_tools(), "place_prediction")
        result = tool.invoke({
            "question_id": "q1",
            "probability": 80,
            "reasoning": self.REASONING,
        })

        mock_client.get_question.assert_called_once_with("q1")
        toolkit._MockWS.resolution_protocol_from_question.assert_called_once()
        mock_client.predict.assert_called_once()
        call_kwargs = mock_client.predict.call_args
        assert call_kwargs[0][0] == "q1"  # question_id
        assert call_kwargs[1]["probability"] == 80
        assert "resolution_protocol" in call_kwargs[1]
        assert "YES" in result

    def test_legacy_prediction_confidence_path(self, toolkit, mock_client):
        self._setup_question(mock_client)
        tool = _tool_by_name(toolkit.get_tools(), "place_prediction")
        result = tool.invoke({
            "question_id": "q1",
            "prediction": False,
            "confidence": 70,
            "reasoning": self.REASONING,
        })

        mock_client.predict.assert_called_once()
        args = mock_client.predict.call_args[0]
        assert args[0] == "q1"
        assert args[1] is False
        assert args[2] == 70
        assert "NO" in result

    def test_discussion_confidence_yes_no_path(self, toolkit, mock_client):
        self._setup_question(mock_client)
        tool = _tool_by_name(toolkit.get_tools(), "place_prediction")
        result = tool.invoke({
            "question_id": "q1",
            "confidence_yes": 30,
            "confidence_no": 70,
            "reasoning": self.REASONING,
        })

        mock_client.predict.assert_called_once()
        kw = mock_client.predict.call_args[1]
        assert kw["confidence_yes"] == 30
        assert kw["confidence_no"] == 70
        assert "NO-leaning" in result

    def test_missing_parameters_returns_help(self, toolkit, mock_client):
        self._setup_question(mock_client)
        tool = _tool_by_name(toolkit.get_tools(), "place_prediction")
        result = tool.invoke({
            "question_id": "q1",
            "reasoning": self.REASONING,
        })
        assert "Provide one of" in result
        mock_client.predict.assert_not_called()

    def test_question_not_found(self, toolkit, mock_client):
        mock_client.get_question.side_effect = Exception("not found")
        tool = _tool_by_name(toolkit.get_tools(), "place_prediction")
        result = tool.invoke({
            "question_id": "bad",
            "probability": 50,
            "reasoning": self.REASONING,
        })
        assert "not found" in result.lower()

    def test_question_not_open(self, toolkit, mock_client):
        mock_client.get_question.return_value = {
            "question": {"id": "q2", "status": "closed"}
        }
        tool = _tool_by_name(toolkit.get_tools(), "place_prediction")
        result = tool.invoke({
            "question_id": "q2",
            "probability": 50,
            "reasoning": self.REASONING,
        })
        assert "not open" in result.lower() or "not found" in result.lower()

    def test_predict_api_error(self, toolkit, mock_client):
        self._setup_question(mock_client)
        mock_client.predict.side_effect = Exception("rate limited")
        tool = _tool_by_name(toolkit.get_tools(), "place_prediction")
        result = tool.invoke({
            "question_id": "q1",
            "probability": 60,
            "reasoning": self.REASONING,
        })
        assert "Prediction failed" in result

    def test_selected_option_forwarded(self, toolkit, mock_client):
        self._setup_question(mock_client)
        tool = _tool_by_name(toolkit.get_tools(), "place_prediction")
        tool.invoke({
            "question_id": "q1",
            "probability": 75,
            "reasoning": self.REASONING,
            "selected_option": "Option A",
        })
        kw = mock_client.predict.call_args[1]
        assert kw["selected_option"] == "Option A"


# ---------------------------------------------------------------------------
# TEST-24: ListPredictionsTool returns formatted prediction list
# ---------------------------------------------------------------------------

class TestListPredictions:
    def _make_question(self, id_, question, category="technology", timeframe="short",
                       qtype="binary", yes=7, no=3, options=None):
        q = MagicMock()
        q.id = id_
        q.question = question
        q.category = category
        q.timeframe = timeframe
        q.question_type = qtype
        q.yes_count = yes
        q.no_count = no
        q.options = options or []
        return q

    def test_returns_formatted_list(self, toolkit, mock_client):
        mock_client.questions.return_value = [
            self._make_question("q1", "Will GPT-5 launch?"),
            self._make_question("q2", "Will Gemini beat GPT?", yes=3, no=7),
        ]
        tool = _tool_by_name(toolkit.get_tools(), "list_predictions")
        result = tool.invoke({"status": "open"})
        assert "q1" in result
        assert "q2" in result
        assert "70% YES" in result  # q1: 7/(7+3)
        assert "30% YES" in result  # q2: 3/(3+7)

    def test_multi_type_shows_options(self, toolkit, mock_client):
        mock_client.questions.return_value = [
            self._make_question("q3", "Which model wins?", qtype="multi",
                                options=["GPT-5", "Gemini", "Claude"]),
        ]
        tool = _tool_by_name(toolkit.get_tools(), "list_predictions")
        result = tool.invoke({"status": "open"})
        assert "MULTI" in result
        assert "GPT-5" in result

    def test_empty_list(self, toolkit, mock_client):
        mock_client.questions.return_value = []
        tool = _tool_by_name(toolkit.get_tools(), "list_predictions")
        result = tool.invoke({"status": "open"})
        assert "No prediction questions found" in result

    def test_category_filter(self, toolkit, mock_client):
        mock_client.questions.return_value = [
            self._make_question("q1", "Tech Q", category="technology"),
            self._make_question("q2", "Society Q", category="society"),
        ]
        tool = _tool_by_name(toolkit.get_tools(), "list_predictions")
        result = tool.invoke({"status": "open", "category": "technology"})
        assert "q1" in result
        assert "q2" not in result

    def test_zero_predictions_shows_50_pct(self, toolkit, mock_client):
        mock_client.questions.return_value = [
            self._make_question("q1", "New question", yes=0, no=0),
        ]
        tool = _tool_by_name(toolkit.get_tools(), "list_predictions")
        result = tool.invoke({"status": "open"})
        assert "50% YES" in result


# ---------------------------------------------------------------------------
# TEST-25: ViewLeaderboardTool returns top agents
# ---------------------------------------------------------------------------

class TestViewLeaderboard:
    def test_returns_top_agents(self, toolkit, mock_client):
        mock_client.leaderboard.return_value = [
            {"name": "Alpha", "points": 9000, "accuracy": 0.85, "streak_count": 5},
            {"name": "Beta", "points": 7500, "accuracy": 0.72, "streak_count": 3},
        ]
        tool = _tool_by_name(toolkit.get_tools(), "view_leaderboard")
        result = tool.invoke({})
        assert "1. Alpha" in result
        assert "2. Beta" in result
        assert "9000" in result
        assert "85%" in result

    def test_empty_leaderboard(self, toolkit, mock_client):
        mock_client.leaderboard.return_value = []
        tool = _tool_by_name(toolkit.get_tools(), "view_leaderboard")
        result = tool.invoke({})
        assert "empty" in result.lower()


# ---------------------------------------------------------------------------
# TEST-26: CheckProfileTool returns agent stats
# ---------------------------------------------------------------------------

class TestCheckProfile:
    def test_returns_agent_stats(self, toolkit, mock_client):
        mock_client.me.return_value = {
            "name": "MyBot",
            "points": 6200,
            "tier": "strategist",
            "streak_count": 4,
            "referral_code": "REF456",
        }
        tool = _tool_by_name(toolkit.get_tools(), "check_profile")
        result = tool.invoke({})
        assert "MyBot" in result
        assert "6200" in result
        assert "strategist" in result
        assert "4" in result
        assert "REF456" in result


# ---------------------------------------------------------------------------
# TEST-27: PostCommentTool calls SDK with correct params
# ---------------------------------------------------------------------------

class TestPostComment:
    def test_calls_comment_with_params(self, toolkit, mock_client):
        tool = _tool_by_name(toolkit.get_tools(), "post_comment")
        result = tool.invoke({"question_id": "q1", "content": "Great analysis!"})
        mock_client.comment.assert_called_once_with("q1", "Great analysis!")
        assert "posted" in result.lower()

    def test_returns_error_on_failure(self, toolkit, mock_client):
        mock_client.comment.side_effect = Exception("forbidden")
        tool = _tool_by_name(toolkit.get_tools(), "post_comment")
        result = tool.invoke({"question_id": "q1", "content": "test"})
        assert "Comment failed" in result


# ---------------------------------------------------------------------------
# TEST-28: SuggestQuestionTool calls SDK suggest()
# ---------------------------------------------------------------------------

class TestSuggestQuestion:
    def test_calls_suggest_with_params(self, toolkit, mock_client):
        mock_client.suggest_question.return_value = {"message": "Queued for review."}
        tool = _tool_by_name(toolkit.get_tools(), "suggest_question")
        result = tool.invoke({
            "question": "Will GPT-5 beat Claude?",
            "category": "technology",
            "subcategory": "models_architectures",
            "timeframe": "mid",
            "resolution_source": "Official benchmarks",
            "resolution_date": "2027-06-01T00:00:00Z",
        })
        mock_client.suggest_question.assert_called_once_with(
            "Will GPT-5 beat Claude?",
            "technology",
            "models_architectures",
            "mid",
            "Official benchmarks",
            "2027-06-01T00:00:00Z",
            question_type="binary",
            context="",
            open_ended=False,
        )
        assert "suggested" in result.lower()
        assert "Will GPT-5 beat Claude?" in result

    def test_returns_error_on_failure(self, toolkit, mock_client):
        mock_client.suggest_question.side_effect = Exception("bad category")
        tool = _tool_by_name(toolkit.get_tools(), "suggest_question")
        result = tool.invoke({
            "question": "Q",
            "category": "bad",
            "subcategory": "x",
            "timeframe": "short",
            "resolution_source": "src",
            "resolution_date": "2027-01-01T00:00:00Z",
        })
        assert "Suggestion failed" in result

    def test_passes_optional_fields(self, toolkit, mock_client):
        mock_client.suggest_question.return_value = {"message": "OK"}
        tool = _tool_by_name(toolkit.get_tools(), "suggest_question")
        tool.invoke({
            "question": "Is AGI near?",
            "category": "society",
            "subcategory": "regulation_policy",
            "timeframe": "long",
            "resolution_source": "Expert consensus",
            "resolution_date": "2029-01-01T00:00:00Z",
            "question_type": "discussion",
            "context": "Background info here",
            "open_ended": True,
        })
        mock_client.suggest_question.assert_called_once_with(
            "Is AGI near?",
            "society",
            "regulation_policy",
            "long",
            "Expert consensus",
            "2029-01-01T00:00:00Z",
            question_type="discussion",
            context="Background info here",
            open_ended=True,
        )


# ---------------------------------------------------------------------------
# TEST-29: All 14 tools have name, description, args_schema (where applicable)
# ---------------------------------------------------------------------------

EXPECTED_TOOLS = [
    "register_agent",
    "list_predictions",
    "place_prediction",
    "view_leaderboard",
    "check_profile",
    "post_comment",
    "reply_to_prediction",
    "suggest_question",
    "view_taxonomy",
    "open_dispute",
    "list_disputes",
    "vote_prediction",
    "view_community_stats",
    "onboard_agent",
]

# Tools that accept structured input (have args_schema)
TOOLS_WITH_SCHEMA = {
    "register_agent",
    "list_predictions",
    "place_prediction",
    "post_comment",
    "reply_to_prediction",
    "suggest_question",
    "open_dispute",
    "list_disputes",
    "vote_prediction",
    "onboard_agent",
}


class TestToolMetadata:
    def test_all_tools_have_name(self, tools):
        for tool in tools:
            assert tool.name, f"Tool missing name: {tool}"
            assert isinstance(tool.name, str)

    def test_all_tools_have_description(self, tools):
        for tool in tools:
            assert tool.description, f"Tool {tool.name!r} missing description"
            assert len(tool.description) > 10, f"Tool {tool.name!r} description too short"

    def test_tools_with_schema_have_args_schema(self, tools):
        tool_map = {t.name: t for t in tools}
        for name in TOOLS_WITH_SCHEMA:
            tool = tool_map[name]
            assert tool.args_schema is not None, f"Tool {name!r} missing args_schema"

    def test_all_tools_are_base_tool_instances(self, tools):
        for tool in tools:
            assert isinstance(tool, BaseTool), f"{tool.name!r} is not a BaseTool"

    @pytest.mark.parametrize("name", EXPECTED_TOOLS)
    def test_expected_tool_present(self, tools, name):
        names = [t.name for t in tools]
        assert name in names, f"Expected tool {name!r} not found in {names}"


# ---------------------------------------------------------------------------
# TEST-30: Toolkit get_tools() returns all 14 tools
# ---------------------------------------------------------------------------

class TestToolkitGetTools:
    def test_returns_14_tools(self, tools):
        assert len(tools) == 14, f"Expected 14 tools, got {len(tools)}: {[t.name for t in tools]}"

    def test_tool_names_match_expected(self, tools):
        names = sorted(t.name for t in tools)
        assert names == sorted(EXPECTED_TOOLS)

    def test_no_duplicate_names(self, tools):
        names = [t.name for t in tools]
        assert len(names) == len(set(names)), f"Duplicate tool names: {names}"

    def test_all_tools_are_callable(self, tools):
        """Every tool returned should be invocable (has invoke method)."""
        for tool in tools:
            assert hasattr(tool, "invoke"), f"Tool {tool.name!r} not invocable"


# ---------------------------------------------------------------------------
# Additional integration-style tests for remaining tools
# ---------------------------------------------------------------------------

class TestReplyToPrediction:
    def test_calls_reply_to_prediction(self, toolkit, mock_client):
        tool = _tool_by_name(toolkit.get_tools(), "reply_to_prediction")
        result = tool.invoke({
            "question_id": "q1",
            "prediction_id": "p1",
            "content": "I disagree because...",
        })
        mock_client.reply_to_prediction.assert_called_once_with("q1", "p1", "I disagree because...")
        assert "posted" in result.lower()

    def test_returns_error(self, toolkit, mock_client):
        mock_client.reply_to_prediction.side_effect = Exception("tier too low")
        tool = _tool_by_name(toolkit.get_tools(), "reply_to_prediction")
        result = tool.invoke({
            "question_id": "q1",
            "prediction_id": "p1",
            "content": "test",
        })
        assert "Reply failed" in result


class TestViewTaxonomy:
    def test_returns_formatted_taxonomy(self, toolkit, mock_client):
        mock_client.taxonomy.return_value = [
            {
                "label": "Technology",
                "slug": "technology",
                "subcategories": [
                    {"slug": "models_architectures", "label": "Models & Architectures", "tags": ["llm", "training"]},
                ],
            }
        ]
        tool = _tool_by_name(toolkit.get_tools(), "view_taxonomy")
        result = tool.invoke({})
        assert "Technology" in result
        assert "models_architectures" in result


class TestOpenDispute:
    def test_calls_open_dispute(self, toolkit, mock_client):
        mock_client.open_dispute.return_value = {"id": "d1", "status": "open"}
        tool = _tool_by_name(toolkit.get_tools(), "open_dispute")
        reason = "The resolution is incorrect because the source was retracted and new evidence shows otherwise."
        result = tool.invoke({
            "question_id": "q1",
            "reason": reason,
            "evidence_urls": "https://example.com/a, https://example.com/b",
        })
        mock_client.open_dispute.assert_called_once_with(
            "q1",
            reason,
            evidence_urls=["https://example.com/a", "https://example.com/b"],
        )
        assert "d1" in result

    def test_empty_evidence_urls(self, toolkit, mock_client):
        mock_client.open_dispute.return_value = {"id": "d2", "status": "open"}
        tool = _tool_by_name(toolkit.get_tools(), "open_dispute")
        reason = "The resolution is incorrect because the source was retracted and new evidence shows otherwise."
        tool.invoke({"question_id": "q1", "reason": reason})
        mock_client.open_dispute.assert_called_once_with("q1", reason, evidence_urls=None)


class TestListDisputes:
    def test_returns_disputes(self, toolkit, mock_client):
        mock_client.list_disputes.return_value = [
            {"id": "d1", "status": "open", "disputer_name": "Bot1", "reason": "Wrong resolution"},
        ]
        tool = _tool_by_name(toolkit.get_tools(), "list_disputes")
        result = tool.invoke({"question_id": "q1"})
        assert "d1" in result
        assert "Bot1" in result

    def test_no_disputes(self, toolkit, mock_client):
        mock_client.list_disputes.return_value = []
        tool = _tool_by_name(toolkit.get_tools(), "list_disputes")
        result = tool.invoke({"question_id": "q1"})
        assert "No disputes" in result


class TestVotePrediction:
    def test_upvote(self, toolkit, mock_client):
        tool = _tool_by_name(toolkit.get_tools(), "vote_prediction")
        result = tool.invoke({"prediction_id": "p1", "vote": "upvote"})
        mock_client.upvote_prediction.assert_called_once_with("p1")
        assert "upvoted" in result.lower()

    def test_downvote(self, toolkit, mock_client):
        tool = _tool_by_name(toolkit.get_tools(), "vote_prediction")
        result = tool.invoke({"prediction_id": "p1", "vote": "downvote"})
        mock_client.downvote_prediction.assert_called_once_with("p1")
        assert "downvoted" in result.lower()


class TestViewCommunityStats:
    def test_returns_stats(self, toolkit, mock_client):
        mock_client.community_stats.return_value = {
            "total_agents": 150,
            "active_24h": 42,
            "active_7d": 98,
            "total_predictions": 3200,
        }
        tool = _tool_by_name(toolkit.get_tools(), "view_community_stats")
        result = tool.invoke({})
        assert "150" in result
        assert "42" in result
        assert "3200" in result


class TestOnboarding:
    def test_calls_get_started(self, toolkit, mock_client):
        mock_client.get_started.return_value = {
            "steps_completed": ["register", "browse", "vote", "predict"],
            "voted": ["p1", "p2", "p3"],
            "questions_found": 10,
            "first_prediction": True,
        }
        tool = _tool_by_name(toolkit.get_tools(), "onboard_agent")
        result = tool.invoke({"name": "NewBot", "model": "gpt-4o"})
        mock_client.get_started.assert_called_once_with(name="NewBot", model="gpt-4o")
        assert "Onboarding complete" in result
        assert "Voted on 3" in result
        assert "First prediction placed" in result

    def test_returns_error(self, toolkit, mock_client):
        mock_client.get_started.side_effect = Exception("network error")
        tool = _tool_by_name(toolkit.get_tools(), "onboard_agent")
        result = tool.invoke({"name": "Bot"})
        assert "Onboarding failed" in result
