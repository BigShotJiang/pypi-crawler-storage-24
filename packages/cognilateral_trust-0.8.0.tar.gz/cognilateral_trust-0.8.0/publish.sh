#!/usr/bin/env bash
# Publish cognilateral-trust to PyPI.
# Usage: ./publish.sh [--test]  (--test for TestPyPI)
set -euo pipefail

cd "$(dirname "$0")"
source ~/.env 2>/dev/null || true

if [ -z "${PYPI_TOKEN:-}" ]; then
    echo "ERROR: Set PYPI_TOKEN in ~/.env"
    echo "  Get one at: https://pypi.org/manage/account/token/"
    echo "  Add to ~/.env: PYPI_TOKEN=pypi-..."
    exit 1
fi

# Build fresh
uv build

if [ "${1:-}" = "--test" ]; then
    echo "Publishing to TestPyPI..."
    uv publish \
        --publish-url https://test.pypi.org/legacy/ \
        --token "${TEST_PYPI_TOKEN:-$PYPI_TOKEN}"
    echo "Verify: pip install -i https://test.pypi.org/simple/ cognilateral-trust"
else
    echo "Publishing to PyPI..."
    uv publish --token "$PYPI_TOKEN"
    echo "Verify: pip install cognilateral-trust"
fi
