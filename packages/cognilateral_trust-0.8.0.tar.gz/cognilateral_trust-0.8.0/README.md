# cognilateral-trust

Epistemic trust layer for AI agents. AI that tells you when it's guessing.

```python
from cognilateral_trust import evaluate_trust

result = evaluate_trust(0.7)
if result.should_proceed:
    perform_action()
else:
    escalate(result.accountability_record.reasons)
```

## Confidence Tiers (C0-C9)

| Tier | Name | Route |
|------|------|-------|
| C0-C3 | Unverified → Measured | basic |
| C4-C6 | Tested → Falsifiable | warrant_check |
| C7-C9 | Governance → Resilient | sovereignty_gate |

## License

Apache-2.0
