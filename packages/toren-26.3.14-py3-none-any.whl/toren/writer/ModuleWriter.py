import collections
import json
import os
from pathlib import Path

from typing import List
from .WriterObject import WriterObject
from .ClassWriter import ClassWriter
from .StringWriter import StringWriter
from ..Project import Project
from ..Module import Module
from ..Class import Class
from ..languages import *
from ..tracer.Logger import Logger

class ModuleWriter(WriterObject):

    def __init__(self, project: Project, 
                 module: Module, 
                 language: Language, 
                 logger:Logger=None, 
                 deleteoutputdirectory:bool=False):
        super().__init__()
        self.DeleteOutputDirectory = deleteoutputdirectory
        self.Project = project
        self.Module = module
        self.Language = language
        self.ClassWriterClass = ClassWriter
        self.StringWriterClass = StringWriter
        self.HeaderFileName = f"{self.Module.Name}_header"
        self.S = self.StringWriterClass(self.Language)
        self.setLogger(logger)

    def getModulePath(self):
        parent_project_path = os.path.join(self.Language.OutputDirectory, self.Project.Name, self.Project.Name)

        module_path = self.writeDirectoryToPath(parent_project_path, 
                                                self.Module.Name, 
                                                clear=True)
        return module_path
        
    def write(self):
        self.Logger.Log(f"=> Writing Module: {self.Module.Name}")
        module_path = self.getModulePath()
        self.Logger.Log(f"=> To Path: {module_path}")
        headerfn = f"{self.HeaderFileName}.{self.Language.DefaultFileExtension}"
        self.writeModuleHeader(module_path, headerfn)
        for classid, _class in self.Module.Classes.Data.items():
            c = self.ClassWriterClass(project=self.Project,
                          module=self.Module,
                          class_=_class,
                          language=self.Language,
                          logger=self.Logger)
            c.write()

    def writeModuleHeader(self, path, filename):
        s = self.S
        for classid, _class in self.Module.Classes.Data.items():
            pass

            
            
