from .Database import Database
import collections

class DatabasePostgreSQL(Database):
  
  class PropertName(Database.PropertName):
    pass

  class PropertID(Database.PropertID):
    pass
  
  def __init__(self):
    super().__init__()

  def getName(self):
    return "PostgreSQL"
  
  def getDescription(self):
    return "PostgreSQL"

  def getType(self):
    return "toren.datastores.DatabasePostgreSQL"
  
  def getID(self):
    return "be3f92e2-e2ff-491d-9ca0-eaefb72cc6bf"
  
  ##########################################################################
  # DB Specific Query Syntax
  ##########################################################################
  
  def GetParameter(self, parameterName: str = "", index: int = -1):
    return f"%({parameterName})s"
  
  def OpenBrackets(self):
    return ""
  
  def CloseBrackets(self):
    return ""
  
  
  def OpenBrackets(self):
    return "\\\"" # Double Escaped
  
  def CloseBrackets(self):
    return "\\\"" # Double Escaped
  
  def TOP(self, number):
    return f""
  
  def LIMIT(self, number):
    return f" LIMIT {str(number)}"
  
  def OFFSET(self, number):
    return f" OFFSET {str(number)}"
  
  def LIMIT_OFFSET(self, limit_number, offset_number):
    return f" LIMIT {str(limit_number)} OFFSET {str(offset_number)}"
  
  ##########################################################################
  # Dependencies
  ##########################################################################

  def CSharpDependencies(self):
    return ["using Npgsql;"]
  
  def PythonDependencies(self):
    return ["import psycopg2"]
  
  def JavaDependencies(self):
    return ["import java.sql.Connection;", "import java.sql.DriverManager;", "import java.sql.SQLException;", "import java.sql.PreparedStatement;"]
  
  def GoDependencies(self):
    return [""]
  
  def JavaScriptDependencies(self):
    return [""]
  
  ##########################################################################
  # Connection
  ##########################################################################

  def PythonConnectionClass(self):
    return "psycopg2"
  
  def JavaConnectionClass(self):
    return "Connection"
  
  ##########################################################################
  # Initialize Connection
  ##########################################################################

  def CSharpInitializeConnection(self, s):
    return s
  
  def PythonInitializeConnection(self, s):
    connclass = self.PythonConnectionClass()
    s.wln("credential = keyring.get_password(config.Credential, config.Username)")
    s.wln("password = base64.b64decode(credential.encode('utf-8')).decode('utf-8')")
    s.wln(f"connection = {connclass}.connect(").o()
    s.wln("user=config.Username,")
    s.wln("password=password,")
    s.wln("host=config.Server,")
    s.wln("port=config.PortNumber,")
    s.wln("database=config.Database")
    s.c()
    s.wln(f")")
    return s
  
  def JavaInitializeConnection(self, s):
    s.wln('Base64.Decoder decoder = Base64.getDecoder();')
    s.wln('String password = new String(decoder.decode(System.getenv(config.getCredential())), StandardCharsets.UTF_8);')
    s.wln('String username = config.getUsername();')
    s.wln('String database = config.getDatabase();')
    s.wln('String server = config.getServer();')
    s.wln('int portno = config.getPortNumber();')
    s.wln('String connectionformat = "jdbc:postgresql:@//%s:%d/%s";')
    s.wln('String connectionstr = String.format(connectionformat, server, portno, database);')
    s.w('try ').o()
    s.wln('connection = DriverManager.getConnection(connectionstr, username, password);')
    s.b(" catch (SQLException e) ")
    s.wln("e.printStackTrace();")
    s.c()
    return s 
  
  def GoInitializeConnection(self, s):
    return s
  
  def JavaScriptInitializeConnection(self, s):
    return s