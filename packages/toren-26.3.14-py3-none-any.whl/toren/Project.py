import collections
import json
from .TorenObject import TorenObject
from .Module import Module
from .ModuleCollection import ModuleCollection
from .languages import *
from .datastores import *
#from .writer import *
from typing import List


class Project(TorenObject):


  class PropertName():
    NAME = "Name"
    DESCRIPTION = "Description"
    ID = "ID"
    VERSION = "Version"
    MODULES = "Modules"
    LANGUAGES = "Languages"
    DATASTORES = "Datastores"
    TYPE = "Type"
    ENTITY = "Entity"
    TLD = "TLD"

  class PropertID():
    NAME = "58795c87-1889-4d2c-8e32-6ae2c8da711b"
    DESCRIPTION = "2ff3a914-ce58-4c59-b444-853521a63e51"
    ID = "5bb456ac-0ba6-4581-9990-f31272c71a4b"
    VERSION = "01d01da2-4492-4d0b-97c0-53b1af0c7b57"
    MODULES = "bf183016-6d32-4950-87a0-1e246a2ffe99" 
    LANGUAGES = "ab43f94f-c692-4318-b8c6-548ab511c6ff"
    DATASTORES = "d4f82402-26dd-484c-b6b0-e50ae4aff2b7"
    TYPE = "06402adf-7222-436a-a542-7791eb9d418a"
    ENTITY = "7843a153-9143-47ed-a740-bd4cf9539ac8"
    TLD = "dd049ec2-5f49-4bd4-abaa-0bc8f3ab29b3"

  def __init__(self):
    self.Type = "toren.Project"
    self.Name = ""
    self.Description = ""
    self.ID = ""
    self.Version = ""
    self.Modules = []
    self.Languages = LanguageCollection()
    self.Datastores = DatabaseCollection()
    self.Entity = "Noone"

  def initialize(self, name: str, 
                 description: str, 
                 entity: str,
                 id: str, 
                 version: str, 
                 modules: list[Module]=None,
                 languages: list[Language] = None,
                 datastores: list[Database] = None,
                 tld: str = "com"):
    self.Type = "toren.Project"
    self.Name = name
    self.Description = description
    self.Entity = entity
    self.ID = id
    self.Version = version
    self.TLD = tld
    self.Modules = ModuleCollection().initialize(modules, self)
    self.Languages = LanguageCollection().initialize(languages, self)
    self.Datastores = DatabaseCollection().initialize(datastores, self)

    #self.setForeignKeys()
    return self

  def to_dict(self):
    _project = {}
    _project[self.PropertName.TYPE] = self.Type
    _project[self.PropertName.NAME] = self.Name
    _project[self.PropertName.DESCRIPTION] = self.Description
    _project[self.PropertName.ENTITY] = self.Entity
    _project[self.PropertName.ID] = self.ID
    _project[self.PropertName.VERSION] = self.Version
    _project[self.PropertName.TLD] = self.TLD
    _project[self.PropertName.MODULES] = self.Modules.to_list_of_dict()
    _project[self.PropertName.LANGUAGES] = self.Languages.to_list_of_dict()
    _project[self.PropertName.DATASTORES] = self.Datastores.to_list_of_dict()

    return _project

  def to_json(self):
    _project_json = json.dumps(self.to_dict())
    return _project_json

  def from_json(self, jsonString):
    _project = json.loads(jsonString)
    self.from_dict(_project)
    return self

  def from_dict(self, project):
    #self.ype = str(project[self.PropertName.TYPE])
    self.Name= str(project[self.PropertName.NAME])
    self.Description = str(project[self.PropertName.DESCRIPTION]) 
    self.Entity = str(project[self.PropertName.ENTITY]) 
    self.ID = str(project[self.PropertName.ID])
    self.Version = str(project[self.PropertName.VERSION])
    self.TLD = str(project[self.PropertName.TLD])
    self.Modules = ModuleCollection().initialize(project[self.PropertName.MODULES], self)
    self.Languages = LanguageCollection().initialize(project[self.PropertName.LANGUAGES], self)
    self.Datastores = DatabaseCollection().initialize(project[self.PropertName.DATASTORES], self)
    
    self.setInheritence()
    self.setForeignKeys()
    return self
  
  def to_file(self, path:str):
    with open(path, "w") as projectfile:
      json.dump(self.to_dict(), projectfile, indent=2)

  def from_file(self, path:str):
    with open(path, 'r') as projectfile:
      projectjson = projectfile.read()
      self.from_json(projectjson)
    return self
  
  def setInheritence(self):
    for moduleid, module in self.Modules.Data.items():
      for _classid, _class in module.Classes.Data.items():
        if _class.InheritsFromID is not None:
          inheritsFromClass = self.getClass(_class.InheritsFromID)
          _class.setInheritsFrom(inheritsFromClass)

  
  def setForeignKeys(self):
    for moduleid, module in self.Modules.Data.items():
      for _classid, _class in module.Classes.Data.items():
        for _propertyid, _property in _class.Properties.Data.items():
          if _property.ForeignKey is not None:
            _fkproperytname = _property.ForeignKey.PropertyName
            _fkclassproperty = self.getProperty(_property.ForeignKey.FKClassPropertyID)
            _fkclass = self.getClass(_property.ForeignKey.FKClassID)
            _property.setForeignKey(_fkproperytname, _fkclassproperty, _fkclass)

  def getClass(self, classid):
    for moduleid, module in self.Modules.Data.items():
      for _classid, _class in module.Classes.Data.items():
        if _classid == classid:
          return _class
    return None

  def getProperty(self, propertyid):
    for moduleid, module in self.Modules.Data.items():
      for _classid, _class in module.Classes.Data.items():
        for _propertyid, _property in _class.Properties.Data.items():
          if _propertyid == propertyid:
            return _property
    return None

