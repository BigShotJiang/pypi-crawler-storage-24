__all__ = [
    "AccessDeniedError",
    "AfcException",
    "AfcFileNotFoundError",
    "AlreadyMountedError",
    "AmfiError",
    "ArbitrationError",
    "ArgumentError",
    "BadCommandError",
    "BadDevError",
    "CannotStopSessionError",
    "CloudConfigurationAlreadyPresentError",
    "ConnectionFailedError",
    "ConnectionFailedToUsbmuxdError",
    "ConnectionTerminatedError",
    "CoreDeviceError",
    "DeprecationError",
    "DeveloperModeError",
    "DeveloperModeIsNotEnabledError",
    "DeviceAlreadyInUseError",
    "DeviceHasPasscodeSetError",
    "DeviceNotFoundError",
    "DeviceVersionNotSupportedError",
    "DisableMemoryLimitError",
    "DvtDirListError",
    "DvtException",
    "ExtractingStackshotError",
    "FatalPairingError",
    "FeatureNotSupportedError",
    "GetProhibitedError",
    "IRecvError",
    "IRecvNoDeviceConnectedError",
    "IncorrectModeError",
    "InspectorEvaluateError",
    "InternalError",
    "InvalidConnectionError",
    "InvalidHostIDError",
    "InvalidServiceError",
    "LaunchingApplicationError",
    "LockdownError",
    "MessageNotSupportedError",
    "MissingValueError",
    "MuxException",
    "MuxVersionError",
    "NoDeviceConnectedError",
    "NotEnoughDiskSpaceError",
    "NotMountedError",
    "NotPairedError",
    "NotTrustedError",
    "NotificationTimeoutError",
    "OSNotSupportedError",
    "PairingDialogResponsePendingError",
    "PairingError",
    "PasscodeRequiredError",
    "PasswordRequiredError",
    "ProfileError",
    "PyException",
    "QuicProtocolNotSupportedError",
    "RSDRequiredError",
    "RemoteAutomationNotEnabledError",
    "RemotePairingCompletedError",
    "SetProhibitedError",
    "StartServiceError",
    "SysdiagnoseTimeoutError",
    "TSSError",
    "TunneldConnectionError",
    "UnrecognizedSelectorError",
    "UnsupportedCommandError",
    "UserDeniedPairingError",
    "WdaError",
    "WebInspectorNotEnabledError",
    "WirError",
]

from typing import Optional


class PyException(Exception):
    pass


class DeviceVersionNotSupportedError(PyException):
    pass


class IncorrectModeError(PyException):
    pass


class NotTrustedError(PyException):
    pass


class PairingError(PyException):
    pass


class NotPairedError(PyException):
    pass


class CannotStopSessionError(PyException):
    pass


class PasswordRequiredError(PairingError):
    pass


class StartServiceError(PyException):
    def __init__(self, service_name: str, message: str) -> None:
        super().__init__()
        self.service_name = service_name
        self.message = message


class FatalPairingError(PyException):
    pass


class NoDeviceConnectedError(PyException):
    pass


class InterfaceIndexNotFoundError(PyException):
    def __init__(self, address: str):
        super().__init__()
        self.address = address


class DeviceNotFoundError(PyException):
    def __init__(self, udid: str):
        super().__init__()
        self.udid = udid


class TunneldConnectionError(PyException):
    pass


class MuxException(PyException):
    pass


class MuxVersionError(MuxException):
    pass


class BadCommandError(MuxException):
    pass


class BadDevError(MuxException):
    pass


class ConnectionFailedError(MuxException):
    pass


class ConnectionFailedToUsbmuxdError(ConnectionFailedError):
    pass


class ArgumentError(PyException):
    pass


class AfcException(PyException, OSError):
    def __init__(self, message: str, status: str, filename: Optional[str] = None) -> None:
        OSError.__init__(self, status, message)
        self.status = status
        self.filename = filename


class AfcFileNotFoundError(AfcException):
    pass


class DvtException(PyException):
    pass


class UnrecognizedSelectorError(DvtException):
    pass


class DvtDirListError(DvtException):
    pass


class NotMountedError(PyException):
    pass


class AlreadyMountedError(PyException):
    pass


class MissingManifestError(PyException):
    pass


class UnsupportedCommandError(PyException):
    pass


class ExtractingStackshotError(PyException):
    pass


class ChannelClosedError(PyException):
    pass


class ConnectionTerminatedError(PyException):
    pass


class StreamClosedError(ConnectionTerminatedError):
    pass


class WebInspectorNotEnabledError(PyException):
    pass


class RemoteAutomationNotEnabledError(PyException):
    pass


class WirError(PyException):
    pass


class InternalError(PyException):
    pass


class ArbitrationError(PyException):
    pass


class DeviceAlreadyInUseError(ArbitrationError):

    @property
    def message(self):
        return self.args[0].get("message")

    @property
    def owner(self):
        return self.args[0].get("owner")

    @property
    def result(self):
        return self.args[0].get("result")


class DeveloperModeIsNotEnabledError(PyException):
    pass


class DeveloperDiskImageNotFoundError(PyException):
    pass


class DeveloperModeError(PyException):
    pass


class LockdownError(PyException):
    def __init__(self, message: str, identifier: Optional[str] = None) -> None:
        super().__init__(message)
        self.identifier = identifier


class GetProhibitedError(LockdownError):
    pass


class SetProhibitedError(LockdownError):
    pass


class PairingDialogResponsePendingError(PairingError):
    pass


class UserDeniedPairingError(PairingError):
    pass


class InvalidHostIDError(PairingError):
    pass


class MissingValueError(LockdownError):
    pass


class InvalidConnectionError(LockdownError):
    pass


class PasscodeRequiredError(LockdownError):
    pass


class AmfiError(PyException):
    pass


class DeviceHasPasscodeSetError(AmfiError):
    pass


class NotificationTimeoutError(PyException, TimeoutError):
    pass


class ProfileError(PyException):
    pass


class CloudConfigurationAlreadyPresentError(ProfileError):
    pass


class IRecvError(PyException):
    pass


class IRecvNoDeviceConnectedError(IRecvError):
    pass


class MessageNotSupportedError(PyException):
    pass


class InvalidServiceError(LockdownError):
    pass


class InspectorEvaluateError(PyException):
    def __init__(
        self,
        class_name: str,
        message: str,
        line: Optional[int] = None,
        column: Optional[int] = None,
        stack: Optional[list[str]] = None,
    ):
        super().__init__()
        self.class_name = class_name
        self.message = message
        self.line = line
        self.column = column
        self.stack = stack

    def __str__(self) -> str:
        stack_trace = "\n".join([f"\t - {frame}" for frame in self.stack])
        return f"{self.class_name}: {self.message}.\nLine: {self.line} Column: {self.column}\nStack: {stack_trace}"


class LaunchingApplicationError(PyException):
    pass


class AppInstallError(PyException):
    pass


class AppNotInstalledError(PyException):
    pass


class CoreDeviceError(PyException):
    pass


class AccessDeniedError(PyException):
    pass


class NoSuchBuildIdentityError(PyException):
    pass


class MobileActivationException(PyException):
    pass


class NotEnoughDiskSpaceError(PyException):
    pass


class DeprecationError(PyException):
    pass


class RSDRequiredError(PyException):
    def __init__(self, identifier: str) -> None:
        self.identifier = identifier
        super().__init__()


class SysdiagnoseTimeoutError(PyException, TimeoutError):
    pass


class SupportError(PyException):
    def __init__(self, os_name):
        self.os_name = os_name
        super().__init__()


class OSNotSupportedError(SupportError):
    pass


class FeatureNotSupportedError(SupportError):
    def __init__(self, os_name, feature):
        super().__init__(os_name)
        self.feature = feature


class QuicProtocolNotSupportedError(PyException):
    pass


class RemotePairingCompletedError(PyException):
    pass


class DisableMemoryLimitError(PyException):
    pass


class ProtocolError(PyException):
    pass


class TSSError(PyException):
    pass


class WdaError(PyException):
    def __init__(self, message: str, status_code: Optional[int] = None):
        super().__init__(message)
        self.status_code = status_code
