# Egune Python SDK

Official Python SDK for the [Egune](https://egune.com) LLM API Gateway.

## Installation

```bash
pip install egune
```

## Quick Start

```python
from egune import Egune

client = Egune(api_key="eg-xxx")

# Non-streaming
response = client.chat.completions.create(
    model="egune1-14b",
    messages=[{"role": "user", "content": "Hello!"}],
)
print(response.choices[0].message.content)

# Streaming
stream = client.chat.completions.create(
    model="egune1-14b",
    messages=[{"role": "user", "content": "Hello!"}],
    stream=True,
)
for chunk in stream:
    if chunk.choices[0].delta.content:
        print(chunk.choices[0].delta.content, end="")
```

## Async

```python
from egune import AsyncEgune

client = AsyncEgune(api_key="eg-xxx")

response = await client.chat.completions.create(
    model="egune1-14b",
    messages=[{"role": "user", "content": "Hello!"}],
)

# Async streaming
stream = await client.chat.completions.create(
    model="egune1-14b",
    messages=[{"role": "user", "content": "Hello!"}],
    stream=True,
)
async for chunk in stream:
    if chunk.choices[0].delta.content:
        print(chunk.choices[0].delta.content, end="")
```

## List Models

```python
models = client.models.list()
for model in models.data:
    print(model.id)
```

## Error Handling

```python
from egune import Egune, EguneError

client = Egune(api_key="eg-xxx")

try:
    response = client.chat.completions.create(
        model="egune1-14b",
        messages=[{"role": "user", "content": "Hello!"}],
    )
except EguneError as e:
    print(f"Error: {e.message} (type={e.type}, code={e.code}, status={e.status})")
```

## Configuration

```python
client = Egune(
    api_key="eg-xxx",
    base_url="https://api.egune.com/v1",  # default
    timeout=600.0,                         # default, in seconds
)
```
