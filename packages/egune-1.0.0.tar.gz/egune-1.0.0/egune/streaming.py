from __future__ import annotations

import json
from typing import Iterator, AsyncIterator

import httpx

from egune.types import ChatCompletionChunk


class Stream:
    """Synchronous SSE stream iterator for chat completions."""

    def __init__(self, response: httpx.Response):
        self._response = response
        self._iterator = response.iter_lines()

    def __iter__(self) -> Iterator[ChatCompletionChunk]:
        return self

    def __next__(self) -> ChatCompletionChunk:
        for line in self._iterator:
            if not line.startswith("data: "):
                continue
            payload = line[6:]
            if payload.strip() == "[DONE]":
                self._response.close()
                raise StopIteration
            chunk = ChatCompletionChunk.from_dict(json.loads(payload))
            return chunk
        self._response.close()
        raise StopIteration

    def close(self) -> None:
        self._response.close()

    def __enter__(self) -> "Stream":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


class AsyncStream:
    """Asynchronous SSE stream iterator for chat completions."""

    def __init__(self, response: httpx.Response):
        self._response = response
        self._iterator = response.aiter_lines()

    def __aiter__(self) -> AsyncIterator[ChatCompletionChunk]:
        return self

    async def __anext__(self) -> ChatCompletionChunk:
        async for line in self._iterator:
            if not line.startswith("data: "):
                continue
            payload = line[6:]
            if payload.strip() == "[DONE]":
                await self._response.aclose()
                raise StopAsyncIteration
            chunk = ChatCompletionChunk.from_dict(json.loads(payload))
            return chunk
        await self._response.aclose()
        raise StopAsyncIteration

    async def close(self) -> None:
        await self._response.aclose()

    async def __aenter__(self) -> "AsyncStream":
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
