from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


class EguneError(Exception):
    """Error returned by the Egune API."""

    def __init__(self, message: str, type: str = "", code: str = "", status: int = 0):
        super().__init__(message)
        self.message = message
        self.type = type
        self.code = code
        self.status = status

    def __repr__(self) -> str:
        return f"EguneError(message={self.message!r}, type={self.type!r}, code={self.code!r}, status={self.status})"


@dataclass
class CompletionUsage:
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0

    @classmethod
    def from_dict(cls, d: Optional[Dict[str, Any]]) -> Optional["CompletionUsage"]:
        if not d:
            return None
        inst = cls(
            prompt_tokens=d.get("prompt_tokens", 0),
            completion_tokens=d.get("completion_tokens", 0),
            total_tokens=d.get("total_tokens", 0),
        )
        if inst.total_tokens == 0:
            inst.total_tokens = inst.prompt_tokens + inst.completion_tokens
        return inst


@dataclass
class Message:
    role: str = ""
    content: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Message":
        return cls(role=d.get("role", ""), content=d.get("content"))


@dataclass
class ChoiceDelta:
    role: Optional[str] = None
    content: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ChoiceDelta":
        return cls(role=d.get("role"), content=d.get("content"))


@dataclass
class Choice:
    index: int = 0
    message: Optional[Message] = None
    delta: Optional[ChoiceDelta] = None
    finish_reason: Optional[str] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Choice":
        msg = Message.from_dict(d["message"]) if "message" in d else None
        delta = ChoiceDelta.from_dict(d["delta"]) if "delta" in d else None
        return cls(
            index=d.get("index", 0),
            message=msg,
            delta=delta,
            finish_reason=d.get("finish_reason"),
        )


@dataclass
class ChatCompletion:
    id: str = ""
    object: str = ""
    created: int = 0
    model: str = ""
    choices: List[Choice] = field(default_factory=list)
    usage: Optional[CompletionUsage] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ChatCompletion":
        return cls(
            id=d.get("id", ""),
            object=d.get("object", ""),
            created=d.get("created", 0),
            model=d.get("model", ""),
            choices=[Choice.from_dict(c) for c in d.get("choices", [])],
            usage=CompletionUsage.from_dict(d.get("usage")),
        )


@dataclass
class ChatCompletionChunk:
    id: str = ""
    object: str = ""
    created: int = 0
    model: str = ""
    choices: List[Choice] = field(default_factory=list)
    usage: Optional[CompletionUsage] = None

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ChatCompletionChunk":
        return cls(
            id=d.get("id", ""),
            object=d.get("object", ""),
            created=d.get("created", 0),
            model=d.get("model", ""),
            choices=[Choice.from_dict(c) for c in d.get("choices", [])],
            usage=CompletionUsage.from_dict(d.get("usage")),
        )


@dataclass
class Model:
    id: str = ""
    object: str = "model"
    created: int = 0
    owned_by: str = ""

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Model":
        return cls(
            id=d.get("id", ""),
            object=d.get("object", "model"),
            created=d.get("created", 0),
            owned_by=d.get("owned_by", ""),
        )


@dataclass
class ModelList:
    object: str = "list"
    data: List[Model] = field(default_factory=list)

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ModelList":
        return cls(
            object=d.get("object", "list"),
            data=[Model.from_dict(m) for m in d.get("data", [])],
        )
