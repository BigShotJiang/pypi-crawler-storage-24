from __future__ import annotations

import json
from typing import Any, Dict, List, Optional, Union, overload
from typing_extensions import Literal

import httpx

from egune.types import (
    ChatCompletion,
    ChatCompletionChunk,
    EguneError,
    ModelList,
)
from egune.streaming import Stream, AsyncStream

_DEFAULT_BASE_URL = "https://api.egune.com/v1"
_DEFAULT_TIMEOUT = 600.0


def _build_headers(api_key: str) -> Dict[str, str]:
    return {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json",
    }


def _handle_error(response: httpx.Response) -> None:
    if response.status_code >= 400:
        try:
            body = response.json()
            err = body.get("error", {})
            raise EguneError(
                message=err.get("message", response.text),
                type=err.get("type", ""),
                code=err.get("code", ""),
                status=response.status_code,
            )
        except (json.JSONDecodeError, KeyError):
            raise EguneError(
                message=response.text,
                status=response.status_code,
            )


class _ChatCompletions:
    """Sync chat.completions namespace."""

    def __init__(self, client: "Egune"):
        self._client = client

    @overload
    def create(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        stream: Literal[True],
        **kwargs: Any,
    ) -> Stream: ...

    @overload
    def create(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        stream: Literal[False] = False,
        **kwargs: Any,
    ) -> ChatCompletion: ...

    @overload
    def create(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        **kwargs: Any,
    ) -> ChatCompletion: ...

    def create(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        stream: bool = False,
        **kwargs: Any,
    ) -> Union[ChatCompletion, Stream]:
        body: Dict[str, Any] = {"model": model, "messages": messages, "stream": stream, **kwargs}

        if stream:
            response = self._client._http.send(
                self._client._http.build_request("POST", "/chat/completions", json=body),
                stream=True,
            )
            if response.status_code >= 400:
                response.read()
                _handle_error(response)
            return Stream(response)

        response = self._client._http.post("/chat/completions", json=body)
        _handle_error(response)
        return ChatCompletion.from_dict(response.json())


class _Completions:
    """Sync completions namespace."""

    def __init__(self, client: "Egune"):
        self._client = client

    @overload
    def create(
        self,
        *,
        model: str,
        prompt: str,
        stream: Literal[True],
        **kwargs: Any,
    ) -> Stream: ...

    @overload
    def create(
        self,
        *,
        model: str,
        prompt: str,
        stream: Literal[False] = False,
        **kwargs: Any,
    ) -> ChatCompletion: ...

    @overload
    def create(
        self,
        *,
        model: str,
        prompt: str,
        **kwargs: Any,
    ) -> ChatCompletion: ...

    def create(
        self,
        *,
        model: str,
        prompt: str,
        stream: bool = False,
        **kwargs: Any,
    ) -> Union[ChatCompletion, Stream]:
        body: Dict[str, Any] = {"model": model, "prompt": prompt, "stream": stream, **kwargs}

        if stream:
            response = self._client._http.send(
                self._client._http.build_request("POST", "/completions", json=body),
                stream=True,
            )
            if response.status_code >= 400:
                response.read()
                _handle_error(response)
            return Stream(response)

        response = self._client._http.post("/completions", json=body)
        _handle_error(response)
        return ChatCompletion.from_dict(response.json())


class _Chat:
    """Sync chat namespace."""

    def __init__(self, client: "Egune"):
        self.completions = _ChatCompletions(client)


class _Models:
    """Sync models namespace."""

    def __init__(self, client: "Egune"):
        self._client = client

    def list(self) -> ModelList:
        response = self._client._http.get("/models")
        _handle_error(response)
        return ModelList.from_dict(response.json())


class Egune:
    """Synchronous Egune API client.

    Usage::

        from egune import Egune

        client = Egune(api_key="eg-xxx")
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello"}],
        )
        print(response.choices[0].message.content)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
    ):
        self.api_key = api_key
        self._http = httpx.Client(
            base_url=base_url,
            headers=_build_headers(api_key),
            timeout=timeout,
        )
        self.chat = _Chat(self)
        self.completions = _Completions(self)
        self.models = _Models(self)

    def close(self) -> None:
        self._http.close()

    def __enter__(self) -> "Egune":
        return self

    def __exit__(self, *args: object) -> None:
        self.close()


# ── Async ──


class _AsyncChatCompletions:
    """Async chat.completions namespace."""

    def __init__(self, client: "AsyncEgune"):
        self._client = client

    @overload
    async def create(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        stream: Literal[True],
        **kwargs: Any,
    ) -> AsyncStream: ...

    @overload
    async def create(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        stream: Literal[False] = False,
        **kwargs: Any,
    ) -> ChatCompletion: ...

    @overload
    async def create(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        **kwargs: Any,
    ) -> ChatCompletion: ...

    async def create(
        self,
        *,
        model: str,
        messages: List[Dict[str, Any]],
        stream: bool = False,
        **kwargs: Any,
    ) -> Union[ChatCompletion, AsyncStream]:
        body: Dict[str, Any] = {"model": model, "messages": messages, "stream": stream, **kwargs}

        if stream:
            response = await self._client._http.send(
                self._client._http.build_request("POST", "/chat/completions", json=body),
                stream=True,
            )
            if response.status_code >= 400:
                await response.aread()
                _handle_error(response)
            return AsyncStream(response)

        response = await self._client._http.post("/chat/completions", json=body)
        _handle_error(response)
        return ChatCompletion.from_dict(response.json())


class _AsyncCompletions:
    """Async completions namespace."""

    def __init__(self, client: "AsyncEgune"):
        self._client = client

    @overload
    async def create(
        self,
        *,
        model: str,
        prompt: str,
        stream: Literal[True],
        **kwargs: Any,
    ) -> AsyncStream: ...

    @overload
    async def create(
        self,
        *,
        model: str,
        prompt: str,
        stream: Literal[False] = False,
        **kwargs: Any,
    ) -> ChatCompletion: ...

    @overload
    async def create(
        self,
        *,
        model: str,
        prompt: str,
        **kwargs: Any,
    ) -> ChatCompletion: ...

    async def create(
        self,
        *,
        model: str,
        prompt: str,
        stream: bool = False,
        **kwargs: Any,
    ) -> Union[ChatCompletion, AsyncStream]:
        body: Dict[str, Any] = {"model": model, "prompt": prompt, "stream": stream, **kwargs}

        if stream:
            response = await self._client._http.send(
                self._client._http.build_request("POST", "/completions", json=body),
                stream=True,
            )
            if response.status_code >= 400:
                await response.aread()
                _handle_error(response)
            return AsyncStream(response)

        response = await self._client._http.post("/completions", json=body)
        _handle_error(response)
        return ChatCompletion.from_dict(response.json())


class _AsyncChat:
    """Async chat namespace."""

    def __init__(self, client: "AsyncEgune"):
        self.completions = _AsyncChatCompletions(client)


class _AsyncModels:
    """Async models namespace."""

    def __init__(self, client: "AsyncEgune"):
        self._client = client

    async def list(self) -> ModelList:
        response = await self._client._http.get("/models")
        _handle_error(response)
        return ModelList.from_dict(response.json())


class AsyncEgune:
    """Asynchronous Egune API client.

    Usage::

        from egune import AsyncEgune

        client = AsyncEgune(api_key="eg-xxx")
        response = await client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hello"}],
        )
        print(response.choices[0].message.content)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
    ):
        self.api_key = api_key
        self._http = httpx.AsyncClient(
            base_url=base_url,
            headers=_build_headers(api_key),
            timeout=timeout,
        )
        self.chat = _AsyncChat(self)
        self.completions = _AsyncCompletions(self)
        self.models = _AsyncModels(self)

    async def close(self) -> None:
        await self._http.aclose()

    async def __aenter__(self) -> "AsyncEgune":
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()
