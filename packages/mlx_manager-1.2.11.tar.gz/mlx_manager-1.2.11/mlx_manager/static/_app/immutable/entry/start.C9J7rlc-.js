import{l as o,a as r}from"../chunks/CKIPzVrA.js";export{o as load_css,r as start};
