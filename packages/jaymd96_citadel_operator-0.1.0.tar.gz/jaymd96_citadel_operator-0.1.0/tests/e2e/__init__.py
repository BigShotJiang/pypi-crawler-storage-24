"""End-to-end tests for Rubix Lite node lifecycle management.

These tests run against a live k3d cluster and exercise the real Kubernetes API.
Skip the entire suite if no cluster is reachable.
"""
