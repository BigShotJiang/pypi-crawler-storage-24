"""Tests for the NodeInfo and DrainResult models."""

import pytest
from datetime import datetime, timezone, timedelta
from citadel_operator.k3s.node import NodeInfo, DrainResult


class TestNodeInfo:
    def test_frozen(self):
        node = NodeInfo(
            name="test",
            creation_timestamp=datetime.now(timezone.utc),
            age_hours=10.0,
            ready=True,
            schedulable=True,
        )
        with pytest.raises(AttributeError):
            node.name = "changed"

    def test_defaults(self):
        node = NodeInfo(
            name="test",
            creation_timestamp=datetime.now(timezone.utc),
            age_hours=0,
            ready=True,
            schedulable=True,
        )
        assert node.conditions == {}
        assert node.labels == {}
        assert not node.marked_for_termination


class TestDrainResult:
    def test_successful_drain(self):
        result = DrainResult(
            node_name="worker-1",
            success=True,
            pods_evicted=5,
        )
        assert result.success
        assert result.pods_evicted == 5
        assert result.pods_failed == []
        assert result.error is None

    def test_failed_drain(self):
        result = DrainResult(
            node_name="worker-1",
            success=False,
            pods_evicted=3,
            pods_failed=["default/stuck-pod"],
            error="PDB blocked eviction",
        )
        assert not result.success
        assert len(result.pods_failed) == 1

    def test_force_deleted_default(self):
        result = DrainResult(
            node_name="worker-1",
            success=True,
            pods_evicted=5,
        )
        assert result.pods_force_deleted == []

    def test_force_deleted_pods(self):
        result = DrainResult(
            node_name="worker-1",
            success=True,
            pods_evicted=3,
            pods_force_deleted=["default/stuck-pod", "default/stuck-pod-2"],
        )
        assert result.success
        assert len(result.pods_force_deleted) == 2
        assert result.pods_failed == []
