"""Citadel Operator - Lightweight K3s cluster management with Cilium."""

__version__ = "0.1.0"
