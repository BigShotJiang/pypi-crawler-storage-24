"""Kubernetes client extensions for Citadel node lifecycle management."""

from citadel_operator.k3s.certificates import CertificateConfig, CertificateManager
from citadel_operator.k3s.custom_probes import CustomProbeChecker, CustomProbeSpec, parse_custom_probes
from citadel_operator.k3s.health import HealthChecker, NodeCondition
from citadel_operator.k3s.lifecycle_models import (
    CycleResult,
    LifecycleConfig,
    NodeTerminationPolicy,
    PolicyMatch,
)
from citadel_operator.k3s.namespace_infra_builder import (
    build_default_deny_policy,
    build_limit_range,
    build_peer_policies,
    build_resource_quota,
    build_tenant_allow_policy,
)
from citadel_operator.k3s.nerdctl import ImageInfo, Nerdctl
from citadel_operator.k3s.node import NodeManager
from citadel_operator.k3s.probe_discovery import (
    DiscoveredProbe,
    EntityHealth,
    ProbeAnnotation,
    ProbeDiscoverer,
    ProbeResult as DiscoveryProbeResult,
)
from citadel_operator.k3s.provider import (
    ClusterInfo,
    ClusterState,
    RancherDesktopProvider,
    ResetResult,
)
from citadel_operator.k3s.rdctl import Rdctl, RdctlSettings
from citadel_operator.k3s.secrets import (
    ExternalSecretConfig,
    SecretKeyMapping,
    SecretStoreConfig,
    SecretsManager,
)

__all__ = [
    "CertificateConfig",
    "CertificateManager",
    "ClusterInfo",
    "ClusterState",
    "CustomProbeChecker",
    "CustomProbeSpec",
    "CycleResult",
    "DiscoveredProbe",
    "DiscoveryProbeResult",
    "EntityHealth",
    "ExternalSecretConfig",
    "HealthChecker",
    "ImageInfo",
    "LifecycleConfig",
    "Nerdctl",
    "NodeCondition",
    "NodeManager",
    "NodeTerminationPolicy",
    "PolicyMatch",
    "ProbeAnnotation",
    "ProbeDiscoverer",
    "RancherDesktopProvider",
    "Rdctl",
    "RdctlSettings",
    "ResetResult",
    "SecretKeyMapping",
    "SecretStoreConfig",
    "SecretsManager",
    "build_default_deny_policy",
    "build_limit_range",
    "build_peer_policies",
    "build_resource_quota",
    "build_tenant_allow_policy",
    "parse_custom_probes",
]
