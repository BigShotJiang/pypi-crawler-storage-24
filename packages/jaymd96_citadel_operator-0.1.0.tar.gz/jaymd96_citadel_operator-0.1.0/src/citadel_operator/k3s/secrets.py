"""External secrets management for Rubix Citadel.

Provides programmatic access to external-secrets-operator resources:
generating SecretStore/ClusterSecretStore YAML manifests, generating
ExternalSecret manifests, listing stores/secrets, and checking sync status.

Integrates with the external-secrets-operator CRDs defined in
security/secrets/secret-stores.yaml and security/secrets/external-secrets.yaml.

Design decisions:
  - SecretStoreConfig, ExternalSecretConfig, SecretKeyMapping are frozen dataclasses
    (consistent with CertificateConfig, NodeInfo, DrainResult, etc.)
  - create_secret_store/create_external_secret are static methods — pure YAML
    generation, no cluster access needed
  - list_secret_stores, list_external_secrets, check_sync_status require a live
    Kubernetes client
  - Namespace=None on SecretStoreConfig means ClusterSecretStore (cluster-wide scope)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from kubernetes import client, config
from kubernetes.client.exceptions import ApiException

if TYPE_CHECKING:
    pass

logger = logging.getLogger(__name__)

# external-secrets-operator API group and version
ESO_GROUP = "external-secrets.io"
ESO_VERSION = "v1beta1"
ESO_SECRET_STORE_PLURAL = "secretstores"
ESO_CLUSTER_SECRET_STORE_PLURAL = "clustersecretstores"
ESO_EXTERNAL_SECRET_PLURAL = "externalsecrets"

# Supported secret store providers
VALID_PROVIDERS = frozenset({
    "kubernetes",
    "vault",
    "aws",
    "azure",
})

# Default refresh interval for ExternalSecrets
DEFAULT_REFRESH_INTERVAL = "1h"

# Valid refresh interval units (external-secrets-operator format)
VALID_REFRESH_UNITS = frozenset({"s", "m", "h"})


def _validate_refresh_interval(interval: str) -> None:
    """Validate that a refresh interval string is well-formed.

    Accepts formats like "1h", "30m", "300s", "0" (disabled).

    Raises:
        ValueError: If the interval format is invalid.
    """
    if interval == "0":
        return
    if not interval:
        raise ValueError("refresh_interval must not be empty")
    if interval[-1] not in VALID_REFRESH_UNITS:
        raise ValueError(
            f"refresh_interval must end with one of {sorted(VALID_REFRESH_UNITS)}, "
            f"got '{interval}'"
        )
    numeric_part = interval[:-1]
    if not numeric_part.isdigit():
        raise ValueError(
            f"refresh_interval numeric part must be a non-negative integer, "
            f"got '{numeric_part}'"
        )
    if int(numeric_part) < 0:
        raise ValueError(
            f"refresh_interval must be non-negative, got '{interval}'"
        )


@dataclass(frozen=True)
class SecretKeyMapping:
    """Maps a single key from an external secret store to a Kubernetes Secret key.

    Attributes:
        remote_key: The key/path in the external secret provider
            (e.g., "my-app/database" for Vault, or the secret name for AWS).
        secret_key: The key name in the resulting Kubernetes Secret's data map.
        property: Optional property/field within the remote secret. When the
            remote secret is a JSON object, this extracts a single field.
            None means use the entire value.
    """

    remote_key: str
    secret_key: str
    property: str | None = None

    def __post_init__(self) -> None:
        if not self.remote_key:
            raise ValueError("remote_key must not be empty")
        if not self.secret_key:
            raise ValueError("secret_key must not be empty")


@dataclass(frozen=True)
class SecretStoreConfig:
    """Configuration for an external-secrets SecretStore or ClusterSecretStore.

    When namespace is None, a ClusterSecretStore is generated (available to all
    namespaces). When namespace is set, a namespace-scoped SecretStore is generated.

    Attributes:
        name: Resource name for the SecretStore.
        provider: Backend provider type. One of: kubernetes, vault, aws, azure.
        namespace: Kubernetes namespace. None for ClusterSecretStore.
        vault_url: Vault server URL. Required when provider is "vault".
        aws_region: AWS region. Required when provider is "aws".
        azure_vault_url: Azure Key Vault URL. Required when provider is "azure".
    """

    name: str
    provider: str
    namespace: str | None = None
    vault_url: str | None = None
    aws_region: str | None = None
    azure_vault_url: str | None = None

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("name must not be empty")
        if self.provider not in VALID_PROVIDERS:
            raise ValueError(
                f"provider must be one of {sorted(VALID_PROVIDERS)}, "
                f"got '{self.provider}'"
            )
        if self.provider == "vault" and not self.vault_url:
            raise ValueError("vault_url is required when provider is 'vault'")
        if self.provider == "aws" and not self.aws_region:
            raise ValueError("aws_region is required when provider is 'aws'")
        if self.provider == "azure" and not self.azure_vault_url:
            raise ValueError(
                "azure_vault_url is required when provider is 'azure'"
            )

    @property
    def is_cluster_scoped(self) -> bool:
        """Return True if this generates a ClusterSecretStore."""
        return self.namespace is None


@dataclass(frozen=True)
class ExternalSecretConfig:
    """Configuration for an external-secrets ExternalSecret resource.

    An ExternalSecret describes what data to fetch from an external provider
    and how to map it into a Kubernetes Secret.

    Attributes:
        name: Resource name for the ExternalSecret.
        namespace: Kubernetes namespace for the ExternalSecret and target Secret.
        store_name: Name of the SecretStore or ClusterSecretStore to use.
        refresh_interval: How often to sync from the external provider.
            Format: "<number><unit>" where unit is s/m/h. "0" disables refresh.
        keys: Mappings from remote keys to Kubernetes Secret keys.
        target_secret_name: Name of the Kubernetes Secret to create. If None,
            defaults to the ExternalSecret name.
        store_kind: Kind of the referenced store. Either "SecretStore" or
            "ClusterSecretStore". Default is "SecretStore".
    """

    name: str
    namespace: str
    store_name: str
    refresh_interval: str = DEFAULT_REFRESH_INTERVAL
    keys: tuple[SecretKeyMapping, ...] = ()
    target_secret_name: str | None = None
    store_kind: str = "SecretStore"

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("name must not be empty")
        if not self.namespace:
            raise ValueError("namespace must not be empty")
        if not self.store_name:
            raise ValueError("store_name must not be empty")
        if not isinstance(self.keys, tuple):
            raise TypeError("keys must be a tuple")
        if not self.keys:
            raise ValueError("keys must contain at least one SecretKeyMapping")
        _validate_refresh_interval(self.refresh_interval)
        if self.store_kind not in ("SecretStore", "ClusterSecretStore"):
            raise ValueError(
                f"store_kind must be 'SecretStore' or 'ClusterSecretStore', "
                f"got '{self.store_kind}'"
            )

    @property
    def effective_target_name(self) -> str:
        """Return the target Secret name, defaulting to the ExternalSecret name."""
        if self.target_secret_name is not None:
            return self.target_secret_name
        return self.name


class SecretsManager:
    """Manages external-secrets-operator resources in a Kubernetes cluster.

    Provides both static methods for offline YAML generation and instance
    methods for live cluster operations (list stores, list secrets, check sync).

    Usage::

        # Offline: generate a SecretStore manifest
        store_config = SecretStoreConfig(
            name="vault-backend",
            provider="vault",
            namespace="production",
            vault_url="https://vault.example.com",
        )
        manifest = SecretsManager.create_secret_store(store_config)

        # Offline: generate an ExternalSecret manifest
        secret_config = ExternalSecretConfig(
            name="my-app-secrets",
            namespace="production",
            store_name="vault-backend",
            keys=(
                SecretKeyMapping(
                    remote_key="secret/data/my-app",
                    secret_key="database-url",
                    property="db_url",
                ),
            ),
        )
        manifest = SecretsManager.create_external_secret(secret_config)

        # Online: check sync status
        manager = SecretsManager()
        status = manager.check_sync_status("my-app-secrets", "production")
    """

    def __init__(self, kubeconfig: str | None = None) -> None:
        """Initialize with Kubernetes client configuration.

        Args:
            kubeconfig: Path to kubeconfig file. If None, tries in-cluster
                config first, then falls back to default kubeconfig.
        """
        if kubeconfig:
            config.load_kube_config(config_file=kubeconfig)
        else:
            try:
                config.load_incluster_config()
            except config.ConfigException:
                config.load_kube_config()

        self._custom = client.CustomObjectsApi()

    @staticmethod
    def create_secret_store(store_config: SecretStoreConfig) -> dict:
        """Generate a SecretStore or ClusterSecretStore resource as a dict.

        This is a pure function -- no cluster access required. The returned
        dict can be serialized to YAML and applied via kubectl, or passed
        directly to the Kubernetes API.

        Args:
            store_config: SecretStore configuration.

        Returns:
            A dict representing a SecretStore or ClusterSecretStore resource.
        """
        kind = "ClusterSecretStore" if store_config.is_cluster_scoped else "SecretStore"

        provider_spec = SecretsManager._build_provider_spec(store_config)

        metadata: dict = {
            "name": store_config.name,
            "labels": {
                "app.kubernetes.io/managed-by": "citadel-operator",
            },
        }
        if not store_config.is_cluster_scoped:
            metadata["namespace"] = store_config.namespace

        return {
            "apiVersion": f"{ESO_GROUP}/{ESO_VERSION}",
            "kind": kind,
            "metadata": metadata,
            "spec": {
                "provider": provider_spec,
            },
        }

    @staticmethod
    def create_external_secret(secret_config: ExternalSecretConfig) -> dict:
        """Generate an ExternalSecret resource as a dict.

        This is a pure function -- no cluster access required. The returned
        dict can be serialized to YAML and applied via kubectl, or passed
        directly to the Kubernetes API.

        Args:
            secret_config: ExternalSecret configuration.

        Returns:
            A dict representing an ExternalSecret resource.
        """
        data_entries = []
        for mapping in secret_config.keys:
            entry: dict = {
                "secretKey": mapping.secret_key,
                "remoteRef": {
                    "key": mapping.remote_key,
                },
            }
            if mapping.property is not None:
                entry["remoteRef"]["property"] = mapping.property
            data_entries.append(entry)

        spec: dict = {
            "refreshInterval": secret_config.refresh_interval,
            "secretStoreRef": {
                "name": secret_config.store_name,
                "kind": secret_config.store_kind,
            },
            "target": {
                "name": secret_config.effective_target_name,
                "creationPolicy": "Owner",
            },
            "data": data_entries,
        }

        return {
            "apiVersion": f"{ESO_GROUP}/{ESO_VERSION}",
            "kind": "ExternalSecret",
            "metadata": {
                "name": secret_config.name,
                "namespace": secret_config.namespace,
                "labels": {
                    "app.kubernetes.io/managed-by": "citadel-operator",
                },
            },
            "spec": spec,
        }

    def list_secret_stores(self, namespace: str | None = None) -> list[dict]:
        """List SecretStore or ClusterSecretStore resources.

        Args:
            namespace: If provided, lists namespace-scoped SecretStores.
                If None, lists ClusterSecretStores.

        Returns:
            List of SecretStore/ClusterSecretStore resource dicts. Empty list
            if none found or if the external-secrets CRDs are not installed.
        """
        try:
            if namespace is None:
                result = self._custom.list_cluster_custom_object(
                    group=ESO_GROUP,
                    version=ESO_VERSION,
                    plural=ESO_CLUSTER_SECRET_STORE_PLURAL,
                )
            else:
                result = self._custom.list_namespaced_custom_object(
                    group=ESO_GROUP,
                    version=ESO_VERSION,
                    namespace=namespace,
                    plural=ESO_SECRET_STORE_PLURAL,
                )
            return result.get("items", [])
        except ApiException as e:
            if e.status == 404:
                logger.warning(
                    "external-secrets CRDs not found. "
                    "Is external-secrets-operator installed?"
                )
                return []
            logger.error(
                "Failed to list secret stores (namespace=%s): %s",
                namespace,
                e.reason,
            )
            raise

    def list_external_secrets(self, namespace: str) -> list[dict]:
        """List ExternalSecret resources in a namespace.

        Args:
            namespace: Kubernetes namespace to query.

        Returns:
            List of ExternalSecret resource dicts. Empty list if none found
            or if the external-secrets CRDs are not installed.
        """
        try:
            result = self._custom.list_namespaced_custom_object(
                group=ESO_GROUP,
                version=ESO_VERSION,
                namespace=namespace,
                plural=ESO_EXTERNAL_SECRET_PLURAL,
            )
            return result.get("items", [])
        except ApiException as e:
            if e.status == 404:
                logger.warning(
                    "external-secrets CRDs not found. "
                    "Is external-secrets-operator installed?"
                )
                return []
            logger.error(
                "Failed to list external secrets in %s: %s",
                namespace,
                e.reason,
            )
            raise

    def check_sync_status(self, name: str, namespace: str) -> dict:
        """Check the sync status of an ExternalSecret.

        Reads the ExternalSecret's status conditions to determine whether
        the secret has been successfully synced from the external provider.

        Args:
            name: ExternalSecret resource name.
            namespace: Kubernetes namespace.

        Returns:
            A dict with keys:
                - "name": ExternalSecret name
                - "namespace": namespace
                - "synced": bool indicating successful sync
                - "status": human-readable status string
                - "last_sync": last sync timestamp string, or None
                - "conditions": list of status condition dicts
        """
        try:
            resource = self._custom.get_namespaced_custom_object(
                group=ESO_GROUP,
                version=ESO_VERSION,
                namespace=namespace,
                plural=ESO_EXTERNAL_SECRET_PLURAL,
                name=name,
            )
        except ApiException as e:
            if e.status == 404:
                logger.error(
                    "ExternalSecret %s not found in namespace %s",
                    name,
                    namespace,
                )
                return {
                    "name": name,
                    "namespace": namespace,
                    "synced": False,
                    "status": "NotFound",
                    "last_sync": None,
                    "conditions": [],
                }
            raise

        status = resource.get("status", {})
        conditions = status.get("conditions", [])

        synced = False
        status_text = "Unknown"
        for condition in conditions:
            if condition.get("type") == "Ready":
                synced = condition.get("status") == "True"
                status_text = condition.get("reason", "Unknown")
                break

        # refreshTime is set by ESO on successful sync
        last_sync = status.get("refreshTime")

        return {
            "name": name,
            "namespace": namespace,
            "synced": synced,
            "status": status_text,
            "last_sync": last_sync,
            "conditions": conditions,
        }

    @staticmethod
    def _build_provider_spec(store_config: SecretStoreConfig) -> dict:
        """Build the provider section of a SecretStore spec.

        Each provider has a different configuration shape. This method
        generates the appropriate structure with placeholder auth references
        that the operator will use to authenticate.
        """
        if store_config.provider == "kubernetes":
            return {
                "kubernetes": {
                    "remoteNamespace": "default",
                    "server": {
                        "caProvider": {
                            "type": "ConfigMap",
                            "name": "kube-root-ca.crt",
                            "key": "ca.crt",
                        },
                    },
                    "auth": {
                        "serviceAccount": {
                            "name": "external-secrets-sa",
                        },
                    },
                },
            }

        if store_config.provider == "vault":
            return {
                "vault": {
                    "server": store_config.vault_url,
                    "path": "secret",
                    "version": "v2",
                    "auth": {
                        "kubernetes": {
                            "mountPath": "kubernetes",
                            "role": "external-secrets",
                            "serviceAccountRef": {
                                "name": "external-secrets-sa",
                            },
                        },
                    },
                },
            }

        if store_config.provider == "aws":
            return {
                "aws": {
                    "service": "SecretsManager",
                    "region": store_config.aws_region,
                    "auth": {
                        "secretRef": {
                            "accessKeyIDSecretRef": {
                                "name": "aws-credentials",
                                "key": "access-key-id",
                            },
                            "secretAccessKeySecretRef": {
                                "name": "aws-credentials",
                                "key": "secret-access-key",
                            },
                        },
                    },
                },
            }

        # azure
        return {
            "azurekv": {
                "vaultUrl": store_config.azure_vault_url,
                "authType": "ManagedIdentity",
            },
        }
