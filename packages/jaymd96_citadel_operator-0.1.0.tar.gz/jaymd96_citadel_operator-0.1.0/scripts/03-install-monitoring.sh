#!/bin/bash
#
# Rubix Monitoring Stack Installation
# Installs Prometheus + Grafana with Cilium ServiceMonitors
#

set -e

echo "=========================================="
echo "  Rubix Monitoring Stack Installation"
echo "  Prometheus + Grafana"
echo "=========================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Set kubeconfig
export KUBECONFIG=/etc/rancher/k3s/k3s.yaml

# Check kubectl access
if ! kubectl get nodes &>/dev/null; then
    echo -e "${RED}Error: Cannot connect to Kubernetes cluster${NC}"
    exit 1
fi

echo -e "${YELLOW}Step 1: Adding Prometheus Helm repository...${NC}"
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo update
echo -e "${GREEN}Repository added${NC}"
echo ""

echo -e "${YELLOW}Step 2: Creating monitoring namespace...${NC}"
kubectl create namespace monitoring --dry-run=client -o yaml | kubectl apply -f -
echo -e "${GREEN}Namespace created${NC}"
echo ""

echo -e "${YELLOW}Step 3: Installing kube-prometheus-stack...${NC}"
echo ""
echo "This includes:"
echo "  - Prometheus (metrics collection)"
echo "  - Grafana (visualization)"
echo "  - AlertManager (alerting)"
echo "  - Node Exporter (host metrics)"
echo "  - Kube State Metrics (K8s metrics)"
echo ""

# Generate a random Grafana admin password
GRAFANA_PASSWORD=$(openssl rand -base64 18 | tr -d '/+=' | head -c 24)

helm upgrade --install prometheus prometheus-community/kube-prometheus-stack \
  --namespace monitoring \
  --set grafana.adminPassword="$GRAFANA_PASSWORD" \
  --set grafana.service.type=ClusterIP \
  --set prometheus.prometheusSpec.serviceMonitorSelectorNilUsesHelmValues=false \
  --set prometheus.prometheusSpec.podMonitorSelectorNilUsesHelmValues=false \
  --wait

echo ""
echo -e "${GREEN}Prometheus stack installed${NC}"
echo ""

echo -e "${YELLOW}Step 4: Applying Cilium ServiceMonitors...${NC}"
# Get the directory of this script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
kubectl apply -f "$SCRIPT_DIR/../monitoring/prometheus-stack.yaml" 2>/dev/null || echo "ServiceMonitors may need CRDs first"
echo -e "${GREEN}ServiceMonitors applied${NC}"
echo ""

echo -e "${YELLOW}Step 5: Waiting for pods to be ready...${NC}"
kubectl wait --for=condition=Ready pods -l release=prometheus -n monitoring --timeout=300s
echo ""

echo -e "${YELLOW}Step 6: Showing monitoring components...${NC}"
kubectl get pods -n monitoring
echo ""

echo "=========================================="
echo -e "${GREEN}Monitoring Stack Installation Complete!${NC}"
echo "=========================================="
echo ""
echo "Access Grafana:"
echo "  kubectl port-forward -n monitoring svc/prometheus-grafana 3000:80"
echo "  Then open: http://localhost:3000"
echo "  Username: admin"
echo "  Password: $GRAFANA_PASSWORD"
echo ""
echo -e "${YELLOW}Save this password! It will not be shown again.${NC}"
echo "To reset: helm upgrade prometheus prometheus-community/kube-prometheus-stack --namespace monitoring --reuse-values --set grafana.adminPassword=NEW_PASSWORD"
echo ""
echo "Access Prometheus:"
echo "  kubectl port-forward -n monitoring svc/prometheus-kube-prometheus-prometheus 9090:9090"
echo "  Then open: http://localhost:9090"
echo ""
echo "Recommended Grafana Dashboards:"
echo "  - Cilium Metrics: Import dashboard ID 16611"
echo "  - Hubble Metrics: Import dashboard ID 16613"
echo ""
