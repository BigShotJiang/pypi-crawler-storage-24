#!/bin/bash
#
# Rubix K3s Installation Script
# Installs K3s with Flannel and kube-proxy disabled for Cilium CNI
#

set -e

echo "=========================================="
echo "  Rubix K3s Installation"
echo "  Security-First Kubernetes Platform"
echo "=========================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Check if running as root
if [[ $EUID -ne 0 ]]; then
   echo -e "${RED}This script must be run as root or with sudo${NC}"
   exit 1
fi

# Check system requirements
echo -e "${YELLOW}Checking system requirements...${NC}"

# Check CPU cores
CPU_CORES=$(nproc)
if [ "$CPU_CORES" -lt 2 ]; then
    echo -e "${RED}Warning: At least 2 CPU cores recommended (found: $CPU_CORES)${NC}"
fi

# Check available memory
MEM_GB=$(free -g | awk '/^Mem:/{print $2}')
if [ "$MEM_GB" -lt 4 ]; then
    echo -e "${RED}Warning: At least 4GB RAM recommended (found: ${MEM_GB}GB)${NC}"
fi

# Check disk space
DISK_GB=$(df -BG / | awk 'NR==2 {print $4}' | sed 's/G//')
if [ "$DISK_GB" -lt 20 ]; then
    echo -e "${RED}Warning: At least 20GB disk space recommended (found: ${DISK_GB}GB)${NC}"
fi

echo -e "${GREEN}System check complete${NC}"
echo ""

# Install K3s with security-first configuration
echo -e "${YELLOW}Installing K3s with Rubix configuration...${NC}"
echo ""
echo "Configuration:"
echo "  - Flannel CNI: DISABLED (Cilium will provide CNI)"
echo "  - kube-proxy: DISABLED (Cilium will replace)"
echo "  - Network Policy: DISABLED (Cilium provides enhanced policies)"
echo "  - ServiceLB: DISABLED (optional, Cilium can provide)"
echo "  - Traefik: DISABLED (deploy your own ingress)"
echo ""

curl -sfL https://get.k3s.io | sh -s - \
  --flannel-backend=none \
  --disable-kube-proxy \
  --disable-network-policy \
  --disable servicelb \
  --disable traefik \
  --write-kubeconfig-mode 644

# Wait for K3s to be ready (partial - no CNI yet)
echo ""
echo -e "${YELLOW}Waiting for K3s to start...${NC}"
sleep 10

# Setup kubectl for current user
echo -e "${YELLOW}Setting up kubectl access...${NC}"

if [ -n "$SUDO_USER" ]; then
    USER_HOME=$(getent passwd "$SUDO_USER" | cut -d: -f6)
    mkdir -p "$USER_HOME/.kube"
    cp /etc/rancher/k3s/k3s.yaml "$USER_HOME/.kube/config"
    chown -R "$SUDO_USER:$SUDO_USER" "$USER_HOME/.kube"
    echo -e "${GREEN}kubectl configured for user: $SUDO_USER${NC}"
fi

# Export for current session
export KUBECONFIG=/etc/rancher/k3s/k3s.yaml

# Check K3s status
echo ""
echo -e "${YELLOW}K3s Status:${NC}"
systemctl status k3s --no-pager || true

# Show nodes (will be NotReady until Cilium is installed)
echo ""
echo -e "${YELLOW}Cluster Nodes:${NC}"
kubectl get nodes || true

echo ""
echo "=========================================="
echo -e "${GREEN}K3s Installation Complete!${NC}"
echo "=========================================="
echo ""
echo "Node is in 'NotReady' state - this is expected."
echo "Run the Cilium installation script next:"
echo ""
echo "  sudo ./02-install-cilium.sh"
echo ""
echo "To use kubectl, run:"
echo "  export KUBECONFIG=/etc/rancher/k3s/k3s.yaml"
echo ""
