#!/bin/bash
#
# Rubix Demo Application Deployment Script
# Deploys the 3-tier demo app with zero-trust policies
#

set -e

echo "=========================================="
echo "  Rubix Demo Application Deployment"
echo "  3-Tier Architecture with Zero-Trust"
echo "=========================================="
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Set kubeconfig
export KUBECONFIG=/etc/rancher/k3s/k3s.yaml

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(dirname "$SCRIPT_DIR")"

# Check Cilium is ready
echo -e "${YELLOW}Step 1: Verifying Cilium is ready...${NC}"
if ! cilium status &>/dev/null; then
    echo -e "${RED}Error: Cilium is not ready. Run 02-install-cilium.sh first.${NC}"
    exit 1
fi
echo -e "${GREEN}Cilium is ready${NC}"
echo ""

# Apply default deny policies first
echo -e "${YELLOW}Step 2: Applying default-deny policies...${NC}"
kubectl apply -f "$BASE_DIR/policies/01-default-deny.yaml"
echo -e "${GREEN}Default-deny policies applied${NC}"
echo ""

# Apply system policies
echo -e "${YELLOW}Step 3: Applying system policies...${NC}"
kubectl apply -f "$BASE_DIR/policies/02-system-policies.yaml"
echo -e "${GREEN}System policies applied${NC}"
echo ""

# Deploy demo application
echo -e "${YELLOW}Step 4: Deploying demo application...${NC}"
kubectl apply -f "$BASE_DIR/apps/demo-app.yaml"
echo -e "${GREEN}Demo application deployed${NC}"
echo ""

# Wait for pods to be ready
echo -e "${YELLOW}Step 5: Waiting for pods to be ready...${NC}"
kubectl wait --for=condition=Ready pods -l tier=frontend -n demo --timeout=120s
kubectl wait --for=condition=Ready pods -l tier=backend -n demo --timeout=120s
kubectl wait --for=condition=Ready pods -l tier=database -n demo --timeout=120s
echo -e "${GREEN}All pods are ready${NC}"
echo ""

# Apply demo app policies
echo -e "${YELLOW}Step 6: Applying demo app network policies...${NC}"
kubectl apply -f "$BASE_DIR/policies/03-demo-app-policies.yaml"
echo -e "${GREEN}Demo app policies applied${NC}"
echo ""

# Show deployment status
echo -e "${YELLOW}Step 7: Deployment Status${NC}"
echo ""
echo -e "${BLUE}Pods:${NC}"
kubectl get pods -n demo -o wide
echo ""

echo -e "${BLUE}Services:${NC}"
kubectl get svc -n demo
echo ""

echo -e "${BLUE}Network Policies:${NC}"
kubectl get ciliumnetworkpolicies -n demo
echo ""

echo "=========================================="
echo -e "${GREEN}Demo Application Deployed!${NC}"
echo "=========================================="
echo ""
echo "Architecture:"
echo "  [External] --> frontend:80 --> backend:5678 --> database:6379"
echo ""
echo "Test connectivity:"
echo ""
echo "  # From test-client to frontend (should WORK):"
echo "  kubectl exec -n demo test-client -- curl -s frontend:80"
echo ""
echo "  # From test-client to backend (should WORK):"
echo "  kubectl exec -n demo test-client -- curl -s backend:5678"
echo ""
echo "  # From test-client to database (should FAIL - blocked by policy):"
echo "  kubectl exec -n demo test-client -- timeout 3 redis-cli -h database ping"
echo ""
echo "  # From frontend to database (should FAIL - not allowed):"
echo "  kubectl exec -n demo deploy/frontend -- timeout 3 nc -zv database 6379"
echo ""
echo "Watch network flows:"
echo "  cilium hubble port-forward &"
echo "  hubble observe --namespace demo"
echo ""
echo "View dropped packets:"
echo "  hubble observe --namespace demo --verdict DROPPED"
echo ""
