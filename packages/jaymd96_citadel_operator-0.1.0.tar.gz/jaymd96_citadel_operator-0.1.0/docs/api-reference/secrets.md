# Secrets Management API

Module: `citadel_operator.k3s.secrets`

Manages external-secrets-operator resources — YAML generation (pure) and cluster operations (list, sync status).

## Constants

```python
VALID_PROVIDERS = {"kubernetes", "vault", "aws", "azure"}
DEFAULT_REFRESH_INTERVAL = "1h"
VALID_REFRESH_UNITS = {"s", "m", "h"}
```

## SecretKeyMapping

Frozen dataclass mapping a remote secret key to a Kubernetes Secret key.

```python
@dataclass(frozen=True)
class SecretKeyMapping:
    remote_key: str             # Key/path in the external store
    secret_key: str             # Resulting key in the K8s Secret
    property: str | None = None # JSON field to extract (optional)
```

## SecretStoreConfig

Frozen dataclass defining a SecretStore or ClusterSecretStore.

```python
@dataclass(frozen=True)
class SecretStoreConfig:
    name: str
    provider: str                          # One of VALID_PROVIDERS
    namespace: str | None = None           # None → ClusterSecretStore
    vault_url: str | None = None           # Required for vault provider
    aws_region: str | None = None          # Required for aws provider
    azure_vault_url: str | None = None     # Required for azure provider

    @property
    def is_cluster_scoped(self) -> bool: ... # True if namespace is None
```

### Validation

- `provider` must be in `VALID_PROVIDERS`
- `vault_url` required when `provider == "vault"`
- `aws_region` required when `provider == "aws"`
- `azure_vault_url` required when `provider == "azure"`

## ExternalSecretConfig

Frozen dataclass defining an ExternalSecret.

```python
@dataclass(frozen=True)
class ExternalSecretConfig:
    name: str
    namespace: str
    store_name: str
    refresh_interval: str = "1h"           # Format: number + s|m|h
    keys: tuple[SecretKeyMapping, ...] = ()
    target_secret_name: str | None = None  # Auto-generated from name if None
    store_kind: str = "SecretStore"        # "SecretStore" or "ClusterSecretStore"

    @property
    def effective_target_name(self) -> str: ...
```

## SecretsManager

### Constructor

```python
SecretsManager(kubeconfig: str | None = None)
```

### Methods

| Method | Signature | Description |
|--------|-----------|-------------|
| `create_secret_store` | `@staticmethod (config) -> dict` | Pure YAML generation |
| `create_external_secret` | `@staticmethod (config) -> dict` | Pure YAML generation |
| `list_secret_stores` | `(namespace=None) -> list[dict]` | List stores (namespace=None lists ClusterSecretStores) |
| `list_external_secrets` | `(namespace) -> list[dict]` | List ExternalSecrets in namespace |
| `check_sync_status` | `(name, namespace) -> dict` | Get sync status (checks Ready condition) |

### Usage

```python
from citadel_operator import SecretStoreConfig, ExternalSecretConfig, SecretKeyMapping, SecretsManager

# Create a Vault SecretStore (pure)
store = SecretStoreConfig(
    name="vault-backend",
    provider="vault",
    namespace="production",
    vault_url="https://vault.internal:8200",
)
store_yaml = SecretsManager.create_secret_store(store)

# Create an ExternalSecret (pure)
secret = ExternalSecretConfig(
    name="db-credentials",
    namespace="production",
    store_name="vault-backend",
    refresh_interval="5m",
    keys=(
        SecretKeyMapping(remote_key="secret/data/db", secret_key="username", property="username"),
        SecretKeyMapping(remote_key="secret/data/db", secret_key="password", property="password"),
    ),
)
secret_yaml = SecretsManager.create_external_secret(secret)

# Check sync status
sm = SecretsManager()
status = sm.check_sync_status("db-credentials", namespace="production")
print(status)  # {"ready": True, "status": "SecretSynced", ...}
```
