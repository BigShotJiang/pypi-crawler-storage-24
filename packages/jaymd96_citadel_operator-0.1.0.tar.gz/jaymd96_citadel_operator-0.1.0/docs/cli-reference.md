# CLI Reference

Citadel has two CLIs serving different purposes.

## `citadel` — Operator Deployment

Installed via pip. Manages the operator within an existing Kubernetes cluster.

### `citadel install`

Install the operator, CRDs, RBAC, and default policies into a cluster.

```bash
citadel install [--namespace NS] [--image IMG] [--with-default-policies] [--no-default-policies] [--timeout SECS]
```

| Flag | Default | Description |
|------|---------|-------------|
| `--namespace` | `citadel-system` | Target namespace for operator deployment |
| `--image` | `citadel-operator:latest` | Operator container image |
| `--with-default-policies` | `true` | Apply built-in NodeTerminationPolicies |
| `--no-default-policies` | — | Skip applying default policies |
| `--timeout` | `120` | Seconds to wait for Deployment rollout |

**What it creates:**
1. Namespace
2. CRDs (`NodeTerminationPolicy`, `NamespaceInfrastructure`)
3. ServiceAccount `citadel-operator`
4. ClusterRole with 14 permission rules
5. ClusterRoleBinding
6. Deployment (1 replica, non-root uid 1000, resource limits 100m/128Mi → 500m/256Mi)
7. Default policies (if enabled): `max-age-48h`, `disk-pressure`, `memory-pressure`, `not-ready`, `stuck-volume-detector` (disabled), `gpu-health-detector` (disabled)

**Idempotent.** Safe to re-run — uses create-or-patch strategy (409 Conflict triggers patch).

### `citadel uninstall`

Remove the operator from the cluster.

```bash
citadel uninstall [--namespace NS] [--delete-crds]
```

| Flag | Default | Description |
|------|---------|-------------|
| `--namespace` | `citadel-system` | Namespace to remove operator from |
| `--delete-crds` | `false` | Also delete CRDs (**destructive** — removes all CRD instances) |

### `citadel status`

Check operator installation health.

```bash
citadel status [--namespace NS]
```

Reports: namespace existence, CRD registration, Deployment readiness, pod status.

### `citadel manifests`

Print all Kubernetes manifests to stdout for review. No cluster connection required.

```bash
citadel manifests [--namespace NS] [--image IMG]
```

Outputs YAML for: Namespace, CRDs, ServiceAccount, ClusterRole, ClusterRoleBinding, Deployment, and default policies.

Useful for GitOps workflows:

```bash
citadel manifests > operator.yaml
kubectl apply -f operator.yaml
```

---

## `./rubix` — Infrastructure Setup

Executable Python script in the repository root. Wraps shell scripts and kubectl commands for bootstrapping cluster infrastructure.

**Requires**: scripts in `scripts/` directory and policies in `policies/` directory (i.e., run from the repo root).

### Cluster Management

```bash
./rubix cluster create <name> [--nodes N]
```

Create a K3s cluster using Rancher Desktop. With `--nodes 1` (default), creates a single server node. With `--nodes 3`, creates a server + 2 agent nodes that auto-join the cluster.

K3s is installed with `--flannel-backend=none --disable-kube-proxy --disable-network-policy` to prepare for Cilium.

```bash
./rubix cluster delete <name>
```

Destroy all VMs matching the cluster name (server + workers).

```bash
./rubix cluster list
```

List all cluster VMs.

### Node Operations

```bash
./rubix node status
```

Show node ages and health using `scripts/node-lifecycle.sh status`.

```bash
./rubix node list
```

Display nodes with lifecycle-specific columns: NAME, AGE, READY, SCHEDULABLE, TERMINATE-REASON, POLICY-NAME.

### Lifecycle Management

```bash
./rubix lifecycle install
```

Apply CRDs and RBAC for node lifecycle management. Runs `kubectl apply` on `crds/nodeterminationpolicy.yaml`, `crds/rbac.yaml`, and `crds/default-policies.yaml`.

```bash
./rubix lifecycle policies
```

List active NodeTerminationPolicy resources: `kubectl get nodeterminationpolicies.rubix.dev -o wide`.

### Network Operations

```bash
./rubix network install
```

Install Cilium CNI with Hubble. Runs `scripts/02-install-cilium.sh`.

```bash
./rubix network policies
```

Apply all network policies from the `policies/` directory (sorted alphabetically). Each `.yaml` file is applied via `kubectl apply -f`.

```bash
./rubix network test
```

Run network policy verification tests. Runs `scripts/05-test-policies.sh`.

### Monitoring

```bash
./rubix monitor install
```

Install the Prometheus + Grafana monitoring stack. Runs `scripts/03-install-monitoring.sh`.

### Security

```bash
./rubix security enable-wireguard
```

Enable transparent WireGuard pod-to-pod encryption. Runs `scripts/06-enable-wireguard.sh`.

```bash
./rubix security enable-audit
```

Enable Kubernetes API audit logging. Runs `scripts/07-enable-audit-logging.sh`. Requires K3s restart.

### Help

```bash
./rubix help
./rubix -h
./rubix --help
```

---

## Environment Variables

| Variable | Default | Used By |
|----------|---------|---------|
| `KUBECONFIG` | `/etc/rancher/k3s/k3s.yaml` | All scripts, `citadel` CLI |
| `NODE_MAX_AGE_HOURS` | `48` | `node-lifecycle.sh` |
| `DRAIN_TIMEOUT` | `300` | `node-lifecycle.sh` |
| `DRY_RUN` | `false` | `node-lifecycle.sh` |

## CLI Comparison

| Feature | `citadel` | `./rubix` |
|---------|-----------|-----------|
| Install method | `pip install citadel-operator` | Run from repo root |
| Cluster creation | No | Yes (Rancher Desktop) |
| Operator deployment | Yes | No |
| Network setup | No | Yes (Cilium, policies) |
| Monitoring setup | No | Yes (Prometheus, Grafana) |
| Security tools | No | Yes (WireGuard, audit) |
| Requires repo checkout | No | Yes |
| Idempotent | Yes | Varies by script |
