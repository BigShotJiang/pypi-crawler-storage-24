"""Sample Python service for Apollo deployment."""

from fastapi import FastAPI
import os

app = FastAPI(title="Sample Service")

VERSION = os.getenv("VERSION", "1.0.0")
ENVIRONMENT = os.getenv("ENVIRONMENT", "unknown")


@app.get("/")
async def root():
    """Root endpoint."""
    return {
        "service": "sample-python-service",
        "version": VERSION,
        "environment": ENVIRONMENT,
        "status": "healthy"
    }


@app.get("/health")
async def health():
    """Health check endpoint."""
    return {"status": "healthy"}


@app.get("/readiness")
async def readiness():
    """Readiness check endpoint."""
    return {"ready": True}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)
