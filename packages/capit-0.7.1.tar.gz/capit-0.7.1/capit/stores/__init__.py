# Stores directory for capit
