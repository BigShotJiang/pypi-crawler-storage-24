"""Internal package for build-time generated SCM version metadata."""
