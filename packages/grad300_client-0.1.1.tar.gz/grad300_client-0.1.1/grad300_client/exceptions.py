from __future__ import annotations

from typing import Any


class Grad300Error(Exception):
    """Base exception for grad300-client."""


class Grad300APIError(Grad300Error):
    """Raised when the backend API returns an HTTP error response."""

    def __init__(
        self,
        status_code: int,
        message: str,
        *,
        response_body: Any | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body


class AuthenticationError(Grad300APIError):
    """Raised when authentication fails or token is missing/invalid."""
