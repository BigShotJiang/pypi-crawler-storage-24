import datetime
import os
from pathlib import Path
from foundry.constants import ALPHA_FEEDBACK_FORM

# Store the session log in a user-level directory, never in the CWD.
# This prevents polluting project repositories with .session.log files.
# Honour SSCLI_LOG_DIR env var for test isolation.
def _get_log_file() -> Path:
    env_dir = os.getenv("SSCLI_LOG_DIR")
    if env_dir:
        log_dir = Path(env_dir)
    else:
        log_dir = Path.home() / ".sscli"
    try:
        log_dir.mkdir(parents=True, exist_ok=True, mode=0o700)
        log_dir.chmod(0o700)  # fix pre-existing dirs that may have loose perms
    except Exception:
        pass
    return log_dir / ".session.log"


LOG_FILE = _get_log_file()


_MAX_LOG_BYTES = 5 * 1024 * 1024  # 5 MB


def log_event(event_type: str, details: str = ""):
    """Log an event to the user-level session log (~/.sscli/.session.log).

    Never writes to the current working directory.
    """
    # M-1: strip carriage returns / newlines to prevent log-injection
    details = details.replace("\r", " ").replace("\n", "↩")

    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    log_entry = f"[{timestamp}] {event_type.upper()}: {details}\n"

    try:
        # M-2b: rotate (truncate) when the log exceeds the size cap
        if LOG_FILE.exists() and LOG_FILE.stat().st_size > _MAX_LOG_BYTES:
            LOG_FILE.write_text("", encoding="utf-8")  # truncate
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(log_entry)
    except Exception:
        # Fallback to silent failure to not break the CLI experience
        pass


def get_feedback_link() -> str:
    """Returns the feedback form link."""
    return ALPHA_FEEDBACK_FORM
