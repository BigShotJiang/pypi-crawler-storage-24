from pathlib import Path
import os

from rich.console import Console

# Base directory navigation
# In a pipx/PyPI install, code is isolated. We need to find the actual monorepo.
def _get_foundry_root() -> Path:
    # 1. Allow explicit override
    if os.getenv("FOUNDRY_ROOT"):
        return Path(os.getenv("FOUNDRY_ROOT"))
    
    # 2. Check if we are running from within the monorepo (CWD has .github, tooling, templates, etc)
    cwd = Path.cwd()
    if (cwd / ".github").exists() and (cwd / "tooling").exists():
        return cwd
    
    # 3. If one level deep (e.g. in tooling/ or templates/), go up one
    if (cwd.parent / ".github").exists() and (cwd.parent / "tooling").exists():
        return cwd.parent
    
    # 4. If two levels deep (e.g. in tooling/stack-cli/), go up two
    if (cwd.parent.parent / ".github").exists() and (cwd.parent.parent / "tooling").exists():
        return cwd.parent.parent

    # 5. Walk up from the source file location (supports editable pip install in monorepo)
    #    constants.py lives at: foundry-meta/tooling/stack-cli/foundry/constants.py
    #    → .parent.parent.parent.parent == foundry-meta/
    _code_root = Path(__file__).resolve().parent.parent.parent.parent
    if (_code_root / ".github").exists() and (_code_root / "tooling").exists():
        return _code_root
        
    # 6. Fallback to where the code is installed (Legacy behavior)
    return Path(__file__).resolve().parent.parent.parent

FOUNDRY_ROOT = _get_foundry_root()
TEMPLATES_DIR = FOUNDRY_ROOT / "templates"

# Production License Server (Hardcoded for security)
SEED_SOURCE_PRODUCTION_API = "https://auth.seedsource.dev/api"

# Development Override
# Only enabled if FOUNDRY_INTERNAL_DEV is explicitly set AND we are in a dev mono-repo
def _get_api_url() -> str:
    # Check for developer override via environment variable
    env_url = os.getenv("LICENSE_SERVER_URL")
    if env_url:
        from urllib.parse import urlparse
        _parsed = urlparse(env_url)
        _ALLOWED_API_HOSTS = {"auth.seedsource.dev", "api.seedsource.dev", "localhost"}
        if _parsed.scheme not in ("https", "http") or _parsed.hostname not in _ALLOWED_API_HOSTS:
            raise ValueError(
                f"LICENSE_SERVER_URL must be https://*.seedsource.dev or localhost. "
                f"Got: {env_url!r}"
            )
        return env_url

    # If running locally in the mono-repo, default to production unless specified
    return SEED_SOURCE_PRODUCTION_API

API_BASE_URL = _get_api_url()

# Domain configuration (defaults to seedsource.dev, override via environment variables)
import re as _re
_DOMAIN_RE = _re.compile(r'^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z]{2,})+$')
_raw_domain = os.getenv("SEED_SOURCE_DOMAIN", "seedsource.dev")
if not _DOMAIN_RE.fullmatch(_raw_domain):
    raise ValueError(f"Invalid SEED_SOURCE_DOMAIN: {_raw_domain!r}. Must be a valid hostname.")
SEED_SOURCE_DOMAIN = _raw_domain
SEED_SOURCE_AUTH_URL = os.getenv("SEED_SOURCE_AUTH_URL", f"https://auth.{SEED_SOURCE_DOMAIN}")
SEED_SOURCE_LANDING_URL = os.getenv("SEED_SOURCE_LANDING_URL", f"https://{SEED_SOURCE_DOMAIN}")
FORMS_BASE_URL = os.getenv("FORMS_BASE_URL", f"https://forms.{SEED_SOURCE_DOMAIN}")

# Marketing URLs (always configured)
PRICING_URL = os.getenv("PRICING_URL", f"https://{SEED_SOURCE_DOMAIN}/pricing")
SALES_EMAIL = os.getenv("SALES_EMAIL", f"sales@{SEED_SOURCE_DOMAIN}")
ALPHA_SUPPORT_EMAIL = os.getenv("ALPHA_SUPPORT_EMAIL", f"support@{SEED_SOURCE_DOMAIN}")
ALPHA_FEEDBACK_FORM = os.getenv("ALPHA_FEEDBACK_FORM", f"{FORMS_BASE_URL}/alpha")

# Metadata-based template registry for PyPI distribution
# This allows the CLI to know about templates without them being on disk
TEMPLATE_REGISTRY = {
    "python-saas": {
        "name": "Python SaaS Boilerplate",
        "description": "NiceGUI UI + Hexagonal Architecture (FastAPI/SQLAlchemy). Primary interface is a NiceGUI web app; FastAPI and uvicorn are bundled via NiceGUI, not a headless REST-only service.",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/python-saas.git",
    },
    "python-worker-service": {
        "name": "Python Worker Service",
        "description": "Headless FastAPI worker — multipart POST endpoints, async task processing, no UI layer. Ideal for audio/ML workloads (e.g. Demucs).",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/python-worker-service.git",
    },
    "rails-api": {
        "name": "Rails API Suite",
        "description": "JSON API with Devise, RSpec, and Docker",
        "tier": "free",
        "base": "rails-hexagonal-base",
        "repo": "https://github.com/seed-source/rails-api.git",
    },
    "rails-fullstack": {
        "name": "Rails Fullstack (Hotwire)",
        "description": "Hexagonal Rails 8 with Turbo, Stimulus, Tailwind, and session auth",
        "tier": "pro",
        "base": "rails-hexagonal-base",
        "repo": "https://github.com/seed-source/rails-fullstack.git",
    },
    "react-client": {
        "name": "React Vite Client",
        "description": "Modern frontend with Tailwind and React Query",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/react-client.git",
    },
    "rails-ui-kit": {
        "name": "Rails UI Kit",
        "description": "Full-stack Rails with ViewComponent and Tailwind",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/rails-ui-kit.git",
    },
    "data-pipeline": {
        "name": "Data Pipeline (dbt)",
        "description": "Modern data stack with dbt and Python",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/data-pipeline.git",
    },
    "mobile-android": {
        "name": "Mobile Android",
        "description": "Kotlin-based Android application",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/mobile-android-private.git",
    },
    "mobile-ios": {
        "name": "Mobile iOS",
        "description": "SwiftUI-based iOS application",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/mobile-ios-private.git",
    },
    "terraform-infra": {
        "name": "Terraform Infrastructure",
        "description": "Multi-cloud IaC modules",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/terraform-infra-private.git",
    },
    "wiring": {
        "name": "Docker Wiring",
        "description": "Orchestration for multi-service stacks",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/wiring-private.git",
    },
    "static-landing": {
        "name": "Astro Static Landing",
        "description": "Astro static site generator for marketing/landing pages",
        "tier": "alpha",
        "repo": "https://github.com/seed-source/static-landing.git",
    },
}

# If a local `static-landing` directory exists in the mono-repo and is a git
# repository (for example as a submodule), prefer that local path so the CLI
# can operate on the on-disk template during development.
# M-10: Only activate the file:// URI when FOUNDRY_INTERNAL_DEV is explicitly "1"
# to prevent env-var path injection in production installs.
try:
    _local_static = Path(TEMPLATES_DIR) / "static-landing"
    if (
        os.getenv("FOUNDRY_INTERNAL_DEV") == "1"
        and _local_static.exists()
        and (_local_static / ".git").exists()
    ):
        TEMPLATE_REGISTRY["static-landing"]["repo"] = f"file://{_local_static.resolve()}"
except Exception:
    # Non-fatal: if anything goes wrong, keep the registry as-is.
    pass

AVAILABLE_EXTENSIONS = {
    "commerce": {
        "name": "Commerce (Shopify/Stripe)",
        "tier": "pro",
        "description": "Injects Shopify/Commerce adapters and webhooks.",
    },
    "tunnel": {
        "name": "Local Tunneling (ngrok)",
        "tier": "pro",
        "description": "Configures the project for ngrok/local tunneling.",
    },
    "admin": {
        "name": "NiceGUI Admin",
        "tier": "pro",
        "description": "Standalone NiceGUI-based admin panel.",
    },
    "sqlite": {
        "name": "SQLite Local",
        "tier": "alpha",
        "description": "Local persistence with SQLAlchemy + Alembic.",
    },
    "ingestor": {
        "name": "Data Ingestor",
        "tier": "pro",
        "description": "Adapter pattern for raw data normalization.",
    },
    "payment": {
        "name": "Stripe Payment (Paid-Once Unlock)",
        "tier": "paid-once",
        "description": "Injects Stripe Checkout + webhook scaffold for subscription billing and one-time payments. Requires payment_feature_unlocked=true on your license.",
    },
}

# Feature registry with detailed descriptions and usage examples
FEATURES_REGISTRY = {
    "commerce": {
        "name": "Commerce Integration",
        "tier": "pro",
        "description": "Full Shopify/Stripe webhook integration with PII scrubbing, webhook deduplication, and secure payment processing.",
        "templates": ["python-saas", "react-client"],
        "example_base": "# Base template: API with basic CRUD operations\napp = FastAPI()\n\n@app.get(\"/items\")\nasync def get_items():\n    return await Item.all()",
        "example_with_feature": "# With Commerce: Shopify webhook handler + payment processor\nfrom foundry_commerce import init_commerce\n\ninit_commerce(app)\n\n@app.post(\"/webhooks/shopify/products.update\")\nasync def on_product_update(request: Request):\n    payload = await request.json()\n    await process_product_webhook(payload)"
    },
    "auth": {
        "name": "Authentication & Authorization",
        "tier": "pro",
        "description": "User authentication with JWT, role-based access control (RBAC), session management, and OAuth2 integration.",
        "templates": ["python-saas", "react-client", "rails-api"],
        "example_base": "# Base template: Open endpoints\napp = FastAPI()\n\n@app.get(\"/public/data\")\nasync def get_public_data():\n    return {\"status\": \"ok\"}",
        "example_with_feature": "# With Auth: Protected endpoints with user context\nfrom foundry_auth import AuthManager, require_auth\n\nauth = AuthManager(app)\n\n@app.get(\"/api/profile\")\n@require_auth()\nasync def get_profile(user: User = Depends(get_current_user)):\n    return {\"user_id\": user.id, \"email\": user.email}"
    },
    "admin": {
        "name": "Admin Dashboard",
        "tier": "pro",
        "description": "Interactive NiceGUI-based admin panel for managing users, content, and system configuration.",
        "templates": ["python-saas"],
        "example_base": "# Base template: CLI or basic management\nif __name__ == \"__main__\":\n    app = FastAPI()\n    uvicorn.run(app, host=\"0.0.0.0\")",
        "example_with_feature": "# With Admin: Interactive dashboard\nfrom nicegui_admin import AdminPanel\n\nui = ni.ui()\nadmin = AdminPanel(ui)\n\n@admin.register_resource(\"users\")\nclass UserAdmin:\n    async def list_users(self):\n        return await User.all()\n    \n    async def create_user(self, data):\n        return await User.create(**data)"
    },
    "tunnel": {
        "name": "Local Tunneling",
        "tier": "pro",
        "description": "ngrok integration for exposing local development server to the internet (useful for webhook testing).",
        "templates": ["python-saas", "react-client", "rails-api"],
        "example_base": "# Base template: Local development only\nuvicorn.run(app, host=\"127.0.0.1\", port=8000)",
        "example_with_feature": "# With Tunnel: Publicly accessible during development\nfrom foundry_tunnel import setup_tunnel\n\nconfig = setup_tunnel(app, subdomain=\"my-dev-project\")\nprint(f\"Public URL: {config.public_url}\")\nuvicorn.run(app, host=\"0.0.0.0\", port=8000)"
    },
    "payment": {
        "name": "Stripe Payment Integration",
        "tier": "paid-once",
        "description": "Stripe Checkout + webhook scaffold. Injects payment gateway port, Stripe adapter, and secure webhook handler. Requires $49 one-time unlock (valid for all templates, all time).",
        "templates": ["python-saas", "react-client", "rails-api", "rails-fullstack"],
        "example_base": "# Base template: No payment processing\n@app.get(\"/plans\")\nasync def get_plans():\n    return [{\"name\": \"Pro\", \"price\": 39}]",
        "example_with_feature": "# With Payment: Stripe Checkout session\nfrom src.infrastructure.payment.stripe_payment_adapter import StripePaymentAdapter\n\n@app.post(\"/payments/checkout\")\nasync def create_checkout(plan_id: str):\n    adapter = StripePaymentAdapter()\n    session = await adapter.create_checkout_session(plan_id)\n    return {\"checkout_url\": session.url}"
    },
}

TIER_HIERARCHY = {"free": 0, "alpha": 1, "pro": 2, "enterprise": 3, "admin": 10}

console = Console()


# Menu configuration
ANIMATED_MENU_ITEMS = [
    "Explore Templates",
    "Generate Project",
    "Manage Config",
    "System Validation",
    "View Docs",
    "Exit",
]

# Apply questionary patching for description styling
from foundry.patch import apply_description_patch
apply_description_patch()

# Shared Questionary styling - consistent across all menus
QUESTIONARY_STYLE = [
    ("qmark", "fg:#673ab7 bold"),       # purple
    ("question", "bold"),               # bold question
    ("answer", "fg:#f44336 bold"),     # red answer
    ("pointer", "fg:#673ab7 bold"),    # purple pointer
    ("highlighted", "fg:#673ab7 bold"),# purple highlighted item (selected)
    ("selected", "fg:#cc5454"),        # selected item
    ("text", "fg:#ffffff"),            # white for unselected items
    ("description", "fg:#888888"),     # gray for descriptions (via patch)
    ("instruction", "fg:#888888 italic"),# gray italic for hints
    ("purple", "fg:#673ab7"),          # purple for categories
    ("yellow", "fg:#f4bf75"),          # yellow for others
    ("cyan", "fg:#66d9ef"),            # cyan for template names
    ("red", "fg:#f92672"),             # red for locked
    ("magenta", "fg:#ae81ff"),         # magenta for pro
    ("green", "fg:#a6e22e"),           # green for free/alpha
]

