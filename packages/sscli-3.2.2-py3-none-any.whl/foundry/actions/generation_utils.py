from pathlib import Path
import json
import re
import subprocess
import sys
import shutil
from rich.panel import Panel
from foundry.constants import console, TIER_HIERARCHY, PRICING_URL
from foundry.telemetry import log_event
from foundry.auth import get_current_license_info
from foundry.codemods.toml_codemods import RemoveToolSectionsCM, RemovePythonDependencyCM


def check_feature_tier_access(feature_key: str) -> bool:
    """Check if the user has the required tier to use a specific injectable feature.

    Shows a clear upgrade prompt if the feature requires a higher tier.
    Returns True if access is granted, False otherwise.
    """
    from foundry.utils import is_internal_dev
    from foundry.constants import FEATURES_REGISTRY, PRICING_URL
    if is_internal_dev():
        return True

    feature_meta = FEATURES_REGISTRY.get(feature_key)
    if not feature_meta:
        # Unknown feature — allow (will fail at injection time)
        return True

    required_tier = feature_meta.get("tier", "free")
    user_info = get_current_license_info(verify=True)
    user_tier = user_info.get("tier", "free")

    if TIER_HIERARCHY.get(user_tier, 0) < TIER_HIERARCHY.get(required_tier.lower(), 0):
        feature_name = feature_meta.get("name", feature_key)
        console.print(
            Panel(
                f"[bold red]Feature Locked[/bold red]\n\n"
                f"The [cyan]--with-{feature_key}[/cyan] flag ([bold]{feature_name}[/bold]) requires a "
                f"[bold yellow]{required_tier.upper()}[/bold yellow] license.\n"
                f"Your current tier is: [bold white]{user_tier.upper()}[/bold white].\n\n"
                f"[dim]ALPHA tier can access templates but not injectable PRO features "
                f"(auth, commerce, admin, tunnel).[/dim]\n\n"
                f"Upgrade at: [link={PRICING_URL}]{PRICING_URL}[/link]",
                title="PRO Feature Required",
                border_style="yellow",
            )
        )
        log_event("FEATURE_FORBIDDEN", f"Feature: {feature_key}, User Tier: {user_tier}")
        return False
    return True


def check_tier_access(template_name: str, required_tier: str) -> bool:
    """Check if the user has the required tier for a template.
    
    For ALPHA users, also checks per-template access grants.
    """
    from foundry.utils import is_internal_dev
    if is_internal_dev():
        return True

    # verify=True: live check against license server so tier upgrades take effect
    # immediately without requiring logout/login. Falls back to cache if server unreachable.
    user_info = get_current_license_info(verify=True)
    user_tier = user_info.get("tier", "free")
    user_id = user_info.get("user_id")

    # Check tier hierarchy first
    if TIER_HIERARCHY.get(user_tier, 0) < TIER_HIERARCHY.get(required_tier.lower(), 0):
        console.print(
            Panel(
                f"[bold red]Access Denied[/bold red]\n\n"
                f"The template [cyan]{template_name}[/cyan] requires a [bold yellow]{required_tier.upper()}[/bold yellow] license.\n"
                f"Your current tier is: [bold white]{user_tier.upper()}[/bold white].\n\n"
                f"Upgrade your license at: [link={PRICING_URL}]{PRICING_URL}[/link]",
                title="License Requirement",
                border_style="red",
            )
        )
        log_event(
            "GENERATE_FORBIDDEN", f"Template: {template_name}, User Tier: {user_tier}"
        )
        return False
    return True


def check_payment_entitlement() -> bool:
    """Check if the user has the payment feature unlocked (paid-once $49 unlock).
    
    This is separate from tier checks — free users CAN have this unlocked.
    """
    from foundry.utils import is_internal_dev
    from foundry.constants import PRICING_URL
    if is_internal_dev():
        return True

    user_info = get_current_license_info(verify=True)
    unlocked = user_info.get("payment_feature_unlocked", False)

    if not unlocked:
        unlock_url = f"{PRICING_URL}#payment-unlock"
        console.print(
            Panel(
                "[bold red]Payment Feature Not Unlocked[/bold red]\n\n"
                "The [cyan]--with-payment[/cyan] flag requires a [bold yellow]$49 one-time unlock[/bold yellow].\n"
                "This is a separate purchase from your subscription — unlock once, inject anytime.\n\n"
                f"Unlock at: [link={unlock_url}]{unlock_url}[/link]",
                title="Payment Feature Gate",
                border_style="red",
            )
        )
        log_event("PAYMENT_FEATURE_FORBIDDEN", "payment_feature_unlocked=false")
        return False
    return True


def apply_landing_blueprint(path: Path, content_path: str = None, theme: str = None):
    """Apply blueprint configuration to static-landing template."""
    blueprint_file = path / "blueprint.json"
    if not blueprint_file.exists():
        return

    try:
        blueprint_data = json.loads(blueprint_file.read_text(encoding="utf-8"))
        
        # Override with custom content if provided
        if content_path:
            custom_content_file = Path(content_path).resolve()
            project_resolved = Path(path).resolve()
            # Only allow files within the project directory
            if not str(custom_content_file).startswith(str(project_resolved)):
                raise ValueError(
                    f"content_path must be within the project directory. Got: {content_path!r}"
                )
            if custom_content_file.is_symlink():
                raise ValueError("content_path must not be a symlink")
            if custom_content_file.exists():
                custom_data = json.loads(custom_content_file.read_text(encoding="utf-8"))
                blueprint_data.update(custom_data)
                console.print(f"   - Applied custom content blueprint from {content_path}")
            else:
                console.print(f"   [yellow]⚠️  Custom content file {content_path} not found.[/yellow]")

        # Override theme if provided
        if theme:
            blueprint_data["theme"] = theme
            console.print(f"   - Applied theme: {theme}")

        blueprint_file.write_text(json.dumps(blueprint_data, indent=2), encoding="utf-8")
        
    except Exception as e:
        console.print(f"   [yellow]⚠️  Failed to apply landing blueprint: {e}[/yellow]")


_APP_NAME_RE = re.compile(r'^[a-zA-Z0-9][a-zA-Z0-9_\-]{0,63}$')


def inject_metadata(path: Path, template: str, app_name: str):
    """
    Inject project name into configuration files.
    
    This is the first step of project initialization, renaming template placeholders.
    """
    if not _APP_NAME_RE.match(app_name):
        raise ValueError(
            f"Invalid app_name {app_name!r}: must match ^[a-zA-Z0-9][a-zA-Z0-9_\\-]{{0,63}}$"
        )
    console.print(f"   - Injecting name '{app_name}' into configuration...")
    files_to_touch = [
        path / "package.json",
        path / "pyproject.toml",
        path / "Gemfile",
        path / "README.md",
        path / ".env.example",
        path / "astro.config.mjs",
    ]
    for f in files_to_touch:
        if f.exists():
            try:
                content = f.read_text(encoding="utf-8")
                new_content = content.replace(f"{template}", app_name)
                # Capitalized version for internal class names or readmes
                new_content = new_content.replace("StackApp", app_name.capitalize())
                f.write_text(new_content, encoding="utf-8")
            except Exception as e:
                console.print(f"   [yellow]⚠️  Failed to inject metadata into {f.name}: {e}[/yellow]")


def disable_linters(path: Path):
    """Remove linter tools and dependencies from the project."""
    pyproject = path / "pyproject.toml"
    if pyproject.exists():
        console.print("   - Removing Ruff/MyPy configurations...")
        try:
            # Use toml-based codemod for clean removal (formatting-aware)
            codemod = RemoveToolSectionsCM(sections=["ruff", "mypy"])
            codemod.apply(pyproject)
            
            # Also remove dependencies
            dep_codemod = RemovePythonDependencyCM(dependencies=["ruff", "mypy"])
            dep_codemod.execute(pyproject)
        except Exception as e:
            console.print(f"   [yellow]⚠️  Failed to disable linters in pyproject.toml: {e}[/yellow]")

    gemfile = path / "Gemfile"
    if gemfile.exists():
        try:
            content = gemfile.read_text(encoding="utf-8")
            new_content = content.replace("gem 'rubocop'", "# gem 'rubocop'").replace("gem 'rubocop-rails'", "# gem 'rubocop-rails'")
            gemfile.write_text(new_content, encoding="utf-8")
            console.print("   - Commented out Rubocop in Gemfile")
        except Exception as e:
            console.print(f"   [yellow]⚠️  Failed to disable linters in Gemfile: {e}[/yellow]")


def regenerate_poetry_lock(path: Path):
    """Regenerate poetry.lock to reflect any manual file changes (like dependency removal)."""
    if not (path / "pyproject.toml").exists() or not (path / "poetry.lock").exists():
        return
        
    console.print("   - Regenerating poetry.lock...")
    try:
        # Check if poetry is available
        subprocess.run(["poetry", "--version"], capture_output=True, check=True)
        
        result = subprocess.run(
            ["poetry", "lock", "--no-update"], 
            cwd=str(path), 
            capture_output=True, 
            text=True, 
            timeout=120
        )
        if result.returncode == 0:
            console.print("   - poetry.lock regenerated successfully")
        else:
            console.print(f"   [yellow]⚠️  Poetry lock failed: {result.stderr.strip()}[/yellow]")
    except (subprocess.CalledProcessError, FileNotFoundError):
        console.print("   [yellow]⚠️  Poetry not found, skipping lock regeneration.[/yellow]")
    except Exception as e:
        console.print(f"   [yellow]⚠️  Unexpected error regenerating poetry.lock: {str(e)}[/yellow]")


def validate_and_fix_pyproject(path: Path):
    """Validate pyproject.toml and fix common formatting issues manually."""
    pyproject = path / "pyproject.toml"
    if not pyproject.exists():
        return
        
    try:
        # Fallback to simple correction if tomlkit fails or for non-standard repairs
        content = pyproject.read_text(encoding="utf-8")
        fixed_lines = []
        in_tool_poetry = False
        in_dependencies_section = False
        has_version = False
        
        for line in content.splitlines():
            stripped = line.strip()
            
            # Detect sections
            if stripped.startswith("[tool.poetry]"):
                in_tool_poetry = True
                in_dependencies_section = False
            elif stripped.startswith("[tool.poetry.dependencies]"):
                in_tool_poetry = False
                in_dependencies_section = True
            elif stripped.startswith("["):
                in_tool_poetry = False
                in_dependencies_section = False

            # Check for version in [tool.poetry]
            if in_tool_poetry and stripped.startswith("version ="):
                has_version = True
                if "=" in stripped:
                    key, val = stripped.split("=", 1)
                    val_clean = val.strip().strip('"').strip("'")
                    if not val_clean:
                        line = 'version = "0.1.0"'
            
            if in_dependencies_section and " = " in line and not stripped.startswith("#"):
                key, value = line.split(" = ", 1)
                key, value = key.strip(), value.strip()
                if value and not value.startswith(('"', "'", "{", "[")):
                    if value[0].isnumeric() or value[0] in "^~<>=!":
                        value = f'"{value}"'
                        line = f"{key} = {value}"
            fixed_lines.append(line)
        
        # Ensure version exists in [tool.poetry] if it was missing entirely
        if in_tool_poetry and not has_version:
            for idx, line in enumerate(fixed_lines):
                if line.strip() == "[tool.poetry]":
                    fixed_lines.insert(idx + 1, 'version = "0.1.0"')
                    break

        fixed_content = "\n".join(fixed_lines) + "\n"
        pyproject.write_text(fixed_content, encoding="utf-8")
        console.print("   - Validated pyproject.toml structure & versioning")
    except Exception as e:
        console.print(f"   [yellow]⚠️  Could not validate pyproject.toml: {e}[/yellow]")


SIDEKIQ_YML = """\
:concurrency: 5
:queues:
  - [critical, 3]
  - [default, 2]
  - [low, 1]
:max_retries: 3
"""

PROCFILE_DEV = """\
web: bundle exec rails server -p 3000
worker: bundle exec sidekiq -c 5
"""


def inject_sidekiq(project_path: Path) -> None:
    """Swap solid_queue for Sidekiq in a Rails project generated from rails-api/rails-fullstack.

    Changes applied:
      - Replaces ``gem 'solid_queue'`` with ``gem 'sidekiq'`` in Gemfile
      - Creates ``config/sidekiq.yml`` with sensible defaults
      - Creates ``Procfile.dev`` for local dev (web + worker)
    """
    gemfile = project_path / "Gemfile"
    if not gemfile.exists():
        # Try one level deeper (template archives put code in a subdirectory)
        candidates = list(project_path.glob("*/Gemfile"))
        if candidates:
            gemfile = candidates[0]
            project_path = gemfile.parent

    if gemfile.exists():
        content = gemfile.read_text(encoding="utf-8")
        if "solid_queue" in content:
            content = content.replace("gem 'solid_queue'", "gem 'sidekiq'")
            gemfile.write_text(content, encoding="utf-8")
            console.print("   - [green]✓[/green] Swapped solid_queue → sidekiq in Gemfile")
        elif "sidekiq" not in content:
            # Append sidekiq if neither gem is present
            with open(gemfile, "a", encoding="utf-8") as f:
                f.write("\ngem 'sidekiq'\n")
            console.print("   - [green]✓[/green] Added sidekiq to Gemfile")
        else:
            console.print("   - [dim]sidekiq already present in Gemfile, no change needed[/dim]")

    # Write config/sidekiq.yml
    config_dir = project_path / "config"
    config_dir.mkdir(parents=True, exist_ok=True)
    sidekiq_yml = config_dir / "sidekiq.yml"
    sidekiq_yml.write_text(SIDEKIQ_YML, encoding="utf-8")
    console.print("   - [green]✓[/green] Created config/sidekiq.yml")

    # Write Procfile.dev
    procfile = project_path / "Procfile.dev"
    if not procfile.exists():
        procfile.write_text(PROCFILE_DEV, encoding="utf-8")
        console.print("   - [green]✓[/green] Created Procfile.dev")

    log_event("INJECT_SIDEKIQ", str(project_path))
