import shutil
import json as json_module
from pathlib import Path

import questionary
from foundry.constants import console
from foundry.telemetry import get_feedback_link, log_event
from foundry.utils import get_template_info
from foundry.actions.generation_utils import (
    inject_metadata,
    disable_linters,
    validate_and_fix_pyproject,
    check_tier_access,
    check_feature_tier_access,
    regenerate_poetry_lock,
    apply_landing_blueprint,
    inject_sidekiq,
)
from foundry.metadata.metadata_tracker import MetadataTracker
from foundry.actions.features import setup_secrets, inject_features
from .interactive_config import get_interactive_config
from .repo_utils import download_template, initialize_github_repo


def run_generator(
    template_name: str = None,
    app_name: str = None,
    target_dir_name: str = None,
    use_linters: bool = True,
    with_commerce: bool = False,
    with_payment: bool = False,
    with_tunnel: bool = False,
    with_landing: bool = False,
    with_admin: bool = False,
    with_sqlite: bool = False,
    with_ingestor: bool = False,
    with_auth: bool = False,
    with_merchant_dashboard: bool = False,
    with_sidekiq: bool = False,
    interactive: bool = False,
    use_ast_injection: bool = False,
    secrets_strategy: str = "Dotenv (Standard .env files)",
    github_config: dict = None,
    content_path: str = None,
    theme: str = None,
    dry_run: bool = False,
    json_output: bool = False,
    stats_only: bool = False,
    output_file: str = None,
):

    if interactive:
        config = get_interactive_config(template_name)
        if not config: return
        
        template_name = config["template_name"]
        app_name = config["app_name"]
        with_commerce = config["with_commerce"]
        with_tunnel = config["with_tunnel"]
        with_landing = config["with_landing"]
        with_admin = config.get("with_admin", False)
        with_sqlite = config.get("with_sqlite", False)
        with_ingestor = config.get("with_ingestor", False)
        with_auth = config.get("with_auth", False)
        with_merchant_dashboard = config.get("with_merchant_dashboard", False)
        use_linters = config["use_linters"]
        use_ast_injection = config.get("use_ast_injection", False)
        secrets_strategy = config["secrets_strategy"]
        github_config = config.get("github_config")
    else:
        secrets_strategy = secrets_strategy or "Dotenv (Standard .env files)"

    # Tier Enforcement Check
    template_info = get_template_info(template_name)
    if not check_tier_access(template_name, template_info.get("tier", "free")):
        return

    # Feature Tier Enforcement — check PRO features before doing any work
    pro_features_requested = {
        "auth": with_auth,
        "commerce": with_commerce,
        "admin": with_admin,
        "tunnel": with_tunnel,
    }
    for feature_key, requested in pro_features_requested.items():
        if requested and not check_feature_tier_access(feature_key):
            return

    # Determine destination path
    if interactive:
        target_path_input = questionary.text(
            "Where would you like to install the repository?", default=str(Path.cwd())
        ).ask()
        if not target_path_input:
            console.print("[red]Error: Installation path required.[/red]")
            return
        target_path = Path(target_path_input)
    else:
        if not target_dir_name and not app_name:
            target_path = Path.cwd()
        else:
            target_path = Path(target_dir_name) if target_dir_name else (Path.cwd() / app_name)

    if not template_name:
        console.print("[red]Error: Template name required.[/red]")
        return

    # Dry-run mode: show what would be generated
    if dry_run:
        # Build the configuration summary dict (used for both display and JSON output)
        features_applied = []
        if with_commerce:
            features_applied.append("commerce")
        if with_payment:
            features_applied.append("payment")
        if with_tunnel:
            features_applied.append("tunnel")
        if with_landing:
            features_applied.append("landing")
        if with_admin:
            features_applied.append("admin")
        if with_sqlite:
            features_applied.append("sqlite")
        if with_ingestor:
            features_applied.append("ingestor")
        if with_auth:
            features_applied.append("auth")
        if with_merchant_dashboard:
            features_applied.append("merchant-dashboard")

        # Collect file tree statistics from the local template if available
        template_info_for_scan = get_template_info(template_name)
        local_template_path = None
        try:
            from foundry.constants import TEMPLATES_DIR
            candidate = TEMPLATES_DIR / template_name
            if candidate.exists():
                local_template_path = candidate
        except Exception:
            pass

        file_stats = {"total_files": 0, "by_extension": {}, "test_files": 0, "dirs": 0}
        file_tree: list = []
        if local_template_path:
            for fp in sorted(local_template_path.rglob("*")):
                if fp.is_dir():
                    file_stats["dirs"] += 1
                    continue
                rel = str(fp.relative_to(local_template_path))
                file_tree.append(rel)
                file_stats["total_files"] += 1
                ext = fp.suffix.lower() or "(no ext)"
                file_stats["by_extension"][ext] = file_stats["by_extension"].get(ext, 0) + 1
                if "test" in rel.lower() or "spec" in rel.lower():
                    file_stats["test_files"] += 1

        # Assemble the dry-run result object
        dry_run_result = {
            "dry_run": True,
            "template": template_name,
            "app_name": app_name,
            "target_path": str(target_path),
            "features": features_applied,
            "linters": use_linters,
            "secrets_strategy": secrets_strategy,
            "stats": file_stats,
            "file_tree": file_tree,
        }

        if stats_only:
            # Show only statistics summary
            console.print(f"[bold yellow]📊 DRY-RUN STATS:[/bold yellow] {template_name}")
            console.print(f"  Total files : [cyan]{file_stats['total_files']}[/cyan]")
            console.print(f"  Directories : [cyan]{file_stats['dirs']}[/cyan]")
            console.print(f"  Test files  : [cyan]{file_stats['test_files']}[/cyan]")
            if file_stats["by_extension"]:
                console.print("  By extension:")
                for ext, count in sorted(file_stats["by_extension"].items(), key=lambda x: -x[1]):
                    console.print(f"    [dim]{ext}[/dim]: {count}")
        elif json_output:
            import sys
            output_str = json_module.dumps(dry_run_result, indent=2)
            if output_file:
                out_path = Path(output_file)
                out_path.parent.mkdir(parents=True, exist_ok=True)
                out_path.write_text(output_str, encoding="utf-8")
                console.print(f"[green]✓[/green] Dry-run JSON written to [cyan]{output_file}[/cyan]")
            else:
                # Print JSON to stdout (no Rich formatting so it's parseable by scripts)
                sys.stdout.write(output_str + "\n")
        else:
            # Human-readable preview (default)
            console.print(f"[yellow]🔍 DRY-RUN:[/yellow] Previewing {template_name} generation...")
            console.print(f"[cyan]Template:[/cyan] {template_name}")
            console.print(f"[cyan]App Name:[/cyan] {app_name}")
            console.print(f"[cyan]Target Path:[/cyan] {target_path}")

            # Show configuration summary
            config_items = []
            if with_commerce:
                config_items.append("✓ Commerce (Shopify/Stripe)")
            if with_payment:
                config_items.append("✓ Payment (Stripe Checkout — Paid-Once Unlock)")
            if with_tunnel:
                config_items.append("✓ Tunneling (ngrok)")
            if with_landing:
                config_items.append("✓ Landing Page (Astro)")
            if with_admin:
                config_items.append("✓ Admin Panel (NiceGUI)")
            if with_sqlite:
                config_items.append("✓ SQLite + Alembic")
            if with_ingestor:
                config_items.append("✓ Data Ingestor")
            if with_auth:
                config_items.append("✓ Authentication")
            if with_merchant_dashboard:
                config_items.append("✓ Merchant Dashboard")
            if use_linters:
                config_items.append("✓ Linters Enabled")

            if config_items:
                console.print("[cyan]Configuration:[/cyan]")
                for item in config_items:
                    console.print(f"  {item}")

            console.print(f"[cyan]Secrets Strategy:[/cyan] {secrets_strategy}")

            if file_stats["total_files"] > 0:
                console.print(f"[cyan]Files would be created:[/cyan] {file_stats['total_files']} files in {file_stats['dirs']} directories")

            # Write output file if requested
            if output_file:
                out_path = Path(output_file)
                out_path.parent.mkdir(parents=True, exist_ok=True)
                out_path.write_text(
                    json_module.dumps(dry_run_result, indent=2), encoding="utf-8"
                )
                console.print(f"[green]✓[/green] Preview written to [cyan]{output_file}[/cyan]")

            console.print("\n[green]✓[/green] Dry-run preview complete (no changes applied)")

        log_event("GENERATE_DRY_RUN", f"Template: {template_name}, App: {app_name}")
        return

    log_event("GENERATE_START", f"Template: {template_name}, App: {app_name}")
    console.print(f"\n[bold green]Deploying {template_name} to {target_path.name}...[/bold green]")

    try:
        if target_path.exists() and any(target_path.iterdir()):
            console.print(f"[red]Error: {target_path.name} already exists and is not empty![/red]")
            return

        if not download_template(template_name, template_info, target_path):
            return

        # Post-download processing
        inject_metadata(target_path, template_name, app_name or target_path.name)
        validate_and_fix_pyproject(target_path)

        if not use_linters:
            disable_linters(target_path)

        if template_name == "static-landing":
            apply_landing_blueprint(target_path, content_path, theme)

        setup_secrets(target_path, secrets_strategy)
        inject_features(
            target_path, 
            template_name, 
            with_commerce, 
            with_tunnel, 
            with_landing,
            with_admin,
            with_sqlite,
            with_ingestor,
            with_auth,
            with_merchant_dashboard,
            payment=with_payment,
            use_ast_injection=use_ast_injection
        )

        # Optional Sidekiq swap (rails-api only)
        if with_sidekiq and template_name in ("rails-api", "rails-fullstack"):
            inject_sidekiq(target_path)

        regenerate_poetry_lock(target_path)

        # Write project metadata to track generation state and injected features
        # Phase 3 Metadata tracking
        features_injected = []
        if with_commerce: features_injected.append("commerce")
        if with_payment: features_injected.append("payment")
        if with_tunnel: features_injected.append("tunnel")
        if with_landing: features_injected.append("landing")
        if with_admin: features_injected.append("nicegui-admin")
        if with_sqlite: features_injected.append("sqlite-local")
        if with_ingestor: features_injected.append("data-ingestor")
        if with_auth: features_injected.append("auth")
        if with_merchant_dashboard: features_injected.append("merchant-dashboard")
        
        tracker = MetadataTracker(project_path=target_path)
        tracker.init_project(
            template_name=template_name,
            version="1.0.0",  # Default for new installs
            features=features_injected,
            project_name=app_name or target_path.name
        )

        # Cleanup
        if template_name != "python-saas":
            features_dir = target_path / "features"
            if features_dir.exists():
                shutil.rmtree(features_dir)

        # GitHub Repo Initialization
        if github_config:
            initialize_github_repo(target_path, github_config)

        console.print(f"[bold green]Success! Project created at {target_path}[/bold green]")
        console.print(f"\n[bold blue]Feedback Wanted![/bold blue] [link={get_feedback_link()}]{get_feedback_link()}[/link]")
        log_event("GENERATE_SUCCESS", f"Template: {template_name}, Target: {target_path}")

    except Exception as e:
        console.print(f"[bold red]Deployment failed:[/bold red] {e}")
        log_event("GENERATE_ERROR", str(e))

