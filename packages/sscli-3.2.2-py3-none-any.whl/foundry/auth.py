import os
import json
import urllib.parse
from pathlib import Path
from typing import Any, Dict, Optional

import requests
from foundry.constants import console, API_BASE_URL

# Allowed hostnames for outbound authenticated requests (C-5)
_ALLOWED_HOSTS = {"seedsource.dev", "localhost"}

# Allowed hostnames for browser-opened verification URIs (H-3)
# Includes github.com because GitHub device flow sends verification_uri there
_ALLOWED_VERIFICATION_HOSTS = {"github.com", "auth.seedsource.dev", "localhost"}


def _validate_request_url(url: str) -> None:
    """Validate that a URL is safe to send Bearer tokens to.

    Enforces HTTPS (except localhost) and hostname allowlist.
    Raises ValueError if the URL does not meet security requirements.
    """
    parsed = urllib.parse.urlparse(url)
    hostname = parsed.hostname or ""
    is_allowed = hostname == "localhost" or hostname.endswith(".seedsource.dev") or hostname == "seedsource.dev"
    if not is_allowed:
        raise ValueError(f"Request URL hostname not in allowed list: {hostname!r}")
    if parsed.scheme == "http" and hostname != "localhost":
        raise ValueError(f"HTTP only allowed for localhost; got scheme {parsed.scheme!r} for {hostname!r}")
    if parsed.scheme not in ("https", "http"):
        raise ValueError(f"Insecure URL scheme: {parsed.scheme!r}")

# Configuration
# The base URL is managed in foundry/constants.py (configurable via environment variables)
LICENSE_SERVER = API_BASE_URL
CREDENTIALS_FILE = Path.home() / ".config" / "sscli" / "credentials.json"


def save_credentials(data: Dict[str, Any]) -> None:
    """Cache authentication data locally.
    
    Stores access token, tier, and org info for CLI operations.
    Token is stored securely with owner-only file permissions (0600).
    """
    # Create directory with restrictive permissions (owner only)
    CREDENTIALS_FILE.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    
    # Store all authentication data
    cached_data = {
        "access_token": data.get("access_token"),
        "tier": data.get("tier", "free"),
        "org_name": data.get("org_name"),
        "email": data.get("email"),
        "status": data.get("status", "active"),
        "authorized": True,  # If we're caching, user just authenticated successfully
    }
    
    # Write to temp file first for atomic operation
    temp_file = CREDENTIALS_FILE.with_suffix('.tmp')
    with open(temp_file, "w") as f:
        json.dump(cached_data, f, indent=2)
    
    # Set restrictive file permissions (owner read/write only)
    os.chmod(temp_file, 0o600)
    
    # Atomic rename to prevent partial/corrupted files, then enforce permissions (M-7)
    temp_file.replace(CREDENTIALS_FILE)
    CREDENTIALS_FILE.chmod(0o600)


def login_flow() -> bool:
    """Authenticate via GitHub Device Flow.
    
    Uses GitHub's device flow to authenticate the user and register with License Server.
    User visits GitHub URL, enters code, and CLI polls for completion.
    
    Returns:
        True if authentication succeeded, False otherwise.
    """
    import time
    import webbrowser
    
    console.print("\n[bold blue]Seed & Source Authentication[/bold blue]")
    console.print("Authenticating with GitHub...\n")
    
    try:
        # Step 1: Request device code from license server
        _device_code_url = f"{LICENSE_SERVER}/v1/auth/device/code"
        _validate_request_url(_device_code_url)  # C-5
        response = requests.post(
            _device_code_url,
            timeout=10,
            verify=True,           # H-1
            allow_redirects=False, # H-2
        )
        if response.status_code != 200:
            console.print(f"[red]Failed to initiate authentication:[/] {response.text}")
            return False
        
        device_data = response.json()
        device_code = device_data["device_code"]
        user_code = device_data["user_code"]
        verification_uri = device_data["verification_uri"]
        interval = device_data.get("interval", 5)
        
        # Step 2: Display user code and open browser
        console.print(f"[bold yellow]Your authentication code: {user_code}[/bold yellow]")
        console.print(f"\nOpening browser to: {verification_uri}")
        console.print(f"If browser doesn't open, visit: {verification_uri}")
        console.print("\nWaiting for authentication...")
        
        try:
            # H-3: validate URI before opening browser — uses _ALLOWED_VERIFICATION_HOSTS
            # (broader than _ALLOWED_HOSTS since GitHub device flow is the OAuth provider)
            _parsed_vuri = urllib.parse.urlparse(verification_uri)
            _vuri_host = _parsed_vuri.hostname or ""
            _vuri_ok = (
                verification_uri.startswith("https://")
                and (_vuri_host in _ALLOWED_VERIFICATION_HOSTS
                     or _vuri_host.endswith(".seedsource.dev"))
            )
            if not _vuri_ok:
                raise ValueError(f"Unsafe verification URI: {verification_uri!r}")
            webbrowser.open(verification_uri)
        except ValueError as _ve:
            console.print(f"[red]Unsafe verification URI blocked:[/red] {_ve}")
        except Exception:
            pass  # Browser opening is best-effort
        
        # Step 3: Poll for authorization
        max_attempts = 60  # 5 minutes max (60 * 5 seconds)
        for attempt in range(max_attempts):
            time.sleep(interval)
            
            try:
                # RFC 8628 §3.4: POST with device_code in the body, never in URL
                # (GET ?device_code=... leaks the secret into server/proxy access logs)
                _poll_url = f"{LICENSE_SERVER}/v1/auth/device/token"
                _validate_request_url(_poll_url)  # C-5
                poll_response = requests.post(
                    _poll_url,
                    data={
                        "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                        "device_code": device_code,
                    },
                    timeout=10,
                    verify=True,           # H-1
                    allow_redirects=False, # H-2
                )
                
                if poll_response.status_code == 200:
                    # Success! User authorized
                    auth_data = poll_response.json()
                    
                    # Save credentials (access_token, tier, org_name)
                    save_credentials({
                        "access_token": auth_data.get("access_token"),
                        "tier": auth_data.get("tier", "free"),
                        "org_name": auth_data.get("org_name"),
                        "email": auth_data.get("email"),
                        "status": "active",
                        "authorized": True
                    })
                    
                    email = auth_data.get('email', 'User')
                    tier_str = auth_data.get('tier', 'free').upper()
                    org_name = auth_data.get('org_name')
                    
                    console.print(f"\n✓ Successfully authenticated as {email}")
                    if org_name:
                        console.print(f"License Tier: {tier_str} (via {org_name})")
                    else:
                        console.print(f"License Tier: {tier_str}")
                    return True
                
                elif poll_response.status_code == 428:
                    # Still waiting for authorization (HTTP 428 = Precondition Required)
                    if attempt % 6 == 0:  # Show progress every 30 seconds
                        console.print(".", end="")
                    continue
                
                elif poll_response.status_code == 404:
                    # Device code invalid or expired
                    console.print(f"\n[red]Device code invalid or expired.[/red]")
                    return False
                
                elif poll_response.status_code in (401, 403):  # H-4
                    raise SystemExit("Authentication failed: server rejected credentials.")
                else:
                    # Unexpected error — sanitize before printing (H-5)
                    _safe = poll_response.text[:200].replace("\n", " ").replace("\r", " ")
                    console.print(f"\n[red]Authorization check failed:[/] {_safe}")
                    return False
                    
            except requests.RequestException as e:
                if attempt < max_attempts - 1:
                    continue  # Retry on network errors
                else:
                    console.print(f"\n[red]Network error:[/] {e}")
                    return False
        
        # Timeout
        console.print("\n[yellow]Authentication timed out. Please try again.[/yellow]")
        return False
        
    except requests.RequestException as e:
        console.print(f"[red]Failed to connect to license server:[/] {e}")
        console.print(f"[yellow]Server URL:[/] {LICENSE_SERVER}")
        return False
    except Exception as e:
        console.print(f"[red]Unexpected error during authentication:[/] {e}")
        return False


def get_current_license_info(verify: bool = False) -> Dict[str, Any]:
    """Get current license/tier info from local cache or validate with server.

    If verify=True, validates stored token with License Server to ensure authenticity.
    If verification fails, returns cached tier (or free if no cache).
    
    Token is stored locally in credentials file with restricted permissions (0600).
    """
    default_info = {"tier": "free", "authorized": False, "org_name": None, "status": "active"}
    
    # Check if cached credentials exist — TOCTOU-safe (H-24)
    cached_info = None
    try:
        with open(CREDENTIALS_FILE, "r") as f:
            cached_info = json.load(f)
        if not isinstance(cached_info, dict):
            cached_info = None
        else:
            # Ensure authorized flag is set for cached credentials
            if "authorized" not in cached_info:
                cached_info["authorized"] = cached_info.get("tier", "free") != "free"
    except (FileNotFoundError, json.JSONDecodeError):
        cached_info = None
    except Exception:
        cached_info = None
    
    # If not verifying, return cached info but never trust local tier (C-14)
    if not verify:
        if cached_info:
            return {**cached_info, "tier": "free"}
        return default_info
    
    # Verification mode: get token from cache and validate with License Server
    if not cached_info or not cached_info.get("access_token"):
        # No token available, return cached or default
        return cached_info or default_info
    
    token = cached_info["access_token"]
    
    try:
        _validate_url = f"{LICENSE_SERVER}/v1/auth/validate"
        _validate_request_url(_validate_url)  # C-5
        response = requests.get(
            _validate_url,
            headers={"Authorization": f"Bearer {token}"},
            timeout=2.0,
            verify=True,           # H-1
            allow_redirects=False, # H-2
        )
        if response.status_code == 200:
            server_data = response.json()
            # Ensure authorized flag is set
            server_data["authorized"] = True
            server_data["access_token"] = token  # Preserve token
            # Update cache with fresh server data
            save_credentials(server_data)
            return server_data
        else:
            # Non-200: cannot verify tier — never trust local JSON tier (C-14)
            fallback = {**(cached_info or {}), "tier": "free"}
            return fallback if fallback else default_info
    except Exception:
        # Server unreachable — never trust local JSON tier (C-14)
        fallback = {**(cached_info or {}), "tier": "free"}
        return fallback if fallback else default_info


def logout() -> None:
    """Clear authentication credentials.

    Removes locally stored access token and cached credentials.
    """
    # TOCTOU-safe unlink (H-24)
    try:
        CREDENTIALS_FILE.unlink()
        console.print("[green]✓ Logged out successfully.[/green]")
    except FileNotFoundError:
        console.print("[yellow]No active session found.[/yellow]")
    except Exception as e:
        console.print(f"[red]Error during logout:[/] {e}")


# Legacy function - no longer used (kept for compatibility)
def get_access_token() -> Optional[str]:
    """Retrieve token from credentials file.
    
    Legacy function kept for backward compatibility.
    Returns stored access token or None if not authenticated.
    """
    # TOCTOU-safe read (H-24)
    try:
        with open(CREDENTIALS_FILE, "r") as f:
            data = json.load(f)
        return data.get("access_token")
    except (FileNotFoundError, json.JSONDecodeError):
        return None
    except Exception:
        return None

