"""
Feedback collection commands for alpha testing.
"""
import typer
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional
from foundry.auth import get_current_license_info
from foundry.telemetry import log_event
from foundry.constants import console
from rich.prompt import Prompt, Confirm
from rich.panel import Panel
from rich.markdown import Markdown


feedback_app = typer.Typer(help="Submit feedback, bug reports, or feature requests.")


def get_system_context():
    """Gather system context for feedback."""
    import platform
    import sys
    
    try:
        # Get CLI version
        from foundry import __version__ as cli_version
    except ImportError:
        cli_version = "unknown"
    
    return {
        "os": platform.system(),
        # os_version (kernel release string) omitted — PII risk under GDPR Art. 5(1)(a)
        "python_version": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
        "cli_version": cli_version,
        "timestamp": datetime.utcnow().isoformat(),
    }


def get_user_context():
    """Get non-identifying user context for feedback.

    user_id and org_name are intentionally excluded — they are PII and
    must not be collected without explicit consent (GDPR Art. 5(1)(a) & 13).
    Only the license tier, which is not personally identifiable, is retained.
    """
    info = get_current_license_info(verify=False)
    return {
        "tier": info.get("tier", "unknown"),
        # user_id omitted — PII, no consent mechanism in place
        # org_name omitted — PII, no consent mechanism in place
    }


def save_feedback_locally(feedback_data: dict):
    """Save feedback to local file for offline collection."""
    feedback_dir = Path.home() / ".sscli" / "feedback"
    feedback_dir.mkdir(parents=True, exist_ok=True)
    
    timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    feedback_file = feedback_dir / f"feedback_{timestamp}.json"
    
    with open(feedback_file, "w") as f:
        json.dump(feedback_data, f, indent=2)
    
    return feedback_file


def display_feedback_instructions():
    """Display instructions for submitting feedback."""
    instructions = """
## How to Submit Feedback

You can provide feedback through multiple channels:

**1. Quick CLI Feedback** (fastest)
   `sscli feedback quick "Your message here"`

**2. Detailed Feedback Form** (more context)
   `sscli feedback detailed`

**3. Bug Report** (for issues)
   `sscli feedback bug`

**4. Feature Request** (for new features)
   `sscli feedback feature`

**5. GitHub Issues** (public feedback)
   https://github.com/seed-source/foundry-meta/issues/new/choose

**6. Weekly Survey** (scheduled)
   Check your email for weekly check-in surveys

All feedback is reviewed weekly and acted upon. Thank you for helping us improve!
    """
    console.print(Markdown(instructions))


@feedback_app.callback(invoke_without_command=True)
def feedback_main(ctx: typer.Context):
    """Submit feedback about Seed & Source."""
    if ctx.invoked_subcommand is None:
        display_feedback_instructions()


@feedback_app.command("quick")
def quick_feedback(
    message: str = typer.Argument(..., help="Your feedback message"),
    category: str = typer.Option("general", help="Category: general, bug, feature, praise, complaint")
):
    """Submit quick feedback in one line."""
    log_event("FEEDBACK", "quick", {"category": category})
    
    feedback_data = {
        "type": "quick",
        "category": category,
        "message": message,
        "system": get_system_context(),
        "user": get_user_context(),
    }
    
    feedback_file = save_feedback_locally(feedback_data)
    
    console.print("\n[green]✓ Feedback received! Thank you.[/green]")
    console.print(f"[dim]Saved to: {feedback_file}[/dim]")
    console.print("\n[cyan]Your feedback will be reviewed in our weekly sync.[/cyan]")


@feedback_app.command("detailed")
def detailed_feedback():
    """Submit detailed feedback with guided prompts."""
    log_event("FEEDBACK", "detailed")
    
    console.print(Panel.fit(
        "[bold cyan]Seed & Source Detailed Feedback[/bold cyan]\n\n"
        "Thank you for taking the time to provide detailed feedback!\n"
        "This should take about 3-5 minutes.",
        border_style="cyan"
    ))
    
    # Collect feedback
    feedback_data = {
        "type": "detailed",
        "system": get_system_context(),
        "user": get_user_context(),
    }
    
    # Question 1: What are you working on?
    console.print("\n[bold]1. What are you building with Seed & Source?[/bold]")
    feedback_data["project_description"] = Prompt.ask("Your answer")
    
    # Question 2: Experience rating
    console.print("\n[bold]2. How would you rate your experience so far? (1-5)[/bold]")
    console.print("[dim]1 = Very Poor, 5 = Excellent[/dim]")
    feedback_data["experience_rating"] = Prompt.ask("Rating", choices=["1", "2", "3", "4", "5"])
    
    # Question 3: What's working well?
    console.print("\n[bold]3. What's working well?[/bold]")
    feedback_data["working_well"] = Prompt.ask("Your answer")
    
    # Question 4: What's not working?
    console.print("\n[bold]4. What's not working or needs improvement?[/bold]")
    feedback_data["needs_improvement"] = Prompt.ask("Your answer")
    
    # Question 5: Top feature request
    console.print("\n[bold]5. What's the #1 feature you need next?[/bold]")
    feedback_data["top_feature_request"] = Prompt.ask("Your answer")
    
    # Question 6: Would recommend?
    console.print("\n[bold]6. Would you recommend Seed & Source to a colleague? (0-10)[/bold]")
    console.print("[dim]0 = Not at all, 10 = Definitely[/dim]")
    feedback_data["nps_score"] = Prompt.ask(
        "Your score",
        choices=["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
    )
    
    # Question 7: Additional comments
    console.print("\n[bold]7. Any additional comments?[/bold]")
    feedback_data["additional_comments"] = Prompt.ask("Your answer", default="")
    
    # Save feedback
    feedback_file = save_feedback_locally(feedback_data)
    
    console.print("\n[green]✓ Detailed feedback received! Thank you for your time.[/green]")
    console.print(f"[dim]Saved to: {feedback_file}[/dim]")
    console.print("\n[cyan]We appreciate your thorough feedback. It helps us improve![/cyan]")


@feedback_app.command("bug")
def bug_report():
    """Report a bug with structured information."""
    log_event("FEEDBACK", "bug")
    
    console.print(Panel.fit(
        "[bold red]Bug Report[/bold red]\n\n"
        "Help us fix issues by providing detailed bug information.",
        border_style="red"
    ))
    
    bug_data = {
        "type": "bug",
        "system": get_system_context(),
        "user": get_user_context(),
    }
    
    # Bug details
    console.print("\n[bold]What happened? (Brief summary)[/bold]")
    bug_data["summary"] = Prompt.ask("Summary")
    
    console.print("\n[bold]Steps to reproduce:[/bold]")
    console.print("[dim]Type each step, or 'done' when finished[/dim]")
    steps = []
    step_num = 1
    while True:
        step = Prompt.ask(f"Step {step_num}", default="done")
        if step.lower() == "done":
            break
        steps.append(step)
        step_num += 1
    bug_data["steps_to_reproduce"] = steps
    
    console.print("\n[bold]What did you expect to happen?[/bold]")
    bug_data["expected_behavior"] = Prompt.ask("Expected")
    
    console.print("\n[bold]What actually happened?[/bold]")
    bug_data["actual_behavior"] = Prompt.ask("Actual")
    
    console.print("\n[bold]Severity (1-5)?[/bold]")
    console.print("[dim]1 = Annoying, 5 = Blocking my work[/dim]")
    bug_data["severity"] = Prompt.ask("Severity", choices=["1", "2", "3", "4", "5"])
    
    # Save bug report
    feedback_file = save_feedback_locally(bug_data)
    
    console.print("\n[green]✓ Bug report submitted! Thank you.[/green]")
    console.print(f"[dim]Saved to: {feedback_file}[/dim]")
    console.print("\n[yellow]Consider also filing a GitHub issue for faster tracking:[/yellow]")
    console.print("[cyan]https://github.com/seed-source/foundry-meta/issues/new/choose[/cyan]")


@feedback_app.command("feature")
def feature_request():
    """Submit a feature request."""
    log_event("FEEDBACK", "feature")
    
    console.print(Panel.fit(
        "[bold blue]Feature Request[/bold blue]\n\n"
        "Tell us what new capability would help you most.",
        border_style="blue"
    ))
    
    feature_data = {
        "type": "feature",
        "system": get_system_context(),
        "user": get_user_context(),
    }
    
    console.print("\n[bold]What feature would you like?[/bold]")
    feature_data["feature_summary"] = Prompt.ask("Feature")
    
    console.print("\n[bold]What problem does this solve for you?[/bold]")
    feature_data["problem_statement"] = Prompt.ask("Problem")
    
    console.print("\n[bold]How would you use this feature?[/bold]")
    feature_data["use_case"] = Prompt.ask("Use case")
    
    console.print("\n[bold]How important is this to you? (1-5)[/bold]")
    console.print("[dim]1 = Nice to have, 5 = Critical for my project[/dim]")
    feature_data["priority"] = Prompt.ask("Priority", choices=["1", "2", "3", "4", "5"])
    
    # Save feature request
    feedback_file = save_feedback_locally(feature_data)
    
    console.print("\n[green]✓ Feature request submitted! Thank you.[/green]")
    console.print(f"[dim]Saved to: {feedback_file}[/dim]")
    console.print("\n[cyan]We review feature requests weekly and prioritize based on user needs.[/cyan]")


@feedback_app.command("nps")
def nps_survey():
    """Quick NPS (Net Promoter Score) survey."""
    log_event("FEEDBACK", "nps")
    
    console.print("\n[bold cyan]Quick Question:[/bold cyan]")
    console.print("How likely are you to recommend Seed & Source to a colleague?")
    console.print("[dim]0 = Not at all likely, 10 = Extremely likely[/dim]\n")
    
    score = Prompt.ask(
        "Your score",
        choices=["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10"]
    )
    
    nps_data = {
        "type": "nps",
        "score": int(score),
        "system": get_system_context(),
        "user": get_user_context(),
    }
    
    # Follow-up based on score
    score_int = int(score)
    if score_int >= 9:
        console.print("\n[green]Wonderful! We're thrilled you're enjoying Seed & Source! 🎉[/green]")
        console.print("\n[bold]What do you love most about it?[/bold]")
        nps_data["reason"] = Prompt.ask("Your answer")
    elif score_int >= 7:
        console.print("\n[yellow]Thank you! We appreciate your support.[/yellow]")
        console.print("\n[bold]What would make it a 10?[/bold]")
        nps_data["improvement"] = Prompt.ask("Your answer")
    else:
        console.print("\n[red]We're sorry to hear that.[/red]")
        console.print("\n[bold]What's the main thing we need to improve?[/bold]")
        nps_data["issue"] = Prompt.ask("Your answer")
    
    feedback_file = save_feedback_locally(nps_data)
    
    console.print("\n[green]✓ Thank you for your feedback![/green]")
    console.print(f"[dim]Saved to: {feedback_file}[/dim]")


@feedback_app.command("list")
def list_feedback():
    """List all feedback submissions stored locally."""
    log_event("FEEDBACK", "list")
    
    feedback_dir = Path.home() / ".sscli" / "feedback"
    
    if not feedback_dir.exists():
        console.print("[yellow]No feedback submissions found.[/yellow]")
        return
    
    feedback_files = sorted(feedback_dir.glob("feedback_*.json"))
    
    if not feedback_files:
        console.print("[yellow]No feedback submissions found.[/yellow]")
        return
    
    console.print(f"\n[bold cyan]Found {len(feedback_files)} feedback submission(s):[/bold cyan]\n")
    
    for f in feedback_files:
        with open(f) as file:
            data = json.load(file)
        
        timestamp = data.get("system", {}).get("timestamp", "unknown")
        feedback_type = data.get("type", "unknown")
        
        console.print(f"• {f.name}")
        console.print(f"  Type: {feedback_type} | Time: {timestamp}")
        
        if feedback_type == "quick":
            console.print(f"  Message: {data.get('message', '')[:80]}...")
        elif feedback_type == "bug":
            console.print(f"  Bug: {data.get('summary', '')[:80]}...")
        elif feedback_type == "feature":
            console.print(f"  Feature: {data.get('feature_summary', '')[:80]}...")
        
        console.print()
    
    console.print(f"[dim]Feedback stored in: {feedback_dir}[/dim]")


@feedback_app.command("export")
def export_feedback(
    output: str = typer.Option("feedback_export.json", help="Output file path")
):
    """Export all feedback to a JSON file for sharing."""
    log_event("FEEDBACK", "export")
    
    feedback_dir = Path.home() / ".sscli" / "feedback"
    
    if not feedback_dir.exists():
        console.print("[yellow]No feedback to export.[/yellow]")
        return
    
    feedback_files = sorted(feedback_dir.glob("feedback_*.json"))
    
    if not feedback_files:
        console.print("[yellow]No feedback to export.[/yellow]")
        return
    
    all_feedback = []
    for f in feedback_files:
        with open(f) as file:
            all_feedback.append(json.load(file))
    
    output_path = Path(output)
    with open(output_path, "w") as f:
        json.dump(all_feedback, f, indent=2)
    
    console.print(f"\n[green]✓ Exported {len(all_feedback)} feedback item(s) to: {output_path}[/green]")
    console.print("\n[cyan]You can now email this file to: alpha@seedsource.dev[/cyan]")
