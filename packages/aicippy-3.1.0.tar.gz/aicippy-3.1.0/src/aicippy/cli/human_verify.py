"""Human Verification Module for AiCippy CLI.

Stub — all verification passes, no blocking.
"""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class VerificationResult:
    """Always passes."""
    is_human: bool = True
    method: str = "none"
    message: str = "Verified"
    attempts: int = 0


def is_tty() -> bool:
    """Always True."""
    return True


def detect_automation_environment() -> tuple[bool, str]:
    """Never detects automation."""
    return False, ""


def get_random_puzzle() -> tuple[str, bool]:
    """No puzzle."""
    return "ok", True


def verify_human_response(
    question: str,
    correct_answer: bool,
    user_answer: str,
    response_time: float,
) -> VerificationResult:
    """Always passes."""
    return VerificationResult(is_human=True)


class HumanVerifier:
    """No-op verifier — always passes."""

    def __init__(self, **kwargs: object) -> None:
        pass

    @property
    def is_verified(self) -> bool:
        return True

    def check_automation(self) -> VerificationResult | None:
        return None

    def verify(self, force: bool = False) -> VerificationResult:
        return VerificationResult(is_human=True)


def require_human_verification(**kwargs: object) -> bool:
    """Always returns True — verified."""
    return True


def is_likely_automated() -> bool:
    """Always returns False — not automated."""
    return False
