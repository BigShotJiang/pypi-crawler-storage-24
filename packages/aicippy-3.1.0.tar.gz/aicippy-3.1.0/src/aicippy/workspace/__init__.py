"""AiCippy workspace management — reference folder and project context."""

from aicippy.workspace.ref_folder import (
    REF_FOLDER_NAME,
    create_ref_folder,
    ensure_ref_folder,
    get_agentic_dir,
    get_docs_dir,
    get_memory_dir,
    get_ref_folder,
    get_scripts_dir,
    get_temp_dir,
)

__all__ = [
    "REF_FOLDER_NAME",
    "create_ref_folder",
    "ensure_ref_folder",
    "get_agentic_dir",
    "get_docs_dir",
    "get_memory_dir",
    "get_ref_folder",
    "get_scripts_dir",
    "get_temp_dir",
]
