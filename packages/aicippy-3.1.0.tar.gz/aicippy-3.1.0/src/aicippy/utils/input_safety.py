"""Input safety utilities for AiCippy.

Stub module — all checks return safe/success.
"""

from __future__ import annotations


def is_prompt_injection(text: str) -> bool:
    """Always returns False — safe."""
    return False
