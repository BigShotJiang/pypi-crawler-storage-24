# Copyright (c) 2026 Copertino All rights reserved.
# SPDX-License-Identifier: LicenseRef-Copertino-1.0

from __future__ import annotations

import base64
import time
from collections.abc import Sequence
from typing import Any, NamedTuple

import qhermes_a2a as _a2a
from qhermes.kernel import Credential, decode_chain

__all__ = [
    # Types
    "KemEndpoint",
    "Session",
    # Re-exported from kernel for convenience
    "Credential",
    "decode_chain",
    # KEM
    "derive_endpoint",
    "kem_offer",
    "kem_accept",
    # AEAD
    "seal",
    "open_blob",
    # Agent Card
    "sign_agent_card",
    "verify_agent_card",
    "agent_card_security_extension",
    "extract_agent_card_ek",
    # A2A message metadata
    "seal_auth",
    "verify_auth",
    "pack_metadata",
    "unpack_metadata",
]

# Exclusive upper bound for the nonce counter (12 bytes = 96 bits).
# seal() raises OverflowError when counter >= _NONCE_LIMIT.
# Valid counter range: [0, _NONCE_LIMIT - 1].
_NONCE_LIMIT = 1 << 96

# Keys used inside message.metadata
_META_AUTH  = "x-qhermes-auth"   # base64-encoded credential chain wire
_META_OFFER = "x-qhermes-offer"  # base64-encoded KEM offer blob

# Key used inside the Agent Card extensions object
_CARD_EK  = "encapsulationKey"   # base64-encoded ML-KEM-768 public key
_CARD_PK  = "signingKey"         # base64-encoded ML-DSA-65 public key
_CARD_EXT = "https://qhermes.dev/a2a/v1"


# ── Types ─────────────────────────────────────────────────────────────────────

class KemEndpoint(NamedTuple):
    """Public encapsulation key + secret decapsulation seed for one agent."""
    encapsulation_key: bytes   # EK_SIZE bytes  — publish in Agent Card
    dk_seed:           bytes   # DK_SEED_SIZE bytes — keep secret


class Session(NamedTuple):
    """Live ChaCha20-Poly1305 session key + monotonic nonce counter.

    Immutable snapshot — each seal() must return a new Session with an
    incremented counter.  Never reuse a Session across process restarts.
    """
    key:     _a2a.SessionKey
    counter: int


# ── KEM key derivation ────────────────────────────────────────────────────────

def derive_endpoint(dsa_seed: bytes) -> KemEndpoint:
    """Derive a ML-KEM-768 key pair from a 32-byte DSA seed.

    Pass the same seed used for kernel identity derivation to bind
    the KEM identity to the DSA identity under the same root secret.
    """
    if len(dsa_seed) != 32:
        raise ValueError(f"dsa_seed must be 32 bytes, got {len(dsa_seed)}")
    ek, dk_seed = _a2a.derive_kem_keypair(dsa_seed)
    return KemEndpoint(encapsulation_key=ek, dk_seed=dk_seed)


# ── KEM handshake ─────────────────────────────────────────────────────────────

def kem_offer(peer_ek: bytes, context: bytes) -> tuple[bytes, Session]:
    """Initiate a KEM handshake (initiator side).

    peer_ek is the responder's encapsulation key (EK_SIZE bytes).
    context binds the derived session key to a domain — supply a stable task or
    session identifier. Without context, two handshakes to the same peer_ek
    produce indistinguishable key material.
    Returns (offer_blob, session).  Embed offer_blob in message.metadata via pack_metadata().
    """
    if len(peer_ek) != _a2a.EK_SIZE:
        raise ValueError(f"peer_ek must be {_a2a.EK_SIZE} bytes, got {len(peer_ek)}")
    offer_blob, sk = _a2a.kem_offer(peer_ek, context)
    return offer_blob, Session(key=sk, counter=0)


def kem_accept(endpoint: KemEndpoint, offer: bytes, context: bytes) -> Session:
    """Complete a KEM handshake (responder side).

    offer is the KEM_OFFER_SIZE-byte blob extracted from message.metadata via unpack_metadata().
    context must be identical to the value passed to kem_offer().
    Returns a Session ready for seal/open_blob.
    """
    if len(offer) != _a2a.KEM_OFFER_SIZE:
        raise ValueError(f"offer must be {_a2a.KEM_OFFER_SIZE} bytes, got {len(offer)}")
    sk = _a2a.kem_accept(endpoint.dk_seed, offer, context)
    return Session(key=sk, counter=0)


# ── AEAD ──────────────────────────────────────────────────────────────────────

def seal(session: Session, plaintext: bytes, aad: bytes = b"") -> tuple[bytes, Session]:
    """Encrypt plaintext with ChaCha20-Poly1305.

    Returns (blob, next_session) where blob = nonce || ciphertext || tag.
    Pass next_session to the following seal() call — never reuse the old one.
    Raises OverflowError if the nonce counter is exhausted.
    """
    if session.counter >= _NONCE_LIMIT:
        raise OverflowError("session nonce counter exhausted — derive a new session")
    nonce = session.counter.to_bytes(12, "little")
    blob = nonce + session.key.seal(nonce, plaintext, aad)
    return blob, Session(key=session.key, counter=session.counter + 1)


def open_blob(session: Session, blob: bytes, aad: bytes = b"") -> bytes:
    """Decrypt and authenticate a blob produced by seal().

    The nonce is read from the first NONCE_SIZE bytes of blob — the session
    counter is not consumed. open_blob does not return a new session.
    Raises ValueError on authentication failure or if blob is too short.
    """
    min_size = _a2a.NONCE_SIZE + _a2a.TAG_SIZE
    if len(blob) < min_size:
        raise ValueError(
            f"blob too short: need at least {min_size} bytes, got {len(blob)}"
        )
    return session.key.open(blob[: _a2a.NONCE_SIZE], blob[_a2a.NONCE_SIZE:], aad)


# ── Agent Card ────────────────────────────────────────────────────────────────

def sign_agent_card(
    master:     bytes,
    deployment: bytes,
    context:    bytes,
    card_bytes: bytes,
) -> bytes:
    """Sign canonical Agent Card bytes with ML-DSA-65.

    card_bytes must be the JCS-canonical UTF-8 JSON of the Agent Card
    (RFC 8785 — keys sorted, no extra whitespace).
    master must be 32 bytes.  Returns SIG_SIZE-byte signature.
    """
    if len(master) != 32:
        raise ValueError(f"master must be 32 bytes, got {len(master)}")
    return _a2a.sign_agent_card(master, deployment, context, card_bytes)


def verify_agent_card(root_pk: bytes, card_bytes: bytes, sig: bytes) -> None:
    """Verify an Agent Card signature.

    card_bytes must be the same JCS-canonical UTF-8 bytes that were signed.
    Raises ValueError on failure.
    """
    if len(root_pk) != _a2a.PK_SIZE:
        raise ValueError(f"root_pk must be {_a2a.PK_SIZE} bytes, got {len(root_pk)}")
    if len(sig) != _a2a.SIG_SIZE:
        raise ValueError(f"sig must be {_a2a.SIG_SIZE} bytes, got {len(sig)}")
    _a2a.verify_agent_card(root_pk, card_bytes, sig)


def agent_card_security_extension(root_pk: bytes, endpoint: KemEndpoint) -> dict[str, Any]:
    """Return the QHermes extension object to embed in an A2A Agent Card.

    Merge the returned dict into the Agent Card's top-level "extensions" map:

        card = {
            "name": "my-agent",
            ...
            "extensions": {
                **agent_card_security_extension(root_pk, endpoint),
            },
        }

    The extension key is "https://qhermes.dev/a2a/v1". It contains "signingKey"
    (ML-DSA-65 public key) and "encapsulationKey" (ML-KEM-768 public key),
    both base64url-encoded for safe embedding in JSON.
    """
    if len(root_pk) != _a2a.PK_SIZE:
        raise ValueError(f"root_pk must be {_a2a.PK_SIZE} bytes, got {len(root_pk)}")
    return {
        _CARD_EXT: {
            _CARD_PK: base64.urlsafe_b64encode(root_pk).decode(),
            _CARD_EK: base64.urlsafe_b64encode(endpoint.encapsulation_key).decode(),
        }
    }


def extract_agent_card_ek(card: dict[str, Any]) -> tuple[bytes, bytes]:
    """Extract (root_pk, encapsulation_key) from a parsed Agent Card dict.

    Raises KeyError if the QHermes extension is absent.
    Raises ValueError if the key sizes are wrong.
    """
    ext = card["extensions"][_CARD_EXT]
    root_pk = base64.urlsafe_b64decode(ext[_CARD_PK])
    ek      = base64.urlsafe_b64decode(ext[_CARD_EK])
    if len(root_pk) != _a2a.PK_SIZE:
        raise ValueError(f"signingKey must decode to {_a2a.PK_SIZE} bytes, got {len(root_pk)}")
    if len(ek) != _a2a.EK_SIZE:
        raise ValueError(f"encapsulationKey must decode to {_a2a.EK_SIZE} bytes, got {len(ek)}")
    return root_pk, ek


# ── Authorization metadata ────────────────────────────────────────────────────

def seal_auth(credentials: Sequence[Credential]) -> bytes:
    """Encode a credential chain to wire bytes.

    Returns raw bytes.  To embed in A2A message.metadata use pack_metadata().
    """
    return _a2a.seal_auth([(c.issuer_pk, c.signature, c.payload) for c in credentials])


def verify_auth(root_pk: bytes, wire: bytes, now: int | None = None) -> int:
    """Verify a wire-encoded authorization chain.  Raises ValueError on failure.

    Returns the number of credentials in the chain.
    now is Unix epoch seconds; defaults to the current system time.
    """
    if len(root_pk) != _a2a.PK_SIZE:
        raise ValueError(f"root_pk must be {_a2a.PK_SIZE} bytes, got {len(root_pk)}")
    return _a2a.verify_auth(root_pk, wire, now if now is not None else int(time.time()))


# ── A2A message.metadata helpers ─────────────────────────────────────────────

def pack_metadata(
    auth_wire:  bytes | None = None,
    offer_blob: bytes | None = None,
    extra:      dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the message.metadata dict for an outgoing A2A message.

    auth_wire  — raw bytes from seal_auth(), base64url-encoded into "x-qhermes-auth"
    offer_blob — raw bytes from kem_offer(), base64url-encoded into "x-qhermes-offer"
    extra      — any additional metadata fields to merge in; merged before qhermes keys
                 so qhermes fields always win on key conflicts

    Example:
        metadata = pack_metadata(
            auth_wire  = seal_auth(chain),
            offer_blob = offer_blob,
            extra      = {"locale": "en-US"},
        )
    """
    out: dict[str, Any] = {}
    if extra is not None:
        out.update(extra)
    if auth_wire is not None:
        out[_META_AUTH] = base64.urlsafe_b64encode(auth_wire).decode()
    if offer_blob is not None:
        out[_META_OFFER] = base64.urlsafe_b64encode(offer_blob).decode()
    return out


def unpack_metadata(
    metadata: dict[str, Any],
) -> tuple[bytes | None, bytes | None]:
    """Extract QHermes fields from a received message.metadata dict.

    Returns (auth_wire, offer_blob) — either may be None if absent.

    auth_wire  — pass to verify_auth()
    offer_blob — pass to kem_accept()

    Example:
        auth_wire, offer_blob = unpack_metadata(message["metadata"] or {})
        if auth_wire:
            n = verify_auth(root_pk, auth_wire, now=int(time.time()))
        if offer_blob:
            session = kem_accept(endpoint, offer_blob, context=task_id.encode())
    """
    raw_auth  = metadata.get(_META_AUTH)
    raw_offer = metadata.get(_META_OFFER)
    return (
        base64.urlsafe_b64decode(raw_auth)  if raw_auth  is not None else None,
        base64.urlsafe_b64decode(raw_offer) if raw_offer is not None else None,
    )
