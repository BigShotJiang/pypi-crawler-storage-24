import sys
import pathlib

# Add both pure-Python layers so that `qhermes.kernel` and `qhermes.a2a` are
# importable alongside the installed Rust extensions.
_ROOT = pathlib.Path(__file__).parent.parent.parent
sys.path.insert(0, str(_ROOT / "qhermes-kernel-py" / "python"))
sys.path.insert(0, str(pathlib.Path(__file__).parent.parent / "python"))
