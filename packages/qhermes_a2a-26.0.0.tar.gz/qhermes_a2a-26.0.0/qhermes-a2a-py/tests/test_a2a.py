# Copyright (c) 2026 Copertino All rights reserved.
# SPDX-License-Identifier: LicenseRef-Copertino-1.0
#
# Integration tests — exercise the compiled Rust extension through the Python layer.
# No mocks. Every assertion operates on real cryptographic output.
#
# Run:  maturin develop && pytest tests/

import base64
import json
import time
import pytest

import qhermes_a2a as _a2a
from qhermes.a2a import (
    KemEndpoint,
    Session,
    derive_endpoint,
    kem_offer,
    kem_accept,
    seal,
    open_blob,
    sign_agent_card,
    verify_agent_card,
    agent_card_security_extension,
    extract_agent_card_ek,
    seal_auth,
    verify_auth,
    pack_metadata,
    unpack_metadata,
    Credential,
)

try:
    import qhermes_kernel as _k
    HAS_KERNEL = True
except ImportError:
    HAS_KERNEL = False


# ── Constants ─────────────────────────────────────────────────────────────────

MASTER     = b"\x01" * 32
DEPLOYMENT = b"prod"
CTX_AGENT  = b"agent-0"
NOW        = int(time.time())


# ── Helper functions ──────────────────────────────────────────────────────────

def make_endpoint() -> KemEndpoint:
    """Derive a KEM endpoint from the fixed MASTER seed."""
    return derive_endpoint(MASTER)


def make_session_pair(context: bytes = b"test-context") -> tuple[Session, Session]:
    """Return (initiator_session, responder_session) sharing the same session key."""
    endpoint          = make_endpoint()
    offer_blob, isess = kem_offer(endpoint.encapsulation_key, context=context)
    rsess             = kem_accept(endpoint, offer_blob, context=context)
    return isess, rsess


@pytest.fixture
def kernel_island():
    pytest.importorskip("qhermes_kernel")
    return _k.IdentityIsland(MASTER, DEPLOYMENT, CTX_AGENT)


@pytest.fixture
def single_credential(kernel_island):
    """Issue a single valid credential against the fixed MASTER identity."""
    child_pk       = _k.IdentityIsland(MASTER, DEPLOYMENT, b"child").public_key()
    scope          = _k.perm_tlv(b"/tasks", b"write")
    caveats        = _k.not_after(NOW + 3600)
    payload, sig   = kernel_island.issue_credential(child_pk, "leaf", 1, scope, caveats)
    issuer_pk      = kernel_island.public_key()
    return Credential(issuer_pk=issuer_pk, signature=sig, payload=payload)


# ── Happy path ────────────────────────────────────────────────────────────────

def test_derive_endpoint_returns_correct_sizes():
    ep = make_endpoint()
    assert len(ep.encapsulation_key) == _a2a.EK_SIZE
    assert len(ep.dk_seed)           == _a2a.DK_SEED_SIZE


def test_kem_handshake_produces_matching_session_keys():
    isess, rsess = make_session_pair(context=b"roundtrip-test")
    blob, _      = seal(isess, b"hello world")
    assert open_blob(rsess, blob) == b"hello world"


def test_seal_open_blob_roundtrip():
    isess, rsess = make_session_pair()
    blob, _      = seal(isess, b"test message")
    assert open_blob(rsess, blob) == b"test message"


def test_seal_open_blob_with_aad_succeeds():
    isess, rsess = make_session_pair()
    blob, _      = seal(isess, b"secret", aad=b"some-metadata")
    assert open_blob(rsess, blob, aad=b"some-metadata") == b"secret"


@pytest.mark.skipif(not HAS_KERNEL, reason="qhermes_kernel not installed")
def test_seal_auth_verify_auth_roundtrip(single_credential):
    wire = seal_auth([single_credential])
    n    = verify_auth(root_pk=single_credential.issuer_pk, wire=wire, now=NOW)
    assert n == 1


def test_pack_unpack_metadata_roundtrip():
    wire = b"\x11" * 16
    blob = b"\x22" * 32
    m    = pack_metadata(auth_wire=wire, offer_blob=blob)
    m2   = json.loads(json.dumps(m))
    auth_wire2, offer_blob2 = unpack_metadata(m2)
    assert auth_wire2  == wire
    assert offer_blob2 == blob


@pytest.mark.skipif(not HAS_KERNEL, reason="qhermes_kernel not installed")
def test_agent_card_sign_verify_roundtrip():
    card    = b'{"name":"agent-0","version":"1"}'
    sig     = sign_agent_card(MASTER, DEPLOYMENT, CTX_AGENT, card)
    root_pk = _k.IdentityIsland(MASTER, DEPLOYMENT, CTX_AGENT).public_key()
    assert len(sig) == _a2a.SIG_SIZE
    verify_agent_card(root_pk=root_pk, card_bytes=card, sig=sig)  # must not raise


@pytest.mark.skipif(not HAS_KERNEL, reason="qhermes_kernel not installed")
def test_full_a2a_message_flow():
    # Issuer builds and signs a credential.
    island   = _k.IdentityIsland(MASTER, DEPLOYMENT, CTX_AGENT)
    child_pk = _k.IdentityIsland(MASTER, DEPLOYMENT, b"worker").public_key()
    scope    = _k.perm_tlv(b"/tasks", b"write")
    caveats  = _k.not_after(NOW + 3600)
    payload, cred_sig = island.issue_credential(child_pk, "leaf", 1, scope, caveats)
    cred = Credential(issuer_pk=island.public_key(), signature=cred_sig, payload=payload)
    wire = seal_auth([cred])

    # Initiator starts a KEM handshake bound to a task identifier.
    task_id  = b"task-abc-123"
    ep       = make_endpoint()
    offer_blob, isess = kem_offer(ep.encapsulation_key, context=task_id)

    # Pack both into message.metadata.
    metadata = pack_metadata(auth_wire=wire, offer_blob=offer_blob)

    # Receiver unpacks, verifies auth, derives matching session key.
    recv_wire, recv_offer = unpack_metadata(metadata)
    n     = verify_auth(root_pk=island.public_key(), wire=recv_wire, now=NOW)
    rsess = kem_accept(ep, recv_offer, context=task_id)
    assert n == 1

    # Both sides can now communicate with AEAD.
    blob, _ = seal(isess, b"authorized payload")
    assert open_blob(rsess, blob) == b"authorized payload"


# ── Edge cases / boundary ─────────────────────────────────────────────────────

def test_seal_open_blob_empty_plaintext():
    isess, rsess = make_session_pair()
    blob, _      = seal(isess, b"")
    assert open_blob(rsess, blob) == b""


def test_seal_open_blob_large_plaintext_64kb():
    isess, rsess = make_session_pair()
    data         = b"x" * 65536
    blob, _      = seal(isess, data)
    assert open_blob(rsess, blob) == data


def test_seal_open_blob_empty_aad():
    isess, rsess = make_session_pair()
    blob, _      = seal(isess, b"msg", aad=b"")
    assert open_blob(rsess, blob, aad=b"") == b"msg"


def test_max_nonce_counter_max_minus_1_works():
    # The last valid counter value must not raise.
    isess, rsess = make_session_pair()
    max_valid    = (1 << 96) - 1
    maxed        = Session(key=isess.key, counter=max_valid)
    blob, next_sess = seal(maxed, b"last valid message")
    # Decryption uses the nonce embedded in the blob, not the session counter.
    assert open_blob(rsess, blob) == b"last valid message"


def test_nonce_counter_exactly_2_pow_96_raises_overflow_error():
    isess, _ = make_session_pair()
    maxed    = Session(key=isess.key, counter=1 << 96)
    with pytest.raises(OverflowError):
        seal(maxed, b"x")


def test_kem_offer_with_empty_context():
    ep         = make_endpoint()
    offer_blob, isess = kem_offer(ep.encapsulation_key, context=b"")
    rsess      = kem_accept(ep, offer_blob, context=b"")
    blob, _    = seal(isess, b"works with empty context")
    assert open_blob(rsess, blob) == b"works with empty context"


def test_kem_offer_with_single_byte_context():
    ep               = make_endpoint()
    offer_blob, isess = kem_offer(ep.encapsulation_key, context=b"X")
    rsess            = kem_accept(ep, offer_blob, context=b"X")
    blob, _          = seal(isess, b"single byte ctx")
    assert open_blob(rsess, blob) == b"single byte ctx"


def test_kem_offer_with_very_long_context():
    ctx              = b"a" * 4096
    ep               = make_endpoint()
    offer_blob, isess = kem_offer(ep.encapsulation_key, context=ctx)
    rsess            = kem_accept(ep, offer_blob, context=ctx)
    blob, _          = seal(isess, b"long context")
    assert open_blob(rsess, blob) == b"long context"


# ── Negative / invalid inputs ─────────────────────────────────────────────────

def test_derive_endpoint_wrong_seed_size_raises():
    with pytest.raises(ValueError):
        derive_endpoint(b"\x01" * 16)


def test_derive_endpoint_empty_seed_raises():
    with pytest.raises(ValueError):
        derive_endpoint(b"")


def test_derive_endpoint_31_bytes_raises():
    with pytest.raises(ValueError):
        derive_endpoint(b"\x01" * 31)


def test_derive_endpoint_33_bytes_raises():
    with pytest.raises(ValueError):
        derive_endpoint(b"\x01" * 33)


def test_kem_offer_wrong_peer_ek_size_raises():
    with pytest.raises(ValueError):
        kem_offer(b"\x00" * 10, context=b"ctx")


def test_kem_offer_empty_peer_ek_raises():
    with pytest.raises(ValueError):
        kem_offer(b"", context=b"ctx")


def test_kem_accept_wrong_offer_size_raises():
    ep = make_endpoint()
    with pytest.raises(ValueError):
        kem_accept(ep, b"\x00" * 10, context=b"ctx")


def test_kem_accept_empty_offer_raises():
    ep = make_endpoint()
    with pytest.raises(ValueError):
        kem_accept(ep, b"", context=b"ctx")


def test_verify_auth_wrong_root_pk_size_raises():
    with pytest.raises(ValueError):
        verify_auth(root_pk=b"\x00" * 10, wire=b"", now=NOW)


def test_sign_agent_card_wrong_master_size_raises():
    with pytest.raises(ValueError):
        sign_agent_card(b"\x01" * 16, DEPLOYMENT, CTX_AGENT, b"card")


def test_sign_agent_card_empty_master_raises():
    with pytest.raises(ValueError):
        sign_agent_card(b"", DEPLOYMENT, CTX_AGENT, b"card")


def test_verify_agent_card_wrong_pk_size_raises():
    with pytest.raises(ValueError):
        verify_agent_card(b"\x00" * 10, b"card", b"\x00" * _a2a.SIG_SIZE)


def test_verify_agent_card_wrong_sig_size_raises():
    with pytest.raises(ValueError):
        verify_agent_card(b"\x00" * _a2a.PK_SIZE, b"card", b"\x00" * 10)


# ── Context binding ────────────────────────────────────────────────────────────

def test_mismatched_context_produces_different_session_key_and_open_blob_fails():
    # kem_offer uses context=b"task-1" but kem_accept uses b"task-2" — key mismatch.
    ep               = make_endpoint()
    offer_blob, isess = kem_offer(ep.encapsulation_key, context=b"task-1")
    rsess            = kem_accept(ep, offer_blob, context=b"task-2")
    blob, _          = seal(isess, b"hello")
    with pytest.raises(Exception):
        open_blob(rsess, blob)


def test_matching_context_produces_same_session_key_and_open_blob_succeeds():
    context          = b"shared-task-id"
    ep               = make_endpoint()
    offer_blob, isess = kem_offer(ep.encapsulation_key, context=context)
    rsess            = kem_accept(ep, offer_blob, context=context)
    blob, _          = seal(isess, b"authenticated")
    assert open_blob(rsess, blob) == b"authenticated"


# ── Integrity: tampered blobs ─────────────────────────────────────────────────

def test_tampered_ciphertext_body_fails_open_blob():
    isess, rsess = make_session_pair()
    blob, _      = seal(isess, b"hello world")
    bad          = bytearray(blob)
    # Flip a byte after the nonce region (first NONCE_SIZE bytes) in the ciphertext body.
    bad[_a2a.NONCE_SIZE] ^= 0xFF
    with pytest.raises(Exception):
        open_blob(rsess, bytes(bad))


def test_tampered_auth_tag_fails_open_blob():
    isess, rsess = make_session_pair()
    blob, _      = seal(isess, b"hello world")
    bad          = bytearray(blob)
    bad[-1]     ^= 0xFF   # last byte is in the Poly1305 authentication tag
    with pytest.raises(Exception):
        open_blob(rsess, bytes(bad))


def test_tampered_nonce_fails_open_blob():
    isess, rsess = make_session_pair()
    blob, _      = seal(isess, b"hello world")
    bad          = bytearray(blob)
    bad[0]      ^= 0xFF   # first byte is in the nonce prefix
    with pytest.raises(Exception):
        open_blob(rsess, bytes(bad))


@pytest.mark.skipif(not HAS_KERNEL, reason="qhermes_kernel not installed")
def test_tampered_wire_fails_verify_auth(single_credential):
    wire = bytearray(seal_auth([single_credential]))
    wire[-1] ^= 0xFF
    with pytest.raises(Exception):
        verify_auth(root_pk=single_credential.issuer_pk, wire=bytes(wire), now=NOW)


@pytest.mark.skipif(not HAS_KERNEL, reason="qhermes_kernel not installed")
def test_expired_credential_fails_verify_auth(kernel_island):
    child_pk     = _k.IdentityIsland(MASTER, DEPLOYMENT, b"child").public_key()
    scope        = _k.perm_tlv(b"/tasks", b"read")
    expired_cav  = _k.not_after(NOW - 1)   # expired one second ago
    payload, sig = kernel_island.issue_credential(child_pk, "leaf", 1, scope, expired_cav)
    cred         = Credential(issuer_pk=kernel_island.public_key(), signature=sig, payload=payload)
    wire         = seal_auth([cred])
    with pytest.raises(Exception):
        verify_auth(root_pk=kernel_island.public_key(), wire=wire, now=NOW)


@pytest.mark.skipif(not HAS_KERNEL, reason="qhermes_kernel not installed")
def test_wrong_root_pk_fails_verify_auth(single_credential):
    impostor_pk = _k.IdentityIsland(b"\xff" * 32, DEPLOYMENT, CTX_AGENT).public_key()
    wire        = seal_auth([single_credential])
    with pytest.raises(Exception):
        verify_auth(root_pk=impostor_pk, wire=wire, now=NOW)


def test_wrong_aad_fails_open_blob():
    isess, rsess = make_session_pair()
    blob, _      = seal(isess, b"secret", aad=b"correct-aad")
    with pytest.raises(Exception):
        open_blob(rsess, blob, aad=b"wrong-aad")


def test_missing_aad_fails_open_blob():
    isess, rsess = make_session_pair()
    blob, _      = seal(isess, b"secret", aad=b"required-aad")
    with pytest.raises(Exception):
        open_blob(rsess, blob)   # aad defaults to b""


def test_blob_too_short_raises_value_error():
    _, rsess = make_session_pair()
    with pytest.raises(ValueError):
        open_blob(rsess, b"\x00" * 5)


def test_empty_blob_raises_value_error():
    _, rsess = make_session_pair()
    with pytest.raises(ValueError):
        open_blob(rsess, b"")


# ── Session immutability ──────────────────────────────────────────────────────

def test_seal_returns_new_session_with_counter_incremented():
    isess, _    = make_session_pair()
    _, isess2   = seal(isess, b"a")
    _, isess3   = seal(isess2, b"b")
    assert isess.counter  == 0
    assert isess2.counter == 1
    assert isess3.counter == 2


def test_original_session_unchanged_after_seal():
    # Session is a NamedTuple — each seal() must return a new object, not mutate.
    isess, _     = make_session_pair()
    _, isess2    = seal(isess, b"msg")
    assert isess.counter == 0


def test_reusing_old_session_produces_same_blob_nonce_reuse():
    # Reusing the same counter/nonce on a deterministic cipher produces identical blobs.
    isess, _ = make_session_pair()
    blob1, _ = seal(isess, b"msg")
    blob2, _ = seal(isess, b"msg")
    assert blob1 == blob2   # nonce reuse is visible as ciphertext equality


def test_sequential_seals_with_different_counters_produce_different_blobs():
    isess, _   = make_session_pair()
    blob1, s2  = seal(isess, b"msg")
    blob2, _   = seal(s2,    b"msg")
    assert blob1 != blob2   # different nonce → different ciphertext even for same plaintext


def test_multiple_sequential_messages_roundtrip():
    isess, rsess = make_session_pair()
    messages     = [b"msg-%d" % i for i in range(10)]
    blobs        = []
    sess         = isess
    for msg in messages:
        blob, sess = seal(sess, msg)
        blobs.append(blob)
    # Responder can open each blob independently (nonce is embedded in the blob).
    for blob, expected in zip(blobs, messages):
        assert open_blob(rsess, blob) == expected


# ── pack_metadata / unpack_metadata ──────────────────────────────────────────

def test_pack_metadata_empty_returns_empty_dict():
    assert pack_metadata() == {}


def test_pack_metadata_auth_wire_is_base64_string():
    wire = b"\x01\x02\x03"
    m    = pack_metadata(auth_wire=wire)
    assert "x-qhermes-auth" in m
    assert isinstance(m["x-qhermes-auth"], str)


def test_pack_metadata_offer_blob_is_base64_string():
    blob = b"\xde\xad\xbe\xef"
    m    = pack_metadata(offer_blob=blob)
    assert "x-qhermes-offer" in m
    assert isinstance(m["x-qhermes-offer"], str)


def test_pack_metadata_extra_fields_are_merged():
    m = pack_metadata(extra={"locale": "en-US", "sessionId": "abc"})
    assert m["locale"]    == "en-US"
    assert m["sessionId"] == "abc"


def test_pack_metadata_extra_empty_dict_does_not_crash():
    # extra={} must be handled gracefully — the guard is `if extra is not None`.
    m = pack_metadata(extra={})
    assert isinstance(m, dict)


def test_pack_metadata_extra_none_does_not_crash():
    m = pack_metadata(extra=None)
    assert isinstance(m, dict)


def test_pack_metadata_qhermes_fields_overwrite_extra_if_key_conflicts():
    # Implementation applies extra first, then writes its own keys — so qhermes wins.
    wire = b"\xAB" * 8
    m    = pack_metadata(auth_wire=wire, extra={"x-qhermes-auth": "WRONG"})
    auth_recovered, _ = unpack_metadata(m)
    assert auth_recovered == wire


def test_pack_metadata_is_json_serializable():
    wire = b"\x11" * 16
    blob = b"\x22" * 32
    m    = pack_metadata(auth_wire=wire, offer_blob=blob, extra={"k": "v"})
    json.dumps(m)   # must not raise


def test_unpack_metadata_absent_fields_return_none():
    auth_wire, offer_blob = unpack_metadata({"locale": "en-US"})
    assert auth_wire  is None
    assert offer_blob is None


def test_unpack_metadata_empty_dict_returns_none_pair():
    auth_wire, offer_blob = unpack_metadata({})
    assert auth_wire  is None
    assert offer_blob is None


def test_pack_metadata_extra_fields_merged_with_qhermes_fields():
    wire = b"\x11" * 8
    m    = pack_metadata(auth_wire=wire, extra={"custom-header": "value"})
    assert "custom-header" in m
    assert "x-qhermes-auth" in m


# ── Agent Card ────────────────────────────────────────────────────────────────

@pytest.mark.skipif(not HAS_KERNEL, reason="qhermes_kernel not installed")
def test_sign_agent_card_is_deterministic():
    card = b'{"name":"agent-0"}'
    sig1 = sign_agent_card(MASTER, DEPLOYMENT, CTX_AGENT, card)
    sig2 = sign_agent_card(MASTER, DEPLOYMENT, CTX_AGENT, card)
    assert sig1 == sig2


@pytest.mark.skipif(not HAS_KERNEL, reason="qhermes_kernel not installed")
def test_verify_agent_card_tampered_card_fails():
    card    = b'{"name":"agent-0"}'
    sig     = sign_agent_card(MASTER, DEPLOYMENT, CTX_AGENT, card)
    root_pk = _k.IdentityIsland(MASTER, DEPLOYMENT, CTX_AGENT).public_key()
    with pytest.raises(Exception):
        verify_agent_card(root_pk, b'{"name":"agent-TAMPERED"}', sig)


@pytest.mark.skipif(not HAS_KERNEL, reason="qhermes_kernel not installed")
def test_verify_agent_card_wrong_key_fails():
    card     = b'{"name":"agent-0"}'
    sig      = sign_agent_card(MASTER, DEPLOYMENT, CTX_AGENT, card)
    wrong_pk = _k.IdentityIsland(b"\xff" * 32, DEPLOYMENT, CTX_AGENT).public_key()
    with pytest.raises(Exception):
        verify_agent_card(wrong_pk, card, sig)


def test_agent_card_security_extension_contains_required_keys():
    ep = make_endpoint()
    # Use a valid PK_SIZE dummy key when kernel is absent.
    root_pk = (
        _k.IdentityIsland(MASTER, DEPLOYMENT, CTX_AGENT).public_key()
        if HAS_KERNEL
        else b"\x00" * _a2a.PK_SIZE
    )
    ext   = agent_card_security_extension(root_pk, ep)
    assert "https://qhermes.dev/a2a/v1" in ext
    inner = ext["https://qhermes.dev/a2a/v1"]
    assert "signingKey"       in inner
    assert "encapsulationKey" in inner


def test_agent_card_security_extension_is_json_serializable():
    ep      = make_endpoint()
    root_pk = b"\x00" * _a2a.PK_SIZE
    ext     = agent_card_security_extension(root_pk, ep)
    json.dumps(ext)   # must not raise


def test_agent_card_security_extension_wrong_pk_size_raises():
    ep = make_endpoint()
    with pytest.raises(ValueError):
        agent_card_security_extension(b"\x00" * 10, ep)


def test_extract_agent_card_ek_missing_extension_raises_key_error():
    with pytest.raises(KeyError):
        extract_agent_card_ek({"extensions": {}})


def test_extract_agent_card_ek_no_extensions_key_raises_key_error():
    with pytest.raises(KeyError):
        extract_agent_card_ek({})


@pytest.mark.skipif(not HAS_KERNEL, reason="qhermes_kernel not installed")
def test_extract_agent_card_ek_roundtrip():
    ep      = make_endpoint()
    root_pk = _k.IdentityIsland(MASTER, DEPLOYMENT, CTX_AGENT).public_key()
    ext     = agent_card_security_extension(root_pk, ep)
    card    = {"extensions": ext}
    recovered_pk, recovered_ek = extract_agent_card_ek(card)
    assert recovered_pk == root_pk
    assert recovered_ek == ep.encapsulation_key


def test_extract_agent_card_ek_truncated_pk_raises_value_error():
    ep = make_endpoint()
    bad_ext = {
        "https://qhermes.dev/a2a/v1": {
            "signingKey":       base64.urlsafe_b64encode(b"\x00" * 10).decode(),
            "encapsulationKey": base64.urlsafe_b64encode(ep.encapsulation_key).decode(),
        }
    }
    with pytest.raises(ValueError):
        extract_agent_card_ek({"extensions": bad_ext})


def test_extract_agent_card_ek_truncated_ek_raises_value_error():
    # Provide a correct-length PK but a truncated EK.
    root_pk = b"\x00" * _a2a.PK_SIZE
    bad_ext = {
        "https://qhermes.dev/a2a/v1": {
            "signingKey":       base64.urlsafe_b64encode(root_pk).decode(),
            "encapsulationKey": base64.urlsafe_b64encode(b"\x00" * 10).decode(),
        }
    }
    with pytest.raises(ValueError):
        extract_agent_card_ek({"extensions": bad_ext})


# ── seal_auth with Sequence types ─────────────────────────────────────────────

@pytest.mark.skipif(not HAS_KERNEL, reason="qhermes_kernel not installed")
def test_seal_auth_accepts_list(single_credential):
    # Passing a plain list must work.
    wire = seal_auth([single_credential])
    assert isinstance(wire, bytes)
    assert len(wire) > 0


@pytest.mark.skipif(not HAS_KERNEL, reason="qhermes_kernel not installed")
def test_seal_auth_accepts_tuple(single_credential):
    # Passing a tuple (also a Sequence) must work.
    wire = seal_auth((single_credential,))
    assert isinstance(wire, bytes)
    assert len(wire) > 0


@pytest.mark.skipif(not HAS_KERNEL, reason="qhermes_kernel not installed")
def test_seal_auth_accepts_generator_expression(single_credential):
    # A generator is a valid Sequence source — seal_auth iterates it.
    wire = seal_auth(c for c in [single_credential])
    assert isinstance(wire, bytes)
    assert len(wire) > 0


@pytest.mark.skipif(not HAS_KERNEL, reason="qhermes_kernel not installed")
def test_seal_auth_list_and_tuple_produce_identical_wire(single_credential):
    wire_list  = seal_auth([single_credential])
    wire_tuple = seal_auth((single_credential,))
    assert wire_list == wire_tuple


# ── derive_endpoint: determinism ──────────────────────────────────────────────

def test_derive_endpoint_is_deterministic():
    ep1 = derive_endpoint(MASTER)
    ep2 = derive_endpoint(MASTER)
    assert ep1.encapsulation_key == ep2.encapsulation_key
    assert ep1.dk_seed           == ep2.dk_seed


def test_derive_endpoint_different_seeds_produce_different_keys():
    ep1 = derive_endpoint(b"\x01" * 32)
    ep2 = derive_endpoint(b"\x02" * 32)
    assert ep1.encapsulation_key != ep2.encapsulation_key


# ── KEM: offer blob uniqueness ────────────────────────────────────────────────

def test_kem_offer_produces_different_blobs_each_call():
    # ML-KEM-768 encapsulation uses OS entropy — successive calls must differ.
    ep     = make_endpoint()
    blob1, _ = kem_offer(ep.encapsulation_key, context=b"ctx")
    blob2, _ = kem_offer(ep.encapsulation_key, context=b"ctx")
    assert blob1 != blob2


def test_kem_offer_returns_session_at_counter_zero():
    ep       = make_endpoint()
    _, sess  = kem_offer(ep.encapsulation_key, context=b"ctx")
    assert isinstance(sess, Session)
    assert sess.counter == 0


def test_kem_accept_returns_session_at_counter_zero():
    ep               = make_endpoint()
    offer_blob, _    = kem_offer(ep.encapsulation_key, context=b"ctx")
    sess             = kem_accept(ep, offer_blob, context=b"ctx")
    assert isinstance(sess, Session)
    assert sess.counter == 0


# ── verify_auth: additional integrity cases ───────────────────────────────────

@pytest.mark.skipif(not HAS_KERNEL, reason="qhermes_kernel not installed")
def test_verify_auth_not_before_in_future_fails(kernel_island):
    child_pk     = _k.IdentityIsland(MASTER, DEPLOYMENT, b"child").public_key()
    scope        = _k.perm_tlv(b"/tasks", b"read")
    future_cav   = _k.not_before(NOW + 3600)   # valid only one hour from now
    payload, sig = kernel_island.issue_credential(child_pk, "leaf", 1, scope, future_cav)
    cred         = Credential(issuer_pk=kernel_island.public_key(), signature=sig, payload=payload)
    wire         = seal_auth([cred])
    with pytest.raises(Exception):
        verify_auth(root_pk=kernel_island.public_key(), wire=wire, now=NOW)


@pytest.mark.skipif(not HAS_KERNEL, reason="qhermes_kernel not installed")
def test_verify_auth_truncated_wire_fails(single_credential):
    wire = seal_auth([single_credential])
    with pytest.raises(Exception):
        verify_auth(root_pk=single_credential.issuer_pk, wire=wire[:10], now=NOW)


def test_verify_auth_empty_wire_fails():
    pk = b"\x00" * _a2a.PK_SIZE
    with pytest.raises(Exception):
        verify_auth(root_pk=pk, wire=b"", now=NOW)


@pytest.mark.skipif(not HAS_KERNEL, reason="qhermes_kernel not installed")
def test_verify_auth_scope_escalation_verb_fails(kernel_island):
    # Parent grants (/tasks, read). Child claims (/tasks, write).
    # verify_auth must reject the chain at scope subset enforcement.
    child_pk   = _k.IdentityIsland(MASTER, DEPLOYMENT, b"child").public_key()
    grandchild = _k.IdentityIsland(MASTER, DEPLOYMENT, b"grandchild")

    read_scope  = _k.perm_tlv(b"/tasks", b"read")
    write_scope = _k.perm_tlv(b"/tasks", b"write")
    no_caveats  = b""

    # Root → child with read scope, role=node so child can delegate.
    payload1, sig1 = kernel_island.issue_credential(child_pk, "node", 1, read_scope, no_caveats)
    cred1 = Credential(issuer_pk=kernel_island.public_key(), signature=sig1, payload=payload1)

    # Child → grandchild claiming write scope (escalation).
    child_island = _k.IdentityIsland(MASTER, DEPLOYMENT, b"child")
    gc_pk        = grandchild.public_key()
    payload2, sig2 = child_island.issue_credential(gc_pk, "leaf", 2, write_scope, no_caveats)
    cred2 = Credential(issuer_pk=child_pk, signature=sig2, payload=payload2)

    wire = seal_auth([cred1, cred2])
    with pytest.raises(Exception):
        verify_auth(root_pk=kernel_island.public_key(), wire=wire, now=NOW)
