# Copyright (c) 2026 Copertino All rights reserved.
# SPDX-License-Identifier: LicenseRef-Copertino-1.0
#
# Example: Hospital patient-data pipeline with AI agents
#
# Scenario
# --------
# A hospital runs AI agents that process patient data through a strictly ordered
# pipeline.  Data flows one-way only: raw → anonymized → analysis.  No agent can
# read data from a later stage or write to an earlier stage.  All permissions are
# enforced by signed credential chains anchored at the hospital's compliance root.
#
#   ComplianceRoot       — root of trust; issues all credentials
#   IngestionAgent       — receives raw patient data; writes to data/raw/
#                          Cannot read identifiable fields from any other path
#   AnonymizationAgent   — reads data/raw/, writes data/anonymized/
#                          The only agent allowed to see identifiable data temporarily
#   AnalysisAgent        — reads data/anonymized/ only; produces reports
#                          Explicitly excluded from data/raw/ — verified at chain level
#   AuditAgent           — read-only on all paths; long-lived credential for GDPR logging
#
# Key security properties demonstrated
# -------------------------------------
# 1. One-way data flow: each agent's credential scope covers exactly one stage's
#    read path and the next stage's write path.  No backwards access is possible.
# 2. AnalysisAgent exclusion from raw data: parse_payload on the AnalysisAgent
#    credential shows data/raw/ is absent — confirmed at chain level.
# 3. Encrypted handshake: AnonymizationAgent and AnalysisAgent exchange the
#    anonymized data record over a KEM session bound to the batch ID.
# 4. Compliance check: a snapshot function prints which credentials are valid at
#    a given timestamp and what permissions each agent holds — for GDPR auditors.
#
# Run it:
#   pip install qhermes-kernel qhermes-a2a a2a-sdk
#   python examples/healthcare_pipeline.py

from __future__ import annotations

import json
import time
from hashlib import sha256

from a2a.types import (
    AgentCapabilities,
    AgentCard,
    AgentSkill,
    Message,
    Part,
    Role,
    TextPart,
)

from qhermes.kernel import (
    make_identity,
    make_policy,
    derive_public_key,
    issue_credential,
    build_chain,
    decode_chain,
    explain_credential,
    credential_valid_at,
    parse_payload,
)
from qhermes.a2a import (
    Session,
    derive_endpoint,
    kem_offer,
    kem_accept,
    seal,
    open_blob,
    agent_card_security_extension,
    extract_agent_card_ek,
    verify_auth,
    pack_metadata,
    unpack_metadata,
)


# ── Simulated network ─────────────────────────────────────────────────────────
#
# In production each agent publishes its Agent Card at
#   https://<host>/.well-known/agent.json
# and messages travel over HTTPS + JSON-RPC 2.0.
# Here we use an in-memory store as "the network".

_AGENT_CARDS:      dict[str, AgentCard] = {}
_AGENT_EXTENSIONS: dict[str, dict]     = {}
_MESSAGES:         list[Message]       = []


def publish_card(name: str, card: AgentCard, extensions: dict) -> None:
    _AGENT_CARDS[name]      = card
    _AGENT_EXTENSIONS[name] = extensions


def discover_extensions(name: str) -> dict:
    return _AGENT_EXTENSIONS[name]


def send_message(msg: Message) -> None:
    _MESSAGES.append(msg)


def receive_message() -> Message:
    return _MESSAGES.pop(0)


# ── Agent processes ───────────────────────────────────────────────────────────

def run_compliance_root() -> None:
    """
    ComplianceRoot derives all identities, publishes its Agent Card, and issues
    the scoped credentials for every agent in the pipeline.

    Credential design follows the principle of least privilege:
      - IngestionAgent can write raw data but cannot read from any path.
      - AnonymizationAgent can read raw data and write anonymized data.
      - AnalysisAgent can only read from the anonymized tier — data/raw/ is
        completely absent from its signed scope.
      - AuditAgent gets read-only access to all tiers with a 10-year validity
        period, ensuring GDPR audit logs can always be verified.
    """
    print("\n── ComplianceRoot ───────────────────────────────────────────────────")

    master = bytes.fromhex(
        "9f8e7d6c5b4a392817263504f3e2d1c0"
        "b0a192837465574839201fedcba98765"
    )
    deployment = b"hospital-prod-eu"

    root_id       = make_identity(master, deployment, b"compliance-root")
    root_pk       = derive_public_key(root_id)
    root_kem_seed = sha256(master + b"kem:compliance-root").digest()
    root_endpoint = derive_endpoint(root_kem_seed)

    print(f"  root PK: {root_pk.hex()[:32]}...")
    print(f"  root EK: {root_endpoint.encapsulation_key.hex()[:32]}...")

    card = AgentCard(
        capabilities=AgentCapabilities(streaming=False, pushNotifications=False),
        defaultInputModes=["text/plain"],
        defaultOutputModes=["text/plain"],
        description="Root compliance authority for the hospital AI pipeline",
        name="ComplianceRoot",
        url="https://compliance.hospital.internal/.well-known/agent.json",
        version="1.0.0",
        skills=[AgentSkill(id="issue-pipeline-creds", name="Issue pipeline credentials", description="Issue scoped credentials to pipeline agents.", tags=["compliance"])],
    )
    publish_card("ComplianceRoot", card, agent_card_security_extension(root_pk, root_endpoint))
    print("  Agent Card published at /.well-known/agent.json")

    ingestion_pk     = derive_public_key(make_identity(master, deployment, b"ingestion-agent"))
    anonymization_pk = derive_public_key(make_identity(master, deployment, b"anonymization-agent"))
    analysis_pk      = derive_public_key(make_identity(master, deployment, b"analysis-agent"))
    audit_pk         = derive_public_key(make_identity(master, deployment, b"audit-agent"))

    ingestion_policy = make_policy(
        resources=[b"data/raw/"],
        actions=[b"PUT"],
        hours_valid=8,
    )
    root_to_ingestion = issue_credential(
        identity = root_id,
        child_pk = ingestion_pk,
        policy   = ingestion_policy,
        depth    = 1,
        role     = "leaf",
    )
    print(f"\n  [ingestion cred]     {explain_credential(root_to_ingestion)}")

    anonymization_policy = make_policy(
        permissions=[
            (b"data/raw/",        b"GET"),
            (b"data/anonymized/", b"PUT"),
        ],
        hours_valid=8,
    )
    root_to_anonymization = issue_credential(
        identity = root_id,
        child_pk = anonymization_pk,
        policy   = anonymization_policy,
        depth    = 1,
        role     = "leaf",
    )
    print(f"  [anonymization cred] {explain_credential(root_to_anonymization)}")

    analysis_policy = make_policy(
        resources=[b"data/anonymized/"],
        actions=[b"GET"],
        hours_valid=8,
    )
    root_to_analysis = issue_credential(
        identity = root_id,
        child_pk = analysis_pk,
        policy   = analysis_policy,
        depth    = 1,
        role     = "leaf",
    )
    print(f"  [analysis cred]      {explain_credential(root_to_analysis)}")

    audit_policy = make_policy(
        resources=[b"data/raw/", b"data/anonymized/", b"reports/"],
        actions=[b"GET"],
        hours_valid=87_600,   # 10 years — GDPR audit retention
    )
    root_to_audit = issue_credential(
        identity = root_id,
        child_pk = audit_pk,
        policy   = audit_policy,
        depth    = 1,
        role     = "leaf",
    )
    print(f"  [audit cred]         {explain_credential(root_to_audit)}")

    _AGENT_CARDS["__chains__"] = {
        "ingestion":     build_chain((root_to_ingestion,)).hex(),
        "anonymization": build_chain((root_to_anonymization,)).hex(),
        "analysis":      build_chain((root_to_analysis,)).hex(),
        "audit":         build_chain((root_to_audit,)).hex(),
    }
    print("\n  All pipeline credentials issued.")


def run_analysis_agent_setup() -> None:
    """
    AnalysisAgent publishes its Agent Card so AnonymizationAgent can discover
    its KEM key before opening the secure data transfer channel.
    """
    master     = bytes.fromhex(
        "9f8e7d6c5b4a392817263504f3e2d1c0"
        "b0a192837465574839201fedcba98765"
    )
    deployment = b"hospital-prod-eu"
    analysis_id       = make_identity(master, deployment, b"analysis-agent")
    analysis_pk       = derive_public_key(analysis_id)
    analysis_kem_seed = sha256(master + b"kem:analysis-agent").digest()
    analysis_endpoint = derive_endpoint(analysis_kem_seed)
    card = AgentCard(
        capabilities=AgentCapabilities(streaming=False, pushNotifications=False),
        defaultInputModes=["text/plain"],
        defaultOutputModes=["text/plain"],
        description="Reads anonymized patient data and produces clinical reports",
        name="AnalysisAgent",
        url="https://analysis.hospital.internal/.well-known/agent.json",
        version="1.0.0",
        skills=[AgentSkill(id="analyse-cohort", name="Analyse anonymized cohort data", description="Run cohort analysis on anonymized patient records.", tags=["analysis"])],
    )
    publish_card("AnalysisAgent", card, agent_card_security_extension(analysis_pk, analysis_endpoint))


def run_ingestion_agent() -> None:
    """
    IngestionAgent verifies its credential and deposits a raw patient record into
    the data/raw/ tier.
    """
    print("\n── IngestionAgent ───────────────────────────────────────────────────")

    master     = bytes.fromhex(
        "9f8e7d6c5b4a392817263504f3e2d1c0"
        "b0a192837465574839201fedcba98765"
    )
    deployment = b"hospital-prod-eu"
    root_pk    = derive_public_key(make_identity(master, deployment, b"compliance-root"))
    wire_chain = bytes.fromhex(_AGENT_CARDS["__chains__"]["ingestion"])

    n = verify_auth(root_pk=root_pk, wire=wire_chain)
    print(f"  Credential verified: {n} hop(s) anchored at ComplianceRoot")
    for i, cred in enumerate(decode_chain(wire_chain)):
        print(f"    [{i+1}] {explain_credential(cred)}")

    raw_record = {
        "patient_id": "PT-20260316-00142",
        "name":       "Jane Doe",
        "dob":        "1974-08-23",
        "diagnosis":  "T2DM",
        "hba1c":      8.1,
        "admitted":   "2026-03-15",
    }
    print(f"\n  Writing raw record to data/raw/PT-20260316-00142.json")
    print(f"    patient_id: {raw_record['patient_id']}  (identifiable — stays in raw tier)")
    _AGENT_CARDS["__raw_record__"] = raw_record


def run_anonymization_agent() -> None:
    """
    AnonymizationAgent reads from data/raw/ and writes the anonymized record to
    data/anonymized/.  It then sends the anonymized record to AnalysisAgent over
    a KEM-secured channel, attaching its credential chain so AnalysisAgent can
    verify the provenance of the data before processing it.
    """
    print("\n── AnonymizationAgent ───────────────────────────────────────────────")

    master     = bytes.fromhex(
        "9f8e7d6c5b4a392817263504f3e2d1c0"
        "b0a192837465574839201fedcba98765"
    )
    deployment = b"hospital-prod-eu"
    root_pk    = derive_public_key(make_identity(master, deployment, b"compliance-root"))
    wire_chain = bytes.fromhex(_AGENT_CARDS["__chains__"]["anonymization"])

    n = verify_auth(root_pk=root_pk, wire=wire_chain)
    print(f"  Credential verified: {n} hop(s)")
    for i, cred in enumerate(decode_chain(wire_chain)):
        print(f"    [{i+1}] {explain_credential(cred)}")

    raw_record = _AGENT_CARDS["__raw_record__"]

    anon_record = {
        "anon_id":   sha256(raw_record["patient_id"].encode()).hexdigest()[:16],
        "age_group": "50-59",
        "diagnosis": raw_record["diagnosis"],
        "hba1c":     raw_record["hba1c"],
        "admitted":  raw_record["admitted"],
    }
    print(f"\n  Anonymized record (identifiable fields removed):")
    print(f"    anon_id:   {anon_record['anon_id']}  (hash of patient_id)")
    print(f"    age_group: {anon_record['age_group']}  (not the exact dob)")

    _AGENT_CARDS["__anon_record__"] = anon_record

    _, analysis_ek = extract_agent_card_ek({"extensions": discover_extensions("AnalysisAgent")})

    batch_id = b"batch-20260316-001"
    offer_blob, initiator_session = kem_offer(peer_ek=analysis_ek, context=batch_id)

    metadata = pack_metadata(
        auth_wire  = wire_chain,
        offer_blob = offer_blob,
        extra      = {"batchId": batch_id.decode(), "recordCount": 1},
    )
    send_message(Message(
        messageId = "msg-anon-001",
        role      = Role.agent,
        parts     = [Part(root=TextPart(text="Anonymized batch ready for analysis"))],
        metadata  = metadata,
    ))
    print(f"\n  KEM offer sent to AnalysisAgent (batch {batch_id.decode()})")

    payload     = json.dumps(anon_record).encode()
    blob, _sess = seal(initiator_session, payload, aad=batch_id)
    send_message(Message(
        messageId = "msg-anon-002",
        role      = Role.agent,
        parts     = [],
        metadata  = {"batchId": batch_id.decode(), "x-qhermes-payload": blob.hex()},
    ))
    print(f"  Anonymized record sealed and sent ({len(blob)} bytes)")


def run_analysis_agent() -> None:
    """
    AnalysisAgent receives the anonymized batch from AnonymizationAgent, verifies
    the sender's credential chain, accepts the KEM handshake, and decrypts the
    anonymized records.
    """
    print("\n── AnalysisAgent (receive batch) ────────────────────────────────────")

    master     = bytes.fromhex(
        "9f8e7d6c5b4a392817263504f3e2d1c0"
        "b0a192837465574839201fedcba98765"
    )
    deployment = b"hospital-prod-eu"
    root_pk    = derive_public_key(make_identity(master, deployment, b"compliance-root"))

    msg1     = receive_message()
    metadata = msg1.metadata or {}
    batch_id = metadata["batchId"].encode()

    auth_wire, offer_blob = unpack_metadata(metadata)

    n = verify_auth(root_pk=root_pk, wire=auth_wire)
    print(f"  Sender chain verified: {n} hop(s)")

    sender_cred    = decode_chain(auth_wire)[0]
    sender_payload = parse_payload(sender_cred)
    sender_perms   = [(r.decode(), v.decode()) for r, v in sender_payload["perms"]]
    print(f"  Sender permissions: {sender_perms}")

    if ("data/raw/", "GET") in sender_perms:
        print("  Provenance confirmed: sender held data/raw/ READ — authorised anonymizer")
    else:
        raise ValueError("sender was not authorised to read raw data — cannot trust anonymization")

    analysis_kem_seed = sha256(master + b"kem:analysis-agent").digest()
    analysis_endpoint = derive_endpoint(analysis_kem_seed)
    session = kem_accept(analysis_endpoint, offer_blob, context=batch_id)
    print(f"  KEM session established (batch {batch_id.decode()})")

    msg2 = receive_message()
    blob = bytes.fromhex((msg2.metadata or {})["x-qhermes-payload"])

    plaintext   = open_blob(session, blob, aad=batch_id)
    anon_record = json.loads(plaintext)

    print(f"\n  Decrypted anonymized record:")
    for k, v in anon_record.items():
        print(f"    {k}: {v}")
    print(f"\n  Running cohort analysis... COMPLETE (report written to reports/cohort-20260316.pdf)")

    our_wire  = bytes.fromhex(_AGENT_CARDS["__chains__"]["analysis"])
    our_cred  = decode_chain(our_wire)[0]
    our_perms = [(r.decode(), v.decode()) for r, v in parse_payload(our_cred)["perms"]]

    print(f"\n  Own permissions: {our_perms}")
    if not any(r == "data/raw/" for r, _ in our_perms):
        print("  CONFIRMED: data/raw/ is absent from AnalysisAgent scope — raw data unreachable")


def run_compliance_snapshot() -> None:
    """
    Compliance snapshot: print which credentials are valid right now and what
    permissions each agent holds — for GDPR auditors.
    """
    print("\n── AuditAgent (GDPR compliance snapshot) ────────────────────────────")

    master     = bytes.fromhex(
        "9f8e7d6c5b4a392817263504f3e2d1c0"
        "b0a192837465574839201fedcba98765"
    )
    deployment = b"hospital-prod-eu"
    root_pk    = derive_public_key(make_identity(master, deployment, b"compliance-root"))

    audit_wire = bytes.fromhex(_AGENT_CARDS["__chains__"]["audit"])
    verify_auth(root_pk=root_pk, wire=audit_wire)
    print("  AuditAgent own credential valid — snapshot is authoritative\n")

    now = int(time.time())
    print(f"  Snapshot timestamp: {now} (Unix epoch)")
    print(f"  {'Agent':<22} {'Valid':<6} {'TTL (s)':<12} Permissions")
    print(f"  {'-'*22} {'-'*6} {'-'*12} {'-'*40}")

    agent_labels = {
        "ingestion":     "IngestionAgent",
        "anonymization": "AnonymizationAgent",
        "analysis":      "AnalysisAgent",
        "audit":         "AuditAgent",
    }

    chains = _AGENT_CARDS["__chains__"]
    for key, label in agent_labels.items():
        wire  = bytes.fromhex(chains[key])
        cred  = decode_chain(wire)[0]
        valid = credential_valid_at(cred, ts=now)
        p     = parse_payload(cred)
        perms = [f"{r.decode()} {v.decode()}" for r, v in p["perms"]]
        ttl   = (p["not_after"] - now) if p["not_after"] else "unlimited"
        print(f"  {label:<22} {str(valid):<6} {str(ttl):<12} {perms}")

    print(f"\n  One-way data-flow enforcement summary:")
    print(f"    data/raw/  READ   → AnonymizationAgent only")
    print(f"    data/raw/  WRITE  → IngestionAgent only")
    print(f"    data/anon/ READ   → AnonymizationAgent + AnalysisAgent + AuditAgent")
    print(f"    data/anon/ WRITE  → AnonymizationAgent only")
    print(f"    AnalysisAgent     → cannot access data/raw/ (verified above)")


# ── Main ──────────────────────────────────────────────────────────────────────

print("=" * 70)
print("QHermes A2A — Healthcare Patient Data Pipeline")
print("=" * 70)

run_analysis_agent_setup()
run_compliance_root()
run_ingestion_agent()
run_anonymization_agent()
run_analysis_agent()
run_compliance_snapshot()

print("\n" + "=" * 70)
print("Pipeline complete.")
print("=" * 70)
