# Copyright (c) 2026 Copertino All rights reserved.
# SPDX-License-Identifier: LicenseRef-Copertino-1.0
#
# Example: basic delegation chain
#
# A root identity issues a credential to an agent. The agent uses it to
# authorize an operation. The verifier checks the chain and executes.
# No multi-hop delegation, no attack scenarios — just the happy path.
#
# Run it:
#   pip install qhermes-kernel qhermes-a2a
#   python examples/delegation_basic.py

from __future__ import annotations

import os

from qhermes.kernel import (
    make_identity,
    make_policy,
    derive_public_key,
    issue_credential,
    build_chain,
    verify_chain,
    decode_chain,
    explain_credential,
    parse_payload,
)
from qhermes.a2a import seal_auth, verify_auth


def main() -> None:
    # ── Root identity ─────────────────────────────────────────────────────────
    # The root holds the master seed. In production this lives in a secret store
    # or HSM — never in source code. Here we use os.urandom for the demo.

    master = os.urandom(32)

    root = make_identity(master, deployment=b"prod", context=b"root")
    root_pk = derive_public_key(root)

    print(f"root PK: {root_pk.hex()[:32]}...")

    # ── Agent identity ────────────────────────────────────────────────────────
    # The agent derives its own identity under the same master. In practice the
    # agent would generate its own keypair and send only the public key to the
    # root for credential issuance.

    agent = make_identity(master, deployment=b"prod", context=b"agent-0")
    agent_pk = derive_public_key(agent)

    print(f"agent PK: {agent_pk.hex()[:32]}...")

    # ── Issue credential ──────────────────────────────────────────────────────
    # Root grants the agent read access to /data for the next hour.

    policy = make_policy(
        resources=[b"/data"],
        actions=[b"read"],
        hours_valid=1,
    )

    cred = issue_credential(
        identity=root,
        child_pk=agent_pk,
        policy=policy,
        depth=1,
        role="leaf",
    )

    print(f"\ncredential issued: {explain_credential(cred)}")

    # ── Build wire ────────────────────────────────────────────────────────────

    wire = build_chain((cred,))
    print(f"wire size: {len(wire)} bytes")

    # ── Verify ────────────────────────────────────────────────────────────────
    # Any party with root_pk can verify the chain locally. No server call.

    n = verify_chain(root_pk=root_pk, wire=wire)
    print(f"\nchain verified: {n} credential(s)")

    for c in decode_chain(wire):
        p = parse_payload(c)
        print(f"  role={p['role']} depth={p['depth']}")
        for resource, verb in p["perms"]:
            print(f"  allow({resource.decode()!r}, {verb.decode()!r})")
        if p["not_after"]:
            print(f"  expires at {p['not_after']} (unix seconds)")

    # ── A2A authorization blob ────────────────────────────────────────────────
    # seal_auth and verify_auth wrap the same chain for embedding in A2A messages.

    auth_blob = seal_auth([cred])
    count = verify_auth(root_pk=root_pk, wire=auth_blob)
    print(f"\nA2A auth blob: {len(auth_blob)} bytes, {count} credential(s) verified")


if __name__ == "__main__":
    main()
