# Copyright (c) 2026 Copertino All rights reserved.
# SPDX-License-Identifier: LicenseRef-Copertino-1.0
#
# Example: AI coding agent with sub-agent delegation
#
# Scenario
# --------
# An AI orchestrator receives a task: "add input validation to the API handler".
# Instead of running with broad permissions, it spawns narrow sub-agents:
#
#   Orchestrator  — root of trust; breaks the task into sub-tasks; never touches files
#   ReaderAgent   — reads src/api/handler.py to understand the current code
#   WriterAgent   — writes the modified src/api/handler.py
#   TestAgent     — reads and writes tests/test_handler.py only
#
# Each sub-agent gets a credential scoped to exactly one file and one operation.
# The Executor enforces this at the crypto layer — not with a runtime sandbox.
#
# Key properties
# --------------
# - Least privilege per sub-task: ReaderAgent cannot write; WriterAgent cannot
#   read tests/; TestAgent cannot touch src/.
# - Operations are encrypted in transit and bound to the operation ID as AAD.
# - Verification happens before execution — the Executor never sees a file path
#   until the chain is valid.
# - No data is moved between agents. Each agent operates on its own slice.
#
# Run it:
#   pip install qhermes-kernel qhermes-a2a a2a-sdk
#   python examples/code_agent_sandbox.py

from __future__ import annotations

import json
from hashlib import sha256

from a2a.types import (
    AgentCapabilities,
    AgentCard,
    AgentSkill,
    Message,
    Part,
    Role,
    TextPart,
)

from qhermes.kernel import (
    make_identity,
    make_policy,
    derive_public_key,
    issue_credential,
    build_chain,
    decode_chain,
    explain_credential,
    parse_payload,
)
from qhermes.a2a import (
    Session,
    derive_endpoint,
    kem_offer,
    kem_accept,
    seal,
    open_blob,
    agent_card_security_extension,
    extract_agent_card_ek,
    verify_auth,
    pack_metadata,
    unpack_metadata,
)


# ── Simulated network ─────────────────────────────────────────────────────────
#
# In production each agent publishes its Agent Card at
#   https://<host>/.well-known/agent.json
# and messages travel over HTTPS + JSON-RPC 2.0.

_AGENT_CARDS:      dict[str, AgentCard] = {}
_AGENT_EXTENSIONS: dict[str, dict]     = {}
_MESSAGES:         list[Message]       = []


def publish_card(name: str, card: AgentCard, extensions: dict) -> None:
    _AGENT_CARDS[name]      = card
    _AGENT_EXTENSIONS[name] = extensions


def discover_extensions(name: str) -> dict:
    return _AGENT_EXTENSIONS[name]


def send_message(msg: Message) -> None:
    _MESSAGES.append(msg)


def receive_message() -> Message:
    return _MESSAGES.pop(0)


# ── Executor ──────────────────────────────────────────────────────────────────

def execute_file_operation(root_pk: bytes, wire_auth: bytes, op: dict) -> None:
    """
    Security boundary between sub-agents and the filesystem.

    Order is deliberate:
      1. Verify the chain — bail out before touching anything if invalid.
      2. Check the specific (path, verb) is in scope — not just that the chain
         is valid, but that this exact operation was granted.
      3. Execute (simulated here with a print).

    The Executor never sees the path until after step 1 passes. The path and
    verb arrive encrypted; decryption happens in the caller before this call,
    but only after the KEM accept succeeds — which requires the private key
    that only the Executor holds.
    """
    path   = op["path"]
    verb   = op["verb"]
    path_b = path.encode()
    verb_b = verb.encode()

    n         = verify_auth(root_pk=root_pk, wire=wire_auth)
    last_cred = decode_chain(wire_auth)[-1]
    granted   = [(r, v) for r, v in parse_payload(last_cred)["perms"]]

    if (path_b, verb_b) not in granted:
        raise ValueError(
            f"credential does not grant {verb} {path} — "
            f"granted: {[(r.decode(), v.decode()) for r, v in granted]}"
        )

    print(f"  [executor] ALLOWED {verb} {path}  ({n} hop(s))")


# ── Orchestrator ──────────────────────────────────────────────────────────────

def run_orchestrator() -> None:
    """
    Orchestrator receives the task, derives sub-agent identities, and issues
    one narrow credential per sub-agent per file.

    It never touches the filesystem itself. Its job is to decompose the task
    and distribute the minimum necessary authority to each sub-agent.
    """
    print("\n── Orchestrator ─────────────────────────────────────────────────────")

    master     = bytes.fromhex(
        "c4d5e6f7081929304a5b6c7d8e9f0a1b"
        "2c3d4e5f6071829384a5b6c7d8e9f0a1"
    )
    deployment = b"acme-prod"

    root_id       = make_identity(master, deployment, b"orchestrator")
    root_pk       = derive_public_key(root_id)
    root_kem_seed = sha256(master + b"kem:orchestrator").digest()
    root_endpoint = derive_endpoint(root_kem_seed)

    print(f"  root PK: {root_pk.hex()[:32]}...")

    ext  = agent_card_security_extension(root_pk, root_endpoint)
    card = AgentCard(
        capabilities    = AgentCapabilities(streaming=False, pushNotifications=False),
        defaultInputModes  = ["text/plain"],
        defaultOutputModes = ["text/plain"],
        description = "Orchestrates sub-agents for code modification tasks",
        name        = "Orchestrator",
        url         = "https://agents.acme.internal/orchestrator/.well-known/agent.json",
        version     = "1.0.0",
        skills      = [AgentSkill(id="run-task", name="Run task", description="Decompose and delegate a coding task.", tags=["coding"])],
    )
    publish_card("Orchestrator", card, ext)

    reader_pk = derive_public_key(make_identity(master, deployment, b"reader-agent"))
    writer_pk = derive_public_key(make_identity(master, deployment, b"writer-agent"))
    test_pk   = derive_public_key(make_identity(master, deployment, b"test-agent"))

    # One credential per sub-agent, scoped to exactly the file it needs.
    # No sub-agent can read or write anything outside its signed scope.

    reader_cred = issue_credential(
        identity = root_id,
        child_pk = reader_pk,
        policy   = make_policy(resources=[b"src/api/handler.py"], actions=[b"GET"], hours_valid=1),
        depth    = 1,
        role     = "leaf",
    )
    writer_cred = issue_credential(
        identity = root_id,
        child_pk = writer_pk,
        policy   = make_policy(resources=[b"src/api/handler.py"], actions=[b"PUT"], hours_valid=1),
        depth    = 1,
        role     = "leaf",
    )
    test_cred = issue_credential(
        identity = root_id,
        child_pk = test_pk,
        policy   = make_policy(
            resources=[b"tests/test_handler.py"],
            actions=[b"GET", b"PUT"],
            hours_valid=1,
        ),
        depth = 1,
        role  = "leaf",
    )

    print(f"\n  [reader cred] {explain_credential(reader_cred)}")
    print(f"  [writer cred] {explain_credential(writer_cred)}")
    print(f"  [test cred]   {explain_credential(test_cred)}")

    _AGENT_CARDS["__chains__"] = {
        "reader": build_chain((reader_cred,)).hex(),
        "writer": build_chain((writer_cred,)).hex(),
        "test":   build_chain((test_cred,)).hex(),
    }


# ── Executor setup ────────────────────────────────────────────────────────────

def run_executor_setup() -> None:
    master     = bytes.fromhex(
        "c4d5e6f7081929304a5b6c7d8e9f0a1b"
        "2c3d4e5f6071829384a5b6c7d8e9f0a1"
    )
    deployment    = b"acme-prod"
    exec_id       = make_identity(master, deployment, b"executor")
    exec_pk       = derive_public_key(exec_id)
    exec_kem_seed = sha256(master + b"kem:executor").digest()
    exec_endpoint = derive_endpoint(exec_kem_seed)

    ext  = agent_card_security_extension(exec_pk, exec_endpoint)
    card = AgentCard(
        capabilities    = AgentCapabilities(streaming=False, pushNotifications=False),
        defaultInputModes  = ["text/plain"],
        defaultOutputModes = ["text/plain"],
        description = "Enforces credential scope before every filesystem operation",
        name        = "Executor",
        url         = "https://agents.acme.internal/executor/.well-known/agent.json",
        version     = "1.0.0",
        skills      = [AgentSkill(id="exec-fs-op", name="Execute filesystem operation", description="Execute a scoped filesystem operation.", tags=["fs"])],
    )
    publish_card("Executor", card, ext)


# ── Sub-agents ────────────────────────────────────────────────────────────────

def run_sub_agent(name: str, chain_key: str, op_path: str, op_verb: str, op_id: str) -> None:
    """
    Generic sub-agent body. Each sub-agent:
      1. Verifies its own credential before doing anything.
      2. Opens a fresh KEM session with the Executor, bound to this op_id.
      3. Sends the operation request encrypted — the Executor sees the path
         only after accepting the KEM offer with its private key.

    No data moves between sub-agents. Each operates independently.
    """
    master     = bytes.fromhex(
        "c4d5e6f7081929304a5b6c7d8e9f0a1b"
        "2c3d4e5f6071829384a5b6c7d8e9f0a1"
    )
    deployment = b"acme-prod"
    root_pk    = derive_public_key(make_identity(master, deployment, b"orchestrator"))
    wire_chain = bytes.fromhex(_AGENT_CARDS["__chains__"][chain_key])

    verify_auth(root_pk=root_pk, wire=wire_chain)

    _, executor_ek = extract_agent_card_ek({"extensions": discover_extensions("Executor")})
    op_id_b        = op_id.encode()
    offer_blob, session = kem_offer(peer_ek=executor_ek, context=op_id_b)

    op_bytes  = json.dumps({"path": op_path, "verb": op_verb}).encode()
    blob, _   = seal(session, op_bytes, aad=op_id_b)

    send_message(Message(
        messageId = f"msg-{op_id}",
        role      = Role.agent,
        parts     = [Part(root=TextPart(text=f"{name}: {op_verb} {op_path}"))],
        metadata  = pack_metadata(
            auth_wire  = wire_chain,
            offer_blob = offer_blob,
            extra      = {"operationId": op_id, "x-qhermes-op": blob.hex()},
        ),
    ))


# ── Executor receive loop ──────────────────────────────────────────────────────

def run_executor_receive_all() -> None:
    """
    Executor processes all pending operation requests.

    Order per message:
      1. Accept KEM — establishes session using Executor's private key.
      2. Decrypt — learns the path and verb only now.
      3. Verify chain + permission — raises if anything is wrong.
      4. Execute — only reached if all checks pass.
    """
    print("\n── Executor (processing requests) ───────────────────────────────────")

    master     = bytes.fromhex(
        "c4d5e6f7081929304a5b6c7d8e9f0a1b"
        "2c3d4e5f6071829384a5b6c7d8e9f0a1"
    )
    deployment        = b"acme-prod"
    root_pk           = derive_public_key(make_identity(master, deployment, b"orchestrator"))
    exec_kem_seed     = sha256(master + b"kem:executor").digest()
    executor_endpoint = derive_endpoint(exec_kem_seed)

    while _MESSAGES:
        msg      = receive_message()
        metadata = msg.metadata or {}
        op_id    = metadata["operationId"].encode()

        auth_wire, offer_blob = unpack_metadata(metadata)
        op_blob               = bytes.fromhex(metadata["x-qhermes-op"])

        session   = kem_accept(executor_endpoint, offer_blob, context=op_id)
        plaintext = open_blob(session, op_blob, aad=op_id)
        op        = json.loads(plaintext)

        try:
            execute_file_operation(root_pk, auth_wire, op)
        except ValueError as exc:
            print(f"  [executor] DENIED — {exc}")


# ── Main ──────────────────────────────────────────────────────────────────────

print("=" * 70)
print("QHermes A2A — AI Coding Agent with Sub-agent Delegation")
print("=" * 70)

run_executor_setup()
run_orchestrator()

print("\n── Sub-agents (task: add input validation to API handler) ───────────")

# Each sub-agent runs with exactly the permissions it needs for its slice of
# the task. None of them can access the other's files.
run_sub_agent("ReaderAgent", "reader", "src/api/handler.py",      "GET", "op-read-handler")
run_sub_agent("WriterAgent", "writer", "src/api/handler.py",      "PUT", "op-write-handler")
run_sub_agent("TestAgent",   "test",   "tests/test_handler.py",   "GET", "op-read-test")
run_sub_agent("TestAgent",   "test",   "tests/test_handler.py",   "PUT", "op-write-test")

# Scope escalation: WriterAgent tries to write tests/ — not in its credential.
print("\n  [attack] WriterAgent attempts to write tests/test_handler.py...")
run_sub_agent("WriterAgent", "writer", "tests/test_handler.py", "PUT", "op-escalation")

run_executor_receive_all()

print("\n" + "=" * 70)
print("Sandbox demo complete.")
print("=" * 70)
