# Copyright (c) 2026 Copertino All rights reserved.
# SPDX-License-Identifier: LicenseRef-Copertino-1.0
#
# Example: Multi-agent financial approval pipeline
#
# Scenario
# --------
# A bank runs three AI agents that collaborate over A2A:
#
#   RiskOrchestrator  — root of trust; owns the master seed; never executes
#   ComplianceAgent   — checks transactions against regulatory rules
#   ExecutionAgent    — executes approved transfers
#
# Each agent is its own process.  This file simulates the three processes
# communicating over an in-memory "network" to keep the example self-contained.
#
# Run it:
#   pip install qhermes-kernel qhermes-a2a a2a-sdk
#   python examples/financial_approval.py

from __future__ import annotations

import json
import time
from hashlib import sha256

from a2a.types import (
    AgentCapabilities,
    AgentCard,
    AgentCardSignature,
    AgentSkill,
    Message,
    Part,
    Role,
    TextPart,
)

from qhermes.kernel import (
    make_identity,
    make_policy,
    derive_public_key,
    issue_credential,
    build_chain,
    decode_chain,
    explain_credential,
)
from qhermes.a2a import (
    Session,
    derive_endpoint,
    kem_offer,
    kem_accept,
    seal,
    open_blob,
    sign_agent_card,
    agent_card_security_extension,
    extract_agent_card_ek,
    verify_auth,
    pack_metadata,
    unpack_metadata,
)


# ── Simulated network ─────────────────────────────────────────────────────────
#
# In production each agent publishes its Agent Card at
#   https://<host>/.well-known/agent.json
# and messages travel over HTTPS + JSON-RPC 2.0.
# Here we use an in-memory store as "the network".

_AGENT_CARDS:      dict[str, AgentCard] = {}
_AGENT_EXTENSIONS: dict[str, dict]     = {}   # qhermes security extension per agent
_MESSAGES:         list[Message]       = []


def publish_card(name: str, card: AgentCard, extensions: dict) -> None:
    _AGENT_CARDS[name]      = card
    _AGENT_EXTENSIONS[name] = extensions


def discover_card(name: str) -> AgentCard:
    return _AGENT_CARDS[name]


def discover_extensions(name: str) -> dict:
    return _AGENT_EXTENSIONS[name]


def send_message(msg: Message) -> None:
    _MESSAGES.append(msg)


def receive_message() -> Message:
    return _MESSAGES.pop(0)


def _jcs(obj: dict) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


# ── Agent processes ───────────────────────────────────────────────────────────

def run_risk_orchestrator() -> None:
    """
    RiskOrchestrator boots once, derives identities and a KEM endpoint from its
    master seed, publishes its Agent Card, and pre-issues the credential chain.

    The master seed lives in a hardware security module (HSM).  Nothing else
    touches it.  All derived keys are independent: compromising one context key
    does not expose the others or the master.
    """
    print("\n── RiskOrchestrator ─────────────────────────────────────────────────")

    master = bytes.fromhex(
        "b1c2d3e4f5061728394a5b6c7d8e9f00"
        "a1b2c3d4e5f6071829304a5b6c7d8e9f"
    )
    deployment = b"bank-prod-eu"

    root_id       = make_identity(master, deployment, b"risk-orchestrator")
    root_pk       = derive_public_key(root_id)
    root_kem_seed = sha256(master + b"kem:risk-orchestrator").digest()
    root_endpoint = derive_endpoint(root_kem_seed)

    print(f"  root PK:  {root_pk.hex()[:32]}...")
    print(f"  root EK:  {root_endpoint.encapsulation_key.hex()[:32]}...")

    ext      = agent_card_security_extension(root_pk, root_endpoint)
    raw_card = {
        "capabilities": {"streaming": False, "pushNotifications": False},
        "defaultInputModes":  ["text/plain"],
        "defaultOutputModes": ["text/plain"],
        "description": "Root authority for bank transaction approval pipeline",
        "name":    "RiskOrchestrator",
        "url":     "https://risk.bank.internal/.well-known/agent.json",
        "version": "1.0.0",
        "skills":  [{"id": "approve-transfer", "name": "Approve wire transfer", "description": "Approve a wire transfer request.", "tags": ["finance"]}],
        "extensions": ext,
    }
    card_bytes = _jcs(raw_card)
    sig_bytes  = sign_agent_card(master, deployment, b"risk-orchestrator", card_bytes)

    card = AgentCard(
        capabilities=AgentCapabilities(streaming=False, pushNotifications=False),
        defaultInputModes=["text/plain"],
        defaultOutputModes=["text/plain"],
        description=raw_card["description"],
        name=raw_card["name"],
        url=raw_card["url"],
        version=raw_card["version"],
        skills=[AgentSkill(id="approve-transfer", name="Approve wire transfer", description="Approve a wire transfer request.", tags=["finance"])],
        signatures=[AgentCardSignature(
            protected="eyJhbGciOiJNTC1EU0EtNjUifQ",  # {"alg":"ML-DSA-65"} base64url
            signature=sig_bytes.hex(),
        )],
    )
    publish_card("RiskOrchestrator", card, ext)
    print("  Agent Card published at /.well-known/agent.json")

    compliance_pk = derive_public_key(make_identity(master, deployment, b"compliance-agent"))
    execution_pk  = derive_public_key(make_identity(master, deployment, b"execution-agent"))

    compliance_policy = make_policy(
        resources=[b"/transfers/check", b"/transfers/approve"],
        actions=[b"POST"],
        hours_valid=1,
    )
    root_to_compliance = issue_credential(
        identity = root_id,
        child_pk = compliance_pk,
        policy   = compliance_policy,
        depth    = 1,
        role     = "node",
    )
    print(f"\n  [cred 1] {explain_credential(root_to_compliance)}")

    compliance_id    = make_identity(master, deployment, b"compliance-agent")
    execution_policy = make_policy(
        resources=[b"/transfers/approve"],
        actions=[b"POST"],
        minutes_valid=5,
    )
    compliance_to_execution = issue_credential(
        identity = compliance_id,
        child_pk = execution_pk,
        policy   = execution_policy,
        depth    = 2,
        role     = "leaf",
    )
    print(f"  [cred 2] {explain_credential(compliance_to_execution)}")

    chain      = (root_to_compliance, compliance_to_execution)
    wire_chain = build_chain(chain)
    print(f"\n  Chain wire-encoded: {len(wire_chain)} bytes")

    _AGENT_CARDS["__wire_chain__"] = {"wire": wire_chain.hex()}


def run_execution_agent() -> None:
    """
    ExecutionAgent builds an A2A message addressed to PaymentGateway.

    It attaches:
      - The credential chain (proves it is authorised back to the root)
      - A KEM offer (proposes an encrypted session bound to this specific task)
    """
    print("\n── ExecutionAgent ───────────────────────────────────────────────────")

    master = bytes.fromhex(
        "b1c2d3e4f5061728394a5b6c7d8e9f00"
        "a1b2c3d4e5f6071829304a5b6c7d8e9f"
    )

    _, gateway_ek = extract_agent_card_ek({"extensions": discover_extensions("PaymentGateway")})
    print(f"  PaymentGateway EK: {gateway_ek.hex()[:32]}...")

    wire_chain = bytes.fromhex(_AGENT_CARDS["__wire_chain__"]["wire"])

    task_id = b"task-transfer-9182736450"
    offer_blob, initiator_session = kem_offer(
        peer_ek = gateway_ek,
        context = task_id,
    )

    metadata = pack_metadata(
        auth_wire  = wire_chain,
        offer_blob = offer_blob,
        extra      = {"taskId": task_id.decode(), "priority": "high"},
    )

    msg = Message(
        messageId = "msg-0001",
        role      = Role.agent,
        parts     = [Part(root=TextPart(text="Requesting approval for wire transfer T-9182736450"))],
        metadata  = metadata,
    )
    send_message(msg)
    print(f"  Message sent ({len(msg.model_dump_json())} bytes JSON)")
    print(f"  KEM offer embedded in metadata ({len(offer_blob)} bytes)")

    _AGENT_CARDS["__initiator_session__"] = {
        "session": initiator_session,
        "task_id": task_id,
    }


def run_payment_gateway_receive() -> tuple[Session, bytes]:
    """
    PaymentGateway receives the A2A message, verifies the credential chain,
    accepts the KEM handshake, and returns the established session.
    """
    print("\n── PaymentGateway (receive) ──────────────────────────────────────────")

    master     = bytes.fromhex(
        "b1c2d3e4f5061728394a5b6c7d8e9f00"
        "a1b2c3d4e5f6071829304a5b6c7d8e9f"
    )
    deployment = b"bank-prod-eu"

    root_pk = derive_public_key(make_identity(master, deployment, b"risk-orchestrator"))

    msg      = receive_message()
    metadata = msg.metadata or {}
    task_id  = metadata["taskId"].encode()

    auth_wire, offer_blob = unpack_metadata(metadata)

    n = verify_auth(root_pk=root_pk, wire=auth_wire, now=int(time.time()))
    print(f"  Chain verified: {n} credential(s) anchored at RiskOrchestrator")

    for i, cred in enumerate(decode_chain(auth_wire)):
        print(f"    [{i+1}] {explain_credential(cred)}")

    gw_kem_seed      = sha256(master + b"kem:payment-gateway").digest()
    gateway_endpoint = derive_endpoint(gw_kem_seed)
    session = kem_accept(gateway_endpoint, offer_blob, context=task_id)
    print(f"\n  KEM session established (bound to task {task_id.decode()})")

    return session, task_id


def run_execution_agent_send_order(responder_session: Session, task_id: bytes) -> None:
    """
    ExecutionAgent sends the actual transfer order over the encrypted channel.
    """
    print("\n── ExecutionAgent (send encrypted order) ────────────────────────────")

    stored             = _AGENT_CARDS["__initiator_session__"]
    initiator_session: Session = stored["session"]

    transfer_order = json.dumps({
        "from":      "ACC-DE-001",
        "to":        "ACC-FR-007",
        "amount":    2_500_000,
        "currency":  "EUR",
        "reference": "INV-2026-Q1-0042",
    }).encode()

    blob, next_session = seal(initiator_session, transfer_order, aad=task_id)
    print(f"  Order sealed: {len(blob)} bytes (12-byte nonce + ciphertext + 16-byte tag)")

    send_message(Message(
        messageId = "msg-0002",
        role      = Role.agent,
        parts     = [],
        metadata  = {"taskId": task_id.decode(), "x-qhermes-payload": blob.hex()},
    ))

    _AGENT_CARDS["__initiator_session__"]["session"] = next_session
    print("  Nonce counter advanced to 1 — old session reference discarded")


def run_payment_gateway_process(session: Session, task_id: bytes) -> None:
    """
    PaymentGateway decrypts the transfer order and processes it.
    """
    print("\n── PaymentGateway (process order) ───────────────────────────────────")

    msg  = receive_message()
    blob = bytes.fromhex((msg.metadata or {})["x-qhermes-payload"])

    plaintext = open_blob(session, blob, aad=task_id)
    order     = json.loads(plaintext)

    print(f"  Transfer order decrypted and authenticated:")
    print(f"    From:      {order['from']}")
    print(f"    To:        {order['to']}")
    print(f"    Amount:    {order['amount']:,} {order['currency']}")
    print(f"    Reference: {order['reference']}")
    print(f"\n  Processing transfer... APPROVED")


def run_payment_gateway_setup() -> None:
    """Publish PaymentGateway's Agent Card before ExecutionAgent discovers it."""
    master     = bytes.fromhex(
        "b1c2d3e4f5061728394a5b6c7d8e9f00"
        "a1b2c3d4e5f6071829304a5b6c7d8e9f"
    )
    deployment = b"bank-prod-eu"
    gw_id       = make_identity(master, deployment, b"payment-gateway")
    gw_pk       = derive_public_key(gw_id)
    gw_kem_seed = sha256(master + b"kem:payment-gateway").digest()
    gw_endpoint = derive_endpoint(gw_kem_seed)

    ext  = agent_card_security_extension(gw_pk, gw_endpoint)
    card = AgentCard(
        capabilities=AgentCapabilities(streaming=False, pushNotifications=False),
        defaultInputModes=["text/plain"],
        defaultOutputModes=["text/plain"],
        description="Executes approved wire transfers",
        name="PaymentGateway",
        url="https://payments.bank.internal/.well-known/agent.json",
        version="1.0.0",
        skills=[AgentSkill(id="execute-transfer", name="Execute wire transfer", description="Execute an approved wire transfer.", tags=["finance"])],
    )
    publish_card("PaymentGateway", card, ext)


# ── Main ──────────────────────────────────────────────────────────────────────

print("=" * 70)
print("QHermes A2A — Financial Approval Pipeline")
print("=" * 70)

run_payment_gateway_setup()
run_risk_orchestrator()
run_execution_agent()
session, task_id = run_payment_gateway_receive()
run_execution_agent_send_order(session, task_id)
run_payment_gateway_process(session, task_id)

print("\n" + "=" * 70)
print("Pipeline complete.")
print("=" * 70)
