# Copyright (c) 2026 Copertino All rights reserved.
# SPDX-License-Identifier: LicenseRef-Copertino-1.0
#
# Example: QHermes + a2a-sdk integration
#
# Shows how qhermes plugs into the real A2A protocol:
#
#   1. Root operator signs an AgentCard with ML-DSA-65.
#   2. The AgentCard carries the qhermes security extension
#      (root public key + ML-KEM-768 encapsulation key).
#   3. A caller fetches the card, verifies the signature,
#      extracts the KEM key, and sends an authorized task request.
#   4. The agent verifies the credential chain from message.metadata
#      before processing the task.
#
# Requires:
#   pip install a2a-sdk
#   maturin develop  (in qhermes-kernel-py and qhermes-a2a-py)
#
# Run:
#   python examples/a2a_sdk_integration.py

from __future__ import annotations

import base64
import json
import os

from a2a.types import (
    AgentCapabilities,
    AgentCard,
    AgentCardSignature,
    AgentSkill,
    Message,
    Part,
    Role,
    TextPart,
)

from qhermes.kernel import (
    make_identity,
    make_policy,
    derive_public_key,
    issue_credential,
    build_chain,
    explain_credential,
)
from qhermes.a2a import (
    derive_endpoint,
    sign_agent_card,
    verify_agent_card,
    agent_card_security_extension,
    extract_agent_card_ek,
    kem_offer,
    kem_accept,
    seal,
    open_blob,
    seal_auth,
    verify_auth,
    pack_metadata,
    unpack_metadata,
)


# ── Helpers ───────────────────────────────────────────────────────────────────

def jcs(obj: dict) -> bytes:
    """Minimal JCS: sort keys, no extra whitespace."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


# ── Setup: root operator ───────────────────────────────────────────────────────

master = os.urandom(32)

root     = make_identity(master, b"prod", b"root")
root_pk  = derive_public_key(root)

agent    = make_identity(master, b"prod", b"summarizer-agent")
agent_pk = derive_public_key(agent)

# KEM endpoint for the agent (published in AgentCard so callers can encrypt to it)
agent_endpoint = derive_endpoint(
    derive_public_key(make_identity(master, b"prod", b"summarizer-agent-kem"))[:32]
)

print("=== Setup ===")
print(f"root PK:  {root_pk.hex()[:24]}...")
print(f"agent PK: {agent_pk.hex()[:24]}...")


# ── Step 1: build and sign the AgentCard ──────────────────────────────────────

raw_card: dict = {
    "capabilities": {"streaming": False, "pushNotifications": False},
    "defaultInputModes":  ["text/plain"],
    "defaultOutputModes": ["text/plain"],
    "description": "Summarizes documents. Secured with QHermes post-quantum auth.",
    "name":    "summarizer-agent",
    "url":     "https://agents.example.com/summarizer",
    "version": "1.0.0",
    "skills": [{"id": "summarize", "name": "Summarize", "description": "Summarize a document.", "tags": ["summarize"]}],
    "extensions": {
        **agent_card_security_extension(root_pk, agent_endpoint),
    },
}

# Sign over the canonical form (signature field absent during signing)
card_bytes = jcs(raw_card)
sig_bytes  = sign_agent_card(master, b"prod", b"root", card_bytes)
sig_b64    = base64.urlsafe_b64encode(sig_bytes).decode()

# Attach signature in the AgentCard signatures field (JWS-like header)
signed_card = AgentCard(
    capabilities=AgentCapabilities(streaming=False, pushNotifications=False),
    defaultInputModes=["text/plain"],
    defaultOutputModes=["text/plain"],
    description=raw_card["description"],
    name=raw_card["name"],
    url=raw_card["url"],
    version=raw_card["version"],
    skills=[AgentSkill(id="summarize", name="Summarize", description="Summarize a document.", tags=["summarize"])],
    signatures=[AgentCardSignature(
        protected=base64.urlsafe_b64encode(json.dumps({"alg": "ML-DSA-65"}, separators=(",", ":")).encode()).decode(),
        signature=sig_b64,
    )],
)

print("\n=== AgentCard ===")
print(f"name:      {signed_card.name}")
print(f"url:       {signed_card.url}")
print(f"signature: {sig_b64[:32]}...")


# ── Step 2: caller fetches and verifies the AgentCard ─────────────────────────

# In production: fetched from agent_url + /.well-known/agent.json
# Here we pass it in-process.

verify_agent_card(root_pk=root_pk, card_bytes=card_bytes, sig=sig_bytes)
print("\n=== AgentCard verified ✓ ===")

caller_root_pk, peer_ek = extract_agent_card_ek(raw_card)
assert caller_root_pk == root_pk
print(f"extracted EK: {peer_ek.hex()[:24]}...")


# ── Step 3: root issues a credential to the caller ────────────────────────────

caller    = make_identity(master, b"prod", b"caller-agent")
caller_pk = derive_public_key(caller)

policy = make_policy(
    resources=[b"/summarize"],
    actions=[b"invoke"],
    hours_valid=1,
)
cred  = issue_credential(identity=root, child_pk=caller_pk, policy=policy, depth=1, role="leaf")
chain = (cred,)
wire  = build_chain(chain)

print(f"\n=== Credential issued ===")
print(f"  {explain_credential(cred)}")


# ── Step 4: caller sends an authorized task request ───────────────────────────

task_id   = b"task-summarize-001"
auth_blob = seal_auth(list(chain))

offer_blob, initiator_session = kem_offer(peer_ek=peer_ek, context=task_id)

plaintext = b"Quantum computing threatens RSA. Post-quantum standards finalized by NIST."
encrypted, _ = seal(initiator_session, plaintext, aad=task_id)

metadata = pack_metadata(
    auth_wire=auth_blob,
    offer_blob=offer_blob,
    extra={"taskId": task_id.decode(), "payload": encrypted.hex()},
)

# Wrap in an a2a-sdk Message
message = Message(
    messageId="msg-001",
    role=Role.user,
    parts=[Part(root=TextPart(text="Please summarize the attached document."))],
    metadata=metadata,
)

print(f"\n=== Message sent ===")
print(f"metadata keys: {list(message.metadata.keys())}")
print(f"plaintext:  {len(plaintext)} bytes  →  encrypted: {len(encrypted)} bytes")


# ── Step 5: agent receives, verifies, decrypts, responds ──────────────────────

recv_metadata = message.metadata or {}
auth_wire, offer = unpack_metadata(recv_metadata)

n = verify_auth(root_pk=root_pk, wire=auth_wire)
print(f"\n=== Agent side ===")
print(f"chain verified: {n} credential(s)")

agent_session = kem_accept(agent_endpoint, offer=offer, context=task_id)
decrypted = open_blob(agent_session, bytes.fromhex(recv_metadata["payload"]), aad=task_id)
print(f"decrypted: {decrypted.decode()}")

# Agent responds using a2a-sdk Message
response = Message(
    messageId="msg-002",
    role=Role.agent,
    parts=[Part(root=TextPart(text="Summary: Post-quantum cryptography replaces RSA using NIST-standardized algorithms."))],
)
print(f"\n=== Agent response ===")
print(f"{response.parts[0].root.text}")
print("\ndone.")
