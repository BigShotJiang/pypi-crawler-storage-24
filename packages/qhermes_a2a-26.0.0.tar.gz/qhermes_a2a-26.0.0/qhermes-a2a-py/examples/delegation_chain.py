# Copyright (c) 2026 Copertino All rights reserved.
# SPDX-License-Identifier: LicenseRef-Copertino-1.0
#
# Example: multi-hop delegation chain
#
# A root issues a credential to an orchestrator. The orchestrator sub-delegates
# a narrower scope to a worker. The worker presents its chain to a verifier,
# which checks every hop in a single pass and then acts on the request.
#
# The scope narrows at each hop:
#   root         — /pipeline/** read+write, node role (can delegate further)
#   orchestrator — /pipeline/jobs read+write, node role
#   worker       — /pipeline/jobs/build-42 write only, leaf role (cannot delegate)
#
# No attack scenarios. No adversarial inputs. Just the normal flow.
#
# Run it:
#   pip install qhermes-kernel qhermes-a2a
#   python examples/delegation_chain.py

from __future__ import annotations

import os

from qhermes.kernel import (
    make_identity,
    make_policy,
    derive_public_key,
    issue_credential,
    delegate,
    build_chain,
    verify_chain,
    decode_chain,
    explain_credential,
    parse_payload,
)
from qhermes.a2a import (
    derive_endpoint,
    kem_offer,
    kem_accept,
    seal,
    open_blob,
    seal_auth,
    verify_auth,
    pack_metadata,
    unpack_metadata,
)


def main() -> None:
    master = os.urandom(32)

    # ── Identities ────────────────────────────────────────────────────────────

    root         = make_identity(master, b"prod", b"root")
    orchestrator = make_identity(master, b"prod", b"orchestrator")
    worker       = make_identity(master, b"prod", b"worker-build-42")

    root_pk         = derive_public_key(root)
    orchestrator_pk = derive_public_key(orchestrator)
    worker_pk       = derive_public_key(worker)

    print(f"root PK:         {root_pk.hex()[:24]}...")
    print(f"orchestrator PK: {orchestrator_pk.hex()[:24]}...")
    print(f"worker PK:       {worker_pk.hex()[:24]}...")

    # ── KEM endpoints ─────────────────────────────────────────────────────────
    # Each participant has a KEM keypair derived from the same master seed.
    # The worker publishes its encapsulation key; the orchestrator uses it to
    # establish an encrypted session when sending the job assignment.

    worker_endpoint = derive_endpoint(derive_public_key(
        make_identity(master, b"prod", b"worker-build-42-kem")
    )[:32])

    # ── Credential issuance ───────────────────────────────────────────────────
    # Root grants the orchestrator broad pipeline access with node role so it
    # can sub-delegate to workers.

    root_policy = make_policy(
        resources=[b"/pipeline/**"],
        actions=[b"read", b"write"],
        hours_valid=8,
    )

    root_to_orch = issue_credential(
        identity=root,
        child_pk=orchestrator_pk,
        policy=root_policy,
        depth=1,
        role="node",
    )

    print(f"\n[hop 1] root -> orchestrator")
    print(f"  {explain_credential(root_to_orch)}")

    # ── Sub-delegation ────────────────────────────────────────────────────────
    # Orchestrator narrows the scope to /pipeline/jobs only and delegates to worker.
    # The worker gets leaf role — it cannot delegate further.

    orch_policy = make_policy(
        resources=[b"/pipeline/**"],
        actions=[b"read", b"write"],
        hours_valid=2,
    )

    chain = delegate(
        identity=orchestrator,
        child_pk=worker_pk,
        policy=orch_policy,
        role="leaf",
        parent_chain=(root_to_orch,),
    )

    print(f"\n[hop 2] orchestrator -> worker")
    print(f"  {explain_credential(chain[-1])}")

    # ── Wire encoding ─────────────────────────────────────────────────────────

    wire = build_chain(chain)
    print(f"\nwire: {len(wire)} bytes, {len(chain)} credential(s)")

    # ── Verification ──────────────────────────────────────────────────────────
    # The verifier has only root_pk. It checks the full chain in one pass:
    # signatures, depth sequence, scope subset at each hop, and time caveats.

    n = verify_chain(root_pk=root_pk, wire=wire)
    print(f"\nchain verified: {n} hop(s)")

    for i, cred in enumerate(decode_chain(wire)):
        p = parse_payload(cred)
        perms = [(r.decode(), v.decode()) for r, v in p["perms"]]
        print(f"  [{i+1}] role={p['role']} depth={p['depth']} perms={perms}")

    # ── A2A message exchange ──────────────────────────────────────────────────
    # Orchestrator sends the worker a job assignment over a KEM session.
    # The credential chain travels in message.metadata alongside the KEM offer.
    # The worker verifies the chain before reading the job payload.

    print("\n── A2A message exchange ─────────────────────────────────────────────")

    task_id    = b"task-build-42"
    auth_blob  = seal_auth(list(chain))
    offer_blob, initiator_session = kem_offer(
        peer_ek=worker_endpoint.encapsulation_key,
        context=task_id,
    )

    job_payload = b'{"job": "build", "ref": "main", "target": "/pipeline/jobs/build-42"}'
    encrypted, _ = seal(initiator_session, job_payload, aad=task_id)

    metadata = pack_metadata(
        auth_wire=auth_blob,
        offer_blob=offer_blob,
        extra={"taskId": task_id.decode(), "payload": encrypted.hex()},
    )

    print(f"orchestrator sends: {len(job_payload)} bytes plaintext -> {len(encrypted)} bytes encrypted")
    print(f"metadata keys: {list(metadata.keys())}")

    # Worker side: verify chain, accept KEM, decrypt job
    auth_wire, offer = unpack_metadata(metadata)

    count = verify_auth(root_pk=root_pk, wire=auth_wire)
    print(f"\nworker verified chain: {count} hop(s)")

    worker_session = kem_accept(worker_endpoint, offer=offer, context=task_id)
    plaintext = open_blob(worker_session, bytes.fromhex(metadata["payload"]), aad=task_id)

    print(f"worker decrypted job: {plaintext.decode()}")
    print("\ndone.")


if __name__ == "__main__":
    main()
