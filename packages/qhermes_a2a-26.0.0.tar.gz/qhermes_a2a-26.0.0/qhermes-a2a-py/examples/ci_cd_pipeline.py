# Copyright (c) 2026 Copertino All rights reserved.
# SPDX-License-Identifier: LicenseRef-Copertino-1.0
#
# Example: CI/CD pipeline with AI agents
#
# Scenario
# --------
# A SaaS company runs AI agents in their CI/CD pipeline:
#
#   PipelineOrchestrator — root of trust; holds the master seed; issues all credentials
#   BuildAgent           — runs tests and builds artifacts; read source, write artifacts
#   StagingDeployAgent   — deploys to the staging environment only
#   ProdDeployAgent      — deploys to production; requires a short-lived credential (15 min)
#                          issued only after human approval is recorded
#   AuditAgent           — read-only across all environments, used for compliance logging
#
# Key security properties demonstrated
# -------------------------------------
# 1. Scope enforcement: a compromised BuildAgent cannot deploy to prod because its
#    credential only covers /artifacts/write — any attempt to forge a prod-deploy
#    credential fails chain verification since it would not be a subset of the parent.
# 2. Expiry: the ProdDeployAgent credential is valid for 15 minutes only.
#    After that window, verify_auth raises ValueError.
# 3. Pre-operation verification: every agent verifies the incoming credential chain
#    before executing any operation.
# 4. Encrypted communication: agents exchange operation payloads over a KEM session.
#
# Run it:
#   pip install qhermes-kernel qhermes-a2a a2a-sdk
#   python examples/ci_cd_pipeline.py

from __future__ import annotations

import json
import time
from hashlib import sha256

from a2a.types import (
    AgentCapabilities,
    AgentCard,
    AgentSkill,
    Message,
    Part,
    Role,
    TextPart,
)

from qhermes.kernel import (
    make_identity,
    make_policy,
    derive_public_key,
    issue_credential,
    build_chain,
    decode_chain,
    explain_credential,
    credential_valid_at,
    parse_payload,
)
from qhermes.a2a import (
    Session,
    derive_endpoint,
    kem_offer,
    kem_accept,
    seal,
    open_blob,
    agent_card_security_extension,
    extract_agent_card_ek,
    verify_auth,
    pack_metadata,
    unpack_metadata,
)


# ── Simulated network ─────────────────────────────────────────────────────────
#
# In production each agent publishes its Agent Card at
#   https://<host>/.well-known/agent.json
# and messages travel over HTTPS + JSON-RPC 2.0.
# Here we use an in-memory store as "the network".

_AGENT_CARDS:      dict[str, AgentCard] = {}
_AGENT_EXTENSIONS: dict[str, dict]     = {}
_MESSAGES:         list[Message]       = []


def publish_card(name: str, card: AgentCard, extensions: dict) -> None:
    _AGENT_CARDS[name]      = card
    _AGENT_EXTENSIONS[name] = extensions


def discover_extensions(name: str) -> dict:
    return _AGENT_EXTENSIONS[name]


def send_message(msg: Message) -> None:
    _MESSAGES.append(msg)


def receive_message() -> Message:
    return _MESSAGES.pop(0)


# ── Agent processes ───────────────────────────────────────────────────────────

def run_pipeline_orchestrator() -> None:
    """
    PipelineOrchestrator boots once per deployment, derives all identities from
    its master seed, publishes its Agent Card, and issues the credential chains
    for every downstream agent.

    Credential scope is deliberately narrow:
      - BuildAgent may only read source and write to the artifacts store.
        It has no permission over any deploy or environment path.
      - StagingDeployAgent may only deploy to the staging environment.
      - ProdDeployAgent receives a separate, short-lived credential valid for 15
        minutes — this window is opened only after a human approval event is
        recorded.  The tight expiry limits blast radius if the credential is stolen.
      - AuditAgent receives a read-only credential across all paths, valid for 24
        hours so it can cover an entire on-call shift.
    """
    print("\n── PipelineOrchestrator ─────────────────────────────────────────────")

    master = bytes.fromhex(
        "a3f1e2d4c5b6079819283a4b5c6d7e8f"
        "f0e1d2c3b4a5961728394a5b6c7d8e9f"
    )
    deployment = b"saas-cicd-prod"

    root_id       = make_identity(master, deployment, b"pipeline-orchestrator")
    root_pk       = derive_public_key(root_id)
    root_kem_seed = sha256(master + b"kem:pipeline-orchestrator").digest()
    root_endpoint = derive_endpoint(root_kem_seed)

    print(f"  root PK:  {root_pk.hex()[:32]}...")
    print(f"  root EK:  {root_endpoint.encapsulation_key.hex()[:32]}...")

    card = AgentCard(
        capabilities=AgentCapabilities(streaming=False, pushNotifications=False),
        defaultInputModes=["text/plain"],
        defaultOutputModes=["text/plain"],
        description="Root authority for the CI/CD agent pipeline",
        name="PipelineOrchestrator",
        url="https://ci.saas.internal/.well-known/agent.json",
        version="1.0.0",
        skills=[AgentSkill(id="issue-build-creds", name="Issue build credentials", description="Issue scoped credentials to CI/CD agents.", tags=["ci"])],
    )
    publish_card("PipelineOrchestrator", card, agent_card_security_extension(root_pk, root_endpoint))
    print("  Agent Card published at /.well-known/agent.json")

    build_pk          = derive_public_key(make_identity(master, deployment, b"build-agent"))
    staging_deploy_pk = derive_public_key(make_identity(master, deployment, b"staging-deploy-agent"))
    prod_deploy_pk    = derive_public_key(make_identity(master, deployment, b"prod-deploy-agent"))
    audit_pk          = derive_public_key(make_identity(master, deployment, b"audit-agent"))

    build_policy = make_policy(
        permissions=[
            (b"/source",    b"GET"),
            (b"/artifacts", b"PUT"),
        ],
        hours_valid=2,
    )
    root_to_build = issue_credential(
        identity = root_id,
        child_pk = build_pk,
        policy   = build_policy,
        depth    = 1,
        role     = "leaf",
    )
    print(f"\n  [build cred]   {explain_credential(root_to_build)}")

    staging_policy = make_policy(
        resources=[b"/deploy/staging"],
        actions=[b"POST"],
        hours_valid=2,
    )
    root_to_staging = issue_credential(
        identity = root_id,
        child_pk = staging_deploy_pk,
        policy   = staging_policy,
        depth    = 1,
        role     = "leaf",
    )
    print(f"  [staging cred] {explain_credential(root_to_staging)}")

    prod_policy = make_policy(
        resources=[b"/deploy/prod"],
        actions=[b"POST"],
        minutes_valid=15,
    )
    root_to_prod = issue_credential(
        identity = root_id,
        child_pk = prod_deploy_pk,
        policy   = prod_policy,
        depth    = 1,
        role     = "leaf",
    )
    print(f"  [prod cred]    {explain_credential(root_to_prod)}")

    audit_policy = make_policy(
        resources=[b"/source", b"/artifacts", b"/deploy/staging", b"/deploy/prod"],
        actions=[b"GET"],
        hours_valid=24,
    )
    root_to_audit = issue_credential(
        identity = root_id,
        child_pk = audit_pk,
        policy   = audit_policy,
        depth    = 1,
        role     = "leaf",
    )
    print(f"  [audit cred]   {explain_credential(root_to_audit)}")

    _AGENT_CARDS["__chains__"] = {
        "build":   build_chain((root_to_build,)).hex(),
        "staging": build_chain((root_to_staging,)).hex(),
        "prod":    build_chain((root_to_prod,)).hex(),
        "audit":   build_chain((root_to_audit,)).hex(),
    }

    print("\n  All credential chains issued and stored.")


def run_build_agent_setup() -> None:
    master     = bytes.fromhex(
        "a3f1e2d4c5b6079819283a4b5c6d7e8f"
        "f0e1d2c3b4a5961728394a5b6c7d8e9f"
    )
    deployment = b"saas-cicd-prod"
    build_id       = make_identity(master, deployment, b"build-agent")
    build_pk       = derive_public_key(build_id)
    build_kem_seed = sha256(master + b"kem:build-agent").digest()
    build_endpoint = derive_endpoint(build_kem_seed)
    card = AgentCard(
        capabilities=AgentCapabilities(streaming=False, pushNotifications=False),
        defaultInputModes=["text/plain"],
        defaultOutputModes=["text/plain"],
        description="Runs tests and produces build artifacts",
        name="BuildAgent",
        url="https://build.saas.internal/.well-known/agent.json",
        version="1.0.0",
        skills=[AgentSkill(id="run-build", name="Run CI build", description="Run the CI build and produce artifacts.", tags=["ci"])],
    )
    publish_card("BuildAgent", card, agent_card_security_extension(build_pk, build_endpoint))


def run_staging_deploy_agent_setup() -> None:
    master     = bytes.fromhex(
        "a3f1e2d4c5b6079819283a4b5c6d7e8f"
        "f0e1d2c3b4a5961728394a5b6c7d8e9f"
    )
    deployment = b"saas-cicd-prod"
    staging_id       = make_identity(master, deployment, b"staging-deploy-agent")
    staging_pk       = derive_public_key(staging_id)
    staging_kem_seed = sha256(master + b"kem:staging-deploy-agent").digest()
    staging_endpoint = derive_endpoint(staging_kem_seed)
    card = AgentCard(
        capabilities=AgentCapabilities(streaming=False, pushNotifications=False),
        defaultInputModes=["text/plain"],
        defaultOutputModes=["text/plain"],
        description="Deploys build artifacts to the staging environment",
        name="StagingDeployAgent",
        url="https://staging.saas.internal/.well-known/agent.json",
        version="1.0.0",
        skills=[AgentSkill(id="deploy-staging", name="Deploy to staging", description="Deploy artifacts to the staging environment.", tags=["ci"])],
    )
    publish_card("StagingDeployAgent", card, agent_card_security_extension(staging_pk, staging_endpoint))


def run_build_agent() -> None:
    """
    BuildAgent verifies its own credential, then sends a signed build-complete
    message to StagingDeployAgent over an encrypted KEM session.
    """
    print("\n── BuildAgent ───────────────────────────────────────────────────────")

    master     = bytes.fromhex(
        "a3f1e2d4c5b6079819283a4b5c6d7e8f"
        "f0e1d2c3b4a5961728394a5b6c7d8e9f"
    )
    deployment = b"saas-cicd-prod"

    root_pk    = derive_public_key(make_identity(master, deployment, b"pipeline-orchestrator"))
    wire_chain = bytes.fromhex(_AGENT_CARDS["__chains__"]["build"])

    n = verify_auth(root_pk=root_pk, wire=wire_chain)
    print(f"  Own credential verified: {n} hop(s) anchored at PipelineOrchestrator")
    for i, cred in enumerate(decode_chain(wire_chain)):
        print(f"    [{i+1}] {explain_credential(cred)}")

    # ── Scope escalation attempt ──────────────────────────────────────────────
    print("\n  [attack] Compromised BuildAgent attempts to use staging cred for prod deploy...")
    staging_wire = bytes.fromhex(_AGENT_CARDS["__chains__"]["staging"])
    try:
        staging_cred = decode_chain(staging_wire)[0]
        payload      = parse_payload(staging_cred)
        granted      = [resource for resource, _ in payload["perms"]]
        if b"/deploy/prod" not in granted:
            raise ValueError(
                f"credential does not grant /deploy/prod — "
                f"granted paths: {[r.decode() for r in granted]}"
            )
    except ValueError as exc:
        print(f"  [attack REJECTED] {exc}")

    # ── Normal operation ──────────────────────────────────────────────────────
    _, staging_ek = extract_agent_card_ek({"extensions": discover_extensions("StagingDeployAgent")})

    task_id = b"build-task-20260316-001"
    offer_blob, initiator_session = kem_offer(peer_ek=staging_ek, context=task_id)

    metadata = pack_metadata(
        auth_wire  = wire_chain,
        offer_blob = offer_blob,
        extra      = {"taskId": task_id.decode(), "commit": "a1b2c3d4"},
    )
    msg = Message(
        messageId = "msg-build-001",
        role      = Role.agent,
        parts     = [Part(root=TextPart(text="Build complete — artifact ready for staging deploy"))],
        metadata  = metadata,
    )
    send_message(msg)
    print(f"\n  Build-complete message sent to StagingDeployAgent ({len(msg.model_dump_json())} bytes)")

    _AGENT_CARDS["__build_session__"] = {
        "session": initiator_session,
        "task_id": task_id,
    }


def run_staging_deploy_agent_receive() -> tuple[Session, bytes]:
    """
    StagingDeployAgent receives the build-complete message, verifies the BuildAgent
    credential chain, and accepts the KEM handshake.
    """
    print("\n── StagingDeployAgent (receive) ─────────────────────────────────────")

    master     = bytes.fromhex(
        "a3f1e2d4c5b6079819283a4b5c6d7e8f"
        "f0e1d2c3b4a5961728394a5b6c7d8e9f"
    )
    deployment = b"saas-cicd-prod"

    root_pk = derive_public_key(make_identity(master, deployment, b"pipeline-orchestrator"))

    msg      = receive_message()
    metadata = msg.metadata or {}
    task_id  = metadata["taskId"].encode()

    auth_wire, offer_blob = unpack_metadata(metadata)

    n = verify_auth(root_pk=root_pk, wire=auth_wire)
    print(f"  Sender credential verified: {n} hop(s)")
    for i, cred in enumerate(decode_chain(auth_wire)):
        print(f"    [{i+1}] {explain_credential(cred)}")

    staging_kem_seed = sha256(master + b"kem:staging-deploy-agent").digest()
    staging_endpoint = derive_endpoint(staging_kem_seed)
    session = kem_accept(staging_endpoint, offer_blob, context=task_id)
    print(f"\n  KEM session established (task {task_id.decode()})")

    return session, task_id


def run_build_agent_send_artifact(responder_session: Session, task_id: bytes) -> None:
    """
    BuildAgent sends the encrypted artifact manifest over the established session.
    """
    print("\n── BuildAgent (send encrypted artifact manifest) ─────────────────────")

    stored             = _AGENT_CARDS["__build_session__"]
    initiator_session: Session = stored["session"]

    artifact_manifest = json.dumps({
        "artifact":     "app-server-20260316-a1b2c3d4.tar.gz",
        "sha256":       "e3b0c44298fc1c149afb4c8996fb92427ae41e4649b934ca495991b7852b855",
        "commit":       "a1b2c3d4",
        "target_env":   "staging",
        "tests_passed": True,
    }).encode()

    blob, next_session = seal(initiator_session, artifact_manifest, aad=task_id)
    print(f"  Artifact manifest sealed: {len(blob)} bytes")

    send_message(Message(
        messageId = "msg-build-002",
        role      = Role.agent,
        parts     = [],
        metadata  = {"taskId": task_id.decode(), "x-qhermes-payload": blob.hex()},
    ))

    _AGENT_CARDS["__build_session__"]["session"] = next_session
    print("  Nonce counter advanced — old session reference discarded")


def run_staging_deploy_agent_execute(session: Session, task_id: bytes) -> None:
    """
    StagingDeployAgent decrypts the artifact manifest and performs the deploy.
    """
    print("\n── StagingDeployAgent (execute deploy) ───────────────────────────────")

    msg  = receive_message()
    blob = bytes.fromhex((msg.metadata or {})["x-qhermes-payload"])

    plaintext = open_blob(session, blob, aad=task_id)
    manifest  = json.loads(plaintext)

    print(f"  Artifact manifest decrypted and authenticated:")
    print(f"    Artifact:     {manifest['artifact']}")
    print(f"    Commit:       {manifest['commit']}")
    print(f"    Target env:   {manifest['target_env']}")
    print(f"    Tests passed: {manifest['tests_passed']}")
    print(f"\n  Deploying to staging... COMPLETE")


def run_prod_deploy_agent() -> None:
    """
    ProdDeployAgent demonstrates the 15-minute expiry window.
    """
    print("\n── ProdDeployAgent (credential expiry demo) ──────────────────────────")

    master     = bytes.fromhex(
        "a3f1e2d4c5b6079819283a4b5c6d7e8f"
        "f0e1d2c3b4a5961728394a5b6c7d8e9f"
    )
    deployment = b"saas-cicd-prod"
    root_pk    = derive_public_key(make_identity(master, deployment, b"pipeline-orchestrator"))
    wire_chain = bytes.fromhex(_AGENT_CARDS["__chains__"]["prod"])

    now = int(time.time())

    n = verify_auth(root_pk=root_pk, wire=wire_chain, now=now)
    print(f"  Credential valid NOW: {n} hop(s) — prod deploy would proceed")
    for i, cred in enumerate(decode_chain(wire_chain)):
        print(f"    [{i+1}] {explain_credential(cred)}")

    future = now + 16 * 60
    print(f"\n  Simulating 16 minutes later (t+{16*60}s)...")
    try:
        verify_auth(root_pk=root_pk, wire=wire_chain, now=future)
        print("  ERROR: should have raised — credential should be expired")
    except ValueError as exc:
        print(f"  Credential EXPIRED as expected: {exc}")
        print("  Prod deploy blocked — operator must re-issue credential after fresh approval")


def run_audit_agent() -> None:
    """
    AuditAgent verifies its own credential and prints a compliance summary.
    """
    print("\n── AuditAgent (compliance summary) ───────────────────────────────────")

    master     = bytes.fromhex(
        "a3f1e2d4c5b6079819283a4b5c6d7e8f"
        "f0e1d2c3b4a5961728394a5b6c7d8e9f"
    )
    deployment = b"saas-cicd-prod"
    root_pk    = derive_public_key(make_identity(master, deployment, b"pipeline-orchestrator"))

    chains = _AGENT_CARDS["__chains__"]
    now    = int(time.time())

    print(f"  Compliance snapshot at t={now}:")
    for agent_name, chain_hex in chains.items():
        wire = bytes.fromhex(chain_hex)
        cred = decode_chain(wire)[0]
        valid = credential_valid_at(cred, ts=now)
        p     = parse_payload(cred)
        perms = [f"{r.decode()} {v.decode()}" for r, v in p["perms"]]
        print(f"\n    Agent : {agent_name}")
        print(f"    Valid : {valid}")
        print(f"    Perms : {perms}")
        if p["not_after"]:
            remaining = p["not_after"] - now
            print(f"    TTL   : {remaining}s remaining")


# ── Main ──────────────────────────────────────────────────────────────────────

print("=" * 70)
print("QHermes A2A — CI/CD Pipeline")
print("=" * 70)

run_build_agent_setup()
run_staging_deploy_agent_setup()
run_pipeline_orchestrator()
run_build_agent()
session, task_id = run_staging_deploy_agent_receive()
run_build_agent_send_artifact(session, task_id)
run_staging_deploy_agent_execute(session, task_id)
run_prod_deploy_agent()
run_audit_agent()

print("\n" + "=" * 70)
print("Pipeline complete.")
print("=" * 70)
