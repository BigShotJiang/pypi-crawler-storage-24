// Copyright (c) 2026 Copertino All rights reserved.
// SPDX-License-Identifier: LicenseRef-Copertino-1.0
// Licensed under the Copertino Source License 1.0 — see LICENSE at the repository root.
// Commercial use requires a license from Copertino: hello@copertino.world

use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::PyBytes;
use qhermes_a2a as a2a;
use qhermes_channels as ch;
use qhermes_kernel as k;

// ── OS RNG adapter ────────────────────────────────────────────────────────

struct OsRng;

impl rand_core::TryRng for OsRng {
    type Error = core::convert::Infallible;
    fn try_fill_bytes(&mut self, dst: &mut [u8]) -> Result<(), Self::Error> {
        getrandom::fill(dst).expect("OS RNG unavailable");
        Ok(())
    }
    fn try_next_u32(&mut self) -> Result<u32, Self::Error> {
        let mut buf = [0u8; 4];
        getrandom::fill(&mut buf).expect("OS RNG unavailable");
        Ok(u32::from_le_bytes(buf))
    }
    fn try_next_u64(&mut self) -> Result<u64, Self::Error> {
        let mut buf = [0u8; 8];
        getrandom::fill(&mut buf).expect("OS RNG unavailable");
        Ok(u64::from_le_bytes(buf))
    }
}

impl rand_core::TryCryptoRng for OsRng {}

fn a2a_err(e: a2a::A2AError) -> PyErr {
    PyValueError::new_err(format!("A2AError::{e:?}"))
}

fn zero_creds() -> [k::Credential<'static>; k::MAX_DEPTH as usize] {
    const ZERO_PK:  [u8; k::PK_SIZE]  = [0u8; k::PK_SIZE];
    const ZERO_SIG: [u8; k::SIG_SIZE] = [0u8; k::SIG_SIZE];
    core::array::from_fn(|_| k::Credential {
        issuer_pk: k::PublicKey(&ZERO_PK),
        signature: k::Signature(&ZERO_SIG),
        payload:   b"",
    })
}

// ── SessionKey ────────────────────────────────────────────────────────────

/// ChaCha20-Poly1305 session key. Obtained via kem_offer() or kem_accept().
/// The underlying key material is zeroed on drop.
#[pyclass]
pub struct SessionKey {
    inner: ch::SessionKey,
}

#[pymethods]
impl SessionKey {
    /// seal(nonce: bytes, plaintext: bytes, aad: bytes) -> bytes
    ///
    /// nonce must be exactly 12 bytes. The nonce must not be reused with the same key.
    /// Returns ciphertext + 16-byte authentication tag.
    fn seal<'py>(
        &self,
        py: Python<'py>,
        nonce: &[u8],
        plaintext: &[u8],
        aad: &[u8],
    ) -> PyResult<Bound<'py, PyBytes>> {
        let nonce_arr: &[u8; ch::NONCE_SIZE] = nonce
            .try_into()
            .map_err(|_| PyValueError::new_err(format!("nonce must be {} bytes", ch::NONCE_SIZE)))?;
        PyBytes::new_with(py, plaintext.len() + ch::TAG_SIZE, |out| {
            self.inner.seal(nonce_arr, plaintext, aad, out)
                .map(|_| ())
                .map_err(|e| PyValueError::new_err(format!("ChannelError::{e:?}")))
        })
    }

    /// open(nonce: bytes, ciphertext: bytes, aad: bytes) -> bytes
    ///
    /// ciphertext is the full output of seal(). Returns the decrypted plaintext.
    /// Raises ValueError with AuthenticationFailed if the tag does not verify.
    fn open<'py>(
        &self,
        py: Python<'py>,
        nonce: &[u8],
        ciphertext: &[u8],
        aad: &[u8],
    ) -> PyResult<Bound<'py, PyBytes>> {
        let nonce_arr: &[u8; ch::NONCE_SIZE] = nonce
            .try_into()
            .map_err(|_| PyValueError::new_err(format!("nonce must be {} bytes", ch::NONCE_SIZE)))?;
        if ciphertext.len() < ch::TAG_SIZE {
            return Err(PyValueError::new_err("ciphertext too short"));
        }
        let pt_len = ciphertext.len() - ch::TAG_SIZE;
        PyBytes::new_with(py, pt_len, |out| {
            self.inner.open(nonce_arr, ciphertext, aad, out)
                .map(|_| ())
                .map_err(|e| PyValueError::new_err(format!("ChannelError::{e:?}")))
        })
    }
}

// ── Free functions ────────────────────────────────────────────────────────

/// sign_agent_card(master, deployment, context, card_bytes) -> bytes
///
/// master must be exactly 32 bytes. Returns the SIG_SIZE-byte signature.
#[pyfunction]
fn sign_agent_card<'py>(
    py: Python<'py>,
    master: &[u8],
    deployment: &[u8],
    context: &[u8],
    card_bytes: &[u8],
) -> PyResult<Bound<'py, PyBytes>> {
    let seed: &[u8; k::SEED_SIZE] = master
        .try_into()
        .map_err(|_| PyValueError::new_err(format!("master must be {} bytes", k::SEED_SIZE)))?;
    let island = k::IdentityIsland::derive(seed, deployment, context)
        .map_err(|e| PyValueError::new_err(format!("KernelError::{e:?}")))?;
    let mut sig = [0u8; k::SIG_SIZE];
    a2a::sign_agent_card(&island, card_bytes, &mut sig).map_err(a2a_err)?;
    Ok(PyBytes::new(py, &sig))
}

/// verify_agent_card(root_pk, card_bytes, sig) -> None
///
/// Raises ValueError on failure.
#[pyfunction]
fn verify_agent_card(root_pk: &[u8], card_bytes: &[u8], sig: &[u8]) -> PyResult<()> {
    let pk_arr: &[u8; k::PK_SIZE] = root_pk
        .try_into()
        .map_err(|_| PyValueError::new_err(format!("root_pk must be {} bytes", k::PK_SIZE)))?;
    let sig_arr: &[u8; k::SIG_SIZE] = sig
        .try_into()
        .map_err(|_| PyValueError::new_err(format!("sig must be {} bytes", k::SIG_SIZE)))?;
    a2a::verify_agent_card(k::PublicKey(pk_arr), card_bytes, sig_arr).map_err(a2a_err)
}

/// seal_auth(credentials: list[tuple[bytes, bytes, bytes]]) -> bytes
///
/// Each tuple is (issuer_pk, sig, payload). Returns the authorization wire blob.
#[pyfunction]
fn seal_auth<'py>(
    py: Python<'py>,
    credentials: Vec<(Vec<u8>, Vec<u8>, Vec<u8>)>,
) -> PyResult<Bound<'py, PyBytes>> {
    let mut bufs: Vec<([u8; k::PK_SIZE], [u8; k::SIG_SIZE], Vec<u8>)> =
        Vec::with_capacity(credentials.len());
    for (i, (pk, sig, payload)) in credentials.into_iter().enumerate() {
        bufs.push((
            pk.as_slice().try_into().map_err(|_| {
                PyValueError::new_err(format!("credential[{i}] issuer_pk must be {} bytes", k::PK_SIZE))
            })?,
            sig.as_slice().try_into().map_err(|_| {
                PyValueError::new_err(format!("credential[{i}] sig must be {} bytes", k::SIG_SIZE))
            })?,
            payload,
        ));
    }
    let chain: Vec<k::Credential<'_>> = bufs.iter().map(|(pk, sig, payload)| k::Credential {
        issuer_pk: k::PublicKey(pk),
        signature: k::Signature(sig),
        payload:   payload.as_slice(),
    }).collect();
    let max = 5 + chain.len() * (k::CREDENTIAL_FIXED_SIZE + k::MAX_PAYLOAD_SIZE);
    let mut out = vec![0u8; max];
    let n = a2a::seal_auth(&chain, &mut out).map_err(a2a_err)?;
    Ok(PyBytes::new(py, &out[..n]))
}

/// verify_auth(root_pk, wire, now) -> int
///
/// Verifies the full credential chain. Returns the credential count.
/// now is seconds since the Unix epoch. Raises ValueError on failure.
#[pyfunction]
fn verify_auth(root_pk: &[u8], wire: &[u8], now: u64) -> PyResult<usize> {
    let pk_arr: &[u8; k::PK_SIZE] = root_pk
        .try_into()
        .map_err(|_| PyValueError::new_err(format!("root_pk must be {} bytes", k::PK_SIZE)))?;
    let mut buf = zero_creds();
    a2a::verify_auth(k::PublicKey(pk_arr), wire, k::Timestamp(now), &mut buf).map_err(a2a_err)
}

/// derive_kem_keypair(dsa_seed: bytes) -> tuple[bytes, bytes]
///
/// dsa_seed must be exactly 32 bytes.
/// Returns (ek_bytes, dk_seed_bytes): EK_SIZE and DK_SEED_SIZE bytes respectively.
/// Store dk_seed_bytes securely; it is the secret required by kem_accept().
#[pyfunction]
fn derive_kem_keypair<'py>(
    py: Python<'py>,
    dsa_seed: &[u8],
) -> PyResult<(Bound<'py, PyBytes>, Bound<'py, PyBytes>)> {
    let seed: &[u8; 32] = dsa_seed
        .try_into()
        .map_err(|_| PyValueError::new_err("dsa_seed must be 32 bytes"))?;
    let kp = ch::derive_kem_keypair(seed)
        .map_err(|e| PyValueError::new_err(format!("ChannelError::{e:?}")))?;
    Ok((
        PyBytes::new(py, kp.encapsulation_key.as_bytes()),
        PyBytes::new(py, kp.decapsulation_key.as_seed()),
    ))
}

/// kem_offer(peer_ek: bytes, context: bytes) -> tuple[bytes, SessionKey]
///
/// peer_ek must be EK_SIZE (1184) bytes.
/// Returns (offer_blob, session_key). offer_blob is KEM_OFFER_SIZE (1088) bytes.
/// OS entropy is used automatically.
#[pyfunction]
fn kem_offer<'py>(
    py: Python<'py>,
    peer_ek: &[u8],
    context: &[u8],
) -> PyResult<(Bound<'py, PyBytes>, SessionKey)> {
    let ek_arr: &[u8; ch::EK_SIZE] = peer_ek
        .try_into()
        .map_err(|_| PyValueError::new_err(format!("peer_ek must be {} bytes", ch::EK_SIZE)))?;
    let kem_ek = ch::KemEncapsulationKey::from_bytes(ek_arr)
        .map_err(|e| PyValueError::new_err(format!("ChannelError::{e:?}")))?;
    let mut out = [0u8; a2a::KEM_OFFER_SIZE];
    let inner = a2a::kem_offer(&kem_ek, context, &mut OsRng, &mut out).map_err(a2a_err)?;
    Ok((PyBytes::new(py, &out), SessionKey { inner }))
}

/// kem_accept(dk_seed: bytes, offer: bytes, context: bytes) -> SessionKey
///
/// dk_seed is the DK_SEED_SIZE (64) bytes returned by derive_kem_keypair().
/// offer is the KEM_OFFER_SIZE (1088) bytes from kem_offer().
/// context must be identical to the value passed to kem_offer().
#[pyfunction]
fn kem_accept(dk_seed: &[u8], offer: &[u8], context: &[u8]) -> PyResult<SessionKey> {
    let seed_arr: &[u8; ch::DK_SEED_SIZE] = dk_seed
        .try_into()
        .map_err(|_| PyValueError::new_err(format!("dk_seed must be {} bytes", ch::DK_SEED_SIZE)))?;
    let offer_arr: &[u8; a2a::KEM_OFFER_SIZE] = offer
        .try_into()
        .map_err(|_| PyValueError::new_err(format!("offer must be {} bytes", a2a::KEM_OFFER_SIZE)))?;
    let dk = ch::KemDecapsulationKey::from_seed(seed_arr);
    let inner = a2a::kem_accept(&dk, offer_arr, context).map_err(a2a_err)?;
    Ok(SessionKey { inner })
}

// ── Module ────────────────────────────────────────────────────────────────

#[pymodule(name = "qhermes_a2a")]
fn qhermes_a2a_ext(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add("PK_SIZE",        k::PK_SIZE)?;
    m.add("SIG_SIZE",       k::SIG_SIZE)?;
    m.add("EK_SIZE",        ch::EK_SIZE)?;
    m.add("DK_SEED_SIZE",   ch::DK_SEED_SIZE)?;
    m.add("CT_SIZE",        ch::CT_SIZE)?;
    m.add("NONCE_SIZE",     ch::NONCE_SIZE)?;
    m.add("TAG_SIZE",       ch::TAG_SIZE)?;
    m.add("KEM_OFFER_SIZE", a2a::KEM_OFFER_SIZE)?;

    m.add_class::<SessionKey>()?;

    m.add_function(wrap_pyfunction!(sign_agent_card, m)?)?;
    m.add_function(wrap_pyfunction!(verify_agent_card, m)?)?;
    m.add_function(wrap_pyfunction!(seal_auth, m)?)?;
    m.add_function(wrap_pyfunction!(verify_auth, m)?)?;
    m.add_function(wrap_pyfunction!(derive_kem_keypair, m)?)?;
    m.add_function(wrap_pyfunction!(kem_offer, m)?)?;
    m.add_function(wrap_pyfunction!(kem_accept, m)?)?;
    Ok(())
}
