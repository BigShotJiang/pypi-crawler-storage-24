// Copyright (c) 2026 Copertino All rights reserved.
// SPDX-License-Identifier: LicenseRef-Copertino-1.0
// Licensed under the Copertino Source License 1.0 — see LICENSE at the repository root.
// Commercial use requires a license from Copertino: hello@copertino.world

#![no_std]
#![forbid(unsafe_code)]

//! Post-quantum encrypted channels for QHermes.
//!
//! ML-KEM-768 key encapsulation + ChaCha20-Poly1305 AEAD.
//! No heap. No I/O. All inputs and outputs are caller-allocated slices or arrays.

use chacha20poly1305::{AeadInPlace, ChaCha20Poly1305, KeyInit};
use hkdf::Hkdf;
use ml_kem::{
    Decapsulate, Encapsulate, FromSeed, KeyExport, MlKem768, Seed,
    kem::Kem,
};
use sha3::Sha3_512;
use zeroize::{Zeroize, ZeroizeOnDrop, Zeroizing};

// ── Size constants ─────────────────────────────────────────────────────────

/// ML-KEM-768 encapsulation key (bytes).
pub const EK_SIZE: usize = 1184;

/// Seed for ML-KEM-768 decapsulation key derivation (bytes).
pub const DK_SEED_SIZE: usize = 64;

/// ML-KEM-768 ciphertext (bytes).
pub const CT_SIZE: usize = 1088;

/// ChaCha20-Poly1305 session key (bytes).
pub const KEY_SIZE: usize = 32;

/// ChaCha20-Poly1305 nonce (bytes).
pub const NONCE_SIZE: usize = 12;

/// ChaCha20-Poly1305 authentication tag (bytes).
pub const TAG_SIZE: usize = 16;

// Changing SALT invalidates all previously derived key material.
const SALT: &[u8] = b"QHermes-Channels-v1";

// ── Error type ────────────────────────────────────────────────────────────

/// Errors returned by `qhermes-channels` operations.
#[derive(Debug, PartialEq, Eq)]
#[non_exhaustive]
pub enum ChannelError {
    /// HKDF key expansion produced fewer bytes than requested.
    HkdfExpandFailed,
    /// The encapsulation key bytes are not a valid ML-KEM-768 encoding.
    KeyDecodingFailed,
    /// The output buffer is smaller than the required minimum.
    OutputBufferTooSmall,
    /// The input buffer does not have the expected size.
    InputBufferTooSmall,
    /// AEAD authentication tag verification failed.
    AuthenticationFailed,
}

// ── Key types ─────────────────────────────────────────────────────────────

type MlEk = <MlKem768 as Kem>::EncapsulationKey;

/// ML-KEM-768 encapsulation key. Public; may be transmitted freely.
#[derive(Clone)]
pub struct KemEncapsulationKey {
    bytes: [u8; EK_SIZE],
    inner: MlEk,
}

impl KemEncapsulationKey {
    /// Raw bytes.
    pub fn as_bytes(&self) -> &[u8; EK_SIZE] {
        &self.bytes
    }

    /// Constructs from raw bytes. Returns `KeyDecodingFailed` if the encoding
    /// is not a valid ML-KEM-768 encapsulation key.
    pub fn from_bytes(bytes: &[u8; EK_SIZE]) -> Result<Self, ChannelError> {
        let key_arr: hybrid_array::Array<u8, _> = (*bytes).into();
        let inner = MlEk::new(&key_arr).map_err(|_| ChannelError::KeyDecodingFailed)?;
        Ok(Self { bytes: *bytes, inner })
    }
}

/// ML-KEM-768 decapsulation key seed. Secret; zeroed on drop.
#[derive(ZeroizeOnDrop)]
pub struct KemDecapsulationKey([u8; DK_SEED_SIZE]);

impl KemDecapsulationKey {
    /// Constructs from a seed previously returned by `derive_kem_keypair`.
    pub fn from_seed(seed: &[u8; DK_SEED_SIZE]) -> Self {
        Self(*seed)
    }

    /// Raw seed bytes.
    pub fn as_seed(&self) -> &[u8; DK_SEED_SIZE] {
        &self.0
    }
}

/// Matching encapsulation / decapsulation key pair.
pub struct KemKeyPair {
    pub encapsulation_key: KemEncapsulationKey,
    pub decapsulation_key: KemDecapsulationKey,
}

/// ML-KEM-768 ciphertext produced by `encapsulate`.
#[derive(Debug)]
pub struct KemCiphertext([u8; CT_SIZE]);

impl KemCiphertext {
    /// Raw bytes.
    pub fn as_bytes(&self) -> &[u8; CT_SIZE] {
        &self.0
    }

    /// Constructs from a fixed-size array.
    pub fn from_bytes(bytes: [u8; CT_SIZE]) -> Self {
        Self(bytes)
    }
}

// ── Session key ───────────────────────────────────────────────────────────

/// ChaCha20-Poly1305 session key derived from a KEM shared secret.
/// Zeroed on drop.
#[derive(ZeroizeOnDrop)]
pub struct SessionKey([u8; KEY_SIZE]);

impl SessionKey {
    /// Derives a `SessionKey` from a 32-byte KEM shared secret via HKDF-SHA3-512.
    ///
    /// `context`: caller-supplied domain separation material. May be empty.
    fn derive(ss: &[u8; 32], context: &[u8]) -> Result<Self, ChannelError> {
        let hk = Hkdf::<Sha3_512>::new(Some(SALT), ss);
        let mut key = [0u8; KEY_SIZE];
        hk.expand_multi_info(&[b"QHermes-session-v1", context], &mut key)
            .map_err(|_| ChannelError::HkdfExpandFailed)?;
        Ok(Self(key))
    }

    /// Encrypts `plaintext` with ChaCha20-Poly1305.
    ///
    /// The nonce must not be reused with the same key.
    ///
    /// `out` must have at least `plaintext.len() + TAG_SIZE` bytes.
    /// Returns the number of bytes written.
    pub fn seal(
        &self,
        nonce: &[u8; NONCE_SIZE],
        plaintext: &[u8],
        aad: &[u8],
        out: &mut [u8],
    ) -> Result<usize, ChannelError> {
        let required = plaintext.len() + TAG_SIZE;
        if out.len() < required {
            return Err(ChannelError::OutputBufferTooSmall);
        }

        out[..plaintext.len()].copy_from_slice(plaintext);

        let cipher = ChaCha20Poly1305::new((&self.0).into());
        let tag = cipher
            .encrypt_in_place_detached(nonce.into(), aad, &mut out[..plaintext.len()])
            .unwrap();

        out[plaintext.len()..required].copy_from_slice(&tag);
        Ok(required)
    }

    /// Decrypts and authenticates a ciphertext produced by `seal`.
    ///
    /// `ciphertext` is the full slice returned by `seal` (plaintext bytes +
    /// 16-byte tag). `out` must have at least `ciphertext.len() - TAG_SIZE` bytes.
    ///
    /// Returns `AuthenticationFailed` if the tag does not verify.
    pub fn open(
        &self,
        nonce: &[u8; NONCE_SIZE],
        ciphertext: &[u8],
        aad: &[u8],
        out: &mut [u8],
    ) -> Result<usize, ChannelError> {
        if ciphertext.len() < TAG_SIZE {
            return Err(ChannelError::InputBufferTooSmall);
        }
        let pt_len = ciphertext.len() - TAG_SIZE;
        if out.len() < pt_len {
            return Err(ChannelError::OutputBufferTooSmall);
        }

        let (body, tag_bytes) = ciphertext.split_at(pt_len);
        let tag: [u8; TAG_SIZE] = tag_bytes.try_into().unwrap();

        out[..pt_len].copy_from_slice(body);

        let cipher = ChaCha20Poly1305::new((&self.0).into());
        cipher
            .decrypt_in_place_detached(nonce.into(), aad, &mut out[..pt_len], (&tag).into())
            .map_err(|_| ChannelError::AuthenticationFailed)?;

        Ok(pt_len)
    }
}

// ── Key derivation ────────────────────────────────────────────────────────

/// Deterministically derives a `KemKeyPair` from a 32-byte DSA seed.
///
/// Passing the same seed used in `qhermes_kernel::IdentityIsland::derive` binds
/// a KEM identity to a DSA identity under the same root secret. Domain separation
/// is provided by the info string `b"QHermes-KEM-768-v1"`, which is distinct from
/// the kernel's `deployment:context` string.
pub fn derive_kem_keypair(dsa_seed: &[u8; 32]) -> Result<KemKeyPair, ChannelError> {

    let hk = Hkdf::<Sha3_512>::new(Some(SALT), dsa_seed);
    let mut seed_buf: Zeroizing<[u8; DK_SEED_SIZE]> = Zeroizing::new([0u8; DK_SEED_SIZE]);
    hk.expand(b"QHermes-KEM-768-v1", seed_buf.as_mut())
        .map_err(|_| ChannelError::HkdfExpandFailed)?;

    let mut ml_seed: Seed = (*seed_buf).into();
    let (_dk_ml, ek_ml) = MlKem768::from_seed(&ml_seed);
    ml_seed.zeroize();

    let ek_raw = ek_ml.to_bytes();
    let mut ek_arr = [0u8; EK_SIZE];
    ek_arr.copy_from_slice(ek_raw.as_ref());

    Ok(KemKeyPair {
        encapsulation_key: KemEncapsulationKey { bytes: ek_arr, inner: ek_ml },
        decapsulation_key: KemDecapsulationKey(*seed_buf),
    })
}

// ── KEM operations ────────────────────────────────────────────────────────

/// Encapsulates a fresh shared secret for `ek`.
///
/// Returns the ciphertext to send to the holder of the corresponding
/// decapsulation key, and a `SessionKey` derived from the shared secret.
///
/// `context`: domain separation material forwarded to `SessionKey::derive`.
/// `rng`: must be a cryptographically secure RNG.
pub fn encapsulate(
    ek: &KemEncapsulationKey,
    context: &[u8],
    rng: &mut impl rand_core::CryptoRng,
) -> Result<(KemCiphertext, SessionKey), ChannelError> {
    let (ct_ml, ss_ml) = ek.inner.encapsulate_with_rng(rng);

    let mut ct_arr = [0u8; CT_SIZE];
    ct_arr.copy_from_slice(ct_ml.as_ref());
    let mut ss = Zeroizing::new([0u8; 32]);
    ss.copy_from_slice(ss_ml.as_ref());

    Ok((KemCiphertext(ct_arr), SessionKey::derive(&ss, context)?))
}

/// Decapsulates the shared secret from `ct` using `dk`.
///
/// Returns a `SessionKey` equivalent to the one returned by `encapsulate` when
/// called with the corresponding encapsulation key.
///
/// `context` must be identical to the value passed to `encapsulate`.
pub fn decapsulate(
    dk: &KemDecapsulationKey,
    ct: &KemCiphertext,
    context: &[u8],
) -> Result<SessionKey, ChannelError> {
    type Dk = <MlKem768 as Kem>::DecapsulationKey;
    type Ct = ml_kem::Ciphertext<MlKem768>;

    let mut ml_seed: Seed = dk.0.into();
    let (dk_ml, _): (Dk, _) = MlKem768::from_seed(&ml_seed);
    ml_seed.zeroize();

    let ct_arr: hybrid_array::Array<u8, _> = ct.0.into();
    let ss_ml = dk_ml.decapsulate(&Ct::from(ct_arr));

    let mut ss = Zeroizing::new([0u8; 32]);
    ss.copy_from_slice(ss_ml.as_ref());
    SessionKey::derive(&ss, context)
}

// ── Tests ─────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    extern crate std;
    use std::vec;
    use core::convert::Infallible;

    // ── Minimal deterministic test RNG ──
    //
    // rand_core 0.10 requires implementing TryRng (with Error = Infallible) and
    // TryCryptoRng.  CryptoRng is then blanket-implemented for anything that
    // satisfies both. Randomness quality is irrelevant in these tests — we only
    // need the KEM to complete without panicking.

    struct XorShift64(u64);

    impl XorShift64 {
        fn next_bytes(&mut self, dst: &mut [u8]) {
            let mut i = 0;
            while i < dst.len() {
                // XorShift64 step
                self.0 ^= self.0 << 13;
                self.0 ^= self.0 >> 7;
                self.0 ^= self.0 << 17;
                let bytes = self.0.to_le_bytes();
                let chunk = (dst.len() - i).min(8);
                dst[i..i + chunk].copy_from_slice(&bytes[..chunk]);
                i += chunk;
            }
        }
    }

    impl rand_core::TryRng for XorShift64 {
        type Error = Infallible;

        fn try_next_u32(&mut self) -> Result<u32, Infallible> {
            self.0 ^= self.0 << 13;
            self.0 ^= self.0 >> 7;
            self.0 ^= self.0 << 17;
            Ok(self.0 as u32)
        }

        fn try_next_u64(&mut self) -> Result<u64, Infallible> {
            self.0 ^= self.0 << 13;
            self.0 ^= self.0 >> 7;
            self.0 ^= self.0 << 17;
            Ok(self.0)
        }

        fn try_fill_bytes(&mut self, dst: &mut [u8]) -> Result<(), Infallible> {
            self.next_bytes(dst);
            Ok(())
        }
    }

    impl rand_core::TryCryptoRng for XorShift64 {}

    fn test_rng() -> XorShift64 {
        XorShift64(0xDEAD_BEEF_CAFE_BABEu64)
    }

    // ── derive_kem_keypair ──

    #[test]
    fn derive_kem_keypair_deterministic() {
        let seed = [0x11u8; 32];
        let kp1 = derive_kem_keypair(&seed).unwrap();
        let kp2 = derive_kem_keypair(&seed).unwrap();
        assert_eq!(kp1.encapsulation_key.as_bytes(), kp2.encapsulation_key.as_bytes());
    }

    #[test]
    fn derive_kem_keypair_different_seeds_different_ek() {
        let seed_a = [0x11u8; 32];
        let seed_b = [0x22u8; 32];
        let kp_a = derive_kem_keypair(&seed_a).unwrap();
        let kp_b = derive_kem_keypair(&seed_b).unwrap();
        assert_ne!(kp_a.encapsulation_key.as_bytes(), kp_b.encapsulation_key.as_bytes());
    }

    #[test]
    fn derive_kem_keypair_ek_has_correct_size() {
        let seed = [0x11u8; 32];
        let kp = derive_kem_keypair(&seed).unwrap();
        assert_eq!(kp.encapsulation_key.as_bytes().len(), EK_SIZE);
    }

    // ── KemEncapsulationKey::from_bytes ──

    #[test]
    fn kem_ek_from_bytes_valid_does_not_panic() {
        let seed = [0x11u8; 32];
        let kp = derive_kem_keypair(&seed).unwrap();
        let ek_bytes = *kp.encapsulation_key.as_bytes();
        // Must succeed for valid bytes produced by derive_kem_keypair.
        let result = KemEncapsulationKey::from_bytes(&ek_bytes);
        assert!(result.is_ok());
    }

    #[test]
    fn kem_ek_from_bytes_all_zero_does_not_panic() {
        // All-zero may or may not be a valid key; we just assert no panic.
        let zeroes = [0u8; EK_SIZE];
        let _result = KemEncapsulationKey::from_bytes(&zeroes);
        // No assertion on Ok/Err — behaviour is implementation-defined.
    }

    // ── encapsulate / decapsulate (KEM round-trip) ──

    #[test]
    fn kem_round_trip_matching_context_same_session_key() {
        let seed = [0x11u8; 32];
        let kp = derive_kem_keypair(&seed).unwrap();

        let mut rng = test_rng();
        let context = b"session-id-abc";
        let (ct, sk_encap) = encapsulate(&kp.encapsulation_key, context, &mut rng).unwrap();
        let sk_decap = decapsulate(&kp.decapsulation_key, &ct, context).unwrap();

        // Both sides must agree on the session key — verify by sealing/opening.
        let nonce = [0u8; NONCE_SIZE];
        let plaintext = b"hello world";
        let mut ciphertext_buf = vec![0u8; plaintext.len() + TAG_SIZE];
        let ct_len = sk_encap.seal(&nonce, plaintext, b"", &mut ciphertext_buf).unwrap();

        let mut recovered = vec![0u8; plaintext.len()];
        let pt_len = sk_decap.open(&nonce, &ciphertext_buf[..ct_len], b"", &mut recovered).unwrap();
        assert_eq!(&recovered[..pt_len], plaintext);
    }

    #[test]
    fn kem_round_trip_mismatched_context_different_session_key() {
        let seed = [0x11u8; 32];
        let kp = derive_kem_keypair(&seed).unwrap();

        let mut rng = test_rng();
        let (ct, sk_encap) = encapsulate(&kp.encapsulation_key, b"context-A", &mut rng).unwrap();
        let sk_decap = decapsulate(&kp.decapsulation_key, &ct, b"context-B").unwrap();

        // Seal with encapsulator's key and attempt to open with decapsulator's key
        // derived from a different context.  The tag verification must fail.
        let nonce = [0u8; NONCE_SIZE];
        let plaintext = b"secret data";
        let mut ciphertext_buf = vec![0u8; plaintext.len() + TAG_SIZE];
        let ct_len = sk_encap.seal(&nonce, plaintext, b"", &mut ciphertext_buf).unwrap();

        let mut recovered = vec![0u8; plaintext.len()];
        let result = sk_decap.open(&nonce, &ciphertext_buf[..ct_len], b"", &mut recovered);
        assert!(matches!(result, Err(ChannelError::AuthenticationFailed)));
    }

    #[test]
    fn encapsulate_produces_ct_size_ciphertext() {
        let seed = [0x11u8; 32];
        let kp = derive_kem_keypair(&seed).unwrap();
        let mut rng = test_rng();
        let (ct, _) = encapsulate(&kp.encapsulation_key, b"ctx", &mut rng).unwrap();
        assert_eq!(ct.as_bytes().len(), CT_SIZE);
    }

    // ── SessionKey::seal / open ──

    /// Derives a test session key from a fixed shared secret.
    fn test_session_key() -> SessionKey {
        let seed = [0x11u8; 32];
        let kp = derive_kem_keypair(&seed).unwrap();
        let mut rng = test_rng();
        let (ct, sk) = encapsulate(&kp.encapsulation_key, b"test", &mut rng).unwrap();
        let _ = ct;
        sk
    }

    #[test]
    fn session_key_seal_open_roundtrip() {
        let sk = test_session_key();
        let nonce = [0xAAu8; NONCE_SIZE];
        let plaintext = b"round-trip message";
        let aad = b"aad-header";

        let mut ct_buf = vec![0u8; plaintext.len() + TAG_SIZE];
        let ct_len = sk.seal(&nonce, plaintext, aad, &mut ct_buf).unwrap();

        let mut pt_buf = vec![0u8; plaintext.len()];
        let pt_len = sk.open(&nonce, &ct_buf[..ct_len], aad, &mut pt_buf).unwrap();
        assert_eq!(&pt_buf[..pt_len], plaintext);
    }

    #[test]
    fn session_key_seal_open_empty_plaintext() {
        let sk = test_session_key();
        let nonce = [0u8; NONCE_SIZE];

        let mut ct_buf = vec![0u8; TAG_SIZE];
        let ct_len = sk.seal(&nonce, b"", b"", &mut ct_buf).unwrap();

        let mut pt_buf = vec![0u8; 0];
        let pt_len = sk.open(&nonce, &ct_buf[..ct_len], b"", &mut pt_buf).unwrap();
        assert_eq!(pt_len, 0);
    }

    #[test]
    fn session_key_seal_open_large_plaintext() {
        let sk = test_session_key();
        let nonce = [0x55u8; NONCE_SIZE];
        let plaintext = vec![0xCCu8; 8192];
        let aad = b"large";

        let mut ct_buf = vec![0u8; plaintext.len() + TAG_SIZE];
        let ct_len = sk.seal(&nonce, &plaintext, aad, &mut ct_buf).unwrap();

        let mut pt_buf = vec![0u8; plaintext.len()];
        let pt_len = sk.open(&nonce, &ct_buf[..ct_len], aad, &mut pt_buf).unwrap();
        assert_eq!(&pt_buf[..pt_len], plaintext.as_slice());
    }

    #[test]
    fn session_key_open_aad_mismatch_returns_auth_failed() {
        let sk = test_session_key();
        let nonce = [0u8; NONCE_SIZE];
        let plaintext = b"sensitive";

        let mut ct_buf = vec![0u8; plaintext.len() + TAG_SIZE];
        let ct_len = sk.seal(&nonce, plaintext, b"correct-aad", &mut ct_buf).unwrap();

        let mut pt_buf = vec![0u8; plaintext.len()];
        let result = sk.open(&nonce, &ct_buf[..ct_len], b"wrong-aad", &mut pt_buf);
        assert!(matches!(result, Err(ChannelError::AuthenticationFailed)));
    }

    #[test]
    fn session_key_open_tampered_ciphertext_body_returns_auth_failed() {
        let sk = test_session_key();
        let nonce = [0u8; NONCE_SIZE];
        let plaintext = b"tamper-me";

        let mut ct_buf = vec![0u8; plaintext.len() + TAG_SIZE];
        let ct_len = sk.seal(&nonce, plaintext, b"", &mut ct_buf).unwrap();

        // Flip a bit in the ciphertext body (not the tag).
        ct_buf[0] ^= 0x01;

        let mut pt_buf = vec![0u8; plaintext.len()];
        let result = sk.open(&nonce, &ct_buf[..ct_len], b"", &mut pt_buf);
        assert!(matches!(result, Err(ChannelError::AuthenticationFailed)));
    }

    #[test]
    fn session_key_open_tampered_tag_returns_auth_failed() {
        let sk = test_session_key();
        let nonce = [0u8; NONCE_SIZE];
        let plaintext = b"tamper-tag";

        let mut ct_buf = vec![0u8; plaintext.len() + TAG_SIZE];
        let ct_len = sk.seal(&nonce, plaintext, b"", &mut ct_buf).unwrap();

        // Flip a bit in the tag (last TAG_SIZE bytes).
        let last = ct_len - 1;
        ct_buf[last] ^= 0x80;

        let mut pt_buf = vec![0u8; plaintext.len()];
        let result = sk.open(&nonce, &ct_buf[..ct_len], b"", &mut pt_buf);
        assert!(matches!(result, Err(ChannelError::AuthenticationFailed)));
    }

    #[test]
    fn session_key_seal_output_too_small_returns_output_buffer_too_small() {
        let sk = test_session_key();
        let nonce = [0u8; NONCE_SIZE];
        let plaintext = b"hello";

        // Provide a buffer one byte too small.
        let mut too_small = vec![0u8; plaintext.len() + TAG_SIZE - 1];
        let result = sk.seal(&nonce, plaintext, b"", &mut too_small);
        assert!(matches!(result, Err(ChannelError::OutputBufferTooSmall)));
    }

    #[test]
    fn session_key_open_output_too_small_returns_output_buffer_too_small() {
        let sk = test_session_key();
        let nonce = [0u8; NONCE_SIZE];
        let plaintext = b"needs room";

        let mut ct_buf = vec![0u8; plaintext.len() + TAG_SIZE];
        let ct_len = sk.seal(&nonce, plaintext, b"", &mut ct_buf).unwrap();

        // Provide a plaintext output buffer one byte too small.
        let mut too_small = vec![0u8; plaintext.len() - 1];
        let result = sk.open(&nonce, &ct_buf[..ct_len], b"", &mut too_small);
        assert!(matches!(result, Err(ChannelError::OutputBufferTooSmall)));
    }

    #[test]
    fn session_key_open_ciphertext_shorter_than_tag_returns_input_buffer_too_small() {
        let sk = test_session_key();
        let nonce = [0u8; NONCE_SIZE];

        // Ciphertext slice shorter than TAG_SIZE (16 bytes).
        let short = vec![0u8; TAG_SIZE - 1];
        let mut pt_buf = vec![0u8; 64];
        let result = sk.open(&nonce, &short, b"", &mut pt_buf);
        assert!(matches!(result, Err(ChannelError::InputBufferTooSmall)));
    }
}
