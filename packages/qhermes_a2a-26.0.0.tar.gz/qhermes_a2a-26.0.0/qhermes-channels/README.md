# qhermes-channels

Part of **QHermes 26** by Copertino.

Thank you for choosing QHermes 26.

ML-KEM-768 key encapsulation, HKDF-SHA3-512 session key derivation, and
ChaCha20-Poly1305 authenticated encryption. No allocator dependency.
No unsafe code. All inputs and outputs are caller-supplied slices or
fixed-size arrays.

Key encapsulation: ML-KEM-768 (FIPS 203). Authenticated encryption: ChaCha20-Poly1305. Session key derivation: HKDF-SHA3-512.

## Design

**KEM and DSA identities may share a root secret.** `derive_kem_keypair` accepts the same 32-byte seed used by `qhermes_kernel::IdentityIsland::derive`. Domain separation between the DSA key and the KEM key is maintained through distinct HKDF info strings — `b"QHermes-KEM-768-v1"` for the KEM, `deployment:context` for the DSA. The two derived keys have no mathematical relationship despite sharing the same input. One root secret binds one signing identity to one encryption identity without coupling between them.

**Nonce management is the caller's responsibility.** `SessionKey::seal` accepts a nonce and writes the ciphertext. It does not track state, increment counters, or prevent reuse. The crate operates in `no_std` environments where no global state is available. Callers must manage nonces. The high-level Python bindings in `qhermes-a2a-py` handle this with a monotonic counter.

**Secret material is zeroized on drop.** `KemDecapsulationKey` and `SessionKey` implement `ZeroizeOnDrop`. Intermediate shared secret buffers throughout the key derivation path are wrapped in `Zeroizing<T>`. Memory is overwritten before deallocation when these types go out of scope.

**The RNG is injected, not embedded.** `encapsulate` accepts a `&mut impl rand_core::CryptoRng`. On standard platforms, pass `OsRng`. On embedded targets, pass any type implementing `CryptoRng` backed by the hardware TRNG. The crate makes no calls to OS entropy sources.

**`context` binds the session key to a domain.** The `context` parameter in `encapsulate` and `decapsulate` is forwarded to HKDF as additional info. Two sessions established with the same KEM exchange but different context values produce different session keys. Supply a stable session or task identifier. Passing `b""` on both sides produces a valid session key with weaker domain binding.

## Usage

```rust
use qhermes_channels::{derive_kem_keypair, encapsulate, decapsulate};

// Derive a KEM key pair from a 32-byte seed.
let kp = derive_kem_keypair(&seed_32)?;

// Initiator: encapsulate a shared secret for the responder.
let (ciphertext, session_key) = encapsulate(&kp.encapsulation_key, context, &mut rng)?;

// Send ciphertext.as_bytes() to the responder.

// Responder: decapsulate and derive the matching session key.
let session_key = decapsulate(&kp.decapsulation_key, &ciphertext, context)?;

// Both sides: seal and open message bodies.
let n = session_key.seal(&nonce, plaintext, aad, &mut out)?;
let m = session_key.open(&nonce, &out[..n], aad, &mut plaintext_buf)?;
```

## Constants

| Name | Value | Description |
|---|---|---|
| `EK_SIZE` | 1184 | ML-KEM-768 encapsulation key, bytes |
| `DK_SEED_SIZE` | 64 | Decapsulation key seed, bytes |
| `CT_SIZE` | 1088 | ML-KEM-768 ciphertext, bytes |
| `KEY_SIZE` | 32 | ChaCha20-Poly1305 session key, bytes |
| `NONCE_SIZE` | 12 | ChaCha20-Poly1305 nonce, bytes |
| `TAG_SIZE` | 16 | ChaCha20-Poly1305 authentication tag, bytes |

## License

Copertino Source License 1.0. Change Date: 2036-01-01. Change License: Apache-2.0.
See [LICENSE](../LICENSE).

Copyright © 2026 Copertino. All rights reserved.
