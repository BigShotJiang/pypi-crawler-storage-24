# qhermes-a2a

Part of **QHermes 26** by Copertino.

Thank you for choosing QHermes 26.

`qhermes-a2a` composes `qhermes-kernel` and `qhermes-channels` into an extension layer for the A2A protocol: Agent Card signing, authorization metadata, and KEM session handshake.

No JSON parsing. No sockets. No allocator dependency. All operations over caller-supplied byte slices. No unsafe code.

## Design

**Base64 encoding is the caller's responsibility.** `seal_auth` writes raw bytes and does not encode them. The caller determines how to embed the wire blob — base64, base64url, hex, or direct binary — according to the requirements of the transport. The crate is transport-agnostic and performs no string handling.

**`context` in the KEM handshake must match on both sides.** The parameter may be empty and the handshake will complete, but without it two sessions established between the same pair of keys are cryptographically indistinguishable. Supply a stable task or session identifier. Both parties must supply the same value.

**`AUTH_BLOB_MAX` is a worst-case bound, not a typical size.** It reflects the maximum possible wire size of a chain at maximum depth with maximum scope and caveats per credential. Actual chains are considerably smaller. Use it for static allocation when the chain size is not known in advance.

**Agent Card bytes must be canonicalized before signing.** `sign_agent_card` signs the bytes supplied to it. A verifier that re-canonicalizes before checking will reject signatures over non-canonical input. JCS (RFC 8785) is the recommended canonicalization: keys sorted, no extra whitespace, signature field omitted before signing and added after.

## Agent Card signing and verification

```rust
use qhermes_a2a::{sign_agent_card, verify_agent_card};

sign_agent_card(&identity, card_bytes, &mut sig)?;
verify_agent_card(root_pk, card_bytes, &sig)?;
```

## Authorization metadata

```rust
use qhermes_a2a::{seal_auth, verify_auth};

let n     = seal_auth(&chain, &mut wire_buf)?;
let count = verify_auth(root_pk, &wire_buf[..n], Timestamp(now), &mut chain_buf)?;
```

## KEM session handshake

```rust
use qhermes_a2a::{kem_offer, kem_accept, KEM_OFFER_SIZE};

let mut offer_buf = [0u8; KEM_OFFER_SIZE];
let session_key = kem_offer(&peer_ek, context, &mut rng, &mut offer_buf)?;

let session_key = kem_accept(&dk, &offer_buf, context)?;

let n = session_key.seal(&nonce, plaintext, aad, &mut out)?;
let m = session_key.open(&nonce, &out[..n], aad, &mut plaintext_buf)?;
```

## Constants

| Name | Value | Description |
|---|---|---|
| `KEM_OFFER_SIZE` | 1088 | KEM offer blob, bytes |
| `AUTH_BLOB_MAX` | — | Worst-case authorization blob size |

## License

Copertino Source License 1.0. Change Date: 2036-01-01. Change License: Apache-2.0.
See [LICENSE](../LICENSE).

Copyright © 2026 Copertino. All rights reserved.
