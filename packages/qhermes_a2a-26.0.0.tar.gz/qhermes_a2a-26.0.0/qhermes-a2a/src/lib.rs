// Copyright (c) 2026 Copertino All rights reserved.
// SPDX-License-Identifier: LicenseRef-Copertino-1.0
// Licensed under the Copertino Source License 1.0 — see LICENSE at the repository root.
// Commercial use requires a license from Copertino: hello@copertino.world

//! A2A identity and authorization layer for QHermes.
//!
//! This crate composes `qhermes-kernel` and `qhermes-channels` to cover the
//! three integration points that A2A requires:
//!
//! 1. Agent Card signing/verification — ML-DSA-65 signature over the
//!    canonicalized Agent Card payload.
//! 2. Authorization metadata — serializes and deserializes a QHermes
//!    credential chain into/from the `message.metadata` blob of each A2A message.
//! 3. Session KEM handshake — offer/accept functions that produce a
//!    `SessionKey` from `qhermes-channels` for encrypting A2A message bodies.
//!
//! This crate does not parse JSON, open sockets, or depend on an allocator.
//! It operates exclusively on caller-supplied byte slices.

#![no_std]
#![forbid(unsafe_code)]

use qhermes_channels::{
    KemCiphertext, KemDecapsulationKey, KemEncapsulationKey, SessionKey,
    CT_SIZE,
};
use qhermes_kernel::{
    read_credential_chain, verify_delegation, verify_signature, write_credential_chain,
    IdentitySigner, KernelError, PublicKey, Signature, Timestamp,
    Credential, SIG_SIZE, MAX_DEPTH, CREDENTIAL_FIXED_SIZE, MAX_PAYLOAD_SIZE,
};

// ── Error ──────────────────────────────────────────────────────────────────

/// Errors returned by `qhermes-a2a` operations.
#[derive(Debug, PartialEq, Eq)]
#[non_exhaustive]
pub enum A2AError {
    /// The input buffer is malformed or has an incorrect length.
    InputInvalid,
    /// A `qhermes-kernel` operation failed.
    Kernel(KernelError),
    /// A `qhermes-channels` operation failed.
    Channel(qhermes_channels::ChannelError),
}

impl From<KernelError> for A2AError {
    fn from(e: KernelError) -> Self {
        A2AError::Kernel(e)
    }
}

impl From<qhermes_channels::ChannelError> for A2AError {
    fn from(e: qhermes_channels::ChannelError) -> Self {
        A2AError::Channel(e)
    }
}

// ── Size constants ─────────────────────────────────────────────────────────

/// Maximum byte length of the authorization blob written by `seal_auth`.
///
/// Corresponds to the worst-case wire size of a credential chain at maximum depth.
pub const AUTH_BLOB_MAX: usize =
    1   // wire version
    + 4 // credential count
    + MAX_DEPTH as usize * (CREDENTIAL_FIXED_SIZE + MAX_PAYLOAD_SIZE);

/// Byte length of the KEM offer blob written by `kem_offer`:
/// `[ciphertext: CT_SIZE]`.
pub const KEM_OFFER_SIZE: usize = CT_SIZE;

// ── 1. Agent Card identity ─────────────────────────────────────────────────

/// Signs a canonicalized Agent Card payload with ML-DSA-65.
///
/// `card_bytes`: raw bytes to sign, typically the Agent Card JSON after applying
/// JCS (JSON Canonicalization Scheme, RFC 8785) or any canonical representation
/// agreed upon by the parties.
///
/// `sig_out`: must have at least `SIG_SIZE` (3309) bytes.
pub fn sign_agent_card(
    signer: &impl IdentitySigner,
    card_bytes: &[u8],
    sig_out: &mut [u8; SIG_SIZE],
) -> Result<(), A2AError> {
    signer.sign_into(card_bytes, sig_out).map_err(A2AError::Kernel)
}

/// Verifies an ML-DSA-65 signature over a canonicalized Agent Card payload.
///
/// `root_pk`: expected ML-DSA-65 public key of the agent.
/// `card_bytes`: the same bytes passed to `sign_agent_card`.
/// `sig`: `SIG_SIZE`-byte signature produced by `sign_agent_card`.
pub fn verify_agent_card(
    root_pk: PublicKey<'_>,
    card_bytes: &[u8],
    sig: &[u8; SIG_SIZE],
) -> Result<(), A2AError> {
    verify_signature(root_pk, card_bytes, Signature(sig)).map_err(A2AError::Kernel)
}

// ── 2. Authorization metadata (message.metadata blob) ─────────────────────

/// Serializes a QHermes credential chain into a caller-allocated buffer,
/// suitable for insertion into `message.metadata` (the caller applies base64 before embedding in JSON).
///
/// `chain`: slice of `Credential` records as returned by `qhermes_kernel::read_credential_chain`.
/// `out`: must have at least `AUTH_BLOB_MAX` bytes. Returns the number of bytes written.
pub fn seal_auth(
    chain: &[Credential<'_>],
    out: &mut [u8],
) -> Result<usize, A2AError> {
    write_credential_chain(out, chain).map_err(A2AError::Kernel)
}

/// Fully deserializes and verifies a QHermes authorization blob received in
/// `message.metadata`.
///
/// `root_pk`: public key of the trust root anchoring this chain.
/// `wire`: raw bytes of the authorization blob (after any base64 decoding the caller applied).
/// `now`: current Unix timestamp in **seconds**. Used to evaluate `not_before` and `not_after` caveats.
/// `chain_buf`: caller-allocated scratch buffer with at least `MAX_DEPTH` slots.
///
/// Returns the number of credentials in the verified chain on success.
pub fn verify_auth<'a>(
    root_pk: PublicKey<'_>,
    wire: &'a [u8],
    now: Timestamp,
    chain_buf: &mut [Credential<'a>],
) -> Result<usize, A2AError> {
    let n = read_credential_chain(wire, chain_buf)?;
    verify_delegation(root_pk, &chain_buf[..n], now)?;
    Ok(n)
}

// ── 3. Session KEM handshake ───────────────────────────────────────────────

/// Initiator side of the KEM handshake.
///
/// Encapsulates a fresh shared secret for `peer_ek` and writes a
/// `KEM_OFFER_SIZE`-byte blob into `out`.
///
/// The ciphertext must be delivered to the responder (e.g. via the first
/// `message.metadata` field in an A2A `message/send` call).
///
/// `context`: domain separation material; recommended to use a stable A2A
/// session or task identifier (e.g. the bytes of `contextId` or `taskId`).
/// May be empty.
///
/// Returns the `SessionKey` the initiator will use to encrypt subsequent messages.
pub fn kem_offer(
    peer_ek: &KemEncapsulationKey,
    context: &[u8],
    rng: &mut impl rand_core::CryptoRng,
    out: &mut [u8; KEM_OFFER_SIZE],
) -> Result<SessionKey, A2AError> {
    let (ct, session_key) = qhermes_channels::encapsulate(peer_ek, context, rng)?;
    out.copy_from_slice(ct.as_bytes());
    Ok(session_key)
}

/// Responder side of the KEM handshake.
///
/// Decapsulates the shared secret from the `KEM_OFFER_SIZE`-byte blob written
/// by `kem_offer`, producing the equivalent `SessionKey`.
///
/// `dk`: responder's decapsulation key (from `derive_kem_keypair`).
/// `offer`: `KEM_OFFER_SIZE`-byte blob received from the initiator.
/// `context`: must be identical to the value passed by the initiator.
///
/// Returns the `SessionKey` the responder will use to open/encrypt messages.
pub fn kem_accept(
    dk: &KemDecapsulationKey,
    offer: &[u8; KEM_OFFER_SIZE],
    context: &[u8],
) -> Result<SessionKey, A2AError> {
    let ct = KemCiphertext::from_bytes(*offer);
    qhermes_channels::decapsulate(dk, &ct, context).map_err(A2AError::Channel)
}

// ── Tests ─────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use qhermes_kernel::{
        BoundedCaveats, BoundedScope, DelegationManifest, Depth, IdentityIsland,
        IdentitySigner, KernelError, MAX_PAYLOAD_SIZE, PERM_TLV_MAX, Role, SIG_SIZE,
        Timestamp, MAX_DEPTH, SEED_SIZE,
        not_after, perm_tlv,
    };
    use qhermes_channels::{derive_kem_keypair, NONCE_SIZE, TAG_SIZE};

    extern crate std;
    use std::vec;
    use std::vec::Vec;
    use core::convert::Infallible;

    // ── Minimal deterministic test RNG ──
    //
    // Implements rand_core 0.10's TryRng + TryCryptoRng, giving us CryptoRng
    // via the blanket impl. Quality is irrelevant here; we just need KEM to run.

    struct XorShift64(u64);

    impl XorShift64 {
        fn step(&mut self) -> u64 {
            self.0 ^= self.0 << 13;
            self.0 ^= self.0 >> 7;
            self.0 ^= self.0 << 17;
            self.0
        }
    }

    impl rand_core::TryRng for XorShift64 {
        type Error = Infallible;

        fn try_next_u32(&mut self) -> Result<u32, Infallible> {
            Ok(self.step() as u32)
        }

        fn try_next_u64(&mut self) -> Result<u64, Infallible> {
            Ok(self.step())
        }

        fn try_fill_bytes(&mut self, dst: &mut [u8]) -> Result<(), Infallible> {
            let mut i = 0;
            while i < dst.len() {
                let b = self.step().to_le_bytes();
                let chunk = (dst.len() - i).min(8);
                dst[i..i + chunk].copy_from_slice(&b[..chunk]);
                i += chunk;
            }
            Ok(())
        }
    }

    impl rand_core::TryCryptoRng for XorShift64 {}

    fn test_rng() -> XorShift64 {
        XorShift64(0xFEED_FACE_CAFE_BABEu64)
    }

    // ── Helpers ──

    /// Derives a test IdentityIsland from a fixed master seed.
    fn make_identity(context: &[u8]) -> IdentityIsland {
        let master = [0xABu8; SEED_SIZE];
        IdentityIsland::derive(&master, b"a2a-test", context).unwrap()
    }

    /// Returns a single-permission TLV for (/a2a, CALL).
    fn make_scope() -> Vec<u8> {
        let mut buf = vec![0u8; PERM_TLV_MAX];
        let n = perm_tlv(b"/a2a", b"CALL", &mut buf).unwrap();
        buf.truncate(n);
        buf
    }

    /// Issues a single-hop credential and returns the serialized wire bytes.
    ///
    /// The root identity signs a credential granting the child identity the
    /// provided scope and caveats, and the resulting chain is serialized.
    fn build_auth_wire(
        root: &IdentityIsland,
        child_pk_bytes: &[u8; qhermes_kernel::PK_SIZE],
        scope_bytes: &[u8],
        caveat_bytes: &[u8],
        role: Role,
    ) -> Vec<u8> {
        let scope   = BoundedScope::try_new(scope_bytes).unwrap();
        let caveats = BoundedCaveats::try_new(caveat_bytes).unwrap();
        let manifest = DelegationManifest {
            child_pk: qhermes_kernel::PublicKey(child_pk_bytes),
            role,
            depth: Depth(1),
            scope,
            caveats,
        };
        let mut payload_buf = [0u8; MAX_PAYLOAD_SIZE];
        let mut sig_buf     = [0u8; SIG_SIZE];
        let payload_len =
            qhermes_kernel::issue_credential(root, &manifest, &mut payload_buf, &mut sig_buf)
                .unwrap();

        let cred = qhermes_kernel::Credential {
            issuer_pk: root.public_key(),
            signature: qhermes_kernel::Signature(&sig_buf),
            payload:   &payload_buf[..payload_len],
        };

        let mut wire = vec![0u8; AUTH_BLOB_MAX];
        let n = seal_auth(&[cred], &mut wire).unwrap();
        wire.truncate(n);
        wire
    }

    // ── sign_agent_card / verify_agent_card ──

    #[test]
    fn sign_verify_agent_card_ok() {
        let signer = make_identity(b"agent");
        let card = b"agent-card-canonical-bytes";
        let mut sig = [0u8; SIG_SIZE];
        sign_agent_card(&signer, card, &mut sig).unwrap();
        let result = verify_agent_card(signer.public_key(), card, &sig);
        assert!(result.is_ok());
    }

    #[test]
    fn sign_agent_card_is_deterministic() {
        let signer = make_identity(b"agent");
        let card = b"canonical-card";
        let mut sig1 = [0u8; SIG_SIZE];
        let mut sig2 = [0u8; SIG_SIZE];
        sign_agent_card(&signer, card, &mut sig1).unwrap();
        sign_agent_card(&signer, card, &mut sig2).unwrap();
        assert_eq!(sig1, sig2);
    }

    #[test]
    fn verify_agent_card_tampered_bytes_returns_error() {
        let signer = make_identity(b"agent");
        let card = b"genuine-card";
        let mut sig = [0u8; SIG_SIZE];
        sign_agent_card(&signer, card, &mut sig).unwrap();

        // Tamper with the card bytes.
        let tampered = b"tampered-card";
        let result = verify_agent_card(signer.public_key(), tampered, &sig);
        assert!(
            matches!(result, Err(A2AError::Kernel(KernelError::SignatureInvalid)))
                || matches!(result, Err(A2AError::Kernel(KernelError::SignatureDecodingFailed))),
            "expected SignatureInvalid or SignatureDecodingFailed, got {:?}",
            result
        );
    }

    #[test]
    fn verify_agent_card_tampered_signature_returns_error() {
        let signer = make_identity(b"agent");
        let card = b"original-card";
        let mut sig = [0u8; SIG_SIZE];
        sign_agent_card(&signer, card, &mut sig).unwrap();

        // Corrupt one byte of the signature.
        sig[500] ^= 0xFF;

        let result = verify_agent_card(signer.public_key(), card, &sig);
        assert!(
            matches!(result, Err(A2AError::Kernel(KernelError::SignatureInvalid)))
                || matches!(result, Err(A2AError::Kernel(KernelError::SignatureDecodingFailed))),
            "expected SignatureInvalid or SignatureDecodingFailed, got {:?}",
            result
        );
    }

    // ── seal_auth / verify_auth ──

    #[test]
    fn seal_then_verify_auth_single_credential_ok() {
        let root  = make_identity(b"root");
        let child = make_identity(b"child");
        let scope_bytes = make_scope();
        let child_pk = *child.public_key().0;

        let wire = build_auth_wire(&root, &child_pk, &scope_bytes, &[], Role::Leaf);

        let mut chain_buf: [qhermes_kernel::Credential; MAX_DEPTH as usize] =
            core::array::from_fn(|_| qhermes_kernel::Credential {
                issuer_pk: qhermes_kernel::PublicKey(&[0u8; qhermes_kernel::PK_SIZE]),
                signature: qhermes_kernel::Signature(&[0u8; SIG_SIZE]),
                payload:   &[],
            });

        let n = verify_auth(root.public_key(), &wire, Timestamp(0), &mut chain_buf).unwrap();
        assert_eq!(n, 1);
    }

    #[test]
    fn seal_auth_empty_chain_verify_returns_empty_chain() {
        // Serialize an empty chain, then verify should return EmptyChain.
        let mut wire = vec![0u8; 16];
        let n = seal_auth(&[], &mut wire).unwrap();
        wire.truncate(n);

        let mut chain_buf: [qhermes_kernel::Credential; MAX_DEPTH as usize] =
            core::array::from_fn(|_| qhermes_kernel::Credential {
                issuer_pk: qhermes_kernel::PublicKey(&[0u8; qhermes_kernel::PK_SIZE]),
                signature: qhermes_kernel::Signature(&[0u8; SIG_SIZE]),
                payload:   &[],
            });

        let root = make_identity(b"root");
        let result = verify_auth(root.public_key(), &wire, Timestamp(0), &mut chain_buf);
        assert!(matches!(result, Err(A2AError::Kernel(KernelError::EmptyChain))));
    }

    #[test]
    fn verify_auth_tampered_wire_returns_error() {
        let root  = make_identity(b"root");
        let child = make_identity(b"child");
        let scope_bytes = make_scope();
        let child_pk = *child.public_key().0;

        let mut wire = build_auth_wire(&root, &child_pk, &scope_bytes, &[], Role::Leaf);

        // Corrupt a byte well into the payload region.
        let mid = wire.len() / 2;
        wire[mid] ^= 0xFF;

        let mut chain_buf: [qhermes_kernel::Credential; MAX_DEPTH as usize] =
            core::array::from_fn(|_| qhermes_kernel::Credential {
                issuer_pk: qhermes_kernel::PublicKey(&[0u8; qhermes_kernel::PK_SIZE]),
                signature: qhermes_kernel::Signature(&[0u8; SIG_SIZE]),
                payload:   &[],
            });

        // Could be WireTruncated, WireInvalid, or a signature/scope error depending
        // on which byte was corrupted; we just require it is an error.
        let result = verify_auth(root.public_key(), &wire, Timestamp(0), &mut chain_buf);
        assert!(result.is_err(), "expected error from tampered wire, got Ok");
    }

    #[test]
    fn verify_auth_wrong_root_pk_returns_parent_key_mismatch() {
        let root  = make_identity(b"root");
        let wrong = make_identity(b"wrong-root");
        let child = make_identity(b"child");
        let scope_bytes = make_scope();
        let child_pk = *child.public_key().0;

        let wire = build_auth_wire(&root, &child_pk, &scope_bytes, &[], Role::Leaf);

        let mut chain_buf: [qhermes_kernel::Credential; MAX_DEPTH as usize] =
            core::array::from_fn(|_| qhermes_kernel::Credential {
                issuer_pk: qhermes_kernel::PublicKey(&[0u8; qhermes_kernel::PK_SIZE]),
                signature: qhermes_kernel::Signature(&[0u8; SIG_SIZE]),
                payload:   &[],
            });

        let result = verify_auth(wrong.public_key(), &wire, Timestamp(0), &mut chain_buf);
        assert!(matches!(result, Err(A2AError::Kernel(KernelError::ParentKeyMismatch))));
    }

    #[test]
    fn verify_auth_expired_caveat_returns_not_after_violation() {
        let root  = make_identity(b"root");
        let child = make_identity(b"child");
        let scope_bytes = make_scope();
        let child_pk = *child.public_key().0;

        // Credential expires at t=1000.
        let caveat = not_after(Timestamp(1000));
        let wire = build_auth_wire(&root, &child_pk, &scope_bytes, &caveat, Role::Leaf);

        let mut chain_buf: [qhermes_kernel::Credential; MAX_DEPTH as usize] =
            core::array::from_fn(|_| qhermes_kernel::Credential {
                issuer_pk: qhermes_kernel::PublicKey(&[0u8; qhermes_kernel::PK_SIZE]),
                signature: qhermes_kernel::Signature(&[0u8; SIG_SIZE]),
                payload:   &[],
            });

        // Evaluate at t=1001, after expiry.
        let result = verify_auth(root.public_key(), &wire, Timestamp(1001), &mut chain_buf);
        assert!(matches!(result, Err(A2AError::Kernel(KernelError::NotAfterViolation))));
    }

    #[test]
    fn verify_auth_truncated_wire_returns_wire_truncated() {
        let root  = make_identity(b"root");
        let child = make_identity(b"child");
        let scope_bytes = make_scope();
        let child_pk = *child.public_key().0;

        let wire = build_auth_wire(&root, &child_pk, &scope_bytes, &[], Role::Leaf);
        // Truncate to just the 5-byte header so credential body is missing.
        let truncated = &wire[..5];

        let mut chain_buf: [qhermes_kernel::Credential; MAX_DEPTH as usize] =
            core::array::from_fn(|_| qhermes_kernel::Credential {
                issuer_pk: qhermes_kernel::PublicKey(&[0u8; qhermes_kernel::PK_SIZE]),
                signature: qhermes_kernel::Signature(&[0u8; SIG_SIZE]),
                payload:   &[],
            });

        let result = verify_auth(root.public_key(), truncated, Timestamp(0), &mut chain_buf);
        assert!(matches!(result, Err(A2AError::Kernel(KernelError::WireTruncated))));
    }

    // ── kem_offer / kem_accept ──

    #[test]
    fn kem_offer_accept_full_handshake_session_keys_agree() {
        let seed = [0x11u8; 32];
        let kp   = derive_kem_keypair(&seed).unwrap();
        let context = b"task-id-xyz";

        let mut rng = test_rng();
        let mut offer_buf = [0u8; KEM_OFFER_SIZE];
        let sk_offer = kem_offer(&kp.encapsulation_key, context, &mut rng, &mut offer_buf).unwrap();
        let sk_accept = kem_accept(&kp.decapsulation_key, &offer_buf, context).unwrap();

        // Verify the session keys agree by seal/open round-trip.
        let nonce = [0u8; NONCE_SIZE];
        let plaintext = b"a2a-message-body";
        let mut ct_buf = vec![0u8; plaintext.len() + TAG_SIZE];
        let ct_len = sk_offer.seal(&nonce, plaintext, b"", &mut ct_buf).unwrap();

        let mut pt_buf = vec![0u8; plaintext.len()];
        let pt_len = sk_accept.open(&nonce, &ct_buf[..ct_len], b"", &mut pt_buf).unwrap();
        assert_eq!(&pt_buf[..pt_len], plaintext);
    }

    #[test]
    fn kem_offer_accept_different_context_session_keys_differ() {
        let seed = [0x11u8; 32];
        let kp   = derive_kem_keypair(&seed).unwrap();

        let mut rng = test_rng();
        let mut offer_buf = [0u8; KEM_OFFER_SIZE];
        let sk_offer = kem_offer(&kp.encapsulation_key, b"ctx-A", &mut rng, &mut offer_buf).unwrap();
        let sk_accept = kem_accept(&kp.decapsulation_key, &offer_buf, b"ctx-B").unwrap();

        // The session keys are derived from different contexts and must not agree.
        let nonce = [0u8; NONCE_SIZE];
        let plaintext = b"should not decrypt";
        let mut ct_buf = vec![0u8; plaintext.len() + TAG_SIZE];
        let ct_len = sk_offer.seal(&nonce, plaintext, b"", &mut ct_buf).unwrap();

        let mut pt_buf = vec![0u8; plaintext.len()];
        let result = sk_accept.open(&nonce, &ct_buf[..ct_len], b"", &mut pt_buf);
        assert!(
            matches!(result, Err(qhermes_channels::ChannelError::AuthenticationFailed)),
            "expected AuthenticationFailed when contexts differ, got {:?}",
            result
        );
    }

    #[test]
    fn kem_offer_writes_kem_offer_size_bytes() {
        let seed = [0x11u8; 32];
        let kp   = derive_kem_keypair(&seed).unwrap();
        let mut rng = test_rng();
        let mut offer_buf = [0u8; KEM_OFFER_SIZE];
        kem_offer(&kp.encapsulation_key, b"ctx", &mut rng, &mut offer_buf).unwrap();
        // The buffer is exactly KEM_OFFER_SIZE == CT_SIZE bytes; success implies
        // the full buffer was written.
        assert_eq!(offer_buf.len(), KEM_OFFER_SIZE);
    }
}
