"""DJ HUD — Lightweight screen/webcam region capture and virtual camera tool for DJs."""

__version__ = "0.7.7"
APP_NAME = "DJ HUD Builder"
