"""
Salim Audit Engine v19 — Queryable Action Log + Pattern Analysis

All autonomous actions, agent steps, and AI decisions are stored in SQLite.
Queryable by: date range, action type, success/failure, goal, agent, cost.

Unlike the JSONL append log, this is fully indexed and supports:
  - "What did Salim do last Tuesday?"
  - "Show all failed shell commands this week"
  - "How many tokens did I spend on AI calls today?"
  - "Which goals completed vs abandoned?"
  - "What's Salim's action success rate by type?"
  - Cross-session analytics with time bucketing

Commands:
  /audit last [n]              — last N actions (default 20)
  /audit today                 — today's actions
  /audit failed [type]         — recent failures
  /audit stats                 — success rates by action type
  /audit search <query>        — full-text search in action descriptions
  /audit cost                  — estimated token/API usage
  /audit goals                 — goal completion rates
  /audit export                — export as CSV to ~/Desktop
"""
from __future__ import annotations

import asyncio
import csv
import html
import json
import logging
import sqlite3
import time
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.audit")
esc = lambda v: html.escape(str(v), quote=False)
H = "HTML"

AUDIT_DB = Path.home() / ".salim" / "audit.db"


# ── DATABASE SCHEMA ───────────────────────────────────────────────────────────

def init_audit_db():
    with get_conn() as conn:
        conn.executescript("""
            CREATE TABLE IF NOT EXISTS actions (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                ts          REAL NOT NULL,
                ts_human    TEXT NOT NULL,
                session     TEXT DEFAULT '',
                source      TEXT DEFAULT 'autonomous',  -- autonomous|agent|user|planner
                action_type TEXT NOT NULL,
                description TEXT DEFAULT '',
                command     TEXT DEFAULT '',
                success     INTEGER DEFAULT 0,
                output      TEXT DEFAULT '',
                duration_ms INTEGER DEFAULT 0,
                cycle       INTEGER DEFAULT 0,
                goal        TEXT DEFAULT '',
                user_id     INTEGER DEFAULT 0,
                confidence  REAL DEFAULT -1,
                tokens_est  INTEGER DEFAULT 0
            );

            CREATE INDEX IF NOT EXISTS idx_ts         ON actions(ts);
            CREATE INDEX IF NOT EXISTS idx_action_type ON actions(action_type);
            CREATE INDEX IF NOT EXISTS idx_success    ON actions(success);
            CREATE INDEX IF NOT EXISTS idx_source     ON actions(source);

            CREATE TABLE IF NOT EXISTS ai_calls (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                ts          REAL NOT NULL,
                ts_human    TEXT NOT NULL,
                source      TEXT DEFAULT '',
                model       TEXT DEFAULT '',
                prompt_tokens   INTEGER DEFAULT 0,
                response_tokens INTEGER DEFAULT 0,
                duration_ms     INTEGER DEFAULT 0,
                success     INTEGER DEFAULT 1
            );

            CREATE INDEX IF NOT EXISTS idx_ai_ts ON ai_calls(ts);

            CREATE TABLE IF NOT EXISTS goals (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                ts_created  REAL NOT NULL,
                ts_updated  REAL,
                goal_text   TEXT NOT NULL,
                source      TEXT DEFAULT 'user',
                status      TEXT DEFAULT 'active',  -- active|completed|abandoned
                action_count INTEGER DEFAULT 0,
                user_id     INTEGER DEFAULT 0
            );
        """)


@contextmanager
def get_conn():
    conn = sqlite3.connect(str(AUDIT_DB))
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


# ── RECORD FUNCTIONS (called from other handlers) ─────────────────────────────

def record_action(
    action_type: str,
    description: str = "",
    command: str = "",
    success: bool = False,
    output: str = "",
    source: str = "autonomous",
    cycle: int = 0,
    goal: str = "",
    user_id: int = 0,
    confidence: float = -1,
    duration_ms: int = 0,
    tokens_est: int = 0,
):
    """Record a single action to the audit log."""
    try:
        init_audit_db()
        now = time.time()
        with get_conn() as conn:
            conn.execute(
                """INSERT INTO actions
                   (ts, ts_human, source, action_type, description, command,
                    success, output, duration_ms, cycle, goal, user_id, confidence, tokens_est)
                   VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    now,
                    datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    source, action_type,
                    description[:500], command[:500],
                    1 if success else 0,
                    output[:1000],
                    duration_ms, cycle, goal[:200],
                    user_id, confidence, tokens_est,
                ),
            )
    except Exception as e:
        logger.debug(f"Audit record failed: {e}")


def record_ai_call(
    source: str = "",
    model: str = "",
    prompt_tokens: int = 0,
    response_tokens: int = 0,
    duration_ms: int = 0,
    success: bool = True,
):
    """Record an AI API call to the audit log."""
    try:
        init_audit_db()
        with get_conn() as conn:
            conn.execute(
                """INSERT INTO ai_calls (ts, ts_human, source, model, prompt_tokens, response_tokens, duration_ms, success)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (time.time(), datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                 source, model, prompt_tokens, response_tokens, duration_ms, 1 if success else 0),
            )
    except Exception as e:
        logger.debug(f"AI call record failed: {e}")


# ── QUERY FUNCTIONS ───────────────────────────────────────────────────────────

def query_actions(
    hours: int = 24,
    action_type: str = "",
    success: Optional[bool] = None,
    source: str = "",
    limit: int = 50,
    search: str = "",
) -> list[sqlite3.Row]:
    """Query recent actions with optional filters."""
    try:
        init_audit_db()
        cutoff = time.time() - (hours * 3600)
        where = ["ts > ?"]
        params: list[Any] = [cutoff]
        if action_type:
            where.append("action_type = ?"); params.append(action_type)
        if success is not None:
            where.append("success = ?"); params.append(1 if success else 0)
        if source:
            where.append("source = ?"); params.append(source)
        if search:
            where.append("(description LIKE ? OR command LIKE ? OR output LIKE ?)")
            params.extend([f"%{search}%"] * 3)
        sql = f"SELECT * FROM actions WHERE {' AND '.join(where)} ORDER BY ts DESC LIMIT ?"
        params.append(limit)
        with get_conn() as conn:
            return conn.execute(sql, params).fetchall()
    except Exception as e:
        logger.debug(f"Query failed: {e}")
        return []


def get_stats(hours: int = 168) -> dict:  # default: last 7 days
    """Get action statistics by type."""
    try:
        init_audit_db()
        cutoff = time.time() - (hours * 3600)
        with get_conn() as conn:
            # Per-type stats
            type_stats = conn.execute(
                """SELECT action_type,
                          COUNT(*) as total,
                          SUM(success) as successes,
                          AVG(duration_ms) as avg_duration
                   FROM actions WHERE ts > ? GROUP BY action_type ORDER BY total DESC""",
                (cutoff,),
            ).fetchall()

            # Overall stats
            overall = conn.execute(
                """SELECT COUNT(*) as total, SUM(success) as successes,
                          AVG(duration_ms) as avg_duration
                   FROM actions WHERE ts > ?""",
                (cutoff,),
            ).fetchone()

            # AI usage
            ai_usage = conn.execute(
                """SELECT SUM(prompt_tokens) as prompt, SUM(response_tokens) as response,
                          COUNT(*) as calls FROM ai_calls WHERE ts > ?""",
                (cutoff,),
            ).fetchone()

        return {
            "type_stats": [dict(r) for r in type_stats],
            "overall": dict(overall) if overall else {},
            "ai_usage": dict(ai_usage) if ai_usage else {},
        }
    except Exception as e:
        logger.debug(f"Stats failed: {e}")
        return {}


def export_csv(hours: int = 168) -> Path:
    """Export recent actions to CSV on Desktop."""
    rows = query_actions(hours=hours, limit=10000)
    out = Path.home() / "Desktop" / f"salim_audit_{datetime.now().strftime('%Y%m%d_%H%M')}.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["ts_human", "source", "action_type", "description", "success", "output", "cycle", "goal"])
        for r in rows:
            writer.writerow([r["ts_human"], r["source"], r["action_type"],
                             r["description"], r["success"], r["output"][:200],
                             r["cycle"], r["goal"]])
    return out


# ── TELEGRAM COMMANDS ─────────────────────────────────────────────────────────

class AuditHandlers:

    @require_auth
    async def cmd_audit(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /audit last [n]        — last N actions
        /audit today           — today's actions
        /audit failed [type]   — recent failures
        /audit stats           — success rates
        /audit search <query>  — full-text search
        /audit cost            — API usage estimate
        /audit export          — export CSV
        """
        msg = update.effective_message
        args = ctx.args or []
        sub = args[0].lower() if args else "last"

        if sub == "last":
            n = int(args[1]) if len(args) > 1 and args[1].isdigit() else 20
            rows = query_actions(hours=168, limit=n)
            if not rows:
                await msg.reply_text("📋 No actions recorded yet.", parse_mode=H)
                return
            lines = [f"📋 <b>Last {len(rows)} Actions</b>\n"]
            for r in rows:
                icon = "✅" if r["success"] else "❌"
                ts = r["ts_human"][-8:]
                lines.append(f"{icon} <code>{ts}</code> [{r['action_type']}] {esc(r['description'][:60])}")
            await msg.reply_text("\n".join(lines[:30]), parse_mode=H)
            return

        if sub == "today":
            rows = query_actions(hours=24, limit=100)
            success = sum(1 for r in rows if r["success"])
            fail = len(rows) - success
            lines = [f"📅 <b>Today: {len(rows)} actions ({success}✅ {fail}❌)</b>\n"]
            for r in rows[:20]:
                icon = "✅" if r["success"] else "❌"
                ts = r["ts_human"][-8:]
                lines.append(f"{icon} <code>{ts}</code> [{r['action_type']}] {esc(r['description'][:55])}")
            await msg.reply_text("\n".join(lines), parse_mode=H)
            return

        if sub == "failed":
            atype = args[1] if len(args) > 1 else ""
            rows = query_actions(hours=168, success=False, action_type=atype, limit=20)
            if not rows:
                await msg.reply_text("✅ No failures in the past week!", parse_mode=H)
                return
            lines = [f"❌ <b>Recent Failures ({len(rows)})</b>\n"]
            for r in rows[:15]:
                lines.append(
                    f"<code>{r['ts_human'][-8:]}</code> [{r['action_type']}] {esc(r['description'][:50])}\n"
                    f"  <i>{esc(r['output'][:80])}</i>"
                )
            await msg.reply_text("\n".join(lines), parse_mode=H)
            return

        if sub == "stats":
            stats = get_stats(hours=168)
            overall = stats.get("overall", {})
            total = overall.get("total", 0) or 1
            success_count = overall.get("successes", 0) or 0
            rate = success_count / total * 100

            lines = [
                f"📊 <b>7-Day Action Stats</b>",
                f"Total: {total}  Success: {int(rate)}%\n",
                "<b>By type:</b>",
            ]
            for t in stats.get("type_stats", [])[:12]:
                t_total = t["total"] or 1
                t_rate = (t["successes"] or 0) / t_total * 100
                bar = "█" * int(t_rate / 10) + "░" * (10 - int(t_rate / 10))
                lines.append(f"  <code>{t['action_type']:15}</code> [{bar}] {int(t_rate)}% ({t['total']}x)")

            ai = stats.get("ai_usage", {})
            if ai.get("calls"):
                lines.append(f"\n🤖 AI calls: {ai['calls']} | ~{(ai.get('prompt_tokens',0) + ai.get('response_tokens',0)):,} tokens")

            await msg.reply_text("\n".join(lines), parse_mode=H)
            return

        if sub == "search":
            query = " ".join(args[1:])
            if not query:
                await msg.reply_text("Usage: <code>/audit search &lt;query&gt;</code>", parse_mode=H)
                return
            rows = query_actions(hours=720, search=query, limit=15)
            if not rows:
                await msg.reply_text(f"🔍 No results for: {esc(query)}", parse_mode=H)
                return
            lines = [f"🔍 <b>Search: {esc(query)}</b> ({len(rows)} results)\n"]
            for r in rows:
                icon = "✅" if r["success"] else "❌"
                lines.append(
                    f"{icon} <code>{r['ts_human'][:16]}</code> [{r['action_type']}]\n"
                    f"  {esc(r['description'][:80])}"
                )
            await msg.reply_text("\n".join(lines[:25]), parse_mode=H)
            return

        if sub == "cost":
            stats = get_stats(hours=720)
            ai = stats.get("ai_usage", {})
            prompt_t = ai.get("prompt", 0) or 0
            response_t = ai.get("response", 0) or 0
            calls = ai.get("calls", 0) or 0
            # Rough cost estimate (Claude Sonnet pricing)
            cost_est = (prompt_t / 1_000_000 * 3.0) + (response_t / 1_000_000 * 15.0)
            await msg.reply_text(
                f"💰 <b>30-Day AI Usage</b>\n\n"
                f"API calls: {calls:,}\n"
                f"Input tokens: ~{prompt_t:,}\n"
                f"Output tokens: ~{response_t:,}\n"
                f"Estimated cost: ~${cost_est:.4f}\n\n"
                f"<i>Costs based on Claude Sonnet pricing. Actual may vary by provider.</i>",
                parse_mode=H,
            )
            return

        if sub == "export":
            thinking = await msg.reply_text("📤 <i>Exporting…</i>", parse_mode=H)
            out = export_csv(hours=720)
            await thinking.edit_text(
                f"✅ Exported to:\n<code>{esc(str(out))}</code>",
                parse_mode=H,
            )
            return

        await msg.reply_text(
            "📋 <b>Audit Log</b>\n\n"
            "<code>/audit last [n]</code>       — last N actions\n"
            "<code>/audit today</code>           — today's actions\n"
            "<code>/audit failed [type]</code>   — recent failures\n"
            "<code>/audit stats</code>           — success rates by type\n"
            "<code>/audit search &lt;q&gt;</code>— full-text search\n"
            "<code>/audit cost</code>            — AI token usage\n"
            "<code>/audit export</code>          — export CSV to Desktop",
            parse_mode=H,
        )
