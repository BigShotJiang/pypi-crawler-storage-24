"""
Salim Autonomous Engine v17 — True Zero-Intervention Full Laptop Management
============================================================================
Salim IS the user's laptop. No human intervention needed. Ever.

OBSERVE → THINK → PLAN → ACT → SELF-HEAL → REFLECT → SLEEP

Full action capabilities:
  shell          — run any bash/cmd command
  python         — run Python code inline
  browse         — fetch+read web page content (httpx)
  browse_click   — Playwright: click element on live page
  browse_type    — Playwright: type into field
  browse_js      — Playwright: run JavaScript on page
  browse_screenshot — Playwright: screenshot current page
  file_write     — write file to disk
  file_read      — read file from disk
  file_delete    — delete a file safely
  email_read     — read inbox emails
  email_send     — compose + send real email
  email_reply    — reply to email by uid
  email_search   — search inbox
  media_play     — play audio/video file or URL via mpv/vlc
  media_stop     — stop currently playing media
  screen_type    — type text on screen via xdotool/pyautogui
  screen_key     — press key combo on screen
  screen_click   — click screen at x,y or find+click element
  screen_scroll  — scroll up/down
  screen_screenshot — full screenshot, analysed with AI
  notify         — desktop notification
  pip_install    — install Python packages
  apt_install    — install system packages
  open_app       — open application by name
  clipboard_read — read clipboard
  clipboard_write— write to clipboard
  http_request   — make HTTP GET/POST to any API
  write_document — write .txt/.md/.docx document to disk
  calendar_read  — read system calendar / .ics files
  report         — narrate status (no action)
  skip           — do nothing this cycle

Commands:
  /auto on              — enable full autonomy
  /auto off             — pause
  /auto status          — current state
  /auto interval <mins> — wake-up interval (default 10)
  /auto goal <text>     — add a standing goal
  /auto goals           — list goals
  /auto dgoal <n>       — delete goal #n
  /auto log [n]         — action history
  /auto think           — trigger immediate cycle
  /auto report          — full environment report
  /auto memory          — show learned facts
  /auto clearmem        — clear memory
"""
from __future__ import annotations

import asyncio
import html
import json
import logging
import os
import platform
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Optional

from telegram import Update
from telegram.ext import Application, ContextTypes

from salim.auth import require_auth
from salim.db import memory_get, memory_set, agent_run_start, agent_run_update

logger = logging.getLogger("salim.autonomous")
esc = lambda v: html.escape(str(v), quote=False)
H = "HTML"

# ══════════════════════════════════════════════════════════════════════════════
#  CONFIG
# ══════════════════════════════════════════════════════════════════════════════

AUTO_DIR       = Path.home() / ".salim" / "autonomous"
STATE_FILE     = AUTO_DIR / "state.json"
LOG_FILE       = AUTO_DIR / "action_log.jsonl"
GOALS_FILE     = AUTO_DIR / "goals.json"
MEMORY_FILE    = AUTO_DIR / "long_memory.json"
MEDIA_PID_FILE = AUTO_DIR / "media_pid"

AUTO_DIR.mkdir(parents=True, exist_ok=True)

DEFAULT_INTERVAL      = 10
MAX_LOG_ENTRIES       = 500
MAX_ACTIONS_PER_CYCLE = 10

# ══════════════════════════════════════════════════════════════════════════════
#  STATE HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _load_state() -> dict:
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text())
        except Exception:
            pass
    return {
        "enabled": False, "interval_mins": DEFAULT_INTERVAL,
        "last_cycle": None, "cycle_count": 0,
        "chat_id": None, "user_id": None,
        "current_plan": None, "last_action": None, "paused_until": None,
    }

def _save_state(state: dict):
    STATE_FILE.write_text(json.dumps(state, indent=2))

def _load_goals() -> list[dict]:
    if GOALS_FILE.exists():
        try:
            return json.loads(GOALS_FILE.read_text())
        except Exception:
            pass
    return []

def _save_goals(goals: list[dict]):
    GOALS_FILE.write_text(json.dumps(goals, indent=2))

def _load_memory() -> dict:
    if MEMORY_FILE.exists():
        try:
            return json.loads(MEMORY_FILE.read_text())
        except Exception:
            pass
    return {"facts": [], "patterns": [], "preferences": {}, "past_successes": [], "past_failures": []}

def _save_memory(mem: dict):
    MEMORY_FILE.write_text(json.dumps(mem, indent=2))

def _append_log(entry: dict):
    entry["ts"] = datetime.now().isoformat()
    with open(LOG_FILE, "a") as f:
        f.write(json.dumps(entry) + "\n")
    try:
        lines = LOG_FILE.read_text().strip().splitlines()
        if len(lines) > MAX_LOG_ENTRIES:
            LOG_FILE.write_text("\n".join(lines[-MAX_LOG_ENTRIES:]) + "\n")
    except Exception:
        pass

def _read_log(n: int = 20) -> list[dict]:
    if not LOG_FILE.exists():
        return []
    try:
        lines = LOG_FILE.read_text().strip().splitlines()
        return [json.loads(l) for l in lines[-n:] if l]
    except Exception:
        return []

# ══════════════════════════════════════════════════════════════════════════════
#  OBSERVER — complete system snapshot
# ══════════════════════════════════════════════════════════════════════════════

def _observe() -> dict:
    obs: dict[str, Any] = {
        "timestamp": datetime.now().isoformat(),
        "os":        platform.system(),
        "hostname":  platform.node(),
        "python":    sys.version.split()[0],
    }

    try:
        import psutil
        cpu = psutil.cpu_percent(interval=0.5)
        mem = psutil.virtual_memory()
        obs.update({
            "cpu_pct":      cpu,
            "ram_pct":      mem.percent,
            "ram_free_gb":  round(mem.available / 1e9, 2),
            "ram_total_gb": round(mem.total / 1e9, 2),
        })

        disk_info = []
        for part in psutil.disk_partitions(all=False):
            try:
                usage = psutil.disk_usage(part.mountpoint)
                disk_info.append({
                    "mount": part.mountpoint, "pct": usage.percent,
                    "free_gb": round(usage.free / 1e9, 2),
                    "total_gb": round(usage.total / 1e9, 2),
                })
            except Exception:
                pass
        obs["disks"] = disk_info

        batt = psutil.sensors_battery()
        if batt:
            obs["battery_pct"]      = round(batt.percent, 1)
            obs["battery_charging"] = batt.power_plugged

        obs["uptime_hours"] = round((time.time() - psutil.boot_time()) / 3600, 1)

        procs = []
        for p in psutil.process_iter(["pid", "name", "cpu_percent", "memory_percent", "status"]):
            try:
                procs.append(p.info)
            except Exception:
                pass
        obs["top_processes"] = sorted(procs, key=lambda x: x.get("cpu_percent", 0), reverse=True)[:8]
        obs["zombie_count"]  = sum(1 for p in procs if p.get("status") == "zombie")

        net = psutil.net_io_counters()
        obs["net_bytes_sent_mb"] = round(net.bytes_sent / 1e6, 1)
        obs["net_bytes_recv_mb"] = round(net.bytes_recv / 1e6, 1)
    except Exception as e:
        obs["psutil_error"] = str(e)

    # Pip packages
    try:
        r = subprocess.run([sys.executable, "-m", "pip", "list", "--format=freeze"],
                           capture_output=True, text=True, timeout=10)
        obs["pip_packages_count"] = len(r.stdout.strip().splitlines())
    except Exception:
        pass

    # Linux apt updates
    try:
        if platform.system() == "Linux" and shutil.which("apt"):
            r = subprocess.run(["apt", "list", "--upgradeable", "--quiet"],
                               capture_output=True, text=True, timeout=15)
            obs["apt_upgradeable"] = len([l for l in r.stdout.splitlines() if "/" in l])
    except Exception:
        pass

    # Tool inventory
    tools_ok, tools_missing = [], []
    for t in ["git", "ffmpeg", "yt-dlp", "aria2c", "docker", "npm", "node",
              "mpv", "vlc", "xdotool", "xclip", "xsel", "notify-send",
              "scrot", "calcurse", "playwright"]:
        (tools_ok if shutil.which(t) else tools_missing).append(t)
    obs["tools_present"] = tools_ok
    obs["tools_missing"]  = tools_missing

    # Recent Salim log errors
    try:
        log_path = Path.home() / ".salim" / "salim.log"
        if log_path.exists():
            recent = log_path.read_text()[-3000:]
            obs["recent_errors"] = [l for l in recent.splitlines()
                                    if "ERROR" in l or "CRITICAL" in l][-5:]
    except Exception:
        pass

    # Temp dir size
    try:
        import tempfile
        td = Path(tempfile.gettempdir())
        obs["tmp_dir_size_mb"] = round(
            sum(f.stat().st_size for f in td.rglob("*") if f.is_file()) / 1e6, 1)
    except Exception:
        pass

    # Email unread count
    try:
        from salim.handlers.email_handler import _get_default_account, _imap_connect
        acc = _get_default_account()
        if acc:
            conn = _imap_connect(acc)
            conn.select("INBOX")
            _, data = conn.search(None, "UNSEEN")
            obs["email_unread"] = len(data[0].split())
            conn.logout()
    except Exception:
        pass

    # Media playing?
    try:
        if MEDIA_PID_FILE.exists():
            pid = int(MEDIA_PID_FILE.read_text().strip())
            import psutil
            if psutil.pid_exists(pid):
                obs["media_playing_pid"] = pid
            else:
                MEDIA_PID_FILE.unlink(missing_ok=True)
    except Exception:
        pass

    return obs


# ══════════════════════════════════════════════════════════════════════════════
#  AI THINK — system prompt with all 28 action types
# ══════════════════════════════════════════════════════════════════════════════

THINK_SYSTEM = """You are Salim — a fully autonomous AI agent. You ARE the user's laptop.
You manage everything: email, files, media, browser, screen, system — with ZERO human input.
Be a proactive, intelligent laptop operator. Think like a competent human assistant.

CHAIN OF THOUGHT — you MUST reason before acting. Your JSON must include a "reasoning" field
that shows your explicit thinking process BEFORE deciding on actions. This is not optional.
Think through: (1) what the situation actually is, (2) what the highest-leverage action is,
(3) what could go wrong, (4) whether you have enough information to act or need to gather first.

You MUST respond ONLY with a valid JSON object (no markdown, no extra text):
{
  "reasoning": "Step-by-step analysis: [1] What I observe... [2] What matters most... [3] Risk if I act... [4] Decision: ...",
  "assessment": "one-line description of current situation",
  "confidence": 0.85,
  "priority": "critical|high|medium|low",
  "information_needed": ["list any info gaps that would change the decision, or empty list"],
  "actions": [
    {
      "type": "<action_type>",
      "description": "plain English: what this does",
      "command": "<formatted command — see below>",
      "expected_outcome": "what will happen",
      "risk": "low|medium|high"
    }
  ],
  "memory_updates": { "key": "value to remember" },
  "next_focus": "what to focus on next cycle"
}

ACTION TYPES — command format:
  shell           → bash command string (non-interactive)
  python          → Python source code string
  browse          → URL to fetch and read as plain text
  browse_click    → CSS selector OR "text:Button Label" to click in active browser
  browse_type     → "css_selector|||text to type"
  browse_js       → JavaScript string to evaluate in active page
  browse_screenshot → "" (screenshots current Playwright page)
  file_write      → "absolute/path.ext|||file content here"
  file_read       → absolute path string
  file_delete     → absolute path string (safe: trash for large files)
  email_read      → number as string e.g. "10" (reads that many recent emails)
  email_send      → "recipient@email.com|||Subject Line|||Email body text"
  email_reply     → "email_uid|||Reply body text"
  email_search    → search query string
  media_play      → file path OR YouTube/web URL
  media_stop      → "" (stops all media players)
  screen_type     → text to type at current focus
  screen_key      → key combo e.g. "ctrl+s", "Return", "super+d", "alt+F4"
  screen_click    → "x,y" pixel coords OR "text:Window Title"
  screen_scroll   → "up" or "down" or pixel amount as string
  screen_screenshot → "" (captures full screen, returns to Telegram)
  notify          → "Notification Title|||Body message"
  pip_install     → package name(s) e.g. "requests" or "numpy pandas"
  apt_install     → package name e.g. "mpv" or "xdotool"
  open_app        → application name e.g. "firefox", "gedit", "gnome-terminal"
  clipboard_read  → "" (reads current clipboard)
  clipboard_write → text to put in clipboard
  http_request    → "GET|||https://api.example.com/path" or "POST|||url|||{json_body}"
  write_document  → "/home/user/docs/report.md|||# Title\n\nContent..."
  calendar_read   → "" (reads upcoming events from system calendar)
  report          → status message string (no action, just inform)
  skip            → "" (nothing to do this cycle)

STANDING PRINCIPLES:
- ALWAYS fill "reasoning" with genuine step-by-step thinking before deciding actions
- Use "information_needed" to list gaps — if critical info is missing, use file_read/shell to gather it first
- Every cycle: check for unread email, summarise important ones to Telegram
- Keep CPU < 85%, RAM < 90%, disk > 10% free — act immediately if exceeded
- Kill zombie processes automatically
- If email_unread > 0: read and summarise them proactively
- If goals are set: actively work toward them using appropriate actions
- Be decisive — do not ask the user anything, decide yourself
- All shell commands must be non-interactive (no prompts, no sudo for destructive ops)
- Maximum 10 actions per cycle; prefer fewer, higher-confidence actions
- Set confidence 0.0-1.0 honestly — low confidence means information_needed is non-empty
- Use memory_updates to remember facts across cycles
- NEVER: rm -rf /, mkfs, dd if=, wget | sh, chmod 777 /
"""


async def _ai_think(obs: dict, goals: list[dict], long_memory: dict, config) -> Optional[dict]:
    from salim.ai import SalimAI
    ai = SalimAI(config)

    goals_text = "\n".join(
        f"  [{i+1}] {g['text']} (priority: {g.get('priority','normal')})"
        for i, g in enumerate(goals)
    ) or "  (no goals set — manage system health and be proactively useful)"

    mem_text = (json.dumps(long_memory.get("facts", [])[:15], indent=2)
                if long_memory.get("facts") else "none")

    # v19: Semantic observation diff — what CHANGED since last cycle?
    prev_obs = long_memory.get("_prev_obs", {})
    obs_diff = {}
    for key in ("cpu_pct", "ram_pct", "email_unread", "zombie_count", "battery_pct"):
        prev = prev_obs.get(key)
        curr = obs.get(key)
        if prev is not None and curr is not None and abs(float(curr) - float(prev)) > 2:
            obs_diff[key] = {"prev": prev, "now": curr, "delta": round(float(curr) - float(prev), 1)}
    obs_diff_text = json.dumps(obs_diff) if obs_diff else "none significant"

    # v19: Long-horizon plan injection
    plan_context = ""
    try:
        state = _load_state()
        user_id = state.get("user_id")
        if user_id:
            from salim.handlers.planner import get_active_plan, get_current_context
            active_plan = get_active_plan(user_id)
            if active_plan:
                plan_context = get_current_context(active_plan)
    except Exception:
        pass

    # v19: Reflections from previous cycles
    reflections = long_memory.get("reflections", [])
    reflection_text = reflections[-1]["text"] if reflections else "none"

    user_prompt = f"""CURRENT SYSTEM STATE:
{json.dumps(obs, indent=2)}

CHANGES SINCE LAST CYCLE (semantic diff):
{obs_diff_text}

STANDING GOALS:
{goals_text}

LONG-TERM MEMORY (from previous cycles):
{mem_text}

LAST REFLECTION:
{reflection_text}
{plan_context}
CURRENT TIME: {datetime.now().strftime('%A %Y-%m-%d %H:%M')}

Analyze everything. What should I do right now? Return your JSON action plan."""

    try:
        response = await ai.chat(
            messages=[{"role": "user", "content": user_prompt}],
            system=THINK_SYSTEM,
            max_tokens=2000,
        )
        text = response.strip()
        if "```" in text:
            text = re.sub(r"```(?:json)?\s*", "", text).replace("```", "").strip()
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            return json.loads(match.group())
    except Exception as e:
        logger.error(f"AI think failed: {e}")
    return None


# ══════════════════════════════════════════════════════════════════════════════
#  ACTION EXECUTOR — all 28 action types
# ══════════════════════════════════════════════════════════════════════════════

BLOCKED_SHELL = [
    r"rm\s+-rf\s+/[^/]", r"mkfs", r"dd\s+if=",
    r":\(\)\{.*\}", r"wget.*\|\s*sh", r"curl.*\|\s*bash",
    r"chmod\s+777\s+/", r">\s*/dev/sda", r"format\s+[a-zA-Z]:",
]


async def _execute_action(action: dict) -> dict:
    atype  = action.get("type", "skip")
    cmd    = action.get("command", "")
    desc   = action.get("description", "")
    result = {"type": atype, "description": desc, "success": False, "output": ""}

    try:

        # ── shell ──────────────────────────────────────────────────────────
        if atype == "shell":
            for pat in BLOCKED_SHELL:
                if re.search(pat, cmd, re.IGNORECASE):
                    result["output"] = "BLOCKED: matches safety filter"
                    return result
            proc = await asyncio.create_subprocess_shell(
                cmd, stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                env={**os.environ, "DEBIAN_FRONTEND": "noninteractive"},
            )
            try:
                out, _ = await asyncio.wait_for(proc.communicate(), timeout=90)
                output = out.decode("utf-8", errors="replace").strip()
                result["success"]    = proc.returncode == 0
                result["output"]     = output[:2000] or "(no output)"
                result["returncode"] = proc.returncode
            except asyncio.TimeoutError:
                proc.kill()
                result["output"] = "TIMEOUT after 90s"

        # ── python ─────────────────────────────────────────────────────────
        elif atype == "python":
            proc = await asyncio.create_subprocess_exec(
                sys.executable, "-c", cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
            )
            try:
                out, _ = await asyncio.wait_for(proc.communicate(), timeout=60)
                output = out.decode("utf-8", errors="replace").strip()
                result["success"] = proc.returncode == 0
                result["output"]  = output[:2000] or "(no output)"
            except asyncio.TimeoutError:
                proc.kill()
                result["output"] = "TIMEOUT after 60s"

        # ── pip install ────────────────────────────────────────────────────
        elif atype == "pip_install":
            pkg = cmd.strip()
            packages = pkg.split()
            proc = await asyncio.create_subprocess_exec(
                sys.executable, "-m", "pip", "install", "--quiet",
                "--disable-pip-version-check", "--break-system-packages", *packages,
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
            )
            try:
                out, _ = await asyncio.wait_for(proc.communicate(), timeout=120)
                result["success"] = proc.returncode == 0
                result["output"]  = f"pip install {pkg}: {'OK' if result['success'] else 'FAILED'}"
            except asyncio.TimeoutError:
                proc.kill()
                result["output"] = "pip install timed out"

        # ── apt install ────────────────────────────────────────────────────
        elif atype == "apt_install":
            pkg = cmd.strip()
            proc = await asyncio.create_subprocess_exec(
                "sudo", "apt-get", "install", "-y", "-q", pkg,
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
                env={**os.environ, "DEBIAN_FRONTEND": "noninteractive"},
            )
            try:
                out, _ = await asyncio.wait_for(proc.communicate(), timeout=180)
                result["success"] = proc.returncode == 0
                result["output"]  = f"apt install {pkg}: {'OK' if result['success'] else 'FAILED'}"
            except asyncio.TimeoutError:
                proc.kill()
                result["output"] = "apt install timed out"

        # ── file write ─────────────────────────────────────────────────────
        elif atype == "file_write":
            parts = cmd.split("|||", 1)
            if len(parts) == 2:
                fpath, content = parts
                p = Path(fpath.strip()).expanduser()
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(content)
                result["success"] = True
                result["output"]  = f"Written {len(content)} chars to {p}"
            else:
                result["output"] = "Invalid file_write — need: path|||content"

        # ── file read ──────────────────────────────────────────────────────
        elif atype == "file_read":
            p = Path(cmd.strip()).expanduser()
            if p.exists():
                result["success"] = True
                result["output"]  = p.read_text(errors="replace")[:3000]
            else:
                result["output"] = f"File not found: {p}"

        # ── file delete ────────────────────────────────────────────────────
        elif atype == "file_delete":
            p = Path(cmd.strip()).expanduser()
            if p.exists():
                if p.stat().st_size < 1_000_000 or p.suffix in {".tmp", ".log", ".bak", ".cache"}:
                    p.unlink()
                    result["success"] = True
                    result["output"]  = f"Deleted: {p}"
                else:
                    trash = Path.home() / ".salim" / "trash"
                    trash.mkdir(exist_ok=True)
                    dest = trash / (p.name + "." + datetime.now().strftime("%Y%m%d%H%M%S"))
                    p.rename(dest)
                    result["success"] = True
                    result["output"]  = f"Moved to trash: {dest}"
            else:
                result["output"] = f"File not found: {p}"

        # ── write document ─────────────────────────────────────────────────
        elif atype == "write_document":
            parts = cmd.split("|||", 1)
            if len(parts) == 2:
                fpath, content = parts
                p = Path(fpath.strip()).expanduser()
                p.parent.mkdir(parents=True, exist_ok=True)
                if p.suffix == ".docx":
                    try:
                        from docx import Document as DocxDocument
                        doc = DocxDocument()
                        for line in content.split("\n"):
                            line = line.strip()
                            if line.startswith("# "):
                                doc.add_heading(line[2:], level=1)
                            elif line.startswith("## "):
                                doc.add_heading(line[3:], level=2)
                            elif line.startswith("### "):
                                doc.add_heading(line[4:], level=3)
                            elif line.startswith("- ") or line.startswith("* "):
                                doc.add_paragraph(line[2:], style="List Bullet")
                            elif line:
                                doc.add_paragraph(line)
                        doc.save(str(p))
                        result["success"] = True
                        result["output"]  = f"DOCX written: {p}"
                    except ImportError:
                        p.write_text(content)
                        result["success"] = True
                        result["output"]  = f"Written as plain text (python-docx not installed): {p}"
                else:
                    p.write_text(content)
                    result["success"] = True
                    result["output"]  = f"Document written: {p} ({len(content)} chars)"
            else:
                result["output"] = "Invalid write_document — need: path|||content"

        # ── browse (httpx, read content) ───────────────────────────────────
        elif atype == "browse":
            try:
                import httpx
                async with httpx.AsyncClient(follow_redirects=True, timeout=20, verify=False) as c:
                    r = await c.get(cmd.strip(), headers={"User-Agent": "Mozilla/5.0"})
                text = re.sub(r"<[^>]+>", " ", r.text)
                text = re.sub(r"\s+", " ", text).strip()[:3000]
                result["success"] = r.status_code < 400
                result["output"]  = f"HTTP {r.status_code}\n{text}"
            except Exception as e:
                result["output"] = f"Browse failed: {e}"

        # ── Playwright browser actions ─────────────────────────────────────
        elif atype in ("browse_click", "browse_type", "browse_js", "browse_screenshot"):
            try:
                from salim.handlers.browser2 import _sessions
                session = _sessions.get(0)
                if session is None or not getattr(session, "_page", None):
                    result["output"] = ("No active Playwright session. "
                                        "Use 'browse' action to navigate to a URL first, "
                                        "or open browser with /browse <url>.")
                    return result

                page = session._page

                if atype == "browse_click":
                    selector = cmd.strip()
                    if selector.startswith("text:"):
                        await page.get_by_text(selector[5:]).first.click(timeout=8000)
                    else:
                        await page.click(selector, timeout=8000)
                    result["success"] = True
                    result["output"]  = f"Clicked: {selector}"

                elif atype == "browse_type":
                    parts = cmd.split("|||", 1)
                    if len(parts) == 2:
                        sel, text = parts
                        await page.fill(sel.strip(), text, timeout=8000)
                        result["success"] = True
                        result["output"]  = f"Typed '{text[:30]}' into {sel}"
                    else:
                        result["output"] = "browse_type needs: selector|||text"

                elif atype == "browse_js":
                    ret = await page.evaluate(cmd)
                    result["success"] = True
                    result["output"]  = str(ret)[:1000]

                elif atype == "browse_screenshot":
                    import io
                    buf = await page.screenshot(full_page=False, type="jpeg", quality=80)
                    result["success"] = True
                    result["output"]  = f"Browser screenshot: {len(buf)} bytes"
                    result["_screenshot_bytes"] = buf

            except Exception as e:
                result["output"] = f"Browser action failed: {e}"

        # ── email read ─────────────────────────────────────────────────────
        elif atype == "email_read":
            try:
                from salim.handlers.email_handler import _get_default_account, _imap_fetch_emails
                acc = _get_default_account()
                if not acc:
                    result["output"] = ("No email account configured. "
                                        "Ask user to run /email setup first.")
                    return result
                limit = int(cmd.strip()) if cmd.strip().isdigit() else 10
                emails = _imap_fetch_emails(acc, limit=limit)
                lines = []
                for i, e in enumerate(emails, 1):
                    frm  = e.get("from", "?")[:40]
                    subj = e.get("subject", "(no subject)")[:60]
                    date = e.get("date", "")[:16]
                    unrd = "🔵" if e.get("unread") else "  "
                    uid  = e.get("uid", "")
                    lines.append(f"{unrd}[{i}|uid:{uid}] {date} | {frm} | {subj}")
                result["success"] = True
                result["output"]  = f"Inbox ({len(emails)} emails):\n" + "\n".join(lines)
            except Exception as e:
                result["output"] = f"Email read failed: {e}"

        # ── email send ─────────────────────────────────────────────────────
        elif atype == "email_send":
            parts = cmd.split("|||", 2)
            if len(parts) == 3:
                to_addr, subject, body = parts
                try:
                    from salim.handlers.email_handler import _get_default_account, _smtp_send
                    acc = _get_default_account()
                    if not acc:
                        result["output"] = "No email account configured."
                        return result
                    _smtp_send(acc, to=to_addr.strip(), subject=subject.strip(), body=body.strip())
                    result["success"] = True
                    result["output"]  = f"Email sent to {to_addr.strip()}"
                except Exception as e:
                    result["output"] = f"Email send failed: {e}"
            else:
                result["output"] = "email_send needs: to@addr|||Subject|||Body"

        # ── email reply ────────────────────────────────────────────────────
        elif atype == "email_reply":
            parts = cmd.split("|||", 1)
            if len(parts) == 2:
                uid, body = parts
                try:
                    from salim.handlers.email_handler import (
                        _get_default_account, _imap_fetch_full, _smtp_send)
                    acc = _get_default_account()
                    if not acc:
                        result["output"] = "No email account configured."
                        return result
                    original = _imap_fetch_full(acc, uid.strip())
                    if original:
                        reply_to = original.get("reply_to") or original.get("from", "")
                        subj     = original.get("subject", "")
                        subject  = subj if subj.startswith("Re:") else f"Re: {subj}"
                        _smtp_send(acc, to=reply_to, subject=subject, body=body.strip())
                        result["success"] = True
                        result["output"]  = f"Replied to {reply_to}"
                    else:
                        result["output"] = f"Email UID {uid} not found in inbox"
                except Exception as e:
                    result["output"] = f"Email reply failed: {e}"
            else:
                result["output"] = "email_reply needs: uid|||body"

        # ── email search ───────────────────────────────────────────────────
        elif atype == "email_search":
            try:
                from salim.handlers.email_handler import _get_default_account, _imap_search
                acc = _get_default_account()
                if not acc:
                    result["output"] = "No email account configured."
                    return result
                emails = _imap_search(acc, cmd.strip(), limit=10)
                lines = [
                    f"[{i+1}|uid:{e.get('uid','')}] {e.get('date','')[:16]} | "
                    f"{e.get('from','?')[:30]} | {e.get('subject','')[:50]}"
                    for i, e in enumerate(emails)
                ]
                result["success"] = True
                result["output"]  = (f"Search '{cmd}' → {len(emails)} results:\n"
                                     + "\n".join(lines))
            except Exception as e:
                result["output"] = f"Email search failed: {e}"

        # ── media play ─────────────────────────────────────────────────────
        elif atype == "media_play":
            target = cmd.strip()
            player = None
            for p in ["mpv", "vlc", "mplayer", "cvlc"]:
                if shutil.which(p):
                    player = p
                    break

            if not player:
                result["output"] = "No media player found. Install mpv: sudo apt install mpv"
                return result

            is_url = target.startswith("http://") or target.startswith("https://")

            try:
                if is_url:
                    args = [player, target]
                else:
                    p = Path(target).expanduser()
                    if not p.exists():
                        result["output"] = f"Media file not found: {p}"
                        return result
                    args = [player, str(p)]

                proc = subprocess.Popen(
                    args,
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                    start_new_session=True,
                )
                MEDIA_PID_FILE.write_text(str(proc.pid))
                result["success"] = True
                result["output"]  = f"Playing with {player} (PID {proc.pid}): {target[:80]}"
            except Exception as e:
                result["output"] = f"Media play failed: {e}"

        # ── media stop ─────────────────────────────────────────────────────
        elif atype == "media_stop":
            stopped = False
            for pname in ["mpv", "vlc", "mplayer", "ffplay", "cvlc"]:
                r = subprocess.run(["pkill", "-f", pname], capture_output=True)
                if r.returncode == 0:
                    stopped = True
            MEDIA_PID_FILE.unlink(missing_ok=True)
            result["success"] = True
            result["output"]  = "Media stopped." if stopped else "No media player was running."

        # ── screen type ────────────────────────────────────────────────────
        elif atype == "screen_type":
            text = cmd
            success = False
            if shutil.which("xdotool"):
                r = subprocess.run(
                    ["xdotool", "type", "--clearmodifiers", "--", text],
                    capture_output=True, timeout=10
                )
                success = r.returncode == 0
            if not success:
                try:
                    import pyautogui
                    pyautogui.write(text, interval=0.02)
                    success = True
                except ImportError:
                    pass
            result["success"] = success
            result["output"]  = (f"Typed: {text[:50]}" if success
                                  else "screen_type failed: install xdotool or pyautogui")

        # ── screen key ─────────────────────────────────────────────────────
        elif atype == "screen_key":
            key = cmd.strip()
            success = False
            if shutil.which("xdotool"):
                r = subprocess.run(["xdotool", "key", "--clearmodifiers", key],
                                   capture_output=True, timeout=10)
                success = r.returncode == 0
            if not success:
                try:
                    import pyautogui
                    pyautogui.hotkey(*key.replace("+", " ").split())
                    success = True
                except ImportError:
                    pass
            result["success"] = success
            result["output"]  = f"Key: {key}" if success else f"screen_key failed: {key}"

        # ── screen click ───────────────────────────────────────────────────
        elif atype == "screen_click":
            target  = cmd.strip()
            success = False
            if "," in target and not target.startswith("text:"):
                # Pixel click
                x, y = target.split(",", 1)
                if shutil.which("xdotool"):
                    r = subprocess.run(
                        ["xdotool", "mousemove", "--sync", x.strip(), y.strip()],
                        capture_output=True, timeout=5
                    )
                    subprocess.run(["xdotool", "click", "1"], capture_output=True)
                    success = True
                else:
                    try:
                        import pyautogui
                        pyautogui.click(int(float(x)), int(float(y)))
                        success = True
                    except ImportError:
                        pass
            elif target.startswith("text:") and shutil.which("xdotool"):
                window_title = target[5:]
                r = subprocess.run(
                    ["xdotool", "search", "--name", window_title],
                    capture_output=True, text=True, timeout=5
                )
                if r.stdout.strip():
                    wid = r.stdout.strip().splitlines()[0]
                    subprocess.run(["xdotool", "windowactivate", "--sync", wid])
                    success = True
            result["success"] = success
            result["output"]  = f"Clicked: {target}" if success else f"screen_click failed: {target}"

        # ── screen scroll ──────────────────────────────────────────────────
        elif atype == "screen_scroll":
            direction = cmd.strip().lower()
            success   = False
            if shutil.which("xdotool"):
                # button 4 = scroll up, button 5 = scroll down
                btn    = "4"
                clicks = 5
                try:
                    px = int(direction)
                    clicks = max(1, abs(px) // 40)
                    btn    = "4" if px < 0 else "5"
                except ValueError:
                    btn = "4" if direction == "up" else "5"
                for _ in range(clicks):
                    subprocess.run(["xdotool", "click", btn], capture_output=True, timeout=3)
                success = True
            else:
                try:
                    import pyautogui
                    amount = 300 if direction == "up" else -300
                    try:
                        amount = int(direction)
                    except ValueError:
                        pass
                    pyautogui.scroll(amount)
                    success = True
                except ImportError:
                    pass
            result["success"] = success
            result["output"]  = f"Scrolled {direction}"

        # ── screen screenshot ──────────────────────────────────────────────
        elif atype == "screen_screenshot":
            taken = False
            try:
                import pyautogui, io
                shot = pyautogui.screenshot()
                buf  = io.BytesIO()
                shot.save(buf, format="JPEG", quality=80)
                result["success"]              = True
                result["output"]               = f"Screenshot: {shot.width}x{shot.height}"
                result["_screenshot_bytes"]    = buf.getvalue()
                taken = True
            except ImportError:
                pass

            if not taken and shutil.which("scrot"):
                ts = datetime.now().strftime("%Y%m%d_%H%M%S")
                p  = Path.home() / f".salim/screenshots/{ts}.jpg"
                p.parent.mkdir(exist_ok=True)
                r  = subprocess.run(["scrot", str(p)], capture_output=True, timeout=10)
                if r.returncode == 0:
                    result["success"] = True
                    result["output"]  = f"Screenshot saved: {p}"
                    result["_screenshot_bytes"] = p.read_bytes()
                    taken = True

            if not taken:
                result["output"] = "No screenshot tool found. Install: pip install pyautogui Pillow"

        # ── notify ─────────────────────────────────────────────────────────
        elif atype == "notify":
            parts = cmd.split("|||", 1)
            title = parts[0].strip()
            body  = parts[1].strip() if len(parts) > 1 else ""
            sent  = False
            if shutil.which("notify-send"):
                r = subprocess.run(["notify-send", "-t", "5000", title, body],
                                   capture_output=True, timeout=5)
                sent = r.returncode == 0
            if not sent and platform.system() == "Darwin":
                script = f'display notification "{body}" with title "{title}"'
                subprocess.run(["osascript", "-e", script], capture_output=True)
                sent = True
            result["success"] = True
            result["output"]  = f"Notification: {title}" + (f" — {body[:60]}" if body else "")

        # ── open app ───────────────────────────────────────────────────────
        elif atype == "open_app":
            app_name = cmd.strip()
            success  = False
            if platform.system() == "Linux":
                for launcher in [[app_name], ["gtk-launch", app_name + ".desktop"]]:
                    try:
                        subprocess.Popen(launcher,
                                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                         start_new_session=True)
                        success = True
                        break
                    except FileNotFoundError:
                        pass
            elif platform.system() == "Darwin":
                r = subprocess.run(["open", "-a", app_name], capture_output=True)
                success = r.returncode == 0
            result["success"] = success
            result["output"]  = (f"Opened: {app_name}" if success
                                  else f"Could not open: {app_name}")

        # ── clipboard read ─────────────────────────────────────────────────
        elif atype == "clipboard_read":
            content = ""
            if shutil.which("xclip"):
                r = subprocess.run(["xclip", "-selection", "clipboard", "-o"],
                                   capture_output=True, text=True, timeout=5)
                content = r.stdout
            elif shutil.which("xsel"):
                r = subprocess.run(["xsel", "--clipboard", "--output"],
                                   capture_output=True, text=True, timeout=5)
                content = r.stdout
            elif platform.system() == "Darwin":
                r = subprocess.run(["pbpaste"], capture_output=True, text=True, timeout=5)
                content = r.stdout
            result["success"] = True
            result["output"]  = content[:2000] or "(clipboard is empty)"

        # ── clipboard write ────────────────────────────────────────────────
        elif atype == "clipboard_write":
            success = False
            if shutil.which("xclip"):
                proc = subprocess.Popen(["xclip", "-selection", "clipboard"],
                                        stdin=subprocess.PIPE)
                proc.communicate(cmd.encode())
                success = proc.returncode == 0
            elif shutil.which("xsel"):
                proc = subprocess.Popen(["xsel", "--clipboard", "--input"],
                                        stdin=subprocess.PIPE)
                proc.communicate(cmd.encode())
                success = True
            elif platform.system() == "Darwin":
                proc = subprocess.Popen(["pbcopy"], stdin=subprocess.PIPE)
                proc.communicate(cmd.encode())
                success = True
            result["success"] = success
            result["output"]  = (f"Clipboard set: {cmd[:60]}" if success
                                  else "clipboard_write failed: install xclip or xsel")

        # ── http request ───────────────────────────────────────────────────
        elif atype == "http_request":
            try:
                import httpx
                parts  = cmd.split("|||", 2)
                method = parts[0].strip().upper() if parts else "GET"
                url    = parts[1].strip() if len(parts) > 1 else cmd.strip()
                body   = parts[2].strip() if len(parts) > 2 else None

                async with httpx.AsyncClient(follow_redirects=True, timeout=20, verify=False) as c:
                    if method == "POST" and body:
                        try:
                            r = await c.post(url, json=json.loads(body),
                                             headers={"Content-Type": "application/json"})
                        except json.JSONDecodeError:
                            r = await c.post(url, content=body.encode())
                    else:
                        r = await c.get(url)

                ct = r.headers.get("content-type", "")
                if "json" in ct:
                    try:
                        output = json.dumps(r.json(), indent=2)[:2000]
                    except Exception:
                        output = r.text[:2000]
                else:
                    output = r.text[:2000]

                result["success"] = r.status_code < 400
                result["output"]  = f"HTTP {r.status_code}\n{output}"
            except Exception as e:
                result["output"] = f"HTTP request failed: {e}"

        # ── calendar read ──────────────────────────────────────────────────
        elif atype == "calendar_read":
            events = []
            now    = datetime.now()

            ics_paths = [
                Path.home() / ".local/share/evolution/tasks/system/calendar.ics",
                Path.home() / ".calendar/calendar.ics",
                Path.home() / "calendar.ics",
                Path.home() / "Documents/calendar.ics",
            ]
            for ics_path in ics_paths:
                if ics_path.exists():
                    try:
                        import icalendar
                        cal = icalendar.Calendar.from_ical(ics_path.read_bytes())
                        for component in cal.walk():
                            if component.name == "VEVENT":
                                dtstart = component.get("dtstart")
                                summary = str(component.get("summary", ""))
                                if dtstart:
                                    dt = dtstart.dt
                                    if not hasattr(dt, "hour"):
                                        from datetime import date as date_type
                                        dt = datetime.combine(dt, datetime.min.time())
                                    if dt >= now:
                                        events.append(f"{dt.strftime('%Y-%m-%d %H:%M')} — {summary}")
                    except Exception as ex:
                        events.append(f"(ical error: {ex})")
                    break

            if not events and shutil.which("calcurse"):
                r = subprocess.run(["calcurse", "-n", "--format-apt", "%S %E %m"],
                                   capture_output=True, text=True, timeout=10)
                events = r.stdout.strip().splitlines()[:15]

            if not events:
                result["output"] = ("No calendar data found. "
                                    "Supported: ~/.calendar/calendar.ics, calcurse")
            else:
                result["success"] = True
                result["output"]  = "Upcoming events:\n" + "\n".join(events[:15])

        # ── report / skip ──────────────────────────────────────────────────
        elif atype in ("report", "skip"):
            result["success"] = True
            result["output"]  = cmd or desc

        else:
            result["output"] = f"Unknown action type: '{atype}'"

    except Exception as e:
        result["output"] = f"Executor error in [{atype}]: {e}"
        logger.exception(f"Action executor exception ({atype}): {e}")

    return result


# ══════════════════════════════════════════════════════════════════════════════
#  SELF-HEALER
# ══════════════════════════════════════════════════════════════════════════════

async def _self_heal(failed_action: dict, error: str, config) -> Optional[dict]:
    from salim.ai import SalimAI
    ai = SalimAI(config)
    prompt = f"""I tried this action and it failed:
Action type: {failed_action.get('type')}
Command: {failed_action.get('command', '')[:300]}
Error: {error[:300]}
Goal: {failed_action.get('description', '')}

Return ONLY a JSON object with a corrected action to achieve the same goal:
{{"type":"...","description":"...","command":"...","expected_outcome":"...","risk":"low"}}"""
    try:
        response = await ai.chat(
            messages=[{"role": "user", "content": prompt}],
            system="You are a system debugger. Return only valid JSON to fix the failed action.",
            max_tokens=400,
        )
        text = response.strip()
        if "```" in text:
            text = re.sub(r"```(?:json)?\s*", "", text).replace("```", "").strip()
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            return json.loads(match.group())
    except Exception as e:
        logger.error(f"Self-heal failed: {e}")
    return None


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN AUTONOMOUS CYCLE
# ══════════════════════════════════════════════════════════════════════════════

async def run_autonomous_cycle(app: Application, config, chat_id: int, user_id: int):
    state  = _load_state()
    goals  = _load_goals()
    memory = _load_memory()
    cycle  = state.get("cycle_count", 0) + 1

    logger.info(f"Autonomous cycle #{cycle} starting")

    # ── 1. Observe ───────────────────────────────────────────────────────────
    obs = _observe()
    # v19: save snapshot for semantic diff next cycle
    try:
        memory["_prev_obs"] = {k: obs[k] for k in ("cpu_pct","ram_pct","email_unread","zombie_count","battery_pct") if k in obs}
        _save_memory(memory)
    except Exception:
        pass

    try:
        cpu_s   = f"CPU {obs.get('cpu_pct','?')}%"
        ram_s   = f"RAM {obs.get('ram_pct','?')}%"
        disk_s  = ""
        email_s = ""
        media_s = ""
        if obs.get("disks"):
            disk_s = f" Disk {obs['disks'][0]['pct']}%"
        if "email_unread" in obs:
            email_s = f" 📧{obs['email_unread']}"
        if obs.get("media_playing_pid"):
            media_s = " 🎵"

        await app.bot.send_message(
            chat_id=chat_id,
            text=(f"🧠 <b>Autonomous Cycle #{cycle}</b>\n"
                  f"🕐 {datetime.now().strftime('%H:%M:%S')} | "
                  f"{cpu_s} | {ram_s}{disk_s}{email_s}{media_s}\n"
                  f"<i>Thinking…</i>"),
            parse_mode=H,
        )
    except Exception:
        pass

    # ── 2. Think ─────────────────────────────────────────────────────────────
    plan = await _ai_think(obs, goals, memory, config)
    if not plan:
        try:
            await app.bot.send_message(
                chat_id=chat_id,
                text="🤖 <i>Could not generate action plan (AI unavailable). Retrying next cycle.</i>",
                parse_mode=H,
            )
        except Exception:
            pass
        return

    assessment = plan.get("assessment", "")
    priority   = plan.get("priority", "low")
    actions    = plan.get("actions", [])[:MAX_ACTIONS_PER_CYCLE]

    pri_emoji = {"critical": "🔴", "high": "🟠", "medium": "🟡", "low": "🟢"}.get(priority, "⚪")

    plan_lines = [
        f"{pri_emoji} <b>Assessment:</b> {esc(assessment)}",
        f"📋 <b>Plan ({len(actions)} actions):</b>",
    ]
    for i, a in enumerate(actions, 1):
        risk_icon = {"high": "⚠️", "medium": "🔶", "low": "✅"}.get(a.get("risk", "low"), "✅")
        plan_lines.append(
            f"  {i}. {risk_icon} [{a.get('type','?')}] {esc(a.get('description','')[:80])}"
        )
    try:
        await app.bot.send_message(chat_id=chat_id, text="\n".join(plan_lines), parse_mode=H)
    except Exception:
        pass

    # ── 3. Execute — parallel for independent, serial for dependent ──────────
    results, success_cnt, fail_cnt = [], 0, 0

    # v18: Group actions by dependency.
    # Actions annotated with "depends_on": [idx] run serially after deps.
    # All others (low-risk, independent) run in parallel batches.
    def _build_parallel_groups(actions: list) -> list[list]:
        """Group independent low-risk actions for parallel execution."""
        groups = []
        current_parallel = []
        for action in actions:
            atype = action.get("type", "skip")
            risk  = action.get("risk", "low")
            deps  = action.get("depends_on", [])
            # High-risk or dependent actions must run alone
            if risk == "high" or deps or atype in ("shell", "file_delete", "email_send", "screen_key"):
                if current_parallel:
                    groups.append(current_parallel)
                    current_parallel = []
                groups.append([action])
            else:
                current_parallel.append(action)
        if current_parallel:
            groups.append(current_parallel)
        return groups

    action_groups = _build_parallel_groups(actions)
    action_idx = 0

    # v19: Confidence scoring — flag low-confidence actions before execution
    try:
        from salim.handlers.confidence import score_plan_confidence, filter_safe_actions, confidence_bar, update_calibration
        conf_report = score_plan_confidence(actions)
        conf_mode = config.get("SALIM_CONFIDENCE_MODE", "normal") if hasattr(config, "get") else "normal"

        if conf_report["needs_escalation"] and conf_mode != "permissive":
            safe_actions, risky_actions = filter_safe_actions(actions)
            if risky_actions and conf_mode == "strict":
                # In strict mode: hold risky actions, only run safe ones
                risky_descs = "\n".join(
                    f"  ⚠️ [{a.get('type','?')}] {a.get('description','')[:60]} "
                    f"({int(a.get('_confidence',0)*100)}% confidence)"
                    for a in risky_actions[:5]
                )
                try:
                    await app.bot.send_message(
                        chat_id=chat_id,
                        text=f"🎯 <b>Confidence Gate (strict mode)</b>\n"
                             f"Plan confidence: {confidence_bar(conf_report['aggregate'])}\n"
                             f"{len(risky_actions)} actions held for review:\n{risky_descs}\n\n"
                             f"<i>Running {len(safe_actions)} safe actions. "
                             f"Use /confidence normal to auto-approve.</i>",
                        parse_mode=H,
                    )
                except Exception:
                    pass
                actions = safe_actions  # only run safe in strict mode
            elif risky_actions and conf_mode == "normal":
                # Normal mode: just warn user, still execute
                try:
                    await app.bot.send_message(
                        chat_id=chat_id,
                        text=f"🎯 Plan confidence: {confidence_bar(conf_report['aggregate'])} "
                             f"({conf_report['low_confidence_count']} flagged)",
                        parse_mode=H,
                    )
                except Exception:
                    pass
    except Exception as e:
        logger.debug(f"Confidence scoring failed: {e}")

    for group in action_groups:
        if len(group) > 1:
            # Parallel execution
            try:
                await app.bot.send_message(
                    chat_id=chat_id,
                    text=f"⚡ <b>Running {len(group)} actions in parallel…</b>",
                    parse_mode=H,
                )
            except Exception:
                pass
            group_results = await asyncio.gather(
                *[_execute_action(a) for a in group],
                return_exceptions=True
            )
            for action, result in zip(group, group_results):
                if isinstance(result, Exception):
                    result = {"success": False, "output": str(result), "type": action.get("type")}
                results.append(result)
                success_cnt += 1 if result.get("success") else 0
                fail_cnt += 0 if result.get("success") else 1
                icon = "✅" if result.get("success") else "❌"
                desc = action.get("description", "")
                out_preview = result.get("output", "")[:300]
                try:
                    await app.bot.send_message(
                        chat_id=chat_id,
                        text=f"{icon} <b>{esc(desc[:80])}</b>\n<pre>{esc(out_preview)}</pre>" if out_preview else f"{icon} {esc(desc[:80])}",
                        parse_mode=H,
                    )
                except Exception:
                    pass
                _append_log({"cycle": cycle, "action_type": action.get("type"), "description": desc, "success": result.get("success"), "output_preview": out_preview[:200]})
        else:
            # Serial (single action from group)
            pass  # falls through to existing serial loop below

    # Serial execution for remaining / originally serial actions
    serial_actions = [a for group in action_groups for a in group if len(action_groups) == 1 or any(
        a.get("risk") == "high" or a.get("depends_on") or a.get("type") in ("shell", "file_delete", "email_send", "screen_key")
        for _ in [None]
    )]
    # Re-derive: only actions that were NOT in parallel groups
    parallel_done = set()
    for group in action_groups:
        if len(group) > 1:
            for a in group:
                parallel_done.add(id(a))
    serial_remaining = [a for a in actions if id(a) not in parallel_done]

    for i, action in enumerate(serial_remaining, 1):
        atype = action.get("type", "skip")
        desc  = action.get("description", "")

        try:
            await app.bot.send_message(
                chat_id=chat_id,
                text=f"⚙️ <b>Action {i}/{len(actions)}:</b> {esc(desc[:100])}",
                parse_mode=H,
            )
        except Exception:
            pass

        result  = await _execute_action(action)
        results.append(result)
        success = result.get("success", False)
        output  = result.get("output", "")

        # Self-heal on failure
        if not success and atype not in ("skip", "report"):
            healed = await _self_heal(action, output, config)
            if healed:
                try:
                    await app.bot.send_message(
                        chat_id=chat_id,
                        text=f"🔧 <b>Self-healing:</b> {esc(healed.get('description','')[:80])}",
                        parse_mode=H,
                    )
                except Exception:
                    pass
                healed_result = await _execute_action(healed)
                if healed_result.get("success"):
                    result  = healed_result
                    success = True
                    output  = healed_result.get("output", "")

        icon = "✅" if success else "❌"
        out_preview = output[:400] if output else "(no output)"
        msg_text = (f"{icon} <b>{esc(desc[:80])}</b>\n"
                    + (f"<pre>{esc(out_preview)}</pre>" if out_preview.strip() else ""))
        try:
            await app.bot.send_message(chat_id=chat_id, text=msg_text, parse_mode=H)
        except Exception:
            pass

        # Send screenshot if captured
        if result.get("_screenshot_bytes"):
            try:
                import io
                raw = result["_screenshot_bytes"]
                if isinstance(raw, bytes):
                    await app.bot.send_photo(chat_id=chat_id, photo=io.BytesIO(raw))
            except Exception:
                pass

        if success:
            success_cnt += 1
        else:
            fail_cnt += 1

        _append_log({
            "cycle":          cycle,
            "action_type":    atype,
            "description":    desc,
            "success":        success,
            "output_preview": out_preview[:200],
        })
        # v19: Write to queryable audit DB
        try:
            from salim.handlers.audit import record_action
            record_action(
                action_type=atype,
                description=desc,
                command=action.get("command","")[:300],
                success=success,
                output=out_preview[:400],
                source="autonomous",
                cycle=cycle,
                goal=goals[0]["text"][:100] if goals else "",
                user_id=user_id,
            )
        except Exception:
            pass

        # v19: Mid-cycle replan — if action fails and reveals blocking info,
        # amend remaining actions before they execute.
        remaining_actions = serial_remaining[i:]
        if remaining_actions and not success and output and len(output) > 50:
            try:
                from salim.ai import SalimAI as _SAI
                _ai_r = _SAI(config)
                remaining_summary = json.dumps([
                    {"type": a.get("type"), "description": a.get("description","")[:60]}
                    for a in remaining_actions[:5]
                ], indent=2)
                _rp = (
                    f"Mid-cycle failure. Action [{atype}] failed: {output[:250]}\n\n"
                    f"Remaining actions: {remaining_summary}\n\n"
                    f"Should remaining actions change? Return JSON ONLY:\n"
                    f'{{ "amend": true, "reason": "...", "new_actions": [...] }} or '
                    f'{{ "amend": false }}'
                )
                rr, _ = await _ai_r._call_with_fallback(
                    [{"role": "user", "content": _rp}],
                    system="Mid-cycle replanner. Return only JSON.",
                    max_tokens=500, temperature=0.1,
                )
                rr = re.sub(r"```(?:json)?|```", "", rr).strip()
                _rm = re.search(r"\{.*\}", rr, re.DOTALL)
                if _rm:
                    rp_data = json.loads(_rm.group())
                    if rp_data.get("amend") and rp_data.get("new_actions"):
                        serial_remaining[i:] = rp_data["new_actions"]
                        try:
                            await app.bot.send_message(
                                chat_id=chat_id,
                                text=f"\U0001f504 <b>Replan:</b> {esc(rp_data.get('reason','')[:100])}",
                                parse_mode=H,
                            )
                        except Exception:
                            pass
            except Exception as _e:
                logger.debug(f"Mid-cycle replan error: {_e}")

        await asyncio.sleep(0.8)

    # ── 4. Update memory (v18: deduped by key) ───────────────────────────────
    mem_updates = plan.get("memory_updates", {})
    if mem_updates:
        memory.setdefault("facts", [])
        existing_keys = {f["key"]: i for i, f in enumerate(memory["facts"])}
        for k, v in mem_updates.items():
            entry = {
                "cycle": cycle,
                "ts":    datetime.now().isoformat(),
                "key":   k,
                "value": str(v)[:200],
            }
            if k in existing_keys:
                # Update existing instead of duplicating
                memory["facts"][existing_keys[k]] = entry
            else:
                memory["facts"].append(entry)
                existing_keys[k] = len(memory["facts"]) - 1
        memory["facts"] = memory["facts"][-100:]  # increased from 60
        _save_memory(memory)

    if success_cnt > 0:
        memory.setdefault("past_successes", [])
        memory["past_successes"].append({
            "cycle":   cycle,
            "ts":      datetime.now().isoformat(),
            "actions": [a.get("description", "")[:60] for a in actions],
        })
        memory["past_successes"] = memory["past_successes"][-30:]
        _save_memory(memory)

    # ── 5. Cycle summary ──────────────────────────────────────────────────────
    next_focus = plan.get("next_focus", "continue monitoring")
    state.update({
        "cycle_count":  cycle,
        "last_cycle":   datetime.now().isoformat(),
        "last_action":  actions[-1].get("description", "") if actions else "",
        "current_plan": next_focus,
    })
    _save_state(state)

    try:
        await app.bot.send_message(
            chat_id=chat_id,
            text=(f"📊 <b>Cycle #{cycle} Complete</b>\n"
                  f"✅ {success_cnt} succeeded  ❌ {fail_cnt} failed\n"
                  f"🔮 <i>Next: {esc(next_focus[:120])}</i>"),
            parse_mode=H,
        )
    except Exception:
        pass

    logger.info(f"Cycle #{cycle} done: {success_cnt} ok, {fail_cnt} failed")
    # v19: emit event bus cycle notification
    try:
        from salim.handlers.event_bus import emit_autonomous_cycle
        import asyncio as _aio
        _aio.get_event_loop().create_task(
            emit_autonomous_cycle(len(results), success_cnt, source="autonomous")
        )
    except Exception:
        pass


# ══════════════════════════════════════════════════════════════════════════════
#  BACKGROUND LOOP
# ══════════════════════════════════════════════════════════════════════════════

_auto_task: Optional[asyncio.Task] = None


async def _auto_loop(app: Application, config):
    while True:
        state = _load_state()
        if not state.get("enabled"):
            await asyncio.sleep(60)
            continue

        paused_until = state.get("paused_until")
        if paused_until:
            try:
                if datetime.fromisoformat(paused_until) > datetime.now():
                    await asyncio.sleep(60)
                    continue
                else:
                    state["paused_until"] = None
                    _save_state(state)
            except Exception:
                pass

        chat_id = state.get("chat_id")
        user_id = state.get("user_id")
        if not chat_id:
            await asyncio.sleep(60)
            continue

        try:
            await run_autonomous_cycle(app, config, chat_id, user_id)
        except Exception as e:
            logger.error(f"Autonomous cycle error: {e}")
            try:
                await app.bot.send_message(
                    chat_id=chat_id,
                    text=f"⚠️ <b>Cycle error:</b> {esc(str(e)[:200])}",
                    parse_mode=H,
                )
            except Exception:
                pass

        state    = _load_state()
        interval = state.get("interval_mins", DEFAULT_INTERVAL)
        await asyncio.sleep(interval * 60)


def start_auto_loop(app: Application, config):
    global _auto_task
    if _auto_task is None or _auto_task.done():
        _auto_task = asyncio.create_task(_auto_loop(app, config))
        logger.info("Autonomous loop started")


# ══════════════════════════════════════════════════════════════════════════════
#  TELEGRAM COMMAND HANDLERS
# ══════════════════════════════════════════════════════════════════════════════

class AutonomousHandlers:

    @require_auth
    async def cmd_auto(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        msg  = update.effective_message
        args = ctx.args or []
        sub  = args[0].lower() if args else "help"

        if sub == "on":
            state = _load_state()
            state.update({
                "enabled": True,
                "chat_id": msg.chat_id,
                "user_id": update.effective_user.id,
            })
            _save_state(state)
            start_auto_loop(self._app, self.config)
            interval = state.get("interval_mins", DEFAULT_INTERVAL)
            await msg.reply_text(
                f"🟢 <b>Autonomous Mode ENABLED</b>\n"
                f"Salim wakes every <b>{interval} min</b> and manages your laptop.\n\n"
                f"<b>Active capabilities:</b>\n"
                f"📧 Email — read, summarise, reply, send, search\n"
                f"🌐 Browser — navigate, click, fill forms, extract data\n"
                f"🎵 Media — play YouTube/local files, stop playback\n"
                f"⌨️ Screen — type, click, scroll, hotkeys\n"
                f"📁 Files — read, write, delete, organise\n"
                f"📄 Documents — write .md/.txt/.docx\n"
                f"🔔 Notifications, open apps, clipboard\n"
                f"🛠️ System — packages, processes, disk cleanup\n"
                f"🌍 HTTP APIs — GET/POST any endpoint\n"
                f"📅 Calendar — read upcoming events\n\n"
                f"<i>Use /auto goal &lt;text&gt; to direct Salim's focus.</i>",
                parse_mode=H,
            )
            asyncio.create_task(run_autonomous_cycle(
                self._app, self.config, msg.chat_id, update.effective_user.id))

        elif sub == "off":
            state = _load_state()
            state["enabled"] = False
            _save_state(state)
            await msg.reply_text("🔴 <b>Autonomous mode DISABLED.</b> Salim is idle.", parse_mode=H)

        elif sub == "status":
            state     = _load_state()
            enabled   = state.get("enabled", False)
            interval  = state.get("interval_mins", DEFAULT_INTERVAL)
            last_cyc  = state.get("last_cycle", "never")
            cycle_cnt = state.get("cycle_count", 0)
            last_act  = state.get("last_action", "none")
            plan      = state.get("current_plan", "")
            goals     = _load_goals()
            memory    = _load_memory()

            icon = "🟢" if enabled else "🔴"
            await msg.reply_text(
                f"{icon} <b>Autonomous Status</b>\n\n"
                f"Mode: {'ACTIVE' if enabled else 'PAUSED'}\n"
                f"Interval: {interval} min\n"
                f"Cycles run: {cycle_cnt}\n"
                f"Last cycle: {last_cyc}\n"
                f"Last action: {esc(str(last_act)[:80])}\n"
                f"Current focus: {esc(plan[:80])}\n"
                f"Goals: {len(goals)}\n"
                f"Memory facts: {len(memory.get('facts',[]))}",
                parse_mode=H,
            )

        elif sub == "interval":
            if len(args) < 2:
                await msg.reply_text("Usage: /auto interval <minutes>")
                return
            try:
                n = max(1, int(args[1]))
                state = _load_state()
                state["interval_mins"] = n
                _save_state(state)
                await msg.reply_text(f"⏱ Interval set to <b>{n} minutes</b>.", parse_mode=H)
            except ValueError:
                await msg.reply_text("Invalid number.")

        elif sub == "goal":
            if len(args) < 2:
                await msg.reply_text("Usage: /auto goal <text>")
                return
            goal_text = " ".join(args[1:])
            goals = _load_goals()
            goals.append({
                "text": goal_text,
                "added_at": datetime.now().isoformat(),
                "priority": "normal",
            })
            _save_goals(goals)
            await msg.reply_text(
                f"🎯 Goal added: <i>{esc(goal_text)}</i>\n"
                f"Salim pursues this every cycle.",
                parse_mode=H,
            )

        elif sub == "goals":
            goals = _load_goals()
            if not goals:
                await msg.reply_text("No goals set. Add with: /auto goal <text>")
                return
            lines = ["🎯 <b>Standing Goals:</b>\n"]
            for i, g in enumerate(goals, 1):
                added = g.get("added_at", "")[:10]
                lines.append(f"  {i}. [{added}] {esc(g['text'])}")
            await msg.reply_text("\n".join(lines), parse_mode=H)

        elif sub == "dgoal":
            if len(args) < 2:
                await msg.reply_text("Usage: /auto dgoal <number>")
                return
            try:
                n     = int(args[1]) - 1
                goals = _load_goals()
                if 0 <= n < len(goals):
                    removed = goals.pop(n)
                    _save_goals(goals)
                    await msg.reply_text(
                        f"🗑 Deleted: <i>{esc(removed['text'])}</i>", parse_mode=H)
                else:
                    await msg.reply_text(f"No goal #{n+1}")
            except ValueError:
                await msg.reply_text("Invalid number.")

        elif sub == "log":
            n = 20
            if len(args) > 1:
                try:
                    n = int(args[1])
                except ValueError:
                    pass
            entries = _read_log(n)
            if not entries:
                await msg.reply_text("📋 No actions logged yet.")
                return
            lines = [f"📋 <b>Last {len(entries)} Actions:</b>\n"]
            for e in entries:
                ts    = e.get("ts", "")[-8:]
                icon  = "✅" if e.get("success") else "❌"
                atype = e.get("action_type", "?")
                desc  = esc(e.get("description", "")[:70])
                lines.append(f"{icon} <code>{ts}</code> [{atype}] {desc}")
            await msg.reply_text("\n".join(lines), parse_mode=H)

        elif sub == "pause":
            # /auto pause <minutes>
            minutes = 60
            if len(args) > 1:
                try:
                    minutes = max(1, int(args[1]))
                except ValueError:
                    pass
            state = _load_state()
            until = datetime.now() + timedelta(minutes=minutes)
            state["paused_until"] = until.isoformat()
            _save_state(state)
            await msg.reply_text(
                f"⏸ <b>Autonomous mode paused for {minutes} minutes</b>\n"
                f"<i>Resumes at {until.strftime('%H:%M')}. Use /auto on to resume early.</i>",
                parse_mode=H,
            )

        elif sub == "reflect":
            # /auto reflect — trigger AI reflection on last cycle
            memory = _load_memory()
            last_actions = [
                f"[{e.get('action_type','?')}] {e.get('description','')[:60]} — {'✅' if e.get('success') else '❌'}"
                for e in _read_log(10)
            ]
            if not last_actions:
                await msg.reply_text("🧠 No actions to reflect on yet. Run /auto think first.", parse_mode=H)
                return
            thinking = await msg.reply_text("🧠 <i>Reflecting on recent actions…</i>", parse_mode=H)
            from salim.ai import SalimAI
            ai = SalimAI(self.config)
            prompt = (
                "You are Salim's self-reflection engine. Analyze these recent autonomous actions:\n\n"
                + "\n".join(last_actions)
                + "\n\nProvide a short reflection (3-5 sentences): What worked? What failed? What should be done differently? "
                + "Output only the reflection, no preamble."
            )
            try:
                reflection, _ = await ai._call_with_fallback(
                    [{"role": "user", "content": prompt}],
                    system="You are a concise self-reflection AI. Output only the reflection.",
                    max_tokens=300,
                )
                memory.setdefault("reflections", [])
                memory["reflections"].append({
                    "ts": datetime.now().isoformat(),
                    "text": reflection.strip()[:500],
                })
                memory["reflections"] = memory["reflections"][-20:]
                _save_memory(memory)
                await thinking.edit_text(
                    f"🧠 <b>Reflection</b>\n\n{esc(reflection.strip()[:800])}",
                    parse_mode=H,
                )
            except Exception as e:
                await thinking.edit_text(f"⚠️ Reflection failed: {esc(str(e))}", parse_mode=H)

        elif sub == "think":
            state   = _load_state()
            chat_id = state.get("chat_id") or msg.chat_id
            user_id = state.get("user_id") or update.effective_user.id
            await msg.reply_text(
                "🧠 <b>Manual cycle triggered…</b>\n<i>OBSERVE → THINK → ACT</i>",
                parse_mode=H,
            )
            asyncio.create_task(run_autonomous_cycle(self._app, self.config, chat_id, user_id))

        elif sub == "report":
            status = await msg.reply_text("📊 <i>Generating environment report…</i>", parse_mode=H)
            obs    = _observe()
            memory = _load_memory()
            goals  = _load_goals()

            disk_lines = "\n".join(
                f"  {d['mount']}: {d['pct']}% used ({d['free_gb']} GB free)"
                for d in obs.get("disks", [])
            ) or "  N/A"

            top_procs = "\n".join(
                f"  {p.get('name','?')[:20]:20} CPU:{p.get('cpu_percent',0):.1f}%  "
                f"RAM:{p.get('memory_percent',0):.1f}%"
                for p in obs.get("top_processes", [])[:5]
            )

            report = (
                f"📊 <b>Environment Report</b>\n"
                f"🕐 {obs.get('timestamp','')}\n\n"
                f"<b>CPU:</b> {obs.get('cpu_pct','?')}%  "
                f"<b>RAM:</b> {obs.get('ram_pct','?')}% ({obs.get('ram_free_gb','?')} GB free)\n"
                f"<b>Uptime:</b> {obs.get('uptime_hours','?')} hours\n"
                f"<b>Battery:</b> {obs.get('battery_pct','N/A')}% "
                f"({'charging' if obs.get('battery_charging') else 'on battery'})\n\n"
                f"<b>Disks:</b>\n{disk_lines}\n\n"
                f"<b>Top Processes:</b>\n<pre>{esc(top_procs)}</pre>\n"
                f"<b>Zombies:</b> {obs.get('zombie_count',0)}\n"
                f"<b>Emails unread:</b> {obs.get('email_unread','N/A')}\n"
                f"<b>Media playing:</b> "
                f"{'PID ' + str(obs.get('media_playing_pid')) if obs.get('media_playing_pid') else 'No'}\n"
                f"<b>Temp dir:</b> {obs.get('tmp_dir_size_mb','?')} MB\n\n"
                f"<b>Tools present:</b> {', '.join(obs.get('tools_present',[]))}\n"
                f"<b>Tools missing:</b> {', '.join(obs.get('tools_missing',[])) or 'none'}\n\n"
                f"<b>Goals:</b> {len(goals)}  "
                f"<b>Memory facts:</b> {len(memory.get('facts',[]))}  "
                f"<b>Packages:</b> {obs.get('pip_packages_count','?')} pip"
            )
            try:
                await status.edit_text(report[:4000], parse_mode=H)
            except Exception:
                await msg.reply_text(report[:4000], parse_mode=H)

        elif sub == "memory":
            memory = _load_memory()
            facts  = memory.get("facts", [])
            if not facts:
                await msg.reply_text("🧠 No long-term memory yet.")
                return
            lines = ["🧠 <b>Long-Term Memory:</b>\n"]
            for f in facts[-20:]:
                ts = f.get("ts", "")[:10]
                lines.append(
                    f"  [{ts}] <b>{esc(f.get('key','')[:30])}</b>: "
                    f"{esc(str(f.get('value',''))[:80])}"
                )
            await msg.reply_text("\n".join(lines), parse_mode=H)

        elif sub == "clearmem":
            _save_memory({"facts": [], "patterns": [], "preferences": {},
                           "past_successes": [], "past_failures": []})
            await msg.reply_text("🧠 Long-term memory cleared.")

        else:
            await msg.reply_text(
                "🤖 <b>Salim Autonomous v18 — Full Laptop Management</b>\n\n"
                "<code>/auto on</code>              — activate full autonomy\n"
                "<code>/auto off</code>             — pause\n"
                "<code>/auto pause &lt;mins&gt;</code>    — pause for N minutes\n"
                "<code>/auto status</code>          — current state\n"
                "<code>/auto interval &lt;n&gt;</code>    — wake-up interval (minutes)\n"
                "<code>/auto goal &lt;text&gt;</code>     — add standing goal\n"
                "<code>/auto goals</code>           — list goals\n"
                "<code>/auto dgoal &lt;n&gt;</code>      — delete goal #n\n"
                "<code>/auto think</code>           — trigger cycle now\n"
                "<code>/auto reflect</code>         — AI reflection on last cycle\n"
                "<code>/auto report</code>          — full system report\n"
                "<code>/auto log [n]</code>         — action history\n"
                "<code>/auto memory</code>          — learned facts\n"
                "<code>/auto clearmem</code>        — clear memory\n\n"
                "<i>v18: parallel action execution, deduped memory, reflection, pause timer.</i>",
                parse_mode=H,
            )
