"""
Salim Shared Scratchpad v19 - Cross-Agent Shared Memory
"""
from __future__ import annotations
import json, logging, time
from datetime import datetime
from pathlib import Path
from typing import Any, Optional
from telegram import Update
from telegram.ext import ContextTypes
from salim.auth import require_auth

logger = logging.getLogger("salim.scratchpad")
esc = lambda v: __import__("html").escape(str(v), quote=False)
H = "HTML"
SCRATCH_FILE = Path.home() / ".salim" / "scratchpad.json"

def _load() -> dict:
    try:
        if SCRATCH_FILE.exists():
            data = json.loads(SCRATCH_FILE.read_text())
            now = time.time()
            return {k: v for k, v in data.items() if not v.get("_ttl") or v["_ttl"] > now}
    except Exception:
        pass
    return {}

def _save(data: dict):
    SCRATCH_FILE.write_text(json.dumps(data, indent=2, default=str))
    SCRATCH_FILE.chmod(0o600)

def scratch_get(key: str, default=None) -> Any:
    entry = _load().get(key)
    return entry.get("value", default) if entry else default

def scratch_set(key: str, value: Any, ttl_seconds: Optional[int] = None, author: str = "?"):
    data = _load()
    entry = {"value": value, "author": author, "ts": time.time(),
             "ts_human": datetime.now().isoformat()[:19]}
    if ttl_seconds:
        entry["_ttl"] = time.time() + ttl_seconds
    data[key] = entry
    _save(data)

def scratch_delete(key: str) -> bool:
    data = _load()
    if key in data:
        del data[key]
        _save(data)
        return True
    return False

def scratch_list(prefix: str = "") -> list:
    data = _load()
    return [(k, v.get("value"), v.get("author","?"), v.get("ts_human",""))
            for k, v in sorted(data.items()) if not prefix or k.startswith(prefix)]

def scratch_clear(prefix: str = ""):
    data = _load()
    _save({k: v for k, v in data.items() if not k.startswith(prefix)} if prefix else {})

def scratch_append(key: str, item: Any, max_items: int = 100, author: str = "?"):
    existing = scratch_get(key, [])
    if not isinstance(existing, list):
        existing = [existing]
    scratch_set(key, (existing + [item])[-max_items:], author=author)

class ScratchpadHandlers:
    @require_auth
    async def cmd_scratch(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        msg = update.effective_message
        args = ctx.args or []
        sub = args[0].lower() if args else "list"

        if sub == "get":
            key = args[1] if len(args) > 1 else ""
            val = scratch_get(key)
            if val is None:
                await msg.reply_text(f"? Key not found: {esc(key)}", parse_mode=H)
            else:
                await msg.reply_text(f"<code>{esc(key)}</code>: <pre>{esc(str(val)[:800])}</pre>", parse_mode=H)
            return

        if sub == "set" and len(args) >= 3:
            key = args[1]
            value = " ".join(args[2:])
            try: value = json.loads(value)
            except Exception: pass
            scratch_set(key, value, author=f"user:{update.effective_user.id}")
            await msg.reply_text(f"Saved {esc(key)}", parse_mode=H)
            return

        if sub in ("del","delete") and len(args) > 1:
            scratch_delete(args[1])
            await msg.reply_text("Deleted.", parse_mode=H)
            return

        if sub == "clear":
            scratch_clear(args[1] if len(args) > 1 else "")
            await msg.reply_text("Cleared.", parse_mode=H)
            return

        prefix = args[1] if len(args) > 1 else ""
        entries = scratch_list(prefix)
        if not entries:
            await msg.reply_text("Scratchpad empty.", parse_mode=H)
            return
        lines = [f"Scratchpad ({len(entries)} keys)"]
        for k, v, author, ts in entries[:20]:
            lines.append(f"  {k} = {str(v)[:50]}")
        await msg.reply_text("\n".join(lines), parse_mode=H)
