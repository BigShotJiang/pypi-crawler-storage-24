"""
Salim Orchestrator v18 — Sub-Agent Architecture

The Orchestrator spawns specialized sub-agents, each with their own
tools and memory, then merges results into a coherent response.

Sub-agents:
  FileAgent   — file search, read, write, organize
  EmailAgent  — inbox management, compose, search
  WebAgent    — browse, fetch, search the web
  SysAgent    — system info, processes, shell commands
  CodeAgent   — write, run, debug code
  DataAgent   — analyze data, generate reports

Commands:
  /orchestrate <goal>    — run goal with best-fit sub-agents
  /orchestrate status    — show running sub-agent tasks
  /orchestrate stop      — stop all running sub-agents
"""
from __future__ import annotations

import asyncio
import html
import json
import logging
import os
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.orchestrator")
esc = lambda v: html.escape(str(v), quote=False)
H = "HTML"

# Active orchestration tasks {user_id: task}
_orch_tasks: dict[int, asyncio.Task] = {}
_orch_results: dict[int, list] = {}


# ── SUB-AGENT DEFINITIONS ─────────────────────────────────────────────────────

AGENTS = {
    "FileAgent": {
        "description": "File system expert — search, read, organize, summarize files",
        "tools": ["shell", "python", "file_read", "file_write"],
        "system": (
            "You are FileAgent, a file system specialist. "
            "You excel at finding, reading, organizing, and summarizing files. "
            "Prefer safe read operations. Confirm before deleting."
        ),
    },
    "EmailAgent": {
        "description": "Email expert — read inbox, compose, reply, search emails",
        "tools": ["email_read", "email_search", "email_send"],
        "system": (
            "You are EmailAgent, an email management specialist. "
            "You read and summarize emails efficiently, detect important messages, "
            "and compose clear professional replies."
        ),
    },
    "WebAgent": {
        "description": "Web research expert — browse, fetch, search the internet",
        "tools": ["browse", "http_request"],
        "system": (
            "You are WebAgent, a web research specialist. "
            "You fetch web pages, extract key information, and synthesize findings. "
            "Always cite your sources."
        ),
    },
    "SysAgent": {
        "description": "System expert — monitor resources, manage processes, run commands",
        "tools": ["shell", "python"],
        "system": (
            "You are SysAgent, a system administration specialist. "
            "You monitor CPU/RAM/disk, manage processes, and run safe shell commands. "
            "Avoid destructive operations unless explicitly requested."
        ),
    },
    "CodeAgent": {
        "description": "Code expert — write, execute, test, and debug programs",
        "tools": ["python", "shell"],
        "system": (
            "You are CodeAgent, a senior software engineer. "
            "You write clean, working code and fix bugs systematically. "
            "Always test your code before reporting success."
        ),
    },
    "DataAgent": {
        "description": "Data analysis expert — process data, generate charts and reports",
        "tools": ["python", "file_write"],
        "system": (
            "You are DataAgent, a data analysis specialist. "
            "You process CSV/JSON data, compute statistics, generate insights, "
            "and produce clear summaries."
        ),
    },
}


# ── AGENT ROUTER ──────────────────────────────────────────────────────────────

async def select_agents(goal: str, ai) -> list[str]:
    """
    Ask AI which agents are best suited for this goal.
    Returns list of agent names.
    """
    agent_list = "\n".join(
        f"- {name}: {info['description']}"
        for name, info in AGENTS.items()
    )
    prompt = (
        f"Given this goal: '{goal}'\n\n"
        f"Available agents:\n{agent_list}\n\n"
        "Which agents should work on this goal? List only the agent names, "
        "comma-separated. Pick 1-3 most relevant ones."
    )
    try:
        response, _ = await ai._call_with_fallback(
            [{"role": "user", "content": prompt}],
            system="You select agents. Return only comma-separated agent names, nothing else.",
            max_tokens=60,
            temperature=0.1,
        )
        names = [n.strip() for n in response.split(",") if n.strip() in AGENTS]
        return names or ["SysAgent"]
    except Exception:
        return ["SysAgent"]


async def run_sub_agent(name: str, goal: str, context: str, ai,
                        task_id: str = "", user_id: int = 0) -> dict:
    """
    v19: Run a sub-agent with namespaced scratchpad isolation.
    
    Each agent writes to its own namespace: task_id:agent_name:key
    This prevents agents from contaminating each other's working memory.
    Agents can ONLY read context explicitly passed to them.
    """
    agent_info = AGENTS.get(name, {})
    system = agent_info.get("system", "You are a helpful AI assistant.")

    # Read this agent's namespace from shared scratchpad
    ns_prefix = f"{task_id}:{name}:" if task_id else f"{name}:"
    try:
        from salim.handlers.scratchpad import scratch_list, scratch_set
        my_scratch = {k[len(ns_prefix):]: v for k, v, _, _ in scratch_list(ns_prefix)}
    except Exception:
        my_scratch = {}

    prompt = (
        f"GOAL: {goal}\n\n"
        f"CONTEXT FROM OTHER AGENTS:\n{context or 'None yet'}\n\n"
        f"MY WORKING MEMORY:\n{json.dumps(my_scratch, indent=2)[:500] if my_scratch else '(empty)'}\n\n"
        f"AVAILABLE TOOLS: {', '.join(agent_info.get('tools', []))}\n\n"
        "Complete the goal. Provide a structured result with:\n"
        "1. Key findings\n"
        "2. Actions taken / data gathered\n"
        "3. Recommendations or next steps\n"
        "4. Any data future agents should know (write these as key:value pairs at the end)"
    )

    try:
        result, _ = await ai._call_with_fallback(
            [{"role": "user", "content": prompt}],
            system=system,
            max_tokens=1000,
        )
        result_text = result.strip()

        # Parse and store any agent-produced key:value facts to namespaced scratchpad
        if task_id and user_id:
            try:
                from salim.handlers.scratchpad import scratch_set
                for line in result_text.split("\n"):
                    if ":" in line and len(line) < 200:
                        k, _, v = line.partition(":")
                        k = k.strip().lower().replace(" ", "_")
                        if 2 < len(k) < 40 and not k.startswith(("1", "2", "3", "-", "*")):
                            scratch_set(
                                f"{ns_prefix}{k}",
                                v.strip()[:200],
                                author=f"agent:{name}",
                            )
            except Exception:
                pass

        return {"agent": name, "result": result_text, "success": True, "namespace": ns_prefix}
    except Exception as e:
        return {"agent": name, "result": str(e), "success": False}


async def synthesize_results(goal: str, agent_results: list[dict], ai,
                            task_id: str = "") -> str:
    """
    v19: Synthesize with full namespaced scratchpad context.
    Reads ALL agent namespaces to build a complete picture before synthesizing.
    """
    results_text = "\n\n".join(
        f"=== {r['agent']} Agent ===\n{r['result']}"
        for r in agent_results
    )

    # Read all accumulated facts from namespaced scratchpad
    shared_facts = {}
    if task_id:
        try:
            from salim.handlers.scratchpad import scratch_list
            for k, v, author, _ in scratch_list(task_id + ":"):
                ns_key = k[len(task_id)+1:]  # strip task_id prefix
                shared_facts[ns_key] = v
        except Exception:
            pass

    facts_text = json.dumps(shared_facts, indent=2)[:800] if shared_facts else "(none)"

    prompt = (
        f"Original goal: {goal}\n\n"
        f"Agent results:\n{results_text}\n\n"
        f"Accumulated facts from all agents:\n{facts_text}\n\n"
        "Synthesize into a complete response:\n"
        "- Start with a 1-sentence executive summary\n"
        "- Key findings from each agent\n"
        "- Combined conclusions\n"
        "- Concrete next steps if applicable"
    )

    try:
        synthesis, _ = await ai._call_with_fallback(
            [{"role": "user", "content": prompt}],
            system="You synthesize multi-agent results. Be specific, use the actual data provided.",
            max_tokens=800,
        )
        return synthesis.strip()
    except Exception as e:
        return f"Synthesis failed: {e}\n\n" + results_text


# ── MAIN ORCHESTRATION FLOW ────────────────────────────────────────────────────

async def orchestrate_goal(goal: str, chat_id: int, user_id: int, app, config):
    """Full orchestration: route → parallel execute → synthesize → report."""
    from salim.ai import SalimAI
    ai = SalimAI(config)

    try:
        # 1. Select agents
        await app.bot.send_message(
            chat_id,
            f"🎯 <b>Orchestrating:</b> {esc(goal[:100])}\n<i>Selecting sub-agents…</i>",
            parse_mode=H,
        )

        selected = await select_agents(goal, ai)

        await app.bot.send_message(
            chat_id,
            f"🤖 <b>Sub-agents selected:</b> {', '.join(selected)}\n"
            f"<i>Running in parallel…</i>",
            parse_mode=H,
        )

        # 2. Run agents in parallel
        context = ""
        tasks = [run_sub_agent(name, goal, context, ai) for name in selected]
        agent_results = await asyncio.gather(*tasks, return_exceptions=True)
        agent_results = [
            r if isinstance(r, dict) else {"agent": selected[i], "result": str(r), "success": False}
            for i, r in enumerate(agent_results)
        ]

        # 3. Report individual results
        for r in agent_results:
            icon = "✅" if r["success"] else "❌"
            await app.bot.send_message(
                chat_id,
                f"{icon} <b>{esc(r['agent'])}</b>\n{esc(r['result'][:600])}",
                parse_mode=H,
            )

        # 4. Synthesize if multiple agents
        if len(agent_results) > 1:
            await app.bot.send_message(
                chat_id,
                "🔀 <i>Synthesizing results…</i>",
                parse_mode=H,
            )
            synthesis = await synthesize_results(goal, agent_results, ai)
            await app.bot.send_message(
                chat_id,
                f"📊 <b>Final Result</b>\n\n{esc(synthesis[:1500])}",
                parse_mode=H,
            )

        # Store results
        _orch_results[user_id] = agent_results

    except asyncio.CancelledError:
        await app.bot.send_message(chat_id, "⏹ Orchestration stopped.", parse_mode=H)
    except Exception as e:
        logger.error(f"Orchestration error: {e}")
        await app.bot.send_message(chat_id, f"❌ Orchestration error: {esc(str(e))}", parse_mode=H)


# ── TELEGRAM COMMANDS ─────────────────────────────────────────────────────────

class OrchestratorHandlers:

    @require_auth
    async def cmd_orchestrate(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /orchestrate <goal>   — run goal using best-fit sub-agents
        /orchestrate status   — show running tasks
        /orchestrate stop     — stop all tasks
        /orchestrate results  — show last results
        """
        msg = update.effective_message
        user_id = update.effective_user.id
        chat_id = update.effective_chat.id
        args = ctx.args or []

        if not args:
            agent_list = "\n".join(
                f"  🤖 <b>{name}</b> — {info['description']}"
                for name, info in AGENTS.items()
            )
            await msg.reply_text(
                "🎯 <b>Salim Orchestrator</b>\n\n"
                "Coordinates multiple specialized sub-agents to complete complex goals.\n\n"
                "<b>Available agents:</b>\n"
                f"{agent_list}\n\n"
                "<code>/orchestrate analyze my downloads folder and summarize the top 10 largest files</code>\n"
                "<code>/orchestrate check my email and system health, give me a status report</code>\n"
                "<code>/orchestrate write a Python script to backup my Desktop to ~/backups</code>",
                parse_mode=H,
            )
            return

        sub = args[0].lower()

        if sub == "status":
            task = _orch_tasks.get(user_id)
            if task and not task.done():
                await msg.reply_text("🔄 <b>Orchestration in progress…</b>", parse_mode=H)
            else:
                await msg.reply_text("✅ No active orchestration.", parse_mode=H)
            return

        if sub == "stop":
            task = _orch_tasks.get(user_id)
            if task and not task.done():
                task.cancel()
                await msg.reply_text("⏹ Orchestration stopped.", parse_mode=H)
            else:
                await msg.reply_text("Nothing to stop.", parse_mode=H)
            return

        if sub == "results":
            results = _orch_results.get(user_id, [])
            if not results:
                await msg.reply_text("No recent results.", parse_mode=H)
                return
            for r in results[:3]:
                icon = "✅" if r.get("success") else "❌"
                await msg.reply_text(
                    f"{icon} <b>{esc(r['agent'])}</b>\n{esc(r['result'][:600])}",
                    parse_mode=H,
                )
            return

        # Start new orchestration
        goal = " ".join(args)

        # Cancel any existing task
        existing = _orch_tasks.get(user_id)
        if existing and not existing.done():
            existing.cancel()

        task = asyncio.create_task(
            orchestrate_goal(goal, chat_id, user_id, self._app, self.config)
        )
        _orch_tasks[user_id] = task
