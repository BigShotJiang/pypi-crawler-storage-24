"""
Salim Self-Developer — Agentic Code Intelligence Engine
========================================================
When developer mode is enabled, Salim understands its own entire codebase,
detects issues, designs safe multi-file fixes, tests them, then auto-pushes
to GitHub and publishes to PyPI.

The agentic loop:
  1. ANALYSE     — build a complete map of all files, their imports, exported
                   symbols, and relationships across the whole project tree
  2. DIAGNOSE    — run tests, import checks, linters; collect all errors/warnings
  3. PLAN        — send the full codebase map + errors to the AI with 128k context;
                   AI returns a structured edit plan covering all affected files
  4. APPLY       — apply every file edit atomically; back up originals first
  5. VERIFY      — re-run import checks, syntax checks, tests; if any error
                   remains, go back to DIAGNOSE with the new error context
  6. COMMIT      — git add / commit with a rich changelog message
  7. PUSH        — git push to GitHub
  8. PUBLISH     — bump version, build wheel, twine upload to PyPI
  9. SELF-UPDATE — pip install --upgrade salim from PyPI; restart bot cleanly

Everything is real. No mocks. No simulations. No placeholders.

Commands:
  /dev status          — show developer mode status + last run summary
  /dev run             — trigger a full dev cycle right now
  /dev analyse         — analyse codebase and show map (no changes)
  /dev diagnose        — run all checks and show issues found
  /dev plan            — show what AI would fix (dry-run, no edits)
  /dev apply           — apply pending plan (if one exists)
  /dev push            — commit + push current state to GitHub
  /dev publish         — bump version + publish to PyPI
  /dev selfupdate      — pip install --upgrade + restart
  /dev log [n]         — show last N dev cycle logs
  /dev on              — enable automatic dev cycles
  /dev off             — disable automatic dev cycles
  /dev interval <mins> — set cycle interval (default 60)
"""
from __future__ import annotations

import ast
import asyncio
import html
import importlib
import importlib.util
import json
import logging
import os
import re
import shutil
import subprocess
import sys
import tempfile
import textwrap
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from telegram import Update
from telegram.ext import Application, ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.self_developer")
H   = "HTML"
esc = lambda v: html.escape(str(v), quote=False)

# ── Paths ─────────────────────────────────────────────────────────────────────
DEV_DIR       = Path.home() / ".salim" / "developer"
STATE_FILE    = DEV_DIR / "state.json"
LOG_FILE      = DEV_DIR / "dev_log.jsonl"
BACKUP_DIR    = DEV_DIR / "backups"
PLAN_FILE     = DEV_DIR / "pending_plan.json"

DEV_DIR.mkdir(parents=True, exist_ok=True)
BACKUP_DIR.mkdir(parents=True, exist_ok=True)

MAX_LOG_ENTRIES = 200
MAX_TOKENS      = 120_000   # Use nearly full 128k context for codebase analysis


# ══════════════════════════════════════════════════════════════════════════════
#  STATE
# ══════════════════════════════════════════════════════════════════════════════

def _load_state() -> dict:
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text())
        except Exception:
            pass
    return {
        "enabled":         False,
        "developer_mode":  False,
        "interval_mins":   60,
        "chat_id":         None,
        "user_id":         None,
        "last_cycle":      None,
        "cycle_count":     0,
        "github_url":      "",
        "github_token":    "",
        "pypi_token":      "",
        "last_version":    "",
        "last_commit":     "",
        "last_publish":    "",
    }

def _save_state(s: dict):
    STATE_FILE.write_text(json.dumps(s, indent=2))
    STATE_FILE.chmod(0o600)

def _append_log(entry: dict):
    entry["ts"] = datetime.now().isoformat()
    with open(LOG_FILE, "a") as f:
        f.write(json.dumps(entry) + "\n")
    try:
        lines = LOG_FILE.read_text().strip().splitlines()
        if len(lines) > MAX_LOG_ENTRIES:
            LOG_FILE.write_text("\n".join(lines[-MAX_LOG_ENTRIES:]) + "\n")
    except Exception:
        pass

def _read_log(n: int = 20) -> list[dict]:
    if not LOG_FILE.exists():
        return []
    try:
        return [json.loads(l) for l in LOG_FILE.read_text().strip().splitlines()[-n:] if l]
    except Exception:
        return []


# ══════════════════════════════════════════════════════════════════════════════
#  STEP 1: ANALYSE — full codebase map
# ══════════════════════════════════════════════════════════════════════════════

def _find_salim_root() -> Optional[Path]:
    """Find the actual installed salim package directory."""
    try:
        import salim
        return Path(salim.__file__).parent
    except Exception:
        pass
    # Try common locations
    for candidate in [
        Path.cwd(),
        Path.home() / "salim_v17",
        Path.home() / "salim_autonomous",
    ]:
        if (candidate / "salim" / "bot.py").exists():
            return candidate / "salim"
        if (candidate / "bot.py").exists():
            return candidate
    return None


def analyse_codebase(root: Path) -> dict:
    """
    Build a complete map of the codebase:
    - All Python files with their content
    - AST-extracted: imports, classes, functions, top-level assignments
    - File size, line count
    - Import graph (which files import which)
    - Detected issues: syntax errors, missing imports, circular imports
    """
    result = {
        "root":          str(root),
        "files":         {},   # path -> {content, size, lines, ast_info}
        "import_graph":  {},   # file -> [files it imports from this project]
        "symbol_table":  {},   # symbol -> defining file
        "issues":        [],   # list of detected problems
        "summary":       {},
    }

    py_files = sorted(root.rglob("*.py"))

    for fpath in py_files:
        rel = str(fpath.relative_to(root.parent))
        try:
            content = fpath.read_text(encoding="utf-8", errors="replace")
            size    = fpath.stat().st_size
            lines   = len(content.splitlines())

            ast_info = _extract_ast_info(content, rel)

            result["files"][rel] = {
                "path":     str(fpath),
                "content":  content,
                "size":     size,
                "lines":    lines,
                "ast_info": ast_info,
            }

            # Populate symbol table
            for cls in ast_info.get("classes", []):
                result["symbol_table"][cls] = rel
            for fn in ast_info.get("functions", []):
                result["symbol_table"][fn] = rel

        except Exception as e:
            result["issues"].append({
                "type":    "read_error",
                "file":    rel,
                "message": str(e),
            })

    # Build import graph
    for rel, fdata in result["files"].items():
        imports = fdata["ast_info"].get("salim_imports", [])
        result["import_graph"][rel] = imports

    # Detect circular imports
    for node, deps in result["import_graph"].items():
        for dep in deps:
            if node in result["import_graph"].get(dep, []):
                result["issues"].append({
                    "type":    "circular_import",
                    "file":    node,
                    "message": f"Circular import between {node} and {dep}",
                })

    result["summary"] = {
        "total_files":   len(result["files"]),
        "total_lines":   sum(f["lines"] for f in result["files"].values()),
        "total_bytes":   sum(f["size"]  for f in result["files"].values()),
        "total_issues":  len(result["issues"]),
        "total_symbols": len(result["symbol_table"]),
    }

    return result


def _extract_ast_info(source: str, filename: str) -> dict:
    info = {
        "imports":        [],   # all import statements as strings
        "salim_imports":  [],   # only imports from this project (salim.*)
        "classes":        [],
        "functions":      [],
        "assignments":    [],
        "syntax_error":   None,
    }
    try:
        tree = ast.parse(source, filename=filename)
    except SyntaxError as e:
        info["syntax_error"] = f"SyntaxError line {e.lineno}: {e.msg}"
        return info

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                info["imports"].append(alias.name)
                if alias.name.startswith("salim"):
                    info["salim_imports"].append(alias.name.replace(".", "/") + ".py")
        elif isinstance(node, ast.ImportFrom):
            mod = node.module or ""
            info["imports"].append(f"from {mod} import ...")
            if mod.startswith("salim"):
                info["salim_imports"].append(mod.replace(".", "/") + ".py")
        elif isinstance(node, ast.ClassDef):
            info["classes"].append(node.name)
        elif isinstance(node, ast.FunctionDef) or isinstance(node, ast.AsyncFunctionDef):
            info["functions"].append(node.name)
        elif isinstance(node, ast.Assign):
            for t in node.targets:
                if isinstance(t, ast.Name):
                    info["assignments"].append(t.id)

    return info


# ══════════════════════════════════════════════════════════════════════════════
#  STEP 2: DIAGNOSE — run all checks
# ══════════════════════════════════════════════════════════════════════════════

async def diagnose(root: Path) -> dict:
    """
    Run comprehensive diagnostics:
    - Syntax check every file
    - Try importing every module
    - Run pytest if available
    - Run ruff/flake8 linter if available
    - Check for undefined names in imports
    """
    diagnosis = {
        "syntax_errors":   [],
        "import_errors":   [],
        "test_results":    None,
        "lint_issues":     [],
        "runtime_errors":  [],
        "all_errors":      [],
    }

    py_files = list(root.rglob("*.py"))

    # ── Syntax check all files ────────────────────────────────────────────────
    for fpath in py_files:
        try:
            source = fpath.read_text(encoding="utf-8", errors="replace")
            ast.parse(source, filename=str(fpath))
        except SyntaxError as e:
            err = {
                "type":    "SyntaxError",
                "file":    str(fpath.relative_to(root.parent)),
                "line":    e.lineno,
                "message": str(e.msg),
                "text":    e.text or "",
            }
            diagnosis["syntax_errors"].append(err)
            diagnosis["all_errors"].append(err)

    # ── Try importing all salim modules ───────────────────────────────────────
    for fpath in py_files:
        if fpath.name.startswith("_") and fpath.name != "__init__.py":
            continue
        rel = fpath.relative_to(root.parent)
        mod_name = str(rel).replace("/", ".").replace("\\", ".").removesuffix(".py")
        try:
            proc = await asyncio.create_subprocess_exec(
                sys.executable, "-c", f"import {mod_name}",
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                env={**os.environ, "PYTHONPATH": str(root.parent)},
            )
            _, stderr = await asyncio.wait_for(proc.communicate(), timeout=15)
            if proc.returncode != 0:
                stderr_text = stderr.decode("utf-8", errors="replace").strip()
                if stderr_text and "No module named" not in stderr_text:
                    err = {
                        "type":    "ImportError",
                        "file":    str(rel),
                        "module":  mod_name,
                        "message": stderr_text[:500],
                    }
                    diagnosis["import_errors"].append(err)
                    diagnosis["all_errors"].append(err)
        except asyncio.TimeoutError:
            pass
        except Exception as e:
            pass

    # ── Run ruff if available ─────────────────────────────────────────────────
    if shutil.which("ruff"):
        try:
            proc = await asyncio.create_subprocess_exec(
                "ruff", "check", str(root), "--output-format=json",
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=30)
            ruff_out = stdout.decode("utf-8", errors="replace").strip()
            if ruff_out:
                try:
                    items = json.loads(ruff_out)
                    for item in items[:50]:
                        err = {
                            "type":    "LintError",
                            "file":    item.get("filename", "?"),
                            "line":    item.get("location", {}).get("row", 0),
                            "code":    item.get("code", "?"),
                            "message": item.get("message", "?"),
                        }
                        diagnosis["lint_issues"].append(err)
                        # Only add serious lint errors to all_errors
                        if item.get("code", "").startswith(("E", "F")):
                            diagnosis["all_errors"].append(err)
                except json.JSONDecodeError:
                    pass
        except asyncio.TimeoutError:
            pass

    # ── Run pytest if available and tests exist ───────────────────────────────
    test_dir = root.parent / "tests"
    if shutil.which("pytest") and test_dir.exists():
        try:
            proc = await asyncio.create_subprocess_exec(
                sys.executable, "-m", "pytest", str(test_dir),
                "--tb=short", "-q", "--no-header",
                "--json-report", f"--json-report-file={DEV_DIR}/pytest_report.json",
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
            )
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=120)
            output = stdout.decode("utf-8", errors="replace").strip()
            passed = output.count(" passed")
            failed = output.count(" failed")
            diagnosis["test_results"] = {
                "passed": passed,
                "failed": failed,
                "output": output[-2000:],
            }
            if failed:
                diagnosis["all_errors"].append({
                    "type":    "TestFailure",
                    "message": f"{failed} tests failed",
                    "detail":  output[-500:],
                })
        except asyncio.TimeoutError:
            diagnosis["test_results"] = {"error": "Tests timed out"}

    return diagnosis


# ══════════════════════════════════════════════════════════════════════════════
#  STEP 3: PLAN — AI designs comprehensive multi-file fixes
# ══════════════════════════════════════════════════════════════════════════════


# ─── Staged planning: triage then per-file edit (v19) ───────────────────────
import json as _json_sp, re as _re_sp

TRIAGE_SYSTEM = """You are a code analyst. Identify which files need changing.
Return ONLY JSON:
{
  "files_to_change": [
    {"file": "handlers/foo.py", "reason": "why", "change_type": "fix_bug|add_feature", "priority": 1, "depends_on": []}
  ],
  "summary": "overall diagnosis",
  "risk_level": "low|medium|high"
}
Only list files that MUST change. Be conservative."""

SINGLE_FILE_EDIT_SYSTEM = """You are a code editor. Edit ONE file to fix a specific issue.
Return ONLY JSON:
{"full_new_content": "COMPLETE new file content", "change_summary": "what changed"}
Return the ENTIRE file. Never truncate."""


async def staged_plan_fixes(codebase_map: dict, diagnosis: dict, config, goal: str = "") -> dict:
    """
    v19 Two-phase planning: triage (which files?) then targeted per-file edits.
    Solves the 8k token limit problem for multi-file changes.
    """
    from salim.ai import SalimAI
    ai = SalimAI(config)
    errors_text = _build_errors_context(diagnosis)

    # Phase 1: Triage
    triage_prompt = (
        f"Files: {codebase_map['summary']['total_files']}, "
        f"Lines: {codebase_map['summary']['total_lines']}\n"
        f"Import graph: {dict(list(codebase_map.get('import_graph',{}).items())[:8])}\n\n"
        f"Errors:\n{errors_text[:2000]}\n"
        + (f"Goal: {goal}\n" if goal else "")
        + "\nWhich files need to change? JSON only."
    )
    triage = None
    try:
        raw, _ = await ai.chat(
            messages=[{"role": "user", "content": triage_prompt}],
            system=TRIAGE_SYSTEM, max_tokens=1000,
        )
        raw = _re_sp.sub(r"```(?:json)?\s*|\s*```", "", raw.strip())
        m = _re_sp.search(r"\{.*\}", raw, _re_sp.DOTALL)
        if m:
            triage = _json_sp.loads(m.group())
    except Exception as e:
        logger.warning(f"Triage failed ({e}), falling back to standard plan_fixes")
        return await plan_fixes(codebase_map, diagnosis, config, goal)

    if not triage or not triage.get("files_to_change"):
        return await plan_fixes(codebase_map, diagnosis, config, goal)

    # Phase 2: Edit each file individually
    all_changes = []
    for fi in sorted(triage["files_to_change"], key=lambda x: x.get("priority", 99))[:8]:
        rel = fi["file"]
        # Find file in codebase map (try with/without prefix)
        fdata = codebase_map["files"].get(rel)
        if not fdata:
            matches = [k for k in codebase_map["files"] if k.endswith(rel) or rel.endswith(k.split("/")[-1])]
            if matches:
                rel, fdata = matches[0], codebase_map["files"][matches[0]]
        if not fdata:
            continue

        file_errors = "\n".join(
            e.get("message","") for e in diagnosis.get("all_errors",[])
            if rel in e.get("file","") or rel.split("/")[-1] in e.get("file","")
        )[:800]

        edit_prompt = (
            f"File: {rel}\nReason: {fi['reason']}\n"
            f"Errors: {file_errors}\n"
            + (f"Goal: {goal}\n" if goal else "")
            + f"\nCURRENT CONTENT:\n{fdata['content'][:14000]}\n\nEdit this file. JSON only."
        )
        try:
            raw, _ = await ai.chat(
                messages=[{"role": "user", "content": edit_prompt}],
                system=SINGLE_FILE_EDIT_SYSTEM, max_tokens=6000,
            )
            raw = _re_sp.sub(r"```(?:json)?\s*|\s*```", "", raw.strip())
            m = _re_sp.search(r"\{.*\}", raw, _re_sp.DOTALL)
            if m:
                ed = _json_sp.loads(m.group())
                if ed.get("full_new_content"):
                    all_changes.append({
                        "file": rel, "action": "modify",
                        "reason": fi["reason"],
                        "affects_files": fi.get("depends_on", []),
                        "full_new_content": ed["full_new_content"],
                    })
        except Exception as e:
            logger.error(f"Staged edit failed for {rel}: {e}")

    if not all_changes:
        return await plan_fixes(codebase_map, diagnosis, config, goal)

    plan = {
        "summary": triage.get("summary", f"Staged: {len(all_changes)} files"),
        "risk_level": triage.get("risk_level","medium"),
        "changes": all_changes,
        "test_command": "python3 -m py_compile salim/**/*.py",
        "version_bump": "patch",
        "changelog_entry": f"Staged triage+edit: {len(all_changes)} files fixed",
        "_staged": True,
    }
    _save_plan(plan)
    return plan


PLAN_SYSTEM = """You are Salim's autonomous self-development AI.
You have full access to the entire Salim codebase and all detected errors.
Your job: produce a comprehensive, safe, correct multi-file edit plan.

CRITICAL RULES:
- You must understand ALL file relationships before editing ANY file
- An edit to one file may require corresponding edits to other files
- Never make an edit that breaks working code to fix broken code
- Always check: if you add a function, update all import sites
- Always check: if you rename/remove something, update all references
- Always check: if you change a function signature, update all call sites
- Write complete, working code — not snippets or abbreviated versions
- Use Python best practices, proper error handling, type hints
- The goal is production-quality code that works first time

You MUST respond with ONLY a valid JSON object:
{
  "summary": "one paragraph describing what you found and what you'll fix",
  "risk_level": "low|medium|high",
  "changes": [
    {
      "file": "relative/path/from/package/root.py",
      "action": "modify|create|delete",
      "reason": "why this change is needed",
      "affects_files": ["list of other files this change touches"],
      "full_new_content": "COMPLETE new content of the file (for modify/create)",
      "delete_confirmed": true
    }
  ],
  "test_command": "command to run to verify the fix worked",
  "version_bump": "patch|minor|major|none",
  "changelog_entry": "human-readable description of what was fixed/added"
}

For "modify" actions, "full_new_content" must be the ENTIRE new file content.
Never use "..." or truncation — write out every line.
Never output partial code. The file will be overwritten exactly as you provide it.
"""


async def plan_fixes(
    codebase_map: dict,
    diagnosis: dict,
    config,
    goal: str = "",
) -> Optional[dict]:
    """
    Send the full codebase map and diagnosis to the AI.
    AI returns a structured plan covering all affected files.
    Uses the maximum context window available.
    """
    from salim.ai import SalimAI
    ai = SalimAI(config)

    # Build a compact but complete representation of the codebase
    # that fits within the 128k context budget
    codebase_text = _build_codebase_context(codebase_map, diagnosis)
    errors_text   = _build_errors_context(diagnosis)
    goal_text     = f"\nDEVELOPER GOAL: {goal}" if goal else ""

    user_prompt = f"""FULL CODEBASE ANALYSIS:
{codebase_text}

DETECTED ERRORS AND ISSUES:
{errors_text}
{goal_text}

CURRENT TIME: {datetime.now().strftime('%Y-%m-%d %H:%M')}

Analyse the entire codebase structure and all errors above.
Produce a comprehensive edit plan that fixes ALL issues without introducing new ones.
Remember: you must output COMPLETE file contents for every modified file."""

    try:
        response = await ai.chat(
            messages=[{"role": "user", "content": user_prompt}],
            system=PLAN_SYSTEM,
            max_tokens=8000,
        )
        text = response.strip()
        # Strip markdown fences
        text = re.sub(r"```(?:json)?\s*", "", text).replace("```", "").strip()
        match = re.search(r"\{.*\}", text, re.DOTALL)
        if match:
            plan = json.loads(match.group())
            _save_plan(plan)
            return plan
    except json.JSONDecodeError as e:
        logger.error(f"Plan JSON parse failed: {e}")
    except Exception as e:
        logger.error(f"AI plan failed: {e}")
    return None


def _build_codebase_context(codebase_map: dict, diagnosis: dict) -> str:
    """Build a token-efficient but comprehensive codebase representation."""
    parts = []
    root  = codebase_map.get("root", "")
    summary = codebase_map.get("summary", {})

    parts.append(f"Root: {root}")
    parts.append(f"Files: {summary.get('total_files',0)} | "
                 f"Lines: {summary.get('total_lines',0)} | "
                 f"Symbols: {summary.get('total_symbols',0)}")
    parts.append("")

    # Files with syntax errors — include full content
    syntax_errs = {e["file"] for e in diagnosis.get("syntax_errors", [])}
    import_errs  = {e["file"] for e in diagnosis.get("import_errors", [])}
    priority_files = syntax_errs | import_errs

    # Always include critical files
    critical = {
        "salim/bot.py", "salim/ai.py", "salim/cli.py", "salim/config.py",
        "salim/auto_install.py",
    }

    # Include all files, full content for errored ones, summary for others
    for rel, fdata in sorted(codebase_map["files"].items()):
        ast_info  = fdata["ast_info"]
        syn_err   = ast_info.get("syntax_error")
        is_error  = rel in priority_files or syn_err
        is_critical = any(rel.endswith(c.split("/")[-1]) or rel == c for c in critical)

        header = (f"\n{'='*60}\n"
                  f"FILE: {rel} ({fdata['lines']} lines)\n"
                  f"Classes: {', '.join(ast_info.get('classes', [])) or 'none'}\n"
                  f"Functions: {', '.join(ast_info.get('functions', [])[:15]) or 'none'}\n"
                  f"Imports: {', '.join(ast_info.get('salim_imports', []))}\n")

        if syn_err:
            header += f"⚠️ SYNTAX ERROR: {syn_err}\n"

        if is_error or is_critical or fdata["lines"] < 100:
            # Include full content for errored/critical/small files
            parts.append(header + "FULL CONTENT:\n" + fdata["content"])
        else:
            # For large working files, include header + first 60 lines
            preview = "\n".join(fdata["content"].splitlines()[:60])
            parts.append(header + f"PREVIEW (first 60 of {fdata['lines']} lines):\n{preview}\n...(truncated)")

    return "\n".join(parts)[:MAX_TOKENS * 3]  # rough char estimate


def _build_errors_context(diagnosis: dict) -> str:
    parts = []
    for err in diagnosis.get("all_errors", []):
        etype   = err.get("type", "?")
        file_   = err.get("file", "?")
        line    = err.get("line", "")
        msg     = err.get("message", "")
        detail  = err.get("detail", "") or err.get("text", "")
        loc     = f":{line}" if line else ""
        parts.append(f"[{etype}] {file_}{loc}: {msg}" +
                     (f"\n  Detail: {detail[:200]}" if detail else ""))
    if not parts:
        parts.append("No errors detected.")
    return "\n".join(parts)


def _save_plan(plan: dict):
    PLAN_FILE.write_text(json.dumps(plan, indent=2))

def _load_plan() -> Optional[dict]:
    if PLAN_FILE.exists():
        try:
            return json.loads(PLAN_FILE.read_text())
        except Exception:
            pass
    return None

def _clear_plan():
    PLAN_FILE.unlink(missing_ok=True)


# ══════════════════════════════════════════════════════════════════════════════
#  STEP 4: APPLY — atomic multi-file edits with backup
# ══════════════════════════════════════════════════════════════════════════════

def apply_plan(plan: dict, root: Path) -> dict:
    """
    Apply all file changes atomically with full rollback.

    v19: If ANY write produces a SyntaxError or exception after others
    have already succeeded, ALL changes are rolled back from backup.
    No partial states ever reach the live codebase.
    """
    changes = plan.get("changes", [])
    applied = []
    skipped = []
    errors  = []
    backups = {}  # rel_path -> Path of backup file

    # ─ Phase 1: Backup every file to be touched ─────────────────────────────
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    for change in changes:
        rel    = change.get("file", "")
        action = change.get("action", "modify")
        fpath  = root.parent / rel
        if action in ("modify", "delete") and fpath.exists():
            bak = BACKUP_DIR / f"{ts}_{rel.replace('/', '__')}.bak"
            bak.parent.mkdir(parents=True, exist_ok=True)
            try:
                import shutil as _sh
                _sh.copy2(str(fpath), str(bak))
                backups[rel] = bak
            except Exception as e:
                errors.append({"file": rel, "error": f"Backup failed: {e}"})

    if errors:
        return {"applied": [], "skipped": [], "errors": errors,
                "rolled_back": False, "backup_dir": str(BACKUP_DIR)}

    # ─ Phase 2: Apply changes ────────────────────────────────────────────────
    for change in changes:
        rel     = change.get("file", "")
        action  = change.get("action", "modify")
        content_new = change.get("full_new_content", "")
        fpath   = root.parent / rel

        try:
            if action == "delete":
                if change.get("delete_confirmed"):
                    fpath.unlink(missing_ok=True)
                    applied.append({"file": rel, "action": "delete"})
                else:
                    skipped.append({"file": rel, "reason": "delete_confirmed not set"})

            elif action in ("modify", "create"):
                if not content_new:
                    skipped.append({"file": rel, "reason": "full_new_content empty"})
                    continue

                # Compute semantic diff
                old_text = fpath.read_text("utf-8", errors="replace") if fpath.exists() else ""
                old_set  = set(old_text.splitlines())
                new_set  = set(content_new.splitlines())

                fpath.parent.mkdir(parents=True, exist_ok=True)
                fpath.write_text(content_new, encoding="utf-8")

                # Immediate syntax check
                try:
                    import ast as _ast
                    _ast.parse(content_new, filename=rel)
                    syntax_ok = True
                except SyntaxError as se:
                    syntax_ok = False
                    # Roll back this file immediately
                    if rel in backups:
                        import shutil as _sh
                        _sh.copy2(str(backups[rel]), str(fpath))
                    errors.append({
                        "file": rel,
                        "error": f"SyntaxError line {se.lineno}: {se.msg}"
                    })
                    continue

                applied.append({
                    "file": rel, "action": action,
                    "lines_added": len(new_set - old_set),
                    "lines_removed": len(old_set - new_set),
                    "syntax_ok": syntax_ok,
                })
            else:
                skipped.append({"file": rel, "reason": f"unknown action: {action}"})

        except Exception as e:
            errors.append({"file": rel, "error": str(e)})

    # ─ Phase 3: If errors occurred, roll back ALL successful edits ───────────
    rolled_back = False
    if errors and applied:
        import shutil as _sh
        for entry in applied:
            rel2  = entry["file"]
            fpath = root.parent / rel2
            if rel2 in backups:
                try:
                    _sh.copy2(str(backups[rel2]), str(fpath))
                    rolled_back = True
                except Exception:
                    pass
            elif entry.get("action") == "create":
                try:
                    fpath.unlink(missing_ok=True)
                    rolled_back = True
                except Exception:
                    pass
        if rolled_back:
            applied = []  # no changes survived

    return {
        "applied":      applied,
        "skipped":      skipped,
        "errors":       errors,
        "rolled_back":  rolled_back,
        "backup_dir":   str(BACKUP_DIR),
        "backup_count": len(backups),
    }


async def verify(root: Path, plan: dict) -> dict:
    """Re-diagnose after applying changes. Return new diagnosis."""
    # Run the test command specified in the plan if any
    test_cmd = plan.get("test_command", "")
    test_result = None
    if test_cmd:
        try:
            proc = await asyncio.create_subprocess_shell(
                test_cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                cwd=str(root.parent),
                env={**os.environ, "PYTHONPATH": str(root.parent)},
            )
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=120)
            test_result = {
                "command":     test_cmd,
                "returncode":  proc.returncode,
                "output":      stdout.decode("utf-8", errors="replace").strip()[-2000:],
            }
        except asyncio.TimeoutError:
            test_result = {"command": test_cmd, "error": "Timeout"}
        except Exception as e:
            test_result = {"command": test_cmd, "error": str(e)}

    new_diagnosis = await diagnose(root)
    new_diagnosis["custom_test"] = test_result
    return new_diagnosis


# ══════════════════════════════════════════════════════════════════════════════
#  STEP 6: COMMIT — git commit
# ══════════════════════════════════════════════════════════════════════════════

async def git_commit(root: Path, message: str, token: str = "", remote_url: str = "") -> dict:
    """Stage all changes and commit."""
    result = {"success": False, "output": "", "sha": ""}
    repo_root = root.parent  # project root (contains pyproject.toml)

    # Configure remote URL with token if provided
    if token and remote_url:
        # Embed token in URL: https://token@github.com/user/repo.git
        auth_url = _embed_token_in_url(remote_url, token)
        await _git_run(repo_root, ["remote", "set-url", "origin", auth_url])

    # Configure git identity if not set
    await _git_run(repo_root, ["config", "user.email", "salim-bot@localhost"])
    await _git_run(repo_root, ["config", "user.name", "Salim Self-Developer"])

    # Stage all changes
    out = await _git_run(repo_root, ["add", "-A"])

    # Check if anything to commit
    status = await _git_run(repo_root, ["status", "--porcelain"])
    if not status.get("output", "").strip():
        result["output"] = "Nothing to commit — working tree clean."
        result["success"] = True
        return result

    # Commit
    commit_out = await _git_run(repo_root, ["commit", "-m", message])
    result["output"]  = commit_out.get("output", "")
    result["success"] = commit_out.get("returncode", 1) == 0

    # Get SHA of new commit
    sha_out = await _git_run(repo_root, ["rev-parse", "--short", "HEAD"])
    result["sha"] = sha_out.get("output", "").strip()

    return result


# ══════════════════════════════════════════════════════════════════════════════
#  STEP 7: PUSH — git push to GitHub
# ══════════════════════════════════════════════════════════════════════════════

async def git_push(root: Path, token: str = "", remote_url: str = "") -> dict:
    """Push to GitHub using stored credentials."""
    repo_root = root.parent

    if token and remote_url:
        auth_url = _embed_token_in_url(remote_url, token)
        await _git_run(repo_root, ["remote", "set-url", "origin", auth_url])

    # Determine current branch
    branch_out = await _git_run(repo_root, ["rev-parse", "--abbrev-ref", "HEAD"])
    branch = branch_out.get("output", "main").strip() or "main"

    # Push
    push_out = await _git_run(repo_root, ["push", "origin", branch], timeout=60)
    return {
        "success":  push_out.get("returncode", 1) == 0,
        "branch":   branch,
        "output":   push_out.get("output", ""),
    }


def _embed_token_in_url(url: str, token: str) -> str:
    """Embed PAT token into HTTPS git URL."""
    # https://github.com/user/repo → https://TOKEN@github.com/user/repo
    if "://" in url:
        scheme, rest = url.split("://", 1)
        # Remove existing auth if present
        if "@" in rest:
            rest = rest.split("@", 1)[1]
        return f"{scheme}://{token}@{rest}"
    return url


async def _git_run(cwd: Path, args: list[str], timeout: int = 30) -> dict:
    """Run a git command and return output."""
    if not shutil.which("git"):
        return {"returncode": 1, "output": "git not found"}
    env = {**os.environ, "GIT_TERMINAL_PROMPT": "0"}
    proc = await asyncio.create_subprocess_exec(
        "git", *args,
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
        cwd=str(cwd), env=env,
    )
    try:
        out, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        return {
            "returncode": proc.returncode,
            "output":     out.decode("utf-8", errors="replace").strip(),
        }
    except asyncio.TimeoutError:
        proc.kill()
        return {"returncode": 1, "output": "git command timed out"}


# ══════════════════════════════════════════════════════════════════════════════
#  STEP 8: PUBLISH — bump version + build + upload to PyPI
# ══════════════════════════════════════════════════════════════════════════════

async def publish_to_pypi(root: Path, pypi_token: str, bump: str = "patch") -> dict:
    """
    1. Bump version in pyproject.toml
    2. Build wheel + sdist
    3. Upload with twine using API token
    """
    result = {"success": False, "version": "", "output": ""}
    repo_root = root.parent

    # ── 1. Find and bump version ──────────────────────────────────────────────
    pyproject = repo_root / "pyproject.toml"
    if not pyproject.exists():
        result["output"] = "pyproject.toml not found"
        return result

    content = pyproject.read_text()
    version_match = re.search(r'version\s*=\s*"([^"]+)"', content)
    if not version_match:
        result["output"] = "Could not find version in pyproject.toml"
        return result

    old_version = version_match.group(1)
    new_version = _bump_version(old_version, bump)
    new_content = content.replace(
        f'version = "{old_version}"',
        f'version = "{new_version}"',
        1
    )
    pyproject.write_text(new_content)
    result["version"] = new_version

    # Also update __version__ in __init__.py if present
    init_file = root / "__init__.py"
    if init_file.exists():
        init_content = init_file.read_text()
        if "__version__" in init_content:
            init_content = re.sub(
                r'__version__\s*=\s*["\'][^"\']+["\']',
                f'__version__ = "{new_version}"',
                init_content
            )
            init_file.write_text(init_content)

    # ── 2. Ensure build tools ─────────────────────────────────────────────────
    for pkg in ["build", "twine"]:
        proc = await asyncio.create_subprocess_exec(
            sys.executable, "-m", "pip", "install", pkg,
            "--quiet", "--disable-pip-version-check",
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
        )
        await asyncio.wait_for(proc.communicate(), timeout=60)

    # ── 3. Clean old dist ─────────────────────────────────────────────────────
    dist_dir = repo_root / "dist"
    if dist_dir.exists():
        shutil.rmtree(str(dist_dir))

    # ── 4. Build ──────────────────────────────────────────────────────────────
    build_proc = await asyncio.create_subprocess_exec(
        sys.executable, "-m", "build",
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
        cwd=str(repo_root),
    )
    try:
        out, _ = await asyncio.wait_for(build_proc.communicate(), timeout=120)
        build_output = out.decode("utf-8", errors="replace").strip()
    except asyncio.TimeoutError:
        result["output"] = "Build timed out"
        return result

    if build_proc.returncode != 0:
        result["output"] = f"Build failed:\n{build_output[-500:]}"
        return result

    # ── 5. Upload with twine ──────────────────────────────────────────────────
    upload_env = {
        **os.environ,
        "TWINE_USERNAME": "__token__",
        "TWINE_PASSWORD": pypi_token,
    }
    upload_proc = await asyncio.create_subprocess_exec(
        sys.executable, "-m", "twine", "upload", "dist/*",
        "--non-interactive", "--skip-existing",
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
        cwd=str(repo_root), env=upload_env,
    )
    try:
        out, _ = await asyncio.wait_for(upload_proc.communicate(), timeout=120)
        upload_output = out.decode("utf-8", errors="replace").strip()
    except asyncio.TimeoutError:
        result["output"] = "Upload timed out"
        return result

    result["success"] = upload_proc.returncode == 0
    result["output"]  = f"Build:\n{build_output[-300:]}\n\nUpload:\n{upload_output[-300:]}"
    return result


def _bump_version(version: str, bump: str) -> str:
    """Bump a semver string: major/minor/patch."""
    parts = version.split(".")
    while len(parts) < 3:
        parts.append("0")
    try:
        major, minor, patch = int(parts[0]), int(parts[1]), int(parts[2].split("-")[0])
    except ValueError:
        return version  # unknown format, return as-is
    if bump == "major":
        return f"{major+1}.0.0"
    elif bump == "minor":
        return f"{major}.{minor+1}.0"
    else:  # patch
        return f"{major}.{minor}.{patch+1}"


# ══════════════════════════════════════════════════════════════════════════════
#  STEP 9: SELF-UPDATE — pip install --upgrade, then restart
# ══════════════════════════════════════════════════════════════════════════════

async def self_update(package_name: str = "salim") -> dict:
    """pip install --upgrade the package from PyPI, then schedule a restart."""
    result = {"success": False, "version": "", "output": ""}

    proc = await asyncio.create_subprocess_exec(
        sys.executable, "-m", "pip", "install", "--upgrade",
        "--disable-pip-version-check", package_name,
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
    )
    try:
        out, _ = await asyncio.wait_for(proc.communicate(), timeout=180)
        output = out.decode("utf-8", errors="replace").strip()
        result["success"] = proc.returncode == 0
        result["output"]  = output[-500:]

        if result["success"]:
            # Get newly installed version
            ver_proc = await asyncio.create_subprocess_exec(
                sys.executable, "-m", "pip", "show", package_name,
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            )
            ver_out, _ = await ver_proc.communicate()
            ver_text = ver_out.decode("utf-8", errors="replace")
            ver_match = re.search(r"Version:\s*(.+)", ver_text)
            if ver_match:
                result["version"] = ver_match.group(1).strip()
    except asyncio.TimeoutError:
        result["output"] = "pip upgrade timed out"

    return result


async def restart_bot():
    """Re-exec the current process — restarts the bot with the new code."""
    # Give a brief moment for the Telegram message to send
    await asyncio.sleep(3)
    os.execv(sys.executable, [sys.executable] + sys.argv)


# ══════════════════════════════════════════════════════════════════════════════
#  FULL AGENTIC LOOP — orchestrates all steps
# ══════════════════════════════════════════════════════════════════════════════

async def run_dev_cycle(
    app: Application,
    config,
    chat_id: int,
    user_id:  int,
    goal:     str = "",
    dry_run:  bool = False,
) -> dict:
    """
    Full ANALYSE → DIAGNOSE → PLAN → APPLY → VERIFY → COMMIT → PUSH → PUBLISH → UPDATE cycle.
    Reports progress to Telegram throughout.
    Returns a summary dict.
    """
    state = _load_state()
    cycle = state.get("cycle_count", 0) + 1

    async def _msg(text: str, **kw):
        try:
            return await app.bot.send_message(chat_id=chat_id, text=text,
                                               parse_mode=H, **kw)
        except Exception:
            return None

    await _msg(f"🛠 <b>Dev Cycle #{cycle} starting</b>{' (dry-run)' if dry_run else ''}\n"
               f"<i>Goal: {esc(goal or 'auto-fix and improve')}</i>")

    root = _find_salim_root()
    if not root:
        await _msg("❌ Could not locate Salim source root.")
        return {"error": "source not found"}

    summary = {"cycle": cycle, "errors_before": 0, "errors_after": 0,
               "files_changed": 0, "pushed": False, "published": False}

    # ── 1. Analyse ────────────────────────────────────────────────────────────
    await _msg("🔍 <b>Step 1/9:</b> Analysing codebase…")
    codebase_map = analyse_codebase(root)
    sm = codebase_map["summary"]
    await _msg(f"📊 <b>Codebase:</b> {sm['total_files']} files · "
               f"{sm['total_lines']:,} lines · {sm['total_symbols']} symbols")

    # ── 2. Diagnose ───────────────────────────────────────────────────────────
    await _msg("🩺 <b>Step 2/9:</b> Running diagnostics…")
    diagnosis = await diagnose(root)
    n_errors  = len(diagnosis["all_errors"])
    summary["errors_before"] = n_errors

    if n_errors == 0 and not goal:
        await _msg("✅ <b>No errors found.</b> Codebase looks healthy.\n"
                   "<i>Provide a /dev goal to add features or improvements.</i>")
        return summary

    if n_errors > 0:
        err_preview = "\n".join(
            f"• [{e['type']}] {e.get('file','?')}: {e.get('message','')[:80]}"
            for e in diagnosis["all_errors"][:8]
        )
        await _msg(f"⚠️ <b>{n_errors} issue(s) found:</b>\n<pre>{esc(err_preview)}</pre>")

    if dry_run:
        await _msg("🔎 <b>Dry-run mode</b> — stopping before applying changes.")
        return summary

    # ── 3. Plan ───────────────────────────────────────────────────────────────
    await _msg("🧠 <b>Step 3/9:</b> AI planning fixes (using full 128k context)…")
    plan = await plan_fixes(codebase_map, diagnosis, config, goal)
    if not plan:
        await _msg("❌ AI could not generate a plan. Will retry next cycle.")
        return summary

    changes  = plan.get("changes", [])
    risk     = plan.get("risk_level", "low")
    risk_ico = {"low": "🟢", "medium": "🟡", "high": "🔴"}.get(risk, "⚪")
    plan_preview = "\n".join(
        f"  {i+1}. [{c.get('action','?')}] {c.get('file','?')} — {c.get('reason','')[:60]}"
        for i, c in enumerate(changes[:10])
    )
    await _msg(f"{risk_ico} <b>Plan ({len(changes)} file changes, risk: {risk}):</b>\n"
               f"<i>{esc(plan.get('summary','')[:200])}</i>\n\n<pre>{esc(plan_preview)}</pre>")

    # ── 4. Apply ──────────────────────────────────────────────────────────────
    await _msg("✏️ <b>Step 4/9:</b> Applying changes…")
    apply_result = apply_plan(plan, root)
    applied = apply_result["applied"]
    failed  = apply_result["failed"]
    summary["files_changed"] = len(applied)

    if failed:
        fail_txt = "\n".join(f"  ❌ {f['file']}: {f['error'][:80]}" for f in failed[:5])
        await _msg(f"⚠️ <b>{len(failed)} change(s) failed to apply:</b>\n<pre>{esc(fail_txt)}</pre>")

    if applied:
        applied_txt = "\n".join(
            f"  ✅ {a['action']} {a['file']} ({a.get('lines','?')} lines)"
            for a in applied[:10]
        )
        await _msg(f"✅ <b>{len(applied)} file(s) changed:</b>\n<pre>{esc(applied_txt)}</pre>")

    if not applied:
        await _msg("❌ No changes were successfully applied.")
        return summary

    # ── 5. Verify ─────────────────────────────────────────────────────────────
    await _msg("🔬 <b>Step 5/9:</b> Verifying changes…")
    new_diagnosis = await verify(root, plan)
    n_after       = len(new_diagnosis["all_errors"])
    summary["errors_after"] = n_after

    if n_after == 0:
        await _msg("✅ <b>Verification passed.</b> All errors resolved.")
    elif n_after < n_errors:
        await _msg(f"⚠️ <b>Partial fix:</b> {n_errors} → {n_after} errors remain.")
    else:
        await _msg(f"❌ <b>Errors unchanged ({n_after}).</b> Running another planning round…")
        # Self-healing: one more AI round to fix remaining issues
        plan2 = await plan_fixes(codebase_map, new_diagnosis, config,
                                  goal=f"Fix remaining errors: {_build_errors_context(new_diagnosis)[:500]}")
        if plan2:
            apply2 = apply_plan(plan2, root)
            final_diagnosis = await diagnose(root)
            n_final = len(final_diagnosis["all_errors"])
            summary["errors_after"] = n_final
            await _msg(f"🔄 <b>Round 2 complete:</b> {n_after} → {n_final} errors.")

    # ── 6. Commit ─────────────────────────────────────────────────────────────
    github_token = state.get("github_token", "")
    github_url   = state.get("github_url", "")

    if not github_token:
        await _msg("ℹ️ No GitHub token — skipping commit/push/publish.")
        return summary

    await _msg("📝 <b>Step 6/9:</b> Committing to git…")
    changelog = plan.get("changelog_entry", f"Auto-fix: {n_errors} issue(s) resolved")
    commit_msg = (f"[salim-dev] {changelog}\n\n"
                  f"Cycle: #{cycle}\n"
                  f"Errors before: {n_errors} → after: {summary['errors_after']}\n"
                  f"Files changed: {len(applied)}\n"
                  f"Changed: {', '.join(a['file'] for a in applied[:5])}")

    commit_result = await git_commit(root, commit_msg, github_token, github_url)
    if commit_result["success"]:
        sha = commit_result.get("sha", "")
        await _msg(f"✅ <b>Committed:</b> {esc(sha)} — {esc(changelog[:100])}")
        state["last_commit"] = sha
    else:
        await _msg(f"⚠️ <b>Commit:</b> {esc(commit_result.get('output','')[:200])}")

    # ── 7. Push ───────────────────────────────────────────────────────────────
    await _msg("⬆️ <b>Step 7/9:</b> Pushing to GitHub…")
    push_result = await git_push(root, github_token, github_url)
    if push_result["success"]:
        await _msg(f"✅ <b>Pushed</b> to <code>{esc(push_result.get('branch','main'))}</code>")
        summary["pushed"] = True
    else:
        await _msg(f"❌ <b>Push failed:</b> {esc(push_result.get('output','')[:200])}")

    # ── 8. Publish to PyPI ────────────────────────────────────────────────────
    pypi_token = state.get("pypi_token", "")
    if not pypi_token:
        await _msg("ℹ️ No PyPI token — skipping publish.")
    else:
        bump = plan.get("version_bump", "patch")
        if bump == "none":
            await _msg("ℹ️ <b>Step 8/9:</b> No version bump needed.")
        else:
            await _msg(f"📦 <b>Step 8/9:</b> Publishing to PyPI ({bump} bump)…")
            pub_result = await publish_to_pypi(root, pypi_token, bump)
            if pub_result["success"]:
                new_ver = pub_result.get("version", "?")
                await _msg(f"✅ <b>Published v{esc(new_ver)}</b> to PyPI")
                state["last_publish"] = new_ver
                summary["published"] = True
            else:
                await _msg(f"❌ <b>Publish failed:</b>\n<pre>{esc(pub_result.get('output','')[:300])}</pre>")

    # ── 9. Self-update ────────────────────────────────────────────────────────
    if summary.get("published"):
        await _msg("🔄 <b>Step 9/9:</b> Self-updating from PyPI…")
        upd_result = await self_update()
        if upd_result["success"]:
            new_ver = upd_result.get("version", "?")
            await _msg(f"✅ <b>Updated to v{esc(new_ver)}</b>. Restarting bot…")
            state["last_version"] = new_ver
            _save_state(state)
            asyncio.create_task(restart_bot())
        else:
            await _msg(f"⚠️ Self-update failed: {esc(upd_result.get('output','')[:200])}")
    else:
        await _msg("✅ <b>Step 9/9:</b> Self-update skipped (no new PyPI release).")

    # ── Update state ──────────────────────────────────────────────────────────
    state["cycle_count"] = cycle
    state["last_cycle"]  = datetime.now().isoformat()
    _save_state(state)

    _append_log({
        "cycle":          cycle,
        "goal":           goal or "auto",
        "errors_before":  summary["errors_before"],
        "errors_after":   summary["errors_after"],
        "files_changed":  summary["files_changed"],
        "pushed":         summary["pushed"],
        "published":      summary["published"],
    })

    await _msg(f"🏁 <b>Dev Cycle #{cycle} complete</b>\n"
               f"Errors: {summary['errors_before']} → {summary['errors_after']}\n"
               f"Files changed: {summary['files_changed']}\n"
               f"Pushed: {'✅' if summary['pushed'] else '❌'}  "
               f"Published: {'✅' if summary['published'] else '❌'}")

    return summary


# ══════════════════════════════════════════════════════════════════════════════
#  BACKGROUND AUTO-LOOP
# ══════════════════════════════════════════════════════════════════════════════

_dev_task: Optional[asyncio.Task] = None

async def _dev_loop(app: Application, config):
    while True:
        state = _load_state()
        if not state.get("enabled"):
            await asyncio.sleep(60)
            continue

        chat_id = state.get("chat_id")
        user_id = state.get("user_id")
        if not chat_id:
            await asyncio.sleep(60)
            continue

        try:
            await run_dev_cycle(app, config, chat_id, user_id)
        except Exception as e:
            logger.error(f"Dev cycle error: {e}")
            try:
                await app.bot.send_message(
                    chat_id=chat_id,
                    text=f"⚠️ <b>Dev cycle error:</b> {esc(str(e)[:200])}",
                    parse_mode=H,
                )
            except Exception:
                pass

        state    = _load_state()
        interval = state.get("interval_mins", 60)
        await asyncio.sleep(interval * 60)

def start_dev_loop(app: Application, config):
    global _dev_task
    if _dev_task is None or _dev_task.done():
        _dev_task = asyncio.create_task(_dev_loop(app, config))
        logger.info("Dev loop started")


# ══════════════════════════════════════════════════════════════════════════════
#  TELEGRAM COMMAND HANDLERS
# ══════════════════════════════════════════════════════════════════════════════

class SelfDeveloperHandlers:

    @require_auth
    async def cmd_dev(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        msg  = update.effective_message
        args = ctx.args or []
        sub  = args[0].lower() if args else "help"
        state = _load_state()

        if not state.get("developer_mode"):
            await msg.reply_text(
                "⚠️ <b>Developer mode is not enabled.</b>\n"
                "Enable it during <code>salim setup</code> by answering yes to "
                "\"Are you a developer of Salim?\"",
                parse_mode=H,
            )
            return

        if sub == "on":
            state.update({
                "enabled": True,
                "chat_id": msg.chat_id,
                "user_id": update.effective_user.id,
            })
            _save_state(state)
            start_dev_loop(self._app, self.config)
            interval = state.get("interval_mins", 60)
            await msg.reply_text(
                f"🛠 <b>Auto Dev Mode ENABLED</b>\n"
                f"Salim will run dev cycles every <b>{interval} min</b>\n\n"
                f"<b>GitHub:</b> {esc(state.get('github_url','not set'))}\n"
                f"<b>GitHub token:</b> {'✅ set' if state.get('github_token') else '❌ not set'}\n"
                f"<b>PyPI token:</b> {'✅ set' if state.get('pypi_token') else '❌ not set'}",
                parse_mode=H,
            )

        elif sub == "off":
            state["enabled"] = False
            _save_state(state)
            await msg.reply_text("🔴 <b>Auto dev mode disabled.</b>", parse_mode=H)

        elif sub == "run":
            goal = " ".join(args[1:]) if len(args) > 1 else ""
            state.update({"chat_id": msg.chat_id, "user_id": update.effective_user.id})
            _save_state(state)
            asyncio.create_task(run_dev_cycle(
                self._app, self.config, msg.chat_id,
                update.effective_user.id, goal=goal,
            ))

        elif sub == "analyse":
            status = await msg.reply_text("🔍 Analysing codebase…")
            root = _find_salim_root()
            if not root:
                await status.edit_text("❌ Salim source root not found.")
                return
            codebase_map = analyse_codebase(root)
            sm = codebase_map["summary"]
            # Build file tree summary
            files_txt = "\n".join(
                f"  {rel} ({d['lines']}L)"
                for rel, d in sorted(codebase_map["files"].items())[:30]
            )
            report = (
                f"📊 <b>Codebase Analysis</b>\n\n"
                f"Root: <code>{esc(str(root))}</code>\n"
                f"Files: {sm['total_files']}\n"
                f"Lines: {sm['total_lines']:,}\n"
                f"Symbols: {sm['total_symbols']}\n"
                f"Issues: {sm['total_issues']}\n\n"
                f"<b>Files:</b>\n<pre>{esc(files_txt)}</pre>"
            )
            await status.edit_text(report[:4000], parse_mode=H)

        elif sub == "diagnose":
            status = await msg.reply_text("🩺 Running diagnostics…")
            root = _find_salim_root()
            if not root:
                await status.edit_text("❌ Source root not found.")
                return
            diagnosis = await diagnose(root)
            n = len(diagnosis["all_errors"])
            if n == 0:
                await status.edit_text("✅ <b>No errors found.</b> Codebase is clean.", parse_mode=H)
                return
            lines = [f"🩺 <b>{n} issue(s) found:</b>\n"]
            for e in diagnosis["all_errors"][:20]:
                lines.append(
                    f"• [{e['type']}] <code>{esc(e.get('file','?'))}</code>"
                    f"{':%d' % e['line'] if e.get('line') else ''}: "
                    f"{esc(e.get('message','')[:100])}"
                )
            await status.edit_text("\n".join(lines)[:4000], parse_mode=H)

        elif sub == "plan":
            root = _find_salim_root()
            if not root:
                await msg.reply_text("❌ Source root not found.")
                return
            goal = " ".join(args[1:]) if len(args) > 1 else ""
            status = await msg.reply_text("🧠 Building plan (this may take a moment)…")
            codebase_map = analyse_codebase(root)
            diagnosis    = await diagnose(root)
            plan = await plan_fixes(codebase_map, diagnosis, self.config, goal)
            if not plan:
                await status.edit_text("❌ Could not generate plan.")
                return
            changes = plan.get("changes", [])
            lines = [
                f"📋 <b>Pending Plan ({len(changes)} changes)</b>\n",
                f"Risk: {plan.get('risk_level','?')}\n",
                f"<i>{esc(plan.get('summary','')[:300])}</i>\n",
            ]
            for i, c in enumerate(changes[:15], 1):
                lines.append(f"{i}. [{c.get('action','?')}] "
                             f"<code>{esc(c.get('file','?'))}</code>\n"
                             f"   <i>{esc(c.get('reason','')[:80])}</i>")
            await status.edit_text("\n".join(lines)[:4000], parse_mode=H)

        elif sub == "apply":
            plan = _load_plan()
            if not plan:
                await msg.reply_text("❌ No pending plan. Run /dev plan first.")
                return
            root = _find_salim_root()
            if not root:
                await msg.reply_text("❌ Source root not found.")
                return
            status = await msg.reply_text("✏️ Applying plan…")
            result = apply_plan(plan, root)
            applied = result["applied"]
            failed  = result["failed"]
            lines = [f"✏️ <b>Apply Result</b>\n",
                     f"Applied: {len(applied)}  Failed: {len(failed)}\n"]
            for a in applied[:10]:
                lines.append(f"✅ {a.get('action','?')} {esc(a.get('file','?'))}")
            for f in failed[:5]:
                lines.append(f"❌ {esc(f.get('file','?'))}: {esc(f.get('error','')[:60])}")
            if applied:
                _clear_plan()
            await status.edit_text("\n".join(lines)[:4000], parse_mode=H)

        elif sub == "push":
            root = _find_salim_root()
            if not root:
                await msg.reply_text("❌ Source root not found.")
                return
            status = await msg.reply_text("⬆️ Committing and pushing to GitHub…")
            commit_res = await git_commit(
                root,
                f"[salim-dev] Manual push at {datetime.now().strftime('%Y-%m-%d %H:%M')}",
                state.get("github_token", ""),
                state.get("github_url", ""),
            )
            push_res = await git_push(
                root,
                state.get("github_token", ""),
                state.get("github_url", ""),
            )
            lines = [
                f"📝 Commit: {'✅' if commit_res['success'] else '❌'} {esc(commit_res.get('sha',''))}\n",
                f"⬆️ Push: {'✅' if push_res['success'] else '❌'} branch {esc(push_res.get('branch','?'))}\n",
                f"<pre>{esc(push_res.get('output','')[:300])}</pre>",
            ]
            await status.edit_text("\n".join(lines), parse_mode=H)

        elif sub == "publish":
            pypi_token = state.get("pypi_token", "")
            if not pypi_token:
                await msg.reply_text("❌ No PyPI token set.")
                return
            root = _find_salim_root()
            if not root:
                await msg.reply_text("❌ Source root not found.")
                return
            bump = args[1] if len(args) > 1 and args[1] in ("patch","minor","major") else "patch"
            status = await msg.reply_text(f"📦 Publishing to PyPI ({bump} bump)…")
            result = await publish_to_pypi(root, pypi_token, bump)
            if result["success"]:
                await status.edit_text(
                    f"✅ <b>Published v{esc(result.get('version','?'))}</b> to PyPI",
                    parse_mode=H)
            else:
                await status.edit_text(
                    f"❌ <b>Publish failed:</b>\n<pre>{esc(result.get('output','')[:500])}</pre>",
                    parse_mode=H)

        elif sub == "selfupdate":
            status = await msg.reply_text("🔄 Updating Salim from PyPI…")
            result = await self_update()
            if result["success"]:
                await status.edit_text(
                    f"✅ <b>Updated to v{esc(result.get('version','?'))}.</b> Restarting…",
                    parse_mode=H)
                asyncio.create_task(restart_bot())
            else:
                await status.edit_text(
                    f"❌ Update failed: {esc(result.get('output','')[:300])}",
                    parse_mode=H)

        elif sub == "log":
            n    = int(args[1]) if len(args) > 1 and args[1].isdigit() else 10
            logs = _read_log(n)
            if not logs:
                await msg.reply_text("📋 No dev cycles logged yet.")
                return
            lines = [f"📋 <b>Last {len(logs)} Dev Cycles:</b>\n"]
            for e in logs:
                ts  = e.get("ts", "")[:16]
                cyc = e.get("cycle", "?")
                eb  = e.get("errors_before", 0)
                ea  = e.get("errors_after", 0)
                fc  = e.get("files_changed", 0)
                pushed  = "✅" if e.get("pushed") else "○"
                pubbed  = "✅" if e.get("published") else "○"
                lines.append(f"#{cyc} [{ts}] {eb}→{ea} err, {fc} files "
                             f"push:{pushed} pypi:{pubbed}")
            await msg.reply_text("\n".join(lines), parse_mode=H)

        elif sub == "interval":
            if len(args) < 2 or not args[1].isdigit():
                await msg.reply_text("Usage: /dev interval <minutes>")
                return
            n = max(5, int(args[1]))
            state["interval_mins"] = n
            _save_state(state)
            await msg.reply_text(f"⏱ Dev cycle interval set to <b>{n} min</b>.", parse_mode=H)

        elif sub == "status":
            enabled    = state.get("enabled", False)
            last_cycle = state.get("last_cycle", "never")
            cycles     = state.get("cycle_count", 0)
            gh_url     = state.get("github_url", "not set")
            gh_token   = "✅ set" if state.get("github_token") else "❌ not set"
            pypi_tok   = "✅ set" if state.get("pypi_token") else "❌ not set"
            last_ver   = state.get("last_version", "unknown")
            last_pub   = state.get("last_publish", "never")
            root       = _find_salim_root()

            await msg.reply_text(
                f"🛠 <b>Developer Mode Status</b>\n\n"
                f"Auto cycles: {'🟢 ON' if enabled else '🔴 OFF'}\n"
                f"Interval: {state.get('interval_mins', 60)} min\n"
                f"Cycles run: {cycles}\n"
                f"Last cycle: {last_cycle}\n"
                f"Source root: <code>{esc(str(root) if root else 'not found')}</code>\n\n"
                f"GitHub URL: <code>{esc(gh_url)}</code>\n"
                f"GitHub token: {gh_token}\n"
                f"PyPI token: {pypi_tok}\n\n"
                f"Current version: {esc(last_ver)}\n"
                f"Last published: {esc(last_pub)}",
                parse_mode=H,
            )

        else:
            await msg.reply_text(
                "🛠 <b>Salim Self-Developer</b>\n\n"
                "<code>/dev status</code>           — status + config\n"
                "<code>/dev run [goal]</code>        — run full cycle now\n"
                "<code>/dev analyse</code>           — show codebase map\n"
                "<code>/dev diagnose</code>          — find all errors\n"
                "<code>/dev plan [goal]</code>       — AI plan (dry-run)\n"
                "<code>/dev apply</code>             — apply pending plan\n"
                "<code>/dev push</code>              — commit + push to GitHub\n"
                "<code>/dev publish [patch|minor|major]</code> — publish to PyPI\n"
                "<code>/dev selfupdate</code>        — pip upgrade + restart\n"
                "<code>/dev log [n]</code>           — show cycle history\n"
                "<code>/dev on</code>                — enable auto cycles\n"
                "<code>/dev off</code>               — disable auto cycles\n"
                "<code>/dev interval &lt;mins&gt;</code>    — set interval\n\n"
                "<i>Salim reads the entire codebase, plans safe multi-file fixes, "
                "tests, pushes to GitHub, publishes to PyPI, and self-updates.</i>",
                parse_mode=H,
            )
