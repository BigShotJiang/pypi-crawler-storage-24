"""
Salim Event Bus v19 - Async inter-handler pub/sub

Decouples handlers from each other. Handlers emit events;
other handlers subscribe to react without direct coupling.

Usage:
    from salim.handlers.event_bus import event_bus
    event_bus.on("email.received", my_callback)
    await event_bus.emit("email.received", {"uid": "123", "subject": "..."})

Standard events:
  system.cpu_high, system.disk_low, system.ram_high, system.battery_low
  email.received, email.sent
  file.created, file.deleted
  autonomous.cycle_done, autonomous.goal_added
  agent.task_done
  plan.phase_advanced, plan.completed
  user.message, ai.response
  self_developer.cycle
"""
from __future__ import annotations
import asyncio, logging, time
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

logger = logging.getLogger("salim.event_bus")
EVENT_LOG_FILE = Path.home() / ".salim" / "events.jsonl"


class EventBus:
    def __init__(self):
        self._subscribers: dict[str, list] = defaultdict(list)
        self._wildcard: list = []
        self._event_count = 0
        self._last_events: list[dict] = []

    def on(self, event_name: str, callback: Callable) -> "EventBus":
        if event_name == "*":
            self._wildcard.append(callback)
        else:
            self._subscribers[event_name].append(callback)
        return self

    def off(self, event_name: str, callback: Callable):
        if event_name == "*":
            self._wildcard = [c for c in self._wildcard if c != callback]
        else:
            self._subscribers[event_name] = [c for c in self._subscribers[event_name] if c != callback]

    async def emit(self, event_name: str, payload: Any = None, source: str = "?") -> int:
        self._event_count += 1
        event = {"name": event_name, "payload": payload, "source": source,
                 "ts": time.time(), "ts_human": datetime.now().isoformat()[:19],
                 "id": self._event_count}
        self._last_events.append(event)
        if len(self._last_events) > 100:
            self._last_events.pop(0)
        asyncio.create_task(self._log_event(event))

        callbacks = list(self._wildcard) + list(self._subscribers.get(event_name, []))
        if "." in event_name:
            prefix = event_name.rsplit(".", 1)[0]
            callbacks.extend(self._subscribers.get(f"{prefix}.*", []))

        if not callbacks:
            return 0

        async def _call(cb):
            try:
                if asyncio.iscoroutinefunction(cb):
                    await cb(event_name, payload)
                else:
                    cb(event_name, payload)
            except Exception as e:
                logger.warning(f"Event handler error [{event_name}]: {e}")

        await asyncio.gather(*[_call(cb) for cb in callbacks], return_exceptions=True)
        return len(callbacks)

    def emit_sync(self, event_name: str, payload: Any = None, source: str = "?"):
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                loop.create_task(self.emit(event_name, payload, source))
        except Exception:
            pass

    async def _log_event(self, event: dict):
        try:
            import json
            with open(EVENT_LOG_FILE, "a") as f:
                f.write(json.dumps(event, default=str) + "\n")
        except Exception:
            pass

    def recent_events(self, n: int = 20, event_filter: str = "") -> list:
        events = self._last_events
        if event_filter:
            events = [e for e in events if e["name"].startswith(event_filter)]
        return events[-n:]

    def subscriber_count(self) -> dict:
        result = {k: len(v) for k, v in self._subscribers.items() if v}
        if self._wildcard:
            result["*"] = len(self._wildcard)
        return result

    def stats(self) -> dict:
        return {"total_events_emitted": self._event_count,
                "active_subscriptions": sum(len(v) for v in self._subscribers.values()) + len(self._wildcard),
                "recent_buffer": len(self._last_events)}


event_bus = EventBus()


async def emit_email_received(uid: str, from_addr: str, subject: str, source: str = "email"):
    await event_bus.emit("email.received", {"uid": uid, "from": from_addr, "subject": subject}, source)

async def emit_system_alert(alert_type: str, payload: dict, source: str = "system"):
    await event_bus.emit(f"system.{alert_type}", payload, source)

async def emit_autonomous_cycle(actions_taken: int, success_count: int, source: str = "autonomous"):
    await event_bus.emit("autonomous.cycle_done", {"actions_taken": actions_taken, "success_count": success_count}, source)

async def emit_plan_event(event: str, plan_id: str, extra: dict = None, source: str = "planner"):
    await event_bus.emit(f"plan.{event}", {"plan_id": plan_id, **(extra or {})}, source)


class EventBusHandlers:
    async def cmd_events(self, update, ctx):
        import html
        esc = lambda v: html.escape(str(v), quote=False)
        H = "HTML"
        msg = update.effective_message
        args = ctx.args or []
        sub = args[0].lower() if args else "recent"

        if sub == "list":
            counts = event_bus.subscriber_count()
            if not counts:
                await msg.reply_text("No active subscriptions.", parse_mode=H)
                return
            lines = ["<b>Event Subscriptions</b>"]
            for event, count in sorted(counts.items()):
                lines.append(f"  <code>{esc(event)}</code> - {count} subscriber(s)")
            await msg.reply_text("\n".join(lines), parse_mode=H)
            return

        if sub == "stats":
            s = event_bus.stats()
            await msg.reply_text(
                f"<b>Event Bus</b>\nEmitted: {s['total_events_emitted']}\n"
                f"Subscriptions: {s['active_subscriptions']}\nBuffer: {s['recent_buffer']}",
                parse_mode=H)
            return

        event_filter = "" if sub == "recent" else sub
        events = event_bus.recent_events(n=15, event_filter=event_filter)
        if not events:
            await msg.reply_text("No recent events.", parse_mode=H)
            return
        lines = ["<b>Recent Events</b>"]
        for e in reversed(events):
            ts = e.get("ts_human", "?")[-8:]
            payload = e.get("payload") or {}
            summary = ""
            if isinstance(payload, dict):
                summary = " ".join(f"{k}={str(v)[:20]}" for k, v in list(payload.items())[:2])
            lines.append(f"  <code>{ts}</code> <b>{esc(e['name'])}</b> <i>{esc(summary)}</i>")
        await msg.reply_text("\n".join(lines), parse_mode=H)
