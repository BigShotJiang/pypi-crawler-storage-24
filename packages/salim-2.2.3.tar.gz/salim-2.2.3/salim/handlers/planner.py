"""
Salim Long-Horizon Planner v19 — Multi-cycle goal execution

Maintains a persistent plan graph across autonomous cycles:
  GOAL → PHASES → STEPS → ACTIONS

Unlike the flat goal list in autonomous.py, plans here are:
  - Decomposed into ordered phases (e.g. "research", "implement", "verify")
  - Each phase has success criteria that are checked before advancing
  - State survives bot restarts (SQLite-backed)
  - Progress is tracked per-step with outcomes
  - The planner injects "current phase context" into each autonomous cycle

Commands:
  /plan new <goal>         — AI decomposes goal into phased plan
  /plan list               — list active plans with progress
  /plan status <id>        — detailed plan status + current step
  /plan advance <id>       — manually advance to next phase
  /plan abort <id>         — cancel a plan
  /plan inject             — inject top plan into next autonomous cycle
"""
from __future__ import annotations

import asyncio
import html
import json
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.planner")
esc = lambda v: html.escape(str(v), quote=False)
H = "HTML"

PLAN_DIR = Path.home() / ".salim" / "plans"
PLAN_DIR.mkdir(parents=True, exist_ok=True)


# ── PLAN DATA MODEL ───────────────────────────────────────────────────────────

def _plan_file(plan_id: str) -> Path:
    return PLAN_DIR / f"{plan_id}.json"


def load_plan(plan_id: str) -> Optional[dict]:
    f = _plan_file(plan_id)
    if not f.exists():
        return None
    try:
        return json.loads(f.read_text())
    except Exception:
        return None


def save_plan(plan: dict):
    f = _plan_file(plan["id"])
    f.write_text(json.dumps(plan, indent=2, default=str))
    f.chmod(0o600)


def list_plans(user_id: int) -> list[dict]:
    plans = []
    for f in sorted(PLAN_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
        try:
            p = json.loads(f.read_text())
            if p.get("user_id") == user_id and p.get("status") not in ("aborted", "complete"):
                plans.append(p)
        except Exception:
            pass
    return plans[:20]


def get_active_plan(user_id: int) -> Optional[dict]:
    """Get the highest-priority active plan for a user."""
    plans = list_plans(user_id)
    if not plans:
        return None
    # Prioritize by status: in_progress > not_started
    in_progress = [p for p in plans if p.get("status") == "in_progress"]
    return in_progress[0] if in_progress else plans[0]


# ── AI PLAN DECOMPOSITION ─────────────────────────────────────────────────────

DECOMPOSE_SYSTEM = """You are Salim's strategic planner. Decompose complex goals into phased plans.

Return ONLY a JSON object:
{
  "goal_summary": "one-line summary of the goal",
  "estimated_cycles": 3,
  "phases": [
    {
      "name": "Research",
      "description": "What this phase accomplishes",
      "steps": [
        {
          "id": "1.1",
          "action": "concrete action description",
          "tool": "shell|python|browse|file_write|email_send|report",
          "expected_output": "what success looks like",
          "success_criteria": "how to verify completion"
        }
      ],
      "completion_criteria": "how to know this phase is done"
    }
  ],
  "final_success_criteria": "overall goal completion criteria",
  "risks": ["potential issue 1", "potential issue 2"]
}

Rules:
- 2-5 phases per plan
- 2-6 steps per phase  
- Steps must be concrete, executable, verifiable
- Each step uses exactly one tool type
- Phases are ordered: gather info → process → output → verify
- Be realistic about what can be done programmatically
"""


async def decompose_goal(goal: str, ai) -> Optional[dict]:
    """Use AI to decompose a goal into a phased plan."""
    try:
        raw, _ = await ai._call_with_fallback(
            [{"role": "user", "content": f"Decompose this goal into a phased plan:\n\n{goal}"}],
            system=DECOMPOSE_SYSTEM,
            max_tokens=2000,
            temperature=0.2,
        )
        raw = re.sub(r"```(?:json)?\s*|\s*```", "", raw.strip())
        m = re.search(r"\{.*\}", raw, re.DOTALL)
        if m:
            return json.loads(m.group())
    except Exception as e:
        logger.error(f"Goal decomposition failed: {e}")
    return None


def create_plan(user_id: int, goal: str, decomposition: dict) -> dict:
    """Create a plan record from AI decomposition."""
    import hashlib, time
    plan_id = hashlib.md5(f"{user_id}{goal}{time.time()}".encode()).hexdigest()[:8]
    phases = decomposition.get("phases", [])
    for i, phase in enumerate(phases):
        for step in phase.get("steps", []):
            step["status"] = "pending"
            step["outcome"] = None
            step["executed_at"] = None
    return {
        "id": plan_id,
        "user_id": user_id,
        "goal": goal,
        "goal_summary": decomposition.get("goal_summary", goal[:80]),
        "estimated_cycles": decomposition.get("estimated_cycles", 3),
        "phases": phases,
        "current_phase_idx": 0,
        "current_step_idx": 0,
        "status": "not_started",
        "created_at": datetime.now().isoformat(),
        "updated_at": datetime.now().isoformat(),
        "final_success_criteria": decomposition.get("final_success_criteria", ""),
        "risks": decomposition.get("risks", []),
        "outcomes": [],
    }


def get_current_context(plan: dict) -> str:
    """
    Generate context string to inject into autonomous cycle THINK prompt.
    This tells the autonomous engine EXACTLY what step to execute next.
    """
    if plan["status"] in ("complete", "aborted"):
        return ""

    phases = plan.get("phases", [])
    phase_idx = plan.get("current_phase_idx", 0)
    step_idx = plan.get("current_step_idx", 0)

    if phase_idx >= len(phases):
        return f"PLAN {plan['id']}: All phases complete. Verify final goal: {plan.get('final_success_criteria', '')}"

    phase = phases[phase_idx]
    steps = phase.get("steps", [])

    if step_idx >= len(steps):
        return (
            f"PLAN {plan['id']} Phase '{phase['name']}': All steps done. "
            f"Check completion: {phase.get('completion_criteria', '')}. "
            f"If complete, mark phase done."
        )

    step = steps[step_idx]
    completed_steps = [
        f"✅ {s['id']}: {s['action'][:60]}"
        for s in steps[:step_idx]
        if s.get("status") == "done"
    ]

    context = (
        f"\n\n🗺️ ACTIVE PLAN [{plan['id']}]: {plan['goal_summary']}\n"
        f"📍 Phase {phase_idx+1}/{len(phases)}: {phase['name']}\n"
        f"📋 Current step {step['id']}: {step['action']}\n"
        f"🔧 Tool: {step['tool']} | Expected: {step['expected_output']}\n"
        f"✓ Success when: {step['success_criteria']}\n"
    )
    if completed_steps:
        context += f"✅ Completed: {', '.join(completed_steps[-3:])}\n"
    context += (
        f"\n⚠️ PRIORITY: Execute the current step above. "
        f"Include plan_id={plan['id']} and step_id={step['id']} in memory_updates.\n"
    )
    return context


def advance_plan_step(plan: dict, step_outcome: str, success: bool) -> dict:
    """Mark current step done and advance to next."""
    phases = plan.get("phases", [])
    phase_idx = plan.get("current_phase_idx", 0)
    step_idx = plan.get("current_step_idx", 0)

    if phase_idx >= len(phases):
        plan["status"] = "complete"
        return plan

    phase = phases[phase_idx]
    steps = phase.get("steps", [])

    if step_idx < len(steps):
        steps[step_idx]["status"] = "done" if success else "failed"
        steps[step_idx]["outcome"] = step_outcome[:500]
        steps[step_idx]["executed_at"] = datetime.now().isoformat()

    plan["outcomes"].append({
        "phase": phase["name"],
        "step_id": steps[step_idx]["id"] if step_idx < len(steps) else "?",
        "outcome": step_outcome[:300],
        "success": success,
        "ts": datetime.now().isoformat(),
    })

    # Advance step
    next_step = step_idx + 1
    if next_step >= len(steps):
        # Advance phase
        next_phase = phase_idx + 1
        if next_phase >= len(phases):
            plan["status"] = "complete"
        else:
            plan["current_phase_idx"] = next_phase
            plan["current_step_idx"] = 0
            plan["status"] = "in_progress"
    else:
        plan["current_step_idx"] = next_step
        plan["status"] = "in_progress"

    plan["updated_at"] = datetime.now().isoformat()
    try:
        from salim.handlers.event_bus import emit_plan_event
        import asyncio as _aio
        event_type = "completed" if plan["status"] == "complete" else "phase_advanced"
        _aio.get_event_loop().create_task(emit_plan_event(event_type, plan["id"]))
    except Exception:
        pass
    return plan


def plan_progress_bar(plan: dict) -> str:
    """Generate ASCII progress bar for a plan."""
    phases = plan.get("phases", [])
    total_steps = sum(len(p.get("steps", [])) for p in phases)
    done_steps = sum(
        sum(1 for s in p.get("steps", []) if s.get("status") == "done")
        for p in phases
    )
    if total_steps == 0:
        return "[░░░░░░░░░░] 0%"
    pct = done_steps / total_steps
    filled = int(pct * 10)
    bar = "█" * filled + "░" * (10 - filled)
    return f"[{bar}] {int(pct*100)}% ({done_steps}/{total_steps} steps)"


# ── TELEGRAM COMMANDS ─────────────────────────────────────────────────────────

class PlannerHandlers:

    @require_auth
    async def cmd_plan(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /plan new <goal>       — AI decomposes goal into phased plan
        /plan list             — active plans
        /plan status <id>      — detailed status
        /plan advance <id>     — force advance to next step
        /plan abort <id>       — cancel plan
        /plan context          — show what's injected into next autonomous cycle
        """
        msg = update.effective_message
        user_id = update.effective_user.id
        args = ctx.args or []
        sub = args[0].lower() if args else "list"

        # ── list ──────────────────────────────────────────────────────────────
        if sub == "list":
            plans = list_plans(user_id)
            if not plans:
                await msg.reply_text(
                    "📋 <b>No active plans.</b>\n\n"
                    "Start a long-horizon goal:\n"
                    "<code>/plan new migrate my project to Python 3.12</code>\n"
                    "<code>/plan new organize and backup all my Documents</code>\n"
                    "<code>/plan new set up a full dev environment for Django</code>",
                    parse_mode=H,
                )
                return
            lines = ["📋 <b>Active Plans</b>\n"]
            for p in plans:
                bar = plan_progress_bar(p)
                phase_n = p.get("current_phase_idx", 0) + 1
                n_phases = len(p.get("phases", []))
                status_icon = {"not_started": "⏳", "in_progress": "🔄", "complete": "✅", "aborted": "❌"}.get(p["status"], "❓")
                lines.append(
                    f"{status_icon} <b>[{p['id']}]</b> {esc(p['goal_summary'][:60])}\n"
                    f"  {bar} · Phase {phase_n}/{n_phases}"
                )
            await msg.reply_text("\n".join(lines), parse_mode=H)
            return

        # ── new <goal> ────────────────────────────────────────────────────────
        if sub == "new":
            goal = " ".join(args[1:])
            if not goal:
                await msg.reply_text("Usage: <code>/plan new &lt;your goal&gt;</code>", parse_mode=H)
                return

            thinking = await msg.reply_text(
                f"🧠 <i>Decomposing goal into phases…</i>\n<b>{esc(goal[:100])}</b>",
                parse_mode=H,
            )
            from salim.ai import SalimAI
            ai = SalimAI(self.config)
            decomp = await decompose_goal(goal, ai)
            if not decomp:
                await thinking.edit_text("❌ Could not decompose goal. Try rephrasing.", parse_mode=H)
                return

            plan = create_plan(user_id, goal, decomp)
            save_plan(plan)

            phases = plan["phases"]
            lines = [
                f"✅ <b>Plan [{plan['id']}] created</b>\n",
                f"🎯 <b>Goal:</b> {esc(plan['goal_summary'])}",
                f"📊 <b>Estimated cycles:</b> {plan['estimated_cycles']}",
                f"📋 <b>{len(phases)} phases:</b>\n",
            ]
            for i, phase in enumerate(phases):
                lines.append(f"  <b>Phase {i+1}: {esc(phase['name'])}</b>")
                lines.append(f"  <i>{esc(phase['description'][:80])}</i>")
                for step in phase.get("steps", [])[:3]:
                    lines.append(f"    • {esc(step['action'][:70])}")
                if len(phase.get("steps", [])) > 3:
                    lines.append(f"    <i>…+{len(phase['steps'])-3} more steps</i>")
                lines.append("")
            if plan.get("risks"):
                lines.append(f"⚠️ <b>Risks:</b> {esc(', '.join(plan['risks'][:2]))}")
            lines.append(f"\n<i>Use /auto think to start execution, or /plan status {plan['id']}</i>")

            await thinking.edit_text("\n".join(lines), parse_mode=H)
            return

        # ── status <id> ───────────────────────────────────────────────────────
        if sub == "status":
            plan_id = args[1] if len(args) > 1 else ""
            if not plan_id:
                plan = get_active_plan(user_id)
            else:
                plan = load_plan(plan_id)
            if not plan:
                await msg.reply_text("❌ Plan not found.", parse_mode=H)
                return

            lines = [
                f"📋 <b>Plan [{plan['id']}]</b>",
                f"🎯 {esc(plan['goal_summary'])}",
                f"📊 {plan_progress_bar(plan)}",
                "",
            ]
            phases = plan.get("phases", [])
            curr_phase = plan.get("current_phase_idx", 0)
            for i, phase in enumerate(phases):
                icon = "✅" if i < curr_phase else ("🔄" if i == curr_phase else "⏳")
                lines.append(f"{icon} <b>Phase {i+1}: {esc(phase['name'])}</b>")
                for step in phase.get("steps", []):
                    s_icon = {"done": "✅", "failed": "❌", "pending": "◻️"}.get(step.get("status"), "◻️")
                    lines.append(f"  {s_icon} {esc(step['action'][:70])}")
                    if step.get("outcome"):
                        lines.append(f"    <i>→ {esc(step['outcome'][:80])}</i>")
                lines.append("")

            if plan.get("risks"):
                lines.append(f"⚠️ Risks: {esc('; '.join(plan['risks']))}")
            lines.append(f"<i>/plan advance {plan['id']} to skip current step</i>")
            await msg.reply_text("\n".join(lines), parse_mode=H)
            return

        # ── advance <id> ──────────────────────────────────────────────────────
        if sub == "advance":
            plan_id = args[1] if len(args) > 1 else ""
            plan = load_plan(plan_id) if plan_id else get_active_plan(user_id)
            if not plan:
                await msg.reply_text("❌ Plan not found.", parse_mode=H)
                return
            plan = advance_plan_step(plan, "manually advanced by user", True)
            save_plan(plan)
            await msg.reply_text(
                f"⏭ Plan <b>[{plan['id']}]</b> advanced.\n{plan_progress_bar(plan)}",
                parse_mode=H,
            )
            return

        # ── abort <id> ────────────────────────────────────────────────────────
        if sub == "abort":
            plan_id = args[1] if len(args) > 1 else ""
            plan = load_plan(plan_id) if plan_id else get_active_plan(user_id)
            if not plan:
                await msg.reply_text("❌ Plan not found.", parse_mode=H)
                return
            plan["status"] = "aborted"
            plan["updated_at"] = datetime.now().isoformat()
            save_plan(plan)
            await msg.reply_text(f"❌ Plan [{plan['id']}] aborted.", parse_mode=H)
            return

        # ── context ───────────────────────────────────────────────────────────
        if sub == "context":
            plan = get_active_plan(user_id)
            if not plan:
                await msg.reply_text("No active plan to inject.", parse_mode=H)
                return
            ctx_text = get_current_context(plan)
            await msg.reply_text(
                f"📌 <b>Plan context that will be injected:</b>\n<pre>{esc(ctx_text)}</pre>",
                parse_mode=H,
            )
            return

        # ── default help ──────────────────────────────────────────────────────
        await msg.reply_text(
            "🗺️ <b>Long-Horizon Planner</b>\n\n"
            "<code>/plan new &lt;complex goal&gt;</code>  — AI decomposes into phases\n"
            "<code>/plan list</code>                  — active plans\n"
            "<code>/plan status [id]</code>           — detailed progress\n"
            "<code>/plan advance [id]</code>          — skip to next step\n"
            "<code>/plan abort [id]</code>            — cancel plan\n"
            "<code>/plan context</code>               — what injects into /auto next\n\n"
            "<i>Works with /auto — inject plan context into autonomous cycles.</i>",
            parse_mode=H,
        )
