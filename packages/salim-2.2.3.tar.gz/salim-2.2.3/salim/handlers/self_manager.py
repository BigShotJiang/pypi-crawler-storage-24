"""
Salim Self-Manager v18 — Health scoring, smart cleanup, backup, auto-update.

Commands:
  /selfstatus   — health score 0-100, component breakdown
  /selfupdate   — pull latest from PyPI and restart
  /selfclean    — smart cleanup (tmp, logs, pip cache, auto trash)
  /selfbackup   — backup config + database to tar.gz
"""
from __future__ import annotations

import asyncio
import html
import json
import logging
import os
import platform
import shutil
import subprocess
import sys
import tarfile
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import Application, ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.self_manager")
esc = lambda v: html.escape(str(v), quote=False)
H = "HTML"

SELF_DIR    = Path.home() / ".salim" / "self_manager"
BACKUP_DIR  = Path.home() / ".salim" / "backups"
LOG_FILE    = Path.home() / ".salim" / "salim.log"
CONFIG_FILE = Path.home() / ".salim" / "config.env"
DB_FILE     = Path.home() / ".salim" / "salim.db"

SELF_DIR.mkdir(parents=True, exist_ok=True)
BACKUP_DIR.mkdir(parents=True, exist_ok=True)


# ── HEALTH SCORING ────────────────────────────────────────────────────────────

def compute_health_score() -> tuple[int, dict]:
    """
    Compute a 0-100 health score for Salim and the host system.
    Returns (score, breakdown_dict).
    """
    scores = {}

    # 1. CPU (20 pts) — penalize if > 85%
    try:
        import psutil
        cpu = psutil.cpu_percent(interval=0.5)
        scores["cpu"] = max(0, 20 - int((cpu / 100) * 20)) if cpu <= 85 else max(0, 20 - int((cpu - 85) * 1.5))
    except Exception:
        scores["cpu"] = 10  # unknown

    # 2. RAM (20 pts)
    try:
        import psutil
        ram = psutil.virtual_memory().percent
        scores["ram"] = max(0, 20 - int((ram / 100) * 20)) if ram <= 80 else max(0, 20 - int((ram - 80) * 2))
    except Exception:
        scores["ram"] = 10

    # 3. Disk (20 pts)
    try:
        import psutil
        disk = psutil.disk_usage("/").percent
        scores["disk"] = max(0, 20) if disk < 70 else max(0, 20 - int((disk - 70) * 2))
    except Exception:
        scores["disk"] = 10

    # 4. Recent errors in log (20 pts)
    try:
        if LOG_FILE.exists():
            recent_log = LOG_FILE.read_text(errors="replace")[-5000:]
            error_count = recent_log.count("ERROR") + recent_log.count("CRITICAL") * 2
            scores["errors"] = max(0, 20 - error_count * 2)
        else:
            scores["errors"] = 20
    except Exception:
        scores["errors"] = 10

    # 5. Uptime / stability (10 pts) — high uptime is good (stable)
    try:
        import psutil
        uptime_h = (time.time() - psutil.boot_time()) / 3600
        scores["uptime"] = 10 if uptime_h > 1 else int(uptime_h * 10)
    except Exception:
        scores["uptime"] = 5

    # 6. Config file integrity (10 pts)
    try:
        has_token = False
        if CONFIG_FILE.exists():
            content = CONFIG_FILE.read_text()
            has_token = "SALIM_BOT_TOKEN" in content and len(content) > 50
        scores["config"] = 10 if has_token else 0
    except Exception:
        scores["config"] = 5

    total = sum(scores.values())
    return min(100, total), scores


def _health_emoji(score: int) -> str:
    if score >= 85: return "🟢"
    if score >= 60: return "🟡"
    if score >= 40: return "🟠"
    return "🔴"


# ── SMART CLEANUP ─────────────────────────────────────────────────────────────

def compute_cleanup_targets() -> dict:
    """Find files/dirs that can be safely cleaned. Returns {path: size_bytes}."""
    targets = {}

    # 1. Python cache dirs
    for cache_dir in Path.home().rglob("__pycache__"):
        try:
            size = sum(f.stat().st_size for f in cache_dir.rglob("*") if f.is_file())
            targets[str(cache_dir)] = size
        except Exception:
            pass

    # 2. .pyc files
    for pyc in Path.home().rglob("*.pyc"):
        try:
            targets[str(pyc)] = pyc.stat().st_size
        except Exception:
            pass

    # 3. pip cache
    pip_cache = Path.home() / ".cache" / "pip"
    if pip_cache.exists():
        try:
            size = sum(f.stat().st_size for f in pip_cache.rglob("*") if f.is_file())
            targets[str(pip_cache)] = size
        except Exception:
            pass

    # 4. Temp files older than 24h
    import tempfile
    tmp_dir = Path(tempfile.gettempdir())
    cutoff = time.time() - 86400
    for f in tmp_dir.iterdir():
        try:
            if f.stat().st_mtime < cutoff:
                size = f.stat().st_size if f.is_file() else sum(
                    x.stat().st_size for x in f.rglob("*") if x.is_file()
                )
                if size > 1024:  # skip tiny files
                    targets[str(f)] = size
        except Exception:
            pass

    # 5. Salim log if > 10MB
    if LOG_FILE.exists():
        try:
            size = LOG_FILE.stat().st_size
            if size > 10 * 1024 * 1024:
                targets[str(LOG_FILE)] = size
        except Exception:
            pass

    # 6. Old Salim backups (keep only last 3)
    try:
        old_backups = sorted(BACKUP_DIR.glob("*.tar.gz"), key=lambda p: p.stat().st_mtime)[:-3]
        for bk in old_backups:
            targets[str(bk)] = bk.stat().st_size
    except Exception:
        pass

    return targets


async def run_cleanup() -> dict:
    """Execute cleanup. Returns {freed_bytes, files_removed, errors}."""
    targets = compute_cleanup_targets()
    freed = 0
    removed = 0
    errors = []

    for path_str, size in targets.items():
        p = Path(path_str)
        try:
            if p.is_file():
                # Rotate log instead of delete
                if p == LOG_FILE:
                    backup = LOG_FILE.with_suffix(".log.old")
                    p.rename(backup)
                    LOG_FILE.touch()
                else:
                    p.unlink()
                freed += size
                removed += 1
            elif p.is_dir():
                shutil.rmtree(p, ignore_errors=True)
                freed += size
                removed += 1
        except Exception as e:
            errors.append(f"{p.name}: {e}")

    return {"freed_bytes": freed, "files_removed": removed, "errors": errors}


# ── BACKUP ────────────────────────────────────────────────────────────────────

def create_backup() -> Path:
    """Create a timestamped backup of config + database. Returns backup path."""
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = BACKUP_DIR / f"salim_backup_{ts}.tar.gz"

    with tarfile.open(backup_path, "w:gz") as tar:
        # Config file
        if CONFIG_FILE.exists():
            tar.add(CONFIG_FILE, arcname="config.env")
        # Database
        if DB_FILE.exists():
            tar.add(DB_FILE, arcname="salim.db")
        # Memory files
        mem_dir = Path.home() / ".salim" / "memory"
        if mem_dir.exists():
            tar.add(mem_dir, arcname="memory")
        # Autonomous state
        auto_dir = Path.home() / ".salim" / "autonomous"
        if auto_dir.exists():
            tar.add(auto_dir, arcname="autonomous")
        # Notes
        notes_dir = Path.home() / ".salim" / "notes"
        if notes_dir.exists():
            tar.add(notes_dir, arcname="notes")

    backup_path.chmod(0o600)
    return backup_path


# ── SELF-UPDATE ───────────────────────────────────────────────────────────────

async def check_latest_version() -> Optional[str]:
    """Check PyPI for the latest salim version."""
    try:
        import httpx
        async with httpx.AsyncClient(timeout=10) as c:
            r = await c.get("https://pypi.org/pypi/salim/json")
            if r.status_code == 200:
                data = r.json()
                return data["info"]["version"]
    except Exception:
        pass
    return None


def get_installed_version() -> str:
    """Get currently installed salim version."""
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "show", "salim"],
            capture_output=True, text=True
        )
        for line in result.stdout.splitlines():
            if line.startswith("Version:"):
                return line.split(":", 1)[1].strip()
    except Exception:
        pass
    return "unknown"


# ── BACKGROUND SELF-MANAGER ───────────────────────────────────────────────────

_sm_task: Optional[asyncio.Task] = None


async def _self_manager_loop(app: Application, config, admin_chat_id: int):
    """Background loop: auto-cleanup and health monitoring."""
    while True:
        try:
            score, breakdown = compute_health_score()
            if score < 40:
                try:
                    await app.bot.send_message(
                        admin_chat_id,
                        f"⚠️ <b>Salim Health Alert</b>\\n"
                        f"Health score: {score}/100 {_health_emoji(score)}\\n"
                        f"<i>Run /selfstatus for details, /selfclean to clean up.</i>",
                        parse_mode=H,
                    )
                except Exception:
                    pass

            # Auto-cleanup if disk is over 85%
            try:
                import psutil
                disk_pct = psutil.disk_usage("/").percent
                if disk_pct > 85:
                    result = await run_cleanup()
                    freed_mb = result["freed_bytes"] / 1024 / 1024
                    if freed_mb > 10:
                        await app.bot.send_message(
                            admin_chat_id,
                            f"🧹 <b>Auto-cleanup:</b> freed {freed_mb:.1f} MB (disk was {disk_pct:.0f}% full)",
                            parse_mode=H,
                        )
            except Exception:
                pass

        except Exception as e:
            logger.error(f"Self-manager loop error: {e}")

        await asyncio.sleep(3600)  # check every hour


def start_self_manager(app: Application, config, admin_chat_id: int):
    global _sm_task
    if _sm_task is None or _sm_task.done():
        _sm_task = asyncio.create_task(_self_manager_loop(app, config, admin_chat_id))
        logger.info("Self-manager background loop started")


# ── TELEGRAM COMMANDS ─────────────────────────────────────────────────────────

class SelfManagerHandlers:

    @require_auth
    async def cmd_selfstatus(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/selfstatus — comprehensive health report with score 0-100"""
        msg = update.effective_message
        thinking = await msg.reply_text("🔍 <i>Computing health score…</i>", parse_mode=H)

        score, breakdown = compute_health_score()
        emoji = _health_emoji(score)

        # Collect system info
        lines = [f"{emoji} <b>Salim Health Score: {score}/100</b>\n"]

        try:
            import psutil
            cpu = psutil.cpu_percent(interval=0.5)
            mem = psutil.virtual_memory()
            disk = psutil.disk_usage("/")
            uptime_h = round((time.time() - psutil.boot_time()) / 3600, 1)

            cpu_icon = "🔴" if cpu > 85 else "🟡" if cpu > 60 else "🟢"
            mem_icon = "🔴" if mem.percent > 85 else "🟡" if mem.percent > 70 else "🟢"
            disk_icon = "🔴" if disk.percent > 90 else "🟡" if disk.percent > 75 else "🟢"

            lines += [
                "🖥️ <b>System</b>",
                f"  {cpu_icon} CPU: {cpu:.1f}%  (score: {breakdown.get('cpu',0)}/20)",
                f"  {mem_icon} RAM: {mem.percent:.1f}%  (score: {breakdown.get('ram',0)}/20)",
                f"  {disk_icon} Disk: {disk.percent:.1f}%  (score: {breakdown.get('disk',0)}/20)",
                f"  ⏱ Uptime: {uptime_h}h  (score: {breakdown.get('uptime',0)}/10)",
                "",
            ]
        except Exception as e:
            lines.append(f"⚠️ System metrics unavailable: {esc(str(e))}\n")

        # Error log health
        err_score = breakdown.get("errors", 0)
        err_icon = "🟢" if err_score >= 18 else "🟡" if err_score >= 12 else "🔴"
        lines.append(f"📋 <b>Error log:</b> {err_icon} (score: {err_score}/20)")

        # Config integrity
        cfg_score = breakdown.get("config", 0)
        cfg_icon = "🟢" if cfg_score == 10 else "🔴"
        lines.append(f"⚙️ <b>Config:</b> {cfg_icon} (score: {cfg_score}/10)")

        # Installed version
        installed = get_installed_version()
        lines += ["", f"📦 <b>Version:</b> {esc(installed)}"]

        # Backup status
        backups = sorted(BACKUP_DIR.glob("*.tar.gz"), key=lambda p: p.stat().st_mtime, reverse=True)
        if backups:
            last_bk = datetime.fromtimestamp(backups[0].stat().st_mtime).strftime("%Y-%m-%d %H:%M")
            lines.append(f"💾 <b>Last backup:</b> {esc(last_bk)}")
        else:
            lines.append("💾 <b>Last backup:</b> None — run /selfbackup")

        # Cleanup preview
        targets = compute_cleanup_targets()
        total_cleanup = sum(targets.values())
        if total_cleanup > 0:
            lines += ["", f"🧹 <b>Cleanable space:</b> {total_cleanup/1024/1024:.1f} MB — run /selfclean"]

        lines += ["", f"<i>Use /selfclean · /selfbackup · /selfupdate</i>"]

        await thinking.edit_text("\n".join(lines), parse_mode=H)

    @require_auth
    async def cmd_selfclean(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/selfclean — smart cleanup of temp, cache, old logs"""
        msg = update.effective_message

        targets = compute_cleanup_targets()
        if not targets:
            await msg.reply_text("✅ Nothing to clean — system is already tidy!", parse_mode=H)
            return

        total_mb = sum(targets.values()) / 1024 / 1024
        thinking = await msg.reply_text(
            f"🧹 <i>Found {len(targets)} items ({total_mb:.1f} MB). Cleaning…</i>",
            parse_mode=H
        )

        result = await run_cleanup()
        freed_mb = result["freed_bytes"] / 1024 / 1024

        lines = [
            f"✅ <b>Cleanup Complete</b>",
            f"🗑 Items removed: {result['files_removed']}",
            f"💾 Space freed: <b>{freed_mb:.1f} MB</b>",
        ]
        if result["errors"]:
            lines.append(f"\n⚠️ Errors ({len(result['errors'])}):")
            for e in result["errors"][:5]:
                lines.append(f"  • {esc(e[:60])}")

        await thinking.edit_text("\n".join(lines), parse_mode=H)

    @require_auth
    async def cmd_selfbackup(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/selfbackup — backup config + database to tar.gz"""
        msg = update.effective_message
        thinking = await msg.reply_text("💾 <i>Creating backup…</i>", parse_mode=H)

        try:
            backup_path = await asyncio.get_event_loop().run_in_executor(None, create_backup)
            size_kb = backup_path.stat().st_size // 1024

            await thinking.edit_text(
                f"✅ <b>Backup Created</b>\n"
                f"📦 File: <code>{esc(backup_path.name)}</code>\n"
                f"💾 Size: {size_kb} KB\n"
                f"📂 Location: <code>{esc(str(BACKUP_DIR))}</code>",
                parse_mode=H
            )

            # Also send the backup file to Telegram
            try:
                with open(backup_path, "rb") as f:
                    await msg.reply_document(
                        document=f,
                        filename=backup_path.name,
                        caption=f"🔒 Salim backup — {datetime.now().strftime('%Y-%m-%d %H:%M')}"
                    )
            except Exception:
                pass  # File might be too large for Telegram

        except Exception as e:
            await thinking.edit_text(f"❌ Backup failed: {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_selfupdate(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/selfupdate — check for updates and upgrade if available"""
        msg = update.effective_message
        thinking = await msg.reply_text("🔍 <i>Checking for updates…</i>", parse_mode=H)

        installed = get_installed_version()
        latest = await check_latest_version()

        if not latest:
            await thinking.edit_text(
                f"⚠️ Could not reach PyPI. Current version: <code>{esc(installed)}</code>",
                parse_mode=H
            )
            return

        if installed == latest:
            await thinking.edit_text(
                f"✅ <b>Already up to date!</b>\n"
                f"Version: <code>{esc(installed)}</code>",
                parse_mode=H
            )
            return

        await thinking.edit_text(
            f"🔄 <b>Update Available!</b>\n"
            f"Current: <code>{esc(installed)}</code>\n"
            f"Latest: <code>{esc(latest)}</code>\n\n"
            f"<i>Installing update…</i>",
            parse_mode=H
        )

        # Create backup before updating
        try:
            create_backup()
        except Exception:
            pass

        # Run pip upgrade
        proc = await asyncio.create_subprocess_exec(
            sys.executable, "-m", "pip", "install", "--upgrade", "salim",
            "--break-system-packages", "--quiet",
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )
        try:
            out, _ = await asyncio.wait_for(proc.communicate(), timeout=120)
            output = out.decode("utf-8", errors="replace").strip()
            success = proc.returncode == 0
        except asyncio.TimeoutError:
            proc.kill()
            output = "Timed out after 120s"
            success = False

        if success:
            await msg.reply_text(
                f"✅ <b>Updated to {esc(latest)}!</b>\n\n"
                f"<i>Restart Salim to apply the update:</i>\n"
                f"<code>salim stop && salim start</code>",
                parse_mode=H
            )
        else:
            await msg.reply_text(
                f"❌ Update failed:\n<pre>{esc(output[:500])}</pre>",
                parse_mode=H
            )
