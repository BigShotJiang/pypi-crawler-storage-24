"""
Salim Confidence Engine v19 — Uncertainty Quantification + Risk Escalation

Every AI decision is scored for confidence before execution.
Low-confidence decisions are flagged to user instead of blind-executed.

How it works:
  1. After AI generates a plan, each action gets a confidence score 0.0-1.0
  2. Actions below CONFIDENCE_THRESHOLD are held for user approval
  3. The aggregate plan confidence feeds back into the autonomous loop delay
  4. Historical success rates update confidence calibration

Integrates with:
  - autonomous.py  — gates action execution
  - agent2.py      — pre-action confidence check
  - ai_handler.py  — shows confidence on destructive actions
"""
from __future__ import annotations

import json
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Optional

logger = logging.getLogger("salim.confidence")

CONFIDENCE_DIR = Path.home() / ".salim" / "confidence"
CONFIDENCE_DIR.mkdir(parents=True, exist_ok=True)

CALIBRATION_FILE = CONFIDENCE_DIR / "calibration.json"

# Below this → escalate to user
HIGH_RISK_THRESHOLD = 0.55
# Below this for destructive ops → always escalate
DESTRUCTIVE_THRESHOLD = 0.75

DESTRUCTIVE_TYPES = {"file_delete", "shell", "email_send", "screen_click", "apt_install"}


# ── CALIBRATION (historical success rates) ────────────────────────────────────

def load_calibration() -> dict:
    try:
        if CALIBRATION_FILE.exists():
            return json.loads(CALIBRATION_FILE.read_text())
    except Exception:
        pass
    return {}


def save_calibration(cal: dict):
    CALIBRATION_FILE.write_text(json.dumps(cal, indent=2))


def update_calibration(action_type: str, success: bool):
    """Record outcome to improve future confidence estimates."""
    cal = load_calibration()
    key = action_type
    entry = cal.get(key, {"successes": 0, "failures": 0})
    if success:
        entry["successes"] += 1
    else:
        entry["failures"] += 1
    cal[key] = entry
    save_calibration(cal)


def get_historical_success_rate(action_type: str) -> float:
    """Get historical success rate for an action type (0.0-1.0)."""
    cal = load_calibration()
    entry = cal.get(action_type)
    if not entry:
        return 0.75  # optimistic prior for new action types
    total = entry["successes"] + entry["failures"]
    if total < 3:
        return 0.75  # not enough data
    return entry["successes"] / total


# ── CONFIDENCE SCORING ────────────────────────────────────────────────────────

def score_action_confidence(action: dict) -> float:
    """
    Score confidence for a single action (0.0 = no confidence, 1.0 = certain).

    Factors:
      - action type risk
      - command specificity (vague commands → lower confidence)
      - historical success rate for this action type
      - presence of expected_outcome field
      - risk field in action
    """
    atype = action.get("type", "report")
    cmd = action.get("command", "")
    risk = action.get("risk", "low")
    expected = action.get("expected_outcome", "")

    # Base score by action type
    base_scores = {
        "report": 0.98,
        "skip": 0.99,
        "notify": 0.95,
        "file_read": 0.92,
        "clipboard_read": 0.92,
        "python": 0.80,
        "browse": 0.85,
        "http_request": 0.80,
        "shell": 0.70,
        "file_write": 0.75,
        "pip_install": 0.82,
        "apt_install": 0.72,
        "email_read": 0.88,
        "email_search": 0.88,
        "screen_screenshot": 0.90,
        "email_send": 0.65,
        "email_reply": 0.65,
        "file_delete": 0.55,
        "screen_click": 0.60,
        "screen_type": 0.72,
        "browse_click": 0.62,
        "browse_type": 0.65,
        "browse_js": 0.60,
    }
    score = base_scores.get(atype, 0.70)

    # Adjust for risk field
    if risk == "high":
        score *= 0.75
    elif risk == "medium":
        score *= 0.90

    # Penalize vague commands
    if len(cmd) < 5:
        score *= 0.85
    if "TODO" in cmd or "PLACEHOLDER" in cmd.upper():
        score *= 0.40

    # Reward specific expected outcome
    if expected and len(expected) > 20:
        score = min(1.0, score * 1.05)

    # Blend with historical success rate
    hist = get_historical_success_rate(atype)
    score = (score * 0.6) + (hist * 0.4)

    return round(min(1.0, max(0.0, score)), 3)


def score_plan_confidence(actions: list[dict]) -> dict:
    """
    Score confidence for a full action plan.
    Returns {aggregate, per_action, low_confidence_count, needs_escalation}
    """
    if not actions:
        return {"aggregate": 1.0, "per_action": [], "low_confidence_count": 0, "needs_escalation": False}

    per_action = []
    for action in actions:
        conf = score_action_confidence(action)
        atype = action.get("type", "?")
        is_destructive = atype in DESTRUCTIVE_TYPES
        needs_escalation = (
            conf < HIGH_RISK_THRESHOLD or
            (is_destructive and conf < DESTRUCTIVE_THRESHOLD)
        )
        per_action.append({
            "type": atype,
            "description": action.get("description", "")[:60],
            "confidence": conf,
            "destructive": is_destructive,
            "escalate": needs_escalation,
        })

    aggregate = sum(a["confidence"] for a in per_action) / len(per_action)
    needs_escalation = any(a["escalate"] for a in per_action)
    low_count = sum(1 for a in per_action if a["escalate"])

    return {
        "aggregate": round(aggregate, 3),
        "per_action": per_action,
        "low_confidence_count": low_count,
        "needs_escalation": needs_escalation,
    }


def confidence_bar(score: float) -> str:
    """Visual confidence bar."""
    filled = int(score * 10)
    bar = "█" * filled + "░" * (10 - filled)
    icon = "🟢" if score >= 0.80 else "🟡" if score >= 0.60 else "🔴"
    return f"{icon} [{bar}] {int(score*100)}%"


def filter_safe_actions(actions: list[dict], auto_approve_threshold: float = HIGH_RISK_THRESHOLD) -> tuple[list, list]:
    """
    Split actions into (safe_to_execute, needs_approval).
    Returns two lists.
    """
    safe = []
    needs_approval = []
    for action in actions:
        conf = score_action_confidence(action)
        atype = action.get("type", "?")
        is_destructive = atype in DESTRUCTIVE_TYPES
        if conf >= auto_approve_threshold and not (is_destructive and conf < DESTRUCTIVE_THRESHOLD):
            safe.append(action)
        else:
            needs_approval.append({**action, "_confidence": conf})
    return safe, needs_approval


# ── TELEGRAM COMMANDS ─────────────────────────────────────────────────────────

class ConfidenceHandlers:

    @property
    def _confidence_mode(self) -> str:
        """Get current confidence gate mode: 'strict' | 'normal' | 'permissive'"""
        try:
            return self.config.get("SALIM_CONFIDENCE_MODE", "normal")
        except Exception:
            return "normal"

    async def cmd_confidence(self, update, ctx):
        """
        /confidence           — show calibration stats
        /confidence strict    — require approval for all medium+ risk actions
        /confidence normal    — default: only escalate high-risk low-confidence
        /confidence permissive— execute everything (trust AI fully)
        /confidence reset     — clear calibration history
        """
        from salim.auth import require_auth
        msg = update.effective_message
        args = ctx.args or []

        if args:
            sub = args[0].lower()
            if sub in ("strict", "normal", "permissive"):
                self.config.set("SALIM_CONFIDENCE_MODE", sub)
                await msg.reply_text(
                    f"✅ Confidence mode set to <b>{sub}</b>.\n"
                    f"{'⚠️ Will ask before most actions.' if sub == 'strict' else ''}"
                    f"{'🔓 AI executes all actions autonomously.' if sub == 'permissive' else ''}",
                    parse_mode="HTML",
                )
                return
            if sub == "reset":
                CALIBRATION_FILE.unlink(missing_ok=True)
                await msg.reply_text("🧹 Confidence calibration reset.", parse_mode="HTML")
                return

        cal = load_calibration()
        mode = self._confidence_mode
        lines = [
            f"🎯 <b>Confidence Engine</b>",
            f"Mode: <b>{mode}</b>\n",
            "<b>Calibration (historical success rates):</b>",
        ]
        if not cal:
            lines.append("<i>No data yet — executes actions to build calibration.</i>")
        else:
            for atype, data in sorted(cal.items()):
                total = data["successes"] + data["failures"]
                rate = data["successes"] / total if total else 0
                lines.append(f"  {confidence_bar(rate)} <code>{atype}</code> ({total} runs)")

        lines += [
            "",
            "<code>/confidence strict</code>   — human-in-the-loop",
            "<code>/confidence normal</code>    — smart gating (default)",
            "<code>/confidence permissive</code>— full autonomy",
        ]
        await msg.reply_text("\n".join(lines), parse_mode="HTML")
