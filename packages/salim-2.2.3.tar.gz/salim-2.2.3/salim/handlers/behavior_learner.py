"""
Salim Behavior Learner v18 — Pattern Learning & Prediction

Tracks command usage patterns and time-of-day behaviors,
then predicts and proactively executes likely next actions.

Commands:
  /learn status   — show learned patterns
  /learn reset    — clear all patterns
  /learn predict  — what Salim thinks you'll do next
"""
from __future__ import annotations

import json
import logging
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.behavior_learner")
esc = lambda v: __import__("html").escape(str(v), quote=False)
H = "HTML"

LEARN_DIR = Path.home() / ".salim" / "behavior"
LEARN_DIR.mkdir(parents=True, exist_ok=True)


def _learn_file(user_id: int) -> Path:
    return LEARN_DIR / f"{user_id}.json"


def load_patterns(user_id: int) -> dict:
    path = _learn_file(user_id)
    if not path.exists():
        return {
            "command_freq": {},          # {cmd: count}
            "time_patterns": {},         # {hour: {cmd: count}}
            "sequences": {},             # {cmd_a: {cmd_b: count}} (what follows what)
            "last_command": None,
            "total_interactions": 0,
        }
    try:
        return json.loads(path.read_text())
    except Exception:
        return {}


def save_patterns(user_id: int, patterns: dict):
    path = _learn_file(user_id)
    path.write_text(json.dumps(patterns, indent=2))
    path.chmod(0o600)


def record_command(user_id: int, command: str):
    """Record a command usage for pattern learning."""
    patterns = load_patterns(user_id)
    hour = datetime.now().hour

    # Frequency
    patterns.setdefault("command_freq", {})[command] = \
        patterns["command_freq"].get(command, 0) + 1

    # Time pattern
    patterns.setdefault("time_patterns", {}).setdefault(str(hour), {})[command] = \
        patterns["time_patterns"].get(str(hour), {}).get(command, 0) + 1

    # Sequence (what follows what)
    last = patterns.get("last_command")
    if last and last != command:
        patterns.setdefault("sequences", {}).setdefault(last, {})[command] = \
            patterns["sequences"].get(last, {}).get(command, 0) + 1

    patterns["last_command"] = command
    patterns["total_interactions"] = patterns.get("total_interactions", 0) + 1
    save_patterns(user_id, patterns)


def predict_next_commands(user_id: int, top_k: int = 3) -> list[str]:
    """Predict likely next commands based on current time + last command."""
    patterns = load_patterns(user_id)
    hour = str(datetime.now().hour)
    scores: dict[str, float] = {}

    # Time-based predictions
    time_cmds = patterns.get("time_patterns", {}).get(hour, {})
    total_time = sum(time_cmds.values()) or 1
    for cmd, count in time_cmds.items():
        scores[cmd] = scores.get(cmd, 0) + (count / total_time) * 0.6

    # Sequence-based predictions
    last = patterns.get("last_command")
    if last:
        seq_cmds = patterns.get("sequences", {}).get(last, {})
        total_seq = sum(seq_cmds.values()) or 1
        for cmd, count in seq_cmds.items():
            scores[cmd] = scores.get(cmd, 0) + (count / total_seq) * 0.4

    # Sort by score
    ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    return [cmd for cmd, _ in ranked[:top_k]]


def get_top_commands(user_id: int, n: int = 10) -> list[tuple[str, int]]:
    """Get top N most-used commands."""
    patterns = load_patterns(user_id)
    freq = patterns.get("command_freq", {})
    return sorted(freq.items(), key=lambda x: x[1], reverse=True)[:n]


class BehaviorLearnerHandlers:

    @require_auth
    async def cmd_learn(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /learn status   — show learned patterns and predictions
        /learn predict  — predict what you'll do next
        /learn reset    — clear all patterns
        """
        msg = update.effective_message
        user_id = update.effective_user.id
        args = ctx.args or []
        sub = args[0].lower() if args else "status"

        if sub == "reset":
            path = _learn_file(user_id)
            if path.exists():
                path.unlink()
            await msg.reply_text("🧹 Behavior patterns cleared.", parse_mode=H)
            return

        if sub == "predict":
            predictions = predict_next_commands(user_id)
            if not predictions:
                await msg.reply_text(
                    "🔮 Not enough data to predict yet.\n"
                    "<i>Use Salim more and predictions will improve.</i>",
                    parse_mode=H,
                )
                return
            lines = ["🔮 <b>Predicted Next Commands</b>\n"]
            for i, cmd in enumerate(predictions, 1):
                lines.append(f"  {i}. <code>/{cmd}</code>")
            await msg.reply_text("\n".join(lines), parse_mode=H)
            return

        # Status (default)
        patterns = load_patterns(user_id)
        total = patterns.get("total_interactions", 0)
        top_cmds = get_top_commands(user_id)
        predictions = predict_next_commands(user_id)

        if total == 0:
            await msg.reply_text(
                "🧠 <b>Behavior Learner</b>\n\n"
                "No patterns learned yet. Use Salim normally and I'll start building your profile.\n\n"
                "<i>/learn predict — once you have 20+ interactions</i>",
                parse_mode=H,
            )
            return

        hour = datetime.now().hour
        time_cmds = patterns.get("time_patterns", {}).get(str(hour), {})
        top_now = sorted(time_cmds.items(), key=lambda x: x[1], reverse=True)[:3]

        lines = [
            f"🧠 <b>Behavior Patterns</b>",
            f"Total interactions: <b>{total}</b>\n",
            "<b>Most used commands:</b>",
        ]
        for cmd, count in top_cmds[:7]:
            bar = "█" * min(10, count)
            lines.append(f"  <code>/{cmd}</code> {bar} ({count})")

        if top_now:
            lines.append(f"\n<b>Common at {hour:02d}:00:</b>")
            for cmd, count in top_now:
                lines.append(f"  <code>/{cmd}</code> ({count}x)")

        if predictions:
            lines.append("\n<b>Predicted next:</b>")
            for cmd in predictions:
                lines.append(f"  → <code>/{cmd}</code>")

        await msg.reply_text("\n".join(lines), parse_mode=H)
