"""
Salim Integrations Hub — OpenClaw-inspired skill integrations
=============================================================
Every integration auto-installs its own required libs on first use.
All libs are free and open-source.

Available integrations:
  PRODUCTIVITY
    calendar     — Google Calendar / iCal / CalDAV read/write
    notion       — Notion pages, databases, blocks
    obsidian     — Obsidian vault: notes, search, append
    todoist      — Todoist tasks (free API)
    trello       — Trello boards, cards, lists
    github       — GitHub issues, PRs, repos, notifications

  COMMUNICATION
    gmail        — Gmail via IMAP/SMTP (already in email_handler, extended here)
    matrix       — Matrix/Element chat bridge
    discord      — Discord webhooks / bot messages
    slack        — Slack webhooks / bot messages
    ntfy         — ntfy.sh push notifications (free, self-host option)
    gotify       — Gotify push notifications (self-hosted)
    apprise      — Universal notification library (100+ services)

  MEDIA & DATA
    spotify      — Spotify playback control (free tier, OAuth)
    yt_dlp       — YouTube / any-site download + info
    rss          — RSS/Atom feed reader and notifier
    weather      — OpenMeteo weather (free, no key needed)
    wikipedia    — Wikipedia article search and summary
    wolfram      — Wolfram Alpha simple API (free tier)
    hacker_news  — Hacker News top stories
    searx        — SearXNG / Searx metasearch (self-host or public)

  SYSTEM / INFRA
    docker       — Docker containers: list, start, stop, logs
    git          — Git operations: status, pull, push, log
    cron         — Cron-style task scheduler
    webhook      — Inbound webhooks → Telegram notifications
    healthcheck  — URL/port/process health monitor
    homeassistant— Home Assistant REST API control

  KNOWLEDGE
    sqlite       — Query any local SQLite database
    csv_query    — Query CSV files with SQL (duckdb)
    readwise     — Readwise highlights sync
    pocket       — Pocket read-later list

Commands:
  /integrations              — list all available integrations
  /integrations status       — show which are configured/active
  /integrations setup <name> — interactive setup for an integration
  /integrations test <name>  — test a configured integration
  /integrations disable <n>  — disable an integration

  Per-integration shortcuts:
  /weather [city]            — current weather (no setup needed)
  /hn [top|new|ask]          — Hacker News stories
  /wiki <query>              — Wikipedia summary
  /rss list|add|check        — RSS feeds
  /gh <command>              — GitHub operations
  /docker <command>          — Docker control
  /git <command>             — Git operations
  /cron list|add|del         — Cron jobs
  /webhook register|list     — Webhook endpoints
  /ha <command>              — Home Assistant
  /ntfy <message>            — Quick notification via ntfy
"""
from __future__ import annotations

import asyncio
import html
import json
import logging
import os
import re
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.auto_install import ensure_one

logger = logging.getLogger("salim.integrations")
H = "HTML"
esc = lambda v: html.escape(str(v), quote=False)

INTEGRATIONS_DIR  = Path.home() / ".salim" / "integrations"
INTEGRATIONS_DIR.mkdir(parents=True, exist_ok=True)

CONFIG_FILE = INTEGRATIONS_DIR / "config.json"
STATE_FILE  = INTEGRATIONS_DIR / "state.json"


# ══════════════════════════════════════════════════════════════════════════════
#  CONFIG HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _load_config() -> dict:
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text())
        except Exception:
            pass
    return {}

def _save_config(cfg: dict):
    CONFIG_FILE.write_text(json.dumps(cfg, indent=2))
    CONFIG_FILE.chmod(0o600)

def _get(name: str) -> dict:
    return _load_config().get(name, {})

def _set(name: str, data: dict):
    cfg = _load_config()
    cfg[name] = data
    _save_config(cfg)

def _load_state() -> dict:
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text())
        except Exception:
            pass
    return {}

def _save_state(state: dict):
    STATE_FILE.write_text(json.dumps(state, indent=2))


# ══════════════════════════════════════════════════════════════════════════════
#  INTEGRATION REGISTRY
# ══════════════════════════════════════════════════════════════════════════════

INTEGRATIONS = {
    # name: {desc, libs, needs_config, config_keys}
    "weather": {
        "desc": "Real-time weather via Open-Meteo (free, no API key)",
        "libs": [("httpx", "httpx>=0.25")],
        "needs_config": False,
    },
    "hn": {
        "desc": "Hacker News top/new/ask stories",
        "libs": [("httpx", "httpx>=0.25")],
        "needs_config": False,
    },
    "wiki": {
        "desc": "Wikipedia article search and summary",
        "libs": [("httpx", "httpx>=0.25")],
        "needs_config": False,
    },
    "rss": {
        "desc": "RSS/Atom feed reader — add any feed URL",
        "libs": [("feedparser", "feedparser>=6.0")],
        "needs_config": True,
        "config_keys": ["feeds"],  # list of URLs
    },
    "github": {
        "desc": "GitHub issues, PRs, notifications (free public API)",
        "libs": [("httpx", "httpx>=0.25")],
        "needs_config": True,
        "config_keys": ["token", "default_repo"],
    },
    "docker": {
        "desc": "Docker container management (uses local docker CLI)",
        "libs": [],
        "needs_config": False,
        "requires_binary": "docker",
    },
    "git": {
        "desc": "Git repo operations (uses local git CLI)",
        "libs": [],
        "needs_config": False,
        "requires_binary": "git",
    },
    "yt_dlp": {
        "desc": "Download video/audio from YouTube and 1000+ sites",
        "libs": [("yt_dlp", "yt-dlp")],
        "needs_config": False,
    },
    "ntfy": {
        "desc": "Push notifications via ntfy.sh (free, no account needed)",
        "libs": [("httpx", "httpx>=0.25")],
        "needs_config": True,
        "config_keys": ["topic", "server"],  # server defaults to ntfy.sh
    },
    "homeassistant": {
        "desc": "Home Assistant control via REST API",
        "libs": [("httpx", "httpx>=0.25")],
        "needs_config": True,
        "config_keys": ["url", "token"],
    },
    "notion": {
        "desc": "Notion pages, databases (free API)",
        "libs": [("httpx", "httpx>=0.25")],
        "needs_config": True,
        "config_keys": ["token", "default_database_id"],
    },
    "trello": {
        "desc": "Trello boards and cards (free API)",
        "libs": [("httpx", "httpx>=0.25")],
        "needs_config": True,
        "config_keys": ["api_key", "token"],
    },
    "todoist": {
        "desc": "Todoist task management (free tier)",
        "libs": [("httpx", "httpx>=0.25")],
        "needs_config": True,
        "config_keys": ["api_token"],
    },
    "sqlite": {
        "desc": "Query any local SQLite database file",
        "libs": [],  # sqlite3 is built-in
        "needs_config": True,
        "config_keys": ["default_db_path"],
    },
    "csv_query": {
        "desc": "SQL queries on CSV files using DuckDB",
        "libs": [("duckdb", "duckdb>=0.10")],
        "needs_config": False,
    },
    "healthcheck": {
        "desc": "Monitor URLs, ports, processes — alert on failure",
        "libs": [("httpx", "httpx>=0.25")],
        "needs_config": True,
        "config_keys": ["checks"],
    },
    "apprise": {
        "desc": "Send notifications to 100+ services (Slack, Discord, email…)",
        "libs": [("apprise", "apprise>=1.7")],
        "needs_config": True,
        "config_keys": ["urls"],
    },
    "obsidian": {
        "desc": "Obsidian vault notes — read, write, append, search",
        "libs": [],
        "needs_config": True,
        "config_keys": ["vault_path"],
    },
    "searx": {
        "desc": "Web search via SearXNG instance (privacy-focused)",
        "libs": [("httpx", "httpx>=0.25")],
        "needs_config": True,
        "config_keys": ["instance_url"],
    },
    "spotify": {
        "desc": "Spotify playback control (requires Spotify Connect device)",
        "libs": [("spotipy", "spotipy>=2.23")],
        "needs_config": True,
        "config_keys": ["client_id", "client_secret", "redirect_uri"],
    },
    "cron": {
        "desc": "Schedule recurring tasks (built-in, no extra deps)",
        "libs": [],
        "needs_config": False,
    },
    "webhook": {
        "desc": "Receive HTTP webhooks and forward to Telegram",
        "libs": [("aiohttp", "aiohttp>=3.9")],
        "needs_config": False,
    },
}


def _ensure_libs(name: str) -> tuple[bool, str]:
    """Install required libs for an integration. Returns (ok, error_msg)."""
    meta = INTEGRATIONS.get(name, {})
    for import_name, pip_name in meta.get("libs", []):
        if not ensure_one(import_name, pip_name):
            return False, f"Failed to install: {pip_name}"
    binary = meta.get("requires_binary")
    if binary and not shutil.which(binary):
        return False, f"System binary not found: {binary}. Install it first."
    return True, ""


# ══════════════════════════════════════════════════════════════════════════════
#  WEATHER — Open-Meteo (100% free, no API key)
# ══════════════════════════════════════════════════════════════════════════════

async def weather_get(city: str = "") -> str:
    import httpx
    # Geocode city → lat/lon using Open-Meteo geocoding API
    lat, lon, resolved = 51.5074, -0.1278, "London"
    if city:
        async with httpx.AsyncClient(timeout=10) as c:
            r = await c.get(
                "https://geocoding-api.open-meteo.com/v1/search",
                params={"name": city, "count": 1, "language": "en", "format": "json"}
            )
            data = r.json()
            if data.get("results"):
                res = data["results"][0]
                lat = res["latitude"]
                lon = res["longitude"]
                resolved = res.get("name", city)

    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.get(
            "https://api.open-meteo.com/v1/forecast",
            params={
                "latitude": lat, "longitude": lon,
                "current": "temperature_2m,apparent_temperature,weather_code,"
                           "wind_speed_10m,relative_humidity_2m,precipitation",
                "hourly": "temperature_2m,precipitation_probability",
                "forecast_days": 1,
                "timezone": "auto",
            }
        )
        d = r.json()

    cur = d.get("current", {})
    temp     = cur.get("temperature_2m", "?")
    feels    = cur.get("apparent_temperature", "?")
    wind     = cur.get("wind_speed_10m", "?")
    humidity = cur.get("relative_humidity_2m", "?")
    precip   = cur.get("precipitation", 0)
    code     = cur.get("weather_code", 0)

    WMO_ICONS = {
        0: "☀️ Clear", 1: "🌤 Mainly clear", 2: "⛅ Partly cloudy", 3: "☁️ Overcast",
        45: "🌫 Foggy", 48: "🌫 Icy fog",
        51: "🌦 Light drizzle", 53: "🌦 Moderate drizzle", 55: "🌧 Dense drizzle",
        61: "🌧 Light rain", 63: "🌧 Moderate rain", 65: "🌧 Heavy rain",
        71: "🌨 Light snow", 73: "🌨 Moderate snow", 75: "❄️ Heavy snow",
        80: "🌦 Rain showers", 81: "🌧 Heavy showers", 82: "⛈ Violent showers",
        95: "⛈ Thunderstorm", 96: "⛈ Thunderstorm + hail", 99: "⛈ Severe thunderstorm",
    }
    condition = WMO_ICONS.get(code, f"Code {code}")

    return (
        f"🌍 <b>{esc(resolved)}</b>\n"
        f"{condition}\n"
        f"🌡 <b>{temp}°C</b> feels like {feels}°C\n"
        f"💨 Wind {wind} km/h  💧 Humidity {humidity}%"
        + (f"\n🌧 Precipitation {precip} mm" if precip else "")
    )


# ══════════════════════════════════════════════════════════════════════════════
#  HACKER NEWS
# ══════════════════════════════════════════════════════════════════════════════

async def hn_get(feed: str = "top", n: int = 10) -> str:
    import httpx
    feed_map = {
        "top": "topstories", "new": "newstories",
        "best": "beststories", "ask": "askstories",
        "show": "showstories", "job": "jobstories",
    }
    endpoint = feed_map.get(feed.lower(), "topstories")
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.get(f"https://hacker-news.firebaseio.com/v0/{endpoint}.json")
        ids = r.json()[:n]
        items = []
        for i, story_id in enumerate(ids, 1):
            r2 = await c.get(f"https://hacker-news.firebaseio.com/v0/item/{story_id}.json")
            s  = r2.json()
            title = s.get("title", "?")
            pts   = s.get("score", 0)
            url   = s.get("url", f"https://news.ycombinator.com/item?id={story_id}")
            items.append(f'{i}. <a href="{esc(url)}">{esc(title)}</a> — {pts}pts')

    return f"🔥 <b>Hacker News {feed.upper()}</b>\n\n" + "\n".join(items)


# ══════════════════════════════════════════════════════════════════════════════
#  WIKIPEDIA
# ══════════════════════════════════════════════════════════════════════════════

async def wiki_search(query: str) -> str:
    import httpx
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.get(
            "https://en.wikipedia.org/api/rest_v1/page/summary/" +
            query.replace(" ", "_"),
            headers={"User-Agent": "Salim-Bot/1.0"}
        )
        if r.status_code == 200:
            d = r.json()
            title   = d.get("title", query)
            extract = d.get("extract", "No summary available.")[:800]
            url     = d.get("content_urls", {}).get("desktop", {}).get("page", "")
            return (f"📖 <b>{esc(title)}</b>\n\n{esc(extract)}"
                    + (f'\n\n<a href="{url}">Read more on Wikipedia</a>' if url else ""))
        else:
            # Try search
            r2 = await c.get(
                "https://en.wikipedia.org/w/api.php",
                params={"action": "search", "srsearch": query, "format": "json",
                        "srlimit": 5, "srprop": "snippet"},
                headers={"User-Agent": "Salim-Bot/1.0"}
            )
            results = r2.json().get("query", {}).get("search", [])
            if results:
                lines = [f"📖 <b>Wikipedia search: {esc(query)}</b>\n"]
                for res in results[:5]:
                    t = esc(res.get("title", "?"))
                    s = re.sub(r"<[^>]+>", "", res.get("snippet", ""))[:100]
                    lines.append(f"• <b>{t}</b> — {esc(s)}")
                return "\n".join(lines)
            return f"No Wikipedia article found for: {query}"


# ══════════════════════════════════════════════════════════════════════════════
#  RSS FEEDS
# ══════════════════════════════════════════════════════════════════════════════

async def rss_check(urls: list[str], limit: int = 5) -> str:
    ok, err = _ensure_libs("rss")
    if not ok:
        return f"❌ {err}"
    import feedparser
    lines = []
    for url in urls[:5]:
        try:
            feed = await asyncio.get_event_loop().run_in_executor(
                None, feedparser.parse, url)
            feed_title = feed.feed.get("title", url)[:40]
            lines.append(f"\n📰 <b>{esc(feed_title)}</b>")
            for entry in feed.entries[:limit]:
                title = entry.get("title", "?")[:80]
                link  = entry.get("link", "")
                lines.append(f'  • <a href="{esc(link)}">{esc(title)}</a>')
        except Exception as e:
            lines.append(f"  ❌ {esc(url[:50])}: {esc(str(e))}")
    return "\n".join(lines) if lines else "No feeds configured."


# ══════════════════════════════════════════════════════════════════════════════
#  GITHUB
# ══════════════════════════════════════════════════════════════════════════════

async def github_request(path: str, token: str = "", method: str = "GET",
                          data: dict = None) -> dict:
    import httpx
    headers = {"Accept": "application/vnd.github.v3+json",
               "User-Agent": "Salim-Bot/1.0"}
    if token:
        headers["Authorization"] = f"token {token}"
    url = f"https://api.github.com{path}"
    async with httpx.AsyncClient(timeout=15) as c:
        if method == "POST" and data:
            r = await c.post(url, json=data, headers=headers)
        else:
            r = await c.get(url, headers=headers)
    return r.json() if r.status_code < 400 else {"error": r.text[:200]}


async def github_notifications(token: str) -> str:
    data = await github_request("/notifications", token)
    if isinstance(data, list):
        if not data:
            return "✅ No unread GitHub notifications."
        lines = ["🔔 <b>GitHub Notifications</b>\n"]
        for n in data[:10]:
            repo    = n.get("repository", {}).get("full_name", "?")
            subject = n.get("subject", {})
            stype   = subject.get("type", "?")
            stitle  = subject.get("title", "?")[:60]
            lines.append(f"• [{stype}] <b>{esc(repo)}</b>: {esc(stitle)}")
        return "\n".join(lines)
    return f"GitHub error: {data.get('error', str(data))[:200]}"


async def github_issues(token: str, repo: str, state: str = "open") -> str:
    data = await github_request(f"/repos/{repo}/issues?state={state}&per_page=10", token)
    if isinstance(data, list):
        if not data:
            return f"No {state} issues in {repo}."
        lines = [f"📋 <b>{esc(repo)} Issues ({state})</b>\n"]
        for iss in data[:10]:
            n    = iss.get("number", "?")
            t    = iss.get("title", "?")[:70]
            url  = iss.get("html_url", "")
            lbls = ", ".join(l["name"] for l in iss.get("labels", []))
            lines.append(f'• <a href="{esc(url)}">#{n}</a> {esc(t)}' +
                         (f" [{esc(lbls)}]" if lbls else ""))
        return "\n".join(lines)
    return f"GitHub error: {str(data)[:200]}"


# ══════════════════════════════════════════════════════════════════════════════
#  DOCKER
# ══════════════════════════════════════════════════════════════════════════════

async def docker_run(cmd_args: list[str], timeout: int = 30) -> str:
    if not shutil.which("docker"):
        return "❌ Docker not installed. Install: https://docs.docker.com/get-docker/"
    proc = await asyncio.create_subprocess_exec(
        "docker", *cmd_args,
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
    )
    try:
        out, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        return out.decode("utf-8", errors="replace").strip()[:2000]
    except asyncio.TimeoutError:
        proc.kill()
        return "TIMEOUT"

async def docker_ps() -> str:
    out = await docker_run(["ps", "-a", "--format",
                             "table {{.Names}}\t{{.Status}}\t{{.Image}}\t{{.Ports}}"])
    return f"🐳 <b>Docker Containers</b>\n<pre>{esc(out)}</pre>"

async def docker_logs(container: str, lines: int = 30) -> str:
    out = await docker_run(["logs", "--tail", str(lines), container])
    return f"📋 <b>Docker Logs: {esc(container)}</b>\n<pre>{esc(out)}</pre>"

async def docker_action(action: str, container: str) -> str:
    if action not in ("start", "stop", "restart", "rm"):
        return f"Unknown action: {action}"
    out = await docker_run([action, container])
    return f"🐳 docker {action} {container}: {esc(out)}"


# ══════════════════════════════════════════════════════════════════════════════
#  GIT
# ══════════════════════════════════════════════════════════════════════════════

async def git_run(repo_path: str, args: list[str], timeout: int = 30) -> str:
    if not shutil.which("git"):
        return "❌ Git not installed."
    env = {**os.environ, "GIT_TERMINAL_PROMPT": "0"}
    proc = await asyncio.create_subprocess_exec(
        "git", "-C", repo_path, *args,
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
        env=env,
    )
    try:
        out, _ = await asyncio.wait_for(proc.communicate(), timeout=timeout)
        return out.decode("utf-8", errors="replace").strip()[:2000]
    except asyncio.TimeoutError:
        proc.kill()
        return "TIMEOUT"


# ══════════════════════════════════════════════════════════════════════════════
#  HOME ASSISTANT
# ══════════════════════════════════════════════════════════════════════════════

async def ha_request(path: str, token: str, base_url: str,
                     method: str = "GET", data: dict = None) -> Any:
    import httpx
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }
    url = base_url.rstrip("/") + path
    async with httpx.AsyncClient(timeout=10, verify=False) as c:
        if method == "POST" and data:
            r = await c.post(url, json=data, headers=headers)
        else:
            r = await c.get(url, headers=headers)
    return r.json() if r.headers.get("content-type", "").startswith("application/json") else r.text


async def ha_states(token: str, base_url: str) -> str:
    data = await ha_request("/api/states", token, base_url)
    if isinstance(data, list):
        # Group by domain
        domains: dict[str, list] = {}
        for entity in data:
            domain = entity.get("entity_id", "").split(".")[0]
            domains.setdefault(domain, []).append(entity)
        lines = ["🏠 <b>Home Assistant States</b>\n"]
        for domain, entities in sorted(domains.items())[:10]:
            lines.append(f"<b>{esc(domain)}</b>")
            for e in entities[:5]:
                eid = e.get("entity_id", "?")
                st  = e.get("state", "?")
                lines.append(f"  {esc(eid)}: {esc(st)}")
        return "\n".join(lines)
    return f"HA error: {str(data)[:200]}"

async def ha_service(token: str, base_url: str, domain: str, service: str,
                     entity_id: str = "", extra: dict = None) -> str:
    data = {"entity_id": entity_id} if entity_id else {}
    if extra:
        data.update(extra)
    result = await ha_request(f"/api/services/{domain}/{service}", token, base_url,
                               method="POST", data=data)
    return f"✅ HA {domain}.{service}: {esc(str(result)[:100])}"


# ══════════════════════════════════════════════════════════════════════════════
#  NTFY — Push notifications
# ══════════════════════════════════════════════════════════════════════════════

async def ntfy_send(topic: str, message: str, title: str = "Salim",
                    server: str = "https://ntfy.sh") -> str:
    import httpx
    url = f"{server.rstrip('/')}/{topic}"
    async with httpx.AsyncClient(timeout=10) as c:
        r = await c.post(url, content=message.encode(),
                         headers={"Title": title, "Priority": "default"})
    if r.status_code in (200, 201):
        return f"✅ Notification sent to {url}"
    return f"❌ ntfy failed: HTTP {r.status_code}"


# ══════════════════════════════════════════════════════════════════════════════
#  NOTION
# ══════════════════════════════════════════════════════════════════════════════

async def notion_request(path: str, token: str, method: str = "GET",
                          data: dict = None) -> Any:
    import httpx
    headers = {
        "Authorization": f"Bearer {token}",
        "Notion-Version": "2022-06-28",
        "Content-Type": "application/json",
    }
    url = f"https://api.notion.com/v1{path}"
    async with httpx.AsyncClient(timeout=15) as c:
        if method == "POST" and data:
            r = await c.post(url, json=data, headers=headers)
        elif method == "PATCH" and data:
            r = await c.patch(url, json=data, headers=headers)
        else:
            r = await c.get(url, headers=headers)
    return r.json()


async def notion_search(token: str, query: str = "") -> str:
    data = await notion_request("/search", token, "POST",
                                 {"query": query, "page_size": 10})
    results = data.get("results", [])
    if not results:
        return "No Notion pages found."
    lines = [f"📓 <b>Notion Search: {esc(query or 'recent')}</b>\n"]
    for r in results:
        obj_type = r.get("object", "?")
        title    = ""
        if obj_type == "page":
            props = r.get("properties", {})
            for key in ("Name", "Title", "title"):
                prop = props.get(key, {})
                if prop.get("type") == "title":
                    title = "".join(t.get("plain_text", "")
                                    for t in prop.get("title", []))
                    break
        elif obj_type == "database":
            t = r.get("title", [])
            title = "".join(x.get("plain_text", "") for x in t)
        lines.append(f"• [{obj_type}] {esc(title or '(untitled)')}")
    return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════════════
#  TODOIST
# ══════════════════════════════════════════════════════════════════════════════

async def todoist_tasks(token: str, project_id: str = "") -> str:
    import httpx
    params = {}
    if project_id:
        params["project_id"] = project_id
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.get("https://api.todoist.com/rest/v2/tasks",
                        params=params,
                        headers={"Authorization": f"Bearer {token}"})
    tasks = r.json() if r.status_code == 200 else []
    if not tasks:
        return "✅ No tasks or Todoist not configured."
    lines = [f"✅ <b>Todoist Tasks ({len(tasks)})</b>\n"]
    for t in tasks[:15]:
        content  = t.get("content", "?")[:80]
        priority = "🔴" if t.get("priority", 1) == 4 else \
                   "🟠" if t.get("priority") == 3 else \
                   "🟡" if t.get("priority") == 2 else "🟢"
        due = t.get("due", {})
        due_str = f" 📅 {due.get('date','')}" if due else ""
        lines.append(f"{priority} {esc(content)}{due_str}")
    return "\n".join(lines)


async def todoist_add(token: str, content: str, due: str = "") -> str:
    import httpx
    payload = {"content": content}
    if due:
        payload["due_string"] = due
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.post("https://api.todoist.com/rest/v2/tasks",
                         json=payload,
                         headers={"Authorization": f"Bearer {token}"})
    if r.status_code == 200:
        return f"✅ Task added: {content}"
    return f"❌ Todoist error: {r.text[:100]}"


# ══════════════════════════════════════════════════════════════════════════════
#  TRELLO
# ══════════════════════════════════════════════════════════════════════════════

async def trello_boards(api_key: str, token: str) -> str:
    import httpx
    async with httpx.AsyncClient(timeout=15) as c:
        r = await c.get(
            "https://api.trello.com/1/members/me/boards",
            params={"key": api_key, "token": token, "fields": "name,url"}
        )
    boards = r.json() if r.status_code == 200 else []
    if not boards:
        return "No Trello boards found."
    lines = ["📋 <b>Trello Boards</b>\n"]
    for b in boards:
        name = b.get("name", "?")
        url  = b.get("url", "")
        lines.append(f'• <a href="{esc(url)}">{esc(name)}</a>')
    return "\n".join(lines)


# ══════════════════════════════════════════════════════════════════════════════
#  SQLITE
# ══════════════════════════════════════════════════════════════════════════════

def sqlite_query(db_path: str, sql: str) -> str:
    import sqlite3
    p = Path(db_path).expanduser()
    if not p.exists():
        return f"Database not found: {p}"
    try:
        conn = sqlite3.connect(str(p))
        cur  = conn.execute(sql)
        rows = cur.fetchmany(50)
        cols = [d[0] for d in cur.description] if cur.description else []
        conn.close()
        if not rows:
            return "Query returned no rows."
        header = " | ".join(cols)
        body   = "\n".join(" | ".join(str(c)[:30] for c in row) for row in rows)
        return f"<pre>{esc(header)}\n{'-'*len(header)}\n{esc(body)}</pre>"
    except Exception as e:
        return f"SQL error: {e}"


# ══════════════════════════════════════════════════════════════════════════════
#  CSV QUERY — DuckDB
# ══════════════════════════════════════════════════════════════════════════════

def csv_query(csv_path: str, sql: str) -> str:
    ok, err = _ensure_libs("csv_query")
    if not ok:
        return f"❌ {err}"
    import duckdb
    p = Path(csv_path).expanduser()
    if not p.exists():
        return f"File not found: {p}"
    try:
        con = duckdb.connect()
        rel = con.execute(f"SELECT * FROM read_csv_auto('{p}') LIMIT 0")
        result = con.execute(sql.replace("FROM csv", f"FROM read_csv_auto('{p}')"))
        rows = result.fetchmany(50)
        cols = [d[0] for d in result.description] if result.description else []
        if not rows:
            return "Query returned no rows."
        header = " | ".join(cols)
        body   = "\n".join(" | ".join(str(c)[:25] for c in row) for row in rows)
        return f"<pre>{esc(header)}\n{esc(body)}</pre>"
    except Exception as e:
        return f"DuckDB error: {e}"


# ══════════════════════════════════════════════════════════════════════════════
#  OBSIDIAN VAULT
# ══════════════════════════════════════════════════════════════════════════════

def obsidian_search(vault_path: str, query: str) -> str:
    vault = Path(vault_path).expanduser()
    if not vault.exists():
        return f"Vault not found: {vault}"
    results = []
    query_lower = query.lower()
    for f in vault.rglob("*.md"):
        try:
            content = f.read_text(errors="replace")
            if query_lower in content.lower() or query_lower in f.stem.lower():
                snippet = content[:200].replace("\n", " ")
                results.append(f"📄 <b>{esc(f.stem)}</b>\n   {esc(snippet[:120])}")
        except Exception:
            pass
        if len(results) >= 10:
            break
    if not results:
        return f"No Obsidian notes matching '{query}'."
    return f"🔍 <b>Obsidian: {esc(query)}</b>\n\n" + "\n\n".join(results)


def obsidian_append(vault_path: str, note_name: str, text: str) -> str:
    vault = Path(vault_path).expanduser()
    note  = vault / f"{note_name}.md"
    note.parent.mkdir(parents=True, exist_ok=True)
    with open(note, "a") as f:
        f.write(f"\n{text}\n")
    return f"✅ Appended to {note.name}"


def obsidian_create(vault_path: str, note_name: str, content: str) -> str:
    vault = Path(vault_path).expanduser()
    note  = vault / f"{note_name}.md"
    note.parent.mkdir(parents=True, exist_ok=True)
    note.write_text(content)
    return f"✅ Created note: {note.name}"


# ══════════════════════════════════════════════════════════════════════════════
#  APPRISE — Universal notifications
# ══════════════════════════════════════════════════════════════════════════════

async def apprise_notify(urls: list[str], title: str, body: str) -> str:
    ok, err = _ensure_libs("apprise")
    if not ok:
        return f"❌ {err}"
    import apprise
    a = apprise.Apprise()
    for url in urls:
        a.add(url)
    success = await a.async_notify(title=title, body=body)
    return "✅ Notification sent." if success else "❌ Apprise notification failed."


# ══════════════════════════════════════════════════════════════════════════════
#  SEARX — Privacy search
# ══════════════════════════════════════════════════════════════════════════════

async def searx_search(instance_url: str, query: str, n: int = 5) -> str:
    import httpx
    url = instance_url.rstrip("/") + "/search"
    try:
        async with httpx.AsyncClient(timeout=15, verify=False) as c:
            r = await c.get(url, params={"q": query, "format": "json"})
        results = r.json().get("results", [])[:n]
        if not results:
            return f"No results from SearXNG for: {query}"
        lines = [f"🔍 <b>Search: {esc(query)}</b>\n"]
        for res in results:
            t = res.get("title", "?")[:80]
            u = res.get("url", "")
            s = re.sub(r"<[^>]+>", "", res.get("content", ""))[:150]
            lines.append(f'• <a href="{esc(u)}">{esc(t)}</a>\n  {esc(s)}')
        return "\n\n".join(lines)
    except Exception as e:
        return f"SearXNG search failed: {e}"


# ══════════════════════════════════════════════════════════════════════════════
#  YT-DLP
# ══════════════════════════════════════════════════════════════════════════════

async def ytdlp_info(url: str) -> str:
    ok, err = _ensure_libs("yt_dlp")
    if not ok:
        return f"❌ {err}"
    import yt_dlp
    opts = {"quiet": True, "no_warnings": True, "skip_download": True}
    try:
        loop = asyncio.get_event_loop()
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = await loop.run_in_executor(None, ydl.extract_info, url)
        title     = info.get("title", "?")
        duration  = info.get("duration", 0)
        uploader  = info.get("uploader", "?")
        views     = info.get("view_count", 0)
        dur_str   = f"{duration//60}:{duration%60:02d}" if duration else "?"
        return (f"🎬 <b>{esc(title)}</b>\n"
                f"👤 {esc(uploader)}  ⏱ {dur_str}  👁 {views:,}")
    except Exception as e:
        return f"yt-dlp info failed: {e}"


async def ytdlp_download(url: str, download_dir: str = "", audio_only: bool = False) -> str:
    ok, err = _ensure_libs("yt_dlp")
    if not ok:
        return f"❌ {err}"
    import yt_dlp
    dest = Path(download_dir).expanduser() if download_dir else Path.home() / "Downloads"
    dest.mkdir(parents=True, exist_ok=True)
    opts = {
        "quiet": True, "no_warnings": True,
        "outtmpl": str(dest / "%(title)s.%(ext)s"),
    }
    if audio_only:
        opts["format"] = "bestaudio/best"
        opts["postprocessors"] = [{"key": "FFmpegExtractAudio", "preferredcodec": "mp3"}]
    try:
        loop = asyncio.get_event_loop()
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = await loop.run_in_executor(None, ydl.extract_info, url)
        title = info.get("title", "?")
        return f"✅ Downloaded: {esc(title)}\n📁 Saved to {dest}"
    except Exception as e:
        return f"yt-dlp download failed: {e}"


# ══════════════════════════════════════════════════════════════════════════════
#  HEALTHCHECK — Monitor URLs / ports / processes
# ══════════════════════════════════════════════════════════════════════════════

async def healthcheck_run(checks: list[dict]) -> str:
    import httpx
    results = []
    for check in checks:
        ctype = check.get("type", "url")
        name  = check.get("name", "?")
        if ctype == "url":
            url = check.get("url", "")
            try:
                async with httpx.AsyncClient(timeout=5, verify=False) as c:
                    r = await c.get(url)
                icon = "✅" if r.status_code < 400 else "⚠️"
                results.append(f"{icon} {esc(name)}: HTTP {r.status_code}")
            except Exception as e:
                results.append(f"❌ {esc(name)}: {esc(str(e)[:60])}")
        elif ctype == "port":
            import socket
            host = check.get("host", "localhost")
            port = int(check.get("port", 80))
            try:
                s = socket.create_connection((host, port), timeout=3)
                s.close()
                results.append(f"✅ {esc(name)}: {host}:{port} open")
            except Exception:
                results.append(f"❌ {esc(name)}: {host}:{port} closed")
        elif ctype == "process":
            proc_name = check.get("process", "")
            found = any(True for _ in __import__("psutil").process_iter(["name"])
                        if proc_name.lower() in _.info.get("name", "").lower())
            icon = "✅" if found else "❌"
            results.append(f"{icon} {esc(name)}: process '{proc_name}' "
                           f"{'running' if found else 'NOT running'}")

    return "🏥 <b>Health Check</b>\n" + "\n".join(results)


# ══════════════════════════════════════════════════════════════════════════════
#  TELEGRAM COMMAND HANDLERS
# ══════════════════════════════════════════════════════════════════════════════

class IntegrationHandlers:

    @require_auth
    async def cmd_integrations(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        msg  = update.effective_message
        args = ctx.args or []
        sub  = args[0].lower() if args else "list"

        if sub == "list":
            cfg = _load_config()
            lines = ["🔌 <b>Salim Integrations</b>\n"]
            categories = {
                "🆓 Free / No Setup": ["weather", "hn", "wiki", "yt_dlp", "docker", "git"],
                "🔑 Needs Config": ["rss", "github", "ntfy", "homeassistant", "notion",
                                    "trello", "todoist", "sqlite", "csv_query",
                                    "healthcheck", "apprise", "obsidian", "searx", "spotify"],
            }
            for cat, names in categories.items():
                lines.append(f"\n<b>{cat}</b>")
                for name in names:
                    meta      = INTEGRATIONS.get(name, {})
                    desc      = meta.get("desc", "")[:55]
                    configured = "✅" if cfg.get(name) else "○"
                    lines.append(f"  {configured} <code>/int_{name}</code> — {esc(desc)}")
            lines.append("\n<i>Use /integrations setup &lt;name&gt; to configure</i>")
            await msg.reply_text("\n".join(lines), parse_mode=H)

        elif sub == "status":
            cfg = _load_config()
            active = [k for k, v in cfg.items() if v]
            if not active:
                await msg.reply_text("No integrations configured yet.")
            else:
                lines = ["✅ <b>Configured Integrations</b>\n"]
                for name in active:
                    meta = INTEGRATIONS.get(name, {})
                    lines.append(f"• {name} — {esc(meta.get('desc','')[:60])}")
                await msg.reply_text("\n".join(lines), parse_mode=H)

        elif sub == "setup" and len(args) > 1:
            name = args[1].lower()
            if name not in INTEGRATIONS:
                await msg.reply_text(f"Unknown integration: {name}")
                return
            meta = INTEGRATIONS[name]
            keys = meta.get("config_keys", [])
            if not keys:
                await msg.reply_text(
                    f"✅ {name} needs no configuration — it works out of the box!\n"
                    f"Use: /int_{name}", parse_mode=H)
                return
            await msg.reply_text(
                f"⚙️ <b>Setup: {name}</b>\n\n"
                f"{esc(meta.get('desc',''))}\n\n"
                f"<b>Required config keys:</b>\n"
                + "\n".join(f"  • <code>{k}</code>" for k in keys) +
                f"\n\nSet each value with:\n"
                f"<code>/integrations set {name} {keys[0]} YOUR_VALUE</code>",
                parse_mode=H,
            )

        elif sub == "set" and len(args) >= 4:
            name  = args[1].lower()
            key   = args[2]
            value = " ".join(args[3:])
            cfg   = _load_config()
            cfg.setdefault(name, {})[key] = value
            _save_config(cfg)
            await msg.reply_text(
                f"✅ <b>{name}</b>.<code>{key}</code> saved.", parse_mode=H)

        elif sub == "test" and len(args) > 1:
            name = args[1].lower()
            await msg.reply_text(f"🧪 Testing {name}…")
            result = await _test_integration(name)
            await msg.reply_text(result, parse_mode=H)

        elif sub == "disable" and len(args) > 1:
            name = args[1].lower()
            cfg  = _load_config()
            cfg.pop(name, None)
            _save_config(cfg)
            await msg.reply_text(f"🔌 Integration {name} disabled and config removed.")

        else:
            await msg.reply_text(
                "🔌 <b>Integrations</b>\n\n"
                "<code>/integrations</code>              — list all\n"
                "<code>/integrations status</code>       — configured ones\n"
                "<code>/integrations setup &lt;name&gt;</code> — setup guide\n"
                "<code>/integrations set &lt;n&gt; &lt;key&gt; &lt;val&gt;</code> — save config\n"
                "<code>/integrations test &lt;name&gt;</code>  — test it\n"
                "<code>/integrations disable &lt;name&gt;</code> — remove\n\n"
                "<i>Quick access: /weather, /hn, /wiki, /gh, /docker, /git, /ntfy</i>",
                parse_mode=H,
            )

    async def _test_integration_cmd(self, update, ctx):
        pass  # done via /integrations test

    @require_auth
    async def cmd_weather(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        city = " ".join(ctx.args) if ctx.args else ""
        ok, err = _ensure_libs("weather")
        if not ok:
            await update.effective_message.reply_text(f"❌ {err}")
            return
        msg = await update.effective_message.reply_text("🌍 Fetching weather…")
        try:
            result = await weather_get(city)
            await msg.edit_text(result, parse_mode=H)
        except Exception as e:
            await msg.edit_text(f"❌ Weather failed: {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_hn(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        feed = ctx.args[0] if ctx.args else "top"
        n    = int(ctx.args[1]) if len(ctx.args) > 1 and ctx.args[1].isdigit() else 10
        msg  = await update.effective_message.reply_text("📰 Fetching HN…")
        try:
            result = await hn_get(feed, n)
            await msg.edit_text(result, parse_mode=H, disable_web_page_preview=True)
        except Exception as e:
            await msg.edit_text(f"❌ HN failed: {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_wiki(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: /wiki <query>")
            return
        query = " ".join(ctx.args)
        msg   = await update.effective_message.reply_text(f"📖 Searching Wikipedia: {esc(query)}…",
                                                           parse_mode=H)
        try:
            result = await wiki_search(query)
            await msg.edit_text(result, parse_mode=H, disable_web_page_preview=True)
        except Exception as e:
            await msg.edit_text(f"❌ Wiki failed: {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_hn_cmd(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await self.cmd_hn(update, ctx)

    @require_auth
    async def cmd_gh(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        args = ctx.args or []
        cfg  = _get("github")
        token = cfg.get("token", "")
        repo  = cfg.get("default_repo", "")
        sub   = args[0].lower() if args else "notifications"

        msg = await update.effective_message.reply_text("🐙 GitHub…")
        try:
            if sub == "notifications":
                result = await github_notifications(token)
            elif sub == "issues" and (len(args) > 1 or repo):
                r = args[1] if len(args) > 1 else repo
                result = await github_issues(token, r)
            elif sub == "prs" and (len(args) > 1 or repo):
                r = args[1] if len(args) > 1 else repo
                data = await github_request(
                    f"/repos/{r}/pulls?state=open&per_page=10", token)
                if isinstance(data, list):
                    lines = [f"🔀 <b>{esc(r)} PRs</b>\n"]
                    for pr in data[:10]:
                        n = pr.get("number", "?")
                        t = pr.get("title", "?")[:70]
                        u = pr.get("html_url", "")
                        lines.append(f'• <a href="{esc(u)}">#{n}</a> {esc(t)}')
                    result = "\n".join(lines) if len(lines) > 1 else "No open PRs."
                else:
                    result = f"GitHub error: {str(data)[:100]}"
            else:
                result = ("🐙 <b>GitHub commands:</b>\n"
                          "<code>/gh notifications</code>\n"
                          "<code>/gh issues [owner/repo]</code>\n"
                          "<code>/gh prs [owner/repo]</code>")
            await msg.edit_text(result, parse_mode=H, disable_web_page_preview=True)
        except Exception as e:
            await msg.edit_text(f"❌ GitHub failed: {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_docker(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        args = ctx.args or []
        sub  = args[0].lower() if args else "ps"
        msg  = await update.effective_message.reply_text("🐳 Docker…")
        try:
            if sub == "ps":
                result = await docker_ps()
            elif sub in ("start", "stop", "restart", "rm") and len(args) > 1:
                result = await docker_action(sub, args[1])
            elif sub == "logs" and len(args) > 1:
                n = int(args[2]) if len(args) > 2 and args[2].isdigit() else 30
                result = await docker_logs(args[1], n)
            elif sub == "images":
                out = await docker_run(["images", "--format",
                                         "table {{.Repository}}\t{{.Tag}}\t{{.Size}}"])
                result = f"🐳 <b>Docker Images</b>\n<pre>{esc(out)}</pre>"
            else:
                result = ("🐳 <b>Docker:</b>\n"
                          "<code>/docker ps</code>\n"
                          "<code>/docker start|stop|restart &lt;container&gt;</code>\n"
                          "<code>/docker logs &lt;container&gt; [n]</code>\n"
                          "<code>/docker images</code>")
            await msg.edit_text(result, parse_mode=H)
        except Exception as e:
            await msg.edit_text(f"❌ Docker: {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_git(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        args = ctx.args or []
        sub  = args[0].lower() if args else "status"
        # Determine repo path
        cfg       = _get("git")
        repo_path = cfg.get("repo_path", str(Path.home()))
        if "--repo" in args:
            idx = args.index("--repo")
            if idx + 1 < len(args):
                repo_path = args[idx + 1]
                args = [a for i, a in enumerate(args) if i != idx and i != idx + 1]

        msg = await update.effective_message.reply_text("⚡ Git…")
        try:
            if sub == "status":
                out = await git_run(repo_path, ["status", "-sb"])
                result = f"📊 <b>Git Status</b>\n<pre>{esc(out)}</pre>"
            elif sub == "log":
                n   = int(args[1]) if len(args) > 1 and args[1].isdigit() else 10
                out = await git_run(repo_path,
                                    ["log", f"--oneline", f"-{n}",
                                     "--pretty=format:%h %s (%an, %ar)"])
                result = f"📜 <b>Git Log</b>\n<pre>{esc(out)}</pre>"
            elif sub == "pull":
                out    = await git_run(repo_path, ["pull"], timeout=60)
                result = f"⬇️ <b>Git Pull</b>\n<pre>{esc(out)}</pre>"
            elif sub == "push":
                out    = await git_run(repo_path, ["push"], timeout=60)
                result = f"⬆️ <b>Git Push</b>\n<pre>{esc(out)}</pre>"
            elif sub == "diff":
                out    = await git_run(repo_path, ["diff", "--stat"])
                result = f"🔍 <b>Git Diff</b>\n<pre>{esc(out[:1500])}</pre>"
            elif sub == "branches":
                out    = await git_run(repo_path, ["branch", "-a"])
                result = f"🌿 <b>Git Branches</b>\n<pre>{esc(out)}</pre>"
            else:
                result = ("⚡ <b>Git:</b>\n"
                          "<code>/git status</code>\n"
                          "<code>/git log [n]</code>\n"
                          "<code>/git pull</code>\n"
                          "<code>/git push</code>\n"
                          "<code>/git diff</code>\n"
                          "<code>/git branches</code>\n"
                          "<code>/git --repo /path/to/repo status</code>")
            await msg.edit_text(result, parse_mode=H)
        except Exception as e:
            await msg.edit_text(f"❌ Git: {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_ntfy(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: /ntfy <message>\nSetup: /integrations setup ntfy")
            return
        cfg     = _get("ntfy")
        topic   = cfg.get("topic", "salim-" + str(update.effective_user.id)[:8])
        server  = cfg.get("server", "https://ntfy.sh")
        message = " ".join(ctx.args)
        msg     = await update.effective_message.reply_text("📣 Sending…")
        result  = await ntfy_send(topic, message, server=server)
        await msg.edit_text(result, parse_mode=H)

    @require_auth
    async def cmd_ha(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        args = ctx.args or []
        cfg  = _get("homeassistant")
        if not cfg.get("url") or not cfg.get("token"):
            await update.effective_message.reply_text(
                "Home Assistant not configured.\n/integrations setup homeassistant")
            return
        sub = args[0].lower() if args else "states"
        msg = await update.effective_message.reply_text("🏠 Home Assistant…")
        try:
            if sub == "states":
                result = await ha_states(cfg["token"], cfg["url"])
            elif sub in ("turn_on", "turn_off", "toggle") and len(args) > 1:
                entity_id = args[1]
                domain    = entity_id.split(".")[0]
                result    = await ha_service(cfg["token"], cfg["url"],
                                             domain, sub, entity_id)
            else:
                result = ("🏠 <b>Home Assistant:</b>\n"
                          "<code>/ha states</code>\n"
                          "<code>/ha turn_on &lt;entity_id&gt;</code>\n"
                          "<code>/ha turn_off &lt;entity_id&gt;</code>\n"
                          "<code>/ha toggle &lt;entity_id&gt;</code>")
            await msg.edit_text(result, parse_mode=H)
        except Exception as e:
            await msg.edit_text(f"❌ HA: {esc(str(e))}", parse_mode=H)

    @require_auth
    async def cmd_rss(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        args = ctx.args or []
        sub  = args[0].lower() if args else "check"
        cfg  = _get("rss")
        feeds = cfg.get("feeds", []) if isinstance(cfg.get("feeds"), list) else []

        if sub == "add" and len(args) > 1:
            url = args[1]
            feeds.append(url)
            _set("rss", {"feeds": feeds})
            await update.effective_message.reply_text(f"✅ RSS feed added: {esc(url)}", parse_mode=H)
        elif sub == "list":
            if not feeds:
                await update.effective_message.reply_text("No RSS feeds added yet. /rss add <url>")
            else:
                lines = ["📰 <b>RSS Feeds:</b>\n"]
                for i, f in enumerate(feeds, 1):
                    lines.append(f"  {i}. {esc(f)}")
                await update.effective_message.reply_text("\n".join(lines), parse_mode=H)
        elif sub == "del" and len(args) > 1:
            try:
                idx = int(args[1]) - 1
                removed = feeds.pop(idx)
                _set("rss", {"feeds": feeds})
                await update.effective_message.reply_text(f"🗑 Removed: {esc(removed)}", parse_mode=H)
            except (ValueError, IndexError):
                await update.effective_message.reply_text("Invalid feed number.")
        else:  # check
            if not feeds:
                await update.effective_message.reply_text(
                    "No feeds yet. Add with: /rss add <url>")
                return
            msg    = await update.effective_message.reply_text("📰 Checking RSS feeds…")
            result = await rss_check(feeds)
            await msg.edit_text(result, parse_mode=H, disable_web_page_preview=True)

    @require_auth
    async def cmd_notion(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        cfg = _get("notion")
        if not cfg.get("token"):
            await update.effective_message.reply_text(
                "Notion not configured.\n/integrations setup notion")
            return
        query = " ".join(ctx.args) if ctx.args else ""
        msg   = await update.effective_message.reply_text("📓 Notion…")
        result = await notion_search(cfg["token"], query)
        await msg.edit_text(result, parse_mode=H)

    @require_auth
    async def cmd_todoist(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        args = ctx.args or []
        cfg  = _get("todoist")
        if not cfg.get("api_token"):
            await update.effective_message.reply_text(
                "Todoist not configured.\n/integrations setup todoist")
            return
        sub = args[0].lower() if args else "list"
        if sub == "list":
            msg    = await update.effective_message.reply_text("✅ Fetching tasks…")
            result = await todoist_tasks(cfg["api_token"])
            await msg.edit_text(result, parse_mode=H)
        elif sub == "add" and len(args) > 1:
            content = " ".join(args[1:])
            msg     = await update.effective_message.reply_text("✅ Adding task…")
            result  = await todoist_add(cfg["api_token"], content)
            await msg.edit_text(result, parse_mode=H)
        else:
            await update.effective_message.reply_text(
                "Usage: /todoist list | /todoist add <task>")

    @require_auth
    async def cmd_obsidian(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        args = ctx.args or []
        cfg  = _get("obsidian")
        vault = cfg.get("vault_path", "")
        if not vault:
            await update.effective_message.reply_text(
                "Obsidian vault not configured.\n/integrations setup obsidian")
            return
        sub = args[0].lower() if args else "search"
        if sub == "search" and len(args) > 1:
            query  = " ".join(args[1:])
            result = obsidian_search(vault, query)
            await update.effective_message.reply_text(result, parse_mode=H)
        elif sub == "append" and len(args) > 2:
            note_name = args[1]
            text      = " ".join(args[2:])
            result    = obsidian_append(vault, note_name, text)
            await update.effective_message.reply_text(result, parse_mode=H)
        elif sub == "new" and len(args) > 2:
            note_name = args[1]
            content   = " ".join(args[2:])
            result    = obsidian_create(vault, note_name, content)
            await update.effective_message.reply_text(result, parse_mode=H)
        else:
            await update.effective_message.reply_text(
                "Usage:\n/obsidian search <query>\n/obsidian append <note> <text>\n"
                "/obsidian new <name> <content>")

    @require_auth
    async def cmd_search(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text("Usage: /search <query>")
            return
        cfg   = _get("searx")
        query = " ".join(ctx.args)
        if not cfg.get("instance_url"):
            # Fall back to Wikipedia + HN
            msg    = await update.effective_message.reply_text("🔍 Searching…")
            result = await wiki_search(query)
            await msg.edit_text(result, parse_mode=H, disable_web_page_preview=True)
        else:
            msg    = await update.effective_message.reply_text("🔍 Searching…")
            result = await searx_search(cfg["instance_url"], query)
            await msg.edit_text(result, parse_mode=H, disable_web_page_preview=True)

    @require_auth
    async def cmd_ytdl(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        args = ctx.args or []
        if not args:
            await update.effective_message.reply_text(
                "Usage:\n/ytdl <url>          — show info\n"
                "/ytdl get <url>      — download video\n"
                "/ytdl audio <url>    — download audio only")
            return
        sub = args[0].lower()
        if sub in ("get", "audio") and len(args) > 1:
            url       = args[1]
            audio     = sub == "audio"
            cfg       = _get("yt_dlp")
            dest      = cfg.get("download_dir", "")
            msg       = await update.effective_message.reply_text("⬇️ Downloading…")
            result    = await ytdlp_download(url, dest, audio)
            await msg.edit_text(result, parse_mode=H)
        else:
            url    = args[0]
            msg    = await update.effective_message.reply_text("🎬 Fetching info…")
            result = await ytdlp_info(url)
            await msg.edit_text(result, parse_mode=H)

    @require_auth
    async def cmd_sqlite(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if not ctx.args:
            await update.effective_message.reply_text(
                "Usage: /sqlite <sql_query>\nSet default DB: /integrations set sqlite default_db_path /path/to/db")
            return
        cfg     = _get("sqlite")
        db_path = cfg.get("default_db_path", "")
        if not db_path:
            await update.effective_message.reply_text(
                "No default database set.\n/integrations set sqlite default_db_path /path/to/file.db")
            return
        sql    = " ".join(ctx.args)
        result = sqlite_query(db_path, sql)
        await update.effective_message.reply_text(result, parse_mode=H)

    @require_auth
    async def cmd_healthcheck(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        cfg    = _get("healthcheck")
        checks = cfg.get("checks", [])
        if not checks:
            await update.effective_message.reply_text(
                "No health checks configured.\n"
                "Example: /integrations set healthcheck checks "
                '[{"type":"url","name":"My Site","url":"https://example.com"}]')
            return
        msg    = await update.effective_message.reply_text("🏥 Running checks…")
        result = await healthcheck_run(checks)
        await msg.edit_text(result, parse_mode=H)


async def _test_integration(name: str) -> str:
    """Quick functional test of an integration."""
    try:
        if name == "weather":
            return await weather_get("London")
        elif name == "hn":
            return await hn_get("top", 3)
        elif name == "wiki":
            return await wiki_search("Python programming language")
        elif name == "docker":
            return await docker_ps()
        elif name == "git":
            out = await git_run(str(Path.home()), ["version"])
            return f"✅ git: {out}"
        else:
            return f"No test defined for {name}. Use the integration commands directly."
    except Exception as e:
        return f"❌ Test failed: {e}"
