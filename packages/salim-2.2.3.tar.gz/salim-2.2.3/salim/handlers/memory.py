"""
Salim Persistent Memory — User Profile & Habit Learning

Stores and retrieves a persistent user profile that survives restarts.
Learns: name, timezone, working hours, language, preferences, frequently used
commands, file paths, recurring patterns, etc.

The profile is injected as context into every AI call so Salim personalizes
responses and remembers things you've told it across sessions.

Storage: ~/.salim/memory/<user_id>.json  (human-readable JSON)

Commands:
  /memory              — show your current profile
  /memory set <k> <v>  — manually set a preference
  /memory forget <key> — delete a specific memory
  /memory clear        — wipe entire profile
  /memory learn        — trigger profile update from recent history
"""
from __future__ import annotations

import asyncio
import json
import logging
import platform
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.memory")

MEMORY_DIR = Path.home() / ".salim" / "memory"

# Keys the memory system tracks automatically
AUTO_KEYS = {
    "name":            "User's preferred name",
    "timezone":        "User's timezone (e.g. Asia/Karachi, UTC+5)",
    "language":        "Preferred response language",
    "wake_time":       "Typical wake-up time (e.g. 07:00)",
    "sleep_time":      "Typical sleep time (e.g. 23:00)",
    "work_start":      "Start of working hours (e.g. 09:00)",
    "work_end":        "End of working hours (e.g. 18:00)",
    "working_days":    "Working days (e.g. Mon-Fri)",
    "role":            "Job role or occupation",
    "projects":        "Active projects user mentions",
    "tools":           "Frequently used software/tools",
    "download_dir":    "Preferred download location",
    "desktop_dir":     "Desktop path",
    "photo_dir":       "Directory where incoming photos are auto-saved",
    "image_dir":       "Alias for photo_dir — where to save received images",
    "briefing_time":   "Daily briefing time (e.g. 08:00)",
    "briefing_enabled":"Whether daily briefing is enabled (true/false)",
    "style":           "Preferred response style (brief/detailed/technical)",
    "interests":       "Topics the user is interested in",
    "last_seen":       "Last interaction timestamp",
}


def _memory_file(user_id: int) -> Path:
    MEMORY_DIR.mkdir(parents=True, mode=0o700, exist_ok=True)
    return MEMORY_DIR / f"{user_id}.json"


def load_memory(user_id: int) -> dict:
    """Load full memory profile for a user."""
    path = _memory_file(user_id)
    if not path.exists():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_memory(user_id: int, data: dict):
    """Overwrite memory profile."""
    path = _memory_file(user_id)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    path.chmod(0o600)


def set_memory(user_id: int, key: str, value: Any):
    """Set a single memory key."""
    data = load_memory(user_id)
    data[key] = value
    data["last_updated"] = datetime.now().isoformat()
    save_memory(user_id, data)


def get_memory(user_id: int, key: str, default: Any = None) -> Any:
    return load_memory(user_id).get(key, default)


def delete_memory_key(user_id: int, key: str):
    data = load_memory(user_id)
    data.pop(key, None)
    save_memory(user_id, data)


def clear_memory(user_id: int):
    path = _memory_file(user_id)
    if path.exists():
        path.unlink()


def update_last_seen(user_id: int):
    """Update last_seen timestamp — called on every interaction."""
    set_memory(user_id, "last_seen", datetime.now().isoformat())


def build_memory_context(user_id: int) -> str:
    """
    Build a memory context string to inject into every AI system prompt.
    Returns empty string if no meaningful memory exists.
    """
    data = load_memory(user_id)
    if not data:
        return ""

    lines = ["[USER MEMORY — what you know about this user:]"]
    important_keys = [
        "name", "timezone", "role", "language", "style",
        "work_start", "work_end", "working_days",
        "wake_time", "sleep_time",
        "briefing_time", "briefing_enabled",
        "projects", "tools", "interests",
        "download_dir", "desktop_dir",
    ]
    shown = set()
    # Show important keys first
    for key in important_keys:
        if key in data and data[key]:
            lines.append(f"  {key}: {data[key]}")
            shown.add(key)
    # Show any additional user-set keys
    skip = {"last_updated", "last_seen", "command_counts", "inferred_habits"}
    for key, val in data.items():
        if key not in shown and key not in skip and val:
            if isinstance(val, (str, int, float, bool)):
                lines.append(f"  {key}: {val}")
    lines.append("Use this information to personalize responses and avoid asking for info already known.")
    return "\n".join(lines)


def learn_from_text(user_id: int, text: str):
    """
    Extract facts from user messages and update memory automatically.
    Called passively on every user message — fast, no AI call needed.
    """
    data = load_memory(user_id)
    changed = False
    text_lower = text.lower().strip()

    # ── Name detection ────────────────────────────────────────────────────────
    name_patterns = [
        r"(?:my name is|i'm|i am|call me)\s+([A-Z][a-z]{1,20})",
        r"^([A-Z][a-z]{1,20})\s+here",
    ]
    if "name" not in data:
        for pat in name_patterns:
            m = re.search(pat, text, re.IGNORECASE)
            if m:
                data["name"] = m.group(1).strip()
                changed = True
                break

    # ── Timezone detection ─────────────────────────────────────────────────────
    tz_patterns = [
        r"(?:i'm in|i live in|my timezone is|i'm at)\s+(UTC[+-]\d{1,2}|\w+/\w+)",
        r"(UTC[+-]\d{1,2})",
        r"\b(Asia/\w+|America/\w+|Europe/\w+|Africa/\w+|Pacific/\w+)\b",
    ]
    if "timezone" not in data:
        for pat in tz_patterns:
            m = re.search(pat, text, re.IGNORECASE)
            if m:
                data["timezone"] = m.group(1).strip()
                changed = True
                break

    # ── Role detection ─────────────────────────────────────────────────────────
    role_patterns = [
        r"i(?:'m| am) (?:a |an )?(.{3,30}?)(?:\.|,|$)",
        r"(?:my job|my role|i work as) (?:is |as )?(.{3,30}?)(?:\.|,|$)",
    ]
    role_kws = ["developer", "engineer", "designer", "manager", "student", "doctor",
                "teacher", "analyst", "scientist", "freelancer", "cto", "ceo", "founder"]
    if "role" not in data:
        for pat in role_patterns:
            m = re.search(pat, text_lower)
            if m:
                candidate = m.group(1).strip()
                if any(kw in candidate for kw in role_kws):
                    data["role"] = candidate
                    changed = True
                    break

    # ── Language preference ────────────────────────────────────────────────────
    if "language" not in data:
        lang_m = re.search(
            r"(?:respond|reply|answer|speak)\s+in\s+([a-zA-Z]{3,20})", text_lower
        )
        if lang_m:
            data["language"] = lang_m.group(1).strip()
            changed = True

    # ── Work hours ─────────────────────────────────────────────────────────────
    if "work_start" not in data:
        wh_m = re.search(r"(?:i work|working hours?).{0,20}?(\d{1,2}(?::\d{2})?(?:\s*[ap]m)?)", text_lower)
        if wh_m:
            data["work_start"] = wh_m.group(1).strip()
            changed = True

    # ── Track command frequency ────────────────────────────────────────────────
    cmd_match = re.match(r"^/(\w+)", text)
    if cmd_match:
        cmd = cmd_match.group(1)
        counts = data.get("command_counts", {})
        counts[cmd] = counts.get(cmd, 0) + 1
        data["command_counts"] = counts
        changed = True

    if changed:
        data["last_updated"] = datetime.now().isoformat()
        save_memory(user_id, data)


async def learn_from_ai(user_id: int, user_message: str, ai_response: str, ai_instance) -> None:
    """
    Use the AI to extract facts from a conversation exchange and update memory.
    Called asynchronously after non-trivial exchanges — won't block main flow.
    """
    data = load_memory(user_id)
    existing = {k: v for k, v in data.items()
                if k not in ("command_counts", "last_seen", "last_updated", "inferred_habits")}

    extract_prompt = f"""You are a memory extractor for a personal AI assistant.

Given this conversation exchange, extract any NEW facts about the user.
Return a JSON object with ONLY new keys not already known.
Return empty {{}} if nothing new was learned.

ALREADY KNOWN: {json.dumps(existing, ensure_ascii=False)}

USER SAID: {user_message[:500]}
ASSISTANT REPLIED: {ai_response[:500]}

Extract keys like: name, timezone, role, language, projects, tools, interests,
work_start, work_end, wake_time, sleep_time, style, download_dir, briefing_time, briefing_enabled.

Return ONLY valid JSON. No explanation."""

    try:
        from salim.ai import SalimAI
        from salim.config import Config
        cfg = Config()
        ai_obj = ai_instance if ai_instance else SalimAI(cfg)
        raw, _ = await ai_obj._call_with_fallback(
            [{"role": "user", "content": extract_prompt}],
            system="You are a JSON-only extractor. Output only valid JSON, nothing else.",
            max_tokens=256,
            temperature=0.1,
        )
        raw = re.sub(r"```(?:json)?|```", "", raw).strip()
        new_facts = json.loads(raw)
        if isinstance(new_facts, dict) and new_facts:
            for k, v in new_facts.items():
                if v and k not in ("last_updated", "last_seen"):
                    data[k] = v
            data["last_updated"] = datetime.now().isoformat()
            save_memory(user_id, data)
            logger.info(f"Memory updated for user {user_id}: {list(new_facts.keys())}")
    except Exception as e:
        logger.debug(f"Memory AI extraction skipped: {e}")


class MemoryHandlers:
    """Mixin for SalimBot — adds /memory commands."""

    @require_auth
    async def cmd_memory(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /memory              — view profile
        /memory set <k> <v>  — set a value
        /memory forget <key> — remove a key
        /memory clear        — wipe everything
        /memory learn        — re-extract from recent history
        """
        import html as _html
        def esc(v): return _html.escape(str(v), quote=False)

        msg = update.effective_message
        user_id = update.effective_user.id
        args = ctx.args or []

        if args and args[0].lower() == "clear":
            clear_memory(user_id)
            await msg.reply_text(
                "🧹 <b>Memory cleared.</b>\n"
                "<i>Salim no longer remembers anything about you.\n"
                "It will start learning again from scratch.</i>",
                parse_mode="HTML",
            )
            return

        if args and args[0].lower() == "forget" and len(args) >= 2:
            key = args[1].lower()
            delete_memory_key(user_id, key)
            await msg.reply_text(
                f"🗑️ Forgot: <code>{esc(key)}</code>", parse_mode="HTML"
            )
            return

        if args and args[0].lower() == "set" and len(args) >= 3:
            key = args[1].lower()
            value = " ".join(args[2:])
            set_memory(user_id, key, value)
            await msg.reply_text(
                f"✅ Memory updated:\n"
                f"<code>{esc(key)}</code> = <code>{esc(value)}</code>",
                parse_mode="HTML",
            )
            return

        if args and args[0].lower() == "learn":
            thinking = await msg.reply_text("🧠 <i>Re-learning from your recent conversation history…</i>", parse_mode="HTML")
            from salim.handlers.history import load_history
            history = load_history(user_id, 30)
            if not history:
                await thinking.edit_text("📭 No history to learn from yet.", parse_mode="HTML")
                return
            # Run AI extraction on last few exchanges
            try:
                pairs = []
                user_msgs = [h["content"] for h in history if h.get("role") == "user"]
                asst_msgs = [h["content"] for h in history if h.get("role") == "assistant"]
                combined_user = " ".join(user_msgs[-5:])
                combined_asst = " ".join(asst_msgs[-5:])
                await learn_from_ai(user_id, combined_user, combined_asst, self._ai if hasattr(self, "_ai") else None)
                data = load_memory(user_id)
                count = len([v for v in data.values() if v and not isinstance(v, dict)])
                await thinking.edit_text(
                    f"🧠 <b>Learning complete!</b>\n"
                    f"<i>{count} facts now stored in memory.</i>",
                    parse_mode="HTML",
                )
            except Exception as e:
                await thinking.edit_text(f"⚠️ Learning failed: {esc(str(e))}", parse_mode="HTML")
            return

        # ── Show memory ────────────────────────────────────────────────────────
        data = load_memory(user_id)
        if not data:
            await msg.reply_text(
                "🧠 <b>No memory yet.</b>\n\n"
                "<i>Salim will automatically learn about you as you chat.\n\n"
                "You can also manually set preferences:</i>\n"
                "<code>/memory set name Ahmed</code>\n"
                "<code>/memory set timezone UTC+5</code>\n"
                "<code>/memory set briefing_time 08:00</code>\n"
                "<code>/memory set style brief</code>",
                parse_mode="HTML",
            )
            return

        skip = {"command_counts", "last_seen", "inferred_habits"}
        lines = ["🧠 <b>Your Memory Profile</b>\n"]
        for k, v in data.items():
            if k in skip:
                continue
            if isinstance(v, dict):
                continue
            icon = {
                "name": "👤", "timezone": "🌍", "role": "💼", "language": "🗣️",
                "wake_time": "⏰", "sleep_time": "😴", "work_start": "🏢", "work_end": "🏠",
                "projects": "📁", "tools": "🔧", "interests": "⭐", "style": "✏️",
                "briefing_time": "📰", "briefing_enabled": "🔔",
            }.get(k, "📌")
            lines.append(f"{icon} <b>{esc(k)}</b>: <code>{esc(str(v))}</code>")

        # Show top 5 most used commands
        counts = data.get("command_counts", {})
        if counts:
            top = sorted(counts.items(), key=lambda x: x[1], reverse=True)[:5]
            top_str = ", ".join(f"/{cmd}({n})" for cmd, n in top)
            lines.append(f"\n📊 <b>Top commands:</b> {esc(top_str)}")

        last = data.get("last_updated", "")
        if last:
            lines.append(f"\n<i>Last updated: {esc(last[:16])}</i>")

        lines.append(
            "\n<i>Commands: /memory set &lt;k&gt; &lt;v&gt; · /memory forget &lt;k&gt; · /memory clear</i>"
        )
        await msg.reply_text("\n".join(lines), parse_mode="HTML")


# ═══════════════════════════════════════════════════════════════════════════════
#  VECTOR / SEMANTIC MEMORY  (v18 upgrade)
# ═══════════════════════════════════════════════════════════════════════════════

import hashlib
import struct

VECTOR_INDEX_FILE = MEMORY_DIR / "vectors.json"


def _simple_embed(text: str) -> list[float]:
    """
    Lightweight local embedding via character n-gram frequency.
    No GPU, no internet. Falls back gracefully if sentence-transformers unavailable.
    Produces a 128-dim vector sufficient for personal memory semantic search.
    """
    try:
        # Try sentence-transformers first (if user has it installed)
        from sentence_transformers import SentenceTransformer
        _model = getattr(_simple_embed, "_model", None)
        if _model is None:
            _simple_embed._model = SentenceTransformer("all-MiniLM-L6-v2")
        vec = _simple_embed._model.encode(text).tolist()
        return vec[:128]
    except ImportError:
        pass

    # Fallback: TF-IDF word vector (256 dims) — much better than n-gram for semantic search
    import math
    words = text.lower().split()
    if not words:
        return [0.0] * 128
    # TF: term frequency in this text
    tf = {}
    for w in words:
        tf[w] = tf.get(w, 0) + 1
    # IDF: inverse doc frequency from global doc count cache
    doc_count = getattr(_simple_embed, "_doc_count", {})
    total_docs = getattr(_simple_embed, "_total_docs", 1) + 1
    vec = [0.0] * 128
    for word, freq in tf.items():
        tf_val = freq / len(words)
        idf_val = math.log((total_docs + 1) / (doc_count.get(word, 0) + 1)) + 1
        tfidf = tf_val * idf_val
        # Hash word to dimension
        dim = int(hashlib.md5(word.encode()).hexdigest()[:4], 16) % 128
        vec[dim] += tfidf
    norm = sum(v*v for v in vec) ** 0.5
    return [v/norm for v in vec] if norm > 0 else vec


def _update_idf_cache(text: str):
    """Update the IDF document frequency cache for better TF-IDF quality."""
    words = set(text.lower().split())
    doc_count = getattr(_simple_embed, "_doc_count", {})
    for w in words:
        doc_count[w] = doc_count.get(w, 0) + 1
    _simple_embed._doc_count = doc_count
    _simple_embed._total_docs = getattr(_simple_embed, "_total_docs", 0) + 1


def _cosine_sim(a: list[float], b: list[float]) -> float:
    """Cosine similarity between two vectors."""
    if len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    mag_a = sum(x * x for x in a) ** 0.5
    mag_b = sum(x * x for x in b) ** 0.5
    if mag_a == 0 or mag_b == 0:
        return 0.0
    return dot / (mag_a * mag_b)


def load_vector_index(user_id: int) -> list[dict]:
    """Load semantic vector index for a user."""
    path = MEMORY_DIR / f"{user_id}_vectors.json"
    if not path.exists():
        return []
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return []


def save_vector_index(user_id: int, index: list[dict]):
    """Save vector index."""
    path = MEMORY_DIR / f"{user_id}_vectors.json"
    path.write_text(json.dumps(index, ensure_ascii=False), encoding="utf-8")
    path.chmod(0o600)


def index_memory_fact(user_id: int, key: str, value: str):
    """
    Add or update a fact in the vector index.
    Deduplicates by key — updates existing entry instead of creating duplicate.
    """
    text = f"{key}: {value}"
    vec = _simple_embed(text)
    index = load_vector_index(user_id)

    # Dedup: remove existing entry with same key
    index = [e for e in index if e.get("key") != key]
    index.append({
        "key": key,
        "value": value,
        "text": text,
        "vec": vec,
        "ts": datetime.now().isoformat(),
    })
    # Keep index bounded
    index = index[-500:]
    save_vector_index(user_id, index)


def _bm25_score(query_terms: list[str], doc_terms: list[str], k1: float = 1.5, b: float = 0.75) -> float:
    """BM25 ranking score between query and document."""
    import math
    if not doc_terms:
        return 0.0
    doc_len = len(doc_terms)
    avg_len = 10.0  # assumed average memory entry length
    term_freq = {}
    for t in doc_terms:
        term_freq[t] = term_freq.get(t, 0) + 1
    score = 0.0
    for term in query_terms:
        tf = term_freq.get(term, 0)
        if tf == 0:
            continue
        idf = math.log(2)  # simplified IDF
        tf_norm = (tf * (k1 + 1)) / (tf + k1 * (1 - b + b * doc_len / avg_len))
        score += idf * tf_norm
    return score


def semantic_search_memory(user_id: int, query: str, top_k: int = 5) -> list[dict]:
    """
    v19: Hybrid BM25 + embedding similarity search over user memory.
    BM25 for keyword precision, embedding for semantic recall.
    Results are interleaved and deduplicated by key.
    """
    index = load_vector_index(user_id)
    if not index:
        return []

    query_lower = query.lower()
    query_terms = query_lower.split()
    query_vec = _simple_embed(query)

    scored = {}
    for entry in index:
        key = entry.get("key", "")
        text = f"{key} {entry.get('value', '')}".lower()
        doc_terms = text.split()

        # BM25 score (keyword matching)
        bm25 = _bm25_score(query_terms, doc_terms)

        # Vector similarity score (semantic)
        vec = entry.get("vec", [])
        cosine = _cosine_sim(query_vec, vec) if vec else 0.0

        # Exact substring bonus
        exact_bonus = 0.5 if query_lower in text else 0.0

        # Hybrid score: 40% BM25 + 50% cosine + 10% exact
        hybrid = (bm25 * 0.4) + (cosine * 0.5) + (exact_bonus * 0.1)

        if hybrid > 0.05:
            # Deduplicate by key, keep highest score
            if key not in scored or scored[key][0] < hybrid:
                scored[key] = (hybrid, entry)

    top = sorted(scored.values(), key=lambda x: x[0], reverse=True)[:top_k]
    return [e for _, e in top]


def set_memory_with_index(user_id: int, key: str, value: Any):
    """Set a memory key AND update the vector index (deduped)."""
    set_memory(user_id, key, value)
    try:
        index_memory_fact(user_id, key, str(value))
    except Exception as e:
        logger.debug(f"Vector index update failed: {e}")


def rebuild_vector_index(user_id: int):
    """Rebuild the full vector index from the flat JSON memory."""
    data = load_memory(user_id)
    skip = {"last_updated", "last_seen", "command_counts", "inferred_habits"}
    for key, val in data.items():
        if key not in skip and isinstance(val, (str, int, float, bool)) and val:
            try:
                index_memory_fact(user_id, key, str(val))
            except Exception:
                pass


# ═══════════════════════════════════════════════════════════════════════════════
#  ENTITY GRAPH (v18)  — simple relationship tracking
# ═══════════════════════════════════════════════════════════════════════════════

def get_entity_graph(user_id: int) -> dict:
    """Load entity relationship graph."""
    path = MEMORY_DIR / f"{user_id}_graph.json"
    if not path.exists():
        return {"entities": {}, "relations": []}
    try:
        return json.loads(path.read_text())
    except Exception:
        return {"entities": {}, "relations": []}


def save_entity_graph(user_id: int, graph: dict):
    path = MEMORY_DIR / f"{user_id}_graph.json"
    path.write_text(json.dumps(graph, indent=2))
    path.chmod(0o600)


def add_entity_relation(user_id: int, entity_a: str, relation: str, entity_b: str):
    """Record a relationship: e.g. ('Ahmed', 'works_on', 'Project X')."""
    graph = get_entity_graph(user_id)
    graph.setdefault("entities", {})[entity_a.lower()] = entity_a
    graph.setdefault("entities", {})[entity_b.lower()] = entity_b
    triple = {"a": entity_a, "rel": relation, "b": entity_b, "ts": datetime.now().isoformat()}
    # Dedup
    existing = [(r["a"], r["rel"], r["b"]) for r in graph.get("relations", [])]
    if (entity_a, relation, entity_b) not in existing:
        graph.setdefault("relations", []).append(triple)
        graph["relations"] = graph["relations"][-200:]
    save_entity_graph(user_id, graph)


def build_entity_ascii_graph(user_id: int) -> str:
    """Build a simple ASCII representation of the entity graph."""
    graph = get_entity_graph(user_id)
    relations = graph.get("relations", [])
    if not relations:
        return "(no entity relationships yet)"
    lines = []
    for r in relations[-20:]:
        lines.append(f"  {r['a']}  —[{r['rel']}]→  {r['b']}")
    return "\n".join(lines)


# ═══════════════════════════════════════════════════════════════════════════════
#  EXTENDED /memory COMMANDS (v18): search, graph
# ═══════════════════════════════════════════════════════════════════════════════

class MemoryHandlersV18(MemoryHandlers):
    """
    Extended memory handlers adding:
      /memory search <query>  — semantic search
      /memory graph           — entity relationship view
      /memory reindex         — rebuild vector index
    """

    @require_auth
    async def cmd_memory(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        import html as _html
        def esc2(v): return _html.escape(str(v), quote=False)

        msg = update.effective_message
        user_id = update.effective_user.id
        args = ctx.args or []

        # ── New v18 sub-commands ──────────────────────────────────────────────
        if args and args[0].lower() == "search":
            query = " ".join(args[1:])
            if not query:
                await msg.reply_text("Usage: <code>/memory search &lt;query&gt;</code>", parse_mode="HTML")
                return
            results = semantic_search_memory(user_id, query)
            if not results:
                await msg.reply_text(
                    f"🔍 No semantic matches for: <b>{esc2(query)}</b>\n"
                    "<i>Try /memory learn to index recent conversations.</i>",
                    parse_mode="HTML"
                )
                return
            lines = [f"🔍 <b>Semantic search: {esc2(query)}</b>\n"]
            for r in results:
                lines.append(f"• <b>{esc2(r['key'])}</b>: {esc2(str(r['value'])[:100])}")
            await msg.reply_text("\n".join(lines), parse_mode="HTML")
            return

        if args and args[0].lower() == "graph":
            graph_text = build_entity_ascii_graph(user_id)
            await msg.reply_text(
                f"🕸 <b>Entity Graph</b>\n\n<pre>{esc2(graph_text)}</pre>",
                parse_mode="HTML"
            )
            return

        if args and args[0].lower() == "reindex":
            thinking = await msg.reply_text("🔄 <i>Rebuilding vector index…</i>", parse_mode="HTML")
            rebuild_vector_index(user_id)
            index = load_vector_index(user_id)
            await thinking.edit_text(
                f"✅ Vector index rebuilt: <b>{len(index)} facts</b> indexed for semantic search.",
                parse_mode="HTML"
            )
            return

        # ── Handle original sub-commands via parent ────────────────────────────
        await super().cmd_memory(update, ctx)

# Replace MemoryHandlers with extended version for bot mixin
MemoryHandlers = MemoryHandlersV18
