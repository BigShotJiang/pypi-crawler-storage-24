"""
Salim Intrusion Alert — physical security monitor.

When armed, Salim watches for:
  • Mouse movement (detected via psutil or pynput)
  • Keyboard activity
  • New USB devices plugged in
  • Webcam access attempts (process monitor)
  • Login/logout events (on Linux via wtmp, on Mac via last)

On detection:
  1. Takes a screenshot immediately
  2. Takes a webcam photo (if available)
  3. Sends alert + photos to Telegram with timestamp

Commands:
  /guard on      — arm intrusion detection (with grace period)
  /guard off     — disarm
  /guard status  — show armed/disarmed status + last event
  /guard grace 60 — set grace period in seconds (default: 30s)

Uses pynput (auto-installed) for keyboard/mouse monitoring.
Falls back to psutil mouse position polling if pynput unavailable.
"""
from __future__ import annotations

import asyncio
import io
import json
import logging
import os
import subprocess
import sys
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

import psutil
from telegram import Bot, Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import is_mac, is_linux, is_windows

logger = logging.getLogger("salim.guard")

GUARD_STATE_FILE = Path.home() / ".salim" / "guard_state.json"

# Global guard state
_guard_armed = False
_guard_task: Optional[asyncio.Task] = None
_guard_bot: Optional[Bot] = None
_guard_user_ids: list[int] = []
_grace_period = 30          # seconds before monitoring starts after arming
_last_mouse_pos = (0, 0)
_last_alert_time = 0.0
_alert_cooldown = 60        # seconds between alerts (avoid spam)


def _save_guard_state():
    GUARD_STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    GUARD_STATE_FILE.write_text(json.dumps({
        "armed": _guard_armed,
        "grace": _grace_period,
    }))


def _load_guard_state() -> dict:
    try:
        if GUARD_STATE_FILE.exists():
            return json.loads(GUARD_STATE_FILE.read_text())
    except Exception:
        pass
    return {"armed": False, "grace": 30}


def _ensure_pynput() -> bool:
    try:
        from pynput import mouse, keyboard  # noqa
        return True
    except ImportError:
        pass
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "pynput", "--quiet"],
            check=True, timeout=60
        )
        return True
    except Exception:
        return False


async def _take_screenshot() -> Optional[bytes]:
    """Take a screenshot. Returns JPEG bytes or None."""
    try:
        import pyautogui
        from PIL import Image
        shot = pyautogui.screenshot()
        buf = io.BytesIO()
        shot.save(buf, format="JPEG", quality=75, optimize=True)
        return buf.getvalue()
    except Exception:
        pass
    # Fallback: ffmpeg
    try:
        import tempfile
        with tempfile.NamedTemporaryFile(suffix=".jpg", delete=False) as f:
            path = f.name
        if is_linux():
            display = os.environ.get("DISPLAY", ":0")
            proc = await asyncio.create_subprocess_exec(
                "ffmpeg", "-y", "-f", "x11grab", "-video_size", "1920x1080",
                "-i", display, "-vframes", "1", path,
                stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL
            )
        elif is_mac():
            proc = await asyncio.create_subprocess_exec(
                "screencapture", "-x", path,
                stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL
            )
        else:
            return None

        await proc.wait()
        if Path(path).exists():
            data = Path(path).read_bytes()
            Path(path).unlink()
            return data
    except Exception:
        pass
    return None


async def _take_webcam_photo() -> Optional[bytes]:
    """Capture webcam frame. Returns JPEG bytes or None."""
    try:
        import cv2
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            return None
        for _ in range(3):
            cap.read()
        ret, frame = cap.read()
        cap.release()
        if not ret:
            return None
        ret, buf = cv2.imencode(".jpg", frame, [cv2.IMWRITE_JPEG_QUALITY, 80])
        return buf.tobytes() if ret else None
    except Exception:
        return None



# ═══════════════════════════════════════════════════════════════════════════════
#  OFFLINE QUEUE — stores alerts when internet is unavailable
# ═══════════════════════════════════════════════════════════════════════════════

import base64 as _b64
import socket as _socket

GUARD_QUEUE_FILE = Path.home() / ".salim" / "guard_queue.jsonl"
_flush_task: Optional[asyncio.Task] = None   # background flush task


def _is_online() -> bool:
    """Quick connectivity check — try to resolve dns."""
    try:
        _socket.setdefaulttimeout(3)
        _socket.getaddrinfo("api.telegram.org", 443)
        return True
    except Exception:
        return False


def _queue_alert(reason: str, ts: str, screenshot: Optional[bytes], webcam: Optional[bytes]):
    """Persist an alert event to disk for later delivery."""
    GUARD_QUEUE_FILE.parent.mkdir(parents=True, exist_ok=True)
    entry = {
        "ts": ts,
        "reason": reason,
        "screenshot_b64": _b64.b64encode(screenshot).decode() if screenshot else None,
        "webcam_b64": _b64.b64encode(webcam).decode() if webcam else None,
        "queued_at": datetime.now().isoformat(),
    }
    try:
        with open(GUARD_QUEUE_FILE, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
        logger.info(f"Guard alert queued offline: {reason} @ {ts}")
    except Exception as e:
        logger.error(f"Failed to queue alert: {e}")


def _load_queue() -> list[dict]:
    if not GUARD_QUEUE_FILE.exists():
        return []
    entries = []
    try:
        for line in GUARD_QUEUE_FILE.read_text(encoding="utf-8").strip().splitlines():
            try:
                entries.append(json.loads(line))
            except Exception:
                pass
    except Exception:
        pass
    return entries


def _clear_queue():
    if GUARD_QUEUE_FILE.exists():
        GUARD_QUEUE_FILE.unlink()


async def _send_alert_entry(entry: dict):
    """Send a single queued alert entry to Telegram."""
    if not _guard_bot or not _guard_user_ids:
        return
    ts = entry.get("ts", "?")
    reason = entry.get("reason", "?")
    queued = entry.get("queued_at", "")
    screenshot_b64 = entry.get("screenshot_b64")
    webcam_b64 = entry.get("webcam_b64")

    screenshot = _b64.b64decode(screenshot_b64) if screenshot_b64 else None
    webcam = _b64.b64decode(webcam_b64) if webcam_b64 else None

    offline_note = ""
    if queued and queued != ts:
        offline_note = f"\n⚠️ <i>Stored offline, sent at {queued[:19]}</i>"

    alert_text = (
        f"🚨 <b>INTRUSION DETECTED</b>{offline_note}\n\n"
        f"📍 Reason: <b>{reason}</b>\n"
        f"🕐 Time: {ts}\n"
        f"💻 Host: {os.uname().nodename if hasattr(os, 'uname') else 'unknown'}\n\n"
        f"<i>Photos below if available.</i>"
    )
    for uid in _guard_user_ids:
        try:
            await _guard_bot.send_message(chat_id=uid, text=alert_text, parse_mode="HTML")
            if screenshot:
                buf = io.BytesIO(screenshot)
                await _guard_bot.send_photo(chat_id=uid, photo=buf, caption=f"🖥️ Screenshot at {ts}")
            if webcam:
                buf = io.BytesIO(webcam)
                await _guard_bot.send_photo(chat_id=uid, photo=buf, caption=f"📷 Webcam at {ts}")
        except Exception as e:
            logger.error(f"Failed to send queued guard alert to {uid}: {e}")
            raise  # propagate so we know flushing failed


async def _flush_queue_loop():
    """Background loop: check for internet every 30s and flush stored alerts."""
    global _flush_task
    while _guard_armed:
        await asyncio.sleep(30)
        queue = _load_queue()
        if not queue:
            continue
        if not _is_online():
            continue
        logger.info(f"Guard: internet restored, flushing {len(queue)} queued alert(s)")
        sent_all = True
        for entry in queue:
            try:
                await _send_alert_entry(entry)
            except Exception:
                sent_all = False
                break
        if sent_all:
            _clear_queue()
            logger.info("Guard: all queued alerts sent and cleared")


async def _send_intrusion_alert(reason: str):
    """Send alert with screenshot and webcam photo. Queues offline if no internet."""
    global _last_alert_time, _flush_task

    now = time.time()
    if now - _last_alert_time < _alert_cooldown:
        return
    _last_alert_time = now

    if not _guard_bot or not _guard_user_ids:
        return

    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logger.warning(f"Intrusion detected: {reason}")

    # Capture evidence regardless of connectivity
    screenshot = await _take_screenshot()
    webcam = await _take_webcam_photo()

    # Start flush loop if not running
    if _flush_task is None or _flush_task.done():
        _flush_task = asyncio.create_task(_flush_queue_loop())

    if not _is_online():
        # No internet — store to disk, will send when online
        _queue_alert(reason, ts, screenshot, webcam)
        logger.warning(f"Guard: offline, alert queued for later delivery ({reason})")
        return

    # Online — try to send immediately; on failure, queue
    entry = {
        "ts": ts,
        "reason": reason,
        "screenshot_b64": _b64.b64encode(screenshot).decode() if screenshot else None,
        "webcam_b64": _b64.b64encode(webcam).decode() if webcam else None,
        "queued_at": datetime.now().isoformat(),
    }
    try:
        await _send_alert_entry(entry)
    except Exception as e:
        logger.error(f"Guard: send failed ({e}), queuing alert for retry")
        _queue_alert(reason, ts, screenshot, webcam)


async def _psutil_guard_loop():
    """Fallback mouse-position polling when pynput unavailable."""
    global _last_mouse_pos, _guard_armed

    try:
        import pyautogui
        _last_mouse_pos = pyautogui.position()
    except Exception:
        pass

    while _guard_armed:
        try:
            import pyautogui
            pos = pyautogui.position()
            if pos != _last_mouse_pos:
                _last_mouse_pos = pos
                await _send_intrusion_alert("Mouse movement detected")
        except Exception:
            pass
        await asyncio.sleep(3)


def _get_usb_devices() -> set[str]:
    """Get current list of USB device names (Linux)."""
    try:
        result = subprocess.run(
            ["lsusb"], capture_output=True, text=True, timeout=5
        )
        return set(result.stdout.strip().splitlines())
    except Exception:
        return set()


async def _pynput_guard_loop():
    """Full intrusion detection using pynput (mouse + keyboard events)."""
    global _guard_armed

    from pynput import mouse as pynput_mouse, keyboard as pynput_keyboard

    # threading.Event so pynput callbacks (running in their own thread) can set it safely
    _activity_flag = threading.Event()
    _main_loop = asyncio.get_event_loop()

    def _wake():
        """Called from pynput thread — sets flag and wakes the asyncio loop."""
        _activity_flag.set()

    def on_move(x, y):
        if _guard_armed:
            _main_loop.call_soon_threadsafe(_wake)

    def on_click(x, y, button, pressed):
        if _guard_armed and pressed:
            _main_loop.call_soon_threadsafe(_wake)

    def on_press(key):
        if _guard_armed:
            _main_loop.call_soon_threadsafe(_wake)

    mouse_listener = pynput_mouse.Listener(on_move=on_move, on_click=on_click)
    keyboard_listener = pynput_keyboard.Listener(on_press=on_press)
    mouse_listener.start()
    keyboard_listener.start()

    # USB monitoring baseline
    usb_baseline = _get_usb_devices() if is_linux() else set()

    try:
        while _guard_armed:
            # Poll the threading.Event with a short asyncio sleep so we don't block
            await asyncio.sleep(0.5)

            if _activity_flag.is_set():
                _activity_flag.clear()
                if _guard_armed:
                    await _send_intrusion_alert("Input activity detected (mouse/keyboard)")

            # USB check every ~10 s (every 20 iterations of the 0.5 s loop)
            if is_linux():
                current_usb = _get_usb_devices()
                new_devices = current_usb - usb_baseline
                if new_devices:
                    usb_baseline = current_usb
                    device_names = ", ".join(list(new_devices)[:3])
                    await _send_intrusion_alert(f"New USB device detected: {device_names}")

    finally:
        mouse_listener.stop()
        keyboard_listener.stop()


async def _guard_loop():
    """Main guard loop — picks best monitoring method available."""
    global _guard_armed

    logger.info("Guard: monitoring started")

    if _ensure_pynput():
        await _pynput_guard_loop()
    else:
        logger.warning("Guard: pynput unavailable, falling back to mouse polling")
        await _psutil_guard_loop()

    logger.info("Guard: monitoring stopped")


class IntrusionHandlers:

    @require_auth
    async def cmd_guard(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /guard on [grace_seconds]  — arm intrusion detection
        /guard off                 — disarm
        /guard status              — show status
        /guard grace <seconds>     — set grace period
        """
        global _guard_armed, _guard_task, _guard_bot, _guard_user_ids, _grace_period

        args = ctx.args or []
        msg = update.effective_message

        if not args or args[0].lower() == "status":
            await self._guard_status(msg)
            return

        sub = args[0].lower()

        if sub == "grace" and len(args) >= 2:
            try:
                _grace_period = max(5, int(args[1]))
                await msg.reply_text(
                    f"⏱️ Grace period set to <b>{_grace_period}s</b>",
                    parse_mode="HTML"
                )
            except ValueError:
                await msg.reply_text("❌ Grace period must be a number of seconds.")
            return

        if sub == "on":
            if _guard_armed:
                await msg.reply_text("🛡️ Guard is already armed.")
                return

            # Parse optional grace override
            grace = _grace_period
            if len(args) >= 2:
                try:
                    grace = int(args[1])
                except ValueError:
                    pass

            _guard_armed = True
            _guard_bot = ctx.bot
            _guard_user_ids = self.config.allowed_ids
            _save_guard_state()

            await msg.reply_text(
                f"🛡️ <b>Guard arming in {grace}s...</b>\n\n"
                f"Move away from your laptop now.\n"
                f"Any mouse/keyboard activity after {grace}s will trigger an alert\n"
                f"with screenshots sent here.\n\n"
                f"<code>/guard off</code> to disarm.",
                parse_mode="HTML"
            )

            # Grace period
            await asyncio.sleep(grace)

            if not _guard_armed:
                return  # Disarmed during grace period

            await msg.reply_text(
                "🔴 <b>Guard ARMED</b> — Watching for intrusions.",
                parse_mode="HTML"
            )

            # Start monitoring
            if _guard_task and not _guard_task.done():
                _guard_task.cancel()

            _guard_task = asyncio.create_task(_guard_loop())
            return

        if sub == "off":
            if not _guard_armed:
                await msg.reply_text("🛡️ Guard is already disarmed.")
                return

            _guard_armed = False
            _save_guard_state()

            if _guard_task:
                _guard_task.cancel()
                _guard_task = None

            await msg.reply_text(
                "🟢 <b>Guard DISARMED</b> — Monitoring stopped.",
                parse_mode="HTML"
            )
            return

        # Unknown subcommand — show help
        await msg.reply_text(
            "🛡️ <b>Intrusion Guard</b>\n\n"
            "<b>Commands:</b>\n"
            "  <code>/guard on</code>       — arm (30s grace period)\n"
            "  <code>/guard on 60</code>    — arm with 60s grace\n"
            "  <code>/guard off</code>      — disarm\n"
            "  <code>/guard status</code>   — show current state\n"
            "  <code>/guard grace 45</code> — set grace period\n\n"
            "<b>What it detects:</b>\n"
            "• Mouse movement\n"
            "• Any key press\n"
            "• USB devices plugged in (Linux)\n\n"
            "<b>On detection:</b>\n"
            "• Sends alert to Telegram\n"
            "• Takes screenshot + webcam photo\n"
            f"• Cooldown: {_alert_cooldown}s between alerts",
            parse_mode="HTML"
        )

    async def _guard_status(self, msg):
        global _guard_armed, _grace_period

        state = "🔴 <b>ARMED</b>" if _guard_armed else "🟢 Disarmed"
        last_alert = ""
        if _last_alert_time > 0:
            dt = datetime.fromtimestamp(_last_alert_time).strftime("%H:%M:%S")
            last_alert = f"\nLast alert: {dt}"

        has_pynput = False
        try:
            from pynput import mouse  # noqa
            has_pynput = True
        except ImportError:
            pass

        await msg.reply_text(
            f"🛡️ <b>Guard Status</b>\n\n"
            f"State: {state}\n"
            f"Grace period: {_grace_period}s\n"
            f"Monitor method: {'pynput (keyboard+mouse)' if has_pynput else 'mouse polling'}{last_alert}\n\n"
            f"<code>/guard on</code> to arm · <code>/guard off</code> to disarm",
            parse_mode="HTML"
        )
