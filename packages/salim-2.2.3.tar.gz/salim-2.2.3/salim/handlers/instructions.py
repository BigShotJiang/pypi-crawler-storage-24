"""
Salim AI Instructions — User-defined AI personality traits & behaviours.

Allows users to build a custom AI assistant by providing persistent
instructions that shape how Salim responds to everything.

Usage:
  /instr <text>          — Add/replace instructions (plain text)
  /instr delete          — Delete all saved instructions
  /instr show            — Display current instructions
  /instr append <text>   — Append new instructions to existing ones

Instructions are saved per-user to ~/.salim/instructions/<user_id>.txt
They are automatically injected into every AI prompt as a system directive.

Examples:
  /instr Be concise. Always reply in bullet points. Use emoji. You are called "Max".
  /instr append Always end responses with a motivational quote.
  /instr delete
"""
from __future__ import annotations

import html
import logging
from pathlib import Path
from datetime import datetime

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.instructions")

INSTRUCTIONS_DIR = Path.home() / ".salim" / "instructions"


def _esc(v: str) -> str:
    return html.escape(str(v), quote=False)


def _instructions_file(user_id: int) -> Path:
    INSTRUCTIONS_DIR.mkdir(parents=True, mode=0o700, exist_ok=True)
    return INSTRUCTIONS_DIR / f"{user_id}.txt"


def load_instructions(user_id: int) -> str:
    """Load saved instructions for a user. Returns empty string if none."""
    path = _instructions_file(user_id)
    if not path.exists():
        return ""
    try:
        return path.read_text(encoding="utf-8").strip()
    except Exception:
        return ""


def save_instructions(user_id: int, text: str):
    """Save instructions for a user."""
    path = _instructions_file(user_id)
    path.write_text(text.strip(), encoding="utf-8")
    path.chmod(0o600)


def delete_instructions(user_id: int):
    """Delete all instructions for a user."""
    path = _instructions_file(user_id)
    if path.exists():
        path.unlink()


def build_instructions_context(user_id: int) -> str:
    """
    Build an instructions context block to inject into AI system prompts.
    Returns empty string if user has no custom instructions.
    """
    instructions = load_instructions(user_id)
    if not instructions:
        return ""
    return (
        "[USER INSTRUCTIONS — follow these behavioural directives precisely and persistently:]\n"
        + instructions
        + "\n[End of user instructions. Apply them to all your responses.]"
    )


class InstructionsHandlers:
    """Mixin for SalimBot — adds /instr command for custom AI instructions."""

    @require_auth
    async def cmd_instr(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /instr <text>         — Set/replace instructions
        /instr append <text>  — Append to existing instructions
        /instr delete         — Remove all instructions
        /instr show           — Show current instructions
        /instr                — Same as show
        """
        msg = update.effective_message
        user_id = update.effective_user.id
        raw = msg.text or ""

        # Strip the /instr command prefix to get the argument text
        # msg.text might be "/instr text here" or "/instr@botname text"
        parts = raw.split(None, 1)  # ["/instr", "rest..."]
        arg_text = parts[1].strip() if len(parts) > 1 else ""

        # Sub-commands
        if not arg_text or arg_text.lower() == "show":
            await self._instr_show(msg, user_id)
            return

        if arg_text.lower() == "delete":
            delete_instructions(user_id)
            await msg.reply_text(
                "🗑️ <b>Instructions deleted.</b>\n\n"
                "<i>Salim will now respond with its default behaviour.\n"
                "Use <code>/instr &lt;text&gt;</code> to set new instructions.</i>",
                parse_mode="HTML",
            )
            return

        if arg_text.lower().startswith("append "):
            new_part = arg_text[7:].strip()
            if not new_part:
                await msg.reply_text(
                    "❓ Nothing to append.\nUsage: <code>/instr append &lt;text&gt;</code>",
                    parse_mode="HTML",
                )
                return
            existing = load_instructions(user_id)
            if existing:
                combined = existing + "\n" + new_part
            else:
                combined = new_part
            save_instructions(user_id, combined)
            preview = _esc(combined[:400]) + ("..." if len(combined) > 400 else "")
            await msg.reply_text(
                f"✅ <b>Instructions updated</b> (appended)\n\n"
                f"<b>Full instructions now:</b>\n<pre>{preview}</pre>",
                parse_mode="HTML",
            )
            return

        # Default: set/replace
        save_instructions(user_id, arg_text)
        preview = _esc(arg_text[:400]) + ("..." if len(arg_text) > 400 else "")
        await msg.reply_text(
            f"✅ <b>AI Instructions saved!</b>\n\n"
            f"<b>Active instructions:</b>\n<pre>{preview}</pre>\n\n"
            f"<i>Salim will follow these in all future responses.\n"
            f"Use <code>/instr append &lt;more&gt;</code> to add more.\n"
            f"Use <code>/instr delete</code> to remove them.</i>",
            parse_mode="HTML",
        )

    async def _instr_show(self, msg, user_id: int):
        instructions = load_instructions(user_id)
        if not instructions:
            await msg.reply_text(
                "📋 <b>No instructions set.</b>\n\n"
                "<i>Add custom behaviour with:</i>\n"
                "<code>/instr Be concise. Reply in bullet points. Call yourself Max.</code>\n\n"
                "<b>More options:</b>\n"
                "  <code>/instr append &lt;text&gt;</code> — add to existing\n"
                "  <code>/instr delete</code> — remove all\n"
                "  <code>/instr show</code> — show current (this)",
                parse_mode="HTML",
            )
            return
        preview = _esc(instructions[:1200]) + ("..." if len(instructions) > 1200 else "")
        length = len(instructions)
        await msg.reply_text(
            f"📋 <b>Active AI Instructions</b> ({length} chars)\n\n"
            f"<pre>{preview}</pre>\n\n"
            f"<i>These directives are applied to every AI response.\n"
            f"<code>/instr delete</code> to remove · <code>/instr append &lt;text&gt;</code> to add more</i>",
            parse_mode="HTML",
        )
