"""
Salim Collaborative Document Editor — Real-time multi-user document editing via Telegram.

A complete live collaborative editing system. Multiple users can work on the same
document simultaneously, see each other's changes in real time, leave comments,
track revisions, and download the final document at any time.

Architecture:
  - Documents stored in ~/.salim/collab_docs/<doc_id>.json
  - Each document has: content (markdown), revision history, active editors,
    pending suggestions, comments, and access list
  - Changes broadcast to all connected users via Telegram messages
  - AI can suggest edits, rewrite sections, expand, summarise on command
  - Full revision history — roll back to any version

Commands:
  /collab new <title>              — Create a new collaborative document
  /collab list                     — List your documents
  /collab open <id>                — Open a document for editing
  /collab edit <id> <section> <new text>  — Edit a specific section
  /collab append <id> <text>       — Append text to the document
  /collab replace <id> <old> | <new>      — Replace text (pipe-separated)
  /collab view <id>                — View current document content
  /collab history <id>             — Show revision history
  /collab revert <id> <rev>        — Revert to a previous revision
  /collab share <id> @user         — Share with another Telegram user by ID
  /collab comment <id> <text>      — Add a comment
  /collab comments <id>            — View all comments
  /collab ai <id> <instruction>    — AI edits the document
  /collab export <id>              — Export as .docx or .txt
  /collab close <id>               — Close/archive a document
  /collab delete <id>              — Delete permanently
"""
from __future__ import annotations

import asyncio
import hashlib
import html
import json
import logging
import re
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import (
    InlineKeyboardButton, InlineKeyboardMarkup, Update
)
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.collab_doc")

COLLAB_DIR = Path.home() / ".salim" / "collab_docs"
MAX_REVISIONS = 50          # keep last 50 revisions per doc
BROADCAST_DELAY = 0.3       # seconds between broadcasts to avoid flood limits

HTML_MODE = "HTML"


def _esc(v) -> str:
    return html.escape(str(v), quote=False)


# ═══════════════════════════════════════════════════════════════════════════════
#  DATA MODEL
# ═══════════════════════════════════════════════════════════════════════════════

def _doc_path(doc_id: str) -> Path:
    COLLAB_DIR.mkdir(parents=True, mode=0o700, exist_ok=True)
    return COLLAB_DIR / f"{doc_id}.json"


def _generate_id(title: str) -> str:
    """Generate a short readable document ID."""
    slug = re.sub(r"[^a-z0-9]", "_", title.lower())[:20].strip("_")
    suffix = hashlib.md5(f"{title}{time.time()}".encode()).hexdigest()[:4]
    return f"{slug}_{suffix}" if slug else f"doc_{suffix}"


def load_doc(doc_id: str) -> Optional[dict]:
    path = _doc_path(doc_id)
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return None


def save_doc(doc: dict):
    path = _doc_path(doc["id"])
    path.write_text(json.dumps(doc, indent=2, ensure_ascii=False), encoding="utf-8")
    path.chmod(0o600)


def list_docs(user_id: int) -> list[dict]:
    """List all documents the user owns or has access to."""
    COLLAB_DIR.mkdir(parents=True, exist_ok=True)
    docs = []
    for p in sorted(COLLAB_DIR.glob("*.json")):
        try:
            d = json.loads(p.read_text(encoding="utf-8"))
            if d.get("owner") == user_id or user_id in d.get("collaborators", []):
                docs.append(d)
        except Exception:
            pass
    return docs


def create_doc(title: str, owner_id: int, owner_name: str) -> dict:
    doc_id = _generate_id(title)
    now = datetime.now().isoformat()
    doc = {
        "id": doc_id,
        "title": title,
        "owner": owner_id,
        "owner_name": owner_name,
        "collaborators": [],         # list of user_ids with edit access
        "collaborator_names": {},    # user_id → display name
        "content": f"# {title}\n\n*Created {datetime.now().strftime('%B %d, %Y')}*\n\n",
        "sections": {},              # section_name → text
        "comments": [],              # list of {user, text, ts, resolved}
        "revisions": [],             # list of {rev, user, ts, summary, snapshot}
        "active_editors": [],        # list of user_ids currently editing
        "created_at": now,
        "updated_at": now,
        "revision_count": 0,
        "archived": False,
    }
    # Save initial revision
    _push_revision(doc, owner_id, owner_name, "Document created")
    save_doc(doc)
    return doc


def _push_revision(doc: dict, user_id: int, user_name: str, summary: str):
    """Snapshot current content into revision history."""
    doc["revision_count"] = doc.get("revision_count", 0) + 1
    rev = {
        "rev": doc["revision_count"],
        "user_id": user_id,
        "user_name": user_name,
        "ts": datetime.now().isoformat(),
        "summary": summary,
        "snapshot": doc.get("content", ""),
    }
    revisions = doc.get("revisions", [])
    revisions.append(rev)
    # Keep only last MAX_REVISIONS
    if len(revisions) > MAX_REVISIONS:
        revisions = revisions[-MAX_REVISIONS:]
    doc["revisions"] = revisions
    doc["updated_at"] = datetime.now().isoformat()


def apply_edit(doc: dict, user_id: int, user_name: str,
               new_content: str, summary: str) -> dict:
    """Apply a content change, push a revision, return updated doc."""
    _push_revision(doc, user_id, user_name, summary)
    doc["content"] = new_content
    doc["updated_at"] = datetime.now().isoformat()
    save_doc(doc)
    return doc


def _format_doc_preview(doc: dict, max_chars: int = 800) -> str:
    """Format document for display in Telegram."""
    content = doc.get("content", "")
    if len(content) > max_chars:
        content = content[:max_chars] + "\n\n…*(truncated)*"
    return content


def _collab_list_string(doc: dict) -> str:
    """Bullet list of collaborators for display."""
    names = doc.get("collaborator_names", {})
    collabs = doc.get("collaborators", [])
    if not collabs:
        return "<i>No collaborators yet</i>"
    parts = []
    for uid in collabs:
        name = names.get(str(uid), str(uid))
        parts.append(f"• {_esc(name)}")
    return "\n".join(parts)


# ═══════════════════════════════════════════════════════════════════════════════
#  BROADCAST ENGINE  — notifies all editors when a change happens
# ═══════════════════════════════════════════════════════════════════════════════

# Active session: doc_id → {user_id → chat_id}
_active_sessions: dict[str, dict[int, int]] = {}


def register_editor(doc_id: str, user_id: int, chat_id: int):
    _active_sessions.setdefault(doc_id, {})[user_id] = chat_id


def unregister_editor(doc_id: str, user_id: int):
    if doc_id in _active_sessions:
        _active_sessions[doc_id].pop(user_id, None)


async def broadcast_change(bot, doc: dict, changed_by_id: int,
                           changed_by_name: str, change_summary: str,
                           show_diff: Optional[str] = None):
    """
    Send a live update notification to all active editors of a document
    (except the person who made the change).
    """
    doc_id = doc["id"]
    sessions = _active_sessions.get(doc_id, {})
    all_editors = set(sessions.keys()) | set(doc.get("collaborators", [])) | {doc.get("owner")}

    rev = doc.get("revision_count", 0)
    title = _esc(doc.get("title", doc_id))
    changer = _esc(changed_by_name)

    diff_section = ""
    if show_diff:
        diff_preview = _esc(show_diff[:300]) + ("…" if len(show_diff) > 300 else "")
        diff_section = f"\n\n📝 <i>Change preview:</i>\n<pre>{diff_preview}</pre>"

    notification = (
        f"📄 <b>{title}</b> — updated\n"
        f"✏️ <b>{changer}</b>: {_esc(change_summary)}\n"
        f"🔢 Revision #{rev}{diff_section}\n\n"
        f"<i>Use /collab view {_esc(doc_id)} to see current content</i>"
    )

    keyboard = InlineKeyboardMarkup([[
        InlineKeyboardButton("👁 View", callback_data=f"collab_view:{doc_id}"),
        InlineKeyboardButton("↩️ Revert", callback_data=f"collab_revert_pick:{doc_id}"),
    ]])

    for uid, chat_id in sessions.items():
        if uid == changed_by_id:
            continue
        try:
            await asyncio.sleep(BROADCAST_DELAY)
            await bot.send_message(
                chat_id=chat_id,
                text=notification,
                parse_mode=HTML_MODE,
                reply_markup=keyboard,
            )
        except Exception as e:
            logger.warning(f"Broadcast to {uid} failed: {e}")


# ═══════════════════════════════════════════════════════════════════════════════
#  AI EDIT ENGINE
# ═══════════════════════════════════════════════════════════════════════════════

async def ai_edit_document(salim_bot, doc: dict, instruction: str) -> tuple[str, str]:
    """
    Use the AI to edit a document given a natural language instruction.
    Returns (new_content, summary_of_change).
    """
    content = doc.get("content", "")
    title = doc.get("title", "Untitled")

    prompt = (
        f"You are editing a collaborative document titled '{title}'.\n\n"
        f"CURRENT DOCUMENT CONTENT:\n{content}\n\n"
        f"USER INSTRUCTION: {instruction}\n\n"
        f"Apply the instruction to edit the document. Return a JSON object with:\n"
        f"{{\"content\": \"<the full updated document content>\", "
        f"\"summary\": \"<brief one-line summary of what changed>\"}}\n\n"
        f"Rules:\n"
        f"- Return the COMPLETE document, not just the changed part\n"
        f"- Preserve existing structure and formatting\n"
        f"- Keep the document in Markdown format\n"
        f"- Summary must be short (under 60 chars)\n"
        f"- Return ONLY the JSON, nothing else"
    )

    try:
        from salim.ai import SalimAI
        ai = SalimAI(salim_bot.config)
        raw, provider = await ai._call_with_fallback(
            [{"role": "user", "content": prompt}],
            system="You are a professional document editor. Return only valid JSON.",
            max_tokens=2048,
            temperature=0.3,
        )
        raw = re.sub(r"```(?:json)?|```", "", raw).strip()
        data = json.loads(raw)
        new_content = data.get("content", content)
        summary = data.get("summary", f"AI edit: {instruction[:50]}")
        return new_content, summary
    except Exception as e:
        logger.error(f"AI doc edit failed: {e}")
        raise RuntimeError(f"AI edit failed: {e}")


# ═══════════════════════════════════════════════════════════════════════════════
#  BOT HANDLER MIXIN
# ═══════════════════════════════════════════════════════════════════════════════

class CollabDocHandlers:
    """Mixin for SalimBot — adds real-time collaborative document editing."""

    @require_auth
    async def cmd_collab(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /collab <subcommand> — Collaborative document editing
        Subcommands: new, list, open, edit, append, replace, view, history,
                     revert, share, comment, comments, ai, export, close, delete
        """
        msg = update.effective_message
        user = update.effective_user
        user_id = user.id
        user_name = user.full_name or user.username or str(user_id)
        args = ctx.args or []

        if not args:
            await self._collab_help(msg)
            return

        sub = args[0].lower()

        if sub == "new":
            title = " ".join(args[1:]) if len(args) > 1 else "Untitled Document"
            await self._collab_new(msg, user_id, user_name, title)

        elif sub == "list":
            await self._collab_list(msg, user_id)

        elif sub in ("open", "join"):
            if len(args) < 2:
                await msg.reply_text("Usage: <code>/collab open &lt;doc_id&gt;</code>", parse_mode=HTML_MODE)
                return
            await self._collab_open(msg, user_id, user_name, args[1])

        elif sub == "view":
            if len(args) < 2:
                await msg.reply_text("Usage: <code>/collab view &lt;doc_id&gt;</code>", parse_mode=HTML_MODE)
                return
            await self._collab_view(msg, args[1])

        elif sub == "edit":
            # /collab edit <id> <new full content or section edit>
            if len(args) < 3:
                await msg.reply_text(
                    "Usage: <code>/collab edit &lt;doc_id&gt; &lt;new content&gt;</code>\n"
                    "Or to replace inline: <code>/collab replace &lt;doc_id&gt; old text | new text</code>",
                    parse_mode=HTML_MODE,
                )
                return
            doc_id = args[1]
            new_content = " ".join(args[2:])
            await self._collab_edit_full(msg, update, user_id, user_name, doc_id, new_content)

        elif sub == "append":
            if len(args) < 3:
                await msg.reply_text("Usage: <code>/collab append &lt;doc_id&gt; &lt;text&gt;</code>", parse_mode=HTML_MODE)
                return
            doc_id = args[1]
            text = " ".join(args[2:])
            await self._collab_append(msg, update, user_id, user_name, doc_id, text)

        elif sub == "replace":
            if len(args) < 3:
                await msg.reply_text(
                    "Usage: <code>/collab replace &lt;doc_id&gt; old text | new text</code>\n"
                    "<i>Separate old and new with a pipe |</i>",
                    parse_mode=HTML_MODE,
                )
                return
            doc_id = args[1]
            rest = " ".join(args[2:])
            if "|" not in rest:
                await msg.reply_text("❌ Use <code>|</code> to separate old text from new text.", parse_mode=HTML_MODE)
                return
            old_text, new_text = rest.split("|", 1)
            await self._collab_replace(msg, update, user_id, user_name, doc_id,
                                       old_text.strip(), new_text.strip())

        elif sub == "history":
            if len(args) < 2:
                await msg.reply_text("Usage: <code>/collab history &lt;doc_id&gt;</code>", parse_mode=HTML_MODE)
                return
            await self._collab_history(msg, args[1])

        elif sub == "revert":
            if len(args) < 3:
                await msg.reply_text("Usage: <code>/collab revert &lt;doc_id&gt; &lt;revision_number&gt;</code>", parse_mode=HTML_MODE)
                return
            await self._collab_revert(msg, update, user_id, user_name, args[1], args[2])

        elif sub == "share":
            if len(args) < 3:
                await msg.reply_text("Usage: <code>/collab share &lt;doc_id&gt; &lt;user_id&gt;</code>", parse_mode=HTML_MODE)
                return
            await self._collab_share(msg, user_id, args[1], args[2])

        elif sub == "comment":
            if len(args) < 3:
                await msg.reply_text("Usage: <code>/collab comment &lt;doc_id&gt; &lt;your comment&gt;</code>", parse_mode=HTML_MODE)
                return
            doc_id = args[1]
            comment_text = " ".join(args[2:])
            await self._collab_add_comment(msg, update, user_id, user_name, doc_id, comment_text)

        elif sub == "comments":
            if len(args) < 2:
                await msg.reply_text("Usage: <code>/collab comments &lt;doc_id&gt;</code>", parse_mode=HTML_MODE)
                return
            await self._collab_view_comments(msg, args[1])

        elif sub == "ai":
            if len(args) < 3:
                await msg.reply_text(
                    "Usage: <code>/collab ai &lt;doc_id&gt; &lt;instruction&gt;</code>\n\n"
                    "<i>Examples:</i>\n"
                    "<code>/collab ai myresume_a1b2 make the summary more concise</code>\n"
                    "<code>/collab ai report_c3d4 add a conclusion section</code>\n"
                    "<code>/collab ai letter_e5f6 rewrite in a more formal tone</code>",
                    parse_mode=HTML_MODE,
                )
                return
            doc_id = args[1]
            instruction = " ".join(args[2:])
            await self._collab_ai_edit(msg, update, user_id, user_name, doc_id, instruction)

        elif sub == "export":
            if len(args) < 2:
                await msg.reply_text("Usage: <code>/collab export &lt;doc_id&gt;</code>", parse_mode=HTML_MODE)
                return
            await self._collab_export(msg, args[1])

        elif sub in ("close", "archive"):
            if len(args) < 2:
                await msg.reply_text("Usage: <code>/collab close &lt;doc_id&gt;</code>", parse_mode=HTML_MODE)
                return
            await self._collab_close(msg, user_id, args[1])

        elif sub == "delete":
            if len(args) < 2:
                await msg.reply_text("Usage: <code>/collab delete &lt;doc_id&gt;</code>", parse_mode=HTML_MODE)
                return
            await self._collab_delete(msg, user_id, args[1])

        else:
            await self._collab_help(msg)

    # ─── Sub-command implementations ──────────────────────────────────────────

    async def _collab_help(self, msg):
        await msg.reply_text(
            "📝 <b>Collaborative Document Editor</b>\n\n"
            "<b>Create &amp; Open:</b>\n"
            "  <code>/collab new My Project Report</code> — create doc\n"
            "  <code>/collab list</code>                 — your documents\n"
            "  <code>/collab open &lt;id&gt;</code>            — join/open a doc\n"
            "  <code>/collab view &lt;id&gt;</code>            — read current content\n\n"
            "<b>Edit:</b>\n"
            "  <code>/collab append &lt;id&gt; &lt;text&gt;</code>     — add text\n"
            "  <code>/collab edit &lt;id&gt; &lt;new content&gt;</code> — set full content\n"
            "  <code>/collab replace &lt;id&gt; old | new</code>  — find &amp; replace\n"
            "  <code>/collab ai &lt;id&gt; &lt;instruction&gt;</code>  — AI edits\n\n"
            "<b>Collaborate:</b>\n"
            "  <code>/collab share &lt;id&gt; &lt;user_id&gt;</code>   — grant access\n"
            "  <code>/collab comment &lt;id&gt; &lt;text&gt;</code>    — add comment\n"
            "  <code>/collab comments &lt;id&gt;</code>          — view comments\n\n"
            "<b>History &amp; Export:</b>\n"
            "  <code>/collab history &lt;id&gt;</code>           — revision log\n"
            "  <code>/collab revert &lt;id&gt; &lt;rev#&gt;</code>     — restore version\n"
            "  <code>/collab export &lt;id&gt;</code>            — download as file\n"
            "  <code>/collab close &lt;id&gt;</code>             — archive doc\n"
            "  <code>/collab delete &lt;id&gt;</code>            — delete doc",
            parse_mode=HTML_MODE,
        )

    async def _collab_new(self, msg, user_id: int, user_name: str, title: str):
        doc = create_doc(title, user_id, user_name)
        register_editor(doc["id"], user_id, msg.chat_id)

        keyboard = InlineKeyboardMarkup([[
            InlineKeyboardButton("📝 Start Editing", callback_data=f"collab_edit_prompt:{doc['id']}"),
            InlineKeyboardButton("👁 View", callback_data=f"collab_view:{doc['id']}"),
        ], [
            InlineKeyboardButton("🤖 AI Write", callback_data=f"collab_ai_prompt:{doc['id']}"),
            InlineKeyboardButton("📤 Export", callback_data=f"collab_export:{doc['id']}"),
        ]])

        await msg.reply_text(
            f"✅ <b>Document created!</b>\n\n"
            f"📄 <b>{_esc(title)}</b>\n"
            f"🆔 ID: <code>{_esc(doc['id'])}</code>\n"
            f"👤 Owner: {_esc(user_name)}\n\n"
            f"<b>Share this ID</b> with collaborators:\n"
            f"<code>/collab open {_esc(doc['id'])}</code>\n\n"
            f"<i>You will receive live notifications when collaborators make changes.</i>",
            parse_mode=HTML_MODE,
            reply_markup=keyboard,
        )

    async def _collab_list(self, msg, user_id: int):
        docs = list_docs(user_id)
        if not docs:
            await msg.reply_text(
                "📂 <b>No documents yet.</b>\n\n"
                "Create one: <code>/collab new My Document Title</code>",
                parse_mode=HTML_MODE,
            )
            return

        lines = [f"📂 <b>Your Documents ({len(docs)})</b>\n"]
        for doc in docs[:20]:
            archived = " 📦" if doc.get("archived") else ""
            owner_marker = "👤" if doc.get("owner") == user_id else "👥"
            rev = doc.get("revision_count", 0)
            updated = doc.get("updated_at", "")[:10]
            title = _esc(doc.get("title", "Untitled"))
            doc_id = _esc(doc["id"])
            collab_count = len(doc.get("collaborators", []))
            lines.append(
                f"{owner_marker} <b>{title}</b>{archived}\n"
                f"   🆔 <code>{doc_id}</code> · Rev#{rev} · {updated}"
                + (f" · 👥{collab_count}" if collab_count else "")
            )

        lines.append("\n<i>Use <code>/collab open &lt;id&gt;</code> to start editing</i>")
        await msg.reply_text("\n".join(lines), parse_mode=HTML_MODE)

    async def _collab_open(self, msg, user_id: int, user_name: str, doc_id: str):
        doc = load_doc(doc_id)
        if not doc:
            await msg.reply_text(f"❌ Document <code>{_esc(doc_id)}</code> not found.", parse_mode=HTML_MODE)
            return

        # Check access
        if doc.get("owner") != user_id and user_id not in doc.get("collaborators", []):
            await msg.reply_text(
                "🔒 <b>Access denied.</b>\n\n"
                "Ask the document owner to run:\n"
                f"<code>/collab share {_esc(doc_id)} {user_id}</code>",
                parse_mode=HTML_MODE,
            )
            return

        register_editor(doc_id, user_id, msg.chat_id)

        # Mark user as active editor
        active = doc.get("active_editors", [])
        if user_id not in active:
            active.append(user_id)
            doc["active_editors"] = active
            save_doc(doc)

        rev = doc.get("revision_count", 0)
        collabs = _collab_list_string(doc)
        owner_name = _esc(doc.get("owner_name", "Unknown"))
        content_preview = _esc(doc.get("content", "")[:400])

        keyboard = InlineKeyboardMarkup([[
            InlineKeyboardButton("📝 Edit (append)", callback_data=f"collab_edit_prompt:{doc_id}"),
            InlineKeyboardButton("🤖 AI Edit", callback_data=f"collab_ai_prompt:{doc_id}"),
        ], [
            InlineKeyboardButton("👁 Full View", callback_data=f"collab_view:{doc_id}"),
            InlineKeyboardButton("📜 History", callback_data=f"collab_history:{doc_id}"),
        ], [
            InlineKeyboardButton("💬 Comments", callback_data=f"collab_comments:{doc_id}"),
            InlineKeyboardButton("📤 Export", callback_data=f"collab_export:{doc_id}"),
        ]])

        await msg.reply_text(
            f"📄 <b>{_esc(doc['title'])}</b> — opened\n\n"
            f"👤 Owner: {owner_name} · Rev#{rev}\n"
            f"👥 Collaborators:\n{collabs}\n\n"
            f"<b>Content preview:</b>\n<pre>{content_preview}</pre>\n\n"
            f"<i>✅ You are now an active editor. You'll receive live change notifications.</i>",
            parse_mode=HTML_MODE,
            reply_markup=keyboard,
        )

        # Notify other editors that this user joined
        await broadcast_change(
            msg.bot if hasattr(msg, 'bot') else self._get_bot(),
            doc, user_id, user_name,
            f"{user_name} joined the document",
        )

    async def _collab_view(self, msg, doc_id: str):
        doc = load_doc(doc_id)
        if not doc:
            await msg.reply_text(f"❌ Document not found: <code>{_esc(doc_id)}</code>", parse_mode=HTML_MODE)
            return

        content = doc.get("content", "")
        title = _esc(doc.get("title", "Untitled"))
        rev = doc.get("revision_count", 0)
        updated = doc.get("updated_at", "")[:16]
        comment_count = len(doc.get("comments", []))
        active_count = len(doc.get("active_editors", []))

        # Split into chunks if large
        chunks = []
        chunk_size = 3800
        if len(content) <= chunk_size:
            chunks = [content]
        else:
            # Split at newlines
            lines = content.split("\n")
            current = ""
            for line in lines:
                if len(current) + len(line) + 1 > chunk_size:
                    chunks.append(current)
                    current = line + "\n"
                else:
                    current += line + "\n"
            if current:
                chunks.append(current)

        keyboard = InlineKeyboardMarkup([[
            InlineKeyboardButton("📝 Edit", callback_data=f"collab_edit_prompt:{doc_id}"),
            InlineKeyboardButton("🤖 AI Edit", callback_data=f"collab_ai_prompt:{doc_id}"),
        ], [
            InlineKeyboardButton("📜 History", callback_data=f"collab_history:{doc_id}"),
            InlineKeyboardButton("📤 Export", callback_data=f"collab_export:{doc_id}"),
        ]])

        header = (
            f"📄 <b>{title}</b> — Rev#{rev}\n"
            f"🕐 {updated} · 💬 {comment_count} comments"
            + (f" · ✏️ {active_count} editing" if active_count > 0 else "")
            + "\n\n"
        )

        for i, chunk in enumerate(chunks):
            text = header + f"<pre>{_esc(chunk)}</pre>" if i == 0 else f"<pre>{_esc(chunk)}</pre>"
            if i == len(chunks) - 1:
                await msg.reply_text(text, parse_mode=HTML_MODE, reply_markup=keyboard)
            else:
                await msg.reply_text(text, parse_mode=HTML_MODE)

    async def _collab_edit_full(self, msg, update, user_id: int, user_name: str,
                                 doc_id: str, new_content: str):
        doc = load_doc(doc_id)
        if not doc:
            await msg.reply_text(f"❌ Document not found: <code>{_esc(doc_id)}</code>", parse_mode=HTML_MODE)
            return
        if not self._collab_can_edit(doc, user_id):
            await msg.reply_text("🔒 You don't have edit access to this document.", parse_mode=HTML_MODE)
            return

        old_content = doc.get("content", "")
        apply_edit(doc, user_id, user_name, new_content, f"Manual edit by {user_name}")
        register_editor(doc_id, user_id, msg.chat_id)

        await msg.reply_text(
            f"✅ <b>Document updated</b> — Rev#{doc['revision_count']}\n"
            f"<i>{_esc(doc['title'])}</i>",
            parse_mode=HTML_MODE,
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("👁 View", callback_data=f"collab_view:{doc_id}"),
                InlineKeyboardButton("↩️ Revert", callback_data=f"collab_revert_pick:{doc_id}"),
            ]]),
        )

        # Compute a simple diff summary
        added = max(0, len(new_content) - len(old_content))
        removed = max(0, len(old_content) - len(new_content))
        diff_hint = f"+{added}/-{removed} chars"
        await broadcast_change(
            update.get_bot() if hasattr(update, 'get_bot') else msg.bot,
            doc, user_id, user_name,
            f"Manual edit ({diff_hint})",
            show_diff=new_content[:200],
        )

    async def _collab_append(self, msg, update, user_id: int, user_name: str,
                              doc_id: str, text: str):
        doc = load_doc(doc_id)
        if not doc:
            await msg.reply_text(f"❌ Document not found: <code>{_esc(doc_id)}</code>", parse_mode=HTML_MODE)
            return
        if not self._collab_can_edit(doc, user_id):
            await msg.reply_text("🔒 You don't have edit access.", parse_mode=HTML_MODE)
            return

        new_content = doc.get("content", "").rstrip() + "\n\n" + text
        apply_edit(doc, user_id, user_name, new_content, f"Appended text by {user_name}")
        register_editor(doc_id, user_id, msg.chat_id)

        await msg.reply_text(
            f"✅ <b>Text appended</b> — Rev#{doc['revision_count']}\n"
            f"<code>+{len(text)} chars</code>",
            parse_mode=HTML_MODE,
        )
        await broadcast_change(
            msg.bot,
            doc, user_id, user_name,
            f"Appended: {text[:60]}{'…' if len(text) > 60 else ''}",
            show_diff=text,
        )

    async def _collab_replace(self, msg, update, user_id: int, user_name: str,
                               doc_id: str, old_text: str, new_text: str):
        doc = load_doc(doc_id)
        if not doc:
            await msg.reply_text(f"❌ Document not found: <code>{_esc(doc_id)}</code>", parse_mode=HTML_MODE)
            return
        if not self._collab_can_edit(doc, user_id):
            await msg.reply_text("🔒 You don't have edit access.", parse_mode=HTML_MODE)
            return

        content = doc.get("content", "")
        if old_text not in content:
            await msg.reply_text(
                f"❌ Text not found in document:\n<code>{_esc(old_text[:200])}</code>\n\n"
                "<i>Check the exact wording and try again.</i>",
                parse_mode=HTML_MODE,
            )
            return

        occurrences = content.count(old_text)
        new_content = content.replace(old_text, new_text)
        apply_edit(doc, user_id, user_name, new_content,
                   f"Replace '{old_text[:30]}' → '{new_text[:30]}' ({occurrences} occurrence{'s' if occurrences > 1 else ''})")
        register_editor(doc_id, user_id, msg.chat_id)

        await msg.reply_text(
            f"✅ <b>Text replaced</b> ({occurrences} occurrence{'s' if occurrences > 1 else ''}) — Rev#{doc['revision_count']}\n"
            f"<s>{_esc(old_text[:80])}</s>\n➡️ {_esc(new_text[:80])}",
            parse_mode=HTML_MODE,
        )
        await broadcast_change(
            msg.bot, doc, user_id, user_name,
            f"Replace: '{old_text[:40]}' → '{new_text[:40]}'",
            show_diff=f"Replaced: {old_text[:100]} → {new_text[:100]}",
        )

    async def _collab_history(self, msg, doc_id: str):
        doc = load_doc(doc_id)
        if not doc:
            await msg.reply_text(f"❌ Document not found: <code>{_esc(doc_id)}</code>", parse_mode=HTML_MODE)
            return

        revisions = doc.get("revisions", [])
        if not revisions:
            await msg.reply_text("📜 No revisions yet.", parse_mode=HTML_MODE)
            return

        lines = [f"📜 <b>Revision History — {_esc(doc['title'])}</b>\n"]
        for rev in reversed(revisions[-20:]):
            ts = rev.get("ts", "")[:16]
            user = _esc(rev.get("user_name", "?"))
            summary = _esc(rev.get("summary", ""))
            rev_num = rev.get("rev", "?")
            lines.append(f"<b>Rev#{rev_num}</b> · {ts}\n   ✏️ {user}: {summary}")

        lines.append(f"\n<i>Use <code>/collab revert {_esc(doc_id)} &lt;rev#&gt;</code> to restore a version</i>")
        await msg.reply_text("\n".join(lines), parse_mode=HTML_MODE)

    async def _collab_revert(self, msg, update, user_id: int, user_name: str,
                              doc_id: str, rev_str: str):
        doc = load_doc(doc_id)
        if not doc:
            await msg.reply_text(f"❌ Document not found: <code>{_esc(doc_id)}</code>", parse_mode=HTML_MODE)
            return
        if not self._collab_can_edit(doc, user_id):
            await msg.reply_text("🔒 You don't have edit access.", parse_mode=HTML_MODE)
            return

        try:
            rev_num = int(rev_str)
        except ValueError:
            await msg.reply_text("❌ Revision number must be an integer.", parse_mode=HTML_MODE)
            return

        target_rev = None
        for rev in doc.get("revisions", []):
            if rev.get("rev") == rev_num:
                target_rev = rev
                break

        if not target_rev:
            await msg.reply_text(
                f"❌ Revision #{rev_num} not found.\n"
                f"Use <code>/collab history {_esc(doc_id)}</code> to see available revisions.",
                parse_mode=HTML_MODE,
            )
            return

        snapshot = target_rev.get("snapshot", "")
        apply_edit(doc, user_id, user_name, snapshot,
                   f"Reverted to Rev#{rev_num} by {user_name}")

        await msg.reply_text(
            f"↩️ <b>Reverted to Rev#{rev_num}</b>\n"
            f"New revision: Rev#{doc['revision_count']}\n"
            f"<i>Original author: {_esc(target_rev.get('user_name', '?'))} @ {target_rev.get('ts', '')[:16]}</i>",
            parse_mode=HTML_MODE,
        )
        await broadcast_change(
            msg.bot, doc, user_id, user_name,
            f"Reverted to Rev#{rev_num}",
        )

    async def _collab_share(self, msg, owner_id: int, doc_id: str, target_str: str):
        doc = load_doc(doc_id)
        if not doc:
            await msg.reply_text(f"❌ Document not found: <code>{_esc(doc_id)}</code>", parse_mode=HTML_MODE)
            return
        if doc.get("owner") != owner_id:
            await msg.reply_text("🔒 Only the document owner can share it.", parse_mode=HTML_MODE)
            return

        # Parse target user ID
        target_str = target_str.lstrip("@")
        try:
            target_id = int(target_str)
        except ValueError:
            await msg.reply_text(
                "❌ Please provide the Telegram user ID (numeric).\n"
                "<i>The user can find their ID by messaging @userinfobot</i>",
                parse_mode=HTML_MODE,
            )
            return

        collaborators = doc.get("collaborators", [])
        if target_id not in collaborators:
            collaborators.append(target_id)
            doc["collaborators"] = collaborators
            save_doc(doc)

        await msg.reply_text(
            f"✅ <b>Access granted</b>\n\n"
            f"User <code>{target_id}</code> can now edit <b>{_esc(doc['title'])}</b>.\n\n"
            f"Tell them to run:\n"
            f"<code>/collab open {_esc(doc_id)}</code>",
            parse_mode=HTML_MODE,
        )

    async def _collab_add_comment(self, msg, update, user_id: int, user_name: str,
                                   doc_id: str, text: str):
        doc = load_doc(doc_id)
        if not doc:
            await msg.reply_text(f"❌ Document not found: <code>{_esc(doc_id)}</code>", parse_mode=HTML_MODE)
            return
        if not self._collab_can_edit(doc, user_id):
            await msg.reply_text("🔒 You don't have access to this document.", parse_mode=HTML_MODE)
            return

        comment = {
            "id": len(doc.get("comments", [])) + 1,
            "user_id": user_id,
            "user_name": user_name,
            "text": text,
            "ts": datetime.now().isoformat(),
            "resolved": False,
        }
        comments = doc.get("comments", [])
        comments.append(comment)
        doc["comments"] = comments
        save_doc(doc)

        await msg.reply_text(
            f"💬 <b>Comment added</b> (#{comment['id']})\n\n"
            f"<i>{_esc(text)}</i>",
            parse_mode=HTML_MODE,
        )

        # Notify collaborators
        await broadcast_change(
            msg.bot, doc, user_id, user_name,
            f"Comment: {text[:60]}{'…' if len(text) > 60 else ''}",
        )

    async def _collab_view_comments(self, msg, doc_id: str):
        doc = load_doc(doc_id)
        if not doc:
            await msg.reply_text(f"❌ Document not found: <code>{_esc(doc_id)}</code>", parse_mode=HTML_MODE)
            return

        comments = doc.get("comments", [])
        if not comments:
            await msg.reply_text("💬 No comments yet.", parse_mode=HTML_MODE)
            return

        lines = [f"💬 <b>Comments — {_esc(doc['title'])}</b>\n"]
        for c in comments:
            status = "✅" if c.get("resolved") else "🔵"
            ts = c.get("ts", "")[:16]
            lines.append(
                f"{status} <b>#{c['id']}</b> · {_esc(c.get('user_name', '?'))} · {ts}\n"
                f"   {_esc(c.get('text', ''))}"
            )
        await msg.reply_text("\n".join(lines), parse_mode=HTML_MODE)

    async def _collab_ai_edit(self, msg, update, user_id: int, user_name: str,
                               doc_id: str, instruction: str):
        doc = load_doc(doc_id)
        if not doc:
            await msg.reply_text(f"❌ Document not found: <code>{_esc(doc_id)}</code>", parse_mode=HTML_MODE)
            return
        if not self._collab_can_edit(doc, user_id):
            await msg.reply_text("🔒 You don't have edit access.", parse_mode=HTML_MODE)
            return

        thinking = await msg.reply_text(
            f"🤖 <i>AI editing document…</i>\n<b>Instruction:</b> {_esc(instruction[:100])}",
            parse_mode=HTML_MODE,
        )

        try:
            new_content, summary = await ai_edit_document(self, doc, instruction)
        except Exception as e:
            await thinking.edit_text(
                f"❌ AI edit failed: <code>{_esc(str(e))}</code>",
                parse_mode=HTML_MODE,
            )
            return

        apply_edit(doc, user_id, user_name, new_content, f"AI: {summary}")
        register_editor(doc_id, user_id, msg.chat_id)

        preview = _esc(new_content[:400]) + ("…" if len(new_content) > 400 else "")

        await thinking.edit_text(
            f"✅ <b>AI edit applied</b> — Rev#{doc['revision_count']}\n"
            f"<b>Change:</b> {_esc(summary)}\n\n"
            f"<b>Preview:</b>\n<pre>{preview}</pre>",
            parse_mode=HTML_MODE,
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("👁 Full View", callback_data=f"collab_view:{doc_id}"),
                InlineKeyboardButton("↩️ Undo", callback_data=f"collab_revert_prev:{doc_id}"),
            ]]),
        )

        await broadcast_change(
            msg.bot, doc, user_id, user_name,
            f"AI edit: {summary}",
            show_diff=new_content[:300],
        )

    async def _collab_export(self, msg, doc_id: str):
        doc = load_doc(doc_id)
        if not doc:
            await msg.reply_text(f"❌ Document not found: <code>{_esc(doc_id)}</code>", parse_mode=HTML_MODE)
            return

        content = doc.get("content", "")
        title = doc.get("title", "document")
        safe_title = re.sub(r"[^\w\s-]", "", title)[:40].strip()

        # Export as .txt
        import io as _io
        txt_buf = _io.BytesIO(content.encode("utf-8"))
        txt_buf.name = f"{safe_title}.txt"

        keyboard = InlineKeyboardMarkup([[
            InlineKeyboardButton("📄 Export as DOCX", callback_data=f"collab_export_docx:{doc_id}"),
        ]])

        await msg.reply_document(
            document=txt_buf,
            filename=f"{safe_title}.txt",
            caption=(
                f"📄 <b>{_esc(title)}</b>\n"
                f"Rev#{doc.get('revision_count', 0)} · "
                f"{len(content):,} chars · "
                f"{doc.get('updated_at', '')[:10]}"
            ),
            parse_mode=HTML_MODE,
            reply_markup=keyboard,
        )

    async def _collab_close(self, msg, user_id: int, doc_id: str):
        doc = load_doc(doc_id)
        if not doc:
            await msg.reply_text(f"❌ Document not found.", parse_mode=HTML_MODE)
            return
        if doc.get("owner") != user_id:
            await msg.reply_text("🔒 Only the owner can close a document.", parse_mode=HTML_MODE)
            return
        doc["archived"] = True
        doc["active_editors"] = []
        save_doc(doc)
        unregister_editor(doc_id, user_id)
        await msg.reply_text(
            f"📦 <b>Document archived:</b> {_esc(doc['title'])}\n"
            f"<i>It remains accessible but is marked as closed.</i>",
            parse_mode=HTML_MODE,
        )

    async def _collab_delete(self, msg, user_id: int, doc_id: str):
        doc = load_doc(doc_id)
        if not doc:
            await msg.reply_text(f"❌ Document not found.", parse_mode=HTML_MODE)
            return
        if doc.get("owner") != user_id:
            await msg.reply_text("🔒 Only the owner can delete a document.", parse_mode=HTML_MODE)
            return
        keyboard = InlineKeyboardMarkup([[
            InlineKeyboardButton("🗑️ Yes, delete permanently",
                                 callback_data=f"collab_delete_confirm:{doc_id}"),
            InlineKeyboardButton("❌ Cancel", callback_data="collab_cancel"),
        ]])
        await msg.reply_text(
            f"⚠️ <b>Delete '{_esc(doc['title'])}'?</b>\n\n"
            f"This will permanently delete the document and all {doc.get('revision_count', 0)} revisions.\n"
            f"<i>This cannot be undone.</i>",
            parse_mode=HTML_MODE,
            reply_markup=keyboard,
        )

    # ─── Callback handler ─────────────────────────────────────────────────────

    async def handle_collab_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        data = query.data or ""
        user_id = update.effective_user.id
        user_name = update.effective_user.full_name or str(user_id)

        if data == "collab_cancel":
            try:
                await query.edit_message_text("❌ Cancelled.")
            except Exception:
                pass
            return

        if data.startswith("collab_view:"):
            doc_id = data[12:]
            ctx.args = ["view", doc_id]
            await self.cmd_collab(update, ctx)
            return

        if data.startswith("collab_history:"):
            doc_id = data[15:]
            ctx.args = ["history", doc_id]
            await self.cmd_collab(update, ctx)
            return

        if data.startswith("collab_comments:"):
            doc_id = data[16:]
            ctx.args = ["comments", doc_id]
            await self.cmd_collab(update, ctx)
            return

        if data.startswith("collab_export:"):
            doc_id = data[14:]
            ctx.args = ["export", doc_id]
            await self.cmd_collab(update, ctx)
            return

        if data.startswith("collab_export_docx:"):
            doc_id = data[19:]
            await self._collab_export_docx(query, doc_id)
            return

        if data.startswith("collab_edit_prompt:"):
            doc_id = data[19:]
            await query.edit_message_text(
                f"✏️ <b>Edit Document</b>\n\n"
                f"Send your text as a message to append it to the document:\n\n"
                f"<code>/collab append {_esc(doc_id)} your text here</code>\n\n"
                f"Or to replace specific text:\n"
                f"<code>/collab replace {_esc(doc_id)} old text | new text</code>\n\n"
                f"Or to set the full content:\n"
                f"<code>/collab edit {_esc(doc_id)} full new content here</code>",
                parse_mode=HTML_MODE,
            )
            return

        if data.startswith("collab_ai_prompt:"):
            doc_id = data[17:]
            await query.edit_message_text(
                f"🤖 <b>AI Edit</b>\n\n"
                f"Tell the AI what to do with the document:\n\n"
                f"<code>/collab ai {_esc(doc_id)} make it more concise</code>\n"
                f"<code>/collab ai {_esc(doc_id)} add an introduction section</code>\n"
                f"<code>/collab ai {_esc(doc_id)} fix grammar and spelling</code>\n"
                f"<code>/collab ai {_esc(doc_id)} rewrite in a formal tone</code>",
                parse_mode=HTML_MODE,
            )
            return

        if data.startswith("collab_revert_prev:"):
            doc_id = data[19:]
            doc = load_doc(doc_id)
            if not doc:
                await query.edit_message_text("❌ Document not found.")
                return
            revisions = doc.get("revisions", [])
            if len(revisions) < 2:
                await query.edit_message_text("❌ No previous revision to revert to.")
                return
            prev_rev = revisions[-2]  # second to last
            snapshot = prev_rev.get("snapshot", "")
            apply_edit(doc, user_id, user_name, snapshot,
                       f"Undo: reverted to Rev#{prev_rev['rev']}")
            await query.edit_message_text(
                f"↩️ <b>Undone</b> — restored Rev#{prev_rev['rev']}\n"
                f"New revision: Rev#{doc['revision_count']}",
                parse_mode=HTML_MODE,
            )
            await broadcast_change(
                query.bot, doc, user_id, user_name,
                f"Undid last change (reverted to Rev#{prev_rev['rev']})",
            )
            return

        if data.startswith("collab_revert_pick:"):
            doc_id = data[19:]
            doc = load_doc(doc_id)
            if not doc:
                await query.edit_message_text("❌ Document not found.")
                return
            revisions = doc.get("revisions", [])[-10:]
            buttons = []
            for rev in reversed(revisions[:-1]):  # skip current
                ts = rev.get("ts", "")[:10]
                label = f"Rev#{rev['rev']} — {ts} — {rev.get('summary', '')[:25]}"
                buttons.append([InlineKeyboardButton(
                    label,
                    callback_data=f"collab_revert_do:{doc_id}:{rev['rev']}"
                )])
            buttons.append([InlineKeyboardButton("❌ Cancel", callback_data="collab_cancel")])
            await query.edit_message_text(
                f"↩️ <b>Revert to which revision?</b>",
                parse_mode=HTML_MODE,
                reply_markup=InlineKeyboardMarkup(buttons),
            )
            return

        if data.startswith("collab_revert_do:"):
            parts = data[17:].split(":", 1)
            doc_id, rev_str = parts[0], parts[1]
            doc = load_doc(doc_id)
            if not doc:
                await query.edit_message_text("❌ Document not found.")
                return
            rev_num = int(rev_str)
            target = next((r for r in doc.get("revisions", []) if r.get("rev") == rev_num), None)
            if not target:
                await query.edit_message_text(f"❌ Revision #{rev_num} not found.")
                return
            apply_edit(doc, user_id, user_name, target["snapshot"],
                       f"Reverted to Rev#{rev_num}")
            await query.edit_message_text(
                f"↩️ <b>Reverted to Rev#{rev_num}</b> — New: Rev#{doc['revision_count']}",
                parse_mode=HTML_MODE,
            )
            await broadcast_change(
                query.bot, doc, user_id, user_name,
                f"Reverted to Rev#{rev_num}",
            )
            return

        if data.startswith("collab_delete_confirm:"):
            doc_id = data[22:]
            doc = load_doc(doc_id)
            if not doc or doc.get("owner") != user_id:
                await query.edit_message_text("❌ Not authorized.")
                return
            _doc_path(doc_id).unlink(missing_ok=True)
            await query.edit_message_text(
                f"🗑️ Document deleted permanently.",
                parse_mode=HTML_MODE,
            )
            return

    async def _collab_export_docx(self, query, doc_id: str):
        """Export document as a proper .docx file."""
        doc = load_doc(doc_id)
        if not doc:
            await query.edit_message_text("❌ Document not found.")
            return

        await query.edit_message_text("⏳ <i>Generating DOCX…</i>", parse_mode=HTML_MODE)

        content = doc.get("content", "")
        title = doc.get("title", "Document")

        # Use document_writer infrastructure to create a real docx
        try:
            import tempfile, subprocess, sys, os, json as _json
            safe_title = re.sub(r"[^\w\s-]", "", title)[:40].strip()
            tmpdir = Path(tempfile.mkdtemp())
            out_path = tmpdir / f"{safe_title}.docx"

            # Build a Node.js script to create the docx
            js = _build_collab_docx_js(title, content, doc)
            js_path = tmpdir / "build.js"
            js_path.write_text(js)
            data_path = tmpdir / "data.json"

            result = subprocess.run(
                ["node", str(js_path), str(out_path)],
                capture_output=True, text=True, timeout=30,
                cwd=str(tmpdir),
            )

            if result.returncode == 0 and out_path.exists():
                import io as _io
                file_bytes = out_path.read_bytes()
                buf = _io.BytesIO(file_bytes)
                buf.name = f"{safe_title}.docx"
                await query.message.reply_document(
                    document=buf,
                    filename=f"{safe_title}.docx",
                    caption=(
                        f"📄 <b>{_esc(title)}</b>\n"
                        f"Rev#{doc.get('revision_count', 0)} · {len(file_bytes)/1024:.1f} KB"
                    ),
                    parse_mode=HTML_MODE,
                )
                await query.edit_message_text(
                    f"✅ DOCX exported: <b>{_esc(safe_title)}.docx</b>",
                    parse_mode=HTML_MODE,
                )
            else:
                # Fallback: send as txt
                raise RuntimeError(result.stderr[:200] if result.stderr else "node failed")

        except Exception as e:
            logger.error(f"DOCX export failed: {e}")
            # Fallback to txt
            import io as _io
            buf = _io.BytesIO(content.encode("utf-8"))
            safe_title2 = re.sub(r"[^\w\s-]", "", title)[:40].strip()
            buf.name = f"{safe_title2}.txt"
            await query.message.reply_document(
                document=buf,
                filename=f"{safe_title2}.txt",
                caption=f"📄 {_esc(title)} (exported as TXT — DOCX unavailable)",
                parse_mode=HTML_MODE,
            )
            await query.edit_message_text(
                f"📄 Exported as TXT <i>(install Node.js for DOCX support)</i>",
                parse_mode=HTML_MODE,
            )

    def _collab_can_edit(self, doc: dict, user_id: int) -> bool:
        return (doc.get("owner") == user_id or
                user_id in doc.get("collaborators", []))

    def _get_bot(self):
        """Helper to get the bot instance from app."""
        if hasattr(self, "_app") and self._app:
            return self._app.bot
        return None


# ─── DOCX builder for collab docs ─────────────────────────────────────────────

def _build_collab_docx_js(title: str, content: str, doc: dict) -> str:
    """Generate a Node.js script that creates a .docx from markdown-ish content."""
    title_json = json.dumps(title)
    owner_json = json.dumps(doc.get("owner_name", "Unknown"))
    date_str = doc.get("updated_at", datetime.now().isoformat())[:10]
    rev = doc.get("revision_count", 0)

    # Parse markdown content into sections
    lines = content.split("\n")
    paragraphs_json = json.dumps(lines)

    return f"""
const {{ Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
        BorderStyle }} = require('docx');
const fs = require('fs');

const outPath = process.argv[2] || 'output.docx';
const title = {title_json};
const author = {owner_json};
const date = '{date_str}';
const rev = {rev};
const lines = {paragraphs_json};

function parseLines(lines) {{
  return lines.map(line => {{
    if (line.startsWith('# ')) {{
      return new Paragraph({{
        text: line.slice(2),
        heading: HeadingLevel.HEADING_1,
        spacing: {{ before: 400, after: 200 }},
      }});
    }} else if (line.startsWith('## ')) {{
      return new Paragraph({{
        text: line.slice(3),
        heading: HeadingLevel.HEADING_2,
        spacing: {{ before: 300, after: 150 }},
      }});
    }} else if (line.startsWith('### ')) {{
      return new Paragraph({{
        text: line.slice(4),
        heading: HeadingLevel.HEADING_3,
        spacing: {{ before: 240, after: 120 }},
      }});
    }} else if (line.startsWith('- ') || line.startsWith('* ')) {{
      return new Paragraph({{
        text: line.slice(2),
        bullet: {{ level: 0 }},
      }});
    }} else if (line.trim() === '') {{
      return new Paragraph({{ text: '', spacing: {{ after: 80 }} }});
    }} else {{
      // Handle **bold** and *italic* inline
      const runs = [];
      let remaining = line;
      // Strip markdown italic/bold markers for simplicity
      remaining = remaining.replace(/\\*\\*(.+?)\\*\\*/g, '$1');
      remaining = remaining.replace(/\\*(.+?)\\*/g, '$1');
      remaining = remaining.replace(/_(.+?)_/g, '$1');
      runs.push(new TextRun({{ text: remaining, size: 24 }}));
      return new Paragraph({{ children: runs, spacing: {{ after: 120 }} }});
    }}
  }});
}}

async function main() {{
  const doc = new Document({{
    sections: [{{
      properties: {{
        page: {{
          margin: {{ top: 1440, right: 1440, bottom: 1440, left: 1440 }},
        }},
      }},
      children: [
        new Paragraph({{
          children: [new TextRun({{ text: title, bold: true, size: 36, color: '1F3864' }})],
          alignment: AlignmentType.CENTER,
          spacing: {{ after: 120 }},
        }}),
        new Paragraph({{
          children: [new TextRun({{ text: `Author: ${{author}} | Rev#${{rev}} | ${{date}}`, size: 18, color: '666666' }})],
          alignment: AlignmentType.CENTER,
          spacing: {{ after: 400 }},
          border: {{ bottom: {{ style: BorderStyle.SINGLE, size: 6, color: '2E74B5' }} }},
        }}),
        ...parseLines(lines),
      ],
    }}],
  }});

  const buffer = await Packer.toBuffer(doc);
  fs.writeFileSync(outPath, buffer);
  console.log('OK');
}}

main().catch(e => {{ console.error(e.message); process.exit(1); }});
"""
