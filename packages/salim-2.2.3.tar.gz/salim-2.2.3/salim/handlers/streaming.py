"""
Salim Streaming Handler v19 — Real-time AI response streaming to Telegram

Since Telegram doesn't support true streaming, we simulate it by:
1. Sending a placeholder "thinking" message
2. Updating it every ~1.5s with accumulated chunks
3. Giving user real-time feedback on long AI responses

Usage in other handlers:
    from salim.handlers.streaming import stream_ai_response

    await stream_ai_response(
        msg=update.effective_message,
        prompt="Your prompt here",
        ai=self._ai,
        system="Your system prompt",
        prefix="🤖 "
    )

Also adds /stream_chat command for direct streaming conversation.
"""
from __future__ import annotations

import asyncio
import html
import logging
import time
from typing import Optional, AsyncIterator

from telegram import Message, Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.streaming")
esc = lambda v: html.escape(str(v), quote=False)
H = "HTML"

# Typing indicator chars (rotates while streaming)
_SPINNERS = ["⣾", "⣽", "⣻", "⢿", "⡿", "⣟", "⣯", "⣷"]


async def stream_ai_response(
    msg: Message,
    ai,
    messages: list[dict],
    system: str = "",
    prefix: str = "",
    update_interval: float = 1.5,
    max_tokens: int = 800,
) -> str:
    """
    Stream an AI response to a Telegram message by polling edits.

    Strategy:
    - Send "thinking" message
    - Start AI call (non-streaming, but with intermediate token simulation)
    - For providers that support streaming (NVIDIA NIM, Groq): stream chunks
    - For non-streaming: show animated progress then reveal result
    
    Returns the full response text.
    """
    thinking = await msg.reply_text(
        f"{prefix}⣾ <i>Thinking…</i>",
        parse_mode=H,
    )

    full_text = ""
    spinner_idx = 0
    last_edit = time.time()
    start_time = time.time()

    async def _try_streaming_call() -> AsyncIterator[str]:
        """Attempt streaming call; fall back to one-shot."""
        try:
            # Try streaming via NVIDIA NIM / Groq (OpenAI-compatible stream)
            import httpx
            provider = None
            api_key = None
            base_url = None
            model = None

            nvidia_key = getattr(ai.config, "nvidia_api_key", "") or ai.config.get("SALIM_NVIDIA_API_KEY", "")
            groq_key = getattr(ai.config, "groq_api_key", "") or ai.config.get("SALIM_GROQ_API_KEY", "")

            if nvidia_key:
                api_key = nvidia_key
                base_url = "https://integrate.api.nvidia.com/v1"
                model = ai.config.get("SALIM_NVIDIA_MODEL", "meta/llama-4-maverick-17b-128e-instruct")
                provider = "nvidia"
            elif groq_key:
                api_key = groq_key
                base_url = "https://api.groq.com/openai/v1"
                model = ai.config.get("SALIM_GROQ_MODEL", "llama3-8b-8192")
                provider = "groq"

            if not api_key:
                return

            payload = {
                "model": model,
                "messages": ([{"role": "system", "content": system}] if system else []) + messages,
                "max_tokens": max_tokens,
                "stream": True,
            }

            async with httpx.AsyncClient(timeout=60) as client:
                async with client.stream(
                    "POST",
                    f"{base_url}/chat/completions",
                    json=payload,
                    headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                ) as response:
                    if response.status_code != 200:
                        return
                    async for line in response.aiter_lines():
                        if line.startswith("data: ") and line != "data: [DONE]":
                            try:
                                import json
                                chunk = json.loads(line[6:])
                                delta = chunk["choices"][0]["delta"].get("content", "")
                                if delta:
                                    yield delta
                            except Exception:
                                pass
        except Exception as e:
            logger.debug(f"Streaming failed: {e}")
            return

    # Try streaming first
    streamed = False
    accumulated = ""
    async for chunk in _try_streaming_call():
        streamed = True
        accumulated += chunk
        full_text = accumulated
        now = time.time()
        if now - last_edit >= update_interval:
            spinner = _SPINNERS[spinner_idx % len(_SPINNERS)]
            spinner_idx += 1
            last_edit = now
            preview = esc(accumulated[:3000])
            try:
                await thinking.edit_text(
                    f"{prefix}{preview}{spinner}",
                    parse_mode=H,
                )
            except Exception:
                pass

    if not streamed:
        # Non-streaming fallback with animated progress
        async def _animate():
            nonlocal spinner_idx
            while True:
                await asyncio.sleep(update_interval)
                spinner = _SPINNERS[spinner_idx % len(_SPINNERS)]
                spinner_idx += 1
                elapsed = int(time.time() - start_time)
                try:
                    await thinking.edit_text(
                        f"{prefix}⏳ <i>Thinking… {elapsed}s {spinner}</i>",
                        parse_mode=H,
                    )
                except Exception:
                    break

        anim_task = asyncio.create_task(_animate())
        try:
            full_text, _ = await ai._call_with_fallback(
                messages,
                system=system,
                max_tokens=max_tokens,
            )
        finally:
            anim_task.cancel()
            try:
                await anim_task
            except asyncio.CancelledError:
                pass

    # Final edit with full response
    elapsed = round(time.time() - start_time, 1)
    final = esc(full_text[:4000]) if full_text else "⚠️ No response."
    try:
        await thinking.edit_text(
            f"{prefix}{final}\n\n<i>⏱ {elapsed}s</i>",
            parse_mode=H,
        )
    except Exception:
        try:
            await thinking.edit_text(f"{prefix}{final[:3900]}", parse_mode=H)
        except Exception:
            pass

    return full_text


class StreamingHandlers:
    """Adds /chat command with simulated streaming response."""

    @require_auth
    async def cmd_chat(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /chat <message>  — streaming AI conversation (shows response in real-time)
        """
        msg = update.effective_message
        user_id = update.effective_user.id
        text = " ".join(ctx.args or [])

        if not text:
            await msg.reply_text(
                "💬 <b>Streaming Chat</b>\n\n"
                "Usage: <code>/chat &lt;your message&gt;</code>\n\n"
                "Like /ask but shows response streaming in real-time.",
                parse_mode=H,
            )
            return

        if not hasattr(self, "_ai") or not self._ai.is_configured():
            await msg.reply_text("⚠️ AI not configured.", parse_mode=H)
            return

        # Load conversation context
        try:
            from salim.handlers.history import get_ai_context
            history = get_ai_context(user_id)
        except Exception:
            history = []

        messages = history + [{"role": "user", "content": text}]

        # Load instructions
        system = "You are Salim, a helpful AI assistant for laptop control."
        try:
            from salim.handlers.instructions import build_instructions_context
            instr = build_instructions_context(user_id)
            if instr:
                system += "\n\n" + instr
        except Exception:
            pass

        response = await stream_ai_response(
            msg=msg,
            ai=self._ai,
            messages=messages,
            system=system,
            prefix="💬 ",
        )

        # Save to history
        if response:
            try:
                from salim.handlers.history import save_message
                save_message(user_id, "user", text)
                save_message(user_id, "assistant", response[:2000])
            except Exception:
                pass
