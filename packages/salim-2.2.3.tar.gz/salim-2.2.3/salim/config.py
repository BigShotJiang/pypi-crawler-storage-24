"""Configuration module for Salim."""

class Config:
    """Configuration class for Salim bot."""
    pass
