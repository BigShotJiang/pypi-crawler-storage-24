"""Stream protocol messages ported from lasersell-stream-proto."""

from __future__ import annotations

import json
import math
from typing import Any, Literal, NotRequired, Required, TypedDict, cast

MarketTypeMsg = Literal[
    "pump_fun",
    "pump_swap",
    "meteora_dbc",
    "meteora_damm_v2",
    "raydium_launchpad",
    "raydium_cpmm",
]


class PumpFunContextMsg(TypedDict):
    pass


class PumpSwapContextMsg(TypedDict, total=False):
    pool: Required[str]
    global_config: NotRequired[str]


class MeteoraDbcContextMsg(TypedDict):
    pool: str
    config: str
    quote_mint: str


class MeteoraDammV2ContextMsg(TypedDict):
    pool: str


class RaydiumLaunchpadContextMsg(TypedDict):
    pool: str
    config: str
    platform: str
    quote_mint: str
    user_quote_account: str


class RaydiumCpmmContextMsg(TypedDict):
    pool: str
    config: str
    quote_mint: str
    user_quote_account: str


class MarketContextMsg(TypedDict, total=False):
    market_type: Required[MarketTypeMsg]
    pumpfun: NotRequired[PumpFunContextMsg]
    pumpswap: NotRequired[PumpSwapContextMsg]
    meteora_dbc: NotRequired[MeteoraDbcContextMsg]
    meteora_damm_v2: NotRequired[MeteoraDammV2ContextMsg]
    raydium_launchpad: NotRequired[RaydiumLaunchpadContextMsg]
    raydium_cpmm: NotRequired[RaydiumCpmmContextMsg]


class TakeProfitLevelMsg(TypedDict):
    profit_pct: float
    sell_pct: float
    trailing_stop_pct: float


class StrategyConfigMsg(TypedDict, total=False):
    target_profit_pct: Required[float]
    stop_loss_pct: Required[float]
    trailing_stop_pct: NotRequired[float]
    sell_on_graduation: NotRequired[bool]
    take_profit_levels: NotRequired[list[TakeProfitLevelMsg]]
    liquidity_guard: NotRequired[bool]
    breakeven_trail_pct: NotRequired[float]


class AutoBuyConfigMsg(TypedDict, total=False):
    wallet_pubkey: Required[str]
    amount_quote_units: Required[int]
    amount_usd1_units: NotRequired[int]


class WatchWalletEntryMsg(TypedDict, total=False):
    pubkey: Required[str]
    auto_buy: NotRequired[AutoBuyConfigMsg]


class LimitsMsg(TypedDict):
    hi_capacity: int
    pnl_flush_ms: int
    max_positions_per_session: int
    max_wallets_per_session: int
    max_positions_per_wallet: int
    max_sessions_per_api_key: int
    max_watch_wallets_per_session: int


class PingClientMessage(TypedDict):
    type: Literal["ping"]
    client_time_ms: int


class ConfigureClientMessage(TypedDict, total=False):
    type: Required[Literal["configure"]]
    wallet_pubkeys: Required[list[str]]
    strategy: Required[StrategyConfigMsg]
    send_mode: NotRequired[str]
    tip_lamports: NotRequired[int]
    watch_wallets: NotRequired[list[WatchWalletEntryMsg]]


class UpdateStrategyClientMessage(TypedDict):
    type: Literal["update_strategy"]
    strategy: StrategyConfigMsg


class ClosePositionClientMessage(TypedDict, total=False):
    type: Required[Literal["close_position"]]
    position_id: NotRequired[int]
    token_account: NotRequired[str]


class RequestExitSignalClientMessage(TypedDict, total=False):
    type: Required[Literal["request_exit_signal"]]
    position_id: NotRequired[int]
    token_account: NotRequired[str]
    slippage_bps: NotRequired[int]


class UpdateWalletsClientMessage(TypedDict):
    type: Literal["update_wallets"]
    wallet_pubkeys: list[str]


class UpdateWatchWalletsClientMessage(TypedDict):
    type: Literal["update_watch_wallets"]
    watch_wallets: list[WatchWalletEntryMsg]


class UpdatePositionStrategyClientMessage(TypedDict):
    type: Literal["update_position_strategy"]
    position_id: int
    strategy: StrategyConfigMsg


ClientMessage = (
    PingClientMessage
    | ConfigureClientMessage
    | UpdateStrategyClientMessage
    | ClosePositionClientMessage
    | RequestExitSignalClientMessage
    | UpdateWalletsClientMessage
    | UpdateWatchWalletsClientMessage
    | UpdatePositionStrategyClientMessage
)


class HelloOkServerMessage(TypedDict):
    type: Literal["hello_ok"]
    session_id: int
    server_time_ms: int
    limits: LimitsMsg


class PongServerMessage(TypedDict):
    type: Literal["pong"]
    server_time_ms: int


class ErrorServerMessage(TypedDict):
    type: Literal["error"]
    code: str
    message: str


class PnlUpdateServerMessage(TypedDict, total=False):
    type: Required[Literal["pnl_update"]]
    position_id: Required[int]
    profit_units: Required[int]
    proceeds_units: Required[int]
    server_time_ms: Required[int]
    token_price_quote: NotRequired[int]
    market_cap_quote: NotRequired[int]
    watched: NotRequired[bool]


class SlippageBandMsg(TypedDict):
    slippage_bps: int
    max_tokens: int
    coverage_pct: float


class LiquiditySnapshotServerMessage(TypedDict, total=False):
    type: Required[Literal["liquidity_snapshot"]]
    position_id: Required[int]
    bands: Required[list[SlippageBandMsg]]
    liquidity_trend: Required[str]
    server_time_ms: Required[int]
    watched: NotRequired[bool]


class BalanceUpdateServerMessage(TypedDict, total=False):
    type: Required[Literal["balance_update"]]
    wallet_pubkey: Required[str]
    mint: Required[str]
    token_account: NotRequired[str]
    token_program: NotRequired[str]
    tokens: Required[int]
    slot: Required[int]


class PositionOpenedServerMessage(TypedDict, total=False):
    type: Required[Literal["position_opened"]]
    position_id: Required[int]
    wallet_pubkey: Required[str]
    mint: Required[str]
    token_account: Required[str]
    token_program: NotRequired[str]
    tokens: Required[int]
    entry_quote_units: Required[int]
    market_context: NotRequired[MarketContextMsg]
    slot: Required[int]
    token_name: NotRequired[str]
    token_symbol: NotRequired[str]
    token_decimals: NotRequired[int]
    token_price_quote: NotRequired[int]
    market_cap_quote: NotRequired[int]
    pool_liquidity_quote: NotRequired[int]
    opened_at_ms: NotRequired[int]
    mirror_source: NotRequired[str]
    watched: NotRequired[bool]


class PositionClosedServerMessage(TypedDict, total=False):
    type: Required[Literal["position_closed"]]
    position_id: Required[int]
    wallet_pubkey: Required[str]
    mint: Required[str]
    token_account: NotRequired[str]
    reason: Required[str]
    slot: Required[int]
    mirror_source: NotRequired[str]
    watched: NotRequired[bool]


class ExitSignalWithTxServerMessage(TypedDict, total=False):
    type: Required[Literal["exit_signal_with_tx"]]
    session_id: Required[int]
    position_id: Required[int]
    wallet_pubkey: Required[str]
    mint: Required[str]
    token_account: NotRequired[str]
    token_program: NotRequired[str]
    position_tokens: Required[int]
    profit_units: Required[int]
    reason: Required[str]
    triggered_at_ms: Required[int]
    market_context: NotRequired[MarketContextMsg]
    unsigned_tx_b64: Required[str]
    sell_tokens: NotRequired[int]
    level_index: NotRequired[int]
    mirror_source: NotRequired[str]
    watched: NotRequired[bool]


class TradeTickServerMessage(TypedDict, total=False):
    type: Required[Literal["trade_tick"]]
    position_id: Required[int]
    time_ms: Required[int]
    side: Required[str]
    token_amount: Required[int]
    quote_amount: Required[int]
    price_quote: Required[int]
    maker: NotRequired[str]
    tx_signature: NotRequired[str]
    watched: NotRequired[bool]


ServerMessage = (
    HelloOkServerMessage
    | PongServerMessage
    | ErrorServerMessage
    | PnlUpdateServerMessage
    | LiquiditySnapshotServerMessage
    | BalanceUpdateServerMessage
    | PositionOpenedServerMessage
    | PositionClosedServerMessage
    | ExitSignalWithTxServerMessage
    | TradeTickServerMessage
)


def client_message_from_text(text: str) -> ClientMessage:
    """Parses JSON text into a validated client message."""

    try:
        parsed = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"decode client message JSON: {exc}") from exc
    return client_message_from_obj(parsed)


def client_message_from_obj(value: object) -> ClientMessage:
    """Parses a Python object into a validated client message."""

    obj = _as_record(value, "client message")
    message_type = _as_string(obj.get("type"), "client message.type")

    if message_type == "ping":
        return {
            "type": "ping",
            "client_time_ms": _as_int(obj.get("client_time_ms"), "ping.client_time_ms"),
        }

    if message_type == "configure":
        message = cast(ConfigureClientMessage, {
            "type": "configure",
            "wallet_pubkeys": _parse_wallet_pubkeys(obj),
            "strategy": _parse_strategy_config(obj.get("strategy")),
        })
        _set_optional_str(message, "send_mode", obj.get("send_mode"), "configure.send_mode")
        _set_optional_int(message, "tip_lamports", obj.get("tip_lamports"), "configure.tip_lamports")
        raw_watch_wallets = obj.get("watch_wallets")
        if raw_watch_wallets is not None and isinstance(raw_watch_wallets, list) and len(raw_watch_wallets) > 0:
            message["watch_wallets"] = _parse_watch_wallets(raw_watch_wallets)
        return message

    if message_type == "update_strategy":
        return {
            "type": "update_strategy",
            "strategy": _parse_strategy_config(obj.get("strategy")),
        }

    if message_type == "close_position":
        message: ClosePositionClientMessage = {"type": "close_position"}
        _set_optional_int(
            message,
            "position_id",
            obj.get("position_id"),
            "close_position.position_id",
        )
        _set_optional_str(
            message,
            "token_account",
            obj.get("token_account"),
            "close_position.token_account",
        )
        return message

    if message_type in ("sell_now", "request_exit_signal"):
        message = cast(RequestExitSignalClientMessage, {"type": "request_exit_signal"})
        _set_optional_int(
            message,
            "position_id",
            obj.get("position_id"),
            "request_exit_signal.position_id",
        )
        _set_optional_str(
            message,
            "token_account",
            obj.get("token_account"),
            "request_exit_signal.token_account",
        )
        _set_optional_int(
            message,
            "slippage_bps",
            obj.get("slippage_bps"),
            "request_exit_signal.slippage_bps",
        )
        return message

    if message_type == "update_wallets":
        return {
            "type": "update_wallets",
            "wallet_pubkeys": _parse_wallet_pubkeys(obj),
        }

    if message_type == "update_watch_wallets":
        return {
            "type": "update_watch_wallets",
            "watch_wallets": _parse_watch_wallets(obj.get("watch_wallets")),
        }

    if message_type == "update_position_strategy":
        return {
            "type": "update_position_strategy",
            "position_id": _as_int(obj.get("position_id"), "update_position_strategy.position_id"),
            "strategy": _parse_strategy_config(obj.get("strategy")),
        }

    raise ValueError(f"unsupported client message type: {message_type}")


def client_message_to_text(message: ClientMessage) -> str:
    """Serializes a client message to JSON text."""

    return json.dumps(message, separators=(",", ":"))


def server_message_from_text(text: str) -> ServerMessage:
    """Parses JSON text into a validated server message."""

    try:
        parsed = json.loads(text)
    except json.JSONDecodeError as exc:
        raise ValueError(f"decode server message JSON: {exc}") from exc
    return server_message_from_obj(parsed)


def server_message_from_obj(value: object) -> ServerMessage:
    """Parses a Python object into a validated server message."""

    obj = _as_record(value, "server message")
    message_type = _as_string(obj.get("type"), "server message.type")

    if message_type == "hello_ok":
        return {
            "type": "hello_ok",
            "session_id": _as_int(obj.get("session_id"), "hello_ok.session_id"),
            "server_time_ms": _as_int(obj.get("server_time_ms"), "hello_ok.server_time_ms"),
            "limits": _parse_limits(obj.get("limits")),
        }

    if message_type == "pong":
        return {
            "type": "pong",
            "server_time_ms": _as_int(obj.get("server_time_ms"), "pong.server_time_ms"),
        }

    if message_type == "error":
        return {
            "type": "error",
            "code": _as_string(obj.get("code"), "error.code"),
            "message": _as_string(obj.get("message"), "error.message"),
        }

    if message_type == "pnl_update":
        message = cast(
            PnlUpdateServerMessage,
            {
                "type": "pnl_update",
                "position_id": _as_int(obj.get("position_id"), "pnl_update.position_id"),
                "profit_units": _as_int(obj.get("profit_units"), "pnl_update.profit_units"),
                "proceeds_units": _as_int(obj.get("proceeds_units"), "pnl_update.proceeds_units"),
                "server_time_ms": _as_int(obj.get("server_time_ms"), "pnl_update.server_time_ms"),
            },
        )
        _set_optional_int(message, "token_price_quote", obj.get("token_price_quote"), "pnl_update.token_price_quote")
        _set_optional_int(message, "market_cap_quote", obj.get("market_cap_quote"), "pnl_update.market_cap_quote")
        _set_optional_bool(message, "watched", obj.get("watched"), "pnl_update.watched")
        return message

    if message_type == "liquidity_snapshot":
        raw_bands = obj.get("bands")
        if not isinstance(raw_bands, list):
            raise ValueError("liquidity_snapshot.bands must be an array")
        bands: list[SlippageBandMsg] = []
        for idx, item in enumerate(raw_bands):
            band_obj = _as_record(item, f"liquidity_snapshot.bands[{idx}]")
            bands.append({
                "slippage_bps": _as_int(band_obj.get("slippage_bps"), f"liquidity_snapshot.bands[{idx}].slippage_bps"),
                "max_tokens": _as_int(band_obj.get("max_tokens"), f"liquidity_snapshot.bands[{idx}].max_tokens"),
                "coverage_pct": _as_float(band_obj.get("coverage_pct"), f"liquidity_snapshot.bands[{idx}].coverage_pct"),
            })
        message = cast(
            LiquiditySnapshotServerMessage,
            {
                "type": "liquidity_snapshot",
                "position_id": _as_int(obj.get("position_id"), "liquidity_snapshot.position_id"),
                "bands": bands,
                "liquidity_trend": _as_string(obj.get("liquidity_trend"), "liquidity_snapshot.liquidity_trend"),
                "server_time_ms": _as_int(obj.get("server_time_ms"), "liquidity_snapshot.server_time_ms"),
            },
        )
        _set_optional_bool(message, "watched", obj.get("watched"), "liquidity_snapshot.watched")
        return message

    if message_type == "balance_update":
        message = cast(
            BalanceUpdateServerMessage,
            {
                "type": "balance_update",
                "wallet_pubkey": _as_string(
                    obj.get("wallet_pubkey"),
                    "balance_update.wallet_pubkey",
                ),
                "mint": _as_string(obj.get("mint"), "balance_update.mint"),
                "tokens": _as_int(obj.get("tokens"), "balance_update.tokens"),
                "slot": _as_int(obj.get("slot"), "balance_update.slot"),
            },
        )
        _set_optional_str(
            message,
            "token_account",
            obj.get("token_account"),
            "balance_update.token_account",
        )
        _set_optional_str(
            message,
            "token_program",
            obj.get("token_program"),
            "balance_update.token_program",
        )
        return message

    if message_type == "position_opened":
        message = cast(
            PositionOpenedServerMessage,
            {
                "type": "position_opened",
                "position_id": _as_int(obj.get("position_id"), "position_opened.position_id"),
                "wallet_pubkey": _as_string(
                    obj.get("wallet_pubkey"),
                    "position_opened.wallet_pubkey",
                ),
                "mint": _as_string(obj.get("mint"), "position_opened.mint"),
                "token_account": _as_string(
                    obj.get("token_account"),
                    "position_opened.token_account",
                ),
                "tokens": _as_int(obj.get("tokens"), "position_opened.tokens"),
                "entry_quote_units": _as_int(
                    obj.get("entry_quote_units"),
                    "position_opened.entry_quote_units",
                ),
                "slot": _as_int(obj.get("slot"), "position_opened.slot"),
            },
        )
        _set_optional_str(
            message,
            "token_program",
            obj.get("token_program"),
            "position_opened.token_program",
        )
        _set_optional_market_context(
            message,
            "market_context",
            obj.get("market_context"),
            "position_opened.market_context",
        )
        _set_optional_str(message, "token_name", obj.get("token_name"), "position_opened.token_name")
        _set_optional_str(message, "token_symbol", obj.get("token_symbol"), "position_opened.token_symbol")
        _set_optional_int(message, "token_decimals", obj.get("token_decimals"), "position_opened.token_decimals")
        _set_optional_int(message, "token_price_quote", obj.get("token_price_quote"), "position_opened.token_price_quote")
        _set_optional_int(message, "market_cap_quote", obj.get("market_cap_quote"), "position_opened.market_cap_quote")
        _set_optional_int(message, "pool_liquidity_quote", obj.get("pool_liquidity_quote"), "position_opened.pool_liquidity_quote")
        _set_optional_int(message, "opened_at_ms", obj.get("opened_at_ms"), "position_opened.opened_at_ms")
        _set_optional_str(message, "mirror_source", obj.get("mirror_source"), "position_opened.mirror_source")
        _set_optional_bool(message, "watched", obj.get("watched"), "position_opened.watched")
        return message

    if message_type == "position_closed":
        message = cast(
            PositionClosedServerMessage,
            {
                "type": "position_closed",
                "position_id": _as_int(obj.get("position_id"), "position_closed.position_id"),
                "wallet_pubkey": _as_string(
                    obj.get("wallet_pubkey"),
                    "position_closed.wallet_pubkey",
                ),
                "mint": _as_string(obj.get("mint"), "position_closed.mint"),
                "reason": _as_string(obj.get("reason"), "position_closed.reason"),
                "slot": _as_int(obj.get("slot"), "position_closed.slot"),
            },
        )
        _set_optional_str(
            message,
            "token_account",
            obj.get("token_account"),
            "position_closed.token_account",
        )
        _set_optional_str(message, "mirror_source", obj.get("mirror_source"), "position_closed.mirror_source")
        _set_optional_bool(message, "watched", obj.get("watched"), "position_closed.watched")
        return message

    if message_type == "exit_signal_with_tx":
        message = cast(
            ExitSignalWithTxServerMessage,
            {
                "type": "exit_signal_with_tx",
                "session_id": _as_int(obj.get("session_id"), "exit_signal_with_tx.session_id"),
                "position_id": _as_int(
                    obj.get("position_id"),
                    "exit_signal_with_tx.position_id",
                ),
                "wallet_pubkey": _as_string(
                    obj.get("wallet_pubkey"),
                    "exit_signal_with_tx.wallet_pubkey",
                ),
                "mint": _as_string(obj.get("mint"), "exit_signal_with_tx.mint"),
                "position_tokens": _as_int(
                    obj.get("position_tokens"),
                    "exit_signal_with_tx.position_tokens",
                ),
                "profit_units": _as_int(
                    obj.get("profit_units"),
                    "exit_signal_with_tx.profit_units",
                ),
                "reason": _as_string(obj.get("reason"), "exit_signal_with_tx.reason"),
                "triggered_at_ms": _as_int(
                    obj.get("triggered_at_ms"),
                    "exit_signal_with_tx.triggered_at_ms",
                ),
                "unsigned_tx_b64": _as_string(
                    obj.get("unsigned_tx_b64"),
                    "exit_signal_with_tx.unsigned_tx_b64",
                ),
            },
        )
        _set_optional_str(
            message,
            "token_account",
            obj.get("token_account"),
            "exit_signal_with_tx.token_account",
        )
        _set_optional_str(
            message,
            "token_program",
            obj.get("token_program"),
            "exit_signal_with_tx.token_program",
        )
        _set_optional_market_context(
            message,
            "market_context",
            obj.get("market_context"),
            "exit_signal_with_tx.market_context",
        )
        _set_optional_int(message, "sell_tokens", obj.get("sell_tokens"), "exit_signal_with_tx.sell_tokens")
        _set_optional_int(message, "level_index", obj.get("level_index"), "exit_signal_with_tx.level_index")
        _set_optional_str(message, "mirror_source", obj.get("mirror_source"), "exit_signal_with_tx.mirror_source")
        _set_optional_bool(message, "watched", obj.get("watched"), "exit_signal_with_tx.watched")
        return message

    if message_type == "trade_tick":
        message = cast(
            TradeTickServerMessage,
            {
                "type": "trade_tick",
                "position_id": _as_int(obj.get("position_id"), "trade_tick.position_id"),
                "time_ms": _as_int(obj.get("time_ms"), "trade_tick.time_ms"),
                "side": _as_string(obj.get("side"), "trade_tick.side"),
                "token_amount": _as_int(obj.get("token_amount"), "trade_tick.token_amount"),
                "quote_amount": _as_int(obj.get("quote_amount"), "trade_tick.quote_amount"),
                "price_quote": _as_int(obj.get("price_quote"), "trade_tick.price_quote"),
            },
        )
        _set_optional_str(message, "maker", obj.get("maker"), "trade_tick.maker")
        _set_optional_str(message, "tx_signature", obj.get("tx_signature"), "trade_tick.tx_signature")
        _set_optional_bool(message, "watched", obj.get("watched"), "trade_tick.watched")
        return message

    raise ValueError(f"unsupported server message type: {message_type}")


def server_message_to_text(message: ServerMessage) -> str:
    """Serializes a server message to JSON text."""

    return json.dumps(message, separators=(",", ":"))


def _parse_wallet_pubkeys(obj: dict[str, object]) -> list[str]:
    wallets = obj.get("wallet_pubkeys", obj.get("wallet_pubkey"))

    if isinstance(wallets, str):
        return [wallets]

    if isinstance(wallets, list):
        return [_as_string(item, f"configure.wallet_pubkeys[{idx}]") for idx, item in enumerate(wallets)]

    raise ValueError(
        "configure.wallet_pubkeys must be a string or string[] (legacy wallet_pubkey is supported)"
    )


def _parse_watch_wallets(value: object) -> list[WatchWalletEntryMsg]:
    if not isinstance(value, list):
        raise ValueError("watch_wallets must be an array")
    result: list[WatchWalletEntryMsg] = []
    for idx, item in enumerate(value):
        entry_obj = _as_record(item, f"watch_wallets[{idx}]")
        entry: WatchWalletEntryMsg = {
            "pubkey": _as_string(entry_obj.get("pubkey"), f"watch_wallets[{idx}].pubkey"),
        }
        raw_auto_buy = entry_obj.get("auto_buy")
        if raw_auto_buy is not None:
            ab_obj = _as_record(raw_auto_buy, f"watch_wallets[{idx}].auto_buy")
            auto_buy: AutoBuyConfigMsg = {
                "wallet_pubkey": _as_string(ab_obj.get("wallet_pubkey"), f"watch_wallets[{idx}].auto_buy.wallet_pubkey"),
                "amount_quote_units": _as_int(ab_obj.get("amount_quote_units"), f"watch_wallets[{idx}].auto_buy.amount_quote_units"),
            }
            usd1 = _optional_int(ab_obj.get("amount_usd1_units"), f"watch_wallets[{idx}].auto_buy.amount_usd1_units")
            if usd1 is not None:
                auto_buy["amount_usd1_units"] = usd1
            entry["auto_buy"] = auto_buy
        result.append(entry)
    return result


def _parse_strategy_config(value: object) -> StrategyConfigMsg:
    obj = _as_record(value, "strategy")

    result: StrategyConfigMsg = {
        "target_profit_pct": _as_float(obj.get("target_profit_pct"), "strategy.target_profit_pct"),
        "stop_loss_pct": _as_float(obj.get("stop_loss_pct"), "strategy.stop_loss_pct"),
    }

    trailing_raw = obj.get("trailing_stop_pct")
    if trailing_raw is not None:
        result["trailing_stop_pct"] = _as_float(trailing_raw, "strategy.trailing_stop_pct")

    sell_on_graduation_raw = obj.get("sell_on_graduation")
    if sell_on_graduation_raw is not None:
        if not isinstance(sell_on_graduation_raw, bool):
            raise ValueError("strategy.sell_on_graduation must be a boolean")
        result["sell_on_graduation"] = sell_on_graduation_raw

    take_profit_levels = obj.get("take_profit_levels", [])
    if isinstance(take_profit_levels, list) and len(take_profit_levels) > 0:
        result["take_profit_levels"] = take_profit_levels

    liquidity_guard = bool(obj.get("liquidity_guard", False))
    if liquidity_guard:
        result["liquidity_guard"] = liquidity_guard

    breakeven_trail_pct = float(obj.get("breakeven_trail_pct", 0.0))
    if breakeven_trail_pct > 0:
        result["breakeven_trail_pct"] = breakeven_trail_pct

    return result


def _parse_limits(value: object) -> LimitsMsg:
    obj = _as_record(value, "limits")

    max_wallets_per_session = _optional_int(
        obj.get("max_wallets_per_session"),
        "limits.max_wallets_per_session",
    )
    max_positions_per_wallet = _optional_int(
        obj.get("max_positions_per_wallet"),
        "limits.max_positions_per_wallet",
    )
    max_sessions_per_api_key = _optional_int(
        obj.get("max_sessions_per_api_key"),
        "limits.max_sessions_per_api_key",
    )
    max_watch_wallets_per_session = _optional_int(
        obj.get("max_watch_wallets_per_session"),
        "limits.max_watch_wallets_per_session",
    )

    return {
        "hi_capacity": _as_int(obj.get("hi_capacity"), "limits.hi_capacity"),
        "pnl_flush_ms": _as_int(obj.get("pnl_flush_ms"), "limits.pnl_flush_ms"),
        "max_positions_per_session": _as_int(
            obj.get("max_positions_per_session"),
            "limits.max_positions_per_session",
        ),
        "max_wallets_per_session": 0 if max_wallets_per_session is None else max_wallets_per_session,
        "max_positions_per_wallet": 0 if max_positions_per_wallet is None else max_positions_per_wallet,
        "max_sessions_per_api_key": 0
        if max_sessions_per_api_key is None
        else max_sessions_per_api_key,
        "max_watch_wallets_per_session": 0
        if max_watch_wallets_per_session is None
        else max_watch_wallets_per_session,
    }


def _set_optional_market_context(
    obj: dict[str, object],
    key: str,
    value: object,
    path: str,
) -> None:
    parsed = _optional_market_context(value, path)
    if parsed is not None:
        obj[key] = parsed


def _optional_market_context(value: object, path: str) -> MarketContextMsg | None:
    if value is None:
        return None
    return _parse_market_context(value, path)


def _parse_market_context(value: object, path: str) -> MarketContextMsg:
    obj = _as_record(value, path)

    result: MarketContextMsg = {
        "market_type": _parse_market_type(
            obj.get("market_type"),
            f"{path}.market_type",
        )
    }

    _set_optional_object(result, "pumpfun", obj.get("pumpfun"), f"{path}.pumpfun")
    _set_optional_object(result, "pumpswap", obj.get("pumpswap"), f"{path}.pumpswap")
    _set_optional_object(result, "meteora_dbc", obj.get("meteora_dbc"), f"{path}.meteora_dbc")
    _set_optional_object(
        result,
        "meteora_damm_v2",
        obj.get("meteora_damm_v2"),
        f"{path}.meteora_damm_v2",
    )
    _set_optional_object(
        result,
        "raydium_launchpad",
        obj.get("raydium_launchpad"),
        f"{path}.raydium_launchpad",
    )
    _set_optional_object(
        result,
        "raydium_cpmm",
        obj.get("raydium_cpmm"),
        f"{path}.raydium_cpmm",
    )

    return result


def _parse_market_type(value: object, path: str) -> MarketTypeMsg:
    market_type = _as_string(value, path)
    allowed_market_types: set[str] = {
        "pump_fun",
        "pump_swap",
        "meteora_dbc",
        "meteora_damm_v2",
        "raydium_launchpad",
        "raydium_cpmm",
    }
    if market_type not in allowed_market_types:
        raise ValueError(f"invalid market type at {path}: {market_type}")
    return cast(MarketTypeMsg, market_type)


def _set_optional_int(
    obj: dict[str, object],
    key: str,
    value: object,
    path: str,
) -> None:
    parsed = _optional_int(value, path)
    if parsed is not None:
        obj[key] = parsed


def _set_optional_bool(
    obj: dict[str, object],
    key: str,
    value: object,
    path: str,
) -> None:
    if value is None:
        return
    if not isinstance(value, bool):
        raise ValueError(f"{path} must be a boolean")
    obj[key] = value


def _set_optional_str(
    obj: dict[str, object],
    key: str,
    value: object,
    path: str,
) -> None:
    parsed = _optional_string(value, path)
    if parsed is not None:
        obj[key] = parsed


def _set_optional_object(
    obj: dict[str, object],
    key: str,
    value: object,
    path: str,
) -> None:
    parsed = _optional_object(value, path)
    if parsed is not None:
        obj[key] = parsed


def _optional_string(value: object, path: str) -> str | None:
    if value is None:
        return None
    return _as_string(value, path)


def _optional_int(value: object, path: str) -> int | None:
    if value is None:
        return None
    return _as_int(value, path)


def _optional_object(value: object, path: str) -> dict[str, object] | None:
    if value is None:
        return None
    return _as_record(value, path)


def _as_record(value: object, path: str) -> dict[str, object]:
    if not isinstance(value, dict):
        raise ValueError(f"{path} must be an object")
    return cast(dict[str, object], value)


def _as_string(value: object, path: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{path} must be a string")
    return value


def _as_float(value: object, path: str) -> float:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        raise ValueError(f"{path} must be a finite number")

    number = float(value)
    if not math.isfinite(number):
        raise ValueError(f"{path} must be a finite number")
    return number


def _as_int(value: object, path: str) -> int:
    if isinstance(value, bool):
        raise ValueError(f"{path} must be an integer")

    if isinstance(value, int):
        return value

    if isinstance(value, float) and value.is_integer() and math.isfinite(value):
        return int(value)

    raise ValueError(f"{path} must be an integer")


__all__ = [
    "AutoBuyConfigMsg",
    "BalanceUpdateServerMessage",
    "ClientMessage",
    "ClosePositionClientMessage",
    "ConfigureClientMessage",
    "ErrorServerMessage",
    "ExitSignalWithTxServerMessage",
    "HelloOkServerMessage",
    "LimitsMsg",
    "LiquiditySnapshotServerMessage",
    "MarketContextMsg",
    "MarketTypeMsg",
    "PnlUpdateServerMessage",
    "PositionClosedServerMessage",
    "PositionOpenedServerMessage",
    "RequestExitSignalClientMessage",
    "ServerMessage",
    "SlippageBandMsg",
    "StrategyConfigMsg",
    "TakeProfitLevelMsg",
    "TradeTickServerMessage",
    "UpdatePositionStrategyClientMessage",
    "UpdateStrategyClientMessage",
    "UpdateWalletsClientMessage",
    "UpdateWatchWalletsClientMessage",
    "WatchWalletEntryMsg",
    "client_message_from_obj",
    "client_message_from_text",
    "client_message_to_text",
    "server_message_from_obj",
    "server_message_from_text",
    "server_message_to_text",
]
