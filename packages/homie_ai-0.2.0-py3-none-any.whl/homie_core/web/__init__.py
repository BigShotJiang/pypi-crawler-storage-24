"""Web analysis utilities."""
