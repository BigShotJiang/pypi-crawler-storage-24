"""
Module to include utils related to printing
and loggin the memory usage of the tests.
"""
from yta_logger import ConsolePrinter
# from yta_timer import Timer

import os
import psutil
import pytest
import gc
import tracemalloc
import time


TESTS_LOG_FILENAME = 'test_files/tests.log'


# @pytest.fixture(autouse = True)
@pytest.hookimpl(hookwrapper = True)
def print_and_log_test_memory_usage(
    request
):
    """
    Print and log the memory usage of every test.

    This method must be used
    """
    # timer = Timer()
    tracemalloc.start()
    process = psutil.Process(os.getpid())
    test_name = request.node.nodeid
    

    general_memory_before = process.memory_info().rss / 1024**2
    python_memory_before = tracemalloc.get_traced_memory()[0] / 1024**2

    _print_and_log(f'\n{test_name}')
    _print_and_log(f'-- Before --')
    _print_and_log(f'[MEM] {general_memory_before:.2f} MB')
    _print_and_log(f'[MEM PYTHON] {python_memory_before:.2f} MB')

    # timer.resume()

    start = time.perf_counter()

    yield

    # timer.pause()

    elapsed = time.perf_counter() - start
    seconds = int(elapsed)

    gc.collect()

    general_memory_after = process.memory_info().rss / 1024**2
    python_memory_after = tracemalloc.get_traced_memory()[0] / 1024**2

    _print_and_log(f'-- After --')
    _print_and_log(f'[MEM ] {general_memory_after:.2f} MB')
    _print_and_log(f'[MEM PYTHON] {python_memory_after:.2f} MB')
    _print_and_log(f'-- Total --')
    # _print_and_log(f'[TIME]: {timer.time_elapsed_str}')
    _print_and_log(f'[TIME] {test_name} -> {seconds//60:02}:{seconds%60:02}')
    _print_and_log(f'[GC OBJECTS]: {str(len(gc.get_objects()))}')

def _print_and_log(
    message: str
):
    """
    *For internal use only*

    Print and log the `message` provided.
    """
    do_print = ConsolePrinter()._do_print
    do_write_file = ConsolePrinter()._do_write_file

    ConsolePrinter().print(
        message = message,
        output_filename = TESTS_LOG_FILENAME
    )

    # Preserve previous values to avoid conflicts
    # with other libraries
    ConsolePrinter()._do_print = do_print
    ConsolePrinter()._do_write_file = do_write_file

    return