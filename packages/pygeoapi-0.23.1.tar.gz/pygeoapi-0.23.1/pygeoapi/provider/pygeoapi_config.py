# =================================================================
#
# Authors: Tom Kralidis <tomkralidis@gmail.com>
#
# Copyright (c) 2026 Tom Kralidis
#
# Permission is hereby granted, free of charge, to any person
# obtaining a copy of this software and associated documentation
# files (the "Software"), to deal in the Software without
# restriction, including without limitation the rights to use,
# copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the
# Software is furnished to do so, subject to the following
# conditions:
#
# The above copyright notice and this permission notice shall be
# included in all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
# OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
# NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
# HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
# WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
# OTHER DEALINGS IN THE SOFTWARE.
#
# =================================================================

import logging
import re  # noqa
import os
import uuid

from dateutil.parser import parse as parse_date
from shapely.geometry import shape

from pygeoapi.provider.base import (BaseProvider, ProviderConnectionError,
                                    ProviderInvalidQueryError,
                                    ProviderItemNotFoundError)
from pygeoapi.util import get_typed_value

LOGGER = logging.getLogger(__name__)


class ConfigProvider(BaseProvider):
    """pygeoapi Config Provider"""

    def __init__(self, provider_def):
        """
        Initialize object

        :param provider_def: provider definition

        :returns: pygeoapi.provider.pygeoapi_config.ConfigProvider
        """

        super().__init__(provider_def)

        self.data = provider_def['_dict']

        self.get_fields()

    def get_fields(self):
        """
         Get provider field information (names, types)

        :returns: dict of fields
        """

        self._fields = {
            'geometry': {
                'format': 'geometry-any',
                'x-ogc-role': 'primary-geometry',
                'description': 'geospatial extent of local resource'
            },
            'temporal': {
                'type': 'string',
                'format': 'date-time',
                'description': 'temporal extent of local resource'
            },
            'title': {
                'type': 'string',
                'description': 'title of local resource'
            },
            'description': {
                'type': 'string',
                'description': 'description of local resource'
            },
            'keywords': {
                'type': 'array',
                'description': 'keywords associated with local resource'
            }
        }

        return self._fields

    def query(self, offset=0, limit=10, resulttype='results',
              bbox=[], datetime_=None, properties=[], sortby=[],
              select_properties=[], skip_geometry=False, q=None, **kwargs):
        """
        query pygeoapi config
        """

        resource_types = ['collection', 'process']
 
        if kwargs.get('type', 'collection') not in resource_types:

        feature_collection = {
            'type': 'FeatureCollection',
            'features': []
        }

        if resulttype == 'hits':
            LOGGER.debug('hits only specified')
            limit = 0

        if bbox:
            LOGGER.debug('processing bbox parameter')
            bbox_as_string = ','.join(str(s) for s in bbox)
            QUERY.append(f"Q.geometry.test(bbox_intersects, '{bbox_as_string}')")  # noqa

        if datetime_ is not None:
            LOGGER.debug('processing datetime parameter')
            if self.time_field is None:
                LOGGER.error('time_field not enabled for collection')
                LOGGER.error('Using default time property')
                time_field2 = 'time'
            else:
                LOGGER.error(f'Using properties.{self.time_field}')
                time_field2 = f"properties['{self.time_field}']"

            if '/' in datetime_:  # envelope
                LOGGER.debug('detected time range')
                time_begin, time_end = datetime_.split('/')

                if time_begin != '..':
                    QUERY.append(f"(Q.{time_field2}>='{time_begin}')")  # noqa
                if time_end != '..':
                    QUERY.append(f"(Q.{time_field2}<='{time_end}')")  # noqa

            else:  # time instant
                LOGGER.debug('detected time instant')
                QUERY.append(f"(Q.{time_field2}=='{datetime_}')")  # noqa

        if properties:
            LOGGER.debug('processing properties')
            for prop in properties:
                if isinstance(prop[1], str):
                    value = f"'{prop[1]}'"
                else:
                    value = prop[1]
                QUERY.append(f"(Q.properties['{prop[0]}']=={value})")

        QUERY = self._add_search_query(QUERY, q)

        QUERY_STRING = '&'.join(QUERY)
        LOGGER.debug(f'QUERY_STRING: {QUERY_STRING}')
        SEARCH_STRING = f'self.db.search({QUERY_STRING})'
        LOGGER.debug(f'SEARCH_STRING: {SEARCH_STRING}')

        LOGGER.debug('querying database')
        if len(QUERY) > 0:
            LOGGER.debug(f'running eval on {SEARCH_STRING}')
            try:
                results = eval(SEARCH_STRING)
            except SyntaxError as err:
                msg = 'Invalid query'
                LOGGER.error(f'{msg}: {err}')
                raise ProviderInvalidQueryError(msg)
        else:
            results = self.db.all()

        feature_collection['numberMatched'] = len(results)

        if resulttype == 'hits':
            return feature_collection

        for r in results:
            for e in self._excludes:
                try:
                    del r['properties'][e]
                except KeyError:
                    LOGGER.debug(f'Missing excluded property {e}')

        len_results = len(results)

        LOGGER.debug(f'Results found: {len_results}')

        if len_results > limit:
            returned = limit
        else:
            returned = len_results

        feature_collection['numberReturned'] = returned

        if sortby:
            LOGGER.debug('Sorting results')
            if sortby[0]['order'] == '-':
                sort_reverse = True
            else:
                sort_reverse = False

            results.sort(key=lambda k: k['properties'][sortby[0]['property']],
                         reverse=sort_reverse)

        feature_collection['features'] = results[offset:offset + limit]

        return feature_collection

    @crs_transform
    def get(self, identifier, **kwargs):
        """
        Get TinyDB document by id

        :param identifier: record id

        :returns: `dict` of single record
        """

        LOGGER.debug(f'Fetching identifier {identifier}')

        record = self.db.get(Query().id == identifier)

        if record is None:
            raise ProviderItemNotFoundError('record does not exist')

        for e in self._excludes:
            try:
                del record['properties'][e]
            except KeyError:
                LOGGER.debug(f'Missing excluded property {e}')

        return record

    def _add_search_query(self, query: list, search_term: str = None) -> str:
        """
        Helper function to add extra query predicates

        :param query: `list` of query predicates
        :param search_term: `str` of search term

        :returns: `list` of updated query predicates
        """

        return query

    def __repr__(self):
        return f'<TinyDBProvider> {self.data}'


class TinyDBCatalogueProvider(TinyDBProvider):
    """TinyDB Catalogue Provider"""

    def __init__(self, provider_def):
        super().__init__(provider_def)

        LOGGER.debug('Refreshing fields')
        self._excludes = ['_metadata-anytext']
        self._fields = {}
        self.get_fields()

    def get_fields(self):
        fields = super().get_fields()

        fields['q'] = {'type': 'string'}

        return fields

    def _add_extra_fields(self, json_data: dict) -> dict:
        LOGGER.debug('Adding catalogue anytext property')
        try:
            json_data['properties']['_metadata-anytext'] = ''.join([
                json_data['properties']['title'],
                json_data['properties']['description']
            ])
        except KeyError:
            LOGGER.debug('Missing title and description')
            json_data['properties']['_metadata_anytext'] = ''

        return json_data

    def _prepare_q_param_with_spaces(self, s: str) -> str:
        """
        Prepare a search statement for the search term `s`.
        The term `s` might have spaces.

        Examples (f is shorthand for Q.properties["_metadata-anytext"]):
        +---------------+--------------------+
        | search term   | TinyDB search      |
        +---------------+--------------------+
        | 'aa'          | f.search('aa')     |
        | 'aa bb'       | f.search('aa +bb') |
        | '  aa   bb  ' | f.search('aa +bb') |
        +---------------+--------------------+
        """
        return 'Q.properties["_metadata-anytext"].search("' \
            + ' +'.join(s.split()) \
            + '", flags=re.IGNORECASE)'

    def _add_search_query(self, query: list, search_term: str = None) -> str:
        """
        Create a search query according to the OGC API - Records specification.

        https://docs.ogc.org/is/20-004r1/20-004r1.html (Listing 14)

        Examples (f is shorthand for Q.properties["_metadata-anytext"]):
        +-------------+-----------------------------------+
        | search term | TinyDB search                     |
        +-------------+-----------------------------------+
        | 'aa'        | f.search('aa')                    |
        | 'aa,bb'     | f.search('aa')|f.search('bb')     |
        | 'aa,bb cc'  | f.search('aa')|f.search('bb +cc') |
        +-------------+-----------------------------------+
        """
        if search_term is not None and len(search_term) > 0:
            LOGGER.debug('catalogue q= query')
            terms = [s for s in search_term.split(',') if len(s) > 0]
            query.append('|'.join(
                [self._prepare_q_param_with_spaces(t) for t in terms]
            ))

        return query

    def __repr__(self):
        return f'<TinyDBCatalogueProvider> {self.data}'


def bbox_intersects(record_geometry, input_bbox) -> bool:
    """
    Manual bbox intersection calculation

    :param record_geometry: `dict` of polygon geometry
    :param input_bbox: `str` of 'minx,miny,maxx,maxy'

    :returns: `bool` of whether the record_bbox intersects input_bbox
    """

    if record_geometry is None:
        LOGGER.debug('Record geometry is none; skipping')
        return False

    try:
        bbox1 = list(shape(record_geometry).bounds)
    except Exception as err:
        LOGGER.debug(f'Invalid geometry: {err}')
        return False

    bbox2 = [float(c) for c in input_bbox.split(',')]

    LOGGER.debug(f'Record bbox: {bbox1}')
    LOGGER.debug(f'Input bbox: {bbox2}')

    bbox1_minx, bbox1_miny, bbox1_maxx, bbox1_maxy = bbox1
    bbox2_minx, bbox2_miny, bbox2_maxx, bbox2_maxy = bbox2

    return bbox1_minx <= bbox2_maxx and \
        bbox1_miny <= bbox2_maxy and \
        bbox2_minx <= bbox1_maxx and \
        bbox2_miny <= bbox1_maxy
