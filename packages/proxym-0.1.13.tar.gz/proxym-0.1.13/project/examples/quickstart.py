"""
Quickstart — src

Minimal working examples for the most common use cases.
Run: python examples/quickstart.py
"""

from pathlib import Path

import src


# ==================================================
# Example 2: Generate documentation
# ==================================================

