"""Model registry: 10 providers × 15 models with cost/capability metadata.

Cost figures are per-million-tokens (March 2026).  The router uses these to
pick the cheapest model that satisfies the task requirements.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class TaskTier(str, Enum):
    """Complexity tier that determines which model class is needed."""

    TRIVIAL = "trivial"          # autocomplete, short answers
    OPERATIONAL = "operational"  # small edits, simple generation
    STANDARD = "standard"        # implementation, moderate complexity
    COMPLEX = "complex"          # multi-file refactor, architecture
    DEEP_REASONING = "deep"      # hard bugs, thinking-heavy tasks

    @property
    def rank(self) -> int:
        return _TIER_RANKS[self]


_TIER_RANKS: dict["TaskTier", int] = {
    TaskTier.TRIVIAL: 0,
    TaskTier.OPERATIONAL: 1,
    TaskTier.STANDARD: 2,
    TaskTier.COMPLEX: 3,
    TaskTier.DEEP_REASONING: 4,
}


class Capability(str, Enum):
    CODE = "code"
    REASONING = "reasoning"
    THINKING = "thinking"        # extended thinking / chain-of-thought
    FAST = "fast"
    VISION = "vision"
    LONG_CONTEXT = "long_context"  # >200K tokens
    TOOL_USE = "tool_use"


@dataclass(frozen=True)
class ModelSpec:
    """Immutable specification for a single model deployment."""

    id: str                          # unique key, e.g. "anthropic/opus-4.6"
    provider: str                    # provider name matching config key
    litellm_model: str               # string passed to litellm.completion()
    display_name: str
    input_cost: float                # $/1M input tokens
    output_cost: float               # $/1M output tokens
    context_window: int              # max tokens
    capabilities: frozenset[Capability] = field(default_factory=frozenset)
    min_tier: TaskTier = TaskTier.TRIVIAL
    max_tier: TaskTier = TaskTier.DEEP_REASONING
    cache_read_cost: float = 0.0     # $/1M tokens for prompt cache read
    batch_discount: float = 1.0      # multiplier (0.5 = 50% off)
    speed_tps: int = 80              # approx output tokens/sec
    notes: str = ""

    @property
    def effective_cost(self) -> float:
        """Blended cost per 1M tokens (assuming 1:1 input:output ratio)."""
        return (self.input_cost + self.output_cost) / 2


# ============================================================
# MODEL REGISTRY — 15 models across 10 providers
# Sorted by effective cost ascending within each tier
# ============================================================

MODELS: dict[str, ModelSpec] = {}


def _r(spec: ModelSpec) -> ModelSpec:
    MODELS[spec.id] = spec
    return spec


# --- Tier: TRIVIAL / OPERATIONAL (< $3 effective) ---

_r(ModelSpec(
    id="cerebras/llama-3.3-70b",
    provider="cerebras",
    litellm_model="cerebras/llama-3.3-70b",
    display_name="Llama 3.3 70B (Cerebras)",
    input_cost=0.60, output_cost=0.60,
    context_window=128_000,
    capabilities=frozenset({Capability.CODE, Capability.FAST}),
    min_tier=TaskTier.TRIVIAL, max_tier=TaskTier.OPERATIONAL,
    speed_tps=2200,  # Cerebras is extremely fast
    notes="Fastest inference available; good for simple tasks",
))

_r(ModelSpec(
    id="deepseek/v3",
    provider="deepseek",
    litellm_model="deepseek/deepseek-chat",
    display_name="DeepSeek V3",
    input_cost=0.27, output_cost=1.10,
    context_window=128_000,
    capabilities=frozenset({Capability.CODE, Capability.REASONING}),
    min_tier=TaskTier.TRIVIAL, max_tier=TaskTier.STANDARD,
    cache_read_cost=0.07,
    speed_tps=60,
    notes="Best cost/quality ratio for routine coding",
))

_r(ModelSpec(
    id="groq/llama-3.3-70b",
    provider="groq",
    litellm_model="groq/llama-3.3-70b-versatile",
    display_name="Llama 3.3 70B (Groq)",
    input_cost=0.59, output_cost=0.79,
    context_window=128_000,
    capabilities=frozenset({Capability.CODE, Capability.FAST}),
    min_tier=TaskTier.TRIVIAL, max_tier=TaskTier.OPERATIONAL,
    speed_tps=1200,
    notes="Free tier available; ultra-fast",
))

_r(ModelSpec(
    id="anthropic/haiku-4.5",
    provider="anthropic",
    litellm_model="anthropic/claude-haiku-4-5-20251001",
    display_name="Claude Haiku 4.5",
    input_cost=1.00, output_cost=5.00,
    context_window=200_000,
    capabilities=frozenset({Capability.CODE, Capability.TOOL_USE}),
    min_tier=TaskTier.TRIVIAL, max_tier=TaskTier.STANDARD,
    cache_read_cost=0.10,
    batch_discount=0.5,
    speed_tps=150,
    notes="Fast, cheap, good for debug and validation",
))

_r(ModelSpec(
    id="google/gemini-2.5-flash",
    provider="google",
    litellm_model="gemini/gemini-2.5-flash-preview-05-20",
    display_name="Gemini 2.5 Flash",
    input_cost=0.15, output_cost=0.60,
    context_window=1_048_576,
    capabilities=frozenset({Capability.CODE, Capability.FAST, Capability.LONG_CONTEXT, Capability.THINKING}),
    min_tier=TaskTier.TRIVIAL, max_tier=TaskTier.STANDARD,
    speed_tps=350,
    notes="Free tier: 500 req/day; great for planning",
))

# --- Tier: STANDARD (< $10 effective) ---

_r(ModelSpec(
    id="google/gemini-2.5-pro",
    provider="google",
    litellm_model="gemini/gemini-2.5-pro-preview-05-06",
    display_name="Gemini 2.5 Pro",
    input_cost=1.25, output_cost=10.00,
    context_window=1_048_576,
    capabilities=frozenset({Capability.CODE, Capability.REASONING, Capability.THINKING,
                           Capability.LONG_CONTEXT, Capability.TOOL_USE}),
    min_tier=TaskTier.OPERATIONAL, max_tier=TaskTier.COMPLEX,
    speed_tps=200,
    notes="Free tier: 1000 req/day via AI Studio; excellent for architecture",
))

_r(ModelSpec(
    id="anthropic/sonnet-4.6",
    provider="anthropic",
    litellm_model="anthropic/claude-sonnet-4-6-20250514",
    display_name="Claude Sonnet 4.6",
    input_cost=3.00, output_cost=15.00,
    context_window=200_000,
    capabilities=frozenset({Capability.CODE, Capability.REASONING, Capability.TOOL_USE}),
    min_tier=TaskTier.OPERATIONAL, max_tier=TaskTier.COMPLEX,
    cache_read_cost=0.30,
    batch_discount=0.5,
    speed_tps=120,
    notes="Best balanced model for daily coding",
))

_r(ModelSpec(
    id="openai/gpt-4.1",
    provider="openai",
    litellm_model="openai/gpt-4.1",
    display_name="GPT-4.1",
    input_cost=2.00, output_cost=8.00,
    context_window=1_047_576,
    capabilities=frozenset({Capability.CODE, Capability.REASONING, Capability.TOOL_USE,
                           Capability.LONG_CONTEXT}),
    min_tier=TaskTier.OPERATIONAL, max_tier=TaskTier.COMPLEX,
    speed_tps=100,
    notes="1M context; solid coding; direct GPT-4.5 successor",
))

_r(ModelSpec(
    id="mistral/codestral-2501",
    provider="mistral",
    litellm_model="mistral/codestral-2501",
    display_name="Codestral 2501",
    input_cost=0.30, output_cost=0.90,
    context_window=256_000,
    capabilities=frozenset({Capability.CODE, Capability.FAST}),
    min_tier=TaskTier.TRIVIAL, max_tier=TaskTier.STANDARD,
    speed_tps=180,
    notes="Specialized code model; very cheap",
))

# --- Tier: COMPLEX ($10–20 effective) ---

_r(ModelSpec(
    id="openrouter/kimi-k2.5",
    provider="openrouter",
    litellm_model="openrouter/moonshotai/kimi-k2.5",
    display_name="Kimi K2.5 (Moonshot)",
    input_cost=1.00, output_cost=4.00,
    context_window=131_072,
    capabilities=frozenset({Capability.CODE, Capability.REASONING, Capability.THINKING}),
    min_tier=TaskTier.OPERATIONAL, max_tier=TaskTier.COMPLEX,
    speed_tps=80,
    notes="Agent Swarm mode; good thinking; via OpenRouter",
))

_r(ModelSpec(
    id="openrouter/swe-1.5",
    provider="openrouter",
    litellm_model="openrouter/all-hands/openhands-lm-32b-v0.1",
    display_name="SWE-1.5 (OpenHands)",
    input_cost=0.80, output_cost=0.80,
    context_window=131_072,
    capabilities=frozenset({Capability.CODE, Capability.TOOL_USE}),
    min_tier=TaskTier.OPERATIONAL, max_tier=TaskTier.STANDARD,
    speed_tps=90,
    notes="Specialized for SWE tasks; cheap via OpenRouter",
))

_r(ModelSpec(
    id="openai/gpt-5.4",
    provider="openai",
    litellm_model="openai/gpt-5.4",
    display_name="GPT-5.4",
    input_cost=2.50, output_cost=15.00,
    context_window=1_047_576,
    capabilities=frozenset({Capability.CODE, Capability.REASONING, Capability.THINKING,
                           Capability.LONG_CONTEXT, Capability.TOOL_USE, Capability.VISION}),
    min_tier=TaskTier.STANDARD, max_tier=TaskTier.DEEP_REASONING,
    speed_tps=90,
    notes="Deep reasoning; good for hard debugging",
))

# --- Tier: DEEP REASONING ($15+ effective) ---

_r(ModelSpec(
    id="anthropic/opus-4.6",
    provider="anthropic",
    litellm_model="anthropic/claude-opus-4-6",
    display_name="Claude Opus 4.6",
    input_cost=5.00, output_cost=25.00,
    context_window=1_000_000,
    capabilities=frozenset({Capability.CODE, Capability.REASONING, Capability.THINKING,
                           Capability.LONG_CONTEXT, Capability.TOOL_USE, Capability.VISION}),
    min_tier=TaskTier.COMPLEX, max_tier=TaskTier.DEEP_REASONING,
    cache_read_cost=0.50,
    batch_discount=0.5,
    speed_tps=60,
    notes="Highest quality coding; use only for complex tasks",
))

_r(ModelSpec(
    id="deepseek/r1",
    provider="deepseek",
    litellm_model="deepseek/deepseek-reasoner",
    display_name="DeepSeek R1",
    input_cost=0.55, output_cost=2.19,
    context_window=128_000,
    capabilities=frozenset({Capability.REASONING, Capability.THINKING}),
    min_tier=TaskTier.STANDARD, max_tier=TaskTier.DEEP_REASONING,
    speed_tps=40,
    notes="Best cost/quality for deep reasoning tasks",
))

# --- Local models (Ollama — $0) ---

_r(ModelSpec(
    id="ollama/qwen2.5-coder-3b",
    provider="ollama",
    litellm_model="ollama/qwen2.5-coder:3b",
    display_name="Qwen2.5-Coder 3B (local)",
    input_cost=0.0, output_cost=0.0,
    context_window=32_768,
    capabilities=frozenset({Capability.CODE, Capability.FAST}),
    min_tier=TaskTier.TRIVIAL, max_tier=TaskTier.OPERATIONAL,
    speed_tps=20,
    notes="Jetson Orin 8GB / RPi 5 compatible",
))


# ============================================================
# Tier-based model selection helpers
# ============================================================

def models_for_tier(tier: TaskTier, required_caps: frozenset[Capability] | None = None,
                    available_providers: set[str] | None = None) -> list[ModelSpec]:
    """Return models suitable for a tier, sorted by effective cost ascending."""
    results = []
    for m in MODELS.values():
        if tier.rank < m.min_tier.rank:
            continue
        if tier.rank > m.max_tier.rank:
            continue
        if required_caps and not required_caps.issubset(m.capabilities):
            continue
        if available_providers and m.provider not in available_providers:
            continue
        results.append(m)
    return sorted(results, key=lambda m: m.effective_cost)


def cheapest_model(tier: TaskTier, available_providers: set[str] | None = None,
                   required_caps: frozenset[Capability] | None = None) -> ModelSpec | None:
    """Return the single cheapest model that satisfies constraints."""
    candidates = models_for_tier(tier, required_caps, available_providers)
    return candidates[0] if candidates else None


def get_model(model_id: str) -> ModelSpec | None:
    return MODELS.get(model_id)
