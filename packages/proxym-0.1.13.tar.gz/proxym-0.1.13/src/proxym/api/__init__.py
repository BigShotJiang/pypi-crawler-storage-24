"""API sub-package — routers split from the monolithic main.py.

Import the individual routers and include them in the FastAPI app.
"""

from proxym.api.completions import router as completions_router
from proxym.api.context_api import router as context_router
from proxym.api.frontend import router as frontend_router
from proxym.api.system import router as system_router

__all__ = [
    "completions_router",
    "context_router",
    "frontend_router",
    "system_router",
]
