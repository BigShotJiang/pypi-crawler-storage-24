"""Chat completions endpoint — delegates to CompletionPipeline.

The endpoint is a thin wrapper; all logic lives in _pipeline.py.
"""

from __future__ import annotations

from fastapi import APIRouter, Header, Request

from proxym.api._pipeline import CompletionPipeline

router = APIRouter()


@router.post("/v1/chat/completions")
async def chat_completions(
    request: Request,
    x_task_tier: str | None = Header(None, alias="X-Task-Tier"),
):
    """OpenAI-compatible chat completions with intelligent routing.

    Extra headers:
      X-Task-Tier: trivial|operational|standard|complex|deep
      X-Inject-Context: true  (inject latest delta context)
      X-Working-Directory: /path/to/project  (project detection)
      X-Session-Id: abc123  (session continuity)
      X-Enable-Tools: true  (inject MCP tools based on context)
    """
    body = await request.json()
    pipeline = CompletionPipeline(body, x_task_tier, headers=dict(request.headers))
    return await pipeline.execute()
