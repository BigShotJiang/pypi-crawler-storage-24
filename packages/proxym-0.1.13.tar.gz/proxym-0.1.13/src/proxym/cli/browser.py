"""CLI commands: browser list/assign/sync/snapshot — extracted from ctl.py."""

from __future__ import annotations

import sys

from proxym.cli._client import make_client, print_table


def cmd_browser_list(args):
    """List detected browser profiles on the host."""
    try:
        from proxym.virt.browser_profiles import detect_all_profiles
    except ImportError:
        print("\033[31mBrowser profiles module not available.\033[0m")
        sys.exit(1)
    profiles = detect_all_profiles()
    if not profiles:
        print("No browser profiles detected.")
        return
    rows = []
    for p in profiles:
        rows.append({
            "browser": p.browser,
            "name": p.name,
            "path": str(p.path)[:50],
            "size": f"{p.size_mb:.1f}MB",
            "sessions": "✓" if p.has_sessions else "✗",
            "accounts": ", ".join(p.accounts_detected[:3]) or "-",
        })
    print_table(rows, ["browser", "name", "path", "size", "sessions", "accounts"])


def cmd_browser_assign(args):
    """Assign a browser profile to an account."""
    c = make_client(args.proxy, args.key)
    result = c.post(f"/dashboard/accounts/{args.account}/bind-tool", json={
        "tool_type": "browser",
        "tool_name": f"browser-{args.profile}",
        "browser_profile": args.profile,
    }).json()
    if result.get("ok"):
        print(f"\033[32mProfile '{args.profile}' assigned to account {args.account}\033[0m")
    else:
        print("\033[31mFailed to assign profile\033[0m")


def cmd_browser_sync(args):
    """Sync browser profile host ↔ VM."""
    c = make_client(args.proxy, args.key)
    result = c.post(f"/dashboard/vms/{args.vm_id}/browser-sync").json()
    if result.get("ok"):
        print(f"\033[32mBrowser profile synced for VM {args.vm_id}\033[0m")
    else:
        print("\033[31mFailed to sync browser profile\033[0m")


def cmd_browser_snapshot(args):
    """Save browser state from VM as snapshot."""
    c = make_client(args.proxy, args.key)
    result = c.post(f"/dashboard/vms/{args.vm_id}/browser-snapshot").json()
    if result.get("ok"):
        print(f"\033[32mBrowser snapshot saved for VM {args.vm_id}\033[0m")
    else:
        print("\033[31mFailed to snapshot browser\033[0m")
