// Dashboard API client — HTTP helpers and configuration.
// Loaded as a <script> before panel.jsx; exposes globals.
// Uses lazy access to APP_CONFIG so the async /config fetch has time to complete.

function _api()  { return window.APP_CONFIG?.api_url || "http://localhost:4000"; }
function _key()  { return window.APP_CONFIG?.api_key || "sk-proxy-local-dev"; }
function _debug(){ return window.APP_CONFIG?.debug || false; }

function _headers() { return { Authorization: `Bearer ${_key()}`, "Content-Type": "application/json" }; }
const get = (path) => fetch(`${_api()}${path}`, { headers: _headers() }).then(r => r.ok ? r.json() : null).catch(() => null);
const post = (path, body) => fetch(`${_api()}${path}`, { method: "POST", headers: _headers(), body: JSON.stringify(body) }).then(r => r.ok ? r.json() : null).catch(() => null);
