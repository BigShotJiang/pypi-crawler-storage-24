from .__main__ import server as app  # noqa: F401

version = "0.0.15"
