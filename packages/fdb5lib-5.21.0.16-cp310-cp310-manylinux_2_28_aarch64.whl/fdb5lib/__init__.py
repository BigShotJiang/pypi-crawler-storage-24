__version__ = '5.21.0.16'
__commit_hash__ = '8a42f438686f700614d38d1af88c7c7a8b2762d8'
findlibs_dependencies = ["eckitlib", "eccodeslib", "metkitlib"]
