from __future__ import annotations

import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from gh_llm.commands.options import raise_unknown_option_value
from gh_llm.github_api import GitHubClient
from gh_llm.invocation import display_command_with
from gh_llm.pager import DEFAULT_PAGE_SIZE, TimelinePager
from gh_llm.render import (
    render_checks_section,
    render_comment_node_detail,
    render_description,
    render_event_detail,
    render_event_detail_blocks,
    render_expand_hints,
    render_frontmatter,
    render_header,
    render_hidden_gap,
    render_mergeability_section,
    render_page,
    render_pr_actions,
)

if TYPE_CHECKING:
    from gh_llm.models import PullRequestMeta, TimelineContext, TimelinePage

DEFAULT_DIFF_HUNK_LINES = 12


@dataclass(frozen=True)
class _ExpandOptions:
    resolved: bool = False
    minimized: bool = False
    details: bool = False


@dataclass(frozen=True)
class _ShowOptions:
    meta: bool = True
    description: bool = True
    timeline: bool = True
    checks: bool = True
    actions: bool = True
    mergeability: bool = True


def register_pr_parser(subparsers: Any) -> None:
    pr_parser = subparsers.add_parser("pr", help="PR-related commands")
    pr_subparsers = pr_parser.add_subparsers(dest="pr_command")

    view_parser = pr_subparsers.add_parser(
        "view",
        help="show first/last timeline page with real GitHub cursor pagination",
    )
    view_parser.add_argument("pr", nargs="?", help="PR number/url/branch")
    view_parser.add_argument("--repo", help="repository in OWNER/REPO format")
    view_parser.add_argument("--page-size", type=int, default=DEFAULT_PAGE_SIZE, help="timeline entries per page")
    view_parser.add_argument(
        "--show",
        action="append",
        default=[],
        help="show regions: meta, description, timeline, checks, actions, mergeability, all (comma-separated or repeatable)",
    )
    view_parser.add_argument(
        "--expand",
        action="append",
        default=[],
        help="auto-expand folded content: resolved, minimized, details, all (comma-separated or repeatable)",
    )
    view_parser.add_argument(
        "--diff-hunk-lines",
        type=int,
        default=DEFAULT_DIFF_HUNK_LINES,
        help="max lines for each review diff hunk (<=0 means full)",
    )
    view_parser.set_defaults(handler=cmd_pr_view)

    timeline_expand_parser = pr_subparsers.add_parser("timeline-expand", help="load one timeline page by number")
    timeline_expand_parser.add_argument("page", type=int, help="1-based page number")
    timeline_expand_parser.add_argument("--pr", help="PR number/url/branch")
    timeline_expand_parser.add_argument("--repo", help="repository in OWNER/REPO format")
    timeline_expand_parser.add_argument("--page-size", type=int, help="timeline entries per page")
    timeline_expand_parser.add_argument(
        "--expand",
        action="append",
        default=[],
        help="auto-expand folded content: resolved, minimized, details, all (comma-separated or repeatable)",
    )
    timeline_expand_parser.add_argument(
        "--diff-hunk-lines",
        type=int,
        default=DEFAULT_DIFF_HUNK_LINES,
        help="max lines for each review diff hunk (<=0 means full)",
    )
    timeline_expand_parser.set_defaults(handler=cmd_pr_timeline_expand)

    details_expand_parser = pr_subparsers.add_parser(
        "details-expand",
        help="show collapsed <details>/<summary> blocks for one timeline event",
    )
    details_expand_parser.add_argument("index", type=int, help="1-based event index from timeline view")
    details_expand_parser.add_argument("--pr", help="PR number/url/branch")
    details_expand_parser.add_argument("--repo", help="repository in OWNER/REPO format")
    details_expand_parser.add_argument("--page-size", type=int, help="timeline entries per page")
    details_expand_parser.set_defaults(handler=cmd_pr_details_expand)

    review_expand_parser = pr_subparsers.add_parser(
        "review-expand",
        help="expand resolved review comments for one or more review IDs",
    )
    review_expand_parser.add_argument(
        "review_ids",
        nargs="+",
        help="review ids, supports values like `PRR_xxx`, `PRR_xxx,PRR_yyy`",
    )
    review_expand_parser.add_argument("--pr", help="PR number/url/branch")
    review_expand_parser.add_argument("--repo", help="repository in OWNER/REPO format")
    review_expand_parser.add_argument("--page-size", type=int, help="timeline entries per page")
    review_expand_parser.add_argument(
        "--threads",
        help="expand specific conversation range like 6-16 (1-based, within current review conversation order)",
    )
    review_expand_parser.add_argument(
        "--diff-hunk-lines",
        type=int,
        default=DEFAULT_DIFF_HUNK_LINES,
        help="max lines for each review diff hunk (<=0 means full)",
    )
    review_expand_parser.set_defaults(handler=cmd_pr_review_expand)

    thread_expand_parser = pr_subparsers.add_parser("thread-expand", help="expand one review thread by thread ID")
    thread_expand_parser.add_argument("thread_id", help="review thread id, e.g. PRRT_xxx")
    thread_expand_parser.add_argument("--pr", help="PR number/url/branch")
    thread_expand_parser.add_argument("--repo", help="repository in OWNER/REPO format")
    thread_expand_parser.add_argument(
        "--diff-hunk-lines",
        type=int,
        default=DEFAULT_DIFF_HUNK_LINES,
        help="max lines for each review diff hunk (<=0 means full)",
    )
    thread_expand_parser.set_defaults(handler=cmd_pr_thread_expand)

    checks_parser = pr_subparsers.add_parser("checks", help="show CI checks for the pull request")
    checks_parser.add_argument("--pr", help="PR number/url/branch")
    checks_parser.add_argument("--repo", help="repository in OWNER/REPO format")
    checks_parser.add_argument("--all", action="store_true", help="show all checks including passed")
    checks_parser.set_defaults(handler=cmd_pr_checks)

    conflicts_parser = pr_subparsers.add_parser(
        "conflict-files",
        help="detect and show conflicted files for a PR (on demand; may take longer on large repos)",
    )
    conflicts_parser.add_argument("--pr", help="PR number/url/branch")
    conflicts_parser.add_argument("--repo", help="repository in OWNER/REPO format")
    conflicts_parser.set_defaults(handler=cmd_pr_conflict_files)

    thread_reply_parser = pr_subparsers.add_parser("thread-reply", help="reply to a pull request review thread")
    thread_reply_parser.add_argument("thread_id", help="review thread id, e.g. PRRT_xxx")
    thread_reply_parser.add_argument("--body", required=True, help="reply body")
    thread_reply_parser.add_argument("--pr", help="PR number/url/branch")
    thread_reply_parser.add_argument("--repo", help="repository in OWNER/REPO format")
    thread_reply_parser.set_defaults(handler=cmd_pr_thread_reply)

    thread_resolve_parser = pr_subparsers.add_parser(
        "thread-resolve", help="mark a pull request review thread as resolved"
    )
    thread_resolve_parser.add_argument("thread_id", help="review thread id, e.g. PRRT_xxx")
    thread_resolve_parser.add_argument("--pr", help="PR number/url/branch")
    thread_resolve_parser.add_argument("--repo", help="repository in OWNER/REPO format")
    thread_resolve_parser.set_defaults(handler=cmd_pr_thread_resolve)

    thread_unresolve_parser = pr_subparsers.add_parser(
        "thread-unresolve", help="mark a pull request review thread as unresolved"
    )
    thread_unresolve_parser.add_argument("thread_id", help="review thread id, e.g. PRRT_xxx")
    thread_unresolve_parser.add_argument("--pr", help="PR number/url/branch")
    thread_unresolve_parser.add_argument("--repo", help="repository in OWNER/REPO format")
    thread_unresolve_parser.set_defaults(handler=cmd_pr_thread_unresolve)

    comment_edit_parser = pr_subparsers.add_parser("comment-edit", help="edit one issue/review comment by node id")
    comment_edit_parser.add_argument("comment_id", help="comment id, e.g. IC_xxx or PRRC_xxx")
    comment_edit_parser.add_argument("--body", required=True, help="new comment body")
    comment_edit_parser.add_argument("--pr", help="PR number/url/branch")
    comment_edit_parser.add_argument("--repo", help="repository in OWNER/REPO format")
    comment_edit_parser.set_defaults(handler=cmd_pr_comment_edit)

    comment_expand_parser = pr_subparsers.add_parser("comment-expand", help="expand one comment by node id")
    comment_expand_parser.add_argument("comment_id", help="comment id, e.g. IC_xxx or PRRC_xxx")
    comment_expand_parser.add_argument("--pr", help="PR number/url/branch")
    comment_expand_parser.add_argument("--repo", help="repository in OWNER/REPO format")
    comment_expand_parser.set_defaults(handler=cmd_pr_comment_expand)

    review_start_parser = pr_subparsers.add_parser(
        "review-start",
        help="show review-oriented diff hunks and ready-to-run comment/suggestion commands",
    )
    review_start_parser.add_argument("--pr", help="PR number/url/branch")
    review_start_parser.add_argument("--repo", help="repository in OWNER/REPO format")
    review_start_parser.add_argument("--max-hunks", type=int, default=40, help="maximum hunks to render")
    review_start_parser.set_defaults(handler=cmd_pr_review_start)

    review_comment_parser = pr_subparsers.add_parser(
        "review-comment", help="add one inline review comment at a specific line"
    )
    review_comment_parser.add_argument("--path", required=True, help="file path in pull request")
    review_comment_parser.add_argument("--line", required=True, type=int, help="line number on selected side")
    review_comment_parser.add_argument("--side", choices=["RIGHT", "LEFT"], default="RIGHT", help="diff side")
    review_comment_parser.add_argument("--body", required=True, help="review comment body")
    review_comment_parser.add_argument("--pr", help="PR number/url/branch")
    review_comment_parser.add_argument("--repo", help="repository in OWNER/REPO format")
    review_comment_parser.set_defaults(handler=cmd_pr_review_comment)

    review_suggest_parser = pr_subparsers.add_parser(
        "review-suggest", help="add one inline review suggestion at a specific line"
    )
    review_suggest_parser.add_argument("--path", required=True, help="file path in pull request")
    review_suggest_parser.add_argument("--line", required=True, type=int, help="line number on selected side")
    review_suggest_parser.add_argument("--side", choices=["RIGHT", "LEFT"], default="RIGHT", help="diff side")
    review_suggest_parser.add_argument(
        "--body",
        default="Suggested change",
        help="review comment body before suggestion block",
    )
    review_suggest_parser.add_argument(
        "--suggestion",
        required=True,
        help="replacement content inserted inside ```suggestion block",
    )
    review_suggest_parser.add_argument("--pr", help="PR number/url/branch")
    review_suggest_parser.add_argument("--repo", help="repository in OWNER/REPO format")
    review_suggest_parser.set_defaults(handler=cmd_pr_review_suggest)

    review_submit_parser = pr_subparsers.add_parser(
        "review-submit", help="submit a top-level PR review (approve/request changes/comment)"
    )
    review_submit_parser.add_argument(
        "--event",
        choices=["COMMENT", "APPROVE", "REQUEST_CHANGES"],
        default="COMMENT",
        help="review event type",
    )
    review_submit_body_group = review_submit_parser.add_mutually_exclusive_group()
    review_submit_body_group.add_argument("--body", default="", help="review summary body")
    review_submit_body_group.add_argument(
        "-F",
        "--body-file",
        help="read review summary body from file (use `-` to read from standard input)",
    )
    review_submit_parser.add_argument("--pr", help="PR number/url/branch")
    review_submit_parser.add_argument("--repo", help="repository in OWNER/REPO format")
    review_submit_parser.set_defaults(handler=cmd_pr_review_submit)


def _read_body_file(path: str) -> str:
    if path == "-":
        return sys.stdin.read()
    return Path(path).read_text(encoding="utf-8")


def _resolve_review_submit_body(args: Any) -> str:
    body_file = getattr(args, "body_file", None)
    if body_file:
        return _read_body_file(str(body_file))
    return str(getattr(args, "body", ""))


def cmd_pr_view(args: Any) -> int:
    page_size = int(args.page_size)
    diff_hunk_lines = _resolve_diff_hunk_lines(args=args, default=DEFAULT_DIFF_HUNK_LINES)
    expand = _parse_expand_options(raw_values=list(getattr(args, "expand", [])))
    show = _parse_show_options(raw_values=list(getattr(args, "show", [])))
    client = GitHubClient()
    pager = TimelinePager(client)

    meta = client.resolve_pull_request(selector=args.pr, repo=args.repo)
    context, first_page, last_page = pager.build_initial(
        meta,
        page_size=page_size,
        show_resolved_details=expand.resolved,
        show_outdated_details=True,
        show_minimized_details=expand.minimized,
        show_details_blocks=expand.details,
        diff_hunk_lines=diff_hunk_lines,
    )
    shown_pages: set[int] = {1}

    wrote_output = False

    def print_block(lines: list[str]) -> None:
        nonlocal wrote_output
        if not lines:
            return
        if wrote_output:
            print()
        for line in lines:
            print(line)
        wrote_output = True

    if show.meta:
        print_block(render_frontmatter(context))
    if show.description:
        print_block(render_description(context))
    if show.timeline:
        print_block(["## Timeline"])
        print_block(render_page(1, context, first_page))

    if show.timeline and last_page is not None:
        trailing_pages: list[tuple[int, TimelinePage]] = []
        include_previous = context.total_pages > 2 and context.total_count % context.page_size != 0
        if include_previous:
            previous_page_number = context.total_pages - 1
            previous_page = pager.fetch_page(
                meta=meta,
                context=context,
                page=previous_page_number,
                show_resolved_details=expand.resolved,
                show_outdated_details=True,
                show_minimized_details=expand.minimized,
                show_details_blocks=expand.details,
                diff_hunk_lines=diff_hunk_lines,
            )
            trailing_pages.append((previous_page_number, previous_page))
            shown_pages.add(previous_page_number)

        trailing_pages.append((context.total_pages, last_page))
        shown_pages.add(context.total_pages)

        first_trailing_page = min(page_number for page_number, _ in trailing_pages)
        hidden_start = 2
        hidden_end = first_trailing_page - 1
        hidden_pages = list(range(hidden_start, hidden_end + 1)) if hidden_start <= hidden_end else []
        print_block(render_hidden_gap(context, hidden_pages))
        if hidden_pages:
            print()
        for index, (page_number, page_data) in enumerate(trailing_pages):
            if index > 0:
                print()
            for line in render_page(page_number, context, page_data):
                print(line)

    if show.timeline:
        print_block(render_expand_hints(context, shown_pages))
    checks: list[Any] = []
    if show.checks or show.mergeability:
        checks = client.fetch_checks(meta.ref) if meta.state == "OPEN" else []
    if show.checks:
        print_block(
            render_checks_section(
                context=context,
                checks=checks,
                show_all=False,
                is_open=(meta.state == "OPEN"),
            )
        )
    if show.actions:
        print_block(
            render_pr_actions(
                context,
                include_diff=True,
                include_manage=show.actions,
            )
        )
    if show.mergeability:
        print_block(render_mergeability_section(context=context, checks=checks))

    return 0


def cmd_pr_timeline_expand(args: Any) -> int:
    client = GitHubClient()
    pager = TimelinePager(client)
    context, meta = _resolve_context_and_meta(client=client, pager=pager, args=args)
    diff_hunk_lines = _resolve_diff_hunk_lines(args=args, default=DEFAULT_DIFF_HUNK_LINES)
    expand = _parse_expand_options(raw_values=list(getattr(args, "expand", [])))

    page = pager.fetch_page(
        meta=meta,
        context=context,
        page=int(args.page),
        show_resolved_details=expand.resolved,
        show_outdated_details=True,
        show_minimized_details=expand.minimized,
        show_details_blocks=expand.details,
        diff_hunk_lines=diff_hunk_lines,
    )

    for line in render_header(context):
        print(line)
    print("## Timeline")
    for line in render_page(int(args.page), context, page):
        print(line)

    return 0


def cmd_pr_details_expand(args: Any) -> int:
    client = GitHubClient()
    pager = TimelinePager(client)
    context, meta = _resolve_context_and_meta(client=client, pager=pager, args=args)

    index = int(args.index)
    if index < 1 or index > context.total_count:
        raise RuntimeError(f"invalid event index {index}, expected in 1..{context.total_count}")

    page_number = ((index - 1) // context.page_size) + 1
    page = pager.fetch_page(
        meta=meta,
        context=context,
        page=page_number,
        show_resolved_details=True,
        show_outdated_details=True,
        show_minimized_details=True,
        show_details_blocks=True,
        diff_hunk_lines=None,
    )

    page_start = (page_number - 1) * context.page_size + 1
    offset = index - page_start
    if offset < 0 or offset >= len(page.items):
        raise RuntimeError("event index is outside loaded page range")

    for line in render_event_detail_blocks(index=index, event=page.items[offset]):
        print(line)
    return 0


def cmd_pr_review_expand(args: Any) -> int:
    client = GitHubClient()
    pager = TimelinePager(client)
    context, meta = _resolve_context_and_meta(client=client, pager=pager, args=args)
    review_ids = parse_review_ids(args.review_ids)
    thread_range = _parse_thread_range(getattr(args, "threads", None))
    diff_hunk_lines = _resolve_diff_hunk_lines(args=args, default=DEFAULT_DIFF_HUNK_LINES)
    if diff_hunk_lines is not None:
        print("Δ Diff hunk window is limited; rerun with `--diff-hunk-lines 0` for full review diff context.")
        print()

    if thread_range is not None:
        start, end = thread_range
        for review_id in review_ids:
            print(f"## Review {review_id}")
            lines = client.expand_review(
                ref=meta.ref,
                review_id=review_id,
                thread_start=start,
                thread_end=end,
                show_resolved_details=False,
                show_details_blocks=False,
                diff_hunk_lines=diff_hunk_lines,
            )
            for line in lines:
                print(line)
            print()
        return 0

    matched: dict[str, tuple[int, TimelinePage]] = {}
    for page_number in range(1, context.total_pages + 1):
        page = pager.fetch_page(
            meta=meta,
            context=context,
            page=page_number,
            show_resolved_details=True,
            show_outdated_details=True,
            show_minimized_details=True,
            show_details_blocks=False,
            review_threads_window=None,
            diff_hunk_lines=diff_hunk_lines,
        )
        for offset, event in enumerate(page.items):
            if not event.kind.startswith("review/"):
                continue
            if event.source_id in review_ids:
                event_index = ((page_number - 1) * context.page_size) + offset + 1
                matched[event.source_id] = (event_index, page)
        if len(matched) == len(review_ids):
            break

    for review_id in review_ids:
        item = matched.get(review_id)
        if item is None:
            print(f"## Review {review_id}")
            print("(not found on this PR timeline)")
            print()
            continue

        event_index, page = item
        page_start = (event_index - 1) // context.page_size * context.page_size + 1
        offset = event_index - page_start
        event = page.items[offset]
        for line in render_event_detail(index=event_index, event=event):
            print(line)
        print()

    return 0


def cmd_pr_thread_expand(args: Any) -> int:
    client = GitHubClient()
    meta = _resolve_pr_meta(client=client, args=args)
    diff_hunk_lines = _resolve_diff_hunk_lines(args=args, default=DEFAULT_DIFF_HUNK_LINES)
    review_id, lines = client.expand_review_thread(
        ref=meta.ref,
        thread_id=str(args.thread_id),
        show_details_blocks=False,
        diff_hunk_lines=diff_hunk_lines,
    )
    print(f"## Review Thread {args.thread_id}")
    print(f"review_id: {review_id}")
    for line in lines:
        print(line)
    return 0


def cmd_pr_checks(args: Any) -> int:
    client = GitHubClient()
    pager = TimelinePager(client)
    context, meta = _resolve_context_and_meta(client=client, pager=pager, args=args)
    checks = client.fetch_checks(meta.ref)
    for line in render_checks_section(
        context=context,
        checks=checks,
        show_all=bool(args.all),
        is_open=(meta.state == "OPEN"),
    ):
        print(line)
    return 0


def cmd_pr_conflict_files(args: Any) -> int:
    client = GitHubClient()
    meta = _resolve_pr_meta(client=client, args=args)
    files = client.fetch_conflict_files(meta)
    repo = f"{meta.ref.owner}/{meta.ref.name}"
    print("## Conflict Files")
    print(f"PR: {meta.ref.number} ({repo})")
    if not files:
        print("(no conflicted files detected, or unable to detect)")
        return 0
    for path in files:
        print(f"- `{path}`")
    return 0


def cmd_pr_thread_reply(args: Any) -> int:
    client = GitHubClient()
    if args.repo is not None and args.pr is None:
        raise RuntimeError("`--pr` is required when `--repo` is provided")
    if args.pr is not None:
        client.resolve_pull_request(selector=args.pr, repo=args.repo)

    comment_id = client.reply_review_thread(thread_id=str(args.thread_id), body=str(args.body))
    print(f"thread: {args.thread_id}")
    if comment_id:
        print(f"reply_comment_id: {comment_id}")
    print("status: replied")
    return 0


def cmd_pr_thread_resolve(args: Any) -> int:
    client = GitHubClient()
    if args.repo is not None and args.pr is None:
        raise RuntimeError("`--pr` is required when `--repo` is provided")
    if args.pr is not None:
        client.resolve_pull_request(selector=args.pr, repo=args.repo)

    resolved = client.resolve_review_thread(thread_id=str(args.thread_id))
    print(f"thread: {args.thread_id}")
    print(f"status: {'resolved' if resolved else 'unchanged'}")
    return 0


def cmd_pr_thread_unresolve(args: Any) -> int:
    client = GitHubClient()
    if args.repo is not None and args.pr is None:
        raise RuntimeError("`--pr` is required when `--repo` is provided")
    if args.pr is not None:
        client.resolve_pull_request(selector=args.pr, repo=args.repo)

    resolved = client.unresolve_review_thread(thread_id=str(args.thread_id))
    print(f"thread: {args.thread_id}")
    print(f"status: {'still_resolved' if resolved else 'unresolved'}")
    return 0


def cmd_pr_comment_edit(args: Any) -> int:
    client = GitHubClient()
    if args.repo is not None and args.pr is None:
        raise RuntimeError("`--pr` is required when `--repo` is provided")
    if args.pr is not None:
        client.resolve_pull_request(selector=args.pr, repo=args.repo)
    updated_comment_id = client.edit_comment(comment_id=str(args.comment_id), body=str(args.body))
    print(f"comment: {updated_comment_id}")
    print("status: edited")
    return 0


def cmd_pr_comment_expand(args: Any) -> int:
    client = GitHubClient()
    if args.repo is not None and args.pr is None:
        raise RuntimeError("`--pr` is required when `--repo` is provided")
    if args.pr is not None:
        client.resolve_pull_request(selector=args.pr, repo=args.repo)
    node = client.fetch_comment_node(str(args.comment_id))
    for line in render_comment_node_detail(str(args.comment_id), node):
        print(line)
    return 0


def cmd_pr_review_start(args: Any) -> int:
    client = GitHubClient()
    meta = _resolve_pr_meta(client=client, args=args)
    diff = client.fetch_pr_diff(selector=getattr(args, "pr", None), repo=getattr(args, "repo", None))
    hunks = _extract_diff_hunks(diff)
    max_hunks = max(1, int(args.max_hunks))
    visible = hunks[:max_hunks]
    hidden = len(hunks) - len(visible)
    repo = f"{meta.ref.owner}/{meta.ref.name}"

    print("## Review Start")
    print(f"PR: {meta.ref.number} ({repo})")
    print(f"Total hunks: {len(hunks)}")
    print(f"Δ full diff: `gh pr diff {meta.ref.number} --repo {repo}`")
    comment_template_cmd = display_command_with(
        f"pr review-comment --path '<path>' --line <line> --side RIGHT --body '<review_comment>' --pr {meta.ref.number} --repo {repo}"
    )
    suggestion_template_cmd = display_command_with(
        f"pr review-suggest --path '<path>' --line <line> --side RIGHT --body '<reason>' --suggestion '<replacement>' --pr {meta.ref.number} --repo {repo}"
    )
    print(f"Comment template: `{comment_template_cmd}`")
    print(f"Suggestion template: `{suggestion_template_cmd}`")
    print()

    if not visible:
        print("(no diff hunks found)")
        return 0

    for idx, hunk in enumerate(visible, start=1):
        print(f"### Hunk {idx}")
        print(f"File: {hunk.path}")
        print(f"Header: {hunk.header}")
        print(f"Suggested anchor line (RIGHT): {hunk.anchor_line}")
        comment_cmd = display_command_with(
            f"pr review-comment --path '{hunk.path}' --line {hunk.anchor_line} --side RIGHT --body '<review_comment>' --pr {meta.ref.number} --repo {repo}"
        )
        suggest_cmd = display_command_with(
            f"pr review-suggest --path '{hunk.path}' --line {hunk.anchor_line} --side RIGHT --body '<reason>' --suggestion '<replacement>' --pr {meta.ref.number} --repo {repo}"
        )
        print(f"⏎ comment: `{comment_cmd}`")
        print(f"⏎ suggest: `{suggest_cmd}`")
        print("```diff")
        for line in hunk.lines:
            print(line)
        print("```")
        print()

    if hidden > 0:
        print(f"... {hidden} hunks hidden by --max-hunks")
    return 0


def cmd_pr_review_comment(args: Any) -> int:
    client = GitHubClient()
    meta = _resolve_pr_meta(client=client, args=args)
    _validate_review_thread_target(
        client=client,
        args=args,
        path=str(args.path),
        line=int(args.line),
        side=str(args.side),
    )
    thread_id, comment_id = client.add_pull_request_review_thread_comment(
        ref=meta.ref,
        path=str(args.path),
        line=int(args.line),
        side=str(args.side),
        body=str(args.body),
    )
    print(f"thread: {thread_id}")
    if comment_id:
        print(f"comment: {comment_id}")
    print("status: commented")
    return 0


def cmd_pr_review_suggest(args: Any) -> int:
    client = GitHubClient()
    meta = _resolve_pr_meta(client=client, args=args)
    _validate_review_thread_target(
        client=client,
        args=args,
        path=str(args.path),
        line=int(args.line),
        side=str(args.side),
    )
    suggestion = str(args.suggestion).rstrip("\n")
    full_body = f"{str(args.body).rstrip()}\n\n```suggestion\n{suggestion}\n```"
    thread_id, comment_id = client.add_pull_request_review_thread_comment(
        ref=meta.ref,
        path=str(args.path),
        line=int(args.line),
        side=str(args.side),
        body=full_body,
    )
    print(f"thread: {thread_id}")
    if comment_id:
        print(f"comment: {comment_id}")
    print("status: suggested")
    return 0


def cmd_pr_review_submit(args: Any) -> int:
    client = GitHubClient()
    meta = _resolve_pr_meta(client=client, args=args)
    body = _resolve_review_submit_body(args)
    review_id, review_state = client.submit_pull_request_review(
        ref=meta.ref,
        event=str(args.event),
        body=body if body else None,
    )
    print(f"review: {review_id}")
    if review_state:
        print(f"state: {review_state}")
    print("status: submitted")
    return 0


def _resolve_context_and_meta(
    *, client: GitHubClient, pager: TimelinePager, args: Any
) -> tuple[TimelineContext, PullRequestMeta]:
    selector = getattr(args, "pr", None)
    repo = getattr(args, "repo", None)
    if repo is not None and selector is None:
        raise RuntimeError("`--pr` is required when `--repo` is provided")
    page_size = getattr(args, "page_size", None)
    effective_page_size = DEFAULT_PAGE_SIZE if page_size is None else int(page_size)
    diff_hunk_lines = _resolve_diff_hunk_lines(args=args, default=DEFAULT_DIFF_HUNK_LINES)
    meta = client.resolve_pull_request(selector=selector, repo=repo)
    context, _, _ = pager.build_initial(
        meta=meta,
        page_size=effective_page_size,
        diff_hunk_lines=diff_hunk_lines,
    )
    return context, meta


def _resolve_diff_hunk_lines(*, args: Any, default: int) -> int | None:
    raw = getattr(args, "diff_hunk_lines", None)
    if raw is None:
        raw = default
    value = int(raw)
    if value <= 0:
        return None
    return value


def _parse_expand_options(*, raw_values: list[str]) -> _ExpandOptions:
    resolved = False
    minimized = False
    details = False

    aliases: dict[str, str] = {
        "resolved": "resolved",
        "resolve": "resolved",
        "resolved_comments": "resolved",
        "resolved-comments": "resolved",
        "minimized": "minimized",
        "details": "details",
        "detail": "details",
        "all": "all",
        "*": "all",
    }
    valid_values = ["resolved", "minimized", "details", "all"]
    alias_values = [alias for alias in aliases if alias not in valid_values and alias != "*"]

    for raw in raw_values:
        for part in raw.split(","):
            token = part.strip().lower()
            if not token:
                continue
            normalized = aliases.get(token)
            if normalized is None:
                raise_unknown_option_value(
                    flag="expand",
                    token=token,
                    valid_values=valid_values,
                    alias_values=alias_values,
                )
            if normalized == "all":
                resolved = True
                minimized = True
                details = True
                continue
            if normalized == "resolved":
                resolved = True
            elif normalized == "minimized":
                minimized = True
            elif normalized == "details":
                details = True

    return _ExpandOptions(resolved=resolved, minimized=minimized, details=details)


def _parse_show_options(*, raw_values: list[str]) -> _ShowOptions:
    if not raw_values:
        return _ShowOptions()

    selected: set[str] = set()
    aliases: dict[str, set[str]] = {
        "meta": {"meta"},
        "description": {"description"},
        "desc": {"description"},
        "timeline": {"timeline"},
        "checks": {"checks"},
        "actions": {"actions"},
        "mergeability": {"mergeability"},
        "merge": {"mergeability"},
        "summary": {"meta", "description"},
        "all": {"meta", "description", "timeline", "checks", "actions", "mergeability"},
        "*": {"meta", "description", "timeline", "checks", "actions", "mergeability"},
    }
    valid_values = ["meta", "description", "timeline", "checks", "actions", "mergeability", "summary", "all"]
    alias_values = [alias for alias in aliases if alias not in valid_values and alias != "*"]

    for raw in raw_values:
        for part in raw.split(","):
            token = part.strip().lower()
            if not token:
                continue
            mapped = aliases.get(token)
            if mapped is None:
                raise_unknown_option_value(
                    flag="show",
                    token=token,
                    valid_values=valid_values,
                    alias_values=alias_values,
                )
            selected.update(mapped)

    return _ShowOptions(
        meta=("meta" in selected),
        description=("description" in selected),
        timeline=("timeline" in selected),
        checks=("checks" in selected),
        actions=("actions" in selected),
        mergeability=("mergeability" in selected),
    )


def _resolve_pr_meta(*, client: GitHubClient, args: Any) -> PullRequestMeta:
    selector = getattr(args, "pr", None)
    repo = getattr(args, "repo", None)
    if repo is not None and selector is None:
        raise RuntimeError("`--pr` is required when `--repo` is provided")
    return client.resolve_pull_request(selector=selector, repo=repo)


class _DiffHunk:
    def __init__(
        self,
        path: str,
        header: str,
        anchor_line: int,
        lines: list[str],
        *,
        left_commentable_lines: set[int],
        right_commentable_lines: set[int],
        match_paths: set[str],
    ) -> None:
        self.path = path
        self.header = header
        self.anchor_line = anchor_line
        self.lines = lines
        self.left_commentable_lines = left_commentable_lines
        self.right_commentable_lines = right_commentable_lines
        self.match_paths = match_paths


_HUNK_HEADER_RE = re.compile(r"^@@ -(?P<old>\d+)(?:,\d+)? \+(?P<new>\d+)(?:,\d+)? @@")


def _extract_diff_hunks(diff: str) -> list[_DiffHunk]:
    hunks: list[_DiffHunk] = []
    current_old_path = ""
    current_new_path = ""
    current_hunk_header = ""
    current_hunk_lines: list[str] = []
    current_old_line = 0
    current_new_line = 0
    current_anchor = 0
    current_fallback_anchor = 0
    current_left_commentable_lines: set[int] = set()
    current_right_commentable_lines: set[int] = set()

    def resolve_hunk_path() -> tuple[str, set[str]]:
        match_paths = {path for path in (current_old_path, current_new_path) if path}
        if current_new_path:
            return current_new_path, match_paths
        if current_old_path:
            return current_old_path, match_paths
        return "", match_paths

    def flush() -> None:
        nonlocal current_hunk_header, current_hunk_lines, current_anchor, current_fallback_anchor
        nonlocal current_left_commentable_lines, current_right_commentable_lines
        path, match_paths = resolve_hunk_path()
        if path and current_hunk_header and current_hunk_lines:
            anchor_line = (
                current_anchor if current_anchor > 0 else current_fallback_anchor if current_fallback_anchor > 0 else 1
            )
            hunks.append(
                _DiffHunk(
                    path=path,
                    header=current_hunk_header,
                    anchor_line=anchor_line,
                    lines=current_hunk_lines.copy(),
                    left_commentable_lines=current_left_commentable_lines.copy(),
                    right_commentable_lines=current_right_commentable_lines.copy(),
                    match_paths=match_paths,
                )
            )
        current_hunk_header = ""
        current_hunk_lines = []
        current_anchor = 0
        current_fallback_anchor = 0
        current_left_commentable_lines = set()
        current_right_commentable_lines = set()

    for raw in diff.splitlines():
        if raw.startswith("diff --git "):
            flush()
            current_old_path = ""
            current_new_path = ""
            continue
        if raw.startswith("--- "):
            flush()
            current_old_path = "" if raw == "--- /dev/null" else raw[len("--- a/") :]
            continue
        if raw.startswith("+++ "):
            flush()
            current_new_path = "" if raw == "+++ /dev/null" else raw[len("+++ b/") :]
            continue

        if raw.startswith("@@ "):
            flush()
            current_hunk_header = raw
            current_hunk_lines = [raw]
            match = _HUNK_HEADER_RE.match(raw)
            if match is None:
                current_old_line = 1
                current_new_line = 1
            else:
                current_old_line = int(match.group("old"))
                current_new_line = int(match.group("new"))
            continue

        if not current_hunk_header:
            continue

        current_hunk_lines.append(raw)
        if raw.startswith("+"):
            if current_anchor <= 0:
                current_anchor = current_new_line
            if current_fallback_anchor <= 0:
                current_fallback_anchor = current_new_line
            current_right_commentable_lines.add(current_new_line)
            current_new_line += 1
        elif raw.startswith(" "):
            if current_fallback_anchor <= 0:
                current_fallback_anchor = current_new_line
            current_left_commentable_lines.add(current_old_line)
            current_right_commentable_lines.add(current_new_line)
            current_old_line += 1
            current_new_line += 1
        elif raw.startswith("-"):
            current_left_commentable_lines.add(current_old_line)
            current_old_line += 1

    flush()
    return hunks


def _validate_review_thread_target(*, client: GitHubClient, args: Any, path: str, line: int, side: str) -> None:
    diff = client.fetch_pr_diff(selector=getattr(args, "pr", None), repo=getattr(args, "repo", None))
    hunks = _extract_diff_hunks(diff)
    path_hunks = [hunk for hunk in hunks if path in hunk.match_paths]
    if not path_hunks:
        raise RuntimeError(f"path is not part of the PR diff: {path}")

    commentable_lines = sorted(
        {
            candidate
            for hunk in path_hunks
            for candidate in (hunk.right_commentable_lines if side == "RIGHT" else hunk.left_commentable_lines)
        }
    )
    if line in commentable_lines:
        return

    if not commentable_lines:
        raise RuntimeError(
            f"line {line} on {side} is not a commentable diff line for {path}. "
            f"The current diff has no commentable lines on {side} for that file."
        )

    preview = ", ".join(str(candidate) for candidate in commentable_lines[:8])
    if len(commentable_lines) > 8:
        preview += ", ..."
    raise RuntimeError(
        f"line {line} on {side} is not a commentable diff line for {path}. "
        f"Try a line from the PR diff for that side instead (e.g. {preview})."
    )


def parse_event_indexes(raw_indexes: list[str]) -> list[int]:
    values: set[int] = set()
    for raw in raw_indexes:
        chunks = [chunk.strip() for chunk in raw.split(",") if chunk.strip()]
        for chunk in chunks:
            if "-" in chunk:
                left, right = chunk.split("-", 1)
                start = int(left)
                end = int(right)
                if start <= 0 or end <= 0:
                    raise RuntimeError(f"invalid index range: {chunk}")
                if start > end:
                    start, end = end, start
                values.update(range(start, end + 1))
                continue
            value = int(chunk)
            if value <= 0:
                raise RuntimeError(f"invalid event index: {value}")
            values.add(value)

    if not values:
        raise RuntimeError("no valid event indexes provided")
    return sorted(values)


def parse_review_ids(raw_review_ids: list[str]) -> list[str]:
    values: list[str] = []
    seen: set[str] = set()
    for raw in raw_review_ids:
        for token in [chunk.strip() for chunk in raw.split(",") if chunk.strip()]:
            if not token.startswith("PRR_"):
                raise RuntimeError(f"invalid review id: {token}")
            if token in seen:
                continue
            seen.add(token)
            values.append(token)
    if not values:
        raise RuntimeError("no valid review ids provided")
    return values


def _parse_thread_range(raw: str | None) -> tuple[int, int] | None:
    if raw is None:
        return None
    text = raw.strip()
    if not text:
        return None
    if "-" in text:
        left, right = text.split("-", 1)
    elif ".." in text:
        left, right = text.split("..", 1)
    else:
        left, right = text, text
    start = int(left)
    end = int(right)
    if start <= 0 or end <= 0:
        raise RuntimeError(f"invalid thread range: {text}")
    if start > end:
        start, end = end, start
    return start, end
