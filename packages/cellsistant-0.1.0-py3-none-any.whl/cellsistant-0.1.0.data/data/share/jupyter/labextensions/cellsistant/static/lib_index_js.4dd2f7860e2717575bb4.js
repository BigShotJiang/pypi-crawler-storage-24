"use strict";
(self["webpackChunkcellsistant"] = self["webpackChunkcellsistant"] || []).push([["lib_index_js"],{

/***/ "./lib/api.js"
/*!********************!*\
  !*** ./lib/api.js ***!
  \********************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   analyzeImage: () => (/* binding */ analyzeImage),
/* harmony export */   executeShell: () => (/* binding */ executeShell),
/* harmony export */   sendToLLM: () => (/* binding */ sendToLLM),
/* harmony export */   sendToLLMWithRetry: () => (/* binding */ sendToLLMWithRetry),
/* harmony export */   streamFromLLM: () => (/* binding */ streamFromLLM)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


/** Extracts XSRF token from cookie */
function getXsrfToken() {
    const match = document.cookie.match(new RegExp('(^|; )_xsrf=([^;]+)'));
    return match ? match[2] : '';
}
const DEFAULT_RETRY_CONFIG = {
    maxRetries: 3,
    baseDelay: 1000,
    maxDelay: 30000
};
/** Get Jupyter server settings */
function getServerSettings() {
    return _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
}
/** Build request headers with XSRF token */
function createRequestHeaders() {
    var _a;
    const settings = getServerSettings();
    const headers = {
        'Content-Type': 'application/json'
    };
    if ((_a = settings.init) === null || _a === void 0 ? void 0 : _a.headers) {
        const initHeaders = settings.init.headers;
        Object.assign(headers, initHeaders);
    }
    const xsrfToken = getXsrfToken();
    if (xsrfToken) {
        headers['X-XSRFToken'] = xsrfToken;
    }
    return headers;
}
/** Execute shell command via server endpoint */
async function executeShell(command, timeout, workingDir) {
    const settings = getServerSettings();
    const endpoint = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'ai-agent', 'shell');
    const body = { command };
    if (timeout) {
        body.timeout = timeout;
    }
    if (workingDir) {
        body.working_dir = workingDir;
    }
    const headers = createRequestHeaders();
    const response = await fetch(endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
        credentials: 'same-origin'
    });
    if (response.status === 403) {
        const text = await response.text();
        try {
            const data = JSON.parse(text);
            throw new Error(`Blocked: ${data.error || 'Access denied'}`);
        }
        catch (_a) {
            throw new Error(`Blocked: ${text.substring(0, 200)}`);
        }
    }
    if (response.status !== 200) {
        const text = await response.text();
        try {
            const data = JSON.parse(text);
            throw new Error(data.error || `Shell error: ${response.status}`);
        }
        catch (_b) {
            throw new Error(`Shell error ${response.status}: ${text.substring(0, 200)}`);
        }
    }
    return await response.json();
}
/** Analyze cell output image via Vision LLM */
async function analyzeImage(imageData, mimeType = 'image/png', cellIndex, context) {
    const settings = getServerSettings();
    const endpoint = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'ai-agent', 'analyze-image');
    const headers = createRequestHeaders();
    const body = {
        image_data: imageData,
        mime_type: mimeType
    };
    if (cellIndex !== undefined) {
        body.cell_index = cellIndex;
    }
    if (context) {
        body.context = context;
    }
    const response = await fetch(endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
        credentials: 'same-origin'
    });
    if (response.status !== 200) {
        const data = await response.json().catch(() => ({}));
        return {
            success: false,
            error: data.error || `Server error: ${response.status}`
        };
    }
    return await response.json();
}
/** Calculate exponential backoff delay */
function getRetryDelay(attempt, config) {
    const delay = config.baseDelay * Math.pow(2, attempt);
    return Math.min(delay, config.maxDelay);
}
/** Send messages to LLM with automatic retry */
async function sendToLLMWithRetry(messages, abortSignal, config = DEFAULT_RETRY_CONFIG) {
    var _a, _b, _c, _d, _e;
    let lastError = null;
    for (let attempt = 0; attempt <= config.maxRetries; attempt++) {
        try {
            const result = await sendToLLM(messages, abortSignal);
            return result;
        }
        catch (error) {
            lastError = error;
            const isRetryable = ((_a = error.message) === null || _a === void 0 ? void 0 : _a.includes('500')) ||
                ((_b = error.message) === null || _b === void 0 ? void 0 : _b.includes('502')) ||
                ((_c = error.message) === null || _c === void 0 ? void 0 : _c.includes('503')) ||
                ((_d = error.message) === null || _d === void 0 ? void 0 : _d.includes('504')) ||
                ((_e = error.message) === null || _e === void 0 ? void 0 : _e.includes('429')) ||
                error.retryable === true;
            if (!isRetryable || attempt >= config.maxRetries) {
                throw error;
            }
            const delay = getRetryDelay(attempt, config);
            console.log(`LLM request failed, retry ${attempt + 1}/${config.maxRetries} after ${delay}ms`);
            await new Promise(resolve => setTimeout(resolve, delay));
        }
    }
    throw lastError || new Error('Max retries exceeded');
}
/** Single API call: send messages, receive response */
async function sendToLLM(messages, abortSignal) {
    const settings = getServerSettings();
    const endpoint = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'ai-agent', 'chat');
    const headers = createRequestHeaders();
    const response = await fetch(endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify({ messages }),
        signal: abortSignal,
        credentials: 'same-origin'
    });
    if (abortSignal === null || abortSignal === void 0 ? void 0 : abortSignal.aborted) {
        throw new Error('Request cancelled');
    }
    if (response.status !== 200) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.error || `Server error: ${response.status}`);
    }
    return await response.json();
}
/** Stream LLM response via SSE */
async function streamFromLLM(messages, callbacks, abortSignal, askMode = false, imageAnalysisEnabled = true) {
    var _a, _b, _c, _d, _e, _f, _g, _h;
    const settings = getServerSettings();
    const endpoint = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'ai-agent', 'chat', 'stream');
    const headers = createRequestHeaders();
    const response = await fetch(endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify({
            messages,
            ask_mode: askMode,
            image_analysis_enabled: imageAnalysisEnabled
        }),
        signal: abortSignal
    });
    if (!response.ok) {
        const errorText = await response.text();
        callbacks.onError(`Server error ${response.status}: ${errorText}`);
        return;
    }
    const reader = (_a = response.body) === null || _a === void 0 ? void 0 : _a.getReader();
    if (!reader) {
        callbacks.onError('No response body');
        return;
    }
    const decoder = new TextDecoder();
    let fullContent = '';
    const toolCalls = new Map();
    let buffer = '';
    try {
        let done = false;
        while (!done) {
            const result = await reader.read();
            done = result.done;
            if (done) {
                break;
            }
            const value = result.value;
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';
            for (const line of lines) {
                const trimmed = line.trim();
                if (trimmed === 'event: done' || trimmed === 'data: [DONE]') {
                    const finalToolCalls = toolCalls.size > 0 ? Array.from(toolCalls.values()) : undefined;
                    callbacks.onDone({
                        role: 'assistant',
                        content: fullContent || null,
                        tool_calls: finalToolCalls
                    });
                    return;
                }
                if (trimmed.startsWith('event: error')) {
                    continue;
                }
                if (!trimmed.startsWith('data: ')) {
                    continue;
                }
                const jsonStr = trimmed.slice(6);
                try {
                    const chunk = JSON.parse(jsonStr);
                    if (chunk.error) {
                        callbacks.onError(typeof chunk.error === 'string'
                            ? chunk.error
                            : chunk.error.message || JSON.stringify(chunk.error));
                        return;
                    }
                    const delta = (_c = (_b = chunk.choices) === null || _b === void 0 ? void 0 : _b[0]) === null || _c === void 0 ? void 0 : _c.delta;
                    if (!delta) {
                        continue;
                    }
                    if (delta.content) {
                        fullContent += delta.content;
                        callbacks.onToken(delta.content);
                    }
                    if (delta.tool_calls) {
                        for (const tc of delta.tool_calls) {
                            const idx = (_d = tc.index) !== null && _d !== void 0 ? _d : 0;
                            if (!toolCalls.has(idx)) {
                                toolCalls.set(idx, {
                                    id: tc.id || '',
                                    type: 'function',
                                    function: {
                                        name: ((_e = tc.function) === null || _e === void 0 ? void 0 : _e.name) || '',
                                        arguments: ((_f = tc.function) === null || _f === void 0 ? void 0 : _f.arguments) || ''
                                    }
                                });
                            }
                            else {
                                const existing = toolCalls.get(idx);
                                if (tc.id) {
                                    existing.id = tc.id;
                                }
                                if ((_g = tc.function) === null || _g === void 0 ? void 0 : _g.name) {
                                    existing.function.name += tc.function.name;
                                }
                                if ((_h = tc.function) === null || _h === void 0 ? void 0 : _h.arguments) {
                                    existing.function.arguments += tc.function.arguments;
                                }
                            }
                        }
                    }
                }
                catch (_j) {
                    continue;
                }
            }
        }
        const finalToolCalls = toolCalls.size > 0 ? Array.from(toolCalls.values()) : undefined;
        callbacks.onDone({
            role: 'assistant',
            content: fullContent || null,
            tool_calls: finalToolCalls
        });
    }
    catch (error) {
        if (error.name === 'AbortError') {
            callbacks.onError('Request cancelled');
        }
        else {
            callbacks.onError(error.message || 'Stream error');
        }
    }
    finally {
        reader.releaseLock();
    }
}


/***/ },

/***/ "./lib/chat-panel.js"
/*!***************************!*\
  !*** ./lib/chat-panel.js ***!
  \***************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ChatPanel: () => (/* binding */ ChatPanel)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./api */ "./lib/api.js");
/* harmony import */ var _tool_registry__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./tool-registry */ "./lib/tool-registry.js");
/* harmony import */ var _permission_manager__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./permission-manager */ "./lib/permission-manager.js");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var highlight_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! highlight.js */ "webpack/sharing/consume/default/highlight.js/highlight.js");
/* harmony import */ var _token_counter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./token-counter */ "./lib/token-counter.js");
/* harmony import */ var _history_api__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./history-api */ "./lib/history-api.js");
/* harmony import */ var _context_collector__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./context-collector */ "./lib/context-collector.js");
/* harmony import */ var _variable_inspector__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./variable-inspector */ "./lib/variable-inspector.js");
/* harmony import */ var _settings_dialog__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./settings-dialog */ "./lib/settings-dialog.js");
/* harmony import */ var _settings_api__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./settings-api */ "./lib/settings-api.js");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_13__);














const DEFAULT_CONTEXT_CONFIG = {
    includeCellOutline: true,
    includeVariables: true,
    maxCellsInOutline: 20,
    maxVariables: 30,
    smartMode: true
};
/** Process inline markdown in table cells */
function parseInlineMarkdown(text) {
    let result = text;
    result = result.replace(/`(.+?)`/g, '<code class="inline-code">$1</code>');
    result = result.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    result = result.replace(/__(.+?)__/g, '<strong>$1</strong>');
    result = result.replace(/\*(.+?)\*/g, '<em>$1</em>');
    result = result.replace(/_(.+?)_/g, '<em>$1</em>');
    result = result.replace(/~~(.+?)~~/g, '<del>$1</del>');
    result = result.replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2" target="_blank">$1</a>');
    return result;
}
/** Simple markdown-to-HTML parser */
function parseMarkdown(text) {
    let html = text;
    html = html
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
    // Preserve tables during formatting
    const tables = [];
    html = html.replace(/^\|(.+)\|\n\|[-:| ]+\|\n((?:\|.*\|\n?)+)/gm, (_match, headerRow, bodyRows) => {
        const headers = headerRow
            .split('|')
            .filter((h) => h.trim())
            .map((h) => `<th>${parseInlineMarkdown(h.trim())}</th>`)
            .join('');
        const rows = bodyRows
            .trim()
            .split('\n')
            .map((row) => {
            const cells = row
                .split('|')
                .filter((c) => c.trim())
                .map((c) => `<td>${parseInlineMarkdown(c.trim())}</td>`)
                .join('');
            return `<tr>${cells}</tr>`;
        })
            .join('');
        tables.push(`<table><thead><tr>${headers}</tr></thead><tbody>${rows}</tbody></table>`);
        return `<!--TABLE${tables.length - 1}-->`;
    });
    // Preserve code blocks with syntax highlighting
    const codeBlocks = [];
    html = html.replace(/```(\w*)\n?([\s\S]*?)```/g, (_match, lang, code) => {
        const idx = codeBlocks.length;
        const langClass = lang ? `language-${lang}` : '';
        const highlighted = highlight_js__WEBPACK_IMPORTED_MODULE_6__["default"].highlightAuto(code).value;
        codeBlocks.push(`<pre class="code-block"><code class="${langClass}">${highlighted}</code></pre>`);
        return `<!--CODEBLOCK${idx}-->`;
    });
    // Inline code after blocks to avoid capturing ```
    html = html.replace(/`(.+?)`/g, '<code class="inline-code">$1</code>');
    // Bold text
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/__(.+?)__/g, '<strong>$1</strong>');
    // Italic text
    html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');
    html = html.replace(/_(.+?)_/g, '<em>$1</em>');
    // Strikethrough
    html = html.replace(/~~(.+?)~~/g, '<del>$1</del>');
    // Links
    html = html.replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2" target="_blank">$1</a>');
    // Bullet lists
    html = html.replace(/^[-*]\s+(.+)$/gm, '<li>$1</li>');
    html = html.replace(/(<li>.*<\/li>\n?)+/g, '<ul>$&</ul>');
    // Numbered lists
    html = html.replace(/^\d+\.\s+(.+)$/gm, '<li>$1</li>');
    // Headers
    html = html.replace(/^### (.+)$/gm, '<h3>$1</h3>');
    html = html.replace(/^## (.+)$/gm, '<h2>$1</h2>');
    html = html.replace(/^# (.+)$/gm, '<h1>$1</h1>');
    // Line breaks
    html = html.replace(/\n/g, '<br>');
    // Restore tables
    tables.forEach((table, i) => {
        html = html.replace(`<!--TABLE${i}-->`, table);
    });
    // Restore code blocks with action buttons
    codeBlocks.forEach((block, i) => {
        const buttons = `<div class="code-block-buttons">
      <button class="code-btn copy-btn" data-code="${i}" title="Copy">
        <span class="copy-icon"></span>
      </button>
      <button class="code-btn add-above-btn" data-code="${i}" title="Add to cell above">
        <span class="add-above-icon"></span>
      </button>
      <button class="code-btn add-below-btn" data-code="${i}" title="Add to cell below">
        <span class="add-below-icon"></span>
      </button>
    </div>`;
        html = html.replace(`<!--CODEBLOCK${i}-->`, `<div class="code-block-wrapper">${block}${buttons}</div>`);
    });
    return html;
}
/** Chat panel with agent loop */
class ChatPanel extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.MainAreaWidget {
    constructor(app, themeManager, notebookTracker) {
        super({ content: new _lumino_widgets__WEBPACK_IMPORTED_MODULE_1__.Widget({ node: document.createElement('div') }) });
        this.isLoading = false;
        this.abortController = null;
        this.lastUserMessage = null;
        this.conversationHistory = [];
        this.autoExecuteTools = true;
        this.askMode = false;
        // Chat history
        this.currentChatId = null;
        this.isHistoryLoading = false;
        this.contextConfig = DEFAULT_CONTEXT_CONFIG;
        this.lastContextNotebook = null;
        this.lastContextTimestamp = 0;
        // Settings
        this.maxAgentIterations = 15;
        this.themeManager = themeManager;
        this.notebookTracker = notebookTracker;
        this.id = 'jupyterlab-ai-agent-panel';
        this.title.closable = true;
        this.title.icon = _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_13__.codeIcon;
        // Initialize context collectors
        this.contextCollector = new _context_collector__WEBPACK_IMPORTED_MODULE_9__.ContextCollector(app, notebookTracker);
        this.variableInspector = new _variable_inspector__WEBPACK_IMPORTED_MODULE_10__.VariableInspector(notebookTracker);
        // Build UI structure
        this.createUI();
        // Listen for theme changes
        this.syncTheme();
        this.themeManager.themeChanged.connect(this.onThemeChanged, this);
        // Load settings on init
        this.loadSettingsFromServer();
    }
    createUI() {
        const container = this.content.node;
        container.className = 'ai-agent-container';
        container.style.position = 'relative';
        // Header with mode checkbox and panel buttons
        const header = document.createElement('div');
        header.className = 'ai-agent-header';
        const headerTop = document.createElement('div');
        headerTop.className = 'ai-agent-header-top';
        // Title
        const titleEl = document.createElement('h2');
        titleEl.textContent = 'Cellsistant';
        titleEl.style.margin = '0';
        titleEl.style.flex = '1';
        // History button
        const historyBtn = document.createElement('button');
        historyBtn.className = 'jp-Button ai-agent-history-btn';
        historyBtn.appendChild(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_13__.historyIcon.element());
        historyBtn.title = 'Chat History';
        historyBtn.addEventListener('click', () => this.toggleHistoryPanel());
        // Settings button
        const settingsBtn = document.createElement('button');
        settingsBtn.className = 'jp-Button ai-agent-settings-btn';
        settingsBtn.appendChild(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_13__.settingsIcon.element());
        settingsBtn.title = 'AI Agent Settings';
        settingsBtn.addEventListener('click', () => this.toggleSettingsPanel());
        headerTop.appendChild(titleEl);
        headerTop.appendChild(historyBtn);
        headerTop.appendChild(settingsBtn);
        header.appendChild(headerTop);
        container.appendChild(header);
        // History panel
        this.historyPanel = document.createElement('div');
        this.historyPanel.className = 'ai-agent-settings-panel ai-agent-hidden';
        container.appendChild(this.historyPanel);
        // Settings panel
        this.settingsPanel = document.createElement('div');
        this.settingsPanel.className = 'ai-agent-settings-panel ai-agent-hidden';
        container.appendChild(this.settingsPanel);
        // Messages area
        this.messagesArea = document.createElement('div');
        this.messagesArea.className = 'ai-agent-messages';
        container.appendChild(this.messagesArea);
        // Input area
        const inputContainer = document.createElement('div');
        inputContainer.className = 'ai-agent-input-container';
        this.inputField = document.createElement('textarea');
        this.inputField.className = 'ai-agent-input';
        this.inputField.placeholder =
            'Type a message... (Enter to send, Shift+Enter for new line)';
        this.inputField.rows = 3;
        this.sendButton = document.createElement('button');
        this.sendButton.className = 'jp-Button ai-agent-send-button';
        this.sendButton.textContent = 'Send';
        this.sendButton.title = 'Send';
        // Stop button (hidden initially)
        this.stopButton = document.createElement('button');
        this.stopButton.className =
            'jp-Button ai-agent-stop-button ai-agent-hidden';
        this.stopButton.textContent = 'Stop';
        this.stopButton.title = 'Stop';
        this.stopButton.addEventListener('click', () => this.handleStop());
        inputContainer.appendChild(this.inputField);
        inputContainer.appendChild(this.sendButton);
        inputContainer.appendChild(this.stopButton);
        container.appendChild(inputContainer);
        // Status bar with Ask mode checkbox and token counter
        const statusBar = document.createElement('div');
        statusBar.className = 'ai-agent-status-bar';
        // Ask mode checkbox
        const askModeContainer = document.createElement('label');
        askModeContainer.className = 'ai-agent-ask-mode';
        askModeContainer.title = 'Ask mode: read-only, no code execution';
        const askModeCheckbox = document.createElement('input');
        askModeCheckbox.type = 'checkbox';
        askModeCheckbox.className = 'ai-agent-ask-mode-checkbox';
        // Load saved state from localStorage
        const savedAskMode = localStorage.getItem('ai-agent-ask-mode');
        if (savedAskMode === 'true') {
            askModeCheckbox.checked = true;
            this.askMode = true;
        }
        askModeCheckbox.addEventListener('change', () => {
            this.askMode = askModeCheckbox.checked;
            localStorage.setItem('ai-agent-ask-mode', String(askModeCheckbox.checked));
        });
        const askModeLabel = document.createElement('span');
        askModeLabel.textContent = 'Ask';
        askModeContainer.appendChild(askModeCheckbox);
        askModeContainer.appendChild(askModeLabel);
        this.tokenCounter = document.createElement('span');
        this.tokenCounter.className = 'ai-agent-token-counter';
        this.tokenCounter.textContent = '';
        statusBar.appendChild(askModeContainer);
        statusBar.appendChild(this.tokenCounter);
        container.appendChild(statusBar);
        // Event handlers
        this.sendButton.addEventListener('click', () => this.handleUserMessage());
        this.inputField.addEventListener('keydown', e => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.handleUserMessage();
            }
            // Escape to cancel
            if (e.key === 'Escape' && this.isLoading) {
                e.preventDefault();
                this.handleStop();
            }
        });
        // Also catch Escape at container level
        container.addEventListener('keydown', e => {
            if (e.key === 'Escape' && this.isLoading) {
                e.preventDefault();
                this.handleStop();
            }
        });
        // Welcome message
        this.addBubble('assistant', 'Hello! I am AI Agent. I can write and execute code in your notebook. Try: "Write a fibonacci function and execute it"');
    }
    // ─────────────────────────────────────────────
    // UI helpers
    // ─────────────────────────────────────────────
    /** Scroll chat to bottom */
    scrollToBottom() {
        this.messagesArea.scrollTop = this.messagesArea.scrollHeight;
    }
    /** Add message bubble to chat */
    addBubble(role, text) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `ai-agent-message ${role}`;
        const roleLabel = document.createElement('span');
        roleLabel.className = 'ai-agent-message-role';
        roleLabel.textContent = role === 'user' ? 'You:' : 'AI:';
        const textDiv = document.createElement('div');
        textDiv.className = 'ai-agent-message-text';
        textDiv.innerHTML = parseMarkdown(text);
        messageDiv.appendChild(roleLabel);
        messageDiv.appendChild(textDiv);
        this.messagesArea.appendChild(messageDiv);
        this.scrollToBottom();
        this.addCodeBlockButtons(textDiv, text);
    }
    /** Add action buttons to code blocks */
    addCodeBlockButtons(textDiv, originalText) {
        const wrappers = textDiv.querySelectorAll('.code-block-wrapper');
        wrappers.forEach(wrapper => {
            const btnContainer = wrapper.querySelector('.code-block-buttons');
            if (!btnContainer) {
                return;
            }
            const copyBtn = btnContainer.querySelector('.copy-icon');
            const addAboveBtn = btnContainer.querySelector('.add-above-icon');
            const addBelowBtn = btnContainer.querySelector('.add-below-icon');
            if (copyBtn) {
                _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_13__.copyIcon.element({
                    container: copyBtn,
                    width: '14px',
                    height: '14px'
                });
            }
            if (addAboveBtn) {
                _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_13__.addAboveIcon.element({
                    container: addAboveBtn,
                    width: '14px',
                    height: '14px'
                });
            }
            if (addBelowBtn) {
                _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_13__.addBelowIcon.element({
                    container: addBelowBtn,
                    width: '14px',
                    height: '14px'
                });
            }
            const buttons = btnContainer.querySelectorAll('.code-btn');
            buttons.forEach(btn => {
                btn.addEventListener('click', () => {
                    const codeBlock = wrapper.querySelector('code');
                    const code = (codeBlock === null || codeBlock === void 0 ? void 0 : codeBlock.textContent) || '';
                    const btnType = btn.classList.contains('copy-btn')
                        ? 'copy'
                        : btn.classList.contains('add-above-btn')
                            ? 'above'
                            : 'below';
                    this.handleCodeBlockAction(code, btnType);
                });
            });
        });
    }
    /** Handle code block button actions */
    handleCodeBlockAction(code, action) {
        if (action === 'copy') {
            navigator.clipboard.writeText(code);
            this.showNotification('Code copied!', 'success');
        }
        else {
            this.addCodeToNotebook(code, action === 'above');
        }
    }
    /** Insert code into notebook cell */
    async addCodeToNotebook(code, addAbove) {
        var _a, _b, _c, _d;
        const notebook = this.notebookTracker.currentWidget;
        if (!notebook) {
            this.showNotification('No notebook open', 'error');
            return;
        }
        const notebookContent = notebook.content;
        const activeIndex = notebookContent.activeCellIndex;
        try {
            if (addAbove) {
                notebookContent.activeCellIndex = activeIndex;
                _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_5__.NotebookActions.insertBelow(notebookContent);
                await new Promise(resolve => setTimeout(resolve, 50));
                const newCell = (_b = (_a = notebookContent.model) === null || _a === void 0 ? void 0 : _a.cells) === null || _b === void 0 ? void 0 : _b.get(activeIndex);
                if (newCell) {
                    const cellAny = newCell;
                    if (cellAny.sharedModel) {
                        cellAny.sharedModel.setSource(code);
                    }
                    else if (cellAny.value) {
                        cellAny.value.text = code;
                    }
                }
            }
            else {
                _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_5__.NotebookActions.insertBelow(notebookContent);
                await new Promise(resolve => setTimeout(resolve, 50));
                const newIndex = activeIndex + 1;
                const newCell = (_d = (_c = notebookContent.model) === null || _c === void 0 ? void 0 : _c.cells) === null || _d === void 0 ? void 0 : _d.get(newIndex);
                if (newCell) {
                    const cellAny = newCell;
                    if (cellAny.sharedModel) {
                        cellAny.sharedModel.setSource(code);
                    }
                    else if (cellAny.value) {
                        cellAny.value.text = code;
                    }
                }
            }
            this.showNotification(`Code added to new cell ${addAbove ? 'above' : 'below'}`, 'success');
        }
        catch (error) {
            console.error('Error adding code:', error);
            this.showNotification('Failed to add code', 'error');
        }
    }
    /** Add error message with retry button */
    addErrorBubbleWithRetry(errorText) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'ai-agent-message assistant ai-agent-error-message';
        const roleLabel = document.createElement('span');
        roleLabel.className = 'ai-agent-message-role';
        roleLabel.textContent = 'AI:';
        const textDiv = document.createElement('div');
        textDiv.className = 'ai-agent-message-text';
        textDiv.innerHTML = parseMarkdown(errorText);
        const retryButton = document.createElement('button');
        retryButton.className = 'jp-Button ai-agent-retry-button';
        const retryIcon = _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_13__.redoIcon.element();
        retryIcon.style.width = '14px';
        retryIcon.style.height = '14px';
        retryButton.appendChild(retryIcon);
        retryButton.appendChild(document.createTextNode(' Retry'));
        retryButton.title = 'Retry last request';
        messageDiv.appendChild(roleLabel);
        messageDiv.appendChild(textDiv);
        messageDiv.appendChild(retryButton);
        this.messagesArea.appendChild(messageDiv);
        this.scrollToBottom();
        // Retry button handler
        retryButton.addEventListener('click', () => {
            messageDiv.remove();
            this.handleUserMessage(true);
        });
    }
    /** Add tool call message bubble */
    addToolBubble(name, args, status) {
        const messageDiv = document.createElement('div');
        messageDiv.className = 'ai-agent-tool-call';
        const statusIcon = {
            pending: '&#9203;',
            completed: '&#10004;',
            error: '&#10060;'
        }[status] || '&#9203;';
        // Collapsible header
        const headerDiv = document.createElement('div');
        headerDiv.className = 'ai-agent-tool-call-header';
        headerDiv.innerHTML = `
      <span class="tool-collapse-icon">▼</span>
      <span class="tool-status">${statusIcon}</span>
      <strong>${name}</strong>
    `;
        // Collapsible body
        const bodyDiv = document.createElement('div');
        bodyDiv.className = 'ai-agent-tool-call-body';
        const argsDiv = document.createElement('div');
        argsDiv.className = 'ai-agent-tool-call-args';
        argsDiv.textContent = this.formatArgs(name, args);
        bodyDiv.appendChild(argsDiv);
        messageDiv.appendChild(headerDiv);
        messageDiv.appendChild(bodyDiv);
        // Toggle collapse on header click
        headerDiv.addEventListener('click', () => {
            const isCollapsed = messageDiv.classList.toggle('collapsed');
            const icon = headerDiv.querySelector('.tool-collapse-icon');
            if (icon) {
                icon.textContent = isCollapsed ? '▶' : '▼';
            }
        });
        // Store data for auto-suggestions
        messageDiv._toolName = name;
        messageDiv._toolArgs = args;
        this.messagesArea.appendChild(messageDiv);
        this.scrollToBottom();
        return messageDiv;
    }
    /** Format tool arguments for display */
    formatArgs(toolName, args) {
        switch (toolName) {
            case 'create_cell':
                return `Create ${args.cell_type} cell:\n${(args.source || '').substring(0, 200)}${(args.source || '').length > 200 ? '...' : ''}`;
            case 'execute_cell':
                return `Execute cell [${args.index}]`;
            case 'get_cell_output':
                return `Get cell output [${args.index}]`;
            case 'update_cell':
                return `Update cell [${args.index}]`;
            case 'delete_cell':
                return `Delete cell [${args.index}]`;
            case 'get_notebook_content':
                return 'Read notebook content';
            case 'get_cell_content':
                return `Read cell [${args.index}]`;
            case 'find_in_notebook':
                return `Search in notebook: "${args.query}"${args.regex ? ' (regex)' : ''}${args.case_sensitive ? ' (case-sensitive)' : ''}`;
            case 'replace_in_cell':
                return `Replace in cell [${args.index}]: "${args.search}" -> "${args.replace}"${args.replace_all ? ' (all)' : ' (first)'}`;
            case 'read_file':
                return `Read file: ${args.path}${args.max_lines ? ` (first ${args.max_lines} lines)` : ''}`;
            case 'write_file':
                return `Write file: ${args.path} (${(args.content || '').length} chars)`;
            case 'list_directory':
                return `List files: ${args.path || '.'}`;
            case 'create_notebook':
                return `Create notebook: ${args.path || ''}${args.name}`;
            case 'delete_file':
                return `Delete: ${args.path}`;
            case 'rename_file':
                return `Rename: ${args.old_path} -> ${args.new_path}`;
            case 'run_shell':
                return `Run command: ${args.command}`;
            case 'install_package':
                return `Install package: ${args.package_name} (${args.manager || 'pip'})${args.extra_args ? ` ${args.extra_args}` : ''}`;
            case 'list_packages':
                return `List packages${args.filter ? `: filter "${args.filter}"` : ''}`;
            case 'remember':
                return `Remember [${args.category || 'general'}]: ${args.key} = "${(args.value || '').substring(0, 100)}"`;
            case 'analyze_image':
                return `Analyze image in cell [${args.cell_index}]${args.context ? `: "${args.context}"` : ''}`;
            default:
                return JSON.stringify(args, null, 2);
        }
    }
    /** Update tool bubble status (supports images) */
    updateToolBubble(el, status, result) {
        const icon = status === 'completed' ? '✅' : '❌';
        const statusEl = el.querySelector('.tool-status');
        if (statusEl) {
            statusEl.textContent = icon;
        }
        const bodyDiv = el.querySelector('.ai-agent-tool-call-body');
        if (!bodyDiv) {
            return;
        }
        const resultDiv = document.createElement('div');
        resultDiv.className = `ai-agent-tool-call-result ${status}`;
        // Check for images in result
        try {
            const parsed = JSON.parse(result);
            if (parsed.outputs && Array.isArray(parsed.outputs)) {
                // Render each output
                for (const output of parsed.outputs) {
                    if (output.type === 'image' && output.base64) {
                        const img = document.createElement('img');
                        img.className = 'ai-agent-output-image';
                        img.src = `data:${output.mime_type || 'image/png'};base64,${output.base64}`;
                        img.alt = output.alt_text || 'Cell output';
                        img.style.maxWidth = '100%';
                        img.style.maxHeight = '400px';
                        img.style.borderRadius = '4px';
                        img.style.marginTop = '8px';
                        resultDiv.appendChild(img);
                    }
                    else if (output.content) {
                        const textNode = document.createElement('pre');
                        textNode.className = 'ai-agent-output-text';
                        textNode.textContent =
                            typeof output.content === 'string'
                                ? output.content
                                : JSON.stringify(output.content, null, 2);
                        resultDiv.appendChild(textNode);
                    }
                }
            }
            else {
                // Plain text result
                resultDiv.textContent = result;
            }
        }
        catch (_a) {
            // Not JSON - show as plain text
            resultDiv.textContent = result;
        }
        // Truncate long results
        if (result.length > 500) {
            resultDiv.textContent = result.substring(0, 500) + '...';
            const showMore = document.createElement('button');
            showMore.className = 'ai-agent-show-more';
            showMore.textContent = 'Show full result';
            showMore.addEventListener('click', () => {
                resultDiv.textContent = result;
                showMore.remove();
            });
            bodyDiv.appendChild(resultDiv);
            bodyDiv.appendChild(showMore);
        }
        else {
            bodyDiv.appendChild(resultDiv);
        }
        // Auto-suggest image analysis
        const toolName = el._toolName;
        const toolArgs = el._toolArgs;
        if (toolName === 'get_cell_output' && status === 'completed') {
            try {
                const parsed = JSON.parse(result);
                if (parsed.has_images ||
                    (parsed.outputs &&
                        parsed.outputs.some((o) => o.type === 'image'))) {
                    this.addImageAnalysisSuggestion(bodyDiv, toolArgs === null || toolArgs === void 0 ? void 0 : toolArgs.index);
                }
            }
            catch (_b) {
                // Ignore parse errors
            }
        }
        // Auto-collapse on success
        if (status === 'completed') {
            el.classList.add('collapsed');
            const collapseIcon = el.querySelector('.tool-collapse-icon');
            if (collapseIcon) {
                collapseIcon.textContent = '▶';
            }
        }
        this.scrollToBottom();
    }
    /** Add image analysis suggestion */
    async addImageAnalysisSuggestion(container, cellIndex) {
        var _a;
        try {
            const settings = await (0,_settings_api__WEBPACK_IMPORTED_MODULE_12__.getSettings)();
            if (((_a = settings.image_analysis) === null || _a === void 0 ? void 0 : _a.auto_suggest) === false) {
                return;
            }
        }
        catch (_b) {
            // Show button if settings fail to load
        }
        const suggestionDiv = document.createElement('div');
        suggestionDiv.className = 'ai-agent-image-suggestion';
        suggestionDiv.innerHTML = `
      <span class="ai-agent-suggestion-text">Image detected in output</span>
      <button class="ai-agent-suggestion-btn">Analyze with AI</button>
    `;
        const btn = suggestionDiv.querySelector('.ai-agent-suggestion-btn');
        btn.addEventListener('click', async () => {
            const cellIdx = cellIndex || 1;
            const text = `Analyze the image in cell ${cellIdx}`;
            this.addBubble('user', text);
            this.setLoading(true);
            this.abortController = new AbortController();
            this.conversationHistory.push({
                role: 'user',
                content: text
            });
            this.updateTokenCounter();
            this.lastUserMessage = text;
            try {
                await this.agentLoop();
            }
            catch (error) {
                const msg = error instanceof Error ? error.message : String(error);
                if (msg !== 'Request cancelled' && !msg.includes('abort')) {
                    this.addBubble('assistant', `Error: ${msg}`);
                }
            }
            finally {
                this.setLoading(false);
            }
            suggestionDiv.remove();
        });
        container.appendChild(suggestionDiv);
    }
    /** Add thinking indicator */
    addThinkingIndicator() {
        const div = document.createElement('div');
        div.className = 'ai-agent-thinking';
        div.innerHTML = '<em>Agent is thinking...</em>';
        this.messagesArea.appendChild(div);
        this.scrollToBottom();
        return div;
    }
    // ═══════════════════════════════════════════════════════
    // File autocompletion (@mention)
    // ═══════════════════════════════════════════════════════
    /** Set loading state */
    setLoading(loading) {
        this.isLoading = loading;
        this.sendButton.disabled = loading;
        this.inputField.disabled = loading;
        // Toggle button visibility
        if (loading) {
            this.sendButton.classList.add('ai-agent-hidden');
            this.stopButton.classList.remove('ai-agent-hidden');
        }
        else {
            this.sendButton.classList.remove('ai-agent-hidden');
            this.stopButton.classList.add('ai-agent-hidden');
        }
    }
    /** Handle stop button click */
    handleStop() {
        if (this.abortController) {
            this.abortController.abort();
            this.abortController = null;
        }
        this.addBubble('assistant', 'Request cancelled by user.');
        this.setLoading(false);
    }
    /** Update token counter display */
    updateTokenCounter() {
        const tokens = (0,_token_counter__WEBPACK_IMPORTED_MODULE_7__.estimateMessagesTokens)(this.conversationHistory);
        this.tokenCounter.textContent = `~${(0,_token_counter__WEBPACK_IMPORTED_MODULE_7__.formatTokenCount)(tokens)} tokens`;
        this.tokenCounter.title = `Approximately ${tokens} tokens in context`;
    }
    // ─────────────────────────────────────────────
    // Auto context
    // ─────────────────────────────────────────────
    /** Decide whether to refresh context */
    shouldRefreshContext() {
        if (!this.contextConfig.smartMode) {
            return true;
        }
        const ctx = this.contextCollector.collect();
        const currentNotebook = ctx.notebookPath;
        const now = Date.now();
        // Refresh if:
        // 1. Notebook changed
        if (currentNotebook !== this.lastContextNotebook) {
            this.lastContextNotebook = currentNotebook;
            this.lastContextTimestamp = now;
            return true;
        }
        // 2. More than 30 seconds passed
        if (now - this.lastContextTimestamp > 30000) {
            this.lastContextTimestamp = now;
            return true;
        }
        // 3. First request in session
        if (this.conversationHistory.length <= 1) {
            return true;
        }
        return false;
    }
    /** Build dynamic context message */
    async buildContextMessage() {
        const parts = [];
        // 1. Environment context (always included)
        parts.push(this.contextCollector.formatAsSystemMessage(this.contextConfig.includeCellOutline));
        // 2. Variables (if enabled)
        if (this.contextConfig.includeVariables) {
            try {
                const varsInfo = await this.variableInspector.formatForPrompt();
                parts.push('');
                parts.push(varsInfo);
            }
            catch (_a) {
                // Skip if variables unavailable
            }
        }
        return parts.join('\n');
    }
    /** Prepare messages for LLM (includes context and truncation) */
    async prepareMessages() {
        const messages = [...this.conversationHistory];
        // 1. Add auto context
        if (this.shouldRefreshContext()) {
            const contextText = await this.buildContextMessage();
            const contextMessage = {
                role: 'user',
                content: `[SYSTEM CONTEXT]\n${contextText}`
            };
            // Insert before last user message
            let insertIndex = messages.length;
            for (let i = messages.length - 1; i >= 0; i--) {
                if (messages[i].role === 'user') {
                    insertIndex = i;
                    break;
                }
            }
            messages.splice(insertIndex, 0, contextMessage);
        }
        // 2. Update token counter
        this.updateTokenCounter();
        return messages;
    }
    // ─────────────────────────────────────────────
    // Confirmation (when auto-mode is off)
    // ─────────────────────────────────────────────
    /** Request tool execution confirmation */
    async confirmTool(name, args) {
        const tool = _tool_registry__WEBPACK_IMPORTED_MODULE_3__.toolRegistry.get(name);
        if (!tool) {
            return false;
        }
        // Check via PermissionManager
        const needsConfirm = _tool_registry__WEBPACK_IMPORTED_MODULE_3__.toolRegistry.permissions.requiresConfirmation(tool, this.autoExecuteTools);
        if (!needsConfirm) {
            return true;
        }
        // Show confirmation dialog
        const confirmClass = _permission_manager__WEBPACK_IMPORTED_MODULE_4__.PermissionManager.getConfirmationClass(tool.safetyLevel);
        return new Promise(resolve => {
            const confirmDiv = document.createElement('div');
            confirmDiv.className = `ai-agent-tool-confirm ${confirmClass}`;
            confirmDiv.innerHTML = `
        <div class="ai-agent-tool-confirm-text">
          Execute <strong>${name}</strong>?
        </div>
        <div class="ai-agent-tool-confirm-details">
          ${this.formatToolArgs(name, args)}
        </div>
        <div class="ai-agent-tool-confirm-buttons">
          <button class="jp-mod-accept">Yes</button>
          <button class="jp-mod-reject">No</button>
        </div>
      `;
            this.messagesArea.appendChild(confirmDiv);
            this.scrollToBottom();
            const acceptBtn = confirmDiv.querySelector('.jp-mod-accept');
            const rejectBtn = confirmDiv.querySelector('.jp-mod-reject');
            const cleanup = () => {
                confirmDiv.remove();
            };
            acceptBtn.onclick = () => {
                cleanup();
                resolve(true);
            };
            rejectBtn.onclick = () => {
                cleanup();
                resolve(false);
            };
        });
    }
    /** Format tool args for display */
    formatToolArgs(name, args) {
        const entries = Object.entries(args);
        if (entries.length === 0) {
            return '';
        }
        const argsHtml = entries
            .map(([key, value]) => {
            const str = typeof value === 'string' ? value : JSON.stringify(value);
            const truncated = str.length > 100 ? str.substring(0, 100) + '...' : str;
            return `<div><strong>${key}:</strong> ${this.escapeHtml(truncated)}</div>`;
        })
            .join('');
        return `<div class="ai-agent-tool-args">${argsHtml}</div>`;
    }
    /** Escape HTML special characters */
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    // ─────────────────────────────────────────────
    // Main agent loop
    // ─────────────────────────────────────────────
    /** Handle user message */
    async handleUserMessage(retryLastMessage = false) {
        // Use last message for retry, otherwise read from input
        let text;
        if (retryLastMessage && this.lastUserMessage) {
            text = this.lastUserMessage;
        }
        else {
            text = this.inputField.value.trim();
            if (!text || this.isLoading) {
                return;
            }
            this.inputField.value = '';
            this.lastUserMessage = text;
        }
        this.addBubble('user', text);
        this.setLoading(true);
        // Create AbortController for this request
        this.abortController = new AbortController();
        this.conversationHistory.push({
            role: 'user',
            content: text
        });
        // Update token counter
        this.updateTokenCounter();
        try {
            await this.agentLoop();
        }
        catch (error) {
            const msg = error instanceof Error ? error.message : String(error);
            if (msg === 'Request cancelled' || msg.includes('abort')) {
                // Cancelled - don't show as error
            }
            else {
                this.addErrorBubbleWithRetry(`Error: ${msg}`);
            }
        }
        finally {
            this.abortController = null;
            this.setLoading(false);
        }
    }
    /**
     * Agent loop:
     * 1. Send history to LLM (streaming)
     * 2. If tool_calls: execute, add results, goto 1
     * 3. If text: display, done
     */
    async agentLoop() {
        for (let iteration = 0; iteration < this.maxAgentIterations; iteration++) {
            const needMore = await this.agentStep();
            if (!needMore) {
                return;
            }
        }
        this.addBubble('assistant', 'Agent iteration limit reached.');
    }
    /** Single agent step with streaming (returns: true=continue, false=done) */
    async agentStep() {
        var _a, _b;
        const thinkingEl = this.addThinkingIndicator();
        // Создаём пустой bubble для ответа ассистента
        let assistantBubble = null;
        let assistantTextEl = null;
        let accumulatedText = '';
        // Prepare messages with context
        const messages = await this.prepareMessages();
        // Get image_analysis settings
        const settings = await (0,_settings_api__WEBPACK_IMPORTED_MODULE_12__.getSettings)();
        const imageAnalysisEnabled = (_b = (_a = settings.image_analysis) === null || _a === void 0 ? void 0 : _a.enabled) !== null && _b !== void 0 ? _b : true;
        return new Promise((resolve, reject) => {
            var _a;
            (0,_api__WEBPACK_IMPORTED_MODULE_2__.streamFromLLM)(messages, {
                onToken: (token) => {
                    // Remove thinking indicator on first token
                    if (thinkingEl.parentNode) {
                        thinkingEl.remove();
                    }
                    // Create bubble on first token
                    if (!assistantBubble) {
                        assistantBubble = document.createElement('div');
                        assistantBubble.className = 'ai-agent-message assistant';
                        const roleLabel = document.createElement('span');
                        roleLabel.className = 'ai-agent-message-role';
                        roleLabel.textContent = 'AI:';
                        assistantTextEl = document.createElement('div');
                        assistantTextEl.className = 'ai-agent-message-text';
                        assistantTextEl.innerHTML = '';
                        assistantBubble.appendChild(roleLabel);
                        assistantBubble.appendChild(assistantTextEl);
                        this.messagesArea.appendChild(assistantBubble);
                    }
                    // Append token
                    if (assistantTextEl) {
                        accumulatedText += token;
                        assistantTextEl.innerHTML = parseMarkdown(accumulatedText);
                    }
                    this.scrollToBottom();
                },
                onToolCalls: _toolCalls => {
                    // Tool calls handled in onDone
                },
                onDone: async (fullMessage) => {
                    thinkingEl.remove();
                    // No tool_calls - final response
                    if (!fullMessage.tool_calls ||
                        fullMessage.tool_calls.length === 0) {
                        this.conversationHistory.push({
                            role: 'assistant',
                            content: fullMessage.content || ''
                        });
                        // Initialize code block buttons
                        if (assistantTextEl) {
                            this.addCodeBlockButtons(assistantTextEl, accumulatedText);
                        }
                        // Update token counter
                        this.updateTokenCounter();
                        resolve(false);
                        return;
                    }
                    // Has tool_calls - add to history and execute
                    this.conversationHistory.push({
                        role: 'assistant',
                        content: fullMessage.content || null,
                        tool_calls: fullMessage.tool_calls
                    });
                    // Update token counter
                    this.updateTokenCounter();
                    // Execute each tool
                    for (const toolCall of fullMessage.tool_calls) {
                        const funcName = toolCall.function.name;
                        let funcArgs = {};
                        try {
                            funcArgs = JSON.parse(toolCall.function.arguments);
                        }
                        catch (_a) {
                            funcArgs = {};
                        }
                        // Show in UI
                        const toolBubble = this.addToolBubble(funcName, funcArgs, 'pending');
                        // Request confirmation (if auto-mode is off)
                        const confirmed = await this.confirmTool(funcName, funcArgs);
                        if (!confirmed) {
                            // User cancelled
                            this.updateToolBubble(toolBubble, 'error', 'Cancelled by user');
                            this.conversationHistory.push({
                                role: 'tool',
                                tool_call_id: toolCall.id,
                                content: JSON.stringify({
                                    success: false,
                                    error: 'Cancelled by user'
                                })
                            });
                            // Update token counter
                            this.updateTokenCounter();
                            continue;
                        }
                        // Execute tool
                        try {
                            const result = await _tool_registry__WEBPACK_IMPORTED_MODULE_3__.toolRegistry.execute(funcName, funcArgs);
                            if (result.success) {
                                this.updateToolBubble(toolBubble, 'completed', JSON.stringify(result.result, null, 2));
                            }
                            else {
                                this.updateToolBubble(toolBubble, 'error', result.error || 'Unknown error');
                            }
                            // Invalidate variable cache after execute_cell
                            if (funcName === 'execute_cell') {
                                this.variableInspector.invalidateCache();
                            }
                            // Add result to history for next LLM iteration
                            this.conversationHistory.push({
                                role: 'tool',
                                tool_call_id: toolCall.id,
                                content: JSON.stringify(result)
                            });
                            // Обновляем счётчик токенов
                            this.updateTokenCounter();
                        }
                        catch (error) {
                            const errMsg = error instanceof Error ? error.message : String(error);
                            this.updateToolBubble(toolBubble, 'error', errMsg);
                            this.conversationHistory.push({
                                role: 'tool',
                                tool_call_id: toolCall.id,
                                content: JSON.stringify({ success: false, error: errMsg })
                            });
                            // Update token counter
                            this.updateTokenCounter();
                        }
                    }
                    resolve(true); // need next iteration
                },
                onError: error => {
                    thinkingEl.remove();
                    reject(new Error(error));
                }
            }, (_a = this.abortController) === null || _a === void 0 ? void 0 : _a.signal, this.askMode, imageAnalysisEnabled);
        });
    }
    /** Sync theme with JupyterLab */
    syncTheme() {
        // CSS variables from JupyterLab apply automatically
    }
    /** Handle theme change */
    onThemeChanged() {
        this.syncTheme();
    }
    // ─────────────────────────────────────────────
    // Chat history management
    // ─────────────────────────────────────────────
    /** Toggle history panel */
    async toggleHistoryPanel() {
        const isVisible = !this.historyPanel.classList.contains('ai-agent-hidden');
        // Hide all panels
        this.historyPanel.classList.add('ai-agent-hidden');
        this.settingsPanel.classList.add('ai-agent-hidden');
        if (isVisible) {
            // Was hidden - restore chat
            this.messagesArea.classList.remove('ai-agent-hidden');
            this.inputField.disabled = false;
            this.sendButton.disabled = false;
            return;
        }
        // Show history
        this.messagesArea.classList.add('ai-agent-hidden');
        this.inputField.disabled = true;
        this.sendButton.disabled = true;
        this.historyPanel.classList.remove('ai-agent-hidden');
        await this.renderHistoryPanel();
    }
    /** Render saved chats list */
    async renderHistoryPanel() {
        var _a, _b, _c;
        if (this.isHistoryLoading) {
            return;
        }
        this.isHistoryLoading = true;
        this.historyPanel.innerHTML =
            '<div class="ai-agent-history-loading">Loading...</div>';
        try {
            const chats = await (0,_history_api__WEBPACK_IMPORTED_MODULE_8__.listChats)();
            const header = document.createElement('div');
            header.className = 'ai-agent-settings-header';
            header.innerHTML = `
        <h3>Chat History</h3>
        <button class="ai-agent-settings-close" title="Close">⨯</button>
      `;
            (_a = header
                .querySelector('.ai-agent-settings-close')) === null || _a === void 0 ? void 0 : _a.addEventListener('click', () => {
                this.toggleHistoryPanel();
            });
            const actions = document.createElement('div');
            actions.className = 'ai-agent-history-actions';
            const newChatBtn = document.createElement('button');
            newChatBtn.className = 'ai-agent-history-action-btn';
            newChatBtn.innerHTML = 'New Chat';
            newChatBtn.addEventListener('click', () => this.startNewChat());
            const saveBtn = document.createElement('button');
            saveBtn.className = 'ai-agent-history-action-btn';
            saveBtn.innerHTML = 'Save';
            saveBtn.addEventListener('click', () => this.saveCurrentChat());
            const exportMdBtn = document.createElement('button');
            exportMdBtn.className = 'ai-agent-history-action-btn';
            exportMdBtn.innerHTML = 'Export MD';
            exportMdBtn.addEventListener('click', async () => {
                if (this.currentChatId) {
                    try {
                        await (0,_history_api__WEBPACK_IMPORTED_MODULE_8__.exportChat)(this.currentChatId);
                    }
                    catch (error) {
                        const errorMsg = error instanceof Error ? error.message : String(error);
                        this.showNotification(`Export error: ${errorMsg}`, 'error');
                    }
                }
                else {
                    this.showNotification('Please save the chat first', 'error');
                }
            });
            const exportJsonBtn = document.createElement('button');
            exportJsonBtn.className = 'ai-agent-history-action-btn';
            exportJsonBtn.innerHTML = 'Export JSON';
            exportJsonBtn.addEventListener('click', () => {
                (0,_history_api__WEBPACK_IMPORTED_MODULE_8__.exportChatAsJson)(this.conversationHistory, this.currentChatId || undefined);
            });
            actions.appendChild(newChatBtn);
            actions.appendChild(saveBtn);
            actions.appendChild(exportMdBtn);
            actions.appendChild(exportJsonBtn);
            const list = document.createElement('div');
            list.className = 'ai-agent-history-list';
            if (chats.length === 0) {
                list.innerHTML =
                    '<div class="ai-agent-history-empty">No saved chats</div>';
            }
            else {
                for (const chat of chats) {
                    const item = document.createElement('div');
                    item.className = 'ai-agent-history-item';
                    if (chat.id === this.currentChatId) {
                        item.classList.add('active');
                    }
                    const date = new Date(chat.updated_at).toLocaleDateString('ru-RU', {
                        day: '2-digit',
                        month: '2-digit',
                        hour: '2-digit',
                        minute: '2-digit'
                    });
                    item.innerHTML = `
            <div class="ai-agent-history-item-main">
              <span class="ai-agent-history-item-title">${this.escapeHtml(chat.title)}</span>
              <span class="ai-agent-history-item-date">${date}</span>
            </div>
            <div class="ai-agent-history-item-actions">
              <button class="ai-agent-history-item-btn" title="Load">Open</button>
              <button class="ai-agent-history-item-btn ai-agent-history-delete" title="Delete">Delete</button>
            </div>
          `;
                    // Load
                    (_b = item
                        .querySelector('.ai-agent-history-item-btn:not(.ai-agent-history-delete)')) === null || _b === void 0 ? void 0 : _b.addEventListener('click', () => this.loadChatById(chat.id));
                    // Delete
                    (_c = item
                        .querySelector('.ai-agent-history-delete')) === null || _c === void 0 ? void 0 : _c.addEventListener('click', async (e) => {
                        e.stopPropagation();
                        if (confirm(`Delete chat "${chat.title}"?`)) {
                            await this.deleteChatById(chat.id);
                            await this.renderHistoryPanel();
                        }
                    });
                    list.appendChild(item);
                }
            }
            this.historyPanel.innerHTML = '';
            this.historyPanel.appendChild(header);
            this.historyPanel.appendChild(actions);
            this.historyPanel.appendChild(list);
        }
        catch (error) {
            const errorMsg = error instanceof Error ? error.message : String(error);
            this.historyPanel.innerHTML = `<div class="ai-agent-history-error">Error: ${this.escapeHtml(errorMsg)}</div>`;
        }
        finally {
            this.isHistoryLoading = false;
        }
    }
    /** Start new chat */
    startNewChat() {
        if (this.conversationHistory.length > 0) {
            if (!confirm('Start new chat? Current chat will be cleared.')) {
                return;
            }
        }
        this.currentChatId = null;
        this.conversationHistory = [];
        this.messagesArea.innerHTML = '';
        this.updateTokenCounter();
        this.addBubble('assistant', 'Hello! I am AI Agent. I can write and execute code in your notebook. Try: "Write a fibonacci function and execute it"');
        this.toggleHistoryPanel();
    }
    /** Save current chat */
    async saveCurrentChat() {
        if (this.conversationHistory.length === 0) {
            this.showNotification('Chat is empty', 'error');
            return;
        }
        try {
            const result = await (0,_history_api__WEBPACK_IMPORTED_MODULE_8__.saveChat)(this.conversationHistory, this.currentChatId || undefined);
            this.currentChatId = result.id;
            this.showNotification(`Chat saved: "${result.title}"`, 'success');
            this.toggleHistoryPanel();
        }
        catch (error) {
            const errorMsg = error instanceof Error ? error.message : String(error);
            this.showNotification(`Save error: ${errorMsg}`, 'error');
        }
    }
    /** Load chat by ID */
    async loadChatById(chatId) {
        if (this.conversationHistory.length > 0) {
            if (!confirm('Load chat? Current chat will be replaced.')) {
                return;
            }
        }
        try {
            const chatData = await (0,_history_api__WEBPACK_IMPORTED_MODULE_8__.loadChat)(chatId);
            this.currentChatId = chatData.id;
            this.conversationHistory = chatData.messages;
            // Display messages
            this.messagesArea.innerHTML = '';
            for (const msg of chatData.messages) {
                if (msg.role === 'user' && msg.content) {
                    this.addBubble('user', msg.content);
                }
                else if (msg.role === 'assistant' && msg.content) {
                    this.addBubble('assistant', msg.content);
                }
                else if (msg.role === 'tool') {
                    // Tool messages are in history, not displayed
                }
            }
            this.updateTokenCounter();
            this.showNotification(`Chat "${chatData.title}" loaded`, 'success');
            this.toggleHistoryPanel();
        }
        catch (error) {
            const errorMsg = error instanceof Error ? error.message : String(error);
            this.showNotification(`Load error: ${errorMsg}`, 'error');
        }
    }
    /** Delete chat by ID */
    async deleteChatById(chatId) {
        try {
            await (0,_history_api__WEBPACK_IMPORTED_MODULE_8__.deleteChat)(chatId);
            if (chatId === this.currentChatId) {
                this.currentChatId = null;
            }
            this.showNotification('Chat deleted', 'success');
        }
        catch (error) {
            const errorMsg = error instanceof Error ? error.message : String(error);
            this.showNotification(`Delete error: ${errorMsg}`, 'error');
        }
    }
    /** Show notification */
    showNotification(message, type) {
        const notification = document.createElement('div');
        notification.className = `ai-agent-notification ai-agent-notification-${type}`;
        notification.textContent = message;
        const container = this.content.node;
        container.appendChild(notification);
        setTimeout(() => {
            notification.classList.add('ai-agent-notification-hide');
            setTimeout(() => notification.remove(), 300);
        }, 3000);
    }
    /** Toggle settings panel */
    async toggleSettingsPanel() {
        const isVisible = !this.settingsPanel.classList.contains('ai-agent-hidden');
        // Hide all panels
        this.historyPanel.classList.add('ai-agent-hidden');
        this.settingsPanel.classList.add('ai-agent-hidden');
        if (isVisible) {
            // Was hidden - restore chat
            this.messagesArea.classList.remove('ai-agent-hidden');
            this.inputField.disabled = false;
            this.sendButton.disabled = false;
            return;
        }
        // Show settings
        this.messagesArea.classList.add('ai-agent-hidden');
        this.inputField.disabled = true;
        this.sendButton.disabled = true;
        this.settingsPanel.classList.remove('ai-agent-hidden');
        await this.renderSettingsPanel();
    }
    /** Load settings from server and apply */
    async loadSettingsFromServer() {
        try {
            const settings = await (0,_settings_api__WEBPACK_IMPORTED_MODULE_12__.getSettings)();
            // Apply settings
            this.maxAgentIterations = settings.max_agent_iterations;
            this.autoExecuteTools = settings.auto_execute_tools;
            // Save context settings
            this.contextConfig = {
                includeCellOutline: settings.include_cell_outline,
                includeVariables: settings.include_variables,
                maxCellsInOutline: 20,
                maxVariables: 30,
                smartMode: true
            };
            // Update permission manager for tool categories
            if (settings.enabled_tool_categories) {
                for (const [category, enabled] of Object.entries(settings.enabled_tool_categories)) {
                    if (enabled) {
                        _tool_registry__WEBPACK_IMPORTED_MODULE_3__.toolRegistry.enableCategory(category);
                    }
                    else {
                        _tool_registry__WEBPACK_IMPORTED_MODULE_3__.toolRegistry.disableCategory(category);
                    }
                }
            }
        }
        catch (e) {
            console.error('Failed to load settings:', e);
        }
    }
    /** Render settings panel */
    async renderSettingsPanel() {
        await (0,_settings_dialog__WEBPACK_IMPORTED_MODULE_11__.renderSettingsPanelContent)(this.settingsPanel, 
        // onClose - just close panel
        () => {
            this.toggleSettingsPanel();
        }, 
        // onSettingsChanged - save and close
        () => {
            this.loadSettingsFromServer();
            this.showNotification('Settings saved', 'success');
            this.toggleSettingsPanel();
        });
    }
}


/***/ },

/***/ "./lib/context-collector.js"
/*!**********************************!*\
  !*** ./lib/context-collector.js ***!
  \**********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ContextCollector: () => (/* binding */ ContextCollector)
/* harmony export */ });
/**
 * Собирает динамический контекст из текущего состояния JupyterLab
 */
class ContextCollector {
    constructor(_app, notebookTracker) {
        this.notebookTracker = notebookTracker;
    }
    /**
     * Собрать полный контекст
     */
    collect() {
        const notebook = this.notebookTracker.currentWidget;
        return {
            notebookName: this.getNotebookName(notebook),
            notebookPath: this.getNotebookPath(notebook),
            kernelInfo: this.getKernelInfo(notebook),
            cellsSummary: this.getCellsSummary(notebook),
            recentErrors: this.getRecentErrors(notebook),
            workingDirectory: this.getWorkingDirectory(notebook),
            cellOutline: this.getCellOutline(notebook),
            emptyCells: this.getEmptyCells(notebook)
        };
    }
    /**
     * Преобразовать контекст в текст для системного промпта
     * @param includeCellOutline - Включать outline ячеек (по умолчанию true)
     */
    formatAsSystemMessage(includeCellOutline = true) {
        const ctx = this.collect();
        const lines = [];
        lines.push('=== CURRENT ENVIRONMENT ===');
        // Ноутбук
        if (ctx.notebookName) {
            lines.push(`Notebook: ${ctx.notebookName} (${ctx.notebookPath})`);
        }
        else {
            lines.push('Notebook: No notebook is open');
        }
        // Ядро
        if (ctx.kernelInfo) {
            lines.push(`Kernel: ${ctx.kernelInfo.displayName} ` +
                `(${ctx.kernelInfo.language}, status: ${ctx.kernelInfo.status})`);
        }
        else {
            lines.push('Kernel: Not connected');
        }
        // Ячейки
        if (ctx.cellsSummary) {
            const cs = ctx.cellsSummary;
            lines.push(`Cells: ${cs.total} total ` +
                `(${cs.code} code, ${cs.markdown} markdown` +
                `${cs.raw > 0 ? `, ${cs.raw} raw` : ''})`);
            lines.push(`Active cell: [${cs.activeCellIndex}] ${cs.activeCellType}`);
            if (cs.activeCellPreview) {
                lines.push(`Active cell preview: ${cs.activeCellPreview}`);
            }
        }
        // Outline ячеек (только если включено)
        if (includeCellOutline && ctx.cellOutline.length > 0) {
            lines.push('');
            lines.push('Cell outline:');
            for (const outline of ctx.cellOutline) {
                lines.push(`  ${outline}`);
            }
        }
        // Ошибки
        if (ctx.recentErrors.length > 0) {
            lines.push('');
            lines.push('Recent errors:');
            for (const err of ctx.recentErrors) {
                lines.push(`  Cell [${err.cellIndex}]: ${err.errorType}: ${err.errorMessage}`);
            }
        }
        // Рабочая директория
        lines.push('');
        lines.push(`Working directory: ${ctx.workingDirectory}`);
        // Пустые ячейки
        if (ctx.emptyCells && ctx.emptyCells.length > 0) {
            lines.push('');
            lines.push(`Empty cells (can be reused): [${ctx.emptyCells.join(', ')}]`);
        }
        lines.push('=== END ENVIRONMENT ===');
        return lines.join('\n');
    }
    // ═══════════════════════════════════════════
    // Методы сбора данных
    // ═══════════════════════════════════════════
    getNotebookName(notebook) {
        if (!notebook) {
            return null;
        }
        return notebook.title.label || null;
    }
    getNotebookPath(notebook) {
        var _a;
        if (!notebook) {
            return null;
        }
        return ((_a = notebook.context) === null || _a === void 0 ? void 0 : _a.path) || null;
    }
    getKernelInfo(notebook) {
        var _a, _b, _c, _d;
        if (!notebook) {
            return null;
        }
        const session = notebook.sessionContext;
        const kernel = (_a = session === null || session === void 0 ? void 0 : session.session) === null || _a === void 0 ? void 0 : _a.kernel;
        if (!kernel) {
            return null;
        }
        // kernelspec info
        const spec = session.kernelPreference;
        const kernelInfo = kernel.info;
        return {
            name: ((_c = (_b = session.session) === null || _b === void 0 ? void 0 : _b.kernel) === null || _c === void 0 ? void 0 : _c.name) || 'unknown',
            displayName: session.kernelDisplayName || kernel.name || 'Unknown',
            language: ((_d = kernelInfo === null || kernelInfo === void 0 ? void 0 : kernelInfo.language_info) === null || _d === void 0 ? void 0 : _d.name) ||
                (spec === null || spec === void 0 ? void 0 : spec.language) ||
                'unknown',
            status: kernel.status
        };
    }
    getCellsSummary(notebook) {
        if (!notebook) {
            return null;
        }
        const model = notebook.content.model;
        if (!model) {
            return null;
        }
        let code = 0;
        let markdown = 0;
        let raw = 0;
        for (let i = 0; i < model.cells.length; i++) {
            const cell = model.cells.get(i);
            switch (cell.type) {
                case 'code':
                    code++;
                    break;
                case 'markdown':
                    markdown++;
                    break;
                case 'raw':
                    raw++;
                    break;
            }
        }
        const activeCellIndex = notebook.content.activeCellIndex;
        const activeCell = model.cells.get(activeCellIndex);
        let activeCellPreview = '';
        if (activeCell) {
            const source = this.getCellSource(activeCell);
            // Первые 100 символов
            activeCellPreview = source.substring(0, 100);
            if (source.length > 100) {
                activeCellPreview += '...';
            }
        }
        return {
            total: model.cells.length,
            code,
            markdown,
            raw,
            activeCellIndex: activeCellIndex,
            activeCellType: (activeCell === null || activeCell === void 0 ? void 0 : activeCell.type) || 'unknown',
            activeCellPreview
        };
    }
    /**
     * Краткий outline: для каждой ячейки — тип + первая строка
     */
    getCellOutline(notebook) {
        if (!notebook) {
            return [];
        }
        const model = notebook.content.model;
        if (!model) {
            return [];
        }
        const outline = [];
        const maxCells = 20; // Ограничиваем, чтобы не раздувать контекст
        for (let i = 0; i < Math.min(model.cells.length, maxCells); i++) {
            const cell = model.cells.get(i);
            const source = this.getCellSource(cell);
            const firstLine = source.split('\n')[0].trim();
            const typeIcon = cell.type === 'code' ? '▸' : '▪';
            const preview = firstLine.substring(0, 60);
            const suffix = firstLine.length > 60 ? '...' : '';
            // Для code-ячеек показываем, есть ли output/ошибка
            let statusMark = '';
            if (cell.type === 'code') {
                const codeCell = cell;
                if (codeCell.outputs && codeCell.outputs.length > 0) {
                    const hasError = this.cellOutputHasError(codeCell);
                    statusMark = hasError ? ' ❌' : ' ✓';
                }
            }
            outline.push(`[${i}] ${typeIcon} ${preview}${suffix}${statusMark}`);
        }
        if (model.cells.length > maxCells) {
            outline.push(`... and ${model.cells.length - maxCells} more cells`);
        }
        return outline;
    }
    /**
     * Получить последние ошибки из ячеек
     */
    getRecentErrors(notebook) {
        if (!notebook) {
            return [];
        }
        const model = notebook.content.model;
        if (!model) {
            return [];
        }
        const errors = [];
        for (let i = 0; i < model.cells.length; i++) {
            const cell = model.cells.get(i);
            if (cell.type !== 'code') {
                continue;
            }
            const codeCell = cell;
            if (!codeCell.outputs) {
                continue;
            }
            for (let j = 0; j < codeCell.outputs.length; j++) {
                const output = codeCell.outputs.get(j);
                const raw = output === null || output === void 0 ? void 0 : output._raw;
                if ((raw === null || raw === void 0 ? void 0 : raw.output_type) === 'error') {
                    errors.push({
                        cellIndex: i,
                        errorType: raw.ename || 'Error',
                        errorMessage: raw.evalue || 'Unknown error'
                    });
                }
            }
        }
        // Возвращаем только последние 5 ошибок
        return errors.slice(-5);
    }
    getWorkingDirectory(notebook) {
        var _a;
        if (!notebook) {
            return '(unknown)';
        }
        const path = ((_a = notebook.context) === null || _a === void 0 ? void 0 : _a.path) || '';
        const parts = path.split('/');
        parts.pop(); // убираем имя файла
        return parts.join('/') || '.';
    }
    getCellSource(cell) {
        if (cell.sharedModel) {
            return cell.sharedModel.getSource();
        }
        if (cell.value) {
            return cell.value.text;
        }
        return '';
    }
    cellOutputHasError(codeCell) {
        for (let i = 0; i < codeCell.outputs.length; i++) {
            const output = codeCell.outputs.get(i);
            const raw = output === null || output === void 0 ? void 0 : output._raw;
            if ((raw === null || raw === void 0 ? void 0 : raw.output_type) === 'error') {
                return true;
            }
        }
        return false;
    }
    /**
     * Получить индексы пустых ячеек (с пустым source)
     */
    getEmptyCells(notebook) {
        if (!notebook) {
            return [];
        }
        const model = notebook.content.model;
        if (!model) {
            return [];
        }
        const emptyCells = [];
        for (let i = 0; i < model.cells.length; i++) {
            const cell = model.cells.get(i);
            const source = this.getCellSource(cell);
            if (!source || source.trim() === '') {
                emptyCells.push(i);
            }
        }
        return emptyCells;
    }
}


/***/ },

/***/ "./lib/history-api.js"
/*!****************************!*\
  !*** ./lib/history-api.js ***!
  \****************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   deleteChat: () => (/* binding */ deleteChat),
/* harmony export */   exportChat: () => (/* binding */ exportChat),
/* harmony export */   exportChatAsJson: () => (/* binding */ exportChatAsJson),
/* harmony export */   listChats: () => (/* binding */ listChats),
/* harmony export */   loadChat: () => (/* binding */ loadChat),
/* harmony export */   saveChat: () => (/* binding */ saveChat)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Получить XSRF токен из настроек сервера или cookie
 */
function getXsrfToken() {
    // JupyterLab хранит токен в PageConfig
    const token = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.PageConfig.getToken();
    if (token) {
        return token;
    }
    // Пробуем из cookie
    const match = document.cookie.match(new RegExp('(^|; )_xsrf=([^;]+)'));
    return match ? match[2] : '';
}
/**
 * Получить список всех сохранённых чатов
 */
async function listChats() {
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const endpoint = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'ai-agent', 'history');
    const response = await fetch(endpoint, {
        method: 'GET',
        credentials: 'same-origin'
    });
    if (response.status !== 200) {
        const text = await response.text();
        try {
            const data = JSON.parse(text);
            throw new Error(data.error || `Server error: ${response.status}`);
        }
        catch (_a) {
            throw new Error(`Server error ${response.status}: ${text.substring(0, 200)}`);
        }
    }
    const data = await response.json();
    return data.chats || [];
}
/**
 * Сохранить текущий чат
 */
async function saveChat(messages, chatId, title) {
    var _a;
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const endpoint = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'ai-agent', 'history', 'save');
    const headers = {
        'Content-Type': 'application/json'
    };
    if ((_a = settings.init) === null || _a === void 0 ? void 0 : _a.headers) {
        const initHeaders = settings.init.headers;
        Object.assign(headers, initHeaders);
    }
    const xsrfToken = getXsrfToken();
    if (xsrfToken) {
        headers['X-XSRFToken'] = xsrfToken;
    }
    const body = { messages };
    if (chatId) {
        body.id = chatId;
    }
    if (title) {
        body.title = title;
    }
    const response = await fetch(endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
        credentials: 'same-origin'
    });
    if (response.status !== 200) {
        const text = await response.text();
        try {
            const data = JSON.parse(text);
            throw new Error(data.error || `Server error: ${response.status}`);
        }
        catch (_b) {
            throw new Error(`Server error ${response.status}: ${text.substring(0, 200)}`);
        }
    }
    return await response.json();
}
/**
 * Загрузить чат по ID
 */
async function loadChat(chatId) {
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const endpoint = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'ai-agent', 'history', chatId);
    const response = await fetch(endpoint, {
        method: 'GET',
        credentials: 'same-origin'
    });
    if (response.status === 404) {
        throw new Error(`Chat not found: ${chatId}`);
    }
    if (response.status !== 200) {
        const text = await response.text();
        try {
            const data = JSON.parse(text);
            throw new Error(data.error || `Server error: ${response.status}`);
        }
        catch (_a) {
            throw new Error(`Server error ${response.status}: ${text.substring(0, 200)}`);
        }
    }
    return await response.json();
}
/**
 * Удалить чат по ID
 */
async function deleteChat(chatId) {
    var _a;
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const endpoint = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'ai-agent', 'history', chatId);
    const headers = {
        'Content-Type': 'application/json'
    };
    if ((_a = settings.init) === null || _a === void 0 ? void 0 : _a.headers) {
        const initHeaders = settings.init.headers;
        Object.assign(headers, initHeaders);
    }
    const xsrfToken = getXsrfToken();
    if (xsrfToken) {
        headers['X-XSRFToken'] = xsrfToken;
    }
    const response = await fetch(endpoint, {
        method: 'DELETE',
        headers,
        credentials: 'same-origin'
    });
    if (response.status === 404) {
        throw new Error(`Chat not found: ${chatId}`);
    }
    if (response.status !== 200) {
        const text = await response.text();
        try {
            const data = JSON.parse(text);
            throw new Error(data.error || `Server error: ${response.status}`);
        }
        catch (_b) {
            throw new Error(`Server error ${response.status}: ${text.substring(0, 200)}`);
        }
    }
}
/**
 * Экспортировать чат в Markdown (скачать файл)
 */
async function exportChat(chatId) {
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const endpoint = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'ai-agent', 'history', chatId, 'export');
    const response = await fetch(endpoint, {
        method: 'GET',
        credentials: 'same-origin'
    });
    if (response.status === 404) {
        throw new Error(`Chat not found: ${chatId}`);
    }
    if (response.status !== 200) {
        const text = await response.text();
        try {
            const data = JSON.parse(text);
            throw new Error(data.error || `Server error: ${response.status}`);
        }
        catch (_a) {
            throw new Error(`Server error ${response.status}: ${text.substring(0, 200)}`);
        }
    }
    // Получаем заголовок Content-Disposition для имени файла
    const contentDisposition = response.headers.get('Content-Disposition');
    let filename = 'chat.md';
    if (contentDisposition) {
        const match = contentDisposition.match(/filename="?(.+)"?/);
        if (match) {
            filename = match[1];
        }
    }
    // Скачиваем файл
    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
}
/**
 * Экспортировать текущий чат в JSON (скачать файл)
 */
function exportChatAsJson(messages, chatId) {
    const data = {
        exported_at: new Date().toISOString(),
        messages
    };
    const json = JSON.stringify(data, null, 2);
    const blob = new Blob([json], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = chatId ? `chat-${chatId}.json` : `chat-${Date.now()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
}


/***/ },

/***/ "./lib/icons/index.js"
/*!****************************!*\
  !*** ./lib/icons/index.js ***!
  \****************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   addProfileIcon: () => (/* binding */ addProfileIcon),
/* harmony export */   deleteProfileIcon: () => (/* binding */ deleteProfileIcon),
/* harmony export */   editProfileIcon: () => (/* binding */ editProfileIcon)
/* harmony export */ });
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/ui-components */ "webpack/sharing/consume/default/@jupyterlab/ui-components");
/* harmony import */ var _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__);

const addProfileSvgStr = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
  <path fill="#BDBDBD" d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm5 11h-4v4h-2v-4H7v-2h4V7h2v4h4v2z"/>
</svg>`;
const editProfileSvgStr = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
  <path fill="#BDBDBD" d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/>
</svg>`;
const deleteProfileSvgStr = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
  <path fill="#BDBDBD" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/>
</svg>`;
const addProfileIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'ai-agent:add-profile',
    svgstr: addProfileSvgStr
});
const editProfileIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'ai-agent:edit-profile',
    svgstr: editProfileSvgStr
});
const deleteProfileIcon = new _jupyterlab_ui_components__WEBPACK_IMPORTED_MODULE_0__.LabIcon({
    name: 'ai-agent:delete-profile',
    svgstr: deleteProfileSvgStr
});


/***/ },

/***/ "./lib/index.js"
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _chat_panel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./chat-panel */ "./lib/chat-panel.js");
/* harmony import */ var _tool_registry__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./tool-registry */ "./lib/tool-registry.js");
/* harmony import */ var _tools_notebook_tools__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./tools/notebook-tools */ "./lib/tools/notebook-tools.js");
/* harmony import */ var _tools_search_tools__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./tools/search-tools */ "./lib/tools/search-tools.js");
/* harmony import */ var _tools_file_tools__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tools/file-tools */ "./lib/tools/file-tools.js");
/* harmony import */ var _tools_shell_tools__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./tools/shell-tools */ "./lib/tools/shell-tools.js");
/* harmony import */ var _tools_package_tools__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./tools/package-tools */ "./lib/tools/package-tools.js");
/* harmony import */ var _jupyter_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./jupyter-service */ "./lib/jupyter-service.js");
/* harmony import */ var _settings_api__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./settings-api */ "./lib/settings-api.js");











/**
 * Зарегистрировать инструменты ноутбука с настройками image analysis
 */
async function registerNotebookTools(jupyterService) {
    try {
        const settings = await (0,_settings_api__WEBPACK_IMPORTED_MODULE_10__.getSettings)();
        const notebookTools = (0,_tools_notebook_tools__WEBPACK_IMPORTED_MODULE_4__.createNotebookTools)(jupyterService, {
            imageAnalysis: settings.image_analysis
        });
        notebookTools.forEach(tool => _tool_registry__WEBPACK_IMPORTED_MODULE_3__.toolRegistry.register(tool));
        console.log('Notebook tools:', notebookTools.map(t => t.name));
    }
    catch (e) {
        console.warn('Failed to load settings, using defaults:', e);
        const notebookTools = (0,_tools_notebook_tools__WEBPACK_IMPORTED_MODULE_4__.createNotebookTools)(jupyterService);
        notebookTools.forEach(tool => _tool_registry__WEBPACK_IMPORTED_MODULE_3__.toolRegistry.register(tool));
    }
}
/**
 * Команда для переключения видимости AI Agent панели
 */
const COMMAND_ID = 'cellsistant:toggle';
/**
 * Плагин для добавления AI Agent боковой панели
 */
const plugin = {
    id: 'cellsistant:plugin',
    description: 'AI Agent sidebar panel for JupyterLab.',
    autoStart: true,
    requires: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ICommandPalette, _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_1__.INotebookTracker, _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.IThemeManager],
    activate: async (app, palette, notebookTracker, themeManager) => {
        console.log('JupyterLab AI Agent extension is activated!');
        // Создаём сервис для работы с JupyterLab
        const jupyterService = new _jupyter_service__WEBPACK_IMPORTED_MODULE_9__.JupyterService(app, notebookTracker);
        // Регистрируем инструменты ноутбука (с настройками image analysis)
        await registerNotebookTools(jupyterService);
        // Регистрируем инструменты поиска и замены
        const searchTools = (0,_tools_search_tools__WEBPACK_IMPORTED_MODULE_5__.createSearchTools)(jupyterService);
        searchTools.forEach(tool => _tool_registry__WEBPACK_IMPORTED_MODULE_3__.toolRegistry.register(tool));
        // Регистрируем файловые инструменты
        const fileTools = (0,_tools_file_tools__WEBPACK_IMPORTED_MODULE_6__.createFileTools)(jupyterService);
        fileTools.forEach(tool => _tool_registry__WEBPACK_IMPORTED_MODULE_3__.toolRegistry.register(tool));
        // Регистрируем shell инструменты
        const shellTools = (0,_tools_shell_tools__WEBPACK_IMPORTED_MODULE_7__.createShellTools)();
        shellTools.forEach(tool => _tool_registry__WEBPACK_IMPORTED_MODULE_3__.toolRegistry.register(tool));
        // Регистрируем package инструменты
        const packageTools = (0,_tools_package_tools__WEBPACK_IMPORTED_MODULE_8__.createPackageTools)();
        packageTools.forEach(tool => _tool_registry__WEBPACK_IMPORTED_MODULE_3__.toolRegistry.register(tool));
        console.log('All tools registered');
        // Создаём панель чата с themeManager для синхронизации темы
        const panel = new _chat_panel__WEBPACK_IMPORTED_MODULE_2__.ChatPanel(app, themeManager, notebookTracker);
        // Добавляем панель в правую панель в самый низ (rank=1000)
        app.shell.add(panel, 'right', { rank: 1000 });
        // Добавляем команду для переключения видимости панели
        app.commands.addCommand(COMMAND_ID, {
            label: 'Toggle AI Agent',
            execute: () => {
                if (!panel.isAttached) {
                    app.shell.add(panel, 'right');
                    app.shell.activateById(panel.id);
                }
                else {
                    // Проверяем, активна ли панель
                    if (app.shell.currentWidget === panel) {
                        panel.close();
                    }
                    else {
                        // Если панель не активна, активируем её
                        app.shell.activateById(panel.id);
                    }
                }
            }
        });
        // Добавляем команду в палитру
        palette.addItem({
            command: COMMAND_ID,
            category: 'AI Agent'
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ },

/***/ "./lib/jupyter-service.js"
/*!********************************!*\
  !*** ./lib/jupyter-service.js ***!
  \********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JupyterService: () => (/* binding */ JupyterService)
/* harmony export */ });
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/notebook */ "webpack/sharing/consume/default/@jupyterlab/notebook");
/* harmony import */ var _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__);

/**
 * Сервис для работы с JupyterLab Notebook API
 */
class JupyterService {
    constructor(app, notebookTracker) {
        this.app = app;
        this.notebookTracker = notebookTracker;
    }
    /**
     * Доступ к ContentsManager через ServiceManager
     */
    get contents() {
        return this.app.serviceManager.contents;
    }
    /**
     * Получить активный ноутбук
     */
    getActiveNotebook() {
        return this.notebookTracker.currentWidget || null;
    }
    /**
     * Создать новую ячейку
     */
    async createCell(cellType, source) {
        const panel = this.getActiveNotebook();
        if (!panel) {
            return { success: false, error: 'No active notebook' };
        }
        const notebook = panel.content;
        const model = notebook.model;
        if (!model) {
            return { success: false, error: 'Notebook has no model' };
        }
        // Запоминаем индекс до создания
        const currentIndex = notebook.activeCellIndex;
        const insertIndex = currentIndex + 1;
        // Создаём ячейку через NotebookActions.insertBelow (всегда code)
        _jupyterlab_notebook__WEBPACK_IMPORTED_MODULE_0__.NotebookActions.insertBelow(notebook);
        // Ждём инициализации ячейки
        await new Promise(resolve => setTimeout(resolve, 50));
        // Если нужна markdown — меняем тип через команду
        if (cellType === 'markdown') {
            notebook.activeCellIndex = insertIndex;
            await this.app.commands.execute('notebook:change-cell-to-markdown');
            await new Promise(resolve => setTimeout(resolve, 50));
        }
        // Получаем созданную ячейку
        const targetCell = model.cells.get(insertIndex);
        if (!targetCell) {
            return { success: false, error: 'Failed to create cell' };
        }
        // Устанавливаем содержимое через sharedModel или value
        if (targetCell.sharedModel) {
            targetCell.sharedModel.setSource(source);
        }
        else if (targetCell.value) {
            targetCell.value.text = source;
        }
        // Делаем созданную ячейку активной
        notebook.activeCellIndex = insertIndex;
        return { success: true, index: insertIndex };
    }
    /**
     * Обновить содержимое ячейки
     */
    updateCell(index, source) {
        const panel = this.getActiveNotebook();
        if (!panel) {
            return { success: false, error: 'No active notebook' };
        }
        const notebook = panel.content;
        const model = notebook.model;
        if (!model) {
            return { success: false, error: 'Notebook has no model' };
        }
        if (index < 0 || index >= model.cells.length) {
            return { success: false, error: `Invalid cell index: ${index}` };
        }
        const cell = model.cells.get(index);
        // Устанавливаем содержимое через sharedModel или value
        if (cell.sharedModel) {
            cell.sharedModel.setSource(source);
        }
        else if (cell.value) {
            cell.value.text = source;
        }
        else {
            return { success: false, error: 'Failed to set cell content' };
        }
        return { success: true };
    }
    /**
     * Удалить ячейку
     */
    deleteCell(index) {
        const panel = this.getActiveNotebook();
        if (!panel) {
            return { success: false, error: 'No active notebook' };
        }
        const notebook = panel.content;
        const model = notebook.model;
        if (!model) {
            return { success: false, error: 'Notebook has no model' };
        }
        if (index < 0 || index >= model.cells.length) {
            return { success: false, error: `Invalid cell index: ${index}` };
        }
        // Выделяем ячейку и удаляем через команду
        notebook.activeCellIndex = index;
        this.app.commands.execute('notebook:delete-cell');
        return { success: true };
    }
    /**
     * Получить содержимое ячейки
     */
    getCellContent(index) {
        const panel = this.getActiveNotebook();
        if (!panel) {
            return { success: false, error: 'No active notebook' };
        }
        const notebook = panel.content;
        const model = notebook.model;
        if (!model) {
            return { success: false, error: 'Notebook has no model' };
        }
        if (index < 0 || index >= model.cells.length) {
            return { success: false, error: `Invalid cell index: ${index}` };
        }
        const cell = model.cells.get(index);
        let source = '';
        // Пробуем получить source через sharedModel или value
        if (cell.sharedModel) {
            source = cell.sharedModel.getSource();
        }
        else if (cell.value) {
            source = cell.value.text;
        }
        return {
            success: true,
            cellType: cell.type,
            source
        };
    }
    /**
     * Метаданные ячейки для tool result
     */
    getCellMetadata(index) {
        var _a;
        const panel = this.getActiveNotebook();
        if (!panel) {
            return { success: false, error: 'No active notebook' };
        }
        const notebook = panel.content;
        const model = notebook.model;
        if (!model) {
            return { success: false, error: 'Notebook has no model' };
        }
        if (index < 0 || index >= model.cells.length) {
            return { success: false, error: `Invalid cell index: ${index}` };
        }
        const cell = model.cells.get(index);
        if (cell.type !== 'code') {
            return { success: false, error: 'Cell is not a code cell' };
        }
        const codeCell = cell;
        const outputs = codeCell.outputs;
        let hasError = false;
        for (let i = 0; i < outputs.length; i++) {
            const output = outputs.get(i);
            const raw = output === null || output === void 0 ? void 0 : output._raw;
            if ((raw === null || raw === void 0 ? void 0 : raw.output_type) === 'error') {
                hasError = true;
                break;
            }
        }
        return {
            success: true,
            execution_count: (_a = codeCell.executionCount) !== null && _a !== void 0 ? _a : null,
            outputs_count: outputs.length,
            has_error: hasError
        };
    }
    /**
     * Получить содержимое всего ноутбука
     */
    getNotebookContent() {
        var _a;
        const panel = this.getActiveNotebook();
        if (!panel) {
            return { success: false, error: 'No active notebook' };
        }
        const notebook = panel.content;
        const model = notebook.model;
        if (!model) {
            return { success: false, error: 'Notebook has no model' };
        }
        const cells = [];
        for (let i = 0; i < model.cells.length; i++) {
            const cell = model.cells.get(i);
            let source = '';
            if (cell.sharedModel) {
                source = cell.sharedModel.getSource();
            }
            else if (cell.value) {
                source = cell.value.text;
            }
            const cellData = {
                type: cell.type,
                source
            };
            if (cell.type === 'code') {
                const codeCell = cell;
                const outputs = codeCell.outputs;
                const executionCount = (_a = codeCell.executionCount) !== null && _a !== void 0 ? _a : null;
                let hasError = false;
                let imageCount = 0;
                let textCount = 0;
                let htmlCount = 0;
                let jsonCount = 0;
                for (let j = 0; j < outputs.length; j++) {
                    const output = outputs.get(j);
                    const raw = output === null || output === void 0 ? void 0 : output._raw;
                    if ((raw === null || raw === void 0 ? void 0 : raw.output_type) === 'error') {
                        hasError = true;
                    }
                    else if (raw === null || raw === void 0 ? void 0 : raw.data) {
                        const data = raw.data;
                        if (data['image/png'] ||
                            data['image/jpeg'] ||
                            data['image/svg+xml']) {
                            imageCount++;
                        }
                        else if (data['text/html']) {
                            htmlCount++;
                        }
                        else if (data['application/json']) {
                            jsonCount++;
                        }
                        else if (data['text/plain']) {
                            textCount++;
                        }
                    }
                    else if ((raw === null || raw === void 0 ? void 0 : raw.output_type) === 'stream') {
                        textCount++;
                    }
                }
                cellData.execution_count = executionCount;
                cellData.outputs_count = outputs.length;
                cellData.has_error = hasError;
                const summaryParts = [];
                if (outputs.length === 0) {
                    summaryParts.push('no output');
                }
                else {
                    if (imageCount > 0) {
                        summaryParts.push(`${imageCount} image${imageCount > 1 ? 's' : ''}`);
                    }
                    if (htmlCount > 0) {
                        summaryParts.push(`${htmlCount} HTML`);
                    }
                    if (jsonCount > 0) {
                        summaryParts.push(`${jsonCount} JSON`);
                    }
                    if (textCount > 0) {
                        summaryParts.push(`${textCount} text`);
                    }
                }
                if (hasError) {
                    summaryParts.push('ERROR');
                }
                cellData.outputs_summary = summaryParts.join(', ');
            }
            cells.push(cellData);
        }
        return { success: true, cells };
    }
    /**
     * Выполнить ячейку (code) или отрендерить markdown ячейку
     * @param timeoutMs — максимальное время ожидания в мс (по умолчанию 120000 = 2 мин)
     */
    async executeCell(index, timeoutMs = 120000) {
        var _a, _b, _c;
        const panel = this.getActiveNotebook();
        if (!panel) {
            return { success: false, error: 'No active notebook' };
        }
        const notebook = panel.content;
        const model = notebook.model;
        if (!model) {
            return { success: false, error: 'Notebook has no model' };
        }
        if (index < 0 || index >= model.cells.length) {
            return { success: false, error: `Invalid cell index: ${index}` };
        }
        const cell = model.cells.get(index);
        // Делаем ячейку активной
        notebook.activeCellIndex = index;
        // Для markdown ячеек — рендерим через команду
        if (cell.type === 'markdown') {
            await this.app.commands.execute('notebook:render-all-markdown');
            // Небольшая пауза для рендеринга
            await new Promise(resolve => setTimeout(resolve, 100));
            return { success: true };
        }
        // Для code ячеек — выполняем через ядро
        if (cell.type !== 'code') {
            return { success: false, error: `Unsupported cell type: ${cell.type}` };
        }
        // Проверяем подключение ядра
        const session = panel.sessionContext;
        if (!((_a = session.session) === null || _a === void 0 ? void 0 : _a.kernel)) {
            return { success: false, error: 'No kernel connected' };
        }
        // Выполняем через команду JupyterLab
        await this.app.commands.execute('notebook:run-cell', { activate: false });
        // Ждём завершения ядра с таймаутом
        const waitResult = await this.waitForKernelIdle(timeoutMs);
        if (!waitResult.success) {
            // ★ Прерываем ядро при таймауте
            if ((_b = waitResult.error) === null || _b === void 0 ? void 0 : _b.includes('timeout')) {
                try {
                    const kernel = (_c = panel.sessionContext.session) === null || _c === void 0 ? void 0 : _c.kernel;
                    if (kernel) {
                        await kernel.interrupt();
                    }
                }
                catch (_d) {
                    // Игнорируем ошибки прерывания
                }
            }
            return { success: false, error: waitResult.error };
        }
        // Маленькая пауза для синхронизации output model
        await new Promise(resolve => setTimeout(resolve, 100));
        return { success: true };
    }
    /**
     * Получить вывод ячейки (обновлённый — с поддержкой изображений)
     */
    getCellOutput(index) {
        var _a, _b;
        const panel = this.getActiveNotebook();
        if (!panel) {
            return { success: false, error: 'No active notebook' };
        }
        const notebook = panel.content;
        const model = notebook.model;
        if (!model) {
            return { success: false, error: 'Notebook has no model' };
        }
        if (index < 0 || index >= model.cells.length) {
            return { success: false, error: `Invalid cell index: ${index}` };
        }
        const cell = model.cells.get(index);
        if (cell.type !== 'code') {
            return { success: false, error: 'Cell is not a code cell' };
        }
        const codeCell = cell;
        const outputs = [];
        for (let i = 0; i < codeCell.outputs.length; i++) {
            const output = codeCell.outputs.get(i);
            // В JupyterLab 4.3+ output це Y.Map, тому використовуємо toJSON() для отримання даних
            let outputData;
            let outputType;
            // Спосіб 1: через toJSON() — повертає звичайний об'єкт
            if (typeof output.toJSON === 'function') {
                outputData = output.toJSON();
                outputType = outputData === null || outputData === void 0 ? void 0 : outputData.output_type;
            }
            // Спосіб 2: через _raw
            else if (output._raw) {
                outputData = output._raw;
                outputType = outputData === null || outputData === void 0 ? void 0 : outputData.output_type;
            }
            else {
                outputData = output;
                outputType = ((_a = outputData.get) === null || _a === void 0 ? void 0 : _a.call(outputData, 'output_type')) || outputData.output_type;
            }
            let data = {};
            if (outputData === null || outputData === void 0 ? void 0 : outputData.data) {
                data = outputData.data;
            }
            switch (outputType) {
                case 'stream':
                    outputs.push({
                        type: 'text',
                        text: outputData.text || ((_b = outputData.get) === null || _b === void 0 ? void 0 : _b.call(outputData, 'text'))
                    });
                    break;
                case 'execute_result':
                case 'display_data': {
                    // Приоритет: image > html > json > text
                    if (data['image/png']) {
                        const pngData = data['image/png'];
                        outputs.push({
                            type: 'image',
                            mimeType: 'image/png',
                            data: pngData,
                            text: data['text/plain'] || '(image)'
                        });
                    }
                    else if (data['image/jpeg']) {
                        const jpegData = data['image/jpeg'];
                        outputs.push({
                            type: 'image',
                            mimeType: 'image/jpeg',
                            data: jpegData,
                            text: data['text/plain'] || '(image)'
                        });
                    }
                    else if (data['image/svg+xml']) {
                        const svgData = data['image/svg+xml'];
                        outputs.push({
                            type: 'image',
                            mimeType: 'image/svg+xml',
                            data: svgData,
                            text: data['text/plain'] || '(SVG image)'
                        });
                    }
                    else if (data['text/html']) {
                        outputs.push({
                            type: 'html',
                            html: data['text/html'],
                            text: data['text/plain'] || '(HTML output)'
                        });
                    }
                    else if (data['application/json']) {
                        outputs.push({
                            type: 'json',
                            text: JSON.stringify(data['application/json'], null, 2)
                        });
                    }
                    else if (data['text/plain']) {
                        outputs.push({
                            type: 'text',
                            text: data['text/plain']
                        });
                    }
                    break;
                }
                case 'error':
                    outputs.push({
                        type: 'error',
                        text: `${outputData.ename}: ${outputData.evalue}`
                    });
                    break;
            }
        }
        return { success: true, outputs };
    }
    /**
     * Дождаться завершения выполнения ядра (busy → idle)
     * @param timeoutMs — максимальное время ожидания (по умолчанию 120 секунд)
     * @returns true если ядро перешло в idle, false если таймаут
     */
    async waitForKernelIdle(timeoutMs = 120000) {
        var _a;
        const panel = this.getActiveNotebook();
        if (!panel) {
            return { success: false, error: 'No active notebook' };
        }
        const session = panel.sessionContext;
        const kernel = (_a = session.session) === null || _a === void 0 ? void 0 : _a.kernel;
        if (!kernel) {
            return { success: false, error: 'No kernel connected' };
        }
        // Если ядро уже idle — сразу возвращаем
        if (kernel.status === 'idle') {
            return { success: true };
        }
        // Ждём перехода в idle
        return new Promise(resolve => {
            let resolved = false;
            const onStatusChanged = (_kernel, status) => {
                if (resolved) {
                    return;
                }
                if (status === 'idle') {
                    resolved = true;
                    kernel.statusChanged.disconnect(onStatusChanged);
                    clearTimeout(timer);
                    resolve({ success: true });
                }
                else if (status === 'dead' || status === 'restarting') {
                    resolved = true;
                    kernel.statusChanged.disconnect(onStatusChanged);
                    clearTimeout(timer);
                    resolve({
                        success: false,
                        error: `Kernel ${status} during execution`
                    });
                }
            };
            // Таймаут
            const timer = setTimeout(() => {
                if (!resolved) {
                    resolved = true;
                    kernel.statusChanged.disconnect(onStatusChanged);
                    resolve({
                        success: false,
                        error: `Kernel timeout after ${timeoutMs / 1000}s`
                    });
                }
            }, timeoutMs);
            // Подписываемся на изменение статуса
            kernel.statusChanged.connect(onStatusChanged);
        });
    }
    // ═══════════════════════════════════════════
    // Файловая система
    // ═══════════════════════════════════════════
    /**
     * Прочитать содержимое файла
     */
    async readFile(path) {
        var _a;
        try {
            const safePath = this.sanitizePath(path);
            const model = await this.contents.get(safePath, {
                content: true,
                type: 'file',
                format: 'text'
            });
            return {
                success: true,
                content: model.content,
                mimeType: model.mimetype || 'text/plain',
                size: ((_a = model.content) === null || _a === void 0 ? void 0 : _a.length) || 0
            };
        }
        catch (error) {
            const msg = error instanceof Error ? error.message : String(error);
            if (msg.includes('404') || msg.includes('not found')) {
                return { success: false, error: `File not found: ${path}` };
            }
            if (msg.includes('400') || msg.includes('is a directory')) {
                return {
                    success: false,
                    error: `Path is a directory, not a file: ${path}. Use list_directory instead.`
                };
            }
            return { success: false, error: `Failed to read file: ${msg}` };
        }
    }
    /**
     * Записать содержимое в файл (создать или перезаписать)
     */
    async writeFile(path, content) {
        try {
            const safePath = this.sanitizePath(path);
            let exists = true;
            try {
                await this.contents.get(safePath, { content: false });
            }
            catch (_a) {
                exists = false;
            }
            await this.ensureDirectory(safePath);
            await this.contents.save(safePath, {
                type: 'file',
                format: 'text',
                content: content
            });
            return {
                success: true,
                created: !exists
            };
        }
        catch (error) {
            const msg = error instanceof Error ? error.message : String(error);
            return { success: false, error: `Failed to write file: ${msg}` };
        }
    }
    /**
     * Получить список файлов в директории
     */
    async listDirectory(path = '') {
        try {
            const safePath = this.sanitizePath(path);
            const model = await this.contents.get(safePath, {
                content: true,
                type: 'directory'
            });
            if (model.type !== 'directory') {
                return { success: false, error: `Path is not a directory: ${path}` };
            }
            const items = model.content.map(item => ({
                name: item.name,
                path: item.path,
                type: item.type,
                size: item.size || undefined,
                lastModified: item.last_modified || undefined
            }));
            items.sort((a, b) => {
                if (a.type === 'directory' && b.type !== 'directory') {
                    return -1;
                }
                if (a.type !== 'directory' && b.type === 'directory') {
                    return 1;
                }
                return a.name.localeCompare(b.name);
            });
            return { success: true, items };
        }
        catch (error) {
            const msg = error instanceof Error ? error.message : String(error);
            return { success: false, error: `Failed to list directory: ${msg}` };
        }
    }
    /**
     * Создать новый ноутбук
     */
    async createNotebook(name, path = '') {
        try {
            if (!name.endsWith('.ipynb')) {
                name = name + '.ipynb';
            }
            const safePath = this.sanitizePath(path);
            const fullPath = safePath ? `${safePath}/${name}` : name;
            try {
                await this.contents.get(fullPath, { content: false });
                return {
                    success: false,
                    error: `Notebook already exists: ${fullPath}`
                };
            }
            catch (_a) {
                // Файл не существует
            }
            const notebookContent = {
                cells: [
                    {
                        cell_type: 'code',
                        source: '',
                        metadata: {},
                        outputs: [],
                        execution_count: null
                    }
                ],
                metadata: {
                    kernelspec: {
                        display_name: 'Python 3',
                        language: 'python',
                        name: 'python3'
                    },
                    language_info: {
                        name: 'python',
                        version: '3.9.0'
                    }
                },
                nbformat: 4,
                nbformat_minor: 5
            };
            await this.contents.save(fullPath, {
                type: 'notebook',
                format: 'json',
                content: notebookContent
            });
            return { success: true, path: fullPath };
        }
        catch (error) {
            const msg = error instanceof Error ? error.message : String(error);
            return { success: false, error: `Failed to create notebook: ${msg}` };
        }
    }
    /**
     * Удалить файл или директорию
     */
    async deleteFile(path) {
        try {
            const safePath = this.sanitizePath(path);
            await this.contents.delete(safePath);
            return { success: true };
        }
        catch (error) {
            const msg = error instanceof Error ? error.message : String(error);
            return { success: false, error: `Failed to delete: ${msg}` };
        }
    }
    /**
     * Переименовать/переместить файл
     */
    async renameFile(oldPath, newPath) {
        try {
            const safeOld = this.sanitizePath(oldPath);
            const safeNew = this.sanitizePath(newPath);
            await this.contents.rename(safeOld, safeNew);
            return { success: true };
        }
        catch (error) {
            const msg = error instanceof Error ? error.message : String(error);
            return { success: false, error: `Failed to rename: ${msg}` };
        }
    }
    // ═══════════════════════════════════════════
    // Вспомогательные методы
    // ═══════════════════════════════════════════
    /**
     * Санитизация пути — защита от path traversal
     */
    sanitizePath(path) {
        const safe = path.replace(/^\/+/, '');
        const parts = safe.split('/').filter(part => {
            return part !== '' && part !== '.' && part !== '..';
        });
        return parts.join('/');
    }
    /**
     * Создать промежуточные директории для файла
     */
    async ensureDirectory(filePath) {
        const parts = filePath.split('/');
        parts.pop();
        if (parts.length === 0) {
            return;
        }
        let currentPath = '';
        for (const part of parts) {
            currentPath = currentPath ? `${currentPath}/${part}` : part;
            try {
                await this.contents.get(currentPath, { content: false });
            }
            catch (_a) {
                await this.contents.save(currentPath, {
                    type: 'directory',
                    format: 'json',
                    content: null
                });
            }
        }
    }
    /**
     * Найти текст во всех ячейках ноутбука
     */
    findInNotebook(query, options) {
        var _a, _b;
        const panel = this.getActiveNotebook();
        if (!panel) {
            return { success: false, error: 'No active notebook' };
        }
        const model = panel.content.model;
        if (!model) {
            return { success: false, error: 'Notebook has no model' };
        }
        const caseSensitive = (_a = options === null || options === void 0 ? void 0 : options.caseSensitive) !== null && _a !== void 0 ? _a : false;
        const useRegex = (_b = options === null || options === void 0 ? void 0 : options.regex) !== null && _b !== void 0 ? _b : false;
        const filterType = options === null || options === void 0 ? void 0 : options.cellType;
        let searchRegex;
        try {
            if (useRegex) {
                searchRegex = new RegExp(query, caseSensitive ? 'g' : 'gi');
            }
            else {
                const escaped = query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                searchRegex = new RegExp(escaped, caseSensitive ? 'g' : 'gi');
            }
        }
        catch (e) {
            return { success: false, error: `Invalid regex: ${query}` };
        }
        const matches = [];
        for (let i = 0; i < model.cells.length; i++) {
            const cell = model.cells.get(i);
            if (filterType && cell.type !== filterType) {
                continue;
            }
            let source = '';
            if (cell.sharedModel) {
                source = cell.sharedModel.getSource();
            }
            else if (cell.value) {
                source = cell.value.text;
            }
            const lines = source.split('\n');
            for (let lineIdx = 0; lineIdx < lines.length; lineIdx++) {
                const line = lines[lineIdx];
                let match;
                searchRegex.lastIndex = 0;
                while ((match = searchRegex.exec(line)) !== null) {
                    matches.push({
                        cellIndex: i,
                        cellType: cell.type,
                        lineNumber: lineIdx + 1,
                        line: line,
                        matchStart: match.index,
                        matchEnd: match.index + match[0].length
                    });
                    if (match[0].length === 0) {
                        searchRegex.lastIndex++;
                    }
                }
            }
        }
        return { success: true, matches };
    }
    /**
     * Заменить текст в конкретной ячейке
     */
    replaceInCell(index, searchText, replaceText, options) {
        var _a, _b, _c;
        const panel = this.getActiveNotebook();
        if (!panel) {
            return { success: false, error: 'No active notebook' };
        }
        const model = panel.content.model;
        if (!model) {
            return { success: false, error: 'Notebook has no model' };
        }
        if (index < 0 || index >= model.cells.length) {
            return { success: false, error: `Invalid cell index: ${index}` };
        }
        const cell = model.cells.get(index);
        let source = '';
        if (cell.sharedModel) {
            source = cell.sharedModel.getSource();
        }
        else if (cell.value) {
            source = cell.value.text;
        }
        const caseSensitive = (_a = options === null || options === void 0 ? void 0 : options.caseSensitive) !== null && _a !== void 0 ? _a : false;
        const useRegex = (_b = options === null || options === void 0 ? void 0 : options.regex) !== null && _b !== void 0 ? _b : false;
        const replaceAll = (_c = options === null || options === void 0 ? void 0 : options.replaceAll) !== null && _c !== void 0 ? _c : true;
        let searchRegex;
        try {
            let flags = caseSensitive ? '' : 'i';
            if (replaceAll) {
                flags += 'g';
            }
            if (useRegex) {
                searchRegex = new RegExp(searchText, flags);
            }
            else {
                const escaped = searchText.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
                searchRegex = new RegExp(escaped, flags);
            }
        }
        catch (e) {
            return { success: false, error: `Invalid search pattern: ${searchText}` };
        }
        const matchCount = (source.match(searchRegex) || []).length;
        if (matchCount === 0) {
            return {
                success: false,
                error: `Text "${searchText}" not found in cell ${index}`
            };
        }
        const newSource = source.replace(searchRegex, replaceText);
        if (cell.sharedModel) {
            cell.sharedModel.setSource(newSource);
        }
        else if (cell.value) {
            cell.value.text = newSource;
        }
        return { success: true, replacements: matchCount };
    }
}


/***/ },

/***/ "./lib/permission-manager.js"
/*!***********************************!*\
  !*** ./lib/permission-manager.js ***!
  \***********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PermissionManager: () => (/* binding */ PermissionManager)
/* harmony export */ });
/* harmony import */ var _tools__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tools */ "./lib/tools.js");

const DEFAULT_PERMISSIONS = {
    enabledCategories: {
        notebook: true,
        files: true,
        shell: true,
        packages: true,
        search: true
    },
    confirmLevels: new Set([_tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.SYSTEM]),
    blockedTools: new Set(),
    alwaysConfirmTools: new Set(['delete_file', 'run_shell', 'delete_cell'])
};
/**
 * Менеджер разрешений для инструментов
 */
class PermissionManager {
    constructor(config) {
        var _a, _b, _c;
        this.config = {
            ...DEFAULT_PERMISSIONS,
            ...config,
            enabledCategories: {
                ...DEFAULT_PERMISSIONS.enabledCategories,
                ...config === null || config === void 0 ? void 0 : config.enabledCategories
            },
            confirmLevels: (_a = config === null || config === void 0 ? void 0 : config.confirmLevels) !== null && _a !== void 0 ? _a : new Set(DEFAULT_PERMISSIONS.confirmLevels),
            blockedTools: (_b = config === null || config === void 0 ? void 0 : config.blockedTools) !== null && _b !== void 0 ? _b : new Set(DEFAULT_PERMISSIONS.blockedTools),
            alwaysConfirmTools: (_c = config === null || config === void 0 ? void 0 : config.alwaysConfirmTools) !== null && _c !== void 0 ? _c : new Set(DEFAULT_PERMISSIONS.alwaysConfirmTools)
        };
    }
    /**
     * Обновить конфигурацию
     */
    updateConfig(updates) {
        if (updates.enabledCategories) {
            this.config.enabledCategories = {
                ...this.config.enabledCategories,
                ...updates.enabledCategories
            };
        }
        if (updates.confirmLevels) {
            this.config.confirmLevels = updates.confirmLevels;
        }
        if (updates.blockedTools) {
            this.config.blockedTools = updates.blockedTools;
        }
        if (updates.alwaysConfirmTools) {
            this.config.alwaysConfirmTools = updates.alwaysConfirmTools;
        }
    }
    /**
     * Проверить, разрешён ли инструмент
     */
    isAllowed(tool) {
        // Проверяем блокировку по имени
        if (this.config.blockedTools.has(tool.name)) {
            return false;
        }
        // Проверяем категорию
        if (!this.config.enabledCategories[tool.category]) {
            return false;
        }
        return true;
    }
    /**
     * Проверить, требуется ли подтверждение
     * @param autoMode — включён ли авто-режим
     */
    requiresConfirmation(tool, autoMode) {
        // Если auto-mode выключен — подтверждение для всех
        if (!autoMode) {
            return true;
        }
        // alwaysConfirm на уровне инструмента
        if (tool.alwaysConfirm) {
            return true;
        }
        // alwaysConfirm в конфигурации
        if (this.config.alwaysConfirmTools.has(tool.name)) {
            return true;
        }
        // Проверяем уровень безопасности
        if (this.config.confirmLevels.has(tool.safetyLevel)) {
            return true;
        }
        return false;
    }
    /**
     * Фильтровать список инструментов — оставить только разрешённые
     */
    filterTools(tools) {
        return tools.filter(tool => this.isAllowed(tool));
    }
    /**
     * Get safety level description
     */
    static getSafetyDescription(level) {
        switch (level) {
            case _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.READ:
                return { label: 'Read-only', icon: '👁', color: '#4caf50' };
            case _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.WRITE:
                return { label: 'Write', icon: '✏️', color: '#ff9800' };
            case _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.EXECUTE:
                return { label: 'Execute', icon: '▶️', color: '#f57c00' };
            case _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.SYSTEM:
                return { label: 'System', icon: '⚠️', color: '#f44336' };
        }
    }
    /**
     * Get confirmation CSS class by safety level
     */
    static getConfirmationClass(level) {
        switch (level) {
            case _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.READ:
                return 'confirm-read';
            case _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.WRITE:
                return 'confirm-write';
            case _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.EXECUTE:
                return 'confirm-execute';
            case _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.SYSTEM:
                return 'confirm-system';
        }
    }
    /**
     * Получить текущую конфигурацию
     */
    getConfig() {
        return { ...this.config };
    }
    /**
     * Включить/выключить категорию инструментов
     */
    setCategoryEnabled(category, enabled) {
        this.updateConfig({
            enabledCategories: {
                ...this.config.enabledCategories,
                [category]: enabled
            }
        });
    }
    /**
     * Добавить инструмент в заблокированные
     */
    blockTool(toolName) {
        const blocked = new Set(this.config.blockedTools);
        blocked.add(toolName);
        this.updateConfig({ blockedTools: blocked });
    }
    /**
     * Разблокировать инструмент
     */
    unblockTool(toolName) {
        const blocked = new Set(this.config.blockedTools);
        blocked.delete(toolName);
        this.updateConfig({ blockedTools: blocked });
    }
    /**
     * Проверить, включена ли категория
     */
    isCategoryEnabled(category) {
        return this.config.enabledCategories[category];
    }
}


/***/ },

/***/ "./lib/settings-api.js"
/*!*****************************!*\
  !*** ./lib/settings-api.js ***!
  \*****************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getSettings: () => (/* binding */ getSettings),
/* harmony export */   testConnection: () => (/* binding */ testConnection),
/* harmony export */   updateSettings: () => (/* binding */ updateSettings)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


const settingsEndpoint = (path = '') => {
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    return _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'ai-agent', 'settings', path);
};
/**
 * Получить текущие настройки
 */
async function getSettings() {
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(settingsEndpoint(), {}, settings);
    if (response.status !== 200) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.error || 'Failed to load settings');
    }
    return await response.json();
}
/**
 * Обновить настройки
 */
async function updateSettings(updates) {
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(settingsEndpoint('update'), {
        method: 'POST',
        body: JSON.stringify(updates)
    }, settings);
    if (response.status !== 200) {
        const data = await response.json().catch(() => ({}));
        throw new Error(data.error || 'Failed to update settings');
    }
    return await response.json();
}
/**
 * Тестировать подключение к API
 */
async function testConnection(params) {
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(settingsEndpoint('test'), {
        method: 'POST',
        body: JSON.stringify(params)
    }, settings);
    return await response.json();
}


/***/ },

/***/ "./lib/settings-dialog.js"
/*!********************************!*\
  !*** ./lib/settings-dialog.js ***!
  \********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   renderSettingsPanelContent: () => (/* binding */ renderSettingsPanelContent),
/* harmony export */   showSettingsDialog: () => (/* binding */ showSettingsDialog)
/* harmony export */ });
/* harmony import */ var _settings_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./settings-api */ "./lib/settings-api.js");
/* harmony import */ var _icons__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./icons */ "./lib/icons/index.js");


function generateId() {
    return 'profile-' + Math.random().toString(36).substring(2, 11);
}
async function showSettingsDialog(container, onSettingsChanged) {
    var _a, _b;
    const overlay = document.createElement('div');
    overlay.className = 'ai-agent-settings-overlay';
    const dialog = document.createElement('div');
    dialog.className = 'ai-agent-settings-dialog';
    dialog.innerHTML = `
<div class="ai-agent-settings-header">
<h3>AI Agent Settings</h3>
<button class="ai-agent-settings-close">⨯</button>
</div>
<div class="ai-agent-settings-body">
<div class="ai-agent-settings-loading">Loading settings...</div>
</div>
<div class="ai-agent-settings-footer">
<button class="ai-agent-settings-test">Test Connection</button>
<div class="ai-agent-settings-spacer"></div>
<button class="ai-agent-settings-cancel">Cancel</button>
<button class="ai-agent-settings-save">Save</button>
</div>
`;
    overlay.appendChild(dialog);
    container.appendChild(overlay);
    const close = () => overlay.remove();
    overlay.addEventListener('click', e => {
        if (e.target === overlay) {
            close();
        }
    });
    (_a = dialog
        .querySelector('.ai-agent-settings-close')) === null || _a === void 0 ? void 0 : _a.addEventListener('click', close);
    (_b = dialog
        .querySelector('.ai-agent-settings-cancel')) === null || _b === void 0 ? void 0 : _b.addEventListener('click', close);
    let currentSettings;
    try {
        currentSettings = await (0,_settings_api__WEBPACK_IMPORTED_MODULE_0__.getSettings)();
    }
    catch (e) {
        const body = dialog.querySelector('.ai-agent-settings-body');
        body.innerHTML = `<div class="ai-agent-settings-error">Load error: ${e}</div>`;
        return;
    }
    const body = dialog.querySelector('.ai-agent-settings-body');
    renderSettingsForm(body, currentSettings, dialog, close, onSettingsChanged);
}
async function renderSettingsPanelContent(panel, onClose, onSettingsChanged) {
    var _a;
    panel.innerHTML = '';
    const header = document.createElement('div');
    header.className = 'ai-agent-settings-header';
    header.innerHTML = `
<h3>AI Agent Settings</h3>
<button class="ai-agent-settings-close" title="Close">⨯</button>
`;
    (_a = header
        .querySelector('.ai-agent-settings-close')) === null || _a === void 0 ? void 0 : _a.addEventListener('click', () => {
        onClose === null || onClose === void 0 ? void 0 : onClose();
    });
    panel.appendChild(header);
    const body = document.createElement('div');
    body.className = 'ai-agent-settings-body';
    panel.appendChild(body);
    const footer = document.createElement('div');
    footer.className = 'ai-agent-settings-footer';
    footer.innerHTML = `
<button class="ai-agent-settings-test">Test Connection</button>
<div class="ai-agent-settings-spacer"></div>
<button class="ai-agent-settings-save">Save</button>
`;
    panel.appendChild(footer);
    const currentSettings = await (0,_settings_api__WEBPACK_IMPORTED_MODULE_0__.getSettings)();
    renderSettingsForm(body, currentSettings, panel, onClose || (() => { }), onSettingsChanged);
}
function renderSettingsForm(body, currentSettings, container, close, onSettingsChanged) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o;
    body.innerHTML = '';
    // Local state for profiles
    let profiles = JSON.parse(JSON.stringify(currentSettings.profiles));
    let activeProfileId = currentSettings.active_profile_id;
    const deletedProfileIds = new Set();
    // Helper to get active profile
    const getActiveProfile = () => {
        const profile = profiles.find(p => p.id === activeProfileId);
        return (profile ||
            profiles[0] || {
            id: 'default',
            name: 'Default',
            base_url: '',
            model: '',
            temperature: 0.3,
            max_tokens: 0
        });
    };
    // ─── Profile Selector Section ───
    const profileSection = createSection('Profile');
    const profileRow = document.createElement('div');
    profileRow.className = 'ai-agent-settings-profile-row';
    const profileSelect = document.createElement('select');
    profileSelect.className = 'ai-agent-settings-select';
    profileSelect.id = 'settings-profile-select';
    profiles.forEach(p => {
        const option = document.createElement('option');
        option.value = p.id;
        option.textContent = p.name;
        option.selected = p.id === activeProfileId;
        profileSelect.appendChild(option);
    });
    // Add profile button
    const addBtn = document.createElement('button');
    addBtn.className = 'ai-agent-settings-profile-btn';
    addBtn.title = 'Add new profile';
    const addIcon = _icons__WEBPACK_IMPORTED_MODULE_1__.addProfileIcon.element();
    addIcon.style.width = '16px';
    addIcon.style.height = '16px';
    addBtn.appendChild(addIcon);
    addBtn.addEventListener('click', () => {
        const name = prompt('Enter profile name:', 'New Profile');
        if (name) {
            const newProfile = {
                id: generateId(),
                name,
                base_url: '',
                model: '',
                temperature: 0.3,
                max_tokens: 0
            };
            profiles.push(newProfile);
            activeProfileId = newProfile.id;
            const option = document.createElement('option');
            option.value = newProfile.id;
            option.textContent = newProfile.name;
            option.selected = true;
            profileSelect.appendChild(option);
            updateFormForProfile(newProfile);
        }
    });
    // Edit profile name button
    const editBtn = document.createElement('button');
    editBtn.className = 'ai-agent-settings-profile-btn';
    editBtn.title = 'Edit profile name';
    const editIcon = _icons__WEBPACK_IMPORTED_MODULE_1__.editProfileIcon.element();
    editIcon.style.width = '16px';
    editIcon.style.height = '16px';
    editBtn.appendChild(editIcon);
    editBtn.addEventListener('click', () => {
        const profile = getActiveProfile();
        const newName = prompt('Enter new profile name:', profile.name);
        if (newName && newName !== profile.name) {
            profile.name = newName;
            const option = profileSelect.querySelector(`option[value="${profile.id}"]`);
            if (option) {
                option.textContent = newName;
            }
        }
    });
    // Delete profile button
    const deleteBtn = document.createElement('button');
    deleteBtn.className = 'ai-agent-settings-profile-btn';
    deleteBtn.title = 'Delete profile';
    const deleteIcon = _icons__WEBPACK_IMPORTED_MODULE_1__.deleteProfileIcon.element();
    deleteIcon.style.width = '16px';
    deleteIcon.style.height = '16px';
    deleteBtn.appendChild(deleteIcon);
    deleteBtn.disabled = profiles.length <= 1;
    deleteBtn.addEventListener('click', () => {
        if (profiles.length <= 1) {
            return;
        }
        const profile = getActiveProfile();
        if (confirm(`Delete profile "${profile.name}"?`)) {
            deletedProfileIds.add(profile.id);
            profiles = profiles.filter(p => p.id !== profile.id);
            const option = profileSelect.querySelector(`option[value="${profile.id}"]`);
            if (option) {
                option.remove();
            }
            activeProfileId = profiles[0].id;
            profileSelect.value = activeProfileId;
            updateFormForProfile(profiles[0]);
            deleteBtn.disabled = profiles.length <= 1;
        }
    });
    profileRow.appendChild(profileSelect);
    profileRow.appendChild(addBtn);
    profileRow.appendChild(editBtn);
    profileRow.appendChild(deleteBtn);
    profileSection.appendChild(profileRow);
    body.appendChild(profileSection);
    // ─── API Base URL ───
    const baseUrlSection = createSection('API Base URL');
    const baseUrlInput = document.createElement('input');
    baseUrlInput.type = 'text';
    baseUrlInput.className = 'ai-agent-settings-input';
    baseUrlInput.id = 'settings-base-url';
    baseUrlInput.placeholder = 'https://openrouter.ai/api/v1';
    baseUrlSection.appendChild(baseUrlInput);
    body.appendChild(baseUrlSection);
    // ─── API Key ───
    const apiKeySection = createSection('API Key');
    const apiKeyInput = document.createElement('input');
    apiKeyInput.type = 'password';
    apiKeyInput.className = 'ai-agent-settings-input';
    apiKeyInput.id = 'settings-api-key';
    apiKeyInput.placeholder = 'Enter API key...';
    const showKeyBtn = document.createElement('button');
    showKeyBtn.className = 'ai-agent-settings-toggle-key';
    showKeyBtn.textContent = 'Show';
    showKeyBtn.title = 'Show/hide key';
    showKeyBtn.addEventListener('click', () => {
        apiKeyInput.type = apiKeyInput.type === 'password' ? 'text' : 'password';
    });
    const keyRow = document.createElement('div');
    keyRow.className = 'ai-agent-settings-row';
    keyRow.appendChild(apiKeyInput);
    keyRow.appendChild(showKeyBtn);
    apiKeySection.appendChild(keyRow);
    body.appendChild(apiKeySection);
    // ─── Model ───
    const modelSection = createSection('Model');
    const modelInput = document.createElement('input');
    modelInput.type = 'text';
    modelInput.className = 'ai-agent-settings-input';
    modelInput.id = 'settings-model';
    modelInput.placeholder = 'e.g., google/gemini-2.0-flash:free';
    modelSection.appendChild(modelInput);
    body.appendChild(modelSection);
    // ─── Temperature ───
    const tempSection = createSection('Temperature');
    const tempSlider = document.createElement('input');
    tempSlider.type = 'range';
    tempSlider.className = 'ai-agent-settings-slider';
    tempSlider.id = 'settings-temperature';
    tempSlider.min = '0';
    tempSlider.max = '2';
    tempSlider.step = '0.1';
    const tempValue = document.createElement('span');
    tempValue.className = 'ai-agent-settings-slider-value';
    tempSlider.addEventListener('input', () => {
        tempValue.textContent = tempSlider.value;
    });
    const tempRow = document.createElement('div');
    tempRow.className = 'ai-agent-settings-row';
    tempRow.appendChild(tempSlider);
    tempRow.appendChild(tempValue);
    tempSection.appendChild(tempRow);
    body.appendChild(tempSection);
    // ─── Max Tokens ───
    const maxTokensSection = createSection('Max Response Tokens');
    const maxTokensInput = document.createElement('input');
    maxTokensInput.type = 'number';
    maxTokensInput.className = 'ai-agent-settings-input';
    maxTokensInput.id = 'settings-max-tokens';
    maxTokensInput.min = '0';
    maxTokensInput.max = '32768';
    maxTokensInput.placeholder = '0 = model default';
    maxTokensSection.appendChild(maxTokensInput);
    body.appendChild(maxTokensSection);
    // Function to update form for selected profile
    const updateFormForProfile = (profile) => {
        var _a, _b;
        baseUrlInput.value = profile.base_url || '';
        apiKeyInput.value = '';
        apiKeyInput.placeholder = profile.api_key
            ? 'Leave empty to keep current key'
            : 'Enter API key...';
        modelInput.value = profile.model || '';
        tempSlider.value = String((_a = profile.temperature) !== null && _a !== void 0 ? _a : 0.3);
        tempValue.textContent = tempSlider.value;
        maxTokensInput.value = String((_b = profile.max_tokens) !== null && _b !== void 0 ? _b : 0);
    };
    // Initial form population
    updateFormForProfile(getActiveProfile());
    // Handle profile selection change
    profileSelect.addEventListener('change', () => {
        activeProfileId = profileSelect.value;
        const profile = getActiveProfile();
        updateFormForProfile(profile);
    });
    // Update profile data when inputs change
    const updateCurrentProfileFromForm = () => {
        const profile = profiles.find(p => p.id === activeProfileId);
        if (profile) {
            profile.base_url = baseUrlInput.value;
            profile.model = modelInput.value;
            profile.temperature = parseFloat(tempSlider.value);
            profile.max_tokens = parseInt(maxTokensInput.value, 10);
            if (apiKeyInput.value) {
                profile.api_key = apiKeyInput.value;
            }
        }
    };
    baseUrlInput.addEventListener('change', updateCurrentProfileFromForm);
    modelInput.addEventListener('change', updateCurrentProfileFromForm);
    tempSlider.addEventListener('change', updateCurrentProfileFromForm);
    maxTokensInput.addEventListener('change', updateCurrentProfileFromForm);
    // ─── Auto Execute Tools ───
    const autoExecSection = createSection('Auto-execute Tools');
    const autoExecCheckbox = document.createElement('input');
    autoExecCheckbox.type = 'checkbox';
    autoExecCheckbox.className = 'ai-agent-settings-checkbox';
    autoExecCheckbox.id = 'settings-auto-execute';
    autoExecCheckbox.checked = (_a = currentSettings.auto_execute_tools) !== null && _a !== void 0 ? _a : true;
    const autoExecLabel = document.createElement('label');
    autoExecLabel.className = 'ai-agent-settings-checkbox-label';
    autoExecLabel.htmlFor = 'settings-auto-execute';
    autoExecLabel.textContent =
        'Automatically execute tool calls without confirmation';
    const autoExecRow = document.createElement('div');
    autoExecRow.className = 'ai-agent-settings-row';
    autoExecRow.appendChild(autoExecCheckbox);
    autoExecRow.appendChild(autoExecLabel);
    autoExecSection.appendChild(autoExecRow);
    body.appendChild(autoExecSection);
    // ─── Include Variables ───
    const includeVarsSection = createSection('Include Variables in Context');
    const includeVarsCheckbox = document.createElement('input');
    includeVarsCheckbox.type = 'checkbox';
    includeVarsCheckbox.className = 'ai-agent-settings-checkbox';
    includeVarsCheckbox.id = 'settings-include-variables';
    includeVarsCheckbox.checked = (_b = currentSettings.include_variables) !== null && _b !== void 0 ? _b : true;
    const includeVarsLabel = document.createElement('label');
    includeVarsLabel.className = 'ai-agent-settings-checkbox-label';
    includeVarsLabel.htmlFor = 'settings-include-variables';
    includeVarsLabel.textContent =
        'Automatically inspect kernel variables and include in context';
    const includeVarsRow = document.createElement('div');
    includeVarsRow.className = 'ai-agent-settings-row';
    includeVarsRow.appendChild(includeVarsCheckbox);
    includeVarsRow.appendChild(includeVarsLabel);
    includeVarsSection.appendChild(includeVarsRow);
    body.appendChild(includeVarsSection);
    // ─── Include Cell Outline ───
    const includeCellsSection = createSection('Include Cell Outline in Context');
    const includeCellsCheckbox = document.createElement('input');
    includeCellsCheckbox.type = 'checkbox';
    includeCellsCheckbox.className = 'ai-agent-settings-checkbox';
    includeCellsCheckbox.id = 'settings-include-cells';
    includeCellsCheckbox.checked = (_c = currentSettings.include_cell_outline) !== null && _c !== void 0 ? _c : true;
    const includeCellsLabel = document.createElement('label');
    includeCellsLabel.className = 'ai-agent-settings-checkbox-label';
    includeCellsLabel.htmlFor = 'settings-include-cells';
    includeCellsLabel.textContent =
        'Include notebook cell outline in automatic context';
    const includeCellsRow = document.createElement('div');
    includeCellsRow.className = 'ai-agent-settings-row';
    includeCellsRow.appendChild(includeCellsCheckbox);
    includeCellsRow.appendChild(includeCellsLabel);
    includeCellsSection.appendChild(includeCellsRow);
    body.appendChild(includeCellsSection);
    // ─── Max Agent Iterations ───
    const maxIterSection = createSection('Max Agent Iterations');
    const maxIterInput = document.createElement('input');
    maxIterInput.type = 'number';
    maxIterInput.className = 'ai-agent-settings-input';
    maxIterInput.id = 'settings-max-iterations';
    maxIterInput.value = String((_d = currentSettings.max_agent_iterations) !== null && _d !== void 0 ? _d : 15);
    maxIterInput.min = '1';
    maxIterInput.max = '50';
    maxIterSection.appendChild(maxIterInput);
    body.appendChild(maxIterSection);
    // ─── Enabled Tool Categories ───
    const toolsSection = createSection('Enabled Tool Categories');
    const toolCategories = [
        { key: 'notebook', label: 'Notebook Tools' },
        { key: 'files', label: 'File Operations' },
        { key: 'shell', label: 'Shell Commands' },
        { key: 'packages', label: 'Package Management' },
        { key: 'search', label: 'Search & Replace' }
    ];
    for (const cat of toolCategories) {
        const catRow = document.createElement('div');
        catRow.className = 'ai-agent-settings-row';
        const catCheckbox = document.createElement('input');
        catCheckbox.type = 'checkbox';
        catCheckbox.className = 'ai-agent-settings-checkbox';
        catCheckbox.id = `settings-tool-${cat.key}`;
        catCheckbox.checked =
            (_e = currentSettings.enabled_tool_categories[cat.key]) !== null && _e !== void 0 ? _e : true;
        const catLabel = document.createElement('label');
        catLabel.className = 'ai-agent-settings-checkbox-label';
        catLabel.htmlFor = `settings-tool-${cat.key}`;
        catLabel.textContent = cat.label;
        catRow.appendChild(catCheckbox);
        catRow.appendChild(catLabel);
        toolsSection.appendChild(catRow);
    }
    body.appendChild(toolsSection);
    // ─── Custom System Prompt ───
    const promptSection = createSection('Custom System Prompt Addition');
    const promptTextarea = document.createElement('textarea');
    promptTextarea.className = 'ai-agent-settings-textarea';
    promptTextarea.id = 'settings-custom-prompt';
    promptTextarea.value = currentSettings.custom_system_prompt || '';
    promptTextarea.placeholder = 'Additional instructions...';
    promptTextarea.rows = 4;
    promptSection.appendChild(promptTextarea);
    body.appendChild(promptSection);
    // ─── Image Analysis Settings ───
    const imgSection = createSection('Image Analysis');
    const imgEnabledRow = document.createElement('div');
    imgEnabledRow.className = 'ai-agent-settings-row';
    const imgEnabledCheckbox = document.createElement('input');
    imgEnabledCheckbox.type = 'checkbox';
    imgEnabledCheckbox.className = 'ai-agent-settings-checkbox';
    imgEnabledCheckbox.id = 'settings-img-enabled';
    imgEnabledCheckbox.checked = (_g = (_f = currentSettings.image_analysis) === null || _f === void 0 ? void 0 : _f.enabled) !== null && _g !== void 0 ? _g : true;
    const imgEnabledLabel = document.createElement('label');
    imgEnabledLabel.className = 'ai-agent-settings-checkbox-label';
    imgEnabledLabel.htmlFor = 'settings-img-enabled';
    imgEnabledLabel.textContent = 'Enable image analysis';
    imgEnabledRow.appendChild(imgEnabledCheckbox);
    imgEnabledRow.appendChild(imgEnabledLabel);
    imgSection.appendChild(imgEnabledRow);
    // Container for image analysis options (shown only when enabled)
    const imgOptionsContainer = document.createElement('div');
    imgOptionsContainer.className = 'ai-agent-settings-img-options';
    imgOptionsContainer.style.display = imgEnabledCheckbox.checked
        ? 'flex'
        : 'none';
    imgOptionsContainer.style.flexDirection = 'column';
    imgOptionsContainer.style.gap = '12px';
    const imgAutoRow = document.createElement('div');
    imgAutoRow.className = 'ai-agent-settings-row';
    const imgAutoCheckbox = document.createElement('input');
    imgAutoCheckbox.type = 'checkbox';
    imgAutoCheckbox.className = 'ai-agent-settings-checkbox';
    imgAutoCheckbox.id = 'settings-img-auto-suggest';
    imgAutoCheckbox.checked =
        (_j = (_h = currentSettings.image_analysis) === null || _h === void 0 ? void 0 : _h.auto_suggest) !== null && _j !== void 0 ? _j : true;
    const imgAutoLabel = document.createElement('label');
    imgAutoLabel.className = 'ai-agent-settings-checkbox-label';
    imgAutoLabel.htmlFor = 'settings-img-auto-suggest';
    imgAutoLabel.textContent = 'Auto-suggest analysis when image detected';
    imgAutoRow.appendChild(imgAutoCheckbox);
    imgAutoRow.appendChild(imgAutoLabel);
    imgOptionsContainer.appendChild(imgAutoRow);
    const imgUseActiveRow = document.createElement('div');
    imgUseActiveRow.className = 'ai-agent-settings-row';
    const imgUseActiveCheckbox = document.createElement('input');
    imgUseActiveCheckbox.type = 'checkbox';
    imgUseActiveCheckbox.className = 'ai-agent-settings-checkbox';
    imgUseActiveCheckbox.id = 'settings-img-use-active';
    imgUseActiveCheckbox.checked =
        ((_k = currentSettings.image_analysis) === null || _k === void 0 ? void 0 : _k.use_active_profile) !== false;
    const imgUseActiveLabel = document.createElement('label');
    imgUseActiveLabel.className = 'ai-agent-settings-checkbox-label';
    imgUseActiveLabel.htmlFor = 'settings-img-use-active';
    imgUseActiveLabel.textContent = 'Use active profile for vision';
    imgUseActiveRow.appendChild(imgUseActiveCheckbox);
    imgUseActiveRow.appendChild(imgUseActiveLabel);
    imgOptionsContainer.appendChild(imgUseActiveRow);
    // Vision profile selector (shown when use_active_profile is false)
    const imgProfileRow = document.createElement('div');
    imgProfileRow.className = 'ai-agent-settings-row';
    imgProfileRow.id = 'settings-img-profile-row';
    imgProfileRow.style.display = imgUseActiveCheckbox.checked ? 'none' : 'flex';
    const imgProfileSelect = document.createElement('select');
    imgProfileSelect.className = 'ai-agent-settings-select';
    imgProfileSelect.id = 'settings-img-profile';
    profiles.forEach(p => {
        var _a;
        const option = document.createElement('option');
        option.value = p.id;
        option.textContent = p.name;
        option.selected = p.id === ((_a = currentSettings.image_analysis) === null || _a === void 0 ? void 0 : _a.profile_id);
        imgProfileSelect.appendChild(option);
    });
    imgProfileRow.appendChild(imgProfileSelect);
    imgOptionsContainer.appendChild(imgProfileRow);
    imgUseActiveCheckbox.addEventListener('change', () => {
        imgProfileRow.style.display = imgUseActiveCheckbox.checked
            ? 'none'
            : 'flex';
    });
    const imgPromptTextarea = document.createElement('textarea');
    imgPromptTextarea.className = 'ai-agent-settings-textarea';
    imgPromptTextarea.id = 'settings-img-custom-prompt';
    imgPromptTextarea.value = ((_l = currentSettings.image_analysis) === null || _l === void 0 ? void 0 : _l.custom_prompt) || '';
    imgPromptTextarea.placeholder =
        'Optional: custom instructions for image analysis...';
    imgPromptTextarea.rows = 2;
    imgOptionsContainer.appendChild(imgPromptTextarea);
    imgSection.appendChild(imgOptionsContainer);
    body.appendChild(imgSection);
    // Toggle image analysis options visibility
    imgEnabledCheckbox.addEventListener('change', () => {
        imgOptionsContainer.style.display = imgEnabledCheckbox.checked
            ? 'flex'
            : 'none';
    });
    // ─── Test Status ───
    const testStatus = document.createElement('div');
    testStatus.className = 'ai-agent-settings-test-status';
    body.appendChild(testStatus);
    // ─── Test Connection Button ───
    (_m = container
        .querySelector('.ai-agent-settings-test')) === null || _m === void 0 ? void 0 : _m.addEventListener('click', async () => {
        testStatus.innerHTML = 'Testing...';
        testStatus.className = 'ai-agent-settings-test-status testing';
        try {
            const profile = getActiveProfile();
            const result = await (0,_settings_api__WEBPACK_IMPORTED_MODULE_0__.testConnection)({
                base_url: baseUrlInput.value || undefined,
                model: modelInput.value || undefined,
                api_key: apiKeyInput.value || undefined,
                profile_id: profile.id
            });
            if (result.success) {
                testStatus.innerHTML = `✓ ${result.response} (${result.latency_ms}ms)`;
                testStatus.className = 'ai-agent-settings-test-status success';
            }
            else {
                testStatus.innerHTML = `✗ ${result.error}`;
                testStatus.className = 'ai-agent-settings-test-status error';
            }
        }
        catch (e) {
            testStatus.innerHTML = `✗ ${e}`;
            testStatus.className = 'ai-agent-settings-test-status error';
        }
    });
    // ─── Save Button ───
    (_o = container
        .querySelector('.ai-agent-settings-save')) === null || _o === void 0 ? void 0 : _o.addEventListener('click', async () => {
        // Update current profile from form
        updateCurrentProfileFromForm();
        const updates = {
            profiles: profiles,
            active_profile_id: activeProfileId,
            auto_execute_tools: autoExecCheckbox.checked,
            include_variables: includeVarsCheckbox.checked,
            include_cell_outline: includeCellsCheckbox.checked,
            max_agent_iterations: parseInt(maxIterInput.value, 10),
            custom_system_prompt: promptTextarea.value,
            enabled_tool_categories: {
                notebook: document.getElementById('settings-tool-notebook').checked,
                files: document.getElementById('settings-tool-files').checked,
                shell: document.getElementById('settings-tool-shell').checked,
                packages: document.getElementById('settings-tool-packages').checked,
                search: document.getElementById('settings-tool-search').checked
            },
            image_analysis: {
                enabled: document.getElementById('settings-img-enabled').checked,
                auto_suggest: document.getElementById('settings-img-auto-suggest').checked,
                use_active_profile: document.getElementById('settings-img-use-active').checked,
                profile_id: imgUseActiveCheckbox.checked
                    ? null
                    : imgProfileSelect.value,
                custom_prompt: document.getElementById('settings-img-custom-prompt').value
            }
        };
        try {
            await (0,_settings_api__WEBPACK_IMPORTED_MODULE_0__.updateSettings)(updates);
            if (onSettingsChanged) {
                onSettingsChanged();
            }
            else {
                close();
            }
        }
        catch (e) {
            testStatus.innerHTML = `Save error: ${e}`;
            testStatus.className = 'ai-agent-settings-test-status error';
        }
    });
}
function createSection(title) {
    const section = document.createElement('div');
    section.className = 'ai-agent-settings-section';
    const label = document.createElement('label');
    label.className = 'ai-agent-settings-label';
    label.textContent = title;
    section.appendChild(label);
    return section;
}


/***/ },

/***/ "./lib/token-counter.js"
/*!******************************!*\
  !*** ./lib/token-counter.js ***!
  \******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   estimateMessageTokens: () => (/* binding */ estimateMessageTokens),
/* harmony export */   estimateMessagesTokens: () => (/* binding */ estimateMessagesTokens),
/* harmony export */   estimateTokens: () => (/* binding */ estimateTokens),
/* harmony export */   formatTokenCount: () => (/* binding */ formatTokenCount)
/* harmony export */ });
/**
 * Модуль для приблизительного подсчёта токенов.
 *
 * Правила большого пальца:
 * - Английский текст: ~4 символа = 1 токен
 * - Код: ~3.5 символа = 1 токен (больше спецсимволов)
 * - Русский/CJK: ~2 символа = 1 токен
 * - JSON: ~3 символа = 1 токен
 */
/**
 * Приблизительный подсчёт токенов для одного текста.
 * Использует взвешенный подсчёт на основе типа символов.
 */
function estimateTokens(text) {
    if (!text) {
        return 0;
    }
    // Считаем типы символов
    const nonAsciiCount = (text.match(/[^[:ascii:]]/g) || []).length;
    const codeChars = (text.match(/[{}()[\];:=<>+\-*/&|!@#$%^~`\\]/g) || [])
        .length;
    const asciiCount = text.length - nonAsciiCount;
    // Взвешенный подсчёт
    const asciiTokens = (asciiCount - codeChars) / 4;
    const codeTokens = codeChars / 3;
    const nonAsciiTokens = nonAsciiCount / 2;
    return Math.ceil(asciiTokens + codeTokens + nonAsciiTokens);
}
/**
 * Подсчитать токены для одного сообщения
 */
function estimateMessageTokens(msg) {
    let tokens = 4; // служебные токены (role, separators)
    if (msg.content) {
        tokens += estimateTokens(msg.content);
    }
    if (msg.tool_calls) {
        for (const tc of msg.tool_calls) {
            tokens += estimateTokens(tc.function.name);
            tokens += estimateTokens(tc.function.arguments);
            tokens += 10; // служебные
            if (tc.id) {
                tokens += 5;
            }
        }
    }
    if (msg.tool_call_id) {
        tokens += 5;
    }
    return tokens;
}
/**
 * Подсчитать токены для массива сообщений
 */
function estimateMessagesTokens(messages) {
    return messages.reduce((sum, msg) => sum + estimateMessageTokens(msg), 0);
}
/**
 * Форматировать количество токенов в читаемый вид
 */
function formatTokenCount(count) {
    if (count < 1000) {
        return `${count}`;
    }
    if (count < 10000) {
        return `${(count / 1000).toFixed(1)}K`;
    }
    if (count < 1000000) {
        return `${Math.round(count / 1000)}K`;
    }
    return `${(count / 1000000).toFixed(1)}M`;
}


/***/ },

/***/ "./lib/tool-registry.js"
/*!******************************!*\
  !*** ./lib/tool-registry.js ***!
  \******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ToolRegistry: () => (/* binding */ ToolRegistry),
/* harmony export */   toolRegistry: () => (/* binding */ toolRegistry)
/* harmony export */ });
/* harmony import */ var _tools__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tools */ "./lib/tools.js");
/* harmony import */ var _permission_manager__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./permission-manager */ "./lib/permission-manager.js");
/* harmony import */ var _tool_validator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./tool-validator */ "./lib/tool-validator.js");



/**
 * Реестр инструментов AI Agent
 */
class ToolRegistry {
    constructor() {
        this.tools = new Map();
        this.permissions = new _permission_manager__WEBPACK_IMPORTED_MODULE_1__.PermissionManager();
    }
    /**
     * Зарегистрировать инструмент
     */
    register(tool) {
        if (this.tools.has(tool.name)) {
            throw new Error(`Tool "${tool.name}" is already registered`);
        }
        this.tools.set(tool.name, tool);
    }
    /**
     * Получить инструмент по названию
     */
    get(name) {
        return this.tools.get(name);
    }
    /**
     * Получить все зарегистрированные инструменты
     */
    getAll() {
        return Array.from(this.tools.values());
    }
    /**
     * Получить определения функций для OpenRouter API — только для разрешённых инструментов
     */
    getFunctionDefinitions() {
        return this.permissions
            .filterTools(this.getAll())
            .map(tool => (0,_tools__WEBPACK_IMPORTED_MODULE_0__.toolParametersToFunctionDefinition)(tool));
    }
    /**
     * Выполнить инструмент по названию с проверкой разрешений и валидацией аргументов
     */
    async execute(name, args) {
        const tool = this.get(name);
        if (!tool) {
            return {
                success: false,
                error: `Unknown tool: ${name}`
            };
        }
        // Проверяем разрешение
        if (!this.permissions.isAllowed(tool)) {
            return {
                success: false,
                error: `Tool "${name}" is disabled. Enable category "${tool.category}" in settings.`
            };
        }
        // ★ Валидация аргументов
        const validation = _tool_validator__WEBPACK_IMPORTED_MODULE_2__.ToolValidator.validate(tool, args);
        if (!validation.valid) {
            return {
                success: false,
                error: `Invalid arguments: ${validation.errors.join('; ')}`
            };
        }
        try {
            return await tool.execute(validation.sanitizedArgs);
        }
        catch (error) {
            return {
                success: false,
                error: error instanceof Error ? error.message : 'Unknown error'
            };
        }
    }
    /**
     * Включить категорию инструментов
     */
    enableCategory(category) {
        this.permissions.setCategoryEnabled(category, true);
    }
    /**
     * Выключить категорию инструментов
     */
    disableCategory(category) {
        this.permissions.setCategoryEnabled(category, false);
    }
}
/**
 * Глобальный экземпляр реестра
 */
const toolRegistry = new ToolRegistry();


/***/ },

/***/ "./lib/tool-validator.js"
/*!*******************************!*\
  !*** ./lib/tool-validator.js ***!
  \*******************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ToolValidator: () => (/* binding */ ToolValidator)
/* harmony export */ });
/**
 * Опасные shell-паттерны для проверки
 */
const DANGEROUS_SHELL_PATTERNS = [
    'rm -rf /',
    'rm -rf ~',
    'mkfs',
    'dd if=',
    ':()',
    'shutdown',
    'reboot',
    'halt',
    'poweroff'
];
/**
 * Валидатор аргументов инструментов
 */
class ToolValidator {
    /**
     * Валидировать и санитизировать аргументы инструмента
     */
    static validate(tool, args) {
        const errors = [];
        const sanitized = { ...args };
        const params = tool.parameters;
        // Проверяем обязательные параметры
        if (params.required) {
            for (const required of params.required) {
                if (!(required in args) ||
                    args[required] === undefined ||
                    args[required] === null) {
                    errors.push(`Missing required parameter: ${required}`);
                }
            }
        }
        // Валидируем типы и значения каждого параметра
        for (const [key, value] of Object.entries(args)) {
            const schema = params.properties[key];
            if (!schema) {
                // Неизвестный параметр — удаляем
                delete sanitized[key];
                continue;
            }
            // Проверяем и приводим типы
            if (schema.type === 'string' && typeof value !== 'string') {
                sanitized[key] = String(value);
            }
            if (schema.type === 'integer') {
                if (typeof value !== 'number') {
                    const num = parseInt(String(value), 10);
                    if (isNaN(num)) {
                        errors.push(`Parameter "${key}" must be an integer`);
                    }
                    else {
                        sanitized[key] = num;
                    }
                }
                else {
                    sanitized[key] = Math.floor(value);
                }
            }
            if (schema.type === 'number' && typeof value !== 'number') {
                const num = parseFloat(String(value));
                if (isNaN(num)) {
                    errors.push(`Parameter "${key}" must be a number`);
                }
                else {
                    sanitized[key] = num;
                }
            }
            if (schema.type === 'boolean' && typeof value !== 'boolean') {
                sanitized[key] = value === 'true' || value === true;
            }
            // Проверяем enum
            if (schema.enum && !schema.enum.includes(value)) {
                errors.push(`Parameter "${key}" must be one of: ${schema.enum.join(', ')}`);
            }
            // Специальные проверки по имени параметра
            if (key === 'path' && typeof value === 'string') {
                // Проверяем path traversal
                if (value.includes('..') || value.startsWith('/')) {
                    errors.push(`Path "${value}" is not allowed (no .. or absolute paths)`);
                }
            }
            if (key === 'index' && typeof value === 'number') {
                if (value < 0) {
                    errors.push('Index must be non-negative');
                }
                if (!Number.isInteger(value)) {
                    errors.push('Index must be an integer');
                }
            }
            if (key === 'source' && typeof value === 'string') {
                // Ограничиваем размер source
                if (value.length > 100000) {
                    errors.push(`Source too large: ${value.length} chars (max 100000)`);
                }
            }
            if (key === 'command' && typeof value === 'string') {
                // Проверяем опасные shell-паттерны
                const commandLower = value.toLowerCase();
                for (const pattern of DANGEROUS_SHELL_PATTERNS) {
                    if (commandLower.includes(pattern)) {
                        errors.push(`Command contains blocked pattern: "${pattern}"`);
                    }
                }
            }
            if (key === 'timeout' && typeof value === 'number') {
                if (value < 0 || value > 600) {
                    errors.push('Timeout must be between 0 and 600 seconds');
                }
            }
        }
        return {
            valid: errors.length === 0,
            errors,
            sanitizedArgs: sanitized
        };
    }
}


/***/ },

/***/ "./lib/tools.js"
/*!**********************!*\
  !*** ./lib/tools.js ***!
  \**********************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ToolSafetyLevel: () => (/* binding */ ToolSafetyLevel),
/* harmony export */   toolParametersToFunctionDefinition: () => (/* binding */ toolParametersToFunctionDefinition)
/* harmony export */ });
/**
 * Уровни безопасности инструментов
 */
var ToolSafetyLevel;
(function (ToolSafetyLevel) {
    /** Только чтение — полностью безопасен */
    ToolSafetyLevel["READ"] = "read";
    /** Запись — модифицирует данные, но не выполняет код */
    ToolSafetyLevel["WRITE"] = "write";
    /** Выполнение — выполняет код или команды */
    ToolSafetyLevel["EXECUTE"] = "execute";
    /** Системный — доступ к ОС, файловой системе, деструктивные операции */
    ToolSafetyLevel["SYSTEM"] = "system";
})(ToolSafetyLevel || (ToolSafetyLevel = {}));
/**
 * Преобразовать ToolParameters в формат для OpenRouter API
 */
function toolParametersToFunctionDefinition(tool) {
    return {
        type: 'function',
        function: {
            name: tool.name,
            description: tool.description,
            parameters: tool.parameters
        }
    };
}


/***/ },

/***/ "./lib/tools/file-tools.js"
/*!*********************************!*\
  !*** ./lib/tools/file-tools.js ***!
  \*********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createFileTools: () => (/* binding */ createFileTools)
/* harmony export */ });
/* harmony import */ var _tools__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../tools */ "./lib/tools.js");

/** Maximum file size for reading (500KB) */
const MAX_FILE_SIZE = 500 * 1024;
/** File extensions considered text files */
const TEXT_EXTENSIONS = new Set([
    '.py',
    '.js',
    '.ts',
    '.tsx',
    '.jsx',
    '.json',
    '.yaml',
    '.yml',
    '.toml',
    '.cfg',
    '.ini',
    '.conf',
    '.txt',
    '.md',
    '.rst',
    '.csv',
    '.tsv',
    '.xml',
    '.html',
    '.css',
    '.scss',
    '.sql',
    '.sh',
    '.bash',
    '.zsh',
    '.r',
    '.R',
    '.jl',
    '.lua',
    '.c',
    '.cpp',
    '.h',
    '.hpp',
    '.java',
    '.go',
    '.rs',
    '.dockerfile',
    '.gitignore',
    '.env',
    '.ipynb',
    'Makefile',
    'Dockerfile',
    'README',
    'LICENSE'
]);
function createFileTools(jupyterService) {
    return [
        // ═══════════════════════════════════════════
        // read_file
        // ═══════════════════════════════════════════
        {
            name: 'read_file',
            safetyLevel: _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.READ,
            category: 'files',
            description: `Read the contents of a text file. Supports common text formats: .py, .js, .json, .csv, .md, .txt, .yaml, etc. Maximum file size: ${MAX_FILE_SIZE / 1024}KB. For binary files (images, PDFs), use other approaches.`,
            parameters: {
                type: 'object',
                properties: {
                    path: {
                        type: 'string',
                        description: 'Path to the file relative to Jupyter working directory. Examples: "data/input.csv", "utils/helper.py", "config.yaml"'
                    },
                    max_lines: {
                        type: 'integer',
                        description: 'Maximum number of lines to return (default: all). Use this for large files to get just the beginning.'
                    }
                },
                required: ['path']
            },
            async execute(args) {
                var _a;
                const path = args.path;
                const maxLines = args.max_lines;
                const ext = '.' + ((_a = path.split('.').pop()) === null || _a === void 0 ? void 0 : _a.toLowerCase());
                const baseName = path.split('/').pop() || '';
                const isText = TEXT_EXTENSIONS.has(ext) ||
                    TEXT_EXTENSIONS.has(baseName) ||
                    !ext.includes('.');
                if (!isText) {
                    return {
                        success: false,
                        error: `File "${path}" appears to be binary (extension: ${ext}). Only text files can be read.`
                    };
                }
                const result = await jupyterService.readFile(path);
                if (!result.success) {
                    return { success: false, error: result.error };
                }
                let content = result.content || '';
                if (content.length > MAX_FILE_SIZE) {
                    content = content.substring(0, MAX_FILE_SIZE);
                    return {
                        success: true,
                        result: {
                            content,
                            truncated: true,
                            message: `File truncated to ${MAX_FILE_SIZE / 1024}KB. Use max_lines parameter for controlled reading.`,
                            total_size: result.size
                        }
                    };
                }
                if (maxLines !== undefined && maxLines > 0) {
                    const lines = content.split('\n');
                    if (lines.length > maxLines) {
                        content = lines.slice(0, maxLines).join('\n');
                        return {
                            success: true,
                            result: {
                                content,
                                truncated: true,
                                shown_lines: maxLines,
                                total_lines: lines.length
                            }
                        };
                    }
                }
                return {
                    success: true,
                    result: {
                        content,
                        lines: content.split('\n').length,
                        size: content.length
                    }
                };
            }
        },
        // ═══════════════════════════════════════════
        // write_file
        // ═══════════════════════════════════════════
        {
            name: 'write_file',
            safetyLevel: _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.WRITE,
            category: 'files',
            description: 'Create a new file or overwrite an existing file with the given content. Parent directories will be created automatically if they do not exist.',
            parameters: {
                type: 'object',
                properties: {
                    path: {
                        type: 'string',
                        description: 'Path for the file relative to Jupyter working directory'
                    },
                    content: {
                        type: 'string',
                        description: 'Content to write to the file'
                    }
                },
                required: ['path', 'content']
            },
            async execute(args) {
                const path = args.path;
                const content = args.content;
                if (path.endsWith('.ipynb')) {
                    return {
                        success: false,
                        error: 'Cannot write .ipynb files directly. Use create_notebook tool or work with cells via create_cell/update_cell.'
                    };
                }
                const result = await jupyterService.writeFile(path, content);
                if (!result.success) {
                    return { success: false, error: result.error };
                }
                return {
                    success: true,
                    result: {
                        path,
                        created: result.created,
                        message: result.created
                            ? `File created: ${path}`
                            : `File updated: ${path}`,
                        size: content.length
                    }
                };
            }
        },
        // ═══════════════════════════════════════════
        // list_directory
        // ═══════════════════════════════════════════
        {
            name: 'list_directory',
            safetyLevel: _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.READ,
            category: 'files',
            description: 'List files and subdirectories in a given directory. Returns names, types (file/directory/notebook), and sizes.',
            parameters: {
                type: 'object',
                properties: {
                    path: {
                        type: 'string',
                        description: 'Path to directory relative to Jupyter working directory. Empty string or "." for root directory.',
                        default: ''
                    }
                }
            },
            async execute(args) {
                const path = args.path || '';
                const result = await jupyterService.listDirectory(path);
                if (!result.success) {
                    return { success: false, error: result.error };
                }
                const items = result.items || [];
                const summary = items.map(item => {
                    const icon = item.type === 'directory'
                        ? '📁'
                        : item.type === 'notebook'
                            ? '📓'
                            : '📄';
                    const size = item.size ? ` (${formatFileSize(item.size)})` : '';
                    return `${icon} ${item.name}${size}`;
                });
                return {
                    success: true,
                    result: {
                        path: path || '.',
                        count: items.length,
                        items: items,
                        summary: summary.join('\n')
                    }
                };
            }
        },
        // ═══════════════════════════════════════════
        // create_notebook
        // ═══════════════════════════════════════════
        {
            name: 'create_notebook',
            safetyLevel: _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.WRITE,
            category: 'files',
            description: 'Create a new empty Jupyter notebook (.ipynb file)',
            parameters: {
                type: 'object',
                properties: {
                    name: {
                        type: 'string',
                        description: 'Name for the notebook (with or without .ipynb extension)'
                    },
                    path: {
                        type: 'string',
                        description: 'Directory where to create the notebook (default: root)',
                        default: ''
                    }
                },
                required: ['name']
            },
            async execute(args) {
                const name = args.name;
                const path = args.path || '';
                const result = await jupyterService.createNotebook(name, path);
                if (!result.success) {
                    return { success: false, error: result.error };
                }
                return {
                    success: true,
                    result: {
                        path: result.path,
                        message: `Notebook created: ${result.path}`
                    }
                };
            }
        },
        // ═══════════════════════════════════════════
        // delete_file
        // ═══════════════════════════════════════════
        {
            name: 'delete_file',
            safetyLevel: _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.SYSTEM,
            category: 'files',
            alwaysConfirm: true,
            description: 'Delete a file or empty directory. Use with caution — this cannot be undone.',
            parameters: {
                type: 'object',
                properties: {
                    path: {
                        type: 'string',
                        description: 'Path to the file or directory to delete'
                    }
                },
                required: ['path']
            },
            async execute(args) {
                const path = args.path;
                const result = await jupyterService.deleteFile(path);
                if (!result.success) {
                    return { success: false, error: result.error };
                }
                return {
                    success: true,
                    result: { message: `Deleted: ${path}` }
                };
            }
        },
        // ═══════════════════════════════════════════
        // rename_file
        // ═══════════════════════════════════════════
        {
            name: 'rename_file',
            safetyLevel: _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.WRITE,
            category: 'files',
            description: 'Rename or move a file/directory',
            parameters: {
                type: 'object',
                properties: {
                    old_path: {
                        type: 'string',
                        description: 'Current path of the file'
                    },
                    new_path: {
                        type: 'string',
                        description: 'New path for the file'
                    }
                },
                required: ['old_path', 'new_path']
            },
            async execute(args) {
                const oldPath = args.old_path;
                const newPath = args.new_path;
                const result = await jupyterService.renameFile(oldPath, newPath);
                if (!result.success) {
                    return { success: false, error: result.error };
                }
                return {
                    success: true,
                    result: { message: `Renamed: ${oldPath} → ${newPath}` }
                };
            }
        }
    ];
}
/** Format file size for display */
function formatFileSize(bytes) {
    if (bytes < 1024) {
        return `${bytes} B`;
    }
    if (bytes < 1024 * 1024) {
        return `${(bytes / 1024).toFixed(1)} KB`;
    }
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}


/***/ },

/***/ "./lib/tools/notebook-tools.js"
/*!*************************************!*\
  !*** ./lib/tools/notebook-tools.js ***!
  \*************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createNotebookTools: () => (/* binding */ createNotebookTools)
/* harmony export */ });
/* harmony import */ var _tools__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../tools */ "./lib/tools.js");
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../api */ "./lib/api.js");


/** Create notebook manipulation tools */
function createNotebookTools(jupyterService, options) {
    var _a;
    const tools = [
        {
            name: 'create_cell',
            safetyLevel: _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.WRITE,
            category: 'notebook',
            description: 'Create a new cell in the active notebook',
            parameters: {
                type: 'object',
                properties: {
                    cell_type: {
                        type: 'string',
                        description: 'Type of cell: "code" or "markdown"',
                        enum: ['code', 'markdown']
                    },
                    source: {
                        type: 'string',
                        description: 'Content of the cell'
                    },
                    index: {
                        type: 'integer',
                        description: 'Position to insert the cell (0-based, default: end of notebook)'
                    }
                },
                required: ['cell_type', 'source']
            },
            async execute(args) {
                const cellType = args.cell_type;
                const source = args.source;
                const result = await jupyterService.createCell(cellType, source);
                if (result.success) {
                    return {
                        success: true,
                        result: {
                            index: result.index,
                            message: `Cell created at index ${result.index}`
                        }
                    };
                }
                else {
                    return {
                        success: false,
                        error: result.error
                    };
                }
            }
        },
        {
            name: 'update_cell',
            safetyLevel: _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.WRITE,
            category: 'notebook',
            description: 'Update the content of an existing cell',
            parameters: {
                type: 'object',
                properties: {
                    index: {
                        type: 'integer',
                        description: 'Index of the cell to update (0-based)'
                    },
                    source: {
                        type: 'string',
                        description: 'New content for the cell'
                    }
                },
                required: ['index', 'source']
            },
            async execute(args) {
                const index = args.index;
                const source = args.source;
                const result = jupyterService.updateCell(index, source);
                if (result.success) {
                    return {
                        success: true,
                        result: { message: `Cell at index ${index} updated` }
                    };
                }
                else {
                    return {
                        success: false,
                        error: result.error
                    };
                }
            }
        },
        {
            name: 'delete_cell',
            safetyLevel: _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.WRITE,
            category: 'notebook',
            alwaysConfirm: true,
            description: 'Delete a cell from the notebook',
            parameters: {
                type: 'object',
                properties: {
                    index: {
                        type: 'integer',
                        description: 'Index of the cell to delete (0-based)'
                    }
                },
                required: ['index']
            },
            async execute(args) {
                const index = args.index;
                const result = jupyterService.deleteCell(index);
                if (result.success) {
                    return {
                        success: true,
                        result: { message: `Cell at index ${index} deleted` }
                    };
                }
                else {
                    return {
                        success: false,
                        error: result.error
                    };
                }
            }
        },
        {
            name: 'get_cell_content',
            safetyLevel: _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.READ,
            category: 'notebook',
            description: 'Get the content of a specific cell',
            parameters: {
                type: 'object',
                properties: {
                    index: {
                        type: 'integer',
                        description: 'Index of the cell (0-based)'
                    }
                },
                required: ['index']
            },
            async execute(args) {
                const index = args.index;
                const result = jupyterService.getCellContent(index);
                if (result.success) {
                    return {
                        success: true,
                        result: {
                            cell_type: result.cellType,
                            source: result.source
                        }
                    };
                }
                else {
                    return {
                        success: false,
                        error: result.error
                    };
                }
            }
        },
        {
            name: 'get_notebook_content',
            safetyLevel: _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.READ,
            category: 'notebook',
            description: 'Get the content of all cells in the active notebook. For code cells, includes execution metadata: execution_count (null if not executed), outputs_count, has_error, and outputs_summary.',
            parameters: {
                type: 'object',
                properties: {}
            },
            async execute() {
                const result = jupyterService.getNotebookContent();
                if (result.success) {
                    return {
                        success: true,
                        result: { cells: result.cells }
                    };
                }
                else {
                    return {
                        success: false,
                        error: result.error
                    };
                }
            }
        },
        {
            name: 'execute_cell',
            safetyLevel: _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.EXECUTE,
            category: 'notebook',
            description: 'Execute a code cell or render a markdown cell. For code cells: runs the code and waits for completion. For markdown cells: renders the markdown as formatted text.',
            parameters: {
                type: 'object',
                properties: {
                    index: {
                        type: 'integer',
                        description: 'Index of the cell to execute/render (0-based)'
                    }
                },
                required: ['index']
            },
            async execute(args) {
                const index = args.index;
                const result = await jupyterService.executeCell(index);
                if (result.success) {
                    return {
                        success: true,
                        result: { message: `Cell at index ${index} executed` }
                    };
                }
                else {
                    return {
                        success: false,
                        error: result.error
                    };
                }
            }
        },
        {
            name: 'get_cell_output',
            safetyLevel: _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.READ,
            category: 'notebook',
            description: 'Get the output of an executed code cell. Returns text output, errors, images (as base64), and HTML (like DataFrames). Images are included by default for matplotlib plots.',
            parameters: {
                type: 'object',
                properties: {
                    index: {
                        type: 'integer',
                        description: 'Index of the cell (0-based)'
                    },
                    include_images: {
                        type: 'boolean',
                        description: 'Include base64 image data (default: true). Set to false to save tokens.'
                    }
                },
                required: ['index']
            },
            async execute(args) {
                const index = args.index;
                // Always include images by default for matplotlib plots
                const includeImages = args.include_images;
                const shouldIncludeImages = includeImages !== false;
                const result = jupyterService.getCellOutput(index);
                if (!result.success) {
                    return { success: false, error: result.error };
                }
                const outputs = result.outputs || [];
                if (outputs.length === 0) {
                    return {
                        success: true,
                        result: {
                            outputs: [],
                            message: 'Cell has no output (may still be executing)'
                        }
                    };
                }
                // Format outputs
                const formattedOutputs = outputs.map(output => {
                    switch (output.type) {
                        case 'text':
                            return {
                                type: 'text',
                                content: output.text
                            };
                        case 'error':
                            return {
                                type: 'error',
                                content: output.text
                            };
                        case 'image': {
                            const imageInfo = {
                                type: 'image',
                                mime_type: output.mimeType,
                                description: `Image output (${output.mimeType})`
                            };
                            // Add base64 by default (unless explicitly disabled)
                            if (shouldIncludeImages && output.data) {
                                imageInfo.base64 = output.data;
                            }
                            else {
                                imageInfo.note =
                                    'Image data available. Call with include_images=true to get base64 data.';
                            }
                            // Add text/plain description (matplotlib adds "Figure(...)")
                            if (output.text) {
                                imageInfo.alt_text = output.text;
                            }
                            return imageInfo;
                        }
                        case 'html':
                            return {
                                type: 'html',
                                // For DataFrame - extract text version
                                content: output.text || '(HTML output)',
                                note: 'Rich HTML output (e.g. DataFrame). The text representation is provided.'
                            };
                        case 'json':
                            return {
                                type: 'json',
                                content: output.text
                            };
                        default:
                            return {
                                type: 'unknown',
                                content: output.text || '(unknown output type)'
                            };
                    }
                });
                return {
                    success: true,
                    result: {
                        outputs: formattedOutputs,
                        output_count: formattedOutputs.length,
                        has_images: outputs.some(o => o.type === 'image'),
                        has_errors: outputs.some(o => o.type === 'error')
                    }
                };
            }
        }
    ];
    // Add analyze_image only if enabled in settings
    const imageAnalysisEnabled = ((_a = options === null || options === void 0 ? void 0 : options.imageAnalysis) === null || _a === void 0 ? void 0 : _a.enabled) !== false;
    if (imageAnalysisEnabled) {
        tools.push({
            name: 'analyze_image',
            safetyLevel: _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.READ,
            category: 'notebook',
            description: 'Analyze an image from a cell output using AI vision. Use when user asks to analyze, explain, or describe an image.',
            parameters: {
                type: 'object',
                properties: {
                    cell_index: {
                        type: 'integer',
                        description: 'Index of the cell containing the image to analyze (0-based)'
                    },
                    context: {
                        type: 'string',
                        description: 'Optional context or specific question about the image'
                    }
                },
                required: ['cell_index']
            },
            async execute(args) {
                const cellIndex = args.cell_index;
                const context = args.context;
                const result = jupyterService.getCellOutput(cellIndex);
                if (!result.success) {
                    return { success: false, error: result.error };
                }
                const outputs = result.outputs || [];
                const imageOutput = outputs.find((o) => o.type === 'image');
                if (!imageOutput || !imageOutput.data) {
                    return {
                        success: false,
                        error: 'No image found in cell output'
                    };
                }
                try {
                    const analysisResult = await (0,_api__WEBPACK_IMPORTED_MODULE_1__.analyzeImage)(imageOutput.data, imageOutput.mimeType || 'image/png', cellIndex, context);
                    if (!analysisResult.success) {
                        return {
                            success: false,
                            error: analysisResult.error || 'Image analysis failed'
                        };
                    }
                    return {
                        success: true,
                        result: {
                            analysis: analysisResult.analysis,
                            model_used: analysisResult.model_used,
                            cell_index: cellIndex,
                            mime_type: imageOutput.mimeType
                        }
                    };
                }
                catch (error) {
                    return {
                        success: false,
                        error: `Analysis error: ${error.message}`
                    };
                }
            }
        });
    }
    return tools;
}


/***/ },

/***/ "./lib/tools/package-tools.js"
/*!************************************!*\
  !*** ./lib/tools/package-tools.js ***!
  \************************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createPackageTools: () => (/* binding */ createPackageTools)
/* harmony export */ });
/* harmony import */ var _tools__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../tools */ "./lib/tools.js");
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../api */ "./lib/api.js");


/**
 * Валидация имени пакета
 * Допустимые символы: буквы, цифры, -, _, ., [, ], =, <, >, !, ~, ,
 */
function isValidPackageName(name) {
    return /^[a-zA-Z0-9._[\]>=<!~,\s]+$/.test(name) && name.length < 200;
}
/**
 * Извлечь базовое имя пакета (без версий)
 */
function getBasePackageName(packageName) {
    return packageName.split(/[>=<!~]/)[0].trim();
}
/**
 * Парсинг типичных ошибок установки
 */
function parseInstallError(output) {
    const lower = output.toLowerCase();
    if (lower.includes('no matching distribution')) {
        return {
            message: 'Package not found in PyPI',
            suggestion: 'Check the package name spelling. Try searching on pypi.org.'
        };
    }
    if (lower.includes('permission denied') || lower.includes('errno 13')) {
        return {
            message: 'Permission denied during installation',
            suggestion: 'Try adding --user flag via extra_args parameter.'
        };
    }
    if (lower.includes('conflict')) {
        return {
            message: 'Package version conflict detected',
            suggestion: 'Try specifying a compatible version or use --force-reinstall.'
        };
    }
    if (lower.includes('no space left')) {
        return {
            message: 'Disk full — no space left',
            suggestion: 'Free up disk space and try again.'
        };
    }
    if (lower.includes('could not build wheels') ||
        lower.includes('compilation')) {
        return {
            message: 'Failed to build package from source',
            suggestion: 'The package may require system-level build tools. Try conda instead of pip.'
        };
    }
    if (lower.includes('network') || lower.includes('connection')) {
        return {
            message: 'Network error during installation',
            suggestion: 'Check your internet connection and try again.'
        };
    }
    return {
        message: output
            .split('\n')
            .filter(l => l.trim())
            .slice(-3)
            .join('; '),
        suggestion: undefined
    };
}
function createPackageTools() {
    return [
        // ─────────────────────────────────────────
        // install_package
        // ─────────────────────────────────────────
        {
            name: 'install_package',
            safetyLevel: _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.SYSTEM,
            category: 'packages',
            description: 'Install a Python package using pip or conda. After installation, the package is available for import in notebook cells. Use this when code fails with ModuleNotFoundError or ImportError.',
            parameters: {
                type: 'object',
                properties: {
                    package_name: {
                        type: 'string',
                        description: 'Package name to install. Can include version: "pandas", "numpy>=1.24", "scikit-learn==1.3.0"'
                    },
                    manager: {
                        type: 'string',
                        enum: ['pip', 'conda'],
                        description: 'Package manager to use (default: pip)',
                        default: 'pip'
                    },
                    extra_args: {
                        type: 'string',
                        description: 'Extra arguments, e.g. "--upgrade", "--no-deps", "-c conda-forge"'
                    }
                },
                required: ['package_name']
            },
            async execute(args) {
                const packageName = args.package_name;
                const manager = args.manager || 'pip';
                const extraArgs = args.extra_args || '';
                // Валидация имени пакета (защита от инъекций)
                if (!isValidPackageName(packageName)) {
                    return {
                        success: false,
                        error: `Invalid package name: "${packageName}". Package name should contain only letters, numbers, hyphens, underscores, dots, and version specifiers.`
                    };
                }
                // Формируем команду
                let command;
                if (manager === 'conda') {
                    command = `conda install -y ${extraArgs} ${packageName}`;
                }
                else {
                    // pip
                    command = `pip install ${extraArgs} ${packageName}`;
                }
                try {
                    // Выполняем установку (с увеличенным таймаутом)
                    const result = await (0,_api__WEBPACK_IMPORTED_MODULE_1__.executeShell)(command, 120);
                    if (result.success) {
                        // Проверяем, что пакет действительно установился
                        const baseName = getBasePackageName(packageName);
                        const importName = baseName.replace(/-/g, '_');
                        const checkResult = await (0,_api__WEBPACK_IMPORTED_MODULE_1__.executeShell)(`python -c "import ${importName}; print('OK')"`, 10);
                        const importable = checkResult.success && checkResult.stdout.includes('OK');
                        return {
                            success: true,
                            result: {
                                package: packageName,
                                manager,
                                message: `Package "${packageName}" installed successfully`,
                                importable,
                                import_name: importName,
                                output: result.stdout.split('\n').slice(-3).join('\n')
                            }
                        };
                    }
                    else {
                        // Парсим типичные ошибки pip/conda
                        const errorInfo = parseInstallError(result.stderr || result.stdout);
                        return {
                            success: false,
                            error: errorInfo.message,
                            result: {
                                suggestion: errorInfo.suggestion,
                                full_output: (result.stderr || result.stdout).substring(0, 500)
                            }
                        };
                    }
                }
                catch (error) {
                    return {
                        success: false,
                        error: error instanceof Error ? error.message : String(error)
                    };
                }
            }
        },
        // ─────────────────────────────────────────
        // list_packages
        // ─────────────────────────────────────────
        {
            name: 'list_packages',
            safetyLevel: _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.READ,
            category: 'packages',
            description: 'List installed Python packages. Use to check what is already available.',
            parameters: {
                type: 'object',
                properties: {
                    filter: {
                        type: 'string',
                        description: 'Filter packages by name substring (optional)'
                    }
                }
            },
            async execute(args) {
                const filter = args.filter || '';
                try {
                    const result = await (0,_api__WEBPACK_IMPORTED_MODULE_1__.executeShell)('pip list --format=json', 30);
                    if (!result.success) {
                        return {
                            success: false,
                            error: `Failed to list packages: ${result.stderr}`
                        };
                    }
                    let packages;
                    try {
                        packages = JSON.parse(result.stdout);
                    }
                    catch (_a) {
                        return {
                            success: false,
                            error: 'Failed to parse pip output'
                        };
                    }
                    // Фильтруем
                    if (filter) {
                        const lowerFilter = filter.toLowerCase();
                        packages = packages.filter(p => p.name.toLowerCase().includes(lowerFilter));
                    }
                    return {
                        success: true,
                        result: {
                            count: packages.length,
                            packages: packages.slice(0, 100), // максимум 100
                            truncated: packages.length > 100
                        }
                    };
                }
                catch (error) {
                    return {
                        success: false,
                        error: error instanceof Error ? error.message : String(error)
                    };
                }
            }
        }
    ];
}


/***/ },

/***/ "./lib/tools/search-tools.js"
/*!***********************************!*\
  !*** ./lib/tools/search-tools.js ***!
  \***********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createSearchTools: () => (/* binding */ createSearchTools)
/* harmony export */ });
/* harmony import */ var _tools__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../tools */ "./lib/tools.js");

function createSearchTools(jupyterService) {
    return [
        // ═══════════════════════════════════════════
        // find_in_notebook
        // ═══════════════════════════════════════════
        {
            name: 'find_in_notebook',
            safetyLevel: _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.READ,
            category: 'search',
            description: 'Search for text or pattern across all cells in the active notebook. Returns cell indices, line numbers, and matching lines. Useful for finding where a variable, function, or pattern is used.',
            parameters: {
                type: 'object',
                properties: {
                    query: {
                        type: 'string',
                        description: 'Text to search for, or a regex pattern if regex=true'
                    },
                    case_sensitive: {
                        type: 'boolean',
                        description: 'Whether search is case-sensitive (default: false)'
                    },
                    regex: {
                        type: 'boolean',
                        description: 'Treat query as a regular expression (default: false)'
                    },
                    cell_type: {
                        type: 'string',
                        enum: ['code', 'markdown'],
                        description: 'Search only in cells of this type (default: all)'
                    }
                },
                required: ['query']
            },
            async execute(args) {
                const query = args.query;
                const caseSensitive = args.case_sensitive;
                const regex = args.regex;
                const cellType = args.cell_type;
                const result = jupyterService.findInNotebook(query, {
                    caseSensitive,
                    regex,
                    cellType
                });
                if (!result.success) {
                    return { success: false, error: result.error };
                }
                const matches = result.matches || [];
                if (matches.length === 0) {
                    return {
                        success: true,
                        result: {
                            found: false,
                            message: `No matches found for "${query}"`,
                            total_matches: 0
                        }
                    };
                }
                // Группируем по ячейкам для читабельности
                const byCell = {};
                for (const m of matches) {
                    if (!byCell[m.cellIndex]) {
                        byCell[m.cellIndex] = [];
                    }
                    byCell[m.cellIndex].push(m);
                }
                const summary = Object.entries(byCell)
                    .map(([idx, cellMatches]) => {
                    const cellType = cellMatches[0].cellType;
                    const lines = cellMatches
                        .map(m => `  Line ${m.lineNumber}: ${m.line.trim()}`)
                        .join('\n');
                    // cellIndex теперь 0-based (как и в jupyterService.findInNotebook)
                    return `Cell [${parseInt(idx)}] (${cellType}):\n${lines}`;
                })
                    .join('\n\n');
                return {
                    success: true,
                    result: {
                        found: true,
                        total_matches: matches.length,
                        cells_with_matches: Object.keys(byCell).length,
                        matches: matches.slice(0, 50), // максимум 50 совпадений
                        summary
                    }
                };
            }
        },
        // ═══════════════════════════════════════════
        // replace_in_cell
        // ═══════════════════════════════════════════
        {
            name: 'replace_in_cell',
            safetyLevel: _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.WRITE,
            category: 'search',
            description: 'Replace text in a specific cell without rewriting the entire cell. Supports literal text and regex replacements. Useful for renaming variables, fixing typos, or modifying specific parts of code.',
            parameters: {
                type: 'object',
                properties: {
                    index: {
                        type: 'integer',
                        description: 'Cell number (0-based, first cell is 0)'
                    },
                    search: {
                        type: 'string',
                        description: 'Text to find (literal or regex if regex=true)'
                    },
                    replace: {
                        type: 'string',
                        description: 'Replacement text. For regex, supports $1, $2 backreferences.'
                    },
                    case_sensitive: {
                        type: 'boolean',
                        description: 'Case-sensitive search (default: false)'
                    },
                    regex: {
                        type: 'boolean',
                        description: 'Use regex for search (default: false)'
                    },
                    replace_all: {
                        type: 'boolean',
                        description: 'Replace all occurrences or only first (default: true = all)'
                    }
                },
                required: ['index', 'search', 'replace']
            },
            async execute(args) {
                const index = args.index;
                const search = args.search;
                const replace = args.replace;
                const caseSensitive = args.case_sensitive;
                const regex = args.regex;
                const replaceAll = args.replace_all;
                const result = jupyterService.replaceInCell(index, search, replace, {
                    caseSensitive,
                    regex,
                    replaceAll
                });
                if (!result.success) {
                    return { success: false, error: result.error };
                }
                return {
                    success: true,
                    result: {
                        replacements: result.replacements,
                        message: `Replaced ${result.replacements} occurrence(s) of "${search}" with "${replace}" in cell [${index}]`
                    }
                };
            }
        }
    ];
}


/***/ },

/***/ "./lib/tools/shell-tools.js"
/*!**********************************!*\
  !*** ./lib/tools/shell-tools.js ***!
  \**********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createShellTools: () => (/* binding */ createShellTools)
/* harmony export */ });
/* harmony import */ var _tools__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../tools */ "./lib/tools.js");
/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../api */ "./lib/api.js");


function createShellTools() {
    return [
        {
            name: 'run_shell',
            safetyLevel: _tools__WEBPACK_IMPORTED_MODULE_0__.ToolSafetyLevel.SYSTEM,
            category: 'shell',
            alwaysConfirm: true,
            description: 'Execute a shell command on the server. Use for: checking versions (python --version), listing processes, git operations, running scripts, system info. Commands are executed with a 60s timeout. Dangerous commands (rm -rf /, shutdown, etc.) are blocked. For Python code, prefer creating and executing notebook cells instead.',
            parameters: {
                type: 'object',
                properties: {
                    command: {
                        type: 'string',
                        description: 'Shell command to execute. Examples: "python --version", "pip list", "git status", "ls -la", "cat requirements.txt"'
                    },
                    timeout: {
                        type: 'integer',
                        description: 'Maximum execution time in seconds (default: 60, max: 60)'
                    }
                },
                required: ['command']
            },
            async execute(args) {
                const command = args.command;
                const timeout = args.timeout;
                try {
                    const result = await (0,_api__WEBPACK_IMPORTED_MODULE_1__.executeShell)(command, timeout);
                    // Format output
                    let output = '';
                    if (result.stdout) {
                        output += result.stdout;
                        if (result.stdout_truncated) {
                            output += '\n... (output truncated)';
                        }
                    }
                    if (result.stderr) {
                        output += (output ? '\n' : '') + `STDERR: ${result.stderr}`;
                        if (result.stderr_truncated) {
                            output += '\n... (stderr truncated)';
                        }
                    }
                    if (!output) {
                        output = '(no output)';
                    }
                    return {
                        success: result.success,
                        result: {
                            return_code: result.return_code,
                            output: output,
                            elapsed: `${result.elapsed_seconds}s`
                        },
                        error: result.success
                            ? undefined
                            : `Command failed with exit code ${result.return_code}`
                    };
                }
                catch (error) {
                    return {
                        success: false,
                        error: error instanceof Error ? error.message : String(error)
                    };
                }
            }
        }
    ];
}


/***/ },

/***/ "./lib/variable-inspector.js"
/*!***********************************!*\
  !*** ./lib/variable-inspector.js ***!
  \***********************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   VariableInspector: () => (/* binding */ VariableInspector)
/* harmony export */ });
/**
 * Код Python для интроспекции переменных
 * Выполняется в ядре, возвращает JSON
 */
const INSPECT_CODE = `
import json as _json
import sys as _sys

def _ai_agent_inspect_vars():
    """Собрать информацию о переменных в текущем пространстве имён"""
    _result = []
    _skip = {
        '_ai_agent_inspect_vars', '_result', '_skip',
        '_json', '_sys', '_name', '_val', '_info',
        'In', 'Out', 'get_ipython', 'exit', 'quit',
        '_ih', '_oh', '_dh', '__', '___', '_i', '_ii', '_iii',
    }

    _globals = {k: v for k, v in globals().items()
                if not k.startswith('_') or k == '_'}

    for _name, _val in _globals.items():
        if _name in _skip:
            continue
        if _name.startswith('__'):
            continue

        _info = {
            'name': _name,
            'type': type(_val).__name__,
            'summary': ''
        }

        try:
            # DataFrame
            if hasattr(_val, 'shape') and hasattr(_val, 'columns'):
                _shape = _val.shape
                _cols = list(_val.columns)[:10]
                _info['summary'] = f'shape={_shape}, columns={_cols}'
                if len(_val.columns) > 10:
                    _info['summary'] += f'... ({len(_val.columns)} total)'
            # NumPy array
            elif hasattr(_val, 'shape') and hasattr(_val, 'dtype'):
                _info['summary'] = f'shape={_val.shape}, dtype={_val.dtype}'
            # List/tuple
            elif isinstance(_val, (list, tuple)):
                _info['summary'] = f'len={len(_val)}'
                if len(_val) > 0:
                    _info['summary'] += f', first={type(_val[0]).__name__}'
            # Dict
            elif isinstance(_val, dict):
                _keys = list(_val.keys())[:5]
                _info['summary'] = f'len={len(_val)}, keys={_keys}'
                if len(_val) > 5:
                    _info['summary'] += '...'
            # String
            elif isinstance(_val, str):
                _info['summary'] = f'len={len(_val)}'
                if len(_val) <= 50:
                    _info['summary'] += f', value="{_val}"'
            # Number
            elif isinstance(_val, (int, float, complex, bool)):
                _info['summary'] = f'value={_val}'
            # Model-like objects
            elif hasattr(_val, 'get_params'):
                try:
                    _params = _val.get_params()
                    _info['summary'] = str({k: v for k, v in list(_params.items())[:5]})
                except:
                    _info['summary'] = repr(_val)[:100]
            # Callable
            elif callable(_val):
                _info['type'] = 'function'
                if hasattr(_val, '__doc__') and _val.__doc__:
                    _first_line = _val.__doc__.strip().split('\\n')[0]
                    _info['summary'] = _first_line[:80]
            else:
                _info['summary'] = repr(_val)[:100]
        except Exception as _e:
            _info['summary'] = f'(error: {_e})'

        _result.append(_info)

    # Сортируем: DataFrames и массивы сверху
    _priority = {'DataFrame': 0, 'ndarray': 1, 'Series': 2}
    _result.sort(key=lambda x: (_priority.get(x['type'], 10), x['name']))

    print(_json.dumps(_result[:50]))  # максимум 50 переменных

_ai_agent_inspect_vars()
del _ai_agent_inspect_vars
`;
/**
 * Инспектор переменных — выполняет код в ядре и парсит результат
 */
class VariableInspector {
    constructor(notebookTracker) {
        this.cache = null;
        this.cacheTimestamp = 0;
        this.cacheTTL = 5000; // 5 секунд
        this.notebookTracker = notebookTracker;
    }
    /**
     * Получить список переменных.
     * Использует кэш, чтобы не выполнять код в ядре слишком часто.
     */
    async getVariables(forceRefresh = false) {
        var _a, _b;
        const now = Date.now();
        // Возвращаем из кэша, если свежий
        if (!forceRefresh &&
            this.cache &&
            now - this.cacheTimestamp < this.cacheTTL) {
            return this.cache;
        }
        const notebook = this.notebookTracker.currentWidget;
        if (!notebook) {
            return [];
        }
        const kernel = (_b = (_a = notebook.sessionContext) === null || _a === void 0 ? void 0 : _a.session) === null || _b === void 0 ? void 0 : _b.kernel;
        if (!kernel) {
            return [];
        }
        // Проверяем, что ядро idle
        if (kernel.status !== 'idle') {
            // Возвращаем старый кэш или пустой массив
            return this.cache || [];
        }
        try {
            const result = await this.executeInKernel(kernel, INSPECT_CODE);
            if (result) {
                this.cache = JSON.parse(result);
                this.cacheTimestamp = now;
                return this.cache;
            }
        }
        catch (e) {
            console.warn('Variable inspection failed:', e);
        }
        return this.cache || [];
    }
    /**
     * Форматировать переменные для промпта
     */
    async formatForPrompt() {
        const vars = await this.getVariables();
        if (vars.length === 0) {
            return 'Variables: (none or kernel not ready)';
        }
        const lines = ['Variables in kernel:'];
        for (const v of vars) {
            if (v.summary) {
                lines.push(`  ${v.name} (${v.type}): ${v.summary}`);
            }
            else {
                lines.push(`  ${v.name} (${v.type})`);
            }
        }
        return lines.join('\n');
    }
    /**
     * Сбросить кэш (вызывать после execute_cell)
     */
    invalidateCache() {
        this.cache = null;
        this.cacheTimestamp = 0;
    }
    /**
     * Выполнить код в ядре и вернуть stdout
     */
    async executeInKernel(kernel, code) {
        return new Promise(resolve => {
            let output = '';
            let resolved = false;
            const future = kernel.requestExecute({
                code,
                silent: true, // Не увеличивает execution_count
                store_history: false // Не сохраняет в In[]
            });
            // Собираем stdout
            future.onIOPub = (msg) => {
                if (msg.header.msg_type === 'stream' && msg.content.name === 'stdout') {
                    output += msg.content.text;
                }
            };
            // Ждём завершения
            future.done
                .then(() => {
                if (!resolved) {
                    resolved = true;
                    resolve(output.trim() || null);
                }
            })
                .catch(() => {
                if (!resolved) {
                    resolved = true;
                    resolve(null);
                }
            });
            // Таймаут 5 секунд
            setTimeout(() => {
                if (!resolved) {
                    resolved = true;
                    resolve(this.cache ? JSON.stringify(this.cache) : null);
                }
            }, 5000);
        });
    }
}


/***/ }

}]);
//# sourceMappingURL=lib_index_js.4dd2f7860e2717575bb4.js.map