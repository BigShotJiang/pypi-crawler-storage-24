"use strict";
(self["webpackChunkcellsistant"] = self["webpackChunkcellsistant"] || []).push([["style_index_js"],{

/***/ "./style/index.js"
/*!************************!*\
  !*** ./style/index.js ***!
  \************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _index_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./index.css */ "./style/index.css");
/* harmony import */ var highlight_js_styles_github_dark_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! highlight.js/styles/github-dark.css */ "./node_modules/highlight.js/styles/github-dark.css");




/***/ },

/***/ "./node_modules/css-loader/dist/cjs.js!./style/base.css"
/*!**************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/base.css ***!
  \**************************************************************/
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/* -----------------------------------------------------------------------------
 | Copyright (c) Jupyter Development Team.
 | Distributed under the terms of the Modified BSD License.
 |----------------------------------------------------------------------------- */

/* Base styles for AI Agent panel — uses JupyterLab CSS variables exclusively */

#jupyterlab-ai-agent-panel {
  background: var(--jp-layout-color1);
  color: var(--jp-content-font-color1);
  font-family: var(--jp-ui-font-family);
  font-size: var(--jp-ui-font-size1);
  line-height: var(--jp-content-line-height);
  display: flex;
  flex-direction: column;
  height: 100%;
  min-width: 320px;
  flex: 0 0 20% !important;
}

/* Right panel width */
.jp-SidePanel[data-side='right'] {
  flex: 0 0 20% !important;
  min-width: 320px;
}

.ai-agent-container {
  display: flex;
  flex-direction: column;
  height: 100%;
  padding: 10px;
  box-sizing: border-box;
}

/* ─────────────────────────────────────────────
   Header
   ───────────────────────────────────────────── */

.ai-agent-header {
  color: var(--jp-content-font-color1);
  margin: 0 0 10px;
  padding-bottom: 10px;
}

.ai-agent-header h2 {
  margin: 0 0 8px;
  font-size: var(--jp-content-font-size3);
  font-weight: var(--jp-content-heading-font-weight);
}

.ai-agent-header-top {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 8px;
}

/* Auto-mode checkbox */
.ai-agent-auto-mode {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-content-font-color2);
  cursor: pointer;
  user-select: none;
}

/* Unified checkbox styling */
.ai-agent-auto-mode input[type='checkbox'],
.ai-agent-ask-mode input[type='checkbox'] {
  margin: 0;
  cursor: pointer;
  width: 14px;
  height: 14px;
  accent-color: var(--jp-brand-color1);
}

/* ─────────────────────────────────────────────
   Messages Area
   ───────────────────────────────────────────── */

.ai-agent-messages {
  flex: 1;
  overflow-y: auto;
  padding: 10px;
  margin-bottom: 10px;
  border-radius: var(--jp-border-radius);
  background: var(--jp-layout-color0);
}

/* Message bubbles */
.ai-agent-message {
  margin-bottom: 12px;
  padding: 8px 12px;
  border-radius: var(--jp-border-radius);
  max-width: 90%;
}

.ai-agent-message.user {
  background: var(--jp-brand-color2);
  margin-left: auto;
  color: var(--jp-ui-inverse-font-color1);
}

.ai-agent-message.assistant {
  background: var(--jp-layout-color2);
  margin-right: auto;
}

.ai-agent-message-role {
  display: block;
  font-size: var(--jp-ui-font-size0);
  font-weight: 600;
  margin-bottom: 4px;
  opacity: 0.8;
}

.ai-agent-message-text {
  word-wrap: break-word;
  white-space: pre-wrap;
  line-height: 1.45;
}

.ai-agent-message-text br {
  display: block;
  margin-top: 0;
  margin-bottom: 0;
  content: '';
  line-height: 0.2;
}

.ai-agent-message-text h1,
.ai-agent-message-text h2,
.ai-agent-message-text h3,
.ai-agent-message-text p,
.ai-agent-message-text ul,
.ai-agent-message-text ol,
.ai-agent-message-text li,
.ai-agent-message-text pre,
.ai-agent-message-text strong,
.ai-agent-message-text em,
.ai-agent-message-text code,
.ai-agent-message-text a,
.ai-agent-message-text del {
  margin-top: 0 !important;
  margin-bottom: 0 !important;
}

.ai-agent-message-text ul,
.ai-agent-message-text ol {
  padding-left: 20px !important;
}

.ai-agent-message-text li {
  margin-left: 24px !important;
}

.ai-agent-message-text img {
  max-width: 300px !important;
  height: auto !important;
  border-radius: 4px;
}

.ai-agent-message-text pre,
.ai-agent-message-text code:not(.inline-code) {
  display: block;
  padding: 8px 12px !important;
  margin: 4px 0 !important;
  background: #212121 !important;
  border-radius: 4px;
  color: #eee !important;
  font-family: Menlo, Monaco, 'Courier New', monospace !important;
  font-size: 13px !important;
  line-height: 1.45 !important;
  overflow-x: auto;
}

.ai-agent-message-text .inline-code {
  background: #212121 !important;
  color: #eee !important;
  padding: 1px 5px !important;
  border-radius: 3px;
  font-family: Menlo, Monaco, 'Courier New', monospace !important;
  font-size: 13px !important;
}

/* Code block wrapper and buttons */
.ai-agent-message-text .code-block-wrapper {
  position: relative;
  display: block;
}

/* Tables */
.ai-agent-message-text table {
  border-collapse: collapse;
  width: 100%;
  overflow-x: auto;
  display: block;
  margin: 8px 0;
}

.ai-agent-message-text th,
.ai-agent-message-text td {
  padding: 8px 12px;
  border: 1px solid #ddd;
}

.ai-agent-message-text .code-block {
  display: block;
}

.ai-agent-message-text .code-block-buttons {
  position: absolute;
  top: 4px;
  right: 4px;
  display: flex;
  gap: 2px;
  background: transparent;
  z-index: 10;
}

.ai-agent-message-text .code-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 20px;
  height: 20px;
  border: none;
  border-radius: 3px;
  background: var(--jp-layout-color2);
  opacity: 0.6;
  cursor: pointer;
  padding: 0;
}

.ai-agent-message-text .code-btn:hover {
  opacity: 1;
  background: var(--jp-layout-color1);
}

.ai-agent-send-button,
.ai-agent-stop-button {
  padding: 4px 8px;
  background: var(--jp-brand-color1);
  color: var(--jp-ui-inverse-font-color1);
  border: none;
  border-radius: var(--jp-border-radius);
  cursor: pointer;
  transition: all 0.15s ease;
  min-width: 32px;
  min-height: 28px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.ai-agent-stop-button {
  background: var(--jp-error-color1);
}

.ai-agent-send-button:disabled,
.ai-agent-stop-button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.ai-agent-send-button:hover:not(:disabled) {
  background: var(--jp-brand-color0);
}

.ai-agent-send-button:active:not(:disabled) {
  transform: scale(0.97);
}

.ai-agent-stop-button:hover:not(:disabled) {
  background: var(--jp-error-color0);
}

.ai-agent-stop-button:active:not(:disabled) {
  transform: scale(0.97);
}

/* Header buttons (history, settings) */
.ai-agent-history-btn,
.ai-agent-settings-btn {
  padding: 4px 8px;
  background: transparent;
  border: none;
  border-radius: var(--jp-border-radius);
  cursor: pointer;
  transition: all 0.15s ease;
  color: var(--jp-content-font-color1);
  display: flex;
  align-items: center;
  justify-content: center;
  min-width: 28px;
  min-height: 28px;
}

.ai-agent-history-btn:hover,
.ai-agent-settings-btn:hover {
  background: var(--jp-layout-color2);
}

.ai-agent-history-btn:active,
.ai-agent-settings-btn:active {
  transform: scale(0.97);
}

/* Retry button */
.ai-agent-error-message {
  border: 1px solid var(--jp-error-color1) !important;
}

.ai-agent-retry-button {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  margin-top: 8px;
  padding: 4px 10px;
  background: var(--jp-accept-color-normal);
  color: var(--jp-ui-inverse-font-color1);
  border: none;
  border-radius: var(--jp-border-radius);
  cursor: pointer;
  font-size: var(--jp-ui-font-size0);
  font-weight: 500;
  transition: all 0.15s ease;
}

.ai-agent-retry-button:hover {
  background: var(--jp-accept-color-hover);
}

.ai-agent-retry-button:active {
  transform: scale(0.97);
}

/* Thinking indicator */
.ai-agent-thinking {
  padding: 8px 12px;
  font-style: italic;
  color: var(--jp-content-font-color3);
  font-size: var(--jp-ui-font-size0);
}

/* ─────────────────────────────────────────────
   Input Area
   ───────────────────────────────────────────── */

.ai-agent-input-container {
  display: flex;
  gap: 8px;
  padding-top: 10px;
}

.ai-agent-input {
  flex: 1;
  resize: none;
  padding: 8px 12px;
  border: 1px solid var(--jp-input-border-color);
  border-radius: var(--jp-border-radius);
  background: var(--jp-input-background);
  color: var(--jp-content-font-color1);
  font-family: var(--jp-content-font-family);
  font-size: var(--jp-ui-font-size1);
}

.ai-agent-input:focus {
  outline: none;
  border-color: var(--jp-input-active-border-color);
  box-shadow: var(--jp-input-box-shadow);
}

.ai-agent-input:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

/* ─────────────────────────────────────────────
   Buttons
   ───────────────────────────────────────────── */

/* JupyterLab-style buttons */
.jp-Button {
  padding: 4px 8px;
  min-height: 24px;
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--jp-border-radius);
  background: var(--jp-layout-color2);
  color: var(--jp-content-font-color1);
  font-family: var(--jp-ui-font-family);
  font-size: var(--jp-ui-font-size1);
  cursor: pointer;
  transition:
    background 0.2s,
    border-color 0.2s;
}

.jp-Button:hover {
  background: var(--jp-layout-color3);
  border-color: var(--jp-brand-color1);
}

.jp-Button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.jp-Button svg,
.ai-agent-send-button svg,
.ai-agent-history-btn svg,
.ai-agent-settings-btn svg,
.ai-agent-retry-button svg {
  width: 14px;
  height: 14px;
  fill: currentcolor;
}

.ai-agent-message-text .code-btn svg {
  width: 14px;
  height: 14px;
}

/* ─────────────────────────────────────────────
   Tool Calls
   ───────────────────────────────────────────── */

.ai-agent-tool-call {
  margin-bottom: 12px;
  padding: 10px 12px;
  border-radius: var(--jp-border-radius);
  background: var(--jp-layout-color2);
  border: 1px solid var(--jp-border-color2);
  max-width: 95%;
}

.ai-agent-tool-call-header {
  display: flex;
  align-items: center;
  gap: 6px;
  cursor: pointer;
  padding: 6px 10px;
  user-select: none;
  font-size: var(--jp-ui-font-size0);
}

.ai-agent-tool-call-header:hover {
  background: var(--jp-layout-color3);
}

.tool-collapse-icon {
  font-size: 10px;
  color: var(--jp-ui-font-color2);
  width: 12px;
  transition: transform 0.15s;
}

.ai-agent-tool-call-body {
  padding: 0 10px 8px 28px;
  overflow: hidden;
  transition:
    max-height 0.3s ease,
    opacity 0.2s;
  max-height: 2000px;
}

.ai-agent-tool-call.collapsed .ai-agent-tool-call-body {
  max-height: 0;
  opacity: 0;
  padding-bottom: 0;
}

.ai-agent-tool-call-args {
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-content-font-color2);
  background: var(--jp-layout-color0);
  padding: 6px 8px;
  border-radius: var(--jp-border-radius);
  font-family: var(--jp-code-font-family);
  white-space: pre-wrap;
  word-break: break-word;
}

.ai-agent-tool-call-result {
  font-size: var(--jp-ui-font-size0);
  background: var(--jp-layout-color0);
  padding: 6px 8px;
  border-radius: var(--jp-border-radius);
  font-family: var(--jp-code-font-family);
  white-space: pre-wrap;
  word-break: break-word;
  margin-top: 6px;
}

.ai-agent-tool-call-result.completed {
  color: var(--jp-success-color1);
}

.ai-agent-tool-call-result.error {
  color: var(--jp-error-color1);
}

/* Tool confirmation dialog */
.ai-agent-tool-confirm {
  margin-bottom: 12px;
  padding: 12px;
  border-radius: var(--jp-border-radius);
  max-width: 95%;
  box-shadow: var(--jp-elevation-z2);
  border-left: 4px solid;
}

.ai-agent-tool-confirm-details {
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-ui-font-color1);
  margin-bottom: 10px;
  padding: 8px;
  background: rgb(0 0 0 / 8%);
  border-radius: 4px;
}

/* Confirmation colors by safety level */
.ai-agent-tool-confirm.confirm-read {
  background: rgb(76 175 80 / 15%);
  border-color: var(--jp-success-color1);
  color: var(--jp-ui-font-color1);
}

.ai-agent-tool-confirm.confirm-write {
  background: rgb(255 152 0 / 15%);
  border-color: var(--jp-warn-color1);
  color: var(--jp-ui-font-color1);
}

.ai-agent-tool-confirm.confirm-execute {
  background: rgb(245 124 0 / 15%);
  border-color: var(--jp-warn-color0);
  color: var(--jp-ui-font-color1);
}

.ai-agent-tool-confirm.confirm-system {
  background: rgb(244 67 54 / 15%);
  border-color: var(--jp-error-color1);
  color: var(--jp-ui-font-color1);
}

.ai-agent-tool-confirm.confirm-read .ai-agent-tool-confirm-details,
.ai-agent-tool-confirm.confirm-write .ai-agent-tool-confirm-details,
.ai-agent-tool-confirm.confirm-execute .ai-agent-tool-confirm-details,
.ai-agent-tool-confirm.confirm-system .ai-agent-tool-confirm-details {
  background: rgb(0 0 0 / 8%);
}

.ai-agent-tool-confirm-text {
  margin-bottom: 10px;
  font-size: var(--jp-ui-font-size0);
  line-height: 1.4;
}

.ai-agent-tool-confirm-text strong {
  color: var(--jp-ui-font-color0);
}

.ai-agent-tool-confirm-buttons {
  display: flex;
  gap: 8px;
}

.ai-agent-tool-confirm-buttons button {
  padding: 6px 12px;
  border: none;
  border-radius: var(--jp-border-radius);
  cursor: pointer;
  font-size: var(--jp-ui-font-size0);
  transition: background 0.2s;
}

.ai-agent-tool-confirm-buttons .jp-mod-accept {
  background: var(--jp-success-color1);
  color: var(--jp-ui-inverse-font-color1);
}

.ai-agent-tool-confirm-buttons .jp-mod-accept:hover {
  background: var(--jp-success-color0);
}

.ai-agent-tool-confirm-buttons .jp-mod-reject {
  background: var(--jp-layout-color3);
  color: var(--jp-content-font-color1);
}

.ai-agent-tool-confirm-buttons .jp-mod-reject:hover {
  background: var(--jp-layout-color4);
}

/* Safety badge */
.ai-agent-safety-badge {
  display: inline-block;
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 11px;
  font-weight: 600;
  margin-right: 8px;
  background: var(--jp-layout-color3);
  color: var(--jp-ui-font-color1);
}

/* Show more button */
.ai-agent-show-more {
  background: none;
  border: none;
  color: var(--jp-brand-color1);
  cursor: pointer;
  font-size: var(--jp-ui-font-size0);
  padding: 4px 0;
  margin-top: 4px;
}

.ai-agent-show-more:hover {
  text-decoration: underline;
}

/* ─────────────────────────────────────────────
   Images & Output
   ───────────────────────────────────────────── */

.ai-agent-output-image {
  max-width: 100%;
  max-height: 400px;
  border-radius: 4px;
  margin-top: 8px;
  border: 1px solid var(--jp-border-color1);
  display: block;
}

.ai-agent-output-text {
  margin: 4px 0;
  padding: 4px 8px;
  font-size: 12px;
  font-family: var(--jp-code-font-family);
  white-space: pre-wrap;
  word-break: break-word;
  max-height: 200px;
  overflow-y: auto;
  background: var(--jp-layout-color0);
  border-radius: var(--jp-border-radius);
}

/* Image Analysis Suggestion */
.ai-agent-image-suggestion {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-top: 10px;
  padding: 8px 12px;
  background: linear-gradient(
    135deg,
    rgb(33 150 243 / 10%),
    rgb(33 150 243 / 5%)
  );
  border: 1px dashed var(--jp-brand-color1);
  border-radius: var(--jp-border-radius);
}

.ai-agent-suggestion-text {
  flex: 1;
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-content-font-color2);
}

.ai-agent-suggestion-btn {
  padding: 4px 12px;
  background: var(--jp-brand-color1);
  color: var(--jp-ui-inverse-font-color1);
  border: none;
  border-radius: var(--jp-border-radius);
  cursor: pointer;
  font-size: var(--jp-ui-font-size0);
  font-weight: 500;
  transition: background 0.2s;
}

.ai-agent-suggestion-btn:hover {
  background: var(--jp-brand-color0);
}

/* ─────────────────────────────────────────────
   Scrollbar
   ───────────────────────────────────────────── */

.ai-agent-messages::-webkit-scrollbar {
  width: 10px;
}

.ai-agent-messages::-webkit-scrollbar-track {
  background: var(--jp-scrollbar-background-color);
}

.ai-agent-messages::-webkit-scrollbar-thumb {
  background: rgb(var(--jp-scrollbar-thumb-color));
  border-radius: var(--jp-scrollbar-thumb-radius);
  margin: var(--jp-scrollbar-thumb-margin);
}

.ai-agent-messages::-webkit-scrollbar-thumb:hover {
  background: rgb(100 108 109);
}

/* ─────────────────────────────────────────────
   Resize Handle
   ───────────────────────────────────────────── */

.ai-agent-resize-handle {
  display: none;
}

.ai-agent-resize-handle:hover {
  background: var(--jp-brand-color1);
}

/* ─────────────────────────────────────────────
   Token Counter & Status Bar
   ───────────────────────────────────────────── */

.ai-agent-status-bar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 4px 10px;
  font-size: 11px;
  color: var(--jp-ui-font-color3);
}

/* Ask mode checkbox */
.ai-agent-ask-mode {
  display: flex;
  align-items: center;
  gap: 4px;
  cursor: pointer;
  user-select: none;
  color: var(--jp-ui-font-color3);
  transition: color 0.2s;
}

.ai-agent-ask-mode:hover {
  color: var(--jp-content-font-color1);
}

.ai-agent-ask-mode input[type='checkbox'] {
  margin: 0;
  cursor: pointer;
  width: 14px;
  height: 14px;
  accent-color: var(--jp-success-color1);
}

.ai-agent-ask-mode span {
  font-size: 11px;
}

.ai-agent-token-counter {
  cursor: help;
  user-select: none;
}

.ai-agent-token-counter.warning {
  color: var(--jp-warn-color1);
  font-weight: 600;
}

/* ─────────────────────────────────────────────
   History & Memory Panels (unified with Settings)
   ───────────────────────────────────────────── */

.ai-agent-history-actions {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  padding: 16px 20px;
  border-bottom: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color2);
}

.ai-agent-history-action-btn {
  flex: 1;
  min-width: 100px;
  padding: 8px 16px;
  background: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--jp-border-radius);
  cursor: pointer;
  font-size: var(--jp-ui-font-size1);
  color: var(--jp-content-font-color1);
  transition:
    background 0.2s,
    border-color 0.2s;
}

.ai-agent-history-action-btn:hover {
  background: var(--jp-brand-color2);
  color: var(--jp-ui-inverse-font-color1);
  border-color: var(--jp-brand-color1);
}

/* History/Memory list */
.ai-agent-history-list {
  display: flex;
  flex-direction: column;
  gap: 4px;
  padding: 16px 20px;
  overflow-y: auto;
  flex: 1;
}

.ai-agent-history-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px 12px;
  background: var(--jp-layout-color2);
  border-radius: var(--jp-border-radius);
  cursor: pointer;
  transition:
    background 0.2s,
    border-color 0.2s;
  border: 1px solid var(--jp-border-color2);
  color: var(--jp-content-font-color1);
}

.ai-agent-history-item:hover {
  background: var(--jp-layout-color3);
  border-color: var(--jp-border-color1);
}

.ai-agent-history-item.active {
  border-left: 3px solid var(--jp-brand-color1);
  background: var(--jp-layout-color3);
}

.ai-agent-history-item-main {
  display: flex;
  flex-direction: column;
  gap: 2px;
  flex: 1;
  min-width: 0;
}

.ai-agent-history-item-title {
  font-weight: 500;
  font-size: var(--jp-ui-font-size1);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  color: var(--jp-content-font-color1);
}

.ai-agent-history-item-date {
  font-size: 10px;
  color: var(--jp-ui-font-color3);
}

.ai-agent-history-item-meta {
  font-size: var(--jp-ui-font-size0);
  color: var(--jp-content-font-color2);
  margin-top: 4px;
}

.ai-agent-history-item-meta span {
  display: block;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.ai-agent-history-item-actions {
  display: flex;
  gap: 4px;
  margin-left: 8px;
}

.ai-agent-history-item-btn {
  background: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color2);
  cursor: pointer;
  font-size: 14px;
  padding: 4px 8px;
  border-radius: var(--jp-border-radius);
  opacity: 0.8;
  transition:
    opacity 0.2s,
    background 0.2s;
  color: var(--jp-content-font-color1);
}

.ai-agent-history-item-btn:hover {
  opacity: 1;
  background: var(--jp-layout-color3);
  border-color: var(--jp-border-color1);
}

.ai-agent-history-item-delete {
  background: transparent;
  border: none;
  cursor: pointer;
  font-size: 14px;
  padding: 4px;
  border-radius: var(--jp-border-radius);
  opacity: 0.6;
  transition: opacity 0.2s;
}

.ai-agent-history-item-delete:hover {
  opacity: 1;
  background: var(--jp-error-color3);
}

.ai-agent-history-empty,
.ai-agent-history-error,
.ai-agent-history-loading {
  text-align: center;
  padding: 40px 20px;
  color: var(--jp-ui-font-color3);
  font-size: var(--jp-ui-font-size1);
}

.ai-agent-history-error {
  color: var(--jp-error-color1);
}

.ai-agent-history-loading {
  font-style: italic;
}

/* ─────────────────────────────────────────────
   Notifications
   ───────────────────────────────────────────── */

.ai-agent-header-btn {
  background: transparent;
  border: none;
  cursor: pointer;
  font-size: 18px;
  padding: 4px 8px;
  border-radius: 4px;
  transition: background 0.2s;
  color: var(--jp-content-font-color1);
}

.ai-agent-header-btn:hover {
  background: var(--jp-layout-color2);
}

.ai-agent-notification {
  position: absolute;
  bottom: 70px;
  left: 50%;
  transform: translateX(-50%);
  padding: 10px 16px;
  border-radius: 6px;
  font-size: var(--jp-ui-font-size0);
  font-weight: 500;
  box-shadow: var(--jp-elevation-z4);
  z-index: 1001;
  animation: ai-agent-notification-slide-in 0.3s ease;
  max-width: 80%;
  text-align: center;
}

.ai-agent-notification-hide {
  animation: ai-agent-notification-slide-out 0.3s ease forwards;
}

@keyframes ai-agent-notification-slide-in {
  from {
    opacity: 0;
    transform: translateX(-50%) translateY(10px);
  }

  to {
    opacity: 1;
    transform: translateX(-50%) translateY(0);
  }
}

@keyframes ai-agent-notification-slide-out {
  from {
    opacity: 1;
    transform: translateX(-50%) translateY(0);
  }

  to {
    opacity: 0;
    transform: translateX(-50%) translateY(10px);
  }
}

@keyframes ai-agent-notification-slide-out {
  from {
    opacity: 1;
    transform: translateX(-50%) translateY(0);
  }

  to {
    opacity: 0;
    transform: translateX(-50%) translateY(10px);
  }
}

.ai-agent-notification-success {
  background: var(--jp-success-color1);
  color: var(--jp-ui-inverse-font-color1);
}

.ai-agent-notification-error {
  background: var(--jp-error-color1);
  color: var(--jp-ui-inverse-font-color1);
}

.ai-agent-notification-info {
  background: var(--jp-brand-color1);
  color: var(--jp-ui-inverse-font-color1);
}

/* ─────────────────────────────────────────────
   Context Warning
   ───────────────────────────────────────────── */

.ai-agent-context-warning {
  background: var(--jp-warn-color3);
  border: 1px solid var(--jp-warn-color1);
  border-radius: 6px;
  padding: 8px 12px;
  margin: 8px;
  font-size: 12px;
  color: var(--jp-warn-color0);
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

.ai-agent-new-chat-btn {
  padding: 4px 12px;
  background: var(--jp-warn-color1);
  color: var(--jp-ui-inverse-font-color1);
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 12px;
  white-space: nowrap;
}

.ai-agent-new-chat-btn:hover {
  background: var(--jp-warn-color0);
}

/* ─────────────────────────────────────────────
   Utility Classes
   ───────────────────────────────────────────── */

.ai-agent-hidden {
  display: none !important;
}

.ai-agent-buttons {
  display: flex;
  flex-direction: column;
  gap: 4px;
}
`, "",{"version":3,"sources":["webpack://./style/base.css"],"names":[],"mappings":"AAAA;;;iFAGiF;;AAEjF,+EAA+E;;AAE/E;EACE,mCAAmC;EACnC,oCAAoC;EACpC,qCAAqC;EACrC,kCAAkC;EAClC,0CAA0C;EAC1C,aAAa;EACb,sBAAsB;EACtB,YAAY;EACZ,gBAAgB;EAChB,wBAAwB;AAC1B;;AAEA,sBAAsB;AACtB;EACE,wBAAwB;EACxB,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,YAAY;EACZ,aAAa;EACb,sBAAsB;AACxB;;AAEA;;kDAEkD;;AAElD;EACE,oCAAoC;EACpC,gBAAgB;EAChB,oBAAoB;AACtB;;AAEA;EACE,eAAe;EACf,uCAAuC;EACvC,kDAAkD;AACpD;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,kBAAkB;AACpB;;AAEA,uBAAuB;AACvB;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,kCAAkC;EAClC,oCAAoC;EACpC,eAAe;EACf,iBAAiB;AACnB;;AAEA,6BAA6B;AAC7B;;EAEE,SAAS;EACT,eAAe;EACf,WAAW;EACX,YAAY;EACZ,oCAAoC;AACtC;;AAEA;;kDAEkD;;AAElD;EACE,OAAO;EACP,gBAAgB;EAChB,aAAa;EACb,mBAAmB;EACnB,sCAAsC;EACtC,mCAAmC;AACrC;;AAEA,oBAAoB;AACpB;EACE,mBAAmB;EACnB,iBAAiB;EACjB,sCAAsC;EACtC,cAAc;AAChB;;AAEA;EACE,kCAAkC;EAClC,iBAAiB;EACjB,uCAAuC;AACzC;;AAEA;EACE,mCAAmC;EACnC,kBAAkB;AACpB;;AAEA;EACE,cAAc;EACd,kCAAkC;EAClC,gBAAgB;EAChB,kBAAkB;EAClB,YAAY;AACd;;AAEA;EACE,qBAAqB;EACrB,qBAAqB;EACrB,iBAAiB;AACnB;;AAEA;EACE,cAAc;EACd,aAAa;EACb,gBAAgB;EAChB,WAAW;EACX,gBAAgB;AAClB;;AAEA;;;;;;;;;;;;;EAaE,wBAAwB;EACxB,2BAA2B;AAC7B;;AAEA;;EAEE,6BAA6B;AAC/B;;AAEA;EACE,4BAA4B;AAC9B;;AAEA;EACE,2BAA2B;EAC3B,uBAAuB;EACvB,kBAAkB;AACpB;;AAEA;;EAEE,cAAc;EACd,4BAA4B;EAC5B,wBAAwB;EACxB,8BAA8B;EAC9B,kBAAkB;EAClB,sBAAsB;EACtB,+DAA+D;EAC/D,0BAA0B;EAC1B,4BAA4B;EAC5B,gBAAgB;AAClB;;AAEA;EACE,8BAA8B;EAC9B,sBAAsB;EACtB,2BAA2B;EAC3B,kBAAkB;EAClB,+DAA+D;EAC/D,0BAA0B;AAC5B;;AAEA,mCAAmC;AACnC;EACE,kBAAkB;EAClB,cAAc;AAChB;;AAEA,WAAW;AACX;EACE,yBAAyB;EACzB,WAAW;EACX,gBAAgB;EAChB,cAAc;EACd,aAAa;AACf;;AAEA;;EAEE,iBAAiB;EACjB,sBAAsB;AACxB;;AAEA;EACE,cAAc;AAChB;;AAEA;EACE,kBAAkB;EAClB,QAAQ;EACR,UAAU;EACV,aAAa;EACb,QAAQ;EACR,uBAAuB;EACvB,WAAW;AACb;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,WAAW;EACX,YAAY;EACZ,YAAY;EACZ,kBAAkB;EAClB,mCAAmC;EACnC,YAAY;EACZ,eAAe;EACf,UAAU;AACZ;;AAEA;EACE,UAAU;EACV,mCAAmC;AACrC;;AAEA;;EAEE,gBAAgB;EAChB,kCAAkC;EAClC,uCAAuC;EACvC,YAAY;EACZ,sCAAsC;EACtC,eAAe;EACf,0BAA0B;EAC1B,eAAe;EACf,gBAAgB;EAChB,aAAa;EACb,mBAAmB;EACnB,uBAAuB;AACzB;;AAEA;EACE,kCAAkC;AACpC;;AAEA;;EAEE,YAAY;EACZ,mBAAmB;AACrB;;AAEA;EACE,kCAAkC;AACpC;;AAEA;EACE,sBAAsB;AACxB;;AAEA;EACE,kCAAkC;AACpC;;AAEA;EACE,sBAAsB;AACxB;;AAEA,uCAAuC;AACvC;;EAEE,gBAAgB;EAChB,uBAAuB;EACvB,YAAY;EACZ,sCAAsC;EACtC,eAAe;EACf,0BAA0B;EAC1B,oCAAoC;EACpC,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,eAAe;EACf,gBAAgB;AAClB;;AAEA;;EAEE,mCAAmC;AACrC;;AAEA;;EAEE,sBAAsB;AACxB;;AAEA,iBAAiB;AACjB;EACE,mDAAmD;AACrD;;AAEA;EACE,oBAAoB;EACpB,mBAAmB;EACnB,QAAQ;EACR,eAAe;EACf,iBAAiB;EACjB,yCAAyC;EACzC,uCAAuC;EACvC,YAAY;EACZ,sCAAsC;EACtC,eAAe;EACf,kCAAkC;EAClC,gBAAgB;EAChB,0BAA0B;AAC5B;;AAEA;EACE,wCAAwC;AAC1C;;AAEA;EACE,sBAAsB;AACxB;;AAEA,uBAAuB;AACvB;EACE,iBAAiB;EACjB,kBAAkB;EAClB,oCAAoC;EACpC,kCAAkC;AACpC;;AAEA;;kDAEkD;;AAElD;EACE,aAAa;EACb,QAAQ;EACR,iBAAiB;AACnB;;AAEA;EACE,OAAO;EACP,YAAY;EACZ,iBAAiB;EACjB,8CAA8C;EAC9C,sCAAsC;EACtC,sCAAsC;EACtC,oCAAoC;EACpC,0CAA0C;EAC1C,kCAAkC;AACpC;;AAEA;EACE,aAAa;EACb,iDAAiD;EACjD,sCAAsC;AACxC;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA;;kDAEkD;;AAElD,6BAA6B;AAC7B;EACE,gBAAgB;EAChB,gBAAgB;EAChB,yCAAyC;EACzC,sCAAsC;EACtC,mCAAmC;EACnC,oCAAoC;EACpC,qCAAqC;EACrC,kCAAkC;EAClC,eAAe;EACf;;qBAEmB;AACrB;;AAEA;EACE,mCAAmC;EACnC,oCAAoC;AACtC;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA;;;;;EAKE,WAAW;EACX,YAAY;EACZ,kBAAkB;AACpB;;AAEA;EACE,WAAW;EACX,YAAY;AACd;;AAEA;;kDAEkD;;AAElD;EACE,mBAAmB;EACnB,kBAAkB;EAClB,sCAAsC;EACtC,mCAAmC;EACnC,yCAAyC;EACzC,cAAc;AAChB;;AAEA;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,eAAe;EACf,iBAAiB;EACjB,iBAAiB;EACjB,kCAAkC;AACpC;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,eAAe;EACf,+BAA+B;EAC/B,WAAW;EACX,2BAA2B;AAC7B;;AAEA;EACE,wBAAwB;EACxB,gBAAgB;EAChB;;gBAEc;EACd,kBAAkB;AACpB;;AAEA;EACE,aAAa;EACb,UAAU;EACV,iBAAiB;AACnB;;AAEA;EACE,kCAAkC;EAClC,oCAAoC;EACpC,mCAAmC;EACnC,gBAAgB;EAChB,sCAAsC;EACtC,uCAAuC;EACvC,qBAAqB;EACrB,sBAAsB;AACxB;;AAEA;EACE,kCAAkC;EAClC,mCAAmC;EACnC,gBAAgB;EAChB,sCAAsC;EACtC,uCAAuC;EACvC,qBAAqB;EACrB,sBAAsB;EACtB,eAAe;AACjB;;AAEA;EACE,+BAA+B;AACjC;;AAEA;EACE,6BAA6B;AAC/B;;AAEA,6BAA6B;AAC7B;EACE,mBAAmB;EACnB,aAAa;EACb,sCAAsC;EACtC,cAAc;EACd,kCAAkC;EAClC,sBAAsB;AACxB;;AAEA;EACE,kCAAkC;EAClC,+BAA+B;EAC/B,mBAAmB;EACnB,YAAY;EACZ,2BAA2B;EAC3B,kBAAkB;AACpB;;AAEA,wCAAwC;AACxC;EACE,gCAAgC;EAChC,sCAAsC;EACtC,+BAA+B;AACjC;;AAEA;EACE,gCAAgC;EAChC,mCAAmC;EACnC,+BAA+B;AACjC;;AAEA;EACE,gCAAgC;EAChC,mCAAmC;EACnC,+BAA+B;AACjC;;AAEA;EACE,gCAAgC;EAChC,oCAAoC;EACpC,+BAA+B;AACjC;;AAEA;;;;EAIE,2BAA2B;AAC7B;;AAEA;EACE,mBAAmB;EACnB,kCAAkC;EAClC,gBAAgB;AAClB;;AAEA;EACE,+BAA+B;AACjC;;AAEA;EACE,aAAa;EACb,QAAQ;AACV;;AAEA;EACE,iBAAiB;EACjB,YAAY;EACZ,sCAAsC;EACtC,eAAe;EACf,kCAAkC;EAClC,2BAA2B;AAC7B;;AAEA;EACE,oCAAoC;EACpC,uCAAuC;AACzC;;AAEA;EACE,oCAAoC;AACtC;;AAEA;EACE,mCAAmC;EACnC,oCAAoC;AACtC;;AAEA;EACE,mCAAmC;AACrC;;AAEA,iBAAiB;AACjB;EACE,qBAAqB;EACrB,gBAAgB;EAChB,kBAAkB;EAClB,eAAe;EACf,gBAAgB;EAChB,iBAAiB;EACjB,mCAAmC;EACnC,+BAA+B;AACjC;;AAEA,qBAAqB;AACrB;EACE,gBAAgB;EAChB,YAAY;EACZ,6BAA6B;EAC7B,eAAe;EACf,kCAAkC;EAClC,cAAc;EACd,eAAe;AACjB;;AAEA;EACE,0BAA0B;AAC5B;;AAEA;;kDAEkD;;AAElD;EACE,eAAe;EACf,iBAAiB;EACjB,kBAAkB;EAClB,eAAe;EACf,yCAAyC;EACzC,cAAc;AAChB;;AAEA;EACE,aAAa;EACb,gBAAgB;EAChB,eAAe;EACf,uCAAuC;EACvC,qBAAqB;EACrB,sBAAsB;EACtB,iBAAiB;EACjB,gBAAgB;EAChB,mCAAmC;EACnC,sCAAsC;AACxC;;AAEA,8BAA8B;AAC9B;EACE,aAAa;EACb,mBAAmB;EACnB,SAAS;EACT,gBAAgB;EAChB,iBAAiB;EACjB;;;;GAIC;EACD,yCAAyC;EACzC,sCAAsC;AACxC;;AAEA;EACE,OAAO;EACP,kCAAkC;EAClC,oCAAoC;AACtC;;AAEA;EACE,iBAAiB;EACjB,kCAAkC;EAClC,uCAAuC;EACvC,YAAY;EACZ,sCAAsC;EACtC,eAAe;EACf,kCAAkC;EAClC,gBAAgB;EAChB,2BAA2B;AAC7B;;AAEA;EACE,kCAAkC;AACpC;;AAEA;;kDAEkD;;AAElD;EACE,WAAW;AACb;;AAEA;EACE,gDAAgD;AAClD;;AAEA;EACE,gDAAgD;EAChD,+CAA+C;EAC/C,wCAAwC;AAC1C;;AAEA;EACE,4BAA4B;AAC9B;;AAEA;;kDAEkD;;AAElD;EACE,aAAa;AACf;;AAEA;EACE,kCAAkC;AACpC;;AAEA;;kDAEkD;;AAElD;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,iBAAiB;EACjB,eAAe;EACf,+BAA+B;AACjC;;AAEA,sBAAsB;AACtB;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,eAAe;EACf,iBAAiB;EACjB,+BAA+B;EAC/B,sBAAsB;AACxB;;AAEA;EACE,oCAAoC;AACtC;;AAEA;EACE,SAAS;EACT,eAAe;EACf,WAAW;EACX,YAAY;EACZ,sCAAsC;AACxC;;AAEA;EACE,eAAe;AACjB;;AAEA;EACE,YAAY;EACZ,iBAAiB;AACnB;;AAEA;EACE,4BAA4B;EAC5B,gBAAgB;AAClB;;AAEA;;kDAEkD;;AAElD;EACE,aAAa;EACb,QAAQ;EACR,eAAe;EACf,kBAAkB;EAClB,gDAAgD;EAChD,mCAAmC;AACrC;;AAEA;EACE,OAAO;EACP,gBAAgB;EAChB,iBAAiB;EACjB,mCAAmC;EACnC,yCAAyC;EACzC,sCAAsC;EACtC,eAAe;EACf,kCAAkC;EAClC,oCAAoC;EACpC;;qBAEmB;AACrB;;AAEA;EACE,kCAAkC;EAClC,uCAAuC;EACvC,oCAAoC;AACtC;;AAEA,wBAAwB;AACxB;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;EACR,kBAAkB;EAClB,gBAAgB;EAChB,OAAO;AACT;;AAEA;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,kBAAkB;EAClB,mCAAmC;EACnC,sCAAsC;EACtC,eAAe;EACf;;qBAEmB;EACnB,yCAAyC;EACzC,oCAAoC;AACtC;;AAEA;EACE,mCAAmC;EACnC,qCAAqC;AACvC;;AAEA;EACE,6CAA6C;EAC7C,mCAAmC;AACrC;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;EACR,OAAO;EACP,YAAY;AACd;;AAEA;EACE,gBAAgB;EAChB,kCAAkC;EAClC,mBAAmB;EACnB,gBAAgB;EAChB,uBAAuB;EACvB,oCAAoC;AACtC;;AAEA;EACE,eAAe;EACf,+BAA+B;AACjC;;AAEA;EACE,kCAAkC;EAClC,oCAAoC;EACpC,eAAe;AACjB;;AAEA;EACE,cAAc;EACd,gBAAgB;EAChB,uBAAuB;EACvB,mBAAmB;AACrB;;AAEA;EACE,aAAa;EACb,QAAQ;EACR,gBAAgB;AAClB;;AAEA;EACE,mCAAmC;EACnC,yCAAyC;EACzC,eAAe;EACf,eAAe;EACf,gBAAgB;EAChB,sCAAsC;EACtC,YAAY;EACZ;;mBAEiB;EACjB,oCAAoC;AACtC;;AAEA;EACE,UAAU;EACV,mCAAmC;EACnC,qCAAqC;AACvC;;AAEA;EACE,uBAAuB;EACvB,YAAY;EACZ,eAAe;EACf,eAAe;EACf,YAAY;EACZ,sCAAsC;EACtC,YAAY;EACZ,wBAAwB;AAC1B;;AAEA;EACE,UAAU;EACV,kCAAkC;AACpC;;AAEA;;;EAGE,kBAAkB;EAClB,kBAAkB;EAClB,+BAA+B;EAC/B,kCAAkC;AACpC;;AAEA;EACE,6BAA6B;AAC/B;;AAEA;EACE,kBAAkB;AACpB;;AAEA;;kDAEkD;;AAElD;EACE,uBAAuB;EACvB,YAAY;EACZ,eAAe;EACf,eAAe;EACf,gBAAgB;EAChB,kBAAkB;EAClB,2BAA2B;EAC3B,oCAAoC;AACtC;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,kBAAkB;EAClB,YAAY;EACZ,SAAS;EACT,2BAA2B;EAC3B,kBAAkB;EAClB,kBAAkB;EAClB,kCAAkC;EAClC,gBAAgB;EAChB,kCAAkC;EAClC,aAAa;EACb,mDAAmD;EACnD,cAAc;EACd,kBAAkB;AACpB;;AAEA;EACE,6DAA6D;AAC/D;;AAEA;EACE;IACE,UAAU;IACV,4CAA4C;EAC9C;;EAEA;IACE,UAAU;IACV,yCAAyC;EAC3C;AACF;;AAEA;EACE;IACE,UAAU;IACV,yCAAyC;EAC3C;;EAEA;IACE,UAAU;IACV,4CAA4C;EAC9C;AACF;;AAEA;EACE;IACE,UAAU;IACV,yCAAyC;EAC3C;;EAEA;IACE,UAAU;IACV,4CAA4C;EAC9C;AACF;;AAEA;EACE,oCAAoC;EACpC,uCAAuC;AACzC;;AAEA;EACE,kCAAkC;EAClC,uCAAuC;AACzC;;AAEA;EACE,kCAAkC;EAClC,uCAAuC;AACzC;;AAEA;;kDAEkD;;AAElD;EACE,iCAAiC;EACjC,uCAAuC;EACvC,kBAAkB;EAClB,iBAAiB;EACjB,WAAW;EACX,eAAe;EACf,4BAA4B;EAC5B,aAAa;EACb,mBAAmB;EACnB,QAAQ;EACR,eAAe;AACjB;;AAEA;EACE,iBAAiB;EACjB,iCAAiC;EACjC,uCAAuC;EACvC,YAAY;EACZ,kBAAkB;EAClB,eAAe;EACf,eAAe;EACf,mBAAmB;AACrB;;AAEA;EACE,iCAAiC;AACnC;;AAEA;;kDAEkD;;AAElD;EACE,wBAAwB;AAC1B;;AAEA;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;AACV","sourcesContent":["/* -----------------------------------------------------------------------------\n | Copyright (c) Jupyter Development Team.\n | Distributed under the terms of the Modified BSD License.\n |----------------------------------------------------------------------------- */\n\n/* Base styles for AI Agent panel — uses JupyterLab CSS variables exclusively */\n\n#jupyterlab-ai-agent-panel {\n  background: var(--jp-layout-color1);\n  color: var(--jp-content-font-color1);\n  font-family: var(--jp-ui-font-family);\n  font-size: var(--jp-ui-font-size1);\n  line-height: var(--jp-content-line-height);\n  display: flex;\n  flex-direction: column;\n  height: 100%;\n  min-width: 320px;\n  flex: 0 0 20% !important;\n}\n\n/* Right panel width */\n.jp-SidePanel[data-side='right'] {\n  flex: 0 0 20% !important;\n  min-width: 320px;\n}\n\n.ai-agent-container {\n  display: flex;\n  flex-direction: column;\n  height: 100%;\n  padding: 10px;\n  box-sizing: border-box;\n}\n\n/* ─────────────────────────────────────────────\n   Header\n   ───────────────────────────────────────────── */\n\n.ai-agent-header {\n  color: var(--jp-content-font-color1);\n  margin: 0 0 10px;\n  padding-bottom: 10px;\n}\n\n.ai-agent-header h2 {\n  margin: 0 0 8px;\n  font-size: var(--jp-content-font-size3);\n  font-weight: var(--jp-content-heading-font-weight);\n}\n\n.ai-agent-header-top {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  margin-bottom: 8px;\n}\n\n/* Auto-mode checkbox */\n.ai-agent-auto-mode {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  font-size: var(--jp-ui-font-size0);\n  color: var(--jp-content-font-color2);\n  cursor: pointer;\n  user-select: none;\n}\n\n/* Unified checkbox styling */\n.ai-agent-auto-mode input[type='checkbox'],\n.ai-agent-ask-mode input[type='checkbox'] {\n  margin: 0;\n  cursor: pointer;\n  width: 14px;\n  height: 14px;\n  accent-color: var(--jp-brand-color1);\n}\n\n/* ─────────────────────────────────────────────\n   Messages Area\n   ───────────────────────────────────────────── */\n\n.ai-agent-messages {\n  flex: 1;\n  overflow-y: auto;\n  padding: 10px;\n  margin-bottom: 10px;\n  border-radius: var(--jp-border-radius);\n  background: var(--jp-layout-color0);\n}\n\n/* Message bubbles */\n.ai-agent-message {\n  margin-bottom: 12px;\n  padding: 8px 12px;\n  border-radius: var(--jp-border-radius);\n  max-width: 90%;\n}\n\n.ai-agent-message.user {\n  background: var(--jp-brand-color2);\n  margin-left: auto;\n  color: var(--jp-ui-inverse-font-color1);\n}\n\n.ai-agent-message.assistant {\n  background: var(--jp-layout-color2);\n  margin-right: auto;\n}\n\n.ai-agent-message-role {\n  display: block;\n  font-size: var(--jp-ui-font-size0);\n  font-weight: 600;\n  margin-bottom: 4px;\n  opacity: 0.8;\n}\n\n.ai-agent-message-text {\n  word-wrap: break-word;\n  white-space: pre-wrap;\n  line-height: 1.45;\n}\n\n.ai-agent-message-text br {\n  display: block;\n  margin-top: 0;\n  margin-bottom: 0;\n  content: '';\n  line-height: 0.2;\n}\n\n.ai-agent-message-text h1,\n.ai-agent-message-text h2,\n.ai-agent-message-text h3,\n.ai-agent-message-text p,\n.ai-agent-message-text ul,\n.ai-agent-message-text ol,\n.ai-agent-message-text li,\n.ai-agent-message-text pre,\n.ai-agent-message-text strong,\n.ai-agent-message-text em,\n.ai-agent-message-text code,\n.ai-agent-message-text a,\n.ai-agent-message-text del {\n  margin-top: 0 !important;\n  margin-bottom: 0 !important;\n}\n\n.ai-agent-message-text ul,\n.ai-agent-message-text ol {\n  padding-left: 20px !important;\n}\n\n.ai-agent-message-text li {\n  margin-left: 24px !important;\n}\n\n.ai-agent-message-text img {\n  max-width: 300px !important;\n  height: auto !important;\n  border-radius: 4px;\n}\n\n.ai-agent-message-text pre,\n.ai-agent-message-text code:not(.inline-code) {\n  display: block;\n  padding: 8px 12px !important;\n  margin: 4px 0 !important;\n  background: #212121 !important;\n  border-radius: 4px;\n  color: #eee !important;\n  font-family: Menlo, Monaco, 'Courier New', monospace !important;\n  font-size: 13px !important;\n  line-height: 1.45 !important;\n  overflow-x: auto;\n}\n\n.ai-agent-message-text .inline-code {\n  background: #212121 !important;\n  color: #eee !important;\n  padding: 1px 5px !important;\n  border-radius: 3px;\n  font-family: Menlo, Monaco, 'Courier New', monospace !important;\n  font-size: 13px !important;\n}\n\n/* Code block wrapper and buttons */\n.ai-agent-message-text .code-block-wrapper {\n  position: relative;\n  display: block;\n}\n\n/* Tables */\n.ai-agent-message-text table {\n  border-collapse: collapse;\n  width: 100%;\n  overflow-x: auto;\n  display: block;\n  margin: 8px 0;\n}\n\n.ai-agent-message-text th,\n.ai-agent-message-text td {\n  padding: 8px 12px;\n  border: 1px solid #ddd;\n}\n\n.ai-agent-message-text .code-block {\n  display: block;\n}\n\n.ai-agent-message-text .code-block-buttons {\n  position: absolute;\n  top: 4px;\n  right: 4px;\n  display: flex;\n  gap: 2px;\n  background: transparent;\n  z-index: 10;\n}\n\n.ai-agent-message-text .code-btn {\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  width: 20px;\n  height: 20px;\n  border: none;\n  border-radius: 3px;\n  background: var(--jp-layout-color2);\n  opacity: 0.6;\n  cursor: pointer;\n  padding: 0;\n}\n\n.ai-agent-message-text .code-btn:hover {\n  opacity: 1;\n  background: var(--jp-layout-color1);\n}\n\n.ai-agent-send-button,\n.ai-agent-stop-button {\n  padding: 4px 8px;\n  background: var(--jp-brand-color1);\n  color: var(--jp-ui-inverse-font-color1);\n  border: none;\n  border-radius: var(--jp-border-radius);\n  cursor: pointer;\n  transition: all 0.15s ease;\n  min-width: 32px;\n  min-height: 28px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.ai-agent-stop-button {\n  background: var(--jp-error-color1);\n}\n\n.ai-agent-send-button:disabled,\n.ai-agent-stop-button:disabled {\n  opacity: 0.5;\n  cursor: not-allowed;\n}\n\n.ai-agent-send-button:hover:not(:disabled) {\n  background: var(--jp-brand-color0);\n}\n\n.ai-agent-send-button:active:not(:disabled) {\n  transform: scale(0.97);\n}\n\n.ai-agent-stop-button:hover:not(:disabled) {\n  background: var(--jp-error-color0);\n}\n\n.ai-agent-stop-button:active:not(:disabled) {\n  transform: scale(0.97);\n}\n\n/* Header buttons (history, settings) */\n.ai-agent-history-btn,\n.ai-agent-settings-btn {\n  padding: 4px 8px;\n  background: transparent;\n  border: none;\n  border-radius: var(--jp-border-radius);\n  cursor: pointer;\n  transition: all 0.15s ease;\n  color: var(--jp-content-font-color1);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  min-width: 28px;\n  min-height: 28px;\n}\n\n.ai-agent-history-btn:hover,\n.ai-agent-settings-btn:hover {\n  background: var(--jp-layout-color2);\n}\n\n.ai-agent-history-btn:active,\n.ai-agent-settings-btn:active {\n  transform: scale(0.97);\n}\n\n/* Retry button */\n.ai-agent-error-message {\n  border: 1px solid var(--jp-error-color1) !important;\n}\n\n.ai-agent-retry-button {\n  display: inline-flex;\n  align-items: center;\n  gap: 6px;\n  margin-top: 8px;\n  padding: 4px 10px;\n  background: var(--jp-accept-color-normal);\n  color: var(--jp-ui-inverse-font-color1);\n  border: none;\n  border-radius: var(--jp-border-radius);\n  cursor: pointer;\n  font-size: var(--jp-ui-font-size0);\n  font-weight: 500;\n  transition: all 0.15s ease;\n}\n\n.ai-agent-retry-button:hover {\n  background: var(--jp-accept-color-hover);\n}\n\n.ai-agent-retry-button:active {\n  transform: scale(0.97);\n}\n\n/* Thinking indicator */\n.ai-agent-thinking {\n  padding: 8px 12px;\n  font-style: italic;\n  color: var(--jp-content-font-color3);\n  font-size: var(--jp-ui-font-size0);\n}\n\n/* ─────────────────────────────────────────────\n   Input Area\n   ───────────────────────────────────────────── */\n\n.ai-agent-input-container {\n  display: flex;\n  gap: 8px;\n  padding-top: 10px;\n}\n\n.ai-agent-input {\n  flex: 1;\n  resize: none;\n  padding: 8px 12px;\n  border: 1px solid var(--jp-input-border-color);\n  border-radius: var(--jp-border-radius);\n  background: var(--jp-input-background);\n  color: var(--jp-content-font-color1);\n  font-family: var(--jp-content-font-family);\n  font-size: var(--jp-ui-font-size1);\n}\n\n.ai-agent-input:focus {\n  outline: none;\n  border-color: var(--jp-input-active-border-color);\n  box-shadow: var(--jp-input-box-shadow);\n}\n\n.ai-agent-input:disabled {\n  opacity: 0.6;\n  cursor: not-allowed;\n}\n\n/* ─────────────────────────────────────────────\n   Buttons\n   ───────────────────────────────────────────── */\n\n/* JupyterLab-style buttons */\n.jp-Button {\n  padding: 4px 8px;\n  min-height: 24px;\n  border: 1px solid var(--jp-border-color2);\n  border-radius: var(--jp-border-radius);\n  background: var(--jp-layout-color2);\n  color: var(--jp-content-font-color1);\n  font-family: var(--jp-ui-font-family);\n  font-size: var(--jp-ui-font-size1);\n  cursor: pointer;\n  transition:\n    background 0.2s,\n    border-color 0.2s;\n}\n\n.jp-Button:hover {\n  background: var(--jp-layout-color3);\n  border-color: var(--jp-brand-color1);\n}\n\n.jp-Button:disabled {\n  opacity: 0.5;\n  cursor: not-allowed;\n}\n\n.jp-Button svg,\n.ai-agent-send-button svg,\n.ai-agent-history-btn svg,\n.ai-agent-settings-btn svg,\n.ai-agent-retry-button svg {\n  width: 14px;\n  height: 14px;\n  fill: currentcolor;\n}\n\n.ai-agent-message-text .code-btn svg {\n  width: 14px;\n  height: 14px;\n}\n\n/* ─────────────────────────────────────────────\n   Tool Calls\n   ───────────────────────────────────────────── */\n\n.ai-agent-tool-call {\n  margin-bottom: 12px;\n  padding: 10px 12px;\n  border-radius: var(--jp-border-radius);\n  background: var(--jp-layout-color2);\n  border: 1px solid var(--jp-border-color2);\n  max-width: 95%;\n}\n\n.ai-agent-tool-call-header {\n  display: flex;\n  align-items: center;\n  gap: 6px;\n  cursor: pointer;\n  padding: 6px 10px;\n  user-select: none;\n  font-size: var(--jp-ui-font-size0);\n}\n\n.ai-agent-tool-call-header:hover {\n  background: var(--jp-layout-color3);\n}\n\n.tool-collapse-icon {\n  font-size: 10px;\n  color: var(--jp-ui-font-color2);\n  width: 12px;\n  transition: transform 0.15s;\n}\n\n.ai-agent-tool-call-body {\n  padding: 0 10px 8px 28px;\n  overflow: hidden;\n  transition:\n    max-height 0.3s ease,\n    opacity 0.2s;\n  max-height: 2000px;\n}\n\n.ai-agent-tool-call.collapsed .ai-agent-tool-call-body {\n  max-height: 0;\n  opacity: 0;\n  padding-bottom: 0;\n}\n\n.ai-agent-tool-call-args {\n  font-size: var(--jp-ui-font-size0);\n  color: var(--jp-content-font-color2);\n  background: var(--jp-layout-color0);\n  padding: 6px 8px;\n  border-radius: var(--jp-border-radius);\n  font-family: var(--jp-code-font-family);\n  white-space: pre-wrap;\n  word-break: break-word;\n}\n\n.ai-agent-tool-call-result {\n  font-size: var(--jp-ui-font-size0);\n  background: var(--jp-layout-color0);\n  padding: 6px 8px;\n  border-radius: var(--jp-border-radius);\n  font-family: var(--jp-code-font-family);\n  white-space: pre-wrap;\n  word-break: break-word;\n  margin-top: 6px;\n}\n\n.ai-agent-tool-call-result.completed {\n  color: var(--jp-success-color1);\n}\n\n.ai-agent-tool-call-result.error {\n  color: var(--jp-error-color1);\n}\n\n/* Tool confirmation dialog */\n.ai-agent-tool-confirm {\n  margin-bottom: 12px;\n  padding: 12px;\n  border-radius: var(--jp-border-radius);\n  max-width: 95%;\n  box-shadow: var(--jp-elevation-z2);\n  border-left: 4px solid;\n}\n\n.ai-agent-tool-confirm-details {\n  font-size: var(--jp-ui-font-size0);\n  color: var(--jp-ui-font-color1);\n  margin-bottom: 10px;\n  padding: 8px;\n  background: rgb(0 0 0 / 8%);\n  border-radius: 4px;\n}\n\n/* Confirmation colors by safety level */\n.ai-agent-tool-confirm.confirm-read {\n  background: rgb(76 175 80 / 15%);\n  border-color: var(--jp-success-color1);\n  color: var(--jp-ui-font-color1);\n}\n\n.ai-agent-tool-confirm.confirm-write {\n  background: rgb(255 152 0 / 15%);\n  border-color: var(--jp-warn-color1);\n  color: var(--jp-ui-font-color1);\n}\n\n.ai-agent-tool-confirm.confirm-execute {\n  background: rgb(245 124 0 / 15%);\n  border-color: var(--jp-warn-color0);\n  color: var(--jp-ui-font-color1);\n}\n\n.ai-agent-tool-confirm.confirm-system {\n  background: rgb(244 67 54 / 15%);\n  border-color: var(--jp-error-color1);\n  color: var(--jp-ui-font-color1);\n}\n\n.ai-agent-tool-confirm.confirm-read .ai-agent-tool-confirm-details,\n.ai-agent-tool-confirm.confirm-write .ai-agent-tool-confirm-details,\n.ai-agent-tool-confirm.confirm-execute .ai-agent-tool-confirm-details,\n.ai-agent-tool-confirm.confirm-system .ai-agent-tool-confirm-details {\n  background: rgb(0 0 0 / 8%);\n}\n\n.ai-agent-tool-confirm-text {\n  margin-bottom: 10px;\n  font-size: var(--jp-ui-font-size0);\n  line-height: 1.4;\n}\n\n.ai-agent-tool-confirm-text strong {\n  color: var(--jp-ui-font-color0);\n}\n\n.ai-agent-tool-confirm-buttons {\n  display: flex;\n  gap: 8px;\n}\n\n.ai-agent-tool-confirm-buttons button {\n  padding: 6px 12px;\n  border: none;\n  border-radius: var(--jp-border-radius);\n  cursor: pointer;\n  font-size: var(--jp-ui-font-size0);\n  transition: background 0.2s;\n}\n\n.ai-agent-tool-confirm-buttons .jp-mod-accept {\n  background: var(--jp-success-color1);\n  color: var(--jp-ui-inverse-font-color1);\n}\n\n.ai-agent-tool-confirm-buttons .jp-mod-accept:hover {\n  background: var(--jp-success-color0);\n}\n\n.ai-agent-tool-confirm-buttons .jp-mod-reject {\n  background: var(--jp-layout-color3);\n  color: var(--jp-content-font-color1);\n}\n\n.ai-agent-tool-confirm-buttons .jp-mod-reject:hover {\n  background: var(--jp-layout-color4);\n}\n\n/* Safety badge */\n.ai-agent-safety-badge {\n  display: inline-block;\n  padding: 2px 8px;\n  border-radius: 4px;\n  font-size: 11px;\n  font-weight: 600;\n  margin-right: 8px;\n  background: var(--jp-layout-color3);\n  color: var(--jp-ui-font-color1);\n}\n\n/* Show more button */\n.ai-agent-show-more {\n  background: none;\n  border: none;\n  color: var(--jp-brand-color1);\n  cursor: pointer;\n  font-size: var(--jp-ui-font-size0);\n  padding: 4px 0;\n  margin-top: 4px;\n}\n\n.ai-agent-show-more:hover {\n  text-decoration: underline;\n}\n\n/* ─────────────────────────────────────────────\n   Images & Output\n   ───────────────────────────────────────────── */\n\n.ai-agent-output-image {\n  max-width: 100%;\n  max-height: 400px;\n  border-radius: 4px;\n  margin-top: 8px;\n  border: 1px solid var(--jp-border-color1);\n  display: block;\n}\n\n.ai-agent-output-text {\n  margin: 4px 0;\n  padding: 4px 8px;\n  font-size: 12px;\n  font-family: var(--jp-code-font-family);\n  white-space: pre-wrap;\n  word-break: break-word;\n  max-height: 200px;\n  overflow-y: auto;\n  background: var(--jp-layout-color0);\n  border-radius: var(--jp-border-radius);\n}\n\n/* Image Analysis Suggestion */\n.ai-agent-image-suggestion {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  margin-top: 10px;\n  padding: 8px 12px;\n  background: linear-gradient(\n    135deg,\n    rgb(33 150 243 / 10%),\n    rgb(33 150 243 / 5%)\n  );\n  border: 1px dashed var(--jp-brand-color1);\n  border-radius: var(--jp-border-radius);\n}\n\n.ai-agent-suggestion-text {\n  flex: 1;\n  font-size: var(--jp-ui-font-size0);\n  color: var(--jp-content-font-color2);\n}\n\n.ai-agent-suggestion-btn {\n  padding: 4px 12px;\n  background: var(--jp-brand-color1);\n  color: var(--jp-ui-inverse-font-color1);\n  border: none;\n  border-radius: var(--jp-border-radius);\n  cursor: pointer;\n  font-size: var(--jp-ui-font-size0);\n  font-weight: 500;\n  transition: background 0.2s;\n}\n\n.ai-agent-suggestion-btn:hover {\n  background: var(--jp-brand-color0);\n}\n\n/* ─────────────────────────────────────────────\n   Scrollbar\n   ───────────────────────────────────────────── */\n\n.ai-agent-messages::-webkit-scrollbar {\n  width: 10px;\n}\n\n.ai-agent-messages::-webkit-scrollbar-track {\n  background: var(--jp-scrollbar-background-color);\n}\n\n.ai-agent-messages::-webkit-scrollbar-thumb {\n  background: rgb(var(--jp-scrollbar-thumb-color));\n  border-radius: var(--jp-scrollbar-thumb-radius);\n  margin: var(--jp-scrollbar-thumb-margin);\n}\n\n.ai-agent-messages::-webkit-scrollbar-thumb:hover {\n  background: rgb(100 108 109);\n}\n\n/* ─────────────────────────────────────────────\n   Resize Handle\n   ───────────────────────────────────────────── */\n\n.ai-agent-resize-handle {\n  display: none;\n}\n\n.ai-agent-resize-handle:hover {\n  background: var(--jp-brand-color1);\n}\n\n/* ─────────────────────────────────────────────\n   Token Counter & Status Bar\n   ───────────────────────────────────────────── */\n\n.ai-agent-status-bar {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 4px 10px;\n  font-size: 11px;\n  color: var(--jp-ui-font-color3);\n}\n\n/* Ask mode checkbox */\n.ai-agent-ask-mode {\n  display: flex;\n  align-items: center;\n  gap: 4px;\n  cursor: pointer;\n  user-select: none;\n  color: var(--jp-ui-font-color3);\n  transition: color 0.2s;\n}\n\n.ai-agent-ask-mode:hover {\n  color: var(--jp-content-font-color1);\n}\n\n.ai-agent-ask-mode input[type='checkbox'] {\n  margin: 0;\n  cursor: pointer;\n  width: 14px;\n  height: 14px;\n  accent-color: var(--jp-success-color1);\n}\n\n.ai-agent-ask-mode span {\n  font-size: 11px;\n}\n\n.ai-agent-token-counter {\n  cursor: help;\n  user-select: none;\n}\n\n.ai-agent-token-counter.warning {\n  color: var(--jp-warn-color1);\n  font-weight: 600;\n}\n\n/* ─────────────────────────────────────────────\n   History & Memory Panels (unified with Settings)\n   ───────────────────────────────────────────── */\n\n.ai-agent-history-actions {\n  display: flex;\n  gap: 8px;\n  flex-wrap: wrap;\n  padding: 16px 20px;\n  border-bottom: 1px solid var(--jp-border-color2);\n  background: var(--jp-layout-color2);\n}\n\n.ai-agent-history-action-btn {\n  flex: 1;\n  min-width: 100px;\n  padding: 8px 16px;\n  background: var(--jp-layout-color1);\n  border: 1px solid var(--jp-border-color2);\n  border-radius: var(--jp-border-radius);\n  cursor: pointer;\n  font-size: var(--jp-ui-font-size1);\n  color: var(--jp-content-font-color1);\n  transition:\n    background 0.2s,\n    border-color 0.2s;\n}\n\n.ai-agent-history-action-btn:hover {\n  background: var(--jp-brand-color2);\n  color: var(--jp-ui-inverse-font-color1);\n  border-color: var(--jp-brand-color1);\n}\n\n/* History/Memory list */\n.ai-agent-history-list {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n  padding: 16px 20px;\n  overflow-y: auto;\n  flex: 1;\n}\n\n.ai-agent-history-item {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 10px 12px;\n  background: var(--jp-layout-color2);\n  border-radius: var(--jp-border-radius);\n  cursor: pointer;\n  transition:\n    background 0.2s,\n    border-color 0.2s;\n  border: 1px solid var(--jp-border-color2);\n  color: var(--jp-content-font-color1);\n}\n\n.ai-agent-history-item:hover {\n  background: var(--jp-layout-color3);\n  border-color: var(--jp-border-color1);\n}\n\n.ai-agent-history-item.active {\n  border-left: 3px solid var(--jp-brand-color1);\n  background: var(--jp-layout-color3);\n}\n\n.ai-agent-history-item-main {\n  display: flex;\n  flex-direction: column;\n  gap: 2px;\n  flex: 1;\n  min-width: 0;\n}\n\n.ai-agent-history-item-title {\n  font-weight: 500;\n  font-size: var(--jp-ui-font-size1);\n  white-space: nowrap;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  color: var(--jp-content-font-color1);\n}\n\n.ai-agent-history-item-date {\n  font-size: 10px;\n  color: var(--jp-ui-font-color3);\n}\n\n.ai-agent-history-item-meta {\n  font-size: var(--jp-ui-font-size0);\n  color: var(--jp-content-font-color2);\n  margin-top: 4px;\n}\n\n.ai-agent-history-item-meta span {\n  display: block;\n  overflow: hidden;\n  text-overflow: ellipsis;\n  white-space: nowrap;\n}\n\n.ai-agent-history-item-actions {\n  display: flex;\n  gap: 4px;\n  margin-left: 8px;\n}\n\n.ai-agent-history-item-btn {\n  background: var(--jp-layout-color1);\n  border: 1px solid var(--jp-border-color2);\n  cursor: pointer;\n  font-size: 14px;\n  padding: 4px 8px;\n  border-radius: var(--jp-border-radius);\n  opacity: 0.8;\n  transition:\n    opacity 0.2s,\n    background 0.2s;\n  color: var(--jp-content-font-color1);\n}\n\n.ai-agent-history-item-btn:hover {\n  opacity: 1;\n  background: var(--jp-layout-color3);\n  border-color: var(--jp-border-color1);\n}\n\n.ai-agent-history-item-delete {\n  background: transparent;\n  border: none;\n  cursor: pointer;\n  font-size: 14px;\n  padding: 4px;\n  border-radius: var(--jp-border-radius);\n  opacity: 0.6;\n  transition: opacity 0.2s;\n}\n\n.ai-agent-history-item-delete:hover {\n  opacity: 1;\n  background: var(--jp-error-color3);\n}\n\n.ai-agent-history-empty,\n.ai-agent-history-error,\n.ai-agent-history-loading {\n  text-align: center;\n  padding: 40px 20px;\n  color: var(--jp-ui-font-color3);\n  font-size: var(--jp-ui-font-size1);\n}\n\n.ai-agent-history-error {\n  color: var(--jp-error-color1);\n}\n\n.ai-agent-history-loading {\n  font-style: italic;\n}\n\n/* ─────────────────────────────────────────────\n   Notifications\n   ───────────────────────────────────────────── */\n\n.ai-agent-header-btn {\n  background: transparent;\n  border: none;\n  cursor: pointer;\n  font-size: 18px;\n  padding: 4px 8px;\n  border-radius: 4px;\n  transition: background 0.2s;\n  color: var(--jp-content-font-color1);\n}\n\n.ai-agent-header-btn:hover {\n  background: var(--jp-layout-color2);\n}\n\n.ai-agent-notification {\n  position: absolute;\n  bottom: 70px;\n  left: 50%;\n  transform: translateX(-50%);\n  padding: 10px 16px;\n  border-radius: 6px;\n  font-size: var(--jp-ui-font-size0);\n  font-weight: 500;\n  box-shadow: var(--jp-elevation-z4);\n  z-index: 1001;\n  animation: ai-agent-notification-slide-in 0.3s ease;\n  max-width: 80%;\n  text-align: center;\n}\n\n.ai-agent-notification-hide {\n  animation: ai-agent-notification-slide-out 0.3s ease forwards;\n}\n\n@keyframes ai-agent-notification-slide-in {\n  from {\n    opacity: 0;\n    transform: translateX(-50%) translateY(10px);\n  }\n\n  to {\n    opacity: 1;\n    transform: translateX(-50%) translateY(0);\n  }\n}\n\n@keyframes ai-agent-notification-slide-out {\n  from {\n    opacity: 1;\n    transform: translateX(-50%) translateY(0);\n  }\n\n  to {\n    opacity: 0;\n    transform: translateX(-50%) translateY(10px);\n  }\n}\n\n@keyframes ai-agent-notification-slide-out {\n  from {\n    opacity: 1;\n    transform: translateX(-50%) translateY(0);\n  }\n\n  to {\n    opacity: 0;\n    transform: translateX(-50%) translateY(10px);\n  }\n}\n\n.ai-agent-notification-success {\n  background: var(--jp-success-color1);\n  color: var(--jp-ui-inverse-font-color1);\n}\n\n.ai-agent-notification-error {\n  background: var(--jp-error-color1);\n  color: var(--jp-ui-inverse-font-color1);\n}\n\n.ai-agent-notification-info {\n  background: var(--jp-brand-color1);\n  color: var(--jp-ui-inverse-font-color1);\n}\n\n/* ─────────────────────────────────────────────\n   Context Warning\n   ───────────────────────────────────────────── */\n\n.ai-agent-context-warning {\n  background: var(--jp-warn-color3);\n  border: 1px solid var(--jp-warn-color1);\n  border-radius: 6px;\n  padding: 8px 12px;\n  margin: 8px;\n  font-size: 12px;\n  color: var(--jp-warn-color0);\n  display: flex;\n  align-items: center;\n  gap: 8px;\n  flex-wrap: wrap;\n}\n\n.ai-agent-new-chat-btn {\n  padding: 4px 12px;\n  background: var(--jp-warn-color1);\n  color: var(--jp-ui-inverse-font-color1);\n  border: none;\n  border-radius: 4px;\n  cursor: pointer;\n  font-size: 12px;\n  white-space: nowrap;\n}\n\n.ai-agent-new-chat-btn:hover {\n  background: var(--jp-warn-color0);\n}\n\n/* ─────────────────────────────────────────────\n   Utility Classes\n   ───────────────────────────────────────────── */\n\n.ai-agent-hidden {\n  display: none !important;\n}\n\n.ai-agent-buttons {\n  display: flex;\n  flex-direction: column;\n  gap: 4px;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ "./node_modules/css-loader/dist/cjs.js!./style/index.css"
/*!***************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/index.css ***!
  \***************************************************************/
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! -!../node_modules/css-loader/dist/cjs.js!./base.css */ "./node_modules/css-loader/dist/cjs.js!./style/base.css");
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_settings_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! -!../node_modules/css-loader/dist/cjs.js!./settings.css */ "./node_modules/css-loader/dist/cjs.js!./style/settings.css");
// Imports




var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_2__["default"]);
___CSS_LOADER_EXPORT___.i(_node_modules_css_loader_dist_cjs_js_settings_css__WEBPACK_IMPORTED_MODULE_3__["default"]);
// Module
___CSS_LOADER_EXPORT___.push([module.id, `
`, "",{"version":3,"sources":[],"names":[],"mappings":"","sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ "./node_modules/css-loader/dist/cjs.js!./style/settings.css"
/*!******************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/settings.css ***!
  \******************************************************************/
(module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/sourceMaps.js */ "./node_modules/css-loader/dist/runtime/sourceMaps.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
// Imports


var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_sourceMaps_js__WEBPACK_IMPORTED_MODULE_0___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, `/* -----------------------------------------------------------------------------
 | Settings Styles for AI Agent — uses JupyterLab CSS variables exclusively
 |----------------------------------------------------------------------------- */

/* Settings panel (embedded in chat panel) */
.ai-agent-settings-panel {
  position: absolute;
  inset: 0;
  background: var(--jp-layout-color1);
  display: flex;
  flex-direction: column;
  z-index: 100;
  overflow: hidden;
}

.ai-agent-settings-panel.ai-agent-hidden {
  display: none;
}

/* Settings dialog overlay */
.ai-agent-settings-overlay {
  position: fixed;
  inset: 0;
  background: var(--jp-dialog-background);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 10000;
}

/* Settings dialog */
.ai-agent-settings-dialog {
  background: var(--jp-layout-color1);
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--jp-border-radius);
  box-shadow: var(--jp-elevation-z8);
  width: 90%;
  max-width: 600px;
  max-height: 85vh;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

/* Header */
.ai-agent-settings-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 16px 20px;
  border-bottom: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color2);
}

.ai-agent-settings-header h3 {
  margin: 0;
  font-size: var(--jp-content-font-size2);
  font-weight: var(--jp-content-heading-font-weight);
  color: var(--jp-content-font-color1);
}

.ai-agent-settings-close {
  background: transparent;
  border: none;
  font-size: 20px;
  cursor: pointer;
  color: var(--jp-content-font-color2);
  padding: 0;
  width: 30px;
  height: 30px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: var(--jp-border-radius);
  transition: background-color 0.2s;
}

.ai-agent-settings-close:hover {
  background: var(--jp-layout-color3);
  color: var(--jp-content-font-color1);
}

/* Body */
.ai-agent-settings-body {
  padding: 20px;
  overflow-y: auto;
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 16px;
}

/* Footer */
.ai-agent-settings-footer {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 16px 20px;
  border-top: 1px solid var(--jp-border-color2);
  background: var(--jp-layout-color2);
}

/* Form sections */
.ai-agent-settings-section {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.ai-agent-settings-label {
  font-weight: 600;
  font-size: var(--jp-ui-font-size1);
  color: var(--jp-content-font-color1);
}

/* Input fields */
.ai-agent-settings-input,
.ai-agent-settings-select {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--jp-border-radius);
  background: var(--jp-layout-color0);
  color: var(--jp-content-font-color1);
  font-size: var(--jp-ui-font-size1);
  font-family: var(--jp-ui-font-family);
  box-sizing: border-box;
  transition: all 0.15s ease;
}

.ai-agent-settings-select {
  cursor: pointer;
}

.ai-agent-settings-input:focus,
.ai-agent-settings-select:focus {
  outline: none;
  border-color: var(--jp-brand-color1);
  box-shadow: 0 0 0 2px rgb(33 150 243 / 25%);
}

/* Textarea */
.ai-agent-settings-textarea {
  width: 100%;
  padding: 8px 12px;
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--jp-border-radius);
  background: var(--jp-layout-color0);
  color: var(--jp-content-font-color1);
  font-size: var(--jp-ui-font-size1);
  font-family: var(--jp-content-font-family);
  box-sizing: border-box;
  transition: all 0.15s ease;
  resize: vertical;
  min-height: 80px;
}

.ai-agent-settings-textarea:focus {
  outline: none;
  border-color: var(--jp-brand-color1);
  box-shadow: 0 0 0 2px rgb(33 150 243 / 25%);
}

.ai-agent-settings-textarea::placeholder {
  color: var(--jp-ui-font-color3);
}

/* Row layout */
.ai-agent-settings-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.ai-agent-settings-row .ai-agent-settings-input {
  flex: 1;
}

/* Toggle key button */
.ai-agent-settings-toggle-key {
  background: var(--jp-layout-color2);
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--jp-border-radius);
  padding: 8px 12px;
  cursor: pointer;
  font-size: var(--jp-ui-font-size1);
  color: var(--jp-content-font-color1);
  transition: background-color 0.2s;
  white-space: nowrap;
}

.ai-agent-settings-toggle-key:hover {
  background: var(--jp-layout-color3);
  border-color: var(--jp-brand-color1);
}

/* Slider */
.ai-agent-settings-slider {
  flex: 1;
  height: 6px;
  border-radius: 3px;
  background: var(--jp-layout-color3);
  outline: none;
  -webkit-appearance: none;
}

.ai-agent-settings-slider::-webkit-slider-thumb {
  -webkit-appearance: none;
  appearance: none;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: var(--jp-brand-color1);
  cursor: pointer;
  border: 2px solid var(--jp-layout-color1);
  transition: background-color 0.2s;
}

.ai-agent-settings-slider::-webkit-slider-thumb:hover {
  background: var(--jp-brand-color2);
}

.ai-agent-settings-slider::-moz-range-thumb {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background: var(--jp-brand-color1);
  cursor: pointer;
  border: 2px solid var(--jp-layout-color1);
  transition: background-color 0.2s;
}

.ai-agent-settings-slider::-moz-range-thumb:hover {
  background: var(--jp-brand-color2);
}

.ai-agent-settings-slider-value {
  min-width: 40px;
  text-align: center;
  font-weight: 600;
  color: var(--jp-brand-color1);
  font-size: var(--jp-ui-font-size1);
}

/* Spacer */
.ai-agent-settings-spacer {
  flex: 1;
}

/* Buttons */
.ai-agent-settings-footer button {
  padding: 8px 16px;
  border-radius: var(--jp-border-radius);
  font-size: var(--jp-ui-font-size1);
  cursor: pointer;
  transition: background-color 0.2s;
  border: 1px solid var(--jp-border-color2);
}

.ai-agent-settings-test {
  background: var(--jp-layout-color2);
  color: var(--jp-content-font-color1);
}

.ai-agent-settings-test:hover {
  background: var(--jp-layout-color3);
}

.ai-agent-settings-cancel {
  background: transparent;
  color: var(--jp-content-font-color2);
}

.ai-agent-settings-cancel:hover {
  background: var(--jp-layout-color2);
  color: var(--jp-content-font-color1);
}

.ai-agent-settings-save {
  background: var(--jp-brand-color1);
  color: var(--jp-ui-inverse-font-color1);
  border-color: var(--jp-brand-color1);
}

.ai-agent-settings-save:hover {
  background: var(--jp-brand-color2);
}

/* Test status */
.ai-agent-settings-test-status {
  padding: 12px;
  border-radius: var(--jp-border-radius);
  font-size: var(--jp-ui-font-size1);
  display: none;
}

.ai-agent-settings-test-status.testing,
.ai-agent-settings-test-status.success,
.ai-agent-settings-test-status.error {
  display: block;
}

.ai-agent-settings-test-status.testing {
  background: var(--jp-info-color1);
  color: var(--jp-ui-inverse-font-color1);
}

.ai-agent-settings-test-status.success {
  background: var(--jp-success-color1);
  color: var(--jp-ui-inverse-font-color1);
}

.ai-agent-settings-test-status.error {
  background: var(--jp-error-color1);
  color: var(--jp-ui-inverse-font-color1);
}

/* Error & Loading states */
.ai-agent-settings-error {
  color: var(--jp-error-color1);
  font-weight: 600;
  padding: 20px;
  text-align: center;
}

.ai-agent-settings-loading {
  color: var(--jp-content-font-color2);
  font-style: italic;
  padding: 20px;
  text-align: center;
}

/* Profile selector row */
.ai-agent-settings-profile-row {
  display: flex;
  align-items: center;
  gap: 8px;
}

.ai-agent-settings-profile-row .ai-agent-settings-select {
  flex: 1;
}

.ai-agent-settings-profile-btn {
  background: var(--jp-layout-color2);
  border: 1px solid var(--jp-border-color2);
  border-radius: var(--jp-border-radius);
  padding: 6px 10px;
  cursor: pointer;
  font-size: var(--jp-ui-font-size1);
  color: var(--jp-content-font-color1);
  transition: background-color 0.2s;
  min-width: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.ai-agent-settings-profile-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.ai-agent-settings-profile-btn:hover:not(:disabled) {
  background: var(--jp-layout-color3);
  border-color: var(--jp-brand-color1);
}
`, "",{"version":3,"sources":["webpack://./style/settings.css"],"names":[],"mappings":"AAAA;;iFAEiF;;AAEjF,4CAA4C;AAC5C;EACE,kBAAkB;EAClB,QAAQ;EACR,mCAAmC;EACnC,aAAa;EACb,sBAAsB;EACtB,YAAY;EACZ,gBAAgB;AAClB;;AAEA;EACE,aAAa;AACf;;AAEA,4BAA4B;AAC5B;EACE,eAAe;EACf,QAAQ;EACR,uCAAuC;EACvC,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,cAAc;AAChB;;AAEA,oBAAoB;AACpB;EACE,mCAAmC;EACnC,yCAAyC;EACzC,sCAAsC;EACtC,kCAAkC;EAClC,UAAU;EACV,gBAAgB;EAChB,gBAAgB;EAChB,gBAAgB;EAChB,aAAa;EACb,sBAAsB;AACxB;;AAEA,WAAW;AACX;EACE,aAAa;EACb,8BAA8B;EAC9B,mBAAmB;EACnB,kBAAkB;EAClB,gDAAgD;EAChD,mCAAmC;AACrC;;AAEA;EACE,SAAS;EACT,uCAAuC;EACvC,kDAAkD;EAClD,oCAAoC;AACtC;;AAEA;EACE,uBAAuB;EACvB,YAAY;EACZ,eAAe;EACf,eAAe;EACf,oCAAoC;EACpC,UAAU;EACV,WAAW;EACX,YAAY;EACZ,aAAa;EACb,mBAAmB;EACnB,uBAAuB;EACvB,sCAAsC;EACtC,iCAAiC;AACnC;;AAEA;EACE,mCAAmC;EACnC,oCAAoC;AACtC;;AAEA,SAAS;AACT;EACE,aAAa;EACb,gBAAgB;EAChB,OAAO;EACP,aAAa;EACb,sBAAsB;EACtB,SAAS;AACX;;AAEA,WAAW;AACX;EACE,aAAa;EACb,mBAAmB;EACnB,SAAS;EACT,kBAAkB;EAClB,6CAA6C;EAC7C,mCAAmC;AACrC;;AAEA,kBAAkB;AAClB;EACE,aAAa;EACb,sBAAsB;EACtB,QAAQ;AACV;;AAEA;EACE,gBAAgB;EAChB,kCAAkC;EAClC,oCAAoC;AACtC;;AAEA,iBAAiB;AACjB;;EAEE,WAAW;EACX,iBAAiB;EACjB,yCAAyC;EACzC,sCAAsC;EACtC,mCAAmC;EACnC,oCAAoC;EACpC,kCAAkC;EAClC,qCAAqC;EACrC,sBAAsB;EACtB,0BAA0B;AAC5B;;AAEA;EACE,eAAe;AACjB;;AAEA;;EAEE,aAAa;EACb,oCAAoC;EACpC,2CAA2C;AAC7C;;AAEA,aAAa;AACb;EACE,WAAW;EACX,iBAAiB;EACjB,yCAAyC;EACzC,sCAAsC;EACtC,mCAAmC;EACnC,oCAAoC;EACpC,kCAAkC;EAClC,0CAA0C;EAC1C,sBAAsB;EACtB,0BAA0B;EAC1B,gBAAgB;EAChB,gBAAgB;AAClB;;AAEA;EACE,aAAa;EACb,oCAAoC;EACpC,2CAA2C;AAC7C;;AAEA;EACE,+BAA+B;AACjC;;AAEA,eAAe;AACf;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;AACV;;AAEA;EACE,OAAO;AACT;;AAEA,sBAAsB;AACtB;EACE,mCAAmC;EACnC,yCAAyC;EACzC,sCAAsC;EACtC,iBAAiB;EACjB,eAAe;EACf,kCAAkC;EAClC,oCAAoC;EACpC,iCAAiC;EACjC,mBAAmB;AACrB;;AAEA;EACE,mCAAmC;EACnC,oCAAoC;AACtC;;AAEA,WAAW;AACX;EACE,OAAO;EACP,WAAW;EACX,kBAAkB;EAClB,mCAAmC;EACnC,aAAa;EACb,wBAAwB;AAC1B;;AAEA;EACE,wBAAwB;EACxB,gBAAgB;EAChB,WAAW;EACX,YAAY;EACZ,kBAAkB;EAClB,kCAAkC;EAClC,eAAe;EACf,yCAAyC;EACzC,iCAAiC;AACnC;;AAEA;EACE,kCAAkC;AACpC;;AAEA;EACE,WAAW;EACX,YAAY;EACZ,kBAAkB;EAClB,kCAAkC;EAClC,eAAe;EACf,yCAAyC;EACzC,iCAAiC;AACnC;;AAEA;EACE,kCAAkC;AACpC;;AAEA;EACE,eAAe;EACf,kBAAkB;EAClB,gBAAgB;EAChB,6BAA6B;EAC7B,kCAAkC;AACpC;;AAEA,WAAW;AACX;EACE,OAAO;AACT;;AAEA,YAAY;AACZ;EACE,iBAAiB;EACjB,sCAAsC;EACtC,kCAAkC;EAClC,eAAe;EACf,iCAAiC;EACjC,yCAAyC;AAC3C;;AAEA;EACE,mCAAmC;EACnC,oCAAoC;AACtC;;AAEA;EACE,mCAAmC;AACrC;;AAEA;EACE,uBAAuB;EACvB,oCAAoC;AACtC;;AAEA;EACE,mCAAmC;EACnC,oCAAoC;AACtC;;AAEA;EACE,kCAAkC;EAClC,uCAAuC;EACvC,oCAAoC;AACtC;;AAEA;EACE,kCAAkC;AACpC;;AAEA,gBAAgB;AAChB;EACE,aAAa;EACb,sCAAsC;EACtC,kCAAkC;EAClC,aAAa;AACf;;AAEA;;;EAGE,cAAc;AAChB;;AAEA;EACE,iCAAiC;EACjC,uCAAuC;AACzC;;AAEA;EACE,oCAAoC;EACpC,uCAAuC;AACzC;;AAEA;EACE,kCAAkC;EAClC,uCAAuC;AACzC;;AAEA,2BAA2B;AAC3B;EACE,6BAA6B;EAC7B,gBAAgB;EAChB,aAAa;EACb,kBAAkB;AACpB;;AAEA;EACE,oCAAoC;EACpC,kBAAkB;EAClB,aAAa;EACb,kBAAkB;AACpB;;AAEA,yBAAyB;AACzB;EACE,aAAa;EACb,mBAAmB;EACnB,QAAQ;AACV;;AAEA;EACE,OAAO;AACT;;AAEA;EACE,mCAAmC;EACnC,yCAAyC;EACzC,sCAAsC;EACtC,iBAAiB;EACjB,eAAe;EACf,kCAAkC;EAClC,oCAAoC;EACpC,iCAAiC;EACjC,eAAe;EACf,aAAa;EACb,mBAAmB;EACnB,uBAAuB;AACzB;;AAEA;EACE,YAAY;EACZ,mBAAmB;AACrB;;AAEA;EACE,mCAAmC;EACnC,oCAAoC;AACtC","sourcesContent":["/* -----------------------------------------------------------------------------\n | Settings Styles for AI Agent — uses JupyterLab CSS variables exclusively\n |----------------------------------------------------------------------------- */\n\n/* Settings panel (embedded in chat panel) */\n.ai-agent-settings-panel {\n  position: absolute;\n  inset: 0;\n  background: var(--jp-layout-color1);\n  display: flex;\n  flex-direction: column;\n  z-index: 100;\n  overflow: hidden;\n}\n\n.ai-agent-settings-panel.ai-agent-hidden {\n  display: none;\n}\n\n/* Settings dialog overlay */\n.ai-agent-settings-overlay {\n  position: fixed;\n  inset: 0;\n  background: var(--jp-dialog-background);\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  z-index: 10000;\n}\n\n/* Settings dialog */\n.ai-agent-settings-dialog {\n  background: var(--jp-layout-color1);\n  border: 1px solid var(--jp-border-color2);\n  border-radius: var(--jp-border-radius);\n  box-shadow: var(--jp-elevation-z8);\n  width: 90%;\n  max-width: 600px;\n  max-height: 85vh;\n  overflow: hidden;\n  display: flex;\n  flex-direction: column;\n}\n\n/* Header */\n.ai-agent-settings-header {\n  display: flex;\n  justify-content: space-between;\n  align-items: center;\n  padding: 16px 20px;\n  border-bottom: 1px solid var(--jp-border-color2);\n  background: var(--jp-layout-color2);\n}\n\n.ai-agent-settings-header h3 {\n  margin: 0;\n  font-size: var(--jp-content-font-size2);\n  font-weight: var(--jp-content-heading-font-weight);\n  color: var(--jp-content-font-color1);\n}\n\n.ai-agent-settings-close {\n  background: transparent;\n  border: none;\n  font-size: 20px;\n  cursor: pointer;\n  color: var(--jp-content-font-color2);\n  padding: 0;\n  width: 30px;\n  height: 30px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  border-radius: var(--jp-border-radius);\n  transition: background-color 0.2s;\n}\n\n.ai-agent-settings-close:hover {\n  background: var(--jp-layout-color3);\n  color: var(--jp-content-font-color1);\n}\n\n/* Body */\n.ai-agent-settings-body {\n  padding: 20px;\n  overflow-y: auto;\n  flex: 1;\n  display: flex;\n  flex-direction: column;\n  gap: 16px;\n}\n\n/* Footer */\n.ai-agent-settings-footer {\n  display: flex;\n  align-items: center;\n  gap: 10px;\n  padding: 16px 20px;\n  border-top: 1px solid var(--jp-border-color2);\n  background: var(--jp-layout-color2);\n}\n\n/* Form sections */\n.ai-agent-settings-section {\n  display: flex;\n  flex-direction: column;\n  gap: 8px;\n}\n\n.ai-agent-settings-label {\n  font-weight: 600;\n  font-size: var(--jp-ui-font-size1);\n  color: var(--jp-content-font-color1);\n}\n\n/* Input fields */\n.ai-agent-settings-input,\n.ai-agent-settings-select {\n  width: 100%;\n  padding: 8px 12px;\n  border: 1px solid var(--jp-border-color2);\n  border-radius: var(--jp-border-radius);\n  background: var(--jp-layout-color0);\n  color: var(--jp-content-font-color1);\n  font-size: var(--jp-ui-font-size1);\n  font-family: var(--jp-ui-font-family);\n  box-sizing: border-box;\n  transition: all 0.15s ease;\n}\n\n.ai-agent-settings-select {\n  cursor: pointer;\n}\n\n.ai-agent-settings-input:focus,\n.ai-agent-settings-select:focus {\n  outline: none;\n  border-color: var(--jp-brand-color1);\n  box-shadow: 0 0 0 2px rgb(33 150 243 / 25%);\n}\n\n/* Textarea */\n.ai-agent-settings-textarea {\n  width: 100%;\n  padding: 8px 12px;\n  border: 1px solid var(--jp-border-color2);\n  border-radius: var(--jp-border-radius);\n  background: var(--jp-layout-color0);\n  color: var(--jp-content-font-color1);\n  font-size: var(--jp-ui-font-size1);\n  font-family: var(--jp-content-font-family);\n  box-sizing: border-box;\n  transition: all 0.15s ease;\n  resize: vertical;\n  min-height: 80px;\n}\n\n.ai-agent-settings-textarea:focus {\n  outline: none;\n  border-color: var(--jp-brand-color1);\n  box-shadow: 0 0 0 2px rgb(33 150 243 / 25%);\n}\n\n.ai-agent-settings-textarea::placeholder {\n  color: var(--jp-ui-font-color3);\n}\n\n/* Row layout */\n.ai-agent-settings-row {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n\n.ai-agent-settings-row .ai-agent-settings-input {\n  flex: 1;\n}\n\n/* Toggle key button */\n.ai-agent-settings-toggle-key {\n  background: var(--jp-layout-color2);\n  border: 1px solid var(--jp-border-color2);\n  border-radius: var(--jp-border-radius);\n  padding: 8px 12px;\n  cursor: pointer;\n  font-size: var(--jp-ui-font-size1);\n  color: var(--jp-content-font-color1);\n  transition: background-color 0.2s;\n  white-space: nowrap;\n}\n\n.ai-agent-settings-toggle-key:hover {\n  background: var(--jp-layout-color3);\n  border-color: var(--jp-brand-color1);\n}\n\n/* Slider */\n.ai-agent-settings-slider {\n  flex: 1;\n  height: 6px;\n  border-radius: 3px;\n  background: var(--jp-layout-color3);\n  outline: none;\n  -webkit-appearance: none;\n}\n\n.ai-agent-settings-slider::-webkit-slider-thumb {\n  -webkit-appearance: none;\n  appearance: none;\n  width: 18px;\n  height: 18px;\n  border-radius: 50%;\n  background: var(--jp-brand-color1);\n  cursor: pointer;\n  border: 2px solid var(--jp-layout-color1);\n  transition: background-color 0.2s;\n}\n\n.ai-agent-settings-slider::-webkit-slider-thumb:hover {\n  background: var(--jp-brand-color2);\n}\n\n.ai-agent-settings-slider::-moz-range-thumb {\n  width: 18px;\n  height: 18px;\n  border-radius: 50%;\n  background: var(--jp-brand-color1);\n  cursor: pointer;\n  border: 2px solid var(--jp-layout-color1);\n  transition: background-color 0.2s;\n}\n\n.ai-agent-settings-slider::-moz-range-thumb:hover {\n  background: var(--jp-brand-color2);\n}\n\n.ai-agent-settings-slider-value {\n  min-width: 40px;\n  text-align: center;\n  font-weight: 600;\n  color: var(--jp-brand-color1);\n  font-size: var(--jp-ui-font-size1);\n}\n\n/* Spacer */\n.ai-agent-settings-spacer {\n  flex: 1;\n}\n\n/* Buttons */\n.ai-agent-settings-footer button {\n  padding: 8px 16px;\n  border-radius: var(--jp-border-radius);\n  font-size: var(--jp-ui-font-size1);\n  cursor: pointer;\n  transition: background-color 0.2s;\n  border: 1px solid var(--jp-border-color2);\n}\n\n.ai-agent-settings-test {\n  background: var(--jp-layout-color2);\n  color: var(--jp-content-font-color1);\n}\n\n.ai-agent-settings-test:hover {\n  background: var(--jp-layout-color3);\n}\n\n.ai-agent-settings-cancel {\n  background: transparent;\n  color: var(--jp-content-font-color2);\n}\n\n.ai-agent-settings-cancel:hover {\n  background: var(--jp-layout-color2);\n  color: var(--jp-content-font-color1);\n}\n\n.ai-agent-settings-save {\n  background: var(--jp-brand-color1);\n  color: var(--jp-ui-inverse-font-color1);\n  border-color: var(--jp-brand-color1);\n}\n\n.ai-agent-settings-save:hover {\n  background: var(--jp-brand-color2);\n}\n\n/* Test status */\n.ai-agent-settings-test-status {\n  padding: 12px;\n  border-radius: var(--jp-border-radius);\n  font-size: var(--jp-ui-font-size1);\n  display: none;\n}\n\n.ai-agent-settings-test-status.testing,\n.ai-agent-settings-test-status.success,\n.ai-agent-settings-test-status.error {\n  display: block;\n}\n\n.ai-agent-settings-test-status.testing {\n  background: var(--jp-info-color1);\n  color: var(--jp-ui-inverse-font-color1);\n}\n\n.ai-agent-settings-test-status.success {\n  background: var(--jp-success-color1);\n  color: var(--jp-ui-inverse-font-color1);\n}\n\n.ai-agent-settings-test-status.error {\n  background: var(--jp-error-color1);\n  color: var(--jp-ui-inverse-font-color1);\n}\n\n/* Error & Loading states */\n.ai-agent-settings-error {\n  color: var(--jp-error-color1);\n  font-weight: 600;\n  padding: 20px;\n  text-align: center;\n}\n\n.ai-agent-settings-loading {\n  color: var(--jp-content-font-color2);\n  font-style: italic;\n  padding: 20px;\n  text-align: center;\n}\n\n/* Profile selector row */\n.ai-agent-settings-profile-row {\n  display: flex;\n  align-items: center;\n  gap: 8px;\n}\n\n.ai-agent-settings-profile-row .ai-agent-settings-select {\n  flex: 1;\n}\n\n.ai-agent-settings-profile-btn {\n  background: var(--jp-layout-color2);\n  border: 1px solid var(--jp-border-color2);\n  border-radius: var(--jp-border-radius);\n  padding: 6px 10px;\n  cursor: pointer;\n  font-size: var(--jp-ui-font-size1);\n  color: var(--jp-content-font-color1);\n  transition: background-color 0.2s;\n  min-width: 32px;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n}\n\n.ai-agent-settings-profile-btn:disabled {\n  opacity: 0.5;\n  cursor: not-allowed;\n}\n\n.ai-agent-settings-profile-btn:hover:not(:disabled) {\n  background: var(--jp-layout-color3);\n  border-color: var(--jp-brand-color1);\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ },

/***/ "./style/index.css"
/*!*************************!*\
  !*** ./style/index.css ***!
  \*************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleDomAPI.js */ "./node_modules/style-loader/dist/runtime/styleDomAPI.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertBySelector.js */ "./node_modules/style-loader/dist/runtime/insertBySelector.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js */ "./node_modules/style-loader/dist/runtime/setAttributesWithoutAttributes.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/insertStyleElement.js */ "./node_modules/style-loader/dist/runtime/insertStyleElement.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/styleTagTransform.js */ "./node_modules/style-loader/dist/runtime/styleTagTransform.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! !!../node_modules/css-loader/dist/cjs.js!./index.css */ "./node_modules/css-loader/dist/cjs.js!./style/index.css");

      
      
      
      
      
      
      
      
      

var options = {};

options.styleTagTransform = (_node_modules_style_loader_dist_runtime_styleTagTransform_js__WEBPACK_IMPORTED_MODULE_5___default());
options.setAttributes = (_node_modules_style_loader_dist_runtime_setAttributesWithoutAttributes_js__WEBPACK_IMPORTED_MODULE_3___default());

      options.insert = _node_modules_style_loader_dist_runtime_insertBySelector_js__WEBPACK_IMPORTED_MODULE_2___default().bind(null, "head");
    
options.domAPI = (_node_modules_style_loader_dist_runtime_styleDomAPI_js__WEBPACK_IMPORTED_MODULE_1___default());
options.insertStyleElement = (_node_modules_style_loader_dist_runtime_insertStyleElement_js__WEBPACK_IMPORTED_MODULE_4___default());

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_6__["default"], options);




       /* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_6__["default"] && _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals ? _node_modules_css_loader_dist_cjs_js_index_css__WEBPACK_IMPORTED_MODULE_6__["default"].locals : undefined);


/***/ }

}]);
//# sourceMappingURL=style_index_js.c77d1da66355d6c7154b.js.map