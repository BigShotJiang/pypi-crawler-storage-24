"""
VERL integration configuration.
"""

