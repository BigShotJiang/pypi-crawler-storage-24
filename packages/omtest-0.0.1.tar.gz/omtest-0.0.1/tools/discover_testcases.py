import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
import omtest

class Dummy(omtest.EmbeddedDevice):
    def connect(self):
        return True
    def disconnect(self):
        pass
    def execute_command(self, cmd, timeout=10, print_info=True):
        return ""

fw = omtest.EmbeddedTestFramework(Dummy())
omtest._discover_and_add_suites('testcases', fw.suites)
print('discovered suites:', [(s.suite_id, s.suite_name) for s in fw.suites])
