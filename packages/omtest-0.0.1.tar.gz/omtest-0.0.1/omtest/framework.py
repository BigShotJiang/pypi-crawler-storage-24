from typing import List, Dict, Any
from .utils import generate_rollback_commands, apply_rollback_commands


class SimpleTestResult:
    def __init__(self, case_id: str, case_name: str, success: bool, test_log: str = "", error_msg: str = "", skipped: bool = False):
        self.case_id = case_id
        self.case_name = case_name
        self.success = success
        self.test_log = test_log
        self.error_msg = error_msg
        self.skipped = bool(skipped)


class EmbeddedTestFramework:
    def __init__(self, device):
        self.device = device
        self.suites: List[TestSuite] = []

    def add_suite(self, suite):
        self.suites.append(suite)

    def run_all(self) -> Dict[str, Any]:
        all_results: Dict[str, Any] = {}
        for suite in self.suites:
            if hasattr(suite, 'run') and callable(getattr(suite, 'run')):
                try:
                    results = suite.run(self.device, self)
                except Exception as e:
                    results = {'error': str(e)}
                all_results[getattr(suite, 'suite_name', getattr(suite, 'name', str(suite)))] = results
                continue

            suite_name = getattr(suite, 'suite_name', getattr(suite, 'name', str(suite)))
            case_results = []
            for case in getattr(suite, 'test_cases', []):
                reqs = getattr(case.test_func, '_requires_capabilities', None) or getattr(case, 'requires', None)
                if reqs:
                    missing = [r for r in reqs if not self.device.has_capability(r)]
                    if missing:
                        msg = f"SKIPPED: missing capabilities: {missing}"
                        case_results.append(SimpleTestResult(case.case_id, case.case_name, False, "", msg, skipped=True))
                        continue
                try:
                    ok, log, err = case.test_func(self.device)
                except Exception as e:
                    ok, log, err = False, "", f"Exception: {e}"
                case_results.append(SimpleTestResult(case.case_id, case.case_name, ok, log, err))
            all_results[suite_name] = case_results
        return all_results

    def generate_rollback(self, before_cfg: str, after_cfg: str):
        return generate_rollback_commands(before_cfg, after_cfg)

    def apply_rollback(self, cmds: List[str]):
        apply_rollback_commands(self.device, cmds)
