from typing import Iterable


def requires_capabilities(*caps: str):
    """Decorator to mark a test function as requiring given capabilities.

    Example:
        @requires_capabilities('ftp', 'judge')
        def test_x(dev):
            ...
    """
    def _decorator(func):
        setattr(func, '_requires_capabilities', set(caps))
        return func
    return _decorator
