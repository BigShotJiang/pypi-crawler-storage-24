import argparse
import fnmatch
import json
import os
import sys
from typing import List

from .devices import TelnetDevice
from .framework import EmbeddedTestFramework
from .utils import _discover_and_add_suites


class DummyDevice(TelnetDevice):
    def __init__(self):
        super().__init__(host='127.0.0.1', port=23)
        self.capabilities = {'telnet', 'ftp', 'judge', 'local-user'}

    def connect(self) -> bool:
        self.log('DummyDevice: pretend connected')
        return True

    def disconnect(self):
        self.log('DummyDevice: pretend disconnected')

    def execute_command(self, cmd, timeout=10, print_info=True):
        self.log(f"DummyDevice: execute_command('{cmd}')")
        return ""

    def execute_command_expect(self, cmd, expect, timeout=10, max_retries=5):
        self.log(f"DummyDevice: execute_command_expect('{cmd}', '{expect}')")
        return True, ""


def parse_level_spec(spec: str) -> set:
    s = set()
    if not spec:
        return s
    parts = [p.strip() for p in spec.split(',') if p.strip()]
    for part in parts:
        if '-' in part:
            try:
                a, b = part.split('-', 1)
                a_i = int(a); b_i = int(b)
                rng = range(min(a_i, b_i), max(a_i, b_i) + 1)
                s.update(rng)
            except Exception:
                continue
        else:
            try:
                s.add(int(part))
            except Exception:
                continue
    return s


def cli_main(argv: List[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description='Run omtest test framework')
    parser.add_argument('--config', '-c', help='Path to config.json (default: ./config.json)')
    parser.add_argument('--host', help='Device host to connect to')
    parser.add_argument('--port', type=int, help='Device port')
    parser.add_argument('--username', help='Device login username')
    parser.add_argument('--password', help='Device login password')
    parser.add_argument('--prompt', help='Device prompt string')
    parser.add_argument('--login-prompt', dest='login_prompt', help='Login prompt to wait for')
    parser.add_argument('--passwd-prompt', dest='passwd_prompt', help='Password prompt to wait for')
    parser.add_argument('--dry-run', action='store_true', help='Use DummyDevice (no real network)')
    parser.add_argument('--filter', '-f', help='Filter case ids (comma-separated, supports * wildcard)')
    parser.add_argument('--level', help='Levels to run (e.g. 1-2,4). Default: 1', dest='levels')
    parser.add_argument('--cases-dir', help='Package name or directory path that contains testcases (default: testcases)', dest='cases_dir')
    parser.add_argument('--report', choices=['plain', 'json'], default='plain', help='Report format to output (plain or json)')
    parser.add_argument('--report-file', help='Write report to file (path). If omitted, prints to stdout.')
    args = parser.parse_args(argv)

    use_dry = args.dry_run or os.environ.get('HITEST_DRY_RUN') == '1'

    cfg_path = args.config if args.config else os.path.join(os.getcwd(), 'config.json')
    cfg = {}
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path, 'r', encoding='utf-8') as f:
                cfg = json.load(f)
        except Exception as e:
            print(f"Warning: failed to load config file {cfg_path}: {e}")

    device_cfg = cfg.get('device', {}) if isinstance(cfg, dict) else {}

    host = args.host or device_cfg.get('host')
    port = args.port if args.port is not None else int(device_cfg.get('port', 23))
    username = args.username or device_cfg.get('username')
    password = args.password or device_cfg.get('password')
    prompt = args.prompt or device_cfg.get('prompt')
    login_prompt = args.login_prompt or device_cfg.get('login_prompt')
    passwd_prompt = args.passwd_prompt or device_cfg.get('passwd_prompt')
    capability_checks = device_cfg.get('capability', {})

    if use_dry:
        device = DummyDevice()
        device.connect()
    else:
        if not host:
            print('Error: host required (or use --dry-run)')
            return 2
        device = TelnetDevice(host=host, port=port, username=username or '', password=password or '', prompt=prompt or '>', login_prompt=login_prompt or 'Username:', passwd_prompt=passwd_prompt or 'Password:', capability_checks=capability_checks)
        if not device.connect():
            return 3

    framework = EmbeddedTestFramework(device)
    cases_pkg = args.cases_dir if args.cases_dir else 'testcases'
    _discover_and_add_suites(cases_pkg, framework.suites)

    # apply filter if requested
    if args.filter:
        patterns = [p.strip() for p in args.filter.split(',') if p.strip()]
        device.log(f"Applying case filter: {patterns}")
        filtered_suites = []
        for suite in framework.suites:
            matched_cases = [c for c in getattr(suite, 'test_cases', []) if any(fnmatch.fnmatch(getattr(c, 'case_id', ''), pat) for pat in patterns)]
            if matched_cases:
                suite.test_cases = matched_cases
                filtered_suites.append(suite)
        framework.suites = filtered_suites
        if not filtered_suites:
            print(f"No test cases match filter: {patterns}")
            return 0

    # parse levels
    if args.levels:
        levels_to_run = parse_level_spec(args.levels)
    else:
        levels_to_run = {1}

    if levels_to_run:
        device.log(f"Filtering test cases by levels: {sorted(levels_to_run)}")
        new_suites = []
        for suite in framework.suites:
            matched_cases = [c for c in getattr(suite, 'test_cases', []) if getattr(c, 'level', 1) in levels_to_run]
            if matched_cases:
                suite.test_cases = matched_cases
                new_suites.append(suite)
        framework.suites = new_suites
        if not new_suites:
            print(f"No test cases match level(s): {sorted(levels_to_run)}")
            return 0

    results = framework.run_all()

    # format report
    if args.report == 'json':
        import json as _json
        serializable = {}
        for suite_name, suite_res in results.items():
            if isinstance(suite_res, list):
                serializable[suite_name] = [
                    {
                        'case_id': getattr(r, 'case_id', ''),
                        'case_name': getattr(r, 'case_name', ''),
                        'success': getattr(r, 'success', False),
                        'error_msg': getattr(r, 'error_msg', ''),
                        'test_log': getattr(r, 'test_log', ''),
                        'skipped': getattr(r, 'skipped', False)
                    }
                    for r in suite_res
                ]
            else:
                serializable[suite_name] = suite_res
        out_text = _json.dumps(serializable, ensure_ascii=False, indent=2)
    else:
        lines = ['Test results:']
        for suite_name, suite_res in results.items():
            lines.append(f"- Suite: {suite_name}")
            if isinstance(suite_res, list):
                for r in suite_res:
                    if getattr(r, 'skipped', False):
                        status = 'SKIP'
                    else:
                        status = 'PASS' if getattr(r, 'success', False) else 'FAIL'
                    lines.append(f"    [{status}] {getattr(r, 'case_id', '')} - {getattr(r, 'case_name', '')}")
            else:
                lines.append(f"    {suite_res}")
        out_text = "\n".join(lines)

    if args.report_file:
        try:
            with open(args.report_file, 'w', encoding='utf-8') as f:
                f.write(out_text)
            print(f"Wrote report to {args.report_file}")
        except Exception as e:
            print(f"Failed to write report to {args.report_file}: {e}")
            print(out_text)
    else:
        print(out_text)

    device.disconnect()
    return 0
import argparse
import fnmatch
import json
import os
import sys
from typing import List

from .devices import TelnetDevice
from .framework import EmbeddedTestFramework
from .utils import _discover_and_add_suites


class DummyDevice(TelnetDevice):
    def __init__(self):
        super().__init__(host='127.0.0.1', port=23)
        # for dry-run, provide some common capabilities so examples may run
        self.capabilities = {'telnet', 'ftp', 'judge', 'local-user'}

    def connect(self) -> bool:
        self.log('DummyDevice: pretend connected')
        return True

    def disconnect(self):
        self.log('DummyDevice: pretend disconnected')

    def execute_command(self, cmd, timeout=10, print_info=True):
        self.log(f"DummyDevice: execute_command('{cmd}')")
        return ""

    def execute_command_expect(self, cmd, expect, timeout=10, max_retries=5):
        self.log(f"DummyDevice: execute_command_expect('{cmd}', '{expect}')")
        return True, ""


def parse_level_spec(spec: str) -> set:
    s = set()
    if not spec:
        return s
    parts = [p.strip() for p in spec.split(',') if p.strip()]
    for part in parts:
        if '-' in part:
            try:
                a, b = part.split('-', 1)
                a_i = int(a); b_i = int(b)
                rng = range(min(a_i, b_i), max(a_i, b_i) + 1)
                s.update(rng)
            except Exception:
                continue
        else:
            try:
                s.add(int(part))
            except Exception:
                continue
    return s


def cli_main(argv: List[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description='Run omtest test framework')
    parser.add_argument('--config', '-c', help='Path to config.json (default: ./config.json)')
    parser.add_argument('--host', help='Device host to connect to')
    parser.add_argument('--port', type=int, help='Device port')
    parser.add_argument('--username', help='Device login username')
    parser.add_argument('--password', help='Device login password')
    parser.add_argument('--prompt', help='Device prompt string')
    parser.add_argument('--login-prompt', dest='login_prompt', help='Login prompt to wait for')
    parser.add_argument('--passwd-prompt', dest='passwd_prompt', help='Password prompt to wait for')
    parser.add_argument('--dry-run', action='store_true', help='Use DummyDevice (no real network)')
    parser.add_argument('--filter', '-f', help='Filter case ids (comma-separated, supports * wildcard)')
    parser.add_argument('--level', help='Levels to run (e.g. 1-2,4). Default: 1', dest='levels')
    parser.add_argument('--cases-dir', help='Package name or directory path that contains testcases (default: testcases)', dest='cases_dir')
    parser.add_argument('--report', choices=['plain', 'json'], default='plain', help='Report format to output (plain or json)')
    parser.add_argument('--report-file', help='Write report to file (path). If omitted, prints to stdout.')
    args = parser.parse_args(argv)

    use_dry = args.dry_run or os.environ.get('HITEST_DRY_RUN') == '1'

    cfg_path = args.config if args.config else os.path.join(os.getcwd(), 'config.json')
    cfg = {}
    if os.path.exists(cfg_path):
        try:
            with open(cfg_path, 'r', encoding='utf-8') as f:
                cfg = json.load(f)
        except Exception as e:
            print(f"Warning: failed to load config file {cfg_path}: {e}")

    device_cfg = cfg.get('device', {}) if isinstance(cfg, dict) else {}

    host = args.host or device_cfg.get('host')
    port = args.port if args.port is not None else int(device_cfg.get('port', 23))
    username = args.username or device_cfg.get('username')
    password = args.password or device_cfg.get('password')
    prompt = args.prompt or device_cfg.get('prompt')
    login_prompt = args.login_prompt or device_cfg.get('login_prompt')
    passwd_prompt = args.passwd_prompt or device_cfg.get('passwd_prompt')
    capability_checks = device_cfg.get('capability', {})

    if use_dry:
        device = DummyDevice()
        device.connect()
    else:
        if not host:
            print('Error: host required (or use --dry-run)')
            return 2
        device = TelnetDevice(host=host, port=port, username=username or '', password=password or '', prompt=prompt or '>', login_prompt=login_prompt or 'Username:', passwd_prompt=passwd_prompt or 'Password:', capability_checks=capability_checks)
        if not device.connect():
            return 3

    framework = EmbeddedTestFramework(device)
    cases_pkg = args.cases_dir if args.cases_dir else 'testcases'
    _discover_and_add_suites(cases_pkg, framework.suites)

    # apply filter if requested
    if args.filter:
        patterns = [p.strip() for p in args.filter.split(',') if p.strip()]
        device.log(f"Applying case filter: {patterns}")
        filtered_suites = []
        for suite in framework.suites:
            matched_cases = [c for c in getattr(suite, 'test_cases', []) if any(fnmatch.fnmatch(getattr(c, 'case_id', ''), pat) for pat in patterns)]
            if matched_cases:
                suite.test_cases = matched_cases
                filtered_suites.append(suite)
        framework.suites = filtered_suites
        if not filtered_suites:
            print(f"No test cases match filter: {patterns}")
            return 0

    # parse levels
    if args.levels:
        levels_to_run = parse_level_spec(args.levels)
    else:
        levels_to_run = {1}

    if levels_to_run:
        device.log(f"Filtering test cases by levels: {sorted(levels_to_run)}")
        new_suites = []
        for suite in framework.suites:
            matched_cases = [c for c in getattr(suite, 'test_cases', []) if getattr(c, 'level', 1) in levels_to_run]
            if matched_cases:
                suite.test_cases = matched_cases
                new_suites.append(suite)
        framework.suites = new_suites
        if not new_suites:
            print(f"No test cases match level(s): {sorted(levels_to_run)}")
            return 0

    results = framework.run_all()

    # format report
    if args.report == 'json':
        import json as _json
        serializable = {}
        for suite_name, suite_res in results.items():
            if isinstance(suite_res, list):
                serializable[suite_name] = [
                    {
                        'case_id': getattr(r, 'case_id', ''),
                        'case_name': getattr(r, 'case_name', ''),
                        'success': getattr(r, 'success', False),
                        'error_msg': getattr(r, 'error_msg', ''),
                        'test_log': getattr(r, 'test_log', ''),
                        'skipped': getattr(r, 'skipped', False)
                    }
                    for r in suite_res
                ]
            else:
                serializable[suite_name] = suite_res
        out_text = _json.dumps(serializable, ensure_ascii=False, indent=2)
    else:
        lines = ['Test results:']
        for suite_name, suite_res in results.items():
            lines.append(f"- Suite: {suite_name}")
            if isinstance(suite_res, list):
                for r in suite_res:
                    if getattr(r, 'skipped', False):
                        status = 'SKIP'
                    else:
                        status = 'PASS' if getattr(r, 'success', False) else 'FAIL'
                    lines.append(f"    [{status}] {getattr(r, 'case_id', '')} - {getattr(r, 'case_name', '')}")
            else:
                lines.append(f"    {suite_res}")
        out_text = "\n".join(lines)

    if args.report_file:
        try:
            with open(args.report_file, 'w', encoding='utf-8') as f:
                f.write(out_text)
            print(f"Wrote report to {args.report_file}")
        except Exception as e:
            print(f"Failed to write report to {args.report_file}: {e}")
            print(out_text)
    else:
        print(out_text)

    device.disconnect()
    return 0
