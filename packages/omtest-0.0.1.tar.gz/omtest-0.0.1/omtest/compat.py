from dataclasses import dataclass, field
from typing import List, Callable, Any, Union
from .devices import EmbeddedDevice


@dataclass
class TestCase:
    case_id: str
    case_name: str
    test_func: Callable[[EmbeddedDevice], tuple[bool, str, str]]
    description: str = ""
    level: Union[int, None] = None

    def __post_init__(self):
        if self.level is None:
            try:
                self.level = int(getattr(self.test_func, '_case_level', 1))
            except Exception:
                self.level = 1


@dataclass
class TestResult:
    case_id: str
    case_name: str
    success: bool = False
    test_log: str = ""
    error_msg: str = ""


@dataclass
class ConfigurationItem:
    name: str
    setup_commands: Union[str, List[str]]
    verify_command: str
    expected_results: Union[str, List[str]]
    max_retries: int = 5


@dataclass
class TestSuite:
    suite_id: str
    suite_name: str
    description: str = ""
    auto_rollback: bool = True
    test_cases: List[TestCase] = field(default_factory=list)

    def add_test_case(self, case: TestCase):
        self.test_cases.append(case)
        print(f"TestSuite [{self.suite_id}] added test case: {case.case_id} - {case.case_name}")

    def add_test_cases(self, cases: List[TestCase]):
        self.test_cases.extend(cases)
        print(f"TestSuite [{self.suite_id}] bulk added {len(cases)} test cases")
