"""Public package surface for omtest.
Exports the main classes and functions for public use.
"""
from .devices import EmbeddedDevice, TelnetDevice, case_level
from .compat import TestCase, TestResult, TestSuite, ConfigurationItem
from .framework import EmbeddedTestFramework
from .utils import apply_and_verify_configurations, generate_rollback_commands, apply_rollback_commands, _discover_and_add_suites, create_verification_items, capture_current_config
from .cli import cli_main

__all__ = [
    '__version__',
    'EmbeddedDevice', 'TelnetDevice', 'case_level',
    'TestCase', 'TestResult', 'TestSuite', 'ConfigurationItem',
    'EmbeddedTestFramework',
    'apply_and_verify_configurations', 'create_verification_items', 'capture_current_config', 'generate_rollback_commands', 'apply_rollback_commands',
    'cli_main',
]

# single-source version placeholder
__version__ = '0.0.1'
