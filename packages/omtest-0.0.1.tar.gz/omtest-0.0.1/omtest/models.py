from typing import List, Dict, Any


class TestResult:
    def __init__(self, name: str, success: bool, details: str = ""):
        self.name = name
        self.success = success
        self.details = details


class TestCase:
    def __init__(self, name: str, func):
        self.name = name
        self.func = func
        self.level = getattr(func, '_case_level', 0)

    def run(self, device, framework) -> TestResult:
        try:
            res = self.func(device, framework)
            return TestResult(self.name, True, str(res))
        except Exception as e:
            return TestResult(self.name, False, str(e))


class ConfigurationItem:
    def __init__(self, path: str, value: str):
        self.path = path
        self.value = value


class TestSuite:
    def __init__(self, name: str):
        self.name = name
        self.cases: List[TestCase] = []

    def add_case(self, case: TestCase):
        self.cases.append(case)

    def run(self, device, framework) -> List[TestResult]:
        results = []
        for case in self.cases:
            results.append(case.run(device, framework))
        return results
