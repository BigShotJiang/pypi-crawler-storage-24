"""Module entrypoint to support `python -m omtest`."""
from . import cli_main


def main():
    cli_main()


if __name__ == '__main__':
    main()
