import re
from typing import List, Tuple
from .models import ConfigurationItem
from . import compat
from typing import Any


def _parse_config_to_paths(cfg_text: str) -> List[ConfigurationItem]:
    items = []
    for line in cfg_text.splitlines():
        if not line.strip():
            continue
        if '\t' in line:
            path, val = line.split('\t', 1)
        elif ' = ' in line:
            path, val = line.split(' = ', 1)
        else:
            parts = line.split()
            path, val = parts[0], ' '.join(parts[1:]) if len(parts) > 1 else ''
        items.append(ConfigurationItem(path.strip(), val.strip()))
    return items


def capture_current_config(device) -> str:
    try:
        out = device.execute_command("display current-configuration", timeout=20, print_info=False)
        return out
    except Exception as e:
        return f"ERROR: Failed to capture configuration: {e}"


def create_verification_items(config_items: List[ConfigurationItem], suffix: str = " Verification") -> List[ConfigurationItem]:
    return [
        ConfigurationItem(
            name=f"{item.name}{suffix}",
            setup_commands=[],
            verify_command=item.verify_command,
            expected_results=item.expected_results,
            max_retries=item.max_retries
        )
        for item in config_items
    ]


def apply_and_verify_configurations(dev, config_items: List[ConfigurationItem]) -> tuple[bool, str]:
    for item in config_items:
        dev.log(f"Processing configuration: {item.name}")
        if item.setup_commands:
            try:
                dev.execute_command("return", print_info=False)
                dev.execute_command("system-view", print_info=False)
                dev.execute_command(item.setup_commands, print_info=True)
            except Exception as e:
                error_msg = f"Failed to apply configuration '{item.name}': {e}"
                dev.err(error_msg)
                return False, error_msg
            dev.log(f"Configuration commands executed: {item.name}")
        dev.log(f"Verifying configuration: {item.name} with command: {item.verify_command}")
        matched, output = dev.execute_command_expect(item.verify_command, item.expected_results, max_retries=item.max_retries)
        if not matched:
            error_msg = f"Configuration '{item.name}' verification failed.\nExpected: {item.expected_results}\nActual output: {output}"
            dev.err(error_msg)
            return False, error_msg
        dev.log(f"[PASS] Configuration '{item.name}' verified successfully")
    return True, ""


def generate_rollback_commands(before_cfg_text: str, after_cfg_text: str) -> List[str]:
    before = _parse_config_to_paths(before_cfg_text)
    after = _parse_config_to_paths(after_cfg_text)
    before_map = {b.path: b.value for b in before}
    cmds = []
    for a in after:
        if a.path not in before_map:
            cmds.append(f"undo {a.path} {a.value}".strip())
        elif before_map[a.path] != a.value:
            cmds.append(f"system-view\n{a.path} {before_map[a.path]}".strip())
    return cmds


def apply_rollback_commands(device, cmds: List[str]) -> None:
    for c in cmds:
        device.execute_command(c)


def _discover_and_add_suites(package_name: str, suites_list: List[Any]):
    import pkgutil
    import importlib
    import sys
    import os

    if not package_name:
        pkg_name = 'testcases'
    else:
        pkg_name = package_name

    pkg = None
    try:
        if os.path.isdir(pkg_name):
            parent = os.path.abspath(os.path.join(pkg_name, os.pardir))
            pkg_basename = os.path.basename(os.path.abspath(pkg_name))
            sys.path.insert(0, parent)
            try:
                pkg = importlib.import_module(pkg_basename)
            finally:
                try:
                    sys.path.pop(0)
                except Exception:
                    pass
        else:
            pkg = importlib.import_module(pkg_name)
    except Exception as e:
        print(f"No testcases package found ('{pkg_name}'): {e}")
        return

    if not hasattr(pkg, '__path__'):
        return

    TestSuiteCls = getattr(compat, 'TestSuite')
    for finder, name, ispkg in pkgutil.iter_modules(pkg.__path__):
        full_name = f"{pkg.__name__}.{name}"
        try:
            mod = importlib.import_module(full_name)
            for obj_name, obj in vars(mod).items():
                if isinstance(obj, TestSuiteCls):
                    suites_list.append(obj)
                    continue
                if isinstance(obj, (list, tuple)):
                    for item in obj:
                        if isinstance(item, TestSuiteCls):
                            suites_list.append(item)
                if isinstance(obj, dict):
                    for item in obj.values():
                        if isinstance(item, TestSuiteCls):
                            suites_list.append(item)
        except Exception as e:
            print(f"Failed to import test module {full_name}: {e}")
