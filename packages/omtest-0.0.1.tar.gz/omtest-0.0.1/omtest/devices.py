import telnetlib
import time
from typing import List, Union, Optional, Dict, Any


def case_level(level: int):
    def _decorator(func):
        setattr(func, '_case_level', int(level))
        return func
    return _decorator


def _read_until_any(tn, candidates=(b'>', b']', b'$'), timeout=10.0, idle_timeout=0.5):
    buf = b''
    end_time = time.monotonic() + timeout
    last_recv = time.monotonic()
    while time.monotonic() < end_time:
        try:
            chunk = tn.read_very_eager()
        except EOFError:
            break
        if chunk:
            buf += chunk
            last_recv = time.monotonic()
            for c in candidates:
                if c in buf:
                    return buf
        else:
            if time.monotonic() - last_recv > idle_timeout:
                break
            time.sleep(0.01)
    return buf


def _match_expect(output: str, expect) -> bool:
    if expect is None:
        return bool(output)

    if isinstance(expect, (list, tuple)):
        if any(isinstance(e, (list, tuple)) for e in expect):
            lines = [ln for ln in str(output).splitlines() if ln.strip()]
            for inner in expect:
                matched_inner = False
                if isinstance(inner, (list, tuple)):
                    for ln in lines:
                        if all(str(item) in ln for item in inner):
                            matched_inner = True
                            break
                else:
                    for ln in lines:
                        if str(inner) in ln:
                            matched_inner = True
                            break
                if not matched_inner:
                    return False
            return True
        else:
            return all(str(item) in output for item in expect)

    return str(expect) in output


class EmbeddedDevice:
    def __init__(self):
        self.has_printed = False
        self.hostname = ""
        self.capabilities = set()

    def connect(self) -> bool:
        raise NotImplementedError

    def disconnect(self):
        raise NotImplementedError

    def execute_command(self, cmd: Union[str, List[str]], timeout: int = 10) -> str:
        raise NotImplementedError

    def is_need_print_last_line(self) -> bool:
        return self.has_printed

    def out_string(self, description: str):
        print(description, end='')
        self.has_printed = False

    def log(self, description: str):
        print(f"\n\033[32m{description}\033[0m")
        self.has_printed = True

    def err(self, description: str):
        print(f"\033[31m>>>>>>>>>>>: {description}\033[0m")
        self.has_printed = True

    def execute_command_expect(self, cmd: Union[str, List[str]], expect: Union[str, List[str]], timeout: int = 10, max_retries: int = 5) -> tuple[bool, str]:
        raise NotImplementedError

    def has_capability(self, cap: str) -> bool:
        return cap in getattr(self, 'capabilities', set())


class CapacityManager:
    """Collects capabilities from a device based on configured checks.

    The checks mapping format is:
    {
      "capability_name": [
          {"cmd": "display version", "expect": "FTP server"},
          {"cmd": "display feature", "expect": ["judge", "acm"]}
      ],
      "another_cap": [ {"cmd": "show something", "expect": "OK"} ]
    }

    Each capability is considered present if ALL checks for it match (logical AND).
    """

    def __init__(self, checks: Optional[Dict[str, Any]] = None):
        self.checks = checks or {}

    def collect(self, dev: EmbeddedDevice, timeout: int = 5) -> set:
        found = set()
        if not self.checks:
            return found
        for cap, checks in self.checks.items():
            all_ok = True
            for chk in checks:
                try:
                    if isinstance(chk, dict):
                        cmd = chk.get('cmd')
                        expect = chk.get('expect')
                    elif isinstance(chk, (list, tuple)) and len(chk) >= 2:
                        cmd, expect = chk[0], chk[1]
                    else:
                        all_ok = False
                        break

                    out = dev.execute_command(cmd, timeout=timeout, print_info=False)
                    if not _match_expect(out, expect):
                        all_ok = False
                        break
                except Exception:
                    all_ok = False
                    break
            if all_ok:
                found.add(cap)
        return found


class TelnetDevice(EmbeddedDevice):
    def __init__(self, host: str, port: int = 23, username: str = "", password: str = "",
                 prompt: str = ">", login_prompt: str = "Username:", passwd_prompt: str = "Password:", capability_checks: Optional[Dict[str, Any]] = None):
        super().__init__()
        self.capabilities = {'telnet'}
        self.host = host
        self.port = port
        self.username = username
        self.password = password
        self.prompt = prompt
        self.login_prompt = login_prompt
        self.passwd_prompt = passwd_prompt
        self._capability_checks = capability_checks or {}
        self.tn: Optional[telnetlib.Telnet] = None
        self.last_line: str = ""
        self.has_printed = False
        self.hostname = ""

    def connect(self) -> bool:
        try:
            self.tn = telnetlib.Telnet(self.host, self.port, timeout=10)
            self.log(f"Connected to device {self.host}:{self.port}")
            if self.username:
                received = self.tn.read_until(self.login_prompt.encode(), timeout=5).decode('utf-8', errors='ignore')
                print(received, end='')
                self.tn.write((self.username + "\n").encode())
            if self.password:
                received = self.tn.read_until(self.passwd_prompt.encode(), timeout=5).decode('utf-8', errors='ignore')
                print(received, end='')
                self.tn.write((self.password + "\n").encode())

            received = _read_until_any(self.tn, candidates=(b'>', b'#', b'$'), timeout=10, idle_timeout=0.5).decode('utf-8', errors='ignore')
            print(received, end='')
            if "Authentication failed" in received or "System is busy in cfg recovery" in received:
                self.err("Authentication failed, check username/password")
                return False

            lines = received.split("\n")
            self.last_line = lines[-1]
            self.log(f"\nLogged into device {self.host}, current prompt: {self.last_line.strip()}")
            self.hostname = self.last_line.strip().rstrip('>')
            try:
                cm = CapacityManager(self._capability_checks)
                caps = cm.collect(self)
                if caps:
                    self.capabilities.update(caps)
                    self.log(f"Detected capabilities: {sorted(list(caps))}")
            except Exception:
                pass
            return True
        except Exception as e:
            self.err(f"Failed to connect to device: {str(e)}")
            return False

    def disconnect(self):
        if self.tn:
            self.tn.close()
            self.tn = None
            self.log(f"Disconnected from device {self.host}")

    def execute_command_ex(self, cmd: str, timeout: int = 10, idle_timeout: int = 0.1, print_info: bool = True) -> str:
        if not self.tn:
            return "Error: device not connected"
        try:
            self.tn.write(cmd.encode('utf-8') + b"\n")

            raw_output = _read_until_any(self.tn,
                                         candidates=(f'{self.hostname}>'.encode(), f'{self.hostname}]'.encode(), f'{self.hostname}$'.encode()),
                                         timeout=timeout, idle_timeout=idle_timeout)
            output = raw_output.decode('utf-8', errors='ignore')

            if print_info:
                if self.is_need_print_last_line():
                    self.out_string(self.last_line)
                self.out_string(output)

            lines = output.split("\n")
            self.last_line = lines[-1]
            return "\n".join(lines)
        except Exception as e:
            return f"Command execution failed: {str(e)}"

    def execute_command(self, cmd: Union[str, List[str]], timeout: int = 10, idle_timeout: int = 0.1, print_info: bool = True) -> str:
        if isinstance(cmd, list):
            all_outputs: List[str] = []
            for single_cmd in cmd:
                output = self.execute_command(single_cmd, timeout=timeout, idle_timeout=idle_timeout, print_info=print_info)
                all_outputs.append(output)
            return "\n".join(all_outputs)

        chunks: List[str] = []
        chunk = self.execute_command_ex(cmd, timeout, idle_timeout, print_info=print_info)
        n = 0
        while chunk.startswith("Command execution failed"):
            if self.connect():
                chunk = self.execute_command_ex(cmd, timeout, idle_timeout, print_info=print_info)
            else:
                time.sleep(1)
                n = n + 1
                if n > 300:
                    self.err(f"Failed to reconnect after {n} attempts, giving up.")
                    return chunk
                continue

        chunks.append(chunk)
        while "-- More --" in chunk:
            chunk = self.execute_command_ex(" ", timeout, idle_timeout, print_info=print_info)
            chunks.append(chunk)

        combined = "".join(chunks)
        lines = combined.splitlines()
        filtered = [ln for ln in lines if "-- More --" not in ln]
        return "\n".join(filtered)

    def execute_command_rollback(self, cmd: str, timeout: int = 10, idle_timeout: int = 0.1) -> str:
        undoFlag = cmd.startswith("undo ")
        while True:
            result = self.execute_command(cmd, timeout, idle_timeout)
            if undoFlag and "Unrecognized command at '^' position" in result:
                last_space_idx = cmd.strip().rfind(' ')
                if last_space_idx != -1:
                    cmd = cmd[:last_space_idx + 1]
                    self.log(f"Smart rollback: {cmd}")
                else:
                    break;
                continue
            else:
                break
        return result

    def execute_command_expect(self, cmd: Union[str, List[str]], expect: Union[str, List[str]], timeout: int = 10, max_retries: int = 5) -> tuple[bool, str]:
        last_output = ""
        for attempt in range(max_retries):
            try:
                output = self.execute_command(cmd, timeout=timeout, print_info=True)
                last_output = output
                if _match_expect(output, expect):
                    return True, output
                else:
                    if attempt < max_retries - 1:
                        self.err(f"Expected pattern not satisfied (attempt {attempt + 1}/{max_retries}), retrying...")
                        time.sleep(0.5)
            except Exception as e:
                self.err(f"Command execution error on attempt {attempt + 1}: {e}")
                if attempt < max_retries - 1:
                    time.sleep(0.5)

        return False, last_output
