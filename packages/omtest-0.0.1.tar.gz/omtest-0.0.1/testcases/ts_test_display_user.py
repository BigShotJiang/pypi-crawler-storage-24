from omtest import TestCase, TestSuite, EmbeddedDevice

def suite_setup(dev: EmbeddedDevice) -> tuple[bool, str]:
    dev.execute_command("return", print_info=False)
    dev.execute_command("screen-length 4")
    return True, ""

def suite_teardown(dev: EmbeddedDevice) -> tuple[bool, str]:
    return True, ""

def test_display_user(dev: EmbeddedDevice) -> tuple[bool, str, str]:
    error_msg = ""
    dev.log("Step 1: run 'display user', expect 'root' user present")
    ip_output = dev.execute_command("display user")
    expected_ip = "root"
    if expected_ip not in ip_output:
        error_msg = f"Not found {expected_ip}"
        dev.err(error_msg)
        return False, "", error_msg

    dev.execute_command("return")
    dev.execute_command("system-view")
    dev.execute_command("judge-mgr")
    dev.execute_command("ignore extra-space enable")
    dev.execute_command("mode acm")
    return True, "", error_msg

tc_test_display_user = TestCase(
    case_id="tc_test_display_user",
    case_name="Query user login info",
    test_func=test_display_user,
    description="Query current logged-in users and verify root is present",
)

ts_test_display_user_suite = TestSuite(
    suite_id="ts_test_display_user_suite",
    suite_name="Test display user suite",
    description="DFX related functional test suite",
)

ts_test_display_user_suite.add_test_cases([tc_test_display_user])
