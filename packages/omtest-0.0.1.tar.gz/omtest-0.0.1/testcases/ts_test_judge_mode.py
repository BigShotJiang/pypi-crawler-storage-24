from omtest import TestCase, TestSuite, EmbeddedDevice
from omtest.capabilities import requires_capabilities


def suite_setup(dev: EmbeddedDevice) -> tuple[bool, str]:
    dev.execute_command("return", print_info=False)
    dev.execute_command("screen-length 4")
    return True, ""


def suite_teardown(dev: EmbeddedDevice) -> tuple[bool, str]:
    return True, ""

@requires_capabilities("wlan")
def test_judge_mode(dev: EmbeddedDevice) -> tuple[bool, str, str]:
    error_msg = ""
    dev.execute_command("return")
    dev.execute_command("system-view")
    dev.execute_command("aaa")
    dev.execute_command("undo local-user test")
    dev.execute_command("local-user test password Huawei@123 service-type telnet ftp")
    dev.log("Step 1: run 'display user', expect 'root' user present")
    dev.execute_command("return")
    dev.execute_command("system-view")
    dev.execute_command("ftp server enable")
    dev.execute_command("judge-mgr")
    dev.execute_command("ignore extra-space enable")
    dev.execute_command("mode acm")
    expected_ip = [["Judge Mode", "ACM"]]
    ok, ip_output = dev.execute_command_expect("display judge brief", expect=expected_ip)
    if not ok:
        error_msg = f"Not found {expected_ip}"
        dev.err(error_msg)
        return False, "", error_msg
    return True, "", error_msg


tc_test_judge_mode = TestCase(
    case_id="tc_test_judge_mode",
    case_name="Judge mode configuration",
    test_func=test_judge_mode,
    description="Verify judge mode configuration is correct",
)

ts_test_judge_mode_suite = TestSuite(
    suite_id="ts_test_judge_mode_suite",
    suite_name="Judge Configuration Suite",
    description="Judge-related functional test suite",
)
ts_test_judge_mode_suite.add_test_case(tc_test_judge_mode)

