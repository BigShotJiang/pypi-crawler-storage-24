import time
from omtest import TestCase, TestSuite, EmbeddedDevice, ConfigurationItem, apply_and_verify_configurations, create_verification_items


def suite_setup(dev: EmbeddedDevice) -> tuple[bool, str]:
    dev.execute_command(["return", "screen-length 4"], print_info=False)
    return True, ""


def suite_teardown(dev: EmbeddedDevice) -> tuple[bool, str]:
    return True, ""


def test_recovery(dev: EmbeddedDevice) -> tuple[bool, str, str]:
    """Recovery mode configuration test - using data-driven configuration framework
    
    配置表：在此定义所有需要配置和验证的项目，无需修改测试框架
    """
    
    # ==== 配置表开始 ====
    configurations = [
        # 配置项1：本地用户账户
        ConfigurationItem(
            name="Local User Configuration",
            setup_commands=[
                "aaa",
                "undo local-user test",
                "local-user test password Huawei@123 service-type telnet ftp"
            ],
            verify_command="display current-configuration",
            expected_results=["local-user test"]
        ),
        
        # 配置项2：Judge模式设置
        ConfigurationItem(
            name="Judge Mode Configuration",
            setup_commands=[
                "ftp server enable",
                "judge-mgr",
                "ignore extra-space enable",
                "mode acm"
            ],
            verify_command="display judge brief",
            expected_results=["Judge Mode    : ACM", "Global Judge Is Enable"]
        ),
    ]
    # ==== 配置表结束 ====
    
    # 阶段1：应用并验证所有配置
    dev.log("========== Stage 1: Apply and Verify Configurations ==========")
    success, error_msg = apply_and_verify_configurations(dev, configurations)
    if not success:
        dev.err(f"Configuration verification failed: {error_msg}")
        return False, "", error_msg
    
    # 阶段2：保存配置并重启设备
    dev.log("========== Stage 2: Save Configuration and Restart Device ==========")
    dev.execute_command(["return", "save", "restart"])
    
    time.sleep(5)  # 等待设备重启
    
    # 阶段3：重启后验证所有配置是否保持（复用前面的验证命令和期望结果）
    dev.log("========== Stage 3: Verify Configurations After Reboot ==========")
    
    success, error_msg = apply_and_verify_configurations(
        dev, 
        create_verification_items(configurations, " After Reboot")
    )
    
    if not success:
        dev.err(f"Post-reboot verification failed: {error_msg}")
        return False, "", error_msg
    
    return True, "", ""

tc_test_recovery = TestCase(
    case_id="tc_test_recovery",
    case_name="Recovery mode configuration",
    test_func=test_recovery,
    level=2,
    description="Verify judge mode configuration is correct",
)

ts_test_recovery_suite = TestSuite(
    suite_id="ts_test_recovery_suite",
    suite_name="Recovery Configuration Suite",
    description="Recovery-related functional test suite",
)
ts_test_recovery_suite.add_test_case(tc_test_recovery)

