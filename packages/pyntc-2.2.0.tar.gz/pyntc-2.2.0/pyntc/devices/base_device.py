"""The module contains the base class that all device classes must inherit from."""

import hashlib
import importlib
import warnings

from pyntc.errors import FeatureNotFoundError, NTCError
from pyntc.utils.models import FileCopyModel


def fix_docs(cls):
    """Create docstring at runtime.

    Returns:
        (class): Returns the class passed in.
    """
    for name, func in vars(cls).items():
        if hasattr(func, "__call__") and not func.__doc__:
            # print(func, 'needs doc')
            for parent in cls.__bases__:
                parfunc = getattr(parent, name, None)
                if parfunc and getattr(parfunc, "__doc__", None):
                    func.__doc__ = parfunc.__doc__
                    break
    return cls


class BaseDevice:  # pylint: disable=too-many-instance-attributes,too-many-public-methods
    """Base Device ABC."""

    def __init__(self, host, username, password, device_type=None, **kwargs):  # noqa: D403  # pylint: disable=unused-argument
        """PyNTC base device implementation.

        Args:
            host (str): The address of the network device.
            username (str): The username to authenticate with the device.
            password (str): The password to authenticate with the device.
            device_type (str, optional): Denotes which device type. Defaults to None.
            kwargs (dict): Additional keyword arguments that may be used by subclasses.
        """
        self.host = host
        self.username = username
        self.password = password
        self.device_type = device_type
        self._uptime = None
        self._os_version = None
        self._interfaces = None
        self._hostname = None
        self._fqdn = None
        self._uptime_string = None
        self._serial_number = None
        self._model = None
        self._vlans = None

    def _image_booted(self, image_name, **vendor_specifics):
        """Determine if a particular image is serving as the active OS.

        Args:
            image_name (str): The image that you would like the device to be using for active OS.
            vendor_specifics (kwargs):
                volume: Required by F5Device as F5 boots into a volume.

        Returns:
            (bool): True if image is currently being used by the device, else False.
        """
        raise NotImplementedError

    def backup_running_config(self, filename):
        """Save a local copy of the running config.

        Args:
            filename (str): The local file path on which to save the running config.
        """
        raise NotImplementedError

    @property
    def boot_options(self):
        """Get current boot variables.

        like system image and kickstart image.

        Returns:
            (dict): A dictionary, e.g. {'kick': router_kick.img, 'sys': 'router_sys.img'}
        """
        raise NotImplementedError

    def checkpoint(self, filename):
        """Save a checkpoint of the running configuration to the device.

        Args:
            filename (str): The filename to save the checkpoint as on the remote device.
        """
        raise NotImplementedError

    def close(self):
        """Close the connection to the device."""
        raise NotImplementedError

    def config(self, command):
        """Send a configuration command.

        Args:
            command (str): The command to send to the device.

        Raises:
            CommandError: If there is a problem with the supplied command.
        """
        raise NotImplementedError

    @property
    def uptime(self):
        """Uptime integer property, part of device facts.

        Raises:
            NotImplementedError: returns not implemented if not included in facts.
        """
        raise NotImplementedError

    @property
    def os_version(self):
        """Operating System string property, part of device facts.

        Raises:
            NotImplementedError: returns not implemented if not included in facts.
        """
        raise NotImplementedError

    @property
    def interfaces(self):
        """Interfaces list of strings property, part of device facts.

        Raises:
            NotImplementedError: returns not implemented if not included in facts.
        """
        raise NotImplementedError

    @property
    def hostname(self):
        """Host name string property, part of device facts.

        Raises:
            NotImplementedError: returns not implemented if not included in facts.
        """
        raise NotImplementedError

    @property
    def fqdn(self):
        """
        Get FQDN of the device.

        Raises:
            NotImplementedError: returns not implemented if not included in facts.
        """
        raise NotImplementedError

    @property
    def uptime_string(self):
        """Uptime string string property, part of device facts.

        Raises:
            NotImplementedError: returns not implemented if not included in facts.
        """
        raise NotImplementedError

    @property
    def serial_number(self):
        """
        Get serial number of the device.

        Raises:
            NotImplementedError: returns not implemented if not included in facts.
        """
        raise NotImplementedError

    @property
    def model(self):
        """Model string property, part of device facts.

        Raises:
            NotImplementedError: returns not implemented if not included in facts.
        """
        raise NotImplementedError

    @property
    def vlans(self):
        """Vlans lost of strings property, part of device facts.

        Raises:
            NotImplementedError: returns not implemented if not included in facts.
        """
        raise NotImplementedError

    def facts(self):  # noqa 401
        """DEPRECATED - Use individual properties to get facts."""
        warnings.warn("facts() is deprecated; use individual fact properties.", DeprecationWarning)
        facts = {
            fact: getattr(self, fact, None)
            for fact in [
                "vendor",
                "uptime",
                "uptime_string",
                "hostname",
                "fqdn",
                "interfaces",
                "vlans",
                "model",
                "serial_number",
                "os_version",
            ]
        }
        if self.device_type == "cisco_ios_ssh":
            facts[self.device_type] = {"config_register": self.config_register}  # pylint: disable=no-member

    def file_copy(self, src, dest=None, **kwargs):
        """Send a local file to the device.

        Args:
            src (str): Path to the local file to send.
            dest (str): The destination file path to be saved on remote flash.
                If none is supplied, the implementing class should use the basename
                of the source path.
            kwargs (dict): Additional keyword arguments that may be used by subclasses.

        Keyword Args:
            file_system (str): Supported only for IOS and NXOS. The file system for the
                remote file. If no file_system is provided, then the ``get_file_system``
                method is used to determine the correct file system to use.
        """
        raise NotImplementedError

    def file_copy_remote_exists(self, src, dest=None, **kwargs):
        """Check if a remote file exists.

        A remote file exists if it has the same name as supplied dest,
        and the same md5 hash as the source.

        Args:
            src (str): Path to local file to check.
            dest (str): The destination file path to be saved on remote the remote device.
                If none is supplied, the implementing class should use the basename
                of the source path.
            kwargs (dict): Additional keyword arguments that may be used by subclasses.

        Keyword Args:
            file_system (str): Supported only for IOS and NXOS. The file system for the
                remote file. If no file_system is provided, then the ``get_file_system``
                method is used to determine the correct file system to use.

        Returns:
            (bool): True if the remote file exists, False if it doesn't.
        """

    def check_file_exists(self, filename, **kwargs):
        """Check if a remote file exists by filename.

        Args:
            filename (str): The name of the file to check for on the remote device.
            kwargs (dict): Additional keyword arguments that may be used by subclasses.

        Keyword Args:
            file_system (str): Supported only for IOS and NXOS. The file system for the
                remote file. If no file_system is provided, then the ``get_file_system``
                method is used to determine the correct file system to use.

        Returns:
            (bool): True if the remote file exists, False if it doesn't.
        """
        raise NotImplementedError

    def get_remote_checksum(self, filename, hashing_algorithm="md5", **kwargs):
        """Get the checksum of a remote file.

        Args:
            filename (str): The name of the file to check for on the remote device.
            hashing_algorithm (str): The hashing algorithm to use (default: "md5").
            kwargs (dict): Additional keyword arguments that may be used by subclasses.

        Keyword Args:
            file_system (str): Supported only for IOS and NXOS. The file system for the
                remote file. If no file_system is provided, then the ``get_file_system``
                method is used to determine the correct file system to use.

        Returns:
            (str): The checksum of the remote file.
        """
        raise NotImplementedError

    @staticmethod
    def get_local_checksum(filepath, hashing_algorithm="md5", add_newline=False):
        """Get the checksum of a local file using a specified algorithm.

        Args:
            filepath (str): The path to the local file.
            hashing_algorithm (str): The hashing algorithm to use (e.g., "md5", "sha256").
            add_newline (bool): Whether to append a newline before final hashing (Some devices may require this).

        Returns:
            (str): The hex digest of the file.
        """
        # Initialize the hash object dynamically
        file_hash = hashlib.new(hashing_algorithm.lower())

        with open(filepath, "rb") as f:
            # Read in chunks to handle large firmware files without RAM spikes
            for chunk in iter(lambda: f.read(4096), b""):
                file_hash.update(chunk)

        if add_newline:
            file_hash.update(b"\n")

        return file_hash.hexdigest()

    def compare_file_checksum(self, checksum, filename, hashing_algorithm="md5", **kwargs):
        """Compare the checksum of a local file with a remote file.

        Args:
            checksum (str): The checksum of the file.
            filename (str): The name of the file to check for on the remote device.
            hashing_algorithm (str): The hashing algorithm to use (default: "md5").
            kwargs (dict): Additional keyword arguments that may be used by subclasses.

        Keyword Args:
            file_system (str): Supported only for IOS and NXOS. The file system for the
                remote file. If no file_system is provided, then the ``get_file_system``
                method is used to determine the correct file system to use.

        Returns:
            (bool): True if the checksums match, False otherwise.
        """
        return checksum == self.get_remote_checksum(filename, hashing_algorithm, **kwargs)

    def remote_file_copy(self, src: FileCopyModel = None, dest=None, **kwargs):
        """Copy a file to a remote device.

        Args:
            src (FileCopyModel): The source file model.
            dest (str): The destination file path on the remote device.
            kwargs (dict): Additional keyword arguments that may be used by subclasses.

        Keyword Args:
            file_system (str): Supported only for IOS and NXOS. The file system for the
                remote file. If no file_system is provided, then the ``get_file_system``
                method is used to determine the correct file system to use.
        """
        raise NotImplementedError

    def verify_file(self, checksum, filename, hashing_algorithm="md5", **kwargs):
        """Verify a file on the remote device by confirming the file exists and validate the checksum.

        Args:
            checksum (str): The checksum of the file.
            filename (str): The name of the file to check for on the remote device.
            hashing_algorithm (str): The hashing algorithm to use (default: "md5").
            kwargs (dict): Additional keyword arguments that may be used by subclasses.

        Keyword Args:
            file_system (str): Supported only for IOS and NXOS. The file system for the
                remote file. If no file_system is provided, then the ``get_file_system``
                method is used to determine the correct file system to use.

        Returns:
            (bool): True if the file is verified successfully, False otherwise.
        """
        raise NotImplementedError

    def install_os(self, image_name, **vendor_specifics):
        """Install the OS from specified image_name.

        Args:
            image_name (str): The name of the image on the device to install.

        Keyword Args:
            kickstart (str): Option for ``NXOSDevice`` for devices that require a kickstart image.
            volume (str): Option for ``F5Device`` to set the target boot volume.
            file_system (str): Option for ``ASADevice``, ``EOSDevice``, ``IOSDevice``, and
                ``NXOSDevice`` to set where the OS files are stored. The default will use
                the ``_get_file_system`` method.
            timeout (int): Option for ``IOSDevice`` and ``NXOSDevice`` to set the wait time for
                device installation to complete.
            vendor_specifics (kwargs): Additional keyword arguments that may be used by subclasses.

        Returns:
            (bool): True if system has been installed during function's call, False if OS has not been installed

        Raises:
            OSInstallError: When device finishes installation process, but the running image
                does not match ``image_name``.
            CommandError: When sending a command to the device fails, or when the config status
                after sending a command does not yield expected results.
            CommandListError: When sending commands to the device fails.
            NotEnoughFreeSpaceError: When the device does not have enough free space for install.
            NTCFileNotFoundError: When the ``image_name`` is not found in the devices ``file_system``.
            FileSystemNotFoundError: When the ``file_system`` is left to default,
                and the ``file_system`` cannot be identified.
            RebootTimeoutError: When device is rebooted and is unreachable longer than ``timeout`` period.
        """
        raise NotImplementedError

    def open(self):
        """Open a connection to the device."""
        raise NotImplementedError

    def reboot(self, wait_for_reload=False):
        """Reload a device.

        Args:
            wait_for_reload (bool): Whether or not reboot method should also run _wait_for_device_reboot(). Defaults to False.

        Raises:
            RebootTimeoutError: When the device is still unreachable after the timeout period.

        Raises:
            NotImplementedError: _description_
        """
        raise NotImplementedError

    def rollback(self, checkpoint_file):
        """Rollback to a checkpoint file.

        Args:
            checkpoint_file (str): The filename of the checkpoint file to load into the running configuration.
        """
        raise NotImplementedError

    @property
    def running_config(self):
        """Return the running configuration of the device."""
        raise NotImplementedError

    def save(self, filename=None):
        """Save a device's running configuration.

        Args:
            filename (str): The filename on the remote device.
                If none is supplied, the implementing class should
                save to the "startup configuration".
        """
        raise NotImplementedError

    def set_boot_options(self, image_name, **vendor_specifics):
        """Set boot variables like system image and kickstart image.

        Args:
            image_name (str): The main system image file name.

        Keyword Args:
            kickstart (str): Option for ``NXOSDevice`` for devices that require a kickstart image.
            volume (str): Option for ``F5Device`` to set which volume should have image installed.
            file_system (str): Option for ``ASADevice`` and ``IOSDevice`` to set which directory
                to use when setting the boot path. The default will use the directory returned
                by the ``_get_file_system()`` method.
            vendor_specifics (kwargs): Additional keyword arguments that may be used by subclasses.

        Raises:
            ValueError: When the boot options returned by the ``boot_options``
                method does not match the ``image_name`` after the config command(s)
                have been sent to the device.
        """
        raise NotImplementedError

    def show(self, command, raw_text=False):
        """Send a non-configuration command.

        Args:
            command (str): The command to send to the device.

        Keyword Args:
            raw_text (bool): Whether to return raw text or structured data.

        Returns:
            (NotImplementedError): The output of the show command, which could be raw text or structured data.
        """
        raise NotImplementedError

    @property
    def startup_config(self):
        """Return the startup configuration of the device."""
        raise NotImplementedError

    def feature(self, feature_name):
        """Return a feature class based on the ``feature_name`` for the appropriate subclassed device type."""
        try:
            feature_module = importlib.import_module(
                f"pyntc.devices.system_features.{feature_name}.{self.device_type}_{feature_name}"
            )
            return feature_module.instance(self)
        except ImportError as import_err:
            raise FeatureNotFoundError(feature_name, self.device_type) from import_err
        except AttributeError as att_err:
            raise AttributeError("Feature attribute error") from att_err

    def get_boot_options(self):
        """Get current boot variables like system image and kickstart image.

        Returns:
            (dict): A dictionary, e.g. {'kick': router_kick.img, 'sys': 'router_sys.img'}
        """
        warnings.warn("get_boot_options() is deprecated; use boot_options property.", DeprecationWarning)
        return self.boot_options

    def refresh(self):
        """Refresh caches on device instance."""
        self.refresh_facts()

    def refresh_facts(self):
        """Refresh cached facts."""
        # Persist values that were not added by facts getter
        if self.uptime:
            self._uptime = None

        if self.os_version:
            self._os_version = None

        if self.interfaces:
            self._interfaces = None

        if self.hostname:
            self._hostname = None

        if self.fqdn:
            self._fqdn = None

        if self.uptime_string:
            self._uptime_string = None

        if self.serial_number:
            self._serial_number = None

        if self.model:
            self._model = None

        if self.vlans:
            self._vlans = None


class RebootTimerError(NTCError):
    """Reboot timer error class to notify user reboot timer is not supported."""

    def __init__(self, device_type):
        """
        Error to notify user reboot timer is not supported.

        Args:
            device_type (str): Ex: cisco_nxos_nxapi, cisco_ios_ssh
        """
        super().__init__(f"Reboot timer not supported on {device_type}.")


class RollbackError(NTCError):
    """Rollback error."""


class SetBootImageError(NTCError):
    """Set boot image error."""
