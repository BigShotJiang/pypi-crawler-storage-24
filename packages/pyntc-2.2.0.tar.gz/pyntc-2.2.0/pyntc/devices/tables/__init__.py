"""Initialization for tables."""
