# Dataloop MCP Proxy Server

This is the main proxy for the Dataloop Micro MCPs, installable as a Python package.

## Installation

```shell
pip install git+<repository-url>
```

## Usage

You can run the proxy server via CLI:

```shell
# Basic usage (loads all system apps matching dataloop-mcp*)
dtlpymcp start

# With custom sources file (loads only sources from the file)
dtlpymcp start --sources-file /path/to/sources.json

# With custom sources file AND system apps (loads both)
dtlpymcp start --sources-file /path/to/sources.json --include-system-apps

# With custom initialization timeout (default: 30 seconds)
dtlpymcp start --init-timeout 60.0

# With custom log level
dtlpymcp start --log-level DEBUG
```

### Command Line Options

- `--sources-file`, `-s`: Path to a JSON file with MCP sources to load. When provided without `--include-system-apps`, only sources from the file are loaded.
- `--include-system-apps`, `-i`: When used with `--sources-file`, also loads system apps matching `dataloop-mcp*`. This allows you to merge custom sources with default system apps.
- `--init-timeout`, `-t`: Timeout in seconds for Dataloop context initialization (default: 30.0)
- `--log-level`, `-l`: Logging level - DEBUG, INFO, WARNING, ERROR, or CRITICAL (default: INFO)

Or using Python module syntax:

```shell
python -m dtlpymcp start
```

## Local Development

- Requires Python 3.10+
- Install dependencies with `pip install -e .`
- Run tests with `pytest`

## Architecture

The server uses a modular architecture with utilities for safe async initialization:

- `dtlpymcp/proxy.py` - Main server implementation using FastMCP
- `dtlpymcp/utils/server_utils.py` - Safe async initialization utilities
- `dtlpymcp/utils/dtlpy_context.py` - Dataloop context management

## Cursor MCP Integration

To add this MCP to Cursor, add the following to your configuration:

### Docker Example
```json
{
  "mcpServers": {
    "dataloop-ai-mcp": {
      "command": "docker run -i --rm -e DATALOOP_API_KEY docker.io/dataloopai/mcp:latest",
      "env": {
        "DATALOOP_API_KEY": "API KEY"
      }
    }
  }
}
```

### Local CLI Example
```json
{
  "mcpServers": {
    "dataloop-ai-mcp": {
      "command": "uvx",
      "args": ["dtlpymcp", "start"],
      "env": {
        "DATALOOP_ENV": "prod",
        "DATALOOP_API_KEY": "API KEY"
      }
    }
  }
}
```

Replace `API KEY` with your actual Dataloop API key.