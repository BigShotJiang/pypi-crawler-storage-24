from fastapi import FastAPI
from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.views.routers import auth, students, courses

app = FastAPI(
    title="Жоскиапикурсовтипачотка",
    description="Чоткоеописаниекурсатипачотко",
    version="Крутаяверсиячоткаяпрямужс"
)

app.include_router(auth.router)
app.include_router(students.router)
app.include_router(courses.router)
