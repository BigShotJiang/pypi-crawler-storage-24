from typing import Any
import bcrypt
from fastapi import Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import jwt
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .config import settings
from datetime import datetime, timezone, timedelta

from .database import get_db
from ..models.schemas.users import User

security = HTTPBearer()


def hash_password(password: str) -> str:
    pwd_bytes = password.encode('utf-8')[:72]
    return bcrypt.hashpw(pwd_bytes, bcrypt.gensalt()).decode('utf-8')


def verify_password(plain_password: str, hashed_password: str) -> bool:
    return bcrypt.checkpw(
        plain_password.encode('utf-8'),
        hashed_password.encode('utf-8')
    )


def create_access_token(subject: str | int, extra: dict[str, Any] | None = None) -> str:
    now = datetime.now(timezone.utc)
    expires = now + timedelta(minutes=5)
    payload = {
        'sub': str(subject),
        'exp': expires,
        'iat': now
    }
    if extra:
        payload.update(extra)
    return jwt.encode(
        payload,
        settings.SECRET_KEY,
        algorithm=settings.ALGORITM
    )


def decode_access_token(token: str) -> dict | None:
    try:
        return jwt.decode(
            token,
            settings.SECRET_KEY,
            algorithms=[settings.ALGORITM]
        )
    except jwt.PyJWTError:
        return None


async def get_current_user(
        credentials: HTTPAuthorizationCredentials = Depends(security),
        db: AsyncSession = Depends(get_db)
) -> User:
    payload = decode_access_token(credentials.credentials)

    if not payload or 'sub' not in payload:
        raise ValueError('Недействительный или истекший токен')

    user_id = int(payload['sub'])
    result = await db.execute(
        select(User).where(User.id == user_id)
    )
    user = result.scalar_one_or_none()
    if not user:
        raise ValueError('Пользователь не найден')
    return user
