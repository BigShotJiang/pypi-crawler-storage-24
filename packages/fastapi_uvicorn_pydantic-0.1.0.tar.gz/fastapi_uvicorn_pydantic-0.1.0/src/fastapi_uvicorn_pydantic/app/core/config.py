from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    DATABASE_URL: str = 'sqlite+aiosqlite:///./database.db'
    SECRET_KEY: str = 'super-secret-key'
    ALGORITM: str = 'HS256'


settings = Settings()
