from typing import Optional
from pydantic import BaseModel, Field, EmailStr, ConfigDict


class StudentResponse(BaseModel):
    id: int
    name: str
    age: int
    email: EmailStr
    course_id: int

    model_config = ConfigDict(from_attributes=True)


class StudentCreate(BaseModel):
    name: str = Field(..., min_length=5, max_length=100)
    age: int = Field(..., ge=16, le=100)
    email: EmailStr
    course_id: int


class StudentUpdate(BaseModel):
    name: Optional[str] = Field(None, min_length=5, max_length=100)
    age: Optional[int] = Field(None, ge=16, le=100)
    email: Optional[EmailStr] = None
    course_id: Optional[int] = None
