from pydantic import BaseModel, EmailStr, ConfigDict


class UserRegistration(BaseModel):
    username: str
    email: EmailStr
    password: str


class UserLogin(BaseModel):
    username: str
    password: str


class UserResponse(BaseModel):
    user_id: int
    access_token: str

    model_config = ConfigDict(from_attributes=True)
