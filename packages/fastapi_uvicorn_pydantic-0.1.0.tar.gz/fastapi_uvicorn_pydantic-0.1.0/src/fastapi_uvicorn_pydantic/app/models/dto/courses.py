from typing import Optional
from pydantic import BaseModel, Field, ConfigDict


class CourseResponse(BaseModel):
    id: int
    title: str
    description: str
    category: str
    duration_hours: int

    model_config = ConfigDict(from_attributes=True)


class CourseCreate(BaseModel):
    title: str = Field(..., min_length=3, max_length=100)
    description: str = Field(..., min_length=10, max_length=300)
    category: str = Field(..., min_length=3, max_length=50)
    duration_hours: int = Field(..., ge=1)


class CourseUpdate(BaseModel):
    title: Optional[str] = Field(None, min_length=3, max_length=100)
    description: Optional[str] = Field(None, min_length=10, max_length=300)
    category: Optional[str] = Field(None, min_length=3, max_length=50)
    duration_hours: Optional[int] = Field(None, ge=0)
