from sqlalchemy import String, Column, DateTime, Integer
from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.core.database import Base


class User(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True, index=True, nullable=False)
    username = Column(String, nullable=False, unique=True)
    email = Column(String, nullable=False, unique=True)
    hashed_password = Column(String, nullable=False)
