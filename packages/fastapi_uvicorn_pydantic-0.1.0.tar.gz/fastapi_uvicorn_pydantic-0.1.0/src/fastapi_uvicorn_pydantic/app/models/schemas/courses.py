from sqlalchemy import Column, String, Text, Integer, DateTime, ForeignKey
from sqlalchemy.orm import relationship
from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.core.database import Base


class Course(Base):
    __tablename__ = 'courses'

    id = Column(Integer, primary_key=True, index=True, nullable=False)
    title = Column(String(255), nullable=False)
    description = Column(Text, nullable=False)
    category = Column(String, nullable=False)
    duration_hours = Column(Integer, nullable=False)

    students = relationship("Student", back_populates="course", cascade="all, delete-orphan")
