from sqlalchemy import String, Column, ForeignKey, Text, Integer
from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.core.database import Base
from sqlalchemy.orm import relationship


class Student(Base):
    __tablename__ = 'students'

    id = Column(Integer, primary_key=True, index=True, nullable=False)
    name = Column(String(255), nullable=False)
    age = Column(Integer, nullable=False)
    email = Column(String(255), nullable=False, unique=True)
    course_id = Column(Integer, ForeignKey('courses.id'), nullable=False)

    course = relationship('Course', back_populates='students')
