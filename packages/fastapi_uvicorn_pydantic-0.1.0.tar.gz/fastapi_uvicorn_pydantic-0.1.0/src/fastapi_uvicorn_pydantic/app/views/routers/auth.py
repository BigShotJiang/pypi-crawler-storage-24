from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession

from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.models.dto.users import UserResponse, UserLogin, UserRegistration
from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.views.services.auth import UserService
from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.core.database import get_db

router = APIRouter(
    prefix='/auth',
    tags=['auth']
)


@router.post('/register', response_model=UserResponse)
async def register(
        user_data: UserRegistration,
        db: AsyncSession = Depends(get_db)
):
    service = UserService(db)
    try:
        user = await service.registration(user_data)
        return user
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(e)
        )


@router.post('/login', response_model=UserResponse)
async def login(
        user_data: UserLogin,
        db: AsyncSession = Depends(get_db)
):
    service = UserService(db)
    try:
        user = await service.login(user_data)
        return user
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail=str(e)
        )
