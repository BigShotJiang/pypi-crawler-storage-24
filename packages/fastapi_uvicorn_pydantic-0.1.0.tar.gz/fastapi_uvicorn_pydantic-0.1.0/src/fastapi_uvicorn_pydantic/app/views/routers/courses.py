from fastapi import APIRouter, status, HTTPException, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession

from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.core.auth import get_current_user
from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.core.database import get_db
from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.models.schemas.users import User
from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.views.services.courses import CourseService
from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.models.dto.courses import CourseUpdate, CourseCreate, CourseResponse

router = APIRouter(
    prefix='/courses',
    tags=['courses']
)


@router.get('/', response_model=list[CourseResponse])
async def course_list(
        category: str = Query(None, min_length=3, max_length=50),
        min_duration: int = Query(None, ge=1),
        max_duration: int = Query(None, ge=1),
        search: str = Query(None),
        db: AsyncSession = Depends(get_db),
        user: User = Depends(get_current_user)
):
    service = CourseService(db)
    courses = await service.list_course(
        category=category,
        min_duration=min_duration,
        max_duration=max_duration,
        search=search
    )
    return courses


@router.get('/{course_id}', response_model=CourseResponse)
async def course_detail(
        course_id: int,
        db: AsyncSession = Depends(get_db),
        user: User = Depends(get_current_user)
):
    service = CourseService(db)
    try:
        courses = await service.get_course_by_id(course_id)
        return courses
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.post('/', response_model=CourseResponse, status_code=status.HTTP_201_CREATED)
async def course_create(
        course_data: CourseCreate,
        db: AsyncSession = Depends(get_db),
        user: User = Depends(get_current_user)
):
    service = CourseService(db)
    try:
        course = await service.create_course(course_data)
        return course
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.patch('/{course_id}', response_model=CourseResponse)
async def course_update(
        course_id: int,
        course_data: CourseUpdate,
        db: AsyncSession = Depends(get_db),
        user: User = Depends(get_current_user)
):
    service = CourseService(db)
    try:
        course = await service.update_course(course_id, course_data)
        return course
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.delete('/{course_id}', status_code=status.HTTP_204_NO_CONTENT)
async def course_delete(
        course_id: int,
        db: AsyncSession = Depends(get_db),
        user: User = Depends(get_current_user)
):
    service = CourseService(db)
    await service.delete_course(course_id)


@router.get("/{course_id}/students")
async def course_students(
        course_id: int,
        db: AsyncSession = Depends(get_db),
        user: User = Depends(get_current_user)
):
    service = CourseService(db)
    return await service.get_course_students(course_id)
