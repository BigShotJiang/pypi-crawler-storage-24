from fastapi import APIRouter, status, HTTPException, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.core.auth import get_current_user
from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.core.database import get_db
from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.models.schemas.users import User
from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.views.services.students import StudentService
from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.models.dto.students import StudentResponse, StudentCreate, StudentUpdate

router = APIRouter(
    prefix='/students',
    tags=['students']
)


@router.get('/', response_model=list[StudentResponse])
async def student_list(
        min_age: int = Query(None, ge=16, le=100),
        max_age: int = Query(None, ge=16, le=100),
        db: AsyncSession = Depends(get_db),
        user: User = Depends(get_current_user)
):
    service = StudentService(db)
    students = await service.list_student(
        min_age=min_age,
        max_age=max_age
    )
    return students


@router.get('/{student_id}', response_model=StudentResponse)
async def student_detail(
        student_id: int,
        db: AsyncSession = Depends(get_db),
        user: User = Depends(get_current_user)
):
    service = StudentService(db)
    try:
        students = await service.get_student_by_id(student_id)
        return students
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(e)
        )


@router.post('/', response_model=StudentResponse, status_code=status.HTTP_201_CREATED)
async def students_create(
        student_data: StudentCreate,
        db: AsyncSession = Depends(get_db),
        user: User = Depends(get_current_user)
):
    service = StudentService(db)
    try:
        students = await service.create_student(student_data)
        return students
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.patch('/{student_id}', response_model=StudentResponse)
async def students_update(
        student_id: int,
        student_data: StudentUpdate,
        db: AsyncSession = Depends(get_db),
        user: User = Depends(get_current_user)
):
    service = StudentService(db)
    try:
        students = await service.update_student(student_data, student_id)
        return students
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e)
        )


@router.delete('/{student_id}', status_code=status.HTTP_204_NO_CONTENT)
async def student_delete(
        student_id: int,
        db: AsyncSession = Depends(get_db),
        user: User = Depends(get_current_user)
):
    service = StudentService(db)
    await service.delete_student(student_id)


@router.get("/{student_id}/course")
async def student_course(
        student_id: int,
        db: AsyncSession = Depends(get_db),
        user: User = Depends(get_current_user)
):
    service = StudentService(db)
    return await service.get_student_course(student_id)
