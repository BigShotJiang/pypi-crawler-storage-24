from typing import Optional
from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.models.dto.students import StudentCreate, StudentUpdate
from sqlalchemy import select, update, delete
from sqlalchemy.ext.asyncio import AsyncSession

from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.models.schemas.courses import Course
from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.models.schemas.students import Student


class StudentService:

    def __init__(self, db: AsyncSession):
        self.db = db

    async def list_student(self, min_age: Optional[int] = None, max_age: Optional[int] = None):

        query = select(Student)

        if min_age is not None:
            query = query.where(Student.age >= min_age)

        if max_age is not None:
            query = query.where(Student.age <= max_age)

        result = await self.db.execute(query)
        return result.scalars().all()

    async def create_student(self, student_data: StudentCreate):
        query = await self.db.execute(
            select(Course).where(Course.id == student_data.course_id)
        )

        course = query.scalar_one_or_none()
        if not course:
            raise ValueError(f'Курс под айди {student_data.course_id} не существует')

        student = Student(**student_data.model_dump())
        self.db.add(student)
        await self.db.commit()
        await self.db.refresh(student)
        return student

    async def get_student_by_id(self, student_id: int):
        result = await self.db.execute(
            select(Student).where(Student.id == student_id)
        )
        return result.scalar_one_or_none()

    async def update_student(self, student_data: StudentUpdate, student_id: int):
        updated_data = student_data.model_dump(exclude_unset=True)
        if updated_data:
            if 'course_id' in updated_data:
                course_id = updated_data['course_id']
                course_check = await self.db.execute(
                    select(Course).where(Course.id == student_data.course_id)
                )
                if not course_check.scalar_one_or_none():
                    raise ValueError(f'Курс под айди {student_data.course_id} не существует')

            await self.db.execute(
                update(Student).where(Student.id == student_id).values(**updated_data)
            )
            await self.db.commit()

        return await self.get_student_by_id(student_id)

    async def delete_student(self, student_id: int):
        await self.db.execute(
            delete(Student).where(Student.id == student_id)
        )
        await self.db.commit()

    async def get_student_course(self, student_id: int):
        result = await self.db.execute(
            select(Student).where(Student.id == student_id)
        )

        student = result.scalar_one_or_none()

        if not student:
            raise ValueError("Student not found")

        result = await self.db.execute(
            select(Course).where(Course.id == student.course_id)
        )

        return result.scalar_one_or_none()
