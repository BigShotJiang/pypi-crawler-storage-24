from fastapi import Depends
from fastapi.security import HTTPAuthorizationCredentials
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.core.auth import hash_password, create_access_token, verify_password
from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.models.dto.users import UserResponse, UserRegistration, UserLogin
from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.models.schemas.users import User


class UserService:

    def __init__(self, db: AsyncSession):
        self.db = db

    async def registration(self, user_data: UserRegistration) -> UserResponse:
        result = await self.db.execute(
            select(User).where(
                (User.username == user_data.username) | (User.email == user_data.email)
            )
        )

        if result.scalar_one_or_none():
            raise ValueError('Пользователь с таким никнеймом / почтой уже есть')

        hashed_password = hash_password(user_data.password)
        user = User(
            username=user_data.username,
            email=user_data.email,
            hashed_password=hashed_password
        )
        self.db.add(user)
        await self.db.commit()
        await self.db.refresh(user)

        token = create_access_token(
            subject=user.id,
            extra={'username': user.username}
        )
        return UserResponse(
            access_token=token,
            user_id=user.id
        )

    async def login(self, user_data: UserLogin) -> UserResponse:
        result = await self.db.execute(
            select(User).where(User.username == user_data.username)
        )

        user = result.scalar_one_or_none()

        if not user or not verify_password(user_data.password, user.hashed_password):
            raise ValueError('Пользователь с такими учетными данными не существует')

        token = create_access_token(
            subject=user.id,
            extra={'username': user.username}
        )

        return UserResponse(
            access_token=token,
            user_id=user.id
        )
