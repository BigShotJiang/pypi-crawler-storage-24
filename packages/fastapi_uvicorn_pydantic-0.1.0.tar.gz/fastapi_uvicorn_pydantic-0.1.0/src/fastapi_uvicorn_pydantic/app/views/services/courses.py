from typing import Optional

from sqlalchemy import select, update, delete
from sqlalchemy.ext.asyncio import AsyncSession

from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.models.schemas.courses import Course
from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.models.dto.courses import CourseCreate, CourseUpdate
from fastapi_uvicorn_pydantic_project.src.fastapi_uvicorn_pydantic.app.models.schemas.students import Student


class CourseService:

    def __init__(self, db: AsyncSession):
        self.db = db

    async def list_course(self,
                          category: Optional[str] = None,
                          min_duration: Optional[int] = None,
                          max_duration: Optional[int] = None,
                          search: Optional[str] = None
                          ):
        query = select(Course)

        if category is not None:
            query = query.where(Course.category == category)
        if min_duration is not None:
            query = query.where(Course.duration_hours >= min_duration)
        if max_duration is not None:
            query = query.where(Course.duration_hours <= max_duration)
        if search is not None:
            query = query.where(Course.title.ilike(f'%{search}%'))

        result = await self.db.execute(query)
        return result.scalars().all()

    async def get_course_by_id(self, course_id: int):
        result = await self.db.execute(
            select(Course).where(Course.id == course_id)
        )
        return result.scalar_one_or_none()

    async def create_course(self, course_data: CourseCreate):
        course = Course(**course_data.model_dump())
        self.db.add(course)
        await self.db.commit()
        await self.db.refresh(course)
        return course

    async def update_course(self, course_id: int, course_data: CourseUpdate):
        updated_data = course_data.model_dump(exclude_unset=True)

        await self.db.execute(
            update(Course).where(Course.id == course_id).values(**updated_data)
        )
        await self.db.commit()

        return await self.get_course_by_id(course_id)

    async def delete_course(self, course_id: int):

        await self.db.execute(
            delete(Course).where(Course.id == course_id)
        )

        await self.db.commit()

    async def get_course_students(self, course_id: int):
        result = await self.db.execute(
            select(Student).where(Student.course_id == course_id)
        )
        return result.scalars().all()
