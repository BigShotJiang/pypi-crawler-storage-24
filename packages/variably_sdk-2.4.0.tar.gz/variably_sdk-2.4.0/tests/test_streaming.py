"""
Unit tests for Variably Python SDK streaming functionality.
"""

import json
import pytest
from unittest.mock import Mock, MagicMock, patch
from io import BytesIO

import sys
import os

# Ensure the src directory is on the path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

from variably.types import StreamingEvaluateResponse, EvaluateResponse


class FakeSSEResponse:
    """Mock requests.Response that yields SSE lines."""

    def __init__(self, lines: list[str]):
        self._lines = lines
        self._closed = False

    def iter_lines(self, decode_unicode=True):
        for line in self._lines:
            yield line

    def close(self):
        self._closed = True


class TestStreamingEvaluateResponse:
    """Tests for StreamingEvaluateResponse iterator."""

    def test_yields_token_content(self):
        """Should yield token strings from SSE stream."""
        lines = [
            "event: variant",
            'data: {"experiment_id":"exp-1","variant_id":"var-1"}',
            "",
            "event: token",
            'data: {"content":"Hello"}',
            "",
            "event: token",
            'data: {"content":" world"}',
            "",
            "event: token",
            'data: {"content":"!"}',
            "",
            "event: done",
            "data: {}",
        ]

        stream = StreamingEvaluateResponse(FakeSSEResponse(lines))
        tokens = list(stream)

        assert tokens == ["Hello", " world", "!"]

    def test_metadata_available_after_iteration(self):
        """Should populate metadata from metadata SSE event."""
        lines = [
            "event: token",
            'data: {"content":"Hi"}',
            "",
            "event: metadata",
            'data: {"execution_id":"exec-1","experiment_id":"exp-1","variant_id":"var-1","model":"claude-3-haiku","provider":"anthropic","prompt_tokens":10,"completion_tokens":1,"total_tokens":11,"latency_ms":120}',
            "",
            "event: done",
            "data: {}",
        ]

        stream = StreamingEvaluateResponse(FakeSSEResponse(lines))
        tokens = list(stream)

        assert tokens == ["Hi"]
        assert stream.metadata is not None
        assert stream.metadata.execution_id == "exec-1"
        assert stream.metadata.model == "claude-3-haiku"
        assert stream.metadata.latency_ms == 120
        assert stream.metadata.content == "Hi"

    def test_handles_error_event(self):
        """Should raise exception on error SSE event."""
        lines = [
            "event: token",
            'data: {"content":"partial"}',
            "",
            "event: error",
            'data: {"message":"Rate limit exceeded"}',
        ]

        stream = StreamingEvaluateResponse(FakeSSEResponse(lines))

        # First token should work
        assert next(stream) == "partial"

        # Error event should raise
        with pytest.raises(Exception, match="Rate limit exceeded"):
            next(stream)

    def test_handles_empty_stream(self):
        """Should handle empty stream gracefully."""
        lines = [
            "event: done",
            "data: {}",
        ]

        stream = StreamingEvaluateResponse(FakeSSEResponse(lines))
        tokens = list(stream)

        assert tokens == []

    def test_skips_empty_token_content(self):
        """Should skip tokens with empty content."""
        lines = [
            "event: token",
            'data: {"content":""}',
            "",
            "event: token",
            'data: {"content":"real"}',
            "",
            "event: done",
            "data: {}",
        ]

        stream = StreamingEvaluateResponse(FakeSSEResponse(lines))
        tokens = list(stream)

        # Empty content tokens are skipped (content is falsy)
        assert tokens == ["real"]

    def test_handles_malformed_json(self):
        """Should skip malformed JSON data lines."""
        lines = [
            "event: token",
            "data: not-json",
            "",
            "event: token",
            'data: {"content":"valid"}',
            "",
            "event: done",
            "data: {}",
        ]

        stream = StreamingEvaluateResponse(FakeSSEResponse(lines))
        tokens = list(stream)

        assert tokens == ["valid"]

    def test_close_stops_iteration(self):
        """Closing the stream should stop iteration."""
        fake = FakeSSEResponse([
            "event: token",
            'data: {"content":"before close"}',
        ])
        stream = StreamingEvaluateResponse(fake)

        stream.close()
        tokens = list(stream)

        assert tokens == []
        assert fake._closed is True

    def test_consumed_stream_raises_stop_iteration(self):
        """After consumption, iterating again should immediately stop."""
        lines = [
            "event: done",
            "data: {}",
        ]

        stream = StreamingEvaluateResponse(FakeSSEResponse(lines))
        list(stream)  # Consume

        # Iterating again should immediately stop
        assert list(stream) == []

    def test_multiline_streaming(self):
        """Should handle many tokens correctly."""
        token_lines = []
        expected_tokens = []
        for i in range(50):
            token = f"token{i}"
            expected_tokens.append(token)
            token_lines.extend([
                "event: token",
                f'data: {{"content":"{token}"}}',
                "",
            ])
        token_lines.extend(["event: done", "data: {}"])

        stream = StreamingEvaluateResponse(FakeSSEResponse(token_lines))
        tokens = list(stream)

        assert tokens == expected_tokens
        assert len(tokens) == 50


class TestStreamingClientIntegration:
    """Tests for the client.evaluate_prompt_stream() method."""

    def test_evaluate_prompt_stream_returns_iterator(self):
        """Should return a StreamingEvaluateResponse from evaluate_prompt_stream."""
        from variably.client import VariablyClient

        with patch('variably.http_client.HTTPClient.evaluate_prompt_stream') as mock_http:
            fake_response = FakeSSEResponse([
                "event: token",
                'data: {"content":"test"}',
                "",
                "event: done",
                "data: {}",
            ])
            mock_http.return_value = fake_response

            client = VariablyClient({
                "api_key": "test_key",
                "base_url": "http://localhost:8080",
            })

            stream = client.evaluate_prompt_stream(
                experiment_key="test-exp",
                user_context={"user_id": "user1"},
                input_variables={"query": "hello"},
            )

            assert isinstance(stream, StreamingEvaluateResponse)
            tokens = list(stream)
            assert tokens == ["test"]

    def test_evaluate_prompt_stream_validates_inputs(self):
        """Should raise an error for missing required parameters."""
        from variably.client import VariablyClient

        client = VariablyClient({
            "api_key": "test_key",
            "base_url": "http://localhost:8080",
        })

        with pytest.raises(Exception, match="[Ee]xperiment"):
            client.evaluate_prompt_stream(
                experiment_key="",
                user_context={"user_id": "user1"},
                input_variables={},
            )

        with pytest.raises(Exception, match="[Uu]ser"):
            client.evaluate_prompt_stream(
                experiment_key="test-exp",
                user_context={},
                input_variables={},
            )
