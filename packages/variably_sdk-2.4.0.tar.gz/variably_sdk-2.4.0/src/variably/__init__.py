"""
Variably Python SDK

Official Python SDK for Variably feature flags and experimentation platform.
"""

from .client import VariablyClient
from .config import VariablyConfig
from .types import UserContext, Event, FlagResult, PromptVariant, EvaluateResponse, StreamingEvaluateResponse, SubmitResponseResult
from .errors import (
    VariablyError,
    NetworkError,
    AuthenticationError,
    ValidationError,
    RateLimitError,
    TimeoutError,
    ConfigurationError,
)
from .version import __version__

__all__ = [
    "VariablyClient",
    "VariablyConfig",
    "UserContext",
    "Event",
    "FlagResult",
    "PromptVariant",
    "EvaluateResponse",
    "StreamingEvaluateResponse",
    "SubmitResponseResult",
    "VariablyError",
    "NetworkError",
    "AuthenticationError",
    "ValidationError",
    "RateLimitError",
    "TimeoutError",
    "ConfigurationError",
    "__version__",
]