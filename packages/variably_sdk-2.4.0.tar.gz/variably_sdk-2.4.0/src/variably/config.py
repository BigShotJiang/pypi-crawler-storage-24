"""Configuration for Variably SDK."""

import os
from typing import Optional

from .types import CacheConfig


class VariablyConfig:
    """Configuration for Variably client."""
    
    def __init__(
        self,
        api_key: str,
        base_url: Optional[str] = None,
        environment: Optional[str] = None,
        timeout: int = 5000,
        retry_attempts: int = 3,
        enable_analytics: bool = True,
        cache: Optional[CacheConfig] = None,
        log_level: str = "INFO",
    ):
        """
        Initialize Variably configuration.
        
        Args:
            api_key: API key for authentication
            base_url: Base URL for the API (default: http://localhost:8080)
            environment: Environment name (development, staging, production)
            timeout: Request timeout in milliseconds (default: 5000)
            retry_attempts: Number of retry attempts (default: 3)
            enable_analytics: Whether to enable analytics tracking (default: True)
            cache: Cache configuration (default: enabled with 5min TTL)
            log_level: Logging level (DEBUG, INFO, WARNING, ERROR)
        """
        if not api_key:
            raise ValueError("API key is required")
        
        self.api_key = api_key
        self.base_url = base_url or "http://localhost:8080"
        self.environment = environment or "development"
        self.timeout = timeout / 1000.0  # Convert to seconds
        self.retry_attempts = retry_attempts
        self.enable_analytics = enable_analytics
        self.log_level = log_level.upper()
        
        # Default cache configuration
        self.cache = cache or CacheConfig(
            ttl=300,  # 5 minutes in seconds
            max_size=1000,
            enabled=True
        )
        
        # Remove trailing slash from base_url
        self.base_url = self.base_url.rstrip("/")
    
    @classmethod
    def from_env(cls) -> "VariablyConfig":
        """
        Create configuration from environment variables.
        
        Environment variables:
        - VARIABLY_API_KEY (required)
        - VARIABLY_BASE_URL
        - VARIABLY_ENVIRONMENT
        - VARIABLY_TIMEOUT
        - VARIABLY_RETRY_ATTEMPTS
        - VARIABLY_ENABLE_ANALYTICS
        - VARIABLY_LOG_LEVEL
        """
        api_key = os.getenv("VARIABLY_API_KEY")
        if not api_key:
            raise ValueError("VARIABLY_API_KEY environment variable is required")
        
        base_url = os.getenv("VARIABLY_BASE_URL")
        environment = os.getenv("VARIABLY_ENVIRONMENT")
        
        timeout = int(os.getenv("VARIABLY_TIMEOUT", "5000"))
        retry_attempts = int(os.getenv("VARIABLY_RETRY_ATTEMPTS", "3"))
        enable_analytics = os.getenv("VARIABLY_ENABLE_ANALYTICS", "true").lower() != "false"
        log_level = os.getenv("VARIABLY_LOG_LEVEL", "INFO")
        
        return cls(
            api_key=api_key,
            base_url=base_url,
            environment=environment,
            timeout=timeout,
            retry_attempts=retry_attempts,
            enable_analytics=enable_analytics,
            log_level=log_level,
        )
    
    def __repr__(self) -> str:
        return (
            f"VariablyConfig(base_url='{self.base_url}', "
            f"environment='{self.environment}', "
            f"timeout={self.timeout}s, "
            f"retry_attempts={self.retry_attempts})"
        )