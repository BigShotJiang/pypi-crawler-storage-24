"""Cache management for Variably SDK."""

import threading
import time
from typing import Any, Dict, Optional

from .types import CacheConfig


class CacheEntry:
    """Cache entry with TTL support."""
    
    def __init__(self, value: Any, ttl: int):
        self.value = value
        self.timestamp = time.time()
        self.ttl = ttl
    
    def is_expired(self) -> bool:
        """Check if cache entry has expired."""
        return time.time() - self.timestamp > self.ttl


class CacheManager:
    """Thread-safe in-memory cache manager."""
    
    def __init__(self, config: CacheConfig):
        self.config = config
        self.cache: Dict[str, CacheEntry] = {}
        self.lock = threading.RLock()
        self._cleanup_thread: Optional[threading.Thread] = None
        self._stop_cleanup = threading.Event()
        
        if config.get("enabled", True):
            self._start_cleanup_thread()
    
    def get(self, key: str) -> Optional[Any]:
        """Get value from cache."""
        if not self.config.get("enabled", True):
            return None
        
        with self.lock:
            entry = self.cache.get(key)
            if entry is None:
                return None
            
            if entry.is_expired():
                del self.cache[key]
                return None
            
            return entry.value
    
    def set(self, key: str, value: Any, custom_ttl: Optional[int] = None) -> None:
        """Set value in cache."""
        if not self.config.get("enabled", True):
            return
        
        ttl = custom_ttl or self.config.get("ttl", 300)
        max_size = self.config.get("max_size", 1000)
        
        with self.lock:
            # Enforce max size by removing oldest entries
            while len(self.cache) >= max_size:
                self._evict_oldest()
            
            self.cache[key] = CacheEntry(value, ttl)
    
    def delete(self, key: str) -> bool:
        """Remove value from cache."""
        with self.lock:
            return self.cache.pop(key, None) is not None
    
    def clear(self) -> None:
        """Clear all cache entries."""
        with self.lock:
            self.cache.clear()
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics."""
        with self.lock:
            return {
                "size": len(self.cache),
                "max_size": self.config.get("max_size", 1000),
                "enabled": self.config.get("enabled", True),
                "ttl": self.config.get("ttl", 300),
            }
    
    def _evict_oldest(self) -> None:
        """Remove the oldest cache entry."""
        if not self.cache:
            return
        
        oldest_key = min(self.cache.keys(), key=lambda k: self.cache[k].timestamp)
        del self.cache[oldest_key]
    
    def _cleanup_expired(self) -> None:
        """Remove expired entries from cache."""
        with self.lock:
            expired_keys = [
                key for key, entry in self.cache.items() if entry.is_expired()
            ]
            for key in expired_keys:
                del self.cache[key]
    
    def _start_cleanup_thread(self) -> None:
        """Start background thread for cleanup."""
        
        def cleanup_worker():
            while not self._stop_cleanup.wait(60):  # Check every minute
                self._cleanup_expired()
        
        self._cleanup_thread = threading.Thread(target=cleanup_worker, daemon=True)
        self._cleanup_thread.start()
    
    def shutdown(self) -> None:
        """Shutdown cache and cleanup thread."""
        if self._cleanup_thread:
            self._stop_cleanup.set()
            self._cleanup_thread.join(timeout=1)
        self.clear()


class NoOpCache:
    """No-op cache implementation that doesn't cache anything."""
    
    def get(self, key: str) -> Optional[Any]:
        return None
    
    def set(self, key: str, value: Any, custom_ttl: Optional[int] = None) -> None:
        pass
    
    def delete(self, key: str) -> bool:
        return False
    
    def clear(self) -> None:
        pass
    
    def get_stats(self) -> Dict[str, Any]:
        return {
            "size": 0,
            "max_size": 0,
            "enabled": False,
            "ttl": 0,
        }
    
    def shutdown(self) -> None:
        pass