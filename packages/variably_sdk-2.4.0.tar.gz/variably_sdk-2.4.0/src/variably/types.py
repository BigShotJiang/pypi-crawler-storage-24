"""Type definitions for Variably SDK."""

from datetime import datetime
from typing import Any, Dict, Optional, Union

try:
    from typing import TypedDict
except ImportError:
    # For Python < 3.8
    from typing_extensions import TypedDict


class UserContext(TypedDict, total=False):
    """User context for feature flag evaluation."""
    
    user_id: str  # Required
    email: Optional[str]
    country: Optional[str]
    language: Optional[str]
    platform: Optional[str]
    version: Optional[str]
    ip_address: Optional[str]
    user_agent: Optional[str]
    attributes: Optional[Dict[str, Any]]
    session_id: Optional[str]


class Event(TypedDict, total=False):
    """Event data for analytics tracking."""
    
    name: str  # Required
    user_id: str  # Required
    properties: Optional[Dict[str, Any]]
    timestamp: Optional[datetime]
    context: Optional[UserContext]
    session_id: Optional[str]


class FlagResult:
    """Result of feature flag evaluation."""
    
    def __init__(
        self,
        key: str,
        value: Any,
        reason: str,
        rule_id: Optional[str] = None,
        variation: Optional[str] = None,
        cache_hit: bool = False,
        evaluated_at: Optional[datetime] = None,
        error: Optional[Exception] = None,
    ):
        self.key = key
        self.value = value
        self.reason = reason
        self.rule_id = rule_id
        self.variation = variation
        self.cache_hit = cache_hit
        self.evaluated_at = evaluated_at or datetime.utcnow()
        self.error = error
    
    def __repr__(self) -> str:
        return (
            f"FlagResult(key='{self.key}', value={self.value}, "
            f"reason='{self.reason}', cache_hit={self.cache_hit})"
        )


class CacheConfig(TypedDict, total=False):
    """Configuration for caching."""
    
    ttl: int  # TTL in seconds
    max_size: int  # Maximum number of cached items
    enabled: bool  # Whether caching is enabled


class SDKMetrics:
    """SDK performance and usage metrics."""
    
    def __init__(self):
        self.api_calls: int = 0
        self.cache_hits: int = 0
        self.cache_misses: int = 0
        self.errors: int = 0
        self.latencies: list[float] = []
        self.flags_evaluated: int = 0
        self.gates_evaluated: int = 0
        self.events_tracked: int = 0
        self.start_time: datetime = datetime.utcnow()
    
    @property
    def average_latency(self) -> float:
        """Calculate average API latency in milliseconds."""
        if not self.latencies:
            return 0.0
        return sum(self.latencies) / len(self.latencies)
    
    @property
    def cache_hit_rate(self) -> float:
        """Calculate cache hit rate (0.0 to 1.0)."""
        total_cache_operations = self.cache_hits + self.cache_misses
        if total_cache_operations == 0:
            return 0.0
        return self.cache_hits / total_cache_operations
    
    @property
    def error_rate(self) -> float:
        """Calculate error rate (0.0 to 1.0)."""
        total_operations = self.flags_evaluated + self.gates_evaluated
        if total_operations == 0:
            return 0.0
        return self.errors / total_operations
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert metrics to dictionary."""
        return {
            "api_calls": self.api_calls,
            "cache_hits": self.cache_hits,
            "cache_misses": self.cache_misses,
            "errors": self.errors,
            "average_latency": self.average_latency,
            "cache_hit_rate": self.cache_hit_rate,
            "error_rate": self.error_rate,
            "flags_evaluated": self.flags_evaluated,
            "gates_evaluated": self.gates_evaluated,
            "events_tracked": self.events_tracked,
            "start_time": self.start_time.isoformat(),
            "uptime_seconds": (datetime.utcnow() - self.start_time).total_seconds(),
        }


# API Request/Response types
class FlagEvaluationRequest(TypedDict):
    """Request for flag evaluation."""
    
    flag_key: str
    context: UserContext


class FlagEvaluationResponse(TypedDict):
    """Response from flag evaluation."""
    
    flag_key: str
    value: Any
    reason: str
    rule_id: Optional[str]


class GateEvaluationRequest(TypedDict):
    """Request for gate evaluation."""
    
    gate_key: str
    context: UserContext


class GateEvaluationResponse(TypedDict):
    """Response from gate evaluation."""
    
    gate_key: str
    value: bool
    reason: str
    rule_id: Optional[str]
    environment: str


class EventTrackingRequest(TypedDict, total=False):
    """Request for event tracking."""
    
    name: str
    user_id: str
    properties: Optional[Dict[str, Any]]
    timestamp: datetime


class BatchFlagEvaluationRequest(TypedDict):
    """Request for batch flag evaluation."""
    
    flag_keys: list[str]
    context: UserContext


class BatchFlagEvaluationResponse(TypedDict):
    """Response from batch flag evaluation."""

    results: Dict[str, FlagEvaluationResponse]


class PromptVariant:
    """Result from get-variant endpoint."""

    def __init__(
        self,
        experiment_id: str,
        experiment_key: str,
        variant_id: str,
        variant_key: str,
        prompt_template: str,
        model: str,
        provider: str,
        parameters: Dict[str, Any],
        is_control: bool,
    ):
        self.experiment_id = experiment_id
        self.experiment_key = experiment_key
        self.variant_id = variant_id
        self.variant_key = variant_key
        self.prompt_template = prompt_template
        self.model = model
        self.provider = provider
        self.parameters = parameters
        self.is_control = is_control

    def __repr__(self) -> str:
        return (
            f"PromptVariant(experiment_key='{self.experiment_key}', "
            f"variant_key='{self.variant_key}', model='{self.model}', "
            f"is_control={self.is_control})"
        )


class EvaluateResponse:
    """Result from managed execution endpoint."""

    def __init__(
        self,
        execution_id: str,
        experiment_id: str,
        variant_id: str,
        content: str,
        model: str,
        provider: str,
        token_usage: Dict[str, int],
        latency_ms: int,
        quality_score: Optional[float] = None,
    ):
        self.execution_id = execution_id
        self.experiment_id = experiment_id
        self.variant_id = variant_id
        self.content = content
        self.model = model
        self.provider = provider
        self.token_usage = token_usage
        self.latency_ms = latency_ms
        self.quality_score = quality_score

    def __repr__(self) -> str:
        return (
            f"EvaluateResponse(execution_id='{self.execution_id}', "
            f"model='{self.model}', latency_ms={self.latency_ms})"
        )


class StreamingEvaluateResponse:
    """Iterator that yields token strings from streaming evaluation.

    Usage:
        stream = client.evaluate_prompt_stream("exp-key", user_ctx, {"query": "hello"})
        for token in stream:
            print(token, end="", flush=True)
        # After iteration completes:
        print(stream.metadata)  # EvaluateResponse with token_usage, latency, etc.
    """

    def __init__(self, raw_response: Any):
        self._response = raw_response
        self._lines_iter = raw_response.iter_lines(decode_unicode=True)
        self._metadata: Optional["EvaluateResponse"] = None
        self._content_parts: list = []
        self._consumed = False

    def __iter__(self) -> "StreamingEvaluateResponse":
        return self

    def __next__(self) -> str:
        if self._consumed:
            raise StopIteration

        import json
        event_type = ""

        for line in self._lines_iter:
            if not line:
                continue

            if line.startswith("event: "):
                event_type = line[7:].strip()
                continue

            if not line.startswith("data: "):
                continue

            data_str = line[6:]
            try:
                data = json.loads(data_str)
            except (ValueError, TypeError):
                continue

            if event_type == "token":
                content = data.get("content", "")
                if content:
                    self._content_parts.append(content)
                    return content

            elif event_type == "metadata":
                self._metadata = EvaluateResponse(
                    execution_id=data.get("execution_id", ""),
                    experiment_id=data.get("experiment_id", ""),
                    variant_id=data.get("variant_id", ""),
                    content="".join(self._content_parts),
                    model=data.get("model", ""),
                    provider=data.get("provider", ""),
                    token_usage={
                        "prompt_tokens": data.get("prompt_tokens", 0),
                        "completion_tokens": data.get("completion_tokens", 0),
                        "total_tokens": data.get("total_tokens", 0),
                    },
                    latency_ms=data.get("latency_ms", 0),
                )

            elif event_type == "error":
                self._consumed = True
                raise Exception(f"Streaming error: {data.get('message', 'unknown')}")

            elif event_type == "done":
                self._consumed = True
                raise StopIteration

        self._consumed = True
        raise StopIteration

    @property
    def metadata(self) -> Optional["EvaluateResponse"]:
        """Available after iteration completes. Contains token usage, latency, etc."""
        return self._metadata

    def close(self) -> None:
        """Close the underlying response."""
        self._consumed = True
        self._response.close()


class SubmitResponseResult:
    """Result from submit-response endpoint."""

    def __init__(self, status: str):
        self.status = status

    def __repr__(self) -> str:
        return f"SubmitResponseResult(status='{self.status}')"


class LogResult:
    """Result from observe/log endpoint."""

    def __init__(self, observation_id: str, experiment_id: str, status: str):
        self.observation_id = observation_id
        self.experiment_id = experiment_id
        self.status = status

    def __repr__(self) -> str:
        return (
            f"LogResult(observation_id='{self.observation_id}', "
            f"experiment_id='{self.experiment_id}', status='{self.status}')"
        )