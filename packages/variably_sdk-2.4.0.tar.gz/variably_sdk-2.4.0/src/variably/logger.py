"""Logging utilities for Variably SDK."""

import json
import logging
import sys
from typing import Any, Dict, Optional


class VariablyLogger:
    """Logger wrapper for Variably SDK."""
    
    def __init__(self, name: str = "variably", level: str = "INFO"):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(getattr(logging, level.upper()))
        
        # Add console handler if no handlers exist
        if not self.logger.handlers:
            handler = logging.StreamHandler(sys.stdout)
            formatter = logging.Formatter(
                "[%(asctime)s] [%(levelname)s] [%(name)s] %(message)s"
            )
            handler.setFormatter(formatter)
            self.logger.addHandler(handler)
    
    def debug(self, message: str, extra: Optional[Dict[str, Any]] = None):
        """Log debug message."""
        self._log(logging.DEBUG, message, extra)
    
    def info(self, message: str, extra: Optional[Dict[str, Any]] = None):
        """Log info message."""
        self._log(logging.INFO, message, extra)
    
    def warning(self, message: str, extra: Optional[Dict[str, Any]] = None):
        """Log warning message."""
        self._log(logging.WARNING, message, extra)
    
    def error(self, message: str, extra: Optional[Dict[str, Any]] = None):
        """Log error message."""
        self._log(logging.ERROR, message, extra)
    
    def _log(self, level: int, message: str, extra: Optional[Dict[str, Any]] = None):
        """Internal logging method."""
        if extra:
            # Add extra context to the message
            message = f"{message} {json.dumps(extra, default=str)}"
        self.logger.log(level, message)


class StructuredLogger(VariablyLogger):
    """Structured JSON logger for Variably SDK."""
    
    def __init__(self, name: str = "variably", level: str = "INFO"):
        super().__init__(name, level)
        
        # Replace formatter with JSON formatter
        for handler in self.logger.handlers:
            handler.setFormatter(JSONFormatter())


class JSONFormatter(logging.Formatter):
    """JSON formatter for structured logging."""
    
    def format(self, record: logging.LogRecord) -> str:
        log_obj = {
            "timestamp": self.formatTime(record),
            "level": record.levelname,
            "name": record.name,
            "message": record.getMessage(),
        }
        
        # Add exception info if present
        if record.exc_info:
            log_obj["exception"] = self.formatException(record.exc_info)
        
        return json.dumps(log_obj)


class SilentLogger:
    """Silent logger that discards all messages."""
    
    def debug(self, message: str, extra: Optional[Dict[str, Any]] = None):
        pass
    
    def info(self, message: str, extra: Optional[Dict[str, Any]] = None):
        pass
    
    def warning(self, message: str, extra: Optional[Dict[str, Any]] = None):
        pass
    
    def error(self, message: str, extra: Optional[Dict[str, Any]] = None):
        pass


def create_logger(
    name: str = "variably",
    level: str = "INFO",
    structured: bool = False,
    silent: bool = False,
) -> VariablyLogger:
    """
    Create a logger instance.
    
    Args:
        name: Logger name
        level: Log level (DEBUG, INFO, WARNING, ERROR)
        structured: Whether to use structured JSON logging
        silent: Whether to create a silent logger
        
    Returns:
        Logger instance
    """
    if silent:
        return SilentLogger()
    elif structured:
        return StructuredLogger(name, level)
    else:
        return VariablyLogger(name, level)