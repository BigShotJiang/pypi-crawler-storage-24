"""Main Variably SDK client."""

import hashlib
import json
from datetime import datetime
from typing import Any, Dict, List, Optional, Union

from .cache import CacheManager, NoOpCache
from .config import VariablyConfig
from .errors import ConfigurationError, VariablyError
from .http_client import HTTPClient
from .logger import VariablyLogger, create_logger
from .types import (
    EvaluateResponse,
    Event,
    FlagResult,
    LogResult,
    PromptVariant,
    SDKMetrics,
    StreamingEvaluateResponse,
    SubmitResponseResult,
    UserContext,
)


class VariablyClient:
    """Main Variably SDK client for feature flags and experimentation."""
    
    def __init__(self, config: Union[VariablyConfig, Dict[str, Any]]):
        """
        Initialize Variably client.
        
        Args:
            config: Configuration object or dictionary
        """
        # Convert dict to config object if needed
        if isinstance(config, dict):
            config = VariablyConfig(**config)
        
        self.config = config
        self.logger = create_logger(level=config.log_level)
        self.metrics = SDKMetrics()
        
        # Initialize cache
        if config.cache.get("enabled", True):
            self.cache = CacheManager(config.cache)
        else:
            self.cache = NoOpCache()
        
        # Initialize HTTP client
        self.http_client = HTTPClient(config, self.logger, self.metrics)
        
        self.logger.info(
            "Variably client initialized",
            {
                "environment": config.environment,
                "base_url": config.base_url,
            },
        )
    
    def evaluate_flag_bool(
        self, flag_key: str, default_value: bool, user_context: UserContext
    ) -> bool:
        """
        Evaluate a boolean feature flag.
        
        Args:
            flag_key: Feature flag key
            default_value: Default value if evaluation fails
            user_context: User context for targeting
            
        Returns:
            Boolean flag value
        """
        result = self.evaluate_flag(flag_key, default_value, user_context)
        return bool(result.value) if isinstance(result.value, bool) else default_value
    
    def evaluate_flag_string(
        self, flag_key: str, default_value: str, user_context: UserContext
    ) -> str:
        """
        Evaluate a string feature flag.
        
        Args:
            flag_key: Feature flag key
            default_value: Default value if evaluation fails
            user_context: User context for targeting
            
        Returns:
            String flag value
        """
        result = self.evaluate_flag(flag_key, default_value, user_context)
        return str(result.value) if isinstance(result.value, str) else default_value
    
    def evaluate_flag_number(
        self, flag_key: str, default_value: Union[int, float], user_context: UserContext
    ) -> Union[int, float]:
        """
        Evaluate a numeric feature flag.
        
        Args:
            flag_key: Feature flag key
            default_value: Default value if evaluation fails
            user_context: User context for targeting
            
        Returns:
            Numeric flag value
        """
        result = self.evaluate_flag(flag_key, default_value, user_context)
        if isinstance(result.value, (int, float)):
            return result.value
        return default_value
    
    def evaluate_flag_json(
        self, flag_key: str, default_value: Any, user_context: UserContext
    ) -> Any:
        """
        Evaluate a JSON feature flag.
        
        Args:
            flag_key: Feature flag key
            default_value: Default value if evaluation fails
            user_context: User context for targeting
            
        Returns:
            JSON flag value
        """
        result = self.evaluate_flag(flag_key, default_value, user_context)
        return result.value if not result.error else default_value
    
    def evaluate_flag(
        self, flag_key: str, default_value: Any, user_context: UserContext
    ) -> FlagResult:
        """
        Evaluate a feature flag with full result details.
        
        Args:
            flag_key: Feature flag key
            default_value: Default value if evaluation fails
            user_context: User context for targeting
            
        Returns:
            FlagResult with evaluation details
        """
        try:
            self.metrics.flags_evaluated += 1
            
            # Validate inputs
            if not flag_key or not isinstance(flag_key, str):
                raise ConfigurationError(
                    "Flag key must be a non-empty string", "flag_key"
                )
            if not user_context.get("user_id"):
                raise ConfigurationError(
                    "User context must include user_id", "user_context.user_id"
                )
            
            # Check cache first
            cache_key = self._generate_cache_key(flag_key, user_context)
            cached = self.cache.get(cache_key)
            if cached:
                self.metrics.cache_hits += 1
                self.logger.debug(
                    "Flag evaluation cache hit",
                    {"flag_key": flag_key, "user_id": user_context["user_id"]},
                )
                cached.cache_hit = True
                return cached
            
            self.metrics.cache_misses += 1
            
            # Evaluate via API
            response = self.http_client.evaluate_flag(flag_key, user_context)
            
            result = FlagResult(
                key=flag_key,
                value=response["value"],
                reason=response.get("reason", "api_evaluation"),
                rule_id=response.get("rule_id"),
                cache_hit=False,
                evaluated_at=datetime.utcnow(),
            )
            
            # Cache the result
            self.cache.set(cache_key, result)
            
            self.logger.debug(
                "Flag evaluation successful",
                {
                    "flag_key": flag_key,
                    "value": response["value"],
                    "user_id": user_context["user_id"],
                },
            )
            
            return result
        
        except Exception as error:
            self.logger.error(
                "Flag evaluation failed",
                {
                    "flag_key": flag_key,
                    "error": str(error),
                    "user_id": user_context.get("user_id"),
                },
            )
            
            # Return default value with error
            return FlagResult(
                key=flag_key,
                value=default_value,
                reason="error_fallback",
                cache_hit=False,
                evaluated_at=datetime.utcnow(),
                error=error,
            )
    
    def evaluate_flags(
        self, flag_keys: List[str], user_context: UserContext
    ) -> Dict[str, FlagResult]:
        """
        Evaluate multiple feature flags in batch.
        
        Args:
            flag_keys: List of feature flag keys
            user_context: User context for targeting
            
        Returns:
            Dictionary mapping flag keys to FlagResult objects
        """
        results: Dict[str, FlagResult] = {}
        
        # Check cache for each flag
        uncached_flags: List[str] = []
        for flag_key in flag_keys:
            self.metrics.flags_evaluated += 1
            cache_key = self._generate_cache_key(flag_key, user_context)
            cached = self.cache.get(cache_key)
            
            if cached:
                self.metrics.cache_hits += 1
                cached.cache_hit = True
                results[flag_key] = cached
            else:
                self.metrics.cache_misses += 1
                uncached_flags.append(flag_key)
        
        # Evaluate uncached flags via batch API
        if uncached_flags:
            try:
                batch_response = self.http_client.evaluate_flags(uncached_flags, user_context)
                
                for flag_key, response in batch_response["results"].items():
                    result = FlagResult(
                        key=flag_key,
                        value=response["value"],
                        reason=response.get("reason", "api_evaluation"),
                        rule_id=response.get("rule_id"),
                        cache_hit=False,
                        evaluated_at=datetime.utcnow(),
                    )
                    
                    results[flag_key] = result
                    
                    # Cache the result
                    cache_key = self._generate_cache_key(flag_key, user_context)
                    self.cache.set(cache_key, result)
            
            except Exception as error:
                self.logger.error("Batch flag evaluation failed", {"error": str(error)})
                
                # Set error results for uncached flags
                for flag_key in uncached_flags:
                    results[flag_key] = FlagResult(
                        key=flag_key,
                        value=False,
                        reason="error_fallback",
                        cache_hit=False,
                        evaluated_at=datetime.utcnow(),
                        error=error,
                    )
        
        return results
    
    def evaluate_gate(self, gate_key: str, user_context: UserContext) -> bool:
        """
        Evaluate a feature gate.
        
        Args:
            gate_key: Feature gate key
            user_context: User context for access control
            
        Returns:
            Boolean indicating access granted
        """
        try:
            self.metrics.gates_evaluated += 1
            
            # Validate inputs
            if not gate_key or not isinstance(gate_key, str):
                raise ConfigurationError(
                    "Gate key must be a non-empty string", "gate_key"
                )
            if not user_context.get("user_id"):
                raise ConfigurationError(
                    "User context must include user_id", "user_context.user_id"
                )
            
            # Check cache first
            cache_key = self._generate_gate_cache_key(gate_key, user_context)
            cached = self.cache.get(cache_key)
            if cached:
                self.metrics.cache_hits += 1
                self.logger.debug(
                    "Gate evaluation cache hit",
                    {"gate_key": gate_key, "user_id": user_context["user_id"]},
                )
                return cached.value
            
            self.metrics.cache_misses += 1
            
            # Evaluate via API
            response = self.http_client.evaluate_gate(gate_key, user_context)
            
            # Cache the result
            result = FlagResult(
                key=gate_key,
                value=response["value"],
                reason=response.get("reason", "api_evaluation"),
                rule_id=response.get("rule_id"),
                cache_hit=False,
                evaluated_at=datetime.utcnow(),
            )
            self.cache.set(cache_key, result)
            
            self.logger.debug(
                "Gate evaluation successful",
                {
                    "gate_key": gate_key,
                    "value": response["value"],
                    "user_id": user_context["user_id"],
                },
            )
            
            return response["value"]
        
        except Exception as error:
            self.logger.error(
                "Gate evaluation failed",
                {
                    "gate_key": gate_key,
                    "error": str(error),
                    "user_id": user_context.get("user_id"),
                },
            )
            return False  # Default to false for gates
    
    def track(self, event: Event) -> None:
        """
        Track an analytics event.
        
        Args:
            event: Event data to track
        """
        try:
            if not self.config.enable_analytics:
                self.logger.debug("Analytics disabled, skipping event tracking")
                return
            
            # Validate event
            if not event.get("name"):
                raise ConfigurationError(
                    "Event name must be a non-empty string", "event.name"
                )
            if not event.get("user_id"):
                raise ConfigurationError(
                    "Event user_id must be a non-empty string", "event.user_id"
                )
            
            # Ensure event has timestamp
            if "timestamp" not in event:
                event["timestamp"] = datetime.utcnow()
            
            self.metrics.events_tracked += 1
            
            self.http_client.track_event(event)
            
            self.logger.debug(
                "Event tracked successfully",
                {"event_name": event["name"], "user_id": event["user_id"]},
            )
        
        except Exception as error:
            self.logger.error(
                "Event tracking failed",
                {
                    "event_name": event.get("name"),
                    "user_id": event.get("user_id"),
                    "error": str(error),
                },
            )
            raise
    
    def track_batch(self, events: List[Event]) -> None:
        """
        Track multiple events in batch.
        
        Args:
            events: List of events to track
        """
        try:
            if not self.config.enable_analytics:
                self.logger.debug("Analytics disabled, skipping batch event tracking")
                return
            
            # Validate and prepare events
            processed_events = []
            for event in events:
                if not event.get("name"):
                    raise ConfigurationError(
                        "Event name must be a non-empty string", "event.name"
                    )
                if not event.get("user_id"):
                    raise ConfigurationError(
                        "Event user_id must be a non-empty string", "event.user_id"
                    )
                
                processed_event = event.copy()
                if "timestamp" not in processed_event:
                    processed_event["timestamp"] = datetime.utcnow()
                
                processed_events.append(processed_event)
            
            self.metrics.events_tracked += len(events)
            
            self.http_client.track_events(processed_events)
            
            self.logger.debug("Batch events tracked successfully", {"count": len(events)})
        
        except Exception as error:
            self.logger.error(
                "Batch event tracking failed",
                {"count": len(events), "error": str(error)},
            )
            raise
    
    def get_variant(
        self,
        experiment_key: str,
        user_context: UserContext,
        input_variables: Optional[Dict[str, Any]] = None,
    ) -> PromptVariant:
        """Get traffic-allocated variant for a prompt experiment (BYOR step 1)."""
        if not experiment_key or not isinstance(experiment_key, str):
            raise ConfigurationError(
                "Experiment key must be a non-empty string", "experiment_key"
            )
        if not user_context.get("user_id"):
            raise ConfigurationError(
                "User context must include user_id", "user_context.user_id"
            )

        response = self.http_client.get_variant(
            experiment_key, dict(user_context), input_variables
        )

        return PromptVariant(
            experiment_id=response["experiment_id"],
            experiment_key=response["experiment_key"],
            variant_id=response["variant_id"],
            variant_key=response["variant_key"],
            prompt_template=response["prompt_template"],
            model=response["model"],
            provider=response["provider"],
            parameters=response.get("parameters", {}),
            is_control=response.get("is_control", False),
        )

    def evaluate_prompt(
        self,
        experiment_key: str,
        user_context: UserContext,
        input_variables: Dict[str, Any],
        evaluation_context: Optional[Dict[str, Any]] = None,
        **kwargs,
    ) -> EvaluateResponse:
        """Managed execution: Variably selects variant, calls LLM, evaluates."""
        if not experiment_key or not isinstance(experiment_key, str):
            raise ConfigurationError(
                "Experiment key must be a non-empty string", "experiment_key"
            )
        if not user_context.get("user_id"):
            raise ConfigurationError(
                "User context must include user_id", "user_context.user_id"
            )

        response = self.http_client.evaluate_prompt(
            experiment_key, dict(user_context), input_variables,
            evaluation_context=evaluation_context,
        )

        return EvaluateResponse(
            execution_id=response["execution_id"],
            experiment_id=response["experiment_id"],
            variant_id=response["variant_id"],
            content=response["content"],
            model=response["model"],
            provider=response["provider"],
            token_usage=response.get("token_usage", {}),
            latency_ms=response.get("latency_ms", 0),
            quality_score=response.get("quality_score"),
        )

    def evaluate_prompt_stream(
        self,
        experiment_key: str,
        user_context: UserContext,
        input_variables: Dict[str, Any],
        evaluation_context: Optional[Dict[str, Any]] = None,
        **kwargs,
    ) -> StreamingEvaluateResponse:
        """Managed execution with streaming. Yields token strings.

        Usage:
            stream = client.evaluate_prompt_stream("my-experiment", user_ctx, {"query": "hello"})
            for token in stream:
                print(token, end="", flush=True)
            print()
            print(stream.metadata)  # EvaluateResponse with token_usage, latency, etc.
        """
        if not experiment_key or not isinstance(experiment_key, str):
            raise ConfigurationError(
                "Experiment key must be a non-empty string", "experiment_key"
            )
        if not user_context.get("user_id"):
            raise ConfigurationError(
                "User context must include user_id", "user_context.user_id"
            )

        raw_response = self.http_client.evaluate_prompt_stream(
            experiment_key, dict(user_context), input_variables,
            evaluation_context=evaluation_context,
        )

        return StreamingEvaluateResponse(raw_response)

    def submit_response(
        self,
        experiment_key: str,
        variant_key: str,
        executed_prompt: str,
        response: str,
        user_context: Optional[UserContext] = None,
        input_variables: Optional[Dict[str, Any]] = None,
        provider: Optional[str] = None,
        model: Optional[str] = None,
        latency_ms: Optional[int] = None,
        prompt_tokens: Optional[int] = None,
        completion_tokens: Optional[int] = None,
        evaluation_context: Optional[Dict[str, Any]] = None,
    ) -> SubmitResponseResult:
        """Submit your own LLM response for 41-dimensional evaluation (BYOR step 3)."""
        if not experiment_key or not isinstance(experiment_key, str):
            raise ConfigurationError(
                "Experiment key must be a non-empty string", "experiment_key"
            )
        if not variant_key or not isinstance(variant_key, str):
            raise ConfigurationError(
                "Variant key must be a non-empty string", "variant_key"
            )

        data: Dict[str, Any] = {
            "experiment_key": experiment_key,
            "variant_key": variant_key,
            "executed_prompt": executed_prompt,
            "response": response,
        }
        if user_context:
            data["user_context"] = dict(user_context)
        if input_variables:
            data["input_variables"] = input_variables
        if provider:
            data["provider"] = provider
        if model:
            data["model"] = model
        if latency_ms is not None:
            data["latency_ms"] = latency_ms
        if prompt_tokens is not None:
            data["prompt_tokens"] = prompt_tokens
        if completion_tokens is not None:
            data["completion_tokens"] = completion_tokens
        if evaluation_context:
            data["evaluation_context"] = evaluation_context

        result = self.http_client.submit_response(data)

        return SubmitResponseResult(status=result.get("status", "ok"))

    def log(
        self,
        prompt: Union[str, List[Dict[str, Any]]],
        response: str,
        *,
        conversation_history: Optional[List[Dict[str, Any]]] = None,
        reference_materials: Optional[List[Dict[str, Any]]] = None,
        retrieval_query: Optional[str] = None,
        tags: Optional[List[str]] = None,
        user_id: Optional[str] = None,
        session_id: Optional[str] = None,
        provider: Optional[str] = None,
        model: Optional[str] = None,
        latency_ms: Optional[int] = None,
        prompt_tokens: Optional[int] = None,
        completion_tokens: Optional[int] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> LogResult:
        """Log a prompt/response pair for 43-dimension evaluation (Observe Mode).

        Zero-friction entry point — no experiment creation needed. Just log your
        prompts and responses and see quality scores in the dashboard.

        Args:
            prompt: The prompt sent to the LLM (str or messages list).
            response: The LLM's response text.
            conversation_history: Prior conversation turns for cross-turn coherence scoring.
            reference_materials: Retrieved RAG chunks for grounding/hallucination scoring.
            retrieval_query: The query sent to the retriever (for retrieval relevance scoring).
            tags: Optional tags for grouping observations (e.g. ["production", "chatbot"]).
            user_id: End-user ID for per-user analytics.
            session_id: Session ID for multi-turn tracking.
            provider: LLM provider name (e.g. "openai", "anthropic").
            model: Model name (e.g. "gpt-4", "claude-3-opus").
            latency_ms: LLM call latency in milliseconds.
            prompt_tokens: Number of input tokens.
            completion_tokens: Number of output tokens.
            metadata: Arbitrary key-value metadata.

        Returns:
            LogResult with observation_id and status.
        """
        # Normalize prompt to string
        prompt_str = prompt if isinstance(prompt, str) else str(prompt)

        data: Dict[str, Any] = {
            "prompt": prompt_str,
            "response": response,
        }

        # Build evaluation_context from multi-turn/RAG params
        evaluation_context: Dict[str, Any] = {}
        if conversation_history:
            evaluation_context["conversation_history"] = conversation_history
        if reference_materials:
            evaluation_context["reference_materials"] = reference_materials
        if retrieval_query:
            evaluation_context["retrieval_query"] = retrieval_query
        if evaluation_context:
            data["evaluation_context"] = evaluation_context

        if tags:
            data["tags"] = tags
        if user_id:
            data["user_id"] = user_id
        if session_id:
            data["session_id"] = session_id
        if provider:
            data["provider"] = provider
        if model:
            data["model"] = model
        if latency_ms is not None:
            data["latency_ms"] = latency_ms
        if prompt_tokens is not None:
            data["prompt_tokens"] = prompt_tokens
        if completion_tokens is not None:
            data["completion_tokens"] = completion_tokens
        if metadata:
            data["metadata"] = metadata

        try:
            result = self.http_client.log_observation(data)
            return LogResult(
                observation_id=result.get("observation_id", ""),
                experiment_id=result.get("experiment_id", ""),
                status=result.get("status", "queued"),
            )
        except Exception as error:
            self.logger.error(
                "Observation logging failed",
                {"error": str(error)},
            )
            raise

    def clear_cache(self) -> None:
        """Clear the cache."""
        self.cache.clear()
        self.logger.debug("Cache cleared")
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get SDK metrics."""
        return self.metrics.to_dict()
    
    def _generate_cache_key(self, flag_key: str, user_context: UserContext) -> str:
        """Generate cache key for flag evaluation."""
        context_hash = self._hash_user_context(user_context)
        return f"flag:{flag_key}:{context_hash}"
    
    def _generate_gate_cache_key(self, gate_key: str, user_context: UserContext) -> str:
        """Generate cache key for gate evaluation."""
        context_hash = self._hash_user_context(user_context)
        return f"gate:{gate_key}:{context_hash}"
    
    def _hash_user_context(self, user_context: UserContext) -> str:
        """Generate a hash of user context for caching."""
        # Create a stable hash of user context
        context_str = json.dumps(
            {
                "user_id": user_context["user_id"],
                "attributes": user_context.get("attributes", {}),
            },
            sort_keys=True,
        )
        return hashlib.md5(context_str.encode()).hexdigest()[:16]
    
    def close(self) -> None:
        """Close the client and cleanup resources."""
        self.http_client.close()
        self.cache.shutdown()
        self.logger.info("Variably client closed")
    
    def __enter__(self):
        """Support for context manager."""
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        """Support for context manager."""
        self.close()


# Convenience functions
def create_client(config: Union[VariablyConfig, Dict[str, Any]]) -> VariablyClient:
    """Create a Variably client."""
    return VariablyClient(config)


def create_client_from_env() -> VariablyClient:
    """Create a Variably client from environment variables."""
    config = VariablyConfig.from_env()
    return VariablyClient(config)