"""HTTP client for Variably API."""

import json
import time
from typing import Any, Dict, List, Optional

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

from .config import VariablyConfig
from .errors import (
    AuthenticationError,
    NetworkError,
    RateLimitError,
    TimeoutError,
    ValidationError,
)
from .logger import VariablyLogger
from .types import (
    BatchFlagEvaluationRequest,
    BatchFlagEvaluationResponse,
    Event,
    EventTrackingRequest,
    FlagEvaluationRequest,
    FlagEvaluationResponse,
    GateEvaluationRequest,
    GateEvaluationResponse,
    SDKMetrics,
    UserContext,
)


class HTTPClient:
    """HTTP client for Variably API with retry logic and error handling."""
    
    def __init__(self, config: VariablyConfig, logger: VariablyLogger, metrics: SDKMetrics):
        self.config = config
        self.logger = logger
        self.metrics = metrics
        self.session = self._create_session()
    
    def _create_session(self) -> requests.Session:
        """Create HTTP session with retry configuration."""
        session = requests.Session()
        
        # Configure retries
        retry_strategy = Retry(
            total=self.config.retry_attempts,
            status_forcelist=[408, 429, 500, 502, 503, 504],
            allowed_methods=["HEAD", "GET", "POST"],
            backoff_factor=1,
        )
        
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        
        # Set default headers
        session.headers.update({
            "Content-Type": "application/json",
            "X-API-Key": self.config.api_key,
            "User-Agent": "Variably-Python-SDK/2.3.0",
        })
        
        return session
    
    def evaluate_flag(self, flag_key: str, context: UserContext) -> FlagEvaluationResponse:
        """Evaluate a single feature flag."""
        request_data: FlagEvaluationRequest = {
            "flag_key": flag_key,
            "context": context,
        }
        
        response = self._make_request(
            "POST",
            "/api/v1/sdk/evaluate",
            json=request_data,
            retryable=True,
        )
        
        return response
    
    def evaluate_flags(
        self, flag_keys: List[str], context: UserContext
    ) -> BatchFlagEvaluationResponse:
        """Evaluate multiple feature flags in batch."""
        request_data: BatchFlagEvaluationRequest = {
            "flag_keys": flag_keys,
            "context": context,
        }
        
        response = self._make_request(
            "POST",
            "/api/v1/sdk/evaluate/batch",
            json=request_data,
            retryable=True,
        )
        
        return response
    
    def evaluate_gate(self, gate_key: str, context: UserContext) -> GateEvaluationResponse:
        """Evaluate a feature gate."""
        request_data: GateEvaluationRequest = {
            "gate_key": gate_key,
            "context": context,
        }
        
        response = self._make_request(
            "POST",
            "/api/v1/sdk/feature-gates/evaluate",
            json=request_data,
            retryable=True,
        )
        
        return response
    
    def track_event(self, event: Event) -> None:
        """Track a single event."""
        request_data: EventTrackingRequest = {
            "name": event["name"],
            "user_id": event["user_id"],
            "properties": event.get("properties"),
            "timestamp": event.get("timestamp") or time.time(),
        }
        
        self._make_request(
            "POST",
            "/api/v1/sdk/events",
            json=request_data,
            retryable=False,
        )
    
    def track_events(self, events: List[Event]) -> None:
        """Track multiple events in batch."""
        request_data = {
            "events": [
                {
                    "name": event["name"],
                    "user_id": event["user_id"],
                    "properties": event.get("properties"),
                    "timestamp": event.get("timestamp") or time.time(),
                }
                for event in events
            ]
        }
        
        self._make_request(
            "POST",
            "/api/v1/sdk/events/batch",
            json=request_data,
            retryable=False,
        )
    
    @staticmethod
    def _convert_user_context(ctx: Dict[str, Any]) -> Dict[str, Any]:
        """Convert snake_case user context keys to camelCase for the Go backend."""
        key_map = {
            "user_id": "userId",
            "ip_address": "ipAddress",
            "user_agent": "userAgent",
            "session_id": "sessionId",
        }
        return {key_map.get(k, k): v for k, v in ctx.items()}

    def get_variant(
        self, experiment_key: str, user_context: Dict[str, Any],
        input_variables: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Get traffic-allocated variant for a prompt experiment."""
        request_data: Dict[str, Any] = {
            "experiment_key": experiment_key,
            "context": self._convert_user_context(user_context),
        }
        if input_variables:
            request_data["input_variables"] = input_variables

        return self._make_request(
            "POST",
            "/api/v1/internal/sdk/prompt-experiments/get-variant",
            json=request_data,
            retryable=True,
        )

    def evaluate_prompt(
        self, experiment_key: str, user_context: Dict[str, Any],
        input_variables: Dict[str, Any],
        evaluation_context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Managed execution: select variant, call LLM, evaluate."""
        request_data = {
            "experiment_key": experiment_key,
            "user_context": self._convert_user_context(user_context),
            "input_variables": input_variables,
        }
        if evaluation_context:
            request_data["evaluation_context"] = evaluation_context

        return self._make_request(
            "POST",
            "/api/v1/internal/sdk/prompt-experiments/evaluate",
            json=request_data,
            retryable=False,
        )

    def evaluate_prompt_stream(
        self, experiment_key: str, user_context: Dict[str, Any],
        input_variables: Dict[str, Any],
        evaluation_context: Optional[Dict[str, Any]] = None,
    ) -> requests.Response:
        """Managed execution with streaming: returns raw SSE response for token parsing."""
        request_data = {
            "experiment_key": experiment_key,
            "user_context": self._convert_user_context(user_context),
            "input_variables": input_variables,
        }
        if evaluation_context:
            request_data["evaluation_context"] = evaluation_context

        url = f"{self.config.base_url}/api/v1/internal/sdk/prompt-experiments/evaluate-stream"

        self.logger.debug(f"Making streaming POST request to evaluate-stream")
        self.metrics.api_calls += 1

        response = self.session.post(
            url,
            json=request_data,
            timeout=self.config.timeout,
            stream=True,
        )

        if not response.ok:
            self._handle_http_error(response, url)

        return response

    def submit_response(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Submit LLM response for evaluation."""
        return self._make_request(
            "POST",
            "/api/v1/internal/sdk/prompt-experiments/submit-response",
            json=data,
            retryable=False,
        )

    def log_observation(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Log a prompt/response pair for observe-mode evaluation."""
        return self._make_request(
            "POST",
            "/api/v1/internal/sdk/observe/log",
            json=data,
            retryable=False,
        )

    def _make_request(
        self,
        method: str,
        path: str,
        retryable: bool = True,
        **kwargs: Any,
    ) -> Any:
        """Make HTTP request with error handling and metrics."""
        url = f"{self.config.base_url}{path}"
        start_time = time.time()
        
        try:
            self.logger.debug(f"Making {method} request to {path}")
            
            response = self.session.request(
                method=method,
                url=url,
                timeout=self.config.timeout,
                **kwargs,
            )
            
            # Record metrics
            duration_ms = (time.time() - start_time) * 1000
            self.metrics.latencies.append(duration_ms)
            self.metrics.api_calls += 1
            
            self.logger.debug(
                f"Request completed",
                {
                    "method": method,
                    "path": path,
                    "status_code": response.status_code,
                    "duration_ms": duration_ms,
                },
            )
            
            # Handle HTTP errors
            if not response.ok:
                self._handle_http_error(response, url)
            
            # Handle empty responses (for tracking endpoints)
            if response.status_code == 204 or not response.content:
                return None
            
            return response.json()
        
        except requests.exceptions.Timeout as e:
            self.metrics.errors += 1
            raise TimeoutError(
                f"Request to {url} timed out after {self.config.timeout}s",
                "http_request",
                e,
            )
        
        except requests.exceptions.ConnectionError as e:
            self.metrics.errors += 1
            raise NetworkError(f"Connection error to {url}", 0, url, e)
        
        except requests.exceptions.RequestException as e:
            self.metrics.errors += 1
            raise NetworkError(f"Request failed: {str(e)}", 0, url, e)
    
    def _handle_http_error(self, response: requests.Response, url: str) -> None:
        """Handle HTTP error responses."""
        try:
            error_data = response.json()
            error_message = error_data.get("message") or error_data.get("error") or "Unknown error"
        except (json.JSONDecodeError, ValueError):
            error_message = response.text or f"HTTP {response.status_code}"
        
        if response.status_code == 400:
            raise ValidationError(f"Bad Request: {error_message}", "request")
        elif response.status_code == 401:
            raise AuthenticationError(f"Unauthorized: {error_message}")
        elif response.status_code == 403:
            raise AuthenticationError(f"Forbidden: {error_message}")
        elif response.status_code == 404:
            raise NetworkError(f"Not Found: {error_message}", response.status_code, url)
        elif response.status_code == 422:
            raise ValidationError(f"Validation Error: {error_message}", "validation")
        elif response.status_code == 429:
            retry_after = int(response.headers.get("Retry-After", 60))
            raise RateLimitError(f"Rate limited: {error_message}", retry_after)
        else:
            raise NetworkError(
                f"HTTP {response.status_code}: {error_message}",
                response.status_code,
                url,
            )
    
    def close(self) -> None:
        """Close HTTP session."""
        self.session.close()