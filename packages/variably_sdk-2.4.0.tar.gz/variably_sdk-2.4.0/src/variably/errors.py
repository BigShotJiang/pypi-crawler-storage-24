"""Error classes for Variably SDK."""


class VariablyError(Exception):
    """Base exception for all Variably SDK errors."""
    
    def __init__(self, message: str, cause: Exception = None):
        super().__init__(message)
        self.cause = cause


class NetworkError(VariablyError):
    """Network-related errors."""
    
    def __init__(self, message: str, status_code: int, url: str, cause: Exception = None):
        super().__init__(message, cause)
        self.status_code = status_code
        self.url = url
    
    @staticmethod
    def is_retryable(status_code: int) -> bool:
        """Check if a status code indicates a retryable error."""
        # Retry on 5xx errors and certain 4xx errors
        return status_code >= 500 or status_code in (408, 429)


class AuthenticationError(VariablyError):
    """Authentication-related errors (401, 403)."""
    pass


class ValidationError(VariablyError):
    """Validation-related errors (400, 422)."""
    
    def __init__(self, message: str, field: str, cause: Exception = None):
        super().__init__(message, cause)
        self.field = field


class RateLimitError(VariablyError):
    """Rate limiting errors (429)."""
    
    def __init__(self, message: str, retry_after: int, cause: Exception = None):
        super().__init__(message, cause)
        self.retry_after = retry_after


class TimeoutError(VariablyError):
    """Request timeout errors."""
    
    def __init__(self, message: str, operation: str, cause: Exception = None):
        super().__init__(message, cause)
        self.operation = operation


class ConfigurationError(VariablyError):
    """Configuration-related errors."""
    
    def __init__(self, message: str, parameter: str, cause: Exception = None):
        super().__init__(message, cause)
        self.parameter = parameter