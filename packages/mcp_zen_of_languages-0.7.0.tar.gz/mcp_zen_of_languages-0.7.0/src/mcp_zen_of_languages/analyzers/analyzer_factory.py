"""Factory function for creating language-specific analyzers.

Centralises the mapping from language identifiers (including common aliases
like ``"py"``, ``"ts"``, ``"rs"``) to their concrete
[`BaseAnalyzer`][mcp_zen_of_languages.analyzers.base.BaseAnalyzer] subclass.
Callers never need to import individual analyzer modules; they go through
``create_analyzer`` and receive a fully configured instance.

Framework analyzers (React, Vue, Angular, Next.js, Pydantic, FastAPI, Django,
SQLAlchemy) are loaded lazily on first use to keep import-time overhead low and
to avoid surfacing circular-import issues during module initialisation.
"""

from __future__ import annotations

import importlib

from typing import TYPE_CHECKING

from mcp_zen_of_languages.languages.ansible.analyzer import AnsibleAnalyzer
from mcp_zen_of_languages.languages.bash.analyzer import BashAnalyzer
from mcp_zen_of_languages.languages.cpp.analyzer import CppAnalyzer
from mcp_zen_of_languages.languages.csharp.analyzer import CSharpAnalyzer
from mcp_zen_of_languages.languages.css.analyzer import CssAnalyzer
from mcp_zen_of_languages.languages.docker_compose.analyzer import DockerComposeAnalyzer
from mcp_zen_of_languages.languages.dockerfile.analyzer import DockerfileAnalyzer
from mcp_zen_of_languages.languages.github_actions.analyzer import GitHubActionsAnalyzer
from mcp_zen_of_languages.languages.gitlab_ci.analyzer import GitLabCIAnalyzer
from mcp_zen_of_languages.languages.go.analyzer import GoAnalyzer
from mcp_zen_of_languages.languages.javascript.analyzer import JavaScriptAnalyzer
from mcp_zen_of_languages.languages.json.analyzer import JsonAnalyzer
from mcp_zen_of_languages.languages.latex.analyzer import LatexAnalyzer
from mcp_zen_of_languages.languages.markdown.analyzer import MarkdownAnalyzer
from mcp_zen_of_languages.languages.powershell.analyzer import PowerShellAnalyzer
from mcp_zen_of_languages.languages.python.analyzer import PythonAnalyzer
from mcp_zen_of_languages.languages.ruby.analyzer import RubyAnalyzer
from mcp_zen_of_languages.languages.rust.analyzer import RustAnalyzer
from mcp_zen_of_languages.languages.sql.analyzer import SqlAnalyzer
from mcp_zen_of_languages.languages.svg.analyzer import SvgAnalyzer
from mcp_zen_of_languages.languages.terraform.analyzer import TerraformAnalyzer
from mcp_zen_of_languages.languages.toml.analyzer import TomlAnalyzer
from mcp_zen_of_languages.languages.typescript.analyzer import TypeScriptAnalyzer
from mcp_zen_of_languages.languages.xml.analyzer import XmlAnalyzer
from mcp_zen_of_languages.languages.yaml.analyzer import YamlAnalyzer


if TYPE_CHECKING:
    from mcp_zen_of_languages.analyzers.base import AnalyzerConfig
    from mcp_zen_of_languages.analyzers.base import BaseAnalyzer
    from mcp_zen_of_languages.analyzers.pipeline import PipelineConfig

    type AnalyzerClass = type[BaseAnalyzer]

SUPPORTED_LANGUAGES: tuple[str, ...] = (
    "python",
    "pydantic",
    "fastapi",
    "django",
    "sqlalchemy",
    "typescript",
    "react",
    "angular",
    "nextjs",
    "javascript",
    "vue",
    "go",
    "rust",
    "svg",
    "bash",
    "powershell",
    "ruby",
    "cpp",
    "csharp",
    "css",
    "docker_compose",
    "dockerfile",
    "ansible",
    "yaml",
    "github-actions",
    "toml",
    "xml",
    "json",
    "sql",
    "terraform",
    "markdown",
    "latex",
    "gitlab_ci",
)

# Framework analyzer aliases are resolved lazily via (module_path, class_name)
# tuples to avoid importing every framework at module load time.
_FRAMEWORK_ALIASES: dict[str, tuple[str, str]] = {
    "pydantic": (
        "mcp_zen_of_languages.frameworks.pydantic.analyzer",
        "PydanticAnalyzer",
    ),
    "fastapi": (
        "mcp_zen_of_languages.frameworks.fastapi.analyzer",
        "FastAPIAnalyzer",
    ),
    "django": (
        "mcp_zen_of_languages.frameworks.django.analyzer",
        "DjangoAnalyzer",
    ),
    "sqlalchemy": (
        "mcp_zen_of_languages.frameworks.sqlalchemy.analyzer",
        "SQLAlchemyAnalyzer",
    ),
    "sqla": (
        "mcp_zen_of_languages.frameworks.sqlalchemy.analyzer",
        "SQLAlchemyAnalyzer",
    ),
    "react": (
        "mcp_zen_of_languages.frameworks.react.analyzer",
        "ReactAnalyzer",
    ),
    "angular": (
        "mcp_zen_of_languages.frameworks.angular.analyzer",
        "AngularAnalyzer",
    ),
    "nextjs": (
        "mcp_zen_of_languages.frameworks.nextjs.analyzer",
        "NextjsAnalyzer",
    ),
    "next.js": (
        "mcp_zen_of_languages.frameworks.nextjs.analyzer",
        "NextjsAnalyzer",
    ),
    "next": (
        "mcp_zen_of_languages.frameworks.nextjs.analyzer",
        "NextjsAnalyzer",
    ),
    "vue": (
        "mcp_zen_of_languages.frameworks.vue.analyzer",
        "VueAnalyzer",
    ),
}

_ANALYZERS_BY_ALIAS: dict[str, AnalyzerClass] = {
    "python": PythonAnalyzer,
    "py": PythonAnalyzer,
    "typescript": TypeScriptAnalyzer,
    "ts": TypeScriptAnalyzer,
    "tsx": TypeScriptAnalyzer,
    "javascript": JavaScriptAnalyzer,
    "js": JavaScriptAnalyzer,
    "jsx": JavaScriptAnalyzer,
    "go": GoAnalyzer,
    "rust": RustAnalyzer,
    "rs": RustAnalyzer,
    "svg": SvgAnalyzer,
    "bash": BashAnalyzer,
    "sh": BashAnalyzer,
    "shell": BashAnalyzer,
    "powershell": PowerShellAnalyzer,
    "ps": PowerShellAnalyzer,
    "pwsh": PowerShellAnalyzer,
    "ruby": RubyAnalyzer,
    "rb": RubyAnalyzer,
    "cpp": CppAnalyzer,
    "c++": CppAnalyzer,
    "cc": CppAnalyzer,
    "cxx": CppAnalyzer,
    "csharp": CSharpAnalyzer,
    "cs": CSharpAnalyzer,
    "css": CssAnalyzer,
    "scss": CssAnalyzer,
    "less": CssAnalyzer,
    "docker_compose": DockerComposeAnalyzer,
    "docker-compose": DockerComposeAnalyzer,
    "dockerfile": DockerfileAnalyzer,
    "docker": DockerfileAnalyzer,
    "ansible": AnsibleAnalyzer,
    "ansible-playbook": AnsibleAnalyzer,
    "yaml": YamlAnalyzer,
    "yml": YamlAnalyzer,
    "github-actions": GitHubActionsAnalyzer,
    "github_actions": GitHubActionsAnalyzer,
    "gha": GitHubActionsAnalyzer,
    "toml": TomlAnalyzer,
    "xml": XmlAnalyzer,
    "json": JsonAnalyzer,
    "sql": SqlAnalyzer,
    "postgresql": SqlAnalyzer,
    "mysql": SqlAnalyzer,
    "sqlite": SqlAnalyzer,
    "mssql": SqlAnalyzer,
    "terraform": TerraformAnalyzer,
    "tf": TerraformAnalyzer,
    "gitlab-ci": GitLabCIAnalyzer,
    "gitlab_ci": GitLabCIAnalyzer,
    "gitlabci": GitLabCIAnalyzer,
    "markdown": MarkdownAnalyzer,
    "mdx": MarkdownAnalyzer,
    "latex": LatexAnalyzer,
    "tex": LatexAnalyzer,
    "ltx": LatexAnalyzer,
    "sty": LatexAnalyzer,
    "bib": LatexAnalyzer,
    "bibtex": LatexAnalyzer,
}


def _resolve_framework_class(alias: str) -> AnalyzerClass:
    """Lazily import and return a framework analyzer class by alias."""
    module_path, class_name = _FRAMEWORK_ALIASES[alias]
    module = importlib.import_module(module_path)
    return getattr(module, class_name)


def supported_languages() -> tuple[str, ...]:
    """Return canonical language identifiers accepted by ``create_analyzer``."""
    return SUPPORTED_LANGUAGES


def create_analyzer(
    language: str,
    config: AnalyzerConfig | None = None,
    pipeline_config: PipelineConfig | None = None,
) -> BaseAnalyzer:
    """Create a language-specific analyzer instance.

    Normalises *language* to lowercase and matches it against known
    identifiers and aliases.  The returned analyzer has its detection
    pipeline pre-built from zen rules, optionally overlaid with
    *pipeline_config* overrides from ``zen-config.yaml``.

    Framework analyzers (React, Vue, Angular, etc.) are imported lazily on
    first use; language analyzers are imported eagerly at module load.

    Args:
        language (str): Language name or alias (case-insensitive).  Common
            aliases are accepted — see the table below.
        config (AnalyzerConfig | None, optional): Global analyzer thresholds; passed through to the
            analyzer's ``__init__``. Default to None.
        pipeline_config (PipelineConfig | None, optional): Optional detector-level overrides merged on
            top of the rule-derived pipeline. Default to None.

    Returns:
        BaseAnalyzer: A configured [`BaseAnalyzer`][mcp_zen_of_languages.analyzers.base.BaseAnalyzer]
        subclass ready to call ``analyze``.

    Raises:
        ValueError: If *language* does not match any supported language.

    Note:
        **Supported languages and accepted aliases:**

        =============================== ===================================
        Language                        Accepted identifiers
        =============================== ===================================
        Python                          ``python``, ``py``
        TypeScript                      ``typescript``, ``ts``, ``tsx``
        JavaScript                      ``javascript``, ``js``, ``jsx``
        Go                              ``go``
        Rust                            ``rust``, ``rs``
        SVG                             ``svg``
        Bash                            ``bash``, ``sh``, ``shell``
        PowerShell                      ``powershell``, ``ps``, ``pwsh``
        Ansible                         ``ansible``, ``ansible-playbook``
        Ruby                            ``ruby``, ``rb``
        C++                             ``cpp``, ``c++``, ``cc``, ``cxx``
        C#                              ``csharp``, ``cs``
        CSS                             ``css``, ``scss``, ``less``
        Docker Compose                  ``docker_compose``, ``docker-compose``
        Dockerfile                      ``dockerfile``, ``docker``
        YAML                            ``yaml``, ``yml``
        GitHub Actions                  ``github-actions``, ``github_actions``, ``gha``
        TOML                            ``toml``
        XML                             ``xml``
        JSON                            ``json``
        SQL                             ``sql``, ``postgresql``, ``mysql``, ``sqlite``, ``mssql``
        Terraform                       ``terraform``, ``tf``
        Markdown / MDX                  ``markdown``, ``mdx``
        LaTeX                           ``latex``, ``tex``, ``ltx``, ``sty``, ``bib``, ``bibtex``
        =============================== ===================================
    """
    lang = language.lower()
    if lang in _FRAMEWORK_ALIASES:
        analyzer_class = _resolve_framework_class(lang)
    else:
        analyzer_class = _ANALYZERS_BY_ALIAS.get(lang)
    if analyzer_class is None:
        msg = f"Unsupported language: {language}"
        raise ValueError(msg)
    return analyzer_class(config=config, pipeline_config=pipeline_config)
