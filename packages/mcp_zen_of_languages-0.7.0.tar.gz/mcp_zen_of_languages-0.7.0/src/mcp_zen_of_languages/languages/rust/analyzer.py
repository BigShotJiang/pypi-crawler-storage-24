"""Language-specific analyzer implementation for rust source files."""

from __future__ import annotations

import re

from typing import TYPE_CHECKING


if TYPE_CHECKING:
    from mcp_zen_of_languages.analyzers.pipeline import PipelineConfig
    from mcp_zen_of_languages.models import CyclomaticSummary
    from mcp_zen_of_languages.models import ParserResult

from mcp_zen_of_languages.analyzers.base import AnalysisContext
from mcp_zen_of_languages.analyzers.base import AnalyzerCapabilities
from mcp_zen_of_languages.analyzers.base import AnalyzerConfig
from mcp_zen_of_languages.analyzers.base import BaseAnalyzer
from mcp_zen_of_languages.analyzers.base import DetectionPipeline


_USE_RE = re.compile(r"^use\s+([\w:]+)")
_MOD_RE = re.compile(r"^mod\s+(\w+)\s*;")
_EXTERN_RE = re.compile(r"^extern\s+crate\s+(\w+)")


class RustAnalyzer(BaseAnalyzer):
    """Analyzer for Rust source files centered on ownership safety and idiomatic patterns.

    Rust analysis is distinct because the language's borrow checker enforces
    memory safety at compile time, but developers can bypass those guarantees
    with ``unsafe`` blocks, ``unwrap()`` calls, and excessive ``clone()``.
    This analyzer applies regex-based detectors to flag those escape hatches
    alongside idiomatic checks for newtype patterns, iterator preference,
    and standard-trait implementations.

    Note:
        No Rust AST parser is currently wired; ``parse_code`` returns
        ``None`` and detectors operate on raw source text.

    See Also:
        ``RustUnwrapUsageDetector``, ``RustUnsafeBlocksDetector`` for the
        highest-impact detectors in this pipeline.
    """

    def __init__(
        self,
        config: AnalyzerConfig | None = None,
        pipeline_config: PipelineConfig | None = None,
    ) -> None:
        """Initialize instance.

        Args:
            config (AnalyzerConfig | None, optional): Typed detector or analyzer configuration that controls thresholds. Default to None.
            pipeline_config ('PipelineConfig' | None, optional): Optional pipeline overrides used to customize detector configuration. Default to None.
        """
        self._pipeline_config = pipeline_config
        super().__init__(config=config)

    def default_config(self) -> AnalyzerConfig:
        """Return default analyzer configuration for this language.

        Returns:
            AnalyzerConfig: Default analyzer settings for the current language implementation.
        """
        return AnalyzerConfig()

    def language(self) -> str:
        """Return the analyzer language key.

        Returns:
            str: Identifier string consumed by callers.
        """
        return "rust"

    def capabilities(self) -> AnalyzerCapabilities:
        """Declare support for use/mod/extern crate dependency extraction."""
        return AnalyzerCapabilities(supports_dependency_analysis=True)

    def parse_code(self, _code: str) -> ParserResult | None:
        """Parse source text into a language parser result when available.

        Args:
            _code (str): Source code text being parsed or analyzed.

        Returns:
            ParserResult | None: Normalized parser output, or ``None`` when parsing is unavailable.
        """
        return None

    def compute_metrics(
        self,
        code: str,
        _ast_tree: ParserResult | None,
    ) -> tuple[CyclomaticSummary | None, float | None, int]:
        """Compute complexity, maintainability, and line-count metrics.

        Args:
            code (str): Source code text being parsed or analyzed.
            _ast_tree (ParserResult | None): Parsed syntax tree produced by the language parser, when available.

        Returns:
            tuple[CyclomaticSummary | None, float | None, int]: Tuple containing computed metrics in analyzer-defined order.
        """
        return None, None, len(code.splitlines())

    def build_pipeline(self) -> DetectionPipeline:
        """Build the detector pipeline for this analyzer.

        Returns:
            DetectionPipeline: Pipeline instance used to run configured detectors.
        """
        return super().build_pipeline()

    def _build_dependency_analysis(self, context: AnalysisContext) -> object | None:
        """Extract ``use``, ``mod``, and ``extern crate`` dependencies.

        Args:
            context (AnalysisContext): Analysis context containing source text and intermediate metrics.

        Returns:
            object | None: DependencyAnalysis with import edges, or ``None`` when no dependencies found.
        """
        imports: list[str] = []
        for line in context.code.splitlines():
            stripped = line.strip()
            for pattern in (_USE_RE, _MOD_RE, _EXTERN_RE):
                m = pattern.match(stripped)
                if m:
                    imports.append(m.group(1))
                    break
        if not imports:
            return None
        from mcp_zen_of_languages.metrics.dependency_graph import build_import_graph

        return build_import_graph({(context.path or "<current>"): imports})
