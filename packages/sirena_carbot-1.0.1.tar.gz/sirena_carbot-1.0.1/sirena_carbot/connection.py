"""
Module-level singleton connection to the carbot USB device.

Usage:
    from sirena_carbot import connect, disconnect

    connect()           # auto-detect port
    connect("COM3")     # specify port explicitly
    disconnect()
"""

import sys
import os
import socket
import threading
import subprocess
import time

# Allow importing serial_communication from the parent directory when developing locally,
# and from inside the installed package otherwise.
_here = os.path.dirname(os.path.abspath(__file__))
_parent = os.path.dirname(_here)
if _parent not in sys.path:
    sys.path.insert(0, _parent)

from serial_communication import SerialManager  # noqa: E402

# ---------------------------------------------------------------------------
# Module-level singletons
# ---------------------------------------------------------------------------

_manager: SerialManager = SerialManager()

PROTOCOL = "LUCI_local"
TARGET = 245

_monitor_client = None


# ---------------------------------------------------------------------------
# RX Monitor
# ---------------------------------------------------------------------------

def enable_rx_monitor() -> None:
    """
    Open a separate terminal window that displays all incoming RX serial data.
    Call this before connect().
    """
    global _monitor_client

    # Start socket server on a free port
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("127.0.0.1", 0))
    port = server.getsockname()[1]
    server.listen(1)

    # Open a new terminal running _rx_monitor.py
    monitor_script = os.path.join(_here, "_rx_monitor.py")
    subprocess.Popen(
        f'start "RX Monitor" cmd /k python "{monitor_script}" {port}',
        shell=True,
    )

    # Accept the monitor connection in background
    def _accept():
        global _monitor_client
        server.settimeout(5)
        try:
            _monitor_client, _ = server.accept()
        except socket.timeout:
            pass

    threading.Thread(target=_accept, daemon=True).start()
    time.sleep(1)   # allow monitor window to connect

    # Attach log callback to forward RX lines to the monitor
    def _on_log(entry):
        if _monitor_client and entry["type"] == "rx":
            try:
                msg = f"[{entry['timestamp']}] RX: {entry['message']}\n"
                _monitor_client.sendall(msg.encode("utf-8"))
            except Exception:
                pass

    _manager.log_callback = _on_log


# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------

def connect(port: str = None) -> bool:
    """
    Connect to the carbot USB device.

    Args:
        port: Serial port name (e.g. 'COM3', '/dev/ttyUSB0').
              If omitted, the first available port is used automatically.

    Returns:
        True on success, False on failure.

    Raises:
        RuntimeError: If no serial ports are found and no port was specified.
    """
    if port is None:
        ports = _manager.list_available_ports()
        if not ports:
            raise RuntimeError(
                "No serial ports found. "
                "Plug in the carbot USB device and try again, "
                "or pass the port name explicitly: connect('COM3')"
            )
        port = ports[0]["port"]
        print(f"[sirena_carbot] Auto-selected port: {port}")

    return _manager.connect(port)


def disconnect() -> None:
    """Disconnect from the carbot USB device."""
    _manager.disconnect()


def list_ports() -> list:
    """Return a list of available serial ports (dicts with 'port', 'description', 'hwid')."""
    return _manager.list_available_ports()


def _send(command_name: str) -> bool:
    """
    Internal helper: send a LUCI_local command by name.

    Sends:  LUCI_local 245 <command_name>

    Returns True if the write succeeded, False otherwise.
    """
    cmd = f"{PROTOCOL} {TARGET} {command_name}"
    return _manager.write(cmd)
