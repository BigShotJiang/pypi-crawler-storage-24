"""
High-level carbot control functions.

Each function accepts a single `state` argument:
    state = 1  →  ON  → sends  "LUCI_local 245 <command>"  over USB
    state = 0  →  OFF →  placeholder (does nothing, returns False)

Usage:
    from sirena_carbot import connect, front_right_window_up

    connect()
    front_right_window_up(1)   # rolls window up
    front_right_window_up(0)   # no-op placeholder
"""

from .connection import _send


# ---------------------------------------------------------------------------
# Internal factory
# ---------------------------------------------------------------------------

def _make_control(command_name: str):
    """
    Return a control function that sends `command_name` when state=1
    and acts as a placeholder when state=0.
    """
    def control(state: int) -> bool:
        """
        Args:
            state: 1 to activate (sends USB command), 0 is a placeholder (no-op).

        Returns:
            True if the command was sent successfully, False otherwise.
        """
        if state == 1:
            return _send(command_name)
        # state == 0: placeholder – command not yet implemented for OFF
        return False

    control.__name__ = command_name
    control.__qualname__ = command_name
    control.__doc__ = (
        f"Control: {command_name}\n\n"
        f"    state=1  →  sends  'LUCI_local 245 {command_name}'  over USB\n"
        f"    state=0  →  placeholder, does nothing\n"
    )
    return control


# ---------------------------------------------------------------------------
# Window controls
# ---------------------------------------------------------------------------

front_right_window_up   = _make_control("front_right_window_up")
front_right_window_down = _make_control("front_right_window_down")

front_left_window_up    = _make_control("front_left_window_up")
front_left_window_down  = _make_control("front_left_window_down")

rear_right_window_up    = _make_control("rear_right_window_up")
rear_right_window_down  = _make_control("rear_right_window_down")

rear_left_window_up     = _make_control("rear_left_window_up")
rear_left_window_down   = _make_control("rear_left_window_down")


# ---------------------------------------------------------------------------
# Mirror controls
# ---------------------------------------------------------------------------

mirror_fold   = _make_control("mirror_fold")
mirror_unfold = _make_control("mirror_unfold")


# ---------------------------------------------------------------------------
# Child lock controls
# ---------------------------------------------------------------------------

child_lock_on  = _make_control("child_lock_on")
child_lock_off = _make_control("child_lock_off")


# ---------------------------------------------------------------------------
# (Add more controls below in the same pattern as needed)
# ---------------------------------------------------------------------------
# Example:
#   horn = _make_control("horn")
#   headlights_on = _make_control("headlights_on")
