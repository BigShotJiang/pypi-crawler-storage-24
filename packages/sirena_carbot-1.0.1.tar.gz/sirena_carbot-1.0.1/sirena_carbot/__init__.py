"""
sirena_carbot v1.0.1
Python library for controlling Sirena carbot features over USB via LUCI_local protocol.

Quick start
-----------
    from sirena_carbot import *

    enable_rx_monitor()         # open live RX window in a separate terminal
    connect()                   # auto-detect USB port

    front_right_window_up(1)    # sends LUCI_local 245 front_right_window_up
    mirror_fold(1)              # sends LUCI_local 245 mirror_fold
    child_lock_on(1)            # sends LUCI_local 245 child_lock_on

    front_right_window_up(0)    # placeholder – does nothing

    disconnect()
"""

# Connection helpers
from .connection import connect, disconnect, list_ports, enable_rx_monitor

# Window controls
from .controls import (
    front_right_window_up,
    front_right_window_down,
    front_left_window_up,
    front_left_window_down,
    rear_right_window_up,
    rear_right_window_down,
    rear_left_window_up,
    rear_left_window_down,
)

# Mirror controls
from .controls import (
    mirror_fold,
    mirror_unfold,
)

# Child lock controls
from .controls import (
    child_lock_on,
    child_lock_off,
)

__version__ = "1.0.1"

__all__ = [
    # connection
    "connect",
    "disconnect",
    "list_ports",
    "enable_rx_monitor",
    # windows
    "front_right_window_up",
    "front_right_window_down",
    "front_left_window_up",
    "front_left_window_down",
    "rear_right_window_up",
    "rear_right_window_down",
    "rear_left_window_up",
    "rear_left_window_down",
    # mirrors
    "mirror_fold",
    "mirror_unfold",
    # child lock
    "child_lock_on",
    "child_lock_off",
]
