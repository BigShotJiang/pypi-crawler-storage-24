"""
RX Monitor window — launched automatically by enable_rx_monitor().
Do not run this file directly.
"""

import socket
import sys

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 9999

print(f"=== Sirena Carbot — RX Monitor ===\n")

try:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect(("127.0.0.1", PORT))
    while True:
        data = s.recv(4096)
        if not data:
            break
        print(data.decode("utf-8", errors="replace"), end="", flush=True)
except (ConnectionRefusedError, ConnectionResetError):
    print("Connection closed.")
except KeyboardInterrupt:
    pass
finally:
    try:
        s.close()
    except Exception:
        pass

input("\nPress Enter to close...")
