# Plan: Add `/learn` REPL command

The `/learn` command tells the agent to review the current session for concrete mistakes or confusions and persist actionable notes to `.swival/memory/`. The system prompt already has standing policy about memory persistence (system_prompt.txt:53-55), but that's passive guidance — `/learn` is an explicit task trigger that says "do this review now."

## Changes needed

### 1. `swival/agent.py` — `_repl_help()` (~line 3165)

Add `/learn` to the help text between `/continue-status` and `/init`:

```
/learn             Review session for mistakes and persist to memory
```

### 2. `swival/agent.py` — REPL command dispatch (~line 3563, before `/continue`)

Add a new `elif cmd == "/learn":` block that:

1. Appends a user message with an explicit task prompt
2. Calls `run_agent_loop()` (same pattern as `/continue`)

Injected user message content — this is a task instruction, not a restatement of policy:

```
Review this session for concrete mistakes, confusions, or surprises you encountered with tools, commands, APIs, or syntax. For each one, persist a concise note to `.swival/memory/MEMORY.md` so you don't repeat it in future sessions. Keep MEMORY.md short (bulleted notes). For detailed topics, create separate files in `.swival/memory/` and reference them from MEMORY.md. If there is nothing worth noting, say so.
```

### Implementation pattern

Follows the same pattern as `/continue`:
- Append user message, call `run_agent_loop()`, handle KeyboardInterrupt, print answer
- History label: `"/learn"`
- The message content is the fixed task prompt above

### 3. `tests/test_repl.py` — New `TestLearnCommand` class

Add tests mirroring the existing `TestContinueCommand` (line 858) and `TestHelpCommand` (line 402) patterns:

1. **`test_help_includes_learn`** — Assert `/learn` appears in `_repl_help()` output (same style as `test_help_prints_commands`)
2. **`test_learn_appends_user_message`** — `/learn` appends a user message containing the task prompt before calling `run_agent_loop()`. Capture message snapshots and verify the last user message contains "Review this session"
3. **`test_learn_invokes_loop`** — `/learn` triggers `run_agent_loop()` (assert call count)
4. **`test_learn_prints_answer`** — Answer from the loop is printed to stdout
5. **`test_learn_keyboard_interrupt`** — KeyboardInterrupt during `/learn` is caught and the REPL continues (does not crash)
6. **`test_learn_history_label`** — If history is enabled, `append_history` is called with label `"/learn"`

## What it does NOT need

- No new files or modules
- No config changes
- No new tool definitions
- No changes to `skills.py` (this is a REPL command, not a skill)
