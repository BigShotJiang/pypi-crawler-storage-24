# Batch Todo Implementation Progress

- [ ] Update schema in `swival/tools.py` — replace `task` with `tasks` (oneOf string/array)
- [ ] Rewrite `TodoState.process()` in `swival/todo.py` — input normalization, batch loop, error collection
- [ ] Refactor `_add`/`_done`/`_remove` to not call `_save()` — caller handles it
- [ ] Update `fmt.py` if needed for batch display
- [ ] Update existing tests to use `tasks` key
- [ ] Add new batch tests
- [ ] Run full test suite and fix failures
