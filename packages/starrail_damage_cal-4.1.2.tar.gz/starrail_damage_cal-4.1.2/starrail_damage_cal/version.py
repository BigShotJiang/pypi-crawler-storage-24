StarRail_version = "4.1.2"
