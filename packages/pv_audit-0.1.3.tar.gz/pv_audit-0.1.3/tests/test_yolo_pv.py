from ultralytics import YOLO
import cv2
import pv_audit
from ultralytics.utils import ASSETS

print("✅ pv_audit import success")

# 加载YOLO模型
model = YOLO("yolov8n.pt")

# 读取YOLO官方示例图片
img_path = str(ASSETS / "bus.jpg")
img = cv2.imread(img_path)

# YOLO推理
results = model(img)[0]

detections = []

for box in results.boxes:
    cls = int(box.cls[0])
    conf = float(box.conf[0])
    xyxy = box.xyxy[0].tolist()

    detections.append({
        "class": results.names[cls],
        "confidence": conf,
        "bbox": xyxy
    })

print("YOLO detections:")
for d in detections:
    print(d)

# 调用你的库
try:
    result = pv_audit.run_audit(detections)
    print("\n✅ pv_audit run success")
    print(result)
except Exception as e:
    print("\n❌ pv_audit call failed")
    print(e)