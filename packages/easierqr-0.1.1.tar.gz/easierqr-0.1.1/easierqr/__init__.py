from .qr_gui import EasierQR

# Kullanıcı artık sadece easierqr üzerinden kullanacak
def url(data):
    return EasierQR().url(data)

def show(obj):
    obj.show()
