import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
import qrcode
import sys

class EasierQR:
    def __init__(self):
        self.data = None
        self.img = None
        self.root = None

    def url(self, data):
        if not data:
            raise ValueError("Data boş olamaz")
        self.data = data
        # QR kod üret
        qr = qrcode.QRCode(version=1, box_size=10, border=4)
        qr.add_data(data)
        qr.make(fit=True)
        self.img = qr.make_image(fill_color="black", back_color="white")
        return self

    def show(self):
        if not self.img:
            raise RuntimeError("Önce url() ile veri girilmeli")

        self.root = tk.Tk()
        self.root.title("QR Kod Görüntüleyici")

        # Üstte veri göster
        data_label = tk.Label(self.root, text=self.data, font=("Arial", 12))
        data_label.pack(pady=(10,0))

        # QR kod
        tk_img = ImageTk.PhotoImage(self.img)
        label = tk.Label(self.root, image=tk_img)
        label.pack(padx=35, pady=10)

        # İndir butonu
        def save_qr():
            file_path = filedialog.asksaveasfilename(
                defaultextension=".png",
                filetypes=[("PNG dosyaları","*.png"), ("Tüm dosyalar","*.*")],
                title="QR Kodunu Kaydet"
            )
            if file_path:
                try:
                    self.img.save(file_path)
                    messagebox.showinfo("Başarılı", f"QR kodu kaydedildi:\n{file_path}")
                except Exception as e:
                    messagebox.showerror("Hata", f"Kaydedilemedi:\n{e}")

        save_button = tk.Button(self.root, text="İndir", command=save_qr)
        save_button.pack(pady=10)

        self.root.mainloop()
