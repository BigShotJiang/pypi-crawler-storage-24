\# easierqr



GUI based QR code generator Python module.



\## Setup



```bash

pip install easierqr

