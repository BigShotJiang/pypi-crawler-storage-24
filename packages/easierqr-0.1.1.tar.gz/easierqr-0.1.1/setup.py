from setuptools import setup, find_packages

setup(
    name="easierqr",                  # Paket adı (PyPI’de eşsiz olmalı)
    version="0.1.1",
    packages=find_packages(),         # otomatik easierqr klasörünü bulur
    install_requires=[
        "qrcode[pil]",
        "Pillow"
    ],
    python_requires=">=3.10",
    description="GUI based QR code generator",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    author="Porwix",
    url="https://github.com/kullanici/easierqr",  # opsiyonel
    license="MIT",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
