"""xcom_api.py: communication api to Studer Xcom via LAN."""

import asyncio
import httpx
import ipaddress
import logging
import os
import struct

from dataclasses import dataclass

from .api_base_async import (
    AsyncXcomApiBase,
)
from .api_base_sync import (
    XcomApiBase,
)
from .const import (
    XcomDiscoverNotConnected,
)
from .data import (
    XcomDiscoveredDevice,
    XcomDiscoveredClient,
)
from .datapoints import (
    XcomDatapoint,
    XcomDataset,
    XcomDatapointUnknownException,
)
from .families import (
    XcomDeviceFamilies
)

_LOGGER = logging.getLogger(__name__)
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)


class AsyncXcomDiscover:

    def __init__(self, api: AsyncXcomApiBase, dataset: XcomDataset):
        """
        MOXA is connecting to the TCP Server we are creating here.
        Once it is connected we can send package requests.
        """
        self._api = api
        self._dataset = dataset


    async def discover_devices(self, getExtendedInfo = False, verbose = False) -> list[XcomDiscoveredDevice]:
        """
        Discover which Studer devices can be reached via the Xcom client
        """
        devices: list[XcomDiscoveredDevice] = []

        # Sanity check
        if not self._api.connected:
            raise XcomDiscoverNotConnected("XcomApi is not connected to remote client; please connect first.")
        
        # Check presence of devices for each family
        for family in XcomDeviceFamilies.get_list():

            _LOGGER.info(f"Trying family {family.id} ({family.model})")

            # Get value for the specific discovery nr, or otherwise the first info nr or first param nr
            nr = family.nr_discover or family.nr_infos_start or family.nr_params_start or None
            if not nr:
                continue

            # Iterate all addresses in the family, up to the first address that is not found
            for device_addr in range(family.addr_devices_start, family.addr_devices_end+1):

                device_code = family.get_code(device_addr)

                # Have we already discovered a device for this address?
                device_found = next((d for d in devices if d.addr == device_addr), None)
                if device_found is not None:
                    # Do not test further device addresses in this family
                    _LOGGER.info(f"  Skip device {device_code}; already found device {device_found.code}")
                    break

                # Send the test request to the device. This will return None in case:
                # - the device does not exist (DEVICE_NOT_FOUND)
                # - the device does not support the param (INVALID_DATA), used to distinguish BSP from BMS
                try:
                    param = self._dataset.get_by_nr(nr, family.id_for_nr)

                    _LOGGER.info(f"Trying device {device_code} on {device_addr} for nr {nr}")
                    value = await self._api.request_value(param, device_addr, verbose=verbose)
                    if value is not None:
                        _LOGGER.info(f"  Found device {device_code} via {nr}:{device_addr}")

                        device = XcomDiscoveredDevice(device_code, device_addr, family.id, family.model)
                        if getExtendedInfo:
                            device = await self.get_extended_device_info(device, verbose=verbose)
                        
                        devices.append(device)

                    else:
                        _LOGGER.info(f"  No device {device_code}; no value returned from Xcom client")

                except Exception as e:
                    _LOGGER.info(f"  No device {device_code}; no value returned from Xcom client: {e}")

                    # Do not test further device addresses in this family
                    break

        return devices


    async def get_extended_device_info(self, device: XcomDiscoveredDevice, verbose=False) -> XcomDiscoveredDevice:
        # ID type
        # ID HW
        # ID HW PWR
        # ID SOFT msb/lsb
        # ID SID
        # ID FID msb/lsb
        try:
            _LOGGER.info(f"Trying to get extended device info for device {device.code})")
            family = XcomDeviceFamilies.get_by_id(device.family_id)

            id_type    = await self._request_value_by_name("ID type",     family.id, device.addr, verbose=verbose)
            id_hw      = await self._request_value_by_name("ID HW",       family.id, device.addr, verbose=verbose)
            id_hw_pwr  = await self._request_value_by_name("ID HW PWR",   family.id, device.addr, verbose=verbose)
            id_sw_msb  = await self._request_value_by_name("ID SOFT msb", family.id, device.addr, verbose=verbose)
            id_sw_lsb  = await self._request_value_by_name("ID SOFT lsb", family.id, device.addr, verbose=verbose)
            id_fid_msb = await self._request_value_by_name("ID FID msb",  family.id, device.addr, verbose=verbose)
            id_fid_lsb = await self._request_value_by_name("ID FID lsb",  family.id, device.addr, verbose=verbose)

            device.device_model = self._decode_type(id_type, "ID type", family.id_for_nr)
            device.hw_version   = self._decode_id_hw(id_hw, id_hw_pwr)
            device.sw_version   = self._decode_id_sw(id_sw_msb, id_sw_lsb)
            device.fid          = self._decode_fid(id_fid_msb, id_fid_lsb)

            _LOGGER.info(f"  Found extended device info: model: {device.device_model}, hw_version: {device.hw_version}, sw_version: {device.sw_version}, fid: {device.fid})")

        except Exception as e:
            _LOGGER.warning(f"  Exception in getExtendedDeviceInfo: {e}")

        return device


    async def _request_value_by_name(self, param_name, family_id, device_addr, verbose=False):
        try:
            param = self._dataset.get_by_name(param_name, family_id)
            return await self._api.request_value(param, device_addr, verbose=verbose)
        except:
            # Not all devices have these IDs
            return None
        

    def _decode_type(self, val, param_name, family_id):
        if val is None:
            return None

        param = self._dataset.get_by_name(param_name, family_id)
        return param.options.get(str(int(val)), None) if param.options else None


    def _decode_id_hw(self, cmd, pwr):
        if cmd is None:
            return None
        
        bytes_cmd = struct.pack(">H", int(cmd))
        if pwr is None:
            return f"{int(bytes_cmd[0])}.{int(bytes_cmd[1])}"
        else:
            bytes_pwr = struct.pack(">H", int(pwr))
            return f"{int(bytes_cmd[0])}.{int(bytes_cmd[1])} / {int(bytes_pwr[0])}.{int(bytes_pwr[1])}"


    def _decode_id_sw(self, msb, lsb):
        if msb is None or lsb is None:
            return None
        
        bytes = struct.pack(">H", int(msb)) + struct.pack(">H", int(lsb))
        return f"{int(bytes[0])}.{int(bytes[2])}.{int(bytes[3])}"


    def _decode_fid(self, msb, lsb):
        if msb is None or lsb is None:
            return None
        
        bytes = struct.pack(">H", int(msb)) + struct.pack(">H", int(lsb))
        return bytes.hex(' ',4).upper()


    async def discover_client_info(self, verbose=False) -> XcomDiscoveredClient:
        """
        Discover extended info about the remote Xcom client connected to us
        """

        # Sanity checks
        if not self._api.connected:
            raise XcomDiscoverNotConnected("XcomApi is not connected to remote client; please connect first.")

        if not self._api.remote_ip:
            raise XcomDiscoverNotConnected("No IP address was detected for the remote client")

        _LOGGER.info(f"Trying to get client info")
        client_ip = None
        client_guid = None

        try:
            client_ip = str(ipaddress.ip_address(self._api.remote_ip))

            _LOGGER.info(f"  Found ip: {client_ip}")

        except Exception as e:
            _LOGGER.warning(f"  Exception in discoverClientInfo: {e}")

        try:
            client_guid = await self._api.request_guid(verbose=verbose)

            _LOGGER.info(f"  Found guid: {client_guid}")

        except Exception as e:
            _LOGGER.warning(f"  Exception in discoverClientInfo: {e}")

        return XcomDiscoveredClient(
            ip = client_ip,
            guid = client_guid,
        )


    @staticmethod
    async def discover_moxa_webconfig(hint: str = None) -> str:
        """
        Discover if Moxa Web Config page can be found on the local network
        """

        # Find all device IP addresses to check
        urls: list[str] = [hint] if hint else []
        urls.append("http://192.168.127.254")   # default if using static address

        for line in os.popen('arp -a'):     # arp seems to be available on Linux, Windows and Pi
            try:
                # Linux:  
                #   ? (192.168.88.250) at 00:90:e8:3c:f8:7e [ether] on end0
                #   ...
                # Windows: 
                #   Interface: 192.168.88.100 --- 0x4
                #     Internet Address      Physical Address      Type
                #     192.168.88.250        00-90-e8-3c-f8-7e     dynamic 
                #     ...
                
                device = line.strip('?').split()[0].strip('()')
                ip = ipaddress.ip_address(device)
                urls.append(f"http://{str(ip)}")
            except:
                pass

        # Define helper function to check for Moxa Web Config page
        async def check_url(client:httpx.AsyncClient, url:str) -> str|None:
            _LOGGER.info(f"Trying {url}")
            try:
                rsp = await client.get(url)
                if rsp and rsp.is_success and rsp.headers.get("Server", "").startswith("Moxa"):
                    return url
                else:
                    return None
            except:
                return None

        # Parallel check for Moxa Web Config page on all found device url's
        # No need to SSL verify plain HTTP GET calls, this also keeps Home Assistant happy
        async with httpx.AsyncClient(verify=False) as client:
            async with asyncio.TaskGroup() as task_group:
                tasks = [task_group.create_task(check_url(client, url)) for url in urls]

                # Start checking completed tasks immediately. Cancel remaining tasks if our url was found
                for task in asyncio.as_completed(tasks):
                    url = task.result() if hasattr(task, 'result') and callable(task.result) else await task
                    if url is not None:
                        for t in tasks:
                            t.cancel()

                        return url
                     
        return None
    
