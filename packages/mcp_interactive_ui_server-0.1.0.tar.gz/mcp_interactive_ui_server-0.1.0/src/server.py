"""
MCP Interactive UI Server — Hauptserver-Datei.

Gibt AI-Agents die Möglichkeit, interaktive UIs zu generieren:
Formulare, Dashboards, Charts, Tabellen, Wizards und Enhanced Markdown.
"""

from mcp.server.fastmcp import FastMCP
from .tools.ui import register_tools


# Server-Instanz erstellen
mcp = FastMCP(
    "Interactive UI Server",
    instructions=(
        "MCP Apps UI toolkit for AI agents. "
        "Generate interactive forms, dashboards, charts, tables, wizards, "
        "and enhanced markdown that MCP clients can render as native UIs. "
        "All tools return structured JSON schemas following the mcp-ui specification."
    ),
)

# UI-Tools registrieren
register_tools(mcp)


def main():
    """Startet den MCP-Server über stdio-Transport."""
    mcp.run()


if __name__ == "__main__":
    main()
