"""
MCP Interactive UI Tools — Generiert strukturierte UI-Definitionen,
die MCP-Clients als interaktive Oberflächen rendern können.
"""

import json
from datetime import datetime
from typing import Any


# ─── UI Schema-Definitionen ───────────────────────────────────────────

# Gültige Feld-Typen für Formulare
FIELD_TYPES = ["text", "number", "select", "checkbox", "date", "email", "password", "textarea", "radio", "range"]

# Gültige Widget-Typen für Dashboards
WIDGET_TYPES = ["chart", "stat_card", "table", "progress_bar", "metric", "list", "markdown"]

# Gültige Chart-Typen
CHART_TYPES = ["bar", "line", "pie", "scatter", "area", "donut", "heatmap"]


def _build_field(field: dict) -> dict:
    """Baut eine einzelne Feld-Definition für Formulare."""
    field_type = field.get("type", "text")
    if field_type not in FIELD_TYPES:
        field_type = "text"

    result = {
        "id": field.get("id", field.get("label", "field").lower().replace(" ", "_")),
        "type": field_type,
        "label": field.get("label", "Unnamed Field"),
        "required": field.get("required", False),
        "placeholder": field.get("placeholder", ""),
    }

    # Typ-spezifische Eigenschaften
    if field_type == "select" and "options" in field:
        result["options"] = field["options"]
    if field_type == "number":
        if "min" in field:
            result["min"] = field["min"]
        if "max" in field:
            result["max"] = field["max"]
        if "step" in field:
            result["step"] = field["step"]
    if field_type == "range":
        result["min"] = field.get("min", 0)
        result["max"] = field.get("max", 100)
        result["step"] = field.get("step", 1)
    if field_type == "textarea":
        result["rows"] = field.get("rows", 4)
    if field_type == "radio" and "options" in field:
        result["options"] = field["options"]
    if "default" in field:
        result["default"] = field["default"]
    if "validation" in field:
        result["validation"] = field["validation"]

    return result


def _build_widget(widget: dict) -> dict:
    """Baut eine einzelne Widget-Definition für Dashboards."""
    widget_type = widget.get("type", "stat_card")
    if widget_type not in WIDGET_TYPES:
        widget_type = "stat_card"

    result = {
        "id": widget.get("id", widget.get("title", "widget").lower().replace(" ", "_")),
        "type": widget_type,
        "title": widget.get("title", "Widget"),
    }

    # Typ-spezifische Eigenschaften
    if widget_type == "stat_card":
        result["value"] = widget.get("value", "0")
        result["unit"] = widget.get("unit", "")
        result["change"] = widget.get("change", None)
        result["trend"] = widget.get("trend", "neutral")  # up, down, neutral
    elif widget_type == "chart":
        result["chart_type"] = widget.get("chart_type", "bar")
        result["data"] = widget.get("data", {})
    elif widget_type == "table":
        result["headers"] = widget.get("headers", [])
        result["rows"] = widget.get("rows", [])
        result["sortable"] = widget.get("sortable", True)
    elif widget_type == "progress_bar":
        result["value"] = widget.get("value", 0)
        result["max"] = widget.get("max", 100)
        result["color"] = widget.get("color", "blue")
        result["label"] = widget.get("label", "")
    elif widget_type == "metric":
        result["value"] = widget.get("value", "0")
        result["prefix"] = widget.get("prefix", "")
        result["suffix"] = widget.get("suffix", "")
        result["sparkline"] = widget.get("sparkline", [])
    elif widget_type == "list":
        result["items"] = widget.get("items", [])
        result["ordered"] = widget.get("ordered", False)
    elif widget_type == "markdown":
        result["content"] = widget.get("content", "")

    # Layout-Optionen (Grid-Positionierung)
    if "width" in widget:
        result["width"] = widget["width"]  # 1-4 (Grid-Spalten)
    if "height" in widget:
        result["height"] = widget["height"]  # 1-4 (Grid-Zeilen)

    return result


def register_tools(mcp):
    """Registriert alle UI-Tools beim MCP-Server."""

    @mcp.tool()
    async def create_form(
        title: str,
        fields: list[dict[str, Any]],
        description: str = "",
        submit_label: str = "Submit",
        layout: str = "vertical"
    ) -> str:
        """Generiert eine JSON-Formular-Definition mit verschiedenen Feld-Typen.

        Erstellt ein strukturiertes Formular-Schema, das MCP-Clients
        als interaktives UI rendern können.

        Unterstützte Feld-Typen: text, number, select, checkbox, date,
        email, password, textarea, radio, range.

        Jedes Feld braucht mindestens: {"label": "Name", "type": "text"}
        Optional: id, required, placeholder, default, validation, options (für select/radio),
        min/max/step (für number/range), rows (für textarea).

        Args:
            title: Formular-Titel
            fields: Liste von Feld-Definitionen (dicts mit type, label, etc.)
            description: Optionale Beschreibung über dem Formular
            submit_label: Text des Submit-Buttons
            layout: "vertical" oder "horizontal" Feld-Anordnung

        Returns:
            JSON-String mit dem Formular-Schema
        """
        form_schema = {
            "$schema": "mcp-ui/form/v1",
            "type": "form",
            "title": title,
            "description": description,
            "layout": layout if layout in ("vertical", "horizontal") else "vertical",
            "fields": [_build_field(f) for f in fields],
            "actions": {
                "submit": {
                    "label": submit_label,
                    "type": "primary"
                },
                "cancel": {
                    "label": "Cancel",
                    "type": "secondary"
                }
            },
            "metadata": {
                "created_at": datetime.now().isoformat(),
                "field_count": len(fields),
                "version": "1.0"
            }
        }

        return json.dumps(form_schema, indent=2)

    @mcp.tool()
    async def create_dashboard(
        title: str,
        widgets: list[dict[str, Any]],
        description: str = "",
        columns: int = 3,
        refresh_interval: int = 0
    ) -> str:
        """Generiert ein Dashboard-Layout mit verschiedenen Widget-Typen.

        Erstellt eine strukturierte Dashboard-Definition mit konfigurierbarem
        Grid-Layout, die MCP-Clients als interaktives Dashboard rendern können.

        Unterstützte Widget-Typen: chart, stat_card, table, progress_bar,
        metric, list, markdown.

        Jedes Widget braucht mindestens: {"type": "stat_card", "title": "Users", "value": "1234"}

        Args:
            title: Dashboard-Titel
            widgets: Liste von Widget-Definitionen (dicts mit type, title, etc.)
            description: Optionale Dashboard-Beschreibung
            columns: Anzahl Grid-Spalten (1-6)
            refresh_interval: Auto-Refresh in Sekunden (0 = kein Refresh)

        Returns:
            JSON-String mit dem Dashboard-Schema
        """
        columns = max(1, min(6, columns))

        dashboard_schema = {
            "$schema": "mcp-ui/dashboard/v1",
            "type": "dashboard",
            "title": title,
            "description": description,
            "layout": {
                "type": "grid",
                "columns": columns,
                "gap": "16px",
                "padding": "24px"
            },
            "widgets": [_build_widget(w) for w in widgets],
            "settings": {
                "refresh_interval": refresh_interval,
                "theme": "auto",
                "responsive": True
            },
            "metadata": {
                "created_at": datetime.now().isoformat(),
                "widget_count": len(widgets),
                "version": "1.0"
            }
        }

        return json.dumps(dashboard_schema, indent=2)

    @mcp.tool()
    async def create_chart(
        chart_type: str,
        data: dict[str, Any],
        title: str = "Chart",
        x_label: str = "",
        y_label: str = "",
        colors: list[str] | None = None,
        stacked: bool = False
    ) -> str:
        """Generiert eine Chart-Definition (Bar, Line, Pie, Scatter, etc.).

        Erstellt ein Chart-Schema mit Daten und Konfiguration,
        das MCP-Clients als interaktives Diagramm rendern können.

        Unterstützte Chart-Typen: bar, line, pie, scatter, area, donut, heatmap.

        Daten-Format:
        - Für bar/line/area: {"labels": ["Jan","Feb"], "datasets": [{"label": "Sales", "values": [10,20]}]}
        - Für pie/donut: {"labels": ["A","B","C"], "values": [30, 50, 20]}
        - Für scatter: {"datasets": [{"label": "Set 1", "points": [{"x": 1, "y": 2}]}]}
        - Für heatmap: {"x_labels": [...], "y_labels": [...], "values": [[...]]}

        Args:
            chart_type: Art des Charts (bar, line, pie, scatter, area, donut, heatmap)
            data: Chart-Daten als Dictionary
            title: Chart-Titel
            x_label: Beschriftung X-Achse
            y_label: Beschriftung Y-Achse
            colors: Optionale Farbliste (hex oder CSS-Farbnamen)
            stacked: Gestapelte Darstellung (nur bar/area)

        Returns:
            JSON-String mit dem Chart-Schema
        """
        if chart_type not in CHART_TYPES:
            chart_type = "bar"

        # Standard-Farbpalette
        default_colors = [
            "#3B82F6", "#10B981", "#F59E0B", "#EF4444",
            "#8B5CF6", "#EC4899", "#06B6D4", "#84CC16"
        ]

        chart_schema = {
            "$schema": "mcp-ui/chart/v1",
            "type": "chart",
            "chart_type": chart_type,
            "title": title,
            "data": data,
            "config": {
                "x_label": x_label,
                "y_label": y_label,
                "colors": colors if colors else default_colors,
                "stacked": stacked and chart_type in ("bar", "area"),
                "legend": True,
                "animation": True,
                "tooltip": True,
                "responsive": True
            },
            "metadata": {
                "created_at": datetime.now().isoformat(),
                "version": "1.0"
            }
        }

        return json.dumps(chart_schema, indent=2)

    @mcp.tool()
    async def create_table(
        headers: list[str],
        rows: list[list[Any]],
        sortable: bool = True,
        filterable: bool = True,
        page_size: int = 10,
        title: str = ""
    ) -> str:
        """Generiert eine interaktive Tabellen-Definition mit Sortierung und Filterung.

        Erstellt ein Tabellen-Schema mit Spalten-Definitionen und Daten,
        das MCP-Clients als interaktive Tabelle rendern können.

        Args:
            headers: Liste von Spalten-Überschriften
            rows: Liste von Zeilen (jede Zeile ist eine Liste von Werten)
            sortable: Spalten sortierbar machen
            filterable: Suchfilter anzeigen
            page_size: Zeilen pro Seite (Pagination)
            title: Optionaler Tabellen-Titel

        Returns:
            JSON-String mit dem Tabellen-Schema
        """
        # Spalten-Definitionen aus Headers bauen
        columns = []
        for i, header in enumerate(headers):
            col = {
                "id": header.lower().replace(" ", "_"),
                "label": header,
                "sortable": sortable,
                "type": "string"  # Standard-Typ
            }

            # Typ-Erkennung aus den Daten
            if rows:
                sample = rows[0][i] if i < len(rows[0]) else None
                if isinstance(sample, (int, float)):
                    col["type"] = "number"
                    col["align"] = "right"
                elif isinstance(sample, bool):
                    col["type"] = "boolean"

            columns.append(col)

        table_schema = {
            "$schema": "mcp-ui/table/v1",
            "type": "table",
            "title": title,
            "columns": columns,
            "rows": [
                {
                    columns[j]["id"]: cell
                    for j, cell in enumerate(row)
                    if j < len(columns)
                }
                for row in rows
            ],
            "features": {
                "sortable": sortable,
                "filterable": filterable,
                "pagination": {
                    "enabled": len(rows) > page_size,
                    "page_size": page_size,
                    "total_rows": len(rows)
                },
                "selectable": False,
                "exportable": True
            },
            "metadata": {
                "created_at": datetime.now().isoformat(),
                "row_count": len(rows),
                "column_count": len(headers),
                "version": "1.0"
            }
        }

        return json.dumps(table_schema, indent=2)

    @mcp.tool()
    async def create_wizard(
        steps: list[dict[str, Any]],
        title: str = "Wizard",
        allow_skip: bool = False,
        show_progress: bool = True
    ) -> str:
        """Generiert einen Multi-Step-Formular-Wizard mit Validierung.

        Erstellt eine Wizard-Definition mit mehreren Schritten,
        die MCP-Clients als geführten Prozess rendern können.
        Jeder Schritt hat eigene Felder und Validierungsregeln.

        Jeder Step braucht: {"title": "Schritt 1", "fields": [...]}
        Optional: description, validation (dict mit Regeln).

        Validierungsregeln pro Step:
        - {"required_fields": ["name", "email"]}
        - {"custom": {"field_id": {"min_length": 3}}}

        Args:
            steps: Liste von Step-Definitionen (dicts mit title, fields, etc.)
            title: Wizard-Gesamttitel
            allow_skip: Schritte überspringbar machen
            show_progress: Fortschrittsanzeige einblenden

        Returns:
            JSON-String mit dem Wizard-Schema
        """
        wizard_steps = []
        for i, step in enumerate(steps):
            wizard_step = {
                "id": f"step_{i + 1}",
                "title": step.get("title", f"Step {i + 1}"),
                "description": step.get("description", ""),
                "fields": [_build_field(f) for f in step.get("fields", [])],
                "validation": step.get("validation", {}),
                "skippable": allow_skip and not step.get("required", True)
            }
            wizard_steps.append(wizard_step)

        wizard_schema = {
            "$schema": "mcp-ui/wizard/v1",
            "type": "wizard",
            "title": title,
            "steps": wizard_steps,
            "navigation": {
                "show_progress": show_progress,
                "allow_back": True,
                "allow_skip": allow_skip,
                "confirm_cancel": True
            },
            "actions": {
                "next": {"label": "Next", "type": "primary"},
                "back": {"label": "Back", "type": "secondary"},
                "finish": {"label": "Finish", "type": "primary"},
                "cancel": {"label": "Cancel", "type": "ghost"}
            },
            "metadata": {
                "created_at": datetime.now().isoformat(),
                "step_count": len(steps),
                "total_fields": sum(len(s.get("fields", [])) for s in steps),
                "version": "1.0"
            }
        }

        return json.dumps(wizard_schema, indent=2)

    @mcp.tool()
    async def render_markdown(
        content: str,
        interactive_elements: list[dict[str, Any]] | None = None,
        theme: str = "auto"
    ) -> str:
        """Erweitertes Markdown mit eingebetteten interaktiven Elementen.

        Kombiniert Standard-Markdown mit interaktiven UI-Komponenten
        wie Buttons, Toggles, Inputs und Accordions, die MCP-Clients
        inline rendern können.

        Interaktive Elemente werden via Platzhalter {{element_id}} im
        Markdown eingebettet.

        Unterstützte Element-Typen:
        - button: {"type": "button", "id": "btn1", "label": "Click", "action": "submit"}
        - toggle: {"type": "toggle", "id": "tog1", "label": "Dark Mode", "default": false}
        - input: {"type": "input", "id": "inp1", "placeholder": "Enter value..."}
        - accordion: {"type": "accordion", "id": "acc1", "title": "Details", "content": "..."}
        - alert: {"type": "alert", "id": "alt1", "severity": "info", "message": "Hinweis..."}
        - badge: {"type": "badge", "id": "bdg1", "text": "New", "color": "green"}
        - tabs: {"type": "tabs", "id": "tab1", "items": [{"label": "Tab 1", "content": "..."}]}

        Args:
            content: Markdown-Inhalt (mit optionalen {{element_id}} Platzhaltern)
            interactive_elements: Liste interaktiver Element-Definitionen
            theme: "auto", "light" oder "dark"

        Returns:
            JSON-String mit dem Enhanced-Markdown-Schema
        """
        ELEMENT_TYPES = ["button", "toggle", "input", "accordion", "alert", "badge", "tabs"]

        elements = {}
        if interactive_elements:
            for elem in interactive_elements:
                elem_type = elem.get("type", "button")
                if elem_type not in ELEMENT_TYPES:
                    continue

                elem_id = elem.get("id", f"elem_{len(elements)}")
                element_def = {
                    "type": elem_type,
                    "id": elem_id,
                }

                # Typ-spezifische Eigenschaften
                if elem_type == "button":
                    element_def["label"] = elem.get("label", "Button")
                    element_def["action"] = elem.get("action", "click")
                    element_def["variant"] = elem.get("variant", "primary")
                    element_def["icon"] = elem.get("icon", None)
                elif elem_type == "toggle":
                    element_def["label"] = elem.get("label", "Toggle")
                    element_def["default"] = elem.get("default", False)
                elif elem_type == "input":
                    element_def["placeholder"] = elem.get("placeholder", "")
                    element_def["input_type"] = elem.get("input_type", "text")
                elif elem_type == "accordion":
                    element_def["title"] = elem.get("title", "Details")
                    element_def["content"] = elem.get("content", "")
                    element_def["open"] = elem.get("open", False)
                elif elem_type == "alert":
                    element_def["severity"] = elem.get("severity", "info")
                    element_def["message"] = elem.get("message", "")
                elif elem_type == "badge":
                    element_def["text"] = elem.get("text", "")
                    element_def["color"] = elem.get("color", "blue")
                elif elem_type == "tabs":
                    element_def["items"] = elem.get("items", [])
                    element_def["default_tab"] = elem.get("default_tab", 0)

                elements[elem_id] = element_def

        markdown_schema = {
            "$schema": "mcp-ui/markdown/v1",
            "type": "enhanced_markdown",
            "content": content,
            "interactive_elements": elements,
            "config": {
                "theme": theme if theme in ("auto", "light", "dark") else "auto",
                "syntax_highlighting": True,
                "math_rendering": True,
                "mermaid_diagrams": True
            },
            "metadata": {
                "created_at": datetime.now().isoformat(),
                "element_count": len(elements),
                "content_length": len(content),
                "version": "1.0"
            }
        }

        return json.dumps(markdown_schema, indent=2)
