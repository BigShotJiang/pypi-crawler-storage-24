from __future__ import annotations

import asyncio
import base64
import email as email_lib
import html
import logging
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from html.parser import HTMLParser
from typing import List, Optional

from googleapiclient.errors import HttpError

from .base import NativeTool, ToolResult
from .google_auth import GoogleAuthManager, NOT_AUTHORIZED_MSG

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# HTML → plain text helper
# ---------------------------------------------------------------------------

class _HTMLStripper(HTMLParser):
    def __init__(self):
        super().__init__()
        self._parts: List[str] = []

    def handle_data(self, data: str) -> None:
        self._parts.append(data)

    def get_text(self) -> str:
        return " ".join(self._parts).strip()


def _strip_html(raw_html: str) -> str:
    stripper = _HTMLStripper()
    stripper.feed(html.unescape(raw_html))
    return stripper.get_text()


# ---------------------------------------------------------------------------
# Gmail body extractor
# ---------------------------------------------------------------------------

def _extract_body(payload: dict) -> str:
    mime_type = payload.get("mimeType", "")
    parts = payload.get("parts", [])

    if not parts:
        data = payload.get("body", {}).get("data", "")
        if data:
            decoded = base64.urlsafe_b64decode(data + "==").decode("utf-8", errors="replace")
            return decoded if "text/plain" in mime_type else _strip_html(decoded)
        return ""

    plain = ""
    html_body = ""
    for part in parts:
        pt = part.get("mimeType", "")
        data = part.get("body", {}).get("data", "")
        if not data:
            # Recurse into nested multipart
            nested = _extract_body(part)
            if nested:
                plain = plain or nested
            continue
        decoded = base64.urlsafe_b64decode(data + "==").decode("utf-8", errors="replace")
        if pt == "text/plain":
            plain = decoded
        elif pt == "text/html":
            html_body = decoded

    return plain or _strip_html(html_body)


def _build_service(auth: GoogleAuthManager):
    from googleapiclient.discovery import build
    return build("gmail", "v1", credentials=auth.get_credentials(), cache_discovery=False)


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

class GmailListTool(NativeTool):
    def __init__(self, auth_manager: GoogleAuthManager):
        self._auth = auth_manager

    @property
    def name(self) -> str:
        return "gmail_list"

    @property
    def description(self) -> str:
        return "List recent emails from Gmail. Returns sender, subject, date, and snippet."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "max_results": {"type": "integer", "default": 10, "description": "Max emails to return"},
                "unread_only": {"type": "boolean", "default": False, "description": "Only unread emails"},
            },
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return ToolResult(success=False, content="", error=NOT_AUTHORIZED_MSG, is_error=True)

        max_results = int(arguments.get("max_results", 10))
        unread_only = arguments.get("unread_only", False)

        def _fetch():
            svc = _build_service(self._auth)
            q = "is:unread" if unread_only else ""
            result = svc.users().messages().list(
                userId="me", maxResults=max_results, q=q
            ).execute()
            messages = result.get("messages", [])
            rows = []
            for m in messages:
                msg = svc.users().messages().get(
                    userId="me", id=m["id"], format="metadata",
                    metadataHeaders=["From", "Subject", "Date"]
                ).execute()
                headers = {h["name"]: h["value"] for h in msg.get("payload", {}).get("headers", [])}
                snippet = msg.get("snippet", "")
                rows.append(
                    f"ID: {m['id']}\n"
                    f"From: {headers.get('From', '?')}\n"
                    f"Subject: {headers.get('Subject', '(no subject)')}\n"
                    f"Date: {headers.get('Date', '?')}\n"
                    f"Snippet: {snippet}\n"
                )
            return rows

        try:
            rows = await asyncio.get_running_loop().run_in_executor(None, _fetch)
            if not rows:
                return ToolResult(success=True, content="No emails found.")
            return ToolResult(success=True, content=("\n" + "-" * 40 + "\n").join(rows))
        except HttpError as e:
            return ToolResult(success=False, content="", error=str(e), is_error=True)


class GmailReadTool(NativeTool):
    def __init__(self, auth_manager: GoogleAuthManager):
        self._auth = auth_manager

    @property
    def name(self) -> str:
        return "gmail_read"

    @property
    def description(self) -> str:
        return "Read the full body of a Gmail message by ID."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "message_id": {"type": "string", "description": "Gmail message ID"},
            },
            "required": ["message_id"],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return ToolResult(success=False, content="", error=NOT_AUTHORIZED_MSG, is_error=True)

        message_id = arguments.get("message_id", "").strip()

        def _fetch():
            svc = _build_service(self._auth)
            msg = svc.users().messages().get(userId="me", id=message_id, format="full").execute()
            payload = msg.get("payload", {})
            headers = {h["name"]: h["value"] for h in payload.get("headers", [])}
            body = _extract_body(payload)
            return (
                f"From: {headers.get('From', '?')}\n"
                f"To: {headers.get('To', '?')}\n"
                f"Subject: {headers.get('Subject', '(no subject)')}\n"
                f"Date: {headers.get('Date', '?')}\n\n"
                f"{body}"
            )

        try:
            content = await asyncio.get_running_loop().run_in_executor(None, _fetch)
            return ToolResult(success=True, content=content)
        except HttpError as e:
            return ToolResult(success=False, content="", error=str(e), is_error=True)


class GmailSendTool(NativeTool):
    def __init__(self, auth_manager: GoogleAuthManager):
        self._auth = auth_manager

    @property
    def name(self) -> str:
        return "gmail_send"

    @property
    def description(self) -> str:
        return "Send an email via Gmail."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "to": {"type": "string", "description": "Recipient email address"},
                "subject": {"type": "string", "description": "Email subject"},
                "body": {"type": "string", "description": "Email body (plain text)"},
                "cc": {"type": "string", "description": "CC email address (optional)"},
            },
            "required": ["to", "subject", "body"],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return ToolResult(success=False, content="", error=NOT_AUTHORIZED_MSG, is_error=True)

        to = arguments.get("to", "")
        subject = arguments.get("subject", "")
        body = arguments.get("body", "")
        cc = arguments.get("cc", "")

        def _send():
            msg = MIMEText(body)
            msg["to"] = to
            msg["subject"] = subject
            if cc:
                msg["cc"] = cc
            raw = base64.urlsafe_b64encode(msg.as_bytes()).decode()
            svc = _build_service(self._auth)
            sent = svc.users().messages().send(userId="me", body={"raw": raw}).execute()
            return sent.get("id", "unknown")

        try:
            msg_id = await asyncio.get_running_loop().run_in_executor(None, _send)
            return ToolResult(success=True, content=f"Email sent successfully. Message ID: {msg_id}")
        except HttpError as e:
            return ToolResult(success=False, content="", error=str(e), is_error=True)


class GmailSearchTool(NativeTool):
    def __init__(self, auth_manager: GoogleAuthManager):
        self._auth = auth_manager

    @property
    def name(self) -> str:
        return "gmail_search"

    @property
    def description(self) -> str:
        return "Search Gmail using Gmail search syntax (e.g. 'from:alice subject:meeting')."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Gmail search query"},
                "max_results": {"type": "integer", "default": 10},
            },
            "required": ["query"],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return ToolResult(success=False, content="", error=NOT_AUTHORIZED_MSG, is_error=True)

        query = arguments.get("query", "")
        max_results = int(arguments.get("max_results", 10))

        def _search():
            svc = _build_service(self._auth)
            result = svc.users().messages().list(
                userId="me", q=query, maxResults=max_results
            ).execute()
            messages = result.get("messages", [])
            rows = []
            for m in messages:
                msg = svc.users().messages().get(
                    userId="me", id=m["id"], format="metadata",
                    metadataHeaders=["From", "Subject", "Date"]
                ).execute()
                headers = {h["name"]: h["value"] for h in msg.get("payload", {}).get("headers", [])}
                rows.append(
                    f"ID: {m['id']}\n"
                    f"From: {headers.get('From', '?')}\n"
                    f"Subject: {headers.get('Subject', '(no subject)')}\n"
                    f"Date: {headers.get('Date', '?')}\n"
                    f"Snippet: {msg.get('snippet', '')}\n"
                )
            return rows

        try:
            rows = await asyncio.get_running_loop().run_in_executor(None, _search)
            if not rows:
                return ToolResult(success=True, content=f"No emails found for query: {query}")
            return ToolResult(success=True, content=("\n" + "-" * 40 + "\n").join(rows))
        except HttpError as e:
            return ToolResult(success=False, content="", error=str(e), is_error=True)


class GmailReplyTool(NativeTool):
    def __init__(self, auth_manager: GoogleAuthManager):
        self._auth = auth_manager

    @property
    def name(self) -> str:
        return "gmail_reply"

    @property
    def description(self) -> str:
        return "Reply to a Gmail message thread."

    @property
    def input_schema(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "message_id": {"type": "string", "description": "ID of the message to reply to"},
                "body": {"type": "string", "description": "Reply body (plain text)"},
            },
            "required": ["message_id", "body"],
        }

    async def execute(self, arguments: dict) -> ToolResult:
        if not self._auth.is_authorized():
            return ToolResult(success=False, content="", error=NOT_AUTHORIZED_MSG, is_error=True)

        message_id = arguments.get("message_id", "").strip()
        body = arguments.get("body", "")

        def _reply():
            svc = _build_service(self._auth)
            orig = svc.users().messages().get(
                userId="me", id=message_id, format="metadata",
                metadataHeaders=["From", "Subject", "Message-ID", "References"]
            ).execute()
            headers = {h["name"]: h["value"] for h in orig.get("payload", {}).get("headers", [])}
            thread_id = orig.get("threadId", "")

            reply = MIMEText(body)
            reply["to"] = headers.get("From", "")
            reply["subject"] = "Re: " + headers.get("Subject", "")
            reply["In-Reply-To"] = headers.get("Message-ID", "")
            reply["References"] = headers.get("References", "") + " " + headers.get("Message-ID", "")

            raw = base64.urlsafe_b64encode(reply.as_bytes()).decode()
            sent = svc.users().messages().send(
                userId="me", body={"raw": raw, "threadId": thread_id}
            ).execute()
            return sent.get("id", "unknown")

        try:
            msg_id = await asyncio.get_running_loop().run_in_executor(None, _reply)
            return ToolResult(success=True, content=f"Reply sent. Message ID: {msg_id}")
        except HttpError as e:
            return ToolResult(success=False, content="", error=str(e), is_error=True)
