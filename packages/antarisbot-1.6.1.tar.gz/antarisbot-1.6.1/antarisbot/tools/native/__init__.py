from __future__ import annotations

from antarisbot.tools import NativeTool, ToolResult
from .browser import BrowserTool
from .file_ops import FileOpsTool
from .shell import ShellTool
from .web_fetch import WebFetchTool
from .web_search import WebSearchTool

# Google Workspace
from .google_auth import GoogleAuthManager
from .gmail import (
    GmailListTool,
    GmailReadTool,
    GmailSendTool,
    GmailSearchTool,
    GmailReplyTool,
)
from .gcalendar import (
    CalendarListEventsTool,
    CalendarCreateEventTool,
    CalendarUpdateEventTool,
    CalendarDeleteEventTool,
    CalendarFreeBusyTool,
)
from .gdrive import (
    DriveSearchTool,
    DriveReadTool,
    DriveUploadTool,
    DriveRecentTool,
)
from .gsheets import (
    SheetsReadTool,
    SheetsWriteTool,
    SheetsAppendTool,
)
from .gdocs import (
    DocsReadTool,
    DocsAppendTool,
    DocsCreateTool,
)
from .spawn_subagent import SpawnSubagentTool

# Slack
from .slack import (
    SlackAuthManager,
    SlackListChannelsTool,
    SlackReadChannelTool,
    SlackSendMessageTool,
    SlackSearchTool,
    SlackGetUserInfoTool,
    SlackListDMsTool,
)

__all__ = [
    # Base
    "NativeTool",
    "ToolResult",
    # Core tools
    "WebSearchTool",
    "WebFetchTool",
    "FileOpsTool",
    "ShellTool",
    "BrowserTool",
    # Google auth
    "GoogleAuthManager",
    # Gmail
    "GmailListTool",
    "GmailReadTool",
    "GmailSendTool",
    "GmailSearchTool",
    "GmailReplyTool",
    # Calendar
    "CalendarListEventsTool",
    "CalendarCreateEventTool",
    "CalendarUpdateEventTool",
    "CalendarDeleteEventTool",
    "CalendarFreeBusyTool",
    # Drive
    "DriveSearchTool",
    "DriveReadTool",
    "DriveUploadTool",
    "DriveRecentTool",
    # Sheets
    "SheetsReadTool",
    "SheetsWriteTool",
    "SheetsAppendTool",
    # Docs
    "DocsReadTool",
    "DocsAppendTool",
    "DocsCreateTool",
    # Subagent spawning
    "SpawnSubagentTool",
    # Slack
    "SlackAuthManager",
    "SlackListChannelsTool",
    "SlackReadChannelTool",
    "SlackSendMessageTool",
    "SlackSearchTool",
    "SlackGetUserInfoTool",
    "SlackListDMsTool",
]
