"""
AntarisBot — Main Bot class.

Wires all components together:
  Config → Memory → Guard → Persona → LLM → Pipeline → Channels
"""

import asyncio
import logging
import os
import signal
import sys
from pathlib import Path
from typing import Optional

from antarisbot.core.config import Config, DEFAULT_CONFIG_PATH
from antarisbot.core.logger import setup_logging
from antarisbot.core.memory import BotMemory
from antarisbot.core.guard import BotGuard
from antarisbot.core.updater import Updater
from antarisbot.core.pipeline import Pipeline
from antarisbot.persona.loader import PersonaLoader
from antarisbot.persona.awakening import Awakening
from antarisbot.llm.anthropic import AnthropicProvider
from antarisbot.channels.base import InboundMessage, OutboundMessage, ChannelAdapter
from antarisbot.channels.terminal import TerminalAdapter
from antarisbot.channels.discord import DiscordAdapter
from antarisbot.channels.telegram import TelegramAdapter
from antarisbot.channels.slack import SlackAdapter

logger = logging.getLogger(__name__)


class Bot:
    """
    Main AntarisBot class. Loads config, initializes all components, runs channels.

    Usage:
        Bot().start()                      # all configured channels
        Bot().start(terminal_only=True)    # terminal only
        Bot().chat()                       # alias for terminal mode
    """

    def __init__(self, config_path: Optional[str] = None):
        self.config = Config.load_with_fallback(config_path)
        if not self.config:
            logger.error("Bot not initialized. Run 'antarisbot init' first.")
            sys.exit(1)

        # ── Structured logging — set up before anything else ─────────────
        config_dir = str(Path(self.config.config_path).parent)
        setup_logging(config_dir)
        logger.info("Bot.__init__: config loaded from %s", self.config.config_path)

        errors = self.config.validate()
        if errors:
            logger.error("Configuration errors:")
            print("❌ Configuration errors:")
            for e in errors:
                logger.error("  - %s", e)
            sys.exit(1)

        # ── Components ────────────────────────────────────────────────────
        self._update_notification: Optional[str] = None
        self._first_message_sent: bool = False
        self._message_count: int = 0
        self._compaction_notified: bool = False
        self._pre_compaction_flushed: bool = False
        # Rolling window of recent turns: (user_id, user_msg, bot_response)
        self._conversation_buffer: list[tuple[str, str, str]] = []

        if getattr(self.config, "auto_update", False):
            logger.info("Auto-update enabled — checking for updates...")
        elif getattr(self.config, "notify_updates", True):
            notify_msg = Updater().check_and_notify()
            if notify_msg:
                logger.info("Update available: %s", notify_msg)

        # ── Initialize components ─────────────────────────────────────────
        # Guard: skip if config not yet loaded (setup wizard will run in start())
        self.memory = None
        self.guard = None
        self.persona = None
        self.awakening = None
        self.llm = None
        self.pipeline = None
        self.tool_middleware = None
        self.tool_registry = None
        self._channels: list[ChannelAdapter] = []

        if not self.config:
            return  # start() will run setup wizard and call _init_components()

        self._init_components()

    def _init_components(self) -> None:
        """Initialise bot components from self.config. Called after config is confirmed loaded."""
        # ── Security setup (must run first — audit hook is irremovable once set) ──
        security_mode = getattr(self.config, "security_mode", "sandboxed")

        # 1. Register audit hook
        from antarisbot.core.guard import register_audit_hook
        # Use the config directory as workspace root (not just memory subdir)
        # so the audit hook allows access to config.json, SOUL.md, etc.
        _config_dir = str(Path(self.config.config_path).parent)
        register_audit_hook(
            security_mode=security_mode,
            workspace_path=_config_dir,
        )

        # 2. Load encryption key for locked mode
        self._encryption_key: Optional[bytes] = None
        if security_mode in ("locked", "encrypted"):
            try:
                from antarisbot.security.encrypted_store import load_or_create_key
                self._encryption_key = load_or_create_key()
            except Exception as e:
                logger.warning("Could not load encryption key: %s — locked mode memory unencrypted", e)

        self.memory = BotMemory(
            store_path=self.config.memory_store,
            search_limit=self.config.memory_search_limit,
            min_relevance=self.config.memory_min_relevance,
            security_mode=security_mode,
            encryption_key=self._encryption_key,
            agent_name=self.config.bot_name or "AntarisBot",
        )
        from antarisbot.core.daily_log import DailyLog
        self.daily_log = DailyLog(self.config.memory_store)
        self.guard = BotGuard(mode=self.config.guard_mode)

        # ── Tool middleware ────────────────────────────────────────────────
        from antarisbot.security.tool_middleware import ToolMiddleware
        _audit_log_path = str(Path.home() / ".antarisbot" / "audit.log")
        self.tool_middleware = ToolMiddleware(
            mode_or_level=security_mode,
            audit_log_path=_audit_log_path,
        )

        self.persona = PersonaLoader()
        self.awakening = Awakening(self.persona)

        if self.config.provider_name == "ollama":
            from antarisbot.llm.ollama import OllamaProvider
            base_url = getattr(self.config, "ollama_base_url", "http://localhost:11434/v1")
            self.llm = OllamaProvider(model=self.config.model, base_url=base_url)
        elif self.config.provider_name == "openai":
            from antarisbot.llm.openai import OpenAIProvider
            self.llm = OpenAIProvider(api_key=self.config.api_key, model=self.config.model)
        elif self.config.provider_name == "google":
            from antarisbot.llm.google import GoogleProvider
            self.llm = GoogleProvider(api_key=self.config.api_key, model=self.config.model)
        else:
            self.llm = AnthropicProvider(api_key=self.config.api_key, model=self.config.model)

        # ── Multi-provider dispatcher for routing ─────────────────────────
        from antarisbot.llm.dispatcher import LLMDispatcher
        self.dispatcher = LLMDispatcher()

        # Register the primary provider
        self.dispatcher.register(self.config.provider_name, self.llm)

        # Register additional providers if API keys are available in config
        _extra_providers = {
            "anthropic": ("antarisbot.llm.anthropic", "AnthropicProvider"),
            "openai": ("antarisbot.llm.openai", "OpenAIProvider"),
            "google": ("antarisbot.llm.google", "GoogleProvider"),
            "ollama": ("antarisbot.llm.ollama", "OllamaProvider"),
        }
        for _pname, (_mod, _cls) in _extra_providers.items():
            if _pname == self.config.provider_name:
                continue  # already registered as primary
            try:
                import importlib
                _m = importlib.import_module(_mod)
                _provider_cls = getattr(_m, _cls)
                if _pname == "ollama":
                    # Ollama uses baseUrl, not api_key
                    _base_url = getattr(self.config, "ollama_base_url", "http://localhost:11434/v1")
                    _extra_llm = _provider_cls(base_url=_base_url)
                    self.dispatcher.register(_pname, _extra_llm)
                    logger.info("Registered extra provider: ollama (%s)", _base_url)
                else:
                    _key = getattr(self.config, f"{_pname}_api_key", None)
                    if _key:
                        _extra_llm = _provider_cls(api_key=_key, model=self.config.model)
                        self.dispatcher.register(_pname, _extra_llm)
                        logger.info("Registered extra provider: %s", _pname)
            except Exception as _e:
                logger.warning("Could not register extra provider %s: %s", _pname, _e)

        # ── Router (antaris-router) ────────────────────────────────────────
        self.router = None
        _router_config = getattr(self.config, "router_config_path", None)
        if _router_config:
            try:
                from antarisbot.suite.router import Router
                self.router = Router(config_path=_router_config)
                logger.info("Router initialized from config: %s", _router_config)
            except Exception as _e:
                logger.warning("Could not initialize router: %s", _e)

        # ── User profiles ─────────────────────────────────────────────────
        from antarisbot.core.profiles import ProfileManager
        _profiles_path = Path(self.config.config_path).parent / "profiles"
        self.profiles = ProfileManager(profiles_dir=_profiles_path)

        # ── Teaching store ────────────────────────────────────────────────
        from antarisbot.core.teachings import TeachingStore
        _teachings_path = Path(self.config.config_path).parent / "teachings"
        self.teachings = TeachingStore(store_dir=_teachings_path)

        # ── Focus manager ─────────────────────────────────────────────────
        from antarisbot.core.focus import FocusManager
        self.focus = FocusManager()

        # ── Thread manager ────────────────────────────────────────────────
        from antarisbot.core.threads import ThreadManager
        _threads_path = Path(self.config.config_path).parent / "threads"
        self.threads = ThreadManager(_threads_path)

        # ── Shortcut learner ──────────────────────────────────────────────
        from antarisbot.core.shortcuts import ShortcutLearner
        _shortcuts_path = Path(self.config.config_path).parent / "shortcuts"
        self.shortcuts = ShortcutLearner(_shortcuts_path)

        # ── Conversation exporter ─────────────────────────────────────────
        from antarisbot.core.exporter import ConversationExporter
        _exports_path = Path(self.config.config_path).parent / "exports"
        self.exporter = ConversationExporter(self.memory, _exports_path)

        # ── Proactive memory ──────────────────────────────────────────────
        from antarisbot.core.proactive import ProactiveMemory
        _proactive_path = Path(self.config.config_path).parent / "proactive"
        self.proactive = ProactiveMemory(_proactive_path)

        # ── Mood detector ─────────────────────────────────────────────────
        from antarisbot.core.mood import MoodDetector
        self.mood = MoodDetector(window_size=10)

        # ── Feedback tracker ──────────────────────────────────────────────
        from antarisbot.core.feedback import FeedbackTracker
        _feedback_path = Path(self.config.config_path).parent / "feedback"
        self.feedback = FeedbackTracker(store_dir=str(_feedback_path))

        # ── Tool registry ─────────────────────────────────────────────────
        self.tool_registry = self._init_tools()

        self.pipeline = Pipeline(
            config=self.config,
            memory=self.memory,
            guard=self.guard,
            persona=self.persona,
            llm=self.llm,
            awakening=self.awakening,
            tool_middleware=self.tool_middleware,
            router=self.router,
            dispatcher=self.dispatcher,
            profiles=self.profiles,
            teachings=self.teachings,
            focus=self.focus,
            threads=self.threads,
            shortcuts=self.shortcuts,
            proactive=self.proactive,
            mood=self.mood,
            feedback=self.feedback,
            tool_registry=self.tool_registry,
        )

        # ── Cron scheduler ────────────────────────────────────────────────
        from antarisbot.core.cron import CronScheduler
        _jobs_path = Path(self.config.config_path).parent / "cron" / "jobs.json"
        self.cron = CronScheduler(jobs_path=_jobs_path, on_fire=self._on_cron_fire)

        # ── Command dispatcher ────────────────────────────────────────────
        from antarisbot.core.commands import CommandDispatcher
        self.commands = CommandDispatcher(self)
        self.pipeline.commands = self.commands

        # ── Heartbeat manager ─────────────────────────────────────────────
        from antarisbot.core.heartbeat import HeartbeatManager
        self.heartbeat = HeartbeatManager(self)

        # ── Subagent registry ─────────────────────────────────────────────
        from antarisbot.core.subagents import SubagentRegistry
        self.subagents = SubagentRegistry(
            bot=self,
            max_agents=getattr(self.config, "max_subagents", 4),
        )
        self._active_discord_channel = None  # set when Discord message arrives

        # ── Register SpawnSubagentTool now that subagents registry exists ──
        # Must happen after both tool_registry and subagents are initialized,
        # because SpawnSubagentTool needs a reference to the SubagentRegistry.
        if self.tool_registry is not None:
            try:
                from antarisbot.tools.native.spawn_subagent import SpawnSubagentTool
                from antarisbot.tools import ToolDef
                spawn_tool = SpawnSubagentTool(registry=self.subagents, origin_channel=None)
                # Direct dict mutation (bypasses asyncio.Lock in register_native) — safe here
                # because _init_components runs during sequential bot startup, before any
                # message handlers or tool-accessing coroutines are active. The public
                # register_native() is async and would require asyncio.run(), which would
                # conflict with the existing event loop.
                self.tool_registry._native_tools['spawn_subagent'] = spawn_tool
                self.tool_registry._tool_definitions['spawn_subagent'] = ToolDef(
                    name='spawn_subagent',
                    description=spawn_tool.description,
                    input_schema=spawn_tool.input_schema,
                    source='native'
                )
                logger.info("Registered SpawnSubagentTool")
            except Exception as e:
                logger.warning("Failed to register SpawnSubagentTool: %s", e)

        self._accepting_messages = True

    def _init_tools(self) -> Optional['ToolRegistry']:
        """Initialize tool registry with configured tools (sync)."""
        from antarisbot.tools import ToolRegistry, ToolDef
        
        registry = ToolRegistry()
        
        # Load tools config from config.json
        tools_config = getattr(self.config, '_tools_config', {})
        
        # Register native tools synchronously (bypass async register_native)
        # This is safe because we're the only thread during init
        
        # 1. Register WebSearchTool if brave_search configured
        brave_config = tools_config.get('brave_search', {})
        if brave_config.get('enabled') and brave_config.get('apiKey'):
            try:
                from antarisbot.tools.native.web_search import WebSearchTool
                tool = WebSearchTool(api_key=brave_config['apiKey'])
                registry._native_tools['web_search'] = tool
                registry._tool_definitions['web_search'] = ToolDef(
                    name='web_search',
                    description=tool.description,
                    input_schema=tool.input_schema,
                    source='native'
                )
                logger.info("Registered WebSearchTool")
            except Exception as e:
                logger.warning("Failed to register WebSearchTool: %s", e)
        
        # 2. Register WebFetchTool (must be explicitly enabled)
        web_fetch_config = tools_config.get('web_fetch', {})
        if web_fetch_config.get('enabled', False):
            try:
                from antarisbot.tools.native.web_fetch import WebFetchTool
                tool = WebFetchTool()
                registry._native_tools['web_fetch'] = tool
                registry._tool_definitions['web_fetch'] = ToolDef(
                    name='web_fetch',
                    description=tool.description,
                    input_schema=tool.input_schema,
                    source='native'
                )
                logger.info("Registered WebFetchTool")
            except Exception as e:
                logger.warning("Failed to register WebFetchTool: %s", e)
        
        # 3. Register BrowserTool if configured
        browser_config = tools_config.get('browser', {})
        if browser_config.get('enabled'):
            try:
                from antarisbot.tools.native.browser import BrowserTool
                config_dir = str(Path(self.config.config_path).parent)
                tool = BrowserTool(workspace_path=config_dir)
                registry._native_tools['browser'] = tool
                registry._tool_definitions['browser'] = ToolDef(
                    name='browser',
                    description=tool.description,
                    input_schema=tool.input_schema,
                    source='native'
                )
                logger.info("Registered BrowserTool")
            except Exception as e:
                logger.warning("Failed to register BrowserTool: %s", e)
        
        # 4. Register FileOpsTool if configured
        file_ops_config = tools_config.get('file_ops', {})
        if file_ops_config.get('enabled'):
            try:
                from antarisbot.tools.native.file_ops import FileOpsTool
                config_dir = str(Path(self.config.config_path).parent)
                tool = FileOpsTool(workspace_path=config_dir)
                registry._native_tools['file_ops'] = tool
                registry._tool_definitions['file_ops'] = ToolDef(
                    name='file_ops',
                    description=tool.description,
                    input_schema=tool.input_schema,
                    source='native'
                )
                logger.info("Registered FileOpsTool")
            except Exception as e:
                logger.warning("Failed to register FileOpsTool: %s", e)
        
        # 5. Register ShellTool if configured
        shell_config = tools_config.get('shell', {})
        if shell_config.get('enabled'):
            try:
                from antarisbot.tools.native.shell import ShellTool
                config_dir = str(Path(self.config.config_path).parent)
                tool = ShellTool(workspace_path=config_dir)
                registry._native_tools['shell'] = tool
                registry._tool_definitions['shell'] = ToolDef(
                    name='shell',
                    description=tool.description,
                    input_schema=tool.input_schema,
                    source='native'
                )
                logger.info("Registered ShellTool")
            except Exception as e:
                logger.warning("Failed to register ShellTool: %s", e)
        
        # 6. Register ImageTool if configured
        image_config = tools_config.get('image', {})
        if image_config.get('enabled'):
            try:
                from antarisbot.tools.native.image import ImageTool
                tool = ImageTool(dispatcher=self.dispatcher)
                registry._native_tools['image'] = tool
                registry._tool_definitions['image'] = ToolDef(
                    name='image',
                    description=tool.description,
                    input_schema=tool.input_schema,
                    source='native'
                )
                logger.info("Registered ImageTool")
            except Exception as e:
                logger.warning("Failed to register ImageTool: %s", e)
        
        # 7. Register TTSTool if configured
        tts_config = tools_config.get('tts', {})
        if tts_config.get('enabled'):
            try:
                from antarisbot.tools.native.tts import TTSTool
                default_voice = tts_config.get('voice', 'Samantha')
                tool = TTSTool(default_voice=default_voice)
                registry._native_tools['tts'] = tool
                registry._tool_definitions['tts'] = ToolDef(
                    name='tts',
                    description=tool.description,
                    input_schema=tool.input_schema,
                    source='native'
                )
                logger.info("Registered TTSTool")
            except Exception as e:
                logger.warning("Failed to register TTSTool: %s", e)
        
        # 8. Register DiscordProactiveTool if configured
        discord_proactive_config = tools_config.get('discord_proactive', {})
        if discord_proactive_config.get('enabled'):
            try:
                from antarisbot.tools.native.discord_proactive import DiscordProactiveTool
                tool = DiscordProactiveTool(discord_client=None)  # Will be set later
                registry._native_tools['discord_proactive'] = tool
                registry._tool_definitions['discord_proactive'] = ToolDef(
                    name='discord_proactive',
                    description=tool.description,
                    input_schema=tool.input_schema,
                    source='native'
                )
                logger.info("Registered DiscordProactiveTool")
            except Exception as e:
                logger.warning("Failed to register DiscordProactiveTool: %s", e)
        
        # 9. Register SessionStatusTool if configured
        session_status_config = tools_config.get('session_status', {})
        if session_status_config.get('enabled'):
            try:
                from antarisbot.tools.native.session_status import SessionStatusTool
                tool = SessionStatusTool(bot=self)
                registry._native_tools['session_status'] = tool
                registry._tool_definitions['session_status'] = ToolDef(
                    name='session_status',
                    description=tool.description,
                    input_schema=tool.input_schema,
                    source='native'
                )
                logger.info("Registered SessionStatusTool")
            except Exception as e:
                logger.warning("Failed to register SessionStatusTool: %s", e)
        
        # 10. Register CanvasTool if configured
        canvas_config = tools_config.get('canvas', {})
        if canvas_config.get('enabled'):
            try:
                from antarisbot.tools.native.canvas import CanvasTool
                default_port = canvas_config.get('port', 7777)
                tool = CanvasTool(default_port=default_port)
                registry._native_tools['canvas'] = tool
                registry._tool_definitions['canvas'] = ToolDef(
                    name='canvas',
                    description=tool.description,
                    input_schema=tool.input_schema,
                    source='native'
                )
                logger.info("Registered CanvasTool")
            except Exception as e:
                logger.warning("Failed to register CanvasTool: %s", e)
        
        # 11. Register NodesTool if configured
        nodes_config = tools_config.get('nodes', {})
        if nodes_config.get('enabled'):
            try:
                from antarisbot.tools.native.nodes import NodesTool
                tool = NodesTool()
                registry._native_tools['nodes'] = tool
                registry._tool_definitions['nodes'] = ToolDef(
                    name='nodes',
                    description=tool.description,
                    input_schema=tool.input_schema,
                    source='native'
                )
                logger.info("Registered NodesTool")
            except Exception as e:
                logger.warning("Failed to register NodesTool: %s", e)
        
        # 12. Register PeekabooTool if configured
        peekaboo_config = tools_config.get('peekaboo', {})
        if peekaboo_config.get('enabled'):
            try:
                from antarisbot.tools.native.peekaboo import PeekabooTool
                config_dir = str(Path(self.config.config_path).parent)
                tool = PeekabooTool(workspace_path=config_dir)
                registry._native_tools['peekaboo'] = tool
                registry._tool_definitions['peekaboo'] = ToolDef(
                    name='peekaboo',
                    description=tool.description,
                    input_schema=tool.input_schema,
                    source='native'
                )
                logger.info("Registered PeekabooTool")
            except Exception as e:
                logger.warning("Failed to register PeekabooTool: %s", e)
        
        # 13. Register PuppeteerTool if configured
        puppeteer_config = tools_config.get('puppeteer', {})
        if puppeteer_config.get('enabled'):
            try:
                from antarisbot.tools.native.puppeteer import PuppeteerTool
                config_dir = str(Path(self.config.config_path).parent)
                tool = PuppeteerTool(workspace_path=config_dir)
                registry._native_tools['puppeteer'] = tool
                registry._tool_definitions['puppeteer'] = ToolDef(
                    name='puppeteer',
                    description=tool.description,
                    input_schema=tool.input_schema,
                    source='native'
                )
                logger.info("Registered PuppeteerTool")
            except Exception as e:
                logger.warning("Failed to register PuppeteerTool: %s", e)

        # 14. Load JS bridges if js_bridges.json exists (informational for now)
        config_dir = Path(self.config.config_path).parent
        js_bridges_path = config_dir / 'tools' / 'js_bridges.json'
        if js_bridges_path.exists():
            try:
                import json
                bridges = json.loads(js_bridges_path.read_text())
                for bridge in bridges.get('bridges', []):
                    # JS bridges are informational for now
                    logger.info("JS bridge detected: %s at %s", bridge['name'], bridge['script_path'])
            except Exception as e:
                logger.warning("Failed to load JS bridges: %s", e)
        
        # Mark as initialized
        registry._initialized = True
        
        # Return registry if it has native tools OR if MCP servers are configured
        # (MCP servers get connected later in _init_mcp_servers, but need the registry to exist)
        has_native_tools = bool(registry.list_tools())
        has_mcp_config = bool(tools_config.get('mcp_servers', []))
        
        if has_native_tools or has_mcp_config:
            if has_native_tools:
                logger.info("Tool registry initialized with %d tools: %s", 
                           len(registry.list_tools()), ', '.join(registry.list_tools()))
            if has_mcp_config:
                logger.info("MCP servers configured: %d (will connect after startup)", 
                           len(tools_config['mcp_servers']))
            return registry
        else:
            logger.debug("No tools configured, returning None")
            return None

    async def _init_mcp_servers(self) -> None:
        """Initialize MCP servers after bot startup (requires async context)."""
        if not self.tool_registry:
            return
            
        tools_config = getattr(self.config, '_tools_config', {})
        mcp_config = tools_config.get('mcp_servers', [])
        
        for server in mcp_config:
            try:
                await self.tool_registry.add_mcp_server(
                    name=server['name'],
                    transport=server.get('transport', 'stdio'),
                    command=server.get('command'),
                    env=server.get('env'),
                    url=server.get('url')
                )
                logger.info("Connected to MCP server: %s", server['name'])
            except Exception as e:
                logger.warning("Failed to connect MCP server %s: %s", server['name'], e)

    async def _on_cron_fire(self, job) -> None:
        """Handle a fired cron job."""
        from antarisbot.channels.base import InboundMessage
        logger.info("Cron job fired: %s (%s)", job.id, job.name)
        if job.payload_kind == "agentTurn":
            # Fire as a synthetic message through the pipeline
            inbound = InboundMessage(
                id=f"cron_{job.id}",
                user_id="system_cron",
                user_name="system_cron",
                channel_id=job.channel_id or "",
                platform="internal",
                text=job.payload_text,
            )
            # Find the right adapter for this channel
            adapter = None
            for ch in self._channels:
                if hasattr(ch, 'channel_id') and ch.channel_id == job.channel_id:
                    adapter = ch
                    break
            if not adapter and self._channels:
                adapter = self._channels[0]
            if adapter:
                result = await self.pipeline.process(inbound, adapter)
                if result.response_text:
                    from antarisbot.channels.base import OutboundMessage
                    await adapter.send(OutboundMessage(
                        channel_id=job.channel_id or "",
                        text=result.response_text,
                    ))
        elif job.payload_kind == "systemEvent":
            logger.info("Cron systemEvent: %s", job.payload_text[:100])
            # Handle heartbeat tick
            if job.payload_text == "heartbeat_tick" and hasattr(self, "heartbeat"):
                try:
                    await self.heartbeat.tick()
                except Exception as e:
                    logger.error("Heartbeat tick failed: %s", e)

    def start(self, terminal_only: bool = False):
        """Launch the bot. Blocks until stopped."""
        # Run setup wizard if the bot has not been configured yet
        from antarisbot.setup.wizard import SetupWizard
        if SetupWizard().is_needed():
            cfg = SetupWizard().run()
            if cfg:
                self.config = cfg
                self._init_components()
            else:
                logger.error("Setup was cancelled. Run 'antaris setup' to configure.")
                return

        if not self.config:
            logger.error("Bot not initialized. Run 'antaris setup' or 'antaris init' first.")
            sys.exit(1)

        signal.signal(signal.SIGINT, self._handle_shutdown)
        signal.signal(signal.SIGTERM, self._handle_shutdown)

        try:
            asyncio.run(self._run(terminal_only=terminal_only))
        except KeyboardInterrupt:
            logger.info("KeyboardInterrupt received, shutting down.")
            print("\n👋 Stopped.")

    def chat(self):
        """Alias for terminal-only mode."""
        self.start(terminal_only=True)

    # ── Graceful shutdown ─────────────────────────────────────────────────

    def _handle_shutdown(self, sig, frame):
        """Flush memory, set shutdown flag, exit cleanly."""
        logger.info("Shutdown signal received (sig=%s), flushing memory...", sig)
        self._accepting_messages = False

        # Flush memory store
        try:
            if self.memory:
                for user_id, store in self.memory._stores.items():
                    try:
                        store.save()
                    except Exception:
                        pass
                logger.info("Memory stores flushed.")
        except Exception as e:
            logger.warning("Memory save failed during shutdown: %s", e)

        # Remove PID file
        pid_file = Path.home() / ".antarisbot" / "bot.pid"
        try:
            pid_file.unlink(missing_ok=True)
        except Exception:
            pass

        # Write daily log shutdown marker
        if hasattr(self, 'daily_log'):
            try:
                self.daily_log.write_shutdown_marker()
            except Exception as _e:
                logger.warning("DailyLog shutdown marker failed: %s", _e)

        # Stop cron scheduler
        if hasattr(self, 'cron') and self.cron:
            try:
                import asyncio as _asyncio
                _asyncio.get_event_loop().run_until_complete(self.cron.stop())
            except Exception as _e:
                logger.warning("Cron stop failed: %s", _e)

        # Stop heartbeat system
        if hasattr(self, 'heartbeat') and self.heartbeat:
            try:
                self.heartbeat.stop()
            except Exception as _e:
                logger.warning("Heartbeat stop failed: %s", _e)

        # Shutdown tool registry
        if hasattr(self, 'tool_registry') and self.tool_registry:
            try:
                import asyncio as _asyncio
                _asyncio.get_event_loop().run_until_complete(self.tool_registry.shutdown())
            except Exception as _e:
                logger.warning("Tool registry shutdown failed: %s", _e)

        logger.info("Bot shut down cleanly.")
        sys.exit(0)

    # ── Internal ──────────────────────────────────────────────────────────

    def _setup_channels(self, terminal_only: bool):
        self._channels = []

        if terminal_only:
            self._channels.append(TerminalAdapter(bot_name=self.config.bot_name))
            return

        if self.config.discord_enabled and self.config.discord_token:
            self._channels.append(
                DiscordAdapter(
                    token=self.config.discord_token,
                    bot_name=self.config.bot_name,
                    open_channels=self.config.discord_open_channels or [],
                    bot_memory=self.memory,
                    bot_llm=self.llm,
                    feedback_tracker=getattr(self, "feedback", None),
                    bridge_enabled=getattr(self.config, "discord_bridge_enabled", False),
                    bridge_channels=getattr(self.config, "discord_bridge_channels", []),
                )
            )

        if self.config.telegram_enabled and self.config.telegram_token:
            self._channels.append(
                TelegramAdapter(
                    token=self.config.telegram_token,
                    bot_name=self.config.bot_name,
                    open_chats=getattr(self.config, "telegram_open_chats", None) or [],
                )
            )

        if (
            getattr(self.config, "slack_enabled", False)
            and getattr(self.config, "slack_bot_token", "")
            and getattr(self.config, "slack_app_token", "")
        ):
            self._channels.append(
                SlackAdapter(
                    bot_token=self.config.slack_bot_token,
                    app_token=self.config.slack_app_token,
                    open_channels=getattr(self.config, "slack_open_channels", None) or [],
                )
            )

        if not self._channels:
            logger.warning("No channels configured — falling back to terminal mode.")
            logger.info("Tip: Run 'antarisbot init' to add Discord or Telegram.")
            print("   ⚠️  No channels configured. Starting in terminal mode.")
            print("   Tip: Run 'antarisbot init' to add Discord or Telegram.")
            self._channels.append(TerminalAdapter(bot_name=self.config.bot_name))
    async def _run(self, terminal_only: bool = False):
        self._setup_channels(terminal_only=terminal_only)
        
        # Initialize MCP servers (requires async context)
        await self._init_mcp_servers()
        
        if hasattr(self, 'cron') and self.cron:
            await self.cron.start()
        # Start heartbeat system
        if hasattr(self, 'heartbeat') and self.heartbeat:
            self.heartbeat.start()
        self._print_banner()
        for adapter in self._channels:
            adapter.on_message(self._make_handler(adapter))
        results = await asyncio.gather(
            *[adapter.connect() for adapter in self._channels],
            return_exceptions=True,
        )
        for adapter, result in zip(self._channels, results):
            if isinstance(result, Exception):
                name = type(adapter).__name__
                logger.error("Channel %s failed to connect: %s", name, result)
                print(f"   ❌ {name} failed: {result}")
        
        # Setup Discord client for Discord proactive tool
        await self._setup_discord_proactive_tool()

    def _make_handler(self, adapter: ChannelAdapter):
        async def handle(inbound: InboundMessage):
            if not self._accepting_messages:
                logger.debug("Ignoring message during shutdown from user=%s", inbound.user_id)
                return
            if not self._first_message_sent and self._update_notification:
                self._first_message_sent = True
                try:
                    await adapter.send(
                        OutboundMessage(
                            channel_id=inbound.channel_id,
                            text=self._update_notification,
                            reply_to=None,
                        )
                    )
                except Exception as exc:
                    logger.warning("Could not send update notification: %s", exc)
            elif not self._first_message_sent:
                self._first_message_sent = True

            result = await self.pipeline.process(inbound, adapter)

            # Track message count for compaction detection
            self._message_count += 1
            _threshold = getattr(self.config, 'compaction_threshold', 80)
            _pre_ratio = getattr(self.config, 'pre_compaction_ratio', 0.75)
            _pre_threshold = int(_threshold * _pre_ratio)

            # Pre-compaction flush: save a session summary at pre_compaction_ratio of threshold
            if (self._message_count >= _pre_threshold
                    and not self._pre_compaction_flushed):
                self._pre_compaction_flushed = True
                asyncio.create_task(self._pre_compaction_flush())

            # Full compaction ping: send DM to owner at the threshold
            if (self._message_count >= _threshold
                    and not self._compaction_notified
                    and getattr(self.config, 'owner_user_id', '')):
                self._compaction_notified = True
                asyncio.create_task(self._send_compaction_ping(adapter))

            if result.success and result.response_text:
                # Accumulate in conversation buffer (rolling window of 30 turns)
                self._conversation_buffer.append(
                    (inbound.user_id, inbound.text, result.response_text)
                )
                if len(self._conversation_buffer) > 30:
                    self._conversation_buffer = self._conversation_buffer[-30:]

                if hasattr(self, 'daily_log'):
                    try:
                        self.daily_log.record(inbound.user_id, inbound.text, result.response_text)
                    except Exception as _dl_err:
                        logger.warning("DailyLog record failed: %s", _dl_err)

            if result.response_text:
                await adapter.send(
                    OutboundMessage(
                        channel_id=inbound.channel_id,
                        text=result.response_text,
                        reply_to=inbound.id,
                    )
                )
            if result.error:
                logger.error("Pipeline error for user=%s: %s", inbound.user_id, result.error)
            if result.failed_stages:
                logger.debug("Failed stages for user=%s: %s", inbound.user_id, result.failed_stages)
        return handle

    def _print_banner(self):
        """Log startup info."""
        memory_count = self._memory_count()
        channel_names = [type(c).__name__.replace("Adapter", "") for c in self._channels]

        logger.info(
            "Starting %s | memory=%d | guard=%s | model=%s via %s | channels=%s",
            self.config.bot_name, memory_count, self.config.guard_mode,
            self.config.model, self.config.provider_name, ", ".join(channel_names),
        )

        security_mode = getattr(self.config, "security_mode", "sandboxed")
        print(f"\n🤖 {self.config.bot_name} starting...")
        print(f"   Memory: {memory_count} entries")
        print(f"   Security: {security_mode} mode")
        print(f"   Guard: {self.config.guard_mode} mode")
        print(f"   Model: {self.config.model} via {self.config.provider_name}")
        print(f"   Channels: {', '.join(channel_names)}")
        if self.awakening.is_needed():
            logger.info("Identity: Awakening needed")
        else:
            logger.info("Identity: SOUL.md loaded")

    def _memory_count(self) -> int:
        try:
            return self.memory.stats().get("total", 0)
        except Exception:
            return 0

    def _build_conversation_summary(self) -> str:
        """Build a structured summary from the conversation buffer.

        Returns a markdown-formatted string with topics discussed, decisions
        made, and key facts learned from the recent conversation turns.
        """
        if not self._conversation_buffer:
            return "(no conversation data available)"

        lines: list[str] = []
        lines.append("### Recent conversation summary\n")
        for _uid, user_msg, bot_resp in self._conversation_buffer:
            user_preview = user_msg[:150].replace("\n", " ")
            bot_preview = bot_resp[:150].replace("\n", " ")
            lines.append(f"- User: {user_preview}")
            lines.append(f"  Bot: {bot_preview}")
        return "\n".join(lines)

    async def _setup_discord_proactive_tool(self):
        """Setup Discord client for the Discord proactive tool."""
        if not self.tool_registry:
            return
        
        # Find Discord adapter
        discord_adapter = None
        for adapter in self._channels:
            if isinstance(adapter, DiscordAdapter):
                discord_adapter = adapter
                break
        
        if not discord_adapter:
            return
        
        # Get Discord proactive tool
        discord_tool = self.tool_registry._native_tools.get('discord_proactive')
        if discord_tool and hasattr(discord_tool, 'set_discord_client'):
            # Wait for Discord to be ready
            await discord_adapter._ready.wait()
            # Set the client
            discord_tool.set_discord_client(discord_adapter._client)
            logger.info("Discord proactive tool configured with client")

    async def _pre_compaction_flush(self) -> None:
        """Save a session summary before context compaction occurs.

        Triggered at pre_compaction_ratio of compaction_threshold.
        Writes to daily log and ingests into BM25 memory.
        """
        logger.info(
            "Pre-compaction flush triggered at message %d", self._message_count
        )
        summary = self._build_conversation_summary()

        # Write to daily log
        if hasattr(self, 'daily_log'):
            try:
                self.daily_log.write_session_summary(
                    summary, message_count=self._message_count
                )
                logger.info("Pre-compaction summary written to daily log")
            except Exception as e:
                logger.warning("Pre-compaction daily log write failed: %s", e)

        # Ingest into BM25 memory for searchability
        if self.memory:
            try:
                ingest_content = (
                    f"[Pre-compaction flush at message {self._message_count}]\n{summary}"
                )
                bot_label = f"Session context saved before compaction (message {self._message_count})"
                await self.memory.ingest(
                    "system",
                    ingest_content,
                    bot_label,
                )
                logger.info("Pre-compaction summary ingested into memory")
            except Exception as e:
                logger.warning("Pre-compaction memory ingest failed: %s", e)

    async def _send_compaction_ping(self, adapter) -> None:
        """DM the owner when message count hits compaction threshold."""
        owner_id = getattr(self.config, 'owner_user_id', '')
        if not owner_id:
            return
        msg = (
            f"Context is getting long ({self._message_count} messages). "
            "Consider starting a fresh session."
        )
        try:
            from antarisbot.channels.discord import DiscordAdapter
            if isinstance(adapter, DiscordAdapter) and hasattr(adapter, '_client') and adapter._client:
                user = await adapter._client.fetch_user(int(owner_id))
                if user:
                    await user.send(msg)
                    logger.info("Sent compaction ping to owner %s", owner_id)
        except Exception as e:
            logger.warning("Could not send compaction DM: %s", e)

        # Persist compaction summary to memory regardless of DM success
        if self.memory:
            try:
                summary = self._build_conversation_summary()
                compaction_content = (
                    f"[Compaction at message {self._message_count}]\n{summary}"
                )
                compaction_label = f"Session compacted at message {self._message_count}"
                await self.memory.ingest(
                    "system",
                    compaction_content,
                    compaction_label,
                )
                logger.info("Compaction summary ingested into memory")
            except Exception as e:
                logger.warning("Compaction summary ingest failed: %s", e)
            return

        # Fallback: log only (no memory available)
        logger.warning("COMPACTION PING (no DM sent): %s", msg)
