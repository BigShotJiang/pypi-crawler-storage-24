"""CLI commands for stats (SDK-backed)."""

from __future__ import annotations

import typer

from cli.output import Format, format_option, output
from cli.sdk_client import get_sdk_client

app = typer.Typer(
    name="stats",
    help="Platform statistics.",
    no_args_is_help=True,
)


@app.command("overview")
def stats_overview(
    format: Format | None = format_option(),
) -> None:
    """Show platform overview statistics."""
    client = get_sdk_client()
    result = client.stats.overview()
    output(result, format=format)


@app.command("clips")
def stats_clips(
    format: Format | None = format_option(),
) -> None:
    """Show clip statistics."""
    client = get_sdk_client()
    result = client.stats.clips()
    output(result, format=format)


@app.command("factories")
def stats_factories(
    format: Format | None = format_option(),
) -> None:
    """Show factory statistics."""
    client = get_sdk_client()
    result = client.stats.factories()
    output(result, format=format)
