"""CLI commands for agent-attributed execution (data-plane, API-backed).

Follows the canonical flow from CLI-DASHBOARD-AGENT-EXECUTION-SPEC.md:

1. Authenticate the human normally (via PAT)
2. Mint a short-lived agent_token
3. Execute the target write with the agent_token
4. Surface actor / acted_for / boundary / expiry clearly
5. Never persist the raw_token locally
"""

from __future__ import annotations

import typer

from cli.console import error, info, success, warning
from cli.guard import require_write
from cli.output import Format, format_option, output

app = typer.Typer(
    name="agent",
    help="Agent-attributed execution via delegated agent tokens.",
    no_args_is_help=True,
)


@app.command("status")
def agent_status(
    format: Format | None = format_option(),
) -> None:
    """Show whether agent-attributed execution is available for the current credential."""
    from cli.sdk_client import get_internal_sdk_client

    client = get_internal_sdk_client()
    access = client.auth.access()

    permissions = access.get("permissions", []) if isinstance(access, dict) else []
    can_mint = "auth.keys.manage" in permissions
    audience = access.get("audience", "unknown") if isinstance(access, dict) else "unknown"
    principal = (
        access.get("principal_subject", "unknown") if isinstance(access, dict) else "unknown"
    )
    principal_type = (
        access.get("principal_type", "unknown") if isinstance(access, dict) else "unknown"
    )

    status_data = {
        "principal": principal,
        "principal_type": principal_type,
        "audience": audience,
        "can_mint_agent_tokens": can_mint,
        "agent_execution_available": can_mint and audience == "internal_user",
        "missing": (
            []
            + (["auth.keys.manage"] if not can_mint else [])
            + (["internal audience"] if audience != "internal_user" else [])
        ),
    }

    if format:
        output(status_data, format=format)
        return

    info(f"Principal: {principal}")
    info(f"Type: {principal_type}")
    info(f"Audience: {audience}")

    if can_mint and audience == "internal_user":
        success("Agent execution: available")
    else:
        missing = status_data["missing"]
        warning(f"Agent execution: not available (missing: {', '.join(missing)})")


@app.command("exec")
def agent_exec(
    ctx: typer.Context,
    action: str = typer.Argument(
        ...,
        help="Action to execute. Currently: update-inventory-devices",
    ),
    partner: str = typer.Option(
        ...,
        "--partner",
        "-p",
        help="Partner slug for the target write.",
    ),
    target_inventory_devices: int | None = typer.Option(
        None,
        "--target-inventory-devices",
        "--devices-total",
        help="New target inventory device count.",
    ),
    agent_subject: str = typer.Option(
        "agent:cli-broker",
        "--agent-subject",
        help="Agent principal subject to use.",
    ),
    boundary_kind: str = typer.Option(
        "platform",
        "--boundary",
        "-b",
        help="Boundary kind: platform or partner.",
    ),
    boundary_partner_id: str | None = typer.Option(
        None,
        "--boundary-partner-id",
        help="Partner UUID for partner boundary (required if --boundary=partner).",
    ),
    dry_run: bool = typer.Option(
        False,
        "--dry-run",
        help="Show what would be executed without performing the write.",
    ),
    format: Format | None = format_option(),
) -> None:
    """Execute an agent-attributed write.

    The CLI authenticates as the human, mints a short-lived agent_token,
    then performs the write with that token. The human PAT is never used
    for the final mutating request.
    """
    if action not in ("update-devices", "update-inventory-devices"):
        error(f"Unknown action: {action}. Supported: update-inventory-devices")
        raise typer.Exit(1)

    if boundary_kind not in ("platform", "partner"):
        error("--boundary must be 'platform' or 'partner'")
        raise typer.Exit(1)

    if boundary_kind == "partner" and not boundary_partner_id:
        error("--boundary-partner-id is required when --boundary=partner")
        raise typer.Exit(1)

    if target_inventory_devices is None:
        error("--target-inventory-devices is required.")
        raise typer.Exit(1)

    require_write(ctx, "Agent-attributed write")

    if dry_run:
        info("Dry run — would execute:")
        info("  Action:    update-inventory-devices")
        info(f"  Partner:   {partner}")
        info(f"  Agent:     {agent_subject}")
        info(f"  Boundary:  {boundary_kind}")
        if target_inventory_devices is not None:
            info(f"  target_inventory_devices:  {target_inventory_devices}")
        return

    from cli.agent_broker import exchange_agent_token, execute_update_inventory_devices

    # Step 1: Mint agent token
    info(f"Minting agent token for {agent_subject}...")

    permissions = ["devices.manage"]
    token_result = exchange_agent_token(
        permissions=permissions,
        boundary_kind=boundary_kind,
        boundary_partner_id=boundary_partner_id,
        agent_subject=agent_subject,
    )

    if isinstance(token_result, str):
        error(f"Token exchange failed: {token_result}")
        raise typer.Exit(1)

    info("Agent token issued:")
    info(f"  Actor:       {token_result.agent_subject}")
    info(f"  Acted for:   {token_result.acted_for_subject}")
    info(f"  Boundary:    {token_result.boundary_kind}")
    info(f"  Permissions: {', '.join(token_result.permissions)}")
    info(f"  Expires:     {token_result.expires_at}")
    info(f"  Credential:  {token_result.credential_public_id}")

    # Step 2: Execute the write with the agent token
    info(f"Executing update-inventory-devices for partner '{partner}'...")

    exec_result = execute_update_inventory_devices(
        agent_token=token_result.raw_token,
        partner_slug=partner,
        target_inventory_devices=target_inventory_devices,
    )

    if not exec_result.ok:
        error(f"Write failed: {exec_result.error}")
        if exec_result.error_code:
            error(f"  Code: {exec_result.error_code}")
        raise typer.Exit(1)

    # Step 3: Surface execution metadata
    execution_summary = {
        "action": "update-inventory-devices",
        "partner": partner,
        "actor": token_result.agent_subject,
        "acted_for": token_result.acted_for_subject,
        "boundary": token_result.boundary_kind,
        "credential": token_result.credential_public_id,
        "expires_at": token_result.expires_at,
        "request_id": exec_result.request_id,
        "result": exec_result.data,
    }

    if format:
        output(execution_summary, format=format)
    else:
        success("Agent-attributed write succeeded")
        info(f"  Actor:      {token_result.agent_subject}")
        info(f"  Acted for:  {token_result.acted_for_subject}")
        info(f"  Boundary:   {token_result.boundary_kind}")
        info(f"  Credential: {token_result.credential_public_id}")
        info(f"  Expires:    {token_result.expires_at}")
        info(f"  Request ID: {exec_result.request_id}")
        if exec_result.data:
            for key, value in exec_result.data.items():
                info(f"  {key}: {value}")
