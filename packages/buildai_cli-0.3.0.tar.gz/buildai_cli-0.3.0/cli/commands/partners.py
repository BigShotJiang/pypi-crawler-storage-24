"""CLI commands for partners (SDK-backed, internal mode)."""

from __future__ import annotations

import itertools

import typer

from cli.output import Format, format_option, output
from cli.sdk_client import get_internal_sdk_client

app = typer.Typer(
    name="partners",
    help="Partner management (internal).",
    no_args_is_help=True,
)


@app.command("list")
def partners_list(
    limit: int = typer.Option(50, "--limit", "-n"),
    format: Format | None = format_option(),
) -> None:
    """List all partners."""
    client = get_internal_sdk_client()
    results = list(itertools.islice(client.partners.iter(), limit))
    output(results, format=format, columns=["slug", "name", "status", "created_at"])


@app.command("get")
def partners_get(
    slug: str = typer.Argument(..., help="Partner slug"),
    format: Format | None = format_option(),
) -> None:
    """Get details for a single partner."""
    client = get_internal_sdk_client()
    partner = client.partners.get(slug)
    output(partner, format=format)


@app.command("kpis")
def partners_kpis(
    format: Format | None = format_option(),
) -> None:
    """Show partner KPIs summary."""
    client = get_internal_sdk_client()
    result = client.partners.kpis()
    output(result, format=format)
