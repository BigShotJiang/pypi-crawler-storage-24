"""
Embedding management CLI commands.

Manages ScaNN indexes and search tuning for embedding tables.

Commands:
    embed index list                       # List all embedding spaces with index status
    embed index list --external            # List external embedding spaces
    embed index status <space_id>          # Show details for a specific index
    embed index create <space_id>          # Create ScaNN index
    embed index drop <space_id>            # Drop ScaNN index
    embed tune show                        # Show current ScaNN tuning settings
    embed tune set                         # Set query-time tuning parameters

Examples:
    # List all spaces and their index status
    cli embed index list

    # List external spaces (Ego4D, EPIC-Kitchens, etc.)
    cli embed index list --external

    # Show index details for space 20
    cli embed index status 20

    # Create index with balanced strategy (sqrt*2)
    cli embed index create 20 --strategy balanced

    # Create external index (UUID space ID)
    cli embed index create 178004c7-da2e-4636-bfa5-2aaa91534867 --external --strategy balanced

    # Create with explicit parameters
    cli embed index create 20 --num-leaves 5656 --quantizer SQ8

    # Preview without creating
    cli embed index create 20 --strategy quality --dry-run

    # Drop an index
    cli embed index drop 20 --force

    # Set query-time tuning for high accuracy
    cli embed tune set --leaves-to-search 500 --reordering-neighbors 200
"""

import asyncio
from enum import Enum
from typing import Annotated

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.prompt import Confirm

from cli.context import get_connection
from cli.console import success, error, info, warning
from cli.guard import require_write

app = typer.Typer(help="Embedding index and tuning commands")
index_app = typer.Typer(help="ScaNN index management")
tune_app = typer.Typer(help="Query-time tuning")

app.add_typer(index_app, name="index")
app.add_typer(tune_app, name="tune")

console = Console()


class Strategy(str, Enum):
    """Index creation strategy."""

    SPEED = "speed"
    BALANCED = "balanced"
    QUALITY = "quality"


class Quantizer(str, Enum):
    """Quantizer type."""

    SQ8 = "SQ8"
    FLAT = "FLAT"
    AH = "AH"


# =============================================================================
# Index Commands
# =============================================================================


@index_app.command("list")
def index_list(
    ctx: typer.Context,
    show_all: Annotated[
        bool,
        typer.Option("--all", "-a", help="Include inactive spaces"),
    ] = False,
    external: Annotated[
        bool,
        typer.Option("--external", help="List external schema spaces (Ego4D, EPIC-Kitchens, etc.)"),
    ] = False,
) -> None:
    """List all embedding spaces with their index status."""
    asyncio.run(_index_list(ctx, show_all, external))


async def _index_list(ctx: typer.Context, show_all: bool, external: bool) -> None:
    from data.context import Context

    settings = ctx.obj["settings"]
    async with get_connection(settings) as conn:
        db_ctx = await Context.for_cli_profile(conn)

        if external:
            from data.external.embeddings import indexes as ext_indexes
            from data.external.embeddings import spaces as ext_spaces

            all_spaces = await ext_spaces.list_spaces(db_ctx, active_only=not show_all)

            table = Table(
                title="External Embedding Spaces & Index Status",
                show_header=True,
                header_style="bold cyan",
            )
            table.add_column("ID", style="dim", max_width=12)
            table.add_column("Table", style="green")
            table.add_column("Model", style="blue")
            table.add_column("Variant", style="yellow")
            table.add_column("Entity", style="magenta")
            table.add_column("Rows", justify="right")
            table.add_column("Index", justify="center")
            table.add_column("num_leaves", justify="right")
            table.add_column("Quantizer", justify="center")
            table.add_column("Size", justify="right")

            indexed_count = 0
            total_count = 0

            for space in all_spaces:
                idx_info = await ext_indexes.get_index_info(db_ctx, space.id)
                total_count += 1

                if idx_info.exists:
                    indexed_count += 1
                    index_status = "[green]Yes[/green]"
                    leaves = str(idx_info.num_leaves) if idx_info.num_leaves else "-"
                    quant = idx_info.quantizer or "-"
                    size = idx_info.index_size or "-"
                else:
                    index_status = "[red]No[/red]"
                    leaves = "-"
                    quant = "-"
                    size = "-"

                # Truncate UUID for display
                short_id = str(space.id)[:8] + "..."

                table.add_row(
                    short_id,
                    space.table_name,
                    space.model_id,
                    space.variant or "(none)",
                    space.entity_type,
                    f"{idx_info.row_count:,}",
                    index_status,
                    leaves,
                    quant,
                    size,
                )

            console.print(table)
            console.print(f"\n[dim]Indexed: {indexed_count}/{total_count} external spaces[/dim]")
        else:
            from data.observations.embeddings import indexes, spaces

            all_spaces = await spaces.list_spaces(db_ctx, active_only=not show_all)

            table = Table(
                title="Embedding Spaces & Index Status",
                show_header=True,
                header_style="bold cyan",
            )
            table.add_column("ID", style="dim", justify="right")
            table.add_column("Table", style="green")
            table.add_column("Model", style="blue")
            table.add_column("Variant", style="yellow")
            table.add_column("Rows", justify="right")
            table.add_column("Index", justify="center")
            table.add_column("num_leaves", justify="right")
            table.add_column("Quantizer", justify="center")
            table.add_column("Size", justify="right")

            indexed_count = 0
            total_count = 0

            for space in all_spaces:
                idx_info = await indexes.get_index_info(db_ctx, space.id)
                total_count += 1

                if idx_info.exists:
                    indexed_count += 1
                    index_status = "[green]Yes[/green]"
                    leaves = str(idx_info.num_leaves) if idx_info.num_leaves else "-"
                    quant = idx_info.quantizer or "-"
                    size = idx_info.index_size or "-"
                else:
                    index_status = "[red]No[/red]"
                    leaves = "-"
                    quant = "-"
                    size = "-"

                table.add_row(
                    str(space.id),
                    space.table_name,
                    space.model_id,
                    space.variant or "(none)",
                    f"{idx_info.row_count:,}",
                    index_status,
                    leaves,
                    quant,
                    size,
                )

            console.print(table)
            console.print(f"\n[dim]Indexed: {indexed_count}/{total_count} spaces[/dim]")


@index_app.command("status")
def index_status(
    ctx: typer.Context,
    space_id: Annotated[
        str, typer.Argument(help="Embedding space ID (int or UUID for --external)")
    ],
    external: Annotated[
        bool,
        typer.Option("--external", help="Use external schema"),
    ] = False,
) -> None:
    """Show detailed index status for an embedding space."""
    asyncio.run(_index_status(ctx, space_id, external))


async def _index_status(ctx: typer.Context, space_id: str, external: bool) -> None:
    from data.context import Context
    from data.observations.embeddings.indexes import calculate_num_leaves

    settings = ctx.obj["settings"]
    async with get_connection(settings) as conn:
        db_ctx = await Context.for_cli_profile(conn)

        if external:
            from data.external.embeddings import indexes as ext_indexes
            from data.external.embeddings import spaces as ext_spaces

            try:
                space = await ext_spaces.get(db_ctx, space_id)
            except Exception as e:
                error(f"External space {space_id} not found: {e}")
                raise typer.Exit(1)

            idx_info = await ext_indexes.get_index_info(db_ctx, space_id)
            schema_prefix = "external"
            display_id = str(space.id)
            create_flag = " --external"
        else:
            from data.observations.embeddings import indexes, spaces

            try:
                space = await spaces.get(db_ctx, int(space_id))
            except Exception as e:
                error(f"Space {space_id} not found: {e}")
                raise typer.Exit(1)

            idx_info = await indexes.get_index_info(db_ctx, int(space_id))
            schema_prefix = "observations"
            display_id = space_id
            create_flag = ""

        lines = [
            f"[bold]Space ID:[/bold] {display_id}",
            f"[bold]Table:[/bold] {schema_prefix}.{space.table_name}",
            f"[bold]Model:[/bold] {space.model_id}",
            f"[bold]Variant:[/bold] {space.variant or '(none)'}",
            f"[bold]Dimensions:[/bold] {space.dimensions}",
            f"[bold]Row Count:[/bold] {idx_info.row_count:,}",
            "",
        ]

        if idx_info.exists:
            lines.extend(
                [
                    "[green bold]Index: EXISTS[/green bold]",
                    f"[bold]Index Name:[/bold] {idx_info.index_name}",
                    f"[bold]num_leaves:[/bold] {idx_info.num_leaves}",
                    f"[bold]quantizer:[/bold] {idx_info.quantizer}",
                    f"[bold]Index Size:[/bold] {idx_info.index_size}",
                    "",
                    "[dim]Strategy recommendations for this row count:[/dim]",
                    f"  speed:    {calculate_num_leaves(idx_info.row_count, 'speed'):,} leaves",
                    f"  balanced: {calculate_num_leaves(idx_info.row_count, 'balanced'):,} leaves",
                    f"  quality:  {calculate_num_leaves(idx_info.row_count, 'quality'):,} leaves",
                ]
            )
        else:
            lines.extend(
                [
                    "[red bold]Index: NONE[/red bold]",
                    "",
                    "[dim]Recommended num_leaves for this row count:[/dim]",
                    f"  speed:    {calculate_num_leaves(idx_info.row_count, 'speed'):,} leaves (fast build, ~90% recall)",
                    f"  balanced: {calculate_num_leaves(idx_info.row_count, 'balanced'):,} leaves (good balance, ~95% recall)",
                    f"  quality:  {calculate_num_leaves(idx_info.row_count, 'quality'):,} leaves (slow build, ~98%+ recall)",
                    "",
                    "[yellow]Create with:[/yellow]",
                    f"  cli embed index create {display_id}{create_flag} --strategy balanced",
                ]
            )

        console.print(Panel("\n".join(lines), title=f"Embedding Space {display_id}"))


@index_app.command("create")
def index_create(
    ctx: typer.Context,
    space_id: Annotated[
        str, typer.Argument(help="Embedding space ID (int or UUID for --external)")
    ],
    strategy: Annotated[
        Strategy,
        typer.Option("--strategy", "-s", help="Strategy for calculating num_leaves"),
    ] = Strategy.BALANCED,
    num_leaves: Annotated[
        int | None,
        typer.Option("--num-leaves", "-n", help="Override num_leaves (auto-calculated if not set)"),
    ] = None,
    quantizer: Annotated[
        Quantizer,
        typer.Option("--quantizer", "-q", help="Quantizer type"),
    ] = Quantizer.SQ8,
    concurrent: Annotated[
        bool,
        typer.Option("--concurrent/--no-concurrent", help="Use CONCURRENTLY (non-blocking)"),
    ] = True,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", help="Show what would be created without executing"),
    ] = False,
    yes: Annotated[
        bool,
        typer.Option("--yes", "-y", help="Skip confirmation prompt"),
    ] = False,
    external: Annotated[
        bool,
        typer.Option("--external", help="Use external schema"),
    ] = False,
) -> None:
    """Create a ScaNN index on an embedding table."""
    if not dry_run:
        require_write(ctx, "Embedding index creation")
    asyncio.run(
        _index_create(
            ctx, space_id, strategy, num_leaves, quantizer, concurrent, dry_run, yes, external
        )
    )


async def _index_create(
    ctx: typer.Context,
    space_id: str,
    strategy: Strategy,
    num_leaves: int | None,
    quantizer: Quantizer,
    concurrent: bool,
    dry_run: bool,
    yes: bool,
    external: bool,
) -> None:
    from data.context import Context
    from data.observations.embeddings.indexes import calculate_num_leaves

    settings = ctx.obj["settings"]
    async with get_connection(settings) as conn:
        db_ctx = await Context.for_cli_profile(conn)

        if external:
            from data.external.embeddings import indexes as ext_indexes
            from data.external.embeddings import spaces as ext_spaces

            try:
                space = await ext_spaces.get(db_ctx, space_id)
            except Exception as e:
                error(f"External space {space_id} not found: {e}")
                raise typer.Exit(1)

            current = await ext_indexes.get_index_info(db_ctx, space_id)
            schema_label = "external"
            create_fn = ext_indexes.create_scann_index
        else:
            from data.observations.embeddings import indexes, spaces

            try:
                space = await spaces.get(db_ctx, int(space_id))
            except Exception as e:
                error(f"Space {space_id} not found: {e}")
                raise typer.Exit(1)

            current = await indexes.get_index_info(db_ctx, int(space_id))
            schema_label = "observations"
            create_fn = indexes.create_scann_index

        if current.exists:
            info(f"Index already exists: {current.index_name}")
            info(f"  num_leaves: {current.num_leaves}, quantizer: {current.quantizer}")
            info("Use 'cli embed index drop' first to recreate with different settings.")
            return

        effective_leaves = num_leaves
        if effective_leaves is None:
            effective_leaves = calculate_num_leaves(current.row_count, strategy.value)

        console.print(
            Panel(
                f"[bold]Schema:[/bold] {schema_label}\n"
                f"[bold]Space:[/bold] {space_id} ({space.table_name})\n"
                f"[bold]Rows:[/bold] {current.row_count:,}\n"
                f"[bold]Strategy:[/bold] {strategy.value}\n"
                f"[bold]num_leaves:[/bold] {effective_leaves:,}\n"
                f"[bold]quantizer:[/bold] {quantizer.value}\n"
                f"[bold]concurrent:[/bold] {concurrent}",
                title="Index Creation Plan",
            )
        )

        if dry_run:
            warning("Dry run - no changes made")
            return

        if not yes:
            if not Confirm.ask("Create this index?"):
                warning("Cancelled")
                return

        info("Creating index... (this may take a while for large tables)")

        resolved_id = space_id if external else int(space_id)

        try:
            result = await create_fn(
                db_ctx,
                resolved_id,
                num_leaves=effective_leaves,
                quantizer=quantizer.value,
                strategy=strategy.value,
                concurrent=concurrent,
                dry_run=False,
            )
            success(f"Index created: {result.index_name}")
            success(f"  Size: {result.index_size}")
        except Exception as e:
            error(f"Failed to create index: {e}")
            raise typer.Exit(1)


@index_app.command("drop")
def index_drop(
    ctx: typer.Context,
    space_id: Annotated[
        str, typer.Argument(help="Embedding space ID (int or UUID for --external)")
    ],
    force: Annotated[
        bool,
        typer.Option("--force", "-f", help="Skip confirmation prompt"),
    ] = False,
    concurrent: Annotated[
        bool,
        typer.Option("--concurrent/--no-concurrent", help="Use CONCURRENTLY (non-blocking)"),
    ] = True,
    external: Annotated[
        bool,
        typer.Option("--external", help="Use external schema"),
    ] = False,
) -> None:
    """Drop a ScaNN index from an embedding table."""
    require_write(ctx, "Embedding index drop")
    asyncio.run(_index_drop(ctx, space_id, force, concurrent, external))


async def _index_drop(
    ctx: typer.Context,
    space_id: str,
    force: bool,
    concurrent: bool,
    external: bool,
) -> None:
    from data.context import Context

    settings = ctx.obj["settings"]
    async with get_connection(settings) as conn:
        db_ctx = await Context.for_cli_profile(conn)

        if external:
            from data.external.embeddings import indexes as ext_indexes

            current = await ext_indexes.get_index_info(db_ctx, space_id)
            drop_fn = ext_indexes.drop_index
            resolved_id = space_id
        else:
            from data.observations.embeddings import indexes

            current = await indexes.get_index_info(db_ctx, int(space_id))
            drop_fn = indexes.drop_index
            resolved_id = int(space_id)

        if not current.exists:
            info(f"No index exists for space {space_id}")
            return

        info(f"Index: {current.index_name}")
        info(f"  Table: {current.table_name}")
        info(f"  Size: {current.index_size}")

        if not force:
            if not Confirm.ask("Drop this index?"):
                warning("Cancelled")
                return

        dropped = await drop_fn(db_ctx, resolved_id, concurrent=concurrent)

        if dropped:
            success(f"Dropped index: {current.index_name}")
        else:
            warning("No index to drop")


# =============================================================================
# Tune Commands
# =============================================================================


@tune_app.command("show")
def tune_show(ctx: typer.Context) -> None:
    """Show current ScaNN query-time tuning settings."""
    asyncio.run(_tune_show(ctx))


async def _tune_show(ctx: typer.Context) -> None:
    settings = ctx.obj["settings"]
    async with get_connection(settings) as conn:
        # Query current session settings
        rows = await conn.fetch("""
            SELECT name, setting, short_desc
            FROM pg_settings
            WHERE name LIKE 'scann.%'
            ORDER BY name
        """)

        if not rows:
            info("No ScaNN settings found (using defaults)")
            console.print("\n[dim]ScaNN parameters:[/dim]")
            console.print("  num_leaves_to_search: 1% of num_leaves (default)")
            console.print("  pre_reordering_num_neighbors: 50*K or 0 (default)")
            return

        table = Table(title="ScaNN Query Settings", show_header=True)
        table.add_column("Parameter", style="green")
        table.add_column("Value", style="yellow")
        table.add_column("Description", style="dim")

        for row in rows:
            table.add_row(row["name"], row["setting"], row["short_desc"] or "")

        console.print(table)


@tune_app.command("set")
def tune_set(
    ctx: typer.Context,
    leaves_to_search: Annotated[
        int | None,
        typer.Option(
            "--leaves-to-search", "-l", help="Number of leaves to search (higher = better recall)"
        ),
    ] = None,
    reordering_neighbors: Annotated[
        int | None,
        typer.Option(
            "--reordering-neighbors",
            "-r",
            help="Candidates for reranking (higher = better recall for high-D)",
        ),
    ] = None,
) -> None:
    """Set query-time ScaNN tuning parameters for this session."""
    require_write(ctx, "Embedding tuning update")
    asyncio.run(_tune_set(ctx, leaves_to_search, reordering_neighbors))


async def _tune_set(
    ctx: typer.Context,
    leaves_to_search: int | None,
    reordering_neighbors: int | None,
) -> None:
    from data.observations.embeddings import indexes

    if leaves_to_search is None and reordering_neighbors is None:
        error("Specify at least one parameter to set")
        raise typer.Exit(1)

    settings = ctx.obj["settings"]
    async with get_connection(settings) as conn:
        statements = indexes.generate_tune_sql(
            leaves_to_search=leaves_to_search,
            reordering_neighbors=reordering_neighbors,
        )

        for stmt in statements:
            await conn.execute(stmt)
            success(f"Set: {stmt}")

        console.print("\n[dim]These settings apply to this session only.[/dim]")
        console.print("[dim]For application use, add to your connection initialization.[/dim]")


@tune_app.command("reset")
def tune_reset(ctx: typer.Context) -> None:
    """Reset ScaNN tuning parameters to defaults."""
    require_write(ctx, "Embedding tuning reset")
    asyncio.run(_tune_reset(ctx))


async def _tune_reset(ctx: typer.Context) -> None:
    from data.observations.embeddings import indexes

    settings = ctx.obj["settings"]
    async with get_connection(settings) as conn:
        statements = indexes.generate_reset_sql()

        for stmt in statements:
            await conn.execute(stmt)
            success(f"Reset: {stmt}")
