"""Raw API proxy — call any endpoint using CLI credentials."""

from __future__ import annotations

import json
import sys
from typing import Any

import httpx
import typer

from cli.config import resolve_api_url, resolve_credential
from cli.console import error


def api(
    path: str = typer.Argument(
        ...,
        help="API path, e.g. /v1/clips or /v1/predictions/types?factory_id=...",
    ),
    method: str = typer.Option(
        "GET",
        "-X",
        "--method",
        help="HTTP method: GET, POST, PATCH, DELETE.",
    ),
    body: str | None = typer.Option(
        None,
        "-d",
        "--body",
        help="JSON request body (for POST/PATCH).",
    ),
    raw: bool = typer.Option(
        False,
        "--raw",
        help="Output the full response including status and headers.",
    ),
) -> None:
    """Call any Build AI API endpoint directly.

    Uses your stored credential — no API key needed in the command.

    Examples:

        buildai api /v1/clips?page_size=3

        buildai api /v1/predictions/types

        buildai api -X POST /v1/query -d '{"sql": "SELECT count(*) FROM core.clips"}'

        buildai api /v1/factories | jq '.data[].id'

        buildai api /v1/assets/ASSET_UUID/sign -X POST
    """
    try:
        token = resolve_credential()
    except RuntimeError as exc:
        error(str(exc))
        raise typer.Exit(1) from exc

    base_url = resolve_api_url()
    url = f"{base_url}{path}" if path.startswith("/") else f"{base_url}/{path}"

    headers: dict[str, str] = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
    }

    parsed_body: Any = None
    if body:
        try:
            parsed_body = json.loads(body)
            headers["Content-Type"] = "application/json"
        except json.JSONDecodeError:
            error("Invalid JSON in --body.")
            raise typer.Exit(1)

    with httpx.Client(timeout=60.0) as client:
        resp = client.request(
            method.upper(),
            url,
            headers=headers,
            json=parsed_body,
        )

    if raw:
        sys.stdout.write(f"HTTP {resp.status_code}\n")
        for k, v in resp.headers.items():
            sys.stdout.write(f"{k}: {v}\n")
        sys.stdout.write("\n")

    try:
        data = resp.json()
        sys.stdout.write(json.dumps(data, indent=2, default=str) + "\n")
    except Exception:
        sys.stdout.write(resp.text + "\n")

    if resp.status_code >= 400:
        raise typer.Exit(1)
