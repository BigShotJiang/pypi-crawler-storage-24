"""CLI commands for predictions."""

from __future__ import annotations

import itertools

import typer

from cli.output import OutputFormat, auto_format, render
from cli.sdk_client import get_sdk_client

app = typer.Typer(
    name="predictions", help="Inspect prediction types and results.", no_args_is_help=True
)


def _output(
    value: object, *, output: OutputFormat | None, columns: list[str] | None = None
) -> None:
    render(value, format=output or auto_format(), columns=columns)


@app.command("types", help="List all registered prediction types (models + prompts).")
def prediction_types(
    output: OutputFormat | None = typer.Option(None, "-o", "--output"),
) -> None:
    client = get_sdk_client()
    try:
        page = client.predictions.types()
    finally:
        client.close()
    _output(
        page.data,
        output=output,
        columns=["id", "display_name", "target", "input_asset_type", "model", "updated_at"],
    )


@app.command("list", help="Query predictions for a factory, optionally filtered by type/label.")
def prediction_list(
    factory: str = typer.Option(..., "--factory", help="Factory UUID."),
    type: str | None = typer.Option(None, "--type", help="Prediction type ID."),
    label: str | None = typer.Option(None, "--label", help="Prediction label."),
    limit: int = typer.Option(50, "--limit", help="Maximum predictions to render."),
    output: OutputFormat | None = typer.Option(None, "-o", "--output"),
) -> None:
    client = get_sdk_client()
    try:
        page = client.predictions.list(
            factory_id=factory,
            prediction_type_id=type,
            label=label,
            page_size=min(limit, 200),
        )
    finally:
        client.close()
    _output(
        list(itertools.islice(page.data, limit)),
        output=output,
        columns=[
            "id",
            "prediction_type_id",
            "clip_id",
            "frame_id",
            "factory_id",
            "worker_id",
            "label",
            "run_id",
            "created_at",
        ],
    )


@app.command("summary", help="Aggregated prediction counts by type and label for a factory.")
def prediction_summary(
    factory: str = typer.Option(..., "--factory", help="Factory UUID."),
    type: str | None = typer.Option(None, "--type", help="Prediction type ID."),
    output: OutputFormat | None = typer.Option(None, "-o", "--output"),
) -> None:
    client = get_sdk_client()
    try:
        page = client.predictions.summary(factory_id=factory, prediction_type_id=type)
    finally:
        client.close()
    _output(page.data, output=output, columns=["prediction_type_id", "label", "count"])


@app.command("get-clip", help="Get all predictions for a specific clip.")
def prediction_get_clip(
    clip_id: str = typer.Argument(..., help="Clip UUID."),
    type: str | None = typer.Option(None, "--type", help="Prediction type ID."),
    output: OutputFormat | None = typer.Option(None, "-o", "--output"),
) -> None:
    client = get_sdk_client()
    try:
        page = client.predictions.get_for_clip(clip_id, prediction_type_id=type)
    finally:
        client.close()
    _output(page.data, output=output)


@app.command("get-frame", help="Get the prediction for a specific frame.")
def prediction_get_frame(
    frame_id: str = typer.Argument(..., help="Frame UUID."),
    type: str | None = typer.Option(None, "--type", help="Prediction type ID."),
    output: OutputFormat | None = typer.Option(None, "-o", "--output"),
) -> None:
    client = get_sdk_client()
    try:
        page = client.predictions.get_for_frame(frame_id, prediction_type_id=type)
    finally:
        client.close()
    _output(page.data, output=output)
