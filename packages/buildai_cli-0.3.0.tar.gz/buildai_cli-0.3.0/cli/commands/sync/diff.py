"""Sync diff command - compare schemas between environments."""

import asyncio
import json
from typing import Sequence

import typer
from rich.table import Table
from typing_extensions import Annotated

from cli.commands.sync.models import SyncDiff
from cli.commands.sync.queries import (
    fetch_constraints,
    fetch_indexes,
    fetch_materialized_views,
    fetch_sequences,
    fetch_triggers,
)
from cli.console import console, info, success, warning
from cli.context import get_connection
from infra.settings import switch_environment


def _index_by_name(items: list, key_attr: str = "full_name") -> dict:
    """Create a dict keyed by attribute name."""
    return {getattr(item, key_attr): item for item in items}


def _compare_items(
    source_items: list,
    target_items: list,
    key_attr: str = "full_name",
) -> tuple[list, list]:
    """
    Compare two lists of items and return (missing_in_target, extra_in_target).
    """
    source_by_name = _index_by_name(source_items, key_attr)
    target_by_name = _index_by_name(target_items, key_attr)

    source_names = set(source_by_name.keys())
    target_names = set(target_by_name.keys())

    missing = [source_by_name[name] for name in sorted(source_names - target_names)]
    extra = [target_by_name[name] for name in sorted(target_names - source_names)]

    return missing, extra


async def compute_diff(
    source_env: str,
    target_env: str,
    schemas: Sequence[str] | None = None,
    include_indexes: bool = True,
    include_constraints: bool = True,
    include_triggers: bool = True,
    include_matviews: bool = True,
    include_sequences: bool = True,
) -> SyncDiff:
    """
    Compute the schema diff between source and target environments.

    Args:
        source_env: Source environment (e.g., 'prod', 'dev')
        target_env: Target environment (e.g., 'dev', 'prod')
        schemas: List of schemas to compare (defaults to app schemas)
        include_indexes: Include index comparison
        include_constraints: Include constraint comparison
        include_triggers: Include trigger comparison
        include_matviews: Include materialized view comparison
        include_sequences: Include sequence comparison

    Returns:
        SyncDiff object with all differences
    """
    diff = SyncDiff(source_env=source_env, target_env=target_env)

    # Normalize schema filter
    schema_list = list(schemas) if schemas else None

    # Fetch from source
    source_settings = switch_environment(source_env)
    async with get_connection(source_settings) as source_conn:
        source_indexes = await fetch_indexes(source_conn, schema_list) if include_indexes else []
        source_constraints = (
            await fetch_constraints(source_conn, schema_list) if include_constraints else []
        )
        source_triggers = await fetch_triggers(source_conn, schema_list) if include_triggers else []
        source_matviews = (
            await fetch_materialized_views(source_conn, schema_list) if include_matviews else []
        )
        source_sequences = (
            await fetch_sequences(source_conn, schema_list) if include_sequences else []
        )

    # Fetch from target
    target_settings = switch_environment(target_env)
    async with get_connection(target_settings) as target_conn:
        target_indexes = await fetch_indexes(target_conn, schema_list) if include_indexes else []
        target_constraints = (
            await fetch_constraints(target_conn, schema_list) if include_constraints else []
        )
        target_triggers = await fetch_triggers(target_conn, schema_list) if include_triggers else []
        target_matviews = (
            await fetch_materialized_views(target_conn, schema_list) if include_matviews else []
        )
        target_sequences = (
            await fetch_sequences(target_conn, schema_list) if include_sequences else []
        )

    # Compare indexes
    if include_indexes:
        diff.indexes_missing_in_target, diff.indexes_extra_in_target = _compare_items(
            source_indexes, target_indexes
        )

    # Compare constraints
    if include_constraints:
        diff.constraints_missing, diff.constraints_extra = _compare_items(
            source_constraints, target_constraints
        )

    # Compare triggers
    if include_triggers:
        diff.triggers_missing, diff.triggers_extra = _compare_items(
            source_triggers, target_triggers
        )

    # Compare materialized views
    if include_matviews:
        diff.matviews_missing, diff.matviews_extra = _compare_items(
            source_matviews, target_matviews
        )

    # Compare sequences
    if include_sequences:
        diff.sequences_missing, diff.sequences_extra = _compare_items(
            source_sequences, target_sequences
        )

    return diff


def print_diff_table(diff: SyncDiff) -> None:
    """Print schema differences as formatted tables."""
    if diff.is_empty():
        success(f"No differences between {diff.source_env} and {diff.target_env}")
        return

    warning(f"Schema differences: {diff.source_env} -> {diff.target_env}")
    console.print()

    # Summary table
    summary = diff.summary()
    has_any = any(v > 0 for v in summary.values())
    if has_any:
        table = Table(title="Diff Summary")
        table.add_column("Object Type", style="cyan")
        table.add_column(f"Missing in {diff.target_env}", justify="right", style="red")
        table.add_column(f"Extra in {diff.target_env}", justify="right", style="yellow")

        if summary["indexes_missing"] or summary["indexes_extra"]:
            table.add_row("Indexes", str(summary["indexes_missing"]), str(summary["indexes_extra"]))
        if summary["constraints_missing"] or summary["constraints_extra"]:
            table.add_row(
                "Constraints",
                str(summary["constraints_missing"]),
                str(summary["constraints_extra"]),
            )
        if summary["triggers_missing"] or summary["triggers_extra"]:
            table.add_row(
                "Triggers", str(summary["triggers_missing"]), str(summary["triggers_extra"])
            )
        if summary["matviews_missing"] or summary["matviews_extra"]:
            table.add_row(
                "Materialized Views",
                str(summary["matviews_missing"]),
                str(summary["matviews_extra"]),
            )
        if summary["sequences_missing"] or summary["sequences_extra"]:
            table.add_row(
                "Sequences", str(summary["sequences_missing"]), str(summary["sequences_extra"])
            )

        console.print(table)
        console.print()

    # Detailed tables for missing indexes
    if diff.indexes_missing_in_target:
        table = Table(title=f"Indexes missing in {diff.target_env}")
        table.add_column("Schema", style="cyan")
        table.add_column("Table", style="white")
        table.add_column("Index", style="red")
        table.add_column("Type", style="dim")

        for idx in diff.indexes_missing_in_target:
            table.add_row(idx.schema_name, idx.table_name, idx.index_name, idx.index_type)

        console.print(table)
        console.print()

    # Extra indexes
    if diff.indexes_extra_in_target:
        table = Table(title=f"Indexes only in {diff.target_env}")
        table.add_column("Schema", style="cyan")
        table.add_column("Table", style="white")
        table.add_column("Index", style="yellow")
        table.add_column("Type", style="dim")

        for idx in diff.indexes_extra_in_target:
            table.add_row(idx.schema_name, idx.table_name, idx.index_name, idx.index_type)

        console.print(table)
        console.print()

    # Missing constraints
    if diff.constraints_missing:
        table = Table(title=f"Constraints missing in {diff.target_env}")
        table.add_column("Schema", style="cyan")
        table.add_column("Table", style="white")
        table.add_column("Constraint", style="red")
        table.add_column("Type", style="dim")

        for c in diff.constraints_missing:
            table.add_row(c.schema_name, c.table_name, c.constraint_name, c.constraint_type)

        console.print(table)
        console.print()

    # Missing triggers
    if diff.triggers_missing:
        table = Table(title=f"Triggers missing in {diff.target_env}")
        table.add_column("Schema", style="cyan")
        table.add_column("Table", style="white")
        table.add_column("Trigger", style="red")
        table.add_column("Function", style="dim")

        for t in diff.triggers_missing:
            table.add_row(t.schema_name, t.table_name, t.trigger_name, t.function_name)

        console.print(table)
        console.print()

    # Missing materialized views
    if diff.matviews_missing:
        table = Table(title=f"Materialized Views missing in {diff.target_env}")
        table.add_column("Schema", style="cyan")
        table.add_column("View", style="red")
        table.add_column("Indexes", justify="right")

        for mv in diff.matviews_missing:
            table.add_row(mv.schema_name, mv.view_name, str(len(mv.indexes)))

        console.print(table)
        console.print()


def print_diff_markdown(diff: SyncDiff) -> None:
    """Print schema differences as markdown."""
    if diff.is_empty():
        console.print(f"No differences between {diff.source_env} and {diff.target_env}")
        return

    console.print(f"## Schema Diff: {diff.source_env} -> {diff.target_env}\n")

    # Indexes
    if diff.indexes_missing_in_target:
        console.print(f"### Indexes missing in {diff.target_env}")
        for idx in diff.indexes_missing_in_target:
            console.print(f"- `{idx.full_name}` on `{idx.schema_name}.{idx.table_name}`")
        console.print()

    if diff.indexes_extra_in_target:
        console.print(f"### Indexes only in {diff.target_env}")
        for idx in diff.indexes_extra_in_target:
            console.print(f"- `{idx.full_name}` on `{idx.schema_name}.{idx.table_name}`")
        console.print()

    # Constraints
    if diff.constraints_missing:
        console.print(f"### Constraints missing in {diff.target_env}")
        for c in diff.constraints_missing:
            console.print(f"- `{c.full_name}` ({c.constraint_type})")
        console.print()

    # Triggers
    if diff.triggers_missing:
        console.print(f"### Triggers missing in {diff.target_env}")
        for t in diff.triggers_missing:
            console.print(f"- `{t.full_name}` -> `{t.function_name}()`")
        console.print()

    # Materialized views
    if diff.matviews_missing:
        console.print(f"### Materialized Views missing in {diff.target_env}")
        for mv in diff.matviews_missing:
            console.print(f"- `{mv.full_name}` ({len(mv.indexes)} indexes)")
        console.print()


# Create the command
app = typer.Typer()


@app.command("diff")
def diff_command(
    source: Annotated[
        str,
        typer.Option("--source", "-s", help="Source environment (default: prod)"),
    ] = "prod",
    target: Annotated[
        str,
        typer.Option("--target", "-t", help="Target environment (default: dev)"),
    ] = "dev",
    indexes: Annotated[
        bool,
        typer.Option("--indexes", help="Only compare indexes"),
    ] = False,
    constraints: Annotated[
        bool,
        typer.Option("--constraints", help="Only compare constraints"),
    ] = False,
    triggers: Annotated[
        bool,
        typer.Option("--triggers", help="Only compare triggers"),
    ] = False,
    matviews: Annotated[
        bool,
        typer.Option("--matviews", help="Only compare materialized views"),
    ] = False,
    sequences: Annotated[
        bool,
        typer.Option("--sequences", help="Only compare sequences"),
    ] = False,
    schema: Annotated[
        str | None,
        typer.Option("--schema", help="Filter by schema name (e.g., core, observations)"),
    ] = None,
    output_format: Annotated[
        str,
        typer.Option("--format", "-f", help="Output format: table, json, markdown"),
    ] = "table",
) -> None:
    """
    Compare schema objects between two database environments.

    By default, compares prod (source) to dev (target) for all object types.
    Use filter flags to compare specific object types only.

    Examples:
        cli sync diff                              # All differences
        cli sync diff --indexes                    # Only index differences
        cli sync diff --source dev --target prod  # Reverse direction
        cli sync diff --schema core               # Only core schema
        cli sync diff --format json               # JSON output
    """

    async def run() -> None:
        # If no specific type is selected, include all
        include_all = not any([indexes, constraints, triggers, matviews, sequences])

        # Parse schemas
        schema_list = [schema] if schema else None

        info(f"Comparing {source} -> {target}...")

        diff = await compute_diff(
            source_env=source,
            target_env=target,
            schemas=schema_list,
            include_indexes=indexes or include_all,
            include_constraints=constraints or include_all,
            include_triggers=triggers or include_all,
            include_matviews=matviews or include_all,
            include_sequences=sequences or include_all,
        )

        console.print()

        if output_format == "json":
            console.print(json.dumps(diff.to_dict(), indent=2))
        elif output_format == "markdown":
            print_diff_markdown(diff)
        else:
            print_diff_table(diff)

    asyncio.run(run())
