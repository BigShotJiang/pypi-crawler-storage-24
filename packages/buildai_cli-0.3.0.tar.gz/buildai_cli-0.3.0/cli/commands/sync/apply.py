"""Sync apply command - apply missing schema objects to target environment."""

import asyncio
from pathlib import Path
from typing import Any

import typer
from rich.syntax import Syntax
from rich.table import Table
from typing_extensions import Annotated

from cli.commands.sync.ddl import (
    generate_add_constraint_ddl,
    generate_index_ddl,
    generate_index_ddl_concurrent,
    generate_matview_ddl,
    generate_sequence_ddl,
    generate_trigger_ddl,
)
from cli.commands.sync.diff import compute_diff
from cli.commands.sync.models import (
    ConstraintInfo,
    IndexInfo,
    MaterializedViewInfo,
    SequenceInfo,
    TriggerInfo,
)
from cli.console import console, error, info, success, warning
from cli.guard import require_write
from cli.context import get_connection
from infra.settings import switch_environment


def validate_sync_direction(
    source: str,
    target: str,
    operation: str,
    allow_prod_write: bool = False,
) -> None:
    """
    Validate that the sync direction is allowed.

    Args:
        source: Source environment
        target: Target environment
        operation: Operation type ('schema' or 'data')
        allow_prod_write: Whether to allow writes to production

    Raises:
        typer.BadParameter: If the operation is not allowed
    """
    target_is_prod = target.lower() in ("prod", "production")

    if target_is_prod:
        if operation == "data":
            raise typer.BadParameter(
                "Data writes to production are BLOCKED. Use `cli promote` for migrations instead."
            )

        if operation == "schema" and not allow_prod_write:
            raise typer.BadParameter(
                "Schema writes to production require --allow-prod-write flag.\n"
                "This promotes schema objects from dev to prod.\n"
                "Run with --allow-prod-write to confirm."
            )


def _format_object_summary(objects: list[Any]) -> str:
    """Format a summary of objects for display."""
    if not objects:
        return "none"

    # Group by type
    by_type: dict[str, int] = {}
    for obj in objects:
        type_name = type(obj).__name__.replace("Info", "").lower()
        by_type[type_name] = by_type.get(type_name, 0) + 1

    parts = [f"{count} {name}{'s' if count > 1 else ''}" for name, count in by_type.items()]
    return ", ".join(parts)


def show_apply_preview(
    objects: list[Any],
    target_env: str,
    ddl_statements: list[str],
) -> None:
    """Show a preview of what will be applied."""
    table = Table(title=f"Objects to apply to {target_env}")
    table.add_column("Type", style="cyan")
    table.add_column("Name", style="white")
    table.add_column("Table/Schema", style="dim")

    for obj in objects:
        if isinstance(obj, IndexInfo):
            table.add_row("Index", obj.index_name, f"{obj.schema_name}.{obj.table_name}")
        elif isinstance(obj, ConstraintInfo):
            table.add_row("Constraint", obj.constraint_name, f"{obj.schema_name}.{obj.table_name}")
        elif isinstance(obj, TriggerInfo):
            table.add_row("Trigger", obj.trigger_name, f"{obj.schema_name}.{obj.table_name}")
        elif isinstance(obj, MaterializedViewInfo):
            table.add_row("Mat. View", obj.view_name, obj.schema_name)
        elif isinstance(obj, SequenceInfo):
            table.add_row("Sequence", obj.sequence_name, obj.schema_name)

    console.print(table)


def confirm_apply(
    objects: list[Any],
    target_env: str,
    yes: bool = False,
) -> bool:
    """
    Show summary and get user confirmation.

    Returns True if confirmed, False otherwise.
    """
    target_is_prod = target_env.lower() in ("prod", "production")

    if target_is_prod:
        console.print()
        console.print("[red bold]WARNING: You are about to modify PRODUCTION[/red bold]")
        console.print()

    if not yes:
        return typer.confirm(
            f"Apply {len(objects)} object(s) to {target_env}?",
            default=False,
        )

    return True


# Create the command
app = typer.Typer()


@app.command("apply")
def apply_command(
    source: Annotated[
        str,
        typer.Option("--source", "-s", help="Source environment (default: prod)"),
    ] = "prod",
    target: Annotated[
        str,
        typer.Option("--target", "-t", help="Target environment (default: dev)"),
    ] = "dev",
    indexes: Annotated[
        bool,
        typer.Option("--indexes", help="Apply all missing indexes"),
    ] = False,
    index: Annotated[
        list[str],
        typer.Option("--index", help="Apply specific index by name (repeatable)"),
    ] = [],
    constraints: Annotated[
        bool,
        typer.Option("--constraints", help="Apply all missing constraints"),
    ] = False,
    triggers: Annotated[
        bool,
        typer.Option("--triggers", help="Apply all missing triggers"),
    ] = False,
    matviews: Annotated[
        bool,
        typer.Option("--matviews", help="Apply all missing materialized views"),
    ] = False,
    sequences: Annotated[
        bool,
        typer.Option("--sequences", help="Apply all missing sequences"),
    ] = False,
    all_objects: Annotated[
        bool,
        typer.Option("--all", help="Apply all missing objects"),
    ] = False,
    concurrent: Annotated[
        bool,
        typer.Option("--concurrent", help="Use CONCURRENTLY for indexes (non-blocking)"),
    ] = False,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", "-n", help="Show DDL without executing"),
    ] = False,
    output: Annotated[
        Path | None,
        typer.Option("--output", "-o", help="Write DDL to file (implies --dry-run)"),
    ] = None,
    allow_prod_write: Annotated[
        bool,
        typer.Option("--allow-prod-write", help="Allow schema writes to production"),
    ] = False,
    yes: Annotated[
        bool,
        typer.Option("--yes", "-y", help="Skip confirmation prompt"),
    ] = False,
    schema: Annotated[
        str | None,
        typer.Option("--schema", help="Filter by schema name"),
    ] = None,
) -> None:
    """
    Apply missing schema objects from source to target environment.

    By default, syncs from prod to dev. Use --allow-prod-write for the reverse.

    Examples:
        cli sync apply --indexes                       # Apply all missing indexes to dev
        cli sync apply --index idx_clips_factory_h265  # Apply specific index
        cli sync apply --indexes --dry-run             # Show DDL without executing
        cli sync apply --indexes --output sync.sql     # Save DDL to file
        cli sync apply --all --yes                     # Apply everything without prompts
        cli sync apply --source dev --target prod --allow-prod-write  # Promote to prod
    """

    async def run() -> None:
        # If output specified, enable dry run
        nonlocal dry_run
        if output:
            dry_run = True

        # Validate direction
        validate_sync_direction(source, target, "schema", allow_prod_write)

        # Check that at least one type is selected
        if not any([indexes, index, constraints, triggers, matviews, sequences, all_objects]):
            error(
                "No object type specified. Use one of:\n"
                "  --indexes, --constraints, --triggers, --matviews, --sequences, --all\n"
                "  --index <name> for specific index"
            )
            raise typer.Exit(1)

        # Parse schemas
        schema_list = [schema] if schema else None

        # Compute diff
        info(f"Computing diff: {source} -> {target}...")
        diff = await compute_diff(
            source_env=source,
            target_env=target,
            schemas=schema_list,
            include_indexes=indexes or all_objects or bool(index),
            include_constraints=constraints or all_objects,
            include_triggers=triggers or all_objects,
            include_matviews=matviews or all_objects,
            include_sequences=sequences or all_objects,
        )

        # Collect objects to apply
        objects_to_apply: list[Any] = []
        ddl_statements: list[str] = []

        # Handle indexes
        if indexes or all_objects:
            for idx in diff.indexes_missing_in_target:
                objects_to_apply.append(idx)
                if concurrent:
                    ddl_statements.append(generate_index_ddl_concurrent(idx))
                else:
                    ddl_statements.append(generate_index_ddl(idx))

        # Handle specific indexes by name
        if index:
            for idx_name in index:
                found = False
                for idx in diff.indexes_missing_in_target:
                    if idx.index_name == idx_name:
                        if idx not in objects_to_apply:
                            objects_to_apply.append(idx)
                            if concurrent:
                                ddl_statements.append(generate_index_ddl_concurrent(idx))
                            else:
                                ddl_statements.append(generate_index_ddl(idx))
                        found = True
                        break
                if not found:
                    warning(f"Index not found in diff: {idx_name}")

        # Handle constraints
        if constraints or all_objects:
            for c in diff.constraints_missing:
                objects_to_apply.append(c)
                ddl_statements.append(generate_add_constraint_ddl(c))

        # Handle triggers
        if triggers or all_objects:
            for t in diff.triggers_missing:
                objects_to_apply.append(t)
                ddl_statements.append(generate_trigger_ddl(t))

        # Handle materialized views
        if matviews or all_objects:
            for mv in diff.matviews_missing:
                objects_to_apply.append(mv)
                ddl_statements.append(generate_matview_ddl(mv))

        # Handle sequences
        if sequences or all_objects:
            for seq in diff.sequences_missing:
                objects_to_apply.append(seq)
                ddl_statements.append(generate_sequence_ddl(seq))

        # Check if anything to apply
        if not objects_to_apply:
            success(f"No objects to apply. {target} is in sync with {source}.")
            return

        console.print()

        # Show preview
        show_apply_preview(objects_to_apply, target, ddl_statements)
        console.print()

        # Dry run: show DDL
        if dry_run:
            info("DDL statements (dry run):")
            console.print()

            for stmt in ddl_statements:
                syntax = Syntax(stmt, "sql", theme="monokai", line_numbers=False)
                console.print(syntax)
                console.print()

            if output:
                output.write_text("\n\n".join(ddl_statements))
                success(f"DDL written to {output}")

            return

        # Confirmation
        if not confirm_apply(objects_to_apply, target, yes):
            info("Cancelled.")
            raise typer.Exit(0)

        # Execute
        info(f"Applying {len(objects_to_apply)} object(s) to {target}...")
        target_settings = switch_environment(target)

        succeeded = 0
        failed = 0

        async with get_connection(target_settings) as conn:
            for i, (obj, stmt) in enumerate(zip(objects_to_apply, ddl_statements)):
                obj_name = getattr(obj, "full_name", str(obj))
                try:
                    await conn.execute(stmt)
                    success(f"[{i + 1}/{len(objects_to_apply)}] Applied: {obj_name}")
                    succeeded += 1
                except Exception as e:
                    error(f"[{i + 1}/{len(objects_to_apply)}] Failed {obj_name}: {e}")
                    failed += 1

        console.print()
        if failed == 0:
            success(f"All {succeeded} object(s) applied successfully.")
        else:
            warning(f"Completed with errors: {succeeded} succeeded, {failed} failed.")

    if not dry_run and output is None:
        require_write(typer.get_current_context(), "Schema sync apply")

    asyncio.run(run())
