"""Sync data command - copy data subsets from prod to dev."""

import asyncio
from dataclasses import dataclass, field

import asyncpg
import typer
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table
from typing_extensions import Annotated

from cli.commands.sync.apply import validate_sync_direction
from cli.console import console, error, info, success, warning
from cli.guard import require_write
from cli.context import get_connection
from infra.settings import switch_environment


# =============================================================================
# Table dependency ordering
# =============================================================================

# Tables ordered by dependency level (parents before children)
# This ensures referential integrity during TRUNCATE CASCADE and COPY
TABLE_DEPENDENCY_ORDER = [
    # Level 0: No dependencies (root tables)
    "observations.embedding_spaces",
    "operations.device_models",
    "operations.organizations",
    "core.asset_types",
    # Level 1: Depends on Level 0
    "core.factories",
    "operations.devices",
    # Level 2: Depends on Level 1
    "core.workers",
    # Level 3: Depends on Level 2
    "core.sessions",
    # Level 4: Depends on Level 3
    "core.streams",
    # Level 5: Depends on Level 4
    "core.clips",
    # Level 6: Depends on Level 5
    "core.frames",
    "core.assets",
    "observations.clip_descriptions",
    # Level 6.5: Embedding spaces (new architecture - space-centric tables)
    "observations.embedding_spaces",
    "observations.emb_siglip2_ego100k_frame_default",
    "observations.emb_qwen_holistic_v0",
    "observations.emb_qwen_holistic_v1",
    "observations.emb_qwen_tool",
    "observations.emb_qwen_productivity",
    "observations.emb_qwen_workspace",
    "observations.emb_qwen_industry",
    "observations.emb_gemini_task_name",
    "observations.emb_gemini_task_description",
    "observations.emb_gemini_process_description",
    "observations.emb_gemini_tools_description",
    "observations.emb_gemini_objects_description",
    "observations.emb_gemini_dexterity_description",
    "observations.emb_gemini_environment_description",
    "observations.emb_gemini_additional_observations",
    # Level 7: Depends on clips
    "observations.freeze_segments",
    "observations.cycle_segments",
    "observations.session_boundaries",
    # Projection/clustering (depends on embeddings - new architecture)
    "observations.projections",
    "observations.projection_points",
    "observations.clustering_runs",
    "observations.cluster_assignments",
    "observations.cluster_labels",
    "observations.medoids",
    # Collections (depends on clips)
    "collections.collections",
    "collections.collection_items",
    "collections.collection_mappings",
    "collections.webdataset_shards",
    "collections.webdataset_shard_clips",
    # Grids
    "collections.grids",
    "collections.grid_clip_positions",
    "collections.grid_lods",
    "collections.grid_rows",
    "collections.grid_tiles",
]

# Tables that require factory_uuid filter
FACTORY_FILTERABLE_TABLES = {
    "core.clips": "factory_uuid",
    "core.workers": "factory_uuid",
    "core.sessions": "factory_uuid",
    "core.streams": "factory_uuid",
}

# Tables with entity_id foreign key (filter via frame subquery)
FRAME_DEPENDENT_TABLES = [
    "observations.emb_siglip2_ego100k_frame_default",
]

# Tables with clip_id foreign key (filter via clip subquery)
CLIP_DEPENDENT_TABLES = [
    "core.frames",
    "core.assets",
    "observations.emb_qwen_holistic_v1",
    "observations.clip_descriptions",
    "observations.freeze_segments",
    "observations.cycle_segments",
    "observations.session_boundaries",
]


@dataclass
class CopyPlan:
    """Plan for copying data from source to target."""

    source_env: str
    target_env: str
    tables: list[str]
    factory_uuid: str | None = None
    limit: int | None = None
    truncate: bool = True
    include_embeddings: bool = False
    row_counts: dict[str, int] = field(default_factory=dict)


async def get_table_row_count(
    conn: asyncpg.Connection,
    table: str,
    where_clause: str | None = None,
) -> int:
    """Get row count for a table with optional filter."""
    query = f"SELECT COUNT(*) FROM {table}"
    if where_clause:
        query += f" WHERE {where_clause}"
    result = await conn.fetchval(query)
    return result or 0


async def copy_table_data(
    source_conn: asyncpg.Connection,
    target_conn: asyncpg.Connection,
    table: str,
    where_clause: str | None = None,
    limit: int | None = None,
    truncate: bool = True,
) -> int:
    """
    Copy data from source to target table.

    Args:
        source_conn: Source database connection
        target_conn: Target database connection
        table: Fully qualified table name (schema.table)
        where_clause: Optional WHERE clause for filtering
        limit: Maximum rows to copy
        truncate: Whether to truncate target table first

    Returns:
        Number of rows copied
    """
    schema_name, table_name = table.split(".")

    # Step 1: Truncate target (optional)
    if truncate:
        await target_conn.execute(f"TRUNCATE {table} CASCADE")

    # Step 2: Build query
    query = f"SELECT * FROM {table}"
    if where_clause:
        query += f" WHERE {where_clause}"
    if limit:
        query += f" LIMIT {limit}"

    # Step 3: Fetch from source
    rows = await source_conn.fetch(query)
    if not rows:
        return 0

    # Step 4: Insert into target using COPY protocol for efficiency
    columns = list(rows[0].keys())

    # Convert records to tuples for copy_records_to_table
    records = [tuple(row[col] for col in columns) for row in rows]

    await target_conn.copy_records_to_table(
        table_name,
        schema_name=schema_name,
        records=records,
        columns=columns,
    )

    return len(rows)


def build_factory_filter_plan(
    factory_uuid: str,
    limit: int | None = None,
    include_embeddings: bool = False,
) -> list[tuple[str, str | None]]:
    """
    Build a list of (table, where_clause) tuples for factory-filtered copy.

    Args:
        factory_uuid: Factory UUID to filter by
        limit: Row limit per table
        include_embeddings: Include embedding tables

    Returns:
        List of (table_name, where_clause) tuples in dependency order
    """
    plan: list[tuple[str, str | None]] = []

    # Embedding spaces (reference data, always copy all)
    plan.append(("observations.embedding_spaces", None))

    # Factory-specific core tables
    plan.append(("core.factories", f"uuid = '{factory_uuid}'"))
    plan.append(("core.workers", f"factory_uuid = '{factory_uuid}'"))
    plan.append(("core.sessions", f"factory_uuid = '{factory_uuid}'"))
    plan.append(("core.streams", f"factory_uuid = '{factory_uuid}'"))
    plan.append(("core.clips", f"factory_uuid = '{factory_uuid}'"))

    # Clip-dependent tables (filter by clips from factory)
    clip_subquery = f"clip_id IN (SELECT id FROM core.clips WHERE factory_uuid = '{factory_uuid}')"
    plan.append(("core.frames", clip_subquery))

    # Frame embeddings (if requested)
    if include_embeddings:
        frame_subquery = f"entity_id IN (SELECT id FROM core.frames WHERE {clip_subquery})"
        plan.append(("observations.emb_siglip2_ego100k_frame_default", frame_subquery))

    return plan


def show_copy_plan(plan: CopyPlan) -> None:
    """Display the copy plan as a table."""
    table = Table(title=f"Data Copy Plan: {plan.source_env} -> {plan.target_env}")
    table.add_column("Table", style="cyan")
    table.add_column("Source Rows", justify="right")
    table.add_column("Action", style="dim")

    for tbl in plan.tables:
        count = plan.row_counts.get(tbl, "?")
        action = "TRUNCATE + COPY" if plan.truncate else "COPY (append)"
        table.add_row(tbl, str(count), action)

    console.print(table)

    if plan.limit:
        console.print(f"\n[dim]Row limit: {plan.limit} per table[/dim]")
    if plan.factory_uuid:
        console.print(f"[dim]Factory filter: {plan.factory_uuid}[/dim]")


# Create the command
app = typer.Typer()


@app.command("data")
def data_command(
    source: Annotated[
        str,
        typer.Option("--source", "-s", help="Source environment (default: prod)"),
    ] = "prod",
    target: Annotated[
        str,
        typer.Option("--target", "-t", help="Target environment (default: dev)"),
    ] = "dev",
    factory: Annotated[
        str | None,
        typer.Option("--factory", "-f", help="Factory UUID to copy (with dependent data)"),
    ] = None,
    tables: Annotated[
        str | None,
        typer.Option("--tables", help="Comma-separated list of tables to copy"),
    ] = None,
    limit: Annotated[
        int | None,
        typer.Option("--limit", "-l", help="Maximum rows per table"),
    ] = None,
    no_truncate: Annotated[
        bool,
        typer.Option("--no-truncate", help="Don't truncate target tables (append mode)"),
    ] = False,
    include_embeddings: Annotated[
        bool,
        typer.Option("--include-embeddings", help="Include embedding tables (large!)"),
    ] = False,
    dry_run: Annotated[
        bool,
        typer.Option("--dry-run", "-n", help="Show plan without executing"),
    ] = False,
    yes: Annotated[
        bool,
        typer.Option("--yes", "-y", help="Skip confirmation prompt"),
    ] = False,
) -> None:
    """
    Copy data subsets from source to target environment.

    This is for populating dev with realistic data from prod.
    Production writes are BLOCKED - this is a one-way sync to dev only.

    Examples:
        cli sync data --factory abc123          # Copy factory and dependents
        cli sync data --factory abc123 --limit 1000  # Limit rows per table
        cli sync data --tables core.clips,core.frames  # Specific tables
        cli sync data --factory abc123 --dry-run  # Show plan only
        cli sync data --factory abc123 --include-embeddings  # Include large tables
    """

    async def run() -> None:
        # Validate direction - data writes to prod are ALWAYS blocked
        validate_sync_direction(source, target, "data", allow_prod_write=False)

        # Validate input
        if not factory and not tables:
            error(
                "Specify data to copy:\n"
                "  --factory <uuid>   Copy factory with all dependent data\n"
                "  --tables <list>    Copy specific tables (comma-separated)"
            )
            raise typer.Exit(1)

        # Build copy plan
        if factory:
            table_filters = build_factory_filter_plan(
                factory_uuid=factory,
                limit=limit,
                include_embeddings=include_embeddings,
            )
            table_list = [t for t, _ in table_filters]
        else:
            table_list = [t.strip() for t in tables.split(",")]
            table_filters = [(t, None) for t in table_list]

        plan = CopyPlan(
            source_env=source,
            target_env=target,
            tables=table_list,
            factory_uuid=factory,
            limit=limit,
            truncate=not no_truncate,
            include_embeddings=include_embeddings,
        )

        # Get source row counts
        info(f"Analyzing source data in {source}...")
        source_settings = switch_environment(source)

        async with get_connection(source_settings) as source_conn:
            for table, where_clause in table_filters:
                try:
                    count = await get_table_row_count(source_conn, table, where_clause)
                    plan.row_counts[table] = count
                except Exception as e:
                    warning(f"Could not count {table}: {e}")
                    plan.row_counts[table] = 0

        console.print()
        show_copy_plan(plan)
        console.print()

        # Dry run stops here
        if dry_run:
            info("Dry run complete. No data was copied.")
            return

        # Confirmation
        total_rows = sum(plan.row_counts.values())
        if not yes:
            if not typer.confirm(
                f"Copy ~{total_rows:,} rows to {target}?",
                default=False,
            ):
                info("Cancelled.")
                raise typer.Exit(0)

        # Execute copy
        info(f"Copying data from {source} to {target}...")
        console.print()

        target_settings = switch_environment(target)

        # Re-get source connection and target connection
        source_settings = switch_environment(source)

        copied_total = 0
        errors = 0

        async with get_connection(source_settings) as source_conn:
            async with get_connection(target_settings) as target_conn:
                with Progress(
                    SpinnerColumn(),
                    TextColumn("[progress.description]{task.description}"),
                    console=console,
                ) as progress:
                    for table, where_clause in table_filters:
                        task = progress.add_task(f"Copying {table}...", total=None)

                        try:
                            # Apply limit to where clause
                            effective_where = where_clause

                            copied = await copy_table_data(
                                source_conn=source_conn,
                                target_conn=target_conn,
                                table=table,
                                where_clause=effective_where,
                                limit=limit,
                                truncate=plan.truncate,
                            )
                            copied_total += copied
                            progress.update(
                                task,
                                description=f"[green]Copied {table}: {copied:,} rows[/green]",
                            )
                        except Exception as e:
                            progress.update(
                                task,
                                description=f"[red]Failed {table}: {e}[/red]",
                            )
                            errors += 1

                        progress.remove_task(task)

        console.print()
        if errors == 0:
            success(f"Copied {copied_total:,} rows across {len(table_list)} tables.")
        else:
            warning(f"Completed with {errors} error(s). Copied {copied_total:,} rows.")

    if not dry_run:
        require_write(typer.get_current_context(), "Data sync")

    asyncio.run(run())
