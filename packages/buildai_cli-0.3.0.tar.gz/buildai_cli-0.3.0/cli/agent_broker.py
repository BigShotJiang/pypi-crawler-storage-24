"""Agent token exchange and execution for CLI agent-attributed writes.

Follows the canonical flow from CLI-DASHBOARD-AGENT-EXECUTION-SPEC.md:

1. Authenticate human normally (via PAT)
2. Mint a short-lived agent_token from POST /v1/auth/agents/tokens
3. Execute the target write with the agent_token
4. Never persist the raw_token to disk, config, or shell history
"""

from __future__ import annotations

import os
import uuid
from dataclasses import dataclass
from typing import Any

import httpx

from cli.config import resolve_cli_api_key

_DEFAULT_BASE_URL = "https://api.build.ai"
_DEFAULT_AGENT_SUBJECT = "agent:cli-broker"
_TOKEN_EXPIRES_MINUTES = 15


@dataclass(frozen=True)
class AgentTokenInfo:
    """Issued agent token metadata (raw_token is ephemeral, never persisted)."""

    credential_id: str
    credential_public_id: str
    agent_subject: str
    acted_for_subject: str
    boundary_kind: str
    boundary_partner_id: str | None
    permissions: list[str]
    expires_at: str
    raw_token: str


@dataclass(frozen=True)
class ExecutionResult:
    """Result of an agent-attributed write."""

    ok: bool
    data: dict[str, Any] | None = None
    request_id: str | None = None
    error: str | None = None
    error_code: str | None = None
    status_code: int | None = None


def _base_url() -> str:
    return os.environ.get("BUILDAI_API_URL", _DEFAULT_BASE_URL)


def _get_api_key() -> str | None:
    return resolve_cli_api_key()


def _parse_api_error(response: httpx.Response) -> str:
    """Extract a human-readable error from an API error response."""
    try:
        body = response.json()
    except Exception:
        return f"HTTP {response.status_code}"

    if isinstance(body, dict):
        detail = body.get("detail")
        error = body.get("error")
        if isinstance(error, dict):
            msg = error.get("message")
            if isinstance(msg, str):
                return msg
        if isinstance(error, str):
            return error
        if isinstance(detail, str):
            return detail
    return f"HTTP {response.status_code}"


def exchange_agent_token(
    *,
    permissions: list[str],
    boundary_kind: str,
    boundary_partner_id: str | None = None,
    agent_subject: str | None = None,
    expires_in_minutes: int = _TOKEN_EXPIRES_MINUTES,
) -> AgentTokenInfo | str:
    """Exchange human PAT for a short-lived agent token.

    Returns AgentTokenInfo on success, or an error string on failure.
    """
    api_key = _get_api_key()
    if not api_key:
        return "No credential found. Set BUILDAI_TOKEN (or BUILDAI_API_KEY) or run: buildai login"

    base = _base_url()
    body = {
        "agent_subject": agent_subject or _DEFAULT_AGENT_SUBJECT,
        "permissions": permissions,
        "intended_surface": "cli",
        "boundary_kind": boundary_kind,
        "boundary_partner_id": boundary_partner_id,
        "expires_in_minutes": expires_in_minutes,
    }

    with httpx.Client(timeout=30) as client:
        response = client.post(
            f"{base}/v1/auth/agents/tokens",
            json=body,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
        )

    if not response.is_success:
        msg = _parse_api_error(response)
        if response.status_code == 404:
            return f"Agent not found: {msg}"
        if response.status_code == 403:
            return f"Permissions not issuable: {msg}"
        if response.status_code == 409:
            return f"Agent not active: {msg}"
        return f"Token exchange failed ({response.status_code}): {msg}"

    data = response.json().get("data", {})
    return AgentTokenInfo(
        credential_id=data.get("credential_id", ""),
        credential_public_id=data.get("credential_public_id", ""),
        agent_subject=data.get("agent_subject", ""),
        acted_for_subject=data.get("acted_for_subject", ""),
        boundary_kind=data.get("boundary_kind", ""),
        boundary_partner_id=data.get("boundary_partner_id"),
        permissions=data.get("permissions", []),
        expires_at=data.get("expires_at", ""),
        raw_token=data.get("raw_token", ""),
    )


def execute_update_inventory_devices(
    *,
    agent_token: str,
    partner_slug: str,
    target_inventory_devices: int | None = None,
) -> ExecutionResult:
    """Execute a partner inventory update using an agent token."""
    base = _base_url()
    idempotency_key = str(uuid.uuid4())

    payload: dict[str, Any] = {}
    if target_inventory_devices is not None:
        payload["target_inventory_devices"] = target_inventory_devices

    with httpx.Client(timeout=30) as client:
        response = client.patch(
            f"{base}/v1/partners/{partner_slug}/devices",
            json=payload,
            headers={
                "Authorization": f"Bearer {agent_token}",
                "Content-Type": "application/json",
                "X-Idempotency-Key": idempotency_key,
            },
        )

    if not response.is_success:
        msg = _parse_api_error(response)
        code = "write_failed"
        if response.status_code == 401:
            code = "token_expired"
        elif response.status_code == 409:
            code = "idempotency_conflict"
        return ExecutionResult(
            ok=False,
            error=msg,
            error_code=code,
            status_code=response.status_code,
        )

    body = response.json()
    data = body.get("data", body)
    request_id = body.get("request_id", "")

    return ExecutionResult(
        ok=True,
        data=data if isinstance(data, dict) else {},
        request_id=request_id,
    )
