"""Write-guard helpers for CLI commands."""

from __future__ import annotations

import typer

from cli.console import error


def require_write(ctx: typer.Context, action: str) -> None:
    """
    Enforce --write for mutating commands.

    Args:
        ctx: Typer context
        action: Short description of the mutation (for error messages)
    """
    ctx_obj = ctx.obj or {}
    allow_write = ctx_obj.get("allow_write", False)
    if not allow_write:
        error(f"{action} is a write operation. Re-run with --write.")
        raise typer.Exit(1)
    cli_profile = ctx_obj.get("cli_profile", "internal_viewer")
    if cli_profile != "internal_admin":
        error(f"{action} requires --profile internal_admin.")
        raise typer.Exit(1)
