"""Lazy SDK client initialization for CLI commands."""

from __future__ import annotations

import os

import typer

from cli.config import resolve_api_url, resolve_credential
from cli.console import error


def get_sdk_client(mode: str = "public"):
    """Get an initialized SDK client for the requested mode."""
    from buildai import Client

    try:
        api_key = resolve_credential()
    except RuntimeError as exc:
        error(str(exc))
        raise typer.Exit(1) from exc

    timeout = float(os.environ.get("BUILDAI_API_TIMEOUT", "300"))
    return Client(
        api_key=api_key,
        base_url=resolve_api_url(),
        mode=mode,
        timeout=timeout,
    )


def get_internal_sdk_client():
    """Get SDK client with internal-only resources enabled."""
    return get_sdk_client(mode="internal")
