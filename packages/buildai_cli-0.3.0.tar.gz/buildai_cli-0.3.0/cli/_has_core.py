"""Detect whether buildai-core is available."""

_cached: bool | None = None


def has_core() -> bool:
    global _cached
    if _cached is None:
        try:
            import infra  # noqa: F401

            _cached = True
        except ImportError:
            _cached = False
    return _cached


def require_core(command_name: str) -> None:
    if not has_core():
        import typer

        from cli.console import error

        error(
            f"'{command_name}' requires ops-plane deps.\n"
            f"  Install with: pip install 'buildai-cli[ops]'\n"
            f"  Or workspace: uv pip install -e 'apps/buildai-cli[ops]' -e core"
        )
        raise typer.Exit(1)
