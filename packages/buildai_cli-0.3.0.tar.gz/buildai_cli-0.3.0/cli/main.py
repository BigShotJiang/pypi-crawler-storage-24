#!/usr/bin/env python3
"""BuildAI CLI entry point."""

from __future__ import annotations

import shutil
import subprocess
import sys
from importlib.metadata import version as pkg_version

import typer
from dotenv import load_dotenv

from cli._has_core import has_core
from cli.commands.api_proxy import api
from cli.commands.assets_cli import app as assets_app
from cli.commands.auth_lite import login, logout, whoami
from cli.commands.clips import app as clips_app
from cli.commands.jobs import app as jobs_app
from cli.commands.predictions import app as predictions_app
from cli.commands.query_api import query
from cli.console import error, info, set_verbose, success, warning

load_dotenv()


def _current_version() -> str:
    try:
        return pkg_version("buildai-cli")
    except Exception:
        return "0.0.0"


def _latest_pypi_version() -> str | None:
    """Check PyPI for the latest buildai-cli version (non-blocking, 3s timeout)."""
    import json
    from urllib.request import urlopen

    try:
        with urlopen("https://pypi.org/pypi/buildai-cli/json", timeout=3) as resp:
            data = json.loads(resp.read())
            return data.get("info", {}).get("version")
    except Exception:
        return None


def _version_tuple(v: str) -> tuple[int, ...]:
    try:
        return tuple(int(x) for x in v.split("."))
    except ValueError:
        return (0, 0, 0)


def _check_update() -> None:
    """Print a warning if a newer version is available on PyPI."""
    current = _current_version()
    latest = _latest_pypi_version()
    if not latest:
        return
    if _version_tuple(latest) > _version_tuple(current):
        warning(f"Update available: {current} → {latest}")
        if shutil.which("brew") and "/homebrew/" in (shutil.which("buildai") or ""):
            info("  Run: brew upgrade buildai-cli")
        else:
            info("  Run: uv tool upgrade buildai-cli")


def _do_upgrade() -> None:
    """Force upgrade the CLI to the latest version."""
    current = _current_version()
    buildai_path = shutil.which("buildai") or ""

    if "/homebrew/" in buildai_path or "/Cellar/" in buildai_path:
        info(f"Current: {current}. Upgrading via Homebrew...")
        subprocess.run(["brew", "update"], check=False, capture_output=True)
        result = subprocess.run(["brew", "upgrade", "buildai-cli"], capture_output=True, text=True)
        if result.returncode == 0:
            success("Upgraded. Restart your terminal or run your command again.")
        else:
            error(f"Upgrade failed: {result.stderr.strip()}")
    elif shutil.which("uv"):
        info(f"Current: {current}. Upgrading via uv...")
        result = subprocess.run(
            ["uv", "tool", "upgrade", "buildai-cli"], capture_output=True, text=True
        )
        if result.returncode == 0:
            success("Upgraded. Run your command again.")
        else:
            error(f"Upgrade failed: {result.stderr.strip()}")
    else:
        info(f"Current: {current}. Upgrading via pip...")
        subprocess.run([sys.executable, "-m", "pip", "install", "--upgrade", "buildai-cli"])


def _version_callback(value: bool) -> None:
    if value:
        v = _current_version()
        print(f"buildai-cli {v}")
        _check_update()
        raise typer.Exit()


def _empty_group(name: str, help_text: str) -> typer.Typer:
    group = typer.Typer(name=name, help=help_text, no_args_is_help=True)

    @group.callback()
    def _callback() -> None:
        return None

    return group


_HELP = """\
Build AI CLI — query data, inspect predictions, sign media URLs.

Get started:
  buildai login                         Authenticate (opens browser)
  buildai whoami                        Show your identity and permissions
  buildai query "SELECT count(*) FROM core.clips"

Output: table (terminal) or JSON (pipe). Override with -o json/jsonl/csv.
Upgrade: buildai upgrade
"""

app = typer.Typer(
    name="buildai",
    help=_HELP,
    no_args_is_help=True,
    rich_markup_mode="rich",
)


@app.callback()
def main_callback(
    verbose: bool = typer.Option(False, "--verbose", "-v"),
    version: bool | None = typer.Option(
        None,
        "--version",
        callback=_version_callback,
        is_eager=True,
        help="Show version and exit.",
    ),
) -> None:
    del version
    set_verbose(verbose)


@app.command("upgrade")
def upgrade() -> None:
    """Upgrade buildai-cli to the latest version."""
    _do_upgrade()


app.command("api")(api)
app.command("login")(login)
app.command("whoami")(whoami)
app.command("logout")(logout)
app.command("query")(query)

app.add_typer(clips_app, name="clips")
app.add_typer(_empty_group("factories", "List and inspect factories."), name="factories")
app.add_typer(
    _empty_group("workers", "List and inspect workers within a factory."),
    name="workers",
)
app.add_typer(_empty_group("sessions", "List recording sessions."), name="sessions")
app.add_typer(_empty_group("streams", "List video streams within a session."), name="streams")
app.add_typer(_empty_group("frames", "List extracted frames for a clip."), name="frames")
app.add_typer(assets_app, name="assets")
app.add_typer(predictions_app, name="predictions")
app.add_typer(jobs_app, name="jobs")
app.add_typer(_empty_group("search", "Semantic search across clips and frames."), name="search")
app.add_typer(_empty_group("schema", "Inspect database tables and columns."), name="schema")
app.add_typer(
    _empty_group("embeddings", "List embedding spaces and models."),
    name="embeddings",
)

admin_app = typer.Typer(
    name="admin",
    help="DB-direct ops commands (requires workspace install + gcloud IAM).",
    no_args_is_help=True,
)


@admin_app.callback()
def admin_callback(
    ctx: typer.Context,
    env: str = typer.Option("production", "--env", "-e", help="Target environment."),
    auth: str = typer.Option(None, "--auth", "-a", help="Auth method: iam or password."),
    user: str = typer.Option(None, "--user", "-u", help="Override database user."),
    profile: str = typer.Option("internal_admin", "--profile", "-p", help="CLI scope profile."),
    write: bool = typer.Option(False, "--write", help="Allow write operations."),
) -> None:
    """Set up ops-plane context for admin commands."""
    import os

    os.environ.setdefault("APP_ENV", env)
    ctx.ensure_object(dict)
    ctx.obj["cli_profile"] = profile
    ctx.obj["allow_write"] = write
    if auth:
        ctx.obj["auth_method"] = auth
    if user:
        ctx.obj["db_user"] = user


if has_core():
    from cli.commands.database import app as database_app
    from cli.commands.embed import app as embed_app
    from cli.commands.external import app as external_app
    from cli.commands.keys import app as keys_app
    from cli.commands.medoid import app as medoid_app
    from cli.commands.operations import app as operations_app
    from cli.commands.partners import app as partners_app
    from cli.commands.permissions import app as permissions_app
    from cli.commands.projection import app as projection_app
    from cli.commands.query import query as admin_query
    from cli.commands.schema import app as schema_app
    from cli.commands.stats import app as stats_app

    admin_app.command("query")(admin_query)
    admin_app.add_typer(operations_app, name="operations")
    admin_app.add_typer(partners_app, name="partners")
    admin_app.add_typer(keys_app, name="keys")
    admin_app.add_typer(stats_app, name="stats")
    admin_app.add_typer(schema_app, name="schema")
    admin_app.add_typer(embed_app, name="embeddings")
    admin_app.add_typer(database_app, name="database")
    admin_app.add_typer(external_app, name="external")
    admin_app.add_typer(permissions_app, name="permissions")
    admin_app.add_typer(projection_app, name="projection")
    admin_app.add_typer(medoid_app, name="medoid")

app.add_typer(admin_app, name="admin")


def main() -> None:
    app()
