#!/usr/bin/env python3
"""Stitchflow data-sync CLI (setup, run, daemon, status)."""

from __future__ import annotations

import asyncio
import json
import os
import pathlib
import platform
import shutil
import signal
import socket
import subprocess
import sys
from datetime import datetime, timezone
from typing import Any

from stitchflow_local_agent.common import config
from stitchflow_local_agent.common.browser import BrowserManager
from stitchflow_local_agent.common.daemon import (
    acquire_pid_file,
    release_pid_file,
)
from stitchflow_local_agent.common.logging import append_jsonl
from stitchflow_local_agent.sync.calendly.export import (
    CALENDLY_ADMIN_USERS_URL,
    CALENDLY_DOWNLOAD_DIR,
    EXPORT_LOG_PATH as CALENDLY_EXPORT_LOG_PATH,
    cleanup_old_csvs as cleanup_old_calendly_csvs,
    export_calendly_users,
)
from stitchflow_local_agent.sync.chatgpt.export import (
    CHATGPT_ADMIN_URL,
    CHATGPT_DOWNLOAD_DIR,
    EXPORT_LOG_PATH as CHATGPT_EXPORT_LOG_PATH,
    cleanup_old_csvs as cleanup_old_chatgpt_csvs,
    export_chatgpt_users,
)
from stitchflow_local_agent.sync.linear.export import (
    LINEAR_DOWNLOAD_DIR,
    LINEAR_MEMBERS_URL,
    EXPORT_LOG_PATH as LINEAR_EXPORT_LOG_PATH,
    cleanup_old_csvs as cleanup_old_linear_csvs,
    export_linear_users,
)
from stitchflow_local_agent.sync.stitchflow_upload import (
    get_sync_app_base_url,
    get_workspace_connections_url,
    upload_csv_to_stitchflow,
)

SYNC_LOG_PATH = config.LOGS_DIR / "data-sync.log"
AUDIT_LOG_PATH = config.LOGS_DIR / "data-sync-audit.jsonl"
DAEMON_LOG_PATH = config.LOGS_DIR / "data-sync-daemon.log"
PID_FILE_PATH = config.STITCHFLOW_HOME_DIR / "data-sync-daemon.pid"
SYNC_LOCK_PATH = config.STITCHFLOW_HOME_DIR / "data-sync.lock"
SYNC_CONFIG_DIR = config.STITCHFLOW_HOME_DIR / "sync"
SYNC_ENV_FILE = SYNC_CONFIG_DIR / "sync.env"
LAUNCHD_LABEL = "com.stitchflow.data-sync"

LAUNCHD_MAX_CHECK_INTERVAL_SECONDS = 14400  # 4 hours

_LAUNCHD_PLIST_TEMPLATE = """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>{label}</string>
  <key>ProgramArguments</key>
  <array>
    <string>/bin/zsh</string>
    <string>-lc</string>
    <string>[ -f "{sync_env}" ] &amp;&amp; source "{sync_env}"; "{python_bin}" -m stitchflow_local_agent.sync_cli run --if-needed &gt;&gt; "{sync_log}" 2&gt;&amp;1</string>
  </array>
  <key>StartInterval</key>
  <integer>{check_interval_seconds}</integer>
  <key>RunAtLoad</key>
  <true/>
  <key>StandardOutPath</key>
  <string>{stdout_log}</string>
  <key>StandardErrorPath</key>
  <string>{stderr_log}</string>
</dict>
</plist>
"""


def _format_interval(seconds: int) -> str:
    if seconds >= 3600:
        return f"{seconds}s ({seconds // 3600}h)"
    return f"{seconds}s ({seconds // 60}m)"


def _ensure_dirs() -> None:
    config.ensure_dirs()
    SYNC_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CALENDLY_DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    CHATGPT_DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    LINEAR_DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)


def _acquire_sync_lock() -> bool:
    """Acquire a file-based lock to prevent concurrent syncs.

    Returns False if another sync process is already running.
    """
    if SYNC_LOCK_PATH.exists():
        try:
            old_pid = int(SYNC_LOCK_PATH.read_text().strip())
            try:
                os.kill(old_pid, 0)
                print(f"Another sync is already running (pid {old_pid}). Skipping this run.")
                return False
            except OSError:
                pass  # stale lock from a dead process
        except (ValueError, OSError):
            pass
    SYNC_LOCK_PATH.parent.mkdir(parents=True, exist_ok=True)
    SYNC_LOCK_PATH.write_text(str(os.getpid()))
    return True


def _release_sync_lock() -> None:
    """Release the sync lock if owned by this process."""
    try:
        if SYNC_LOCK_PATH.exists():
            stored_pid = int(SYNC_LOCK_PATH.read_text().strip())
            if stored_pid == os.getpid():
                SYNC_LOCK_PATH.unlink(missing_ok=True)
    except (ValueError, OSError):
        pass


def _check_network(host: str = "dns.google", port: int = 443, timeout: float = 5.0) -> bool:
    """Quick connectivity check — can we reach a public DNS endpoint?"""
    try:
        conn = socket.create_connection((host, port), timeout=timeout)
        conn.close()
        return True
    except OSError:
        return False


def _per_app_last_success() -> dict[str, datetime | None]:
    """Return each sync app's most recent successful sync timestamp."""
    result: dict[str, datetime | None] = {k: None for k in SYNC_APP_REGISTRY}
    if not AUDIT_LOG_PATH.exists():
        return result
    try:
        lines = AUDIT_LOG_PATH.read_text().strip().splitlines()
        for line in reversed(lines):
            entry = json.loads(line)
            app = entry.get("app", "")
            if app in result and result[app] is None and entry.get("status") == "success":
                ts = entry.get("timestamp")
                if ts:
                    dt = datetime.fromisoformat(ts)
                    if dt.tzinfo is None:
                        dt = dt.replace(tzinfo=timezone.utc)
                    result[app] = dt
            if all(v is not None for v in result.values()):
                break
    except Exception:
        pass
    return result


def _last_successful_sync_time() -> datetime | None:
    """Return the oldest per-app last success time.

    If any app has never synced, returns None (sync is needed).
    Otherwise returns the oldest timestamp so that the overdue check
    triggers as soon as any single app is overdue.
    """
    per_app = _per_app_last_success()
    timestamps = list(per_app.values())
    if any(t is None for t in timestamps):
        return None
    return min(t for t in timestamps if t is not None)


def _is_sync_overdue() -> bool:
    """True if any app's last successful sync is older than the interval (or missing)."""
    oldest = _last_successful_sync_time()
    if oldest is None:
        return True
    age = (datetime.now(timezone.utc) - oldest).total_seconds()
    return age > config.SYNC_INTERVAL_SECONDS


def _load_sync_env_into_environ() -> None:
    """Load sync-specific env vars before config.init_config()."""
    if not SYNC_ENV_FILE.exists():
        return
    try:
        for raw_line in SYNC_ENV_FILE.read_text().splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("export "):
                line = line[len("export ") :]
            if "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = value
    except Exception as exc:
        print(f"WARNING: Could not load sync env file: {exc}")


def _normalize_app_url(url_value: str) -> str:
    value = (url_value or "").strip()
    if not value:
        return get_sync_app_base_url()
    if "://" not in value:
        value = f"https://{value}"
    return value.rstrip("/")


def _persist_sync_env(workspace_id: str, app_url: str) -> None:
    """Persist sync-specific config independent from agent.env."""
    SYNC_CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    lines = [
        f'export STITCHFLOW_WORKSPACE_ID="{workspace_id}"',
        f'export STITCHFLOW_SYNC_APP_URL="{app_url}"',
        f'export STITCHFLOW_SYNC_INTERVAL_SECONDS="{config.SYNC_INTERVAL_SECONDS}"',
    ]
    SYNC_ENV_FILE.write_text("\n".join(lines) + "\n")
    os.chmod(SYNC_ENV_FILE, 0o600)


def _prompt_sync_target() -> tuple[str, str]:
    workspace_default = config.WORKSPACE_ID.strip()
    while True:
        prompt = (
            f"  STITCHFLOW_WORKSPACE_ID [{workspace_default}]: "
            if workspace_default
            else "  STITCHFLOW_WORKSPACE_ID [required]: "
        )
        workspace_input = input(prompt).strip()
        workspace_id = (workspace_input or workspace_default).strip().strip("/")
        if workspace_id:
            break
        print("  STITCHFLOW_WORKSPACE_ID is required for data sync uploads.")

    app_url_default = get_sync_app_base_url()
    app_url_input = input(f"  STITCHFLOW_SYNC_APP_URL [{app_url_default}]: ").strip()
    app_url = _normalize_app_url(app_url_input or app_url_default)
    return workspace_id, app_url


def configure_target() -> None:
    """Update sync target URL/workspace without rerunning full setup."""
    _ensure_dirs()
    print("Configure sync target (Stitchflow URL + workspace)...")
    workspace_id, app_url = _prompt_sync_target()
    config.WORKSPACE_ID = workspace_id
    os.environ["STITCHFLOW_WORKSPACE_ID"] = workspace_id
    os.environ["STITCHFLOW_SYNC_APP_URL"] = app_url
    _persist_sync_env(workspace_id, app_url)
    print("\nSaved sync target configuration.")
    print(f"  Workspace ID:     {workspace_id}")
    print(f"  Stitchflow URL:   {app_url}")
    print(f"  Sync env file:    {SYNC_ENV_FILE}")
    print("\nRun 'stitchflow-sync setup' to refresh logins for this target if needed.")


def _auto_enable_scheduler() -> bool:
    """Auto-enable OS scheduler for data sync after setup."""
    if platform.system() == "Darwin":
        launchctl_bin = shutil.which("launchctl") or (
            "/bin/launchctl" if pathlib.Path("/bin/launchctl").exists() else None
        )
        if not launchctl_bin:
            print("\nWARNING: launchctl is not available on this macOS host.")
            print("  launchd is built into macOS and cannot be installed by stitchflow-sync.")
            print("  Ask IT to enable launchctl access or run foreground mode: stitchflow-sync daemon")
            return False

        plist_path = pathlib.Path.home() / "Library" / "LaunchAgents" / f"{LAUNCHD_LABEL}.plist"
        plist_path.parent.mkdir(parents=True, exist_ok=True)

        try:
            check_interval = min(config.SYNC_INTERVAL_SECONDS, LAUNCHD_MAX_CHECK_INTERVAL_SECONDS)
            content = _LAUNCHD_PLIST_TEMPLATE.format(
                label=LAUNCHD_LABEL,
                sync_env=SYNC_ENV_FILE,
                python_bin=sys.executable,
                sync_log=SYNC_LOG_PATH,
                check_interval_seconds=check_interval,
                stdout_log=config.LOGS_DIR / "data-sync.out.log",
                stderr_log=config.LOGS_DIR / "data-sync.err.log",
            )
            plist_path.write_text(content)

            # Reload if already present.
            subprocess.run([launchctl_bin, "unload", str(plist_path)], check=False, capture_output=True)
            subprocess.run([launchctl_bin, "load", str(plist_path)], check=True)

            print("\nAuto-enabled launchd scheduler for data sync.")
            print(f"  LaunchAgent: {plist_path}")
            print("  It runs in background automatically at login and every sync interval.")
            return True
        except Exception as exc:
            print(f"\nWARNING: Failed to auto-enable launchd scheduler: {exc}")
            return False

    if platform.system() == "Windows":
        root_dir = pathlib.Path(__file__).resolve().parent.parent
        script = root_dir / "windows" / "register-task-data-sync.ps1"
        if not script.exists():
            print("\nWARNING: Task Scheduler script not found; skipping auto scheduler install.")
            return False
        try:
            subprocess.run(
                [
                    "powershell",
                    "-NoProfile",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-File",
                    str(script),
                ],
                input="\n",
                text=True,
                check=True,
            )
            print("\nAuto-enabled Task Scheduler for data sync.")
            return True
        except Exception as exc:
            print(f"\nWARNING: Failed to auto-enable Task Scheduler: {exc}")
            print("  You can run windows/register-task-data-sync.ps1 manually.")
            return False

    print("\nScheduler auto-install is not implemented for this OS.")
    return False


def _print_scheduler_status() -> None:
    """Print OS scheduler status for data sync."""
    system = platform.system()
    if system == "Darwin":
        launchctl_bin = shutil.which("launchctl") or (
            "/bin/launchctl" if pathlib.Path("/bin/launchctl").exists() else None
        )
        if not launchctl_bin:
            print("Scheduler:           launchd unavailable (launchctl not found)")
            return
        try:
            result = subprocess.run(
                [launchctl_bin, "list", LAUNCHD_LABEL],
                capture_output=True,
                text=True,
                check=False,
            )
            if result.returncode == 0:
                print(f"Scheduler:           launchd loaded ({LAUNCHD_LABEL})")
            else:
                print(f"Scheduler:           launchd not loaded ({LAUNCHD_LABEL})")
        except Exception:
            print("Scheduler:           launchd status check failed")
        return

    if system == "Windows":
        print("Scheduler:           Task Scheduler (check task: StitchflowDataSync)")
        return

    print("Scheduler:           not configured for this OS")


def _send_system_notification(title: str, message: str) -> None:
    """Best-effort desktop notification across supported OSes."""
    system = platform.system()
    try:
        if system == "Darwin":
            safe_title = title.replace('"', '\\"')
            safe_msg = message.replace('"', '\\"')
            subprocess.run(
                ["osascript", "-e", f'display notification "{safe_msg}" with title "{safe_title}"'],
                check=False,
                capture_output=True,
            )
            return
        if system == "Linux" and shutil.which("notify-send"):
            subprocess.run(["notify-send", title, message], check=False, capture_output=True)
            return
        if system == "Windows":
            ps_script = (
                "Add-Type -AssemblyName System.Windows.Forms; "
                f"[System.Windows.Forms.MessageBox]::Show('{message}', '{title}') | Out-Null"
            )
            subprocess.run(
                ["powershell", "-NoProfile", "-Command", ps_script],
                check=False,
                capture_output=True,
            )
            return
    except Exception:
        pass


def _notify_sync_failure(app_name: str, reason: str) -> None:
    title = f"Stitchflow sync failed: {app_name}"
    message = (
        f"{app_name} data sync failed ({reason}). Please contact Stitchflow support, "
        "or re-login by running 'stitchflow-sync setup' (auth may be expired)."
    )
    _send_system_notification(title, message)


def _notify_sync_success(app_name: str) -> None:
    _send_system_notification(
        f"Stitchflow sync complete: {app_name}",
        f"{app_name} data synced successfully.",
    )


def _sync_app(
    app_name: str,
    export_fn: Any,
    cleanup_fn: Any,
    started_at: str,
    driver: Any,
    notify_failure: bool = True,
) -> bool:
    """Run export -> upload -> log for a single app. Returns True on success."""
    app_lower = app_name.lower()

    csv_path = export_fn(driver)
    if not csv_path:
        ended_at = datetime.now(timezone.utc).isoformat()
        append_jsonl(
            SYNC_LOG_PATH,
            {
                "started_at": started_at,
                "ended_at": ended_at,
                "status": "failed",
                "step": f"{app_lower}_export",
                "app": app_lower,
                "error": f"Failed to export CSV from {app_name}",
            },
        )
        append_jsonl(
            AUDIT_LOG_PATH,
            {
                "timestamp": ended_at,
                "app": app_lower,
                "status": "failed",
                "error": f"Failed to export CSV from {app_name}",
            },
        )
        if notify_failure:
            _notify_sync_failure(app_name, "export failed")
        return False

    upload_result = upload_csv_to_stitchflow(driver, csv_path, app_name=app_name)
    ended_at = datetime.now(timezone.utc).isoformat()

    if upload_result.get("status") == "connected":
        cleanup_fn()
        append_jsonl(
            SYNC_LOG_PATH,
            {
                "started_at": started_at,
                "ended_at": ended_at,
                "status": "success",
                "csv_path": csv_path,
                "app": app_lower,
            },
        )
        append_jsonl(
            AUDIT_LOG_PATH,
            {
                "timestamp": ended_at,
                "app": app_lower,
                "status": "success",
                "csv_uploaded": csv_path,
            },
        )
        print(f"\n{app_name} sync completed successfully")
        _notify_sync_success(app_name)
        return True

    error_msg = upload_result.get("error", "Unknown upload failure")
    append_jsonl(
        SYNC_LOG_PATH,
        {
            "started_at": started_at,
            "ended_at": ended_at,
            "status": "failed",
            "step": "stitchflow_upload",
            "csv_path": csv_path,
            "app": app_lower,
            "error": error_msg,
        },
    )
    append_jsonl(
        AUDIT_LOG_PATH,
        {
            "timestamp": ended_at,
            "app": app_lower,
            "status": "failed",
            "error": error_msg,
        },
    )
    if notify_failure:
        _notify_sync_failure(app_name, error_msg)
    print(f"\n{app_name} sync failed: {error_msg}")
    return False


# Registry of sync-capable apps: name -> (export_fn, cleanup_fn)
SYNC_APP_REGISTRY: dict[str, tuple[Any, Any]] = {
    "calendly": (export_calendly_users, cleanup_old_calendly_csvs),
    "chatgpt": (export_chatgpt_users, cleanup_old_chatgpt_csvs),
    "linear": (export_linear_users, cleanup_old_linear_csvs),
}

# Display names for each app key.
SYNC_APP_DISPLAY_NAMES: dict[str, str] = {
    "calendly": "Calendly",
    "chatgpt": "ChatGPT",
    "linear": "Linear",
}


def run_sync(app_filter: str | None = None) -> bool:
    """Execute a sync cycle.

    Acquires a file lock so only one sync can run at a time.
    Checks network connectivity before starting the browser.

    Args:
        app_filter: If set, sync only this app (case-insensitive).
                    If None, sync all configured apps.
    """
    if app_filter:
        app_key = app_filter.lower()
        if app_key not in SYNC_APP_REGISTRY:
            print(f"ERROR: Unknown app '{app_filter}'. Available: {', '.join(SYNC_APP_REGISTRY)}")
            return False
        apps_to_sync = [app_key]
    else:
        apps_to_sync = list(SYNC_APP_REGISTRY)

    if not _acquire_sync_lock():
        return True  # another sync is handling it; not a failure

    try:
        if not _check_network():
            print("Network is not available — sync skipped.")
            now = datetime.now(timezone.utc).isoformat()
            for ak in apps_to_sync:
                append_jsonl(
                    AUDIT_LOG_PATH,
                    {"timestamp": now, "app": ak, "status": "failed", "error": "Network unavailable"},
                )
            return False

        started_at = datetime.now(timezone.utc).isoformat()
        label = SYNC_APP_DISPLAY_NAMES.get(apps_to_sync[0], apps_to_sync[0]) if len(apps_to_sync) == 1 else "all apps"
        print(f"\n{'=' * 60}")
        print(f"Data sync started at {started_at} ({label})")
        print(f"{'=' * 60}")

        headless_apps = [a for a in apps_to_sync if a != "chatgpt"]
        headed_apps = [a for a in apps_to_sync if a == "chatgpt"]
        results: list[bool] = []

        if headless_apps:
            headless_names = ", ".join(SYNC_APP_DISPLAY_NAMES.get(a, a) for a in headless_apps)
            print(f"Running in headless mode: {headless_names}")
            _send_system_notification(
                "Stitchflow",
                f"Sync started in background for {headless_names}.",
            )

            mgr = BrowserManager()
            try:
                driver = mgr.initialize(
                    integration="sync-headless",
                    profile_dir=config.BROWSER_PROFILE_DIR,
                    headless=True,
                    download_dir=str(CALENDLY_DOWNLOAD_DIR),
                )

                for app_key in headless_apps:
                    export_fn, cleanup_fn = SYNC_APP_REGISTRY[app_key]
                    display_name = SYNC_APP_DISPLAY_NAMES.get(app_key, app_key)
                    results.append(
                        _sync_app(
                            display_name,
                            export_fn,
                            cleanup_fn,
                            started_at,
                            driver,
                            notify_failure=True,
                        )
                    )
            finally:
                mgr.shutdown()

        if headed_apps:
            print("Running ChatGPT in headed mode for stability.")
            mgr = BrowserManager()
            try:
                driver = mgr.initialize(
                    integration="sync-chatgpt",
                    profile_dir=config.BROWSER_PROFILE_DIR,
                    headless=False,
                    download_dir=str(CALENDLY_DOWNLOAD_DIR),
                )

                for app_key in headed_apps:
                    export_fn, cleanup_fn = SYNC_APP_REGISTRY[app_key]
                    display_name = SYNC_APP_DISPLAY_NAMES.get(app_key, app_key)
                    results.append(
                        _sync_app(
                            display_name,
                            export_fn,
                            cleanup_fn,
                            started_at,
                            driver,
                            notify_failure=True,
                        )
                    )
            finally:
                mgr.shutdown()

        all_ok = all(results)
        print(f"\nSync cycle finished — {sum(results)}/{len(results)} succeeded")
        return all_ok
    finally:
        _release_sync_lock()


async def run_daemon() -> None:
    if not config.WORKSPACE_ID:
        print("ERROR: STITCHFLOW_WORKSPACE_ID not set. Run 'stitchflow-sync setup'.")
        sys.exit(1)
    if not acquire_pid_file(PID_FILE_PATH):
        sys.exit(1)
    _ensure_dirs()

    loop = asyncio.get_running_loop()
    shutdown_event = asyncio.Event()

    def _handle_sigterm() -> None:
        print("\nReceived shutdown signal, stopping daemon...")
        shutdown_event.set()

    loop.add_signal_handler(signal.SIGTERM, _handle_sigterm)
    loop.add_signal_handler(signal.SIGINT, _handle_sigterm)

    interval_label = _format_interval(config.SYNC_INTERVAL_SECONDS)
    retry_label = _format_interval(config.SYNC_RETRY_INTERVAL_SECONDS)
    print(f"Sync daemon started (interval: {interval_label}, retry: {retry_label}). Press Ctrl+C to stop.")
    cycle = 0
    try:
        while not shutdown_event.is_set():
            cycle += 1
            print(f"\n-- sync cycle {cycle} --")
            success = False
            try:
                success = await asyncio.to_thread(run_sync)
            except Exception as exc:
                print(f"Sync cycle error: {exc}")

            if success:
                sleep_time = config.SYNC_INTERVAL_SECONDS
            else:
                sleep_time = config.SYNC_RETRY_INTERVAL_SECONDS
                print(f"Sync failed — retrying in {retry_label} instead of {interval_label}")

            print(f"Sleeping {_format_interval(sleep_time)} until next sync...")
            try:
                await asyncio.wait_for(shutdown_event.wait(), timeout=sleep_time)
            except asyncio.TimeoutError:
                pass
        print("Daemon stopped.")
    finally:
        release_pid_file(PID_FILE_PATH)


def run_once(app_filter: str | None = None) -> None:
    if not config.WORKSPACE_ID:
        print("ERROR: STITCHFLOW_WORKSPACE_ID not set. Run 'stitchflow-sync setup'.")
        sys.exit(1)
    _ensure_dirs()
    success = run_sync(app_filter=app_filter)
    sys.exit(0 if success else 1)


def run_if_needed(app_filter: str | None = None) -> None:
    """Run sync only when the last successful sync is older than the interval.

    Used by the OS scheduler (launchd / Task Scheduler) which fires more
    frequently than the actual sync interval to catch up after missed runs.
    """
    if not config.WORKSPACE_ID:
        print("ERROR: STITCHFLOW_WORKSPACE_ID not set. Run 'stitchflow-sync setup'.")
        sys.exit(1)
    _ensure_dirs()

    if not _is_sync_overdue():
        oldest = _last_successful_sync_time()
        age_s = int((datetime.now(timezone.utc) - oldest).total_seconds()) if oldest else 0
        print(
            f"Sync not needed — oldest per-app success was {_format_interval(age_s)} ago "
            f"(interval: {_format_interval(config.SYNC_INTERVAL_SECONDS)})."
        )
        sys.exit(0)

    now = datetime.now(timezone.utc)
    per_app = _per_app_last_success()
    overdue = [
        app for app, ts in per_app.items() if ts is None or (now - ts).total_seconds() > config.SYNC_INTERVAL_SECONDS
    ]
    print(f"Sync is overdue for: {', '.join(overdue) or 'all apps'} — running now.")
    success = run_sync(app_filter=app_filter)
    sys.exit(0 if success else 1)


def setup() -> None:
    print("Running data sync setup...")
    _ensure_dirs()
    workspace_id, app_url = _prompt_sync_target()

    config.WORKSPACE_ID = workspace_id
    os.environ["STITCHFLOW_WORKSPACE_ID"] = workspace_id
    os.environ["STITCHFLOW_SYNC_APP_URL"] = app_url
    _persist_sync_env(workspace_id, app_url)
    print(f"Saved sync config to: {SYNC_ENV_FILE}")

    mgr = BrowserManager()

    step = 1

    print(f"\nStep {step}: Log into Calendly")
    print("A browser will open. Please log into your Calendly admin account.")
    driver = mgr.initialize(integration="sync", profile_dir=config.BROWSER_PROFILE_DIR, headless=False)
    driver.get(CALENDLY_ADMIN_USERS_URL)
    input("Press Enter after you have logged into Calendly and see the admin users page...")
    step += 1

    print(f"\nStep {step}: Log into ChatGPT")
    print("The browser will navigate to the ChatGPT admin page. Please log in if needed.")
    print("(The account/workspace ID will be auto-discovered from the admin page.)")
    driver.get(CHATGPT_ADMIN_URL)
    input("Press Enter after you have logged into ChatGPT...")
    step += 1

    print(f"\nStep {step}: Log into Linear")
    print("The browser will navigate to the Linear members page. Please log in if needed.")
    driver.get(LINEAR_MEMBERS_URL)
    input("Press Enter after you have logged into Linear and see the members page...")
    step += 1

    print(f"\nStep {step}: Log into Stitchflow")
    workspace_connections_url = get_workspace_connections_url()
    print("The browser will now navigate to your selected Stitchflow workspace.")
    print(f"Target workspace URL: {workspace_connections_url}")
    driver.get(workspace_connections_url)
    input("Press Enter after you have logged into Stitchflow and see the connections page...")

    mgr.shutdown()
    scheduler_enabled = _auto_enable_scheduler()

    # Auto-install and launch the menu bar app on macOS.
    tray_enabled = False
    if platform.system() == "Darwin":
        try:
            from stitchflow_local_agent.tray.app import install_launchagent

            tray_enabled = install_launchagent()
        except Exception as exc:
            print(f"\nNote: Could not auto-start menu bar app: {exc}")
            print("  You can start it manually with: stitchflow-tray")

    print("\nSetup complete. Sessions saved to browser profile.")
    print(f"  Profile:         {config.BROWSER_PROFILE_DIR}")
    print(f"  Sync env file:   {SYNC_ENV_FILE}")
    print(f"  Stitchflow URL:  {get_sync_app_base_url()}")
    print(f"  Workspace ID:    {config.WORKSPACE_ID}")
    print(f"  Calendly CSVs:   {CALENDLY_DOWNLOAD_DIR}")
    print(f"  ChatGPT CSVs:    {CHATGPT_DOWNLOAD_DIR}")
    print(f"  Linear CSVs:     {LINEAR_DOWNLOAD_DIR}")
    print("\nRun 'stitchflow-sync run' for a one-time sync.")
    if scheduler_enabled:
        print("Background daily sync is enabled via the OS scheduler.")
    else:
        print("Background daily sync was not auto-enabled; run 'stitchflow-sync daemon' in foreground for now.")
    if tray_enabled:
        print("Menu bar app installed — look for the Stitchflow icon in your menu bar.")
    print("Use 'stitchflow-sync status' to verify daemon status and recent audit logs.")


def _print_export_log(log_path: pathlib.Path, label: str) -> None:
    """Print the last 5 entries from a JSONL export log."""
    if not log_path.exists():
        return
    try:
        lines = log_path.read_text().strip().splitlines()
        if not lines:
            return
        print(f"\n{label} (last 5 of {len(lines)}):")
        for line in lines[-5:]:
            entry = json.loads(line)
            ts = entry.get("timestamp", "?")
            st = entry.get("status", "?")
            if st == "success":
                csv_f = pathlib.Path(entry.get("csv_path", "")).name
                size = entry.get("csv_size_bytes", "?")
                extra = ""
                if entry.get("user_count"):
                    extra = f", {entry['user_count']} users"
                print(f"  [{ts}] {st} - {csv_f} ({size} bytes{extra})")
            else:
                err = entry.get("error", "unknown error")
                print(f"  [{ts}] {st} - {err}")
    except Exception:
        pass


def status() -> None:
    _ensure_dirs()
    print(f"Profile path:        {config.BROWSER_PROFILE_DIR}")
    print(f"Profile exists:      {config.BROWSER_PROFILE_DIR.exists()}")
    print(f"Stitchflow URL:      {get_sync_app_base_url()}")
    print(f"Workspace ID:        {config.WORKSPACE_ID or '(not set)'}")
    print(f"Sync env file:       {SYNC_ENV_FILE} (exists={SYNC_ENV_FILE.exists()})")
    print(f"ChatGPT account ID:  {config.CHATGPT_ACCOUNT_ID or '(auto-discovered)'}")
    print(f"Sync interval:       {_format_interval(config.SYNC_INTERVAL_SECONDS)}")
    print(f"Calendly CSV dir:    {CALENDLY_DOWNLOAD_DIR}")
    print(f"ChatGPT CSV dir:     {CHATGPT_DOWNLOAD_DIR}")
    print(f"Log file:            {SYNC_LOG_PATH}")
    print(f"Daemon log:          {DAEMON_LOG_PATH}")
    print(f"Audit log:           {AUDIT_LOG_PATH}")
    print(f"PID file:            {PID_FILE_PATH}")
    _print_scheduler_status()

    if SYNC_LOG_PATH.exists():
        try:
            lines = SYNC_LOG_PATH.read_text().strip().splitlines()
            if lines:
                last = json.loads(lines[-1])
                print("\nLast sync:")
                print(f"  App:       {last.get('app', 'unknown')}")
                print(f"  Status:    {last.get('status', 'unknown')}")
                print(f"  Started:   {last.get('started_at', 'unknown')}")
                print(f"  Ended:     {last.get('ended_at', 'unknown')}")
                if last.get("csv_path"):
                    print(f"  CSV:       {last['csv_path']}")
                if last.get("error"):
                    print(f"  Error:     {last['error']}")
        except Exception:
            pass

    _print_export_log(CALENDLY_EXPORT_LOG_PATH, "Calendly export log")
    _print_export_log(CHATGPT_EXPORT_LOG_PATH, "ChatGPT export log")
    _print_export_log(LINEAR_EXPORT_LOG_PATH, "Linear export log")

    if AUDIT_LOG_PATH.exists():
        try:
            lines = AUDIT_LOG_PATH.read_text().strip().splitlines()
            if lines:
                print(f"\nStitchflow upload audit (last 5 of {len(lines)}):")
                for line in lines[-5:]:
                    entry = json.loads(line)
                    ts = entry.get("timestamp", "?")
                    st = entry.get("status", "?")
                    app = entry.get("app", "?")
                    if st == "success":
                        csv_f = pathlib.Path(entry.get("csv_uploaded", "")).name
                        print(f"  [{ts}] {app} {st} - uploaded {csv_f}")
                    else:
                        err = entry.get("error", "unknown error")
                        print(f"  [{ts}] {app} {st} - {err}")
        except Exception:
            pass

    for label, directory, pattern in [
        ("Calendly", CALENDLY_DOWNLOAD_DIR, "calendly_users_*.csv"),
        ("ChatGPT", CHATGPT_DOWNLOAD_DIR, "chatgpt_users_*.csv"),
        ("Linear", LINEAR_DOWNLOAD_DIR, "linear_users_*.csv"),
    ]:
        csv_files = sorted(
            directory.glob(pattern),
            key=lambda f: f.stat().st_mtime,
            reverse=True,
        )
        if csv_files:
            print(f"\nRecent {label} CSVs ({len(csv_files)}):")
            for f in csv_files[:5]:
                print(f"  {f.name} ({f.stat().st_size} bytes)")

    if PID_FILE_PATH.exists():
        try:
            pid = int(PID_FILE_PATH.read_text().strip())
            try:
                os.kill(pid, 0)
                print(f"\nDaemon: running (pid {pid})")
            except OSError:
                print(f"\nDaemon: stale PID file (pid {pid} not running)")
        except (ValueError, OSError):
            print("\nDaemon: invalid PID file")
    else:
        print("\nDaemon: not running")
        print("  Note: this PID check reflects foreground daemon mode.")
        print("  If Scheduler shows loaded, background sync is still active via OS scheduler.")


def main() -> None:
    try:
        sys.stdout.reconfigure(line_buffering=True)  # type: ignore[attr-defined]
        sys.stderr.reconfigure(line_buffering=True)  # type: ignore[attr-defined]
    except Exception:
        pass

    _load_sync_env_into_environ()
    config.init_config()

    if len(sys.argv) < 2:
        print("Stitchflow Data Sync v0.1")
        print("Usage:")
        print("  stitchflow-sync setup              One-time login to Calendly, ChatGPT, Linear & Stitchflow")
        print("  stitchflow-sync target             Update Stitchflow URL and workspace ID")
        print("  stitchflow-sync run                Run a sync cycle for all apps")
        print("  stitchflow-sync run --app calendly  Sync a single app (calendly, chatgpt, linear)")
        print("  stitchflow-sync run --if-needed    Run only if last sync is older than the interval")
        print("  stitchflow-sync daemon             Start the daily sync daemon")
        print("  stitchflow-sync status             Show config and last sync info")
        return

    command = sys.argv[1]
    if command == "setup":
        setup()
    elif command == "target":
        configure_target()
    elif command == "run":
        app_filter = None
        if "--app" in sys.argv:
            idx = sys.argv.index("--app")
            if idx + 1 < len(sys.argv):
                app_filter = sys.argv[idx + 1]
            else:
                print(f"ERROR: --app requires a value. Available: {', '.join(SYNC_APP_REGISTRY)}")
                sys.exit(1)
        if "--if-needed" in sys.argv:
            run_if_needed(app_filter=app_filter)
        else:
            run_once(app_filter=app_filter)
    elif command == "daemon":
        try:
            asyncio.run(run_daemon())
        except KeyboardInterrupt:
            print("\nDaemon stopped.")
    elif command == "status":
        status()
    else:
        print(f"Unknown command: {command}")
        sys.exit(1)


if __name__ == "__main__":
    main()
