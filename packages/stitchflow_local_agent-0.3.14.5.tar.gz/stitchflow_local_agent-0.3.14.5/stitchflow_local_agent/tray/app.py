#!/usr/bin/env python3
"""Stitchflow menu bar (tray) app for macOS.

Provides an always-on status icon with per-app sync controls,
connection status, and quick access to agent operations.
"""

from __future__ import annotations

import atexit
import json
import os
import pathlib
import platform
import subprocess
import sys
import threading
import urllib.request
from datetime import datetime, timezone
from importlib.metadata import PackageNotFoundError, version as pkg_version
from typing import Any

import rumps

from stitchflow_local_agent.common import config

# ---------------------------------------------------------------------------
# Paths (mirror sync_cli / agent_cli)
# ---------------------------------------------------------------------------
SYNC_LOG_PATH = config.LOGS_DIR / "data-sync.log"
AUDIT_LOG_PATH = config.LOGS_DIR / "data-sync-audit.jsonl"
AGENT_AUDIT_LOG_PATH = config.LOGS_DIR / "audit.log"
AGENT_PID_PATH = config.STITCHFLOW_HOME_DIR / "agent-daemon.pid"
SYNC_PID_PATH = config.STITCHFLOW_HOME_DIR / "data-sync-daemon.pid"
SYNC_ENV_FILE = config.STITCHFLOW_HOME_DIR / "sync" / "sync.env"

EXPORT_LOGS: dict[str, pathlib.Path] = {
    "Calendly": config.LOGS_DIR / "calendly-export.jsonl",
    "ChatGPT": config.LOGS_DIR / "chatgpt-export.jsonl",
    "Linear": config.LOGS_DIR / "linear-export.jsonl",
}

ICON_PATH = pathlib.Path(__file__).parent / "resources" / "icon.png"
TRAY_PID_PATH = config.STITCHFLOW_HOME_DIR / "tray.pid"

LAUNCHD_TRAY_LABEL = "com.stitchflow.tray"
LAUNCHD_SYNC_LABEL = "com.stitchflow.data-sync"
LAUNCHD_AGENT_LABEL = "com.stitchflow.agent.daemon"

# How often the menu bar refreshes status (seconds).
STATUS_POLL_INTERVAL = 60

# All known sync-capable apps.
SYNC_APPS = ["Calendly", "ChatGPT", "Linear"]

# Sync is considered stale if older than the configured sync interval.
SYNC_STALE_THRESHOLD_SECONDS = config.SYNC_INTERVAL_SECONDS

# Error substrings that indicate an expired browser session.
SESSION_EXPIRED_MARKERS = (
    "session may have expired",
    "not on stitchflow",
    "login",
    "authenticate",
    "unauthorized",
    "403",
    "401",
)

# Number of recent audit entries to show inline in the menu.
RECENT_AUDIT_COUNT = 3


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _acquire_tray_lock() -> bool:
    """Write our PID to the lock file. Returns False if another tray is alive."""
    config.ensure_dirs()
    if TRAY_PID_PATH.exists():
        try:
            existing_pid = int(TRAY_PID_PATH.read_text().strip())
            os.kill(existing_pid, 0)
            # Process is alive -- another tray is running.
            return False
        except (ValueError, OSError):
            pass  # stale or invalid PID file
    TRAY_PID_PATH.write_text(str(os.getpid()))
    return True


def _release_tray_lock() -> None:
    """Remove the lock file if it belongs to us."""
    try:
        if TRAY_PID_PATH.exists():
            stored = int(TRAY_PID_PATH.read_text().strip())
            if stored == os.getpid():
                TRAY_PID_PATH.unlink(missing_ok=True)
    except (ValueError, OSError):
        pass


def _pid_running(pid_path: pathlib.Path) -> bool | None:
    """Check if a PID file points to a running process. None = no PID file."""
    if not pid_path.exists():
        return None
    try:
        pid = int(pid_path.read_text().strip())
        os.kill(pid, 0)
        return True
    except (ValueError, OSError):
        return False


def _launchd_loaded(label: str) -> bool:
    """Check if a launchd job is loaded."""
    try:
        result = subprocess.run(
            ["launchctl", "list", label],
            capture_output=True,
            text=True,
            check=False,
        )
        return result.returncode == 0
    except Exception:
        return False


def _last_sync_entry(app_name: str) -> dict[str, Any] | None:
    """Read the most recent audit log entry for an app."""
    if not AUDIT_LOG_PATH.exists():
        return None
    try:
        lines = AUDIT_LOG_PATH.read_text().strip().splitlines()
        for line in reversed(lines):
            entry = json.loads(line)
            if entry.get("app", "").lower() == app_name.lower():
                return entry
    except Exception:
        pass
    return None


def _last_export_entry(app_name: str) -> dict[str, Any] | None:
    """Read the most recent export log entry for an app."""
    log_path = EXPORT_LOGS.get(app_name)
    if not log_path or not log_path.exists():
        return None
    try:
        lines = log_path.read_text().strip().splitlines()
        if lines:
            return json.loads(lines[-1])
    except Exception:
        pass
    return None


def _recent_audit_entries(count: int = RECENT_AUDIT_COUNT) -> list[dict[str, Any]]:
    """Return the last N entries from the data-sync audit log."""
    if not AUDIT_LOG_PATH.exists():
        return []
    try:
        lines = AUDIT_LOG_PATH.read_text().strip().splitlines()
        entries = []
        for line in lines[-count:]:
            entries.append(json.loads(line))
        return entries
    except Exception:
        return []


def _format_audit_line(entry: dict[str, Any]) -> str:
    """Format a single audit log entry for display in the menu."""
    ts = entry.get("timestamp", "")
    app = entry.get("app", "?").capitalize()
    status = entry.get("status", "?")
    rel = _format_relative_time(ts) if ts else "?"

    if status == "success":
        csv_name = pathlib.Path(entry.get("csv_uploaded", "")).name
        return f"{app} synced {rel}" + (f" ({csv_name})" if csv_name else "")
    else:
        err = entry.get("error", "unknown")
        if len(err) > 40:
            err = err[:37] + "..."
        return f"{app} failed {rel} \u2014 {err}"


def _format_relative_time(iso_timestamp: str) -> str:
    """Convert an ISO timestamp to a human-readable relative time."""
    try:
        dt = datetime.fromisoformat(iso_timestamp)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        now = datetime.now(timezone.utc)
        delta = now - dt
        seconds = int(delta.total_seconds())
        if seconds < 60:
            return "just now"
        if seconds < 3600:
            mins = seconds // 60
            return f"{mins}m ago"
        if seconds < 86400:
            hours = seconds // 3600
            return f"{hours}h ago"
        days = seconds // 86400
        return f"{days}d ago"
    except Exception:
        return "unknown"


def _seconds_since(iso_timestamp: str | None) -> float | None:
    """Return seconds elapsed since an ISO timestamp, or None."""
    if not iso_timestamp:
        return None
    try:
        dt = datetime.fromisoformat(iso_timestamp)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return (datetime.now(timezone.utc) - dt).total_seconds()
    except Exception:
        return None


def _looks_like_session_error(error_msg: str | None) -> bool:
    """Check if an error message suggests an expired browser session."""
    if not error_msg:
        return False
    lower = error_msg.lower()
    return any(marker in lower for marker in SESSION_EXPIRED_MARKERS)


def _load_sync_env_overrides() -> dict[str, str]:
    """Parse sync.env and return key-value pairs to overlay on the environment.

    This ensures subprocess sync commands use the workspace ID and app URL
    from sync.env rather than inheriting stale values from the tray process.
    """
    overrides: dict[str, str] = {}
    if not SYNC_ENV_FILE.exists():
        return overrides
    try:
        for raw_line in SYNC_ENV_FILE.read_text().splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#"):
                continue
            if line.startswith("export "):
                line = line[len("export ") :]
            if "=" not in line:
                continue
            key, value = line.split("=", 1)
            key = key.strip()
            value = value.strip().strip('"').strip("'")
            if key:
                overrides[key] = value
    except Exception:
        pass
    return overrides


def _build_sync_env() -> dict[str, str]:
    """Build subprocess environment with sync.env values taking precedence."""
    env = dict(os.environ)
    env.update(_load_sync_env_overrides())
    return env


def _run_cli_background(
    args: list[str],
    callback: Any = None,
    env: dict[str, str] | None = None,
) -> None:
    """Run a CLI command in a background thread to avoid blocking the UI."""

    def _worker():
        try:
            subprocess.run(args, check=False, capture_output=True, env=env)
        except Exception:
            pass
        if callback:
            callback()

    t = threading.Thread(target=_worker, daemon=True)
    t.start()


PYPI_PACKAGE_NAME = "stitchflow-local-agent"
PYPI_JSON_URL = f"https://pypi.org/pypi/{PYPI_PACKAGE_NAME}/json"


def _get_installed_version() -> str:
    """Return the currently installed package version, or empty string."""
    try:
        return pkg_version(PYPI_PACKAGE_NAME)
    except PackageNotFoundError:
        return ""


def _fetch_latest_pypi_version() -> str:
    """Fetch the latest version from PyPI. Returns empty string on failure."""
    try:
        req = urllib.request.Request(PYPI_JSON_URL, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=5) as resp:
            data = json.loads(resp.read())
            return data.get("info", {}).get("version", "")
    except Exception:
        return ""


def _get_current_workspace_info() -> dict[str, str]:
    """Return current workspace config for display."""
    sync_overrides = _load_sync_env_overrides()
    info: dict[str, str] = {}
    info["workspace_id"] = config.WORKSPACE_ID or sync_overrides.get("STITCHFLOW_WORKSPACE_ID", "") or "(not set)"
    info["api_url"] = config.API_URL or "(not set)"
    info["sync_app_url"] = sync_overrides.get("STITCHFLOW_SYNC_APP_URL", "(default)")
    return info


# ---------------------------------------------------------------------------
# App status model
# ---------------------------------------------------------------------------


class AppStatus:
    """Holds the current status for a single connected app."""

    def __init__(self, name: str):
        self.name = name
        self.last_sync_time: str | None = None
        self.last_sync_status: str | None = None  # "success" | "failed"
        self.last_sync_error: str | None = None
        self.last_export_time: str | None = None
        self.needs_relogin: bool = False

    def refresh(self) -> None:
        audit = _last_sync_entry(self.name)
        if audit:
            self.last_sync_time = audit.get("timestamp")
            self.last_sync_status = audit.get("status")
            self.last_sync_error = audit.get("error")
            self.needs_relogin = _looks_like_session_error(self.last_sync_error)
        else:
            self.last_sync_error = None
            self.needs_relogin = False

        export = _last_export_entry(self.name)
        if export:
            self.last_export_time = export.get("timestamp")
            if export.get("status") == "failed" and not self.needs_relogin:
                self.needs_relogin = _looks_like_session_error(export.get("error"))

    @property
    def health(self) -> str:
        """Return 'green', 'yellow', or 'red' based on current state."""
        if self.needs_relogin:
            return "red"
        if self.last_sync_status == "failed":
            return "red"
        if self.last_sync_status == "success":
            age = _seconds_since(self.last_sync_time)
            if age is not None and age > SYNC_STALE_THRESHOLD_SECONDS:
                return "yellow"
            return "green"
        # Never synced.
        return "yellow"

    @property
    def status_icon(self) -> str:
        if self.needs_relogin:
            return "\U0001f511"  # key — needs re-login
        if self.last_sync_status == "success":
            age = _seconds_since(self.last_sync_time)
            if age is not None and age > SYNC_STALE_THRESHOLD_SECONDS:
                return "\u23f1\ufe0f"  # stopwatch — stale
            return "\u2705"  # green check
        if self.last_sync_status == "failed":
            return "\u274c"  # red X
        return "\u2014"  # em dash — never synced

    @property
    def subtitle(self) -> str:
        if self.needs_relogin:
            return "Re-login needed"
        if self.last_sync_status == "failed" and self.last_sync_error:
            # Show a truncated error.
            err = self.last_sync_error
            if len(err) > 50:
                err = err[:47] + "..."
            return f"Failed: {err}"
        if self.last_sync_time:
            rel = _format_relative_time(self.last_sync_time)
            return f"Last sync {rel}"
        return "Never synced"


# ---------------------------------------------------------------------------
# Main menu bar app
# ---------------------------------------------------------------------------


def _hide_dock_icon() -> None:
    """Hide the app from the Dock — menu bar only, like Kandji/Docker."""
    try:
        from AppKit import NSApplication, NSApplicationActivationPolicyAccessory

        NSApplication.sharedApplication().setActivationPolicy_(NSApplicationActivationPolicyAccessory)
    except ImportError:
        # AppKit unavailable — dock icon will remain visible but harmless.
        pass


class StitchflowTrayApp(rumps.App):
    """macOS menu bar app for Stitchflow local agent."""

    def __init__(self):
        _hide_dock_icon()
        icon_file = str(ICON_PATH) if ICON_PATH.exists() else None
        super().__init__(
            name="Stitchflow",
            title=None if icon_file else "SF",
            icon=icon_file,
            template=True,
            quit_button=None,
        )
        self.app_statuses: dict[str, AppStatus] = {}
        for app_name in SYNC_APPS:
            self.app_statuses[app_name] = AppStatus(app_name)

        self._syncing: set[str] = set()
        self._update_available: str | None = None
        self._is_updating: bool = False
        self._build_menu()

    # -- Menu construction ---------------------------------------------------

    def _build_menu(self) -> None:
        """Rebuild the full menu from current state."""
        self.menu.clear()

        # No-op callback to keep items styled as active (not greyed out).
        def _noop(_):
            pass

        # Header
        header = rumps.MenuItem("Stitchflow Agent", callback=_noop)
        self.menu.add(header)

        # Overall status
        agent_running = _launchd_loaded(LAUNCHD_AGENT_LABEL) or _pid_running(AGENT_PID_PATH)
        sync_running = _launchd_loaded(LAUNCHD_SYNC_LABEL) or _pid_running(SYNC_PID_PATH)

        if agent_running or sync_running:
            status_text = "\u25cf  Running"
        else:
            status_text = "\u25cb  Not running"
        status_item = rumps.MenuItem(status_text, callback=_noop)
        self.menu.add(status_item)

        # Workspace info line
        ws_info = _get_current_workspace_info()
        ws_label = f"Workspace: {ws_info['workspace_id']}"
        ws_item = rumps.MenuItem(ws_label, callback=_noop)
        self.menu.add(ws_item)

        # Update banner
        if self._is_updating:
            self.menu.add(rumps.MenuItem("Updating...", callback=_noop))
        elif self._update_available:
            update_label = f"Update Available (v{self._update_available})"
            self.menu.add(rumps.MenuItem(update_label, callback=self._on_update))

        self.menu.add(rumps.separator)

        # -- Apps section (each app is a submenu) ----------------------------
        apps_header = rumps.MenuItem("Your Apps", callback=_noop)
        self.menu.add(apps_header)

        any_needs_relogin = False

        for app_name, app_status in self.app_statuses.items():
            app_status.refresh()
            is_syncing = app_name in self._syncing

            if app_status.needs_relogin:
                any_needs_relogin = True

            app_label = f"{app_status.status_icon} {app_name} \u2014 {app_status.subtitle}"
            app_menu = rumps.MenuItem(app_label)

            if app_status.needs_relogin:
                app_menu.add(
                    rumps.MenuItem(
                        "Re-login",
                        callback=self._on_relogin,
                    )
                )
            elif is_syncing:
                syncing_item = rumps.MenuItem("Syncing...", callback=_noop)
                app_menu.add(syncing_item)
            else:
                app_menu.add(
                    rumps.MenuItem(
                        "Sync Now",
                        callback=self._make_sync_callback(app_name),
                    )
                )

            self.menu.add(app_menu)

        # -- Global actions --------------------------------------------------
        self.menu.add(rumps.MenuItem("Sync All Apps", callback=self._on_sync_all))
        self.menu.add(rumps.MenuItem("Run Agent Tasks (upcoming)"))

        self.menu.add(rumps.separator)

        # -- Recent Activity section -----------------------------------------
        activity_header = rumps.MenuItem("Recent Activity", callback=_noop)
        self.menu.add(activity_header)

        recent = _recent_audit_entries(RECENT_AUDIT_COUNT)
        if recent:
            for entry in reversed(recent):  # newest first
                line = _format_audit_line(entry)
                item = rumps.MenuItem(f"  {line}", callback=_noop)
                self.menu.add(item)
        else:
            no_activity = rumps.MenuItem("  No sync activity yet", callback=_noop)
            self.menu.add(no_activity)

        self.menu.add(rumps.MenuItem("  Data Sync Logs", callback=self._on_view_sync_logs))
        self.menu.add(rumps.MenuItem("  Actions Logs", callback=self._on_view_agent_logs))
        self.menu.add(rumps.MenuItem("  Open Logs Folder", callback=self._on_open_logs_folder))

        self.menu.add(rumps.separator)

        if any_needs_relogin:
            relogin_item = rumps.MenuItem(
                "Re-login needed \u2014 sessions expired",
                callback=self._on_relogin,
            )
            self.menu.add(relogin_item)
        else:
            self.menu.add(rumps.MenuItem("Re-login (browser)", callback=self._on_relogin))

        # -- Settings submenu ------------------------------------------------
        settings_menu = rumps.MenuItem("Settings")
        settings_menu.add(rumps.MenuItem("Change Workspace...", callback=self._on_change_workspace))
        settings_menu.add(rumps.MenuItem("Change Sync Target...", callback=self._on_change_sync_target))
        settings_menu.add(rumps.separator)
        settings_menu.add(rumps.MenuItem("Open Config Folder", callback=self._on_open_config))
        self.menu.add(settings_menu)

        self.menu.add(rumps.separator)

        self.menu.add(rumps.MenuItem("Uninstall Stitchflow Agent", callback=self._on_uninstall))

        self.menu.add(rumps.separator)
        self.menu.add(rumps.MenuItem("Refresh", callback=self._on_refresh))

    def _refresh_menu(self) -> None:
        """Refresh menu items with latest status."""
        self._build_menu()

    # -- Callbacks -----------------------------------------------------------

    def _make_sync_callback(self, app_name: str):
        """Create a per-app sync callback."""

        def _callback(sender):
            self._syncing.add(app_name)
            self._refresh_menu()
            rumps.notification(
                title="Stitchflow",
                subtitle=f"Syncing {app_name}...",
                message="This may take a minute.",
            )
            _run_cli_background(
                [sys.executable, "-m", "stitchflow_local_agent.sync_cli", "run", "--app", app_name.lower()],
                callback=lambda: self._on_sync_complete(app_name),
                env=_build_sync_env(),
            )

        return _callback

    def _on_sync_complete(self, app_name: str) -> None:
        self._syncing.discard(app_name)
        self.app_statuses[app_name].refresh()
        status = self.app_statuses[app_name]
        if status.needs_relogin:
            rumps.notification(
                title="Stitchflow",
                subtitle=f"{app_name}: re-login needed",
                message="Browser session expired. Click Re-login in the menu bar.",
            )
        elif status.last_sync_status == "success":
            rumps.notification(
                title="Stitchflow",
                subtitle=f"{app_name} sync complete",
                message=status.subtitle,
            )
        else:
            rumps.notification(
                title="Stitchflow",
                subtitle=f"{app_name} sync failed",
                message=status.last_sync_error or "Check logs for details.",
            )
        self._refresh_menu()

    def _on_sync_all(self, sender) -> None:
        for app_name in SYNC_APPS:
            self._syncing.add(app_name)
        self._refresh_menu()
        rumps.notification(
            title="Stitchflow",
            subtitle="Syncing all apps...",
            message="Running full sync cycle.",
        )
        _run_cli_background(
            [sys.executable, "-m", "stitchflow_local_agent.sync_cli", "run"],
            callback=self._on_sync_all_complete,
            env=_build_sync_env(),
        )

    def _on_sync_all_complete(self) -> None:
        self._syncing.clear()
        for s in self.app_statuses.values():
            s.refresh()
        successes = sum(1 for s in self.app_statuses.values() if s.last_sync_status == "success")
        relogins = sum(1 for s in self.app_statuses.values() if s.needs_relogin)
        msg = f"{successes}/{len(SYNC_APPS)} apps synced successfully."
        if relogins:
            msg += f" {relogins} app(s) need re-login."
        rumps.notification(
            title="Stitchflow",
            subtitle="Sync cycle complete",
            message=msg,
        )
        self._refresh_menu()

    def _on_run_agent(self, sender) -> None:
        rumps.notification(
            title="Stitchflow",
            subtitle="Running agent tasks...",
            message="Processing pending operations.",
        )
        _run_cli_background(
            [sys.executable, "-m", "stitchflow_local_agent.agent_cli", "run"],
            callback=lambda: rumps.notification("Stitchflow", "Agent run complete", "Check status for results."),
        )

    def _on_update(self, sender) -> None:
        """Run pip upgrade in background."""
        self._is_updating = True
        self._refresh_menu()
        rumps.notification("Stitchflow", "Updating...", "Installing latest version.")
        _run_cli_background(
            [sys.executable, "-m", "pip", "install", "--upgrade", PYPI_PACKAGE_NAME],
            callback=self._on_update_complete,
        )

    def _on_update_complete(self) -> None:
        self._is_updating = False
        self._update_available = None
        self.title = None
        rumps.notification(
            "Stitchflow",
            "Update complete",
            "Click Refresh to apply the new version.",
        )
        self._refresh_menu()

    def _on_relogin(self, sender) -> None:
        """Open browser for re-authentication. This needs a terminal."""
        try:
            subprocess.Popen(
                [
                    "osascript",
                    "-e",
                    f'tell app "Terminal" to do script "{sys.executable} -m stitchflow_local_agent.sync_cli setup"',
                ],
            )
        except Exception:
            rumps.notification(
                "Stitchflow",
                "Re-login",
                "Run 'stitchflow-sync setup' in a terminal to re-authenticate.",
            )

    def _on_change_workspace(self, sender) -> None:
        """Open Terminal to run stitchflow-sync target for workspace change."""
        try:
            subprocess.Popen(
                [
                    "osascript",
                    "-e",
                    f'tell app "Terminal" to do script "{sys.executable} -m stitchflow_local_agent.sync_cli target"',
                ],
            )
        except Exception:
            rumps.notification(
                "Stitchflow",
                "Workspace Setup",
                "Run 'stitchflow-sync target' in a terminal.",
            )

    def _on_change_sync_target(self, sender) -> None:
        """Open Terminal to run stitchflow-sync target for sync URL change."""
        try:
            subprocess.Popen(
                [
                    "osascript",
                    "-e",
                    f'tell app "Terminal" to do script "{sys.executable} -m stitchflow_local_agent.sync_cli target"',
                ],
            )
        except Exception:
            rumps.notification(
                "Stitchflow",
                "Sync Target",
                "Run 'stitchflow-sync target' in a terminal.",
            )

    def _on_view_sync_logs(self, sender) -> None:
        """Open the data-sync audit log, or the logs folder if it doesn't exist yet."""
        self._open_log_file(AUDIT_LOG_PATH)

    def _on_view_agent_logs(self, sender) -> None:
        """Open the agent actions audit log, or the logs folder if it doesn't exist yet."""
        self._open_log_file(AGENT_AUDIT_LOG_PATH)

    def _open_log_file(self, path: pathlib.Path) -> None:
        if path.exists():
            subprocess.Popen(["open", "-t", str(path)])
        else:
            config.LOGS_DIR.mkdir(parents=True, exist_ok=True)
            subprocess.Popen(["open", str(config.LOGS_DIR)])

    def _on_open_logs_folder(self, sender) -> None:
        subprocess.Popen(["open", str(config.LOGS_DIR)])

    def _on_open_config(self, sender) -> None:
        subprocess.Popen(["open", str(config.STITCHFLOW_HOME_DIR)])

    def _on_uninstall(self, sender) -> None:
        response = rumps.alert(
            title="Uninstall Stitchflow Agent",
            message=(
                "This will:\n"
                "- Stop and remove all launchd daemons\n"
                "- Remove the menu bar app from login items\n"
                "- Delete ~/.stitchflow configuration\n\n"
                "Browser profiles and exported CSVs will be preserved.\n\n"
                "Are you sure?"
            ),
            ok="Uninstall",
            cancel="Cancel",
        )
        if response == 1:  # OK pressed
            self._do_uninstall()

    def _do_uninstall(self) -> None:
        """Remove launchd jobs and config."""
        agents_dir = pathlib.Path.home() / "Library" / "LaunchAgents"

        for label in [LAUNCHD_AGENT_LABEL, LAUNCHD_SYNC_LABEL, LAUNCHD_TRAY_LABEL]:
            plist = agents_dir / f"{label}.plist"
            if plist.exists():
                subprocess.run(["launchctl", "unload", str(plist)], check=False, capture_output=True)
                plist.unlink(missing_ok=True)

        # Remove config but preserve browser profile and data
        for item in [
            config.LOCAL_ENV_FILE,
            config.CONNECTIONS_FILE,
            config.STITCHFLOW_HOME_DIR / "sync" / "sync.env",
            AGENT_PID_PATH,
            SYNC_PID_PATH,
            TRAY_PID_PATH,
        ]:
            if item.exists():
                item.unlink(missing_ok=True)

        rumps.notification(
            "Stitchflow",
            "Uninstalled",
            "Launchd daemons removed. You can re-run 'pip install ...' and 'stitchflow-agent setup' to reinstall.",
        )
        rumps.quit_application()

    def _on_refresh(self, sender) -> None:
        """Restart the tray app process via launchd KeepAlive."""
        rumps.quit_application()

    # -- Timer for periodic refresh ------------------------------------------

    def _check_for_update(self) -> None:
        """Check PyPI for a newer version (runs in background thread)."""
        current = _get_installed_version()
        latest = _fetch_latest_pypi_version()
        if current and latest and latest != current:
            self._update_available = latest
        else:
            self._update_available = None
        self.title = "\u2022" if self._update_available else None
        self._refresh_menu()

    @rumps.timer(STATUS_POLL_INTERVAL)
    def _poll_status(self, timer) -> None:
        """Periodically refresh app statuses and update the menu."""
        for s in self.app_statuses.values():
            s.refresh()
        self._refresh_menu()
        threading.Thread(target=self._check_for_update, daemon=True).start()


# ---------------------------------------------------------------------------
# LaunchAgent installer
# ---------------------------------------------------------------------------


def install_launchagent() -> bool:
    """Install a LaunchAgent to auto-start the menu bar app on login."""
    if platform.system() != "Darwin":
        print("LaunchAgent install is macOS only.")
        return False

    config.ensure_dirs()

    agents_dir = pathlib.Path.home() / "Library" / "LaunchAgents"
    agents_dir.mkdir(parents=True, exist_ok=True)
    plist_path = agents_dir / f"{LAUNCHD_TRAY_LABEL}.plist"

    plist_content = f"""\
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" \
"http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>{LAUNCHD_TRAY_LABEL}</string>
  <key>ProgramArguments</key>
  <array>
    <string>{sys.executable}</string>
    <string>-m</string>
    <string>stitchflow_local_agent.tray.app</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <true/>
  <key>StandardOutPath</key>
  <string>{config.LOGS_DIR}/tray.out.log</string>
  <key>StandardErrorPath</key>
  <string>{config.LOGS_DIR}/tray.err.log</string>
</dict>
</plist>
"""
    plist_path.write_text(plist_content)
    subprocess.run(["launchctl", "unload", str(plist_path)], check=False, capture_output=True)
    subprocess.run(["launchctl", "load", str(plist_path)], check=True)

    print("Menu bar app will auto-start on login.")
    print(f"  LaunchAgent: {plist_path}")
    return True


def uninstall_launchagent() -> bool:
    """Remove the tray LaunchAgent."""
    plist_path = pathlib.Path.home() / "Library" / "LaunchAgents" / f"{LAUNCHD_TRAY_LABEL}.plist"
    if plist_path.exists():
        subprocess.run(["launchctl", "unload", str(plist_path)], check=False, capture_output=True)
        plist_path.unlink(missing_ok=True)
        print("Menu bar LaunchAgent removed.")
        return True
    print("No tray LaunchAgent found.")
    return False


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """CLI entry point for stitchflow-tray."""
    config.init_config()

    if len(sys.argv) >= 2:
        command = sys.argv[1]
        if command == "install":
            install_launchagent()
            print("Menu bar app will be started by launchd.")
            return
        elif command == "uninstall":
            uninstall_launchagent()
            return
        elif command == "run":
            pass  # fall through to run
        else:
            print("Stitchflow Menu Bar App")
            print("Usage:")
            print("  stitchflow-tray           Launch the menu bar app")
            print("  stitchflow-tray install   Install LaunchAgent (auto-start on login) and launch")
            print("  stitchflow-tray uninstall Remove LaunchAgent")
            return

    if not _acquire_tray_lock():
        print("Another Stitchflow tray instance is already running. Exiting.")
        return
    atexit.register(_release_tray_lock)

    StitchflowTrayApp().run()


if __name__ == "__main__":
    main()
