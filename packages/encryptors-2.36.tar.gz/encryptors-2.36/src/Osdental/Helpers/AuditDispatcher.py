import asyncio
from typing import Dict, Any
from fastapi import Request
from Osdental.Models.AuditConfig import AuditConfig
from Osdental.Messaging import IMessageQueue
from Osdental.Graphql._Helpers._AuditHelper import AuditHelper
from Osdental.Models._Audit import Audit
from Osdental.Models.Response import Response
from Osdental.Shared.Enums.Constant import Constant
from Osdental.Shared.Logger import logger

class AuditDispatcher:

    def __init__(self, messaging: IMessageQueue, audit_config: AuditConfig, max_queue_size: int = 5000):
        self._messaging = messaging
        self._audit_config = audit_config
        self._queue = asyncio.Queue(maxsize=max_queue_size)
        self._worker_task = None

    # Se llama en startup
    def start(self):
        self._worker_task = asyncio.create_task(self._worker())

    # Se llama en shutdown
    async def stop(self):
        # Esperar a que la cola se vacíe
        await self._queue.join()

        # Enviar sentinel para cerrar worker
        await self._queue.put(None)

        # Esperar a que el worker termine
        if self._worker_task:
            await self._worker_task

    # Ultra rápido, no bloquea
    def dispatch(
        self, 
        request: Request, 
        request_payload: Dict[str, Any], 
        result: Response,
        audit_type: str = None
    ):
        try:
            payload = {
                "request": request,
                "request_payload": request_payload,
                "result": result,
                "audit_type": audit_type
            }

            self._queue.put_nowait(payload)

        except asyncio.QueueFull:
            logger.error("Audit queue full. Dropping message.")

    # Worker real
    async def _worker(self):        
        while True:
            payload = await self._queue.get()
            # Sentinel detectado → salir limpio
            if payload is None:
                self._queue.task_done()
                break

            try:
                await self._process(payload)
            except Exception:
                logger.exception("Audit processing failed")
            finally:
                self._queue.task_done()

    # Logica
    async def _process(self, payload: Dict[str, Any]):
        request = payload["request"]
        request_payload = payload["request_payload"]
        result = payload["result"]
        audit_type = payload["audit_type"]

        operation_name = request_payload.get("operation_name")
        if operation_name == 'UnknownOperation':
            logger.info("Skipping audit: no data in GraphQL response")
            return
        
        audit = Audit(
            audit_type=audit_type,
            request=request,
            audit_config=self._audit_config,
            operation_name=operation_name,
            full_name=request_payload.get("user", "Joe Doe"),
            payload=request_payload.get("variables")
        )
        request_audit_payload = await AuditHelper.build_request_payload(audit=audit)

        status_code = result.status
        message = result.message
        data = result.data
        error = result.error if result.error else message
        
        if audit_type == Constant.MESSAGE_LOG_INTERNAL:

            ERROR_PREFIXES = ("DB_ERROR", "DB_WARNING")

            is_error = status_code.upper().startswith(ERROR_PREFIXES)

        else:

            try:
                is_error = not (200 <= status_code < 300)
            except ValueError:
                is_error = True
    

        if is_error:
            payload = AuditHelper.build_final_payload(
                _type="ERROR",
                status_code=status_code,
                error=error
            )

            audit_message = request_audit_payload | payload

        else:
            payload = AuditHelper.build_final_payload(
                _type="RESPONSE",
                status_code=status_code,
                result=data
            )

            audit_message = request_audit_payload | payload
        
        await self._messaging.send_message(audit_message)
