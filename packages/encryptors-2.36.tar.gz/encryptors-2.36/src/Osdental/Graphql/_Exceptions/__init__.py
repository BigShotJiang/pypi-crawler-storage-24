from Osdental.Exception.ControlledException import OSDException

class AESKeyNotFound(OSDException):
    def __init__(
        self, 
        error: str = None
    ):
        super().__init__(error=error)