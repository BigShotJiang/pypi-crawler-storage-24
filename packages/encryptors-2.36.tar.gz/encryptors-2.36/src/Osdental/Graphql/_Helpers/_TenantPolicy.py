from typing import Dict, Any
from uuid import UUID
from graphql import OperationType
from starlette.datastructures import Headers
from Osdental.Encryptor.Aes import AES
from Osdental.Models.Token import AuthToken

class TenantPolicy:

    @staticmethod
    def resolve(
        token: AuthToken, 
        headers: Headers, 
        decrypted_payload: Dict[str, Any], 
        operation_type: str
    ) -> AuthToken:

        # Set original idExternalEnterprise
        token.base_id_external_enterprise = token.id_external_enterprise
        # SUPER ADMIN / OSDEL ADMIN -> UUID 0
        should_use_zero_uuid = (
            token.abbreviation.startswith(("SPAU", "OSDA")) 
            and operation_type == OperationType.QUERY
        )

        if should_use_zero_uuid:
            token.id_external_enterprise = str(UUID(int=0))
            return token

        # Marketing -> tomar dynamicClientId del header
        if token.abbreviation.startswith("OSDMK"):
            dynamic_client_id = headers.get("dynamicClientId")
            if dynamic_client_id:
                decrypted_mk_id = AES.decrypt(token.aes_key_auth, dynamic_client_id)
                token.id_external_enterprise = decrypted_mk_id
                token.mk_id_external_enterprise = decrypted_mk_id
                return token

        # If it comes by request, it is taken as priority
        external_enterprise_req = decrypted_payload.get("idExternalEnterprise")
        if external_enterprise_req and token:
            token.id_external_enterprise = external_enterprise_req

        return token