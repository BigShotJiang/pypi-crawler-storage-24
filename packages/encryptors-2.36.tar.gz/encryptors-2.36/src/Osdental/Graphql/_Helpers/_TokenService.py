from starlette.datastructures import Headers
from Osdental.Encryptor.Aes import AES
from Osdental.Encryptor.Jwt import JWT
from Osdental.Models.Token import AuthToken
from Osdental.Graphql._Helpers._ExtractAuthToken import ExtractAuthToken

class TokenService:

    def __init__(self, jwt_user_key: str, auth_validator):
        self.jwt_user_key = jwt_user_key
        self.auth_validator = auth_validator

    async def authenticate(self, headers: Headers, aes_user: str) -> AuthToken:
        encrypted_token = ExtractAuthToken.get_auth_token(headers)

        user_token = AES.decrypt(aes_user, encrypted_token)
        payload = JWT.extract_payload(user_token, self.jwt_user_key)
        token = AuthToken(**payload)

        # Validate via RPC
        paylod = {
            'idToken': token.id_token,
            'idUser': token.id_user
        }
        is_valid = await self.auth_validator.validate_auth_token(paylod)
        if not is_valid:
            raise ValueError("You are not authorized to access this portal.")

        return token