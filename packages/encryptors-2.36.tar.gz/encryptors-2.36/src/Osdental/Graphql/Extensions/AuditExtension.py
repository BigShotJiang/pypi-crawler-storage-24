import json
from graphql.pyutils import is_awaitable
from ariadne.types import Extension
from Osdental.Encryptor.Aes import AES
from Osdental.Graphql._Helpers._TenantPolicy import TenantPolicy
from Osdental.Rest.Context.RequestContext import (
    current_context,
    RequestContext
)
from Osdental.Graphql.Models import BaseGraphQLContext
from Osdental.Graphql._Exceptions import AESKeyNotFound
from Osdental.Shared.Enums.Constant import Constant

class AuditExtension(Extension):

    def request_started(self, context):
        request = context.request
        self._ctx_token = current_context.set(
            RequestContext(
                request=request,
                request_id=request.headers.get("x-request-id"),
                user=None
            )
        )

        self.errors = None
        self.request_payload = None
        self.result = None

    async def resolve(self, next_, root, info, **kwargs):

        if not self.request_payload:
            context: BaseGraphQLContext = info.context

            request = context.request
            self.request = request

            body = await request.json()
            headers = request.headers

            container = context.container
            token_service = container.token_service

            aes_auth = request.app.state.aes_auth
            aes_user = request.app.state.aes_user

            if not aes_auth:
                raise AESKeyNotFound("AES user key is missing.", "aes_auth")
            
            if not aes_user:
                raise AESKeyNotFound("AES authorization key is missing.", "aes_user")

            original_token = await token_service.authenticate(headers, aes_user)
            
            variables = body.get("variables") or {}
            encrypted_payload = variables.get("data")

            decrypted_payload = None

            if encrypted_payload:
                try:
                    decrypted_payload = AES.decrypt(aes_auth, encrypted_payload)

                    try:
                        decrypted_payload = json.loads(decrypted_payload)
                    except Exception:
                        pass

                except Exception:
                    decrypted_payload = None

            token = TenantPolicy.resolve(
                token=original_token,
                headers=request.headers,
                decrypted_payload=decrypted_payload,
                operation_type=info.operation.operation.value
            )
            
            self.request_payload = {
                "operation_type": info.operation.operation.value,
                "operation_name": body.get("operationName", "UnknownOperation"),
                "query": body.get("query"),
                "variables": decrypted_payload,
                "user": token.user_full_name
            }

            context.decrypted_payload = decrypted_payload
            context.token = token
            context.aes_auth = aes_auth

        result = next_(root, info, **kwargs)

        if is_awaitable(result):
            result = await result

        if root is None:
            self.result = result

        return result

    def has_errors(self, errors, context):
        self.errors = errors

    def request_finished(self, context):
        query = self.request_payload.get("query", "")
        if "__schema" in query or "__type" in query: return
    
        if not hasattr(context, "audit_plain_response"): return

        dispatcher = context.request.app.state.audit_dispatcher

        dispatcher.dispatch(
            request=self.request,
            request_payload=self.request_payload,
            result=context.audit_plain_response,
            audit_type=Constant.MESSAGE_LOG_INTERNAL
        )