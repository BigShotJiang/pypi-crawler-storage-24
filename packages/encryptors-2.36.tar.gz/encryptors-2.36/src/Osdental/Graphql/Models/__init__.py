from dataclasses import dataclass
from typing import Optional, Any
from fastapi import Request
from Osdental.Models.Token import AuthToken

@dataclass
class BaseGraphQLContext:
    request: Request
    container: Any
    # valores agregados durante ejecución (AuditExtention)
    token: Optional[AuthToken] = None
    decrypted_payload: Optional[dict] = None
    aes_auth: Optional[str] = None
    audit_plain_response: Optional[Any] = None