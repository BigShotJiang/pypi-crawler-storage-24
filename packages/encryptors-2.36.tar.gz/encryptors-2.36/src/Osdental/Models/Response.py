from dataclasses import dataclass, field, asdict
from typing import Optional, Any
from Osdental.Shared.Enums.Code import Code
from Osdental.Shared.Enums.Message import Message

@dataclass
class Response:
    status: Any = field(default=Code.PROCESS_SUCCESS_CODE)
    message: str = field(default=Message.PROCESS_SUCCESS_MSG)
    data: Optional[Any] = None
    error: Optional[str] = None

    def send(self):
        response = asdict(self)

        if response["error"] is None:
            response.pop("error")

        return response