import httpx
from typing import Optional, Dict, Any
from Osdental.Decorators.Retry import rest_retry
from Osdental.Rest.Context.RequestContext import current_context
from Osdental.Models.Response import Response
from Osdental.Http._Exceptions import HttpClientException
from Osdental.Shared.Enums.Constant import Constant
from Osdental.Shared.Logger import logger

class APIClient:

    def __init__(
        self,
        timeout: Optional[httpx.Timeout] = None,
        limits: Optional[httpx.Limits] = None
    ):
        self._client = httpx.AsyncClient(
            follow_redirects=True,
            timeout=timeout or httpx.Timeout(10.0, read=20.0),
            limits=limits or httpx.Limits(
                max_connections=100,
                max_keepalive_connections=20
            )
        )

    async def close(self):
        await self._client.aclose()

    @rest_retry
    async def _request(self, method: str, url: str, **kwargs) -> httpx.Response:

        try:

            response = await self._client.request(
                method,
                url,
                **kwargs
            )

            ctx = current_context.get()

            if ctx and ctx.request:
                request = ctx.request

                dispatcher = request.app.state.audit_dispatcher
                dispatcher.dispatch(
                    request=request,
                    request_payload={
                        "operation_name": "ExternalAPI",
                        "query": url,
                        "variables": kwargs.get("json") or kwargs.get("params")
                    },
                    result=Response(
                        status=response.status_code,
                        message="External API",
                        data=response.text
                    ),
                    audit_type=Constant.MESSAGE_LOG_EXTERNAL
                )

            response.raise_for_status()

            return response

        except httpx.HTTPStatusError as exc:

            raise HttpClientException(
                status_code=exc.response.status_code,
                message=exc.response.text
            ) from exc
        
        except httpx.RequestError as exc:

            raise HttpClientException(
                status_code=0,
                message=str(exc)
            ) from exc
        
    
    async def request(
        self,
        method: str,
        url: str,
        **kwargs
    ) -> Any:

        response = await self._request(
            method,
            url,
            **kwargs
        )

        content_type = response.headers.get(
            "content-type", ""
        ).lower()

        if "application/json" in content_type:
            return response.json()

        if "text/" in content_type or "xml" in content_type:
            return response.text

        return response.content
    

    async def execute(
        self,
        url: str,
        query: str,
        variables: Dict[str, Any],
        headers: Optional[Dict[str, str]] = None
    ) -> Dict[str, Any]:

        payload = {
            "query": query,
            "variables": variables
        }

        response = await self._request(
            "POST",
            url,
            json=payload,
            headers=headers or {}
        )

        data = response.json()

        if "errors" in data:

            logger.error(
                f"GraphQL error: {data['errors']}"
            )

            raise HttpClientException(
                message="GraphQL execution failed",
                error=str(data["errors"])
            )

        return data["data"]