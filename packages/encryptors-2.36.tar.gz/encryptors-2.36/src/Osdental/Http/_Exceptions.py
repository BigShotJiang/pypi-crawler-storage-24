from Osdental.Exception.ControlledException import OSDException
from Osdental.Shared.Enums.Code import Code
from Osdental.Shared.Enums.Message import Message

class HttpClientException(OSDException):
    def __init__(
        self, 
        message: str = Message.UNEXPECTED_ERROR_MSG, 
        error: str = None, 
        status_code: str = Code.HTTP_ERROR_CODE
    ):
        super().__init__(message=message, error=error, status_code=status_code)