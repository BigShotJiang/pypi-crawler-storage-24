__author__ = "ziyan.yin"
__date__ = "2026-01-13"

import functools
from typing import Any, Mapping, Sequence, Union

from fastapi import FastAPI, params
from fastapi._compat import (ModelField, get_cached_model_fields,
                             lenient_issubclass, shared)
from fastapi.dependencies import utils
from pydantic import BaseModel
from starlette import datastructures

from fastapi_extra import routing
from fastapi_extra.urlparse import parse_qsl


def install_routes(app: FastAPI) -> None:
    routing.install(app)


@functools.lru_cache
def is_sequence_field(annotation: type[Any]) -> bool:
    return shared.field_annotation_is_sequence(annotation)


def request_params_to_args(
    fields: Sequence[ModelField],
    received_params: Union[Mapping[str, Any], datastructures.QueryParams, datastructures.Headers],
) -> tuple[dict[str, Any], list[Any]]:
    values: dict[str, Any] = {}
    errors: list[dict[str, Any]] = []

    if not fields:
        return values, errors

    first_field = fields[0]
    fields_to_extract = fields
    single_not_embedded_field = False
    default_convert_underscores = True
    if len(fields) == 1 and lenient_issubclass(
        first_field.field_info.annotation, BaseModel
    ):
        fields_to_extract = get_cached_model_fields(first_field.field_info.annotation)
        single_not_embedded_field = True
        # If headers are in a Pydantic model, the way to disable convert_underscores
        # would be with Header(convert_underscores=False) at the Pydantic model level
        default_convert_underscores = getattr(
            first_field.field_info, "convert_underscores", True
        )

    params_to_process: dict[str, Any] = {}

    processed_keys = set()

    for field in fields_to_extract:
        alias = field_alias = utils.get_validation_alias(field)
        if isinstance(received_params, datastructures.Headers):
            # Handle fields extracted from a Pydantic Model for a header, each field
            # doesn't have a FieldInfo of type Header with the default convert_underscores=True
            convert_underscores = getattr(
                field.field_info, "convert_underscores", default_convert_underscores
            )
            if convert_underscores and alias == field.name:
                alias = alias.replace("_", "-")
        value = utils._get_multidict_value(field, received_params, alias=alias)
        if value is not None:
            params_to_process[field_alias] = value
        processed_keys.add(alias)

    for key in received_params.keys():
        if key not in processed_keys:
            if hasattr(received_params, "getlist"):
                value = received_params.getlist(key)
                if isinstance(value, list) and (len(value) == 1):
                    params_to_process[key] = value[0]
                else:
                    params_to_process[key] = value
            else:
                params_to_process[key] = received_params.get(key)

    if single_not_embedded_field:
        field_info = first_field.field_info
        assert isinstance(field_info, params.Param), (
            "Params must be subclasses of Param"
        )
        loc: tuple[str, ...] = (field_info.in_.value,)
        v_, errors_ = utils._validate_value_with_model_field(
            field=first_field, value=params_to_process, values=values, loc=loc
        )
        return {first_field.name: v_}, errors_

    for field in fields:
        field_alias = utils.get_validation_alias(field)
        value = params_to_process.get(field_alias, None)
        field_info = field.field_info
        assert isinstance(field_info, params.Param), (
            "Params must be subclasses of Param"
        )
        loc = (field_info.in_.value, field_alias)
        v_, errors_ = utils._validate_value_with_model_field(
            field=field, value=value, values=values, loc=loc
        )
        if errors_:
            errors.extend(errors_)
        else:
            values[field.name] = v_
    return values, errors


def query_params_init(obj: datastructures.QueryParams, *args, **kwargs) -> None:
    value = args[0] if args else []

    if isinstance(value, bytes):
        super(datastructures.QueryParams, obj).__init__(parse_qsl(value, keep_blank_values=True), **kwargs)
    elif isinstance(value, str):
        super(datastructures.QueryParams, obj).__init__(parse_qsl(value.encode("latin-1"), keep_blank_values=True), **kwargs)
    else:
        super(datastructures.QueryParams, obj).__init__(*args, **kwargs)  # type: ignore[arg-type]
        obj._list = [(str(k), str(v)) for k, v in obj._list]
        obj._dict = {str(k): str(v) for k, v in obj._dict.items()}
