"""Auto-generated stub for module: test_data_generators."""
from typing import Any, Dict, List, Tuple

# Functions
def create_basic_counting_tracking_scenarios() -> List[Dict[str, Any]]:
    """
    Create basic counting and tracking test scenarios.
    """
    ...
def create_configuration_variants() -> Dict[str, Dict[str, Any]]:
    """
    Create various configuration variants for testing.
    """
    ...
def create_customer_service_areas() -> Dict[str, Dict[str, List[List[int]]]]:
    """
    Create customer service area configurations.
    """
    ...
def create_customer_service_scenarios() -> List[Dict[str, Any]]:
    """
    Create customer service analysis test scenarios.
    """
    ...
def create_detection_results(num_detections: int = 10, categories: List[str] = None, confidence_range: Tuple[float, float] = (0.5, 0.95), bbox_size_range: Tuple[int, int] = (20, 100), image_size: Tuple[int, int] = (640, 480), include_metadata: bool = True) -> List[Dict[str, Any]]:
    """
    Create realistic detection results.
    """
    ...
def create_edge_case_data() -> Dict[str, List[Dict[str, Any]]]:
    """
    Create edge case test data.
    """
    ...
def create_line_crossing_data(lines: Dict[str, List[List[int]]], num_tracks: int = 5, frames: int = 20) -> List[Dict[str, Any]]:
    """
    Create tracking data that crosses specified lines.
    """
    ...
def create_multi_camera_data(num_cameras: int = 3) -> Dict[str, Any]:
    """
    Create multi-camera test data.
    """
    ...
def create_people_counting_scenarios() -> List[Dict[str, Any]]:
    """
    Create various people counting test scenarios.
    """
    ...
def create_performance_test_data(scale: str = 'medium') -> Dict[str, Any]:
    """
    Create performance test data at different scales.
    """
    ...
def create_result_format_variants() -> Dict[str, Dict[str, Any]]:
    """
    Create test data in different result formats.
    """
    ...
def create_temporal_data_series(duration_minutes: int = 60) -> List[Dict[str, Any]]:
    """
    Create temporal data series for time-based analysis.
    """
    ...
def create_tracking_results(num_tracks: int = 8, categories: List[str] = None, frames: int = 10, confidence_range: Tuple[float, float] = (0.6, 0.9), bbox_size_range: Tuple[int, int] = (30, 80), image_size: Tuple[int, int] = (640, 480), include_trajectory: bool = True) -> List[Dict[str, Any]]:
    """
    Create realistic tracking results.
    """
    ...
def create_zone_polygons(zone_names: List[str], image_size: Tuple[int, int] = (640, 480), zone_types: List[str] = None) -> Dict[str, List[List[int]]]:
    """
    Create zone polygon configurations.
    """
    ...
