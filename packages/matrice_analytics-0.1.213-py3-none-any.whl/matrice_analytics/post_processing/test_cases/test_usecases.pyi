"""Auto-generated stub for module: test_usecases."""
from typing import Any

# Functions
def main() -> Any: ...

# Classes
class UseCaseTestProcessor:
    # A flexible YOLO-based video processor for testing different post-processing use cases.

    def __init__(self: Any, file_name: Any, config_name: Any, usecase_name: Any, model_path: Any, video_path: Any, post_process: Any = None, max_frames: Any = None) -> None: ...

    def process_video(self: Any) -> Any:
        """
        Run YOLO inference on video and post-process frame by frame.
        """
        ...

