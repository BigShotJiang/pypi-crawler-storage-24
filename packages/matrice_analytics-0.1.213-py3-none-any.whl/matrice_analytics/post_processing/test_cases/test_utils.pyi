"""Auto-generated stub for module: test_utils."""
from typing import Any, Union

from .test_data_generators import create_detection_results, create_tracking_results, create_zone_polygons, create_line_crossing_data, create_edge_case_data
from .test_utilities import BasePostProcessingTest

# Classes
class TestCountingUtils:
    # Test counting utility functions.

    def test_calculate_counting_summary(self: Any) -> Any:
        """
        Test comprehensive counting summary.
        """
        ...

    def test_count_objects_by_category(self: Any) -> Any:
        """
        Test object counting by category.
        """
        ...

    def test_count_objects_in_zones(self: Any) -> Any:
        """
        Test zone-based object counting.
        """
        ...

    def test_count_unique_tracks(self: Any) -> Any:
        """
        Test unique track counting.
        """
        ...

class TestFilterUtils:
    # Test filter utility functions.

    def test_apply_category_mapping(self: Any) -> Any:
        """
        Test category mapping application.
        """
        ...

    def test_filter_by_area(self: Any) -> Any:
        """
        Test area-based filtering.
        """
        ...

    def test_filter_by_categories(self: Any) -> Any:
        """
        Test category filtering.
        """
        ...

    def test_filter_by_confidence(self: Any) -> Any:
        """
        Test confidence filtering.
        """
        ...

    def test_remove_duplicate_detections(self: Any) -> Any:
        """
        Test duplicate detection removal.
        """
        ...

class TestFormatUtils:
    # Test format utility functions.

    def test_convert_to_coco_format(self: Any) -> Any:
        """
        Test conversion to COCO format.
        """
        ...

    def test_convert_to_tracking_format(self: Any) -> Any:
        """
        Test conversion to tracking format.
        """
        ...

    def test_convert_to_yolo_format(self: Any) -> Any:
        """
        Test conversion to YOLO format.
        """
        ...

    def test_match_results_structure(self: Any) -> Any:
        """
        Test result structure matching.
        """
        ...

class TestGeometryUtils:
    # Test geometry utility functions.

    def test_calculate_bbox_overlap(self: Any) -> Any:
        """
        Test bounding box overlap calculation.
        """
        ...

    def test_calculate_distance(self: Any) -> Any:
        """
        Test distance calculation between points.
        """
        ...

    def test_calculate_iou(self: Any) -> Any:
        """
        Test IoU (Intersection over Union) calculation.
        """
        ...

    def test_get_bbox_area(self: Any) -> Any:
        """
        Test bounding box area calculation.
        """
        ...

    def test_get_bbox_center(self: Any) -> Any:
        """
        Test bounding box center calculation.
        """
        ...

    def test_line_segments_intersect(self: Any) -> Any:
        """
        Test line segment intersection detection.
        """
        ...

    def test_normalize_denormalize_bbox(self: Any) -> Any:
        """
        Test bbox normalization and denormalization.
        """
        ...

    def test_point_in_polygon(self: Any) -> Any:
        """
        Test point in polygon detection.
        """
        ...

    def test_point_in_polygon_complex(self: Any) -> Any:
        """
        Test point in polygon with complex shapes.
        """
        ...

class TestTrackingUtils:
    # Test tracking utility functions.

    def test_analyze_track_movements(self: Any) -> Any:
        """
        Test track movement analysis.
        """
        ...

    def test_detect_line_crossings(self: Any) -> Any:
        """
        Test line crossing detection.
        """
        ...

    def test_filter_tracks_by_duration(self: Any) -> Any:
        """
        Test track filtering by duration.
        """
        ...

    def test_track_objects_in_zone(self: Any) -> Any:
        """
        Test zone-based object tracking.
        """
        ...

class TestUtilsIntegration:
    # Integration tests for utility functions.

    def test_detection_processing_pipeline(self: Any) -> Any:
        """
        Test complete detection processing pipeline.
        """
        ...

    def test_edge_cases_handling(self: Any) -> Any:
        """
        Test utility functions with edge cases.
        """
        ...

    def test_format_conversion_roundtrip(self: Any) -> Any:
        """
        Test format conversion round trip.
        """
        ...

    def test_tracking_analysis_pipeline(self: Any) -> Any:
        """
        Test complete tracking analysis pipeline.
        """
        ...

