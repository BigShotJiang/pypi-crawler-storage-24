"""Auto-generated stub for module: leaf_disease."""
from typing import Any, Dict, Optional

from ..advanced_tracker import AdvancedTracker
from ..advanced_tracker.config import TrackerConfig
from ..core.base import BaseProcessor, ProcessingContext, ProcessingResult, ConfigProtocol, ResultFormat
from ..core.config import BaseConfig, AlertConfig, ZoneConfig
from ..utils import filter_by_confidence, filter_by_categories, apply_category_mapping, count_objects_by_category, count_objects_in_zones, calculate_counting_summary, match_results_structure, bbox_smoothing, BBoxSmoothingConfig, BBoxSmoothingTracker

# Classes
class LeafDiseaseDetectionConfig:
    # Configuration for leaf disease detection use case in

    ...
class LeafDiseaseDetectionUseCase:
    def __init__(self: Any) -> None: ...

    CATEGORY_DISPLAY: Dict[Any, Any]

    def get_total_counts(self: Any) -> Any:
        """
        Return total unique track_id count for each category.
        """
        ...

    def process(self: Any, data: Any, config: Any, context: Optional[Any] = None, stream_info: Optional[Dict[str, Any]] = None) -> Any:
        """
        Main entry point for  post-processing.
        Applies category mapping, smoothing, counting, alerting, and summary generation.
        Returns a ProcessingResult with all relevant outputs.
        """
        ...

