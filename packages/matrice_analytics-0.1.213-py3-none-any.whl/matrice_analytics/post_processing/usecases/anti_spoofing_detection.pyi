"""Auto-generated stub for module: anti_spoofing_detection."""
from typing import Any, Dict, Optional

from ..advanced_tracker import AdvancedTracker
from ..advanced_tracker.config import TrackerConfig
from ..core.base import BaseProcessor, ProcessingContext, ProcessingResult, ConfigProtocol, ResultFormat
from ..core.config import BaseConfig, AlertConfig, ZoneConfig
from ..utils import filter_by_confidence, filter_by_categories, apply_category_mapping, count_objects_by_category, count_objects_in_zones, calculate_counting_summary, match_results_structure, bbox_smoothing, BBoxSmoothingConfig, BBoxSmoothingTracker

# Classes
class AntiSpoofingDetectionConfig:
    # Configuration for anti-spoofing detection use case.

    ...
class AntiSpoofingDetectionUseCase:
    def __init__(self: Any) -> None: ...

    CATEGORY_DISPLAY: Any

    def get_total_counts(self: Any) -> Any:
        """
        Return total unique track_id count for each category.
        """
        ...

    def process(self: Any, data: Any, config: Any, context: Optional[Any] = None, stream_info: Optional[Dict[str, Any]] = None) -> Any: ...

