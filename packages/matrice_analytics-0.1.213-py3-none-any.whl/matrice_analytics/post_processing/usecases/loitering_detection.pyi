"""Auto-generated stub for module: loitering_detection."""
from typing import Any, Dict, List, Optional

from ..core.base import BaseProcessor, ProcessingContext, ProcessingResult, ConfigProtocol
from ..core.config import BaseConfig, AlertConfig
from ..utils import filter_by_confidence, apply_category_mapping, match_results_structure, bbox_smoothing, BBoxSmoothingConfig, BBoxSmoothingTracker, SORTTracker, ByteTrackWrapper, bbox_centroid, bbox_feet_point, dist, smooth_point, bbox_iou

# Classes
class LoiteringConfig:
    def validate(self: Any) -> List[str]: ...

class LoiteringUseCase:
    def __init__(self: Any) -> None: ...

    GLOBAL_ZONE_NAME: str

    def get_total_counts(self: Any) -> Dict[str, int]:
        """
        Return total unique track_id counts per category.
        """
        ...

    def process(self: Any, data: Any, config: Any, context: Optional[Any] = None, stream_info: Optional[Dict[str, Any]] = None) -> Any: ...

