"""Auto-generated stub for module: area_utilization."""
from typing import Any, Dict, List, Optional

from ..advanced_tracker import AdvancedTracker
from ..advanced_tracker.config import TrackerConfig
from ..core.base import BaseProcessor, ProcessingContext, ProcessingResult, ConfigProtocol, ProcessingStatus, ResultFormat
from ..core.config import BaseConfig, ZoneConfig, AlertConfig
from ..utils import filter_by_confidence, apply_category_mapping, match_results_structure, filter_by_categories, count_objects_by_category, count_objects_in_zones, calculate_counting_summary, bbox_smoothing, BBoxSmoothingConfig, BBoxSmoothingTracker, point_in_polygon

# Constants
DEFAULT_CAPACITY: int
DEFAULT_WINDOW_SECONDS: int
TARGET_CATEGORY: str
WARN_MISSING_STREAM_RESOLUTION: str
WARN_NO_ZONES: str
WARN_ZONE_TOO_BIG: str

# Classes
class AreaUtilizationConfig:
    # Configuration for area utilization use case.
    #
    # This config intentionally mirrors PeopleCountingConfig so that:
    # - client payloads stay consistent
    # - PostProcessor/config_manager behavior remains predictable
    # - we can safely clone people_counting.py behavior
    #
    # Utilization-specific parameters live in:
    #   extra_params = {
    #     "zone_capacities": {"global": 10, "meeting_room": 6},
    #     "window_seconds": 300,
    #   }

    def validate(self: Any) -> List[str]:
        """
        Validate area utilization configuration (PeopleCountingConfig-compatible).
        """
        ...

class AreaUtilizationUseCase:
    # Area Utilization = People Counting + Capacity Analytics.
    #
    # Keeps PeopleCounting behavior:
    # - incidents
    # - tracking_stats
    # - alerts (count-based + optional occupancy-based)
    # - human_text summary
    #
    # Adds:
    # - business_analytics with zone-wise utilization metrics

    def __init__(self: Any) -> None: ...

    def get_total_counts(self: Any) -> Dict[str, int]: ...

    def process(self: Any, data: Any, config: Any, context: Optional[Any] = None, stream_info: Optional[Dict[str, Any]] = None) -> Any: ...

