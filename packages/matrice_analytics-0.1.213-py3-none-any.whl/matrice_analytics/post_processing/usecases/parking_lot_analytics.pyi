"""Auto-generated stub for module: parking_lot_analytics."""
from typing import Any, Dict, Optional

from ..advanced_tracker import AdvancedTracker
from ..advanced_tracker.config import TrackerConfig
from ..core.base import BaseProcessor, ProcessingContext, ProcessingResult, ConfigProtocol, ResultFormat
from ..core.config import BaseConfig, AlertConfig, ZoneConfig
from ..utils import filter_by_confidence, filter_by_categories, apply_category_mapping, count_objects_by_category, count_objects_in_zones, calculate_counting_summary, match_results_structure, bbox_smoothing, BBoxSmoothingConfig, BBoxSmoothingTracker
from ..utils.geometry_utils import get_bbox_center, point_in_polygon, get_bbox_bottom25_center
from ..utils.parking_analytics_tracker import ParkingAnalyticsTracker, VehicleParkingState

# Classes
class ParkingLotAnalyticsConfig:
    # Configuration for vehicle detection use case in parking lot analytics (parking time).

    ...
class ParkingLotAnalyticsUseCase:
    def __init__(self: Any) -> None: ...

    CATEGORY_DISPLAY: Dict[Any, Any]

    def get_total_counts(self: Any) -> Any: ...

    def process(self: Any, data: Any, config: Any, context: Optional[Any] = None, stream_info: Optional[Dict[str, Any]] = None) -> Any: ...

