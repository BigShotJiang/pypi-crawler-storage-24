"""Auto-generated stub for module: tailgating_detection."""
from typing import Any, Dict, List, Optional

from ..core.base import BaseProcessor, ProcessingContext, ProcessingResult, ConfigProtocol
from ..core.config import BaseConfig, ZoneConfig, AlertConfig
from ..utils import filter_by_confidence, match_results_structure, get_bbox_bottom25_center
from ..utils.tailgating_utils import DoorRuntime, CrossingRecord, AccessEventManager, analyze_passage, detect_crossing, compute_entry_normal, signed_distance

# Classes
class TailgatingConfig:
    def __init__(self: Any, usecase: str = 'tailgating_detection', category: str = 'security', confidence_threshold: float = 0.5, target_categories: Optional[List[str]] = None, zones: Optional[Dict[str, Any]] = None, access_window_sec: float = 5.0, silence_timeout_sec: float = 2.0, cooldown_sec: float = 4.0, allowed_persons_per_event: int = 1, max_follow_time_delta_sec: float = 3.0, alert_config: Optional[Any] = None, **kwargs: Any) -> None: ...

    def validate(self: Any) -> Any: ...

class TailgatingDetectionUseCase:
    def __init__(self: Any) -> None: ...

    def create_default_config(self: Any, **overrides: Any) -> Any: ...

    def process(self: Any, data: Any, config: Any, context: Optional[Any] = None, stream_info: Optional[Any] = None) -> Any: ...

