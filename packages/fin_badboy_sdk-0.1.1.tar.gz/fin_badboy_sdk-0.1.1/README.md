# fin-badboy-sdk — Python SDK

Track AI/LLM usage events from Python applications. **PyPI:** `fin-badboy-sdk` (import package remains `fin_sdk`).

## Install

From PyPI:

```bash
pip install fin-badboy-sdk
```

**Monorepo contributors:** `pip install -e sdks/python/`

## Quick Start

```python
import time
from openai import OpenAI
from fin_sdk import FinClient

client = OpenAI()
fin = FinClient()

start = time.time()
response = client.chat.completions.create(
    model="gpt-4o-mini",
    messages=[{"role": "user", "content": "Hello"}],
)

fin.track_response(
    response,
    provider="openai",
    feature_id="chat",
    environment="production",
    latency_ms=(time.time() - start) * 1000,
)
```

## Configuration

Set environment variables (read at construction time):

```bash
export FIN_INGEST_URL=https://events.badboy.dev
export FIN_API_KEY=sk-your-api-key
```

For experiment resolution (`resolve_model` / `experiment`), also set `FIN_API_URL` (api-nest base URL), for example `https://api.badboy.dev`.

Or pass explicitly:

```python
fin = FinClient(
    ingest_url="https://events.badboy.dev",
    api_key="sk-your-api-key",
)
```

For local development against a running events service, use `http://localhost:3001` as `ingest_url` (no trailing slash).

## API

### `track_response(response=None, *, provider, feature_id, environment, ...)`

Build and POST a usage event from a provider response. `response` is positional-or-keyword; all other parameters are keyword-only.

| Parameter | Type | Required | Description |
|-----------|------|----------|-------------|
| `response` | `Any` | No | Raw LLM response; SDK auto-extracts `usage` + `model` |
| `provider` | `str` | Yes | Use a key from **Supported Providers** below (matches Fin `model_pricing`), or any string with explicit `usage` / `model` |
| `feature_id` | `str` | Yes | Workflow/feature name |
| `environment` | `str` | Yes | `"production"`, `"staging"`, `"development"` |
| `model` | `str` | No | Override or fallback |
| `usage` | `dict` | No | `{"input_tokens": N, "output_tokens": N, "total_tokens": N}` (snake_case; converted to camelCase internally) |
| `latency_ms` | `float` | No | End-to-end latency in milliseconds |
| `error` | `bool` | No | `True` on error path (zeroes usage) |
| `tenant_id` | `str` | No | Your end-user/customer ID |
| `plan_tier` | `str` | No | e.g. `"free"`, `"pro"` |
| `outcome` | `str` | No | e.g. `"success"`, `"refusal"` |
| `cost` | `float` | No | Client-supplied cost in USD |
| `idempotency_key` | `str` | No | De-duplicate retries |

### `track(payload, *, idempotency_key=None)`

Post a pre-built event dict. All keys must be **camelCase**. Missing required fields are logged and the event is silently skipped.

Required fields: `featureId`, `environment`, `provider`, `model`, `usage`, `timestamp` (ISO 8601), `error`.

## Supported Providers

These keys align with **Fin `model_pricing`** (same provider ids as server-side cost lookup).

| Provider key | Extraction |
|--------------|------------|
| `"openai"` | `usage.prompt_tokens` → `inputTokens`, `usage.completion_tokens` → `outputTokens`, `usage.total_tokens` → `totalTokens`; `model` |
| `"groq"` | Same as `"openai"` |
| `"azure_openai"` | Same as `"openai"` |
| `"mistral"` | Same as `"openai"` (Mistral chat API is OpenAI-compatible) |
| `"anthropic"` | `usage.input_tokens` → `inputTokens`, `usage.output_tokens` → `outputTokens`; `totalTokens` derived as input + output; `model` |
| `"google"` | `usageMetadata.promptTokenCount`, `.candidatesTokenCount`, `.totalTokenCount` (snake_case variants supported); `model` from `model`, `modelVersion`, or `model_version` |

Other provider strings still work: pass `usage` and `model` explicitly on `track_response`, or use `track()` with a full camelCase payload.

## Error Handling

The SDK never raises on ingest failure. HTTP errors and network issues are logged via `logging.getLogger("fin_sdk")` with a `[fin-sdk] ingest failed:` prefix. Your application flow is never disrupted.

## Full Documentation

See [docs/getting-started.md](../../docs/getting-started.md) for the complete integration guide.
