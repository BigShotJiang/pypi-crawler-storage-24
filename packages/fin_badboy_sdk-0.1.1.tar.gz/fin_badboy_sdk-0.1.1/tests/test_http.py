"""Tests for the HTTP client layer."""
import responses as responses_lib
import requests
import pytest

from fin_sdk.http import post_event

INGEST_URL = "http://localhost:3001"
API_KEY = "test-key"

BASE_EVENT = {
    "featureId": "chat",
    "environment": "production",
    "provider": "openai",
    "model": "gpt-4o-mini",
    "usage": {"inputTokens": 10, "outputTokens": 5, "totalTokens": 15},
    "timestamp": "2026-03-04T12:00:00.000Z",
    "error": False,
}


@responses_lib.activate
def test_posts_to_correct_url_with_api_key_header():
    responses_lib.add(responses_lib.POST, f"{INGEST_URL}/usage/ingest", status=202, json={"accepted": True})

    post_event(ingest_url=INGEST_URL, api_key=API_KEY, event=BASE_EVENT)

    assert len(responses_lib.calls) == 1
    req = responses_lib.calls[0].request
    assert req.url == f"{INGEST_URL}/usage/ingest"
    assert req.headers["x-api-key"] == API_KEY
    assert req.headers["Content-Type"] == "application/json"


@responses_lib.activate
def test_forwards_idempotency_key_header():
    responses_lib.add(responses_lib.POST, f"{INGEST_URL}/usage/ingest", status=202)

    post_event(ingest_url=INGEST_URL, api_key=API_KEY, event=BASE_EVENT, idempotency_key="idem-abc")

    req = responses_lib.calls[0].request
    assert req.headers["idempotency-key"] == "idem-abc"


@responses_lib.activate
def test_does_not_include_idempotency_header_when_not_provided():
    responses_lib.add(responses_lib.POST, f"{INGEST_URL}/usage/ingest", status=202)

    post_event(ingest_url=INGEST_URL, api_key=API_KEY, event=BASE_EVENT)

    req = responses_lib.calls[0].request
    assert "idempotency-key" not in req.headers


@responses_lib.activate
def test_does_not_raise_on_400_response():
    responses_lib.add(responses_lib.POST, f"{INGEST_URL}/usage/ingest", status=400, body="Bad Request")

    # Should not raise
    post_event(ingest_url=INGEST_URL, api_key=API_KEY, event=BASE_EVENT)


def test_does_not_raise_on_network_error():
    with responses_lib.RequestsMock(assert_all_requests_are_fired=False) as rsps:
        rsps.add(responses_lib.POST, f"{INGEST_URL}/usage/ingest", body=requests.ConnectionError("ECONNREFUSED"))

        # Should not raise
        post_event(ingest_url=INGEST_URL, api_key=API_KEY, event=BASE_EVENT)


@responses_lib.activate
def test_strips_trailing_slash_from_ingest_url():
    responses_lib.add(responses_lib.POST, f"{INGEST_URL}/usage/ingest", status=202)

    post_event(ingest_url=INGEST_URL + "/", api_key=API_KEY, event=BASE_EVENT)

    assert responses_lib.calls[0].request.url == f"{INGEST_URL}/usage/ingest"
