"""Tests for track_response and track (business logic layer)."""
import pytest
from unittest.mock import patch

from fin_sdk.client import FinClient


INGEST_URL = "http://localhost:3001"
API_KEY = "test-key"


@pytest.fixture
def fin():
    return FinClient(ingest_url=INGEST_URL, api_key=API_KEY)


class TestTrackResponseSuccessPath:
    def test_builds_camelcase_body_and_calls_post(self, fin):
        with patch("fin_sdk.track.post_event") as mock_post:
            fin.track_response(
                provider="openai",
                feature_id="chat",
                environment="production",
                model="gpt-4o-mini",
                usage={"input_tokens": 100, "output_tokens": 50, "total_tokens": 150},
                latency_ms=250,
            )

        mock_post.assert_called_once()
        _, kwargs = mock_post.call_args
        event = kwargs["event"]
        assert event["featureId"] == "chat"
        assert event["environment"] == "production"
        assert event["provider"] == "openai"
        assert event["model"] == "gpt-4o-mini"
        assert event["latencyMs"] == 250
        assert event["error"] is False

    def test_converts_snake_case_usage_to_camelcase(self, fin):
        with patch("fin_sdk.track.post_event") as mock_post:
            fin.track_response(
                provider="openai",
                feature_id="chat",
                environment="production",
                model="gpt-4o-mini",
                usage={"input_tokens": 100, "output_tokens": 50, "total_tokens": 150},
            )

        _, kwargs = mock_post.call_args
        usage = kwargs["event"]["usage"]
        assert usage == {"inputTokens": 100, "outputTokens": 50, "totalTokens": 150}
        assert "input_tokens" not in usage

    def test_includes_optional_fields_when_provided(self, fin):
        with patch("fin_sdk.track.post_event") as mock_post:
            fin.track_response(
                provider="anthropic",
                feature_id="summarize",
                environment="staging",
                model="claude-3-5-sonnet",
                usage={"input_tokens": 50, "output_tokens": 30, "total_tokens": 80},
                tenant_id="tenant-abc",
                plan_tier="pro",
                outcome="success",
            )

        _, kwargs = mock_post.call_args
        event = kwargs["event"]
        assert event["tenantId"] == "tenant-abc"
        assert event["planTier"] == "pro"
        assert event["outcome"] == "success"

    def test_omits_none_optional_fields(self, fin):
        with patch("fin_sdk.track.post_event") as mock_post:
            fin.track_response(
                provider="openai",
                feature_id="chat",
                environment="production",
                model="gpt-4o-mini",
                usage={"input_tokens": 10, "output_tokens": 5, "total_tokens": 15},
            )

        _, kwargs = mock_post.call_args
        event = kwargs["event"]
        assert "tenantId" not in event
        assert "planTier" not in event
        assert "outcome" not in event
        assert "latencyMs" not in event


class TestTrackResponseErrorPath:
    def test_sends_zero_usage_on_error(self, fin):
        with patch("fin_sdk.track.post_event") as mock_post:
            fin.track_response(
                provider="openai",
                feature_id="chat",
                environment="production",
                model="gpt-4o-mini",
                error=True,
                latency_ms=120,
            )

        _, kwargs = mock_post.call_args
        event = kwargs["event"]
        assert event["error"] is True
        assert event["usage"] == {"inputTokens": 0, "outputTokens": 0, "totalTokens": 0}

    def test_defaults_model_to_unknown_when_not_provided_on_error(self, fin):
        with patch("fin_sdk.track.post_event") as mock_post:
            fin.track_response(
                provider="openai",
                feature_id="chat",
                environment="production",
                error=True,
            )

        _, kwargs = mock_post.call_args
        assert kwargs["event"]["model"] == "unknown"

    def test_uses_provided_model_on_error_path(self, fin):
        with patch("fin_sdk.track.post_event") as mock_post:
            fin.track_response(
                provider="openai",
                feature_id="chat",
                environment="production",
                model="gpt-4o-mini",
                error=True,
            )

        _, kwargs = mock_post.call_args
        assert kwargs["event"]["model"] == "gpt-4o-mini"


class TestIdempotencyKey:
    def test_forwards_idempotency_key_to_post(self, fin):
        with patch("fin_sdk.track.post_event") as mock_post:
            fin.track_response(
                provider="openai",
                feature_id="chat",
                environment="production",
                model="gpt-4o",
                usage={"input_tokens": 10, "output_tokens": 5, "total_tokens": 15},
                idempotency_key="req-xyz-123",
            )

        _, kwargs = mock_post.call_args
        assert kwargs["idempotency_key"] == "req-xyz-123"


class TestExtractorIntegration:
    """Integration: track_response with real extractor (not mocked)."""

    def test_derives_usage_and_model_from_openai_response(self, fin):
        class _Usage:
            prompt_tokens = 100
            completion_tokens = 50
            total_tokens = 150

        class _Response:
            model = "gpt-4o-mini"
            usage = _Usage()

        with patch("fin_sdk.track.post_event") as mock_post:
            fin.track_response(
                _Response(),
                provider="openai",
                feature_id="chat",
                environment="production",
            )

        _, kwargs = mock_post.call_args
        event = kwargs["event"]
        assert event["model"] == "gpt-4o-mini"
        assert event["usage"] == {"inputTokens": 100, "outputTokens": 50, "totalTokens": 150}

    def test_falls_back_to_caller_usage_for_unknown_provider(self, fin):
        class _Response:
            model = "command-r"
            usage = None

        with patch("fin_sdk.track.post_event") as mock_post:
            fin.track_response(
                _Response(),
                provider="cohere",
                feature_id="chat",
                environment="production",
                model="command-r",
                usage={"input_tokens": 10, "output_tokens": 5, "total_tokens": 15},
            )

        _, kwargs = mock_post.call_args
        event = kwargs["event"]
        assert event["model"] == "command-r"
        assert event["usage"] == {"inputTokens": 10, "outputTokens": 5, "totalTokens": 15}

    def test_derives_usage_from_mistral_response(self, fin):
        class _Usage:
            prompt_tokens = 7
            completion_tokens = 3
            total_tokens = 10

        class _Response:
            model = "mistral-small-latest"
            usage = _Usage()

        with patch("fin_sdk.track.post_event") as mock_post:
            fin.track_response(
                _Response(),
                provider="mistral",
                feature_id="chat",
                environment="production",
            )

        _, kwargs = mock_post.call_args
        event = kwargs["event"]
        assert event["model"] == "mistral-small-latest"
        assert event["usage"] == {"inputTokens": 7, "outputTokens": 3, "totalTokens": 10}

    def test_derives_anthropic_total_tokens_as_sum(self, fin):
        """Anthropic has no total_tokens field; extractor derives it as input + output."""

        class _Usage:
            input_tokens = 40
            output_tokens = 60

        class _Response:
            model = "claude-3-5-sonnet-20241022"
            usage = _Usage()

        with patch("fin_sdk.track.post_event") as mock_post:
            fin.track_response(
                _Response(),
                provider="anthropic",
                feature_id="summarize",
                environment="production",
            )

        _, kwargs = mock_post.call_args
        event = kwargs["event"]
        assert event["model"] == "claude-3-5-sonnet-20241022"
        assert event["usage"] == {"inputTokens": 40, "outputTokens": 60, "totalTokens": 100}


class TestExperimentId:
    def test_experiment_id_included_in_event_when_provided(self, fin):
        with patch("fin_sdk.track.post_event") as mock_post:
            fin.track_response(
                provider="openai",
                feature_id="chat",
                environment="production",
                model="gpt-4o-mini",
                usage={"input_tokens": 10, "output_tokens": 5, "total_tokens": 15},
                experiment_id="exp-uuid-123",
            )

        _, kwargs = mock_post.call_args
        event = kwargs["event"]
        assert event["experimentId"] == "exp-uuid-123"

    def test_experiment_id_omitted_when_not_provided(self, fin):
        with patch("fin_sdk.track.post_event") as mock_post:
            fin.track_response(
                provider="openai",
                feature_id="chat",
                environment="production",
                model="gpt-4o-mini",
                usage={"input_tokens": 10, "output_tokens": 5, "total_tokens": 15},
            )

        _, kwargs = mock_post.call_args
        event = kwargs["event"]
        assert "experimentId" not in event


class TestTrackRaw:
    def test_posts_pre_built_camelcase_event(self, fin):
        payload = {
            "featureId": "chat",
            "environment": "production",
            "provider": "openai",
            "model": "gpt-4o",
            "usage": {"inputTokens": 10, "outputTokens": 5, "totalTokens": 15},
            "timestamp": "2026-03-04T12:00:00.000Z",
            "error": False,
        }

        with patch("fin_sdk.track.post_event") as mock_post:
            fin.track(payload)

        _, kwargs = mock_post.call_args
        assert kwargs["event"]["featureId"] == "chat"
        assert kwargs["event"]["model"] == "gpt-4o"
