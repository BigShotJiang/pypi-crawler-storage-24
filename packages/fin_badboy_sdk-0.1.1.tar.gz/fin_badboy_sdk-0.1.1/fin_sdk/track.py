"""track_response and track — core SDK entry points."""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from .extractor import extract
from .http import post_event

logger = logging.getLogger("fin_sdk")

_ZERO_USAGE = {"inputTokens": 0, "outputTokens": 0, "totalTokens": 0}


def _snake_to_camel(key: str) -> str:
    parts = key.split("_")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])


def _convert_usage(usage: dict) -> dict:
    """Convert snake_case usage keys to camelCase for the REST API."""
    mapping = {
        "input_tokens": "inputTokens",
        "output_tokens": "outputTokens",
        "total_tokens": "totalTokens",
    }
    return {mapping.get(k, _snake_to_camel(k)): v for k, v in usage.items()}


def track_response(
    *,
    ingest_url: str,
    api_key: str,
    response: Any = None,
    provider: str,
    feature_id: str,
    environment: str,
    latency_ms: Optional[float] = None,
    error: bool = False,
    model: Optional[str] = None,
    tenant_id: Optional[str] = None,
    plan_tier: Optional[str] = None,
    outcome: Optional[str] = None,
    cost: Optional[float] = None,
    usage: Optional[Dict[str, int]] = None,
    idempotency_key: Optional[str] = None,
    experiment_id: Optional[str] = None,
) -> None:
    """
    Build and POST a canonical usage event derived from a provider response.

    On error path: usage is zeroed, model defaults to "unknown" if not supplied.
    Caller-supplied usage keys are snake_case (input_tokens, output_tokens, total_tokens);
    the SDK converts to camelCase before posting.
    """
    if error:
        resolved_usage = _ZERO_USAGE.copy()
        resolved_model = model or "unknown"
    else:
        extracted = extract(response, provider) if response is not None else None

        if extracted is not None:
            resolved_usage = extracted.get("usage", _ZERO_USAGE.copy())
            resolved_model = extracted.get("model") or model or "unknown"
        else:
            resolved_usage = _convert_usage(usage) if usage else _ZERO_USAGE.copy()
            resolved_model = model or "unknown"

    timestamp = datetime.now(tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"

    event: dict = {
        "featureId": feature_id,
        "environment": environment,
        "provider": provider,
        "model": resolved_model,
        "usage": resolved_usage,
        "timestamp": timestamp,
        "error": error,
    }

    if tenant_id is not None:
        event["tenantId"] = tenant_id
    if plan_tier is not None:
        event["planTier"] = plan_tier
    if latency_ms is not None:
        event["latencyMs"] = round(latency_ms)
    if cost is not None:
        event["cost"] = cost
    if outcome is not None:
        event["outcome"] = outcome
    if experiment_id is not None:
        event["experimentId"] = experiment_id

    post_event(ingest_url=ingest_url, api_key=api_key, event=event, idempotency_key=idempotency_key)


_REQUIRED_EVENT_FIELDS = ("featureId", "environment", "provider", "model", "usage", "timestamp")


def track(
    *,
    ingest_url: str,
    api_key: str,
    payload: dict,
    idempotency_key: Optional[str] = None,
) -> None:
    """
    Post a pre-built canonical event directly (already camelCase).
    No key conversion — caller is responsible for correct field names.
    Performs minimal field-presence validation before sending.
    """
    missing = [f for f in _REQUIRED_EVENT_FIELDS if not payload.get(f)]
    if missing:
        logger.error("[fin-sdk] invalid event, not sent: missing required fields: %s", ", ".join(missing))
        return
    post_event(ingest_url=ingest_url, api_key=api_key, event=payload, idempotency_key=idempotency_key)
