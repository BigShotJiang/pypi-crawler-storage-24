from vstools import vs

def av2deblock(
    clip: vs.VideoNode,
    qpmap: vs.VideoNode,
    mbmap: vs.VideoNode
) -> vs.VideoNode:
    """
    Apply AV2 deblocking filter to a clip using a QP map and macroblock map.

    :param clip:            Clip to process (16bit, if not will be internally converted in 16bit).
    :param qpmap:           QP map corresponding to the input clip. Must be GRAY16.
    :param mbmap:           Macroblock map corresponding to the input clip. Must be GRAY16.
    :return:                Deblocked clip.
    """

    core = vs.core
    # Il deblocker AV2 usa solo 1 campione nei blocchi 4x4, e 3 vengono analizzati per la decisione.
    # Il deblocker è composto da 3 stadi
    # 1) Determinare locazione dei blocchi (tramite mbmap), determinare se applicare il deblock (threshold), trovare il numero di pixel da modificare.
    # 2) Analizza i campioni, la lunghezza e la forza.
    # 3) Opera in base ai valori trovati.
    # qpmap è una mappa di valori indicati come pixel in grayscale
    # mbmap è una mapap di 0 o 1 che indicano se il blocco è 4x4 o 8x8, rispettivamente, in grayscale
    def _stadio1(clip, qpmap):
        # Funzione n.6: Prima derivata del segnale, d1[i] = s[i+1] – s[i]
        d1 = core.akarin.Expr([clip], "x[1,0] x  -")
        # Funzione n.7: Seconda derivata del segnale, d2[i] = |d1[i] – d1[i-1]|
        d2 = core.akarin.Expr([d1], "x x[-1,0] - abs")
        # q_threshold(q) = 16 * 2 ^ (q / 32) dove q è il valore della qpmap in quel pixel
        q_threshold = core.akarin.Expr([qpmap], f"x 32 / 2 pow 16 *")
        """
        int q_scaled = (255 * q_index) / Qmax_local     # la funzione è calibrata per Qmax 255

        float t1 = 0.0444f * q_scaled - 2.9936f
        float t2 = 0.31f   * q_scaled - 39.0f

        float t = t1 t2 max

        int side_threshold = max(256 * 32 * t, 0)        # evita valori negativi
        """ 
        qmax = 51 #63 per 16bit
        q_scaled = f"x 255 * {qmax} /"
        t1 = f"{q_scaled} 0.0444 * 2.9936 -"
        t2 = f"{q_scaled} 0.31 * 39 -"
        t = f"{t1} {t2} max"
        side_threshold = core.akarin.Expr([qpmap], f"{t} 256 * 0 max")
        side_threshold = core.resize.Point(side_threshold, format=vs.GRAY16)
        # Funzione n.8: Deve essere falsa per proseguire con il deblock sul campione, d2[i] > thr1 (chiamato q_threshold in av2) per i = 1, -2. se il valore finale è 0 è falso
        mask = core.akarin.Expr([d2, q_threshold], "x y > 1 0 ?")
        # Funzione n.9: Deve essere falsa per proseguire con il deblock sul campione, d2[0] + d2[-1] > thr2 (chiamato q_threshold in av2). se il valore finale è 0 è falso
        mask = core.akarin.Expr([d2, q_threshold, mask], "x x[-1,0] + y > 1 0 ?")
        # Funzione n.10: non si usa (sopra 8x8)
        # Funzione n.11: non si usa (sopra 8x8)

        return side_threshold, mask

    def _stadio2_hor(clip, side_threshold):
        # Funzione n.12: si ripete per tutti i sample questa equazione, Delta = [3(s[0] – s[–1]) – (s[1] – s[–2])] / 2
        delta = core.akarin.Expr([clip], "x x[-1,0] - 3 * x[1,0] x[-2,0] - - 2 /")
        # Funzione n.13: Clipping con thr4 (side_threshold in av2)
        clipping = core.akarin.Expr([delta, side_threshold], "x y min") # D -thr4 thr4 clip
        return clipping
    
    def _stadio2_ver(clip, side_threshold):
        # Funzione n.12: si ripete per tutti i sample questa equazione, Delta = [3(s[0] – s[–1]) – (s[1] – s[–2])] / 2
        delta = core.akarin.Expr([clip], "x x[0,-1] - 3 * x[0,1] x[0,-2] - - 2 /")
        # Funzione n.13: Clipping con thr4 (side_threshold in av2)
        clipping = core.akarin.Expr([delta, side_threshold], "x y 2 y * - y clip") # x -y y clip

        return clipping

    def _stadio3_hor(clip8x8, clip4x4, delta):
        # stringhe di resto già pronte per 4x4 e 8x8, esempio se voglio il valore del primo pixel nel blocco 8x8 sarà "{hor8x8} 0 ="
        hor8x8 = "X 8 %"
        hor4x4 = "X 4 %"
        # Funzione n.14: s'[i] = s[i] – D(N – i) / (2N + 1), dove N è il numero di campioni da modificare, 8x8 sono 2, 4x4 è 1
        # Funzione n.15: s'[-i-1] = s[-i-1] – D(N – i) / (2N + 1), dove N è il numero di campioni da modificare, 8x8 sono 2, 4x4 è 1
        i_0_8x8_hor = f"{hor8x8} 0 = x y 2 * 5 / -"
        i_1_8x8_hor = f"{hor8x8} 1 = x y 5 / -"
        i_neg1_8x8_hor = f"{hor8x8} -1 = x y 2 * 5 / -"
        i_neg2_8x8_hor = f"{hor8x8} -2 = x y 5 / -"

        i_0_4x4_hor = f"{hor4x4} 0 = x y 3 / -"
        i_neg1_4x4_hor = f"{hor4x4} -1 = x y 3 / -"

        fun_8x8 = f"{i_0_8x8_hor} {i_1_8x8_hor} {i_neg1_8x8_hor} {i_neg2_8x8_hor} x ? ? ? ?"
        fun_4x4 = f"{i_0_4x4_hor} {i_neg1_4x4_hor} x ? ?"
        clip8x8 = core.akarin.Expr([clip8x8, delta], f"{fun_8x8}")
        clip4x4 = core.akarin.Expr([clip4x4, delta], f"{fun_4x4}")

        return clip8x8, clip4x4
    
    def _stadio3_ver(clip8x8, clip4x4, delta):
        # stringhe di resto già pronte per 4x4 e 8x8, esempio se voglio il valore del primo pixel nel blocco 8x8 sarà "{hor8x8} 0 ="
        ver8x8 = "Y 8 %"
        ver4x4 = "Y 4 %"
        # Funzione n.14: s'[i] = s[i] – D(N – i) / (2N + 1), dove N è il numero di campioni da modificare, 8x8 sono 2, 4x4 è 1
        # Funzione n.15: s'[-i-1] = s[-i-1] – D(N – i) / (2N + 1), dove N è il numero di campioni da modificare, 8x8 sono 2, 4x4 è 1
        i_0_8x8_ver = f"{ver8x8} 0 = x y 2 * 5 / -"
        i_1_8x8_ver = f"{ver8x8} 1 = x y 5 / -"
        i_neg1_8x8_ver = f"{ver8x8} -1 = x y 2 * 5 / -"
        i_neg2_8x8_ver = f"{ver8x8} -2 = x y 5 / -"

        i_0_4x4_ver = f"{ver4x4} 0 = x y 3 / -"
        i_neg1_4x4_ver = f"{ver4x4} -1 = x y 3 / -"

        fun_8x8 = f"{i_0_8x8_ver} {i_1_8x8_ver} {i_neg1_8x8_ver} {i_neg2_8x8_ver} x ? ? ? ?"
        fun_4x4 = f"{i_0_4x4_ver} {i_neg1_4x4_ver} x ? ?"
        clip8x8 = core.akarin.Expr([clip8x8, delta], f"{fun_8x8}")
        clip4x4 = core.akarin.Expr([clip4x4, delta], f"{fun_4x4}")

        return clip8x8, clip4x4
    
    side_threshold, mask = _stadio1(clip, qpmap)
    delta = _stadio2_hor(clip, side_threshold)
    clip8x8_hor, clip4x4_hor = _stadio3_hor(clip, clip, delta)
    delta = _stadio2_ver(clip, side_threshold) #TODO: non dovrebbero esserci clip8x8 e clip4x4, quindi andrà sostituito l'input con l'uscita dello _stadio3_hor
    clip8x8, clip4x4 = _stadio3_ver(clip8x8_hor, clip4x4_hor, delta)

    # TODO: unire i risultati di 4x4 e 8x8 in base alla mbmap, e applicare la maschera per escludere i blocchi che non devono essere debloccati

    return clip8x8, clip4x4
