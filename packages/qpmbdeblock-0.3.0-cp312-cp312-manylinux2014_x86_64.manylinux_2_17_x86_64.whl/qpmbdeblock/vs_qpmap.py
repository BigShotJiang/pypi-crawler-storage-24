from __future__ import annotations

import os
from pathlib import Path
from typing import Optional


def _load_mkv(core: "object", path: str) -> "object":  # vs.VideoNode
    """Load via bestsource, ffms2 or lsmas, whichever is installed first."""
    import vapoursynth as vs

    if hasattr(core, "bs"):
        clip = core.bs.VideoSource(path, fpsnum=-1)
    elif hasattr(core, "ffms2"):
        clip = core.ffms2.Source(path)
    elif hasattr(core, "lsmas"):
        clip = core.lsmas.Source(path)
    else:
        raise RuntimeError(
            "[qpmap] No source plugin found. Install bestsource, ffms2 or lsmas."
        )

    return core.resize.Point(clip, format=vs.GRAY8)


def VSqpmap_mask(
    input_video: Optional[str] = None,
    qpmap_path: Optional[str] = None,
    ffmpeg_path: str = "ffmpeg",
    high_bitdepth: bool = True,
    scale_video: bool = True,
    segment_duration: float = 20.0,
    max_workers: Optional[int] = None,
    reference_clip: Optional["object"] = None,  # vs.VideoNode
    chroma_qpmap: bool = False,
) -> "object":  # vs.VideoNode
    """
    Load (or generate) a QP map as a VapourSynth VideoNode.

    Parameters
    ----------
    input_video    : Path to the source H.264 video. If None search in current directory.
    qpmap_path     : Path to the qpmap MKV file. Defaults to `<stem>.qpmap.mkv`.
    ffmpeg_path    : Path to the ffmpeg executable (used only during generation).
    high_bitdepth  : If True (default), output in GRAY16/YUV16, values stay 0-63.
    scale_video    : If True (default), upscale the QP map 16x via Point resize
                     then crop it to match reference dimensions.
    segment_duration: Extraction block size in seconds (default 20.0).
    max_workers    : Number of parallel extraction threads (default 8 or cpu_count).
    reference_clip : A VapourSynth VideoNode used as crop reference when
                     `scale_video=True`. If not given, input_video dimensions are used.
    chroma_qpmap   : If True, generate YUV QP map based on the detected subsampling in reference_clip.

    Returns
    -------
    vs.VideoNode  GRAY8/GRAY16 or YUV 16-bit, cropped to reference dimensions if scale_video.
    """
    import vapoursynth as vs
    import glob

    core = vs.core

    input_path = None
    if input_video is None:
        if qpmap_path is None:
            qmaps = (
                glob.glob("*.qpmap.mkv")
                + glob.glob("*.qmap.mkv")
                + glob.glob("*.qpmap")
                + glob.glob("*.qmap")
            )
            if qmaps:
                qpmap_path = qmaps[0]
            else:
                raise ValueError(
                    "[qpmap] No input_video or qpmap_path provided, and no .qmap found in current dir."
                )
    else:
        input_path = Path(input_video).resolve()
        if qpmap_path is None:
            qpmap_path = str(input_path.parent / f"{input_path.stem}.qpmap.mkv")

    qpmap_path = str(Path(qpmap_path).resolve())

    # Generate if missing
    if not os.path.isfile(qpmap_path):
        if input_video is None:
            raise RuntimeError(
                f"[qpmap] QP map not found at {qpmap_path} and no input_video provided to generate it."
            )
        print(f"[qpmap] Generating QP map: {qpmap_path}")
        from .qpmap_native import h264QPparser

        parser = h264QPparser(str(input_path), ffmpeg_path=ffmpeg_path)
        result = parser.create_qp_map(
            qpmap_path,
            segment_duration=segment_duration,
            max_workers=max_workers,
        )
        if result is None:
            raise RuntimeError(f"[qpmap] Failed to generate QP map for: {input_path}")
        print(f"[qpmap] QP map created: {qpmap_path}")
    else:
        print(f"[qpmap] Loading QP map: {qpmap_path}")

    clip = _load_mkv(core, qpmap_path)  # GRAY8

    ref_w = None
    ref_h = None
    subsampling = None

    if reference_clip is not None:
        ref_w = reference_clip.width
        ref_h = reference_clip.height
        fmt = reference_clip.format
        if fmt is not None:
            subsampling = (fmt.subsampling_w, fmt.subsampling_h)
    elif input_video is not None:
        try:
            if hasattr(core, "bs"):
                src = core.bs.VideoSource(input_video, fpsnum=-1)
            elif hasattr(core, "ffms2"):
                src = core.ffms2.Source(input_video)
            elif hasattr(core, "lsmas"):
                src = core.lsmas.Source(input_video)
            else:
                src = None

            if src is not None:
                ref_w = src.width
                ref_h = src.height
                fmt = src.format
                if fmt is not None:
                    subsampling = (fmt.subsampling_w, fmt.subsampling_h)
        except Exception as e:
            print(f"[qpmap] Warning: Could not open input_video bounds: {e}")

    luma_clip = clip

    if scale_video:
        luma_scaled_w = luma_clip.width * 16
        luma_scaled_h = luma_clip.height * 16
        luma_clip = core.resize.Point(
            luma_clip, width=luma_scaled_w, height=luma_scaled_h
        )

        if ref_w is not None and ref_h is not None:
            crop_right = max(0, luma_scaled_w - ref_w)
            crop_bottom = max(0, luma_scaled_h - ref_h)
            if crop_right > 0 or crop_bottom > 0:
                luma_clip = core.std.Crop(
                    luma_clip, right=crop_right, bottom=crop_bottom
                )

    if high_bitdepth:
        luma_clip = core.resize.Point(luma_clip, format=vs.GRAY16)

    if not chroma_qpmap:
        res_clip = luma_clip
    else:
        if subsampling == (0, 0):  # 444
            res_clip = core.std.ShufflePlanes(
                [luma_clip, luma_clip, luma_clip], planes=[0, 0, 0], colorfamily=vs.YUV
            )
        elif subsampling == (1, 0):  # 422
            raise NotImplementedError(
                "[qpmap] 422 chroma subsampling not yet implemented."
            )
        else:  # 420 or default
            v_w = luma_clip.width // 2
            v_h = luma_clip.height // 2

            chroma_clip = core.resize.Point(luma_clip, width=v_w, height=v_h)
            chroma_clip = core.std.Expr(chroma_clip, "x 2 /")

            res_clip = core.std.ShufflePlanes(
                [luma_clip, chroma_clip, chroma_clip],
                planes=[0, 0, 0],
                colorfamily=vs.YUV,
            )

    return res_clip
