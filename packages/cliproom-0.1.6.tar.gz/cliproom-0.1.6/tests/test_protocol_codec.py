from __future__ import annotations

from cliproom.protocol import (
    ClipboardFormat,
    ClipMessage,
    JoinMessage,
    decode_message_line,
    encode_message,
    hash_passphrase,
)


def test_join_roundtrip() -> None:
    join = JoinMessage(
        session="devteam",
        auth=hash_passphrase("secret"),
        client_name="laptop",
    )
    raw = encode_message(join)
    parsed = decode_message_line(raw)
    assert parsed.type == "join"
    assert parsed.session == "devteam"
    assert parsed.client_name == "laptop"


def test_clip_roundtrip() -> None:
    clip = ClipMessage(
        session="devteam",
        message_id="m1",
        formats=[
            ClipboardFormat(
                mime="text/plain",
                encoding="utf-8",
                data="SGVsbG8=",
            )
        ],
    )
    raw = encode_message(clip)
    parsed = decode_message_line(raw)
    assert parsed.type == "clip"
    assert parsed.message_id == "m1"
    assert parsed.formats[0].mime == "text/plain"
