from __future__ import annotations

import cliproom.clipboard.adapters as adapters


def test_linux_prefers_xclip_on_x11_when_wl_installed(monkeypatch) -> None:
    monkeypatch.setattr(adapters.sys, "platform", "linux")
    monkeypatch.delenv("WAYLAND_DISPLAY", raising=False)
    monkeypatch.setenv("DISPLAY", ":0")
    monkeypatch.setenv("CLIPROOM_CLIPBOARD_BACKEND", "")

    def which(binary: str) -> str | None:
        if binary in {"wl-paste", "wl-copy", "xclip"}:
            return f"/usr/bin/{binary}"
        return None

    monkeypatch.setattr(adapters.shutil, "which", which)
    adapter = adapters.create_default_adapter()
    assert isinstance(adapter, adapters.XclipClipboardAdapter)


def test_linux_prefers_wl_on_wayland(monkeypatch) -> None:
    monkeypatch.setattr(adapters.sys, "platform", "linux")
    monkeypatch.setenv("WAYLAND_DISPLAY", "wayland-0")
    monkeypatch.setenv("DISPLAY", ":0")
    monkeypatch.setenv("CLIPROOM_CLIPBOARD_BACKEND", "")

    def which(binary: str) -> str | None:
        if binary in {"wl-paste", "wl-copy", "xclip"}:
            return f"/usr/bin/{binary}"
        return None

    monkeypatch.setattr(adapters.shutil, "which", which)
    adapter = adapters.create_default_adapter()
    assert isinstance(adapter, adapters.WlClipboardAdapter)


def test_linux_override_backend_to_xclip(monkeypatch) -> None:
    monkeypatch.setattr(adapters.sys, "platform", "linux")
    monkeypatch.setenv("WAYLAND_DISPLAY", "wayland-0")
    monkeypatch.setenv("DISPLAY", ":0")
    monkeypatch.setenv("CLIPROOM_CLIPBOARD_BACKEND", "xclip")

    def which(binary: str) -> str | None:
        if binary in {"wl-paste", "wl-copy", "xclip"}:
            return f"/usr/bin/{binary}"
        return None

    monkeypatch.setattr(adapters.shutil, "which", which)
    adapter = adapters.create_default_adapter()
    assert isinstance(adapter, adapters.XclipClipboardAdapter)
