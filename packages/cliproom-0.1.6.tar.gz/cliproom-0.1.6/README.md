# ClipRoom

Clipboard sharing across live sessions.

ClipRoom synchronizes clipboard content between multiple devices connected
to the same session.

------------------------------------------------------------------------

## Features

- automatic clipboard synchronization
- shared sessions
- LAN discovery
- multiple MIME formats

------------------------------------------------------------------------

## Installation

    pip install cliproom

------------------------------------------------------------------------

## Quick Start

Create a session:

    cliproom host devteam

Join the session:

    cliproom join devteam

Discover sessions on LAN:

    cliproom discover

------------------------------------------------------------------------

## Documentation

See the `docs/` folder.

- architecture.md
- protocol.md
- discovery.md
- cli.md
- clipboard.md
- roadmap.md

------------------------------------------------------------------------

## Project Structure

    cliproom/
        client/
        server/
        protocol/
        discovery/
        clipboard/
        cli/
    docs/

------------------------------------------------------------------------

## Protocol

ClipRoom uses **CRP (Clipboard Replication Protocol)**.

CRP is an application-level protocol for clipboard synchronization.
