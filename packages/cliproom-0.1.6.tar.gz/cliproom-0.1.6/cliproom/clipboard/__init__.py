"""Clipboard adapters."""

from .adapters import (
    ClipboardAdapter,
    ClipboardUnavailableError,
    SUPPORTED_MIME_TYPES,
    create_default_adapter,
)

__all__ = [
    "ClipboardAdapter",
    "ClipboardUnavailableError",
    "SUPPORTED_MIME_TYPES",
    "create_default_adapter",
]
