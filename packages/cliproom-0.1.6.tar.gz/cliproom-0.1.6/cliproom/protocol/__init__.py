"""CRP contracts and helpers."""

from .codec import decode_message_line, encode_message, hash_passphrase, parse_message
from .constants import (
    CRP_VERSION,
    DEFAULT_DISCOVERY_PORT,
    DEFAULT_DISCOVERY_TIMEOUT_SECONDS,
    DEFAULT_TCP_PORT,
    MAX_MESSAGE_BYTES,
)
from .errors import ProtocolValidationError
from .messages import (
    ClipboardFormat,
    ClipMessage,
    DiscoverMessage,
    DiscoverReplyMessage,
    ErrorMessage,
    HeartbeatMessage,
    JoinAckMessage,
    JoinMessage,
    LeaveMessage,
)
from .types import CRPMessage, JSONObject, JSONValue, MessageType

__all__ = [
    "CRP_VERSION",
    "DEFAULT_TCP_PORT",
    "DEFAULT_DISCOVERY_PORT",
    "DEFAULT_DISCOVERY_TIMEOUT_SECONDS",
    "MAX_MESSAGE_BYTES",
    "ProtocolValidationError",
    "ClipboardFormat",
    "JoinMessage",
    "JoinAckMessage",
    "ClipMessage",
    "LeaveMessage",
    "HeartbeatMessage",
    "ErrorMessage",
    "DiscoverMessage",
    "DiscoverReplyMessage",
    "CRPMessage",
    "MessageType",
    "JSONValue",
    "JSONObject",
    "parse_message",
    "encode_message",
    "decode_message_line",
    "hash_passphrase",
]
