"""Protocol-specific error types."""


class ProtocolValidationError(ValueError):
    """Raised when a message does not satisfy CRP contracts."""

