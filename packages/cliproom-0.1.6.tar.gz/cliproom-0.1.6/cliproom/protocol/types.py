"""Shared typing aliases for protocol layer."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal, TypeAlias

if TYPE_CHECKING:
    from .messages import (
        ClipMessage,
        DiscoverMessage,
        DiscoverReplyMessage,
        ErrorMessage,
        HeartbeatMessage,
        JoinAckMessage,
        JoinMessage,
        LeaveMessage,
    )

MessageType: TypeAlias = Literal[
    "join",
    "join_ack",
    "clip",
    "leave",
    "heartbeat",
    "error",
    "discover",
    "discover_reply",
]

JSONScalar: TypeAlias = str | int | float | bool | None
JSONValue: TypeAlias = JSONScalar | list["JSONValue"] | dict[str, "JSONValue"]
JSONObject: TypeAlias = dict[str, JSONValue]

if TYPE_CHECKING:
    CRPMessage: TypeAlias = (
        JoinMessage
        | JoinAckMessage
        | ClipMessage
        | LeaveMessage
        | HeartbeatMessage
        | ErrorMessage
        | DiscoverMessage
        | DiscoverReplyMessage
    )
else:
    CRPMessage: TypeAlias = Any
