"""Built-in code scorers (CodeScorer subclasses / async score() functions).

Scorer files use the ``_scorer`` suffix (e.g. ``gpumode_scorer.py``) to
disambiguate from the identically-named bench modules under
``wafer.eval.bench.<name>``.

Each scorer invokes its corresponding bench script as a subprocess via
``python -m wafer.eval.bench.<name>``, parses the JSON output printed to
stdout, and returns a ``Score`` object.
"""
