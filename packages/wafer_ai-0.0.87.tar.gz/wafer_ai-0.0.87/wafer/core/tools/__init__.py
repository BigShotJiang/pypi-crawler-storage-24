"""Tool executors.

Each file contains both a Tool schema definition and an exec_* function that returns ToolResult.

Imports are lazy: tools are only loaded when accessed, avoiding heavy deps
(pandas, numpy, asyncssh) at CLI startup time.
"""
from __future__ import annotations

import importlib
from typing import Any

_TOOL_REGISTRY: dict[str, tuple[str, list[str]]] = {
    "wafer.core.tools.bash_tool": [
        "BASH_TOOL",
        "ApprovalCallback",
        "BashPermission",
        "BashPermissionResult",
        "check_bash_permissions",
        "exec_bash",
    ],
    "wafer.core.tools.file_tools": [
        "EDIT_TOOL",
        "GLOB_TOOL",
        "GREP_TOOL",
        "READ_TOOL",
        "WRITE_TOOL",
        "exec_edit",
        "exec_glob",
        "exec_grep",
        "exec_read",
        "exec_write",
    ],
    "wafer.core.tools.skill_tool": [
        "SKILL_TOOL",
        "exec_skill",
    ],
    "wafer.core.tools.pull_session_files_tool": [
        "PULL_SESSION_FILES_TOOL",
        "exec_pull_session_files",
    ],
    "wafer.core.tools.sandbox_run_tool": [
        "SANDBOX_RUN_TOOL",
        "exec_sandbox_run",
    ],
    "wafer.core.tools.subagent_tool": [
        "SUBAGENT_TOOL",
        "exec_subagent",
    ],
}

_NAME_TO_MODULE: dict[str, str] = {}
for _mod, _names in _TOOL_REGISTRY.items():
    for _name in _names:
        _NAME_TO_MODULE[_name] = _mod


def __getattr__(name: str) -> Any:
    module_path = _NAME_TO_MODULE.get(name)
    if module_path is not None:
        mod = importlib.import_module(module_path)
        val = getattr(mod, name)
        globals()[name] = val
        return val
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = list(_NAME_TO_MODULE.keys())
