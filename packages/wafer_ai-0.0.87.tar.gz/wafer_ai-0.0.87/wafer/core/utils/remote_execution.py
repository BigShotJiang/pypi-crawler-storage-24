"""Remote execution utilities for GPU benchmark environments.
Pure functions for setting up and running code on remote GPU servers.
Tiger Style:
- Pure functions (no hidden state)
- Explicit error handling
- Clear separation of concerns
"""
import logging
from dataclasses import replace
from pathlib import Path

from wafer.core.kernel.deployment import (
    DeploymentConfig,
    DeploymentState,
    TestKernelParams,
    setup_deployment,
    test_kernel,
)
from wafer.core.utils.execution_types import KernelExecutionContext, ProfilingArtifactConfig

logger = logging.getLogger(__name__)


async def setup_remote_deployment(
    ssh_target: str,
    ssh_key: str,
    gpu_id: int,
    benchmark_name: str,
    project_subdir: str | None = None,
    dataset_path: str | None = None,
    workspace_path: str = "~/.wafer/workspaces/wafer",
) -> tuple[DeploymentState | None, str | None]:
    """Setup remote GPU environment for code execution.
    Deploys codebase via bifrost and sets up venv.
    Args:
        ssh_target: SSH connection string (user@host:port)
        ssh_key: Path to SSH key file
        gpu_id: GPU ID to use
        benchmark_name: Benchmark name ("gpumode", "leetgpu", etc.)
        project_subdir: Optional project subdirectory (e.g., "benchmarks/leetgpu")
        dataset_path: Optional dataset path (e.g., "datasets/leetgpu_problems.jsonl")
        workspace_path: Remote workspace path
    Returns:
        Tuple of (deployment_state, error_message)
        - deployment_state: DeploymentState if successful, None on error
        - error_message: Error string if failed, None on success
    Example:
        >>> state, err = await setup_remote_deployment(
        ...     ssh_target="user@host:22",
        ...     ssh_key="~/.ssh/id_rsa",
        ...     gpu_id=0,
        ...     benchmark_name="gpumode",
        ... )
        >>> if err:
        ...     print(f"Setup failed: {err}")
        >>> else:
        ...     print("Deployment ready!")
    """
    # Tiger Style: Explicit parameters instead of kwargs dict
    # GPUMode doesn't use these - it relies on full wafer monorepo deployment
    if benchmark_name == "leetgpu" and project_subdir and dataset_path:
        config = DeploymentConfig(
            ssh_target=ssh_target,
            ssh_key=ssh_key,
            gpu_id=gpu_id,
            workspace_path=workspace_path,
            project_subdir=project_subdir,
            dataset_path=dataset_path,
        )
    else:
        config = DeploymentConfig(
            ssh_target=ssh_target,
            ssh_key=ssh_key,
            gpu_id=gpu_id,
            workspace_path=workspace_path,
        )

    state, err = await setup_deployment(config)
    if err:
        logger.error(f"deployment setup failed: {err}")
        return None, err
    return state, None


async def execute_kernel_remote(
    deployment_state: DeploymentState,
    kernel_code: str,
    context: KernelExecutionContext,
    profiling_config: ProfilingArtifactConfig | None = None,
) -> dict:
    """Execute kernel code on remote GPU with correctness and benchmark testing.
    Two-phase execution:
    1. Correctness tests (required)
    2. Benchmark tests (only if correctness passes)
    3. Optional profiling (if requested and benchmarks pass)
    Args:
        deployment_state: Remote deployment state
        kernel_code: Code to execute
        context: Execution context (problem, test suite, benchmark info)
        profiling_config: Configuration for profiling and artifact collection
    Returns:
        Dict with keys:
            - compiled: bool
            - error_message: str | None
            - correctness_score: float (0.0 to 1.0)
            - all_correct: bool
            - passed_tests: int
            - total_tests: int
            - geomean_speedup: float
    Example:
        >>> ctx = KernelExecutionContext(
        ...     problem_id="p1",
        ...     sample_data={...},
        ...     test_suite="correctness",
        ...     reference_backend="reference",
        ...     benchmark_name="gpumode",
        ...     benchmark_suite="benchmark",
        ... )
        >>> results = await execute_kernel_remote(
        ...     deployment_state=state,
        ...     kernel_code="def solve(A, B): return A + B",
        ...     context=ctx,
        ... )
        >>> if results["all_correct"]:
        ...     print(f"Speedup: {results['geomean_speedup']:.2f}x")
    """
    if profiling_config is None:
        profiling_config = ProfilingArtifactConfig()
    # Prepare problem_id (LeetGPU needs special formatting)
    formatted_problem_id = (
        f"challenge_{context.problem_id}" if context.benchmark_name == "leetgpu" else context.problem_id
    )
    # Tiger Style: Explicit dataclass instead of kwargs dict
    test_params = TestKernelParams(
        state=deployment_state,
        kernel_code=kernel_code,
        backend_name="agent",
        test_suite=context.test_suite,
        reference_backend=context.reference_backend,
        problem_id=formatted_problem_id,
        sample_data=context.sample_data,
        profile=False,
        ncu=False,
        language_filter=context.language,  # None if not provided
        artifact_dir=str(profiling_config.artifacts_dir) if profiling_config.artifacts_dir else None,
    )
    # PHASE 1: Correctness tests
    logger.debug("   Running correctness tests...")
    results, err = await test_kernel(test_params)
    if err:
        return {
            "compiled": False,
            "error_message": err,
            "correctness_score": 0.0,
            "all_correct": False,
            "passed_tests": 0,
            "total_tests": 0,
            "geomean_speedup": 0.0,
        }
    # If no error, results must be valid (test_kernel contract)
    assert results is not None, "test_kernel returned no error but results is None"
    # PHASE 2: Benchmark tests (only if correctness passes)
    if results.all_correct:
        logger.debug("   [ok] Correctness passed - running benchmarks...")
        # Switch to benchmark suite
        # Tiger Style: Create new immutable params instead of mutating dict
        benchmark_params = replace(test_params, test_suite=context.benchmark_suite)
        # Run benchmarks WITHOUT profiling first
        results_benchmark, err_benchmark = await test_kernel(benchmark_params)
        if not err_benchmark:
            assert results_benchmark is not None, "test_kernel returned no error but results is None"
            results = results_benchmark
            logger.debug(f"   Benchmark speedup: {results.geomean_speedup:.2f}x")
            # PHASE 3: Optional profiling
            if profiling_config.profile_on_success:
                logger.debug("   Running profiling: profile=True")
                profiled_params = replace(
                    benchmark_params,
                    backend_name="agent_profiled",
                    profile=True,
                    ncu=False,
                )
                _, err_profile = await test_kernel(profiled_params)
                if not err_profile:
                    logger.debug("   [ok] Profiling data collected")
                else:
                    logger.warning(f"   [warn]  Profiling failed: {err_profile}")
    return {
        "compiled": True,
        "error_message": None,
        "correctness_score": results.correctness_score,
        "all_correct": results.all_correct,
        "passed_tests": (
            len([t for t in results.correctness_tests if t.get("is_correct", False)])
            if results.correctness_tests
            else 0
        ),
        "total_tests": len(results.correctness_tests) if results.correctness_tests else 0,
        "geomean_speedup": results.geomean_speedup,
    }
