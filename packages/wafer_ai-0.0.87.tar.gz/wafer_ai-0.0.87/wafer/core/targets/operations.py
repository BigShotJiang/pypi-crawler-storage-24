"""Target operations: SSH info resolution, file sync, target loading.

Extracted from wafer.cli.targets_ops and wafer.cli.targets so that
core code (e.g. sandbox_run_tool) can use these without depending
on the CLI package.
"""
from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from wafer.core.infra.async_ssh import SyncSSHClient
    from wafer.core.targets.config import (
        BaremetalTarget,
        TargetConfig,
        VMTarget,
    )

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class TargetSSHInfo:
    """SSH connection info for a target."""
    host: str
    port: int
    user: str
    key_path: Path


class TargetExecError(Exception):
    """Error during target operation (exec/ssh/sync)."""
    pass


def _expand_key_path(ssh_key: str) -> Path:
    """Expand SSH key path (synchronous, fast operation)."""
    return Path(ssh_key).expanduser()


async def get_target_ssh_info(target: TargetConfig) -> TargetSSHInfo:
    """Get SSH connection info for a target.

    For Baremetal/VM: Returns configured SSH info directly.
    For Modal/Workspace: Raises (no SSH access).
    """
    from wafer.core.targets.config import (
        BaremetalTarget,
        ModalTarget,
        VMTarget,
        WorkspaceTarget,
    )
    if isinstance(target, (BaremetalTarget, VMTarget)):
        return _get_direct_ssh_info(target)
    elif isinstance(target, WorkspaceTarget):
        raise TargetExecError(
            f"WorkspaceTarget '{target.name}' uses API-based access.\n"
            "Use wafer target sync for file transfer. For command execution, use the sandbox tool."
        )
    elif isinstance(target, ModalTarget):
        raise TargetExecError(
            f"ModalTarget '{target.name}' is serverless and has no SSH access.\n"
            "Use 'wafer tool eval' to run code on Modal targets."
        )
    raise TargetExecError(f"Unknown target type: {type(target).__name__}")


def _get_direct_ssh_info(target: BaremetalTarget | VMTarget) -> TargetSSHInfo:
    """Get SSH info for Baremetal/VM target (no provisioning needed)."""
    from wafer.core.infra.ssh_utils import parse_ssh_target

    parsed = parse_ssh_target(target.ssh_target)
    key_path = _expand_key_path(target.ssh_key)
    if not key_path.exists():
        raise TargetExecError(f"SSH key not found: {key_path}")
    return TargetSSHInfo(
        host=parsed.host,
        port=parsed.port,
        user=parsed.user,
        key_path=key_path,
    )


def _make_client(ssh_info: TargetSSHInfo) -> SyncSSHClient:
    """Create a SyncSSHClient from TargetSSHInfo."""
    from wafer.core.infra.async_ssh import SyncSSHClient
    connection_str = f"{ssh_info.user}@{ssh_info.host}:{ssh_info.port}"
    return SyncSSHClient(connection_str, str(ssh_info.key_path))


def sync_to_target(
    ssh_info: TargetSSHInfo,
    local_path: Path,
    remote_path: str | None = None,
    on_progress: Callable[[str], None] | None = None,
) -> int:
    """Sync files to target via SyncSSHClient (rsync under the hood).
    Returns number of files synced.
    """
    if remote_path is None:
        resolved = local_path.resolve()
        if resolved.is_file():
            remote_path = "/tmp"
        else:
            assert resolved.name, f"Cannot derive remote dir from local path: {local_path}"
            remote_path = f"/tmp/{resolved.name}"
    if on_progress:
        on_progress(f"Syncing {local_path} to {ssh_info.host}:{remote_path}")
    client = _make_client(ssh_info)
    try:
        result = client.upload_files(
            local_path=str(local_path.resolve()),
            remote_path=remote_path,
            recursive=local_path.is_dir(),
        )
        if not result.success:
            raise TargetExecError(f"Upload failed: {result.error_message}")
        if on_progress:
            on_progress(f"Synced {result.files_copied} files")
        return result.files_copied
    finally:
        client.close()


_cache_loaded_targets: dict[str, TargetConfig | None] = {}


def load_target(name: str) -> TargetConfig:
    """Load target config by name from the API. Results are cached for the process lifetime."""
    if name in _cache_loaded_targets:
        cached = _cache_loaded_targets[name]
        if cached is None:
            raise FileNotFoundError(
                f"Target not found: {name}\n"
                f"  Register with: wafer target init ssh --name {name} --host <user>@<host>"
            )
        return cached
    from wafer.cli.user_targets_api import get_target_by_name, user_target_to_baremetal_target
    t = get_target_by_name(name)
    if t is None:
        _cache_loaded_targets[name] = None
        raise FileNotFoundError(
            f"Target not found: {name}\n"
            f"  Register with: wafer target init ssh --name {name} --host <user>@<host>"
        )
    result = user_target_to_baremetal_target(t)
    _cache_loaded_targets[name] = result
    return result


def invalidate_target_cache() -> None:
    """Reset loaded-target cache. Call after mutating targets (create, delete)."""
    _cache_loaded_targets.clear()
