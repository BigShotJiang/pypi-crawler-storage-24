"""Metric computation for kernel scope analysis."""

from wafer.core.profiling.kernel_scope.metrics.occupancy import (
    OccupancyResult,
    compute_occupancy,
)

__all__ = [
    "compute_occupancy",
    "OccupancyResult",
]
