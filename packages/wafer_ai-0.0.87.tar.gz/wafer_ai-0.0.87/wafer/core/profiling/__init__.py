"""Profiling tool interfaces.

Stateful classes for ROCprofiler and Perfetto profiling tools.
"""


# Lazy imports to avoid loading heavy dependencies
def __getattr__(name: str):
    """Lazy import profiling tool components."""
    if name in ("PerfettoTool", "PerfettoConfig"):
        from wafer.core.profiling.perfetto import PerfettoConfig, PerfettoTool
        if name == "PerfettoTool":
            return PerfettoTool
        return PerfettoConfig
    
    if name in ("TraceManager", "TraceMeta"):
        from wafer.core.profiling.perfetto import TraceManager, TraceMeta
        if name == "TraceManager":
            return TraceManager
        return TraceMeta
    
    if name in ("TraceProcessorManager", "TraceProcessorStatus"):
        from wafer.core.profiling.perfetto import (
            TraceProcessorManager,
            TraceProcessorStatus,
        )
        if name == "TraceProcessorManager":
            return TraceProcessorManager
        return TraceProcessorStatus
    
    if name in ("rocprofiler", "perfetto", "distributed_traces"):
        import importlib
        return importlib.import_module(f"wafer.core.profiling.{name}")
    
    raise AttributeError(f"module 'wafer.core.profiling' has no attribute {name!r}")
