"""Kernel trace tool for discovering SOTA kernels.

Given a PyTorch operation, traces what kernel PyTorch dispatches to on target hardware.

Usage:
    from wafer.core.dispatch_baseline import quick_trace

    result = quick_trace(
        "torch.matmul(A, B)",
        {"A": (4096, 4096), "B": (4096, 4096)},
        hardware="H100",
    )
    print(result.summary())
"""
from __future__ import annotations

import importlib
from typing import Any

_ATTR_MODULES = {
    "lookup_baseline": "wafer.core.dispatch_baseline.client",
    "store_baseline": "wafer.core.dispatch_baseline.client",
    "generate_trace_script": "wafer.core.dispatch_baseline.codegen",
    "parse_op_string": "wafer.core.dispatch_baseline.codegen",
    "update_dtypes": "wafer.core.dispatch_baseline.codegen",
    "update_shapes": "wafer.core.dispatch_baseline.codegen",
    "HardwareSpec": "wafer.core.dispatch_baseline.dtypes",
    "KernelInfo": "wafer.core.dispatch_baseline.dtypes",
    "KernelTraceConfig": "wafer.core.dispatch_baseline.dtypes",
    "KernelTraceResult": "wafer.core.dispatch_baseline.dtypes",
    "OpSpec": "wafer.core.dispatch_baseline.dtypes",
    "RooflineAnalysis": "wafer.core.dispatch_baseline.dtypes",
    "TensorSpec": "wafer.core.dispatch_baseline.dtypes",
    "TraceExecutionResult": "wafer.core.dispatch_baseline.executor",
    "quick_trace": "wafer.core.dispatch_baseline.executor",
    "trace_kernel_local": "wafer.core.dispatch_baseline.executor",
    "trace_kernel_remote": "wafer.core.dispatch_baseline.executor",
    "HARDWARE_SPECS": "wafer.core.dispatch_baseline.roofline",
    "compute_roofline": "wafer.core.dispatch_baseline.roofline",
    "get_hardware_spec": "wafer.core.dispatch_baseline.roofline",
}


def __getattr__(name: str) -> Any:
    module_path = _ATTR_MODULES.get(name)
    if module_path is not None:
        mod = importlib.import_module(module_path)
        val = getattr(mod, name)
        globals()[name] = val
        return val
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = list(_ATTR_MODULES.keys())
