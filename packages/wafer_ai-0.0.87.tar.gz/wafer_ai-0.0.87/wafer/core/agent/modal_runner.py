"""Modal target runner for CLI agents.

Runs agents in WaferSandbox on Modal container targets.
Called by run_cli_agent() when use_modal=True.
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable
from uuid import uuid4

import modal

from wafer.core.dtypes import Trajectory

from .subprocess_agents import CLIAgentConfig, CLIAgentResult, _parse_agent_output, build_cli_command

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class _ModalSandbox:
    """WaferSandbox wrapping a modal.Sandbox container target."""

    id: str
    _modal_sandbox: object
    target_name: str = "modal"
    gpu_ids: tuple[int, ...] = ()

    @property
    def target_type(self) -> str:
        return "modal"

    @property
    def workspace_dir(self) -> str:
        return "/workspace"


async def run_cli_agent_modal(
    config: CLIAgentConfig,
    instruction: str,
    working_dir: Path,
    on_stream_line: Callable[[dict[str, Any]], None] | None = None,
) -> CLIAgentResult:
    """Run a CLI agent inside a Modal Sandbox.

    Same interface as the local subprocess path in run_cli_agent(),
    but executes inside an isolated container. Uses the same
    build_cli_command() and _parse_agent_output() functions.
    """
    from wafer.core.agent.modal_sandbox_utils import (
        build_agent_image,
        get_agent_secrets,
    )

    assert config is not None
    assert instruction
    assert config.agent == "wafer"

    cmd = build_cli_command(config, instruction)
    logger.info("modal_run agent=%s cmd=%s", config.agent, cmd[:5])

    start_time = time.perf_counter()
    raw_output_chunks: list[str] = []

    image = build_agent_image(config.agent)
    secrets = get_agent_secrets(config.agent)

    sandbox = modal.Sandbox.create(
        image=image,
        secrets=[secrets],
        workdir="/workspace",
        timeout=int(config.timeout_sec),
    )
    wafer_sandbox = _ModalSandbox(id=f"modal-{uuid4().hex[:8]}", _modal_sandbox=sandbox)

    process = sandbox.exec(*cmd)

    for line in process.stdout:
        raw_output_chunks.append(line)

        if on_stream_line is not None:
            stripped = line.strip()
            if stripped:
                try:
                    obj = json.loads(stripped)
                    on_stream_line(obj)
                except json.JSONDecodeError:
                    pass  # non-JSON lines from agent stderr/warnings — skip

    process.wait()
    duration_sec = time.perf_counter() - start_time
    raw_output = "".join(raw_output_chunks)

    messages = _parse_agent_output(config.agent, raw_output)
    error = None
    if process.returncode != 0:
        stderr_text = process.stderr.read()
        error = f"Exit code {process.returncode}: {stderr_text[:500]}"

    sandbox.terminate()

    return CLIAgentResult(
        trajectory=Trajectory(messages=messages),
        raw_output=raw_output,
        duration_sec=duration_sec,
        exit_code=process.returncode,
        session_id=None,
        error=error,
    )
