"""JsonFrontend - NDJSON output for scripting and piping.
Emits newline-delimited JSON for each event. Supports two formats:
- "claude-code": Claude Code stream-json with turn aggregation
- "extension": Real-time chunk events for extensions/UIs
"""
from __future__ import annotations

import json
import sys
import time
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from wafer.core.dtypes import StreamEvent, ToolCall


class JsonFrontend:
    """NDJSON streaming frontend.
    Emits one JSON object per line for each event.

    format="claude-code" (default):
        {"type":"system","subtype":"init","session_id":"abc123","tools":["read","write"]}
        {"type":"assistant","message":{"content":[{"type":"text","text":"Hello"}]}}
        {"type":"result","subtype":"success","session_id":"abc123","num_turns":1}

    format="extension":
        {"type":"session_started","session_id":"abc123","model":"claude-sonnet-4.5"}
        {"type":"text_delta","delta":"Hello"}
        {"type":"session_complete"}
    """
    def __init__(
        self,
        file: object | None = None,
        include_thinking: bool = False,
        include_timing: bool = True,
        format: str = "claude-code",  # noqa: A002
    ) -> None:
        assert format in ("claude-code", "extension"), f"Unknown format: {format!r}"
        self.file = file or sys.stdout
        self.include_thinking = include_thinking
        self.include_timing = include_timing
        self._format = format
        # Shared state
        self._start_time: float = 0
        self._num_turns: int = 0
        self._session_id: str | None = None
        self._tools: list[str] = []
        self._model: str | None = None
        # Token tracking
        self._total_input_tokens: int = 0
        self._total_output_tokens: int = 0
        self._total_cache_read_tokens: int = 0
        self._total_cache_write_tokens: int = 0
        # Turn aggregation state (claude-code format)
        self._current_text: list[str] = []
        self._current_thinking: list[str] = []
        self._current_tool_calls: list[dict] = []
        self._current_turn_tools: list[str] = []
        self._tool_results: dict[str, dict] = {}
        # Extension format state
        self._stopped: bool = False
        self._session_start_emitted: bool = False

    _EVAL_RESULT_PREFIX = "EVAL_RESULT_JSON:"

    def _emit(self, obj: dict) -> None:
        """Emit a single NDJSON line."""
        print(json.dumps(obj, ensure_ascii=False), file=self.file, flush=True)

    @staticmethod
    def _reward_from_metrics(metrics: list[dict]) -> float:
        """Weighted average of metrics with weight > 0, matching Score.reward."""
        weighted = [(m["value"], m.get("weight", 0.0)) for m in metrics if m.get("weight", 0.0) > 0]
        if not weighted:
            return 0.0
        total_weight = sum(w for _, w in weighted)
        return sum(v * w for v, w in weighted) / total_weight

    def _extract_score(self, event: object) -> dict | None:
        """Extract score data from a ToolResultReceived event.

        Checks two sources:
        1. event.details with metrics (structured path)
        2. EVAL_RESULT_JSON: prefix in tool output text (from submit_eval.py / bash)
        """
        details = getattr(event, "details", None)
        if details and "metrics" in details:
            metrics = details["metrics"]
            out = {"reward": self._reward_from_metrics(metrics), "metrics": metrics}
            if "task_id" in details:
                out["task_id"] = details["task_id"]
            return out

        content = getattr(event, "content", None)
        if not isinstance(content, str):
            return None
        for line in content.splitlines():
            if not line.startswith(self._EVAL_RESULT_PREFIX):
                continue
            try:
                data = json.loads(line[len(self._EVAL_RESULT_PREFIX):])
            except (json.JSONDecodeError, ValueError):
                continue
            if not isinstance(data, dict):
                continue
            if "metrics" in data and isinstance(data["metrics"], list):
                metrics = data["metrics"]
                out = {"reward": self._reward_from_metrics(metrics), "metrics": metrics}
                if "task_id" in data:
                    out["task_id"] = data["task_id"]
                return out
            if "score" in data:
                out = {"reward": float(data["score"]), "metrics": data}
                if "task_id" in data:
                    out["task_id"] = data["task_id"]
                return out
        return None

    # --- Turn aggregation (claude-code format) ---

    def _flush_assistant_turn(self) -> None:
        """Emit aggregated assistant turn for Claude Code compatibility.

        Text and tool_use blocks are omitted since they were already emitted
        incrementally (text_delta, tool_call_start/end). Only thinking blocks
        (when enabled) are included here since they may not have been streamed.
        The assistant message is still emitted for parsers that consume the
        aggregated format (eval harness, session persistence).
        """
        content = []

        if self._current_thinking and self.include_thinking:
            thinking_text = "".join(self._current_thinking).strip()
            if thinking_text:
                content.append({"type": "thinking", "thinking": thinking_text})

        text = "".join(self._current_text).strip()
        if text:
            content.append({"type": "text", "text": text})

        content.extend(self._current_tool_calls)
        if content:
            self._emit({"type": "assistant", "message": {"content": content}})
            self._num_turns += 1
            self._emit({
                "type": "turn_end",
                "finish_reason": "stop",
                "turn": self._num_turns,
                "usage": {
                    "input_tokens": self._total_input_tokens,
                    "output_tokens": self._total_output_tokens,
                    "cache_read_tokens": self._total_cache_read_tokens,
                    "cache_write_tokens": self._total_cache_write_tokens,
                },
                "tools_used": self._current_turn_tools,
            })
        self._current_text = []
        self._current_thinking = []
        self._current_tool_calls = []
        self._current_turn_tools = []

    # --- Session lifecycle ---

    async def start(self) -> None:
        """Emit init event."""
        self._start_time = time.time()
        if self._format == "extension":
            if self._session_id:
                self._emit({
                    "type": "session_started",
                    "session_id": self._session_id,
                    "model": self._model,
                })
                self._session_start_emitted = True
            return
        self._emit({
            "type": "system",
            "subtype": "init",
            "session_id": self._session_id or "",
            "tools": self._tools,
        })

    async def stop(self) -> None:
        """Emit result/completion event."""
        if self._format == "extension":
            self._stopped = True
            return
        self._flush_assistant_turn()
        result = {
            "type": "result",
            "subtype": "success",
            "session_id": self._session_id or "",
            "num_turns": self._num_turns,
            "usage": {
                "input_tokens": self._total_input_tokens,
                "output_tokens": self._total_output_tokens,
                "cache_read_tokens": self._total_cache_read_tokens,
                "cache_write_tokens": self._total_cache_write_tokens,
            },
        }
        if self.include_timing:
            result["duration_ms"] = int((time.time() - self._start_time) * 1000)
        self._emit(result)

    def emit_session_start(self, session_id: str, model: str | None = None) -> None:
        """Emit session_started event (called by runner for new sessions)."""
        if self._session_start_emitted:
            return
        self._emit({
            "type": "session_started",
            "session_id": session_id,
            "model": model if model else self._model,
        })
        self._session_start_emitted = True

    def finalize(self, session_id: str | None = None) -> None:
        """Emit session_started (if needed) and session_complete (extension format)."""
        if self._format != "extension":
            return
        if session_id and not self._session_start_emitted:
            self.emit_session_start(session_id)
        self._emit({"type": "session_complete"})

    # --- Event handling ---

    async def handle_event(self, event: StreamEvent) -> None:
        """Handle streaming event by emitting JSON."""
        if self._format == "extension":
            return await self._handle_event_extension(event)
        return await self._handle_event_claude_code(event)

    async def _handle_event_claude_code(self, event: StreamEvent) -> None:
        """Claude Code format: aggregates assistant turns."""
        from wafer.core.dtypes import (
            LLMCallEnd,
            StreamDone,
            StreamError,
            TextDelta,
            ThinkingDelta,
            ToolCallDelta,
            ToolCallEnd,
            ToolCallStart,
            ToolResultDelta,
            ToolResultReceived,
        )
        if isinstance(event, LLMCallEnd):
            if event.tokens_in is not None:
                self._total_input_tokens += event.tokens_in
            if event.tokens_out is not None:
                self._total_output_tokens += event.tokens_out
            if event.cache_read_tokens is not None:
                self._total_cache_read_tokens += event.cache_read_tokens
            if event.cache_write_tokens is not None:
                self._total_cache_write_tokens += event.cache_write_tokens
        elif isinstance(event, TextDelta):
            self._current_text.append(event.delta)
            if event.delta:
                self._emit({"type": "text_delta", "delta": event.delta})
        elif isinstance(event, ThinkingDelta):
            self._current_thinking.append(event.delta)
            if event.delta and self.include_thinking:
                self._emit({"type": "thinking_delta", "delta": event.delta})
        elif isinstance(event, ToolCallStart):
            self._emit({
                "type": "tool_call_start",
                "id": event.tool_call_id,
                "name": event.tool_name,
            })
        elif isinstance(event, ToolCallDelta):
            self._emit({
                "type": "tool_call_delta",
                "id": event.tool_call_id,
                "partial_args": event.partial_args,
            })
        elif isinstance(event, ToolCallEnd):
            self._emit({
                "type": "tool_call_end",
                "id": event.tool_call.id,
                "name": event.tool_call.name,
                "args": dict(event.tool_call.args),
            })
            self._current_tool_calls.append({
                "type": "tool_use",
                "id": event.tool_call.id,
                "name": event.tool_call.name,
                "input": dict(event.tool_call.args),
            })
            self._current_turn_tools.append(event.tool_call.name)
        elif isinstance(event, ToolResultReceived):
            self._flush_assistant_turn()
            content = event.content
            if isinstance(content, list):
                content = json.dumps(content)
            payload: dict[str, object] = {
                "type": "tool_result",
                "tool_call_id": event.tool_call_id,
                "content": str(content),
                "is_error": event.is_error,
            }
            if event.error:
                payload["error"] = event.error
            if event.details:
                payload["details"] = event.details
            self._emit(payload)
            score_data = self._extract_score(event)
            if score_data is not None:
                payload = {
                    "type": "score",
                    "tool_call_id": event.tool_call_id,
                    "reward": score_data.get("reward", 0),
                    "metrics": score_data.get("metrics", {}),
                    "turn": self._num_turns,
                    "usage": {
                        "input_tokens": self._total_input_tokens,
                        "output_tokens": self._total_output_tokens,
                        "cache_read_tokens": self._total_cache_read_tokens,
                        "cache_write_tokens": self._total_cache_write_tokens,
                    },
                }
                if "task_id" in score_data:
                    payload["task"] = score_data["task_id"]
                self._emit(payload)
        elif isinstance(event, ToolResultDelta):
            self._emit({
                "type": "tool_result_delta",
                "tool_call_id": event.tool_call_id,
                "delta": event.delta,
            })
        elif isinstance(event, StreamDone):
            self._flush_assistant_turn()
        elif isinstance(event, StreamError):
            self._flush_assistant_turn()
            self._emit({
                "type": "error",
                "error": str(event.error),
            })

    async def _handle_event_extension(self, event: StreamEvent) -> None:
        """Extension format: real-time chunk events without turn aggregation."""
        from wafer.core.dtypes import (
            StreamDone,
            StreamError,
            TextDelta,
            ThinkingDelta,
            ToolCallEnd,
            ToolCallStart,
            ToolResultDelta,
            ToolResultReceived,
        )
        if isinstance(event, TextDelta):
            self._emit({"type": "text_delta", "delta": event.delta})
        elif isinstance(event, ThinkingDelta):
            pass
        elif isinstance(event, ToolCallStart):
            self._emit({
                "type": "tool_call_start",
                "id": event.tool_call_id,
                "name": event.tool_name,
            })
        elif isinstance(event, ToolCallEnd):
            tool_call = event.tool_call
            self._emit({
                "type": "tool_call_end",
                "id": tool_call.id,
                "name": tool_call.name,
                "args": dict(tool_call.args) if tool_call.args else {},
            })
            self._num_turns += 1
        elif isinstance(event, ToolResultReceived):
            result_event: dict[str, object] = {"type": "tool_result", "is_error": event.is_error}
            if event.error:
                result_event["error"] = event.error
            if event.content:
                if isinstance(event.content, list):
                    result_event["content"] = "\n".join(
                        str(item) if not isinstance(item, dict) else item.get("text", str(item))
                        for item in event.content
                    )
                else:
                    result_event["content"] = str(event.content)
            self._emit(result_event)
            score_data = self._extract_score(event)
            if score_data is not None:
                score_payload: dict[str, object] = {
                    "type": "score",
                    "reward": score_data.get("reward", 0),
                    "metrics": score_data.get("metrics", {}),
                    "turn": self._num_turns,
                }
                if "task_id" in score_data:
                    score_payload["task"] = score_data["task_id"]
                self._emit(score_payload)
        elif isinstance(event, ToolResultDelta):
            self._emit({
                "type": "tool_result_delta",
                "tool_call_id": event.tool_call_id,
                "delta": event.delta,
            })
        elif isinstance(event, StreamDone):
            pass
        elif isinstance(event, StreamError):
            self._emit({"type": "error", "error": str(event.error)})

    async def get_input(self, prompt: str = "") -> str:
        """Get user input - not supported in JSON mode."""
        raise RuntimeError(
            "JsonFrontend does not support interactive input. "
            "Use -p to provide input or resume with --session."
        )

    async def confirm_tool(self, tool_call: ToolCall) -> bool:
        """Auto-approve all tools in JSON mode."""
        return True

    def show_loader(self, text: str) -> None:
        """No-op for JSON mode."""
        pass

    def hide_loader(self) -> None:
        """No-op for JSON mode."""
        pass

    def set_status(
        self,
        *,
        model: str | None = None,
        session_id: str | None = None,
        input_tokens: int | None = None,
        output_tokens: int | None = None,
        cost: float | None = None,
        env_info: dict[str, str] | None = None,
    ) -> None:
        """Track status for result emission."""
        if session_id is not None:
            self._session_id = session_id
        if model is not None:
            self._model = model

    def set_tools(self, tools: list[str]) -> None:
        """Set tool names for init event."""
        self._tools = tools
