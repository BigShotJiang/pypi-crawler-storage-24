"""Sandbox types.

WaferSandbox = isolated agent workspace on a target (protocol).
Sandbox = SSH-based implementation (tmux session on a remote machine).
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable


@runtime_checkable
class WaferSandbox(Protocol):
    """Isolated agent workspace on a target. Target-agnostic.

    Every agent runs in a WaferSandbox. Every WaferSandbox lives on a Target.
    Implementations: Sandbox (SSH/tmux), LocalSandbox, ModalTargetSandbox.
    """

    @property
    def id(self) -> str: ...

    @property
    def target_name(self) -> str: ...

    @property
    def target_type(self) -> str: ...

    @property
    def workspace_dir(self) -> str: ...

    @property
    def gpu_ids(self) -> tuple[int, ...]: ...


@dataclass(frozen=True)
class Sandbox:
    """SSH-based sandbox: persistent tmux session on a remote GPU machine.

    Implements WaferSandbox with target_type="ssh".
    """

    id: str
    target_name: str
    tmux_session: str
    ssh_target: str
    ssh_key: str
    created_at: str
    timeout_hours: int
    gpu_vendor: str | None = None
    gpu_count: int = 0
    gpu_ids: tuple[int, ...] = ()

    @property
    def target_type(self) -> str:
        return "ssh"

    @property
    def workspace_dir(self) -> str:
        return f"/tmp/.wafer_sandbox/{self.tmux_session}"
