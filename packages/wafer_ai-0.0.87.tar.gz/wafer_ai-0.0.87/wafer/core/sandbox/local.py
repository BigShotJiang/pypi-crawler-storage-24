"""LocalSandbox: WaferSandbox implementation for local machine execution."""
from __future__ import annotations

import shutil
from dataclasses import dataclass
from pathlib import Path
from uuid import uuid4


@dataclass(frozen=True)
class LocalSandbox:
    """WaferSandbox on the local machine.

    Creates an isolated workspace directory under workspace_base_dir.
    Satisfies the WaferSandbox protocol with target_type="local".
    """

    id: str
    workspace_dir: str
    target_name: str = "local"
    gpu_ids: tuple[int, ...] = ()

    @property
    def target_type(self) -> str:
        return "local"

    def cleanup(self) -> None:
        shutil.rmtree(self.workspace_dir, ignore_errors=True)


def create_local_sandbox(
    workspace_base_dir: str = "/tmp/wafer-sandboxes",
) -> LocalSandbox:
    """Create a new local sandbox with an isolated workspace directory."""
    sandbox_id = f"sandbox-{uuid4().hex[:8]}"
    workspace = Path(workspace_base_dir) / sandbox_id
    workspace.mkdir(parents=True, exist_ok=True)
    return LocalSandbox(id=sandbox_id, workspace_dir=str(workspace))
