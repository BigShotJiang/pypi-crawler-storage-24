# Changelog


## [v3.1] - 2026-03-14

**Fixes:**
- `@after` ignoring dependencies not explicitly in search terms.


## [v3.0] - 2026-02-14

**Breaking change:** `@after` filenames are now resolved relative to the
file containing the directive, supporting

```
@after ../project-b/setup.md
@after subtask/notes.md
@after ~/tasks/dependency.md
```

Previously `whatnext` assumed a flat hierarchy of unique filenames.

**Added:**
- `@phase` directive in section headers creates a dependency chain within
  the file; the first phase is always visible, and subsequent phases
  will only show when all previous phases are complete.

**Fixes:**
- `@after` referencing a file excluded by `--ignore` no longer warns about
  the file not existing, instead treating the dependency as complete.


## [v2.0] - 2026-02-09

Added `@queue` directive show only one task at a time, for simple sequential
work that doesn't need to be split across files using `@after`.

**Fixes:**
- Annotation and priority indicators were not appearing for headerless files


## [v2.0] - 2026-01-28

**Breaking change:** `whatnext` now ignores tasks and headers within
quoting elements -- blockquotes, code fences, and indented text.

**Fixes:**
- bug in relative summaries was reusing characters for different states


## [v1.4] - 2026-01-27

`next` now shows a diff of the change made to the task file.

Prefer `tasks.md` in the current directory to `~/tasks.md`.

**Fixes:**
- Bare `@after` waiting for all incomplete tasks, including those with
  `@after file.md` dependencies.
- `next` rejecting task text containing flag-like arguments (e.g. `-e`).
- `next -a` inserting after the last task instead of at the end of the file.


## [v1.3.2] - 2026-01-11

Fixed repeated warnings when a file has a missing `@after` dependency.

Added `--ignore-after` flag to show all outstanding tasks regardless of
`@after` constraints.


## [v1.3.1] - 2026-01-10

Fixed file-level `@after` being ignored when the file has no headings.


## [v1.3] - 2026-01-09

Added `next` command to quickly add tasks from the command line.

Files can self-exclude from results using `@notnext`.


## [v1.2] - 2026-01-08

Files, sections, or individual tasks can be deferred using `@after` to hide
them until other tasks are complete.

Added `--guide` to show a short Markdown formatting reference, separating
it out of the `--help` usage.


## [v1.1] - 2025-12-04

Fixed relative summaries to include all tasks, not just some.

Removed slashes from summary columns for cleaner output.

Added `-e`/`--edit` flag to open task files in your editor at the line number
of the first matching task.


## [v1.0] - 2025-12-02

Output is now colour-coded by default, override with `--color/--no-color`
or by setting `WHATNEXT_COLOR`.

Focused task selection:

- `whatnext 5` will show the five highest status tasks.
- `whatnext 5r` will show five randomly selected tasks.

Annotations, including a ` ```whatnext ` fenced block allows notes that appear
in context in the output.

Include totals in summaries.


## [v0.5] - 2025-12-01

Tasks can have deadlines using the `@YYYY-MM-DD/4w` syntax. As the deadline
approaches, the task's priority automatically shifts to `imminent` (two weeks
before by default). Once past the deadline, the priority becomes `overdue`.


## [v0.4] - 2025-12-01

Individual tasks and sections of tasks can be marked with emphasis to denote
\_medium\_ priority or as \*\*high\*\* priority. They will be displayed at the
top of the output, each priority in separate blocks.


## [v0.3] — 2025-11-29

Adding more states to the roster, tasks can be marked as open (unstarted),
in progress, cancelled, blocked, and completed.

Tasks can be filtered by any of these states when showing tasks or summaries.


## [v0.2] — 2025-11-28

Filtering tasks by text/header can be helpful. And as useful as it
can be to use `--dir` to specify the base dir, sometimes you just
want to do it quicker, so you can also specify a dir or file as
an argument to restrict searching just to that.

Arguments can be mixed and matched freely. Multiple search terms
are additive not exclusive.


## [v0.1] — 2025-11-28

First version, very basic. Lists tasks found in Markdown files in a
given directory. Can produce summaries.
