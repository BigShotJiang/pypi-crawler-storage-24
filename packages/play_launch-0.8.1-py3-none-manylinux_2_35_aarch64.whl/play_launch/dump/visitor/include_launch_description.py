import logging
import os

from launch.actions.include_launch_description import IncludeLaunchDescription
from launch.actions.set_launch_configuration import SetLaunchConfiguration
from launch.launch_context import LaunchContext
from launch.launch_description_entity import LaunchDescriptionEntity
from launch.utilities import normalize_to_list_of_substitutions, perform_substitutions

from ..launch_dump import LaunchDump, extract_package_from_path

logger = logging.getLogger(__name__)


def visit_include_launch_description(
    include: IncludeLaunchDescription, context: LaunchContext, dump: LaunchDump
) -> list[LaunchDescriptionEntity]:
    """Execute the action."""
    launch_description = include.launch_description_source.get_launch_description(context)

    # Push scope for this include
    try:
        launch_file_path = include._get_launch_file()
    except Exception as e:
        logger.debug("Could not resolve include launch file path: %s", e)
        launch_file_path = None
    filename = os.path.basename(launch_file_path) if launch_file_path else "unknown"
    pkg = extract_package_from_path(launch_file_path) if launch_file_path else None

    # Get namespace from context
    ns = context.launch_configurations.get("ros_namespace", "/")

    # Get include args
    include_args = {}
    for arg_name, arg_value in include.launch_arguments:
        try:
            resolved_name = perform_substitutions(
                context, normalize_to_list_of_substitutions(arg_name)
            )
            resolved_value = perform_substitutions(
                context, normalize_to_list_of_substitutions(arg_value)
            )
            include_args[resolved_name] = resolved_value
        except Exception as e:
            logger.debug("Could not resolve include arg '%s': %s", arg_name, e)

    dump.push_scope(pkg, filename, ns, include_args)

    # If the location does not exist, then it's likely set to '<script>' or something.
    context.extend_locals(
        {
            "current_launch_file_path": launch_file_path,
        }
    )
    context.extend_locals(
        {
            "current_launch_file_directory": include._get_launch_file_directory(),
        }
    )

    # Do best effort checking to see if non-optional, non-default declared arguments
    # are being satisfied.
    my_argument_names = [
        perform_substitutions(context, normalize_to_list_of_substitutions(arg_name))
        for arg_name, arg_value in include.launch_arguments
    ]
    declared_launch_arguments = (
        launch_description.get_launch_arguments_with_include_launch_description_actions()
    )
    for argument, ild_actions in declared_launch_arguments:
        if argument._conditionally_included or argument.default_value is not None:
            continue
        argument_names = my_argument_names
        if ild_actions is not None:
            for ild_action in ild_actions:
                argument_names.extend(ild_action._try_get_arguments_names_without_context())
        if argument.name not in argument_names:
            raise RuntimeError(
                "Included launch description missing required argument '{}' "
                "(description: '{}'), given: [{}]".format(
                    argument.name, argument.description, ", ".join(argument_names)
                )
            )

    # Create actions to set the launch arguments into the launch configurations.
    set_launch_configuration_actions = []
    for name, value in include.launch_arguments:
        set_launch_configuration_actions.append(SetLaunchConfiguration(name, value))

    # Set launch arguments as launch configurations and then include the launch description.
    return [*set_launch_configuration_actions, launch_description]
