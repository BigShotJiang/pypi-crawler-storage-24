from setuptools import setup, find_packages
from pathlib import Path
import sys

# 1) Locate this script’s directory reliably
this_dir = Path(__file__).resolve().parent

# 2) Find any README file, preferring .md
readme_path = this_dir / "README.md"
if not readme_path.exists():
    readme_candidates = [p for p in this_dir.glob("[Rr][Ee][Aa][Dd][Mm][Ee]*") if p.is_file()]
    if not readme_candidates:
        print(f"❌ Could not find a README file in {this_dir}", file=sys.stderr)
        print("Files present:", [p.name for p in this_dir.iterdir()], file=sys.stderr)
        sys.exit(1)
    # Prefer .md if available among candidates
    readme_path = next((p for p in readme_candidates if p.suffix.lower() == ".md"), readme_candidates[0])

long_description = readme_path.read_text(encoding="utf-8")

# 3) Extract version
version_dict = {}
with open(this_dir / "langxchange" / "__version__.py") as f:
    exec(f.read(), version_dict)
version = version_dict.get("__version__", "0.0.1")

setup(
    name="langxchange",
    version=version,
    description="AI Framework for fast integration of Private Data and LLM, Agent Ochestration Platform",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Timothy Owusu",
    author_email="support@langxchange.ai",
    packages=find_packages(),
    install_requires=[
        "pandas",
        "sentence-transformers",
        "chromadb",
        "pinecone-client",
        "sqlalchemy",
        "pymongo",
        "pymysql",
        "numpy",
        "google-generativeai",
        "openai",
        "anthropic",
        "weaviate-client",
        "qdrant-client",
        "elasticsearch",
        "elasticsearch-dsl",
        "opensearch-py",
        "faiss-cpu",
        "pymilvus>=2.3.0",
        "tiktoken",
        "tenacity",
        "aiohttp",
        "requests",
        "pillow",
        "SpeechRecognition",
        "pydub",
        "voyageai"
    ],
    python_requires=">=3.8",
)
