pub mod clone;
pub mod cp;
pub mod create;
pub mod create_sandbox_image;
pub mod exec;
pub mod ls;
pub mod port;
pub mod resume;
pub mod run;
pub mod snapshot;
pub mod snapshot_ls;
pub mod snapshot_rm;
pub mod ssh;
pub mod suspend;
pub mod terminate;

use crate::auth::context::CliContext;
use crate::error::{CliError, Result};
use chrono::{DateTime, Local, TimeZone, Utc};
use tokio::time::{Duration, Instant};

/// Build the lifecycle API base URL for sandbox CRUD operations.
///
/// Cloud mode: `{api_url}/sandboxes`, `{api_url}/snapshots/...`
/// Localhost mode: `{api_url}/v1/namespaces/{namespace}/sandboxes`
pub fn sandbox_endpoint(ctx: &CliContext, endpoint: &str) -> String {
    if is_localhost(&ctx.api_url) {
        format!(
            "{}/v1/namespaces/{}/{}",
            ctx.api_url, ctx.namespace, endpoint
        )
    } else {
        format!("{}/{}", ctx.api_url, endpoint)
    }
}

pub const DEFAULT_SANDBOX_WAIT_TIMEOUT: Duration = Duration::from_secs(120);
const SANDBOX_WAIT_POLL_INTERVAL: Duration = Duration::from_secs(1);

pub fn new_spinner(message: &str) -> indicatif::ProgressBar {
    let spinner = indicatif::ProgressBar::new_spinner();
    spinner.set_style(
        indicatif::ProgressStyle::default_spinner()
            .tick_strings(&["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"])
            .template("{spinner} {msg}")
            .unwrap(),
    );
    spinner.set_message(message.to_string());
    spinner.enable_steady_tick(std::time::Duration::from_millis(80));
    spinner
}

pub async fn wait_for_sandbox_status(
    ctx: &CliContext,
    sandbox_id: &str,
    waiting_message: &str,
    target_status: &str,
    timeout: Duration,
) -> Result<String> {
    let client = ctx.client()?;

    let spinner = new_spinner(&format!("{}...", waiting_message));

    let deadline = Instant::now() + timeout;
    loop {
        if Instant::now() > deadline {
            spinner.finish_with_message(format!("{} timed out", waiting_message));
            return Err(CliError::Other(anyhow::anyhow!(
                "Sandbox {} did not reach '{}' within {}s",
                sandbox_id,
                target_status,
                timeout.as_secs()
            )));
        }

        let info_resp = client
            .get(sandbox_endpoint(ctx, &format!("sandboxes/{sandbox_id}")))
            .send()
            .await
            .map_err(CliError::Http)?;

        if info_resp.status().is_success() {
            let info: serde_json::Value = info_resp.json().await.map_err(CliError::Http)?;
            let current_status = info
                .get("status")
                .and_then(|value| value.as_str())
                .unwrap_or("")
                .to_string();

            if current_status == target_status {
                spinner.finish_with_message(format!("{} {}", waiting_message, current_status));
                return Ok(current_status);
            }

            if current_status == "terminated" && target_status != "terminated" {
                spinner.finish_with_message(format!("{} terminated", waiting_message));
                return Err(CliError::Other(anyhow::anyhow!(
                    "Sandbox terminated while waiting to reach '{}'",
                    target_status
                )));
            }
        }

        tokio::time::sleep(SANDBOX_WAIT_POLL_INTERVAL).await;
    }
}

/// Build the proxy base URL for a specific sandbox (process/file/PTY operations).
///
/// The proxy URL uses subdomain-based routing: `{sandbox_id}.sandbox.example.com`
/// For localhost, it uses `localhost:9443` with a Host header override.
pub fn sandbox_proxy_base(ctx: &CliContext, sandbox_id: &str) -> (String, Option<String>) {
    let proxy_url = resolve_proxy_url(&ctx.api_url);

    if let Ok(parsed) = url::Url::parse(&proxy_url) {
        let host = parsed.host_str().unwrap_or("");
        if host == "localhost" || host == "127.0.0.1" {
            // Localhost: keep URL as-is, set Host header to {sandbox_id}.local
            let host_header = format!("{}.local", sandbox_id);
            return (proxy_url, Some(host_header));
        }
        // Cloud: prefix sandbox_id as subdomain
        let port_part = parsed.port().map(|p| format!(":{}", p)).unwrap_or_default();
        let base_url = format!("{}://{}.{}{}", parsed.scheme(), sandbox_id, host, port_part);
        return (base_url, None);
    }

    // Fallback
    (format!("{}/{}", proxy_url, sandbox_id), None)
}

/// Resolve the sandbox proxy URL from env or api_url.
fn resolve_proxy_url(api_url: &str) -> String {
    if let Ok(url) = std::env::var("TENSORLAKE_SANDBOX_PROXY_URL") {
        return url;
    }
    if is_localhost(api_url) {
        return "http://localhost:9443".to_string();
    }
    if let Ok(parsed) = url::Url::parse(api_url) {
        let host = parsed.host_str().unwrap_or("");
        if let Some(rest) = host.strip_prefix("api.") {
            let proxy_host = format!("sandbox.{}", rest);
            return format!("{}://{}", parsed.scheme(), proxy_host);
        }
    }
    "https://sandbox.tensorlake.ai".to_string()
}

fn is_localhost(url: &str) -> bool {
    if let Ok(parsed) = url::Url::parse(url) {
        let host = parsed.host_str().unwrap_or("");
        return host == "localhost" || host == "127.0.0.1";
    }
    false
}

/// Parse `sandbox_id:/remote/path` syntax.
pub fn parse_sandbox_path(path: &str) -> (Option<&str>, &str) {
    if let Some(colon_pos) = path.find(':') {
        let prefix = &path[..colon_pos];
        // Avoid matching single-letter drive letters (Windows)
        if prefix.len() > 1 {
            return (Some(prefix), &path[colon_pos + 1..]);
        }
    }
    (None, path)
}

/// Parse KEY=VALUE environment variable pairs.
pub fn parse_env_vars(env: &[String]) -> Result<Option<serde_json::Value>> {
    if env.is_empty() {
        return Ok(None);
    }
    let mut map = serde_json::Map::new();
    for item in env {
        let eq_pos = item.find('=').ok_or_else(|| {
            crate::error::CliError::usage(format!("Invalid env format: {}. Use KEY=VALUE.", item))
        })?;
        let key = &item[..eq_pos];
        let value = &item[eq_pos + 1..];
        map.insert(
            key.to_string(),
            serde_json::Value::String(value.to_string()),
        );
    }
    Ok(Some(serde_json::Value::Object(map)))
}

pub fn format_created_at(value: Option<&serde_json::Value>) -> String {
    let Some(timestamp) = created_at_sort_key(value) else {
        return "-".to_string();
    };

    let now = Utc::now();
    let age = now.signed_duration_since(timestamp);

    if age < chrono::TimeDelta::zero() || age > chrono::TimeDelta::days(5) {
        return timestamp
            .with_timezone(&Local)
            .format("%Y-%m-%d %H:%M")
            .to_string();
    }

    if age < chrono::TimeDelta::minutes(1) {
        let seconds = age.num_seconds().max(0);
        return format_relative(seconds, "sec");
    }

    if age < chrono::TimeDelta::hours(1) {
        return format_relative(age.num_minutes(), "min");
    }

    if age < chrono::TimeDelta::days(1) {
        return format_relative(age.num_hours(), "hr");
    }

    format_relative(age.num_days(), "day")
}

fn format_relative(value: i64, unit: &str) -> String {
    let suffix = if unit == "day" && value != 1 { "s" } else { "" };
    format!("{value} {unit}{suffix} ago")
}

pub fn created_at_sort_key(value: Option<&serde_json::Value>) -> Option<DateTime<Utc>> {
    match value? {
        serde_json::Value::String(timestamp) => DateTime::parse_from_rfc3339(timestamp)
            .ok()
            .map(|dt| dt.with_timezone(&Utc)),
        serde_json::Value::Number(timestamp) => parse_numeric_timestamp(timestamp.as_f64()?),
        _ => None,
    }
}

fn parse_numeric_timestamp(timestamp: f64) -> Option<DateTime<Utc>> {
    let seconds = if timestamp > 1e15 {
        timestamp / 1_000_000.0
    } else if timestamp > 1e12 {
        timestamp / 1_000.0
    } else {
        timestamp
    };

    let whole_seconds = seconds.trunc() as i64;
    let nanos = ((seconds.fract() * 1_000_000_000.0).round() as u32).min(999_999_999);
    Utc.timestamp_opt(whole_seconds, nanos).single()
}

#[cfg(test)]
mod tests {
    use super::format_created_at;
    use chrono::{Duration, Utc};

    #[test]
    fn format_created_at_uses_relative_time_for_recent_timestamps() {
        let timestamp = serde_json::Value::String((Utc::now() - Duration::minutes(3)).to_rfc3339());
        let formatted = format_created_at(Some(&timestamp));

        assert_eq!(formatted, "3 min ago");
    }

    #[test]
    fn format_created_at_uses_absolute_time_after_five_days() {
        let timestamp = serde_json::Value::String((Utc::now() - Duration::days(6)).to_rfc3339());
        let formatted = format_created_at(Some(&timestamp));

        assert!(!formatted.ends_with("ago"));
        assert!(formatted.contains('-'));
        assert!(formatted.contains(':'));
    }
}
