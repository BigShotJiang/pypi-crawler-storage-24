from __future__ import annotations

from textual.app import App

from termchat.api import ApiClient
from termchat.config import CONFIG_DIR
from termchat.themes import DEFAULT_THEME, THEMES


class TermChatApp(App):
    CSS_PATH = "termchat.tcss"
    TITLE = "termchat"

    def __init__(self) -> None:
        super().__init__()
        self.api = ApiClient()

    def on_ready(self) -> None:
        for t in THEMES:
            self.register_theme(t)

        theme_file = CONFIG_DIR / "theme"
        if theme_file.exists():
            saved = theme_file.read_text().strip()
            theme_names = [t.name for t in THEMES]
            if saved in theme_names:
                self.theme = saved
                return
        self.theme = DEFAULT_THEME

    async def on_mount(self) -> None:
        from termchat.auth import load_tokens

        tokens = load_tokens()
        if tokens:
            # Push chat screen immediately — it handles loading data itself
            from termchat.screens.chat import ChatScreen
            self.push_screen(ChatScreen())
            # Check for updates in background
            import asyncio
            asyncio.create_task(self._check_update())
            # Ensure E2E keys exist and are uploaded
            asyncio.create_task(self._ensure_e2e_keys())
            return

        from termchat.screens.login import LoginScreen
        self.push_screen(LoginScreen())

    async def _check_update(self) -> None:
        """Check PyPI for newer version."""
        try:
            import importlib.metadata
            current = importlib.metadata.version("trmchat")
            resp = await self.api._client.get("https://pypi.org/pypi/trmchat/json", timeout=3.0)
            if resp.status_code == 200:
                latest = resp.json()["info"]["version"]
                if latest != current:
                    if self.screen:
                        self.screen.notify(
                            f"update available: v{current} \u2192 v{latest}\npip install --upgrade trmchat",
                            timeout=6,
                        )
        except Exception:
            pass

    async def _ensure_e2e_keys(self) -> None:
        """Generate keypair if needed and upload public key to server."""
        try:
            from termchat.crypto import generate_keypair, get_public_key_b64, has_keypair
            me = await self.api.get_me()
            username = me.get("username", "")
            if not username:
                return

            if not has_keypair(username):
                generate_keypair(username)

            pub_b64 = get_public_key_b64(username)
            if pub_b64 and me.get("public_key") != pub_b64:
                await self.api.update_profile(public_key=pub_b64)
        except Exception:
            pass

    async def on_unmount(self) -> None:
        try:
            await self.api.close()
        except Exception:
            pass


def _cli_send(args: list[str]) -> None:
    import asyncio
    import sys

    if not args:
        print("usage: termchat send @username [message]")
        print("       echo 'text' | termchat send @username")
        sys.exit(1)

    target = args[0].lstrip("@")

    if len(args) > 1:
        message = " ".join(args[1:])
    elif not sys.stdin.isatty():
        message = sys.stdin.read().strip()
    else:
        print("no message provided")
        sys.exit(1)

    if not message:
        print("empty message")
        sys.exit(1)

    asyncio.run(_async_send(target, message))


async def _async_send(target: str, message: str) -> None:
    import sys

    from termchat.api import ApiClient
    from termchat.auth import load_tokens

    tokens = load_tokens()
    if not tokens:
        print("not logged in — run 'termchat' to log in first")
        sys.exit(1)

    api = ApiClient()
    try:
        users = await api.search_users(target)
        exact = next((u for u in users if u.get("username") == target), None)
        if not exact:
            print(f"user '{target}' not found")
            sys.exit(1)

        conv = await api.create_conversation("dm", [exact["id"]])
        await api.send_message(conv["id"], message)
        print(f"sent to @{target}")
    except Exception as e:
        print(f"error: {e}")
        sys.exit(1)
    finally:
        await api.close()


def _cli_pipe(args: list[str]) -> None:
    import asyncio
    import sys

    if not args:
        print("usage: tail -f log.txt | termchat pipe @username")
        sys.exit(1)

    target = args[0].lstrip("@")
    asyncio.run(_async_pipe(target))


async def _async_pipe(target: str) -> None:
    import sys

    from termchat.api import ApiClient
    from termchat.auth import load_tokens

    tokens = load_tokens()
    if not tokens:
        print("not logged in — run 'termchat' to log in first")
        sys.exit(1)

    api = ApiClient()
    try:
        users = await api.search_users(target)
        exact = next((u for u in users if u.get("username") == target), None)
        if not exact:
            print(f"user '{target}' not found")
            sys.exit(1)

        conv = await api.create_conversation("dm", [exact["id"]])
        conv_id = conv["id"]

        count = 0
        for line in sys.stdin:
            line = line.rstrip("\n")
            if line:
                await api.send_message(conv_id, line)
                count += 1

        print(f"sent {count} messages to @{target}")
    except KeyboardInterrupt:
        pass
    except Exception as e:
        print(f"error: {e}")
        sys.exit(1)
    finally:
        await api.close()


def _cli_status(args: list[str]) -> None:
    import asyncio

    asyncio.run(_async_status(args))


async def _async_status(args: list[str]) -> None:
    import json as jsonlib
    import sys

    from termchat.api import ApiClient
    from termchat.auth import load_tokens

    tokens = load_tokens()
    if not tokens:
        if "--json" in args:
            print(jsonlib.dumps({"logged_in": False}))
        elif "--unread" in args:
            print("0")
        else:
            print("not logged in")
        return

    api = ApiClient()
    try:
        me = await api.get_me()
        convs = await api.get_conversations()
        total_unread = sum(c.get("unread_count", 0) for c in convs)

        if "--json" in args:
            print(jsonlib.dumps({
                "logged_in": True,
                "username": me.get("username"),
                "status": me.get("status"),
                "conversations": len(convs),
                "unread": total_unread,
            }))
        elif "--unread" in args:
            print(str(total_unread))
        else:
            username = me.get("username", "?")
            status = me.get("status", "?")
            print(f"@{username} ({status})")
            print(f"{len(convs)} conversations, {total_unread} unread")
    except Exception as e:
        if "--json" in args:
            print(jsonlib.dumps({"logged_in": False, "error": str(e)}))
        elif "--unread" in args:
            print("0")
        else:
            print(f"error: {e}")
    finally:
        await api.close()


def _cli_help() -> None:
    print("""termchat — terminal messaging for developers

USAGE
  termchat                     launch the TUI chat client
  termchat send @user [msg]    send a message (or pipe from stdin)
  termchat pipe @user          stream stdin lines as messages
  termchat status              show account & unread count
  termchat status --json       machine-readable status (for tmux)
  termchat status --unread     just print unread count
  termchat version             show version
  termchat help                show this help

EXAMPLES
  termchat send @alice "deploy is done"
  echo "build failed" | termchat send @bob
  tail -f app.log | termchat pipe @ops-channel
  tmux set -g status-right "#(termchat status --unread) unread"

DOCS
  https://github.com/difa/term-chat
""")


def main() -> None:
    import sys

    args = sys.argv[1:]

    if not args:
        app = TermChatApp()
        app.run()
        return

    cmd = args[0]

    if cmd == "send":
        _cli_send(args[1:])
    elif cmd == "pipe":
        _cli_pipe(args[1:])
    elif cmd == "status":
        _cli_status(args[1:])
    elif cmd == "version":
        print("termchat v3.3.3")
    elif cmd == "help" or cmd == "--help" or cmd == "-h":
        _cli_help()
    else:
        print(f"unknown command: {cmd}")
        print("run 'termchat help' for usage")
        sys.exit(1)


if __name__ == "__main__":
    main()
