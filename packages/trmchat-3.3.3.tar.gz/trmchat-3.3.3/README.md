# termchat

[![PyPI](https://img.shields.io/pypi/v/trmchat)](https://pypi.org/project/trmchat/)
[![Python 3.10+](https://img.shields.io/badge/python-3.10%2B-blue)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/license-MIT-green)](LICENSE)

A terminal-based chat application for developers. Real-time messaging, end-to-end encryption, file sharing, code snippets, and full keyboard-driven workflow — all inside your terminal.

<!-- screenshot -->

## Quick Start

### Install

```bash
pip install trmchat
```

### Run

```bash
termchat
```

On first launch you will be prompted to create an account or log in. The client connects to the hosted server at `romantic-spirit-production-7063.up.railway.app` by default.

To connect to a self-hosted server:

```bash
TERMCHAT_SERVER=https://myserver.com termchat
```

## Features

- **Real-time messaging** — WebSocket-powered instant delivery
- **Direct messages and group chats** — one-on-one or multi-person conversations
- **End-to-end encryption** — X25519 key exchange + AES-256-GCM for DMs; the server never sees plaintext
- **Message replies, reactions, editing, and deletion** — full message interaction
- **File sharing** — send and receive files up to 2 MB
- **Code snippets** — share code with syntax highlighting
- **User status** — set yourself as available, away, or do-not-disturb with custom status messages
- **User blocking and conversation muting** — control who and what you see
- **Notes to self** — a private scratchpad via `/notes`
- **18 built-in themes** — customize the look from settings
- **CLI integration** — send messages, pipe output, and read status from scripts
- **Auto-update check** — get notified when a new version is available
- **tmux integration** — display unread counts in your status bar

## Commands

| Command | Description |
|---|---|
| `/code [lang] <code>` | Share a code snippet with optional language for highlighting |
| `/file <path>` | Share a file (max 2 MB) |
| `/download` | List available files or download one by name |
| `/edit [text]` | Edit your last message |
| `/delete` | Delete your last message |
| `/reply` | Reply to the last message in the conversation |
| `/react <emoji>` | React to the last message with an emoji |
| `/notes` | Open your private notes-to-self chat |
| `/status available\|away\|dnd` | Set your status |
| `/profile [@user]` | View your profile or another user's profile |
| `/search <text>` | Search messages in the current conversation |
| `/rename <name>` | Rename a group chat |
| `/add @user` | Add a user to the current group |
| `/kick @user` | Remove a user from the current group |
| `/block @user` | Block a user |
| `/unblock @user` | Unblock a user |
| `/mute` | Mute the current conversation |
| `/unmute` | Unmute the current conversation |
| `/silent` | Toggle all notification sounds |
| `/password` | Change your password |
| `/info` | Show info about the current chat |
| `/online` | Show online users |
| `/logout` | Log out |
| `/clear` | Clear the current view |
| `/help` | Show the help screen |

Tab completion is supported — type `/` and press `Tab` to cycle through commands.

## Keybindings

| Key | Action |
|---|---|
| `Ctrl+N` | New direct message |
| `Ctrl+G` | New group chat |
| `Ctrl+F` | Search |
| `Ctrl+D` | Delete or leave chat |
| `Ctrl+O` | Settings |
| `Ctrl+L` | Log out |
| `Ctrl+Q` | Quit |
| `Tab` / `Shift+Tab` | Cycle between panels |
| `Escape` | Deselect chat or cancel current action |
| `PageUp` | Load older messages |
| `Up` / `Down` | Input history |
| `Tab` (in `/command`) | Tab completion |

## CLI Integration

termchat can be used non-interactively from scripts, CI pipelines, and other tools.

### Send a message

```bash
termchat send @user "deployment finished"
```

### Pipe from stdin

```bash
echo "build failed" | termchat send @user
```

### Stream lines

```bash
tail -f /var/log/app.log | termchat pipe @user
```

Each line from stdin is sent as a separate message.

### Query status

```bash
# JSON output for scripting
termchat status --json

# Just the unread count
termchat status --unread
```

## End-to-End Encryption

Direct messages are encrypted end-to-end using X25519 for key exchange and AES-256-GCM for message encryption.

- Key pairs are generated on first use and stored locally in `~/.termchat/keys/`
- Public keys are uploaded to the server automatically when you log in
- The server relays ciphertext only — it never has access to plaintext message content
- An **E2E** indicator appears in the chat header when encryption is active
- Group chats are not yet encrypted

No configuration is needed. Encryption is enabled automatically for all DMs when both participants have keys available.

## Themes

termchat ships with 18 built-in themes. Open settings with `Ctrl+O` to browse and apply them. Your selection is saved across sessions.

## Self-Hosting

### Docker Compose

```bash
cd server
docker compose up -d
```

### Railway

Deploy the `server/` directory to Railway. The server reads the standard `PORT` environment variable injected by Railway.

### Connecting clients

Point clients to your server with the `TERMCHAT_SERVER` environment variable:

```bash
export TERMCHAT_SERVER=https://myserver.com
termchat
```

Or set it per invocation:

```bash
TERMCHAT_SERVER=https://myserver.com termchat
```

## tmux Integration

Display your unread message count in the tmux status bar:

```bash
# In .tmux.conf
set -g status-right "#(termchat status --unread) unread"
```

The `termchat status --unread` command prints the count and exits immediately, so it works well as a tmux status command that runs on an interval.

## Configuration

### Environment variables

| Variable | Description | Default |
|---|---|---|
| `TERMCHAT_SERVER` | Server URL | `https://romantic-spirit-production-7063.up.railway.app` |

### Config directory

termchat stores all local data in `~/.termchat/`:

```
~/.termchat/
  keys/        # E2E encryption key pairs
```

## Contributing

Contributions are welcome. The project lives at [github.com/difa/term-chat](https://github.com/difa/term-chat).

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/my-feature`)
3. Commit your changes
4. Push to your fork and open a pull request

Please open an issue first for large changes so the approach can be discussed.

## License

MIT
