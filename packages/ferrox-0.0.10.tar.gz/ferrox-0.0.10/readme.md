# ferrox &nbsp; <img src="docs/assets/ferrox-logo.svg" alt="ferrox logo" width="50">

[![Tests](https://github.com/periodiclabs/ferrox/actions/workflows/test.yml/badge.svg)](https://github.com/periodiclabs/ferrox/actions/workflows/test.yml)
[![PyPI](https://img.shields.io/pypi/v/ferrox?logo=pypi&logoColor=white)](https://pypi.org/project/ferrox)
[![npm](https://img.shields.io/npm/v/matterviz-wasm?logo=npm&logoColor=white)](https://www.npmjs.com/package/matterviz-wasm)

High-performance base layer for computational materials science, written in Rust with Python and WebAssembly bindings. Provides 10-100x speedups for atomistic simulations.

## Features

- **Structure I/O**: Parse CIF, POSCAR, extXYZ, LAMMPS, XDATCAR, and more ([source](src/io))
- **Structure Matching**: Fast deduplication and grouping with parallel processing ([source](src/structure), [notebook](notebooks/06_rust_vs_python_struct_benchmark.py))
- **Symmetry Analysis**: Space groups, Wyckoff positions, primitive/conventional cells ([notebook](notebooks/07_structure_properties_explorer.py))
- **Molecular Dynamics**: NVE/NVT integrators, thermostats, geometry optimizers (FIRE) ([source](src/simulation), [notebook](notebooks/05_md_ensembles_diffusion.py))
- **Surface Science**: Slab generation, Miller indices, adsorption sites, Wulff shapes ([source](src/analysis/surfaces))
- **Defect Engineering**: Vacancies, substitutions, interstitials, Voronoi sites ([source](src/defects), [notebook](notebooks/09_distortions_shakenbreak.py))
- **Trajectory Analysis**: RDF, MSD, diffusion coefficients, Steinhardt order parameters ([source](src/analysis))
- **ML Training Data**: LMDB dataset storage with rkyv zero-copy reads, OCP/fairchem import ([source](src/io/lmdb), [notebook](notebooks/12_lmdb_training_data.py))
- **Properties**: XRD, elastic tensors, coordination, convex hull, oxidation states ([source](src/analysis))
- **Typed Units**: Runtime-checked physical quantities with unit conversion ([source](src/units), [notebook](notebooks/11_typed_units_walkthrough.py))
- **Integrations**: Materials Project REST client, VASP CHGCAR/Fourier support ([source](src/io/mp.rs), [notebook](notebooks/10_chgcar_fourier_analysis.py))
- **Python bindings**: Full OOP API with Structure, Lattice, Composition, Element classes ([source](src/python))
- **WASM bindings**: Browser-ready WebAssembly build for web applications ([source](src/wasm))

## Installation

```bash
pip install ferrox
```

## Usage

```python
from ferrox import Structure, StructureMatcher

# Create structures
s1 = Structure.from_prototype("rocksalt", ["Na", "Cl"], a=5.64)
s2 = Structure.from_prototype("rocksalt", ["Na", "Cl"], a=5.65)

# Compare with desired tolerances
matcher = StructureMatcher(latt_len_tol=0.2, site_pos_tol=0.3, angle_tol=5.0)
is_match = matcher.fit(s1, s2)

# Batch deduplication
unique_indices = matcher.get_unique_indices([s1, s2])
groups = matcher.group([s1, s2])
```

## Development

Requires Rust 1.93+ and Python 3.11+.

```bash
# Build and install in development mode
maturin develop --features python-extension --release

# Run tests
cargo test
```

### Python Type Stubs

Python type stubs (`.pyi` files) are auto-generated from Rust code using `pyo3-stub-gen`. After modifying PyO3-exposed functions or classes, regenerate stubs:

```bash
python bindings/python/generate_stubs.py

# Verify stubs pass type checking
ty check bindings/python/ferrox
```

The script runs `cargo` to generate raw stubs, then cleans them to use modern Python type syntax (`X | None` instead of `Optional[X]`, `list[float]` instead of `builtins.list[builtins.float]`).

The CI pipeline automatically verifies stubs are in sync with Rust code.

## Provenance

`ferrox` was originally developed by [Janosh Riebesell](https://github.com/janosh) as part of the [MatterViz](https://github.com/janosh/matterviz) project, and later extracted into this standalone repo.

## License

MIT
