//! Shared helper functions for Python bindings.

use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::{PyDict, PyList};

use crate::composition::Composition;
use crate::defects;
use crate::io::{parse_structure_json, structure_to_pymatgen_json};
use crate::structure::{ReductionAlgo, Structure};
use crate::units::UnitSymbol;

/// Accept either an int (ITA number) or string (HM symbol) as spacegroup input.
pub struct SpacegroupInput(pub String);

impl pyo3_stub_gen::PyStubType for SpacegroupInput {
    fn type_input() -> pyo3_stub_gen::TypeInfo {
        pyo3_stub_gen::TypeInfo::with_module("int | str", "typing".into())
    }
    fn type_output() -> pyo3_stub_gen::TypeInfo {
        pyo3_stub_gen::TypeInfo::with_module("int | str", "typing".into())
    }
}

impl<'a, 'py> pyo3::FromPyObject<'a, 'py> for SpacegroupInput {
    type Error = PyErr;

    fn extract(ob: pyo3::Borrowed<'a, 'py, pyo3::PyAny>) -> PyResult<Self> {
        if let Ok(num) = ob.extract::<i32>() {
            Ok(Self(num.to_string()))
        } else if let Ok(sym) = ob.extract::<String>() {
            Ok(Self(sym))
        } else {
            Err(PyValueError::new_err(
                "sg must be an int (1-230) or string (e.g. 'Fm-3m')",
            ))
        }
    }
}

/// A structure input that can be either a JSON string, dict, or pymatgen object.
///
/// Accepts:
/// - `ferrox.func(struct)` (pymatgen Structure object directly)
/// - `ferrox.func(struct.as_dict())` (dict from as_dict())
/// - `ferrox.func(json.dumps(struct.as_dict()))` (JSON string)
///
/// Note: Functions using `parse_struct` internally expect periodic Structure data.
/// For molecules, use the dedicated molecule functions (e.g., `parse_molecule_json`).
pub struct StructureJson(pub String);

// Tell pyo3-stub-gen what Python type StructureJson maps to in stubs.
// Accepts str (JSON) or dict (from pymatgen .as_dict()).
impl pyo3_stub_gen::PyStubType for StructureJson {
    fn type_input() -> pyo3_stub_gen::TypeInfo {
        pyo3_stub_gen::TypeInfo::with_module("str | dict[str, Any]", "typing".into())
    }
    fn type_output() -> pyo3_stub_gen::TypeInfo {
        pyo3_stub_gen::TypeInfo::with_module("str | dict[str, Any]", "typing".into())
    }
}

impl<'a, 'py> FromPyObject<'a, 'py> for StructureJson {
    type Error = PyErr;

    fn extract(ob: pyo3::Borrowed<'a, 'py, PyAny>) -> PyResult<Self> {
        use pyo3::types::PyString;
        let py = ob.py();
        let json_module = py.import("json")?;

        // Case 1: JSON string
        if let Ok(s) = ob.cast::<PyString>() {
            return Ok(StructureJson(s.to_string()));
        }

        // Case 2: Dict (e.g. from struct.as_dict())
        if let Ok(dict) = ob.cast::<PyDict>() {
            let json_str: String = json_module.call_method1("dumps", (dict,))?.extract()?;
            return Ok(StructureJson(json_str));
        }

        // Case 3: Object with as_dict() method (e.g. pymatgen Structure/Molecule)
        if ob.hasattr("as_dict")? {
            let dict = ob.call_method0("as_dict")?;
            let json_str: String = json_module.call_method1("dumps", (dict,))?.extract()?;
            return Ok(StructureJson(json_str));
        }

        Err(PyValueError::new_err(
            "Expected a JSON string, dict, or object with as_dict() method (e.g. pymatgen Structure/Molecule)",
        ))
    }
}

macro_rules! define_quantity_input {
    ($name:ident, $doc:expr, $target_unit:expr, $param:expr
     $(, validate: $validate:expr)?) => {
        #[doc = $doc]
        pub struct $name(pub f64);

        impl pyo3_stub_gen::PyStubType for $name {
            fn type_input() -> pyo3_stub_gen::TypeInfo {
                pyo3_stub_gen::TypeInfo::with_module("float | Quantity", "typing".into())
            }
            fn type_output() -> pyo3_stub_gen::TypeInfo {
                pyo3_stub_gen::TypeInfo::with_module("float", "builtins".into())
            }
        }

        impl<'a, 'py> FromPyObject<'a, 'py> for $name {
            type Error = PyErr;

            fn extract(ob: pyo3::Borrowed<'a, 'py, PyAny>) -> PyResult<Self> {
                let value = extract_quantity_or_float(&ob, $target_unit, $param)?;
                $($validate(value, $param)?;)?
                Ok(Self(value))
            }
        }
    };
}

fn validate_non_negative(value: f64, name: &str) -> PyResult<()> {
    if value < 0.0 {
        return Err(PyValueError::new_err(format!(
            "{name} must be non-negative, got {value}"
        )));
    }
    Ok(())
}

fn validate_positive(value: f64, name: &str) -> PyResult<()> {
    if value <= 0.0 {
        return Err(PyValueError::new_err(format!(
            "{name} must be positive, got {value}"
        )));
    }
    Ok(())
}

define_quantity_input!(
    TemperatureInput,
    "Unit-aware non-negative temperature input extracted as Kelvin.",
    UnitSymbol::Kelvin, "temperature",
    validate: validate_non_negative
);

define_quantity_input!(
    PositiveTemperatureInput,
    "Unit-aware positive temperature input extracted as Kelvin (for thermostats).",
    UnitSymbol::Kelvin, "temperature",
    validate: validate_positive
);

define_quantity_input!(
    PositiveTimeInput,
    "Unit-aware positive time input extracted as femtoseconds.",
    UnitSymbol::Femtosecond, "time",
    validate: validate_positive
);

define_quantity_input!(
    PressureInput,
    "Unit-aware pressure input extracted as GPa.",
    UnitSymbol::Gigapascal,
    "pressure"
);

/// Extract a `float | Quantity` argument, converting to the target unit.
fn extract_quantity_or_float<'a, 'py>(
    obj: &pyo3::Borrowed<'a, 'py, PyAny>,
    target_unit: UnitSymbol,
    parameter_name: &str,
) -> PyResult<f64> {
    use super::units::{PyQuantity, coerce_raw_float, map_units_error_to_pyerr};

    if let Ok(quantity_ref) = obj.extract::<PyRef<'_, PyQuantity>>() {
        let value = quantity_ref
            .inner
            .to_unit_symbol(target_unit)
            .map_err(map_units_error_to_pyerr)?;
        return validate_finite(value, parameter_name);
    }
    if let Ok(raw_value) = obj.extract::<f64>() {
        let dimension = target_unit.dimension();
        let value = coerce_raw_float(obj.py(), raw_value, dimension, parameter_name)?;
        return validate_finite(value, parameter_name);
    }
    Err(pyo3::exceptions::PyTypeError::new_err(format!(
        "{parameter_name} expects float or Quantity"
    )))
}

fn validate_finite(value: f64, parameter_name: &str) -> PyResult<f64> {
    if !value.is_finite() {
        return Err(PyValueError::new_err(format!(
            "{parameter_name} must be finite, got {value}"
        )));
    }
    Ok(value)
}

/// Parse an element symbol, returning a PyResult.
pub fn parse_element(symbol: &str) -> PyResult<crate::element::Element> {
    crate::element::Element::from_symbol(symbol)
        .ok_or_else(|| PyValueError::new_err(format!("Unknown element: {symbol}")))
}

/// Parse a composition formula string, returning a PyResult.
pub fn parse_comp(formula: &str) -> PyResult<Composition> {
    Composition::from_formula(formula)
        .map_err(|err| PyValueError::new_err(format!("Error parsing formula: {err}")))
}

/// Parse a structure from StructureJson (string or dict), returning a PyResult.
pub fn parse_struct(input: &StructureJson) -> PyResult<Structure> {
    parse_structure_json(&input.0)
        .map_err(|err| PyValueError::new_err(format!("Error parsing structure: {err}")))
}

/// Convert a JSON string to a Python dict.
pub fn json_to_pydict(py: Python<'_>, json: &str) -> PyResult<Py<PyDict>> {
    let result = py.import("json")?.call_method1("loads", (json,))?;
    Ok(result.cast::<PyDict>()?.clone().unbind())
}

/// Parse a pair of structure inputs, returning a PyResult.
pub fn parse_structure_pair(
    struct1: &StructureJson,
    struct2: &StructureJson,
) -> PyResult<(Structure, Structure)> {
    Ok((parse_struct(struct1)?, parse_struct(struct2)?))
}

/// Convert Vec<String> to Vec<&str> for batch operations.
pub fn to_str_refs(strings: &[String]) -> Vec<&str> {
    strings.iter().map(|s| s.as_str()).collect()
}

/// Check if site indices are within bounds, returning PyIndexError if not.
pub fn check_site_bounds(num_sites: usize, indices: &[usize]) -> PyResult<()> {
    for &idx in indices {
        if idx >= num_sites {
            return Err(pyo3::exceptions::PyIndexError::new_err(format!(
                "Site index {idx} out of bounds (num_sites={num_sites})"
            )));
        }
    }
    Ok(())
}

/// Check if a single site index is within bounds.
#[inline]
pub fn check_site_idx(site_idx: usize, num_sites: usize) -> PyResult<()> {
    if site_idx >= num_sites {
        return Err(pyo3::exceptions::PyIndexError::new_err(format!(
            "Site index {site_idx} out of bounds (num_sites={num_sites})"
        )));
    }
    Ok(())
}

/// Check if a pair of site indices are within bounds.
#[inline]
pub fn check_site_pair(idx_a: usize, idx_b: usize, num_sites: usize) -> PyResult<()> {
    if idx_a >= num_sites || idx_b >= num_sites {
        return Err(pyo3::exceptions::PyIndexError::new_err(format!(
            "Site index out of bounds (num_sites={num_sites})"
        )));
    }
    Ok(())
}

/// Convert a Structure to a Python dict in pymatgen format.
pub fn structure_to_pydict<'py>(
    py: Python<'py>,
    structure: &Structure,
) -> PyResult<Bound<'py, PyDict>> {
    let dict = PyDict::new(py);

    // Pymatgen markers
    dict.set_item("@module", "pymatgen.core.structure")?;
    dict.set_item("@class", "Structure")?;

    // Lattice
    let lattice_dict = PyDict::new(py);
    let mat = structure.lattice.matrix();
    let matrix = PyList::new(
        py,
        [
            PyList::new(py, [mat[(0, 0)], mat[(0, 1)], mat[(0, 2)]])?,
            PyList::new(py, [mat[(1, 0)], mat[(1, 1)], mat[(1, 2)]])?,
            PyList::new(py, [mat[(2, 0)], mat[(2, 1)], mat[(2, 2)]])?,
        ],
    )?;
    lattice_dict.set_item("matrix", matrix)?;
    let lengths = structure.lattice.lengths();
    let angles = structure.lattice.angles();
    lattice_dict.set_item("a", lengths.x)?;
    lattice_dict.set_item("b", lengths.y)?;
    lattice_dict.set_item("c", lengths.z)?;
    lattice_dict.set_item("alpha", angles.x)?;
    lattice_dict.set_item("beta", angles.y)?;
    lattice_dict.set_item("gamma", angles.z)?;
    lattice_dict.set_item("volume", structure.lattice.volume())?;
    lattice_dict.set_item(
        "pbc",
        PyList::new(
            py,
            [
                structure.lattice.pbc[0],
                structure.lattice.pbc[1],
                structure.lattice.pbc[2],
            ],
        )?,
    )?;
    dict.set_item("lattice", lattice_dict)?;

    // Sites with all species and their occupancies
    let mat_t = structure.lattice.matrix().transpose();
    let sites = PyList::empty(py);
    for (site_occ, coord) in structure
        .site_occupancies
        .iter()
        .zip(structure.frac_coords.iter())
    {
        let site = PyDict::new(py);

        // Species list with occupancies
        let species_list = PyList::empty(py);
        for (sp, occ) in &site_occ.species {
            let species_entry = PyDict::new(py);
            species_entry.set_item("element", sp.element.symbol())?;
            species_entry.set_item("occu", occ)?;
            if let Some(oxi) = sp.oxidation_state {
                species_entry.set_item("oxidation_state", oxi)?;
            }
            species_list.append(species_entry)?;
        }
        site.set_item("species", species_list)?;

        // Fractional coordinates
        site.set_item("abc", PyList::new(py, [coord.x, coord.y, coord.z])?)?;

        // Cartesian coordinates: xyz = matrix^T * frac (pymatgen convention)
        let cart = mat_t * coord;
        site.set_item("xyz", PyList::new(py, [cart.x, cart.y, cart.z])?)?;

        let label = site_occ
            .properties
            .get("label")
            .and_then(|v| v.as_str())
            .unwrap_or_else(|| site_occ.dominant_species().element.symbol());
        site.set_item("label", label)?;

        // Site-level properties (excluding label which is at top level)
        let site_props = PyDict::new(py);
        for (key, value) in &site_occ.properties {
            if key != "label" {
                site_props.set_item(key, json_to_py(py, value)?)?;
            }
        }
        site.set_item("properties", site_props)?;

        sites.append(site)?;
    }
    dict.set_item("sites", sites)?;

    // Properties
    let props = PyDict::new(py);
    for (key, value) in &structure.properties {
        // Convert serde_json::Value to Python object
        let py_value = json_to_py(py, value)?;
        props.set_item(key, py_value)?;
    }
    dict.set_item("properties", props)?;

    // Charge (preserve non-zero values for round-tripping)
    dict.set_item("charge", structure.charge)?;

    Ok(dict)
}

/// Convert serde_json::Value to Python object.
pub fn json_to_py(py: Python<'_>, value: &serde_json::Value) -> PyResult<Py<PyAny>> {
    use pyo3::IntoPyObject;

    match value {
        serde_json::Value::Null => Ok(py.None()),
        serde_json::Value::Bool(b) => Ok(b.into_pyobject(py)?.to_owned().unbind().into_any()),
        serde_json::Value::Number(n) => {
            if let Some(idx) = n.as_i64() {
                Ok(idx.into_pyobject(py)?.unbind().into_any())
            } else if let Some(u) = n.as_u64() {
                Ok(u.into_pyobject(py)?.unbind().into_any())
            } else if let Some(f) = n.as_f64() {
                Ok(f.into_pyobject(py)?.unbind().into_any())
            } else {
                Err(PyValueError::new_err("Invalid number in JSON"))
            }
        }
        serde_json::Value::String(s) => Ok(s.into_pyobject(py)?.unbind().into_any()),
        serde_json::Value::Array(arr) => {
            let list: Vec<Py<PyAny>> = arr
                .iter()
                .map(|val| json_to_py(py, val))
                .collect::<PyResult<_>>()?;
            Ok(PyList::new(py, list)?.into_any().unbind())
        }
        serde_json::Value::Object(obj) => {
            let dict = PyDict::new(py);
            for (key, val) in obj {
                dict.set_item(key, json_to_py(py, val)?)?;
            }
            Ok(dict.unbind().into_any())
        }
    }
}

/// Helper to build a Python dict from a DefectStructure result.
pub fn defect_result_to_pydict(
    py: Python<'_>,
    result: &defects::DefectStructure,
) -> PyResult<Py<PyDict>> {
    let dict = PyDict::new(py);
    let struct_json = structure_to_pymatgen_json(&result.structure);
    dict.set_item("structure", json_to_pydict(py, &struct_json)?)?;
    dict.set_item("defect_type", result.defect.defect_type.as_str())?;
    dict.set_item("site_idx", result.defect.site_idx)?;
    dict.set_item("position", result.defect.position.as_slice())?;
    if let Some(ref species) = result.defect.species {
        dict.set_item("species", species.to_string())?;
    }
    if let Some(ref original) = result.defect.original_species {
        dict.set_item("original_species", original.to_string())?;
    }
    Ok(dict.unbind())
}

/// Parse reduction algorithm from string.
pub fn parse_reduction_algo(algo: &str) -> PyResult<ReductionAlgo> {
    match algo.to_lowercase().as_str() {
        "niggli" => Ok(ReductionAlgo::Niggli),
        "lll" => Ok(ReductionAlgo::LLL),
        _ => Err(PyValueError::new_err(format!(
            "Unknown reduction algorithm: {algo}. Use 'niggli' or 'lll'."
        ))),
    }
}

pub(crate) use crate::structure::mat3_to_array;

/// Convert nested array to nalgebra Matrix3.
#[inline]
pub fn array_to_mat3(arr: [[f64; 3]; 3]) -> nalgebra::Matrix3<f64> {
    nalgebra::Matrix3::from_row_slice(&[
        arr[0][0], arr[0][1], arr[0][2], arr[1][0], arr[1][1], arr[1][2], arr[2][0], arr[2][1],
        arr[2][2],
    ])
}

/// Convert slice of [f64; 3] arrays to Vec of nalgebra Vector3.
#[inline]
pub fn positions_to_vec3(positions: &[[f64; 3]]) -> Vec<nalgebra::Vector3<f64>> {
    positions
        .iter()
        .map(|p| nalgebra::Vector3::from(*p))
        .collect()
}

/// Convert slice of nalgebra Vector3 to Vec of [f64; 3] arrays.
#[inline]
pub fn vec3_to_positions(vecs: &[nalgebra::Vector3<f64>]) -> Vec<[f64; 3]> {
    vecs.iter().map(|v| [v.x, v.y, v.z]).collect()
}

/// Default pbc based on whether cell is provided.
/// Returns [true, true, true] if cell is Some, [false, false, false] otherwise.
#[inline]
pub fn default_pbc(pbc: Option<[bool; 3]>, has_cell: bool) -> [bool; 3] {
    pbc.unwrap_or(if has_cell {
        [true, true, true]
    } else {
        [false, false, false]
    })
}

/// Maximum safe integer that can be exactly represented in f64.
pub const MAX_SAFE_F64_INT: f64 = (1_u64 << 53) as f64; // 2^53

/// Validate optional f64 with custom constraint.
#[inline]
pub fn validate_opt<F>(value: Option<f64>, name: &str, constraint: &str, check: F) -> PyResult<()>
where
    F: FnOnce(f64) -> bool,
{
    if let Some(val) = value
        && (!val.is_finite() || !check(val))
    {
        return Err(PyValueError::new_err(format!(
            "{name} must be finite and {constraint}, got {val}"
        )));
    }
    Ok(())
}

/// Validate a required f64 parameter (finite and positive).
#[inline]
pub fn validate_positive_f64(value: f64, name: &str) -> PyResult<()> {
    if !value.is_finite() || value <= 0.0 {
        return Err(PyValueError::new_err(format!(
            "{name} must be finite and positive, got {value}"
        )));
    }
    Ok(())
}

/// Validate a float value as a valid array index, returning usize.
/// Returns error if value is not finite, negative, non-integer, or exceeds MAX_SAFE_F64_INT.
pub fn validate_array_index(value: f64, context: &str) -> PyResult<usize> {
    if !value.is_finite() || value < 0.0 || value.fract() != 0.0 || value > MAX_SAFE_F64_INT {
        return Err(PyValueError::new_err(format!(
            "{context}={value} is invalid (must be finite non-negative integer <= {MAX_SAFE_F64_INT})"
        )));
    }
    Ok(value as usize)
}

/// Convert a HashMap of JSON values to a Python dict.
pub fn props_to_pydict<'py>(
    py: Python<'py>,
    props: &std::collections::HashMap<String, serde_json::Value>,
) -> PyResult<Bound<'py, PyDict>> {
    let dict = PyDict::new(py);
    for (key, val) in props {
        dict.set_item(key, json_to_py(py, val)?)?;
    }
    Ok(dict)
}

/// Convert Python object to serde_json::Value.
pub fn py_to_json_value(obj: &Bound<'_, pyo3::PyAny>) -> PyResult<serde_json::Value> {
    if obj.is_none() {
        Ok(serde_json::Value::Null)
    } else if let Ok(b) = obj.extract::<bool>() {
        Ok(serde_json::Value::Bool(b))
    } else if let Ok(i) = obj.extract::<i64>() {
        Ok(serde_json::json!(i))
    } else if let Ok(u) = obj.extract::<u64>() {
        Ok(serde_json::json!(u))
    } else if let Ok(f) = obj.extract::<f64>() {
        Ok(serde_json::json!(f))
    } else if let Ok(s) = obj.extract::<String>() {
        Ok(serde_json::Value::String(s))
    } else if let Ok(list) = obj.cast::<PyList>() {
        let arr: Vec<serde_json::Value> = list
            .iter()
            .map(|item| py_to_json_value(&item))
            .collect::<PyResult<_>>()?;
        Ok(serde_json::Value::Array(arr))
    } else if let Ok(dict) = obj.cast::<PyDict>() {
        let mut map = serde_json::Map::new();
        for (k, v) in dict {
            let key: String = k.extract()?;
            map.insert(key, py_to_json_value(&v)?);
        }
        Ok(serde_json::Value::Object(map))
    } else {
        Err(PyValueError::new_err(format!(
            "Cannot convert Python object to JSON: {:?}",
            obj.get_type().name()
        )))
    }
}
