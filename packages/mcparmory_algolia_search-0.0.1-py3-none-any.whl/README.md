# mcparmory-algolia-search

MCP server for Search API.

Full version coming soon. See [mcparmory.com](https://mcparmory.com)
