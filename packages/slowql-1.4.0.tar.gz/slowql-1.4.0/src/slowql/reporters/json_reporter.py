# slowql/src/slowql/reporters/json_reporter.py
"""
JSON reporter for SlowQL.

Outputs the full analysis result as a structured JSON object.
Useful for CI/CD integration and machine consumption.
"""

from __future__ import annotations

import csv
import json
import sys
from html import escape
from typing import TYPE_CHECKING, Any

from slowql.core.models import Severity
from slowql.reporters.base import BaseReporter

if TYPE_CHECKING:
    from slowql.core.models import AnalysisResult

class JSONReporter(BaseReporter):
    """
    Renders analysis results as JSON.
    """

    def report(self, result: AnalysisResult) -> None:
        """
        Convert result to JSON and write to output.
        """
        data = result.to_dict()

        json_output = json.dumps(
            data,
            indent=2,
            ensure_ascii=False,
            default=str,  # Handle datetimes etc.
        )

        if self.output_file:
            self.output_file.write(json_output)
        else:
            print(json_output)


def _normalize_fix_text(fix_obj: Any) -> str:
    """
    Normalize the `fix` field into a human-readable string.

    Supports:
      - None
      - str
      - structured Fix objects with .description / .replacement
    """
    if fix_obj is None:
        return ""

    if isinstance(fix_obj, str):
        txt = fix_obj.strip()
        return "" if txt.lower() == "none" else txt

    desc = getattr(fix_obj, "description", None)
    repl = getattr(fix_obj, "replacement", None)

    parts: list[str] = []
    if desc:
        parts.append(str(desc).strip())
    if repl:
        parts.append(str(repl).strip())

    txt = " ".join(parts).strip()
    return "" if txt.lower() == "none" else txt


class HTMLReporter(BaseReporter):
    """
    Renders analysis results as a standalone HTML report.

    One row per Issue, with:
      - Severity
      - Rule ID
      - Dimension
      - Message
      - Impact
      - Fix (normalized text)
      - Location (if available)
    """

    def _calculate_health_score(self, result: AnalysisResult) -> int:
        """Calculate 0-100 health score based on severity of all issues."""
        weights: dict[Severity, int] = {
            Severity.CRITICAL: 25,
            Severity.HIGH: 15,
            Severity.MEDIUM: 5,
            Severity.LOW: 2,
            Severity.INFO: 0,
        }
        penalty = sum(weights.get(issue.severity, 0) for issue in result.issues)
        return max(0, 100 - min(penalty, 100))

    def report(self, result: AnalysisResult) -> None:
        rows: list[dict[str, str]] = []

        for issue in result.issues:
            sev = getattr(issue.severity, "name", str(issue.severity))

            rows.append(
                {
                    "severity": sev,
                    "rule_id": issue.rule_id or "",
                    "dimension": getattr(issue.dimension, "name", "")
                    if getattr(issue, "dimension", None)
                    else "",
                    "message": issue.message or "",
                    "impact": issue.impact or "",
                    "fix": _normalize_fix_text(getattr(issue, "fix", None)),
                    "location": f"{getattr(issue, 'location', '') or ''}",
                }
            )

        # Build HTML table body
        html_rows: list[str] = []
        for r in rows:
            html_rows.append(
                f"""
        <tr>
          <td class="sev sev-{escape(r["severity"].lower())}">{escape(r["severity"])}</td>
          <td>{escape(r["rule_id"])}</td>
          <td>{escape(r["dimension"])}</td>
          <td>{escape(r["message"])}</td>
          <td>{escape(r["impact"])}</td>
          <td>{escape(r["fix"])}</td>
          <td>{escape(r["location"])}</td>
        </tr>"""
            )

        # Safe meta values
        total_issues = getattr(result.statistics, "total_issues", len(result.issues))
        health_score = self._calculate_health_score(result)

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>SlowQL Analysis Report</title>
  <style>
    body {{
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      background: #0b1120;
      color: #e5e7eb;
      padding: 24px;
    }}
    h1 {{
      color: #f97316;
      text-align: center;
      margin-bottom: 0.25rem;
    }}
    h2.health-score {{
        text-align: center;
        margin-top: 0;
    }}
    h2 {{
      color: #a855f7;
      margin-top: 1.5rem;
    }}
    .meta {{
      font-size: 13px;
      color: #9ca3af;
      margin-bottom: 1rem;
      text-align: center;
    }}
    table {{
      width: 100%;
      border-collapse: collapse;
      margin-top: 1rem;
      font-size: 13px;
    }}
    th, td {{
      padding: 8px 10px;
      border-bottom: 1px solid #1f2937;
      vertical-align: top;
    }}
    th {{
      background: #020617;
      color: #f9fafb;
      text-align: left;
      position: sticky;
      top: 0;
      z-index: 1;
    }}
    tr:nth-child(even) td {{
      background: #020617;
    }}
    .sev-critical {{ color: #f97373; font-weight: 600; }}
    .sev-high     {{ color: #fb923c; font-weight: 600; }}
    .sev-medium   {{ color: #22c55e; }}
    .sev-low      {{ color: #38bdf8; }}
    .sev-info     {{ color: #9ca3af; }}
    code {{
      font-family: "JetBrains Mono", "Fira Code", monospace;
    }}
  </style>
</head>
<body>
  <h1>SlowQL Analysis Report</h1>
  <div class="meta">
    <div>Total Issues: {total_issues}</div>
    <h2 class="health-score">
      Health Score: <span class="health-score-value">{health_score}</span>/100
    </h2>
  </div>

  <h2>Detected Issues</h2>
  <table>
    <thead>
      <tr>
        <th>Severity</th>
        <th>Rule ID</th>
        <th>Dimension</th>
        <th>Message</th>
        <th>Impact</th>
        <th>Fix</th>
        <th>Location</th>
      </tr>
    </thead>
    <tbody>
      {"".join(html_rows)}
    </tbody>
  </table>
</body>
</html>
"""
        if self.output_file:
            self.output_file.write(html)
        else:
            print(html)


class CSVReporter(BaseReporter):
    """
    Renders analysis results as CSV.

    Columns:
      severity, rule_id, dimension, message, impact, fix, location
    """

    def report(self, result: AnalysisResult) -> None:
        writer = csv.writer(self.output_file or sys.stdout)

        # Header
        writer.writerow(
            [
                "severity",
                "rule_id",
                "dimension",
                "message",
                "impact",
                "fix",
                "location",
            ]
        )

        for issue in result.issues:
            sev = getattr(issue.severity, "name", str(issue.severity))
            rule_id = issue.rule_id or ""
            dim = getattr(issue.dimension, "name", "") if getattr(issue, "dimension", None) else ""
            msg = issue.message or ""
            impact = issue.impact or ""
            fix_txt = _normalize_fix_text(getattr(issue, "fix", None))
            loc = f"{getattr(issue, 'location', '') or ''}"

            writer.writerow([sev, rule_id, dim, msg, impact, fix_txt, loc])
