"""
SlowQL Top-level package
"""

from __future__ import annotations

from typing import TYPE_CHECKING

# Define version FIRST to avoid import errors
__version__: str | None
try:
    from importlib.metadata import version

    try:
        __version__ = version("slowql")
    except Exception:
        # Fallback to sqlguard for backwards compatibility
        __version__ = version("sqlguard")
except Exception:
    __version__ = None

__author__ = "makroumi"
__license__ = "Apache-2.0"

from slowql.core.config import Config
from slowql.core.engine import SlowQL
from slowql.core.models import (
    AnalysisResult,
    Dimension,
    Issue,
    Location,
    Severity,
)

if TYPE_CHECKING:
    from pathlib import Path

__all__ = [
    "AnalysisResult",
    "Config",
    "Dimension",
    "Issue",
    "Location",
    "Severity",
    "SlowQL",
    "__version__",
    "analyze",
    "analyze_file",
]


def analyze(
    sql: str,
    *,
    dialect: str | None = None,
    config: Config | None = None,
) -> AnalysisResult:
    engine = SlowQL(config=config)
    return engine.analyze(sql, dialect=dialect)


def analyze_file(
    path: str | Path,
    *,
    dialect: str | None = None,
    config: Config | None = None,
) -> AnalysisResult:
    engine = SlowQL(config=config)
    return engine.analyze_file(path, dialect=dialect)
