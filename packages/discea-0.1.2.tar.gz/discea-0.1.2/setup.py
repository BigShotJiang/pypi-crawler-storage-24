from setuptools import setup, find_packages

setup(
    name="discea",
    version="0.1.0",
    author="Your Name",
    author_email="you@example.com",
    description="A simple Python module for creating Discord bots and sending webhooks",
    long_description=open("README.md", "r", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    install_requires=[
        "discord.py>=2.0.0",
        "requests>=2.28.0"
    ],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.10',
)