# Discea

A modern, powerful, and developer-friendly Python module for creating Discord bots and sending webhooks. Built on top of `discord.py`, Discea aims to simplify the boilerplate while providing a premium development experience.

## Why Discea?

Discord bot development often involves repetitive code for syncing commands, handling interactions, and building complex embeds. **Discea** streamlines this by providing:

- 🚀 **Zero-Config Syncing**: Command tree syncing is handled automatically.
- ✨ **Fluent API**: Design embeds and views using a chainable, readable syntax.
- 🛡️ **Unified Messaging**: A single `send` method that works for both prefix and slash commands.
- 🎨 **Premium Defaults**: Modern intents and settings enabled by default.

## Installation

```bash
pip install discea
```

## Quick Start

### Creating a Bot

```python
from discea import DisceaBot, DisceaEmbed, DisceaView
import discord

bot = DisceaBot(prefix="!")

@bot.slash_command(name="ping", description="Check if the bot is responsive")
async def ping(interaction: discord.Interaction):
    await bot.send(interaction, "Pong!")

@bot.command(name="hello")
async def hello(ctx):
    await bot.send(ctx, "Hello there!")

if __name__ == "__main__":
    bot.run("YOUR_TOKEN")
```

## Advanced Examples

### Complex Fluent Embeds

```python
embed = (DisceaEmbed.simple("System Status", "All services are operational.")
         .add("API Latency", "12ms", inline=True)
         .add("Database", "Connected", inline=True)
         .image("https://example.com/status.png")
         .footer("Last updated 2 mins ago")
         .author("Discea Monitoring", icon_url="https://example.com/icon.png"))

await bot.send(interaction, embed=embed)
```

### Interactive Views with Callbacks

```python
async def button_callback(interaction: discord.Interaction):
    await interaction.response.send_message("Button was clicked!", ephemeral=True)

view = DisceaView()
view.add_button("Primary Action", style=discord.ButtonStyle.primary, callback=button_callback)
view.add_link("Documentation", "https://github.com/...")

await bot.send(interaction, "Interactive Message:", view=view)
```

## API Reference

### `DisceaBot`
| Method | Description |
| --- | --- |
| `slash_command(name, description)` | Decorator to register a global slash command. |
| `command(name)` | Decorator to register a traditional prefix command. |
| `send(ctx, content, embed, view)` | Unified send method. `ctx` can be `Interaction` or `Context`. |
| `run(token, sync=True)` | Starts the bot and handles command syncing. |

### `DisceaEmbed`
| Method | Description |
| --- | --- |
| `add(name, value, inline)` | Adds a field. Returns `self` for chaining. |
| `footer(text, icon_url)` | Sets footer. Returns `self`. |
| `author(name, url, icon_url)` | Sets author. Returns `self`. |
| `image(url)` | Sets image. Returns `self`. |
| `thumbnail(url)` | Sets thumbnail. Returns `self`. |

### `DisceaView`
| Method | Description |
| --- | --- |
| `add_button(label, style, callback, ...)` | Adds a button to the view. |
| `add_link(label, url)` | Adds a URL button (link) to the view. |

### `DisceaWebhook`
| Method | Description |
| --- | --- |
| `send(content, ...)` | Sends a POST request to the Discord webhook. |
| `send_embed(title, description)` | Helper for quick embed delivery via webhook. |

## Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## License

Discea is licensed under the MIT License.
