import discord

class DisceaEmbed(discord.Embed):
    """
    An enhanced discord.Embed with simplified methods and a fluent interface.
    """
    def __init__(self, title=None, description=None, color=0x2F3136, **kwargs):
        super().__init__(title=title, description=description, color=color, **kwargs)

    def add(self, name, value, inline=False):
        """Quickly add a field."""
        self.add_field(name=name, value=value, inline=inline)
        return self

    def footer(self, text, icon_url=None):
        """Quickly set the footer."""
        self.set_footer(text=text, icon_url=icon_url)
        return self

    def author(self, name, url=None, icon_url=None):
        """Quickly set the author."""
        self.set_author(name=name, url=url, icon_url=icon_url)
        return self

    def image(self, url):
        """Quickly set the image."""
        self.set_image(url=url)
        return self

    def thumbnail(self, url):
        """Quickly set the thumbnail."""
        self.set_thumbnail(url=url)
        return self

    @classmethod
    def simple(cls, title, description, color=0x2F3136):
        """Create a simple embed in one line."""
        return cls(title=title, description=description, color=color)
