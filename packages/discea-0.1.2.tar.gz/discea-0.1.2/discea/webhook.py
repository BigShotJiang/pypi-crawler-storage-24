import requests

class DisceaWebhook:
    def __init__(self, url):
        self.url = url

    def send(self, content=None, username=None, avatar_url=None, embeds=None):
        """Send a simple message or embed via webhook."""
        data = {
            "content": content,
            "username": username,
            "avatar_url": avatar_url,
            "embeds": embeds
        }
        # remove None values
        data = {k: v for k, v in data.items() if v is not None}
        response = requests.post(self.url, json=data)
        return response

    def send_embed(self, title, description=None, color=0x2F3136):
        """Quick helper to send an embed."""
        embed = {
            "title": title,
            "description": description,
            "color": color
        }
        return self.send(embeds=[embed])