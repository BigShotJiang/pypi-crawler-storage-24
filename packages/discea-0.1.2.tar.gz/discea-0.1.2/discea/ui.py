import discord
from discord.ui import Button, View, Select

class DisceaView(View):
    """A simplified View that makes adding items easier."""
    def __init__(self, timeout=180):
        super().__init__(timeout=timeout)

    def add_button(self, label, style=discord.ButtonStyle.secondary, custom_id=None, url=None, disabled=False, emoji=None, callback=None):
        """Quickly add a button with an optional callback."""
        button = Button(label=label, style=style, custom_id=custom_id, url=url, disabled=disabled, emoji=emoji)
        if callback:
            button.callback = callback
        self.add_item(button)
        return button

    def add_link(self, label, url, emoji=None):
        """Quickly add a link button."""
        return self.add_button(label=label, url=url, emoji=emoji)

class DisceaButton(Button):
    """A button that can take a callback in its constructor."""
    def __init__(self, label, style=discord.ButtonStyle.secondary, callback=None, **kwargs):
        super().__init__(label=label, style=style, **kwargs)
        self._callback_func = callback

    async def callback(self, interaction: discord.Interaction):
        if self._callback_func:
            await self._callback_func(interaction)
