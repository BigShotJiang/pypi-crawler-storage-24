import discord
from discord.ext import commands
from discord import app_commands

class DisceaBot:
    def __init__(self, prefix="!", intents=None):
        if intents is None:
            intents = discord.Intents.default()
            intents.message_content = True
            intents.guilds = True
        self.bot = commands.Bot(command_prefix=prefix, intents=intents)
        self.tree = self.bot.tree

    def command(self, name=None, **kwargs):
        """Decorator to add a prefix command."""
        return self.bot.command(name=name, **kwargs)

    def slash_command(self, name=None, description="No description provided"):
        """Decorator to add a slash command."""
        return self.tree.command(name=name, description=description)

    def event(self, func):
        """Decorator to add an event listener."""
        self.bot.event(func)
        return func

    async def send(self, ctx, content=None, embed=None, view=discord.utils.MISSING):
        """
        Helper to send a message. Handles both prefix Commands and Slash Commands (Interactions).
        """
        if isinstance(ctx, discord.Interaction):
            if ctx.response.is_done():
                return await ctx.followup.send(content=content, embed=embed, view=view)
            else:
                return await ctx.response.send_message(content=content, embed=embed, view=view)
        else:
            return await ctx.send(content=content, embed=embed, view=view)

    async def sync_commands(self, guild=None):
        """Sync app commands to Discord."""
        return await self.tree.sync(guild=guild)

    def run(self, token, sync=True):
        """Run the bot. Automatically syncs commands if sync is True."""
        if sync:
            @self.bot.event
            async def on_ready():
                await self.sync_commands()
        
        self.bot.run(token)