# ob-auth

Lightweight, zero-dependency Python client for authenticating with the Outerbounds platform.

Use `ob-auth` when you need to call Outerbounds deployment APIs programmatically
without pulling in the full `metaflow` or `outerbounds` packages.

## Installation

```bash
pip install ob-auth
```

If you use IAM-based authentication (AWS Secrets Manager config), install the optional
AWS extra:

```bash
pip install ob-auth[aws]
```

## Usage

### From local Metaflow config (laptop or inside a deployment)

```python
from ob_auth import OuterboundsAuth

auth = OuterboundsAuth()
auth.init_from_config()  # reads ~/.metaflowconfig/config.json

# If the config contains OBP_METAFLOW_CONFIG_URL, the full config
# is fetched remotely using the auth key from the same file.

import urllib.request, json

req = urllib.request.Request(
    "https://api-c-xxxxx.your-domain.outerbounds.xyz/predict",
    headers=auth.api_headers(),
)
resp = urllib.request.urlopen(req)
print(json.loads(resp.read()))
```

### From an encoded config string (e.g. from Outerbounds UI)

```python
from ob_auth import OuterboundsAuth

auth = OuterboundsAuth()
auth.init(config_string="awssm-arn:BASE64...")
headers = auth.api_headers()  # {"x-api-key": "..."}
```

### From a service principal (CI/CD, GitHub Actions)

```python
from ob_auth import OuterboundsAuth

auth = OuterboundsAuth()
auth.init_from_service_principal(
    service_principal_name="my-cicd-bot",
    deployment_domain="my-company.outerbounds.xyz",
    github_actions=True,  # or jwt_token="..." for static tokens
)
headers = auth.api_headers()
```

### With ob-events

If you also use `ob-events`, you can share a single auth instance:

```python
from ob_auth import OuterboundsAuth
from ob_events import EventTrigger

auth = OuterboundsAuth()
auth.init_from_config()

# Use auth for direct API calls
headers = auth.api_headers()

# And pass it to EventTrigger
et = EventTrigger(auth=auth)
et.trigger("my_event", {"key": "value"})
```
