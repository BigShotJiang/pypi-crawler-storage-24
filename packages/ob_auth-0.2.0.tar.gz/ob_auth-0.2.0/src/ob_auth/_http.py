"""Minimal HTTP helpers using only stdlib urllib.request, with retry + backoff."""

import json
import socket
import time
import urllib.request
import urllib.error
import urllib.parse

MAX_RETRIES = 3
BACKOFF_BASE = 1.0  # seconds; retries at ~1s, ~2s, ~4s

_RETRIABLE_HTTP_CODES = frozenset(
    {
        429,  # Too Many Requests
        500,  # Internal Server Error
        502,  # Bad Gateway
        503,  # Service Unavailable
        504,  # Gateway Timeout
    }
)


class HttpError(Exception):
    def __init__(self, url, status, body):
        self.url = url
        self.status = status
        self.body = body
        super().__init__("HTTP %d from %s: %s" % (status, url, body[:200]))


def http_get_json(url, headers=None, params=None, json_body=None):
    """GET request returning parsed JSON response. Retries on transient errors."""
    if params:
        url = url + "?" + urllib.parse.urlencode(params)
    hdrs = dict(headers or {})
    data = None
    if json_body is not None:
        data = json.dumps(json_body).encode("utf-8")
        hdrs["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=hdrs, method="GET")
    return _do_with_retry(req)


def http_post_json(url, headers=None, json_body=None):
    """POST request with JSON body returning parsed JSON response. Retries on transient errors."""
    data = None
    hdrs = dict(headers or {})
    if json_body is not None:
        data = json.dumps(json_body).encode("utf-8")
        hdrs["Content-Type"] = "application/json"
    req = urllib.request.Request(url, data=data, headers=hdrs, method="POST")
    return _do_with_retry(req)


def _do_with_retry(req):
    if "Accept" not in req.headers:
        req.add_header("Accept", "application/json")

    last_exc = None
    for attempt in range(MAX_RETRIES + 1):
        if attempt > 0:
            time.sleep(BACKOFF_BASE * (2 ** (attempt - 1)))

        try:
            return _do(req)
        except HttpError as e:
            last_exc = e
            if e.status not in _RETRIABLE_HTTP_CODES:
                raise
        except (socket.timeout, socket.gaierror, socket.herror) as e:
            last_exc = e
        except OSError as e:
            # Covers ConnectionRefusedError, ConnectionResetError, BrokenPipeError,
            # and other low-level network errors
            last_exc = e
        except urllib.error.URLError as e:
            # Wraps socket errors (DNS failures, connection refused, timeouts)
            last_exc = e

    raise last_exc


def _do(req):
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            raw = resp.read()
    except urllib.error.HTTPError as e:
        body = ""
        try:
            body = e.read().decode("utf-8", errors="replace")
        except Exception:
            pass
        raise HttpError(req.full_url, e.code, body) from e

    # Let JSONDecodeError / ValueError bubble up naturally,
    # same as requests' resp.json().
    return json.loads(raw.decode("utf-8"))
