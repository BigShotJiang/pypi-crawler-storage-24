"""
Outerbounds auth configuration loader.

There are three init methods. Each loads a Metaflow config dict that
must contain METAFLOW_SERVICE_AUTH_KEY (or it can be set as an env var).

1. init_from_config()  -- auto-discover local config
   |
   +-- Read config.json from:
   |     - $METAFLOW_HOME/config.json  (if METAFLOW_HOME is set; error if missing)
   |     - ~/.metaflowconfig/config.json  (fallback when METAFLOW_HOME is not set)
   |
   +-- If config has OBP_METAFLOW_CONFIG_URL:
   |     Fetch full config from that URL using METAFLOW_SERVICE_AUTH_KEY as x-api-key.
   |     Response format: {"config": {...}}. The auth key is preserved from the
   |     local config.
   |
   +-- If config has OB_CONFIG_TYPE == "aws-secrets-manager":
         Fetch real config from AWS Secrets Manager using the ARN and region
         in the config. Requires boto3 (pip install ob-auth[aws]).
         Token is auto-refreshed when JWT nears expiry.

2. init(config_string=...) or init(config_file_path=...)
   |
   +-- config_string: base64+zlib encoded config, optionally prefixed
   |   with "awssm-arn:" or similar (prefix is stripped before decoding).
   |   The decoded JSON may be a direct config or an AWS Secrets Manager
   |   pointer (OB_CONFIG_TYPE == "aws-secrets-manager"), same as above.
   |
   +-- config_file_path: plain JSON file read directly.

3. init_from_service_principal(...)
   |
   +-- Get a JWT token:
   |     - jwt_token=... (provided directly), OR
   |     - github_actions=True (fetched from GHA OIDC endpoint using
   |       ACTIONS_ID_TOKEN_REQUEST_TOKEN / ACTIONS_ID_TOKEN_REQUEST_URL)
   |
   +-- Exchange JWT for an origin token:
   |     GET https://auth.<domain>/generate/service-principal
   |     with x-api-key: <jwt>, body: {servicePrincipalName, deploymentName, perimeter}
   |
   +-- Fetch Metaflow config using origin token:
         GET https://api.<domain>/v1/perimeters/<perimeter>/metaflowconfigs/default
         The origin token becomes METAFLOW_SERVICE_AUTH_KEY in the config.

After init, call .token() or .api_headers() to get the auth credentials.
.token() also checks the METAFLOW_SERVICE_AUTH_KEY env var as a fallback.
If the token is a JWT nearing expiry, token() automatically re-reads
the config from its original source (local file, AWS Secrets Manager).
This handles k8s secret mount rotation transparently.
"""

import json
import zlib
import base64
import sys
import time
import os
from typing import Dict, Any, Optional

from ._http import http_get_json, http_post_json, HttpError


def _to_unicode(x):
    if isinstance(x, bytes):
        return x.decode("utf-8")
    return str(x)


class ConfigError(Exception):
    """Raised for issues loading or parsing configuration."""

    pass


class OuterboundsAuth:
    def __init__(self):
        self._config = {}  # type: Dict[str, Any]
        self._remote_config_pointer = None  # type: Optional[Dict[str, Any]]
        self._config_file_path = None  # type: Optional[str]
        self._initialized = False

    def init_from_config(self):
        """
        Initialize from local metaflow config file.

        Searches for config.json in:
          1. $METAFLOW_HOME/config.json
          2. ~/.metaflowconfig/config.json

        If the config contains OBP_METAFLOW_CONFIG_URL, fetches the full
        config remotely using METAFLOW_SERVICE_AUTH_KEY as x-api-key.

        The resolved file path is remembered so that token() can re-read
        the file when the JWT nears expiry (e.g. k8s secret rotation).
        """
        config_dict, resolved_path = _load_local_metaflow_config()
        self._config_file_path = resolved_path

        if "OBP_METAFLOW_CONFIG_URL" in config_dict:
            config_dict = _fetch_remote_config(config_dict)

        self._init_with_config_dict(config_dict)

    def init(self, config_string=None, config_file_path=None):
        """
        Initialize from an encoded config string or a JSON file path.
        Provide either config_string or config_file_path.
        """
        config_dict = {}
        if config_string:
            try:
                config_dict = _decode_config(config_string)
            except Exception as e:
                raise ConfigError("Failed to decode config string: %s" % e)
        elif config_file_path:
            try:
                with open(config_file_path, "r") as f:
                    config_dict = json.load(f)
            except Exception as e:
                raise ConfigError(
                    "Failed to read config file %s: %s" % (config_file_path, e)
                )
            self._config_file_path = config_file_path
        else:
            raise ConfigError("Must provide either config_string or config_file_path.")

        self._init_with_config_dict(config_dict)

    def init_from_service_principal(
        self,
        service_principal_name,  # type: str
        deployment_domain,  # type: str
        perimeter="default",  # type: str
        jwt_token=None,  # type: Optional[str]
        github_actions=False,  # type: bool
    ):
        """
        Initialize by authenticating as a service principal.
        Provide jwt_token directly, or set github_actions=True in a GHA environment.
        """
        audience = "https://%s" % deployment_domain
        if not jwt_token and github_actions:
            jwt_token = _get_gha_jwt(audience)

        if not jwt_token:
            raise ConfigError(
                "Must provide 'jwt_token' or set 'github_actions=True' "
                "in a GHA environment."
            )

        auth_server = "https://auth.%s" % deployment_domain
        deployment_name = deployment_domain.split(".")[0]
        origin_token = _get_origin_token(
            service_principal_name, deployment_name, perimeter, jwt_token, auth_server
        )

        api_server = "https://api.%s" % deployment_domain
        metaflow_config = _get_remote_metaflow_config_for_perimeter(
            origin_token, perimeter, api_server
        )

        self._init_with_config_dict(metaflow_config)

    def token(self):
        """
        Return the current auth token (METAFLOW_SERVICE_AUTH_KEY).
        Automatically refreshes if the JWT is near expiry by re-reading
        from the original source (AWS Secrets Manager or local config file).
        """
        if not self._initialized:
            raise ConfigError(
                "OuterboundsAuth has not been initialized. Call init*() first."
            )

        auth_key = self._config.get("METAFLOW_SERVICE_AUTH_KEY") or os.environ.get(
            "METAFLOW_SERVICE_AUTH_KEY"
        )
        if not auth_key:
            raise ConfigError("Config is missing 'METAFLOW_SERVICE_AUTH_KEY'.")

        if _jwt_needs_refresh(auth_key):
            try:
                if self._remote_config_pointer:
                    self._refresh_remote_config()
                elif self._config_file_path:
                    self._refresh_from_file()
                auth_key = self._config.get("METAFLOW_SERVICE_AUTH_KEY", auth_key)
            except Exception as e:
                print(
                    "Warning: Failed to refresh config/token. Error: %s" % e,
                    file=sys.stderr,
                )

        return auth_key

    def api_headers(self):
        """Return auth headers dict for calling Outerbounds API endpoints."""
        return {"x-api-key": self.token()}

    @property
    def config(self):
        """Return the full metaflow config dict (read-only access)."""
        if not self._initialized:
            raise ConfigError(
                "OuterboundsAuth has not been initialized. Call init*() first."
            )
        return dict(self._config)

    # -- internal --

    def _init_with_config_dict(self, config):
        self._config = config

        if self._config.get("OB_CONFIG_TYPE") == "aws-secrets-manager":
            self._remote_config_pointer = self._config
            try:
                self._refresh_remote_config()
            except Exception as e:
                raise ConfigError("Failed to load remote config on init: %s" % e)

        self._initialized = True

    def _refresh_remote_config(self):
        if not self._remote_config_pointer:
            raise ConfigError("No remote config pointer found.")

        config_type = self._remote_config_pointer.get("OB_CONFIG_TYPE")
        if config_type != "aws-secrets-manager":
            raise ConfigError("Unknown remote config type: %s" % config_type)

        try:
            arn = self._remote_config_pointer["AWS_SECRETS_MANAGER_SECRET_ARN"]
            region = self._remote_config_pointer["AWS_SECRETS_MANAGER_REGION"]
        except KeyError as e:
            raise ConfigError("Remote config is missing required key: %s" % e)

        try:
            import boto3
        except ImportError:
            raise ImportError(
                "The 'boto3' package is required for AWS Secrets Manager config. "
                "Please install it (e.g., 'pip install ob-auth[aws]')"
            )

        try:
            client = boto3.client("secretsmanager", region_name=region)
            response = client.get_secret_value(SecretId=arn)

            if "SecretBinary" in response:
                secret_data = response["SecretBinary"]
                if isinstance(secret_data, bytes):
                    self._config = json.loads(secret_data.decode("utf-8"))
                else:
                    self._config = json.loads(secret_data)
            elif "SecretString" in response:
                self._config = json.loads(response["SecretString"])
            else:
                raise ConfigError(
                    "AWS Secret Value contains neither SecretBinary nor SecretString."
                )
        except ConfigError:
            raise
        except Exception as e:
            raise ConfigError("Failed to retrieve secret %s from AWS: %s" % (arn, e))

    def _refresh_from_file(self):
        """Re-read config from the file that was used during init.

        If the config contains OBP_METAFLOW_CONFIG_URL, the full config
        is re-fetched remotely (same as init_from_config does).
        """
        if not self._config_file_path:
            raise ConfigError("No config file path stored for refresh.")

        try:
            with open(self._config_file_path, "r") as f:
                config_dict = json.load(f)
        except Exception as e:
            raise ConfigError(
                "Failed to re-read config file %s: %s" % (self._config_file_path, e)
            )

        if "OBP_METAFLOW_CONFIG_URL" in config_dict:
            config_dict = _fetch_remote_config(config_dict)

        self._config = config_dict


# -- module-level helpers --


def _load_local_metaflow_config():
    """Read config.json from standard metaflow config locations.

    If METAFLOW_HOME is set, look there.
    Otherwise, look in ~/.metaflowconfig.

    Returns (config_dict, resolved_path).
    """
    metaflow_home = os.environ.get("METAFLOW_HOME", "")
    if metaflow_home:
        path = os.path.join(metaflow_home, "config.json")
        if not os.path.isfile(path):
            raise ConfigError(
                "METAFLOW_HOME is set to %s but %s does not exist."
                % (metaflow_home, path)
            )
        try:
            with open(path, "r") as f:
                return json.load(f), path
        except Exception as e:
            raise ConfigError("Failed to read config file %s: %s" % (path, e))

    path = os.path.expanduser("~/.metaflowconfig/config.json")
    if os.path.isfile(path):
        try:
            with open(path, "r") as f:
                return json.load(f), path
        except Exception as e:
            raise ConfigError("Failed to read config file %s: %s" % (path, e))

    raise ConfigError("No metaflow config found. Searched: %s" % path)


def _fetch_remote_config(local_config):
    """
    Fetch full config from OBP_METAFLOW_CONFIG_URL using the auth key
    from the local config. Returns the fetched config dict with the
    original auth key preserved.
    """
    url = local_config["OBP_METAFLOW_CONFIG_URL"]
    auth_key = local_config.get("METAFLOW_SERVICE_AUTH_KEY")
    if not auth_key:
        raise ConfigError(
            "Config has OBP_METAFLOW_CONFIG_URL but is missing "
            "METAFLOW_SERVICE_AUTH_KEY."
        )

    try:
        resp = http_get_json(url, headers={"x-api-key": auth_key})
    except HttpError as e:
        raise ConfigError("Failed to fetch remote config from %s: %s" % (url, e))

    config = resp.get("config", resp)
    config["METAFLOW_SERVICE_AUTH_KEY"] = auth_key
    return config


def _decode_config(encoded_config):
    data = encoded_config.split(":", maxsplit=1)[-1]
    compressed = base64.b64decode(data)
    uncompressed = zlib.decompress(compressed)
    return json.loads(_to_unicode(uncompressed))


def _jwt_needs_refresh(token):
    try:
        payload_b64 = token.split(".")[1]
        payload_b64 += "=" * (-len(payload_b64) % 4)
        payload_json = base64.urlsafe_b64decode(payload_b64).decode("utf-8")
        payload = json.loads(payload_json)

        if "exp" not in payload:
            return False

        current_timestamp = int(time.time())
        return payload["exp"] < (current_timestamp + 300)
    except Exception:
        return False


def _get_gha_jwt(audience):
    req_token = os.environ.get("ACTIONS_ID_TOKEN_REQUEST_TOKEN")
    req_url = os.environ.get("ACTIONS_ID_TOKEN_REQUEST_URL")

    if req_token and req_url:
        try:
            resp = http_get_json(
                req_url,
                headers={"Authorization": "Bearer %s" % req_token},
                params={"audience": audience},
            )
            return resp["value"]
        except Exception as e:
            raise ConfigError("Failed to fetch JWT token from GitHub Actions: %s" % e)

    raise ConfigError(
        "GHA flag was set, but $ACTIONS_ID_TOKEN_REQUEST_TOKEN and "
        "$ACTIONS_ID_TOKEN_REQUEST_URL env vars were not found."
    )


def _get_origin_token(
    service_principal_name, deployment, perimeter, token, auth_server
):
    try:
        resp = http_get_json(
            "%s/generate/service-principal" % auth_server,
            headers={"x-api-key": token},
            json_body={
                "servicePrincipalName": service_principal_name,
                "deploymentName": deployment,
                "perimeter": perimeter,
            },
        )
        return resp["token"]
    except Exception as e:
        raise ConfigError(
            "Failed to get origin token from %s. Error: %s" % (auth_server, e)
        )


def _get_remote_metaflow_config_for_perimeter(origin_token, perimeter, api_server):
    try:
        resp = http_get_json(
            "%s/v1/perimeters/%s/metaflowconfigs/default" % (api_server, perimeter),
            headers={"x-api-key": origin_token},
        )
        config = resp["config"]
        config["METAFLOW_SERVICE_AUTH_KEY"] = origin_token
        return config
    except Exception as e:
        raise ConfigError(
            "Failed to get metaflow config from %s. Error: %s" % (api_server, e)
        )
