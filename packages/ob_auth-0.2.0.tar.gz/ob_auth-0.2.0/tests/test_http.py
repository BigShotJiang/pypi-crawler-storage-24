"""Tests for ob_auth._http retry and error handling."""

import json
import socket
import socketserver
import sys
import os
import unittest
from http.server import HTTPServer, BaseHTTPRequestHandler
import threading
import urllib.error

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

import ob_auth._http as _http
from ob_auth._http import http_get_json, http_post_json, HttpError, MAX_RETRIES

# Speed up retries for tests
_http.BACKOFF_BASE = 0.01


class MockHandler(BaseHTTPRequestHandler):
    """Test HTTP server handler. Reads response sequence from server.responses.

    Each response is a dict:
      {"status": 200, "body": {...}}           -- normal JSON response
      {"action": "reset"}                      -- close connection immediately (simulates network error)
    """

    def do_GET(self):
        self._handle()

    def do_POST(self):
        self._handle()

    def _handle(self):
        if not self.server.responses:
            self.send_response(500)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"error": "no more mock responses"}')
            return

        resp = self.server.responses.pop(0)
        self.server.request_count += 1

        if resp.get("action") == "reset":
            self.connection.close()
            return

        status = resp["status"]
        body = json.dumps(resp.get("body", {})).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Connection", "close")
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):
        pass


def start_server(responses):
    server = HTTPServer(("127.0.0.1", 0), MockHandler)
    server.responses = list(responses)
    server.request_count = 0
    t = threading.Thread(target=server.serve_forever)
    t.daemon = True
    t.start()
    return server


class TestHttpGetJson(unittest.TestCase):
    def test_success(self):
        server = start_server([{"status": 200, "body": {"ok": True}}])
        port = server.server_address[1]
        try:
            result = http_get_json("http://127.0.0.1:%d/test" % port)
            self.assertEqual(result, {"ok": True})
        finally:
            server.shutdown()

    def test_params_appended(self):
        server = start_server([{"status": 200, "body": {"got": "it"}}])
        port = server.server_address[1]
        try:
            result = http_get_json(
                "http://127.0.0.1:%d/test" % port, params={"foo": "bar"}
            )
            self.assertEqual(result, {"got": "it"})
        finally:
            server.shutdown()

    def test_non_retriable_error_no_retry(self):
        server = start_server(
            [
                {"status": 403, "body": {"error": "forbidden"}},
                {"status": 200, "body": {"should": "not reach"}},
            ]
        )
        port = server.server_address[1]
        try:
            with self.assertRaises(HttpError) as ctx:
                http_get_json("http://127.0.0.1:%d/test" % port)
            self.assertEqual(ctx.exception.status, 403)
            self.assertEqual(server.request_count, 1)
        finally:
            server.shutdown()

    def test_404_no_retry(self):
        server = start_server([{"status": 404, "body": {"error": "not found"}}])
        port = server.server_address[1]
        try:
            with self.assertRaises(HttpError) as ctx:
                http_get_json("http://127.0.0.1:%d/test" % port)
            self.assertEqual(ctx.exception.status, 404)
        finally:
            server.shutdown()


class TestHttpPostJson(unittest.TestCase):
    def test_success(self):
        server = start_server([{"status": 200, "body": {"created": True}}])
        port = server.server_address[1]
        try:
            result = http_post_json(
                "http://127.0.0.1:%d/test" % port,
                json_body={"name": "test"},
            )
            self.assertEqual(result, {"created": True})
        finally:
            server.shutdown()


class TestRetryOnHttpErrors(unittest.TestCase):
    def test_retry_on_503_then_success(self):
        server = start_server(
            [
                {"status": 503, "body": {"error": "unavailable"}},
                {"status": 200, "body": {"ok": True}},
            ]
        )
        port = server.server_address[1]
        try:
            result = http_get_json("http://127.0.0.1:%d/" % port)
            self.assertEqual(result, {"ok": True})
            self.assertEqual(server.request_count, 2)
        finally:
            server.shutdown()

    def test_retry_on_429_then_success(self):
        server = start_server(
            [
                {"status": 429, "body": {"error": "rate limited"}},
                {"status": 429, "body": {"error": "rate limited"}},
                {"status": 200, "body": {"ok": True}},
            ]
        )
        port = server.server_address[1]
        try:
            result = http_get_json("http://127.0.0.1:%d/" % port)
            self.assertEqual(result, {"ok": True})
            self.assertEqual(server.request_count, 3)
        finally:
            server.shutdown()

    def test_retry_on_500_then_success(self):
        server = start_server(
            [
                {"status": 500, "body": {"error": "server error"}},
                {"status": 200, "body": {"ok": True}},
            ]
        )
        port = server.server_address[1]
        try:
            result = http_get_json("http://127.0.0.1:%d/" % port)
            self.assertEqual(result, {"ok": True})
            self.assertEqual(server.request_count, 2)
        finally:
            server.shutdown()

    def test_exhausted_retries_raises(self):
        responses = [
            {"status": 502, "body": {"error": "bad gateway"}}
            for _ in range(MAX_RETRIES + 1)
        ]
        server = start_server(responses)
        port = server.server_address[1]
        try:
            with self.assertRaises(HttpError) as ctx:
                http_get_json("http://127.0.0.1:%d/" % port)
            self.assertEqual(ctx.exception.status, 502)
            self.assertEqual(server.request_count, MAX_RETRIES + 1)
        finally:
            server.shutdown()


class TestRetryOnNetworkErrors(unittest.TestCase):
    def test_retry_on_connection_refused(self):
        """Connect to a port nothing is listening on."""
        sock = socket.socket()
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
        sock.close()

        with self.assertRaises((OSError, urllib.error.URLError)):
            http_get_json("http://127.0.0.1:%d/" % port)

    def test_retry_on_dns_failure(self):
        """Name resolution failure should retry and eventually raise."""
        with self.assertRaises((socket.gaierror, urllib.error.URLError, OSError)):
            http_get_json("http://this-host-does-not-exist-ob-auth-test.invalid/")

    def test_connection_reset_then_success(self):
        """Server drops first connection, succeeds on retry."""
        server = start_server(
            [
                {"action": "reset"},
                {"status": 200, "body": {"ok": True}},
            ]
        )
        port = server.server_address[1]
        try:
            result = http_get_json("http://127.0.0.1:%d/" % port)
            self.assertEqual(result, {"ok": True})
            self.assertEqual(server.request_count, 2)
        finally:
            server.shutdown()

    def test_multiple_resets_then_success(self):
        """Server drops first two connections, succeeds on third."""
        server = start_server(
            [
                {"action": "reset"},
                {"action": "reset"},
                {"status": 200, "body": {"ok": True}},
            ]
        )
        port = server.server_address[1]
        try:
            result = http_get_json("http://127.0.0.1:%d/" % port)
            self.assertEqual(result, {"ok": True})
            self.assertEqual(server.request_count, 3)
        finally:
            server.shutdown()

    def test_all_resets_exhausts_retries(self):
        """Server drops all connections, retries exhausted."""
        server = start_server([{"action": "reset"} for _ in range(MAX_RETRIES + 1)])
        port = server.server_address[1]
        try:
            with self.assertRaises((OSError, urllib.error.URLError)):
                http_get_json("http://127.0.0.1:%d/" % port)
        finally:
            server.shutdown()

    def test_mixed_errors_then_success(self):
        """Connection reset, then 503, then success."""
        server = start_server(
            [
                {"action": "reset"},
                {"status": 503, "body": {"error": "unavailable"}},
                {"status": 200, "body": {"ok": True}},
            ]
        )
        port = server.server_address[1]
        try:
            result = http_get_json("http://127.0.0.1:%d/" % port)
            self.assertEqual(result, {"ok": True})
            self.assertEqual(server.request_count, 3)
        finally:
            server.shutdown()


class TestHttpErrorAttributes(unittest.TestCase):
    def test_error_has_status_and_body(self):
        server = start_server([{"status": 418, "body": {"msg": "I'm a teapot"}}])
        port = server.server_address[1]
        try:
            with self.assertRaises(HttpError) as ctx:
                http_get_json("http://127.0.0.1:%d/" % port)
            err = ctx.exception
            self.assertEqual(err.status, 418)
            self.assertIn("teapot", err.body)
            self.assertIn("127.0.0.1", err.url)
        finally:
            server.shutdown()


if __name__ == "__main__":
    unittest.main()
