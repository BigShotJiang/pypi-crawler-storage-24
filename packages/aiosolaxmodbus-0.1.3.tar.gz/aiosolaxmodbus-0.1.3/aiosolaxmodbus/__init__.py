"""Async Python client for SolaX inverters over Modbus TCP."""

from .client import SolaxModbusClient
from .exceptions import (
    SolaxModbusConnectionError,
    SolaxModbusError,
    SolaxModbusReadError,
    SolaxModbusTimeoutError,
    SolaxModbusUnsupportedModelError,
    SolaxModbusWriteError,
)
from .models import InverterInfo, RunMode, SolaxInverterData
from .registers import (
    DataType,
    InverterModel,
    RegisterDefinition,
    RegisterType,
    detect_model,
)

__all__ = [
    "DataType",
    "InverterInfo",
    "InverterModel",
    "RegisterDefinition",
    "RegisterType",
    "RunMode",
    "SolaxInverterData",
    "SolaxModbusClient",
    "SolaxModbusConnectionError",
    "SolaxModbusError",
    "SolaxModbusReadError",
    "SolaxModbusTimeoutError",
    "SolaxModbusUnsupportedModelError",
    "SolaxModbusWriteError",
    "detect_model",
]
