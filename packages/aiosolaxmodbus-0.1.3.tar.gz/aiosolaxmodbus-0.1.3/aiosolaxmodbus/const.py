"""Constants for aiosolaxmodbus."""

DEFAULT_PORT = 502
DEFAULT_TIMEOUT = 5.0
DEFAULT_SLAVE_ID = 1
