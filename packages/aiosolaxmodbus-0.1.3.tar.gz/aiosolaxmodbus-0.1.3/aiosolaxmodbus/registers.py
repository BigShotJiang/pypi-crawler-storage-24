"""Data-driven register map definitions for SolaX inverters."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class RegisterType(Enum):
    """Modbus register type (determines function code)."""

    INPUT = "input"  # FC 0x04 - read_input_registers
    HOLDING = "holding"  # FC 0x03 - read_holding_registers


class DataType(Enum):
    """Data type stored in registers."""

    U16 = "u16"  # Unsigned 16-bit
    S16 = "s16"  # Signed 16-bit
    U32 = "u32"  # Unsigned 32-bit (2 consecutive registers, big-endian)
    STRING = "string"  # ASCII string across multiple registers


@dataclass(frozen=True)
class RegisterDefinition:
    """Definition of a single Modbus register or register group."""

    key: str
    name: str
    register_type: RegisterType
    address: int
    data_type: DataType
    scale: float = 1.0
    unit: str | None = None
    count: int = 1  # Number of registers for STRING type
    writable: bool = False

    @property
    def register_count(self) -> int:
        """Number of 16-bit registers this definition spans."""
        if self.data_type == DataType.U32:
            return 2
        if self.data_type == DataType.STRING:
            return self.count
        return 1


# ── X1-Hybrid Gen4 Register Map ──────────────────────────────────────

X1_HYBRID_G4_INPUT_REGISTERS: tuple[RegisterDefinition, ...] = (
    # Grid
    RegisterDefinition(
        "grid_voltage", "Grid Voltage",
        RegisterType.INPUT, 0x0000, DataType.U16, 0.1, "V",
    ),
    RegisterDefinition(
        "grid_current", "Grid Current",
        RegisterType.INPUT, 0x0001, DataType.S16, 0.1, "A",
    ),
    RegisterDefinition(
        "grid_power", "Grid Power",
        RegisterType.INPUT, 0x0002, DataType.S16, 1.0, "W",
    ),
    # PV String 1
    RegisterDefinition(
        "pv1_voltage", "PV1 Voltage",
        RegisterType.INPUT, 0x0003, DataType.U16, 0.1, "V",
    ),
    RegisterDefinition(
        "pv1_current", "PV1 Current",
        RegisterType.INPUT, 0x0004, DataType.U16, 0.1, "A",
    ),
    RegisterDefinition(
        "pv1_power", "PV1 Power",
        RegisterType.INPUT, 0x0005, DataType.U16, 1.0, "W",
    ),
    # PV String 2
    RegisterDefinition(
        "pv2_voltage", "PV2 Voltage",
        RegisterType.INPUT, 0x0006, DataType.U16, 0.1, "V",
    ),
    RegisterDefinition(
        "pv2_current", "PV2 Current",
        RegisterType.INPUT, 0x0007, DataType.U16, 0.1, "A",
    ),
    RegisterDefinition(
        "pv2_power", "PV2 Power",
        RegisterType.INPUT, 0x0008, DataType.U16, 1.0, "W",
    ),
    # System
    RegisterDefinition(
        "grid_frequency", "Grid Frequency",
        RegisterType.INPUT, 0x0009, DataType.U16, 0.01, "Hz",
    ),
    RegisterDefinition(
        "inverter_temperature", "Inverter Temperature",
        RegisterType.INPUT, 0x000A, DataType.S16, 1.0, "°C",
    ),
    RegisterDefinition(
        "run_mode", "Run Mode",
        RegisterType.INPUT, 0x000B, DataType.U16,
    ),
    # Battery
    RegisterDefinition(
        "battery_voltage", "Battery Voltage",
        RegisterType.INPUT, 0x000F, DataType.S16, 0.01, "V",
    ),
    RegisterDefinition(
        "battery_current", "Battery Current",
        RegisterType.INPUT, 0x0010, DataType.S16, 0.1, "A",
    ),
    RegisterDefinition(
        "battery_power", "Battery Power",
        RegisterType.INPUT, 0x0011, DataType.S16, 1.0, "W",
    ),
    RegisterDefinition(
        "battery_temperature", "Battery Temperature",
        RegisterType.INPUT, 0x0014, DataType.S16, 1.0, "°C",
    ),
    RegisterDefinition(
        "battery_soc", "Battery SOC",
        RegisterType.INPUT, 0x001C, DataType.U16, 1.0, "%",
    ),
    # Lifetime totals (U32)
    RegisterDefinition(
        "total_pv_energy", "Total PV Energy",
        RegisterType.INPUT, 0x0046, DataType.U32, 0.1, "kWh",
    ),
    RegisterDefinition(
        "total_feed_in_energy", "Total Feed-in Energy",
        RegisterType.INPUT, 0x0048, DataType.U32, 0.1, "kWh",
    ),
    RegisterDefinition(
        "total_consumption", "Total Consumption",
        RegisterType.INPUT, 0x004A, DataType.U32, 0.1, "kWh",
    ),
    # Today's values
    RegisterDefinition(
        "today_pv_energy", "Today's PV Energy",
        RegisterType.INPUT, 0x0050, DataType.U16, 0.1, "kWh",
    ),
    RegisterDefinition(
        "today_battery_charge", "Today's Battery Charge",
        RegisterType.INPUT, 0x0051, DataType.U16, 0.1, "kWh",
    ),
    RegisterDefinition(
        "today_battery_discharge", "Today's Battery Discharge",
        RegisterType.INPUT, 0x0052, DataType.U16, 0.1, "kWh",
    ),
    RegisterDefinition(
        "today_feed_in_energy", "Today's Feed-in Energy",
        RegisterType.INPUT, 0x0054, DataType.U16, 0.1, "kWh",
    ),
    RegisterDefinition(
        "today_consumption", "Today's Consumption",
        RegisterType.INPUT, 0x0055, DataType.U16, 0.1, "kWh",
    ),
)

X1_HYBRID_G4_HOLDING_REGISTERS: tuple[RegisterDefinition, ...] = (
    # Identification (read-only)
    RegisterDefinition(
        "serial_number", "Serial Number",
        RegisterType.HOLDING, 0x0000, DataType.STRING, count=7,
    ),
    # Writable configuration (sorted by address)
    RegisterDefinition(
        "run_mode_setting", "Run Mode Setting",
        RegisterType.HOLDING, 0x001F, DataType.U16, writable=True,
    ),
    RegisterDefinition(
        "firmware_version_main", "Firmware Version (Main)",
        RegisterType.HOLDING, 0x0020, DataType.U16,
    ),
    RegisterDefinition(
        "firmware_version_sub", "Firmware Version (Sub)",
        RegisterType.HOLDING, 0x0021, DataType.U16,
    ),
    RegisterDefinition(
        "battery_charge_max_current", "Battery Charge Max Current",
        RegisterType.HOLDING, 0x0024, DataType.U16, 0.1, "A", writable=True,
    ),
    RegisterDefinition(
        "battery_discharge_max_current", "Battery Discharge Max Current",
        RegisterType.HOLDING, 0x0025, DataType.U16, 0.1, "A", writable=True,
    ),
    RegisterDefinition(
        "export_limit", "Export Limit",
        RegisterType.HOLDING, 0x0028, DataType.U16, 1.0, "W", writable=True,
    ),
    RegisterDefinition(
        "min_battery_soc", "Min Battery SOC",
        RegisterType.HOLDING, 0x0029, DataType.U16, 1.0, "%", writable=True,
    ),
)


@dataclass(frozen=True)
class InverterModel:
    """Metadata and register maps for an inverter model."""

    name: str
    input_registers: tuple[RegisterDefinition, ...]
    holding_registers: tuple[RegisterDefinition, ...]


# Serial number prefix -> model info
# H43 = HYBRID | GEN4 | X1
INVERTER_MODELS: dict[str, InverterModel] = {
    "H43": InverterModel(
        name="X1-Hybrid Gen4",
        input_registers=X1_HYBRID_G4_INPUT_REGISTERS,
        holding_registers=X1_HYBRID_G4_HOLDING_REGISTERS,
    ),
}


def detect_model(serial_number: str) -> InverterModel | None:
    """Detect inverter model from serial number prefix.

    Returns None if the serial prefix is not recognised.
    """
    for prefix, model in INVERTER_MODELS.items():
        if serial_number.upper().startswith(prefix):
            return model
    return None
