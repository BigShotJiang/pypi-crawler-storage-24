"""Async client for SolaX inverters over Modbus TCP."""

from __future__ import annotations

import asyncio
import logging
import struct
from typing import Self

import inspect

from pymodbus.client import AsyncModbusTcpClient
from pymodbus.exceptions import ModbusException

from .const import DEFAULT_PORT, DEFAULT_SLAVE_ID, DEFAULT_TIMEOUT


def _slave_kwarg(slave_id: int) -> dict[str, int]:
    """Return the correct keyword argument for pymodbus slave/unit ID.

    pymodbus changed parameter names across versions:
    - 3.5-3.7: slave=
    - 3.8+: may not accept slave on per-call basis
    Detect which parameter is accepted by inspecting the method signature.
    """
    sig = inspect.signature(AsyncModbusTcpClient.read_holding_registers)
    for name in ("slave", "slave_id", "unit"):
        if name in sig.parameters:
            return {name: slave_id}
    return {}
from .exceptions import (
    SolaxModbusConnectionError,
    SolaxModbusReadError,
    SolaxModbusTimeoutError,
    SolaxModbusUnsupportedModelError,
    SolaxModbusWriteError,
)
from .models import InverterInfo, RunMode, SolaxInverterData
from .registers import (
    DataType,
    InverterModel,
    RegisterDefinition,
    RegisterType,
    detect_model,
)

_LOGGER = logging.getLogger(__name__)


def _parse_value(registers: list[int], reg_def: RegisterDefinition) -> int | float | str:
    """Parse a raw register value according to its definition."""
    if reg_def.data_type == DataType.STRING:
        chars = []
        for word in registers:
            high = (word >> 8) & 0xFF
            low = word & 0xFF
            if high:
                chars.append(chr(high))
            if low:
                chars.append(chr(low))
        return "".join(chars).strip("\x00")

    if reg_def.data_type == DataType.U32:
        raw = (registers[0] << 16) | registers[1]
        return round(raw * reg_def.scale, 2)

    raw = registers[0]

    if reg_def.data_type == DataType.S16:
        # Convert unsigned 16-bit to signed
        (raw,) = struct.unpack(">h", struct.pack(">H", raw))

    return round(raw * reg_def.scale, 2)


def _group_contiguous(
    reg_defs: tuple[RegisterDefinition, ...],
) -> list[tuple[int, int, list[RegisterDefinition]]]:
    """Group register definitions into contiguous read ranges.

    Returns list of (start_address, count, [definitions]).
    Gaps of more than 10 registers trigger a new group.
    """
    if not reg_defs:
        return []

    sorted_defs = sorted(reg_defs, key=lambda r: r.address)
    groups: list[tuple[int, int, list[RegisterDefinition]]] = []

    group_start = sorted_defs[0].address
    group_end = group_start + sorted_defs[0].register_count
    group_defs: list[RegisterDefinition] = [sorted_defs[0]]

    for reg_def in sorted_defs[1:]:
        if reg_def.address <= group_end + 10:
            group_end = max(group_end, reg_def.address + reg_def.register_count)
            group_defs.append(reg_def)
        else:
            groups.append((group_start, group_end - group_start, group_defs))
            group_start = reg_def.address
            group_end = group_start + reg_def.register_count
            group_defs = [reg_def]

    groups.append((group_start, group_end - group_start, group_defs))
    return groups


class SolaxModbusClient:
    """Async client for SolaX inverters via Modbus TCP.

    Handles connection lifecycle, register batch reads, value scaling,
    and single-connection locking (SolaX only supports one TCP connection).
    """

    def __init__(
        self,
        host: str,
        port: int = DEFAULT_PORT,
        slave_id: int = DEFAULT_SLAVE_ID,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        """Initialize the client."""
        self._host = host
        self._port = port
        self._slave_id = slave_id
        self._timeout = timeout
        self._client: AsyncModbusTcpClient | None = None
        self._lock = asyncio.Lock()
        self._model: InverterModel | None = None
        self._slave_kwargs = _slave_kwarg(slave_id)

    async def __aenter__(self) -> Self:
        """Enter async context manager."""
        await self.connect()
        return self

    async def __aexit__(self, *args: object) -> None:
        """Exit async context manager."""
        await self.disconnect()

    @property
    def connected(self) -> bool:
        """Return whether the client is connected."""
        return self._client is not None and self._client.connected

    @property
    def model(self) -> InverterModel | None:
        """Return the detected inverter model, if known."""
        return self._model

    async def connect(self) -> None:
        """Connect to the inverter via Modbus TCP."""
        if self.connected:
            return

        self._client = AsyncModbusTcpClient(
            host=self._host,
            port=self._port,
            timeout=self._timeout,
        )

        try:
            connected = await self._client.connect()
        except OSError as err:
            msg = f"Failed to connect to {self._host}:{self._port}"
            raise SolaxModbusConnectionError(msg) from err

        if not connected:
            msg = f"Failed to connect to {self._host}:{self._port}"
            raise SolaxModbusConnectionError(msg)

        _LOGGER.debug("Connected to SolaX inverter at %s:%s", self._host, self._port)

    async def disconnect(self) -> None:
        """Disconnect from the inverter."""
        if self._client is not None:
            self._client.close()
            self._client = None
            _LOGGER.debug("Disconnected from SolaX inverter")

    async def _ensure_connected(self) -> AsyncModbusTcpClient:
        """Ensure connected, reconnecting if necessary."""
        if not self.connected:
            await self.connect()
        assert self._client is not None
        return self._client

    async def _read_registers(
        self,
        register_type: RegisterType,
        address: int,
        count: int,
    ) -> list[int]:
        """Read a block of registers."""
        client = await self._ensure_connected()

        try:
            if register_type == RegisterType.INPUT:
                result = await client.read_input_registers(
                    address, count=count, **self._slave_kwargs
                )
            else:
                result = await client.read_holding_registers(
                    address, count=count, **self._slave_kwargs
                )
        except ModbusException as err:
            msg = f"Modbus error reading {register_type.value} registers at 0x{address:04X}"
            raise SolaxModbusReadError(msg) from err
        except asyncio.TimeoutError as err:
            msg = f"Timeout reading registers at 0x{address:04X}"
            raise SolaxModbusTimeoutError(msg) from err
        except OSError as err:
            # Connection lost
            self._client = None
            msg = f"Connection lost reading registers at 0x{address:04X}"
            raise SolaxModbusConnectionError(msg) from err

        if result.isError():
            msg = f"Error response reading {register_type.value} registers at 0x{address:04X}: {result}"
            raise SolaxModbusReadError(msg)

        return list(result.registers)

    async def _read_register_batch(
        self,
        register_type: RegisterType,
        reg_defs: tuple[RegisterDefinition, ...],
    ) -> dict[str, int | float | str]:
        """Read a batch of registers using optimized grouping."""
        groups = _group_contiguous(reg_defs)
        values: dict[str, int | float | str] = {}

        for start_addr, count, defs in groups:
            raw = await self._read_registers(register_type, start_addr, count)

            for reg_def in defs:
                offset = reg_def.address - start_addr
                reg_count = reg_def.register_count
                reg_raw = raw[offset : offset + reg_count]
                values[reg_def.key] = _parse_value(reg_raw, reg_def)

        return values

    async def read_info(self) -> InverterInfo:
        """Read inverter identification and detect model.

        Raises SolaxModbusUnsupportedModelError if the serial number
        prefix is not recognised.
        """
        async with self._lock:
            # Read serial number (holding 0x0000, 7 registers)
            serial_raw = await self._read_registers(
                RegisterType.HOLDING, 0x0000, 7
            )
            chars = []
            for word in serial_raw:
                high = (word >> 8) & 0xFF
                low = word & 0xFF
                if high:
                    chars.append(chr(high))
                if low:
                    chars.append(chr(low))
            serial_number = "".join(chars).strip("\x00")

            # Read firmware versions (holding 0x0020-0x0021)
            firmware_raw = await self._read_registers(
                RegisterType.HOLDING, 0x0020, 2
            )
            firmware_main = firmware_raw[0]
            firmware_sub = firmware_raw[1]

        model = detect_model(serial_number)
        if model is None:
            msg = (
                f"Unsupported inverter model: serial={serial_number}. "
                f"Please open a GitHub issue with your serial number prefix."
            )
            raise SolaxModbusUnsupportedModelError(msg)

        self._model = model

        return InverterInfo(
            serial_number=serial_number,
            firmware_main=firmware_main,
            firmware_sub=firmware_sub,
            model=model.name,
        )

    async def read_data(self) -> SolaxInverterData:
        """Read all monitoring and configuration registers.

        Returns a fully-parsed SolaxInverterData with all values scaled.
        The read is protected by a lock to prevent concurrent Modbus access.
        """
        if self._model is None:
            # Auto-detect on first read
            await self.read_info()
        assert self._model is not None

        async with self._lock:
            input_values = await self._read_register_batch(
                RegisterType.INPUT, self._model.input_registers
            )

            # Read only config-relevant holding registers (writable + firmware)
            config_defs = tuple(
                r for r in self._model.holding_registers if r.writable
            )
            holding_values = await self._read_register_batch(
                RegisterType.HOLDING, config_defs
            )

        return SolaxInverterData(
            # Grid
            grid_voltage=float(input_values["grid_voltage"]),
            grid_current=float(input_values["grid_current"]),
            grid_power=float(input_values["grid_power"]),
            # PV
            pv1_voltage=float(input_values["pv1_voltage"]),
            pv1_current=float(input_values["pv1_current"]),
            pv1_power=float(input_values["pv1_power"]),
            pv2_voltage=float(input_values["pv2_voltage"]),
            pv2_current=float(input_values["pv2_current"]),
            pv2_power=float(input_values["pv2_power"]),
            # System
            grid_frequency=float(input_values["grid_frequency"]),
            inverter_temperature=float(input_values["inverter_temperature"]),
            run_mode=RunMode(int(input_values["run_mode"])),
            # Battery
            battery_voltage=float(input_values["battery_voltage"]),
            battery_current=float(input_values["battery_current"]),
            battery_power=float(input_values["battery_power"]),
            battery_temperature=float(input_values["battery_temperature"]),
            battery_soc=int(input_values["battery_soc"]),
            # Totals
            total_pv_energy=float(input_values["total_pv_energy"]),
            total_feed_in_energy=float(input_values["total_feed_in_energy"]),
            total_consumption=float(input_values["total_consumption"]),
            # Today
            today_pv_energy=float(input_values["today_pv_energy"]),
            today_battery_charge=float(input_values["today_battery_charge"]),
            today_battery_discharge=float(input_values["today_battery_discharge"]),
            today_feed_in_energy=float(input_values["today_feed_in_energy"]),
            today_consumption=float(input_values["today_consumption"]),
            # Config
            run_mode_setting=RunMode(int(holding_values["run_mode_setting"])),
            battery_charge_max_current=float(holding_values["battery_charge_max_current"]),
            battery_discharge_max_current=float(holding_values["battery_discharge_max_current"]),
            export_limit=int(holding_values["export_limit"]),
            min_battery_soc=int(holding_values["min_battery_soc"]),
        )

    async def _write_register(self, address: int, value: int) -> None:
        """Write a single holding register value."""
        async with self._lock:
            client = await self._ensure_connected()
            try:
                result = await client.write_register(
                    address, value=value, **self._slave_kwargs
                )
            except ModbusException as err:
                msg = f"Modbus error writing register 0x{address:04X}"
                raise SolaxModbusWriteError(msg) from err
            except asyncio.TimeoutError as err:
                msg = f"Timeout writing register 0x{address:04X}"
                raise SolaxModbusTimeoutError(msg) from err
            except OSError as err:
                self._client = None
                msg = f"Connection lost writing register 0x{address:04X}"
                raise SolaxModbusConnectionError(msg) from err

            if result.isError():
                msg = f"Error response writing register 0x{address:04X}: {result}"
                raise SolaxModbusWriteError(msg)

        _LOGGER.debug("Wrote value %d to register 0x%04X", value, address)

    async def write_run_mode(self, mode: RunMode) -> None:
        """Set the inverter run mode."""
        await self._write_register(0x001F, int(mode))

    async def write_battery_charge_max_current(self, amps: float) -> None:
        """Set the maximum battery charge current in amps."""
        await self._write_register(0x0024, int(amps / 0.1))

    async def write_battery_discharge_max_current(self, amps: float) -> None:
        """Set the maximum battery discharge current in amps."""
        await self._write_register(0x0025, int(amps / 0.1))

    async def write_export_limit(self, watts: int) -> None:
        """Set the export power limit in watts."""
        await self._write_register(0x0028, watts)

    async def write_min_battery_soc(self, percent: int) -> None:
        """Set the minimum battery state of charge (%)."""
        await self._write_register(0x0029, percent)
