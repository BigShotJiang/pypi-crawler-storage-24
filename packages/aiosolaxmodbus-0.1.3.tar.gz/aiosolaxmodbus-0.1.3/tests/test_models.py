"""Tests for data models."""

from aiosolaxmodbus.models import InverterInfo, RunMode, SolaxInverterData


def test_inverter_info_frozen():
    info = InverterInfo(
        serial_number="H4372AI4633110",
        firmware_main=259,
        firmware_sub=18,
        model="X1-Hybrid Gen4",
    )
    assert info.serial_number == "H4372AI4633110"
    assert info.firmware_main == 259
    assert info.model == "X1-Hybrid Gen4"


def test_inverter_data_frozen():
    data = SolaxInverterData(
        grid_voltage=242.2,
        grid_current=5.0,
        grid_power=1210.0,
        pv1_voltage=315.0,
        pv1_current=3.2,
        pv1_power=1008.0,
        pv2_voltage=320.0,
        pv2_current=2.8,
        pv2_power=896.0,
        grid_frequency=49.95,
        inverter_temperature=35.0,
        run_mode=RunMode.SELF_USE,
        battery_voltage=49.20,
        battery_current=1.5,
        battery_power=74.0,
        battery_temperature=22.0,
        battery_soc=49,
        total_pv_energy=5234.0,
        total_feed_in_energy=3120.0,
        total_consumption=4210.0,
        today_pv_energy=8.2,
        today_battery_charge=3.5,
        today_battery_discharge=2.1,
        today_feed_in_energy=4.8,
        today_consumption=6.7,
        run_mode_setting=RunMode.SELF_USE,
        battery_charge_max_current=25.0,
        battery_discharge_max_current=20.0,
        export_limit=3700,
        min_battery_soc=10,
    )
    assert data.grid_voltage == 242.2
    assert data.battery_soc == 49
    assert data.run_mode == RunMode.SELF_USE


def test_run_mode_values():
    assert RunMode.SELF_USE == 0
    assert RunMode.FEEDIN_PRIORITY == 1
    assert RunMode.BACKUP == 2
    assert RunMode(0) == RunMode.SELF_USE
