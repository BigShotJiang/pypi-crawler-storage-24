"""
System API - System information, statistics, and IP limit settings
"""

from typing import Dict, Any, Optional, List


class SystemAPI:
    """System operations"""
    
    def __init__(self, client):
        self.client = client
    
    async def get_stats(self) -> Optional[Dict[str, Any]]:
        """
        Get system statistics
        
        Returns:
            {
                "total_user": int,
                "users_active": int,
                "incoming_bandwidth": int,
                "outgoing_bandwidth": int,
                "incoming_bandwidth_speed": int,
                "outgoing_bandwidth_speed": int
            }
        """
        status, data = await self.client._request("GET", "/system")
        return data if status == 200 else None
    
    async def get_inbounds(self) -> List[Dict[str, Any]]:
        """List all inbounds"""
        status, data = await self.client._request("GET", "/inbounds")
        return data if status == 200 else []
    
    async def get_hosts(self) -> List[Dict[str, Any]]:
        """Get hosts configuration"""
        status, data = await self.client._request("GET", "/hosts")
        return data if status == 200 else []
    
    async def restart_core(self) -> bool:
        """Restart Xray core"""
        status, _ = await self.client._request("POST", "/core/restart")
        return status == 200
    
    async def get_core_config(self) -> Optional[Dict[str, Any]]:
        """Get current core configuration"""
        status, data = await self.client._request("GET", "/core/config")
        return data if status == 200 else None
    
    # ── IP Limit Settings ──────────────────────────────────────────
    
    async def get_ip_limit(self) -> Optional[Dict[str, Any]]:
        """
        Get IP limit settings
        
        Returns:
            {
                "global_ip_limit": int,         # 0 = unlimited
                "ip_online_ttl": int,           # seconds before IP considered offline
                "ip_ban_duration": int,         # minutes to ban after violation; 0 = no penalty
                "ip_limit_ban_delay": int,      # seconds grace period
                "max_concurrent_inbounds": int  # max inbounds per user; 0 = unlimited
            }
        """
        status, data = await self.client._request("GET", "/ip-limit")
        return data if status == 200 else None
    
    async def update_ip_limit(
        self,
        global_ip_limit: int = 0,
        ip_online_ttl: int = 120,
        ip_ban_duration: int = 0,
        ip_limit_ban_delay: int = 10,
        max_concurrent_inbounds: int = 0
    ) -> bool:
        """
        Update IP limit settings
        
        Args:
            global_ip_limit: Max simultaneous IPs per user (0 = unlimited)
            ip_online_ttl: Seconds before an inactive IP is considered offline
            ip_ban_duration: Minutes to ban user after IP limit violation (0 = no penalty)
            ip_limit_ban_delay: Seconds to wait before applying ban (grace period)
            max_concurrent_inbounds: Max distinct inbound tags per user simultaneously (0 = unlimited)
            
        Returns:
            True if successful
        """
        payload = {
            "global_ip_limit": global_ip_limit,
            "ip_online_ttl": ip_online_ttl,
            "ip_ban_duration": ip_ban_duration,
            "ip_limit_ban_delay": ip_limit_ban_delay,
            "max_concurrent_inbounds": max_concurrent_inbounds,
        }
        status, _ = await self.client._request("PUT", "/ip-limit", payload)
        return status == 200
    
    async def get_user_online_ips(self, username: str) -> Optional[Dict[str, Any]]:
        """
        Get online IPs for a specific user
        
        Args:
            username: Username to check
            
        Returns:
            {
                "username": str,
                "ips": [{"ip": str, "node_id": int|None, "last_seen": str}],
                "ip_count": int,
                "ip_limit": int|None,       # user-level override (None = use global)
                "effective_limit": int       # actual limit applied (0 = unlimited)
            }
        """
        try:
            status, data = await self.client._request("GET", f"/online-ips/{username}")
            return data if status == 200 else None
        except:
            return None
