"""
Core Traaaction client.

- track.*        — fire-and-forget (daemon threads, pk_xxx)
- links.*        — sync management (trac_live_xxx)
- missions.*     — sync management
- sellers.*      — sync management
- customers.*    — sync management
- commissions.*  — sync management
- payouts.*      — sync management
- analytics.*    — sync management

Zero external dependencies: only Python stdlib (urllib, json, threading).
"""

import json
import logging
import os
import threading
import urllib.error
import urllib.request
from typing import Any, Dict, Optional

from ._models import LeadParams, SaleParams
from ._track import TrackAPI
from ._http import BaseSyncClient

logger = logging.getLogger("traaaction")

_DEFAULT_BASE_URL = "https://www.traaaction.com"


class TraaactionClient:
    """
    Traaaction Python SDK client.

    Usage::

        from traaaction import Traaaction

        # Tracking only (pk_xxx)
        trac = Traaaction(api_key="pk_live_xxx")
        trac.track.lead(click_id=..., customer_id=str(user.id))

        # Management API (trac_live_xxx)
        trac = Traaaction(api_key="trac_live_xxx")
        links = trac.links.list()
        missions = trac.missions.list(status="ACTIVE")

        # Dual mode: set both keys
        trac = Traaaction(
            api_key="trac_live_xxx",     # used for management API
            public_key="pk_live_xxx",    # used for tracking
        )
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        public_key: Optional[str] = None,
        base_url: str = _DEFAULT_BASE_URL,
    ) -> None:
        """
        Initialize the Traaaction client.

        Args:
            api_key:    Your Traaaction API key.
                        - Public key (``pk_live_xxx``): for tracking only.
                        - Secret key (``trac_live_xxx``): for management API.
                        Defaults to env var ``TRAAACTION_API_KEY`` (or ``TRAC_API_KEY``).
            public_key: Optional separate public key for tracking when ``api_key``
                        is a secret key. Defaults to env var ``TRAAACTION_PUBLIC_KEY``.
            base_url:   Override the Traaaction API base URL (advanced usage).
        """
        resolved_key = (
            api_key
            or os.environ.get("TRAAACTION_API_KEY")
            or os.environ.get("TRAC_API_KEY")
        )
        if not resolved_key:
            raise ValueError(
                "Traaaction API key not found. Set the TRAAACTION_API_KEY "
                "environment variable or pass api_key= to Traaaction()."
            )
        self._api_key = resolved_key
        self._base_url = base_url.rstrip("/")

        # Determine which key to use for tracking (must be a public key pk_xxx)
        resolved_public = (
            public_key
            or os.environ.get("TRAAACTION_PUBLIC_KEY")
        )
        # If api_key is already a public key, use it directly for tracking
        if resolved_key.startswith("pk_"):
            self._tracking_key = resolved_key
        elif resolved_public:
            self._tracking_key = resolved_public
        else:
            self._tracking_key = resolved_key  # Best-effort (secret key for tracking)

        # Track API (fire-and-forget)
        self.track = TrackAPI(self)

        # Management APIs (synchronous, trac_live_xxx)
        _mgmt = BaseSyncClient(self._api_key, self._base_url)
        self._management_http = _mgmt

        from .links import LinksAPI
        from .missions import MissionsAPI
        from .sellers import SellersAPI
        from .customers import CustomersAPI
        from .commissions import CommissionsAPI
        from .payouts import PayoutsAPI
        from .analytics import AnalyticsAPI

        self.links = LinksAPI(self)
        self.missions = MissionsAPI(self)
        self.sellers = SellersAPI(self)
        self.customers = CustomersAPI(self)
        self.commissions = CommissionsAPI(self)
        self.payouts = PayoutsAPI(self)
        self.analytics = AnalyticsAPI(self)

    # ------------------------------------------------------------------
    # Management API helper (used by all management modules)
    # ------------------------------------------------------------------

    def _management_request(
        self,
        method: str,
        path: str,
        json_body: Optional[Dict[str, Any]] = None,
        params: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Delegate to the synchronous HTTP client."""
        return self._management_http.request(method, path, json_body=json_body, params=params)

    # ------------------------------------------------------------------
    # Track helpers (fire-and-forget, used by TrackAPI)
    # ------------------------------------------------------------------

    def stripe_metadata(self, request: object, customer_id: str) -> dict:
        """
        Return a dict suitable for Stripe checkout session metadata.

        Pass the result directly to stripe.checkout.Session.create(metadata=...).

        Args:
            request:     Django (or any) request object. The click ID is read from
                         ``request.trac_click_id`` if available (set by TraacMiddleware),
                         then falls back to cookies.
            customer_id: Your app's unique user ID.

        Returns:
            dict with ``tracCustomerExternalId`` and ``tracClickId`` keys.
        """
        from .django import get_click_id  # soft import — works without Django installed
        click_id = get_click_id(request)
        return {
            "tracCustomerExternalId": customer_id,
            "tracClickId": click_id,
        }

    def _fire_and_forget(self, path: str, payload: dict) -> None:
        """Spawn a daemon thread to POST payload. Never blocks, never raises."""
        t = threading.Thread(
            target=self._post,
            args=(path, payload),
            daemon=True,
        )
        t.start()

    def _post(self, path: str, payload: dict) -> None:
        """Synchronous POST — runs inside a daemon thread for fire-and-forget tracking."""
        url = self._base_url + path
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=data,
            headers={
                "Content-Type": "application/json",
                "x-publishable-key": self._tracking_key,
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=5) as resp:
                logger.debug("traaaction: %s → %s", path, resp.status)
        except urllib.error.HTTPError as e:
            logger.warning("traaaction: HTTP %s on %s — %s", e.code, path, e.reason)
        except urllib.error.URLError as e:
            logger.warning("traaaction: connection error on %s — %s", path, e.reason)
        except Exception as e:  # noqa: BLE001
            logger.warning("traaaction: unexpected error on %s — %s", path, e)
