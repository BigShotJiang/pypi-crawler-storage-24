"""
Traaaction Python SDK
=====================

Affiliate tracking and management for Python web apps.

Quick start::

    pip install traaaction

    from traaaction import Traaaction

    trac = Traaaction()  # reads TRAAACTION_API_KEY env var

    # --- Tracking (fire-and-forget, pk_xxx) ---

    # After user signs up
    trac.track.lead(
        click_id=get_click_id(request),  # from traaaction.django import get_click_id
        event_name="sign_up",
        customer_id=str(user.id),
        customer_email=user.email,
    )

    # Stripe checkout metadata
    metadata = trac.stripe_metadata(request, str(user.id))
    session = stripe.checkout.Session.create(..., metadata=metadata)

    # --- Management API (synchronous, trac_live_xxx) ---

    trac = Traaaction(api_key="trac_live_xxx")

    # Short links
    link = trac.links.create(destination="https://example.com", mission_id="...")
    links = trac.links.list(page=1, limit=50)

    # Missions
    missions = trac.missions.list(status="ACTIVE")
    mission = trac.missions.get(mission_id="...")

    # Sellers
    sellers = trac.sellers.list(mission_id="...")
    seller = trac.sellers.get(seller_id="...")

    # Customers
    customers = trac.customers.list()
    customer = trac.customers.get("your-user-id")

    # Commissions
    commissions = trac.commissions.list(status="PROCEED")

    # Payouts
    payouts = trac.payouts.list()

    # Analytics
    stats = trac.analytics.retrieve(interval="30d")

Django integration::

    from traaaction.django import TraacMiddleware, get_click_id

    # settings.py: add 'traaaction.django.TraacMiddleware' to MIDDLEWARE

Flask integration::

    pip install "traaaction[flask]"

    from traaaction.flask import TraacMiddleware, get_click_id

    app = Flask(__name__)
    app.wsgi_app = TraacMiddleware(app.wsgi_app)

FastAPI integration::

    pip install "traaaction[fastapi]"

    from fastapi import Depends
    from traaaction.fastapi import get_click_id

    @app.post("/signup")
    async def signup(click_id: str | None = Depends(get_click_id)):
        trac.track.lead(customer_id=user.id, click_id=click_id or "")

Full docs: https://traaaction.com/docs/sdks/python
"""

from ._client import TraaactionClient as Traaaction
from .exceptions import TraaactionAPIError, TraaactionAuthError, TraaactionError

__version__ = "1.1.0"
__all__ = [
    "Traaaction",
    "TraaactionError",
    "TraaactionAPIError",
    "TraaactionAuthError",
    "__version__",
]
