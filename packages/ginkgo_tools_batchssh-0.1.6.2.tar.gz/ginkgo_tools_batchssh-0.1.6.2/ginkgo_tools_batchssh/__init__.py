"""
GINKGO-TOOLS-BATCHSSH
=====================

一个用于批量SSH操作和文件传输的Python工具包。

主要功能：
- SSH连接管理
- 远程命令执行（支持超时控制）
- SFTP文件上传下载（支持通配符）
- 批量主机管理
- 日志记录系统

模块说明：
- SSHWrapper: 核心SSH连接和操作类
- module_logger: 日志配置和管理模块  
- moduel_convenient_tools: 便捷工具函数集合

作者: 霍城
邮箱: 495466557@qq.com
"""

__version__ = "0.1.0"
__author__ = "霍城"
__email__ = "495466557@qq.com"
__description__ = "批量SSH操作和文件传输工具包"

# 核心类导入

from .module_SSHwrapper import SSHWrapper
from .module_convenient_tools import read_hosts_file, parse_and_filter_hosts
from .module_logger import setup_logging, get_logger


# 定义公共API
__all__ = [
    # 核心类
    'SSHWrapper',
    
    # 便捷工具函数
    'read_hosts_file',
    'parse_and_filter_hosts',
    
    # 日志相关
    'setup_logging',
    'get_logger',
    
    # 版本信息
    '__version__',
    '__author__',
    '__email__',
    '__description__'
]
