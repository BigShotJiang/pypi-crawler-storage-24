import uuid
import datetime
import os
import logging

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def setup_logging(console_level="INFO", file_level="DEBUG", log_dir="batch_record"):

    """配置整个应用的日志系统"""
    # 获取根记录器
    root_logger = logging.getLogger()

    # 避免重复添加处理器
    # 也保证了在一次链式调用中，只会产生一个日志文件
    if root_logger.handlers:
        return

    timestr = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    os.makedirs(log_dir, exist_ok=True)
    log_path = os.path.join(log_dir, f'batch-{timestr}.log')

    # 设置根记录器的级别为最低，确保消息能传递到处理器
    level_dict = {
        "INFO":logging.INFO,
        "DEBUG":logging.DEBUG,
        "WARNING":logging.WARNING,
        "ERROR":logging.ERROR,
        "CRITICAL":logging.CRITICAL
    }
    root_logger.setLevel(min(level_dict.get(console_level), level_dict.get(file_level)))

    # 控制台输出日志，简化版本
    console_formatter = logging.Formatter("%(levelname)s - %(name)s - %(message)s")
    console_handler = logging.StreamHandler()
    console_handler.setLevel(level_dict.get(console_level))
    console_handler.setFormatter(console_formatter)
    # 记录到文件的使用详细格式化的日志版本
    file_formatter = logging.Formatter("%(asctime)s - %(levelname)s - %(name)s - %(message)s")
    file_handler = logging.FileHandler(log_path, mode='a', encoding='utf-8')
    file_handler.setLevel(level_dict.get(file_level))
    file_handler.setFormatter(file_formatter)

    root_logger.addHandler(console_handler)
    root_logger.addHandler(file_handler)

    # 顺手关掉第三方库的日志
    logging.getLogger("paramiko").setLevel(logging.CRITICAL)
    logging.getLogger("chardet").setLevel(logging.CRITICAL)



def get_logger(name):
    """获取预配置的日志记录器"""
    logger_instance = logging.getLogger(name)
    # 根记录器已经配置，不需要额外配置
    return logger_instance