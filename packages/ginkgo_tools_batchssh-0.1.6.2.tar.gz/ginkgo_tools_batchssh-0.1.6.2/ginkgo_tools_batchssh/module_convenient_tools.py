import os

"""读取hosts文件，优先以当前目录下的Hosts为准，如果不存在，则读取/etc/hosts"""
def read_hosts_file(local_host_dir: str = None) -> str:
    """读取hosts文件内容"""
    local_host = os.path.join(local_host_dir, "hosts")
    try:
        with open(local_host, "r", encoding="utf-8") as f:
            return f.read()
    except:
        with open("/etc/hosts", "r", encoding="utf-8") as f:
            return f.read()




"""过滤操作对象的主机地址列表，并执行去重和反向主机名匹配"""
def parse_and_filter_hosts(hosts_content: str, filter_list: list) -> dict:
    """解析并过滤hosts文件内容"""
    """输入的content可以是read_hosts_file()的值，也可以是手动生成的字符串，保证是ip host1 host2的行格式即可"""
    target_hosts = {}

    for line_num, line in enumerate(hosts_content.splitlines(), 1):
        # 跳过注释行和空行
        line = line.strip()
        if not line or line.startswith("#"): continue

        # 解析行内容
        parts = line.split()
        if len(parts) < 2: continue

        ip_address, *hostnames = parts

        # 跳过本地回环地址
        if ip_address in ("127.0.0.1", "::1"): continue
        # 应用过滤条件
        if filter_list and not all(filter_word in line for filter_word in filter_list): continue
        # 合并主机名（去重）
        if ip_address in target_hosts:
            target_hosts[ip_address].extend(hostnames)
        else:
            target_hosts[ip_address] = hostnames.copy()
    return target_hosts






