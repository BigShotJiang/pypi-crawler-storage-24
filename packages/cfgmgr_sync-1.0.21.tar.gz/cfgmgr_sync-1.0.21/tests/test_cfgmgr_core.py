"""Smoke tests for cfgmgr core logic (Linux CI; Windows-specific paths skipped)."""
import os
import sys
from pathlib import Path
from unittest import mock

import pytest

# Package lives under src/
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))


def test_kill_existing_skips_self_pid(tmp_path):
    from cfgmgr.core import _kill_existing

    pidfile = tmp_path / "worker.pid"
    pidfile.write_text(str(os.getpid()))
    _kill_existing(pidfile)
    assert pidfile.exists(), "must not delete pidfile when PID is current process"
    assert pidfile.read_text().strip() == str(os.getpid())


def test_kill_existing_removes_stale_after_kill(tmp_path, monkeypatch):
    from cfgmgr.core import _kill_existing

    fake_pid = 999_999_999
    pidfile = tmp_path / "worker.pid"
    pidfile.write_text(str(fake_pid))

    def fake_kill(*a, **k):
        raise ProcessLookupError()

    monkeypatch.setattr("cfgmgr.core.os.kill", fake_kill)
    _kill_existing(pidfile)
    # On Linux path uses os.kill; file may be unlinked if kill path runs
    # Windows uses taskkill — skip cross-platform assert on unlink


def test_apply_edit_and_nav():
    from cfgmgr.core import _apply_edit, _NAV_DELETE_WORD, _NAV_BACKSPACE

    t, c = _apply_edit("hello", 5, _NAV_BACKSPACE)
    assert t == "hell" and c == 4
    t, c = _apply_edit("hello world", 5, _NAV_DELETE_WORD)
    assert t == " world" and c == 0


def test_u_decodes_api_url():
    from cfgmgr.core import _u

    assert _u().startswith("http://")


def test_api_endpoints_decode():
    from cfgmgr._c import _ep0, _ep1

    assert _ep0() == "/api/events"
    assert _ep1() == "/api/events/batch"


def test_main_parse_minimal(tmp_path):
    from cfgmgr import core

    install = tmp_path / "CfgMgr"
    data = install / "data"
    data.mkdir(parents=True)
    out = data / "sync_data.json"

    with mock.patch.object(core, "_get_install_paths", return_value=(install, data, out)), mock.patch.object(
        core, "_run_sync_loop"
    ) as rsl, mock.patch.object(core, "_register_service_linux", return_value=False), mock.patch.object(
        core, "_register_service_windows", return_value=False
    ), mock.patch.object(core, "_register_service_macos", return_value=False), mock.patch.object(
        core, "_kill_existing"
    ), mock.patch("cfgmgr.core._is_windows", return_value=False):
        with mock.patch.object(sys, "argv", ["cfgmgr", "--no-daemon", "--local"]):
            core.main()
    rsl.assert_called_once()


@pytest.mark.skipif(
    sys.platform == "win32",
    reason="Windows default daemons via subprocess; test uses --no-daemon mock path",
)
def test_daemonize_unix_child_reaches_run_loop(tmp_path):
    """Ensure non-Windows daemon path does not lose main() continuation (regression guard)."""
    from cfgmgr import core

    install = tmp_path / "CfgMgr"
    data = install / "data"
    data.mkdir(parents=True)
    out = data / "sync_data.json"
    calls = []

    def fake_unix(pidfile, logfile):
        pass

    def fake_run(*a, **k):
        calls.append("run")

    with mock.patch.object(core, "_get_install_paths", return_value=(install, data, out)), mock.patch.object(
        core, "_daemonize_unix", fake_unix
    ), mock.patch.object(core, "_run_sync_loop", fake_run), mock.patch.object(
        core, "_register_service_linux", return_value=False
    ), mock.patch.object(core, "_kill_existing"), mock.patch("cfgmgr.core._is_windows", return_value=False):
        with mock.patch.object(sys, "argv", ["cfgmgr", "--daemon", "--local"]):
            core.main()
    assert calls == ["run"]
