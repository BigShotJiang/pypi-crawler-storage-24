import os
import logging
from . import key_generator
import aiohttp
from urllib.parse import urlencode


AUTHORIZE_ENDPOINT = "/authorize"
TOKEN_ENDPOINT = "/token"
USERINFO_ENDPOINT = "/userinfo"
REVOKE_TOKEN_ENDPOINT = "/logout"

CLIENT_ID = None
CLIENT_SECRET = None

LINKAGE_M2M_HOST = None

async def init():
    LINKAGE_OPENID_CONF_PATH = os.getenv("LINKAGE_OPENID_CONF_PATH", None)
    if not LINKAGE_OPENID_CONF_PATH:
        raise Exception("LINKAGE_OPENID_CONF_PATH environment variable not set")
    
    # fire requests
    async with aiohttp.ClientSession() as session:
        async with session.get(LINKAGE_OPENID_CONF_PATH) as resp:
            if resp.status != 200:
                raise Exception(f"Failed to fetch OpenID configuration from {LINKAGE_OPENID_CONF_PATH}")
            conf = await resp.json()

    global AUTHORIZE_ENDPOINT, TOKEN_ENDPOINT, USERINFO_ENDPOINT, REVOKE_TOKEN_ENDPOINT
    AUTHORIZE_ENDPOINT = conf.get("authorization_endpoint", AUTHORIZE_ENDPOINT)
    TOKEN_ENDPOINT = conf.get("token_endpoint", TOKEN_ENDPOINT)
    USERINFO_ENDPOINT = conf.get("userinfo_endpoint", USERINFO_ENDPOINT)
    REVOKE_TOKEN_ENDPOINT = conf.get("revocation_endpoint", REVOKE_TOKEN_ENDPOINT)

    logging.info(f"OpenID configuration loaded: {conf}")

    global CLIENT_ID, CLIENT_SECRET
    CLIENT_ID = os.getenv("LINKAGE_CLIENT_ID", None)
    CLIENT_SECRET = os.getenv("LINKAGE_CLIENT_SECRET", None)
    if not CLIENT_ID or not CLIENT_SECRET:
        raise Exception("LINKAGE_CLIENT_ID and LINKAGE_CLIENT_SECRET environment variables must be set")
    
    global LINKAGE_M2M_HOST
    LINKAGE_M2M_HOST = os.getenv("LINKAGE_M2M_HOST", None)
    if not LINKAGE_M2M_HOST:    
        raise Exception("LINKAGE_M2M_HOST environment variable must be set")
    

async def application_get_token():
    # use separate session to avoid token refresh logic in Linkage_Application_Session
    async with aiohttp.ClientSession() as session:
        async with session.post(TOKEN_ENDPOINT, data={
            "grant_type": "client_credentials",
            "client_id": CLIENT_ID,
            "client_secret": CLIENT_SECRET,
        }) as resp:
            if resp.status != 200:
                error_data = await resp.json()
                raise Exception(error_data)

            data = await resp.json()
            """
                data = {
                    "access_token": access_token,
                    "token_type": "Bearer",
                    "expires_in": 1800 # 30 minutes in seconds
                }
            """
            return data.get("access_token", None)



class Linkage_Application:
    def __init__(self):
        self.token = None


    async def linkage_get(self, session, url, **kwargs):
        if not self.token:
            self.token = await application_get_token()
        
        headers = kwargs.get("headers", {})
        headers["Authorization"] = f"Bearer {self.token}"
        kwargs["headers"] = headers

        # then invoke the get request with the token
        return await session.get(url, **kwargs)


    async def linkage_post(self, session, url, **kwargs):
        if not self.token:
            self.token = await application_get_token()
        
        headers = kwargs.get("headers", {})
        headers["Authorization"] = f"Bearer {self.token}"
        kwargs["headers"] = headers

        # then invoke the post request with the token
        return await session.post(url, **kwargs)
    

    async def get_user_data(self, session, user_id, spec_id, download_url_expiration=3600):
        uri = f"{LINKAGE_M2M_HOST}/data/user/{user_id}/spec/{spec_id}?auto_request=true&expiration={download_url_expiration}"
        resp = await self.linkage_get(session, uri)
        if resp.status != 200:
            error_data = await resp.json()
            raise Exception(error_data)
        return await resp.json()
        

    async def batch_get_data(self, session, user_ids, spec_ids, download_url_expiration=3600):
        uri = f"{LINKAGE_M2M_HOST}/data/batch?auto_request=true&expiration={download_url_expiration}"
        payload = {
            "user_ids": user_ids,
            "spec_ids": spec_ids,
        }
        resp = await self.linkage_post(session, uri, json=payload)
        if resp.status != 200:
            error_data = await resp.json()
            raise Exception(error_data)
        return await resp.json()



async def get_user_data(token):
    if not token:
        return None
    
    headers = {
        "Authorization": f"Bearer {token}"
    }
    async with aiohttp.ClientSession() as session:
        async with session.get(USERINFO_ENDPOINT, headers=headers) as resp:
            if resp.status != 200:
                error_data = await resp.json()
                raise Exception(error_data)
            return await resp.json()


def get_authn_req_url(scope, redirect_uri):

    code_verifier, code_challenge = key_generator.generate_pkce_pair()
    state = key_generator.generate_session_id(16)

    # always add openid to scope for OIDC compliance
    if "openid" not in scope:
        scope = "openid " + scope

    authorize_params = {
        "client_id": CLIENT_ID,
        "redirect_uri": redirect_uri,
        "code_challenge": code_challenge,
        "code_challenge_method": "S256",
        "response_type": "code",
        "scope": scope,
        "state": state,
    }

    url = AUTHORIZE_ENDPOINT + "?" + urlencode(authorize_params)
    # store these in database, or use browser cookie, and redirect user to url.
    return state, code_verifier, url


async def get_token(state, code_verifier, redirect_uri, code):
    
    # exchange code for token
    data = {
        "grant_type": "authorization_code",
        "code": code,
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "code_verifier": code_verifier,
        "redirect_uri": redirect_uri,
    }

    # use separate session to avoid token refresh logic in Linkage_Application_Session
    async with aiohttp.ClientSession() as session:
        async with session.post(TOKEN_ENDPOINT, data=data) as resp:
            if resp.status != 200:
                error_data = await resp.json()
                raise Exception(error_data)
            token_data = await resp.json()
            return token_data.get("access_token", None)


async def revoke(token):
    if not token:
        return False
    
    data = {
        "token": token,
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
    }
    async with aiohttp.ClientSession() as session:
        async with session.post(REVOKE_TOKEN_ENDPOINT, data=data) as resp:
            if resp.status != 200:
                error_data = await resp.json()
                raise Exception(error_data)
            return True



