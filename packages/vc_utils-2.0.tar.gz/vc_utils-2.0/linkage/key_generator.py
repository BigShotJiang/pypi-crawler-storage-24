import base64
import hashlib
import secrets
import bcrypt
import uuid


# --- 1. PKCE Generation and Verification ---

def generate_pkce_pair():
    """
    Generates a PKCE code_verifier and code_challenge.
    """
    
    # 1. Generate the code_verifier (The Secret Key)
    # The spec requires a random string between 43 and 128 characters long.
    # secrets.token_urlsafe(64) produces an 86-character URL-safe string.
    code_verifier = secrets.token_urlsafe(64)

    # 2. Generate the code_challenge (The Public Padlock)
    # First, hash the verifier using SHA-256
    sha256_hash = hashlib.sha256(code_verifier.encode('ascii')).digest()
    
    # Next, Base64-URL encode the raw hash bytes. 
    # The OAuth spec strictly requires removing the trailing '=' padding characters.
    code_challenge = base64.urlsafe_b64encode(sha256_hash).decode('ascii').rstrip('=')

    return code_verifier, code_challenge


def verify_pkce(code_verifier: str, stored_challenge: str, method: str) -> bool:
    """Validates the verifier against the stored challenge. Only S256 is supported."""
    if method == "S256":
        # 1. Hash the verifier using SHA-256
        hashed = hashlib.sha256(code_verifier.encode("ascii")).digest()
        # 2. Base64-URL encode it (without padding '=' as per RFC 7636)
        encoded = base64.urlsafe_b64encode(hashed).decode("ascii").rstrip("=")
        return encoded == stored_challenge
    return False


# 2. --- Password Hashing ---

def generate_hash(code: str) -> str:
    """Hashes a password using standard bcrypt."""
    # bcrypt requires bytes, so we encode the string first
    pwd_bytes = code.encode('utf-8')
    salt = bcrypt.gensalt()
    hashed_bytes = bcrypt.hashpw(pwd_bytes, salt)
    
    # Return as a string so it can be cleanly saved to Firestore
    return hashed_bytes.decode('utf-8')


def verify_hash(plain_code: str, hashed_code: str) -> bool:
    """Verifies a plain password against the stored hash."""
    plain_bytes = plain_code.encode('utf-8')
    hashed_bytes = hashed_code.encode('utf-8')
    
    return bcrypt.checkpw(plain_bytes, hashed_bytes)


# 3. --- Session ID Generation ---

def generate_session_id(length=64) -> str:
    """Generates a secure random session ID."""
    return secrets.token_urlsafe(length)


def compare_session_id(a: str, b: str) -> bool:
    """Constant-time comparison of two tokens to prevent timing attacks."""
    return secrets.compare_digest(a, b)


# 4. --- Client Credentials Generation ---

def generate_client_id(app_name: str) -> str:
    """Generates a unique client ID for an application."""
    return f"{app_name}_{secrets.token_hex(8)}"


def generate_client_secret(length=32) -> str:
    """Generates a secure random client secret."""
    return secrets.token_urlsafe(length)


# 5. --- Token Hashing ---

def hash_token(token: str) -> str:
    """SHA-256 hash of a token, used as a short deterministic identifier."""
    return hashlib.sha256(token.encode()).hexdigest()


# 6. --- Generate unique id ---

def generate_unique_id(prefix: str = "", length: int = 16) -> str:
    """Generates a unique ID with an optional prefix."""
    unique_part = uuid.uuid4().hex[:length]
    return f"{prefix}{unique_part}"