# vulcan-utils

Vulcan python utility

## Features

### Linkage APIs

- Linkage API for various services

## Installation

```bash
pip install vulcan-utils
```

## Usage

Add environment variables for Linkage M2M host and API key:

```bash
export LINKAGE_OPENID_CONF_PATH="https://idp-linkage.vulcanproduct.com/.well-known/openid-configuration"
export LINKAGE_CLIENT_ID="test-client-id"
export LINKAGE_CLIENT_SECRET="test-client-secret"

export LINKAGE_M2M_HOST="https://application-linkage.vulcanproduct.com"
```

Then you can import and use the Linkage API in your code:

```python
from vulcan_utils import linkage
```

## Test

```bash
pip3 install fastapi uvicorn aiohttp dotenv bcrypt
python3 test.py
```
