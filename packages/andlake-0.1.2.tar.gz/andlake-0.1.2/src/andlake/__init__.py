"""Andlake SDK — pre-configured connections to all platform services.

Import helpers directly from the top-level package::

    from andlake import get_trino_connection, configure_mlflow
    import pandas as pd

    configure_mlflow(experiment_name="fraud-detection")
    conn = get_trino_connection()
    df = pd.read_sql("SELECT * FROM lake.silver.transactions LIMIT 1000", conn)
"""

from andlake._version import __version__
from andlake.config import AndlakeConfig, get_config, reset_config
from andlake.iceberg import get_iceberg_catalog
from andlake.mlflow import configure_mlflow, get_mlflow_client
from andlake.nessie import get_nessie_client
from andlake.s3 import get_default_bucket, get_s3_client, get_s3_resource
from andlake.trino import get_trino_connection, get_trino_engine

__all__ = [
    "__version__",
    # Config
    "AndlakeConfig",
    "get_config",
    "reset_config",
    # Trino
    "get_trino_connection",
    "get_trino_engine",
    # Nessie
    "get_nessie_client",
    # MLflow
    "configure_mlflow",
    "get_mlflow_client",
    # S3
    "get_s3_client",
    "get_s3_resource",
    "get_default_bucket",
    # Iceberg
    "get_iceberg_catalog",
]
