"""PyIceberg catalog configured for the Andlake platform.

Uses the Nessie REST catalog endpoint to query and manage Iceberg tables
directly from Python, bypassing Trino when you need low-level table access
(e.g. reading Parquet files, inspecting snapshots, time-travel).

Usage::

    from andlake import get_iceberg_catalog

    catalog = get_iceberg_catalog()
    table = catalog.load_table("silver.transactions")
    df = table.scan().to_pandas()
"""

from __future__ import annotations

from andlake.config import get_config


def get_iceberg_catalog():
    """Return a PyIceberg REST catalog pointing at the Nessie Iceberg endpoint.

    The catalog is configured with:
    - URI: ``http://nessie:19120/iceberg`` (Nessie's Iceberg REST API)
    - Warehouse: ``s3://<bucket>/trino/warehouse``

    Returns
    -------
    pyiceberg.catalog.rest.RestCatalog
    """
    from pyiceberg.catalog.rest import RestCatalog

    cfg = get_config()

    # Nessie exposes an Iceberg REST catalog at /iceberg on the same host
    # as the Nessie API.  Extract the base URL from the Nessie URI.
    nessie_base = cfg.nessie_uri.rsplit("/api/", 1)[0]
    iceberg_uri = f"{nessie_base}/iceberg"

    return RestCatalog(
        name=cfg.default_catalog,
        uri=iceberg_uri,
        warehouse=f"s3://{cfg.s3_bucket}/trino/warehouse",
    )
