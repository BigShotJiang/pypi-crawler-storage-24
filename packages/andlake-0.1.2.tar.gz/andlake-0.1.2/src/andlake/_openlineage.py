"""Phase 2 stub: OpenLineage event builder.

This internal module will be responsible for constructing OpenLineage
``RunEvent`` messages that capture data lineage during notebook execution.

Phase 2 will implement:
- ``emit_start_event()``  — beginning of a tracked run
- ``emit_complete_event()`` — successful completion
- ``emit_fail_event()`` — run failure
- ``build_dataset_facet()`` — table read/write facets
- ``build_job_facet()``  — notebook job metadata

For now this module is intentionally minimal to reserve the namespace.
"""

from __future__ import annotations


def _placeholder() -> None:
    """Placeholder to prevent the module from being empty.

    This will be replaced with real OpenLineage event construction
    in Phase 2.
    """
