"""Nessie catalog client for branch/tag management.

Nessie provides Git-like version control for Iceberg tables.  The client
returned here is pre-configured to point at the in-cluster Nessie server.

Usage::

    from andlake import get_nessie_client

    client = get_nessie_client()
    branches = client.list_references()
"""

from __future__ import annotations

from andlake.config import get_config


def get_nessie_client():
    """Return a ``pynessie`` client configured from environment variables.

    Returns
    -------
    pynessie.NessieClient
    """
    from pynessie import NessieClient

    cfg = get_config()
    return NessieClient(
        config={"endpoint": cfg.nessie_uri},
    )
