"""Upstream client tests."""
