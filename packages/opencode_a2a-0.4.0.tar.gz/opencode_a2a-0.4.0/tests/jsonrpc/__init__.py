"""JSON-RPC surface tests."""
