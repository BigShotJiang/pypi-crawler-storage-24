"""Execution-pipeline tests."""
