"""Script contract tests."""
