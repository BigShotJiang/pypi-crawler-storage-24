"""Part-normalization tests."""
