"""Contract-consistency tests."""
