#!/usr/bin/env python3
"""
Plugin para integración con Azure DevOps.
Se activa automáticamente si AZURE_DEVOPS_ENABLED=true en .env
"""
import os
import re
import glob
from .base_plugin import BasePlugin
from hakalab_framework.core.azure_devops_manager import AzureDevOpsManager


class AzureDevOpsPlugin(BasePlugin):
    """
    Plugin para integración automática con Azure DevOps.

    Funcionalidades:
    - Actualiza work items (test cases) con el estado del test
    - Adjunta reporte HTML y video a ambos tags (test case y task)
    - Se configura completamente desde .env

    Convención de tags (misma lógica que Jira):
      1er tag → Test Case (se actualiza estado + adjuntos)
      2do tag → Task/Historia (solo adjuntos)
    """

    def _is_enabled(self) -> bool:
        """Plugin habilitado si AZURE_DEVOPS_ENABLED=true."""
        return os.getenv('AZURE_DEVOPS_ENABLED', 'false').lower() == 'true'

    def before_all(self, context) -> None:
        """Inicializa el gestor de Azure DevOps."""
        if not self.enabled:
            return
        context.azure_devops = AzureDevOpsManager(context)
        if context.azure_devops.enabled:
            print("🔵 Azure DevOps Plugin inicializado")
        else:
            print("⚠️ Azure DevOps Plugin habilitado pero configuración incompleta")

    def after_scenario(self, context, scenario) -> None:
        """Recopila tags y actualiza el estado del test case (1er tag)."""
        if not self.enabled or not hasattr(context, 'azure_devops'):
            return
        if not context.azure_devops.enabled:
            return

        try:
            status = context.azure_devops.config['status_passed']
            if scenario.status == 'failed':
                status = context.azure_devops.config['status_failed']

            # Actualizar solo el test case (1er tag)
            results = context.azure_devops.process_scenario_tags(
                scenario, status, None
            )

            if results.get('test_case_updated'):
                print(f"   ✅ Work item {results['test_case_id']} actualizado: {status}")

            # Recopilar TODOS los tags numéricos para adjuntar en after_all
            if not hasattr(context, '_azure_work_item_ids'):
                context._azure_work_item_ids = []

            if hasattr(scenario, 'tags'):
                for tag in scenario.tags:
                    wid = context.azure_devops._extract_work_item_id(tag)
                    if wid and wid not in context._azure_work_item_ids:
                        context._azure_work_item_ids.append(wid)

        except Exception as e:
            print(f"❌ Error en Azure DevOps Plugin (after_scenario): {e}")

    def after_all(self, context) -> None:
        """Adjunta HTML y video a TODOS los work items recopilados (ambos tags)."""
        if not self.enabled or not hasattr(context, 'azure_devops'):
            return
        if not context.azure_devops.enabled:
            return

        work_item_ids = getattr(context, '_azure_work_item_ids', [])
        if not work_item_ids:
            return

        print("\n📎 AzureDevOpsPlugin: Adjuntando reportes...")

        report_path = self._find_latest_html_report(context)
        video_path = self._find_latest_video(context)

        for wid in work_item_ids:
            # HTML
            if report_path:
                success = context.azure_devops.attach_file_to_work_item(
                    wid, report_path,
                    comment=f"Reporte HTML - {self._timestamp()}"
                )
                if success:
                    print(f"   📄 Reporte HTML adjuntado a work item {wid}")

            # Video
            if video_path:
                success = context.azure_devops.attach_file_to_work_item(
                    wid, video_path,
                    comment=f"Video de ejecución - {self._timestamp()}"
                )
                if success:
                    print(f"   🎬 Video adjuntado a work item {wid}")

        print("✅ AzureDevOpsPlugin: Procesamiento completado")

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _timestamp() -> str:
        from datetime import datetime
        return datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def _find_latest_html_report(self, context) -> str:
        """Busca el reporte HTML más reciente."""
        from pathlib import Path

        # 1. Contexto
        if hasattr(context, 'html_report_path'):
            p = Path(context.html_report_path)
            if p.exists():
                return str(p)

        # 2. Directorio configurado en .env
        report_cfg = context.azure_devops.config.get('report_path', '')
        if report_cfg:
            report_dir = Path(report_cfg).parent
        else:
            report_dir = Path(os.getenv('HTML_REPORTS_DIR', 'html-reports'))

        if not report_dir.exists():
            return None

        html_files = list(report_dir.glob('*.html'))
        if not html_files:
            return None

        return str(max(html_files, key=lambda p: p.stat().st_mtime))

    @staticmethod
    def _find_latest_video(context) -> str:
        """Busca el video más reciente (misma lógica que JiraConfigPlugin)."""
        # 1. Videos renombrados por el framework
        if hasattr(context, 'saved_videos') and context.saved_videos:
            for video in reversed(context.saved_videos):
                if os.path.exists(video):
                    return video

        # 2. Video path explícito
        if hasattr(context, 'video_path') and context.video_path:
            if os.path.exists(context.video_path):
                return context.video_path

        # 3. Buscar en VIDEO_DIR filtrando temporales
        video_dir = os.getenv('VIDEO_DIR', 'videos')
        if not os.path.exists(video_dir):
            return None

        temp_pattern = re.compile(
            r'^[0-9a-f]{8}(-[0-9a-f]{4}){3}-[0-9a-f]{12}\.'
            r'|^[0-9a-f]{20,}\.',
            re.IGNORECASE
        )
        video_files = []
        for ext in ("webm", "mp4", "avi"):
            for f in glob.glob(os.path.join(video_dir, f"*.{ext}")):
                if not temp_pattern.match(os.path.basename(f)):
                    video_files.append(f)

        if video_files:
            return max(video_files, key=os.path.getmtime)

        return None
