import json
import os
import re
import subprocess
from abc import ABC
from typing import Optional, List
import copy

import yaml

from ..utility import custom_print as log
from ..utils.constants import (
    PBT_FILE_NAME,
    LANGUAGE,
    JOBS,
    PIPELINES,
    PIPELINE_CONFIGURATIONS,
    PROJECT_CONFIGURATIONS,
    CONFIGURATIONS,
    JSON_EXTENSION,
    BASE_PIPELINE,
    PROJECT_ID_PLACEHOLDER_REGEX,
    PROJECT_RELEASE_VERSION_PLACEHOLDER_REGEX,
    PROJECT_RELEASE_TAG_PLACEHOLDER_REGEX,
    GEMS,
    GEM_CONTAINER,
    PROJECT_URL_PLACEHOLDER_REGEX,
    PROJECT_CONFIGURATIONS_CONFIGS_PATH,
)
from ..utils.exceptions import ProjectPathNotFoundException, ProjectFileNotFoundException
from ..utils.versioning import update_all_versions
from ..utils.project_models import Colors

# Example:
# 'gitUri=http://gitserver:3000/UnSTjHIY_team_5/UnSTjHIY_project_12.git&subPath=&tag=HelloWorld/rashmin-1.0.25&projectSubscriptionProjectId=12&path=pipelines/customers_orders'
SUBSCRIBED_ENTITY_URI_REGEX = re.compile(
    r"gitUri=(.*)&subPath=(.*)&tag=(.*)&projectSubscriptionProjectId=(.*)&path=(.*)"
)

# Match "2.12" or "2.13" in strings like "scala2.12", "12.2.x-scala2.13", or "prophecy-libs_2.13"


def _get_scala_version() -> str:
    """
    Resolve Scala major version (2.12 or 2.13) for prophecy-libs package name.
    Priority: SCALA_VERSION env -> SPARK_VERSION env -> scalac/scala -version -> sbt scalaVersion -> default 2.12.
    """
    # 1. check if SCALA_VERSION env var is set
    scala_version_env = os.environ.get("SCALA_VERSION")
    if scala_version_env is not None and scala_version_env.strip():
        if scala_version_env.strip() in ("2.12", "2.13"):
            log(f"[DEBUG] SCALA_VERSION env detected: {scala_version_env.strip()}")
            return scala_version_env.strip()
        else:
            log(f"[DEBUG] Invalid SCALA_VERSION value detected: {scala_version_env}")
            raise ValueError(f"Invalid SCALA_VERSION for prophecy-libs (must be 2.12 or 2.13): {scala_version_env}")

    # 2. From SPARK_VERSION (e.g. "12.2.x-scala2.12" or "3.5.0-scala2.13")
    spark_version_str = os.environ.get("SPARK_VERSION", "")
    SPARK_SCALA_VERSION_RE = re.compile(r"-scala2\.(12|13)\b")
    if spark_version_str:
        log(f"[DEBUG] SPARK_VERSION env detected: {spark_version_str}")
        m = SPARK_SCALA_VERSION_RE.search(spark_version_str)
        if m:
            scala_version = f"2.{m.group(1)}"
            log(f"[DEBUG] Scala version found in SPARK_VERSION: {scala_version}")
            return scala_version
        else:
            log(f"[DEBUG] No scala version matched in SPARK_VERSION: {spark_version_str}")

    # 3. From scalac -version or scala -version on the machine
    for cmd in (["scalac", "-version"], ["scala", "-version"]):
        try:
            log(f"[DEBUG] Running subprocess to detect scala version: {' '.join(cmd)}")
            out = subprocess.run(cmd, capture_output=True, text=True, timeout=5, check=False)
            SCALA_VERSION_RE = re.compile(r"version\s+2\.(12|13)")
            if out.returncode == 0 and out.stderr:
                m = SCALA_VERSION_RE.search(out.stderr)
                if m:
                    scala_version = f"2.{m.group(1)}"
                    log(f"[DEBUG] Scala version detected from {cmd[0]} stderr: {scala_version}")
                    os.environ["SCALA_VERSION"] = scala_version  # Cache in env var
                    return scala_version
            if out.stdout:
                m = SCALA_VERSION_RE.search(out.stdout)
                if m:
                    scala_version = f"2.{m.group(1)}"
                    log(f"[DEBUG] Scala version detected from {cmd[0]} stdout: {scala_version}")
                    os.environ["SCALA_VERSION"] = scala_version  # Cache in env var
                    return scala_version
            log(f"[DEBUG] No scala version detected with command: {' '.join(cmd)}")
        except (FileNotFoundError, subprocess.TimeoutExpired) as e:
            log(f"[DEBUG] Command failed: {' '.join(cmd)}; error: {e}")
            continue

    # 4. Try 'sbt scalaVersion'
    try:
        log(f"[DEBUG] Running subprocess to detect scala version via sbt scalaVersion")
        out = subprocess.run(["sbt", "scalaVersion"], capture_output=True, text=True, timeout=15, check=False)
        # Output is likely multi-line; scan all lines.
        # Regex matches 2.12, 2.13 at start of a version string like '2.12.17'.
        SBT_SCALA_VERSION_RE = re.compile(r"2\.(12|13)\.")
        for line in out.stdout.splitlines():
            m = SBT_SCALA_VERSION_RE.search(line)
            if m:
                scala_version = f"2.{m.group(1)}"
                log(f"[DEBUG] Scala version detected from sbt: {scala_version}, line: {line}")
                os.environ["SCALA_VERSION"] = scala_version  # Cache in env var
                return scala_version
        for line in out.stderr.splitlines():
            m = SBT_SCALA_VERSION_RE.search(line)
            if m:
                scala_version = f"2.{m.group(1)}"
                log(f"[DEBUG] Scala version detected from sbt (stderr): {scala_version}, line: {line}")
                os.environ["SCALA_VERSION"] = scala_version  # Cache in env var
                return scala_version
        log("[DEBUG] No scala version detected from sbt output")
    except (FileNotFoundError, subprocess.TimeoutExpired) as e:
        log(f"[DEBUG] Command failed: sbt scalaVersion; error: {e}")

    log("[DEBUG] Defaulting to Scala version 2.12")
    return "2.12"


def is_cross_project_pipeline(pipeline):
    match = SUBSCRIBED_ENTITY_URI_REGEX.search(pipeline)

    if match:
        git_uri, sub_path, tag, project_subscription_project_id, path = match.groups()
        return project_subscription_project_id, tag.split("/")[1], path
    else:
        return None, None, None


def wrap_main_file_in_try_except(main_file_content: str) -> str:
    contents_line = "\n".join([f"  {line}" for line in main_file_content.split("\n")])

    return f"try:\n{contents_line}\nexcept ModuleNotFoundError:\n  pass"


def _read_file_content(file_path: str) -> Optional[str]:
    if not os.path.exists(file_path):
        return None
        # If the file exists, read its content
    with open(file_path, "r") as file:
        content = file.read()
        return content


class Project:
    _DATABRICKS_JOB_JSON = "databricks-job.json"
    _CODE_FOLDER = "code"

    def __init__(
        self,
        project_path: str,
        project_id: Optional[str] = None,
        release_tag: Optional[str] = None,
        release_version: Optional[str] = None,
        dependant_project_list: Optional[str] = None,
    ):
        self.project_id = project_id
        self.project_path = os.path.abspath(project_path)

        self.release_tag = release_tag
        self.release_version = release_version
        self.md_url = os.environ.get("MD_PATH", "")

        self.pbt_project_dict = {}
        self.project_language = None
        self.jobs = {}
        self.pipelines = {}
        self.pipeline_id_to_name = {}
        self.gems = {}

        self._verify_project()
        self._load_project_config()

        self._extract_project_info()
        self.pipeline_configurations = self._load_pipeline_configurations()
        self.subscribed_project_configurations = self._load_subscribed_project_configurations()
        self.project_configurations = self._load_project_configurations()

        log(f"Project name {self.pbt_project_dict.get('name', '')}")
        pipelines_str = ", ".join(
            map(
                lambda pipeline: "%s (%s)" % (pipeline["name"], pipeline["language"]),
                self.pipelines.values(),
            )
        )

        jobs_str = ", ".join(
            map(
                lambda job: "%s" % (job["name"]),
                self.jobs.values(),
            )
        )
        log(f"Found {len(self.jobs)} jobs: {jobs_str}")
        log(f"Found {len(self.pipelines)} pipelines: {pipelines_str}\n  ")

        self.dependent_project = None

        if dependant_project_list is not None and len(dependant_project_list) > 0:
            project_paths = dependant_project_list.split(",")
            dependant_projects = []
            log("Parsing dependent projects")
            for path in project_paths:
                dependant_projects.append(Project(path, ""))

            self.dependent_project = DependentProjectCli(dependant_projects)
        else:
            self.dependent_project = DependentProjectAPP(project_path, self)

        self.fabric_volumes_detected = self._detect_volume_usage_per_fabric()

    @property
    def name(self) -> str:
        return self.pbt_project_dict.get("name")

    def load_databricks_job(self, job_id: str) -> Optional[str]:
        try:
            path = os.path.join(self.project_path, job_id, self._CODE_FOLDER, self._DATABRICKS_JOB_JSON)
            content = _read_file_content(path)

            if content is not None:
                return self._replace_placeholders(self._DATABRICKS_JOB_JSON, content)

            return content
        except Exception:
            return None

    def load_airflow_base_folder_path(self, job_id):
        return os.path.join(self.project_path, job_id, self._CODE_FOLDER)

    def load_airflow_folder(self, job_id):
        return {
            path: self._replace_placeholders(path, content)
            for path, content in self._read_directory(
                os.path.join(self.project_path, job_id, self._CODE_FOLDER)
            ).items()
        }

    def load_airflow_folder_with_placeholder(self, job_id):
        return self._read_directory(os.path.join(self.project_path, job_id, self._CODE_FOLDER))

    def load_airflow_aspect(self, job_id: str) -> Optional[str]:
        path = os.path.join(self.project_path, job_id, "pbt_aspects.yml")
        return _read_file_content(path)

    def load_pipeline_base_path(self, pipeline):
        return os.path.join(self.project_path, pipeline, self._CODE_FOLDER)

    def load_pipeline_folder(self, pipeline):
        base_path = os.path.join(self.project_path, pipeline, self._CODE_FOLDER)

        content = self._read_directory(base_path)
        if len(content) > 0:
            return content
        else:
            return self.dependent_project.load_pipeline_folder(pipeline)

    @staticmethod
    def get_pipeline_whl_or_jar(base_path: str):
        for dir_path, dir_names, filenames in os.walk(base_path):
            for filename in filenames:
                full_path = os.path.join(dir_path, filename)
                if full_path.endswith(".whl") or full_path.endswith(".jar"):
                    return full_path

    @staticmethod
    def get_pipeline_jar_for_scala_version(base_path: str, scala_version: str) -> Optional[str]:
        target_dir = os.path.join(base_path, "target")
        if not os.path.isdir(target_dir):
            return None
        suffix = f"_{scala_version}.jar"
        for name in os.listdir(target_dir):
            if name.endswith(suffix) and "jar-with-dependencies" not in name:
                return os.path.join(target_dir, name)
        return None

    def get_py_pipeline_main_file(self, pipeline_id):
        if self.does_project_contains_dynamic_pipeline() and pipeline_id in self.pipelines:
            return self._uber_main_py_file()
        else:
            try:
                main_file = os.path.join(self.project_path, pipeline_id, self._CODE_FOLDER, "main.py")
                data = _read_file_content(main_file)
                return data
            except Exception:
                return self.dependent_project.get_py_pipeline_main_file(pipeline_id)

    def _uber_main_py_file(self):
        main_file = ""
        for pipeline in self.pipelines.keys():
            main_file = os.path.join(self.project_path, pipeline, self._CODE_FOLDER, "main.py")
            data = _read_file_content(main_file)
            if data is not None:
                main_file = main_file + "\n\n" + wrap_main_file_in_try_except(data)

        return main_file

    def get_pipeline_absolute_path(self, pipeline_id):
        return os.path.join(os.path.join(self.project_path, pipeline_id), "code")

    def get_pipeline_id(self, pipeline_name):
        return next((k for k, v in self.pipelines.items() if v["name"] == pipeline_name), None)

    def get_pipeline_name(self, pipeline_id):
        try:
            pipeline_path = pipeline_id
            pipelines = self.pipelines
            return pipelines.get(pipeline_path, {}).get("name", pipeline_path.split("/")[-1])
        except Exception:
            return self.dependent_project.get_pipeline_name(pipeline_id)

    def get_maven_dependencies_for_python_pipelines(self, pipeline_id=None):
        """
        leave pipeline id blank to get dependencies for all pipelines.
        """
        # gather project level dependencies:
        project_level_dependencies = self.pbt_project_dict.get("dependencies", [])
        project_level_maven_dependencies = [d for d in project_level_dependencies if d["type"] == "coordinates"]

        # the plibs maven does not have a normal coordinate so we have to make one:
        spark_version = os.environ.get("SPARK_VERSION", "{{REPLACE_ME}}")
        plibs_maven_deps = [d for d in project_level_dependencies if d.get("name") == "plibMaven"]
        if len(plibs_maven_deps) != 1:
            log(
                f"{Colors.WARNING}Skipping creating maven dependencies, pbt_project.yml is missing "
                f"prophecy-libs information. please update your prophecy-libs in the Prophecy UI{Colors.ENDC}"
            )
            return None
        plibs_maven_dep = copy.deepcopy(plibs_maven_deps[0])
        plibs_maven_dep["type"] = "coordinates"
        scala_version = _get_scala_version()
        plibs_maven_dep["package"] = f"prophecy-libs_{scala_version}"
        plibs_maven_dep["version"] = spark_version + "-" + plibs_maven_dep["version"]
        plibs_maven_dep["coordinates"] = f"io.prophecy:{plibs_maven_dep['package']}:{plibs_maven_dep['version']}"
        project_level_maven_dependencies.append(plibs_maven_dep)

        pipeline_level_maven_dependencies = []
        pipelines_to_process = [pipeline_id] if pipeline_id else self.pipelines
        for pid in pipelines_to_process:
            rdc = self.load_pipeline_folder(pid)
            workflow_str = rdc.get(".prophecy/workflow.latest.json")
            if not workflow_str:
                continue
            workflow = json.loads(workflow_str)
            pipeline_level_dependencies = workflow.get("metainfo", {}).get("externalDependencies", [])
            pipeline_level_maven_dependencies += [
                d for d in pipeline_level_dependencies if d.get("type") == "coordinates"
            ]
        maven_dependencies = pipeline_level_maven_dependencies + project_level_maven_dependencies
        return maven_dependencies

    def _read_directory(self, base_path: str):
        rdc = {}
        ignore_dirs = ["build", "dist", "__pycache__"]

        for dir_path, dir_names, filenames in os.walk(base_path):
            if os.path.basename(dir_path) in ignore_dirs:
                continue

            # Add resources to RDC
            if "resources" in dir_names:
                resource_dir_path = os.path.join(dir_path, "resources")
                for resource_subdir_path, _, resource_filenames in os.walk(resource_dir_path):
                    if os.path.basename(resource_subdir_path) in ignore_dirs:
                        continue

                    for resource_filename in resource_filenames:
                        resource_full_path = os.path.join(resource_subdir_path, resource_filename)
                        resource_content = _read_file_content(resource_full_path)
                        if resource_content is not None:
                            relative_path = os.path.relpath(resource_full_path, base_path)
                            rdc[relative_path] = resource_content

            # Add generated code to RDC
            for filename in filenames:
                if filename.endswith((".py", ".json", ".conf", ".scala", "pom.xml")):
                    full_path = os.path.join(dir_path, filename)
                    content = _read_file_content(full_path)
                    if content is not None:
                        relative_path = os.path.relpath(full_path, base_path)
                        rdc[relative_path] = content
        return rdc

    def _load_subscribed_project_yml(self, subscribed_project_id: str):
        path = os.path.join(self.project_path, ".prophecy", subscribed_project_id, "pbt_project.yml")
        content = _read_file_content(path)
        if content is not None:
            return yaml.safe_load(content)

    def _verify_project(self):
        if not os.path.exists(self.project_path):
            raise ProjectPathNotFoundException(f"Project path does not exist {self.project_path}")

        if not os.path.exists(os.path.join(self.project_path, PBT_FILE_NAME)):
            raise ProjectFileNotFoundException(f"Project file does not exist at path {self.project_path}")

    def _load_project_config(self):
        pbt_project_path = os.path.join(self.project_path, PBT_FILE_NAME)
        content = _read_file_content(pbt_project_path)
        if content is not None:
            self.pbt_project_dict = yaml.safe_load(content)

    def _extract_project_info(self):
        self.project_language = self.pbt_project_dict.get(LANGUAGE, None)
        self.jobs = self.pbt_project_dict.get(JOBS, {})
        self.pipelines = self.pbt_project_dict.get(PIPELINES, {})
        self.gems = self.pbt_project_dict.get(GEM_CONTAINER, {}).get(GEMS, [])

    def _load_pipeline_configurations(self):
        pipeline_configurations = {}

        pipeline_conf = dict(self.pbt_project_dict.get(PIPELINE_CONFIGURATIONS, []))

        for pipeline_config_path, pipeline_config_object in pipeline_conf.items():
            configurations = {}

            for configurations_key in pipeline_config_object[CONFIGURATIONS]:
                config_name = pipeline_config_object[CONFIGURATIONS][configurations_key]["name"]
                file_path = os.path.join(self.project_path, configurations_key + JSON_EXTENSION)

                config = _read_file_content(file_path)

                # in case of empty config file, we will skip it
                if config is not None:
                    configurations[config_name] = config

            pipeline_configurations[pipeline_config_object[BASE_PIPELINE]] = configurations

        return pipeline_configurations

    def _load_project_configurations(self):
        # project_path -> projectConfigurations/config/code/configs -> all json files as a dict of fileName (no extension): parsed JSON content
        config_dir = os.path.join(self.project_path, PROJECT_CONFIGURATIONS_CONFIGS_PATH)
        config_dict = {}
        if os.path.exists(config_dir) and os.path.isdir(config_dir):
            for file_name in os.listdir(config_dir):
                if file_name.endswith(JSON_EXTENSION):
                    file_path = os.path.join(config_dir, file_name)
                    content = _read_file_content(file_path)
                    if content is not None:
                        try:
                            key = os.path.splitext(file_name)[0]
                            config_dict[key] = content
                        except Exception:
                            log(f"Failed to parse JSON for {file_name}", step_id="Summary")
        return config_dict

    def _load_subscribed_project_configurations(self):
        project_configurations = {}

        project_conf = dict(self.pbt_project_dict.get(PROJECT_CONFIGURATIONS, []))

        if not project_conf:
            return project_configurations

        for project_config_path, project_config_object in project_conf.items():
            configurations = {}

            # Check if CONFIGURATIONS key exists before accessing it
            if CONFIGURATIONS in project_config_object:
                for configurations_key in project_config_object[CONFIGURATIONS]:
                    if "name" not in project_config_object[CONFIGURATIONS][configurations_key]:
                        continue

                    config_name = project_config_object[CONFIGURATIONS][configurations_key]["name"]
                    file_path = os.path.join(self.project_path, configurations_key + JSON_EXTENSION)

                    config = _read_file_content(file_path)

                    if config is not None:
                        configurations[config_name] = config

            if configurations:
                project_configurations.update(configurations)

        return project_configurations

    def _replace_placeholders(self, path: str, content: str) -> str:
        if path.endswith(".json") or path.endswith(".scala") or path.endswith(".py"):
            content = (
                content.replace(PROJECT_ID_PLACEHOLDER_REGEX, self.project_id)
                .replace(PROJECT_RELEASE_VERSION_PLACEHOLDER_REGEX, self.release_version)
                .replace(PROJECT_RELEASE_TAG_PLACEHOLDER_REGEX, self.release_tag)
                .replace(PROJECT_URL_PLACEHOLDER_REGEX, self.md_url)
            )

        return content

    # only check for non-empty gems directory
    def non_empty_gems_directory(self):
        return os.path.exists(os.path.join(self.project_path, "gems"))

    def get_package_path(self, _pipeline_id) -> (str, str):
        pipeline_path = os.path.join(self.project_path, _pipeline_id, "code")
        for root, dirs, files in os.walk(pipeline_path):
            for file in files:
                if file.endswith(".jar") or file.endswith(".whl"):
                    return root, file

    def fabrics(self) -> List[str]:
        return list(
            set(
                [
                    content.get("fabricUID", None)
                    for content in self.jobs.values()
                    if content.get("fabricUID", None) is not None
                ]
            )
        )

    @staticmethod
    def strip_prefix(value, prefix):
        if value.startswith(prefix):
            return value[len(prefix) :]
        return value

    def _detect_volume_usage_per_fabric(self):
        fabrics_using_volumes = {}
        for job_id, content in self.jobs.items():
            if content.get("fabricUID", None) is not None:
                fabric_uid = str(content["fabricUID"])
                fabric_path = self._find_path_job_id(job_id)
                if fabric_path and (fabric_path.startswith("/Volumes") or fabric_path.startswith("dbfs:/Volumes")):
                    # path can contain any number of delimiters if it's a volume
                    # /Volume/vol1/subfolder1/subfolder2/etc
                    # therefore, find the common substring and get the base path up to that point
                    fabrics_using_volumes[fabric_uid] = fabric_path.split("/prophecy/artifacts/")[0]
        return fabrics_using_volumes

    def _find_path_job_id(self, job_id):
        db_jobs = self.load_databricks_job(job_id)
        if db_jobs is not None:
            json_content = json.loads(db_jobs)
            for component in json_content["components"]:
                for c_name, c_content in component.items():
                    path = c_content["path"]
                    return path
        return None

    def _find_path(self):
        # it's just returning first found.
        for job_id in self.jobs.keys():
            path = self._find_path_job_id(job_id)
            if path:
                return path
        return None

    def find_customer_name(self) -> str:
        path = self._find_path()
        if path is not None:
            # path can contain any number of delimiters if it's a volume
            # /Volume/vol1/subfolder1/subfolder2/etc
            # therefore, find the common substring. delimiters will be consistent after that point.
            return path.split("/prophecy/artifacts/")[1].split("/")[0]
        else:
            return "dev"

    def find_control_plane_name(self):
        path = self._find_path()
        if path is not None:
            # path can contain any number of delimiters if it's a volume
            # /Volume/vol1/subfolder1/subfolder2/etc
            # therefore, find the common substring. delimiters will be consistent after that point.
            return path.split("/prophecy/artifacts/")[1].split("/")[1]
        else:
            return "execution"

    def load_main_file(self, path):
        main_file = os.path.join(self.project_path, path, self._CODE_FOLDER, "main.py")
        return _read_file_content(main_file)

    def is_cross_project_pipeline(self, from_path):
        if from_path in self.pipelines:
            return None, None, None
        return self.dependent_project.is_cross_project_pipeline(from_path)

    def does_project_contains_dynamic_dataproc_pipeline(self):
        for job in self.jobs.keys():
            rdc = self.load_airflow_folder_with_placeholder(job)
            if rdc is not None and rdc.get("prophecy-job.json"):
                prophecy_json = json.loads(rdc.get("prophecy-job.json"))
                if "metainfo" in prophecy_json and "dynamicPipelineStatus" in prophecy_json["metainfo"]:
                    dynamic_pipeline_status = prophecy_json["metainfo"]["dynamicPipelineStatus"]
                    is_dynamic = dynamic_pipeline_status["dataproc"]

                    # if is true then return true otherwise False.
                    if is_dynamic:
                        return is_dynamic

        return False

    def does_project_contains_dynamic_pipeline(self):
        for job in self.jobs.keys():
            rdc = self.load_airflow_folder_with_placeholder(job)
            if rdc is not None and rdc.get("prophecy-job.json"):
                prophecy_json = json.loads(rdc.get("prophecy-job.json"))
                if "metainfo" in prophecy_json and "dynamicPipelineStatus" in prophecy_json["metainfo"]:
                    dynamic_pipeline_status = prophecy_json["metainfo"]["dynamicPipelineStatus"]
                    is_dynamic = (
                        dynamic_pipeline_status["databricks"]
                        | dynamic_pipeline_status["dataproc"]
                        | dynamic_pipeline_status["emr"]
                    )

                    # if is true then return true otherwise False.
                    if is_dynamic:
                        return is_dynamic

        return False

    def update_version(self, new_version, force=False, pbt_only=False):
        update_all_versions(
            self.project_path,
            self.project_language,
            orig_project_version=self.pbt_project_dict["version"],
            new_version=new_version,
            force=force,
            pbt_only=pbt_only,
        )
        # update our internal reference in case calls get chained which use this field.
        self.pbt_project_dict["version"] = new_version


class DependentProject(ABC):
    @staticmethod
    def is_cross_project_pipeline(pipeline_id):
        (pid, tag, path) = is_cross_project_pipeline(pipeline_id)
        if pid is not None and tag is not None and path is not None:
            return True
        else:
            return False

    def get_py_pipeline_main_file(self, pipeline_id) -> Optional[str]:
        pass

    def get_pipeline_name(self, pipeline_id: str) -> Optional[str]:
        pass

    def load_pipeline_folder(self, pipeline_id: str):
        pass


class DependentProjectCli(DependentProject, ABC):
    def __init__(self, dependant_projects: List[Project]):
        self.dependant_projects = dependant_projects

    def get_py_pipeline_main_file(self, pipeline_id) -> Optional[str]:
        (pid, tag, path) = is_cross_project_pipeline(pipeline_id)
        for project in self.dependant_projects:
            if path in project.pipelines:
                return project.get_py_pipeline_main_file(path)

        return None

    def get_pipeline_name(self, pipeline_id: str) -> Optional[str]:
        (pid, tag, path) = is_cross_project_pipeline(pipeline_id)
        for project in self.dependant_projects:
            if path in project.pipelines:
                return project.pipelines[path]["name"]

        return None

    def load_pipeline_folder(self, pipeline_id: str):
        (pid, tag, path) = is_cross_project_pipeline(pipeline_id)
        for project in self.dependant_projects:
            if path in project.pipelines:
                return project.load_pipeline_folder(path)

        return {}


class DependentProjectAPP(DependentProject, ABC):
    def __init__(self, path: str, main_project: Project):
        self.path = path
        self.project = main_project
        self.base_path = self.project.project_path

    def get_py_pipeline_main_file(self, pipeline_id) -> Optional[str]:
        (pid, tag, path) = is_cross_project_pipeline(pipeline_id)
        if pid is not None:
            base_path = "{}/.prophecy/{}/{}".format(self.base_path, pid, path)
            return self.project.load_main_file(base_path)
        else:
            return None

    def get_pipeline_name(self, pipeline_id: str) -> Optional[str]:
        (pid, tag, path) = is_cross_project_pipeline(pipeline_id)
        if pid is not None:
            base_path = "{}/.prophecy/{}".format(self.base_path, pid)
            return Project(base_path, pid).get_pipeline_name(path)
        else:
            return None

    def load_pipeline_folder(self, pipeline_id: str):
        (pid, tag, path) = is_cross_project_pipeline(pipeline_id)
        if pid is not None:
            base_path = "{}/.prophecy/{}".format(self.base_path, pid)
            return Project(base_path, pid).load_pipeline_folder(path)
        else:
            return {}
