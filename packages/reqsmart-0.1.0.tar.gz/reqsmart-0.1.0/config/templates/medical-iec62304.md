# Medical Device Requirement Quality Gates

Extends the RQ baseline (IEEE 29148) with gates from IEC 62304, ISO 14971, and FDA guidance.

Applicable to: medical device software, SaMD (Software as a Medical Device), IVD software.

## Baseline Gates (IEEE 29148)

### RQ1: Unambiguous
- **Pass:** Single possible interpretation. No vague terms.
- **Fail:** Multiple interpretations possible.
- **Warn:** Minor ambiguity resolvable by domain context.

### RQ2: Verifiable
- **Pass:** Can be verified by test, analysis, inspection, or demonstration.
- **Fail:** No verification method identifiable.
- **Warn:** Verifiable but criteria implicit.

### RQ3: Singular
- **Pass:** One requirement per statement.
- **Fail:** Multiple concerns combined.
- **Warn:** Single concern but broad scope.

### RQ4: Appropriate
- **Pass:** Correct abstraction level. WHAT, not HOW.
- **Fail:** Contains implementation details.
- **Warn:** Boundary case.

### RQ5: Traceable
- **Pass:** Traces to source (user need, risk control, regulatory) and to verification.
- **Fail:** No trace path.
- **Warn:** Partial trace.

### RQ6: Complete
- **Pass:** All parameters specified. No TBDs.
- **Fail:** Contains TBD or missing values.
- **Warn:** References pending external document.

## Medical Device Domain Gates

### MQ1: Software Safety Classification
- **Pass:** Requirement is assigned a software safety class (A, B, or C per IEC 62304 §4.3) based on the severity of harm if the software fails. Classification is consistent with the parent system risk analysis.
- **Fail:** No safety class assigned. Or classification conflicts with the risk analysis.
- **Warn:** Class assigned but risk analysis reference not cited.
- **Reference:** IEC 62304 §4.3, §5.2.2; IEC 62304 Amendment 1 (2015)

### MQ2: Hazard Traceability
- **Pass:** If the requirement implements a risk control measure, it traces to: (1) the specific hazardous situation in the risk management file (ISO 14971), (2) the risk control measure description, and (3) verification of risk control effectiveness.
- **Fail:** Risk control requirement with no trace to hazard or no effectiveness verification.
- **Warn:** Traces to hazard but effectiveness verification not yet defined.
- **Reference:** ISO 14971 §7; IEC 62304 §7.3.3

### MQ3: Intended Use Boundary
- **Pass:** Requirement is consistent with the documented intended use and indications for use. Does not introduce functionality outside the intended use without regulatory impact assessment.
- **Fail:** Requirement describes functionality that contradicts or extends the intended use without flagging the regulatory implication.
- **Warn:** Requirement is within intended use but touches adjacent functionality (e.g., data export that could enable off-label analysis).
- **Reference:** FDA Guidance "General Principles of Software Validation" §4; IEC 62304 §5.2.1

### MQ4: SOUP/OTS Identification
- **Pass:** If the requirement will be fulfilled by Software of Unknown Provenance (SOUP) or off-the-shelf components, the SOUP item is identified, its anomaly list reviewed, and its failure modes assessed per the software safety class.
- **Fail:** Requirement depends on third-party/SOUP component but the component is not identified in the software architecture.
- **Warn:** SOUP identified but anomaly list review or failure mode assessment pending.
- **Reference:** IEC 62304 §5.3.3, §8.1.2
