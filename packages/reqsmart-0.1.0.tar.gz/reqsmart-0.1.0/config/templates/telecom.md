# Telecommunications Requirement Quality Gates

Extends the RQ baseline (IEEE 29148) with gates from TL9000, ITU-T, and RFC 2119.

Applicable to: optical networking, wireless infrastructure, transport systems, NFV/SDN.

## Baseline Gates (IEEE 29148)

### RQ1: Unambiguous
- **Pass:** Single possible interpretation. Clear subject, verb, object. No prohibited vague terms.
- **Fail:** Multiple valid interpretations possible. Uses vague terms without quantification.
- **Warn:** Minor ambiguity that telecom domain context resolves.

### RQ2: Verifiable
- **Pass:** Numeric thresholds, enumerable states, or observable criteria. A tester can write a pass/fail test.
- **Fail:** No verifiable criteria. Pure definitional statement.
- **Warn:** Verifiable but criteria are implicit.

### RQ3: Singular
- **Pass:** One concern per requirement. Independently implementable and testable.
- **Fail:** Multiple concerns combined with conjunctions.
- **Warn:** Single concern but overly broad scope.

### RQ4: Appropriate
- **Pass:** Specifies WHAT, not HOW. Correct abstraction level for the document.
- **Fail:** Contains implementation/design details.
- **Warn:** Boundary case between requirement and design.

### RQ5: Traceable
- **Pass:** Traceable to source (standard, stakeholder need) and to implementation + verification.
- **Fail:** No traceability path identifiable.
- **Warn:** Partial traceability.

### RQ6: Complete
- **Pass:** All parameters specified. No TBDs or placeholders.
- **Fail:** Contains TBD, TBC, or missing values.
- **Warn:** Values present but reference unavailable external documents.

## Telecom Domain Gates

### TQ1: Protocol Compliance
- **Pass:** When referencing a protocol or standard, specifies the version/edition (e.g., "per ITU-T G.698.2 (2018)", "OpenROADM MSA v5.1", "RFC 8040"). Identifies mandatory vs optional protocol features.
- **Fail:** References a protocol without version (e.g., "shall comply with NETCONF" — which version?). Assumes protocol features without citing source.
- **Warn:** Version cited but edition/amendment unclear.
- **Reference:** TL9000 §7.1; ITU-T Author's Guide §2.3

### TQ2: Keyword Compliance (RFC 2119)
- **Pass:** Uses RFC 2119 keywords correctly: "shall" (mandatory), "should" (recommended), "may" (optional). Obligation level matches the requirement's importance.
- **Fail:** Uses "shall" for optional features, or "should" for safety-critical requirements. Mixes obligation levels within one statement.
- **Warn:** Uses non-standard keywords ("must", "will", "needs to") where RFC 2119 keywords would be clearer.
- **Reference:** RFC 2119, RFC 8174; 3GPP TS 21.801 §2.1

### TQ3: Interface Completeness
- **Pass:** Interface requirements specify: protocol, transport, encoding, error handling, timeout, and expected behavior on failure. For data models, specifies leaves/containers/types.
- **Fail:** Specifies interface name only without behavioral details (e.g., "shall support SNMP" with no OID references, trap definitions, or access control).
- **Warn:** Core interface behavior specified but edge cases (timeout, error, overload) missing.
- **Reference:** TL9000 §7.1.2; IEEE 29148 §5.2.5(b)

### TQ4: Interoperability Reference
- **Pass:** When claiming interoperability, references specific test suite, conformance spec, or interop event (e.g., "OIF interop tested", "MEF CE 2.0 certified", "OpenROADM conformance test suite v5.1").
- **Fail:** Claims interoperability without reference to how it is verified.
- **Warn:** References a standard but not a specific conformance/test mechanism.
- **Reference:** TL9000 §7.3 (measurement of interoperability)
