# Aerospace Requirement Quality Gates

Extends the RQ baseline (IEEE 29148) with gates from DO-178C, DO-331, and ARP 4754A.

Applicable to: avionics software, airborne systems, unmanned aerial systems (UAS).

## Baseline Gates (IEEE 29148)

### RQ1: Unambiguous
- **Pass:** Single possible interpretation. No vague terms.
- **Fail:** Multiple interpretations possible.
- **Warn:** Minor ambiguity resolvable by domain context.

### RQ2: Verifiable
- **Pass:** Can be verified by test, analysis, inspection, or demonstration per DO-178C Table A-3.
- **Fail:** No verification method identifiable.
- **Warn:** Verifiable but method not explicitly stated.

### RQ3: Singular
- **Pass:** One requirement per statement. Independently verifiable.
- **Fail:** Multiple concerns combined.
- **Warn:** Single concern but broad scope.

### RQ4: Appropriate
- **Pass:** Correct abstraction for document level (system req vs HLR vs LLR). No implementation in HLRs.
- **Fail:** Wrong abstraction level or contains implementation details at HLR level.
- **Warn:** Boundary case.

### RQ5: Traceable
- **Pass:** Bidirectional trace: backward to system requirement or safety requirement, forward to design/code and verification case.
- **Fail:** No trace path.
- **Warn:** Partial trace (one direction only).

### RQ6: Complete
- **Pass:** All parameters specified. No TBDs.
- **Fail:** Contains TBD or missing values.
- **Warn:** References pending external document.

## Aerospace Domain Gates

### AQ1: Design Assurance Level (DAL) Allocated
- **Pass:** Requirement has an explicit DAL assignment (A, B, C, D, or E) consistent with the system-level failure condition classification. DAL is inherited from parent system requirement or assigned via Functional Hazard Assessment (FHA).
- **Fail:** No DAL assigned. Or DAL is inconsistent with the parent failure condition severity.
- **Warn:** DAL assigned but FHA reference not cited.
- **Reference:** DO-178C §2.3; ARP 4754A §5.2 (FDAL/IDAL allocation)

### AQ2: Derived Requirement Flagged
- **Pass:** If this requirement does not trace directly to a system-level requirement (it was derived during software design), it is explicitly marked as DERIVED and has been reviewed for safety impact per DO-178C §5.1.1.e.
- **Fail:** Requirement has no parent trace but is not flagged as derived.
- **Warn:** Flagged as derived but safety impact review status unknown.
- **Reference:** DO-178C §5.1.1(e), §MB.3(a); DO-331 §MB.3(a)

### AQ3: Safety Requirement Traceability
- **Pass:** Safety requirements (those addressing failure conditions of Catastrophic, Hazardous, or Major severity) trace to: (1) the specific failure condition in the FHA/PSSA/SSA, (2) at least one verification case that demonstrates mitigation, and (3) independence evidence if DAL A or B.
- **Fail:** Safety requirement lacks trace to failure condition or has no verification case allocated.
- **Warn:** Traces exist but independence evidence not yet documented.
- **Reference:** DO-178C Table A-3 objectives 1-3; ARP 4761 §4

### AQ4: Verification Method Specified
- **Pass:** Requirement specifies or is allocated a verification method: Test (T), Analysis (A), Inspection (I), or Demonstration (D). For DAL A/B, structural coverage criteria (MC/DC, decision, statement) are identified.
- **Fail:** No verification method assigned.
- **Warn:** Method assigned but coverage criteria not yet specified for DAL A/B.
- **Reference:** DO-178C §6.4, Table A-7
