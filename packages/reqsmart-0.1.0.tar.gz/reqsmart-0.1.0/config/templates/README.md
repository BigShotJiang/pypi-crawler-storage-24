# Domain Gate Templates

These templates extend the default RQ baseline (IEEE 29148) with domain-specific quality gates required by industry standards. Copy a template to your client config directory and customize.

```bash
# Example: set up for aerospace
mkdir -p ~/.smart-req/clients/myproject
cp config/templates/aerospace-do178c.md ~/.smart-req/clients/myproject/gates.md
# Edit gates.md to match your project's specific DAL levels, derived req policy, etc.
smart-req configure --client myproject
```

## Available Templates

| Template | Standards | Domain | Additional Gates |
|---|---|---|---|
| `telecom.md` | TL9000, ITU-T, RFC 2119 | Telecommunications | Protocol version, interop reference, keyword compliance |
| `aerospace-do178c.md` | DO-178C, ARP 4754A | Aerospace / avionics | DAL allocation, derived req flagging, safety traceability |
| `medical-iec62304.md` | IEC 62304, ISO 14971, FDA | Medical devices | Risk class, hazard traceability, intended use |
| `automotive-iso26262.md` | ISO 26262, ASPICE | Automotive | ASIL allocation, freedom from interference |

All templates include the 6 RQ baseline gates plus domain-specific additions.
