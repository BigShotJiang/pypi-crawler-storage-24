# Automotive Requirement Quality Gates

Extends the RQ baseline (IEEE 29148) with gates from ISO 26262 and Automotive SPICE (ASPICE).

Applicable to: automotive ECU software, ADAS, powertrain control, body electronics.

## Baseline Gates (IEEE 29148)

### RQ1: Unambiguous
- **Pass:** Single possible interpretation. No vague terms.
- **Fail:** Multiple interpretations possible.
- **Warn:** Minor ambiguity resolvable by domain context.

### RQ2: Verifiable
- **Pass:** Can be verified by test, analysis, inspection, or demonstration.
- **Fail:** No verification method identifiable.
- **Warn:** Verifiable but criteria implicit.

### RQ3: Singular
- **Pass:** One requirement per statement.
- **Fail:** Multiple concerns combined.
- **Warn:** Single concern but broad scope.

### RQ4: Appropriate
- **Pass:** Correct abstraction level. WHAT, not HOW.
- **Fail:** Contains implementation details.
- **Warn:** Boundary case.

### RQ5: Traceable
- **Pass:** Bidirectional trace: to source and to implementation + verification.
- **Fail:** No trace path.
- **Warn:** Partial trace.

### RQ6: Complete
- **Pass:** All parameters specified. No TBDs.
- **Fail:** Contains TBD or missing values.
- **Warn:** References pending external document.

## Automotive Domain Gates

### VQ1: ASIL Allocated
- **Pass:** Requirement has an explicit ASIL assignment (A, B, C, D, or QM) derived from the Hazard Analysis and Risk Assessment (HARA). ASIL is consistent with the parent safety goal.
- **Fail:** No ASIL assigned. Or ASIL is inconsistent with the parent safety goal decomposition.
- **Warn:** ASIL assigned but HARA reference not cited.
- **Reference:** ISO 26262-6 §7.4.1; ISO 26262-3 §7 (HARA)

### VQ2: Freedom from Interference
- **Pass:** If this requirement involves a software component that shares resources (CPU, memory, I/O) with components of different ASIL levels, the requirement specifies or references the freedom from interference mechanism (spatial isolation, temporal isolation, or equivalent).
- **Fail:** Mixed-ASIL resource sharing without interference mitigation specified.
- **Warn:** Interference mechanism referenced but not detailed at this requirement level.
- **Reference:** ISO 26262-6 §7.4.4; ISO 26262-9 §6 (ASIL decomposition)

### VQ3: Fault Handling Specified
- **Pass:** For safety-related requirements (ASIL A-D), the requirement specifies behavior under fault conditions: detection mechanism, safe state transition, fault tolerance time interval (FTTI), and degraded mode behavior.
- **Fail:** Safety-related requirement with no fault handling behavior specified.
- **Warn:** Fault detection specified but safe state or FTTI not yet defined.
- **Reference:** ISO 26262-6 §7.4.5; ISO 26262-4 §7.4.4.3 (FTTI)

### VQ4: Bidirectional Traceability (ASPICE)
- **Pass:** Requirement traces forward to: architectural element, detailed design, code unit, AND test case. Traces backward to: system requirement or safety goal. Consistency between forward and backward traces verified.
- **Fail:** Missing trace in any direction. Or forward and backward traces are inconsistent (e.g., traces to wrong parent).
- **Warn:** All traces exist but consistency verification not yet performed.
- **Reference:** ASPICE SWE.1 BP5, BP6; ISO 26262-6 §7.4.7
