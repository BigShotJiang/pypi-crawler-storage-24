# Client Configurations

This directory contains client-specific gate definitions, domain terms, and prompts.

To create a configuration for your organization:

1. Create a directory: `mkdir -p ~/.smart-req/clients/yourcompany`
2. Copy the default gates: `cp config/default/gates.md ~/.smart-req/clients/yourcompany/gates.md`
3. Edit the gates to match your quality methodology
4. Add domain terms: create `~/.smart-req/clients/yourcompany/domain_terms.md`
5. Score with your config: `smart-req score --client yourcompany`

See the README for details, or contact support@aisterna.com for onboarding support.
