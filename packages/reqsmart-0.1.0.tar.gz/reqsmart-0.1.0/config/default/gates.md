# Requirement Quality Baseline

Six universal gates derived from IEEE/ISO/IEC 29148:2018 — "Systems and software engineering — Life cycle processes — Requirements engineering."

References: IEEE 29148:2018 Clause 5.2.5 (Characteristics of individual requirements), INCOSE Guide for Writing Requirements v4.

## Quality Gates

### RQ1: Unambiguous
- **Pass:** Single possible interpretation. Clear subject, verb, object. No prohibited vague terms (see list below).
- **Fail:** Multiple valid interpretations possible. Uses vague terms like "appropriate", "sufficient", "as needed", "user-friendly", "fast", "robust".
- **Warn:** Minor ambiguity that domain context resolves.
- **Reference:** IEEE 29148 §5.2.5(c) — "each requirement shall be stated so there is only one way to interpret it"

### RQ2: Verifiable
- **Pass:** Can be proven true or false through test, analysis, inspection, or demonstration. Contains numeric thresholds, enumerable states, or observable acceptance criteria.
- **Fail:** No verifiable criteria. Pure definitional statement. A tester cannot determine pass/fail.
- **Warn:** Verifiable but criteria are implicit rather than explicit.
- **Reference:** IEEE 29148 §5.2.5(l) — "a requirement is verifiable if a finite, cost-effective process can check that the product meets the requirement"

### RQ3: Singular
- **Pass:** Single concern per requirement. One "shall" statement. Can be independently implemented and independently verified.
- **Fail:** Multiple concerns combined. Contains "and" joining unrelated behaviors. Would require splitting for independent verification.
- **Warn:** Single concern but overly broad scope.
- **Reference:** IEEE 29148 §5.2.5(i) — "the requirement statement includes only one requirement with no use of conjunctions"

### RQ4: Appropriate
- **Pass:** Correct level of abstraction for the document. Specifies WHAT (behavior, capability, constraint), not HOW (design, implementation). Serves a stakeholder need, safety requirement, or regulatory mandate.
- **Fail:** Contains design/implementation details. Out of scope for the document's abstraction level.
- **Warn:** Necessary but may be better expressed as a design decision rather than a requirement.
- **Reference:** IEEE 29148 §5.2.5(a) — "a requirement that has a clear, relevant purpose and is stated at an appropriate level"

### RQ5: Traceable
- **Pass:** Can be traced backward to its source (stakeholder need, parent requirement, regulation) AND forward to at least one implementation artifact and one verification artifact.
- **Fail:** Cannot identify any source, implementation path, or verification path.
- **Warn:** Forward trace exists but backward trace (source) or verification path is unclear.
- **Reference:** IEEE 29148 §5.2.5(k) — "a requirement is traceable if the origin of the requirement can be determined and it can be referenced in future development"

### RQ6: Complete
- **Pass:** All parameters, values, and conditions are specified. No TBDs, TBCs, placeholders, or "to be determined" markers.
- **Fail:** Contains TBD, TBC, "[placeholder]", missing values, or unresolved references.
- **Warn:** All values present but some reference external documents not yet available.
- **Reference:** IEEE 29148 §5.2.5(b) — "the requirement sufficiently describes a capability, characteristic, or quality factor such that further elaboration is not necessary"

## Prohibited Phrases

The following phrases indicate ambiguity (RQ1 violation). If these terms have precise meaning in your domain, add them to your client's `domain_terms.md` to suppress false positives.

- "appropriate", "appropriately"
- "sufficient", "sufficiently"
- "reasonable", "reasonably"
- "adequate", "adequately"
- "as needed", "as required", "as necessary"
- "etc.", "and so on", "and similar"
- "user-friendly", "easy to use"
- "fast", "quick", "slow" (without numeric threshold)
- "robust", "reliable" (without measurable criteria)
- "minimize", "maximize", "optimize" (without target)
- "support" (without specifying what support means)
- "handle", "manage" (without specifying behavior)
- "properly", "correctly" (without defining correct behavior)
