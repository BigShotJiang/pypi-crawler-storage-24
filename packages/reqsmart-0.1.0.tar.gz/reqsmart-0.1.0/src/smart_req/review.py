"""Skill: /req-review — HITL review UI for scored requirements."""

import json
import logging
import webbrowser
from datetime import datetime
from pathlib import Path
from typing import Optional

from .models import (
    Manifest, ReviewDecision, Decision, OverallStatus,
    GateStatus, ScoredRequirement,
)

logger = logging.getLogger(__name__)


def load_manifest(manifest_path: Path) -> Manifest:
    """Load manifest from JSON file."""
    with open(manifest_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return Manifest.model_validate(data)


def save_manifest(manifest: Manifest, manifest_path: Path):
    """Save manifest to JSON file."""
    with open(manifest_path, 'w', encoding='utf-8') as f:
        json.dump(manifest.model_dump(mode='json'), f, indent=2, default=str)


def get_review_items(manifest: Manifest) -> list[ScoredRequirement]:
    """Get items needing review (REVIEW + FAIL, excluding already decided)."""
    items = []
    for sr in manifest.requirements:
        if sr.overall in (OverallStatus.REVIEW, OverallStatus.FAIL):
            if sr.requirement.req_id not in manifest.decisions:
                items.append(sr)
    return items


def _gate_icon(status: GateStatus) -> str:
    if status == GateStatus.PASS:
        return "PASS"
    elif status == GateStatus.WARN:
        return "WARN"
    else:
        return "FAIL"


def _build_html(manifest: Manifest, manifest_path: Path) -> str:
    """Build the full review HTML page."""
    review_items = []
    decided_items = []

    for sr in manifest.requirements:
        if sr.overall in (OverallStatus.REVIEW, OverallStatus.FAIL):
            if sr.requirement.req_id in manifest.decisions:
                decided_items.append((sr, manifest.decisions[sr.requirement.req_id]))
            else:
                review_items.append(sr)

    stats = manifest.stats
    total_to_review = len(review_items) + len(decided_items)
    done_count = len(decided_items)

    cards_html = ""
    for i, sr in enumerate(review_items):
        req = sr.requirement
        gates_html = ""
        for gr in sr.gate_results:
            color = "#22c55e" if gr.status == GateStatus.PASS else "#eab308" if gr.status == GateStatus.WARN else "#ef4444"
            gates_html += f'<span style="color:{color};font-weight:600;margin-right:12px">{gr.gate_id} {_gate_icon(gr.status)}</span>'

        findings_html = ""
        for gr in sr.gate_results:
            if gr.status != GateStatus.PASS:
                color = "#eab308" if gr.status == GateStatus.WARN else "#ef4444"
                findings_html += f'<div style="margin:4px 0;color:{color}"><strong>{gr.gate_id} {gr.gate_name}:</strong> {gr.finding}</div>'

        fix_html = ""
        if sr.suggested_fix:
            fix_html = f'''
            <div style="background:#1a2332;padding:12px;border-radius:6px;margin-top:8px">
                <div style="font-weight:600;margin-bottom:4px">SUGGESTED FIX</div>
                <textarea id="fix-{req.req_id}" rows="3" style="width:100%;background:#0d1117;color:#e6edf3;border:1px solid #30363d;border-radius:4px;padding:8px;font-family:inherit;resize:vertical">{sr.suggested_fix}</textarea>
                {f'<div style="color:#8b949e;margin-top:4px;font-size:0.85em">Rationale: {sr.fix_rationale}</div>' if sr.fix_rationale else ''}
            </div>'''

        status_color = "#ef4444" if sr.overall == OverallStatus.FAIL else "#eab308"
        status_label = sr.overall.value

        cards_html += f'''
        <div id="card-{req.req_id}" class="card" style="background:#161b22;border:1px solid #30363d;border-radius:8px;padding:16px;margin-bottom:12px">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
                <span style="font-weight:700;font-size:1.1em">{req.req_id}</span>
                <span style="background:{status_color};color:white;padding:2px 8px;border-radius:4px;font-size:0.85em">{status_label}</span>
            </div>
            <div style="margin-bottom:8px">
                <div style="color:#8b949e;font-size:0.85em">Section {req.section} | {req.title}</div>
            </div>
            <div style="background:#0d1117;padding:10px;border-radius:6px;margin-bottom:8px;border-left:3px solid #30363d">
                {req.text}
            </div>
            <div style="margin-bottom:8px">{gates_html}</div>
            {findings_html}
            {fix_html}
            <div style="margin-top:12px;display:flex;gap:8px;align-items:center">
                <button onclick="decide('{req.req_id}','accepted')" style="background:#238636;color:white;border:none;padding:6px 16px;border-radius:6px;cursor:pointer;font-weight:600">Accept</button>
                <button onclick="showModify('{req.req_id}')" style="background:#1f6feb;color:white;border:none;padding:6px 16px;border-radius:6px;cursor:pointer;font-weight:600">Modify</button>
                <button onclick="showReject('{req.req_id}')" style="background:#da3633;color:white;border:none;padding:6px 16px;border-radius:6px;cursor:pointer;font-weight:600">Reject</button>
            </div>
            <div id="modify-area-{req.req_id}" style="display:none;margin-top:8px">
                <textarea id="modify-{req.req_id}" rows="4" style="width:100%;background:#0d1117;color:#e6edf3;border:1px solid #1f6feb;border-radius:4px;padding:8px;font-family:inherit;resize:vertical">{sr.suggested_fix or req.text}</textarea>
                <div style="margin-top:6px;display:flex;gap:8px">
                    <button onclick="decide('{req.req_id}','modified')" style="background:#1f6feb;color:white;border:none;padding:6px 16px;border-radius:6px;cursor:pointer;font-weight:600">Submit Modified Text</button>
                    <button onclick="hideModify('{req.req_id}')" style="background:#30363d;color:#e6edf3;border:none;padding:6px 12px;border-radius:6px;cursor:pointer">Cancel</button>
                </div>
            </div>
            <div id="reject-area-{req.req_id}" style="display:none;margin-top:8px;display:none;flex-direction:row;gap:8px;align-items:center">
                <input id="reject-{req.req_id}" type="text" placeholder="Justification for rejection..." style="flex:1;background:#0d1117;color:#e6edf3;border:1px solid #da3633;border-radius:4px;padding:6px 8px">
                <button onclick="decide('{req.req_id}','rejected')" style="background:#da3633;color:white;border:none;padding:6px 12px;border-radius:6px;cursor:pointer;font-weight:600">Confirm Reject</button>
                <button onclick="hideReject('{req.req_id}')" style="background:#30363d;color:#e6edf3;border:none;padding:6px 12px;border-radius:6px;cursor:pointer">Cancel</button>
            </div>
        </div>'''

    # Decided items summary
    decided_html = ""
    if decided_items:
        decided_html = '<div style="margin-top:20px"><h3>Reviewed</h3>'
        for sr, dec in decided_items:
            color = "#238636" if dec.decision == Decision.ACCEPTED else "#1f6feb" if dec.decision == Decision.MODIFIED else "#da3633"
            decided_html += f'<div style="padding:4px 0;color:#8b949e"><span style="color:{color};font-weight:600">{dec.decision.value.upper()}</span> {sr.requirement.req_id} — {sr.requirement.title}</div>'
        decided_html += '</div>'

    return f'''<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>smart-req Review</title>
    <style>
        body {{ background:#0d1117; color:#e6edf3; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; max-width:900px; margin:0 auto; padding:20px; }}
        h1 {{ border-bottom:1px solid #30363d; padding-bottom:8px; }}
        .stats {{ display:flex; gap:20px; margin-bottom:20px; }}
        .stat {{ background:#161b22; padding:12px 20px; border-radius:8px; text-align:center; }}
        .stat-value {{ font-size:1.5em; font-weight:700; }}
        .stat-label {{ color:#8b949e; font-size:0.85em; }}
        button:hover {{ opacity:0.9; }}
        kbd {{ background:#161b22; padding:2px 6px; border:1px solid #30363d; border-radius:3px; font-size:0.85em; }}
    </style>
</head>
<body>
    <h1>smart-req Review</h1>
    <div style="color:#8b949e;margin-bottom:16px">
        {manifest.input_document} | {manifest.gate_config} | {manifest.llm_model}
    </div>
    <div class="stats">
        <div class="stat"><div class="stat-value" style="color:#22c55e">{stats['pass']}</div><div class="stat-label">PASS</div></div>
        <div class="stat"><div class="stat-value" style="color:#eab308">{stats['review']}</div><div class="stat-label">REVIEW</div></div>
        <div class="stat"><div class="stat-value" style="color:#ef4444">{stats['fail']}</div><div class="stat-label">FAIL</div></div>
        <div class="stat"><div class="stat-value">{done_count}/{total_to_review}</div><div class="stat-label">DECIDED</div></div>
    </div>
    <div style="margin-bottom:12px;color:#8b949e">
        Shortcuts: <kbd>A</kbd> Accept | <kbd>M</kbd> Modify | <kbd>R</kbd> Reject | <kbd>N</kbd> Next | <kbd>P</kbd> Previous
    </div>
    <div id="cards">
        {cards_html}
    </div>
    {decided_html}
    <div id="done-msg" style="display:{'none' if review_items else 'block'};text-align:center;padding:40px">
        <div style="color:#22c55e;font-size:1.2em;margin-bottom:8px">All items reviewed.</div>
        <div style="color:#8b949e">Exporting final spreadsheet and closing server...</div>
    </div>

    <script>
    const manifestPath = {json.dumps(str(manifest_path))};

    function showModify(reqId) {{
        document.getElementById('modify-area-' + reqId).style.display = 'block';
        document.getElementById('reject-area-' + reqId).style.display = 'none';
        document.getElementById('modify-' + reqId).focus();
    }}

    function hideModify(reqId) {{
        document.getElementById('modify-area-' + reqId).style.display = 'none';
    }}

    function showReject(reqId) {{
        document.getElementById('reject-area-' + reqId).style.display = 'flex';
        document.getElementById('modify-area-' + reqId).style.display = 'none';
        document.getElementById('reject-' + reqId).focus();
    }}

    function hideReject(reqId) {{
        document.getElementById('reject-area-' + reqId).style.display = 'none';
    }}

    function decide(reqId, decision) {{
        let modifiedText = null;
        let justification = null;

        if (decision === 'modified') {{
            const textarea = document.getElementById('modify-' + reqId);
            if (textarea) {{
                modifiedText = textarea.value;
            }}
        }}
        if (decision === 'rejected') {{
            const input = document.getElementById('reject-' + reqId);
            if (input) {{
                justification = input.value || 'No justification provided';
            }}
        }}

        fetch('/api/decide', {{
            method: 'POST',
            headers: {{'Content-Type': 'application/json'}},
            body: JSON.stringify({{
                req_id: reqId,
                decision: decision,
                modified_text: modifiedText,
                justification: justification,
            }})
        }}).then(r => r.json()).then(data => {{
            const card = document.getElementById('card-' + reqId);
            if (card) {{
                card.style.opacity = '0.3';
                card.style.pointerEvents = 'none';
            }}
            if (data.remaining === 0) {{
                document.getElementById('done-msg').style.display = 'block';
                // Auto-export and shutdown
                setTimeout(() => {{
                    fetch('/api/finish', {{ method: 'POST' }})
                        .then(r => r.json())
                        .then(result => {{
                            if (result.status === 'exported') {{
                                document.getElementById('done-msg').innerHTML =
                                    '<div style="color:#22c55e;font-size:1.3em;margin-bottom:12px">Review complete.</div>' +
                                    '<div style="color:#e6edf3;margin-bottom:8px">Exported: <code>' + result.output + '</code></div>' +
                                    '<div style="color:#8b949e;margin-top:16px">You can close this tab now.</div>';
                            }}
                        }})
                        .catch(() => {{
                            document.getElementById('done-msg').innerHTML =
                                '<div style="color:#22c55e;font-size:1.3em">Review complete. You can close this tab.</div>';
                        }});
                }}, 500);
            }}
        }});
    }}

    // Keyboard shortcuts
    let currentCard = 0;
    document.addEventListener('keydown', function(e) {{
        const cards = document.querySelectorAll('.card:not([style*="opacity: 0.3"])');
        if (cards.length === 0) return;

        if (e.key === 'n' || e.key === 'N') {{ currentCard = Math.min(currentCard + 1, cards.length - 1); cards[currentCard].scrollIntoView({{behavior:'smooth'}}); }}
        if (e.key === 'p' || e.key === 'P') {{ currentCard = Math.max(currentCard - 1, 0); cards[currentCard].scrollIntoView({{behavior:'smooth'}}); }}
    }});
    </script>
</body>
</html>'''


def start_review_server(manifest_path: Path, port: int = 8321):
    """Start the HITL review server."""
    try:
        from fastapi import FastAPI
        from fastapi.responses import HTMLResponse, JSONResponse
        import uvicorn
    except ImportError:
        raise ImportError("fastapi and uvicorn required: pip install fastapi uvicorn")

    manifest_path = Path(manifest_path)
    manifest = load_manifest(manifest_path)

    app = FastAPI(title="smart-req Review")

    @app.get("/", response_class=HTMLResponse)
    async def index():
        # Reload manifest each time to reflect latest decisions
        m = load_manifest(manifest_path)
        return _build_html(m, manifest_path)

    @app.post("/api/decide")
    async def decide(payload: dict):
        m = load_manifest(manifest_path)
        req_id = payload["req_id"]
        decision = Decision(payload["decision"])

        m.decisions[req_id] = ReviewDecision(
            req_id=req_id,
            decision=decision,
            modified_text=payload.get("modified_text"),
            justification=payload.get("justification"),
            reviewer="engineer",
            timestamp=datetime.now(),
        )

        save_manifest(m, manifest_path)

        remaining = sum(
            1 for sr in m.requirements
            if sr.overall in (OverallStatus.REVIEW, OverallStatus.FAIL)
            and sr.requirement.req_id not in m.decisions
        )

        return JSONResponse({"status": "ok", "remaining": remaining})

    _server_ref = {"server": None}

    @app.post("/api/finish")
    async def finish():
        """Auto-export and shutdown when all reviews are done."""
        import asyncio

        m = load_manifest(manifest_path)

        # Run export
        from .export import export_xlsx
        try:
            output_path = export_xlsx(
                manifest_path=manifest_path,
                output_path=None,
            )
            result = {"status": "exported", "output": str(output_path.resolve())}
        except SystemExit:
            result = {"status": "export_failed", "reason": "pending reviews remain"}
            return JSONResponse(result)

        # Schedule graceful server shutdown
        async def _shutdown():
            await asyncio.sleep(2)
            if _server_ref["server"]:
                _server_ref["server"].should_exit = True

        asyncio.create_task(_shutdown())
        return JSONResponse(result)

    from rich.console import Console
    console = Console()
    console.print(f"[bold]Starting review server on http://localhost:{port}[/bold]")
    console.print(f"  Manifest: {manifest_path.resolve()}")

    stats = manifest.stats
    to_review = stats["review"] + stats["fail"] - stats["decided"]
    console.print(f"  Items to review: {to_review}")
    console.print()
    console.print("[dim]Server will auto-close when all reviews are complete.[/dim]")
    console.print("[dim]Or press Ctrl+C to stop manually.[/dim]")

    webbrowser.open(f"http://localhost:{port}")

    config = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning")
    server = uvicorn.Server(config)
    _server_ref["server"] = server
    server.run()
