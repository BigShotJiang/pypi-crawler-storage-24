"""Core data models for smart-req pipeline."""

from datetime import datetime
from enum import Enum
from typing import Optional, List, Dict
from pydantic import BaseModel, Field


class GateStatus(str, Enum):
    PASS = "Pass"
    WARN = "Warn"
    FAIL = "Fail"


class OverallStatus(str, Enum):
    PASS = "PASS"
    REVIEW = "REVIEW"
    FAIL = "FAIL"


class Decision(str, Enum):
    PENDING = "pending"
    ACCEPTED = "accepted"
    MODIFIED = "modified"
    REJECTED = "rejected"
    AUTO_PASS = "auto_pass"


class Requirement(BaseModel):
    """Extracted requirement from specification document."""
    req_id: str = Field(description="Deterministic requirement ID")
    section: str = Field(description="Document section number")
    title: str = Field(description="Short requirement title")
    text: str = Field(description="Full requirement text")
    category: Optional[str] = Field(default=None, description="Auto-classified category")
    source_page: Optional[int] = Field(default=None, description="PDF page number")
    extraction_confidence: Optional[float] = Field(default=None, description="LLM confidence 0-1")

    def __hash__(self):
        return hash(self.req_id.lower())

    def __eq__(self, other):
        if not isinstance(other, Requirement):
            return False
        return self.req_id.lower() == other.req_id.lower()


class GateDefinition(BaseModel):
    """Parsed gate definition from gates.md."""
    id: str = Field(description="Gate identifier (e.g., G1, S, M)")
    name: str = Field(description="Gate name (e.g., Atomic, Measurable)")
    pass_criteria: str = Field(description="What constitutes a pass")
    fail_criteria: str = Field(description="What constitutes a fail")
    warn_criteria: str = Field(default="", description="What constitutes a warning")


class GateResult(BaseModel):
    """Per-gate scoring result."""
    gate_id: str
    gate_name: str
    status: GateStatus
    finding: str = Field(description="Specific evidence for this score")


class ScoredRequirement(BaseModel):
    """A requirement with gate scoring results."""
    requirement: Requirement
    gate_results: List[GateResult] = Field(default_factory=list)
    overall: OverallStatus = OverallStatus.PASS
    suggested_fix: Optional[str] = Field(default=None)
    fix_rationale: Optional[str] = Field(default=None)


class ReviewDecision(BaseModel):
    """HITL decision on a scored requirement."""
    req_id: str
    decision: Decision = Decision.PENDING
    modified_text: Optional[str] = Field(default=None)
    justification: Optional[str] = Field(default=None)
    reviewer: Optional[str] = Field(default=None)
    timestamp: Optional[datetime] = Field(default=None)


class Manifest(BaseModel):
    """Full pipeline state — persisted as manifest.json."""
    tool_version: str = "0.1.0"
    source_pdf: str = ""  # Original PDF filename (carried through pipeline)
    input_document: str = ""  # CSV input to score step
    input_hash: str = ""
    gate_config: str = ""
    gate_config_hash: str = ""
    llm_model: str = ""
    timestamp: datetime = Field(default_factory=datetime.now)

    # Pipeline outputs
    requirements: List[ScoredRequirement] = Field(default_factory=list)
    decisions: Dict[str, ReviewDecision] = Field(default_factory=dict)

    # Statistics (computed)
    @property
    def stats(self) -> dict:
        total = len(self.requirements)
        pass_count = sum(1 for r in self.requirements if r.overall == OverallStatus.PASS)
        review_count = sum(1 for r in self.requirements if r.overall == OverallStatus.REVIEW)
        fail_count = sum(1 for r in self.requirements if r.overall == OverallStatus.FAIL)
        decided = sum(1 for d in self.decisions.values() if d.decision != Decision.PENDING)
        pending = sum(
            1 for r in self.requirements
            if r.overall in (OverallStatus.REVIEW, OverallStatus.FAIL)
            and r.requirement.req_id not in self.decisions
        )
        return {
            "total": total,
            "pass": pass_count,
            "review": review_count,
            "fail": fail_count,
            "decided": decided,
            "pending_review": pending,
        }
