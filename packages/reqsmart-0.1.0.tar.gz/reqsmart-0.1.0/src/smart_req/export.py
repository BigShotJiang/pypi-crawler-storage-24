"""Skill: /req-export — Export gate-clean XLSX with audit trail."""

import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Optional

from rich.console import Console

from .models import (
    Manifest, OverallStatus, Decision, GateStatus,
)

logger = logging.getLogger(__name__)
console = Console()


def load_manifest(manifest_path: Path) -> Manifest:
    with open(manifest_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    return Manifest.model_validate(data)


def check_review_complete(manifest: Manifest) -> list[str]:
    """Check if all REVIEW/FAIL items have been decided. Returns list of pending req_ids."""
    pending = []
    for sr in manifest.requirements:
        if sr.overall in (OverallStatus.REVIEW, OverallStatus.FAIL):
            if sr.requirement.req_id not in manifest.decisions:
                pending.append(sr.requirement.req_id)
    return pending


def export_xlsx(
    manifest_path: Path,
    output_path: Optional[Path] = None,
) -> Path:
    """Export finalized requirements to XLSX with audit trail.

    Returns path to output XLSX.
    """
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    except ImportError:
        raise ImportError("openpyxl required: pip install openpyxl")

    manifest_path = Path(manifest_path)
    manifest = load_manifest(manifest_path)

    # Check completeness
    pending = check_review_complete(manifest)
    if pending:
        console.print(f"[bold red]Cannot export: {len(pending)} items still pending review[/bold red]")
        for req_id in pending[:10]:
            console.print(f"  - {req_id}")
        if len(pending) > 10:
            console.print(f"  ... and {len(pending) - 10} more")
        console.print()
        console.print("[dim]Run 'smart-req review' to complete the review.[/dim]")
        raise SystemExit(1)

    # Determine output path — prefer source PDF name over CSV name
    if output_path is None:
        if manifest.source_pdf:
            stem = Path(manifest.source_pdf).stem
        elif manifest.input_document:
            stem = Path(manifest.input_document).stem
        else:
            stem = "requirements"
        output_path = Path(f"{stem}_Final.xlsx")
    output_path = Path(output_path)

    # Styles
    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="1F2937", end_color="1F2937", fill_type="solid")
    pass_fill = PatternFill(start_color="D1FAE5", end_color="D1FAE5", fill_type="solid")
    reviewed_fill = PatternFill(start_color="FEF3C7", end_color="FEF3C7", fill_type="solid")
    override_fill = PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid")
    thin_border = Border(
        left=Side(style='thin'), right=Side(style='thin'),
        top=Side(style='thin'), bottom=Side(style='thin'),
    )
    wrap = Alignment(wrap_text=True, vertical='top')

    wb = Workbook()

    # --- Sheet 1: Final Requirements ---
    ws = wb.active
    ws.title = "Requirements"

    headers = [
        "ReqID", "Section", "Requirement Text", "SMART Score",
        "Gate Details", "Decision", "Justification", "Source Page",
    ]
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.border = thin_border
        cell.alignment = Alignment(wrap_text=True, vertical='top', horizontal='center')

    # Column widths
    ws.column_dimensions['A'].width = 15
    ws.column_dimensions['B'].width = 10
    ws.column_dimensions['C'].width = 60
    ws.column_dimensions['D'].width = 14
    ws.column_dimensions['E'].width = 35
    ws.column_dimensions['F'].width = 12
    ws.column_dimensions['G'].width = 30
    ws.column_dimensions['H'].width = 10

    row = 2
    for sr in manifest.requirements:
        req = sr.requirement
        decision_info = manifest.decisions.get(req.req_id)

        # Determine final text and score label
        if sr.overall == OverallStatus.PASS:
            final_text = req.text
            score_label = "PASS"
            decision_label = "auto_pass"
            justification = ""
            row_fill = pass_fill
        elif decision_info:
            if decision_info.decision == Decision.ACCEPTED:
                final_text = sr.suggested_fix or req.text
                score_label = "PASS-REVIEWED"
                decision_label = "accepted"
                justification = ""
                row_fill = reviewed_fill
            elif decision_info.decision == Decision.MODIFIED:
                final_text = decision_info.modified_text or req.text
                score_label = "PASS-REVIEWED"
                decision_label = "modified"
                justification = ""
                row_fill = reviewed_fill
            elif decision_info.decision == Decision.REJECTED:
                final_text = req.text
                score_label = "OVERRIDE"
                decision_label = "rejected"
                justification = decision_info.justification or ""
                row_fill = override_fill
            else:
                final_text = req.text
                score_label = sr.overall.value
                decision_label = "pending"
                justification = ""
                row_fill = None
        else:
            final_text = req.text
            score_label = sr.overall.value
            decision_label = "pending"
            justification = ""
            row_fill = None

        # Gate details string
        gate_details = " ".join(
            f"{gr.gate_id}:{gr.status.value}" for gr in sr.gate_results
        )

        values = [
            req.req_id, req.section, final_text, score_label,
            gate_details, decision_label, justification, req.source_page or "",
        ]

        for col, value in enumerate(values, 1):
            cell = ws.cell(row=row, column=col, value=value)
            cell.border = thin_border
            cell.alignment = wrap
            if row_fill:
                cell.fill = row_fill

        row += 1

    # --- Sheet 2: Audit Trail ---
    ws2 = wb.create_sheet("Audit Trail")
    audit_headers = ["ReqID", "Original Text", "Final Text", "Decision", "Reviewer", "Timestamp", "Justification"]
    for col, header in enumerate(audit_headers, 1):
        cell = ws2.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.border = thin_border

    ws2.column_dimensions['A'].width = 15
    ws2.column_dimensions['B'].width = 50
    ws2.column_dimensions['C'].width = 50
    ws2.column_dimensions['D'].width = 12
    ws2.column_dimensions['E'].width = 15
    ws2.column_dimensions['F'].width = 20
    ws2.column_dimensions['G'].width = 30

    row = 2
    for sr in manifest.requirements:
        req = sr.requirement
        dec = manifest.decisions.get(req.req_id)
        if not dec or dec.decision == Decision.AUTO_PASS:
            continue

        if dec.decision == Decision.ACCEPTED:
            final = sr.suggested_fix or req.text
        elif dec.decision == Decision.MODIFIED:
            final = dec.modified_text or req.text
        else:
            final = req.text

        values = [
            req.req_id, req.text, final, dec.decision.value,
            dec.reviewer or "", str(dec.timestamp or ""), dec.justification or "",
        ]
        for col, value in enumerate(values, 1):
            cell = ws2.cell(row=row, column=col, value=value)
            cell.border = thin_border
            cell.alignment = wrap
        row += 1

    # Save
    output_path.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output_path)

    # Also save audit trail JSON
    audit_json_path = output_path.with_suffix('.audit.json')
    audit_data = {
        "tool": "smart-req",
        "version": manifest.tool_version,
        "timestamp": datetime.now().isoformat(),
        "input_document": manifest.input_document,
        "input_hash": manifest.input_hash,
        "gate_config": manifest.gate_config,
        "llm_model": manifest.llm_model,
        "statistics": manifest.stats,
        "decisions": [
            d.model_dump(mode='json') for d in manifest.decisions.values()
        ],
    }
    with open(audit_json_path, 'w', encoding='utf-8') as f:
        json.dump(audit_data, f, indent=2, default=str)

    # Summary
    stats = manifest.stats
    decided = manifest.decisions
    accepted = sum(1 for d in decided.values() if d.decision == Decision.ACCEPTED)
    modified = sum(1 for d in decided.values() if d.decision == Decision.MODIFIED)
    rejected = sum(1 for d in decided.values() if d.decision == Decision.REJECTED)

    console.print(f"[bold green]Export complete[/bold green]")
    console.print(f"  {stats['pass']} PASS (untouched)")
    if accepted:
        console.print(f"  {accepted} accepted (suggested fix applied)")
    if modified:
        console.print(f"  {modified} modified (engineer's text)")
    if rejected:
        console.print(f"  {rejected} rejected (original kept with justification)")
    console.print()
    console.print(f"  XLSX:  {output_path.resolve()}")
    console.print(f"  Audit: {audit_json_path.resolve()}")

    return output_path
