"""Full web UI for smart-req — upload PDF, extract, score, review, export."""

import asyncio
import json
import logging
import shutil
import tempfile
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


def create_app(default_client: Optional[str] = None, api_key: Optional[str] = None):
    """Create the FastAPI web application."""
    from fastapi import FastAPI, UploadFile, File, Form, Request
    from fastapi.responses import HTMLResponse, JSONResponse, FileResponse, StreamingResponse

    app = FastAPI(title="smart-req")

    # Session storage: session_id -> {work_dir, state, ...}
    sessions: dict[str, dict] = {}

    def get_session(session_id: str) -> dict:
        return sessions.get(session_id, {})

    # --- Shared HTML components ---

    def _page(title: str, content: str, session_id: str = "", step: int = 0) -> str:
        steps = [
            ("Upload", "/"),
            ("Extract", "#"),
            ("Score", "#"),
            ("Review", "#"),
            ("Export", "#"),
        ]
        step_html = ""
        for i, (label, _) in enumerate(steps):
            if i < step:
                color = "#22c55e"
                icon = "&#10003;"
            elif i == step:
                color = "#58a6ff"
                icon = str(i + 1)
            else:
                color = "#484f58"
                icon = str(i + 1)
            step_html += f'''
            <div style="display:flex;align-items:center;gap:6px">
                <div style="width:28px;height:28px;border-radius:50%;background:{color};
                     display:flex;align-items:center;justify-content:center;font-weight:700;
                     font-size:0.85em;color:white">{icon}</div>
                <span style="color:{color};font-weight:{'700' if i == step else '400'}">{label}</span>
            </div>'''
            if i < len(steps) - 1:
                step_html += f'<div style="width:40px;height:2px;background:{color if i < step else "#30363d"}"></div>'

        return f'''<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>smart-req — {title}</title>
    <style>
        body {{ background:#0d1117; color:#e6edf3; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; margin:0; padding:0; }}
        .container {{ max-width:900px; margin:0 auto; padding:20px; }}
        h1 {{ font-size:1.5em; margin-bottom:4px; }}
        .subtitle {{ color:#8b949e; margin-bottom:24px; }}
        .steps {{ display:flex; align-items:center; gap:4px; margin-bottom:32px; padding:16px; background:#161b22; border-radius:8px; justify-content:center; }}
        .card {{ background:#161b22; border:1px solid #30363d; border-radius:8px; padding:20px; margin-bottom:16px; }}
        button, .btn {{ background:#238636; color:white; border:none; padding:10px 24px; border-radius:6px; cursor:pointer; font-weight:600; font-size:1em; text-decoration:none; display:inline-block; }}
        button:hover, .btn:hover {{ background:#2ea043; }}
        .btn-blue {{ background:#1f6feb; }}
        .btn-blue:hover {{ background:#388bfd; }}
        input[type="file"] {{ display:none; }}
        .upload-area {{ border:2px dashed #30363d; border-radius:8px; padding:40px; text-align:center; cursor:pointer; transition:border-color 0.2s; }}
        .upload-area:hover {{ border-color:#58a6ff; }}
        .upload-area.dragover {{ border-color:#58a6ff; background:#161b22; }}
        select {{ background:#0d1117; color:#e6edf3; border:1px solid #30363d; border-radius:4px; padding:8px 12px; font-size:1em; }}
        .progress-bar {{ width:100%; height:8px; background:#21262d; border-radius:4px; overflow:hidden; margin:12px 0; }}
        .progress-fill {{ height:100%; background:#58a6ff; border-radius:4px; transition:width 0.3s; }}
        .stat {{ display:inline-block; padding:8px 16px; border-radius:6px; margin:4px; text-align:center; }}
        .stat-pass {{ background:#0d2818; color:#22c55e; }}
        .stat-review {{ background:#2d2000; color:#eab308; }}
        .stat-fail {{ background:#2d0000; color:#ef4444; }}
        table {{ width:100%; border-collapse:collapse; }}
        th {{ background:#1f2937; color:white; padding:8px 12px; text-align:left; font-size:0.85em; }}
        td {{ padding:8px 12px; border-bottom:1px solid #21262d; vertical-align:top; }}
        tr:hover {{ background:#161b22; }}
        .gate-pass {{ color:#22c55e; }}
        .gate-warn {{ color:#eab308; }}
        .gate-fail {{ color:#ef4444; }}
        textarea {{ width:100%; background:#0d1117; color:#e6edf3; border:1px solid #30363d; border-radius:4px; padding:8px; font-family:inherit; resize:vertical; box-sizing:border-box; }}
    </style>
</head>
<body>
    <div class="container">
        <h1>smart-req</h1>
        <div class="subtitle">Requirement Qualification Tool</div>
        <div class="steps">{step_html}</div>
        {content}
    </div>
</body>
</html>'''

    # --- Page 1: Upload ---

    @app.get("/", response_class=HTMLResponse)
    async def upload_page():
        # Check for active sessions — offer resume if one is in progress
        active = [(sid, s) for sid, s in sessions.items()
                  if s.get("state") in ("extracting", "scoring", "uploaded", "parsing")]
        done = [(sid, s) for sid, s in sessions.items()
                if s.get("state") == "done"]
        reviewed = [(sid, s) for sid, s in sessions.items()
                    if s.get("state") == "done" and s.get("final_xlsx")]

        resume_html = ""
        if active:
            sid, s = active[-1]  # Most recent active session
            resume_html = f'''
            <div class="card" style="border:1px solid #58a6ff;margin-bottom:16px">
                <div style="display:flex;justify-content:space-between;align-items:center">
                    <div>
                        <div style="color:#58a6ff;font-weight:600">Processing in progress</div>
                        <div style="color:#8b949e;font-size:0.9em">{s.get("pdf_name", "Unknown")} — {s.get("state", "")}</div>
                    </div>
                    <a href="/processing/{sid}" class="btn btn-blue" style="text-decoration:none">Resume</a>
                </div>
            </div>'''
        elif done:
            sid, s = done[-1]
            resume_html = f'''
            <div class="card" style="border:1px solid #22c55e;margin-bottom:16px">
                <div style="display:flex;justify-content:space-between;align-items:center">
                    <div>
                        <div style="color:#22c55e;font-weight:600">Ready for review</div>
                        <div style="color:#8b949e;font-size:0.9em">{s.get("pdf_name", "Unknown")}</div>
                    </div>
                    <a href="/review/{sid}" class="btn" style="text-decoration:none">Continue Review</a>
                </div>
            </div>'''

        # List available gate configs
        from .config import PACKAGE_TEMPLATES_DIR, USER_CONFIG_DIR
        configs = [("", "Default (IEEE 29148 Baseline — 6 gates)")]

        # Package templates
        templates_dir = PACKAGE_TEMPLATES_DIR
        if templates_dir.exists():
            for f in sorted(templates_dir.glob("*.md")):
                if f.name != "README.md":
                    name = f.stem
                    configs.append((f"template:{name}", f"Template: {name}"))

        # User clients
        clients_dir = USER_CONFIG_DIR / "clients"
        if clients_dir.exists():
            for d in sorted(clients_dir.iterdir()):
                if d.is_dir() and (d / "gates.md").exists():
                    configs.append((d.name, f"Client: {d.name}"))

        # Default client
        from .config import get_default_client
        default = get_default_client() or ""

        options_html = ""
        for value, label in configs:
            selected = "selected" if value == default else ""
            options_html += f'<option value="{value}" {selected}>{label}</option>\n'

        content = f'''
        {resume_html}
        <div class="card">
            <form id="upload-form" action="/upload" method="post" enctype="multipart/form-data">
                <div class="upload-area" id="drop-area" onclick="document.getElementById('file-input').click()">
                    <div style="font-size:2em;margin-bottom:8px">&#128196;</div>
                    <div style="font-size:1.1em;margin-bottom:4px" id="file-label">Drop your specification PDF here or click to browse</div>
                    <div style="color:#8b949e;font-size:0.85em">Supports any text-based PDF</div>
                    <input type="file" id="file-input" name="file" accept=".pdf" onchange="fileSelected(this)">
                </div>

                <div style="margin-top:20px;display:flex;gap:16px;align-items:end">
                    <div style="flex:1">
                        <label style="color:#8b949e;font-size:0.85em;display:block;margin-bottom:4px">Quality Gates</label>
                        <select name="gates" style="width:100%">
                            {options_html}
                        </select>
                    </div>
                    <div>
                        <label style="color:#8b949e;font-size:0.85em;display:block;margin-bottom:4px">Sections (optional)</label>
                        <input type="text" name="sections" placeholder="e.g., 3.5,3.22"
                               style="background:#0d1117;color:#e6edf3;border:1px solid #30363d;border-radius:4px;padding:8px 12px;width:150px">
                    </div>
                    <button type="submit" id="start-btn" disabled style="opacity:0.5">Start</button>
                </div>
            </form>
        </div>

        <script>
        const dropArea = document.getElementById('drop-area');
        const fileInput = document.getElementById('file-input');
        const startBtn = document.getElementById('start-btn');
        const fileLabel = document.getElementById('file-label');

        function fileSelected(input) {{
            if (input.files.length > 0) {{
                fileLabel.textContent = input.files[0].name;
                startBtn.disabled = false;
                startBtn.style.opacity = '1';
                dropArea.style.borderColor = '#22c55e';
            }}
        }}

        ['dragenter','dragover'].forEach(e => dropArea.addEventListener(e, ev => {{
            ev.preventDefault(); dropArea.classList.add('dragover');
        }}));
        ['dragleave','drop'].forEach(e => dropArea.addEventListener(e, ev => {{
            ev.preventDefault(); dropArea.classList.remove('dragover');
        }}));
        dropArea.addEventListener('drop', ev => {{
            fileInput.files = ev.dataTransfer.files;
            fileSelected(fileInput);
        }});
        </script>
        '''
        return _page("Upload", content, step=0)

    # --- Upload + Start Processing ---

    @app.post("/upload", response_class=HTMLResponse)
    async def upload_file(file: UploadFile = File(...), gates: str = Form(""), sections: str = Form("")):
        # Create session
        session_id = str(uuid.uuid4())[:8]
        work_dir = Path(tempfile.mkdtemp(prefix=f"smart-req-{session_id}-"))

        # Save uploaded PDF
        pdf_path = work_dir / file.filename
        with open(pdf_path, "wb") as f:
            content = await file.read()
            f.write(content)

        sessions[session_id] = {
            "work_dir": str(work_dir),
            "pdf_name": file.filename,
            "pdf_path": str(pdf_path),
            "gates": gates,
            "sections": sections,
            "state": "uploaded",
            "extract_progress": 0,
            "extract_total": 0,
            "extract_found": 0,
            "score_progress": 0,
            "score_total": 0,
            "error": None,
        }

        # Redirect to processing page
        return _processing_page(session_id)

    def _processing_page(session_id: str) -> str:
        session = sessions[session_id]
        content = f'''
        <style>
            @keyframes pulse {{
                0%, 100% {{ opacity: 1; }}
                50% {{ opacity: 0.4; }}
            }}
            @keyframes shimmer {{
                0% {{ background-position: -200% 0; }}
                100% {{ background-position: 200% 0; }}
            }}
            .pulse {{ animation: pulse 2s ease-in-out infinite; }}
            .shimmer-bar {{
                background: linear-gradient(90deg, #58a6ff 25%, #388bfd 50%, #58a6ff 75%);
                background-size: 200% 100%;
                animation: shimmer 1.5s ease-in-out infinite;
            }}
            .elapsed {{ color:#484f58; font-size:0.8em; }}
        </style>

        <div class="card">
            <div style="text-align:center">
                <div style="font-size:1.1em;margin-bottom:8px" id="status-text">
                    <span class="pulse">Preparing document...</span>
                </div>
                <div style="color:#8b949e" id="status-detail">{session["pdf_name"]}</div>
                <div class="progress-bar">
                    <div class="progress-fill shimmer-bar" id="progress" style="width:5%"></div>
                </div>
                <div style="color:#8b949e;font-size:0.85em" id="progress-text">
                    Parsing PDF and chunking text...
                </div>
                <div class="elapsed" id="elapsed"></div>
                <div style="margin-top:16px">
                    <button onclick="cancelProcessing()" style="background:#da3633;padding:6px 20px;font-size:0.9em">Cancel</button>
                </div>
            </div>
        </div>

        <div class="card" style="margin-top:16px;color:#8b949e;font-size:0.9em">
            <div style="margin-bottom:8px"><strong style="color:#e6edf3">What's happening:</strong></div>
            <div id="step-extract" style="margin-bottom:6px;display:flex;align-items:baseline;gap:8px">
                <span id="icon-extract" class="pulse">&#9711;</span>
                <span>Extracting requirements from PDF</span>
                <span id="est-extract" style="color:#484f58;font-size:0.85em"></span>
            </div>
            <div id="step-score" style="margin-bottom:6px;opacity:0.4;display:flex;align-items:baseline;gap:8px">
                <span id="icon-score">&#9711;</span>
                <span>Scoring each requirement against quality gates</span>
                <span id="est-score" style="color:#484f58;font-size:0.85em"></span>
            </div>
            <div id="step-review" style="opacity:0.4;display:flex;align-items:baseline;gap:8px">
                <span id="icon-review">&#9711;</span>
                <span>Preparing review page</span>
                <span style="color:#484f58;font-size:0.85em">(&lt;1s)</span>
            </div>
        </div>

        <script>
        const sessionId = "{session_id}";
        const startTime = Date.now();

        // Start processing (only if not already started)
        fetch('/api/process/' + sessionId, {{method: 'POST'}});

        // Warn before leaving the page during processing
        let navigationAllowed = false;
        window.addEventListener('beforeunload', function(e) {{
            if (navigationAllowed) return;
            e.preventDefault();
            e.returnValue = 'Processing is in progress. If you leave, extraction will continue in the background but you may lose track of results.';
        }});

        function cancelProcessing() {{
            if (confirm('Cancel extraction? You can start over from the upload page.')) {{
                navigationAllowed = true;
                fetch('/api/cancel/' + sessionId, {{method: 'POST'}});
                clearInterval(poll);
                window.location.href = '/';
            }}
        }}

        // Elapsed timer
        setInterval(() => {{
            const secs = Math.floor((Date.now() - startTime) / 1000);
            const mins = Math.floor(secs / 60);
            const s = secs % 60;
            document.getElementById('elapsed').textContent =
                mins > 0 ? mins + 'm ' + s + 's elapsed' : s + 's elapsed';
        }}, 1000);

        // Poll for progress
        const poll = setInterval(async () => {{
            const r = await fetch('/api/status/' + sessionId);
            const data = await r.json();

            const statusText = document.getElementById('status-text');
            const progress = document.getElementById('progress');
            const progressText = document.getElementById('progress-text');

            // Time estimation helpers
            // ~8s per chunk for extraction, ~10s per requirement for scoring
            const SEC_PER_CHUNK = 8;
            const SEC_PER_REQ = 10;

            function fmtEst(seconds) {{
                if (seconds < 60) return '~' + seconds + 's';
                const m = Math.floor(seconds / 60);
                const s = seconds % 60;
                return s > 0 ? '~' + m + 'm ' + s + 's' : '~' + m + 'm';
            }}

            function fmtRemaining(total, done, secPer) {{
                const remaining = Math.max(0, (total - done) * secPer);
                if (remaining === 0) return '';
                return fmtEst(remaining) + ' remaining';
            }}

            if (data.state === 'uploaded') {{
                statusText.innerHTML = '<span class="pulse">Starting...</span>';
                progressText.textContent = 'Initializing extraction pipeline...';

            }} else if (data.state === 'parsing') {{
                statusText.innerHTML = '<span class="pulse">Parsing PDF...</span>';
                progressText.textContent = 'Reading ' + (data.pdf_pages > 0 ? data.pdf_pages + ' pages' : 'pages') + ' and splitting into chunks...';
                document.getElementById('est-extract').textContent = '(parsing PDF...)';

            }} else if (data.state === 'extracting') {{
                progress.classList.remove('shimmer-bar');
                statusText.innerHTML = 'Extracting requirements...';

                const pct = data.extract_total > 0
                    ? Math.max(5, (data.extract_progress / data.extract_total * 50))
                    : 5;
                progress.style.width = pct + '%';

                if (data.extract_total > 0) {{
                    const remaining = fmtRemaining(data.extract_total, data.extract_progress, SEC_PER_CHUNK);
                    const totalEst = fmtEst(data.extract_total * SEC_PER_CHUNK);

                    if (data.extract_progress === 0) {{
                        // Chunks known but first LLM call hasn't returned yet
                        progressText.textContent = data.extract_total + ' chunks to process — first result in ~' + SEC_PER_CHUNK + 's...';
                        document.getElementById('est-extract').textContent = '(' + totalEst + ' total)';
                    }} else {{
                        progressText.textContent = 'Chunk ' + data.extract_progress + '/' + data.extract_total +
                            ' — ' + data.extract_found + ' requirements found' +
                            (remaining ? ' — ' + remaining : '');
                        document.getElementById('est-extract').textContent =
                            '(' + (remaining || 'finishing...') + ')';
                    }}

                    // Estimate scoring based on found requirements so far
                    if (data.extract_found > 0) {{
                        const scoreEst = data.extract_found * SEC_PER_REQ;
                        document.getElementById('est-score').textContent = '(' + fmtEst(scoreEst) + ' estimated)';
                    }} else {{
                        // Rough estimate: ~5 reqs per chunk
                        const estReqs = data.extract_total * 5;
                        document.getElementById('est-score').textContent = '(' + fmtEst(estReqs * SEC_PER_REQ) + ' estimated)';
                    }}
                }}

                document.getElementById('step-extract').style.opacity = '1';
                document.getElementById('icon-extract').innerHTML = '&#9881;';
                document.getElementById('icon-extract').classList.add('pulse');

            }} else if (data.state === 'scoring') {{
                progress.classList.remove('shimmer-bar');
                statusText.innerHTML = '<span class="pulse" style="color:#58a6ff">Scoring against quality gates...</span>';

                const pct = 50 + (data.score_total > 0
                    ? (data.score_progress / data.score_total * 45)
                    : 0);
                progress.style.width = pct + '%';

                const remaining = fmtRemaining(data.score_total, data.score_progress, SEC_PER_REQ);
                progressText.textContent = data.score_progress + '/' + data.score_total +
                    ' requirements scored' + (remaining ? ' — ' + remaining : '');

                // Update step indicators — extract done
                document.getElementById('est-extract').textContent = '(done)';
                document.getElementById('step-extract').style.opacity = '0.6';
                document.getElementById('icon-extract').innerHTML = '&#10003;';
                document.getElementById('icon-extract').classList.remove('pulse');
                document.getElementById('icon-extract').style.color = '#22c55e';

                // Score step active — pulse
                const scoreRemaining = fmtRemaining(data.score_total, data.score_progress, SEC_PER_REQ);
                document.getElementById('est-score').textContent = '(' + (scoreRemaining || 'finishing...') + ')';
                document.getElementById('step-score').style.opacity = '1';
                document.getElementById('step-score').style.color = '#58a6ff';
                document.getElementById('icon-score').innerHTML = '&#9881;';
                document.getElementById('icon-score').style.animation = 'pulse 2s ease-in-out infinite';

            }} else if (data.state === 'done') {{
                clearInterval(poll);
                navigationAllowed = true;
                progress.style.width = '100%';
                progress.style.background = '#22c55e';

                // Show scoring as done
                document.getElementById('est-extract').textContent = '(done)';
                document.getElementById('step-extract').style.opacity = '0.6';
                document.getElementById('icon-extract').innerHTML = '&#10003;';
                document.getElementById('icon-extract').classList.remove('pulse');
                document.getElementById('icon-extract').style.color = '#22c55e';

                document.getElementById('est-score').textContent = '(done)';
                document.getElementById('step-score').style.opacity = '0.6';
                document.getElementById('icon-score').innerHTML = '&#10003;';
                document.getElementById('icon-score').classList.remove('pulse');
                document.getElementById('icon-score').style.color = '#22c55e';

                document.getElementById('step-review').style.opacity = '1';
                document.getElementById('icon-review').innerHTML = '&#9881;';
                document.getElementById('icon-review').classList.add('pulse');
                document.getElementById('icon-review').style.color = '#58a6ff';

                const reviewUrl = '/review/' + sessionId;
                statusText.innerHTML = '<span style="color:#22c55e">Done!</span> Redirecting to review...';
                progressText.innerHTML = '<a href="' + reviewUrl + '" style="color:#58a6ff;text-decoration:underline">' +
                    'Click here if not redirected automatically</a>';

                // Redirect after a brief pause to let UI update render
                setTimeout(() => {{
                    window.location.replace(reviewUrl);
                }}, 500);

            }} else if (data.state === 'error') {{
                clearInterval(poll);
                progress.style.background = '#ef4444';
                statusText.innerHTML = '<span style="color:#ef4444">Error</span>';
                progressText.textContent = data.error;
            }}
        }}, 1000);
        </script>
        '''
        return _page("Processing", content, session_id=session_id, step=1)

    @app.get("/processing/{session_id}", response_class=HTMLResponse)
    async def processing_page(session_id: str):
        """Resume viewing the processing progress page."""
        session = get_session(session_id)
        if not session:
            return _page("Error", '<div class="card">Session not found. <a href="/" class="btn" style="margin-left:12px">Start Over</a></div>', step=1)
        if session.get("state") == "done":
            from fastapi.responses import RedirectResponse
            return RedirectResponse(f"/review/{session_id}")
        return _processing_page(session_id)

    @app.post("/api/cancel/{session_id}")
    async def cancel_processing(session_id: str):
        session = sessions.get(session_id)
        if session:
            session["cancelled"] = True
            session["state"] = "cancelled"
            # Clean up work dir
            work_dir = session.get("work_dir")
            if work_dir and Path(work_dir).exists():
                shutil.rmtree(work_dir, ignore_errors=True)
        return JSONResponse({"status": "cancelled"})

    @app.get("/api/status/{session_id}")
    async def get_status(session_id: str):
        session = get_session(session_id)
        if not session:
            return JSONResponse({"state": "error", "error": "Session not found"})
        # Return only JSON-safe fields
        safe_fields = {
            "state": session.get("state", "uploaded"),
            "pdf_name": session.get("pdf_name", ""),
            "extract_progress": session.get("extract_progress", 0),
            "extract_total": session.get("extract_total", 0),
            "extract_found": session.get("extract_found", 0),
            "score_progress": session.get("score_progress", 0),
            "score_total": session.get("score_total", 0),
            "pdf_pages": session.get("pdf_pages", 0),
            "error": session.get("error"),
        }
        return JSONResponse(safe_fields)

    @app.post("/api/process/{session_id}")
    async def start_processing(session_id: str):
        """Run extract + score in background."""
        session = sessions.get(session_id)
        if not session:
            return JSONResponse({"error": "Session not found"})

        # Prevent duplicate runs on page refresh
        if session.get("processing_started"):
            return JSONResponse({"status": "already_running"})
        session["processing_started"] = True

        def _run():
            work_dir = Path(session["work_dir"])
            pdf_path = Path(session["pdf_path"])
            csv_path = work_dir / "raw_extract.csv"
            gates_config = session["gates"]
            sections_str = session["sections"]

            from .config import get_api_key as _get_api_key
            key = api_key or _get_api_key()

            # Resolve client from gates selection
            client = None
            if gates_config.startswith("template:"):
                # Copy template to temp client dir
                template_name = gates_config.split(":", 1)[1]
                from .config import PACKAGE_TEMPLATES_DIR, USER_CONFIG_DIR
                template_path = PACKAGE_TEMPLATES_DIR / f"{template_name}.md"
                temp_client = f"_session_{session_id}"
                temp_client_dir = USER_CONFIG_DIR / "clients" / temp_client
                temp_client_dir.mkdir(parents=True, exist_ok=True)
                shutil.copy(template_path, temp_client_dir / "gates.md")
                client = temp_client
            elif gates_config:
                client = gates_config

            if not client and default_client:
                client = default_client

            # --- Extract ---
            try:
                session["state"] = "parsing"
                from .pdf import PDFProcessor
                from .extract import extract_from_chunk, deduplicate, EXTRACTION_PROMPT
                from .llm import LLMClient
                from .config import load_prompt

                llm = LLMClient(api_key=key)
                processor = PDFProcessor()
                custom_prompt = load_prompt(client, "extract")

                chunks, pdf_info = processor.process_pdf(pdf_path)

                if sections_str:
                    section_list = [s.strip() for s in sections_str.split(",")]
                    chunks = processor.filter_sections(chunks, section_list)

                session["extract_total"] = len(chunks)
                session["pdf_pages"] = pdf_info.get("page_count", 0)
                session["state"] = "extracting"
                all_reqs = []

                for chunk in chunks:
                    if session.get("cancelled"):
                        return
                    reqs = extract_from_chunk(llm, chunk, custom_prompt)
                    all_reqs.extend(reqs)
                    session["extract_progress"] += 1
                    session["extract_found"] = len(all_reqs)

                all_reqs, _ = deduplicate(all_reqs)

                # Save CSV
                import csv
                with open(csv_path, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.DictWriter(f, fieldnames=['ReqID', 'Section', 'Title', 'Text', 'Category', 'SourcePage'])
                    writer.writeheader()
                    for req in all_reqs:
                        writer.writerow({
                            'ReqID': req.req_id, 'Section': req.section, 'Title': req.title,
                            'Text': req.text, 'Category': req.category or '', 'SourcePage': req.source_page or '',
                        })

                # Save meta
                with open(csv_path.with_suffix('.meta.json'), 'w') as f:
                    json.dump({"source_pdf": pdf_path.name}, f)

            except Exception as e:
                session["state"] = "error"
                session["error"] = str(e)
                return

            # --- Score ---
            try:
                session["state"] = "scoring"
                from .score import score_single, load_requirements_from_csv, _save_manifest_xlsx
                from .config import load_gates, load_domain_terms, compute_file_hash, gates_config_name
                from .models import Manifest, ScoredRequirement, OverallStatus

                requirements = load_requirements_from_csv(csv_path)
                gates = load_gates(client)
                domain_terms = load_domain_terms(client)

                session["score_total"] = len(requirements)
                scored = []

                for req in requirements:
                    if session.get("cancelled"):
                        return
                    try:
                        result = score_single(llm, req, gates, domain_terms)
                        scored.append(result)
                    except Exception as e:
                        scored.append(ScoredRequirement(requirement=req, overall=OverallStatus.REVIEW))
                    session["score_progress"] += 1

                manifest = Manifest(
                    source_pdf=pdf_path.name,
                    input_document=csv_path.name,
                    input_hash=compute_file_hash(csv_path),
                    gate_config=gates_config_name(client),
                    llm_model=llm.model,
                    requirements=scored,
                )

                manifest_path = work_dir / "manifest.json"
                with open(manifest_path, 'w', encoding='utf-8') as f:
                    json.dump(manifest.model_dump(mode='json'), f, indent=2, default=str)

                _save_manifest_xlsx(manifest, gates, work_dir / "manifest.xlsx")

                session["state"] = "done"

            except Exception as e:
                session["state"] = "error"
                session["error"] = str(e)

        asyncio.create_task(asyncio.to_thread(_run))
        return JSONResponse({"status": "started"})

    # --- Page 3: Review ---

    @app.get("/review/{session_id}", response_class=HTMLResponse)
    async def review_page(session_id: str):
        session = get_session(session_id)
        if not session:
            return _page("Error", '<div class="card">Session not found.</div>', step=3)

        work_dir = Path(session["work_dir"])
        manifest_path = work_dir / "manifest.json"

        from .review import load_manifest
        from .models import OverallStatus, GateStatus, Decision

        manifest = load_manifest(manifest_path)
        stats = manifest.stats

        # Build review table rows
        rows_html = ""
        for sr in manifest.requirements:
            req = sr.requirement
            if sr.overall == OverallStatus.PASS:
                continue

            # Check if already decided
            dec = manifest.decisions.get(req.req_id)
            if dec and dec.decision != Decision.PENDING:
                continue

            gates_html = ""
            findings_html = ""
            for gr in sr.gate_results:
                css = "gate-pass" if gr.status == GateStatus.PASS else "gate-warn" if gr.status == GateStatus.WARN else "gate-fail"
                gates_html += f'<span class="{css}" style="margin-right:8px">{gr.gate_id}</span>'
                if gr.status != GateStatus.PASS:
                    findings_html += f'<div class="{css}" style="font-size:0.85em;margin-top:2px"><strong>{gr.gate_id}:</strong> {gr.finding}</div>'

            status_css = "stat-fail" if sr.overall == OverallStatus.FAIL else "stat-review"
            fix_escaped = (sr.suggested_fix or req.text).replace('"', '&quot;').replace("'", "&#39;")

            req_text_js = req.text.replace("\\", "\\\\").replace("'", "\\'").replace('"', '\\"').replace("\n", " ")

            rows_html += f'''
            <tr id="row-{req.req_id}">
                <td style="white-space:nowrap;font-weight:600">{req.req_id}</td>
                <td>{req.text}</td>
                <td>{gates_html}{findings_html}</td>
                <td style="font-size:0.85em">{sr.suggested_fix or ""}</td>
                <td>
                    <select id="dec-{req.req_id}" style="margin-bottom:4px;width:100%"
                            onchange="toggleModify('{req.req_id}', this.value)">
                        <option value="">—</option>
                        <option value="accepted">Accept</option>
                        <option value="modified">Modify</option>
                        <option value="rejected">Reject</option>
                    </select>
                    <textarea id="mod-{req.req_id}" rows="2" style="display:none;margin-top:4px;font-size:0.85em"
                              placeholder="Enter modified text or rejection reason...">{fix_escaped}</textarea>
                </td>
                <td>
                    <button style="background:#30363d;padding:4px 10px;font-size:0.8em"
                            onclick="openChat('{req.req_id}', '{req_text_js}', '')">Ask</button>
                </td>
            </tr>'''

        decided_count = sum(1 for d in manifest.decisions.values() if d.decision != Decision.PENDING)
        to_review = stats["review"] + stats["fail"] - decided_count

        # Also show PASS requirements in a collapsed section
        pass_rows = ""
        for sr in manifest.requirements:
            if sr.overall == OverallStatus.PASS:
                req = sr.requirement
                pass_rows += f'<tr><td style="font-weight:600">{req.req_id}</td><td>{req.text}</td><td style="color:#22c55e">All gates passed</td></tr>'

        content = f'''
        <div style="display:flex;gap:12px;margin-bottom:20px;flex-wrap:wrap">
            <div class="stat stat-pass">{stats["pass"]} PASS</div>
            <div class="stat stat-review">{stats["review"]} REVIEW</div>
            <div class="stat stat-fail">{stats["fail"]} FAIL</div>
            <div class="stat" style="background:#161b22;color:#8b949e">{to_review} to review</div>
        </div>

        <div class="card" style="overflow-x:auto">
            <table>
                <thead>
                    <tr>
                        <th style="width:8%">ReqID</th>
                        <th style="width:22%">Requirement</th>
                        <th style="width:22%">Gate Results</th>
                        <th style="width:18%">Suggested Fix</th>
                        <th style="width:18%">Decision</th>
                        <th style="width:12%"></th>
                    </tr>
                </thead>
                <tbody>
                    {rows_html}
                </tbody>
            </table>
        </div>

        <!-- Action buttons -->
        <div style="margin-top:16px;display:flex;gap:12px;justify-content:space-between;flex-wrap:wrap">
            <button style="background:#30363d" onclick="toggleAddForm()">+ Add Requirement</button>
            <div style="display:flex;gap:12px">
                <button class="btn-blue" onclick="acceptAll()">Accept All Suggestions</button>
                <button onclick="submitDecisions()">Submit Decisions</button>
            </div>
        </div>

        <!-- Add Requirement Form (hidden by default) -->
        <div id="add-form" class="card" style="display:none;margin-top:16px">
            <div style="font-weight:700;margin-bottom:12px">Add a Missing Requirement</div>
            <div style="display:flex;gap:12px;margin-bottom:8px">
                <div style="flex:0 0 120px">
                    <label style="color:#8b949e;font-size:0.85em">ReqID</label>
                    <input type="text" id="add-reqid" placeholder="e.g., 3.5.1-99"
                           style="width:100%;background:#0d1117;color:#e6edf3;border:1px solid #30363d;border-radius:4px;padding:6px 8px;box-sizing:border-box">
                </div>
                <div style="flex:0 0 100px">
                    <label style="color:#8b949e;font-size:0.85em">Section</label>
                    <input type="text" id="add-section" placeholder="e.g., 3.5.1"
                           style="width:100%;background:#0d1117;color:#e6edf3;border:1px solid #30363d;border-radius:4px;padding:6px 8px;box-sizing:border-box">
                </div>
                <div style="flex:1">
                    <label style="color:#8b949e;font-size:0.85em">Title</label>
                    <input type="text" id="add-title" placeholder="Short title"
                           style="width:100%;background:#0d1117;color:#e6edf3;border:1px solid #30363d;border-radius:4px;padding:6px 8px;box-sizing:border-box">
                </div>
            </div>
            <div style="margin-bottom:8px">
                <label style="color:#8b949e;font-size:0.85em">Requirement Text</label>
                <textarea id="add-text" rows="3" placeholder="The system shall..."
                          style="width:100%;box-sizing:border-box"></textarea>
            </div>
            <div style="display:flex;gap:8px">
                <button onclick="addRequirement()">Score & Add</button>
                <button style="background:#30363d" onclick="toggleAddForm()">Cancel</button>
            </div>
            <div id="add-status" style="margin-top:8px;color:#8b949e;display:none"></div>
        </div>

        <!-- Chat Panel (shown when Ask is clicked on a requirement) -->
        <div id="chat-panel" class="card" style="display:none;margin-top:16px;position:relative">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
                <div style="font-weight:700">Ask about: <span id="chat-req-id" style="color:#58a6ff"></span></div>
                <button onclick="closeChat()" style="background:#30363d;padding:4px 12px;font-size:0.85em">Close</button>
            </div>
            <div id="chat-messages" style="max-height:300px;overflow-y:auto;margin-bottom:12px;padding:8px;background:#0d1117;border-radius:6px">
                <div style="color:#8b949e;font-style:italic">Ask a question about this requirement...</div>
            </div>
            <div style="display:flex;gap:8px">
                <input type="text" id="chat-input" placeholder="e.g., How should I split this? Is this testable?"
                       style="flex:1;background:#0d1117;color:#e6edf3;border:1px solid #30363d;border-radius:4px;padding:8px"
                       onkeydown="if(event.key==='Enter')sendChat()">
                <button class="btn-blue" onclick="sendChat()">Ask</button>
            </div>
        </div>

        {f"""<!-- PASS requirements (collapsed) -->
        <details style="margin-top:20px">
            <summary style="cursor:pointer;color:#8b949e;padding:8px">Show {stats["pass"]} passed requirements</summary>
            <div class="card" style="margin-top:8px;overflow-x:auto">
                <table><thead><tr><th>ReqID</th><th>Requirement</th><th>Status</th></tr></thead>
                <tbody>{pass_rows}</tbody></table>
            </div>
        </details>""" if pass_rows else ""}

        <script>
        const sessionId = "{session_id}";
        let chatReqId = null;

        function toggleModify(reqId, value) {{
            const textarea = document.getElementById('mod-' + reqId);
            if (value === 'modified' || value === 'rejected') {{
                textarea.style.display = 'block';
                textarea.placeholder = value === 'rejected' ? 'Reason for rejection...' : 'Enter your modified text...';
            }} else {{
                textarea.style.display = 'none';
            }}
        }}

        function acceptAll() {{
            document.querySelectorAll('select[id^="dec-"]').forEach(sel => {{
                if (sel.value === '') sel.value = 'accepted';
            }});
        }}

        // --- Add Requirement ---
        function toggleAddForm() {{
            const form = document.getElementById('add-form');
            form.style.display = form.style.display === 'none' ? 'block' : 'none';
        }}

        async function addRequirement() {{
            const reqId = document.getElementById('add-reqid').value.trim();
            const section = document.getElementById('add-section').value.trim();
            const title = document.getElementById('add-title').value.trim();
            const text = document.getElementById('add-text').value.trim();

            if (!reqId || !text) {{
                alert('ReqID and Requirement Text are required.');
                return;
            }}

            const status = document.getElementById('add-status');
            status.style.display = 'block';
            status.textContent = 'Scoring against quality gates...';
            status.style.color = '#58a6ff';

            const r = await fetch('/api/add-requirement/' + sessionId, {{
                method: 'POST',
                headers: {{'Content-Type': 'application/json'}},
                body: JSON.stringify({{ req_id: reqId, section: section, title: title, text: text }}),
            }});
            const data = await r.json();

            if (data.status === 'ok') {{
                status.textContent = 'Added and scored: ' + data.overall;
                status.style.color = '#22c55e';
                setTimeout(() => window.location.reload(), 1000);
            }} else {{
                status.textContent = 'Error: ' + (data.error || 'Unknown');
                status.style.color = '#ef4444';
            }}
        }}

        // --- Chat / Q&A ---
        function openChat(reqId, reqText, gateResults) {{
            chatReqId = reqId;
            document.getElementById('chat-req-id').textContent = reqId;
            document.getElementById('chat-messages').innerHTML =
                '<div style="color:#8b949e;font-style:italic">Ask a question about this requirement...</div>' +
                '<div style="margin-top:8px;padding:8px;background:#161b22;border-radius:4px;font-size:0.9em">' +
                '<strong>Requirement:</strong> ' + reqText + '</div>';
            document.getElementById('chat-panel').style.display = 'block';
            document.getElementById('chat-input').focus();
            document.getElementById('chat-panel').scrollIntoView({{behavior:'smooth'}});
        }}

        function closeChat() {{
            document.getElementById('chat-panel').style.display = 'none';
            chatReqId = null;
        }}

        async function sendChat() {{
            const input = document.getElementById('chat-input');
            const question = input.value.trim();
            if (!question || !chatReqId) return;

            const messages = document.getElementById('chat-messages');
            messages.innerHTML += '<div style="margin-top:8px;color:#e6edf3"><strong>You:</strong> ' + question + '</div>';
            input.value = '';

            // Show thinking indicator
            const thinkingId = 'thinking-' + Date.now();
            messages.innerHTML += '<div id="' + thinkingId + '" style="margin-top:8px;color:#8b949e;font-style:italic">Thinking...</div>';
            messages.scrollTop = messages.scrollHeight;

            const r = await fetch('/api/chat/' + sessionId, {{
                method: 'POST',
                headers: {{'Content-Type': 'application/json'}},
                body: JSON.stringify({{ req_id: chatReqId, question: question }}),
            }});
            const data = await r.json();

            // Replace thinking with answer
            const thinking = document.getElementById(thinkingId);
            if (thinking) {{
                thinking.outerHTML = '<div style="margin-top:8px;padding:8px;background:#161b22;border-radius:4px">' +
                    '<strong style="color:#58a6ff">smart-req:</strong> ' + data.answer + '</div>';
            }}
            messages.scrollTop = messages.scrollHeight;
        }}

        async function submitDecisions() {{
            const decisions = [];
            document.querySelectorAll('select[id^="dec-"]').forEach(sel => {{
                const reqId = sel.id.replace('dec-', '');
                const value = sel.value;
                if (!value) return;
                const textarea = document.getElementById('mod-' + reqId);
                decisions.push({{
                    req_id: reqId,
                    decision: value,
                    modified_text: value === 'modified' ? textarea.value : null,
                    justification: value === 'rejected' ? textarea.value : null,
                }});
            }});

            if (decisions.length === 0) {{
                alert('Please make at least one decision before submitting.');
                return;
            }}

            const r = await fetch('/api/decisions/' + sessionId, {{
                method: 'POST',
                headers: {{'Content-Type': 'application/json'}},
                body: JSON.stringify(decisions),
            }});
            const data = await r.json();

            if (data.remaining === 0) {{
                window.location.href = '/export/' + sessionId;
            }} else {{
                window.location.href = '/review/' + sessionId;
            }}
        }}
        </script>
        '''
        return _page("Review", content, session_id=session_id, step=3)

    @app.post("/api/decisions/{session_id}")
    async def submit_decisions(session_id: str, request: Request):
        session = get_session(session_id)
        if not session:
            return JSONResponse({"error": "Session not found"})

        work_dir = Path(session["work_dir"])
        manifest_path = work_dir / "manifest.json"

        from .review import load_manifest, save_manifest
        from .models import ReviewDecision, Decision, OverallStatus

        manifest = load_manifest(manifest_path)
        decisions = await request.json()

        for dec in decisions:
            manifest.decisions[dec["req_id"]] = ReviewDecision(
                req_id=dec["req_id"],
                decision=Decision(dec["decision"]),
                modified_text=dec.get("modified_text"),
                justification=dec.get("justification"),
                reviewer="web_ui",
                timestamp=datetime.now(),
            )

        save_manifest(manifest, manifest_path)

        remaining = sum(
            1 for sr in manifest.requirements
            if sr.overall in (OverallStatus.REVIEW, OverallStatus.FAIL)
            and sr.requirement.req_id not in manifest.decisions
        )

        return JSONResponse({"status": "ok", "remaining": remaining})

    # --- API: Add Requirement ---

    @app.post("/api/add-requirement/{session_id}")
    async def add_requirement(session_id: str, request: Request):
        """Add a new requirement, score it, and append to manifest."""
        session = get_session(session_id)
        if not session:
            return JSONResponse({"error": "Session not found"})

        work_dir = Path(session["work_dir"])
        manifest_path = work_dir / "manifest.json"

        payload = await request.json()
        req_id = payload.get("req_id", "").strip()
        section = payload.get("section", "").strip()
        title = payload.get("title", "").strip()
        text = payload.get("text", "").strip()

        if not req_id or not text:
            return JSONResponse({"error": "ReqID and text are required"})

        from .models import Requirement, ScoredRequirement, OverallStatus
        from .review import load_manifest, save_manifest
        from .score import score_single
        from .config import load_gates, load_domain_terms, get_api_key as _get_api_key
        from .llm import LLMClient

        key = api_key or _get_api_key()
        manifest = load_manifest(manifest_path)

        # Resolve client
        client = None
        gates_config = session.get("gates", "")
        if gates_config.startswith("template:"):
            client = f"_session_{session_id}"
        elif gates_config:
            client = gates_config
        if not client and default_client:
            client = default_client

        new_req = Requirement(
            req_id=req_id,
            section=section,
            title=title or req_id,
            text=text,
            source_page=None,
        )

        # Score the new requirement
        try:
            llm = LLMClient(api_key=key)
            gates = load_gates(client)
            domain_terms = load_domain_terms(client)
            scored = score_single(llm, new_req, gates, domain_terms)
        except Exception as e:
            scored = ScoredRequirement(requirement=new_req, overall=OverallStatus.REVIEW)

        manifest.requirements.append(scored)
        save_manifest(manifest, manifest_path)

        return JSONResponse({
            "status": "ok",
            "req_id": req_id,
            "overall": scored.overall.value,
        })

    # --- API: Chat / Q&A ---

    @app.post("/api/chat/{session_id}")
    async def chat_about_requirement(session_id: str, request: Request):
        """Answer a question about a specific requirement."""
        session = get_session(session_id)
        if not session:
            return JSONResponse({"error": "Session not found"})

        work_dir = Path(session["work_dir"])
        manifest_path = work_dir / "manifest.json"

        payload = await request.json()
        req_id = payload.get("req_id", "")
        question = payload.get("question", "").strip()

        if not question:
            return JSONResponse({"answer": "Please ask a question."})

        from .review import load_manifest
        from .config import load_gates, load_domain_terms, get_api_key as _get_api_key
        from .llm import LLMClient

        key = api_key or _get_api_key()
        manifest = load_manifest(manifest_path)

        # Find the requirement and its scoring context
        scored_req = None
        for sr in manifest.requirements:
            if sr.requirement.req_id == req_id:
                scored_req = sr
                break

        if not scored_req:
            return JSONResponse({"answer": f"Requirement {req_id} not found."})

        req = scored_req.requirement
        gate_context = ""
        for gr in scored_req.gate_results:
            gate_context += f"- {gr.gate_id} {gr.gate_name}: {gr.status.value} — {gr.finding}\n"

        fix_context = ""
        if scored_req.suggested_fix:
            fix_context = f"\nSuggested fix: {scored_req.suggested_fix}"
            if scored_req.fix_rationale:
                fix_context += f"\nFix rationale: {scored_req.fix_rationale}"

        # Resolve client for domain terms
        client = None
        gates_config = session.get("gates", "")
        if gates_config.startswith("template:"):
            client = f"_session_{session_id}"
        elif gates_config:
            client = gates_config
        if not client and default_client:
            client = default_client

        domain_terms = load_domain_terms(client)
        domain_context = f"\nDomain terms (not ambiguous in this context):\n{domain_terms}" if domain_terms else ""

        prompt = f"""You are a requirements engineering assistant helping an engineer review a specification requirement.

REQUIREMENT:
- ReqID: {req.req_id}
- Section: {req.section}
- Title: {req.title}
- Text: {req.text}

QUALITY GATE RESULTS:
{gate_context}
{fix_context}
{domain_context}

The engineer asks: {question}

Answer concisely and practically. If they ask how to improve the requirement, give a specific rewritten version. If they ask about splitting, show the individual requirements. If they ask about ambiguity, explain what's ambiguous and why. Keep answers under 200 words."""

        try:
            llm = LLMClient(api_key=key)
            answer = llm.call(prompt, max_tokens=1024)
            # Escape HTML in the answer
            answer = answer.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\n", "<br>")
        except Exception as e:
            answer = f"Error: {str(e)}"

        return JSONResponse({"answer": answer})

    # --- Page 4: Export ---

    @app.get("/export/{session_id}", response_class=HTMLResponse)
    async def export_page(session_id: str):
        session = get_session(session_id)
        if not session:
            return _page("Error", '<div class="card">Session not found.</div>', step=4)

        work_dir = Path(session["work_dir"])
        manifest_path = work_dir / "manifest.json"

        # Run export
        from .export import export_xlsx
        try:
            output_path = export_xlsx(
                manifest_path=manifest_path,
                output_path=work_dir / f"{Path(session['pdf_name']).stem}_Final.xlsx",
            )
            session["final_xlsx"] = str(output_path)
        except SystemExit:
            return _page("Export", '''
            <div class="card" style="text-align:center">
                <div style="color:#ef4444;font-size:1.2em">Some items still need review.</div>
                <a href="/review/''' + session_id + '''" class="btn" style="margin-top:16px">Back to Review</a>
            </div>''', step=4)

        from .review import load_manifest
        manifest = load_manifest(manifest_path)
        stats = manifest.stats
        from .models import Decision
        decided = manifest.decisions
        accepted = sum(1 for d in decided.values() if d.decision == Decision.ACCEPTED)
        modified = sum(1 for d in decided.values() if d.decision == Decision.MODIFIED)
        rejected = sum(1 for d in decided.values() if d.decision == Decision.REJECTED)

        filename = Path(session["pdf_name"]).stem + "_Final.xlsx"

        content = f'''
        <div class="card" style="text-align:center">
            <div style="font-size:2em;margin-bottom:12px">&#10003;</div>
            <div style="font-size:1.3em;color:#22c55e;margin-bottom:16px">Review Complete</div>

            <div style="display:flex;gap:12px;justify-content:center;margin-bottom:20px">
                <div class="stat stat-pass">{stats["pass"]} auto-pass</div>
                {f'<div class="stat" style="background:#0d2818;color:#22c55e">{accepted} accepted</div>' if accepted else ''}
                {f'<div class="stat" style="background:#0d1832;color:#58a6ff">{modified} modified</div>' if modified else ''}
                {f'<div class="stat" style="background:#2d0000;color:#ef4444">{rejected} rejected</div>' if rejected else ''}
            </div>

            <a href="/download/{session_id}" class="btn" style="font-size:1.1em;padding:12px 32px">
                Download {filename}
            </a>

            <div style="margin-top:24px;color:#8b949e;font-size:0.85em">
                Source: {session["pdf_name"]} | Gates: {manifest.gate_config} | {stats["total"]} requirements
            </div>
        </div>
        '''
        return _page("Export", content, session_id=session_id, step=4)

    @app.get("/download/{session_id}")
    async def download_file(session_id: str):
        session = get_session(session_id)
        if not session or "final_xlsx" not in session:
            return JSONResponse({"error": "No file available"})

        path = Path(session["final_xlsx"])
        return FileResponse(
            path=path,
            filename=path.name,
            media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )

    return app


def start_webapp(client: Optional[str] = None, api_key: Optional[str] = None, port: int = 8321):
    """Start the web application."""
    import uvicorn
    import webbrowser
    from .config import get_api_key as _get_api_key, resolve_client

    api_key = api_key or _get_api_key()
    client = resolve_client(client)

    app = create_app(default_client=client, api_key=api_key)

    from rich.console import Console
    console = Console()
    console.print(f"[bold]smart-req web UI starting on http://localhost:{port}[/bold]")
    console.print("[dim]Press Ctrl+C to stop.[/dim]")

    webbrowser.open(f"http://localhost:{port}")

    config = uvicorn.Config(app, host="127.0.0.1", port=port, log_level="warning")
    server = uvicorn.Server(config)
    server.run()
