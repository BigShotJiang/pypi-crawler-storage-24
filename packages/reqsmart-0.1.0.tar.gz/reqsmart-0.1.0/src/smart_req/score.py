"""Skill: /req-score — Score requirements against quality gates."""

import asyncio
import csv
import json
import logging
import time
from pathlib import Path
from typing import List, Optional

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn
from rich.table import Table

from .models import (
    Requirement, GateDefinition, GateResult, GateStatus,
    ScoredRequirement, OverallStatus, Manifest,
)
from .config import (
    load_gates, load_domain_terms, load_prompt,
    compute_file_hash, gates_config_name,
)
from .llm import LLMClient

logger = logging.getLogger(__name__)
console = Console()


def build_scoring_prompt(
    requirement: Requirement,
    gates: List[GateDefinition],
    domain_terms: str,
) -> str:
    """Build the LLM prompt for scoring a single requirement."""
    gates_text = ""
    for g in gates:
        gates_text += f"\n### {g.id}: {g.name}\n"
        gates_text += f"- **Pass:** {g.pass_criteria}\n"
        gates_text += f"- **Fail:** {g.fail_criteria}\n"
        if g.warn_criteria:
            gates_text += f"- **Warn:** {g.warn_criteria}\n"

    domain_section = ""
    if domain_terms:
        domain_section = f"""
DOMAIN-SPECIFIC TERMS (do NOT flag these as ambiguous):
{domain_terms}
"""

    return f"""Score this requirement against each quality gate.

REQUIREMENT:
- ReqID: {requirement.req_id}
- Section: {requirement.section}
- Title: {requirement.title}
- Text: {requirement.text}

QUALITY GATES:
{gates_text}
{domain_section}
For each gate, assess Pass, Warn, or Fail with a specific finding.
If ANY gate is Fail, also provide a suggested fix for the requirement text and a brief rationale.

Respond with ONLY a JSON object:
{{
  "gates": [
    {{"gate_id": "...", "gate_name": "...", "status": "Pass|Warn|Fail", "finding": "..."}},
    ...
  ],
  "suggested_fix": "improved requirement text or null if all pass",
  "fix_rationale": "why the fix was needed or null"
}}

JSON:"""


def parse_score_response(response: str, gates: List[GateDefinition]) -> dict:
    """Parse LLM scoring response into structured data."""
    data = LLMClient.parse_json_object(response)
    if not data:
        # Return all-pass fallback if parsing fails
        return {
            "gates": [
                {"gate_id": g.id, "gate_name": g.name, "status": "Pass", "finding": "Parse error — defaulted to Pass"}
                for g in gates
            ],
            "suggested_fix": None,
            "fix_rationale": None,
        }
    return data


def score_single(
    llm: LLMClient,
    requirement: Requirement,
    gates: List[GateDefinition],
    domain_terms: str,
) -> ScoredRequirement:
    """Score a single requirement against all gates."""
    prompt = build_scoring_prompt(requirement, gates, domain_terms)
    response = llm.call(prompt)
    data = parse_score_response(response, gates)

    gate_results = []
    for g_data in data.get("gates", []):
        status_str = g_data.get("status", "Pass")
        try:
            status = GateStatus(status_str)
        except ValueError:
            status = GateStatus.PASS

        gate_results.append(GateResult(
            gate_id=g_data.get("gate_id", ""),
            gate_name=g_data.get("gate_name", ""),
            status=status,
            finding=g_data.get("finding", ""),
        ))

    # Determine overall status
    has_fail = any(g.status == GateStatus.FAIL for g in gate_results)
    has_warn = any(g.status == GateStatus.WARN for g in gate_results)

    if has_fail:
        overall = OverallStatus.FAIL
    elif has_warn:
        overall = OverallStatus.REVIEW
    else:
        overall = OverallStatus.PASS

    return ScoredRequirement(
        requirement=requirement,
        gate_results=gate_results,
        overall=overall,
        suggested_fix=data.get("suggested_fix"),
        fix_rationale=data.get("fix_rationale"),
    )


async def score_single_async(
    llm: LLMClient,
    requirement: Requirement,
    gates: List[GateDefinition],
    domain_terms: str,
    semaphore: asyncio.Semaphore,
) -> ScoredRequirement:
    """Async version of score_single with concurrency control."""
    async with semaphore:
        prompt = build_scoring_prompt(requirement, gates, domain_terms)
        response = await llm.call_async(prompt)
        data = parse_score_response(response, gates)

        gate_results = []
        for g_data in data.get("gates", []):
            status_str = g_data.get("status", "Pass")
            try:
                status = GateStatus(status_str)
            except ValueError:
                status = GateStatus.PASS

            gate_results.append(GateResult(
                gate_id=g_data.get("gate_id", ""),
                gate_name=g_data.get("gate_name", ""),
                status=status,
                finding=g_data.get("finding", ""),
            ))

        has_fail = any(g.status == GateStatus.FAIL for g in gate_results)
        has_warn = any(g.status == GateStatus.WARN for g in gate_results)

        if has_fail:
            overall = OverallStatus.FAIL
        elif has_warn:
            overall = OverallStatus.REVIEW
        else:
            overall = OverallStatus.PASS

        return ScoredRequirement(
            requirement=requirement,
            gate_results=gate_results,
            overall=overall,
            suggested_fix=data.get("suggested_fix"),
            fix_rationale=data.get("fix_rationale"),
        )


def _save_manifest_xlsx(manifest: Manifest, gates: List[GateDefinition], xlsx_path: Path):
    """Save scoring results as a 3-sheet XLSX for human review.

    Sheets:
    - PASS: requirements that passed all gates
    - REVIEW: requirements with warnings (no fails)
    - FAIL: requirements with at least one fail — includes suggested fix and decision column
    """
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.worksheet.datavalidation import DataValidation

    wb = Workbook()

    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill(start_color="1F2937", end_color="1F2937", fill_type="solid")
    pass_fill = PatternFill(start_color="D1FAE5", end_color="D1FAE5", fill_type="solid")
    warn_fill = PatternFill(start_color="FEF3C7", end_color="FEF3C7", fill_type="solid")
    fail_fill = PatternFill(start_color="FEE2E2", end_color="FEE2E2", fill_type="solid")
    thin_border = Border(
        left=Side(style='thin'), right=Side(style='thin'),
        top=Side(style='thin'), bottom=Side(style='thin'),
    )
    wrap = Alignment(wrap_text=True, vertical='top')

    # Build gate column headers
    gate_ids = [g.id for g in gates]

    # Common headers
    base_headers = ["ReqID", "Section", "Original Requirement Text"]
    gate_headers = gate_ids
    review_extra = ["Overall", "Suggested Fix", "Fix Rationale", "Decision (Accept/Modify/Reject)", "Engineer Notes"]

    def _write_headers(ws, headers, fill):
        for col, h in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=h)
            cell.font = header_font
            cell.fill = fill
            cell.border = thin_border
            cell.alignment = Alignment(wrap_text=True, vertical='top', horizontal='center')

    def _set_col_widths(ws, headers):
        for col, h in enumerate(headers, 1):
            if h in ("Original Requirement Text", "Suggested Fix"):
                ws.column_dimensions[chr(64 + col) if col <= 26 else 'A'].width = 55
            elif h in ("Fix Rationale", "Engineer Notes"):
                ws.column_dimensions[chr(64 + col) if col <= 26 else 'A'].width = 30
            elif h in ("Decision (Accept/Modify/Reject)",):
                ws.column_dimensions[chr(64 + col) if col <= 26 else 'A'].width = 20
            elif h == "ReqID":
                ws.column_dimensions[chr(64 + col) if col <= 26 else 'A'].width = 15
            else:
                ws.column_dimensions[chr(64 + col) if col <= 26 else 'A'].width = 12

    # --- PASS sheet ---
    ws_pass = wb.active
    ws_pass.title = "PASS"
    pass_headers = base_headers + gate_headers + ["Overall"]
    _write_headers(ws_pass, pass_headers, header_fill)
    _set_col_widths(ws_pass, pass_headers)

    row = 2
    for sr in manifest.requirements:
        if sr.overall != OverallStatus.PASS:
            continue
        req = sr.requirement
        values = [req.req_id, req.section, req.text]
        for gid in gate_ids:
            gr = next((g for g in sr.gate_results if g.gate_id == gid), None)
            values.append(gr.status.value if gr else "—")
        values.append("PASS")

        for col, val in enumerate(values, 1):
            cell = ws_pass.cell(row=row, column=col, value=val)
            cell.border = thin_border
            cell.alignment = wrap
            cell.fill = pass_fill
        row += 1

    # --- REVIEW sheet ---
    ws_review = wb.create_sheet("REVIEW")
    review_headers = base_headers + gate_headers + review_extra
    _write_headers(ws_review, review_headers, header_fill)
    _set_col_widths(ws_review, review_headers)

    row = 2
    for sr in manifest.requirements:
        if sr.overall != OverallStatus.REVIEW:
            continue
        req = sr.requirement
        values = [req.req_id, req.section, req.text]
        for gid in gate_ids:
            gr = next((g for g in sr.gate_results if g.gate_id == gid), None)
            values.append(gr.status.value if gr else "—")
        values.extend([
            sr.overall.value,
            sr.suggested_fix or "",
            sr.fix_rationale or "",
            "",  # Decision column — engineer fills in
            "",  # Engineer notes
        ])

        for col, val in enumerate(values, 1):
            cell = ws_review.cell(row=row, column=col, value=val)
            cell.border = thin_border
            cell.alignment = wrap
            cell.fill = warn_fill
        row += 1

    # Add dropdown validation to Decision column in REVIEW sheet
    if row > 2:  # Has data rows
        decision_col_idx = review_headers.index("Decision (Accept/Modify/Reject)") + 1
        decision_col_letter = chr(64 + decision_col_idx) if decision_col_idx <= 26 else 'A'
        dv_review = DataValidation(
            type="list",
            formula1='"Accept,Modify,Reject"',
            allow_blank=True,
            showErrorMessage=True,
            errorTitle="Invalid Decision",
            error="Please select Accept, Modify, or Reject.",
            promptTitle="Decision",
            prompt="Select: Accept, Modify, or Reject",
            showInputMessage=True,
        )
        dv_review.add(f"{decision_col_letter}2:{decision_col_letter}{row - 1}")
        ws_review.add_data_validation(dv_review)

    # --- FAIL sheet ---
    ws_fail = wb.create_sheet("FAIL")
    fail_headers = base_headers + gate_headers + review_extra
    _write_headers(ws_fail, fail_headers, header_fill)
    _set_col_widths(ws_fail, fail_headers)

    row = 2
    for sr in manifest.requirements:
        if sr.overall != OverallStatus.FAIL:
            continue
        req = sr.requirement

        # Also add per-gate findings as a tooltip-style column
        values = [req.req_id, req.section, req.text]
        for gid in gate_ids:
            gr = next((g for g in sr.gate_results if g.gate_id == gid), None)
            if gr and gr.status != GateStatus.PASS:
                values.append(f"{gr.status.value}: {gr.finding}")
            else:
                values.append(gr.status.value if gr else "—")
        values.extend([
            sr.overall.value,
            sr.suggested_fix or "",
            sr.fix_rationale or "",
            "",  # Decision column
            "",  # Engineer notes
        ])

        for col, val in enumerate(values, 1):
            cell = ws_fail.cell(row=row, column=col, value=val)
            cell.border = thin_border
            cell.alignment = wrap
            cell.fill = fail_fill
        row += 1

    # Add dropdown validation to Decision column in FAIL sheet
    if row > 2:  # Has data rows
        decision_col_idx = fail_headers.index("Decision (Accept/Modify/Reject)") + 1
        decision_col_letter = chr(64 + decision_col_idx) if decision_col_idx <= 26 else 'A'
        dv_fail = DataValidation(
            type="list",
            formula1='"Accept,Modify,Reject"',
            allow_blank=True,
            showErrorMessage=True,
            errorTitle="Invalid Decision",
            error="Please select Accept, Modify, or Reject.",
            promptTitle="Decision",
            prompt="Select: Accept, Modify, or Reject",
            showInputMessage=True,
        )
        dv_fail.add(f"{decision_col_letter}2:{decision_col_letter}{row - 1}")
        ws_fail.add_data_validation(dv_fail)

    # --- Instructions sheet ---
    ws_instr = wb.create_sheet("Instructions", 0)  # Insert as first sheet
    instructions = [
        ("smart-req Scoring Results", ""),
        ("", ""),
        ("HOW TO REVIEW:", ""),
        ("1.", "Go to the REVIEW and FAIL tabs"),
        ("2.", "For each requirement, enter a decision in the 'Decision' column:"),
        ("", "   Accept  — use the suggested fix as-is"),
        ("", "   Modify  — edit the 'Suggested Fix' column with your text"),
        ("", "   Reject  — keep the original requirement (add reason in Engineer Notes)"),
        ("3.", "Save this spreadsheet"),
        ("4.", "Run this command in your terminal:"),
        ("", "   smart-req finalize"),
        ("", ""),
        ("", "This reads your decisions and produces the final gate-clean spreadsheet."),
        ("", ""),
        ("ALTERNATIVE:", "Use the browser review UI instead:"),
        ("", "   smart-req review"),
        ("", ""),
        ("TABS:", ""),
        ("  PASS", f"{sum(1 for r in manifest.requirements if r.overall == OverallStatus.PASS)} requirements — passed all gates, no action needed"),
        ("  REVIEW", f"{sum(1 for r in manifest.requirements if r.overall == OverallStatus.REVIEW)} requirements — warnings, review recommended"),
        ("  FAIL", f"{sum(1 for r in manifest.requirements if r.overall == OverallStatus.FAIL)} requirements — failed gates, action required"),
    ]

    ws_instr.column_dimensions['A'].width = 15
    ws_instr.column_dimensions['B'].width = 80

    for row_idx, (col_a, col_b) in enumerate(instructions, 1):
        cell_a = ws_instr.cell(row=row_idx, column=1, value=col_a)
        cell_b = ws_instr.cell(row=row_idx, column=2, value=col_b)
        cell_a.alignment = Alignment(vertical='top')
        cell_b.alignment = Alignment(vertical='top', wrap_text=True)
        if row_idx == 1:
            cell_a.font = Font(bold=True, size=14)
        elif col_a in ("HOW TO REVIEW:", "ALTERNATIVE:", "TABS:"):
            cell_a.font = Font(bold=True)

    wb.save(xlsx_path)
    logger.info(f"Manifest XLSX saved to {xlsx_path}")


def load_requirements_from_csv(csv_path: Path) -> List[Requirement]:
    """Load requirements from raw_extract.csv."""
    requirements = []
    with open(csv_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            requirements.append(Requirement(
                req_id=row.get('ReqID', ''),
                section=row.get('Section', ''),
                title=row.get('Title', ''),
                text=row.get('Text', row.get('ShortSummary', '')),
                category=row.get('Category') or None,
                source_page=int(row['SourcePage']) if row.get('SourcePage') else None,
            ))
    return requirements


def score_requirements(
    input_path: Path,
    output_dir: Path,
    client: Optional[str] = None,
    model: str = "claude-sonnet-4-20250514",
    concurrency: int = 10,
    api_key: Optional[str] = None,
) -> Path:
    """Full scoring pipeline: CSV -> manifest.json.

    Returns path to manifest.json.
    """
    input_path = Path(input_path)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    # Load inputs
    requirements = load_requirements_from_csv(input_path)
    gates = load_gates(client)
    domain_terms = load_domain_terms(client)
    custom_prompt = load_prompt(client, "score")

    console.print(f"[bold]Scoring {len(requirements)} requirements against {len(gates)} gates[/bold]")
    console.print(f"  Gates: {gates_config_name(client)}")
    console.print(f"  Model: {model}")
    console.print()

    llm = LLMClient(model=model, api_key=api_key)
    start_time = time.time()

    # Score all requirements (sync for simplicity in v1)
    scored = []
    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("{task.completed}/{task.total}"),
        console=console,
    ) as progress:
        task = progress.add_task("Scoring", total=len(requirements))

        for req in requirements:
            try:
                result = score_single(llm, req, gates, domain_terms)
                scored.append(result)
            except Exception as e:
                logger.error(f"Failed to score {req.req_id}: {e}")
                # Add with all-pass fallback
                scored.append(ScoredRequirement(
                    requirement=req,
                    overall=OverallStatus.REVIEW,
                ))
            progress.update(task, advance=1)

    elapsed = time.time() - start_time

    # Resolve source PDF name from extract sidecar
    source_pdf = ""
    meta_path = input_path.with_suffix('.meta.json')
    if meta_path.exists():
        with open(meta_path) as f:
            meta = json.load(f)
            source_pdf = meta.get("source_pdf", "")

    # Build manifest
    manifest = Manifest(
        source_pdf=source_pdf,
        input_document=input_path.name,
        input_hash=compute_file_hash(input_path),
        gate_config=gates_config_name(client),
        llm_model=model,
        requirements=scored,
    )

    # Save manifest JSON
    manifest_path = output_dir / "manifest.json"
    with open(manifest_path, 'w', encoding='utf-8') as f:
        json.dump(manifest.model_dump(mode='json'), f, indent=2, default=str)

    # Save manifest XLSX (3 sheets: PASS, REVIEW, FAIL)
    xlsx_path = output_dir / "manifest.xlsx"
    _save_manifest_xlsx(manifest, gates, xlsx_path)

    # Print summary
    stats = manifest.stats
    console.print()
    console.print(f"[bold green]Scoring complete[/bold green] ({elapsed:.1f}s)")
    console.print()

    table = Table(title="Results")
    table.add_column("Status", style="bold")
    table.add_column("Count", justify="right")
    table.add_column("Percentage", justify="right")

    total = stats["total"]
    for label, count, style in [
        ("PASS", stats["pass"], "green"),
        ("REVIEW", stats["review"], "yellow"),
        ("FAIL", stats["fail"], "red"),
    ]:
        pct = f"{count/total*100:.0f}%" if total else "0%"
        table.add_row(f"[{style}]{label}[/{style}]", str(count), pct)

    table.add_row("[bold]Total[/bold]", str(total), "100%")
    console.print(table)

    # Top failure patterns
    failure_counts: dict[str, int] = {}
    for sr in scored:
        for gr in sr.gate_results:
            if gr.status == GateStatus.FAIL:
                key = f"{gr.gate_id} {gr.gate_name}"
                failure_counts[key] = failure_counts.get(key, 0) + 1

    if failure_counts:
        console.print()
        console.print("[bold]Top failure patterns:[/bold]")
        for gate, count in sorted(failure_counts.items(), key=lambda x: -x[1])[:5]:
            console.print(f"  {gate}: {count}")

    console.print()
    console.print(f"  Output directory: {output_dir.resolve()}")
    console.print(f"  Manifest JSON:   {manifest_path.resolve()}")
    console.print(f"  Manifest XLSX:   {xlsx_path.resolve()}")
    console.print()
    console.print("[dim]Run 'smart-req review' to open HITL review.[/dim]")

    return manifest_path
