"""Import review decisions from manifest.xlsx back into manifest.json."""

import json
import logging
from datetime import datetime
from pathlib import Path

from rich.console import Console

from .models import Manifest, ReviewDecision, Decision, OverallStatus

logger = logging.getLogger(__name__)
console = Console()

# Accepted decision values (case-insensitive)
DECISION_MAP = {
    "accept": Decision.ACCEPTED,
    "accepted": Decision.ACCEPTED,
    "a": Decision.ACCEPTED,
    "modify": Decision.MODIFIED,
    "modified": Decision.MODIFIED,
    "m": Decision.MODIFIED,
    "reject": Decision.REJECTED,
    "rejected": Decision.REJECTED,
    "r": Decision.REJECTED,
    "deny": Decision.REJECTED,
    "denied": Decision.REJECTED,
}


def import_from_xlsx(
    xlsx_path: Path,
    manifest_path: Path,
) -> int:
    """Import decisions from manifest.xlsx into manifest.json.

    Reads the Decision and Engineer Notes columns from REVIEW and FAIL sheets.
    Updates manifest.json with the decisions found.

    Returns number of decisions imported.
    """
    try:
        from openpyxl import load_workbook
    except ImportError:
        raise ImportError("openpyxl required: pip install openpyxl")

    xlsx_path = Path(xlsx_path)
    manifest_path = Path(manifest_path)

    # Load manifest
    with open(manifest_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    manifest = Manifest.model_validate(data)

    # Load XLSX
    wb = load_workbook(xlsx_path)
    imported = 0

    for sheet_name in ("REVIEW", "FAIL"):
        if sheet_name not in wb.sheetnames:
            continue

        ws = wb[sheet_name]

        # Find column indices from header row
        headers = {}
        for col in range(1, ws.max_column + 1):
            val = ws.cell(row=1, column=col).value
            if val:
                headers[val.strip()] = col

        # Locate required columns
        req_id_col = headers.get("ReqID")
        decision_col = None
        notes_col = None

        # Find decision column (flexible matching)
        for h, c in headers.items():
            h_lower = h.lower()
            if "decision" in h_lower:
                decision_col = c
            if "engineer" in h_lower and "note" in h_lower:
                notes_col = c
            if "notes" == h_lower:
                notes_col = c

        if not req_id_col or not decision_col:
            console.print(f"[yellow]Sheet '{sheet_name}': Could not find ReqID or Decision column, skipping[/yellow]")
            continue

        # Find Suggested Fix column for modified text
        fix_col = headers.get("Suggested Fix")

        # Read decisions
        for row in range(2, ws.max_row + 1):
            req_id = ws.cell(row=row, column=req_id_col).value
            decision_raw = ws.cell(row=row, column=decision_col).value
            notes = ws.cell(row=row, column=notes_col).value if notes_col else None

            if not req_id or not decision_raw:
                continue

            # Parse decision
            decision_str = str(decision_raw).strip().lower()
            decision = DECISION_MAP.get(decision_str)

            if decision is None:
                console.print(f"[yellow]  {req_id}: Unknown decision '{decision_raw}', skipping[/yellow]")
                continue

            # For modified decisions, get the text from Suggested Fix column
            # (engineer may have edited it in Excel)
            modified_text = None
            if decision == Decision.MODIFIED and fix_col:
                modified_text = ws.cell(row=row, column=fix_col).value

            # For accepted decisions, we don't need modified_text
            # (the suggested fix from scoring is used)

            manifest.decisions[req_id] = ReviewDecision(
                req_id=req_id,
                decision=decision,
                modified_text=modified_text if decision == Decision.MODIFIED else None,
                justification=str(notes).strip() if notes else None,
                reviewer="xlsx_import",
                timestamp=datetime.now(),
            )
            imported += 1

    # Save updated manifest
    with open(manifest_path, 'w', encoding='utf-8') as f:
        json.dump(manifest.model_dump(mode='json'), f, indent=2, default=str)

    # Summary
    stats = manifest.stats
    console.print(f"[bold green]Imported {imported} decisions from {xlsx_path.name}[/bold green]")
    console.print(f"  Pending review: {stats['pending_review']}")
    console.print(f"  Total decided: {stats['decided']}")

    if stats['pending_review'] == 0:
        console.print()
        console.print("[dim]All items reviewed. Run 'smart-req export' to generate the final spreadsheet.[/dim]")
    else:
        console.print()
        console.print(f"[dim]{stats['pending_review']} items still need decisions. Edit the XLSX or use 'smart-req review'.[/dim]")

    return imported
