"""smart-req: SMART Requirement Qualification Skill Pack."""

__version__ = "0.1.0"
