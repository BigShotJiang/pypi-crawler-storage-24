"""
PDF processing for requirement extraction.

PDF text extraction with section-aware chunking.
Handles text extraction, sanitization, and section-aware chunking.
"""

import bisect
import re
import logging
from pathlib import Path
from typing import List, Tuple, Optional, Generator
from dataclasses import dataclass

logger = logging.getLogger(__name__)

# Zero-width and invisible Unicode characters to strip
_ZERO_WIDTH_CHARS = re.compile(
    r'[\u200b\u200c\u200d\u200e\u200f'
    r'\u2060\u2061\u2062\u2063\u2064'
    r'\ufeff\u00ad\u034f\u061c'
    r'\u115f\u1160\u17b4\u17b5\u180e\uffa0]'
)


@dataclass
class TextChunk:
    """A chunk of text from a PDF with metadata."""
    index: int
    text: str
    start_page: int
    end_page: int
    token_count: int
    char_count: int
    section_hint: Optional[str] = None


class PDFProcessor:
    """Extract and chunk text from PDF documents for LLM processing."""

    SECTION_PATTERNS = [
        r'^(\d+\.)+\d*\s+[A-Z]',
        r'^Section\s+\d+',
        r'^Chapter\s+\d+',
        r'^[A-Z][A-Z\s]{5,}$',
    ]

    def __init__(
        self,
        max_tokens_per_chunk: int = 4000,
        overlap_tokens: int = 300,
        chars_per_token: float = 4.0,
        section_patterns: Optional[List[str]] = None,
        sanitize: bool = True,
    ):
        self.max_tokens_per_chunk = max_tokens_per_chunk
        self.overlap_tokens = overlap_tokens
        self.chars_per_token = chars_per_token
        self.sanitize = sanitize
        self._fitz = None
        if section_patterns:
            self.SECTION_PATTERNS = section_patterns

    def _ensure_fitz(self):
        if self._fitz is None:
            try:
                import fitz
                self._fitz = fitz
            except ImportError:
                raise ImportError(
                    "pymupdf is required for PDF processing. "
                    "Install with: pip install pymupdf"
                )
        return self._fitz

    def sanitize_text(self, text: str) -> str:
        if not self.sanitize:
            return text
        text = _ZERO_WIDTH_CHARS.sub('', text)
        text = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]', '', text)
        return text

    def get_pdf_info(self, pdf_path: Path) -> dict:
        fitz = self._ensure_fitz()
        pdf_path = Path(pdf_path)
        if not pdf_path.exists():
            raise FileNotFoundError(f"PDF not found: {pdf_path}")
        doc = fitz.open(pdf_path)
        info = {
            "page_count": doc.page_count,
            "file_size_mb": pdf_path.stat().st_size / (1024 * 1024),
            "title": doc.metadata.get("title", ""),
            "author": doc.metadata.get("author", ""),
            "filename": pdf_path.name,
        }
        doc.close()
        return info

    def estimate_tokens(self, text: str) -> int:
        return int(len(text) / self.chars_per_token)

    def _find_section_positions(self, text: str) -> List[int]:
        positions = []
        for line_match in re.finditer(r'^(.+)$', text, re.MULTILINE):
            line = line_match.group(1).strip()
            if not line:
                continue
            for pattern in self.SECTION_PATTERNS:
                if re.match(pattern, line):
                    positions.append(line_match.start())
                    break
        return sorted(positions)

    def _find_section_start(self, text: str) -> Optional[str]:
        lines = text.strip().split('\n')[:5]
        for line in lines:
            line = line.strip()
            for pattern in self.SECTION_PATTERNS:
                if re.match(pattern, line):
                    return line[:100]
        return None

    def _find_best_break(self, text: str, target_pos: int, section_positions: List[int]) -> int:
        search_start = max(target_pos - 2000, 0)
        best_section = None
        for sp in section_positions:
            if search_start <= sp < target_pos:
                best_section = sp
            elif sp >= target_pos:
                break

        min_chunk = int(self.max_tokens_per_chunk * self.chars_per_token * 0.7)
        if best_section is not None and (target_pos - best_section) < min_chunk:
            return best_section

        if target_pos >= len(text):
            return len(text)

        search_text = text[max(target_pos - 500, 0):target_pos]
        para_break = search_text.rfind('\n\n')
        if para_break != -1:
            return max(target_pos - 500, 0) + para_break

        newline = search_text.rfind('\n')
        if newline != -1:
            return max(target_pos - 500, 0) + newline

        return target_pos

    def chunk_text(self, text: str, page_boundaries: Optional[List[int]] = None) -> List[TextChunk]:
        chunks = []
        max_chars = int(self.max_tokens_per_chunk * self.chars_per_token)
        overlap_chars = min(int(self.overlap_tokens * self.chars_per_token), 300)

        section_positions = self._find_section_positions(text)
        pos = 0
        chunk_idx = 0
        text_len = len(text)

        while pos < text_len:
            end_pos = min(pos + max_chars, text_len)
            if end_pos < text_len:
                end_pos = self._find_best_break(text, end_pos, section_positions)
            if end_pos <= pos:
                end_pos = min(pos + max_chars, text_len)

            chunk_text_str = text[pos:end_pos].strip()
            if not chunk_text_str:
                break

            start_page = 1
            end_page = 1
            if page_boundaries:
                start_page = bisect.bisect_right(page_boundaries, pos)
                end_page = bisect.bisect_right(page_boundaries, end_pos)

            section_hint = self._find_section_start(chunk_text_str)
            chunk = TextChunk(
                index=chunk_idx,
                text=chunk_text_str,
                start_page=start_page,
                end_page=end_page,
                token_count=self.estimate_tokens(chunk_text_str),
                char_count=len(chunk_text_str),
                section_hint=section_hint,
            )
            chunks.append(chunk)

            overlap_start = max(end_pos - overlap_chars, pos)
            overlap_section = None
            for sp in section_positions:
                if overlap_start <= sp < end_pos:
                    overlap_section = sp
                elif sp >= end_pos:
                    break

            new_pos = overlap_section if overlap_section is not None else end_pos - overlap_chars
            if new_pos <= pos:
                new_pos = end_pos
            pos = new_pos
            chunk_idx += 1

        return chunks

    def process_pdf(self, pdf_path: Path) -> Tuple[List[TextChunk], dict]:
        pdf_path = Path(pdf_path)
        info = self.get_pdf_info(pdf_path)
        fitz = self._ensure_fitz()
        doc = fitz.open(pdf_path)

        pages_text = []
        page_boundaries = [0]
        current_pos = 0

        for page_num in range(doc.page_count):
            page = doc[page_num]
            text = page.get_text("text")
            text = self.sanitize_text(text)
            pages_text.append(text)
            current_pos += len(text) + 2
            page_boundaries.append(current_pos)

        doc.close()

        full_text = "\n\n".join(pages_text)
        info["total_chars"] = len(full_text)
        info["estimated_tokens"] = self.estimate_tokens(full_text)

        chunks = self.chunk_text(full_text, page_boundaries)
        return chunks, info

    def filter_sections(self, chunks: List[TextChunk], sections: List[str]) -> List[TextChunk]:
        """Filter chunks to only those containing specified section numbers."""
        if not sections:
            return chunks

        filtered = []
        section_patterns = [re.compile(rf'^{re.escape(s)}[\.\s]', re.MULTILINE) for s in sections]

        for chunk in chunks:
            for pattern in section_patterns:
                if pattern.search(chunk.text):
                    filtered.append(chunk)
                    break

        return filtered
