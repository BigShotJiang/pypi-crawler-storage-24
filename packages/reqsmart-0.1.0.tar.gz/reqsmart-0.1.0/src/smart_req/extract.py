"""Skill: /req-extract — PDF to raw requirements CSV."""

import csv
import hashlib
import json
import logging
import time
from pathlib import Path
from typing import List, Optional, Tuple

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn

from .models import Requirement
from .pdf import PDFProcessor, TextChunk
from .llm import LLMClient
from .config import load_prompt

logger = logging.getLogger(__name__)
console = Console()

EXTRACTION_PROMPT = """Extract ATOMIC requirements from this specification document section.

The goal is to break down every specification into the smallest testable unit — each requirement must map to exactly ONE test case.

For each requirement found, extract:
1. req_id: Synthesize as <section>-<running#> (e.g., 3.5.3-1, 3.5.10-7)
2. section: Document section number — use the MOST SPECIFIC subsection (e.g., 3.5.9.1 not 3.5.9)
3. title: Short, specific title
4. text: Full requirement text — the complete SHALL/MUST/SHOULD statement with all qualifiers and conditions
5. category: Best-fit category from the document's domain

ATOMIC EXTRACTION RULES — extract at the FINEST granularity:
- Extract ONE requirement per SHALL/MUST/SHOULD statement — do NOT merge multiple statements into one requirement
- TABLES: Extract ONE requirement PER ROW, not per table or per component group
  - Behavior tables: ONE requirement per behavior/state row
  - Timing tables: ONE requirement per component timing value
  - Alarm/fault tables: ONE requirement per alarm or fault type
  - LED/indicator tables: ONE requirement per LED state or condition
- WORKFLOWS/PROCEDURES: Extract ONE requirement per numbered step
- COMPONENT LISTS: Extract ONE requirement per component when they have DISTINCT specifications
- IMPLICIT REQUIREMENTS: Extract requirements even when not preceded by "shall":
  - Specifications in tables, state diagrams, and timing constraints ARE requirements
  - YANG data model references (RPC definitions, leaf nodes, containers) ARE interface requirements
  - NBI command specifications (CLI commands, REST endpoints, SNMP OIDs) ARE interface requirements
  - Customer requirement references (links to external specs, M120-xxx references) ARE traceability requirements
  - Overview/parent sections that define scope, card types, or LED categories ARE definitional requirements
- Do NOT consolidate or summarize — if the document lists 20 states, extract 20 requirements
- Do NOT skip sections just because they lack "shall" — if a section specifies behavior, data models, or interfaces, those are extractable requirements
- Do NOT extract: section headers, table of contents entries, figure captions, version history, metadata, or comments
- Each requirement must be distinct and independently testable

GROUP PRESERVATION:
When multiple items share ONE specification, keep them as ONE requirement with the COMPLETE item list. Only atomize when items have DISTINCT specifications (different values, behaviors, or conditions).

BEHAVIORAL RESPONSE:
Every requirement text MUST describe what the system DOES in response to a condition, not just name the scenario. BAD: "System SHALL handle LED state." GOOD: "System SHALL set the SYS LED to red within 500ms when a traffic-affecting fault is detected." The text must be testable.

CONTEXTUAL QUALIFIERS:
Preserve temporal, causal, and conditional qualifiers from the source that change meaning. "During switchover", "after commit", "only when enabled" — these MUST appear in the text.

COUPLED BEHAVIORS:
Keep closely-coupled aspects as ONE requirement when they describe a single observable behavior forming one test case. Split only when behaviors are independently triggered or testable.

TEXT:
{text}

RESPONSE FORMAT — respond with ONLY a valid JSON array:
[{{"req_id": "...", "section": "...", "title": "...", "text": "...", "category": "..."}}]
If NO requirements found: []

JSON ARRAY:"""


def generate_req_id(section: str, title: str, text: str, seq: int) -> str:
    """Generate deterministic ReqID from content."""
    content_hash = hashlib.sha256(f"{section}:{title}:{text}".encode()).hexdigest()[:6]
    return f"{section}-{seq}"


def extract_from_chunk(
    llm: LLMClient,
    chunk: TextChunk,
    custom_prompt: Optional[str] = None,
) -> List[Requirement]:
    """Extract requirements from a single text chunk."""
    prompt_template = custom_prompt or EXTRACTION_PROMPT
    prompt = prompt_template.format(text=chunk.text)

    try:
        response = llm.call(prompt)
        items = LLMClient.parse_json_response(response)

        requirements = []
        for item in items:
            req_id = item.get("req_id", "")
            title = item.get("title", "")
            text = item.get("text", item.get("summary", ""))

            if not req_id or not title:
                continue

            requirements.append(Requirement(
                req_id=req_id,
                section=item.get("section", ""),
                title=title,
                text=text,
                category=item.get("category"),
                source_page=chunk.start_page,
            ))

        return requirements

    except Exception as e:
        logger.error(f"Chunk {chunk.index} extraction failed: {e}")
        return []


def deduplicate(requirements: List[Requirement]) -> Tuple[List[Requirement], List[dict]]:
    """Merge-dedup by req_id, keeping longest text."""
    by_id: dict[str, list[Requirement]] = {}
    for req in requirements:
        key = req.req_id.lower()
        by_id.setdefault(key, []).append(req)

    unique = []
    merge_log = []

    for req_id_lower, group in by_id.items():
        if len(group) == 1:
            unique.append(group[0])
        else:
            group.sort(key=lambda r: len(r.text), reverse=True)
            winner = group[0]
            unique.append(winner)
            for dropped in group[1:]:
                merge_log.append({
                    "req_id": winner.req_id,
                    "kept_len": len(winner.text),
                    "dropped_len": len(dropped.text),
                })

    return unique, merge_log


def extract_requirements(
    pdf_path: Path,
    output_path: Path,
    client: Optional[str] = None,
    model: str = "claude-sonnet-4-20250514",
    sections: Optional[List[str]] = None,
    api_key: Optional[str] = None,
) -> Path:
    """Full extraction pipeline: PDF -> raw_extract.csv.

    Returns path to output CSV.
    """
    pdf_path = Path(pdf_path)
    output_path = Path(output_path)

    # Initialize
    llm = LLMClient(model=model, api_key=api_key)
    processor = PDFProcessor()

    # Load custom prompt if available
    custom_prompt = load_prompt(client, "extract")

    # Process PDF
    console.print(f"[bold]Extracting requirements from {pdf_path.name}...[/bold]")
    chunks, pdf_info = processor.process_pdf(pdf_path)
    console.print(
        f"  {pdf_info['page_count']} pages, "
        f"{len(chunks)} chunks, "
        f"~{pdf_info['estimated_tokens']} tokens"
    )

    # Filter sections if specified
    if sections:
        chunks = processor.filter_sections(chunks, sections)
        console.print(f"  Filtered to {len(chunks)} chunks matching sections: {', '.join(sections)}")

    if not chunks:
        console.print("[yellow]No text chunks to process.[/yellow]")
        return output_path

    # Extract from each chunk
    all_requirements = []
    start_time = time.time()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("{task.completed}/{task.total}"),
        console=console,
    ) as progress:
        task = progress.add_task("Extracting", total=len(chunks))

        for chunk in chunks:
            reqs = extract_from_chunk(llm, chunk, custom_prompt)
            all_requirements.extend(reqs)
            progress.update(task, advance=1, description=f"Extracting (found {len(all_requirements)})")

    # Deduplicate
    raw_count = len(all_requirements)
    all_requirements, merge_log = deduplicate(all_requirements)

    elapsed = time.time() - start_time

    # Save CSV
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(
            f,
            fieldnames=['ReqID', 'Section', 'Title', 'Text', 'Category', 'SourcePage'],
        )
        writer.writeheader()
        for req in all_requirements:
            writer.writerow({
                'ReqID': req.req_id,
                'Section': req.section,
                'Title': req.title,
                'Text': req.text,
                'Category': req.category or '',
                'SourcePage': req.source_page or '',
            })

    # Save source PDF name as sidecar (for score/export to derive output names)
    import json
    meta_path = output_path.with_suffix('.meta.json')
    with open(meta_path, 'w') as f:
        json.dump({"source_pdf": pdf_path.name}, f)

    # Summary
    console.print()
    console.print(f"[bold green]Extraction complete[/bold green] ({elapsed:.1f}s)")
    console.print(f"  Total extracted: {raw_count}")
    if merge_log:
        console.print(f"  Deduplicated: {len(merge_log)} duplicates removed")
    console.print(f"  Final: {len(all_requirements)} requirements")
    console.print(f"  Output: {output_path.resolve()}")
    console.print()
    console.print("[dim]Review raw_extract.csv before scoring. Check for missed or mis-split requirements.[/dim]")

    return output_path
