"""LLM client abstraction for smart-req."""

import json
import logging
import os
import re
import time
from typing import Optional

logger = logging.getLogger(__name__)

DEFAULT_MODEL = "claude-sonnet-4-20250514"


class LLMClient:
    """Thin wrapper around Anthropic API with JSON parsing."""

    def __init__(self, model: str = DEFAULT_MODEL, api_key: Optional[str] = None):
        self.model = model
        self._client = None
        self._async_client = None
        self._api_key = api_key

    def _ensure_client(self):
        if self._client is None:
            try:
                from anthropic import Anthropic
            except ImportError:
                raise ImportError("anthropic package required: pip install anthropic")

            api_key = self._api_key or os.environ.get("ANTHROPIC_API_KEY")
            if not api_key:
                raise ValueError(
                    "Anthropic API key required. Set ANTHROPIC_API_KEY env var "
                    "or run: smart-req configure --api-key <key>"
                )
            self._client = Anthropic(api_key=api_key)
        return self._client

    def _ensure_async_client(self):
        if self._async_client is None:
            try:
                from anthropic import AsyncAnthropic
            except ImportError:
                raise ImportError("anthropic package required: pip install anthropic")

            api_key = self._api_key or os.environ.get("ANTHROPIC_API_KEY")
            if not api_key:
                raise ValueError("Anthropic API key required.")
            self._async_client = AsyncAnthropic(api_key=api_key)
        return self._async_client

    def call(
        self,
        user_prompt: str,
        system_prompt: Optional[str] = None,
        max_tokens: int = 16384,
        retry_count: int = 3,
    ) -> str:
        """Synchronous LLM call with retry."""
        client = self._ensure_client()

        for attempt in range(retry_count):
            try:
                kwargs = {
                    "model": self.model,
                    "max_tokens": max_tokens,
                    "messages": [{"role": "user", "content": user_prompt}],
                }
                if system_prompt:
                    kwargs["system"] = system_prompt

                response = client.messages.create(**kwargs)
                return response.content[0].text

            except Exception as e:
                logger.warning(f"LLM call failed (attempt {attempt + 1}/{retry_count}): {e}")
                if attempt < retry_count - 1:
                    time.sleep(2 ** attempt)
                else:
                    raise

    async def call_async(
        self,
        user_prompt: str,
        system_prompt: Optional[str] = None,
        max_tokens: int = 16384,
        retry_count: int = 3,
    ) -> str:
        """Async LLM call with retry."""
        import asyncio
        client = self._ensure_async_client()

        for attempt in range(retry_count):
            try:
                kwargs = {
                    "model": self.model,
                    "max_tokens": max_tokens,
                    "messages": [{"role": "user", "content": user_prompt}],
                }
                if system_prompt:
                    kwargs["system"] = system_prompt

                response = await client.messages.create(**kwargs)
                return response.content[0].text

            except Exception as e:
                logger.warning(f"Async LLM call failed (attempt {attempt + 1}): {e}")
                if attempt < retry_count - 1:
                    await asyncio.sleep(2 ** attempt)
                else:
                    raise

    @staticmethod
    def parse_json_response(content: str) -> list:
        """Extract JSON array from LLM response, handling markdown fences."""
        content = content.strip()

        # Handle markdown code blocks
        if "```" in content:
            for fp in [r'```json\s*([\s\S]+?)```', r'```\s*([\s\S]+?)```']:
                match = re.search(fp, content)
                if match:
                    content = match.group(1).strip()
                    break

        # Find JSON array
        if not content.startswith('['):
            match = re.search(r'\[[\s\S]*\]', content)
            if match:
                content = match.group(0)

        # Check for "no requirements" responses
        no_req_patterns = [
            r'no\s+requirements?\s+(found|identified|present)',
            r'does\s+not\s+contain\s+(any\s+)?requirements?',
            r'this\s+(text|section)\s+(contains?|has)\s+no',
        ]
        if any(re.search(p, content.lower()) for p in no_req_patterns):
            return []

        try:
            parsed = json.loads(content)
            if isinstance(parsed, list):
                return parsed
            return []
        except json.JSONDecodeError:
            if '[]' in content:
                return []
            # Try to find embedded arrays
            arrays = re.findall(
                r'\[(?:[^\[\]]|\[(?:[^\[\]]|\[[^\[\]]*\])*\])*\]',
                content
            )
            results = []
            for arr_str in arrays:
                try:
                    arr = json.loads(arr_str)
                    if isinstance(arr, list):
                        results.extend(arr)
                except json.JSONDecodeError:
                    continue
            return results

    @staticmethod
    def parse_json_object(content: str) -> dict:
        """Extract JSON object from LLM response."""
        content = content.strip()

        if "```" in content:
            for fp in [r'```json\s*([\s\S]+?)```', r'```\s*([\s\S]+?)```']:
                match = re.search(fp, content)
                if match:
                    content = match.group(1).strip()
                    break

        if not content.startswith('{'):
            match = re.search(r'\{[\s\S]*\}', content)
            if match:
                content = match.group(0)

        try:
            parsed = json.loads(content)
            if isinstance(parsed, dict):
                return parsed
        except json.JSONDecodeError:
            pass

        return {}
