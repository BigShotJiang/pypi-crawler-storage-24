"""Configuration loading: gate definitions, client resolution, prompts."""

import hashlib
import os
import re
import yaml
from pathlib import Path
from typing import List, Optional

from .models import GateDefinition

# Package-level config directory
# For PyPI installs: config is inside the package (src/smart_req/default_config/)
# For dev installs: falls back to external config/ directory
_PACKAGE_DIR = Path(__file__).parent
_BUNDLED_DEFAULT = _PACKAGE_DIR / "default_config"
_BUNDLED_TEMPLATES = _PACKAGE_DIR / "templates_config"
_EXTERNAL_CONFIG = _PACKAGE_DIR.parent.parent / "config"

# Use bundled config if it exists (PyPI install), otherwise external (dev install)
if _BUNDLED_DEFAULT.exists():
    PACKAGE_CONFIG_DIR = _PACKAGE_DIR  # gates at default_config/, templates at templates_config/
    PACKAGE_DEFAULT_DIR = _BUNDLED_DEFAULT
    PACKAGE_TEMPLATES_DIR = _BUNDLED_TEMPLATES
else:
    PACKAGE_CONFIG_DIR = _EXTERNAL_CONFIG
    PACKAGE_DEFAULT_DIR = _EXTERNAL_CONFIG / "default"
    PACKAGE_TEMPLATES_DIR = _EXTERNAL_CONFIG / "templates"

USER_CONFIG_DIR = Path.home() / ".smart-req"


def get_config_path() -> Path:
    """Return user config file path."""
    return USER_CONFIG_DIR / "config.yaml"


def load_user_config() -> dict:
    """Load user configuration (API key, default client)."""
    config_path = get_config_path()
    if config_path.exists():
        with open(config_path) as f:
            return yaml.safe_load(f) or {}
    return {}


def save_user_config(config: dict):
    """Save user configuration."""
    config_path = get_config_path()
    config_path.parent.mkdir(parents=True, exist_ok=True)
    with open(config_path, "w") as f:
        yaml.dump(config, f, default_flow_style=False)


def get_api_key() -> Optional[str]:
    """Get API key from config or environment."""
    key = os.environ.get("ANTHROPIC_API_KEY")
    if key:
        return key
    config = load_user_config()
    return config.get("api_key")


def get_default_client() -> Optional[str]:
    """Get default client from config. Returns None if not set."""
    config = load_user_config()
    return config.get("default_client")


def resolve_client(explicit: Optional[str]) -> Optional[str]:
    """Resolve client: explicit flag > config default > None."""
    if explicit is not None:
        return explicit
    return get_default_client()


def resolve_client_dir(client: Optional[str]) -> Path:
    """Resolve client config directory. Checks user dir first, then package."""
    if not client:
        return PACKAGE_DEFAULT_DIR

    # Check user-level config first
    user_client = USER_CONFIG_DIR / "clients" / client
    if user_client.exists():
        return user_client

    # Fall back to package-bundled config (external config/ dir for dev installs)
    pkg_client = _EXTERNAL_CONFIG / "clients" / client
    if pkg_client.exists():
        return pkg_client

    # Fall back to default
    return PACKAGE_DEFAULT_DIR


def parse_gates_md(gates_path: Path) -> List[GateDefinition]:
    """Parse a gates.md file into GateDefinition objects.

    Expected format:
        ### G1: Atomic
        - **Pass:** criteria text
        - **Fail:** criteria text
        - **Warn:** criteria text (optional)
    """
    if not gates_path.exists():
        raise FileNotFoundError(f"Gate config not found: {gates_path}")

    content = gates_path.read_text()
    gates = []

    # Split by ### headers
    sections = re.split(r'^### ', content, flags=re.MULTILINE)

    for section in sections:
        if not section.strip():
            continue

        # Parse header: "G1: Atomic" or "RQ1: Specific"
        header_match = re.match(r'(\w+):\s*(.+)', section.strip().split('\n')[0])
        if not header_match:
            continue

        gate_id = header_match.group(1).strip()
        gate_name = header_match.group(2).strip()

        pass_criteria = ""
        fail_criteria = ""
        warn_criteria = ""

        pass_match = re.search(r'\*\*Pass:\*\*\s*(.+)', section)
        fail_match = re.search(r'\*\*Fail:\*\*\s*(.+)', section)
        warn_match = re.search(r'\*\*Warn:\*\*\s*(.+)', section)

        if pass_match:
            pass_criteria = pass_match.group(1).strip()
        if fail_match:
            fail_criteria = fail_match.group(1).strip()
        if warn_match:
            warn_criteria = warn_match.group(1).strip()

        gates.append(GateDefinition(
            id=gate_id,
            name=gate_name,
            pass_criteria=pass_criteria,
            fail_criteria=fail_criteria,
            warn_criteria=warn_criteria,
        ))

    return gates


def load_gates(client: Optional[str] = None) -> List[GateDefinition]:
    """Load gate definitions for a client (or default)."""
    client_dir = resolve_client_dir(client)
    gates_path = client_dir / "gates.md"
    return parse_gates_md(gates_path)


def load_domain_terms(client: Optional[str] = None) -> str:
    """Load domain-specific terms that should not be flagged as ambiguous."""
    client_dir = resolve_client_dir(client)
    terms_path = client_dir / "domain_terms.md"
    if terms_path.exists():
        return terms_path.read_text()
    return ""


def load_prompt(client: Optional[str], prompt_name: str) -> Optional[str]:
    """Load a client-specific prompt template."""
    client_dir = resolve_client_dir(client)
    prompt_path = client_dir / "prompts" / f"{prompt_name}.md"
    if prompt_path.exists():
        return prompt_path.read_text()
    return None


def compute_file_hash(path: Path) -> str:
    """Compute SHA-256 hash of a file."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(8192), b""):
            h.update(chunk)
    return f"sha256:{h.hexdigest()[:16]}"


def gates_config_name(client: Optional[str]) -> str:
    """Human-readable name for the gate config."""
    if client:
        return f"{client}-gates"
    return "rq-baseline"
