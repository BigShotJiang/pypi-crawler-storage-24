"""smart-req CLI — Requirement Qualification Skill Pack."""

import click
from pathlib import Path
from typing import Optional


@click.group()
@click.version_option(package_name="smart-req")
def main():
    """Requirement Qualification Tool.

    Skills: extract, score, review, export, finalize.
    """
    pass


@main.command()
@click.option("--input", "-i", "input_path", required=True, type=click.Path(exists=True),
              help="Path to specification PDF")
@click.option("--output", "-o", default="raw_extract.csv",
              help="Output CSV path")
@click.option("--client", default=None,
              help="Client config name (overrides configured default)")
@click.option("--model", default="claude-sonnet-4-20250514",
              help="LLM model for extraction")
@click.option("--sections", "-s", default=None,
              help="Comma-separated section numbers to extract (e.g., 3.5,3.22)")
@click.option("--api-key", default=None, envvar="ANTHROPIC_API_KEY",
              help="Anthropic API key")
def extract(input_path, output, client, model, sections, api_key):
    """Extract requirements from a specification PDF.

    Skill: /req-extract
    """
    from .extract import extract_requirements
    from .config import get_api_key, resolve_client

    api_key = api_key or get_api_key()
    client = resolve_client(client)
    section_list = [s.strip() for s in sections.split(",")] if sections else None

    extract_requirements(
        pdf_path=Path(input_path),
        output_path=Path(output),
        client=client,
        model=model,
        sections=section_list,
        api_key=api_key,
    )


@main.command()
@click.option("--input", "-i", "input_path", default="raw_extract.csv",
              type=click.Path(exists=True),
              help="Path to raw_extract.csv")
@click.option("--output-dir", "-o", default=".",
              help="Directory for manifest output")
@click.option("--client", default=None,
              help="Client config name (overrides configured default)")
@click.option("--model", default="claude-sonnet-4-20250514",
              help="LLM model for scoring")
@click.option("--concurrency", default=10, type=int,
              help="Max concurrent LLM calls")
@click.option("--api-key", default=None, envvar="ANTHROPIC_API_KEY",
              help="Anthropic API key")
def score(input_path, output_dir, client, model, concurrency, api_key):
    """Score requirements against quality gates.

    Skill: /req-score

    Uses configured default client if --client is not specified.
    Run 'smart-req configure --client <name>' to set a default.
    """
    from .score import score_requirements
    from .config import get_api_key, resolve_client

    api_key = api_key or get_api_key()
    client = resolve_client(client)

    score_requirements(
        input_path=Path(input_path),
        output_dir=Path(output_dir),
        client=client,
        model=model,
        concurrency=concurrency,
        api_key=api_key,
    )


@main.command()
@click.option("--manifest", "-m", default="manifest.json",
              type=click.Path(exists=True),
              help="Path to manifest.json")
@click.option("--port", default=8321, type=int,
              help="Local server port")
def review(manifest, port):
    """Open HITL review UI in browser.

    Skill: /req-review
    """
    from .review import start_review_server

    start_review_server(
        manifest_path=Path(manifest),
        port=port,
    )


@main.command()
@click.option("--manifest", "-m", default="manifest.json",
              type=click.Path(exists=True),
              help="Path to manifest.json")
@click.option("--output", "-o", default=None,
              help="Output XLSX path (default: {input}_Final.xlsx)")
def export(manifest, output):
    """Export gate-clean XLSX with audit trail.

    Skill: /req-export
    """
    from .export import export_xlsx

    output_path = Path(output) if output else None
    export_xlsx(
        manifest_path=Path(manifest),
        output_path=output_path,
    )


@main.command()
@click.option("--xlsx", "-x", default="manifest.xlsx",
              type=click.Path(exists=True),
              help="Path to manifest.xlsx with decisions filled in")
@click.option("--manifest", "-m", default="manifest.json",
              type=click.Path(exists=True),
              help="Path to manifest.json")
@click.option("--output", "-o", default=None,
              help="Output XLSX path (default: {input}_Final.xlsx)")
def finalize(xlsx, manifest, output):
    """Import decisions from spreadsheet and export final XLSX.

    One command after saving your reviewed manifest.xlsx:
    reads decisions -> exports gate-clean spreadsheet + audit trail.
    """
    from .import_decisions import import_from_xlsx
    from .export import export_xlsx

    # Step 1: Import decisions from XLSX
    count = import_from_xlsx(
        xlsx_path=Path(xlsx),
        manifest_path=Path(manifest),
    )

    if count == 0:
        from rich.console import Console
        Console().print("[yellow]No decisions found in spreadsheet. Fill in the Decision column in REVIEW/FAIL sheets first.[/yellow]")
        return

    # Step 2: Export final XLSX
    from rich.console import Console
    Console().print()
    output_path = Path(output) if output else None
    try:
        export_xlsx(
            manifest_path=Path(manifest),
            output_path=output_path,
        )
    except SystemExit:
        pass  # Export prints its own error for pending items


@main.command("import-decisions")
@click.option("--xlsx", "-x", default="manifest.xlsx",
              type=click.Path(exists=True),
              help="Path to manifest.xlsx with decisions filled in")
@click.option("--manifest", "-m", default="manifest.json",
              type=click.Path(exists=True),
              help="Path to manifest.json to update")
def import_decisions(xlsx, manifest):
    """Import review decisions from manifest.xlsx into manifest.json (advanced).

    Fill in the Decision column (Accept/Modify/Reject) and Engineer Notes
    in the REVIEW and FAIL sheets of manifest.xlsx, then run this command
    to sync those decisions back into the manifest.
    """
    from .import_decisions import import_from_xlsx

    import_from_xlsx(
        xlsx_path=Path(xlsx),
        manifest_path=Path(manifest),
    )


@main.command()
@click.option("--client", default=None, help="Default client config name")
@click.option("--api-key", prompt="Anthropic API key", hide_input=True,
              help="Anthropic API key")
def configure(client, api_key):
    """Configure smart-req (API key, default client).

    The default client is used automatically by extract and score commands
    unless overridden with --client.
    """
    from .config import save_user_config, load_user_config

    config = load_user_config()
    if api_key:
        config["api_key"] = api_key
    if client:
        config["default_client"] = client

    save_user_config(config)

    from rich.console import Console
    console = Console()
    console.print("[bold green]Configuration saved[/bold green]")
    console.print(f"  Location: ~/.smart-req/config.yaml")
    if client:
        console.print(f"  Default client: {client}")
        console.print(f"  All commands will use '{client}' gates unless --client is specified.")
    else:
        console.print(f"  No default client set. Commands will use the RQ baseline gates.")
        console.print(f"  To set a default: smart-req configure --client <name>")
    console.print(f"  API key: {'*' * 8}...{api_key[-4:]}")


@main.command()
@click.option("--input", "-i", "input_path", required=True, type=click.Path(exists=True),
              help="Path to specification PDF")
@click.option("--client", default=None,
              help="Client config name (overrides configured default)")
@click.option("--model", default="claude-sonnet-4-20250514",
              help="LLM model")
@click.option("--sections", "-s", default=None,
              help="Comma-separated section numbers to extract")
@click.option("--spreadsheet", is_flag=True, default=False,
              help="Use spreadsheet review instead of browser review")
@click.option("--api-key", default=None, envvar="ANTHROPIC_API_KEY",
              help="Anthropic API key")
@click.option("--port", default=8321, type=int,
              help="Local server port for browser review")
def run(input_path, client, model, sections, spreadsheet, api_key, port):
    """Run the full pipeline: extract, score, and review.

    Browser review (default):
      smart-req run --input spec.pdf
      Extracts, scores, opens browser review, auto-exports when done.

    Spreadsheet review:
      smart-req run --input spec.pdf --spreadsheet
      Extracts, scores, opens manifest.xlsx for review.
      After filling in decisions and saving, run: smart-req finalize
    """
    import subprocess
    import sys
    from .extract import extract_requirements
    from .score import score_requirements
    from .config import get_api_key, resolve_client

    api_key = api_key or get_api_key()
    client = resolve_client(client)
    section_list = [s.strip() for s in sections.split(",")] if sections else None

    output_dir = Path(".")
    csv_path = output_dir / "raw_extract.csv"

    # Step 1: Extract
    extract_requirements(
        pdf_path=Path(input_path),
        output_path=csv_path,
        client=client,
        model=model,
        sections=section_list,
        api_key=api_key,
    )

    # Step 2: Score
    score_requirements(
        input_path=csv_path,
        output_dir=output_dir,
        client=client,
        model=model,
        api_key=api_key,
    )

    # Step 3: Review
    if spreadsheet:
        # Open manifest.xlsx and tell user what to do next
        import platform
        xlsx_path = output_dir / "manifest.xlsx"
        if platform.system() == "Darwin":
            subprocess.Popen(["open", str(xlsx_path)])
        elif platform.system() == "Windows":
            subprocess.Popen(["start", str(xlsx_path)], shell=True)
        else:
            subprocess.Popen(["xdg-open", str(xlsx_path)])

        from rich.console import Console
        console = Console()
        console.print()
        console.print("[bold]Spreadsheet opened.[/bold]")
        console.print("  1. Fill in the Decision column (Accept/Modify/Reject) in REVIEW and FAIL tabs")
        console.print("  2. Save the spreadsheet")
        console.print("  3. Run: [bold]smart-req finalize[/bold]")
    else:
        # Browser review — auto-exports and closes when done
        from .review import start_review_server
        start_review_server(
            manifest_path=output_dir / "manifest.json",
            port=port,
        )


@main.command()
@click.option("--client", default=None,
              help="Client config name (overrides configured default)")
@click.option("--port", default=8321, type=int,
              help="Local server port")
@click.option("--api-key", default=None, envvar="ANTHROPIC_API_KEY",
              help="Anthropic API key")
def web(client, port, api_key):
    """Launch the full web UI in your browser.

    No terminal commands needed — upload PDF, review, and download
    the final spreadsheet all from the browser.
    """
    from .webapp import start_webapp
    from .config import get_api_key, resolve_client

    api_key = api_key or get_api_key()
    client = resolve_client(client)

    start_webapp(client=client, api_key=api_key, port=port)


if __name__ == "__main__":
    main()
