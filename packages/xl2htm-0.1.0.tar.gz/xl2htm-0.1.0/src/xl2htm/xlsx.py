import openpyxl


def sheets(path: str):
    book = openpyxl.load_workbook(filename=path, data_only=True)
    for name in book.sheetnames:
        sheet = book[name]
        if sheet.sheet_state == "hidden":
            continue
        yield (name, sheet)


def hidden_rows(sh):
    return set(
        row_num
        for row_num in range(1, min(10000, sh.max_row) + 1)
        if sh.row_dimensions[row_num].hidden
    )


col_names = (
    [""]
    + [chr(ord("A") + i) for i in range(26)]
    + ["A" + chr(ord("A") + i) for i in range(26)]
)


def hidden_cols(sh):
    cols = set()
    for col_num in range(1, min(50, sh.max_column) + 1):
        dim = sh.column_dimensions[col_names[col_num]]
        if dim.hidden:
            for c in range(dim.min, dim.max + 1):
                cols.add(c)
    return cols


def merges(sh):
    return [
        (r.min_row, r.min_col, r.max_row, r.max_col) for r in sh.merged_cells.ranges
    ]


def grid(sh):
    max_column = min(50, sh.max_column)
    max_row = min(10000, sh.max_row)
    return [create_row(sh, row_num, max_column) for row_num in range(1, max_row + 1)]


def create_row(sheet, row_num, max_column):
    row = []
    for col_num in range(1, max_column + 1):
        value = sheet.cell(row=row_num, column=col_num).value
        row.append((row_num, col_num, value))
    return row
