import xlrd


def sheets(path: str):
    book = xlrd.open_workbook(path, formatting_info=True)
    for idx, name in enumerate(book.sheet_names()):
        sheet = book.sheet_by_index(idx)
        yield (name, sheet)


def hidden_rows(sh):
    return set(
        i + 1 for (i, rowinfo) in sh.rowinfo_map.items() if i < 10000 and rowinfo.hidden
    )


def hidden_cols(sh):
    return set(
        i + 1 for (i, colinfo) in sh.colinfo_map.items() if i < 50 and colinfo.hidden
    )


def merges(sheet):
    return [(m[0] + 1, m[2] + 1, m[1], m[3]) for m in sheet.merged_cells]


def grid(sheet):
    return [
        [create_cell(sheet, row_num, col_num) for col_num in range(0, sheet.ncols)]
        for row_num in range(0, sheet.nrows)
    ]


def create_cell(sheet, row_num, col_num):
    value = sheet.cell_value(rowx=row_num, colx=col_num)
    value = None if value == xlrd.empty_cell.value else value
    return (row_num + 1, col_num + 1, value)
