# xl2htm

- Converts Excel files (.xlsx, .xls) to HTML
- Preserves merged cells with `rowspan` and `colspan` attributes
- Handles hidden rows and columns correctly
- Generates standalone HTML files with minimal styling

## Installation

Install from PyPI:

```bash
pip install xl2htm
```

Or with uv:

```bash
uv pip install xl2htm
```

## Usage

### CLI

options:

- `excel_file`: Path to the Excel file (.xlsx or .xls)
- `-s, --sheets`: List of sheet names to convert (if not specified, all sheets are converted)

for exmaple:

```bash
xl2htm spreadsheet.xlsx -s Sheet1 Sheet2 > output.html
```

### As a Package

Import and use in Python:

```python
from xl2htm import excel_to_html

# Convert all sheets to HTML
html = excel_to_html('spreadsheet.xlsx')
print(html)
```

Convert specific sheets:

```python
from xl2htm import excel_to_html

html = excel_to_html('spreadsheet.xlsx', sheet_names=['Sheet1', 'Sheet2'])
print(html)
```

Get individual sheet objects:

```python
from xl2htm import extract_sheets, extract_sheet

# Extract all sheets
sheets = extract_sheets('spreadsheet.xlsx')
for sheet in sheets:
    print(f"Sheet: {sheet.name}")
    print(f"Rows: {sheet.rows_count()}, Columns: {sheet.columns_count()}")

# Extract a single sheet by name
sheet = extract_sheet('spreadsheet.xlsx', 'Sheet1')
html_table = sheet.table()
```

## License

MIT
