# GitGalaxy

Code is art. Logic is art. Systems engineering is art.

GitGalaxy reveals the complexity of codebases as explorable 3D galaxies by using source code as a seed for procedural generative art. It acts as a Rosetta Stone for code complexity, allowing you to visually compare the scale and risk exposure of different projects—from Apollo 11 to the Linux Kernel—under the same set of rules.

> **Note:** This is a condensed version of the full documentation. For the 200-page Architectural Master Blueprint, please visit: [https://github.com/squid-protocol/gitgalaxy](https://github.com/squid-protocol/gitgalaxy)

---

## Quickstart

### 1. Install

```bash
pip install gitgalaxy
```

### 2. Scan a Repository

Point the GalaxyScope at any local repository or ZIP archive. The engine runs entirely on your local machine—zero data is transmitted.

```bash
gitgalaxy /path/to/your/repo
```

### 3. View the Galaxy

GitGalaxy offers two ways to visualize your 3D architecture, both built on a strict Zero-Trust Privacy Model where your code never leaves your machine.

**Option A: The Web Viewer (Frictionless)**
Simply drag and drop your generated "your_repo_galaxy.json" file (or a .zip of your raw repository) directly into GitGalaxy.io. All rendering and scanning happens entirely in your browser's local memory.

**Option B: The Local Server (Enterprise & Offline)**
For teams working behind strict corporate firewalls, you can host the 3D viewer locally. Clone the repository and spin up the included Flask server:

```bash
git clone https://github.com/squid-protocol/gitgalaxy.git
cd gitgalaxy
python app.py
```

Then open http://localhost:5000 in your browser and drop your JSON file in securely.

## What Does it Measure?

Traditional code analysis tools act like strict linguists. GitGalaxy functions as a sensor grid. We do not assess "Bad Code"; we measure Risk Exposure. By analyzing 9 independent metrics, we procedurally generate a 3D universe where:

* **Stars (Files):** Mass indicates Lines of Code (LOC).
* **Bioluminescence (Pulse):** Indicates inbound references and popularity.
* **Satellites (Functions):** Moons orbit their parent stars; orbital reach dictates function length.
* **Color Overlays:** Instantly highlight Cognitive Load (Purple), Tech Debt (Red), Churn (Orange), and API Exposure (Electric Rose).

## Zero-Trust Architecture

Your code never leaves your machine. GitGalaxy performs 100% of its scanning and vectorization locally.

* **No Data Transmission:** Source code is never transmitted to any API, cloud database, or third-party service.
* **Ephemeral Memory Processing:** Repositories are unpacked into a volatile memory buffer (RAM) and are automatically purged when the browser tab is closed.
* **Privacy-by-Design:** Even when using the web-based viewer, the data remains behind the user's firewall at all times.

## License & Copyright

Copyright (c) 2026 Joseph Michael Esquibel

GitGalaxy is released under the PolyForm Noncommercial License 1.0.0. It is completely free for personal use, research, experiment, testing, and hobby projects. Use by educational or charitable organizations is also permitted.

Any commercial use or integration into commercial SaaS products or corporate CI/CD pipelines requires a separate commercial license. Please reach out via gitgalaxy.io to discuss commercial integration.