"""YAML test suite parser."""

from __future__ import annotations

from pathlib import Path

import yaml

from .models import (
    Assertion,
    AssertionType,
    HttpMethod,
    LoadTestConfig,
    MockEndpoint,
    MockServerConfig,
    RequestConfig,
    TestSuite,
)


def parse_test_suite(file_path: str | Path) -> TestSuite:
    """Parse a YAML test suite file."""
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"Test suite file not found: {path}")

    with open(path, encoding="utf-8") as f:
        data = yaml.safe_load(f)

    if not isinstance(data, dict):
        raise ValueError("Invalid test suite format: expected YAML object")

    suite = TestSuite(
        name=data.get("name", path.stem),
        base_url=data.get("base_url", ""),
        variables=data.get("variables", {}),
        headers=data.get("headers", {}),
    )

    for req_data in data.get("requests", []):
        suite.requests.append(_parse_request(req_data))

    return suite


def _parse_request(data: dict) -> RequestConfig:
    """Parse a single request configuration."""
    method_str = data.get("method", "GET").upper()
    try:
        method = HttpMethod(method_str)
    except ValueError:
        method = HttpMethod.GET

    config = RequestConfig(
        name=data.get("name", "Unnamed Request"),
        url=data.get("url", ""),
        method=method,
        headers=data.get("headers", {}),
        body=data.get("body"),
        timeout=data.get("timeout", 30.0),
        variables=data.get("variables", {}),
        depends_on=data.get("depends_on"),
    )

    # Parse assertions
    for assertion_data in data.get("assertions", []):
        config.assertions.append(_parse_assertion(assertion_data))

    return config


def _parse_assertion(data: dict) -> Assertion:
    """Parse a single assertion."""
    type_str = data.get("type", "status").lower()
    try:
        assertion_type = AssertionType(type_str)
    except ValueError:
        assertion_type = AssertionType.STATUS

    return Assertion(
        type=assertion_type,
        expected=data.get("expected", data.get("value")),
        path=data.get("path", data.get("header")),
    )


def parse_load_test_config(file_path: str | Path) -> LoadTestConfig:
    """Parse a YAML load test configuration file."""
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"Load test config file not found: {path}")

    with open(path, encoding="utf-8") as f:
        data = yaml.safe_load(f)

    method_str = data.get("method", "GET").upper()
    try:
        method = HttpMethod(method_str)
    except ValueError:
        method = HttpMethod.GET

    return LoadTestConfig(
        url=data.get("url", ""),
        method=method,
        headers=data.get("headers", {}),
        body=data.get("body"),
        concurrency=data.get("concurrency", 10),
        requests_per_second=data.get("requests_per_second", 0),
        duration_seconds=data.get("duration_seconds", 10),
        timeout=data.get("timeout", 30.0),
    )


def parse_mock_config(file_path: str | Path) -> MockServerConfig:
    """Parse a YAML mock server configuration file."""
    path = Path(file_path)
    if not path.exists():
        raise FileNotFoundError(f"Mock config file not found: {path}")

    with open(path, encoding="utf-8") as f:
        data = yaml.safe_load(f)

    config = MockServerConfig(
        name=data.get("name", "api-forge-mock"),
        host=data.get("host", "127.0.0.1"),
        port=data.get("port", 8000),
        default_status=data.get("default_status", 404),
        default_body=data.get("default_body", '{"error": "Not Found"}'),
        cors=data.get("cors", True),
    )

    for ep_data in data.get("endpoints", []):
        config.endpoints.append(_parse_mock_endpoint(ep_data))

    return config


def _parse_mock_endpoint(data: dict) -> MockEndpoint:
    """Parse a single mock endpoint."""
    method_str = data.get("method", "GET").upper()
    try:
        method = HttpMethod(method_str)
    except ValueError:
        method = HttpMethod.GET

    body = data.get("body", "")
    if isinstance(body, dict):
        import json

        body = json.dumps(body)

    return MockEndpoint(
        path=data.get("path", "/"),
        method=method,
        status_code=data.get("status", 200),
        headers=data.get("headers", {}),
        body=body,
        delay_ms=data.get("delay_ms", 0),
        match_headers=data.get("match_headers", {}),
        match_body=data.get("match_body"),
    )


def generate_example_suite() -> str:
    """Generate an example test suite YAML."""
    return """# API Test Suite Example
name: "User API Tests"
base_url: "https://jsonplaceholder.typicode.com"

# Global headers applied to all requests
headers:
  Content-Type: "application/json"
  Accept: "application/json"

# Global variables
variables:
  api_version: "v1"

requests:
  - name: "Get all users"
    url: "/users"
    method: GET
    assertions:
      - type: status
        expected: 200
      - type: response_time
        expected: 2000
      - type: body_contains
        expected: '"email"'

  - name: "Get single user"
    url: "/users/1"
    method: GET
    assertions:
      - type: status
        expected: 200
      - type: json_path
        path: "id"
        expected: 1
    variables:
      user_name: "name"  # Extract name for next request

  - name: "Create post"
    url: "/posts"
    method: POST
    headers:
      X-Custom-Header: "test"
    body:
      title: "Test Post"
      body: "This is a test"
      userId: 1
    assertions:
      - type: status
        expected: 201
      - type: json_path
        path: "id"
        expected: 101
"""


def generate_example_load_test() -> str:
    """Generate an example load test YAML."""
    return """# Load Test Configuration
url: "https://jsonplaceholder.typicode.com/posts/1"
method: GET

# Concurrency settings
concurrency: 50
requests_per_second: 100  # 0 = unlimited
duration_seconds: 30

# Request configuration
timeout: 10.0
headers:
  Accept: "application/json"
"""


def generate_example_mock_config() -> str:
    """Generate an example mock server YAML."""
    return """# Mock Server Configuration
name: "Test API Mock"
host: "127.0.0.1"
port: 8000
cors: true

# Default response for unmatched routes
default_status: 404
default_body: '{"error": "Not Found"}'

endpoints:
  - path: "/health"
    method: GET
    status: 200
    body:
      status: "healthy"
      version: "1.0.0"

  - path: "/users"
    method: GET
    status: 200
    headers:
      X-Total-Count: "100"
    body:
      - id: 1
        name: "Alice"
        email: "alice@example.com"
      - id: 2
        name: "Bob"
        email: "bob@example.com"

  - path: "/users"
    method: POST
    status: 201
    body:
      id: 3
      message: "User created"

  - path: "/slow"
    method: GET
    status: 200
    delay_ms: 2000  # Simulate slow response
    body:
      message: "This took a while"

  - path: "/error"
    method: GET
    status: 500
    body:
      error: "Internal Server Error"
"""
