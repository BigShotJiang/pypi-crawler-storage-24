"""HTTP client for API testing."""

from __future__ import annotations

import asyncio
import json
import time

import httpx

from .models import (
    LoadTestConfig,
    LoadTestResult,
    RequestConfig,
    RequestResult,
    TestSuite,
    TestSuiteResult,
)


async def execute_request(
    config: RequestConfig,
    base_url: str = "",
    global_headers: dict[str, str] | None = None,
    variables: dict[str, str] | None = None,
) -> RequestResult:
    """Execute a single API request."""
    # Resolve URL
    url = config.url
    if base_url and not url.startswith(("http://", "https://")):
        url = f"{base_url.rstrip('/')}/{url.lstrip('/')}"

    # Variable substitution
    all_vars = {**(variables or {}), **config.variables}
    url = _substitute_variables(url, all_vars)

    # Merge headers
    headers = {**(global_headers or {}), **config.headers}
    headers = {k: _substitute_variables(v, all_vars) for k, v in headers.items()}

    # Prepare body
    body = config.body
    if isinstance(body, dict):
        body = json.dumps(body)
    elif isinstance(body, str):
        body = _substitute_variables(body, all_vars)

    start = time.perf_counter()
    result = RequestResult(
        name=config.name,
        url=url,
        method=config.method.value,
        status_code=0,
        headers={},
        body="",
        duration_ms=0.0,
    )

    try:
        async with httpx.AsyncClient(timeout=config.timeout, follow_redirects=True) as client:
            response = await client.request(
                method=config.method.value,
                url=url,
                headers=headers,
                content=body,
            )

            result.status_code = response.status_code
            result.headers = dict(response.headers)
            result.body = response.text

    except httpx.TimeoutException:
        result.error = "Request timed out"
    except httpx.ConnectError as e:
        result.error = f"Connection failed: {e}"
    except Exception as e:
        result.error = f"Request failed: {e}"

    result.duration_ms = (time.perf_counter() - start) * 1000

    # Run assertions
    for assertion in config.assertions:
        assertion.evaluate(result)
        result.assertions.append(assertion)

    return result


async def run_test_suite(suite: TestSuite) -> TestSuiteResult:
    """Run all tests in a test suite."""
    start = time.perf_counter()
    result = TestSuiteResult(name=suite.name)

    variables = dict(suite.variables)

    for request in suite.requests:
        req_result = await execute_request(
            request,
            base_url=suite.base_url,
            global_headers=suite.headers,
            variables=variables,
        )
        result.results.append(req_result)

        # Extract variables from response for chaining
        for var_name, json_path in request.variables.items():
            from .models import _json_path_extract

            extracted = _json_path_extract(req_result.body, json_path)
            if extracted is not None:
                variables[var_name] = str(extracted)

    result.total_duration_ms = (time.perf_counter() - start) * 1000
    return result


async def run_load_test(config: LoadTestConfig) -> LoadTestResult:
    """Run a load test against an endpoint."""
    result = LoadTestResult(config=config)
    start = time.perf_counter()
    end_time = start + config.duration_seconds

    # Prepare body
    body = config.body
    if isinstance(body, dict):
        body = json.dumps(body)

    semaphore = asyncio.Semaphore(config.concurrency)
    tasks: list[asyncio.Task] = []

    async def make_request() -> tuple[int, float, str | None]:
        async with semaphore:
            req_start = time.perf_counter()
            try:
                async with httpx.AsyncClient(timeout=config.timeout) as client:
                    response = await client.request(
                        method=config.method.value,
                        url=config.url,
                        headers=config.headers,
                        content=body,
                    )
                    duration_ms = (time.perf_counter() - req_start) * 1000
                    return response.status_code, duration_ms, None
            except Exception as e:
                duration_ms = (time.perf_counter() - req_start) * 1000
                return 0, duration_ms, str(e)

    # Generate requests until duration expires
    request_count = 0
    delay = 1.0 / config.requests_per_second if config.requests_per_second > 0 else 0

    while time.perf_counter() < end_time:
        tasks.append(asyncio.create_task(make_request()))
        request_count += 1

        if delay > 0:
            await asyncio.sleep(delay)
        else:
            # Batch to avoid overwhelming event loop
            if request_count % 100 == 0:
                await asyncio.sleep(0.001)

    # Wait for all requests to complete
    responses = await asyncio.gather(*tasks, return_exceptions=True)

    result.duration_seconds = time.perf_counter() - start

    for resp in responses:
        if isinstance(resp, Exception):
            result.failed_requests += 1
            result.errors.append(str(resp))
            continue

        status, latency, error = resp
        result.total_requests += 1
        result.latencies_ms.append(latency)

        if error:
            result.failed_requests += 1
            if len(result.errors) < 10:  # Cap error samples
                result.errors.append(error)
        else:
            result.successful_requests += 1
            result.status_codes[status] = result.status_codes.get(status, 0) + 1

    return result


def _substitute_variables(text: str, variables: dict[str, str]) -> str:
    """Replace {{var}} placeholders with variable values."""
    import re

    def replacer(match: re.Match) -> str:
        var_name = match.group(1)
        return variables.get(var_name, match.group(0))

    return re.sub(r"\{\{(\w+)\}\}", replacer, text)
