"""Data models for api-forge."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class HttpMethod(str, Enum):
    """HTTP methods."""

    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"
    HEAD = "HEAD"
    OPTIONS = "OPTIONS"


class AssertionType(str, Enum):
    """Types of assertions for response validation."""

    STATUS = "status"
    HEADER = "header"
    BODY_CONTAINS = "body_contains"
    BODY_JSON_PATH = "json_path"
    BODY_REGEX = "body_regex"
    RESPONSE_TIME = "response_time"


@dataclass
class Assertion:
    """A single assertion to validate a response."""

    type: AssertionType
    expected: Any
    path: str | None = None  # For JSON path or header name
    actual: Any = None
    passed: bool = False
    message: str = ""

    def evaluate(self, response: "RequestResult") -> None:
        """Evaluate this assertion against a response."""
        import re

        try:
            if self.type == AssertionType.STATUS:
                self.actual = response.status_code
                if isinstance(self.expected, list):
                    self.passed = self.actual in self.expected
                else:
                    self.passed = self.actual == self.expected
                self.message = f"Status {self.actual}" + ("" if self.passed else f" != expected {self.expected}")

            elif self.type == AssertionType.HEADER:
                self.actual = response.headers.get(self.path or "", "")
                self.passed = self.expected.lower() in self.actual.lower() if self.actual else False
                self.message = f"Header '{self.path}': '{self.actual}'" + ("" if self.passed else f" != expected '{self.expected}'")

            elif self.type == AssertionType.BODY_CONTAINS:
                self.actual = self.expected in response.body
                self.passed = self.actual
                self.message = f"Body contains '{self.expected}'" if self.passed else f"Body does not contain '{self.expected}'"

            elif self.type == AssertionType.BODY_JSON_PATH:
                self.actual = _json_path_extract(response.body, self.path or "")
                self.passed = self.actual == self.expected
                self.message = f"JSON path '{self.path}' = {self.actual}" + ("" if self.passed else f" != expected {self.expected}")

            elif self.type == AssertionType.BODY_REGEX:
                match = re.search(self.expected, response.body)
                self.actual = match.group(0) if match else None
                self.passed = match is not None
                self.message = f"Regex '{self.expected}' " + ("matched" if self.passed else "not found")

            elif self.type == AssertionType.RESPONSE_TIME:
                self.actual = response.duration_ms
                self.passed = self.actual <= self.expected
                self.message = f"Response time {self.actual:.0f}ms" + ("" if self.passed else f" > max {self.expected}ms")

        except Exception as e:
            self.passed = False
            self.message = f"Assertion error: {e}"


def _json_path_extract(body: str, path: str) -> Any:
    """Extract value from JSON body using dot notation path.

    Example: "user.name" extracts {"user": {"name": "value"}} → "value"
    """
    import json

    try:
        data = json.loads(body)
    except json.JSONDecodeError:
        return None

    parts = path.split(".")
    current = data
    for part in parts:
        if isinstance(current, dict):
            current = current.get(part)
        elif isinstance(current, list):
            try:
                idx = int(part)
                current = current[idx] if 0 <= idx < len(current) else None
            except ValueError:
                return None
        else:
            return None
        if current is None:
            return None
    return current


@dataclass
class RequestConfig:
    """Configuration for a single API request."""

    name: str
    url: str
    method: HttpMethod = HttpMethod.GET
    headers: dict[str, str] = field(default_factory=dict)
    body: str | dict | None = None
    timeout: float = 30.0
    assertions: list[Assertion] = field(default_factory=list)
    variables: dict[str, str] = field(default_factory=dict)  # Variables to extract from response
    depends_on: str | None = None  # Name of request this depends on


@dataclass
class RequestResult:
    """Result of a single API request."""

    name: str
    url: str
    method: str
    status_code: int
    headers: dict[str, str]
    body: str
    duration_ms: float
    error: str | None = None
    assertions: list[Assertion] = field(default_factory=list)

    @property
    def success(self) -> bool:
        """Request succeeded (no error and all assertions passed)."""
        if self.error:
            return False
        if not self.assertions:
            return 200 <= self.status_code < 400
        return all(a.passed for a in self.assertions)

    @property
    def failed_assertions(self) -> list[Assertion]:
        """Get list of failed assertions."""
        return [a for a in self.assertions if not a.passed]


@dataclass
class TestSuite:
    """A collection of API tests."""

    name: str
    base_url: str = ""
    requests: list[RequestConfig] = field(default_factory=list)
    variables: dict[str, str] = field(default_factory=dict)  # Global variables
    headers: dict[str, str] = field(default_factory=dict)  # Default headers for all requests


@dataclass
class TestSuiteResult:
    """Results of running a test suite."""

    name: str
    results: list[RequestResult] = field(default_factory=list)
    total_duration_ms: float = 0.0

    @property
    def total(self) -> int:
        return len(self.results)

    @property
    def passed(self) -> int:
        return sum(1 for r in self.results if r.success)

    @property
    def failed(self) -> int:
        return self.total - self.passed

    @property
    def success_rate(self) -> float:
        return (self.passed / self.total * 100) if self.total else 0.0


@dataclass
class LoadTestConfig:
    """Configuration for load testing."""

    url: str
    method: HttpMethod = HttpMethod.GET
    headers: dict[str, str] = field(default_factory=dict)
    body: str | dict | None = None
    concurrency: int = 10
    requests_per_second: int = 0  # 0 = as fast as possible
    duration_seconds: int = 10
    timeout: float = 30.0


@dataclass
class LoadTestResult:
    """Results of a load test run."""

    config: LoadTestConfig
    total_requests: int = 0
    successful_requests: int = 0
    failed_requests: int = 0
    latencies_ms: list[float] = field(default_factory=list)
    status_codes: dict[int, int] = field(default_factory=dict)
    errors: list[str] = field(default_factory=list)
    duration_seconds: float = 0.0

    @property
    def requests_per_second(self) -> float:
        return self.total_requests / self.duration_seconds if self.duration_seconds > 0 else 0.0

    @property
    def avg_latency_ms(self) -> float:
        return sum(self.latencies_ms) / len(self.latencies_ms) if self.latencies_ms else 0.0

    @property
    def min_latency_ms(self) -> float:
        return min(self.latencies_ms) if self.latencies_ms else 0.0

    @property
    def max_latency_ms(self) -> float:
        return max(self.latencies_ms) if self.latencies_ms else 0.0

    @property
    def p50_latency_ms(self) -> float:
        return _percentile(self.latencies_ms, 50)

    @property
    def p95_latency_ms(self) -> float:
        return _percentile(self.latencies_ms, 95)

    @property
    def p99_latency_ms(self) -> float:
        return _percentile(self.latencies_ms, 99)

    @property
    def success_rate(self) -> float:
        return (self.successful_requests / self.total_requests * 100) if self.total_requests else 0.0

    @property
    def error_rate(self) -> float:
        return 100.0 - self.success_rate


def _percentile(values: list[float], p: int) -> float:
    """Calculate the p-th percentile of values."""
    if not values:
        return 0.0
    sorted_vals = sorted(values)
    idx = int(len(sorted_vals) * p / 100)
    idx = min(idx, len(sorted_vals) - 1)
    return sorted_vals[idx]


@dataclass
class MockEndpoint:
    """Configuration for a mock endpoint."""

    path: str
    method: HttpMethod = HttpMethod.GET
    status_code: int = 200
    headers: dict[str, str] = field(default_factory=dict)
    body: str | dict = ""
    delay_ms: int = 0  # Simulate latency
    match_headers: dict[str, str] = field(default_factory=dict)  # Request must have these headers
    match_body: str | None = None  # Request body must contain this


@dataclass
class MockServerConfig:
    """Configuration for a mock server."""

    name: str = "api-forge-mock"
    host: str = "127.0.0.1"
    port: int = 8000
    endpoints: list[MockEndpoint] = field(default_factory=list)
    default_status: int = 404
    default_body: str = '{"error": "Not Found"}'
    cors: bool = True
