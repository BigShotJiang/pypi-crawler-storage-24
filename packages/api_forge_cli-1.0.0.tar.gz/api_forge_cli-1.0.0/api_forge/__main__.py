"""Allow running as python -m api_forge."""

from api_forge.cli import cli

if __name__ == "__main__":
    cli()
