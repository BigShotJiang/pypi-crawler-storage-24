"""Mock HTTP server for API testing."""

from __future__ import annotations

import json
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
from threading import Thread
from typing import Any

from .models import MockEndpoint, MockServerConfig


class MockHandler(BaseHTTPRequestHandler):
    """HTTP request handler for mock server."""

    server_config: MockServerConfig

    def log_message(self, format: str, *args: Any) -> None:
        """Suppress default logging."""
        pass

    def _handle_request(self, method: str) -> None:
        """Handle an incoming request."""
        config = self.server_config
        path = self.path.split("?")[0]  # Remove query string

        # Read request body if present
        content_length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(content_length).decode("utf-8") if content_length > 0 else ""

        # Find matching endpoint
        endpoint = self._find_endpoint(path, method, body)

        if endpoint:
            # Simulate latency
            if endpoint.delay_ms > 0:
                time.sleep(endpoint.delay_ms / 1000)

            self._send_response(endpoint.status_code, endpoint.headers, endpoint.body)
        else:
            self._send_response(config.default_status, {}, config.default_body)

    def _find_endpoint(self, path: str, method: str, body: str) -> MockEndpoint | None:
        """Find a matching mock endpoint."""
        for ep in self.server_config.endpoints:
            # Check path match
            if not self._path_matches(path, ep.path):
                continue

            # Check method match
            if ep.method.value != method:
                continue

            # Check header requirements
            if ep.match_headers:
                headers_match = all(self.headers.get(k, "").lower() == v.lower() for k, v in ep.match_headers.items())
                if not headers_match:
                    continue

            # Check body requirements
            if ep.match_body and ep.match_body not in body:
                continue

            return ep

        return None

    def _path_matches(self, request_path: str, pattern: str) -> bool:
        """Check if request path matches the pattern.

        Supports simple wildcards: /users/* matches /users/123
        """
        if pattern == request_path:
            return True

        if "*" in pattern:
            pattern_parts = pattern.split("/")
            request_parts = request_path.split("/")

            if len(pattern_parts) != len(request_parts):
                return False

            for pp, rp in zip(pattern_parts, request_parts):
                if pp != "*" and pp != rp:
                    return False
            return True

        return False

    def _send_response(self, status: int, headers: dict[str, str], body: str | dict) -> None:
        """Send HTTP response."""
        self.send_response(status)

        # CORS headers if enabled
        if self.server_config.cors:
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "*")

        # Custom headers
        for key, value in headers.items():
            self.send_header(key, value)

        # Default content-type
        if "Content-Type" not in headers:
            self.send_header("Content-Type", "application/json")

        self.end_headers()

        # Body
        if isinstance(body, dict):
            body = json.dumps(body)
        self.wfile.write(body.encode("utf-8"))

    def do_GET(self) -> None:
        self._handle_request("GET")

    def do_POST(self) -> None:
        self._handle_request("POST")

    def do_PUT(self) -> None:
        self._handle_request("PUT")

    def do_PATCH(self) -> None:
        self._handle_request("PATCH")

    def do_DELETE(self) -> None:
        self._handle_request("DELETE")

    def do_HEAD(self) -> None:
        self._handle_request("HEAD")

    def do_OPTIONS(self) -> None:
        """Handle CORS preflight requests."""
        self.send_response(200)
        if self.server_config.cors:
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, PUT, PATCH, DELETE, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "*")
        self.end_headers()


class MockServer:
    """Mock HTTP server for API testing."""

    def __init__(self, config: MockServerConfig):
        self.config = config
        self._server: HTTPServer | None = None
        self._thread: Thread | None = None

    def start(self) -> None:
        """Start the mock server in a background thread."""
        handler_class = type("ConfiguredMockHandler", (MockHandler,), {"server_config": self.config})
        self._server = HTTPServer((self.config.host, self.config.port), handler_class)
        self._thread = Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        """Stop the mock server."""
        if self._server:
            self._server.shutdown()
            self._server = None
        if self._thread:
            self._thread.join(timeout=1)
            self._thread = None

    @property
    def url(self) -> str:
        """Get the mock server URL."""
        return f"http://{self.config.host}:{self.config.port}"

    def __enter__(self) -> "MockServer":
        self.start()
        return self

    def __exit__(self, *args: Any) -> None:
        self.stop()


def run_mock_server_blocking(config: MockServerConfig) -> None:
    """Run the mock server in blocking mode (for CLI use)."""
    handler_class = type("ConfiguredMockHandler", (MockHandler,), {"server_config": config})
    server = HTTPServer((config.host, config.port), handler_class)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.shutdown()
