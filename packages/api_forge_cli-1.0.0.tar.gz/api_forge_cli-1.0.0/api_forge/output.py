"""Rich console output for api-forge."""

from __future__ import annotations

from rich import box
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from .models import LoadTestResult, RequestResult, TestSuiteResult

console = Console()


def render_request_result(result: RequestResult) -> None:
    """Render a single request result."""
    status_color = "green" if result.success else "red"
    status_icon = "✓" if result.success else "✗"

    # Header
    console.print(f"  [{status_color}]{status_icon}[/] [bold]{result.name}[/]")
    console.print(f"    [dim]{result.method} {result.url}[/]")

    if result.error:
        console.print(f"    [red]Error: {result.error}[/]")
    else:
        console.print(f"    [dim]Status: {result.status_code} | Time: {result.duration_ms:.0f}ms[/]")

    # Assertions
    if result.assertions:
        for a in result.assertions:
            a_color = "green" if a.passed else "red"
            a_icon = "✓" if a.passed else "✗"
            console.print(f"      [{a_color}]{a_icon}[/] {a.message}")

    console.print()


def render_test_suite_result(result: TestSuiteResult) -> None:
    """Render full test suite results."""
    console.print()

    # Header
    header = Panel(
        Text.from_markup(f"[bold]🔧 API Test Suite: {result.name}[/]"),
        box=box.ROUNDED,
        padding=(0, 2),
    )
    console.print(header)
    console.print()

    # Individual results
    for req_result in result.results:
        render_request_result(req_result)

    # Summary
    passed_color = "green" if result.passed == result.total else "yellow"
    failed_color = "red" if result.failed > 0 else "dim"

    summary = Table(show_header=False, box=None, padding=(0, 2))
    summary.add_column()
    summary.add_column(justify="right")

    summary.add_row("[bold]Total Requests[/]", str(result.total))
    summary.add_row(f"[{passed_color}]Passed[/]", f"[{passed_color}]{result.passed}[/]")
    summary.add_row(f"[{failed_color}]Failed[/]", f"[{failed_color}]{result.failed}[/]")
    summary.add_row("[dim]Duration[/]", f"[dim]{result.total_duration_ms:.0f}ms[/]")
    summary.add_row("[bold]Success Rate[/]", f"[bold]{result.success_rate:.1f}%[/]")

    console.print(Panel(summary, title="Summary", box=box.ROUNDED))


def render_load_test_result(result: LoadTestResult) -> None:
    """Render load test results."""
    console.print()

    # Header
    header = Panel(
        Text.from_markup(f"[bold]⚡ Load Test Results[/]\n[dim]{result.config.method.value} {result.config.url}[/]"),
        box=box.ROUNDED,
        padding=(0, 2),
    )
    console.print(header)
    console.print()

    # Main metrics
    metrics = Table(show_header=False, box=None, padding=(0, 2))
    metrics.add_column(width=20)
    metrics.add_column(justify="right")

    success_color = "green" if result.success_rate >= 99 else ("yellow" if result.success_rate >= 95 else "red")

    metrics.add_row("[bold]Total Requests[/]", f"{result.total_requests:,}")
    metrics.add_row(f"[{success_color}]Successful[/]", f"[{success_color}]{result.successful_requests:,}[/]")
    metrics.add_row("[red]Failed[/]" if result.failed_requests else "[dim]Failed[/]", f"[red]{result.failed_requests:,}[/]" if result.failed_requests else f"[dim]{result.failed_requests}[/]")
    metrics.add_row("[bold]Duration[/]", f"{result.duration_seconds:.1f}s")
    metrics.add_row("[bold]Requests/sec[/]", f"[cyan]{result.requests_per_second:.1f}[/]")
    metrics.add_row(f"[{success_color}]Success Rate[/]", f"[{success_color}]{result.success_rate:.2f}%[/]")

    console.print(Panel(metrics, title="Overview", box=box.ROUNDED))
    console.print()

    # Latency stats
    if result.latencies_ms:
        latency = Table(show_header=False, box=None, padding=(0, 2))
        latency.add_column(width=20)
        latency.add_column(justify="right")

        latency.add_row("[dim]Min[/]", f"[dim]{result.min_latency_ms:.1f}ms[/]")
        latency.add_row("[bold]Average[/]", f"{result.avg_latency_ms:.1f}ms")
        latency.add_row("[bold]P50 (Median)[/]", f"{result.p50_latency_ms:.1f}ms")
        latency.add_row("[yellow]P95[/]", f"[yellow]{result.p95_latency_ms:.1f}ms[/]")
        latency.add_row("[red]P99[/]", f"[red]{result.p99_latency_ms:.1f}ms[/]")
        latency.add_row("[dim]Max[/]", f"[dim]{result.max_latency_ms:.1f}ms[/]")

        console.print(Panel(latency, title="Latency", box=box.ROUNDED))
        console.print()

    # Status codes
    if result.status_codes:
        status_table = Table(show_header=True, box=box.SIMPLE)
        status_table.add_column("Status", style="bold")
        status_table.add_column("Count", justify="right")
        status_table.add_column("Percent", justify="right")

        for status, count in sorted(result.status_codes.items()):
            pct = count / result.total_requests * 100
            color = "green" if 200 <= status < 300 else ("yellow" if 300 <= status < 400 else "red")
            status_table.add_row(f"[{color}]{status}[/]", f"{count:,}", f"{pct:.1f}%")

        console.print(Panel(status_table, title="Status Codes", box=box.ROUNDED))
        console.print()

    # Errors
    if result.errors:
        console.print(Panel(f"[red]Sample Errors ({len(result.errors)} shown):[/]\n" + "\n".join(f"  • {e}" for e in result.errors[:5]), title="Errors", box=box.ROUNDED, border_style="red"))


def render_quick_request(result: RequestResult) -> None:
    """Render a quick/single request result."""
    console.print()

    status_color = "green" if 200 <= result.status_code < 300 else ("yellow" if 300 <= result.status_code < 400 else "red")

    header = Text()
    header.append(f"{result.method} ", style="bold")
    header.append(result.url, style="dim")

    console.print(Panel(header, box=box.ROUNDED))
    console.print()

    # Status line
    console.print(f"  Status: [{status_color}][bold]{result.status_code}[/][/]")
    console.print(f"  Time:   [cyan]{result.duration_ms:.0f}ms[/]")

    if result.error:
        console.print(f"  [red]Error: {result.error}[/]")
        return

    # Headers (selected)
    if result.headers:
        console.print("\n  [bold]Headers:[/]")
        important_headers = ["content-type", "content-length", "cache-control", "x-request-id", "x-response-time"]
        for h in important_headers:
            if h in result.headers:
                console.print(f"    [dim]{h}:[/] {result.headers[h]}")

    # Body preview
    if result.body:
        console.print("\n  [bold]Body:[/]")
        body_preview = result.body[:500]
        if len(result.body) > 500:
            body_preview += "..."

        # Try to pretty-print JSON
        import json

        try:
            parsed = json.loads(result.body)
            body_preview = json.dumps(parsed, indent=2)[:500]
            if len(json.dumps(parsed, indent=2)) > 500:
                body_preview += "\n..."
        except json.JSONDecodeError:
            pass

        for line in body_preview.split("\n"):
            console.print(f"    [dim]{line}[/]")

    console.print()
