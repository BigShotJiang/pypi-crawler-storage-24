"""api-forge — API Testing & Mock Server CLI."""

__version__ = "1.0.0"
