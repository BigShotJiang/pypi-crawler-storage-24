"""CLI entry point for api-forge."""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

import click

from . import __version__
from .client import execute_request, run_load_test, run_test_suite
from .mock_server import run_mock_server_blocking
from .models import (
    HttpMethod,
    LoadTestConfig,
    MockServerConfig,
    RequestConfig,
)
from .output import (
    console,
    render_load_test_result,
    render_quick_request,
    render_test_suite_result,
)
from .parser import (
    generate_example_load_test,
    generate_example_mock_config,
    generate_example_suite,
    parse_load_test_config,
    parse_mock_config,
    parse_test_suite,
)


@click.group()
@click.version_option(__version__, prog_name="api-forge")
def cli():
    """🔧 api-forge — API Testing & Mock Server CLI.

    Test APIs, run load tests, and create mock servers from YAML
    configuration files.

    Examples:

        api-forge test suite.yaml

        api-forge load config.yaml

        api-forge mock mock.yaml

        api-forge get https://api.example.com/users
    """


@cli.command("test")
@click.argument("file", type=click.Path(exists=True))
@click.option("--verbose", "-v", is_flag=True, help="Show detailed output")
def test_cmd(file: str, verbose: bool):
    """Run API tests from a YAML test suite.

    Examples:

        api-forge test suite.yaml

        api-forge test tests/api-tests.yaml -v
    """
    try:
        suite = parse_test_suite(file)
    except Exception as e:
        console.print(f"[red]Failed to parse test suite: {e}[/]")
        sys.exit(1)

    console.print(f"[dim]Running test suite: {suite.name}[/]")

    result = asyncio.run(run_test_suite(suite))
    render_test_suite_result(result)

    if result.failed > 0:
        sys.exit(1)


@cli.command("load")
@click.argument("target", required=False)
@click.option("--config", "-c", type=click.Path(exists=True), help="Load test config YAML file")
@click.option("--concurrency", "-n", default=10, help="Number of concurrent connections")
@click.option("--duration", "-d", default=10, help="Test duration in seconds")
@click.option("--rps", default=0, help="Requests per second (0 = unlimited)")
def load_cmd(target: str | None, config: str | None, concurrency: int, duration: int, rps: int):
    """Run load tests against an API endpoint.

    Examples:

        api-forge load https://api.example.com/health

        api-forge load -c loadtest.yaml

        api-forge load https://api.example.com/users -n 50 -d 30
    """
    if config:
        try:
            load_config = parse_load_test_config(config)
        except Exception as e:
            console.print(f"[red]Failed to parse config: {e}[/]")
            sys.exit(1)
    elif target:
        load_config = LoadTestConfig(
            url=target,
            concurrency=concurrency,
            duration_seconds=duration,
            requests_per_second=rps,
        )
    else:
        console.print("[red]Please provide a URL or --config file[/]")
        sys.exit(1)

    console.print(f"[dim]Starting load test: {load_config.url}[/]")
    console.print(f"[dim]Concurrency: {load_config.concurrency} | Duration: {load_config.duration_seconds}s[/]\n")

    result = asyncio.run(run_load_test(load_config))
    render_load_test_result(result)


@cli.command("mock")
@click.argument("file", type=click.Path(exists=True), required=False)
@click.option("--port", "-p", default=8000, help="Server port")
@click.option("--host", "-h", "host", default="127.0.0.1", help="Server host")
def mock_cmd(file: str | None, port: int, host: str):
    """Start a mock API server from YAML configuration.

    Examples:

        api-forge mock mock.yaml

        api-forge mock mock.yaml -p 3000

        api-forge mock  # Starts default server on :8000
    """
    if file:
        try:
            config = parse_mock_config(file)
            config.port = port  # CLI override
            config.host = host
        except Exception as e:
            console.print(f"[red]Failed to parse mock config: {e}[/]")
            sys.exit(1)
    else:
        # Default mock server
        config = MockServerConfig(host=host, port=port)

    console.print(f"[bold green]🚀 Mock server running at http://{config.host}:{config.port}[/]")
    console.print(f"[dim]Endpoints: {len(config.endpoints)}[/]")
    console.print("[dim]Press Ctrl+C to stop[/]\n")

    try:
        run_mock_server_blocking(config)
    except KeyboardInterrupt:
        console.print("\n[yellow]Server stopped[/]")


@cli.command("get")
@click.argument("url")
@click.option("--header", "-H", multiple=True, help="Headers (key:value)")
@click.option("--timeout", "-t", default=30.0, help="Request timeout")
def get_cmd(url: str, header: tuple, timeout: float):
    """Make a GET request to a URL.

    Examples:

        api-forge get https://api.example.com/users

        api-forge get https://api.example.com/users -H "Authorization:Bearer token"
    """
    _quick_request(url, HttpMethod.GET, header, None, timeout)


@cli.command("post")
@click.argument("url")
@click.option("--data", "-d", help="Request body (JSON string)")
@click.option("--header", "-H", multiple=True, help="Headers (key:value)")
@click.option("--timeout", "-t", default=30.0, help="Request timeout")
def post_cmd(url: str, data: str | None, header: tuple, timeout: float):
    """Make a POST request to a URL.

    Examples:

        api-forge post https://api.example.com/users -d '{"name":"Alice"}'

        api-forge post https://api.example.com/login -d '{"user":"admin"}' -H "Content-Type:application/json"
    """
    _quick_request(url, HttpMethod.POST, header, data, timeout)


@cli.command("put")
@click.argument("url")
@click.option("--data", "-d", help="Request body (JSON string)")
@click.option("--header", "-H", multiple=True, help="Headers (key:value)")
@click.option("--timeout", "-t", default=30.0, help="Request timeout")
def put_cmd(url: str, data: str | None, header: tuple, timeout: float):
    """Make a PUT request to a URL.

    Examples:

        api-forge put https://api.example.com/users/1 -d '{"name":"Bob"}'
    """
    _quick_request(url, HttpMethod.PUT, header, data, timeout)


@cli.command("delete")
@click.argument("url")
@click.option("--header", "-H", multiple=True, help="Headers (key:value)")
@click.option("--timeout", "-t", default=30.0, help="Request timeout")
def delete_cmd(url: str, header: tuple, timeout: float):
    """Make a DELETE request to a URL.

    Examples:

        api-forge delete https://api.example.com/users/1
    """
    _quick_request(url, HttpMethod.DELETE, header, None, timeout)


@cli.command("init")
@click.option("--type", "init_type", type=click.Choice(["test", "load", "mock"]), default="test", help="Type of config to generate")
@click.option("--output", "-o", help="Output file path")
def init_cmd(init_type: str, output: str | None):
    """Generate example configuration files.

    Examples:

        api-forge init --type test -o suite.yaml

        api-forge init --type load -o loadtest.yaml

        api-forge init --type mock -o mock.yaml
    """
    generators = {
        "test": ("test-suite.yaml", generate_example_suite),
        "load": ("load-test.yaml", generate_example_load_test),
        "mock": ("mock-server.yaml", generate_example_mock_config),
    }

    default_name, generator = generators[init_type]
    content = generator()
    output_path = output or default_name

    Path(output_path).write_text(content, encoding="utf-8")
    console.print(f"[green]Created {output_path}[/]")


def _quick_request(url: str, method: HttpMethod, headers: tuple, data: str | None, timeout: float) -> None:
    """Execute a quick HTTP request."""
    # Parse headers
    parsed_headers = {}
    for h in headers:
        if ":" in h:
            key, value = h.split(":", 1)
            parsed_headers[key.strip()] = value.strip()

    config = RequestConfig(
        name="Quick Request",
        url=url,
        method=method,
        headers=parsed_headers,
        body=data,
        timeout=timeout,
    )

    result = asyncio.run(execute_request(config))
    render_quick_request(result)

    if result.error or result.status_code >= 400:
        sys.exit(1)


if __name__ == "__main__":
    cli()
