"""Pytest fixtures for api-forge tests."""

from __future__ import annotations

import pytest

from api_forge.mock_server import MockServer
from api_forge.models import HttpMethod, MockEndpoint, MockServerConfig


@pytest.fixture(scope="session")
def mock_server():
    """Start a mock server for testing."""
    config = MockServerConfig(
        port=18000,
        endpoints=[
            MockEndpoint(
                path="/health",
                method=HttpMethod.GET,
                status_code=200,
                body='{"status": "healthy", "version": "1.0.0"}',
            ),
            MockEndpoint(
                path="/users",
                method=HttpMethod.GET,
                status_code=200,
                headers={"X-Total-Count": "2"},
                body='[{"id": 1, "name": "Alice"}, {"id": 2, "name": "Bob"}]',
            ),
            MockEndpoint(
                path="/users",
                method=HttpMethod.POST,
                status_code=201,
                body='{"id": 3, "message": "User created"}',
            ),
            MockEndpoint(
                path="/users/*",
                method=HttpMethod.GET,
                status_code=200,
                body='{"id": 1, "name": "Alice"}',
            ),
            MockEndpoint(
                path="/error",
                method=HttpMethod.GET,
                status_code=500,
                body='{"error": "Internal Server Error"}',
            ),
        ],
    )
    with MockServer(config) as server:
        yield server
