"""Tests for api_forge.cli — CLI commands."""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest
from click.testing import CliRunner

from api_forge.cli import cli

SAMPLE_TEST_SUITE = """
name: "CLI Test"
base_url: "http://127.0.0.1:18000"
requests:
  - name: "Health Check"
    url: "/health"
    method: GET
    assertions:
      - type: status
        expected: 200
"""


@pytest.fixture
def runner():
    return CliRunner()


class TestCliHelp:
    def test_main_help(self, runner):
        result = runner.invoke(cli, ["--help"])
        assert result.exit_code == 0
        assert "api-forge" in result.output.lower()

    def test_test_help(self, runner):
        result = runner.invoke(cli, ["test", "--help"])
        assert result.exit_code == 0

    def test_load_help(self, runner):
        result = runner.invoke(cli, ["load", "--help"])
        assert result.exit_code == 0

    def test_mock_help(self, runner):
        result = runner.invoke(cli, ["mock", "--help"])
        assert result.exit_code == 0

    def test_get_help(self, runner):
        result = runner.invoke(cli, ["get", "--help"])
        assert result.exit_code == 0

    def test_init_help(self, runner):
        result = runner.invoke(cli, ["init", "--help"])
        assert result.exit_code == 0


class TestInitCommand:
    def test_init_test_suite(self, runner):
        with tempfile.TemporaryDirectory() as d:
            result = runner.invoke(cli, ["init", "--type", "test", "-o", f"{d}/test.yaml"])
            assert result.exit_code == 0
            assert Path(f"{d}/test.yaml").exists()

    def test_init_load_test(self, runner):
        with tempfile.TemporaryDirectory() as d:
            result = runner.invoke(cli, ["init", "--type", "load", "-o", f"{d}/load.yaml"])
            assert result.exit_code == 0
            assert Path(f"{d}/load.yaml").exists()

    def test_init_mock_config(self, runner):
        with tempfile.TemporaryDirectory() as d:
            result = runner.invoke(cli, ["init", "--type", "mock", "-o", f"{d}/mock.yaml"])
            assert result.exit_code == 0
            assert Path(f"{d}/mock.yaml").exists()


class TestTestCommand:
    def test_run_test_suite(self, runner, mock_server):
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "test.yaml"
            f.write_text(SAMPLE_TEST_SUITE, encoding="utf-8")
            result = runner.invoke(cli, ["test", str(f)])
            assert result.exit_code == 0

    def test_test_file_not_found(self, runner):
        result = runner.invoke(cli, ["test", "/nonexistent/file.yaml"])
        assert result.exit_code != 0


class TestQuickRequests:
    def test_get_request(self, runner, mock_server):
        result = runner.invoke(cli, ["get", f"{mock_server.url}/health"])
        assert result.exit_code == 0

    def test_post_request(self, runner, mock_server):
        result = runner.invoke(cli, ["post", f"{mock_server.url}/users", "-d", '{"name": "Test"}'])
        assert result.exit_code == 0

    def test_get_with_header(self, runner, mock_server):
        result = runner.invoke(cli, ["get", f"{mock_server.url}/health", "-H", "Accept:application/json"])
        assert result.exit_code == 0

    def test_request_error(self, runner, mock_server):
        result = runner.invoke(cli, ["get", f"{mock_server.url}/error"])
        assert result.exit_code == 1  # 500 error should exit with 1
