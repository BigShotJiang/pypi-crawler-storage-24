"""Tests for api_forge.client — HTTP client functionality."""

from __future__ import annotations

import pytest

from api_forge.client import _substitute_variables, execute_request, run_test_suite
from api_forge.models import Assertion, AssertionType, HttpMethod, RequestConfig, TestSuite


class TestSubstituteVariables:
    def test_single_variable(self):
        result = _substitute_variables("Hello {{name}}!", {"name": "World"})
        assert result == "Hello World!"

    def test_multiple_variables(self):
        result = _substitute_variables("{{a}} and {{b}}", {"a": "foo", "b": "bar"})
        assert result == "foo and bar"

    def test_missing_variable(self):
        result = _substitute_variables("Hello {{name}}!", {})
        assert result == "Hello {{name}}!"

    def test_no_variables(self):
        result = _substitute_variables("No variables here", {"a": "b"})
        assert result == "No variables here"

    def test_url_with_variables(self):
        result = _substitute_variables("https://api.example.com/users/{{user_id}}/posts/{{post_id}}", {"user_id": "123", "post_id": "456"})
        assert result == "https://api.example.com/users/123/posts/456"


class TestExecuteRequest:
    @pytest.mark.asyncio
    async def test_request_with_mock_server(self, mock_server):
        """Test execute_request against a mock server."""
        config = RequestConfig(
            name="Test Request",
            url=f"{mock_server.url}/health",
            method=HttpMethod.GET,
        )
        result = await execute_request(config)
        assert result.status_code == 200
        assert result.error is None

    @pytest.mark.asyncio
    async def test_request_with_assertions(self, mock_server):
        """Test execute_request with assertions."""
        config = RequestConfig(
            name="Test Request",
            url=f"{mock_server.url}/health",
            method=HttpMethod.GET,
            assertions=[
                Assertion(type=AssertionType.STATUS, expected=200),
                Assertion(type=AssertionType.BODY_CONTAINS, expected="healthy"),
            ],
        )
        result = await execute_request(config)
        assert len(result.assertions) == 2
        assert all(a.passed for a in result.assertions)

    @pytest.mark.asyncio
    async def test_request_connection_error(self):
        """Test execute_request with connection error."""
        config = RequestConfig(
            name="Test Request",
            url="http://localhost:1",  # Invalid port
            method=HttpMethod.GET,
            timeout=1.0,
        )
        result = await execute_request(config)
        assert result.error is not None

    @pytest.mark.asyncio
    async def test_request_with_base_url(self, mock_server):
        """Test execute_request with base_url."""
        config = RequestConfig(
            name="Test Request",
            url="/health",
            method=HttpMethod.GET,
        )
        result = await execute_request(config, base_url=mock_server.url)
        assert result.status_code == 200

    @pytest.mark.asyncio
    async def test_request_with_variables(self, mock_server):
        """Test execute_request with variable substitution."""
        config = RequestConfig(
            name="Test Request",
            url="{{base}}/health",
            method=HttpMethod.GET,
        )
        result = await execute_request(config, variables={"base": mock_server.url})
        assert result.status_code == 200

    @pytest.mark.asyncio
    async def test_post_request(self, mock_server):
        """Test POST request."""
        config = RequestConfig(
            name="Test POST",
            url=f"{mock_server.url}/users",
            method=HttpMethod.POST,
            body={"name": "Alice"},
        )
        result = await execute_request(config)
        assert result.status_code == 201


class TestRunTestSuite:
    @pytest.mark.asyncio
    async def test_run_suite(self, mock_server):
        """Test running a complete test suite."""
        suite = TestSuite(
            name="Test Suite",
            base_url=mock_server.url,
            requests=[
                RequestConfig(name="Health Check", url="/health", method=HttpMethod.GET),
                RequestConfig(name="Get Users", url="/users", method=HttpMethod.GET),
            ],
        )
        result = await run_test_suite(suite)
        assert result.total == 2
        assert result.passed == 2

    @pytest.mark.asyncio
    async def test_suite_with_variables(self, mock_server):
        """Test test suite with global variables."""
        suite = TestSuite(
            name="Test Suite",
            variables={"base": mock_server.url},
            requests=[
                RequestConfig(name="Health Check", url="{{base}}/health", method=HttpMethod.GET),
            ],
        )
        result = await run_test_suite(suite)
        assert result.passed == 1

    @pytest.mark.asyncio
    async def test_suite_with_extracted_variables(self, mock_server):
        """Test variable extraction from response."""
        suite = TestSuite(
            name="Test Suite",
            base_url=mock_server.url,
            requests=[
                RequestConfig(
                    name="Get Users",
                    url="/users",
                    method=HttpMethod.GET,
                    variables={"first_user": "0.id"},  # Extract first user's id
                ),
            ],
        )
        result = await run_test_suite(suite)
        assert result.passed == 1
