"""Tests for api_forge.parser — YAML parsing."""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from api_forge.models import AssertionType, HttpMethod
from api_forge.parser import (
    generate_example_load_test,
    generate_example_mock_config,
    generate_example_suite,
    parse_load_test_config,
    parse_mock_config,
    parse_test_suite,
)

SAMPLE_TEST_SUITE = """
name: "Sample Tests"
base_url: "https://api.example.com"
headers:
  Authorization: "Bearer token"
variables:
  user_id: "123"
requests:
  - name: "Get User"
    url: "/users/{{user_id}}"
    method: GET
    assertions:
      - type: status
        expected: 200
      - type: json_path
        path: "id"
        expected: 123
  - name: "Create User"
    url: "/users"
    method: POST
    body:
      name: "Alice"
    assertions:
      - type: status
        expected: 201
"""

SAMPLE_LOAD_CONFIG = """
url: "https://api.example.com/health"
method: GET
concurrency: 20
duration_seconds: 15
requests_per_second: 50
timeout: 5.0
headers:
  Accept: "application/json"
"""

SAMPLE_MOCK_CONFIG = """
name: "Test Mock"
host: "0.0.0.0"
port: 9000
cors: false
endpoints:
  - path: "/health"
    method: GET
    status: 200
    body:
      status: "ok"
  - path: "/users"
    method: POST
    status: 201
    delay_ms: 100
"""


class TestParseTestSuite:
    def test_basic_parsing(self):
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "test.yaml"
            f.write_text(SAMPLE_TEST_SUITE, encoding="utf-8")
            suite = parse_test_suite(f)

            assert suite.name == "Sample Tests"
            assert suite.base_url == "https://api.example.com"
            assert "Authorization" in suite.headers
            assert len(suite.requests) == 2

    def test_request_parsing(self):
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "test.yaml"
            f.write_text(SAMPLE_TEST_SUITE, encoding="utf-8")
            suite = parse_test_suite(f)

            req = suite.requests[0]
            assert req.name == "Get User"
            assert req.method == HttpMethod.GET
            assert len(req.assertions) == 2

    def test_assertion_parsing(self):
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "test.yaml"
            f.write_text(SAMPLE_TEST_SUITE, encoding="utf-8")
            suite = parse_test_suite(f)

            assertions = suite.requests[0].assertions
            assert assertions[0].type == AssertionType.STATUS
            assert assertions[0].expected == 200
            assert assertions[1].type == AssertionType.BODY_JSON_PATH
            assert assertions[1].path == "id"

    def test_post_with_body(self):
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "test.yaml"
            f.write_text(SAMPLE_TEST_SUITE, encoding="utf-8")
            suite = parse_test_suite(f)

            req = suite.requests[1]
            assert req.method == HttpMethod.POST
            assert req.body == {"name": "Alice"}

    def test_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            parse_test_suite("/nonexistent/file.yaml")


class TestParseLoadTestConfig:
    def test_basic_parsing(self):
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "load.yaml"
            f.write_text(SAMPLE_LOAD_CONFIG, encoding="utf-8")
            config = parse_load_test_config(f)

            assert config.url == "https://api.example.com/health"
            assert config.method == HttpMethod.GET
            assert config.concurrency == 20
            assert config.duration_seconds == 15
            assert config.requests_per_second == 50
            assert config.timeout == 5.0
            assert "Accept" in config.headers

    def test_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            parse_load_test_config("/nonexistent/file.yaml")


class TestParseMockConfig:
    def test_basic_parsing(self):
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "mock.yaml"
            f.write_text(SAMPLE_MOCK_CONFIG, encoding="utf-8")
            config = parse_mock_config(f)

            assert config.name == "Test Mock"
            assert config.host == "0.0.0.0"
            assert config.port == 9000
            assert config.cors is False
            assert len(config.endpoints) == 2

    def test_endpoint_parsing(self):
        with tempfile.TemporaryDirectory() as d:
            f = Path(d) / "mock.yaml"
            f.write_text(SAMPLE_MOCK_CONFIG, encoding="utf-8")
            config = parse_mock_config(f)

            ep = config.endpoints[0]
            assert ep.path == "/health"
            assert ep.method == HttpMethod.GET
            assert ep.status_code == 200

            ep2 = config.endpoints[1]
            assert ep2.delay_ms == 100

    def test_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            parse_mock_config("/nonexistent/file.yaml")


class TestExampleGenerators:
    def test_example_suite_valid_yaml(self):
        import yaml
        content = generate_example_suite()
        data = yaml.safe_load(content)
        assert "name" in data
        assert "requests" in data

    def test_example_load_test_valid_yaml(self):
        import yaml
        content = generate_example_load_test()
        data = yaml.safe_load(content)
        assert "url" in data
        assert "concurrency" in data

    def test_example_mock_valid_yaml(self):
        import yaml
        content = generate_example_mock_config()
        data = yaml.safe_load(content)
        assert "port" in data
        assert "endpoints" in data
