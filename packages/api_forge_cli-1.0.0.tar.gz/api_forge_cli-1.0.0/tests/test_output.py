"""Tests for api_forge.output — console rendering (smoke tests)."""

from __future__ import annotations

from io import StringIO
from unittest.mock import patch

from rich.console import Console

from api_forge import output as output_mod
from api_forge.models import (
    Assertion,
    AssertionType,
    LoadTestConfig,
    LoadTestResult,
    RequestResult,
    TestSuiteResult,
)
from api_forge.output import (
    render_load_test_result,
    render_quick_request,
    render_request_result,
    render_test_suite_result,
)


def _capture_output(func, *args):
    """Capture console output from a render function."""
    buf = StringIO()
    fake_console = Console(file=buf, width=120, force_terminal=True)
    with patch.object(output_mod, "console", fake_console):
        func(*args)
    return buf.getvalue()


class TestRenderRequestResult:
    def test_success(self):
        result = RequestResult(
            name="Test", url="http://test", method="GET",
            status_code=200, headers={}, body="", duration_ms=100
        )
        output = _capture_output(render_request_result, result)
        assert "Test" in output
        assert "200" in output

    def test_failure(self):
        result = RequestResult(
            name="Test", url="http://test", method="GET",
            status_code=500, headers={}, body="", duration_ms=100
        )
        output = _capture_output(render_request_result, result)
        assert "Test" in output
        assert "500" in output

    def test_with_error(self):
        result = RequestResult(
            name="Test", url="http://test", method="GET",
            status_code=0, headers={}, body="", duration_ms=100,
            error="Connection refused"
        )
        output = _capture_output(render_request_result, result)
        assert "Connection refused" in output

    def test_with_assertions(self):
        result = RequestResult(
            name="Test", url="http://test", method="GET",
            status_code=200, headers={}, body="", duration_ms=100,
            assertions=[
                Assertion(type=AssertionType.STATUS, expected=200, passed=True, message="Status 200"),
            ]
        )
        output = _capture_output(render_request_result, result)
        # Output contains assertion info with ANSI codes
        assert "200" in output


class TestRenderTestSuiteResult:
    def test_basic(self):
        result = TestSuiteResult(
            name="My Suite",
            results=[
                RequestResult(name="A", url="", method="GET", status_code=200, headers={}, body="", duration_ms=100),
                RequestResult(name="B", url="", method="GET", status_code=500, headers={}, body="", duration_ms=100),
            ],
            total_duration_ms=200,
        )
        output = _capture_output(render_test_suite_result, result)
        assert "My Suite" in output
        assert "2" in output  # Total
        assert "1" in output  # Passed


class TestRenderLoadTestResult:
    def test_basic(self):
        result = LoadTestResult(
            config=LoadTestConfig(url="http://test"),
            total_requests=100,
            successful_requests=95,
            failed_requests=5,
            latencies_ms=[10, 20, 30, 40, 50],
            status_codes={200: 90, 500: 5, 503: 5},
            duration_seconds=10.0,
        )
        output = _capture_output(render_load_test_result, result)
        assert "100" in output
        assert "95" in output

    def test_with_errors(self):
        result = LoadTestResult(
            config=LoadTestConfig(url="http://test"),
            total_requests=10,
            successful_requests=5,
            failed_requests=5,
            latencies_ms=[100, 200],
            errors=["Timeout", "Connection refused"],
            duration_seconds=1.0,
        )
        output = _capture_output(render_load_test_result, result)
        assert "Timeout" in output or "Errors" in output


class TestRenderQuickRequest:
    def test_success(self):
        result = RequestResult(
            name="Quick", url="http://test/api", method="GET",
            status_code=200, headers={"content-type": "application/json"},
            body='{"key": "value"}', duration_ms=50
        )
        output = _capture_output(render_quick_request, result)
        assert "GET" in output
        assert "200" in output

    def test_with_error(self):
        result = RequestResult(
            name="Quick", url="http://test/api", method="GET",
            status_code=0, headers={}, body="", duration_ms=0,
            error="Connection refused"
        )
        output = _capture_output(render_quick_request, result)
        assert "Connection refused" in output
