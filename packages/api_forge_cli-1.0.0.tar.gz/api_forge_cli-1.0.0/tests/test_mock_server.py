"""Tests for api_forge.mock_server — mock HTTP server."""

from __future__ import annotations

import time

import httpx

from api_forge.mock_server import MockHandler, MockServer
from api_forge.models import HttpMethod, MockEndpoint, MockServerConfig


class TestMockServer:
    def test_server_starts_and_stops(self):
        config = MockServerConfig(port=18001)
        server = MockServer(config)
        server.start()
        time.sleep(0.1)  # Let server start
        assert server.url == "http://127.0.0.1:18001"
        server.stop()

    def test_context_manager(self):
        config = MockServerConfig(port=18002)
        with MockServer(config) as server:
            assert server.url == "http://127.0.0.1:18002"

    def test_get_endpoint(self, mock_server):
        response = httpx.get(f"{mock_server.url}/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "healthy"

    def test_post_endpoint(self, mock_server):
        response = httpx.post(f"{mock_server.url}/users", json={"name": "Test"})
        assert response.status_code == 201

    def test_404_for_unknown_path(self, mock_server):
        response = httpx.get(f"{mock_server.url}/unknown")
        assert response.status_code == 404

    def test_cors_headers(self, mock_server):
        response = httpx.get(f"{mock_server.url}/health")
        assert "access-control-allow-origin" in response.headers

    def test_custom_headers(self, mock_server):
        response = httpx.get(f"{mock_server.url}/users")
        # The mock_server fixture should have custom headers
        assert response.status_code == 200


class TestMockHandler:
    def test_path_matches_exact(self):
        handler = MockHandler.__new__(MockHandler)
        handler.server_config = MockServerConfig()
        assert handler._path_matches("/users", "/users") is True
        assert handler._path_matches("/users", "/posts") is False

    def test_path_matches_wildcard(self):
        handler = MockHandler.__new__(MockHandler)
        handler.server_config = MockServerConfig()
        assert handler._path_matches("/users/123", "/users/*") is True
        assert handler._path_matches("/users/123/posts", "/users/*/posts") is True
        assert handler._path_matches("/users/123", "/posts/*") is False


class TestMockEndpointMatching:
    def test_method_matching(self, mock_server):
        # GET /users should work
        get_response = httpx.get(f"{mock_server.url}/users")
        assert get_response.status_code == 200

        # POST /users should work with different response
        post_response = httpx.post(f"{mock_server.url}/users", json={})
        assert post_response.status_code == 201

    def test_delay_simulation(self):
        config = MockServerConfig(
            port=18003,
            endpoints=[
                MockEndpoint(path="/slow", method=HttpMethod.GET, status_code=200, delay_ms=500),
            ],
        )
        with MockServer(config) as server:
            start = time.time()
            response = httpx.get(f"{server.url}/slow")
            elapsed = time.time() - start
            assert response.status_code == 200
            assert elapsed >= 0.4  # Allow some margin


class TestMockServerConfig:
    def test_default_response(self):
        config = MockServerConfig(
            port=18004,
            default_status=503,
            default_body='{"error": "Service Unavailable"}',
        )
        with MockServer(config) as server:
            response = httpx.get(f"{server.url}/undefined")
            assert response.status_code == 503
            assert "Service Unavailable" in response.text
