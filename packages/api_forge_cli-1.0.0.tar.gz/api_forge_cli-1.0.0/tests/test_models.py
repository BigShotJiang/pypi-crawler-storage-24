"""Tests for api_forge.models — data models and assertions."""

from __future__ import annotations

from api_forge.models import (
    Assertion,
    AssertionType,
    HttpMethod,
    LoadTestConfig,
    LoadTestResult,
    MockEndpoint,
    MockServerConfig,
    RequestResult,
    TestSuiteResult,
    _json_path_extract,
    _percentile,
)


class TestHttpMethod:
    def test_values(self):
        assert HttpMethod.GET.value == "GET"
        assert HttpMethod.POST.value == "POST"
        assert HttpMethod.PUT.value == "PUT"
        assert HttpMethod.DELETE.value == "DELETE"

    def test_is_str_enum(self):
        # HttpMethod.value gives the string representation
        assert HttpMethod.GET.value == "GET"


class TestAssertionType:
    def test_values(self):
        assert AssertionType.STATUS.value == "status"
        assert AssertionType.HEADER.value == "header"
        assert AssertionType.BODY_CONTAINS.value == "body_contains"
        assert AssertionType.BODY_JSON_PATH.value == "json_path"


class TestJsonPathExtract:
    def test_simple_key(self):
        assert _json_path_extract('{"name": "Alice"}', "name") == "Alice"

    def test_nested_key(self):
        assert _json_path_extract('{"user": {"name": "Bob"}}', "user.name") == "Bob"

    def test_array_index(self):
        assert _json_path_extract('{"items": ["a", "b", "c"]}', "items.1") == "b"

    def test_missing_key(self):
        assert _json_path_extract('{"name": "Alice"}', "age") is None

    def test_invalid_json(self):
        assert _json_path_extract("not json", "key") is None

    def test_deep_nesting(self):
        json_str = '{"a": {"b": {"c": {"d": "value"}}}}'
        assert _json_path_extract(json_str, "a.b.c.d") == "value"

    def test_numeric_value(self):
        assert _json_path_extract('{"count": 42}', "count") == 42


class TestAssertion:
    def test_status_assertion_pass(self):
        result = RequestResult(
            name="test", url="http://test", method="GET",
            status_code=200, headers={}, body="", duration_ms=100
        )
        assertion = Assertion(type=AssertionType.STATUS, expected=200)
        assertion.evaluate(result)
        assert assertion.passed is True

    def test_status_assertion_fail(self):
        result = RequestResult(
            name="test", url="http://test", method="GET",
            status_code=404, headers={}, body="", duration_ms=100
        )
        assertion = Assertion(type=AssertionType.STATUS, expected=200)
        assertion.evaluate(result)
        assert assertion.passed is False

    def test_status_list_assertion(self):
        result = RequestResult(
            name="test", url="http://test", method="GET",
            status_code=201, headers={}, body="", duration_ms=100
        )
        assertion = Assertion(type=AssertionType.STATUS, expected=[200, 201])
        assertion.evaluate(result)
        assert assertion.passed is True

    def test_header_assertion(self):
        result = RequestResult(
            name="test", url="http://test", method="GET",
            status_code=200, headers={"Content-Type": "application/json"}, body="", duration_ms=100
        )
        assertion = Assertion(type=AssertionType.HEADER, expected="json", path="Content-Type")
        assertion.evaluate(result)
        assert assertion.passed is True

    def test_body_contains_assertion(self):
        result = RequestResult(
            name="test", url="http://test", method="GET",
            status_code=200, headers={}, body='{"message": "hello"}', duration_ms=100
        )
        assertion = Assertion(type=AssertionType.BODY_CONTAINS, expected="hello")
        assertion.evaluate(result)
        assert assertion.passed is True

    def test_json_path_assertion(self):
        result = RequestResult(
            name="test", url="http://test", method="GET",
            status_code=200, headers={}, body='{"user": {"id": 123}}', duration_ms=100
        )
        assertion = Assertion(type=AssertionType.BODY_JSON_PATH, expected=123, path="user.id")
        assertion.evaluate(result)
        assert assertion.passed is True

    def test_regex_assertion(self):
        result = RequestResult(
            name="test", url="http://test", method="GET",
            status_code=200, headers={}, body='User ID: 12345', duration_ms=100
        )
        assertion = Assertion(type=AssertionType.BODY_REGEX, expected=r"\d{5}")
        assertion.evaluate(result)
        assert assertion.passed is True

    def test_response_time_assertion_pass(self):
        result = RequestResult(
            name="test", url="http://test", method="GET",
            status_code=200, headers={}, body="", duration_ms=100
        )
        assertion = Assertion(type=AssertionType.RESPONSE_TIME, expected=500)
        assertion.evaluate(result)
        assert assertion.passed is True

    def test_response_time_assertion_fail(self):
        result = RequestResult(
            name="test", url="http://test", method="GET",
            status_code=200, headers={}, body="", duration_ms=1000
        )
        assertion = Assertion(type=AssertionType.RESPONSE_TIME, expected=500)
        assertion.evaluate(result)
        assert assertion.passed is False


class TestRequestResult:
    def test_success_on_2xx(self):
        result = RequestResult(
            name="test", url="http://test", method="GET",
            status_code=200, headers={}, body="", duration_ms=100
        )
        assert result.success is True

    def test_fail_on_error(self):
        result = RequestResult(
            name="test", url="http://test", method="GET",
            status_code=200, headers={}, body="", duration_ms=100,
            error="Connection refused"
        )
        assert result.success is False

    def test_fail_on_4xx(self):
        result = RequestResult(
            name="test", url="http://test", method="GET",
            status_code=404, headers={}, body="", duration_ms=100
        )
        assert result.success is False

    def test_failed_assertions_computed(self):
        result = RequestResult(
            name="test", url="http://test", method="GET",
            status_code=200, headers={}, body="", duration_ms=100,
            assertions=[
                Assertion(type=AssertionType.STATUS, expected=200, passed=True, actual=200),
                Assertion(type=AssertionType.STATUS, expected=201, passed=False, actual=200),
            ]
        )
        assert len(result.failed_assertions) == 1


class TestTestSuiteResult:
    def test_counts(self):
        result = TestSuiteResult(name="test", results=[
            RequestResult(name="a", url="", method="GET", status_code=200, headers={}, body="", duration_ms=100),
            RequestResult(name="b", url="", method="GET", status_code=500, headers={}, body="", duration_ms=100),
            RequestResult(name="c", url="", method="GET", status_code=200, headers={}, body="", duration_ms=100),
        ])
        assert result.total == 3
        assert result.passed == 2
        assert result.failed == 1

    def test_success_rate(self):
        result = TestSuiteResult(name="test", results=[
            RequestResult(name="a", url="", method="GET", status_code=200, headers={}, body="", duration_ms=100),
            RequestResult(name="b", url="", method="GET", status_code=200, headers={}, body="", duration_ms=100),
        ])
        assert result.success_rate == 100.0


class TestPercentile:
    def test_p50(self):
        values = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
        assert _percentile(values, 50) == 60

    def test_p99(self):
        values = list(range(1, 101))
        assert _percentile(values, 99) == 100

    def test_empty(self):
        assert _percentile([], 50) == 0.0


class TestLoadTestResult:
    def test_properties(self):
        result = LoadTestResult(
            config=LoadTestConfig(url="http://test"),
            total_requests=100,
            successful_requests=95,
            failed_requests=5,
            latencies_ms=[10, 20, 30, 40, 50],
            duration_seconds=10.0,
        )
        assert result.requests_per_second == 10.0
        assert result.avg_latency_ms == 30.0
        assert result.min_latency_ms == 10
        assert result.max_latency_ms == 50
        assert result.success_rate == 95.0
        assert result.error_rate == 5.0


class TestMockEndpoint:
    def test_defaults(self):
        ep = MockEndpoint(path="/test")
        assert ep.method == HttpMethod.GET
        assert ep.status_code == 200
        assert ep.delay_ms == 0


class TestMockServerConfig:
    def test_defaults(self):
        config = MockServerConfig()
        assert config.host == "127.0.0.1"
        assert config.port == 8000
        assert config.cors is True
