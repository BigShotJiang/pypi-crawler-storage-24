---
name: submit-skill-repo
description: Submit a GitHub repository to be indexed by the OpenAkita Skill Store. Use when user wants to share their skill repository with the community or register a new skill source.
system: true
handler: skill_store
tool-name: submit_skill_repo
category: Platform
---

# Submit Skill Repo

将 GitHub 仓库提交到 OpenAkita Skill Store 索引。

## Tools

- `submit_skill_repo` - Submit a GitHub repo URL for skill indexing

## Usage

Use this skill when the user wants to:
- Share their GitHub repository containing Skills
- Submit a community Skill to the platform
- Register a new Skill source for the Skill Store

## Parameters

- `repo_url` (required): GitHub repository URL (e.g. https://github.com/owner/repo)

## Examples

- "把我的 GitHub 仓库提交到 Skill Store"
- "提交 https://github.com/my-org/my-skill 到平台"
