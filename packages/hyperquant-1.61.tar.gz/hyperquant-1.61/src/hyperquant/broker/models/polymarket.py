from __future__ import annotations

import json
from dataclasses import dataclass, field
from heapq import heappop, heappush
import time
from typing import TYPE_CHECKING, Any, Iterable

from pybotters.store import DataStore, DataStoreCollection
from pybotters.ws import ClientWebSocketResponse

if TYPE_CHECKING:
    from pybotters.typedefs import Item

   
class Position(DataStore):
    """Position store fed only by User WS trade events."""

    _KEYS = ["asset"]

    def _init(self) -> None:
        self._owner_key: str | None = None
        self._dedup_seen: dict[str, float] = {}
        self._dedup_ttl_secs = 15 * 60
        self._dedup_max_entries = 50_000
        self._market_state: dict[str, dict[str, Any]] = {}
        self._market_assets: dict[str, dict[str, str | None]] = {}

    def set_owner_key(self, api_key: str | None) -> None:
        owner = str(api_key).strip().lower() if api_key else ""
        self._owner_key = owner or None

    def sorted(
        self, query: Item | None = None, limit: int | None = None
    ) -> dict[str, list[Item]]:
        if query is None:
            query = {}
        result: dict[str, list[Item]] = {}
        for item in self:
            if all(k in item and query[k] == item[k] for k in query):
                outcome = item.get("outcome") or "unknown"
                result.setdefault(outcome, []).append(item)
        for outcome in result:
            result[outcome].sort(key=lambda x: float(x.get("ts") or 0.0), reverse=True)
            if limit:
                result[outcome] = result[outcome][:limit]
        return result

    def _on_response(self, msg: list[Item]) -> None:
        # Inventory is user-trade driven only (do not overwrite via REST snapshots).
        _ = msg
        return

    @staticmethod
    def _to_float(value: Any) -> float | None:
        try:
            return float(value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _status_bucket(status: str) -> str | None:
        if status in {"MATCHED", "MINED", "CONFIRMED"}:
            return "SUCCESS"
        if status == "FAILED":
            return "FAILED"
        return None

    @staticmethod
    def _normalize_owner(owner: Any) -> str:
        return str(owner or "").strip().lower()

    @staticmethod
    def _dedup_bucket(status_bucket: str) -> str:
        return "SUCCESS" if status_bucket == "SUCCESS" else "FAILED"

    def _remember_dedup(self, key: str) -> bool:
        now = time.time()
        cutoff = now - self._dedup_ttl_secs
        if self._dedup_seen:
            stale = [k for k, ts in self._dedup_seen.items() if ts < cutoff]
            for k in stale:
                self._dedup_seen.pop(k, None)

        if key in self._dedup_seen:
            return False

        self._dedup_seen[key] = now
        if len(self._dedup_seen) > self._dedup_max_entries:
            oldest_key = min(self._dedup_seen, key=self._dedup_seen.get)
            self._dedup_seen.pop(oldest_key, None)
        return True

    def _infer_side_key(
        self,
        *,
        market: str,
        asset_id: str,
        outcome: str | None,
        outcome_index: Any,
    ) -> str | None:
        assets = self._market_assets.setdefault(market, {"YES": None, "NO": None})

        mapped_side: str | None = None
        if asset_id:
            if assets.get("YES") == asset_id:
                mapped_side = "YES"
            elif assets.get("NO") == asset_id:
                mapped_side = "NO"

        # Prefer outcome text for side inference; outcome_index is fallback only.
        text_side: str | None
        text = str(outcome or "").strip().upper()
        if text in {"YES", "UP", "TRUE"}:
            text_side = "YES"
        elif text in {"NO", "DOWN", "FALSE"}:
            text_side = "NO"
        else:
            text_side = None

        idx_side: str | None = None
        if outcome_index is not None:
            try:
                idx = int(outcome_index)
                if idx == 0:
                    idx_side = "YES"
                elif idx == 1:
                    idx_side = "NO"
            except (TypeError, ValueError):
                idx_side = None

        explicit_side = text_side if text_side is not None else idx_side

        # Correct a previously wrong binding once explicit side appears.
        if mapped_side and explicit_side and mapped_side != explicit_side:
            dst_asset = assets.get(explicit_side)
            if dst_asset in (None, asset_id):
                assets[mapped_side] = None
                assets[explicit_side] = asset_id
                self._migrate_side_state(market=market, from_side=mapped_side, to_side=explicit_side)
                mapped_side = explicit_side
            else:
                # Conflicting mapping (both legs already occupied by different assets): skip.
                return None

        if mapped_side:
            return mapped_side

        # Unknown outcome/index: do not guess side to avoid poisoning inventory.
        if explicit_side is None:
            return None

        bound = assets.get(explicit_side)
        if bound not in (None, asset_id):
            return None
        assets[explicit_side] = asset_id
        return explicit_side

    def _migrate_side_state(self, *, market: str, from_side: str, to_side: str) -> None:
        if from_side == to_side:
            return
        state = self._market_state.get(market)
        if not state:
            return

        from_qty_key = "yes_qty" if from_side == "YES" else "no_qty"
        from_avg_key = "yes_avg_cost" if from_side == "YES" else "no_avg_cost"
        to_qty_key = "yes_qty" if to_side == "YES" else "no_qty"
        to_avg_key = "yes_avg_cost" if to_side == "YES" else "no_avg_cost"

        from_qty = float(state.get(from_qty_key) or 0.0)
        from_avg = float(state.get(from_avg_key) or 0.0)
        to_qty = float(state.get(to_qty_key) or 0.0)

        # Safe migration only when destination leg has no existing inventory.
        if to_qty > 1e-12:
            return
        state[to_qty_key] = from_qty
        state[to_avg_key] = from_avg
        state[from_qty_key] = 0.0
        state[from_avg_key] = 0.0
        self._recompute_derived(state)

    def _default_state(self) -> dict[str, Any]:
        return {
            "yes_qty": 0.0,
            "no_qty": 0.0,
            "yes_avg_cost": 0.0,
            "no_avg_cost": 0.0,
            "cash_flow": 0.0,
            "open_cost": 0.0,
            "realized_pnl": 0.0,
            "pnl_if_yes_win": 0.0,
            "pnl_if_no_win": 0.0,
            "max_loss": 0.0,
            "best_case_pnl": 0.0,
            "net_diff": 0.0,
            "portfolio_cost": 0.0,
            "yes_asset": None,
            "no_asset": None,
            "yes_outcome": "Yes",
            "no_outcome": "No",
        }

    def _recompute_derived(self, state: dict[str, Any]) -> None:
        yes_qty = float(state.get("yes_qty") or 0.0)
        no_qty = float(state.get("no_qty") or 0.0)
        yes_avg = float(state.get("yes_avg_cost") or 0.0)
        no_avg = float(state.get("no_avg_cost") or 0.0)
        cash_flow = float(state.get("cash_flow") or 0.0)
        open_cost = yes_qty * yes_avg + no_qty * no_avg

        state["net_diff"] = yes_qty - no_qty
        state["portfolio_cost"] = (yes_avg + no_avg) if (yes_qty > 0.0 and no_qty > 0.0) else 0.0
        state["open_cost"] = open_cost
        state["realized_pnl"] = cash_flow + open_cost
        state["pnl_if_yes_win"] = cash_flow + yes_qty
        state["pnl_if_no_win"] = cash_flow + no_qty
        state["max_loss"] = min(state["pnl_if_yes_win"], state["pnl_if_no_win"])
        state["best_case_pnl"] = max(state["pnl_if_yes_win"], state["pnl_if_no_win"])

    def _upsert_row(self, row: dict[str, Any]) -> None:
        existing = self.get({"asset": row["asset"]})
        if existing:
            self._update([row])
        else:
            self._insert([row])

    def _publish_market_state(self, market: str, state: dict[str, Any]) -> None:
        now_ms = int(time.time() * 1000)

        common = {
            "market": market,
            "yes_qty": float(state.get("yes_qty") or 0.0),
            "no_qty": float(state.get("no_qty") or 0.0),
            "yes_avg_cost": float(state.get("yes_avg_cost") or 0.0),
            "no_avg_cost": float(state.get("no_avg_cost") or 0.0),
            "cash_flow": float(state.get("cash_flow") or 0.0),
            "open_cost": float(state.get("open_cost") or 0.0),
            "realized_pnl": float(state.get("realized_pnl") or 0.0),
            "pnl_if_yes_win": float(state.get("pnl_if_yes_win") or 0.0),
            "pnl_if_no_win": float(state.get("pnl_if_no_win") or 0.0),
            "max_loss": float(state.get("max_loss") or 0.0),
            "best_case_pnl": float(state.get("best_case_pnl") or 0.0),
            "net_diff": float(state.get("net_diff") or 0.0),
            "portfolio_cost": float(state.get("portfolio_cost") or 0.0),
            "ts": now_ms,
            "source": "user_ws_trade",
        }

        yes_asset = state.get("yes_asset")
        no_asset = state.get("no_asset")
        if yes_asset:
            yes_qty = common["yes_qty"]
            yes_avg = common["yes_avg_cost"]
            self._upsert_row(
                {
                    "asset": yes_asset,
                    "outcome": state.get("yes_outcome") or "Yes",
                    "size": yes_qty,
                    "avgPrice": yes_avg,
                    "totalAvgPrice": yes_avg,
                    "expected_pnl_if_win": common["pnl_if_yes_win"],
                    "expected_pnl_if_lose": common["pnl_if_no_win"],
                    **common,
                }
            )
        if no_asset:
            no_qty = common["no_qty"]
            no_avg = common["no_avg_cost"]
            self._upsert_row(
                {
                    "asset": no_asset,
                    "outcome": state.get("no_outcome") or "No",
                    "size": no_qty,
                    "avgPrice": no_avg,
                    "totalAvgPrice": no_avg,
                    "expected_pnl_if_win": common["pnl_if_no_win"],
                    "expected_pnl_if_lose": common["pnl_if_yes_win"],
                    **common,
                }
            )

    def _apply_fill(self, fill: dict[str, Any], status_bucket: str) -> None:
        market = str(fill.get("market") or "")
        if not market:
            market = "__unknown_market__"

        asset_id = str(fill.get("asset_id") or "")
        if not asset_id:
            return

        outcome = fill.get("outcome")
        side = str(fill.get("side") or "").upper()
        size = self._to_float(fill.get("size"))
        price = self._to_float(fill.get("price"))
        if side not in {"BUY", "SELL"} or size is None or price is None or size <= 0.0 or price <= 0.0:
            return

        side_key = self._infer_side_key(
            market=market,
            asset_id=asset_id,
            outcome=str(outcome or ""),
            outcome_index=fill.get("outcome_index"),
        )
        if side_key is None:
            return

        state = self._market_state.setdefault(market, self._default_state())
        assets = self._market_assets.get(market) or {}
        state["yes_asset"] = assets.get("YES")
        state["no_asset"] = assets.get("NO")
        if side_key == "YES":
            state["yes_asset"] = asset_id
            if outcome:
                state["yes_outcome"] = outcome
        else:
            state["no_asset"] = asset_id
            if outcome:
                state["no_outcome"] = outcome

        trade_sign = 1.0 if side == "BUY" else -1.0
        status_sign = -1.0 if status_bucket == "FAILED" else 1.0
        delta = size * trade_sign * status_sign
        if abs(delta) < 1e-12:
            return
        cash_delta = (-price * size if side == "BUY" else price * size) * status_sign
        state["cash_flow"] = float(state.get("cash_flow") or 0.0) + cash_delta

        qty_key = "yes_qty" if side_key == "YES" else "no_qty"
        avg_key = "yes_avg_cost" if side_key == "YES" else "no_avg_cost"
        old_qty = float(state.get(qty_key) or 0.0)
        old_avg = float(state.get(avg_key) or 0.0)
        new_qty = max(old_qty + delta, 0.0)
        state[qty_key] = new_qty

        if delta > 0.0 and new_qty > 0.0:
            state[avg_key] = (old_qty * old_avg + delta * price) / new_qty
        elif new_qty < 1e-12:
            state[avg_key] = 0.0
        else:
            state[avg_key] = old_avg

        self._recompute_derived(state)
        self._publish_market_state(market, state)

    def _parse_maker_fills(self, trade: Item) -> list[dict[str, Any]]:
        fills: list[dict[str, Any]] = []
        maker_orders = trade.get("maker_orders") or []
        if not isinstance(maker_orders, list):
            return fills

        trade_price = self._to_float(trade.get("price"))
        trade_size = self._to_float(trade.get("size"))
        trade_side = str(trade.get("side") or "").upper()

        for maker in maker_orders:
            if not isinstance(maker, dict):
                continue
            owner = self._normalize_owner(maker.get("owner"))
            if self._owner_key and (not owner or owner != self._owner_key):
                continue

            side = str(maker.get("side") or trade_side or "").upper()
            size = self._to_float(maker.get("matched_amount"))
            if size is None:
                size = self._to_float(maker.get("size"))
            if size is None:
                size = trade_size
            price = self._to_float(maker.get("price"))
            if price is None:
                price = trade_price
            if side not in {"BUY", "SELL"} or size is None or price is None:
                continue
            fills.append(
                {
                    "trade_id": trade.get("id"),
                    "order_id": maker.get("order_id"),
                    "market": trade.get("market"),
                    "asset_id": maker.get("asset_id") or trade.get("asset_id"),
                    "outcome": maker.get("outcome") or trade.get("outcome"),
                    "outcome_index": maker.get("outcome_index"),
                    "side": side,
                    "size": size,
                    "price": price,
                }
            )
        return fills

    def _parse_taker_fill(self, trade: Item) -> list[dict[str, Any]]:
        owner = self._normalize_owner(trade.get("trade_owner") or trade.get("owner"))
        if self._owner_key and owner and owner != self._owner_key:
            return []

        side = str(trade.get("side") or "").upper()
        size = self._to_float(trade.get("size"))
        price = self._to_float(trade.get("price"))
        if side not in {"BUY", "SELL"} or size is None or price is None:
            return []

        return [
            {
                "trade_id": trade.get("id"),
                "order_id": trade.get("taker_order_id") or trade.get("order_id"),
                "market": trade.get("market"),
                "asset_id": trade.get("asset_id"),
                "outcome": trade.get("outcome"),
                "outcome_index": trade.get("outcome_index"),
                "side": side,
                "size": size,
                "price": price,
            }
        ]

    def on_trade(self, trade: Item) -> None:
        status = str(trade.get("status") or "").upper()
        status_bucket = self._status_bucket(status)
        if status_bucket is None:
            return

        trader_side = str(trade.get("trader_side") or "")
        maker_orders = trade.get("maker_orders") or []
        has_maker_orders = isinstance(maker_orders, list) and len(maker_orders) > 0

        if trader_side.upper() == "MAKER" or (not trader_side and has_maker_orders):
            fills = self._parse_maker_fills(trade)
            if not fills:
                return
        else:
            fills = self._parse_taker_fill(trade)

        bucket = self._dedup_bucket(status_bucket)
        for fill in fills:
            trade_id = str(fill.get("trade_id") or "")
            order_id = str(fill.get("order_id") or "")
            if trade_id:
                dedup_key = f"tid:{trade_id}:oid:{order_id}:{bucket}"
            else:
                dedup_key = (
                    f"oid:{order_id}:{bucket}:"
                    f"{fill.get('asset_id')}:{fill.get('side')}:"
                    f"{fill.get('price')}:{fill.get('size')}"
                )
            if not self._remember_dedup(dedup_key):
                continue
            self._apply_fill(fill, status_bucket)

    def _on_order(self, order: dict[str, Any]) -> None:
        # Position is no longer order-driven.
        _ = order
        return



class Fill(DataStore):
    """Fill records keyed by maker order id."""

    _KEYS = ["order_id"]

    @staticmethod
    def _from_trade(trade: dict[str, Any], maker: dict[str, Any]) -> dict[str, Any] | None:
        order_id = maker.get("order_id")
        if not order_id:
            return None

        record = {
            "order_id": order_id,
            "trade_id": trade.get("id"),
            "asset_id": maker.get("asset_id") or trade.get("asset_id"),
            "market": trade.get("market"),
            "outcome": maker.get("outcome") or trade.get("outcome"),
            "matched_amount": maker.get("matched_amount") or trade.get("size"),
            "price": maker.get("price") or trade.get("price"),
            "status": trade.get("status"),
            "match_time": trade.get("match_time") or trade.get("timestamp"),
            "maker_owner": maker.get("owner"),
            "taker_order_id": trade.get("taker_order_id"),
            "side": maker.get("side") or trade.get("side"),
        }

        for key in ("matched_amount", "price"):
            value = record.get(key)
            if value is None:
                continue
            try:
                record[key] = float(value)
            except (TypeError, ValueError):
                pass

        return record

    def _on_trade(self, trade: dict[str, Any]) -> None:
        status = str(trade.get("status") or "").upper()
        if status != "MATCHED":
            return
        maker_orders = trade.get("maker_orders") or []
        upserts: list[dict[str, Any]] = []
        for maker in maker_orders:
            record = self._from_trade(trade, maker)
            if not record:
                continue
            upserts.append(record)

        if not upserts:
            return

        for record in upserts:
            key = {"order_id": record["order_id"]}
            if self.get(key):
                self._update([record])
            else:
                self._insert([record])


class Order(DataStore):
    """User orders keyed by order id (REST + WS)."""

    _KEYS = ["id"]

    @staticmethod
    def _normalize(entry: dict[str, Any]) -> dict[str, Any] | None:
        oid = entry.get("id")
        if not oid:
            return None
        normalized = dict(entry)
        # numeric fields
        for field in ("price", "original_size", "size_matched"):
            val = normalized.get(field)
            try:
                if val is not None:
                    normalized[field] = float(val)
            except (TypeError, ValueError):
                pass
        return normalized

    def _on_response(self, items: list[dict[str, Any]] | dict[str, Any]) -> None:
        """增量同步：insert新增、update变更、delete消失的订单"""
        rows: list[dict[str, Any]] = []
        if isinstance(items, dict):
            items = [items]
        for it in items or []:
            norm = self._normalize(it)
            if norm:
                rows.append(norm)

        # 构建新订单id集合
        new_ids = {r["id"] for r in rows}

        # 删除不再存在的订单（传入完整状态）
        to_delete = [dict(item) for item in self if item["id"] not in new_ids]
        if to_delete:
            self._delete(to_delete)

        # 插入或更新
        for row in rows:
            existing = self.get({"id": row["id"]})
            if existing:
                # 有变化才update
                if any(existing.get(k) != row.get(k) for k in row):
                    self._update([row])
            else:
                self._insert([row])

    def _on_message(self, msg: dict[str, Any]) -> None:
        status = str(msg.get("status") or "").upper()
        # CANCELED MATCHED 删除
        order = self.get({"id": msg.get("id")})
        if not order:
            self._insert([msg])

        if status in {"CANCELED", "MATCHED"}:
            self._delete([msg])

class MyTrade(DataStore):
    """User trades keyed by trade id."""

    _KEYS = ["id"]

    @staticmethod
    def _normalize(entry: dict[str, Any]) -> dict[str, Any] | None:
        trade_id = entry.get("id")
        if not trade_id:
            return None
        normalized = dict(entry)
        for field in ("price", "size", "fee_rate_bps"):
            value = normalized.get(field)
            if value is None:
                continue
            try:
                normalized[field] = float(value)
            except (TypeError, ValueError):
                pass
        return normalized

    def _on_message(self, msg: dict[str, Any]) -> None:
        normalized = self._normalize(msg) or {}
        trade_id = normalized.get("id")
        if not trade_id:
            return
        if self.get({"id": trade_id}):
            self._update([normalized])
        else:
            self._insert([normalized])

class Trade(DataStore):
    """User trades keyed by trade id."""

    _KEYS = ["hash"]
    _MAXLEN = 500

    def _on_message(self, msg: dict[str, Any]) -> None:
        payload = msg or {}
        if payload:
            if payload.get("event_type") == "last_trade_price":
                transaction_hash = payload.get("transaction_hash")
                if transaction_hash:
                    payload.update({"hash": transaction_hash})
                    payload.pop("transaction_hash", None)
            else:
                if payload.get("transactionHash"):
                    payload.update({"hash": payload.get("transactionHash")})
                    payload.pop("transactionHash", None)

            self._insert([payload])

class Book(DataStore):
    """Full depth order book keyed by Polymarket token id."""

    _KEYS = ["s", "S", "p"]
    _PRICE_SCALE = 10_000
    _SIZE_SCALE = 10_000

    def _init(self) -> None:
        self.id_to_alias: dict[str, str] = {}
        # Internal hot-path storage:
        # symbol -> {"a": {price_ticks: size_units}, "b": {price_ticks: size_units}}
        self._levels: dict[str, dict[str, dict[int, int]]] = {}
        # Per-symbol monotonic sequence/timestamp gate.
        self._last_seq: dict[str, int] = {}

    def update_aliases(self, mapping: dict[str, str]) -> None:
        if not mapping:
            return
        self.id_to_alias.update(mapping)

    def _alias(self, asset_id: str | None) -> tuple[str, str | None] | tuple[None, None]:
        if asset_id is None:
            return None, None
        alias = self.id_to_alias.get(asset_id)
        return asset_id, alias

    @classmethod
    def _to_fixed(cls, value: Any, scale: int) -> int | None:
        if value is None:
            return None

        if isinstance(value, int):
            return value * scale

        if isinstance(value, float):
            if value != value or value in (float("inf"), float("-inf")):
                return None
            return int(round(value * scale))

        text = str(value).strip()
        if not text:
            return None

        if "e" in text or "E" in text:
            try:
                val = float(text)
            except ValueError:
                return None
            if val != val or val in (float("inf"), float("-inf")):
                return None
            return int(round(val * scale))

        neg = False
        if text[0] in "+-":
            neg = text[0] == "-"
            text = text[1:]
            if not text:
                return None

        whole, dot, frac = text.partition(".")
        if not whole:
            whole = "0"
        if not whole.isdigit():
            return None

        frac_digits = len(str(scale)) - 1
        if dot:
            if not frac.isdigit():
                return None
            frac = (frac + ("0" * frac_digits))[:frac_digits]
            frac_val = int(frac) if frac else 0
        else:
            frac_val = 0

        units = int(whole) * scale + frac_val
        return -units if neg else units

    @staticmethod
    def _parse_int_like(value: Any) -> int | None:
        if value is None:
            return None
        if isinstance(value, bool):
            return None
        if isinstance(value, int):
            return value
        if isinstance(value, float):
            if value != value or value in (float("inf"), float("-inf")):
                return None
            return int(value)
        text = str(value).strip()
        if not text:
            return None
        try:
            if "." in text:
                return int(float(text))
            return int(text)
        except ValueError:
            return None

    @classmethod
    def _extract_timestamp(cls, msg: dict[str, Any], change: dict[str, Any] | None = None) -> int | None:
        for source in (change, msg):
            if not source:
                continue
            for key in ("timestamp", "ts", "sequence", "seq", "last_update", "lastUpdate"):
                value = cls._parse_int_like(source.get(key))
                if value is not None:
                    return value
        return None

    def _accept_sequence(self, symbol: str, seq: int | None) -> bool:
        if seq is None:
            return True
        prev = self._last_seq.get(symbol)
        # Polymarket market stream can emit multiple related updates sharing the same timestamp.
        # Drop only strictly older packets; allow equal timestamps to apply idempotently.
        if prev is not None and seq < prev:
            return False
        self._last_seq[symbol] = seq
        return True

    @classmethod
    def _price_to_ticks(cls, value: Any) -> int | None:
        return cls._to_fixed(value, cls._PRICE_SCALE)

    @classmethod
    def _size_to_units(cls, value: Any) -> int | None:
        return cls._to_fixed(value, cls._SIZE_SCALE)

    @classmethod
    def _ticks_to_price(cls, ticks: int) -> float:
        return ticks / cls._PRICE_SCALE

    @classmethod
    def _units_to_size(cls, units: int) -> float:
        return units / cls._SIZE_SCALE

    def _symbol_levels(self, symbol: str) -> dict[str, dict[int, int]]:
        state = self._levels.get(symbol)
        if state is None:
            state = {"a": {}, "b": {}}
            self._levels[symbol] = state
        return state

    def _record(
        self, *, symbol: str, side: str, price_ticks: int, size_units: int, alias: str | None
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {
            "s": symbol,
            "S": side,
            "p": self._ticks_to_price(price_ticks),
            "q": self._units_to_size(size_units),
        }
        if alias is not None:
            payload["alias"] = alias
        return payload

    def _delete_key(self, *, symbol: str, side: str, price_ticks: int) -> dict[str, Any]:
        return {"s": symbol, "S": side, "p": self._ticks_to_price(price_ticks)}

    def _snapshot_side(
        self,
        *,
        symbol: str,
        side: str,
        entries: Iterable[dict[str, Any]] | None,
        alias: str | None,
    ) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
        next_levels: dict[int, int] = {}
        if entries:
            for entry in entries:
                if not isinstance(entry, dict):
                    continue
                price_ticks = self._price_to_ticks(entry.get("price"))
                size_units = self._size_to_units(entry.get("size"))
                if price_ticks is None or size_units is None:
                    continue
                if size_units <= 0:
                    continue
                next_levels[price_ticks] = size_units

        symbol_levels = self._symbol_levels(symbol)
        prev_levels = symbol_levels[side]
        removals = [
            self._delete_key(symbol=symbol, side=side, price_ticks=price_ticks)
            for price_ticks in prev_levels
            if price_ticks not in next_levels
        ]
        updates = [
            self._record(
                symbol=symbol,
                side=side,
                price_ticks=price_ticks,
                size_units=size_units,
                alias=alias,
            )
            for price_ticks, size_units in next_levels.items()
            if prev_levels.get(price_ticks) != size_units
        ]
        symbol_levels[side] = next_levels
        return removals, updates

    def _on_message(self, msg: dict[str, Any]) -> None:
        msg_type = msg.get("event_type")
        if msg_type not in {"book", "price_change"}:
            return

        if msg_type == "book":
            asset_id = msg.get("asset_id") or msg.get("token_id")
            symbol, alias = self._alias(asset_id)
            if symbol is None:
                return
            if not self._accept_sequence(symbol, self._extract_timestamp(msg)):
                return
            bid_deletes, bid_updates = self._snapshot_side(
                symbol=symbol,
                side="b",
                entries=msg.get("bids"),
                alias=alias,
            )
            ask_deletes, ask_updates = self._snapshot_side(
                symbol=symbol,
                side="a",
                entries=msg.get("asks"),
                alias=alias,
            )

            deletes = bid_deletes + ask_deletes
            updates = bid_updates + ask_updates
            if deletes:
                self._delete(deletes)
            if updates:
                self._update(updates)
            return

        price_changes = msg.get("price_changes") or []
        grouped: dict[str, dict[str, Any]] = {}
        for change in price_changes:
            asset_id = change.get("asset_id") or change.get("token_id")
            symbol, alias = self._alias(asset_id)
            if symbol is None:
                continue
            bucket = grouped.setdefault(
                symbol,
                {"alias": alias, "changes": [], "seq": None},
            )
            if bucket["alias"] is None and alias is not None:
                bucket["alias"] = alias
            bucket["changes"].append(change)
            ts = self._extract_timestamp(msg, change)
            if ts is not None:
                cur = bucket["seq"]
                bucket["seq"] = ts if cur is None else max(cur, ts)

        updates: dict[tuple[str, str, int], dict[str, Any]] = {}
        removals: dict[tuple[str, str, int], dict[str, Any]] = {}
        for symbol, bucket in grouped.items():
            if not self._accept_sequence(symbol, bucket["seq"]):
                continue
            alias = bucket["alias"]
            symbol_levels = self._symbol_levels(symbol)
            for change in bucket["changes"]:
                side = "b" if str(change.get("side") or "").upper() == "BUY" else "a"
                price_ticks = self._price_to_ticks(change.get("price"))
                size_units = self._size_to_units(change.get("size"))
                if price_ticks is None or size_units is None:
                    continue
                side_levels = symbol_levels[side]
                key = (symbol, side, price_ticks)

                if size_units <= 0:
                    if price_ticks in side_levels:
                        side_levels.pop(price_ticks, None)
                        removals[key] = self._delete_key(
                            symbol=symbol, side=side, price_ticks=price_ticks
                        )
                        updates.pop(key, None)
                    continue

                if side_levels.get(price_ticks) == size_units:
                    continue
                side_levels[price_ticks] = size_units
                updates[key] = self._record(
                    symbol=symbol,
                    side=side,
                    price_ticks=price_ticks,
                    size_units=size_units,
                    alias=alias,
                )
                removals.pop(key, None)

        if removals:
            self._delete(list(removals.values()))
        if updates:
            self._update(list(updates.values()))

    def sorted(
        self, query: Item | None = None, limit: int | None = None
    ) -> dict[str, list[Item]]:
        if query is None:
            query = {}

        if any(k not in {"s", "S", "alias"} for k in query):
            return self._sorted(
                item_key="S",
                item_asc_key="a",
                item_desc_key="b",
                sort_key="p",
                query=query,
                limit=limit,
            )

        symbol = query.get("s")
        if symbol is None:
            return self._sorted(
                item_key="S",
                item_asc_key="a",
                item_desc_key="b",
                sort_key="p",
                query=query,
                limit=limit,
            )

        symbol_levels = self._levels.get(str(symbol))
        if symbol_levels is None:
            return {"a": [], "b": []}

        alias = self.id_to_alias.get(str(symbol))
        alias_query = query.get("alias")
        if alias_query is not None and alias != alias_query:
            return {"a": [], "b": []}

        side_query = query.get("S")
        if side_query in {"a", "b"}:
            sides = [side_query]
        else:
            sides = ["a", "b"]

        result: dict[str, list[Item]] = {"a": [], "b": []}
        for side in sides:
            side_levels = symbol_levels.get(side, {})
            if not side_levels:
                continue
            ordered_prices = sorted(side_levels) if side == "a" else sorted(side_levels, reverse=True)
            if limit is not None:
                ordered_prices = ordered_prices[:limit]
            rows: list[Item] = []
            for price_ticks in ordered_prices:
                row: dict[str, Any] = {
                    "s": str(symbol),
                    "S": side,
                    "p": self._ticks_to_price(price_ticks),
                    "q": self._units_to_size(side_levels[price_ticks]),
                }
                if alias is not None:
                    row["alias"] = alias
                rows.append(row)
            result[side] = rows
        return result

class Price(DataStore):
    _KEYS = ["s"]

    def _on_message(self, msg: dict[str, Any]) -> None:
        payload = msg.get('payload') or {}
        data = payload.get('data') or {}
        symbol = payload.get('symbol')

        if not symbol:
            return
        
        _next = self.get({'s': symbol}) or {}
        _next_price = _next.get('p')
        last_price = None
        
        if data and isinstance(data, list):
            last_price = data[-1].get('value')
        if 'value' in payload:
            last_price = payload.get('value')
        
        if last_price is None:
            return

        record = {'s': symbol, 'p': last_price}
        key = {'s': symbol}
        if self.get(key):
            self._update([record])
        else:
            self._insert([record])


class BBO(DataStore):
    _KEYS = ["s", "S"]

    def _init(self) -> None:
        self.id_to_alias: dict[str, str] = {}
        self._levels: dict[str, dict[str, dict[int, int]]] = {}
        self._best: dict[str, dict[str, tuple[int, int] | None]] = {}
        self._last_seq: dict[str, int] = {}

    def update_aliases(self, mapping: dict[str, str]) -> None:
        if not mapping:
            return
        self.id_to_alias.update(mapping)

    def _alias(self, asset_id: str | None) -> tuple[str, str | None] | tuple[None, None]:
        if asset_id is None:
            return None, None
        alias = self.id_to_alias.get(asset_id)
        return asset_id, alias

    def _symbol_levels(self, symbol: str) -> dict[str, dict[int, int]]:
        state = self._levels.get(symbol)
        if state is None:
            state = {"a": {}, "b": {}}
            self._levels[symbol] = state
        return state

    def _symbol_best(self, symbol: str) -> dict[str, tuple[int, int] | None]:
        state = self._best.get(symbol)
        if state is None:
            state = {"a": None, "b": None}
            self._best[symbol] = state
        return state

    @staticmethod
    def _format_scaled(units: int, scale: int) -> str:
        neg = units < 0
        value = -units if neg else units
        whole = value // scale
        frac = value % scale
        if frac == 0:
            out = str(whole)
        else:
            width = len(str(scale)) - 1
            frac_str = f"{frac:0{width}d}".rstrip("0")
            out = f"{whole}.{frac_str}"
        return f"-{out}" if neg else out

    @classmethod
    def _price_to_str(cls, ticks: int) -> str:
        return cls._format_scaled(ticks, Book._PRICE_SCALE)

    @classmethod
    def _size_to_str(cls, units: int) -> str:
        return cls._format_scaled(units, Book._SIZE_SCALE)

    def _accept_sequence(self, symbol: str, seq: int | None) -> bool:
        if seq is None:
            return True
        prev = self._last_seq.get(symbol)
        # Same-timestamp updates are common in market stream bursts; keep them.
        if prev is not None and seq < prev:
            return False
        self._last_seq[symbol] = seq
        return True

    def _recompute_best(self, symbol: str, side: str) -> None:
        levels = self._symbol_levels(symbol)[side]
        best_state = self._symbol_best(symbol)
        if not levels:
            best_state[side] = None
            return
        best_tick = min(levels) if side == "a" else max(levels)
        best_state[side] = (best_tick, levels[best_tick])

    def _sync_side(self, symbol: str, side: str, alias: str | None) -> None:
        key = {"s": symbol, "S": side}
        current = self.get(key)
        best = self._symbol_best(symbol).get(side)

        if best is None:
            if current:
                self._delete([key])
            return

        price_ticks, size_units = best
        payload = {
            "s": symbol,
            "S": side,
            "p": self._price_to_str(price_ticks),
            "q": self._size_to_str(size_units),
        }
        if alias is not None:
            payload["alias"] = alias

        if current:
            cur_price = str(current.get("p"))
            cur_size = str(current.get("q"))
            cur_alias = current.get("alias")
            new_price = payload["p"]
            new_size = payload["q"]

            if cur_price == new_price:
                # price unchanged -> only update quantities / alias changes
                if cur_size != new_size or (alias is not None and cur_alias != alias):
                    self._update([payload])
                return

            # price changed -> delete old then insert new level to trigger change watchers
            self._delete([key])

        self._insert([payload])

    def _sync_symbol(self, symbol: str, alias: str | None) -> None:
        self._sync_side(symbol, "a", alias)
        self._sync_side(symbol, "b", alias)

    @staticmethod
    def _parse_levels(entries: Iterable[dict[str, Any]] | None) -> dict[int, int]:
        out: dict[int, int] = {}
        if not entries:
            return out
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            price_ticks = Book._price_to_ticks(entry.get("price"))
            size_units = Book._size_to_units(entry.get("size"))
            if price_ticks is None or size_units is None:
                continue
            if price_ticks <= 0 or size_units <= 0:
                continue
            out[price_ticks] = size_units
        return out

    def _from_price_changes(self, msg: dict[str, Any]) -> None:
        price_changes = msg.get("price_changes") or []
        grouped: dict[str, dict[str, Any]] = {}
        for change in price_changes:
            asset_id = change.get("asset_id") or change.get("token_id")
            symbol, alias = self._alias(asset_id)
            if symbol is None:
                continue
            bucket = grouped.setdefault(
                symbol,
                {"alias": alias, "changes": [], "seq": None, "touched_sides": set()},
            )
            if bucket["alias"] is None and alias is not None:
                bucket["alias"] = alias
            bucket["changes"].append(change)
            ts = Book._extract_timestamp(msg, change)
            if ts is not None:
                cur = bucket["seq"]
                bucket["seq"] = ts if cur is None else max(cur, ts)

        for symbol, bucket in grouped.items():
            if not self._accept_sequence(symbol, bucket["seq"]):
                continue
            levels = self._symbol_levels(symbol)
            touched_sides: set[str] = bucket["touched_sides"]
            for change in bucket["changes"]:
                side = "b" if str(change.get("side") or "").upper() == "BUY" else "a"
                price_ticks = Book._price_to_ticks(change.get("price"))
                size_units = Book._size_to_units(change.get("size"))
                if price_ticks is None or size_units is None or price_ticks <= 0:
                    continue
                touched_sides.add(side)
                side_levels = levels[side]
                if size_units <= 0:
                    side_levels.pop(price_ticks, None)
                else:
                    side_levels[price_ticks] = size_units

            for side in touched_sides:
                self._recompute_best(symbol, side)
            self._sync_symbol(symbol, bucket["alias"])

    def _from_snapshot(self, msg: dict[str, Any]) -> None:
        asset_id = msg.get("asset_id") or msg.get("token_id")
        symbol, alias = self._alias(asset_id)
        if symbol is None:
            return
        if not self._accept_sequence(symbol, Book._extract_timestamp(msg)):
            return
        levels = self._symbol_levels(symbol)
        levels["a"] = self._parse_levels(msg.get("asks"))
        levels["b"] = self._parse_levels(msg.get("bids"))
        self._recompute_best(symbol, "a")
        self._recompute_best(symbol, "b")
        self._sync_symbol(symbol, alias)

    def _apply_best_side_event(
        self,
        *,
        symbol: str,
        side: str,
        price_value: Any,
        size_value: Any,
    ) -> None:
        levels = self._symbol_levels(symbol)[side]
        price_ticks = Book._price_to_ticks(price_value)

        if price_ticks is None or price_ticks <= 0:
            levels.clear()
            self._symbol_best(symbol)[side] = None
            return

        if size_value is not None:
            size_units = Book._size_to_units(size_value)
            if size_units is None or size_units <= 0:
                levels.clear()
                self._symbol_best(symbol)[side] = None
                return
            levels.clear()
            levels[price_ticks] = size_units
            self._symbol_best(symbol)[side] = (price_ticks, size_units)
            return

        # Keep last known top size when best_bid_ask omits size.
        fallback = levels.get(price_ticks)
        if fallback is None:
            fallback_best = self._symbol_best(symbol).get(side)
            if fallback_best is None:
                return
            fallback = fallback_best[1]
        levels.clear()
        levels[price_ticks] = fallback
        self._symbol_best(symbol)[side] = (price_ticks, fallback)

    def _from_best_bid_ask(self, msg: dict[str, Any]) -> None:
        asset_id = msg.get("asset_id") or msg.get("token_id")
        symbol, alias = self._alias(asset_id)
        if symbol is None:
            return
        if not self._accept_sequence(symbol, Book._extract_timestamp(msg)):
            return

        bid_size = None
        for key in ("best_bid_size", "bid_size"):
            if msg.get(key) not in (None, ""):
                bid_size = msg.get(key)
                break

        ask_size = None
        for key in ("best_ask_size", "ask_size"):
            if msg.get(key) not in (None, ""):
                ask_size = msg.get(key)
                break

        self._apply_best_side_event(
            symbol=symbol,
            side="b",
            price_value=msg.get("best_bid"),
            size_value=bid_size,
        )
        self._apply_best_side_event(
            symbol=symbol,
            side="a",
            price_value=msg.get("best_ask"),
            size_value=ask_size,
        )
        self._sync_symbol(symbol, alias)

    def _on_message(self, msg: dict[str, Any]) -> None:
        msg_type = (msg.get("event_type") or msg.get("type") or "").lower()
        if msg_type == "book":
            self._from_snapshot(msg)
        elif msg_type == "price_change":
            self._from_price_changes(msg)
        elif msg_type == "best_bid_ask":
            self._from_best_bid_ask(msg)


class Detail(DataStore):
    """Market metadata keyed by Polymarket token id."""

    _KEYS = ["token_id"]

    @staticmethod
    def _normalize_entry(market: dict[str, Any], token: dict[str, Any]) -> dict[str, Any]:
        slug = market.get("slug")
        outcome = token.get("outcome")
        alias = slug if outcome is None else f"{slug}:{outcome}"

        tick_size = (
            market.get("minimum_tick_size")
            or market.get("orderPriceMinTickSize")
            or market.get("order_price_min_tick_size")
        )
        step_size = (
            market.get("minimum_order_size")
            or market.get("orderMinSize")
            or market.get("order_min_size")
        )

        try:
            tick_size = float(tick_size) if tick_size is not None else None
        except (TypeError, ValueError):
            tick_size = None
        try:
            step_size = float(step_size) if step_size is not None else None
        except (TypeError, ValueError):
            step_size = None

        return {
            "token_id": token.get("token_id") or token.get("id"),
            "asset_id": token.get("token_id") or token.get("id"),
            "alias": alias,
            "question": market.get("question"),
            "outcome": outcome,
            "active": market.get("active"),
            "closed": market.get("closed"),
            "neg_risk": market.get("neg_risk"),
            "tick_size": tick_size if tick_size is not None else 0.01,
            "step_size": step_size if step_size is not None else 1.0,
            "minimum_order_size": step_size if step_size is not None else 1.0,
            "minimum_tick_size": tick_size if tick_size is not None else 0.01,
        }

    def on_response(self, markets: Iterable[dict[str, Any]]) -> dict[str, str]:
        mapping: dict[str, str] = {}
        records: list[dict[str, Any]] = []
        for market in markets or []:
            tokens = market.get("tokens") or []
            if not tokens:
                token_ids = market.get("clobTokenIds") or []
                outcomes = market.get("outcomes") or []

                if isinstance(token_ids, str):
                    try:
                        token_ids = json.loads(token_ids)
                    except json.JSONDecodeError:
                        token_ids = [token_ids]
                if isinstance(outcomes, str):
                    try:
                        outcomes = json.loads(outcomes)
                    except json.JSONDecodeError:
                        outcomes = [outcomes]

                if not isinstance(token_ids, list):
                    token_ids = [token_ids]
                if not isinstance(outcomes, list):
                    outcomes = [outcomes]

                tokens = [
                    {"token_id": tid, "outcome": outcomes[idx] if idx < len(outcomes) else None}
                    for idx, tid in enumerate(token_ids)
                    if tid
                ]

            for token in tokens:
                normalized = self._normalize_entry(market, token)
                slug: str = market.get("slug")
                # 取最后一个'-'之前部分
                base_slug = slug.rsplit("-", 1)[0] if slug else slug
                # Add or update additional fields from market
                normalized.update({
                    "condition_id": market.get("conditionId"),
                    "slug": market.get("slug"),
                    "base_slug": base_slug,
                    "end_date": market.get("endDate"),
                    "start_date": market.get("startDate"),
                    "icon": market.get("icon"),
                    "image": market.get("image"),
                    "liquidity": market.get("liquidityNum") or market.get("liquidity"),
                    "volume": market.get("volumeNum") or market.get("volume"),
                    "accepting_orders": market.get("acceptingOrders"),
                    "spread": market.get("spread"),
                    "best_bid": market.get("bestBid"),
                    "best_ask": market.get("bestAsk"),
                })
                token_id = normalized.get("token_id")
                if not token_id:
                    continue
                records.append(normalized)
                mapping[token_id] = normalized.get("alias") or token_id

        self._update(records)
        return mapping

    def _on_ws_message(self, msg: dict[str, Any]) -> None:
        msg_type = str(msg.get("event_type") or msg.get("type") or "").lower()
        token_id = msg.get("asset_id") or msg.get("token_id")
        if not token_id:
            return

        update: dict[str, Any] = {"token_id": token_id, "asset_id": token_id}
        changed = False

        if msg_type == "tick_size_change":
            tick = msg.get("new_tick_size")
            try:
                tick = float(tick) if tick is not None else None
            except (TypeError, ValueError):
                tick = None
            if tick is not None:
                update["tick_size"] = tick
                update["minimum_tick_size"] = tick
                changed = True

        if msg_type == "best_bid_ask":
            for src, dst in (("best_bid", "best_bid"), ("best_ask", "best_ask"), ("spread", "spread")):
                value = msg.get(src)
                try:
                    value = float(value) if value is not None else None
                except (TypeError, ValueError):
                    value = None
                if value is not None:
                    update[dst] = value
                    changed = True

        if not changed:
            return
        self._update([update])


class PolymarketDataStore(DataStoreCollection):
    """Polymarket-specific DataStore aggregate."""

    def _init(self) -> None:
        self._create("book", datastore_class=Book)
        self._create("bbo", datastore_class=BBO)
        self._create("detail", datastore_class=Detail)
        self._create("position", datastore_class=Position)
        self._create("order", datastore_class=Order)
        self._create("mytrade", datastore_class=MyTrade)
        self._create("fill", datastore_class=Fill)
        self._create("trade", datastore_class=Trade)
        self._create("price", datastore_class=Price)

    def set_owner_key(self, api_key: str | None) -> None:
        self.position.set_owner_key(api_key)

    @property
    def book(self) -> Book:
        """Order Book DataStore
        _key: s (asset_id), S (side), p (price)

        .. code:: json
            [{
                "s": "asset_id",
                "S": "b" | "a",
                "p": "price",
                "q": "size"
            }]
        """
        return self._get("book")

    @property
    def detail(self) -> Detail:
        """
        Market metadata keyed by token id.

        .. code:: json
            
            [
                {
                    "token_id": "14992165475527298486519422865149275159537493330633013685269145597531945526992",
                    "asset_id": "14992165475527298486519422865149275159537493330633013685269145597531945526992",
                    "alias": "Bitcoin Up or Down - November 12, 12:30AM-12:45AM ET:Down",
                    "question": "Bitcoin Up or Down - November 12, 12:30AM-12:45AM ET",
                    "outcome": "Down",
                    "active": true,
                    "closed": false,
                    "neg_risk": null,
                    "tick_size": 0.01,
                    "step_size": 5.0,
                    "minimum_order_size": 5.0,
                    "minimum_tick_size": 0.01,
                    "condition_id": "0xb64133e5ae9710fab2533cfd3c48cba142347e4bab36822964ca4cca4b7660d2",
                    "slug": "btc-updown-15m-1762925400",
                    "end_date": "2025-11-12T05:45:00Z",
                    "start_date": "2025-11-11T05:32:59.491174Z",
                    "icon": "https://polymarket-upload.s3.us-east-2.amazonaws.com/BTC+fullsize.png",
                    "image": "https://polymarket-upload.s3.us-east-2.amazonaws.com/BTC+fullsize.png",
                    "liquidity": 59948.1793,
                    "volume": 12214.600385,
                    "accepting_orders": true,
                    "spread": 0.01,
                    "best_bid": 0.5,
                    "best_ask": 0.51
                }
            ]
        """

        return self._get("detail")
    
    @property
    def position(self) -> Position:
        """
        User inventory snapshot keyed by ``asset`` (token id), updated from
        authenticated User WS ``trade`` events only.

        Notes:
        - Data source: user WS trade events (MATCHED/MINED/CONFIRMED/FAILED).
        - Order stream and REST position sync do not drive inventory.
        - Maker fills are owner-filtered by api key; reconnect duplicates are deduped.
        - FAILED events reverse prior inventory impact.

        .. code:: json
            {
                "asset": "15425820309554596073938947961054885346747932482195187699753650361958599405318",  // token id
                "outcome": "Yes",            // 当前asset对应的outcome名称
                "size": 5.0,                 // 当前asset仓位数量（对应 yes_qty 或 no_qty）
                "avgPrice": 0.47,            // 当前asset均价
                "totalAvgPrice": 0.47,       // 与 avgPrice 同步，兼容旧字段
                "market": "0x...",           // conditionId / market id
                "yes_qty": 5.0,              // YES腿数量
                "no_qty": 3.0,               // NO腿数量
                "yes_avg_cost": 0.47,        // YES腿VWAP成本
                "no_avg_cost": 0.49,         // NO腿VWAP成本
                "cash_flow": -0.88,          // 交易净现金流(买入为负,卖出为正), FAILED会反向回滚
                "open_cost": 3.82,           // 当前未平仓持仓成本 = yes_qty*yes_avg_cost + no_qty*no_avg_cost
                "realized_pnl": 2.94,        // 已实现盈亏 = cash_flow + open_cost
                "pnl_if_yes_win": 4.12,      // 若YES结算为1、NO归零时的最终盈亏
                "pnl_if_no_win": 2.12,       // 若NO结算为1、YES归零时的最终盈亏
                "max_loss": 2.12,            // 两种结算情景下的较差结果
                "best_case_pnl": 4.12,       // 两种结算情景下的较优结果
                "expected_pnl_if_win": 4.12, // 对当前asset而言,该outcome获胜时的预期最终盈亏
                "expected_pnl_if_lose": 2.12,// 对当前asset而言,该outcome落败时的预期最终盈亏
                "net_diff": 2.0,             // 净敞口 = yes_qty - no_qty
                "portfolio_cost": 0.96,      // 组合成本 = yes_avg_cost + no_avg_cost（双腿都有仓时）
                "ts": 1772269014393,         // 本地更新时间戳(ms)
                "source": "user_ws_trade"    // 数据来源标记
            }
        """

        return self._get("position")

    @property
    def orders(self) -> Order:
        """User orders keyed by order id.

        Example row (from REST get_orders):

        .. code:: json
            {
              "id": "0xd4359d…",
              "status": "LIVE",
              "owner": "<api-key>",
              "maker_address": "0x…",
              "market": "0x…",
              "asset_id": "317234…",
              "side": "BUY",
              "original_size": 5.0,
              "size_matched": 0.0,
              "price": 0.02,
              "outcome": "Up",
              "order_type": "GTC",
              "created_at": 1762912331
            }

        """

        return self._get("order")

    @property
    def mytrade(self) -> MyTrade:
        """User trade stream keyed by trade id.

        Columns include Polymarket websocket ``trade`` payloads, e.g.

        .. code:: json
            {
                "event_type": "trade",
                "id": "28c4d2eb-bbea-40e7-a9f0-b2fdb56b2c2e",
                "market": "0xbd31…",
                "asset_id": "521143…",
                "side": "BUY",
                "price": 0.57,
                "size": 10,
                "status": "MATCHED",
                "maker_orders": [ ... ]
            }
        """

        return self._get("mytrade")
    
    @property
    def price(self) -> Price:
        """Price DataStore
        _key: s 
        """
        return self._get("price")

    @property
    def fill(self) -> Fill:
        """Maker-order fills keyed by ``order_id``.

        A row is created whenever a trade arrives with ``status == 'MATCHED'``.
        ``matched_amount`` and ``price`` are stored as floats for quick PnL math.

        .. code:: json
            {
                "order_id": "0xb46574626be7eb57a8fa643eac5623bdb2ec42104e2dc3441576a6ed8d0cc0ed",
                "owner": "1aa9c6be-02d2-c021-c5fc-0c5b64ba8fd6",
                "maker_address": "0x64A46A989363eb21DAB87CD53d57A4567Ccbc103",
                "matched_amount": "1.35",
                "price": "0.73",
                "fee_rate_bps": "0",
                "asset_id": "60833383978754019365794467018212448484210363665632025956221025028271757152271",
                "outcome": "Up",
                "outcome_index": 0,
                "side": "BUY"
            }
        """

        return self._get("fill")
    
    @property
    def bbo(self) -> BBO:
        """Best Bid and Offer DataStore
        _key: s (asset_id), S (side)

        Notes:
        - Derived from `book` / `price_change`.
        - When `best_bid_ask` omits size, the last known top-level size is preserved.

        """
        return self._get("bbo")
    
    @property
    def trade(self) -> Trade:
        """
        _key asset
        .. code:: json
           {

            }
        """
        return self._get("trade")
    

    def onmessage(self, msg: Any, ws: ClientWebSocketResponse | None = None) -> None:
        # 判定msg是否为list
        lst_msg = msg if isinstance(msg, list) else [msg]
        for m in lst_msg:
            if m == '':
                continue
            topic = m.get("topic") or ""
            if topic in {'crypto_prices_chainlink', 'crypto_prices'}:
                self.price._on_message(m)
                continue
            raw_type = m.get("event_type") or m.get("type")
            if not raw_type:
                continue
            msg_type = str(raw_type).lower()
            if msg_type in {"book", "price_change"}:
                self.book._on_message(m)
                self.bbo._on_message(m)
            elif msg_type == "best_bid_ask":
                self.bbo._on_message(m)
                self.detail._on_ws_message(m)
            elif msg_type == "tick_size_change":
                self.detail._on_ws_message(m)
            elif msg_type == "order":
                self.orders._on_message(m)

            elif msg_type == "trade":
                self.mytrade._on_message(m)
                self.position.on_trade(m)
            elif msg_type == 'orders_matched':
                payload = m.get("payload") or {}
                if not payload:
                    continue
                trade_msg = dict(payload)
                if "asset_id" not in trade_msg and "asset" in trade_msg:
                    trade_msg["asset_id"] = trade_msg["asset"]
                self.trade._on_message(trade_msg)
    
    def onmessage_for_bbo(self, msg: Any, ws: ClientWebSocketResponse | None = None) -> None:
        # 判定msg是否为list
        lst_msg = msg if isinstance(msg, list) else [msg]
        for m in lst_msg:
            raw_type = m.get("event_type") or m.get("type")
            if not raw_type:
                continue
            msg_type = str(raw_type).lower()
            if msg_type in {"book", "price_change", "best_bid_ask"}:
                self.bbo._on_message(m)
            if msg_type == "best_bid_ask":
                self.detail._on_ws_message(m)
            elif msg_type == "tick_size_change":
                self.detail._on_ws_message(m)

    def onmessage_for_last_trade(self, msg, ws = None):
        # 判定msg是否为list
        lst_msg = msg if isinstance(msg, list) else [msg]
        for m in lst_msg:
            raw_type = m.get("event_type") or m.get("type")
            if not raw_type:
                continue
            msg_type = str(raw_type).lower()
            if msg_type == "last_trade_price":
                self.trade._on_message(m)
