# 🎨 Color Palette Extractor

A modern Python package for extracting dominant colors from images, generating PNG palette previews, exporting color data to JSON, and naming colors using any custom palette (e.g., Pantone, Material, Brand palettes).

This package includes:
- Dominant color extraction using K-Means
- RGB or HEX output
- PNG color palette image generation
- JSON export
- Optional color naming using custom palettes (Pantone-compatible if you provide the licensed palette)
- Command-line interface (`colorpalette`)
- Clean import API for integration in other scripts

## Installation
Run:
```
pip install .
```

## CLI Usage
```
colorpalette input.jpg --colors 5 --format hex --json palette.json --png palette.png
```

## Color Naming
Provide a custom palette JSON:
```
colorpalette input.jpg --name-colors --palette pantone.json
```

## Python Usage
```
from color_palette_extractor import extract_palette
colors, names = extract_palette("image.jpg", num_colors=5, output_format="hex")
```

## Package Structure
color_palette_extractor/
- extractor.py
- palette_image.py
- utils.py
- color_naming.py
- cli.py
- __init__.py

## License
MIT License
