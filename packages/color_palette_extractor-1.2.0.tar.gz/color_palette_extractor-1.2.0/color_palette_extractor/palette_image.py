from PIL import Image, ImageDraw

def create_palette_image(colors, output_path="palette.png", swatch_size=100):
    def hex_to_rgb(h):
        h = h.lstrip('#')
        return tuple(int(h[i:i+2], 16) for i in (0,2,4))

    rgb_colors = [c if isinstance(c, tuple) else hex_to_rgb(c) for c in colors]

    width = swatch_size * len(rgb_colors)
    height = swatch_size

    img = Image.new("RGB", (width, height))
    draw = ImageDraw.Draw(img)

    for i, color in enumerate(rgb_colors):
        x0 = i * swatch_size
        draw.rectangle([x0, 0, x0+swatch_size, height], fill=color)

    img.save(output_path)
    return output_path
