import json

def save_palette_json(colors, output_path="palette.json", names=None, dominance=None):
    data = {"palette": colors}
    if dominance is not None:
        data["dominance"] = dominance
    if names:
        data["names"] = names
    with open(output_path, "w") as f:
        json.dump(data, f, indent=4)

def rgb_to_hex(rgb):
    return "#{:02x}{:02x}{:02x}".format(*rgb)
