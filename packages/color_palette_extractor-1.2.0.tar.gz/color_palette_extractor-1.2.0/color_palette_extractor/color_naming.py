from colormath.color_objects import sRGBColor, LabColor
from colormath.color_conversions import convert_color
from colormath.color_diff import delta_e_cie2000

def load_palette(palette_dict):
    formatted = {}
    for name, hex_value in palette_dict.items():
        hex_value = hex_value.lstrip('#')
        rgb = tuple(int(hex_value[i:i+2], 16) for i in (0,2,4))
        formatted[name] = rgb
    return formatted

def rgb_to_lab(rgb):
    r, g, b = rgb
    return convert_color(sRGBColor(r/255, g/255, b/255), LabColor)

def closest_color(rgb, palette):
    target = rgb_to_lab(rgb)
    best = None
    best_d = float('inf')
    for name, rgb2 in palette.items():
        d = delta_e_cie2000(target, rgb_to_lab(rgb2))
        if d < best_d:
            best_d = d
            best = name
    return best, best_d
