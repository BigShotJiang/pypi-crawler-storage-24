from PIL import Image
import numpy as np
from sklearn.cluster import KMeans
from .color_naming import closest_color, load_palette
from .utils import rgb_to_hex

def extract_palette(
    image_path,
    num_colors=5,
    output_format="rgb",
    naming_palette=None,
    ignore_white=False,
    ignore_black=False,
    white_threshold=240,
    black_threshold=15,
):
    img = Image.open(image_path).convert("RGB")
    img = img.resize((300, 300))
    flat = np.array(img).reshape(-1, 3)

    # Filter near-white and/or near-black pixels before clustering
    mask = np.ones(len(flat), dtype=bool)
    if ignore_white:
        mask &= ~np.all(flat >= white_threshold, axis=1)
    if ignore_black:
        mask &= ~np.all(flat <= black_threshold, axis=1)

    filtered = flat[mask]
    if len(filtered) < num_colors:
        filtered = flat  # fallback: not enough pixels remain after filtering

    kmeans = KMeans(n_clusters=num_colors, random_state=42)
    kmeans.fit(filtered)

    # Compute dominance from cluster label distribution
    labels = kmeans.labels_
    total = len(labels)
    raw_colors = [tuple(map(int, c)) for c in kmeans.cluster_centers_]
    raw_dominance = [
        round(float(np.sum(labels == i)) / total * 100, 2)
        for i in range(num_colors)
    ]

    # Sort by dominance descending so index 0 is the most dominant color
    pairs = sorted(zip(raw_colors, raw_dominance), key=lambda x: x[1], reverse=True)
    colors = [p[0] for p in pairs]
    dominance = [p[1] for p in pairs]

    if output_format == "hex":
        colors_out = [rgb_to_hex(c) for c in colors]
    else:
        colors_out = colors

    # Naming (optional)
    names = None
    if naming_palette:
        names = {}
        for c in colors:
            name, dist = closest_color(c, naming_palette)
            names[rgb_to_hex(c)] = name

    return colors_out, names, dominance
