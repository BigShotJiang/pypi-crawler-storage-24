import argparse, json
from .extractor import extract_palette
from .palette_image import create_palette_image
from .utils import save_palette_json
from .color_naming import load_palette

def main():
    p = argparse.ArgumentParser(description="Extract image color palette.")
    p.add_argument("image_path")
    p.add_argument("--colors", type=int, default=5)
    p.add_argument("--format", choices=["rgb", "hex"], default="rgb")
    p.add_argument("--json")
    p.add_argument("--png")
    p.add_argument("--name-colors", action="store_true")
    p.add_argument("--palette", help="Path to palette JSON (Pantone or other)")
    p.add_argument("--ignore-white", action="store_true", help="Exclude near-white pixels from palette extraction")
    p.add_argument("--ignore-black", action="store_true", help="Exclude near-black pixels from palette extraction")
    p.add_argument("--white-threshold", type=int, default=240, help="RGB threshold above which a pixel is considered white (default: 240)")
    p.add_argument("--black-threshold", type=int, default=15, help="RGB threshold below which a pixel is considered black (default: 15)")
    args = p.parse_args()

    naming = None
    if args.name_colors and args.palette:
        naming = load_palette(json.load(open(args.palette)))

    colors, names, dominance = extract_palette(
        args.image_path,
        args.colors,
        args.format,
        naming,
        ignore_white=args.ignore_white,
        ignore_black=args.ignore_black,
        white_threshold=args.white_threshold,
        black_threshold=args.black_threshold,
    )

    print("Extracted colors (sorted by dominance):")
    for color, pct in zip(colors, dominance):
        print(f"  {color}  {pct}%")

    if names:
        print("Color names:")
        print(names)

    if args.json:
        save_palette_json(colors, args.json, names, dominance)
        print(f"Saved JSON -> {args.json}")

    if args.png:
        create_palette_image(colors, args.png)
        print(f"Saved PNG -> {args.png}")
