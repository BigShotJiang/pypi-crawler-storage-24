"""Kernel: version, dmesg, modules, bootlog, sysctl."""
import os, re, subprocess
from .utils import *

def _sh(cmd):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
        return r.stdout.strip()
    except: return ""

def cmd_kernel_info(args):
    section('Kernel Info'); print()
    serial = getattr(args,'serial',None)

    # /proc/version — try direct, then getprop, then uname
    ver = ''
    try: ver = open('/proc/version').read().strip()
    except: pass
    if not ver: ver = _sh('uname -a 2>/dev/null')
    if not ver: ver, _, _ = adb_cmd(['shell','uname','-a'], serial=serial)
    if not ver: ver = _sh('getprop ro.build.version.release 2>/dev/null')

    if ver:
        m = re.search(r'Linux version ([\d.\-\w]+)', ver)
        kver = m.group(1) if m else ver[:80]
        print(f"  {c(B,'Version:  ')} {c(GRN+B, kver)}")
        gcc = re.search(r'gcc[- ]version ([\d.\-\w]+)', ver, re.I)
        if gcc: print(f"  {c(B,'GCC:      ')} {c(DIM, gcc.group(1))}")
    else:
        # Last resort: getprop
        kver = _sh('getprop ro.build.kernel.id 2>/dev/null')
        if kver: print(f"  {c(B,'Kernel ID:')} {c(GRN, kver)}")
        else: warn("Cannot read kernel version")

    # Hardware info from cpuinfo or getprop
    hw = ''
    try:
        ci = open('/proc/cpuinfo').read()
        m  = re.search(r'Hardware\s*:\s*(.+)', ci)
        if m: hw = m.group(1).strip()
    except: pass
    if not hw: hw = _sh('getprop ro.hardware 2>/dev/null')
    if hw: print(f"  {c(B,'Hardware: ')} {c(WHT, hw)}")

    # Board platform
    plat = _sh('getprop ro.board.platform 2>/dev/null')
    if plat: print(f"  {c(B,'Platform: ')} {c(CYN, plat)}")

    # Boot cmdline
    cmdline = ''
    try: cmdline = open('/proc/cmdline').read().strip()
    except: pass
    if not cmdline: cmdline, _, _ = adb_cmd(['shell','cat','/proc/cmdline'], serial=serial)
    if cmdline:
        print(f"\n  {c(B,'Boot cmdline:')}")
        for part in cmdline.split():
            if any(k in part for k in ['androidboot','ro.','selinux','console','init']):
                print(f"    {c(CYN, part)}")
            else:
                print(f"    {c(DIM, part)}")
    print()

def cmd_dmesg(args):
    section('Kernel Ring Buffer (dmesg)'); print()
    serial = getattr(args,'serial',None)
    n      = getattr(args,'n', 50)
    filt   = getattr(args,'filter',None)
    level  = (getattr(args,'level',None) or '').lower()

    out = _sh('dmesg 2>/dev/null')
    # Check if output is actually a "su not found" message, not real dmesg
    if out and 'Termux' in out and 'rooting' in out: out = ''
    if not out: out = _sh('su -c "dmesg" 2>/dev/null')
    if out and 'Termux' in out and 'rooting' in out: out = ''
    if not out: out, _, _ = adb_cmd(['shell','dmesg'], serial=serial)
    if not out:
        err("Cannot read dmesg — needs root or ADB")
        info("Connect via ADB or root the device first")
        print(); return

    lines = out.split('\n')
    if filt:        lines = [l for l in lines if filt.lower() in l.lower()]
    if level == 'err':  lines = [l for l in lines if re.search(r'\b(error|err|crit|emerg|alert)\b',l,re.I)]
    elif level == 'warn': lines = [l for l in lines if re.search(r'\b(warn|error|crit)\b',l,re.I)]

    for line in lines[-n:]:
        col = RED  if re.search(r'\b(error|crit|emerg|BUG|oops|panic)\b',line,re.I) else \
              YLW  if re.search(r'\b(warn|fail)\b',line,re.I) else DIM
        print(f"  {c(col,line)}")
    print()

def cmd_modules(args):
    section('Kernel Modules'); print()
    serial = getattr(args,'serial',None)
    filt   = getattr(args,'filter',None)

    out = ''
    try: out = open('/proc/modules').read()
    except: pass
    if out and 'Termux' in out and 'rooting' in out: out = ''
    if not out: out = _sh('su -c "cat /proc/modules" 2>/dev/null')
    if out and 'Termux' in out and 'rooting' in out: out = ''
    if not out: out, _, _ = adb_cmd(['shell','cat','/proc/modules'], serial=serial)
    if not out:
        err("Cannot read modules — needs root or ADB")
        print(); return

    count = 0
    for line in sorted(out.split('\n')):
        if not line.strip(): continue
        if filt and filt.lower() not in line.lower(): continue
        p     = line.split()
        name  = p[0] if p else '?'
        size  = p[1] if len(p)>1 else ''
        state = p[4] if len(p)>4 else ''
        col   = GRN if state=='Live' else YLW if state=='Loading' else DIM
        try: sz = f"{int(size)//1024}KB"
        except: sz = size
        print(f"  {c(CYN,name):<30} {c(DIM,sz):<10} {c(col,state)}")
        count += 1
    print(f"\n  {c(B,str(count))} modules\n")

def cmd_bootlog(args):
    section('Boot Log (ramoops)'); print()
    n = getattr(args,'n',80)
    paths = ['/sys/fs/pstore/console-ramoops-0',
             '/sys/fs/pstore/console-ramoops',
             '/proc/last_kmsg']
    for p in paths:
        try:
            data  = open(p).read()
            lines = data.split('\n')
            print(f"  {c(DIM,'Source: '+p)}\n")
            for line in lines[-n:]:
                col = RED if re.search(r'error|panic',line,re.I) else \
                      YLW if 'warn' in line.lower() else DIM
                print(f"  {c(col,line)}")
            print(); return
        except: continue
    warn("No ramoops/last_kmsg found (needs root or specific kernel config)")
    print()

def cmd_sysctl(args):
    section('Kernel Parameters (sysctl)'); print()
    serial = getattr(args,'serial',None)
    filt   = getattr(args,'filter',None)
    import subprocess as _sp, os

    def _rd(p):
        try:
            v = open(p).read().strip()
            if '\n' not in v and len(v) < 200: return v
        except: pass
        return None

    def _sh(cmd):
        try:
            r = _sp.run(cmd, shell=True, capture_output=True, text=True, timeout=20)
            return (r.stdout + r.stderr).strip()
        except: return ''

    params = {}

    # Strategy 1: walk /proc/sys — reliable, no subprocess buffering issues
    # If filter given, only walk that subtree for speed
    if filt:
        # Map common filter names to /proc/sys subdirs
        subdir_map = {
            'net': 'net', 'vm': 'vm', 'kernel': 'kernel',
            'fs': 'fs', 'dev': 'dev', 'abi': 'abi',
        }
        walk_root = '/proc/sys'
        for k, v in subdir_map.items():
            if filt.lower() == k:
                walk_root = f'/proc/sys/{v}'
                break
        walk_roots = [walk_root]
    else:
        walk_roots = ['/proc/sys']

    for wr in walk_roots:
        try:
            for root, dirs, files in os.walk(wr):
                dirs.sort()
                for fname in sorted(files):
                    fpath = os.path.join(root, fname)
                    key   = fpath[len('/proc/sys/'):].replace('/','.')
                    val   = _rd(fpath)
                    if val is not None:
                        params[key] = val
        except: pass

    # Strategy 2: sysctl -a as supplement
    out = _sh('sysctl -a 2>/dev/null')
    if out and '=' in out:
        for line in out.splitlines():
            line = line.strip()
            if not line or line.startswith('sysctl:'): continue
            if ' = ' in line: k, _, v = line.partition(' = ')
            elif '=' in line: k, _, v = line.partition('=')
            else: continue
            k = k.strip(); v = v.strip()
            if k and k not in params: params[k] = v

    # ADB fallback
    if not params:
        out, _, _ = adb_cmd(['shell','sysctl','-a'], serial=serial)
        if out and '=' in out:
            for line in out.splitlines():
                if ' = ' in line:
                    k, _, v = line.partition(' = ')
                    params[k.strip()] = v.strip()

    if not params:
        err('sysctl not accessible on this device')
        print(); return

    count = 0
    for k in sorted(params):
        v = params[k]
        if filt and filt.lower() not in k.lower(): continue
        col = CYN if k.startswith('net.') else YLW if k.startswith('vm.') else GRN if k.startswith('kernel.') else DIM
        print(f"  {c(col,k):<52} {c(WHT,str(v)[:68])}")
        count += 1
    print()
    print(f"  {c(B,str(count))} parameters")
    print()
