"""Logcat analyzer, crash detector, battery, memory."""
import os, re, glob, subprocess
from .utils import *

def _sh(cmd):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
        return r.stdout.strip()
    except: return ""

def cmd_crash(args):
    serial = getattr(args, 'serial', None)
    lines  = getattr(args, 'lines', None) or 5000
    section('Crash & ANR Detector'); print()
    sp = Spinner('Reading logcat...'); sp.start()
    out, _, _ = adb_cmd(['logcat', '-d', '-t', str(lines), '-v', 'time'], serial=serial)
    # On-device fallback (works in Termux without ADB)
    if not out:
        import subprocess as _sp
        try:
            r = _sp.run(['logcat', '-d', '-t', str(lines), '-v', 'time'],
                        capture_output=True, text=True, timeout=30)
            out = r.stdout
        except: pass
    sp.stop()
    if not out: err("No logcat output — try: pkg install android-tools"); print(); return

    crashes = []; anrs = []; exceptions = []
    current_block = []; in_block = False
    for line in out.split('\n'):
        # Real crash markers only — avoid false positives from normal AndroidRuntime startup
        is_crash = ('FATAL EXCEPTION' in line or
                    ('AndroidRuntime' in line and 'FATAL' in line) or
                    ('Process:' in line and ', PID:' in line and in_block) or
                    'CRASH' in line)
        if is_crash:
            in_block = True; current_block = [line]
        elif in_block:
            if (line.strip().startswith('at ') or
                    'Caused by:' in line or
                    'Exception' in line or
                    'Error:' in line):
                current_block.append(line)
            elif line.strip() == '':
                pass  # allow blank lines in block
            else:
                if len(current_block) > 2:  # only count if has stack trace
                    crashes.append('\n'.join(current_block[:15]))
                in_block = False; current_block = []
        if 'ANR in' in line: anrs.append(line)
        if re.search(r'\b(NullPointerException|OutOfMemoryError|IllegalStateException|NetworkOnMainThreadException)', line):
            exceptions.append(line)

    print(f"  {c(B,'Crashes:  ')} {c(RED+B if crashes else GRN, str(len(crashes)))}")
    print(f"  {c(B,'ANRs:     ')} {c(RED+B if anrs else GRN, str(len(anrs)))}")
    print(f"  {c(B,'Exceptions:')} {c(YLW if exceptions else GRN, str(len(exceptions)))}")
    print()
    if crashes:
        print(f"  {c(RED+B,'═ CRASHES ══════════════════════════════')}")
        for i, crash in enumerate(crashes[:3]):
            print(f"\n  {c(RED+B,'Crash '+str(i+1)+':')}")
            for line in crash.split('\n')[:10]:
                m = re.search(r'\s([VDIWEFS])/', line)
                col = RED if m and m.group(1) in 'EF' else DIM
                print(f"  {c(col, line)}")
        if len(crashes) > 3: print(f"\n  {c(DIM,f'... and {len(crashes)-3} more')}")
        print()
    if anrs:
        print(f"  {c(YLW+B,'═ ANRs ══════════════════════════════════')}")
        for anr in anrs[:5]: print(f"  {c(YLW, anr)}")
        print()

def _parse_dumpsys_battery(out):
    """Parse dumpsys battery output into a dict."""
    d = {}
    for line in out.split('\n'):
        line = line.strip()
        if ':' not in line: continue
        k, _, v = line.partition(':')
        d[k.strip().lower()] = v.strip()
    return d

def cmd_battery(args):
    section('Battery Stats'); print()
    serial = getattr(args, 'serial', None)
    import glob, subprocess as _sp, json as _j

    def _sh(cmd):
        try:
            r = _sp.run(cmd, shell=True, capture_output=True, text=True, timeout=20)
            return r.stdout.strip()
        except: return ''

    def _bar(pct):
        col = GRN if pct > 50 else YLW if pct > 20 else RED
        n = int(pct / 3.33)
        return c(col, chr(9608)*n) + c(DIM, chr(9617)*(30-n)), col

    # Strategy 1: termux-battery-status (best — gives voltage, current, cycle)
    tb = _sh('termux-battery-status 2>/dev/null')
    if tb and '{' in tb:
        try:
            d = _j.loads(tb)
            pct    = d.get('percentage', 0) or d.get('level', 0)
            stat   = d.get('status', '')
            temp   = d.get('temperature', 0)
            hlt    = d.get('health', '')
            tech   = d.get('technology', '')
            plugged= d.get('plugged', '')
            volt   = d.get('voltage', 0)       # mV
            curr   = d.get('current', 0)       # µA
            curr_avg = d.get('current_average', 0)
            cycle  = d.get('cycle', 0)
            if pct:
                bar, col = _bar(int(pct))
                print(f"  {c(B,'Level:   ')}  {bar} {c(col+B, str(pct)+'%')}")
            if stat:
                scol = GRN if 'CHARG' in stat else YLW
                plug_str = ' (' + plugged + ')' if plugged and plugged != 'UNPLUGGED' else ''
                print(f"  {c(B,'Status:  ')}  {c(scol, stat+plug_str)}")
            if temp:
                tc = GRN if temp < 40 else YLW if temp < 50 else RED
                print(f"  {c(B,'Temp:    ')}  {c(tc, str(temp)+'°C')}")
            if volt:
                print(f"  {c(B,'Voltage: ')}  {c(WHT, str(volt/1000.0)+'V')}")
            if curr:
                ma = abs(curr) // 1000
                ca = abs(curr_avg) // 1000 if curr_avg else 0
                curr_col = GRN if curr > 0 else YLW
                curr_str = str(ma)+'mA'
                if ca: curr_str += f' (avg {ca}mA)'
                print(f"  {c(B,'Current: ')}  {c(curr_col, curr_str)}")
            if hlt:
                print(f"  {c(B,'Health:  ')}  {c(GRN if hlt=='GOOD' else RED, hlt)}")
            if tech:
                print(f"  {c(B,'Type:    ')}  {c(DIM, tech)}")
            if cycle and int(cycle) > 0:
                ccol = GRN if cycle < 300 else YLW if cycle < 500 else RED
                print(f"  {c(B,'Cycles:  ')}  {c(ccol, str(cycle))}")
            print(); return
        except: pass

    # Strategy 2: /sys/class/power_supply
    bases = (glob.glob('/sys/class/power_supply/battery') +
             glob.glob('/sys/class/power_supply/Battery') +
             glob.glob('/sys/class/power_supply/*bat*'))
    for base in bases:
        try:
            cap = open(f"{base}/capacity").read().strip()
            if not cap.isdigit(): continue
            pct = int(cap)
            bar, col = _bar(pct)
            print(f"  {c(B,'Level:   ')}  {bar} {c(col+B, str(pct)+'%')}")
            for key, label in [('status','Status'), ('technology','Type'), ('health','Health')]:
                try:
                    v = open(f"{base}/{key}").read().strip()
                    if v: print(f"  {c(B,label+':')}  {c(WHT, v)}")
                except: pass
            try:
                t = int(open(f"{base}/temp").read().strip()) / 10.0
                tc = GRN if t < 40 else YLW if t < 50 else RED
                print(f"  {c(B,'Temp:    ')}  {c(tc, str(t)+'°C')}")
            except: pass
            print(); return
        except: continue

    # Strategy 3: dumpsys battery
    out = _sh('dumpsys battery 2>/dev/null')
    if not out:
        out, _, _ = adb_cmd(['shell', 'dumpsys', 'battery'], serial=serial)
    if out and 'level' in out.lower():
        d = {}
        for line in out.splitlines():
            line = line.strip()
            if ':' in line:
                k, _, v = line.partition(':')
                d[k.strip().lower()] = v.strip()
        cap = d.get('level')
        if cap and cap.isdigit():
            pct = int(cap)
            bar, col = _bar(pct)
            print(f"  {c(B,'Level:   ')}  {bar} {c(col+B, str(pct)+'%')}")
            stat_map = {'2':'Charging','3':'Discharging','4':'Not charging','5':'Full'}
            stat = stat_map.get(d.get('status',''), d.get('status',''))
            if stat: print(f"  {c(B,'Status:  ')}  {c(GRN if 'Charg' in stat else YLW, stat)}")
            temp_raw = d.get('temperature')
            if temp_raw and temp_raw.isdigit():
                t = int(temp_raw) / 10.0
                tc = GRN if t < 40 else YLW if t < 50 else RED
                print(f"  {c(B,'Temp:    ')}  {c(tc, str(t)+'°C')}")
            print(); return

    err('Cannot read battery info')
    info('Install Termux:API: pkg install termux-api')
    print()

def cmd_memory(args):
    section('Memory Stats'); print()
    mi = ""
    try: mi = open('/proc/meminfo').read()
    except: pass
    if not mi: err("Cannot read meminfo"); print(); return

    fields = {}
    for line in mi.split('\n'):
        m = re.match(r'(\w+):\s+(\d+)', line)
        if m: fields[m.group(1)] = int(m.group(2)) // 1024

    total  = fields.get('MemTotal', 0)
    avail  = fields.get('MemAvailable', 0)
    used   = total - avail
    cached = fields.get('Cached', 0) + fields.get('Buffers', 0)

    if total:
        pct = used / total
        col = RED if pct > 0.85 else YLW if pct > 0.6 else GRN
        bl  = int(pct * 30)
        bar = c(col, '█'*bl) + c(DIM, '░'*(30-bl))
        print(f"  {c(B,'RAM:    ')}  {bar} {c(col+B,str(used)+'MB')} / {c(WHT,str(total)+'MB')}")
        print(f"  {c(B,'Free:   ')}  {c(GRN, str(avail)+'MB')}")
        print(f"  {c(B,'Cached: ')}  {c(DIM, str(cached)+'MB')}")

    print(f"\n  {c(B,'Top processes:')}")
    try:
        procs = []
        for pid in os.listdir('/proc'):
            if not pid.isdigit(): continue
            try:
                status = open(f'/proc/{pid}/status').read()
                name_m = re.search(r'Name:\s*(\S+)', status)
                rss_m  = re.search(r'VmRSS:\s+(\d+)', status)
                if name_m and rss_m:
                    procs.append((int(rss_m.group(1))//1024, name_m.group(1), pid))
            except: pass
        for mb, name, pid in sorted(procs, reverse=True)[:10]:
            col = RED if mb > 200 else YLW if mb > 100 else WHT
            print(f"  {c(col, str(mb)+'MB'):<12} {c(CYN,name):<25} {c(DIM,'pid:'+pid)}")
    except: pass
    print()
