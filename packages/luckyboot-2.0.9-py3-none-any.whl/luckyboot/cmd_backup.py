"""Backup/restore APKs and data via ADB."""
import os, re, glob, time
from .utils import *

def cmd_backup(args):
    """Pull APK(s) from device."""
    section('Backup APKs'); print()
    serial  = getattr(args,'serial',None)
    package = getattr(args,'package',None)
    out_dir = getattr(args,'out',None) or './luckyboot_backup'
    os.makedirs(out_dir, exist_ok=True)

    if package:
        pkgs = [package]
    else:
        out, _, _ = adb_cmd(['shell','pm','list','packages','-3'], serial=serial)
        pkgs = [l.replace('package:','').strip() for l in out.split('\n') if l.strip()]

    info(f"Backing up {len(pkgs)} package(s) to {c(CYN, out_dir)}")
    print()
    ok_count = 0
    for pkg in pkgs:
        path_out, _, _ = adb_cmd(['shell','pm','path', pkg], serial=serial)
        m = re.search(r'package:(.+)', path_out)
        if not m: warn(f"Cannot find APK for {pkg}"); continue
        apk_path = m.group(1).strip()
        dest     = os.path.join(out_dir, pkg + '.apk')
        _, _, code = adb_cmd(['pull', apk_path, dest], serial=serial)
        if code == 0:
            sz = os.path.getsize(dest) // 1024
            ok(f"{c(CYN,pkg)} ({sz}KB)")
            ok_count += 1
        else:
            err(f"Failed: {pkg}")
    print(f"\n  {c(B,'Done:')} {ok_count}/{len(pkgs)} APKs saved to {c(CYN,out_dir)}\n")

def cmd_restore(args):
    """Install APK(s) back."""
    section('Restore APKs'); print()
    serial  = getattr(args,'serial',None)
    src     = getattr(args,'src',None) or './luckyboot_backup'
    package = getattr(args,'package',None)

    if package:
        apks = glob.glob(os.path.join(src,'*.apk')) if os.path.isdir(src) else [src]
        apks = [a for a in apks if package in a]
    elif os.path.isdir(src):
        apks = glob.glob(os.path.join(src,'*.apk'))
    else:
        apks = [src]

    if not apks: err(f"No APKs found in {src}"); print(); return
    info(f"Restoring {len(apks)} APK(s)...")
    print()
    for apk in apks:
        name = os.path.basename(apk)
        out, _, code = adb_cmd(['install','-r', apk], serial=serial)
        if code == 0 and 'Success' in out: ok(name)
        else: err(f"{name}: {out[:80]}")
    print()

def cmd_backup_data(args):
    """Full ADB backup."""
    section('ADB Data Backup'); print()
    serial  = getattr(args,'serial',None)
    package = getattr(args,'package',None)
    out_f   = getattr(args,'out',None) or f'backup_{int(time.time())}.ab'
    warn("ADB backup — device will ask for confirmation")
    print()
    cmd = ['adb'] + (['-s',serial] if serial else []) + ['backup','-f',out_f,'-apk','-obb','-all','-system']
    if package: cmd = ['adb'] + (['-s',serial] if serial else []) + ['backup','-f',out_f,'-apk',package]
    info(f"Running: {c(CYN,' '.join(cmd))}")
    info("Unlock device and press 'Back up my data'")
    print()
    out, err_s, code = run(cmd, timeout=300)
    if code == 0: ok(f"Backup saved: {c(CYN,out_f)}")
    else: err(f"Backup failed: {err_s[:200]}")
    print()

def cmd_restore_data(args):
    """Restore ADB backup."""
    section('ADB Data Restore'); print()
    serial = getattr(args,'serial',None)
    src    = getattr(args,'src',None) or 'backup.ab'
    if not os.path.exists(src): err(f"Not found: {src}"); print(); return
    warn("This will restore data to the device")
    cmd = ['adb'] + (['-s',serial] if serial else []) + ['restore', src]
    info(f"Running: {c(CYN,' '.join(cmd))}")
    out, err_s, code = run(cmd, timeout=300)
    if code == 0: ok("Restore complete!")
    else: err(err_s[:200])
    print()

def cmd_pull_media(args):
    """Pull DCIM, Downloads, Photos."""
    section('Pull Media'); print()
    serial  = getattr(args,'serial',None)
    out_dir = getattr(args,'out',None) or './luckyboot_media'
    filt    = getattr(args,'filter',None)
    os.makedirs(out_dir, exist_ok=True)
    folders = ['/sdcard/DCIM', '/sdcard/Pictures', '/sdcard/Downloads', '/sdcard/Movies']
    for folder in folders:
        out_chk, _, _ = adb_cmd(['shell','ls',folder], serial=serial)
        if 'No such file' in out_chk or not out_chk.strip(): continue
        dest = os.path.join(out_dir, os.path.basename(folder))
        sp   = Spinner(f'Pulling {folder}...'); sp.start()
        _, _, code = adb_cmd(['pull', folder, dest], serial=serial)
        sp.stop()
        if code == 0: ok(f"Pulled: {c(CYN,folder)} → {dest}")
        else: warn(f"Partial pull: {folder}")
    print()
