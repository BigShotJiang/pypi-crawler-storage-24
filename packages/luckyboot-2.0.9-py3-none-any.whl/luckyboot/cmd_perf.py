"""Performance: CPU, thermal, top, FPS, meminfo."""
import os, re, glob, subprocess, time
from .utils import *

def _sh(cmd):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
        return r.stdout.strip()
    except: return ""

def cmd_cpu(args):
    section('CPU Info'); print()
    serial = getattr(args,'serial',None)
    import subprocess as _sp, glob as _glob

    def _sh(cmd):
        try:
            r = _sp.run(cmd, shell=True, capture_output=True, text=True, timeout=8)
            return r.stdout.strip()
        except: return ''

    def _rd(path):
        try: return open(path).read().strip()
        except: return ''

    cpus = sorted(_glob.glob('/sys/devices/system/cpu/cpu[0-9]*'))
    if cpus:
        print(f"  {c(B+WHT,'Core'):<10} {c(B+WHT,'Cur MHz'):<12} {c(B+WHT,'Min'):<10} {c(B+WHT,'Max'):<10} {c(B+WHT,'Governor')}")
        print(f"  {c(DIM,chr(8212)*55)}")
        for cpu_path in cpus:
            core = cpu_path.split('/')[-1]
            base = cpu_path + '/cpufreq/'
            cur  = _rd(base+'scaling_cur_freq')
            mn   = _rd(base+'cpuinfo_min_freq')
            mx   = _rd(base+'cpuinfo_max_freq')
            gov  = _rd(base+'scaling_governor') or '?'
            def mhz(v): return str(int(v)//1000) if v and v.isdigit() else '?'
            cur_mhz = mhz(cur)
            col = RED if cur_mhz != '?' and int(cur_mhz) > 2000 else YLW if cur_mhz != '?' and int(cur_mhz) > 1000 else GRN
            print(f"  {c(CYN,core):<10} {c(col,cur_mhz):<12} {c(DIM,mhz(mn)):<10} {c(DIM,mhz(mx)):<10} {c(DIM,gov)}")
    print()

    # SoC name — try many sources
    cpu_name = ''
    try:
        ci = open('/proc/cpuinfo').read()
        import re as _re
        for pat in [r'Hardware\s*:\s*(.+)', r'model name\s*:\s*(.+)', r'Processor\s*:\s*(.+)']:
            m = _re.search(pat, ci)
            if m: cpu_name = m.group(1).strip(); break
    except: pass
    if not cpu_name:
        for prop in ['ro.boot.auto.chipid','ro.chip.id','ro.hardware',
                     'ro.board.platform','ro.product.board']:
            cpu_name = _sh('getprop '+prop+' 2>/dev/null')
            if cpu_name: break
    if not cpu_name:
        for p in ['/sys/devices/soc0/family','/sys/devices/soc0/machine']:
            cpu_name = _rd(p)
            if cpu_name: break

    cores = len(cpus) or _sh('nproc 2>/dev/null') or '?'
    if cpu_name:
        print(f"  {c(B,'SoC:  ')} {c(WHT, cpu_name)}  {c(DIM,f'({cores} cores)')}")

    # CPU governor info
    avail_gov = _rd('/sys/devices/system/cpu/cpu0/cpufreq/scaling_available_governors')
    if avail_gov:
        print(f"  {c(B,'Govs: ')} {c(DIM, avail_gov)}")
    print()


def cmd_thermal(args):
    section('Thermal Zones'); print()
    serial = getattr(args,'serial',None)
    import subprocess as _sp, glob as _glob, re as _re, json as _j

    def _sh(cmd):
        try:
            r = _sp.run(cmd, shell=True, capture_output=True, text=True, timeout=20)
            return r.stdout.strip()
        except: return ''

    found = False

    # Strategy 1: /sys/class/thermal
    for zone in sorted(_glob.glob('/sys/class/thermal/thermal_zone*'))[:32]:
        try:
            raw = open(f"{zone}/temp").read().strip()
            try: tname = open(f"{zone}/type").read().strip()
            except: tname = zone.split('/')[-1]
            t = int(raw)
            if t > 100000: t = t / 1000.0
            elif t > 1000: t = t / 100.0
            elif t > 200:  t = t / 10.0
            col = GRN if t < 40 else YLW if t < 60 else RED
            bar = c(col, chr(9608)*int(min(t,100)/4)) + c(DIM, chr(9617)*(25-int(min(t,100)/4)))
            print(f"  {c(DIM,tname[:28]):<30} {bar}  {c(col+B, f'{t:.1f}°C')}")
            found = True
        except: continue

    # Strategy 2: dumpsys thermalservice
    if not found:
        out = _sh('dumpsys thermalservice 2>/dev/null')
        if out and 'mValue' in out:
            for line in out.splitlines():
                m = _re.search(r'mName=(\S+).*?mValue=([\d.]+)', line)
                if m:
                    name, val = m.group(1), float(m.group(2))
                    col = GRN if val < 40 else YLW if val < 60 else RED
                    print(f"  {c(DIM,name[:28]):<30} {c(col+B, f'{val:.1f}°C')}")
                    found = True

    # Strategy 3: termux-battery-status (always try)
    tb = _sh('termux-battery-status 2>/dev/null')
    if tb and '{' in tb:
        try:
            d = _j.loads(tb)
            temp = d.get('temperature', 0)
            if temp:
                col = GRN if temp < 40 else YLW if temp < 50 else RED
                bar = c(col, chr(9608)*int(min(temp,100)/4)) + c(DIM, chr(9617)*(25-int(min(temp,100)/4)))
                print(f"  {c(DIM,'battery'):<30} {bar}  {c(col+B, f'{temp:.1f}°C')}")
                found = True
        except: pass

    # Strategy 4: ADB
    if not found:
        out, _, _ = adb_cmd(['shell', 'for f in /sys/class/thermal/thermal_zone*/temp; do echo "$f:$(cat $f 2>/dev/null)"; done'], serial=serial)
        if out:
            for line in out.splitlines():
                m = _re.match(r'.*/thermal_zone(\d+)/temp:(\d+)', line)
                if m:
                    idx, raw = int(m.group(1)), int(m.group(2))
                    t = raw/1000.0 if raw > 100000 else raw/10.0 if raw > 200 else float(raw)
                    col = GRN if t < 40 else YLW if t < 60 else RED
                    print(f"  {c(DIM,f'zone{idx}'):<30} {c(col+B, f'{t:.1f}°C')}")
                    found = True

    if not found:
        warn('Thermal sensors not accessible without root')
    print()


def cmd_top(args):
    serial = getattr(args,'serial',None)
    n = getattr(args,'n', 15)
    section(f'Top {n} Processes'); print()
    procs = []
    try:
        for pid in os.listdir('/proc'):
            if not pid.isdigit(): continue
            try:
                status = open(f'/proc/{pid}/status').read()
                name_m = re.search(r'Name:\s*(\S+)', status)
                rss_m  = re.search(r'VmRSS:\s+(\d+)', status)
                name   = name_m.group(1) if name_m else '?'
                rss    = int(rss_m.group(1))//1024 if rss_m else 0
                procs.append((rss, name, pid))
            except: pass
    except: pass

    if procs:
        print(f"  {c(B+WHT,'PID'):<8} {c(B+WHT,'RSS MB'):<10} {c(B+WHT,'Process')}")
        print(f"  {c(DIM,chr(8212)*40)}")
        for rss, name, pid in sorted(procs, reverse=True)[:n]:
            col = RED if rss > 200 else YLW if rss > 100 else WHT
            print(f"  {c(DIM,pid):<8} {c(col,str(rss)):<10} {c(CYN,name)}")
    else:
        out = _sh(f'top -n1 -b 2>/dev/null | head -{n+6}')
        if not out:
            out, _, _ = adb_cmd(['shell',f'top -n1 -b'], serial=serial)
        for line in (out or '').split('\n')[4:4+n]:
            print(f"  {c(DIM, line)}")
    print()

def cmd_fps(args):
    serial = getattr(args,'serial',None)
    pkg    = getattr(args,'package',None)
    section('FPS Monitor'); print()
    import subprocess as _sp
    def _sh(cmd):
        try:
            r = _sp.run(cmd, shell=True, capture_output=True, text=True, timeout=8)
            return r.stdout.strip()
        except: return ''
    if not pkg:
        # Try local dumpsys first
        out = _sh('dumpsys window windows 2>/dev/null')
        if not out:
            out, _, _ = adb_cmd(['shell','dumpsys','window','windows'], serial=serial)
        m = re.search(r'mCurrentFocus.+\{[^\}]+\s(\S+)/\S+\}', out or '')
        if not m:
            m = re.search(r'mFocusedApp.*ActivityRecord\{[^\}]+\s(\S+)/', out or '')
        if m: pkg = m.group(1)
    if pkg:
        info(f"Package: {c(CYN, pkg)}")
        out, _, _ = adb_cmd(['shell','dumpsys','gfxinfo', pkg], serial=serial)
        if out:
            frames = re.findall(r'Draw\s+([\d.]+)\s+([\d.]+)\s+([\d.]+)', out)
            if frames:
                total_ms = sum(float(f[0])+float(f[1])+float(f[2]) for f in frames[-60:])
                count    = min(len(frames), 60)
                avg_ms   = total_ms / count if count else 0
                fps      = 1000 / avg_ms if avg_ms > 0 else 0
                col = GRN if fps >= 55 else YLW if fps >= 30 else RED
                print(f"  {c(B,'Approx FPS:')} {c(col+B, f'{fps:.1f}')}")
                janky = sum(1 for f in frames if float(f[0])+float(f[1])+float(f[2]) > 16.67)
                print(f"  {c(B,'Janky frames:')} {c(RED if janky>10 else YLW if janky>5 else GRN, str(janky))}")
    else:
        warn("Could not detect foreground package")
        info("Use: luckyboot fps -p com.example.app")
    print()

def cmd_meminfo(args):
    serial = getattr(args,'serial',None)
    pkg    = getattr(args,'package',None)
    section('Memory Info'); print()
    if pkg:
        out, _, _ = adb_cmd(['shell','dumpsys','meminfo', pkg], serial=serial)
        if out:
            for line in out.split('\n')[:30]:
                if any(k in line for k in ['TOTAL','Java','Native','Code','Stack','Heap','Graphics']):
                    print(f"  {c(BLU, line)}")
    else:
        try: mi = open('/proc/meminfo').read()
        except: mi, _, _ = adb_cmd(['shell','cat','/proc/meminfo'], serial=serial)
        if mi:
            for line in mi.split('\n')[:15]:
                m = re.match(r'(\w+):\s+(\d+)', line)
                if m:
                    mb  = int(m.group(2)) // 1024
                    col = CYN if 'Total' in m.group(1) else GRN if 'Available' in m.group(1) else DIM
                    print(f"  {c(col,m.group(1)):<22} {c(WHT,str(mb)+'MB')}")
    print()
