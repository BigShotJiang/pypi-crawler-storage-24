"""Network info on device: IP, WiFi, DNS, ping, traceroute, netstat."""
import re, subprocess
from .utils import *

def _sh(cmd):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
        return r.stdout.strip()
    except: return ""

def _parse_ip_addr(out):
    """Parse 'ip addr' output correctly. Returns list of (iface, ip, mask)."""
    results = []
    cur_iface = ''
    for line in out.split('\n'):
        # Interface line: "2: wlan0: <FLAGS>"
        m = re.match(r'\s*\d+:\s+(\w+):', line)
        if m:
            cur_iface = m.group(1)
            continue
        # inet line: "    inet 192.168.1.1/24 ..."
        m2 = re.search(r'inet ([\d.]+)/(\d+)', line)
        if m2 and cur_iface and cur_iface != 'lo':
            results.append((cur_iface, m2.group(1), m2.group(2)))
    return results

def cmd_netinfo(args):
    section('Network Info'); print()
    serial = getattr(args,'serial',None)
    import subprocess as _sp, json as _j

    def _sh(cmd):
        try:
            r = _sp.run(cmd, shell=True, capture_output=True, text=True, timeout=8)
            return r.stdout.strip()
        except: return ''

    found = False

    # Strategy 1: termux-wifi-connectioninfo
    tw = _sh('termux-wifi-connectioninfo 2>/dev/null')
    if tw and '{' in tw:
        try:
            d = _j.loads(tw)
            ip    = d.get('ip', '')
            ssid  = d.get('ssid', '')
            link  = d.get('link_speed_mbps', -1)
            rssi  = d.get('rssi', -127)
            freq  = d.get('frequency_mhz', -1)
            mac   = d.get('mac_address', '')
            state = d.get('supplicant_state', '')
            valid_ip   = ip   and ip   not in ('0.0.0.0', '', 'null')
            valid_ssid = ssid and ssid not in ('<unknown ssid>', '', 'null')
            valid_rssi = isinstance(rssi, (int,float)) and rssi > -120
            valid_link = isinstance(link, (int,float)) and link > 0
            valid_freq = isinstance(freq, (int,float)) and freq > 0
            valid_mac  = mac  and mac  not in ('02:00:00:00:00:00', '')
            if valid_ip:   print('  ' + c(B,'IP:      ') + '  ' + c(GRN, str(ip)))
            if valid_ssid: print('  ' + c(B,'SSID:    ') + '  ' + c(CYN, str(ssid)))
            if valid_link: print('  ' + c(B,'Speed:   ') + '  ' + c(YLW, str(link)+' Mbps'))
            if valid_rssi:
                col = GRN if rssi > -60 else YLW if rssi > -75 else RED
                print('  ' + c(B,'Signal:  ') + '  ' + c(col, str(rssi)+' dBm'))
            if valid_freq: print('  ' + c(B,'Freq:    ') + '  ' + c(DIM, str(freq)+' MHz'))
            if valid_mac:  print('  ' + c(B,'MAC:     ') + '  ' + c(DIM, str(mac)))
            if state and state != 'UNINITIALIZED':
                print('  ' + c(B,'WiFi:    ') + '  ' + c(GRN if state=='COMPLETED' else YLW, state))
            found = valid_ip or valid_ssid
            if not found and state == 'UNINITIALIZED':
                warn('WiFi details require location permission (Android 14+ restriction)')
        except: pass

    # DNS via getprop — works on all devices
    dns_found = []
    for key in ['net.dns1','net.dns2','dhcp.wlan0.dns1','dhcp.wlan0.dns2',
                'net.wlan0.dns1','net.wlan0.dns2','net.rmnet0.dns1','net.rmnet0.dns2']:
        v = _sh('getprop ' + key + ' 2>/dev/null')
        if v and v not in ('','0.0.0.0') and v not in dns_found:
            dns_found.append(v)
            found = True
        if len(dns_found) >= 2: break

    # Gateway from /proc/net/route
    try:
        for line in open('/proc/net/route').read().splitlines()[1:]:
            p = line.split()
            if len(p) >= 3 and p[1] == '00000000':
                gw = '.'.join(str(int(p[2][i:i+2],16)) for i in (6,4,2,0))
                if gw and gw != '0.0.0.0':
                    dns_found.append(gw)
                    found = True
                    break
    except: pass

    # ADB fallback for IP
    if not found:
        out, _, _ = adb_cmd(['shell', 'ip addr show wlan0 2>/dev/null || ip addr show eth0 2>/dev/null'], serial=serial)
        if out:
            import re as _re
            m = _re.search(r'inet ([\d.]+)/(\d+)', out)
            if m:
                print('  ' + c(B,'IP:   ') + '  ' + c(GRN, m.group(1)+'/'+m.group(2)))
                found = True

    print()
    for i, dns in enumerate(dns_found[:2], 1):
        print('  ' + c(B,'DNS '+str(i)+':  ') + '  ' + c(YLW, dns))

    if not found:
        warn('Network info limited — WiFi details blocked by Android 14+ permissions')
        info('Full info available via ADB: adb shell ip addr')
    print()


def cmd_wifi_scan(args):
    section('WiFi Networks'); print()
    serial = getattr(args,'serial',None)

    out = _sh('dumpsys wifi 2>/dev/null')
    if not out:
        out, _, _ = adb_cmd(['shell','dumpsys','wifi'], serial=serial)
    if not out:
        warn("Cannot access WiFi scan (needs system permission)")
        info("Try connecting via ADB: luckyboot wifi-scan -s <serial>")
        print(); return

    networks = {}
    for block in out.split('\n'):
        ssid_m  = re.search(r'SSID:\s*"?([^",\n<][^",\n]*)"?', block)
        level_m = re.search(r'level=(-\d+)', block)
        if ssid_m and level_m:
            ssid  = ssid_m.group(1).strip()
            level = int(level_m.group(1))
            if ssid and len(ssid) > 0:
                if ssid not in networks or networks[ssid] < level:
                    networks[ssid] = level

    if networks:
        print(f"  {c(B+WHT,'SSID'):<35} {c(B+WHT,'Signal')}")
        print(f"  {c(DIM,chr(8212)*50)}")
        for ssid, lvl in sorted(networks.items(), key=lambda x: x[1], reverse=True):
            col  = GRN if lvl > -60 else YLW if lvl > -75 else RED
            bars = '▂▄▆█' if lvl > -60 else '▂▄▆░' if lvl > -75 else '▂▄░░' if lvl > -85 else '▂░░░'
            print(f"  {c(CYN,ssid):<35} {c(col,bars+' '+str(lvl)+'dBm')}")
    else:
        warn("No networks in dumpsys wifi")
    print()

def cmd_ping_device(args):
    section('Ping'); print()
    serial = getattr(args,'serial',None)
    host   = getattr(args,'host',None) or '8.8.8.8'
    count  = getattr(args,'count',4)
    info(f"Pinging {c(CYN,host)} x{count}...")
    print()

    out = _sh(f'ping -c {count} {host} 2>&1')
    if not out:
        out, _, _ = adb_cmd(['shell',f'ping -c {count} {host}'], serial=serial)

    if out:
        for line in out.split('\n'):
            if 'bytes from' in line:
                m   = re.search(r'time=([\d.]+)', line)
                ms  = float(m.group(1)) if m else 0
                col = GRN if ms < 50 else YLW if ms < 150 else RED
                print(f"  {c(col, line.strip())}")
            elif 'packet loss' in line:
                m    = re.search(r'(\d+)% packet loss', line)
                loss = int(m.group(1)) if m else 0
                col  = GRN if loss == 0 else YLW if loss < 50 else RED
                print(f"  {c(col, line.strip())}")
            elif 'min/avg/max' in line or 'rtt' in line:
                print(f"  {c(DIM, line.strip())}")
    else:
        err(f"Ping failed")
    print()

def cmd_traceroute(args):
    section('Traceroute'); print()
    serial = getattr(args,'serial',None)
    host   = getattr(args,'host',None) or '8.8.8.8'
    info(f"Traceroute to {c(CYN, host)}")
    print()

    out = _sh(f'traceroute -m 15 {host} 2>&1') or _sh(f'tracepath {host} 2>&1')
    if not out:
        out, _, _ = adb_cmd(['shell',f'traceroute -m 15 {host}'], serial=serial)
    if out:
        for line in out.split('\n'):
            if not line.strip(): continue
            m = re.search(r'(\d+)\s+\S+\s+\(([\d.]+)\)\s+([\d.]+)\s*ms', line)
            if m:
                hop, ip, ms = m.groups()
                col = GRN if float(ms) < 50 else YLW if float(ms) < 150 else RED
                print(f"  {c(DIM,hop.rjust(3))}  {c(CYN,ip):<20} {c(col,ms+'ms')}")
            else:
                print(f"  {c(DIM, line.strip())}")
    else:
        err("traceroute not available")
        info("Install: pkg install inetutils")
    print()

def cmd_netstat(args):
    section('Active Connections'); print()
    serial = getattr(args,'serial',None)
    import subprocess as _sp, re as _re

    def _sh(cmd):
        try:
            r = _sp.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
            return r.stdout.strip()
        except: return ''

    STATE = {'01':'ESTABLISHED','02':'SYN_SENT','03':'SYN_RECV',
             '04':'FIN_WAIT1','05':'FIN_WAIT2','06':'TIME_WAIT',
             '07':'CLOSE','08':'CLOSE_WAIT','09':'LAST_ACK',
             '0A':'LISTEN','0B':'CLOSING'}

    def hex2addr(h):
        try:
            ip_hex, port_hex = h.split(':')
            ip = '.'.join(str(int(ip_hex[i:i+2],16)) for i in (6,4,2,0))
            return f"{ip}:{int(port_hex,16)}"
        except: return h

    rows = []

    # Try ss (works on rooted/some devices)
    out = _sh('ss -tnp 2>/dev/null')
    if out and ('ESTAB' in out or 'LISTEN' in out) and 'Termux' not in out:
        for line in out.splitlines()[1:]:
            p = line.split()
            if len(p) >= 5:
                pm = _re.search(r'\("([^"]+)"', line)
                proc = pm.group(1) if pm else ''
                rows.append((p[0], p[3], p[4], proc))

    # /proc/net/tcp + tcp6
    if not rows:
        for fname in ('/proc/net/tcp', '/proc/net/tcp6'):
            try:
                for line in open(fname).read().splitlines()[1:]:
                    p = line.split()
                    if len(p) < 4: continue
                    local  = hex2addr(p[1])
                    remote = hex2addr(p[2])
                    state  = STATE.get(p[3].upper(), p[3])
                    rows.append((state, local, remote, ''))
            except: continue

    # ADB fallback
    if not rows:
        out, _, _ = adb_cmd(['shell', 'cat /proc/net/tcp /proc/net/tcp6 2>/dev/null'], serial=serial)
        if out:
            for line in out.splitlines():
                p = line.split()
                if len(p) < 4 or not p[0].isdigit(): continue
                try:
                    local  = hex2addr(p[1])
                    remote = hex2addr(p[2])
                    state  = STATE.get(p[3].upper(), p[3])
                    rows.append((state, local, remote, ''))
                except: continue

    if rows:
        order = {'ESTABLISHED':0,'LISTEN':1,'CLOSE_WAIT':2,'TIME_WAIT':3}
        rows.sort(key=lambda x: order.get(x[0], 9))
        print(f"  {c(B+WHT,'State'):<16} {c(B+WHT,'Local'):<26} {c(B+WHT,'Remote'):<26} {c(B+WHT,'Process')}")
        print(f"  {c(DIM,chr(8212)*75)}")
        seen = set()
        for state, local, remote, proc in rows:
            key = state+local+remote
            if key in seen: continue
            seen.add(key)
            col = GRN if state=='ESTABLISHED' else YLW if state=='LISTEN' else DIM
            print(f"  {c(col,state):<16} {c(CYN,local):<26} {c(DIM,remote):<26} {c(DIM,proc)}")
    else:
        warn('No connections accessible — /proc/net/tcp requires root on Android 14+')
        info('Connect via ADB for full network stats')
    print()

