#!/usr/bin/env python3
"""luckyboot — Android root, flash & debug toolkit."""
import sys, argparse

def banner():
    from luckyboot import __version__
    from .utils import c, B, CYN, YLW, DIM, R
    print(f"""{CYN}{B}
  ██╗     ██╗   ██╗ ██████╗██╗  ██╗██╗   ██╗██████╗  ██████╗  ██████╗ ████████╗
  ██║     ██║   ██║██╔════╝██║ ██╔╝╚██╗ ██╔╝██╔══██╗██╔═══██╗██╔═══██╗╚══██╔══╝
  ██║     ██║   ██║██║     █████╔╝  ╚████╔╝ ██████╔╝██║   ██║██║   ██║   ██║
  ██║     ██║   ██║██║     ██╔═██╗   ╚██╔╝  ██╔══██╗██║   ██║██║   ██║   ██║
  ███████╗╚██████╔╝╚██████╗██║  ██╗   ██║   ██████╔╝╚██████╔╝╚██████╔╝   ██║
  ╚══════╝ ╚═════╝  ╚═════╝╚═╝  ╚═╝   ╚═╝   ╚═════╝  ╚═════╝  ╚═════╝   ╚═╝
{R}  {c(DIM,'Android root, flash & debug toolkit')}  {c(YLW+B,f'v{__version__}')}{R}
""")

def print_help():
    from luckyboot import __version__
    from .utils import c, B, CYN, YLW, DIM, WHT, GRN, RED, R
    banner()
    print(f"""{c(RED+B,'── ROOT ──────────────────────────────────────────────────────────────')}
  {c(RED+B,'root')}           {c(GRN+B,'THE one command — analyzes device and does everything')}
                    {c(DIM,'[--boot boot.img] [--method magisk|kernelsu] [--force]')}

{c(YLW+B,'── BOOTLOADER ────────────────────────────────────────────────────────')}
  {c(CYN+B,'bl-unlock')}      Step-by-step bootloader unlock (brand-aware)
  {c(CYN+B,'bootloader')}     Show lock status, verifiedboot, vars

{c(YLW+B,'── FLASH ─────────────────────────────────────────────────────────────')}
  {c(CYN+B,'flash-boot')}     {c(DIM,'<boot.img>')}        Flash boot partition (auto slot)
  {c(CYN+B,'flash-img')}      {c(DIM,'<partition> <img>')} Flash any partition
  {c(CYN+B,'flash-zip')}      {c(DIM,'<zip>')}             Flash ZIP via TWRP or sideload
  {c(CYN+B,'magisk-patch')}   {c(DIM,'[--boot boot.img]')} Download Magisk, patch, flash
  {c(CYN+B,'twrp')}           {c(DIM,'[--image twrp.img]')} Auto-download + flash TWRP
  {c(CYN+B,'wipe')}           {c(DIM,'<cache|data|dalvik|all>')} Wipe partitions

{c(WHT+B,'── ADB ───────────────────────────────────────────────────────────────')}
  {c(CYN+B,'devices')}        List connected devices
  {c(CYN+B,'shell')}          {c(DIM,'[-c cmd]')}          ADB shell
  {c(CYN+B,'logcat')}         {c(DIM,'[-t tag] [-l lvl] [-n N] [--clear]')}
  {c(CYN+B,'install')}        {c(DIM,'<apk> [-d] [-g]')}   Install APK
  {c(CYN+B,'uninstall')}      {c(DIM,'<package>')}
  {c(CYN+B,'apps')}           {c(DIM,'[-f filter] [-s] [-p]')}  List apps
  {c(CYN+B,'screenshot')}     {c(DIM,'[-n name.png]')}
  {c(CYN+B,'pull')}           {c(DIM,'<remote> [local]')}
  {c(CYN+B,'push')}           {c(DIM,'<local> <remote>')}
  {c(CYN+B,'reboot')}         {c(DIM,'[system|recovery|bootloader|edl|sideload]')}
  {c(CYN+B,'adb-wifi')}       {c(DIM,'[--connect IP] [--pair ADDR --code CODE]')}
  {c(CYN+B,'sideload')}       {c(DIM,'<zip>')}             ADB sideload

{c(WHT+B,'── DEVICE ────────────────────────────────────────────────────────────')}
  {c(CYN+B,'info')}           CPU, RAM, storage, model, build
  {c(CYN+B,'root-check')}     Detect Magisk / KernelSU / SuperSU
  {c(CYN+B,'props')}          {c(DIM,'[-f filter]')}       Build props dump
  {c(CYN+B,'partitions')}     Partition table + mounts

{c(WHT+B,'── DEBLOAT ───────────────────────────────────────────────────────────')}
  {c(CYN+B,'debloat')}        {c(DIM,'[--brand X] [-f filter]')}  Scan bloatware
  {c(CYN+B,'debloat-remove')} {c(DIM,'[--safe] [--package X] [--dry-run]')}

{c(WHT+B,'── FRIDA / SECURITY ──────────────────────────────────────────────────')}
  {c(CYN+B,'frida-setup')}    {c(DIM,'[--auto]')}          Download + push frida-server
  {c(CYN+B,'frida-start')}    Start frida-server on device
  {c(CYN+B,'frida-ps')}       List processes via frida
  {c(CYN+B,'objection')}      {c(DIM,'[--package com.x]')} Runtime app exploration

{c(WHT+B,'── BACKUP / RESTORE ──────────────────────────────────────────────────')}
  {c(CYN+B,'backup')}         {c(DIM,'[-p pkg] [-o dir]')}      Pull APK(s) from device
  {c(CYN+B,'restore')}        {c(DIM,'[src] [-p pkg]')}         Install APK(s) back
  {c(CYN+B,'backup-data')}    {c(DIM,'[-p pkg] [-o file.ab]')}  Full ADB data backup
  {c(CYN+B,'restore-data')}   {c(DIM,'[file.ab]')}              Restore ADB backup
  {c(CYN+B,'pull-media')}     {c(DIM,'[-o dir]')}               Pull DCIM/Photos/Downloads

{c(WHT+B,'── NETWORK ───────────────────────────────────────────────────────────')}
  {c(CYN+B,'netinfo')}        IP, WiFi SSID, DNS, gateway
  {c(CYN+B,'wifi-scan')}      Available WiFi networks + signal
  {c(CYN+B,'ping')}           {c(DIM,'[host] [-c N]')}     Ping from device
  {c(CYN+B,'traceroute')}     {c(DIM,'[host]')}            Traceroute from device
  {c(CYN+B,'netstat')}        Active TCP/UDP connections

{c(WHT+B,'── PERFORMANCE ───────────────────────────────────────────────────────')}
  {c(CYN+B,'cpu')}            Per-core freq, governor, usage
  {c(CYN+B,'thermal')}        All thermal zones + battery temp
  {c(CYN+B,'top')}            {c(DIM,'[-n N]')}            Top processes by CPU
  {c(CYN+B,'fps')}            Frame rate via SurfaceFlinger
  {c(CYN+B,'meminfo')}        {c(DIM,'[-p pkg]')}          Detailed memory breakdown

{c(WHT+B,'── KERNEL ────────────────────────────────────────────────────────────')}
  {c(CYN+B,'kernel')}         Kernel version, CPU info, boot cmdline
  {c(CYN+B,'dmesg')}          {c(DIM,'[-n N] [-f filter] [-l err|warn]')}  Kernel ring buffer
  {c(CYN+B,'modules')}        {c(DIM,'[-f filter]')}       Loaded kernel modules
  {c(CYN+B,'bootlog')}        {c(DIM,'[-n N]')}            Last boot log (ramoops)
  {c(CYN+B,'sysctl')}         {c(DIM,'[-f filter]')}       Kernel parameters

{c(WHT+B,'── LOGS ──────────────────────────────────────────────────────────────')}
  {c(CYN+B,'crash')}          {c(DIM,'[-n N]')}            Crashes & ANRs in logcat
  {c(CYN+B,'battery')}        Battery health, temp, level
  {c(CYN+B,'memory')}         RAM + top processes

{c(WHT+B,'── GLOBAL ────────────────────────────────────────────────────────────')}
  {c(DIM,'-s <serial>')}    Target specific device (or: export ANDROID_SERIAL=...)
  {c(DIM,'--yes')}          Skip confirmations
  {c(DIM,'--no-reboot')}    Don't reboot after flash

{c(GRN+B,'QUICK START:')}
  {c(RED+B,'luckyboot root')}                          {c(DIM,'← start here')}
  {c(CYN,'luckyboot root --boot boot.img')}       {c(DIM,'← already have boot.img? flash it')}
  {c(CYN,'luckyboot bl-unlock')}                  {c(DIM,'← unlock bootloader first')}
  {c(CYN,'luckyboot magisk-patch --boot boot.img')} {c(DIM,'← patch + flash')}
  {c(CYN,'luckyboot flash-zip Magisk.zip')}       {c(DIM,'← flash via TWRP')}
  {c(CYN,'luckyboot debloat && luckyboot debloat-remove --safe')}

{c(DIM,f'v{__version__} | zero dependencies | pure Python stdlib')}
""")

def base():
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument('-s','--serial')
    p.add_argument('--yes', action='store_true')
    p.add_argument('--no-reboot','--no_reboot', dest='no_reboot', action='store_true')
    return p

def main():
    if len(sys.argv) > 1 and sys.argv[1] in ('--version','-v','version'):
        from luckyboot import __version__
        print(f"luckyboot v{__version__}")
        return
    if len(sys.argv) < 2 or sys.argv[1] in ('-h','--help','help'):
        print_help(); return

    cmd  = sys.argv[1].lower()
    rest = sys.argv[2:]

    # ── ROOT ──────────────────────────────────────────────────────────────────
    if cmd == 'root':
        from .cmd_root_auto import cmd_root
        p = base()
        p.add_argument('--boot','-b')
        p.add_argument('--method', choices=['magisk','kernelsu'])
        p.add_argument('--force', action='store_true')
        cmd_root(p.parse_args(rest))

    # ── FLASH ─────────────────────────────────────────────────────────────────
    elif cmd == 'flash-boot':
        from .cmd_flash import cmd_flash_boot
        p = base(); p.add_argument('image')
        p.add_argument('--slot')
        p.add_argument('--no-verify', dest='no_verify', action='store_true')
        cmd_flash_boot(p.parse_args(rest))

    elif cmd == 'flash-img':
        from .cmd_flash import cmd_flash_img
        p = base(); p.add_argument('partition'); p.add_argument('image')
        p.add_argument('--slot')
        cmd_flash_img(p.parse_args(rest))

    elif cmd == 'flash-zip':
        from .cmd_flash import cmd_flash_zip
        p = base(); p.add_argument('zipfile')
        p.add_argument('--method', choices=['auto','twrp','sideload'], default='auto')
        cmd_flash_zip(p.parse_args(rest))

    elif cmd == 'magisk-patch':
        from .cmd_flash import cmd_magisk_patch
        p = base(); p.add_argument('--boot','-b')
        p.add_argument('--apk-only', dest='apk_only', action='store_true')
        cmd_magisk_patch(p.parse_args(rest))

    elif cmd == 'twrp':
        from .cmd_flash import cmd_twrp
        p = base(); p.add_argument('--image'); p.add_argument('--device')
        cmd_twrp(p.parse_args(rest))

    elif cmd == 'wipe':
        from .cmd_flash import cmd_wipe
        p = base()
        p.add_argument('target', choices=['cache','data','userdata','dalvik','system-cache','all'], nargs='?', default='cache')
        cmd_wipe(p.parse_args(rest))

    # ── BOOTLOADER ────────────────────────────────────────────────────────────
    elif cmd == 'bl-unlock':
        from .cmd_flash import cmd_bl_unlock
        p = base(); p.add_argument('--brand')
        cmd_bl_unlock(p.parse_args(rest))

    elif cmd in ('bootloader', 'fastboot'):
        from .cmd_boot import cmd_bootloader
        cmd_bootloader(base().parse_args(rest))

    elif cmd == 'unlock':
        from .cmd_flash import cmd_bl_unlock
        p = base(); p.add_argument('--brand')
        cmd_bl_unlock(p.parse_args(rest))

    elif cmd == 'recovery':
        from .cmd_flash import cmd_twrp
        p = base(); p.add_argument('--image'); p.add_argument('--device')
        cmd_twrp(p.parse_args(rest))

    # ── ADB ───────────────────────────────────────────────────────────────────
    elif cmd == 'devices':
        from .cmd_adb import cmd_devices
        cmd_devices(base().parse_args(rest))

    elif cmd == 'shell':
        from .cmd_adb import cmd_shell
        p = base(); p.add_argument('-c','--cmd')
        cmd_shell(p.parse_args(rest))

    elif cmd == 'logcat':
        from .cmd_adb import cmd_logcat
        p = base()
        p.add_argument('-t','--tag'); p.add_argument('-l','--level')
        p.add_argument('-n','--lines', type=int); p.add_argument('--clear', action='store_true')
        cmd_logcat(p.parse_args(rest))

    elif cmd == 'install':
        from .cmd_adb import cmd_install
        p = base(); p.add_argument('apk')
        p.add_argument('-d','--downgrade', action='store_true')
        p.add_argument('-g','--grant', action='store_true')
        cmd_install(p.parse_args(rest))

    elif cmd == 'uninstall':
        from .cmd_adb import cmd_uninstall
        p = base(); p.add_argument('package')
        p.add_argument('-k','--keep_data', action='store_true')
        cmd_uninstall(p.parse_args(rest))

    elif cmd == 'apps':
        from .cmd_adb import cmd_apps
        p = base()
        p.add_argument('--system','-S', action='store_true')
        p.add_argument('-f','--filter')
        p.add_argument('-p','--paths', action='store_true')
        cmd_apps(p.parse_args(rest))

    elif cmd == 'screenshot':
        from .cmd_adb import cmd_screenshot
        p = base(); p.add_argument('-n','--name')
        cmd_screenshot(p.parse_args(rest))

    elif cmd == 'pull':
        from .cmd_adb import cmd_pull
        p = base(); p.add_argument('remote'); p.add_argument('local', nargs='?')
        cmd_pull(p.parse_args(rest))

    elif cmd == 'push':
        from .cmd_adb import cmd_push
        p = base(); p.add_argument('local'); p.add_argument('remote')
        cmd_push(p.parse_args(rest))

    elif cmd == 'sideload':
        from .cmd_adb import cmd_sideload
        p = base(); p.add_argument('zipfile')
        cmd_sideload(p.parse_args(rest))

    elif cmd == 'adb-wifi':
        from .cmd_adb import cmd_adb_wifi
        p = base()
        p.add_argument('--connect'); p.add_argument('--pair')
        p.add_argument('--code'); p.add_argument('--port', type=int)
        cmd_adb_wifi(p.parse_args(rest))

    elif cmd == 'reboot':
        from .cmd_adb import cmd_reboot
        p = base(); p.add_argument('mode', nargs='?', default='system')
        cmd_reboot(p.parse_args(rest))

    # ── DEVICE ────────────────────────────────────────────────────────────────
    elif cmd == 'info':
        from .cmd_device import cmd_info
        cmd_info(base().parse_args(rest))

    elif cmd == 'root-check':
        from .cmd_device import cmd_root_check
        cmd_root_check(base().parse_args(rest))

    elif cmd == 'props':
        from .cmd_device import cmd_props
        p = base(); p.add_argument('-f','--filter')
        cmd_props(p.parse_args(rest))

    elif cmd == 'partitions':
        from .cmd_device import cmd_partitions
        cmd_partitions(base().parse_args(rest))

    # ── DEBLOAT ───────────────────────────────────────────────────────────────
    elif cmd == 'debloat':
        from .cmd_debloat import cmd_debloat_list
        p = base(); p.add_argument('--brand'); p.add_argument('-f','--filter')
        cmd_debloat_list(p.parse_args(rest))

    elif cmd == 'debloat-remove':
        from .cmd_debloat import cmd_debloat_remove
        p = base()
        p.add_argument('--safe', action='store_true')
        p.add_argument('--package')
        p.add_argument('--dry-run', dest='dry_run', action='store_true')
        cmd_debloat_remove(p.parse_args(rest))

    # ── FRIDA ─────────────────────────────────────────────────────────────────
    elif cmd == 'frida-setup':
        from .cmd_frida import cmd_frida_setup
        p = base(); p.add_argument('--auto', action='store_true'); p.add_argument('--version')
        cmd_frida_setup(p.parse_args(rest))

    elif cmd == 'frida-start':
        from .cmd_frida import cmd_frida_start
        cmd_frida_start(base().parse_args(rest))

    elif cmd == 'frida-ps':
        from .cmd_frida import cmd_frida_ps
        cmd_frida_ps(base().parse_args(rest))

    elif cmd == 'objection':
        from .cmd_frida import cmd_objection
        p = base(); p.add_argument('--package')
        cmd_objection(p.parse_args(rest))

    # ── BACKUP ────────────────────────────────────────────────────────────────
    elif cmd == 'backup':
        from .cmd_backup import cmd_backup
        p = base(); p.add_argument('-p','--package'); p.add_argument('-o','--out')
        cmd_backup(p.parse_args(rest))

    elif cmd == 'restore':
        from .cmd_backup import cmd_restore
        p = base(); p.add_argument('src', nargs='?'); p.add_argument('-p','--package')
        cmd_restore(p.parse_args(rest))

    elif cmd == 'backup-data':
        from .cmd_backup import cmd_backup_data
        p = base(); p.add_argument('-p','--package'); p.add_argument('-o','--out')
        cmd_backup_data(p.parse_args(rest))

    elif cmd == 'restore-data':
        from .cmd_backup import cmd_restore_data
        p = base(); p.add_argument('src', nargs='?')
        cmd_restore_data(p.parse_args(rest))

    elif cmd == 'pull-media':
        from .cmd_backup import cmd_pull_media
        p = base(); p.add_argument('-o','--out'); p.add_argument('-f','--filter')
        cmd_pull_media(p.parse_args(rest))

    # ── NETWORK ───────────────────────────────────────────────────────────────
    elif cmd == 'netinfo':
        from .cmd_netdev import cmd_netinfo
        cmd_netinfo(base().parse_args(rest))

    elif cmd == 'wifi-scan':
        from .cmd_netdev import cmd_wifi_scan
        cmd_wifi_scan(base().parse_args(rest))

    elif cmd == 'ping':
        from .cmd_netdev import cmd_ping_device
        p = base(); p.add_argument('host', nargs='?', default='8.8.8.8')
        p.add_argument('-c','--count', type=int, default=4)
        cmd_ping_device(p.parse_args(rest))

    elif cmd == 'traceroute':
        from .cmd_netdev import cmd_traceroute
        p = base(); p.add_argument('host', nargs='?', default='8.8.8.8')
        cmd_traceroute(p.parse_args(rest))

    elif cmd == 'netstat':
        from .cmd_netdev import cmd_netstat
        cmd_netstat(base().parse_args(rest))

    # ── PERFORMANCE ───────────────────────────────────────────────────────────
    elif cmd == 'cpu':
        from .cmd_perf import cmd_cpu
        cmd_cpu(base().parse_args(rest))

    elif cmd == 'thermal':
        from .cmd_perf import cmd_thermal
        cmd_thermal(base().parse_args(rest))

    elif cmd == 'top':
        from .cmd_perf import cmd_top
        p = base(); p.add_argument('-n', type=int, default=15)
        cmd_top(p.parse_args(rest))

    elif cmd == 'fps':
        from .cmd_perf import cmd_fps
        p = base(); p.add_argument('-p','--package')
        cmd_fps(p.parse_args(rest))

    elif cmd == 'meminfo':
        from .cmd_perf import cmd_meminfo
        p = base(); p.add_argument('-p','--package')
        cmd_meminfo(p.parse_args(rest))

    # ── KERNEL ────────────────────────────────────────────────────────────────
    elif cmd == 'kernel':
        from .cmd_kernel import cmd_kernel_info
        cmd_kernel_info(base().parse_args(rest))

    elif cmd == 'dmesg':
        from .cmd_kernel import cmd_dmesg
        p = base(); p.add_argument('-n', type=int, default=50)
        p.add_argument('-f','--filter'); p.add_argument('-l','--level')
        cmd_dmesg(p.parse_args(rest))

    elif cmd == 'modules':
        from .cmd_kernel import cmd_modules
        p = base(); p.add_argument('-f','--filter')
        cmd_modules(p.parse_args(rest))

    elif cmd == 'bootlog':
        from .cmd_kernel import cmd_bootlog
        p = base(); p.add_argument('-n', type=int, default=80)
        cmd_bootlog(p.parse_args(rest))

    elif cmd == 'sysctl':
        from .cmd_kernel import cmd_sysctl
        p = base(); p.add_argument('-f','--filter')
        cmd_sysctl(p.parse_args(rest))

    # ── LOGS ──────────────────────────────────────────────────────────────────
    elif cmd == 'crash':
        from .cmd_logs import cmd_crash
        p = base(); p.add_argument('-n','--lines', type=int)
        cmd_crash(p.parse_args(rest))

    elif cmd == 'battery':
        from .cmd_logs import cmd_battery
        cmd_battery(base().parse_args(rest))

    elif cmd == 'memory':
        from .cmd_logs import cmd_memory
        cmd_memory(base().parse_args(rest))

    else:
        from .utils import c, RED, CYN
        print(f"\n{c(RED,'✗ Unknown command:')} {cmd}")
        print(f"  Run {c(CYN,'luckyboot help')} to see all commands.\n")

if __name__ == '__main__':
    main()