"""ADB commands."""
import os, sys, time, subprocess, re
from .utils import *

def _need_adb():
    if not has_adb():
        err("ADB not installed")
        if is_termux(): info("pkg install android-tools")
        print(); return False
    return True

def cmd_devices(args):
    if not _need_adb(): return
    section('ADB Devices'); print()
    out,_,_=run(['adb','devices','-l'])
    lines=out.strip().split('\n')[1:]
    if not lines or all(not l.strip() for l in lines):
        warn("No devices connected"); info("Enable Developer Options → USB Debugging"); print(); return
    for line in lines:
        if not line.strip(): continue
        p=line.split(); serial=p[0] if p else '?'; status=p[1] if len(p)>1 else '?'
        extra=' '.join(p[2:]) if len(p)>2 else ''
        col=GRN if status=='device' else RED if status=='offline' else YLW
        model=''
        if status=='device':
            m,_,_=adb_cmd(['shell','getprop','ro.product.model'],serial=serial)
            model=m.strip()
        print(f"  {c(CYN+B,serial):<30}{c(col,status):<12}{c(WHT,model):<20}{c(DIM,extra[:40])}")
    print()

def cmd_shell(args):
    if not _need_adb(): return
    serial=getattr(args,'serial',None)
    cmd_str=getattr(args,'cmd',None)
    if cmd_str:
        out,err_s,code=adb_cmd(['shell']+cmd_str.split(),serial=serial)
        if out: print(out)
        if err_s and code!=0: print(c(RED,err_s))
    else:
        adb_args=['adb']
        if serial: adb_args+=['-s',serial]
        adb_args+=['shell']
        print(f"\n  {c(DIM,'Entering ADB shell — type exit to quit')}\n")
        os.execvp('adb',adb_args)

def cmd_logcat(args):
    if not _need_adb(): return
    serial=getattr(args,'serial',None); tag=getattr(args,'tag',None)
    level=(getattr(args,'level',None) or 'V').upper(); clear=getattr(args,'clear',False)
    section('Logcat'); print()
    if clear: adb_cmd(['logcat','-c'],serial=serial); ok("Log cleared"); print(); return
    LC={'V':DIM,'D':BLU,'I':GRN,'W':YLW,'E':RED,'F':RED+B,'S':DIM}
    adb_args=['adb']+(['-s',serial] if serial else [])+['logcat','-v','time']
    if tag: adb_args+=[f'{tag}:{level}','*:S']
    lines=getattr(args,'lines',None) or 0
    if lines>0: adb_args+=['-d','-t',str(lines)]
    try:
        import re as _re
        proc=subprocess.Popen(adb_args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
        print(f"  {c(DIM,'Ctrl+C to stop')}\n")
        for line in proc.stdout:
            line=line.rstrip()
            m=_re.search(r'\s([VDIWEFS])/',line); lvl=m.group(1) if m else 'V'
            col=LC.get(lvl,WHT)
            line=_re.sub(r'(Exception|Error|FATAL|ANR)',c(RED+B,r'\1'),line)
            print(c(col,line))
    except KeyboardInterrupt: print(f"\n{c(DIM,'Stopped.')}\n"); proc.terminate()

def cmd_install(args):
    if not _need_adb(): return
    serial=getattr(args,'serial',None); apk=getattr(args,'apk','')
    if not os.path.exists(apk): err(f"APK not found: {apk}"); print(); return
    section(f'Install APK: {os.path.basename(apk)}'); print()
    sz=os.path.getsize(apk)/(1024*1024); info(f"Size: {sz:.1f} MB")
    flags=['-r']
    if getattr(args,'downgrade',False): flags.append('-d')
    if getattr(args,'grant',False): flags.append('-g')
    sp=Spinner('Installing...'); sp.start()
    out,err_s,code=adb_cmd(['install']+flags+[apk],serial=serial)
    sp.stop()
    if code==0 and 'Success' in out: ok("Installed successfully!")
    else: err(f"Failed: {(err_s or out)[:200]}")
    print()

def cmd_uninstall(args):
    if not _need_adb(): return
    serial=getattr(args,'serial',None); package=getattr(args,'package','')
    section(f'Uninstall: {package}'); print()
    sp=Spinner('Uninstalling...'); sp.start()
    out,err_s,code=adb_cmd(['uninstall',package],serial=serial)
    sp.stop()
    if code==0: ok("Uninstalled")
    else: err(f"{out or err_s}")
    print()

def cmd_apps(args):
    serial   = getattr(args, 'serial', None)
    show_sys = getattr(args, 'system', False)
    filt     = getattr(args, 'filter', None)
    section('Installed Apps'); print()
    # If filtering, search ALL packages (system + user); -3 would miss system apps like Google
    # Use --show-versioncode is not needed; just list all when filter active
    flags = [] if (show_sys or filt) else ['-3']
    import subprocess as _sp, re as _re2
    out = ''
    try:
        r = _sp.run(['cmd','package','list','packages']+flags,
                    capture_output=True, text=True, timeout=20)
        if r.returncode == 0 and r.stdout.strip():
            out = r.stdout
    except: pass
    if not out:
        out, _, _ = adb_cmd(['shell','cmd','package','list','packages']+flags, serial=serial)
    if not out:
        err('Cannot list packages')
        print()
        return
    packages = []
    for ln in out.strip().splitlines():
        ln = ln.strip()
        m = _re2.match(r'package:(.+)', ln)
        if m:
            packages.append(m.group(1).strip())
    packages.sort()
    count = 0
    for pkg in packages:
        if filt and filt.lower() not in pkg.lower():
            continue
        print('  ' + c(CYN, pkg))
        count += 1
    print()
    label = 'apps' if not show_sys and not filt else 'packages'
    print('  ' + c(B, str(count)) + ' ' + label)
    print()

def cmd_screenshot(args):
    if not _need_adb(): return
    serial=getattr(args,'serial',None)
    name=getattr(args,'name',None) or f"screen_{int(time.time())}.png"
    section('Screenshot'); print()
    sp=Spinner('Capturing...'); sp.start()
    _,_,code=adb_cmd(['shell','screencap','-p','/sdcard/lb_tmp.png'],serial=serial)
    sp.stop()
    if code!=0: err("screencap failed"); print(); return
    out,err_s,code=adb_cmd(['pull','/sdcard/lb_tmp.png',name],serial=serial)
    adb_cmd(['shell','rm','/sdcard/lb_tmp.png'],serial=serial)
    if code==0:
        ok(f"Saved: {c(CYN,name)}")
        sz=os.path.getsize(name)/1024; info(f"Size: {sz:.0f} KB")
    else: err(f"Pull failed: {err_s[:100]}")
    print()

def cmd_pull(args):
    if not _need_adb(): return
    serial=getattr(args,'serial',None); remote=args.remote; local=getattr(args,'local',None) or '.'
    section(f'Pull: {remote}'); print()
    sp=Spinner(f'Pulling...'); sp.start()
    out,err_s,code=adb_cmd(['pull',remote,local],serial=serial)
    sp.stop()
    if code==0: ok(f"Saved to: {c(CYN,local)}")
    else: err(err_s[:200])
    print()

def cmd_push(args):
    if not _need_adb(): return
    serial=getattr(args,'serial',None); local=args.local; remote=args.remote
    section(f'Push: {os.path.basename(local)}'); print()
    if not os.path.exists(local): err(f"Not found: {local}"); print(); return
    sp=Spinner('Pushing...'); sp.start()
    out,err_s,code=adb_cmd(['push',local,remote],serial=serial)
    sp.stop()
    if code==0: ok(f"Pushed to: {c(CYN,remote)}")
    else: err(err_s[:200])
    print()

def cmd_sideload(args):
    if not _need_adb(): return
    serial=getattr(args,'serial',None); zipfile=args.zipfile
    if not os.path.exists(zipfile): err(f"Not found: {zipfile}"); print(); return
    section(f'Sideload: {os.path.basename(zipfile)}'); print()
    warn("Device must be in sideload mode")
    info("From recovery: Advanced → ADB Sideload")
    sz=os.path.getsize(zipfile)/(1024*1024); info(f"Size: {sz:.1f} MB")
    sp=Spinner('Sideloading...'); sp.start()
    out,err_s,code=adb_cmd(['sideload',zipfile],serial=serial)
    sp.stop()
    if code==0: ok("Sideload complete!")
    else: err(f"Failed: {err_s[:200]}")
    print()

def cmd_adb_wifi(args):
    section('ADB over WiFi'); print()
    if not _need_adb(): return
    serial=getattr(args,'serial',None); port=getattr(args,'port',None) or 5555
    if getattr(args,'connect',None):
        ip=args.connect
        out,err_s,_=run(['adb','connect',f'{ip}:{port}'])
        if 'connected' in out.lower(): ok(f"Connected: {c(GRN,f'{ip}:{port}')}")
        else: err(out or err_s)
    else:
        _,_,code=adb_cmd(['tcpip',str(port)],serial=serial)
        if code==0:
            ok(f"ADB TCP enabled on port {port}")
            ip_out,_,_=adb_cmd(['shell','ip','route'],serial=serial)
            import re as _re; m=_re.search(r'src (\d+\.\d+\.\d+\.\d+)',ip_out)
            if m: info(f"Device IP: {c(GRN,m.group(1))} → luckyboot adb-wifi --connect {m.group(1)}")
        else: err("Failed — USB device must be connected first")
    print()

def cmd_reboot(args):
    if not _need_adb(): return
    serial=getattr(args,'serial',None); mode=getattr(args,'mode',None) or 'system'
    section(f'Reboot → {mode}'); print()
    cmd_map={'system':['reboot'],'recovery':['reboot','recovery'],
             'bootloader':['reboot','bootloader'],'fastboot':['reboot','bootloader'],
             'edl':['reboot','edl'],'sideload':['reboot','sideload']}
    adb_args=cmd_map.get(mode,['reboot'])
    warn(f"Rebooting to {mode}...")
    _,_,code=adb_cmd(['shell']+adb_args,serial=serial)
    if code==0: ok("Reboot command sent")
    else:
        _,_,code=adb_cmd(adb_args,serial=serial)
        if code==0: ok("Reboot command sent")
        else: err("Reboot failed")
    print()
