"""Device info, root-check, props, partitions — works on-device in Termux."""
import os, re, subprocess
from .utils import *

MAGISK_PATHS = ['/data/adb/magisk', '/sbin/.magisk', '/data/adb/magisk.db']
KSU_PATHS    = ['/data/adb/ksu', '/data/adb/ksud']
SUPERSU_PATHS= ['/system/xbin/daemonsu', '/system/etc/.installed_su_daemon']
ROOT_BINS    = ['/sbin/su', '/system/bin/su', '/system/xbin/su', '/su/bin/su']

def _read(path):
    try: return open(path).read()
    except: return ""

def _shell(cmd):
    try:
        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=10)
        return r.stdout.strip()
    except: return ""

def cmd_info(args):
    section('Device Info'); print()
    props = {
        'Model':       'ro.product.model',
        'Brand':       'ro.product.brand',
        'Device':      'ro.product.device',
        'Android':     'ro.build.version.release',
        'SDK':         'ro.build.version.sdk',
        'Build':       'ro.build.display.id',
        'Arch':        'ro.product.cpu.abi',
        'Board':       'ro.product.board',
        'Bootloader':  'ro.bootloader',
        'Hardware':    'ro.hardware',
        'Fingerprint': 'ro.build.fingerprint',
    }
    # Add kernel version from uname
    import subprocess as _sp2
    try:
        kr = _sp2.run(['uname','-r'], capture_output=True, text=True, timeout=5)
        kver = kr.stdout.strip()
    except: kver = ''
    if not kver:
        try: kver = open('/proc/version').read().split()[2]
        except: pass
    if kver:
        print(f"  {c(B, 'Kernel:'):<22} {c(GRN, kver)}")
    for label, key in props.items():
        val = get_prop(key)
        print(f"  {c(B, label+':'):<22} {c(GRN if val else DIM, val or '?')}")
    print()

    # RAM
    mi = _read('/proc/meminfo')
    if mi:
        tot = re.search(r'MemTotal:\s+(\d+)', mi)
        avl = re.search(r'MemAvailable:\s+(\d+)', mi)
        if tot:
            tm = int(tot.group(1)) // 1024
            am = int(avl.group(1)) // 1024 if avl else 0
            um = tm - am
            bl = int((um / tm) * 30) if tm else 0
            col = RED if um/tm > 0.85 else YLW if um/tm > 0.6 else GRN
            bar = c(col, '█'*bl) + c(DIM, '░'*(30-bl))
            print(f"  {c(B,'RAM:  ')}  {bar} {c(YLW,str(um)+'MB')} / {c(WHT,str(tm)+'MB')}")

    # CPU
    ci = _read('/proc/cpuinfo')
    if ci:
        hw    = re.search(r'Hardware\s*:\s*(.+)', ci)
        cores = ci.count('processor\t:')
        mod   = re.search(r'model name\s*:\s*(.+)', ci)
        raw = hw.group(1) if hw else mod.group(1) if mod else ''
        cs  = raw.strip() if raw.strip() else (
            _shell('getprop ro.boot.auto.chipid 2>/dev/null') or
            _shell('getprop ro.hardware 2>/dev/null') or
            _shell('getprop ro.board.platform 2>/dev/null') or '?'
        )
        print(f"  {c(B,'CPU:  ')}  {c(WHT, cs)} {c(DIM, f'({cores} cores)')}")

    # Storage
    df = _shell('df -h /data')
    if df:
        parts = df.strip().split('\n')
        if len(parts) > 1:
            p = parts[1].split()
            if len(p) >= 4:
                print(f"  {c(B,'Storage:')} {c(YLW,p[2])} used / {c(WHT,p[1])} total")
    print()

def cmd_root_check(args):
    section('Root Status Check'); print()
    rooted = False; root_method = None

    sp = Spinner('Testing su access...'); sp.start()
    su_out, su_err, su_code = run(['su', '-c', 'id'], timeout=6)
    sp.stop()
    if su_code == 0 and 'uid=0' in su_out:
        ok(f"su works → {c(GRN, su_out.strip())}"); rooted = True
    else:
        err(f"su not available ({su_err[:60] if su_err else 'no response'})")
    print()

    # Detect root manager — check paths directly (no run_root needed)
    for path in MAGISK_PATHS:
        if os.path.exists(path):
            ok(f"Magisk detected: {c(CYN, path)}")
            root_method = 'magisk'; rooted = True
            mv = _shell('magisk -v 2>/dev/null')
            if mv: info(f"Version: {mv[:40]}")
            break
    if not root_method:
        for path in KSU_PATHS:
            if os.path.exists(path):
                ok(f"KernelSU detected: {c(CYN, path)}")
                root_method = 'kernelsu'; rooted = True; break
    if not root_method:
        for path in SUPERSU_PATHS:
            if os.path.exists(path):
                ok(f"SuperSU detected: {c(CYN, path)}")
                root_method = 'supersu'; rooted = True; break
    if not root_method:
        found = [p for p in ROOT_BINS if os.path.exists(p)]
        if found: warn(f"Root binary found: {found[0]}"); root_method = 'unknown'
        else: err("No root manager detected")
    print()

    sel = _shell('getenforce 2>/dev/null')
    if sel:
        print(f"  {c(B,'SELinux:'):<16} {c(YLW if 'Enforcing' in sel else GRN, sel)}")

    bl = get_prop('ro.boot.flash.locked') or get_prop('ro.secureboot.lockstate')
    if bl:
        locked = bl in ('1', 'locked', 'true')
        print(f"  {c(B,'Bootloader:'):<16} {c(RED,'LOCKED') if locked else c(GRN,'UNLOCKED')}")
    print()

    if rooted: ok(c(GRN+B, f"Device IS rooted ({root_method or 'detected'})"))
    else:
        err(c(RED+B, "Device is NOT rooted"))
        print(f"\n  Run {c(CYN+B,'luckyboot root')} to root it.\n")

def cmd_props(args):
    section('Build Properties'); print()
    filt = getattr(args, 'filter', None)
    out  = _shell('getprop')
    if not out: err("Cannot read props"); print(); return
    try:
        for line in out.split('\n'):
            if not line.strip(): continue
            if filt and filt.lower() not in line.lower(): continue
            m = re.match(r'\[([^\]]+)\]:\s*\[([^\]]*)\]', line)
            if m:
                k, v = m.group(1), m.group(2)
                col = CYN if any(x in k for x in ['version','model','brand','build']) else BLU
                print(f"  {c(col,k):<45} {c(WHT,v)}")
    except BrokenPipeError:
        pass
    print()

def cmd_partitions(args):
    section('Partitions'); print()
    raw = _read('/proc/partitions')
    if raw:
        print(f"  {c(B+WHT,'Name'):<24} {c(B+WHT,'Size')}\n  {c(DIM,chr(8212)*35)}")
        for line in raw.strip().split('\n')[2:]:
            p = line.split()
            if len(p) < 4: continue
            nm = p[3]
            try: sz = int(p[2]) // 1024
            except: continue
            if sz == 0: continue
            col = GRN if re.search(r'mmcblk\d+p\d+', nm) else YLW if 'mmcblk' in nm else DIM
            print(f"  {c(col, nm):<24} {c(YLW, str(sz)+'MB') if sz > 1 else c(DIM,p[2]+'K')}")

    mnt = _read('/proc/mounts')
    if mnt:
        print(f"\n  {c(B,'Mounted:')}")
        imp = ['system','vendor','data','cache','boot','recovery','odm','product']
        seen = set()
        for line in mnt.split('\n'):
            p = line.split()
            if len(p) >= 4 and any(k in p[1] for k in imp) and p[1] not in seen:
                seen.add(p[1])
                opts = p[3].split(',')
                rw = c(GRN,'rw') if 'rw' in opts else c(RED,'ro')
                dev = p[0][:28]
                mntpt = p[1][:30]
                print(f"  {c(BLU,dev):<30}  {c(WHT,mntpt):<32}  {rw}")
    print()
