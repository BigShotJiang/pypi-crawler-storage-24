"""Debloat helper: list bloatware, safely remove by brand."""
import json
from .utils import *

# Common bloatware by brand/category
BLOAT_DB = {
    'samsung': [
        'com.samsung.android.game.gametools','com.samsung.android.game.gamehome',
        'com.samsung.android.bixby.agent','com.samsung.android.bixby.wakeup',
        'com.samsung.android.bixby.service','com.samsung.android.app.spage',
        'com.samsung.android.app.tips','com.samsung.android.arzone',
        'com.samsung.android.dynamiclock','com.samsung.android.themestore',
        'com.samsung.android.app.dressroom','com.samsung.android.app.galaxyfinder',
        'com.samsung.android.kidsinstaller','com.samsung.android.mdecservice',
        'com.samsung.android.messaging','com.samsung.android.email.provider',
    ],
    'xiaomi': [
        'com.miui.analytics','com.xiaomi.mipicks','com.miui.msa.global',
        'com.miui.daemon','com.miui.contentcatcher','com.miui.bugreport',
        'com.duokan.phone.remotecontroller','com.miui.video','com.miui.player',
        'com.miui.fm','com.mi.global.shop','com.xiaomi.payment',
        'com.mipay.wallet.id','com.miui.yellowpage',
    ],
    'oppo': [
        'com.oppo.market','com.nearme.gamecenter','com.coloros.health',
        'com.oplus.statistics.rom','com.oplus.ota','com.nearme.statistics.rom',
        'com.coloros.safecenter','com.coloros.weather',
    ],
    'generic': [
        'com.facebook.appmanager','com.facebook.services','com.facebook.katana',
        'com.facebook.system','com.instagram.android',
        'com.google.android.apps.tachyon','com.google.android.videos',
        'com.google.android.music','com.google.android.apps.magazines',
        'com.google.android.apps.subscriptions.red',
        'com.microsoft.teams','com.linkedin.android',
        'com.amazon.appmanager',
    ],
}

SAFE_TO_REMOVE = set()
for pkgs in BLOAT_DB.values():
    SAFE_TO_REMOVE.update(pkgs)

def _get_packages(serial=None):
    import subprocess as _sp
    out = ''
    # Try cmd package list (works in Termux without root/ADB)
    try:
        r = _sp.run(['cmd','package','list','packages'],
                    capture_output=True, text=True, timeout=20)
        if r.returncode == 0 and r.stdout.strip():
            out = r.stdout
    except: pass
    # ADB fallback
    if not out:
        out, _, _ = adb_cmd(['shell','cmd','package','list','packages'], serial=serial)
    if not out:
        out, _, _ = adb_cmd(['shell','pm','list','packages'], serial=serial)
    pkgs = []
    for line in out.strip().splitlines():
        line = line.strip().replace('package:','')
        if line: pkgs.append(line)
    return pkgs

def cmd_debloat_list(args):
    """List installed bloatware."""
    serial = getattr(args,'serial',None)
    brand  = (getattr(args,'brand',None) or get_prop('ro.product.brand') or '').lower()
    section(f'Bloatware Scanner'); print()
    info(f"Brand: {c(YLW, brand or 'auto-detect')}")
    sp = Spinner('Scanning packages...')
    sp.start()
    installed = set(_get_packages(serial))
    sp.stop()
    if not installed:
        err("Could not list packages — is ADB enabled?"); print(); return

    # Build target list
    targets = list(BLOAT_DB.get('generic', []))
    for b, pkgs in BLOAT_DB.items():
        if b != 'generic' and b in brand:
            targets.extend(pkgs)

    found = [(p, p in SAFE_TO_REMOVE) for p in targets if p in installed]
    custom_filter = getattr(args,'filter',None)
    if custom_filter:
        found += [(p,'?') for p in installed if custom_filter.lower() in p.lower() and p not in [f[0] for f in found]]

    if not found:
        ok("No known bloatware found!"); print(); return

    print(f"\n  {c(B,'Found')} {c(RED+B, str(len(found)))} bloatware packages:\n")
    for pkg, safe in found:
        icon = c(GRN,'✓ safe') if safe else c(YLW,'? check')
        print(f"  {icon:<14} {c(RED if not safe else DIM, pkg)}")
    print()
    info(f"Remove all safe ones: {c(CYN+B,'luckyboot debloat --remove --safe')}")
    info(f"Remove specific:      {c(CYN,'luckyboot debloat --remove com.package.name')}")
    print()

def cmd_debloat_remove(args):
    serial  = getattr(args,'serial',None)
    safe    = getattr(args,'safe',False)
    package = getattr(args,'package',None)
    dry_run = getattr(args,'dry_run',False)
    section('Debloat — Remove Packages'); print()

    if dry_run: warn("DRY RUN — not actually removing\n")

    if safe:
        sp = Spinner('Scanning...')
        sp.start()
        installed = set(_get_packages(serial))
        sp.stop()
        brand = get_prop('ro.product.brand').lower()
        targets = list(BLOAT_DB.get('generic',[]))
        for b,pkgs in BLOAT_DB.items():
            if b != 'generic' and b in brand:
                targets.extend(pkgs)
        to_remove = [p for p in targets if p in installed and p in SAFE_TO_REMOVE]
    elif package:
        to_remove = [package]
    else:
        err("Use --safe to remove all known-safe bloatware, or --package com.xxx")
        print(); return

    if not to_remove:
        ok("Nothing to remove"); print(); return

    print(f"  Removing {c(RED+B, str(len(to_remove)))} packages...\n")
    ok_count = 0; fail_count = 0
    for pkg in to_remove:
        if dry_run:
            print(f"  {c(DIM,'[dry-run]')} would remove: {c(YLW, pkg)}")
            ok_count += 1; continue
        out, err_s, code = adb_cmd(['shell','pm','uninstall','-k','--user','0',pkg], serial=serial)
        if code == 0 and ('Success' in out or 'success' in out):
            print(f"  {c(GRN,'✓')} {c(DIM,pkg)}")
            ok_count += 1
        else:
            # Try disable instead
            out2, _, code2 = adb_cmd(['shell','pm','disable-user','--user','0',pkg], serial=serial)
            if code2 == 0:
                print(f"  {c(YLW,'~')} {c(DIM,pkg)} {c(DIM,'(disabled)')}")
                ok_count += 1
            else:
                print(f"  {c(RED,'✗')} {pkg} {c(DIM,'(need root or failed)')}")
                fail_count += 1
    print(f"\n  {c(GRN, str(ok_count)+' removed/disabled')}  {c(RED if fail_count else DIM, str(fail_count)+' failed')}\n")
