"""
cmd_root_auto.py — fully automatic root for luckyboot
Strategies (in order):
  1. GKI device (kernel 5.10+, Android 12+) → KernelSU boot.img from GitHub
  2. Google Pixel → factory image from Google, extract boot.img
  3. Bootloader unlocked → dd dump boot partition directly from device
  4. Magisk patch flow (user provides/downloads boot.img)
  5. Bootloader locked → unlock first, then retry
"""
import os, re, time, json, urllib.request, subprocess, zipfile, shutil
from .utils   import (c, B, GRN, RED, YLW, CYN, WHT, DIM, BLU,
                      section, info, warn, err, ok, step,
                      get_prop, run, Spinner,
                      adb_cmd, _require_adb, _confirm, _download_file,
                      _wait_for_adb)
from .cmd_flash import cmd_flash_boot

MAGISK_RELEASES = 'https://api.github.com/repos/topjohnwu/Magisk/releases/latest'
KSU_RELEASES    = 'https://api.github.com/repos/tiann/KernelSU/releases/latest'


# ── Device snapshot ───────────────────────────────────────────────────────────

def _device_snapshot():
    d = {}
    d['model']     = get_prop('ro.product.model')
    d['brand']     = get_prop('ro.product.brand')
    d['device']    = get_prop('ro.product.device')
    d['android']   = get_prop('ro.build.version.release')
    d['sdk']       = get_prop('ro.build.version.sdk')
    d['build']     = get_prop('ro.build.display.id')
    d['arch']      = get_prop('ro.product.cpu.abi')
    d['board']     = get_prop('ro.product.board')
    d['bl_locked'] = get_prop('ro.boot.flash.locked') or get_prop('ro.secureboot.lockstate')
    d['verifiedboot'] = get_prop('ro.boot.verifiedbootstate')
    d['selinux']   = get_prop('ro.boot.selinux')
    d['ab_device'] = bool(get_prop('ro.boot.slot_suffix'))
    d['slot']      = get_prop('ro.boot.slot_suffix')
    kver = ''
    try:
        kinfo = open('/proc/version').read()
        m = re.search(r'Linux version ([\d.]+[-\w.]*)', kinfo)
        if m: kver = m.group(1)
    except: pass
    if not kver:
        try:
            r = subprocess.run(['uname','-r'], capture_output=True, text=True, timeout=5)
            kver = r.stdout.strip()
        except: pass
    d['kernel'] = kver
    return d

def _is_rooted():
    o, _, c_ = run(['su','-c','id'], timeout=5)
    return c_==0 and 'uid=0' in o

def _has_magisk():
    paths = ['/data/adb/magisk','/sbin/.magisk','/data/adb/magisk.db']
    return any(os.path.exists(p) for p in paths)

def _bl_is_unlocked(d):
    bl = d.get('bl_locked','')
    if bl in ('0','unlocked','false'): return True
    if bl in ('1','locked','true'):    return False
    vb = d.get('verifiedboot','')
    if vb == 'orange': return True
    if vb == 'green':  return False
    return None

def _print_device(d):
    brand = d.get('brand','?'); model = d.get('model','?')
    android = d.get('android','?'); sdk = d.get('sdk','?')
    arch    = d.get('arch','?');    kernel = d.get('kernel','')
    bl = d.get('bl_locked','')
    bl_str = {None:'unknown','0':'UNLOCKED','unlocked':'UNLOCKED','false':'UNLOCKED',
              '1':'LOCKED','locked':'LOCKED','true':'LOCKED'}.get(bl, bl or 'unknown')
    bl_col = GRN if bl_str=='UNLOCKED' else RED if bl_str=='LOCKED' else YLW
    print(f"  {c(B,'Device:   ')} {c(GRN+B, brand+' '+model)}")
    print(f"  {c(B,'Android:  ')} {c(WHT, android)} (SDK {sdk})")
    kernel_display = kernel
    if not kernel_display:
        try:
            kernel_display = subprocess.run(['uname','-r'], capture_output=True,
                                            text=True, timeout=5).stdout.strip()
        except: pass
    print(f"  {c(B,'Kernel:   ')} {c(CYN, kernel_display or '?')}")
    print(f"  {c(B,'Arch:     ')} {c(YLW, arch)}")
    print(f"  {c(B,'A/B:      ')} {c(GRN,'yes (slot '+d.get('slot','?')+')') if d.get('ab_device') else c(DIM,'no')}")
    print(f"  {c(B,'Bootloader:')} {c(bl_col, bl_str)}")


# ── KernelSU GKI auto-root ────────────────────────────────────────────────────

def _parse_kmi(kver):
    """Extract KMI string from kernel version e.g. 5.15.149-android13-8-... → android13-5.15"""
    m = re.search(r'(android\d+)-([\d]+\.[\d]+)', kver)
    if m: return f"{m.group(1)}-{m.group(2)}"
    m = re.search(r'([\d]+\.[\d]+)', kver)
    if m:
        parts = m.group(1).split('.')
        return f"android13-{parts[0]}.{parts[1]}"
    return None

def _ksu_find_boot(kmi, arch='arm64'):
    """Find KernelSU boot.img URL matching kmi from GitHub releases."""
    info(f"Searching KernelSU releases for KMI: {c(CYN, kmi)}")
    try:
        req = urllib.request.Request(KSU_RELEASES, headers={'User-Agent': 'luckyboot'})
        with urllib.request.urlopen(req, timeout=15) as r:
            data = json.loads(r.read())
        assets = data.get('assets', [])
        # Look for boot-<kmi>.img or boot-<kmi>-<arch>.img
        candidates = []
        for a in assets:
            name = a['name'].lower()
            if 'boot' in name and kmi.lower() in name and name.endswith('.img'):
                candidates.append(a)
        if not candidates:
            # Try partial match on kernel version
            kparts = kmi.split('-')
            for a in assets:
                name = a['name'].lower()
                if 'boot' in name and name.endswith('.img'):
                    if any(p in name for p in kparts):
                        candidates.append(a)
        if candidates:
            # Prefer lz4 > gz > plain
            for pref in ['lz4', 'gz', '']:
                for c_ in candidates:
                    if pref in c_['name'].lower() or pref == '':
                        return c_['browser_download_url'], c_['name']
    except Exception as e:
        warn(f"KernelSU API error: {e}")
    return None, None

def _gki_root(d, serial):
    """Root GKI device via KernelSU — no boot.img needed from user."""
    kver = d.get('kernel', '')
    arch = 'arm64' if 'arm64' in d.get('arch','') else 'x86_64'
    kmi  = _parse_kmi(kver)
    if not kmi:
        warn("Could not determine KMI from kernel version")
        return False

    print()
    info(f"GKI device detected — using KernelSU (no boot.img needed)")
    info(f"Kernel: {c(CYN, kver)}")
    info(f"KMI:    {c(CYN, kmi)}")
    print()

    url, fname = _ksu_find_boot(kmi, arch)
    if not url:
        warn(f"No pre-built KernelSU image found for KMI {kmi}")
        info("Try manually: https://github.com/tiann/KernelSU/releases")
        return False

    ok(f"Found: {c(GRN, fname)}")
    print()

    # Confirm with user before flashing
    brand = d.get('brand','?'); model = d.get('model','?')
    build = d.get('build','?')
    print(f"  {c(YLW+B,'⚠ About to flash KernelSU boot image')}")
    print(f"  Device:  {c(CYN, brand+' '+model)}")
    print(f"  Build:   {c(CYN, build)}")
    print(f"  Image:   {c(CYN, fname)}")
    print()
    if not _confirm(f"Is this your phone? Proceed with KernelSU root?"):
        warn("Cancelled by user"); return False

    step(1, 3, f"Downloading {fname}")
    if not _download_file(url, fname):
        err("Download failed"); return False
    ok(f"Downloaded {fname}")

    step(2, 3, "Flashing KernelSU boot image")
    from argparse import Namespace
    flash_args = Namespace(image=fname, serial=serial, slot=None,
                           yes=True, no_reboot=False, no_verify=False)
    cmd_flash_boot(flash_args)

    step(3, 3, "Waiting for device to boot")
    time.sleep(5)
    if _wait_for_adb(serial, 120):
        time.sleep(5)
        if _is_rooted():
            ok(c(GRN+B, "ROOT SUCCESSFUL via KernelSU! 🎉"))
            info("Install KernelSU Manager APK to manage root permissions")
            info("Download: https://github.com/tiann/KernelSU/releases")
            return True
        else:
            warn("Device booted — open KernelSU Manager to complete setup")
            _install_ksu_apk(serial)
            return True
    warn("Device did not come back online — check manually")
    return False


# ── Google Pixel auto-root ────────────────────────────────────────────────────

PIXEL_FACTORY_BASE = 'https://dl.google.com/dl/android/aosp/'
PIXEL_CODENAMES = {
    'flame','coral','sunfish','bramble','redfin','barbet','oriole','raven',
    'bluejay','panther','cheetah','lynx','tangorpro','felix','shiba','husky',
    'akita','caiman','komodo','tokay'
}

def _pixel_root(d, serial):
    """Auto-root Google Pixel by downloading factory image."""
    device  = d.get('device','').lower()
    build   = d.get('build','')
    if device not in PIXEL_CODENAMES:
        return False

    info(f"Google Pixel detected ({device})")
    build_lower = build.lower().replace('.','').replace('_','')

    # Build factory image URL pattern: https://dl.google.com/dl/android/aosp/device-buildid-factory-xxx.zip
    search_url = f"https://developers.google.com/android/images#{device}"
    info(f"Factory images: {c(CYN, search_url)}")

    # Try direct download from Google
    try:
        req = urllib.request.Request(
            f"https://dl.google.com/dl/android/aosp/{device}-{build.lower()}-factory-latest.zip",
            headers={'User-Agent': 'luckyboot'}, method='HEAD')
        urllib.request.urlopen(req, timeout=10)
        dl_url = req.full_url
    except:
        warn("Could not find factory image URL automatically")
        info(f"Download manually from: {c(CYN, search_url)}")
        info(f"Look for build: {c(CYN, build)}")
        info(f"Then run: {c(CYN,'luckyboot root --boot boot.img')}")
        return False

    print()
    if not _confirm(f"Download factory image for {device} ({build})? (~1GB)"):
        return False

    # Download, extract boot.img, patch with Magisk, flash
    step(1, 4, "Downloading factory image")
    fname = f"{device}-factory.zip"
    if not _download_file(dl_url, fname):
        err("Download failed"); return False

    step(2, 4, "Extracting boot.img")
    boot_path = _extract_boot_from_zip(fname)
    if not boot_path:
        err("Could not extract boot.img"); return False
    ok(f"Extracted: {boot_path}")

    return _magisk_patch_and_flash(d, serial, boot_path)


# ── DD dump boot from device (unlocked bootloader) ───────────────────────────

def _dd_dump_boot(d, serial):
    """Dump boot partition directly via dd — requires unlocked bootloader."""
    slot = d.get('slot', '')
    partition = f"boot{slot}" if slot else "boot"
    info(f"Dumping /{partition} partition via dd")

    # Find block device
    boot_block = None
    candidates = [
        f'/dev/block/by-name/{partition}',
        f'/dev/block/bootdevice/by-name/{partition}',
        f'/dev/block/platform/*/by-name/{partition}',
    ]
    for path in candidates:
        out, _, code = adb_cmd(['shell', f'ls {path} 2>/dev/null'], serial=serial)
        if code == 0 and out.strip():
            boot_block = out.strip().splitlines()[0]
            break

    if not boot_block:
        out, _, _ = adb_cmd(['shell', f'find /dev/block -name "{partition}" 2>/dev/null | head -1'], serial=serial)
        if out.strip():
            boot_block = out.strip()

    if not boot_block:
        warn(f"Could not find {partition} block device")
        return None

    ok(f"Found: {c(CYN, boot_block)}")
    step(1, 3, f"Dumping {partition} partition")
    out_path = f'/sdcard/stock_{partition}.img'
    _, err_s, code = adb_cmd(['shell', f'dd if={boot_block} of={out_path} bs=4096 2>/dev/null'], serial=serial)
    if code != 0:
        # Try with su
        _, _, code = adb_cmd(['shell', f'su -c "dd if={boot_block} of={out_path} bs=4096"'], serial=serial)
    if code != 0:
        warn(f"dd failed: {err_s[:100]}")
        return None

    step(2, 3, "Pulling boot.img to device")
    local_path = f'stock_{partition}.img'
    _, _, code = adb_cmd(['pull', out_path, local_path], serial=serial)
    if code != 0:
        warn("adb pull failed"); return None

    ok(f"Dumped: {c(GRN, local_path)}")
    return local_path


# ── Magisk patch + flash ──────────────────────────────────────────────────────

def _magisk_patch_and_flash(d, serial, boot_path):
    """Patch boot.img with Magisk app on device, pull back, flash."""
    step(1, 4, "Installing Magisk APK")
    _install_magisk_apk(serial)

    step(2, 4, "Pushing boot.img to device for patching")
    remote = '/sdcard/stock_boot.img'
    _, _, code = adb_cmd(['push', boot_path, remote], serial=serial)
    if code != 0:
        err("Could not push boot.img to device"); return False

    print()
    info(f"{c(YLW+B,'ACTION REQUIRED:')}")
    info("1. Open Magisk app on your device")
    info("2. Tap Install → Select and Patch a File")
    info(f"3. Select: {c(CYN, remote)}")
    info("4. Tap Let's go, wait for patching to finish")
    print()
    input(f"  {c(B,'Press ENTER when Magisk has finished patching...')} ")

    step(3, 4, "Pulling patched boot.img")
    out, _, _ = adb_cmd(['shell', 'ls /sdcard/Download/magisk_patched*.img 2>/dev/null'], serial=serial)
    patched = out.strip().splitlines()[0] if out.strip() else None
    if not patched:
        warn("Could not find magisk_patched*.img in /sdcard/Download/")
        path = input(f"  {c(B,'Enter path manually (or blank to cancel): ')}").strip()
        if not path: return False
        patched = path

    local_patched = 'magisk_patched.img'
    _, _, code = adb_cmd(['pull', patched, local_patched], serial=serial)
    if code != 0:
        err("Could not pull patched image"); return False
    ok(f"Pulled: {c(GRN, local_patched)}")

    step(4, 4, "Flashing patched boot.img")
    from argparse import Namespace
    flash_args = Namespace(image=local_patched, serial=serial, slot=None,
                           yes=True, no_reboot=False, no_verify=False)
    cmd_flash_boot(flash_args)
    time.sleep(5)
    if _wait_for_adb(serial, 120):
        time.sleep(5)
        if _is_rooted():
            ok(c(GRN+B, "ROOT SUCCESSFUL via Magisk! 🎉"))
            return True
        else:
            warn("Device booted — open Magisk app to complete setup")
            return True
    warn("Device did not come back online — check manually")
    return False


# ── Zip/payload extraction ────────────────────────────────────────────────────

def _extract_boot_from_zip(zip_path):
    """Extract boot.img from a factory zip or OTA zip."""
    try:
        with zipfile.ZipFile(zip_path) as z:
            names = z.namelist()
            # Direct boot.img
            for name in names:
                if name.endswith('boot.img') and 'init_boot' not in name:
                    z.extract(name, '.')
                    return name
            # Nested zip (Google factory format: image-device-build.zip inside)
            for name in names:
                if name.endswith('.zip') and 'image' in name:
                    z.extract(name, '.')
                    inner = _extract_boot_from_zip(name)
                    if inner: return inner
            # payload.bin — need payload-dumper
            if 'payload.bin' in names:
                warn("payload.bin format — trying payload-dumper-go")
                z.extract('payload.bin', '.')
                out = subprocess.run(
                    ['payload-dumper-go', '-partitions', 'boot', 'payload.bin'],
                    capture_output=True, text=True, timeout=120
                )
                if out.returncode == 0:
                    for root, _, files in os.walk('.'):
                        for f in files:
                            if f == 'boot.img':
                                return os.path.join(root, f)
                warn("payload-dumper-go failed — install with: pkg install payload-dumper-go")
    except Exception as e:
        warn(f"Extraction error: {e}")
    return None


# ── APK installers ────────────────────────────────────────────────────────────

def _install_magisk_apk(serial):
    try:
        req = urllib.request.Request(MAGISK_RELEASES, headers={'User-Agent':'luckyboot'})
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read())
        apk_url, apk_name = None, 'Magisk.apk'
        for asset in data.get('assets',[]):
            if asset['name'].endswith('.apk'):
                apk_url  = asset['browser_download_url']
                apk_name = asset['name']
                break
    except:
        apk_url  = 'https://github.com/topjohnwu/Magisk/releases/latest/download/Magisk.apk'
        apk_name = 'Magisk.apk'
    if apk_url and _download_file(apk_url, apk_name):
        _, _, code = adb_cmd(['install','-r', apk_name], serial=serial)
        if code == 0: ok("Magisk APK installed!")
        else: warn("APK install failed — install manually from device")
    else:
        warn("Could not download Magisk APK")
        info("Download manually: https://github.com/topjohnwu/Magisk/releases")

def _install_ksu_apk(serial):
    try:
        req = urllib.request.Request(KSU_RELEASES, headers={'User-Agent':'luckyboot'})
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read())
        apk_url, apk_name = None, 'KernelSU.apk'
        for asset in data.get('assets',[]):
            if asset['name'].endswith('.apk'):
                apk_url  = asset['browser_download_url']
                apk_name = asset['name']
                break
    except:
        apk_url  = 'https://github.com/tiann/KernelSU/releases/latest/download/KernelSU.apk'
        apk_name = 'KernelSU.apk'
    if apk_url and _download_file(apk_url, apk_name):
        _, _, code = adb_cmd(['install','-r', apk_name], serial=serial)
        if code == 0: ok("KernelSU Manager APK installed!")


# ── Main cmd_root ─────────────────────────────────────────────────────────────

def cmd_root(args):
    """Fully automatic root — detects device, finds boot.img, patches, flashes."""
    section('luckyboot root — Auto Root'); print()

    serial   = getattr(args,'serial',None)
    boot_img = getattr(args,'boot',None)
    force    = getattr(args,'force',False)
    method   = getattr(args,'method',None)  # magisk, kernelsu

    sp = Spinner('Analyzing device...')
    sp.start()
    d = _device_snapshot()
    already_rooted       = _is_rooted()
    has_magisk_installed = _has_magisk() if already_rooted else False
    sp.stop()

    _print_device(d)
    print()

    # Already rooted?
    if already_rooted and not force:
        ok(c(GRN+B, "Device is already rooted!"))
        if has_magisk_installed: info("Root manager: Magisk")
        print()
        info(f"Re-root (force): {c(CYN,'luckyboot root --force')}")
        return

    adb_available = _require_adb(serial)
    bl_unlocked   = _bl_is_unlocked(d)
    sdk   = int(d.get('sdk','0') or '0')
    brand = d.get('brand','').lower()
    kver  = d.get('kernel','')
    k_parts = [p for p in kver.split('.')[:2] if p.isdigit()]
    k_major = int(k_parts[0]) if k_parts else 0
    k_minor = int(k_parts[1]) if len(k_parts)>1 else 0

    print(f"  {c(B+WHT,'── Status ───────────────────────────────────────')}")
    print(f"  ADB connected:     {c(GRN,'yes') if adb_available else c(RED,'no')}")
    print(f"  Bootloader:        {c(GRN,'UNLOCKED') if bl_unlocked else c(RED,'LOCKED') if bl_unlocked==False else c(YLW,'unknown')}")
    print(f"  boot.img provided: {c(GRN, boot_img) if boot_img else c(YLW,'no')}")
    print()

    # ── Case 0: user provided a boot.img → just flash ─────────────────────────
    if boot_img and os.path.exists(os.path.expanduser(boot_img)):
        info("boot.img provided — flashing directly")
        print()
        step(1,1,"Flashing patched boot.img")
        from argparse import Namespace
        flash_args = Namespace(image=boot_img, serial=serial, slot=None,
                               yes=True, no_reboot=False, no_verify=False)
        cmd_flash_boot(flash_args)
        time.sleep(3)
        if _wait_for_adb(serial, 90):
            time.sleep(3)
            if _is_rooted():
                ok(c(GRN+B,"ROOT SUCCESSFUL! 🎉"))
            else:
                warn("Device booted but su not working yet")
                info("Open Magisk/KernelSU app to complete setup")
        return

    # ── Need ADB for everything below ─────────────────────────────────────────
    if not adb_available:
        err("ADB not connected — required for automatic root")
        info("Install ADB:  pkg install android-tools")
        info("Enable USB debugging on device, then connect via USB")
        info(f"Or wirelessly: {c(CYN,'luckyboot adb-wifi')}")
        return

    # ── Case 1: GKI device (Android 12+, kernel 5.10+) → KernelSU ────────────
    is_gki = sdk >= 31 and k_major >= 5 and (k_major > 5 or k_minor >= 10)
    if is_gki and method != 'magisk':
        if _gki_root(d, serial):
            return
        warn("KernelSU auto-root failed — falling back to Magisk method")
        print()

    # ── Case 2: Google Pixel → factory image ──────────────────────────────────
    if 'google' in brand or d.get('device','').lower() in PIXEL_CODENAMES:
        if bl_unlocked and _pixel_root(d, serial):
            return

    # ── Case 3: Bootloader unlocked → dd dump + Magisk ────────────────────────
    if bl_unlocked:
        print(f"  {c(B+WHT,'── Auto-root plan ───────────────────────────────')}")
        info("Bootloader unlocked — will dump boot.img from device")
        print()
        if not _confirm("Start automatic root process?"):
            print(f"\n  {c(DIM,'Cancelled.')}\n"); return
        boot_path = _dd_dump_boot(d, serial)
        if boot_path:
            if _magisk_patch_and_flash(d, serial, boot_path):
                return
        warn("Auto-dump failed")
        print()
        info("Try providing boot.img manually:")
        info(f"  {c(CYN,'luckyboot root --boot /path/to/stock_boot.img')}")
        _guide_get_boot_img(d)
        return

    # ── Case 4: Bootloader locked ─────────────────────────────────────────────
    if bl_unlocked == False:
        print(f"  {c(RED+B,'Bootloader is LOCKED')}")
        print()
        exploitable = sdk <= 27 and (k_major < 4 or (k_major==4 and k_minor<=9))
        if exploitable:
            warn(f"Older kernel {kver} — trying exploit methods first")
            _try_no_unlock_root(d, serial)
        else:
            print(f"  {c(B+WHT,'── Plan ─────────────────────────────────────────')}")
            info("Standard root path:")
            step(1,3,"Unlock bootloader (erases data!)")
            step(2,3,"Auto-detect and patch boot.img")
            step(3,3,"Flash → rooted!")
            print()
            if not _confirm("Start with bootloader unlock?"):
                print(f"\n  {c(DIM,'Cancelled. Run luckyboot bl-unlock manually.')}\n"); return
            _do_bl_unlock(d, serial, brand)
        return

    # ── Case 5: Unknown status ────────────────────────────────────────────────
    warn("Bootloader status unknown")
    _guide_get_boot_img(d)
    info(f"Then: {c(CYN,'luckyboot root --boot stock_boot.img')}")
    print()


# ── Helpers ───────────────────────────────────────────────────────────────────

def _do_bl_unlock(d, serial, brand):
    from .cmd_flash import (
        cmd_bl_unlock as _bl_unlock
    )
    from argparse import Namespace
    ul_args = Namespace(serial=serial, yes=False, brand=brand,
                        no_reboot=False, force=False)
    _bl_unlock(ul_args)

def _try_no_unlock_root(d, serial):
    section('Attempting root without bootloader unlock'); print()
    arch  = d.get('arch','arm64')
    brand = d.get('brand','').lower()
    step(1,3,"Checking for Magisk/KSU already installed")
    if _has_magisk():
        ok("Magisk already installed — device may be rooted")
        return
    step(2,3,"Checking CPU for known exploits")
    cpu = get_prop('ro.hardware') or get_prop('ro.board.platform') or ''
    if 'mt' in cpu.lower() or 'mediatek' in cpu.lower():
        ok(f"MediaTek CPU detected: {cpu}")
        info("MTK-SU exploit may work")
        info(f"Download: {c(CYN,'github.com/diplomatic-dispute/mtk-su')}")
        print()
        info("Commands:")
        print(f"  {c(CYN,'adb push mtk-su /data/local/tmp/')}")
        print(f"  {c(CYN,'adb shell chmod 755 /data/local/tmp/mtk-su')}")
        print(f"  {c(CYN,'adb shell /data/local/tmp/mtk-su')}")
    else:
        info(f"CPU: {cpu or '?'} — no known exploit")
    step(3,3,"Brand-specific methods")
    if 'samsung' in brand:
        info("Samsung: check for Engineering Bootloader on XDA")
        info(f"Search: {c(CYN,'xdaforums.com/search/?q='+d.get('device','?')+'+root+no+unlock')}")
    info(f"XDA: {c(CYN,'xdaforums.com/search/?q='+d.get('device','?')+'+root')}")
    print()
    warn("No guaranteed method found — bootloader unlock is most reliable")
    info(f"Run: {c(CYN,'luckyboot bl-unlock')}")
    print()

def _try_dirtycow(serial, arch):
    if not _require_adb(serial): return
    dirtycow_urls = {
        'arm64': 'https://github.com/nowsecure/android-vts/raw/master/tests/CVE-2016-5195/poc',
        'arm':   'https://github.com/nowsecure/android-vts/raw/master/tests/CVE-2016-5195/poc-arm',
    }
    dl_url = dirtycow_urls.get(arch, dirtycow_urls['arm64'])
    info(f"Downloading exploit binary ({arch})...")
    fname = f'dirtycow-{arch}'
    if _download_file(dl_url, fname):
        ok(f"Downloaded: {fname}")
        adb_cmd(['push', fname, '/data/local/tmp/poc'], serial=serial)
        adb_cmd(['shell', 'chmod', '755', '/data/local/tmp/poc'], serial=serial)
        ok("Exploit pushed")
        out, err_s, code = adb_cmd(['shell', '/data/local/tmp/poc'], serial=serial)
        if code == 0 and ('root' in out.lower() or '#' in out):
            ok(c(GRN+B,"Exploit may have worked!"))
            info(f"Check: {c(CYN,'adb shell id')}")
        else:
            warn(f"Exploit output: {(out+err_s)[:100]}")
    else:
        warn("Could not download exploit binary")

def _guide_get_boot_img(d):
    build = d.get('build','?'); device = d.get('device','?'); brand = d.get('brand','?')
    print(f"  {c(B,'Where to get boot.img for:')} {c(CYN, build)}\n")
    info(f"1. {c(GRN,'firmware.mobi')} — search {c(CYN, build)}")
    info(f"2. {c(GRN,'xdaforums.com')} — search {c(CYN, device+' stock firmware')}")
    info(f"3. {c(GRN,'OTA update zip')} — extract boot.img from full OTA")
    if 'google' in brand.lower() or 'pixel' in brand.lower():
        info(f"4. {c(GRN,'Google factory images')} — developers.google.com/android/images")
    if 'samsung' in brand.lower():
        info(f"4. {c(GRN,'SamFirm / Frija')} — download firmware for your model")
    print()
    info(f"Extract with: {c(CYN,'unzip firmware.zip boot.img')}")
    info(f"Or:           {c(CYN,'payload-dumper-go firmware.zip')}")
