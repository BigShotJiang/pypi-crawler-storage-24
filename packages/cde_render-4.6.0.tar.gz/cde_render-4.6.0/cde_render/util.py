"""
This module contains filters and other helper functions and classes meant to be used from the templates.

These may rely on the 'data' module.

This entire module is made available to the templates as 'UTIL'.
"""

import collections
from collections.abc import Iterable

from .aux_data import CourseAssignment, LodgementAssignment
from .common import RegistrationPartStati
from .data import Course, CourseTrackStati, EventPart, EventTrack, Lodgement, Registration


def get_course_assignments(registration: Registration, tracks: Iterable[EventTrack]) -> list[CourseAssignment]:
    """Get the courses to be printed on the nametag from a list of event tracks and the registration.

    Additionally append an empty course assignment at the end, to properly display orgas who are assigned to a course.

    :param registration: The registration to get its courses
    :param tracks: The list of event tracks to consider (e.g. only the tracks of one EventPart).
        Also require the registration to be present at the relevent part.
    :returns The grouped list of course assignments.
    """
    ret = {}
    for track in tracks:
        if not registration.parts[track.part].status.is_present:
            continue
        course = registration.tracks[track].course
        if course not in ret:
            ret[course] = CourseAssignment(
                registration=registration,
                course=course,
                tracks=[track],
            )
        else:
            ret[course].tracks.append(track)
    if None not in ret:
        ret[None] = CourseAssignment(registration=registration, course=None, tracks=[])
    return list(ret.values())


def get_lodgement_assignments(registration: Registration, parts: Iterable[EventPart]) -> list[LodgementAssignment]:
    """Get the lodgements to be printed on the nametag from a list of event partsand the registration.

    :param registration: The registration to get its courses
    :param parts: The list of event parts to consider. Also require the registration to be present at the relevent part.
    :returns The grouped list of course assignments.
    """
    ret = {}
    for part in parts:
        if not registration.parts[part].status.is_present:
            continue
        lodgement = registration.parts[part].lodgement
        if lodgement not in ret:
            ret[lodgement] = LodgementAssignment(registration=registration, lodgement=lodgement, parts=[part])
        else:
            ret[lodgement].parts.append(part)

    # Unlike for course assignments this does not seem useful.
    # if None not in ret:
    #     ret[None] = LodgementAssignment(registration=registration, lodgement=None, parts=[])
    return list(ret.values())


def gather_course_attendees(course: Course, include_guests: bool) -> list[tuple[Registration, list[EventTrack]]]:
    """Get a single list of all regular attendees (not instructors or guests) of a course (in all active tracks of the
    course)

    :param course: The course to gather its atttendees
    :return: A list of tuples, each representing a unique attendee of the course:
        (Registration: list of EventTracks, in which they attend the course)
    """
    regs = collections.defaultdict(list)
    for event_track, course_track in course.tracks.items():
        for reg, instr in course_track.attendees:
            if not instr and course_track.status == CourseTrackStati.active:
                if not include_guests and reg.parts[event_track.part].status == RegistrationPartStati.guest:
                    continue
                regs[reg].append(event_track)

    return sorted(regs.items())


def get_font_size(size_spec: list[tuple[int, int, int]], s: str) -> tuple[int, int]:
    """
    Helper function to determine the appropriate font size and line height for a string from a given spec.

    Select the first entry where the given string is shorter than the max length or the max length is -1.

    :param size_spec: An ordered list of string lengths and font and line height for strings of that length.
    """
    for max_len, font_size, line_height in size_spec:
        if len(s) <= max_len or max_len == -1:
            return font_size, line_height
    return 0, 0


def _override_filter(value: str | None, entity: Course | Lodgement | Registration, override_field: str) -> str | None:
    if value is None:
        return None
    replacement_value = entity.fields.get(override_field)
    if replacement_value is not None:
        return str(replacement_value)
    return value


# The functions below are copied almost verbatim from the CdEDB.


def _small_int_to_words(num: int) -> str:
    """Convert a small integer into a written representation.

    Helper for the general function.
    """
    if num < 0 or num > 999:
        raise ValueError("Out of supported scope.")
    digits = tuple((num // 10**i) % 10 for i in range(3))
    atoms = ("null", "ein", "zwei", "drei", "vier", "fünf", "sechs",
                "sieben", "acht", "neun", "zehn", "elf", "zwölf", "dreizehn",
                "vierzehn", "fünfzehn", "sechzehn", "siebzehn", "achtzehn",
                "neunzehn")  # fmt: skip
    tens = ("", "", "zwanzig", "dreißig", "vierzig", "fünfzig", "sechzig",
            "siebzig", "achtzig", "neunzig")  # fmt: skip
    ret = ""
    if digits[2]:
        ret += atoms[digits[2]] + "hundert"
    if num % 100 < 20:
        if num % 100:
            ret += atoms[num % 100]
        return ret
    if digits[0]:
        ret += atoms[digits[0]]
    if digits[0] and digits[1]:
        ret += "und"
    if digits[1]:
        ret += tens[digits[1]]
    return ret


def _int_to_words_filter(num: int) -> str:
    """Convert an integer into a written representation.

    This is for the usage such as '2 apples' -> 'two apples'.
    """
    if num < 0 or num > 999999:
        raise ValueError("Out of supported scope.")
    if num == 0:
        return "null"
    multipliers = ("", "tausend")
    number_words = []
    tmp = num
    while tmp > 0:
        number_words.append(_small_int_to_words(tmp % 1000))
        tmp = tmp // 1000
    ret = ""
    for number_word, multiplier in reversed(tuple(zip(number_words, multipliers))):
        if number_word != "null":
            ret += number_word + multiplier
    return ret
