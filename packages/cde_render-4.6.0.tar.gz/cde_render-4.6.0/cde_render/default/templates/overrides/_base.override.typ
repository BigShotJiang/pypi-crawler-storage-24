<<# This is a common override hook template for all documents except for the participation letter / Teilnahmebrief.

    It extends the common base template (`_base.typ`) and is used as a base for all other templates.

    To customize common typst code from the _base.typ template, you may create a `_base.override.typ` in your custom
    template directory, which replaces this empty template. In your custom `_base.override.typ`, you can then redefine
    individual Jinja blocks from the _base.typ template.

    Note that the individual templates also will override varying blocks from the _base.typ template. Thus, it may be
    necessary to create override-Templates for some or all of the target templates for your custom override.
#>>
<<% extends "_base.typ" %>>
