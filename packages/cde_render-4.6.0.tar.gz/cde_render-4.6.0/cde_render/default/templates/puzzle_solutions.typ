#table(
    columns: 2,
    align: (center, left),
    <<% for puzzle in all_puzzles %>>
        image(
            "<<< find_asset(puzzle.get_asset_name()) >>>",
            width: 2cm, height: 2cm,
        ),
        [
            <<< puzzle.description >>>

            <<% if CONFIG.nametags.puzzles.show_frequency %>>
                (Gesamt: <<< puzzle_stats.frequency[puzzle]|string ->>>
                <<% if puzzle_stats.frequency_by_part|length > 1 %>>,
                    <<% for ep, counter in puzzle_stats.frequency_by_part.items() %>>
                        <<< ep.shortname >>>: <<< counter[puzzle]|string + (", " if not loop.last else "") >>>
                    <<% endfor %>>
                <<%- endif %>>)
            <<% endif -%>>
        ],
    <<% endfor %>>
)

<<% if CONFIG.nametags.puzzles.show_distribution %>>
    Häufigkeit der Symbolanzahl:

    <<% if puzzle_stats.distribution_by_part|length > 1 %>>
    <<% for part, distribution in puzzle_stats.distribution_by_part.items() %>>
    - <<< part.shortname >>>:
        <<% for num, count in distribution.items()|sort %>>
        - <<< num >>>: <<< count >>>
        <<% endfor %>>
    <<% endfor %>>
    <<% endif %>>

    <<% if puzzle_stats.distribution -%>>
    <<% for num, count in puzzle_stats.distribution.items()|sort %>>
    - <<< num >>>: <<< count >>>
    <<% endfor %>>
    <<% endif %>>
<<%- endif %>>
