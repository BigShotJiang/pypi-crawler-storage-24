<<% extends "_base.override.typ" %>>

<<% block preamble %>>
    #set text(size: 12pt)
    #set par(leading: 1em)  // line spacing
    #set page(
        margin: (
            x: 0pt,
            y: 21.5mm,
        ),
    )

    #let nametag_margins = 6mm

    // Add faint lines to the grid and the boxes inside in debug mode.
    <<% if CONFIG.layout.typst_debug %>>
        #let mystroke = (thickness: .2pt, paint: blue)
    <<% else %>>
        #let mystroke = (thickness: 0pt)
    <<% endif %>>
    #set table(stroke: mystroke)
    #set grid(stroke: mystroke)
    #show table: set box(stroke: mystroke)
    #show grid: set box(stroke: mystroke)

    // Setup pagination in header and footer.
    #let pagination(marker) = context [
        #h(5mm)
        _#marker _
        #h(1fr)
        Seiten #counter(page).display("1 / 1", both: true)
        #h(1fr)
        _#marker _
        #h(5mm)
    ]
<<% endblock %>>

<<% block content %>>
    <<% for list in participants|batch(10) %>>
        #let marker = [<<< list[0].registration.name.nametag_forename.split()[0] >>> -- <<< list[-1].registration.name.nametag_forename.split()[0] >>>]
        #page(header: pagination(marker), footer: pagination(marker))[
            #grid(
                columns: 2,
                inset: nametag_margins,  // margins inside the grid cells.
                <<% for departing_participant in list %>>
                [
                    #box(
                        // nametag size minus margins.
                        width: 105mm - 2 * nametag_margins,
                        height: 50.8mm - 2 * nametag_margins,
                    )[
                        <<% block nametag_name scoped %>>
                            <<% set forename = departing_participant.registration.name.nametag_forename|override(departing_participant.registration, CONFIG.data.overrides.nametag_forename) %>>
                            <<% set pronouns = departing_participant.registration.name.nametag_pronouns|override(departing_participant.registration, CONFIG.data.overrides.nametag_pronouns) %>>
                            #fit(93mm)[
                                #set text(size: <<< CONFIG.nametags.forename_fontsizes[0][1] >>>pt)
                                *<<< forename >>>*
                                <<% if pronouns %>>
                            ][
                                #set text(size: <<< CONFIG.nametags.pronouns_fontsizes[0][1] >>>pt)
                                (<<< pronouns >>>)
                                <<% endif %>>
                            ] \
                            // Surname
                            <<% set surname = departing_participant.registration.name.nametag_surname|override(departing_participant.registration, CONFIG.data.overrides.nametag_surname) %>>
                            #fit(93mm)[
                                #set text(size: <<< CONFIG.nametags.surname_fontsizes[0][1] >>>pt)
                                *<<< surname >>>*
                            ]
                        <<% endblock %>>
                        #align(bottom)[
                            #set text(size: 18pt)
                            <<% block departure_info scoped %>>
                                <<% if departing_participant.is_car %>>
                                    Auto
                                    <<% if not departing_participant.time_is_missing %>>
                                        <<% if departing_participant.time.date() != part.end %>>am <<< departing_participant.time|datetime('%d.%m.') >>><<% endif %>>
                                        um <<< departing_participant.time|datetime('%H:%M') >>> Uhr
                                    <<% endif %>>
                                <<% elif departing_participant.is_present_next %>>
                                    Ich bleibe.
                                <<% else %>>
                                    <<% if config.bus_field %>>
                                        <<% set bus_name = departing_participant.bus %>>
                                        <<% if config.bus_descriptions %>>
                                            <<% set bus_name = config.bus_descriptions.get(bus_name, bus_name) %>>
                                        <<% endif %>>
                                        <<< bus_name >>>
                                    <<% endif %>>
                                <<% endif %>>
                            <<% endblock %>>
                        ]
                    ]
                    <table-cell-<<< loop.index >>>>
                ],
                <<% endfor %>>
            )
        ]
    <<% endfor %>>
<<% endblock %>>
