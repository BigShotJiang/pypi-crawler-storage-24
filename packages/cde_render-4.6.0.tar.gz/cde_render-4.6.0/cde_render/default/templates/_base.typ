#set page(
    paper: "a4",
    margin: (
        x: 1.5cm,
        y: 2cm,
    ),
)

#let design_color = rgb("#<<< CONFIG.layout.design_color >>>")
#let link_color = rgb("#<<< CONFIG.layout.link_color >>>")
#let row_color = rgb("#<<< CONFIG.layout.row_color >>>")

#show link: text.with(fill: link_color)

#set document(
    title: "<<< title >>>",
    author: "<<< CONFIG.meta.pdf_author >>>",
)

#set text(
    font: (
        <<% for font in CONFIG.layout.typst_fonts %>>
            "<<< font >>>",
        <<% endfor %>>
        "Libertinus Serif",
    ),
)


/*
  Helper to scale a list of contents down to fit the given width.

  The elements are spaced equally with additional spacing given (default 1mm).
  Everything is sized down using binary search until it comes within eps of perfect fit.
*/
#let fit(max, spacing: 1mm, eps: 1mm, ..it) = context {
  let filtered = it.pos().filter(x => measure(x).width > 0mm)
  let resized = filtered.map(box)
  let separator = h(1fr) + h(spacing)
  let result = resized.join(separator)
  if measure(result).width < max {
    return result
  }
  let (a, b) = (0%, 100%)
  while (b - a) * max > eps or measure(result).width > max {
    let pivot = (a + b) / 2
    for (i, x) in filtered.enumerate() {
      resized.at(i) = box(scale(pivot, x, reflow: true))
    }
    result = resized.join(separator)
    if measure(result).width < max {
      a = pivot
    } else {
      b = pivot
    }
    // Debug output.
    //[#a #pivot #b #(max - measure(result).width).mm()\ ]
  }
  result
}


<<% block preamble %>>
<<% endblock %>>

<<% block content %>>
<<% endblock %>>
