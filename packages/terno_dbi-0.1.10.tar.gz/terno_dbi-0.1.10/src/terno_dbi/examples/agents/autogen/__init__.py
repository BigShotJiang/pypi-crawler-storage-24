"""
AutoGen examples for TernoDBI.
"""
