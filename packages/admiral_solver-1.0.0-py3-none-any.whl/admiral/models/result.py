from __future__ import annotations
import dataclasses
from typing import Any

@dataclasses.dataclass
class TimingInfo:
    total_ms: float = 0; presolve_ms: float = 0; solver_ms: float = 0; postprocess_ms: float = 0

@dataclasses.dataclass
class SolveResult:
    solution: list[int] | dict[str, Any] | None = None
    energy: float = float("inf"); feasible: bool = True
    timing: TimingInfo = dataclasses.field(default_factory=TimingInfo)
    solver_used: str = ""; num_reads: int = 0
    convergence: list[float] = dataclasses.field(default_factory=list)
    solution_pool: list[dict] = dataclasses.field(default_factory=list)
    metadata: dict[str, Any] = dataclasses.field(default_factory=dict)
    def to_dict(self) -> dict: return dataclasses.asdict(self)

@dataclasses.dataclass
class ComplexityAnalysis:
    num_variables: int = 0; num_constraints: int = 0; num_interactions: int = 0
    density: float = 0.0; estimated_time_s: float = 0.0; complexity_class: str = "UNKNOWN"
    recommended_solvers: list[tuple[str, float]] = dataclasses.field(default_factory=list)
    treewidth_bound: int | None = None; is_decomposable: bool = False; components: int = 1
