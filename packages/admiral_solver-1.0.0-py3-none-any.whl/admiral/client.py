"""Admiral SDK — HTTP client that talks to the Admiral API. No local solvers."""
from __future__ import annotations
import time, os
from typing import Any, Callable
import numpy as np
import httpx
from admiral.models.result import SolveResult, TimingInfo

class Solver:
    """Cloud solver — sends problems to api.admiral.dev and returns results."""

    def __init__(self, api_key=None, base_url=None, timeout=300):
        self.api_key = api_key or os.getenv("ADMIRAL_API_KEY", "")
        self.base_url = (base_url or os.getenv("ADMIRAL_API_URL", "https://api.admiral-platform.tech")).rstrip("/")
        self._c = httpx.Client(base_url=self.base_url, timeout=timeout,
            headers={"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"})

    def solve_qubo(self, Q, timeout=30, num_reads=100, solver="auto", return_pool=False, seed=None, on_progress=None):
        """Solve a QUBO: min x^T Q x."""
        if isinstance(Q, np.ndarray): Q = Q.tolist()
        return self._submit("qubo", {"Q": Q}, timeout, num_reads, solver, return_pool, seed, on_progress)

    def solve_ising(self, h, J, timeout=30, **kw):
        """Solve Ising: min Σhᵢsᵢ + ΣJᵢⱼsᵢsⱼ."""
        if isinstance(h, np.ndarray): h = h.tolist()
        if isinstance(J, np.ndarray): J = J.tolist()
        return self._submit("ising", {"h": h, "J": J}, timeout, **kw)

    def solve(self, problem, timeout=30, **kw):
        """Auto-detect and solve any model type."""
        if isinstance(problem, np.ndarray): return self.solve_qubo(problem, timeout=timeout, **kw)
        if hasattr(problem, "problem_type") and hasattr(problem, "to_dict"):
            pt = problem.problem_type.value if hasattr(problem.problem_type, "value") else str(problem.problem_type)
            return self._submit(pt, problem.to_dict(), timeout, **kw)
        raise ValueError("Cannot detect type. Use solve_qubo(), solve_ising(), or pass a model object.")

    def analyze(self, problem):
        """Pre-solve complexity analysis."""
        if isinstance(problem, np.ndarray): d = {"problem_type": "qubo", "data": {"Q": problem.tolist()}}
        elif hasattr(problem, "problem_type"): d = {"problem_type": problem.problem_type.value, "data": problem.to_dict()}
        else: d = problem
        return self._c.post("/v1/analyze", json=d).json()

    def convert(self, from_type, to_type, data):
        """Convert between formats (QUBO↔Ising, etc.)."""
        r = self._c.post("/v1/convert", json={"from_type": from_type, "to_type": to_type, "data": data})
        r.raise_for_status(); return r.json()

    def usage(self):
        """Get current usage and quota."""
        return self._c.get("/v1/usage").json()

    def solvers(self):
        """List available solver engines."""
        return self._c.get("/v1/solvers").json()

    def _submit(self, ptype, data, timeout=30, num_reads=100, solver="auto", return_pool=False, seed=None, on_progress=None):
        cfg = {"timeout": timeout, "solver": solver, "num_reads": num_reads, "return_pool": return_pool, "presolve": True}
        if seed is not None: cfg["seed"] = seed
        r = self._c.post("/v1/solve", json={"problem_type": ptype, "data": data, "config": cfg})
        r.raise_for_status()
        jid = r.json()["job_id"]
        poll, t0 = 0.25, time.monotonic()
        while time.monotonic() - t0 < timeout + 60:
            s = self._c.get(f"/v1/jobs/{jid}").json()
            if s["status"] == "completed":
                r = s.get("result", {})
                return SolveResult(
                    solution=r.get("solution"), energy=r.get("energy", float("inf")),
                    feasible=r.get("feasible", True), timing=TimingInfo(**r.get("timing", {})),
                    solver_used=r.get("solver_used", ""), num_reads=r.get("num_reads", 0),
                    convergence=r.get("convergence", []), solution_pool=r.get("solution_pool", []),
                    metadata=r.get("metadata", {}))
            if s["status"] == "failed":
                raise RuntimeError(f"Job {jid} failed: {s.get('error', 'unknown error')}")
            if on_progress and s["status"] == "running":
                on_progress({"job_id": jid, "status": "running"})
            time.sleep(poll)
            poll = min(poll * 1.5, 5.0)
        raise TimeoutError(f"Job {jid} did not complete within {timeout + 60}s")

    def close(self): self._c.close()
    def __enter__(self): return self
    def __exit__(self, *a): self.close()
