import json
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace

import pytest
from typer.testing import CliRunner

from kage import db
from kage.config import CommandDef, GlobalConfig, ProviderConfig
from kage.main import app
from kage.parser import TaskDef
from kage.runs import get_run

runner = CliRunner()


@pytest.fixture
def cli_env(tmp_path: Path, mocker):
    db_path = tmp_path / "kage.db"
    logs_dir = tmp_path / "logs"
    mocker.patch("kage.db.KAGE_DB_PATH", db_path)
    mocker.patch("kage.config.KAGE_DB_PATH", db_path)
    mocker.patch("kage.runs.KAGE_DB_PATH", db_path)
    mocker.patch("kage.config.KAGE_LOGS_DIR", logs_dir)
    mocker.patch("kage.runs.KAGE_LOGS_DIR", logs_dir)
    db.init_db()
    return {"db_path": db_path, "logs_dir": logs_dir}


def _append_event(path: Path, stream: str, text: str):
    payload = {
        "ts": datetime.now().astimezone().isoformat(),
        "stream": stream,
        "text": text,
    }
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, ensure_ascii=False) + "\n")


def test_runs_cli_lists_tsv(cli_env):
    exec_id = db.start_execution("/tmp/demo", "Nightly Research")
    db.update_execution(
        exec_id,
        "SUCCESS",
        "visible output\n",
        "",
        exit_code=0,
        output_summary="visible output",
    )

    result = runner.invoke(app, ["runs"])

    assert result.exit_code == 0
    assert "Nightly Research" in result.stdout
    assert exec_id[:8] in result.stdout
    assert "\tSUCCESS\t" in result.stdout


def test_logs_cli_reads_raw_stdout_without_cleaning(cli_env):
    exec_id = db.start_execution("/tmp/demo", "Nightly Research")
    run = get_run(exec_id)
    assert run is not None

    stdout_path = Path(run.stdout_path)
    events_path = Path(run.events_path)
    stdout_path.write_text("<thinking>secret</thinking>\nvisible\n", encoding="utf-8")
    _append_event(events_path, "stdout", "<thinking>secret</thinking>\nvisible\n")

    db.update_execution(
        exec_id,
        "SUCCESS",
        "visible\n",
        "",
        exit_code=0,
        output_summary="visible",
        stdout_bytes=len(stdout_path.read_bytes()),
    )

    result = runner.invoke(app, ["logs", "Nightly Research", "--stream", "stdout"])

    assert result.exit_code == 0
    assert "<thinking>secret</thinking>" in result.stdout
    assert "visible" in result.stdout


def test_logs_cli_requires_project_for_duplicate_task_names(cli_env):
    first = db.start_execution("/tmp/project-a", "Shared Task")
    db.update_execution(first, "SUCCESS", "a\n", "", output_summary="a")

    second = db.start_execution("/tmp/project-b", "Shared Task")
    db.update_execution(second, "SUCCESS", "b\n", "", output_summary="b")

    result = runner.invoke(app, ["logs", "Shared Task"])

    assert result.exit_code == 1
    assert "Use --project" in result.stdout


def test_runs_cli_filters_connector_poll_source(cli_env):
    connector_run = db.start_execution(
        "/tmp/demo", "connector:test_discord", execution_kind="connector_poll"
    )
    db.update_execution(
        connector_run,
        "SUCCESS",
        "reply\n",
        "",
        output_summary="reply",
    )

    task_run = db.start_execution(
        "/tmp/demo", "Nightly Research", execution_kind="prompt"
    )
    db.update_execution(task_run, "SUCCESS", "done\n", "", output_summary="done")

    result = runner.invoke(app, ["runs", "--source", "connector_poll"])

    assert result.exit_code == 0
    assert "connector:test_discord" in result.stdout
    assert "Nightly Research" not in result.stdout


def test_top_level_run_requires_task_name():
    result = runner.invoke(app, ["run"])

    assert result.exit_code == 2


def test_cron_run_executes_scheduler(mocker):
    run_all = mocker.patch("kage.scheduler.run_all_scheduled_tasks")

    result = runner.invoke(app, ["cron", "run"])

    assert result.exit_code == 0
    run_all.assert_called_once_with()


def test_task_list_shows_compiled_statuses(mocker, tmp_path: Path):
    project_dir = tmp_path / "proj"
    task_file = project_dir / ".kage" / "tasks" / "nightly.md"
    shell_file = project_dir / ".kage" / "tasks" / "shell.md"
    task_file.parent.mkdir(parents=True)

    prompt_task = TaskDef(name="Nightly", cron="* * * * *", prompt="hello")
    shell_task = TaskDef(name="Shell", cron="* * * * *", command="echo hi")

    mocker.patch("kage.scheduler.get_projects", return_value=[project_dir])
    mocker.patch(
        "kage.parser.load_project_tasks",
        return_value=[
            (task_file, SimpleNamespace(task=prompt_task)),
            (shell_file, SimpleNamespace(task=shell_task)),
        ],
    )
    mocker.patch(
        "kage.compiler.compiled_task_indicator",
        side_effect=[
            {"state": "stale", "label": "stale"},
            {"state": "n/a", "label": "-"},
        ],
    )

    result = runner.invoke(app, ["task", "list"])

    assert result.exit_code == 0
    assert "STALE" in result.stdout
    assert "Nightly" in result.stdout
    assert "Shell" in result.stdout


def test_doctor_reports_stale_compiled_locks(mocker, tmp_path: Path):
    global_dir = tmp_path / ".kage"
    config_path = global_dir / "config.toml"
    projects_list = global_dir / "projects.list"
    db_path = global_dir / "kage.db"
    logs_dir = global_dir / "logs"
    state_path = global_dir / "migrations" / "install_state.json"
    project_dir = tmp_path / "proj"
    task_file = project_dir / ".kage" / "tasks" / "nightly.md"

    global_dir.mkdir(parents=True)
    logs_dir.mkdir(parents=True)
    config_path.write_text("", encoding="utf-8")
    projects_list.write_text(str(project_dir) + "\n", encoding="utf-8")
    db_path.write_text("", encoding="utf-8")
    task_file.parent.mkdir(parents=True)
    task_file.write_text(
        """---
name: Nightly
cron: "* * * * *"
provider: codex
---

hello
""",
        encoding="utf-8",
    )

    cfg = GlobalConfig(
        default_ai_engine="codex",
        commands={"codex": CommandDef(template=["codex", "exec", "{prompt}"])},
        providers={"codex": ProviderConfig(command="codex")},
    )

    mocker.patch("kage.config.KAGE_GLOBAL_DIR", global_dir)
    mocker.patch("kage.config.KAGE_CONFIG_PATH", config_path)
    mocker.patch("kage.config.KAGE_PROJECTS_LIST", projects_list)
    mocker.patch("kage.config.KAGE_DB_PATH", db_path)
    mocker.patch("kage.config.KAGE_LOGS_DIR", logs_dir)
    mocker.patch(
        "kage.config.get_global_config",
        side_effect=lambda workspace_dir=None: cfg,
    )
    mocker.patch("kage.scheduler.get_projects", return_value=[project_dir])
    mocker.patch(
        "kage.migrations.runner.get_install_migration_state_path",
        return_value=state_path,
    )
    mocker.patch("kage.migrations.runner.discover_install_migrations", return_value=[])
    mocker.patch(
        "kage.compiler.compiled_task_indicator",
        return_value={
            "state": "stale",
            "label": "stale",
            "path": str(task_file.with_suffix(".lock.sh")),
            "exists": True,
            "is_fresh": False,
            "needs_compile": True,
        },
    )

    result = runner.invoke(app, ["doctor"])

    assert result.exit_code == 0
    assert "compiled locks" in result.stdout
    assert "Nightly@proj" in result.stdout
