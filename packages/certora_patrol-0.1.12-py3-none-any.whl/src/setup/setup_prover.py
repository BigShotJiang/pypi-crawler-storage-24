"""
Setup Prover Module - Handles all setup-related operations for the Certora PreAudit Orchestrator.

This module contains all the setup phase functionality including:
- Setup summaries generation
- Compilation analysis
- ERC-7201 detection
- Generator execution (Generic rules, External call checker, Privileged operations)
- Summary compilation testing
"""

import json
import re
import shutil
import subprocess
import sys
import traceback
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Optional, Tuple, Union

from src.parsers.orchestrator_argparse import parse_contract_files
from src.setup.auto_munges import detect_and_apply_code_access_patches
from src.setup.signature_manager import SignatureManager
from src.setup.signature_types import ContractInfo
from src.setup.solidity_utils import extract_definitions_from_solidity
from src.utils.solc_version_resolver import resolve_pragma_to_version, extract_pragma_spec
from src.utils.types import ContractHandle, ContractKind, TypeParseMode, parse_type_descriptor

class CompilationAnalysisError(Exception):
    """Raised when compilation analysis fails."""


class SummarySetupError(Exception):
    """Raised when setup summaries generation fails."""


# Add the script directory to path for imports
scripts_dir_path = Path(__file__).parent.resolve()
sys.path.insert(0, str(scripts_dir_path))

# Import TypecheckerLoop for template processing
from src.typechecker_loop import TypecheckerLoop


@dataclass
class CompilationWorkaround:
    """Represents a compilation workaround with detection and application logic.

    A workaround consists of three components:
    1. Detection function: Analyzes compilation output to identify if this workaround applies
    2. Application function: Modifies configuration to apply the workaround
    3. Enabled flag: Controls whether this workaround is active

    Attributes:
        name: Human-readable name for the workaround (e.g., "compiler_version_mismatch")

        detect_fn: Detection function that analyzes compilation output.
            Args:
                output (str): Combined stdout+stderr from certoraRun compilation
            Returns:
                Any: Detection result if workaround applies, None/False otherwise.
                Importantly, this result is passed as the argument `detect_result` to the apply_fn.
                Return type varies by workaround:
                    - str: Contract name for contract-specific workarounds (e.g., stack-too-deep)
                    - Tuple[str, str]: (contract_name, extra_info) for workarounds needing additional data (e.g., compiler version)
                    - str (non-None): Marker value like "detected" for global workarounds
                    - bool: True if detected (when combined with conditional checks in lambda)
                    - None/False: Workaround does not apply

        apply_fn: Application function that modifies configuration to apply the workaround.
            Args:
                detect_result (Any): The value returned by detect_fn
                updated_config_dict (Dict): Tracker for config updates across retries
                compilation_config (Dict): Full compilation config to be updated
                config_file (Path): Path to config file to rewrite
                contracts (List[ContractHandle]): List of all contracts being compiled
            Returns:
                Dict: Updated config dictionary (typically updated_config_dict)

        enabled: Whether this workaround is currently active.
            Typically disabled if:
            - User has explicitly configured a setting that makes the workaround unnecessary
            - Another workaround has already handled the same issue

    Examples:
        # Via-IR workaround for stack-too-deep errors
        CompilationWorkaround(
            name="stack_too_deep_via_ir",
            detect_fn=lambda output: self._detect_stack_too_deep_errors(output, contracts),
            apply_fn=self._apply_via_ir_workaround_to_config,
            enabled=not global_via_ir_enabled,
        )

        # Compiler version workaround
        CompilationWorkaround(
            name="compiler_version_mismatch",
            detect_fn=lambda output: self._detect_compiler_version_mismatch(output, contracts),
            apply_fn=self._apply_compiler_version_workaround_to_config,
            enabled=not solc_already_set,
        )
    """

    name: str
    detect_fn: Callable[[str], Any]
    apply_fn: Callable[
        [Any, Dict, Dict, Path, List[ContractHandle]], Dict
    ]
    enabled: bool


class SetupProver:
    """Class to handle setup operations for Certora Prover."""

    def __init__(
        self,
        log,
        certora_dir,
        script_dir,
        additional_contracts,
        extra_args,
        skip_llm,
        force_llm_regenerate,
        stop_after_summaries,
        scope,
        verbose=0,
        certora_run_command="certoraRun",
        contract_names=None,
        get_build_system_config_dict=None,
        solc_default_version="solc8.33",
    ):
        """Initialize SetupProver with required dependencies."""
        self.log = log
        self.certora_dir = certora_dir
        self.script_dir = script_dir
        self.additional_contracts = additional_contracts
        self.extra_args = extra_args
        self.skip_llm = skip_llm
        self.force_llm_regenerate = force_llm_regenerate
        self.stop_after_summaries = stop_after_summaries
        self.verbose = verbose
        self.certora_run_command = certora_run_command
        self.contract_names = contract_names or []
        self.get_build_system_config_dict = get_build_system_config_dict or (lambda: {})
        self.solc_default_version = solc_default_version
        self.scope = scope

        # Track compilation configuration updates
        self.compilation_config_updates: Dict[str, Any] = {}
        self.import_patcher_applied: bool = False
        self._remappings_workaround_applied: bool = False
        self._build_dir: Path | None = None

    def find_all_summaries_spec_files(
        self, contract_names: List[str]
    ) -> Dict[Path, str]:
        """
        Find all summaries spec files in the certora directory.

        This includes:
        - The main summaries.spec
        - Any versioned summaries specs (e.g., summaries-ROUND1-abc123.spec)
        - Any versioned summaries specs with contract names (e.g., summaries-MyContract.spec)

        Returns:
            Map of Path objects for all summaries spec files found to their contract name, for the provided contract_names
        """
        summaries_specs = {}

        # Look for all files matching summaries*.spec pattern
        for contract_name in contract_names:
            for spec_file in self.certora_dir.glob(f"summaries-{contract_name}.spec"):
                summaries_specs[spec_file] = contract_name

        if summaries_specs:
            ## Sort by modification time (newest first) # todo fix dict sorting
            # summaries_specs.sort(key=lambda p: p.stat().st_mtime, reverse=True)
            self.log(
                f"Found {len(summaries_specs)} summaries spec file(s): {[s.name for s in summaries_specs]}"
            )
        else:
            self.log("Warning: No summaries spec files found", "WARNING")

        return summaries_specs

    def run_setup_erc7201(self) -> bool:
        """Run setup_erc7201.py to detect and configure ERC-7201 storage patterns."""
        self.log("🔍 Running ERC-7201 storage pattern detection...")

        try:
            # Import and call the run function directly
            from setup.setup_erc7201 import run # type: ignore[import-not-found]

            # Get verbose setting from orchestrator if available
            verbose = getattr(self, "verbose", False)

            result = run(
                directory=".",
                spec_output="certora/erc7201.spec",
                verbose=verbose,
                no_config_update=False,
                summary_only=False,
            )

            if result == 0:
                self.log("✅ ERC-7201 detection completed successfully")
                return True
            else:
                self.log("⚠️ ERC-7201 detection completed with warnings", "WARNING")
                return True  # Don't fail the orchestration

        except Exception as e:
            self.log(f"❌ Error running ERC-7201 detection: {e}", "WARNING")
            return True  # Don't fail the orchestration

    def _extract_contract_names(self, build_data: Dict) -> List[str]:
        """
        Extract unique contract names from a .certora_build.json file.

        Args:
            build_data: Build data dictionary from .certora_build.json file

        Returns:
            List of unique contract names found in the build data

        Raises:
            RuntimeError: If build_data is None or not a dictionary
        """
        # Validate input
        if build_data is None:
            raise RuntimeError("build_data cannot be None")
        if not isinstance(build_data, dict):
            raise RuntimeError(f"build_data must be a dictionary, got {type(build_data).__name__}")

        unique_contract_names = set()

        # Iterate through all top-level entries
        for entry_key, entry_value in build_data.items():
            # Check if this entry has a 'contracts' list
            if isinstance(entry_value, dict) and "contracts" in entry_value:
                contracts_list = entry_value["contracts"]

                # Extract contract names from the contracts list
                if isinstance(contracts_list, list):
                    for contract in contracts_list:
                        if isinstance(contract, dict) and "name" in contract:
                            unique_contract_names.add(contract["name"])

        # Return sorted list for consistent ordering
        return sorted(list(unique_contract_names))

    def run_compilation_analysis(
        self, contracts: List[ContractHandle], main_contract: str
    ) -> Tuple[bool, Dict[str, Any], bool]:
        """Run compilation-only step to extract method information from contracts.

        Returns:
            Tuple[bool, Dict[str, Any], bool]: (success, updated_config_dict, import_patcher_applied)
            - success: True if compilation succeeded
            - updated_config_dict: Configuration dictionary with all updates applied during compilation
            - import_patcher_applied: True if import patcher was successfully applied
        """
        self.log("=== COMPILATION ANALYSIS PHASE ===")
        self.log("Running compilation analysis to extract method information...")

        # Track configuration updates and import patcher application
        import_patcher_applied = False
        updated_config_dict = self.get_build_system_config_dict().copy()

        try:
            # Always create a dummy spec for compilation to avoid path issues
            dummy_spec_path = Path("certora") / "compilation_dummy.spec"
            dummy_spec_path.parent.mkdir(parents=True, exist_ok=True)
            with open(dummy_spec_path, "w") as f:
                f.write("")  # Empty spec file
            spec_to_use = "certora/compilation_dummy.spec"

            # Create a minimal config file for compilation
            config_file = self.certora_dir / "compilation_config.conf"
            contract_strings = [c.to_config_str() for c in contracts]
            all_files_raw = contract_strings + self.additional_contracts

            # Deduplicate files by contract name (keep shortest path)
            all_files = self._deduplicate_contract_files(all_files_raw)

            compilation_config = {
                "files": all_files,
                "verify": f"{main_contract}:{spec_to_use}",
                "msg": f"Compilation analysis for {main_contract}",
                "assert_autofinder_success": True
            }

            # Merge build system configuration (Foundry, Hardhat, etc.)
            if updated_config_dict:
                compilation_config.update(updated_config_dict)
                self.log("Merged build system config into compilation config")

            with open(config_file, "w") as f:
                json.dump(compilation_config, f, indent=2)

            # Build command using config file - similar to warmup
            cmd = [self.certora_run_command, str(config_file)]

            # Add --compilation_steps_only flag
            cmd.append("--compilation_steps_only")

            # Add --dump-asts flag to generate AST files
            cmd.append("--dump_asts")

            # Add custom message if not already in extra_args
            has_msg = any(arg == "--msg" for arg in self.extra_args)
            if not has_msg:
                msg = f'"{main_contract} compilation analysis"'
                cmd.extend(["--msg", msg])

            # Add ALL extra arguments - this ensures --solc-via-ir and other compilation flags are included
            cmd.extend(self.extra_args)

            # Run the compilation command with workarounds
            self.log("Running: Compilation analysis")
            self.log(f"Full command: {' '.join(cmd)}")

            success, output, updated_config_dict = self._run_compilation_with_workarounds(
                cmd, config_file, compilation_config, contracts, updated_config_dict
            )

            if not success:
                self.log("Compilation analysis failed - attempting import patch fix", "WARNING")
                # Log the failure output from first attempt
                self.log("Output from first compilation attempt:", "WARNING")
                self.log(output, "WARNING")

                # Try to apply import patch and retry
                if self._run_import_patch():
                    self.log("Import patch applied successfully, retrying compilation...")
                    import_patcher_applied = True
                    success, output, updated_config_dict = self._run_compilation_with_workarounds(
                        cmd, config_file, compilation_config, contracts, updated_config_dict
                    )

                    if not success:
                        self.log("Compilation analysis failed even after import patch", "ERROR")
                        self.log("Output from second compilation attempt (after import patch):", "ERROR")
                        self.log(output, "ERROR")
                        self.log("Reverting import patch as it was not useful...", "WARNING")
                        self._revert_import_patch()
                        import_patcher_applied = False
                        self.log("Cannot proceed without successful compilation. Exiting.", "ERROR")
                        sys.exit(1)
                else:
                    self.log("Import patch failed", "ERROR")
                    self.log("Cannot proceed without successful compilation. Exiting.", "ERROR")
                    sys.exit(1)

            self.log("✓ Compilation analysis completed successfully")

            # Post-process the .certora_build.json file
            if not self.process_certora_build_json():
                self.log("Warning: Failed to process .certora_build.json", "WARNING")
                return False, updated_config_dict, import_patcher_applied

            return True, updated_config_dict, import_patcher_applied

        except Exception as e:
            self.log(f"✗ Compilation analysis failed with exception: {e}", "ERROR")
            return False, updated_config_dict, import_patcher_applied

    def _run_import_patch(self, project_dir: str = ".") -> bool:
        """Create and apply import patches to convert relative imports to absolute imports.

        Args:
            project_dir: Project directory to process (default: current directory)

        Returns:
            True if successful, False otherwise
        """
        import_patch_script = self.script_dir / "setup" / "solidity_import_patch.py"

        if not import_patch_script.exists():
            self.log(f"Import patch script not found: {import_patch_script}", "ERROR")
            return False

        try:
            # Step 1: Create patch
            self.log("Creating import patch...")
            result = subprocess.run(
                [
                    "python3",
                    str(import_patch_script),
                    "create",
                    "--project-dir",
                    project_dir,
                ],
                timeout=300,  # 5 minutes timeout
            )

            if result.returncode != 0:
                self.log(
                    f"Import patch creation failed with return code: {result.returncode}",
                    "ERROR",
                )
                return False

            # Step 2: Apply patch
            self.log("Applying import patch...")
            result = subprocess.run(
                ["python3", str(import_patch_script), "apply"],
                timeout=300,  # 5 minutes timeout
            )

            if result.returncode != 0:
                self.log(
                    f"Import patch application failed with return code: {result.returncode}",
                    "ERROR",
                )
                return False

            self.log("✓ Import patch completed successfully")
            return True

        except subprocess.TimeoutExpired:
            self.log("Import patch operation timed out", "ERROR")
            return False
        except Exception as e:
            self.log(f"Error running import patch: {e}", "ERROR")
            return False

    def _revert_import_patch(self) -> bool:
        """Revert previously applied import patches.

        Returns:
            True if successful, False otherwise
        """
        import_patch_script = self.script_dir / "setup" / "solidity_import_patch.py"

        if not import_patch_script.exists():
            self.log(f"Import patch script not found: {import_patch_script}", "ERROR")
            return False

        try:
            self.log("Reverting import patch...")
            result = subprocess.run(
                ["python3", str(import_patch_script), "revert"],
                timeout=300,  # 5 minutes timeout
            )

            if result.returncode != 0:
                self.log(
                    f"Import patch revert failed with return code: {result.returncode}",
                    "ERROR",
                )
                return False

            self.log("✓ Import patch reverted successfully")
            return True

        except subprocess.TimeoutExpired:
            self.log("Import patch revert operation timed out", "ERROR")
            return False
        except Exception as e:
            self.log(f"Error reverting import patch: {e}", "ERROR")
            return False

    def _deduplicate_contract_files(self, file_strings: List[str]) -> List[str]:
        """Deduplicate contract files by contract name, keeping shortest relative path.

        When multiple files declare the same contract name, keeps only the file with
        the shortest relative path to cwd. This resolves certoraRun errors about
        duplicate contract declarations.

        Args:
            file_strings: List of file specifications in format "PATH" or "PATH:CONTRACT_NAME"

        Returns:
            Deduplicated list of file specifications

        Example:
            Input: [
                "contracts/helpers/Token.sol",
                "src/contracts/helpers/Token.sol",
                "src/Utils.sol:UtilityContract"
            ]
            Output: [
                "contracts/helpers/Token.sol",  # Shorter path wins
                "src/Utils.sol:UtilityContract"
            ]
        """
        from pathlib import Path

        # Parse all file strings to ContractHandles (includes validation)
        contract_handles = parse_contract_files(file_strings)
        parsed_files = []

        for handle in contract_handles:
            # Normalize path to relative from cwd
            try:
                path_obj = Path(handle.source_file)
                if path_obj.is_absolute():
                    # Convert absolute to relative
                    rel_path = path_obj.relative_to(Path.cwd())
                else:
                    rel_path = path_obj

                # Check for parent directory references (../)
                if '..' in str(rel_path):
                    self.log(
                        f"Warning: File path contains parent directory reference: {rel_path}. "
                        f"This may indicate incorrect working directory.",
                        "WARNING"
                    )

                parsed_files.append((str(rel_path), handle.contract_name))
            except ValueError:
                # Path is outside cwd, keep as is
                parsed_files.append((handle.source_file, handle.contract_name))

        # Group by contract name
        contract_to_paths: dict[str, list[str]] = {}
        for path, contract_name in parsed_files:
            if contract_name not in contract_to_paths:
                contract_to_paths[contract_name] = []
            contract_to_paths[contract_name].append(path)

        # For each contract, keep the shortest path
        deduplicated_tuples = []
        for contract_name, paths in contract_to_paths.items():
            if len(paths) > 1:
                # Multiple files for same contract - pick shortest path
                # Sort by path length (shortest first)
                paths.sort(key=lambda p: len(p))
                shortest_path = paths[0]

                # Log the deduplication
                self.log(
                    f"Deduplicated contract '{contract_name}': selected '{shortest_path}' "
                    f"(shortest of {len(paths)} paths: {', '.join(paths)})",
                    "WARNING"
                )

                deduplicated_tuples.append((shortest_path, contract_name))
            else:
                # Only one file for this contract
                deduplicated_tuples.append((paths[0], contract_name))

        # Convert tuples back to file strings
        result = []
        for path, contract_name in deduplicated_tuples:
            # Check if contract name matches the basename
            if Path(path).stem == contract_name:
                # Simple format: just the path
                result.append(path)
            else:
                # Explicit format: PATH:CONTRACT_NAME
                result.append(f"{path}:{contract_name}")

        return result

    def _get_contract_name_from_path(
        self, file_path: str, contracts: List[ContractHandle]
    ) -> Optional[str]:
        """Map a file path from error message to contract name.

        Args:
            file_path: File path extracted from compiler error message
            contracts: List of ContractHandle objects to search

        Returns:
            Contract name if found, None otherwise
        """
        from pathlib import Path as PathlibPath

        # Try direct string match first (fastest)
        for contract in contracts:
            if contract.source_file == file_path:
                return contract.contract_name

        # Try normalized path comparison
        try:
            normalized_path = str(PathlibPath(file_path).resolve())
            for contract in contracts:
                contract_path = str(PathlibPath(contract.source_file).resolve())
                if contract_path == normalized_path:
                    return contract.contract_name
        except Exception:
            pass

        return None

    def _detect_stack_too_deep_errors(
        self, output: str, contracts: List[ContractHandle]
    ) -> Optional[str]:
        """Detect stack-too-deep error and return affected contract name.

        With assert_autofinder_success=True, only one contract will fail per run,
        so we return immediately upon finding the first match.

        Detects two error patterns:
        1. "Compiling <PATH> to expose internal function information"
           followed by "Encountered an exception generating autofinder"
           followed by "CompilerError: Stack too deep"
        2. "Compiling <PATH>..."
           followed by "solc<version> had an error:"
           followed by "CompilerError: Stack too deep"

        Args:
            output: Combined stdout+stderr from certoraRun
            contracts: List of ContractHandle objects to map paths to names

        Returns:
            Contract name that needs solc_via_ir_map entry, or None if no error found
        """
        lines = output.split("\n")

        for i in range(len(lines)):
            line = lines[i]

            # Pattern 1: Look for "Compiling <PATH> to expose internal function information"
            if "Compiling" in line and "to expose internal function information" in line:
                # Extract path between "Compiling" and "to expose"
                parts = line.split("Compiling", 1)
                if len(parts) > 1:
                    path_part = parts[1].split(
                        "to expose internal function information", 1
                    )[0].strip()

                    # Check next 2 lines for error pattern
                    if i + 2 < len(lines):
                        if "Encountered an exception generating autofinder" in lines[i + 1]:
                            if lines[i + 2].startswith("CompilerError: Stack too deep"):
                                # Map path to contract name
                                contract_name = self._get_contract_name_from_path(
                                    path_part, contracts
                                )
                                if contract_name:
                                    self.log(
                                        f"Detected stack-too-deep error for {contract_name} (path: {path_part})"
                                    )
                                    return contract_name  # Return immediately!
                                else:
                                    self.log(
                                        f"Warning: Could not map path '{path_part}' to contract name",
                                        "WARNING",
                                    )

            # Pattern 2: Look for "Compiling <PATH>..." (generic compilation)
            elif line.startswith("Compiling ") and line.endswith("...") and i + 1 < len(lines) and not lines[i + 1].startswith("Compiling "):
                # Extract path between "Compiling " and "..."
                path_part = line[len("Compiling ") : -3]

                # Check next lines for "solc<version> had an error:" and "CompilerError: Stack too deep"
                for j in range(i + 1, min(i + 5, len(lines))):  # Check up to 4 lines ahead
                    if lines[j].startswith("Compiling "):
                        break
                    if "had an error:" in lines[j]:
                        # Look for CompilerError in subsequent lines
                        for k in range(j + 1, min(j + 3, len(lines))):
                            if lines[k].startswith("CompilerError: Stack too deep"):
                                # Map path to contract name
                                contract_name = self._get_contract_name_from_path(
                                    path_part, contracts
                                )
                                if contract_name:
                                    self.log(
                                        f"Detected stack-too-deep error for {contract_name} (path: {path_part})"
                                    )
                                    return contract_name  # Return immediately!
                                else:
                                    self.log(
                                        f"Warning: Could not map path '{path_part}' to contract name",
                                        "WARNING",
                                    )
                        break  # Stop looking after finding "had an error:"

        return None  # No stack-too-deep error found

    def _detect_yul_exception_stack_too_deep(self, output: str) -> bool:
        """Detect YulException with stack too deep error.

        This error typically occurs after via-ir is enabled on contracts.

        Args:
            output: Combined stdout+stderr from certoraRun

        Returns:
            True if YulException stack-too-deep error detected
        """
        pattern = r"YulException:.*Stack too deep"
        return bool(re.search(pattern, output, re.IGNORECASE))

    def _detect_compiler_version_mismatch(
        self, output: str, contracts: List[ContractHandle]
    ) -> Optional[Tuple[str, str]]:
        """Detect compiler version mismatch error and extract contract name and required version.

        Parses errors like:
        Compiling src/ERC4337Account.sol...

        solc had an error:
        ParserError: Source file requires different compiler version (current compiler is 0.8.28+...)
         --> /path/to/file.sol:2:1:
          |
        2 | pragma solidity 0.8.23;
          | ^^^^^^^^^^^^^^^^^^^^^^^

        Args:
            output: Combined stdout+stderr from certoraRun
            contracts: List of ContractHandle objects to map paths to names

        Returns:
            Tuple of (contract_name, version_string) or None if not found
        """
        lines = output.split("\n")

        for i in range(len(lines)):
            line = lines[i]

            # Look for ParserError
            if "ParserError: Source file requires different compiler version" in line:
                file_path = None

                # Try to find file_path from preceding "Compiling ..." line
                for j in range(i - 1, max(i - 15, -1), -1):
                    if lines[j].startswith("Compiling ") and lines[j].endswith("..."):
                        file_path = lines[j][len("Compiling ") : -3]
                        break

                # Fallback: Extract file_path from arrow line if not found above
                # This happens with --compilation_steps_only flag in CI
                # In CI, paths can be wrapped across multiple lines
                if not file_path:
                    for j in range(i + 1, min(i + 10, len(lines))):
                        if "-->" in lines[j]:
                            # Collect path fragments from this and subsequent lines
                            path_parts = []
                            # Start from arrow line
                            arrow_line = lines[j].split("-->", 1)
                            if len(arrow_line) > 1:
                                path_parts.append(arrow_line[1].strip())

                            # Collect subsequent lines until we find line:col pattern
                            for k in range(j + 1, min(j + 5, len(lines))):
                                stripped = lines[k].strip()
                                if not stripped or stripped == "|":
                                    break  # Hit separator or empty line
                                path_parts.append(stripped)
                                # Check if this line ends with :line:col:
                                if re.search(r":\d+:\d+:\s*$", stripped):
                                    break

                            # Reconstruct full path
                            full_path = "".join(path_parts)
                            # Extract path without line:col
                            path_match = re.search(r"^(.+?):\d+:\d+:\s*$", full_path)
                            if path_match:
                                file_path = path_match.group(1).strip()
                                break

                if not file_path:
                    continue

                # Extract pragma specification from subsequent lines
                for k in range(i + 1, min(i + 10, len(lines))):
                    pragma_spec = extract_pragma_spec(lines[k])
                    if pragma_spec:

                        # Resolve pragma spec to concrete version
                        version = resolve_pragma_to_version(pragma_spec)
                        if not version:
                            self.log(
                                f"Could not resolve pragma '{pragma_spec}' to concrete version",
                                "WARNING",
                            )
                            return None

                        # Map file path to contract name
                        contract_name = self._get_contract_name_from_path(file_path, contracts)
                        if contract_name:
                            self.log(
                                f"Detected compiler version mismatch for {contract_name}: requires {version}"
                            )
                            return (contract_name, version)
                        else:
                            self.log(
                                f"Warning: Could not map path '{file_path}' to contract name",
                                "WARNING",
                            )
                            return None

        return None

    def _apply_via_ir_workaround(
        self, contract_needing_via_ir: str, config_dict: Dict, contracts: List[ContractHandle]
    ) -> Dict:
        """Add solc_via_ir_map entry for contract that needs via-ir compilation.

        Sets all contracts in the map: affected contract to true, others to false
        (unless already true from previous iterations).

        Args:
            contract_needing_via_ir: Contract name that needs via-ir enabled
            config_dict: Current configuration dictionary
            contracts: List of all ContractHandle objects being compiled

        Returns:
            Updated configuration dictionary with solc_via_ir_map entries
        """
        if "solc_via_ir_map" not in config_dict:
            # First time: initialize map with all contracts set to false
            config_dict["solc_via_ir_map"] = {}
            for contract in contracts:
                config_dict["solc_via_ir_map"][contract.contract_name] = False

        # Set the affected contract to true
        config_dict["solc_via_ir_map"][contract_needing_via_ir] = True
        self.log(f"Adding via-ir workaround for contract: {contract_needing_via_ir}")

        return config_dict

    def _apply_via_ir_workaround_to_config(
        self,
        contract_name: str,
        updated_config_dict: Dict,
        compilation_config: Dict,
        config_file: Path,
        contracts: List[ContractHandle],
    ) -> Dict:
        """Apply via-ir workaround to config files for a contract with stack-too-deep error.

        Args:
            contract_name: Name of contract needing via-ir workaround
            updated_config_dict: Tracker for config updates
            compilation_config: Full compilation config to be updated
            config_file: Path to config file to rewrite
            contracts: List of all contracts being compiled

        Returns:
            Updated config dictionary
        """
        self.log(f"Applying via-ir workaround for contract: {contract_name}")
        updated_config_dict = self._apply_via_ir_workaround(
            contract_name, updated_config_dict, contracts
        )
        compilation_config.update(updated_config_dict)

        # Rewrite config file with updated settings
        with open(config_file, "w") as f:
            json.dump(compilation_config, f, indent=2)

        return updated_config_dict

    def _apply_yul_exception_workaround(
        self,
        _detect_result: str,
        updated_config_dict: Dict,
        compilation_config: Dict,
        config_file: Path,
        _contracts: List[ContractHandle],
    ) -> Dict:
        """Apply YulException workaround by disabling assert_autofinder_success.

        Args:
            _detect_result: Not used (YulException detection returns bool, not a value)
            updated_config_dict: Tracker for config updates
            compilation_config: Full compilation config to be updated
            config_file: Path to config file to rewrite
            _contracts: Not used

        Returns:
            Updated config dictionary
        """
        self.log(
            "Detected YulException stack-too-deep error (caused by via-ir)", "WARNING"
        )
        self.log("Disabling assert_autofinder_success and retrying...")

        # Disable assert_autofinder_success in both dicts
        compilation_config["assert_autofinder_success"] = False
        updated_config_dict["assert_autofinder_success"] = False

        # Rewrite config file with updated settings
        with open(config_file, "w") as f:
            json.dump(compilation_config, f, indent=2)

        return updated_config_dict

    def _apply_compiler_version_workaround(
        self,
        contract_name: str,
        version_string: str,
        config_dict: Dict,
        contracts: List[ContractHandle],
    ) -> Dict:
        """Add compiler_map entry for contract that needs specific compiler version.

        Sets all contracts in the map: affected contract to required version, others to default version
        (configurable via --solc-default flag), unless already set from previous iterations.

        Args:
            contract_name: Contract name that needs specific compiler version
            version_string: Required version (e.g., "0.8.23")
            config_dict: Current configuration dictionary
            contracts: List of all ContractHandle objects being compiled

        Returns:
            Updated configuration dictionary with compiler_map entries
        """
        from src.utils.enhanced_config_manager import ConfigManager

        if "compiler_map" not in config_dict:
            # First time: initialize map with all contracts set to default
            config_dict["compiler_map"] = {}
            for contract in contracts:
                config_dict["compiler_map"][contract.contract_name] = (
                    self.solc_default_version
                )

        # Convert version to Certora format
        certora_version = ConfigManager.convert_solc_version_to_certora_format(
            version_string
        )

        # Set the affected contract to required version
        config_dict["compiler_map"][contract_name] = certora_version
        self.log(
            f"Adding compiler version workaround for {contract_name}: {certora_version}"
        )

        return config_dict

    def _apply_compiler_version_workaround_to_config(
        self,
        detect_result: Tuple[str, str],
        updated_config_dict: Dict,
        compilation_config: Dict,
        config_file: Path,
        contracts: List[ContractHandle],
    ) -> Dict:
        """Apply compiler version workaround to config files for a contract with version mismatch.

        Args:
            detect_result: Tuple of (contract_name, version_string) from detection
            updated_config_dict: Tracker for config updates
            compilation_config: Full compilation config to be updated
            config_file: Path to config file to rewrite
            contracts: List of all contracts being compiled

        Returns:
            Updated config dictionary
        """
        # Unpack the detection result tuple
        contract_name, version_string = detect_result

        self.log(f"Applying compiler version workaround for contract: {contract_name}")
        updated_config_dict = self._apply_compiler_version_workaround(
            contract_name, version_string, updated_config_dict, contracts
        )
        compilation_config.update(updated_config_dict)

        # Rewrite config file with updated settings
        with open(config_file, "w") as f:
            json.dump(compilation_config, f, indent=2)

        return updated_config_dict

    def _has_remappings_conflict(self, output: str) -> bool:
        return "package.json and remappings.txt include duplicated keys in" in output

    def _build_packages_from_remappings_and_packagejson(self) -> List[str]:
        """Build a merged packages list from remappings.txt and package.json.

        Remappings.txt entries take priority. For package.json dependencies not already
        covered by remappings, we add key=node_modules/key entries.

        For keys that appear in both sources, we validate that the remapping path (after '=')
        matches node_modules/<key>. If they disagree, we raise an error since automatic
        resolution is not safe.

        Returns:
            Combined list of package entries.

        Raises:
            RuntimeError: If a key appears in both remappings.txt and package.json with conflicting paths.
        """
        packages = []
        # Map from normalized key to the path (value after '=') from remappings.txt
        remapping_key_to_path: Dict[str, str] = {}

        # Read remappings.txt
        remappings_path = Path("remappings.txt")
        if remappings_path.exists():
            for line in remappings_path.read_text().splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                packages.append(line)
                # Extract key and path: key=path
                parts = line.split("=", 1)
                key = parts[0].rstrip("/")
                path = parts[1] if len(parts) > 1 else ""
                remapping_key_to_path[key] = path

        # Read package.json and add entries not already in remappings
        package_json_path = Path("package.json")
        if package_json_path.exists():
            package_data = json.loads(package_json_path.read_text())
            for section in ("dependencies", "devDependencies"):
                for key in package_data.get(section, {}):
                    normalized_key = key.rstrip("/")
                    if normalized_key not in remapping_key_to_path:
                        packages.append(f"{key}=node_modules/{key}")
                        remapping_key_to_path[normalized_key] = f"node_modules/{key}"
                    else:
                        # Key exists in both sources - validate that paths agree
                        remapping_path = remapping_key_to_path[normalized_key].rstrip("/")
                        expected_path = f"node_modules/{normalized_key}"
                        if remapping_path != expected_path:
                            raise RuntimeError(
                                f"Conflicting paths for package '{normalized_key}': "
                                f"remappings.txt maps to '{remapping_path}' but "
                                f"package.json implies 'node_modules/{normalized_key}'. "
                                f"Please resolve this conflict manually."
                            )

        return packages

    def _apply_remappings_conflict_workaround(
        self,
        _detect_result: str,
        updated_config_dict: Dict,
        compilation_config: Dict,
        config_file: Path,
        _contracts: List[ContractHandle],
    ) -> Dict:
        """Apply remappings conflict workaround by constructing explicit packages list.

        Args:
            _detect_result: Not used
            updated_config_dict: Tracker for config updates
            compilation_config: Full compilation config to be updated
            config_file: Path to config file to rewrite
            _contracts: Not used

        Returns:
            Updated config dictionary
        """
        self.log("Detected remappings conflict between package.json and remappings.txt", "WARNING")
        self.log("Building explicit packages list to resolve conflict...")

        packages = self._build_packages_from_remappings_and_packagejson()
        updated_config_dict["packages"] = packages
        compilation_config["packages"] = packages

        with open(config_file, "w") as f:
            json.dump(compilation_config, f, indent=2)

        self._remappings_workaround_applied = True
        return updated_config_dict

    def _run_compilation_with_workarounds(
        self,
        cmd: List[str],
        config_file: Path,
        compilation_config: Dict,
        contracts: List[ContractHandle],
        updated_config_dict: Dict,
    ) -> Tuple[bool, str, Dict]:
        """Run compilation with automatic workarounds for common errors.

        Applies workarounds in priority order:
        1. Remappings conflict (package.json vs remappings.txt duplicate keys)
        2. Compiler version mismatch (blocks all compilation)
        3. Stack-too-deep errors (via-ir workaround)
        4. YulException stack-too-deep (assert_autofinder_success workaround)

        Args:
            cmd: Command to execute
            config_file: Path to config file (to rewrite on updates)
            compilation_config: Full compilation config (will be updated)
            contracts: List of contracts for path mapping
            updated_config_dict: Config dict to track updates

        Returns:
            Tuple of (success, output, updated_config_dict)
        """
        # Check if global solc_via_ir is already enabled
        global_via_ir_enabled = updated_config_dict.get("solc_via_ir", False)
        solc_already_set = "solc" in updated_config_dict

        # Initialize workarounds list
        workarounds = [
            CompilationWorkaround(
                name="remappings_conflict",
                detect_fn=lambda output: (
                    "detected"
                    if self._has_remappings_conflict(output) and not self._remappings_workaround_applied
                    else None
                ),
                apply_fn=self._apply_remappings_conflict_workaround,
                enabled=True,
            ),
            CompilationWorkaround(
                name="compiler_version_mismatch",
                detect_fn=lambda output: self._detect_compiler_version_mismatch(
                    output, contracts
                ),
                apply_fn=self._apply_compiler_version_workaround_to_config,
                enabled=not solc_already_set,
            ),
            CompilationWorkaround(
                name="stack_too_deep_via_ir",
                detect_fn=lambda output: self._detect_stack_too_deep_errors(
                    output, contracts
                ),
                apply_fn=self._apply_via_ir_workaround_to_config,
                enabled=not global_via_ir_enabled,
            ),
            CompilationWorkaround(
                name="yul_exception_stack_too_deep",
                detect_fn=lambda output: (
                    "detected"
                    if self._detect_yul_exception_stack_too_deep(output)
                    and compilation_config.get("assert_autofinder_success", False)
                    else None
                ),
                apply_fn=self._apply_yul_exception_workaround,
                enabled=True,  # Always check, but detect_fn checks if applicable
            ),
        ]

        # Calculate max retries based on enabled workarounds
        enabled_workarounds = [w for w in workarounds if w.enabled]
        max_retries = len(contracts) * len(enabled_workarounds)
        retry_count = 0

        while retry_count <= max_retries:
            # Run compilation
            result = subprocess.run(cmd, capture_output=True, text=True, check=False)
            output = result.stdout + result.stderr

            if result.returncode == 0:
                return True, output, updated_config_dict

            # Log compilation output for debugging
            if self.verbose >= 2:
                self.log("Compilation output (stdout + stderr):")
                self.log(output)

            # Try to find an applicable workaround
            workaround_applied = False
            for workaround in workarounds:
                if not workaround.enabled:
                    continue

                # Try to detect if this workaround applies
                detect_result = workaround.detect_fn(output)
                if detect_result is not None:
                    # Apply the workaround
                    self.log(f"Applying {workaround.name} workaround")
                    updated_config_dict = workaround.apply_fn(
                        detect_result,
                        updated_config_dict,
                        compilation_config,
                        config_file,
                        contracts,
                    )
                    workaround_applied = True
                    retry_count += 1
                    self.log(
                        f"Retrying compilation after {workaround.name} fix (attempt {retry_count}/{max_retries})"
                    )
                    break  # Only apply one workaround per iteration

            # If no workaround applies, exit immediately (guardrail against infinite loop)
            if not workaround_applied:
                if retry_count == 0:
                    # First attempt failed - log output for debugging
                    self.log("Compilation failed. Output:", "WARNING")
                    self.log(output, "WARNING")
                else:
                    self.log(
                        "Compilation failed with no applicable workaround", "ERROR"
                    )
                return False, output, updated_config_dict

        # Max retries exceeded
        self.log(f"Max retries ({max_retries}) exceeded for workarounds", "ERROR")
        self.log("Final compilation output:", "ERROR")
        self.log(output, "ERROR")
        return False, output, updated_config_dict

    def _process_method_info(
        self,
        method: Dict,
        methods_set: set,
        all_methods: List,
        method_counts: Dict,
        originating_contract: str,
        is_internal: bool = False,
    ) -> None:
        """Process a single method and add it to the collections if not already seen."""
        # Build fullSignature from fullArgs
        full_args = method.get("fullArgs", [])
        signature_types = []
        locations = []

        for arg in full_args:
            type_desc = arg.get("typeDesc", {})
            arg_type = parse_type_descriptor(type_desc, TypeParseMode.QUALIFIED, method.get("contractName", ""))

            # Crash if arg_type is empty - this indicates a serious problem
            if not arg_type:
                raise Exception(
                    f"FATAL: Failed to convert typeDesc to signature type for argument in method {method.get('name', 'UNKNOWN')} "
                    f"in contract {method.get('contractName', 'UNKNOWN')}. "
                    f"typeDesc: {type_desc}, arg: {arg}"
                )

            signature_types.append(arg_type)
            locations.append(arg.get("location", ""))

        # Extract parameter names from method (paramNames is a separate field in the build JSON)
        param_names = method.get("paramNames", [])

        # Build return type signature from returns (same structure as fullArgs)
        returns_raw = method.get("returns", [])
        return_types = []
        return_locations = []
        for ret in returns_raw:
            type_desc = ret.get("typeDesc", {})
            ret_type = parse_type_descriptor(type_desc, TypeParseMode.QUALIFIED, method.get("contractName", ""))
            if not ret_type:
                raise Exception(
                    f"FATAL: Failed to convert typeDesc to signature type for return value in method "
                    f"{method.get('name', 'UNKNOWN')} in contract {method.get('contractName', 'UNKNOWN')}. "
                    f"typeDesc: {type_desc}, ret: {ret}"
                )
            return_types.append(ret_type)
            return_locations.append(ret.get("location", ""))

        # Extract only the fields we care about
        method_info = {
            "contractName": method.get("contractName", ""),
            "originatingContract": originating_contract,
            "isLibrary": method.get("isLibrary", False),
            "name": method.get("name", ""),
            "nonpayable": method.get("nonpayable", False)
            if not is_internal
            else method.get("stateMutability", "nonpayable") == "nonpayable",
            "stateMutability": method.get("stateMutability", "")
            if not is_internal
            else method.get("stateMutability", "nonpayable"),
            "visibility": method.get("visibility", "")
            if not is_internal
            else method.get("visibility", "internal"),
            "fullSignature": signature_types,
            "paramNames": param_names,
            "location": locations,
            "returns": return_types,
            "returnLocations": return_locations,
        }

        # Create a signature for deduplication (include full signature)
        method_signature = (
            method_info["contractName"],
            method_info["name"],
            method_info["stateMutability"],
            method_info["visibility"],
            tuple(method_info["fullSignature"]),
        )

        # Only add if not already seen
        if method_signature not in methods_set:
            methods_set.add(method_signature)
            all_methods.append(method_info)

    def generate_all_methods_json(self, build_data: Dict) -> None:
        """Extract and write all methods information to all_methods.json."""
        # Extract all methods from all contracts
        # Use a set to avoid duplicates during collection, then convert to list
        methods_set: set = set()
        all_methods: list = []
        method_counts: dict = {}  # For calculating overload counts

        # Iterate through all objects in the build data
        for key, obj in build_data.items():
            if isinstance(obj, dict) and "contracts" in obj:
                # Each contract object has a 'contracts' array with actual contract data
                for contract in obj.get("contracts", []):
                    # Get the originating contract name (the main compilation unit)
                    originating_contract = contract.get("name", "")

                    # Process regular methods
                    if isinstance(contract, dict) and "allMethods" in contract:
                        for method in contract["allMethods"]:
                            self._process_method_info(
                                method,
                                methods_set,
                                all_methods,
                                method_counts,
                                originating_contract,
                                is_internal=False,
                            )

                    # Process internal functions
                    if isinstance(contract, dict) and "internalFunctions" in contract:
                        # Internal functions are stored with IDs as keys
                        for func_id, func_data in contract["internalFunctions"].items():
                            if "method" in func_data:
                                method = func_data["method"]
                                self._process_method_info(
                                    method,
                                    methods_set,
                                    all_methods,
                                    method_counts,
                                    originating_contract,
                                    is_internal=True,
                                )

        # Write the processed data to all_methods.json
        output_path = Path(".certora_internal/all_methods.json")
        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, "w") as f:
            json.dump(all_methods, f, indent=2)

        self.log(f"✓ Processed {len(all_methods)} methods to {output_path}")

    def generate_all_user_defined_types_json(self, build_data: Dict) -> int:
        """Extract and write all user-defined types information to all_user_defined_types.json."""
        # Extract user-defined types from solidityTypes sections
        all_user_defined_types = []

        # Process user-defined types from each contract
        for key, obj in build_data.items():
            if isinstance(obj, dict) and "contracts" in obj:
                # Each contract object has a 'contracts' array with actual contract data
                for contract in obj.get("contracts", []):
                    if isinstance(contract, dict) and "solidityTypes" in contract:
                        for type_info in contract.get("solidityTypes", []):
                            if isinstance(type_info, dict):
                                type_name = None
                                qualified_name = None
                                base_type = None

                                # Handle UserDefinedValueType
                                if type_info.get("type") == "UserDefinedValueType":
                                    type_name = type_info.get("valueTypeName")
                                    containing_contract = type_info.get(
                                        "containingContract"
                                    )

                                    if containing_contract:
                                        qualified_name = (
                                            f"{containing_contract}.{type_name}"
                                        )
                                    else:
                                        # Use main contract name from orchestrator
                                        main_contract = (
                                            getattr(
                                                self,
                                                "contract_names",
                                                ["UnknownContract"],
                                            )[0]
                                            if hasattr(self, "contract_names")
                                            else "UnknownContract"
                                        )
                                        qualified_name = f"{main_contract}.{type_name}"

                                    # Get the base type
                                    value_type = type_info.get(
                                        "valueTypeAliasedName", {}
                                    )
                                    if value_type.get("type") == "Primitive":
                                        base_type = value_type.get("primitiveName")

                                # Handle UserDefinedStruct
                                elif type_info.get("type") == "UserDefinedStruct":
                                    type_name = type_info.get("structName")
                                    containing_contract = type_info.get(
                                        "containingContract"
                                    )

                                    if containing_contract:
                                        qualified_name = (
                                            f"{containing_contract}.{type_name}"
                                        )
                                    else:
                                        # Use main contract name from orchestrator
                                        main_contract = (
                                            getattr(
                                                self,
                                                "contract_names",
                                                ["UnknownContract"],
                                            )[0]
                                            if hasattr(self, "contract_names")
                                            else "UnknownContract"
                                        )
                                        qualified_name = f"{main_contract}.{type_name}"

                                    base_type = "struct"
                                    # Extract struct members
                                    struct_members = type_info.get("structMembers", [])

                                # Handle UserDefinedEnum
                                elif type_info.get("type") == "UserDefinedEnum":
                                    type_name = type_info.get("enumName")
                                    containing_contract = type_info.get(
                                        "containingContract"
                                    )

                                    if containing_contract:
                                        qualified_name = (
                                            f"{containing_contract}.{type_name}"
                                        )
                                    else:
                                        # Use main contract name from orchestrator
                                        main_contract = (
                                            getattr(
                                                self,
                                                "contract_names",
                                                ["UnknownContract"],
                                            )[0]
                                            if hasattr(self, "contract_names")
                                            else "UnknownContract"
                                        )
                                        qualified_name = f"{main_contract}.{type_name}"

                                    base_type = "uint8"
                                    # Extract enum members
                                    enum_members = type_info.get("enumMembers", [])

                                # Add to collection if we found a valid type
                                if type_name and qualified_name:
                                    user_type_info = {
                                        "typeName": type_name,
                                        "qualifiedName": qualified_name,
                                        "baseType": base_type,
                                        "typeCategory": type_info.get("type"),
                                        "containingContract": type_info.get(
                                            "containingContract"
                                        ),
                                        "main_contract": contract.get("name"),
                                    }

                                    # Add enum members for UserDefinedEnum
                                    if type_info.get("type") == "UserDefinedEnum":
                                        user_type_info["enumMembers"] = enum_members
                                    # Add struct members for UserDefinedStruct
                                    if type_info.get("type") == "UserDefinedStruct":
                                        user_type_info["structMembers"] = struct_members
                                    all_user_defined_types.append(user_type_info)

        # Write user-defined types to JSON file
        types_output_path = Path(".certora_internal/all_user_defined_types.json")
        types_output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(types_output_path, "w") as f:
            json.dump(all_user_defined_types, f, indent=2)

        return len(all_user_defined_types)

    def generate_logic_contracts_json(
        self, build_data: Dict, build_json_path: Path
    ) -> bool:
        """Extract and write logic contracts information to all_logic_contracts.json."""
        # Extract logic contracts using the auxiliary function
        try:
            logic_contracts = self._extract_contract_names(build_data)

            if not logic_contracts:
                self.log("No logic contracts found in build file", "ERROR")
                return False

            # Write logic contracts to JSON file
            contracts_output_path = Path(".certora_internal/all_logic_contracts.json")
            with open(contracts_output_path, "w") as f:
                json.dump(logic_contracts, f, indent=2)

            self.log(
                f"✓ Extracted {len(logic_contracts)} logic contracts to {contracts_output_path}"
            )
            self.log(f"Logic contracts found: {logic_contracts}")
            return True

        except Exception as e:
            self.log(f"Failed to extract logic contracts: {e}", "ERROR")
            return False

    def generate_all_sources_json(self, build_data: Dict) -> None:
        """Extract and write all source file paths with their definitions to all_sources.json.

        The output structure is:
        {
            "path/to/file.sol": {
                "contracts": ["ContractA", "ContractB"],
                "libraries": ["LibraryX"]
            },
            ...
        }
        """
        # Collect all source file paths from srclist entries
        all_source_paths = set()

        # Iterate through all objects in the build data
        for key, obj in build_data.items():
            if isinstance(obj, dict) and "srclist" in obj:
                srclist = obj["srclist"]
                if isinstance(srclist, dict):
                    # srclist is a mapping from string to path - collect all paths
                    for source_key, source_path in srclist.items():
                        if isinstance(source_path, str):
                            all_source_paths.add(source_path)

        # Build dict mapping path -> {contracts: [...], libraries: [...]}
        all_sources_dict = {}

        for source_path in sorted(all_source_paths):
            try:
                # Extract contracts and libraries from the source file
                contracts = extract_definitions_from_solidity(source_path, definition_type='contract')
                libraries = extract_definitions_from_solidity(source_path, definition_type='library')

                all_sources_dict[source_path] = {
                    "contracts": contracts,
                    "libraries": libraries
                }
            except FileNotFoundError:
                self.log(f"Warning: Source file not found: {source_path}", "WARNING")
                # Store empty lists for missing files
                all_sources_dict[source_path] = {
                    "contracts": [],
                    "libraries": []
                }
            except Exception as e:
                self.log(f"Warning: Could not parse {source_path}: {e}", "WARNING")
                # Store empty lists for unparseable files
                all_sources_dict[source_path] = {
                    "contracts": [],
                    "libraries": []
                }

        # Write source files to JSON file
        sources_output_path = Path(".certora_internal/all_sources.json")
        sources_output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(sources_output_path, "w") as f:
            json.dump(all_sources_dict, f, indent=2)

        # Count total definitions
        total_contracts = sum(len(defs["contracts"]) for defs in all_sources_dict.values())
        total_libraries = sum(len(defs["libraries"]) for defs in all_sources_dict.values())

        self.log(
            f"✓ Processed {len(all_sources_dict)} source files to {sources_output_path} "
            f"({total_contracts} contracts, {total_libraries} libraries)"
        )

    def generate_bytes_mappings_json(self, build_data: Dict) -> None:
        """Extract and write contracts with bytes mapping fields to bytes_mappings.json.

        The output structure is a list of objects:
        [
            {
                "contract_name": "MyContract",
                "source_file": "src/MyContract.sol",
                "bytes_mapping_fields": ["field1", "field2"]
            },
            ...
        ]
        """
        bytes_mappings_list = []

        # Iterate through all contracts in the build data
        for contract_data in build_data.values():
            for contract in contract_data.get('contracts', []):
                contract_name = contract.get('name')
                source_file = contract.get('file')

                if not contract_name or not source_file:
                    continue

                storage_layout = contract.get('storageLayout', {})
                bytes_mapping_fields = []

                # Check each storage field
                for storage_item in storage_layout.get('storage', []):
                    descriptor = storage_item.get('descriptor', {})

                    # Check if this is a mapping with bytes key
                    if descriptor.get('type') == 'Mapping':
                        key_type = descriptor.get('mappingKeyType', {})
                        if key_type.get('type') == 'PackedBytes':
                            field_name = storage_item.get('label', '')
                            if field_name:
                                bytes_mapping_fields.append(field_name)

                # Add to list if we found any bytes mapping fields
                if bytes_mapping_fields:
                    bytes_mappings_list.append({
                        "contract_name": contract_name,
                        "source_file": source_file,
                        "bytes_mapping_fields": bytes_mapping_fields
                    })

        # Write to JSON file
        output_path = Path(".certora_internal/bytes_mappings.json")
        output_path.parent.mkdir(parents=True, exist_ok=True)

        with open(output_path, "w") as f:
            json.dump(bytes_mappings_list, f, indent=2)

        if bytes_mappings_list:
            self.log(f"✓ Found {len(bytes_mappings_list)} contract(s) with bytes mappings, written to {output_path}")
        else:
            self.log(f"✓ No contracts with bytes mappings found")

    def generate_signature_database_json(self, build_json_path: Path) -> None:
        """Generate signature database JSON from the Certora build JSON."""
        self.log("Extracting function signatures and creating signature database...")

        try:
            # Initialize signature manager
            project_root = Path.cwd()
            signature_manager = SignatureManager(project_root)

            # Extract signatures from build JSON
            signatures = signature_manager.extract_signatures_from_build(
                build_json_path
            )

            # Create contract info objects from build data
            contract_infos = self._extract_contract_infos_from_build(build_json_path)

            # Find the latest AST file
            ast_file_path = self.getASTPath()

            # Extract inheritance info and abstract contracts from AST if available
            inheritance_info, abstract_contracts = self._extract_inheritance_and_abstract_from_ast(ast_file_path)
            if inheritance_info:
                # Update contract_infos with inheritance information
                contract_infos = self._merge_inheritance_info(contract_infos, inheritance_info)

            self.log(f"Detected abstract contracts: {abstract_contracts}")
            # Populate signature database
            self.log("🔄 Populating signature database with contract_infos and signatures...")
            signature_manager.populate_signature_database(contract_infos, signatures, abstract_contracts)

            # Dump signature database to JSON (same as autosetup)
            dump_path = signature_manager.dump_signature_database()
            self.log(f"✓ Generated signature database: {dump_path}")

        except Exception as e:
            self.log(f"Failed to generate signature database: {e}", "ERROR")
            self.log(f"Traceback: {traceback.format_exc()}", "ERROR")
            raise

    def _extract_inheritance_and_abstract_from_ast(self, ast_file_path: Optional[Path]) -> tuple[Dict[str, List[str]], set]:
        """Extract inheritance information and abstract contracts from AST dumps.

        Args:
            ast_file_path: Path to the .asts.json file, or None if not available

        Returns:
            Tuple of (inheritance_info, abstract_contracts) where:
            - inheritance_info: Dict mapping contract_name -> list of parent contracts
            - abstract_contracts: Set of contract names that are abstract or interfaces
        """
        inheritance_info = {}
        abstract_contracts = set()

        if not ast_file_path:
            self.log("No AST file provided - inheritance info will be missing", "WARNING")
            return inheritance_info, abstract_contracts

        try:
            with open(ast_file_path, "r", encoding="utf-8") as f:
                asts = json.load(f)

            self.log(f"Extracting inheritance info from {ast_file_path}")

            # Extract inheritance info from AST structure
            # Build ID to contract name mapping once
            id_to_name = {}
            for file_path, abs_path_dict in asts.items():
                for abs_path, nodes in abs_path_dict.items():
                    for node_id, node in nodes.items():
                        if node.get("nodeType") == "ContractDefinition":
                            contract_id = node.get("id")
                            contract_name = node.get("name")
                            if contract_id and contract_name:
                                id_to_name[contract_id] = contract_name

            # Now process contracts and resolve inheritance using the pre-built mapping
            for file_path, abs_path_dict in asts.items():
                for abs_path, nodes in abs_path_dict.items():
                    for node_id, node in nodes.items():
                        # Look for contract definitions to get linearizedBaseContracts
                        if node.get("nodeType") == "ContractDefinition":
                            contract_name = node.get("name")
                            if contract_name:
                                # Check if abstract or interface
                                is_abstract = node.get("abstract", False)
                                contract_kind = node.get("contractKind", "contract")

                                if is_abstract or contract_kind == "interface":
                                    abstract_contracts.add(contract_name)
                                    self.log(f"Identified {'abstract' if is_abstract else 'interface'}: {contract_name}", "DEBUG")

                                # Get linearized base contracts (includes self + all inherited contracts)
                                linearized = node.get("linearizedBaseContracts", [])
                                if len(linearized) > 1:  # More than just self
                                    # Convert IDs to contract names using pre-built mapping
                                    base_contracts = [id_to_name[contract_id] for contract_id in linearized[1:] if contract_id in id_to_name]
                                    if base_contracts:
                                        inheritance_info[contract_name] = base_contracts

            self.log(f"Extracted inheritance for {len(inheritance_info)} contracts", "DEBUG")
            self.log(f"Found {len(abstract_contracts)} abstract/interface contracts to skip", "INFO")
            return inheritance_info, abstract_contracts

        except Exception as e:
            self.log(f"Failed to extract inheritance from AST: {e}", "WARNING")
            return inheritance_info, abstract_contracts

    def _merge_inheritance_info(self, contract_infos: List[ContractInfo], inheritance_info: Dict[str, List[str]]) -> List[ContractInfo]:
        """Merge inheritance information into ContractInfo objects."""
        updated_contract_infos = []

        for contract_info in contract_infos:
            if contract_info.name in inheritance_info:
                # Create new ContractInfo with inheritance info
                updated_contract_info = ContractInfo(
                    name=contract_info.name,
                    kind=contract_info.kind,
                    source_file=contract_info.source_file,
                    function_signatures=contract_info.function_signatures,
                    is_compilable=contract_info.is_compilable,
                    compilation_error=contract_info.compilation_error,
                    inherits_from=(contract_info.inherits_from or []) + inheritance_info[contract_info.name]  # Add inheritance info
                )
                updated_contract_infos.append(updated_contract_info)
            else:
                # Keep original contract info
                updated_contract_infos.append(contract_info)

        return updated_contract_infos

    def _extract_contract_infos_from_build(
        self, build_json_path: Path
    ) -> List[ContractInfo]:
        """Extract contract information from build JSON to create ContractInfo objects."""
        contract_infos = []

        try:
            with open(build_json_path, "r") as f:
                build_data = json.load(f)

            seen_contracts = set()

            # Discover contracts and create ContractInfo objects
            for contract_key, contract_data in build_data.items():
                if (
                    not isinstance(contract_data, dict)
                    or "contracts" not in contract_data
                ):
                    continue

                for contract in contract_data.get("contracts", []):
                    if not isinstance(contract, dict):
                        continue

                    methods = contract.get("methods", [])
                    if not methods:
                        continue

                    contract_name = contract.get("name", "Unknown")

                    # Skip if already processed
                    if contract_name in seen_contracts:
                        continue
                    seen_contracts.add(contract_name)

                    # Get source file directly from contract object (canonical source)
                    source_file_str = contract.get("original_file") or contract.get("file")

                    # Fall back to method inspection only if contract-level fields are missing
                    if not source_file_str:
                        fallback_source = None
                        for method in methods:
                            original_file = method.get("originalFile")
                            if original_file:
                                fallback_source = original_file

                            # Prefer file that matches contract name (where contract is actually defined)
                            if original_file.endswith(f"/{contract_name}.sol") or original_file.endswith(f"\\{contract_name}.sol"):
                                source_file_str = original_file
                                break
                        if not source_file_str and fallback_source:
                            source_file_str = fallback_source

                    # Final fallback
                    if not source_file_str:
                        source_file_str = "unknown.sol"

                    # Determine contract kind (basic heuristic)
                    is_library = any(
                        method.get("isLibrary", False) for method in methods
                    )
                    kind = ContractKind.LIBRARY if is_library else ContractKind.CONTRACT

                    # Create contract info with inheritance
                    contract_info = ContractInfo(
                        name=contract_name,
                        kind=kind,
                        source_file=Path(source_file_str),
                        inherits_from=[],  # added later via _extract_inheritance_from_ast()
                        artifact_path=build_json_path,
                    )

                    contract_infos.append(contract_info)

            return contract_infos

        except Exception as e:
            self.log(f"Error extracting contract infos: {e}", "ERROR")
            return []

    def generate_ast_graph(self, ast_path: Path) -> None:
        """
        Generate a parent graph from the AST for efficient node parent lookups.

        Creates a mapping from node_id to parent_node_id for all nodes in the AST.
        This allows O(1) lookup of a node's parent, which is useful for filtering
        operations like detecting chained member accesses.

        Args:
            ast_path: Path to the .asts.json file

        Output:
            Writes to .certora_internal/.ast_graph.json with structure:
            {
                "relative_path": {
                    "absolute_path": {
                        "node_id": "parent_node_id"
                    }
                }
            }
        """
        self.log("Building AST parent graph...")

        try:
            with open(ast_path, 'r') as f:
                asts_data = json.load(f)

            # Build parent graph: node_id -> parent_node_id
            parent_graph = {}

            # Structure: dict[relative_path: dict[absolute_path: dict[node_id: node_data]]]
            for relative_path, path_data in asts_data.items():
                parent_graph[relative_path] = {}

                for absolute_path, nodes in path_data.items():
                    parent_graph[relative_path][absolute_path] = {}

                    # For each node, find all child node IDs and map them to this parent
                    for node_id, node in nodes.items():
                        if not isinstance(node, dict):
                            continue

                        # Find all child node IDs referenced in this node
                        child_ids = self._extract_child_node_ids(node)
                        for child_id in child_ids:
                            parent_graph[relative_path][absolute_path][str(child_id)] = str(node_id)

            # Write parent graph to JSON
            graph_path = self.getASTParentGraphPath()
            with open(graph_path, 'w') as f:
                json.dump(parent_graph, f, indent=2)

            self.log(f"✓ AST parent graph saved to {graph_path}")

        except Exception as e:
            self.log(f"Warning: Failed to generate AST parent graph: {e}", "WARNING")
            self.log(f"Traceback: {traceback.format_exc()}", "WARNING")

    def _extract_child_node_ids(self, node: Any) -> List[int]:
        """
        Extract all child node IDs from an AST node.

        Args:
            node: AST node (dict or other type)

        Returns:
            List of child node IDs
        """
        child_ids = []

        if isinstance(node, dict):
            for key, value in node.items():
                # Look for 'id' fields in nested structures
                if isinstance(value, dict) and 'id' in value:
                    child_ids.append(value['id'])
                elif isinstance(value, list):
                    for item in value:
                        if isinstance(item, dict) and 'id' in item:
                            child_ids.append(item['id'])

        return child_ids

    def getASTPath(self) -> Path:
        return Path(".certora_internal/all_asts.json")

    def getASTParentGraphPath(self) -> Path:
        return Path(".certora_internal/all_ast_parent_graph.json")
    
    def process_certora_build_json(self) -> bool:
        """Process .certora_build.json to extract method information."""
        build_json_path = Path(".certora_internal/latest/.certora_build.json")
        self._build_dir = build_json_path.parent

        self.log(f"Processing build json: {build_json_path.resolve()}")

        if not build_json_path.exists():
            self.log(f"Build JSON not found at: {build_json_path}", "ERROR")
            return False

        try:
            with open(build_json_path, "r") as f:
                build_data = json.load(f)

            # Generate all_methods.json
            self.generate_all_methods_json(build_data)

            # Generate all_user_defined_types.json
            self.generate_all_user_defined_types_json(build_data)

            # Generate all_sources.json
            self.generate_all_sources_json(build_data)

            # Generate all_logic_contracts.json
            if not self.generate_logic_contracts_json(build_data, build_json_path):
                return False

            # Copy .asts.json from build directory to .certora_internal
            asts_source = self._build_dir / ".asts.json"
            asts_target = self.getASTPath()
            if not asts_source.exists():
                self.log(f"FATAL: .asts.json not found at {asts_source}. "
                         f"The Certora build did not produce the expected AST file.", "ERROR")
                sys.exit(1)
            try:
                shutil.copy2(asts_source, asts_target)
                self.log(f"Copied AST file from {asts_source} to {asts_target}")
            except Exception as e:
                self.log(f"FATAL: Failed to copy .asts.json from {asts_source} to {asts_target}: {e}", "ERROR")
                sys.exit(1)

            self.generate_ast_graph(asts_target)

            # Generate signature database (uses the ast file copied before)
            self.generate_signature_database_json(build_json_path)

            # Generate bytes mappings JSON
            self.generate_bytes_mappings_json(build_data)

            return True

        except Exception as e:
            self.log(f"Error processing .certora_build.json: {e}", "ERROR")
            self.log(f"Traceback: {traceback.format_exc()}", "ERROR")
            return False

    def run_setup_summaries(self, contract_files: List[str]) -> Tuple[bool, Any]:
        """
        Run setup_summaries to detect and configure library summaries.

        Returns:
            Tuple[bool, List[str]]: (success, has_more_templates)
            - success: True if setup completed successfully
            - setup: setup object for later use (e.g. template processing)
        """
        self.log("Running setup_summaries to configure library summaries...")

        try:
            # Import SummarySetup
            from setup.setup_summaries import SummarySetup # type: ignore[import-not-found]

            # Create SummarySetup instance, passing through the verbosity level
            # Default to 1 if verbose is 0 (for basic logging)
            inheritance_graph = self.scope.signature_database.build_inheritance_graph()
            setup = SummarySetup(verbose=max(1, self.verbose), inheritance_graph=inheritance_graph)

            # Run the setup with appropriate flags
            success = setup.run(
                contract_files=contract_files,
                skip_update=False,
                include_test_files=False,
                include_dependencies=True,
                enable_llm=not self.skip_llm,
                force_llm_regenerate=self.force_llm_regenerate,
                custom_recipe=None,
            )

            if success:
                self.log("✓ Setup summaries completed successfully")
                return True, setup
            else:
                self.log("✗ Setup summaries failed", "ERROR")
                return False, []

        except Exception as e:
            self.log(f"✗ Setup summaries failed with exception: {e}", "ERROR")
            self.log(f"Traceback: {traceback.format_exc()}", "ERROR")
            return False, []

    def setup_prover(
        self, contract_handles: List[ContractHandle], main_contract_handles: List[ContractHandle]
    ) -> Tuple[Dict[str, Path], Dict[str, Any], bool]:
        """Run compilation analysis and setup summaries for the prover.

        Returns:
            Tuple[Dict[str, Path], Dict[str, Any], bool]: (contract_to_summary_map, updated_config_dict, import_patcher_applied)
            - contract_to_summary_map: Map from contract name to summaries spec path
            - updated_config_dict: Configuration dictionary with all updates applied during compilation
            - import_patcher_applied: True if import patcher was successfully applied
        """
        main_contract_names = [ch.contract_name for ch in main_contract_handles]

        # Run compilation-only step to extract method information
        # We run the compilation analysis for all the contracts (i.e. for
        # contract_files, not just for main_contract_files) because we need to
        # have all the contracts in the signature database (which is then for
        # instance consumed by the dispatcher call resolution logic).
        success, updated_config_dict, import_patcher_applied = self.run_compilation_analysis(
            contract_handles, contract_handles[0].contract_name
        )
        if not success:
            raise CompilationAnalysisError("Compilation analysis failed")

        # Store the configuration updates
        self.compilation_config_updates = updated_config_dict
        self.import_patcher_applied = import_patcher_applied

        # Detect and apply code access patches
        self.code_access_patches_applied = detect_and_apply_code_access_patches(
            self.log, self.getASTPath(), self.getASTParentGraphPath(), self.scope
        )

        # Run setup_summaries to detect and configure library summaries
        # We need to run this for all contract_files (not just
        # main_contract_files), because the LLM part currently scans only the
        # files directly passed to this function. I.e. if contract A imports and
        # use B, and B uses muldiv from PRBMath, but only A is in
        # main_contracts, we would not get the summary for the muldiv called
        # from B. Hence, we include all contract files in this analysis. This
        # can be possibly reworked in the future.
        success_summaries, setup = self.run_setup_summaries([ch.source_file for ch in contract_handles])
        if not success_summaries:
            raise SummarySetupError("Setup summaries generation failed")

        # Stop here if requested for debugging summaries
        if self.stop_after_summaries:
            self.log(
                "🛑 Stopping after summaries generation as requested (--stop-after-summaries)"
            )
            self.log("✅ Function summaries generation completed successfully")
            self.log(f"📁 Generated summaries are available in: {self.certora_dir}")

            all_methods = self.certora_dir / "all_methods.json"
            if all_methods.exists():
                self.log(f"📄 all_methods.json: {all_methods}")

            all_types = self.certora_dir / "all_user_defined_types.json"
            if all_types.exists():
                self.log(f"📄 all_user_defined_types.json: {all_types}")

            # Exit cleanly - summaries generation completed successfully
            sys.exit(0)

        # Run setup_erc7201.py
        self.log("=== ERC-7201 DETECTION PHASE ===")
        self.run_setup_erc7201()  # todo handle this within summaries.spec

        ret_dict = {}

        self.log("=== TEMPLATE PROCESSING PHASE ===")
        self.log(
            f"Found {len(setup.templates)} template(s) to process for {len(contract_handles)} contract(s)"
        )

        # Step 1: Build spec name mapping for reverse_rename_function
        # Maps versioned names to base names: {"PRB_Math-MyContract": "PRB_Math", ...}
        spec_name_mapping = {}
        base_names = set()
        base_names.add("summaries")

        # auxiliary mapping for rename functions
        for contract_name in main_contract_names:
            versioned_name = f"summaries-{contract_name}"
            spec_name_mapping[versioned_name] = "summaries"
        for template_path in setup.templates:
            template_spec_path = Path(template_path)
            base_name = template_spec_path.stem  # e.g., "PRB_Math"
            base_names.add(base_name)
            for contract_name in main_contract_names:
                versioned_name = f"{base_name}-{contract_name}"
                spec_name_mapping[versioned_name] = base_name
            # the real files have to exist so that we could follow imports graph
            old_path = self.certora_dir / Path(template_path)
            new_path = self.certora_dir / Path(template_path).with_suffix(".spec")
            if old_path != new_path:
                shutil.copyfile(old_path, new_path)

        # Step 2: Build updates dictionary with template processing callbacks, per each contract
        for contract_name in main_contract_names:
            updates = {}
            for template_path in setup.templates:
                template_spec_path = Path(template_path)
                base_name = template_spec_path.stem

                # Create callback for this template
                def create_template_callback(base):
                    def process_template(
                        spec_path: Path,
                        rename_fn: Callable[[str], str],
                        reverse_rename_fn: Callable[[str], str],
                    ) -> Path:
                        """Process template for a contract and return the last versioned spec path."""
                        last_spec_path = None

                        # Create versioned spec name
                        versioned_name = rename_fn(base)
                        versioned_spec_path = (
                            spec_path.parent / f"{versioned_name}.spec"
                        )
                        template_path = spec_path.parent / f"{base}.template.spec"

                        # Process the template for this contract
                        setup.process_template_in_place(
                            template_path, spec_path, versioned_spec_path, contract_name
                        )

                        self.log(
                            f"Created {versioned_spec_path.name} for contract {contract_name}"
                        )

                        last_spec_path = versioned_spec_path

                        return last_spec_path

                    return process_template

                updates[base_name] = create_template_callback(base_name)

            # Step 3: Define rename and reverse_rename functions using the mapping
            def rename_function(base_name: str) -> str:
                """Append the contract name as suffix."""
                return f"{base_name}-{contract_name}"

            def reverse_rename_function(current_name: str) -> str:
                """Extract base name from versioned name using precomputed mapping."""
                if current_name in spec_name_mapping:
                    return spec_name_mapping[current_name]
                if current_name in base_names:
                    return current_name

                raise Exception(
                    f"Did not find a reverse entry for {current_name} in mapping {spec_name_mapping}"
                )

            # Step 4: Call perform_recursive_update
            # Always use keep_intermediate_files=True for template processing to ensure
            # all import chains are properly updated
            typechecker_loop = TypecheckerLoop(
                certora_dir=self.certora_dir,
                verbose=bool(self.verbose),
                keep_intermediate_files=True
            )
            self.log("Processing templates with perform_recursive_update...")
            # Use contract-specific summaries file, not the placeholder summaries.spec
            contract_summaries_spec = self.certora_dir / f"summaries-{contract_name}.spec"
            new_summaries_spec = typechecker_loop.perform_recursive_update(
                updates=updates,
                main_spec=str(contract_summaries_spec),
                rename_function=rename_function,
                reverse_rename_function=reverse_rename_function,
            )

            self.log(
                f"✓ Template processing complete. New summaries spec: {new_summaries_spec}"
            )
            ret_dict[contract_name] = Path(new_summaries_spec)

        return ret_dict, self.compilation_config_updates, self.import_patcher_applied
