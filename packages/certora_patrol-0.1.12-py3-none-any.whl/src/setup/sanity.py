#!/usr/bin/env python3
"""
Sanity Phase - Two-stage parallel optimization of loop bounds and hashing parameters.

High-level approach:
1. Stage 1: Find minimum sufficient loop_iter using very large hashing bounds (parallel testing)
2. Stage 2: Use optimal loop_iter to detect precise hashing bounds via bound detection
"""

import re
import time
from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

from src.utils.enhanced_config_manager import ConfigManager, ProverJobSpec
from src.utils.logger import log_with_contract
from src.utils.prover_runner import ProverRunner
from src.utils.runner_types import JobStatus, NotificationType, ProverResult, RuleResult


@dataclass
class SanityAnalysis:
    """Analysis results for sanity checking."""

    methods_passed: List[str]
    methods_failed: List[str]
    total_methods: int
    sanity_passed: bool

    @property
    def summary(self) -> str:
        return f"{len(self.methods_passed)}/{self.total_methods} methods passed"


class SanityResult(Enum):
    """Results from sanity checking runs."""

    SUCCESS = "success"
    SANITY_FAIL = "sanity_fail"
    TIMEOUT = "timeout"
    MEMOUT = "memout"
    UNKNOWN_FAIL = "unknown_fail"


@dataclass
class BoundConfiguration:
    """Configuration for a specific bound combination."""

    loop_iter: int
    hashing_bound: Optional[int]
    optimistic_hashing: bool # currently we always set the optimistic version
    optimistic_loop: bool # currently we always set the optimistic version

    def get_config_properties(self) -> Dict[str, Any]:
        """Get config properties (not command line args) for this bound configuration."""
        properties = {
            "loop_iter": self.loop_iter,
            "optimistic_loop": self.optimistic_loop,
            "optimistic_hashing": self.optimistic_hashing,
        }
        if self.hashing_bound is not None:
            properties["hashing_length_bound"] = self.hashing_bound
        return properties

    def __str__(self) -> str:
        """String representation for logging."""
        parts = [f"loop_iter={self.loop_iter}"]
        parts.append(f"optimistic_hashing={self.optimistic_hashing}")
        parts.append(f"optimistic_loop={self.optimistic_loop}")
        if self.hashing_bound:
            parts.append(f"hashing_bound={self.hashing_bound}")
        return f"BoundConfig({', '.join(parts)})"


@dataclass
class SanityTestResult:
    """Result from testing a specific bound configuration."""

    config: BoundConfiguration
    result: SanityResult
    duration: float
    report_path: Optional[str]
    sanity_analysis: Optional[SanityAnalysis] = None

    @property
    def success(self) -> bool:
        """Whether this configuration was successful."""
        return self.result == SanityResult.SUCCESS


class SanityEarlyTerminationCallback:
    """Early termination callback for sanity loop iteration optimization."""

    def __init__(self, all_job_specs: List["ProverJobSpec"]):
        self.all_job_specs = all_job_specs

    def should_terminate(
        self,
        completed_result: ProverResult,
        all_completed_results: List[ProverResult],
    ) -> bool:
        """
        Early termination logic for sanity testing:
        If a job with loop_iter=N succeeds (i.e. all methods passed sanity) and
        all jobs with loop_iter < N have finished,
        then N is the optimal solution and we can terminate remaining higher loop_iter jobs.
        """
        # Only consider successful results that pass sanity checks for early termination
        if (
            not completed_result.success
            or not completed_result.job_spec.context
        ):
            return False

        # Check if sanity tests passed
        if (
            not completed_result.transformed_result
            or not completed_result.transformed_result.success
        ):
            return False

        current_loop_iter = completed_result.job_spec.context.loop_iter

        # Get list of completed job specs for comparison
        completed_job_specs = [
            result.job_spec for result in all_completed_results
        ]

        # Check if all job specs with lower loop_iter have finished
        for job_spec in self.all_job_specs:
            if job_spec.context and job_spec.context.loop_iter < current_loop_iter:
                if job_spec not in completed_job_specs:
                    # Found a job with lower loop_iter that hasn't finished yet
                    return False

        # All jobs with lower loop_iter have finished
        log_with_contract(
            "Sanity",
            "info",
            completed_result.job_spec.contract_name,
            f"Found optimal solution with loop_iter={current_loop_iter}. "
            f"All lower loop_iter jobs have finished and sanity checks passed. Triggering early termination.",
        )
        return True


class SanityPhase:
    """
    Two-stage sanity phase with parallel bound optimization.

    Stage 1: Find minimum loop_iter with large hashing bounds (parallel)
    Stage 2: Use optimal loop_iter for precise hashing bound detection
    """

    def __init__(
        self,
        contract_name: str,
        config_file: Path,
        prover_runner: ProverRunner,
        config_manager: ConfigManager,
        orchestration_timestamp: str,
        extra_args: Optional[List[str]] = None,
    ):
        """
        Initialize sanity phase.

        Args:
            contract_name: Name of the contract being processed
            config_file: Path to the configuration file to optimize
            prover_runner: Runner for prover execution (local or cloud)
            config_manager: Configuration manager for handling .conf files
            extra_args: Optional extra arguments to pass to prover
            orchestration_timestamp: Timestamp for job msg (format: YYYYMMDD_HHMMSS)
        """
        self.contract_name = contract_name
        self.config_file = config_file
        self.prover_runner = prover_runner
        self.config_manager = config_manager
        self.extra_args = extra_args or []
        self.orchestration_timestamp = orchestration_timestamp

        # Use very large hashing bound for stage 1 (sufficient for most cases)
        self.LARGE_HASHING_BOUND = 1024

    def _build_job_msg(self, conf_file: Path) -> Optional[str]:
        """Build the msg string for a prover job.

        Format: "Patrol <timestamp> <ContractName>: <conf_name>"
        Returns None if no orchestration_timestamp is set.
        """
        return ProverJobSpec.build_job_msg(self.orchestration_timestamp, self.contract_name, conf_file)

    def log(self, level: str, message: str):
        """Simple contract logging utility."""
        log_with_contract("Sanity", level, self.contract_name, message)

    async def execute(self) -> None:
        """
        Execute the two-stage sanity optimization process.

        The resultant loop_iter and hashing_bound values are written to self.config_file
        """
        self.log("info", "Starting two-stage sanity optimization")
        start_time = time.time()

        # Stage 1: Find optimal loop_iter with large hashing bounds
        self.log("info", "Stage 1: Finding optimal loop_iter")
        optimal_loop_iter = await self._find_optimal_loop_iter()

        if optimal_loop_iter is None:
            duration = time.time() - start_time
            self.log("error", f"Stage 1 failed - no sufficient loop_iter found. Duration: {duration}")
            return

        self.log("info", f"Stage 1 completed: optimal loop_iter = {optimal_loop_iter}")

        # Stage 2: Detect precise hashing bounds using optimal loop_iter
        self.log(
            "info",
            f"Stage 2: Detecting hashing bounds with loop_iter={optimal_loop_iter}",
        )

        optimal_hashing_bound = await self._detect_optimal_hashing_bounds()

        # If we failed to detect an optimal hashing bound with the prover auto
        # detection mode, we use the self.LARGE_HASHING_BOUND instead
        if optimal_hashing_bound is None:
            optimal_hashing_bound = self.LARGE_HASHING_BOUND

        self.config_manager.update_config_with_properties(
            self.config_file, {
                "hashing_length_bound": optimal_hashing_bound, 
                "optimistic_hashing": True # always enabled for now
                }
        )

        duration = time.time() - start_time

        self.log(
            "info",
            f"Two-stage sanity optimization completed in {duration:.1f}s - "
            f"loop_iter={optimal_loop_iter}, hashing_bound={optimal_hashing_bound}",
        )

    async def _find_optimal_loop_iter(self) -> Optional[int]:
        """
        Stage 1: Find the minimum sufficient loop_iter using large hashing bounds.

        Tests multiple loop_iter values in parallel with very large hashing bounds
        to ensure hashing is not the limiting factor.

        Args:
            state: Contract state

        Returns:
            Minimum sufficient loop_iter, or None if none work
        """
        self.log("debug", "Testing loop_iter values in parallel")

        # Generate loop_iter configurations to test in parallel
        loop_iter_configs = []
        loop_iter_values = range(1,5)

        for loop_iter in loop_iter_values:
            config = BoundConfiguration(
                loop_iter=loop_iter,
                hashing_bound=self.LARGE_HASHING_BOUND,  # Large enough to not be limiting
                optimistic_hashing=True,
                optimistic_loop=True,
            )
            loop_iter_configs.append(config)

        self.log(
            "info",
            f"Testing {len(loop_iter_configs)} loop_iter configurations in parallel "
            f"with hashing_bound={self.LARGE_HASHING_BOUND}",
        )

        # Test all configurations in parallel
        test_results = await self._test_configurations(
            loop_iter_configs, "loop_iter_optimization"
        )

        successful_results = [r for r in test_results if r.success]

        if successful_results:
            # Return minimum loop_iter that succeeded
            optimal_result = min(successful_results, key=lambda r: r.config.loop_iter)
            optimal_loop_iter = optimal_result.config.loop_iter

            self.log(
                "info",
                f"Found optimal loop_iter = {optimal_loop_iter} "
                f"(tested {len(successful_results)}/{len(test_results)} successful)",
            )

            # Apply the optimal configuration to the main config immediately
            self._apply_loop_iter_and_flags_to_main_config(optimal_loop_iter)
            return optimal_loop_iter

        # No successful results - analyze failures for potential fixes
        self.log("warning", "No successful loop_iter configurations found")

        best_effort_loop_iter = self._select_best_effort_configuration(test_results)

        if best_effort_loop_iter:
            # Apply best-effort configuration to main config
            self._apply_loop_iter_and_flags_to_main_config(best_effort_loop_iter)

        return best_effort_loop_iter

    def _apply_loop_iter_and_flags_to_main_config(self, loop_iter: int) -> None:
        """
        Apply the optimal loop_iter to the main config immediately.

        Args:
            loop_iter: Optimal loop_iter to apply
        """
        try:
            # Create config properties to apply
            config_properties = {
                "loop_iter": loop_iter,
                "optimistic_loop": True,  # TODO: either never touch it or pass it to the function
            }

            # Update the main config file
            self.config_manager.update_config_with_properties(
                self.config_file, config_properties
            )

            self.log("info", f"Applied loop_iter={loop_iter} to main config")

        except Exception as e:
            self.log("error", f"Failed to apply configuration to main config: {e}")

    async def _detect_optimal_hashing_bounds(self) -> Optional[int]:
        """
        Stage 2: Detect precise hashing bounds using the optimal loop_iter.

        Now that we have sufficient loop unrolling, we can accurately detect
        the minimum required hashing bounds.

        Returns:
            Maximum of the detected hashing bounds, or None if none found
        """
        self.log("info", "Detecting hashing bounds")

        try:
            # hashingBoundDetection is a prover arg
            detection_args = {"hashingBoundDetection": "true"}

            bound_detection_config = self.config_manager.create_copy_with_prover_args(
                self.config_file, detection_args, "_bound_detection"
            )

            # Submit bound detection job
            job_spec: ProverJobSpec = ProverJobSpec(
                contract_name=self.contract_name,
                phase="hashing_bound_detection",
                config_file=bound_detection_config,
                extra_args=self.extra_args,
                msg=self._build_job_msg(bound_detection_config.path),
            )

            result = await self.prover_runner.check_with_prover(job_spec)

            if result.success and result.job_handle and result.job_handle.job_id:
                # Analyze hashing bounds from the alert_report field in ProverResult
                max_bound = self._analyze_hashing_bounds_from_result(result)

                if max_bound:
                    return max_bound
                else:
                    self.log(
                        "info",
                        "No specific hashing bounds detected",
                    )
                    return None
            else:
                self.log(
                    "warning", f"Hashing bound detection failed: {result.error_message}"
                )
                return None

        except Exception as e:
            self.log("error", f"Hashing bound detection failed: {e}")
            return None

    def _analyze_hashing_bounds_from_result(
        self, result: ProverResult
    ) -> Optional[int]:
        """
        Comprehensive hashing bound detection from ProverResult.

        Analyzes all methods to determine:
        1. Which methods use hashing (have hashing_bound_assert_* subrules)
        2. Which methods have successful bound detection (alert messages)
        3. Which methods have failed bound detection (subrules verified but no alert)

        Args:
            result: ProverResult containing rule results and alert report

        Returns:
            Maximum detected bound, or None if no bounds found
        """
        try:
            job_id = result.job_handle.job_id
            self.log("debug", f"Analyzing hashing bounds for job: {job_id}")

            # Get all checks from the result
            all_checks = result.rule_results

            # Get alert report from the result
            alert_report = result.alert_report

            # Find all sanity rule checks
            # TODO: we assume that there there exist a rule called sanity (currently
            # we create it in the base config's spec). Might be better to check
            # within the sanity phase that the rule actually exist, and also to
            # run only this rule.
            sanity_checks = [c for c in all_checks if c.rule_name == "sanity"]

            # Group by method
            methods_with_hashing: Dict[str, List] = {}

            for check in sanity_checks:
                method_name = check.method
                # TODO: "unknown_method" might be claude hallucinating?
                if not method_name or method_name == "unknown_method":
                    continue

                # Check if this is a hashing bound assertion subrule
                if (
                    check.assert_message
                    and "hashing_bound_assert_" in check.assert_message
                ):
                    if method_name not in methods_with_hashing:
                        methods_with_hashing[method_name] = []
                    methods_with_hashing[method_name].append(check)

            # Parse alert messages to find successful bound detections
            successful_bounds = {}
            pattern = r"The suggested minimal hashing bound for (.+?) is (\d+)"

            if isinstance(alert_report, list):
                for alert in alert_report:
                    if isinstance(alert, dict) and "message" in alert:
                        matches = re.findall(pattern, alert["message"])
                        for method_match, bound_match in matches:
                            try:
                                bound = int(bound_match)
                                bound = min(bound, self.LARGE_HASHING_BOUND)
                                successful_bounds[method_match] = bound
                            except ValueError:
                                continue

            # Analyze results
            self.log(
                "info",
                f"Hashing bound detection analysis:\n"
                f"  Methods with hashing: {len(methods_with_hashing)}\n"
                f"  Successful bound detections: {len(successful_bounds)}",
            )

            # Collect methods that failed bound detection
            failed_methods = []
            for method_name, hashing_checks in methods_with_hashing.items():
                if method_name not in successful_bounds:
                    failed_methods.append(method_name)

            # Issue warnings for failed methods
            if failed_methods:
                self.log(
                    "warning",
                    f"Failed to detect hashing bounds for {len(failed_methods)} methods: {failed_methods}. "
                    "Consider manually setting hashing_length_bound or investigating the methods.",
                )

            # Return the maximum bound found, or None if no bounds detected
            if successful_bounds:
                max_bound = max(successful_bounds.values())
                detected_methods = list(successful_bounds.keys())
                self.log(
                    "info",
                    f"Using maximum detected bound: {max_bound} (from methods: {detected_methods})",
                )
                return max_bound
            else:
                self.log(
                    "info",
                    "No hashing bounds detected - will use predefined bound",
                )
                return None

        except Exception as e:
            self.log("error", f"Failed to analyze hashing bounds from result: {e}")
            return None

    async def _test_configurations(
        self, configs: List[BoundConfiguration], stage: str
    ) -> List[SanityTestResult]:
        """
        Test all bound configurations in parallel using prover_runner.submit_and_wait_for_jobs.

        Args:
            configs: List of bound configurations to test
            stage: Stage identifier for logging/naming
            additional_flags: Optional additional config properties to apply

        Returns:
            List of test results
        """

        self.log(
            "debug",
            f"Testing {len(configs)} configurations in parallel for {self.contract_name} ({stage}).",
        )

        # Create job specifications for all configurations
        job_specs = []
        for i, config in enumerate(configs):
            config_id = f"{stage}_{i}"

            # Create configuration with specific bounds and optional additional flags
            base_config = self.config_file
            config_properties = config.get_config_properties()

            test_config = self.config_manager.create_copy_with_config_properties(
                base_config, config_properties, f"_sanity_{config_id}"
            )

            # Create job specification with context
            job_spec = ProverJobSpec(
                contract_name=self.contract_name,
                phase=f"sanity_{config_id}",
                config_file=test_config,
                extra_args=self.extra_args,
                context=config,  # Store BoundConfiguration as context
                msg=self._build_job_msg(test_config.path),
            )
            job_specs.append(job_spec)

        # Create early termination callback and transformer
        early_termination_callback = SanityEarlyTerminationCallback(job_specs)
        sanity_transformer = self.create_sanity_transformer()

        try:
            # Submit all jobs and wait for completion using prover runner with early termination and transformer
            results = (
                await self.prover_runner.submit_and_wait_for_jobs_with_transformer(
                    job_specs,
                    early_termination_callback=early_termination_callback,
                    result_transformer=sanity_transformer,
                )
            )

            # Extract sanity test results from results
            sanity_results: List[SanityTestResult] = []
            for result in results:
                try:
                    # Skip cancelled results
                    if (
                        result.job_handle
                        and result.job_handle.status
                        == JobStatus.CANCELLED
                    ):
                        continue

                    # Ensure transformed_result exists and is of correct type
                    if result.transformed_result is not None:
                        sanity_results.append(result.transformed_result)
                except Exception as e:
                    self.log(
                        "error",
                        f"Failed to process result for {result.job_spec.contract_name}: {e}",
                    )
                    continue

        finally:
            # Clean up temporary config files
            for job_spec in job_specs:
                try:
                    job_spec.config_file.path.unlink()
                    self.log(
                        "debug",
                        f"Cleaned up temporary config: {job_spec.config_file.path}",
                    )
                except Exception as e:
                    self.log(
                        "warning",
                        f"Failed to cleanup temporary config {job_spec.config_file.path}: {e}",
                    )

        success_count = len([r for r in sanity_results if r.success])
        self.log(
            "info",
            f"Parallel testing completed ({stage}): {success_count}/{len(sanity_results)} configurations succeeded",
        )
        return sanity_results

    def _select_best_effort_configuration(
        self, test_results: List[SanityTestResult]
    ) -> Optional[int]:
        """
        Select the best configuration from failed results based on:
        1. Primary: Configuration that solved the most sanity checks
        2. Secondary: Configuration with the lowest loop_iter

        Args:
            test_results: List of test results (all failed)

        Returns:
            Best-effort loop_iter, or None if no useful results
        """
        if not test_results:
            return None

        # Score each configuration based on sanity analysis
        scored_results = []
        for result in test_results:
            if result.sanity_analysis:
                # Score = methods passed (higher is better)
                score = len(result.sanity_analysis.methods_passed)
                scored_results.append((score, result))

        if not scored_results:
            # No sanity analysis available, just pick lowest loop_iter
            self.log(
                "warning",
                "No sanity analysis available for best-effort selection, choosing lowest loop_iter",
            )
            best_result = min(test_results, key=lambda r: r.config.loop_iter)
            return best_result.config.loop_iter

        # Sort by score (descending), then by loop_iter (ascending)
        scored_results.sort(key=lambda x: (-x[0], x[1].config.loop_iter))

        best_score, best_result = scored_results[0]
        best_loop_iter = best_result.config.loop_iter

        self.log(
            "info",
            f"Best-effort configuration selected: loop_iter={best_loop_iter}, "
            f"sanity_score={best_score}/{best_result.sanity_analysis.total_methods if best_result.sanity_analysis else 0}",
        )

        return best_loop_iter

    def create_sanity_transformer(self):
        """Create a transformer function for converting ProverResult to SanityTestResult."""

        def transform_prover_result_to_sanity_result(
            prover_result: ProverResult
        ) -> SanityTestResult:
            """Transform ProverResult to SanityTestResult using SanityPhase logic."""
            if prover_result.job_spec.context is None:
                raise ValueError("Job spec context is None")
            return self._convert_prover_result_to_sanity_result(
                prover_result, prover_result.job_spec.context, prover_result.job_spec.phase  # type: ignore[arg-type]
            )

        return transform_prover_result_to_sanity_result

    def _convert_prover_result_to_sanity_result(
        self, prover_result: ProverResult, config: BoundConfiguration, phase: str
    ) -> SanityTestResult:
        """
        Convert a ProverResult to a SanityTestResult.

        Args:
            prover_result: ProverResult from the prover execution
            config: BoundConfiguration that was tested
            phase: Phase identifier

        Returns:
            SanityTestResult with analysis
        """
        start_time = time.time()

        try:
            # Parse rule results using ProverRunner
            job_id = (
                prover_result.job_handle.job_id if prover_result.job_handle else None
            )
            rule_results = (
                self.prover_runner.parse_rule_results_from_job(job_id) if job_id else []
            )

            # Analyze sanity results
            sanity_analysis = self.analyze_sanity_results(rule_results, config)

            # Determine result type
            if prover_result.success and sanity_analysis.sanity_passed:
                sanity_result = SanityResult.SUCCESS
            elif prover_result.success:
                sanity_result = SanityResult.SANITY_FAIL
            elif "timeout" in (prover_result.error_message or "").lower():
                sanity_result = SanityResult.TIMEOUT
            elif "memory" in (prover_result.error_message or "").lower():
                sanity_result = SanityResult.MEMOUT
            else:
                sanity_result = SanityResult.UNKNOWN_FAIL

            duration = prover_result.duration or (time.time() - start_time)

            return SanityTestResult(
                config=config,
                result=sanity_result,
                duration=duration,
                report_path=prover_result.report_path,
                sanity_analysis=sanity_analysis,
            )

        except Exception as e:
            self.log("error", f"Failed to convert prover result: {e}")
            duration = time.time() - start_time

            return SanityTestResult(
                config=config,
                result=SanityResult.UNKNOWN_FAIL,
                duration=duration,
                report_path=None,
            )

    def analyze_sanity_results(
        self, rule_results: List[RuleResult], config: BoundConfiguration
    ) -> SanityAnalysis:
        """
        Analyze rule results to extract sanity-specific information.

        Args:
            rule_results: List of RuleResult objects
            config: BoundConfiguration being tested (for logging context)

        Returns:
            SanityAnalysis object with sanity-specific results
        """

        methods_passed = []
        methods_failed = []
        sanity_methods = set()

        for rule in rule_results:
            # Check if this is our custom sanity rule based on rule name and
            # assert message
            # TODO: we assume, there there exist a rule called sanity (currently
            # we create it in the base config's spec). Might be better to check
            # within the sanity phase that the rule actually exist, and also to
            # run only this rule.
            is_our_sanity_rule = (
                rule.rule_name == "sanity"
                and rule.assert_message is not None
                and "Satisfy_sanity_check_failed" in rule.assert_message
            )

            if is_our_sanity_rule and rule.method:
                if rule.method in sanity_methods:
                    self.log(
                        "warning",
                        f"Found multiple sanity rules for method {rule.method}, expected exactly 1",
                    )

                sanity_methods.add(rule.method)

                if rule.passed:
                    methods_passed.append(rule.method)
                elif NotificationType.ONLY_REVERTING_PATHS in rule.notifications:
                    methods_passed.append(rule.method)
                else:
                    methods_failed.append(rule.method)

        analysis = SanityAnalysis(
            methods_passed=methods_passed,
            methods_failed=methods_failed,
            total_methods=len(sanity_methods),
            sanity_passed=len(methods_failed) == 0,
        )

        self.log("info", f"Sanity analysis: {analysis.summary}")
        return analysis
