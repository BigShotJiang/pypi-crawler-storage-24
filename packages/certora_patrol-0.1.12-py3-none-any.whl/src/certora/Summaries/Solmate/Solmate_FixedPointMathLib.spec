import "../Math.spec";

methods {
    function FixedPointMathLib.mulDivDown(uint256 x, uint256 y, uint256 denominator) internal returns (uint256) => mulDivDownSummary(x,y,denominator);
    function FixedPointMathLib.mulDivUp(uint256 x, uint256 y, uint256 denominator) internal returns (uint256) => mulDivUpSummary(x,y,denominator);
    function FixedPointMathLib.sqrt(uint256 x) internal returns (uint256) => sqrtSummary(x);
    // TODO: add rpow and other functions
}