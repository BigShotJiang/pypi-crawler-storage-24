import os


def get_default_rag_db() -> str:
    """Return the default RAG database path.

    Priority: CERTORA_RAG_DB env var > bundled ChromaDB from analyzer package > PostgreSQL fallback.
    """
    env_val = os.environ.get("CERTORA_RAG_DB")
    if env_val:
        return env_val
    try:
        from analyzer.rag_data import get_path

        return str(get_path())
    except ImportError:
        return "postgresql://localhost/cvl_docs"
