#!/usr/bin/env python3
"""
LLM Utility Functions

This module provides utility functions for making LLM API calls,
useful for testing and standalone prompting.
"""

import os
import sys
import time
import logging
import logging.handlers
from pydantic import BaseModel, ValidationError
from dataclasses import dataclass
from pathlib import Path
from datetime import datetime
from typing import Any, Callable, Optional, overload, Literal, Generator, TypeVar, cast

from src.utils.constants import ANTHROPIC_API_KEY_ENV

# Try to load .env file for API keys
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # dotenv not available, will use environment variables directly

# Optional imports for LLM functionality
try:
    import anthropic
    import anthropic.types
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False

MODEL_SONNET = "claude-sonnet-4-5-20250929"

# Cache for Anthropic clients to avoid recreating them
_client_cache = {}

@overload
def _get_cached_client(api_key: str) -> Optional['anthropic.Anthropic']:
    ...

@overload
def _get_cached_client(api_key: str, async_client: Literal[True]) -> Optional["anthropic.AsyncAnthropic"]:
    ...

def _get_cached_client(api_key: str, async_client: Literal[True] | None = None) -> Optional['anthropic.Anthropic'] | Optional["anthropic.AsyncAnthropic"]:
    """Get or create a cached Anthropic client for the given API key."""
    if not ANTHROPIC_AVAILABLE:
        return None

    # Use a hash of the API key as the cache key for security
    import hashlib
    is_async = async_client is not None
    cache_key = hashlib.sha256((api_key + ("async" if is_async else "")).encode()).hexdigest()[:16]

    if cache_key not in _client_cache:
        try:
            if is_async:
                _client_cache[cache_key] = anthropic.AsyncAnthropic(api_key=api_key)
            else:
                _client_cache[cache_key] = anthropic.Anthropic(api_key=api_key)
        except Exception:
            return None

    return _client_cache[cache_key]


def clear_client_cache():
    """Clear the Anthropic client cache. Useful for testing or when API keys change."""
    global _client_cache
    _client_cache.clear()

@dataclass
class LLMCall:
    model: str
    max_tokens: int
    temperature: float
    messages: list["anthropic.types.MessageParam"]
    system: list["anthropic.types.TextBlockParam"] | None = None

T = TypeVar("T")


def _setup_file_logger(log_path: Optional[str]) -> logging.Logger:
    """Configure and return a rotating file logger for LLM calls."""
    log_path_final = Path(log_path) if log_path else Path(".certora_internal/llm_util.log")
    log_path_final.parent.mkdir(parents=True, exist_ok=True)

    logger = logging.getLogger('llm_util')
    logger.setLevel(logging.INFO)

    for h in logger.handlers[:]:
        logger.removeHandler(h)

    handler = logging.handlers.RotatingFileHandler(
        filename=str(log_path_final),
        maxBytes=20 * 1024 * 1024,  # 20MB
        backupCount=1,
        encoding='utf-8',
    )
    handler.setLevel(logging.INFO)
    handler.setFormatter(logging.Formatter('%(message)s'))
    logger.addHandler(handler)
    logger.propagate = False
    return logger


def _call_llm_pure(
    prompt: str,
    model: str,
    max_tokens: int,
    temperature: float,
    max_retries: int,
    log_to_file: bool,
    log_path: Optional[str],
    verbose: bool,
    system_prompt: Optional[str] = None,
) -> Generator[LLMCall, T, Optional[T]]:
    """Generator that yields LLMCall requests and receives responses.

    When *system_prompt* is provided the prompt is sent with cache_control=ephemeral
    and the user text is wrapped in a content block (used by the cached-prompt path).
    """
    if not ANTHROPIC_AVAILABLE:
        if verbose:
            print("Error: Anthropic library not available. Install with: pip install anthropic")
        return None

    logger: Optional[logging.Logger] = None
    if log_to_file:
        logger = _setup_file_logger(log_path)
        log_entry = f"\n{'='*80}\n"
        log_entry += f"Timestamp: {datetime.now().isoformat()}\n"
        log_entry += f"Model: {model}\n"
        log_entry += f"Max Tokens: {max_tokens}\n"
        log_entry += f"Temperature: {temperature}\n"
        if system_prompt is not None:
            log_entry += f"System Prompt:\n{system_prompt}\n"
            log_entry += f"User Prompt:\n{prompt}\n"
        else:
            log_entry += f"Prompt:\n{prompt}\n"
        logger.info(log_entry)

    if system_prompt is not None:
        system: list[anthropic.types.TextBlockParam] | None = [
            cast(
                "anthropic.types.TextBlockParam",
                {"type": "text", "text": system_prompt, "cache_control": {"type": "ephemeral"}},
            )
        ]
        messages: list[anthropic.types.MessageParam] = [
            {"role": "user", "content": [{"type": "text", "text": prompt}]}
        ]
    else:
        system = None
        messages = cast(list[anthropic.types.MessageParam], [{"role": "user", "content": prompt}])

    for attempt in range(max_retries):
        try:
            if verbose and attempt > 0:
                print(f"Retry attempt {attempt + 1}/{max_retries}...")

            response = yield LLMCall(
                model=model,
                max_tokens=max_tokens,
                temperature=temperature,
                messages=messages,
                system=system,
            )

            if logger is not None:
                logger.info(f"Response:\n{response}\n{'='*80}\n")

            if verbose:
                print(f"✅ LLM call successful")

            return response

        except anthropic.RateLimitError as e:
            if verbose:
                print(f"Rate limit hit: {e}")
            if attempt < max_retries - 1:
                wait_time = 2 ** attempt
                if verbose:
                    print(f"Waiting {wait_time} seconds before retry...")
                time.sleep(wait_time)
            else:
                if verbose:
                    print("Max retries reached")
                if logger is not None:
                    logger.error(f"Error: Rate limit after {max_retries} attempts\n{'='*80}\n")
                return None

        except Exception as e:
            if verbose:
                print(f"Error calling LLM: {e}")
            if logger is not None:
                logger.error(f"Error: {e}\n{'='*80}\n")
            return None

    return None

def _load_anthropic_key(verbose: bool, api_key: Optional[str]) -> Optional[str]:
    if not ANTHROPIC_AVAILABLE:
        if verbose:
            print("Error: Anthropic library not available. Install with: pip install anthropic")
        return None

    if not api_key:
        api_key = os.getenv(ANTHROPIC_API_KEY_ENV)

    if not api_key:
        if verbose:
            print(f"Error: No API key provided and {ANTHROPIC_API_KEY_ENV} environment variable not set")
        return None
    return api_key


@overload
def _init_client(verbose: bool, api_key: Optional[str]) -> Optional["anthropic.Anthropic"]: ...
@overload
def _init_client(
    verbose: bool, api_key: Optional[str], *, raise_on_failure: Literal[True]
) -> "anthropic.Anthropic": ...

def _init_client(
    verbose: bool, api_key: Optional[str], *, raise_on_failure: bool = False
) -> Optional["anthropic.Anthropic"]:
    """Load API key, return a cached sync client. Raises or returns None on failure."""
    loaded_key = _load_anthropic_key(verbose, api_key)
    if loaded_key is None:
        if raise_on_failure:
            raise RuntimeError(f"{ANTHROPIC_API_KEY_ENV} environment variable not set")
        return None
    client = _get_cached_client(loaded_key)
    if client is None:
        if raise_on_failure:
            raise RuntimeError("Failed to initialize Anthropic client")
        if verbose:
            print("Error: Failed to initialize Anthropic client")
    return client


def _init_async_client(verbose: bool, api_key: Optional[str]) -> Optional["anthropic.AsyncAnthropic"]:
    """Load API key, return a cached async client. Returns None on failure."""
    loaded_key = _load_anthropic_key(verbose, api_key)
    if loaded_key is None:
        if verbose:
            print("Failed to load Anthropic API key")
        return None
    client = _get_cached_client(loaded_key, async_client=True)
    if client is None and verbose:
        print("Error: Failed to initialize Anthropic client")
    return client


M = TypeVar("M", bound=BaseModel)


def _tool_use_params(output_type: type[BaseModel]) -> dict:
    """Return the tools + tool_choice kwargs for forced structured output."""
    return {
        "tools": [{
            "name": "output",
            "description": output_type.__doc__ or "Provide your output in structured format",
            "input_schema": output_type.model_json_schema(),
        }],
        "tool_choice": {"type": "tool", "name": "output"},
    }


def _parse_tool_use_block(response: "anthropic.types.Message", output_type: type[M]) -> M:
    """Extract the ToolUseBlock from a forced-tool-use response and validate it."""
    if not isinstance(response.content, list):
        raise ValueError("Expected list response from Claude")
    last = response.content[-1]
    if not isinstance(last, anthropic.types.ToolUseBlock):
        raise ValueError("Forced tool calling did not produce ToolUseBlock")
    return output_type.model_validate(last.input)


def _retry_transient(
    api_call: Callable[[], "anthropic.types.Message"],
    max_retries: int,
    verbose: bool,
) -> "anthropic.types.Message":
    """Call *api_call* with retries on transient API errors. Raises on fatal errors."""
    last_exception: Optional[Exception] = None
    for attempt in range(max_retries):
        try:
            return api_call()
        except (anthropic.AuthenticationError, anthropic.PermissionDeniedError):
            raise
        except (anthropic.RateLimitError, anthropic.APIConnectionError, anthropic.InternalServerError) as e:
            last_exception = e
            if verbose:
                print(f"Transient API error (attempt {attempt + 1}/{max_retries}): {e}")
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt)
        except anthropic.APIStatusError as e:
            if e.status_code == 529:
                last_exception = e
                if verbose:
                    print(f"API overloaded (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)
            else:
                raise
    raise last_exception  # type: ignore[misc]


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def call_llm_structured(
    prompt: str,
    ty: type[M],
    model: str = MODEL_SONNET,
    max_tokens: int = 1000,
    temperature: float = 0.0,
    max_retries: int = 10,
    log_to_file: bool = True,
    log_path: Optional[str] = None,
    api_key: Optional[str] = None,
    verbose: bool = False,
) -> Optional[M]:
    client = _init_client(verbose, api_key)
    if client is None:
        return None

    gen: Generator[LLMCall, M, Optional[M]] = _call_llm_pure(
        prompt, model, max_tokens, temperature, max_retries, log_to_file, log_path, verbose
    )
    try:
        msg = next(gen)
        while True:
            try:
                response = client.messages.create(
                    model=msg.model,
                    max_tokens=msg.max_tokens,
                    messages=msg.messages,
                    temperature=msg.temperature,
                    **_tool_use_params(ty),
                )
                msg = gen.send(_parse_tool_use_block(response, ty))
            except Exception as e:
                msg = gen.throw(e)
    except StopIteration as e:
        return e.value


def call_llm(
    prompt: str,
    model: str = MODEL_SONNET,
    max_tokens: int = 1000,
    temperature: float = 0.0,
    max_retries: int = 10,
    log_to_file: bool = True,
    log_path: Optional[str] = None,
    api_key: Optional[str] = None,
    verbose: bool = False,
) -> Optional[str]:
    """
    Make a call to the LLM API with the given prompt.

    Args:
        prompt: The prompt to send to the LLM
        model: The model to use (default: latest Claude Sonnet)
        max_tokens: Maximum tokens in response
        temperature: Temperature for response generation (0.0 = deterministic)
        max_retries: Number of retries for rate limiting
        log_to_file: Whether to log to a file
        log_path: Path to log file (default: .certora_internal/llm_util.log)
        api_key: API key (if not provided, uses ANTHROPIC_API_KEY env var)
        verbose: Whether to print verbose output

    Returns:
        The LLM response text, or None if failed

    Example:
        >>> from utils.llm_util import call_llm
        >>> response = call_llm("What is 2+2?")
        >>> print(response)
        4
    """
    client = _init_client(verbose, api_key)
    if client is None:
        return None

    gen: Generator[LLMCall, str, Optional[str]] = _call_llm_pure(
        prompt, model, max_tokens, temperature, max_retries, log_to_file, log_path, verbose
    )
    try:
        msg = next(gen)
        while True:
            try:
                response = client.messages.create(
                    model=msg.model,
                    max_tokens=msg.max_tokens,
                    messages=msg.messages,
                    temperature=msg.temperature,
                )
                content_block = response.content[0]
                if hasattr(content_block, 'text'):
                    answer = content_block.text.strip()  # type: ignore[union-attr]
                else:
                    answer = str(content_block)
                msg = gen.send(answer)
            except Exception as e:
                msg = gen.throw(e)
    except StopIteration as e:
        return e.value


async def call_llm_async_structured_cached(
    system_prompt: str,
    user_prompt: str,
    ty: type[M],
    model: str = MODEL_SONNET,
    max_tokens: int = 1000,
    temperature: float = 0.0,
    max_retries: int = 10,
    log_to_file: bool = True,
    log_path: Optional[str] = None,
    api_key: Optional[str] = None,
    verbose: bool = False,
) -> Optional[M]:
    """Like call_llm_async_structured but with a separate system prompt that gets cache_control."""
    client = _init_async_client(verbose, api_key)
    if client is None:
        return None

    gen: Generator[LLMCall, M, Optional[M]] = _call_llm_pure(
        user_prompt, model, max_tokens, temperature, max_retries, log_to_file, log_path, verbose,
        system_prompt=system_prompt,
    )
    try:
        msg = next(gen)
        while True:
            try:
                create_kwargs: dict[str, Any] = {
                    "model": msg.model,
                    "max_tokens": msg.max_tokens,
                    "messages": msg.messages,
                    "temperature": msg.temperature,
                    **_tool_use_params(ty),
                }
                if msg.system is not None:
                    create_kwargs["system"] = msg.system
                response = await client.messages.create(**create_kwargs)  # type: ignore[arg-type]
                if log_to_file:
                    usage = response.usage
                    cache_creation = getattr(usage, 'cache_creation_input_tokens', 0) or 0
                    cache_read = getattr(usage, 'cache_read_input_tokens', 0) or 0
                    logging.getLogger('llm_util').info(
                        f"Usage: input_tokens={usage.input_tokens}, output_tokens={usage.output_tokens}, "
                        f"cache_creation_input_tokens={cache_creation}, cache_read_input_tokens={cache_read}"
                    )
                msg = gen.send(_parse_tool_use_block(response, ty))
            except Exception as e:
                msg = gen.throw(e)
    except StopIteration as e:
        return e.value


def call_llm_messages_structured(
    system: list["anthropic.types.TextBlockParam"],
    messages: list["anthropic.types.MessageParam"],
    output_type: type[M],
    model: str = MODEL_SONNET,
    max_tokens: int = 4096,
    temperature: float = 0.0,
    max_retries: int = 3,
    max_validation_retries: int = 2,
    on_api_response: Optional[Callable[["anthropic.types.Message"], None]] = None,
    api_key: Optional[str] = None,
    verbose: bool = False,
) -> M:
    """Call Claude with pre-built system/messages, forced tool use, and validation retry.

    On Pydantic ValidationError, feeds the error back to the LLM as a tool_result(is_error=True)
    and retries, giving the model a chance to self-correct.

    Args:
        system: Pre-built system content blocks (with cache_control as needed).
        messages: Pre-built message list.
        output_type: Pydantic model class for structured output.
        model: Claude model identifier.
        max_tokens: Maximum tokens in response.
        temperature: Sampling temperature.
        max_retries: Retries for transient API errors per validation attempt.
        max_validation_retries: How many times to retry on ValidationError.
        on_api_response: Callback invoked with every raw API response (for token tracking).
        api_key: Anthropic API key (falls back to env var).
        verbose: Print verbose output.

    Returns:
        Parsed Pydantic model instance.

    Raises:
        RuntimeError: If API key or client cannot be initialized.
        anthropic.AuthenticationError, anthropic.PermissionDeniedError: Fatal, raised immediately.
        Exception: Last transient error if all retries exhausted.
        ValidationError: If all validation retries exhausted.
    """
    client = _init_client(verbose, api_key, raise_on_failure=True)

    tool_params = _tool_use_params(output_type)
    conversation = list(messages)  # never mutate caller's list
    last_validation_error: Optional[ValidationError] = None

    for _validation_attempt in range(1 + max_validation_retries):
        response = _retry_transient(
            lambda: client.messages.create(  # type: ignore[arg-type]
                model=model,
                max_tokens=max_tokens,
                temperature=temperature,
                system=system,
                messages=conversation,
                **tool_params,
            ),
            max_retries,
            verbose,
        )
        if on_api_response is not None:
            on_api_response(response)

        try:
            return _parse_tool_use_block(response, output_type)
        except ValidationError as ve:
            last_validation_error = ve
            if verbose:
                print(f"Validation error, retrying: {ve}")
            last_block = response.content[-1]
            assert isinstance(last_block, anthropic.types.ToolUseBlock)
            conversation.append({"role": "assistant", "content": response.content})
            conversation.append({
                "role": "user",
                "content": [{
                    "type": "tool_result",
                    "tool_use_id": last_block.id,
                    "is_error": True,
                    "content": str(ve),
                }],
            })

    raise last_validation_error  # type: ignore[misc]


def call_llm_messages(
    system: list["anthropic.types.TextBlockParam"],
    messages: list["anthropic.types.MessageParam"],
    model: str = MODEL_SONNET,
    max_tokens: int = 4096,
    temperature: float = 0.0,
    max_retries: int = 3,
    on_api_response: Optional[Callable[["anthropic.types.Message"], None]] = None,
    api_key: Optional[str] = None,
    verbose: bool = False,
) -> str:
    """Call Claude with pre-built system/messages and return plain text.

    Retries on transient API errors with exponential backoff.

    Args:
        system: Pre-built system content blocks (with cache_control as needed).
        messages: Pre-built message list.
        model: Claude model identifier.
        max_tokens: Maximum tokens in response.
        temperature: Sampling temperature.
        max_retries: Retries for transient API errors.
        on_api_response: Callback invoked with every raw API response (for token tracking).
        api_key: Anthropic API key (falls back to env var).
        verbose: Print verbose output.

    Returns:
        Text content from the first content block.

    Raises:
        RuntimeError: If API key or client cannot be initialized.
        anthropic.AuthenticationError, anthropic.PermissionDeniedError: Fatal, raised immediately.
        Exception: Last transient error if all retries exhausted.
    """
    client = _init_client(verbose, api_key, raise_on_failure=True)

    response = _retry_transient(
        lambda: client.messages.create(  # type: ignore[arg-type]
            model=model,
            max_tokens=max_tokens,
            temperature=temperature,
            system=system,
            messages=messages,
        ),
        max_retries,
        verbose,
    )
    if on_api_response is not None:
        on_api_response(response)

    content_block = response.content[0]
    if hasattr(content_block, "text"):
        return content_block.text.strip()  # type: ignore[union-attr]
    return str(content_block)


def test_llm_connection(api_key: Optional[str] = None, verbose: bool = True) -> bool:
    """
    Test if LLM connection is working.

    Args:
        api_key: API key (if not provided, uses ANTHROPIC_API_KEY env var)
        verbose: Whether to print output

    Returns:
        True if connection works, False otherwise
    """
    response = call_llm(
        "Reply with just 'OK' if you receive this message.",
        max_tokens=10,
        log_to_file=False,
        api_key=api_key,
        verbose=verbose
    )

    if response and "OK" in response:
        if verbose:
            print("✅ LLM connection test successful")
        return True
    else:
        if verbose:
            print("❌ LLM connection test failed")
        return False


def main():
    """Command-line interface for testing LLM calls."""
    import argparse

    parser = argparse.ArgumentParser(description="Test LLM API calls")
    parser.add_argument("prompt", nargs="?", help="Prompt to send to LLM")
    parser.add_argument("--model", default=MODEL_SONNET,
                        help="Model to use")
    parser.add_argument("--max-tokens", type=int, default=1000,
                        help="Maximum tokens in response")
    parser.add_argument("--temperature", type=float, default=0.0,
                        help="Temperature for response generation")
    parser.add_argument("--test", action="store_true",
                        help="Test LLM connection")
    parser.add_argument("--no-log", action="store_true",
                        help="Don't log to file")
    parser.add_argument("--log-path", help="Path to log file")
    parser.add_argument("-v", "--verbose", action="store_true",
                        help="Verbose output")

    args = parser.parse_args()

    if args.test:
        success = test_llm_connection(verbose=args.verbose)
        sys.exit(0 if success else 1)

    if not args.prompt:
        parser.print_help()
        sys.exit(1)

    response = call_llm(
        prompt=args.prompt,
        model=args.model,
        max_tokens=args.max_tokens,
        temperature=args.temperature,
        log_to_file=not args.no_log,
        log_path=args.log_path,
        verbose=args.verbose
    )

    if response:
        print(response)
    else:
        if not args.verbose:
            print("Error: LLM call failed. Use -v for details.", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
