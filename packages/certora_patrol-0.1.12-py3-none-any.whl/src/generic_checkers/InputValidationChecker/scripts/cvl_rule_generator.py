#!/usr/bin/env python3
"""
CVL Rule Generator for Input Validation Checker

This module generates CVL rules for testing input validation across different type categories.
"""

from typing import List, Optional, Set, Tuple
from src.parsers.type_analyzer import (
    MethodInfo, ParameterInfo, TypeInfo, StructInfo, ArrayInfo,
    TypeCategory, StructFieldInfo
)


class CVLRuleGenerator:
    """Generator for CVL input validation rules."""

    def __init__(self, loop_iter: int = 3, use_satisfy_mode: bool = False):
        """
        Initialize the rule generator.

        Args:
            loop_iter: Maximum loop iteration count from config (for array bounds)
            use_satisfy_mode: If True, use 'satisfy' for stronger checking (requires nondet control).
                            If False (default), use 'assert' for robustness to nondeterminism.
        """
        self.loop_iter = loop_iter
        self.use_satisfy_mode = use_satisfy_mode
        self.generated_rule_names: Set[str] = set()

    def _get_array_nesting_info(self, array_info: ArrayInfo) -> Tuple[int, TypeInfo]:
        """Get nesting depth and innermost element type for an array.

        Returns:
            (depth, innermost_type): depth=1 for T[], depth=2 for T[][], etc.
        """
        depth = 1
        current = array_info.element_type
        while isinstance(current, ArrayInfo):
            depth += 1
            current = current.element_type
        return depth, current

    def _generate_index_combinations(self, depth: int) -> List[Tuple[int, ...]]:
        """Generate all index combinations for nested arrays up to loop_iter at each level.

        For depth=1: [(0,), (1,), (2,)] (assuming loop_iter=3)
        For depth=2: [(0,0), (0,1), (0,2), (1,0), (1,1), (1,2), (2,0), (2,1), (2,2)]
        """
        if depth == 1:
            return [(i,) for i in range(self.loop_iter)]
        else:
            inner = self._generate_index_combinations(depth - 1)
            return [(i,) + combo for i in range(self.loop_iter) for combo in inner]

    def _generate_validation_check(self, inequality_expr: str) -> str:
        """
        Generate either assert or satisfy statement based on mode.

        Args:
            inequality_expr: The inequality expression (e.g., "input1 != input2")

        Returns:
            Complete assertion/satisfy statement with lastReverted check
        """
        if self.use_satisfy_mode:
            # Satisfy mode: find a case where different inputs cause revert
            # UNSAT means no validation (input doesn't affect behavior)
            return f"satisfy {inequality_expr} && lastReverted;"
        else:
            # Assert mode (default): check if different inputs must cause revert
            # Violation means function accepts multiple values (may be false positive for range validation)
            return f"assert {inequality_expr} => lastReverted;"

    def generate_rules_for_method(self, method: MethodInfo) -> List[str]:
        """
        Generate all input validation rules for a method.

        Args:
            method: Method information

        Returns:
            List of CVL rule strings
        """
        rules = []

        for param in method.parameters:
            param_rules = self._generate_rules_for_parameter(method, param)
            rules.extend(param_rules)

        return rules

    def _generate_rules_for_parameter(self, method: MethodInfo, param: ParameterInfo) -> List[str]:
        """Generate rules for a single parameter based on its type."""
        type_info = param.type_info

        if type_info.category == TypeCategory.PRIMITIVE:
            return [self._generate_primitive_rule(method, param)]

        elif type_info.category == TypeCategory.BYTES:
            return [self._generate_bytes_rule(method, param)]

        elif type_info.category == TypeCategory.STRING:
            return [self._generate_string_rule(method, param)]

        elif type_info.category == TypeCategory.ENUM:
            # Enums are treated as primitives (uint8)
            return [self._generate_primitive_rule(method, param)]

        elif type_info.category == TypeCategory.ARRAY:
            return self._generate_array_rules(method, param)

        elif type_info.category == TypeCategory.STRUCT:
            return self._generate_struct_rules(method, param)

        else:
            # Unsupported type (e.g., mapping)
            return []

    def _generate_primitive_rule(self, method: MethodInfo, param: ParameterInfo) -> str:
        """Generate rule for primitive type parameter."""
        rule_name = self._make_rule_name(method, param, "")
        type_str = param.type_info.cvl_name

        # Get other parameters
        other_params = [p for p in method.parameters if p.index != param.index]
        other_params_decl = self._generate_other_params_declarations(other_params)
        call_args = self._generate_call_arguments(method.parameters, param.index, "input1", "input2")

        rule = f"""
rule {rule_name}({type_str} input1, {type_str} input2) {{
    env e;
    storage initState = lastStorage;

{other_params_decl}
    {method.method_name}(e{call_args[0]});

    {method.method_name}@withrevert(e{call_args[1]}) at initState;

    // if the input affects the function's behavior, changing it should cause a revert
    {self._generate_validation_check("input1 != input2")}
}}
"""
        return rule

    def _generate_bytes_rule(self, method: MethodInfo, param: ParameterInfo) -> str:
        """Generate rule for bytes type parameter."""
        rule_name = self._make_rule_name(method, param, "")
        type_str = "bytes"

        other_params = [p for p in method.parameters if p.index != param.index]
        other_params_decl = self._generate_other_params_declarations(other_params)
        call_args = self._generate_call_arguments(method.parameters, param.index, "input1", "input2")

        rule = f"""
rule {rule_name}(bytes input1, bytes input2) {{
    env e;
    storage initState = lastStorage;

{other_params_decl}
    {method.method_name}(e{call_args[0]});

    {method.method_name}@withrevert(e{call_args[1]}) at initState;

    // if the input affects the function's behavior, changing it should cause a revert
    {self._generate_validation_check("keccak256(input1) != keccak256(input2)")}
}}
"""
        return rule

    def _generate_string_rule(self, method: MethodInfo, param: ParameterInfo) -> str:
        """Generate rule for string type parameter."""
        rule_name = self._make_rule_name(method, param, "")
        type_str = "string"

        other_params = [p for p in method.parameters if p.index != param.index]
        other_params_decl = self._generate_other_params_declarations(other_params)
        call_args = self._generate_call_arguments(method.parameters, param.index, "input1", "input2")

        rule = f"""
rule {rule_name}(string input1, string input2) {{
    env e;
    storage initState = lastStorage;

{other_params_decl}
    {method.method_name}(e{call_args[0]});

    {method.method_name}@withrevert(e{call_args[1]}) at initState;

    // if the input affects the function's behavior, changing it should cause a revert
    {self._generate_validation_check("keccak256(input1) != keccak256(input2)")}
}}
"""
        return rule

    def _generate_array_rules(self, method: MethodInfo, param: ParameterInfo) -> List[str]:
        """Generate two rules for array type parameter: length check and element check."""
        array_info = param.type_info
        if not isinstance(array_info, ArrayInfo):
            return []

        element_type = array_info.element_type

        # Handle nested arrays (e.g., T[][]) with dedicated method
        if isinstance(element_type, ArrayInfo):
            return self._generate_nested_array_rules(method, param)

        array_type_str = array_info.cvl_name

        rules = []

        # Rule 1: Length check
        rule_name_length = self._make_rule_name(method, param, "length")
        other_params = [p for p in method.parameters if p.index != param.index]
        other_params_decl = self._generate_other_params_declarations(other_params)
        call_args = self._generate_call_arguments(method.parameters, param.index, "array1", "array2")

        rule_length = f"""
rule {rule_name_length}() {{
    env e;
    storage initState = lastStorage;

{other_params_decl}
    {array_type_str} array1;
    {array_type_str} array2;

    {method.method_name}(e{call_args[0]});

    {method.method_name}@withrevert(e{call_args[1]}) at initState;

    // length change also means set of elements is different. Hence, we want to check a stronger statement:
    // Any change to the length must cause the function to revert.
    {self._generate_validation_check("array1.length != array2.length")}
}}
"""
        rules.append(rule_length)

        # Rule 2: Element check - special handling for arrays of structs
        if element_type.is_struct():
            # Arrays of structs require special handling with unrolled bounds
            struct_field_rules = self._generate_array_of_struct_rules(method, param)
            rules.extend(struct_field_rules)
        elif not element_type.category == TypeCategory.MAPPING:
            # Simple element check for primitives, bytes, string
            rule_name_element = self._make_rule_name(method, param, "element")

            # Generate equality/inequality based on element type
            if element_type.is_bytes_or_string():
                element_inequality = "keccak256(array1[index]) != keccak256(array2[index])"
                element_equality_fn = lambda i: f"keccak256(array1[{i}]) == keccak256(array2[{i}])"
            else:
                element_inequality = "array1[index] != array2[index]"
                element_equality_fn = lambda i: f"array1[{i}] == array2[{i}]"

            # Generate unrolled requires for other indices
            other_indices_requires = []
            for i in range(self.loop_iter):
                other_indices_requires.append(
                    f"    require index != {i} => {element_equality_fn(i)};"
                )
            other_indices_requires_str = "\n".join(other_indices_requires)

            rule_element = f"""
rule {rule_name_element}(uint256 index) {{
    env e;
    storage initState = lastStorage;

{other_params_decl}
    {array_type_str} array1;
    {array_type_str} array2;

    require array1.length == array2.length;
    require array1.length <= {self.loop_iter};
    require index < array1.length;

{other_indices_requires_str}

    {method.method_name}(e{call_args[0]});

    {method.method_name}@withrevert(e{call_args[1]}) at initState;

    // if changing this element affects behavior, it should cause a revert
    assert {element_inequality} => lastReverted;
}}
"""
            rules.append(rule_element)

        return rules

    def _generate_nested_array_rules(self, method: MethodInfo, param: ParameterInfo) -> List[str]:
        """Generate rules for nested array parameters like T[][]."""
        array_info = param.type_info
        if not isinstance(array_info, ArrayInfo):
            return []

        depth, innermost_type = self._get_array_nesting_info(array_info)

        rules = []
        other_params = [p for p in method.parameters if p.index != param.index]
        other_params_decl = self._generate_other_params_declarations(other_params)
        call_args = self._generate_call_arguments(method.parameters, param.index, "array1", "array2")
        array_type_str = array_info.cvl_name

        # Generate k length check rules (one for each nesting level)
        for level in range(depth):
            rules.append(self._generate_nested_array_length_rule(
                method, param, level, other_params_decl, call_args, array_type_str
            ))

        # Generate element satisfy check(s) with k indices
        if innermost_type.category != TypeCategory.MAPPING:
            element_rules = self._generate_nested_array_element_rule(
                method, param, depth, innermost_type, other_params_decl, call_args, array_type_str
            )
            if isinstance(element_rules, list):
                rules.extend(element_rules)
            else:
                rules.append(element_rules)

        return rules

    def _generate_nested_array_length_rule(
        self,
        method: MethodInfo,
        param: ParameterInfo,
        level: int,
        other_params_decl: str,
        call_args: Tuple[str, str],
        array_type_str: str
    ) -> str:
        """Generate length check rule for a specific nesting level."""
        # Build index parameters
        index_params = ", ".join(f"uint256 i{i}" for i in range(level)) if level > 0 else ""

        # Build requires for accessing this level
        requires = []
        for i in range(level):
            access_path = "".join(f"[i{j}]" for j in range(i))
            requires.append(f"require i{i} < array1{access_path}.length;")
            requires.append(f"require array1{access_path}.length == array2{access_path}.length;")
        requires_str = "\n    ".join(requires) if requires else ""

        # Build access path for this level's length check
        access_path = "".join(f"[i{i}]" for i in range(level))

        rule_name = self._make_rule_name(method, param, f"length_level{level}")

        requires_block = f"\n    {requires_str}\n" if requires_str else ""

        return f"""
rule {rule_name}({index_params}) {{
    env e;
    storage initState = lastStorage;

{other_params_decl}
    {array_type_str} array1;
    {array_type_str} array2;
{requires_block}
    {method.method_name}(e{call_args[0]});

    {method.method_name}@withrevert(e{call_args[1]}) at initState;

    assert array1{access_path}.length != array2{access_path}.length => lastReverted;
}}
"""

    def _generate_nested_array_element_rule(
        self,
        method: MethodInfo,
        param: ParameterInfo,
        depth: int,
        innermost_type: TypeInfo,
        other_params_decl: str,
        call_args: Tuple[str, str],
        array_type_str: str
    ) -> str | List[str]:
        """Generate element check(s) with k indices for deepest level."""
        # For structs, generate one rule per leaf field
        if innermost_type.is_struct() and isinstance(innermost_type, StructInfo):
            return self._generate_nested_array_struct_field_rules(
                method, param, depth, innermost_type, other_params_decl, call_args, array_type_str
            )

        # Build index parameters
        index_params = ", ".join(f"uint256 i{i}" for i in range(depth))
        index_vars = [f"i{i}" for i in range(depth)]

        # Build requires for each index (bounds and length equality + loop_iter bound)
        requires = []
        for i in range(depth):
            access_path = "".join(f"[i{j}]" for j in range(i))
            requires.append(f"require array1{access_path}.length == array2{access_path}.length;")
            requires.append(f"require array1{access_path}.length <= {self.loop_iter};")
            requires.append(f"require i{i} < array1{access_path}.length;")

        # Generate equality for other indices (all index combinations except the one under test)
        if innermost_type.is_bytes_or_string():
            equality_fn = lambda *indices: f"keccak256(array1{''.join(f'[{i}]' for i in indices)}) == keccak256(array2{''.join(f'[{i}]' for i in indices)})"
        else:
            equality_fn = lambda *indices: f"array1{''.join(f'[{i}]' for i in indices)} == array2{''.join(f'[{i}]' for i in indices)}"

        requires.append("")
        requires.append("// Other indices must be equal")
        for combo in self._generate_index_combinations(depth):
            # Build condition: NOT (all indices match)
            condition_parts = [f"{combo[i]} == {index_vars[i]}" for i in range(depth)]
            differs_cond = f"!({' && '.join(condition_parts)})"
            equality = equality_fn(*combo)
            requires.append(f"require {differs_cond} => {equality};")

        requires_str = "\n    ".join(requires)

        # Build full access path for the test index
        full_access = "".join(f"[i{i}]" for i in range(depth))

        # Generate element comparison based on innermost type
        if innermost_type.is_bytes_or_string():
            element_cmp = f"keccak256(array1{full_access}) != keccak256(array2{full_access})"
        else:
            element_cmp = f"array1{full_access} != array2{full_access}"

        rule_name = self._make_rule_name(method, param, "element")

        return f"""
rule {rule_name}({index_params}) {{
    env e;
    storage initState = lastStorage;

{other_params_decl}
    {array_type_str} array1;
    {array_type_str} array2;

    {requires_str}

    {method.method_name}(e{call_args[0]});

    {method.method_name}@withrevert(e{call_args[1]}) at initState;

    // if changing this element affects behavior, it should cause a revert
    {self._generate_validation_check(element_cmp)}
}}
"""

    def _generate_nested_array_struct_field_rules(
        self,
        method: MethodInfo,
        param: ParameterInfo,
        depth: int,
        struct_info: StructInfo,
        other_params_decl: str,
        call_args: Tuple[str, str],
        array_type_str: str
    ) -> List[str]:
        """Generate element rules for each struct field in nested array of structs."""
        rules = []
        leaf_fields = struct_info.get_all_leaf_fields()

        # Filter out fields that are arrays or mappings (too complex for element comparison)
        comparable_fields = [f for f in leaf_fields
                            if not f.type_info.is_array() and f.type_info.category != TypeCategory.MAPPING]

        if not comparable_fields:
            return rules

        # Build index parameters
        index_params = ", ".join(f"uint256 i{i}" for i in range(depth))
        index_vars = [f"i{i}" for i in range(depth)]
        full_access = "".join(f"[i{i}]" for i in range(depth))

        # Build base requires for each index (bounds and length equality + loop_iter bound)
        base_requires = []
        for i in range(depth):
            access_path = "".join(f"[i{j}]" for j in range(i))
            base_requires.append(f"require array1{access_path}.length == array2{access_path}.length;")
            base_requires.append(f"require array1{access_path}.length <= {self.loop_iter};")
            base_requires.append(f"require i{i} < array1{access_path}.length;")

        # Helper to generate field equality comparison
        def field_equality(access: str, field: StructFieldInfo) -> str:
            if field.type_info.is_bytes_or_string():
                return f"keccak256(array1{access}.{field.field_path}) == keccak256(array2{access}.{field.field_path})"
            else:
                return f"array1{access}.{field.field_path} == array2{access}.{field.field_path}"

        for field_under_test in comparable_fields:
            field_path = field_under_test.field_path
            field_type = field_under_test.type_info

            requires = list(base_requires)

            # Add requires for other fields at the same indices (i0, i1, ...)
            requires.append("")
            requires.append(f"// Other fields at same index ({', '.join(index_vars)}) must be equal")
            for other_field in comparable_fields:
                if other_field.field_path != field_path:
                    equality = field_equality(full_access, other_field)
                    requires.append(f"require {equality};")

            # Add requires for ALL fields at other index combinations
            requires.append("")
            requires.append("// All fields at other indices must be equal")
            for combo in self._generate_index_combinations(depth):
                # Build condition: NOT (all indices match)
                condition_parts = [f"{combo[i]} == {index_vars[i]}" for i in range(depth)]
                differs_cond = f"!({' && '.join(condition_parts)})"

                # All fields must be equal at this other index
                access = "".join(f"[{idx}]" for idx in combo)
                all_fields_equal = " && ".join(field_equality(access, f) for f in comparable_fields)
                requires.append(f"require {differs_cond} => ({all_fields_equal});")

            requires_str = "\n    ".join(requires)

            # Generate field comparison for the assert
            if field_type.is_bytes_or_string():
                field_cmp = f"keccak256(array1{full_access}.{field_path}) != keccak256(array2{full_access}.{field_path})"
            else:
                field_cmp = f"array1{full_access}.{field_path} != array2{full_access}.{field_path}"

            rule_name = self._make_rule_name(method, param, f"element_{field_path.replace('.', '_')}")

            rule = f"""
rule {rule_name}({index_params}) {{
    env e;
    storage initState = lastStorage;

{other_params_decl}
    {array_type_str} array1;
    {array_type_str} array2;

    {requires_str}

    {method.method_name}(e{call_args[0]});

    {method.method_name}@withrevert(e{call_args[1]}) at initState;

    // if changing this field affects behavior, it should cause a revert
    assert {field_cmp} => lastReverted;
}}
"""
            rules.append(rule)

        return rules

    def _generate_struct_rules(self, method: MethodInfo, param: ParameterInfo) -> List[str]:
        """Generate rules for struct type parameter - one rule per field."""
        struct_info = param.type_info
        if not isinstance(struct_info, StructInfo):
            return []

        rules = []

        # Get all leaf fields (recursively flattened)
        leaf_fields = struct_info.get_all_leaf_fields()

        for field in leaf_fields:
            rule = self._generate_struct_field_rule(method, param, field, leaf_fields)
            if rule:
                rules.append(rule)

        return rules

    def _generate_struct_field_rule(
        self,
        method: MethodInfo,
        param: ParameterInfo,
        field_under_test: StructFieldInfo,
        all_fields: List[StructFieldInfo]
    ) -> str:
        """Generate a rule for a single struct field."""
        struct_info = param.type_info
        if not isinstance(struct_info, StructInfo):
            return ""

        # Create rule name with field path
        field_suffix = field_under_test.field_path.replace(".", "_")
        rule_name = self._make_rule_name(method, param, f"field_{field_suffix}")

        struct_type_str = struct_info.cvl_name

        # Get other method parameters
        other_params = [p for p in method.parameters if p.index != param.index]
        other_params_decl = self._generate_other_params_declarations(other_params)
        call_args = self._generate_call_arguments(method.parameters, param.index, "input1", "input2")

        # Generate equality constraints for all fields except the one under test
        equality_constraints = []
        for field in all_fields:
            if field.field_path != field_under_test.field_path:
                constraint = self._generate_field_equality_constraint(
                    "input1", "input2", field
                )
                equality_constraints.append(constraint)

        equality_constraints_str = "\n".join(equality_constraints)

        # Generate the inequality check for the field under test
        field_inequality = self._generate_field_inequality(
            "input1", "input2", field_under_test
        )

        rule = f"""
rule {rule_name}() {{
    env e;
    storage initState = lastStorage;

{other_params_decl}
    {struct_type_str} input1;
    {struct_type_str} input2;

{equality_constraints_str}

    {method.method_name}(e{call_args[0]});

    {method.method_name}@withrevert(e{call_args[1]}) at initState;

    // if changing this field affects behavior, it should cause a revert
    {self._generate_validation_check(field_inequality)}
}}
"""
        return rule

    def _generate_array_of_struct_rules(self, method: MethodInfo, param: ParameterInfo) -> List[str]:
        """
        Generate rules for array of struct parameter - one rule per struct field at index 0.
        Uses unrolled loop bounds for array equality constraints.
        """
        array_info = param.type_info
        if not isinstance(array_info, ArrayInfo):
            return []

        element_type = array_info.element_type
        if not isinstance(element_type, StructInfo):
            return []

        struct_info = element_type
        array_type_str = array_info.cvl_name

        # Get all leaf fields of the struct
        leaf_fields = struct_info.get_all_leaf_fields()

        rules = []

        # Generate one rule per struct field (testing field at index 0)
        for field in leaf_fields:
            rule = self._generate_array_of_struct_field_rule(
                method, param, field, leaf_fields, struct_info, array_type_str
            )
            if rule:
                rules.append(rule)

        return rules

    def _generate_array_of_struct_field_rule(
        self,
        method: MethodInfo,
        param: ParameterInfo,
        field_under_test: StructFieldInfo,
        all_fields: List[StructFieldInfo],
        struct_info: StructInfo,
        array_type_str: str
    ) -> str:
        """Generate a rule for testing a single field at index 0 of an array of structs."""
        # Create rule name with field path
        field_suffix = field_under_test.field_path.replace(".", "_")
        rule_name = self._make_rule_name(method, param, f"index0_field_{field_suffix}")

        # Get other method parameters
        other_params = [p for p in method.parameters if p.index != param.index]
        other_params_decl = self._generate_other_params_declarations(other_params)
        call_args = self._generate_call_arguments(method.parameters, param.index, "array1", "array2")

        # Generate unrolled equality constraints for array indices
        equality_constraints = []

        # Arrays must have same length and be bounded by loop_iter
        equality_constraints.append(f'    require array1.length == array2.length, "Arrays must have same length";')
        equality_constraints.append(f'    require array1.length <= {self.loop_iter}, "Bound array length to loop_iter";')
        equality_constraints.append(f'    require array1.length > 0, "Arrays must have at least one element";')

        # For index 0: all fields except the one under test must be equal
        index_0_constraints = []
        for field in all_fields:
            if field.field_path != field_under_test.field_path:
                constraint_expr = self._generate_field_equality_for_array_element(
                    "array1", "array2", 0, field
                )
                index_0_constraints.append(f"    require {constraint_expr};")

        if index_0_constraints:
            equality_constraints.append("\n    // Index 0: all fields except the one under test must be equal")
            equality_constraints.extend(index_0_constraints)

        # For indices 1 to loop_iter: all fields must be equal (unrolled)
        for idx in range(1, self.loop_iter):
            equality_constraints.append(f"\n    // Index {idx}: all struct fields must be equal")
            all_fields_equal = self._generate_array_struct_equality_at_index(
                "array1", "array2", idx, struct_info, all_fields
            )
            equality_constraints.append(all_fields_equal)

        equality_constraints_str = "\n".join(equality_constraints)

        # Generate the inequality check for the field under test at index 0
        field_inequality = self._generate_field_inequality_for_array_element(
            "array1", "array2", 0, field_under_test
        )

        rule = f"""
rule {rule_name}() {{
    env e;
    storage initState = lastStorage;

{other_params_decl}
    {array_type_str} array1;
    {array_type_str} array2;

{equality_constraints_str}

    {method.method_name}(e{call_args[0]});

    {method.method_name}@withrevert(e{call_args[1]}) at initState;

    // if changing this field at index 0 affects behavior, it should cause a revert
    {self._generate_validation_check(field_inequality)}
}}
"""
        return rule

    def _generate_field_equality_constraint(
        self, struct1: str, struct2: str, field: StructFieldInfo
    ) -> str:
        """Generate a require statement for field equality."""
        field_path = field.field_path
        field_type = field.type_info

        if field_type.is_bytes_or_string():
            return f'    require keccak256({struct1}.{field_path}) == keccak256({struct2}.{field_path}), "Assume field not under test is not changed";'
        elif field_type.is_array():
            # For arrays, check length and use quantifier
            array_info = field_type
            assert isinstance(array_info, ArrayInfo), f"Expected ArrayInfo but got {type(array_info)}"
            element_type = array_info.element_type
            if element_type.is_bytes_or_string():
                element_eq = f"keccak256({struct1}.{field_path}[i]) == keccak256({struct2}.{field_path}[i])"
            else:
                element_eq = f"{struct1}.{field_path}[i] == {struct2}.{field_path}[i]"

            return f'''    require {struct1}.{field_path}.length == {struct2}.{field_path}.length, "Assume field not under test is not changed";
    require forall uint256 i. 0 <= i && i < {struct1}.{field_path}.length => {element_eq}, "Assume field not under test is not changed";'''
        else:
            return f'    require {struct1}.{field_path} == {struct2}.{field_path}, "Assume field not under test is not changed";'

    def _generate_field_inequality(
        self, struct1: str, struct2: str, field: StructFieldInfo
    ) -> str:
        """Generate the inequality expression for a field."""
        field_path = field.field_path
        field_type = field.type_info

        if field_type.is_bytes_or_string():
            return f"keccak256({struct1}.{field_path}) != keccak256({struct2}.{field_path})"
        elif field_type.is_array():
            # For arrays, check if any element is different (at index 0 for simplicity)
            array_info = field_type
            assert isinstance(array_info, ArrayInfo), f"Expected ArrayInfo but got {type(array_info)}"
            element_type = array_info.element_type
            # Check that arrays have at least one element
            length_check = f"{struct1}.{field_path}.length > 0"
            if element_type.is_bytes_or_string():
                element_ineq = f"keccak256({struct1}.{field_path}[0]) != keccak256({struct2}.{field_path}[0])"
            else:
                element_ineq = f"{struct1}.{field_path}[0] != {struct2}.{field_path}[0]"
            return f"({length_check} && {element_ineq})"
        else:
            return f"{struct1}.{field_path} != {struct2}.{field_path}"

    def _generate_array_struct_equality_at_index(
        self,
        array1_name: str,
        array2_name: str,
        index: int,
        struct_info: StructInfo,
        all_fields: List[StructFieldInfo]
    ) -> str:
        """
        Generate equality constraints for all fields of a struct at a specific array index.
        Uses unrolled constraints (not quantifiers).
        """
        field_constraints = []

        for field in all_fields:
            constraint = self._generate_field_equality_for_array_element(
                array1_name, array2_name, index, field
            )
            field_constraints.append(constraint)

        # Combine all constraints with implication for index bounds
        if field_constraints:
            all_constraints = " &&\n        ".join([c.strip() for c in field_constraints if c.strip()])
            return f'    require {array1_name}.length > {index} => (\n        {all_constraints}\n    ), "Index {index} equality";'
        else:
            return f'    // No fields to constrain at index {index}'

    def _generate_field_equality_for_array_element(
        self,
        array1_name: str,
        array2_name: str,
        index: int,
        field: StructFieldInfo
    ) -> str:
        """Generate equality constraint for a single field at an array element."""
        field_path = field.field_path
        field_type = field.type_info

        if field_type.is_bytes_or_string():
            return f"keccak256({array1_name}[{index}].{field_path}) == keccak256({array2_name}[{index}].{field_path})"
        elif field_type.is_array():
            # For nested arrays, just check length (to avoid nested quantifiers)
            return f"{array1_name}[{index}].{field_path}.length == {array2_name}[{index}].{field_path}.length"
        else:
            return f"{array1_name}[{index}].{field_path} == {array2_name}[{index}].{field_path}"

    def _generate_field_inequality_for_array_element(
        self,
        array1_name: str,
        array2_name: str,
        index: int,
        field: StructFieldInfo
    ) -> str:
        """Generate inequality expression for a single field at an array element."""
        field_path = field.field_path
        field_type = field.type_info

        if field_type.is_bytes_or_string():
            return f"keccak256({array1_name}[{index}].{field_path}) != keccak256({array2_name}[{index}].{field_path})"
        elif field_type.is_array():
            # For nested arrays, check if first element is different
            array_info = field_type
            assert isinstance(array_info, ArrayInfo), f"Expected ArrayInfo but got {type(array_info)}"
            element_type = array_info.element_type
            length_check = f"{array1_name}[{index}].{field_path}.length > 0"
            if element_type.is_bytes_or_string():
                element_ineq = f"keccak256({array1_name}[{index}].{field_path}[0]) != keccak256({array2_name}[{index}].{field_path}[0])"
            else:
                element_ineq = f"{array1_name}[{index}].{field_path}[0] != {array2_name}[{index}].{field_path}[0]"
            return f"({length_check} && {element_ineq})"
        else:
            return f"{array1_name}[{index}].{field_path} != {array2_name}[{index}].{field_path}"

    def _generate_other_params_declarations(self, other_params: List[ParameterInfo]) -> str:
        """Generate havoc variable declarations for other parameters."""
        if not other_params:
            return ""

        declarations = []
        for param in other_params:
            type_str = param.type_info.cvl_name
            declarations.append(f"    {type_str} anotherInput{param.index};")

        return "\n".join(declarations) + "\n"

    def _generate_call_arguments(
        self,
        all_params: List[ParameterInfo],
        test_param_index: int,
        test_value1: str,
        test_value2: str
    ) -> tuple:
        """
        Generate argument lists for method calls.

        Returns:
            Tuple of (args_with_value1, args_with_value2)
        """
        args1 = []
        args2 = []

        for param in all_params:
            if param.index == test_param_index:
                args1.append(test_value1)
                args2.append(test_value2)
            else:
                args1.append(f"anotherInput{param.index}")
                args2.append(f"anotherInput{param.index}")

        args1_str = ", " + ", ".join(args1) if args1 else ""
        args2_str = ", " + ", ".join(args2) if args2 else ""

        return (args1_str, args2_str)

    def _make_rule_name(self, method: MethodInfo, param: ParameterInfo, suffix: str) -> str:
        """Generate a unique rule name."""
        method_sig = method.get_signature_hash()
        # Replace dots, brackets, and spaces with underscores for valid CVL identifiers
        param_type = param.type_info.solidity_name.replace("[]", "Array").replace(".", "_").replace(" ", "_")

        base_name = f"input_validation_{method_sig}_param{param.index}_{param_type}"

        if suffix:
            base_name = f"{base_name}_{suffix}"

        # Ensure uniqueness
        if base_name in self.generated_rule_names:
            counter = 1
            while f"{base_name}_{counter}" in self.generated_rule_names:
                counter += 1
            base_name = f"{base_name}_{counter}"

        self.generated_rule_names.add(base_name)
        return base_name


def generate_spec_file_header(contract_name: str) -> str:
    """Generate the header for a spec file."""
    return f"""/*
 * Input Validation Checker for {contract_name}
 * Auto-generated by Certora Patrol
 *
 * This spec checks if user inputs are properly validated by testing
 * if different input values cause the function to revert.
 * Note that in order to (somewhat) avoid effects of non-deterministic external calls, it's enough that a single
 * different input makes the method not revert to be considred potentially lacking checks:
 * `assert input1 != input2 => lastReverted;`
 * This by itself may lead to false positives.
 * For setups where all non-determinism is eliminated, it is recommend to check that:
 * `satisfy input1 != input2 && lastReverted;`
 * If the satisfy statement is failing (UNSAT), then no other input can cause a reverting behavior,
 * meaning it is not checked. Without controlling for non-determinism, it is easy to hit on reverts due to other reasons.
 */

methods {{
    // Placeholder for any method declarations if needed
}}

"""
