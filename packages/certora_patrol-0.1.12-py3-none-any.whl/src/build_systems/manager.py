#!/usr/bin/env python3
"""
Build System Manager - Abstract base class for build system managers.

Provides common functionality for config file discovery, auto-detection,
and artifact management. Concrete managers only implement build-system-specific
parsing and artifact filtering.
"""

import os
import sys
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Callable, List, Optional, Set

from src.build_systems.base import BuildSystemConfig
from src.setup.solidity_utils import DEPENDENCIES


class BuildSystemManager(ABC):
    """
    Abstract base class for build system managers.

    Provides common functionality for config file discovery, auto-detection,
    compilation, and artifact management. Concrete managers only implement
    build-system-specific parsing and command generation.
    """

    def __init__(self, project_root: Path, scope, component_name: str):
        """
        Initialize build system manager.

        Args:
            project_root: Root directory of the project
            scope: Centralized scope for consistent filtering
            component_name: Name for logging (e.g. "FoundryManager", "HardhatManager")
        """
        self.project_root = project_root
        self.scope = scope
        self.component = component_name

    def log(self, message: str, level: str = "INFO"):
        """Log message using centralized logger."""
        # Import here to avoid circular dependency
        sys.path.insert(0, str(Path(__file__).parent.parent.parent))
        from src.utils.logger import logger
        logger.log(message, level, self.component)

    @abstractmethod
    def get_config_filenames(self) -> List[str]:
        """
        Return list of config filenames to search for.

        Examples:
            - Foundry: ["foundry.toml"]
            - Hardhat: ["hardhat.config.js", "hardhat.config.ts"]

        Returns:
            List of config filenames
        """
        pass

    @abstractmethod
    def parse_config(self, config_file: Path, profile: str | None = None) -> BuildSystemConfig:
        """
        Parse a specific config file (build-system specific logic).

        Args:
            config_file: Path to config file
            profile: Optional build profile (used by Foundry)

        Returns:
            Parsed BuildSystemConfig (FoundryConfig, HardhatConfig, etc.)
        """
        pass

    @abstractmethod
    def get_default_artifact_dir(self) -> str:
        """
        Return default artifact directory name.

        Examples:
            - Foundry: "out"
            - Hardhat: "artifacts"

        Returns:
            Directory name (relative to project root)
        """
        pass

    @abstractmethod
    def get_build_command(self, profile: Optional[None] = None) -> str:
        """
        Return the build command for this build system.

        Examples:
            - Foundry: "forge build"
            - Hardhat: "npx hardhat compile"

        Returns:
            Build command string
        """
        pass

    @abstractmethod
    def filter_artifacts(self, artifacts_dir: Path) -> List[Path]:
        """
        Filter artifacts based on build system conventions.

        Implemented using os.walk for explicit directory traversal with pruning.
        Each build system has different filtering logic:
            - Foundry: Include all .json files except build-info/
            - Hardhat: Include .json files in contracts/, exclude .dbg.json and build-info/

        Args:
            artifacts_dir: Path to artifacts directory

        Returns:
            List of artifact file paths
        """
        pass

    def find_config_files(self) -> List[Path]:
        """
        Find all build system configuration files in the project and context directories.

        Generic config file finding logic parameterized by get_config_filenames().
        Searches in:
            1. Project root
            2. Parent directories (up to 3 levels)
            3. Subdirectories (with pruning of excluded dirs)

        Returns:
            List of config file paths
        """
        config_files = []
        config_filenames = self.get_config_filenames()

        # Search in project root
        for config_name in config_filenames:
            root_config = self.project_root / config_name
            if root_config.exists():
                config_files.append(root_config)

        # Search in parent directories (common in monorepos)
        # Don't traverse into lib directories
        current_dir = self.project_root.parent
        skip_dirs = set(DEPENDENCIES) | {".certora_internal", ".certora_sources", "gitmodules"}
        for _ in range(3):  # Search up to 3 levels up
            # Skip if current directory is in excluded paths
            if any(part in skip_dirs for part in current_dir.parts):
                break

            for config_name in config_filenames:
                config_file = current_dir / config_name
                if config_file.exists() and config_file not in config_files:
                    config_files.append(config_file)
            current_dir = current_dir.parent

        # Search in subdirectories (for multi-project setups) - exclude Certora output directories
        # Use os.walk with directory pruning to avoid traversing into excluded directories
        for root, dirs, files in os.walk(self.project_root):
            # Prune directories we don't want to traverse into
            dirs[:] = [d for d in dirs if d not in skip_dirs]

            for config_name in config_filenames:
                if config_name in files:
                    config_file = Path(root) / config_name
                    if config_file not in config_files and self.scope.is_file_in_scope(config_file):
                        config_files.append(config_file)

        self.log(f"Found {len(config_files)} config files")
        return config_files

    def _walk_and_filter_artifacts(
        self,
        base_dir: Path,
        skip_dirs: Set[str],
        file_filter: Callable[[str], bool]
    ) -> List[Path]:
        """
        Common os.walk pattern for artifact filtering.

        Template helper method that traverses a directory tree and filters files
        based on provided criteria. Used by concrete managers in filter_artifacts().

        Args:
            base_dir: Base directory to start traversal
            skip_dirs: Set of directory names to skip during traversal
            file_filter: Callable that returns True if a filename should be included

        Returns:
            List of Path objects for files matching the filter
        """
        artifact_files = []
        for root, dirs, files in os.walk(base_dir):
            # Prune directories we don't want to traverse
            dirs[:] = [d for d in dirs if d not in skip_dirs]

            for filename in files:
                if file_filter(filename):
                    artifact_files.append(Path(root) / filename)

        return artifact_files

    def auto_detect_config(self, profile: str | None = None) -> BuildSystemConfig:
        """
        Automatically find config file, verify single file, and return parsed config.

        Generic auto-detection logic:
            1. Uses find_config_files() to find all config files
            2. Validates exactly one config file found
            3. Parses and returns the config

        Args:
            profile: Optional build profile (used by Foundry)

        Returns:
            Parsed BuildSystemConfig

        Raises:
            Exception: If there's not exactly one config file
        """
        config_files = self.find_config_files()

        if len(config_files) == 0:
            raise Exception(f"No {self.component} config file found in project")

        if len(config_files) > 1:
            files_str = "\n  ".join(str(f) for f in config_files)
            raise Exception(
                f"Multiple {self.component} config files found:\n  {files_str}\n"
                f"Please ensure only one config file exists."
            )

        config_file = config_files[0]
        self.log(f"Auto-detected config: {config_file}")
        return self.parse_config(config_file, profile=profile)

