# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class DetachInstancesResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'failed_operation_list': 'list[VmOperateResult]',
        'job_id': 'str',
        'success_job_ids': 'list[str]'
    }

    attribute_map = {
        'failed_operation_list': 'failed_operation_list',
        'job_id': 'job_id',
        'success_job_ids': 'success_job_ids'
    }

    def __init__(self, failed_operation_list=None, job_id=None, success_job_ids=None):
        r"""DetachInstancesResponse

        The model defined in huaweicloud sdk

        :param failed_operation_list: 操作失败桌面列表。
        :type failed_operation_list: list[:class:`huaweicloudsdkworkspace.v2.VmOperateResult`]
        :param job_id: 任务ID,池桌面返回job_id,普通桌面job_id为空。
        :type job_id: str
        :param success_job_ids: 内部服务操作成功jobId
        :type success_job_ids: list[str]
        """
        
        super().__init__()

        self._failed_operation_list = None
        self._job_id = None
        self._success_job_ids = None
        self.discriminator = None

        if failed_operation_list is not None:
            self.failed_operation_list = failed_operation_list
        if job_id is not None:
            self.job_id = job_id
        if success_job_ids is not None:
            self.success_job_ids = success_job_ids

    @property
    def failed_operation_list(self):
        r"""Gets the failed_operation_list of this DetachInstancesResponse.

        操作失败桌面列表。

        :return: The failed_operation_list of this DetachInstancesResponse.
        :rtype: list[:class:`huaweicloudsdkworkspace.v2.VmOperateResult`]
        """
        return self._failed_operation_list

    @failed_operation_list.setter
    def failed_operation_list(self, failed_operation_list):
        r"""Sets the failed_operation_list of this DetachInstancesResponse.

        操作失败桌面列表。

        :param failed_operation_list: The failed_operation_list of this DetachInstancesResponse.
        :type failed_operation_list: list[:class:`huaweicloudsdkworkspace.v2.VmOperateResult`]
        """
        self._failed_operation_list = failed_operation_list

    @property
    def job_id(self):
        r"""Gets the job_id of this DetachInstancesResponse.

        任务ID,池桌面返回job_id,普通桌面job_id为空。

        :return: The job_id of this DetachInstancesResponse.
        :rtype: str
        """
        return self._job_id

    @job_id.setter
    def job_id(self, job_id):
        r"""Sets the job_id of this DetachInstancesResponse.

        任务ID,池桌面返回job_id,普通桌面job_id为空。

        :param job_id: The job_id of this DetachInstancesResponse.
        :type job_id: str
        """
        self._job_id = job_id

    @property
    def success_job_ids(self):
        r"""Gets the success_job_ids of this DetachInstancesResponse.

        内部服务操作成功jobId

        :return: The success_job_ids of this DetachInstancesResponse.
        :rtype: list[str]
        """
        return self._success_job_ids

    @success_job_ids.setter
    def success_job_ids(self, success_job_ids):
        r"""Sets the success_job_ids of this DetachInstancesResponse.

        内部服务操作成功jobId

        :param success_job_ids: The success_job_ids of this DetachInstancesResponse.
        :type success_job_ids: list[str]
        """
        self._success_job_ids = success_job_ids

    def to_dict(self):
        import warnings
        warnings.warn("DetachInstancesResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DetachInstancesResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
