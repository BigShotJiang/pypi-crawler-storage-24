#
# (C) Pywikibot team, 2020-2026
#
# Distributed under the terms of the MIT license.
#
"""Pywikibot metadata file.

.. version-added:: 4.0
"""
from __future__ import annotations

from time import strftime


__version__ = '11.1.0'
__url__ = 'https://www.mediawiki.org/wiki/Manual:Pywikibot'
__copyright__ = f'2003-{strftime("%Y")}, Pywikibot team'
