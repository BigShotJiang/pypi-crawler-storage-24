#
# (C) Pywikibot team, 2021-2026
#
# Distributed under the terms of the MIT license.
#
"""Folder which holds framework scripts.

.. version-added:: 7.0
.. version-removed:: 9.4
   ``preload_sites`` script, previously added in release 6.0
   (:phab:`T226157`), was removed (:phab:`T348925`).
"""
from __future__ import annotations

from os import environ, getenv


def _import_with_no_user_config(*import_args):
    """Return ``__import__(*import_args)`` without loading user config.

    .. version-added:: 3.0
    .. version-changed:: 7.0
       moved to pywikibot.scripts
    """
    orig_no_user_config = getenv('PYWIKIBOT_NO_USER_CONFIG')
    environ['PYWIKIBOT_NO_USER_CONFIG'] = '2'
    result = __import__(*import_args)
    # Reset this flag
    if not orig_no_user_config:
        del environ['PYWIKIBOT_NO_USER_CONFIG']
    else:  # pragma: no cover
        environ['PYWIKIBOT_NO_USER_CONFIG'] = orig_no_user_config
    return result
