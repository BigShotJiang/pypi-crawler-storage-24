# -*- coding: utf-8 -*-
"""CLI commands for port-app-config"""

import json
import sys
from pathlib import Path
from typing import Any, Type

import click
from jsonref import replace_refs  # type: ignore[import-untyped]

from port_ocean.cli.commands.main import cli_start
from port_ocean.core.handlers import BasePortAppConfig
from port_ocean.core.handlers.port_app_config.validators import (
    validate_and_get_config_schema,
)
from port_ocean.core.handlers.port_app_config.models import PortAppConfig
from port_ocean.core.integrations.base import BaseIntegration
from port_ocean.utils.misc import get_integration_class


def _get_config_class(
    integration_class: Type[BaseIntegration],
) -> Type[PortAppConfig]:
    """Extract CONFIG_CLASS from the integration's AppConfigHandlerClass."""
    handler_class: Type[BasePortAppConfig] = integration_class.AppConfigHandlerClass
    return handler_class.CONFIG_CLASS


def _load_integration_class(path: str) -> Type[BaseIntegration]:
    """Load the integration class from *path*, handling errors."""
    should_cleanup_sys_path = False
    if path not in sys.path:
        sys.path.append(path)
        should_cleanup_sys_path = True
    try:
        cls = get_integration_class(path)
        if cls is None:
            click.echo(f"No integration class found in {path}", err=True)
            sys.exit(1)
        return cls
    except FileNotFoundError:
        click.echo(f"Integration class not found for {path}", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Failed to load integration from {path}: {e}", err=True)
        sys.exit(1)
    finally:
        if should_cleanup_sys_path:
            sys.path.remove(path)


def _dereference_schema(result: dict[str, Any]) -> dict[str, Any]:
    """Dereference all $ref in the UI schema and remove definitions. Uses jsonref."""
    for kind_data in result.get("kinds", {}).values():
        selectors = kind_data.get("selectors")
        if isinstance(selectors, dict) and "definitions" in selectors:
            kind_data["selectors"] = replace_refs(selectors, proxies=False)
            kind_data["selectors"].pop("definitions", None)
    return result


def _write_json_output(
    data: dict[str, Any],
    output_file: str | None,
    pretty: bool,
) -> None:
    """Serialise *data* as JSON to *output_file* or stdout."""
    indent = 2 if pretty else None
    json_output = json.dumps(data, indent=indent)

    if output_file:
        output_path = Path(output_file)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        output_path.write_text(json_output)
        click.echo(
            click.style(f"Output written to {output_file}", fg="green"),
            err=True,
        )
    else:
        print(json_output)


@cli_start.group("port-app-config")
def port_app_config() -> None:
    """Commands related to port-app-config"""
    pass


@port_app_config.command("schema")
@click.argument("path", default=".", type=click.Path(exists=True))
@click.option(
    "-f",
    "--format",
    "format",
    type=click.Choice(["json", "ui"]),
    default="json",
    help="Schema format: json (default) or ui (UI-compatible schema).",
)
@click.option(
    "-o",
    "--output",
    "output_file",
    default=None,
    type=click.Path(),
    help="Output file path. If not specified, prints to stdout.",
)
@click.option(
    "--pretty/--compact",
    "pretty",
    default=True,
    help="Pretty print JSON output (default: pretty).",
)
def port_app_config_schema(
    path: str,
    format: str,
    output_file: str | None,
    pretty: bool,
) -> None:
    """
    Extract the PortAppConfig schema for an integration.

    PATH: Path to the integration directory (default: current directory).

    Format: json (default) outputs raw JSON Schema; ui outputs
    UI-compatible schema with dereferenced selectors.
    """
    integration_class = _load_integration_class(path)
    config_class = _get_config_class(integration_class)

    match format:
        case "json":
            validate_and_get_config_schema(config_class)
            result = config_class.schema()
        case "ui":
            result = validate_and_get_config_schema(config_class)
            result = _dereference_schema(result)
        case _:
            click.echo(f"Invalid format: {format}", err=True)
            sys.exit(1)

    _write_json_output(result, output_file, pretty)
