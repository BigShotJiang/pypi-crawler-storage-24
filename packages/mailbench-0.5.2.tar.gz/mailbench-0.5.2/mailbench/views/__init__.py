"""Views for Mailbench."""
