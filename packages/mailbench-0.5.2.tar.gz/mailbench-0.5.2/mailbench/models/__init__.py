"""Data models for Mailbench."""
