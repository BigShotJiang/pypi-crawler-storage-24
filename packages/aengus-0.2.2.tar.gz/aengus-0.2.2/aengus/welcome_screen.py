import random

welcome_screen_cow = [
    r"                                                                         ",
    r"        ____\/____             ____  _\/________\/__ ___/ \_   __        ",
    r"       /          \_____\/____/                   / _ \     \_/_ \       ",
    r"       |          ___                             \__|-\\  |/-/__/       ",
    r"       |         / _ \                                 \ \  / /          ",
    r"       \_       / /_\ \ ___ _ __   __ _ _   _ ___      | |  | /          ",
    r"       |        |  _  |/ _ \ '_ \ / _` | | | / __|     | /  \\           ",
    r"       |        | | | |  __/ | | | (_| | |_| \__ \      \ \/ /           ",
    r"       |        \_| |_/\___|_| |_|\__, |\__,_|___/       \/              ",
    r"      |        ___                 __/ |                //               ",
    r"      \\     //   \               |___/                //                ",
    r"       |     /     \_                                 /                  ",
    r"      /    //       \_                               _/                  ",
    r"      |_   / \ _____ _\_____ /_____    __/_  _/ \__ |/                   ",
    r"      \   /  \  /|\ /              \__/    |  |  \__/                    ",
    r"       \ /    \ _ _/                        \  \  _/                     ",
    r"       | |    \   /                          |  \ |                      ",
    r"       | _\    \\ \                          |  | /                      ",
    r"       /  \     \  \                         |_/| |                      ",
    r"       /__|      \_\\                       /_| /_\                      ",
    r"^~._.~^~._.~^~._.~^~._.~^~._.~^~._.~^~._.~^~._.~^~._.~^~._.~^~._.~^~._.~.",
]

welcome_screen_calliope = [
    r".~^~._.~^~._.~^~._.~^~._.~^~._.~^~._.~^~._.~^~._.~^~._.~^~._.~^~._.~^~",
    r" .~----~.           ___                                      .~----~. ",
    r"(  ~^^~  )         / _ \                                    (  ~^^~  )",
    r" )      (         / /_\ \ ___ _ __   __ _ _   _ ___          )      ( ",
    r"(  (())  )        |  _  |/ _ \ '_ \ / _` | | | / __|        (  (())  )",
    r" |  ||  |         | | | |  __/ | | | (_| | |_| \__ \         |  ||  | ",
    r" |  ||  |         \_| |_/\___|_| |_|\__, |\__,_|___/         |  ||  | ",
    r" |  ||  |                            __/ |                   |  ||  | ",
    r" |  ||  |                           |___/                    |  ||  | ",
    r" |  ||  |                                                    |  ||  | ",
    r" |  ||  |          -- your personal writing hub --           |  ||  | ",
    r"(________)                                                  (________)",
    r".~^~._.~^~._.~^~._.~^~._.~^~._.~^~._.~^~._.~^~._.~^~._.~^~._.~^~._.~^~",
]


def random_welcome_screen(welcome_screen: list[str]) -> str:
    random_frame = []
    for _ in range(len(welcome_screen)):
        line = []
        for _ in range(len(welcome_screen[0])):
            c = chr(random.randint(36, 128))
            if c in "[]\\":
                c = "."
            line.append(c)
        random_frame.append("".join(line))
    return "\n".join(random_frame)


def get_animation_frame(frame_count: int, total_frames: int, welcome_screen: str) -> str:
    if frame_count >= total_frames:
        return "\n".join(welcome_screen_cow)

    progress = frame_count / (total_frames - 1)

    ascii_min = 32
    ascii_max = 126

    lines = []
    for line in welcome_screen:
        new_chars = []
        for char in line:
            # TODO: do not randomize whitespace for extra effect?
            if random.random() < progress:
                new_chars.append(char)
            else:
                random_char = chr(random.randint(ascii_min, ascii_max))
                if random_char in "[]\\":
                    random_char = "."
                new_chars.append(random_char)
        lines.append("".join(new_chars))

    return "\n".join(lines)
