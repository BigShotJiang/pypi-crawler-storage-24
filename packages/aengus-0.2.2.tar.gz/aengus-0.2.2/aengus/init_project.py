from pathlib import Path


def _write_toml(root: Path, folder: str) -> None:
    (root / "aengus.toml").write_text(
        "[project]\n"
        f'name = "{folder}"\n\n'
        "[mentions]\n"
        "# a list of folders to look for files to populate the mentions swatch\n"
        'folders = ["characters", "places"]\n\n'
        "# for every folder you can specify a color for highlighting in the editor\n"
        'colors = {"characters" = "#ff0000"}\n\n'
        "[word_count]\n"
        "# folders to be included when calculating the total word count\n"
        'folders = ["novel"]\n'
        "# total word goal\n"
        "goal = 80_000\n",
        encoding="utf-8",
    )


def _write_empty_stats(root: Path) -> None:
    (root / "aengus_stats.csv").write_text("date,minutes,total_words\n", encoding="utf-8")


def init_empty_project(folder: str) -> None:
    root = Path(folder)
    novel_dir = root / "novel"
    characters_dir = root / "characters"
    places_dir = root / "places"

    novel_dir.mkdir(parents=True, exist_ok=True)
    characters_dir.mkdir(parents=True, exist_ok=True)
    places_dir.mkdir(parents=True, exist_ok=True)
    (root / "notes").mkdir(parents=True, exist_ok=True)

    chapter_file = novel_dir / "chapter01.md"
    character_file = characters_dir / "Sima.md"
    place_file = places_dir / "Ashara.md"

    chapter_file.write_text(
        "### Chapter 01\n\nSima was walking down the street in Ashara..\n",
        encoding="utf-8",
    )
    character_file.write_text(
        "---\n"
        "# this is optional but can include aliases for highlighting and a color\n"
        "aliases:\n"
        ' - "Ashamad"\n'
        ' - "Little Mouse"\n'
        'color: "#2fff00"\n'
        "---\n"
        "### Description\n\nShe is awesome.\n",
        encoding="utf-8",
    )
    place_file.write_text("### Description\n\nBusy place.\n", encoding="utf-8")

    _write_toml(root=root, folder=folder)
    _write_empty_stats(root=root)


def init_existing_project(folder: str) -> None:
    root = Path(folder)
    _write_toml(root=root, folder=folder)
    _write_empty_stats(root=root)
