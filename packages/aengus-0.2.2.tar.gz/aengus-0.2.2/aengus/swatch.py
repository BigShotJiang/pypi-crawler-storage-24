import re
from dataclasses import dataclass
from pathlib import Path

from rich.style import Style
from rich.text import Text
from textual import on
from textual.containers import VerticalScroll
from textual.message import Message
from textual.widgets import Button

DEFAULT_COLORS = {
    "characters": "#FFD700",
    "places": "#87CEEB",
}
FALLBACK_COLOR = "#970bca"


@dataclass
class Mention:
    name: str
    aliases: list[str]
    style: Style
    folder: str


class MentionSwatch(VerticalScroll):
    def __init__(self, id: str) -> None:
        super().__init__(id=id)
        self.mentions: list[Mention] = []

    def set_mentions(self, mentions_metadata: list[dict[str, str | list[str]]]) -> None:
        self.mentions = [
            Mention(
                name=m.get("name"),
                aliases=m.get("aliases", []),
                style=Style(
                    color=m.get("color", DEFAULT_COLORS.get(m.get("folder"), FALLBACK_COLOR)),
                    bold=True,
                ),
                folder=m.get("folder"),
            )
            for m in mentions_metadata
        ]

    def update_mentions(self, text: str, current_file: Path | None) -> None:
        self.call_after_refresh(self._sync_mentions, text, current_file)

    async def _sync_mentions(self, text: str, cur_file: Path | None) -> None:
        current_words = set(re.findall(r"\b\w+\b", text))

        wanted: dict[str, tuple[str, Style]] = {}  # name -> (folder, style)
        if cur_file is not None:
            for mention in self.mentions:
                if mention.folder == cur_file.parent.name and mention.name == cur_file.stem:
                    continue
                for alias in [mention.name] + mention.aliases:
                    if alias in current_words:
                        wanted[mention.name] = (mention.folder, mention.style)

        existing: dict[str, str] = {  # name -> folder
            name: folder for folder, name in (b.id.split("__") for b in self.query(Button))
        }

        for name, (folder, style) in wanted.items():
            if name not in existing:
                await self.mount(
                    Button(
                        label=Text(text=name, style=style),
                        flat=True,
                        id=f"{folder}__{name}",
                    )
                )

        for name, folder in existing.items():
            if name not in wanted:
                await self.query_one(f"#{folder}__{name}", Button).remove()

    @on(Button.Pressed)
    def on_button_pressed(self, event: Button.Pressed) -> None:
        category, name = event.button.id.split("__")
        self.post_message(self.NameSelected(name, category))

    class NameSelected(Message):
        def __init__(self, name: str, category: str | None):
            self.name = name
            self.category = category
            super().__init__()
