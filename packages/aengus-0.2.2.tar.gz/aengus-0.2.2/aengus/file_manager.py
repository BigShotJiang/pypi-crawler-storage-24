import csv
from datetime import datetime
from pathlib import Path

import frontmatter


class FileManager:
    def __init__(self, project_root: Path, mention_folders: list[str], stats_path: Path):
        self._project_root = project_root
        self._mention_folders = mention_folders
        self._stats_path = stats_path
        self._all_files: list[Path] = []
        self._session_stats: list[dict[str, int | str]] | None = None

    @property
    def all_files(self) -> list[Path]:
        return self._all_files

    def get_mentions_metadata(self) -> list[dict[str, str | list[str]]]:
        self._all_files = [
            p
            for p in self._project_root.rglob("*")
            if p.is_file()
            and not any(part.startswith(".") for part in p.parts)
            and p != self._stats_path
        ]
        mentions_metadata = []
        for folder in self._mention_folders:
            folder_path = self._project_root / folder
            if not folder_path.exists():
                continue
            for file in folder_path.glob("*.md"):
                metadata = frontmatter.load(file).metadata
                mentions_metadata.append(metadata | {"name": file.stem, "folder": folder})
        return mentions_metadata

    def read_file(self, path: Path) -> str:
        return path.read_text(encoding="utf-8")

    def save_file(self, path: Path, content: str) -> None:
        path.write_text(content, encoding="utf-8")

    def create_file(self, path: Path) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("", encoding="utf-8")

    def delete_file(self, path: Path) -> None:
        path.unlink()

    def is_inside_project(self, path: Path) -> bool:
        try:
            path.relative_to(self._project_root)
            return True
        except ValueError:
            return False

    def load_session_stats(self) -> list[dict[str, int | str]]:
        if not self._stats_path.exists():
            return []
        if self._session_stats is not None:
            return self._session_stats

        rows: list[dict[str, int | str]] = []
        with self._stats_path.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            for row in reader:
                if not row:
                    continue
                try:
                    minutes = int(row.get("minutes", "0"))
                    total_words = int(row.get("total_words", "0"))
                except ValueError:
                    continue
                raw_date = row.get("date", "")
                if raw_date:
                    try:
                        parsed = datetime.strptime(raw_date, "%Y-%m-%d %H:%M")
                        formatted_date = parsed.strftime("%d/%m/%Y %H:%M")
                    except ValueError:
                        formatted_date = raw_date
                else:
                    formatted_date = ""
                rows.append(
                    {
                        "date": formatted_date,
                        "minutes": minutes,
                        "total_words": total_words,
                    }
                )
        self._session_stats = rows
        return rows

    def append_session_stats(self, minutes: int, total_words: int) -> None:
        write_header = not self._stats_path.exists()
        with self._stats_path.open("a", encoding="utf-8", newline="") as handle:
            writer = csv.writer(handle)
            if write_header:
                writer.writerow(["date", "minutes", "total_words"])
            writer.writerow([datetime.now().strftime("%Y-%m-%d %H:%M"), minutes, total_words])
