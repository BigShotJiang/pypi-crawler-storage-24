import math
from importlib.resources import files
from pathlib import Path
from time import monotonic

from textual import on
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal
from textual.reactive import reactive
from textual.widgets import ListView, Static

from aengus.confirm_dialog import ConfirmDeleteScreen
from aengus.editor import AengusEditor
from aengus.file_manager import FileManager
from aengus.file_picker import FilePicker, PickerMode
from aengus.footer import AengusFooter
from aengus.statistics import Statistics
from aengus.swatch import MentionSwatch
from aengus.welcome_screen import get_animation_frame, random_welcome_screen, welcome_screen_cow
from aengus.word_counter import WordCounter


class Aengus(App):
    CSS_PATH = str(files("aengus").joinpath("aengus.tcss"))
    LAYERS = ["default", "overlay"]
    BINDINGS = [
        Binding("ctrl+q", "quit", "Quit"),
        Binding("ctrl+s", "save", "Save"),
        Binding("ctrl+t", "close", "Close"),
        Binding("ctrl+o", "open_finder", "Open File"),
        Binding("ctrl+n", "new_file", "New File"),
        Binding("ctrl+b", "back", "Go Back"),
        Binding("ctrl+k", "delete_file", "Delete File", priority=True),
        Binding("escape", "close_finder", "Close Finder", show=False),
        Binding("ctrl+l", "statistics", "Open Statistics"),
        Binding("alt+left", "focus_left", "Focus Left", show=False),
        Binding("alt+right", "focus_right", "Focus Right", show=False),
    ]
    show_statistics: reactive[bool] = reactive(False)

    def __init__(self, project_root: Path, config: dict | None = None):
        super().__init__()
        self.project_root = project_root.resolve()
        self._config = config or {}
        self._project_name = self._config.get("project", {}).get("name") or "Project"
        mention_folders = self._config.get("mentions", {}).get("folders") or [
            "characters",
            "places",
        ]
        word_count_cfg = self._config.get("word_count", {})

        self.file_manager = FileManager(
            project_root=self.project_root,
            mention_folders=mention_folders,
            stats_path=self.project_root / "aengus_stats.csv",
        )

        self.word_counter = WordCounter(
            project_root=self.project_root,
            tracked_folders=word_count_cfg.get("folders") or ["novel"],
            goal=word_count_cfg.get("goal"),
        )

        self._left_file: Path | None = None
        self._right_file: Path | None = None
        self._left_last_file: Path | None = None
        self._right_last_file: Path | None = None
        self._active_pane: str = "left"
        self._picker_open: bool = False
        self._current_welcome_frame = 0
        self._max_welcome_frames = 48
        self._mention_timer = None

    # ------------------------------------------------------------------ compose & mount

    def compose(self) -> ComposeResult:
        with Horizontal(id="header-bar"):
            yield Static("Word Count: ", id="header-wordcount")
            yield Static(self._project_name, id="header-center")
            yield Static("0:00:00", id="header-timer")

        yield FilePicker(id="file-picker")

        with Horizontal(id="main-area"):
            with Container(id="editor-container-left", classes="editor-pane-secondary"):
                yield AengusEditor(id="editor-left")
                yield Static(
                    "Start your story..", id="welcome-screen-left", classes="welcome-screen"
                )
            with Container(id="editor-container-right", classes="editor-pane-main"):
                yield AengusEditor(id="editor-right")
                yield Static(
                    random_welcome_screen(welcome_screen_cow),
                    id="welcome-screen-right",
                    classes="welcome-screen",
                )
            yield MentionSwatch(id="swatch")
            yield Statistics(id="statistics")
        yield AengusFooter(id="footer")

    def on_mount(self) -> None:
        self._start_time = monotonic()
        self._header_timer = self.query_one("#header-timer", Static)
        self._header_wordcount = self.query_one("#header-wordcount", Static)
        self._editor_left = self.query_one("#editor-left", AengusEditor)
        self._editor_right = self.query_one("#editor-right", AengusEditor)
        self._swatch = self.query_one("#swatch", MentionSwatch)
        self.query_one("#statistics").display = False
        self.set_interval(1, self._tick_timer)
        self._animation = self.set_interval(0.05, self._animate_welcome_screen)
        self._refresh_header()
        self._index_files()
        self._switch_pane("right")

    # ------------------------------------------------------------------ pane helpers

    def _get_pane_file(self, pane: str) -> Path | None:
        return self._left_file if pane == "left" else self._right_file

    def _set_pane_file(self, pane: str, path: Path | None) -> None:
        if pane == "left":
            self._left_file = path
        else:
            self._right_file = path
        self.query_one(f"#welcome-screen-{pane}", Static).display = path is None

    def _get_pane_editor(self, pane: str) -> AengusEditor:
        return self._editor_left if pane == "left" else self._editor_right

    def _get_pane_last_file(self, pane: str) -> Path | None:
        return self._left_last_file if pane == "left" else self._right_last_file

    def _set_pane_last_file(self, pane: str, path: Path | None) -> None:
        if pane == "left":
            self._left_last_file = path
        else:
            self._right_last_file = path

    @property
    def _active_editor(self) -> AengusEditor:
        return self._get_pane_editor(self._active_pane)

    @property
    def _active_file(self) -> Path | None:
        return self._get_pane_file(self._active_pane)

    # ------------------------------------------------------------------ focus / pane switching

    def _switch_pane(self, pane: str) -> None:
        changed = pane != self._active_pane
        self._active_pane = pane
        self._editor_left.set_class(pane == "left", "active-editor")
        self._editor_right.set_class(pane == "right", "active-editor")
        self.query_one("#editor-container-left").set_class(pane == "left", "active-pane")
        self.query_one("#editor-container-right").set_class(pane == "right", "active-pane")
        self._active_editor.focus()
        if changed:
            self._check_for_mentions()
            self._refresh_header()
            self._refresh_header_center()

    def action_focus_left(self) -> None:
        self._switch_pane("left")

    def action_focus_right(self) -> None:
        self._switch_pane("right")

    @on(AengusEditor.Focused)
    def on_editor_focused(self, event: AengusEditor.Focused) -> None:
        if event.editor.id == "editor-left":
            self._switch_pane("left")
        elif event.editor.id == "editor-right":
            self._switch_pane("right")

    # ------------------------------------------------------------------ timer & animation

    def _tick_timer(self) -> None:
        elapsed = int(monotonic() - self._start_time)
        h, remainder = divmod(elapsed, 3600)
        m, s = divmod(remainder, 60)
        self._header_timer.update(f"{h}:{m:02}:{s:02}")

    def _animate_welcome_screen(self) -> None:
        animation_text = get_animation_frame(
            frame_count=self._current_welcome_frame,
            total_frames=self._max_welcome_frames,
            welcome_screen=welcome_screen_cow,
        )
        self.query_one("#welcome-screen-right", Static).update(animation_text)
        if self._current_welcome_frame >= self._max_welcome_frames:
            self._animation.stop()
            return
        self._current_welcome_frame += 1

    # ------------------------------------------------------------------ header

    def _refresh_header(self) -> None:
        self._header_wordcount.update(self.word_counter.format_wordcount(self._active_file))

    def _refresh_header_center(self) -> None:
        header_center = self.query_one("#header-center", Static)
        if not header_center:
            return
        if self._active_file is not None:
            relative_path = self._active_file.relative_to(self.project_root)
            header_center.update(f"Editing: {relative_path}")
        else:
            header_center.update(self._project_name)

    # ------------------------------------------------------------------ indexing & mentions

    def _index_files(self) -> None:
        mentions_metadata = self.file_manager.get_mentions_metadata()
        self._swatch.set_mentions(mentions_metadata)
        self._editor_left.highlight_mentions(self._swatch.mentions)
        self._editor_right.highlight_mentions(self._swatch.mentions)

    @on(AengusEditor.Changed)
    def on_editor_changed(self, event: AengusEditor.Changed) -> None:
        editor = event.editor
        file = self._left_file if editor.id == "editor-left" else self._right_file
        if file is not None:
            self.word_counter.update(file, editor.text)
        self._refresh_header()
        self._schedule_mention_check()

    def _schedule_mention_check(self) -> None:
        if self._mention_timer is not None:
            self._mention_timer.stop()
        self._mention_timer = self.set_timer(0.3, self._check_for_mentions)

    def _check_for_mentions(self) -> None:
        self._mention_timer = None
        self._swatch.update_mentions(self._active_editor.text, self._active_file)

    @on(MentionSwatch.NameSelected)
    def on_swatch_name_selected(self, event: MentionSwatch.NameSelected) -> None:
        self.action_save()
        self.open_file(path=self.project_root / event.category / f"{event.name}.md")

    @on(AengusEditor.OpenMention)
    def on_open_mention(self, event: AengusEditor.OpenMention) -> None:
        path = self.project_root / event.folder / f"{event.name}.md"
        if not path.is_file():
            return
        self.action_save()
        other = "right" if self._active_pane == "left" else "left"
        current_in_other = self._get_pane_file(other)
        if current_in_other is not None:
            self._set_pane_last_file(other, current_in_other)
        text = self.file_manager.read_file(path)
        self._set_pane_file(other, path)
        self._get_pane_editor(other).text = text
        # Keep focus on the current editor
        self._editor_left.set_class(self._active_pane == "left", "active-editor")
        self._editor_right.set_class(self._active_pane == "right", "active-editor")
        self.query_one("#editor-container-left").set_class(
            self._active_pane == "left", "active-pane"
        )
        self.query_one("#editor-container-right").set_class(
            self._active_pane == "right", "active-pane"
        )

    # ------------------------------------------------------------------ file operations

    def action_save(self) -> None:
        for pane in ("left", "right"):
            file = self._get_pane_file(pane)
            editor = self._get_pane_editor(pane)
            if file:
                self.file_manager.save_file(path=file, content=editor.text)

    def _target_pane(self) -> str:
        """Decide which pane should receive a newly opened file.

        If the active pane already has a file and the other pane is empty,
        open in the empty one so both panes are utilised.
        """
        other = "right" if self._active_pane == "left" else "left"
        if self._active_file is not None and self._get_pane_file(other) is None:
            return other
        return self._active_pane

    def open_file(self, path: Path, remember: bool = True) -> None:
        if not path.is_file():
            return
        self.action_save()
        target = self._target_pane()
        current = self._get_pane_file(target)
        if remember and current is not None:
            self._set_pane_last_file(target, current)

        text = self.file_manager.read_file(path)
        self._set_pane_file(target, path)
        self._get_pane_editor(target).text = text
        self._switch_pane(target)
        self._refresh_header()
        self._refresh_header_center()
        self._check_for_mentions()

    # ------------------------------------------------------------------ close / back / quit

    def action_close(self) -> None:
        if self._active_file is not None:
            self._set_pane_last_file(self._active_pane, self._active_file)
        self.action_save()
        self._set_pane_file(self._active_pane, None)
        self._active_editor.text = ""
        self._refresh_header()
        self._refresh_header_center()
        self._check_for_mentions()

    def action_back(self) -> None:
        last = self._get_pane_last_file(self._active_pane)
        if last is not None and last.is_file():
            self.action_save()
            self._set_pane_last_file(self._active_pane, self._active_file)
            text = self.file_manager.read_file(last)
            self._set_pane_file(self._active_pane, last)
            self._active_editor.text = text
            self._refresh_header()
            self._refresh_header_center()
            self._check_for_mentions()

    def action_quit(self) -> None:
        self.action_save()
        self.word_counter.reindex()
        elapsed = monotonic() - self._start_time
        minutes = max(1, math.ceil(elapsed / 60))
        self.file_manager.append_session_stats(minutes, self.word_counter.total)
        self.exit()

    # ------------------------------------------------------------------ file picker

    def action_new_file(self) -> None:
        if self.show_statistics:
            return
        picker = self.query_one("#file-picker", FilePicker)
        if self._picker_open and picker.mode == PickerMode.NEW:
            self.action_close_finder()
            return
        self.action_save()
        picker.open_new(self.project_root)
        self._picker_open = True

    @on(FilePicker.NewFileRequested)
    def on_new_file_requested(self, event: FilePicker.NewFileRequested) -> None:
        if not self.file_manager.is_inside_project(event.path):
            self.notify("Path must be inside project", timeout=1.5)
            return

        if event.path.exists():
            self.notify("File already exists", timeout=1.5)
            return

        self.file_manager.create_file(event.path)
        self._index_files()
        self.action_close_finder()
        self.open_file(event.path)

    def action_open_finder(self) -> None:
        if self.show_statistics:
            return
        picker = self.query_one("#file-picker", FilePicker)
        if self._picker_open and picker.mode == PickerMode.OPEN:
            self.action_close_finder()
            return
        self._index_files()
        picker.open(self.file_manager.all_files, self.project_root)
        self._picker_open = True

    def action_close_finder(self) -> None:
        if self.show_statistics:
            return
        picker = self.query_one("#file-picker", FilePicker)
        picker.close()
        self._picker_open = False
        self._active_editor.focus()

    @on(ListView.Selected, "#file-search-results")
    def on_file_selected_from_picker(self, event: ListView.Selected) -> None:
        if self.show_statistics:
            return
        if event.item.name == "__folder__":
            return
        picker = self.query_one("#file-picker", FilePicker)
        path = Path(event.item.name)
        if picker.mode == PickerMode.DELETE:
            self.action_close_finder()
            self._confirm_and_delete(path=path)
        else:
            self.action_close_finder()
            self.open_file(path=path)

    # ------------------------------------------------------------------ delete

    def action_delete_file(self) -> None:
        if self.show_statistics:
            return
        picker = self.query_one("#file-picker", FilePicker)
        if self._picker_open and picker.mode == PickerMode.DELETE:
            self.action_close_finder()
            return
        if self._active_file is not None:
            self._confirm_and_delete(self._active_file)
        else:
            self._index_files()
            picker.open_delete(self.file_manager.all_files, self.project_root)
            self._picker_open = True

    def _confirm_and_delete(self, path: Path) -> None:
        def _handle_result(confirmed: bool) -> None:
            if not confirmed:
                return
            self._do_delete(path)

        self.push_screen(ConfirmDeleteScreen(path, self.project_root), _handle_result)

    def _do_delete(self, path: Path) -> None:
        resolved = path.resolve()
        for pane in ("left", "right"):
            file = self._get_pane_file(pane)
            if file is not None and file.resolve() == resolved:
                self._get_pane_editor(pane).text = ""
                self._set_pane_file(pane, None)
                self._set_pane_last_file(pane, None)
            last = self._get_pane_last_file(pane)
            if last is not None and last.resolve() == resolved:
                self._set_pane_last_file(pane, None)

        self.word_counter.remove(path)
        try:
            self.file_manager.delete_file(path)
        except OSError as exc:
            self.notify(f"Could not delete: {exc}", timeout=2)
            return

        self._index_files()
        self._refresh_header()
        self._refresh_header_center()

    @on(FilePicker.DeleteFileRequested)
    def on_delete_file_requested(self, event: FilePicker.DeleteFileRequested) -> None:
        self.action_close_finder()
        self._confirm_and_delete(event.path)

    # ------------------------------------------------------------------ statistics

    def action_statistics(self) -> None:
        self.show_statistics = not self.show_statistics

        statistics = self.query_one("#statistics", Statistics)
        left_container = self.query_one("#editor-container-left")
        right_container = self.query_one("#editor-container-right")
        header_center = self.query_one("#header-center", Static)

        if self.show_statistics:
            header_center.update(f"{self._project_name} Statistics")
            statistics.display = True
            left_container.display = False
            right_container.display = False
            self._swatch.display = False
            statistics.show()
        else:
            self._refresh_header_center()
            statistics.display = False
            left_container.display = True
            right_container.display = True
            self._swatch.display = True
