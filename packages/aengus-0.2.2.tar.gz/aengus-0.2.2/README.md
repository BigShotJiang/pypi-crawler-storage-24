# Aengus

A tui writing app.

### Setup

Install environment with `uv sync`.


## Installation

Install with `pip install .`

On windows add the `Scripts` folder to `PATH` if you have not already.

Then create a project with `aengus new <PROJECT_NAME>` and open with `aengus open <PROJECT_NAME>`.

Or get help with `aengus -h`.
