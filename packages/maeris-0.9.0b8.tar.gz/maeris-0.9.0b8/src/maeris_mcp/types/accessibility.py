"""Accessibility (WCAG) scanning types."""

from enum import Enum

from pydantic import BaseModel, ConfigDict, Field


class WcagImpact(str, Enum):
    """WCAG finding impact levels."""

    MINOR = "minor"
    MODERATE = "moderate"
    SERIOUS = "serious"
    CRITICAL = "critical"


class WcagResultType(str, Enum):
    """Whether the check passed or was a violation."""

    PASS = "pass"
    VIOLATION = "violation"


class WcagFinding(BaseModel):
    """A single WCAG accessibility finding."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    impact: WcagImpact
    rule_id: str = Field(alias="ruleId")
    tags: list[str] = Field(default_factory=list)
    description: str
    help_url: str = Field(default="", alias="helpUrl")
    nodes: list[dict] = Field(default_factory=list)
    result_type: WcagResultType = Field(default=WcagResultType.VIOLATION, alias="resultType")
    file_path: str = Field(default="", alias="filePath")
    line_start: int = Field(default=0, alias="lineStart")
    line_end: int | None = Field(default=None, alias="lineEnd")
    code_snippet: str | None = Field(default=None, alias="codeSnippet")
    component_id: str = Field(default="", alias="componentId")
    page_id: str = Field(default="", alias="pageId")


class WcagSeverityCounts(BaseModel):
    """Count of findings by impact."""

    minor: int = 0
    moderate: int = 0
    serious: int = 0
    critical: int = 0


class WcagScanSummary(BaseModel):
    """Summary statistics for a WCAG scan."""

    model_config = ConfigDict(populate_by_name=True)

    total_findings: int = Field(alias="totalFindings")
    by_impact: WcagSeverityCounts = Field(alias="byImpact")
    files_scanned: int = Field(default=0, alias="filesScanned")
    compliance_score: float = Field(default=100.0, alias="complianceScore")


class WcagScanResult(BaseModel):
    """Complete WCAG scan result."""

    model_config = ConfigDict(populate_by_name=True)

    scan_id: str = Field(alias="scanId")
    target_path: str = Field(alias="targetPath")
    scan_timestamp: str = Field(alias="scanTimestamp")
    summary: WcagScanSummary
    findings: list[WcagFinding] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)


class StoredWcagScan(BaseModel):
    """Stored WCAG scan with metadata."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    target_path: str = Field(alias="targetPath")
    result: WcagScanResult
    stored_at: str = Field(alias="storedAt")
    last_accessed: str = Field(alias="lastAccessed")
    status: str = "pending"
    file_list: list[str] = Field(default_factory=list, alias="fileList")
    pushed_to_maeris: bool = Field(default=False, alias="pushedToMaeris")
    pushed_at: str | None = Field(default=None, alias="pushedAt")
