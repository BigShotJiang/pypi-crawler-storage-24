"""Thread-safe in-memory storage for spell/grammar scan results."""

import hashlib
import os
import threading
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

import structlog

from maeris_mcp.types.spell_grammar import (
    SpellGrammarCorrection,
    SpellGrammarScanResult,
    SpellGrammarScanSummary,
    StoredSpellGrammarScan,
)

logger = structlog.get_logger()


@dataclass
class SpellGrammarScanMeta:
    scan_root: str
    base_for_rel: str


@dataclass
class SpellGrammarScanIndexes:
    by_file: dict[str, list[str]] = field(default_factory=dict)
    by_type: dict[str, list[str]] = field(default_factory=dict)
    by_id: dict[str, SpellGrammarCorrection] = field(default_factory=dict)
    fingerprints: set[str] = field(default_factory=set)
    files_served: set[str] = field(default_factory=set)
    files_acknowledged: set[str] = field(default_factory=set)
    last_served_batch: list[str] = field(default_factory=list)


class SpellGrammarScanStore:
    """Thread-safe storage for spell/grammar scan results."""

    def __init__(self, max_scans: int = 50) -> None:
        self._lock = threading.RLock()
        self._scans: dict[str, StoredSpellGrammarScan] = {}
        self._meta: dict[str, SpellGrammarScanMeta] = {}
        self._indexes: dict[str, SpellGrammarScanIndexes] = {}
        self._max_scans = max_scans

    def create_scan(
        self,
        result: SpellGrammarScanResult,
        file_list: list[str],
        scan_root: str,
        base_for_rel: str,
    ) -> str:
        with self._lock:
            self._enforce_max_size()
            now = datetime.now(timezone.utc).isoformat()
            stored = StoredSpellGrammarScan(
                id=result.scan_id,
                target_path=result.target_path,
                result=result,
                stored_at=now,
                last_accessed=now,
                status="pending",
                file_list=file_list,
                pushed_to_maeris=False,
                pushed_at=None,
            )
            self._scans[result.scan_id] = stored
            self._meta[result.scan_id] = SpellGrammarScanMeta(scan_root=scan_root, base_for_rel=base_for_rel)
            self._indexes[result.scan_id] = SpellGrammarScanIndexes()
            return result.scan_id

    def get(self, scan_id: str) -> StoredSpellGrammarScan | None:
        with self._lock:
            if scan := self._scans.get(scan_id):
                scan.last_accessed = datetime.now(timezone.utc).isoformat()
                return scan
            return None

    def get_all(self) -> list[StoredSpellGrammarScan]:
        with self._lock:
            return list(self._scans.values())

    def get_meta(self, scan_id: str) -> SpellGrammarScanMeta | None:
        with self._lock:
            return self._meta.get(scan_id)

    def add_corrections(self, scan_id: str, corrections: list[SpellGrammarCorrection]) -> dict[str, int]:
        with self._lock:
            scan = self._scans.get(scan_id)
            indexes = self._indexes.get(scan_id)
            if not scan or not indexes:
                return {"added": 0, "deduped": 0}
            if scan.status == "completed":
                return {"added": 0, "deduped": 0}

            added = 0
            deduped = 0
            for correction in corrections:
                fingerprint = self._fingerprint(correction)
                if fingerprint in indexes.fingerprints:
                    deduped += 1
                    continue
                indexes.fingerprints.add(fingerprint)
                scan.result.corrections.append(correction)
                self._index_correction(indexes, correction)
                added += 1
            return {"added": added, "deduped": deduped}

    def record_files_served(self, scan_id: str, file_paths: list[str]) -> None:
        with self._lock:
            if idx := self._indexes.get(scan_id):
                idx.last_served_batch = list(file_paths)
                idx.files_served.update(file_paths)

    def acknowledge_last_batch(self, scan_id: str) -> None:
        with self._lock:
            if idx := self._indexes.get(scan_id):
                idx.files_acknowledged.update(idx.last_served_batch)

    def finalize_scan(self, scan_id: str) -> StoredSpellGrammarScan | None:
        with self._lock:
            scan = self._scans.get(scan_id)
            if not scan:
                return None
            files_scanned = len(scan.file_list)
            scan.result.summary = self._compute_summary(scan.result.corrections, files_scanned)
            scan.status = "completed"
            return scan

    def mark_pushed(self, scan_id: str) -> None:
        with self._lock:
            scan = self._scans.get(scan_id)
            if scan:
                scan.pushed_to_maeris = True
                scan.pushed_at = datetime.now(timezone.utc).isoformat()

    def delete(self, scan_id: str) -> bool:
        with self._lock:
            if scan_id not in self._scans:
                return False
            del self._scans[scan_id]
            self._meta.pop(scan_id, None)
            self._indexes.pop(scan_id, None)
            return True

    def clear(self) -> int:
        with self._lock:
            count = len(self._scans)
            self._scans.clear()
            self._meta.clear()
            self._indexes.clear()
            return count

    def _enforce_max_size(self) -> None:
        if len(self._scans) < self._max_scans:
            return
        oldest_id = min(self._scans.keys(), key=lambda k: self._scans[k].stored_at)
        del self._scans[oldest_id]
        self._meta.pop(oldest_id, None)
        self._indexes.pop(oldest_id, None)

    @staticmethod
    def _fingerprint(correction: SpellGrammarCorrection) -> str:
        key = f"{correction.file_path}|{correction.incorrect}|{correction.correct}"
        return hashlib.md5(key.encode()).hexdigest()[:16]

    @staticmethod
    def _index_correction(indexes: SpellGrammarScanIndexes, correction: SpellGrammarCorrection) -> None:
        indexes.by_id[correction.id] = correction
        if correction.file_path:
            indexes.by_file.setdefault(correction.file_path, []).append(correction.id)
        indexes.by_type.setdefault(correction.correction_type, []).append(correction.id)

    @staticmethod
    def _compute_summary(corrections: list[SpellGrammarCorrection], files_scanned: int) -> SpellGrammarScanSummary:
        spelling = sum(1 for c in corrections if c.correction_type == "spelling")
        grammar = len(corrections) - spelling

        return SpellGrammarScanSummary(
            total_corrections=len(corrections),
            spelling_count=spelling,
            grammar_count=grammar,
            files_scanned=files_scanned,
        )


# ---------------------------------------------------------------------------
# Persistent disk cache — module-level helpers
# ---------------------------------------------------------------------------

def _get_spell_grammar_cache_path(scan_root: str) -> Path:
    """Return the path to the persistent spell/grammar corrections JSON for this scan root."""
    root_hash = hashlib.sha256(scan_root.encode()).hexdigest()[:16]
    base = Path(os.getenv("MAERIS_CONFIG_DIR") or Path.home() / ".maeris")
    cache_dir = base / "spell_grammar_scans" / root_hash
    cache_dir.mkdir(parents=True, exist_ok=True)
    return cache_dir / "corrections.json"


def save_spell_grammar_to_disk(scan_root: str, stored: StoredSpellGrammarScan) -> None:
    """Persist a finalized spell/grammar scan to disk for later push retry."""
    try:
        cache_path = _get_spell_grammar_cache_path(scan_root)
        cache_path.write_text(stored.model_dump_json(by_alias=True, indent=2))
        logger.info("spell_grammar_cache.saved", path=str(cache_path), corrections=len(stored.result.corrections))
    except Exception as e:
        logger.warning("spell_grammar_cache.save_failed", error=str(e))


def load_spell_grammar_from_disk(scan_root: str) -> StoredSpellGrammarScan | None:
    """Load a previously cached spell/grammar scan from disk."""
    cache_path = _get_spell_grammar_cache_path(scan_root)
    if not cache_path.exists():
        return None
    try:
        return StoredSpellGrammarScan.model_validate_json(cache_path.read_text())
    except Exception as e:
        logger.warning("spell_grammar_cache.load_failed", error=str(e))
        return None
