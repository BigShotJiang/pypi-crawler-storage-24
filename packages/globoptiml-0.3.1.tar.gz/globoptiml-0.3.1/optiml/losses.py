"""Integer loss functions for CP-SAT optimisation.

Losses create auxiliary CP-SAT variables and constraints so that the
objective expression stays linear (required by ``CpModel.minimize``).
"""

import numpy as np


class Loss:
    """Base class for all OptiML losses."""

    def __call__(self, y_pred, y_true, solver_model):
        return self.compute(y_pred, y_true, solver_model)

    def compute(self, y_pred, y_true, solver_model):
        raise NotImplementedError


class SAELoss(Loss):
    """Sum of Absolute Errors  —  sum |y_pred − y_true|.

    Implemented via ``AddAbsEquality``.  Safe with any weight range
    because it never squares the error.
    """

    def compute(self, predictions, targets, solver_model):
        m = solver_model.model
        parts = []

        for pred, target in zip(predictions, targets):
            p_flat = pred.data.flatten()
            t_flat = np.atleast_1d(target).flatten()
            for p_val, t_val in zip(p_flat, t_flat):
                ae = solver_model.create_variable(shape=(1,), lb=0)
                m.add_abs_equality(ae.data[0], p_val - int(t_val))
                parts.append(ae.data[0])

        return sum(parts)


class SSELoss(Loss):
    """Sum of Squared Errors  —  sum (y_pred − y_true)².

    Each squared term is modelled with ``AddMultiplicationEquality``.

    .. warning::
       With wide weight ranges (e.g. full int16) the squared values
       may overflow int64.  Use :class:`SAELoss` if that is a concern.
    """

    def compute(self, predictions, targets, solver_model):
        m = solver_model.model
        parts = []

        for pred, target in zip(predictions, targets):
            p_flat = pred.data.flatten()
            t_flat = np.atleast_1d(target).flatten()
            for p_val, t_val in zip(p_flat, t_flat):
                err = solver_model.create_variable(shape=(1,))
                m.add(err.data[0] == p_val - int(t_val))

                sq = solver_model.create_variable(shape=(1,), lb=0)
                m.add_multiplication_equality(
                    sq.data[0], [err.data[0], err.data[0]],
                )
                parts.append(sq.data[0])

        return sum(parts)
