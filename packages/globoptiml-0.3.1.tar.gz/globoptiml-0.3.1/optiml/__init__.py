"""OptiML — train neural networks via integer optimisation (CP-SAT)."""

__version__ = "0.3.0"

from .layers import OptiModule, Linear, ReLU, Flatten
from .model import Sequential
from .solver import SolverVariable, SolverModel
from . import losses

__all__ = [
    "OptiModule",
    "Sequential",
    "Linear",
    "ReLU",
    "Flatten",
    "SolverVariable",
    "SolverModel",
    "losses",
]
