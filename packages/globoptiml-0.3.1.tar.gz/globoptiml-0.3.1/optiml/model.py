"""High-level Sequential model for binary-weight neural-network optimisation."""

import os
from collections import OrderedDict

import numpy as np
from ortools.sat.python import cp_model

from .solver import SolverModel, SolverVariable
from .layers import OptiModule
from .losses import Loss, SAELoss


class Sequential(OptiModule):
    """Ordered container of OptiML layers with fit / export capabilities.

    Edge weights are binary {0, 1}.  Biases are bounded integers.

    Example::

        import optiml

        model = optiml.Sequential(
            optiml.Linear(4, 3),
            optiml.ReLU(),
            optiml.Linear(3, 3),
        )
        model.fit(X_train, y_train)
        pytorch_model = model.export('pytorch')
    """

    def __init__(self, *layers):
        super().__init__()
        self._layers = OrderedDict()
        for i, layer in enumerate(layers):
            name = f"{layer.__class__.__name__.lower()}_{i}"
            self._layers[name] = layer

        self._solver_model: SolverModel | None = None
        self._fitted = False
        self.input_scale: int = 1
        self.target_scale: int = 1

    # ------------------------------------------------------------------
    def forward(self, x, solver_model):
        out = x
        for layer in self._layers.values():
            out = layer(out, solver_model)
        return out

    # ------------------------------------------------------------------
    def fit(
        self,
        X,
        y,
        loss=None,
        input_scale=100,
        target_scale=100,
        bias_bounds=(-1000, 1000),
        time_limit=None,
        num_workers=None,
        tee=True,
        verbose=True,
    ):
        """Build the CP-SAT model and solve it.

        Parameters
        ----------
        X : array-like, shape (n_samples, n_features)
            Training inputs (float, will be scaled to integers).
        y : array-like
            Training targets (float, will be scaled to integers).
        loss : Loss, optional
            Loss function.  Default: ``SAELoss()``.
        input_scale : int
            Inputs are multiplied by this and rounded to int.
        target_scale : int
            Targets are multiplied by this and rounded to int.
        bias_bounds : tuple[int, int]
            (lower, upper) bounds for bias parameters.
            Edge weights are always binary {0, 1}.
        time_limit : float or None
            Max solver wall-clock seconds.
        num_workers : int or None
            CPU threads.  ``None`` → all available cores.
        tee : bool
            Show solver log.
        verbose : bool
            Print progress messages.
        """
        if loss is None:
            loss = SAELoss()

        X_f = np.asarray(X, dtype=np.float64)
        y_f = np.asarray(y, dtype=np.float64)

        self.input_scale = input_scale
        self.target_scale = target_scale

        X_int = np.rint(X_f * input_scale).astype(np.int64)
        y_int = np.rint(y_f * target_scale).astype(np.int64)

        for layer in self._layers.values():
            layer._bias_bounds = bias_bounds

        sm = SolverModel()
        self._solver_model = sm

        n_samples = len(X_int)
        if verbose:
            print(f"[OptiML] Building model for {n_samples} samples …")
            print(f"[OptiML] Scales: input×{input_scale}  target×{target_scale}")
            print(f"[OptiML] Bias bounds: {bias_bounds}")
            print(f"[OptiML] Weights: binary {{0, 1}}")

        predictions = []
        for i in range(n_samples):
            x_in = SolverVariable(X_int[i])
            predictions.append(self.forward(x_in, sm))

        if verbose:
            print(f"[OptiML] {sm._var_counter} variable groups created")
            print(f"[OptiML] Computing {loss.__class__.__name__} …")

        obj_expr = loss(predictions, y_int, sm)
        sm.set_objective(obj_expr, minimize=True)

        n_workers = num_workers or os.cpu_count() or 1
        if verbose:
            print(f"[OptiML] Solving with CP-SAT ({n_workers} workers) …")

        status = sm.solve(num_workers=n_workers, time_limit=time_limit, tee=tee)
        self._fitted = True

        if verbose:
            print(f"[OptiML] Status: {sm.status_name}")
            if status in (cp_model.OPTIMAL, cp_model.FEASIBLE):
                print(f"[OptiML] Objective value: {sm.objective_value}")

        return status

    # ------------------------------------------------------------------
    @property
    def objective_value(self):
        if not self._fitted:
            raise RuntimeError("Call .fit() first.")
        return self._solver_model.objective_value

    # ------------------------------------------------------------------
    def export(self, backend="pytorch"):
        """Export fitted model to a target framework.

        The exported PyTorch model expects **integer-scaled** inputs
        (i.e. ``np.rint(X * input_scale)``).  Its raw outputs
        can be compared via ``argmax`` for classification.
        """
        if not self._fitted:
            raise RuntimeError("Call .fit() first.")
        if backend == "pytorch":
            return self._export_pytorch()
        raise ValueError(f"Unknown backend '{backend}'")

    def _export_pytorch(self):
        import torch.nn as nn

        parts = []
        for name, layer in self._layers.items():
            parts.append((name, layer.to_pytorch(self._solver_model)))
        return nn.Sequential(OrderedDict(parts))

    # ------------------------------------------------------------------
    def __repr__(self):
        lines = ["Sequential("]
        for name, layer in self._layers.items():
            lines.append(f"  ({name}): {layer.__class__.__name__}()")
        lines.append(")")
        return "\n".join(lines)
