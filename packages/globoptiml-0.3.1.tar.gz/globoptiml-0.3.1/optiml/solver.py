"""OR-Tools CP-SAT backend for integer optimisation."""

import os

import numpy as np
from ortools.sat.python import cp_model


class SolverVariable:
    """Numpy array of CP-SAT IntVars or plain integer constants."""

    def __init__(self, data):
        self.data = np.asarray(data, dtype=object)

    @property
    def shape(self):
        return self.data.shape

    @property
    def is_constant(self):
        return all(isinstance(v, (int, np.integer)) for v in self.data.flat)

    def __getitem__(self, key):
        result = self.data[key]
        if isinstance(result, np.ndarray):
            return SolverVariable(result)
        return result


class SolverModel:
    """Wraps a CP-SAT CpModel for building and solving integer programmes."""

    _DEFAULT_RANGE = 10 ** 15

    def __init__(self):
        self.model = cp_model.CpModel()
        self._var_counter = 0
        self._solver: cp_model.CpSolver | None = None
        self._status: int | None = None

    def create_variable(self, shape, lb=None, ub=None, name=None):
        lb = int(lb if lb is not None else -self._DEFAULT_RANGE)
        ub = int(ub if ub is not None else self._DEFAULT_RANGE)
        if name is None:
            name = f"v{self._var_counter}"
        self._var_counter += 1
        flat_size = int(np.prod(shape))
        arr = np.array(
            [self.model.new_int_var(lb, ub, f"{name}_{i}") for i in range(flat_size)],
            dtype=object,
        ).reshape(shape)
        return SolverVariable(arr)

    def create_bool_variable(self, shape, name=None):
        if name is None:
            name = f"b{self._var_counter}"
        self._var_counter += 1
        flat_size = int(np.prod(shape))
        arr = np.array(
            [self.model.new_bool_var(f"{name}_{i}") for i in range(flat_size)],
            dtype=object,
        ).reshape(shape)
        return SolverVariable(arr)

    def set_objective(self, expr, minimize=True):
        if minimize:
            self.model.minimize(expr)
        else:
            self.model.maximize(expr)

    def solve(self, num_workers=None, time_limit=None, tee=True):
        solver = cp_model.CpSolver()
        solver.parameters.num_workers = num_workers or os.cpu_count() or 1
        if time_limit is not None:
            solver.parameters.max_time_in_seconds = float(time_limit)
        solver.parameters.log_search_progress = bool(tee)
        status = solver.solve(self.model)
        self._solver = solver
        self._status = status
        return status

    def value(self, var):
        return self._solver.value(var)

    @property
    def objective_value(self):
        return self._solver.objective_value

    @property
    def status_name(self):
        return self._solver.status_name(self._status)
