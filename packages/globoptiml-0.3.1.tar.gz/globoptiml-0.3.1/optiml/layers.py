"""Neural-network layers for CP-SAT integer optimisation.

Edge weights are **binary** (0 or 1).  Biases are bounded integers.
"""

import numpy as np

from .solver import SolverVariable


class OptiModule:
    """Base class for all OptiML layers."""

    def __init__(self):
        self._parameters = {}
        self._bias_bounds = (-1000, 1000)

    def forward(self, x, solver_model):
        raise NotImplementedError

    def __call__(self, x, solver_model):
        return self.forward(x, solver_model)

    def _extract_weights(self, param_name, solver_model):
        sv = self._parameters[param_name]
        arr = np.empty(sv.shape, dtype=np.int64)
        for idx in np.ndindex(sv.shape):
            arr[idx] = solver_model.value(sv.data[idx])
        return arr

    def to_pytorch(self, solver_model):
        raise NotImplementedError(
            f"PyTorch export not implemented for {self.__class__.__name__}"
        )


class Linear(OptiModule):
    """Fully-connected layer with binary edge weights.

    y = W @ x + b  where  W ∈ {0,1}  and  b ∈ ℤ.

    For constant inputs (first layer) the product ``bool × const`` is
    a native CP-SAT linear expression.  For variable inputs (hidden
    layers) each product is modelled via reification — no big-M and
    no ``AddMultiplicationEquality`` needed.
    """

    def __init__(self, in_features, out_features):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features

    def _ensure_params(self, solver_model):
        if "weight" in self._parameters:
            return
        sm = solver_model
        self._parameters["weight"] = sm.create_bool_variable(
            (self.out_features, self.in_features),
            name=f"L{id(self)}_w",
        )
        lb, ub = self._bias_bounds
        self._parameters["bias"] = sm.create_variable(
            (self.out_features,), lb=lb, ub=ub,
            name=f"L{id(self)}_b",
        )

    def forward(self, x, solver_model):
        sm = solver_model
        m = sm.model
        self._ensure_params(sm)

        W = self._parameters["weight"]
        b = self._parameters["bias"]
        out = sm.create_variable(shape=(self.out_features,))

        x_flat = (
            x.data.flatten()
            if isinstance(x, SolverVariable)
            else np.asarray(x, dtype=object).flatten()
        )
        x_const = all(isinstance(v, (int, np.integer)) for v in x_flat)

        for j in range(self.out_features):
            if x_const:
                terms = sum(
                    int(x_flat[i]) * W.data[j, i]
                    for i in range(self.in_features)
                )
                m.add(out.data[j] == terms + b.data[j])
            else:
                products = []
                for i in range(self.in_features):
                    p = sm.create_variable(shape=(1,))
                    w_bool = W.data[j, i]
                    m.add(p.data[0] == x_flat[i]).only_enforce_if(w_bool)
                    m.add(p.data[0] == 0).only_enforce_if(w_bool.Not())
                    products.append(p.data[0])
                m.add(out.data[j] == sum(products) + b.data[j])

        return out

    def to_pytorch(self, solver_model):
        import torch
        import torch.nn as nn

        layer = nn.Linear(self.in_features, self.out_features)
        w = self._extract_weights("weight", solver_model).astype(np.float32)
        b = self._extract_weights("bias", solver_model).astype(np.float32)
        layer.weight.data = torch.tensor(w)
        layer.bias.data = torch.tensor(b)
        return layer


class ReLU(OptiModule):
    """ReLU activation: y = max(0, x).

    Uses CP-SAT's native ``AddMaxEquality`` — no big-M trick needed.
    """

    def forward(self, x, solver_model):
        m = solver_model.model
        out = solver_model.create_variable(shape=x.shape, lb=0)

        for idx in np.ndindex(x.shape):
            m.add_max_equality(out.data[idx], [x.data[idx], 0])

        return out

    def to_pytorch(self, solver_model):
        import torch.nn as nn

        return nn.ReLU()


class Flatten(OptiModule):
    """Flatten all dimensions into a single vector."""

    def forward(self, x, solver_model):
        return SolverVariable(x.data.flatten())

    def to_pytorch(self, solver_model):
        import torch.nn as nn

        return nn.Flatten(start_dim=1)
