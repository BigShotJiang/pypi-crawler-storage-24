"""Pytola Core - Essential utilities and components for Pytola applications.

This package provides core functionality including:
- Advanced logging system with colored output
- High DPI scaling support for Qt applications
- Security utilities for input validation
- Theme management system
- Environment configuration helpers
- Generic registry system for component management.
"""

__version__ = "0.1.18"

from .registry import DefaultRegistry, Registry, get_registry, register

__all__ = [
    "DefaultRegistry",
    "Registry",
    "get_registry",
    "register",
]
