"""File-based IPC controls for PyWiggum runner."""

import json
import os
import time
from datetime import datetime
from pathlib import Path


class Controls:
    """File-based controls for runner orchestration."""

    def __init__(self, work_dir: Path):
        """Initialize controls.

        Args:
            work_dir: Working directory for control files
        """
        self.work_dir = work_dir
        self.pause_file = work_dir / ".wiggum-pause"
        self.max_file = work_dir / ".wiggum-max"
        self.hint_file = work_dir / ".wiggum-hint"
        self.hints_archive_dir = work_dir / ".wiggum-hints-archive"
        self.state_file = work_dir / ".wiggum-state.json"

        # Ensure hints archive directory exists
        self.hints_archive_dir.mkdir(exist_ok=True)

    def is_paused(self) -> bool:
        """Check if runner is paused.

        Returns:
            True if pause file exists
        """
        return self.pause_file.exists()

    def pause(self) -> None:
        """Pause the runner by creating pause file."""
        self.pause_file.touch()

    def resume(self) -> None:
        """Resume the runner by removing pause file."""
        if self.pause_file.exists():
            self.pause_file.unlink()

    def get_max_iterations(self) -> int | None:
        """Get max iterations from control file.

        Returns:
            Max iterations if file exists and is valid, None otherwise
        """
        if not self.max_file.exists():
            return None

        try:
            content = self.max_file.read_text().strip()
            return int(content)
        except (ValueError, OSError):
            return None

    def set_max_iterations(self, max_iterations: int) -> None:
        """Set max iterations in control file.

        Args:
            max_iterations: New max iterations value
        """
        self.max_file.write_text(str(max_iterations))

    def add_iterations(self, additional: int) -> int:
        """Add iterations to the current max.

        Args:
            additional: Number of iterations to add

        Returns:
            New max iterations value
        """
        current = self.get_max_iterations()
        if current is None:
            current = 0

        new_max = current + additional
        self.set_max_iterations(new_max)
        return new_max

    def get_hint(self) -> str | None:
        """Get the current hint if one exists.

        Returns:
            Hint text or None if no hint file exists
        """
        if not self.hint_file.exists():
            return None

        try:
            return self.hint_file.read_text().strip()
        except OSError:
            return None

    def set_hint(self, hint: str) -> None:
        """Set a hint for the next iteration.

        Args:
            hint: Hint text
        """
        self.hint_file.write_text(hint)

    def consume_hint(self) -> str | None:
        """Consume the hint file (read and archive it).

        Returns:
            Hint text or None if no hint exists
        """
        hint = self.get_hint()
        if hint is None:
            return None

        # Archive the hint
        timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        archive_path = self.hints_archive_dir / f"hint-{timestamp}.txt"
        archive_path.write_text(hint)

        # Remove the hint file
        self.hint_file.unlink()

        return hint

    def wait_while_paused(self, check_interval: int = 2) -> None:
        """Wait in a loop while paused.

        Args:
            check_interval: Seconds between pause checks
        """
        while self.is_paused():
            time.sleep(check_interval)

    def write_state(self, iteration: int, task_id: str | None = None) -> None:
        """Write runner state (PID, iteration, heartbeat).

        Args:
            iteration: Current iteration number
            task_id: Current task ID if active
        """
        state = {
            "pid": os.getpid(),
            "iteration": iteration,
            "task_id": task_id,
            "updated_at": datetime.now().isoformat(),
        }
        self.state_file.write_text(json.dumps(state))

    def clear_state(self) -> None:
        """Remove state file on clean shutdown."""
        if self.state_file.exists():
            self.state_file.unlink()

    def read_state(self) -> dict | None:
        """Read runner state file.

        Returns:
            State dict or None if file doesn't exist
        """
        if not self.state_file.exists():
            return None
        try:
            return json.loads(self.state_file.read_text())
        except (json.JSONDecodeError, OSError):
            return None

    # --- Approval gate ---

    def _approval_path(self, task_id: str) -> Path:
        """Get path for an approval file."""
        safe_id = task_id.replace("/", "_").replace("\\", "_")
        return self.work_dir / f".wiggum-approval-{safe_id}.json"

    def request_approval(self, task_id: str, context: dict) -> None:
        """Write an approval request file.

        Args:
            task_id: Task that needs approval
            context: Dict with task_title, task_description, agent output, etc.
        """
        data = {
            "task_id": task_id,
            "status": "pending",
            "requested_at": datetime.now().isoformat(),
            "context": context,
        }
        self._approval_path(task_id).write_text(json.dumps(data, indent=2))

    def check_approval(self, task_id: str) -> str | None:
        """Check approval status for a task.

        Returns:
            "approved", "rejected", or None if pending/no request
        """
        path = self._approval_path(task_id)
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text())
            status = data.get("status", "pending")
            return status if status in ("approved", "rejected") else None
        except (json.JSONDecodeError, OSError):
            return None

    def set_approval(self, task_id: str, verdict: str, comment: str = "") -> bool:
        """Approve or reject a task.

        Args:
            task_id: Task to approve/reject
            verdict: "approved" or "rejected"
            comment: Optional reviewer comment

        Returns:
            True if approval file existed and was updated
        """
        path = self._approval_path(task_id)
        if not path.exists():
            return False
        try:
            data = json.loads(path.read_text())
            data["status"] = verdict
            data["comment"] = comment
            data["decided_at"] = datetime.now().isoformat()
            path.write_text(json.dumps(data, indent=2))
            return True
        except (json.JSONDecodeError, OSError):
            return False

    def clear_approval(self, task_id: str) -> None:
        """Remove an approval file."""
        path = self._approval_path(task_id)
        if path.exists():
            path.unlink()

    def check_auto_approval(self, task_id: str) -> bool:
        """Check if a pending approval should be auto-approved.

        Auto-approves if:
        - Claude score was >= 4
        - auto_approve_after timestamp has passed
        - Human has not already responded

        Returns:
            True if auto-approved
        """
        path = self._approval_path(task_id)
        if not path.exists():
            return False
        try:
            data = json.loads(path.read_text())
            if data.get("status") != "pending":
                return False

            auto_after = data.get("context", {}).get("auto_approve_after")
            if not auto_after:
                return False

            deadline = datetime.fromisoformat(auto_after)
            if datetime.now() >= deadline:
                # Auto-approve: update the file
                data["status"] = "approved"
                data["comment"] = "Auto-approved: Claude scored 4+, human timeout (1h)"
                data["decided_at"] = datetime.now().isoformat()
                path.write_text(json.dumps(data, indent=2))
                return True

        except (json.JSONDecodeError, OSError, ValueError):
            pass
        return False

    def list_pending_approvals(self) -> list[dict]:
        """List all pending approval requests.

        Returns:
            List of approval request dicts
        """
        pending = []
        for path in self.work_dir.glob(".wiggum-approval-*.json"):
            try:
                data = json.loads(path.read_text())
                if data.get("status") == "pending":
                    pending.append(data)
            except (json.JSONDecodeError, OSError):
                continue
        return pending

    def is_runner_alive(self) -> bool:
        """Check if the runner process is still alive.

        Returns:
            True if runner PID exists and process is running
        """
        state = self.read_state()
        if state is None:
            return False
        pid = state.get("pid")
        if pid is None:
            return False
        try:
            os.kill(pid, 0)
            return True
        except (ProcessLookupError, PermissionError):
            return False
