"""Command-line interface for PyWiggum."""

import json
import subprocess
import sys
from pathlib import Path

import click

from pywiggum import __version__
from pywiggum.config import WiggumConfig
from pywiggum.controls import Controls
from pywiggum.kanban import KanbanManager
from pywiggum.runner import Runner


@click.group()
@click.version_option(version=__version__)
def main() -> None:
    """PyWiggum - AI Agent Orchestrator with Dashboard.

    "Me fail English? That's unpossible!" — Ralph Wiggum
    """
    pass


@main.command()
@click.option("--force", is_flag=True, help="Overwrite existing files")
def init(force: bool) -> None:
    """Initialize a new PyWiggum project with templates."""
    config_path = Path("wiggum.yaml")
    kanban_path = Path("kanban.json")

    # Check if files exist
    if config_path.exists() and not force:
        click.echo(f"Error: {config_path} already exists. Use --force to overwrite.")
        sys.exit(1)

    if kanban_path.exists() and not force:
        click.echo(f"Error: {kanban_path} already exists. Use --force to overwrite.")
        sys.exit(1)

    # Create default config
    config = WiggumConfig()
    config.save(config_path)
    click.echo(f"Created {config_path}")

    # Create template kanban
    kanban = KanbanManager(kanban_path)
    board = kanban.create_template()
    kanban.save(board)
    click.echo(f"Created {kanban_path}")

    click.echo("\nProject initialized! Edit wiggum.yaml and kanban.json to customize.")
    click.echo("Run 'wiggum run' to start the autonomous loop.")


@main.command()
@click.option("--max-iterations", type=int, help="Override max iterations")
@click.option("--agent", help="Override agent backend")
@click.option("--model", help="Override model")
@click.option("--dash", is_flag=True, help="Also start dashboard in background")
def run(
    max_iterations: int | None, agent: str | None, model: str | None, dash: bool
) -> None:
    """Start the runner loop."""
    config_path = Path("wiggum.yaml")

    if not config_path.exists():
        click.echo("Error: wiggum.yaml not found. Run 'wiggum init' first.")
        sys.exit(1)

    # Load config
    config = WiggumConfig.load(config_path)

    # Apply overrides
    overrides = {}
    if max_iterations is not None:
        overrides["max_iterations"] = max_iterations
    if agent is not None:
        overrides["agent"] = agent
    if model is not None:
        overrides["model"] = model

    if overrides:
        config = config.merge_overrides(**overrides)

    # Start dashboard if requested
    if dash:
        click.echo("Starting dashboard in background...")
        subprocess.Popen(
            [sys.executable, "-m", "pywiggum.dashboard"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

    # Create and run
    try:
        runner = Runner(config)
        runner.run()
    except KeyboardInterrupt:
        click.echo("\nRunner interrupted by user")
        sys.exit(0)
    except Exception as e:
        click.echo(f"Error: {e}")
        sys.exit(1)


@main.command()
@click.option("--port", type=int, help="Override dashboard port")
@click.option("--host", help="Override dashboard host")
def dash(port: int | None, host: str | None) -> None:
    """Start the dashboard server."""
    config_path = Path("wiggum.yaml")

    if not config_path.exists():
        click.echo("Error: wiggum.yaml not found. Run 'wiggum init' first.")
        sys.exit(1)

    # Load config
    config = WiggumConfig.load(config_path)

    # Apply overrides
    overrides = {}
    if port is not None:
        overrides["port"] = port
    if host is not None:
        overrides["host"] = host

    if overrides:
        config = config.merge_overrides(**overrides)

    # Import and run dashboard
    from pywiggum.dashboard.server import start_server

    click.echo(f"Starting dashboard on {config.dashboard.host}:{config.dashboard.port}")
    start_server(config)


@main.command()
def status() -> None:
    """Print current status to terminal."""
    config_path = Path("wiggum.yaml")

    if not config_path.exists():
        click.echo("Error: wiggum.yaml not found. Run 'wiggum init' first.")
        sys.exit(1)

    config = WiggumConfig.load(config_path)
    controls = Controls(config.get_work_dir())
    kanban = KanbanManager(config.get_kanban_path())

    try:
        kanban.load()
    except FileNotFoundError:
        click.echo("Error: kanban.json not found")
        sys.exit(1)

    from pywiggum.history import HistoryTracker

    stats = kanban.get_stats()
    history = HistoryTracker(config.get_work_dir())
    history.load()

    # Runner state
    state = controls.read_state()
    runner_alive = controls.is_runner_alive()

    click.echo(f"Project: {config.project.name}")
    if runner_alive and state:
        click.echo(f"Runner: RUNNING (iteration {state.get('iteration', '?')}, pid {state.get('pid', '?')})")
        if state.get("task_id"):
            click.echo(f"Current task: {state['task_id']}")
    elif controls.is_paused():
        click.echo("Runner: PAUSED")
    else:
        click.echo("Runner: STOPPED")

    click.echo(f"Max iterations: {controls.get_max_iterations()}")

    # Progress bar
    progress = (stats["done"] / stats["total"] * 100) if stats["total"] > 0 else 0
    bar_width = 30
    filled = int(bar_width * stats["done"] / stats["total"]) if stats["total"] > 0 else 0
    bar = "█" * filled + "░" * (bar_width - filled)
    click.echo(f"\nProgress: [{bar}] {progress:.0f}% ({stats['done']}/{stats['total']})")
    if stats["failed"] > 0:
        click.echo(f"  Failed: {stats['failed']}")

    # Milestones
    click.echo(f"\nMilestones:")
    assert kanban.board is not None
    completed_ids = {m.id for m in kanban.board.milestones if kanban._is_milestone_done(m)}
    for milestone in kanban.board.milestones:
        m_stats = kanban.get_milestone_stats(milestone.id)
        blocked = any(b not in completed_ids for b in milestone.blocked_by)

        if m_stats["done"] == m_stats["total"] and m_stats["total"] > 0:
            icon = "✅"
        elif blocked:
            icon = "🔒"
        elif m_stats["done"] > 0:
            icon = "🔧"
        else:
            icon = "⬚ "
        click.echo(f"  {icon} {milestone.id}: {milestone.name} ({m_stats['done']}/{m_stats['total']})")

    # Tasks detail
    click.echo(f"\nTasks:")
    for milestone in kanban.board.milestones:
        for task in milestone.tasks:
            if task.status == "done":
                icon = "✅"
            elif task.status == "failed":
                icon = "❌"
            elif state and state.get("task_id") == task.id:
                icon = "⏳"
            else:
                # Check if actionable
                done_ids = set()
                for m in kanban.board.milestones:
                    for t in m.tasks:
                        if t.status == "done":
                            done_ids.add(t.id)
                blocked = any(b not in completed_ids for b in milestone.blocked_by)
                deps_met = all(d in done_ids for d in task.depends_on)
                if blocked or not deps_met:
                    icon = "🔒"
                else:
                    icon = "○ "
            type_label = f" [{task.type}]" if task.type else ""
            click.echo(f"  {icon} {task.id}: {task.title}{type_label}")

    # Pending approvals
    pending = controls.list_pending_approvals()
    if pending:
        click.echo(f"\nPending approvals:")
        for p in pending:
            ctx = p.get("context", {})
            score = ctx.get("claude_score")
            score_str = f" [Claude: {score}/5]" if score else ""
            auto = ctx.get("auto_approve_after")
            auto_str = ""
            if auto:
                from datetime import datetime as dt
                try:
                    deadline = dt.fromisoformat(auto)
                    remaining = deadline - dt.now()
                    mins = int(remaining.total_seconds() / 60)
                    if mins > 0:
                        auto_str = f" (auto-approve in {mins}m)"
                    else:
                        auto_str = " (auto-approve imminent)"
                except ValueError:
                    pass
            click.echo(
                f"  ⏸  {p['task_id']}: {ctx.get('task_title', '?')}"
                f"{score_str}{auto_str}"
            )
            rec = ctx.get("claude_recommendation")
            if rec:
                click.echo(f"      {rec[:120]}")

    # Velocity
    if history.completions:
        h_stats = history.get_stats()
        click.echo(f"\nVelocity:")
        click.echo(f"  Avg task duration: {h_stats['avg_duration_minutes']:.1f} min")
        click.echo(f"  Recent velocity: {h_stats['recent_velocity_minutes']:.1f} min/task")
        eta = history.predict_eta(stats["todo"])
        if eta:
            from datetime import datetime
            remaining = eta - datetime.now()
            hours = remaining.total_seconds() / 3600
            if hours > 0:
                click.echo(f"  ETA: {eta.strftime('%H:%M')} ({hours:.1f}h remaining)")


@main.command()
def pause() -> None:
    """Pause the runner."""
    config = WiggumConfig.load(Path("wiggum.yaml"))
    controls = Controls(config.get_work_dir())
    controls.pause()
    click.echo("Runner paused")


@main.command()
def resume() -> None:
    """Resume the runner."""
    config = WiggumConfig.load(Path("wiggum.yaml"))
    controls = Controls(config.get_work_dir())
    controls.resume()
    click.echo("Runner resumed")


@main.command()
@click.argument("text")
def hint(text: str) -> None:
    """Send hint to runner."""
    config = WiggumConfig.load(Path("wiggum.yaml"))
    controls = Controls(config.get_work_dir())
    controls.set_hint(text)
    click.echo("Hint sent to runner")


@main.command()
@click.argument("n", type=int)
def add_iterations(n: int) -> None:
    """Increase max iterations."""
    config = WiggumConfig.load(Path("wiggum.yaml"))
    controls = Controls(config.get_work_dir())
    new_max = controls.add_iterations(n)
    click.echo(f"Max iterations increased to {new_max}")


@main.command()
@click.argument("task_id")
@click.option("--reject", is_flag=True, help="Reject instead of approve")
@click.option("--comment", default="", help="Reviewer comment")
def approve(task_id: str, reject: bool, comment: str) -> None:
    """Approve or reject a pending task."""
    config = WiggumConfig.load(Path("wiggum.yaml"))
    controls = Controls(config.get_work_dir())

    # Check if there's a pending approval for this task
    status = controls.check_approval(task_id)
    if status is not None:
        click.echo(f"Task {task_id} already has verdict: {status}")
        return

    # Check if approval file exists at all
    if not controls._approval_path(task_id).exists():
        click.echo(f"No pending approval found for task {task_id}")
        # List pending approvals
        pending = controls.list_pending_approvals()
        if pending:
            click.echo("\nPending approvals:")
            for p in pending:
                ctx = p.get("context", {})
                click.echo(f"  {p['task_id']}: {ctx.get('task_title', '(no title)')}")
        sys.exit(1)

    verdict = "rejected" if reject else "approved"
    controls.set_approval(task_id, verdict, comment)
    icon = "❌" if reject else "✅"
    click.echo(f"{icon} Task {task_id} {verdict}")


if __name__ == "__main__":
    main()
