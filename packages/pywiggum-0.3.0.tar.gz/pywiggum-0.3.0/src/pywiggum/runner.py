"""Main orchestration loop for PyWiggum."""

import logging
import subprocess
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta
from pathlib import Path

from pywiggum.agents.base import AgentResult, BaseAgent
from pywiggum.agents.opencode import OpenCodeAgent
from pywiggum.config import WiggumConfig
from pywiggum.controls import Controls
from pywiggum.history import HistoryTracker, TaskCompletion
from pywiggum.kanban import KanbanManager, Task
from pywiggum.prompt import PromptBuilder
from pywiggum.routing import AgentLevel, Router
from pywiggum.supervisor import Supervisor
from pywiggum.verifier import Verifier

# Set up logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler()],
)

logger = logging.getLogger(__name__)


class Runner:
    """Main orchestration loop for PyWiggum."""

    def __init__(self, config: WiggumConfig, log_file: Path | None = None):
        """Initialize runner.

        Args:
            config: PyWiggum configuration
            log_file: Optional path to log file (defaults to work_dir/wiggum.log)
        """
        self.config = config
        self.work_dir = config.get_work_dir()

        # Set up file logging
        if log_file is None:
            log_file = self.work_dir / "wiggum.log"

        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(
            logging.Formatter("%(asctime)s [%(levelname)s] %(message)s")
        )
        logger.addHandler(file_handler)

        # Initialize components
        self.kanban = KanbanManager(config.get_kanban_path())
        self.controls = Controls(self.work_dir)
        self.history = HistoryTracker(self.work_dir)
        self.prompt_builder = PromptBuilder(config)

        # Initialize routing if enabled
        self.router: Router | None = None
        if config.routing:
            self.router = Router(config.routing)
            logger.info("🚔 Springfield PD routing enabled!")

        # Initialize race mode if enabled
        self.race_enabled = bool(config.race and config.race.enabled)
        if self.race_enabled:
            race_names = ", ".join(config.race.agents)
            logger.info(f"🏁 Race mode enabled! Agents: {race_names}")

        # Initialize verifier if enabled
        self.verifier: Verifier | None = None
        if config.verifier and config.verifier.enabled:
            self.verifier = Verifier(config.verifier, self.work_dir)
            logger.info("🔍 Verifier enabled!")

        # Initialize supervisor if enabled
        self.supervisor: Supervisor | None = None
        if config.supervisor and config.supervisor.enabled:
            self.supervisor = Supervisor(config.supervisor, self.controls, self.work_dir)
            logger.info("👮 Supervisor (Lou) enabled!")

        # Initialize agent
        self.agent = self._create_agent()

        # Runtime state
        self.current_iteration = 0
        self.current_task_id: str | None = None
        self.current_task_start: datetime | None = None
        self.current_task_iterations: int = 0
        self.current_agent_level: AgentLevel = AgentLevel.RALPH
        self.current_agent_config: dict = {}  # routing agent config for custom prompts
        self._pending_approvals: set[str] = set()  # task IDs awaiting approval

    def _create_agent(self) -> BaseAgent:
        """Create the agent backend based on configuration.

        Returns:
            Agent instance

        Raises:
            ValueError: If agent backend is not supported or not available
        """
        backend = self.config.agent.backend

        if backend == "opencode":
            agent = OpenCodeAgent(self.config.agent.model)
        elif backend == "claude_code":
            # Import here to avoid circular dependency
            from pywiggum.agents.claude_code import ClaudeCodeAgent

            agent = ClaudeCodeAgent(permission_mode="acceptEdits")
        elif backend == "api":
            # Import here to avoid circular dependency
            from pywiggum.agents.api import APIAgent

            agent = APIAgent(
                model=self.config.agent.model,
                api_base_url=self.config.agent.api_base_url,
                api_key_env=self.config.agent.api_key_env,
            )
        elif backend == "human":
            # Import here to avoid circular dependency
            from pywiggum.agents.human import HumanAgent

            agent = HumanAgent()
        else:
            raise ValueError(f"Unsupported agent backend: {backend}")

        if not agent.check_available():
            raise ValueError(f"Agent backend '{backend}' is not available")

        return agent

    def _create_agent_from_config(self, agent_config: dict) -> BaseAgent:
        """Create an agent from a routing config dictionary.

        Args:
            agent_config: Agent configuration from router

        Returns:
            Agent instance
        """
        backend = agent_config.get("backend", "opencode")
        model = agent_config.get("model", "vllm/qwen3-coder-next")

        if backend == "opencode":
            return OpenCodeAgent(model)
        elif backend == "claude_code":
            from pywiggum.agents.claude_code import ClaudeCodeAgent

            permission_mode = agent_config.get("permission_mode", "acceptEdits")
            return ClaudeCodeAgent(permission_mode=permission_mode)
        elif backend == "api":
            from pywiggum.agents.api import APIAgent

            return APIAgent(
                model=model,
                api_base_url=agent_config.get("api_base_url"),
                api_key_env=agent_config.get("api_key_env"),
            )
        elif backend == "human":
            from pywiggum.agents.human import HumanAgent

            return HumanAgent()
        else:
            raise ValueError(f"Unsupported agent backend: {backend}")

    def run(self) -> None:
        """Run the main orchestration loop."""
        logger.info(f"Starting PyWiggum runner for {self.config.project.name}")
        logger.info(f"Agent: {self.agent.name} / Model: {self.config.agent.model}")

        # Load history and kanban
        self.history.load()
        self.kanban.load()

        # Initialize max iterations control
        max_iterations = self.controls.get_max_iterations()
        if max_iterations is None:
            max_iterations = self.config.runner.max_iterations
            self.controls.set_max_iterations(max_iterations)

        # Set baseline if first run
        stats = self.kanban.get_stats()
        if not self.history.baseline_eta and stats["todo"] > 0:
            self.history.set_baseline(stats["todo"])
            logger.info(f"Set baseline ETA for {stats['todo']} remaining tasks")

        # Main loop
        try:
            self._run_loop(max_iterations)
        finally:
            self.controls.clear_state()
            logger.info(f"Runner completed after {self.current_iteration} iterations")

    def _run_loop(self, max_iterations: int) -> None:
        """Inner loop, separated so finally block can clean up state."""
        while self.current_iteration < max_iterations:
            self.current_iteration += 1

            # Write heartbeat state
            self.controls.write_state(self.current_iteration, self.current_task_id)

            # Check for max iterations update
            new_max = self.controls.get_max_iterations()
            if new_max is not None and new_max != max_iterations:
                max_iterations = new_max
                logger.info(f"Max iterations updated to {max_iterations}")

            # Check for pause
            if self.controls.is_paused():
                logger.info("Runner paused, waiting for resume...")
                self.controls.wait_while_paused()
                logger.info("Runner resumed")

            # Check pending approvals
            if self._pending_approvals:
                resolved = set()
                for pending_id in self._pending_approvals:
                    verdict = self.controls.check_approval(pending_id)
                    if verdict == "approved":
                        logger.info(f"[Approval] ✅ {pending_id} approved!")
                        self.kanban.load()
                        self.kanban.update_task_status(pending_id, "done")
                        self.controls.clear_approval(pending_id)
                        resolved.add(pending_id)
                    elif verdict == "rejected":
                        logger.info(f"[Approval] ❌ {pending_id} rejected")
                        self.kanban.load()
                        self.kanban.update_task_status(pending_id, "failed", note="Rejected in approval")
                        self.controls.clear_approval(pending_id)
                        resolved.add(pending_id)
                    else:
                        # Check for auto-approval timeout
                        auto_approved = self.controls.check_auto_approval(pending_id)
                        if auto_approved:
                            logger.info(
                                f"[Approval] ⏰ {pending_id} auto-approved "
                                f"(1h timeout, Claude score >= 4)"
                            )
                            self.kanban.load()
                            self.kanban.update_task_status(pending_id, "done",
                                note="Auto-approved: Claude scored 4+, human did not respond within 1h")
                            self.controls.clear_approval(pending_id)
                            resolved.add(pending_id)
                self._pending_approvals -= resolved

            # Check for parallel execution opportunity
            if self.config.runner.parallel_tasks:
                actionable = self.kanban.find_actionable_tasks(
                    max_count=self.config.runner.max_parallel,
                )
                if len(actionable) > 1:
                    logger.info(
                        f"[Parallel] Found {len(actionable)} actionable tasks, "
                        f"running up to {self.config.runner.max_parallel} in parallel"
                    )
                    hint = self.controls.consume_hint()
                    self._run_parallel(actionable, hint)
                    time.sleep(self.config.runner.sleep_between)
                    continue
                # Fall through to single-task path if only 1 actionable

            # Find next task
            next_task = self.kanban.find_next_task()
            if next_task is None:
                logger.info("No more tasks available, exiting")
                break

            milestone, task = next_task

            # Check if this is a new task or continuing previous
            is_new_task = task.id != self.current_task_id
            if is_new_task:
                self.current_task_id = task.id
                self.current_task_start = datetime.now()
                self.current_task_iterations = 0
                self.current_agent_level = AgentLevel.RALPH

            self.current_task_iterations += 1

            # Routing: determine which agent to use
            if self.router:
                escalated = False

                # Check for escalation
                duration = (datetime.now() - self.current_task_start).total_seconds()
                should_escalate = self.router.should_escalate(
                    self.current_task_iterations, duration
                )

                if should_escalate:
                    next_level = self.router.escalate(self.current_agent_level)
                    if next_level:
                        logger.warning(
                            f"⚠️  Escalating from {self.current_agent_level.value} to {next_level.value}!"
                        )
                        self.current_agent_level = next_level
                        escalated = True

                if escalated:
                    # Escalation overrides routing rules — use escalated agent
                    agent_level = self.current_agent_level
                    agent_config = self.router.config.agents.get(agent_level, {})
                    self.current_agent_config = agent_config
                    logger.info(f"🚔 {self.router.get_agent_description(agent_level)}")
                    self.agent = self._create_agent_from_config(agent_config)
                else:
                    # Route task to appropriate agent via rules
                    agent_level, agent_config = self.router.route_task(
                        task_id=task.id,
                        task_type=task.type,
                        milestone_id=milestone.id,
                        current_level=self.current_agent_level,
                    )

                    if agent_level != self.current_agent_level or is_new_task:
                        self.current_agent_level = agent_level
                        self.current_agent_config = agent_config
                        logger.info(f"🚔 {self.router.get_agent_description(agent_level)}")
                        self.agent = self._create_agent_from_config(agent_config)

            logger.info(
                f"Iteration {self.current_iteration}/{max_iterations}: "
                f"Task {task.id} - {task.title} "
                f"(attempt {self.current_task_iterations})"
            )

            # Check for hint
            hint = self.controls.consume_hint()
            if hint:
                logger.info(f"Received hint: {hint[:100]}...")

            # Decide: race or single agent
            race_type_ok = task.type not in ("planning", "review")
            if race_type_ok and self.config.race and self.config.race.task_types:
                race_type_ok = task.type in self.config.race.task_types
            use_race = (
                self.race_enabled
                and self.verifier
                and self.router
                and race_type_ok
            )

            if use_race:
                verdict, winner = self._run_race(task, hint)
            else:
                verdict, winner = self._run_single(task, hint)

            # Handle result
            if verdict in ("done", "failed"):
                # Enforce commit — catch agents that change files but forget to commit
                if verdict == "done" and self.config.runner.commit_after_task:
                    self._enforce_commit(task)

                # Check if approval is required before marking done
                if verdict == "done" and self.router:
                    approver = self.router.get_approval_agent(
                        task_id=task.id, task_type=task.type,
                        milestone_id=milestone.id,
                    )
                    if approver:
                        # Run pre-approval review via Claude before sending to human
                        score, recommendation = self._run_pre_approval_review(task)

                        if score is not None and score <= 3:
                            # Score 1-3: needs rework, send back
                            logger.warning(
                                f"[Approval] Task {task.id} scored {score}/5 — sending back for rework"
                            )
                            self.kanban.load()
                            self.kanban.update_task_status(
                                task.id, "todo",
                                note=f"Pre-approval review score {score}/5: {recommendation}",
                            )
                            self.controls.set_hint(
                                f"Task {task.id} was reviewed and scored {score}/5. "
                                f"Issues to fix: {recommendation}"
                            )
                            self.current_task_id = None
                            self.current_task_start = None
                            self.current_task_iterations = 0
                            self.current_agent_level = AgentLevel.RALPH
                            time.sleep(self.config.runner.sleep_between)
                            continue

                        # Score 4-5 (or review failed): send to human with recommendation
                        logger.info(
                            f"[Approval] Task {task.id} scored {score}/5 — sending to {approver}"
                        )
                        self.controls.request_approval(task.id, {
                            "task_title": task.title,
                            "task_description": task.description,
                            "approver": approver,
                            "claude_score": score,
                            "claude_recommendation": recommendation,
                            "auto_approve_after": (
                                datetime.now() + timedelta(
                                    minutes=self.config.runner.auto_approve_minutes
                                )
                            ).isoformat() if (
                                score and score >= 4
                                and self.config.runner.auto_approve_minutes > 0
                            ) else None,
                        })
                        self._pending_approvals.add(task.id)
                        # Don't mark as done yet — keep as todo until approved
                        self.current_task_id = None
                        self.current_task_start = None
                        self.current_task_iterations = 0
                        self.current_agent_level = AgentLevel.RALPH
                        time.sleep(self.config.runner.sleep_between)
                        continue

                duration = (datetime.now() - self.current_task_start).total_seconds()
                self.kanban.load()
                # Ensure kanban is updated (race/verifier may have already done it)
                current = self.kanban.get_task(task.id)
                if current and current.status == "todo":
                    self.kanban.update_task_status(task.id, verdict)

                completion = TaskCompletion(
                    task_id=task.id,
                    task_title=task.title,
                    started_at=self.current_task_start.isoformat(),
                    completed_at=datetime.now().isoformat(),
                    duration_seconds=duration,
                    iterations=self.current_task_iterations,
                    status=verdict,
                    agent=winner,
                )
                self.history.record_completion(completion)
                agent_label = f" by {winner}" if winner else ""
                logger.info(
                    f"Task {task.id} completed with status '{verdict}'{agent_label} "
                    f"in {duration / 60:.1f} minutes"
                )
                self.current_task_id = None
                self.current_task_start = None
                self.current_task_iterations = 0
                self.current_agent_level = AgentLevel.RALPH
            else:
                logger.warning(f"Task {task.id} not yet complete, retrying")
                if self.supervisor and self.supervisor.should_review(
                    self.current_iteration, self.current_task_iterations
                ):
                    self._run_supervisor_review(task)

            # Sleep between iterations
            time.sleep(self.config.runner.sleep_between)

    def _run_pre_approval_review(self, task: Task) -> tuple[int | None, str]:
        """Run a Claude review before sending to human for approval.

        Returns:
            (score, recommendation) where score is 1-5 or None if review failed.
            1-3 = needs rework, 4-5 = ready for human approval.
        """
        import shutil

        if not shutil.which("claude"):
            logger.warning("[PreApproval] claude CLI not found, skipping review")
            return None, "Review skipped — claude not available"

        # Gather git diff
        git_diff = self._get_git_diff()

        # Get custom review prompt from agent config if available
        custom_review = ""
        if self.router:
            lou_config = self.router.config.agents.get(AgentLevel.LOU, {})
            custom_review = lou_config.get("review_prompt", "")

        criteria_str = "\n".join(
            f"- {c}" for c in task.acceptance_criteria
        ) if task.acceptance_criteria else "(none)"

        prompt = f"""You are reviewing work before it goes to a human approver.

## Task
- **ID**: {task.id}
- **Title**: {task.title}
- **Description**: {task.description}
- **Acceptance Criteria**:
{criteria_str}

## Git diff
```
{git_diff[:6000]}
```

## Git status
"""
        # Add git status to catch uncommitted files
        try:
            status_r = subprocess.run(
                ["git", "status", "--short"],
                cwd=self.work_dir, capture_output=True, text=True, timeout=10,
            )
            prompt += f"```\n{status_r.stdout[:2000]}\n```\n"
        except Exception:
            prompt += "(could not get git status)\n"

        if custom_review.strip():
            prompt += f"\n## Additional Review Instructions\n{custom_review.strip()}\n"

        prompt += """
## Your job
Score this work from 1-5:
  1 = Fundamentally broken, wrong approach
  2 = Major issues: missing files, broken logic, key criteria unmet
  3 = Partial: some criteria met but significant gaps remain
  4 = Good: all criteria met, minor issues only
  5 = Excellent: clean, complete, ready to ship

IMPORTANT: Check that code changes are actually COMMITTED (not just in working tree).
If git status shows uncommitted source files, that's at least a score of 2.

Respond in EXACTLY this format (two lines only):
SCORE: <number 1-5>
REVIEW: <one paragraph explaining your score and what needs fixing, if anything>"""

        logger.info(f"[PreApproval] Reviewing task {task.id}")

        try:
            result = subprocess.run(
                ["claude", "-p", "--permission-mode", "plan", prompt],
                cwd=self.work_dir,
                capture_output=True,
                text=True,
                timeout=180,
            )
        except subprocess.TimeoutExpired:
            logger.warning("[PreApproval] Review timed out")
            return None, "Review timed out"
        except Exception as e:
            logger.warning(f"[PreApproval] Review failed: {e}")
            return None, f"Review failed: {e}"

        if result.returncode != 0:
            logger.warning(f"[PreApproval] claude exited {result.returncode}")
            return None, "Claude exited with error"

        # Parse score and review
        score = None
        review = ""
        for line in result.stdout.strip().splitlines():
            line = line.strip()
            if line.upper().startswith("SCORE:"):
                try:
                    score = int(line.split(":", 1)[1].strip()[0])
                    score = max(1, min(5, score))
                except (ValueError, IndexError):
                    pass
            elif line.upper().startswith("REVIEW:"):
                review = line.split(":", 1)[1].strip()

        if score is None:
            logger.warning(f"[PreApproval] Could not parse score from: {result.stdout[:200]}")
            return None, "Could not parse review score"

        logger.info(f"[PreApproval] Score: {score}/5 — {review[:120]}")
        return score, review

    def _enforce_commit(self, task: Task) -> None:
        """Check for uncommitted changes after a task completes and auto-commit them."""
        try:
            # Check for uncommitted changes (excluding control files)
            status_result = subprocess.run(
                ["git", "status", "--porcelain"],
                cwd=self.work_dir, capture_output=True, text=True, timeout=10,
            )
            if status_result.returncode != 0:
                return

            # Filter out control/config files
            skip = {"kanban.json", "wiggum.yaml", "wiggum.log", ".wiggum-",
                    "wiggum-runner.out", ".gitignore"}
            uncommitted = []
            for line in status_result.stdout.strip().splitlines():
                if not line.strip():
                    continue
                filepath = line[3:].strip()
                if any(filepath.startswith(s) or s in filepath for s in skip):
                    continue
                if filepath.startswith("??"):
                    continue
                uncommitted.append(filepath)

            # Also check untracked source files
            for line in status_result.stdout.strip().splitlines():
                filepath = line[3:].strip()
                if line.startswith("??") and (
                    filepath.startswith("src/") or filepath.startswith("db/")
                ):
                    uncommitted.append(filepath)

            if not uncommitted:
                return

            logger.warning(
                f"[CommitEnforce] Agent left {len(uncommitted)} files uncommitted, auto-committing"
            )

            # Stage the uncommitted files
            subprocess.run(
                ["git", "add"] + uncommitted,
                cwd=self.work_dir, capture_output=True, text=True, timeout=10,
            )

            # Commit
            commit_msg = self.config.runner.commit_format.format(
                task_id=task.id, task_title=task.title,
            )
            commit_msg += " (auto-committed by runner)"
            subprocess.run(
                ["git", "commit", "-m", commit_msg],
                cwd=self.work_dir, capture_output=True, text=True, timeout=10,
            )
            logger.info(f"[CommitEnforce] Auto-committed: {commit_msg}")

        except Exception as e:
            logger.warning(f"[CommitEnforce] Failed: {e}")

    def _run_single(self, task: Task, hint: str | None) -> tuple[str, str]:
        """Run a single agent on the task. Returns (verdict, agent_name)."""
        agent_name = self.current_agent_level.value
        prompt = self.prompt_builder.build_task_prompt(
            task, hint, agent_config=self.current_agent_config,
        )
        result = self.agent.run(
            prompt=prompt,
            work_dir=self.work_dir,
            timeout=self.config.agent.timeout,
        )

        if result.success:
            logger.info(f"Agent completed (exit code {result.exit_code})")
            # Handle subtask declarations if subagents enabled
            if self.config.subagents and self.config.subagents.enabled:
                self._handle_subtasks(result, agent_name)
        else:
            logger.warning(f"Agent failed (exit code {result.exit_code})")
            if result.stderr:
                logger.warning(f"Error: {result.stderr[:200]}")

        # Check if agent updated kanban directly
        self.kanban.load()
        updated_task = self.kanban.get_task(task.id)
        if updated_task and updated_task.status != "todo":
            return updated_task.status, agent_name

        # Agent didn't update kanban — try verifier
        if self.verifier and result.success:
            git_diff = self._get_git_diff()
            verdict = self.verifier.verify(
                task_id=task.id,
                task_title=task.title,
                task_description=task.description,
                acceptance_criteria=task.acceptance_criteria,
                git_diff=git_diff,
            )
            return verdict, agent_name

        return "todo", agent_name

    def _run_parallel(
        self, tasks: list[tuple], hint: str | None,
    ) -> None:
        """Run multiple independent tasks in parallel via git worktrees.

        Each task runs in its own worktree. Results are applied sequentially.
        """
        from pywiggum.kanban import Milestone, Task as KanbanTask

        # Get current HEAD
        head_result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=self.work_dir, capture_output=True, text=True, timeout=10,
        )
        start_sha = head_result.stdout.strip()
        timeout = self.config.agent.timeout

        worktrees: dict[str, Path] = {}  # task_id -> worktree path
        task_agents: dict[str, BaseAgent] = {}
        task_prompts: dict[str, str] = {}
        task_map: dict[str, tuple[Milestone, KanbanTask]] = {}

        try:
            for milestone, task in tasks:
                task_map[task.id] = (milestone, task)

                # Create worktree
                wt_dir = tempfile.mkdtemp(prefix=f"pywiggum-parallel-{task.id}-")
                wt_path = Path(wt_dir)
                wt_result = subprocess.run(
                    ["git", "worktree", "add", "--detach", str(wt_path)],
                    cwd=self.work_dir, capture_output=True, text=True, timeout=10,
                )
                if wt_result.returncode != 0:
                    logger.warning(f"[Parallel] Failed to create worktree for {task.id}: {wt_result.stderr}")
                    continue
                worktrees[task.id] = wt_path

                # Route task to get agent + config
                if self.router:
                    agent_level, agent_config = self.router.route_task(
                        task_id=task.id, task_type=task.type, milestone_id=milestone.id,
                    )
                    task_agents[task.id] = self._create_agent_from_config(agent_config)
                    task_prompts[task.id] = self.prompt_builder.build_race_prompt(task, hint)
                    logger.info(f"[Parallel] {task.id} → {agent_level.value}")
                else:
                    task_agents[task.id] = self.agent
                    task_prompts[task.id] = self.prompt_builder.build_race_prompt(task, hint)

            if not worktrees:
                logger.warning("[Parallel] No worktrees created, skipping")
                return

            # Run all tasks in parallel
            logger.info(f"[Parallel] 🚀 Starting {len(worktrees)} tasks in parallel")
            results: dict[str, AgentResult] = {}

            with ThreadPoolExecutor(max_workers=len(worktrees)) as executor:
                futures = {}
                for task_id, wt_path in worktrees.items():
                    future = executor.submit(
                        task_agents[task_id].run,
                        task_prompts[task_id], wt_path, timeout,
                    )
                    futures[future] = task_id

                for future in as_completed(futures):
                    task_id = futures[future]
                    try:
                        results[task_id] = future.result()
                        status = "✅" if results[task_id].success else "❌"
                        logger.info(f"[Parallel] {task_id} finished {status}")
                    except Exception as e:
                        logger.warning(f"[Parallel] {task_id} threw exception: {e}")

            # Process results — apply diffs sequentially
            for task_id, wt_path in worktrees.items():
                milestone, task = task_map[task_id]
                task_start = datetime.now()

                if task_id not in results or not results[task_id].success:
                    logger.info(f"[Parallel] {task_id} did not succeed, marking as todo")
                    continue

                # Get diff from worktree
                diff_result = subprocess.run(
                    ["git", "diff", start_sha, "--", ".", ":!kanban.json", ":!wiggum.yaml", ":!wiggum.log"],
                    cwd=wt_path, capture_output=True, text=True, timeout=10,
                )
                diff = diff_result.stdout.strip()

                if not diff:
                    logger.info(f"[Parallel] {task_id} produced no code changes")
                    # Check if agent updated kanban in worktree
                    continue

                # Verify if verifier is enabled
                verdict = "done"
                agent_name = None
                if self.verifier:
                    verdict = self.verifier.verify(
                        task_id=task.id, task_title=task.title,
                        task_description=task.description,
                        acceptance_criteria=task.acceptance_criteria,
                        git_diff=diff,
                    )

                if verdict == "done":
                    # Apply diff to main worktree
                    apply_result = subprocess.run(
                        ["git", "apply", "--allow-empty"],
                        input=diff,
                        cwd=self.work_dir, capture_output=True, text=True, timeout=10,
                    )
                    if apply_result.returncode == 0:
                        logger.info(f"[Parallel] ✅ {task_id} applied successfully")
                        self.kanban.load()
                        current = self.kanban.get_task(task.id)
                        if current and current.status == "todo":
                            self.kanban.update_task_status(task.id, verdict)

                        completion = TaskCompletion(
                            task_id=task.id, task_title=task.title,
                            started_at=task_start.isoformat(),
                            completed_at=datetime.now().isoformat(),
                            duration_seconds=(datetime.now() - task_start).total_seconds(),
                            iterations=1, status=verdict,
                            agent=task_agents[task_id].name if task_id in task_agents else None,
                        )
                        self.history.record_completion(completion)
                    else:
                        logger.warning(
                            f"[Parallel] Failed to apply {task_id} diff (conflict?): "
                            f"{apply_result.stderr[:200]}"
                        )
                else:
                    logger.info(f"[Parallel] {task_id} verdict: {verdict}")

        finally:
            # Cleanup all worktrees
            for task_id, wt_path in worktrees.items():
                try:
                    subprocess.run(
                        ["git", "worktree", "remove", "--force", str(wt_path)],
                        cwd=self.work_dir, capture_output=True, timeout=10,
                    )
                except Exception:
                    logger.warning(f"[Parallel] Failed to clean up worktree for {task_id}")

    def _handle_subtasks(self, result: AgentResult, parent_agent: str) -> None:
        """Parse agent output for SUBTASK markers and spawn child agents."""
        import re

        output = result.output
        subtask_pattern = re.compile(r"^SUBTASK:\s*(.+)$", re.MULTILINE)
        matches = subtask_pattern.findall(output)

        if not matches:
            return

        subagent_config = self.config.subagents
        max_subtasks = subagent_config.max_per_task
        matches = matches[:max_subtasks]

        logger.info(f"[Subagent] Found {len(matches)} subtask(s) from {parent_agent}")

        # Find matching subagent rule
        matching_rule = None
        for rule in subagent_config.rules:
            if rule.parent == parent_agent:
                matching_rule = rule
                break

        if matching_rule is None:
            logger.warning(f"[Subagent] No subagent rule found for parent={parent_agent}")
            return

        child_level = AgentLevel(matching_rule.child)
        if not self.router:
            logger.warning("[Subagent] Router required for subagent delegation")
            return

        child_agent_config = self.router.config.agents.get(child_level, {})
        child_backend = child_agent_config.get("backend", "opencode")

        if child_backend not in subagent_config.allowed_backends:
            logger.warning(f"[Subagent] Backend '{child_backend}' not in allowed_backends")
            return

        # Get current HEAD for diff tracking
        head_result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=self.work_dir, capture_output=True, text=True, timeout=10,
        )
        start_sha = head_result.stdout.strip()

        for i, subtask_desc in enumerate(matches):
            logger.info(f"[Subagent] Spawning child {matching_rule.child} for: {subtask_desc[:80]}")

            # Create worktree
            wt_dir = tempfile.mkdtemp(prefix=f"pywiggum-subagent-{matching_rule.child}-")
            wt_path = Path(wt_dir)

            try:
                wt_result = subprocess.run(
                    ["git", "worktree", "add", "--detach", str(wt_path)],
                    cwd=self.work_dir, capture_output=True, text=True, timeout=10,
                )
                if wt_result.returncode != 0:
                    logger.warning(f"[Subagent] Failed to create worktree: {wt_result.stderr}")
                    continue

                # Build subtask prompt
                prompt = (
                    f"You are a coding agent. Complete this specific sub-task:\n\n"
                    f"{subtask_desc}\n\n"
                    f"Do NOT update kanban.json. Do NOT git commit. Just make the code changes and exit."
                )

                # Add tech stack context
                if self.config.prompt.tech_stack.strip():
                    prompt += f"\n\n## TECH STACK\n{self.config.prompt.tech_stack.strip()}"
                if self.config.prompt.conventions.strip():
                    prompt += f"\n\n## CONVENTIONS\n{self.config.prompt.conventions.strip()}"

                child_agent = self._create_agent_from_config(child_agent_config)
                child_result = child_agent.run(
                    prompt=prompt, work_dir=wt_path,
                    timeout=self.config.agent.timeout,
                )

                if child_result.success:
                    # Get diff and apply to main worktree
                    diff_result = subprocess.run(
                        ["git", "diff", start_sha, "--", ".", ":!kanban.json", ":!wiggum.yaml", ":!wiggum.log"],
                        cwd=wt_path, capture_output=True, text=True, timeout=10,
                    )
                    diff = diff_result.stdout.strip()
                    if diff:
                        apply_result = subprocess.run(
                            ["git", "apply", "--allow-empty"],
                            input=diff,
                            cwd=self.work_dir, capture_output=True, text=True, timeout=10,
                        )
                        if apply_result.returncode == 0:
                            logger.info(f"[Subagent] ✅ Subtask {i+1} applied successfully")
                        else:
                            logger.warning(f"[Subagent] Failed to apply diff: {apply_result.stderr[:200]}")
                    else:
                        logger.info(f"[Subagent] Subtask {i+1} produced no changes")
                else:
                    logger.warning(f"[Subagent] Child agent failed for subtask {i+1}")

            finally:
                try:
                    subprocess.run(
                        ["git", "worktree", "remove", "--force", str(wt_path)],
                        cwd=self.work_dir, capture_output=True, timeout=10,
                    )
                except Exception:
                    logger.warning(f"[Subagent] Failed to clean up worktree")

    def _run_race(self, task: Task, hint: str | None) -> tuple[str, str | None]:
        """Run multiple agents in parallel via git worktrees, pick the winner."""
        race_agents = self.config.race.agents

        # Get current HEAD
        head_result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            cwd=self.work_dir, capture_output=True, text=True, timeout=10,
        )
        start_sha = head_result.stdout.strip()

        prompt = self.prompt_builder.build_race_prompt(task, hint)
        timeout = self.config.agent.timeout
        worktrees: dict[str, Path] = {}
        agents: dict[str, BaseAgent] = {}

        try:
            # Create worktrees and agents
            for agent_name in race_agents:
                wt_dir = tempfile.mkdtemp(prefix=f"pywiggum-{agent_name}-")
                wt_path = Path(wt_dir)

                wt_result = subprocess.run(
                    ["git", "worktree", "add", "--detach", str(wt_path)],
                    cwd=self.work_dir, capture_output=True, text=True, timeout=10,
                )
                if wt_result.returncode != 0:
                    logger.warning(f"[Race] Failed to create worktree for {agent_name}: {wt_result.stderr}")
                    continue

                worktrees[agent_name] = wt_path

                level = AgentLevel(agent_name)
                agent_config = self.router.config.agents.get(level, {})
                agents[agent_name] = self._create_agent_from_config(agent_config)

            if not worktrees:
                logger.warning("[Race] No worktrees created, falling back to single agent")
                return self._run_single(task, hint)  # already returns tuple

            # Run all agents in parallel
            logger.info(f"[Race] 🏁 Starting race: {', '.join(worktrees.keys())}")
            results: dict[str, AgentResult] = {}

            with ThreadPoolExecutor(max_workers=len(worktrees)) as executor:
                futures = {}
                for agent_name, wt_path in worktrees.items():
                    future = executor.submit(
                        agents[agent_name].run, prompt, wt_path, timeout,
                    )
                    futures[future] = agent_name

                for future in as_completed(futures):
                    agent_name = futures[future]
                    try:
                        results[agent_name] = future.result()
                        status = "✅" if results[agent_name].success else "❌"
                        logger.info(f"[Race] {agent_name} finished {status}")
                    except Exception as e:
                        logger.warning(f"[Race] {agent_name} threw exception: {e}")

            # Verify results — prefer stronger agents (later in list)
            # Reverse so we check the stronger agent first
            for agent_name in reversed(race_agents):
                if agent_name not in results or not results[agent_name].success:
                    continue

                wt_path = worktrees[agent_name]

                # Get diff from worktree vs starting point (excludes kanban.json)
                diff_result = subprocess.run(
                    ["git", "diff", start_sha, "--", ".", ":!kanban.json", ":!wiggum.yaml", ":!wiggum.log"],
                    cwd=wt_path, capture_output=True, text=True, timeout=10,
                )
                diff = diff_result.stdout.strip()

                if not diff:
                    logger.info(f"[Race] {agent_name} produced no code changes, skipping")
                    continue

                logger.info(f"[Race] Verifying {agent_name}'s work...")
                verdict = self.verifier.verify(
                    task_id=task.id,
                    task_title=task.title,
                    task_description=task.description,
                    acceptance_criteria=task.acceptance_criteria,
                    git_diff=diff,
                )

                if verdict == "done":
                    # Apply this agent's changes to main worktree
                    apply_result = subprocess.run(
                        ["git", "apply", "--allow-empty"],
                        input=diff,
                        cwd=self.work_dir, capture_output=True, text=True, timeout=10,
                    )
                    if apply_result.returncode == 0:
                        logger.info(f"[Race] 🏆 {agent_name} wins! Applied changes.")
                        return "done", agent_name
                    else:
                        logger.warning(f"[Race] Failed to apply {agent_name}'s diff: {apply_result.stderr[:200]}")
                elif verdict == "failed":
                    logger.info(f"[Race] {agent_name}'s work marked failed by verifier")

            logger.info("[Race] No winner this round")
            return "todo", None

        finally:
            # Cleanup worktrees
            for agent_name, wt_path in worktrees.items():
                try:
                    subprocess.run(
                        ["git", "worktree", "remove", "--force", str(wt_path)],
                        cwd=self.work_dir, capture_output=True, timeout=10,
                    )
                except Exception:
                    logger.warning(f"[Race] Failed to clean up worktree for {agent_name}")

    def _get_git_diff(self) -> str:
        """Get git diff for uncommitted changes + last commit."""
        import subprocess

        parts = []
        # Uncommitted changes (staged + unstaged)
        try:
            r = subprocess.run(
                ["git", "diff", "HEAD"],
                cwd=self.work_dir, capture_output=True, text=True, timeout=10,
            )
            if r.returncode == 0 and r.stdout.strip():
                parts.append(r.stdout)
        except Exception:
            pass

        # Last commit diff (agent may have committed)
        try:
            r = subprocess.run(
                ["git", "diff", "HEAD~1..HEAD"],
                cwd=self.work_dir, capture_output=True, text=True, timeout=10,
            )
            if r.returncode == 0 and r.stdout.strip():
                parts.append(r.stdout)
        except Exception:
            pass

        return "\n".join(parts) if parts else "(no changes detected)"

    def _run_supervisor_review(self, task: Task) -> None:
        """Gather context and run a supervisor review."""
        import subprocess

        # Get git diff stat (last 3 commits)
        try:
            diff_result = subprocess.run(
                ["git", "diff", "--stat", "HEAD~3..HEAD"],
                cwd=self.work_dir,
                capture_output=True,
                text=True,
                timeout=10,
            )
            git_diff = diff_result.stdout if diff_result.returncode == 0 else "(no git diff available)"
        except Exception:
            git_diff = "(no git diff available)"

        # Get last 30 lines of wiggum.log
        log_path = self.work_dir / "wiggum.log"
        log_tail = ""
        if log_path.exists():
            try:
                lines = log_path.read_text().splitlines()
                log_tail = "\n".join(lines[-30:])
            except Exception:
                log_tail = "(could not read log)"

        self.supervisor.review(
            task_id=task.id,
            task_title=task.title,
            task_description=task.description,
            acceptance_criteria=task.acceptance_criteria,
            attempt_count=self.current_task_iterations,
            kanban_path=str(self.config.get_kanban_path()),
            log_tail=log_tail,
            git_diff=git_diff,
        )

    def get_status(self) -> dict:
        """Get current runner status.

        Returns:
            Status dictionary
        """
        stats = self.kanban.get_stats()
        history_stats = self.history.get_stats()

        status = {
            "running": self.current_task_id is not None,
            "paused": self.controls.is_paused(),
            "iteration": self.current_iteration,
            "max_iterations": self.controls.get_max_iterations(),
            "current_task": self.current_task_id,
            "current_task_iterations": self.current_task_iterations,
            "current_agent_level": self.current_agent_level.value if self.router else None,
            "routing_enabled": self.router is not None,
            "kanban_stats": stats,
            "history_stats": history_stats,
        }

        # Add current task duration if active
        if self.current_task_start:
            duration = (datetime.now() - self.current_task_start).total_seconds()
            status["current_task_duration_seconds"] = duration

            # Check for stall
            stall_multiplier = self.history.detect_stall(duration)
            if stall_multiplier > 0:
                status["stall_multiplier"] = stall_multiplier

        # Add ETA prediction
        eta = self.history.predict_eta(stats["todo"])
        if eta:
            status["predicted_eta"] = eta.isoformat()

        # Add drift
        drift = self.history.get_drift(stats["todo"])
        if drift:
            status["drift_minutes"] = drift.total_seconds() / 60.0

        return status
