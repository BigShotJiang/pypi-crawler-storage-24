"""Task verifier — checks if agent work meets acceptance criteria and updates kanban."""

import logging
import shutil
import subprocess
from pathlib import Path

from pywiggum.config import VerifierConfig

logger = logging.getLogger(__name__)


class Verifier:
    """Runs after the coding agent to check work and update kanban status."""

    def __init__(self, config: VerifierConfig, work_dir: Path):
        self.config = config
        self.work_dir = work_dir

    def verify(
        self,
        task_id: str,
        task_title: str,
        task_description: str,
        acceptance_criteria: list[str],
        git_diff: str,
    ) -> str:
        """Verify if task work meets acceptance criteria.

        Returns:
            "done", "failed", or "todo" (not enough evidence).
        """
        if not shutil.which("claude"):
            logger.warning("[Verifier] claude CLI not found, skipping")
            return "todo"

        prompt = self._build_prompt(
            task_id, task_title, task_description, acceptance_criteria, git_diff,
        )

        logger.info(f"[Verifier] Checking task {task_id}")

        try:
            cmd = [
                "claude", "-p",
                "--permission-mode", self.config.permission_mode,
                prompt,
            ]
            result = subprocess.run(
                cmd,
                cwd=self.work_dir,
                capture_output=True,
                text=True,
                timeout=self.config.timeout,
            )
        except subprocess.TimeoutExpired:
            logger.warning(f"[Verifier] Timed out after {self.config.timeout}s")
            return "todo"
        except Exception as e:
            logger.warning(f"[Verifier] Failed: {e}")
            return "todo"

        if result.returncode != 0:
            logger.warning(f"[Verifier] claude exited {result.returncode}: {result.stderr[:200]}")
            return "todo"

        verdict = self._parse_verdict(result.stdout)
        logger.info(f"[Verifier] Verdict for {task_id}: {verdict}")
        return verdict

    def _build_prompt(
        self,
        task_id: str,
        task_title: str,
        task_description: str,
        acceptance_criteria: list[str],
        git_diff: str,
    ) -> str:
        criteria_str = "\n".join(f"- {c}" for c in acceptance_criteria) if acceptance_criteria else "(none)"

        return f"""You are a task verifier. An AI coding agent just worked on a task.
Your job: check if the work is done by comparing the git diff against the acceptance criteria.

## Task
- **ID**: {task_id}
- **Title**: {task_title}
- **Description**: {task_description}
- **Acceptance Criteria**:
{criteria_str}

## Git diff (changes made by the agent)
```
{git_diff[:4000]}
```

## Instructions
Look at the git diff and determine if the acceptance criteria are met.
- If the diff shows meaningful progress that satisfies the criteria: respond DONE
- If the diff shows work that is clearly wrong or breaks things: respond FAILED
- If there is no diff or insufficient evidence to judge: respond TODO

Respond with ONLY one word: DONE, FAILED, or TODO"""

    def _parse_verdict(self, response: str) -> str:
        text = response.strip().upper()
        # Check last line first (model sometimes adds preamble)
        for line in reversed(text.splitlines()):
            line = line.strip()
            if line in ("DONE", "FAILED", "TODO"):
                return line.lower()
        # Fallback: search anywhere in response
        if "DONE" in text:
            return "done"
        if "FAILED" in text:
            return "failed"
        logger.warning(f"[Verifier] Unexpected response: {response[:200]}")
        return "todo"
