"""Prompt builder for PyWiggum agents."""

from pathlib import Path

from pywiggum.config import WiggumConfig
from pywiggum.kanban import Task


class PromptBuilder:
    """Builds prompts for agent execution."""

    def __init__(self, config: WiggumConfig):
        """Initialize prompt builder.

        Args:
            config: PyWiggum configuration
        """
        self.config = config

    def build_task_prompt(
        self, task: Task, hint: str | None = None, agent_config: dict | None = None,
    ) -> str:
        """Build a prompt for executing a task.

        Args:
            task: The task to execute
            hint: Optional hint from human operator
            agent_config: Optional agent config dict (from routing) with custom prompts

        Returns:
            Complete prompt string
        """
        project_name = self.config.project.name
        kanban_path = Path(self.config.project.kanban).name
        tech_stack = self.config.prompt.tech_stack
        conventions = self.config.prompt.conventions
        extra_context = self.config.prompt.extra_context
        commit_format = self.config.runner.commit_format

        # Build the base prompt
        prompt_parts = [
            f"You are an autonomous coding agent working on {project_name}.",
            "",
            "## INSTRUCTIONS",
            f"1. Read {kanban_path} in the project root.",
            "2. Find the first task with status 'todo' whose milestone is not blocked.",
            "3. Implement the task. Write code, create files, install packages as needed.",
            "4. Verify your work against the acceptance criteria.",
            f"5. CRITICAL: Update {kanban_path}: set the task's status to 'done' (or 'failed' with a note). "
            f"This step is MANDATORY — if you skip it, the task will be re-run. "
            f"Edit the JSON file directly to change \"status\": \"todo\" to \"status\": \"done\".",
        ]

        # Add git commit instruction if enabled
        if self.config.runner.commit_after_task:
            commit_msg = commit_format.format(task_id=task.id, task_title=task.title)
            prompt_parts.append(f"6. Git commit with message: '{commit_msg}'")
            prompt_parts.append("7. EXIT. One task per iteration.")
        else:
            prompt_parts.append("6. EXIT. One task per iteration.")

        # Add tech stack if provided
        if tech_stack.strip():
            prompt_parts.extend(
                [
                    "",
                    "## TECH STACK",
                    tech_stack.strip(),
                ]
            )

        # Add conventions if provided
        if conventions.strip():
            prompt_parts.extend(
                [
                    "",
                    "## CONVENTIONS",
                    conventions.strip(),
                ]
            )

        # Add extra context if provided
        if extra_context.strip():
            prompt_parts.extend(
                [
                    "",
                    extra_context.strip(),
                ]
            )

        # Planning tasks: use custom prompt or default reclassification instructions
        if task.type == "planning":
            custom_planning = (agent_config or {}).get("planning_prompt", "").strip()
            if custom_planning:
                prompt_parts.extend(["", "## PLANNING TASK", custom_planning])
            else:
                prompt_parts.extend(
                    [
                        "",
                        "## PLANNING TASK — RECLASSIFY SIBLING TASKS",
                        f"After completing this planning task, review the other tasks in the same milestone in {kanban_path}.",
                        "For each sibling task, evaluate whether its 'type' field is correct based on complexity:",
                        "- 'code' or 'frontend': Simple changes, local models can handle",
                        "- 'backend': Complex server/DB/git operations requiring a stronger model",
                        "- 'planning': Design/architecture decisions",
                        "- 'review': Code review and verification",
                        "If a task is miscategorized (e.g., a complex cherry-pick marked as 'code' when it should be 'backend'),",
                        f"update its 'type' field in {kanban_path}. This determines which model handles the task.",
                    ]
                )

        # Review tasks: use custom review prompt if provided
        if task.type == "review":
            custom_review = (agent_config or {}).get("review_prompt", "").strip()
            if custom_review:
                prompt_parts.extend(["", "## REVIEW TASK", custom_review])

        # Add subagent instructions if enabled
        if self.config.subagents and self.config.subagents.enabled:
            prompt_parts.extend(
                [
                    "",
                    "## SUBAGENT DELEGATION",
                    "If part of this task could be done independently by a simpler agent,",
                    "you can delegate it by writing a line in your output like:",
                    "  SUBTASK: <clear one-sentence description of the bounded sub-task>",
                    "The runner will spawn a child agent to handle it in a separate worktree.",
                    f"You can delegate at most {self.config.subagents.max_per_task} subtasks.",
                    "Only delegate bounded, file-scoped work — not open-ended tasks.",
                ]
            )

        # Add hint if provided
        if hint and hint.strip():
            prompt_parts.extend(
                [
                    "",
                    "## HUMAN HINT (read this carefully, it's from the project lead)",
                    hint.strip(),
                ]
            )

        return "\n".join(prompt_parts)

    def build_race_prompt(self, task: Task, hint: str | None = None) -> str:
        """Build a prompt for parallel race execution.

        Unlike the normal prompt, this embeds the task directly (no kanban read)
        and does NOT ask the agent to update kanban or commit (the runner handles that).

        Args:
            task: The task to execute
            hint: Optional hint from human operator

        Returns:
            Complete prompt string
        """
        project_name = self.config.project.name
        tech_stack = self.config.prompt.tech_stack
        conventions = self.config.prompt.conventions
        extra_context = self.config.prompt.extra_context

        criteria_str = "\n".join(f"  - {c}" for c in task.acceptance_criteria) if task.acceptance_criteria else "  (none)"

        prompt_parts = [
            f"You are an autonomous coding agent working on {project_name}.",
            "",
            "## YOUR TASK",
            f"- **ID**: {task.id}",
            f"- **Title**: {task.title}",
            f"- **Description**: {task.description}",
            f"- **Acceptance Criteria**:",
            criteria_str,
            "",
            "## INSTRUCTIONS",
            "1. Implement the task. Write code, create files, install packages as needed.",
            "2. Verify your work against the acceptance criteria.",
            "3. Do NOT update kanban.json — a separate verifier handles that.",
            "4. Do NOT git commit — the runner handles that.",
            "5. EXIT when done. One task per iteration.",
        ]

        if tech_stack.strip():
            prompt_parts.extend(["", "## TECH STACK", tech_stack.strip()])

        if conventions.strip():
            prompt_parts.extend(["", "## CONVENTIONS", conventions.strip()])

        if extra_context.strip():
            prompt_parts.extend(["", extra_context.strip()])

        if hint and hint.strip():
            prompt_parts.extend([
                "",
                "## HUMAN HINT (read this carefully, it's from the project lead)",
                hint.strip(),
            ])

        return "\n".join(prompt_parts)
