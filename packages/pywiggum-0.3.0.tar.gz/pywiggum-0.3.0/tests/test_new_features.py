"""Tests for new features: task_types, depends_on, parallel, approval, subagents, custom prompts."""

import json
import tempfile
from pathlib import Path

from pywiggum.config import RaceConfig, RunnerConfig, SubagentConfig, SubagentRule, WiggumConfig
from pywiggum.controls import Controls
from pywiggum.kanban import KanbanManager, KanbanBoard, Milestone, Task
from pywiggum.prompt import PromptBuilder
from pywiggum.routing import AgentLevel, RoutingConfig, RoutingRule, Router


# --- Feature 1: task_types on RaceConfig ---


def test_race_config_task_types_default():
    """task_types defaults to empty list (all non-planning/review)."""
    race = RaceConfig(enabled=True)
    assert race.task_types == []


def test_race_config_task_types_set():
    """task_types can be explicitly set."""
    race = RaceConfig(enabled=True, task_types=["backend", "code"])
    assert race.task_types == ["backend", "code"]


def test_race_config_roundtrip():
    """RaceConfig with task_types survives save/load."""
    with tempfile.TemporaryDirectory() as tmpdir:
        config = WiggumConfig()
        config.race = RaceConfig(enabled=True, task_types=["backend"])
        config_path = Path(tmpdir) / "wiggum.yaml"
        config.save(config_path)

        loaded = WiggumConfig.load(config_path)
        assert loaded.race.task_types == ["backend"]


# --- Feature 2: Custom planning_prompt / review_prompt ---


def test_custom_planning_prompt():
    """Agent config with planning_prompt overrides default reclassification."""
    config = WiggumConfig()
    builder = PromptBuilder(config)
    task = Task(id="M1.1", title="Plan", description="Plan stuff", type="planning")

    agent_config = {"planning_prompt": "Break tasks into DAG with depends_on."}
    prompt = builder.build_task_prompt(task, agent_config=agent_config)

    assert "Break tasks into DAG" in prompt
    assert "RECLASSIFY SIBLING TASKS" not in prompt


def test_default_planning_prompt_without_custom():
    """Without custom prompt, default reclassification instructions are used."""
    config = WiggumConfig()
    builder = PromptBuilder(config)
    task = Task(id="M1.1", title="Plan", description="Plan stuff", type="planning")

    prompt = builder.build_task_prompt(task)
    assert "RECLASSIFY SIBLING TASKS" in prompt


def test_custom_review_prompt():
    """Agent config with review_prompt injects review instructions."""
    config = WiggumConfig()
    builder = PromptBuilder(config)
    task = Task(id="M1.3", title="Review", description="Review work", type="review")

    agent_config = {"review_prompt": "Run git diff and check acceptance criteria."}
    prompt = builder.build_task_prompt(task, agent_config=agent_config)

    assert "Run git diff and check acceptance criteria" in prompt
    assert "REVIEW TASK" in prompt


def test_non_review_task_no_review_prompt():
    """Non-review tasks don't get review prompt section."""
    config = WiggumConfig()
    builder = PromptBuilder(config)
    task = Task(id="M1.2", title="Code", description="Write code", type="code")

    agent_config = {"review_prompt": "Should not appear"}
    prompt = builder.build_task_prompt(task, agent_config=agent_config)

    assert "REVIEW TASK" not in prompt


# --- Feature 3: depends_on + find_actionable_tasks ---


def test_task_depends_on_default():
    """depends_on defaults to empty list."""
    task = Task(id="T1", title="Test", description="Test")
    assert task.depends_on == []


def test_task_depends_on_set():
    """depends_on can be set."""
    task = Task(id="T2", title="Test", description="Test", depends_on=["T1"])
    assert task.depends_on == ["T1"]


def test_find_actionable_tasks_no_deps():
    """Without depends_on, all todo tasks in unblocked milestones are actionable."""
    with tempfile.TemporaryDirectory() as tmpdir:
        kanban_path = Path(tmpdir) / "kanban.json"
        board = KanbanBoard(milestones=[
            Milestone(id="M1", name="Setup", tasks=[
                Task(id="M1.1", title="Task A", description="A"),
                Task(id="M1.2", title="Task B", description="B"),
                Task(id="M1.3", title="Task C", description="C"),
            ]),
        ])
        manager = KanbanManager(kanban_path)
        manager.save(board)
        manager.load()

        results = manager.find_actionable_tasks(max_count=3)
        assert len(results) == 3
        assert [t.id for _, t in results] == ["M1.1", "M1.2", "M1.3"]


def test_find_actionable_tasks_with_deps():
    """Tasks with unmet depends_on are not actionable."""
    with tempfile.TemporaryDirectory() as tmpdir:
        kanban_path = Path(tmpdir) / "kanban.json"
        board = KanbanBoard(milestones=[
            Milestone(id="M1", name="Setup", tasks=[
                Task(id="M1.1", title="Plan", description="Plan", depends_on=[]),
                Task(id="M1.2", title="Backend", description="Backend", depends_on=["M1.1"]),
                Task(id="M1.3", title="Frontend", description="Frontend", depends_on=["M1.1"]),
                Task(id="M1.4", title="Wire", description="Wire", depends_on=["M1.2", "M1.3"]),
            ]),
        ])
        manager = KanbanManager(kanban_path)
        manager.save(board)
        manager.load()

        # Only M1.1 is actionable (no deps)
        results = manager.find_actionable_tasks(max_count=5)
        assert len(results) == 1
        assert results[0][1].id == "M1.1"

        # Complete M1.1, now M1.2 and M1.3 should be actionable
        manager.update_task_status("M1.1", "done")
        manager.load()
        results = manager.find_actionable_tasks(max_count=5)
        assert len(results) == 2
        ids = {t.id for _, t in results}
        assert ids == {"M1.2", "M1.3"}

        # Complete M1.2 only, M1.4 still blocked (needs M1.3)
        manager.update_task_status("M1.2", "done")
        manager.load()
        results = manager.find_actionable_tasks(max_count=5)
        assert len(results) == 1
        assert results[0][1].id == "M1.3"

        # Complete M1.3, now M1.4 is actionable
        manager.update_task_status("M1.3", "done")
        manager.load()
        results = manager.find_actionable_tasks(max_count=5)
        assert len(results) == 1
        assert results[0][1].id == "M1.4"


def test_find_next_task_respects_depends_on():
    """find_next_task returns first task with satisfied deps."""
    with tempfile.TemporaryDirectory() as tmpdir:
        kanban_path = Path(tmpdir) / "kanban.json"
        board = KanbanBoard(milestones=[
            Milestone(id="M1", name="Setup", tasks=[
                Task(id="M1.1", title="Blocked", description="Blocked", depends_on=["M1.2"]),
                Task(id="M1.2", title="Free", description="Free", depends_on=[]),
            ]),
        ])
        manager = KanbanManager(kanban_path)
        manager.save(board)
        manager.load()

        result = manager.find_next_task()
        assert result is not None
        _, task = result
        # M1.1 is blocked by M1.2, so M1.2 should come first
        assert task.id == "M1.2"


def test_find_actionable_tasks_max_count():
    """max_count limits returned tasks."""
    with tempfile.TemporaryDirectory() as tmpdir:
        kanban_path = Path(tmpdir) / "kanban.json"
        board = KanbanBoard(milestones=[
            Milestone(id="M1", name="Setup", tasks=[
                Task(id="M1.1", title="A", description="A"),
                Task(id="M1.2", title="B", description="B"),
                Task(id="M1.3", title="C", description="C"),
            ]),
        ])
        manager = KanbanManager(kanban_path)
        manager.save(board)
        manager.load()

        results = manager.find_actionable_tasks(max_count=2)
        assert len(results) == 2


def test_depends_on_json_roundtrip():
    """depends_on survives JSON save/load."""
    with tempfile.TemporaryDirectory() as tmpdir:
        kanban_path = Path(tmpdir) / "kanban.json"
        board = KanbanBoard(milestones=[
            Milestone(id="M1", name="Test", tasks=[
                Task(id="M1.1", title="A", description="A", depends_on=["M0.1", "M0.2"]),
            ]),
        ])
        manager = KanbanManager(kanban_path)
        manager.save(board)

        # Reload
        manager2 = KanbanManager(kanban_path)
        manager2.load()
        task = manager2.get_task("M1.1")
        assert task.depends_on == ["M0.1", "M0.2"]


# --- Feature 3b: RunnerConfig parallel fields ---


def test_runner_config_parallel_defaults():
    """parallel_tasks defaults to False, max_parallel to 2."""
    rc = RunnerConfig()
    assert rc.parallel_tasks is False
    assert rc.max_parallel == 2


def test_runner_config_parallel_roundtrip():
    """Parallel config survives save/load."""
    with tempfile.TemporaryDirectory() as tmpdir:
        config = WiggumConfig()
        config.runner.parallel_tasks = True
        config.runner.max_parallel = 3
        config_path = Path(tmpdir) / "wiggum.yaml"
        config.save(config_path)

        loaded = WiggumConfig.load(config_path)
        assert loaded.runner.parallel_tasks is True
        assert loaded.runner.max_parallel == 3


# --- Feature 4: Approval gate ---


def test_routing_rule_approve_default():
    """approve defaults to None."""
    rule = RoutingRule(task_type="planning", agent_level=AgentLevel.LOU)
    assert rule.approve is None


def test_routing_rule_approve_set():
    """approve can be set."""
    rule = RoutingRule(task_type="planning", agent_level=AgentLevel.LOU, approve="matt")
    assert rule.approve == "matt"


def test_router_get_approval_agent():
    """get_approval_agent returns the approve value for matching rule."""
    config = RoutingConfig(
        rules=[
            RoutingRule(task_type="planning", agent_level=AgentLevel.LOU, approve="matt"),
            RoutingRule(task_type="code", agent_level=AgentLevel.RALPH),
        ]
    )
    router = Router(config)

    assert router.get_approval_agent("M1.1", task_type="planning") == "matt"
    assert router.get_approval_agent("M1.2", task_type="code") is None
    assert router.get_approval_agent("M1.3", task_type="backend") is None


def test_controls_approval_lifecycle():
    """Approval request → check pending → approve → check approved."""
    with tempfile.TemporaryDirectory() as tmpdir:
        controls = Controls(Path(tmpdir))

        # No approval yet
        assert controls.check_approval("M1.1") is None

        # Request approval
        controls.request_approval("M1.1", {"task_title": "Plan stuff"})
        assert controls.check_approval("M1.1") is None  # Still pending

        # Approve
        assert controls.set_approval("M1.1", "approved", "Looks good")
        assert controls.check_approval("M1.1") == "approved"

        # Cleanup
        controls.clear_approval("M1.1")
        assert controls.check_approval("M1.1") is None


def test_controls_approval_rejection():
    """Approval rejection works."""
    with tempfile.TemporaryDirectory() as tmpdir:
        controls = Controls(Path(tmpdir))

        controls.request_approval("M1.1", {"task_title": "Plan"})
        controls.set_approval("M1.1", "rejected", "Needs more detail")
        assert controls.check_approval("M1.1") == "rejected"


def test_controls_list_pending_approvals():
    """list_pending_approvals returns only pending ones."""
    with tempfile.TemporaryDirectory() as tmpdir:
        controls = Controls(Path(tmpdir))

        controls.request_approval("M1.1", {"task_title": "Plan A"})
        controls.request_approval("M1.2", {"task_title": "Plan B"})
        controls.set_approval("M1.1", "approved")

        pending = controls.list_pending_approvals()
        assert len(pending) == 1
        assert pending[0]["task_id"] == "M1.2"


# --- Feature 4b: Auto-approval timeout ---


def test_auto_approval_not_triggered_before_deadline():
    """Auto-approval doesn't fire before the deadline."""
    with tempfile.TemporaryDirectory() as tmpdir:
        controls = Controls(Path(tmpdir))
        from datetime import datetime, timedelta

        # Set auto_approve_after to 1 hour from now
        future = (datetime.now() + timedelta(hours=1)).isoformat()
        controls.request_approval("M1.1", {
            "task_title": "Plan",
            "claude_score": 4,
            "auto_approve_after": future,
        })

        assert controls.check_auto_approval("M1.1") is False
        assert controls.check_approval("M1.1") is None  # Still pending


def test_auto_approval_triggers_after_deadline():
    """Auto-approval fires after the deadline passes."""
    with tempfile.TemporaryDirectory() as tmpdir:
        controls = Controls(Path(tmpdir))
        from datetime import datetime, timedelta

        # Set auto_approve_after to 1 hour ago
        past = (datetime.now() - timedelta(hours=1)).isoformat()
        controls.request_approval("M1.1", {
            "task_title": "Plan",
            "claude_score": 5,
            "auto_approve_after": past,
        })

        assert controls.check_auto_approval("M1.1") is True
        assert controls.check_approval("M1.1") == "approved"


def test_auto_approval_not_triggered_without_flag():
    """Auto-approval doesn't fire if auto_approve_after is not set."""
    with tempfile.TemporaryDirectory() as tmpdir:
        controls = Controls(Path(tmpdir))

        controls.request_approval("M1.1", {
            "task_title": "Plan",
            "claude_score": 5,
            # No auto_approve_after
        })

        assert controls.check_auto_approval("M1.1") is False


def test_auto_approval_not_triggered_if_already_decided():
    """Auto-approval doesn't fire if human already responded."""
    with tempfile.TemporaryDirectory() as tmpdir:
        controls = Controls(Path(tmpdir))
        from datetime import datetime, timedelta

        past = (datetime.now() - timedelta(hours=1)).isoformat()
        controls.request_approval("M1.1", {
            "task_title": "Plan",
            "claude_score": 4,
            "auto_approve_after": past,
        })

        # Human rejects before auto-approval checks
        controls.set_approval("M1.1", "rejected")
        assert controls.check_auto_approval("M1.1") is False
        assert controls.check_approval("M1.1") == "rejected"


# --- Feature 5: Subagent config ---


def test_subagent_config_default():
    """SubagentConfig defaults to disabled."""
    config = WiggumConfig()
    assert config.subagents is None


def test_subagent_config_roundtrip():
    """SubagentConfig survives save/load."""
    with tempfile.TemporaryDirectory() as tmpdir:
        config = WiggumConfig()
        config.subagents = SubagentConfig(
            enabled=True,
            max_per_task=2,
            allowed_backends=["opencode"],
            rules=[
                SubagentRule(parent="eddie", child="ralph", trigger="subtask", max_iterations=5),
            ],
        )
        config_path = Path(tmpdir) / "wiggum.yaml"
        config.save(config_path)

        loaded = WiggumConfig.load(config_path)
        assert loaded.subagents is not None
        assert loaded.subagents.enabled is True
        assert loaded.subagents.max_per_task == 2
        assert len(loaded.subagents.rules) == 1
        assert loaded.subagents.rules[0].parent == "eddie"
        assert loaded.subagents.rules[0].child == "ralph"


def test_subagent_prompt_injection():
    """When subagents enabled, prompt includes SUBTASK delegation instructions."""
    config = WiggumConfig()
    config.subagents = SubagentConfig(enabled=True, max_per_task=3)
    builder = PromptBuilder(config)
    task = Task(id="M1.2", title="Code", description="Write code", type="code")

    prompt = builder.build_task_prompt(task)
    assert "SUBTASK:" in prompt
    assert "3 subtasks" in prompt


def test_subagent_prompt_not_injected_when_disabled():
    """When subagents disabled/None, no delegation instructions."""
    config = WiggumConfig()
    builder = PromptBuilder(config)
    task = Task(id="M1.2", title="Code", description="Write code", type="code")

    prompt = builder.build_task_prompt(task)
    assert "SUBTASK:" not in prompt


# --- Orbit wiggum.yaml compatibility ---


def test_orbit_wiggum_yaml_loads():
    """The orbit project's wiggum.yaml should parse without error."""
    orbit_config = Path("/home/admin/projects/orbit/wiggum.yaml")
    if orbit_config.exists():
        config = WiggumConfig.load(orbit_config)
        assert config.project.name == "Orbit NDA Send/Receive Workflow"
        assert config.runner.parallel_tasks is True
        assert config.runner.max_parallel == 3
        assert config.subagents is not None
        assert config.subagents.enabled is True
