"""Tests for PyWiggum."""
