# Contributing to StackShip

## Dev Setup

```bash
# Clone the repo
git clone https://github.com/ai-engineering-lab/stackship.git
cd stackship

# Create a virtual environment
python -m venv .venv
source .venv/bin/activate  # Linux/macOS
# .venv\Scripts\activate   # Windows

# Install in editable mode with dev dependencies
pip install -e ".[dev]"
```

## Running Tests

```bash
pytest -v
```

## Linting & Formatting

```bash
# Check for lint issues
ruff check .

# Auto-format code
ruff format .
```

## Type Checking

```bash
mypy stackship/ --ignore-missing-imports
```

## Submitting Changes

1. Fork the repo and create a feature branch
2. Make your changes
3. Ensure tests pass and linting is clean
4. Open a pull request against `main`
