"""Allow running the CLI via python -m stackship."""

from stackship.cli import app

if __name__ == "__main__":
    app()
