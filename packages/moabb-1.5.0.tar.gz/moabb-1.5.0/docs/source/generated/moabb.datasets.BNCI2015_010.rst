﻿moabb.datasets.BNCI2015_010
===========================

.. currentmodule:: moabb.datasets

.. autoclass:: BNCI2015_010
   :special-members: __contains__,__getitem__,__iter__,__len__,__add__,__sub__,__mul__,__div__,__neg__,__hash__
   :members:

.. include:: moabb.datasets.BNCI2015_010.examples

.. raw:: html

    <div style='clear:both'></div>