﻿moabb.datasets.BNCI2003_004
===========================

.. currentmodule:: moabb.datasets

.. autoclass:: BNCI2003_004
   :special-members: __contains__,__getitem__,__iter__,__len__,__add__,__sub__,__mul__,__div__,__neg__,__hash__
   :members:

.. include:: moabb.datasets.BNCI2003_004.examples

.. raw:: html

    <div style='clear:both'></div>