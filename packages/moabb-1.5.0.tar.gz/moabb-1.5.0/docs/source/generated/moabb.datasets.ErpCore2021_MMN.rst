﻿moabb.datasets.ErpCore2021_MMN
==============================

.. currentmodule:: moabb.datasets

.. autoclass:: ErpCore2021_MMN
   :special-members: __contains__,__getitem__,__iter__,__len__,__add__,__sub__,__mul__,__div__,__neg__,__hash__
   :members:

.. include:: moabb.datasets.ErpCore2021_MMN.examples

.. raw:: html

    <div style='clear:both'></div>