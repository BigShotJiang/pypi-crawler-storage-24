﻿moabb.datasets.MartinezCagigal2023Checker
=========================================

.. currentmodule:: moabb.datasets

.. autoclass:: MartinezCagigal2023Checker
   :special-members: __contains__,__getitem__,__iter__,__len__,__add__,__sub__,__mul__,__div__,__neg__,__hash__
   :members:

.. include:: moabb.datasets.MartinezCagigal2023Checker.examples

.. raw:: html

    <div style='clear:both'></div>