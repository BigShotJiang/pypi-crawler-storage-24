﻿moabb.evaluations.WithinSubjectSplitter
=======================================

.. currentmodule:: moabb.evaluations

.. autoclass:: WithinSubjectSplitter
   :special-members: __contains__,__getitem__,__iter__,__len__,__add__,__sub__,__mul__,__div__,__neg__,__hash__
   :members:

.. include:: moabb.evaluations.WithinSubjectSplitter.examples

.. raw:: html

    <div style='clear:both'></div>