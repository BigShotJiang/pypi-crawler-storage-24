﻿moabb.pipelines.classification.SSVEP_TRCA_R
===========================================

.. currentmodule:: moabb.pipelines.classification

.. autoclass:: SSVEP_TRCA_R
   :special-members: __contains__,__getitem__,__iter__,__len__,__add__,__sub__,__mul__,__div__,__neg__,__hash__
   :members:

.. include:: moabb.pipelines.classification.SSVEP_TRCA_R.examples

.. raw:: html

    <div style='clear:both'></div>