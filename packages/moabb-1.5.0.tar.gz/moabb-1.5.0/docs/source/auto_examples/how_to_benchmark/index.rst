

.. _sphx_glr_auto_examples_how_to_benchmark:

Benchmarking and Pipeline Evaluation
------------------------------------

Examples focusing on running benchmarks and comparing multiple models or configurations, following MOABB’s evaluation
methodology.
These scripts reflect EEG decoding best practices by evaluating algorithms under consistent conditions and
tracking performance (and even resource usage).

.. toctree::
   :hidden:



.. raw:: html

    <div class="sphx-glr-thumbnails">

.. thumbnail-parent-div-open

.. raw:: html

    <div class="sphx-glr-thumbcontainer" tooltip="This script compares the new flattened-parallel evaluation path (``_process_parallel``) against the legacy dataset-level parallel path (``_process_legacy``) introduced in the full-parallel branch.">

.. only:: html

  .. image:: /auto_examples/how_to_benchmark/images/thumb/sphx_glr_noplot_benchmark_parallel_vs_legacy_thumb.png
    :alt:

  :doc:`/auto_examples/how_to_benchmark/noplot_benchmark_parallel_vs_legacy`

.. raw:: html

      <div class="sphx-glr-thumbnail-title">Benchmark: Parallel vs Legacy Evaluation Paths</div>
    </div>


.. raw:: html

    <div class="sphx-glr-thumbcontainer" tooltip="This example shows how to use MOABB to track the CO2 footprint using CodeCarbon library. For this example, we will use only one dataset to keep the computation time low, but this benchmark is designed to easily scale to many datasets. Due to limitation of online documentation generation, the results are computed on a local cluster but could be easily replicated on your infrastructure.">

.. only:: html

  .. image:: /auto_examples/how_to_benchmark/images/thumb/sphx_glr_noplot_example_codecarbon_thumb.png
    :alt:

  :doc:`/auto_examples/how_to_benchmark/noplot_example_codecarbon`

.. raw:: html

      <div class="sphx-glr-thumbnail-title">Benchmarking with MOABB showing the CO2 footprint</div>
    </div>


.. raw:: html

    <div class="sphx-glr-thumbcontainer" tooltip="This example shows how to use MOABB to benchmark a set of pipelines on all available datasets. For this example, we will use only one dataset to keep the computation time low, but this benchmark is designed to easily scale to many datasets.">

.. only:: html

  .. image:: /auto_examples/how_to_benchmark/images/thumb/sphx_glr_plot_benchmark_thumb.png
    :alt:

  :doc:`/auto_examples/how_to_benchmark/plot_benchmark`

.. raw:: html

      <div class="sphx-glr-thumbnail-title">Benchmarking with MOABB</div>
    </div>


.. raw:: html

    <div class="sphx-glr-thumbcontainer" tooltip="This example shows how to use MOABB to benchmark a set of pipelines on all available datasets. In particular we run the Gridsearch to select the best hyperparameter of some pipelines and save the gridsearch. For this example, we will use only one dataset to keep the computation time low, but this benchmark is designed to easily scale to many datasets.">

.. only:: html

  .. image:: /auto_examples/how_to_benchmark/images/thumb/sphx_glr_plot_benchmark_grid_search_thumb.png
    :alt:

  :doc:`/auto_examples/how_to_benchmark/plot_benchmark_grid_search`

.. raw:: html

      <div class="sphx-glr-thumbnail-title">Benchmarking with MOABB with Grid Search</div>
    </div>


.. raw:: html

    <div class="sphx-glr-thumbcontainer" tooltip="Tutorial: Within-Session Splitting on Real MI Dataset">

.. only:: html

  .. image:: /auto_examples/how_to_benchmark/images/thumb/sphx_glr_plot_within_session_splitter_thumb.png
    :alt:

  :doc:`/auto_examples/how_to_benchmark/plot_within_session_splitter`

.. raw:: html

      <div class="sphx-glr-thumbnail-title">Tutorial: Within-Session Splitting on Real MI Dataset</div>
    </div>


.. thumbnail-parent-div-close

.. raw:: html

    </div>


.. toctree::
   :hidden:

   /auto_examples/how_to_benchmark/noplot_benchmark_parallel_vs_legacy
   /auto_examples/how_to_benchmark/noplot_example_codecarbon
   /auto_examples/how_to_benchmark/plot_benchmark
   /auto_examples/how_to_benchmark/plot_benchmark_grid_search
   /auto_examples/how_to_benchmark/plot_within_session_splitter

