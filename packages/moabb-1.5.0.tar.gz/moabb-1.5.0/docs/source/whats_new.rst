.. _whats_new:

.. currentmodule:: moabb

What's new
==========


.. NOTE: there are 3 separate sections for changes, based on type:

- "Enhancements" for new features
- "Bugs" for bug fixes
- "API changes" for backward-incompatible changes

.. _current:

Version 1.6  (Source - GitHub)
-------------------------------

Enhancements
~~~~~~~~~~~~
- None yet.

API changes
~~~~~~~~~~~
- None yet.

Requirements
~~~~~~~~~~~~
- None yet.

Bugs
~~~~
- None yet.

Code health
~~~~~~~~~~~
- None yet.

Version 1.5.0  (Stable - PyPi)
-------------------------------

Enhancements
~~~~~~~~~~~~
- Add 9 new dataset adapters (8 SSVEP and 1 ERP) covering 357+ subjects: :class:`moabb.datasets.Liu2020BETA` (70 subjects, 40-class JFPM), :class:`moabb.datasets.Liu2022EldBETA` (100 elderly subjects, 9-class, BIDS/GDF format), :class:`moabb.datasets.Kim2025BetaRange` (40 subjects, 40-class beta-range), :class:`moabb.datasets.Dong2023` (59 subjects, 40-class), :class:`moabb.datasets.Lee2021Mobile_SSVEP` and :class:`moabb.datasets.Lee2021Mobile_ERP` (24 subjects, mobile BCI), :class:`moabb.datasets.Chen2017SingleFlicker` (12 subjects, spatial SSVEP), :class:`moabb.datasets.Wang2021Combined` (8 subjects, combined SSVEP), and :class:`moabb.datasets.Han2024Fatigue` (24 subjects, fatigue study with low/high frequency paradigms). Add shared utilities ``build_raw_from_epochs``, ``TSINGHUA_64CH_NAMES``, and ``FIGSHARE_DL_URL`` to ``moabb.datasets.utils`` (by `Bruno Aristimunha`_)
- Add 17 new motor imagery dataset adapters covering 345+ subjects: :class:`moabb.datasets.Tavakolan2017`, :class:`moabb.datasets.Zhang2017`, :class:`moabb.datasets.Forenzo2023`, :class:`moabb.datasets.Zhou2020`, :class:`moabb.datasets.Jeong2020`, :class:`moabb.datasets.Kaya2018`, :class:`moabb.datasets.Kumar2024`, :class:`moabb.datasets.Rozado2015`, :class:`moabb.datasets.Brandl2020`, :class:`moabb.datasets.Ma2020`, :class:`moabb.datasets.Wairagkar2018`, :class:`moabb.datasets.Wu2020`, :class:`moabb.datasets.Yang2025`, :class:`moabb.datasets.Chang2025`, :class:`moabb.datasets.HefmiIch2025`, :class:`moabb.datasets.TrianaGuzman2024`, :class:`moabb.datasets.Yi2025`, and :class:`moabb.datasets.Zuo2025` (by `Bruno Aristimunha`_)
- Add :class:`moabb.datasets.GuttmannFlury2025_MI`, :class:`moabb.datasets.GuttmannFlury2025_ME`, :class:`moabb.datasets.GuttmannFlury2025_SSVEP`, and :class:`moabb.datasets.GuttmannFlury2025_P300` multi-paradigm dataset adapters with Zenodo re-hosted data (by `Bruno Aristimunha`_)
- Add :class:`moabb.datasets.Liu2025` visual imagery dataset adapter (62 subjects) with Zenodo re-hosted data, and fix :class:`moabb.datasets.Zhou2020` download path (by `Bruno Aristimunha`_)
- Add :class:`moabb.datasets.Gao2026` visual imagery dataset adapter (25 subjects) (by `Bruno Aristimunha`_)
- Add 20 :class:`moabb.datasets.mainsah2025.Mainsah2025` (BigP3BCI) P300 dataset adapters (studies A-S2, ~305 subjects from PhysioNet) (by `Bruno Aristimunha`_)
- Add 3 new P300/ERP dataset adapters: :class:`moabb.datasets.Simoes2020` (15 ASD subjects, Zenodo re-hosted from Kaggle), :class:`moabb.datasets.Speier2017` (13 subjects, RSVP), :class:`moabb.datasets.Chailloux2020` (15 subjects) (by `Bruno Aristimunha`_)
- Add :meth:`~moabb.datasets.Stieger2021.get_trial_info` and :meth:`~moabb.datasets.Stieger2021.suggest_interval` methods to help users choose an optimal epoch interval for variable-length trials, and preserve per-trial ``triallength`` metadata through BIDS conversion via annotation extras (:gh:`816`)
- Redesign dataset API pages with a structured snapshot card, visual summary blocks, HED-tag visualization, benchmark highlights, citation/public API cards, and responsive mobile improvements (:gh:`1000` by `Bruno Aristimunha`_)
- Add GA4 pageview metrics and popularity ranking to dataset documentation cards, with inline sparkline charts showing 90-day traffic trends (by `Bruno Aristimunha`_)
- Refine dataset documentation cards by removing PapersWithCode links from summary tables, folding page-view metrics into the Citation & Impact card, and adding an expandable Overview teaser with a direct link to the Overview tab (:gh:`1025` by `Bruno Aristimunha`_)
- Polish API reference page with color-coded concept highlights, section breaks, table styling, and scoped CSS to avoid affecting other pages (by `Bruno Aristimunha`_)
- Implementation of Pseudo-Online framework (:gh:`641` by `Igor Carrara`_ and `Bruno Aristimunha`_)
- Introduce a new logo for the MOABB library (:gh:`858` by `Pierre Guetschel`_ and community)
- Better verbosity control for initialization of the library (:gh:`850` by `Bruno Aristimunha`_)
- Enhanced BNCI datasets with comprehensive participant demographics documentation (by `Bruno Aristimunha`_)
- Added ``_participant_demographics`` class attribute to BNCI2014-002, BNCI2014-009, BNCI2015-001, and BNCI2015-004 for programmatic access to demographics (by `Bruno Aristimunha`_)
- Improved BIDS conversion with guaranteed montage preservation for all BNCI datasets (by `Bruno Aristimunha`_)
- Dataset-specific metadata extraction for BNCI2014-001, BNCI2014-004, and BNCI2014-008 with age, gender, and clinical information (by `Bruno Aristimunha`_)
- Improved error messages for dataset compatibility checks in evaluations - now provides specific reasons when datasets are incompatible (e.g., "dataset has only 1 session(s), but CrossSessionEvaluation requires at least 2 sessions") by `Bruno Aristimunha`_
- Ability to join rows from the tables of MOABB predictive performance scores and detailed CodeCarbon compute profiling metrics by the column `codecarbon_task_name` in MOABB results and the column `task_name` in CodeCarbon results (:gh:`866` by `Ethan Davis`_).
- Adding two c-VEP datasets: :class:`moabb.datasets.MartinezCagigal2023Checker` and :class:`moabb.datasets.MartinezCagigal2023Pary` by `Victor Martinez-Cagigal`_
- Allow custom paradigms to have multiple scores for evaluations (:gh:`948` by `Ethan Davis`_)
- Ability to parameterize the scoring rule of paradigms (:gh:`948` by `Ethan Davis`_)
- Extend scoring configuration to accept lists of metric callables, scorer objects, and tuple kwargs (e.g., `needs_proba`/`needs_threshold`) for multi-metric evaluations (:gh:`948` by `Ethan Davis`_ and `Bruno Aristimunha`_)
- Implement :class:`moabb.evaluations.WithinSubjectSplitter` for k-fold cross-validation within each subject across all sessions (by `Bruno Aristimunha`_)
- Add ``cv_class`` and ``cv_kwargs`` parameters to all evaluation classes (WithinSessionEvaluation, CrossSessionEvaluation, CrossSubjectEvaluation) for custom cross-validation strategies (:gh:`963` by `Bruno Aristimunha`_)
- Implement ``LearningCurveSplitter`` as a dedicated sklearn-compatible cross-validator for learning curves, enabling learning curve analysis with any evaluation type (:gh:`963` by `Bruno Aristimunha`_)
- Flattened parallel evaluation: CV folds are now evaluated in parallel within each dataset via ``_process_parallel()``, replacing per-fold sequential evaluation while preserving per-dataset scheduling (by `Bruno Aristimunha`_)
- Auto-generate dataset documentation admonitions (Participants, Equipment, Preprocessing, Data Access, Experimental Protocol) from class-level ``METADATA`` when missing, while preserving manually written sections (:gh:`960` by `Bruno Aristimunha`_)
- Add a "Report an Issue on GitHub" feedback section to all dataset docstrings so users can easily report dataset problems (:gh:`982` by `Bruno Aristimunha`_)
- Add ``additional_metadata`` parameter to ``paradigm.get_data()`` to fetch additional metadata columns from BIDS ``events.tsv`` files. Supports ``"all"`` to load all columns or a list of specific column names (:gh:`744` by `Matthias Dold`_)
- Add ``get_additional_metadata()`` method to :class:`moabb.datasets.base.BaseDataset` allowing datasets to provide additional metadata for epochs. Implemented for BIDS datasets in :class:`moabb.datasets.base.BaseBIDSDataset` (:gh:`744` by `Matthias Dold`_)
- Add automatic HED 8.4.0 (Hierarchical Event Descriptors) annotations to BIDS export with 83 validated paradigm-specific tags covering all MOABB datasets, ``HEDVersion`` in ``dataset_description.json``, events.json sidecar patching, per-dataset override via ``ExperimentMetadata.hed_tags``, and ``Label/`` fallback for unmapped events (:gh:`974` by `Bruno Aristimunha`_)
- Add tutorial on time-resolved decoding with :class:`mne.decoding.SlidingEstimator`, showing how to evaluate per-time-point AUC across subjects as an alternative to pseudo-online evaluation (:gh:`718` by `Bruno Aristimunha`_)
- Add advanced tutorial on Riemannian Artifact Rejection (Riemannian Potato and Potato Field) as a pre-processing step using pipeline surgery (by `Davoud Hajhassani`_ and `Bruno Aristimunha`_)
- Simplify the Riemannian Artifact Rejection tutorial by using pyRiemann's enhanced ``PotatoField`` API (per-potato metrics and configurable p-value combination), and refresh the 2D potato visualization to better match the pyRiemann reference (:gh:`1011` by `Bruno Aristimunha`_)
- Add pipeline surgery methods (``find_steps``, ``insert_step``, ``remove_step``) to ``FixedPipeline`` for easier pipeline manipulation (by `Davoud Hajhassani`_ and `Bruno Aristimunha`_)
- Add license metadata to all datasets with known licenses, covering BNCI, BrainInvaders, ErpCore2021, Castillos, MartinezCagigal2023, Beetl2021, Kojima2024, Dreyer2023, and many others (:gh:`989` by `Bruno Aristimunha`_)
- Add parametrized test ``test_all_datasets_have_license`` to ensure all datasets declare a license in their documentation metadata (:gh:`989` by `Bruno Aristimunha`_)
- Add and correct ``license`` and ``repository`` fields in ``DocumentationMetadata`` across all datasets against upstream sources; standardize all license strings to SPDX identifiers; correct DOIs for BNCI2014_002 and MAMEM1/2/3 datasets (by `Katelyn Begany`_)
- Validate and correct metadata across 45 datasets against original publications, fixing ~920 fields including country codes, preprocessing conflation, reference electrodes, and fabricated auxiliary channels (:gh:`1001` by `Bruno Aristimunha`_)
- Add :meth:`~moabb.datasets.base.BaseDataset.convert_to_bids` method for exporting raw EEG datasets to clean BIDS-compliant directory structures without processing-pipeline hash in filenames (by `Bruno Aristimunha`_)
- Expose ``subjects`` and ``sessions`` parameters on all dataset constructors to allow filtering at instantiation time (e.g., ``PhysionetMI(subjects=[1, 2, 3])``). Add ``all_subjects`` property and ``sessions`` parameter to ``get_data()`` (by `Bruno Aristimunha`_)
- Enhance Tutorial 4 ("Creating a dataset class") with a new section demonstrating :class:`~moabb.datasets.base.BaseBIDSDataset` and :class:`~moabb.datasets.base.LocalBIDSDataset` as the recommended approach for adding BIDS-format datasets to MOABB (:gh:`1007` by `Bruno Aristimunha`_)
- Add Copy and CSV export buttons to benchmark results tables on the results webpage, enabling users to copy or download table data directly (:gh:`1002` by `Bruno Aristimunha`_)
- Add license chip with official Creative Commons SVG icons to dataset documentation pages, showing license type with inline icons and links to license deeds (:gh:`1015` by `Bruno Aristimunha`_)
- Add adjusted chance levels, distribution plot, and restyle analysis plots with colorblind-friendly palette (:gh:`1019` by `Bruno Aristimunha`_)
- Enrich documentation metadata for Hinss2021, ErpCore2021 (all 7 variants), Schirrmeister2017, MartinezCagigal2023 (Checker + Pary), and Rodrigues2017 with investigators, institution, country, ethics approval, funding, contact info, acknowledgements, and citation instructions extracted from published papers. All 83 datasets now have ``investigators`` populated (:gh:`1017` by `Bruno Aristimunha`_)
- Add ``return_all_modalities`` keyword-only parameter to :class:`moabb.datasets.base.BaseDataset` and 30+ multi-modal dataset subclasses, allowing users to retain non-EEG channels (EOG, EMG, ECG, misc) when loading data. Accepts ``True`` (all non-stim channels), or a ``dict`` of :func:`mne.pick_types` keyword arguments for fine-grained control (e.g. ``dict(eeg=True, eog=True)``). The setting is respected through the preprocessing pipeline (``RawToEpochs``) and BIDS conversion so non-EEG channels survive epoching and export. Add shared ``pick_channels_for_modalities()`` helper to ``moabb.datasets.utils`` (:gh:`966`, :gh:`1030` by `Bruno Aristimunha`_)
- Add new ``moabb.analysis.neural_signatures`` module with interactive Plotly-based neural signature visualizations for all five BCI paradigms: Motor Imagery ERD/ERS topomaps, P300/ERP waveforms, SSVEP power spectra and SNR, c-VEP evoked responses with PSD, and Resting State band power distributions. Public API: ``generate_neural_signature``, ``neural_signature_html``, ``get_plotly_template``, ``get_plotly_colorscale``. Produces standalone HTML reports with MOABB branding, interactive SVG head diagrams, electrode selection, and per-subject views (:gh:`1039` by `Bruno Aristimunha`_)
- Add ``generate_figures`` parameter to :meth:`~moabb.datasets.base.BaseDataset.convert_to_bids` for optional neural signature generation into ``{bids_root}/derivatives/neural_signatures/`` during BIDS export (:gh:`1039` by `Bruno Aristimunha`_)
- Conditionally export ``generate_neural_signature`` and ``neural_signature_html`` from ``moabb.analysis`` when ``plotly`` is installed (:gh:`1039` by `Bruno Aristimunha`_)

API changes
~~~~~~~~~~~
- Removed ``SinglePass`` and ``FilterBank`` intermediate classes from motor imagery and P300 paradigms. ``FilterBankLeftRightImagery`` now inherits from ``LeftRightImagery``, ``FilterBankMotorImagery`` inherits from ``MotorImagery``, and ``P300`` inherits directly from ``BaseP300``. ``RestingStateToP300Adapter`` now inherits from ``BaseP300``. Docstring inheritance is handled via ``NumpyDocstringInheritanceInitMeta`` (:gh:`467` by `Bruno Aristimunha`_).
- Allow CodeCarbon script level configurations when instantiating a :class:`moabb.evaluations.base.BaseEvaluation` child class (:gh:`866` by `Ethan Davis`_).
- When CodeCarbon is installed, MOABB HDF5 results have an additional column `codecarbon_task_name`. If CodeCarbon is configured to save to file, its own tabular results have a column `task_name`. These columns are unique UUID4s. Related rows can be joined to see detailed costs and benefits of predictive performance and computing profiling metrics (:gh:`866` by `Ethan Davis`_).
- Isolated model fitting, duration tracking, and CodeCarbon compute profiling tracking. New and consistent ordering of duration and CodeCarbon tracking across all evaluations: (Higher priority, closest to model fitting) required duration tracking, (lower priority, second closest to model fitting) optional CodeCarbon tracking (:gh:`866` by `Ethan Davis`_).
- Replaced unreliable wall clock duration tracking (Python's `time.time()`) in favor of performance counter duration tracking (Python's `time.perf_counter()`) (:gh:`866` by `Ethan Davis`_).
- Enable choice of online or offline CodeCarbon through the parameterization of `codecarbon_config` when instantiating a :class:`moabb.evaluations.base.BaseEvaluation` child class (:gh:`956` by `Ethan Davis`_)
- Renamed stimulus channel from ``stim`` to ``STI`` in BNCI motor imagery and error-related potential datasets for clarity and BIDS compliance (by `Bruno Aristimunha`_).
- Added four new BNCI P300/ERP dataset classes: :class:`moabb.datasets.BNCI2015_009` (AMUSE), :class:`moabb.datasets.BNCI2015_010` (RSVP), :class:`moabb.datasets.BNCI2015_012` (PASS2D), and :class:`moabb.datasets.BNCI2015_013` (ErrP) (by `Bruno Aristimunha`_).
- Removed ``data_size`` and ``n_perms`` parameters from :class:`moabb.evaluations.WithinSessionEvaluation`. Use ``cv_class=LearningCurveSplitter`` with ``cv_kwargs=dict(data_size=..., n_perms=...)`` instead (:gh:`963` by `Bruno Aristimunha`_)
- Learning curve results now automatically include "data_size" and "permutation" columns when using ``LearningCurveSplitter`` (:gh:`963` by `Bruno Aristimunha`_)
- Replace wildcard imports with explicit class imports in ``moabb.paradigms`` (:gh:`1004` by `Bruno Aristimunha`_)

Requirements
~~~~~~~~~~~~
- Allows CodeCarbon environment variables or a configuration file to be defined in the home directory or the current working directory (:gh:`866` by `Ethan Davis`_).
- Added ``filelock`` as a core dependency to fix missing import errors in utils (:gh:`959` by `Mateusz Naklicki`_).
- Switch ``pyriemann`` dependency from GitHub source back to PyPI (``>=0.7``). The Riemannian Artifact Rejection tutorial still requires ``pyriemann`` from source for ``PotatoField`` features and is no longer auto-executed during doc builds (:gh:`1011` by `Bruno Aristimunha`_)
- Add type hints to :class:`moabb.evaluations.base.BaseEvaluation` and all concrete evaluation classes (:gh:`732` by `Sarthak Tayal`_)
- Add ``plotly>=5.18.0`` as optional ``interactive`` dependency (``pip install moabb[interactive]``), included in ``moabb[all]`` (:gh:`1039` by `Bruno Aristimunha`_)

Bugs
~~~~
- Fix trial acceptance condition in :class:`moabb.datasets.Stieger2021` that allowed epochs
  to extend beyond actual motor imagery duration into adjacent trials' resting periods (:gh:`816`)
- Fix DOI escaping in "See DOI" fallback link on dataset citation cards (:gh:`1000` by `Bruno Aristimunha`_)
- Prefer paper DOI over data DOI in dataset citation card when both are available (:gh:`1000` by `Bruno Aristimunha`_)
- Fix timeline SVG card artifact caused by link styling on dataset pages (by `Bruno Aristimunha`_)
- Fix dataset documentation teaser rendering by skipping raw reStructuredText directives in previews, hiding empty page-view rows when analytics are unavailable, and clearing dataset summary reST warnings (:gh:`1025` by `Bruno Aristimunha`_)
- Fix class-balance visualization counts by normalizing metadata/event class labels (e.g., ``NonTarget`` vs ``non-target``) and use the first valid dataset subject in generated quickstart snippets instead of hardcoded ``subjects=[1]`` (:gh:`1000` by `Bruno Aristimunha`_)
- Fix missing ``P300`` from the list of valid paradigms in the :func:`moabb.benchmark` docstring (by `Bruno Aristimunha`_)
- Fix critical trigger alignment bug in :class:`moabb.datasets.Liu2024` where ``create_event_array()`` selected the first 40 of 120 STI triggers (mixing instruction, MI, and break onsets) instead of filtering for only the MI onset triggers (value=2). Also fix swapped left/right hand label mapping in ``encoding()`` and correct epoch interval from ``(2, 6)`` to ``(0, 4)`` to match MI onset triggers (by `Bruno Aristimunha`_)
- Fixed incorrect DOIs in Dreyer2023, RomaniBF2025ERP, BNCI2015_003, BNCI2015_004, and BNCI2015_012 datasets (:gh:`977` by `Bruno Aristimunha`_)
- Added missing metadata DOIs for AlexMI, PhysionetMI, GrosseWentrup2009, Shin2017A, Shin2017B, BNCI2014_004, and BNCI2003_004 datasets (:gh:`977` by `Bruno Aristimunha`_)
- Fixed montage not being set before BIDS cache conversion in BNCI datasets (by `Bruno Aristimunha`_)
- Fixed measurement date setting for BNCI datasets to use specific collection years from papers (by `Bruno Aristimunha`_)
- Ensured proper subject ID assignment for BIDS compliance across all BNCI datasets (by `Bruno Aristimunha`_)
- Correct :class:`moabb.pipelines.classification.SSVEP_CCA`, :class:`moabb.pipelines.classification.SSVEP_TRCA` and :class:`moabb.pipelines.classification.SSVEP_MsetCCA` behavior (:gh:`625` by `Sylvain Chevallier`_)
- Fix scikit-learn LogisticRegression elasticnet penalty parameter deprecation by re-adding `penalty='elasticnet'` for ElasticNet configurations with `0 < l1_ratio < 1` (:gh:`869` by `Bruno Aristimunha`_)
- Fixing option to pickle model (:gh:`870` by `Ethan Davis`_)
- Normalize Zenodo download paths and add a custom user-agent to improve download robustness (:gh:`946` by `Bruno Aristimunha`_)
- Use the BNCI mirror host to avoid download timeouts (:gh:`946` by `Bruno Aristimunha`_)
- Repair incomplete or corrupted :class:`moabb.datasets.Zhou2016` subject downloads by validating extracted EEG/events files and re-downloading under a subject-level lock, preventing empty-session failures during parallel docs/CI runs (by `Bruno Aristimunha`_)
- Prevent Python mutable default argument when defining CodeCarbon configurations (:gh:`956` by `Ethan Davis`_)
- Fix copytree FileExistsError in BrainInvaders2013a download by adding dirs_exist_ok=True (by `Bruno Aristimunha`_)
- Ensure optional additional scoring columns in evaluation results (:gh:`957` by `Ethan Davis`_)
- Fix pandas ``ArrowStringArray`` shuffle warning by converting ``.unique()`` results to numpy arrays in splitters, avoiding issues with newer pandas versions (:gh:`963` by `Bruno Aristimunha`_)
- Fix crash in :class:`moabb.datasets.Huebner2017` when regex match on vhdr filenames returns ``None`` (:gh:`1036` by `Sarthak Tayal`_)
- Replace production ``assert`` statements with proper ``ValueError`` / ``TypeError`` exceptions across analysis, pipelines, paradigms, and datasets modules (:gh:`1036` by `Sarthak Tayal`_)
- Fix silent pipeline name collision in ``moabb.pipelines.utils.create_pipeline_from_config`` by raising ``ValueError`` on duplicate names (:gh:`1036` by `Sarthak Tayal`_)
- Replace bare ``print()`` calls with proper logging in :class:`moabb.datasets.MartinezCagigal2023Checker` (:gh:`1036` by `Sarthak Tayal`_)
- ``LearningCurveSplitter`` now skips training splits that collapse to a single class (e.g., with very small ``data_size``) and emits a ``RuntimeWarning`` instead of producing NaN results (:gh:`963` by `Bruno Aristimunha`_)
- Fix double µV-to-V conversion in BNCI2003-004 and BNCI2015-006: data loaded in microvolts was labeled as volts without unit conversion, causing a second scaling during EDF export via ``mne_bids`` (by `Bruno Aristimunha`_)
- Fix ``Beetl2021_A`` and ``Beetl2021_B`` 403 Forbidden errors by skipping Figshare API calls when data already exists locally, and fix double-nested zip extraction directory structure (:gh:`969` by `Bruno Aristimunha`_)
- Fix wrong channel names in Riemannian Artifact Rejection tutorial that caused ``pick()`` to fail on BNCI2014-009 (by `Bruno Aristimunha`_)
- Fix :class:`moabb.datasets.RomaniBF2025ERP` to follow MOABB nomenclature pattern by using dynamic folder name ``MNE-{code}-data`` instead of hardcoded folder name. Automatically migrates legacy folder ``BrainForm-BIDS-eeg-dataset`` to new nomenclature for backward compatibility (by `Bruno Aristimunha`_)
- Move BIDS cache lock file from the BIDS subject folder to the ``code/`` folder for BIDS validator compliance. Lock files are now written per-session as ``code/sub-{subject}_ses-{session}_desc-{hash}_lockfile.json``. Backward compatibility is preserved for caches created with the old location (:gh:`986` by `Pierre Guetschel`_ and `Bruno Aristimunha`_)
- Fixed ``erase()`` in ``BIDSInterfaceBase`` to handle multi-session datasets correctly by using per-session ``rm()`` calls instead of a single subject-level call, which previously caused a ``RuntimeError`` when looking up ``scans.tsv`` across multiple sessions (:gh:`986` by `Pierre Guetschel`_ and `Bruno Aristimunha`_)
- Fix ``MOABB_RESULTS`` default path to respect ``MNE_DATA`` configuration instead of hardcoding ``~/mne_data``, and fix docs CI cache to use workspace-relative ``MNE_DATA`` path and cache ``~/.mne`` config directory (by `Bruno Aristimunha`_)
- Fix :class:`moabb.datasets.RomaniBF2025ERP` ``get_data()`` failing with description merge error when adding stim channel, causing sessions to be silently dropped (:gh:`991` by `Bruno Aristimunha`_)
- Fix docs CI cache: set ``MNE_DATA`` env var and persist ``~/.mne`` config directory so dataset paths survive cache restore (by `Bruno Aristimunha`_)
- Fix CI dataset cache reuse across commits/PR updates by using stable cache keys and default-branch cache saves for docs/tests workflows, avoiding repeated dataset downloads (by `Bruno Aristimunha`_)
- Fix :class:`moabb.datasets.Liu2024` download failure by switching Figshare URLs from ``figshare.com/ndownloader`` to ``ndownloader.figshare.com`` and adding ``BadZipFile`` recovery for corrupted cached downloads (:gh:`992` by `Bruno Aristimunha`_)
- Remove redundant ``autoattribute METADATA`` from MartinezCagigal2023 Checker and Pary docstrings (:gh:`1022` by `Bruno Aristimunha`_)
- Fix TRCA Riemannian mean convergence failure by regularizing ill-conditioned cross-covariance matrices in :class:`moabb.pipelines.classification.SSVEP_TRCA`. Eigenvalue clamping bounds the condition number, eliminating ``Convergence not reached`` and ``invalid value encountered in log`` warnings (by `Bruno Aristimunha`_)
- Fix SSVEP CCA-family estimator consistency and eCCA formulation:
  :class:`moabb.pipelines.classification.SSVEP_CCA`,
  :class:`moabb.pipelines.classification.SSVEP_MsetCCA`,
  :class:`moabb.pipelines.classification.SSVEP_itCCA`, and
  :class:`moabb.pipelines.classification.SSVEP_eCCA` now return predictions in the same label space as ``classes_`` and align ``predict_proba`` columns with ``classes_`` order. :class:`moabb.pipelines.classification.SSVEP_CCA` and :class:`moabb.pipelines.classification.SSVEP_eCCA` now infer frequencies robustly from epochs metadata (with ``freq_map`` override), and :class:`moabb.pipelines.classification.SSVEP_eCCA` now uses the corrected 4-feature filter assignments with updated reference/citation alignment (by `Bruno Aristimunha`_)
- Add documentation note to :class:`moabb.datasets.PhysionetMI` that subject 88 was recorded at 128 Hz instead of 160 Hz, which causes errors when loaded alongside other subjects (:gh:`538` by `Bruno Aristimunha`_)
- Fix BIDS validator compliance: monkey-patch ``mne_bids`` to generate ``electrodes.json`` sidecar with ``SpatialReference`` key required by BIDS validator v2.4.0 when ``space-CapTrak`` entity is present (by `Bruno Aristimunha`_)
- Fix ``HardwareFilters`` BIDS sidecar format: wrap flat filter dicts in the required nested structure ``{"FilterName": {"key": "value"}}`` instead of writing a flat dict, and wrap string filters similarly (by `Bruno Aristimunha`_)
- Fix ``doi`` field in ``dataset_description.json`` to use BIDS-required ``doi:<value>`` format by adding the ``doi:`` prefix when missing (by `Bruno Aristimunha`_)
- Fix ``write_raw_bids`` overwrite error for multi-session datasets by detecting when a subject already exists in ``participants.tsv`` and setting ``overwrite=True`` for subsequent sessions (by `Bruno Aristimunha`_)
- Fix :class:`moabb.datasets.Ofner2017` generic channel names (``eeg-0`` .. ``eeg-60``) in subject 1 execution GDF files by mapping them to correct 10-20 montage labels (by `Bruno Aristimunha`_)
- Fix :class:`moabb.datasets.Wang2021Combined` segfault during BIDS conversion by switching from ``mne.io.read_raw_ant`` to ``mne.io.read_raw_cnt``, avoiding a crash in the ANT reader's C library (libEep) on macOS (by `Bruno Aristimunha`_)
- Fix brittle channel picking in ``BIDSInterfaceRawEDF`` that enumerated every MNE channel type keyword; replaced with stim-exclusion approach (:gh:`1030` by `Bruno Aristimunha`_)
- Fix ``set_montage`` crash in :class:`moabb.datasets.Thielen2015` when ``return_all_modalities=True`` by retyping ANA/EXG channels to ``misc`` (:gh:`1030` by `Bruno Aristimunha`_)
- Fix duplicate stim channels and dead CPz reference channel in :class:`moabb.datasets.Liu2024` when ``return_all_modalities=True`` (:gh:`1030` by `Bruno Aristimunha`_)
- Fix ``RawToEpochs`` silently stripping all non-EEG channels regardless of ``return_all_modalities`` setting (:gh:`1030` by `Bruno Aristimunha`_)
- Fix HED annotation semantics for Motor Imagery events per expert review: decompose each MI event into separate ``(Sensory-event, Experimental-stimulus, Visual-presentation)`` and ``(Agent-action, ...)`` top-level groups per HED Rules 2b/2e/2f, remove conflated ``Cue`` + ``Experimental-stimulus`` roles, fix SSVEP ``rest`` tag to ``Experiment-structure``, and extract shared ``_MI_SENSORY`` constant to reduce tag duplication. Revert arrow-specific cues from paradigm-level HED defaults to generic sensory prefix, and add per-dataset ``hed_tags`` overrides for the 6 datasets that actually use arrow cues (BNCI2014-001, BNCI2014-004, Lee2019_MI, Zhou2016, Shin2017A, GrosseWentrup2009) (:gh:`1035` by `Bruno Aristimunha`_)

Code health
~~~~~~~~~~~
- Generate dataset timeline SVGs at Sphinx build time instead of tracking pre-rendered files in git (by `Bruno Aristimunha`_)
- Fix Sphinx documentation warnings and move sliding-estimator tutorial to advanced examples (by `Bruno Aristimunha`_)
- Fix autosummary descriptions in API page by skipping ``dataset_timeline_ext`` in summary context (by `Bruno Aristimunha`_)
- Hide right sidebar and admonition icons on dataset pages for a cleaner layout using per-page meta directives (by `Bruno Aristimunha`_)
- Add GA4 pageview export script and CI workflow integration for automated dataset traffic metrics (by `Bruno Aristimunha`_)
- Resolve all 216 pytest warnings across the test suite by addressing root causes: clear Epochs annotations before concatenation, replace lambda with named function in test pipelines, re-apply montage after ``add_reference_channels``, conditionally pass ``groups`` parameter in splitters using ``GroupsConsumerMixin``, use ``os.environ`` in ``FakeDataset`` to avoid non-standard config warnings, and suppress intentional ``OptunaSearchCV`` experimental warnings at init (by `Bruno Aristimunha`_)
- Added systematic DOI validation test suite that checks format, docstring tracking, resolution, and author overlap across all datasets (:gh:`977` by `Bruno Aristimunha`_)
- Further reorganized BNCI datasets into year-specific modules (``bnci_2003``, ``bnci_2014``, ``bnci_2015``, ``bnci_2019``) with shared helpers in ``legacy_base`` for clearer maintenance. The temporary ``legacy.py`` file has been removed (by `Bruno Aristimunha`_).
- Added new datasets :class:`moabb.datasets.BNCI2020_001`, :class:`moabb.datasets.BNCI2020_002`, :class:`moabb.datasets.BNCI2022_001`, :class:`moabb.datasets.BNCI2025_001`, and :class:`moabb.datasets.BNCI2025_002` (by `Bruno Aristimunha`_).
- Persist docs/test CI MNE dataset cache across runs to reduce cold-cache downloads (:gh:`946` by `Bruno Aristimunha`_)
- Refactor evaluation scoring into shared utility functions for future improvements (:gh:`948` by `Bruno Aristimunha`_)
- Centralize CV resolution in BaseEvaluation with new ``_resolve_cv()`` method for consistent cross-validation handling across all evaluation types. Add ``_build_result()`` and ``_build_scored_result()`` helpers to centralize result dict construction across WithinSession, CrossSession, and CrossSubject evaluations, replacing manual dict assembly in each (:gh:`963` by `Bruno Aristimunha`_)
- Remove redundant learning curve methods (``get_data_size_subsets()``, ``score_explicit()``, ``_evaluate_learning_curve()``) from WithinSessionEvaluation in favor of unified splitter-based approach (:gh:`963` by `Bruno Aristimunha`_)
- Generic metadata column registration: ``LearningCurveSplitter`` declares a ``metadata_columns`` class attribute, and ``BaseEvaluation`` auto-detects it via ``hasattr(cv_class, "metadata_columns")`` instead of hardcoding class checks, making it extensible to future custom splitters (:gh:`963` by `Bruno Aristimunha`_)
- Fix ``get_n_splits()`` delegation in ``WithinSessionSplitter`` and ``WithinSubjectSplitter`` to properly forward to the inner ``cv_class.get_n_splits()`` instead of hardcoding ``n_folds``, giving correct split counts when using custom CV classes like ``LearningCurveSplitter`` (:gh:`963` by `Bruno Aristimunha`_)
- Remove dead ``_fit_and_score()`` function and unused ``paradigm``/``mne_labels`` parameters from ``_evaluate_fold()`` in ``evaluations/base.py`` (by `Bruno Aristimunha`_)
- Memory optimization in ``_process_parallel()``: pass ``X``, ``y``, ``metadata`` as top-level positional args to ``joblib.delayed()`` so the loky backend can auto-mmap large numpy arrays, avoiding N full copies for N parallel tasks (by `Bruno Aristimunha`_)
- Remove duplicate ``get_inner_splitter_metadata()`` from ``WithinSessionSplitter``, ``WithinSubjectSplitter``, and ``CrossSubjectSplitter``. All splitters now store a ``_current_splitter`` reference, and ``BaseEvaluation._build_scored_result()`` reads metadata generically from it (:gh:`963` by `Bruno Aristimunha`_)
- Extract ``_fit_cv()``, ``_maybe_save_model_cv()``, and ``_attach_emissions()`` into ``BaseEvaluation``, removing duplicated model-fitting, model-saving, and carbon-tracking boilerplate from ``WithinSessionEvaluation``, ``CrossSessionEvaluation``, and ``CrossSubjectEvaluation`` (:gh:`963` by `Bruno Aristimunha`_)
- Extract ``_load_data()`` helper into ``BaseEvaluation`` to centralize data loading logic (epoch requirement checking and ``paradigm.get_data()`` call) that was duplicated across all three evaluation classes (:gh:`963` by `Bruno Aristimunha`_)
- Extract ``_get_nchan()`` helper into ``BaseEvaluation`` to replace repeated channel count extraction (``X.info["nchan"] if isinstance(X, BaseEpochs) else X.shape[1]``) in all evaluation classes (:gh:`963` by `Bruno Aristimunha`_)
- Move ``_pipeline_requires_epochs()`` from ``evaluations.py`` to ``utils.py`` for shared access by ``BaseEvaluation._load_data()`` (:gh:`963` by `Bruno Aristimunha`_)
- Move ``WithinSessionSplitter`` creation outside the per-session loop in ``WithinSessionEvaluation``, since splitter parameters do not change per session (:gh:`963` by `Bruno Aristimunha`_)
- Add a compile smoke test (``moabb/tests/test_compilation.py``) that validates syntax for all Python files under ``moabb/`` using ``py_compile`` (:gh:`960` by `Bruno Aristimunha`_)
- Add persistent DOI resolution cache (``moabb/tests/doi_cache.json``) for ``test_doi_validation.py`` to avoid network requests on every test run, reducing DOI test time from ~9 minutes to <1 second. Refresh with ``--update-doi-cache`` (:gh:`996` by `Bruno Aristimunha`_)
- Fix ``UtilEvaluation`` test class not discovered by pytest: renamed to ``TestUtilEvaluation`` and replaced ``self.skipTest`` (unittest-only) with ``pytest.skip`` (:gh:`1005` by `Bruno Aristimunha`_)
- Add 282 parametrized tests in ``moabb/tests/test_neural_signatures.py`` covering all five paradigms, HTML generation, template/colorscale utilities, and edge cases for the ``moabb.analysis.neural_signatures`` module (:gh:`1039` by `Bruno Aristimunha`_)

Version 1.4.3 (Stable - PyPi)
-------------------------------

Enhancements
~~~~~~~~~~~~
- Add “Open in Colab” buttons for gallery examples (:gh:`853` by `Bruno Aristimunha`_)
- Refresh docs homepage design and citation visibility (:gh:`853` by `Bruno Aristimunha`_)
- Add ``FixedPipeline`` and ``moabb.datasets.preprocessing.make_fixed_pipeline`` to avoid scikit-learn unfitted pipeline warnings (:gh:`850` by `Bruno Aristimunha`_)

API changes
~~~~~~~~~~~
- None.

Requirements
~~~~~~~~~~~~
- Improve compatibility with Python 3.14 (:gh:`848` by `Bruno Aristimunha`_)

Bugs
~~~~
- Fixing warnings from the latest scikit-learn version within the Preprocessing logic (:gh:`850` by `Bruno Aristimunha`_)
- Fixing compatibility with Scikit-learn 1.8 (:gh:`852` by `Bruno Aristimunha`_)

Code health
~~~~~~~~~~~
- Generate notebooks in docs CI for Colab integration (:gh:`853` by `Bruno Aristimunha`_)


Version 1.4.2
---------------

Enhancements
~~~~~~~~~~~~
- Adding dataset :class:`moabb.datasets.RomaniBF2025ERP` converted to BIDS (:gh:`825` by `Romani Michele`_)
- Improve compute_pvals_perm function (:gh:`818` by `Quentin Barthelemy`_)

Bugs
~~~~
- Fixes the management of include/exclude datasets in :func:`moabb.benchmark`, adds additional verifications (:gh:`834` by `Anton Andreev`_)
- Fixing pagination issue with figshare (:gh:`839` by `Bruno Aristimunha`_)
- Fixes ``SetRawAnnotations`` in case no STIM channel is present (:gh:`838` by `Pierre Guetschel`_ and `Simon Kojima`_)

API changes
~~~~~~~~~~~
- None.



Version  - 1.4
-----------------------
Enhancements
~~~~~~~~~~~~
- Update to pyRiemann 0.9 and numpy 2.0 for improved compatibility (:gh:`789` by `Gregoire Cattan`_ and `Bruno Aristimunha`_)
- Adding :class:`moabb.datasets.Kojima2024A` (:gh:`807` by `Simon Kojima`_)
- Adding :class:`moabb.datasets.Kojima2024B` (:gh:`806` by `Simon Kojima`_)
- Add new dataset :class:`moabb.datasets.BNCI2003_004` dataset (:gh:`811` by `Griffin Keeler`_)
- Added the ability to feed pipelines using a list of dictionaries in :func:`moabb.benchmark` (:gh:`826` by `Anton Andreev`_)

Bugs
~~~~
- Fixing label swapped issue with  :class:`moabb.datasets.Kalunga2016` dataset (:gh:`814` by `Griffin Keeler`_)
- Fix the :class:`moabb.datasets.Dreyer2023` (:gh:`828` by `Simon Kojima`_)

API changes
~~~~~~~~~~~
- None.


Version  - 1.3
--------------------------------------

Enhancements
~~~~~~~~~~~~
- Adding a tutorial for :class:`moabb.evaluations.splitters.WithinSessionSplitter` (:gh:`776` by `Thomas Kooiman`_, `Paul Verhoeven`_, `Jorge Sanmartin Martinez`_, and `Radovan Vodila`_ )
- Adding new motor imagery dataset, Dreyer2023 (:gh:`404` by `Sara Sedlar`_, `Sylvain Chevallier`_ and `Bruno Aristimunha`_)
- Reordering the examples in the documentation (:gh:`706` by `Bruno Aristimunha`_)
- Creating the meta information for the BIDS converted datasets (:gh:`688` by `Bruno Aristimunha`_)
- Adding :class:`moabb.datasets.Beetl2021_A` and :class:`moabb.datasets.Beetl2021_B` (:gh:`675` by `Samuel Boehm`_)
- Adding :class:`moabb.evaluations.splitters.CrossSubjectSplitter` (:gh:`722` by `Bruna Lopes`_ and `Bruno Aristimunha`_)
- Adding :class:`moabb.evaluations.splitters.CrossSessionSplitter` (:gh:`720` by `Bruna Lopes`_ and `Bruno Aristimunha`_)
- Adding :class:`moabb.datasets.base.BaseBIDSDataset` and :class:`moabb.datasets.base.LocalBIDSDataset` (:gh:`724` by `Pierre Guetschel`_)
- Adding :func:`moabb.analysis.plotting.dataset_bubble_plot` plus the corresponding tutorial (:gh:`753` by `Pierre Guetschel`_)
- Adding ``moabb.datasets.utils.plot_all_datasets`` and update the tutorial (:gh:`758` by `Pierre Guetschel`_)
- Improve the dataset model cards in each API page (:gh:`765` by `Pierre Guetschel`_)
- Refactor :class:`moabb.evaluations.CrossSessionEvaluation`, :class:`moabb.evaluations.CrossSubjectEvaluation` and  :class:`moabb.evaluations.WithinSessionEvaluation` to use the new splitter classes (:gh:`769` by `Bruno Aristimunha`_)
- Adding tutorial on using mne-features (:gh:`762` by `Alexander de Ranitz`_, `Luuk Neervens`_, `Charlynn van Osch`_ and `Bruno Aristimunha`_)
- Creating tutorial to expose the pre-processing steps (:gh:`771` by `Bruno Aristimunha`_)
- Add function to auto-generate tables for the paper results documentation page (:gh:`785` by `Lucas Heck`_)
- Improving the Filterbank tutorial and implementing the mutual information selection to reproduce the FilterbankCSP (:gh:`787` by `Bruno Aristimunha`_)
- A tutorial on how to create and use a MOABB dataset from X y (non continuous, epoched) data (:gh:`800` by `Anton Andreev`_)
- Improving the parallel writing of results (:gh:`803` by `Bruno Aristimunha`_)

Bugs
~~~~
- Fix regression in evaluations ignoring ``process_pipeline`` flag (:gh:`774` by `Bruno Aristimunha`_)
- Fix caching issue with incomplete results (:gh:`715` by `Sylvain Chevallier`_)
- Fix learning curve example (:gh:`717` by `Pierre Guetschel`_)
- Pick all data channels in filter preprocessing step (:gh:`729` by `Pierre Guetschel`_)
- Fix CI for permutation testing (:gh:`757` by `Quentin Barthelemy`_)
- Fix download issue with Schirrmeister2017 dataset (:gh:`751` by `Zheyu Yao`_)
- Fix code carbon example code (:gh:`777` by `Amar Enkhbat`_)
- Including the fix_bad_channels for the :class:`moabb.datasets.Stieger2021` (:gh:`783` by `Bruno Aristimunha`_)
- Fix the :class:`moabb.datasets.Wang2016` (:gh:`781` by `Ulysse Durand`_)
- Fix warnings raised when building the documentation (:gh:`784` by `Lucas Heck`_)
- Remove an unnecessary line in the README.md (:gh:`791` by `Lionel Kusch`_)
- Update the dead link about the tutorial of GitHub in CONTRIBUTING.md (:gh:`792` by `Lionel Kusch`_)
- Fix: number of trial per class for PHMD_ML dataset (:gh:`797` by `Gregoire Cattan`_)
- Converting the :class:`moabb.datasets.Zhou2016` to BIDS (:gh:`802` by `Bruno Aristimunha`_)

API changes
~~~~~~~~~~~
- Removing the deep learning module from inside moabb in favour of braindecode integration (:gh:`692` by `Bruno Aristimunha`_ )


Version - 1.2.0
----------------


Enhancements
~~~~~~~~~~~~
- Adding :class:`moabb.evaluations.splitters.WithinSessionSplitter` (:gh:`664` by `Bruna Lopes_`)
- Update version of pyRiemann to 0.7 (:gh:`671` by `Gregoire Cattan`_)
- Add columns definitions in the datasets doc (:gh:`672` by `Pierre Guetschel`_)
- Add ERP CORE datasets :class:`moabb.datasets.erpcore2021.ErpCore2021` dataset (:gh:`627` by `Taha Habib`_)
- Update paths of BIDS cache to better follow the standards. Cache created in previous MOABB versions should still be compatible (:gh:`707` by `Pierre Guetschel`_)

Bugs
~~~~

- Fix Stieger2021 dataset bugs (:gh:`651` by `Martin Wimpff`_)
- Unpinning major version Scikit-learn and numpy (:gh:`652` by `Bruno Aristimunha`_)
- Replacing the func:`numpy.string_` to func:`numpy.bytes_` (:gh:`665` by `Bruno Aristimunha`_)
- Fixing the set_download_dir that was not working when we tried to set the dir more than 10 times at the same time (:gh:`668` by `Bruno Aristimunha`_)
- Creating stimulus channels in :class:`moabb.datasets.Zhou2016` and :class:`moabb.datasets.PhysionetMI` to allow braindecode compatibility (:gh:`669` by `Bruno Aristimunha`_)
- Improving the CI (:gh:`686` by `Bruno Aristimunha`_)
- Making the download test work again (:gh:`693` by `Bruno Aristimunha`_)
- Fix the EpochSelectChannel that caused incorrect channel selection in `example <examples/plot_Hinss2021_classification.py>`__ (:gh:`685` by `AFF`)
- Fixing the logger on the Stieger2021 and Wang2016 dataset (:gh:`693` by `Bruno Aristimunha`_)
- Change the way of creating the path to the folder (:gh:`697` by `Sebastien Velut`_)
- Fixing bug with braindecode and moabb datasets EPFLP300 (:gh:`696` by `Bruno Aristimunha`_)
- Fixing the dataset details for bids conversion (:gh:`698` by `Bruno Aristimunha`_)
- Fixing unit issue and lack of montage with :class:`moabb.datasets.Rodrigues2017`, :class:`moabb.datasets.Rodrigues2017`, :class:`moabb.datasets.castillos2023.BaseCastillos2023`,  :class:`moabb.datasets.castillos2023.BaseCastillos2023`,  :class:`moabb.datasets.Huebner2018`,  :class:`moabb.datasets.Cattan2019_PHMD`, :class:`moabb.datasets.Ofner2017`  (:gh:`700`  `Bruno Aristimunha`_)
- Fix t-test permutation tests (:gh:`684` and :gh:`709` by `Gregoire Cattan`_, `Anton Andreev`_, `Marco Congedo`_ and `Bruno Aristimunha`_)


API changes
~~~~~~~~~~~
- Removing the braindecode module from inside moabb (:gh:`666` by `Bruno Aristimunha`_ )



Version - 1.1.1
----------------

Enhancements
~~~~~~~~~~~~
- Add possibility to use OptunaGridSearch (:gh:`630` by `Igor Carrara`_)
- Add scripts to upload results on PapersWithCode (:gh:`561` by `Pierre Guetschel`_)
- Centralize dataset summary tables in CSV files (:gh:`635` by `Pierre Guetschel`_)
- Add new dataset :class:`moabb.datasets.Liu2024` dataset (:gh:`619` by `Taha Habib`_)
- Add choice to choose the size of time window (by `Sebastien Velut`_)



Bugs
~~~~
- Fix caching in the workflows (:gh:`632` by `Pierre Guetschel`_)

API changes
~~~~~~~~~~~
- Include optuna as soft-dependency in the benchmark function and in the base of evaluation (:gh:`630` by `Igor Carrara`_)



Version - 1.1.0
----------------


Enhancements
~~~~~~~~~~~~

- Add cache option to the evaluation (:gh:`518` by `Bruno Aristimunha`_)
- Option to interpolate channel in paradigms' `match_all` method (:gh:`480` by `Gregoire Cattan`_)
- Add leave k-Subjects out evaluations (:gh:`470` by `Bruno Aristimunha`_)
- Update Braindecode dependency to 0.8 (:gh:`542` by `Pierre Guetschel`_)
- Improve transform function of AugmentedDataset (:gh:`541` by `Quentin Barthelemy`_)
- Add new paper results website (:gh:`556` by `Bruno Aristimunha`_)
- Move cVEP common functions to ``moabb.datasets.utils`` (:gh:`564` :gh:`557` by `Pierre Guetschel`_)
- Normalize c-VEP description tables (:gh:`562` :gh:`566` by `Pierre Guetschel`_ and `Bruno Aristimunha`_)
- Update citation in README (:gh:`573` by `Igor Carrara`_)
- Update pyRiemann dependency (:gh:`577` by `Gregoire Cattan`_)
- Add resting stage Hinss2021 dataset (:gh:`580` by `Gregoire Cattan`_ and `Yash Chauhan`_)
- Expose the `learning` rate parameter in the keras deep learning methods and optimize parameters (:gh:`589` and :gh:`592` by `Bruno Aristimunha`_)
- Updating the braindecode pipelines for the new braindecode version 0.8.1 (:gh:`589` by `Bruno Aristimunha`_)
- Add SSVEP and ERP paradigms to DL pipelines (:gh:`590` by `Pierre Guetschel`_)
- Allow to pass a single pipeline file to ``benchmark`` (:gh:`591` by `Pierre Guetschel`_)
- Add new dataset :class:`moabb.datasets.Stieger2021` (:gh:`604` by `Reinmar Kobler`_ and `Bruno Aristimunha`_)
- Exposing the `drop_rate` for all the deep learning parameters (:gh:`592` by `Bruno Aristimunha`_)
- Add new dataset :class:`moabb.datasets.Rodrigues2017` dataset (:gh:`602` by `Gregoire Cattan`_ and `Pedro L. C. Rodrigues`_)
- Change unittest to pytest (:gh:`618` by `Bruno Aristimunha`_)
- Remove tensorflow import warning (:gh:`622` by `Bruno Aristimunha`_)

Bugs
~~~~

- Fix TRCA implementation for different stimulation freqs and for signal filtering (:gh:522 by `Sylvain Chevallier`_)
- Fix saving to BIDS runs with a description string in their name (:gh:`530` by `Pierre Guetschel`_)
- Fix import of keras BatchNormalization for TF 2.13 and higher (:gh:`544` by `Brian Irvine`_)
- Fix the doc summary tables of :class:`moabb.datasets.Lee2019_SSVEP` (:gh:`548` :gh:`547` :gh:`546` by `Pierre Guetschel`_)
- Fix the doc summary for Castillos2023 dataset (:gh:`561` by `Bruno Aristimunha`_)
- Fix format string receiving incorrect number of args in bids interface (:gh:`563` by `Pierre Guetschel`_)
- Fix number of sessions in doc of :class:`moabb.datasets.Sosulski2019` (:gh:`565` by `Pierre Guetschel`_)
- Fix `code` column of :class:`moabb.datasets.CastillosCVEP100` and :class:`moabb.datasets.CastillosCVEP100` (:gh:`567` by `Pierre Guetschel`_)
- MAINT updating the packages pre-release (:gh:`578` by `Bruno Aristimunha`_)
- Fix mne_bids version incompatibility with mne (:gh:`586` by `Bruna Lopes`_)
- Updating the parameters of the SSVEP_TRCA method (:gh:`589` by `Bruno Aristimunha`_)
- Fix and updating the parameters for the benchmark function (:gh:`588` by `Bruno Aristimunha`_)
- Fix result table display (:gh:`599` by `Sylvain Chevallier`_)
- Fix ``SetRawAnnotations`` setting incorrect annotations when the dataset's interval does not start at 0 (:gh:`607` by `Pierre Guetschel`_)
- Fix download link for GigaDB Cho2017 and Lee2019 datasets (:gh:`621` by `Anton Andreev`_)


API changes
~~~~~~~~~~~

- None


Version - 1.0.0
----------------

Enhancements
~~~~~~~~~~~~

- Adding extra thank you section in the documentation (:gh:`390` by `Bruno Aristimunha`_)
- Adding new script to get the meta information of the datasets (:gh:`389` by `Bruno Aristimunha`_)
- Fixing the dataset description based on the meta information (:gh:`389` and `398` by `Bruno Aristimunha`_ and `Sara Sedlar`_)
- Adding second deployment of the documentation (:gh:`374` by `Bruno Aristimunha`_)
- Adding Parallel evaluation for :func:`moabb.evaluations.WithinSessionEvaluation` , :func:`moabb.evaluations.CrossSessionEvaluation` (:gh:`364` by `Bruno Aristimunha`_)
- Add example with VirtualReality BrainInvaders dataset (:gh:`393` by `Gregoire Cattan`_ and `Pedro L. C. Rodrigues`_)
- Adding saving option for the models (:gh:`401` by `Bruno Aristimunha`_ and `Igor Carrara`_)
- Adding example to load different type of models (:gh:`401` by `Bruno Aristimunha`_ and `Igor Carrara`_)
- Add resting state paradigm with dataset and example (:gh:`400` by `Gregoire Cattan`_ and `Pedro L. C. Rodrigues`_)
- Speeding the augmentation method by 400% with NumPy vectorization  (:gh:`419` by `Bruno Aristimunha`_)
- Add possibility to convert datasets to BIDS, plus `example <examples/example_bids_conversion.py>`__ (PR :gh:`408`, PR :gh:`391` by `Pierre Guetschel`_ and `Bruno Aristimunha`_)
- Allow caching intermediate processing steps on disk, plus `example <examples/example_disk_cache.py>`__ (PR :gh:`408`, issue :gh:`385` by `Pierre Guetschel`_)
- Restructure the paradigms and datasets to move all preprocessing steps to ``moabb.datasets.preprocessing`` and as sklearn pipelines (PR :gh:`408` by `Pierre Guetschel`_)
- Add :func:`moabb.paradigms.FixedIntervalWindowsProcessing` and :func:`moabb.paradigms.FilterBankFixedIntervalWindowsProcessing`, plus `example <examples/example_fixed_interval_windows.py>`__ (PR :gh:`408`, issue :gh:`424` by `Pierre Guetschel`_)
- Define :func:`moabb.paradigms.base.BaseProcessing`, common parent to :func:`moabb.paradigms.base.BaseParadigm` and :func:`moabb.paradigms.BaseFixedIntervalWindowsProcessing` (PR :gh:`408` by `Pierre Guetschel`_)
- Allow passing a fixed processing pipeline to :func:`moabb.paradigms.base.BaseProcessing.get_data` and cache its result on disk (PR :gh:`408`, issue :gh:`367` by `Pierre Guetschel`_)
- Update :func:`moabb.datasets.fake.FakeDataset`'s code to be unique for each parameter combination (PR :gh:`408` by `Pierre Guetschel`_)
- Systematically set the annotations when loading data, eventually using the stim channel (PR :gh:`408` by `Pierre Guetschel`_)
- Allow :func:`moabb.datasets.utils.dataset_search` to search across paradigms ``paradigm=None`` (PR :gh:`408` by `Pierre Guetschel`_)
- Improving the review processing with more pre-commit bots (:gh:`435` by `Bruno Aristimunha`_)
- Add methods ``make_processing_pipelines`` and ``make_labels_pipeline`` to :class:`moabb.paradigms.base.BaseProcessing` (:gh:`447` by `Pierre Guetschel`_)
- Pipelines' digests are now computed from the whole processing+classification pipeline (:gh:`447` by `Pierre Guetschel`_)
- Update all dataset codes to remove white spaces and underscores (:gh:`448` by `Pierre Guetschel`_)
- Add ``moabb.utils.depreciated_alias`` decorator (:gh:`455` by `Pierre Guetschel`_)
- Rename many dataset class names to standardize and deprecate old names (:gh:`455` by `Pierre Guetschel`_)
- Change many dataset codes to match the class names (:gh:`455` by `Pierre Guetschel`_)
- Add ``moabb.datasets.compound_dataset.utils.compound_dataset_list``  (:gh:`455` by `Pierre Guetschel`_)
- Add c-VEP paradigm and Thielen2021 c-VEP dataset (:gh:`463` by `Jordy Thielen`_)
- Add option to plot scores vertically. (:gh:`417` by `Sara Sedlar`_)
- Change naming scheme for runs and sessions to align to BIDS standard (:gh:`471` by `Pierre Guetschel`_)
- Increase the python version to 3.11 (:gh:`470` by `Bruno Aristimunha`_)
- Add match_all method in paradigm to support CompoundDataset evaluation with MNE epochs (:gh:`473` by `Gregoire Cattan`_)
- Automate setting of event_id in compound dataset and add `data_origin` information to the data (:gh:`475` by `Gregoire Cattan`_)
- Add possibility of not saving the model (:gh:`489` by `Igor Carrara`_)
- Add CVEP and BurstVEP dataset from Castillos from Toulouse lab (:gh:`531` by `Sebastien Velut`_)
- Add c-VEP dataset from Thielen et al. 2015 (:gh:`557` by `Jordy Thielen`_)

Bugs
~~~~

- Restore 3 subject from Cho2017 (:gh:`392` by `Igor Carrara`_ and `Sylvain Chevallier`_)
- Correct downloading with VirtualReality BrainInvaders dataset (:gh:`393` by `Gregoire Cattan`_)
- Rename event `subtraction` in :func:`moabb.datasets.Shin2017B` (:gh:`397` by `Pierre Guetschel`_)
- Save parameters of :func:`moabb.datasets.PhysionetMI` (:gh:`403` by `Pierre Guetschel`_)
- Fixing issue with parallel evaluation (:gh:`401` by `Bruno Aristimunha`_ and `Igor Carrara`_)
- Fixing SSLError from BCI competition IV (:gh:`404` by `Bruno Aristimunha`_)
- Fixing ``moabb.datasets.bnci.MNEBNCI.data_path`` that returned the data itself instead of paths (:gh:`412` by `Pierre Guetschel`_)
- Adding ``moabb.datasets.fake`` in the init file to use in braindecode object (:gh:`414` by `Bruno Aristimunha`_)
- Fixing the parallel download issue when the dataset have the same directory (:gh:`421` by `Sara Sedlar`_)
- Fixing fixes the problem with the annotation loading for the P300 datasets Sosulski2019, Huebner2017 and Huebner2018 (:gh:`396` by `Sara Sedlar`_)
- Removing the print in the dataset list (:gh:`423` by `Bruno Aristimunha`_)
- Fixing bug in ``moabb.pipelines.utils_pytorch.BraindecodeDatasetLoader`` where incorrect y was used in transform calls (:gh:`426` by `Gabriel Schwartz`_)
- Fixing one test in ``moabb.pipelines.utils_pytorch.BraindecodeDatasetLoader`` (:gh:`426` by `Bruno Aristimunha`_)
- Fix :func:`moabb.benchmark` overwriting ``include_datasets`` list (:gh:`408` by `Pierre Guetschel`_)
- Fix :func:`moabb.paradigms.base.BaseParadigm` using attributes before defining them  (PR :gh:`408`, issue :gh:`425` by `Pierre Guetschel`_)
- Fix ``FakeImageryParadigm``, ``FakeP300Paradigm`` and ``FakeSSVEPParadigm`` ``is_valid`` methods to only accept the correct datasets (PR :gh:`408` by `Pierre Guetschel`_)
- Fix ``dataset_list`` construction, which could be empty due to bad import order (PR :gh:`449` by `Thomas Moreau`_).
- Fixing dataset downloader from servers with non-http (PR :gh:`433` by `Sara Sedlar`_)
- Fix ``dataset_list`` to include deprecated datasets (PR :gh:`464` by `Bruno Aristimunha`_)
- Fixed bug in ``moabb.analysis.results.get_string_rep`` to handle addresses such as 0x__0A as well (PR :gh:`468` by `Anton Andreev`_)
- Moving the ``moabb.evaluations.grid_search`` to inside the base evaluation (:gh:`487` by `Bruno Aristimunha`_)
- Removing joblib Parallel (:gh:`488` by `Igor Carrara`_)
- Fix case when events specified via ``raw.annotations`` but no events (:gh:`491` by `Pierre Guetschel`_)
- Fix bug in downloading Shin2017A dataset (:gh:`493` by `Igor Carrara`_)
- Fix the cropped option in the dataset preprocessing (:gh:`502` by `Bruno Aristimunha`_)
- Fix bug in :func:`moabb.datasets.utils.dataset_search` with missing cvep paradigm (:gh:`557` by `Jordy Thielen`_)
- Fix mistakes in ``moabb.datasets.thielen2021`` considering wrong docs and hardcoded trial stim channel (:gh:`557` by `Jordy Thielen`_)

API changes
~~~~~~~~~~~

- None


Version - 0.5.0
---------------

Enhancements
~~~~~~~~~~~~
- Speeding the augmentation model (:gh:`365` by `Bruno Aristimunha`_)
- Add VirtualReality BrainInvaders dataset (:gh:`358` by `Gregoire Cattan`_)
- Switch to python-3.8, update dependencies, fix code link in doc, add `code coverage <https://app.codecov.io/gh/NeuroTechX/moabb>`__ (:gh:`315` by `Sylvain Chevallier`_)
- Adding a comprehensive benchmarking function (:gh:`264` by `Divyesh Narayanan`_ and `Sylvain Chevallier`_)
- Add meta-information for datasets in documentation (:gh:`317` by `Bruno Aristimunha`_)
- Add GridSearchCV for different evaluation procedure (:gh:`319` by `Igor Carrara`_)
- Add new tutorial to benchmark with GridSearchCV (:gh:`323` by `Igor Carrara`_)
- Add six deep learning models (Tensorflow), and build a tutorial to show to use the deep learning model (:gh:`326` by `Igor Carrara`_, `Bruno Aristimunha`_ and `Sylvain Chevallier`_)
- Add a augmentation model to the pipeline (:gh:`326` by `Igor Carrara`_)
- Add BrainDecode example (:gh:`340` by `Igor Carrara`_ and `Bruno Aristimunha`_)
- Add Google Analytics to the documentation (:gh:`335` by `Bruno Aristimunha`_)
- Add support to Braindecode classifier (:gh:`328` by `Bruno Aristimunha`_)
- Add CodeCarbon to track emission CO₂ (:gh:`350` by `Igor Carrara`_, `Bruno Aristimunha`_ and `Sylvain Chevallier`_)
- Add CodeCarbon example (:gh:`356` by `Igor Carrara`_ and `Bruno Aristimunha`_)
- Add MsetCCA method for SSVEP classification, parametrise CCA `n_components` in CCA based methods (:gh:`359` by `Emmanuel Kalunga`_ and `Sylvain Chevallier`_)
- Set epochs' `metadata` field in `get_data` (:gh:`371` by `Pierre Guetschel`_)
- Add possibility to use transformers to apply fixed pre-processings before evaluations (:gh:`372` by `Pierre Guetschel`_)
- Add `seed` parameter to `FakeDataset` (:gh:`372` by `Pierre Guetschel`_)

Bugs
~~~~
- Fix circular import with braindecode (:gh:`363` by `Bruno Aristimunha`_)
- Fix bug for MotorImagery when we handle all events (:gh:`327` by `Igor Carrara`_)
- Fixing CI to handle with new deep learning dependencies (:gh:`332` and :gh:`326` by `Igor Carrara`_, `Bruno Aristimunha`_ and `Sylvain Chevallier`_)
- Correct CI error due to isort (:gh:`330` by `Bruno Aristimunha`_)
- Restricting Python <= 3.11 version and adding tensorflow, keras, scikeras, braindecode, skorch and torch, as optional dependence (:gh:`329` by `Bruno Aristimunha`_)
- Fix numpy variable to handle with the new version of python (:gh:`324` by `Bruno Aristimunha`_)
- Correct CI error due to black (:gh:`292` by `Sylvain Chevallier`_)
- Preload Schirrmeister2017 raw files (:gh:`290` by `Pierre Guetschel`_)
- Incorrect event assignation for Lee2019 in MNE >= 1.0.0 (:gh:`298` by `Sylvain Chevallier`_)
- Correct usage of name simplification function in analyze (:gh:`306` by `Divyesh Narayanan`_)
- Fix downloading path issue for Weibo2014 and Zhou2016, numy error in DemonsP300 (:gh:`315` by `Sylvain Chevallier`_)
- Fix unzip error for Huebner2017 and Huebner2018 (:gh:`318` by `Sylvain Chevallier`_)
- Fix n_classes when events set to None (:gh:`337` by `Igor Carrara`_ and `Sylvain Chevallier`_)
- Change n_jobs=-1 to self.n_jobs in GridSearch (:gh:`344` by `Igor Carrara`_)
- Fix dropped epochs issue (:gh:`371` by `Pierre Guetschel`_)
- Fix redundancy website issue (:gh:`372` by `Bruno Aristimunha`_)

API changes
~~~~~~~~~~~

- None

Version - 0.4.6
---------------

Enhancements
~~~~~~~~~~~~

- Add P300 BrainInvaders datasets (:gh:`283` by `Sylvain Chevallier`_)
- Add explicit warning when lambda function are used to parametrize pipelines (:gh:`278` by `Jan Sosulski`_)


Bugs
~~~~

- Correct default path for ERP visualization (:gh:`279` by `Jan Sosulski`_)
- Correct documentation (:gh:`282` and :gh:`284` by `Jan Sosulski`_)



Version - 0.4.5
---------------

Enhancements
~~~~~~~~~~~~

- Progress bars, pooch, tqdm (:gh:`258` by `Divyesh Narayanan`_ and `Sylvain Chevallier`_)
- Adding test and example for set_download_dir (:gh:`249` by `Divyesh Narayanan`_)
- Update to newer version of Schirrmeister2017 dataset (:gh:`265` by `Robin Schirrmeister`_)
- Adding Huebner2017 and Huebner2018 P300 datasets (:gh:`260`  by `Jan Sosulski`_)
- Adding Sosulski2019 auditory P300 datasets (:gh:`266`  by `Jan Sosulski`_)
- New script to visualize ERP on all datasets, as a sanity check (:gh:`261`  by `Jan Sosulski`_)

Bugs
~~~~

- Removing dependency on mne method for PhysionetMI data downloading, renaming runs (:gh:`257` by `Divyesh Narayanan`_)
- Correcting events management in Schirrmeister2017, renaming session and run (:gh:`255` by `Pierre Guetschel`_ and `Sylvain Chevallier`_)
- Switch session and runs in MAMEM1, 2 and 3 to avoid error in WithinSessionEvaluation (:gh:`256` by `Sylvain Chevallier`_)
- Correct doctstrings for the documentation, including Lee2017 (:gh:`256` by `Sylvain Chevallier`_)


Version - 0.4.4
---------------

Enhancements
~~~~~~~~~~~~

- Add TRCA algorithm for SSVEP (:gh:`238` by `Ludovic Darmet`_)

Bugs
~~~~

- Remove unused argument from dataset_search (:gh:`243` by `Divyesh Narayanan`_)
- Remove MNE call to `_fetch_dataset` and use MOABB `_fetch_file` (:gh:`235` by `Jan Sosulski`_)
- Correct doc formatting (:gh:`232` by `Sylvain Chevallier`_)

API changes
~~~~~~~~~~~

- Minimum supported Python version is now 3.7
- MOABB now depends on scikit-learn >= 1.0


Version - 0.4.3
----------------

Enhancements
~~~~~~~~~~~~

- Rewrite Lee2019 to add P300 and SSVEP datasets (:gh:`217` by `Pierre Guetschel`_)

Bugs
~~~~

- Avoid information leakage for MNE Epochs pipelines in evaluation (:gh:`222` by `Sylvain Chevallier`_)
- Correct error in set_download_dir (:gh:`225` by `Sylvain Chevallier`_)
- Ensure that channel order is consistent across dataset when channel argument is specified in paradigm (:gh:`229` by `Sylvain Chevallier`_)

API changes
~~~~~~~~~~~

- ch_names argument added to init of moabb.datasets.fake.FakeDataset (:gh:`229` by `Sylvain Chevallier`_)

Version - 0.4.2
---------------

Enhancements
~~~~~~~~~~~~
- None

Bugs
~~~~
- Correct error when downloading Weibo dataset  (:gh:`212` by `Sylvain Chevallier`_)

API changes
~~~~~~~~~~~
- None

Version - 0.4.1
---------------

Enhancements
~~~~~~~~~~~~
- None

Bugs
~~~~
- Correct path error for first time launch (:gh:`204` by `Sylvain Chevallier`_)
- Fix optional dependencies issues for PyPi (:gh:`205` by `Sylvain Chevallier`_)

API changes
~~~~~~~~~~~
- Remove update_path on all datasets, `update_path` parameter in `dataset.data_path()` is deprecated (:gh:`207` by `Sylvain Chevallier`_)

Version - 0.4.0
---------------

Enhancements
~~~~~~~~~~~~
- Implementation for learning curves (:gh:`155` by `Jan Sosulski`_)
- Adding Neiry Demons P300 dataset (:gh:`156` by `Vladislav Goncharenko`_)
- Coloredlogs removal (:gh:`163` by `Vladislav Goncharenko`_)
- Update for README (:gh:`164` by `Vladislav Goncharenko`_ and `Sylvain Chevallier`_)
- Test all relevant python versions in Github Actions CI (:gh:`167` by `Vladislav Goncharenko`_)
- Adding motor imagery part of the Lee2019 dataset (:gh:`170` by `Ali Abdul Hussain`_)
- CI: deploy docs from CI pipeline  (:gh:`124` by `Erik Bjäreholt`_, `Divyesh Narayanan`_ and `Sylvain Chevallier`_)
- Remove dependencies: WFDB and pyunpack (:gh:`180` and :gh:`188` by `Sylvain Chevallier`_)
- Add support for FigShare API (:gh:`188` by `Sylvain Chevallier`_)
- New download backend function relying on Pooch, handling FTP, HTTP and HTTPS (:gh:`188` by `Sylvain Chevallier`_)
- Complete rework of examples and tutorial (:gh:`188` by `Sylvain Chevallier`_)
- Change default storage location for results: instead of moabb source code directory it is now stored in mne_data (:gh:`188` by `Sylvain Chevallier`_)
- Major update of test (:gh:`188` by `Sylvain Chevallier`_)
- Adding troubleshooting and badges in README (:gh:`189` by `Jan Sosulski`_ and `Sylvain Chevallier`_)
- Use MNE epoch in evaluation (:gh:`192` by `Sylvain Chevallier`_)
- Allow changing of storage location (:gh:`192` by `Divyesh Narayanan`_ and `Sylvain Chevallier`_)
- Deploy docs on moabb.github.io (:gh:`196` by `Sylvain Chevallier`_)
- Broadening subject_list type for :class:`moabb.datasets.base.BaseDataset` (:gh:`198` by `Sylvain Chevallier`_)
- Adding this what's new (:gh:`200` by `Sylvain Chevallier`_)
- Improving cache usage and save computation time in CI (:gh:`200` by `Sylvain Chevallier`_)
- Rewrite Lee2019 to add P300 and SSVEP datasets (:gh:`217` by `Pierre Guetschel`_)


Bugs
~~~~
- Restore basic logging (:gh:`177` by `Jan Sosulski`_)
- Correct wrong type of results dataframe columns (:gh:`188` by `Sylvain Chevallier`_)
- Add ``accept`` arg to acknowledge licence for :func:`moabb.datasets.Shin2017A` and :func:`moabb.datasets.Shin2017B` (:gh:`201` by `Sylvain Chevallier`_)

API changes
~~~~~~~~~~~
- Drop `update_path` from moabb.download.data_path and moabb.download.data_dl


Version 0.3.0
----------------

Enhancements
~~~~~~~~~~~~
- Expose sklearn error_score parameter (:gh:`70` by `Jan Sosulski`_)
- Adds a ``unit_factor`` attribute to base_paradigms (:gh:`72` by `Jan Sosulski`_)
- Allow event lists in P300 paradigm (:gh:`83` by `Jan Sosulski`_)
- Return epochs instead of np.ndarray in process_raw (:gh:`86` by `Jan Sosulski`_)
- Set path for hdf5 files (:gh:`92` by `Jan Sosulski`_)
- Update to MNE 0.21  (:gh:`101` by `Ramiro Gatti`_ and `Sylvain Chevallier`_)
- Adding a baseline correction (:gh:`115` by `Ramiro Gatti`_)
- Adding SSVEP datasets: MAMEM1, MAMEM2, MAMEM3, Nakanishi2015, Wang2016, (:gh:`118` by `Sylvain Chevallier`_, `Quentin Barthelemy`_, and `Divyesh Narayanan`_)
- Switch to GitHub Actions (:gh:`124` by `Erik Bjäreholt`_)
- Allow recording of additional scores/parameters/metrics in evaluation (:gh:`127` and :gh:`128` by `Jan Sosulski`_)
- Fix Ofner2017 and PhysionetMI annotations (:gh:`135` by `Ali Abdul Hussain`_)
- Adding Graz workshop tutorials (:gh:`130` and :gh:`137` by `Sylvain Chevallier`_ and `Lucas Custódio`_)
- Adding pre-commit configuration using isort, black and flake8 (:gh:`140` by `Vladislav Goncharenko`_)
- style: format Python code with black  (:gh:`147` by `Erik Bjäreholt`_)
- Switching to Poetry dependency management (:gh:`150` by `Vladislav Goncharenko`_)
- Using Prettier to format md and yml files (:gh:`151` by `Vladislav Goncharenko`_)


Bugs
~~~~
- Use stim_channels or check annotation when loading files in Paradigm  (:gh:`72` by `Jan Sosulski`_)
- Correct MNE issues (:gh:`76` by `Sylvain Chevallier`_)
- Fix capitalization in channel names of cho dataset  (:gh:`90` by `Jan Sosulski`_)
- Correct failing CI tests (:gh:`100` by `Sylvain Chevallier`_)
- Fix EPFL dataset flat signal sections and wrong scaling (:gh:`104` and :gh:`96` by  `Jan Sosulski`_)
- Fix schirrmeister dataset for Python3.8 (:gh:`105` by `Robin Schirrmeister`_)
- Correct event detection problem and duplicate event error (:gh:`106` by `Sylvain Chevallier`_)
- Fix channel selection in paradigm (:gh:`108` by `Sylvain Chevallier`_)
- Fix upperlimb Ofner2017 error and gdf import problem (:gh:`111` and :gh:`110` by `Sylvain Chevallier`_)
- Fix event_id in events_from_annotations missed (:gh:`112` by `Ramiro Gatti`_)
- Fix h5py>=3.0 compatibility issue (:gh:`138` by `Mohammad Mostafa Farzan`_)
- Python 2 support removal (:gh:`148` by `Vladislav Goncharenko`_)
- Travis-ci config removal (:gh:`149` by `Vladislav Goncharenko`_)

API changes
~~~~~~~~~~~
- None

Version 0.2.1
-------------

Enhancements
~~~~~~~~~~~~
- Add Tikhonov regularized CSP in ``moabb.pipelines.csp`` from the paper (:gh:`60` by `Vinay Jayaram`_)
- update to MNE version 0.19 (:gh:`73` by `Jan Sosulski`_)
- Improve doc building in CI (:gh:`60` by `Sylvain Chevallier`_)

Bugs
~~~~
- Update GigaDB Cho2017 URL (`Pedro L. C. Rodrigues`_ and `Vinay Jayaram`_)
- Fix braininvaders ERP data (`Pedro L. C. Rodrigues`_)
- Replace MNE ``read_montage`` with ``make_standard_montage`` (`Jan Sosulski`_)
- Correct Flake and PEP8 error (`Sylvain Chevallier`_)

API changes
~~~~~~~~~~~
- None


Version 0.2.0
-------------

Enhancements
~~~~~~~~~~~~
- MOABB corresponding to the paper version by `Vinay Jayaram`_ and `Alexandre Barachant`_
- Creating P300 paradigm and BNCI datasets (:gh:`53` by `Pedro L. C. Rodrigues`_)
- Adding EPFL P300 dataset (:gh:`56` by `Pedro L. C. Rodrigues`_)
- Adding BrainInvaders P300 dataset (:gh:`57` by `Pedro L. C. Rodrigues`_)
- Creating SSVEP paradigm and SSVEPExo dataset (:gh:`59` by `Sylvain Chevallier`_)

Bugs
~~~~
- None

API changes
~~~~~~~~~~~
- None

.. _Ethan Davis: https://github.com/davisethan
.. _Zheyu Yao: https://github.com/zyao197
.. _Martin Wimpff: https://github.com/martinwimpff
.. _Reinmar Kobler: https://github.com/rkobler
.. _Gabriel Schwartz: https://github.com/Kaos9001
.. _Sara Sedlar: https://github.com/Sara04
.. _Emmanuel Kalunga: https://github.com/emmanuelkalunga
.. _Gregoire Cattan: https://github.com/gcattan
.. _Anton Andreev: https://github.com/toncho11
.. _Igor Carrara: https://github.com/carraraig
.. _Bruno Aristimunha: https://github.com/bruAristimunha
.. _Alexandre Barachant: https://github.com/alexandrebarachant
.. _Quentin Barthelemy: https://github.com/qbarthelemy
.. _Erik Bjäreholt: https://github.com/ErikBjare
.. _Sylvain Chevallier: https://github.com/sylvchev
.. _Lucas Custódio: https://github.com/lucascust
.. _Mohammad Mostafa Farzan: https://github.com/m2-farzan
.. _Ramiro Gatti: https://github.com/ragatti
.. _Vladislav Goncharenko: https://github.com/v-goncharenko
.. _Ali Abdul Hussain: https://github.com/AliAbdulHussain
.. _Vinay Jayaram: https://github.com/vinay-jayaram
.. _Divyesh Narayanan: https://github.com/Div12345
.. _Pedro L. C. Rodrigues: https://github.com/plcrodrigues
.. _Robin Schirrmeister: https://github.com/robintibor
.. _Jan Sosulski: https://github.com/jsosulski
.. _Pierre Guetschel: https://github.com/PierreGtch
.. _Ludovic Darmet: https://github.com/ludovicdmt
.. _Thomas Moreau: https://github.com/tommoral
.. _Jordy Thielen: https://github.com/thijor
.. _Sebastien Velut: https://github.com/sebVelut
.. _Brian Irvine: https://github.com/brianjohannes
.. _Bruna Lopes: https://github.com/brunaafl
.. _Yash Chauhan: https://github.com/jiggychauhi
.. _Taha Habib: https://github.com/tahatt13
.. _AFF: https://github.com/allwaysFindFood
.. _Marco Congedo: https://github.com/Marco-Congedo
.. _Samuel Boehm: https://github.com/Samuel-Boehm
.. _Amar Enkhbat: https://github.com/amar-enkhbat
.. _Alexander de Ranitz: https://github.com/alexander-de-ranitz
.. _Luuk Neervens: https://github.com/LuukNeervens
.. _Charlynn van Osch: https://github.com/charlynnvanosch
.. _Paul Verhoeven: https://github.com/PaulusBoskabouter
.. _Thomas Kooiman: https://github.com/jellymace
.. _Jorge Sanmartin Martinez: https://github.com/jorgesanmar
.. _Radovan Vodila: https://github.com/rvodila
.. _Ulysse Durand: https://github.com/UlysseDurand
.. _Lucas Heck: https://github.com/lucas-heck
.. _Simon Kojima: https://github.com/simonkojima
.. _Griffin Keeler: https://github.com/griffinkeeler
.. _Kosei Nakada: https://github.com/ponpopon
.. _Romani Michele: https://github.com/BRomans
.. _Lionel Kusch: https://github.com/lionelkusch
.. _Victor Martinez-Cagigal: https://github.com/vicmarcag
.. _Mateusz Naklicki: https://github.com/luluu9
.. _Matthias Dold: https://github.com/matthiasdold
.. _Davoud Hajhassani: https://github.com/Davoud-Hajhassani
.. _Katelyn Begany: https://github.com/kbegany
.. _Sarthak Tayal: https://github.com/tayal-sarthak
