"""BBCI EEG fNIRS Motor imagery dataset."""

import os
import os.path as op
import zipfile as z

import numpy as np
from mne import create_info
from mne.channels import make_standard_montage
from mne.io import RawArray
from pooch import retrieve
from pooch.downloaders import choose_downloader
from scipy.io import loadmat

from moabb.datasets.download import get_dataset_path
from moabb.datasets.metadata.schema import (
    AcquisitionMetadata,
    AuxiliaryChannelsMetadata,
    BCIApplicationMetadata,
    CrossValidationMetadata,
    DatasetMetadata,
    DataStructureMetadata,
    DocumentationMetadata,
    ExperimentMetadata,
    ParadigmSpecificMetadata,
    ParticipantMetadata,
    PreprocessingMetadata,
    SignalProcessingMetadata,
    Tags,
)
from moabb.utils import _handle_deprecated_kwargs

from .base import BaseDataset


SHIN_URL = "http://doc.ml.tu-berlin.de/hBCI"


def eeg_data_path(base_path, subject, accept):
    datapath = op.join(
        base_path, "EEG", "subject {:02d}".format(subject), "with occular artifact"
    )
    if not op.isfile(op.join(datapath, "cnt.mat")):
        if not op.isdir(op.join(base_path, "EEG")):
            os.makedirs(op.join(base_path, "EEG"))
        intervals = [[1, 5], [6, 10], [11, 15], [16, 20], [21, 25], [26, 29]]
        for low, high in intervals:
            if subject >= low and subject <= high:
                if not op.isfile(op.join(base_path, "EEG.zip")):
                    if not accept:
                        raise AttributeError(
                            "You must accept licence term to download this dataset,"
                            "set accept=True when instantiating the dataset."
                        )
                    downloader = choose_downloader(SHIN_URL, progressbar=True)
                    downloader.kwargs.setdefault("verify", False)
                    retrieve(
                        "{}/EEG/EEG_{:02d}-{:02d}.zip".format(SHIN_URL, low, high),
                        None,
                        fname="EEG.zip",
                        path=base_path,
                        progressbar=True,
                        downloader=downloader,
                    )
                with z.ZipFile(op.join(base_path, "EEG.zip"), "r") as f:
                    f.extractall(op.join(base_path, "EEG"))
                os.remove(op.join(base_path, "EEG.zip"))
                break
    assert op.isfile(op.join(datapath, "cnt.mat")), op.join(datapath, "cnt.mat")
    return [op.join(datapath, fn) for fn in ["cnt.mat", "mrk.mat"]]


def fnirs_data_path(path, subject, accept):
    datapath = op.join(path, "NIRS", "subject {:02d}".format(subject))
    if not op.isfile(op.join(datapath, "mrk.mat")):
        # fNIRS
        if not op.isfile(op.join(path, "fNIRS.zip")):
            if not accept:
                raise AttributeError(
                    "You must accept licence term to download this dataset,"
                    "set accept=True when instantiating the dataset."
                )
            retrieve(
                "http://doc.ml.tu-berlin.de/hBCI/NIRS/NIRS_01-29.zip",
                None,
                fname="fNIRS.zip",
                path=path,
                progressbar=True,
            )
        if not op.isdir(op.join(path, "NIRS")):
            os.makedirs(op.join(path, "NIRS"))
        with z.ZipFile(op.join(path, "fNIRS.zip"), "r") as f:
            f.extractall(op.join(path, "NIRS"))
        os.remove(op.join(path, "fNIRS.zip"))
    return [op.join(datapath, fn) for fn in ["cnt.mat", "mrk.mat"]]


class BaseShin2017(BaseDataset):
    """Not to be used."""

    def __init__(
        self,
        suffix,
        fnirs=False,
        motor_imagery=True,
        mental_arithmetic=False,
        accept=False,
        subjects=None,
        sessions=None,
        *,
        return_all_modalities=False,
        **kwargs,
    ):
        deprecated_renames = {
            "FNIRS": "fnirs",
            "MotorImagery": "motor_imagery",
            "MentalArithmetic": "mental_arithmetic",
            "Accept": "accept",
        }
        resolved = _handle_deprecated_kwargs(kwargs, deprecated_renames, "BaseShin2017")
        fnirs = resolved.get("fnirs", fnirs)
        motor_imagery = resolved.get("motor_imagery", motor_imagery)
        mental_arithmetic = resolved.get("mental_arithmetic", mental_arithmetic)
        accept = resolved.get("accept", accept)

        if not any([motor_imagery, mental_arithmetic]):
            raise (
                ValueError(
                    "at least one of motor_imagery or" " mental_arithmetic must be true"
                )
            )
        events = dict()
        n_sessions = 0
        if motor_imagery:
            events.update(dict(left_hand=1, right_hand=2))
            n_sessions += 3

        if mental_arithmetic:
            events.update(dict(subtraction=3, rest=4))
            n_sessions += 3

        self.motor_imagery = motor_imagery
        self.mental_arithmetic = mental_arithmetic
        self.accept = accept

        super().__init__(
            subjects=list(range(1, 30)),
            sessions_per_subject=n_sessions,
            events=events,
            code="Shin2017" + suffix,
            # marker is for *task* start not cue start
            interval=[0, 10],
            paradigm="imagery",  # no arithmetic paradigm in MOABB at the moment
            doi="10.1109/TNSRE.2016.2628057",
            selected_subjects=subjects,
            selected_sessions=sessions,
            return_all_modalities=return_all_modalities,
        )

        if fnirs:
            raise (NotImplementedError("Fnirs not implemented."))
        self.fnirs = fnirs  # TODO: actually incorporate fNIRS somehow

    def _get_single_subject_data(self, subject):
        """Return data for a single subject."""
        fname, fname_mrk = self.data_path(subject)
        data = loadmat(fname, squeeze_me=True, struct_as_record=False)["cnt"]
        mrk = loadmat(fname_mrk, squeeze_me=True, struct_as_record=False)["mrk"]

        sessions = {}
        # motor imagery
        if self.motor_imagery:
            for ii in [0, 2, 4]:
                session = self._convert_one_session(data, mrk, ii, trig_offset=0)
                sessions[f"{ii}imagery"] = session

        # arithmetic/rest
        if self.mental_arithmetic:
            for ii in [1, 3, 5]:
                session = self._convert_one_session(data, mrk, ii, trig_offset=2)
                sessions[f"{ii}arithmetic"] = session

        return sessions

    def _convert_one_session(self, data, mrk, session, trig_offset=0):
        eeg = data[session].x.T * 1e-6
        trig = np.zeros((1, eeg.shape[1]))
        idx = (mrk[session].time - 1) // 5
        trig[0, idx] = mrk[session].event.desc // 16 + trig_offset
        eeg = np.vstack([eeg, trig])
        ch_names = list(data[session].clab) + ["Stim"]
        ch_types = ["eeg"] * 30 + ["eog"] * 2 + ["stim"]

        montage = make_standard_montage("standard_1005")
        info = create_info(ch_names=ch_names, ch_types=ch_types, sfreq=200.0)
        raw = RawArray(data=eeg, info=info, verbose=False)
        raw.set_montage(montage)
        return {"0": raw}

    def data_path(
        self,
        subject,
        path=None,
        force_update=False,
        update_path=None,
        verbose=None,
        accept=False,
    ):
        if subject not in self.subject_list:
            raise (ValueError("Invalid subject number"))
        if accept:
            self.accept = True

        path = get_dataset_path("BBCIFNIRS", path)
        if not op.isdir(op.join(path, "MNE-eegfnirs-data")):
            os.makedirs(op.join(path, "MNE-eegfnirs-data"))
        if self.fnirs:
            return fnirs_data_path(
                op.join(path, "MNE-eegfnirs-data"), subject, self.accept
            )
        else:
            return eeg_data_path(op.join(path, "MNE-eegfnirs-data"), subject, self.accept)


class Shin2017A(BaseShin2017):
    """Motor Imagey Dataset from Shin et al 2017.

    Dataset from [1]_.

    .. caution::
       You should accept the licence term [2]_ to download this dataset, using:
       ``Shin2017A(accept=True)``

    **Data Acquisition**

    EEG and NIRS data was collected in an ordinary bright room. EEG data was
    recorded by a multichannel BrainAmp EEG amplifier with thirty active
    electrodes (Brain Products GmbH, Gilching, Germany) with linked mastoids
    reference at 1000 Hz sampling rate. The EEG amplifier was also used to
    measure the electrooculogram (EOG), electrocardiogram (ECG) and respiration
    with a piezo based breathing belt. Thirty EEG electrodes were placed on a
    custom-made stretchy fabric cap (EASYCAP GmbH, Herrsching am Ammersee,
    Germany) and placed according to the international 10-5 system (AFp1, AFp2,
    AFF1h, AFF2h, AFF5h, AFF6h, F3, F4, F7, F8, FCC3h, FCC4h, FCC5h, FCC6h, T7,
    T8, Cz, CCP3h, CCP4h, CCP5h, CCP6h, Pz, P3, P4, P7, P8, PPO1h, PPO2h, POO1,
    POO2 and Fz for ground electrode).

    NIRS data was collected by NIRScout (NIRx GmbH, Berlin, Germany) at 12.5 Hz
    sampling rate. Each adjacent source-detector pair creates one physiological
    NIRS channel. Fourteen sources and sixteen detectors resulting in
    thirty-six
    physiological channels were placed at frontal (nine channels around Fp1,
    Fp2, and Fpz), motor (twelve channels around C3 and C4, respectively) and
    visual areas (three channels around Oz). The inter-optode distance was 30
    mm. NIRS optodes were fixed on the same cap as the EEG electrodes. Ambient
    lights were sufficiently blocked by a firm contact between NIRS optodes and
    scalp and use of an opaque cap.

    EOG was recorded using two vertical (above and below left eye) and two
    horizontal (outer canthus of each eye) electrodes. ECG was recorded based
    on
    Einthoven triangle derivations I and II, and respiration was measured using
    a respiration belt on the lower chest. EOG, ECG and respiration were
    sampled
    at the same sampling rate of the EEG. ECG and respiration data were not
    analyzed in this study, but are provided along with the other signals.

    **Experimental Procedure**

    The subjects sat on a comfortable armchair in front of a 50-inch white
    screen. The distance between their heads and the screen was 1.6 m. They
    were
    asked not to move any part of the body during the data recording. The
    experiment consisted of three sessions of left and right hand MI (dataset
    A)and MA and baseline tasks (taking a rest without any thought) (dataset B)
    each. Each session comprised a 1 min pre-experiment resting period, 20
    repetitions of the given task and a 1 min post-experiment resting
    period. The task started with 2 s of a visual introduction of the task,
    followed by 10 s of a task period and resting period which was given
    randomly from 15 to 17 s. At the beginning and end of the task period, a
    short beep (250 ms) was played. All instructions were displayed on the
    white
    screen by a video projector. MI and MA tasks were performed in separate
    sessions but in alternating order (i.e., sessions 1, 3 and 5 for MI
    (dataset
    A) and sessions 2, 4 and 6 for MA (dataset B)). Fig. 2 shows the schematic
    diagram of the experimental paradigm. Five sorts of motion artifacts
    induced
    by eye and head movements (dataset C) were measured. The motion artifacts
    were recorded after all MI and MA task recordings. The experiment did not
    include the pre- and post-experiment resting state periods.

    **Motor Imagery (Dataset A)**

    For motor imagery, subjects were instructed to perform haptic motor imagery
    (i.e. to imagine the feeling of opening and closing their hands as they
    were
    grabbing a ball) to ensure that actual motor imagery, not visual imagery,
    was performed. All subjects were naive to the MI experiment. For the visual
    instruction, a black arrow pointing to either the left or right side
    appeared at the center of the screen for 2 s. The arrow disappeared with a
    short beep sound and then a black fixation cross was displayed during the
    task period. The subjects were asked to imagine hand gripping (opening and
    closing their hands) in a 1 Hz pace. This pace was shown to and repeated by
    the subjects by performing real hand gripping before the experiment. Motor
    imagery was performed continuously over the task period. The task period
    was finished with a short beep sound and a 'STOP' displayed for 1s on the
    screen. The fixation cross was displayed again during the rest period and
    the subjects were asked to gaze at it to minimize their eye movements. This
    process was repeated twenty times in a single session (ten trials per
    condition in a single session; thirty trials in the whole sessions). In a
    single session, motor imagery tasks were performed on the basis of ten
    subsequent blocks randomly consisting of one of two conditions: Either
    first left and then right hand motor imagery or vice versa.

    References
    ----------

    .. [1] Shin, J., von Lühmann, A., Blankertz, B., Kim, D.W., Jeong, J.,
           Hwang, H.J. and Müller, K.R., 2017. Open access dataset for EEG+NIRS
           single-trial classification. IEEE Transactions on Neural Systems
           and Rehabilitation Engineering, 25(10), pp.1735-1745.

    .. [2] GNU General Public License, Version 3
           `<https://www.gnu.org/licenses/gpl-3.0.txt>`_
    """

    METADATA = DatasetMetadata(
        acquisition=AcquisitionMetadata(
            sampling_rate=200.0,
            n_channels=30,
            channel_types={"eeg": 30, "eog": 2},
            montage="10-5",
            hardware="BrainAmp",
            sensor_type="active electrodes",
            reference="linked mastoids",
            ground="Fz",
            software=None,
            cap_manufacturer="EASYCAP GmbH",
            cap_model="custom-made stretchy fabric cap",
            sensors=[
                "AFF1h",
                "AFF2h",
                "AFF5h",
                "AFF6h",
                "AFp1",
                "AFp2",
                "CCP3h",
                "CCP4h",
                "CCP5h",
                "CCP6h",
                "Cz",
                "F3",
                "F4",
                "F7",
                "F8",
                "FCC3h",
                "FCC4h",
                "FCC5h",
                "FCC6h",
                "HEOG",
                "P3",
                "P4",
                "P7",
                "P8",
                "POO1",
                "POO2",
                "PPO1h",
                "PPO2h",
                "Pz",
                "T7",
                "T8",
                "VEOG",
            ],
            line_freq=50.0,
            auxiliary_channels=AuxiliaryChannelsMetadata(
                has_eog=True,
                eog_channels=4,
                eog_type=["horizontal", "vertical"],
                has_emg=False,
                other_physiological=["ecg", "respiration"],
            ),
        ),
        participants=ParticipantMetadata(
            n_subjects=29,
            health_status="healthy",
            gender={"male": 14, "female": 15},
            age_mean=28.5,
            age_std=3.7,
            handedness={"right": 29, "left": 1},
            bci_experience="naive to MI experiment",
            species="human",
        ),
        experiment=ExperimentMetadata(
            events={"left_hand": 1, "right_hand": 2},
            paradigm="imagery",
            n_classes=2,
            class_labels=["left_hand", "right_hand"],
            trial_duration=10.0,
            study_design="Dataset A: left vs right hand motor imagery (kinesthetic imagery of opening and closing hands)",
            feedback_type="none",
            stimulus_type="visual arrow and fixation cross",
            stimulus_modalities=["visual", "auditory"],
            primary_modality="visual",
            synchronicity="cued",
            mode="offline",
            instructions="Subjects were instructed to perform kinesthetic MI (i.e., to imagine the opening and closing their hands as they were grabbing a ball) to ensure that actual MI, not visual MI, was performed. Subjects were asked to imagine hand gripping (opening and closing their hands) with a 1 Hz pace.",
            hed_tags={
                "left_hand": (
                    "(Sensory-event, Experimental-stimulus, Visual-presentation, "
                    "(Leftward, Arrow)), "
                    "(Agent-action, (Imagine, Move, (Left, Hand)))"
                ),
                "right_hand": (
                    "(Sensory-event, Experimental-stimulus, Visual-presentation, "
                    "(Rightward, Arrow)), "
                    "(Agent-action, (Imagine, Move, (Right, Hand)))"
                ),
            },
        ),
        documentation=DocumentationMetadata(
            doi="10.1109/TNSRE.2016.2628057",
            description="Open access dataset for hybrid brain-computer interfaces (BCIs) using electroencephalography (EEG) and near-infrared spectroscopy (NIRS). Dataset includes two BCI experiments: left versus right hand motor imagery, and mental arithmetic versus resting state.",
            investigators=[
                "Jaeyoung Shin",
                "Alexander von Lühmann",
                "Benjamin Blankertz",
                "Do-Won Kim",
                "Jichai Jeong",
                "Han-Jeong Hwang",
                "Klaus-Robert Müller",
            ],
            institution="Berlin Institute of Technology",
            country="DE",
            publication_year=2017,
            senior_author="Klaus-Robert Müller",
            contact_info=["h2j@kumoh.ac.kr", "klaus-robert.mueller@tuberlin.de"],
            funding=[
                "Basic Science Research Program through the National Research Foundation of Korea (NRF) funded by the Ministry of Education (NRF2014R1A6A3A03057524)",
                "Ministry of Science, ICT & Future Planning (NRF-2015R1C1A1A02037032)",
                "Brain Korea 21 PLUS Program through the NRF funded by the Ministry of Education",
                "Korea University Grant",
                "BMBF (#01GQ0850, Bernstein Focus: Neurotechnology)",
            ],
            institution_address="10587 Berlin, Germany",
            institution_department="Machine Learning Group, Department of Computer Science",
            ethics_approval=[
                "Ethics Committee of the Institute of Psychology and Ergonomics, Technical University of Berlin (approval number: SH_01_20150330)",
                "Declaration of Helsinki",
            ],
            keywords=[
                "Brain-computer interface (BCI)",
                "electroencephalography (EEG)",
                "hybrid BCI",
                "mental arithmetic",
                "motor imagery",
                "near-infrared spectroscopy (NIRS)",
                "open access dataset",
            ],
            repository="GitHub",
            data_url="http://doc.ml.tu-berlin.de/hBCI",
            license="GPL-3.0",
        ),
        sessions_per_subject=3,
        runs_per_session=1,
        data_processed=True,
        file_format="MATLAB",
        tags=Tags(
            pathology=["Healthy"],
            modality=["Motor"],
            type=["Imagery"],
        ),
        preprocessing=PreprocessingMetadata(
            data_state="preprocessed",
            preprocessing_applied=True,
            preprocessing_steps=[
                "common average reference",
                "bandpass filtering (0.5-50 Hz)",
                "ICA-based EOG rejection",
                "downsampling to 200 Hz",
            ],
            highpass_hz=0.5,
            lowpass_hz=50.0,
            bandpass=[0.5, 50.0],
            filter_type="Chebyshev type II",
            filter_order=4,
            artifact_methods=["ICA", "EOG rejection"],
            re_reference="car",
            downsampled_to_hz=200.0,
        ),
        signal_processing=SignalProcessingMetadata(
            classifiers=["Shrinkage LDA"],
            feature_extraction=["CSP", "log-variance"],
            frequency_bands={
                "mu": [8.0, 12.0],
                "beta": [12.0, 25.0],
                "analyzed_range": [8.0, 25.0],
            },
            spatial_filters=["CSP"],
        ),
        cross_validation=CrossValidationMetadata(
            cv_method="10x5-fold",
            cv_folds=5,
            evaluation_type=["within_subject"],
        ),
        performance={
            "accuracy_percent": 65.6,
            "EEG_accuracy": 65.6,
            "HbR_accuracy": 66.5,
            "HbO_accuracy": 63.5,
            "EEG+HbR+HbO_accuracy": 74.2,
        },
        bci_application=BCIApplicationMetadata(
            applications=["motor_control"],
            environment="laboratory",
            online_feedback=False,
        ),
        paradigm_specific=ParadigmSpecificMetadata(
            detected_paradigm="imagery",
            n_repetitions=20,
            imagery_tasks=["left_hand", "right_hand"],
            cue_duration_s=2.0,
            imagery_duration_s=10.0,
        ),
        data_structure=DataStructureMetadata(
            n_trials={
                "per_session": 20,
                "per_class_per_session": 10,
                "total_per_class": 30,
            },
            n_blocks=10,
            trials_context="10 blocks per session, each block containing 2 trials (one left, one right hand MI) randomized",
        ),
        abstract="We provide an open access dataset for hybrid brain-computer interfaces (BCIs) using electroencephalography (EEG) and near-infrared spectroscopy (NIRS). For this, we conducted two BCI experiments (left versus right hand motor imagery; mental arithmetic versus resting state). The dataset was validated using baseline signal analysis methods, with which classification performance was evaluated for each modality and a combination of both modalities. As already shown in previous literature, the capability of discriminating different mental states can be enhanced by using a hybrid approach, when comparing to single modality analyses. This makes the provided data highly suitable for hybrid BCI investigations. Since our open access dataset also comprises motion artifacts and physiological data, we expect that it can be used in a wide range of future validation approaches in multimodal BCI research.",
        methodology="Twenty-nine right-handed and one left-handed healthy subjects participated in motor imagery and mental arithmetic tasks. EEG data was recorded at 1000 Hz using 30 active electrodes with a BrainAmp amplifier, referenced to linked mastoids. NIRS data was collected at 12.5 Hz using NIRScout with 14 sources and 16 detectors resulting in 36 channels. Three sessions were conducted for each paradigm (MI and MA). Each session included 20 trials with 10s task periods and 15-17s rest periods. For MI, subjects performed kinesthetic hand gripping imagery at 1 Hz pace. Visual instructions included arrows for MI and arithmetic problems for MA. Motion artifacts from eye/head movements were also recorded. Signal processing included CSP for spatial filtering, log-variance features, and shrinkage LDA classifier with 10x5-fold cross-validation.",
    )

    def __init__(
        self,
        accept=False,
        subjects=None,
        sessions=None,
        *,
        return_all_modalities=False,
        **kwargs,
    ):
        deprecated_renames = {"Accept": "accept"}
        resolved = _handle_deprecated_kwargs(kwargs, deprecated_renames, "Shin2017A")
        accept = resolved.get("accept", accept)
        super().__init__(
            suffix="A",
            fnirs=False,
            motor_imagery=True,
            mental_arithmetic=False,
            accept=accept,
            subjects=subjects,
            sessions=sessions,
            return_all_modalities=return_all_modalities,
        )


class Shin2017B(BaseShin2017):
    """Mental Arithmetic Dataset from Shin et al 2017.

    Dataset from [1]_.

    .. caution::
        You should accept the licence term [2]_ to download this dataset, using:
        ``Shin2017B(accept=True)``

    **Data Acquisition**

    EEG and NIRS data was collected in an ordinary bright room. EEG data was
    recorded by a multichannel BrainAmp EEG amplifier with thirty active
    electrodes (Brain Products GmbH, Gilching, Germany) with linked mastoids
    reference at 1000 Hz sampling rate. The EEG amplifier was also used to
    measure the electrooculogram (EOG), electrocardiogram (ECG) and respiration
    with a piezo based breathing belt. Thirty EEG electrodes were placed on a
    custom-made stretchy fabric cap (EASYCAP GmbH, Herrsching am Ammersee,
    Germany) and placed according to the international 10-5 system (AFp1, AFp2,
    AFF1h, AFF2h, AFF5h, AFF6h, F3, F4, F7, F8, FCC3h, FCC4h, FCC5h, FCC6h, T7,
    T8, Cz, CCP3h, CCP4h, CCP5h, CCP6h, Pz, P3, P4, P7, P8, PPO1h, PPO2h, POO1,
    POO2 and Fz for ground electrode).

    NIRS data was collected by NIRScout (NIRx GmbH, Berlin, Germany) at 12.5 Hz
    sampling rate. Each adjacent source-detector pair creates one physiological
    NIRS channel. Fourteen sources and sixteen detectors resulting in
    thirty-six
    physiological channels were placed at frontal (nine channels around Fp1,
    Fp2, and Fpz), motor (twelve channels around C3 and C4, respectively) and
    visual areas (three channels around Oz). The inter-optode distance was 30
    mm. NIRS optodes were fixed on the same cap as the EEG electrodes. Ambient
    lights were sufficiently blocked by a firm contact between NIRS optodes and
    scalp and use of an opaque cap.

    EOG was recorded using two vertical (above and below left eye) and two
    horizontal (outer canthus of each eye) electrodes. ECG was recorded based
    on
    Einthoven triangle derivations I and II, and respiration was measured using
    a respiration belt on the lower chest. EOG, ECG and respiration were
    sampled
    at the same sampling rate of the EEG. ECG and respiration data were not
    analyzed in this study, but are provided along with the other signals.

    **Experimental Procedure**

    The subjects sat on a comfortable armchair in front of a 50-inch white
    screen. The distance between their heads and the screen was 1.6 m. They
    were
    asked not to move any part of the body during the data recording. The
    experiment consisted of three sessions of left and right hand MI (dataset
    A)and MA and baseline tasks (taking a rest without any thought) (dataset B)
    each. Each session comprised a 1 min pre-experiment resting period, 20
    repetitions of the given task and a 1 min post-experiment resting
    period. The task started with 2 s of a visual introduction of the task,
    followed by 10 s of a task period and resting period which was given
    randomly from 15 to 17 s. At the beginning and end of the task period, a
    short beep (250 ms) was played. All instructions were displayed on the
    white
    screen by a video projector. MI and MA tasks were performed in separate
    sessions but in alternating order (i.e., sessions 1, 3 and 5 for MI
    (dataset
    A) and sessions 2, 4 and 6 for MA (dataset B)). Fig. 2 shows the schematic
    diagram of the experimental paradigm. Five sorts of motion artifacts
    induced
    by eye and head movements (dataset C) were measured. The motion artifacts
    were recorded after all MI and MA task recordings. The experiment did not
    include the pre- and post-experiment resting state periods.

    **Mental Arithmetic (Dataset B)**

    For the visual instruction of the MA task, an initial subtraction such as
    'three-digit number minus one-digit number' (e.g., 384-8) appeared at the
    center of the screen for 2 s. The subjects were instructed to memorize the
    numbers while the initial subtraction was displayed on the screen. The
    initial subtraction disappeared with a short beep sound and a black
    fixation cross was displayed during the task period in which the subjects
    were asked
    to repeatedly perform to subtract the one-digit number from the result of
    the previous subtraction. For the baseline task, no specific sign but the
    black fixation cross was displayed on the screen, and the subjects were
    instructed to take a rest. Note that there were other rest periods between
    the MA and baseline task periods, as same with the MI paradigm. Both task
    periods were finished with a short beep sound and a 'STOP' displayed for
    1 s on the screen. The fixation cross was displayed again during the rest
    period. MA and baseline trials were randomized in the same way as MI.

    References
    ----------
    .. [1] Shin, J., von Lühmann, A., Blankertz, B., Kim, D.W., Jeong, J.,
           Hwang, H.J. and Müller, K.R., 2017. Open access dataset for EEG+NIRS
           single-trial classification. IEEE Transactions on Neural Systems
           and Rehabilitation Engineering, 25(10), pp.1735-1745.

    .. [2] GNU General Public License, Version 3
           `<https://www.gnu.org/licenses/gpl-3.0.txt>`_
    """

    METADATA = DatasetMetadata(
        acquisition=AcquisitionMetadata(
            sampling_rate=200.0,
            n_channels=30,
            channel_types={"eeg": 30, "eog": 2},
            montage="10-5",
            hardware="BrainAmp",
            sensor_type="active electrodes",
            reference="linked mastoids",
            ground="Fz",
            software="MATLAB R2013b",
            sensors=[
                "AFF1h",
                "AFF2h",
                "AFF5h",
                "AFF6h",
                "AFp1",
                "AFp2",
                "CCP3h",
                "CCP4h",
                "CCP5h",
                "CCP6h",
                "Cz",
                "F3",
                "F4",
                "F7",
                "F8",
                "FCC3h",
                "FCC4h",
                "FCC5h",
                "FCC6h",
                "HEOG",
                "P3",
                "P4",
                "P7",
                "P8",
                "POO1",
                "POO2",
                "PPO1h",
                "PPO2h",
                "Pz",
                "T7",
                "T8",
                "VEOG",
            ],
            line_freq=50.0,
            auxiliary_channels=AuxiliaryChannelsMetadata(
                has_eog=True,
                eog_channels=4,
                eog_type=["horizontal", "vertical"],
                other_physiological=["ecg", "respiration"],
            ),
            cap_manufacturer="EASYCAP GmbH",
            cap_model="custom-made stretchy fabric cap",
        ),
        participants=ParticipantMetadata(
            n_subjects=29,
            health_status="healthy",
            gender={"male": 14, "female": 15},
            age_mean=28.5,
            age_std=3.7,
            handedness={"right": 29, "left": 1},
            bci_experience="naive to MI experiment",
            species="human",
        ),
        experiment=ExperimentMetadata(
            paradigm="imagery",
            n_classes=2,
            class_labels=["subtraction", "rest"],
            trial_duration=10.0,
            study_design="Dataset B: mental arithmetic (serial subtraction of one-digit number) versus baseline/rest task",
            feedback_type="none",
            stimulus_type="visual instruction (subtraction problem and fixation cross)",
            stimulus_modalities=["visual", "auditory"],
            primary_modality="visual",
            synchronicity="cued-synchronous",
            mode="offline",
            has_training_test_split=False,
            instructions="For the MA task, subjects memorized an initial subtraction (three-digit minus one-digit) displayed for 2s, then repeatedly subtracted the one-digit number from each result. For baseline, subjects rested with no specific thought.",
            events={"subtraction": 3, "rest": 4},
            trials_per_class={"subtraction": 30, "rest": 30},
        ),
        documentation=DocumentationMetadata(
            doi="10.1109/TNSRE.2016.2628057",
            description="Open access dataset for hybrid brain-computer interfaces using EEG and NIRS with motor imagery and mental arithmetic tasks",
            investigators=[
                "Jaeyoung Shin",
                "Alexander von Lühmann",
                "Benjamin Blankertz",
                "Do-Won Kim",
                "Jichai Jeong",
                "Han-Jeong Hwang",
                "Klaus-Robert Müller",
            ],
            institution="Berlin Institute of Technology",
            country="DE",
            publication_year=2017,
            senior_author="Klaus-Robert Müller",
            contact_info=["h2j@kumoh.ac.kr", "klaus-robert.mueller@tuberlin.de"],
            funding=[
                "Basic Science Research Program through the National Research Foundation of Korea (NRF) funded by the Ministry of Education (NRF-2014R1A6A3A03057524)",
                "Ministry of Science, ICT & Future Planning (NRF-2015R1C1A1A02037032)",
                "Brain Korea 21 PLUS Program through the NRF funded by the Ministry of Education",
                "Korea University Grant",
                "BMBF (#01GQ0850, Bernstein Focus: Neurotechnology)",
            ],
            institution_address="10587 Berlin, Germany",
            institution_department="Department of Computer Science, Machine Learning Group",
            ethics_approval=[
                "Ethics Committee of the Institute of Psychology and Ergonomics, Technical University of Berlin (approval number: SH_01_20150330)"
            ],
            keywords=[
                "Brain-computer interface",
                "BCI",
                "electroencephalography",
                "EEG",
                "hybrid BCI",
                "mental arithmetic",
                "motor imagery",
                "near-infrared spectroscopy",
                "NIRS",
                "open access dataset",
            ],
            repository="GitHub",
            data_url="http://doc.ml.tu-berlin.de/hBCI",
            license="GPL-3.0",
        ),
        sessions_per_subject=3,
        runs_per_session=1,
        sessions=[
            "1arithmetic",
            "3arithmetic",
            "5arithmetic",
        ],
        data_processed=True,
        file_format="MATLAB",
        tags=Tags(
            pathology=["Healthy"],
            modality=["Cognitive"],
            type=["Cognitive"],
        ),
        preprocessing=PreprocessingMetadata(
            data_state="preprocessed",
            preprocessing_applied=True,
            preprocessing_steps=[
                "common average reference",
                "bandpass filtering (0.5-50 Hz)",
                "ICA-based EOG rejection",
                "downsampling to 200 Hz",
            ],
            highpass_hz=0.5,
            lowpass_hz=50.0,
            bandpass=[0.5, 50.0],
            filter_type="Chebyshev type II",
            filter_order=4,
            artifact_methods=["EOG correction", "ICA"],
            re_reference="car",
            downsampled_to_hz=200.0,
        ),
        signal_processing=SignalProcessingMetadata(
            classifiers=["LDA", "Shrinkage LDA"],
            feature_extraction=["CSP", "log-variance"],
            frequency_bands={
                "analyzed_range": [4.0, 35.0],
            },
            spatial_filters=["CSP"],
        ),
        cross_validation=CrossValidationMetadata(
            cv_method="10x5-fold",
            cv_folds=5,
            evaluation_type=["within_subject"],
        ),
        performance={
            "MA_EEG_max_accuracy": 75.9,
            "MA_HbR_max_accuracy": 80.7,
            "MA_HbO_max_accuracy": 83.6,
        },
        bci_application=BCIApplicationMetadata(
            applications=["hybrid_bci_research"],
            environment="laboratory",
            online_feedback=False,
        ),
        paradigm_specific=ParadigmSpecificMetadata(
            detected_paradigm="imagery",
            n_repetitions=20,
            imagery_tasks=None,
            imagery_duration_s=None,
            cue_duration_s=None,
        ),
        data_structure=DataStructureMetadata(
            n_trials={
                "per_session": 20,
                "per_condition_session": 10,
                "per_condition_total": 30,
            },
            trials_context="Each session: 1 min pre-experiment rest + 20 trials + 1 min post-experiment rest. Trial: 2s visual instruction + 10s task + 15-17s random rest",
        ),
        abstract="Open access dataset for hybrid brain-computer interfaces using EEG and NIRS. Includes two experiments: (1) left vs right hand motor imagery, (2) mental arithmetic vs resting state. Dataset validated using baseline signal analysis showing hybrid approach enhances discrimination of mental states. Also includes motion artifacts and physiological data for wide range of validation approaches.",
        methodology="Thirty subjects performed 6 sessions alternating between motor imagery (dataset A: left/right hand) and mental arithmetic (dataset B: MA vs rest). Each session: 20 trials with 2s cue, 10s task, 15-17s rest. EEG recorded at 1000 Hz with 30 channels, downsampled to 200 Hz. Preprocessing: CAR, 0.5-50 Hz bandpass (4th order Chebyshev II), ICA-based EOG rejection. Feature extraction: CSP with log-variance of first/last 3 components using 3s moving window (1s step). Classification: shrinkage LDA with 10x5-fold CV. Hybrid analysis combines EEG and NIRS outputs using meta-classifier.",
    )

    def __init__(
        self,
        accept=False,
        subjects=None,
        sessions=None,
        *,
        return_all_modalities=False,
        **kwargs,
    ):
        deprecated_renames = {"Accept": "accept"}
        resolved = _handle_deprecated_kwargs(kwargs, deprecated_renames, "Shin2017B")
        accept = resolved.get("accept", accept)
        super().__init__(
            suffix="B",
            fnirs=False,
            motor_imagery=False,
            mental_arithmetic=True,
            subjects=subjects,
            sessions=sessions,
            accept=accept,
            return_all_modalities=return_all_modalities,
        )
