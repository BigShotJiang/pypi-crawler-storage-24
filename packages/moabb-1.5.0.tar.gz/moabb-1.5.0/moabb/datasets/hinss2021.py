import os
import os.path as osp
import zipfile as z

import mne
import numpy as np

from moabb.datasets import download as dl
from moabb.datasets.base import BaseDataset
from moabb.datasets.metadata.schema import (
    AcquisitionMetadata,
    AuxiliaryChannelsMetadata,
    BCIApplicationMetadata,
    CrossValidationMetadata,
    DatasetMetadata,
    DataStructureMetadata,
    DocumentationMetadata,
    ExperimentMetadata,
    ParadigmSpecificMetadata,
    ParticipantMetadata,
    PreprocessingMetadata,
    SignalProcessingMetadata,
    Tags,
)


URL = "https://zenodo.org/record/5055046/files/"
# private dictionary to map events to integers
_HINNS_EVENTS = dict(rs=1, easy=2, medium=3, diff=4)


class Hinss2021(BaseDataset):
    """Neuroergonomic 2021 dataset.

    We describe the experimental procedures for a dataset that is publicly available
    at https://zenodo.org/records/5055046.
    This dataset contains electroencephalographic recordings of 15 subjects (6 female, with an
    average age of 25 years). A total of 62 active Ag–AgCl
    electrodes were available in the dataset.

    The participants engaged in 3 (2 available here) distinct experimental sessions, each of which
    was separated by 1 week.

    At the beginning of each session, the resting state of the participant
    (measured as 1 minute with eyes open) was recorded.

    Subsequently, participants undertook 3 tasks of varying difficulty levels
    (i.e., easy, medium, and difficult). The task assignments
    were randomized. For more details, please check [Hinss2021]_ and [Hinss2023]_.

    Notes
    -----

    .. versionadded:: 1.0.1

    References
    ----------

    .. [Hinss2021] M. Hinss, B. Somon, F. Dehais & R. N. Roy (2021)
            Open EEG Datasets for Passive Brain-Computer
            Interface Applications: Lacks and Perspectives.
            IEEE Neural Engineering Conference.

    .. [Hinss2023] M. F. Hinss, et al. (2023)
            An EEG dataset for cross-session mental workload estimation:
            Passive BCI competition of the Neuroergonomics Conference 2021.
            Scientific Data, 10, 85.
            https://doi.org/10.1038/s41597-022-01898-y
    """

    METADATA = DatasetMetadata(
        acquisition=AcquisitionMetadata(
            sampling_rate=500.0,
            n_channels=62,
            channel_types={"eeg": 62},
            montage="standard_1020",
            hardware="ActiCHamp (Brain Products Gmbh)",
            sensor_type="active Ag/AgCl",
            reference="Fpz",
            software=None,
            filters=None,
            impedance_threshold_kohm=25,
            sensors=[
                "AF3",
                "AF4",
                "AF7",
                "AF8",
                "AFz",
                "C1",
                "C2",
                "C3",
                "C4",
                "C5",
                "C6",
                "CP1",
                "CP2",
                "CP3",
                "CP4",
                "CP5",
                "CP6",
                "CPz",
                "F1",
                "F2",
                "F3",
                "F4",
                "F5",
                "F6",
                "F7",
                "F8",
                "FC1",
                "FC2",
                "FC3",
                "FC4",
                "FC5",
                "FC6",
                "FCz",
                "FT10",
                "FT7",
                "FT8",
                "FT9",
                "Fp1",
                "Fp2",
                "Fz",
                "O1",
                "O2",
                "Oz",
                "P1",
                "P2",
                "P3",
                "P4",
                "P5",
                "P6",
                "P7",
                "P8",
                "PO3",
                "PO4",
                "PO7",
                "PO8",
                "POz",
                "Pz",
                "T7",
                "T8",
                "TP7",
                "TP8",
            ],
            line_freq=50.0,
            auxiliary_channels=AuxiliaryChannelsMetadata(
                other_physiological=["ecg"],
            ),
        ),
        participants=ParticipantMetadata(
            n_subjects=15,
            gender={"female": 11, "male": 18},
            age_mean=23.9,
            handedness=None,
        ),
        experiment=ExperimentMetadata(
            events={"rs": 1, "easy": 2, "medium": 3, "diff": 4},
            paradigm="rstate",
            n_classes=4,
            class_labels=["rest", "easy", "medium", "difficult"],
            study_design="Passive BCI neuroergonomics dataset with resting state and 3 difficulty levels of MATB-II task (easy, medium, difficult). The MOABB loader provides resting state and MATB conditions only.",
            feedback_type="none",
            stimulus_type="visual display",
            has_training_test_split=False,
        ),
        documentation=DocumentationMetadata(
            doi="10.1038/s41597-022-01898-y",
            publication_year=2023,
            investigators=[
                "Marcel F. Hinss",
                "Emilie S. Jahanpour",
                "Bertille Somon",
                "Lou Pluchon",
                "Frédéric Dehais",
                "Raphaëlle N. Roy",
            ],
            senior_author="Raphaëlle N. Roy",
            institution="ISAE-SUPAERO, Université de Toulouse",
            institution_department="Department of Information Processing and Systems",
            institution_address="Toulouse, France",
            country="FR",
            contact_info=["marcel.hinss@isae-supaero.fr"],
            ethics_approval=[
                "Comité d'Éthique de la Recherche (CER), Université de Toulouse (CER number 2021-342)"
            ],
            funding=[
                "ERASMUS program",
                "ANITI (Artificial and Natural Intelligence Toulouse Institute)",
            ],
            acknowledgements=(
                "This research was supported in part by the ERASMUS program "
                "(which funded Mr Hinss' internship), and by ANITI (Artificial "
                "and Natural Intelligence Toulouse Institute), Toulouse, France."
            ),
            how_to_acknowledge=(
                "Please cite: Hinss et al. (2023). Open multi-session and multi-task "
                "EEG cognitive dataset for passive brain-computer interface applications. "
                "Scientific Data, 10, 85. https://doi.org/10.1038/s41597-022-01898-y"
            ),
            repository="Zenodo",
            data_url="https://doi.org/10.5281/zenodo.6874128",
            license="CC-BY-SA-4.0",
        ),
        tags=Tags(
            pathology=["Healthy"],
            modality=["Cognitive"],
            type=["Research"],
        ),
        preprocessing=PreprocessingMetadata(
            data_state="raw",
            preprocessing_applied=False,
            highpass_hz=None,
            filter_type=None,
            artifact_methods=None,
            re_reference=None,
            downsampled_to_hz=None,
        ),
        signal_processing=SignalProcessingMetadata(
            classifiers=["MDM", "Riemannian"],
            feature_extraction=["Bandpower", "Covariance/Riemannian", "ICA"],
            frequency_bands={
                "alpha": [8.0, 13.0],
                "theta": [4.0, 8.0],
            },
        ),
        cross_validation=CrossValidationMetadata(
            cv_method="5-fold",
            cv_folds=5,
            evaluation_type=["cross_subject", "cross_session", "transfer_learning"],
        ),
        performance={
            "accuracy_percent": 70.67,
        },
        bci_application=BCIApplicationMetadata(
            applications=["neuroergonomics", "mental_workload_estimation"],
            environment="laboratory",
        ),
        paradigm_specific=ParadigmSpecificMetadata(
            detected_paradigm="rstate",
        ),
        data_structure=DataStructureMetadata(
            n_trials=90,
            n_blocks=None,
            trials_context="total",
        ),
        sessions_per_subject=2,
        runs_per_session=1,
        data_processed=False,
        file_format="set",
    )

    def __init__(self, subjects=None, sessions=None):
        super().__init__(
            subjects=list(range(1, 16)),  # 15 participants
            sessions_per_subject=2,  # 2 sessions per subject
            events=_HINNS_EVENTS,
            code="Hinss2021",
            interval=[0, 2],  # Epochs are 2-second long
            paradigm="rstate",
            doi="10.1038/s41597-022-01898-y",
            selected_subjects=subjects,
            selected_sessions=sessions,
        )

    def _get_stim_channel(self, rs_epochs, easy_epochs, med_epochs, n_epochs, n_samples):
        n_epochs_rs = rs_epochs.get_data().shape[0]
        n_epochs_easy = easy_epochs.get_data().shape[0]
        n_epochs_med = med_epochs.get_data().shape[0]
        stim = np.zeros((1, n_epochs * n_samples))
        for i in range(n_epochs):
            stim[0, n_samples * i + 1] = (
                _HINNS_EVENTS["rs"]
                if i < n_epochs_rs
                else (
                    _HINNS_EVENTS["easy"]
                    if i < n_epochs_rs + n_epochs_easy
                    else (
                        _HINNS_EVENTS["medium"]
                        if i < n_epochs_rs + n_epochs_easy + n_epochs_med
                        else _HINNS_EVENTS["diff"]
                    )
                )
            )
        return stim

    def _get_epochs(self, session_path, subject, session, event_file):
        raw = os.path.join(
            session_path,
            f"alldata_sbj{str(subject).zfill(2)}_sess{session}_{event_file}.set",
        )
        epochs = mne.io.read_epochs_eeglab(raw)
        return epochs

    def _get_single_subject_data(self, subject):
        """Load data for a single subject."""
        data = {}

        subject_path = self.data_path(subject)[0]

        for session in range(1, self.n_sessions + 1):
            session_path = os.path.join(subject_path, f"S{session}/eeg/")

            # get 'resting state'
            rs_epochs = self._get_epochs(session_path, subject, session, "RS")

            # get task 'easy'
            easy_epochs = self._get_epochs(session_path, subject, session, "MATBeasy")

            # get task 'med'
            med_epochs = self._get_epochs(session_path, subject, session, "MATBmed")

            # get task 'diff'
            diff_epochs = self._get_epochs(session_path, subject, session, "MATBdiff")

            # concatenate raw data
            raw_data = np.concatenate(
                (
                    rs_epochs.get_data(),
                    easy_epochs.get_data(),
                    med_epochs.get_data(),
                    diff_epochs.get_data(),
                )
            )

            # reshape data in the form n_channel x n_sample
            raw_data = raw_data.transpose((1, 0, 2))
            n_channel, n_epochs, n_samples = raw_data.shape
            raw_data = raw_data.reshape((n_channel, n_epochs * n_samples))

            # add stim channel
            stim = self._get_stim_channel(
                rs_epochs, easy_epochs, med_epochs, n_epochs, n_samples
            )
            raw_data = np.concatenate((raw_data, stim))

            # create info
            self._chnames = rs_epochs.ch_names + ["stim"]
            self._chtypes = ["eeg"] * (raw_data.shape[0] - 1) + ["stim"]

            info = mne.create_info(
                ch_names=self._chnames, sfreq=500, ch_types=self._chtypes, verbose=False
            )
            raw = mne.io.RawArray(raw_data, info)

            # Only one run => "0"
            data[str(session)] = {"0": raw}

        return data

    def data_path(
        self, subject, path=None, force_update=False, update_path=None, verbose=None
    ):
        if subject not in self.subject_list:
            raise (ValueError("Invalid subject number"))

        # check if has the .zip
        url = f"{URL}P{subject:02}.zip"

        path_zip = dl.data_dl(url, "Neuroergonomics2021")
        path_folder = path_zip.strip(f"P{subject:02}.zip")

        # check if has to unzip
        if not (osp.isdir(path_folder + f"P{subject:02}")) and not (
            osp.isdir(path_folder + f"P{subject:02}")
        ):
            zip_ref = z.ZipFile(path_zip, "r")
            zip_ref.extractall(path_folder)

        final_path = f"{path_folder}P{subject:02}"
        return [final_path]
