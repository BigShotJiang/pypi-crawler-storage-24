"""Utils for easy database selection."""

from __future__ import annotations

import abc
import inspect
import logging
import shutil
import stat
import subprocess
import tarfile
import zipfile
from pathlib import Path

import matplotlib.pyplot as plt
import mne
import mne_bids
import numpy as np
from mne import create_info
from mne.channels import make_standard_montage
from mne.io import RawArray

import moabb.datasets as db
from moabb.analysis.plotting import (
    _get_dataset_parameters,
    dataset_bubble_plot,
    get_dataset_area,
)
from moabb.datasets import download as dl
from moabb.datasets._channel_pick import pick_channels_for_modalities  # noqa: F401
from moabb.datasets.base import BaseDataset
from moabb.utils import aliases_list


logger = logging.getLogger(__name__)

dataset_list = []
dataset_dict = {}


def _init_dataset():
    # Recompute dataset registries on each call to avoid duplicate accumulation
    # from repeated initialization in long-lived test sessions.
    dataset_list.clear()
    dataset_dict.clear()

    for ds in inspect.getmembers(db, inspect.isclass):
        if issubclass(ds[1], BaseDataset):
            dataset_list.append(ds[1])

    deprecated_names = list(zip(*aliases_list))[0] if aliases_list else ()
    dataset_class = {
        dataset.__name__: dataset
        for dataset in dataset_list
        if dataset.__name__ not in deprecated_names
    }

    dataset_dict.update(dataset_class)


def dataset_search(  # noqa: C901
    paradigm=None,
    multi_session=False,
    events=None,
    has_all_events=False,
    interval=None,
    min_subjects=1,
    channels=(),
):
    """Returns a list of datasets that match a given criteria.

    Parameters
    ----------
    paradigm: str | None
        'imagery', 'p300', 'ssvep', 'cvep', None

    multi_session: bool
        if True only returns datasets with more than one session per subject.
        If False return all

    events: list of strings
        events to select

    has_all_events: bool
        skip datasets that don't have all events in events

    interval:
        Length of motor imagery interval, in seconds. Only used in imagery
        paradigm

    min_subjects: int,
        minimum subjects in dataset

    channels: list of str
        list or set of channels
    """
    if len(dataset_list) == 0:
        _init_dataset()

    if not dataset_dict:
        _init_dataset()

    deprecated_names = list(zip(*aliases_list))[0] if aliases_list else ()

    channels = set(channels)
    out_data = []
    if events is not None and has_all_events:
        n_classes = len(events)
    else:
        n_classes = None
    if paradigm not in ["imagery", "p300", "ssvep", "cvep", None]:  # was assert
        raise ValueError(
            f"paradigm must be one of 'imagery', 'p300', 'ssvep', 'cvep', or None, "
            f"got '{paradigm}'"
        )

    for type_d in dataset_list:
        if type_d.__name__ in deprecated_names:
            continue

        d = type_d()
        skip_dataset = False
        if multi_session and d.n_sessions < 2:
            continue

        if len(d.subject_list) < min_subjects:
            continue

        if paradigm is not None and paradigm != d.paradigm:
            continue

        if interval is not None and d.interval[1] - d.interval[0] < interval:
            continue

        keep_event_dict = {}
        if events is None:
            keep_event_dict = d.event_id.copy()
        else:
            n_events = 0
            for e in events:
                if n_classes is not None:
                    if n_events == n_classes:
                        break
                if e in d.event_id.keys():
                    keep_event_dict[e] = d.event_id[e]
                    n_events += 1
                else:
                    if has_all_events:
                        skip_dataset = True
        if keep_event_dict and not skip_dataset:
            if len(channels) > 0:
                s1 = d.get_data([1])[1]
                sess1 = s1[list(s1.keys())[0]]
                raw = sess1[list(sess1.keys())[0]]
                picks = pick_channels_for_modalities(raw.info, d.return_all_modalities)
                raw.pick(picks)
                if channels <= set(raw.info["ch_names"]):
                    out_data.append(d)
            else:
                out_data.append(d)
    return out_data


def find_intersecting_channels(datasets, verbose=False):
    """Given a list of dataset instances return a list of channels shared by
    all datasets. Skip datasets which have 0 overlap with the others.

    returns: set of common channels, list of datasets with valid channels
    """
    allchans = set()
    dset_chans = []
    keep_datasets = []
    for d in datasets:
        logger.info("Searching dataset: {:s}".format(type(d).__name__))
        s1 = d.get_data([1])[1]
        sess1 = s1[list(s1.keys())[0]]
        raw = sess1[list(sess1.keys())[0]]
        picks = pick_channels_for_modalities(raw.info, d.return_all_modalities)
        raw.pick(picks)
        processed = []
        for ch in raw.info["ch_names"]:
            ch = ch.upper()
            if ch.find("EEG") == -1:
                # TODO: less hacky way of finding poorly labeled datasets
                processed.append(ch)
        allchans.update(processed)
        if len(processed) > 0:
            if verbose:
                logger.info("Found EEG channels: {}".format(processed))
            dset_chans.append(processed)
            keep_datasets.append(d)
        else:
            logger.warning(
                "Dataset {:s} has no recognizable EEG channels".format(type(d).__name__)
            )  # noqa
    allchans.intersection_update(*dset_chans)
    allchans = [s.replace("Z", "z") for s in allchans]
    return allchans, keep_datasets


def _download_all(update_path=True, verbose=None):
    """Download all data.

    This function is mainly used to generate the data cache.
    """

    # iterate over dataset
    for ds in dataset_list:
        # call download
        ds().download(update_path=True, verbose=verbose, accept=True)


def block_rep(block: int, rep: int, n_rep: int):
    idx = block * n_rep + rep
    return f"{idx}block{block}rep{rep}"


def blocks_reps(blocks: list, reps: list, n_rep: int):
    return [block_rep(b, r, n_rep) for b in blocks for r in reps]


def add_stim_channel_trial(raw, onsets, labels, offset=200, ch_name="stim_trial"):
    """
    Add a stimulus channel with trial onsets and their labels.

    Parameters
    ----------
    raw: mne.Raw
        The raw object to add the stimulus channel to.
    onsets: List | np.ndarray
        The onsets of the trials in sample numbers.
    labels: List | np.ndarray
        The labels of the trials.
    offset : int
        The integer value to start markers with. For instance, if 200, then label 0 will be marker 200, label 1
        will be marker 201, etc. Defaults to ``200``.
    ch_name : str
        The name of the added stimulus channel. Defaults to ``"stim_trial"``.

    Returns
    -------
    mne.Raw
        The raw object with the added stimulus channel.

    Notes
    -----
    .. versionadded:: 1.1.0
    """
    stim_chan = np.zeros((1, len(raw)))
    for onset, label in zip(onsets, labels):
        stim_chan[0, onset] = offset + label
    info = create_info(
        ch_names=[ch_name],
        ch_types=["stim"],
        sfreq=raw.info["sfreq"],
        verbose=False,
    )
    raw = raw.add_channels([RawArray(data=stim_chan, info=info, verbose=False)])
    return raw


def add_stim_channel_epoch(
    raw,
    onsets,
    labels,
    codes=None,
    presentation_rate=None,
    offset=100,
    ch_name="stim_epoch",
):
    """
    Add a stimulus channel with epoch onsets and their labels, which are the values of the presented code for each
    of the trials.

    Parameters
    ----------
    raw: mne.Raw
        The raw object to add the stimulus channel to.
    onsets: List | np.ndarray
        The onsets of the trials in sample numbers.
    labels: List | np.ndarray
        The labels of the trials.
    codes : np.ndarray or None
        The codebook containing each presented code, of shape ``(nr_bits, nr_codes)``,
        sampled at the presentation rate.
        If None, the labels information is used directly. Defaults to ``None``.
    presentation_rate : int or None
        The presentation rate (e.g., frame rate) at which the codes were presented in Hz.
        If None, the raw object's sampling frequency is used. Defaults to ``None``.
    offset : int
        The integer value to start markers with. For instance, if 100, then label 0 will be marker 100, label 1
        will be marker 101, etc. Defaults to ``100``.
    ch_name : str
        The name of the added stimulus channel. Defaults to ``"stim_epoch"``.

    Returns
    -------
    mne.Raw
        The raw object with the added stimulus channel.

    Notes
    -----
    .. versionadded:: 1.1.0
    """
    if presentation_rate is None:
        presentation_rate = raw.info["sfreq"]
    stim_chan = np.zeros((1, len(raw)))
    for onset, label in zip(onsets, labels):
        if codes is None:
            stim_chan[0, int(onset * presentation_rate)] = offset + label
        else:
            idx = np.round(
                onset + np.arange(codes.shape[0]) / presentation_rate * raw.info["sfreq"]
            ).astype("int")
            stim_chan[0, idx] = offset + codes[:, label]

    info = create_info(
        ch_names=[ch_name],
        ch_types=["stim"],
        sfreq=raw.info["sfreq"],
        verbose=False,
    )
    raw = raw.add_channels([RawArray(data=stim_chan, info=info, verbose=False)])
    return raw


def stim_channels_with_selected_ids(
    raw: mne.io.BaseRaw, desired_event_id: dict, stim_channel_name="STIM"
):
    """
    Add a stimulus channel with filtering and renaming based on events_ids.

    Parameters
    ----------
    raw: mne.Raw
        The raw object to add the stimulus channel to.
    desired_event_id: dict
        Dictionary with events
    """

    # Get events using the consistent event_id mapping
    events, _ = mne.events_from_annotations(raw, event_id=desired_event_id)

    # Filter the events array to include only desired events
    desired_event_ids = list(desired_event_id.values())
    filtered_events = events[np.isin(events[:, 2], desired_event_ids)]

    # Create annotations from filtered events using the inverted mapping
    event_desc = {v: k for k, v in desired_event_id.items()}
    annot_from_events = mne.annotations_from_events(
        events=filtered_events,
        event_desc=event_desc,
        sfreq=raw.info["sfreq"],
        orig_time=raw.info["meas_date"],
    )
    raw.set_annotations(annot_from_events)

    # Create the stim channel data array
    stim_channs = np.zeros((1, raw.n_times))
    for event in filtered_events:
        sample_index = event[0]
        event_code = event[2]  # Consistent event IDs
        stim_channs[0, sample_index] = event_code

    # Create the stim channel and add it to raw

    stim_info = mne.create_info(
        [stim_channel_name], sfreq=raw.info["sfreq"], ch_types=["stim"]
    )
    stim_raw = mne.io.RawArray(stim_channs, stim_info, verbose=False)
    raw_with_stim = raw.copy().add_channels([stim_raw], force_update_info=True)

    return raw_with_stim


def bids_metainfo(bids_path: Path) -> dict:
    """Create metadata for the BIDS dataset.

    To allow lazy loading of the metadata, we store the metadata in a JSON file
    in the root of the BIDS dataset.

    Parameters
    ----------
    bids_path : pathlib.Path
        The path to the BIDS dataset.
    """
    json_data = {}

    paths = mne_bids.find_matching_paths(
        root=bids_path,
        datatypes="eeg",
    )

    for path in paths:
        uid = path.fpath.name
        json_data[uid] = path.entities
        json_data[uid]["fpath"] = str(path.fpath)

    return json_data


FIGSHARE_DL_URL = "https://ndownloader.figshare.com/files/"

# Tsinghua/Neuroscan 64-channel layout used by Wang2016, Liu2020BETA,
# Liu2022EldBETA, and Han2024Fatigue. Includes non-standard CB1/CB2 channels.
# fmt: off
TSINGHUA_64CH_NAMES = [
    "Fp1", "Fpz", "Fp2", "AF3", "AF4", "F7", "F5", "F3", "F1", "Fz", "F2", "F4", "F6",
    "F8", "FT7", "FC5", "FC3", "FC1", "FCz", "FC2", "FC4", "FC6", "FT8", "T7", "C5",
    "C3", "C1", "Cz", "C2", "C4", "C6", "T8", "M1", "TP7", "CP5", "CP3", "CP1", "CPz",
    "CP2", "CP4", "CP6", "TP8", "M2", "P7", "P5", "P3", "P1", "Pz", "P2", "P4", "P6",
    "P8", "PO7", "PO5", "PO3", "POz", "PO4", "PO6", "PO8", "CB1", "O1", "Oz", "O2",
    "CB2",
]
# fmt: on


def _validate_member_destination(dest_dir: Path, member_name: str):
    """Ensure archive member extraction stays within destination directory."""
    target = (dest_dir / member_name).resolve()
    try:
        target.relative_to(dest_dir)
    except ValueError as exc:
        raise ValueError(
            f"Unsafe archive member path {member_name!r} escapes {dest_dir}."
        ) from exc
    return target


def safe_extract_zip(zf: zipfile.ZipFile, dest_dir: Path, members=None):
    """Safely extract a ZIP archive into ``dest_dir`` (path traversal protected)."""
    dest_dir = Path(dest_dir).resolve()
    selected = members if members is not None else zf.infolist()

    for member in selected:
        info = member if isinstance(member, zipfile.ZipInfo) else zf.getinfo(member)
        _validate_member_destination(dest_dir, info.filename)
        # Reject symlink entries when present in UNIX mode bits.
        mode = info.external_attr >> 16
        if mode and stat.S_ISLNK(mode):
            raise ValueError(
                f"Unsafe ZIP member {info.filename!r}: symbolic links are not allowed."
            )

    zf.extractall(dest_dir, members=selected)


def safe_extract_tar(tf: tarfile.TarFile, dest_dir: Path, members=None):
    """Safely extract a TAR archive into ``dest_dir`` (path traversal protected)."""
    dest_dir = Path(dest_dir).resolve()
    selected = members if members is not None else tf.getmembers()

    for member in selected:
        _validate_member_destination(dest_dir, member.name)
        if member.issym() or member.islnk():
            raise ValueError(f"Unsafe TAR member {member.name!r}: links are not allowed.")

    tf.extractall(dest_dir, members=selected)


def build_raw_from_epochs(
    data,
    ch_names,
    sfreq,
    event_ids,
    montage_name,
    *,
    ch_types=None,
    scale=1e-6,
    buffer_samples=50,
    onset_sample=0,
):
    """Convert (n_trials, n_channels, n_samples) epoched data to continuous Raw.

    Parameters
    ----------
    data : ndarray
        Epoched EEG data (in original units, e.g. microvolts),
        of shape ``(n_trials, n_channels, n_samples)``.
    ch_names : list of str
        EEG channel names (without "stim").
    sfreq : float
        Sampling frequency in Hz.
    event_ids : ndarray
        Integer event code for each trial, of shape ``(n_trials,)``.
    montage_name : str
        Name of a standard MNE montage (e.g. "standard_1005", "biosemi32").
    ch_types : list of str or None
        Channel types for each signal channel in ``ch_names``. If None, all
        channels are treated as ``"eeg"``.
    scale : float
        Scale factor to convert data to Volts. Defaults to ``1e-6``
        (for microvolts).
    buffer_samples : int
        Number of zero-padding samples between trials. Defaults to ``50``.
    onset_sample : int
        Sample index within each epoch to place the event marker.
        Defaults to ``0``.

    Returns
    -------
    raw : mne.io.RawArray
        Continuous raw data with EEG + stim channels.
    """
    data = np.asarray(data)
    if data.ndim != 3:
        raise ValueError(
            "data must have shape (n_trials, n_channels, n_samples), "
            f"got array with shape {data.shape}."
        )
    n_trials, n_channels, n_samples = data.shape

    if isinstance(ch_names, str):
        raise ValueError(
            "ch_names must be a sequence of channel names, not a single string."
        )
    if len(ch_names) != n_channels:
        raise ValueError(
            f"ch_names length ({len(ch_names)}) must match n_channels ({n_channels})."
        )

    if ch_types is None:
        ch_types = ["eeg"] * n_channels
    if isinstance(ch_types, str):
        raise ValueError(
            "ch_types must be a sequence of channel types, not a single string."
        )
    if len(ch_types) != n_channels:
        raise ValueError(
            f"ch_types length ({len(ch_types)}) must match n_channels ({n_channels})."
        )

    event_ids = np.asarray(event_ids)
    if event_ids.ndim != 1:
        raise ValueError(
            "event_ids must be a 1D array-like of length n_trials; "
            f"got shape {event_ids.shape}."
        )
    if len(event_ids) != n_trials:
        raise ValueError(
            f"event_ids length ({len(event_ids)}) must match n_trials ({n_trials})."
        )

    if isinstance(onset_sample, bool) or not isinstance(onset_sample, (int, np.integer)):
        raise ValueError(
            f"onset_sample must be an integer in [0, {n_samples - 1}], got "
            f"{onset_sample!r} ({type(onset_sample).__name__})."
        )
    if onset_sample < 0 or onset_sample >= n_samples:
        raise ValueError(
            f"onset_sample ({onset_sample}) must be between 0 and {n_samples - 1}."
        )

    # De-mean and scale each trial in-place (callers pass freshly created arrays)
    data = data - data.mean(axis=2, keepdims=True)
    data *= scale

    # Build stim channel
    stim = np.zeros((n_trials, 1, n_samples))
    stim[:, 0, onset_sample] = event_ids

    # Combine EEG + stim, add zero-padding buffers
    combined = np.concatenate([data, stim], axis=1)
    n_total_ch = n_channels + 1

    if buffer_samples > 0:
        buff = np.zeros((n_trials, n_total_ch, buffer_samples))
        combined = np.concatenate([buff, combined, buff], axis=2)

    # Flatten trials into continuous data: (n_trials, n_ch, n_time) -> (n_ch, n_trials*n_time)
    continuous = combined.transpose(1, 0, 2).reshape(n_total_ch, -1)

    ch_names_full = list(ch_names) + ["STI"]
    ch_types_full = list(ch_types) + ["stim"]
    info = create_info(ch_names_full, sfreq, ch_types_full)
    raw = RawArray(data=continuous, info=info, verbose=False)
    montage = make_standard_montage(montage_name)
    raw.set_montage(montage, on_missing="ignore")
    return raw


def download_and_extract_subject_zip(
    url, sign, extract_dir, path=None, force_update=False, verbose=None
):
    """Download a per-subject ZIP and safely extract it.

    Handles the common pattern: ``dl.data_dl()`` → rename to ``.zip`` →
    ``safe_extract_zip()``.

    Parameters
    ----------
    url : str
        Direct download URL for the ZIP file.
    sign : str
        Dataset code passed to :func:`dl.data_dl` (e.g., ``"Wu2020"``).
    extract_dir : pathlib.Path | str
        Directory to extract ZIP contents into.
    path : str | None
        Download path passed to :func:`dl.data_dl`.
    force_update : bool
        Force re-download even if file exists locally.
    verbose : bool | None
        Verbosity level.
    """
    dl_path = Path(dl.data_dl(url, sign, path, force_update, verbose))

    # Rename to .zip if dl.data_dl() stripped the extension.
    zip_path = dl_path.with_suffix(".zip")
    if dl_path != zip_path:
        dl_path.rename(zip_path)

    extract_dir = Path(extract_dir)
    extract_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path) as zf:
        safe_extract_zip(zf, extract_dir)


def extract_rar(rar_path, dest_dir):
    """Extract a RAR archive using available system tools.

    Tries ``unrar``, ``unar``, and ``7z`` in order.

    Parameters
    ----------
    rar_path : str or pathlib.Path
        Path to the RAR archive.
    dest_dir : str or pathlib.Path
        Directory to extract files into.
    """
    dest_dir = Path(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=True)
    rar_path = str(rar_path)

    for tool, cmd_fn in [
        ("unrar", lambda d, r: ["unrar", "x", "-o+", r, str(d) + "/"]),
        ("unar", lambda d, r: ["unar", "-f", "-o", str(d), r]),
        ("7z", lambda d, r: ["7z", "x", "-y", f"-o{d}", r]),
    ]:
        if shutil.which(tool) is not None:
            cmd = cmd_fn(dest_dir, rar_path)
            result = subprocess.run(cmd, capture_output=True, text=True)
            if result.returncode != 0:
                raise RuntimeError(
                    f"RAR extraction failed with {tool} "
                    f"(exit {result.returncode}):\n{result.stderr}"
                )
            return

    raise RuntimeError(
        "No RAR extraction tool found. Install one of: unrar, unar, or 7z. "
        "For example: 'brew install unar' (macOS) or 'apt install unrar' (Linux)."
    )


class _BubbleChart:
    def __init__(self, area, bubble_spacing=0.0):
        """
        Setup for bubble collapse.

        From https://matplotlib.org/stable/gallery/misc/packed_bubbles.html

        Parameters
        ----------
        area : array-like
            Area of the bubbles.
        bubble_spacing : float
            Minimal spacing between bubbles after collapsing.
            Defaults to ``0``.

        Notes
        -----
        If "area" is sorted, the results might look weird.
        """
        area = np.asarray(area)
        r = np.sqrt(area / np.pi)

        self.bubble_spacing = bubble_spacing
        self.bubbles = np.ones((len(area), 4))
        self.bubbles[:, 2] = r
        self.bubbles[:, 3] = area
        self.maxstep = 2 * self.bubbles[:, 2].max() + self.bubble_spacing
        self.step_dist = self.maxstep / 2

        # calculate initial grid layout for bubbles
        length = np.ceil(np.sqrt(len(self.bubbles)))
        grid = np.arange(length) * self.maxstep
        gx, gy = np.meshgrid(grid, grid)
        self.bubbles[:, 0] = gx.flatten()[: len(self.bubbles)]
        self.bubbles[:, 1] = gy.flatten()[: len(self.bubbles)]

        self.com = self.center_of_mass()

    def center_of_mass(self):
        return np.average(self.bubbles[:, :2], axis=0, weights=self.bubbles[:, 3])

    def center_distance(self, bubble, bubbles):
        return np.hypot(bubble[0] - bubbles[:, 0], bubble[1] - bubbles[:, 1])

    def outline_distance(self, bubble, bubbles):
        center_distance = self.center_distance(bubble, bubbles)
        return center_distance - bubble[2] - bubbles[:, 2] - self.bubble_spacing

    def check_collisions(self, bubble, bubbles):
        distance = self.outline_distance(bubble, bubbles)
        return len(distance[distance < 0])

    def collides_with(self, bubble, bubbles):
        distance = self.outline_distance(bubble, bubbles)
        return np.argmin(distance, keepdims=True)

    def collapse(self, n_iterations=50):
        """
        Move bubbles to the center of mass.

        Parameters
        ----------
        n_iterations : int
            Number of moves to perform. Defaults to ``50``.
        """
        for _i in range(n_iterations):
            moves = 0
            for i in range(len(self.bubbles)):
                rest_bub = np.delete(self.bubbles, i, 0)
                # try to move directly towards the center of mass
                # direction vector from bubble to the center of mass
                dir_vec = self.com - self.bubbles[i, :2]

                # shorten direction vector to have length of 1
                dir_vec = dir_vec / np.sqrt(dir_vec.dot(dir_vec))

                # calculate new bubble position
                new_point = self.bubbles[i, :2] + dir_vec * self.step_dist
                new_bubble = np.append(new_point, self.bubbles[i, 2:4])

                # check whether new bubble collides with other bubbles
                if not self.check_collisions(new_bubble, rest_bub):
                    self.bubbles[i, :] = new_bubble
                    self.com = self.center_of_mass()
                    moves += 1
                else:
                    # try to move around a bubble that you collide with
                    # find colliding bubble
                    for colliding in self.collides_with(new_bubble, rest_bub):
                        # calculate direction vector
                        dir_vec = rest_bub[colliding, :2] - self.bubbles[i, :2]
                        dir_vec = dir_vec / np.sqrt(dir_vec.dot(dir_vec))
                        # calculate orthogonal vector
                        orth = np.array([dir_vec[1], -dir_vec[0]])
                        # test which direction to go
                        new_point1 = self.bubbles[i, :2] + orth * self.step_dist
                        new_point2 = self.bubbles[i, :2] - orth * self.step_dist
                        dist1 = self.center_distance(self.com, np.array([new_point1]))
                        dist2 = self.center_distance(self.com, np.array([new_point2]))
                        new_point = new_point1 if dist1 < dist2 else new_point2
                        new_bubble = np.append(new_point, self.bubbles[i, 2:4])
                        if not self.check_collisions(new_bubble, rest_bub):
                            self.bubbles[i, :] = new_bubble
                            self.com = self.center_of_mass()

            if moves / len(self.bubbles) < 0.1:
                self.step_dist = self.step_dist / 2

    def get_centers(self):
        return self.bubbles[:, :2]


class _BaseDatasetPlotter:
    def __init__(self, datasets, meta_gap, kwargs, n_col=None):
        self.datasets = datasets = (
            datasets
            if datasets is not None
            else sorted(
                [dataset() for dataset in dataset_list if "Fake" not in dataset.__name__],
                key=lambda x: x.__class__.__name__,
            )
        )
        areas_list = []
        for d in datasets:
            if isinstance(d, dict):
                n_subjects = d["n_subjects"]
                n_sessions = d["n_sessions"]
                n_trials = d["n_trials"]
                trial_len = d["trial_len"]
            else:
                _, _, n_subjects, n_sessions, n_trials, trial_len = (
                    _get_dataset_parameters(d)
                )
            areas_list.append(
                get_dataset_area(
                    n_subjects=n_subjects,
                    n_sessions=n_sessions,
                    n_trials=n_trials,
                    trial_len=trial_len,
                )
            )
        self.areas = np.array(areas_list)
        self.radii = np.sqrt(self.areas / np.pi)
        self.meta_gap = meta_gap
        self.kwargs = kwargs
        self.n_col = n_col

    @abc.abstractmethod
    def _get_centers(self) -> np.ndarray:
        pass

    def plot(self):

        centers = self._get_centers()

        rm = self.radii + self.meta_gap
        xlim = ((centers[:, 0] - rm).min(), (centers[:, 0] + rm).max() + self.meta_gap)
        ylim = ((centers[:, 1] - rm).min(), (centers[:, 1] + rm).max())
        lx, ly = xlim[1] - self.meta_gap, ylim[0] + self.meta_gap

        factor = 0.05
        # No need to expose the factor parameter as users can already
        # tune the scale and fontsize arguments, which will have the same effect.
        fig, ax = plt.subplots(
            subplot_kw={"aspect": "equal"},
            figsize=(factor * (xlim[1] - xlim[0]), factor * (ylim[1] - ylim[0])),
        )
        ax.set_xlim(xlim)
        ax.set_ylim(ylim)
        for i, dataset in enumerate(self.datasets):
            dataset_kwargs = (
                dataset if isinstance(dataset, dict) else {"dataset": dataset}
            )
            dataset_bubble_plot(
                **dataset_kwargs,
                ax=ax,
                center=centers[i],
                legend=i == len(self.datasets) - 1,
                legend_position=(lx, ly),
                scale_ax=False,
                **self.kwargs,
            )
        return fig


class _ClusterDatasetPlotter(_BaseDatasetPlotter):
    def _get_centers(self):
        bubble_chart = _BubbleChart(self.areas, bubble_spacing=self.meta_gap)
        bubble_chart.collapse(n_iterations=100)
        return bubble_chart.get_centers()


class _GridDatasetPlotter(_BaseDatasetPlotter):
    def _get_centers(self):
        assert isinstance(self.n_col, int)
        height = self.radii.max() * 2
        i = np.arange(len(self.datasets))
        x = i % self.n_col
        y = -(i // self.n_col)
        return np.stack([x, y], axis=1) * height


def plot_datasets_grid(
    datasets: list[BaseDataset | dict] | None = None,
    n_col: int = 10,
    margin: float = 10.0,
    **kwargs,
):
    """Plots all the MOABB datasets in one figure, distributed on a grid.

    This uses the :func:`~moabb.analysis.plotting.dataset_bubble_plot` function to
    plot the datasets.
    The datasets are sorted in alphabetical order and
    plotted in a grid with n_col columns.

    Parameters
    ----------
    datasets: list[BaseDataset | dict] | None
        List of datasets to plot. If None, all datasets are plotted.
        If an element of the list is a dictionary, it is assumed to
        have the following keys:

            dataset_name: str
                Name of the dataset.
            paradigm: str
                Paradigm of the dataset (e.g., 'imagery', 'p300').
            n_subjects: int
                Number of subjects in the dataset.
            n_sessions: int
                Number of sessions in the dataset.
            n_trials: int
                Number of trials in the dataset.
            trial_len: float
                Length of each trial in seconds.

    n_col: int
        Number of columns in the figure.
    margin: float
        Margin around the plots.
    kwargs: dict
        Additional arguments to pass to the dataset_bubble_plot function.

    Returns
    -------
    fig: :class:`matplotlib.figure.Figure`
        Pyplot handle
    """
    plotter = _GridDatasetPlotter(
        datasets=datasets,
        meta_gap=margin,
        n_col=n_col,
        kwargs=kwargs,
    )
    return plotter.plot()


def plot_datasets_cluster(
    datasets: list[BaseDataset | dict] | None = None,
    meta_gap: float = 10.0,
    **kwargs,
):
    """Plots all the MOABB datasets in one figure, grouped in one cluster.

    This uses the :func:`~moabb.analysis.plotting.dataset_bubble_plot` function to
    plot the datasets.
    The datasets are sorted in alphabetical order and
    plotted in a grid with n_col columns.

    Parameters
    ----------
    datasets: list[BaseDataset | dict] | None
        List of datasets to plot. If None, all datasets are plotted.
        If an element of the list is a dictionary, it is assumed to
        have the following keys:

            dataset_name: str
                Name of the dataset.
            paradigm: str
                Paradigm of the dataset (e.g., 'imagery', 'p300').
            n_subjects: int
                Number of subjects in the dataset.
            n_sessions: int
                Number of sessions in the dataset.
            n_trials: int
                Number of trials in the dataset.
            trial_len: float
                Length of each trial in seconds.

    meta_gap: float
        Gap between the different datasets in the cluster.
    kwargs: dict
        Additional arguments to pass to the dataset_bubble_plot function.

    Returns
    -------
    fig: :class:`matplotlib.figure.Figure`
        Pyplot handle
    """
    plotter = _ClusterDatasetPlotter(
        datasets=datasets,
        meta_gap=meta_gap,
        kwargs=kwargs,
    )
    return plotter.plot()
