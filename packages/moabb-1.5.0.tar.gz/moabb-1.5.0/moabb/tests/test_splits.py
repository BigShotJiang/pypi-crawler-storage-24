import numpy as np
import pytest
from sklearn.model_selection import (
    GroupShuffleSplit,
    KFold,
    LeaveOneGroupOut,
    LeaveOneOut,
    LeavePGroupsOut,
    LeavePOut,
    RepeatedKFold,
    RepeatedStratifiedKFold,
    ShuffleSplit,
    StratifiedGroupKFold,
    StratifiedKFold,
    StratifiedShuffleSplit,
    TimeSeriesSplit,
)
from sklearn.utils import check_random_state

from moabb.datasets.fake import FakeDataset
from moabb.evaluations.splitters import (
    CrossDatasetSplitter,
    CrossSessionSplitter,
    CrossSubjectSplitter,
    LearningCurveSplitter,
    WithinSessionSplitter,
    WithinSubjectSplitter,
)
from moabb.paradigms.motor_imagery import FakeImageryParadigm


@pytest.fixture
def data():
    dataset = FakeDataset(
        ["left_hand", "right_hand"], n_subjects=5, seed=12, n_sessions=5
    )
    paradigm = FakeImageryParadigm()
    return paradigm.get_data(dataset=dataset)


# Split done for the Within Session evaluation
def eval_split_within_session(shuffle, random_state, data):
    _, y, metadata = data

    all_index = metadata.index.values
    # Convert to numpy array to avoid ArrowStringArray shuffle warning
    subjects = np.array(metadata["subject"].unique())
    if shuffle:
        shuffle_rng = check_random_state(random_state)
        shuffle_rng.shuffle(subjects)

    for i, subject in enumerate(subjects):
        subject_mask = metadata["subject"] == subject

        subject_indices = all_index[subject_mask]
        subject_metadata = metadata[subject_mask]
        # Convert to numpy array to avoid ArrowStringArray shuffle warning
        sessions = np.array(subject_metadata["session"].unique())
        y_subject = y[subject_mask]

        if shuffle:
            shuffle_rng.shuffle(sessions)

        for session in sessions:
            session_mask = subject_metadata["session"] == session
            indices = subject_indices[session_mask]
            metadata_ = subject_metadata[session_mask]
            y_ = y_subject[session_mask]

            cv_rng = check_random_state(random_state) if shuffle else None
            cv = StratifiedKFold(n_splits=5, shuffle=shuffle, random_state=cv_rng)

            for idx_train, idx_test in cv.split(metadata_, y_):
                yield indices[idx_train], indices[idx_test]


def eval_split_within_subject(shuffle, random_state, data):
    _, y, metadata = data
    rng = check_random_state(random_state) if shuffle else None

    all_index = metadata.index.values
    # Convert to numpy array to avoid ArrowStringArray shuffle warning
    subjects = np.array(metadata["subject"].unique())
    if shuffle:
        rng.shuffle(subjects)

    for subject in subjects:
        subject_mask = metadata["subject"] == subject
        subject_indices = all_index[subject_mask]
        y_subject = y[subject_mask]

        cv = StratifiedKFold(n_splits=5, shuffle=shuffle, random_state=rng)

        for idx_train, idx_test in cv.split(subject_indices, y_subject):
            yield subject_indices[idx_train], subject_indices[idx_test]


def eval_split_cross_subject(shuffle, random_state, data):
    rng = check_random_state(random_state) if shuffle else None

    _, y, metadata = data
    subjects = metadata["subject"].unique()

    if shuffle:
        splitter = GroupShuffleSplit(random_state=rng)
    else:
        splitter = LeaveOneGroupOut()

    for train_subj_idx, test_subj_idx in splitter.split(
        X=np.zeros(len(subjects)), y=None, groups=subjects
    ):
        train_mask = metadata["subject"].isin(subjects[train_subj_idx])
        test_mask = metadata["subject"].isin(subjects[test_subj_idx])

        yield metadata.index[train_mask].values, metadata.index[test_mask].values


def _metadata_with_dataset_column(metadata, n_datasets=3):
    """Attach a synthetic dataset-group column while preserving subjects."""
    metadata = metadata.copy()
    subjects = np.array(metadata["subject"].unique())
    n_datasets = max(1, min(n_datasets, len(subjects)))
    dataset_labels = np.array([f"ds_{i + 1}" for i in range(n_datasets)])
    subject_to_dataset = {
        subject: dataset_labels[i % len(dataset_labels)]
        for i, subject in enumerate(subjects)
    }
    metadata["dataset"] = metadata["subject"].map(subject_to_dataset)
    return metadata


def eval_split_cross_dataset(shuffle, random_state, data):
    rng = check_random_state(random_state) if shuffle else None

    _, y, metadata = data
    metadata = _metadata_with_dataset_column(metadata)
    datasets = metadata["dataset"].unique()

    if shuffle:
        splitter = GroupShuffleSplit(random_state=rng)
    else:
        splitter = LeaveOneGroupOut()

    for train_dataset_idx, test_dataset_idx in splitter.split(
        X=np.zeros(len(datasets)), y=None, groups=datasets
    ):
        train_mask = metadata["dataset"].isin(datasets[train_dataset_idx])
        test_mask = metadata["dataset"].isin(datasets[test_dataset_idx])

        yield metadata.index[train_mask].values, metadata.index[test_mask].values


def eval_split_cross_session(shuffle, random_state, data):
    _, y, metadata = data

    rng = check_random_state(random_state) if shuffle else None

    subjects = metadata["subject"].unique()

    for subject in subjects:
        subject_mask = metadata["subject"] == subject
        subject_metadata = metadata[subject_mask]
        subject_sessions = subject_metadata["session"].unique()

        if shuffle:
            splitter = GroupShuffleSplit(n_splits=len(subject_sessions), random_state=rng)
        else:
            splitter = LeaveOneGroupOut()

        for train_ix, test_ix in splitter.split(
            X=subject_metadata, y=y[subject_mask], groups=subject_metadata["session"]
        ):
            yield subject_metadata.index[train_ix], subject_metadata.index[test_ix]


@pytest.mark.parametrize("shuffle, random_state", [(True, 0), (True, 42), (False, None)])
def test_within_session_compatibility(shuffle, random_state, data):
    _, y, metadata = data

    split = WithinSessionSplitter(n_folds=5, shuffle=shuffle, random_state=random_state)

    for (idx_train, idx_test), (idx_train_splitter, idx_test_splitter) in zip(
        eval_split_within_session(shuffle=shuffle, random_state=random_state, data=data),
        split.split(y, metadata),
    ):
        # Check if the output is the same as the input
        assert np.array_equal(idx_train, idx_train_splitter)
        assert np.array_equal(idx_test, idx_test_splitter)


@pytest.mark.parametrize("shuffle, random_state", [(True, 0), (True, 42), (False, None)])
def test_within_subject_compatibility(shuffle, random_state, data):
    _, y, metadata = data

    split = WithinSubjectSplitter(n_folds=5, shuffle=shuffle, random_state=random_state)

    for (idx_train, idx_test), (idx_train_splitter, idx_test_splitter) in zip(
        eval_split_within_subject(shuffle=shuffle, random_state=random_state, data=data),
        split.split(y, metadata),
    ):
        # Check if the output is the same as the input
        assert np.array_equal(idx_train, idx_train_splitter)
        assert np.array_equal(idx_test, idx_test_splitter)


def test_is_shuffling(data):
    X, y, metadata = data

    split = WithinSessionSplitter(n_folds=5, shuffle=False)
    split_shuffle = WithinSessionSplitter(n_folds=5, shuffle=True, random_state=3)

    for (train, test), (train_shuffle, test_shuffle) in zip(
        split.split(y, metadata), split_shuffle.split(y, metadata)
    ):
        # Check if the output is the same as the input
        assert not np.array_equal(train, train_shuffle)
        assert not np.array_equal(test, test_shuffle)


@pytest.mark.parametrize(
    "splitter",
    [
        WithinSessionSplitter,
        WithinSubjectSplitter,
        CrossSessionSplitter,
        CrossSubjectSplitter,
        CrossDatasetSplitter,
    ],
)
def test_custom_inner_cv(
    splitter,
    data,
):
    X, y, metadata = data
    if splitter == CrossDatasetSplitter:
        metadata = _metadata_with_dataset_column(metadata)
    # Use a custom inner cv
    split = splitter(cv_class=TimeSeriesSplit, max_train_size=2)

    for train, test in split.split(y, metadata):
        # Check if the output is the same as the input
        assert len(train) <= 2  # Due to TimeSeriesSplit constraints
        assert len(test) >= 20


def test_custom_shuffle_group(data):
    _, y, metadata = data

    n_splits = 5
    splitter = CrossSubjectSplitter(
        random_state=42,
        cv_class=GroupShuffleSplit,
        n_splits=n_splits,
    )

    splits = list(splitter.split(y, metadata))

    assert len(splits) == n_splits, f"Expected {n_splits} splits, got {len(splits)}"

    for train, test in splits:
        train_subjects = metadata.iloc[train]["subject"].unique()
        test_subjects = metadata.iloc[test]["subject"].unique()

        # Assert no overlap between train and test subjects
        assert len(set(train_subjects) & set(test_subjects)) == 0

    # Check if shuffling produces different splits
    splitter_different_seed = CrossSubjectSplitter(
        cv_class=GroupShuffleSplit,
        n_splits=n_splits,
    )
    splits_different_seed = list(splitter_different_seed.split(y, metadata))

    assert not all(
        np.array_equal(train, train_alt) and np.array_equal(test, test_alt)
        for (train, test), (train_alt, test_alt) in zip(splits, splits_different_seed)
    )


@pytest.mark.parametrize("shuffle, random_state", [(True, 0), (True, 42), (False, None)])
def test_cross_session(shuffle, random_state, data):
    _, y, metadata = data

    params = {"random_state": random_state}
    params["shuffle"] = shuffle
    if shuffle:
        params["cv_class"] = GroupShuffleSplit

    split = CrossSessionSplitter(**params)

    for idx_train_splitter, idx_test_splitter in split.split(y, metadata):
        # Check if the output is the same as the input
        session_train = metadata.iloc[idx_train_splitter]["session"].unique()
        session_test = metadata.iloc[idx_test_splitter]["session"].unique()
        assert np.intersect1d(session_train, session_test).size == 0
        assert (
            np.union1d(session_train, session_test).size
            == metadata["session"].unique().size
        )


@pytest.mark.parametrize(
    "splitter", [CrossSessionSplitter, CrossSubjectSplitter, CrossDatasetSplitter]
)
@pytest.mark.parametrize("shuffle, random_state", [(False, None), (True, 0), (True, 42)])
def test_cross_compatibility(splitter, shuffle, random_state, data):
    _, y, metadata = data

    if splitter == CrossSessionSplitter:
        function_split = eval_split_cross_session
    elif splitter == CrossSubjectSplitter:
        function_split = eval_split_cross_subject
    else:
        function_split = eval_split_cross_dataset
        metadata = _metadata_with_dataset_column(metadata)

    params = {"random_state": random_state}
    if splitter == CrossSessionSplitter:
        params["shuffle"] = shuffle
    if shuffle:
        params["cv_class"] = GroupShuffleSplit

    split = splitter(**params)

    for (idx_train, idx_test), (idx_train_splitter, idx_test_splitter) in zip(
        function_split(shuffle=shuffle, random_state=random_state, data=data),
        split.split(y, metadata),
    ):
        assert np.array_equal(idx_train, idx_train_splitter)
        assert np.array_equal(idx_test, idx_test_splitter)


def test_cross_session_is_shuffling_and_order(data):
    _, y, metadata = data

    splitter_no_shuffle = CrossSessionSplitter(shuffle=False)
    splitter_shuffle = CrossSessionSplitter(
        shuffle=True, random_state=3, cv_class=GroupShuffleSplit
    )

    splits_no_shuffle = list(splitter_no_shuffle.split(y, metadata))
    splits_shuffle = list(splitter_shuffle.split(y, metadata))

    train_diff = []
    test_diff = []

    # For tracking session order differences
    session_orders_no_shuffle = []
    session_orders_shuffle = []

    for i, ((train_ns, test_ns), (train_s, test_s)) in enumerate(
        zip(splits_no_shuffle, splits_shuffle)
    ):
        print(f"\nFold {i}:")

        # Get session ordering for non-shuffled and shuffled
        train_ns_sessions = metadata.iloc[train_ns]["session"].unique()
        test_ns_sessions = metadata.iloc[test_ns]["session"].unique()
        train_s_sessions = metadata.iloc[train_s]["session"].unique()
        test_s_sessions = metadata.iloc[test_s]["session"].unique()

        print(f"Train no shuffle sessions: {train_ns_sessions}")
        print(f"Test no shuffle sessions : {test_ns_sessions}")
        print(f"Train shuffled sessions  : {train_s_sessions}")
        print(f"Test shuffle sessions    : {test_s_sessions}")

        # Track if indices are the same
        train_diff.append(np.array_equal(train_ns, train_s))
        test_diff.append(np.array_equal(test_ns, test_s))

        # Track session orders
        session_orders_no_shuffle.append(
            (list(train_ns_sessions), list(test_ns_sessions))
        )
        session_orders_shuffle.append((list(train_s_sessions), list(test_s_sessions)))

    # Check if indices are different in at least some folds
    assert not all(train_diff), "All train indices are identical despite shuffle"
    assert not all(test_diff), "All test indices are identical despite shuffle"

    # Check if session ordering is different
    session_order_differences = [
        not (
            np.array_equal(no_shuffle[0], shuffle[0])
            and np.array_equal(no_shuffle[1], shuffle[1])
        )
        for no_shuffle, shuffle in zip(session_orders_no_shuffle, session_orders_shuffle)
    ]

    assert any(session_order_differences), (
        "Session ordering is identical in all folds despite shuffle. "
        "When shuffle=True, we expect some difference in the session ordering."
    )


def test_cross_session_unique_subjects(data):
    _, y, metadata = data

    splitter_shuffle = CrossSessionSplitter(
        shuffle=True, random_state=3, cv_class=GroupShuffleSplit
    )
    splits_shuffle = list(splitter_shuffle.split(y, metadata))

    # Check if session splits are different across subjects
    subject_session_patterns = {}
    for i, (train_idx, test_idx) in enumerate(splits_shuffle):
        subject = metadata.iloc[train_idx]["subject"].iloc[
            0
        ]  # Get the subject for this fold
        if subject not in subject_session_patterns:
            subject_session_patterns[subject] = []

        train_sessions = set(metadata.iloc[train_idx]["session"].unique())
        test_sessions = set(metadata.iloc[test_idx]["session"].unique())
        subject_session_patterns[subject].append((train_sessions, test_sessions))

    # Verify that at least some subjects have different session splitting patterns
    pattern_differences = []
    subjects = list(subject_session_patterns.keys())
    for sub1, sub2 in zip(subjects, subjects[1:]):
        # Compare patterns for each subject pair
        patterns_differ = False
        for (train1, test1), (train2, test2) in zip(
            subject_session_patterns[sub1], subject_session_patterns[sub2]
        ):
            if train1 != train2 or test1 != test2:
                patterns_differ = True
                break
        pattern_differences.append(patterns_differ)

    assert any(
        pattern_differences
    ), "Session splitting patterns are identical across all subjects"


@pytest.mark.parametrize("shuffle, random_state", [(True, 0), (True, 42), (False, None)])
def test_cross_session_unique_sessions(shuffle, random_state, data):
    _, y, metadata = data
    if shuffle:
        split = CrossSessionSplitter(
            shuffle=shuffle, random_state=random_state, cv_class=GroupShuffleSplit
        )
    else:
        split = CrossSessionSplitter(shuffle=shuffle, random_state=random_state)

    splits = list(split.split(y, metadata))

    for i, (train, test) in enumerate(splits):
        train_sessions = metadata.iloc[train]["session"].unique()
        test_sessions = metadata.iloc[test]["session"].unique()
        assert not np.intersect1d(
            train_sessions, test_sessions
        ).size, f"Fold {i} train and test sessions overlap"


@pytest.mark.parametrize("shuffle", [True, False])
def test_cross_session_get_n_splits(data, shuffle):
    _, y, metadata = data
    if shuffle:
        split = CrossSessionSplitter(shuffle=shuffle, cv_class=GroupShuffleSplit)
    else:
        split = CrossSessionSplitter()

    n_splits = split.get_n_splits(metadata)
    assert n_splits == 5 * 5  # 5 subjects, 5 sessions each


def test_cross_subject_get_n_splits(data):
    _, y, metadata = data

    split = CrossSubjectSplitter()

    n_splits = split.get_n_splits(metadata)
    assert n_splits == 5  # 5 subjects


def test_cross_dataset_get_n_splits(data):
    _, y, metadata = data
    metadata = _metadata_with_dataset_column(metadata)

    split = CrossDatasetSplitter()

    n_splits = split.get_n_splits(metadata)
    assert n_splits == metadata["dataset"].nunique()


def test_within_subject_get_n_splits(data):
    _, y, metadata = data

    split = WithinSubjectSplitter()

    n_splits = split.get_n_splits(metadata)
    assert n_splits == 5 * 5  # 5 subjects, 5 folds each


@pytest.mark.parametrize(
    "splitter", [CrossSessionSplitter, CrossSubjectSplitter, CrossDatasetSplitter]
)
def test_if_split_is_not_random(data, splitter):
    _, y, metadata = data
    if splitter == CrossDatasetSplitter:
        metadata = _metadata_with_dataset_column(metadata)

    if splitter == CrossSessionSplitter:
        split = splitter(shuffle=True, random_state=42, cv_class=GroupShuffleSplit)
    else:
        split = splitter(random_state=42, cv_class=GroupShuffleSplit)

    splits = list(split.split(y, metadata))
    splits_2 = list(split.split(y, metadata))

    for (train, test), (train_2, test_2) in zip(splits, splits_2):
        print(f"Train: {train}")
        print(f"Test: {test}")
        print(f"Train 2: {train_2}")
        print(f"Test 2: {test_2}")
        assert np.array_equal(train, train_2)
        assert np.array_equal(test, test_2)


@pytest.mark.parametrize(
    "cv_class",
    [
        LeaveOneGroupOut,
        TimeSeriesSplit,
        # GroupKFold, changed behavior within scikit-learn 1.6
        LeaveOneOut,
        LeavePGroupsOut,
        LeavePOut,
    ],
)
def test_raise_error_on_invalid_cv_class(cv_class):
    with pytest.raises(ValueError):
        CrossSessionSplitter(shuffle=True, cv_class=cv_class)


@pytest.mark.parametrize(
    "cv_class",
    [
        GroupShuffleSplit,
        StratifiedKFold,
        KFold,
        RepeatedKFold,
        RepeatedStratifiedKFold,
        ShuffleSplit,
        StratifiedGroupKFold,
        StratifiedShuffleSplit,
    ],
)
def test_cross_session_splitter_without_error(
    cv_class,
):
    splitter = CrossSessionSplitter(shuffle=True, cv_class=cv_class)
    assert splitter is not None
    assert isinstance(splitter, CrossSessionSplitter)


def test_learning_curve_splitter_metadata():
    y = np.array([0, 1] * 10)
    data_size = {"policy": "ratio", "value": np.array([0.5, 1.0])}
    n_perms = np.array([2, 1])
    splitter = LearningCurveSplitter(
        data_size=data_size, n_perms=n_perms, test_size=0.2, random_state=0
    )

    splits = list(splitter.split(np.arange(len(y)), y))
    assert len(splits) == int(np.sum(n_perms))

    for _train, _test in splits:
        meta = splitter.get_metadata()
        assert meta["data_size"] is not None
        assert meta["permutation"] is not None


@pytest.mark.parametrize(
    "splitter",
    [
        WithinSessionSplitter,
        WithinSubjectSplitter,
        CrossSessionSplitter,
        CrossSubjectSplitter,
        CrossDatasetSplitter,
    ],
)
def test_learning_curve_as_cv_class(splitter, data):
    """Test that LearningCurveSplitter can be used as cv_class for all splitters."""
    _, y, metadata = data
    if splitter == CrossDatasetSplitter:
        metadata = _metadata_with_dataset_column(metadata)

    data_size = {"policy": "ratio", "value": np.array([0.5, 1.0])}
    n_perms = np.array([2, 1])

    # CrossSessionSplitter requires shuffle=True when using random_state
    extra_kwargs = {}
    if splitter == CrossSessionSplitter:
        extra_kwargs["shuffle"] = True

    split = splitter(
        cv_class=LearningCurveSplitter,
        data_size=data_size,
        n_perms=n_perms,
        test_size=0.2,
        random_state=42,
        **extra_kwargs,
    )

    splits = list(split.split(y, metadata))
    assert len(splits) > 0

    for train, test in splits:
        # Check that we get valid train/test indices
        assert len(train) > 0
        assert len(test) > 0
        # Check no overlap between train and test
        assert len(set(train) & set(test)) == 0
        if splitter == CrossSessionSplitter:
            train_meta = metadata.loc[train]
            test_meta = metadata.loc[test]
            train_subjects = set(train_meta["subject"])
            test_subjects = set(test_meta["subject"])
            assert len(train_subjects) == 1
            assert train_subjects == test_subjects
            train_sessions = set(train_meta["session"])
            test_sessions = set(test_meta["session"])
            assert train_sessions.isdisjoint(test_sessions)
        elif splitter == CrossSubjectSplitter:
            train_subjects = set(metadata.loc[train]["subject"])
            test_subjects = set(metadata.loc[test]["subject"])
            assert train_subjects.isdisjoint(test_subjects)
        elif splitter == CrossDatasetSplitter:
            train_datasets = set(metadata.loc[train]["dataset"])
            test_datasets = set(metadata.loc[test]["dataset"])
            assert train_datasets.isdisjoint(test_datasets)


@pytest.mark.parametrize(
    "splitter_cls",
    [
        WithinSessionSplitter,
        WithinSubjectSplitter,
        CrossSessionSplitter,
        CrossSubjectSplitter,
        CrossDatasetSplitter,
    ],
)
def test_splitter_metadata_interface(splitter_cls, data):
    """Test get_metadata() access for splitters using metadata-aware inner CV."""
    _, y, metadata = data
    if splitter_cls == CrossDatasetSplitter:
        metadata = _metadata_with_dataset_column(metadata)

    data_size = {"policy": "ratio", "value": np.array([0.5, 1.0])}
    n_perms = np.array([2, 1])

    extra_kwargs = {}
    if splitter_cls == CrossSessionSplitter:
        extra_kwargs["shuffle"] = True

    split = splitter_cls(
        cv_class=LearningCurveSplitter,
        data_size=data_size,
        n_perms=n_perms,
        test_size=0.2,
        random_state=42,
        **extra_kwargs,
    )

    has_split = False
    for _train, _test in split.split(y, metadata):
        has_split = True
        meta = split.get_metadata()
        assert meta is not None
        assert meta["data_size"] is not None
        assert meta["permutation"] is not None
    assert has_split


def test_cross_dataset_requires_group_column(data):
    _, y, metadata = data
    splitter = CrossDatasetSplitter(group_column="does_not_exist")
    with pytest.raises(ValueError):
        list(splitter.split(y, metadata))
