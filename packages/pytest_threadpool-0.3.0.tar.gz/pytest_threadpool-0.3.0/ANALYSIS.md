# pytest-threadpool: Risk, Bug & Test Gap Analysis

## Overview

pytest-threadpool runs test bodies and function-scoped fixture setup in parallel via a thread pool while keeping shared fixtures (module/class/session scope) and teardown sequential. Function-scoped FixtureDefs are cloned per-item so each worker creates independent fixture instances. This analysis covers risks, potential bugs, and missing test coverage.

---

## Potential Bugs

### 1. ~~Empty `callable_items` after setup failures~~ [RESOLVED — Not a bug]

**Debunked.** When `callable_items` is empty, `workers = 1` (line 365). The guard on line 409 (`if workers > 1 and len(callable_items) > 1`) prevents `ThreadPoolExecutor` creation — execution falls through to the `else` branch (lines 427–431), which iterates over the empty list harmlessly. Phase 3 then correctly reports setup failures via `_report_item`. No unnecessary thread pool is created and no misleading output is produced.

### 2. ~~`_do_call` exception swallowing~~ [RESOLVED — Not a bug]

**Debunked.** When `future.exception()` is not None (lines 416–422), the exception is wrapped in a `CallInfo` via `CallInfo.from_call()` and stored in `call_results[item]`. Then `_report_item(item)` is called immediately (line 426), which builds a report via `pytest_runtest_makereport` and fires `pytest_runtest_logreport` — properly recording it as a test failure in pytest's statistics. Exceptions are not swallowed; they follow the standard reporting path.

### 3. ~~Fixture finalizer ordering after restore~~ [RESOLVED — Not a bug]

**Debunked.** `save_and_clear_function_fixtures()` uses `saved.extend(fixturedef._finalizers)` iterating over `request._fixture_defs.values()`. Since Python 3.7+ dicts preserve insertion order (matching fixture resolution/setup order), and `_teardown_all` runs `for fn in reversed(fns)`, the result is correct LIFO ordering: later-resolved fixtures' finalizers run first, and within each fixture, finalizers run in reverse registration order — matching pytest's normal teardown semantics.

### 4. ~~`sys.modules` iteration in `MarkerResolver.package_scope()`~~ [RESOLVED — Not a bug]

**Debunked.** The code uses `sys.modules.get(pkg)` (line 76 of `_markers.py`) — a single-key dict lookup, not iteration. The analysis incorrectly claims the code "iterates `sys.modules`." Furthermore, `package_scope()` is only called during `GroupKeyBuilder.group_key()`, which runs during the sequential collection/grouping phase before any parallel execution begins. No thread-safety concern exists.

### 5. ~~`_initrequest()` side effects~~ [RESOLVED — Not a bug, duplicate of Risk #1]

**Debunked as a standalone bug.** The `_initrequest()` call mirrors pytest's own `runtestprotocol` in `_pytest/runner.py`. It's the standard way to initialize the request lifecycle for an item. The concern about private API stability is valid but is already covered under Risk #1 (heavy reliance on pytest private API). This is a maintenance risk, not a bug.

---

## Risks

### 1. Heavy reliance on pytest private API (HIGH)

The plugin accesses numerous protected members:
- `item._request` / `item._initrequest()`
- `request._fixture_defs`
- `session._setupstate.stack`
- `fixturedef._scope`, `._finalizers`, `.cached_result`
- `TerminalReporter._tw`

**Impact**: Any pytest minor release could break the plugin silently. No compatibility layer or version detection exists beyond `pytest >= 9.0.2`.

### 2. No free-threaded runtime validation (MEDIUM)

The plugin doesn't verify that it's running on free-threaded Python (`PYTHON_GIL=0` or 3.14t+). If run on a GIL-enabled build, tests will execute but without true parallelism, potentially masking concurrency bugs in user code that only manifest under real parallelism.

### 3. Single lock for all terminal output (MEDIUM)

`_LiveReporter` uses one `threading.Lock()` for state updates. The lock protects `_item_state` mutations but doesn't protect the actual terminal write operations in `_render()`. If `_render()` is called from the main thread while a worker thread calls `mark_done()`, the render could read partially-updated state.

### 4. ANSI escape sequence fragility (LOW)

The live reporter uses raw ANSI cursor movement (`\033[F`, `\033[K`) for in-place updates. This assumes:
- Terminal supports ANSI sequences
- No other output is written to stdout during rendering
- Line count calculations are accurate

Broken assumptions produce garbled terminal output.

### 5. Hardcoded barrier timeouts in tests (LOW)

Test cases use `threading.Barrier(N, timeout=10)`. On slow CI or high-contention environments, this could cause flaky test failures that look like concurrency bugs but are just timeout issues.

### 6. ~~No signal/interrupt handling during parallel phase~~ [RESOLVED]

Replaced ThreadPoolExecutor with a daemon-thread worker pool. On SIGINT, pending work items are abandoned (daemon threads exit with the process), fixture teardown still runs, and KeyboardInterrupt is re-raised for pytest's handler.

---

## Missing Tests

### Error & Edge Cases
- [x] Test body raises `SystemExit` or `KeyboardInterrupt` during parallel execution — tested, both caught and reported as failures
- [x] All tests in a parallel group fail during setup (empty `callable_items`) — tested + fixed cached error leak
- [x] Mixed setup pass/fail within a single parallel group — tested + fixed cached error leak
- [ ] Non-pickleable objects in test state during parallel batches
- [x] SIGINT during parallel execution phase — fixed with daemon-thread pool, exits promptly
- [ ] Test that modifies `sys.modules` during parallel execution

### Fixture Scenarios
- [x] Fixtures with interdependent finalizers (finalizer A must run before finalizer B) — tested, LIFO ordering correct
- [x] `autouse` fixtures with function scope in parallel groups — tested, works correctly
- [x] Fixture teardown that raises exceptions in parallel groups — tested + fixed to run all finalizers
- [ ] Complex fixture parameter combinations where scope changes mid-group
- [ ] `yield` fixtures with cleanup that depends on execution order

### Scope & Grouping
- [ ] Deeply nested packages (3+ levels) with mixed marker inheritance
- [x] Dynamic parametrize (e.g., `pytest_generate_tests`) with parallel markers — tested + fixed grouping bug
- [x] Groups where all items have `not_parallelizable` — verify no thread pool created — tested, runs on MainThread
- [ ] Very large groups (100+ tests) to verify thread pool scaling

### Reporting
- [ ] Mixed verbosity flags (`-v`, `-vv`, `-q`) with parallel output
- [ ] `--tb=long` / `--tb=short` with parallel test failures
- [ ] ~~Captured stdout/stderr from parallel tests~~ — capsys is process-global, incompatible with parallel execution by design
- [ ] `--no-header` and other output-modifying flags
- [ ] Plugin interaction with `pytest-xdist` (should error or warn)

### Compatibility
- [ ] Python 3.13t with explicit `PYTHON_GIL=0`
- [ ] pytest version matrix (9.0.2, 9.1.x, 9.2.x, 10.x)
- [ ] Interaction with common plugins (`pytest-cov`, `pytest-timeout`, `pytest-randomly`)

### Concurrency Stress
- [ ] High thread count (16, 32, 64 threads) with many small tests
- [x] Tests that themselves spawn threads (nested parallelism) — tested, works correctly
- [ ] Tests with heavy I/O (file writes to same directory) in parallel
- [ ] Memory pressure: many parallel tests allocating large objects

---

## Summary

| Category | Count | Status |
|----------|-------|--------|
| Potential bugs | 5 | **All 5 debunked** — none were actual bugs |
| Risks | 6 | 1 high, 3 medium, 2 low (unchanged) |
| Missing test areas | 25+ | Mixed (unchanged) |

All five "potential bugs" were investigated and found to be incorrect or misleading claims. The code handles each scenario correctly. The highest-priority item remains the **dependency on pytest private API** (Risk #1). The second priority is adding **error/edge-case tests** for parallel execution failures.


  ┌─────┬───────────────────────────────────────────┬─────────────────────────────────────────────────────────────────────────────────────────────┬───────────────────────────────────────────────┐
  │  #  │                   Risk                    │                                            Real?                                            │                   Fixable?                    │
  ├─────┼───────────────────────────────────────────┼─────────────────────────────────────────────────────────────────────────────────────────────┼───────────────────────────────────────────────┤
  │ 1   │ Private API reliance                      │ True — inherent to approach                                                                 │ No code fix possible — it's a design tradeoff │
  ├─────┼───────────────────────────────────────────┼─────────────────────────────────────────────────────────────────────────────────────────────┼───────────────────────────────────────────────┤
  │ 2   │ No free-threaded runtime validation       │ True — but by design                                                                        │ Feature request, not a bug                    │
  ├─────┼───────────────────────────────────────────┼─────────────────────────────────────────────────────────────────────────────────────────────┼───────────────────────────────────────────────┤
  │ 3   │ Single lock / unprotected terminal writes │ False — _render() doesn't exist; both mark_running and mark_done hold the lock when writing │ N/A                                           │
  ├─────┼───────────────────────────────────────────┼─────────────────────────────────────────────────────────────────────────────────────────────┼───────────────────────────────────────────────┤
  │ 4   │ ANSI escape fragility                     │ True — already mitigated by plain-mode fallback                                             │ Low severity, no fix needed                   │
  ├─────┼───────────────────────────────────────────┼─────────────────────────────────────────────────────────────────────────────────────────────┼───────────────────────────────────────────────┤
  │ 5   │ Hardcoded barrier timeouts                │ True — test-only concern                                                                    │ Low severity, no production code affected     │
  ├─────┼───────────────────────────────────────────┼─────────────────────────────────────────────────────────────────────────────────────────────┼───────────────────────────────────────────────┤
  │ 6   │ No SIGINT handling                        │ True — ThreadPoolExecutor provides basic cleanup but Phase 4 teardown is skipped            │ Feature request, not a bug                    │
  └─────┴───────────────────────────────────────────┴─────────────────────────────────────────────────────────────────────────────────────────────┴───────────────────────────────────────────────┘

