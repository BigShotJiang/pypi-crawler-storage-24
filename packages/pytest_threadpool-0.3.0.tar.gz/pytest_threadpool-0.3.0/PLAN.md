Must-have
1. Publish a real compatibility matrix
Add a table to README.md covering at least:
Python versions supported
pytest versions supported
whether support requires free-threaded builds
whether each combo is:
supported
tested
experimental
unsupported
Example shape: ```markdown
| Python | Build type      | pytest | Status       |
|--------|------------------|--------|--------------|
| 3.14t  | free-threaded    | 8.x    | supported    |
| 3.13t  | free-threaded    | 8.x    | supported    |
| 3.14   | regular GIL build| 8.x    | unsupported  |
```

Why this matters:
removes guesswork
makes breakage attributable
gives users confidence you know your support surface
 
2. Add CI that proves the matrix
Production-grade means “supported” is not just a vibe.
At minimum, automate:
multiple Python versions
multiple pytest versions if feasible
Linux at least
normal run and --threadpool run
a smoke test for installation as a package
Since this project uses uv, keep setup aligned with that.
Good CI checks would include:``` bash
uv sync
uv run pytest -v
uv run pytest --threadpool auto
```

Bonus points:
fail on warnings from your own package
run a small repeated stress subset multiple times
 
3. Write a “guarantees and non-goals” section
This is probably the single highest-value documentation addition.
You want one section that explicitly says:
Guarantees
test call phases may run concurrently
function-scoped fixture setup runs in parallel (cloned per-item)
shared fixture setup/teardown (module/class/session) remains sequential
unmarked tests remain sequential
not_parallelizable always wins
marker precedence rules are stable
Non-goals
not all pytest plugins are guaranteed compatible
not all tests benefit from parallel execution
shared mutable state in user tests is not automatically made safe
not intended to replace process-based isolation tools
That turns the project from “interesting” to “predictable”.
 
4. Add an explicit plugin compatibility policy
This can start small.
Add a table like:``` markdown
| Plugin / feature      | Status        | Notes |
|-----------------------|---------------|-------|
| pytest built-ins      | supported     | core target |
| junitxml              | unverified    | needs CI coverage |
| coverage integration  | unverified    | behavior may depend on backend |
| pytest-xdist          | unsupported   | overlapping execution models |
| custom runtest hooks  | caution       | may depend on hook assumptions |
```

Important:
You do not need every answer to be “supported”.
You just need the answers to exist.
That alone makes the project feel much more responsible.
 
5. Add a debug/trace mode
A concurrency plugin needs explainability.
A flag like this would help a lot:``` bash
pytest --threadpool auto --threadpool-debug
```

Useful output would include:
resolved thread count
effective marker source per item
why a test was sequential
group key per item
batch size and worker count
setup/call/teardown phase transitions
maybe a summary of batches
This is one of the biggest practical upgrades for maintainers and adopters.
 
Should-have
6. Harden failure-mode behavior and document it
You want tests and docs for cases like:
setup fails for one item in a parallel batch
teardown fails after successful calls
multiple teardown failures
one test errors while others are still running
session stop / fail-fast semantics
keyboard interrupt behavior
collection errors with --threadpool
Even if the implementation is already decent, the maturity jump comes from making these behaviors:
intentional
documented
regression-tested
A production tool should answer:
“What exactly happens if three things go wrong at once?” 
7. Add stress/repeat tests for race sensitivity
Right now the suite looks thoughtful, but I’d add a dedicated stress layer.
Examples:
repeat selected parallel tests 25–100 times
random sleep durations
mixed fast/slow tests
repeated setup/call/teardown interactions
randomized pass/fail/skip in one group
large batches with many items
tests specifically designed to catch ordering/reporting regressions
You don’t need a giant benchmark lab.
You do need evidence that the plugin survives timing variation.
 
8. Define and freeze the public API
Before 1.0, decide what is stable:
package exports from pytest_threadpool
marker names
scope strings / enum values
CLI flags
precedence behavior
skip behavior for parallel_only
Then document that as public contract.
Also document what is not public:
underscored modules
internal grouping keys
runner internals
fixture state choreography
The user should know what they’re allowed to rely on.
 
Nice-to-have but maturity-boosting
9. Add operational docs: “when to use” and “when not to use”
A practical page in the README or docs:
Good fit
CPU-bound tests on free-threaded Python
tests whose call bodies are independent
suites where process-based parallelism is too heavy
Bad fit
tests sharing mutable global state
tiny tests where overhead dominates
suites depending on plugins with incompatible execution assumptions
tests requiring strict sequential side effects
This kind of guidance is very production-minded. It helps teams self-select correctly.
 
10. Add lightweight performance guidance
Even just a short section would help:
what “auto” means
when explicit thread counts are better
expected benefit profile
why fixture-heavy suites may see limited speedup
warning that more threads is not always better
Users don’t need a PhD thesis.
They need enough to avoid cargo-culting --threadpool 64.
 
My recommended release checklist
If I were driving this to 1.0, I’d use this exact gating list.
Blockers for 1.0
compatibility matrix documented
CI validates supported combinations
guarantees / non-goals documented
plugin compatibility policy documented
public API surface documented
debug/trace mode implemented
failure-mode tests expanded
repeated stress tests added
Strongly recommended
changelog exists
semantic versioning policy stated
known limitations section in README
“when not to use” guidance added
performance expectations documented
 
If you want the most leverage, do these first
Here’s the highest ROI order:
Phase 1 — trust
compatibility matrix
CI matrix
guarantees/non-goals
plugin compatibility table
Phase 2 — supportability
debug flag
failure-mode tests
stress/repeat tests
Phase 3 — product maturity
public API policy
versioning/changelog
performance + operational docs
 
My honest ranking of what matters most
If you only did three things, I’d choose:
1. Compatibility + CI
Because “supported” without proof is decoration.
2. Guarantees / non-goals
Because concurrency tools need a crisp contract.
3. Debug mode
Because once users try this on real suites, they will ask why something grouped, skipped, or stayed sequential.
 
One thing I’d watch especially closely
Because this project likely relies on internal pytest behavior, I would treat upstream compatibility drift as a first-class product concern, not an afterthought.
That means:
pinning or testing version ranges carefully
documenting break/fix expectations
being conservative about claiming support
That’s not a weakness. For a tool like this, that’s professionalism.
 
Bottom line
To reach 1.0, this repo doesn’t mainly need “more cleverness.”
It needs more contract, more proof, and more observability.
That is what makes a concurrency framework feel like an instrument instead of an experiment.
If you want, I can next turn this into a repo-specific action plan with concrete suggested edits for:
README.md
CONTRIBUTING.md
pyproject.toml
a new tests/test_pytester_failures.py
a new debug flag in plugin.py / _runner.py