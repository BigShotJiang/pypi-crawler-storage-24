# TODO — Road to Beta and Beyond

## 1.0 Requirements

### Phase 1 — Trust (Highest ROI)
- [ ] Publish compatibility matrix in README (Python versions, pytest versions, platform, status)
- [ ] CI validates all supported combinations
- [ ] Write "Guarantees & Non-Goals" section in README
- [ ] Document plugin compatibility policy (xdist, cov, timeout, etc.)

### Phase 2 — Supportability
- [ ] Implement `--threadpool-debug` flag (resolved thread count, effective marker source, group keys, phase transitions)
- [ ] Expand failure-mode tests (multiple teardown failures, concurrent errors, collection errors with --threadpool)
- [ ] Add stress/repeat tests (25-100x repeats, random sleep durations, large batches, mixed fast/slow)

### Phase 3 — Product Maturity
- [ ] Define and freeze public API (exports, marker names, scope strings, CLI flags, precedence behavior)
- [ ] Add changelog
- [ ] State semantic versioning policy
- [ ] Write "When to use / When not to use" guidance
- [ ] Add performance tuning docs (what "auto" means, when explicit thread counts help, fixture-heavy suite caveats)

---

## Stretch / Nice-to-Have
- [ ] Test deeply nested packages (3+ levels)
- [ ] Test very large groups (100+ items)
- [ ] Test mixed verbosity flags (-v, -vv, -q)
- [ ] Test --no-header and output-modifying flags
- [ ] Test high thread count stress (16-64 threads)
- [ ] Test memory pressure / large object allocation
- [ ] Test plugin interactions (pytest-cov, pytest-timeout, pytest-randomly)
