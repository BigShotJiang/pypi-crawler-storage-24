# Continuous Sampling Module

::: lonkit.continuous.sampling.compute_lon
    options:
      show_root_heading: true
      show_source: true

::: lonkit.continuous.sampling.BasinHoppingSamplerConfig
    options:
      show_root_heading: true
      show_source: true

::: lonkit.continuous.sampling.BasinHoppingSampler
    options:
      show_root_heading: true
      show_source: true
      members:
        - sample
        - sample_to_lon

::: lonkit.continuous.sampling.BasinHoppingResult
    options:
      show_root_heading: true
      show_source: true

## Step Size Estimation

::: lonkit.continuous.step_size.StepSizeEstimatorConfig
    options:
      show_root_heading: true
      show_source: true

::: lonkit.continuous.step_size.StepSizeEstimator
    options:
      show_root_heading: true
      show_source: true

::: lonkit.continuous.step_size.StepSizeResult
    options:
      show_root_heading: true
      show_source: true
