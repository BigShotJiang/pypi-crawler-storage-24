import abc
import os
import zipfile
from collections.abc import Generator
from contextlib import contextmanager
from gzip import GzipFile
from io import TextIOWrapper
from pathlib import Path
from typing import Any

from fastapi import Query
from progress.bar import Bar
from pydantic import BaseModel, Field


class Term(BaseModel):
    lexicon: str | None = Field(None, description="Lexicon of the term", json_schema_extra={"example": "MeSH"})
    identifier: str = Field(
        ...,
        description="Unique identifier of the term",
        json_schema_extra={"example": "http://www.example.com/rocks"},
    )
    preferredForm: str | None = Field(
        None, description="The preferred label of the term", json_schema_extra={"example": "rocks"}
    )
    properties: dict[str, Any] | None = Field(
        None,
        description="Additional properties of the term",
        json_schema_extra={"example": {"altForms": ["basalt", "granite", "slate"], "wikidataId": "Q8063"}},
    )


class KnowledgeParserOptions(BaseModel):
    project: str | None = Query(None, description="Name of the project", json_schema_extra={"extra": "internal"})
    lexicon: str | None = Query(
        None, description="Lexicon to inject the terms", json_schema_extra={"extra": "internal"}
    )
    lang: str = Query("en", description="Language of the project", json_schema_extra={"extra": "internal"})
    limit: int = Query(
        0, description="Number of terms to import. 0 means all", ge=0, json_schema_extra={"extra": "advanced"}
    )


KnowledgeParserModel = KnowledgeParserOptions


class KnowledgeParserBase(metaclass=abc.ABCMeta):
    """Base class for example plugin used in the tutorial."""

    def __init__(self):  # noqa: B027
        pass

    @abc.abstractmethod
    def parse(
        self,
        source: Path,
        options: KnowledgeParserOptions | dict[str, Any],
        bar: Bar,
    ) -> Generator[Term, None, None]:
        """Parse the input source file and return a stream of concepts.

        :param source: A file object containing the knowledge.
        :param options: options of the parser.
        :param bar: progress bar
        :returns: Iterable producing the concepts.
        """

    @classmethod
    def get_schema(cls) -> type[KnowledgeParserOptions]:
        return KnowledgeParserOptions

    @classmethod
    def get_model(cls) -> type[BaseModel]:
        return KnowledgeParserModel

    @classmethod
    def get_extensions(cls) -> list[str]:
        return []


@contextmanager
def maybe_archive(source: Path, mode="r", encoding="utf-8"):
    try:
        archive = None
        file = None
        guessed = None
        if source.suffix == ".gz":
            guessed = "gzip"
        elif source.suffix == ".zip":
            guessed = "zip"
        else:
            if zipfile.is_zipfile(source):
                guessed = "zip"
            if is_gzipfile(source):
                guessed = "gzip"
        if guessed == "gzip":
            file = GzipFile(str(source), mode=mode)
        elif guessed == "zip":
            archive = zipfile.ZipFile(str(source))
            if "[Content_Types].xml" in archive.NameToInfo:
                # This is not a real zip file but a xlsx file
                archive.close()
                archive = None
                guessed = None
            else:
                if len(archive.filelist) == 1:
                    file = (
                        archive.open(archive.filelist[0])
                        if "b" in mode
                        else TextIOWrapper(archive.open(archive.filelist[0]), encoding=encoding)
                    )
                else:
                    file = archive
        if file is None:
            file = source.open(mode) if "b" in mode else source.open(mode, encoding=encoding)
        yield file
    finally:
        if file:
            file.close()
        if archive:
            archive.close()


def is_gzipfile(filename):
    """
    This function attempts to ascertain the gzip status of a file based on the "magic signatures" of
    the file. This was taken from the stack overflow
    http://stackoverflow.com/questions/13044562/python-mechanism-to-identify-compressed-file-type\
        -and-uncompress
    """
    assert os.path.exists(filename), f"Input {filename} does not " + "point to a file."
    with open(filename, "rb") as in_f:
        start_of_file = in_f.read(3)
        return start_of_file == b"\x1f\x8b\x08"
