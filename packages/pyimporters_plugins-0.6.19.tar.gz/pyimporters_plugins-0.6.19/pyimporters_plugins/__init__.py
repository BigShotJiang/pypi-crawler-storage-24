"""Sherpa knowledge import plugins"""

__version__ = "0.6.19"
