import importlib.metadata


APP_NAME = "zalando-kubectl"

KUBECTL_VERSION = "v1.34.4"
KUBECTL_SHA512 = {
    "linux": "018d0a75b74b55942a0777afc7edf64ca98c004e6e12f9dc93ad75c26cb58089104ba0f9ceae2f0be5a6f6854948c705b0eb828f0960302a0ff84d57c464fc09",
    "darwin": "d54016baa54cf847d68b56bee5f73f8453e2f7ea2fade04fb0a2dd4dabb2ac343e604d2ceae48fb16338c6fb4d92a6eb46b4294dda54500fc93800992a6c1c1d",
}
STERN_VERSION = "1.30.0"
STERN_SHA256 = {
    "linux": "ea1bf1f1dddf1fd4b9971148582e88c637884ac1592dcba71838a6a42277708b",
    "darwin": "4eaf8f0d60924902a3dda1aaebb573a376137bb830f45703d7a0bd89e884494a",
}
KUBELOGIN_VERSION = "v1.35.2"
KUBELOGIN_SHA256 = {
    "linux": "40ccbc12a9d47ad6416ac111cbc895ed01d3cf2cad33454f1d3a035d6c21135a",
    "darwin": "b342e08b9eab45a650907c2587e418569f715ed3ba47a67dc0a73ab8f180423e",
}
ZALANDO_AWS_CLI_VERSION = "1.1.2"
ZALANDO_AWS_CLI_SHA256 = {
    "linux": "d0dc1bbbab2a5c94d5e16aa8d90f38d40dc16c03fc552ed03c57871b6ec33c2c",
    "darwin": "baae4a2b2b738f34bfa7202eb56448ded76b8ef3cca1a8990f9f334978be63f2",
}

APP_VERSION = "v" + importlib.metadata.version(APP_NAME)
