import asyncio
import hashlib
import json
import random
import time
from abc import ABC, abstractmethod
from collections.abc import Callable
from dataclasses import dataclass, field
from functools import wraps
from pathlib import Path
from typing import Literal, ParamSpec, TypeVar

from donkit.llm import (
    ContentPart,
    ContentType,
    GenerateRequest,
    LLMModelAbstract,
    Message,
)
from loguru import logger

P = ParamSpec("P")
R = TypeVar("R")


@dataclass
class ImageAnalysisResult:
    """Result of an image analysis call, including token usage."""

    content: str
    usage: dict[str, int | None] | None = field(default=None)


@dataclass
class LLMUsageMetrics:
    """Aggregated LLM usage metrics for a reading operation."""

    total_llm_requests: int = 0
    total_prompt_tokens: int = 0
    total_completion_tokens: int = 0

    def add_usage(self, usage: dict[str, int | None] | None) -> None:
        self.total_llm_requests += 1
        if usage:
            self.total_prompt_tokens += usage.get("prompt_tokens") or 0
            self.total_completion_tokens += usage.get("completion_tokens") or 0


def retry_on_exception(
    max_retries: int = 3,
    initial_wait: float = 1.0,
    max_wait: float = 10.0,
    exceptions: tuple[type[Exception], ...] = (Exception,),
) -> Callable[[Callable[P, R]], Callable[P, R]]:
    """Retry a callable (sync or async) on specified exceptions with backoff.

    - Supports both sync and async functions.
    - Exponential backoff with randomized jitter.
    - Raises immediately on the final failed attempt.
    """

    def decorator(func: Callable[P, R]) -> Callable[P, R]:
        if asyncio.iscoroutinefunction(func):

            @wraps(func)
            async def async_wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
                last_exc: Exception | None = None
                for attempt in range(max_retries + 1):
                    try:
                        return await func(*args, **kwargs)  # type: ignore[misc]
                    except exceptions as e:  # type: ignore[misc]
                        last_exc = e
                        if attempt == max_retries:
                            logger.error(
                                f"All {max_retries} attempts failed. Last error: {e!s}"
                            )
                            raise
                        wait_time = min(
                            initial_wait * (2**attempt)
                            + random.uniform(0, 0.2 * initial_wait),
                            max_wait,
                        )
                        logger.warning(
                            f"Attempt {attempt + 1}/{max_retries} failed: {e!s}. "
                            f"Retrying in {wait_time:.2f}s"
                        )
                        await asyncio.sleep(wait_time)
                # Unreachable; for type-checkers
                assert last_exc is not None
                raise last_exc

            return async_wrapper  # type: ignore[return-value]

        @wraps(func)
        def sync_wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            last_exc: Exception | None = None
            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:  # type: ignore[misc]
                    last_exc = e
                    if attempt == max_retries:
                        logger.error(
                            f"All {max_retries} attempts failed. Last error: {e!s}"
                        )
                        raise
                    wait_time = min(
                        initial_wait * (2**attempt)
                        + random.uniform(0, 0.2 * initial_wait),
                        max_wait,
                    )
                    logger.warning(
                        f"Attempt {attempt + 1}/{max_retries} failed: {e!s}. "
                        f"Retrying in {wait_time:.2f}s"
                    )
                    time.sleep(wait_time)

            # Unreachable; for type-checkers
            assert last_exc is not None
            raise last_exc

        return sync_wrapper  # type: ignore[return-value]

    return decorator


DEFAULT_PROMPT: str = (
    "Analyze the document slide and extract ALL visible information in detail. "
    "Include all text, numbers, data points, labels, captions, titles, headers, footers, "
    "watermarks, logos, icons, charts, graphs, tables, diagrams, and any other visual elements. "
    "Describe layouts, positioning, and relationships between elements. "
    "Be extremely thorough and precise - do not summarize or omit any details."
)

# JSON-specific guidance (used only when output_format == 'json')
JSON_SCHEMA_PROMPT: str = (
    "Extract and structure all slide content in JSON format with the following keys: "
    '"title": extract the main slide title, '
    '"content": all body text preserving bullet points and hierarchical structure, '
    '"tables": format any tables as nested JSON arrays with column headers, '
    '"charts": describe any charts with type, data points, and trends, '
    '"images": brief descriptions of any non-chart images, '
    '"notes": any presenter notes or footnotes. '
    "Be extremely precise and concise. Avoid any commentary or subjective interpretation. "
    "Format response as a clean JSON object without line breaks or extra formatting."
)


# Additional formatting instructions by output format
def _format_instructions(output_format: Literal["json", "text", "md"]) -> str:
    if output_format == "json":
        return (
            " Return ONLY a valid JSON object. No markdown, no codeFences, no commentary. "
            "Ensure proper escaping and valid JSON syntax."
        )
    if output_format == "md":
        return """
            Return only Markdown. Do not include JSON or code fences with language tags (like ```json).
            Only use code fences if the image explicitly contains a code snippet."""
    return (
        " Provide a concise plain text summary. Do NOT use JSON or markdown. "
        "Use paragraphs and simple lists only if needed."
    )


def _build_prompt_for_format(
    base_prompt: str, output_format: Literal["json", "text", "md"]
) -> str:
    # Custom prompt passed externally — use as-is, no format overrides
    if base_prompt != DEFAULT_PROMPT:
        return base_prompt
    if output_format == "json":
        return f"{JSON_SCHEMA_PROMPT}\n{_format_instructions('json')}"
    # md or text get neutral base + their formatting rules
    return f"{DEFAULT_PROMPT}\n{_format_instructions(output_format)}"


# Cache configuration
CACHE_FILE = Path("image_cache.json")


class ImageAnalysisService(ABC):
    """Interface for image analysis operations."""

    @abstractmethod
    def analyze_image(
        self,
        encoded_image: str,
        prompt: str = DEFAULT_PROMPT,
        context: str | None = None,
    ) -> ImageAnalysisResult:
        """Analyze image content based on the provided prompt."""
        pass

    @abstractmethod
    async def aanalyze_image(
        self,
        encoded_image: str,
        prompt: str = DEFAULT_PROMPT,
        context: str | None = None,
    ) -> ImageAnalysisResult:
        """Async: Analyze image content based on the provided prompt."""
        pass

    @abstractmethod
    def call_text_only(self, prompt: str) -> ImageAnalysisResult:
        """Call the service with a text-only prompt."""
        pass


# Implementation classes
class FileBasedImageCache:
    """File-based implementation of image caching service."""

    def __init__(self, cache_file: Path = CACHE_FILE):
        self.cache_file = cache_file
        self._cache = self._load_cache()

    def _load_cache(self) -> dict[str, str]:
        if self.cache_file.exists():
            try:
                content = self.cache_file.read_text()
                if not content.strip():
                    return {}
                return json.loads(content)
            except Exception as e:
                logger.error(
                    f"Failed to load cache: {e}. Deleting corrupted cache file."
                )
                try:
                    self.cache_file.unlink()
                except Exception as unlink_error:
                    logger.error(f"Failed to delete corrupted cache: {unlink_error}")
        return {}

    def _save_cache(self) -> None:
        try:
            self.cache_file.write_text(
                json.dumps(self._cache, indent=4, ensure_ascii=False), encoding="utf-8"
            )
        except Exception as e:
            logger.error(f"Failed to save cache: {e}")

    def get_hash(self, image_bytes: bytes) -> str:
        return hashlib.md5(image_bytes).hexdigest()

    def get(self, image_hash: str) -> str | None:
        return self._cache.get(image_hash)

    def set(self, image_hash: str, content: str) -> None:
        if not image_hash:
            return
        self._cache[image_hash] = content
        self._save_cache()


class LLMImageAnalysisService(ImageAnalysisService):
    """Image analysis via unified LLM (donkit.models)."""

    def __init__(
        self,
        llm_model: LLMModelAbstract,
        cache_service: FileBasedImageCache | None = None,
        *,
        output_format: Literal["json", "text", "md"] = "json",
        max_tokens: int = 16384,
    ):
        self.cache_service = cache_service or FileBasedImageCache()
        self.model = llm_model
        self.max_tokens = max_tokens
        self.output_format: Literal["json", "text", "md"] = output_format

    @staticmethod
    def _build_messages(
        prompt: str, encoded_image: str, context: str | None = None
    ) -> list[Message]:
        messages: list[Message] = []
        if context:
            messages.append(Message(role="user", content=context))
        parts: list[ContentPart] = [
            ContentPart(
                content_type=ContentType.TEXT,
                content=prompt,
            ),
            ContentPart(
                content_type=ContentType.IMAGE_BASE64,
                content=encoded_image,
                mime_type="image/png",
            ),
        ]
        messages.append(Message(role="user", content=parts))
        return messages

    @retry_on_exception()
    def analyze_image(
        self,
        encoded_image: str,
        prompt: str = DEFAULT_PROMPT,
        context: str | None = None,
    ) -> ImageAnalysisResult:
        if self.cache_service:
            image_hash = self.cache_service.get_hash(encoded_image.encode())
            cached = self.cache_service.get(image_hash)
            if cached:
                return ImageAnalysisResult(content=cached, usage=None)
        prompt_for_format = _build_prompt_for_format(prompt, self.output_format)
        messages = self._build_messages(prompt_for_format, encoded_image, context)
        req = GenerateRequest(messages=messages, max_tokens=self.max_tokens)
        try:
            resp = asyncio.run(self.model.generate(req))
        except RuntimeError:
            loop = asyncio.new_event_loop()
            try:
                resp = loop.run_until_complete(self.model.generate(req))
            finally:
                loop.close()

        content = resp.content or ""
        usage = resp.usage
        if self.cache_service and content:
            image_hash = self.cache_service.get_hash(encoded_image.encode())
            self.cache_service.set(image_hash, content)
        return ImageAnalysisResult(content=content, usage=usage)

    @retry_on_exception()
    async def aanalyze_image(
        self,
        encoded_image: str,
        prompt: str = DEFAULT_PROMPT,
        context: str | None = None,
    ) -> ImageAnalysisResult:
        prompt_for_format = _build_prompt_for_format(prompt, self.output_format)
        image_hash = None
        # Cache key should include image + output format + prompt to avoid collisions
        if self.cache_service:
            key_material = (
                encoded_image + "|" + self.output_format + "|" + prompt_for_format
            ).encode("utf-8")
            image_hash = self.cache_service.get_hash(key_material)
            cached = self.cache_service.get(image_hash)
            if cached:
                return ImageAnalysisResult(content=cached, usage=None)

        messages = self._build_messages(prompt_for_format, encoded_image, context)
        req = GenerateRequest(
            messages=messages, max_tokens=self.max_tokens, temperature=0
        )
        resp = await self.model.generate(req)
        content = resp.content or ""
        usage = resp.usage
        if self.cache_service and content:
            # Store under the same composite key
            self.cache_service.set(image_hash, content)
        return ImageAnalysisResult(content=content, usage=usage)

    # @retry_on_exception()
    def call_text_only(self, prompt: str) -> ImageAnalysisResult:
        # Use model without image
        req = GenerateRequest(
            messages=[Message(role="user", content=prompt)], max_tokens=self.max_tokens
        )
        try:
            resp = asyncio.run(self.model.generate(req))  # type: ignore[arg-type]
        except RuntimeError:
            loop = asyncio.new_event_loop()
            try:
                resp = loop.run_until_complete(self.model.generate(req))  # type: ignore[arg-type]
            finally:
                loop.close()
        return ImageAnalysisResult(content=resp.content or "", usage=resp.usage)


def get_image_analysis_service(
    llm_model: LLMModelAbstract,
    cache_service: FileBasedImageCache | None = None,
    *,
    output_format: Literal["json", "text", "md"] = "json",
    max_tokens: int = 16384,
) -> LLMImageAnalysisService:
    return LLMImageAnalysisService(
        llm_model=llm_model,
        cache_service=cache_service,
        output_format=output_format,
        max_tokens=max_tokens,
    )
