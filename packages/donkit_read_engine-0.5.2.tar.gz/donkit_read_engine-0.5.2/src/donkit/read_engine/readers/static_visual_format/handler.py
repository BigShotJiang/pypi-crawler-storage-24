import base64

from ..static_visual_format.models import ImageAnalysisService


def image_read_handler(
    path: str,
    image_service: ImageAnalysisService,
) -> dict[str, list[dict[str, str | int]]]:
    """Processes and extracts information from an image file.

    :param path: Path to the image file
    :param image_service: Image analysis service instance
    :return: Structured content extracted from the image
    """
    with open(path, "rb") as image_file:
        image_bytes: bytes = base64.b64encode(image_file.read())
        encoded_image: str = image_bytes.decode("utf-8")

        result: str = image_service.analyze_image(encoded_image).content

        return {
            "content": [
                {
                    "page": 0,
                    "type": "Image",
                    "content": result,
                }
            ],
        }
