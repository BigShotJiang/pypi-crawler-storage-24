import asyncio
import base64
import errno
import gc
import json
import os
import pathlib
import re
import shutil
import stat
import tempfile
import time
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

import fitz
from json_repair import repair_json
from loguru import logger
from pydantic import BaseModel

from ..static_visual_format.models import ImageAnalysisService, LLMUsageMetrics


class PageContent(BaseModel):
    """Represents extracted content from a single PDF page."""

    page_num: int
    content: dict[str, Any] | str
    type: str = "Slide"


class PDFSplitter:
    """Splits PDF into individual pages."""

    @staticmethod
    def split(pdf_path: pathlib.Path, output_dir: pathlib.Path) -> None:
        """Split PDF into individual pages.

        Args:
            pdf_path: Path to PDF file
            output_dir: Directory to save page files
        """
        if output_dir.exists():
            safe_rmtree(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        document = fitz.open(pdf_path)
        try:
            for page_num in range(document.page_count):
                output_file = output_dir / f"page_{page_num + 1}.pdf"
                pdf_writer = fitz.open()
                try:
                    pdf_writer.insert_pdf(
                        document, from_page=page_num, to_page=page_num
                    )
                    pdf_writer.save(output_file)
                finally:
                    pdf_writer.close()
        finally:
            document.close()

    @staticmethod
    def get_sorted_pages(directory: pathlib.Path) -> list[str]:
        """Get sorted list of page files."""

        def extract_page_number(filename: str) -> int:
            match = re.search(r"page_(\d+)\.pdf", filename)
            return int(match.group(1)) if match else 0

        return sorted(os.listdir(directory), key=extract_page_number)


class PageProcessor:
    """Processes individual PDF pages."""

    def __init__(self, image_service: ImageAnalysisService):
        """Initialize page processor.

        Args:
            image_service: Image analysis service instance for LLM-based processing
        """
        self.image_service = image_service

    def process(self, page_path: str, page_num: int) -> PageContent:
        """[DEPRECATED] Sync processing is disabled. Use aprocess()."""
        raise NotImplementedError("Sync PDF processing is removed. Use aprocess().")

    async def aprocess(
        self, page_path: str, page_num: int
    ) -> tuple[PageContent, float, float, dict[str, int | None] | None]:
        """Async: Process a single PDF page.

        Returns:
            (PageContent, rasterize_s, gc_s, usage)
        """
        try:
            encoded_image, rasterize_s, gc_s = self._page_to_image(page_path)

            analysis_result = await self.image_service.aanalyze_image(encoded_image)
            raw_data = analysis_result.content
            usage = analysis_result.usage

            logger.debug(
                f"Parsing page {page_num}: raw_type={type(raw_data).__name__}, sample={(raw_data[:200] if isinstance(raw_data, str) else str(raw_data))[:200]}"
            )
            parsed_content = self._parse_output(raw_data, page_num)
            logger.debug(
                f"Parsed page {page_num}: parsed_type={type(parsed_content).__name__}"
            )

            return (
                PageContent(page_num=page_num, content=parsed_content),
                rasterize_s,
                gc_s,
                usage,
            )
        except Exception as e:
            logger.error("Error processing page {}: {}", page_num, e, exc_info=True)
            raise RuntimeError(f"Failed to process page {page_num}: {e}") from e

    @staticmethod
    def _page_to_image(page_path: str) -> tuple[str, float, float]:
        """Convert PDF page to base64-encoded image.

        Returns:
            (encoded_image, rasterize_s, gc_s)
        """
        document = fitz.open(page_path)
        try:
            fitz.TOOLS.set_aa_level(1)
            dpi = 85
            scale = dpi / 72
            mat = fitz.Matrix(scale, scale)

            t0 = time.monotonic()
            page = document[0]
            pix = page.get_pixmap(colorspace=fitz.csGRAY, alpha=False, matrix=mat)
            png_bytes = pix.tobytes("png")
            encoded_image = base64.b64encode(png_bytes).decode("ascii")
            rasterize_s = time.monotonic() - t0
        finally:
            document.close()
            t0 = time.monotonic()
            gc.collect()
            gc_s = time.monotonic() - t0
        return encoded_image, rasterize_s, gc_s

    @staticmethod
    def _parse_output(raw_data: str | dict, page_num: int) -> dict[str, Any] | str:
        """Parse model output into structured format."""
        if isinstance(raw_data, dict):
            return raw_data

        if not isinstance(raw_data, str):
            logger.warning(
                f"Unexpected data type for page {page_num}: {type(raw_data)}"
            )
            raise ValueError("Unexpected data type from model")

        text = raw_data.strip()

        # Remove markdown fences
        if text.startswith("```json"):
            text = text[len("```json") :].strip()
        if text.startswith("```"):
            text = text[len("```") :].strip()
        if text.endswith("```"):
            text = text[:-3].strip()

        if not text:
            logger.warning(f"Empty content for page {page_num}")
            return ""

        # If output is not JSON-like (e.g., plain text or markdown), return as text
        if not (text.startswith("{") or text.startswith("[")):
            return text

        # JSON-like: attempt to repair and parse
        try:
            parsed = json.loads(repair_json(text))
            return parsed if isinstance(parsed, dict) else text
        except json.JSONDecodeError as e:
            logger.error(f"JSON parsing failed for page {page_num}: {e}")
            return text


class LlmPDFReader:
    """Main PDF reader with LLM-based image analysis."""

    @dataclass
    class ReadResult:
        output_path: str
        page_count: int = 0
        page_split_duration_ms: int | None = None
        reading_duration_ms: int | None = None
        gc_duration_ms: int | None = None
        json_serialize_duration_ms: int | None = None
        rasterize_duration_ms: int | None = None
        total_llm_requests: int = 0
        total_prompt_tokens: int = 0
        total_completion_tokens: int = 0

    def __init__(
        self,
        image_service: ImageAnalysisService,
        progress_interval: int = 1,
        progress_callback: Callable[[int, int, str | None], None] | None = None,
        max_ahead: int = 50,
        concurrency: int = 20,
    ):
        """Initialize PDF reader.

        Args:
            image_service: Image analysis service instance (required for LLM-based processing)
            progress_interval: Log progress every N pages
            progress_callback: Optional callback for progress reporting.
                               Signature: (current: int, total: int, message: str | None) -> None
            max_ahead: Max pages scheduled ahead of the last written page
            concurrency: Max concurrent LLM calls
        """
        self.image_service = image_service
        self.progress_interval = progress_interval
        self.progress_callback = progress_callback
        self._max_ahead = max_ahead
        self._concurrency = concurrency
        self._splitter = PDFSplitter

    async def aread(
        self, pdf_path: str, output_path: str | None = None
    ) -> "list[dict[str, Any]] | LlmPDFReader.ReadResult":
        """Async: Read and process PDF file.

        Args:
            pdf_path: Path to PDF file
            output_path: Optional path to write results incrementally. If provided,
                        results are written in batches and ReadResult is returned.

        Returns:
            List of page dictionaries if output_path is None, otherwise ReadResult with timings

        Raises:
            RuntimeError: If processing fails
        """
        pdf_name = pathlib.Path(pdf_path).stem
        tmp_dir = self._create_temp_dir(pdf_name)

        try:
            t0 = time.monotonic()
            await asyncio.to_thread(
                self._splitter.split, pathlib.Path(pdf_path), tmp_dir
            )
            page_split_ms = int((time.monotonic() - t0) * 1000)

            page_files = self._splitter.get_sorted_pages(tmp_dir)
            processor = PageProcessor(self.image_service)

            if output_path:
                self._last_detail_timings = {}
                self._last_metrics = LLMUsageMetrics()
                t0 = time.monotonic()
                await self._aprocess_all_pages_to_file(
                    tmp_dir,
                    page_files,
                    processor,
                    output_path,
                    max_ahead=self._max_ahead,
                    concurrency=self._concurrency,
                )
                reading_ms = int((time.monotonic() - t0) * 1000)
                detail = self._last_detail_timings
                llm_metrics = self._last_metrics

                if llm_metrics.total_llm_requests > 0:
                    logger.info(
                        f"LlmPDFReader LLM usage for {pdf_path}: "
                        f"{llm_metrics.total_llm_requests} requests, "
                        f"{llm_metrics.total_prompt_tokens} prompt tokens, "
                        f"{llm_metrics.total_completion_tokens} completion tokens"
                    )

                return LlmPDFReader.ReadResult(
                    output_path=output_path,
                    page_count=len(page_files),
                    page_split_duration_ms=page_split_ms,
                    reading_duration_ms=reading_ms,
                    gc_duration_ms=detail.get("gc_duration_ms"),
                    json_serialize_duration_ms=detail.get("json_serialize_duration_ms"),
                    rasterize_duration_ms=detail.get("rasterize_duration_ms"),
                    total_llm_requests=llm_metrics.total_llm_requests,
                    total_prompt_tokens=llm_metrics.total_prompt_tokens,
                    total_completion_tokens=llm_metrics.total_completion_tokens,
                )
            else:
                results, llm_metrics = await self._aprocess_all_pages(
                    tmp_dir, page_files, processor
                )
                if llm_metrics.total_llm_requests > 0:
                    logger.info(
                        f"LlmPDFReader LLM usage for {pdf_path}: "
                        f"{llm_metrics.total_llm_requests} requests, "
                        f"{llm_metrics.total_prompt_tokens} prompt tokens, "
                        f"{llm_metrics.total_completion_tokens} completion tokens"
                    )
                return results

        except Exception as e:
            logger.error("Error processing PDF: {}", e, exc_info=True)
            raise

        finally:
            if tmp_dir.exists():
                safe_rmtree(tmp_dir)

    @staticmethod
    def _create_temp_dir(pdf_name: str) -> pathlib.Path:
        """Create temporary directory."""
        tmp_dir = pathlib.Path(tempfile.mkdtemp(prefix=f"donkit_pdf_{pdf_name}_"))
        tmp_dir.mkdir(parents=True, exist_ok=True)
        return tmp_dir

    def _process_all_pages(
        self, tmp_dir: pathlib.Path, page_files: list[str], processor: PageProcessor
    ) -> list[dict[str, Any]]:
        """[DEPRECATED] Sync processing is disabled. Use _aprocess_all_pages()."""
        raise NotImplementedError(
            "Sync PDF processing is removed. Use _aprocess_all_pages()."
        )

    async def _aprocess_all_pages(
        self, tmp_dir: pathlib.Path, page_files: list[str], processor: PageProcessor
    ) -> tuple[list[dict[str, Any]], LLMUsageMetrics]:
        """Async: Process all pages in parallel using asyncio."""
        start_time = time.time()
        semaphore = asyncio.Semaphore(20)  # Limit concurrent LLM calls
        results = []
        metrics = LLMUsageMetrics()
        lock = asyncio.Lock()

        async def process_one_page(page_num: int, page_file: str):
            """Process single page with semaphore."""
            async with semaphore:
                try:
                    page_path = tmp_dir / page_file
                    page_content, _, _, usage = await processor.aprocess(
                        str(page_path), page_num
                    )

                    async with lock:
                        metrics.add_usage(usage)
                        results.append(
                            {
                                "page": page_content.page_num,
                                "type": page_content.type,
                                "content": page_content.content,
                            }
                        )

                        processed = len(results)
                        if processed % self.progress_interval == 0 or processed in [
                            1,
                            5,
                            15,
                            25,
                        ]:
                            elapsed = time.time() - start_time
                            avg_time = elapsed / processed
                            remaining = len(page_files) - processed
                            est_remaining = remaining * avg_time
                            msg = (
                                f"{processed}/{len(page_files)} pages "
                                f"({elapsed:.1f}s elapsed, ~{est_remaining:.1f}s remaining)"
                            )
                            if self.progress_callback:
                                self.progress_callback(processed, len(page_files), msg)

                        if processed % 5 == 0:
                            gc.collect()

                except Exception as e:
                    logger.error(f"Error processing page {page_num}: {e}")
                    async with lock:
                        results.append(
                            {
                                "page": page_num,
                                "type": "Error",
                                "content": f"Error processing page: {str(e)}",
                            }
                        )

        # Create tasks for all pages
        tasks = [
            process_one_page(page_num, page_file)
            for page_num, page_file in enumerate(page_files, start=1)
        ]

        # Wait for all tasks to complete
        await asyncio.gather(*tasks)

        # Sort results by page number
        results.sort(key=lambda x: x.get("page", 0))

        return results, metrics

    async def _aprocess_all_pages_to_file(
        self,
        tmp_dir: pathlib.Path,
        page_files: list[str],
        processor: PageProcessor,
        output_path: str,
        max_ahead: int = 50,
        concurrency: int = 20,
    ) -> None:
        """Async: Process pages with sliding window and write in order.

        Uses a semaphore for concurrency (up to `concurrency` LLM calls in
        flight) and an ahead-limiter so no more than `max_ahead` pages are
        scheduled beyond the last written page.  Results are written in strict
        page order as soon as the next expected page is ready.
        """
        start_time = time.time()
        output_file = pathlib.Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)

        semaphore = asyncio.Semaphore(max(1, concurrency))
        ahead_sem = asyncio.Semaphore(max(1, max_ahead))

        total_gc_s = 0.0
        total_json_s = 0.0
        total_rasterize_s = 0.0
        metrics = LLMUsageMetrics()
        timing_lock = asyncio.Lock()

        f = open(output_file, "w", encoding="utf-8")

        async def _write(data: str) -> None:
            await asyncio.to_thread(f.write, data)

        try:
            await _write('{"content": [\n')

            total_processed = 0

            async def process_one_page(page_num: int, page_file: str) -> dict[str, Any]:
                nonlocal total_gc_s, total_rasterize_s
                async with semaphore:
                    page_path = tmp_dir / page_file
                    page_content, rasterize_s, gc_s, usage = await processor.aprocess(
                        str(page_path), page_num
                    )
                    async with timing_lock:
                        total_gc_s += gc_s
                        total_rasterize_s += rasterize_s
                        metrics.add_usage(usage)
                    return {
                        "page": page_content.page_num,
                        "type": page_content.type,
                        "content": page_content.content,
                    }

            async def launch(page_num: int, page_file: str) -> dict[str, Any]:
                await ahead_sem.acquire()
                return await process_one_page(page_num, page_file)

            tasks: list[asyncio.Task[dict[str, Any]]] = [
                asyncio.create_task(launch(idx + 1, pf))
                for idx, pf in enumerate(page_files)
            ]

            for task in tasks:
                result = await task
                ahead_sem.release()

                t_json = time.monotonic()
                serialized = json.dumps(result, ensure_ascii=False, indent=2)
                total_json_s += time.monotonic() - t_json

                if total_processed > 0:
                    await _write(",\n" + serialized)
                else:
                    await _write(serialized)

                total_processed += 1
                if total_processed % self.progress_interval == 0 or total_processed in [
                    1,
                    5,
                    15,
                    25,
                ]:
                    elapsed = time.time() - start_time
                    avg_time = elapsed / max(total_processed, 1)
                    remaining = len(page_files) - total_processed
                    est_remaining = max(remaining * avg_time, 0)
                    msg = (
                        f"{total_processed}/{len(page_files)} pages "
                        f"({elapsed:.1f}s elapsed, ~{est_remaining:.1f}s remaining)"
                    )
                    if self.progress_callback:
                        self.progress_callback(total_processed, len(page_files), msg)

                if total_processed % 20 == 0:
                    t_gc = time.monotonic()
                    gc.collect()
                    total_gc_s += time.monotonic() - t_gc

            self._last_detail_timings = {
                "gc_duration_ms": int(total_gc_s * 1000),
                "json_serialize_duration_ms": int(total_json_s * 1000),
                "rasterize_duration_ms": int(total_rasterize_s * 1000),
            }
            self._last_metrics = metrics
        finally:
            try:
                await _write("\n]}")
            except Exception as e:
                logger.warning(f"Failed to finalize JSON output: {e}")
            finally:
                try:
                    f.close()
                except Exception:
                    pass


def safe_rmtree(path: pathlib.Path) -> None:
    """Safely remove directory tree with Windows-compatible error handling.

    On Windows, files might still be locked by the system. This function
    handles permission errors by trying to change file permissions before removal.

    Args:
        path: Path to directory to remove
    """
    import gc
    import platform

    # On Windows, force garbage collection and add small delay to release file handles
    if platform.system() == "Windows":
        gc.collect()
        time.sleep(0.1)  # 100ms delay for Windows to release file handles

    def handle_remove_error(func, filepath, exc_info):
        """Handle errors during directory removal on Windows."""
        # If permission error, try to change permissions and retry
        if exc_info[1].errno == errno.EACCES:
            try:
                os.chmod(filepath, stat.S_IWRITE)
                time.sleep(0.05)  # Small delay before retry
                func(filepath)
            except Exception as e:
                logger.warning(f"Could not remove {filepath}: {e}")
        else:
            logger.warning(f"Could not remove {filepath}: {exc_info[1]}")

    try:
        shutil.rmtree(path, onerror=handle_remove_error)
    except Exception as e:
        logger.warning(f"Failed to cleanup directory {path}: {e}")
