import uuid
from dataclasses import dataclass
from datetime import datetime
from datetime import timezone

import aioboto3
from botocore.config import Config


@dataclass
class FileToUpload:
    path: str
    url: str


@dataclass
class FileInfoWithSize:
    name: str
    size: int


@dataclass
class FileInfo:
    name: str
    type: str


@dataclass
class S3Credentials:
    access_key_id: str
    secret_access_key: str
    region_name: str
    endpoint_url: str
    bucket_name: str


class PresignedUrlService:
    MAX_FILES_FOR_PRESIGNED_URLS = 100
    MAX_FILENAME_LENGTH = 255

    def __init__(self, credentials: S3Credentials):
        self._credentials = credentials
        self._s3_session = aioboto3.Session(
            aws_access_key_id=credentials.access_key_id,
            aws_secret_access_key=credentials.secret_access_key,
        )
        self._bucket_name = credentials.bucket_name
        self._region_name = credentials.region_name
        self._endpoint_url = credentials.endpoint_url

    async def get_presigned_upload_urls(
        self,
        files: list[FileInfo],
        folder: str = "",
    ) -> list[FileToUpload]:
        file_count = len(files)

        if file_count <= 0:
            return []

        if file_count > self.MAX_FILES_FOR_PRESIGNED_URLS:
            msg = f"file_count must not exceed {self.MAX_FILES_FOR_PRESIGNED_URLS}."
            raise ValueError(msg)

        if not all(1 <= len(file.name) <= self.MAX_FILENAME_LENGTH for file in files):
            msg = f"Each file name must be between 1 and {self.MAX_FILENAME_LENGTH} characters."
            raise ValueError(msg)

        date = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
        short_hash = uuid.uuid4().hex[:8]

        folder = f"{folder}/upload-{date}-{short_hash}"

        urls = []

        async with self._s3_session.client(
            "s3",
            region_name=self._region_name,
            endpoint_url=self._endpoint_url,
        ) as client:
            for file in files:
                object_name = f"{folder}/{file.name}"
                presigned_url = await client.generate_presigned_url(
                    "put_object",
                    Params={
                        "Bucket": self._bucket_name,
                        "Key": object_name,
                        "ContentType": file.type,
                    },
                    ExpiresIn=3600,
                )
                urls.append(presigned_url)
        return [
            FileToUpload(path=f"{folder}/{file.name}", url=url)
            for file, url in zip(files, urls)
        ]

    async def get_presigned_upload_urls_with_size(
        self,
        files: list[FileInfoWithSize],
        folder: str = "",
    ) -> list[FileToUpload]:
        file_count = len(files)

        if file_count <= 0:
            return []

        if file_count > self.MAX_FILES_FOR_PRESIGNED_URLS:
            msg = f"file_count must not exceed {self.MAX_FILES_FOR_PRESIGNED_URLS}."
            raise ValueError(msg)

        if not all(1 <= len(file.name) <= self.MAX_FILENAME_LENGTH for file in files):
            msg = (
                f"Each file name/path must be between 1 and {self.MAX_FILENAME_LENGTH} characters. "
                f"Note: file.name may contain subdirectories (e.g., 'subdir/file.txt')."
            )
            raise ValueError(msg)

        if not all(file.size > 0 for file in files):
            msg = "Each file size must be greater than 0."
            raise ValueError(msg)

        # If folder is provided and already contains upload- prefix, use it as is
        # Otherwise, generate a new upload folder
        if folder and folder.startswith("upload-"):
            # Folder already contains upload- prefix, use it directly
            upload_folder = folder
        else:
            # Generate new upload folder
            date = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
            short_hash = uuid.uuid4().hex[:8]
            if folder:
                upload_folder = f"{folder}/upload-{date}-{short_hash}"
            else:
                upload_folder = f"upload-{date}-{short_hash}"

        urls = []

        async with self._s3_session.client(
            "s3",
            region_name=self._region_name,
            endpoint_url=self._endpoint_url,
            config=Config(signature_version="s3v4"),
        ) as client:
            for file in files:
                object_name = f"{upload_folder}/{file.name}"
                presigned_url = await client.generate_presigned_url(
                    "put_object",
                    Params={
                        "Bucket": self._bucket_name,
                        "Key": object_name,
                    },
                    ExpiresIn=3600,
                )
                urls.append(presigned_url)
        return [
            FileToUpload(path=f"{upload_folder}/{file.name}", url=url)
            for file, url in zip(files, urls)
        ]


class S3Service:
    """Service for direct S3 operations (download/upload files)."""

    def __init__(self, credentials: S3Credentials):
        self._credentials = credentials
        self._s3_session = aioboto3.Session(
            aws_access_key_id=credentials.access_key_id,
            aws_secret_access_key=credentials.secret_access_key,
        )
        self._bucket_name = credentials.bucket_name
        self._region_name = credentials.region_name
        self._endpoint_url = credentials.endpoint_url

    async def download_file(self, s3_path: str, local_path: str) -> None:
        """Download file from S3 to local path.

        Args:
            s3_path: S3 object key (path within bucket, e.g., "path/to/file.pdf")
            local_path: Local file path to save the downloaded file
        """
        async with self._s3_session.client(
            "s3",
            region_name=self._region_name,
            endpoint_url=self._endpoint_url,
        ) as s3_client:
            await s3_client.download_file(self._bucket_name, s3_path, local_path)

    async def upload_file(self, local_path: str, s3_path: str) -> None:
        """Upload file from local path to S3.

        Args:
            local_path: Local file path to upload
            s3_path: S3 object key (path within bucket, e.g., "path/to/file.pdf")
        """
        async with self._s3_session.client(
            "s3",
            region_name=self._region_name,
            endpoint_url=self._endpoint_url,
        ) as s3_client:
            await s3_client.upload_file(local_path, self._bucket_name, s3_path)

    async def upload_content(self, s3_path: str, content: bytes) -> None:
        """Upload bytes content directly to S3.

        Args:
            s3_path: S3 object key (path within bucket, e.g., "path/to/file.json")
            content: Bytes content to upload
        """
        from io import BytesIO

        async with self._s3_session.client(
            "s3",
            region_name=self._region_name,
            endpoint_url=self._endpoint_url,
        ) as s3_client:
            await s3_client.upload_fileobj(BytesIO(content), self._bucket_name, s3_path)
