"""DataForge Mask: High-Performance Data Masking."""

__version__ = "0.1.0"

from .dataforge_mask import mask, version

__all__ = ["mask", "version"]
