"""Shared vault utilities."""
import re


def slugify(text: str) -> str:
    """Convert a title to a URL-safe filename slug (max 80 chars)."""
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_]+", "-", text)
    text = re.sub(r"-+", "-", text)
    return text[:80].strip("-")
