"""Auto-configure Obsidian inside the vault on first run.

Merge strategy: locram keys are applied on top of existing config —
user customisations are preserved. Obsolete locram-managed keys are
removed from types.json on each run.
"""
import json
from pathlib import Path

_OBSIDIAN_TYPES: dict[str, str] = {
    "type":      "text",
    "subject":   "multitext",
    "tags":      "tags",
    "status":    "text",
    "created":   "datetime",
    "updated":   "datetime",
    "review in": "number",
    "reviewed":  "datetime",
    "parent":    "text",
    "id":        "text",
}

_OBSIDIAN_CORE_PLUGINS: dict[str, bool] = {
    "file-explorer":  True,
    "global-search":  True,
    "graph":          True,
    "backlink":       True,
    "outgoing-link":  True,
    "tag-pane":       True,
    "properties":     True,
    "templates":      True,
    "outline":        True,
    "word-count":     True,
    "file-recovery":  True,
}

_OBSOLETE_TYPE_KEYS: set[str] = {"review_days"}


def setup_obsidian(vault: Path) -> None:
    """Create or update Obsidian vault configuration for locram.

    Existing user settings are preserved; locram keys are merged in.
    """
    obsidian = vault / ".obsidian"
    obsidian.mkdir(exist_ok=True)
    (vault / "templates").mkdir(exist_ok=True)
    (vault / "attachments").mkdir(exist_ok=True)

    merge_json(obsidian / "app.json", {
        "showInlineTitle": True,
        "attachmentFolderPath": "attachments",
    })

    merge_types_json(obsidian / "types.json")

    merge_json(obsidian / "templates.json", {"folder": "templates"})

    merge_json(obsidian / "core-plugins.json", _OBSIDIAN_CORE_PLUGINS)

    merge_json(obsidian / "graph.json", {
        "showOrphans": True,
        "showArrow": True,
    })

    template_path = vault / "templates" / "locram note.md"
    if not template_path.exists():
        template_path.write_text(
            "---\n"
            "type: fleeting\n"
            "subject: []\n"
            "tags: []\n"
            "status: active\n"
            "created: {{date:YYYY-MM-DD}}T{{time:HH:mm}}\n"
            "updated: {{date:YYYY-MM-DD}}T{{time:HH:mm}}\n"
            "review in: 7\n"
            "parent:\n"
            "id:\n"
            "---\n"
            "\n"
            "<!-- type: fleeting | note-taking | permanent | structure | hub -->\n"
            "<!-- status: active | archived | to_delete -->\n",
            encoding="utf-8",
        )


def merge_json(path: Path, updates: dict) -> None:
    """Shallow-merge updates into an existing JSON config file.

    Keys present in updates are set only if absent from the existing file.
    Keys the user has set are never touched.
    """
    existing: dict = {}
    if path.exists():
        try:
            existing = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            existing = {}

    merged = {**updates, **existing}
    path.write_text(json.dumps(merged, indent=2, ensure_ascii=False), encoding="utf-8")


def merge_types_json(path: Path) -> None:
    """Merge locram property types into types.json.

    - Adds locram-managed type definitions if absent.
    - Removes known obsolete locram keys (e.g. review_days).
    - Preserves all other user-defined property types.
    """
    existing: dict = {}
    if path.exists():
        try:
            existing = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            existing = {}

    current_types: dict = existing.get("types", {})

    for key in _OBSOLETE_TYPE_KEYS:
        current_types.pop(key, None)

    merged_types = {**_OBSIDIAN_TYPES, **current_types}

    path.write_text(
        json.dumps({"types": merged_types}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def write_json(path: Path, data: object) -> None:
    """Write JSON only if the file does not exist yet (legacy helper)."""
    if not path.exists():
        path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
