from pathlib import Path

import frontmatter

from locram.config import DB_PATH, VAULT_EXCLUDED_DIRS, VAULT_PATH
from locram.interfaces.vault_store import VaultStore
from locram.models.page import Page
from locram.vault.obsidian import setup_obsidian
from locram.vault.reader import parse_md
from locram.vault.sync import run_sync
from locram.vault.utils import slugify


def vault_md_files(vault: Path = VAULT_PATH):
    for f in vault.rglob("*.md"):
        if not any(part in VAULT_EXCLUDED_DIRS for part in f.relative_to(vault).parts):
            yield f


class ObsidianVaultStore(VaultStore):

    def __init__(self, vault: Path = VAULT_PATH, db_path: Path | None = None) -> None:
        self._vault = vault
        self._db_path = db_path or DB_PATH
        self._vault.mkdir(parents=True, exist_ok=True)
        self._id_index: dict[str, Path] = {}
        self._rebuild_index()

    @property
    def vault_path(self) -> Path:
        return self._vault

    @property
    def db_path(self) -> Path:
        return self._db_path

    def _rebuild_index(self) -> None:
        self._id_index.clear()
        for f in vault_md_files(self._vault):
            meta = parse_md(f)
            if meta and (pid := meta.get("id")):
                self._id_index[str(pid)] = f

    def _unique_path(self, title: str, exclude_id: str | None = None) -> Path:
        base = slugify(title)
        candidate = self._vault / f"{base}.md"
        if not candidate.exists():
            return candidate
        # Check if the existing file belongs to exclude_id (rename case)
        existing_meta = parse_md(candidate)
        if existing_meta and str(existing_meta.get("id", "")) == (exclude_id or ""):
            return candidate
        # Collision: find next available suffix
        i = 2
        while True:
            candidate = self._vault / f"{base}-{i}.md"
            if not candidate.exists():
                return candidate
            i += 1

    def write(self, page: Page) -> Path:
        existing_path = self._id_index.get(page.id)

        if existing_path and existing_path.exists():
            old_slug = existing_path.stem
            new_slug = slugify(page.title)
            if old_slug != new_slug:
                # Title changed → rename
                new_path = self._unique_path(page.title, exclude_id=page.id)
                existing_path.unlink(missing_ok=True)
                target_path = new_path
            else:
                target_path = existing_path
        else:
            target_path = self._unique_path(page.title, exclude_id=page.id)

        post = frontmatter.Post(
            content=page.content,
            handler=frontmatter.YAMLHandler(),
            **{
                "type":      page.type.value,
                "subject":   page.subject,
                "tags":      page.tags,
                "status":    page.status.value,
                "created":   page.created_at,
                "updated":   page.updated_at,
                "review in": page.review_interval_days,
                "reviewed":  page.reviewed_at,
                "parent":    f"[[{page.parent['title']}]]" if page.parent else None,
                "id":        page.id,
            },
        )
        target_path.write_text(frontmatter.dumps(post), encoding="utf-8")
        self._id_index[page.id] = target_path
        return target_path

    def remove(self, page_id: str) -> None:
        path = self._id_index.pop(page_id, None)
        if path:
            path.unlink(missing_ok=True)

    def read(self, path: Path) -> dict | None:
        return parse_md(path)

    def sync(self, file_path: Path | None = None) -> dict:
        return run_sync(self, file_path)

    def setup_obsidian(self) -> None:
        setup_obsidian(self._vault)
