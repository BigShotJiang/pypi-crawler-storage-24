Change Log
##########

..
   All enhancements and patches to panorama_openedx_backend will be documented
   in this file.  It adheres to the structure of https://keepachangelog.com/ ,
   but in reStructuredText instead of Markdown (for ease of incorporation into
   Sphinx documentation and the PyPI description).

   This project adheres to Semantic Versioning (https://semver.org/).

Version 20.0.1 (2026-03-24)
***************************

* Pass ``userId`` and ``lms`` learner parameters to student dashboard embed URLs in custom mode.
* Update GitHub Actions workflows to Node 20 compatible action and reusable workflow versions.

Version 20.0.0 (2026-03-16)
***************************

* Align packaging, tox, CI, and pinned requirements with the Open edX Teak Python 3.11 baseline.

Version 16.0.15 (2026-03-04)
****************************

* Return the default user ARN when the configured ARN is missing.
* Make the UserAccessConfiguration ARN field optional.
* Use a user lookup widget in the Django admin for the user access configuration.
* Update tox to test against Django >= 4.2.

Version 16.0.14 (2026-03-04)
****************************

* Take the default user arn if not specified in the user access configuration (valid for custom mode only)

Version 16.0.13 (2025-12-02)
****************************

Fix dashboard views for author users

Version 16.0.12 (2024-08-09)
****************************

* fix: Support STUDENT role

Version 16.0.11 (2024-08-09)
****************************

* fix: return student dashboards if the user is not listed in the access
  configuration and the student view is enabled.

Version 16.0.10 (2024-08-05)
****************************

* fix: Fix bug when retrieving the default user arn from the settings.
* fix: Fix allowed domain when generating embed url

Version 16.0.9 (2024-06-11)
***************************

* Manage nonexistent user access configuration

Version 16.0.8 (2024-06-11)
***************************

* Show "available to students" field in the "dashboard type"'s admin list.

Version 16.0.7 (2024-06-10)
***************************

* Increase timeout to 60 secs in api calls

Version 16.0.6 (2024-06-10)
***************************

* Add user role (dashboard_function) to the signed requests to the api.
  This allows for Author, AI and Student views in SaaS modes.

Version 16.0.5 (2024-06-08)
***************************

* Fix SigV4 calls

Version 16.0.4 (2024-06-06)
***************************

* Return "STUDENT" user role in SAAS and CUSTOM modes.
* Return PANORAMA_DEFAULT_USER_ARN if there is no user access configuration.

Version 16.0.3 (2024-06-05)
***************************

* Initial release
