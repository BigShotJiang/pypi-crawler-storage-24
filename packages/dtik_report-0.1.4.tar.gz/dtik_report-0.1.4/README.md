# dtik-report

Công cụ CLI tự động report tài khoản TikTok, hỗ trợ hai chế độ: **Browser** (Chrome + Playwright) và **API** (tls_client, không cần trình duyệt).

## Yêu cầu

- Python 3.11 trở lên
- Google Chrome (chỉ cần cho chế độ Browser)
- macOS, Linux hoặc Windows

## Cài đặt

```bash
pipx install dtik-report
```

> Dùng `pipx` để tool chạy trong môi trường độc lập. Cài pipx: `brew install pipx` hoặc `pip install pipx`.

Nếu dùng **chế độ Browser**, cài thêm Playwright:

```bash
pipx inject dtik-report playwright
playwright install chromium
```

---

## Thiết lập

```bash
dtik setup
```

Wizard sẽ hỏi lần lượt:

**[1] Chế độ hoạt động**

| Chế độ | Mô tả |
|---|---|
| `browser` | Chrome + Playwright, cần đăng nhập TikTok trước, chính xác cao |
| `api` | tls_client, không cần trình duyệt, nhanh, hỗ trợ nhiều thread |

---

### Chế độ Browser

**[2] Số lượng Chrome profile** — mỗi profile là một tài khoản TikTok đăng nhập riêng.

**[3] Giữ hay tắt trình duyệt** giữa các vòng:
- *Giữ mở* — nhanh hơn, ít tốn thời gian khởi động
- *Tắt và mở lại* — tiết kiệm RAM hơn

**[4] Thời gian chờ** giữa các vòng (giây). Nhập `0` để không chờ.

**[5] Proxy xoay** — chọn nhà cung cấp và dán API key (xem mục Proxy bên dưới).

Sau khi setup, Chrome sẽ mở cho từng profile — đăng nhập TikTok rồi đóng lại là xong.

---

### Chế độ API

**[2] Số thread đồng thời** — số request gửi song song mỗi vòng (mặc định 5).

**[3] Thời gian chờ** giữa các vòng (giây). Nhập `0` để không chờ.

**[4] Proxy xoay** — bắt buộc nếu muốn tránh bị block IP.

Chế độ API cần **Report URL** lấy từ DevTools (xem hướng dẫn bên dưới).

---

## Chạy

### Chế độ Browser

```bash
dtik run @username
```

Tool tự động mở từng Chrome profile, thực hiện các bước report trên TikTok và lặp lại theo chu kỳ:

```
  [proxy] Lay proxy tu proxyxoay.shop ...
  [proxy] http://42.117.243.215:10836  (con 1777s)

--- Vong 1 ---
  Proxy: http://42.117.243.215:10836  (con 1750s)

  [Tai khoan 1] Reload TikTok ...
  [Tai khoan 1] [OK] Report thanh cong

  [Tai khoan 2] Reload TikTok ...
  [Tai khoan 2] [OK] Report thanh cong

  Hoan thanh vong 1. Cho 120s ...
  Con lai: 01:58

--- Vong 2 ---
  ...
```

Dừng bất cứ lúc nào bằng `Ctrl+C`.

---

### Chế độ API

#### Bước 1 — Lấy Report URL

1. Mở TikTok trên trình duyệt, vào trang profile cần report
2. Mở **DevTools** (`F12` hoặc `Cmd+Option+I`) → tab **Network**
3. Nhấn `Ctrl+L` / `Cmd+K` để xóa log cũ
4. Thực hiện report thủ công một lần (Actions → Report → chọn lý do → Submit)
5. Trong Network, tìm request có tên chứa `feedback`
6. Chuột phải → **Copy** → **Copy URL**

#### Bước 2 — Chạy

```bash
dtik run <report-url>
```

Hoặc chạy không có tham số, tool sẽ hiển thị danh sách URL đã dùng gần đây:

```bash
dtik run
```

Tool gửi đồng thời nhiều request qua proxy trong mỗi vòng:

```
  [proxy] Lay proxy tu proxyxoay.shop ...
  [proxy] http://160.250.166.19:10157  (con 1418s)

--- Vong 1 (5 threads) ---
  Proxy: http://160.250.166.19:10157  (con 1390s)
  Ket qua: 5 OK / 0 FAIL

  Hoan thanh vong 1. Cho 120s ...
  Con lai: 01:58

--- Vong 2 (5 threads) ---
  ...
```

> **Lưu ý:** Report URL chứa session token của bạn và sẽ hết hạn sau một thời gian. Khi gặp lỗi liên tục, lấy URL mới từ DevTools rồi chạy lại.

---

## Proxy xoay

Tool hỗ trợ proxy xoay tự động. Khi proxy sắp hết hạn (còn dưới 60 giây), tool tự động gọi API lấy proxy mới. Ở chế độ Browser, Chrome được restart với proxy mới.

Nhà cung cấp hiện hỗ trợ:

| Nhà cung cấp | Website | Ghi chú |
|---|---|---|
| proxyxoay.shop | [proxyxoay.shop](https://proxyxoay.shop) | Proxy xoay IP Việt Nam, IP whitelist theo máy |

Cấu hình trong `dtik setup` → chọn nhà cung cấp → dán API key.

---

## Đăng nhập lại

Nếu phiên TikTok trong Chrome bị hết hạn:

```bash
dtik setup --retry
```

Chọn profile cần đăng nhập lại, Chrome sẽ mở ra — đăng nhập xong đóng lại là xong.

---

## Dữ liệu & Cấu hình

Toàn bộ dữ liệu lưu tại `~/.dtik-report/`:

```
~/.dtik-report/
├── settings.json
└── profiles/
    ├── profile_1/     ← Chrome session của tài khoản 1
    ├── profile_2/
    └── ...
```

Ví dụ `settings.json` đầy đủ — **chế độ Browser**:

```json
{
  "engine": "browser",
  "num_profiles": 2,
  "profiles": [
    { "id": "profile_1", "alias": "Tai khoan 1" },
    { "id": "profile_2", "alias": "Tai khoan 2" }
  ],
  "keep_browser_between_reports": true,
  "timeout_between_reports_sec": 120,
  "proxy": {
    "enabled": true,
    "provider": "proxyxoay",
    "config": { "key": "your_api_key_here" }
  }
}
```

Ví dụ `settings.json` — **chế độ API**:

```json
{
  "engine": "api",
  "api_threads": 5,
  "timeout_between_reports_sec": 0,
  "proxy": {
    "enabled": true,
    "provider": "proxyxoay",
    "config": { "key": "your_api_key_here" }
  }
}
```

---

## Giấy phép

MIT
