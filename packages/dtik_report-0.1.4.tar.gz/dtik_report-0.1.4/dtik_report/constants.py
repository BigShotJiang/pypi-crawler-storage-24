"""
Hang so toan cuc.
"""
from pathlib import Path
import sys

# ── App data directory ──────────────────────────────────────────────────────
APP_DATA_DIR = Path.home() / ".dtik-report"

# ── Chrome ─────────────────────────────────────────────────────────────────
CDP_PORT_BASE = 9300
CHROME_LAUNCH_TIMEOUT_SEC = 30

if sys.platform == "darwin":
    CHROME_BINARY = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
elif sys.platform == "win32":
    CHROME_BINARY = r"C:\Program Files\Google\Chrome\Application\chrome.exe"
else:
    CHROME_BINARY = "/usr/bin/google-chrome"

# ── TikTok ─────────────────────────────────────────────────────────────────
TIKTOK_URL = "https://www.tiktok.com"

def tiktok_profile_url(tiktok_id: str) -> str:
    """URL trang profile cua mot tai khoan TikTok."""
    handle = tiktok_id if tiktok_id.startswith("@") else f"@{tiktok_id}"
    return f"{TIKTOK_URL}/{handle}"

# ── Browser ─────────────────────────────────────────────────────────────────
BROWSER_SLOW_MO = 100  # ms, de action trong tu nhien hon

# ── Selectors ───────────────────────────────────────────────────────────────
# Nut "..." (3 cham) tren trang profile
SEL_MORE_BUTTON = 'button[data-e2e="user-more"]'

# Item "Report" trong popover menu
SEL_REPORT_ITEM = 'div[role="button"][aria-label="Report"]'

# Buoc 1: Chon "Report account"
SEL_REPORT_REASON_STEP1 = '[data-e2e="report-card-reason"]:has-text("Report account")'

# Buoc 2: Chon "Something else" (card so 4)
SEL_REPORT_REASON_STEP2 = '[data-e2e="report-card-reason"]:has-text("Something else")'

# Buoc 3: Chon "Frauds and scams" (card so 4)
SEL_REPORT_REASON_STEP3 = '[data-e2e="report-card-reason"]:has-text("Frauds and scams")'

# Nut Submit
SEL_REPORT_SUBMIT = 'button:has-text("Submit")'

# Modal thanh cong ("Thanks for reporting")
SEL_REPORT_SUCCESS = 'text=Thanks for reporting'

# Nut Done de dong modal
SEL_REPORT_CONFIRM = 'button:has-text("Done")'
