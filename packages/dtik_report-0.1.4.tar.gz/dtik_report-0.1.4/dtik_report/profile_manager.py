"""
Quan ly Chrome user-data-dir profiles.
"""
from __future__ import annotations

from pathlib import Path

from .constants import APP_DATA_DIR

PROFILES_DIR = APP_DATA_DIR / "profiles"


def get_profile_path(profile_id: str) -> Path:
    return PROFILES_DIR / profile_id


def ensure_profile_exists(profile_id: str) -> Path:
    path = get_profile_path(profile_id)
    path.mkdir(parents=True, exist_ok=True)
    return path
