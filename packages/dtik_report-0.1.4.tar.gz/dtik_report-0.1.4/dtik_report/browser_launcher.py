"""
Quan ly vong doi Chrome.

LOGIN MODE   : Mo Chrome binh thuong bang subprocess (khong co Playwright).
AUTOMATE MODE: Mo Chrome bang subprocess voi --remote-debugging-port,
               sau do Playwright ket noi qua CDP.
=> Khong co banner "controlled by automated software".
"""
from __future__ import annotations

import socket
import subprocess
import sys
import time
from pathlib import Path

from .constants import (
    CHROME_BINARY,
    CDP_PORT_BASE,
    CHROME_LAUNCH_TIMEOUT_SEC,
    BROWSER_SLOW_MO,
    TIKTOK_URL,
)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _macos_get_frontmost_app() -> str | None:
    if sys.platform != "darwin":
        return None
    try:
        out = subprocess.run(
            ["osascript", "-e", 'tell application "System Events" to get name of first process whose frontmost is true'],
            capture_output=True, text=True, timeout=2,
        )
        if out.returncode == 0 and out.stdout:
            return out.stdout.strip()
    except Exception:
        pass
    return None


def _macos_activate_app(app_name: str) -> None:
    if sys.platform != "darwin" or not app_name:
        return
    try:
        subprocess.run(
            ["osascript", "-e", f'tell application "{app_name}" to activate'],
            capture_output=True, timeout=2,
        )
    except Exception:
        pass


def _wait_for_cdp(port: int, proc: subprocess.Popen, timeout: float = 30.0) -> None:
    deadline = time.time() + timeout
    while time.time() < deadline:
        ret = proc.poll()
        if ret is not None:
            stderr_out = ""
            if proc.stderr:
                stderr_out = proc.stderr.read().decode(errors="replace")[:500]
            raise RuntimeError(
                f"Chrome thoat ngay lap tuc (exit code {ret}).\n"
                f"Stderr: {stderr_out or '(trong)'}"
            )
        try:
            with socket.create_connection(("127.0.0.1", port), timeout=1):
                return
        except OSError:
            time.sleep(0.4)
    stderr_out = ""
    if proc.stderr:
        stderr_out = proc.stderr.read().decode(errors="replace")[:500]
    raise TimeoutError(
        f"Chrome khong mo cong CDP {port} sau {timeout}s.\n"
        f"Stderr: {stderr_out or '(trong)'}\n"
        "Thu tat tat ca Chrome dang mo roi chay lai."
    )



def _spawn_chrome(
    profile_path: Path,
    *,
    debug_port: int | None = None,
    url: str | None = None,
    start_minimized: bool = False,
    proxy_server: str | None = None,
) -> subprocess.Popen:
    cmd = [
        CHROME_BINARY,
        f"--user-data-dir={profile_path}",
        "--no-first-run",
        "--no-default-browser-check",
        "--mute-audio",
    ]
    if proxy_server:
        cmd.append(f"--proxy-server={proxy_server}")
    if debug_port:
        cmd.append(f"--remote-debugging-port={debug_port}")
    if start_minimized:
        cmd.append("--start-minimized")
    if url:
        cmd.append(url)
    print(f"  [chrome] Mo: {profile_path.name} ...")
    return subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)


def _kill_chrome_using_profile(profile_path: Path) -> None:
    """Kill bat ky Chrome process nao dang dung profile_path nay."""
    try:
        result = subprocess.run(
            ["pgrep", "-f", f"user-data-dir={profile_path}"],
            capture_output=True, text=True,
        )
        pids = result.stdout.strip().split()
        for pid in pids:
            if pid.isdigit():
                subprocess.run(["kill", "-9", pid], capture_output=True)
        if pids:
            print(f"  [chrome] Da kill {len(pids)} Chrome process cu cua {profile_path.name}")
            time.sleep(1.0)
    except Exception:
        pass


def _remove_singleton_lock(profile_path: Path) -> None:
    for name in ("SingletonLock", "SingletonSocket", "SingletonCookie"):
        f = profile_path / name
        if f.exists():
            try:
                f.unlink()
                print(f"  [chrome] Da xoa {name}: {f}")
            except Exception:
                pass


# ---------------------------------------------------------------------------
# Login mode
# ---------------------------------------------------------------------------

def launch_chrome_for_login(
    profile_path: Path,
    url: str | None = None,
    proxy_server: str | None = None,
) -> subprocess.Popen:
    """Mo Chrome binh thuong de user dang nhap TikTok thu cong."""
    return _spawn_chrome(profile_path, url=url or TIKTOK_URL, proxy_server=proxy_server)


# ---------------------------------------------------------------------------
# Automate mode
# ---------------------------------------------------------------------------

def launch_chrome_for_automation(
    profile_path: Path,
    debug_port: int,
    target_url: str,
    timeout: float = 30.0,
    proxy_server: str | None = None,
):
    """
    Mo Chrome voi CDP va ket noi Playwright.
    Tra ve (proc, playwright, browser, context, page).
    Caller phai goi pw.stop() va close_chrome(proc) khi xong.
    """
    from playwright.sync_api import sync_playwright

    _kill_chrome_using_profile(profile_path)
    _remove_singleton_lock(profile_path)
    _frontmost_before = _macos_get_frontmost_app()

    print(f"  [chrome] Khoi dong: {profile_path.name} (port {debug_port}) ...")
    # Khong truyen URL vao subprocess — de Playwright navigate sau khi ket noi
    # tranh double-navigation gay ERR_CONNECTION_RESET qua proxy
    proc = _spawn_chrome(
        profile_path,
        debug_port=debug_port,
        start_minimized=True,
        proxy_server=proxy_server,
    )

    print(f"  [chrome] Cho CDP san sang ...")
    _wait_for_cdp(debug_port, proc=proc, timeout=timeout)

    print(f"  [chrome] Ket noi Playwright ...")
    pw = sync_playwright().start()
    browser = pw.chromium.connect_over_cdp(
        f"http://127.0.0.1:{debug_port}",
        slow_mo=BROWSER_SLOW_MO,
    )
    context = browser.contexts[0] if browser.contexts else browser.new_context()

    # Lay tab hien tai hoac mo tab moi, roi navigate
    page = context.pages[0] if context.pages else context.new_page()
    print(f"  [chrome] Mo TikTok ...")
    page.goto(target_url, wait_until="domcontentloaded", timeout=60_000)

    if _frontmost_before:
        time.sleep(0.5)
        _macos_activate_app(_frontmost_before)

    print(f"  [chrome] San sang: {profile_path.name}")
    return proc, pw, browser, context, page


def reconnect_chrome_for_automation(
    profile_path: Path,
    debug_port: int,
    target_url: str,
    proc: subprocess.Popen,
    timeout: float = 30.0,
):
    """
    Ket noi lai Playwright vao Chrome dang chay (khong kill/spawn).
    Chi reload page de bat dau vong moi.
    Tra ve (proc, playwright, browser, context, page).
    """
    from playwright.sync_api import sync_playwright

    _frontmost_before = _macos_get_frontmost_app()

    print(f"  [chrome] Ket noi lai: {profile_path.name} (port {debug_port}) ...")
    pw = sync_playwright().start()
    browser = pw.chromium.connect_over_cdp(
        f"http://127.0.0.1:{debug_port}",
        slow_mo=BROWSER_SLOW_MO,
    )
    context = browser.contexts[0] if browser.contexts else browser.new_context()

    page = next(
        (p for p in context.pages if "tiktok.com" in (p.url or "")),
        None,
    )
    if page is None:
        page = context.pages[0] if context.pages else context.new_page()
        page.goto(target_url, wait_until="domcontentloaded", timeout=30_000)
    else:
        print(f"  [chrome] Reload: {profile_path.name} ...")
        page.reload(wait_until="domcontentloaded", timeout=30_000)
        if target_url not in page.url:
            page.goto(target_url, wait_until="domcontentloaded", timeout=30_000)

    if _frontmost_before:
        time.sleep(0.5)
        _macos_activate_app(_frontmost_before)

    print(f"  [chrome] San sang: {profile_path.name}")
    return proc, pw, browser, context, page


def close_chrome(proc: subprocess.Popen) -> None:
    proc.terminate()
    try:
        proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.kill()
