"""
Proxy provider abstraction.

De them nha cung cap moi:
  1. Ke thua ProxyProvider
  2. Implement phuong thuc fetch() tra ve ProxyInfo
  3. Dang ky trong PROVIDERS va make_provider()
"""
from __future__ import annotations

import json
import re
import time
import urllib.error
import urllib.request
from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class ProxyInfo:
    """Thong tin proxy duoc fetch tu provider."""
    http_url: str       # vd: "http://1.2.3.4:8080"
    expires_at: float   # unix timestamp, 0 = khong co TTL

    def seconds_left(self) -> int:
        if self.expires_at == 0:
            return 9999
        return max(0, int(self.expires_at - time.time()))

    def is_expired(self, buffer_sec: float = 60.0) -> bool:
        """True neu proxy sap het han (con < buffer_sec giay)."""
        if self.expires_at == 0:
            return False
        return time.time() >= self.expires_at - buffer_sec


class ProxyProvider(ABC):
    """Interface chung cho moi nha cung cap proxy."""

    # Ten hien thi trong setup wizard
    label: str = "Unknown"

    @abstractmethod
    def fetch(self) -> ProxyInfo:
        """Lay proxy moi. Raise RuntimeError neu that bai."""
        ...

    @classmethod
    @abstractmethod
    def from_config(cls, cfg: dict) -> "ProxyProvider":
        """Tao instance tu phan 'config' trong settings."""
        ...

    @abstractmethod
    def to_config(self) -> dict:
        """Tra ve dict de luu vao settings."""
        ...


# ---------------------------------------------------------------------------
# ProxyXoay — proxyxoay.shop
# ---------------------------------------------------------------------------

class ProxyxoayProvider(ProxyProvider):
    label = "proxy.vn"
    _API = "https://proxyxoay.shop/api/get.php"

    def __init__(self, key: str):
        self.key = key

    def fetch(self) -> ProxyInfo:
        url = f"{self._API}?key={self.key}&nhamang=random&tinhthanh=0&whitelist="
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "dtik-report/1.0"})
            with urllib.request.urlopen(req, timeout=15) as resp:
                data = json.loads(resp.read().decode())
        except urllib.error.URLError as e:
            raise RuntimeError(f"Khong the ket noi proxyxoay.shop: {e}")

        if data.get("status") != 100:
            msg = data.get("message", str(data))
            raise RuntimeError(f"proxyxoay.shop tra ve loi: {msg}")

        # Format: "ip:port::" (IP whitelist, khong co user:pass)
        proxy_http: str = data["proxyhttp"]
        parts = proxy_http.split(":")
        host, port = parts[0], parts[1]

        # Parse TTL tu message: "proxy nay se die sau 1777s"
        ttl = 300  # fallback 5 phut
        match = re.search(r"(\d+)s", data.get("message", ""))
        if match:
            ttl = int(match.group(1))

        return ProxyInfo(
            http_url=f"http://{host}:{port}",
            expires_at=time.time() + ttl,
        )

    @classmethod
    def from_config(cls, cfg: dict) -> "ProxyxoayProvider":
        return cls(key=cfg["key"])

    def to_config(self) -> dict:
        return {"key": self.key}


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

# Thu tu nay se hien thi trong setup wizard
PROVIDERS: dict[str, type[ProxyProvider]] = {
    "proxyxoay": ProxyxoayProvider,
    # "proxyvn": ProxyVnProvider,  # them sau
}

PROVIDER_LABELS: dict[str, str] = {k: v.label for k, v in PROVIDERS.items()}


def make_provider(proxy_cfg: dict) -> ProxyProvider | None:
    """Tao ProxyProvider tu settings. Tra ve None neu proxy tat."""
    if not proxy_cfg or not proxy_cfg.get("enabled"):
        return None
    provider_id = proxy_cfg.get("provider")
    cls = PROVIDERS.get(provider_id)
    if cls is None:
        raise ValueError(f"Nha cung cap proxy khong hop le: '{provider_id}'")
    return cls.from_config(proxy_cfg.get("config", {}))
