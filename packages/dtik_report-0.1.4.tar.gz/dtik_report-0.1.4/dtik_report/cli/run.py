"""
Lenh `dtik run` — tu dong report tai khoan TikTok.
"""
from __future__ import annotations

import sys
import time

import click
import questionary

from ..config import load_settings, validate_settings, get_recent_targets, add_recent_target
from ..profile_manager import ensure_profile_exists
from ..browser_launcher import launch_chrome_for_automation, reconnect_chrome_for_automation, close_chrome
from ..reporter import report_account
from ..api_reporter import report_batch
from ..proxy_provider import make_provider, ProxyInfo, PROVIDER_LABELS
from ..constants import CDP_PORT_BASE, CHROME_LAUNCH_TIMEOUT_SEC, tiktok_profile_url
from .common import _LINE, _BOLD


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_timeout_sec(settings: dict) -> int:
    """Doc timeout theo giay. Compat voi key cu (phut)."""
    if "timeout_between_reports_sec" in settings:
        return max(0, settings["timeout_between_reports_sec"])
    return settings.get("timeout_between_reports_min", 2) * 60


def _fetch_proxy(provider, label: str) -> ProxyInfo | None:
    try:
        click.echo(f"  [proxy] Lay proxy tu {label} ...")
        info = provider.fetch()
        click.echo(f"  [proxy] {info.http_url}  (con {info.seconds_left()}s)")
        return info
    except Exception as e:
        click.echo(f"  [proxy] Loi: {e}", err=True)
        return None


def _refresh_proxy_if_needed(
    provider,
    provider_label: str,
    current_proxy: ProxyInfo | None,
    chrome_procs: dict | None = None,
) -> ProxyInfo | None:
    """Lay proxy moi neu het han. Neu chrome_procs truyen vao thi dong Chrome truoc."""
    if provider is None:
        return current_proxy
    if current_proxy is not None and not current_proxy.is_expired():
        return current_proxy

    click.echo("\n  [proxy] Proxy sap het han, lay proxy moi ...")
    new_proxy = _fetch_proxy(provider, provider_label)
    if new_proxy:
        if chrome_procs:
            click.echo("  [proxy] Tat Chrome de mo lai voi proxy moi ...")
            for proc in chrome_procs.values():
                try:
                    close_chrome(proc)
                except Exception:
                    pass
            chrome_procs.clear()
        return new_proxy

    click.echo("  [proxy] Khong the lay proxy moi, tiep tuc voi proxy cu.")
    return current_proxy


def _countdown(seconds: int) -> None:
    if seconds <= 0:
        return
    while seconds > 0:
        mins, secs = divmod(seconds, 60)
        click.echo(f"\r  Con lai: {mins:02d}:{secs:02d}  ", nl=False)
        time.sleep(1)
        seconds -= 1
    click.echo("\r  Het gio, bat dau vong moi ...        ")


def _ask_target(settings: dict, arg: str | None, label: str, prompt_text: str) -> str | None:
    """Hien thi recent list de chon, hoac hoi nhap moi."""
    target = arg
    if not target:
        _NEW = "__new__"
        recent = get_recent_targets(settings)
        if recent:
            choices = [questionary.Choice(title=r[:90], value=r) for r in recent]
            choices.append(questionary.Choice(title=f"-- {label} --", value=_NEW))
            chosen = questionary.select(f"Chon {label.lower()}:", choices=choices).ask()
            if chosen is None:
                return None
            if chosen == _NEW:
                target = click.prompt(prompt_text)
            else:
                target = chosen
        else:
            target = click.prompt(prompt_text)
    return target or None


# ---------------------------------------------------------------------------
# Browser mode
# ---------------------------------------------------------------------------

def _run_report_browser(tiktok_id: str, profiles: list[dict], settings: dict) -> None:
    timeout_sec = _get_timeout_sec(settings)
    keep_browser: bool = settings.get("keep_browser_between_reports", True)
    target_url = tiktok_profile_url(tiktok_id)

    proxy_cfg = settings.get("proxy", {})
    provider = make_provider(proxy_cfg)
    provider_label = PROVIDER_LABELS.get(proxy_cfg.get("provider", ""), "proxy")
    current_proxy: ProxyInfo | None = None

    if provider:
        current_proxy = _fetch_proxy(provider, provider_label)
        proxy_display = current_proxy.http_url if current_proxy else "Loi"
    else:
        proxy_display = "Tat"

    timeout_display = f"{timeout_sec}s" if timeout_sec > 0 else "Khong cho"

    click.echo(f"\n{_BOLD}")
    click.echo("  DTIK REPORT — BROWSER MODE")
    click.echo(f"  Target   : {target_url}")
    click.echo(f"  Profiles : {len(profiles)}")
    click.echo(f"  Timeout  : {timeout_display}")
    click.echo(f"  Browser  : {'Giu mo' if keep_browser else 'Tat va mo lai'}")
    click.echo(f"  Proxy    : {proxy_display}")
    click.echo(_BOLD)

    round_num = 0
    chrome_procs: dict[str, object] = {}

    while True:
        round_num += 1

        current_proxy = _refresh_proxy_if_needed(
            provider, provider_label, current_proxy,
            chrome_procs=chrome_procs if keep_browser else None,
        )
        proxy_server = current_proxy.http_url if current_proxy else None

        click.echo(f"\n--- Vong {round_num} ---")
        if provider and current_proxy:
            click.echo(f"  Proxy: {current_proxy.http_url}  (con {current_proxy.seconds_left()}s)")

        for idx, profile in enumerate(profiles):
            profile_id = profile["id"]
            alias = profile.get("alias", profile_id)
            debug_port = CDP_PORT_BASE + idx
            profile_path = ensure_profile_exists(profile_id)

            proc = pw = None
            try:
                existing_proc = chrome_procs.get(profile_id)
                is_alive = existing_proc is not None and existing_proc.poll() is None

                if keep_browser and is_alive:
                    click.echo(f"\n  [{alias}] Reload TikTok ...")
                    proc, pw, _, _, page = reconnect_chrome_for_automation(
                        profile_path,
                        debug_port=debug_port,
                        target_url=target_url,
                        proc=existing_proc,
                        timeout=float(CHROME_LAUNCH_TIMEOUT_SEC),
                    )
                else:
                    click.echo(f"\n  [{alias}] Mo TikTok ...")
                    proc, pw, _, _, page = launch_chrome_for_automation(
                        profile_path,
                        debug_port=debug_port,
                        target_url=target_url,
                        timeout=float(CHROME_LAUNCH_TIMEOUT_SEC),
                        proxy_server=proxy_server,
                    )
                    if keep_browser:
                        chrome_procs[profile_id] = proc

                result = report_account(page)
                click.echo(f"  [{alias}] {result}")

            except Exception as e:
                click.echo(f"  [{alias}] Loi: {e}", err=True)
                chrome_procs.pop(profile_id, None)

            finally:
                if pw:
                    try:
                        pw.stop()
                    except Exception:
                        pass
                if not keep_browser and proc:
                    close_chrome(proc)

        click.echo(f"\n  Hoan thanh vong {round_num}.")
        if timeout_sec > 0:
            click.echo(f"  Cho {timeout_sec}s ...")
            _countdown(timeout_sec)


# ---------------------------------------------------------------------------
# API mode
# ---------------------------------------------------------------------------

def _run_report_api(report_url: str, settings: dict) -> None:
    timeout_sec = _get_timeout_sec(settings)
    threads: int = settings.get("api_threads", 5)

    proxy_cfg = settings.get("proxy", {})
    provider = make_provider(proxy_cfg)
    provider_label = PROVIDER_LABELS.get(proxy_cfg.get("provider", ""), "proxy")
    current_proxy: ProxyInfo | None = None

    if provider:
        current_proxy = _fetch_proxy(provider, provider_label)
        proxy_display = current_proxy.http_url if current_proxy else "Loi"
    else:
        proxy_display = "Tat"

    timeout_display = f"{timeout_sec}s" if timeout_sec > 0 else "Khong cho"

    click.echo(f"\n{_BOLD}")
    click.echo("  DTIK REPORT — API MODE")
    click.echo(f"  URL      : {report_url[:80]}...")
    click.echo(f"  Threads  : {threads}")
    click.echo(f"  Timeout  : {timeout_display}")
    click.echo(f"  Proxy    : {proxy_display}")
    click.echo(_BOLD)

    round_num = 0

    while True:
        round_num += 1

        current_proxy = _refresh_proxy_if_needed(provider, provider_label, current_proxy)
        proxy_server = current_proxy.http_url if current_proxy else None

        click.echo(f"\n--- Vong {round_num} ({threads} threads) ---")
        if provider and current_proxy:
            click.echo(f"  Proxy: {current_proxy.http_url}  (con {current_proxy.seconds_left()}s)")

        ok, fail = report_batch(report_url, threads=threads, proxy_http=proxy_server)
        click.echo(f"  Ket qua: {ok} OK / {fail} FAIL")

        click.echo(f"\n  Hoan thanh vong {round_num}.")
        if timeout_sec > 0:
            click.echo(f"  Cho {timeout_sec}s ...")
            _countdown(timeout_sec)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def register_run(main: click.Group) -> None:
    @main.command("run")
    @click.argument("target", required=False)
    @click.option("--id", "target_opt", default=None, help="TikTok ID hoac Report URL")
    def cmd_run(target: str | None, target_opt: str | None) -> None:
        """Tu dong report TikTok (browser mode hoac API mode)."""
        settings = load_settings()

        try:
            validate_settings(settings)
        except ValueError as e:
            click.echo(f"Loi cau hinh: {e}", err=True)
            sys.exit(1)

        engine = settings.get("engine", "browser")
        raw_target = target or target_opt

        try:
            if engine == "api":
                # API mode: target la full report URL tu DevTools
                url = _ask_target(
                    settings, raw_target,
                    label="Nhap Report URL moi",
                    prompt_text="  Dan Report URL (tu DevTools TikTok Network tab)",
                )
                if not url:
                    click.echo("Chua nhap URL.", err=True)
                    sys.exit(1)
                add_recent_target(settings, url)
                _run_report_api(url, settings)

            else:
                # Browser mode: target la TikTok handle
                tid = _ask_target(
                    settings, raw_target,
                    label="Nhap TikTok ID moi",
                    prompt_text="  Nhap TikTok ID (vd: @username hoac username)",
                )
                if not tid:
                    click.echo("Chua nhap TikTok ID.", err=True)
                    sys.exit(1)
                if not tid.startswith("@"):
                    tid = f"@{tid}"
                add_recent_target(settings, tid)

                profiles = settings["profiles"]
                if len(profiles) > 1:
                    choices = [
                        questionary.Choice(
                            title=f"{p.get('alias', p['id'])} ({p['id']})", value=p, checked=True
                        )
                        for p in profiles
                    ]
                    selected = questionary.checkbox(
                        "Chon profiles se dung (Space: chon/bo, Enter: xac nhan)",
                        choices=choices,
                    ).ask()
                    if selected is None:
                        sys.exit(0)
                    if not selected:
                        click.echo("Khong co profile nao duoc chon.")
                        sys.exit(0)
                    profiles = selected

                _run_report_browser(tid, profiles, settings)

        except KeyboardInterrupt:
            click.echo("\n\n  Da dung boi nguoi dung.")
            sys.exit(0)
