"""
Utilities chung cho CLI.
"""
from __future__ import annotations

import subprocess
import sys

import click

_LINE = "=" * 50
_BOLD = "=" * 50


def ensure_playwright_browsers() -> None:
    """Cai Chromium neu chua co, de tranh loi khi chay lan dau."""
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            _ = pw.chromium
    except Exception:
        click.echo("Cai dat Playwright browsers ...")
        subprocess.run(
            [sys.executable, "-m", "playwright", "install", "chromium"],
            check=False,
        )
