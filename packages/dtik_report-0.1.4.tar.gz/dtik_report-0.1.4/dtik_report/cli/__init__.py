"""
CLI package — entry point `dtik`
  dtik setup           — cau hinh profiles, mo TikTok de dang nhap
  dtik setup --retry   — mo lai profile cu de dang nhap lai
  dtik run [ID]        — tu dong report tai khoan TikTok
  dtik open [alias]    — mo Chrome cho mot profile
  dtik check           — kiem tra setup hien tai
  dtik update          — cap nhat package
  dtik uninstall       — go cai tool
  dtik help            — hien thi huong dan
"""
from __future__ import annotations

import click

from .common import ensure_playwright_browsers
from .setup import register_setup
from .run import register_run
from .commands import register_open, register_check, register_update, register_uninstall, register_help


@click.group()
def main() -> None:
    """dtik-report — Tu dong report tai khoan TikTok bang nhieu Chrome profiles."""
    ensure_playwright_browsers()


register_setup(main)
register_run(main)
register_open(main)
register_check(main)
register_update(main)
register_uninstall(main)
register_help(main)

__all__ = ["main"]
