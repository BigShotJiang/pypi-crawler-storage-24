"""
Cac lenh phu: open, check, update, uninstall, help.
"""
from __future__ import annotations

import subprocess
import sys

import click
import questionary

from ..config import load_settings, validate_settings, SETTINGS_FILE
from ..profile_manager import ensure_profile_exists, get_profile_path, PROFILES_DIR
from ..browser_launcher import launch_chrome_for_login
from ..constants import TIKTOK_URL, APP_DATA_DIR
from .common import _LINE, _BOLD


def register_open(main: click.Group) -> None:
    @main.command("open")
    @click.argument("alias", required=False)
    def cmd_open(alias: str | None) -> None:
        """Mo Chrome cho mot profile de quan ly dang nhap TikTok."""
        settings = load_settings()
        profiles = settings.get("profiles", [])

        if not profiles:
            click.echo("Chua co profile nao. Chay: dtik setup")
            sys.exit(1)

        if alias:
            match = next(
                (p for p in profiles if (p.get("alias") or p["id"]).lower() == alias.lower()),
                None,
            )
            if match is None:
                available = ", ".join(p.get("alias", p["id"]) for p in profiles)
                click.echo(f"Khong tim thay profile '{alias}'. Cac profile: {available}")
                sys.exit(1)
        else:
            choices = [
                questionary.Choice(title=f"{p.get('alias', p['id'])} ({p['id']})", value=p)
                for p in profiles
            ]
            match = questionary.select("Chon profile de mo Chrome", choices=choices).ask()
            if match is None:
                sys.exit(0)

        profile_path = ensure_profile_exists(match["id"])
        click.echo(f"Mo Chrome: {match.get('alias', match['id'])} ...")
        proc = launch_chrome_for_login(profile_path, url=TIKTOK_URL)
        click.echo("Dong cua so Chrome khi xong.")
        proc.wait()


def register_check(main: click.Group) -> None:
    @main.command("check")
    def cmd_check() -> None:
        """Kiem tra cau hinh hien tai."""
        settings = load_settings()

        click.echo(f"\n{_BOLD}")
        click.echo("  DTIK REPORT — KIEM TRA SETUP")
        click.echo(_BOLD)

        click.echo(f"\n  File cau hinh : {SETTINGS_FILE}")
        click.echo(f"  Ton tai       : {'Co' if SETTINGS_FILE.exists() else 'Khong'}")

        if not settings:
            click.echo(f"\n  {_LINE}")
            click.echo("  Chua co cau hinh. Chay: dtik setup")
            click.echo(_LINE)
            return

        timeout_min = settings.get("timeout_between_reports_min", 2)
        keep_browser = settings.get("keep_browser_between_reports", True)
        click.echo(f"\n  Timeout giua report : {timeout_min} phut")
        click.echo(f"  Browser             : {'Giu mo' if keep_browser else 'Tat va mo lai'}")

        profiles = settings.get("profiles", [])
        click.echo(f"\n  Profiles     : {len(profiles)}")
        for i, p in enumerate(profiles, 1):
            pid = p.get("id", "")
            alias = p.get("alias", pid)
            path = get_profile_path(pid)
            exists = path.exists() and path.is_dir()
            status = "OK" if exists else "Chua tao thu muc"
            click.echo(f"    {i}. {alias} ({pid}) — {status}")

        click.echo(f"\n  Thu muc profiles : {PROFILES_DIR}")

        click.echo(f"\n  {_LINE}")
        try:
            validate_settings(settings)
            click.echo("  San sang chay : Co")
        except ValueError as e:
            click.echo(f"  San sang chay : Khong — {e}")
        click.echo(_LINE)
        click.echo()


def register_update(main: click.Group) -> None:
    @main.command("update")
    def cmd_update() -> None:
        """Cap nhat dtik-report len phien ban moi nhat."""
        exe = sys.executable
        if "pipx" in exe or "pipx" in sys.argv[0]:
            click.echo("Cap nhat qua pipx ...")
            cmd = ["pipx", "upgrade", "dtik-report"]
        else:
            click.echo("Cap nhat qua pip ...")
            cmd = [exe, "-m", "pip", "install", "--upgrade", "dtik-report"]

        result = subprocess.run(cmd)
        if result.returncode == 0:
            click.echo("\nCap nhat thanh cong!")
        else:
            click.echo("\nCap nhat that bai. Thu chay thu cong:", err=True)
            click.echo("  pipx upgrade dtik-report", err=True)
            click.echo("  hoac: pip3 install --upgrade dtik-report", err=True)
            sys.exit(result.returncode)


def register_uninstall(main: click.Group) -> None:
    @main.command("uninstall")
    def cmd_uninstall() -> None:
        """Go cai dtik-report va xoa du lieu trong ~/.dtik-report/."""
        import shutil

        click.echo("\n  DTIK REPORT — UNINSTALL")
        click.echo("  " + "=" * 40)
        click.echo(f"  Se xoa: {APP_DATA_DIR}")
        click.echo("  Se go cai package dtik-report")
        click.echo()

        if not click.confirm("  Ban chac chan muon go cai khong?", default=False):
            click.echo("  Da huy.")
            return

        if APP_DATA_DIR.exists():
            shutil.rmtree(APP_DATA_DIR)
            click.echo(f"  Da xoa: {APP_DATA_DIR}")

        exe = sys.executable
        if "pipx" in exe or "pipx" in sys.argv[0]:
            cmd = ["pipx", "uninstall", "dtik-report"]
        else:
            cmd = [exe, "-m", "pip", "uninstall", "-y", "dtik-report"]

        result = subprocess.run(cmd)
        if result.returncode == 0:
            click.echo("\n  Go cai thanh cong!")
        else:
            click.echo("\n  Go cai that bai.", err=True)
            sys.exit(result.returncode)


def register_help(main: click.Group) -> None:
    @main.command("help")
    @click.pass_context
    def cmd_help(ctx: click.Context) -> None:
        """Hien thi danh sach lenh."""
        click.echo(ctx.parent.get_help())  # type: ignore[union-attr]
