"""
Lenh `dtik setup` — cau hinh profiles, mo TikTok de dang nhap.
"""
from __future__ import annotations

import sys
import time

import click
import questionary

from ..config import load_settings, save_settings
from ..profile_manager import ensure_profile_exists
from ..browser_launcher import launch_chrome_for_login
from ..proxy_provider import PROVIDERS, PROVIDER_LABELS, make_provider
from ..constants import TIKTOK_URL
from .common import _LINE, _BOLD


def _setup_full() -> None:
    click.echo(f"\n{_BOLD}")
    click.echo("  DTIK REPORT — THIET LAP")
    click.echo(_BOLD)

    settings = load_settings()

    # ── [1] Engine ────────────────────────────────────────────────────────
    click.echo("\n[1] Chon che do hoat dong")
    engine = questionary.select(
        "  Che do:",
        choices=[
            questionary.Choice(
                title="Browser  — Chrome + Playwright (can dang nhap, chinh xac cao)",
                value="browser",
            ),
            questionary.Choice(
                title="API      — tls_client, khong can browser (nhanh, nhieu thread)",
                value="api",
            ),
        ],
        default=settings.get("engine", "browser"),
    ).ask()
    if engine is None:
        return

    profiles: list[dict] = []
    keep_browser_choice: bool = True
    api_threads: int = 5

    if engine == "browser":
        # ── [2] So luong profiles ──────────────────────────────────────────
        click.echo("\n[2] Cau hinh Chrome profiles")
        num_options = [str(i) for i in range(1, 11)]
        default_num = str(max(1, min(settings.get("num_profiles", 1), 10)))
        num_str = questionary.select(
            "  So luong Chrome profile",
            choices=num_options,
            default=default_num,
        ).ask()
        if num_str is None:
            return
        num = int(num_str)

        for i in range(1, num + 1):
            alias = click.prompt(
                f"  Ten alias cho profile {i} (Enter = mac dinh)",
                default=settings.get("profiles", [{}] * i)[i - 1].get("alias", f"Tai khoan {i}")
                if i <= len(settings.get("profiles", [])) else f"Tai khoan {i}",
            )
            profiles.append({"id": f"profile_{i}", "alias": alias})

        # ── [3] Keep browser ───────────────────────────────────────────────
        click.echo("\n[3] Browser giua cac lan timeout")
        keep_browser_choice = questionary.select(
            "  Giu browser mo hay tat browser giua cac lan cho?",
            choices=[
                questionary.Choice(title="Giu browser mo (nhanh hon, de theo doi)", value=True),
                questionary.Choice(title="Tat browser, mo lai sau (tiet kiem RAM)", value=False),
            ],
            default=settings.get("keep_browser_between_reports", True),
        ).ask()
        if keep_browser_choice is None:
            return

    else:  # api mode
        # ── [2] So threads ─────────────────────────────────────────────────
        click.echo("\n[2] So thread dong thoi")
        api_threads = click.prompt(
            "  So request gui cung luc moi vong (mac dinh 5)",
            type=int,
            default=settings.get("api_threads", 5),
        )
        api_threads = max(1, min(api_threads, 50))

    # ── Timeout (chung cho ca 2 mode) ─────────────────────────────────────
    step = 4 if engine == "browser" else 3
    click.echo(f"\n[{step}] Thoi gian cho giua cac vong report")
    # Compat: doc tu key cu neu chua co key moi
    default_sec = settings.get(
        "timeout_between_reports_sec",
        settings.get("timeout_between_reports_min", 2) * 60,
    )
    timeout_sec = click.prompt(
        "  Giay cho giua moi vong (0 = khong cho, mac dinh 120)",
        type=int,
        default=default_sec,
    )
    timeout_sec = max(0, timeout_sec)

    # ── Proxy ─────────────────────────────────────────────────────────────
    step += 1
    click.echo(f"\n[{step}] Proxy xoay")
    existing_proxy = settings.get("proxy", {})
    use_proxy = questionary.confirm(
        "  Su dung proxy xoay khong?",
        default=existing_proxy.get("enabled", False),
    ).ask()
    if use_proxy is None:
        return

    proxy_cfg: dict = {"enabled": False}
    if use_proxy:
        provider_choices = [
            questionary.Choice(title=label, value=pid)
            for pid, label in PROVIDER_LABELS.items()
        ]
        current_provider = existing_proxy.get("provider", list(PROVIDERS.keys())[0])
        selected_provider = questionary.select(
            "  Nha cung cap proxy",
            choices=provider_choices,
            default=current_provider,
        ).ask()
        if selected_provider is None:
            return

        existing_config = existing_proxy.get("config", {})
        provider_cfg = _ask_provider_config(selected_provider, existing_config)
        if provider_cfg is None:
            return

        click.echo("  Dang kiem tra ket noi proxy ...")
        test_cfg = {"enabled": True, "provider": selected_provider, "config": provider_cfg}
        try:
            provider = make_provider(test_cfg)
            info = provider.fetch()
            click.echo(f"  [OK] Lay proxy thanh cong: {info.http_url} (con {info.seconds_left()}s)")
        except Exception as e:
            click.echo(f"  [WARN] Kiem tra proxy that bai: {e}")
            if not click.confirm("  Tiep tuc luu cau hinh du co loi?", default=False):
                return

        proxy_cfg = {
            "enabled": True,
            "provider": selected_provider,
            "config": provider_cfg,
        }

    # ── Save ──────────────────────────────────────────────────────────────
    settings.update({
        "engine": engine,
        "num_profiles": len(profiles),
        "profiles": profiles,
        "api_threads": api_threads,
        "timeout_between_reports_sec": timeout_sec,
        "keep_browser_between_reports": keep_browser_choice,
        "proxy": proxy_cfg,
    })
    save_settings(settings)

    proxy_label = PROVIDER_LABELS.get(proxy_cfg.get("provider", ""), "Tat") if use_proxy else "Tat"
    timeout_display = f"{timeout_sec}s" if timeout_sec > 0 else "Khong cho"

    click.echo(f"\n{_LINE}")
    click.echo("  Cau hinh da luu.")
    click.echo(f"  - Che do  : {engine}")
    if engine == "browser":
        for p in profiles:
            ensure_profile_exists(p["id"])
        click.echo(f"  - Profiles: {len(profiles)}")
        click.echo(f"  - Browser : {'Giu mo' if keep_browser_choice else 'Tat va mo lai'}")
    else:
        click.echo(f"  - Threads : {api_threads}")
    click.echo(f"  - Cho     : {timeout_display}")
    click.echo(f"  - Proxy   : {proxy_label}")
    click.echo(_LINE)

    if engine == "browser":
        click.echo("\nHuong dan sau khi Chrome mo:")
        click.echo("  1. Dang nhap TikTok trong moi cua so Chrome")
        click.echo("  2. Dong tat ca cua so Chrome khi xong")
        click.echo(_LINE)
        if click.confirm("\nMo Chrome de dang nhap TikTok ngay bay gio?", default=True):
            _open_browsers_for_login(profiles)
    else:
        click.echo("\nChe do API: lay Report URL tu DevTools TikTok roi chay `dtik run <url>`.")
        click.echo("  1. Mo TikTok tren trinh duyet, mo DevTools (F12) → Network")
        click.echo("  2. Report thu cong 1 lan")
        click.echo("  3. Tim request 'feedback', copy URL")
        click.echo("  4. Chay: dtik run <url_do>")
        click.echo(_LINE)


def _ask_provider_config(provider_id: str, existing: dict) -> dict | None:
    """Hoi user nhap thong tin cau hinh cho tung provider. Tra ve None neu huy."""
    if provider_id == "proxyxoay":
        key = click.prompt(
            "  API key proxy.vn",
            default=existing.get("key", ""),
        ).strip()
        if not key:
            click.echo("  API key khong duoc de trong.", err=True)
            return None
        return {"key": key}

    # Fallback: khong co config dac biet
    return {}


def _setup_retry() -> None:
    settings = load_settings()
    profiles = settings.get("profiles", [])

    if not profiles:
        click.echo("Chua co profile nao. Chay `dtik setup` truoc.", err=True)
        sys.exit(1)

    choices = [
        questionary.Choice(title=f"{p.get('alias', p['id'])} ({p['id']})", value=p, checked=True)
        for p in profiles
    ]
    selected = questionary.checkbox(
        "Chon profile de dang nhap lai (Space: chon/bo, Enter: xac nhan)",
        choices=choices,
    ).ask()

    if selected is None:
        return
    if not selected:
        click.echo("Khong co profile nao duoc chon.")
        return

    _open_browsers_for_login(selected)


def _open_browsers_for_login(profiles: list[dict]) -> None:
    for p in profiles:
        path = ensure_profile_exists(p["id"])
        click.echo(f"  Mo Chrome: {p['alias']} ...")
        launch_chrome_for_login(path, url=TIKTOK_URL)
        time.sleep(0.8)

    click.echo(f"\nDa mo {len(profiles)} cua so Chrome.")
    click.echo("Dang nhap TikTok xong thi dong cac cua so la xong.")


def register_setup(main: click.Group) -> None:
    @main.command("setup")
    @click.option("--retry", is_flag=True, help="Mo lai profile cu de dang nhap lai.")
    def cmd_setup(retry: bool) -> None:
        """Cau hinh Chrome profiles va mo TikTok de dang nhap."""
        if retry:
            _setup_retry()
        else:
            _setup_full()
