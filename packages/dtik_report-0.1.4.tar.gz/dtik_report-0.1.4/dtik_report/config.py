"""
Settings manager — luu/doc cau hinh tai ~/.dtik-report/settings.json
"""
from __future__ import annotations

import json

from .constants import APP_DATA_DIR

SETTINGS_FILE = APP_DATA_DIR / "settings.json"


def load_settings() -> dict:
    if not SETTINGS_FILE.exists():
        return {}
    return json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))


def save_settings(settings: dict) -> None:
    APP_DATA_DIR.mkdir(parents=True, exist_ok=True)
    SETTINGS_FILE.write_text(
        json.dumps(settings, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )


def validate_settings(settings: dict) -> None:
    """Raise ValueError neu thieu cac truong bat buoc."""
    engine = settings.get("engine", "browser")
    if engine == "browser" and not settings.get("profiles"):
        raise ValueError("Chua co profile nao. Vui long chay `dtik setup` truoc.")
    if not settings:
        raise ValueError("Chua co cau hinh. Vui long chay `dtik setup` truoc.")


_MAX_RECENT = 10


def get_recent_targets(settings: dict) -> list[str]:
    return settings.get("recent_targets", [])


def add_recent_target(settings: dict, tid: str) -> None:
    """Them tid vao dau danh sach recent, gioi han _MAX_RECENT phan tu."""
    recent: list[str] = settings.get("recent_targets", [])
    # Xoa neu da ton tai de day len dau
    recent = [x for x in recent if x != tid]
    recent.insert(0, tid)
    settings["recent_targets"] = recent[:_MAX_RECENT]
    save_settings(settings)
