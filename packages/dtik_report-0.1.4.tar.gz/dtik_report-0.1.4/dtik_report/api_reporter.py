"""
API-based reporter — dung tls_client gia mao Chrome TLS fingerprint.
Khong can browser, chay nhanh, nhieu thread dong thoi.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed


def report_via_api(
    report_url: str,
    proxy_http: str | None = None,
    timeout_sec: int = 15,
) -> tuple[bool, str]:
    """
    Gui 1 report request toi TikTok bang tls_client.
    Tra ve (success, message).
    """
    try:
        import tls_client
    except ImportError:
        return False, "tls_client chua duoc cai. Chay: pip install tls-client"

    session = tls_client.Session(
        client_identifier="chrome112",
        random_tls_extension_order=True,
    )
    if proxy_http:
        session.proxies = {"http": proxy_http, "https": proxy_http}

    try:
        resp = session.get(report_url, timeout_seconds=timeout_sec)
        if resp.status_code == 200:
            return True, "OK"
        return False, f"HTTP {resp.status_code}"
    except Exception as e:
        return False, str(e)


def report_batch(
    report_url: str,
    threads: int,
    proxy_http: str | None = None,
) -> tuple[int, int]:
    """
    Gui `threads` request dong thoi.
    Tra ve (so_ok, so_fail).
    """
    ok = fail = 0
    with ThreadPoolExecutor(max_workers=threads) as executor:
        futures = [
            executor.submit(report_via_api, report_url, proxy_http)
            for _ in range(threads)
        ]
        for f in as_completed(futures):
            success, _ = f.result()
            if success:
                ok += 1
            else:
                fail += 1
    return ok, fail
