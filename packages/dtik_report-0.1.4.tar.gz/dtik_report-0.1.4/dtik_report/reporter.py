"""
Logic tu dong report mot tai khoan TikTok.
"""
from __future__ import annotations

import time

from playwright.sync_api import Page, TimeoutError as PWTimeoutError

from .constants import (
    SEL_MORE_BUTTON,
    SEL_REPORT_ITEM,
    SEL_REPORT_REASON_STEP1,
    SEL_REPORT_REASON_STEP2,
    SEL_REPORT_REASON_STEP3,
    SEL_REPORT_SUBMIT,
    SEL_REPORT_SUCCESS,
    SEL_REPORT_CONFIRM,
)

STEP_TIMEOUT = 15_000   # ms cho moi wait_for_selector
RETRY_COUNT  = 3        # so lan thu lai neu khong tim thay element
RETRY_DELAY  = 1.5      # giay cho giua cac lan thu


class ReportResult:
    def __init__(self, success: bool, message: str):
        self.success = success
        self.message = message

    def __str__(self) -> str:
        status = "OK" if self.success else "FAIL"
        return f"[{status}] {self.message}"


def _click(page: Page, selector: str, label: str) -> None:
    """
    Cho element xuat hien roi click.
    Thu lai RETRY_COUNT lan neu gap timeout.
    """
    for attempt in range(1, RETRY_COUNT + 1):
        try:
            page.wait_for_selector(selector, state="visible", timeout=STEP_TIMEOUT)
            page.click(selector)
            return
        except PWTimeoutError:
            if attempt < RETRY_COUNT:
                print(f"    [retry {attempt}/{RETRY_COUNT}] Chua tim thay: {label}")
                time.sleep(RETRY_DELAY)
            else:
                raise PWTimeoutError(f"Khong tim thay '{label}' sau {RETRY_COUNT} lan thu (selector: {selector})")


def report_account(page: Page) -> ReportResult:
    """
    Thuc hien day du cac buoc report tren trang profile TikTok.
    Page da duoc navigate den URL profile truoc khi goi ham nay.
    """
    try:
        # B1: Click nut 3 cham (more options)
        _click(page, SEL_MORE_BUTTON, "nut 3 cham")

        # B2: Click "Report" trong popover
        _click(page, SEL_REPORT_ITEM, "Report item")

        # B3: Chon "Report account"
        _click(page, SEL_REPORT_REASON_STEP1, "Report account")

        # B4: Chon "Something else" (card 4)
        _click(page, SEL_REPORT_REASON_STEP2, "Something else")

        # B5: Chon "Frauds and scams" (card 4)
        _click(page, SEL_REPORT_REASON_STEP3, "Frauds and scams")

        # B6: Submit
        _click(page, SEL_REPORT_SUBMIT, "Submit")

        # B7: Cho modal "Thanks for reporting" xuat hien
        page.wait_for_selector(SEL_REPORT_SUCCESS, state="visible", timeout=STEP_TIMEOUT)

        # B8: Click Done de dong modal
        _click(page, SEL_REPORT_CONFIRM, "Done")

        return ReportResult(success=True, message="Report thanh cong")

    except PWTimeoutError as e:
        return ReportResult(success=False, message=f"Timeout: {e}")
    except Exception as e:
        return ReportResult(success=False, message=f"Loi: {e}")
