#!/usr/bin/env zsh
# ----------------------------------------------------------------------------
# run.sh — Khoi dong DTIK Report Tool
# Su dung: ./run.sh setup | ./run.sh run @username | ./run.sh help
# ----------------------------------------------------------------------------
set -e

ROOT="$(cd "$(dirname "$0")" && pwd)"
VENV="$ROOT/.venv"
PYTHON="$VENV/bin/python"
PIP="$VENV/bin/pip"

# 1. Tao virtualenv neu chua co
if [ ! -f "$PYTHON" ]; then
  echo "[run.sh] Tao virtual environment ..."
  python3 -m venv "$VENV"
fi

# 2. Cai dependencies
echo "[run.sh] Kiem tra dependencies ..."
"$PIP" install -q --upgrade pip
"$PIP" install -q -e "$ROOT"

# 3. Cai Playwright browsers neu chua co
if [ ! -d "$HOME/Library/Caches/ms-playwright" ] && [ ! -d "$HOME/.cache/ms-playwright" ]; then
  echo "[run.sh] Cai Playwright browsers ..."
  "$VENV/bin/playwright" install chromium
fi

# 4. Chay lenh — truyen tat ca tham so
echo "[run.sh] Chay: dtik $*"
"$VENV/bin/dtik" "$@"
