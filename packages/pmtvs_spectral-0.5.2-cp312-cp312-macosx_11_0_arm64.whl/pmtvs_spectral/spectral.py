"""
Spectral Analysis Functions

Power spectrum, frequency analysis, and spectral features.
"""

import numpy as np
from typing import Optional, Tuple

import pmtvs_spectral._rust as _rust


def power_spectral_density(
    signal: np.ndarray,
    fs: float = 1.0,
    nperseg: int = 256,
    noverlap: Optional[int] = None
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute power spectral density using Welch's method.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    fs : float
        Sampling frequency
    nperseg : int
        Segment length
    noverlap : int, optional
        Overlap (default: nperseg // 2)

    Returns
    -------
    tuple
        (frequencies, psd)
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    signal = signal[~np.isnan(signal)]
    no = noverlap if noverlap is not None else -1
    freqs, psd = _rust.power_spectral_density(signal, fs, nperseg, no)
    return np.asarray(freqs), np.asarray(psd)


def dominant_frequency(
    signal: np.ndarray,
    fs: float = 1.0
) -> float:
    """
    Find dominant frequency (frequency with highest power).

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    fs : float
        Sampling frequency

    Returns
    -------
    float
        Dominant frequency
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    signal = signal[~np.isnan(signal)]
    return float(_rust.dominant_frequency(signal, fs))


def spectral_entropy(
    signal: np.ndarray,
    fs: float = 1.0,
    normalize: bool = True
) -> float:
    """
    Compute spectral entropy.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    fs : float
        Sampling frequency
    normalize : bool
        Normalize to [0, 1]

    Returns
    -------
    float
        Spectral entropy
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    signal = signal[~np.isnan(signal)]
    return float(_rust.spectral_entropy(signal, fs, normalize))


def spectral_centroid(
    signal: np.ndarray,
    fs: float = 1.0
) -> float:
    """
    Compute spectral centroid (center of mass of spectrum).

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    fs : float
        Sampling frequency

    Returns
    -------
    float
        Spectral centroid frequency
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    signal = signal[~np.isnan(signal)]
    return float(_rust.spectral_centroid(signal, fs))


def spectral_bandwidth(
    signal: np.ndarray,
    fs: float = 1.0,
    p: int = 2
) -> float:
    """
    Compute spectral bandwidth (spread around centroid).

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    fs : float
        Sampling frequency
    p : int
        Order of bandwidth (default: 2)

    Returns
    -------
    float
        Spectral bandwidth
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    signal = signal[~np.isnan(signal)]
    return float(_rust.spectral_bandwidth(signal, fs, p))


def spectral_rolloff(
    signal: np.ndarray,
    fs: float = 1.0,
    threshold: float = 0.85
) -> float:
    """
    Compute spectral rolloff frequency.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    fs : float
        Sampling frequency
    threshold : float
        Energy threshold (default: 85%)

    Returns
    -------
    float
        Rolloff frequency
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    signal = signal[~np.isnan(signal)]
    return float(_rust.spectral_rolloff(signal, fs, threshold))


def spectral_flatness(
    signal: np.ndarray,
    fs: float = 1.0
) -> float:
    """
    Compute spectral flatness (Wiener entropy).

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    fs : float
        Sampling frequency

    Returns
    -------
    float
        Spectral flatness in [0, 1]
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    signal = signal[~np.isnan(signal)]
    return float(_rust.spectral_flatness(signal, fs))


def harmonic_ratio(
    signal: np.ndarray,
    fs: float = 1.0,
    n_harmonics: int = 5
) -> float:
    """
    Compute harmonic-to-noise ratio.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    fs : float
        Sampling frequency
    n_harmonics : int
        Number of harmonics

    Returns
    -------
    float
        Harmonic ratio
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    signal = signal[~np.isnan(signal)]
    return float(_rust.harmonic_ratio(signal, fs, n_harmonics))


def total_harmonic_distortion(
    signal: np.ndarray,
    fs: float = 1.0,
    n_harmonics: int = 10
) -> float:
    """
    Compute total harmonic distortion (THD).

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    fs : float
        Sampling frequency
    n_harmonics : int
        Number of harmonics

    Returns
    -------
    float
        THD
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    signal = signal[~np.isnan(signal)]
    return float(_rust.total_harmonic_distortion(signal, fs, n_harmonics))


def fft_magnitude(
    signal: np.ndarray,
    fs: float = 1.0
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute FFT magnitude spectrum.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    fs : float
        Sampling frequency

    Returns
    -------
    tuple
        (frequencies, magnitudes)
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    signal = signal[~np.isnan(signal)]
    freqs, mags = _rust.fft_magnitude(signal, fs)
    return np.asarray(freqs), np.asarray(mags)


def hilbert_transform(
    signal: np.ndarray
) -> np.ndarray:
    """
    Compute the analytic signal using the Hilbert transform.

    Parameters
    ----------
    signal : np.ndarray
        Input real-valued signal

    Returns
    -------
    np.ndarray
        Complex analytic signal
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    signal = signal[~np.isnan(signal)]
    real, imag = _rust.hilbert_transform(signal)
    return np.asarray(real) + 1j * np.asarray(imag)


def envelope(
    signal: np.ndarray
) -> np.ndarray:
    """
    Compute signal envelope via Hilbert transform.

    Parameters
    ----------
    signal : np.ndarray
        Input signal

    Returns
    -------
    np.ndarray
        Envelope (instantaneous amplitude)
    """
    analytic = hilbert_transform(signal)
    return np.abs(analytic)


def instantaneous_frequency(
    signal: np.ndarray,
    fs: float = 1.0
) -> np.ndarray:
    """
    Compute instantaneous frequency via Hilbert transform.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    fs : float
        Sampling frequency

    Returns
    -------
    np.ndarray
        Instantaneous frequency
    """
    analytic = hilbert_transform(signal)
    phase = np.unwrap(np.angle(analytic))
    inst_freq = np.diff(phase) / (2.0 * np.pi) * fs
    return inst_freq


def instantaneous_amplitude(
    signal: np.ndarray
) -> np.ndarray:
    """
    Compute instantaneous amplitude via Hilbert transform.

    Parameters
    ----------
    signal : np.ndarray
        Input signal

    Returns
    -------
    np.ndarray
        Instantaneous amplitude
    """
    return envelope(signal)


def instantaneous_phase(
    signal: np.ndarray
) -> np.ndarray:
    """
    Compute instantaneous phase via Hilbert transform.

    Parameters
    ----------
    signal : np.ndarray
        Input signal

    Returns
    -------
    np.ndarray
        Instantaneous phase (unwrapped, in radians)
    """
    analytic = hilbert_transform(signal)
    return np.unwrap(np.angle(analytic))


def spectral_slope(
    signal: np.ndarray,
    fs: float = 1.0
) -> float:
    """
    Compute spectral slope via log-log linear regression.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    fs : float
        Sampling frequency

    Returns
    -------
    float
        Spectral slope
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    signal = signal[~np.isnan(signal)]
    return float(_rust.spectral_slope(signal, fs))


def signal_to_noise(
    signal: np.ndarray,
    kernel_fraction: int = 20
) -> dict:
    """
    Estimate signal-to-noise ratio via moving-average separation.

    Parameters
    ----------
    signal : np.ndarray
        Input signal
    kernel_fraction : int
        Denominator for kernel size

    Returns
    -------
    dict
        db, linear, signal_power, noise_power.
    """
    signal = np.ascontiguousarray(np.asarray(signal, dtype=np.float64).flatten())
    signal = signal[~np.isnan(signal)]

    if len(signal) < 10:
        return {
            'db': np.nan, 'linear': np.nan,
            'signal_power': np.nan, 'noise_power': np.nan,
        }

    db, linear, sig_power, noise_power = _rust.signal_to_noise(signal, kernel_fraction)

    return {
        'db': float(db), 'linear': float(linear),
        'signal_power': float(sig_power), 'noise_power': float(noise_power),
    }
