"""
pmtvs-spectral — Spectral analysis primitives.

numpy in, array/number out.
"""

__version__ = "0.5.1"
BACKEND = "rust"

try:
    import pmtvs_spectral._rust  # noqa: F401 — validates Rust extension is loadable
except ImportError as e:
    raise ImportError(
        f"\n\nRust extension not found: {e}\n"
        f"The pmtvs framework requires compiled Rust extensions.\n"
        f"Install with: cd packages/pmtvs-spectral && maturin develop --release\n"
        f"Or rebuild the Docker image.\n"
    ) from e

from pmtvs_spectral.spectral import (
    power_spectral_density,
    dominant_frequency,
    spectral_entropy,
    spectral_centroid,
    spectral_bandwidth,
    spectral_rolloff,
    spectral_flatness,
    harmonic_ratio,
    total_harmonic_distortion,
    fft_magnitude,
    hilbert_transform,
    envelope,
    instantaneous_frequency,
    instantaneous_amplitude,
    instantaneous_phase,
    spectral_slope,
    signal_to_noise,
)

__all__ = [
    "__version__",
    "BACKEND",
    "power_spectral_density",
    "dominant_frequency",
    "spectral_entropy",
    "spectral_centroid",
    "spectral_bandwidth",
    "spectral_rolloff",
    "spectral_flatness",
    "harmonic_ratio",
    "total_harmonic_distortion",
    "fft_magnitude",
    "hilbert_transform",
    "envelope",
    "instantaneous_frequency",
    "instantaneous_amplitude",
    "instantaneous_phase",
    "spectral_slope",
    "signal_to_noise",
]
