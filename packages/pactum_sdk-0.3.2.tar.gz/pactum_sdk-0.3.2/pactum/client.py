"""
Pactum SDK — Python client for the Pactum marketplace.

Setup:
    from pactum import PactumClient

    # Register (one-time)
    api_key, wallet = PactumClient.register("user@example.com")
    # → check email for 6-digit code
    api_key, wallet = PactumClient.verify("user@example.com", "123456")

    client = PactumClient(api_key=api_key)

Buyer usage:
    items = client.search("BTC whale positions")
    result = client.buy(items[0]["item_id"], query="BTC whale positions last 24h")

Seller usage:
    client.register_seller(description="Crypto Data API")
    client.list_item(name="Whale Tracker", description="Track whale positions", price=0.001)
    orders = client.get_orders(status="paid")
    client.deliver(orders[0]["order_id"], content="result data")
"""

from __future__ import annotations

import json
import base64
import time
from typing import Any

import requests

from .exceptions import (
    PactumError,
    AuthError,
    PaymentError,
    InsufficientCreditError,
    OrderError,
    OrderTimeoutError,
)

_DEFAULT_GATEWAY = "https://api.pactum.cc"
_DEFAULT_WALLET = "https://www.pactum.cc"


class PactumClient:
    """Pactum marketplace client."""

    def __init__(
        self,
        api_key: str,
        *,
        gateway_url: str = _DEFAULT_GATEWAY,
        wallet_url: str = _DEFAULT_WALLET,
        payment_method: str = "credit",
    ):
        """
        Args:
            api_key: Wallet API key (pk_live_...).
            gateway_url: Gateway API base URL.
            wallet_url: Wallet service base URL.
            payment_method: Default payment method ("credit" or "escrow").
        """
        self.api_key = api_key
        self.gateway_url = gateway_url.rstrip("/")
        self.wallet_url = wallet_url.rstrip("/")
        self.payment_method = payment_method
        self._token: str | None = None
        self._session = requests.Session()

    # ── wallet setup (static) ──────────────────────────────

    @staticmethod
    def register(
        email: str,
        *,
        wallet_url: str = _DEFAULT_WALLET,
    ) -> dict:
        """
        Register a new wallet. Sends a verification code to the email.

        Args:
            email: Email address to register.

        Returns:
            {"message": "Verification code sent"}

        Next step: call PactumClient.verify(email, code) with the 6-digit code.
        """
        r = requests.post(f"{wallet_url.rstrip('/')}/v1/register", json={"email": email})
        if r.status_code != 200:
            raise PactumError(f"Registration failed: {r.text}", r.status_code)
        return r.json()

    @staticmethod
    def verify(
        email: str,
        code: str,
        *,
        wallet_url: str = _DEFAULT_WALLET,
    ) -> tuple[str, str]:
        """
        Verify email with the 6-digit code.

        Args:
            email: Email used in register().
            code: 6-digit verification code from email.

        Returns:
            (api_key, wallet_address) tuple.
        """
        r = requests.post(
            f"{wallet_url.rstrip('/')}/v1/verify",
            json={"email": email, "code": code},
        )
        if r.status_code != 200:
            raise AuthError(f"Verification failed: {r.text}", r.status_code)
        data = r.json()
        return data["api_key"], data["wallet_address"]

    @staticmethod
    def recover(
        email: str,
        code: str,
        *,
        wallet_url: str = _DEFAULT_WALLET,
    ) -> tuple[str, str]:
        """
        Recover a lost API key with email + verification code.

        Call register() first to send a new code, then recover() with the code.

        Returns:
            (api_key, wallet_address) tuple.
        """
        r = requests.post(
            f"{wallet_url.rstrip('/')}/v1/recover",
            json={"email": email, "code": code},
        )
        if r.status_code != 200:
            raise AuthError(f"Recovery failed: {r.text}", r.status_code)
        data = r.json()
        return data["api_key"], data["wallet_address"]

    # ── auth ─────────────────────────────────────────────

    def _refresh_token(self) -> str:
        r = self._session.post(
            f"{self.gateway_url}/market/auth/wallet",
            json={"api_key": self.api_key},
        )
        if r.status_code != 200:
            raise AuthError(f"Auth failed: {r.text}", r.status_code, r.json() if r.text else {})
        self._token = r.json()["token"]
        return self._token

    def _token_valid(self) -> bool:
        if not self._token:
            return False
        try:
            part = self._token.split(".")[1]
            part += "=" * (-len(part) % 4)
            payload = json.loads(base64.b64decode(part))
            return payload["exp"] > time.time() + 60
        except Exception:
            return False

    def _ensure_token(self) -> str:
        if not self._token_valid():
            self._refresh_token()
        return self._token

    def _auth_headers(self) -> dict:
        return {"Authorization": f"Bearer {self._ensure_token()}"}

    def _wallet_headers(self) -> dict:
        return {"Authorization": f"Bearer {self.api_key}"}

    def _request(
        self,
        method: str,
        url: str,
        *,
        auth: str = "gateway",
        retry_auth: bool = True,
        **kwargs,
    ) -> requests.Response:
        """Make an HTTP request with auto auth-refresh on 401."""
        headers = kwargs.pop("headers", {})
        if auth == "gateway":
            headers.update(self._auth_headers())
        elif auth == "wallet":
            headers.update(self._wallet_headers())

        r = self._session.request(method, url, headers=headers, **kwargs)

        if r.status_code == 401 and retry_auth and auth == "gateway":
            self._refresh_token()
            headers.update(self._auth_headers())
            r = self._session.request(method, url, headers=headers, **kwargs)
            if r.status_code == 401:
                raise AuthError("Authentication failed after refresh", 401)

        return r

    # ── search / discover ────────────────────────────────

    def search(self, q: str = "", **filters) -> list[dict]:
        """
        Search marketplace items.

        Args:
            q: Natural language search query.
            **filters: tags, category, type, min_price, max_price,
                       seller, sort, limit, offset.

        Returns:
            List of item dicts.
        """
        body = {"q": q, **filters}
        r = self._request("POST", f"{self.gateway_url}/market/discover", json=body, auth="none")
        r.raise_for_status()
        return r.json()["items"]

    def get_item(self, item_id: str) -> dict:
        """Get a single item by ID."""
        r = self._request("GET", f"{self.gateway_url}/market/items/{item_id}", auth="none")
        r.raise_for_status()
        return r.json()

    # ── buy ───────────────────────────────────────────────

    def buy(
        self,
        item_id: str,
        *,
        query: str | None = None,
        payment_method: str | None = None,
        wait: bool = True,
        poll_interval: float = 2.0,
        timeout: float = 300.0,
    ) -> dict:
        """
        Buy an item. Handles the full flow: payment → delivery → result.

        Args:
            item_id: Item to buy.
            query: Request text for the seller (required if item.required.description is true).
            payment_method: "credit" or "escrow". Defaults to client-level setting.
            wait: If True, poll until order completes or times out.
            poll_interval: Seconds between polls (when wait=True).
            timeout: Max seconds to wait for delivery (when wait=True).

        Returns:
            Order dict. If wait=True and order completed, includes result.

        Raises:
            InsufficientCreditError: Credit balance too low.
            PaymentError: Escrow deposit or payment proof failed.
            OrderTimeoutError: Timed out waiting for delivery (when wait=True).
            OrderError: Order failed after delivery.
        """
        method = payment_method or self.payment_method

        body: dict[str, Any] = {"payment_method": method}
        if query is not None:
            body["query"] = query

        if method == "credit":
            return self._buy_credit(item_id, body, wait=wait, poll_interval=poll_interval, timeout=timeout)
        else:
            return self._buy_escrow(item_id, body, wait=wait, poll_interval=poll_interval, timeout=timeout)

    def _buy_credit(
        self,
        item_id: str,
        body: dict,
        *,
        wait: bool,
        poll_interval: float,
        timeout: float,
    ) -> dict:
        r = self._request("POST", f"{self.gateway_url}/market/buy/{item_id}", json=body)

        if r.status_code == 400:
            data = r.json()
            if data.get("error") == "INSUFFICIENT_CREDIT":
                raise InsufficientCreditError(
                    f"Insufficient credit: {data.get('message', '')}",
                    400, data,
                )
            raise PactumError(data.get("message", r.text), 400, data)

        if r.status_code not in (200, 201):
            raise PaymentError(f"Buy failed: {r.status_code} {r.text}", r.status_code)

        order = r.json()
        if wait:
            return self._wait_for_order(order["order_id"], poll_interval, timeout)
        return order

    def _buy_escrow(
        self,
        item_id: str,
        body: dict,
        *,
        wait: bool,
        poll_interval: float,
        timeout: float,
    ) -> dict:
        # Step 1: initial buy → 402
        r = self._request("POST", f"{self.gateway_url}/market/buy/{item_id}", json=body)

        if r.status_code == 400:
            data = r.json()
            raise PactumError(data.get("message", r.text), 400, data)
        if r.status_code != 402:
            if r.status_code in (200, 201):
                order = r.json()
                return self._wait_for_order(order["order_id"], poll_interval, timeout) if wait else order
            raise PaymentError(f"Expected 402, got {r.status_code}: {r.text}", r.status_code)

        data = r.json()
        order_id = data["order_id"]
        recipient = data["recipient"]
        amount_units = data["amount_units"]
        escrow_info = data["escrow"]

        # Step 2: escrow deposit via wallet service
        deposit_body = {
            "escrow_contract": escrow_info["contract"],
            "usdc_contract": escrow_info["usdc_contract"],
            "order_id_bytes32": escrow_info["order_id_bytes32"],
            "seller": recipient,
            "amount": amount_units / 1_000_000,
        }
        r2 = self._request(
            "POST",
            f"{self.wallet_url}/v1/escrow-deposit",
            json=deposit_body,
            auth="wallet",
        )
        if r2.status_code != 200:
            raise PaymentError(f"Escrow deposit failed: {r2.status_code} {r2.text}", r2.status_code)

        tx_hash = r2.json()["deposit_tx"]

        # Step 3: submit payment proof
        r3 = self._request(
            "POST",
            f"{self.gateway_url}/market/buy/{item_id}",
            headers={"X-Payment-Proof": tx_hash, "X-Order-Id": order_id},
            json={},
        )
        if r3.status_code not in (200, 201):
            raise PaymentError(
                f"Payment proof failed: {r3.status_code} {r3.text}. "
                f"Deposit tx: {tx_hash} — do NOT deposit again, retry proof only.",
                r3.status_code,
            )

        order = r3.json()
        if wait:
            return self._wait_for_order(order["order_id"], poll_interval, timeout)
        return order

    def _wait_for_order(
        self,
        order_id: str,
        poll_interval: float,
        timeout: float,
    ) -> dict:
        """Poll order until it reaches a terminal state or times out."""
        deadline = time.time() + timeout

        while time.time() < deadline:
            order = self.get_order(order_id)
            status = order.get("status")

            if status in ("completed", "delivered"):
                return order
            if status == "failed":
                raise OrderError(
                    f"Order {order_id} failed: {order.get('result', {}).get('error', 'unknown')}",
                    body=order,
                )
            if status in ("disputed", "refunded"):
                raise OrderError(f"Order {order_id} is {status}", body=order)

            time.sleep(poll_interval)

        raise OrderTimeoutError(f"Order {order_id} timed out after {timeout}s")

    # ── orders ────────────────────────────────────────────

    def get_orders(self, *, status: str | None = None) -> list[dict]:
        """Get all orders, optionally filtered by status."""
        params = {}
        if status:
            params["status"] = status
        r = self._request("GET", f"{self.gateway_url}/market/orders", params=params)
        r.raise_for_status()
        return r.json()["orders"]

    def get_order(self, order_id: str) -> dict:
        """Get a single order by ID."""
        r = self._request("GET", f"{self.gateway_url}/market/orders/{order_id}")
        r.raise_for_status()
        return r.json()

    def confirm_order(self, order_id: str) -> dict:
        """Confirm order and release funds to seller."""
        r = self._request("POST", f"{self.gateway_url}/market/orders/{order_id}/confirm")
        r.raise_for_status()
        return r.json()

    def retry_order(self, order_id: str) -> dict:
        """Retry a failed order (up to 3 times)."""
        r = self._request("POST", f"{self.gateway_url}/market/orders/{order_id}/retry")
        r.raise_for_status()
        return r.json()

    def dispute_order(self, order_id: str, reason: str = "") -> dict:
        """Open a dispute on an order."""
        r = self._request(
            "POST",
            f"{self.gateway_url}/market/orders/{order_id}/dispute",
            json={"reason": reason} if reason else {},
        )
        r.raise_for_status()
        return r.json()

    def send_message(self, order_id: str, content: str) -> dict:
        """Send a message on an order."""
        r = self._request(
            "POST",
            f"{self.gateway_url}/market/orders/{order_id}/messages",
            json={"content": content},
        )
        r.raise_for_status()
        return r.json()

    def get_messages(self, order_id: str) -> list[dict]:
        """Get messages for an order."""
        r = self._request("GET", f"{self.gateway_url}/market/orders/{order_id}/messages")
        r.raise_for_status()
        return r.json()["messages"]

    # ── balance ───────────────────────────────────────────

    def get_balance(self) -> dict:
        """Get wallet USDC balance."""
        r = self._request("GET", f"{self.wallet_url}/v1/balance", auth="wallet")
        r.raise_for_status()
        return r.json()

    def get_credit_balance(self) -> dict:
        """Get credit balance (available, frozen, total)."""
        r = self._request("GET", f"{self.gateway_url}/market/credit/balance")
        r.raise_for_status()
        return r.json()

    def topup_credit(self, amount: float, provider: str = "stripe") -> dict:
        """
        Top up credit balance via Stripe/Alipay/WeChat.

        Args:
            amount: USD amount to add.
            provider: "stripe" (card/Apple Pay), "alipay", or "wechat".

        Returns:
            {"checkout_url": "https://..."} — open this URL to complete payment.
        """
        r = self._request(
            "POST",
            f"{self.gateway_url}/market/credit/topup",
            json={"amount": amount, "provider": provider},
        )
        r.raise_for_status()
        return r.json()

    def get_credit_transactions(self) -> list[dict]:
        """Get credit transaction history."""
        r = self._request("GET", f"{self.gateway_url}/market/credit/transactions")
        r.raise_for_status()
        return r.json()["transactions"]

    def set_shipping_address(self, address: dict) -> dict:
        """
        Set shipping address for physical item purchases.

        Args:
            address: {"name", "street", "city", "state", "postal_code", "country"}
        """
        r = self._request(
            "PUT",
            f"{self.gateway_url}/market/address",
            json={"address": address},
        )
        r.raise_for_status()
        return r.json()

    # ── seller ────────────────────────────────────────────

    def register_seller(
        self,
        *,
        description: str = "",
        name: str | None = None,
        endpoint: str | None = None,
    ) -> dict:
        """
        Register as a seller. Mints a PactumAgent NFT.
        The client's JWT is automatically updated after registration.
        """
        body: dict[str, Any] = {}
        if description:
            body["description"] = description
        if name:
            body["name"] = name
        if endpoint:
            body["endpoint"] = endpoint

        r = self._request("POST", f"{self.gateway_url}/market/register/seller", json=body)
        if r.status_code != 200:
            raise PactumError(f"Seller registration failed: {r.text}", r.status_code)

        data = r.json()
        self._token = data["token"]
        return data

    def list_item(
        self,
        *,
        name: str,
        description: str,
        price: float,
        item_type: str = "digital",
        required: dict | None = None,
        endpoint: str | None = None,
        quota: dict | None = None,
        tags: list[str] | None = None,
    ) -> dict:
        """List a new item for sale."""
        body: dict[str, Any] = {
            "name": name,
            "description": description,
            "price": price,
            "type": item_type,
            "required": required,
        }
        if endpoint:
            body["endpoint"] = endpoint
        if quota:
            body["quota"] = quota

        r = self._request("POST", f"{self.gateway_url}/market/items", json=body)
        if r.status_code != 200:
            raise PactumError(f"List item failed: {r.text}", r.status_code)

        item = r.json()

        if tags:
            self.update_item(item["item_id"], tags=tags)

        return item

    def update_item(self, item_id: str, **fields) -> dict:
        """Update an existing item (price, status, tags, metadata, capabilities, etc.)."""
        r = self._request(
            "PATCH",
            f"{self.gateway_url}/market/items/{item_id}",
            json=fields,
        )
        r.raise_for_status()
        return r.json()

    def deliver(self, order_id: str, content: str, tracking: str | None = None) -> dict:
        """Deliver text result for an order."""
        body: dict[str, Any] = {"content": content}
        if tracking:
            body["tracking"] = tracking
        r = self._request(
            "POST",
            f"{self.gateway_url}/market/orders/{order_id}/deliver",
            json=body,
        )
        r.raise_for_status()
        return r.json()

    def deliver_file(self, order_id: str, file_path: str, message: str | None = None) -> dict:
        """
        Deliver a file for an order (max 30MB).

        Args:
            order_id: Order to deliver.
            file_path: Local path to the file.
            message: Optional text message with the file.
        """
        import os
        data = {"content": message} if message else {}
        with open(file_path, "rb") as f:
            files = {"file": (os.path.basename(file_path), f)}
            r = self._request(
                "POST",
                f"{self.gateway_url}/market/orders/{order_id}/deliver-file",
                files=files,
                data=data,
            )
        r.raise_for_status()
        return r.json()

    def refund_order(self, order_id: str) -> dict:
        """Refund an order (seller only)."""
        r = self._request("POST", f"{self.gateway_url}/market/orders/{order_id}/refund")
        r.raise_for_status()
        return r.json()
