"""AgenticEvolve — Pattern library for AI agents.

Pure-Python SDK that wraps the ``evolve`` CLI binary via subprocess.
Zero required dependencies; only stdlib: subprocess, json, pathlib, dataclasses.
"""

from __future__ import annotations

import json
import logging
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

__version__ = "0.1.0"

logger = logging.getLogger(__name__)


class EvolveError(Exception):
    """Raised when an evolve CLI command fails."""


@dataclass
class EvolveStore:
    """Interface to an ``.evolve`` pattern library file.

    Parameters
    ----------
    path : str | Path
        Path to the ``.evolve`` file. Created automatically on first write
        if it does not exist.
    binary : str
        Name or path of the ``evolve`` CLI binary.
    """

    path: str | Path
    binary: str = "evolve"
    _resolved_binary: Optional[str] = field(default=None, repr=False, init=False)

    def __post_init__(self) -> None:
        self.path = Path(self.path)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _find_binary(self) -> str:
        if self._resolved_binary is not None:
            return self._resolved_binary

        import shutil

        found = shutil.which(self.binary)
        if found is None:
            raise EvolveError(
                f"Cannot find '{self.binary}' on PATH. "
                "Install AgenticEvolve: curl -fsSL https://agentralabs.tech/install/evolve | bash"
            )
        self._resolved_binary = found
        return found

    def _run(self, *args: str, check: bool = True) -> str:
        """Execute an evolve CLI command and return stdout."""
        cmd = [self._find_binary(), "--file", str(self.path), *args]
        logger.debug("Running: %s", " ".join(cmd))
        result = subprocess.run(cmd, capture_output=True, text=True)
        if check and result.returncode != 0:
            raise EvolveError(
                f"evolve command failed (exit {result.returncode}): {result.stderr.strip()}"
            )
        return result.stdout.strip()

    def _run_json(self, *args: str) -> Any:
        """Execute a command and parse JSON output."""
        raw = self._run(*args, "--format", "json")
        return json.loads(raw) if raw else {}

    # ------------------------------------------------------------------
    # Pattern operations
    # ------------------------------------------------------------------

    def store_pattern(
        self,
        name: str,
        *,
        language: Optional[str] = None,
        body: Optional[str] = None,
    ) -> str:
        """Store a code pattern. Returns the pattern ID."""
        args = ["pattern", "store", name]
        if language:
            args.extend(["--language", language])
        if body:
            args.extend(["--body", body])
        return self._run(*args)

    def match_pattern(
        self,
        query: str,
        *,
        language: Optional[str] = None,
    ) -> list[dict[str, Any]]:
        """Match patterns by query. Returns matching patterns as JSON."""
        args = ["match", "signature", query, "--format", "json"]
        if language:
            args.extend(["--language", language])
        raw = self._run(*args)
        return json.loads(raw) if raw else []

    def list_patterns(self) -> list[dict[str, Any]]:
        """List all stored patterns."""
        raw = self._run("pattern", "list", "--format", "json")
        return json.loads(raw) if raw else []

    def crystallize(self) -> str:
        """Crystallize verified patterns for reuse. Returns summary."""
        return self._run("crystallize")

    # ------------------------------------------------------------------
    # Stats
    # ------------------------------------------------------------------

    def stats(self) -> dict[str, Any]:
        """Get evolve store statistics."""
        raw = self._run("stats", "--format", "json")
        return json.loads(raw) if raw else {}

    # ------------------------------------------------------------------
    # File operations
    # ------------------------------------------------------------------

    def save(self) -> None:
        """Explicit save (most operations auto-save)."""
        pass

    @property
    def exists(self) -> bool:
        """Whether the .evolve file exists on disk."""
        return self.path.exists()
