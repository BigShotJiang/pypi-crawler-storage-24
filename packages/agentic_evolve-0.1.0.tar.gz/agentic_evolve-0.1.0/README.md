# AgenticEvolve Python SDK

Pattern library for AI agents -- store, match, and crystallize verified code patterns for reuse.

## Install

```bash
pip install agentic-evolve
```

## Usage

```python
from agentic_evolve import EvolveStore

es = EvolveStore("project.evolve")
es.store_pattern("error-handler", language="python", body="try/except with logging")
es.match_pattern("error handling")
es.crystallize()
```

Requires the `evolve` CLI binary on PATH. Install via:

```bash
curl -fsSL https://agentralabs.tech/install/evolve | bash
```
