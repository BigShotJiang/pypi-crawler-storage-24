# Core tests for xwentity
