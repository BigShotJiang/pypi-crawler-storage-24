# Tests for xwentity library
