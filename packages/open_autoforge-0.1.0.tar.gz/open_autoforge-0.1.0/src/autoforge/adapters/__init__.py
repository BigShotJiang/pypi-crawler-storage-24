"""Metric adapters for AutoForge."""
