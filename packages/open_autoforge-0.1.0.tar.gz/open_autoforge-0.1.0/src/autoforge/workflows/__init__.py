"""Workflow configurations for AutoForge."""
