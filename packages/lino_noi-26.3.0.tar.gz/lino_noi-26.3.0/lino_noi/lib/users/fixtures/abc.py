from lino.modlib.users.fixtures.abc import *
