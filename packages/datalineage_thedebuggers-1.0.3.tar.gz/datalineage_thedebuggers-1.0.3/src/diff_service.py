import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List

import numpy as np
import pandas as pd

from src.errors import DataLineageError
from src.repo import RepoState


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _load_processed_dataframe(version_dir: Path) -> pd.DataFrame:
    import zipfile
    import tempfile
    import os
    tmp_path = None
    try:
        processed_csv = version_dir / "processed.csv"
        processed_txt = version_dir / "processed.txt"
        processed_json = version_dir / "processed.json"
        processed_csv_zip = version_dir / "processed.csv.zip"
        processed_txt_zip = version_dir / "processed.txt.zip"
        processed_json_zip = version_dir / "processed.json.zip"
        if processed_csv.exists():
            processed_file = processed_csv
        elif processed_txt.exists():
            processed_file = processed_txt
        elif processed_json.exists():
            processed_file = processed_json
        elif processed_csv_zip.exists():
            with zipfile.ZipFile(processed_csv_zip, 'r') as zf:
                if 'processed.csv' not in zf.namelist():
                    raise DataLineageError(f"processed.csv.zip does not contain processed.csv in {version_dir}")
                with tempfile.NamedTemporaryFile(delete=False, suffix='.csv') as tmp:
                    tmp.write(zf.read('processed.csv'))
                    tmp_path = tmp.name
            processed_file = Path(tmp_path)
        elif processed_txt_zip.exists():
            with zipfile.ZipFile(processed_txt_zip, 'r') as zf:
                if 'processed.txt' not in zf.namelist():
                    raise DataLineageError(f"processed.txt.zip does not contain processed.txt in {version_dir}")
                with tempfile.NamedTemporaryFile(delete=False, suffix='.txt') as tmp:
                    tmp.write(zf.read('processed.txt'))
                    tmp_path = tmp.name
            processed_file = Path(tmp_path)
        elif processed_json_zip.exists():
            with zipfile.ZipFile(processed_json_zip, 'r') as zf:
                if 'processed.json' not in zf.namelist():
                    raise DataLineageError(f"processed.json.zip does not contain processed.json in {version_dir}")
                with tempfile.NamedTemporaryFile(delete=False, suffix='.json') as tmp:
                    tmp.write(zf.read('processed.json'))
                    tmp_path = tmp.name
            processed_file = Path(tmp_path)
        else:
            raise DataLineageError(
                f"Processed artifact missing: {processed_csv}, {processed_txt}, {processed_json}, {processed_csv_zip}, {processed_txt_zip}, or {processed_json_zip}"
            )
        from src.io_loader import load_dataset
        df, _ = load_dataset(str(processed_file))
    finally:
        if tmp_path is not None:
            try:
                os.unlink(tmp_path)
            except Exception:
                pass
    return df


def _load_metadata(version_dir: Path) -> Dict[str, Any]:
    metadata_file = version_dir / "metadata.json"
    if not metadata_file.exists():
        raise DataLineageError(f"Metadata artifact missing: {metadata_file}")
    try:
        return json.loads(metadata_file.read_text(encoding="utf-8"))
    except json.JSONDecodeError as error:
        raise DataLineageError(f"Invalid metadata JSON: {metadata_file}") from error


def _load_config_snapshot(version_dir: Path) -> Dict[str, Any]:
    """Load config_snapshot.json stored inside the version folder."""
    config_file = version_dir / "config_snapshot.json"
    if not config_file.exists():
        return {}
    try:
        return json.loads(config_file.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return {}


def _now_utc_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _tokenize(text) -> set:
    if pd.isna(text):
        return set()
    return set(re.findall(r"\w+", str(text).lower()))


# ---------------------------------------------------------------------------
# Config diff
# ---------------------------------------------------------------------------

def _diff_configs(config_a: Dict, config_b: Dict) -> Dict[str, Any]:
    IMPACT_MAP = {
        "lowercase_text":         ("MODERATE", "Text case normalisation changed — affects vocab and token matching."),
        "remove_punctuation":     ("MODERATE", "Punctuation removal changed — affects token boundaries and vocab."),
        "remove_urls":            ("LOW",       "URL stripping changed — minor effect on text content."),
        "remove_stopwords":       ("HIGH",      "Stopword removal changed — significantly affects vocab and BoW F1."),
        "tokenize":               ("HIGH",      "Tokenisation changed — affects how text is split and evaluated."),
        "null_strategy":          ("HIGH",      "Null handling strategy changed — can alter row count significantly."),
        "drop_nulls":             ("MODERATE",  "Null dropping changed — may change row count."),
        "drop_duplicates":        ("MODERATE",  "Duplicate removal changed — may change row count."),
        "select_columns":         ("HIGH",      "Column selection changed — dataset structure is different."),
        "drop_columns":           ("HIGH",      "Columns dropped changed — dataset structure is different."),
        "filter_numeric":         ("HIGH",      "Numeric row filter changed — row count will differ."),
        "filter_include":         ("HIGH",      "Row include filter changed — row count will differ."),
        "filter_exclude":         ("HIGH",      "Row exclude filter changed — row count will differ."),
        "value_mappings":         ("MODERATE",  "Value mappings changed — label/category encoding differs."),
        "rename_columns":         ("LOW",       "Column names changed — same data, different labels."),
        "label_column":           ("HIGH",      "Label column changed — F1 and evaluation will differ."),
        "text_columns":           ("HIGH",      "Text column(s) changed — BoW and vocabulary will differ."),
        "coerce_numeric_columns": ("LOW",       "Numeric coercion changed — minor dtype effect."),
    }
    all_keys = set(config_a.keys()) | set(config_b.keys())
    changed = {}
    only_in_a = {}
    only_in_b = {}
    for key in sorted(all_keys):
        if key in config_a and key in config_b:
            if config_a[key] != config_b[key]:
                sev, expl = IMPACT_MAP.get(key, ("LOW", f"Config key '{key}' changed."))
                changed[key] = {"a": config_a[key], "b": config_b[key],
                                "impact": sev, "explanation": expl}
        elif key in config_a:
            only_in_a[key] = config_a[key]
        else:
            only_in_b[key] = config_b[key]
    return {
        "changed": changed,
        "only_in_a": only_in_a,
        "only_in_b": only_in_b,
        "total_changes": len(changed) + len(only_in_a) + len(only_in_b),
    }


# ---------------------------------------------------------------------------
# Preprocessing impact diff
# ---------------------------------------------------------------------------

def _preprocess_impact(meta_a: Dict, meta_b: Dict) -> Dict[str, Any]:
    stats_a = meta_a.get("preprocess_stats", {})
    stats_b = meta_b.get("preprocess_stats", {})

    def retention(before, after):
        if not before:
            return 100.0
        return round(after / before * 100, 2)

    rows_before_a = stats_a.get("rows_before", meta_a.get("row_count", 0))
    rows_after_a  = stats_a.get("rows_after",  meta_a.get("row_count", 0))
    rows_before_b = stats_b.get("rows_before", meta_b.get("row_count", 0))
    rows_after_b  = stats_b.get("rows_after",  meta_b.get("row_count", 0))
    cols_before_a = stats_a.get("columns_before", [])
    cols_after_a  = stats_a.get("columns_after",  [])
    cols_before_b = stats_b.get("columns_before", [])
    cols_after_b  = stats_b.get("columns_after",  [])

    return {
        "version_a": {
            "rows_before": rows_before_a, "rows_after": rows_after_a,
            "retention_pct": retention(rows_before_a, rows_after_a),
            "cols_dropped": sorted(set(cols_before_a) - set(cols_after_a)),
            "cols_added":   sorted(set(cols_after_a)  - set(cols_before_a)),
        },
        "version_b": {
            "rows_before": rows_before_b, "rows_after": rows_after_b,
            "retention_pct": retention(rows_before_b, rows_after_b),
            "cols_dropped": sorted(set(cols_before_b) - set(cols_after_b)),
            "cols_added":   sorted(set(cols_after_b)  - set(cols_before_b)),
        },
    }


# ---------------------------------------------------------------------------
# Row-level diff — index-aligned (NOT set-based)
# ---------------------------------------------------------------------------

def _row_level_diff(df_a: pd.DataFrame, df_b: pd.DataFrame,
                    common_cols: List[str], n: int = 10) -> Dict[str, Any]:
    """
    Compare rows by position (index-aligned). This correctly detects
    text transformations (lowercase, stopword removal, etc.) as CHANGED rows.

    The old set-based approach treated every transformed row as a brand-new
    row (added) and the original as deleted — showing 0 changed rows always.
    """
    a = df_a[common_cols].reset_index(drop=True) if common_cols else df_a.reset_index(drop=True)
    b = df_b[common_cols].reset_index(drop=True) if common_cols else df_b.reset_index(drop=True)

    len_a, len_b = len(a), len(b)
    min_len = min(len_a, len_b)

    changed_rows = []
    for i in range(min_len):
        row_diffs = {}
        for col in (common_cols or list(a.columns)):
            val_a = a.iloc[i][col]
            val_b = b.iloc[i][col]
            str_a = "NaN" if (isinstance(val_a, float) and pd.isna(val_a)) else str(val_a)
            str_b = "NaN" if (isinstance(val_b, float) and pd.isna(val_b)) else str(val_b)
            if str_a != str_b:
                row_diffs[col] = {"a": str_a, "b": str_b}
        if row_diffs:
            changed_rows.append({"row_index": i, "diffs": row_diffs})

    added_rows   = [b.iloc[i].tolist() for i in range(len_a, len_b)] if len_b > len_a else []
    removed_rows = [a.iloc[i].tolist() for i in range(len_b, len_a)] if len_a > len_b else []

    return {
        "changed_rows_total":  len(changed_rows),
        "added_rows_total":    len(added_rows),
        "removed_rows_total":  len(removed_rows),
        "changed_rows_sample": changed_rows[:n],
        "added_rows_sample":   added_rows[:n],
        "removed_rows_sample": removed_rows[:n],
        "columns":             common_cols,
    }


# ---------------------------------------------------------------------------
# Semantic diff per column
# ---------------------------------------------------------------------------

def _semantic_diff(df_a: pd.DataFrame, df_b: pd.DataFrame,
                   common_cols: List[str]) -> Dict[str, Any]:
    stats = {}
    for col in common_cols:
        s: Dict[str, Any] = {}
        is_num_a = pd.api.types.is_numeric_dtype(df_a[col])
        is_num_b = pd.api.types.is_numeric_dtype(df_b[col])
        is_txt_a = df_a[col].dtype == object or pd.api.types.is_string_dtype(df_a[col])
        is_txt_b = df_b[col].dtype == object or pd.api.types.is_string_dtype(df_b[col])

        if is_num_a and is_num_b:
            s["type"] = "numeric"
            s["mean_a"]     = round(float(df_a[col].mean()), 4) if len(df_a) else 0
            s["mean_b"]     = round(float(df_b[col].mean()), 4) if len(df_b) else 0
            s["mean_shift"] = round(s["mean_b"] - s["mean_a"], 4)
            s["std_a"]      = round(float(df_a[col].std()), 4)  if len(df_a) else 0
            s["std_b"]      = round(float(df_b[col].std()), 4)  if len(df_b) else 0
            s["std_shift"]  = round(s["std_b"] - s["std_a"], 4)
            s["null_count_a"] = int(df_a[col].isna().sum())
            s["null_count_b"] = int(df_b[col].isna().sum())
            s["null_delta"]   = s["null_count_b"] - s["null_count_a"]

        elif is_txt_a or is_txt_b:
            s["type"] = "text"
            toks_a = df_a[col].dropna().map(_tokenize)
            toks_b = df_b[col].dropna().map(_tokenize)
            vocab_a = set().union(*toks_a) if not toks_a.empty else set()
            vocab_b = set().union(*toks_b) if not toks_b.empty else set()
            words_lost   = sorted(vocab_a - vocab_b)
            words_gained = sorted(vocab_b - vocab_a)
            overlap_pct  = (len(vocab_a & vocab_b) / max(1, len(vocab_a | vocab_b)) * 100
                            if (vocab_a or vocab_b) else 100.0)
            lost_ratio   = len(words_lost) / max(1, len(vocab_a))
            oov_risk     = "HIGH" if lost_ratio > 0.3 else ("MEDIUM" if lost_ratio > 0.1 else "LOW")

            s["vocab_size_a"]        = len(vocab_a)
            s["vocab_size_b"]        = len(vocab_b)
            s["vocab_overlap_pct"]   = round(overlap_pct, 2)
            s["words_lost_count"]    = len(words_lost)
            s["words_gained_count"]  = len(words_gained)
            s["words_lost_sample"]   = words_lost[:20]
            s["words_gained_sample"] = words_gained[:20]
            s["oov_risk"]            = oov_risk

            def tlen(series):
                ll = series.dropna().map(lambda x: len(str(x)))
                if ll.empty:
                    return {"mean": 0, "std": 0, "min": 0, "max": 0}
                return {"mean": round(float(ll.mean()), 2), "std": round(float(ll.std()), 2),
                        "min": int(ll.min()), "max": int(ll.max())}
            s["text_length_a"] = tlen(df_a[col])
            s["text_length_b"] = tlen(df_b[col])
            s["mean_length_delta"] = round(s["text_length_b"]["mean"] - s["text_length_a"]["mean"], 2)
            s["null_count_a"]    = int(df_a[col].isna().sum())
            s["null_count_b"]    = int(df_b[col].isna().sum())
            s["null_delta"]      = s["null_count_b"] - s["null_count_a"]
            s["duplicate_count_a"] = int(df_a[col].duplicated().sum())
            s["duplicate_count_b"] = int(df_b[col].duplicated().sum())
            s["duplicate_delta"]   = s["duplicate_count_b"] - s["duplicate_count_a"]
        else:
            s["type"] = "other"
        stats[col] = s
    return stats


# ---------------------------------------------------------------------------
# Label distribution diff
# ---------------------------------------------------------------------------

def _label_diff(meta_a: Dict, meta_b: Dict) -> Dict[str, Any]:
    dist_a = meta_a.get("label_distribution", {})
    dist_b = meta_b.get("label_distribution", {})
    all_labels = sorted(set(dist_a.keys()) | set(dist_b.keys()))
    per_label = {}
    for lbl in all_labels:
        cnt_a = dist_a.get(lbl, 0)
        cnt_b = dist_b.get(lbl, 0)
        per_label[lbl] = {"count_a": cnt_a, "count_b": cnt_b, "delta": cnt_b - cnt_a}
    return {"a": dist_a, "b": dist_b, "changed": dist_a != dist_b, "per_label": per_label}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def compare_versions(repo: RepoState, version_a: str, version_b: str) -> Dict[str, Any]:
    """
    Full comparison of two versions. Always recomputes (no stale cache).
    Returns a summary dict with a '_report' key containing the full diff.
    Also saves the report to reports/diff_XXXXXXXX__YYYYYYYY.json.
    """
    if not repo.version_exists(version_a):
        raise DataLineageError(f"Version not found: {version_a}")
    if not repo.version_exists(version_b):
        raise DataLineageError(f"Version not found: {version_b}")

    reports_dir = repo.project_root / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    report_file = reports_dir / f"diff_{version_a[:8]}__{version_b[:8]}.json"
    if report_file.exists():
        with open(report_file, encoding="utf-8") as f:
            diff_report = json.load(f)
        return {
            "version_a": version_a,
            "version_b": version_b,
            "row_count_a": diff_report["summary"]["row_count_a"],
            "row_count_b": diff_report["summary"]["row_count_b"],
            "row_delta": diff_report["summary"]["row_delta"],
            "config_changed": diff_report["summary"]["config_changed"],
            "input_same": diff_report["summary"]["input_same"],
            "label_distribution_changed": diff_report["label_distribution"]["changed"],
            "changed_rows": diff_report["row_level"]["changed_rows_total"],
            "config_diff_count": diff_report["config_diff"]["total_changes"],
            "report_path": str(report_file),
            "_report": diff_report,
        }

    dir_a = repo.versions_root / version_a
    dir_b = repo.versions_root / version_b

    df_a    = _load_processed_dataframe(dir_a)
    df_b    = _load_processed_dataframe(dir_b)
    meta_a  = _load_metadata(dir_a)
    meta_b  = _load_metadata(dir_b)
    cfg_a   = _load_config_snapshot(dir_a)
    cfg_b   = _load_config_snapshot(dir_b)

    cols_a      = [str(c) for c in df_a.columns.tolist()]
    cols_b      = [str(c) for c in df_b.columns.tolist()]
    common_cols = sorted(set(cols_a) & set(cols_b))

    config_diff  = _diff_configs(cfg_a, cfg_b)
    preproc_diff = _preprocess_impact(meta_a, meta_b)
    row_diff     = _row_level_diff(df_a, df_b, common_cols)
    semantic     = _semantic_diff(df_a, df_b, common_cols)
    label_diff   = _label_diff(meta_a, meta_b)

    eval_a = meta_a.get("eval_metrics") or {}
    eval_b = meta_b.get("eval_metrics") or {}
    f1_a   = eval_a.get("f1") or eval_a.get("macro_f1") or eval_a.get("f1_score")
    f1_b   = eval_b.get("f1") or eval_b.get("macro_f1") or eval_b.get("f1_score")
    acc_a  = eval_a.get("accuracy")
    acc_b  = eval_b.get("accuracy")
    eval_diff = {
        "f1_a":      f1_a,
        "f1_b":      f1_b,
        "f1_delta":  round(f1_b - f1_a, 4) if (f1_a is not None and f1_b is not None) else None,
        "acc_a":     acc_a,
        "acc_b":     acc_b,
        "acc_delta": round(acc_b - acc_a, 4) if (acc_a is not None and acc_b is not None) else None,
    }

    diff_report: Dict[str, Any] = {
        "generated_at": _now_utc_iso(),
        "version_a":    version_a,
        "version_b":    version_b,
        "summary": {
            "row_count_a":    int(len(df_a)),
            "row_count_b":    int(len(df_b)),
            "row_delta":      int(len(df_b) - len(df_a)),
            "column_count_a": int(len(cols_a)),
            "column_count_b": int(len(cols_b)),
            "config_changed": bool(meta_a.get("config_hash") != meta_b.get("config_hash")),
            "input_same":     bool(meta_a.get("input_hash") == meta_b.get("input_hash")),
            "changed_rows":   row_diff["changed_rows_total"],
            "added_rows":     row_diff["added_rows_total"],
            "removed_rows":   row_diff["removed_rows_total"],
        },
        "columns": {
            "only_in_a": sorted(set(cols_a) - set(cols_b)),
            "only_in_b": sorted(set(cols_b) - set(cols_a)),
            "common":    common_cols,
        },
        "hashes": {
            "config_hash_a":  meta_a.get("config_hash"),
            "config_hash_b":  meta_b.get("config_hash"),
            "input_hash_a":   meta_a.get("input_hash"),
            "input_hash_b":   meta_b.get("input_hash"),
            "version_hash_a": meta_a.get("version_hash"),
            "version_hash_b": meta_b.get("version_hash"),
        },
        "config_diff":        config_diff,
        "preprocessing":      preproc_diff,
        "row_level":          row_diff,
        "semantic":           semantic,
        "label_distribution": label_diff,
        "eval_metrics":       eval_diff,
    }

    reports_dir = repo.project_root / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    report_file = reports_dir / f"diff_{version_a[:8]}__{version_b[:8]}.json"
    report_file.write_text(
        json.dumps(diff_report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    return {
        "version_a":                  version_a,
        "version_b":                  version_b,
        "row_count_a":                int(len(df_a)),
        "row_count_b":                int(len(df_b)),
        "row_delta":                  int(len(df_b) - len(df_a)),
        "config_changed":             bool(meta_a.get("config_hash") != meta_b.get("config_hash")),
        "input_same":                 bool(meta_a.get("input_hash") == meta_b.get("input_hash")),
        "label_distribution_changed": bool(label_diff["changed"]),
        "changed_rows":               row_diff["changed_rows_total"],
        "config_diff_count":          config_diff["total_changes"],
        "report_path":                str(report_file),
        "_report":                    diff_report,
    }
