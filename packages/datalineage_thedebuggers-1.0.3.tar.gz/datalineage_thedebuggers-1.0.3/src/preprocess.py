import re
import unicodedata
from typing import Dict

import numpy as np

import pandas as pd


def get_default_preprocess_config() -> Dict:
    return {
        "drop_nulls": True,
        "drop_duplicates": True,
        "cleanup_text": True,
        "strip_text": True,
        "lowercase_text": True,
        "remove_punctuation": True,
        "collapse_spaces": True,
        "normalize_unicode": True,
        "remove_urls": False,
        "coerce_numeric_columns": True,
        "null_strategy": "smart_fill",  # drop_any | drop_all | fill | smart_fill | keep
        "null_fill_text": "",
        "null_fill_numeric": 0,
        "sort_rows": True,
    }


def _normalize_columns(dataframe: pd.DataFrame) -> pd.DataFrame:
    dataframe = dataframe.copy()
    dataframe.columns = [str(column).strip().lower() for column in dataframe.columns]
    return dataframe




def _cleanup_text_with_config(value: str, config: Dict) -> str:
    text = str(value)

    if bool(config.get("normalize_unicode", True)):
        text = unicodedata.normalize("NFKC", text)

    if bool(config.get("strip_text", True)):
        text = text.strip()

    if bool(config.get("remove_urls", False)):
        text = re.sub(r"https?://\S+|www\.\S+", " ", text)

    if bool(config.get("lowercase_text", True)):
        text = text.lower()

    if bool(config.get("remove_punctuation", True)):
        text = re.sub(r"[^a-z0-9\s]", " ", text)

    if bool(config.get("collapse_spaces", True)):
        text = re.sub(r"\s+", " ", text)

    return text.strip()


def _normalize_unwanted_values(dataframe: pd.DataFrame, config: Dict) -> pd.DataFrame:
    processed = dataframe.copy()
    unwanted_values = config.get(
        "unwanted_values",
        ["", "na", "n/a", "null", "none", "-", "?"],
    )
    unwanted_lookup = {str(item).strip().lower() for item in unwanted_values}

    object_columns = processed.select_dtypes(include=["object", "string"]).columns
    for column in object_columns:
        normalized = processed[column].astype(str).str.strip().str.lower()
        processed.loc[normalized.isin(unwanted_lookup), column] = pd.NA

    return processed


def _looks_like_numeric_series(series: pd.Series) -> bool:
    non_null = series.dropna()
    if non_null.empty:
        return False

    normalized = non_null.astype(str).str.replace(",", "", regex=False).str.strip()
    numeric_pattern = r"^-?\d+(\.\d+)?$"
    return bool(normalized.str.match(numeric_pattern).all())


def _coerce_numeric_like_columns(dataframe: pd.DataFrame, config: Dict) -> pd.DataFrame:
    if not bool(config.get("coerce_numeric_columns", True)):
        return dataframe

    processed = dataframe.copy()
    object_columns = processed.select_dtypes(include=["object", "string"]).columns
    for column in object_columns:
        if _looks_like_numeric_series(processed[column]):
            processed[column] = pd.to_numeric(
                processed[column].astype(str).str.replace(",", "", regex=False),
                errors="coerce",
            )

    return processed


def _apply_null_strategy(dataframe: pd.DataFrame, config: Dict) -> pd.DataFrame:
    processed = dataframe.copy()

    strategy = str(config.get("null_strategy", "smart_fill")).strip().lower()
    if not strategy:
        strategy = "smart_fill"

    # If user sets null_strategy: keep, always respect it. Warn if drop_nulls: True and strategy is keep.
    if bool(config.get("drop_nulls", True)) and strategy == "keep":
        print("Warning: Your config sets null_strategy: 'keep' with drop_nulls: True. Nulls will be kept as-is. This may cause issues in downstream processing.")
        # Do not override strategy; proceed with 'keep'

    if strategy == "drop_any":
        return processed.dropna(how="any")

    if strategy == "drop_all":
        return processed.dropna(how="all")

    if strategy == "fill":
        text_fill_value = config.get("null_fill_text", "")
        numeric_fill_value = config.get("null_fill_numeric", 0)

        object_columns = processed.select_dtypes(include=["object", "string"]).columns
        numeric_columns = processed.select_dtypes(include=["number", "boolean"]).columns

        if len(object_columns) > 0:
            processed[object_columns] = processed[object_columns].fillna(text_fill_value)

        if len(numeric_columns) > 0:
            processed[numeric_columns] = processed[numeric_columns].fillna(numeric_fill_value)

        remaining_columns = [
            column
            for column in processed.columns
            if column not in set(object_columns).union(set(numeric_columns))
        ]
        if remaining_columns:
            processed[remaining_columns] = processed[remaining_columns].fillna(text_fill_value)

        return processed

    if strategy == "smart_fill":
        # Smart filling: numeric → median, categorical → mode or "Unknown"
        numeric_columns = processed.select_dtypes(include=["number"]).columns
        object_columns = processed.select_dtypes(include=["object", "string"]).columns

        # Fill numeric columns with median
        for column in numeric_columns:
            if processed[column].isnull().any():
                median_value = processed[column].median()
                if pd.notna(median_value):
                    processed[column] = processed[column].fillna(median_value)
                else:
                    processed[column] = processed[column].fillna(0)

        # Fill categorical columns with mode or "Unknown"
        for column in object_columns:
            if processed[column].isnull().any():
                mode_values = processed[column].mode()
                if len(mode_values) > 0:
                    processed[column] = processed[column].fillna(mode_values[0])
                else:
                    processed[column] = processed[column].fillna("Unknown")

        # Handle any remaining columns
        remaining_columns = [
            column
            for column in processed.columns
            if column not in set(object_columns).union(set(numeric_columns))
        ]
        if remaining_columns:
            for column in remaining_columns:
                if processed[column].isnull().any():
                    processed[column] = processed[column].fillna("Unknown")

        return processed

    return processed


def _apply_column_selection(dataframe: pd.DataFrame, config: Dict) -> pd.DataFrame:
    """Select or drop specific columns"""
    processed = dataframe.copy()
    
    # Select only specific columns
    select_columns = config.get("select_columns", [])
    if select_columns:
        if not isinstance(select_columns, (list, tuple, set)):
            select_columns = [select_columns]
        available_columns = [col for col in select_columns if col in processed.columns]
        if available_columns:
            processed = processed[available_columns]
    
    # Drop specific columns
    drop_columns = config.get("drop_columns", [])
    if drop_columns:
        if not isinstance(drop_columns, (list, tuple, set)):
            drop_columns = [drop_columns]
        columns_to_drop = [col for col in drop_columns if col in processed.columns]
        if columns_to_drop:
            processed = processed.drop(columns=columns_to_drop)
    
    return processed


def _apply_row_filtering(dataframe: pd.DataFrame, config: Dict) -> pd.DataFrame:
    """Filter rows based on conditions"""
    processed = dataframe.copy()
    
    # Filter by numeric range (e.g., "age": {"min": 18, "max": 65})
    filter_numeric = config.get("filter_numeric", {})
    for column, constraints in filter_numeric.items():
        if column in processed.columns:
            if "min" in constraints:
                processed = processed[processed[column] >= constraints["min"]]
            if "max" in constraints:
                processed = processed[processed[column] <= constraints["max"]]
    
    # Filter by value inclusion (e.g., "sex": ["male", "female"])
    filter_include = config.get("filter_include", {})
    for column, values in filter_include.items():
        if column in processed.columns and values:
            # Accept both single values and lists for filter values
            if not isinstance(values, (list, tuple, set)):
                values = [values]
            processed = processed[processed[column].isin(values)]
    
    # Filter by value exclusion
    filter_exclude = config.get("filter_exclude", {})
    for column, values in filter_exclude.items():
        if column in processed.columns and values:
            # Accept both single values and lists for filter values
            if not isinstance(values, (list, tuple, set)):
                values = [values]
            processed = processed[~processed[column].isin(values)]
    
    return processed


def _apply_value_mapping(dataframe: pd.DataFrame, config: Dict) -> pd.DataFrame:
    """Map/replace values in columns"""
    processed = dataframe.copy()
    
    # Value mapping (e.g., "sex": {"male": 0, "female": 1})
    value_mappings = config.get("value_mappings", {})
    for column, mapping in value_mappings.items():
        if column in processed.columns and mapping:
            # If mapping keys are lists, flatten them
            safe_mapping = {}
            for k, v in mapping.items():
                if isinstance(k, (list, tuple, set)):
                    for single_k in k:
                        safe_mapping[single_k] = v
                else:
                    safe_mapping[k] = v
            processed[column] = processed[column].replace(safe_mapping)
    
    return processed


def _apply_column_renaming(dataframe: pd.DataFrame, config: Dict) -> pd.DataFrame:
    """Rename columns"""
    processed = dataframe.copy()
    
    # Column renaming (e.g., {"passengerid": "id", "survived": "target"})
    rename_columns = config.get("rename_columns", {})
    if rename_columns:
        # Only rename columns that exist, and ensure keys are hashable
        valid_renames = {}
        for old, new in rename_columns.items():
            if isinstance(old, (list, tuple, set)):
                for single_old in old:
                    if single_old in processed.columns:
                        valid_renames[single_old] = new
            else:
                if old in processed.columns:
                    valid_renames[old] = new
        if valid_renames:
            processed = processed.rename(columns=valid_renames)
    
    return processed


def apply_deterministic_preprocessing(dataframe: pd.DataFrame, config: Dict) -> pd.DataFrame:
    merged_config = {**get_default_preprocess_config(), **(config or {})}

    processed = _normalize_columns(dataframe)
    processed = _normalize_unwanted_values(processed, merged_config)

    # --- Config-driven text preprocessing ---
    text_columns = merged_config.get("text_columns")
    if text_columns:
        if not isinstance(text_columns, (list, tuple, set)):
            text_columns = [text_columns]
        text_columns = [col for col in text_columns if col in processed.columns]
        missing = set(merged_config.get("text_columns", [])) - set(text_columns)
        if missing:
            print(f"[WARNING] The following text_columns are missing in data and will be skipped: {missing}")
    else:
        # Auto-detect: pick the object/string column with highest avg string length
        obj_cols = list(processed.select_dtypes(include=["object", "string"]).columns)
        if obj_cols:
            avg_lens = {col: processed[col].dropna().astype(str).map(len).mean() for col in obj_cols}
            detected_col = max(avg_lens, key=avg_lens.get)
            avg_len = avg_lens[detected_col]
            text_columns = [detected_col]
            print(f"[INFO] text_columns not specified in config. Auto-detected text column: '{detected_col}' (avg length: {avg_len:.0f} chars)")
        else:
            text_columns = []

    # Tokenization and stopword removal config
    tokenize = bool(merged_config.get("tokenize", False))
    remove_stopwords = bool(merged_config.get("remove_stopwords", False))
    stopwords = set(merged_config.get("stopwords", []))
    # Default English stopwords if needed
    if remove_stopwords and not stopwords:
        stopwords = {
            "a", "an", "the", "is", "it", "in", "of", "to", "and", "for", "on", "at", "by", "with", "from", "this", "that", "are", "was", "were", "be", "been", "has", "have", "had", "do", "does", "did", "will", "would", "could", "should", "may", "might", "i", "you", "he", "she", "we", "they", "my", "your", "his", "her", "its", "our", "their"
        }
        print("[INFO] No custom stopwords provided. Using default English stopword list.")

    def _tokenize_text(text):
        # Split on words (alphanumeric), ignore punctuation
        return re.findall(r"\w+", text)

    vocab = set()
    tokens_per_row = []

    for column in text_columns:
        if bool(merged_config.get("cleanup_text", True)):
            def process_value(value):
                if pd.isna(value):
                    return value
                cleaned = _cleanup_text_with_config(str(value), merged_config)
                if tokenize:
                    tokens = _tokenize_text(cleaned)
                    if remove_stopwords and stopwords:
                        tokens = [t for t in tokens if t not in stopwords]
                    vocab.update(tokens)
                    tokens_per_row.append(len(tokens))
                    # Join tokens back to string (space-separated)
                    return " ".join(tokens)
                else:
                    return cleaned
            processed[column] = processed[column].map(process_value)

    # Backward compatibility: process other object columns as before
    other_object_columns = set(processed.select_dtypes(include=["object", "string"]).columns) - set(text_columns)
    for column in other_object_columns:
        if bool(merged_config.get("cleanup_text", True)):
            processed[column] = processed[column].map(
                lambda value: value if pd.isna(value) else _cleanup_text_with_config(str(value), merged_config)
            )

    processed = _coerce_numeric_like_columns(processed, merged_config)
    processed = _apply_null_strategy(processed, merged_config)

    if bool(merged_config.get("drop_duplicates", True)):
        processed = processed.drop_duplicates(keep="first")

    # Apply transformations
    processed = _apply_column_selection(processed, merged_config)
    processed = _apply_row_filtering(processed, merged_config)
    processed = _apply_value_mapping(processed, merged_config)
    processed = _apply_column_renaming(processed, merged_config)

    if bool(merged_config.get("sort_rows", True)):
        sort_columns = list(processed.columns)
        if sort_columns:
            processed = processed.sort_values(
                by=sort_columns,
                kind="mergesort",
                na_position="last",
            )
    processed = processed.reset_index(drop=True)

    # --- Store tokenization stats in config for traceability ---
    if tokenize and tokens_per_row:
        merged_config["tokenization_stats"] = {
            "tokens_per_row_avg": float(np.mean(tokens_per_row)) if tokens_per_row else 0.0,
            "tokens_per_row_min": int(np.min(tokens_per_row)) if tokens_per_row else 0,
            "tokens_per_row_max": int(np.max(tokens_per_row)) if tokens_per_row else 0,
            "vocab_size": len(vocab),
            "top_10_tokens": list(pd.Series([t for column in text_columns for t in _tokenize_text(str(processed[column].iloc[0])) if t not in stopwords]).value_counts().head(10).index) if text_columns else [],
        }

    return processed
