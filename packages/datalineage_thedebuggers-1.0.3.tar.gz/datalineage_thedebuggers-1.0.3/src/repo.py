import json
import re
from pathlib import Path
from typing import Any, Dict, List, Optional

from src.errors import RepositoryNotInitializedError


class RepoState:
    def get_version_metadata(self, version_id: str) -> dict:
        """Fetch metadata.json for a given version_id. Returns dict or raises if not found."""
        import json
        metadata_path = self.versions_root / version_id / "metadata.json"
        if not metadata_path.exists():
            raise FileNotFoundError(f"metadata.json not found for version {version_id}")
        with open(metadata_path, "r", encoding="utf-8") as f:
            return json.load(f)
    def __init__(self, project_root: Optional[Path] = None) -> None:
        self.project_root = project_root or Path(__file__).resolve().parents[1]
        self.repo_root = self.project_root / ".mydata"
        self.versions_root = self.repo_root / "versions"
        self.branches_root = self.repo_root / "branches"
        self.current_branch_file = self.repo_root / "CURRENT_BRANCH"
        self.detached_head_file = self.repo_root / "DETACHED_HEAD"
        self.head_file = self.repo_root / "HEAD"
        self.logs_file = self.repo_root / "logs.jsonl"
        self.meta_file = self.repo_root / "repo_meta.json"
        self._version_index = None  # Dict[str, Path]
        self._parent_map = None     # Dict[str, Optional[str]]
        self._child_map = None      # Dict[str, List[str]]
        self._ensure_initialized()
        self._ensure_branch_state()
        self._build_version_index()
        self._build_graph_index()

    def _build_graph_index(self) -> None:
        """Builds parent and child maps for version graph traversal."""
        self._parent_map = {}
        self._child_map = {}
        if self.versions_root.exists():
            for vdir in self.versions_root.iterdir():
                if vdir.is_dir() and len(vdir.name) == 64:
                    meta_path = vdir / "metadata.json"
                    parent_id = None
                    if meta_path.exists():
                        try:
                            with open(meta_path, "r", encoding="utf-8") as f:
                                meta = json.load(f)
                            parent_id = meta.get("parent_id")
                        except Exception:
                            parent_id = None
                    self._parent_map[vdir.name] = parent_id
                    if parent_id:
                        self._child_map.setdefault(parent_id, []).append(vdir.name)
        # Ensure all versions are in child_map
        for vid in self._version_index:
            self._child_map.setdefault(vid, [])

    def get_version_chain(self, version_id: str) -> List[str]:
        """Return the chain of version_ids from root to the given version (inclusive)."""
        if self._parent_map is None:
            self._build_graph_index()
        chain = []
        curr = version_id
        while curr:
            chain.append(curr)
            curr = self._parent_map.get(curr)
        return list(reversed(chain))

    def get_all_versions(self) -> List[str]:
        """Return all version_ids in topological order (parents before children)."""
        if self._parent_map is None:
            self._build_graph_index()
        # Kahn's algorithm for topological sort
        in_degree = {vid: 0 for vid in self._version_index}
        for child, parent in self._parent_map.items():
            if parent and parent in in_degree:
                in_degree[child] += 1
        queue = [vid for vid, deg in in_degree.items() if deg == 0]
        topo = []
        while queue:
            vid = queue.pop(0)
            topo.append(vid)
            for child in self._child_map.get(vid, []):
                in_degree[child] -= 1
                if in_degree[child] == 0:
                    queue.append(child)
        return topo

    def _build_version_index(self) -> None:
        """Builds a dict mapping version_id to its path for fast lookup."""
        self._version_index = {}
        if self.versions_root.exists():
            for vdir in self.versions_root.iterdir():
                if vdir.is_dir() and len(vdir.name) == 64:
                    self._version_index[vdir.name] = vdir

    def get_version_path(self, version_id: str) -> Optional[Path]:
        if self._version_index is None:
            self._build_version_index()
        return self._version_index.get(version_id)

    def _ensure_initialized(self) -> None:
        required_paths = [
            self.repo_root,
            self.versions_root,
            self.head_file,
            self.logs_file,
            self.meta_file,
        ]
        if not all(path.exists() for path in required_paths):
            raise RepositoryNotInitializedError(
                f"Repository not initialized under: {self.repo_root}"
            )

    def _ensure_branch_state(self) -> None:
        self.branches_root.mkdir(parents=True, exist_ok=True)

        if not self.current_branch_file.exists():
            self.current_branch_file.write_text("main\n", encoding="utf-8")

        if not self.detached_head_file.exists():
            self.detached_head_file.write_text("\n", encoding="utf-8")

        current_branch = self.get_current_branch()
        current_branch_path = self.branches_root / current_branch

        head_value = self.head_file.read_text(encoding="utf-8").strip()
        if not current_branch_path.exists():
            current_branch_path.write_text(f"{head_value}\n" if head_value else "\n", encoding="utf-8")

    def _read_pointer_file(self, path: Path) -> Optional[str]:
        raw_value = path.read_text(encoding="utf-8").strip()
        if raw_value in {"", "null", "None"}:
            return None
        return raw_value

    def _write_pointer_file(self, path: Path, version_id: Optional[str]) -> None:
        if version_id:
            path.write_text(f"{version_id}\n", encoding="utf-8")
        else:
            path.write_text("\n", encoding="utf-8")

    def _validate_branch_name(self, branch_name: str) -> str:
        normalized = branch_name.strip()
        if not normalized:
            raise ValueError("Branch name cannot be empty.")
        if normalized in {".", ".."}:
            raise ValueError("Invalid branch name.")
        if not re.fullmatch(r"[A-Za-z0-9._-]+", normalized):
            raise ValueError("Branch name can only contain letters, numbers, dot, underscore, and hyphen.")
        return normalized

    def get_current_branch(self) -> str:
        if not self.current_branch_file.exists():
            return "main"
        raw_value = self.current_branch_file.read_text(encoding="utf-8").strip()
        return raw_value or "main"

    def set_current_branch(self, branch_name: str) -> None:
        safe_name = self._validate_branch_name(branch_name)
        self.current_branch_file.write_text(f"{safe_name}\n", encoding="utf-8")

    def get_detached_head(self) -> Optional[str]:
        if not self.detached_head_file.exists():
            return None
        return self._read_pointer_file(self.detached_head_file)

    def is_detached(self) -> bool:
        return self.get_detached_head() is not None

    def detach_head(self, version_id: str) -> None:
        if not self.version_exists(version_id):
            raise ValueError(f"Version not found: {version_id}")
        self._write_pointer_file(self.detached_head_file, version_id)
        self._write_pointer_file(self.head_file, version_id)

    def clear_detached_head(self) -> None:
        self._write_pointer_file(self.detached_head_file, None)

    def checkout_detached(self, version_id: str) -> None:
        self.detach_head(version_id)

    def branch_exists(self, branch_name: str) -> bool:
        safe_name = self._validate_branch_name(branch_name)
        return (self.branches_root / safe_name).exists()

    def list_branches(self) -> List[str]:
        if not self.branches_root.exists():
            return []
        return sorted([p.name for p in self.branches_root.iterdir() if p.is_file()])

    def get_branch_head(self, branch_name: str) -> Optional[str]:
        safe_name = self._validate_branch_name(branch_name)
        branch_path = self.branches_root / safe_name
        if not branch_path.exists():
            return None
        return self._read_pointer_file(branch_path)

    def create_branch(self, branch_name: str, from_version: Optional[str] = None) -> str:
        safe_name = self._validate_branch_name(branch_name)
        branch_path = self.branches_root / safe_name
        if branch_path.exists():
            raise ValueError(f"Branch already exists: {safe_name}")

        base_version = from_version or self.get_head()
        if base_version and not self.version_exists(base_version):
            raise ValueError(f"Cannot create branch from unknown version: {base_version}")

        self._write_pointer_file(branch_path, base_version)
        return safe_name

    def switch_branch(self, branch_name: str) -> Optional[str]:
        safe_name = self._validate_branch_name(branch_name)
        branch_path = self.branches_root / safe_name
        if not branch_path.exists():
            raise ValueError(f"Branch does not exist: {safe_name}")

        branch_head = self._read_pointer_file(branch_path)
        self.clear_detached_head()
        self.set_current_branch(safe_name)
        self._write_pointer_file(self.head_file, branch_head)
        return branch_head

    def get_head(self) -> Optional[str]:
        detached = self.get_detached_head()
        if detached:
            return detached
        current_branch = self.get_current_branch()
        branch_pointer = self.branches_root / current_branch
        if branch_pointer.exists():
            return self._read_pointer_file(branch_pointer)
        return self._read_pointer_file(self.head_file)

    def set_head(self, version_id: str) -> None:
        current_branch = self.get_current_branch()
        branch_pointer = self.branches_root / current_branch
        self.clear_detached_head()
        self._write_pointer_file(branch_pointer, version_id)
        self._write_pointer_file(self.head_file, version_id)

    def read_logs(self) -> List[Dict[str, Any]]:
        logs = []
        if not self.logs_file.exists():
            return logs
        with self.logs_file.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        logs.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
        return logs

    def append_log(self, record: Dict[str, Any]) -> None:
        with self.logs_file.open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")

    def version_exists(self, version_id: str) -> bool:
        if self._version_index is None:
            self._build_version_index()
        return version_id in self._version_index
