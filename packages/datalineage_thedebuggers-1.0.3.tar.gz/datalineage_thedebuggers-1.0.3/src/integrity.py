import pandas as pd
from pathlib import Path
from src.hasher import dataframe_to_stable_csv_bytes, sha256_from_bytes
from src.errors import DataLineageError
import json

def verify_version_integrity(version_dir: Path) -> bool:
    """
    Verifies that the processed.csv in version_dir matches the stored version_hash in metadata.json.
    Returns True if valid, raises DataLineageError if not.
    """
    import zipfile
    import tempfile
    processed_csv = version_dir / "processed.csv"
    processed_txt = version_dir / "processed.txt"
    processed_json = version_dir / "processed.json"
    processed_csv_zip = version_dir / "processed.csv.zip"
    processed_txt_zip = version_dir / "processed.txt.zip"
    processed_json_zip = version_dir / "processed.json.zip"
    metadata_file = version_dir / "metadata.json"
    import os
    tmp_path = None
    computed_hash = None
    try:
        if processed_csv.exists():
            processed_file = processed_csv
        elif processed_txt.exists():
            processed_file = processed_txt
        elif processed_json.exists():
            processed_file = processed_json
        elif processed_csv_zip.exists():
            with zipfile.ZipFile(processed_csv_zip, 'r') as zf:
                if 'processed.csv' not in zf.namelist():
                    raise DataLineageError(f"processed.csv.zip does not contain processed.csv in {version_dir}")
                with tempfile.NamedTemporaryFile(delete=False, suffix='.csv') as tmp:
                    tmp.write(zf.read('processed.csv'))
                    tmp_path = tmp.name
            processed_file = Path(tmp_path)
        elif processed_txt_zip.exists():
            with zipfile.ZipFile(processed_txt_zip, 'r') as zf:
                if 'processed.txt' not in zf.namelist():
                    raise DataLineageError(f"processed.txt.zip does not contain processed.txt in {version_dir}")
                with tempfile.NamedTemporaryFile(delete=False, suffix='.txt') as tmp:
                    tmp.write(zf.read('processed.txt'))
                    tmp_path = tmp.name
            processed_file = Path(tmp_path)
        elif processed_json_zip.exists():
            with zipfile.ZipFile(processed_json_zip, 'r') as zf:
                if 'processed.json' not in zf.namelist():
                    raise DataLineageError(f"processed.json.zip does not contain processed.json in {version_dir}")
                with tempfile.NamedTemporaryFile(delete=False, suffix='.json') as tmp:
                    tmp.write(zf.read('processed.json'))
                    tmp_path = tmp.name
            processed_file = Path(tmp_path)
        else:
            raise DataLineageError(f"Missing processed.csv, processed.txt, processed.json, processed.csv.zip, processed.txt.zip, or processed.json.zip in {version_dir}")
        if not metadata_file.exists():
            raise DataLineageError(f"Missing metadata.json in {version_dir}")
        # Load and hash processed file
        from src.io_loader import load_dataset
        df, _ = load_dataset(str(processed_file))
        csv_bytes = dataframe_to_stable_csv_bytes(df)
        computed_hash = sha256_from_bytes(csv_bytes)
        # Load metadata
    finally:
        if tmp_path is not None:
            try:
                os.unlink(tmp_path)
            except Exception:
                pass
    with open(metadata_file, encoding="utf-8") as f:
        metadata = json.load(f)
    # For future: load raw data using raw_data_ref if needed
    raw_data_ref = metadata.get("artifacts", {}).get("raw_data_ref")
    if raw_data_ref:
        raw_data_path = version_dir.parents[1] / raw_data_ref["path"]
        # Could load or check raw_data_path here if needed
    # Only use processed_csv_hash for processed output integrity
    stored_hash = metadata.get("processed_csv_hash")
    if not stored_hash:
        raise DataLineageError(f"No processed_csv_hash in metadata for {version_dir}")
    if computed_hash != stored_hash:
        raise DataLineageError(f"Integrity check failed: computed hash {computed_hash} != stored {stored_hash} for {version_dir}")
    return True
