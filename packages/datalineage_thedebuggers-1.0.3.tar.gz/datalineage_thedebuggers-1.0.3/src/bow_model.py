import numpy as np
import pandas as pd
from collections import defaultdict, Counter

class BagOfWords:
    # Store last probability scores for AUC-ROC
    _last_scores = None
    def __init__(self, text_column, label_column):
        self.text_column = text_column
        self.label_column = label_column
        self.vocab = set()
        self.class_priors = dict()
        self.word_counts = dict()  # {class: Counter(word)}
        self.class_word_totals = dict()
        self.classes = []

    def fit(self, texts, labels):
        self.classes = np.unique(labels)
        self.word_counts = {c: Counter() for c in self.classes}
        self.class_word_totals = {c: 0 for c in self.classes}
        class_counts = Counter(labels)
        total = len(labels)
        self.class_priors = {c: class_counts[c] / total for c in self.classes}
        for text, label in zip(texts, labels):
            words = str(text).split()
            self.vocab.update(words)
            self.word_counts[label].update(words)
            self.class_word_totals[label] += len(words)
        self.vocab = sorted(self.vocab)

    def predict(self, texts):
        predictions = []
        for text in texts:
            words = str(text).split()
            class_scores = {}
            for c in self.classes:
                # log(P(class))
                score = np.log(self.class_priors[c] + 1e-12)
                total_words = self.class_word_totals[c] + len(self.vocab)  # Laplace smoothing
                for w in words:
                    count = self.word_counts[c][w] if w in self.word_counts[c] else 0
                    # log(P(word|class))
                    score += np.log((count + 1) / total_words)
                class_scores[c] = score
            # Pick class with highest score
            best_class = max(class_scores, key=class_scores.get)
            predictions.append(best_class)
        return np.array(predictions)

    def evaluate(self, texts, labels):
        y_true = np.array(labels)
        # Compute predicted probabilities for AUC-ROC
        y_pred, y_scores = self._predict_with_scores(texts)
        self._last_scores = y_scores
        accuracy = np.mean(y_true == y_pred)
        metrics = self._compute_metrics(y_true, y_pred, y_scores)
        metrics['accuracy'] = accuracy
        # Print metrics in required format
        print("=== Evaluation Metrics ===")
        print(f"Accuracy  : {metrics['accuracy']:.3f}")
        print(f"Precision : {metrics['precision']:.3f}")
        print(f"Recall    : {metrics['recall']:.3f}")
        print(f"F1        : {metrics['f1']:.3f}")
        print(f"AUC-ROC   : {metrics['auc_roc']:.3f}")
        print(f"MCC       : {metrics['mcc']:.3f}")
        print(f"FPR       : {metrics['fpr']:.3f}")
        print(f"FNR       : {metrics['fnr']:.3f}")
        print()
        # Print confusion matrix
        cm = metrics['confusion_matrix']
        labels = metrics['labels']
        print("=== Confusion Matrix ===")
        print(f"{'':>16}Pred {labels[0]:<7}Pred {labels[1]:<7}")
        # Support both NumPy array and list
        if hasattr(cm, 'shape'):
            print(f"Actual {labels[0]:<6}  [   {cm[0,0]:<5} |   {cm[0,1]:<5} ]")
            print(f"Actual {labels[1]:<6}  [   {cm[1,0]:<5} |   {cm[1,1]:<5} ]")
        else:
            print(f"Actual {labels[0]:<6}  [   {cm[0][0]:<5} |   {cm[0][1]:<5} ]")
            print(f"Actual {labels[1]:<6}  [   {cm[1][0]:<5} |   {cm[1][1]:<5} ]")
        print()
        return metrics

    def _predict_with_scores(self, texts):
        # Returns predicted class and probability for positive class (for AUC-ROC)
        preds = []
        scores = []
        for text in texts:
            words = str(text).split()
            class_scores = {}
            for c in self.classes:
                score = np.log(self.class_priors[c] + 1e-12)
                total_words = self.class_word_totals[c] + len(self.vocab)
                for w in words:
                    count = self.word_counts[c][w] if w in self.word_counts[c] else 0
                    score += np.log((count + 1) / total_words)
                class_scores[c] = score
            # Softmax for probability
            logit = np.array([class_scores[self.classes[0]], class_scores[self.classes[1]]])
            max_logit = np.max(logit)
            exp_logit = np.exp(logit - max_logit)
            probs = exp_logit / np.sum(exp_logit)
            # Prob for positive class (assume classes[1] is positive)
            prob_pos = probs[1]
            best_class = self.classes[np.argmax(logit)]
            preds.append(best_class)
            scores.append(prob_pos)
        return np.array(preds), np.array(scores)

    def _compute_metrics(self, y_true, y_pred, y_scores):
        # Only for binary classification
        classes = np.unique(y_true)
        assert len(classes) == 2, "AUC-ROC and MCC only supported for binary classification."
        # Confusion matrix
        cm = np.zeros((2,2), dtype=int)
        for i, actual in enumerate(classes):
            for j, pred in enumerate(classes):
                cm[i,j] = np.sum((y_true == actual) & (y_pred == pred))
        # Support both NumPy array and list
        if hasattr(cm, 'shape'):
            tp = cm[1,1]
            tn = cm[0,0]
            fp = cm[0,1]
            fn = cm[1,0]
        else:
            tp = cm[1][1]
            tn = cm[0][0]
            fp = cm[0][1]
            fn = cm[1][0]
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0.0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0.0
        fpr = fp / (fp + tn) if (fp + tn) > 0 else 0.0
        fnr = fn / (fn + tp) if (fn + tp) > 0 else 0.0
        # Matthews Correlation Coefficient
        denom = np.sqrt((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))
        mcc = ((tp*tn - fp*fn) / denom) if denom > 0 else 0.0
        # AUC-ROC (using y_scores)
        if y_scores is None:
            auc_roc = float('nan')
        else:
            # Sort by descending score
            desc = np.argsort(-y_scores)
            y_true_bin = (y_true == classes[1]).astype(int)
            y_true_sorted = y_true_bin[desc]
            y_scores_sorted = y_scores[desc]
            tpr_list = [0.0]
            fpr_list = [0.0]
            P = np.sum(y_true_sorted == 1)
            N = np.sum(y_true_sorted == 0)
            tp_auc = 0
            fp_auc = 0
            for i in range(len(y_true_sorted)):
                if y_true_sorted[i] == 1:
                    tp_auc += 1
                else:
                    fp_auc += 1
                tpr = tp_auc / P if P > 0 else 0.0
                fprate = fp_auc / N if N > 0 else 0.0
                tpr_list.append(tpr)
                fpr_list.append(fprate)
            # Trapezoidal rule
            auc_roc = np.trapz(tpr_list, fpr_list)
        return {
            'precision': float(precision),
            'recall': float(recall),
            'f1': float(f1),
            'auc_roc': float(auc_roc),
            'mcc': float(mcc),
            'fpr': float(fpr),
            'fnr': float(fnr),
            'confusion_matrix': cm.tolist() if hasattr(cm, 'tolist') else cm,
            'labels': [str(classes[0]), str(classes[1])],
        }
