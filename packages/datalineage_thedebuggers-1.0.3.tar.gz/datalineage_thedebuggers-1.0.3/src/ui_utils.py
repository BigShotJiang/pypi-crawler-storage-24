# UI/print helper utilities for DataLineage CLI


def print_boxed_header(title: str, width: int = 70):
    # Dynamically set width based on title
    content_width = max(width, len(title) + 4)
    heading_color = '\033[96m'  # bright cyan
    reset_color = '\033[0m'
    print(heading_color + title.center(content_width) + reset_color)

def print_boxed_section(text: str, width: int = 70):
    # Print each line as plain text, no borders
    lines = text.splitlines()
    for line in lines:
        print(line)

def print_boxed_footer(width: int = 70):
    print("╚" + "═" * (width - 2) + "╝")

def print_separator(width: int = 72):
    print("═" * width)

def print_menu(menu_items, title: str = "DataLineage CLI — Main Menu", width: int = 70):
    # Dynamically set width based on longest line
    content_width = max(width, len(title) + 4, max((len(item) for item in menu_items), default=0))
    heading_color = '\033[96m'  # bright cyan
    reset_color = '\033[0m'
    print('-' * content_width)
    print(heading_color + title.center(content_width) + reset_color)
    print('-' * content_width)
    for item in menu_items:
        print(item.ljust(content_width))
    # No extra horizontal line at the end

def print_error(msg: str, width: int = 70):
    content_width = max(width, len(msg) + 12)
    print("ERROR: "+ msg.ljust(content_width - 7))

def print_unexpected_error(msg: str, width: int = 70):
    content_width = max(width, len(msg) + 22)
    print("UNEXPECTED ERROR: "+ msg.ljust(content_width - 18))
