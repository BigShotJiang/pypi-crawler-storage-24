

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Tuple
import pandas as pd

from src.hasher import (
    dataframe_to_stable_csv_bytes,
    sha256_from_bytes,
    sha256_from_json,
)
from src.io_loader import load_dataset, read_config, validate_schema
from src.errors import DataLineageError
from src.models import VersionRecord
from src.preprocess import apply_deterministic_preprocessing, get_default_preprocess_config
from src.repo import RepoState

# --- Modularized helpers for repeated logic ---
def _normalize_and_read_file(path_value: str) -> Tuple[Path, bytes]:
    norm_path = _normalize_user_path(path_value)
    file_path = Path(norm_path)
    if not file_path.exists():
        raise DataLineageError(f"File not found: {file_path}")
    return file_path, file_path.read_bytes()

def _load_and_validate_dataset(dataset_path: str) -> pd.DataFrame:
    df, _ = load_dataset(dataset_path)
    validate_schema(df)
    return df

def _preprocess_dataframe(raw_df: pd.DataFrame, config: Dict) -> pd.DataFrame:
    return apply_deterministic_preprocessing(raw_df, config)


from typing import Tuple
def _label_distribution(processed_rows: pd.DataFrame, config: Dict) -> Tuple[str, Dict[str, int]]:
    # 1. Use config if specified
    label_col = config.get("label_column")
    if label_col and label_col in processed_rows.columns:
        col = label_col
    else:
        # 2. Auto-detect: pick non-text column with lowest cardinality
        candidates = []
        for c in processed_rows.columns:
            if pd.api.types.is_numeric_dtype(processed_rows[c]) or processed_rows[c].nunique() < 20:
                candidates.append((c, processed_rows[c].nunique()))
        if candidates:
            # Pick the one with lowest cardinality
            col = min(candidates, key=lambda x: x[1])[0]
        else:
            # Fallback: just pick the first column
            col = processed_rows.columns[0] if len(processed_rows.columns) > 0 else None
        # Print warning for hackathon/demo users
        print("[WARNING] Label column not specified in config. Auto-detected label column:", col)
    if not col or col not in processed_rows.columns:
        print("[ERROR] Could not determine a valid label column. Please check your config and data columns.")
        return None, {}
    distribution = processed_rows[col].value_counts(dropna=False).to_dict()
    return col, {str(key): int(value) for key, value in distribution.items()}


def _now_utc_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat()


def _normalize_user_path(path_value: str) -> str:
    from pathlib import Path
    normalized = path_value.strip()
    # Remove surrounding quotes
    if len(normalized) >= 2 and normalized[0] == normalized[-1] and normalized[0] in {'"', "'"}:
        normalized = normalized[1:-1]
    # Expand ~ to home, resolve relative paths, handle backslashes
    try:
        normalized = str(Path(normalized).expanduser().resolve())
    except Exception:
        # If path doesn't exist yet, resolve as much as possible
        normalized = str(Path(normalized).expanduser().absolute())
    return normalized


def _persist_version(
    repo: RepoState,
    source_data_path: str,
    source_config_path: str,
    input_bytes: bytes,
    raw_dataframe,
    processed_dataframe,
    config: Dict[str, Any],
    commit_message: str,
    parent_raw_data_ref=None,
) -> Dict[str, Any]:

    # Detect input/output format by file extension
    from pathlib import Path
    input_suffix = Path(source_data_path).suffix.lower() if isinstance(source_data_path, str) else ""
    is_txt = input_suffix == ".txt"

    # Save raw data only once in raw_data/ by hash+filename
    if parent_raw_data_ref is not None:
        # Use parent's raw_data_ref (for HEAD commits)
        raw_data_ref = parent_raw_data_ref
        input_hash = raw_data_ref["hash"]
        orig_filename = raw_data_ref["filename"]
        raw_data_path = repo.project_root / raw_data_ref["path"]
    else:
        input_hash = sha256_from_bytes(input_bytes)
        raw_data_dir = repo.project_root / "raw_data"
        raw_data_dir.mkdir(parents=True, exist_ok=True)
        orig_filename = Path(source_data_path).name if isinstance(source_data_path, str) else "raw_input"
        raw_data_filename = f"{input_hash}__{orig_filename}"
        raw_data_path = raw_data_dir / raw_data_filename
        if not raw_data_path.exists():
            raw_data_path.write_bytes(input_bytes)
        raw_data_ref = {
            "hash": input_hash,
            "filename": orig_filename,
            "path": str(raw_data_path.relative_to(repo.project_root)),
        }

    # Only save processed data in version folder
    if is_txt:
        def df_to_txt_bytes(df):
            if "text" not in df.columns:
                raise ValueError("TXT output requires a 'text' column.")
            return ("\n".join(df["text"].astype(str).tolist()) + "\n").encode("utf-8")
        processed_bytes = df_to_txt_bytes(processed_dataframe)
        processed_snapshot_name = "processed.txt"
    else:
        from src.hasher import dataframe_to_stable_csv_bytes
        processed_bytes = dataframe_to_stable_csv_bytes(processed_dataframe)
        processed_snapshot_name = "processed.csv"

    config_hash = sha256_from_json(config)
    from src.hasher import build_version_hash
    version_hash = build_version_hash(input_hash, config_hash)

    parent_id = repo.get_head()

    import shutil, tempfile
    timestamp = _now_utc_iso()
    version_dir = repo.versions_root / version_hash
    if version_dir.exists():
        dedupe_event = {
            "event_type": "dedupe_hit",
            "timestamp": timestamp,
            "requested_source_data_path": source_data_path,
            "requested_source_config_path": source_config_path,
            "requested_input_hash": input_hash,
            "requested_config_hash": config_hash,
            "resolved_version_id": version_hash,
            "message": "Run recorded. No new version created; existing version reused.",
        }
        repo.append_log(dedupe_event)
        return {
            "status": "duplicate",
            "version_id": version_hash,
            "head": repo.get_head(),
            "message": "Identical processed output already committed.",
        }

    # Atomic write: write to temp dir, then rename
    temp_dir = repo.versions_root / f"_tmp_{version_hash}"
    temp_dir.mkdir(parents=True, exist_ok=False)

    processed_snapshot_path = temp_dir / processed_snapshot_name
    config_snapshot_path = temp_dir / "config_snapshot.json"
    metadata_path = temp_dir / "metadata.json"

    try:
        processed_snapshot_path.write_bytes(processed_bytes)
        config_snapshot_path.write_text(
            json.dumps(config, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
    except Exception as e:
        print(f"[ERROR] Failed to write snapshot files: {e}")
        raise


    # Compute label distribution and store used label column
    used_label_col, label_dist = _label_distribution(processed_dataframe, config)

    record = VersionRecord(
        version_id=version_hash,
        parent_id=parent_id,
        timestamp=timestamp,
        commit_message=commit_message.strip(),
        source_data_path=source_data_path,
        source_config_path=source_config_path,
        input_hash=input_hash,
        config_hash=config_hash,
        version_hash=version_hash,
        row_count=int(len(processed_dataframe)),
        label_distribution=label_dist,
        eval_metrics=None,
    )

    # Compute processed_csv_hash for integrity
    processed_csv_hash = sha256_from_bytes(processed_bytes)

    metadata: Dict[str, Any] = {
        "event_type": "commit",
        **record.to_dict(),
        "label_column": used_label_col,
        "preprocess_stats": {
            "rows_before": int(len(raw_dataframe)),
            "rows_after": int(len(processed_dataframe)),
            "columns_before": list(map(str, raw_dataframe.columns.tolist())),
            "columns_after": list(map(str, processed_dataframe.columns.tolist())),
        },
        "artifacts": {
            "raw_data_ref": raw_data_ref,
            "processed_snapshot": processed_snapshot_name,
            "config_snapshot": config_snapshot_path.name,
        },
        "output_format": "txt" if is_txt else "csv",
        "processed_csv_hash": processed_csv_hash,
    }

    # raw_data/ archive logic removed for robust, non-duplicative versioning

    metadata_path.write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )

    # Atomic rename
    temp_dir.rename(version_dir)
    # Update version index after commit (HashMap bug fix)
    if hasattr(repo, '_version_index') and repo._version_index is not None:
        repo._version_index[version_hash] = version_dir
    # Update parent/child maps for graph traversal
    if hasattr(repo, '_parent_map') and repo._parent_map is not None:
        repo._parent_map[version_hash] = parent_id
        if parent_id:
            repo._child_map.setdefault(parent_id, []).append(version_hash)
        repo._child_map.setdefault(version_hash, [])

    # Write only minimal info to logs.jsonl
    minimal_log = {
        "event_type": "commit",
        "version_id": version_hash,
        "parent_id": parent_id,
        "timestamp": timestamp,
        "commit_message": commit_message.strip(),
    }
    repo.append_log(minimal_log)
    repo.set_head(version_hash)

    return {
        "status": "created",
        "version_id": version_hash,
        "parent_id": parent_id,
        "head": version_hash,
        "rows_before": int(len(raw_dataframe)),
        "rows_after": int(len(processed_dataframe)),
        "version_path": str(version_dir),
        "metadata_path": str(version_dir / "metadata.json"),
    }


def create_version_from_paths(
    repo: RepoState,
    dataset_path: str,
    config_path: str,
    commit_message: str,
) -> Dict[str, Any]:
    dataset_file, raw_bytes = _normalize_and_read_file(dataset_path)
    config_file, _ = _normalize_and_read_file(config_path)
    config = read_config(str(config_file))
    raw_dataframe = _load_and_validate_dataset(str(dataset_file))
    processed_dataframe = _preprocess_dataframe(raw_dataframe, config)
    return _persist_version(
        repo=repo,
        source_data_path=str(dataset_file),
        source_config_path=str(config_file),
        input_bytes=raw_bytes,
        raw_dataframe=raw_dataframe,
        processed_dataframe=processed_dataframe,
        config=config,
        commit_message=commit_message,
    )


def create_version_from_head(
    repo: RepoState,
    config_path: str,
    commit_message: str,
) -> Dict[str, Any]:
    config_file, _ = _normalize_and_read_file(config_path)
    head_version = repo.get_head()
    if not head_version:
        raise DataLineageError("HEAD is not set. First commit must use a dataset path.")
    head_dir = repo.versions_root / head_version
    import zipfile, tempfile, os
    head_processed_csv = head_dir / "processed.csv"
    head_processed_txt = head_dir / "processed.txt"
    head_processed_json = head_dir / "processed.json"
    head_processed_csv_zip = head_dir / "processed.csv.zip"
    head_processed_txt_zip = head_dir / "processed.txt.zip"
    head_processed_json_zip = head_dir / "processed.json.zip"
    temp_path = None
    try:
        if head_processed_csv.exists():
            head_processed_path = head_processed_csv
        elif head_processed_txt.exists():
            head_processed_path = head_processed_txt
        elif head_processed_json.exists():
            head_processed_path = head_processed_json
        elif head_processed_csv_zip.exists():
            with zipfile.ZipFile(head_processed_csv_zip, 'r') as zf:
                if 'processed.csv' not in zf.namelist():
                    raise DataLineageError(f"processed.csv.zip does not contain processed.csv in {head_dir}")
                with tempfile.NamedTemporaryFile(delete=False, suffix='.csv') as tmp:
                    tmp.write(zf.read('processed.csv'))
                    temp_path = tmp.name
            head_processed_path = Path(temp_path)
        elif head_processed_txt_zip.exists():
            with zipfile.ZipFile(head_processed_txt_zip, 'r') as zf:
                if 'processed.txt' not in zf.namelist():
                    raise DataLineageError(f"processed.txt.zip does not contain processed.txt in {head_dir}")
                with tempfile.NamedTemporaryFile(delete=False, suffix='.txt') as tmp:
                    tmp.write(zf.read('processed.txt'))
                    temp_path = tmp.name
            head_processed_path = Path(temp_path)
        elif head_processed_json_zip.exists():
            with zipfile.ZipFile(head_processed_json_zip, 'r') as zf:
                if 'processed.json' not in zf.namelist():
                    raise DataLineageError(f"processed.json.zip does not contain processed.json in {head_dir}")
                with tempfile.NamedTemporaryFile(delete=False, suffix='.json') as tmp:
                    tmp.write(zf.read('processed.json'))
                    temp_path = tmp.name
            head_processed_path = Path(temp_path)
        else:
            raise DataLineageError(
                f"HEAD processed snapshot not found: {head_processed_csv}, {head_processed_txt}, {head_processed_json}, {head_processed_csv_zip}, {head_processed_txt_zip}, {head_processed_json_zip}"
            )
        config = read_config(str(config_file))
        raw_dataframe = _load_and_validate_dataset(str(head_processed_path))
        processed_dataframe = _preprocess_dataframe(raw_dataframe, config)
        parent_metadata_path = head_dir / "metadata.json"
        if not parent_metadata_path.exists():
            raise DataLineageError(f"Parent metadata.json not found for HEAD version: {head_version}")
        with open(parent_metadata_path, "r", encoding="utf-8") as f:
            parent_metadata = json.load(f)
        parent_raw_data_ref = parent_metadata.get("artifacts", {}).get("raw_data_ref")
        if not parent_raw_data_ref:
            raise DataLineageError(f"Parent raw_data_ref not found in metadata.json for HEAD version: {head_version}")
        return _persist_version(
            repo=repo,
            source_data_path=f"HEAD:{head_version}",
            source_config_path=str(config_file),
            input_bytes=None,  # Not needed for HEAD
            raw_dataframe=raw_dataframe,
            processed_dataframe=processed_dataframe,
            config=config,
            commit_message=commit_message,
            parent_raw_data_ref=parent_raw_data_ref
        )
    finally:
        if temp_path is not None:
            try:
                os.remove(temp_path)
            except Exception:
                pass


def create_version_from_raw_default(
    repo: RepoState,
    dataset_path: str,
    commit_message: str,
) -> Dict[str, Any]:
    dataset_file, raw_bytes = _normalize_and_read_file(dataset_path)
    raw_dataframe = _load_and_validate_dataset(str(dataset_file))
    config = get_default_preprocess_config()
    processed_dataframe = _preprocess_dataframe(raw_dataframe, config)
    return _persist_version(
        repo=repo,
        source_data_path=str(dataset_file),
        source_config_path="DEFAULT_CONFIG",
        input_bytes=raw_bytes,
        raw_dataframe=raw_dataframe,
        processed_dataframe=processed_dataframe,
        config=config,
        commit_message=commit_message,
    )


def create_version_from_raw_no_preprocessing(
    repo: RepoState,
    dataset_path: str,
    commit_message: str,
) -> Dict[str, Any]:
    dataset_file, raw_bytes = _normalize_and_read_file(dataset_path)
    raw_dataframe = _load_and_validate_dataset(str(dataset_file))
    config = {"preprocessing": "none", "note": "Raw data stored without preprocessing"}
    processed_dataframe = raw_dataframe.copy()
    return _persist_version(
        repo=repo,
        source_data_path=str(dataset_file),
        source_config_path="NO_PREPROCESSING",
        input_bytes=raw_bytes,
        raw_dataframe=raw_dataframe,
        processed_dataframe=processed_dataframe,
        config=config,
        commit_message=commit_message,
    )
