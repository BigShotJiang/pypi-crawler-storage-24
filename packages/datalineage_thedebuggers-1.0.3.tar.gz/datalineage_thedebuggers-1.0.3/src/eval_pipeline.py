def _select_text_column(df, config, allow_user_input, verbose):
    text_columns = config.get("text_columns")
    if text_columns:
        if not isinstance(text_columns, (list, tuple, set)):
            text_columns = [text_columns]
        candidates = [c for c in text_columns if c in df.columns]
    else:
        candidates = []
    if not candidates:
        candidates = list(df.select_dtypes(include=["object", "string"]).columns)
    if not candidates:
        if verbose:
            print("[EVAL] No valid text columns found in data.")
        return None
    if allow_user_input and len(candidates) > 1:
        print(f"Multiple text columns detected: {candidates}")
        text_col = input("Select text column: ").strip()
        if text_col not in candidates:
            print("[EVAL] Invalid text column selected.")
            return None
        return text_col
    return candidates[0]

def _select_label_column(df, config, text_col, allow_user_input, verbose):
    non_text = [c for c in df.columns if c != text_col]
    if "label_column" in config and config["label_column"] in df.columns:
        return config["label_column"]
    if not non_text:
        if verbose:
            print("[EVAL] No valid label columns found in data.")
        return None
    if allow_user_input and len(non_text) > 1:
        print(f"Multiple label columns detected: {non_text}")
        label_col = input("Select label column: ").strip()
        if label_col not in non_text:
            print("[EVAL] Invalid label column selected.")
            return None
        return label_col
    return non_text[0]

def _save_bow_report(repo, version_id, text_col, label_col, metrics, n_train, n_test, verbose):
    reports_dir = repo.project_root / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    report = {
        "version_id": version_id,
        "text_column": text_col,
        "label_column": label_col,
        "metrics": metrics,
        "n_train": int(n_train),
        "n_test": int(n_test),
        "timestamp": ts,
    }
    report_path = reports_dir / f"bow_{version_id[:8]}_{ts}.json"
    with open(report_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    if verbose:
        print(f"Report saved: {report_path}")
    return report_path
# Unified evaluation and training pipeline for DataLineage
import json
import numpy as np
from src.bow_model import BagOfWords
from src.io_loader import load_dataset
from datetime import datetime
from pathlib import Path

def evaluate_and_train_bow(repo, version_id, allow_user_input=False, verbose=True, save_report=True):
    """
    Unified pipeline for evaluating/training Bag-of-Words model on a version.
    If allow_user_input is True, will prompt for ambiguous columns.
    Returns metrics dict or None on error.
    """
    version_dir = repo.versions_root / version_id
    if not version_dir.exists():
        if verbose:
            print(f"[EVAL] Version directory not found: {version_dir}")
        return None
    processed_csv = version_dir / "processed.csv"
    processed_txt = version_dir / "processed.txt"
    processed_json = version_dir / "processed.json"
    processed_csv_zip = version_dir / "processed.csv.zip"
    processed_txt_zip = version_dir / "processed.txt.zip"
    processed_json_zip = version_dir / "processed.json.zip"
    config_path = version_dir / "config_snapshot.json"
    metadata_path = version_dir / "metadata.json"
    import zipfile, tempfile, os
    tmp_path = None
    try:
        if processed_csv.exists():
            data_path = processed_csv
        elif processed_txt.exists():
            data_path = processed_txt
        elif processed_json.exists():
            data_path = processed_json
        elif processed_csv_zip.exists():
            with zipfile.ZipFile(processed_csv_zip, 'r') as zf:
                if 'processed.csv' not in zf.namelist():
                    if verbose:
                        print("[EVAL] processed.csv.zip does not contain processed.csv.")
                    return None
                with tempfile.NamedTemporaryFile(delete=False, suffix='.csv') as tmp:
                    tmp.write(zf.read('processed.csv'))
                    tmp_path = tmp.name
            data_path = Path(tmp_path)
        elif processed_txt_zip.exists():
            with zipfile.ZipFile(processed_txt_zip, 'r') as zf:
                if 'processed.txt' not in zf.namelist():
                    if verbose:
                        print("[EVAL] processed.txt.zip does not contain processed.txt.")
                    return None
                with tempfile.NamedTemporaryFile(delete=False, suffix='.txt') as tmp:
                    tmp.write(zf.read('processed.txt'))
                    tmp_path = tmp.name
            data_path = Path(tmp_path)
        elif processed_json_zip.exists():
            with zipfile.ZipFile(processed_json_zip, 'r') as zf:
                if 'processed.json' not in zf.namelist():
                    if verbose:
                        print("[EVAL] processed.json.zip does not contain processed.json.")
                    return None
                with tempfile.NamedTemporaryFile(delete=False, suffix='.json') as tmp:
                    tmp.write(zf.read('processed.json'))
                    tmp_path = tmp.name
            data_path = Path(tmp_path)
        else:
            if verbose:
                print("[EVAL] Processed data not found in version directory.")
            return None
        if not config_path.exists():
            if verbose:
                print(f"[EVAL] Config snapshot not found: {config_path}")
            return None
        # Load data and config (only once)
        if verbose:
            print("Loading dataset...")
        df, _ = load_dataset(str(data_path))
        if verbose:
            print("Loading config...")
        with open(config_path, "r", encoding="utf-8") as f:
            config = json.load(f)
        text_col = _select_text_column(df, config, allow_user_input, verbose)
        if not text_col:
            return None
        label_col = _select_label_column(df, config, text_col, allow_user_input, verbose)
        if not label_col:
            return None
    finally:
        if tmp_path is not None:
            try:
                os.unlink(tmp_path)
            except Exception:
                pass
    if verbose:
        print(f"Using text column: {text_col}, label column: {label_col}")
    X_raw = df[text_col].astype(str).tolist()
    y_raw = df[label_col].astype(str).tolist()
    n = len(X_raw)
    idx = np.arange(n)
    np.random.seed(42)
    np.random.shuffle(idx)
    split = int(0.8 * n)
    X_train = [X_raw[i] for i in idx[:split]]
    y_train = [y_raw[i] for i in idx[:split]]
    X_test = [X_raw[i] for i in idx[split:]]
    y_test = [y_raw[i] for i in idx[split:]]
    if verbose:
        print("Training Bag-of-Words model...")
    model = BagOfWords(text_col, label_col)
    model.fit(X_train, y_train)
    if verbose:
        print("Evaluating model...")
    metrics = model.evaluate(X_test, y_test)
    if save_report:
        _save_bow_report(repo, version_id, text_col, label_col, metrics, len(X_train), len(X_test), verbose)
    # Optionally update metadata.json
    if metadata_path.exists():
        with open(metadata_path, "r", encoding="utf-8") as f:
            metadata = json.load(f)
        metadata['eval_metrics'] = metrics
        with open(metadata_path, "w", encoding="utf-8") as f:
            json.dump(metadata, f, indent=2, ensure_ascii=False)
        if verbose:
            print(f"[EVAL] Evaluation metrics updated in {metadata_path}")
    return metrics
