import json
from pathlib import Path
from typing import Dict, Tuple

import pandas as pd

from src.errors import ValidationError


def read_config(config_path: str) -> Dict:
    path = Path(config_path)
    if not path.exists() or not path.is_file():
        raise ValidationError(f"Config file not found: {config_path}")

    if path.suffix.lower() != ".json":
        raise ValidationError("Config file must be a .json file in this prototype.")

    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as error:
        raise ValidationError(f"Invalid JSON config: {error}") from error


def load_dataset(dataset_path: str) -> Tuple[pd.DataFrame, str]:
    path = Path(dataset_path)
    if not path.exists() or not path.is_file():
        raise ValidationError(f"Dataset file not found: {dataset_path}")

    suffix = path.suffix.lower()
    if suffix in [".csv", ".tsv"]:
        # Try UTF-8 first, fallback to latin-1
        try:
            dataframe = pd.read_csv(path, encoding="utf-8")
        except UnicodeDecodeError:
            dataframe = pd.read_csv(path, encoding="latin-1")
        # If only one column and file is .csv or .tsv, try tab separator
        if len(dataframe.columns) == 1 and suffix in [".csv", ".tsv"]:
            try:
                dataframe = pd.read_csv(path, sep="\t", encoding="utf-8")
            except UnicodeDecodeError:
                dataframe = pd.read_csv(path, sep="\t", encoding="latin-1")
    elif suffix == ".json":
        try:
            dataframe = pd.read_json(path)
        except ValueError:
            dataframe = pd.read_json(path, lines=True)
    elif suffix == ".txt":
        # Each line is a document/text sample; store as DataFrame with one column 'text', filter empty lines
        try:
            lines = [l for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]
        except UnicodeDecodeError:
            lines = [l for l in path.read_text(encoding="latin-1").splitlines() if l.strip()]
        dataframe = pd.DataFrame({"text": lines})
    else:
        raise ValidationError("Only CSV, TSV, JSON, and TXT input are supported in this prototype.")

    if dataframe.empty:
        raise ValidationError("Loaded dataset is empty.")

    return dataframe, suffix


def validate_schema(dataframe: pd.DataFrame) -> None:
    # Critical errors
    if dataframe is None or dataframe.empty:
        raise ValidationError("Dataset schema invalid: dataset is empty.")
    if len(dataframe.columns) == 0:
        raise ValidationError("Dataset schema invalid: no columns found.")

    # Warnings (print, don't raise)
    # 1. Few rows
    if len(dataframe) < 3:
        print("Warning: Dataset has very few rows. This may indicate a header issue or an incomplete file.")

    # 2. Non-string or empty column names
    bad_names = [col for col in dataframe.columns if not isinstance(col, str) or not col.strip()]
    if bad_names:
        print(f"Warning: Some columns have empty or non-string names: {bad_names}")

    # 3. Duplicate column names
    if dataframe.columns.duplicated().any():
        dups = dataframe.columns[dataframe.columns.duplicated()].tolist()
        print(f"Warning: Duplicate column names found: {dups}")

    # 4. Completely empty columns
    empty_cols = [col for col in dataframe.columns if dataframe[col].isnull().all()]
    if empty_cols:
        print(f"Warning: The following columns are completely empty: {empty_cols}")

    # 5. Columns with only one unique value (not always an error, but often a sign of a problem)
    constant_cols = [col for col in dataframe.columns if dataframe[col].nunique(dropna=True) <= 1]
    if constant_cols:
        print(f"Warning: The following columns have only one unique value: {constant_cols}")

    # 6. Columns with >50% missing values (common ML pain point)
    mostly_null_cols = [col for col in dataframe.columns if dataframe[col].isnull().mean() > 0.5]
    if mostly_null_cols:
        print(f"Warning: The following columns have more than 50% missing values: {mostly_null_cols}")

    # 7. High cardinality categorical columns (can cause ML issues)
    high_card_cols = [col for col in dataframe.select_dtypes(include=["object", "string"]).columns if dataframe[col].nunique() > 100]
    if high_card_cols:
        print(f"Warning: The following categorical columns have >100 unique values (high cardinality): {high_card_cols}")
