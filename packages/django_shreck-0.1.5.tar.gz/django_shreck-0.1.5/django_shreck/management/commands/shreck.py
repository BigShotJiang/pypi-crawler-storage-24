from django.core.management.base import BaseCommand


class Command(BaseCommand):
    help = "Launch the Shreck TUI shell — a rich terminal interface for Django"


    def handle(self, *args, **options):
        import os

        # Textual runs an asyncio event loop internally. Django raises
        # SynchronousOnlyOperation when sync ORM calls are detected inside
        # an async context. Since all ORM usage in Shreck is intentionally
        # synchronous (run in the main thread / thread workers), we disable
        # the async-safety guard so queries work normally.
        os.environ.setdefault("DJANGO_ALLOW_ASYNC_UNSAFE", "true")

        self.stdout.write(self.style.SUCCESS("Starting Shreck TUI..."))

        from django_shreck.app import ShreckApp

        app = ShreckApp()
        app.run()

