from django.apps import AppConfig


class DjangoShreckConfig(AppConfig):
    name = "django_shreck"
    verbose_name = "Django Shreck"
    default_auto_field = "django.db.models.BigAutoField"

