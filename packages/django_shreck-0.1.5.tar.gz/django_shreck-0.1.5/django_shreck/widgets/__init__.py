from django_shreck.widgets.shell_widget import ShellWidget
from django_shreck.widgets.detail_widget import DetailWidget
from django_shreck.widgets.compare_widget import CompareWidget
from django_shreck.widgets.table_widget import TableWidget
from django_shreck.widgets.result_panel import ResultPanel
from django_shreck.widgets.model_browser_widget import ModelBrowserWidget

__all__ = [
    "ShellWidget",
    "DetailWidget",
    "CompareWidget",
    "TableWidget",
    "ResultPanel",
    "ModelBrowserWidget",
]

