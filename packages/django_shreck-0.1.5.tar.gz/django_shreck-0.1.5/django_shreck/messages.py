from textual.message import Message


class ShowDetail(Message):
    """Request to display a single model instance in the detail view."""

    def __init__(self, instance: object, editable: bool = False, start_editing: bool = False) -> None:
        super().__init__()
        self.instance = instance
        self.editable = editable
        self.start_editing = start_editing


class ShowTable(Message):
    """Request to display a queryset as a scrollable table."""

    def __init__(self, queryset: object) -> None:
        super().__init__()
        self.queryset = queryset


class ShowCompare(Message):
    """Request to display multiple model instances side by side."""

    def __init__(self, instances: list) -> None:
        super().__init__()
        self.instances = instances


class ShowCreate(Message):
    """Request to display a blank edit form for creating a new model instance."""

    def __init__(self, model: object) -> None:
        super().__init__()
        self.model = model


class GoBack(Message):
    """Request to navigate back to the previous view."""


class ModelCursorChanged(Message):
    """Posted when the cursor moves to a different model in the model browser."""

    def __init__(self, model) -> None:
        super().__init__()
        self.model = model

