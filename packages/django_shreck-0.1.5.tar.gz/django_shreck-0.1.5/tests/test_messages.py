"""Tests for the Textual app and message routing."""

from django_shreck.messages import (
    ShowDetail,
    ShowTable,
    ShowCompare,
    ShowCreate,
    GoBack,
    ModelCursorChanged,
)


class TestMessages:
    """Tests that custom Textual messages can be instantiated correctly."""

    def test_show_detail_message(self):
        msg = ShowDetail(instance="fake_instance", editable=True)
        assert msg.instance == "fake_instance"
        assert msg.editable is True

    def test_show_detail_default_not_editable(self):
        msg = ShowDetail(instance="fake_instance")
        assert msg.editable is False

    def test_show_detail_start_editing(self):
        msg = ShowDetail(instance="fake_instance", start_editing=True)
        assert msg.start_editing is True

    def test_show_table_message(self):
        msg = ShowTable(queryset="fake_queryset")
        assert msg.queryset == "fake_queryset"

    def test_show_compare_message(self):
        msg = ShowCompare(instances=["obj1", "obj2", "obj3"])
        assert msg.instances == ["obj1", "obj2", "obj3"]

    def test_show_create_message(self):
        msg = ShowCreate(model="fake_model")
        assert msg.model == "fake_model"

    def test_go_back_message(self):
        msg = GoBack()
        assert isinstance(msg, GoBack)

    def test_model_cursor_changed_message(self):
        msg = ModelCursorChanged(model="fake_model")
        assert msg.model == "fake_model"


