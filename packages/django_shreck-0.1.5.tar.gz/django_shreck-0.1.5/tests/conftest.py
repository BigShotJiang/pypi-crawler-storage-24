import django
from django.conf import settings


def pytest_configure():
    """Configure Django settings for the test suite."""
    if not settings.configured:
        settings.configure(
            INSTALLED_APPS=[
                "django.contrib.contenttypes",
                "django.contrib.auth",
                "django.contrib.admin",
                "django_shreck",
            ],
            DATABASES={
                "default": {
                    "ENGINE": "django.db.backends.sqlite3",
                    "NAME": ":memory:",
                }
            },
            ROOT_URLCONF="tests.urls",
            DEFAULT_AUTO_FIELD="django.db.models.BigAutoField",
            SECRET_KEY="test-secret-key-not-for-production",
        )
        django.setup()

