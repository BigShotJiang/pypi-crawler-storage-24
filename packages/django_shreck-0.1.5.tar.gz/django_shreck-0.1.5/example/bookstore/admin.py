from __future__ import annotations

from django.contrib import admin

from .models import Author, Book, Genre, Order


@admin.register(Genre)
class GenreAdmin(admin.ModelAdmin):
    list_display = ("name",)
    search_fields = ("name",)


@admin.register(Author)
class AuthorAdmin(admin.ModelAdmin):
    list_display = ("last_name", "first_name", "born")
    search_fields = ("first_name", "last_name")
    list_filter = ("born",)


@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ("title", "author", "genre", "published", "price", "in_stock")
    list_filter = ("genre", "in_stock")
    search_fields = ("title", "isbn", "author__last_name")
    date_hierarchy = "published"


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("pk", "book", "quantity", "customer_email", "ordered_at", "shipped")
    list_filter = ("shipped",)
    search_fields = ("customer_email", "book__title")
    date_hierarchy = "ordered_at"

