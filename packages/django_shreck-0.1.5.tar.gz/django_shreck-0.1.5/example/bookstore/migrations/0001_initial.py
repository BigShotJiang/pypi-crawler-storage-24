from __future__ import annotations

import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="Genre",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("name", models.CharField(max_length=100, unique=True)),
                ("description", models.TextField(blank=True)),
            ],
            options={
                "ordering": ["name"],
            },
        ),
        migrations.CreateModel(
            name="Author",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("first_name", models.CharField(max_length=100)),
                ("last_name", models.CharField(max_length=100)),
                ("bio", models.TextField(blank=True)),
                ("born", models.DateField(blank=True, null=True)),
            ],
            options={
                "ordering": ["last_name", "first_name"],
            },
        ),
        migrations.CreateModel(
            name="Book",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("title", models.CharField(max_length=200)),
                ("author", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="books", to="bookstore.author")),
                ("genre", models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="books", to="bookstore.genre")),
                ("published", models.DateField()),
                ("isbn", models.CharField(max_length=20, unique=True)),
                ("price", models.DecimalField(decimal_places=2, max_digits=8)),
                ("in_stock", models.BooleanField(default=True)),
            ],
            options={
                "ordering": ["title"],
            },
        ),
        migrations.CreateModel(
            name="Order",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("book", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="orders", to="bookstore.book")),
                ("quantity", models.PositiveIntegerField(default=1)),
                ("customer_email", models.EmailField(max_length=254)),
                ("ordered_at", models.DateTimeField(auto_now_add=True)),
                ("shipped", models.BooleanField(default=False)),
            ],
            options={
                "ordering": ["-ordered_at"],
            },
        ),
    ]

