# django-shreck — Example App

A minimal **Bookstore** Django project that lets you try out `django-shreck` immediately.

## Models

| Model    | Fields                                                   |
|----------|----------------------------------------------------------|
| `Genre`  | `name`, `description`                                   |
| `Author` | `first_name`, `last_name`, `bio`, `born`                |
| `Book`   | `title`, `author`, `genre`, `published`, `isbn`, `price`, `in_stock` |
| `Order`  | `book`, `quantity`, `customer_email`, `ordered_at`, `shipped` |

## Quick Start

Make sure you have installed `django-shreck` from the repo root first:

```bash
# from the repository root
pip install -e ".[dev]"
```

Then set up and run the example:

```bash
cd example/
python manage.py migrate        # create the SQLite database
python manage.py seed_data      # load sample data (4 genres, 4 authors, 8 books, 10 orders)
python manage.py shreck         # launch the TUI 🚀
```

Or use the Makefile shortcuts from the repo root:

```bash
make example-setup   # migrate + seed
make example-run     # launch the TUI
```

## Things to Try in the Shell

```python
# Table view (3+ results)
Book.objects.all()

# Compare view (2 results)
Book.objects.filter(author__last_name="Orwell")

# Detail view (1 result)
Book.objects.get(pk=1)

# Single model instance → detail view
Author.objects.first()

# Cheap books
Book.objects.filter(price__lt=10)

# Pending orders
Order.objects.filter(shipped=False)
```

