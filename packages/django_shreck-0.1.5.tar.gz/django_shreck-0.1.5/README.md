# 🟢 django-shreck

> A rich TUI replacement for Django's `shell_plus` — browse models and querysets from your terminal.

![Python 3.11+](https://img.shields.io/badge/python-3.11+-blue.svg)
![Django 4.2+](https://img.shields.io/badge/django-4.2+-green.svg)
![License: MIT](https://img.shields.io/badge/license-MIT-yellow.svg)

## Screenshots

<p>
  <img src="docs/Screenshot_2026-03-21_07-56-03.png" width="48%" alt="Shell and table view" />
  <img src="docs/Screenshot_2026-03-21_07-57-53.png" width="48%" alt="Detail view" />
</p>
<p>
  <img src="docs/Screenshot_2026-03-21_07-58-18.png" width="48%" alt="Inline editing" />
  <img src="docs/Screenshot_2026-03-21_07-58-58.png" width="48%" alt="Side-by-side compare" />
</p>

> 🎬 [Watch the screencast](docs/screencast.mp4)

## Features

- **Auto-imported models** — All your Django models are available immediately with tab completion
- **Interactive shell** — Full Python REPL with auto-imported models and history
- **Scrollable table view** — QuerySets are rendered as rich, scrollable tables
- **Detail browser** — Single objects displayed as navigable key-value detail views
- **Inline editing** — Edit and save single model instances directly from the TUI
- **Side-by-side compare** — Two objects rendered in a diff-style comparison view
- **Admin integration** — Single keypress opens the Django admin for any object or queryset

## Installation

```bash
pip install django-shreck
```

Add to your `INSTALLED_APPS`:

```python
INSTALLED_APPS = [
    # ...
    "django_shreck",
]
```

## Usage

```bash
python manage.py shreck
```

### Keybindings

| Key | Action |
|-----|--------|
| `q` | Quit |
| `a` | Open admin for current object/queryset |
| `Enter` | Execute shell input |
| `↑/↓` | Browse fields / scroll table |
| `Tab` | Auto-complete |

## Development

```bash
git clone https://github.com/belda/django-shreck.git
cd django-shreck
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev]"
make test
```

## License

MIT

