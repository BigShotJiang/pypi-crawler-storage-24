"""Main entry point for Reportify API CLI."""

import typer
from typer.core import TyperGroup

from src.commands import agent, channels, concepts, docs, following, kb, macro, quant, search, stock, timeline, user


class AliasGroup(TyperGroup):
    """Custom TyperGroup that supports -h as alias for --help. """

    def parse_args(self, ctx, args):
        # Replace -h with --help
        args = ["--help" if arg == "-h" else arg for arg in args]
        return super().parse_args(ctx, args)


app = typer.Typer(
    help="Reportify API CLI - Access all Reportify SDK features via command line",
    rich_markup_mode="rich",
    no_args_is_help=True,
    cls=AliasGroup,
)

# Add all command modules as sub-apps
app.add_typer(search.app, name="search", help="Document search")
app.add_typer(docs.app, name="docs", help="Document management")
app.add_typer(kb.app, name="kb", help="Knowledge base")
app.add_typer(stock.app, name="stock", help="Stock data")
app.add_typer(quant.app, name="quant", help="Quantitative analysis")
app.add_typer(macro.app, name="macro", help="Macro economic data")
app.add_typer(timeline.app, name="timeline", help="Timeline")
app.add_typer(channels.app, name="channels", help="Channel management")
app.add_typer(following.app, name="following", help="Follow group management")
app.add_typer(concepts.app, name="concepts", help="Concept dynamics")
app.add_typer(user.app, name="user", help="User data")
app.add_typer(agent.app, name="agent", help="Agent conversations")


def main():
    """Main entry point."""
    app()


if __name__ == "__main__":
    main()
