# mng-kanpan

This package has been renamed to [imbue-mngr-kanpan](https://pypi.org/project/imbue-mngr-kanpan/).

Install the new package:

```
pip install imbue-mngr-kanpan
```
