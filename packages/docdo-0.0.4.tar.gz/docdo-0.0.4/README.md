# Docdo

CLI tool that converts Markdown files to PDF using Playwright and CSS themes.

## Install

```bash
uv tool install docdo
playwright install chromium
```

## Usage

```bash
docdo -i README.md                       # outputs README.pdf next to it
docdo -i docs/ -o out/                   # converts a whole folder
docdo -i README.md -t dracula            # use a built-in theme
docdo -i README.md -t ./my-style.css     # use a custom CSS file
```

| Flag | Description |
|------|-------------|
| `-i`, `--input` | Markdown file or folder (required) |
| `-o`, `--output` | Output PDF file or folder (defaults to input location) |
| `-t`, `--theme` | Built-in theme name (`default`, `dracula`) or path to a `.css` file |

## Themes

Built-in themes live in `src/docdo/themes/`. To add your own, drop a `.css` file there or just pass any CSS file path with `-t`.

## How it works

1. Parses Markdown with `markdown-it-py` (with `pygments` for syntax highlighting).
2. Wraps the HTML with the selected CSS theme.
3. Renders to PDF via Playwright (headless Chromium).

## Dev

```bash
uv sync
uv run docdo -i README.md
```
