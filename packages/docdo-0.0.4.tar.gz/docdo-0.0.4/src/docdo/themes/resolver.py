"""Theme resolver: maps a name or CSS file path to a CSS string."""

from __future__ import annotations

import importlib.resources
from pathlib import Path

# Built-in theme registry: name → filename inside the themes/ package directory
_BUILTIN_THEMES: dict[str, str] = {
    "default": "default.css",
    "dracula": "dracula.css",
}


def list_themes() -> list[str]:
    """Return the names of all built-in themes."""
    return list(_BUILTIN_THEMES.keys())


def load_theme(theme: str | None) -> str:
    """Resolve *theme* to a CSS string.

    *theme* may be:
    - ``None`` or ``"default"`` → built-in default theme
    - A registered theme name (e.g. ``"dracula"``)
    - An absolute or relative path to a ``.css`` file

    Raises:
        FileNotFoundError: if *theme* is a path that does not exist.
        ValueError: if *theme* is an unrecognised name.
    """
    if not theme:
        theme = "default"

    # Check if it looks like a file path
    path = Path(theme)
    if path.suffix.lower() == ".css":
        if not path.is_file():
            raise FileNotFoundError(
                f"Theme CSS file not found: {path.resolve()}"
            )
        return path.read_text(encoding="utf-8")

    # Treat as a built-in theme name
    if theme not in _BUILTIN_THEMES:
        choices = ", ".join(sorted(_BUILTIN_THEMES))
        raise ValueError(
            f"Unknown theme '{theme}'. "
            f"Available built-in themes: {choices}. "
            "You can also pass a path to a .css file."
        )

    filename = _BUILTIN_THEMES[theme]
    # Use importlib.resources for reliable access inside installed packages
    package = importlib.resources.files("docdo.themes")
    css_path = package.joinpath(filename)
    return css_path.read_text(encoding="utf-8")
