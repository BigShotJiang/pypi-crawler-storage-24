"""Built-in themes package — CSS files live here as package data."""

from docdo.themes.resolver import list_themes, load_theme

__all__ = ["list_themes", "load_theme"]
