"""Click CLI entry point for docdo."""

from __future__ import annotations

import sys
from pathlib import Path

import click

from docdo import themes as _themes
from docdo.converter import convert as _convert


def _default_output(input_path: Path) -> Path:
    """Return a default PDF path next to the input file."""
    return input_path.with_suffix(".pdf")


@click.command(context_settings={"help_option_names": ["-h", "--help"]})
@click.option(
    "-i", "--input", "input_path",
    required=True,
    type=click.Path(exists=True, readable=True, path_type=Path),
    help="Input Markdown file or folder.",
)
@click.option(
    "-o", "--output", "output_path",
    default=None,
    type=click.Path(path_type=Path),
    help="Output PDF file or folder. Defaults to the input location.",
)
@click.option(
    "-t", "--theme",
    default=None,
    metavar="NAME_OR_PATH",
    help=(
        f"Theme name ({', '.join(_themes.list_themes())}) "
        "or path to a .css file. Defaults to 'default'."
    ),
)
@click.version_option(package_name="docdo")
def main(input_path: Path, output_path: Path | None, theme: str | None) -> None:
    """Convert Markdown files to PDF with beautiful CSS themes."""

    if input_path.is_dir():
        _convert_folder(input_path, output_path, theme)
    else:
        _convert_file(input_path, output_path, theme)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _convert_file(
    input_path: Path,
    output_path: Path | None,
    theme: str | None,
) -> None:
    if output_path is None:
        output_path = _default_output(input_path)
    if output_path.is_dir():
        output_path = output_path / input_path.with_suffix(".pdf").name

    click.echo(f"  → {input_path.name}  ➜  {output_path}")
    try:
        _convert(input_path, output_path, theme)
    except (FileNotFoundError, ValueError) as exc:
        click.secho(f"Error: {exc}", fg="red", err=True)
        sys.exit(1)
    click.secho("  ✓ Done", fg="green")


def _convert_folder(
    input_folder: Path,
    output_folder: Path | None,
    theme: str | None,
) -> None:
    md_files = sorted(input_folder.rglob("*.md"))
    if not md_files:
        click.secho(f"No .md files found in {input_folder}", fg="yellow")
        return

    if output_folder is None:
        output_folder = input_folder

    output_folder.mkdir(parents=True, exist_ok=True)
    errors = 0

    for md_file in md_files:
        # Preserve sub-folder structure relative to input_folder
        relative = md_file.relative_to(input_folder)
        out_file = output_folder / relative.with_suffix(".pdf")
        out_file.parent.mkdir(parents=True, exist_ok=True)

        click.echo(f"  → {relative}  ➜  {out_file.relative_to(output_folder)}")
        try:
            _convert(md_file, out_file, theme)
            click.secho("    ✓", fg="green")
        except Exception as exc:  # noqa: BLE001
            click.secho(f"    ✗ {exc}", fg="red", err=True)
            errors += 1

    total = len(md_files)
    success = total - errors
    color = "green" if errors == 0 else "yellow"
    click.secho(
        f"\nConverted {success}/{total} file(s).",
        fg=color,
    )
    if errors:
        sys.exit(1)
