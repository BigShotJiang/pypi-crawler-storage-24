"""HTML → PDF exporter via Playwright (headless Chromium)."""

from __future__ import annotations

import tempfile
from pathlib import Path

from playwright.sync_api import sync_playwright


def html_to_pdf(html: str, output_path: Path) -> None:
    """Render *html* to a PDF file at *output_path*.

    Args:
        html:        Complete HTML document string.
        output_path: Destination path for the generated PDF (created/overwritten).

    Raises:
        RuntimeError: If Playwright fails to render the page.
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # Write the HTML to a temporary file so that relative paths (images, etc.)
    # resolve correctly from the file's directory.
    with tempfile.NamedTemporaryFile(
        suffix=".html", mode="w", encoding="utf-8", delete=False
    ) as tmp:
        tmp.write(html)
        tmp_path = Path(tmp.name)

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch()
            page = browser.new_page()
            page.goto(tmp_path.as_uri(), wait_until="networkidle")
            page.pdf(
                path=str(output_path),
                format="A4",
                print_background=True,
                margin={"top": "0", "right": "0", "bottom": "0", "left": "0"},
            )
            browser.close()
    finally:
        tmp_path.unlink(missing_ok=True)
