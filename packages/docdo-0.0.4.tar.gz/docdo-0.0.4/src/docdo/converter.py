"""High-level converter: glues themes, renderer, and PDF exporter together."""

from __future__ import annotations

from pathlib import Path

from docdo import pdf as _pdf
from docdo import renderer as _renderer
from docdo import themes as _themes


def convert(
    input_path: str | Path,
    output_path: str | Path,
    theme: str | None = None,
) -> None:
    """Convert a single Markdown file to PDF.

    Args:
        input_path:  Path to the source ``.md`` file.
        output_path: Destination path for the generated ``.pdf`` file.
        theme:       Built-in theme name or path to a ``.css`` file.
                     Defaults to the ``"default"`` theme.

    Raises:
        FileNotFoundError: If *input_path* does not exist.
        ValueError:        If *theme* is an unknown name and not a valid path.
    """
    input_path = Path(input_path)
    output_path = Path(output_path)

    if not input_path.is_file():
        raise FileNotFoundError(f"Input file not found: {input_path.resolve()}")

    markdown_source = input_path.read_text(encoding="utf-8")
    css = _themes.load_theme(theme)
    html = _renderer.render(markdown_source, css)
    _pdf.html_to_pdf(html, output_path)
