"""docdo - Markdown to PDF converter."""

from docdo.converter import convert

__all__ = ["convert"]
