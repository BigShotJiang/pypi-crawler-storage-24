"""Markdown → styled HTML page renderer."""

from __future__ import annotations

import re

from pygments import highlight
from pygments.formatters import HtmlFormatter
from pygments.lexers import get_lexer_by_name, guess_lexer
from pygments.util import ClassNotFound


# ---------------------------------------------------------------------------
# Syntax highlighter (used as a callback by markdown-it-py)
# ---------------------------------------------------------------------------


def _highlight_code(code: str, lang: str, _info: str) -> str:
    """Pygments syntax highlighter called by markdown-it-py."""
    try:
        lexer = get_lexer_by_name(lang, stripall=True) if lang else guess_lexer(code)
    except ClassNotFound:
        lexer = guess_lexer(code)

    formatter = HtmlFormatter(nowrap=True)
    highlighted = highlight(code, lexer, formatter)
    return f'<pre class="highlight"><code>{highlighted}</code></pre>'


# ---------------------------------------------------------------------------
# Markdown parser (created after the highlight callback is defined)
# ---------------------------------------------------------------------------

from markdown_it import MarkdownIt  # noqa: E402

_md = MarkdownIt("js-default", {
    "highlight": _highlight_code,
    "breaks": True
    }
)
_md.enable("table")
_md.enable("strikethrough")


# ---------------------------------------------------------------------------
# HTML page template
# ---------------------------------------------------------------------------

_HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>{title}</title>
  <style>
{css}
  </style>
</head>
<body>
  <div class="md-page">
{body}
  </div>
</body>
</html>
"""


def _derive_title(markdown_source: str) -> str:
    """Extract an H1 title from the Markdown source, falling back to 'Document'."""
    match = re.search(r"^#\s+(.+)$", markdown_source, re.MULTILINE)
    return match.group(1).strip() if match else "Document"


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def render(markdown_source: str, css: str) -> str:
    """Convert *markdown_source* to a full HTML page string styled with *css*.

    Args:
        markdown_source: Raw Markdown text.
        css:             CSS string (already resolved by the themes module).

    Returns:
        A complete, self-contained HTML document as a string.
    """
    body_html = _md.render(markdown_source)
    title = _derive_title(markdown_source)
    return _HTML_TEMPLATE.format(
        title=title,
        css=css,
        body=body_html,
    )
