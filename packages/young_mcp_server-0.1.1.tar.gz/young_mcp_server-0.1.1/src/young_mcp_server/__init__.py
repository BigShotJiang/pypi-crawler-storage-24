def main() -> None:
    print("Hello from young-mcp-server!")
