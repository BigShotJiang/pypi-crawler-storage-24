"""Tests for TitanRDM model classes."""

import pytest

from titan_rdm_sdk.models import (
    Branch,
    DeployedColumnDefinition,
    DeployedTableDefinition,
    Domain,
)


class TestBranch:
    """Tests for Branch model."""

    def test_from_api_response_full(self):
        """Test Branch.from_api_response with all fields."""
        data = {
            "id": 5,
            "name": "dev",
            "description": "Development branch",
            "branch_type": "shared",
            "status": "open",
            "database_suffix": "dev",
            "is_default_dev_branch": True,
            "is_integration_branch": False,
            "parent_branch": {"id": 2, "name": "test"},
            "owner": {"id": 1, "email": "admin@acme.com"},
            "created_at": "2026-01-15T10:00:00.000Z",
            "updated_at": "2026-01-15T10:00:00.000Z",
        }

        branch = Branch.from_api_response(data)

        assert branch.id == 5
        assert branch.name == "dev"
        assert branch.description == "Development branch"
        assert branch.branch_type == "shared"
        assert branch.status == "open"
        assert branch.database_suffix == "dev"
        assert branch.is_default_dev_branch is True
        assert branch.is_integration_branch is False
        assert branch.parent_branch_id == 2
        assert branch.parent_branch_name == "test"
        assert branch.owner_id == 1
        assert branch.owner_email == "admin@acme.com"
        assert branch.created_at == "2026-01-15T10:00:00.000Z"
        assert branch.updated_at == "2026-01-15T10:00:00.000Z"

    def test_from_api_response_minimal(self):
        """Test Branch.from_api_response with minimal fields."""
        data = {"id": 1, "name": "prod"}

        branch = Branch.from_api_response(data)

        assert branch.id == 1
        assert branch.name == "prod"
        assert branch.description is None
        assert branch.parent_branch_id is None
        assert branch.parent_branch_name is None
        assert branch.owner_id is None
        assert branch.owner_email is None
        assert branch.is_default_dev_branch is False
        assert branch.is_integration_branch is False

    def test_from_api_response_null_parent_and_owner(self):
        """Test Branch.from_api_response with null parent and owner."""
        data = {
            "id": 3,
            "name": "shared-branch",
            "parent_branch": None,
            "owner": None,
        }

        branch = Branch.from_api_response(data)

        assert branch.parent_branch_id is None
        assert branch.owner_id is None


class TestDomain:
    """Tests for Domain model."""

    def test_from_api_response_full(self):
        """Test Domain.from_api_response with all fields."""
        data = {
            "id": 1,
            "name": "Customer Data",
            "abbreviation": "cust",
            "description": "Customer reference data",
            "created_at": "2026-01-15T10:00:00.000Z",
            "updated_at": "2026-01-15T10:00:00.000Z",
        }

        domain = Domain.from_api_response(data)

        assert domain.id == 1
        assert domain.name == "Customer Data"
        assert domain.abbreviation == "cust"
        assert domain.description == "Customer reference data"
        assert domain.created_at == "2026-01-15T10:00:00.000Z"

    def test_from_api_response_minimal(self):
        """Test Domain.from_api_response with minimal fields."""
        data = {"id": 2, "name": "Product Data"}

        domain = Domain.from_api_response(data)

        assert domain.id == 2
        assert domain.name == "Product Data"
        assert domain.abbreviation is None
        assert domain.description is None


class TestDeployedColumnDefinition:
    """Tests for DeployedColumnDefinition model."""

    def test_from_api_response_full(self):
        """Test DeployedColumnDefinition.from_api_response with all fields."""
        data = {
            "id": 100,
            "key": "col-uuid-1",
            "name": "customer_id",
            "data_type": "integer",
            "length": None,
            "is_primary_key": True,
            "is_required": True,
            "display_order": 1,
            "is_deleted": False,
            "description": "Primary key",
        }

        col = DeployedColumnDefinition.from_api_response(data)

        assert col.id == 100
        assert col.key == "col-uuid-1"
        assert col.name == "customer_id"
        assert col.data_type == "integer"
        assert col.length is None
        assert col.is_primary_key is True
        assert col.is_required is True
        assert col.display_order == 1
        assert col.is_deleted is False
        assert col.description == "Primary key"

    def test_from_api_response_varchar_with_length(self):
        """Test DeployedColumnDefinition with varchar type and length."""
        data = {
            "id": 101,
            "key": "col-uuid-2",
            "name": "email",
            "data_type": "varchar",
            "length": 255,
            "is_primary_key": False,
            "is_required": True,
            "display_order": 2,
            "is_deleted": False,
        }

        col = DeployedColumnDefinition.from_api_response(data)

        assert col.data_type == "varchar"
        assert col.length == 255
        assert col.is_primary_key is False

    def test_from_api_response_defaults(self):
        """Test DeployedColumnDefinition defaults for missing booleans."""
        data = {"id": 102, "name": "optional_field"}

        col = DeployedColumnDefinition.from_api_response(data)

        assert col.is_primary_key is False
        assert col.is_required is False
        assert col.is_deleted is False


class TestDeployedTableDefinition:
    """Tests for DeployedTableDefinition model."""

    def test_from_api_response_full(self):
        """Test DeployedTableDefinition.from_api_response with all fields."""
        data = {
            "id": 10,
            "key": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
            "name": "customers",
            "database_table_name": "t_cust_customers",
            "domain": {"id": 1, "name": "Customer Data", "abbreviation": "cust"},
            "branch": {"id": 5, "name": "dev", "branch_type": "shared"},
            "column_definitions": [
                {
                    "id": 100,
                    "key": "col-uuid-1",
                    "name": "customer_id",
                    "data_type": "integer",
                    "is_primary_key": True,
                    "is_required": True,
                    "display_order": 1,
                    "is_deleted": False,
                },
                {
                    "id": 101,
                    "key": "col-uuid-2",
                    "name": "email",
                    "data_type": "varchar",
                    "length": 255,
                    "is_primary_key": False,
                    "is_required": True,
                    "display_order": 2,
                    "is_deleted": False,
                },
            ],
            "created_at": "2026-01-20T10:00:00.000Z",
            "updated_at": "2026-02-27T09:00:00.000Z",
        }

        table = DeployedTableDefinition.from_api_response(data)

        assert table.id == 10
        assert table.key == "a1b2c3d4-e5f6-7890-abcd-ef1234567890"
        assert table.name == "customers"
        assert table.database_table_name == "t_cust_customers"
        assert table.domain_id == 1
        assert table.domain_name == "Customer Data"
        assert table.domain_abbreviation == "cust"
        assert table.branch_id == 5
        assert table.branch_name == "dev"
        assert len(table.column_definitions) == 2
        assert table.column_definitions[0].name == "customer_id"
        assert table.column_definitions[1].name == "email"
        assert table.created_at == "2026-01-20T10:00:00.000Z"

    def test_from_api_response_deployed_column_definitions_key(self):
        """Test that 'deployed_column_definitions' key is also handled."""
        data = {
            "id": 20,
            "name": "products",
            "deployed_column_definitions": [
                {"id": 200, "name": "product_id", "data_type": "integer"},
            ],
        }

        table = DeployedTableDefinition.from_api_response(data)

        assert len(table.column_definitions) == 1
        assert table.column_definitions[0].name == "product_id"

    def test_from_api_response_no_columns(self):
        """Test DeployedTableDefinition with no column definitions."""
        data = {
            "id": 30,
            "name": "empty_table",
            "domain": {"id": 2, "name": "Product Data"},
        }

        table = DeployedTableDefinition.from_api_response(data)

        assert table.column_definitions == []
        assert table.domain_id == 2

    def test_from_api_response_null_domain_and_branch(self):
        """Test DeployedTableDefinition with null domain and branch."""
        data = {
            "id": 40,
            "name": "orphan_table",
            "domain": None,
            "branch": None,
        }

        table = DeployedTableDefinition.from_api_response(data)

        assert table.domain_id is None
        assert table.domain_name is None
        assert table.branch_id is None
        assert table.branch_name is None
