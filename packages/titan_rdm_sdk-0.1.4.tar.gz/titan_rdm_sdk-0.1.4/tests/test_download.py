"""Tests for Download class."""

from unittest.mock import MagicMock, patch

import pandas as pd
import pytest

from titan_rdm_sdk import Download, TitanRDMClient
from titan_rdm_sdk.exceptions import (
    ExportFailedError,
    ExportNotReadyError,
    ValidationError,
)


@pytest.fixture
def mock_client():
    """Create a mock TitanRDMClient."""
    client = MagicMock(spec=TitanRDMClient)
    client.url = "https://example.com"
    client.access_token = "test_token"
    return client


class TestDownloadInitialization:
    """Tests for Download initialization."""

    def test_invalid_pattern_raises_validation_error(self, mock_client):
        """Test that invalid pattern raises ValidationError."""
        mock_client._make_request.return_value = {"id": 1, "status": "started"}

        with pytest.raises(ValidationError, match="pattern must be"):
            Download(
                client=mock_client,
                branch_id=174,
                table_definition_key=50,
                pattern="invalid",
            )

    def test_incremental_without_high_water_mark_raises_error(self, mock_client):
        """Test that incremental pattern without high_water_mark raises error."""
        with pytest.raises(ValidationError, match="high_water_mark is required"):
            Download(
                client=mock_client,
                branch_id=174,
                table_definition_key=50,
                pattern="incremental",
            )

    def test_invalid_high_water_mark_format_raises_error(self, mock_client):
        """Test that invalid high_water_mark format raises error."""
        with pytest.raises(ValidationError, match="ISO 8601"):
            Download(
                client=mock_client,
                branch_id=174,
                table_definition_key=50,
                pattern="incremental",
                high_water_mark="not-a-date",
            )

    def test_successful_full_export_creation(self, mock_client):
        """Test successful full export creation."""
        mock_client._make_request.return_value = {
            "id": 123,
            "status": "started",
            "branch_id": 174,
            "table_definition_key": 50,
            "pattern": "full",
            "started_datetime": "2025-01-22T10:30:00Z",
        }

        download = Download(
            client=mock_client,
            branch_id=174,
            table_definition_key=50,
            pattern="full",
            correlation_code="test-correlation",
        )

        assert download.id == 123
        assert download.status == "started"
        assert download.pattern == "full"

    def test_successful_incremental_export_creation(self, mock_client):
        """Test successful incremental export creation."""
        mock_client._make_request.return_value = {
            "id": 124,
            "status": "started",
            "pattern": "incremental",
            "high_water_mark": "2025-01-01T00:00:00Z",
        }

        download = Download(
            client=mock_client,
            branch_id=174,
            table_definition_key=50,
            pattern="incremental",
            high_water_mark="2025-01-01T00:00:00Z",
        )

        assert download.id == 124
        assert download.pattern == "incremental"
        assert download.high_water_mark == "2025-01-01T00:00:00Z"

    def test_api_request_payload(self, mock_client):
        """Test that API request is made with correct payload."""
        mock_client._make_request.return_value = {"id": 1, "status": "started"}

        Download(
            client=mock_client,
            branch_id=174,
            table_definition_key=50,
            pattern="full",
            correlation_code="test-code",
        )

        mock_client._make_request.assert_called_once_with(
            method="POST",
            endpoint="/api/exports/new",
            json={
                "branch_id": 174,
                "table_definition_key": 50,
                "pattern": "full",
                "correlation_code": "test-code",
            },
        )


class TestCheckStatus:
    """Tests for check_status method."""

    def test_check_status_updates_attributes(self, mock_client):
        """Test that check_status updates download attributes."""
        mock_client._make_request.side_effect = [
            {"id": 123, "status": "started"},  # Creation
            {  # Status check
                "id": 123,
                "status": "ready",
                "rows_exported": 1500,
                "files_exported": 1,
                "bytes_exported": 45678,
                "download_url": "https://s3.example.com/file.csv",
                "complete_datetime": "2025-01-22T10:30:15Z",
            },
        ]

        download = Download(
            client=mock_client,
            branch_id=174,
            table_definition_key=50,
        )

        status = download.check_status()

        assert status == "ready"
        assert download.rows_exported == 1500
        assert download.download_url == "https://s3.example.com/file.csv"


class TestReceive:
    """Tests for receive method."""

    def test_receive_when_not_ready_raises_error(self, mock_client):
        """Test that receive raises error when export not ready."""
        mock_client._make_request.side_effect = [
            {"id": 123, "status": "started"},  # Creation
            {"id": 123, "status": "started"},  # Status check
        ]

        download = Download(
            client=mock_client,
            branch_id=174,
            table_definition_key=50,
        )

        with pytest.raises(ExportNotReadyError):
            download.receive()

    def test_receive_when_failed_raises_error(self, mock_client):
        """Test that receive raises error when export failed."""
        mock_client._make_request.side_effect = [
            {"id": 123, "status": "started"},  # Creation
            {"id": 123, "status": "failed", "message": "Table not found"},  # Status
        ]

        download = Download(
            client=mock_client,
            branch_id=174,
            table_definition_key=50,
        )

        with pytest.raises(ExportFailedError, match="Table not found"):
            download.receive()

    @patch("titan_rdm_sdk.download.requests.get")
    def test_receive_returns_dataframe(self, mock_get, mock_client):
        """Test that receive returns a pandas DataFrame."""
        mock_client._make_request.side_effect = [
            {
                "id": 123,
                "status": "ready",
                "download_url": "https://s3.example.com/file.csv",
            },
        ]

        csv_content = "id,name,value\n1,Alice,100\n2,Bob,200\n"
        mock_response = MagicMock()
        mock_response.content = csv_content.encode("utf-8")
        mock_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_response

        download = Download(
            client=mock_client,
            branch_id=174,
            table_definition_key=50,
        )

        df = download.receive()

        assert isinstance(df, pd.DataFrame)
        assert len(df) == 2
        assert list(df.columns) == ["id", "name", "value"]
        assert df.iloc[0]["name"] == "Alice"


class TestWaitUntilReady:
    """Tests for wait_until_ready method."""

    def test_wait_until_ready_returns_when_ready(self, mock_client):
        """Test that wait_until_ready returns when export is ready."""
        mock_client._make_request.side_effect = [
            {"id": 123, "status": "started"},  # Creation
            {"id": 123, "status": "started"},  # First poll
            {"id": 123, "status": "ready"},  # Second poll
        ]

        download = Download(
            client=mock_client,
            branch_id=174,
            table_definition_key=50,
        )

        status = download.wait_until_ready(poll_interval=0.01)

        assert status == "ready"

    def test_wait_until_ready_raises_on_failure(self, mock_client):
        """Test that wait_until_ready raises error when export fails."""
        mock_client._make_request.side_effect = [
            {"id": 123, "status": "started"},  # Creation
            {"id": 123, "status": "failed", "message": "Export error"},  # Poll
        ]

        download = Download(
            client=mock_client,
            branch_id=174,
            table_definition_key=50,
        )

        with pytest.raises(ExportFailedError, match="Export error"):
            download.wait_until_ready(poll_interval=0.01)

    def test_wait_until_ready_raises_timeout(self, mock_client):
        """Test that wait_until_ready raises TimeoutError when max_wait exceeded."""
        mock_client._make_request.return_value = {"id": 123, "status": "started"}

        download = Download(
            client=mock_client,
            branch_id=174,
            table_definition_key=50,
        )

        with pytest.raises(TimeoutError, match="did not complete"):
            download.wait_until_ready(poll_interval=0.01, max_wait=0.05)
