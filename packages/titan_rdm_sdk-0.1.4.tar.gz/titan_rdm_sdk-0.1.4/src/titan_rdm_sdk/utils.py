"""Helper utilities for TitanRDM SDK."""

from datetime import datetime
from io import StringIO
from typing import Any

import pandas as pd


def validate_iso8601(timestamp: str) -> bool:
    """
    Validate that a string is in ISO 8601 format.

    Args:
        timestamp: The timestamp string to validate.

    Returns:
        True if valid ISO 8601 format, False otherwise.
    """
    try:
        datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
        return True
    except (ValueError, AttributeError):
        return False


def parse_csv_response(content: bytes | str) -> pd.DataFrame:
    """
    Parse CSV content into a pandas DataFrame.

    Args:
        content: CSV content as bytes or string.

    Returns:
        pandas DataFrame with the parsed data.
    """
    if isinstance(content, bytes):
        content = content.decode("utf-8")
    return pd.read_csv(StringIO(content))


def dataframe_to_csv(df: pd.DataFrame) -> bytes:
    """
    Convert a pandas DataFrame to CSV bytes.

    Args:
        df: The DataFrame to convert.

    Returns:
        CSV data as UTF-8 encoded bytes.
    """
    return df.to_csv(index=False).encode("utf-8")


def extract_error_message(response_json: dict[str, Any]) -> str:
    """
    Extract error message from API error response.

    Args:
        response_json: The JSON response from the API.

    Returns:
        Human-readable error message.
    """
    if "message" in response_json:
        return response_json["message"]
    if "error" in response_json:
        error = response_json["error"]
        if "error_description" in response_json:
            return f"{error}: {response_json['error_description']}"
        return error
    if "errors" in response_json:
        return "; ".join(response_json["errors"])
    return str(response_json)
