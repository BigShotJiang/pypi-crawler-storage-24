"""Upload class for TitanRDM import operations."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from titan_rdm_sdk.exceptions import ValidationError
from titan_rdm_sdk.table_upload import TableUpload

if TYPE_CHECKING:
    from titan_rdm_sdk.client import TitanRDMClient


class Upload:
    """
    Represents an import operation to TitanRDM.

    Can upload multiple tables in a single import batch.
    """

    def __init__(
        self,
        client: TitanRDMClient,
        branch_id: int,
        description: str | None = None,
        correlation_code: str | None = None,
    ) -> None:
        """
        Create a new import operation.

        Args:
            client: TitanRDMClient instance for API calls.
            branch_id: Target branch ID.
            description: Description of the import.
            correlation_code: User-defined tracking identifier.

        Raises:
            ValidationError: If branch_id is missing.
            APIError: If the import creation fails.
        """
        if branch_id is None:
            raise ValidationError("branch_id is required")

        self._client = client
        self.branch_id = branch_id
        self.description = description
        self.correlation_code = correlation_code

        # Attributes populated from API response
        self.id: int | None = None
        self.status: str | None = None
        self.message: str | None = None
        self.created_date: str | None = None
        self.file_size: int | None = None
        self.insert_row_count: int | None = None
        self.update_row_count: int | None = None
        self.delete_row_count: int | None = None
        self.duration_secs: int | None = None

        # Create the import
        self._create_import()

    def _create_import(self) -> None:
        """Create the import via the API."""
        payload: dict[str, Any] = {
            "branch_id": self.branch_id,
        }

        if self.description:
            payload["description"] = self.description

        if self.correlation_code:
            payload["correlation_code"] = self.correlation_code

        response = self._client._make_request(
            method="POST",
            endpoint="/api/imports/new",
            json=payload,
        )

        self._update_from_response(response)

    def _update_from_response(self, data: dict[str, Any]) -> None:
        """Update attributes from API response."""
        self.id = data.get("id")
        self.status = data.get("status")
        self.message = data.get("message")
        self.created_date = data.get("created_date")
        self.file_size = data.get("file_size")
        self.insert_row_count = data.get("insert_row_count")
        self.update_row_count = data.get("update_row_count")
        self.delete_row_count = data.get("delete_row_count")
        self.duration_secs = data.get("duration_secs")

        # Also update from response if available
        if data.get("description"):
            self.description = data["description"]
        if data.get("correlation_code"):
            self.correlation_code = data["correlation_code"]

    def get_table_upload(
        self,
        table_definition_key: int,
        import_mapping_key: int,
        pattern: str = "full",
        correlation_code: str | None = None,
    ) -> TableUpload:
        """
        Create a TableUpload for uploading data to a specific table.

        Args:
            table_definition_key: Target table definition key (required).
            import_mapping_key: Import mapping key that defines column mappings (required).
            pattern: Import pattern - 'full', 'incremental', or 'incremental_with_delete'
                (default: 'full').
            correlation_code: User-defined tracking identifier for this table upload.

        Returns:
            A new TableUpload instance ready for data upload.

        Raises:
            ValidationError: If required parameters are missing or invalid.
            APIError: If the table upload creation fails.
        """
        return TableUpload(
            client=self._client,
            upload=self,
            table_definition_key=table_definition_key,
            import_mapping_key=import_mapping_key,
            pattern=pattern,
            correlation_code=correlation_code,
        )

    def complete(self, message: str | None = None) -> Upload:
        """
        Mark the import as completed.

        Call this after all table uploads are finished.

        Args:
            message: Optional completion message.

        Returns:
            self (for method chaining).

        Raises:
            APIError: If the completion fails.
        """
        payload: dict[str, Any] = {}

        if message:
            payload["message"] = message

        response = self._client._make_request(
            method="POST",
            endpoint=f"/api/imports/{self.id}/upload_complete",
            json=payload if payload else None,
        )

        self._update_from_response(response)
        return self
