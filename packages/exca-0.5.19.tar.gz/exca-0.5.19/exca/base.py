# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.
#
# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.

import collections
import dataclasses
import functools
import inspect
import logging
import shutil
import string
import typing as tp
from pathlib import Path

import pydantic

# pylint: disable=unused-import
from . import logconf  # noqa
from . import utils
from .confdict import ConfDict as ConfDict
from .workdir import WorkDir

# pylint: disable=too-many-instance-attributes
logger = logging.getLogger(__name__)
C = tp.TypeVar("C", bound=tp.Callable[..., tp.Any])
ExcludeCallable = tp.Callable[[tp.Any], tp.Iterable[str]]
Mapping = tp.MutableMapping[str, tp.Any] | tp.Iterable[tuple[str, tp.Any]]
# add functions here that return True if mismatch with cached config can be ignored, else False
DEFAULT_CHECK_SKIPS: list[tp.Callable[[str, tp.Any, tp.Any], bool]] = []


class Sentinel:
    pass


@dataclasses.dataclass
class _BaseInfraState:
    """Ephemeral/recomputable state, stored as a PrivateAttr in
    __pydantic_private__ and accessed via _fast_state() to bypass
    pydantic's __getattr__ on hot paths.  Reset on pickle."""

    checked_configs: bool = False
    factory: str | None = None
    uid: str | None = None
    infra_method: "InfraMethod | None" = None
    method_override: tp.Any = None


def _fast_state(infra: "BaseInfra") -> _BaseInfraState:
    """Read _state directly from __pydantic_private__, bypassing __getattr__
    for fast access.

    Falls back to normal access if pydantic's storage changes.
    See test_fast_state_no_fallback for upgrade detection.
    """
    try:
        return infra.__pydantic_private__["_state"]  # type: ignore[index]
    except (KeyError, TypeError):
        return infra._state


@pydantic.model_validator(mode="after")
def model_with_infra_validator_after(obj: pydantic.BaseModel) -> pydantic.BaseModel:
    return _add_name(obj, propagate_defaults=True)


def _add_name(
    obj: pydantic.BaseModel, propagate_defaults: bool = False
) -> pydantic.BaseModel:
    """Provide owner object to the infra"""
    private = obj.__pydantic_private__ or {}
    params = collections.ChainMap(dict(obj), private)
    for name, val in params.items():
        if not isinstance(val, BaseInfra):
            continue
        # pull default infra from model_fields
        # (or from private_attributes if private/has leading _)
        if name in type(obj).model_fields:
            default = type(obj).model_fields[name].default
        else:  # private!
            default = obj.__private_attributes__[name].default
        if not isinstance(default, BaseInfra):
            continue  # unspecified default
        imethod = default._infra_method
        if imethod is None:
            cls = type(obj).__name__
            raise RuntimeError(f"Infra {name!r} on {cls} was not applied to a method.")
        imethod.infra_name = name
        if getattr(val, "_infra_name", "") not in (name, ""):
            msg = f"Cannot set name of infra to {name!r}"
            msg += f" (already named {val._infra_name!r})"
            raise RuntimeError(msg)
        if getattr(val, "_obj", obj) is not obj:
            msg = f"Cannot apply infra {name!r} on {obj!r}"
            msg += f"\n(already applied on {val._obj!r})"
            raise RuntimeError(msg)
        # register infra owner object, name, and method it is applied to
        # into this infra instance:
        val._obj = obj
        val._infra_name = name
        val._infra_method = imethod
        # propagate set values of default infra instance into this infra instance
        if propagate_defaults:
            unset_defaults = default.model_fields_set - val.model_fields_set
            if unset_defaults:
                upds = {name: getattr(default, name) for name in unset_defaults}
                val._update(upds)
    return obj


@pydantic.model_validator(mode="before")
def model_with_infra_validator_before(obj: tp.Any) -> tp.Any:
    """Provide owner object to the infra
    (this is set to the owner class during __set_name__)
    """
    if not isinstance(obj, dict):
        return obj  # should not happen
    for name, val in obj.items():
        if isinstance(val, BaseInfra):
            # make sure the object owns its own infra instance to avoid
            # applying same infra to multiple objects
            obj[name] = {x: getattr(val, x) for x in val.model_fields_set}
    return obj


class BaseInfra(pydantic.BaseModel):
    folder: Path | str | None = None
    # general permission for folders and files
    # use os.chmod / path.chmod compatible numbers, or None to deactivate
    # eg: 0o777 for all rights to all users
    permissions: int | str | None = 0o777
    # {folder} will be replaced by the class folder
    # {user} by user id and %j by job id
    logs: Path | str = "{folder}/logs/{user}/%j"
    # cache versioning
    version: str = "0"

    model_config = pydantic.ConfigDict(extra="forbid")
    # {factory} will be replaced by method name and version tag
    # {uid} by the owner class uid
    _uid_string: str = "{method},{version}/{uid}"
    _state: _BaseInfraState = pydantic.PrivateAttr(default_factory=_BaseInfraState)
    _uid: str | None = None  # deprecated: now in _state, kept for backward compat
    _obj: tp.Any = pydantic.PrivateAttr()  # pydantic model the infra is an attribute of
    _infra_name: str = ""
    _infra_method: "InfraMethod | None" = pydantic.PrivateAttr(None)  # method container

    def __getstate__(self) -> dict[str, tp.Any]:
        out = super().__getstate__()
        # Reset ephemeral state so pickled copies start fresh
        state = out["__pydantic_private__"].get("_state")
        if state is not None:
            out["__pydantic_private__"]["_state"] = type(state)()
        return out

    def __setstate__(self, state: tp.Any) -> None:
        if "__dict__" in state:
            d = state["__dict__"]
            # compatiblity
            d.setdefault("version", "0")
            d.setdefault("mode", "cached")
        if "__pydantic_private__" in state:
            d = state["__pydantic_private__"]
            d.setdefault("_uid_string", "{method},{version}/{uid}")
            if "_state" not in d:
                d["_state"] = type(self)._state.default_factory()  # type: ignore
            # infra method can lose the name, so let's recover it
            # (in private infra in particular)
            iname = d.get("_infra_name", None)
            if iname and iname is not None:
                imethod = d.get("_infra_method", None)
                if isinstance(imethod, InfraMethod):
                    if imethod.infra_name is None or not imethod.infra_name:
                        imethod.infra_name = iname
        super().__setstate__(state)

    def __set_name__(self, owner: type[pydantic.BaseModel], name: str) -> None:
        if not issubclass(owner, pydantic.BaseModel):
            cls = owner.__name__
            msg = f"{self.__class__.__name__} cannot be applied to {cls}:\n"
            msg += f"{cls} must inherit from pydantic.BaseModel"
            raise RuntimeError(msg)
        owner.model_config.setdefault("extra", "forbid")
        self._infra_name = name
        # set mechanism to provide owner obj to the infra:
        owner._model_with_infra_validator_after = model_with_infra_validator_after  # type: ignore
        owner._model_with_infra_validator_before = model_with_infra_validator_before  # type: ignore

    def _exclude_from_cls_uid(self) -> list[str]:
        if getattr(self._infra_method, "version", None) is not None:
            return ["."]  # compatibility -> avoid uid change
        return list(set(type(self).model_fields) - {"version"})

    def model_post_init(self, log__: tp.Any) -> None:
        super().model_post_init(log__)
        self._set_permissions(None)  # set compatibility for permissions as string

    def config(self, uid: bool = True, exclude_defaults: bool = False) -> ConfDict:
        """Exports the task configuration as a ConfigDict
        ConfDict are dict which split on "." with extra flatten,
        to_uid and to_yaml features

        Parameters
        ----------
        uid: bool
            if True, uses the _exclude_from_cls_uid field/method to filter in and out
            some fields
        exclude_defaults: bool
            if True, values that are set to defaults are not included
        """
        if not hasattr(self, "_obj") or self._infra_method is None:
            raise RuntimeError(f"Infra not tied to an object/method: {self!r}")
        cdict = ConfDict.from_model(self._obj, uid=uid, exclude_defaults=exclude_defaults)
        excluded: tp.Any = self._infra_method.exclude_from_cache_uid
        if callable(excluded):
            excluded = excluded(self._obj)
        elif isinstance(excluded, str):
            name = excluded.split("method:", maxsplit=1)[1]
            func = getattr(self._obj, name, None)
            if func is None:
                c = self._obj.__class__.__name__
                msg = f"exclude_from_cache_uid={excluded!r} but {c}.{name} does not exist"
                raise RuntimeError(msg)
            excluded = func()
        if uid:
            for name in excluded:
                cdict.pop(name, None)  # may not be present if default
        return cdict

    def _check_configs(self, write: bool = True) -> None:
        state = _fast_state(self)
        if state.checked_configs:
            return  # already done
        xpfolder = self.uid_folder()
        if xpfolder is None:
            return
        # Create ConfigDump using self.config() which handles exclude_from_cache_uid
        dump = utils.ConfigDump(
            model=self._obj,
            uid=self.config(uid=True, exclude_defaults=True),
            full_uid=self.config(uid=True, exclude_defaults=False),
        )
        dump.check_and_write(xpfolder, write=write)
        state.checked_configs = True
        # Set permissions on written files
        if write:
            for name in ("uid", "full-uid", "config"):
                fp = xpfolder / f"{name}.yaml"
                if fp.exists():
                    try:
                        self._set_permissions(fp)
                    except (OSError, FileNotFoundError):
                        pass

    def _factory(self) -> str:
        state = _fast_state(self)
        if state.factory is not None:
            return state.factory
        cls = self._obj.__class__
        if self._infra_method is None:
            raise RuntimeError(f"Infra {self!r} was not applied to a method")
        name = self._infra_method.method.__name__
        version = self._infra_method.version
        if version is not None and self.version != version:  # compatibility
            object.__setattr__(self, "version", version)  # bypass freeze, as not in uid
            c = self.__class__.__name__
            msg = f"{cls.__name__}: set infra.apply_on(version=None) and "
            msg += f"infra: {c} = {c}(version={version!r}) for latest syntax"
            logger.warning(msg)
        factory = f"{cls.__module__}.{cls.__qualname__ }.{name}"
        if isinstance(self._infra_method, InfraMethod):  # NOT LEGACY
            m = self._infra_method.method
            factory = f"{m.__module__}.{m.__qualname__ }"
            # if the method is not overriden, then use the current class name
            current_m = getattr(cls, m.__name__)
            if isinstance(current_m, property) and self._infra_method is current_m.fget:
                factory = f"{cls.__module__}.{cls.__qualname__ }.{name}"
        state.factory = factory
        return factory

    def uid(self) -> str:
        """Returns the unique uid of the task"""
        state = _fast_state(self)
        if state.uid is not None:
            return state.uid
        # deprecated path: check legacy _uid attribute for backward compat
        if not hasattr(self, "_uid"):
            self._uid = None  # backward-compatibility
        if self._uid is not None:
            state.uid = self._uid
            return self._uid
        cfg = self.config(uid=True, exclude_defaults=True)
        uid = cfg.to_uid()
        uid = uid if uid else "default"
        params = dict(method=self._factory(), version=self.version, uid=uid)
        parsed = string.Formatter().parse(self._uid_string)
        names = {v[1] for v in parsed if v[1] is not None}
        if names != set(params):
            msg = f"uid_string {self._uid_string!r} should contain exactly {set(params)}"
            msg += f"\nbut got {names} for infra applied on {self._obj!r}"
            raise ValueError(msg)
        computed = self._uid_string.format(**params)
        state.uid = computed
        self._uid = computed  # deprecated: kept for backward compat
        utils.recursive_freeze(self._obj)
        msg = "Froze instance %s after computing its uid: %s"
        logger.debug(msg, repr(self._obj), computed)
        # compat
        if self.folder is not None and uid != "default":
            folder = Path(self.folder) / computed
            if not folder.exists():
                params["uid"] = cfg.to_uid(version=2)
                old = Path(self.folder) / self._uid_string.format(**params)
                if old.exists():
                    # rename all folders in cache at once if possible
                    from exca import helpers

                    helpers.update_uids(self.folder, dryrun=False)
                if old.exists():
                    # if this very cache was not updated
                    # (eg: because of unexpected uid_string), then fix it manually
                    msg = "Automatic update fail, manual update to new uid: '%s' -> '%s'"
                    logger.warning(msg, old, folder)
                    shutil.move(old, folder)
        latest = ConfDict.LATEST_UID_VERSION
        # warn for mixture of versioning
        if self.folder is not None and ConfDict.UID_VERSION != latest:
            new = Path(self.folder) / cfg.to_uid(version=latest)
            if new.exists():
                msg = "Found folder with latest version %s but currently using %s"
                logger.warning(msg, latest, ConfDict.UID_VERSION)
        return computed

    def uid_folder(self, create: bool = False) -> Path | None:
        """Folder where this task instance is stored"""
        if self.folder is None:
            return None
        folder = Path(self.folder) / self.uid()
        if not create:
            return folder
        folder.mkdir(exist_ok=True, parents=True)
        self._set_permissions(self.folder)
        self._set_permissions(folder)
        return folder

    def iter_cached(self) -> tp.Iterable[pydantic.BaseModel]:
        """Iterate over similar objects in the cache folder"""
        cls = self._obj.__class__
        folder = self.uid_folder()
        if folder is None:
            return
        folder = folder.parent
        for fp in folder.glob("*/config.yaml"):
            if not fp.with_name("uid.yaml").exists():
                continue  # not a task config file
            cfg = ConfDict.from_yaml(fp)
            yield cls(**cfg)

    def _set_permissions(self, path: str | Path | None) -> None:
        if isinstance(self.permissions, str):
            if not self.permissions:
                self.permissions = None
            elif self.permissions == "a+rwx":
                self.permissions = 0o777
            else:
                raise ValueError(f"No compatibility for permissions {self.permissions}")
            msg = "infra.permissions set to %s by compatibility mode"
            logger.warning(msg, self.permissions)
        if path is not None and self.permissions is not None:
            try:
                Path(path).chmod(self.permissions)
            except Exception as e:
                msg = f"Failed to set permission to {self.permissions} on '{path}'\n({e})"
                logger.warning(msg)

    def clone_obj(self, *args: dict[str, tp.Any], **kwargs: tp.Any) -> tp.Any:
        """Create a new decorated object by applying a diff config to the underlying object"""
        if args:
            if len(args) > 1:
                raise ValueError(f"Only one positional argument allowed, got {args}")
            if kwargs:
                msg = "Provide either args or kwargs, not both, got {args=} {kwargs=}"
                raise ValueError(msg)
            kwargs = args[0]
        cdict = self.config(exclude_defaults=True, uid=False)
        cdict.update(kwargs)
        out = self._obj.model_validate(cdict)
        _ = self.uid()  # trigger uid computation (to propagate dicriminated status)
        try:
            utils.copy_discriminated_status(self._obj, out)
        except Exception as e:
            msg = f"Failed to copy discriminated status, cloning may be slow:\n{e!r}"
            logger.warning(msg)
        return out

    def _method_override(self, *args: tp.Any, **kwargs: tp.Any) -> tp.Any:
        raise NotImplementedError

    def _update(
        self, mapping: "BaseInfra" | Mapping | None = None, **kwargs: tp.Any
    ) -> None:
        """Updates infra parameters (with a mapping or kwargs)

        Usage
        ----
        > def model_post_init(self, log__: tp.Any) -> None:
        >     super().model_post_init(log__)
        >     self._infra._update(dict(self.infra))  # use another infra to update
        >     self._infra._update(folder=tmp_path)  # update single item
        """
        if mapping is not None:
            if isinstance(mapping, collections.abc.Mapping):
                mapping = mapping.items()
            kwargs.update(dict(mapping))
        for name, val in kwargs.items():
            if "#" in name:
                # #infra#pydantic#discriminator is recorded in the dict
                continue
            if isinstance(val, dict):
                if name == "workdir":
                    val = WorkDir(**val)
                else:
                    raise RuntimeError(f"Unsupported update {val} for {name}")
            setattr(self, name, val)

    def obj_infras(self) -> tp.Mapping[str, "BaseInfra"]:
        """Returns a dictionary of all infras part of the current model/config
        (including sub-configs)
        """
        return utils.find_models(self._obj, BaseInfra, stop_on_find=True)

    def __eq__(self, other: tp.Any) -> bool:
        if type(other) is not type(self):
            return False

        if self.__dict__ != other.__dict__:
            return False

        # Compare infra methods safely
        if self._infra_method is None or other._infra_method is None:
            if self._infra_method is not other._infra_method:
                return False
        else:
            if self._infra_method.infra_name != other._infra_method.infra_name:
                return False

        # Compare underlying object types (either may be unbound)
        self_obj = getattr(self, "_obj", None)
        other_obj = getattr(other, "_obj", None)
        if type(self_obj) is not type(other_obj):
            return False

        return True


@dataclasses.dataclass
class BaseInfraMethod:
    # function designed to be used as fget in a property
    # replacing the decorated method
    method: tp.Callable[..., tp.Any]
    exclude_from_cache_uid: str | tp.Iterable[str] | ExcludeCallable = ()
    version: str | None = None  # TO BE REMOVED AFTER COMPATIBILITY
    # internal
    infra_name: str | None = None

    def __post_init__(self) -> None:
        if self.method.__name__.startswith("__"):
            raise ValueError("Private methods cannot be overriden")
        functools.update_wrapper(self, self.method)  # type: ignore
        if isinstance(self.exclude_from_cache_uid, str):
            if not self.exclude_from_cache_uid.startswith("method:"):
                msg = "exclude_from_cache_uid should be a list/tuple/set, or a string starting with 'method:'"
                raise TypeError(msg)
        self.exclude_from_cache_uid = self.exclude_from_cache_uid
        if not isinstance(self.exclude_from_cache_uid, str):
            if not callable(self.exclude_from_cache_uid):
                self.exclude_from_cache_uid = tuple(self.exclude_from_cache_uid)


@dataclasses.dataclass
class InfraMethod(BaseInfraMethod):
    # function designed to be used as fget in a property
    # replacing the decorated method
    default_infra: BaseInfra | None = None  # COMPAT

    def __call__(self, obj: pydantic.BaseModel) -> tp.Any:
        # fast path: return cached result if this InfraMethod already resolved
        infra_name = self.infra_name
        if infra_name:
            infra = getattr(obj, infra_name, None)
            if infra is not None:
                state = _fast_state(infra)
                if state.infra_method is self and state.method_override is not None:
                    return state.method_override
        # full dispatch (first call or legacy/override paths)
        if not infra_name:
            default_infra = getattr(self, "default_infra", None)  # LEGACY
            if default_infra is not None:
                self.infra_name = default_infra._infra_name
        if self.infra_name is None:
            # recheck if infra is available (this may have been skipped for hidden infra)
            _add_name(obj, propagate_defaults=False)
            if self.infra_name is None:
                self.infra_name = ""  # not found = overriden by another infra instance
        infra_name = self.infra_name
        if not infra_name:
            # bypassing infra as it was overriden
            return functools.partial(self.method, obj)
        if not isinstance(obj, pydantic.BaseModel):
            raise TypeError("infra can only be added to pydantic.BaseModel")
        # get default
        if infra_name in type(obj).model_fields:
            default_imethod = (
                type(obj)
                .model_fields[infra_name]
                .default.__pydantic_private__["_infra_method"]
            )
        elif infra_name.startswith("_"):
            default_imethod = obj.__private_attributes__[infra_name].default.__pydantic_private__["_infra_method"]  # type: ignore
        else:
            raise RuntimeError(f"Could not find infra named {infra_name!r} on {obj!r}")
        if default_imethod is None:
            msg = "Overriding infra in child class was not applied to a method"
            raise RuntimeError(msg)
        infra = getattr(obj, infra_name, None)
        if infra is None:
            msg = "This should only happen when unpickling config which was modified from legacy to decorator"
            logger.warning(msg)
            return None
        if "_obj" not in (infra.__pydantic_private__ or {}):
            infra._obj = obj  # only for legacy to decorator change compatibility
        if default_imethod is not self:
            # bypassing infra as it was overriden
            return functools.partial(self.method, obj)
        result = infra._method_override
        state = _fast_state(infra)
        state.infra_method = self
        state.method_override = result
        return result

    def check_method_signature(self) -> None:
        sig = inspect.signature(self.method)
        if tuple(sig.parameters) != ("self",):
            m = self.method
            funcname = f"{m.__module__}.{m.__qualname__}"
            msg = "TaskInfra cannot be applied on method "
            msg += f"{funcname!r} as this method should only take 'self' as parameter."
            msg += f"\n(found parameter(s): {list(sig.parameters.keys())})\n"
            raise ValueError(msg)

    def __reduce__(self) -> tp.Any:
        if "<locals>" in self.method.__qualname__ or self.method.__module__ == "__main__":
            # Use "standard" reducer -> cloudpickle will handle it well
            # (but would not work with pickle because decorated method has changed name)
            return (_InfraMethodPickler(self.__class__, dataclasses.asdict(self)), ())
        # works in most cases, except for <local> and __main__ cases
        return self.method.__qualname__ + ".fget"  # in the property


class _InfraMethodPickler:
    """Called for pickling with cloudpickle in cases where pickle does not work (local/main)"""

    def __init__(self, cls: type[InfraMethod], data: dict[str, tp.Any]) -> None:
        self.cls = cls
        self.data = data

    def __call__(self) -> InfraMethod:
        return self.cls(**self.data)
