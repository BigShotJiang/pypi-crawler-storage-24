# add-two-numbers-arub

A simple Python library that adds two numbers.

Example:

from add_two_numbers_arub import add

print(add(2, 3))
