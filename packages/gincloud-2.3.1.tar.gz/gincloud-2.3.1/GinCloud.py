import sys
import re
import typer
import os
import subprocess
import tempfile
from typing import Optional

# importing custom libs
from utils.logger import get_logger, set_console_log_level
from utils.github import GitHubManager
from utils.runtime import (
    get_runtime_info,
    get_version,
    format_startup_banner,
    format_version_block,
)
from cli.dns import DNSCommand
from cli.azure import AzureCommand
from cli.github import GitHubCommand
from cli.monitoring import MonitoringCommand

logger = get_logger("ginesyscloud")

# Initialize Typer CLI app
RootCommand = typer.Typer(invoke_without_command=True, add_completion=False)
RootCommand.add_typer(AzureCommand)
RootCommand.add_typer(GitHubCommand)
RootCommand.add_typer(DNSCommand)
RootCommand.add_typer(MonitoringCommand)

# ── GitHub source coordinates (shared by update helpers) ─────────────────────
_GH_OWNER = "GinesysOneIT"
_GH_REPO = "Cloud-Infra-Management"
_GH_TOKEN = "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"

# Detect runtime context first, then resolve version from the correct source
_runtime_info = get_runtime_info()
Current_Version = get_version(_runtime_info)
logger.info(format_startup_banner(Current_Version, _runtime_info))


# ─────────────────────────── update helpers ──────────────────────────────────

# Matches a plain semantic version: 2.3.1 / 2.3 / 2.3.1.4
_VERSION_RE = re.compile(r"^\d+(\.\d+)+$")


def _version_to_release_tag(version: str) -> str:
    """
    Convert a user-supplied version string (e.g. '2.3.1') to the internal
    release tag used in the repository (e.g. 'gincloud2.3.1').
    When no specific version is requested the latest tag 'main' is used.
    """
    if version == "latest":
        return "main"
    return f"gincloud{version}"


def _update_via_installer(version_label: str, release_tag: str) -> None:
    """
    executable mode — fetch the versioned Windows installer from the release
    and launch it silently. Exits the current process immediately so the
    installer can replace the running binary.
    """
    tempdir = tempfile.gettempdir()
    asset_name = "GinCloudInstaller.exe"

    logger.info("Downloading GinCloud %s installer...", version_label)
    logger.debug("Release tag: %s", release_tag)

    gh = GitHubManager(repo=_GH_REPO, owner=_GH_OWNER, token=_GH_TOKEN)
    gh.download_file(
        repo_file_path="Utility/GinCloud/bin/GinCloudInstaller.exe",
        output_dir=tempdir,
        reference=release_tag,
    )
    installer_path = os.path.join(tempdir, asset_name)
    logger.debug("Installer downloaded to %s", installer_path)

    logger.info("Launching installer in background...")
    subprocess.Popen(
        [installer_path, "/VERYSILENT", "/NORESTART", "/SUPPRESSMSGBOXES"],
        creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
    )
    logger.info(
        "Installer launched. Exiting current process so the update can proceed..."
    )
    os._exit(0)


def _update_via_pip(version_label: str, release_tag: str) -> None:
    """
    package mode — upgrade the gincloud pip package from the release using
    the current Python interpreter.
    """
    install_url = (
        f"git+https://{_GH_TOKEN}@github.com/{_GH_OWNER}/{_GH_REPO}.git"
        f"@{release_tag}#subdirectory=Utility/GinCloud/src"
    )
    logger.info("Upgrading GinCloud to %s...", version_label)
    logger.debug(
        "Package source: git+https://***@github.com/%s/%s.git@%s#subdirectory=Utility/GinCloud/src",
        _GH_OWNER, _GH_REPO, release_tag,
    )

    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", "--upgrade", install_url],
        check=False,
    )

    if result.returncode == 0:
        logger.info(
            "GinCloud updated to %s successfully. "
            "Restart your shell for the new version to take effect.",
            version_label,
        )
    else:
        raise RuntimeError(
            f"Upgrade to {version_label} failed (pip exit code {result.returncode}). "
            "Run with --log-level DEBUG for more detail."
        )


# ─────────────────────────── commands ────────────────────────────────────────

@RootCommand.command(
    name="update", help="Update GinCloud to the latest or a specific version"
)
def update_gincloud(
    version_arg: Optional[str] = typer.Argument(
        None,
        metavar="VERSION",
        help="Version to update to (e.g. 2.3.1). Omit to get the latest version.",
    ),
    version_opt: Optional[str] = typer.Option(
        None,
        "--version",
        "-r",
        metavar="VERSION",
        help="Version to update to (e.g. 2.3.1). Alternative to the positional argument.",
    ),
):
    """
    Update GinCloud to the latest or a specific version.

    Version can be supplied as a positional argument or via -r / --version:\n
      gincloud update              → latest version\n
      gincloud update 2.3.1        → specific version\n
      gincloud update -r 2.3.1     → same, via option\n

    Behaviour depends on how GinCloud is installed:\n
      executable  — downloads and silently runs the Windows installer\n
      package     — upgrades the pip package in the current Python environment\n
      script      — not supported; update by pulling the repository manually
    """
    # Positional takes precedence over the option
    version_input = version_arg or version_opt

    # Validate format and resolve display label + internal release tag
    if version_input is None:
        version_label = "latest"
        release_tag = "main"
    elif _VERSION_RE.match(version_input):
        version_label = f"v{version_input}"
        release_tag = _version_to_release_tag(version_input)
    else:
        logger.error(
            "Invalid version format '%s'. Expected x.x.x (e.g. 2.3.1).",
            version_input,
        )
        raise typer.Exit(code=1)

    mode = _runtime_info.get("mode")

    try:
        if mode == "executable":
            _update_via_installer(version_label, release_tag)

        elif mode == "package":
            _update_via_pip(version_label, release_tag)

        else:  # script
            logger.warning(
                "GinCloud is running as a plain script (mode=script). "
                "Automatic update is not supported in this mode. "
                "Pull the latest changes from the repository manually."
            )
            raise typer.Exit(code=1)

    except typer.Exit:
        raise
    except Exception as e:
        logger.error("Update failed: %s", e)
        raise typer.Exit(code=1)


@RootCommand.command(name="version", help="Check current version of GinCloud utility")
def version():
    """
    Check current version of GinCloud utility
    """
    try:
        typer.echo(format_version_block(Current_Version, _runtime_info))
    except Exception as e:
        logger.error(f"Error while Version check: {e}")
        raise typer.Exit(code=1)


@RootCommand.callback(invoke_without_command=True)
def main(
    ctx: typer.Context,
    log_level: str = typer.Option(
        os.getenv("GINCLOUD_CONSOLE_LOG_LEVEL", "INFO"),
        "--log-level",
        "-ll",
        metavar="DEBUG|INFO|WARNING|ERROR",
        help=(
            "Set the console log verbosity level for this session.\n\n"
            "  DEBUG   — full diagnostic output (very verbose)\n"
            "  INFO    — standard progress messages  [default]\n"
            "  WARNING — only warnings and errors\n"
            "  ERROR   — errors only\n\n"
            "Can also be set permanently via env var: GINCLOUD_CONSOLE_LOG_LEVEL"
        ),
        is_eager=True,  # apply before any subcommand runs
    ),
):
    """This command-line tool provides a powerful and efficient way to manage Azure cloud resources,
    generate reports, and handle resource tagging for Ginesys Cloud environments."""

    # Apply log level immediately so every subsequent logger call respects it
    set_console_log_level(log_level)

    # If no subcommand was invoked, show help
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


if __name__ == "__main__":
    RootCommand()
