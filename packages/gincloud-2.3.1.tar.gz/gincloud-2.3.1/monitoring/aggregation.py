"""
Prometheus to MS SQL Server - Daily Availability Data Exporter
(Daily only, with uptime_minutes added)
"""

from urllib.parse import urlparse
import requests
from datetime import datetime, timedelta, date
from pathlib import Path
import pyodbc
from typing import List, Dict, Any, Optional
import yaml
import os
import logging
from dataclasses import dataclass, field


from utils.logger import get_logger

logger = get_logger("monitoring.aggregation")

# -----------------------------------------------------------------------------
# Configuration Models
# -----------------------------------------------------------------------------

@dataclass
class PrometheusConfig:
    url: str
    timeout: int = 30


@dataclass
class MSSQLConfig:
    server: str
    database: str
    username: str
    password: str
    driver: str = "ODBC Driver 17 for SQL Server"


@dataclass
class ExporterConfig:
    prometheus: PrometheusConfig
    mssql: MSSQLConfig
    log_file: str = field(default_factory=lambda: str(
        Path("C:/ProgramData/Ginesys/CloudAdmin/Monitoring/prometheus_exporter.log")
    ))
    default_step: str = "5m"
    batch_size: int = 1000


# -----------------------------------------------------------------------------
# Config Loader
# -----------------------------------------------------------------------------

class ConfigLoader:
    PREFIX = "GINCLOUD_"

    @staticmethod
    def load_from_yaml(config_file: str) -> Dict[str, Any]:
        try:
            with open(config_file, "r") as f:
                return yaml.safe_load(f) or {}
        except Exception:
            return {}

    @staticmethod
    def load_from_env() -> Dict[str, Any]:
        cfg = {"prometheus": {}, "mssql": {}}

        if os.getenv("GINCLOUD_PROMETHEUS_URL"):
            cfg["prometheus"]["url"] = os.getenv("GINCLOUD_PROMETHEUS_URL")

        if os.getenv("GINCLOUD_MSSQL_SERVER"):
            cfg["mssql"]["server"] = os.getenv("GINCLOUD_MSSQL_SERVER")
        if os.getenv("GINCLOUD_MSSQL_DATABASE"):
            cfg["mssql"]["database"] = os.getenv("GINCLOUD_MSSQL_DATABASE")
        if os.getenv("GINCLOUD_MSSQL_USERNAME"):
            cfg["mssql"]["username"] = os.getenv("GINCLOUD_MSSQL_USERNAME")
        if os.getenv("GINCLOUD_MSSQL_PASSWORD"):
            cfg["mssql"]["password"] = os.getenv("GINCLOUD_MSSQL_PASSWORD")

        return cfg

    @staticmethod
    def merge_configs(*configs: Dict[str, Any]) -> Dict[str, Any]:
        result: Dict[str, Any] = {}
        for cfg in configs:
            for k, v in cfg.items():
                if isinstance(v, dict) and isinstance(result.get(k), dict):
                    result[k].update(v)
                else:
                    result[k] = v
        return result

    @classmethod
    def load(cls, yaml_file: str, cli_cfg: Dict[str, Any]) -> ExporterConfig:
        final = cls.merge_configs(
            cls.load_from_yaml(yaml_file),
            cls.load_from_env(),
            cli_cfg
        )

        return ExporterConfig(
            prometheus=PrometheusConfig(**final["prometheus"]),
            mssql=MSSQLConfig(**final["mssql"]),
            log_file=final.get("log_file"),
            default_step=final.get("default_step", "5m")
        )

# -----------------------------------------------------------------------------
# Data Model
# -----------------------------------------------------------------------------

@dataclass
class AvailabilityMetric:
    metric_date: date
    client_id: str
    application_name: str
    instance: str
    total_checks: int
    successful_checks: int
    failed_checks: int
    uptime_percentage: float
    uptime_minutes: float
    downtime_minutes: float


# -----------------------------------------------------------------------------
# Exporter
# -----------------------------------------------------------------------------

class PrometheusToMSSQL:

    def __init__(self, config: ExporterConfig, logger: logging.Logger = logger):
        self.config = config
        self.logger = logger
        self.connection: Optional[pyodbc.Connection] = None

    def connect(self) -> None:
        conn_str = (
            f"DRIVER={{{self.config.mssql.driver}}};"
            f"SERVER={self.config.mssql.server};"
            f"DATABASE={self.config.mssql.database};"
            f"UID={self.config.mssql.username};"
            f"PWD={self.config.mssql.password}"
        )
        self.connection = pyodbc.connect(conn_str)
        self.logger.info("Successfully Connected to MSSQL")

    def create_table(self) -> None:
        sql = """
        IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='availability_metrics_daily' AND xtype='U')
        CREATE TABLE availability_metrics_daily (
            id INT IDENTITY(1,1) PRIMARY KEY,
            metric_date DATE NOT NULL,
            client_id VARCHAR(255) NOT NULL,
            application_name VARCHAR(255) NOT NULL,
            instance VARCHAR(255) NOT NULL,
            total_checks INT NOT NULL,
            successful_checks INT NOT NULL,
            failed_checks INT NOT NULL,
            uptime_percentage DECIMAL(5,2) NOT NULL,
            uptime_minutes DECIMAL(10,2) NOT NULL,
            downtime_minutes DECIMAL(10,2) NOT NULL,
            created_at DATETIME DEFAULT GETDATE(),
            updated_at DATETIME DEFAULT GETDATE(),
            CONSTRAINT UC_daily UNIQUE (metric_date, client_id, application_name, instance)
        );
        """
        cur = self.connection.cursor()
        cur.execute(sql)
        self.connection.commit()
        self.logger.info("Successfully Created or Verified Table")

    def query_prometheus(self, query: str, start: datetime, end: datetime) -> Dict[str, Any]:
        self.logger.debug(f"Querying Prometheus for {query} from {start} to {end}")
        url = f"{self.config.prometheus.url}/api/v1/query_range"
        params = {
            "query": query,
            "start": start.timestamp(),
            "end": end.timestamp(),
            "step": "5m"
        }
        r = requests.get(url, params=params, timeout=self.config.prometheus.timeout)
        r.raise_for_status()
        self.logger.info("Successfully Queried Prometheus")
        return r.json()

    def calculate_daily_metrics(self, target_date: date) -> List[AvailabilityMetric]:
        self.logger.debug("Calculating metrics for %s", target_date)
        start = datetime.combine(target_date, datetime.min.time())
        end = start + timedelta(days=1)

        result = self.query_prometheus(
            "avg_over_time(probe_success[5m])", start, end
        )

        metrics: List[AvailabilityMetric] = []

        for series in result["data"]["result"]:
            labels = series["metric"]
            values = series["values"]

            total = len(values)
            success = sum(1 for v in values if float(v[1]) == 1.0)
            failed = total - success

            uptime_minutes = success * 5
            downtime_minutes = failed * 5

            instance = labels.get("instance", "unknown")
            metrics.append(
                AvailabilityMetric(
                    metric_date=target_date,
                    client_id=urlparse(instance).hostname or instance,
                    application_name=labels.get("job", "unknown"),
                    instance=instance,
                    total_checks=total,
                    successful_checks=success,
                    failed_checks=failed,
                    uptime_percentage=round((success / total) * 100, 2) if total else 0,
                    uptime_minutes=uptime_minutes,
                    downtime_minutes=downtime_minutes
                )
            )
        self.logger.info("Successfully Calculated metrics for %s", target_date)
        return metrics

    def save_metrics(self, metrics: List[AvailabilityMetric]) -> None:
        self.logger.debug("Saving metrics into MSSQL")
        sql = """
        MERGE availability_metrics_daily AS t
        USING (VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)) AS s
        (metric_date, client_id, application_name, instance,
         total_checks, successful_checks, failed_checks,
         uptime_percentage, uptime_minutes, downtime_minutes)
        ON t.metric_date=s.metric_date AND t.client_id=s.client_id
           AND t.application_name=s.application_name AND t.instance=s.instance
        WHEN MATCHED THEN UPDATE SET
            total_checks=s.total_checks,
            successful_checks=s.successful_checks,
            failed_checks=s.failed_checks,
            uptime_percentage=s.uptime_percentage,
            uptime_minutes=s.uptime_minutes,
            downtime_minutes=s.downtime_minutes,
            updated_at=GETDATE()
        WHEN NOT MATCHED THEN INSERT
        (metric_date, client_id, application_name, instance,
         total_checks, successful_checks, failed_checks,
         uptime_percentage, uptime_minutes, downtime_minutes)
        VALUES
        (s.metric_date, s.client_id, s.application_name, s.instance,
         s.total_checks, s.successful_checks, s.failed_checks,
         s.uptime_percentage, s.uptime_minutes, s.downtime_minutes);
        """

        cur = self.connection.cursor()
        for m in metrics:
            cur.execute(sql, (
                m.metric_date, m.client_id, m.application_name, m.instance,
                m.total_checks, m.successful_checks, m.failed_checks,
                m.uptime_percentage, m.uptime_minutes, m.downtime_minutes
            ))
        self.connection.commit()
        self.logger.info("Successfully Saved metrics into MSSQL")

    def close(self):
        self.logger.info("Closing connection to MSSQL")
        if self.connection:
            self.connection.close()




