"""
Shared CLI context objects passed through the Typer/Click context object (ctx.obj).

Every parent-group callback writes into one of these dataclasses so child
commands can read the values without repeating the same CLI options.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class AzureContext:
    """
    Holds the shared Azure auth + scope state set by the ``azure`` group callback.

    Child commands receive this via ``ctx.obj`` and can:
      • Use it as-is   →  gincloud azure --tenant xxx --auth cli tag export
      • Override bits  →  gincloud azure --tenant xxx tag export --subscription yyy

    Attribute precedence (resolved inside ``resolve_scope_from_context``):
      command-level override  >  AzureContext value  >  built-in default
    """

    # ── Authentication ─────────────────────────────────────────────────────
    auth_method: List[str] = field(
        default_factory=lambda: [
            os.getenv("GINCLOUD_DEFAULT_AZURE_AUTH_METHOD", "browser")
        ]
    )
    client_id: Optional[str] = field(
        default_factory=lambda: os.getenv("GINCLOUD_AUTH_CLIENT_ID")
    )
    client_secret: Optional[str] = field(
        default_factory=lambda: os.getenv("GINCLOUD_AUTH_CLIENT_SECRET")
    )
    thumbprint: Optional[str] = field(
        default_factory=lambda: os.getenv("GINCLOUD_AUTH_CERTIFICATE_THUMBPRINT")
    )
    access_token: Optional[str] = field(
        default_factory=lambda: os.getenv("GINCLOUD_AUTH_ACCESS_TOKEN")
    )

    # ── Scope ──────────────────────────────────────────────────────────────
    tenant_ids: List[str] = field(default_factory=list)
    subscription_ids: List[str] = field(default_factory=lambda: ["all"])
    exclude_subscription_ids: List[str] = field(default_factory=list)

    # ── Subscription policy flags ──────────────────────────────────────────
    allow_disable: bool = False
    allow_spending_limit: bool = True
