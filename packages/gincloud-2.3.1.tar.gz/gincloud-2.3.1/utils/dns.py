from typing import List, Dict, Optional, Union, Tuple
import requests
import dns.resolver
import csv
from pathlib import Path
import ipaddress
import re

from utils.environment import ensure_env
from utils.logger import get_logger

logger = get_logger("utils.dns")


# ------------------- Constants ------------------- #
GODADDY_API = "https://api.godaddy.com/v1"


# ------------------- Helpers ------------------- #
def _get_godaddy_headers(
    api_key: Optional[str] = None, api_secret: Optional[str] = None
) -> Dict[str, str]:
    """Return authentication headers for GoDaddy API."""
    api_key = api_key or ensure_env("GINCLOUD_GODADDY_API_KEY")
    api_secret = api_secret or ensure_env("GINCLOUD_GODADDY_API_SECRET")

    if not api_key or not api_secret:
        logger.error("Missing GoDaddy API credentials (API Key/Secret).")
        raise ValueError(
            "GoDaddy API Key and Secret must be provided or set in environment variables"
        )

    return {
        "Authorization": f"sso-key {api_key}:{api_secret}",
        "Content-Type": "application/json",
    }


def _split_domain(full_domain: str) -> Tuple[str, str]:
    """Split full domain into record name and base domain."""
    parts = full_domain.split(".")
    if len(parts) < 2:
        logger.error(f"Invalid domain format: {full_domain}")
        raise ValueError("Invalid domain format")
    domain = ".".join(parts[-2:])
    name = ".".join(parts[:-2]) if len(parts) > 2 else "@"
    return name, domain


def _detect_record_type_by_data(data: str) -> str:
    """
    Detect whether the given data should be an A record or a CNAME.

    Returns:
        "A" if data is an IPv4/IPv6 address
        "CNAME" if data looks like a hostname/FQDN
    """
    logger.info(f"called Check record type by data :{data}")
    try:
        # Try parsing as IP (IPv4 or IPv6)
        ipaddress.ip_address(data)
        return "A"
    except ValueError:
        # Not an IP, check if valid hostname/FQDN
        fqdn_pattern = re.compile(
            r"^(?=.{1,253}$)(?!-)[A-Za-z0-9-]{1,63}(?<!-)(\.(?!-)[A-Za-z0-9-]{1,63}(?<!-))*\.?$"
        )
        if fqdn_pattern.match(data):
            return "CNAME"
        else:
            raise ValueError(
                f"Invalid data: '{data}' is neither a valid IP nor a hostname"
            )


# ------------------- Core Functions ------------------- #


def get_record_by_resolve_dns(
    domain: str,
    types: List[str] = ["CNAME", "A", "AAAA", "MX", "TXT", "NS"],
    nameservers: List[str] = ["8.8.8.8"],
):
    """
    Try to resolve different record types for the given domain.
    Returns (exists, type, data) or (False, None, None).
    """
    logger.debug(
        f"Checking DNS for {domain} with types {types} using nameservers {nameservers}"
    )
    resolver = dns.resolver.Resolver()
    resolver.nameservers = nameservers

    for rtype in types:
        try:
            answers = resolver.resolve(domain, rtype, raise_on_no_answer=False)
            if answers.rrset:
                targets = [str(rdata) for rdata in answers]
                return True, rtype, ";".join(targets)
        except (
            dns.resolver.NoAnswer,
            dns.resolver.NXDOMAIN,
            dns.resolver.NoNameservers,
            dns.exception.Timeout,
        ):
            continue
    return False, None, None


def get_record(
    name: str,
    domain: str = "ginesys.cloud",
    types: list[str] = ["CNAME", "A"],
    api_key: Optional[str] = None,
    api_secret: Optional[str] = None,
) -> Optional[List[Dict]]:
    """Fetch existing DNS record."""

    headers = _get_godaddy_headers(api_key, api_secret)

    for tp in list(types):
        logger.debug(f"Fetching record {tp} {name}.{domain}")
        resp = requests.get(
            f"{GODADDY_API}/domains/{domain}/records/{tp}/{name}", headers=headers
        )

        if resp.status_code == 200:
            records = resp.json()
            if records:  # non-empty list
                logger.info(f"Found record {name}.{domain} ({tp})")
                return records[0]
            else:
                logger.debug(f"No {tp} record found for {name}.{domain}")
                continue

        elif resp.status_code == 404:
            logger.debug(f"No {tp} record exists for {name}.{domain}")
            continue

        else:
            logger.error(f"Error {resp.status_code}: {resp.text}")
            continue

    logger.debug(f"No record found for {name}.{domain} ({types})")
    return {}


def get_all_records(
    domain: str,
    api_key: Optional[str] = None,
    api_secret: Optional[str] = None,
) -> Optional[List[Dict]]:
    """Fetch all DNS records for a domain."""
    headers = _get_godaddy_headers(api_key, api_secret)
    url = f"{GODADDY_API}/domains/{domain}/records"

    logger.debug(f"Fetching all records for domain {domain}")
    resp = requests.get(url, headers=headers)

    if resp.status_code == 200:
        logger.info(f"Found records for domain {domain}")
        # appending the domain in to the response records
        records = resp.json()
        for record in records:
            record["domain"] = domain
        return records

    logger.warning(f"No records found for domain {domain}")
    return None


def create_record(
    name: str,
    data: str,
    rtype: str = "CNAME",
    domain: str = "ginesys.cloud",
    ttl: int = 3600,
    overwrite: bool = False,
    api_key: Optional[str] = None,
    api_secret: Optional[str] = None,
):
    """Create a DNS record (optionally overwrite if exists)."""
    headers = _get_godaddy_headers(api_key, api_secret)

    if domain in name:
        new_name = name.replace(f".{domain}", "")
        logger.warning(
            f"Domain {domain} is already in name {name},Hence removing domain from name to get actual name {new_name}"
        )
        name = new_name

    full_domain = f"{name}.{domain}"

    existing_record = get_record(
        name=name, domain=domain, api_key=api_key, api_secret=api_secret
    )
    record = [{"data": data, "name": name, "ttl": ttl, "type": rtype}]

    if existing_record.get("data", False) and not overwrite:
        logger.error(
            f"Record already exists for {full_domain}: {existing_record.get('data', None)}"
        )
        return {"status": "exists", "record": existing_record.get("data", None)}

    if existing_record.get("data", False) and overwrite:
        logger.warning(f"Overwriting existing record {full_domain} with data {data}")
        return update_record(
            name=name,
            data=data,
            rtype=rtype,
            domain=domain,
            ttl=ttl,
            api_key=api_key,
            api_secret=api_secret,
        )

    url = f"{GODADDY_API}/domains/{domain}/records"
    resp = requests.patch(url, headers=headers, json=record)
    resp.raise_for_status()
    logger.info(f"Created record {name}.{domain} ({rtype}) -> {data}")
    return {
        "name": name,
        "data": data,
        "type": rtype,
        "domain": domain,
        "ttl": ttl,
        "action": "create",
        "status": "created",
        "result": record,
        "note": None,
    }


def update_record(
    name: str,
    data: str = None,
    rtype: str = None,
    domain: str = "ginesys.cloud",
    ttl: int = 3600,
    ignore_type_mismatch: bool = True,
    if_not_exists_create: bool = True,
    api_key: Optional[str] = None,
    api_secret: Optional[str] = None,
):
    """Update an existing DNS record even if the type is different."""
    logger.debug(
        f"updating record with name:{name} data:{data} type:{rtype} domain:{domain} ttl:{ttl} ignore_type_mismatch:{ignore_type_mismatch} if_not_exists_create:{if_not_exists_create} "
    )
    headers = _get_godaddy_headers(api_key, api_secret)
    if domain in name:
        new_name = name.replace(f".{domain}", "")
        logger.warning(
            f"Domain {domain} is already in name {name},Hence removing domain from name to get actual name {new_name}"
        )
        name = new_name
    full_domain = f"{name}.{domain}"

    existing_record = get_record(name=name, domain=domain)

    if data is None:  # if data not provided, keep existing data
        data = existing_record.get("data", None)
    if rtype is None:  # if record type not provided, keep existing type
        if existing_record.get("type", False):
            logger.debug("updating current type with existing type")
            rtype = existing_record.get("type", None)
        elif data:
            logger.debug("try to check type as per provided data ip/fqdns")
            rtype = _detect_record_type_by_data(data=data)
        else:
            rtype = input("DNS Type is required kindly provide dns type :").upper()

    record = [{"data": data, "name": name, "ttl": ttl, "type": rtype}]
    url = f"{GODADDY_API}/domains/{domain}/records/{rtype}/{name}"

    if existing_record.get("name", None) != name:
        if if_not_exists_create:
            logger.warning(
                f"No existing record found for {full_domain} ({rtype}). Creating new record."
            )
            return create_record(
                name=name,
                data=data,
                rtype=rtype,
                domain=domain,
                ttl=ttl,
                overwrite=False,
                api_key=api_key,
                api_secret=api_secret,
            )
        else:
            logger.warning(
                f"No existing record found for {full_domain} ({rtype}). to create if not existing use flag --if-not-exists-create ."
            )

            return {
                "name": name,
                "data": data,
                "type": rtype,
                "domain": domain,
                "ttl": ttl,
                "action": "update",
                "status": "failed",
                "result": record,
                "note": "There no existing record and not provided flag to create when there is no record",
            }

    # handle type mismatch by deleting and recreating
    if existing_record.get("type", None) != rtype:
        if not ignore_type_mismatch:
            logger.error(
                f"Record type mismatch for {full_domain}: existing type is {existing_record.get('type', None)}, requested type is {rtype}. Use --ignore-type-mismatch to overwrite."
            )
            return {
                "name": name,
                "data": data,
                "type": rtype,
                "domain": domain,
                "ttl": ttl,
                "action": "update",
                "status": "failed",
                "result": record,
                "note": "Found type mismatch and there no flag to delete existing on and create new one",
            }

        logger.warning(
            f"Record type mismatch for {full_domain}: existing type is {existing_record.get('type', None)}, requested type is {rtype}. Overwriting."
        )
        delete_record(
            name=name,
            rtype=existing_record.get("type", None),
            domain=domain,
            api_key=api_key,
            api_secret=api_secret,
        )

        create_record(
            name=name,
            data=data,
            rtype=rtype,
            domain=domain,
            ttl=ttl,
            api_key=api_key,
            api_secret=api_secret,
        )
        logger.info(f"Created new record {full_domain} of type {rtype}")
        return {
            "name": name,
            "data": data,
            "type": rtype,
            "domain": domain,
            "ttl": ttl,
            "action": "update",
            "status": "updated_with_new_type",
            "result": record,
            "note": None,
        }

    resp = requests.put(url, headers=headers, json=record)
    resp.raise_for_status()
    logger.info(f"Updated record {name}.{domain} ({rtype}) -> {data}")
    return {"status": "updated", "record": record}


def delete_record(
    name: str,
    domain: str = "ginesys.cloud",
    rtype: str = None,
    confirm: bool = False,
    api_key: Optional[str] = None,
    api_secret: Optional[str] = None,
):
    """Delete a DNS record."""
    logger.info(
        f"delete_recod function called with name:{name} domain:{domain} rtype:{rtype} confirmation:{confirm}"
    )
    headers = _get_godaddy_headers(api_key, api_secret)
    if domain in name:
        new_name = name.replace(f".{domain}", "")
        logger.warning(
            f"Domain {domain} is already in name {name},Hence removing domain from name to get actual name {new_name}"
        )
        name = new_name
    full_domain = f"{name}.{domain}"

    existing_record = get_record(
        name=name, domain=domain, api_key=api_key, api_secret=api_secret
    )

    if not existing_record.get("name", False):
        logger.warning(
            f"No existing record found for {full_domain}. Nothing to delete."
        )
        return {
            "name": name,
            "data": existing_record.get("data"),
            "type": rtype,
            "domain": domain,
            "ttl": existing_record.get("ttl"),
            "action": "delete",
            "status": "failed",
            "result": None,
            "note": "No existing record found to delete",
        }

    # check and detect record type if not provided
    if not rtype:
        rtype = existing_record.get("type")
        logger.info(f"Detected record type {rtype} for {full_domain}")

    if not confirm:
        confirm = input(f"are you sure want to delete {full_domain} ? y/n :").lower()
        if confirm != "y":
            logger.info("skip deletion by user !")
            return {"status": "skip_deleted", "record": f"{name}.{domain}"}

    resp = requests.delete(
        f"{GODADDY_API}/domains/{domain}/records/{rtype}/{name}", headers=headers
    )
    if resp.status_code in (200, 204):
        logger.info(f"Deleted record {name}.{domain} ({rtype})")
        return {
            "name": name,
            "data": existing_record.get("data"),
            "type": rtype,
            "domain": domain,
            "ttl": existing_record.get("ttl"),
            "action": "delete",
            "status": "deleted",
            "result": None,
            "note": None,
        }

    logger.error(f"Failed to delete {name}.{domain} ({rtype}): {resp.text}")
    resp.raise_for_status()


# ------------------- CSV Reader ------------------- #
def _read_csv_records(
    file_path: Union[str, Path],
    name_col: str = "name",
    data_col: str = "data",
    type_col: str = "type",
    domain_col: str = "domain",
    ttl_col: str = "ttl",
) -> List[Dict]:
    """Read CSV into records with flexible column names."""
    records = []
    with open(file_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            record = {
                "domain": row.get(domain_col, "").strip(),
                "name": row.get(name_col, "").strip(),
                "type": row.get(type_col, "").strip().upper() or None,
                "data": row.get(data_col, "").strip() or None,
                "ttl": row.get(ttl_col, "").strip() or None,
            }
            records.append(record)
    return records


# ------------------- Bulk Create ------------------- #
def bulk_create_records(
    input_file: Union[str, Path],
    overwrite: bool = False,
    input_file_col_name: str = "name",
    input_file_col_data: str = "data",
    input_file_col_type: str = "type",
    input_file_col_domain: str = "domain",
    input_file_col_ttl: str = "ttl",
    default_domain: str = "ginesys.cloud",
    default_data: Optional[str] = None,
    default_type: str = "CNAME",
    default_ttl: int = 3600,
    api_key: Optional[str] = None,
    api_secret: Optional[str] = None,
):
    results = []

    records = _read_csv_records(
        file_path=input_file,
        domain_col=input_file_col_domain,
        name_col=input_file_col_name,
        data_col=input_file_col_data,
        type_col=input_file_col_type,
        ttl_col=input_file_col_ttl,
    )

    for rec in records:
        name = rec["name"]
        data = rec["data"] or default_data
        domain = rec["domain"] or default_domain
        rtype = rec["type"] or default_type
        ttl = int(rec["ttl"] or default_ttl)

        if not domain or not data:
            logger.error(f"Skipping record due to missing domain/data: {rec}")
            results.append(
                {
                    "name": name,
                    "data": data,
                    "type": rtype,
                    "domain": domain,
                    "ttl": ttl,
                    "action": "create",
                    "status": "failed",
                    "result": None,
                    "note": "There is no name in the csv",
                }
            )
            continue

        try:
            res = create_record(
                name=name,
                data=data,
                domain=domain,
                rtype=rtype,
                ttl=ttl,
                overwrite=overwrite,
                api_key=api_key,
                api_secret=api_secret,
            )
            results.append(res)
        except Exception as e:
            logger.error(f"Failed to create record {domain}")
            results.append(
                {
                    "name": name,
                    "data": data,
                    "type": rtype,
                    "domain": domain,
                    "ttl": ttl,
                    "action": "create",
                    "status": "failed",
                    "result": None,
                    "note": f"Due to error: {e}",
                }
            )
    return results


# ------------------- Bulk Update ------------------- #
def bulk_update_records(
    input_file: str,
    ignore_type_mismatch: bool = False,
    if_not_exists_create: bool = False,
    input_file_col_name: str = "name",
    input_file_col_data: str = "data",
    input_file_col_type: str = "type",
    input_file_col_ttl: str = "ttl",
    default_type: Optional[str] = None,
    default_domain: Optional[str] = None,
    default_data: Optional[str] = None,
    default_ttl: int = 3600,
    api_key: Optional[str] = None,
    api_secret: Optional[str] = None,
):
    results = []

    records = _read_csv_records(
        file_path=input_file,
        name_col=input_file_col_name,
        type_col=input_file_col_type,
        data_col=input_file_col_data,
        ttl_col=input_file_col_ttl,
    )

    for rec in records:
        name = rec["name"]

        if not name:
            logger.error(f"Skipping update due to missing domain: {rec}")
            results.append(
                {
                    "name": name,
                    "data": None,
                    "type": None,
                    "domain": None,
                    "ttl": None,
                    "action": "update",
                    "status": "failed",
                    "result": None,
                    "note": "No name found in the csv.",
                }
            )
            continue
        domain = rec["domain"] or default_domain
        rtype = (
            rec["type"]
            or default_type
            or input("Enter record type for {}: ".format(domain)).upper()
        )
        data = (
            rec["data"] or default_data or input("Enter data for {}: ".format(domain))
        )
        ttl = int(rec["ttl"] or default_ttl)

        try:
            logger.info(
                f"1 updating record with name:{name} data:{data} type:{rtype} domain:{domain} ttl:{ttl} ignore_type_mismatch:{ignore_type_mismatch} if_not_exists_create:{if_not_exists_create} "
            )

            res = update_record(
                name=name,
                domain=domain,
                data=data,
                rtype=rtype,
                ttl=ttl,
                ignore_type_mismatch=ignore_type_mismatch,
                if_not_exists_create=if_not_exists_create,
                api_key=api_key,
                api_secret=api_secret,
            )
            results.append(res)
        except Exception as e:
            logger.exception(f"Failed to update record {domain}")
            results.append(
                {
                    "name": name,
                    "data": data,
                    "type": rtype,
                    "domain": domain,
                    "ttl": ttl,
                    "action": "update",
                    "status": "failed",
                    "result": None,
                    "note": f"Due to error :{e}",
                }
            )

    return results


# ------------------- Bulk Delete ------------------- #
def bulk_delete_records(
    input_file: List[Union[str, Path]],
    confirm: bool = False,
    input_file_col_name: str = "name",
    input_file_col_domain: str = "domain",
    input_file_col_type: str = "type",
    default_domain: Optional[str] = None,
    default_type: Optional[str] = None,
    api_key: Optional[str] = None,
    api_secret: Optional[str] = None,
):
    results = []

    records = _read_csv_records(
        file_path=input_file,
        name_col=input_file_col_name,
        domain_col=input_file_col_domain,
        type_col=input_file_col_type,
    )

    for rec in records:
        name = rec["name"]
        domain = rec["domain"] or default_domain
        rtype = rec["type"] or default_type

        if not name:
            logger.error(f"Skipping delete due to missing domain name: {rec}")
            results.append(
                {
                    "name": name,
                    "data": None,
                    "type": rtype,
                    "domain": domain,
                    "ttl": None,
                    "action": "delete",
                    "status": "failed",
                    "result": None,
                    "note": "No name found in csv.",
                }
            )
            continue

        try:
            res = delete_record(
                name=name,
                domain=domain,
                rtype=rtype,
                confirm=confirm,
                api_key=api_key,
                api_secret=api_secret,
            )
            results.append(res)
        except Exception as e:
            logger.exception(f"Failed to delete record {domain}")
            results.append(
                {
                    "name": name,
                    "data": None,
                    "type": rtype,
                    "domain": domain,
                    "ttl": None,
                    "action": "delete",
                    "status": "failed",
                    "result": None,
                    "note": f"Due to error : {e}",
                }
            )

    return results
