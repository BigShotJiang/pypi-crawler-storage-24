import os
import platform
import subprocess
from typing import Optional
from utils.logger import get_logger
from utils import input_with_timeout
# Configure logging
logger = get_logger(name="utils.environment")

def env_exists(var_name: str) -> bool:
    """Check if an environment variable exists."""
    exists = var_name in os.environ
    logger.debug("Check environment variable '%s': %s", var_name, exists)
    return exists


def get_env(var_name: str, default: Optional[str] = None) -> str:
    """Retrieve an environment variable value with optional default."""
    value = os.environ.get(var_name, default)
    if value is None:
        logger.error("Environment variable '%s' not set and no default provided.", var_name)
        raise ValueError(f"Environment variable '{var_name}' not set.")
    logger.debug("Retrieved environment variable '%s'", var_name)
    return value


def set_env(var_name: str, value: str) -> None:
    """Set an environment variable for the current session."""
    os.environ[var_name] = value
    logger.debug("Environment variable '%s' set for current execution session.", var_name)


def set_env_permanent(var_name: str, value: str) -> None:
    """Persistently set an environment variable on the system."""
    system = platform.system()
    try:
        if system == "Windows":
            out = subprocess.run(
                f'setx {var_name} "{value}"',
                shell=True,
                check=True
            )
            logger.debug("setx output: %s", out)
            logger.info("Environment variable '%s' set permanently on Windows.", var_name)
            logger.warning("Restart terminal to apply changes.")

        elif system in ("Linux", "Darwin"):
            rc_file = os.path.expanduser("~/.bashrc")
            if not os.path.exists(rc_file):
                rc_file = os.path.expanduser("~/.zshrc")

            with open(rc_file, "a") as f:
                f.write(f'\nexport {var_name}="{value}"\n')

            logger.info(
                "Environment variable '%s' set permanently in %s. "
                "Restart terminal or run 'source %s' to apply.",
                var_name, rc_file, rc_file
            )
        else:
            logger.warning("Unsupported OS '%s'. Please set manually.", system)

    except subprocess.CalledProcessError as e:
        logger.error("Failed to set environment variable '%s' permanently: %s", var_name, e)
    except Exception as e:
        logger.exception("Unexpected error while setting environment variable permanently: %s", e)


def ensure_env(var_name: str) -> str:
    """Ensure an environment variable exists, prompt user if missing."""
    if not env_exists(var_name):
        value = input(f"Enter a value for environment variable: '{var_name}': ")
        set_env(var_name, value)
        if input_with_timeout(f"Do you want to save the environment variable '{var_name}' permanently? (y/n): ",10).strip().lower() == "y":
            set_env_permanent(var_name, value)
    return get_env(var_name)


def save_env_to_file(var_name: str, value: str, file_path: str = ".env") -> None:
    """Append an environment variable to a .env file."""
    try:
        with open(file_path, "a") as f:
            f.write(f"{var_name}={value}\n")
        logger.info("Saved '%s' to %s", var_name, file_path)
    except Exception as e:
        logger.exception("Error saving '%s' to %s: %s", var_name, file_path, e)


def load_env_file(file_path: str = ".env") -> None:
    """Load environment variables from a .env file."""
    try:
        with open(file_path, "r") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    key, value = line.split("=", 1)
                    os.environ[key] = value
                    logger.debug("Loaded '%s' from %s", key, file_path)
        logger.info("Environment variables loaded from %s", file_path)
    except FileNotFoundError:
        logger.warning("%s not found. Skipping.", file_path)
    except Exception as e:
        logger.exception("Error loading environment variables from %s: %s", file_path, e)