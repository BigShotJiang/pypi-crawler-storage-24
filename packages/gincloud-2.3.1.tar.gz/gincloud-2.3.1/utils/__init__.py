import csv
import pandas as pd
import json
from typing import List, Dict, Any
import re
import os
import time
import msvcrt
from InquirerPy import inquirer

from utils.logger import get_logger

logger = get_logger("gincloud.utils")
# Function to save the data to a CSV file



def input_with_timeout(prompt: str, timeout: int = 5, default="") -> str:
    """Prompt user for input with timeout. Works on Windows using msvcrt."""
    print(prompt, end="", flush=True)
    start_time = time.time()
    inp = ""

    while True:
        if msvcrt.kbhit():
            char = msvcrt.getche()
            if char in {b"\r", b"\n"}:
                print()  # move to next line
                return inp
            elif char == b"\x08":  # backspace
                inp = inp[:-1]
                print(" \b", end="", flush=True)
            else:
                inp += char.decode(errors="ignore")

        if time.time() - start_time > timeout:
            print()  # <-- ensure cursor moves to next line after timeout
            logger.debug("No input received within %s seconds. Skipping...", timeout)
            return default

def get_unique_output_filename(output_file: str,force_overwrite=False) -> str:
    """
    Checks if the output file exists. If it does, prompts the user for overwrite.
    If not overwriting, appends a numeric suffix to create a unique filename.

    Args:
        output_file (str): Desired output file path.

    Returns:
        str: Final file path to use.
    """
    if not os.path.exists(output_file):
        return output_file
    if not force_overwrite:
        response = input_with_timeout(f"File '{output_file}' already exists. Overwrite? (y/n)[default:n]: ",15,'n').strip().lower()

    if response == 'y' :
        return output_file
    else:
        base, ext = os.path.splitext(output_file)
        counter = 1
        new_file = f"{base}_({counter}){ext}"
        while os.path.exists(new_file):
            counter += 1
            new_file = f"{base}_({counter}){ext}"
        logger.warning(f"New file name will be: {new_file}")
        return new_file

def save_to_csv(data: list[dict], output_file: str, fixed_column_order: list[str] = [],ensure_sorted: bool = True) -> None:
    """
    Save the provided data to a CSV file.
    
    Args:
        data (list[dict]): List of dictionaries representing rows to save.
        output_file (str): Path to the CSV output file.
        fixed_column_order (list[str], optional): List of fields to be fixed at the start of the CSV header.
    """
    if not data:
        logger.warning("No data to save. Exiting without creating a file.")
        return
    if output_file:
        output_file = get_unique_output_filename(output_file)
    try:
        # Collect all keys from all rows
        all_keys = []
        seen = set()
        for row in data:
            for k in row.keys():
                if k not in seen:
                    all_keys.append(k)
                    seen.add(k)
        
        # Build fieldnames
        if fixed_column_order:
            remaining_keys = [k for k in all_keys if k not in fixed_column_order]
            fieldnames = fixed_column_order + remaining_keys
        elif ensure_sorted:
            fieldnames = sorted(all_keys)
        else:
            fieldnames = all_keys
        
        with open(output_file, mode="w", newline="", encoding="utf-8") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(data)
        
        logger.info(f"Successfully exported data to {output_file}")
    
    except Exception as e:
        logger.error(f"Error exporting data to {output_file}: {str(e)}")

def join_list_of_dict(left: list[dict], right: list[dict], on: str,how:str='outer',**kwargs):
    """
    Perform an outer join on two datasets based on a common field (on) using Pandas,
    and replace NaN values with blank strings.
    """
    # Convert lists to DataFrames
    left = pd.DataFrame(left)
    right = pd.DataFrame(right)
    # Convert values in the specified field to lowercase for both data frames
    left[on] = left[on].apply(lambda x: str(x).lower() if isinstance(x, str) else x)
    right[on] = right[on].apply(lambda x: str(x).lower() if isinstance(x, str) else x)

    # Perform outer join on the specified field
    merged_df = pd.merge(left, right, on=on, how=how,**kwargs)

    # Replace NaN values with blank strings
    merged_df = merged_df.fillna('')

    # Convert the merged DataFrame back to a list of dictionaries
    result = merged_df.to_dict(orient='records')

    return result

def save_dict_to_json(data_dict, file_path):
    """
    Saves a dictionary to a JSON file.

    Args:
        data_dict (dict): The dictionary to save.
        file_path (str): The path of the JSON file to save the dictionary to.

    Returns:
        None
    """
    try:
        with open(file_path, 'w') as json_file:
            json.dump(data_dict, json_file, indent=4)  # indent for pretty printing
        print(f"Dictionary successfully saved to {file_path}")
    except Exception as e:
        print(f"Error saving dictionary to JSON file: {e}")


def flatten_json_data(data_list: List[Dict[str, Any]], sep: str = '_') -> List[Dict[str, Any]]:
    """
    Dynamically flattens any nested JSON structure and replaces NaN/null with empty strings.
    """
    def parse_json_strings(obj: Any) -> Any:
        """Recursively parse potential JSON strings in any structure"""
        if isinstance(obj, dict):
            return {k: parse_json_strings(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [parse_json_strings(item) for item in obj]
        elif isinstance(obj, str):
            try:
                parsed = json.loads(obj)
                if isinstance(parsed, (dict, list)):
                    return parse_json_strings(parsed)
            except json.JSONDecodeError:
                pass
        return obj
    
    # Process each record
    processed_data = [parse_json_strings(item) for item in data_list]
    
    # Flatten using pandas
    df = pd.json_normalize(processed_data, sep=sep)
    
    # Clean column names
    df.columns = [re.sub(r'[^\w\s-]', '', col).strip() for col in df.columns]
    
    # Replace NaN and null values with empty strings
    df = df.fillna('')
    
    # Convert back to list of dicts
    return df.to_dict(orient='records')

def interactive_select_from_list(
    data: List[str],
    title: str = "Select one or more items:",
    allow_empty: bool = False,
    ignore_case: bool = True
) -> List[str]:
    """
    Interactive CLI selector for choosing items from a list using InquirerPy.

    Features:
      - Supports multiple selections
      - Includes "[Select All]" option
      - Includes "[Filter by comma-separated list]" option
      - Filters input based on exact match (optional case-insensitive)
      - Avoids duplicates
      - Re-prompts if selection is empty and allow_empty=False

    Args:
        data (List[str]): List of available options.
        title (str): Title/message displayed for selection prompt.
        allow_empty (bool): Whether empty selection is allowed.
        ignore_case (bool): If True, manual filter is case-insensitive.

    Returns:
        List[str]: The final list of selected items.
    """
    if not data:
        logger.warning("No data available to select from.")
        return []

    # Deduplicate and sort
    unique_data = sorted(set(data))

    # Prepare mapping for case-insensitive lookup if needed
    if ignore_case:
        lookup_map = {item.lower(): item for item in unique_data}
    else:
        lookup_map = {item: item for item in unique_data}

    while True:
        base_choices = ["[Select All]", "[Filter by comma-separated list]"] + unique_data

        selected = inquirer.checkbox(
            message=title,
            choices=base_choices,
            cycle=True,
            instruction="(Use arrow keys and space to select)",
        ).execute()

        # --- Handle [Select All] ---
        if "[Select All]" in selected:
            logger.info("All items selected.")
            return unique_data

        # --- Handle [Filter by comma-separated list] ---
        filtered_selection = []
        if "[Filter by comma-separated list]" in selected:
            manual_filter = inquirer.text(
                message="Enter comma-separated filters (exact match):"
            ).execute().strip()

            if manual_filter:
                filters = [f.strip() for f in manual_filter.split(",") if f.strip()]
                matched = []
                unmatched = []

                for f in filters:
                    key = f.lower() if ignore_case else f
                    if key in lookup_map:
                        matched.append(lookup_map[key])
                    else:
                        unmatched.append(f)

                filtered_selection = sorted(set(matched))

                if unmatched:
                    logger.warning(f"No exact matches found for: {', '.join(unmatched)}")

                if not filtered_selection:
                    logger.warning("No items matched your filter. Returning to main selection.")
                    continue

        # Remove control options
        normal_selection = [s for s in selected if not s.startswith("[")]

        # Combine manual and checkbox selections
        final_selection = sorted(set(normal_selection + filtered_selection))

        if not final_selection and not allow_empty:
            logger.warning("You must select at least one item. Please try again.")
            continue

        logger.debug(f"Selected items: {final_selection}")
        return final_selection

