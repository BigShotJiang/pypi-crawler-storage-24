import pandas as pd
from googleapiclient.discovery import build
from google.oauth2 import service_account

from utils.logger import get_logger


logger = get_logger("utils.google_sheet")
GOOGLE_JSON_FILE = "Config/googlesheet.json"

class GoogleSheetsAutomation:
    def __init__(self, sheet_id, sheet_name, range_name, json_file=GOOGLE_JSON_FILE):
        self.sheet_id = sheet_id
        self.sheet_name = sheet_name  # Store the sheet name
        self.range_name = range_name

        try:
            # Load credentials
            credentials = service_account.Credentials.from_service_account_file(
                json_file, scopes=["https://www.googleapis.com/auth/spreadsheets"]
            )
            logger.info("Credentials loaded successfully from %s", json_file)

            # Create Google Sheets API service
            self.service = build('sheets', 'v4', credentials=credentials)
            logger.info("Google Sheets API service created successfully.")
        
        except FileNotFoundError as fnf_error:
            logger.error("Credential file not found: %s", fnf_error)
            raise
        except Exception as e:
            logger.error("An error occurred during authentication or service creation: %s", e)
            raise

    def load_as_dataframe(self):
        try:
            # Fetch data from the correct sheet and range
            full_range = f"{self.sheet_name}!{self.range_name}"
            logger.info("Fetching data from Google Sheet: %s, Range: %s", self.sheet_id, full_range)
            sheet = self.service.spreadsheets()
            result = sheet.values().get(spreadsheetId=self.sheet_id, range=full_range).execute()
            values = result.get('values', [])

            if not values:
                logger.warning("No data found in the sheet.")
                return pd.DataFrame()

            # Create pandas DataFrame
            df = pd.DataFrame(values[1:], columns=values[0])
            logger.info("Data successfully loaded into DataFrame.")
            return df

        except Exception as e:
            logger.error("Failed to load data from Google Sheet: %s", e)
            raise

    def update_sheet_cell(self, row, col, new_value):
        try:
            # Construct the exact cell range with sheet name and coordinates
            # Ensure that the sheet name is included in the range
            cell_range = f"{self.sheet_name}!{chr(65 + col)}{row + 2}"  # `+2` for 1-based index and header
            update_body = {
                "range": cell_range,
                "values": [[new_value]]
            }

            # Update the cell in Google Sheets
            logger.info("Updating cell %s with value: %s", cell_range, new_value)
            self.service.spreadsheets().values().update(
                spreadsheetId=self.sheet_id,
                range=cell_range,
                valueInputOption="RAW",
                body=update_body
            ).execute()

            logger.info("Successfully updated cell %s with value: %s", cell_range, new_value)

        except Exception as e:
            logger.error("Failed to update cell %s with value %s: %s", cell_range, new_value, e)
            raise

    def sync_dataframe_to_sheet(self, df):
        try:
            # Read current sheet data
            logger.info("Syncing DataFrame changes to Google Sheet.")
            current_df = self.load_as_dataframe()

            # Compare and update cells that have changed
            for i in range(len(df)):
                for j in range(len(df.columns)):
                    if df.iloc[i, j] != current_df.iloc[i, j]:
                        self.update_sheet_cell(i, j, df.iloc[i, j])

            logger.info("Data synchronization completed successfully.")

        except Exception as e:
            logger.error("Error occurred during synchronization: %s", e)
            raise

# Usage Test
if __name__ == "__main__":
    try:
        logger.info("Starting Google Sheets automation script.")
        
        # Specify your Google Sheet ID, sheet name, and range
        sheet_id = "1FXaY0LVIkHZylWebz2URxX6APQxbf2qR4DDFFQ36Akc"
        sheet_name = "Infra-Prod"  # Add the sheet name here
        range_name = "A3:D4"  # Specify the range

        # Initialize GoogleSheetsAutomation
        google_sheet = GoogleSheetsAutomation(sheet_id, sheet_name, range_name)

        # Load data into a DataFrame
        df = google_sheet.load_as_dataframe()
        logger.info("Loaded DataFrame: \n%s", df)
       
        # Example modification (update a value in the DataFrame)
        df.iloc[0, 1] = "Updated Value"  # Modify a cell

        # Sync changes back to Google Sheets
        google_sheet.sync_dataframe_to_sheet(df)

    except Exception as e:
        logger.error("Script failed with error: %s", e)
    finally:
        logger.info("Google Sheets automation script completed.")

