import io
import logging
import os
import sys
from datetime import datetime
from colorama import init, Fore, Style
from logging.handlers import QueueHandler, QueueListener
from queue import Queue

# Initialize colorama
init(autoreset=True)

# Base log file directory
LOG_DIR = os.getenv("GINCLOUD_LOG_DIR", "C:/ProgramData/Ginesys/CloudAdmin/GinCloud")

# Default log file name with timestamp
DEFAULT_LOG_FILE = os.getenv(
    "GINCLOUD_LOG_FILE",
    os.path.join(LOG_DIR, f"gincloud_{datetime.now().strftime('%Y%m%d_%H%M%S')}.log"),
)

# Define log level to color mapping
LOG_COLORS = {
    "DEBUG": Fore.BLUE,
    "INFO": Fore.GREEN,
    "WARNING": Fore.YELLOW,
    "ERROR": Fore.RED,
    "CRITICAL": Fore.RED + Style.BRIGHT,
}


class ColorFormatter(logging.Formatter):
    def format(self, record):
        log_color = LOG_COLORS.get(record.levelname, "")
        message = super().format(record)
        return f"{log_color}{message}{Style.RESET_ALL}"


def _make_console_handler() -> logging.StreamHandler:
    """
    Create a StreamHandler that can write Unicode (UTF-8) on Windows.

    On Windows the default sys.stderr encoding is often cp1252, which cannot
    represent characters like U+2500 (box-drawing) or U+2717 (ballot X).
    We wrap stderr in a UTF-8 TextIOWrapper with ``errors='replace'`` so
    those characters are replaced with ``?`` instead of crashing the logger.
    """
    stream = sys.stderr
    if sys.platform == "win32" and hasattr(stream, "buffer"):
        stream = io.TextIOWrapper(
            stream.buffer, encoding="utf-8", errors="replace", line_buffering=True
        )
    return logging.StreamHandler(stream)


# ----------------- Global queue for threaded logging -----------------
_thread_log_queue = Queue()
_thread_queue_listener = None


# ----------------- Single-threaded logger -----------------
def setup_logger(name: str, file_name: str = DEFAULT_LOG_FILE):
    """
    Set up a logger with different configurations for file and console outputs.

    Args:
        name (str): Name of the logger, usually corresponds to the module or component.
        file_name (str, optional): Name of the file to log messages. Defaults to DEFAULT_LOG_FILE.

    Returns:
        logging.Logger: Configured logger instance.
    """
    logger = logging.getLogger(name)

    file_log_level = os.getenv("GINCLOUD_FILE_LOG_LEVEL", "DEBUG").upper()
    console_log_level = os.getenv("GINCLOUD_CONSOLE_LOG_LEVEL", "INFO").upper()

    logger.setLevel(
        min(
            logging.getLevelName(file_log_level),
            logging.getLevelName(console_log_level),
        )
    )

    if not logger.handlers:
        # File handler
        if file_name:
            os.makedirs(os.path.dirname(file_name), exist_ok=True)
            file_handler = logging.FileHandler(file_name)
            file_handler.setLevel(logging.getLevelName(file_log_level))
            file_formatter = logging.Formatter(
                "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
            )
            file_handler.setFormatter(file_formatter)
            logger.addHandler(file_handler)

        # Console handler with colors (UTF-8 safe on Windows)
        console_handler = _make_console_handler()
        console_handler.setLevel(logging.getLevelName(console_log_level))
        console_formatter = ColorFormatter("%(levelname)s - %(message)s")
        console_handler.setFormatter(console_formatter)
        logger.addHandler(console_handler)
    # ✅ Prevent propagation to root logger
    logger.propagate = False
    
    return logger


def get_logger(name: str = None, file_name: str = None):
    """
    Get a logger, defaulting to the root logger if no name is provided.

    Args:
        name (str, optional): Name of the logger. Defaults to "gincloud".
        file_name (str, optional): Name of the file to log messages. Defaults to DEFAULT_LOG_FILE.

    Returns:
        logging.Logger: Configured logger instance.
    """
    if name is None:
        name = "gincloud"

    if file_name is None:
        file_name = DEFAULT_LOG_FILE

    return setup_logger(name, file_name)


# ----------------- Thread-safe logger -----------------
def get_thread_safe_logger(name: str = None, file_name: str = None):
    """
    Thread-safe logger using QueueHandler + QueueListener for multi-threaded code.
    """
    global _thread_queue_listener
    if name is None:
        name = "gincloud"
    if file_name is None:
        file_name = DEFAULT_LOG_FILE

    logger = logging.getLogger(name)

    file_log_level = os.getenv("GINCLOUD_FILE_LOG_LEVEL", "DEBUG").upper()
    console_log_level = os.getenv("GINCLOUD_CONSOLE_LOG_LEVEL", "INFO").upper()

    # Set logger to the minimum level needed by ANY handler
    logger.setLevel(
        min(
            logging.getLevelName(file_log_level),
            logging.getLevelName(console_log_level),
        )
    )

    if not logger.handlers:
        # QueueHandler for threads - set to NOTSET to pass everything through
        queue_handler = QueueHandler(_thread_log_queue)
        queue_handler.setLevel(logging.NOTSET)  # <-- FIX: Let handlers decide
        logger.addHandler(queue_handler)

        # File handler (listener)
        os.makedirs(os.path.dirname(file_name), exist_ok=True)
        file_handler = logging.FileHandler(file_name)
        file_handler.setLevel(logging.getLevelName(file_log_level))  # File gets DEBUG
        file_formatter = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - [%(threadName)s] - %(message)s"
        )
        file_handler.setFormatter(file_formatter)

        # Console handler with color (UTF-8 safe on Windows)
        console_handler = _make_console_handler()
        console_handler.setLevel(logging.getLevelName(console_log_level))  # Console gets INFO
        console_formatter = ColorFormatter(
            "%(levelname)s - [%(threadName)s] - %(message)s"
        )
        console_handler.setFormatter(console_formatter)

        # Start global QueueListener once
        if _thread_queue_listener is None:
            _thread_queue_listener = QueueListener(
                _thread_log_queue, file_handler, console_handler, respect_handler_level=True  # <-- IMPORTANT
            )
            _thread_queue_listener.start()

    logger.propagate = False
    return logger


# ─────────────────────────── Runtime level control ───────────────────────────

def set_console_log_level(level: str) -> None:
    """
    Dynamically change the **console** log level for every active GinCloud logger.

    Called by the root CLI callback when the user passes ``--log-level``.
    File-handler levels are intentionally left untouched (always DEBUG).

    Args:
        level: One of DEBUG | INFO | WARNING | ERROR  (case-insensitive).
    """
    level_int = logging.getLevelName(level.upper())
    if not isinstance(level_int, int):
        # Unknown level name — ignore gracefully
        return

    # Persist so that loggers created *after* this call also pick it up
    os.environ["GINCLOUD_CONSOLE_LOG_LEVEL"] = level.upper()

    # ── Update StreamHandlers on regular (non-threaded) loggers ───────────
    for logger_instance in logging.Logger.manager.loggerDict.values():
        if not isinstance(logger_instance, logging.Logger):
            continue
        for handler in logger_instance.handlers:
            # StreamHandler but NOT a FileHandler
            if isinstance(handler, logging.StreamHandler) and not isinstance(
                handler, logging.FileHandler
            ):
                handler.setLevel(level_int)
        # Also lower the logger's own level if needed so records pass through
        if logger_instance.level > level_int:
            logger_instance.setLevel(level_int)

    # ── Update the thread-safe QueueListener's console handler ────────────
    if _thread_queue_listener is not None:
        for handler in _thread_queue_listener.handlers:
            if isinstance(handler, logging.StreamHandler) and not isinstance(
                handler, logging.FileHandler
            ):
                handler.setLevel(level_int)