import os
import requests
import datetime
import sys
from typing import Optional, List, Dict, Union, Tuple
import zipfile
import io
import shutil
from utils.logger import get_logger

# Global Variables
current_dir = os.getcwd()

# Custom Exceptions
class GitHubError(Exception):
    """Base exception for GitHub-related errors"""
    pass

class RepositoryNotFound(GitHubError):
    """Raised when a repository is not found"""
    def __init__(self, repo_name):
        self.repo_name = repo_name
        super().__init__(f"Repository '{repo_name}' not found")

class FileNotFound(GitHubError):
    """Raised when a file is not found in the repository"""
    def __init__(self, file_path, repo_name):
        self.file_path = file_path
        self.repo_name = repo_name
        super().__init__(f"File '{file_path}' not found in repository '{repo_name}'")

class AuthenticationError(GitHubError):
    """Raised when there are authentication issues"""
    def __init__(self, message="Authentication failed"):
        super().__init__(message)

class RateLimitExceeded(GitHubError):
    """Raised when GitHub API rate limit is exceeded"""
    def __init__(self, reset_time):
        self.reset_time = reset_time
        super().__init__(f"Rate limit exceeded. Try again after {reset_time}")

class InvalidToken(GitHubError):
    """Raised when the GitHub token is invalid"""
    def __init__(self):
        super().__init__("Invalid GitHub token provided")

# Logging Setup
logger = get_logger(name="utils.github")

# Custom exception handler
def custom_exception_handler(exc_type, exc_value, exc_traceback):
    logger.error("Uncaught exception", exc_info=(exc_type, exc_value, exc_traceback))

sys.excepthook = custom_exception_handler

class GitHubManager:
    """A class to manage GitHub repositories and files"""
    
    BASE_URL = "https://api.github.com"
    
    def __init__(self, token: Optional[str] = None, owner: Optional[str] = None, repo: Optional[str] = None):
        """
        Initialize the GitHub manager
        
        Args:
            token (str, optional): GitHub personal access token
            owner (str, optional): Repository owner
            repo (str, optional): Repository name
        """
        self.token = token or os.getenv('GITHUB_TOKEN')
        self.owner = owner or os.getenv('GITHUB_OWNER')
        self.repo = repo or os.getenv('GITHUB_REPO')
        self.headers = {
            'Accept': 'application/vnd.github.v3+json',
            'Authorization': f'token {self.token}' if self.token else None
        }
        
    def _make_request(self, method: str, endpoint: str, **kwargs) -> requests.Response:
        """
        Make a request to the GitHub API
        
        Args:
            method (str): HTTP method
            endpoint (str): API endpoint
            **kwargs: Additional arguments for requests
            
        Returns:
            requests.Response: API response
            
        Raises:
            GitHubError: For general GitHub API errors
            AuthenticationError: For authentication issues
            RateLimitExceeded: When rate limit is exceeded
        """
        url = f"{self.BASE_URL}{endpoint}"
        response = requests.request(method, url, headers=self.headers, **kwargs)
        
        if response.status_code == 401:
            raise AuthenticationError()
        elif response.status_code == 403 and 'rate limit' in response.text.lower():
            reset_time = datetime.datetime.fromtimestamp(int(response.headers.get('X-RateLimit-Reset', 0)))
            raise RateLimitExceeded(reset_time)
        elif response.status_code == 404:
            raise RepositoryNotFound(endpoint.split('/')[2])
        elif not response.ok:
            raise GitHubError(f"GitHub API error: {response.text}")
            
        return response

    def get_all_release_tags(self, owner: Optional[str] = None, repo: Optional[str] = None) -> List[str]:
        """
        Get all release tags from a repository
        
        Args:
            owner (str, optional): Repository owner
            repo (str, optional): Repository name
            
        Returns:
            List[str]: List of release tags
        """
        owner = owner or self.owner
        repo = repo or self.repo
        response = self._make_request('GET', f'/repos/{owner}/{repo}/releases')
        return [release['tag_name'] for release in response.json()]

    def get_latest_release_tag(self, owner: Optional[str] = None, repo: Optional[str] = None) -> Optional[str]:
        """
        Get the latest release tag
        
        Args:
            owner (str, optional): Repository owner
            repo (str, optional): Repository name
            
        Returns:
            Optional[str]: Latest release tag or None if no releases exist
        """
        owner = owner or self.owner
        repo = repo or self.repo
        response = self._make_request('GET', f'/repos/{owner}/{repo}/releases/latest')
        return response.json().get('tag_name')

    def get_separated_tags(self, tag_list: Optional[List[str]] = None) -> Dict[str, List[str]]:
        """
        Separate tags by prefix and sort versions
        
        Args:
            tag_list (List[str], optional): List of tags to process
            
        Returns:
            Dict[str, List[str]]: Dictionary of tags grouped by prefix
        """
        if tag_list is None:
            tag_list = self.get_all_release_tags()
            
        version_dict = {}
        for item in tag_list:
            prefix = ''.join(filter(str.isalpha, item))
            version = ''.join(filter(str.isdigit, item))
            
            if prefix not in version_dict:
                version_dict[prefix] = []
            version_dict[prefix].append(item)
            
        for prefix in version_dict:
            version_dict[prefix].sort()
        return version_dict

    def download_with_tag(self, tag_name: str, output_dir: str = current_dir) -> str:
        """
        Download a repository release by tag
        
        Args:
            tag_name (str): Release tag to download
            output_dir (str): Directory to save the release
            
        Returns:
            str: Path to downloaded release
        """
        logger.info(f"Starting download of source code from release {tag_name}...")
        try:
            release_url = f"/repos/{self.owner}/{self.repo}/zipball/refs/tags/{tag_name}"
            response = self._make_request('GET', release_url)
            
            if response.status_code == 200:
                with zipfile.ZipFile(io.BytesIO(response.content)) as zip_file:
                    zip_file.extractall(output_dir)
                    
                temp_dir_start = f"{self.owner}-{self.repo}"
                
                for directory in os.listdir(output_dir):
                    directory = os.path.join(output_dir, directory)
                    if directory.split(os.path.sep)[-1].startswith(temp_dir_start) and os.path.isdir(directory):
                        for item in os.listdir(directory):
                            source_item = os.path.join(directory, item)
                            destination_item = os.path.join(output_dir, item)
                            dest_dir = os.path.dirname(destination_item)
                            if not os.path.exists(dest_dir):
                                os.makedirs(dest_dir)
                            shutil.move(source_item, destination_item)
                        shutil.rmtree(directory)
                        
                logger.info(f"GitHub release '{tag_name}' downloaded and extracted to '{output_dir}'")
                return output_dir
            else:
                raise GitHubError(f"Failed to download release '{tag_name}'. Status code: {response.status_code}")
                
        except Exception as e:
            logger.error(f"Error downloading release: {str(e)}")
            raise

    def download_file(self, repo_file_path: str, reference: str, output_dir: str = current_dir) -> str:
        """
        Download a specific file from a repository
        
        Args:
            repo_file_path (str): Path to file in repository
            reference (str): Branch or tag reference
            output_dir (str): Directory to save the file
            
        Returns:
            str: Path to downloaded file
        """
        api_url = f"/repos/{self.owner}/{self.repo}/contents/{repo_file_path}?ref={reference}"
        response = self._make_request('GET', api_url)
        
        if response.status_code == 200:
            file_data = response.json()
            download_url = file_data["download_url"]
            file_name = os.path.join(output_dir, repo_file_path.split("/")[-1])
            
            os.makedirs(output_dir, exist_ok=True)
            file_response = requests.get(download_url)
            
            if file_response.status_code == 200:
                with open(file_name, "wb") as file:
                    file.write(file_response.content)
                logger.info(f"File '{file_name}' downloaded successfully")
                return file_name
            else:
                raise GitHubError(f"Failed to download file: {file_name}")
        else:
            raise GitHubError(f"Failed to fetch file information: {response.text}")

    def download_directory(self, repo_dir_path: str, reference: str, is_recursive: bool = False, output_dir: str = current_dir) -> str:
        """
        Download a directory from a repository
        
        Args:
            repo_dir_path (str): Path to directory in repository
            reference (str): Branch or tag reference
            is_recursive (bool): Whether to download recursively
            output_dir (str): Directory to save the files
            
        Returns:
            str: Path to downloaded directory
        """
        api_url = f"/repos/{self.owner}/{self.repo}/contents/{repo_dir_path}?ref={reference}"
        response = self._make_request('GET', api_url)
        
        if response.status_code == 200:
            data = response.json()
            
            if is_recursive:
                current_working_dir = os.path.join(*[part for part in repo_dir_path.split("/") 
                                                   if part not in getattr(self, '_temp_extra_path', [])])
            else:
                self._temp_extra_path = repo_dir_path.split("/")[:-1]
                current_working_dir = repo_dir_path.split("/")[-1]
                
            output_dirx = os.path.join(output_dir, current_working_dir)
            os.makedirs(output_dirx, exist_ok=True)
            
            if isinstance(data, list):
                for item in data:
                    if item["type"] == "file":
                        file_name = os.path.basename(item["path"])
                        file_url = item["download_url"]
                        file_response = requests.get(file_url, headers=self.headers, stream=True)
                        
                        if file_response.status_code == 200:
                            file_path = os.path.join(output_dirx, file_name)
                            with open(file_path, "wb") as file:
                                for chunk in file_response.iter_content(chunk_size=8192):
                                    file.write(chunk)
                        else:
                            logger.warning(f"Failed to download file: {file_name}")
                            
                    elif item["type"] == "dir":
                        subdirectory_path = item["path"]
                        self.download_directory(repo_dir_path=subdirectory_path, 
                                             reference=reference, 
                                             is_recursive=True, 
                                             output_dir=output_dir)
                        
                logger.info(f"Directory '{current_working_dir}' downloaded successfully")
                return output_dirx
            else:
                logger.warning(f"Directory '{current_working_dir}' is empty")
                return output_dirx
        else:
            raise GitHubError(f"Failed to fetch directory information: {response.text}")
    def download_repository(self, branch_name: str = 'main', output_dir: str = os.getcwd()) -> str:
        """
        Download entire repository as a zip file using a single request
        
        Args:
            branch_name (str): Branch to download, defaults to 'main'
            output_dir (str): Directory to save the files
            
        Returns:
            str: Path to downloaded repository directory
        """
        try:
            logger.info(f"Downloading repository {self.repo} branch {branch_name}")
            
            # Get zip archive URL for the branch
            zip_url = f"https://api.github.com/repos/{self.owner}/{self.repo}/zipball/{branch_name}"
            
            # Download the zip file
            response = requests.get(zip_url, headers=self.headers, stream=True)
            
            if response.status_code == 200:
                # Create a BytesIO object from the response content
                zip_content = io.BytesIO(response.content)
                
                # Create output directory if it doesn't exist
                os.makedirs(output_dir, exist_ok=True)
                
                # Extract the zip file
                with zipfile.ZipFile(zip_content) as zip_ref:
                    # Get the name of the root directory in the zip
                    root_dir = zip_ref.namelist()[0]
                    
                    # Extract all files
                    zip_ref.extractall(output_dir)
                    
                    # Rename extracted directory to repository name
                    extracted_path = os.path.join(output_dir, root_dir)
                    final_path = os.path.join(output_dir, self.repo)
                    
                    # Remove existing directory if it exists
                    if os.path.exists(final_path):
                        shutil.rmtree(final_path)
                    
                    # Rename directory
                    os.rename(extracted_path, final_path)
                
                logger.info(f"Repository downloaded successfully to {final_path}")
                return final_path
            else:
                raise GitHubError(f"Failed to download repository. Status code: {response.status_code}")
                
        except Exception as e:
            logger.error(f"An error occurred while downloading the repository: {e}")
            raise


    def create_release(self, branch_name: str, tag_name: Optional[str] = None, 
                      title: Optional[str] = None, note: Optional[str] = None,
                      draft: bool = False, prerelease: bool = False) -> Dict:
        """
        Create a new release
        
        Args:
            branch_name (str): Branch to create release from
            tag_name (str, optional): Tag name for the release
            title (str, optional): Release title
            note (str, optional): Release notes
            draft (bool): Whether release is a draft
            prerelease (bool): Whether release is a prerelease
            
        Returns:
            Dict: Release information
        """
        try:
            logger.info(f"Creating release for branch '{branch_name}' tag {tag_name}")
            
            release_url = f"/repos/{self.owner}/{self.repo}/releases"
            data = {
                "tag_name": tag_name or branch_name,
                "target_commitish": branch_name,
                "name": title or f"Release for {branch_name}",
                "body": note or f"Release for branch {branch_name}",
                "draft": draft,
                "prerelease": prerelease
            }
            
            response = self._make_request('POST', release_url, json=data)
            
            if response.status_code == 201:
                logger.info(f"Release for branch '{branch_name}' created successfully")
                return response.json()
            else:
                raise GitHubError(f"Failed to create release. Status code: {response.status_code}")
                
        except Exception as e:
            logger.error(f"An error occurred while creating the release: {e}")
            raise
