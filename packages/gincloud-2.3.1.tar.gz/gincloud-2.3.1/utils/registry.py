import winreg
from utils.logger import get_logger

logger = get_logger("utils.registry")


def get_registry_value(
    name,
    path,
    root=winreg.HKEY_LOCAL_MACHINE,
):
    """Retrieve a registry string value."""
    try:
        with winreg.OpenKey(root, path) as key:
            value, _ = winreg.QueryValueEx(key, name)
            return value
    except FileNotFoundError:
        return None
    except Exception as e:
        logger.error(f"Error accessing registry {path}\\{name}: {e}")
        return None


def set_registry_value(
    name,
    value,
    path,
    root=winreg.HKEY_LOCAL_MACHINE,
):
    """Set or update a registry string value."""
    try:
        with winreg.CreateKey(root, path) as key:
            winreg.SetValueEx(key, name, 0, winreg.REG_SZ, value)
            return True
    except Exception as e:
        logger.error(f"Error setting registry {path}\\{name}: {e}")
        return False
