import logging
import os
import sys
import platform

# Registry uninstall key written by InnoSetup
_REGISTRY_KEY = (
    r"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall"
    r"\{9AC51422-A176-4480-ACB8-34DAC611E25F}}_is1"
)

_log = logging.getLogger("utils.runtime")


def get_version(runtime_info: dict) -> str:
    """
    Resolve the authoritative GinCloud version based on *how* it is running.

    Priority rules
    ──────────────
    executable  → registry is the single source of truth (InnoSetup wrote it)
    package     → importlib.metadata is the single source of truth (pip/uv installed it)
    script      → importlib.metadata first, registry as fallback, else "unknown"

    If both sources are present but carry *different* versions, a WARNING is
    logged so the mismatch is visible without breaking anything.
    """
    mode = runtime_info.get("mode")

    # ── collect both sources without crashing ────────────────────────────────
    reg_version: str | None = None
    if sys.platform == "win32":
        try:
            from utils.registry import get_registry_value

            reg_version = get_registry_value("DisplayVersion", _REGISTRY_KEY)
        except Exception:
            pass

    pkg_version: str | None = None
    try:
        from importlib.metadata import version as _pkg_ver

        pkg_version = _pkg_ver("gincloud")
    except Exception:
        pass

    # ── warn on mismatch when both are present ────────────────────────────────
    if reg_version and pkg_version and reg_version != pkg_version:
        _log.warning(
            "Version mismatch detected — installer registry: %s, pip package: %s. "
            "Using %s version (mode=%s). "
            "Consider uninstalling the conflicting copy.",
            reg_version,
            pkg_version,
            "registry" if mode == "executable" else "package",
            mode,
        )

    # ── pick authoritative source by mode ────────────────────────────────────
    if mode == "executable":
        return reg_version or pkg_version or "unknown"
    elif mode == "package":
        return pkg_version or reg_version or "unknown"
    else:  # script — developer / CI context
        return pkg_version or reg_version or "unknown"


def get_runtime_info() -> dict:
    """
    Detect how GinCloud is running and collect path / install metadata.

    Returns a dict with:
        mode            "executable" | "package" | "script"
        path            Absolute path to the exe, installed module, or script
        install_date    YYYY-MM-DD string, or None
        install_location  Directory where GinCloud is installed, or None
        python_version  Python version string (omitted for frozen exe)
    """
    info: dict = {
        "mode": None,
        "path": None,
        "install_date": None,
        "install_location": None,
        "python_version": None,
    }

    # ── 1. Detect runtime mode ────────────────────────────────────────────────
    #
    # Detection order matters — each check must come BEFORE any that could
    # produce a false positive:
    #
    #   frozen     → PyInstaller sets sys.frozen; checked first, unambiguous
    #   .py suffix → argv[0] ends with .py  →  explicit script invocation
    #                (e.g. `python GinCloud.py`).  Must be checked BEFORE
    #                importlib.metadata, because uv/pip installs the package
    #                into the venv even during development, so metadata would
    #                exist and incorrectly report mode=package.
    #   else       → no .py suffix  →  invoked via an installed entry-point
    #                (`gincloud` console script).  Only NOW check metadata.
    #
    if getattr(sys, "frozen", False):
        # PyInstaller / cx_Freeze compiled executable
        info["mode"] = "executable"
        info["path"] = sys.executable
    else:
        info["python_version"] = platform.python_version()

        if sys.argv[0].endswith(".py"):
            # Explicit script invocation: python GinCloud.py  /  uv run python GinCloud.py
            info["mode"] = "script"
            info["path"] = os.path.abspath(sys.argv[0])
        else:
            # Invoked via installed entry-point — safe to trust importlib.metadata
            try:
                from importlib.metadata import version as _pkg_ver, files as _pkg_files

                _pkg_ver("gincloud")  # raises PackageNotFoundError if not installed
                info["mode"] = "package"
                # Locate GinCloud.py inside the installed package
                pkg_files = _pkg_files("gincloud") or []
                for f in pkg_files:
                    if f.name == "GinCloud.py":
                        info["path"] = str(f.locate().resolve())
                        break
                if info["path"] is None:
                    info["path"] = os.path.abspath(sys.argv[0])
            except Exception:
                # Entry-point exists but package metadata is broken — treat as script
                info["mode"] = "script"
                info["path"] = os.path.abspath(sys.argv[0])

    # ── 2. Pull install metadata from the Windows registry ───────────────────
    if sys.platform == "win32":
        try:
            from utils.registry import get_registry_value

            raw_date = get_registry_value("InstallDate", _REGISTRY_KEY)
            if raw_date and len(raw_date) == 8 and raw_date.isdigit():
                info["install_date"] = f"{raw_date[:4]}-{raw_date[4:6]}-{raw_date[6:]}"

            reg_location = get_registry_value("InstallLocation", _REGISTRY_KEY)
            if reg_location and info["mode"] == "executable":
                info["install_location"] = reg_location.rstrip("\\")
        except Exception:
            pass  # registry unavailable — non-fatal

    # ── 3. Fallback install_location from path ────────────────────────────────
    if info["install_location"] is None and info["path"]:
        info["install_location"] = os.path.dirname(info["path"])

    return info


def format_startup_banner(version: str, runtime: dict) -> str:
    """
    Build a single-line startup context string for the first log entry.

    Example outputs:
        GinCloud v2.2.1  |  mode=executable  |  path=C:\\Program Files\\GinCloud\\GinCloud.exe
        GinCloud v2.2.1  |  mode=package     |  python=3.12.3  |  path=...
    """
    parts = [f"GinCloud v{version}", f"mode={runtime['mode']}"]

    if runtime.get("python_version"):
        parts.append(f"python={runtime['python_version']}")

    if runtime.get("path"):
        parts.append(f"path={runtime['path']}")

    return "  |  ".join(parts)


def format_version_block(version: str, runtime: dict) -> str:
    """
    Build the multi-line string shown by the `version` command.
    """
    lines = [
        f"GinCloud  v{version}",
        f"  Runtime mode    : {runtime['mode']}",
        f"  Executable path : {runtime['path'] or 'unknown'}",
    ]

    if runtime.get("python_version"):
        lines.append(f"  Python version  : {runtime['python_version']}")

    lines.append(f"  Install location: {runtime['install_location'] or 'unknown'}")
    lines.append(f"  Install date    : {runtime['install_date'] or 'unknown'}")
    lines.append(
        f"  Platform        : {platform.system()} {platform.release()} "
        f"({platform.machine()})"
    )

    return "\n".join(lines)
