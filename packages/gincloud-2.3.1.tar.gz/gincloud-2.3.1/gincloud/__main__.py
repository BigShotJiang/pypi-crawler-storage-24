"""
Entry point for `python -m gincloud`.
Imports the Typer app from GinCloud.py and invokes it.
"""
from GinCloud import RootCommand


def main():
    RootCommand()


if __name__ == "__main__":
    main()
