from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.subscription import SubscriptionClient
from typing import List, Dict, Optional
from azure.mgmt.resourcegraph import ResourceGraphClient
from azure.mgmt.resourcegraph.models import QueryRequest
from gincloud.azure import get_tenant_name_from_id

def get_resource_details_with_resource_graph(
    credential,
    subscription_ids: Optional[List[str]] = None,
    tag_key_prefix: str = "tag_"
) -> List[Dict]:
    """
    Fetch Azure resources across subscriptions using Resource Graph (with paging).
    Returns details in the same schema as the original resource_client-based function.
    """

    # --- Get subscriptions if not provided ---
    subscription_client = SubscriptionClient(credential)
    if not subscription_ids:
        subscriptions = subscription_client.subscriptions.list()
        subscription_ids = [sub.subscription_id for sub in subscriptions]

    # Build lookup: subscription_id -> (tenant_id, subscription_name)
    sub_lookup = {}
    for sub in subscription_ids:
        sub_info = subscription_client.subscriptions.get(sub)
        sub_lookup[sub] = {
            "tenant_id": sub_info.tenant_id,
            "tenant_domain": get_tenant_name_from_id(credential, sub_info.tenant_id),
            "subscription_name": sub_info.display_name,
        }

    # --- Initialize Resource Graph Client ---
    rg_client = ResourceGraphClient(credential)

    # --- Resource Graph query ---
    query = """
    Resources
    | project
        id,
        name,
        type,
        location,
        subscriptionId,
        resourceGroup,
        sku = tostring(sku.name),
        managedBy,
        tags,
        properties
    """

    resource_details = []
    skip_token = None

    while True:
        request = QueryRequest(
            subscriptions=subscription_ids,
            query=query,
            options={"$skipToken": skip_token} if skip_token else None
        )

        response = rg_client.resources(request)

        for item in response.data:
            sub_info = sub_lookup.get(item["subscriptionId"], {})

            # Flatten tags
            tags = item.get("tags", {}) or {}
            flattened_tags = {f"{tag_key_prefix}{k}": v for k, v in tags.items()}

            # Handle SKU (generic + VM-specific fallback)
            sku = item.get("sku")
            if not sku and item.get("type", "").lower() == "microsoft.compute/virtualmachines":
                sku = (
                    item.get("properties", {})
                    .get("hardwareProfile", {})
                    .get("vmSize", "N/A")
                )

            # Build resource info
            resource_info = {
                "Location": item.get("location"),
                "Tenant": sub_info.get("tenant_domain", "N/A"),
                "SubscriptionName": sub_info.get("subscription_name", "N/A"),
                "SubscriptionId": item.get("subscriptionId"),
                "ResourceGroup": item.get("resourceGroup", "N/A"),
                "ResourceCategory": "/".join(item["type"].split("/")[:-1])
                                    if "/" in item["type"] else item["type"],
                "ResourceType": item["type"].split("/")[-1]
                                if "/" in item["type"] else item["type"],
                "StockKeepingUnit": sku or "N/A",
                "ResourceId": item.get("id"),
                "ResourceName": item.get("name"),
                "ManagedBy": item.get("managedBy", "N/A") or "N/A",
            }

            resource_info.update(flattened_tags)
            resource_details.append(resource_info)

        # Check if more pages exist
        if getattr(response, "skip_token", None):
            skip_token = response.skip_token
        else:
            break

    return resource_details


def get_resource_details(credential, subscription_ids: Optional[List[str]] = None, tag_key_prefix : str = 'tag_') -> List[Dict]:
    """
    Fetch Azure resources across multiple or all subscriptions with detailed information.
    
    If subscription_ids is None, it fetches resources for all available subscriptions.

    Args:
        credential: Azure credential object.
        subscription_ids (List[str], optional): List of Azure subscription IDs. Defaults to None (fetches all subscriptions).

    Returns:
        List[Dict]: List of dictionaries containing detailed information for each resource.
    """
    
    # Initialize Subscription Client
    subscription_client = SubscriptionClient(credential)
    
    # Fetch all subscriptions if none provided
    if not subscription_ids:
        subscriptions = subscription_client.subscriptions.list()
        subscription_ids = [sub.subscription_id for sub in subscriptions]

    resource_details = []
    
    for subscription_id in subscription_ids:
        try:
            # Get Subscription Details
            subscription_info = subscription_client.subscriptions.get(subscription_id)
            subscription_name = subscription_info.display_name
            tenant_id = subscription_info.tenant_id  # Get Tenant ID
            tenant_domain = get_tenant_name_from_id(credential, tenant_id)  # Fetch Tenant Name using helper function
            # tenant_name = f"Tenant-{tenant_id}"  # Placeholder, as Azure Graph API is required for actual Tenant Name

            # Initialize Resource Client
            resource_client = ResourceManagementClient(credential, subscription_id)

            # Fetch all resources for the subscription
            resources = resource_client.resources.list()
            
            for resource in resources:
                # Flatten tags for Pandas DataFrame compatibility
                tags = resource.tags if resource.tags else {}
                flattened_tags = {f"{tag_key_prefix}{key}": value for key, value in tags.items()}

                # Resource Information
                resource_info = {
                    "Location": resource.location,
                    "Tenant": tenant_domain,
                    "SubscriptionName": subscription_name,
                    "SubscriptionId": subscription_id,
                    "ResourceGroup": resource.id.split("/")[4] if "/resourceGroups/" in resource.id else "N/A",
                    "ResourceCategory": "/".join(resource.type.split("/")[:-1]) if "/" in resource.type else resource.type,
                    "ResourceType": resource.type.split("/")[-1] if "/" in resource.type else resource.type,
                    "StockKeepingUnit": resource.sku.name if resource.sku else "N/A",
                    "ResourceId": resource.id,
                    "ResourceName": resource.name,
                    "ManagedBy": resource.managed_by if resource.managed_by else "N/A",
                }

                # Merge flattened tags
                resource_info.update(flattened_tags)

                resource_details.append(resource_info)

        except Exception as e:
            print(f"Error fetching resources for subscription {subscription_id}: {e}")

    return resource_details
