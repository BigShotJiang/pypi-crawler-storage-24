"""
Azure RunCommand — execute scripts on VMs asynchronously.

Concurrency is driven by ``asyncio`` with the Azure async compute SDK.
A single ``asyncio.Semaphore`` bounds how many VMs run at the same time,
and ``asyncio.wait_for`` provides **real** cancellation on timeout (no
zombie threads).

Public API
----------
execute_run_command(...)  -> list[dict]
detect_script_type(...)   -> str
"""
from __future__ import annotations

import asyncio
import os
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional, Tuple

import typer
from azure.core.exceptions import AzureError, HttpResponseError, ResourceNotFoundError
from azure.mgmt.compute import ComputeManagementClient
from azure.mgmt.compute.aio import ComputeManagementClient as AsyncComputeClient

from utils import interactive_select_from_list
from utils.logger import get_logger

logger = get_logger("gincloud.azure.runcommand")


# ---------------------------------------------------------------------------
# Async credential adapter
# ---------------------------------------------------------------------------

class _AsyncCredentialAdapter:
    """Wrap a sync ``TokenCredential`` so it works with async Azure clients."""

    def __init__(self, sync_credential: Any) -> None:
        self._sync = sync_credential

    async def get_token(self, *scopes: str, **kwargs: Any):
        return self._sync.get_token(*scopes, **kwargs)

    async def close(self) -> None:
        fn = getattr(self._sync, "close", None)
        if callable(fn):
            fn()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *args):
        await self.close()


# ---------------------------------------------------------------------------
# Result dataclass
# ---------------------------------------------------------------------------

@dataclass
class _VMRunResult:
    vm: str
    resource_group: str
    invoke_status: str           # success | failed
    invoke_message: str
    execution_status: str        # success | warning | error | unknown
    execution_std_output: str
    execution_error_output: str
    poll_timed_out: bool = False

    @property
    def ok(self) -> bool:
        return (
            self.invoke_status == "success"
            and self.execution_status in ("success", "warning")
        )

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d.pop("poll_timed_out")
        return d


# ---------------------------------------------------------------------------
# Public entry point (sync — callers need zero changes)
# ---------------------------------------------------------------------------

def execute_run_command(
    credential: Any,
    subscription_id: str,
    filter_by: List[str],
    filter_value: Optional[str],
    script: str,
    parameters: Optional[str] = None,
    max_workers: int = 10,
    show_progress: bool = True,
    poll_timeout: int = 300,
) -> List[Dict[str, Any]]:
    """
    Run a script on every VM that matches the filter.

    Internally launches an ``asyncio`` event loop; the caller stays sync.
    """
    script_content, script_type = _prepare_script(script)
    param_list = _parse_parameters(parameters)

    # Sync client — used only for the initial VM listing.
    compute = ComputeManagementClient(credential, subscription_id)
    vms = _filter_vms(compute, filter_by, filter_value)
    if not vms:
        logger.warning("No VMs matched the filter — nothing to execute.")
        return []

    concurrency = max(max_workers, 1)
    logger.info(
        "Dispatching RunCommand to %d VM(s)  "
        "[concurrency=%d | timeout=%ds | type=%s].",
        len(vms), concurrency, poll_timeout, script_type,
    )

    results = asyncio.run(
        _dispatch(
            credential, subscription_id, vms,
            script_type, script_content, param_list,
            concurrency, show_progress, poll_timeout,
        )
    )

    _log_summary(results)
    return [r.to_dict() for r in results]


# ---------------------------------------------------------------------------
# Async core
# ---------------------------------------------------------------------------

async def _dispatch(
    credential: Any,
    subscription_id: str,
    vms: List[Dict[str, str]],
    script_type: str,
    script_content: str,
    param_list: List[Dict[str, str]],
    concurrency: int,
    show_progress: bool,
    poll_timeout: int,
) -> List[_VMRunResult]:
    """Fan-out to all VMs with bounded concurrency, collect results."""
    sem = asyncio.Semaphore(concurrency)
    cred = _AsyncCredentialAdapter(credential)

    try:
        async with AsyncComputeClient(cred, subscription_id) as client:
            tasks = [
                _run_one(client, vm, script_type, script_content,
                         param_list, sem, poll_timeout)
                for vm in vms
            ]
            results: List[_VMRunResult] = []

            if show_progress:
                with typer.progressbar(length=len(tasks),
                                       label="RunCommand") as bar:
                    for coro in asyncio.as_completed(tasks):
                        results.append(await coro)
                        bar.update(1)
            else:
                for coro in asyncio.as_completed(tasks):
                    r = await coro
                    _log_vm_result(r)
                    results.append(r)
    finally:
        await cred.close()

    return results


async def _run_one(
    client: AsyncComputeClient,
    vm: Dict[str, str],
    script_type: str,
    script_content: str,
    param_list: List[Dict[str, str]],
    sem: asyncio.Semaphore,
    poll_timeout: int,
) -> _VMRunResult:
    """Acquire the semaphore, then execute on a single VM."""
    async with sem:
        return await _execute_on_vm(
            client, vm, script_type, script_content,
            param_list, poll_timeout=poll_timeout,
        )


# ---------------------------------------------------------------------------
# Per-VM execution
# ---------------------------------------------------------------------------

def _fail(name: str, rg: str, msg: str, **kw) -> _VMRunResult:
    """Shorthand for returning a failed result."""
    return _VMRunResult(
        vm=name, resource_group=rg,
        invoke_status="failed", invoke_message=msg,
        execution_status=kw.get("exec_status", "error"),
        execution_std_output=kw.get("stdout", ""),
        execution_error_output=kw.get("stderr", ""),
        poll_timed_out=kw.get("timed_out", False),
    )


async def _execute_on_vm(
    client: AsyncComputeClient,
    vm: Dict[str, str],
    script_type: str,
    script_content: str,
    param_list: List[Dict[str, str]],
    *,
    poll_timeout: int = 300,
) -> _VMRunResult:
    """
    Invoke RunCommand on one VM.

    ``asyncio.wait_for`` wraps the poller so that a genuine cancellation
    happens on timeout — no zombie coroutines left behind.
    """
    rg, name = vm["resource_group"], vm["name"]
    std_out = err_out = ""

    try:
        logger.debug("[VM: %s] Submitting RunCommand (rg=%s, type=%s).",
                     name, rg, script_type)

        poller = await client.virtual_machines.begin_run_command(
            rg, name,
            {
                "command_id": script_type,
                "script": [script_content],
                "parameters": param_list or [],
            },
        )

        # -- poll with real cancellation on timeout -------------------------
        try:
            raw = await asyncio.wait_for(poller.result(), timeout=poll_timeout)
        except asyncio.TimeoutError:
            logger.warning("[VM: %s] Polling timed out after %ds.", name, poll_timeout)
            return _fail(name, rg,
                         f"Polling timed out after {poll_timeout}s.",
                         exec_status="unknown", timed_out=True)

        # -- parse stdout / stderr ------------------------------------------
        std_out, err_out = _extract_outputs(raw.as_dict(), vm_name=name)
        status = _classify_execution(stderr=err_out)

        logger.debug("[VM: %s] Done — status=%s, stdout=%d chars, stderr=%d chars.",
                     name, status, len(std_out), len(err_out))

        return _VMRunResult(
            vm=name, resource_group=rg,
            invoke_status="success",
            invoke_message="RunCommand completed.",
            execution_status=status,
            execution_std_output=std_out,
            execution_error_output=err_out,
        )

    # -- error hierarchy (most specific first) ------------------------------
    except ResourceNotFoundError:
        msg = f"VM '{name}' not found in RG '{rg}' (deleted?)."
        logger.error("[VM: %s] %s", name, msg)
        return _fail(name, rg, msg)

    except HttpResponseError as exc:
        msg = f"Azure API error -- HTTP {exc.status_code}: {exc.message}"
        logger.error("[VM: %s] %s", name, msg)
        return _fail(name, rg, msg)

    except AzureError as exc:
        msg = f"Azure SDK error: {exc}"
        logger.error("[VM: %s] %s", name, msg, exc_info=True)
        return _fail(name, rg, msg)

    except asyncio.CancelledError:
        logger.warning("[VM: %s] Task cancelled.", name)
        return _fail(name, rg, "Task cancelled.",
                     exec_status="unknown", stdout=std_out, stderr=err_out)

    except Exception as exc:
        msg = f"Unexpected error: {exc}"
        logger.exception("[VM: %s] %s", name, msg)
        return _fail(name, rg, msg, stdout=std_out, stderr=err_out)


# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------

def _classify_execution(*, stderr: str) -> str:
    if not stderr:
        return "success"
    lo = stderr.lower()
    if any(k in lo for k in ("error", "exception", "fail", "cannot", "access denied")):
        return "error"
    if any(k in lo for k in ("warning", "verbose", "information")):
        return "warning"
    return "error"                    # unknown content — conservative


def _extract_outputs(
    result_dict: Dict[str, Any], *, vm_name: str = "",
) -> Tuple[str, str]:
    """Parse stdout / stderr from the Azure RunCommand response payload."""
    stdout_parts: List[str] = []
    stderr_parts: List[str] = []
    try:
        for entry in result_dict.get("value", []):
            code = entry.get("code", "").lower()
            msg = entry.get("message", "")
            if "stdout" in code:
                stdout_parts.append(msg)
            elif "stderr" in code:
                stderr_parts.append(msg)
        if not stdout_parts and not stderr_parts:
            logger.debug("[VM: %s] Response contained no output streams.", vm_name)
    except Exception as exc:
        logger.error("[VM: %s] Failed to parse output: %s", vm_name, exc)
        stderr_parts.append(f"[output parse error: {exc}]")
    return "\n".join(stdout_parts).strip(), "\n".join(stderr_parts).strip()


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

_BAR = "-" * 72                      # ASCII-safe separator


def _log_vm_result(result: _VMRunResult) -> None:
    lines = [
        _BAR,
        f"  VM     : {result.vm}  (RG: {result.resource_group})",
        f"  Status : invoke={result.invoke_status.upper()}"
        f"  exec={result.execution_status.upper()}",
    ]
    if result.invoke_status != "success" or result.poll_timed_out:
        lines.append(f"  Reason : {result.invoke_message}")
    else:
        if result.execution_error_output:
            lines.append("  STDERR :")
            lines.extend(f"    {ln}"
                         for ln in result.execution_error_output.splitlines())
        if result.execution_std_output:
            lines.append("  STDOUT :")
            lines.extend(f"    {ln}"
                         for ln in result.execution_std_output.splitlines())
        else:
            lines.append("  STDOUT : (no output)")
    lines.append(_BAR)

    block = "\n".join(lines)
    (logger.info if result.ok else logger.error)(block)


def _log_summary(results: List[_VMRunResult]) -> None:
    total     = len(results)
    succeeded = sum(1 for r in results if r.ok)
    failed    = total - succeeded
    timed_out = sum(1 for r in results if r.poll_timed_out)

    logger.info("RunCommand complete -- total=%d  succeeded=%d  failed=%d  timed_out=%d.",
                total, succeeded, failed, timed_out)

    for r in results:
        if not r.ok:
            logger.warning("  [x]  %-40s  rg=%-30s  invoke=%-8s  exec=%s",
                           r.vm, r.resource_group, r.invoke_status, r.execution_status)
            if r.invoke_message and r.invoke_message != "RunCommand completed.":
                logger.warning("       \\-- %s", r.invoke_message)


# ---------------------------------------------------------------------------
# Script helpers
# ---------------------------------------------------------------------------

def _prepare_script(script: str) -> Tuple[str, str]:
    if os.path.isfile(script):
        with open(script, "r", encoding="utf-8") as fh:
            content = fh.read().strip()
        stype = detect_script_type(content, path=script)
        logger.info("Script loaded from file: %s  (type=%s, %d chars).",
                     script, stype, len(content))
    else:
        content = script.strip()
        stype = detect_script_type(content)
        logger.info("Inline script (type=%s, %d chars).", stype, len(content))
    if not content:
        raise ValueError("Script content is empty — nothing to execute.")
    return content, stype


def _parse_parameters(parameters: Optional[str]) -> List[Dict[str, str]]:
    """
    Parse comma-separated parameters into Azure RunCommandInputParameter list.

    Supported formats:
      - Key=Value   → {"name": "Key", "value": "Value"}
      - SwitchName  → {"name": "SwitchName", "value": "true"}  (bare token = switch)
    """
    if not parameters:
        return []
    result: List[Dict[str, str]] = []
    for tok in parameters.split(","):
        tok = tok.strip()
        if not tok:
            continue
        if "=" in tok:
            k, v = tok.split("=", 1)
            result.append({"name": k.strip(), "value": v.strip()})
        else:
            # Bare token → treat as a PowerShell switch (value="true")
            result.append({"name": tok, "value": "true"})
    return result


# ---------------------------------------------------------------------------
# VM filtering
# ---------------------------------------------------------------------------

def _filter_vms(
    client: ComputeManagementClient,
    filter_by: List[str],
    filter_value: Optional[str] = None,
) -> List[Dict[str, str]]:
    values = [v.strip() for v in (filter_value or "").split(",") if v.strip()]

    logger.info("Fetching VM list (filter_by=%s, values=%s)...",
                filter_by, values or "n/a")

    try:
        all_vms = list(client.virtual_machines.list_all())
    except AzureError as exc:
        logger.error("Failed to enumerate VMs: %s", exc)
        raise

    logger.debug("Subscription contains %d VM(s) total.", len(all_vms))

    if "all" in filter_by:
        return [{"name": vm.name,
                 "resource_group": _rg_from_id(vm.id)} for vm in all_vms]

    if "selective" in filter_by or "select" in filter_by:
        all_vms = _interactive_vm_selection(all_vms)

    matched = [
        {"name": vm.name, "resource_group": _rg_from_id(vm.id)}
        for vm in all_vms
        if _vm_matches(vm, rg=_rg_from_id(vm.id),
                       filter_by=filter_by, values=values)
    ]
    logger.info("Filter matched %d / %d VM(s).", len(matched), len(all_vms))
    return matched


def _rg_from_id(resource_id: str) -> str:
    try:
        return resource_id.split("/")[4]
    except (IndexError, AttributeError):
        return ""


def _interactive_vm_selection(all_vms: list) -> list:
    rg_opts = sorted({_rg_from_id(vm.id) for vm in all_vms})
    sel_rgs = interactive_select_from_list(data=rg_opts,
                                           title="Select Resource Group(s):")
    in_rg = [vm for vm in all_vms if _rg_from_id(vm.id) in sel_rgs]
    sel_names = interactive_select_from_list(
        data=[vm.name for vm in in_rg],
        title=f"Select VM(s) under: {', '.join(sel_rgs)}",
    )
    return [vm for vm in in_rg if vm.name in sel_names]


def _vm_matches(
    vm: Any, rg: str,
    filter_by: List[str], values: List[str],
) -> bool:
    tags = vm.tags or {}

    if "vm" in filter_by and values:
        if vm.name.lower() not in {v.lower() for v in values}:
            return False

    if "rg" in filter_by and values:
        if rg.lower() not in {v.lower() for v in values}:
            return False

    if "tag" in filter_by and values:
        for tok in values:
            sep = "=" if "=" in tok else (":" if ":" in tok else None)
            if sep:
                key, want = (s.strip() for s in tok.split(sep, 1))
                got = (tags.get(key) or "").lower()
                if got != want.lower():
                    return False
            else:
                if tok.strip() not in tags:
                    return False
    return True


# ---------------------------------------------------------------------------
# Script type detection
# ---------------------------------------------------------------------------

_PS_KEYWORDS = frozenset({
    "write-host", "write-output", "get-item", "set-item",
    "invoke-", "param(", "$env:", "get-process", "get-service",
    "new-item", "remove-item", "get-content", "set-content",
})

# Patterns that identify a shell shebang
_SHELL_SHEBANG_HINTS = ("bash", "/sh", "env sh")


def detect_script_type(content: str, path: Optional[str] = None) -> str:
    """
    Determine the Azure RunCommand script type.

    Detection order:
      1. File extension  (.ps1 -> PowerShell,  .sh/.bash -> Shell)
      2. Shebang line    (#!/bin/bash, #!/bin/sh, #!/usr/bin/env sh)
      3. PowerShell keyword scan
      4. Default: PowerShell  (safe default — most Azure VMs are Windows)
    """
    if path:
        ext = os.path.splitext(path.lower())[1]
        if ext == ".ps1":
            return "RunPowerShellScript"
        if ext in (".sh", ".bash"):
            return "RunShellScript"

    head = content[:512].lower()

    if head.startswith("#!"):
        first_line = head.splitlines()[0]
        if any(hint in first_line for hint in _SHELL_SHEBANG_HINTS):
            return "RunShellScript"

    if any(kw in head for kw in _PS_KEYWORDS):
        return "RunPowerShellScript"

    return "RunPowerShellScript"
