import requests
import time
import json
from datetime import datetime
from azure.mgmt.costmanagement import CostManagementClient
from azure.core.exceptions import HttpResponseError
from azure.mgmt.subscription import SubscriptionClient
from typing import List, Dict,Any
from azure.mgmt.consumption import ConsumptionManagementClient
from utils.logger import get_logger
from gincloud.azure import get_tenant_domain_using_credential
from azure.mgmt.costmanagement.models import (
    QueryDefinition,
    QueryTimePeriod,
    QueryDataset,
    QueryAggregation,
    QueryGrouping,
)


# Get a logger specific to this module (gincloud.azure.report.cost)
logger = get_logger("gincloud.azure.cost")


def get_azure_sku_pricing(
    currency_code: str = "INR",
    filter_conditions: list[str] = None,
    credential=None,
    max_retries: int = 3,
    retry_delay: int = 5,
) -> list[dict]:
    """
    Fetch Azure SKU pricing details from the Retail Prices API.

    Args:
        currency_code (str): Currency code for the pricing data (default: 'USD').
        filter_conditions (list[str] | None): List of OData filter parts to be joined with 'and'.
                                              If None or empty, fetches all SKUs for the given currency.
        credential: Azure credential object for authentication.
        max_retries (int): Number of retries for network errors.
        retry_delay (int): Seconds to wait before retrying.

    Returns:
        list[dict]: List of dictionaries containing complete SKU pricing data.
    """
    try:
        logger.info("Starting Azure SKU pricing fetch process...")
        logger.debug(f"Currency Code: {currency_code}")
        logger.debug(f"Provided Filters: {filter_conditions}")

        # Build filter part of query
        if filter_conditions:
            filter_query = " and ".join(filter_conditions)
            filter_param = f"&$filter={filter_query}"
        else:
            filter_param = ""

        # Validate Azure credentials (optional check)
        if credential:
            SubscriptionClient(credential)

        # Base API URL
        api_url = f"https://prices.azure.com/api/retail/prices?currencyCode='{currency_code}'{filter_param}"

        all_sku_pricing = []
        page_counter = 0

        while api_url:
            retries = 0
            while retries <= max_retries:
                try:
                    logger.debug(f"Requesting data from: {api_url}")
                    response = requests.get(api_url, timeout=30)
                    response.raise_for_status()
                    break  # Exit retry loop if successful
                except requests.exceptions.ConnectionError:
                    retries += 1
                    logger.warning(
                        f"Connection error. Retry {retries}/{max_retries} after {retry_delay}s..."
                    )
                    time.sleep(retry_delay)
                except requests.exceptions.Timeout:
                    retries += 1
                    logger.warning(
                        f"Request timed out. Retry {retries}/{max_retries} after {retry_delay}s..."
                    )
                    time.sleep(retry_delay)

            else:
                logger.error(f"Failed to retrieve data after {max_retries} retries.")
                raise requests.RequestException(
                    "Max retries reached for Azure Pricing API."
                )

            # Parse JSON
            json_data = response.json()
            page_counter += 1

            items = json_data.get("Items", [])
           
            logger.info(
                f"Page {page_counter}: Already had {len(all_sku_pricing)} items, "
                f"retrieved {len(items)} more, "
                f"new total will be {len(all_sku_pricing) + len(items)}."
            )

            all_sku_pricing.extend(items)

            # Get next page link
            api_url = json_data.get("NextPageLink")

        logger.info(f"Total SKUs retrieved: {len(all_sku_pricing)}")
        return all_sku_pricing

    except requests.RequestException as http_err:
        logger.error(f"HTTP request failed: {http_err}", exc_info=True)
        raise
    except Exception as err:
        logger.error(f"Unexpected error occurred: {err}", exc_info=True)
        raise



def get_cost_data(credential, subscription_id, start_date, end_date,granularity='None'):
    """
    Query Azure cost data grouped by resource.

    Parameters:
        credential: Azure credential object.
        subscription_id (str): Azure subscription ID.
        start_date (str): Start date for the cost query in 'yyyy-mm-dd' format.
        end_date (str): End date for the cost query in 'yyyy-mm-dd' format.

    Returns:
        list[dict]: A list of dictionaries containing resource ID, cost, and currency.
    """
    cost_client = CostManagementClient(credential)

    # Convert the start and end dates to the proper ISO 8601 datetime format with UTC timezone
    try:
        start_date_obj = datetime.strptime(start_date, "%Y-%m-%d")
        end_date_obj = datetime.strptime(end_date, "%Y-%m-%d")
        
        # Add time part to make it a full ISO 8601 datetime string
        start_date_iso = start_date_obj.strftime("%Y-%m-%dT00:00:00Z")
        end_date_iso = end_date_obj.strftime("%Y-%m-%dT23:59:59Z")
    except ValueError as ve:
        logger.error(f"Error parsing date: {str(ve)}")
        return []
    # Ensure valid granularity
    valid_granularities = ['None', 'Daily', 'Monthly']
    if granularity not in valid_granularities:
        logger.error(f"Invalid granularity: {granularity}. Must be one of {valid_granularities}.")
        return []
    query_definition = {
        "type": "Usage",
        "timeframe": "Custom",
        "timePeriod": {"from": start_date_iso, "to": end_date_iso},
        "dataset": {
            "granularity": granularity,
            "aggregation": {
                "totalCost": {"name": "PreTaxCost", "function": "Sum"}
            },
            "grouping": [{"type": "Dimension", "name": "ResourceId"},{"type": "Dimension", "name": "CustomerName"},{"type": "Dimension", "name": "SubscriptionName"}]
        }
    }

    try:
        response = cost_client.query.usage(
            scope=f"/subscriptions/{subscription_id}",
            parameters=query_definition
        )
        # Extract column names from response
        column_names = [col.name for col in response.columns]

        # Convert rows to a list of dictionaries
        response_rows = [dict(zip(column_names, row)) for row in response.rows]
        # Including or modifying data in the response with calculative field.
        final_data = [
                    {       
                        'Tenant': entry.pop("CustomerName","UnKnown Tenant"),
                        'SubscriptionName' : entry.pop("SubscriptionName","UnKnown SubscriptionName"),
                        'ResourceGroupName': entry['ResourceId'].split('/')[4],
                        'ResourceCategory': entry['ResourceId'].split('/')[6],
                        'ResourceType': entry['ResourceId'].split('/')[7],
                        'ResourceName' : entry['ResourceId'].split('/')[8],
                        'Cost': entry.pop("PreTaxCost",None),
                        **entry
                    }
                   
                    for entry in response_rows
                ]
        
        return final_data
    except Exception as e:
        logger.error(f"Error querying cost data: {str(e)}")
        return []




def get_cost_details_data(
    credential,
    subscription_id,
    start_date,
    end_date,
    granularity='None',
    group_by=None
):
    """
    Query Azure cost data grouped by specified dimensions.

    Parameters:
        credential: Azure credential object.
        subscription_id (str): Azure subscription ID.
        start_date (str): Start date for the cost query in 'yyyy-mm-dd' format.
        end_date (str): End date for the cost query in 'yyyy-mm-dd' format.
        group_by (list): A list of dimensions to group the cost data by (max 15).

    Returns:
        list[dict]: A list of dictionaries containing cost details for each grouping.
    """
    _tenant_domain = get_tenant_domain_using_credential(credential=credential)
    
   
    cost_client = CostManagementClient(credential)
    # Ensure group_by is a list
    group_by = list(group_by) if group_by else []
    # Ensure group_by does not exceed 11  dimensions
    if len(group_by) > 11:
        group_by = group_by[:11]
        logger.warning(f"group_by list exceeds 11 dimensions. Truncating to first 11. Now group_by list: {group_by}")

    predefined_dimensions = ["ResourceId","UnitOfMeasure","SubscriptionName"] 
    # Ensure predefined dimensions are included
    for dim in predefined_dimensions:
        if dim not in group_by:
            group_by.insert(0, dim)
    logger.debug(f"Final group_by list: {group_by}")


  
    grouping_definitions = [
        QueryGrouping(name=dimension, type="Dimension") for dimension in group_by
    ]

    start_date_iso = f"{start_date}T00:00:00Z"
    end_date_iso = f"{end_date}T23:59:59Z"

    query_definition = QueryDefinition(
        type="Usage",
        timeframe="Custom",
        time_period=QueryTimePeriod(from_property=start_date_iso, to=end_date_iso),
        dataset=QueryDataset(
            granularity=granularity,
            aggregation={
                "totalCost": QueryAggregation(name="PreTaxCost", function="Sum"),
                "usageQuantity": QueryAggregation(name="UsageQuantity", function="Sum")
            },
            grouping=grouping_definitions
        )
    )

    scope = f"/subscriptions/{subscription_id}"
    results = []

    # First request
    try:
        response = cost_client.query.usage(scope=scope, parameters=query_definition)
        logger.debug("azure cost data initial fetching is done successfully")

    except HttpResponseError as e:
        if e.status_code == 429:
            logger.warning("Fall Under Azure SDK rate limit (http_code:429). Waiting for 300 Sec and Retry...")
            time.sleep(300)
            try:
                response = cost_client.query.usage(scope=scope, parameters=query_definition)
                logger.debug("After waiting for 300 Sec and retry azure cost data fetching is done successfully")

            except Exception as e:
                logger.error(f"While retrying after azure SDK rate limit (http_code:429) getting this error {e}")
        else:
            raise
    except Exception as e:
        logger.error(f"Error While trying to get azure cost data ! Error : {e}")
    
   
    def extract_rows(resp_obj):
        columns = [col.name for col in resp_obj.columns]
        return [dict(zip(columns, row)) for row in resp_obj.rows]

    results.extend(extract_rows(response))

    # Handle pagination manually using requests
    next_link = getattr(response, 'next_link', None)

    if next_link:
        _index_count = 1
        token = credential.get_token("https://management.azure.com/.default").token
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }

        query_payload = query_definition.serialize()

        _max_page_retries = 3
        while next_link:
            logger.warning(f"Found NextLink for the current subscription:{subscription_id} , Going to fetch nex_link[{_index_count}]..")
            _index_count += 1
            # calling api for next_link
            r = None
            try:
                r = requests.post(next_link, headers=headers, json=query_payload)
            except Exception as e:
                if r is not None and r.status_code == 429:
                    logger.warning("Next Link : Fall Under Azure SDK rate limit (http_code:429). Waiting for 300 Sec and Retry...")
                    time.sleep(300)
                    r = requests.post(next_link, headers=headers, json=query_payload)
                else:
                    logger.error(f"Next Link : Error While trying to get azure cost data ! Error : {e}")
                    break

            # Organize data into correct form
            next_page = r.json()
            _page_retry_count = 0
            while (not next_page or "properties" not in next_page or "columns" not in next_page["properties"]):
                if _page_retry_count >= _max_page_retries:
                    logger.error("Next Link : Invalid response structure after max retries. Stopping pagination.")
                    next_link = None
                    break
                logger.warning(f"Next Link : No more data found or invalid response structure. Retrying after 300 seconds (attempt {_page_retry_count + 1}/{_max_page_retries})...")
                time.sleep(300)
                r = requests.post(next_link, headers=headers, json=query_payload)
                next_page = r.json()
                _page_retry_count += 1

            if not next_link:
                break

            columns = [col["name"] for col in next_page["properties"]["columns"]]
            rows = next_page["properties"]["rows"]
            results.extend([dict(zip(columns, row)) for row in rows])
            next_link = next_page.get("properties", {}).get("nextLink")

    # Formatting or modifying data in the response with calculative field.
    formatted_data = []

    for entry in results:
        resource_id = entry.get('ResourceId', '')
        resource_parts = resource_id.split('/')

        if len(resource_parts) < 9:
            logger.warning(f"Invalid ResourceId format: {resource_id}")
            resource_group = resource_type = resource_category = resource_name = "UNKNOWN"
        else:
            resource_group = resource_parts[4]
            resource_category = resource_parts[6]
            resource_type = resource_parts[7]
            resource_name = resource_parts[8]

        formatted_entry = {
            'Tenant': _tenant_domain,
            'ResourceGroupName': resource_group,
            'ResourceCategory': resource_category,
            'ResourceType': resource_type,
            'ResourceName': resource_name,
            'Cost': entry.pop("PreTaxCost", None),
            **entry
        }

        formatted_data.append(formatted_entry)

    return formatted_data


def get_cost_data_by_api(credential, subscription_id: str, start_date: str, end_date: str, api_version: str = "2019-10-01"):
    """
    Fetches Azure consumption details for the given subscription ID within a date range.

    Parameters:
        tenant_id (str): Azure Tenant ID for authentication.
        subscription_id (str): Azure Subscription ID.
        start_date (str): Start date for the cost query in 'yyyy-mm-dd' format.
        end_date (str): End date for the cost query in 'yyyy-mm-dd' format.
        api_version (str): The API version for the consumption details request. Default is "2019-10-01".

    Returns:
        dict: The JSON response with the cost details or an error message.
    """
    # Convert the start and end dates to the proper ISO 8601 datetime format with UTC timezone
    try:
        start_date_obj = datetime.strptime(start_date, "%Y-%m-%d")
        end_date_obj = datetime.strptime(end_date, "%Y-%m-%d")

        # Add time part to make it a full ISO 8601 datetime string
        start_date_iso = start_date_obj.strftime("%Y-%m-%dT00:00:00Z")
        end_date_iso = end_date_obj.strftime("%Y-%m-%dT23:59:59Z")
    except ValueError as ve:
        return {"error": f"Error parsing date: {str(ve)}"}

    # Endpoint URL for usage details
    url = f"https://management.azure.com/subscriptions/{subscription_id}/providers/Microsoft.Consumption/usagedetails?api-version={api_version}&$filter=usageStart ge {start_date_iso} and usageEnd le {end_date_iso}"

    try:
        
        token = credential.get_token("https://management.azure.com/.default")

        # Prepare headers with the token
        headers = {
            "Authorization": f"Bearer {token.token}",
            "Content-Type": "application/json"
        }

        # Make the GET request
        response = requests.get(url, headers=headers)

        # Check if the request was successful
        if response.status_code == 200:
            return response.json()  # Return the cost details as JSON
        else:
            return {"error": f"Error fetching cost details: {response.status_code} - {response.text}"}
    
    except Exception as e:
        return {"error": f"An error occurred: {str(e)}"}
    
    
def get_granular_cost_data(credential, subscription_id, start_date, end_date, group_by=["UnitOfMeasure"], granularity="Daily"):
    """
    Query Azure cost data grouped by resource with a specified granularity.

    Parameters:
        credential: Azure credential object.
        subscription_id (str): Azure subscription ID.
        start_date (str): Start date for the cost query in 'yyyy-mm-dd' format.
        end_date (str): End date for the cost query in 'yyyy-mm-dd' format.
        group_by (list[str]): List of dimensions to group by.
        granularity (str): Granularity of the data, e.g., "Daily".

    Returns:
        list[dict]: A list of dictionaries containing cost data grouped by resource details.
    """
    try:
        # Convert dates to ISO 8601 format
        start_date_iso = datetime.strptime(start_date, "%Y-%m-%d").strftime("%Y-%m-%dT00:00:00Z")
        end_date_iso = datetime.strptime(end_date, "%Y-%m-%d").strftime("%Y-%m-%dT23:59:59Z")
    except ValueError as ve:
        logger.error(f"Error parsing date: {str(ve)}")
        return []

    # Limit group_by to 15 dimensions
    group_by = group_by[:15]
    grouping_definitions = [{"type": "Dimension", "name": dimension} for dimension in group_by]
    cost_client = CostManagementClient(credential)
    query_definition = {
        "type": "Usage",
        "timeframe": "Custom",
        "timePeriod": {"from": start_date_iso, "to": end_date_iso},
        "dataset": {
            "granularity": granularity,
            "aggregation": {
                "totalCost": {"name": "PreTaxCost", "function": "Sum"},
                "usageQuantity": {"name": "UsageQuantity", "function": "Sum"}
            },
            "grouping": [{"type": "Dimension", "name": "ResourceId"}, *grouping_definitions],
        },
    }

    try:
        # Query cost data
        response = cost_client.query.usage(
            scope=f"/subscriptions/{subscription_id}",
            parameters=query_definition,
        )

        # Extract columns and rows
        columns = [col.name for col in response.columns]
        rows = response.rows

        if not rows:
            logger.warning("No data returned for the specified query.")
            return []

        # Map rows to column names
        formatted_rows = [dict(zip(columns, row)) for row in rows]

        # Process and enrich the data
        enriched_data = []
        for entry in formatted_rows:
            resource_id = entry.get("ResourceId", "")
            resource_parts = resource_id.split('/') if resource_id else []

            # Add group_by fields dynamically
            group_by_data = {group: entry.get(group, None) for group in group_by}

            enriched_data.append({
                "Date": datetime.strptime(str(entry.get("UsageDate")), "%Y%m%d").strftime("%Y-%m-%d")
                if entry.get("UsageDate") else None,
                "ResourceId": resource_id,
                "SubscriptionId": resource_parts[2] if len(resource_parts) > 2 else None,
                "ResourceGroupName": resource_parts[4] if len(resource_parts) > 4 else None,
                "ResourceCategory": resource_parts[6] if len(resource_parts) > 6 else None,
                "ResourceType": resource_parts[7] if len(resource_parts) > 7 else None,
                "ResourceName": resource_parts[8] if len(resource_parts) > 8 else None,
                **group_by_data,
                "UsageQuantity" : entry.get("UsageQuantity",0),
                "Cost": entry.get("PreTaxCost", 0),
                "Currency": entry.get("Currency", 'Unknown'),
              
            })

        return enriched_data
    except Exception as e:
        logger.error(f"Error querying cost data: {str(e)}")
        return []






def get_resource_tags_and_cost_data_from_cost_management(
    credential: Any,
    subscription_id: str,
    start_date: str,
    end_date: str,
    tag_prefix: str = "tag_",
    include_extended_fields: bool = True,
    include_additional_info: bool = False
) -> list[dict]:
    """
    Fetch Azure resource cost and usage data from Cost Management API.

    Args:
        credential: Azure credential object for authentication
        subscription_id: Azure subscription ID
        start_date: Start date in 'YYYY-MM-DD' format
        end_date: End date in 'YYYY-MM-DD' format
        tag_prefix: Prefix for tag keys in output (default: 'tag_')
        include_extended_fields: Include billing/partner/publisher details (default: True)
        include_additional_info: Include additional info JSON fields like RINormalizationRatio (default: False)

    Returns:
        List of dictionaries containing resource cost and usage data
    """
    logger.info(f"Fetching cost data for subscription {subscription_id} from {start_date} to {end_date}")

   
    tenant_domain = {"Tenant":get_tenant_domain_using_credential(credential=credential)}
    # Fetch usage details from Azure
    client = ConsumptionManagementClient(credential, subscription_id)
    usage_details = client.usage_details.list(
        scope=f"/subscriptions/{subscription_id}",
        expand="properties/meterDetails",
        filter=f"properties/usageStart ge '{start_date}' and properties/usageEnd le '{end_date}'"
    )

    # Build records
    data = []
    for item in usage_details:
        # Step 1: Tenant/Credential info (First)
        record = {}
        record.update(tenant_domain)
        
        # Step 2: Core resource and meter fields
        core_fields = {
            "SubscriptionId": "subscription_guid",
            "SubscriptionName": "subscription_name",
            "ResourceGroupName": "resource_group",
            "ResourceId": "instance_name",
            "ResourceType": "type",
            "Location": "resource_location",
            "MeterId": "meter_id",
            "MeterName": "meter_name",
            "MeterCategory": "meter_category",
            "MeterSubCategory": "meter_sub_category",
            "MeterRegion": "meter_region",
            "ServiceFamily": "service_family",
        }
        record.update({key: getattr(item, attr, None) for key, attr in core_fields.items()})
        
        # Step 3: Additional info (between core and cost fields)
        if include_additional_info:
            additional_info = getattr(item, "additional_info", None)
            if additional_info:
                try:
                    record.update(json.loads(additional_info))
                except json.JSONDecodeError:
                    record["AdditionalInfoRaw"] = additional_info
        # Step 4: Extended fields
        if include_extended_fields:
            extended_fields = {
                "BillingAccountId": "billing_account_id",
                "BillingAccountName": "billing_account_name",
                "CustomerTenantId": "customer_tenant_id",
                "CustomerName": "customer_name",
                "PartnerTenantId": "partner_tenant_id",
                "PartnerName": "partner_name",
                "PublisherName": "publisher_name",
                "PublisherType": "publisher_type",
                "ProductOrderId": "product_order_id",
                "ProductOrderName": "product_order_name",
            }
            record.update({key: getattr(item, attr, None) for key, attr in extended_fields.items()})

        # Step 5: Cost and usage fields
        cost_fields = {
            "CostInUSD": "cost_in_usd",
            "CostInBillingCurrency": "cost_in_billing_currency",
            "CostInPricingCurrency": "cost_in_pricing_currency",
            "Quantity": "quantity",
            "UnitOfMeasure": "unit_of_measure",
            "UnitPrice": "unit_price",
            "EffectivePrice": "effective_price",
            "ChargeType": "charge_type",
            "Frequency": "frequency",
            "UsageStart": "billing_period_start_date",
            "UsageEnd": "billing_period_end_date",
        }
        record.update({key: getattr(item, attr, None) for key, attr in cost_fields.items()})
        
        
        
        # Step 6: Tags at the end
        tags = getattr(item, "tags", {}) or {}
        record.update({f"{tag_prefix}{k}": v for k, v in tags.items()})
        
        data.append(record)

    # Return list of dictionaries
    logger.info(f"Fetched {len(data)} cost records")
    return data