import logging
import csv
from datetime import datetime, timedelta
from azure.identity import DefaultAzureCredential, InteractiveBrowserCredential
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.subscription import SubscriptionClient
from azure.mgmt.costmanagement import CostManagementClient
import typer
import pandas as pd
import os
import sys
import logging
from logging.handlers import RotatingFileHandler
from azure.mgmt.storage import StorageManagementClient
from azure.storage.blob import BlobServiceClient


from utils.logger import get_logger

# Get a logger specific to this module (gincloud.azure.report.cost)
logger = get_logger("gincloud.azure.storage")








# Function to get blob uses data
def get_storage_blob_data(credential,subscription_id):
    """
    Retrieves Azure storage account, container, and blob details with sizes in byets using Storage Context.
    Returns the data as a list of dictionaries.
    """
    # Authenticate using DefaultAzureCredential
    #credential = DefaultAzureCredential()
    storage_client = StorageManagementClient(credential, subscription_id)

    # List to hold all results
    storage_data = []

    # Iterate through all storage accounts in the subscription
    for account in storage_client.storage_accounts.list():
        resource_group = account.id.split("/")[4]  # Extract resource group name from the account ID

        # Prepare account-level details
        account_details = {
            'Subscription': subscription_id,
            'StorageAccountName': account.name,
            'ResourceGroup': resource_group,
            'StorageCreationDate': account.creation_time,
            'StorageSku': account.sku.name,
            'StorageType': account.kind,
            'Location': account.location,
            'StorageAccessTier': account.access_tier,
        }

        # Retrieve the primary connection string for the storage account
        try:
            keys = storage_client.storage_accounts.list_keys(resource_group, account.name)
            connection_string = f"DefaultEndpointsProtocol=https;AccountName={account.name};AccountKey={keys.keys[0].value};EndpointSuffix=core.windows.net"

            # Access the Blob Service Client using the connection string
            blob_service_client = BlobServiceClient.from_connection_string(connection_string)

            # List all containers in the storage account
            for container in blob_service_client.list_containers():
                container_name = container["name"]

                try:
                    container_client = blob_service_client.get_container_client(container_name)
                    blobs = container_client.list_blobs()

                    for blob in blobs:
                        # Calculate blob size in MB and add blob details
                        blob_details = {
                            **account_details,
                            'ContainerName': container_name,
                            'BlobName': blob.name,
                            'BlobSizeBytes': blob.size ,
                            'BlobSizeMB': blob.size / (1024 * 1024),
                            'BlobLastModified': blob.last_modified,
                            'BlobTier': blob.blob_tier,
                        }
                        storage_data.append(blob_details)

                except Exception as blob_error:
                    # Log the error and skip this container
                    logger.error(f"Error retrieving blobs for container {container_name}: {blob_error}")

        except Exception as connection_error:
            # Log the error and skip this storage account
            logger.error(f"Error retrieving connection string for account {account.name}: {connection_error}")

    return storage_data


