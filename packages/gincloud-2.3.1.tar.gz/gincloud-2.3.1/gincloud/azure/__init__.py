import requests
from azure.identity import InteractiveBrowserCredential
from azure.mgmt.subscription import SubscriptionClient
from azure.mgmt.resource import ResourceManagementClient
from utils.logger import get_logger

import os
import logging
import subprocess
import json
from typing import Optional, List , Dict,Iterable
from azure.identity import (
    ManagedIdentityCredential,
    ClientSecretCredential,
    AzureCliCredential,
    AzurePowerShellCredential,
)
from azure.core.credentials import AccessToken, TokenCredential


logger = get_logger("gincloud.azure")


class AccessTokenCredential(TokenCredential):
    """
    Custom credential wrapper for directly provided access tokens.
    """

    def __init__(self, access_token: str, expires_on: int = 3600):
        self._token = access_token
        self._expires_on = expires_on

    def get_token(self, *scopes, **kwargs) -> AccessToken:
        return AccessToken(self._token, self._expires_on)

def _get_token_via_certificate_powershell(
    tenant_id: str, client_id: str, thumbprint: str
) -> str:
    ps_script = f"""
    try {{
        Connect-AzAccount -ServicePrincipal -TenantId "{tenant_id}" -ApplicationId "{client_id}" -CertificateThumbprint "{thumbprint}" -ErrorAction Stop *>$null
        $token = Get-AzAccessToken -ResourceUrl "https://management.azure.com"
        $token | ConvertTo-Json -Compress
    }} catch {{
        $err = @{{ error = $_.Exception.Message }}
        $err | ConvertTo-Json -Compress
        exit 1
    }}
    """

    result = subprocess.run(
        ["powershell", "-NoProfile", "-Command", ps_script],
        capture_output=True,
        text=True,
    )

    if result.returncode != 0:
        logger.error(f"PowerShell script failed: {result.stderr.strip()}")
        raise RuntimeError(f"PowerShell error: {result.stderr.strip()}")

    try:
        output = json.loads(result.stdout.strip())
    except json.JSONDecodeError as e:
        raise RuntimeError(f"Failed to parse PowerShell output: {e}\nOutput: {result.stdout}")
    
    # check Expiration on is not expired
    if output.get("ExpiresOn"):
        from datetime import datetime, timezone
        expires_on = datetime.fromtimestamp(int(output["ExpiresOn"][6:-2]) / 1000, tz=timezone.utc)
        if expires_on < datetime.now(timezone.utc):
            logger.error(f"Token expired at {expires_on}, current time is {datetime.now(timezone.utc)}")
            raise RuntimeError("The retrieved token is expired.")
        else:
            logger.debug(f"Certificate Token is valid until {expires_on}")
    if tenant_id is not None and output.get("TenantId") != tenant_id:
        logger.error(f"Token tenant ID {output.get('TenantId')} does not match requested tenant ID {tenant_id}")
        raise RuntimeError("The retrieved token's tenant ID does not match the requested tenant ID.")

    token = output.get("Token")
    if not token:
        raise RuntimeError("Failed to retrieve token from PowerShell script.")
    return token

def authenticate_to_azure(
    auth_method: List[str] = "browser",
    tenant_id: Optional[List[str]] = None,
    # For  adisonal methods
    client_id: Optional[str] = None,
    client_secret: Optional[str] = None,  # Only for client secret auth
    thumbprint: Optional[str] = None,  # Only for certificate auth (powershell)
    access_token: Optional[str] = None,
) -> Optional[TokenCredential]:
    """
    Authenticate to Azure using multiple methods.
    Methods: browser, cli, powershell, certificate (via PowerShell), token.

    Env Vars (overridden by args):
        GINCLOUD_TENANT_ID
        GINCLOUD_METHOD
        GINCLOUD_CLIENT_ID
        GINCLOUD_ACCESS_TOKEN
        GINCLOUD_THUMBPRINT
    """
    _VALID_AUTH_METHOD_LIST = [
        "browser",
        "cli",
        "powershell",
        "managedidentity",
        "clientsecret",
        "powercert",
        "token",
    ]
    # Load from env if not provided
    tenant_id = tenant_id or os.getenv("GINCLOUD_AZURE_DEFAULT_TENANT_ID")
    auth_method = auth_method or os.getenv(
        "GINCLOUD_AZURE_DEFAULT_AUTH_METHOD", "browser"
    ).split("/")

    client_id = client_id or os.getenv("GINCLOUD_AUTH_CLIENT_ID")
    client_secret = client_secret or os.getenv("GINCLOUD_AUTH_CLIENT_SECRET")
    thumbprint = thumbprint or os.getenv("GINCLOUD_AUTH_CERTIFICATE_THUMBPRINT")
    access_token = access_token or os.getenv("GINCLOUD_AUTH_ACCESS_TOKEN")

    for method in auth_method:
        method = method.lower()
        if method not in _VALID_AUTH_METHOD_LIST:
            logger.error(
                f"Invalid auth method: {method}. Valid options: {_VALID_AUTH_METHOD_LIST}"
            )
            continue

        logger.info(
            f"Starting azure authentication. With TenantID: {tenant_id} Method: {method} "
        )

        if method == "browser":
            try:
                credential = InteractiveBrowserCredential(tenant_id=tenant_id)
                credential.get_token("https://management.azure.com/.default")
                logger.debug("Using InteractiveBrowserCredential.")
            except Exception as e:
                logger.warning(f"Browser authentication failed: {e}")
                continue

        elif method == "cli":
            try:
                credential = AzureCliCredential(tenant_id=tenant_id)
                credential.get_token("https://management.azure.com/.default")
                logger.debug("Using Azure CLI credential.")
            except Exception as e:
                logger.warning(f"Azure CLI authentication failed: {e}")
                continue

        elif method == "powershell":
            try:
                credential = AzurePowerShellCredential(tenant_id=tenant_id)
                credential.get_token("https://management.azure.com/.default")
                logger.debug("Using Azure PowerShell credential.")
            except Exception as e:
                logger.warning(f"Azure PowerShell authentication failed: {e}")
                continue

        elif method == "managedidentity":
            try:
                credential = ManagedIdentityCredential(tenant_id=tenant_id)
                credential.get_token("https://management.azure.com/.default")
                logger.debug("Using Azure managedidentity.")
            except Exception as e:
                logger.warning(f"Azure managedidentity authentication failed: {e}")
                continue

        elif method == "clientsecret":
            try:
                if not (client_secret and client_id):
                    raise ValueError(
                        "Managed Identity method requires tenant_id and client_id."
                    )
                credential = ClientSecretCredential(
                    client_id=client_id,
                    client_secret=client_secret,
                    tenant_id=tenant_id,
                )
                credential.get_token("https://management.azure.com/.default")
                logger.debug("Using Azure managedidentity.")
            except Exception as e:
                logger.warning(f"Azure managedidentity authentication failed: {e}")
                continue

        elif method == "powercert":
            try:
                if not (tenant_id and client_id and thumbprint):
                    raise ValueError(
                        "Certificate method requires tenant_id, client_id, and thumbprint."
                    )

                token = _get_token_via_certificate_powershell(
                    tenant_id, client_id, thumbprint
                )
                credential = AccessTokenCredential(token)
                credential.get_token("https://management.azure.com/.default")
                logger.debug("Using certificate auth via PowerShell.")
            except Exception as e:
                logger.warning(f"Certificate authentication failed: {e}")
                continue

        elif method == "token":
            try:
                if not access_token:
                    raise ValueError("Access token is required for 'token' method.")
                credential = AccessTokenCredential(access_token)
                logger.debug("Using AccessTokenCredential.")
                credential.get_token("https://management.azure.com/.default")
            except Exception as e:
                logger.warning(f"Access token authentication failed: {e}")
                continue
        else:  #
            logger.error(f"Unsupported auth method: {method}")
            continue

        # Verify authentication
        subscription_client = SubscriptionClient(credential)
        subscriptions = list(subscription_client.subscriptions.list())

        logger.debug(
            f"Tenant {tenant_id} Authenticated using {method}. Found {len(subscriptions)} subscriptions."
        )
        for sub in subscriptions:
            logger.debug(
                f"Subscription ID: {sub.subscription_id}, Name: {sub.display_name}"
            )

        return credential

def get_tenant_name_from_id(credential, tenant_id: str) -> str:
    """
    Resolve tenant domain (e.g., contoso.onmicrosoft.com) from tenant_id using MS Graph.
    """
    token = credential.get_token("https://graph.microsoft.com/.default")
    headers = {"Authorization": f"Bearer {token.token}"}
    url = "https://graph.microsoft.com/v1.0/domains"

    resp = requests.get(url, headers=headers)
    resp.raise_for_status()
    domains = resp.json().get("value", [])

    # Prefer default verified domain, else first domain
    for d in domains:
        if d.get("isDefault"):
            return d["id"]
    return domains[0]["id"] if domains else tenant_id

def authenticate_with_tenant_id(tenant_id: str):
    """
    Authenticate to Azure using InteractiveBrowserCredential with a specific Tenant ID,
    verify authentication by retrieving subscriptions, and log the details.

    Args:
        tenant_id (str): The Azure Active Directory tenant ID.

    Returns:
        tuple: A tuple containing the credential object and a list of subscriptions,
               or None if authentication fails.
    """
    try:
        logger.debug("Initializing InteractiveBrowserCredential.")
        credential = InteractiveBrowserCredential(tenant_id=tenant_id)
        logger.debug("InteractiveBrowserCredential initialized successfully.")

        # Verify authentication by listing subscriptions
        logger.debug("Initializing SubscriptionClient to verify authentication.")
        subscription_client = SubscriptionClient(credential)
        subscriptions = list(subscription_client.subscriptions.list())

        logger.info(
            f"Successfully authenticated and retrieved {len(subscriptions)} subscriptions."
        )
        for sub in subscriptions:
            logger.debug(
                f"Subscription ID: {sub.subscription_id}, Display Name: {sub.display_name}"
            )

        return credential  # , subscriptions

    except Exception as e:
        logger.error(
            f"Error during authentication or subscription verification. Error :{e}",
            exc_info=True,
        )
        return None


def get_subscription_name_from_id(credential, subscription_id):
    try:
        subscription_client = SubscriptionClient(credential)
        subscriptions = list(subscription_client.subscriptions.list())

        # Find the subscription with the matching ID
        matching_sub = next(
            (sub for sub in subscriptions if sub.subscription_id == subscription_id),
            None,
        )

        if matching_sub:
            return matching_sub.display_name

        # Log an error if no matching subscription is found
        logging.error(f"No subscription found with ID: {subscription_id}")
        return None

    except Exception as e:
        # Log the exception and the error
        logging.exception(
            f"Error retrieving subscription name for ID {subscription_id}: {str(e)}"
        )
        return None


def get_subscription_id_from_name(credential, subscription_name):
    try:
        subscription_client = SubscriptionClient(credential)
        subscriptions = list(subscription_client.subscriptions.list())

        # Filter subscriptions by display name (case insensitive)
        matching_subs = [
            sub
            for sub in subscriptions
            if sub.display_name.lower() == subscription_name.lower()
        ]

        if matching_subs:
            return matching_subs[0].subscription_id

        # Log an error if no matching subscription is found
        logging.error(f"No subscription found with name: {subscription_name}")
        return None

    except Exception as e:
        # Log the exception and the error
        logging.exception(
            f"Error retrieving subscription ID for {subscription_name}: {str(e)}"
        )
        return None



def get_subscriptions(
    credential,
    include_spending_limit: bool = False,
    include_disabled: bool = False,
    select_subscriptions: Optional[Iterable[str]] = None,
    exclude_subscriptions: Optional[Iterable[str]] = None,
) -> List:
    """
    Retrieve Azure subscriptions with flexible filtering.

    Selection & exclusion support:
      - subscription ID
      - subscription display name
      - or both

    Behavior:
      - select_subscriptions = None  -> select ALL subscriptions (default)
      - exclude_subscriptions always applied after selection

    Args:
        credential: Azure credential
        include_spending_limit (bool): Include free/trial/student subscriptions
        include_disabled (bool): Include disabled subscriptions
        select_subscriptions (Iterable[str]): IDs and/or names to include
        exclude_subscriptions (Iterable[str]): IDs and/or names to exclude

    Returns:
        List of filtered Subscription objects
    """

    logger.debug("Initializing SubscriptionClient...")
    client = SubscriptionClient(credential)

    try:
        subscriptions = client.subscriptions.list()
    except Exception as e:
        logger.error("Failed to list subscriptions: %s", e)
        raise

    # Normalize filters (case-insensitive)
    selected_values = {v.strip().lower() for v in select_subscriptions or []}
    excluded_values = {v.strip().lower() for v in exclude_subscriptions or []}

    filtered_subscriptions = []

    for sub in subscriptions:
        sub_id = (sub.subscription_id or "").lower()
        sub_name = (sub.display_name or "").lower()

        # ---- Selection filter (default = all) ----
        if selected_values and sub_id not in selected_values and sub_name not in selected_values:
            logger.debug(
                "Skipped subscription (not selected): %s (id=%s)",
                sub.display_name,
                sub.subscription_id,
            )
            continue

        # ---- Exclusion filter ----
        if sub_id in excluded_values or sub_name in excluded_values:
            logger.warning(
                "Excluded subscription: %s (id=%s)",
                sub.display_name,
                sub.subscription_id,
            )
            continue

        state = (sub.state or "").lower()
        policies = getattr(sub, "subscription_policies", None)
        spending_limit = getattr(policies, "spending_limit", "").lower() if policies else ""

        is_enabled = state == "enabled"
        is_free_like = spending_limit in ("on", "currentperiodoff")

        # ---- State / spending filters ----
        if not is_enabled and not include_disabled:
            logger.debug(
                "Excluded subscription: %s (state=%s)",
                sub.display_name,
                state,
            )
            continue

        if is_free_like and not include_spending_limit:
            logger.debug(
                "Excluded subscription: %s (spending_limit=%s)",
                sub.display_name,
                spending_limit,
            )
            continue

        filtered_subscriptions.append(sub)
        logger.debug(
            "Included subscription: %s (state=%s, spending_limit=%s)",
            sub.display_name,
            state,
            spending_limit,
        )

    logger.debug("Final subscription count: %d", len(filtered_subscriptions))
    return filtered_subscriptions
def get_resource_details(credential, subscription_id: str):
    """
    Fetch all Azure resources and their tags for a given subscription,
    and filter based on specified keys.

    Args:
        credential: Azure credential object.
        subscription_id (str): Azure subscription ID.
        Tags_to_include (List[str], optional): List of keys to include in the output,
                                               including 'resource_id'. Defaults to None.

    Returns:
        List[Dict]: Filtered list of resources and their tags.
    """
    resource_client = ResourceManagementClient(credential, subscription_id)
    resources = resource_client.resources.list()

    return resources


def get_tenant_domain_using_credential(credential):
    token = credential.get_token("https://graph.microsoft.com/.default").token
    url = "https://graph.microsoft.com/v1.0/organization"
    headers = {"Authorization": f"Bearer {token}"}

    resp = requests.get(url, headers=headers)
    resp.raise_for_status()
    data = resp.json()
    logger.debug(
        f"get_tenant_domain_using_credential found tenant domain name : {data['value'][0]['verifiedDomains'][0]['name']}"
    )
    return data["value"][0]["verifiedDomains"][0]["name"]




def get_resource_providers(credential, subscription_id: str) -> List[Dict]:
    """
    Fetch all resource providers in a subscription
    and show whether they are registered or not.
    """
    logger.debug(f"Fetching resouce provider of subscription:{subscription_id}")
    client = ResourceManagementClient(credential, subscription_id)

    providers_info = []
    for provider in client.providers.list() :
        providers_info.append({
            "subscription" : subscription_id,
            "namespace": provider.namespace,
            "registration_state": provider.registration_state,
            "resource_types": [
                {
                    "resource_type": rt.resource_type,
                    "locations": rt.locations
                }
                for rt in provider.resource_types or []
            ]
        })


    return providers_info


def set_resource_provider(
    credential,
    subscription_id: str,
    provider_namespace: str,
    action: str = "register"
) -> None:
    """
    Register or unregister a resource provider.

    :param credential: Azure credential
    :param subscription_id: Azure subscription ID
    :param provider_namespace: Provider namespace (e.g. 'Microsoft.Compute')
    :param action: 'register' or 'unregister'
    """
    client = ResourceManagementClient(credential, subscription_id)

    provider = client.providers.get(provider_namespace)
    current_state = provider.registration_state

    action = action.lower()

    if action == "register":
        if current_state != "Registered":
            logger.info(f"Registering provider: {provider_namespace}")
            client.providers.register(provider_namespace)
        else:
            logger.warning(f"Provider already registered: {provider_namespace}")

    elif action == "unregister":
        if current_state == "Registered":
            logger.info(f"Unregistering provider: {provider_namespace}")
            client.providers.unregister(provider_namespace)
        else:
            logger.warning(
                f"Provider is not registered, cannot unregister: {provider_namespace}"
            )

    else:
        raise ValueError("Invalid action. Use 'register' or 'unregister'.")