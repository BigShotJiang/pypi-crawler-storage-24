import re
import time
from azure.mgmt.resource import ResourceManagementClient
from azure.mgmt.resourcegraph import ResourceGraphClient
from azure.mgmt.resourcegraph.models import QueryRequest
from azure.core.exceptions import AzureError, HttpResponseError
from azure.mgmt.consumption import ConsumptionManagementClient
from typing import List, Dict, Optional
from utils.logger import get_logger

# Get a logger specific to this module (gincloud.azure.report.cost)
logger = get_logger("gincloud.azure.tags")



def get_azure_resource_tags(
    credential,
    subscription_id: str,
    method: str = "resource",
    only_selected_tags: Optional[List[str]] = None,
    tag_key_prefix: str = "tag_",
    include_resource_metadata: bool = False,
) -> List[Dict]:
    """
    Fetch Azure resource tags using one of three available methods:
    - 'resource': Azure ResourceManagementClient
    - 'resourcegraph': Azure ResourceGraphClient
    - 'cost': Azure ConsumptionManagementClient

    Args:
        credential: Azure credential object.
        subscription_id (str): Azure subscription ID.
        method (str): Method to fetch tags. One of 'resource', 'resourcegraph', or 'cost'.
        only_selected_tags (Optional[List[str]]): List of tag keys to include (without prefix).
        tag_key_prefix (str): Prefix for tag keys (default 'tag_').

    Returns:
        List[Dict]: Filtered list of resource tag data.
    """
    method = method.lower()
    logger.debug(f"Fetching tags via '{method}' method for subscription: {subscription_id} with only_selected_tags: {only_selected_tags} and tag_key_prefix: {tag_key_prefix}")

    # Normalize selected tag keys
    selected_keys = None
    if only_selected_tags:
        selected_keys = set(f"{tag_key_prefix}{t}" for t in only_selected_tags)
        selected_keys.add("ResourceId")

    rows = []

    try:
        # ------------------------------
        # 1️⃣ ResourceManagementClient
        # ------------------------------
        if method == "resource":
            resource_client = ResourceManagementClient(credential, subscription_id)
            resources = resource_client.resources.list()

            for res in resources:
                if not res.tags:
                    continue

                tags = {f"{tag_key_prefix}{k}": v for k, v in res.tags.items()}
                data = {"ResourceId": res.id, **tags}
                if include_resource_metadata:
                    sku_name = getattr(res.sku, "name", None) if res.sku else None
                    resource_type_parts =  res.type.split('/')

                    data["StockKeepingUnit"] = sku_name
                    data['ResourceCategory'] = resource_type_parts[0]
                    data['ResourceType'] =  '/'.join(resource_type_parts[1:])

                if selected_keys:
                    data = {k: v for k, v in data.items() if k in selected_keys}

                rows.append(data)

        # ------------------------------
        # 2️⃣ ResourceGraphClient
        # ------------------------------
        elif method == "resourcegraph":
            rg_client = ResourceGraphClient(credential)
            query = "Resources | project id, tags , sku = tostring(sku.name), type | extend tags"
            query_request = QueryRequest(
                subscriptions=[subscription_id],
                query=query,
                options={"resultFormat": "objectArray"},
            )

            response = rg_client.resources(query_request)
            for item in response.data:
                tags = item.get("tags") or {}
                tags = {f"{tag_key_prefix}{k}": v for k, v in tags.items()}
                data = {"ResourceId": item["id"],"ResourceCategory": item['type'].split('/')[0], "ResourceType": '/'.join(item['type'].split('/')[1:]), **tags}
                if include_resource_metadata:
                    sku_name = item.get("sku", None)
                    resource_type_parts =  item['type'].split('/')

                    data["StockKeepingUnit"] = sku_name
                    data['ResourceCategory'] = resource_type_parts[0]
                    data['ResourceType'] =  '/'.join(resource_type_parts[1:])


                if selected_keys:
                    data = {k: v for k, v in data.items() if k in selected_keys}

                rows.append(data)

        # ------------------------------
        # 3️⃣ Cost Management
        # ------------------------------
        elif method == "cost":
            cost_client = ConsumptionManagementClient(credential, subscription_id)
            usage_iter = cost_client.usage_details.list(scope=f"/subscriptions/{subscription_id}")

            seen = {}

            for item in usage_iter:
                tags = getattr(item, "tags", None)
                if not tags:
                    continue

                rid = getattr(item, "instance_name", None)
                if not rid:
                    continue

                rid = rid.lower()

                # ✅ If already seen → compare tags and consolidate
                if rid in seen:
                    old_tags = seen[rid].get("__original_tags__", {})
                    new_tags = tags

                    if old_tags != new_tags:
                        logger.warning(
                            f"Tag mismatch detected for RID: {rid}\n"
                            f"Old Tags: {old_tags}\n"
                            f"New Tags: {new_tags}\n\n"
                        )

                        # ✅ Consolidate tag values
                        merged_tags = {}
                        all_keys = set(old_tags.keys()) | set(new_tags.keys())

                        for key in all_keys:
                            old_val = old_tags.get(key)
                            new_val = new_tags.get(key)

                            if old_val == new_val:
                                merged_tags[key] = old_val
                            else:
                                
                                # Convert existing values into a list (split on '/')
                                old_list = str(old_val).split("/") if old_val else []
                                new_list = str(new_val).split("/") if new_val else []
                                if new_val in old_list:
                                    continue
                                
                                # Merge + remove duplicates
                                merged_unique = sorted(set(old_list + new_list))
                                logger.debug(f"Tag mismatch detected for RID: {rid} where Key:{key} Values:{merged_unique}")


                                # Join back
                                merged_tags[key] = "/".join(merged_unique)

                        # ✅ Update the record with merged tags
                        seen[rid]["__original_tags__"] = merged_tags

                        # ✅ Update flattened output tags too
                        for k, v in merged_tags.items():
                            flat_key = f"{tag_key_prefix}{k}"
                            if not selected_keys or flat_key in selected_keys:
                                seen[rid][flat_key] = v

                    continue  # Done processing duplicate

                # ✅ First time seeing this RID → create entry
                flattened = {
                    f"{tag_key_prefix}{k}": v
                    for k, v in tags.items()
                    if not selected_keys or f"{tag_key_prefix}{k}" in selected_keys
                }

                flattened["ResourceId"] = rid

                if include_resource_metadata:
                    resource_type_parts = getattr(item, "type", "").split("/")
                    flattened["StockKeepingUnit"] = "unknown"
                    flattened["ResourceCategory"] = resource_type_parts[0]
                    flattened["ResourceType"] = "/".join(resource_type_parts[1:])

                # Keep original tags for later merging
                flattened["__original_tags__"] = tags

                seen[rid] = flattened

            # ✅ Remove __original_tags__ before returning rows
            for rid in seen:
                seen[rid].pop("__original_tags__", None)

            rows = list(seen.values())


        else:
            logger.error(f"Invalid method '{method}' provided. Use one of: 'resource', 'resourcegraph', or 'cost'.")
            return []

    except AzureError as e:
        logger.error(f"Azure SDK Error method: ({method}) subscriptionId: [{subscription_id}] Due to :-> {e}")
        return []
    except Exception as e:
        logger.error(f"Unexpected error in get_azure_resource_tags function where method: ({method}) subscriptionId: [{subscription_id}] Due to :-> {e}")
        return []

    logger.debug(f"Fetched {len(rows)} resources using  method: ({method}) subscriptionId: [{subscription_id}]")
    return rows

def get_all_resource_tags_using_resourcegraph(
    credential, subscription_id: str, only_selected_tags: Optional[List[str]] = None ,tag_key_prefix : str = 'tag_'
) -> List[Dict]:
    """
    Fetch all Azure resources, including deleted resources, and their tags for a given subscription.
    Filter the results based on specified keys.

    Args:
        credential: Azure credential object.
        subscription_id (str): Azure subscription ID.
        only_selected_tags (Optional[List[str]]): List of keys to include in the output,
                                               including 'ResourceId'. Defaults to None.

    Returns:
        List[Dict]: Filtered list of resources and their tags.
    """
    # Initialize ResourceGraph client
    resource_graph_client = ResourceGraphClient(credential)
    logger.debug(f"Fetching resource tags using Resource Graph for subscription: {subscription_id} with only_selected_tags: {only_selected_tags} and tag_key_prefix: {tag_key_prefix}")

    # Resource Graph query to fetch all resources including their tags
    query = """
    Resources
    | project id, tags
    | extend tags
    """
    query_request = QueryRequest(
        subscriptions=[subscription_id],
        query=query,
        options={"resultFormat": "objectArray"}
    )

    try:
        # Execute the query
        response = resource_graph_client.resources(query_request)
    except Exception as e:
        # Handle potential API call exceptions
        logger.error(f"Error while executing query: {e}")
        return []

    
    # Ensure only_selected_tags includes 'ReourceId'
    if only_selected_tags:
        only_selected_tags = [f"{tag_key_prefix}{inc_tag}" for inc_tag in only_selected_tags]
        only_selected_tags = set(only_selected_tags + ["ResourceId"])
        #only_selected_tags.append("ResourceId") # Ensure only_selected_tags includes 'ResourceId' if provided

    # Process the response
    rows = []
    for resource in response.data:
        # Safely get the tags or default to an empty dictionary if tags are None
        tags = resource.get("tags") or {}
        # Ensure ResourceId is included
        flattened_tags = {f"{tag_key_prefix}{key}": value for key, value in tags.items()}
        resource_data = {"ResourceId": resource["id"], **flattened_tags}
        # Filter the resource data based on only_selected_tags
        
        if only_selected_tags != None and only_selected_tags != []:
            
            filtered_data = {key: resource_data[key] for key in only_selected_tags if key in resource_data}
            rows.append(filtered_data)
        else:
            rows.append(resource_data)
    logger.debug(f"Final tag data: {rows[:1]} (truncated)")
    return rows


def get_resource_tags(
    credential, subscription_id: str, only_selected_tags: List[str] = None , tag_key_prefix : str = 'tag_'
) -> List[Dict]:
    """
    Fetch all Azure resources and their tags for a given subscription,
    and filter based on specified keys.

    Args:
        credential: Azure credential object.
        subscription_id (str): Azure subscription ID.
        only_selected_tags (List[str], optional): List of keys to include in the output, 
                                               including 'ReourceId'. Defaults to None.

    Returns:
        List[Dict]: Filtered list of resources and their tags.
    """
    logger.debug(f"Fetching resource tags for subscription: {subscription_id} with only_selected_tags: {only_selected_tags} and tag_key_prefix: {tag_key_prefix}")
    resource_client = ResourceManagementClient(credential, subscription_id)
    resources = resource_client.resources.list()

    # Ensure only_selected_tags includes 'ReourceId'
    if only_selected_tags:
        only_selected_tags = [f"{tag_key_prefix}{inc_tag}" for inc_tag in only_selected_tags]
        only_selected_tags = set(only_selected_tags + ["ResourceId"])

    # Fetch and filter resources and tags
    rows = []
    for resource in resources:
        if resource.tags:
            # Create a filtered dictionary for the resource
            flattened_tags = {f"{tag_key_prefix}{key}": value for key, value in resource.tags.items()}
            resource_data = {"ResourceId": resource.id, **flattened_tags}
            if only_selected_tags:
                resource_data = {key: value for key, value in resource_data.items() if key in only_selected_tags}
            rows.append(resource_data)

    return rows


def get_resource_tags_from_cost_management(
    credential,
    subscription_id: str,
    only_selected_tags: List[str] = None,
    tag_key_prefix: str = "tag_"
) -> List[Dict]:
    """
    Fetch all Azure resources and their tags for a given subscription from Cost Management,
    filtering based on specified tag keys.


    Args:
        credential: Azure credential object.
        subscription_id (str): Azure subscription ID.
        only_selected_tags (List[str], optional): List of tag keys to include in the output (without prefix).
        tag_key_prefix (str, optional): Prefix added to tag keys. Defaults to 'tag_'.

    Returns:
        List[Dict]: List of unique resources with their filtered tags.
    """

    logger.debug(
        f"Fetching resource tags for subscription: {subscription_id}, "
        f"only_selected_tags={only_selected_tags}, tag_key_prefix={tag_key_prefix}"
    )

    consumption_client = ConsumptionManagementClient(credential, subscription_id)
    usage_iter = consumption_client.usage_details.list(
        scope=f"/subscriptions/{subscription_id}"
    )

    selected_keys = None
    if only_selected_tags:
        selected_keys = set(f"{tag_key_prefix}{t}" for t in only_selected_tags)
        selected_keys.add("ResourceId")

    resource_map = {}

    for item in usage_iter:
        tags = getattr(item, "tags", None)
        if not tags:
            continue

        resource_id = item.instance_name.lower()
        if not resource_id:  # safety check
            continue

        # Skip if already processed (deduplication by resource ID)
        if resource_id in resource_map:
            continue

        # Flatten + optionally filter tags
        flattened = {
            f"{tag_key_prefix}{k}": v
            for k, v in tags.items()
            if not selected_keys or f"{tag_key_prefix}{k}" in selected_keys
        }

        flattened["ResourceId"] = resource_id
        resource_map[resource_id] = flattened

    result = list(resource_map.values())
    logger.debug(f"Fetched {len(result)} unique resources with tags for subscription {subscription_id}")
    return result



def _extract_supported_api_version(error_message: str) -> Optional[str]:
    """Extract the most recent supported API version from Azure error message."""
    match = re.search(r"supported api-versions are ['\"]([^'\"]+)['\"]", error_message, re.IGNORECASE)
    if not match:
        return None
    versions = [v.strip() for v in match.group(1).split(',')]
    return versions[-1] if versions else None


def _get_api_version(client: ResourceManagementClient, provider_namespace: str, resource_type: str) -> str:
    """Retrieve the latest API version for a resource type with a fallback."""
    try:
        provider = client.providers.get(provider_namespace)
        resource_entry = next(
            (rt for rt in provider.resource_types if rt.resource_type == resource_type),
            None
        )
        if resource_entry and resource_entry.api_versions:
            return resource_entry.api_versions[0]
    except Exception as e:
        logger.warning(f"Failed to get API version for {provider_namespace}/{resource_type}: {e}")
    return "2021-04-01"  # fallback


def _calculate_expected_tags(current_tags: dict, new_tags: dict, operation: str) -> dict:
    """Compute the new tag set based on operation type."""
    match operation.lower():
        case "merge":
            filtered_new_tags = {
                k: v
                for k, v in new_tags.items()
                if v is not None and str(v).strip() != ""
            }
            return {**current_tags, **filtered_new_tags}
        case "replace":
            return new_tags.copy()
        case "delete":
            updated = current_tags.copy()
            for key in new_tags:
                updated.pop(key, None)
            return updated
        case "append":
            updated = current_tags.copy()
            for key, value in new_tags.items():
                if key not in updated:
                    updated[key] = value
            return updated

        case _:
            raise ValueError(f"Invalid tag operation: {operation}")


def _get_resource_safe(client: ResourceManagementClient, resource_id: str, api_version: str) -> dict | None:
    """Safely retrieve an Azure resource and handle common errors."""
    try:
        return client.resources.get_by_id(resource_id, api_version=api_version)
    except HttpResponseError as err:
        msg = str(err).lower()
        not_found = (
            "resourcenotfound" in msg
            or "was not found" in msg
            or (hasattr(err, "error") and getattr(err.error, "code", "").lower() == "resourcenotfound")
        )
        if not_found:
            logger.warning(f"[NotFound] Resource not found: {resource_id}")
            return None
        logger.error(f"[Error] Unable to get resource {resource_id}: {err}")
        raise
    except Exception as e:
        logger.error(f"[Error] Unexpected failure getting resource {resource_id}: {e}")
        raise


def update_tags_using_resource_id(
    credential,
    resource_id: str,
    new_tags: dict,
    operation: str = "merge",
    max_retries: int = 3
) -> dict:
    """
    Update tags on an Azure resource with automatic API version detection and retry handling.

    :param credential: Azure credential object
    :param resource_id: Full Azure resource ID
    :param new_tags: Tags to add/update/delete
    :param operation: 'merge', 'replace', or 'delete'
    :param max_retries: Number of retry attempts
    :return: Operation status and tag info
    """
    parts = resource_id.split("/")
    if len(parts) < 9:
        raise ValueError(f"Invalid Azure resource ID: {resource_id}")

    subscription_id = parts[2]
    provider_namespace, resource_type = parts[6], parts[7]

    client = ResourceManagementClient(credential, subscription_id)
    api_version = _get_api_version(client, provider_namespace, resource_type)
    api_version_retried = False

    for attempt in range(1, max_retries + 1):
        try:
            resource = _get_resource_safe(client, resource_id, api_version)
            if resource is None:
                return {
                    "resource_id": resource_id,
                    "status": "NotFound",
                    "message": "Resource not found",
                    "before_change_tags": {},
                    "after_change_tags": None,
                }

            before_tags = resource.tags or {}
            expected_tags = _calculate_expected_tags(before_tags, new_tags, operation)

            if operation == "merge" and before_tags == expected_tags:
                logger.info(f"[Skip] No tag change for {resource_id}")
                return {
                    "resource_id": resource_id,
                    "status": "Skip",
                    "message": "No tag change detected",
                    "before_change_tags": before_tags,
                    "after_change_tags": None,
                }

            # Update tags
            poller = client.resources.begin_update_by_id(
                resource_id,
                api_version=api_version,
                parameters={"tags": expected_tags},
            )
            poller.result()

            # Verify update
            after_tags = (client.resources.get_by_id(resource_id, api_version=api_version).tags) or {}
            logger.info(f"[Success] Tags updated for {resource_id} (API {api_version})")

            return {
                "resource_id": resource_id,
                "new_tags": new_tags,
                "expected_tags": expected_tags,
                "before_change_tags": before_tags,
                "after_change_tags": after_tags,
                "status": "Success",
                "api_version": api_version,
            }

        except HttpResponseError as e:
            err_msg = str(e)
            # Retry with alternate API version (only once)
            if not api_version_retried and "api version" in err_msg.lower():
                supported = _extract_supported_api_version(err_msg)
                if supported:
                    logger.warning(
                        f"[API Version Switch] Retrying {resource_id} using supported version {supported}"
                    )
                    api_version = supported
                    api_version_retried = True
                    continue

            # Retry transient issues
            if attempt < max_retries:
                wait = 2 ** attempt
                logger.warning(f"[Retry {attempt}] {resource_id} failed: {e}. Retrying in {wait}s...")
                time.sleep(wait)
                continue

            logger.error(f"[Failed] Max retries reached for {resource_id}: {e}")
            return {
                "resource_id": resource_id,
                "status": "Failed",
                "message": str(e),
                "before_change_tags": {},
                "after_change_tags": None,
            }

        except AzureError as e:
            if attempt < max_retries:
                wait = 2 ** attempt
                logger.warning(f"[Retry {attempt}] AzureError: {e}. Waiting {wait}s...")
                time.sleep(wait)
                continue
            return {
                "resource_id": resource_id,
                "status": "Failed",
                "message": str(e),
                "before_change_tags": {},
                "after_change_tags": None,
            }

        except Exception as e:
            logger.error(f"[Error] Unexpected error for {resource_id}: {e}")
            return {
                "resource_id": resource_id,
                "status": "Failed",
                "message": str(e),
                "before_change_tags": {},
                "after_change_tags": None,
            }

    raise RuntimeError(f"Failed to update tags after {max_retries} attempts.")
