import typer
from typing import List, Optional
from datetime import datetime
from utils import interactive_select_from_list, save_to_csv
from gincloud.azure.runcommand import execute_run_command
from utils.logger import get_logger
from utils.context import AzureContext

from cli.azure.tags import TagCommand
from cli.azure.cost import ReportCommand
from cli.azure.core import (
    COMMON_CLI_OPTIONS,
    resolve_scope_from_context,
    parse_multi_value_input,
)

# Logger
logger = get_logger("cli.azure")

AzureCommand = typer.Typer(
    name="azure",
    help="Azure cloud management commands for various operations, including cost analysis, reporting, and resource management etc.",
)

AzureCommand.add_typer(TagCommand)
AzureCommand.add_typer(ReportCommand)


@AzureCommand.callback(invoke_without_command=True)
def azure_callback(
    ctx: typer.Context,
    tenant_id: Optional[List[str]] = typer.Option(
        None,
        "-t",
        "--tenant",
        "--tenants",
        "--tenant-id",
        "--tenant-name",
        "--tenant-ids",
        "--tenant-names",
        help=(
            "Azure Tenant ID(s). Set once here and every azure subcommand inherits it.\n\n"
            "Can still be overridden per-subcommand with the same flag.\n"
            "If omitted entirely, the first subcommand that needs it will prompt interactively."
        ),
        callback=parse_multi_value_input,
    ),
    subscription_id: List[str] = COMMON_CLI_OPTIONS["subscription_id"],
    exclude_subscription_id: List[str] = COMMON_CLI_OPTIONS["exclude_subscription_id"],
    auth_method: str = COMMON_CLI_OPTIONS["auth_method"],
    client_id: Optional[str] = COMMON_CLI_OPTIONS["client_id"],
    client_secret: Optional[str] = COMMON_CLI_OPTIONS["client_secret"],
    thumbprint: Optional[str] = COMMON_CLI_OPTIONS["thumbprint"],
    access_token: Optional[str] = COMMON_CLI_OPTIONS["access_token"],
    allow_disable_subscriptions: bool = COMMON_CLI_OPTIONS["allow_disable_subscriptions"],
    allow_spending_limited_subscriptions: bool = COMMON_CLI_OPTIONS[
        "allow_spending_limited_subscriptions"
    ],
):
    """Azure cloud management commands for various operations, including cost analysis,
    reporting, and resource management etc."""
    ctx.obj = AzureContext(
        tenant_ids=tenant_id or [],
        subscription_ids=subscription_id or ["all"],
        exclude_subscription_ids=exclude_subscription_id or [],
        auth_method=auth_method if isinstance(auth_method, list) else [auth_method],
        client_id=client_id,
        client_secret=client_secret,
        thumbprint=thumbprint,
        access_token=access_token,
        allow_disable=allow_disable_subscriptions,
        allow_spending_limit=allow_spending_limited_subscriptions,
    )
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())
        raise typer.Exit()


@AzureCommand.command(
    help="Run a script (inline or file) on Azure VMs.",
    short_help="Execute RunCommand on VMs.",
)
def run_command(
    ctx: typer.Context,
    # -- scope --
    tenant_id: Optional[List[str]] = typer.Option(
        None,
        "-t", "--tenant",
        help="Tenant ID(s). Overrides the azure-group value.",
        callback=parse_multi_value_input,
    ),
    subscription_id: List[str] = COMMON_CLI_OPTIONS["subscription_id"],
    exclude_subscription_id: List[str] = COMMON_CLI_OPTIONS["exclude_subscription_id"],
    # -- VM targeting --
    filter_by: str = typer.Option(
        "selective",
        "-f", "--filter-by", "--filter",
        help=(
            "VM filter mode (comma-separated, AND logic). "
            "Modes: all | selective | vm | rg | tag."
        ),
        callback=parse_multi_value_input,
        show_default=True,
    ),
    filter_value: Optional[str] = typer.Option(
        None,
        "-v", "--filter-value", "--value",
        help="Comma-separated values for vm/rg/tag filters.",
    ),
    # -- script --
    script: str = typer.Argument(
        ...,
        help=(
            "Inline script or path to a .ps1/.sh file.\n\n"
            "Examples:\n\n"
            "  Inline PS : 'Write-Host $env:COMPUTERNAME'\n\n"
            "  File      : C:\\scripts\\check.ps1\n\n"
            "  Shell     : '#!/bin/bash\\necho hello'"
        ),
    ),
    parameters: Optional[str] = typer.Argument(
        None,
        help=(
            "Script parameters as comma-separated tokens.\n\n"
            "Formats:\n\n"
            "  Key-Value : Name=admin,Path=C:\\temp\n\n"
            "  Switch    : Force,Verbose  (passed as name=true)\n\n"
            "  Mixed     : User=admin,Force,Mode=Test\n\n"
            "In the .ps1 script, receive them with param():\n\n"
            "  param($User, [switch]$Force, $Mode)"
        ),
    ),
    # -- output --
    output_file: str = COMMON_CLI_OPTIONS["output_file"],
    # -- execution --
    max_workers: int = typer.Option(
        10,
        "-w", "--max-workers",
        help="Max parallel VM executions (1 = serial).",
    ),
    show_progress: bool = typer.Option(
        False,
        "--show-progress/--no-progress",
        help="Show a progress bar (hides per-VM output).",
    ),
    poll_timeout: int = typer.Option(
        300,
        "-pt", "--poll-timeout", "--timeout",
        help="Seconds to wait per VM before timeout.",
    ),
):
    all_scope = resolve_scope_from_context(
        ctx,
        tenant_ids=tenant_id,
        subscription_ids=subscription_id,
        exclude_subscription_ids=exclude_subscription_id,
        include_spending_limit=True,
    )
    for scope in all_scope:
        _tenant_id = scope["tenant_id"]
        credential = scope["credential"]
        subscriptions = scope["subscriptions"]
        tenant_domain = scope["tenant_domain"]

        # If multiple subscriptions are available and user wants interactive selection,
        # let them narrow down which subscriptions to target.
        if len(subscriptions) > 1 and (
            "selective" in filter_by or "select" in filter_by
        ):
            chosen_sub_name = interactive_select_from_list(
                data=[sub.display_name for sub in subscriptions],
                title="Select Subscription(s)",
            )
            subscriptions = [
                sub for sub in subscriptions if sub.display_name in chosen_sub_name
            ]

        results = []
        for sub in subscriptions:
            logger.info(
                f"Processing Tenant: [{tenant_domain}] Subscription: [{sub.display_name}] for azure runcommand.."
            )
            results.extend(
                execute_run_command(
                    credential=credential,
                    subscription_id=sub.subscription_id,
                    filter_by=filter_by,
                    filter_value=filter_value,
                    script=script,
                    parameters=parameters,
                    max_workers=max_workers,
                    show_progress=show_progress,
                    poll_timeout=poll_timeout,
                )
            )
        # Print results nicely
        if results:
            if output_file is None:
                output_file = f"Run_Command_Execution_Result_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            save_to_csv(data=results, output_file=output_file, ensure_sorted=False)
        else:
            typer.echo("No VMs matched or no output returned.")
