import typer
from typing import Optional
from typing import List
from gincloud.azure.cost import (
    get_cost_data,
    get_cost_details_data,
    get_cost_data_by_api,
    get_azure_sku_pricing,
    get_resource_tags_and_cost_data_from_cost_management,
)
from utils import join_list_of_dict, save_to_csv, flatten_json_data
from gincloud.azure.tags import (
    get_azure_resource_tags,
    get_resource_tags,
    get_all_resource_tags_using_resourcegraph,
)
from cli.azure.core import (
    COMMON_CLI_OPTIONS,
    parse_multi_value_input,
    resolve_scope_from_context,
)
from utils.logger import get_logger

# Logger
logger = get_logger("cli.azure.cost")

ReportCommand = typer.Typer(
    name="report",
    help="Commands for generating and exporting various Azure reports, including cost reports and usage analysis.",
)


@ReportCommand.command(
    "sku-pricing",
    help="Export Azure SKU pricing data to a CSV file from the Azure Retail Prices API.",
)
def sku_pricing(
    ctx: typer.Context,
    tenant_id: Optional[List[str]] = typer.Option(
        None,
        "-t",
        "--tenant",
        "--tenants",
        "--tenant-id",
        "--tenant-ids",
        help="Override the tenant ID(s) set at the azure group level.",
        callback=parse_multi_value_input,
    ),
    filter_conditions: Optional[str] = typer.Option(
        None,
        help="Comma-separated OData filter parts. Example: \"serviceName eq 'Virtual Machines', armRegionName eq 'centralindia'\"",
    ),
    currency_code: str = typer.Option(
        "INR", help="Currency code for pricing data (default: INR)"
    ),
    output_file: str = typer.Option(
        "azure_sku_pricing.csv",
        help="Path to save the output CSV file (default: azure_sku_pricing.csv)",
    ),
    csv_column_sort: bool = typer.Option(
        True, help="Sort the CSV columns alphabetically before saving."
    ),
):
    """
    Fetches Azure SKU pricing and exports it to CSV.
    """
    try:
        # Convert filter string to list if provided
        filters = (
            [f.strip() for f in filter_conditions.split(",")]
            if filter_conditions
            else None
        )

        logger.info("Authenticating with Azure...")
        all_scope = resolve_scope_from_context(ctx, tenant_ids=tenant_id)
        if not all_scope:
            logger.error("No Azure scope resolved.")
            raise typer.Exit(code=1)

        # SKU pricing is global — only one credential is needed
        credential = all_scope[0]["credential"]

        logger.info("Fetching SKU pricing data...")
        sku_data = get_azure_sku_pricing(
            currency_code=currency_code,
            filter_conditions=filters,
            credential=credential,
        )

        if not sku_data:
            logger.warning("No SKU pricing data retrieved.")
            raise typer.Exit(code=1)

        logger.info(f"Saving {len(sku_data)} records to {output_file}...")
        save_to_csv(
            data=sku_data, output_file=output_file, ensure_sorted=csv_column_sort
        )

    except Exception as e:
        logger.error(f"Error exporting Azure SKU pricing: {e}", exc_info=True)
        raise typer.Exit(code=1)


# CLI Command for cost report
@ReportCommand.command(
    help="Export Azure cost data for each resource ID to a CSV file. "
    "Provides detailed cost insights at the resource level, helping with cost analysis and optimization."
)
def resource_cost(
    ctx: typer.Context,
    tenant_id: Optional[List[str]] = typer.Option(
        None,
        "-t",
        "--tenant",
        "--tenants",
        "--tenant-id",
        "--tenant-ids",
        help="Override the tenant ID(s) set at the azure group level.",
        callback=parse_multi_value_input,
    ),
    subscription_id: List[str] = COMMON_CLI_OPTIONS["subscription_id"],
    exclude_subscription_id: List[str] = COMMON_CLI_OPTIONS["exclude_subscription_id"],
    start_date: str = COMMON_CLI_OPTIONS["start_date"],
    end_date: str = COMMON_CLI_OPTIONS["end_date"],
    include_all_tags: bool = COMMON_CLI_OPTIONS["include_all_tags"],
    include_selected_tags: str = COMMON_CLI_OPTIONS["include_selected_tags"],
    tag_key_prefix: str = COMMON_CLI_OPTIONS["tag_prefix"],
    granularity: str = typer.Option(
        "None", help="Granularity of cost data.", metavar="None,Daily,Monthly"
    ),
    exclude_zero_cost_rows: bool = typer.Option(
        True, help="Exclude rows with zero or missing cost values."
    ),
    use_resource_graph_api: bool = typer.Option(
        False,
        help="Use Azure Resource Graph API to fetch tags instead of the standard method.",
    ),
    output_file: str = COMMON_CLI_OPTIONS["output_file"],
):
    try:
        if output_file is None:
            output_file = f"Report_Resource_Cost_{start_date.replace('-', '_')}_to_{end_date.replace('-', '_')}.csv"

        logger.debug(
            f"Function: resource_cost - Arguments: tenant_id={tenant_id}, subscription_id={subscription_id}, start_date={start_date}, end_date={end_date}, granularity={granularity}, include_all_tags={include_all_tags}, include_selected_tags={include_selected_tags}, tag_key_prefix={tag_key_prefix}, exclude_zero_cost_rows={exclude_zero_cost_rows}, use_resource_graph_api={use_resource_graph_api}, output_file={output_file}"
        )

        if use_resource_graph_api:
            get_tags = get_all_resource_tags_using_resourcegraph
        else:
            get_tags = get_resource_tags

        all_scope = resolve_scope_from_context(
            ctx,
            tenant_ids=tenant_id,
            subscription_ids=subscription_id,
            exclude_subscription_ids=exclude_subscription_id,
        )

        cost_data, tags_data = [], []

        for scope in all_scope:
            _tenant_id = scope["tenant_id"]
            credential = scope["credential"]
            _subscription_ids = scope["subscription_ids"]

            logger.debug(
                f"Found {len(_subscription_ids)} subscription ids in tenant {_tenant_id}. Which are: {_subscription_ids}"
            )

            for sub_id in _subscription_ids:
                logger.info(
                    f"Processing tenant ID {_tenant_id} where subscription ID: {sub_id}"
                )
                cost_data.extend(
                    get_cost_data(
                        credential=credential,
                        subscription_id=sub_id,
                        start_date=start_date,
                        end_date=end_date,
                        granularity=granularity,
                    )
                )
                if include_all_tags:
                    logger.debug("Fetching all tags.")
                    tags_data.extend(
                        get_tags(
                            credential=credential,
                            subscription_id=sub_id,
                            tag_key_prefix=tag_key_prefix,
                        )
                    )
                elif include_selected_tags:
                    logger.info(f"Fetching selected tags: {include_selected_tags}")
                    tags_data.extend(
                        get_tags(
                            credential=credential,
                            subscription_id=sub_id,
                            only_selected_tags=include_selected_tags,
                            tag_key_prefix=tag_key_prefix,
                        )
                    )

        if tags_data:
            logger.info("Merging cost data with tags.")
            final_data = join_list_of_dict(cost_data, tags_data, on="ResourceId")
        else:
            final_data = cost_data

        if exclude_zero_cost_rows:
            logger.info("Excluding rows with zero or missing cost values.")
            final_data = [
                row for row in final_data if row.get("Cost") not in (None, "")
            ]
            logger.debug(
                f"Removing these rows as their cost is zero {[row for row in cost_data if row.get('Cost') in (None, '')]}"
            )

        if not final_data:
            logger.warning("No data available to export.")
            return

        logger.debug(f"Final cost data: {final_data[:1]} (truncated)")
        save_to_csv(
            final_data,
            output_file,
            fixed_column_order=[
                "Tenant",
                "SubscriptionName",
                "ResourceGroupName",
                "ResourceCategory",
                "ResourceType",
                "ResourceName",
                "ResourceId",
                "Cost",
                "Currency",
            ],
        )

    except Exception as e:
        logger.error(
            f"An error occurred while executing command 'azure report-cost': {e}"
        )
        raise


# CLI Command for detailed cost report
@ReportCommand.command(
    help="Export detailed Azure resource cost data with additional information like usage details. "
    "Using the --group-by option, you can further segment the data for more granular analysis. "
    "The output is saved as a CSV file."
)
def resource_details_cost(
    ctx: typer.Context,
    tenant_id: Optional[List[str]] = typer.Option(
        None,
        "-t",
        "--tenant",
        "--tenants",
        "--tenant-id",
        "--tenant-ids",
        help="Override the tenant ID(s) set at the azure group level.",
        callback=parse_multi_value_input,
    ),
    subscription_id: List[str] = COMMON_CLI_OPTIONS["subscription_id"],
    exclude_subscription_id: List[str] = COMMON_CLI_OPTIONS["exclude_subscription_id"],
    start_date: str = COMMON_CLI_OPTIONS["start_date"],
    end_date: str = COMMON_CLI_OPTIONS["end_date"],
    include_all_tags: bool = COMMON_CLI_OPTIONS["include_all_tags"],
    include_selected_tags: List[str] = COMMON_CLI_OPTIONS["include_selected_tags"],
    tag_key_prefix: str = COMMON_CLI_OPTIONS["tag_prefix"],
    group_by: str = typer.Option(
        None,
        "--group-by",
        "--group",
        "-gb",
        help="Group the cost calculation by these attributes. [maximum : 10]",
        metavar="ResourceType,ResourceLocation,MeterCategory,MeterSubcategory,Meter,ServiceFamily,PartNumber,BillingAccountName,BillingProfileId,BillingProfileName,InvoiceSection,InvoiceSectionId,InvoiceSectionName,Product,ResourceGuid,ChargeType,ServiceName,ProductOrderId,ProductOrderName,PublisherType,ReservationId,ReservationName,Frequency,InvoiceId,PricingModel,CostAllocationRuleName,MarkupRuleName,BillingMonth,Provider,BenefitId,BenefitName,CustomerTenantId,TenantDomainName,ResellerMPNId,PartnerEarnedCreditApplied,PartnerName",
    ),
    granularity: str = typer.Option(
        "None",
        "--granularity",
        "-gr",
        help="Granularity of cost data.",
        metavar="None,Daily,Monthly",
    ),
    exclude_zero_cost_rows: bool = typer.Option(
        True, help="Exclude rows with zero or missing cost values."
    ),
    tag_source: str = COMMON_CLI_OPTIONS["tag_source"],
    output_file: str = COMMON_CLI_OPTIONS["output_file"],
):
    try:
        if output_file is None:
            output_file = f"Report_Resource_Details_Cost_{start_date}_to_{end_date}.csv"
        logger.debug(
            f"Function: resource_details_cost - Arguments: tenant_id={tenant_id}, subscription_id={subscription_id}, start_date={start_date}, end_date={end_date}, granularity={granularity}, include_all_tags={include_all_tags}, include_selected_tags={include_selected_tags}, tag_key_prefix={tag_key_prefix}, exclude_zero_cost_rows={exclude_zero_cost_rows}, tag_source={tag_source}, output_file={output_file}"
        )

        group_by = group_by.split(",") if group_by else []

        all_scope = resolve_scope_from_context(
            ctx,
            tenant_ids=tenant_id,
            subscription_ids=subscription_id,
            exclude_subscription_ids=exclude_subscription_id,
        )

        cost_data, tags_data = [], []

        for scope in all_scope:
            _tenant_id = scope["tenant_id"]
            tenant_domain = scope["tenant_domain"]
            credential = scope["credential"]
            _subscription_ids = scope["subscription_ids"]
            subscriptions = scope["subscriptions"]

            logger.debug(
                f"Found {len(_subscription_ids)} subscription ids in tenant {_tenant_id}. Which are: {_subscription_ids}"
            )

            logger.debug(f"Include selected tags: {include_selected_tags}")

            for sub in subscriptions:
                logger.info(
                    f"Processing Tenant:({tenant_domain})[{_tenant_id}] where subscription: ({sub.display_name})[{sub.subscription_id}]"
                )

                cost_data.extend(
                    get_cost_details_data(
                        credential=credential,
                        subscription_id=sub.subscription_id,
                        start_date=start_date,
                        end_date=end_date,
                        granularity=granularity,
                        group_by=group_by,
                    )
                )

                if include_all_tags or include_selected_tags:
                    tags_data.extend(
                        get_azure_resource_tags(
                            credential=credential,
                            method=tag_source,
                            subscription_id=sub.subscription_id,
                            tag_key_prefix=tag_key_prefix,
                            only_selected_tags=include_selected_tags,
                        )
                    )

        # Storing key of cost data for custom sorting data
        predefined_headers = [
            "Tenant",
            "SubscriptionName",
            "ResourceGroupName",
            "ResourceCategory",
            "ResourceType",
            "ResourceName",
            "ResourceId",
            "UsageQuantity",
            "UnitOfMeasure",
            "Cost",
            "Currency",
        ]
        _insert_position = (
            predefined_headers.index("ResourceName") + 1
        )  # Assuming you want to insert them after 'ResourceName' and before 'ResourceId'
        # Adding selected Tags to predefined headers
        if include_selected_tags:
            predefined_headers.extend(
                [f"{tag_key_prefix}{tag}" for tag in include_selected_tags]
            )
        # fixing output csv header order with group by columns as provided by user.
        if group_by:
            for grp in group_by:
                if grp not in predefined_headers:
                    predefined_headers.insert(_insert_position, grp)
                    _insert_position += 1

        _all_unique_header_of_cost_data = list(
            {key for d in cost_data for key in d.keys()}
        )  # Extract the unique headers from the list of dictionaries
        _header_which_are_not_added = [
            header
            for header in _all_unique_header_of_cost_data
            if header not in predefined_headers
        ]  # Find headers that are not in the predefined list
        # Insert the new headers after 'ResourceName' and before 'ResourceId'
        final_headers = (
            predefined_headers[:_insert_position]
            + _header_which_are_not_added
            + predefined_headers[_insert_position:]
        )
        logger.debug(f"Final headers after insertion: {final_headers}")

        if tags_data:
            logger.info("Merging cost data with tags.")
            cost_data = join_list_of_dict(cost_data, tags_data, on="ResourceId")

        if exclude_zero_cost_rows:
            logger.info("Excluding rows with zero or missing cost values.")
            cost_data = [row for row in cost_data if row.get("Cost") not in (None, "")]
            logger.debug(
                f"Removing these rows as their cost is zero {[row for row in cost_data if row.get('Cost') in (None, '')]}"
            )

        if not cost_data:
            logger.warning("No data available to export.")
            return

        logger.debug(f"Final cost data: {cost_data[:1]} (truncated)")
        save_to_csv(cost_data, output_file, fixed_column_order=final_headers)

    except Exception as e:
        logger.error(
            f"An error occurred while executing command 'azure report-details-cost': {e}"
        )
        raise


# CLI Command for detailed cost report
@ReportCommand.command(
    help="Export API response for Azure resource cost data to a CSV file. "
    "Note: This report is in an experimental state and may not provide fully refined data."
)
def resource_api_cost(
    ctx: typer.Context,
    tenant_id: Optional[List[str]] = typer.Option(
        None,
        "-t",
        "--tenant",
        "--tenants",
        "--tenant-id",
        "--tenant-ids",
        help="Override the tenant ID(s) set at the azure group level.",
        callback=parse_multi_value_input,
    ),
    subscription_id: List[str] = COMMON_CLI_OPTIONS["subscription_id"],
    exclude_subscription_id: List[str] = COMMON_CLI_OPTIONS["exclude_subscription_id"],
    start_date: str = COMMON_CLI_OPTIONS["start_date"],
    end_date: str = COMMON_CLI_OPTIONS["end_date"],
    output_file: str = COMMON_CLI_OPTIONS["output_file"],
):
    try:
        if output_file is None:
            output_file = f"Report_Api_Cost_{start_date}_to_{end_date}.csv"
        logger.debug(
            f"Function: resource_api_cost - Arguments: tenant_id={tenant_id}, subscription_id={subscription_id}, start_date={start_date}, end_date={end_date}, output_file={output_file}"
        )

        all_scope = resolve_scope_from_context(
            ctx,
            tenant_ids=tenant_id,
            subscription_ids=subscription_id,
            exclude_subscription_ids=exclude_subscription_id,
        )

        final_data = []
        for scope in all_scope:
            credential = scope["credential"]
            for sub_id in scope["subscription_ids"]:
                logger.debug(f"Processing subscription: {sub_id}")
                out = get_cost_data_by_api(
                    credential=credential,
                    subscription_id=sub_id,
                    start_date=start_date,
                    end_date=end_date,
                )
                final_data = final_data + out["value"]

        save_to_csv(
            data=flatten_json_data(final_data),
            output_file=output_file,
            fixed_column_order=["id"],
        )

    except Exception as e:
        logger.error(
            f"An error occurred while executing command 'azure report-api-cost': {e}"
        )
        raise


# CLI Command for direct cost report
@ReportCommand.command(
    help="A direct report that provides direct cost information for each Azure resource, without additional usage details. "
)
def resource_direct_cost(
    ctx: typer.Context,
    tenant_id: Optional[List[str]] = typer.Option(
        None,
        "-t",
        "--tenant",
        "--tenants",
        "--tenant-id",
        "--tenant-ids",
        help="Override the tenant ID(s) set at the azure group level.",
        callback=parse_multi_value_input,
    ),
    subscription_id: List[str] = COMMON_CLI_OPTIONS["subscription_id"],
    exclude_subscription_id: List[str] = COMMON_CLI_OPTIONS["exclude_subscription_id"],
    start_date: str = COMMON_CLI_OPTIONS["start_date"],
    end_date: str = COMMON_CLI_OPTIONS["end_date"],
    tag_key_prefix: str = COMMON_CLI_OPTIONS["tag_prefix"],
    include_extended_fields: bool = typer.Option(
        False, help="Include extended fields in the output."
    ),
    include_additional_info: bool = typer.Option(
        False, help="Include additional info fields in the output."
    ),
    output_file: str = COMMON_CLI_OPTIONS["output_file"],
):
    try:
        if output_file is None:
            output_file = f"Report_Resource_Details_Cost_{start_date}_to_{end_date}.csv"

        all_scope = resolve_scope_from_context(
            ctx,
            tenant_ids=tenant_id,
            subscription_ids=subscription_id,
            exclude_subscription_ids=exclude_subscription_id,
        )

        cost_data = []

        for scope in all_scope:
            _tenant_id = scope["tenant_id"]
            tenant_domain = scope["tenant_domain"]
            credential = scope["credential"]
            subscriptions = scope["subscriptions"]

            for sub in subscriptions:
                logger.info(
                    f"Processing Tenant:({tenant_domain})[{_tenant_id}] where subscription: ({sub.display_name})[{sub.subscription_id}]"
                )

                cost_data.extend(
                    get_resource_tags_and_cost_data_from_cost_management(
                        credential=credential,
                        subscription_id=sub.subscription_id,
                        start_date=start_date,
                        end_date=end_date,
                        tag_prefix=tag_key_prefix,
                        include_extended_fields=include_extended_fields,
                        include_additional_info=include_additional_info,
                    )
                )

        if not cost_data:
            logger.warning("No data available to export.")
            return

        logger.debug(f"Final cost data: {cost_data[:1]} (truncated)")
        save_to_csv(cost_data, output_file, ensure_sorted=False)

    except Exception as e:
        logger.error(
            f"An error occurred while executing command 'azure report-details-cost': {e}"
        )
        raise
