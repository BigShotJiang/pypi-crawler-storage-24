import click
import typer
import os
import re
import ast
from typing import List, Dict, Optional, Union
from gincloud.azure import (
    authenticate_to_azure,
    get_subscriptions,
    get_tenant_domain_using_credential,
)
from utils.logger import get_logger
from utils.context import AzureContext
from datetime import datetime, timedelta

# Logger
logger = get_logger("cli.azure.core")


def parse_multi_value_input(
    ctx: Optional[click.Context],
    param: Optional[click.Parameter],
    value: Optional[Union[str, List[str]]],
) -> List[str]:
    """
    Parse multi-value input (string or list) into a clean list of strings.

    Supports:
    - Multiple -t flags: -t value1 -t value2
    - Comma-separated: -t value1,value2
    - Slash-separated: -t value1/value2
    - Mixed: -t value1,value2 -t value3

    Args:
        ctx: Click/Typer context (automatically passed by Typer)
        param: Click parameter object (automatically passed by Typer)
        value: Input value (str | list[str] | None)

    Returns:
        list[str]: Parsed and trimmed list of values.
    """

    separators = (",", "/")

    try:
        if value is None or value == "":
            logger.debug(
                f"No value provided; returning empty list. where param: {param}"
            )
            return []

        # ---- FIX: Handle stringified list from Typer prompt ----
        if isinstance(value, str):
            stripped = value.strip()
            if stripped.startswith("[") and stripped.endswith("]"):
                try:
                    parsed = ast.literal_eval(stripped)
                    if isinstance(parsed, list):
                        value = parsed
                except Exception:
                    pass

        # ---- Handle list input ----
        if isinstance(value, list):
            result = []
            for item in value:
                if not item:
                    continue
                normalized = str(item).strip()
                for sep in separators:
                    normalized = normalized.replace(sep, ",")
                result.extend(v.strip() for v in normalized.split(",") if v.strip())
            return result

        # ---- Handle string input ----
        if isinstance(value, str):
            normalized = value.strip()
            for sep in separators:
                normalized = normalized.replace(sep, ",")
            return [v.strip() for v in normalized.split(",") if v.strip()]

        return []

    except Exception as ex:
        logger.error(
            f"Error parsing multi-value input '{value}': {ex}",
            exc_info=True,
        )
        return []

COMMON_CLI_OPTIONS = {
    "tenant_id": typer.Option(
        ...,
        "-t",
        "--tenant",
        "--tenants",
        "--tenant-id",
        "--tenant-name",
        "--tenant-ids",
        "--tenant-names",
       
        help="Azure Tenant ID(s). Provide a single Tenant ID or multiple IDs separated by commas.",
        prompt=True,
        callback=parse_multi_value_input,
    ),
    "subscription_id": typer.Option(
        ["all"],
        "-s",
        "--subscription",
        "--subscriptions",
        "--subscription-id",
        "--subscription-name",
        "--subscription-ids",
        "--subscription-names",
        "--sub",
        "--subs",
        help=(
            "Select Azure subscription(s) by ID or name. "
            "Provide one or more comma-separated values, "
            "or use 'all' to include all subscriptions in the tenant."
            ),
        prompt=False,
        callback=parse_multi_value_input,
    ),
    "exclude_subscription_id": typer.Option(
        None,
        "-xs",
        "-es",
        "--exclude-subscription",
        "--exclude-subscriptions",
        "--ignore-subscriptions",
        "--skip-subscriptions",
        "--not-subscriptions",
        "--no-sub",
        help="Comma-separated list of Subscription ID or Name to exclude from the report.",
        prompt=False,
        callback=parse_multi_value_input,
    ),
    "auth_method": typer.Option(
        os.getenv("GINCLOUD_DEFAULT_AZURE_AUTH_METHOD", "browser"),
        "-a",
        "--auth-method",
        "--auth-type",
        "--auth",
        help=(
            "Authentication method to use. "
            "Available options:\n\n"
            "  browser     - Authenticate via a web browser (interactive login).\n"
            "  powercert   - Authenticate using a certificate stored in the Windows certificate store (via PowerShell).\n"
            "  cli         - Use the currently signed-in Azure CLI session.\n"
            "  clientsecret - Authenticate using a Client ID and Client Secret.\n"
            "  token       - Use a pre-fetched access token.\n"
            "  managedidentity - Use Managed Identity (for Azure VMs or services with MSI enabled).\n"
            " powershell  - Authenticate using the current PowerShell session.\n\n"
        ),
        metavar="browser,powercert,cli,clientsecret,token,managedidentity,powershell",
        callback=parse_multi_value_input,
    ),
    "client_id": typer.Option(
        None,
        "-cid",
        "--client-id",
        "--app-id",
        "--application-id",
        help=(
            "The Azure Application (Client) ID.\n\n"
            "Required when using:\n"
            "  • clientsecret authentication\n"
            "  • powercert authentication\n\n"
            "Not required for other methods."
        ),
    ),
    "client_secret": typer.Option(
        None,
        "-cse",
        "--client-secret",
        "--secret",
        help=(
            "The Azure Client Secret.\n\n"
            "Required when using:\n"
            "  • clientsecret authentication\n\n"
            "Not used with other methods."
        ),
    ),
    "thumbprint": typer.Option(
        None,
        "-tmb",
        "--thumbprint",
        "--certificate-thumbprint",
        "--cert-thumb",
        "--thumb",
        help=(
            "The certificate thumbprint from the local certificate store.\n\n"
            "Required when using:\n"
            "  • powercert authentication\n\n"
            "Not used with other methods."
        ),
    ),
    "access_token": typer.Option(
        None,
        "-tkn",
        "--access-token",
        "--token",
        help=(
            "A pre-fetched Azure access token.\n\n"
            "Required when using:\n"
            "  • token authentication\n\n"
            "Not used with other methods."
        ),
    ),
    "start_date": typer.Option(
        (datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d"),
        "--start-date",
        "--from-date",
        "--start",
        "-sd",
        help="Start date for the cost query in 'yyyy-mm-dd' format.",
    ),
    "end_date": typer.Option(
        datetime.now().strftime("%Y-%m-%d"),
        "--end-date",
        "--till-date",
        "--to-date",
        "--end",
        "-ed",
        "-td",
        help="End date for the cost query in 'yyyy-mm-dd' format. Default: Today.",
    ),
    "include_all_tags": typer.Option(
        False,
        "--include-all-tags",
        "--all-tags",
        "--all-tag",
        "-at",
        help="Include all resource tags in the output.",
    ),
    "include_selected_tags": typer.Option(
        None,
        "--include-selected-tags",
        "--selected-tags",
        "--selected-tag",
        "--only-selected-tags",
        "-st",
        help="Comma-separated list of specific tags to include in the output.",
        callback=parse_multi_value_input,
    ),
    "tag_prefix": typer.Option(
        "tag_",
        "--tag-key-prefix",
        "--tag-prefix",
        "--prefix",
        "-tp",
        help="Prefix for all tag columns in the CSV file.",
        prompt=False,
    ),
    "tag_source": typer.Option(
        "resource",
        "--tag-source",
        "--tag-src",
        "-ts",
        help="Use option to get tags. 'resourcegraph' uses Resource Graph API, 'resource' uses Resource Export API, 'cost' uses Cost Management API to fetch tags. Default is 'costmanagement'.",
        metavar="resource,resourcegraph,cost",
    ),
    "output_file": typer.Option(
        None,
        "--output-file",
        "--output",
        "--out",
        "-o",
        help="Path to save the output file.",
    ),
    "allow_disable_subscriptions": typer.Option(
        False,
        "--allow-disable",
        "--allow-disable-subscriptions",
        "-ads",  # short alias
        help="Allow operations on disabled subscriptions. (This may cause errors or crashes.)",
    ),
    "allow_spending_limited_subscriptions": typer.Option(
        True,
        "--allow-spending-limit",
        "--allow-spending-limited-subscriptions",
        "-asls",  # unique short alias
        help="Allow operations on subscriptions with spending limits. ⚠️ This may cause errors or crashes.",
    ),
}


def resolve_azure_scope(
    tenant_ids: List[str],
    subscription_ids: List[str] = ["all"],
    excluded_subscription_ids: List[str] = [],
    include_spending_limit: bool = False,
    include_disabled: bool = False,
    auth_method: str = "browser",
    client_id: str = None,
    client_secret: str = None,
    thumbprint: str = None,
    access_token: str = None,
) -> list[dict]:
    """
    Resolve Azure scopes (tenants and subscriptions) based on provided identifiers.

    Args:
        tenant_ids (str): Comma-separated list of Azure tenant IDs.
        subscription_ids (str): Comma-separated list of Azure subscription IDs or "all".
        excluded_subscriptions (str): Comma-separated list of subscription IDs to exclude.
        auth_method (str): Azure authentication method (e.g., 'browser', 'client_secret', etc.).
        client_id (str): Azure AD application (client) ID.
        client_secret (str): Azure AD client secret.
        thumbprint (str): Certificate thumbprint (if using certificate-based auth).
        access_token (str): Direct access token for token-based authentication.

    Returns:
        list[dict]: List of resolved Azure scopes containing tenant, subscriptions, and credentials.
    """
    logger.debug("Parsing Azure scope input parameters.")

    logger.debug(
        {
            "tenants": tenant_ids,
            "requested_subscriptions": subscription_ids,
            "excluded_subscriptions": excluded_subscription_ids,
        }
    )

    scopes = []

    for tenant in tenant_ids:
        logger.debug(
            f"Authenticating to Azure (tenant: {tenant}, method: {auth_method})."
        )

        credential = authenticate_to_azure(
            tenant_id=tenant,
            auth_method=auth_method,
            client_id=client_id,
            client_secret=client_secret,
            thumbprint=thumbprint,
            access_token=access_token,
        )

        if not subscription_ids or 'all' in subscription_ids or subscription_ids == ["['all']"] or subscription_ids == []:
            subscription_ids = None
            
        available_subscriptions = get_subscriptions(
            credential=credential,
            exclude_subscriptions=excluded_subscription_ids,
            select_subscriptions=subscription_ids,
            include_spending_limit=include_spending_limit,
            include_disabled=include_disabled,
        )

        filtered_subscription_ids = [
                sub_id.subscription_id
                for sub_id in available_subscriptions
            ]

        scope_entry = {
            "tenant_id": tenant,
            "tenant_domain": get_tenant_domain_using_credential(credential),
            "subscription_ids": filtered_subscription_ids,
            "credential": credential,
            "subscriptions": available_subscriptions,
        }
        scopes.append(scope_entry)

        logger.debug(f"Resolved tenant scope: {scope_entry}")

    logger.info(
    "Azure authentication and scope resolution completed successfully "
    "for %d tenant(s) using '%s' authentication.",
    len(scopes),
    auth_method,
    )

    return scopes


def convert_comma_separated_string_into_list_of_string(value: str) -> list[str]:
    """Parses a comma-separated string into a list of strings."""
    return value.split(",") if value else []


def parse_tag_inputs(tag_inputs: List[str]) -> Dict[str, str]:
    """
    Parses multiple tag formats into a dictionary.

    Supports formats like:
      - tag1=value1,tag2=value2
      - tag1:value1,tag2:value2
      - 'tag':'value','tag2':'value2'
      - "tag":"value","tag2":"value2"
      - multiple --tag "key:value" options
    """
    tags: Dict[str, str] = {}

    for raw in tag_inputs:
        # Normalize and clean input
        cleaned = raw.strip().strip("{} ").strip("'\"")

        # Split if comma-separated group
        parts = re.split(r"\s*,\s*", cleaned)

        for part in parts:
            if not part:
                continue

            # Match key-value pairs separated by :, =, or JSON-like quotes
            match = re.match(
                r"['\"]?([\w\-.]+)['\"]?\s*[:=]\s*['\"]?([\w\-.]+)['\"]?", part.strip()
            )
            if match:
                key, value = match.groups()
                tags[key] = value
            else:
                # Handle keys with empty value or invalid pairs gracefully
                key = part.strip().strip("'\"")
                if key:
                    tags[key] = ""

    return tags


# ─────────────────────────── Context-aware scope resolution ──────────────────

def resolve_scope_from_context(
    ctx: typer.Context,
    *,
    # Per-command overrides — each defaults to None, meaning "use context value"
    tenant_ids: Optional[List[str]] = None,
    subscription_ids: Optional[List[str]] = None,
    exclude_subscription_ids: Optional[List[str]] = None,
    auth_method: Optional[List[str]] = None,
    client_id: Optional[str] = None,
    client_secret: Optional[str] = None,
    thumbprint: Optional[str] = None,
    access_token: Optional[str] = None,
    include_disabled: Optional[bool] = None,
    include_spending_limit: Optional[bool] = None,
) -> list:
    """
    Resolve Azure auth + scope by merging command-level overrides with the
    ``AzureContext`` stored in ``ctx.obj`` by the ``azure`` group callback.

    Precedence (highest → lowest):
      1. Explicit keyword argument to this function  (command-level override)
      2. Value from ``ctx.obj`` (set by ``azure`` group callback)
      3. ``AzureContext`` dataclass defaults (env-var → hard-coded default)

    If ``tenant_ids`` is still empty after merging, the user is prompted
    interactively so no command ever silently operates on no tenants.

    Args:
        ctx:   Typer/Click context carrying ``ctx.obj: AzureContext``.
        **:    Optional per-command overrides for any auth/scope param.

    Returns:
        list[dict] — same structure as ``resolve_azure_scope()``.
    """
    az: AzureContext = ctx.obj if isinstance(ctx.obj, AzureContext) else AzureContext()

    # Merge: override (if not None/empty) > context > dataclass default
    def _pick(override, ctx_val):
        """Return override when it carries a real value, else fall back to ctx."""
        if override is not None and override != [] and override != [""]:
            return override
        return ctx_val

    effective_tenants      = _pick(tenant_ids, az.tenant_ids)
    effective_subs         = _pick(subscription_ids, az.subscription_ids)
    effective_excludes     = _pick(exclude_subscription_ids, az.exclude_subscription_ids)
    effective_auth         = _pick(auth_method, az.auth_method)
    effective_client_id    = client_id    or az.client_id
    effective_secret       = client_secret or az.client_secret
    effective_thumbprint   = thumbprint    or az.thumbprint
    effective_token        = access_token  or az.access_token
    effective_disabled     = az.allow_disable     if include_disabled     is None else include_disabled
    effective_spending     = az.allow_spending_limit if include_spending_limit is None else include_spending_limit

    # Prompt for tenant if still unset (only interactive fallback)
    if not effective_tenants:
        raw = typer.prompt(
            "Azure Tenant ID (or comma-separated list)",
            prompt_suffix=": ",
        )
        effective_tenants = parse_multi_value_input(None, None, raw)

    return resolve_azure_scope(
        tenant_ids=effective_tenants,
        subscription_ids=effective_subs,
        excluded_subscription_ids=effective_excludes,
        auth_method=effective_auth,
        client_id=effective_client_id,
        client_secret=effective_secret,
        thumbprint=effective_thumbprint,
        access_token=effective_token,
        include_disabled=effective_disabled,
        include_spending_limit=effective_spending,
    )
