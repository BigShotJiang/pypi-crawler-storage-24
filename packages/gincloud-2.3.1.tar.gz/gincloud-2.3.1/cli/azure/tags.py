import typer
import os
from datetime import datetime
import pandas as pd
from typing import Optional, List
from azure.mgmt.resource import ResourceManagementClient
from cli.azure.core import parse_tag_inputs
from utils import interactive_select_from_list
from gincloud.azure.tags import get_azure_resource_tags
from utils import save_to_csv
from gincloud.azure.tags import (
    get_resource_tags,
    get_all_resource_tags_using_resourcegraph,
    update_tags_using_resource_id,
)

from cli.azure.core import (
    convert_comma_separated_string_into_list_of_string,
    parse_multi_value_input,
    resolve_scope_from_context,
    COMMON_CLI_OPTIONS,
)

from utils.logger import get_logger

# Logger
logger = get_logger("cli.azure.tags")
TagCommand = typer.Typer(
    name="tag",
    help="Commands for managing Azure resource tags, including exporting, filtering, and updating tag information.",
)


@TagCommand.command(
    help="Export Azure resource tags data to a CSV file, including ResourceId. "
    "Supports updating existing files. "
    "Note: This feature is in an experimental state, so use it cautiously."
)
def export_update(
    ctx: typer.Context,
    tenant_id: Optional[List[str]] = typer.Option(
        None,
        "-t",
        "--tenant",
        "--tenants",
        "--tenant-id",
        "--tenant-ids",
        help="Override the tenant ID(s) set at the azure group level.",
        callback=parse_multi_value_input,
    ),
    subscription_id: List[str] = COMMON_CLI_OPTIONS["subscription_id"],
    exclude_subscription_id: List[str] = COMMON_CLI_OPTIONS["exclude_subscription_id"],
    output_entry_type: str = typer.Option(
        "update",
        metavar="append,update",
        help="Output entry type (e.g., append).",
        prompt=False,
    ),
    include_selected_tags: str = COMMON_CLI_OPTIONS["include_selected_tags"],
    tag_key_prefix: str = COMMON_CLI_OPTIONS["tag_prefix"],
    use_resource_graph_api: bool = typer.Option(
        False, help="Use Resource Graph API for tags retrieval."
    ),
    output_file: str = typer.Option(
        "Export_Resource_Tags.csv", help="Path to save the output CSV file."
    ),
):
    try:
        tags_data = []

        # Decide which function to use for fetching tags
        get_tags = (
            get_all_resource_tags_using_resourcegraph
            if use_resource_graph_api
            else get_resource_tags
        )

        all_scope = resolve_scope_from_context(
            ctx,
            tenant_ids=tenant_id,
            subscription_ids=subscription_id,
            exclude_subscription_ids=exclude_subscription_id,
        )

        for scope in all_scope:
            _tenant_id = scope["tenant_id"]
            _credential = scope["credential"]
            _subscription_ids = scope["subscription_ids"]

            logger.debug(
                f"Found {len(_subscription_ids)} subscription(s) for tenant {_tenant_id}: {_subscription_ids}"
            )

            for sub_id in _subscription_ids:
                logger.info(
                    f"Processing tenant ID {_tenant_id}, subscription ID: {sub_id}"
                )

                if include_selected_tags:
                    selected_tags = include_selected_tags.split(",") or []
                    logger.info(f"Fetching selected tags: {selected_tags}")
                    tags_data += get_tags(
                        credential=_credential,
                        subscription_id=sub_id,
                        include_selected_tags=selected_tags,
                        tag_key_prefix=tag_key_prefix,
                    )
                else:
                    logger.info("Fetching all tags.")
                    tags_data += get_tags(
                        credential=_credential,
                        subscription_id=sub_id,
                        tag_key_prefix=tag_key_prefix,
                    )

        logger.info(f"Total records fetched: {len(tags_data)}")

        if not tags_data:
            logger.warning("No data available to export.")
            return

        # Add timestamp column to tags_data
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        for record in tags_data:
            record["DataInsertedTime"] = timestamp

        # Convert to DataFrame and reorder columns
        tags_df = pd.DataFrame(tags_data)
        columns = ["DataInsertedTime"] + [
            col for col in tags_df.columns if col != "DataInsertedTime"
        ]
        tags_df = tags_df[columns]

        # Handle output
        if os.path.exists(output_file):
            logger.info(f"Loading existing data from '{output_file}'.")
            existing_data = pd.read_csv(output_file)
            logger.info(f"Existing data contains {len(existing_data)} records.")

            if output_entry_type == "append":
                # Append only new rows based on 'ResourceId'
                new_data = tags_df[
                    ~tags_df["ResourceId"].isin(existing_data["ResourceId"])
                ]
                logger.info(f"New rows to append: {len(new_data)}")

                # Combine and save
                updated_data = pd.concat([existing_data, new_data], ignore_index=True)
            elif output_entry_type == "update":
                # Update rows where 'ResourceId' matches and append new rows
                combined_data = pd.concat([existing_data, tags_df], ignore_index=True)
                updated_data = combined_data.drop_duplicates(
                    subset=["ResourceId"], keep="last"
                )
                logger.info(f"Updated data now contains {len(updated_data)} records.")
        else:
            logger.info(
                f"Creating new file '{output_file}' with {len(tags_df)} records."
            )
            updated_data = tags_df

        # Save the updated or new data to CSV
        updated_data.to_csv(output_file, index=False)
        logger.info(f"Data successfully saved to '{output_file}'.")

    except Exception as e:
        logger.error(
            f"An error occurred while executing command 'azure report-tags': {e}"
        )
        raise


@TagCommand.command(
    help="Export Azure resource tags data to a CSV file with advanced filtering and contextual options. "
    "Supports tag-based filtering, selection of specific tags, and structured tag data extraction "
)
def export(
    ctx: typer.Context,
    tenant_id: Optional[List[str]] = typer.Option(
        None,
        "-t",
        "--tenant",
        "--tenants",
        "--tenant-id",
        "--tenant-ids",
        help="Override the tenant ID(s) set at the azure group level.",
        callback=parse_multi_value_input,
    ),
    subscription_id: List[str] = COMMON_CLI_OPTIONS["subscription_id"],
    exclude_subscription_id: List[str] = COMMON_CLI_OPTIONS["exclude_subscription_id"],
    include_selected_tags: str = COMMON_CLI_OPTIONS["include_selected_tags"],
    filter_tag: str = typer.Option(
        None,
        help="Comma-separated list of specific tags and values to filter resources. "
        "Example: 'tag1:value1,tag2:value2'. Use '*' for any value and leave blank for null values.",
    ),
    tag_key_prefix: str = COMMON_CLI_OPTIONS["tag_prefix"],
    tag_source: str = COMMON_CLI_OPTIONS["tag_source"],
    output_file: str = COMMON_CLI_OPTIONS["output_file"],
):
    try:
        if output_file is None:
            output_file = "Export_Resource_Tags.csv"

        tags_data = []

        all_scope = resolve_scope_from_context(
            ctx,
            tenant_ids=tenant_id,
            subscription_ids=subscription_id,
            exclude_subscription_ids=exclude_subscription_id,
        )

        for scope in all_scope:
            tenant_domain = scope.get("tenant_domain", "unknownTenant")
            subscriptions = scope.get("subscriptions", [])
            _credential = scope["credential"]
            _subscription_ids = scope["subscription_ids"]

            for sub_id in _subscription_ids:
                new_tags = get_azure_resource_tags(
                    credential=_credential,
                    subscription_id=sub_id,
                    method=tag_source,
                    only_selected_tags=include_selected_tags,
                    tag_key_prefix=tag_key_prefix,
                    include_resource_metadata=True,
                )

                for record in new_tags:
                    resource_info = record.get("ResourceId").split("/")
                    if "ResourceGroup" not in record:
                        record["ResourceGroup"] = resource_info[4]
                    if "ResourceCategory" not in record:
                        record["ResourceCategory"] = resource_info[6]
                    if "ResourceType" not in record:
                        record["ResourceType"] = resource_info[7]
                    if "ResourceName" not in record:
                        record["ResourceName"] = resource_info[-1]
                    if "SubscriptionId" not in record:
                        record["SubscriptionId"] = resource_info[2]
                    if "SubscriptionName" not in record:
                        record["SubscriptionName"] = next(
                            (
                                sub.display_name
                                for sub in subscriptions
                                if sub.subscription_id == resource_info[2]
                            ),
                            None,
                        )
                    if "Tenant" not in record:
                        record["Tenant"] = tenant_domain

                tags_data += new_tags

        logger.info(f"Total records fetched: {len(tags_data)}")

        if not tags_data:
            logger.warning("No data available to export.")
            return

        # Convert to DataFrame and reorder columns
        tags_df = pd.DataFrame(tags_data)

        # Select only specified tags if provided and resource info available
        if include_selected_tags:
            logger.info(f"Filtering to only selected tags: {include_selected_tags}")

            # Add prefix and check if they exist in DataFrame
            filtered_columns = [
                f"{tag_key_prefix}{tag}" for tag in include_selected_tags
            ]
            existing_filtered_columns = [
                col for col in filtered_columns if col in tags_df.columns
            ]

            # Warn about missing tags
            missing_columns = set(filtered_columns) - set(existing_filtered_columns)
            if missing_columns:
                logger.warning(
                    f"The following specified tags were not found in the data and will be ignored: {missing_columns}"
                )

            # Final selection of tag columns
            selected_tag_columns = existing_filtered_columns

            # Always keep base columns
            base_columns = [
                "Tenant",
                "SubscriptionName",
                "SubscriptionId",
                "ResourceGroup",
                "ResourceType",
                "ResourceId",
                "ResourceName",
            ]

            # Filter dataframe
            tags_df = tags_df[base_columns + selected_tag_columns]

        if filter_tag:
            filter_conditions = filter_tag.split(",")  # Split by comma

            for condition in filter_conditions:
                tag, value = condition.split(":", 1)  # Split into tag & value

                # Ensure "tag_" prefix is added
                column_name = f"{tag_key_prefix}{tag}"

                if column_name in tags_df.columns:  # Check if column exists
                    if value == "*":
                        continue  # Wildcard, skip filtering for this tag
                    elif value == "":
                        tags_df = tags_df[
                            tags_df[column_name].isna()
                        ]  # Filter NULL values
                    else:
                        tags_df = tags_df[tags_df[column_name] == value]  # Exact match

        # Save the updated or new data to CSV
        col_oder = [
            "Tenant",
            "SubscriptionName",
            "SubscriptionId",
            "ResourceGroup",
            "ResourceCategory",
            "ResourceType",
            "StockKeepingUnit",
            "ResourceId",
            "ResourceName",
        ]
        if include_selected_tags:
            col_oder = col_oder + selected_tag_columns
        # Replace NaN with None (or "" if you prefer blanks)
        tags_df = tags_df.where(pd.notnull(tags_df), None)

        save_to_csv(
            data=tags_df.to_dict(orient="records"),
            output_file=output_file,
            fixed_column_order=col_oder,
        )

    except Exception as e:
        logger.error(
            f"An error occurred while executing command 'azure tag export': {e}"
        )
        raise


@TagCommand.command(
    help="Update Azure resource tags using a CSV input file. "
    "Supports bulk tag modifications, including merging, replacing, and deleting tags. "
    "Allows filtering of specific tags and defining custom update conditions. "
    "Updates only those rows where the specified --col-action-key matches the --col-action-value."
)
def update(
    ctx: typer.Context,
    tenant_id: Optional[List[str]] = typer.Option(
        None,
        "-t",
        "--tenant",
        "--tenants",
        "--tenant-id",
        "--tenant-ids",
        help="Override the tenant ID(s) set at the azure group level.",
        callback=parse_multi_value_input,
    ),
    subscription_id: List[str] = COMMON_CLI_OPTIONS["subscription_id"],
    exclude_subscription_id: List[str] = COMMON_CLI_OPTIONS["exclude_subscription_id"],
    input_csv: str = typer.Option(
        ...,
        "-i",
        "--input-csv",
        "--csv",
        help="Path to the input CSV file containing resource IDs and tag update details.",
        prompt=True,
    ),
    operation: str = typer.Option(
        "merge",
        help="Specify the update operation. Options: 'merge' (add/update tags), 'replace' (overwrite all tags), or 'delete' (remove specified tags) or 'append' (append tags) which are not there in the destination resource.",
        metavar="merge,replace,delete,append",
    ),
    output_csv: str = COMMON_CLI_OPTIONS["output_file"],
    tag_key_prefix: str = COMMON_CLI_OPTIONS["tag_prefix"],
    tag_to_update: str = typer.Option(
        None,
        help="Comma-separated list of specific tags to update. If not provided, all tags in the CSV will be considered.",
        prompt=False,
        callback=convert_comma_separated_string_into_list_of_string,
    ),
    col_resource_id_key=typer.Option(
        "ResourceId",
        help="Column name in the input CSV file that contains the Azure resource IDs.",
        prompt=False,
    ),
    col_action_key: str = typer.Option(
        "action",
        help="Column name in the input CSV that specifies the action type for each resource.",
        prompt=False,
    ),
    col_action_value: str = typer.Option(
        "update",
        help="Filter condition: only rows where this column --col-action-key has the specified value will be updated.",
        prompt=False,
    ),
):
    try:
        # Parse tenant IDs
        if output_csv is None:
            output_csv = (
                f"Tag_Update_Result_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            )

        result = []

        _load_csv_dataframe = pd.read_csv(input_csv, low_memory=False, keep_default_na=False, na_values=[''])
        if _load_csv_dataframe.empty:
            logger.error(f"provided csv is not valid {input_csv}")
            return

        all_scope = resolve_scope_from_context(
            ctx,
            tenant_ids=tenant_id,
            subscription_ids=subscription_id,
            exclude_subscription_ids=exclude_subscription_id,
        )

        for scope in all_scope:
            _tenant_id = scope["tenant_id"]
            _credential = scope["credential"]
            _subscription_ids = scope["subscription_ids"]

            for sub_id in _subscription_ids:
                logger.info(
                    f"Updating tags on scope :-> tenant_id:{_tenant_id}, subscription_id: {sub_id}"
                )

                _load_csv_dataframe_sub_filtered = _load_csv_dataframe[
                    _load_csv_dataframe[col_resource_id_key].str.split("/").str[2]
                    == sub_id
                ]

                logger.debug(
                    f"Found {_load_csv_dataframe_sub_filtered.shape[0]} rows for Subscription ID '{sub_id}' in the provided CSV file."
                )
                logger.info(
                    f"Found {_load_csv_dataframe_sub_filtered[_load_csv_dataframe_sub_filtered[col_action_key] == col_action_value].shape[0]} actionable rows for Subscription ID '{sub_id}', where column '{col_action_key}' has the value '{col_action_value}'."
                )

                for index, row in _load_csv_dataframe_sub_filtered.iterrows():
                    resource_id = row[col_resource_id_key]
                    if (
                        row[col_action_key] == col_action_value
                    ):  # Ensuring case-insensitive comparison
                        tag_keys_to_update = (
                            [
                                f"{tag_key_prefix}{tag}" for tag in tag_to_update
                            ]  # Remove "tag_" if tags are provided
                            if tag_to_update
                            else [
                                tag
                                for tag in row.index
                                if tag.startswith(tag_key_prefix)
                            ]  # Remove "tag_" from existing columns
                        )

                        # Collect the tags to be updated (removing 'tag_' prefix)
                        updated_tags = {
                            tag.replace(tag_key_prefix, ""): row[
                                tag
                            ]  # Remove 'tag_' prefix
                            for tag in tag_keys_to_update
                            if not pd.isna(row[tag])
                        }

                        result.append(
                            update_tags_using_resource_id(
                                credential=_credential,
                                resource_id=resource_id,
                                new_tags=updated_tags,
                                operation=operation,
                            )
                        )
        df_result = pd.DataFrame(result)
        df_result.to_csv(output_csv, index=False)
        logger.info(
            f"Tag update operation is completed successfully , for more info check output csv at {output_csv}"
        )

    except Exception as e:
        logger.error(
            f"An error occurred while update tag using  command 'azure tag update' due to: {e}"
        )
        raise


@TagCommand.command(name="copy", help="Copy tags from one Azure resource to another.")
def copy(
    ctx: typer.Context,
    tenant_id: Optional[List[str]] = typer.Option(
        None,
        "-t",
        "--tenant",
        "--tenants",
        "--tenant-id",
        "--tenant-ids",
        help="Override the tenant ID(s) set at the azure group level.",
        callback=parse_multi_value_input,
    ),
    source_resource_id: str = typer.Argument(
        ..., help="Source resource ID to copy tags from."
    ),
    destination_resource_ids: str = typer.Argument(
        ...,
        help="Destination resource ID(s) to copy tags to.",
        callback=convert_comma_separated_string_into_list_of_string,
    ),
    operation: str = typer.Option(
        "merge",
        help="Specify the update operation. Options: 'merge' (add/append tags), 'replace' (remove and overwrite all tags) 'append' (append tags) which are not there in the destination resource. ",
        metavar="merge,replace,append",
    ),
):
    """
    Copy tags from a source resource to one or more destination resources.
    Supports multiple tenants and subscriptions.
    Auth scopes are resolved once and matched to relevant subscriptions.
    """
    try:
        # --- Extract subscription IDs
        source_subscription_id = source_resource_id.split("/")[2]
        destination_sub_ids = [rid.split("/")[2] for rid in destination_resource_ids]
        all_sub_ids = list(set([source_subscription_id] + destination_sub_ids))

        # --- Resolve authentication scopes ONCE
        scopes = resolve_scope_from_context(
            ctx,
            tenant_ids=tenant_id,
            subscription_ids=all_sub_ids,
        )

        # --- Helper: find matching credential for a subscription ID
        def get_scope_for_subscription(sub_id: str):
            for s in scopes:
                if sub_id in s.get("subscription_ids", []):
                    return s
            return None

        # --- Fetch source tags
        source_scope = get_scope_for_subscription(source_subscription_id)
        if not source_scope:
            logger.error(
                f"No valid scope found for source subscription: {source_subscription_id} with in tenant {tenant_id}"
            )
            return

        credential = source_scope["credential"]
        tenant = source_scope["tenant_id"]

        try:
            resource_client = ResourceManagementClient(
                credential, source_subscription_id
            )
            source_resource = resource_client.resources.get_by_id(
                source_resource_id, api_version="2021-04-01"
            )
            source_tags = source_resource.tags or {}
            logger.info(f"SOURCE TAGS: {source_tags} from ResourceId: [{source_resource_id}] Tenant: [{tenant}]")
        except Exception as e:
            logger.error(f"Failed to fetch source tags from ResourceId: [{source_resource_id}] Tenant: [{tenant}] Due to :-> {e}")
            return

        if not source_tags:
            logger.warning(f"No tags found on source ResourceId: [{source_resource_id}] Tenant: [{tenant}]")
            return

        if operation.lower() == "delete":
            logger.error("Delete operation is not supported for copy command.")
            return

        # --- Process each destination resource
        for destination_resource_id in destination_resource_ids:
            dest_sub_id = destination_resource_id.split("/")[2]
            dest_scope = get_scope_for_subscription(dest_sub_id)

            if not dest_scope:
                logger.warning(
                    f" ResourceID {destination_resource_id}. No valid scope found for destination subscription: {dest_sub_id} with in tenant {tenant_id}, skipping..."
                )
                continue

            dest_credential = dest_scope["credential"]
            dest_tenant = dest_scope["tenant_id"]

            try:
                result = update_tags_using_resource_id(
                    credential=dest_credential,
                    resource_id=destination_resource_id,
                    new_tags=source_tags,
                    operation=operation.lower(),
                )

                if result.get("after_change_tags"):
                    logger.info(
                        f"DESTINATION TAGS (changed):{ result.get("after_change_tags", {})} for ResourceId: [{destination_resource_id}] Tenant: [{dest_tenant}]."
                    )
                else:
                    logger.info(
                        f"DESTINATION TAGS (unchanged): {result.get("before_change_tags", {})} for ResourceId: [{destination_resource_id}] Tenant: [{dest_tenant}]."
                    )
            except Exception as e:
                logger.error(
                    f"Failed to update tags for ResourceId: [{destination_resource_id}]  Tenant: [{dest_tenant}]. Due to :-> {e}"
                )

    except Exception as e:
        logger.error(
            f"An error occurred while update tag using  command 'azure tag update' due to: {e}"
        )
        raise


@TagCommand.command(
    help="Add tags to Azure resources by interactively selecting resources."
)
def select_update(
    ctx: typer.Context,
    tenant_id: Optional[List[str]] = typer.Option(
        None,
        "-t",
        "--tenant",
        "--tenants",
        "--tenant-id",
        "--tenant-ids",
        help="Override the tenant ID(s) set at the azure group level.",
        callback=parse_multi_value_input,
    ),
    input_tags: List[str] = typer.Option(
        ..., "--tag", "--tags", help="Tags in various formats", prompt=True
    ),
    operation: str = typer.Option(
        "merge",
        help="Specify the update operation. Options: 'merge' (add/append tags), 'replace' (remove and overwrite all tags) 'append' (append tags) which are not there in the destination resource.",
        metavar="merge,replace,append",
    ),
):
    tag_dict = parse_tag_inputs(input_tags)
    logger.warning(f"Provided Tags: {tag_dict}")

    # Step 0: Resolve Azure scope
    all_scope = resolve_scope_from_context(ctx, tenant_ids=tenant_id)

    # Prepare a flat list of resources to update
    resources_to_update = []

    for scope in all_scope:
        tenant_domain = scope.get("tenant_domain", "unknownTenant")
        subscriptions = scope.get("subscriptions", [])
        credential = scope.get("credential")

        # Step 1: Select subscriptions
        subscription_names = [sub.display_name for sub in subscriptions]
        selected_sub_names = interactive_select_from_list(
            data=subscription_names,
            title=f"Select target subscriptions under tenant {tenant_domain}",
        )
        selected_subscriptions = [
            sub for sub in subscriptions if sub.display_name in selected_sub_names
        ]

        for sub in selected_subscriptions:
            client = ResourceManagementClient(credential, sub.subscription_id)

            # Step 2: Select Resource Groups
            rg_list = list(client.resource_groups.list())
            rg_names = [rg.name for rg in rg_list]
            selected_rg_names = interactive_select_from_list(
                data=rg_names,
                title=f"Select resource groups under subscription {sub.display_name}",
            )
            selected_rgs = [rg for rg in rg_list if rg.name in selected_rg_names]

            for rg in selected_rgs:
                # Step 3: List all resources in this RG
                resources = list(client.resources.list_by_resource_group(rg.name))
                resource_types = sorted(set(res.type for res in resources))

                # Step 4: Select resource types
                selected_types = interactive_select_from_list(
                    data=resource_types,
                    title=f"Select resource types in resource group {rg.name}",
                )

                for r_type in selected_types:
                    selected_resources = [
                        res for res in resources if res.type == r_type
                    ]
                    resource_names = [res.name for res in selected_resources]
                    selected_resource_names = interactive_select_from_list(
                        data=resource_names,
                        title=f"Select resources of type {r_type} in RG {rg.name}",
                    )
                    final_resources = [
                        res
                        for res in selected_resources
                        if res.name in selected_resource_names
                    ]

                    # Add to the global update list
                    for resource in final_resources:
                        resources_to_update.append(
                            {
                                "tenant_domain": tenant_domain,
                                "subscription_name": sub.display_name,
                                "resource_group": rg.name,
                                "resource_type": r_type,
                                "resource": resource,
                                "credential": credential,
                            }
                        )

    # Step 5: Update tags after all selections
    for res_info in resources_to_update:
        _out = update_tags_using_resource_id(
            credential=res_info["credential"],
            resource_id=res_info["resource"].id,
            new_tags=tag_dict,
            operation=operation,
        )
        logger.debug(f"Tag copy operation result: {_out}")

        final_tags = (
            _out.get("after_change_tags") or _out.get("before_change_tags") or {}
        )
        logger.info(
            "[TAG UPDATE SUCCESS] "
            f"Tenant: {res_info['tenant_domain']} | "
            f"Subscription: {res_info['subscription_name']} | "
            f"Resource Group: {res_info['resource_group']} | "
            f"Resource Type: {res_info['resource_type']} | "
            f"Resource Name: {res_info['resource'].name} | "
            f"Tags: {final_tags}"
        )
