import typer
from  cli.monitoring.aggregation import AggregationCommand   

MonitoringCommand = typer.Typer(name="monitoring", help="Command for managing monitoring")
MonitoringCommand.add_typer(AggregationCommand)