
import typer
from datetime import datetime,timedelta
from utils.logger import get_logger
from monitoring.aggregation import PrometheusToMSSQL, ConfigLoader

logger = get_logger("cli.monitoring.aggregation")


AggregationCommand = typer.Typer(name="aggregate", help="Command for aggregating metrics")

@AggregationCommand.command("availability-to-mssql", help="Aggregate availability metrics and save into MS SQL database")
def aggrage_and_save_into_mssql_database(
    date: str = typer.Option(..., "--date", "-d", help="Date in YYYY-MM-DD format"),
    config: str = typer.Option("config.yaml", "--config", "-c", help="Path to the configuration file")    
):
    cfg = ConfigLoader.load(config, {})

    exporter = PrometheusToMSSQL(cfg)
    exporter.connect()
    exporter.create_table()

    target_date = (
        datetime.strptime(date, "%Y-%m-%d").date()
        if date else
        (datetime.now() - timedelta(days=1)).date()
    )

    metrics = exporter.calculate_daily_metrics(target_date)
    exporter.save_metrics(metrics)
    exporter.close()

    logger.info("Daily availability export completed successfully")
