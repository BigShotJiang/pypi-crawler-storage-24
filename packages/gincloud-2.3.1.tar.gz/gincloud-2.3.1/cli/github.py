import typer
import os
from utils.github import GitHubManager
from typing import Optional
from utils.logger import get_logger
from utils.environment import ensure_env

logger = get_logger("cli.github")

GitHubCommand = typer.Typer(
    name="github", help="Command for managing Github repositories and files"
)


@GitHubCommand.command(
    help="Download a file or directory from the latest committed branch on GitHub."
)
def download(
    token: Optional[str] = None,
    repo_owner: Optional[str] = None,
    repo_name: Optional[str] = None,
    branch_name: Optional[str] = "main",
    repo_dir_path: Optional[str] = None,
    repo_file_path: Optional[str] = None,
    output_dir: str = os.getcwd(),
):
    """Download files from a branch"""
    branch_name = branch_name.lower()
    logger.debug(
        f"get_branch called with name={branch_name}, dir={repo_dir_path}, file={repo_file_path}"
    )
    if not token:
        token = ensure_env("GINCLOUD_GITHUB_TOKEN")
    if not repo_owner:
        repo_owner = ensure_env("GINCLOUD_GITHUB_OWNER")
    if not repo_name:
        repo_name = ensure_env("GINCLOUD_GITHUB_REPO")

    github = GitHubManager(token=token, owner=repo_owner, repo=repo_name)

    if repo_dir_path:
        github.download_directory(
            repo_dir_path=repo_dir_path, reference=branch_name, output_dir=output_dir
        )
    elif repo_file_path:
        github.download_file(
            repo_file_path=repo_file_path, reference=branch_name, output_dir=output_dir
        )
    else:
        github.download_repository(branch_name=branch_name, output_dir=output_dir)
