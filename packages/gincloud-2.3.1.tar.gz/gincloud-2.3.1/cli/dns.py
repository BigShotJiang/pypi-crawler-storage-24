import typer
import csv
from pathlib import Path
from typing import List, Optional
from datetime import datetime

from utils.logger import get_logger
from utils import save_to_csv
from utils.dns import (
    get_record_by_resolve_dns,
    get_all_records,
    create_record,
    update_record,
    delete_record,
    bulk_create_records,
    bulk_update_records,
    bulk_delete_records,
)


logger = get_logger("cli.dns")


DNSCommand = typer.Typer(name="dns", help="Command for managing DNS records")

COMMON_OPTIONS = {
    "name": typer.Argument(
        ...,
        help="Domain name (prefix Only) to create like 'example' for 'example.ginesys.cloud' just put 'example'",
    ),
    "data": typer.Argument(
        ..., help="Target value mening IP or FQDN where record will point"
    ),
    "rtype": typer.Option(
        "CNAME", "--type", "-t", help="Record type (A, CNAME, TXT, etc.)"
    ),
    "types": typer.Option(
        "CNAME",
        "--type",
        help="List of types can be comma separated or provided lile --types CNAME --types A  multiple times",
    ),
    "domain": typer.Option(
        "ginesys.cloud",
        "--domain",
        "-d",
        help="The domain you are working on like ginesys.cloud, gsl.in etc.",
    ),
    "ttl": typer.Option(
        3600, "--time-to-live", "--ttl", "-ttl", help="Time to live in seconds"
    ),
    "overwrite": typer.Option(
        False,
        "--overwrite",
        "--force",
        "-f",
        help="Forcefully overwrite if record exists",
    ),
    "nameservers": typer.Option(
        ["8.8.8.8"],
        "--ns",
        "-n",
        help="Custom nameservers (default: Google DNS 8.8.8.8)",
    ),
    "api_key": typer.Option(
        None,
        "--api-key",
        help="GoDaddy API Key leave blank to use env variable 'GINCLOUD_GODADDY_API_KEY' ",
    ),
    "api_secret": typer.Option(
        None,
        "--api-secret",
        help="GoDaddy API Secret leave blank to use env variable 'GINCLOUD_GODADDY_API_SECRET' ",
    ),
    "input_file": typer.Argument(
        ..., help="Input CSV file with default columns: name,data,domain,type,ttl"
    ),
}


# ---------------- Commands ---------------- #
@DNSCommand.command(name="create", help="Create a new DNS record")
def create(
    name: str = COMMON_OPTIONS["name"],
    data: str = COMMON_OPTIONS["data"],
    rtype: str = COMMON_OPTIONS["rtype"],
    domain: str = COMMON_OPTIONS["domain"],
    ttl: int = COMMON_OPTIONS["ttl"],
    overwrite: bool = COMMON_OPTIONS["overwrite"],
    api_key: str = COMMON_OPTIONS["api_key"],
    api_secret: str = COMMON_OPTIONS["api_secret"],
):
    """Create a new DNS record."""
    try:
        result = create_record(
            name=name,
            data=data,
            domain=domain,
            rtype=rtype,
            ttl=ttl,
            overwrite=overwrite,
            api_key=api_key,
            api_secret=api_secret,
        )
        typer.echo(result)
    except Exception as e:
        logger.error(e)
        raise typer.Exit(code=1)


@DNSCommand.command(name="update", help="Update an existing DNS record")
def update(
    name: str = COMMON_OPTIONS["name"],
    data: str = COMMON_OPTIONS["data"],
    rtype: str = COMMON_OPTIONS["rtype"],
    domain: str = COMMON_OPTIONS["domain"],
    ttl: int = COMMON_OPTIONS["ttl"],
    ignore_type_mismatch: bool = typer.Option(
        False,
        "--ignore-type",
        "--ignore-type-mismatch",
        "-it",
        help="Ignore type mismatch and update anyway",
    ),
    if_not_exists_create: bool = typer.Option(
        False,
        "--if-not-exists-create",
        "--create",
        help="Create the record if it does not exist",
    ),
    api_key: str = COMMON_OPTIONS["api_key"],
    api_secret: str = COMMON_OPTIONS["api_secret"],
):
    """Update an existing DNS record."""
    try:
        result = update_record(
            name=name,
            data=data,
            domain=domain,
            rtype=rtype,
            ignore_type_mismatch=ignore_type_mismatch,
            if_not_exists_create=if_not_exists_create,
            ttl=ttl,
            api_key=api_key,
            api_secret=api_secret,
        )

        typer.echo(result)
    except Exception as e:
        logger.error(e)
        raise typer.Exit(code=1)


@DNSCommand.command(name="delete", help="Delete a DNS record")
def delete(
    name: str = COMMON_OPTIONS["name"],
    domain: str = COMMON_OPTIONS["domain"],
    rtype: str = COMMON_OPTIONS["rtype"],
    confirm: bool = typer.Option(
        False, "--confirm", "-y", help="Delete without confirmation"
    ),
    api_key: str = COMMON_OPTIONS["api_key"],
    api_secret: str = COMMON_OPTIONS["api_secret"],
):
    """Delete a DNS record."""
    try:
        result = delete_record(
            name=name,
            domain=domain,
            rtype=rtype,
            confirm=confirm,
            api_key=api_key,
            api_secret=api_secret,
        )
        typer.echo(result)
    except Exception as e:
        logger.error(e)
        raise typer.Exit(code=1)


@DNSCommand.command("export", help="Export DNS records for a domain to CSV")
def export(
    domain: str = typer.Argument(
        "ginesys.cloud",
        help="Domain to export records for like ginesys.cloud, gsl.in etc.",
    ),
    output_file: str = typer.Option(
        f"dns_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
        "--output-file",
        "-o",
        help="File name to save the exported DNS records",
    ),
    api_key: Optional[str] = COMMON_OPTIONS["api_key"],
    api_secret: Optional[str] = COMMON_OPTIONS["api_secret"],
):
    """Export DNS records for a domain to CSV"""

    try:
        records = get_all_records(domain, api_key, api_secret)
        if not records:
            logger.warning(f"No records to export for domain {domain}")
            return
        # Save to CSV
        save_to_csv(data=records, output_file=output_file, ensure_sorted=False)
        typer.echo(
            f"Exported {len(records)} records for domain {domain} to {output_file}"
        )
    except Exception as e:
        logger.error(e)
        raise typer.Exit(code=1)


@DNSCommand.command("test", help="Check DNS records for a single domain")
def single_test(
    domain: str = typer.Argument(
        ..., help="Full domain name to check [like 'example.something.com']"
    ),
    record_types: List[str] = typer.Option(
        ["CNAME", "A", "AAAA", "MX", "TXT", "NS"],
        "--type",
        "-t",
        help="Record types to check (CNAME, A, AAAA, MX, TXT, NS)",
    ),
    nameservers: List[str] = COMMON_OPTIONS["nameservers"],
):
    """
    Check DNS records for a single domain
    """
    logger.debug(
        f"Checking DNS for {domain} with types {record_types} using nameservers {nameservers}"
    )
    exists, rtype, target = get_record_by_resolve_dns(domain, record_types, nameservers)
    if exists:
        logger.info(f"[v] {domain} -> {rtype}: {target}")
    else:
        logger.warning(f"[x] {domain} -> No records found")


@DNSCommand.command(
    "bulk-test",
    help="Check bulk DNS records from CSV file with columns(* marked are required): name*,domain*,type",
)
def bulk_test(
    input_file: Path = typer.Argument(
        ...,
        help="Input CSV file with columns(* marked are required): name*,domain*,type",
    ),
    output_file: Path = typer.Argument(
        f"dns_check_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
        help="Output CSV file",
    ),
    default_domain: str = typer.Option(
        "ginesys.cloud",
        help="if domain is not provided in the file and wnat to provide same domain for all records",
    ),
    input_file_col_name: str = typer.Option(
        "name",
        help="Provide column name for **name**, if it diffrent in the file than 'name' Where value will be like 'example' for 'example.something.com'",
    ),
    input_file_col_domain: str = typer.Option(
        "domain",
        help="Provide column name for **domain**, if it diffrent in the file than 'domain' Where value will be like 'something.com' for 'example.something.com'",
    ),
    input_file_col_type: str = typer.Option(
        "type",
        help="Provide column name for **type**, if it diffrent in the file than 'type' Where value will be like 'A' for 'example.something.com'",
    ),
    record_types: List[str] = typer.Option(
        ["CNAME", "A", "AAAA", "MX", "TXT", "NS"],
        "--type",
        "-t",
        help="Default record types to check (CNAME, A, AAAA, MX, TXT, NS)",
    ),
    nameservers: List[str] = COMMON_OPTIONS["nameservers"],
):
    """
    Process a CSV file of domains and write results to a new CSV
    """
    logger.debug(f"Processing CSV {input_file}, output will be saved to {output_file}")
    if not input_file.exists():
        logger.error(f"Input file {input_file} does not exist.")

    with (
        input_file.open("r", newline="") as infile,
        output_file.open("w", newline="") as outfile,
    ):
        reader = csv.DictReader(infile)
        if not reader.fieldnames:
            logger.error("Invalid CSV: No header row found.")

        fieldnames = reader.fieldnames + ["Exists", "Record_Type", "Target"]
        writer = csv.DictWriter(outfile, fieldnames=fieldnames)
        writer.writeheader()

        for row in reader:
            domain = row.get(input_file_col_domain) or default_domain
            if not domain:
                logger.warning(
                    f"domain column is missing in the CSV at row {row}, Hence skiping this row"
                )
                continue
            name = row.get(input_file_col_name)
            if not name:
                logger.warning(
                    f"name column is missing in the CSV at row {row}, Hence skiping this row"
                )
                continue

            if domain in name:
                full_domain = name
            else:
                full_domain = f"{name}.{domain}"

            # Decide record types (from CSV column or CLI option)
            row_record_types = record_types
            if input_file_col_type and row.get(input_file_col_type):
                row_record_types = [
                    r.strip() for r in row[input_file_col_type].split(",") if r.strip()
                ]

            exists, rtype, target = get_record_by_resolve_dns(
                full_domain.strip(), row_record_types, nameservers
            )
            if exists:
                logger.info(
                    f"[v] Successfully checked : {full_domain} -> Found Type:{rtype}, Target:{target}, IsExist:{exists}"
                )
            else:
                logger.warning(
                    f"[x] Failed to check : {full_domain} -> Not Found Type:{rtype}, Target:{target}, IsExist:{exists}"
                )

            row["Exists"] = "Yes" if exists else "No"
            row["Record_Type"] = rtype if rtype else ""
            row["Target"] = target if target else ""
            writer.writerow(row)

    logger.info(f"Results written to {output_file}")


@DNSCommand.command(
    "bulk-create",
    help="Bulk create records from CSV file with columns (* mark is required): name*,data*,domain,type,ttl",
)
def bulk_create(
    input_file: str = typer.Argument(
        ...,
        help="Input CSV file with columns (* mark is required): name*,data*,domain*,type,ttl",
    ),
    output_file: str = typer.Option("bulk_update_results.csv", help="Output CSV file"),
    overwrite: bool = COMMON_OPTIONS["overwrite"],
    default_domain: str = typer.Option(
        "ginesys.cloud",
        help="if domain is not provided in the file and wnat to provide same domain for all records",
    ),
    default_data: Optional[str] = typer.Option(
        None,
        help="if data is not provided in the file and wnat to provide same data for all records",
    ),
    default_type: Optional[str] = typer.Option(
        None,
        help="if type is not provided in the file and wnat to provide same type for all records",
    ),
    default_ttl: int = typer.Option(
        3600,
        help="if ttl is not provided in the file and wnat to provide same ttl for all records",
    ),
    input_file_col_name: str = typer.Option(
        "name",
        help="Provide column name for **name**, if it diffrent in the file than 'name' Where value will be like 'example' for 'example.something.com'",
    ),
    input_file_col_domain: str = typer.Option(
        "domain",
        help="Provide column name for **domain**, if it diffrent in the file than 'domain' Where value will be like 'something.com' for 'example.something.com'",
    ),
    input_file_col_data: str = typer.Option(
        "data",
        help="Provide column name for **data**, if it diffrent in the file than 'data' Where value will be like '127.0.0.1' for 'example.something.com -> 127.0.0.1'",
    ),
    input_file_col_ttl: str = typer.Option(
        "ttl",
        help="Provide column name for **ttl**, if it diffrent in the file than 'ttl' Where value will be like '3600' for 'example.something.com'",
    ),
    input_file_col_type: str = typer.Option(
        "type",
        help="Provide column name for **type**, if it diffrent in the file than 'type' Where value will be like 'A' for 'example.something.com'",
    ),
    api_key: Optional[str] = COMMON_OPTIONS["api_key"],
    api_secret: Optional[str] = COMMON_OPTIONS["api_secret"],
):
    """Bulk create records from CSV file with columns: name,data,domain,type,ttl"""
    try:
        result = bulk_create_records(
            input_file=input_file,
            overwrite=overwrite,
            input_file_col_name=input_file_col_name,
            input_file_col_domain=input_file_col_domain,
            input_file_col_type=input_file_col_type,
            input_file_col_data=input_file_col_data,
            input_file_col_ttl=input_file_col_ttl,
            default_type=default_type,
            default_data=default_data,
            default_domain=default_domain,
            default_ttl=default_ttl,
            api_key=api_key,
            api_secret=api_secret,
        )

        save_to_csv(data=result, output_file=output_file, ensure_sorted=False)
        typer.echo(result)
    except Exception as e:
        logger.error(e)
        raise typer.Exit(code=1)


@DNSCommand.command("bulk-update")
def bulk_update(
    input_file: str,
    output_file: str = "bulk_update_results.csv",
    ignore_type_mismatch: bool = False,
    if_not_exists_create: bool = False,
    default_type: Optional[str] = None,
    default_domain: Optional[str] = None,
    default_data: Optional[str] = None,
    default_ttl: int = 3600,
    input_file_col_name: str = typer.Option(
        "name",
        help="Provide column name for **name**, if it diffrent in the file than 'name' Where value will be like 'example' for 'example.something.com'",
    ),
    input_file_col_domain: str = typer.Option(
        "domain",
        help="Provide column name for **domain**, if it diffrent in the file than 'domain' Where value will be like 'something.com' for 'example.something.com'",
    ),
    input_file_col_data: str = typer.Option(
        "data",
        help="Provide column name for **data**, if it diffrent in the file than 'data' Where value will be like '127.0.0.1' for 'example.something.com -> 127.0.0.1'",
    ),
    input_file_col_ttl: str = typer.Option(
        "ttl",
        help="Provide column name for **ttl**, if it diffrent in the file than 'ttl' Where value will be like '3600' for 'example.something.com'",
    ),
    input_file_col_type: str = typer.Option(
        "type",
        help="Provide column name for **type**, if it diffrent in the file than 'type' Where value will be like 'A' for 'example.something.com'",
    ),
    api_key: Optional[str] = COMMON_OPTIONS["api_key"],
    api_secret: Optional[str] = COMMON_OPTIONS["api_secret"],
):
    """Bulk update records from CSV file with columns: name,data,domain,type,ttl"""
    try:
        result = bulk_update_records(
            input_file=input_file,
            ignore_type_mismatch=ignore_type_mismatch,
            if_not_exists_create=if_not_exists_create,
            input_file_col_name=input_file_col_name,
            input_file_col_type=input_file_col_type,
            input_file_col_data=input_file_col_data,
            input_file_col_ttl=input_file_col_ttl,
            default_type=default_type,
            default_domain=default_domain,
            default_data=default_data,
            default_ttl=default_ttl,
            api_key=api_key,
            api_secret=api_secret,
        )
        save_to_csv(data=result, output_file=output_file, ensure_sorted=False)
        typer.echo(result)
    except Exception as e:
        logger.error(e)
        raise typer.Exit(code=1)


@DNSCommand.command("bulk-delete")
def bulk_delete(
    input_file: str = typer.Argument(
        ...,
        help="Input CSV file with columns (* mark is required): name*,domain*,type*",
    ),
    output_file: str = typer.Argument(
        f"bulk_delete_results_{datetime.now().strftime('%Y%m%d%H%M%S')}.csv",
        help="Output CSV file",
    ),
    confirm: bool = typer.Option(False, "--confirm", "-y", help="Confirm deletion"),
    input_file_col_name: str = typer.Option("name", help="Input CSV file column name"),
    input_file_col_domain: str = typer.Option(
        "domain", help="Input CSV file column domain"
    ),
    input_file_col_type: str = typer.Option("type", help="Input CSV file column type"),
    default_domain: Optional[str] = typer.Option(
        "ginesys.cloud", help="Default domain"
    ),
    default_type: Optional[str] = typer.Option(None, help="Default type"),
    api_key: Optional[str] = COMMON_OPTIONS["api_key"],
    api_secret: Optional[str] = COMMON_OPTIONS["api_secret"],
):
    """Bulk delete records from CSV file with columns (* mark is required): name*,domain*,type*"""
    try:
        result = bulk_delete_records(
            input_file=input_file,
            confirm=confirm,
            input_file_col_name=input_file_col_name,
            input_file_col_domain=input_file_col_domain,
            input_file_col_type=input_file_col_type,
            default_domain=default_domain,
            default_type=default_type,
            api_key=api_key,
            api_secret=api_secret,
        )
        save_to_csv(data=result, output_file=output_file, ensure_sorted=False)
        typer.echo(result)
    except Exception as e:
        logger.error(e)
        raise typer.Exit(code=1)
