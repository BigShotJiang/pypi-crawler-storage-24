# autobots-tui

A terminal-based interface for the [Autobots](https://github.com/jetoslabs/autobots) AI automation platform. Built with [Textual](https://textual.textualize.io/) and [Typer](https://typer.tiangolo.com/), it provides a chat-style TUI and command-line access to manage and interact with Autobots actions, action graphs, and their runs.

## Installation

```bash
pip install autobots-tui
```

This installs two commands:

- `autobots` — Main entry point for all commands
- `autobots-tui` — Shortcut to launch the TUI directly

Requires Python 3.13+.

## Quick Start

```bash
# Login
autobots login

# Launch the interactive TUI
autobots tui

# Or use commands directly
autobots actions list
autobots runs list --status processing
```

## Commands

```
autobots login                            Authenticate with email and password
autobots whoami                           Check authentication status
autobots tui                              Launch the interactive TUI

autobots actions list [--name N]          List actions
autobots actions get <id>                 Get action details

autobots runs list [--action-id ID]       List action runs (results)
autobots runs get <id>                    Get run details

autobots graphs list [--name N]           List action graphs
autobots graphs get <id>                  Get graph details

autobots graph-runs list [--graph-id ID]  List graph runs (results)
autobots graph-runs get <id>              Get graph run details
```

All list commands support `--limit` and `--offset` for pagination. Runs can be filtered by `--status` (processing, success, error, stuck, waiting).

## Interactive TUI

Launch with `autobots tui` or `autobots-tui`. The TUI provides a full-screen chat interface for conversing with Autobots actions in real time.

- **Chat interface** — Send messages to actions and receive streamed responses via SSE (Server-Sent Events)
- **Session management** — Switch actions, continue existing runs, or start new conversations
- **Slash commands** — All commands above work inside the TUI chat with a `/` prefix
- **Authentication** — Login screen with email/password, automatic token refresh, secure local token storage
- **Theming** — Dark/light mode toggle (`Ctrl+D`)
- **Keyboard shortcuts** — `Ctrl+C` quit, `Ctrl+L` logout, `Ctrl+D` toggle theme

### Slash Commands

Inside the TUI chat:

```
/use <action_id>              Switch to a different action
/continue <run_id>            Continue an existing conversation run
/new                          Start a new conversation (resets to default action)
/status                       Show current action and run IDs

/actions list                 List all actions
/runs list --status success   Filter runs by status
/graphs get <id>              View graph details
/help                         Show all available commands
```

### Streaming

Actions execute asynchronously. The TUI streams status updates in real time via SSE and automatically fetches the final result on completion. Falls back to polling if the SSE stream ends without delivering a result.

## Configuration

Stored at `~/.autobots-tui/config.json`:

```json
{
  "backend_url": "https://api.example.com",
  "log_level": "INFO",
  "theme": "dark",
  "refresh_interval": 5
}
```

Logs are written to `~/.autobots-tui/autobots_tui.log`.

## Development

```bash
git clone https://github.com/jetoslabs/autobots-tui.git
cd autobots-tui
uv sync
uv run autobots tui
```

## License

MIT
