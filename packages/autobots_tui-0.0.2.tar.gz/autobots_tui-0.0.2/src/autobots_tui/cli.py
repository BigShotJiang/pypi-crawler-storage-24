"""Typer CLI for Autobots — thin wrapper over commands.py."""

from typing import Optional

from loguru import logger
logger.remove()  # Suppress loguru console output in CLI mode

import typer
from autobots_client import AuthenticatedClient

from .config import ConfigManager
from .auth import TokenManager
from . import commands

app = typer.Typer(name="autobots", help="Autobots CLI — interact with the Autobots API.")

actions_app = typer.Typer(name="actions", help="Manage actions.")
action_runs_app = typer.Typer(name="runs", help="Manage action runs (results).")
graphs_app = typer.Typer(name="graphs", help="Manage action graphs.")
graph_runs_app = typer.Typer(name="graph-runs", help="Manage action graph runs (results).")

app.add_typer(actions_app)
app.add_typer(action_runs_app)
app.add_typer(graphs_app)
app.add_typer(graph_runs_app)


def _get_client() -> AuthenticatedClient:
    config = ConfigManager().config
    tm = TokenManager()
    if not tm.is_authenticated():
        typer.echo("Not authenticated. Run `autobots login` first.", err=True)
        raise typer.Exit(code=1)
    return AuthenticatedClient(base_url=config.backend_url, token=tm.get_access_token(), raise_on_unexpected_status=False)


def _print(lines: list[str]) -> None:
    for line in lines:
        typer.echo(line)


# -- actions ----------------------------------------------------------------

@actions_app.command("list")
def actions_list_cmd(
    name: Optional[str] = typer.Option(None, help="Filter by name"),
    limit: int = typer.Option(20, help="Max results"),
    offset: int = typer.Option(0, help="Offset"),
):
    """List actions."""
    _print(commands.actions_list(_get_client(), name=name, limit=limit, offset=offset))

@actions_app.command("get")
def actions_get_cmd(id: str = typer.Argument(help="Action ID")):
    """Get action details."""
    _print(commands.actions_get(_get_client(), id=id))


# -- runs -------------------------------------------------------------------

@action_runs_app.command("list")
def runs_list_cmd(
    action_id: Optional[str] = typer.Option(None, help="Filter by action ID"),
    action_name: Optional[str] = typer.Option(None, help="Filter by action name"),
    status: Optional[str] = typer.Option(None, help="Filter by status"),
    limit: int = typer.Option(20, help="Max results"),
    offset: int = typer.Option(0, help="Offset"),
):
    """List action runs (results)."""
    _print(commands.runs_list(_get_client(), action_id=action_id, action_name=action_name, status=status, limit=limit, offset=offset))

@action_runs_app.command("get")
def runs_get_cmd(id: str = typer.Argument(help="Action run ID")):
    """Get action run details."""
    _print(commands.runs_get(_get_client(), id=id))


# -- graphs -----------------------------------------------------------------

@graphs_app.command("list")
def graphs_list_cmd(
    name: Optional[str] = typer.Option(None, help="Filter by name"),
    limit: int = typer.Option(20, help="Max results"),
    offset: int = typer.Option(0, help="Offset"),
):
    """List action graphs."""
    _print(commands.graphs_list(_get_client(), name=name, limit=limit, offset=offset))

@graphs_app.command("get")
def graphs_get_cmd(id: str = typer.Argument(help="Action graph ID")):
    """Get action graph details."""
    _print(commands.graphs_get(_get_client(), id=id))


# -- graph-runs -------------------------------------------------------------

@graph_runs_app.command("list")
def graph_runs_list_cmd(
    graph_id: Optional[str] = typer.Option(None, "--graph-id", help="Filter by graph ID"),
    graph_name: Optional[str] = typer.Option(None, "--graph-name", help="Filter by graph name"),
    status: Optional[str] = typer.Option(None, help="Filter by status"),
    limit: int = typer.Option(20, help="Max results"),
    offset: int = typer.Option(0, help="Offset"),
):
    """List action graph runs (results)."""
    _print(commands.graph_runs_list(_get_client(), action_graph_id=graph_id, action_graph_name=graph_name, status=status, limit=limit, offset=offset))

@graph_runs_app.command("get")
def graph_runs_get_cmd(id: str = typer.Argument(help="Graph run ID")):
    """Get action graph run details."""
    _print(commands.graph_runs_get(_get_client(), id=id))


# -- top-level --------------------------------------------------------------

@app.command()
def login(
    username: str = typer.Option(..., prompt=True, help="Email"),
    password: str = typer.Option(..., prompt=True, hide_input=True, help="Password"),
):
    """Login and save authentication tokens."""
    from .client import AutobotsClientWrapper
    from .models import LoginCredentials

    config = ConfigManager().config
    token_manager = TokenManager()
    wrapper = AutobotsClientWrapper(base_url=config.backend_url)
    success, tokens, message = wrapper.login(LoginCredentials(username=username, password=password))

    if success and tokens:
        token_manager.save_tokens(tokens)
        typer.echo("Logged in successfully.")
    else:
        typer.echo(f"Login failed: {message}", err=True)
        raise typer.Exit(code=1)

@app.command()
def logout():
    """Logout and clear saved authentication tokens."""
    tm = TokenManager()
    tm.clear_tokens()
    typer.echo("Logged out successfully.")

@app.command()
def whoami():
    """Show current authentication status."""
    tm = TokenManager()
    config = ConfigManager().config
    if tm.is_authenticated():
        typer.echo(f"Authenticated\nServer: {config.backend_url}")
    else:
        typer.echo("Not authenticated. Run `autobots login` to sign in.")

@app.command()
def tui():
    """Launch the interactive TUI."""
    from .main import main
    main()


def cli():
    """Entry point for the CLI."""
    app()

if __name__ == "__main__":
    cli()
