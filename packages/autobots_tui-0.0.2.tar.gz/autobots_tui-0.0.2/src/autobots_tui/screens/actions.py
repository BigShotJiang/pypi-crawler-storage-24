"""Actions execution screen."""

from datetime import datetime
from textual.app import ComposeResult
from textual.screen import Screen
from textual.containers import Container, Horizontal, Vertical, ScrollableContainer
from textual.widgets import Header, Footer, Static, DataTable, Button, Input, Label
from loguru import logger

from ..models import Action, ActionExecution, ActionStatus
from ..widgets import StatusBadge, ActionButton, InfoPanel


class ActionsScreen(Screen):
    """Screen for viewing and executing actions."""

    CSS = """
    ActionsScreen {
        background: $surface;
    }

    #actions-header {
        height: auto;
        padding: 1;
        background: $panel;
        border-bottom: solid $primary;
    }

    #actions-title {
        text-style: bold;
        color: $accent;
        text-align: center;
    }

    #main-content {
        height: 1fr;
    }

    #left-panel {
        width: 1fr;
        padding: 1;
        border-right: solid $primary;
    }

    #right-panel {
        width: 2fr;
        padding: 1;
    }

    #actions-list {
        height: 1fr;
        margin-top: 1;
    }

    #execution-container {
        height: 1fr;
    }

    #action-buttons {
        height: auto;
        padding: 1;
        align: center middle;
    }

    .section-title {
        text-style: bold;
        color: $accent;
        padding: 1 0;
    }

    #status-display {
        height: auto;
        padding: 1;
        border: solid $primary;
        margin: 1 0;
    }
    """

    BINDINGS = [
        ("escape", "back", "Back"),
        ("e", "execute", "Execute"),
        ("r", "refresh", "Refresh"),
        ("q", "quit", "Quit"),
    ]

    def __init__(self):
        """Initialize actions screen."""
        super().__init__()
        self.actions: list[Action] = []
        self.executions: list[ActionExecution] = []
        self.selected_action: Action | None = None

    def compose(self) -> ComposeResult:
        """Compose actions screen widgets."""
        yield Header()

        with Container(id="actions-header"):
            yield Static("⚡ Actions & Execution", id="actions-title")

        with Horizontal(id="main-content"):
            # Left panel - Actions list
            with Vertical(id="left-panel"):
                yield Static("Available Actions", classes="section-title")
                yield DataTable(id="actions-list")

            # Right panel - Execution details
            with ScrollableContainer(id="right-panel"):
                yield Static("Action Details", classes="section-title")

                yield InfoPanel(
                    "No Action Selected",
                    "Select an action from the list to view details and execute.",
                    id="action-details"
                )

                with Horizontal(id="action-buttons"):
                    yield ActionButton("▶ Execute", variant="success", id="btn-execute")
                    yield ActionButton("⏹ Stop", variant="danger", id="btn-stop")

                yield Static("Execution History", classes="section-title")
                yield Container(id="execution-container")

        yield Footer()

    def on_mount(self) -> None:
        """Called when screen is mounted."""
        logger.info("Actions screen mounted")

        # Setup table
        table = self.query_one("#actions-list", DataTable)
        table.cursor_type = "row"
        table.zebra_stripes = True
        table.add_columns("ID", "Name", "Autobot")

        # Load actions
        self.load_actions()

    def load_actions(self) -> None:
        """Load available actions."""
        logger.debug("Loading actions")

        # TODO: Fetch from autobots client
        # Mock data
        self.actions = [
            Action(
                id="act-001",
                name="Generate Report",
                description="Generate monthly sales report",
                autobot_id="ab-002",
                parameters={"format": "pdf", "month": "current"}
            ),
            Action(
                id="act-002",
                name="Send Notification",
                description="Send notification to subscribers",
                autobot_id="ab-005",
                parameters={"channel": "email", "template": "newsletter"}
            ),
            Action(
                id="act-003",
                name="Analyze Data",
                description="Run data analysis pipeline",
                autobot_id="ab-002",
                parameters={"dataset": "sales_2024", "model": "regression"}
            ),
            Action(
                id="act-004",
                name="Scrape Prices",
                description="Scrape competitor pricing",
                autobot_id="ab-003",
                parameters={"urls": ["example.com"], "frequency": "daily"}
            ),
        ]

        self.populate_table()

    def populate_table(self) -> None:
        """Populate actions table."""
        table = self.query_one("#actions-list", DataTable)
        table.clear()

        for action in self.actions:
            table.add_row(
                action.id,
                action.name,
                action.autobot_id,
            )

        logger.info(f"Loaded {len(self.actions)} actions")

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        """Handle action selection."""
        row_key = event.row_key
        table = self.query_one("#actions-list", DataTable)
        row_data = table.get_row(row_key)

        action_id = str(row_data[0])
        self.selected_action = next(
            (act for act in self.actions if act.id == action_id), None
        )

        if self.selected_action:
            logger.info(f"Selected action: {self.selected_action.name}")
            self.update_action_details()

    def update_action_details(self) -> None:
        """Update action details panel."""
        if not self.selected_action:
            return

        details_text = f"{self.selected_action.description}\n\n"
        details_text += f"ID: {self.selected_action.id}\n"
        details_text += f"Autobot: {self.selected_action.autobot_id}\n\n"
        details_text += "Parameters:\n"

        for key, value in self.selected_action.parameters.items():
            details_text += f"  • {key}: {value}\n"

        panel = self.query_one("#action-details", InfoPanel)
        panel.query_one(".panel-title", Static).update(self.selected_action.name)
        panel.update_content(details_text)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == "btn-execute":
            self.action_execute()
        elif event.button.id == "btn-stop":
            self.stop_execution()

    def action_execute(self) -> None:
        """Execute selected action."""
        if not self.selected_action:
            self.notify("Please select an action first", severity="warning")
            return

        logger.info(f"Executing action: {self.selected_action.name}")

        # TODO: Execute via autobots client
        # Mock execution
        execution = ActionExecution(
            id=f"exec-{len(self.executions) + 1:03d}",
            action_id=self.selected_action.id,
            status=ActionStatus.RUNNING,
        )
        self.executions.append(execution)

        self.notify(
            f"Executing: {self.selected_action.name}",
            severity="information"
        )

    def stop_execution(self) -> None:
        """Stop running execution."""
        logger.info("Stop execution requested")
        self.notify("Stop execution coming soon!", severity="warning")

    def action_back(self) -> None:
        """Return to previous screen."""
        logger.info("Returning to dashboard")
        self.app.pop_screen()

    def action_refresh(self) -> None:
        """Refresh actions list."""
        logger.info("Refreshing actions list")
        self.load_actions()
        self.notify("Actions list refreshed", severity="information")

    def action_quit(self) -> None:
        """Quit the application."""
        logger.info("Quitting application from actions screen")
        self.app.exit()
