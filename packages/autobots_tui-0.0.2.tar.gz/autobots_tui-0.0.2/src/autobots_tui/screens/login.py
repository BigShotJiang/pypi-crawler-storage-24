"""Login screen for Autobots TUI."""

from textual.app import ComposeResult
from textual.screen import Screen
from textual.containers import Container, Vertical, Center, Horizontal
from textual.widgets import Header, Footer, Static, Input, Button
from textual.validation import Length
from textual.message import Message
from loguru import logger

from ..models import LoginCredentials
from ..widgets import ActionButton


class LoginScreen(Screen):
    """Screen for user authentication."""

    AUTO_FOCUS = None  # Prevent automatic focus changes

    CSS = """
    LoginScreen {
        background: $surface;
        layout: vertical;
    }

    #login-container {
        width: 100%;
        height: 1fr;
        min-height: 20;
        border: none;
        background: transparent;
        padding: 4 8;
        overflow-y: auto;
    }

    #logo-container {
        width: 100%;
        height: auto;
        margin-bottom: 2;
        content-align: left top;
    }

    #logo {
        color: #5fffff; /* Cyan-ish */
        width: auto;
    }

    #logo-text-container {
        margin-left: 2;
        height: auto;
    }

    #logo-text {
        color: #5fffff;
        text-style: bold;
        height: auto;
    }

    #logo-subtitle {
        color: #5fffff;
        height: auto;
    }

    .divider {
        width: 100%;
        height: 1;
        border-bottom: solid #444444;
        margin-bottom: 2;
    }

    .info-row {
        height: auto;
        margin-bottom: 0;
    }

    .info-label {
        color: #5fffff;
        width: auto;
        margin-right: 1;
    }

    .info-value {
        color: $text;
    }

    .section-header {
        color: #5fffff;
        text-style: bold;
        margin-top: 2;
        margin-bottom: 1;
        border-bottom: solid #444444;
        width: 40;
    }

    .input-prompt {
        color: #5fffff;
        width: auto;
        margin-right: 1;
    }

    .form-group {
        layout: horizontal;
        height: 1;
        margin: 0;
    }

    Input {
        width: 40;
        background: transparent;
        border: none;
        padding: 0;
        height: 1;
        color: $text;
    }

    Input:focus {
        border: none;
    }

    #status-message {
        margin-top: 1;
        height: auto;
    }

    .status-line {
        height: auto;
    }

    .status-symbol-success {
        color: $success;
        margin-right: 1;
    }

    .status-symbol-pending {
        color: #5fffff;
        margin-right: 1;
    }

    .status-symbol-error {
        color: $error;
        margin-right: 1;
    }

    #button-container {
        display: none; /* Hide button to match sleek look */
    }
    """

    BINDINGS = [
        ("escape", "quit", "Quit"),
        ("ctrl+c", "quit", "Quit"),
    ]

    def compose(self) -> ComposeResult:
        """Compose login screen widgets."""
        yield Header()

        with Container(id="login-container"):
            # Logo Section
            with Horizontal(id="logo-container"):
                logo_ascii = (
                    "      #\n"
                    "    #####\n"
                    "  #########\n"
                    " ###########\n"
                    "#############\n"
                    " ###########\n"
                    "  #########\n"
                    "    #####\n"
                    "      #"
                )
                yield Static(logo_ascii, id="logo")
                with Vertical(id="logo-text-container"):
                    yield Static("KIWI AI", id="logo-text")
                    yield Static("Terminal Agent for AI-Powered Automation", id="logo-subtitle")

            yield Static("", classes="divider")

            # Environment Info
            with Horizontal(classes="info-row"):
                yield Static("> Server:", classes="info-label")
                yield Static(f"app ({self.app.config.backend_url})", classes="info-value")
            
            with Horizontal(classes="info-row"):
                yield Static("> Mode:", classes="info-label")
                yield Static("restricted", classes="info-value")

            yield Static("Authentication", classes="section-header")

            with Horizontal(classes="form-group"):
                yield Static("> Email:", classes="input-prompt")
                yield Input(
                    placeholder="email@example.com",
                    id="username-input",
                )

            with Horizontal(classes="form-group"):
                yield Static("> Password:", classes="input-prompt")
                yield Input(
                    placeholder="••••••••",
                    password=True,
                    id="password-input",
                )

            yield Static("", id="status-message")

            with Center(id="button-container"):
                yield ActionButton("Sign In", variant="success", id="btn-login")

        yield Footer()

    def on_mount(self) -> None:
        """Called when screen is mounted."""
        logger.info("Login screen mounted")
        # Focus on username input after a brief delay to ensure DOM is ready
        try:
            username_input = self.query_one("#username-input", Input)
            self.set_timer(0.1, lambda: username_input.focus())
        except Exception as e:
            logger.error(f"Error focusing username input: {e}")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == "btn-login":
            self.action_login()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle input submission (Enter key)."""
        if event.input.id == "username-input":
            # Move to password field
            self.query_one("#password-input", Input).focus()
        elif event.input.id == "password-input":
            # Submit login
            self.action_login()

    def action_login(self) -> None:
        """Attempt to login with provided credentials."""
        username_input = self.query_one("#username-input", Input)
        password_input = self.query_one("#password-input", Input)
        status_widget = self.query_one("#status-message", Static)

        username = username_input.value.strip()
        password = password_input.value

        # Validate inputs
        if not username:
            status_widget.update("~ Please enter your email")
            status_widget.styles.color = "red"
            username_input.focus()
            return

        if not password:
            status_widget.update("~ Please enter your password")
            status_widget.styles.color = "red"
            password_input.focus()
            return

        # Show loading state
        status_widget.styles.color = "#5fffff"
        status_widget.update(f"~ Authenticating with {self.app.config.backend_url}...")

        logger.info(f"Login attempt for user: {username}")

        # Create credentials
        credentials = LoginCredentials(username=username, password=password)

        # Call login through app
        if hasattr(self.app, 'autobots_client'):
            success, tokens, message = self.app.autobots_client.login(credentials)

            if success and tokens:
                status_widget.update("> Login successful!")
                status_widget.styles.color = "green"
                logger.info(f"Login successful for user: {username}")

                # Save tokens
                if hasattr(self.app, 'token_manager'):
                    self.app.token_manager.save_tokens(tokens)

                # Notify app of successful login
                self.app.post_message(LoginSuccess(tokens))

                # Switch to dashboard
                self.app.switch_screen("dashboard")
            else:
                error_msg = f"~ {message}"
                status_widget.update(error_msg)
                status_widget.styles.color = "red"
                logger.error(f"Login failed for user {username}: {message}")
                password_input.value = ""
                password_input.focus()
        else:
            error_msg = "~ Client not initialized"
            status_widget.update(error_msg)
            status_widget.styles.color = "red"
            logger.error("Autobots client not found in app")

    def action_quit(self) -> None:
        """Quit the application."""
        logger.info("Quitting application from login screen")
        self.app.exit()


class LoginSuccess(Message):
    """Message sent when login is successful."""

    bubbles = True

    def __init__(self, tokens):
        """Initialize login success message.

        Args:
            tokens: Authentication tokens
        """
        super().__init__()
        self.tokens = tokens
