"""Autobots list screen."""

from datetime import datetime
from textual.app import ComposeResult
from textual.screen import Screen
from textual.containers import Container, Vertical, Horizontal
from textual.widgets import Header, Footer, Static, DataTable, Button
from loguru import logger

from ..models import Autobot, AutobotType
from ..widgets import StatusBadge, ActionButton


class AutobotsScreen(Screen):
    """Screen displaying list of autobots."""

    CSS = """
    AutobotsScreen {
        background: $surface;
    }

    #autobots-header {
        height: auto;
        padding: 1;
        background: $panel;
        border-bottom: solid $primary;
    }

    #autobots-title {
        text-style: bold;
        color: $accent;
        text-align: center;
    }

    #actions-bar {
        height: auto;
        padding: 1;
        align: center middle;
    }

    #table-container {
        height: 1fr;
        padding: 1;
    }

    DataTable {
        height: 100%;
    }
    """

    BINDINGS = [
        ("escape", "back", "Back"),
        ("n", "new_autobot", "New"),
        ("r", "refresh", "Refresh"),
        ("q", "quit", "Quit"),
    ]

    def __init__(self):
        """Initialize autobots screen."""
        super().__init__()
        self.autobots: list[Autobot] = []

    def compose(self) -> ComposeResult:
        """Compose autobots screen widgets."""
        yield Header()

        with Container(id="autobots-header"):
            yield Static("🤖 Autobots Management", id="autobots-title")

        with Horizontal(id="actions-bar"):
            yield ActionButton("➕ New Autobot", variant="success", id="btn-new")
            yield ActionButton("🔄 Refresh", variant="primary", id="btn-refresh")

        with Container(id="table-container"):
            yield DataTable(id="autobots-table")

        yield Footer()

    def on_mount(self) -> None:
        """Called when screen is mounted."""
        logger.info("Autobots screen mounted")

        # Setup table
        table = self.query_one(DataTable)
        table.cursor_type = "row"
        table.zebra_stripes = True

        # Add columns
        table.add_columns("ID", "Name", "Type", "Status", "Runs", "Last Run")

        # Load autobots
        self.load_autobots()

    def load_autobots(self) -> None:
        """Load autobots from backend."""
        logger.debug("Loading autobots")

        # TODO: Fetch from autobots client
        # Mock data for now
        self.autobots = [
            Autobot(
                id="ab-001",
                name="Content Generator",
                type=AutobotType.AUTOMATION,
                description="Generates blog content automatically",
                enabled=True,
                run_count=45,
                last_run=datetime.now(),
            ),
            Autobot(
                id="ab-002",
                name="Data Analyzer",
                type=AutobotType.ANALYSIS,
                description="Analyzes sales data and generates reports",
                enabled=True,
                run_count=23,
                last_run=datetime.now(),
            ),
            Autobot(
                id="ab-003",
                name="Web Scraper",
                type=AutobotType.SEARCH,
                description="Scrapes competitor pricing data",
                enabled=False,
                run_count=12,
                last_run=None,
            ),
            Autobot(
                id="ab-004",
                name="Chat Assistant",
                type=AutobotType.CHAT,
                description="Handles customer inquiries",
                enabled=True,
                run_count=156,
                last_run=datetime.now(),
            ),
            Autobot(
                id="ab-005",
                name="Email Responder",
                type=AutobotType.AUTOMATION,
                description="Automated email responses",
                enabled=True,
                run_count=89,
                last_run=datetime.now(),
            ),
        ]

        self.populate_table()

    def populate_table(self) -> None:
        """Populate table with autobot data."""
        table = self.query_one(DataTable)
        table.clear()

        for autobot in self.autobots:
            status = "✓ Enabled" if autobot.enabled else "✗ Disabled"
            last_run = (
                autobot.last_run.strftime("%Y-%m-%d %H:%M")
                if autobot.last_run
                else "Never"
            )

            table.add_row(
                autobot.id,
                autobot.name,
                autobot.type.value.title(),
                status,
                str(autobot.run_count),
                last_run,
            )

        logger.info(f"Loaded {len(self.autobots)} autobots")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button press events."""
        if event.button.id == "btn-new":
            self.action_new_autobot()
        elif event.button.id == "btn-refresh":
            self.action_refresh()

    def on_data_table_row_selected(self, event: DataTable.RowSelected) -> None:
        """Handle table row selection."""
        row_key = event.row_key
        table = self.query_one(DataTable)
        row_data = table.get_row(row_key)

        autobot_id = str(row_data[0])
        autobot = next((ab for ab in self.autobots if ab.id == autobot_id), None)

        if autobot:
            logger.info(f"Selected autobot: {autobot.name}")
            self.notify(
                f"Selected: {autobot.name}\n{autobot.description}",
                severity="information",
            )

    def action_back(self) -> None:
        """Return to previous screen."""
        logger.info("Returning to dashboard")
        self.app.pop_screen()

    def action_new_autobot(self) -> None:
        """Create new autobot."""
        logger.info("New autobot requested")
        self.notify("New autobot creation coming soon!", severity="information")

    def action_refresh(self) -> None:
        """Refresh autobots list."""
        logger.info("Refreshing autobots list")
        self.load_autobots()
        self.notify("Autobots list refreshed", severity="information")

    def action_quit(self) -> None:
        """Quit the application."""
        logger.info("Quitting application from autobots screen")
        self.app.exit()
