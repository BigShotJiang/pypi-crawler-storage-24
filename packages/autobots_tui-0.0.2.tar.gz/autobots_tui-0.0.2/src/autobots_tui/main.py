"""Main entry point for Autobots TUI application."""

from textual.app import App
from textual.binding import Binding
from loguru import logger

from .logger import setup_logging
from .config import ConfigManager
from .client import AutobotsClientWrapper
from .auth import TokenManager
from .screens import LoginScreen, DashboardScreen, AutobotsScreen, ActionsScreen


class AutobotsTUI(App):
    """A modern Textual app for managing Autobots."""

    CSS = """
    Screen {
        background: $surface;
    }

    Header {
        background: #006666;
        color: #00ffff;
    }

    Footer {
        background: #006666;
    }

    Footer > .footer--key {
        background: #008888;
        color: #00ffff;
    }
    """

    TITLE = "Kiwi Code"
    SUB_TITLE = ""

    SCREENS = {
        "login": LoginScreen,
        "dashboard": DashboardScreen,
        "autobots": AutobotsScreen,
        "actions": ActionsScreen,
    }

    BINDINGS = [
        Binding("ctrl+c", "quit", "Quit", show=True),
        Binding("ctrl+d", "toggle_dark", "Toggle Dark Mode", show=False),
        Binding("ctrl+l", "logout", "Logout", show=False),
    ]

    def __init__(self, config_manager: ConfigManager | None = None, token_manager: TokenManager | None = None):
        """Initialize Autobots TUI app.

        Args:
            config_manager: Configuration manager instance
            token_manager: Token manager instance
        """
        super().__init__()
        self.config_manager = config_manager or ConfigManager()
        self.config = self.config_manager.config

        # Initialize token manager
        self.token_manager = token_manager or TokenManager()

        # Check for existing tokens
        tokens = self.token_manager.load_tokens()
        access_token = None

        if tokens:
            # Check if token needs refresh
            if tokens.is_expired():
                logger.info("Access token expired, attempting refresh")
                # Try to refresh token
                temp_client = AutobotsClientWrapper(base_url=self.config.backend_url)
                success, new_tokens, message = temp_client.refresh_token(tokens.refresh_token)

                if success and new_tokens:
                    logger.info("Token refreshed successfully")
                    self.token_manager.save_tokens(new_tokens)
                    access_token = new_tokens.access_token
                else:
                    logger.warning(f"Token refresh failed: {message}")
                    self.token_manager.clear_tokens()
            else:
                logger.info("Valid access token found")
                access_token = tokens.access_token

        # Initialize autobots client
        self.autobots_client = AutobotsClientWrapper(
            base_url=self.config.backend_url,
            access_token=access_token,
            api_key=self.config.api_key,
        )

    def on_mount(self) -> None:
        """Called when app is mounted."""
        logger.info("Autobots TUI on_mount called")
        logger.info(f"Backend URL: {self.config.backend_url}")

        # Set theme
        self.dark = self.config.theme == "dark"

        # Check if user is authenticated
        if self.token_manager.is_authenticated():
            logger.info("User is authenticated, showing dashboard")
            try:
                self.switch_screen("dashboard")
            except IndexError:
                # If switch_screen fails (empty stack), use push_screen
                self.push_screen("dashboard")
        else:
            logger.info("User not authenticated, showing login screen")
            try:
                self.switch_screen("login")
            except IndexError:
                # If switch_screen fails (empty stack), use push_screen
                self.push_screen("login")

    def action_toggle_dark(self) -> None:
        """Toggle dark mode."""
        self.dark = not self.dark
        theme = "dark" if self.dark else "light"
        self.config_manager.update(theme=theme)
        logger.info(f"Theme changed to {theme}")
        self.notify(f"Theme: {theme}", severity="information")

    def action_logout(self) -> None:
        """Logout user and return to login screen."""
        logger.info("User logout requested")

        # Clear tokens
        self.token_manager.clear_tokens()

        # Reset client to unauthenticated
        self.autobots_client = AutobotsClientWrapper(
            base_url=self.config.backend_url,
        )

        # Switch to login screen
        self.switch_screen("login")
        self.notify("Logged out successfully", severity="information")

    def action_quit(self) -> None:
        """Quit the application."""
        logger.info("Autobots TUI shutting down")
        # Close autobots client connection
        if hasattr(self, 'autobots_client'):
            self.autobots_client.close()
        self.exit()


def main():
    """Run the Autobots TUI application."""
    # Setup logging
    config_manager = ConfigManager()
    config = config_manager.load()
    setup_logging(log_level=config.log_level)

    logger.info("="*60)
    logger.info("Starting Autobots TUI")
    logger.info("="*60)

    # Run app
    app = AutobotsTUI(config_manager=config_manager)
    app.run()

    logger.info("Autobots TUI terminated")


if __name__ == "__main__":
    main()
