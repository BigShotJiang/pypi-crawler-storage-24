"""Reusable widgets for Autobots TUI."""

from textual.app import ComposeResult
from textual.containers import Container, Vertical, Horizontal
from textual.widgets import Static, Button, Label, DataTable
from textual.reactive import reactive
from rich.text import Text


class StatusBadge(Static):
    """A colored status badge widget."""

    DEFAULT_CSS = """
    StatusBadge {
        width: auto;
        height: 1;
        padding: 0 1;
        margin: 0 1;
    }

    StatusBadge.success {
        background: $success;
        color: $text;
    }

    StatusBadge.error {
        background: $error;
        color: $text;
    }

    StatusBadge.warning {
        background: $warning;
        color: $text;
    }

    StatusBadge.info {
        background: $accent;
        color: $text;
    }
    """

    def __init__(self, label: str, variant: str = "info", **kwargs):
        """Initialize status badge.

        Args:
            label: Text to display
            variant: Color variant (success, error, warning, info)
        """
        super().__init__(label, **kwargs)
        self.add_class(variant)


class StatCard(Container):
    """A card displaying a statistic."""

    DEFAULT_CSS = """
    StatCard {
        width: 1fr;
        height: auto;
        border: none;
        padding: 0;
        margin: 0 2;
    }

    StatCard > .stat-value {
        text-align: left;
        text-style: bold;
        color: #5fffff;
    }

    StatCard > .stat-label {
        text-align: left;
        color: $text-muted;
    }
    """

    value: reactive[str] = reactive("", init=False)
    label: reactive[str] = reactive("", init=False)

    def __init__(self, label: str, value: str = "0", **kwargs):
        """Initialize stat card.

        Args:
            label: Description of the stat
            value: Current value
        """
        super().__init__(**kwargs)
        self._initial_label = label
        self._initial_value = value

    def compose(self) -> ComposeResult:
        """Compose stat card widgets."""
        yield Static(self._initial_value, classes="stat-value")
        yield Static(self._initial_label, classes="stat-label")

    def on_mount(self) -> None:
        """Called when widget is mounted."""
        self.label = self._initial_label
        self.value = self._initial_value

    def watch_value(self, value: str) -> None:
        """Update displayed value."""
        if self.is_mounted:
            self.query_one(".stat-value", Static).update(value)

    def watch_label(self, label: str) -> None:
        """Update displayed label."""
        if self.is_mounted:
            self.query_one(".stat-label", Static).update(label)


class ActionButton(Button):
    """A styled action button."""

    DEFAULT_CSS = """
    ActionButton {
        min-width: 16;
        margin: 0 1;
        border: none;
        background: $surface;
        color: $text;
    }

    ActionButton:focus {
        background: #5fffff;
        color: black;
    }

    ActionButton.primary {
        color: #5fffff;
    }

    ActionButton.success {
        color: $success;
    }

    ActionButton.danger {
        color: $error;
    }
    """

    def __init__(self, label: str, variant: str = "primary", **kwargs):
        """Initialize action button.

        Args:
            label: Button text
            variant: Style variant (primary, success, danger)
        """
        super().__init__(label, **kwargs)
        self.add_class(variant)


class InfoPanel(Container):
    """An information panel with title and content."""

    DEFAULT_CSS = """
    InfoPanel {
        height: auto;
        border: none;
        padding: 0;
        margin: 1 0;
    }

    InfoPanel > .panel-title {
        text-style: bold;
        color: #5fffff;
        margin-bottom: 0;
    }

    InfoPanel > .panel-content {
        color: $text;
    }
    """

    def __init__(self, title: str, content: str = "", **kwargs):
        """Initialize info panel.

        Args:
            title: Panel title
            content: Panel content
        """
        super().__init__(**kwargs)
        self._title = title
        self._content = content

    def compose(self) -> ComposeResult:
        """Compose info panel widgets."""
        yield Static(self._title, classes="panel-title")
        yield Static(self._content, classes="panel-content")

    def update_content(self, content: str) -> None:
        """Update panel content.

        Args:
            content: New content to display
        """
        self.query_one(".panel-content", Static).update(content)
