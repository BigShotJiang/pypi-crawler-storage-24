#!/usr/bin/env python3
"""Simple test script to verify autobots client hello API."""

from src.autobots_tui.client import AutobotsClientWrapper
from src.autobots_tui.logger import setup_logging

# Setup logging
setup_logging(log_level="DEBUG")

# Test with default backend URL
print("Testing connection to Autobots backend...\n")

client = AutobotsClientWrapper(base_url="https://api.meetkiwi.ai")
success, message = client.hello()

print(f"Success: {success}")
print(f"Message: {message}")

client.close()
