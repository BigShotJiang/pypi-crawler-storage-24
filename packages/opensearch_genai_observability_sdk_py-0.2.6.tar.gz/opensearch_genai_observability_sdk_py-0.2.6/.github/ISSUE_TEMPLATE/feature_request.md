---
name: Feature request
about: Suggest an idea for this project
title: '[FEATURE] '
labels: 'enhancement'
assignees: ''

---

**Is your feature request related to a problem? Please describe.**
A clear and concise description of what the problem is. Ex. I'm always frustrated when [...]

**Describe the solution you'd like**
A clear and concise description of what you want to happen.

**Describe alternatives you've considered**
A clear and concise description of any alternative solutions or features you've considered.

**Use Case**
Describe the specific use case or scenario where this feature would be helpful.

**Example Usage**
```python
# Show how you would like to use this feature
```

**Additional context**
Add any other context or screenshots about the feature request here.

**Priority**
- [ ] High - This is blocking my project
- [ ] Medium - This would significantly improve my workflow
- [ ] Low - This would be nice to have