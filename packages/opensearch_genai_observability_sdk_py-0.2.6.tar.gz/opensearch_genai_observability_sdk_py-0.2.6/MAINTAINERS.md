## Overview

This document contains a list of maintainers in this repo. See [opensearch-project/.github/RESPONSIBILITIES.md](https://github.com/opensearch-project/.github/blob/main/RESPONSIBILITIES.md#maintainer-responsibilities) that explains what the role of maintainer means, what maintainers do in this and other repos, and how they should be doing it. If you're interested in contributing, and becoming a maintainer, see [CONTRIBUTING](CONTRIBUTING.md).

## Current Maintainers

| Maintainer            | GitHub ID                                                     | Affiliation |
| --------------------- | ------------------------------------------------------------- | ----------- |
| Vamsi Manohar         | [vamsimanohar](https://github.com/vamsimanohar)               | Amazon      |
| Kyle Hounslow         | [kylehounslow](https://github.com/kylehounslow)               | Amazon      |
| Joshua Li             | [joshuali925](https://github.com/joshuali925)                 | Amazon      |
