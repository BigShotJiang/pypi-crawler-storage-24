"""Shared helpers for examples/scripts and examples/example_agent."""

from __future__ import annotations

import asyncio
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path

from aep import AEP, Profile, ToolSchemaBinding
from aep.capability.tool.mcp import MCPTransport

EXAMPLES_DIR = Path(__file__).resolve().parents[1]
DEMO_PROFILE_SOURCE = EXAMPLES_DIR / "demo_profile"
RUNTIME_DIR = EXAMPLES_DIR / "runtime"
RUNTIME_PROFILE_DIR = RUNTIME_DIR / "demo_profile"
RUNTIME_WORKSPACE_DIR = RUNTIME_DIR / "workspace"


@dataclass(slots=True)
class CommandResult:
    status: str
    exit_code: int | None
    stdout: str
    stderr: str


def ensure_runtime_layout(*, reset: bool = False) -> None:
    if reset:
        if RUNTIME_PROFILE_DIR.exists():
            shutil.rmtree(RUNTIME_PROFILE_DIR)
        if RUNTIME_WORKSPACE_DIR.exists():
            shutil.rmtree(RUNTIME_WORKSPACE_DIR)
    RUNTIME_PROFILE_DIR.mkdir(parents=True, exist_ok=True)
    RUNTIME_WORKSPACE_DIR.mkdir(parents=True, exist_ok=True)


def build_demo_profile(
    *,
    reset: bool = False,
    tool_dependencies: list[str] | None = None,
    include_mcp: bool = False,
    mcp_server_script: Path | None = None,
) -> Profile:
    ensure_runtime_layout(reset=reset)
    profile = Profile(
        RUNTIME_PROFILE_DIR,
        auto_init_tool_env=False,
        include_default_tool_dependencies=False,
    )

    for tool_file in sorted((DEMO_PROFILE_SOURCE / "tools").glob("*.py")):
        profile.add_tool(tool_file, name=tool_file.stem)

    for skill_dir in sorted((DEMO_PROFILE_SOURCE / "skills").iterdir()):
        if skill_dir.is_dir():
            profile.add_skill(skill_dir, name=skill_dir.name)

    for doc_file in sorted((DEMO_PROFILE_SOURCE / "library").glob("*.md")):
        profile.add_library(doc_file, name=doc_file.name)

    if tool_dependencies:
        profile.add_tool_dependency(*tool_dependencies)

    if include_mcp:
        if mcp_server_script is None or not mcp_server_script.exists():
            raise FileNotFoundError(f"MCP server script not found: {mcp_server_script}")
        profile.add_mcp_server(
            "echo_mcp",
            transport=MCPTransport.STDIO,
            command=sys.executable,
            args=[str(mcp_server_script)],
        )

    profile.index()
    return profile


def create_demo_runtime(
    *,
    reset: bool = False,
    tool_dependencies: list[str] | None = None,
    include_mcp: bool = False,
    mcp_server_script: Path | None = None,
) -> tuple[Profile, AEP, ToolSchemaBinding]:
    profile = build_demo_profile(
        reset=reset,
        tool_dependencies=tool_dependencies,
        include_mcp=include_mcp,
        mcp_server_script=mcp_server_script,
    )
    aep = AEP(profile, workspace=RUNTIME_WORKSPACE_DIR)
    binding = aep.tool_schemas("demo-session")
    return profile, aep, binding


async def run_command_async(
    aep: AEP,
    session_id: str,
    command: str,
    *,
    timeout_ms: int = 120_000,
    output_limit: int = 512,
) -> CommandResult:
    result = await aep.call_tool(
        session_id,
        "aep_exec",
        {
            "command": command,
            "timeout_ms": timeout_ms,
            "output_limit": output_limit,
        },
    )

    stdout_parts: list[str] = [str(result.get("stdout", ""))]
    stderr_parts: list[str] = [str(result.get("stderr", ""))]
    exit_code = result.get("exit_code")
    status = str(result.get("status", "failed"))

    if result.get("is_running"):
        exec_id = str(result["exec_id"])
        cursor = int(result.get("next_cursor", 0))
        stdout_parts = [str(result.get("stdout_delta", ""))]
        stderr_parts = [str(result.get("stderr_delta", ""))]

        while True:
            output = await aep.call_tool(
                session_id,
                "aep_output",
                {
                    "exec_id": exec_id,
                    "cursor": cursor,
                    "limit": output_limit,
                },
            )
            stdout_parts.append(str(output.get("stdout_delta", "")))
            stderr_parts.append(str(output.get("stderr_delta", "")))
            status = str(output.get("status", status))
            exit_code = output.get("exit_code", exit_code)

            next_cursor = int(output.get("next_cursor", cursor))
            if next_cursor == cursor and not output.get("is_running"):
                break
            cursor = next_cursor

    return CommandResult(
        status=status,
        exit_code=exit_code,
        stdout="".join(stdout_parts),
        stderr="".join(stderr_parts),
    )


def run_command(
    aep: AEP,
    session_id: str,
    command: str,
    *,
    timeout_ms: int = 120_000,
    output_limit: int = 512,
) -> CommandResult:
    return asyncio.run(
        run_command_async(
            aep,
            session_id,
            command,
            timeout_ms=timeout_ms,
            output_limit=output_limit,
        )
    )


def print_command_result(title: str, command: str, result: CommandResult) -> None:
    print(f"\n[{title}]")
    print(f"$ {command}")
    if result.stdout.strip():
        print(result.stdout.strip())
    if result.stderr.strip():
        print("[stderr]")
        print(result.stderr.strip())
