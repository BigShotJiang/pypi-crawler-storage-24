"""Demo: investigate markdown docs via native shell search commands."""

from __future__ import annotations

import argparse
import os
import shutil

from _demo_common import create_demo_runtime, print_command_result, run_command


def _rg_command(rg_exe: str) -> str:
    quoted = f'"{rg_exe}"'
    if os.name == "nt":
        return f'& {quoted} -n -i -L -uu "tool|skill|aep|demo" .agents/library'
    return f'{quoted} -n -i -L -uu "tool|skill|aep|demo" .agents/library'


def _native_search_command() -> str:
    if os.name == "nt":
        return (
            "Get-ChildItem .agents\\library -Recurse -Filter *.md | "
            "Select-String -Pattern 'tool|skill|aep|demo' -CaseSensitive:$false"
        )
    return "grep -RniE 'tool|skill|aep|demo' .agents/library"


def _show_index_command() -> str:
    if os.name == "nt":
        return "cat .agents\\library\\index.md"
    return "cat .agents/library/index.md"


def main() -> None:
    parser = argparse.ArgumentParser(description="Run library markdown search demo.")
    parser.add_argument(
        "--reset",
        action="store_true",
        help="Reset examples/runtime before running",
    )
    args = parser.parse_args()

    _profile, aep, binding = create_demo_runtime(reset=args.reset)
    try:
        cmd_index = _show_index_command()
        result = run_command(aep, binding.session_id, cmd_index)
        print_command_result("library index", cmd_index, result)

        rg_exe = shutil.which("rg")
        if rg_exe:
            cmd_rg = _rg_command(rg_exe)
            result = run_command(aep, binding.session_id, cmd_rg)
            print_command_result("markdown search via rg", cmd_rg, result)

        cmd_native = _native_search_command()
        result = run_command(aep, binding.session_id, cmd_native)
        print_command_result("markdown search via native shell", cmd_native, result)
    finally:
        aep.detach()


if __name__ == "__main__":
    main()
