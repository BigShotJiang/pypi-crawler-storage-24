"""Demo: single and multiple skill calls with one demo profile."""

from __future__ import annotations

import argparse

from _demo_common import create_demo_runtime, print_command_result, run_command


def main() -> None:
    parser = argparse.ArgumentParser(description="Run skill-call demo scripts.")
    parser.add_argument(
        "--reset",
        action="store_true",
        help="Reset examples/runtime before running",
    )
    args = parser.parse_args()

    _profile, aep, binding = create_demo_runtime(reset=args.reset)
    try:
        result = run_command(aep, binding.session_id, "skills list")
        print_command_result("skills list", "skills list", result)

        cmd_single = "skills run hello-skill/scripts/hello.py Alice"
        result = run_command(aep, binding.session_id, cmd_single)
        print_command_result("single skill call", cmd_single, result)

        cmd_multi_1 = "skills run hello-skill/scripts/hello.py Bob"
        result = run_command(aep, binding.session_id, cmd_multi_1)
        print_command_result("multiple skills call (1/2)", cmd_multi_1, result)

        cmd_multi_2 = "skills run report-skill/scripts/report.py 2 3 5 8"
        result = run_command(aep, binding.session_id, cmd_multi_2)
        print_command_result("multiple skills call (2/2)", cmd_multi_2, result)
    finally:
        aep.detach()


if __name__ == "__main__":
    main()
