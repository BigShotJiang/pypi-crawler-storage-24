"""Demo: single/multi/chained tool calls with one demo profile."""

from __future__ import annotations

import argparse
from pathlib import Path

from _demo_common import create_demo_runtime, print_command_result, run_command


def main() -> None:
    parser = argparse.ArgumentParser(description="Run tool-call demo scripts.")
    parser.add_argument(
        "--reset",
        action="store_true",
        help="Reset examples/runtime before running",
    )
    args = parser.parse_args()

    root = Path(__file__).resolve().parents[2]
    echo_server = root / "tests" / "mcp" / "echo_server.py"

    _profile, aep, binding = create_demo_runtime(
        reset=args.reset,
        tool_dependencies=["pandas", "mcp"],
        include_mcp=True,
        mcp_server_script=echo_server,
    )
    try:
        result = run_command(aep, binding.session_id, "tools list")
        print_command_result("tools list", "tools list", result)

        cmd_single = 'tools run "tools.calc_tool.add(7, 9)"'
        result = run_command(aep, binding.session_id, cmd_single)
        print_command_result("single tool call", cmd_single, result)

        code_dataframe = """
df = tools.dataframe_tool.sample_sales()
df2 = tools.dataframe_tool.add_unit_price(df)
summary = tools.dataframe_tool.summary(df2)
top2 = tools.dataframe_tool.top_regions(df2, 2)
print({"summary": summary, "top_regions": top2})
""".strip()
        cmd_dataframe = f"tools run '''{code_dataframe}'''"
        result = run_command(aep, binding.session_id, cmd_dataframe)
        print_command_result("pandas dataframe example", cmd_dataframe, result)

        code_mcp = """
echo_result = tools.echo_mcp.echo(message="hello from mcp")
sum_result = tools.echo_mcp.add(a=13, b=29)
calc_result = tools.calc_tool.multiply(6, 7)
print({"mcp_echo": echo_result, "mcp_add": sum_result, "calc_result": calc_result})
""".strip()
        cmd_mcp = f"tools run '''{code_mcp}'''"
        result = run_command(aep, binding.session_id, cmd_mcp)
        print_command_result("mcp example", cmd_mcp, result)
    finally:
        aep.detach()


if __name__ == "__main__":
    main()
