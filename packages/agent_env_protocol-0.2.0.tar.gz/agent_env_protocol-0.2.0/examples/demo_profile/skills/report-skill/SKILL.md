---
name: report-skill
description: Build a numeric report from command-line inputs.
---

# Report Skill

Run:

```bash
skills run report-skill/scripts/report.py 2 3 5 8
```
