#!/usr/bin/env python3
"""Generate a small numeric report."""

from __future__ import annotations

import json
import sys


def main() -> None:
    if len(sys.argv) <= 1:
        print("Usage: skills run report-skill/scripts/report.py 1 2 3")
        return

    values = [float(item) for item in sys.argv[1:]]
    total = sum(values)
    report = {
        "count": len(values),
        "sum": total,
        "avg": total / len(values),
        "min": min(values),
        "max": max(values),
    }
    print(json.dumps(report, ensure_ascii=False))


if __name__ == "__main__":
    main()
