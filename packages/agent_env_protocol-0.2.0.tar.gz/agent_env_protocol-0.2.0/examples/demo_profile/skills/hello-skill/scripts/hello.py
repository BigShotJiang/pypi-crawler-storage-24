#!/usr/bin/env python3
"""Print a hello message for one user."""

from __future__ import annotations

import sys


def main() -> None:
    name = sys.argv[1] if len(sys.argv) > 1 else "User"
    print(f"[hello-skill] Hello, {name}!")


if __name__ == "__main__":
    main()
