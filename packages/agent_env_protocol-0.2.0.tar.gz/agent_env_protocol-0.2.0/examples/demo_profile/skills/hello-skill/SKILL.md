---
name: hello-skill
description: Print a greeting for one user.
---

# Hello Skill

Run:

```bash
skills run hello-skill/scripts/hello.py Alice
```
