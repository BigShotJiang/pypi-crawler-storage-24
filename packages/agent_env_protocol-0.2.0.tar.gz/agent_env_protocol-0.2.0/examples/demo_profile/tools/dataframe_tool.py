"""Pandas DataFrame helpers used by demo tool script."""

from __future__ import annotations

import pandas as pd


def sample_sales() -> pd.DataFrame:
    return pd.DataFrame(
        [
            {"region": "north", "sales": 120, "orders": 8},
            {"region": "south", "sales": 160, "orders": 10},
            {"region": "east", "sales": 90, "orders": 6},
            {"region": "west", "sales": 200, "orders": 12},
        ]
    )


def add_unit_price(df: pd.DataFrame) -> pd.DataFrame:
    result = df.copy()
    result["unit_price"] = result["sales"] / result["orders"]
    return result


def summary(df: pd.DataFrame) -> dict[str, float | int]:
    return {
        "rows": int(df.shape[0]),
        "total_sales": float(df["sales"].sum()),
        "avg_sales": float(df["sales"].mean()),
        "max_sales": float(df["sales"].max()),
    }


def top_regions(df: pd.DataFrame, n: int = 2) -> list[dict[str, float | int | str]]:
    top = df.sort_values("sales", ascending=False).head(max(1, n))
    return top.to_dict(orient="records")
