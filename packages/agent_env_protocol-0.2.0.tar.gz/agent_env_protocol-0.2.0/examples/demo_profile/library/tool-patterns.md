# Tool Patterns

Use one command for different patterns:

- Single tool call:
  `tools run "tools.calc_tool.add(7, 9)"`
- Pandas DataFrame flow:
  `tools run "df = tools.dataframe_tool.sample_sales(); print(tools.dataframe_tool.summary(df))"`
- MCP + local tool in one block:
  `tools run "print(tools.echo_mcp.add(a=1, b=2)); print(tools.calc_tool.multiply(3, 4))"`

When a command can have side effects, keep it small and explicit.
