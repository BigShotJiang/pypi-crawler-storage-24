# Demo Profile Quickstart

This demo profile provides:

- `tools`: callable Python modules for arithmetic/pandas processing
- `skills`: script-style capabilities runnable by `skills run`
- `library`: markdown docs that can be investigated by shell commands
- `mcp`: added by demo script as `echo_mcp` for remote-style tool calls

Typical flow:

1. `tools list`
2. `tools run "tools.calc_tool.add(2, 3)"`
3. `tools run "df = tools.dataframe_tool.sample_sales(); print(df.head())"`
4. `skills list`
5. `skills run hello-skill/scripts/hello.py Alice`
