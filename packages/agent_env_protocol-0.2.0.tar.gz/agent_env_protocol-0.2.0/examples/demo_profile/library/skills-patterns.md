# Skill Patterns

`skills run` is ideal for deterministic scripts.

Examples:

- `skills run hello-skill/scripts/hello.py Bob`
- `skills run report-skill/scripts/report.py 3 5 8`

To execute multiple skills, run multiple commands in sequence.
