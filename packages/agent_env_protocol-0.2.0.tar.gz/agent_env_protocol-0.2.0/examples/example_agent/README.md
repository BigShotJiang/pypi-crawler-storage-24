# Example Agent (OpenAI)

This interactive script uses one shared profile: `examples/demo_profile`.

## 1. Edit config

Update `openai_config.json`:

```json
{
  "api_key": "your_api_key_here",
  "base_url": "https://api.openai.com/v1",
  "model": "gpt-4.1-mini"
}
```

## 2. Run

From repository root:

```bash
uv run --with openai python examples/example_agent/chat_openai_agent.py --reset
```

Notes:
- Assistant responses are streamed token-by-token in terminal output.
- The demo session installs `pandas` into the runtime tool environment so `dataframe_tool` can load.
- Terminal output uses four distinct labels with ANSI color styling:
  - `user>` — your input
  - `thinking>` — model reasoning/thinking (dimmed gray)
  - `tool>` — tool calls and results, displayed as compact box-drawn cards
  - `response>` — final assistant response (bold)
- `aep_exec` / `aep_output` / `aep_kill` results show command, status, exit code, and stdout/stderr in a structured card format.
- DeepSeek reasoning models are supported — `reasoning_content` is written back into the assistant message without duplication.
- Multi-line execution blocks are supported (for example, `tools run PY<<...PY`).

After startup, chat directly:

```text
you> list available tools and run one simple calc
you> now run one skill for me
you> search docs for tool patterns
you> exit
```
