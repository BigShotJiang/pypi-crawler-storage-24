"""Terminal renderer for the example agent runtime."""

from __future__ import annotations

import json
import os
import re
import shutil
import sys
import unicodedata
from typing import Any

from agent_runtime import AgentEventHandler

PREVIEW_MAX_CHARS = 800

_RST = "\033[0m"
_BOLD = "\033[1m"
_DIM = "\033[2m"
_CYAN = "\033[36m"
_GREEN = "\033[32m"
_YELLOW = "\033[33m"
_RED = "\033[31m"
_GRAY = "\033[90m"

_S_THINK = _GRAY
_S_TOOL = _CYAN
_S_TOOL_DIM = _DIM + _CYAN
_S_ERR = _RED

_B_TL = "┌"
_B_TR = "┐"
_B_V = "│"
_B_BL = "└"
_B_BR = "┘"
_B_H = "─"

_TOOL_INDENT = "      "
_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


def init_ansi() -> None:
    if sys.platform == "win32":
        os.system("")


def print_banner(model: str) -> None:
    print(f"{_BOLD}Interactive AEP Agent{_RST} ({model})")
    print(f"{_DIM}Type 'exit' to quit.{_RST}\n")


def print_bye() -> None:
    print(f"{_BOLD}response>{_RST} bye")


def user_prompt() -> str:
    return f"{_BOLD}user>{_RST} "


def _preview(value: Any, max_chars: int = PREVIEW_MAX_CHARS) -> str:
    text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False)
    if len(text) <= max_chars:
        return text
    return f"{text[: max_chars - 3]}..."


def _char_width(ch: str) -> int:
    return 2 if unicodedata.east_asian_width(ch) in ("W", "F") else 1


def _strip_ansi(text: str) -> str:
    return _ANSI_RE.sub("", text)


def _display_width(text: str) -> int:
    return sum(_char_width(ch) for ch in _strip_ansi(text))


def _tool_box_w() -> int:
    try:
        cols = shutil.get_terminal_size().columns
    except Exception:
        cols = 80
    return max(cols - 10, 40)


def _wrap_text(text: str, max_w: int) -> list[str]:
    out: list[str] = []
    for paragraph in text.splitlines():
        if not paragraph:
            out.append("")
            continue
        current: list[str] = []
        col = 0
        for ch in paragraph:
            cw = _char_width(ch)
            if col + cw > max_w:
                out.append("".join(current))
                current = [ch]
                col = cw
            else:
                current.append(ch)
                col += cw
        out.append("".join(current))
    return out or [""]


class _ThinkingPrinter:
    _LABEL = "thinking>"
    _INDENT = " " * 10

    def __init__(self) -> None:
        try:
            cols = shutil.get_terminal_size().columns
        except Exception:
            cols = 80
        self._max_w = max(cols - len(self._INDENT) - 4, 30)
        self._col = 0
        self._started = False

    @property
    def started(self) -> bool:
        return self._started

    def write(self, text: str) -> None:
        if not text:
            return
        if not self._started:
            self._header()
        for ch in text:
            if ch == "\n":
                self._newline()
            else:
                cw = _char_width(ch)
                if self._col + cw > self._max_w:
                    self._newline()
                sys.stdout.write(ch)
                self._col += cw
        sys.stdout.flush()

    def close(self) -> None:
        if not self._started:
            return
        pad = self._max_w - self._col
        bar_w = self._max_w + 2
        sys.stdout.write(
            f"{' ' * pad} {_B_V}{_RST}\n"
            f"{_S_THINK}{self._INDENT}{_B_BL}{_B_H * bar_w}{_B_BR}{_RST}\n"
        )
        sys.stdout.flush()

    def _header(self) -> None:
        bar_w = self._max_w + 2
        sys.stdout.write(
            f"{_S_THINK}{self._LABEL} {_B_TL}{_B_H * bar_w}{_B_TR}{_RST}\n"
            f"{_S_THINK}{self._INDENT}{_B_V} {_RST}{_S_THINK}"
        )
        self._started = True

    def _newline(self) -> None:
        pad = self._max_w - self._col
        sys.stdout.write(
            f"{' ' * pad} {_B_V}{_RST}\n"
            f"{_S_THINK}{self._INDENT}{_B_V} {_RST}{_S_THINK}"
        )
        self._col = 0


def _box_line(styled_text: str, box_w: int, *, border_style: str = _S_TOOL) -> None:
    width = _display_width(styled_text)
    pad = max(0, box_w - width)
    print(
        f"{border_style}{_TOOL_INDENT}{_B_V}{_RST} "
        f"{styled_text}{' ' * pad} "
        f"{border_style}{_B_V}{_RST}"
    )


def _card_header(tool_name: str, box_w: int) -> None:
    fill = max(0, box_w - len(tool_name))
    print(
        f"{_S_TOOL}tool> {_B_TL} {_BOLD}{tool_name}{_RST}"
        f"{_S_TOOL} {_B_H * fill}{_B_TR}{_RST}"
    )


def _card_footer(box_w: int) -> None:
    print(f"{_S_TOOL}{_TOOL_INDENT}{_B_BL}{_B_H * (box_w + 2)}{_B_BR}{_RST}")


def _print_exec_card(
    tool_name: str,
    arguments: dict[str, Any],
    result: dict[str, Any],
) -> None:
    box_w = _tool_box_w()
    _card_header(tool_name, box_w)

    command = arguments.get("command")
    if isinstance(command, str) and command.strip():
        cmd_lines = _preview(command.strip(), 600).splitlines()
        for line_index, line in enumerate(cmd_lines):
            first_chunk = True
            for wrapped in _wrap_text(line, box_w - 2):
                prefix = f"{_BOLD}$ {_RST}" if line_index == 0 and first_chunk else "  "
                _box_line(f"{prefix}{wrapped}", box_w)
                first_chunk = False

    status = result.get("status", "?")
    exit_code = result.get("exit_code")
    is_running = result.get("is_running", False)
    timed_out = result.get("timed_out", False)

    parts = [f"status={status}"]
    if exit_code is not None:
        code_color = _GREEN if exit_code == 0 else _RED
        parts.append(f"{code_color}code={exit_code}{_RST}")
    if is_running:
        parts.append(f"{_YELLOW}running{_RST}")
    if timed_out:
        parts.append(f"{_YELLOW}timed_out{_RST}")
    _box_line("  ".join(parts), box_w)

    stdout_text = result.get("stdout") or result.get("stdout_delta")
    if isinstance(stdout_text, str) and stdout_text.strip():
        sep = f"{_S_TOOL}{_B_H * 2} stdout {_B_H * max(0, box_w - 10)}{_RST}"
        _box_line(sep, box_w)
        for raw_line in _preview(stdout_text).splitlines():
            for wrapped in _wrap_text(raw_line, box_w):
                _box_line(wrapped, box_w)

    stderr_text = result.get("stderr") or result.get("stderr_delta")
    if isinstance(stderr_text, str) and stderr_text.strip():
        sep = f"{_S_ERR}{_B_H * 2} stderr {_B_H * max(0, box_w - 10)}{_RST}"
        _box_line(sep, box_w, border_style=_S_ERR)
        for raw_line in _preview(stderr_text).splitlines():
            for wrapped in _wrap_text(raw_line, box_w):
                _box_line(f"{_DIM}{wrapped}{_RST}", box_w, border_style=_S_ERR)

    if is_running:
        exec_id = result.get("exec_id", "")
        cursor = result.get("next_cursor", 0)
        _box_line(f"{_S_TOOL_DIM}exec_id={exec_id}  cursor={cursor}{_RST}", box_w)

    has_stdout = isinstance(stdout_text, str) and stdout_text.strip()
    has_stderr = isinstance(stderr_text, str) and stderr_text.strip()
    if not has_stdout and not has_stderr:
        skip = {
            "ok",
            "tool",
            "exec_id",
            "status",
            "is_running",
            "timed_out",
            "queue_pos",
            "exit_code",
            "next_cursor",
            "chunks",
        }
        extra = {key: value for key, value in result.items() if key not in skip}
        if extra:
            for wrapped in _wrap_text(_preview(extra, 400), box_w):
                _box_line(f"{_DIM}{wrapped}{_RST}", box_w)

    _card_footer(box_w)


def _print_generic_card(
    tool_name: str,
    arguments: dict[str, Any],
    result: dict[str, Any],
) -> None:
    box_w = _tool_box_w()
    _card_header(tool_name, box_w)
    if arguments:
        for wrapped in _wrap_text(f"args: {_preview(arguments, 200)}", box_w):
            _box_line(f"{_DIM}{wrapped}{_RST}", box_w)
    for wrapped in _wrap_text(_preview(result, 600), box_w):
        _box_line(wrapped, box_w)
    _card_footer(box_w)


def print_tool_result(
    tool_name: str,
    arguments: dict[str, Any],
    result: dict[str, Any],
) -> None:
    if tool_name in {"aep_exec", "aep_output", "aep_kill"}:
        _print_exec_card(tool_name, arguments, result)
    else:
        _print_generic_card(tool_name, arguments, result)


class TerminalAgentEventHandler(AgentEventHandler):
    def __init__(self) -> None:
        self._thinking = _ThinkingPrinter()
        self._response_started = False

    def on_reasoning_delta(self, text: str) -> None:
        self._thinking.write(text)

    def on_response_start(self) -> None:
        if self._thinking.started:
            self._thinking.close()
        if not self._response_started:
            sys.stdout.write(f"{_BOLD}response>{_RST} ")
            self._response_started = True

    def on_response_delta(self, text: str) -> None:
        if not self._response_started:
            self.on_response_start()
        sys.stdout.write(text)
        sys.stdout.flush()

    def on_response_end(self) -> None:
        if self._response_started:
            sys.stdout.write("\n")
            sys.stdout.flush()
            self._response_started = False

    def on_assistant_message_end(self, *, had_thinking: bool, had_response: bool) -> None:
        if had_thinking and not had_response and self._thinking.started:
            self._thinking.close()
        self._thinking = _ThinkingPrinter()

    def on_tool_result(
        self,
        *,
        tool_name: str,
        arguments: dict[str, Any],
        result: dict[str, Any],
    ) -> None:
        print_tool_result(tool_name, arguments, result)

    def on_empty_response(self) -> None:
        print(f"{_BOLD}response>{_RST} ")

    def on_max_tool_turns(self, max_tool_turns: int) -> None:
        print(f"{_BOLD}response>{_RST} Reached max tool turns ({max_tool_turns}).")
