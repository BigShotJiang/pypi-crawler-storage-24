"""Interactive OpenAI agent demo using one shared demo profile."""

from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path

from agent_runtime import OpenAIAEPAgent, build_system_prompt, needs_reasoning_content
from terminal_ui import (
    TerminalAgentEventHandler,
    init_ansi,
    print_banner,
    print_bye,
    user_prompt,
)

SCRIPTS_DIR = Path(__file__).resolve().parents[1] / "scripts"
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

from _demo_common import create_demo_runtime  # noqa: E402

OPENAI_API_KEY = "your_api_key_here"
OPENAI_BASE_URL = "https://api.openai.com/v1"
OPENAI_MODEL = "gpt-4.1-mini"

DEFAULT_CONFIG_FILE = Path(__file__).resolve().parent / "openai_config.json"


def load_llm_config(config_path: Path) -> dict[str, str]:
    default = {
        "api_key": OPENAI_API_KEY,
        "base_url": OPENAI_BASE_URL,
        "model": OPENAI_MODEL,
    }
    if not config_path.exists():
        return default
    data = json.loads(config_path.read_text(encoding="utf-8"))
    return {
        "api_key": str(data.get("api_key", OPENAI_API_KEY)).strip(),
        "base_url": str(data.get("base_url", OPENAI_BASE_URL)).strip(),
        "model": str(data.get("model", OPENAI_MODEL)).strip(),
    }


async def run_chat(config_file: Path, reset: bool) -> None:
    try:
        from openai import AsyncOpenAI
    except ImportError as exc:
        raise RuntimeError(
            "OpenAI SDK is required. Run: uv run --with openai "
            "python examples/example_agent/chat_openai_agent.py"
        ) from exc

    init_ansi()

    _profile, aep, binding = create_demo_runtime(
        reset=reset,
        tool_dependencies=["pandas"],
    )
    try:
        llm = load_llm_config(config_file)
        api_key = llm["api_key"]
        base_url = llm["base_url"]
        model = llm["model"]
        if not api_key or api_key == "your_api_key_here":
            raise RuntimeError(
                "Please set OPENAI_API_KEY in script or write api_key into "
                f"{config_file}"
            )

        context = aep.build_context(
            include_tools=True,
            include_skills=True,
            include_library=True,
        )
        system_prompt = build_system_prompt(
            capability_context=context,
            assistant_description=(
                "You are an interactive assistant for the local AEP demo profile."
            ),
        )

        client = AsyncOpenAI(api_key=api_key, base_url=base_url)

        async def call_bound_tool(
            name: str,
            arguments: dict[str, object],
        ) -> dict[str, object]:
            return await aep.call_tool(binding.session_id, name, arguments)

        agent = OpenAIAEPAgent(
            client=client,
            model=model,
            tools=binding.schemas,
            call_tool=call_bound_tool,
            system_prompt=system_prompt,
            include_reasoning_content=needs_reasoning_content(base_url),
        )

        print_banner(model)
        while True:
            try:
                user_input = input(user_prompt()).strip()
            except (EOFError, KeyboardInterrupt):
                print()
                print_bye()
                return
            if not user_input:
                continue
            if user_input.lower() in {"exit", "quit"}:
                print_bye()
                return
            await agent.run_user_turn(
                user_input,
                handler=TerminalAgentEventHandler(),
            )
    finally:
        aep.detach()


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Interactive OpenAI + AEP demo agent.")
    parser.add_argument(
        "--config",
        default=str(DEFAULT_CONFIG_FILE),
        help="Path to OpenAI config JSON file",
    )
    parser.add_argument(
        "--reset",
        action="store_true",
        help="Reset examples/runtime before running",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    asyncio.run(run_chat(config_file=Path(args.config).resolve(), reset=args.reset))


if __name__ == "__main__":
    main()
