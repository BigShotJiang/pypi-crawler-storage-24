"""Reusable agent runtime for the example OpenAI + AEP agent."""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any, Awaitable, Callable

DEFAULT_MAX_TOOL_TURNS = 20


def parse_tool_args(raw: str | None) -> dict[str, Any]:
    if not raw:
        return {}
    try:
        parsed = json.loads(raw)
    except (TypeError, json.JSONDecodeError):
        return {}
    return parsed if isinstance(parsed, dict) else {}


def needs_reasoning_content(base_url: str) -> bool:
    return "deepseek" in base_url.strip().lower()


def build_system_prompt(
    *,
    capability_context: str,
    assistant_description: str,
) -> str:
    return "\n\n".join(
        [
            capability_context,
            assistant_description,
        ]
    )


def _collect_text_parts(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        return [value]
    if isinstance(value, list):
        parts: list[str] = []
        for item in value:
            parts.extend(_collect_text_parts(item))
        return parts
    if isinstance(value, dict):
        parts = []
        for key in ("text", "content", "value", "summary"):
            if key in value:
                parts.extend(_collect_text_parts(value[key]))
        return parts

    parts = []
    for attr in ("text", "content", "value", "summary"):
        attr_value = getattr(value, attr, None)
        if attr_value is not None:
            parts.extend(_collect_text_parts(attr_value))
    return parts


def _extract_reasoning_text(delta: Any) -> str:
    seen: set[str] = set()
    for attr in ("reasoning_content", "reasoning", "thinking_content", "thinking"):
        text = "".join(_collect_text_parts(getattr(delta, attr, None)))
        if text and text not in seen:
            return text
        if text:
            seen.add(text)

    model_extra = getattr(delta, "model_extra", None)
    if isinstance(model_extra, dict):
        for key in ("reasoning_content", "reasoning", "thinking_content", "thinking"):
            text = "".join(_collect_text_parts(model_extra.get(key)))
            if text and text not in seen:
                return text
    return ""


def _extract_response_text(delta: Any) -> str:
    content = getattr(delta, "content", None)
    if isinstance(content, str):
        return content
    return "".join(_collect_text_parts(content))


@dataclass(slots=True)
class AssistantStreamResult:
    payload: dict[str, Any]
    had_thinking: bool
    had_response: bool


class AgentEventHandler:
    """UI/event sink for agent-loop updates."""

    def on_reasoning_delta(self, text: str) -> None:
        del text

    def on_response_start(self) -> None:
        pass

    def on_response_delta(self, text: str) -> None:
        del text

    def on_response_end(self) -> None:
        pass

    def on_assistant_message_end(self, *, had_thinking: bool, had_response: bool) -> None:
        del had_thinking, had_response

    def on_tool_result(
        self,
        *,
        tool_name: str,
        arguments: dict[str, Any],
        result: dict[str, Any],
    ) -> None:
        del tool_name, arguments, result

    def on_empty_response(self) -> None:
        pass

    def on_max_tool_turns(self, max_tool_turns: int) -> None:
        del max_tool_turns


class OpenAIAEPAgent:
    """Stateful agent runner that is independent from any specific UI."""

    def __init__(
        self,
        *,
        client: Any,
        model: str,
        tools: list[dict[str, Any]],
        call_tool: Callable[[str, dict[str, Any]], Awaitable[dict[str, Any]]],
        system_prompt: str,
        include_reasoning_content: bool = False,
        max_tool_turns: int = DEFAULT_MAX_TOOL_TURNS,
    ) -> None:
        self._client = client
        self._model = model
        self._tools = tools
        self._call_tool = call_tool
        self._include_reasoning_content = include_reasoning_content
        self._max_tool_turns = max_tool_turns
        self._messages: list[dict[str, Any]] = [
            {"role": "system", "content": system_prompt},
        ]

    @property
    def messages(self) -> list[dict[str, Any]]:
        return list(self._messages)

    async def run_user_turn(
        self,
        user_input: str,
        *,
        handler: AgentEventHandler | None = None,
    ) -> None:
        if not user_input.strip():
            raise ValueError("user_input must be non-empty")
        event_handler = handler or AgentEventHandler()
        self._messages.append({"role": "user", "content": user_input})
        await self._run_turn_loop(handler=event_handler)

    async def _run_turn_loop(self, *, handler: AgentEventHandler) -> None:
        for _ in range(self._max_tool_turns):
            assistant = await self._stream_assistant_message(
                tools=self._tools,
                handler=handler,
            )
            self._messages.append(assistant.payload)

            if not assistant.payload.get("tool_calls"):
                if not assistant.had_response and not assistant.had_thinking:
                    handler.on_empty_response()
                return

            for tool_call in assistant.payload["tool_calls"]:
                fn = tool_call.get("function", {})
                arguments = parse_tool_args(fn.get("arguments"))
                tool_name = fn.get("name")
                if not isinstance(tool_name, str):
                    tool_name = ""
                result = await self._call_tool(tool_name, arguments)
                handler.on_tool_result(
                    tool_name=tool_name,
                    arguments=arguments,
                    result=result,
                )
                self._messages.append(
                    {
                        "role": "tool",
                        "tool_call_id": str(tool_call.get("id", "")),
                        "content": json.dumps(result, ensure_ascii=False),
                    }
                )
        handler.on_max_tool_turns(self._max_tool_turns)

    async def _stream_assistant_message(
        self,
        *,
        tools: list[dict[str, Any]],
        handler: AgentEventHandler,
    ) -> AssistantStreamResult:
        stream = await self._client.chat.completions.create(
            model=self._model,
            messages=self._messages,
            tools=tools,
            tool_choice="auto",
            temperature=0,
            stream=True,
        )

        content_parts: list[str] = []
        reasoning_parts: list[str] = []
        tool_calls: dict[int, dict[str, Any]] = {}
        response_started = False

        async for chunk in stream:
            if not chunk.choices:
                continue
            choice = chunk.choices[0]
            delta = choice.delta

            reasoning_text = _extract_reasoning_text(delta)
            response_text = _extract_response_text(delta)
            if reasoning_text and response_text and reasoning_text == response_text:
                response_text = ""

            if reasoning_text:
                handler.on_reasoning_delta(reasoning_text)
                reasoning_parts.append(reasoning_text)

            if response_text:
                if not response_started:
                    handler.on_response_start()
                    response_started = True
                handler.on_response_delta(response_text)
                content_parts.append(response_text)

            for delta_call in delta.tool_calls or []:
                call = tool_calls.setdefault(
                    delta_call.index,
                    {
                        "id": delta_call.id or f"call_{delta_call.index}",
                        "type": delta_call.type or "function",
                        "function": {"name": "", "arguments": ""},
                    },
                )
                if delta_call.id:
                    call["id"] = delta_call.id
                if delta_call.type:
                    call["type"] = delta_call.type
                if delta_call.function:
                    if delta_call.function.name:
                        call["function"]["name"] += delta_call.function.name
                    if delta_call.function.arguments:
                        call["function"]["arguments"] += delta_call.function.arguments

        if response_started:
            handler.on_response_end()

        had_thinking = bool(reasoning_parts)
        had_response = bool(content_parts)
        handler.on_assistant_message_end(
            had_thinking=had_thinking,
            had_response=had_response,
        )

        payload: dict[str, Any] = {
            "role": "assistant",
            "content": "".join(content_parts),
        }
        if self._include_reasoning_content and reasoning_parts:
            payload["reasoning_content"] = "".join(reasoning_parts)
        if tool_calls:
            ordered = [tool_calls[idx] for idx in sorted(tool_calls)]
            for index, call in enumerate(ordered):
                if not call["id"]:
                    call["id"] = f"call_{index}"
                if not call["function"]["arguments"]:
                    call["function"]["arguments"] = "{}"
            payload["tool_calls"] = ordered

        return AssistantStreamResult(
            payload=payload,
            had_thinking=had_thinking,
            had_response=had_response,
        )
