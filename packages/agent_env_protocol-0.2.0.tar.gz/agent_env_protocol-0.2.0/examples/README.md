# Examples Layout

The examples folder now uses one shared profile source: `examples/demo_profile`.

## Directory structure

- `demo_profile/`
  - `tools/`: demo tools
  - `skills/`: demo skills
  - `library/`: demo markdown docs
- `scripts/`
  - `demo_tools.py`: single call + pandas DataFrame + MCP tool calls
  - `demo_skills.py`: single / multiple skill calls
  - `demo_library_search.py`: markdown investigation via native shell search
- `example_agent/`
  - `chat_openai_agent.py`: interactive OpenAI agent wired to AEP
  - `openai_config.json`: API config file
- `runtime/`: generated runtime profile/workspace (git-ignored)

## Quick run

From repository root:

```bash
uv run python examples/scripts/demo_tools.py --reset
uv run python examples/scripts/demo_skills.py
uv run python examples/scripts/demo_library_search.py
uv run --with openai python examples/example_agent/chat_openai_agent.py
```
