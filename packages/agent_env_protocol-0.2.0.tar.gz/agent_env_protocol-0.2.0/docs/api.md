# AEP API Reference

本文档对应当前 `src/aep/*` 主体结构，不包含旧 `AEPWorkspace / AEPProfile / AEPSessionToolAdapter` 兼容层。

## Public API

```python
from aep import AEP, Profile, ToolSchemaBinding
```

- `Profile`: capability 配置与索引管理
- `AEP`: 运行时门面，负责 mount、context、session-bound tools、tool dispatch
- `ToolSchemaBinding`: 一个轻量结构，包含 `session_id` 和 `schemas`

CLI 入口仍然是 `src/aep/cli.py`。

## Profile

文件：`src/aep/profile.py`

### 构造

```python
Profile(
    config_dir: str | Path,
    *,
    auto_init_tool_env: bool = False,
    include_default_tool_dependencies: bool = True,
    tool_dependencies: list[str] | None = None,
)
```

### 资源方法

- `add_tool(source, name=None, dependencies=None) -> Path`
- `add_skill(source, name=None, dependencies=None) -> Path`
- `add_library(source, name=None, target_dir=None) -> Path`
- `add_mcp_server(name, **kwargs) -> Path`
- `add_tool_dependency(*packages) -> Path`
- `init_tool_environment(dependencies=None, include_default=True) -> Path`
- `index(library_chunk_size_lines=None, library_max_summary_chars=None) -> None`

### handler 属性

- `tools`
- `skills`
- `library`
- `mcp`

### 目录属性

- `config_dir`
- `tools_dir`
- `skills_dir`
- `library_dir`

`Profile` 不再负责 agent prompt 拼装。它只负责能力资源和索引生成。

## AEP

文件：`src/aep/runtime/aep.py`

### 构造

```python
AEP(
    config: str | Path | Profile,
    *,
    workspace: str | Path,
    agent_dir: str = ".agents",
    max_queue_size: int = 32,
)
```

一个 `AEP` 绑定：

- 一个 profile
- 一个 workspace
- 一个 `.agents/` mount 目录
- 多个惰性创建的 logical sessions

不同 `session_id` 隔离：

- 命令历史
- 自定义环境变量
- cwd

### build_context()

```python
build_context(
    *,
    include_tools: bool = True,
    include_skills: bool = True,
    include_library: bool = True,
) -> str
```

返回给模型的统一上下文，内容包括：

1. 这是为 agent 打造的终端环境说明
2. 暴露的 5 个 tool schema 及用途
3. `tools run` 单行 / 多行用法
4. `skills run` 用法
5. 当前 profile 生成的 `index.md`

### tool_schemas(session_id)

```python
tool_schemas(session_id: str) -> ToolSchemaBinding
```

返回值：

```python
ToolSchemaBinding(
    session_id="agent-1-session",
    schemas=[...],
)
```

语义：

- `schemas` 传给模型
- `session_id` 留在宿主侧
- 调用时不会把 `session_id` 暴露给模型
- 同一个 `AEP` 可以为多个 agent 生成不同的 binding

### call_tool(session_id, name, arguments)

```python
await call_tool(
    session_id: str,
    name: str,
    arguments: Mapping[str, Any] | None = None,
) -> dict[str, Any]
```

宿主显式按 `session_id` 路由 tool call。

这一步是 session 管理显式可见的地方，不靠全局 active session，也不要求模型传 `session_id`。

### detach()

```python
detach() -> None
```

释放所有 session，并清理 workspace 下 `.agents/` 的挂载链接。

## ToolSchemaBinding

文件：`src/aep/runtime/bound_tools.py`

```python
@dataclass(slots=True)
class ToolSchemaBinding:
    session_id: str
    schemas: list[dict[str, object]]
```

这是一个轻量绑定对象，不承担执行逻辑。执行统一回到 `AEP.call_tool(...)`。

## Default Tool Schemas

文件：`src/aep/runtime/context.py`

默认暴露 5 个 function tools：

- `aep_exec`
- `aep_output`
- `aep_kill`
- `aep_history`
- `aep_env`

它们都作用于“当前绑定 session”，但 `session_id` 由宿主路由，不是模型参数。

### aep_exec

```python
{
  "command": str,
  "timeout_ms": int = 8000,
  "output_limit": int = 200,
}
```

执行一条命令。命令可以是：

- shell 命令，例如 `pwd`
- `tools list`
- `tools run "tools.calc.add(1, 2)"`
- `tools run PY<< ... PY`
- `skills run <skill>/scripts/<script>.py`

### aep_output

```python
{
  "exec_id": str,
  "cursor": int = 0,
  "limit": int = 200,
}
```

读取某次执行的增量输出。

### aep_kill

```python
{
  "exec_id": str,
  "cursor": int = 0,
  "limit": int = 200,
}
```

终止某次排队中或运行中的执行，并返回后续输出。

### aep_history

```python
{
  "limit": int = 10,
  "include_output": bool = False,
  "output_preview_chars": int = 600,
}
```

读取当前 session 的执行历史。

### aep_env

```python
{
  "keys": list[str] | None = None,
}
```

读取当前 session 的自定义环境变量。

## Host Integration Pattern

典型宿主流程：

1. 创建 `Profile` 并生成 index
2. 创建 `AEP`
3. 调用 `build_context()` 生成系统提示词上下文
4. 对每个 agent 调用 `tool_schemas(session_id)`
5. 把 `binding.schemas` 提供给模型
6. 模型返回 tool call 后，宿主使用 `binding.session_id` 调 `aep.call_tool(...)`

示例：

```python
binding = aep.tool_schemas("agent-1")
tools = binding.schemas

result = await aep.call_tool(
    binding.session_id,
    "aep_exec",
    {"command": "tools list"},
)
```

双 agent 示例：

```python
binding1 = aep.tool_schemas("agent-1")
binding2 = aep.tool_schemas("agent-2")

tools_for_agent1 = binding1.schemas
tools_for_agent2 = binding2.schemas

result1 = await aep.call_tool(binding1.session_id, "aep_env", {})
result2 = await aep.call_tool(binding2.session_id, "aep_env", {})
```

两边拿到的是同一组 tool 名称，但指向不同 session。

## Capability Modules

当前能力实现位于：

- `src/aep/capability/tool/`
- `src/aep/capability/skill/`
- `src/aep/capability/library/`
- `src/aep/capability/indexing/`

`Profile` 通过 handler 聚合它们：

- `ToolsHandler`
- `SkillsHandler`
- `LibraryHandler`
- `MCPHandler`

这些 handler 仍然可以通过 `profile.tools` / `profile.skills` / `profile.library` / `profile.mcp` 访问，但对外推荐优先使用 `Profile` 的便捷方法。

## Runtime Internals

当前 runtime 代码位于：

- `src/aep/runtime/aep.py`
- `src/aep/runtime/context.py`
- `src/aep/runtime/bound_tools.py`
- `src/aep/runtime/session/`

其中：

- `runtime/aep.py`: 公开运行时门面
- `runtime/context.py`: agent-facing context 与 tool schema 定义
- `runtime/bound_tools.py`: `ToolSchemaBinding` 与 session tool runtime
- `runtime/session/`: 会话状态、执行器、输出缓冲、历史记录

## CLI

常用命令：

- `aep index --profile <config>`
- `aep tool add <source> --profile <config>`
- `aep skill add <source> --profile <config>`
- `aep library add <source> --profile <config>`
- `aep shell --profile <config> --workspace <workspace>`

`shell` 复用的就是同一套 `tools run` / `skills run` / shell passthrough 语义。
