﻿# Agent Environment Protocol (AEP) Architecture

## 1. 系统目标

AEP 的目标是把 Agent 能力管理分成三层：

1. 配置层：注册 tools / skills / library / mcp
2. 挂载层：把配置目录挂到工作区 `.agents/`
3. 运行层：通过统一命令执行能力

核心对象：

- `AEPProfile`：配置管理
- `AEPWorkspace`：挂载入口
- `AEPSession`：运行时入口（`run/output/wait/kill`）

## 2. 目录结构

配置目录：

```text
config_dir/
├── tools/
│   ├── .venv/
│   ├── requirements.txt
│   ├── index.md
│   └── *.py
├── skills/
│   ├── index.md
│   └── <skill-name>/
│       ├── .venv/
│       ├── SKILL.md
│       ├── requirements.txt
│       └── scripts/...
├── library/
│   ├── index.md
│   └── *.md
└── _mcp/
    └── <server>/
        └── config.json
```

工作区挂载目录：

```text
workspace/.agents/
├── tools   -> symlink to config/tools
├── skills  -> symlink to config/skills
└── library -> symlink to config/library
```

## 3. 核心模块

```text
src/aep/
├── profile.py                 # AEPProfile：配置门面 + context 构建
├── workspace.py               # AEPWorkspace.attach/detach + session 管理
├── session/
│   ├── manager.py             # AEPSession 生命周期（run/output/wait/kill）
│   ├── command_executor.py    # 单入口命令分发（tools/skills/cd/export/shell）
│   ├── capability_commands.py # tools/skills 子命令实现与执行准备
│   ├── execution_state.py     # 执行状态机与输出缓冲
│   ├── subprocess_runner.py   # 子进程执行与流式输出采集
│   ├── history.py             # ExecutionFact 历史记录
│   └── models.py              # RunResponse/OutputResponse/... 数据模型
├── datamodels/
│   ├── config.py              # EnvConfig, MCPServerConfig
│   └── session.py             # ExecResult
├── tool/
│   ├── handler.py             # tools 管理
│   └── mcp/                   # MCP transport/handler/stubgen
├── skill/
│   ├── handler.py             # skills 管理
│   ├── parser.py              # SKILL.md frontmatter 解析
│   └── validator.py           # skills 规范校验
├── library/handler.py         # library 管理与索引
└── indexing/                  # 通用 index 数据模型与渲染
```

## 4. 调用链路

### 4.1 配置阶段

- `AEPProfile` 初始化目录
- `add_tool` / `add_skill` / `add_library` / `add_mcp_server`
- `index()` 生成三类索引

### 4.2 挂载阶段

- `AEPWorkspace.attach(workspace, config)` 创建 `.agents`
- 创建 `tools/skills/library` 三个符号链接

### 4.3 运行阶段

- `AEPSession.run(command)` 提交命令进入会话队列
- `CommandExecutor` 按前缀路由：
  - `tools ...`
  - `skills ...`
  - `cd` / `export`
  - 其他命令透传 shell

执行组件：

- `CapabilityCommands`：处理 `tools/skills list|info|run` 子命令
- `subprocess_runner`：执行子进程并采集 stdout/stderr
- `ExecutionState`：维护状态、输出缓冲、历史快照

## 5. Skills 设计（当前实现）

### 5.1 输入模式

`SkillsHandler.add(source, name=None, dependencies=None)` 支持：

- 目录输入：复制整个 skill 目录
- 单文件输入：仅接受 `.md`，按 frontmatter `name` 建目录并保存为 `SKILL.md`

### 5.2 校验

添加后会调用本地 validator（`src/aep/skill/validator.py`）做规范校验：

- 必填字段：`name`, `description`
- `name` 格式校验
- `description` 长度校验
- 目录名与 `name` 一致性
- 不允许未定义 frontmatter 字段

校验失败会回滚删除目标 skill 目录。

### 5.3 索引

`skills/index.md` 由 parser 读取 `SKILL.md` frontmatter 生成：

- `name`
- `description`
- `path`（skill 目录）

并追加统一运行提示：`skills run xx.py`。

## 6. MCP 设计

`MCPHandler.add(...)` 支持两种传输：

- `STDIO`：`command + args + env`
- `HTTP`：`url + headers`

流程：

1. 参数校验
2. 前置工具检查（STDIO）
3. 保存 `_mcp/<name>/config.json`
4. 连接并发现 tools
5. 生成 `tools/<name>.py` stub

## 7. 上下文拼装

`AEPProfile.build_context()` 会拼接：

- `tools/index.md`
- `skills/index.md`
- `library/index.md`

用于给 Agent 注入 L0 能力概览。

## 8. 关键权衡

- 通过目录和 index 保持可审计与可读性
- skills 强制 frontmatter 校验，降低运行期歧义
- 工具与技能分离 venv，隔离依赖污染
- MCP 统一转换为 tools 调用语法，减少 Agent 侧分支逻辑
