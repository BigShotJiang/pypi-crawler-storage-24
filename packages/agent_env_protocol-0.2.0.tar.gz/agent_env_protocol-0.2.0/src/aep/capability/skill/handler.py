﻿"""Skills domain handler."""

from __future__ import annotations

import shutil
from pathlib import Path

from loguru import logger

from aep._util.dependency_mixin import DependencyOpsMixin
from aep.datamodels.config import EnvConfig
from aep.capability.indexing import IndexEntry, normalize_summary, render_catalog
from .parser import parse_frontmatter, read_properties
from .validator import validate


class SkillsHandler(DependencyOpsMixin):
    """Manage skills and skills index."""

    def __init__(self, config: EnvConfig):
        self.config = config

    def _validate_skill(self, skill_dir: Path) -> None:
        errors = validate(skill_dir)
        if errors:
            details = "\n".join(f"- {error}" for error in errors)
            raise ValueError(
                f"Skill `{skill_dir.name}` does not satisfy Agent Skills rules:\n{details}"
            )

    def _skill_name_from_single_md(self, source: Path) -> str:
        if source.suffix.lower() != ".md":
            raise ValueError("Single-file skill input only supports .md")

        content = source.read_text(encoding="utf-8")
        metadata, _ = parse_frontmatter(content)
        skill_name = metadata.get("name")
        if not isinstance(skill_name, str) or not skill_name.strip():
            raise ValueError("Single-file SKILL.md requires non-empty frontmatter name")
        return skill_name.strip()

    def add(
        self,
        source: str | Path,
        name: str | None = None,
        dependencies: list[str] | None = None,
    ) -> Path:
        source_path = Path(source).resolve()

        if source_path.is_file():
            parsed_name = self._skill_name_from_single_md(source_path)
            if name is not None and name != parsed_name:
                raise ValueError(
                    "Single-file skill name argument must match SKILL.md name: "
                    f"{name} != {parsed_name}"
                )
            target_name = parsed_name
            skill_dir = self.config.skill_dir(target_name)
            if skill_dir.exists():
                shutil.rmtree(skill_dir)
            skill_dir.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source_path, skill_dir / "SKILL.md")
            logger.warning(
                f"Detected single-file skill, wrote to skills/{target_name}/SKILL.md"
            )
        elif source_path.is_dir():
            target_name = name or source_path.name
            skill_dir = self.config.skill_dir(target_name)
            if skill_dir.exists():
                shutil.rmtree(skill_dir)
            shutil.copytree(source_path, skill_dir)
        else:
            raise FileNotFoundError(f"Skill source not found: {source_path}")

        try:
            self._validate_skill(skill_dir)
        except Exception:
            if skill_dir.exists():
                shutil.rmtree(skill_dir)
            raise

        logger.info(f"Add skill: {skill_dir.name} <- {source_path}")

        if dependencies:
            self.save_requirements(self.config.skill_requirements(skill_dir.name), dependencies)

        self.ensure_venv(self.config.skill_venv_dir(skill_dir.name))

        if dependencies:
            self.install_dependencies(
                self.config.skill_venv_dir(skill_dir.name),
                dependencies,
                skill_dir,
            )

        return skill_dir

    def sync_dependencies(self, name: str) -> None:
        skill_dir = self.config.skill_dir(name)
        if not skill_dir.exists():
            raise FileNotFoundError(f"Skill not found: {name}")

        self.ensure_venv(self.config.skill_venv_dir(name))
        self.install_from_requirements(
            self.config.skill_venv_dir(name),
            self.config.skill_requirements(name),
        )

    def list(self) -> list[str]:
        return sorted(
            [
                directory.name
                for directory in self.config.skills_dir.iterdir()
                if directory.is_dir() and not directory.name.startswith(".")
            ]
        )

    def remove(self, name: str) -> bool:
        skill_dir = self.config.skill_dir(name)
        if skill_dir.exists():
            shutil.rmtree(skill_dir)
            logger.info(f"Remove skill: {name}")
            return True
        return False

    def generate_index(self) -> None:
        entries: list[IndexEntry] = []
        for skill in self.list():
            skill_dir = self.config.skill_dir(skill)
            try:
                props = read_properties(skill_dir)
                display_name = props.name
                description = normalize_summary(props.description)
            except Exception as exc:
                logger.warning(f"Failed parsing skill for index {skill_dir}: {exc}")
                display_name = skill
                description = "Description unavailable."

            entries.append(
                IndexEntry(
                    name=display_name,
                    entry_type="skill",
                    description=description,
                    path=f"{skill_dir.name}/",
                )
            )

        content = render_catalog(
            title="Skills",
            entries=entries,
            empty_message="_no skills_",
            intro="Unified skill index (name/description/path).",
        )
        (self.config.skills_dir / "index.md").write_text(content, encoding="utf-8")
