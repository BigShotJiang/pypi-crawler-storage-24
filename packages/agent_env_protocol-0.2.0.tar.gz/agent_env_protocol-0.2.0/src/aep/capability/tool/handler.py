﻿"""Tools domain handler."""

from __future__ import annotations

import ast
from pathlib import Path

from loguru import logger

from aep._util.dependency_mixin import DependencyOpsMixin
from aep.datamodels.config import EnvConfig
from aep.capability.indexing import IndexEntry, normalize_summary, render_catalog


class ToolsHandler(DependencyOpsMixin):
    """Manage Python tools and tools index."""

    def __init__(self, config: EnvConfig):
        self.config = config

    def add(
        self,
        source: str | Path,
        name: str | None = None,
        dependencies: list[str] | None = None,
    ) -> Path:
        source_path = Path(source).resolve()
        if not source_path.exists():
            raise FileNotFoundError(f"Tool file not found: {source_path}")

        target_name = name or source_path.stem
        target = self.config.tool_path(target_name)

        content = self._read_text_with_fallback(source_path)
        target.write_text(content, encoding="utf-8")
        logger.info(f"Add tool: {target_name} <- {source_path}")

        if dependencies:
            self.save_requirements(self.config.tools_requirements, dependencies)

        self.ensure_venv(self.config.tools_venv_dir)

        if dependencies:
            self.install_dependencies(
                self.config.tools_venv_dir,
                dependencies,
                self.config.tools_dir,
            )

        return target

    def add_dependencies(self, *packages: str) -> Path:
        dependencies = list(packages)
        self.save_requirements(self.config.tools_requirements, dependencies)
        self.ensure_venv(self.config.tools_venv_dir)
        self.install_dependencies(
            self.config.tools_venv_dir,
            dependencies,
            self.config.tools_dir,
        )
        logger.info(f"Add tool dependencies: {packages}")
        return self.config.tools_requirements

    def sync_dependencies(self) -> None:
        self.ensure_venv(self.config.tools_venv_dir)
        self.install_from_requirements(
            self.config.tools_venv_dir,
            self.config.tools_requirements,
        )

    def list(self) -> list[str]:
        return sorted(
            [
                file.stem
                for file in self.config.tools_dir.glob("*.py")
                if not file.stem.startswith("_")
            ]
        )

    def remove(self, name: str) -> bool:
        tool_path = self.config.tool_path(name)
        if tool_path.exists():
            tool_path.unlink()
            logger.info(f"Remove tool: {name}")
            return True
        return False

    def generate_index(self) -> None:
        entries: list[IndexEntry] = []
        for tool in self.list():
            tool_path = self.config.tool_path(tool)
            description = self._extract_tool_description(tool_path)
            entry_type = "tool"

            mcp_config_dir = self.config.mcp_config_path(tool)
            if mcp_config_dir.is_dir() and (mcp_config_dir / "config.json").exists():
                entry_type = "tool.mcp"
                if description == "No description available.":
                    description = "MCP server tool stub."

            entries.append(
                IndexEntry(
                    name=tool,
                    entry_type=entry_type,
                    description=description,
                    path=f"{tool}.py",
                )
            )

        intro = "Unified tool index (name/description/path)."
        requirements_hint = self._shared_requirements_hint()
        if requirements_hint:
            intro = f"{intro}\n\n{requirements_hint}"

        content = render_catalog(
            title="Tools",
            entries=entries,
            empty_message="_no tools_",
            intro=intro,
        )
        (self.config.tools_dir / "index.md").write_text(content, encoding="utf-8")

    def _shared_requirements_hint(self) -> str:
        requirements_file = self.config.tools_requirements
        if not requirements_file.exists():
            return "Shared tools environment dependencies are declared in `requirements.txt`."

        lines = [
            line.strip()
            for line in requirements_file.read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.strip().startswith("#")
        ]
        if not lines:
            return "Shared tools environment dependencies are declared in `requirements.txt`."

        packages = ", ".join(lines)
        return (
            "Shared tools environment dependencies are declared in "
            f"`requirements.txt`: {packages}."
        )

    def _read_text_with_fallback(self, path: Path) -> str:
        try:
            return path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            return path.read_text(encoding="utf-8", errors="ignore")

    def _extract_tool_description(self, tool_path: Path) -> str:
        if not tool_path.exists():
            return "No description available."

        try:
            source = tool_path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            source = tool_path.read_text(encoding="utf-8", errors="ignore")

        try:
            module = ast.parse(source)
        except SyntaxError:
            return "Tool module (description unavailable due to syntax error)."

        docstring = ast.get_docstring(module)
        if not docstring:
            return "No description available."

        first_non_empty = ""
        for line in docstring.splitlines():
            candidate = line.strip()
            if candidate:
                first_non_empty = candidate
                break

        if not first_non_empty:
            return "No description available."

        return normalize_summary(first_non_empty)
