"""MCP tool stub generation helpers."""

from __future__ import annotations

import json
from pathlib import Path

from aep.datamodels.config import MCPServerConfig
from .transport import MCPTransport


def build_stdio_connect_code(config: MCPServerConfig) -> str:
    command = config.command[0] if config.command else ""
    args = json.dumps(config.command[1:] if config.command else [])
    env = json.dumps(config.env or {})

    return f'''
from contextlib import asynccontextmanager
from mcp import StdioServerParameters
from mcp.client.stdio import stdio_client

_SERVER_PARAMS = StdioServerParameters(
    command={json.dumps(command)},
    args={args},
    env={env} or None,
)


@asynccontextmanager
async def _connect():
    """Create STDIO connection."""
    async with stdio_client(_SERVER_PARAMS) as streams:
        yield streams
'''


def build_http_connect_code(config: MCPServerConfig) -> str:
    url = json.dumps(config.url or "")
    headers = json.dumps(config.headers or {})

    return f'''
from contextlib import asynccontextmanager
import httpx
from mcp.client.streamable_http import streamable_http_client

_MCP_URL = {url}
_MCP_HEADERS = {headers}


@asynccontextmanager
async def _connect():
    """Create streamable HTTP connection."""
    async with httpx.AsyncClient(headers=_MCP_HEADERS or None) as http_client:
        async with streamable_http_client(_MCP_URL, http_client=http_client) as (read, write, _):
            yield (read, write)
'''


def build_connect_code(transport: MCPTransport, config: MCPServerConfig) -> str:
    if transport == MCPTransport.STDIO:
        return build_stdio_connect_code(config)
    if transport == MCPTransport.HTTP:
        return build_http_connect_code(config)
    raise ValueError(f"Unsupported MCP transport: {transport.value}")


def build_tool_methods(tools_info: list[dict]) -> str:
    if not tools_info:
        return ""

    methods: list[str] = []
    for tool in tools_info:
        tool_name = tool["name"]
        description = tool.get("description", "")
        schema = tool.get("inputSchema", {})

        properties = schema.get("properties", {})
        required = schema.get("required", [])

        params: list[str] = []
        for prop_name, prop_info in properties.items():
            param_type = prop_info.get("type", "any")
            type_hint = {
                "string": "str",
                "integer": "int",
                "boolean": "bool",
                "number": "float",
                "object": "dict",
                "array": "list",
            }.get(param_type, "")

            if prop_name in required:
                params.append(f"{prop_name}: {type_hint}" if type_hint else prop_name)
            else:
                default = prop_info.get("default", "None")
                if isinstance(default, str) and default != "None":
                    default = f'"{default}"'
                if type_hint:
                    params.append(f"{prop_name}: {type_hint} = {default}")
                else:
                    params.append(f"{prop_name}={default}")

        docstring_lines: list[str] = [description] if description else []
        if properties:
            docstring_lines.append("")
            docstring_lines.append("Args:")
            for prop_name, prop_info in properties.items():
                prop_desc = prop_info.get("description", "")
                docstring_lines.append(f"    {prop_name}: {prop_desc}")
        docstring = "\n".join(docstring_lines)

        methods.append(
            f'''
def {tool_name}({", ".join(params)}):
    """
    {docstring}
    """
    return _call_mcp("{tool_name}", {{k: v for k, v in locals().items() if v is not None}})
'''
        )

    return "\n".join(methods)


def generate_stub(
    name: str,
    transport: MCPTransport,
    config: MCPServerConfig,
    tools_info: list[dict],
    target: Path,
) -> Path:
    connect_code = build_connect_code(transport, config)
    methods_code = build_tool_methods(tools_info)

    if tools_info:
        tools_doc = "\n".join(
            f"  - {tool['name']}: {tool.get('description', '')}" for tool in tools_info
        )
        docstring = (
            '"""\n'
            f"MCP Server ({transport.value}): {name}\n\n"
            f"Available tools:\n{tools_doc}\n"
            '"""'
        )
    else:
        docstring = (
            '"""\n'
            f"MCP Server ({transport.value}): {name}\n\n"
            "Use call(tool_name, **kwargs) to invoke tools.\n"
            '"""'
        )

    content = f'''{docstring}

import asyncio
from mcp import ClientSession

{connect_code}


def _call_mcp(tool_name: str, arguments: dict):
    """Call MCP tool by spawning a fresh connection."""
    return asyncio.run(_async_call_mcp(tool_name, arguments))


async def _async_call_mcp(tool_name: str, arguments: dict):
    async with _connect() as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            result = await session.call_tool(tool_name, arguments)

            texts = []
            for item in result.content:
                if hasattr(item, "text"):
                    texts.append(item.text)
                elif hasattr(item, "data"):
                    texts.append(str(item.data))

            return "\\n".join(texts) if texts else None


def call(tool_name: str, **kwargs):
    """Generic call entrypoint."""
    return _call_mcp(tool_name, {{k: v for k, v in kwargs.items() if v is not None}})

{methods_code}
'''

    target.write_text(content, encoding="utf-8")
    return target
