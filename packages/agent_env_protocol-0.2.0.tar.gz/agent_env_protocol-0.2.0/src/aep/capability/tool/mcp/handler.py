﻿"""MCP server management handler."""

from __future__ import annotations

import asyncio
import json
import shutil
from contextlib import asynccontextmanager
from pathlib import Path
from typing import Any, AsyncIterator, Coroutine, TypeVar

from loguru import logger

from aep.datamodels.config import EnvConfig, MCPServerConfig
from .stubgen import generate_stub
from .transport import MCPTransport

_T = TypeVar("_T")


class MCPHandler:
    """Manage MCP server configs and generate local tool stubs."""

    def __init__(self, config: EnvConfig):
        self.config = config

    def add(
        self,
        name: str,
        *,
        command: str | None = None,
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
        url: str | None = None,
        headers: dict[str, str] | None = None,
        transport: MCPTransport = MCPTransport.STDIO,
    ) -> Path:
        return self._run_sync(
            self.add_async(
                name,
                command=command,
                args=args,
                env=env,
                url=url,
                headers=headers,
                transport=transport,
            ),
            async_api="add_async",
        )

    async def add_async(
        self,
        name: str,
        *,
        command: str | None = None,
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
        url: str | None = None,
        headers: dict[str, str] | None = None,
        transport: MCPTransport = MCPTransport.STDIO,
    ) -> Path:
        self._validate_transport_args(transport, command=command, url=url)

        if transport == MCPTransport.STDIO and command:
            self._check_prerequisites(command)

        mcp_config = MCPServerConfig(
            name=name,
            transport=transport.value,
            command=[command, *(args or [])] if command else None,
            env=env or {},
            url=url,
            headers=headers or {},
            tools=[],
        )

        config_dir = self.config.mcp_config_path(name)
        config_dir.mkdir(parents=True, exist_ok=True)
        (config_dir / "config.json").write_text(
            json.dumps(mcp_config.to_dict(), indent=2, ensure_ascii=False),
            encoding="utf-8",
        )

        logger.info(f"Connecting MCP server: {name} ({transport.value})")
        try:
            discovered = await self._discover(name, transport, mcp_config)
        except Exception as exc:
            logger.error(f"MCP discovery failed: {exc}")
            raise RuntimeError(f"Cannot connect MCP server '{name}': {exc}") from exc

        tools_info = discovered.get("tools", [])
        stub_file = self._generate_stub(name, transport, mcp_config, tools_info)
        logger.info(f"MCP server added: {name} ({len(tools_info)} tools)")
        return stub_file

    def list(self) -> list[str]:
        if not self.config.mcp_config_dir.exists():
            return []
        return sorted(
            [
                item.name
                for item in self.config.mcp_config_dir.iterdir()
                if item.is_dir() and (item / "config.json").exists()
            ]
        )

    def get_config(self, name: str) -> MCPServerConfig | None:
        config_file = self.config.mcp_config_path(name) / "config.json"
        if not config_file.exists():
            return None
        return MCPServerConfig.from_dict(json.loads(config_file.read_text(encoding="utf-8")))

    def remove(self, name: str) -> bool:
        removed = False

        stub_file = self.config.tool_path(name)
        if stub_file.exists():
            stub_file.unlink()
            removed = True

        config_dir = self.config.mcp_config_path(name)
        if config_dir.exists():
            shutil.rmtree(config_dir)
            removed = True

        if removed:
            logger.info(f"Removed MCP server: {name}")
        return removed

    def refresh(self, name: str) -> Path:
        return self._run_sync(self.refresh_async(name), async_api="refresh_async")

    async def refresh_async(self, name: str) -> Path:
        config = self.get_config(name)
        if config is None:
            raise FileNotFoundError(f"MCP server not found: {name}")

        transport = MCPTransport(config.transport)
        discovered = await self._discover(name, transport, config)
        tools_info = discovered.get("tools", [])
        return self._generate_stub(name, transport, config, tools_info)

    def _run_sync(self, awaitable: Coroutine[Any, Any, _T], *, async_api: str) -> _T:
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(awaitable)

        awaitable.close()
        raise RuntimeError(
            "Cannot call sync MCP API inside a running event loop. "
            f"Use `await mcp.{async_api}(...)` instead."
        )

    async def _discover(
        self,
        name: str,
        transport: MCPTransport,
        config: MCPServerConfig,
    ) -> dict[str, list[dict]]:
        from mcp import ClientSession

        result: dict[str, list[dict]] = {"tools": []}
        async with self._connect(transport, config) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                result = await self._fetch_tools(session)
        return result

    @asynccontextmanager
    async def _connect(
        self,
        transport: MCPTransport,
        config: MCPServerConfig,
    ) -> AsyncIterator[tuple[Any, Any]]:
        if transport == MCPTransport.STDIO:
            from mcp import StdioServerParameters
            from mcp.client.stdio import stdio_client

            server_params = StdioServerParameters(
                command=config.command[0] if config.command else "",
                args=config.command[1:] if config.command and len(config.command) > 1 else [],
                env=config.env or None,
            )
            async with stdio_client(server_params) as streams:
                yield streams
            return

        if transport == MCPTransport.HTTP:
            import httpx
            from mcp.client.streamable_http import streamable_http_client

            async with httpx.AsyncClient(headers=config.headers or None) as http_client:
                async with streamable_http_client(
                    config.url or "",
                    http_client=http_client,
                ) as (read, write, _):
                    yield (read, write)
            return

        raise ValueError(f"Unsupported MCP transport: {transport.value}")

    async def _fetch_tools(self, session: Any) -> dict[str, list[dict]]:
        tools: list[dict] = []
        try:
            tools_result = await session.list_tools()
            for tool in tools_result.tools:
                tools.append(
                    {
                        "name": tool.name,
                        "description": tool.description or "",
                        "inputSchema": tool.inputSchema if hasattr(tool, "inputSchema") else {},
                    }
                )
        except Exception as exc:
            logger.warning(f"Failed listing MCP tools: {exc}")
        return {"tools": tools}

    def _check_prerequisites(self, command: str) -> None:
        if shutil.which(command):
            return

        hints = {
            "npx": "Install Node.js: https://nodejs.org/",
            "node": "Install Node.js: https://nodejs.org/",
            "uv": "Install uv: https://docs.astral.sh/uv/getting-started/installation/",
            "uvx": "Install uv: https://docs.astral.sh/uv/getting-started/installation/",
            "python": "Install Python: https://www.python.org/downloads/",
        }
        hint = hints.get(command, f"Ensure '{command}' is in PATH.")
        raise RuntimeError(f"Command not found: '{command}'. {hint}")

    def _generate_stub(
        self,
        name: str,
        transport: MCPTransport,
        config: MCPServerConfig,
        tools_info: list[dict],
    ) -> Path:
        return generate_stub(
            name=name,
            transport=transport,
            config=config,
            tools_info=tools_info,
            target=self.config.tool_path(name),
        )

    def _validate_transport_args(
        self,
        transport: MCPTransport,
        *,
        command: str | None,
        url: str | None,
    ) -> None:
        if transport == MCPTransport.STDIO and not command:
            raise ValueError("STDIO mode requires command")
        if transport == MCPTransport.HTTP and not url:
            raise ValueError("HTTP mode requires url")
        if transport not in (MCPTransport.STDIO, MCPTransport.HTTP):
            raise ValueError(f"Unsupported MCP transport: {transport}")
