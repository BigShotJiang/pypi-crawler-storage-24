"""MCP transport definitions."""

from enum import Enum


class MCPTransport(Enum):
    """Supported MCP transport types."""

    STDIO = "stdio"
    HTTP = "http"
