﻿"""Shared data models for index rendering."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(slots=True)
class IndexEntry:
    """Single index line item."""

    name: str
    description: str
    entry_type: str | None = None
    path: str | None = None
    metadata: dict[str, str] = field(default_factory=dict)
