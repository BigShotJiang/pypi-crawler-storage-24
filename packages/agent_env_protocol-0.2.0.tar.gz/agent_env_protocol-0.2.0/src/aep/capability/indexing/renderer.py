﻿"""Shared markdown renderer for index files."""

from __future__ import annotations

from .models import IndexEntry


def normalize_summary(text: str, max_chars: int = 180) -> str:
    """Normalize whitespace and bound summary length."""
    clean = " ".join(text.replace("|", "/").split())
    if not clean:
        return "N/A"

    if len(clean) > max_chars:
        return clean[: max_chars - 3].rstrip() + "..."
    return clean


def render_entry(entry: IndexEntry) -> str:
    """Render one bullet line for an index item."""
    parts: list[str] = [f"name: {entry.name}"]
    if entry.entry_type:
        parts.append(f"type: {entry.entry_type}")
    parts.append(f"description: {entry.description}")
    if entry.path:
        parts.append(f"path: {entry.path}")
    for key, value in entry.metadata.items():
        parts.append(f"{key}: {value}")

    return "- " + " | ".join(parts)


def render_catalog(
    *,
    title: str,
    entries: list[IndexEntry],
    empty_message: str,
    intro: str | None = None,
    footer: str | None = None,
) -> str:
    """Render a simple top-level index markdown document."""
    lines = [f"# {title}", ""]

    if intro:
        lines.append(intro)
        lines.append("")

    if entries:
        for entry in entries:
            lines.append(render_entry(entry))
    else:
        lines.append(empty_message)

    if footer:
        lines.append("")
        lines.append(footer)

    return "\n".join(lines).rstrip() + "\n"
