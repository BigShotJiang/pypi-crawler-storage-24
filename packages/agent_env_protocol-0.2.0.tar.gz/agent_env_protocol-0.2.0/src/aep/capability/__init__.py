﻿"""Capability domain packages."""
