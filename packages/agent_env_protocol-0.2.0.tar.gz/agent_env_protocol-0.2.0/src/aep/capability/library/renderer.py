"""Renderer helpers for recursive library indexes."""

from __future__ import annotations

from pathlib import Path
from typing import Callable

from aep.capability.indexing import IndexEntry, normalize_summary, render_entry


def describe_directory(
    child_dirs: list[Path],
    files: list[Path],
    *,
    max_summary_chars: int,
) -> str:
    dir_count = len(child_dirs)
    file_count = len(files)
    if dir_count == 0 and file_count == 0:
        return "Empty directory."

    parts: list[str] = []
    if dir_count:
        parts.append(f"{dir_count} {'subdirectory' if dir_count == 1 else 'subdirectories'}")
    if file_count:
        parts.append(f"{file_count} {'file' if file_count == 1 else 'files'}")
    return normalize_summary(
        f"Contains {' and '.join(parts)}.",
        max_chars=max_summary_chars,
    )


def describe_file(
    file_path: Path,
    read_text: Callable[[Path], str],
    *,
    max_summary_chars: int,
) -> str:
    content = read_text(file_path)
    if not content.strip():
        return "Empty file."

    lines = [line.strip() for line in content.splitlines() if line.strip()]
    if not lines:
        return "Empty file."

    first = lines[0].lstrip("#").strip() if lines[0].startswith("#") else lines[0]
    preview = f"{first} {lines[1]}" if len(lines) > 1 else first
    return normalize_summary(preview, max_chars=max_summary_chars)


def summarize_chunk(chunk_lines: list[str], *, max_summary_chars: int) -> str:
    non_empty = [line.strip() for line in chunk_lines if line.strip()]
    if not non_empty:
        return "Blank lines or separators."
    return normalize_summary(" ".join(non_empty[:2]), max_chars=max_summary_chars)


def chunk_file(
    file_path: Path,
    read_text: Callable[[Path], str],
    *,
    chunk_size_lines: int,
    max_summary_chars: int,
) -> list[tuple[int, int, str]]:
    content = read_text(file_path)
    lines = content.splitlines()
    if not lines:
        return []

    chunks: list[tuple[int, int, str]] = []
    for offset in range(0, len(lines), chunk_size_lines):
        chunk_lines = lines[offset : offset + chunk_size_lines]
        line_start = offset + 1
        line_end = offset + len(chunk_lines)
        chunks.append(
            (
                line_start,
                line_end,
                summarize_chunk(chunk_lines, max_summary_chars=max_summary_chars),
            )
        )
    return chunks


def render_directory_index(
    *,
    library_root: Path,
    directory: Path,
    relative_dir: Path,
    description: str,
    child_dirs: list[Path],
    files: list[Path],
    descriptions: dict[Path, str],
    index_file_name: str,
    read_text: Callable[[Path], str],
    chunk_size_lines: int,
    max_summary_chars: int,
) -> str:
    index_name = "library" if relative_dir == Path(".") else directory.name
    index_path = "library" if relative_dir == Path(".") else f"library/{relative_dir.as_posix()}"

    lines: list[str] = [
        "---",
        f"name: {index_name}",
        f"path: {index_path}",
        "type: dir",
        f"description: {description}",
        "---",
        "",
        "## Directories",
    ]

    if child_dirs:
        for child in child_dirs:
            child_rel = child.relative_to(library_root)
            child_desc = descriptions.get(child_rel, "Empty directory.")
            lines.append(
                render_entry(
                    IndexEntry(
                        name=child.name,
                        entry_type="dir",
                        description=child_desc,
                        metadata={"index_link": f"./{child.name}/{index_file_name}"},
                    )
                )
            )
    else:
        lines.append("- (none)")

    lines.append("")
    lines.append("## Files")
    if files:
        for file_path in files:
            file_desc = describe_file(
                file_path,
                read_text,
                max_summary_chars=max_summary_chars,
            )
            lines.append(
                render_entry(
                    IndexEntry(
                        name=file_path.name,
                        entry_type="file",
                        description=file_desc,
                        metadata={"file_link": f"./{file_path.name}"},
                    )
                )
            )

            chunks = chunk_file(
                file_path,
                read_text,
                chunk_size_lines=chunk_size_lines,
                max_summary_chars=max_summary_chars,
            )
            if chunks:
                for idx, (line_start, line_end, chunk_desc) in enumerate(chunks, start=1):
                    chunk_id = f"{file_path.stem}#c{idx:03d}"
                    lines.append(
                        f"  - chunk_id: {chunk_id} | range: lines {line_start}-{line_end} "
                        f"| description: {chunk_desc}"
                    )
            else:
                lines.append(
                    f"  - chunk_id: {file_path.stem}#c001 | range: lines 1-1 | "
                    "description: Empty file."
                )
            lines.append("")
    else:
        lines.append("- (none)")

    return "\n".join(lines).rstrip() + "\n"
