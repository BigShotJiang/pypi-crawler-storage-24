"""Library documents domain handler."""

from __future__ import annotations

import shutil
from pathlib import Path

from loguru import logger

from aep.datamodels.config import EnvConfig
from .renderer import describe_directory, render_directory_index


class LibraryHandler:
    """Manage library files and per-directory indexes."""

    INDEX_FILE_NAME = "index.md"
    CHUNK_SIZE_LINES = 80
    MAX_SUMMARY_CHARS = 50

    def __init__(self, config: EnvConfig):
        self.config = config

    def add(
        self,
        source: str | Path,
        name: str | None = None,
        target_dir: str | Path | None = None,
    ) -> Path:
        source_path = Path(source).resolve()
        if not source_path.exists():
            raise FileNotFoundError(f"Library file not found: {source_path}")
        if not source_path.is_file():
            raise ValueError(f"Library source must be a file: {source_path}")

        target_name = name or source_path.name
        target_parent = self._resolve_target_dir(target_dir)
        target_parent.mkdir(parents=True, exist_ok=True)

        target = target_parent / target_name
        shutil.copy2(source_path, target)

        logger.info(f"Add library file: {target.relative_to(self.config.library_dir)}")
        return target

    def list(self) -> list[str]:
        files: list[str] = []
        for file in self.config.library_dir.rglob("*"):
            if not file.is_file():
                continue
            if file.name == self.INDEX_FILE_NAME:
                continue
            files.append(file.relative_to(self.config.library_dir).as_posix())
        return sorted(files)

    def remove(self, name: str) -> bool:
        target = self._resolve_relative_path(name)
        if target.name == self.INDEX_FILE_NAME:
            return False

        if target.exists() and target.is_file():
            target.unlink()
            self._cleanup_empty_directories(target.parent)
            logger.info(f"Remove library file: {name}")
            return True
        return False

    def generate_index(
        self,
        *,
        chunk_size_lines: int | None = None,
        max_summary_chars: int | None = None,
    ) -> None:
        chunk_size = (
            self.CHUNK_SIZE_LINES if chunk_size_lines is None else chunk_size_lines
        )
        summary_chars = (
            self.MAX_SUMMARY_CHARS if max_summary_chars is None else max_summary_chars
        )
        if chunk_size <= 0:
            raise ValueError("chunk_size_lines must be > 0")
        if summary_chars <= 0:
            raise ValueError("max_summary_chars must be > 0")

        root = self.config.library_dir
        directories = [root, *[path for path in root.rglob("*") if path.is_dir()]]
        directories.sort(
            key=lambda path: len(path.relative_to(root).parts),
            reverse=True,
        )

        descriptions: dict[Path, str] = {}
        for directory in directories:
            relative_dir = Path(".") if directory == root else directory.relative_to(root)
            child_dirs = sorted(
                [
                    entry
                    for entry in directory.iterdir()
                    if entry.is_dir() and not entry.name.startswith(".")
                ],
                key=lambda item: item.name.lower(),
            )
            files = sorted(
                [
                    entry
                    for entry in directory.iterdir()
                    if entry.is_file() and entry.name != self.INDEX_FILE_NAME
                ],
                key=lambda item: item.name.lower(),
            )

            description = describe_directory(
                child_dirs,
                files,
                max_summary_chars=summary_chars,
            )
            descriptions[relative_dir] = description

            content = render_directory_index(
                library_root=root,
                directory=directory,
                relative_dir=relative_dir,
                description=description,
                child_dirs=child_dirs,
                files=files,
                descriptions=descriptions,
                index_file_name=self.INDEX_FILE_NAME,
                read_text=self._read_text,
                chunk_size_lines=chunk_size,
                max_summary_chars=summary_chars,
            )
            (directory / self.INDEX_FILE_NAME).write_text(content, encoding="utf-8")

    def _resolve_target_dir(self, target_dir: str | Path | None) -> Path:
        if target_dir is None:
            return self.config.library_dir
        return self.config.library_dir / self._normalize_relative_path(target_dir)

    def _resolve_relative_path(self, value: str | Path) -> Path:
        return self.config.library_dir / self._normalize_relative_path(value)

    def _normalize_relative_path(self, value: str | Path) -> Path:
        path = Path(value)
        if path.is_absolute():
            raise ValueError(f"Path must be relative to library/: {value}")

        normalized = Path()
        for part in path.parts:
            if part in ("", "."):
                continue
            if part == "..":
                raise ValueError(f"Path cannot include '..': {value}")
            normalized = normalized / part
        return normalized

    def _cleanup_empty_directories(self, start: Path) -> None:
        root = self.config.library_dir
        current = start
        while current != root and current.exists():
            if any(current.iterdir()):
                break
            current.rmdir()
            current = current.parent

    def _read_text(self, file_path: Path) -> str:
        try:
            return file_path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            return file_path.read_text(encoding="utf-8", errors="ignore")
