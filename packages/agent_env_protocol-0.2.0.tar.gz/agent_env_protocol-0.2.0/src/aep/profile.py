"""Profile resource manager for AEP capabilities."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from loguru import logger

from .datamodels.config import EnvConfig
from .capability.library.handler import LibraryHandler
from .capability.skill.handler import SkillsHandler
from .capability.tool.handler import ToolsHandler
from .capability.tool.mcp.handler import MCPHandler


class Profile:
    """Manage one AEP capability configuration directory."""

    DEFAULT_TOOL_DEPENDENCIES = (
        "numpy",
        "pandas",
        "matplotlib",
        "mcp",
    )

    def __init__(
        self,
        config_dir: str | Path,
        *,
        auto_init_tool_env: bool = False,
        include_default_tool_dependencies: bool = True,
        tool_dependencies: list[str] | None = None,
    ) -> None:
        self.config = EnvConfig(config_dir)

        self._tools = ToolsHandler(self.config)
        self._skills = SkillsHandler(self.config)
        self._library = LibraryHandler(self.config)
        self._mcp = MCPHandler(self.config)

        self._init_dirs()

        if auto_init_tool_env:
            self.init_tool_environment(
                dependencies=tool_dependencies,
                include_default=include_default_tool_dependencies,
            )

        logger.info(f"Profile initialized: {self.config.config_dir}")

    def _init_dirs(self) -> None:
        self.config.config_dir.mkdir(parents=True, exist_ok=True)
        self.config.tools_dir.mkdir(exist_ok=True)
        self.config.skills_dir.mkdir(exist_ok=True)
        self.config.library_dir.mkdir(exist_ok=True)
        self.config.mcp_config_dir.mkdir(exist_ok=True)

    @property
    def tools(self) -> ToolsHandler:
        return self._tools

    @property
    def skills(self) -> SkillsHandler:
        return self._skills

    @property
    def library(self) -> LibraryHandler:
        return self._library

    @property
    def mcp(self) -> MCPHandler:
        return self._mcp

    def add_tool(
        self,
        source: str | Path,
        name: str | None = None,
        dependencies: list[str] | None = None,
    ) -> Path:
        return self._tools.add(source, name, dependencies)

    def add_skill(
        self,
        source: str | Path,
        name: str | None = None,
        dependencies: list[str] | None = None,
    ) -> Path:
        return self._skills.add(source, name, dependencies)

    def add_library(
        self,
        source: str | Path,
        name: str | None = None,
        target_dir: str | Path | None = None,
    ) -> Path:
        return self._library.add(source, name, target_dir)

    def add_mcp_server(self, name: str, **kwargs: Any) -> Path:
        return self._mcp.add(name, **kwargs)

    def add_tool_dependency(self, *packages: str) -> Path:
        return self._tools.add_dependencies(*packages)

    def init_tool_environment(
        self,
        *,
        dependencies: list[str] | None = None,
        include_default: bool = True,
    ) -> Path:
        deps: list[str] = []
        if include_default:
            deps.extend(self.DEFAULT_TOOL_DEPENDENCIES)
        if dependencies:
            deps.extend(dependencies)

        unique = list(dict.fromkeys(dep for dep in deps if dep and dep.strip()))
        if unique:
            logger.info(f"Initialize tools dependencies: {unique}")
            return self._tools.add_dependencies(*unique)

        self._tools.ensure_venv(self.config.tools_venv_dir)
        return self.config.tools_requirements

    def index(
        self,
        *,
        library_chunk_size_lines: int | None = None,
        library_max_summary_chars: int | None = None,
    ) -> None:
        self._tools.generate_index()
        self._skills.generate_index()
        self._library.generate_index(
            chunk_size_lines=library_chunk_size_lines,
            max_summary_chars=library_max_summary_chars,
        )
        logger.info("Index generation completed")

    @property
    def config_dir(self) -> Path:
        return self.config.config_dir

    @property
    def tools_dir(self) -> Path:
        return self.config.tools_dir

    @property
    def skills_dir(self) -> Path:
        return self.config.skills_dir

    @property
    def library_dir(self) -> Path:
        return self.config.library_dir

    def __repr__(self) -> str:
        return f"Profile({self.config.config_dir})"
