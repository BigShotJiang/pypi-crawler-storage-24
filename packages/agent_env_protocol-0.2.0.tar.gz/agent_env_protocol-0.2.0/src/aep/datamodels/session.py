"""Session-related data structures."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(slots=True)
class ExecResult:
    """Command execution result."""

    stdout: str = ""
    stderr: str = ""
    return_code: int = 0
