"""Data structures shared across AEP domains."""

from .config import EnvConfig, MCPServerConfig
from .session import ExecResult

__all__ = [
    "EnvConfig",
    "MCPServerConfig",
    "ExecResult",
]
