"""Configuration data structures."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class MCPServerConfig:
    name: str
    transport: str
    command: list[str] | None = None
    env: dict[str, str] = field(default_factory=dict)
    url: str | None = None
    headers: dict[str, str] = field(default_factory=dict)
    tools: list[dict] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "transport": self.transport,
            "command": self.command,
            "env": self.env,
            "url": self.url,
            "headers": self.headers,
            "tools": self.tools,
        }

    @classmethod
    def from_dict(cls, data: dict) -> "MCPServerConfig":
        return cls(
            name=data["name"],
            transport=data["transport"],
            command=data.get("command"),
            env=data.get("env", {}),
            url=data.get("url"),
            headers=data.get("headers", {}),
            tools=data.get("tools", []),
        )


@dataclass
class EnvConfig:
    """Directory and path conventions for one capability environment."""

    config_dir: Path

    def __post_init__(self) -> None:
        self.config_dir = Path(self.config_dir).resolve()

    @property
    def tools_dir(self) -> Path:
        return self.config_dir / "tools"

    @property
    def tools_venv_dir(self) -> Path:
        return self.tools_dir / ".venv"

    @property
    def tools_requirements(self) -> Path:
        return self.tools_dir / "requirements.txt"

    @property
    def skills_dir(self) -> Path:
        return self.config_dir / "skills"

    @property
    def library_dir(self) -> Path:
        return self.config_dir / "library"

    @property
    def mcp_config_dir(self) -> Path:
        return self.config_dir / "_mcp"

    def skill_dir(self, name: str) -> Path:
        return self.skills_dir / name

    def skill_venv_dir(self, name: str) -> Path:
        return self.skill_dir(name) / ".venv"

    def skill_requirements(self, name: str) -> Path:
        return self.skill_dir(name) / "requirements.txt"

    def tool_path(self, name: str) -> Path:
        return self.tools_dir / f"{name}.py"

    def mcp_config_path(self, name: str) -> Path:
        return self.mcp_config_dir / name

    def __repr__(self) -> str:
        return f"EnvConfig({self.config_dir})"
