"""Shared dependency/venv helper mixin for domain handlers."""

from __future__ import annotations

from pathlib import Path

from .venv import ensure_venv, install_deps, install_from_requirements, save_requirements


class DependencyOpsMixin:
    """Provide shared dependency-management methods for handlers."""

    def ensure_venv(self, venv_dir: Path) -> None:
        ensure_venv(venv_dir)

    def install_dependencies(
        self,
        venv_dir: Path,
        dependencies: list[str],
        work_dir: Path | None = None,
    ) -> None:
        install_deps(venv_dir, dependencies, work_dir)

    def install_from_requirements(self, venv_dir: Path, requirements_file: Path) -> None:
        install_from_requirements(venv_dir, requirements_file)

    def save_requirements(self, requirements_file: Path, dependencies: list[str]) -> None:
        save_requirements(requirements_file, dependencies)
