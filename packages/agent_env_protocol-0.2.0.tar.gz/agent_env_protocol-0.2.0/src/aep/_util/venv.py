"""Virtual environment utilities shared by handlers and executors."""

from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

from loguru import logger


def _find_uv() -> str:
    """Return uv executable name/path."""
    if shutil.which("uv"):
        return "uv"
    return "uv"


def _get_python(venv_dir: Path) -> Path:
    """Return Python executable inside a venv."""
    win_python = venv_dir / "Scripts" / "python.exe"
    if win_python.exists():
        return win_python

    unix_python = venv_dir / "bin" / "python"
    if unix_python.exists():
        return unix_python

    raise RuntimeError(f"Venv python not found: {venv_dir}")


def ensure_venv(venv_dir: Path) -> None:
    """Create venv with uv when absent."""
    if venv_dir.exists():
        return

    logger.info(f"Create venv: {venv_dir}")
    try:
        subprocess.run(
            [_find_uv(), "venv", str(venv_dir)],
            cwd=str(venv_dir.parent),
            check=True,
            capture_output=True,
        )
    except FileNotFoundError as exc:
        raise RuntimeError(
            "uv is not installed. Install via `pip install uv` or "
            "https://docs.astral.sh/uv/getting-started/installation/"
        ) from exc


def install_deps(
    venv_dir: Path,
    dependencies: list[str],
    work_dir: Path | None = None,
) -> None:
    """Install dependencies into a venv using uv pip."""
    if not dependencies:
        return

    if work_dir is None:
        work_dir = venv_dir.parent

    logger.info(f"Install dependencies: {dependencies}")
    try:
        subprocess.run(
            [_find_uv(), "pip", "install", *dependencies],
            cwd=str(work_dir),
            env={**os.environ, "VIRTUAL_ENV": str(venv_dir)},
            check=True,
            capture_output=True,
        )
    except subprocess.CalledProcessError as exc:
        stderr = exc.stderr.decode(errors="ignore") if exc.stderr else str(exc)
        logger.error(f"Dependency install failed: {stderr}")
        raise RuntimeError(f"Dependency install failed: {exc}") from exc


def install_from_requirements(venv_dir: Path, requirements_file: Path) -> None:
    """Install dependencies from requirements.txt into a venv."""
    if not requirements_file.exists():
        return

    logger.info(f"Install from requirements: {requirements_file}")
    try:
        subprocess.run(
            [_find_uv(), "pip", "install", "-r", str(requirements_file)],
            cwd=str(requirements_file.parent),
            env={**os.environ, "VIRTUAL_ENV": str(venv_dir)},
            check=True,
            capture_output=True,
        )
    except subprocess.CalledProcessError as exc:
        stderr = exc.stderr.decode(errors="ignore") if exc.stderr else str(exc)
        logger.error(f"Dependency install failed: {stderr}")
        raise RuntimeError(f"Dependency install failed: {exc}") from exc


def save_requirements(requirements_file: Path, dependencies: list[str]) -> None:
    """Merge dependencies into requirements.txt."""
    if not dependencies:
        return

    existing: set[str] = set()
    if requirements_file.exists():
        existing = {
            line.strip()
            for line in requirements_file.read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.lstrip().startswith("#")
        }

    existing.update(dep for dep in dependencies if dep and dep.strip())
    requirements_file.write_text("\n".join(sorted(existing)) + "\n", encoding="utf-8")
    logger.info(f"Saved requirements: {requirements_file}")
