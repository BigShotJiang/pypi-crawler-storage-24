"""Centralized agent-facing context and tool schema definitions."""

from __future__ import annotations

from copy import deepcopy


_TOOL_SCHEMA_DEFINITIONS: list[dict[str, object]] = [
    {
        "name": "aep_exec",
        "summary": (
            "Execute one command in the current bound terminal session, including shell, "
            "`tools run`, and `skills run`."
        ),
        "schema": {
            "type": "function",
            "function": {
                "name": "aep_exec",
                "description": (
                    "Execute one command in the current bound AEP terminal session. "
                    "Use this for normal shell commands and for `tools run` / `skills run`."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "command": {
                            "type": "string",
                            "description": (
                                "Command to execute in the current bound terminal session, for "
                                "example `pwd`, `tools list`, "
                                "`tools run \"tools.calc.add(1, 2)\"`, "
                                "`tools run PY<<\\nprint(tools.calc.add(1, 2))\\nPY`, or "
                                "`skills run report-skill/scripts/report.py --help`."
                            ),
                        },
                        "timeout_ms": {
                            "type": "integer",
                            "minimum": 0,
                            "description": (
                                "Short wait timeout. If execution is still running, the response "
                                "returns output chunks and a cursor for follow-up polling."
                            ),
                        },
                        "output_limit": {
                            "type": "integer",
                            "minimum": 1,
                            "description": "Maximum number of output chunks to fetch in this call.",
                        },
                    },
                    "required": ["command"],
                    "additionalProperties": False,
                },
            },
        },
    },
    {
        "name": "aep_output",
        "summary": "Read incremental output for one execution in the current bound session.",
        "schema": {
            "type": "function",
            "function": {
                "name": "aep_output",
                "description": "Read incremental output for one execution in the current bound session.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "exec_id": {
                            "type": "string",
                            "description": "Execution ID returned by `aep_exec`.",
                        },
                        "cursor": {
                            "type": "integer",
                            "minimum": 0,
                            "description": "Chunk cursor to continue from.",
                        },
                        "limit": {
                            "type": "integer",
                            "minimum": 1,
                            "description": "Maximum number of output chunks to fetch.",
                        },
                    },
                    "required": ["exec_id"],
                    "additionalProperties": False,
                },
            },
        },
    },
    {
        "name": "aep_kill",
        "summary": "Kill a queued or running execution in the current bound session.",
        "schema": {
            "type": "function",
            "function": {
                "name": "aep_kill",
                "description": (
                    "Kill a queued or running execution in the current bound session and "
                    "return output."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "exec_id": {
                            "type": "string",
                            "description": "Execution ID returned by `aep_exec`.",
                        },
                        "cursor": {
                            "type": "integer",
                            "minimum": 0,
                            "description": "Chunk cursor to continue from after kill.",
                        },
                        "limit": {
                            "type": "integer",
                            "minimum": 1,
                            "description": "Maximum number of output chunks to fetch.",
                        },
                    },
                    "required": ["exec_id"],
                    "additionalProperties": False,
                },
            },
        },
    },
    {
        "name": "aep_history",
        "summary": "Inspect command history and status for the current bound session.",
        "schema": {
            "type": "function",
            "function": {
                "name": "aep_history",
                "description": "Read recent execution history records from the current bound session.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "limit": {
                            "type": "integer",
                            "minimum": 1,
                            "description": "Maximum number of recent records to return.",
                        },
                        "include_output": {
                            "type": "boolean",
                            "description": "Whether to include stdout and stderr previews.",
                        },
                        "output_preview_chars": {
                            "type": "integer",
                            "minimum": 0,
                            "description": "Maximum preview length per stdout/stderr field.",
                        },
                    },
                    "additionalProperties": False,
                },
            },
        },
    },
    {
        "name": "aep_env",
        "summary": "Read custom environment variables from the current bound session.",
        "schema": {
            "type": "function",
            "function": {
                "name": "aep_env",
                "description": "Read current custom environment variables from the current bound session.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "keys": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": (
                                "Optional environment variable names to fetch. If omitted, all "
                                "custom session variables are returned."
                            ),
                        },
                    },
                    "additionalProperties": False,
                },
            },
        },
    },
]


def build_tool_schemas() -> list[dict[str, object]]:
    """Return tool schemas for the current bound session."""
    schemas: list[dict[str, object]] = []
    for definition in _TOOL_SCHEMA_DEFINITIONS:
        schemas.append(deepcopy(definition["schema"]))
    return schemas


def build_context(
    *,
    agent_dir_name: str,
    workspace_dir: str,
    sections: dict[str, str],
) -> str:
    """Render the agent context shown to the model."""
    lines = [
        "# AEP Agent Context",
        "",
        "## Workspace Layout",
        "",
        (
            "This is a terminal environment built for an agent."
        ),
        (
            f"The workspace root is `{workspace_dir}`."
        ),
        (
            "AEP mounts capability directories into the workspace at "
            f"`{agent_dir_name}/tools`, `{agent_dir_name}/skills`, and "
            f"`{agent_dir_name}/library`."
        ),
        (
            "In other words, the agent can inspect capability files at "
            f"`{workspace_dir}/{agent_dir_name}/tools`, "
            f"`{workspace_dir}/{agent_dir_name}/skills`, and "
            f"`{workspace_dir}/{agent_dir_name}/library`."
        ),
        (
            f"`{agent_dir_name}/tools` contains Python tools, "
            f"`{agent_dir_name}/skills` contains skills, and "
            f"`{agent_dir_name}/library` contains reference docs and indexes."
        ),
        "",
        "## Exposed Tool Schemas",
        "",
    ]

    for definition in _TOOL_SCHEMA_DEFINITIONS:
        lines.append(f"- `{definition['name']}`: {definition['summary']}")

    lines.extend(
        [
            "",
            "Each schema operates on the current bound session. Different sessions keep "
            "separate command history, custom env, and cwd.",
            "",
            "## Special Commands",
            "",
            (
                "`tools run` starts the shared Python tools environment. Registered "
                "tool modules are mounted under the `tools.<name>` namespace."
            ),
            (
                "Single-line example: `tools run \"tools.calc.add(1, 2)\"`. You may also "
                "import packages installed in the tools environment in the same script."
            ),
            "Multiline example:",
            "```text",
            "tools run PY<<",
            "import pandas as pd",
            "df = tools.dataframe_tool.sample_sales()",
            "print(df.shape)",
            "PY",
            "```",
            (
                "`skills run <skill-name>/scripts/<script>.py [args]` executes a script "
                "inside that skill's own virtual environment."
            ),
            (
                "Use `tools list` / `tools info <name>` and `skills list` / "
                "`skills info <name>` to inspect available capabilities."
            ),
            "",
            "## Index",
            "",
            "The sections below are the generated indexes for the current profile.",
        ]
    )

    ordered_sections = [
        sections[name]
        for name in ("tools", "skills", "library")
        if name in sections
    ]
    if ordered_sections:
        lines.extend(["", *ordered_sections])
    else:
        lines.extend(["", "_no indexes generated yet; run `Profile.index()` first._"])

    return "\n".join(lines)
