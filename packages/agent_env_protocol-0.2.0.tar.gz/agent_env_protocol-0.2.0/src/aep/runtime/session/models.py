"""Session data models for async execution lifecycle."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any


class ExecutionStatus(StrEnum):
    """Execution lifecycle status."""

    QUEUED = "queued"
    RUNNING = "running"
    EXITED = "exited"
    FAILED = "failed"
    KILLED = "killed"


@dataclass(slots=True)
class RunResponse:
    """Response shape for session.run()."""

    exec_id: str
    status: ExecutionStatus
    queue_pos: int
    started_at: str | None = None


@dataclass(slots=True)
class OutputChunk:
    """Incremental output chunk for session.output()."""

    cursor: int
    stream: str
    content: str
    created_at: str


@dataclass(slots=True)
class OutputResponse:
    """Response shape for session.output()."""

    chunks: list[OutputChunk]
    next_cursor: int
    is_running: bool
    exit_code: int | None = None


@dataclass(slots=True)
class WaitResponse:
    """Response shape for session.wait()."""

    status: ExecutionStatus
    exit_code: int | None
    finished_at: str | None = None


@dataclass(slots=True)
class KillResponse:
    """Response shape for session.kill()."""

    status_before: ExecutionStatus
    status_after: ExecutionStatus


@dataclass(slots=True)
class ExecutionFact:
    """Execution fact record stored in session history."""

    aep_session_id: str
    exec_id: str
    created_at: str
    started_at: str | None
    finished_at: str | None
    raw_command: str
    executor_kind: str
    cwd_before: str
    cwd_after: str | None
    env_delta: dict[str, str] = field(default_factory=dict)
    status: ExecutionStatus = ExecutionStatus.QUEUED
    exit_code: int | None = None
    stdout: str = ""
    stderr: str = ""
    # Reserved extension slot; currently not populated/consumed in runtime paths.
    extra: dict[str, Any] = field(default_factory=dict)
