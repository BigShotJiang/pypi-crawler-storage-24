"""Session runtime primitives."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import datetime, timezone

from aep.datamodels.session import ExecResult

from .models import ExecutionStatus, OutputChunk


@dataclass(slots=True)
class OutputBufferConfig:
    """Output buffer limits to avoid unbounded memory usage."""

    max_chunks: int = 2_000
    max_chars: int = 1_000_000


class OutputBuffer:
    """In-memory chunk buffer with cursor semantics."""

    def __init__(self, config: OutputBufferConfig | None = None) -> None:
        self.config = config or OutputBufferConfig()
        self._chunks: list[OutputChunk] = []
        self._chars = 0

    @property
    def size(self) -> int:
        return len(self._chunks)

    def append(self, chunk: OutputChunk) -> bool:
        if self.size >= self.config.max_chunks:
            return False
        if self._chars >= self.config.max_chars:
            return False
        self._chunks.append(chunk)
        self._chars += len(chunk.content)
        return True

    def read(self, cursor: int, limit: int = 200) -> tuple[list[OutputChunk], int]:
        if cursor < 0:
            cursor = 0
        if limit <= 0:
            return ([], cursor)
        end = min(cursor + limit, self.size)
        return (self._chunks[cursor:end], end)


def now_iso() -> str:
    """Return current UTC timestamp in ISO-8601 format."""

    return datetime.now(timezone.utc).isoformat()


def is_terminal(status: ExecutionStatus) -> bool:
    """Whether status is a terminal state."""

    return status in (
        ExecutionStatus.EXITED,
        ExecutionStatus.FAILED,
        ExecutionStatus.KILLED,
    )


class ExecutionState:
    """Runtime state of one queued/running execution."""

    def __init__(
        self,
        *,
        session_id: str,
        exec_id: str,
        raw_command: str,
        cwd_before: str,
        env_before: dict[str, str],
        max_output_chunks: int,
        max_output_chars: int,
        max_history_chars: int,
    ) -> None:
        self.session_id = session_id
        self.exec_id = exec_id
        self.raw_command = raw_command
        self.executor_kind = "shell"
        self.cwd_before = cwd_before
        self.cwd_after: str | None = None
        self.env_before = env_before
        self.env_after: dict[str, str] = env_before.copy()

        self.created_at = now_iso()
        self.started_at: str | None = None
        self.finished_at: str | None = None
        self.status = ExecutionStatus.QUEUED
        self.exit_code: int | None = None

        self.process: asyncio.subprocess.Process | None = None
        self.kill_requested = False

        self._output = OutputBuffer(
            OutputBufferConfig(max_chunks=max_output_chunks, max_chars=max_output_chars)
        )
        self._next_cursor = 0
        self._output_truncated = False
        self._finished = asyncio.Event()
        self._lock = asyncio.Lock()

        self._max_history_chars = max_history_chars
        self._stdout = ""
        self._stderr = ""
        self._stdout_truncated = False
        self._stderr_truncated = False

    def is_running(self) -> bool:
        return self.status == ExecutionStatus.RUNNING

    def is_terminal(self) -> bool:
        return is_terminal(self.status)

    def mark_running(self) -> None:
        if self.status != ExecutionStatus.QUEUED:
            return
        self.status = ExecutionStatus.RUNNING
        self.started_at = now_iso()

    def finalize(self, status: ExecutionStatus, exit_code: int | None) -> None:
        if self.is_terminal():
            return
        self.status = status
        self.exit_code = exit_code
        self.finished_at = now_iso()
        self._finished.set()

    async def append_output(self, stream: str, content: str) -> None:
        if not content:
            return
        async with self._lock:
            chunk = OutputChunk(
                cursor=self._next_cursor,
                stream=stream,
                content=content,
                created_at=now_iso(),
            )
            added = self._output.append(chunk)
            if added:
                self._next_cursor += 1
            elif not self._output_truncated:
                marker = OutputChunk(
                    cursor=self._next_cursor,
                    stream="stderr",
                    content="\n[output truncated]\n",
                    created_at=now_iso(),
                )
                marker_added = self._output.append(marker)
                if marker_added:
                    self._next_cursor += 1
                self._output_truncated = True

            self._append_history(stream, content)

    async def read_output(
        self, cursor: int, limit: int
    ) -> tuple[list[OutputChunk], int]:
        async with self._lock:
            return self._output.read(cursor, limit)

    async def wait_finished(self, timeout_ms: int | None = None) -> bool:
        if timeout_ms is None:
            await self._finished.wait()
            return True
        try:
            await asyncio.wait_for(self._finished.wait(), timeout_ms / 1000)
            return True
        except TimeoutError:
            return False

    def history_stdout(self) -> str:
        if self._stdout_truncated:
            return f"{self._stdout}\n...[truncated]"
        return self._stdout

    def history_stderr(self) -> str:
        if self._stderr_truncated:
            return f"{self._stderr}\n...[truncated]"
        return self._stderr

    def _append_history(self, stream: str, content: str) -> None:
        if stream == "stdout":
            self._stdout, self._stdout_truncated = _append_with_limit(
                self._stdout,
                content,
                self._max_history_chars,
                self._stdout_truncated,
            )
            return
        self._stderr, self._stderr_truncated = _append_with_limit(
            self._stderr,
            content,
            self._max_history_chars,
            self._stderr_truncated,
        )


async def finalize_from_exec_result(state: ExecutionState, result: ExecResult) -> None:
    """Append ExecResult output into state and finalize status/exit code."""
    if result.stdout:
        await state.append_output("stdout", result.stdout)
    if result.stderr:
        await state.append_output("stderr", result.stderr)

    status = ExecutionStatus.EXITED
    if result.return_code != 0:
        status = ExecutionStatus.FAILED
    state.finalize(status, result.return_code)


def _append_with_limit(
    current: str,
    incoming: str,
    max_chars: int,
    truncated: bool,
) -> tuple[str, bool]:
    if truncated:
        return (current, True)
    if len(current) >= max_chars:
        return (current, True)
    available = max_chars - len(current)
    if len(incoming) > available:
        return (f"{current}{incoming[:available]}", True)
    return (f"{current}{incoming}", False)
