"""Session execution history storage."""

from __future__ import annotations

from .models import ExecutionFact
from .execution_state import ExecutionState


class SessionHistory:
    """In-memory execution facts for one session."""

    def __init__(self) -> None:
        self._records: dict[str, ExecutionFact] = {}

    def put(self, fact: ExecutionFact) -> None:
        self._records[fact.exec_id] = fact

    def get(self, exec_id: str) -> ExecutionFact | None:
        return self._records.get(exec_id)

    def list_all(self) -> list[ExecutionFact]:
        return list(self._records.values())

    def upsert_from_state(self, state: ExecutionState) -> ExecutionFact:
        env_delta = _env_delta(state.env_before, state.env_after)
        # `ExecutionFact.extra` is intentionally left as default `{}` for now.
        fact = ExecutionFact(
            aep_session_id=state.session_id,
            exec_id=state.exec_id,
            created_at=state.created_at,
            started_at=state.started_at,
            finished_at=state.finished_at,
            raw_command=state.raw_command,
            executor_kind=state.executor_kind,
            cwd_before=state.cwd_before,
            cwd_after=state.cwd_after,
            env_delta=env_delta,
            status=state.status,
            exit_code=state.exit_code,
            stdout=state.history_stdout(),
            stderr=state.history_stderr(),
        )
        self.put(fact)
        return fact


def _env_delta(before: dict[str, str], after: dict[str, str]) -> dict[str, str]:
    delta: dict[str, str] = {}

    for key, value in after.items():
        if before.get(key) != value:
            delta[key] = value

    for key in before:
        if key not in after:
            delta[key] = "<deleted>"

    return delta
