﻿"""Command entrypoint and dispatch orchestration for AEPSession."""

from __future__ import annotations

import os
import shlex
from typing import TYPE_CHECKING, Awaitable, Callable

from .builtins import handle_cd, handle_export
from .capability_commands import CapabilityCommands
from .models import ExecutionStatus
from .execution_state import ExecutionState, finalize_from_exec_result
from .subprocess_runner import run_subprocess_exec, run_subprocess_shell

if TYPE_CHECKING:
    from aep.profile import Profile
    from .manager import AEPSession


CommandHandler = Callable[
    ["AEPSession", ExecutionState, list[str], str | None],
    Awaitable[None],
]


class CommandExecutor:
    """Single command entrypoint for tools/skills/shell dispatch."""

    def __init__(self, config: "Profile") -> None:
        self._capability_commands = CapabilityCommands(config)
        self._command_handlers: dict[str, CommandHandler] = {}
        self.register_handler("tools", self._handle_tools)
        self.register_handler("skills", self._handle_skills)
        self.register_handler("cd", self._handle_cd)
        self.register_handler("export", self._handle_export)

    def register_handler(self, command: str, handler: CommandHandler) -> None:
        """Register or override a command handler in the dispatch registry."""
        normalized = command.strip()
        if not normalized:
            raise ValueError("command must be non-empty")
        self._command_handlers[normalized] = handler

    async def execute(self, session: "AEPSession", state: ExecutionState) -> None:
        if state.kill_requested:
            state.finalize(ExecutionStatus.KILLED, None)
            return

        command = state.raw_command.strip()
        if not command:
            state.finalize(ExecutionStatus.EXITED, 0)
            return

        raw_tools_run_arg = self._extract_raw_tools_run_arg(command)

        try:
            parts = self._split_command(command)
        except ValueError as exc:
            await state.append_output("stderr", f"Command parse error: {exc}\n")
            state.finalize(ExecutionStatus.FAILED, 1)
            return

        if not parts:
            state.finalize(ExecutionStatus.EXITED, 0)
            return

        cmd, args = parts[0], parts[1:]

        handler = self._command_handlers.get(cmd)
        if handler is not None:
            await handler(session, state, args, raw_tools_run_arg)
            return

        state.executor_kind = "shell"
        await self._run_shell_command(session, state, command)

    def _extract_raw_tools_run_arg(self, command: str) -> str | None:
        raw_parts = command.split(maxsplit=2)
        if len(raw_parts) >= 2 and raw_parts[0] == "tools" and raw_parts[1] == "run":
            return raw_parts[2] if len(raw_parts) == 3 else ""
        return None

    def _split_command(self, command: str) -> list[str]:
        if os.name != "nt":
            return shlex.split(command)
        return [self._strip_matching_quotes(part) for part in shlex.split(command, posix=False)]

    @staticmethod
    def _strip_matching_quotes(value: str) -> str:
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
            return value[1:-1]
        return value

    async def _handle_tools(
        self,
        session: "AEPSession",
        state: ExecutionState,
        args: list[str],
        raw_tools_run_arg: str | None,
    ) -> None:
        state.executor_kind = "tools"
        await self._capability_commands.execute_tools_command(
            state=state,
            args=args,
            raw_tools_run_arg=raw_tools_run_arg,
            cwd=session.cwd,
            workspace=session.workspace,
        )

    async def _handle_skills(
        self,
        _session: "AEPSession",
        state: ExecutionState,
        args: list[str],
        _raw_tools_run_arg: str | None,
    ) -> None:
        state.executor_kind = "skills"
        await self._capability_commands.execute_skills_command(
            state=state,
            args=args,
        )

    async def _handle_cd(
        self,
        session: "AEPSession",
        state: ExecutionState,
        args: list[str],
        _raw_tools_run_arg: str | None,
    ) -> None:
        state.executor_kind = "shell"
        result, new_cwd = handle_cd(
            args,
            workspace=session.workspace,
            cwd=session.cwd,
        )
        if result.return_code == 0:
            session.cwd = new_cwd
        await finalize_from_exec_result(state, result)

    async def _handle_export(
        self,
        session: "AEPSession",
        state: ExecutionState,
        args: list[str],
        _raw_tools_run_arg: str | None,
    ) -> None:
        state.executor_kind = "shell"
        await finalize_from_exec_result(state, handle_export(args, session.env))

    async def _run_shell_command(
        self,
        session: "AEPSession",
        state: ExecutionState,
        command: str,
    ) -> None:
        env = {**os.environ, **session.env}
        if os.name == "nt":
            await run_subprocess_exec(
                state=state,
                argv=[
                    "powershell.exe",
                    "-NoLogo",
                    "-NoProfile",
                    "-NonInteractive",
                    "-Command",
                    command,
                ],
                cwd=session.cwd,
                env=env,
            )
            return

        await run_subprocess_shell(
            state=state,
            command=command,
            cwd=session.cwd,
            env=env,
        )
