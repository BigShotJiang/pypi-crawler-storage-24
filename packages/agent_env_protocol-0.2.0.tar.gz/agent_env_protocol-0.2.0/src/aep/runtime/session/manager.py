﻿"""Session lifecycle manager for async command execution."""

from __future__ import annotations

import asyncio
from collections import deque
from pathlib import Path
from typing import TYPE_CHECKING
from uuid import uuid4

from loguru import logger

from .command_executor import CommandExecutor
from .history import SessionHistory
from .models import (
    ExecutionFact,
    ExecutionStatus,
    KillResponse,
    OutputResponse,
    RunResponse,
    WaitResponse,
)
from .execution_state import ExecutionState

if TYPE_CHECKING:
    from aep.profile import Profile


class AEPSession:
    """Manage one interactive runtime session."""

    def __init__(
        self,
        workspace: Path,
        config: "Profile",
        *,
        max_queue_size: int = 32,
        max_output_chunks: int = 2_000,
        max_output_chars: int = 1_000_000,
        max_history_chars: int = 200_000,
    ):
        self.session_id = uuid4().hex
        self.workspace = workspace
        self.config = config
        self.cwd = workspace
        self.env: dict[str, str] = {}

        self._command_executor = CommandExecutor(config)

        self._queue_lock = asyncio.Lock()
        self._running_exec_id: str | None = None
        self._queue: deque[str] = deque()
        self._executions: dict[str, ExecutionState] = {}
        self._history = SessionHistory()
        self._released = False

        self._max_queue_size = max_queue_size
        self._max_output_chunks = max_output_chunks
        self._max_output_chars = max_output_chars
        self._max_history_chars = max_history_chars

        logger.debug(
            f"Session created: session_id={self.session_id} workspace={workspace}"
        )

    async def run(self, command: str) -> RunResponse:
        """Queue one command for async execution."""

        if self._released:
            raise RuntimeError("Session is released.")

        exec_id = uuid4().hex
        state = ExecutionState(
            session_id=self.session_id,
            exec_id=exec_id,
            raw_command=command,
            cwd_before=str(self.cwd),
            env_before=self.env.copy(),
            max_output_chunks=self._max_output_chunks,
            max_output_chars=self._max_output_chars,
            max_history_chars=self._max_history_chars,
        )

        start_now = False
        async with self._queue_lock:
            self._executions[exec_id] = state
            if self._running_exec_id is None:
                self._running_exec_id = exec_id
                state.mark_running()
                start_now = True
                queue_pos = 0
            else:
                if len(self._queue) >= self._max_queue_size:
                    del self._executions[exec_id]
                    raise RuntimeError(
                        f"Session queue full (max_queue_size={self._max_queue_size})."
                    )
                self._queue.append(exec_id)
                queue_pos = len(self._queue)

        self._history.upsert_from_state(state)

        if start_now:
            asyncio.create_task(self._execute(exec_id))

        return RunResponse(
            exec_id=exec_id,
            status=state.status,
            queue_pos=queue_pos,
            started_at=state.started_at,
        )

    async def output(
        self,
        exec_id: str,
        cursor: int = 0,
        limit: int = 200,
    ) -> OutputResponse:
        """Read incremental output from a cursor."""

        state = self._get_execution(exec_id)
        chunks, next_cursor = await state.read_output(cursor, limit)
        return OutputResponse(
            chunks=chunks,
            next_cursor=next_cursor,
            is_running=state.is_running(),
            exit_code=state.exit_code if state.is_terminal() else None,
        )

    async def wait(
        self,
        exec_id: str,
        timeout_ms: int | None = None,
    ) -> WaitResponse:
        """Wait for an execution to finish."""

        state = self._get_execution(exec_id)
        await state.wait_finished(timeout_ms)
        return WaitResponse(
            status=state.status,
            exit_code=state.exit_code,
            finished_at=state.finished_at,
        )

    async def kill(self, exec_id: str) -> KillResponse:
        """Kill queued/running execution."""

        state = self._get_execution(exec_id)
        status_before = state.status

        if status_before == ExecutionStatus.QUEUED:
            async with self._queue_lock:
                try:
                    self._queue.remove(exec_id)
                except ValueError:
                    pass
            state.kill_requested = True
            state.finalize(ExecutionStatus.KILLED, None)
            state.cwd_after = str(self.cwd)
            state.env_after = self.env.copy()
            self._history.upsert_from_state(state)
            return KillResponse(
                status_before=status_before,
                status_after=state.status,
            )

        if status_before == ExecutionStatus.RUNNING:
            state.kill_requested = True
            process = state.process
            if process and process.returncode is None:
                try:
                    process.kill()
                except ProcessLookupError:
                    pass

            await state.wait_finished(timeout_ms=5_000)
            if not state.is_terminal():
                state.finalize(ExecutionStatus.KILLED, None)
                state.cwd_after = str(self.cwd)
                state.env_after = self.env.copy()
                self._history.upsert_from_state(state)

        return KillResponse(
            status_before=status_before,
            status_after=state.status,
        )

    async def release(self) -> dict[str, bool]:
        """Release this session and cancel pending/running work."""

        if self._released:
            return {"released": False}
        self._released = True

        async with self._queue_lock:
            queued_ids = list(self._queue)
            self._queue.clear()
            running_id = self._running_exec_id

        for queued_id in queued_ids:
            queued_state = self._executions.get(queued_id)
            if queued_state and not queued_state.is_terminal():
                queued_state.kill_requested = True
                queued_state.finalize(ExecutionStatus.KILLED, None)
                queued_state.cwd_after = str(self.cwd)
                queued_state.env_after = self.env.copy()
                self._history.upsert_from_state(queued_state)

        if running_id is not None:
            await self.kill(running_id)

        return {"released": True}

    def get_execution_fact(self, exec_id: str) -> ExecutionFact | None:
        return self._history.get(exec_id)

    def list_execution_facts(self) -> list[ExecutionFact]:
        return self._history.list_all()

    async def _execute(self, exec_id: str) -> None:
        state = self._executions.get(exec_id)
        if state is None:
            return
        if state.is_terminal():
            state.cwd_after = str(self.cwd)
            state.env_after = self.env.copy()
            self._history.upsert_from_state(state)
            await self._start_next(exec_id)
            return
        if state.status == ExecutionStatus.QUEUED:
            state.mark_running()
            self._history.upsert_from_state(state)

        try:
            await self._command_executor.execute(self, state)
        except Exception as exc:
            logger.exception(f"Session async execution failed: {exc}")
            await state.append_output("stderr", f"Execution error: {exc}\n")
            state.finalize(ExecutionStatus.FAILED, 1)
        finally:
            state.cwd_after = str(self.cwd)
            state.env_after = self.env.copy()
            self._history.upsert_from_state(state)
            await self._start_next(exec_id)

    async def _start_next(self, finished_exec_id: str) -> None:
        next_id: str | None = None
        async with self._queue_lock:
            if self._running_exec_id == finished_exec_id:
                self._running_exec_id = None

            while self._queue:
                candidate = self._queue.popleft()
                next_state = self._executions.get(candidate)
                if next_state is None or next_state.status != ExecutionStatus.QUEUED:
                    continue
                self._running_exec_id = candidate
                next_state.mark_running()
                self._history.upsert_from_state(next_state)
                next_id = candidate
                break

        if next_id is not None:
            asyncio.create_task(self._execute(next_id))

    def _get_execution(self, exec_id: str) -> ExecutionState:
        state = self._executions.get(exec_id)
        if state is None:
            raise KeyError(f"Execution not found: {exec_id}")
        return state
