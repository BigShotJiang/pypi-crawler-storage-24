﻿"""Async subprocess execution helpers for session commands."""

from __future__ import annotations

import asyncio
import locale
from pathlib import Path

from .models import ExecutionStatus
from .execution_state import ExecutionState


async def run_subprocess_shell(
    *,
    state: ExecutionState,
    command: str,
    cwd: Path,
    env: dict[str, str] | None,
) -> None:
    try:
        process = await asyncio.create_subprocess_shell(
            command,
            cwd=str(cwd),
            env=env,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except Exception as exc:
        await state.append_output("stderr", f"Execution error: {exc}\n")
        state.finalize(ExecutionStatus.FAILED, 1)
        return

    await run_process_output(state, process)


async def run_subprocess_exec(
    *,
    state: ExecutionState,
    argv: list[str],
    cwd: Path,
    env: dict[str, str] | None,
) -> None:
    try:
        process = await asyncio.create_subprocess_exec(
            *argv,
            cwd=str(cwd),
            env=env,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
    except Exception as exc:
        await state.append_output("stderr", f"Execution error: {exc}\n")
        state.finalize(ExecutionStatus.FAILED, 1)
        return

    await run_process_output(state, process)


async def run_process_output(
    state: ExecutionState,
    process: asyncio.subprocess.Process,
) -> None:
    state.process = process
    if state.kill_requested and process.returncode is None:
        try:
            process.kill()
        except ProcessLookupError:
            pass

    async def _pump(
        stream: asyncio.StreamReader | None,
        stream_name: str,
    ) -> None:
        if stream is None:
            return
        preferred_encoding = _preferred_text_encoding()
        pending = b""
        use_preferred = False
        while True:
            chunk = await stream.read(4_096)
            if not chunk:
                if pending:
                    await state.append_output(
                        stream_name,
                        _decode_final(
                            pending,
                            preferred_encoding=preferred_encoding,
                            use_preferred=use_preferred,
                        ),
                    )
                return

            text, pending, use_preferred = _decode_chunk(
                pending + chunk,
                preferred_encoding=preferred_encoding,
                use_preferred=use_preferred,
            )
            if text:
                await state.append_output(stream_name, text)

    stdout_task = asyncio.create_task(_pump(process.stdout, "stdout"))
    stderr_task = asyncio.create_task(_pump(process.stderr, "stderr"))
    return_code = await process.wait()
    await asyncio.gather(stdout_task, stderr_task)

    if state.kill_requested:
        state.finalize(ExecutionStatus.KILLED, return_code)
        return

    status = ExecutionStatus.EXITED if return_code == 0 else ExecutionStatus.FAILED
    state.finalize(status, return_code)


def _preferred_text_encoding() -> str:
    encoding = locale.getpreferredencoding(False)
    if encoding and encoding.strip():
        return encoding
    return "utf-8"


def _decode_chunk(
    data: bytes,
    *,
    preferred_encoding: str,
    use_preferred: bool,
) -> tuple[str, bytes, bool]:
    if not data:
        return ("", b"", use_preferred)

    if use_preferred:
        return (data.decode(preferred_encoding, errors="replace"), b"", True)

    try:
        return (data.decode("utf-8"), b"", False)
    except UnicodeDecodeError as exc:
        # Keep an incomplete utf-8 tail for the next chunk.
        if exc.reason == "unexpected end of data" and exc.start < len(data):
            prefix = data[: exc.start]
            tail = data[exc.start:]
            text = prefix.decode("utf-8", errors="replace") if prefix else ""
            return (text, tail, False)

        return (data.decode(preferred_encoding, errors="replace"), b"", True)


def _decode_final(
    data: bytes,
    *,
    preferred_encoding: str,
    use_preferred: bool,
) -> str:
    if not data:
        return ""
    if use_preferred:
        return data.decode(preferred_encoding, errors="replace")
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode(preferred_encoding, errors="replace")
