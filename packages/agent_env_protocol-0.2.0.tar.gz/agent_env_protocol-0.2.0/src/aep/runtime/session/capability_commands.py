﻿"""Unified tools/skills command handling and capability execution helpers."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from aep._util.venv import _get_python
from aep.datamodels.session import ExecResult
from .builtins import extract_tools_run_code, skills_info, tools_info
from .execution_state import ExecutionState, finalize_from_exec_result
from .subprocess_runner import run_subprocess_exec

if TYPE_CHECKING:
    from aep.profile import Profile


class CapabilityCommands:
    """Handle tools/skills command dispatch plus execution preparation."""

    def __init__(self, config: "Profile") -> None:
        self._config = config
        self._tools_dir = config.tools_dir
        self._skills_dir = config.skills_dir

    async def execute_tools_command(
        self,
        *,
        state: ExecutionState,
        args: list[str],
        raw_tools_run_arg: str | None,
        cwd: Path,
        workspace: Path,
    ) -> None:
        if not args:
            await finalize_from_exec_result(
                state,
                ExecResult(
                    stderr=(
                        "Usage: tools <list|info|run> [args]\n"
                        "  tools list             - list all tools\n"
                        "  tools info <name>      - show tool details\n"
                        '  tools run "<code>"     - execute single-line python code\n'
                        "  tools run PY<< ... PY  - execute multi-line python code"
                    ),
                    return_code=1,
                ),
            )
            return

        subcmd = args[0]
        if subcmd == "list":
            index_file = self._config.tools_dir / "index.md"
            if index_file.exists():
                await finalize_from_exec_result(
                    state,
                    ExecResult(stdout=index_file.read_text(encoding="utf-8")),
                )
                return
            await finalize_from_exec_result(state, ExecResult(stdout="_no tools_\n"))
            return

        if subcmd == "info":
            if len(args) < 2:
                await finalize_from_exec_result(
                    state,
                    ExecResult(stderr="Usage: tools info <name>", return_code=1),
                )
                return
            await finalize_from_exec_result(state, tools_info(self._config, args[1]))
            return

        if subcmd == "run":
            if raw_tools_run_arg is not None:
                await self._execute_tools_run(
                    state=state,
                    code_arg=raw_tools_run_arg,
                    cwd=cwd,
                    workspace=workspace,
                )
                return
            if len(args) < 2:
                await finalize_from_exec_result(
                    state,
                    ExecResult(
                        stderr='Usage: tools run "<python_code>" or tools run PY<< ... PY',
                        return_code=1,
                    ),
                )
                return
            await self._run_tools_code(
                state=state,
                code=args[1],
                cwd=cwd,
                workspace=workspace,
            )
            return

        await finalize_from_exec_result(
            state,
            ExecResult(stderr=f"Unknown subcommand: {subcmd}", return_code=1),
        )

    async def execute_skills_command(
        self,
        *,
        state: ExecutionState,
        args: list[str],
    ) -> None:
        if not args:
            await finalize_from_exec_result(
                state,
                ExecResult(
                    stderr=(
                        "Usage: skills <list|info|run> [args]\n"
                        "  skills list                  - list all skills\n"
                        "  skills info <name>           - show skill details\n"
                        "  skills run <path.py> [args]  - run skill script"
                    ),
                    return_code=1,
                ),
            )
            return

        subcmd = args[0]
        if subcmd == "list":
            index_file = self._config.skills_dir / "index.md"
            if index_file.exists():
                await finalize_from_exec_result(
                    state,
                    ExecResult(stdout=index_file.read_text(encoding="utf-8")),
                )
                return
            await finalize_from_exec_result(state, ExecResult(stdout="_no skills_\n"))
            return

        if subcmd == "info":
            if len(args) < 2:
                await finalize_from_exec_result(
                    state,
                    ExecResult(stderr="Usage: skills info <name>", return_code=1),
                )
                return
            await finalize_from_exec_result(state, skills_info(self._config, args[1]))
            return

        if subcmd == "run":
            if len(args) < 2:
                await finalize_from_exec_result(
                    state,
                    ExecResult(
                        stderr="Usage: skills run <path.py> [args]",
                        return_code=1,
                    ),
                )
                return
            await self._run_skill_script(
                state=state,
                script_path=args[1],
                args=args[2:],
            )
            return

        await finalize_from_exec_result(
            state,
            ExecResult(stderr=f"Unknown subcommand: {subcmd}", return_code=1),
        )

    async def _execute_tools_run(
        self,
        *,
        state: ExecutionState,
        code_arg: str,
        cwd: Path,
        workspace: Path,
    ) -> None:
        code_arg = code_arg.strip()
        if not code_arg:
            await finalize_from_exec_result(
                state,
                ExecResult(
                    stderr='Usage: tools run "<python_code>" or tools run PY<< ... PY',
                    return_code=1,
                ),
            )
            return

        code = extract_tools_run_code(code_arg)
        if code is None:
            await finalize_from_exec_result(
                state,
                ExecResult(
                    stderr=(
                        'Code must use either quoted syntax, e.g. tools run "code", '
                        "or the exact multi-line block syntax, e.g.\n"
                        "tools run PY<<\n"
                        "print(123)\n"
                        "PY"
                    ),
                    return_code=1,
                ),
            )
            return

        await self._run_tools_code(
            state=state,
            code=code,
            cwd=cwd,
            workspace=workspace,
        )

    async def _run_tools_code(
        self,
        *,
        state: ExecutionState,
        code: str,
        cwd: Path,
        workspace: Path,
    ) -> None:
        try:
            argv = self._prepare_tools_run(code, cwd=cwd, workspace=workspace)
        except Exception as exc:
            await finalize_from_exec_result(
                state,
                ExecResult(stderr=f"Execution error: {exc}", return_code=1),
            )
            return

        await run_subprocess_exec(
            state=state,
            argv=argv,
            cwd=cwd,
            env=None,
        )

    async def _run_skill_script(
        self,
        *,
        state: ExecutionState,
        script_path: str,
        args: list[str],
    ) -> None:
        try:
            argv, cwd = self._prepare_skill_run(script_path, args)
        except Exception as exc:
            await finalize_from_exec_result(
                state,
                ExecResult(stderr=str(exc), return_code=1),
            )
            return

        await run_subprocess_exec(
            state=state,
            argv=argv,
            cwd=cwd,
            env=None,
        )

    def _prepare_tools_run(
        self,
        code: str,
        *,
        cwd: Path,
        workspace: Path,
    ) -> list[str]:
        python = self._ensure_tools_python()
        wrapper_script = self._build_tools_wrapper_script(code, cwd, workspace)
        return [str(python), "-c", wrapper_script]

    def _prepare_skill_run(
        self,
        script_path: str,
        args: list[str],
    ) -> tuple[list[str], Path]:
        normalized_script_path = script_path.replace("\\", "/")
        parts = [
            part
            for part in normalized_script_path.split("/")
            if part not in ("", ".")
        ]
        if not parts:
            raise RuntimeError(f"Invalid script path: {script_path}")
        if any(part == ".." for part in parts):
            raise RuntimeError(f"Script path cannot contain '..': {script_path}")

        skill_name = parts[0]
        skill_dir = self._skills_dir / skill_name
        if not skill_dir.is_dir():
            raise RuntimeError(f"Skill not found: {skill_name}")

        full_script = self._skills_dir / Path(*parts)
        if not full_script.exists() or not full_script.is_file():
            raise RuntimeError(f"Script not found: {script_path}")

        python = self._ensure_skill_python(skill_name)
        argv = [str(python), str(full_script), *args]
        return argv, skill_dir

    def _ensure_tools_python(self) -> Path:
        venv_dir = self._tools_dir / ".venv"
        if not venv_dir.exists():
            raise RuntimeError(
                "tools venv does not exist; initialize tools environment."
            )
        return _get_python(venv_dir)

    def _ensure_skill_python(self, skill_name: str) -> Path:
        skill_dir = self._skills_dir / skill_name
        venv_dir = skill_dir / ".venv"
        if not venv_dir.exists():
            raise RuntimeError(f"Skill venv missing: {skill_dir}")
        return _get_python(venv_dir)

    def _build_tools_wrapper_script(
        self,
        code: str,
        cwd: Path,
        workspace: Path,
    ) -> str:
        tools_dir_str = str(self._tools_dir).replace("\\", "\\\\")
        cwd_str = str(cwd).replace("\\", "\\\\")
        workspace_str = str(workspace).replace("\\", "\\\\")
        escaped_code = code.replace("\\", "\\\\").replace('"', '\\"')

        return f'''
import ast
import importlib.util
import json
import re
import sys
from pathlib import Path

cwd = Path("{cwd_str}")
workspace = Path("{workspace_str}")
tools_dir = Path("{tools_dir_str}")

class ToolsNamespace:
    pass

tools = ToolsNamespace()
for py_file in tools_dir.glob("*.py"):
    tool_name = py_file.stem
    try:
        spec = importlib.util.spec_from_file_location(tool_name, py_file)
        if spec and spec.loader:
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            setattr(tools, tool_name, module)
    except Exception as e:
        print(f"Warning: Failed to load tool {{tool_name}}: {{e}}", file=sys.stderr)

_code = """{escaped_code}"""

def _repl_exec(_code, _globals):
    try:
        tree = ast.parse(_code)
    except SyntaxError as e:
        print(f"SyntaxError: {{e}}", file=sys.stderr)
        sys.exit(1)

    if not tree.body:
        return

    last_stmt = tree.body[-1]
    if isinstance(last_stmt, ast.Expr):
        if len(tree.body) > 1:
            mod = ast.Module(body=tree.body[:-1], type_ignores=[])
            exec(compile(mod, "<code>", "exec"), _globals)

        expr = ast.Expression(body=last_stmt.value)
        result = eval(compile(expr, "<code>", "eval"), _globals)
        if result is not None:
            print(result)
    else:
        exec(compile(tree, "<code>", "exec"), _globals)

try:
    _repl_exec(_code, globals())
except Exception as e:
    print(f"{{type(e).__name__}}: {{e}}", file=sys.stderr)
    sys.exit(1)
'''
