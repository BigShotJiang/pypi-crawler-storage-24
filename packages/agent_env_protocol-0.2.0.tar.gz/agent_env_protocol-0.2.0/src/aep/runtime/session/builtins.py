﻿"""Built-in command helpers and metadata readers for session commands."""

from __future__ import annotations

import os
from pathlib import Path
from typing import TYPE_CHECKING

from aep.datamodels.session import ExecResult

if TYPE_CHECKING:
    from aep.profile import Profile


def extract_quoted_code(value: str) -> str | None:
    """Extract quoted code payload for `tools run` syntax."""
    if value.startswith('"""') and value.endswith('"""') and len(value) >= 6:
        return value[3:-3]
    if value.startswith("'''") and value.endswith("'''") and len(value) >= 6:
        return value[3:-3]
    if value.startswith('"') and value.endswith('"') and len(value) >= 2:
        return value[1:-1]
    if value.startswith("'") and value.endswith("'") and len(value) >= 2:
        return value[1:-1]
    return None


def extract_heredoc_code(value: str) -> str | None:
    """Extract `PY<< ... PY` style code payload for `tools run`."""
    lines = value.splitlines()
    if len(lines) < 2:
        return None

    first = lines[0].strip()
    if first != "PY<<":
        return None
    if lines[-1].strip() != "PY":
        return None
    return "\n".join(lines[1:-1])


def extract_tools_run_code(value: str) -> str | None:
    """Extract `tools run` code from single-line quoted or `PY<< ... PY` syntax."""
    code = extract_heredoc_code(value)
    if code is not None:
        return code
    if "\n" in value or "\r" in value:
        return None
    return extract_quoted_code(value)


def tools_info(config: "Profile", name: str) -> ExecResult:
    doc_file = config.tools_dir / f"{name}.md"
    if doc_file.exists():
        return ExecResult(stdout=doc_file.read_text(encoding="utf-8"))

    py_file = config.tools_dir / f"{name}.py"
    if py_file.exists():
        content = py_file.read_text(encoding="utf-8")
        if content.startswith('"""'):
            end = content.find('"""', 3)
            if end > 0:
                return ExecResult(stdout=content[3:end].strip())
        return ExecResult(stdout=f"Tool {name} exists, but no docs found.")

    return ExecResult(stderr=f"Tool not found: {name}", return_code=1)


def skills_info(config: "Profile", name: str) -> ExecResult:
    skill_dir = config.skills_dir / name
    if not skill_dir.is_dir():
        return ExecResult(stderr=f"Skill not found: {name}", return_code=1)

    for doc_name in ("SKILL.md", "README.md"):
        doc_file = skill_dir / doc_name
        if doc_file.exists():
            return ExecResult(stdout=doc_file.read_text(encoding="utf-8"))

    return ExecResult(stdout=f"Skill {name} exists, but no docs found.")


def handle_cd(args: list[str], *, workspace: Path, cwd: Path) -> tuple[ExecResult, Path]:
    if not args:
        return ExecResult(stdout=str(workspace)), workspace

    target = args[0]
    target_path = Path(target)
    if _is_absolute_target(target, target_path):
        candidate = target_path
    else:
        candidate = cwd / target_path

    # Keep logical navigation for symlink paths (e.g. workspace/.agents/*).
    # resolve() follows symlinks and can unexpectedly jump into profile dirs.
    new_path = _normalize_logical_path(candidate)
    if not new_path.exists():
        return ExecResult(stderr=f"Directory not found: {new_path}", return_code=1), cwd
    if not new_path.is_dir():
        return ExecResult(stderr=f"Not a directory: {new_path}", return_code=1), cwd

    if _is_within_workspace(new_path, workspace):
        return ExecResult(stdout=str(new_path)), new_path

    warning = (
        f"{new_path}\n"
        "Warning: You are outside the workspace. "
        "Run `cd` to return to the workspace root."
    )
    return ExecResult(stdout=warning), new_path


def _normalize_logical_path(path: Path) -> Path:
    return Path(os.path.normpath(str(path)))


def _is_absolute_target(target: str, target_path: Path) -> bool:
    if target_path.is_absolute():
        return True
    if target.startswith("/") or target.startswith("\\"):
        return True
    if len(target) > 1 and target[1] == ":":
        return True
    return False


def _is_within_workspace(path: Path, workspace: Path) -> bool:
    path_norm = os.path.normcase(os.path.normpath(str(path)))
    workspace_norm = os.path.normcase(os.path.normpath(str(workspace)))
    try:
        common = os.path.commonpath([path_norm, workspace_norm])
    except ValueError:
        return False
    return common == workspace_norm


def handle_export(args: list[str], env: dict[str, str]) -> ExecResult:
    if not args:
        output = "\n".join(f"{key}={value}" for key, value in env.items())
        return ExecResult(stdout=output or "(no custom env vars)")

    for item in args:
        if "=" not in item:
            return ExecResult(
                stderr=f"Invalid format: {item}, expected KEY=VALUE",
                return_code=1,
            )
        key, value = item.split("=", 1)
        env[key] = value

    return ExecResult()
