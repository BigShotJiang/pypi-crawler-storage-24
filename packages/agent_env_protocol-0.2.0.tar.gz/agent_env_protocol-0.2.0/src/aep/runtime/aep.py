"""Unified AEP runtime facade."""

from __future__ import annotations

import asyncio
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from loguru import logger

from ..profile import Profile
from .context import build_context as render_context
from .context import build_tool_schemas
from .session import AEPSession
from .bound_tools import SessionToolRuntime, ToolSchemaBinding


class AEP:
    """Bind one profile to one workspace and manage lazy logical sessions."""

    def __init__(
        self,
        config: str | Path | Profile,
        *,
        workspace: str | Path,
        agent_dir: str = ".agents",
        max_queue_size: int = 32,
    ) -> None:
        self.profile = config if isinstance(config, Profile) else Profile(config)
        self.workspace = Path(workspace).resolve()
        self.workspace.mkdir(parents=True, exist_ok=True)

        self.agent_dir_name = agent_dir
        self.agent_dir = self.workspace / agent_dir
        self._max_queue_size = max_queue_size
        self._sessions: dict[str, AEPSession] = {}

        self._attach()

    def build_context(
        self,
        *,
        include_tools: bool = True,
        include_skills: bool = True,
        include_library: bool = True,
    ) -> str:
        sections = self._collect_context_sections(
            include_tools=include_tools,
            include_skills=include_skills,
            include_library=include_library,
        )
        return render_context(
            agent_dir_name=self.agent_dir_name,
            workspace_dir=str(self.workspace),
            sections=sections,
        )

    def tool_schemas(self, session_id: str) -> ToolSchemaBinding:
        session_key = self._normalize_session_id(session_id)
        self._ensure_session(session_key)
        return ToolSchemaBinding(
            session_id=session_key,
            schemas=build_tool_schemas(),
        )

    async def call_tool(
        self,
        session_id: str,
        name: str,
        arguments: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        runtime = SessionToolRuntime(self._ensure_session(session_id))
        return await runtime.call_tool(name, arguments)

    def detach(self) -> None:
        self._release_all_sessions()

        if not self.agent_dir.exists():
            return

        for name in ("tools", "skills", "library"):
            link = self.agent_dir / name
            if link.is_symlink():
                link.unlink()

        try:
            if not any(self.agent_dir.iterdir()):
                self.agent_dir.rmdir()
        except OSError as exc:
            logger.warning(f"Failed removing {self.agent_dir}: {exc}")

        logger.info(f"AEP detached: {self.workspace}")

    def _attach(self) -> None:
        if self.agent_dir.exists():
            logger.info(f"{self.agent_dir_name}/ exists; links will be refreshed")
        else:
            self.agent_dir.mkdir(parents=True)

        links: list[tuple[str, Path]] = [
            ("tools", self.profile.tools_dir),
            ("skills", self.profile.skills_dir),
            ("library", self.profile.library_dir),
        ]

        for name, target in links:
            link = self.agent_dir / name

            if link.exists() and not link.is_symlink():
                raise RuntimeError(f"Path conflict: {link} exists and is not a symlink.")

            if link.is_symlink():
                link.unlink()

            try:
                link.symlink_to(target, target_is_directory=True)
            except OSError as exc:
                logger.error(f"Failed creating symlink: {link} -> {target}: {exc}")
                raise

        logger.info(f"AEP attached: {self.workspace} <- {self.profile.config_dir}")

    def _collect_context_sections(
        self,
        *,
        include_tools: bool,
        include_skills: bool,
        include_library: bool,
    ) -> dict[str, str]:
        sections: dict[str, str] = {}

        if include_tools:
            tools_index = self.profile.tools_dir / "index.md"
            if tools_index.exists():
                sections["tools"] = tools_index.read_text(encoding="utf-8")

        if include_skills:
            skills_index = self.profile.skills_dir / "index.md"
            if skills_index.exists():
                sections["skills"] = skills_index.read_text(encoding="utf-8")

        if include_library:
            library_index = self.profile.library_dir / "index.md"
            if library_index.exists():
                sections["library"] = library_index.read_text(encoding="utf-8")

        return sections

    def _ensure_session(self, session_id: str) -> AEPSession:
        session_key = self._normalize_session_id(session_id)
        session = self._sessions.get(session_key)
        if session is None:
            session = AEPSession(
                self.workspace,
                self.profile,
                max_queue_size=self._max_queue_size,
            )
            self._sessions[session_key] = session
        return session

    def _release_all_sessions(self) -> None:
        sessions = list(self._sessions.values())
        self._sessions.clear()
        if not sessions:
            return

        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            asyncio.run(self._release_sessions_async(sessions))
            return

        for session in sessions:
            loop.create_task(session.release())

    async def _release_sessions_async(self, sessions: list[AEPSession]) -> None:
        for session in sessions:
            await session.release()

    @staticmethod
    def _normalize_session_id(session_id: str) -> str:
        value = session_id.strip()
        if not value:
            raise ValueError("session_id must be non-empty")
        return value

    def __repr__(self) -> str:
        return (
            "AEP("
            f"config={self.profile.config_dir}, "
            f"workspace={self.workspace}, "
            f"agent_dir={self.agent_dir_name}"
            ")"
        )
