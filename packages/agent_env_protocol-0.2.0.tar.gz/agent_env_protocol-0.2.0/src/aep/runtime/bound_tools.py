"""Session-bound tool execution helpers for the AEP runtime."""

from __future__ import annotations

from dataclasses import dataclass
from collections.abc import Mapping
from typing import Any

from .session import AEPSession
from .session.models import ExecutionFact, ExecutionStatus, OutputChunk


@dataclass(slots=True)
class ToolSchemaBinding:
    """Lightweight binding between one logical session and its tool schemas."""

    session_id: str
    schemas: list[dict[str, object]]


class SessionToolRuntime:
    """Expose one AEPSession as function-call friendly tool methods."""

    DEFAULT_EXEC_TIMEOUT_MS = 8_000
    DEFAULT_OUTPUT_LIMIT = 200
    MAX_DRAIN_PAGES = 1_000

    _TERMINAL_STATUSES = {
        ExecutionStatus.EXITED,
        ExecutionStatus.FAILED,
        ExecutionStatus.KILLED,
    }

    def __init__(self, session: AEPSession) -> None:
        self._session = session

    async def call_tool(
        self,
        name: str,
        arguments: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        payload = dict(arguments or {})
        try:
            if name == "aep_exec":
                command = self._require_string(payload, "command")
                timeout_ms = self._optional_int(
                    payload,
                    "timeout_ms",
                    default=self.DEFAULT_EXEC_TIMEOUT_MS,
                    minimum=0,
                )
                output_limit = self._optional_int(
                    payload,
                    "output_limit",
                    default=self.DEFAULT_OUTPUT_LIMIT,
                    minimum=1,
                )
                return await self.aep_exec(
                    command=command,
                    timeout_ms=timeout_ms,
                    output_limit=output_limit,
                )

            if name == "aep_output":
                exec_id = self._require_string(payload, "exec_id")
                cursor = self._optional_int(payload, "cursor", default=0, minimum=0)
                limit = self._optional_int(
                    payload,
                    "limit",
                    default=self.DEFAULT_OUTPUT_LIMIT,
                    minimum=1,
                )
                return await self.aep_output(exec_id=exec_id, cursor=cursor, limit=limit)

            if name == "aep_kill":
                exec_id = self._require_string(payload, "exec_id")
                cursor = self._optional_int(payload, "cursor", default=0, minimum=0)
                limit = self._optional_int(
                    payload,
                    "limit",
                    default=self.DEFAULT_OUTPUT_LIMIT,
                    minimum=1,
                )
                return await self.aep_kill(exec_id=exec_id, cursor=cursor, limit=limit)

            if name == "aep_history":
                limit = self._optional_int(payload, "limit", default=10, minimum=1)
                include_output = self._optional_bool(
                    payload,
                    "include_output",
                    default=False,
                )
                output_preview_chars = self._optional_int(
                    payload,
                    "output_preview_chars",
                    default=600,
                    minimum=0,
                )
                return await self.aep_history(
                    limit=limit,
                    include_output=include_output,
                    output_preview_chars=output_preview_chars,
                )

            if name == "aep_env":
                keys = self._optional_string_list(payload, "keys")
                return await self.aep_env(keys=keys)

            return self._error(name, f"Unknown tool: {name}")
        except Exception as exc:
            return self._error(name, str(exc))

    async def aep_exec(
        self,
        *,
        command: str,
        timeout_ms: int = DEFAULT_EXEC_TIMEOUT_MS,
        output_limit: int = DEFAULT_OUTPUT_LIMIT,
    ) -> dict[str, Any]:
        if not command.strip():
            raise ValueError("command must be non-empty")
        if timeout_ms < 0:
            raise ValueError("timeout_ms must be >= 0")
        if output_limit <= 0:
            raise ValueError("output_limit must be > 0")

        run_result = await self._session.run(command)
        wait_result = await self._session.wait(run_result.exec_id, timeout_ms=timeout_ms)

        if wait_result.status not in self._TERMINAL_STATUSES:
            out = await self._session.output(run_result.exec_id, cursor=0, limit=output_limit)
            stdout_delta, stderr_delta = self._split_streams(out.chunks)
            return {
                "ok": True,
                "tool": "aep_exec",
                "exec_id": run_result.exec_id,
                "status": wait_result.status.value,
                "is_running": wait_result.status in (ExecutionStatus.QUEUED, ExecutionStatus.RUNNING),
                "timed_out": True,
                "queue_pos": run_result.queue_pos,
                "exit_code": None,
                "stdout_delta": stdout_delta,
                "stderr_delta": stderr_delta,
                "chunks": [self._chunk_to_dict(chunk) for chunk in out.chunks],
                "next_cursor": out.next_cursor,
            }

        stdout, stderr, next_cursor = await self._drain_output(
            exec_id=run_result.exec_id,
            cursor=0,
            limit=output_limit,
        )
        return {
            "ok": True,
            "tool": "aep_exec",
            "exec_id": run_result.exec_id,
            "status": wait_result.status.value,
            "is_running": False,
            "timed_out": False,
            "queue_pos": run_result.queue_pos,
            "exit_code": wait_result.exit_code,
            "stdout": stdout,
            "stderr": stderr,
            "next_cursor": next_cursor,
        }

    async def aep_output(
        self,
        *,
        exec_id: str,
        cursor: int = 0,
        limit: int = DEFAULT_OUTPUT_LIMIT,
    ) -> dict[str, Any]:
        if not exec_id.strip():
            raise ValueError("exec_id must be non-empty")
        if cursor < 0:
            raise ValueError("cursor must be >= 0")
        if limit <= 0:
            raise ValueError("limit must be > 0")

        out = await self._session.output(exec_id, cursor=cursor, limit=limit)
        status = self._resolve_status(exec_id, is_running=out.is_running, exit_code=out.exit_code)
        stdout_delta, stderr_delta = self._split_streams(out.chunks)
        return {
            "ok": True,
            "tool": "aep_output",
            "exec_id": exec_id,
            "status": status,
            "is_running": out.is_running,
            "exit_code": out.exit_code,
            "stdout_delta": stdout_delta,
            "stderr_delta": stderr_delta,
            "chunks": [self._chunk_to_dict(chunk) for chunk in out.chunks],
            "next_cursor": out.next_cursor,
        }

    async def aep_kill(
        self,
        *,
        exec_id: str,
        cursor: int = 0,
        limit: int = DEFAULT_OUTPUT_LIMIT,
    ) -> dict[str, Any]:
        if not exec_id.strip():
            raise ValueError("exec_id must be non-empty")
        if cursor < 0:
            raise ValueError("cursor must be >= 0")
        if limit <= 0:
            raise ValueError("limit must be > 0")

        killed = await self._session.kill(exec_id)
        out = await self._session.output(exec_id, cursor=cursor, limit=limit)
        stdout_delta, stderr_delta = self._split_streams(out.chunks)
        return {
            "ok": True,
            "tool": "aep_kill",
            "exec_id": exec_id,
            "status_before": killed.status_before.value,
            "status_after": killed.status_after.value,
            "status": killed.status_after.value,
            "is_running": out.is_running,
            "exit_code": out.exit_code,
            "stdout_delta": stdout_delta,
            "stderr_delta": stderr_delta,
            "chunks": [self._chunk_to_dict(chunk) for chunk in out.chunks],
            "next_cursor": out.next_cursor,
        }

    async def aep_history(
        self,
        *,
        limit: int = 10,
        include_output: bool = False,
        output_preview_chars: int = 600,
    ) -> dict[str, Any]:
        if limit <= 0:
            raise ValueError("limit must be > 0")
        if output_preview_chars < 0:
            raise ValueError("output_preview_chars must be >= 0")

        facts = list(reversed(self._session.list_execution_facts()))
        selected = facts[:limit]
        return {
            "ok": True,
            "tool": "aep_history",
            "count": len(selected),
            "items": [
                self._fact_to_dict(
                    fact,
                    include_output=include_output,
                    output_preview_chars=output_preview_chars,
                )
                for fact in selected
            ],
        }

    async def aep_env(
        self,
        *,
        keys: list[str] | None = None,
    ) -> dict[str, Any]:
        current = self._session.env.copy()
        if keys is None:
            selected = dict(sorted(current.items()))
            missing: list[str] = []
        else:
            missing = [key for key in keys if key not in current]
            selected = {key: current[key] for key in keys if key in current}

        return {
            "ok": True,
            "tool": "aep_env",
            "env": selected,
            "keys": keys or list(selected.keys()),
            "missing": missing,
        }

    async def _drain_output(
        self,
        *,
        exec_id: str,
        cursor: int,
        limit: int,
    ) -> tuple[str, str, int]:
        stdout_parts: list[str] = []
        stderr_parts: list[str] = []
        next_cursor = cursor

        for _ in range(self.MAX_DRAIN_PAGES):
            out = await self._session.output(exec_id, cursor=next_cursor, limit=limit)
            stdout_delta, stderr_delta = self._split_streams(out.chunks)
            if stdout_delta:
                stdout_parts.append(stdout_delta)
            if stderr_delta:
                stderr_parts.append(stderr_delta)

            if out.next_cursor == next_cursor:
                break
            next_cursor = out.next_cursor

            if out.is_running:
                break

        return ("".join(stdout_parts), "".join(stderr_parts), next_cursor)

    def _resolve_status(
        self,
        exec_id: str,
        *,
        is_running: bool,
        exit_code: int | None,
    ) -> str:
        fact = self._session.get_execution_fact(exec_id)
        if fact is not None:
            return fact.status.value
        if is_running:
            return ExecutionStatus.RUNNING.value
        if exit_code is None:
            return ExecutionStatus.QUEUED.value
        if exit_code == 0:
            return ExecutionStatus.EXITED.value
        return ExecutionStatus.FAILED.value

    @staticmethod
    def _split_streams(chunks: list[OutputChunk]) -> tuple[str, str]:
        stdout_parts: list[str] = []
        stderr_parts: list[str] = []
        for chunk in chunks:
            if chunk.stream == "stdout":
                stdout_parts.append(chunk.content)
            else:
                stderr_parts.append(chunk.content)
        return ("".join(stdout_parts), "".join(stderr_parts))

    @staticmethod
    def _chunk_to_dict(chunk: OutputChunk) -> dict[str, Any]:
        return {
            "cursor": chunk.cursor,
            "stream": chunk.stream,
            "content": chunk.content,
            "created_at": chunk.created_at,
        }

    @staticmethod
    def _fact_to_dict(
        fact: ExecutionFact,
        *,
        include_output: bool,
        output_preview_chars: int,
    ) -> dict[str, Any]:
        item: dict[str, Any] = {
            "exec_id": fact.exec_id,
            "status": fact.status.value,
            "exit_code": fact.exit_code,
            "raw_command": fact.raw_command,
            "executor_kind": fact.executor_kind,
            "created_at": fact.created_at,
            "started_at": fact.started_at,
            "finished_at": fact.finished_at,
            "cwd_before": fact.cwd_before,
            "cwd_after": fact.cwd_after,
            "env_delta": fact.env_delta,
        }
        if include_output:
            item["stdout"] = SessionToolRuntime._trim_preview(
                fact.stdout,
                output_preview_chars,
            )
            item["stderr"] = SessionToolRuntime._trim_preview(
                fact.stderr,
                output_preview_chars,
            )
        return item

    @staticmethod
    def _trim_preview(content: str, max_chars: int) -> str:
        if max_chars == 0:
            return ""
        if len(content) <= max_chars:
            return content
        if max_chars <= 3:
            return content[:max_chars]
        return f"{content[: max_chars - 3]}..."

    @staticmethod
    def _optional_int(
        payload: Mapping[str, Any],
        key: str,
        *,
        default: int,
        minimum: int,
    ) -> int:
        raw = payload.get(key, default)
        if isinstance(raw, bool):
            raise ValueError(f"{key} must be an integer")
        value = int(raw)
        if value < minimum:
            raise ValueError(f"{key} must be >= {minimum}")
        return value

    @staticmethod
    def _optional_bool(
        payload: Mapping[str, Any],
        key: str,
        *,
        default: bool,
    ) -> bool:
        raw = payload.get(key, default)
        if isinstance(raw, bool):
            return raw
        raise ValueError(f"{key} must be a boolean")

    @staticmethod
    def _optional_string_list(
        payload: Mapping[str, Any],
        key: str,
    ) -> list[str] | None:
        raw = payload.get(key)
        if raw is None:
            return None
        if not isinstance(raw, list):
            raise ValueError(f"{key} must be a list of strings")
        values: list[str] = []
        for item in raw:
            if not isinstance(item, str):
                raise ValueError(f"{key} must be a list of strings")
            if item not in values:
                values.append(item)
        return values

    @staticmethod
    def _require_string(payload: Mapping[str, Any], key: str) -> str:
        raw = payload.get(key)
        if not isinstance(raw, str):
            raise ValueError(f"{key} must be a string")
        return raw

    @staticmethod
    def _error(tool_name: str, message: str) -> dict[str, Any]:
        return {
            "ok": False,
            "tool": tool_name,
            "error": message,
        }
