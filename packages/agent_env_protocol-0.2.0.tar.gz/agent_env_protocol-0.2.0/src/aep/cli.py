﻿"""Command-line interface for AEP profile/workspace/session workflows."""

from __future__ import annotations

import argparse
import asyncio
import json
import shutil
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Sequence

from aep.runtime.aep import AEP
from aep.profile import Profile
from aep.runtime.session.models import ExecutionStatus
from aep.capability.tool.mcp import MCPTransport


@dataclass(slots=True)
class CommandResult:
    status: ExecutionStatus
    exit_code: int | None
    stdout: str
    stderr: str


def cli() -> None:
    """Console-script entrypoint."""
    raise SystemExit(main())


def main(argv: Sequence[str] | None = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(list(argv) if argv is not None else None)

    try:
        if args.group == "index":
            return _cmd_index(args)
        if args.group == "tool":
            return _dispatch_tool(args)
        if args.group == "skill":
            return _dispatch_skill(args)
        if args.group == "library":
            return _dispatch_library(args)
        if args.group == "mcp":
            return _dispatch_mcp(args)
        if args.group == "shell":
            return _cmd_shell(args)
    except Exception as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    parser.error(f"Unsupported command group: {args.group}")
    return 2


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="aep",
        description="AEP CLI for tools/skills/library/MCP management and shell execution.",
    )
    groups = parser.add_subparsers(dest="group", required=True)

    # index
    index = groups.add_parser("index", help="Generate tools/skills/library indexes.")
    index.add_argument("--profile", required=True, help="Profile config directory path.")
    index.add_argument(
        "--library-chunk-size-lines",
        type=int,
        default=None,
        help="Override library index chunk size (lines per chunk).",
    )
    index.add_argument(
        "--library-max-summary-chars",
        type=int,
        default=None,
        help="Override library index summary max characters.",
    )

    # tool
    tool = groups.add_parser("tool", help="Manage tools.")
    tool_sub = tool.add_subparsers(dest="action", required=True)

    tool_add = tool_sub.add_parser("add", help="Add one Python tool file.")
    tool_add.add_argument("source", help="Path to tool source file.")
    tool_add.add_argument("--name", help="Optional target tool name.")
    tool_add.add_argument("--profile", required=True, help="Profile config directory path.")
    tool_add.add_argument(
        "--dep",
        action="append",
        default=[],
        help="Tool dependency, repeatable.",
    )

    tool_list = tool_sub.add_parser("list", help="List tools.")
    tool_list.add_argument("--profile", required=True, help="Profile config directory path.")

    tool_remove = tool_sub.add_parser("remove", help="Remove one tool.")
    tool_remove.add_argument("name", help="Tool name.")
    tool_remove.add_argument("--profile", required=True, help="Profile config directory path.")

    # skill
    skill = groups.add_parser("skill", help="Manage skills.")
    skill_sub = skill.add_subparsers(dest="action", required=True)

    skill_add = skill_sub.add_parser("add", help="Add one skill (directory or .md).")
    skill_add.add_argument("source", help="Path to skill source.")
    skill_add.add_argument("--name", help="Optional target skill name.")
    skill_add.add_argument("--profile", required=True, help="Profile config directory path.")
    skill_add.add_argument(
        "--dep",
        action="append",
        default=[],
        help="Skill dependency, repeatable.",
    )

    skill_list = skill_sub.add_parser("list", help="List skills.")
    skill_list.add_argument("--profile", required=True, help="Profile config directory path.")

    skill_remove = skill_sub.add_parser("remove", help="Remove one skill.")
    skill_remove.add_argument("name", help="Skill name.")
    skill_remove.add_argument("--profile", required=True, help="Profile config directory path.")

    # library
    library = groups.add_parser("library", help="Manage library documents.")
    library_sub = library.add_subparsers(dest="action", required=True)

    library_add = library_sub.add_parser("add", help="Add one library file.")
    library_add.add_argument("source", help="Path to library source file.")
    library_add.add_argument("--profile", required=True, help="Profile config directory path.")
    library_add.add_argument("--target-dir", help="Target sub-directory in library.")
    library_add.add_argument("--name", help="Optional target file name.")

    library_remove = library_sub.add_parser("remove", help="Remove one library file.")
    library_remove.add_argument(
        "name",
        help="Library relative path, file or directory (e.g. backend/auth).",
    )
    library_remove.add_argument("--profile", required=True, help="Profile config directory path.")

    # mcp
    mcp = groups.add_parser("mcp", help="Manage MCP servers.")
    mcp_sub = mcp.add_subparsers(dest="action", required=True)

    mcp_add = mcp_sub.add_parser("add", help="Add one MCP server from JSON config.")
    mcp_add.add_argument("jsonfilepath", help="Path to MCP config json.")
    mcp_add.add_argument("--name", help="Optional MCP server name override.")
    mcp_add.add_argument("--profile", required=True, help="Profile config directory path.")

    mcp_remove = mcp_sub.add_parser("remove", help="Remove one MCP server.")
    mcp_remove.add_argument("name", help="MCP server name.")
    mcp_remove.add_argument("--profile", required=True, help="Profile config directory path.")

    # shell
    shell = groups.add_parser("shell", help="Interactive session shell.")
    shell.add_argument("--profile", required=True, help="Profile config directory path.")
    shell.add_argument("--workspace", required=True, help="Workspace directory path.")
    shell.add_argument(
        "--timeout-ms",
        type=int,
        default=120_000,
        help="Per-command timeout in milliseconds.",
    )

    return parser


def _profile(path: str) -> Profile:
    return Profile(Path(path))


def _workspace(path: str) -> Path:
    workspace = Path(path)
    workspace.mkdir(parents=True, exist_ok=True)
    return workspace


def _cmd_index(args: argparse.Namespace) -> int:
    profile = _profile(args.profile)
    profile.index(
        library_chunk_size_lines=args.library_chunk_size_lines,
        library_max_summary_chars=args.library_max_summary_chars,
    )
    print(f"Indexed profile: {profile.config_dir}")
    return 0


def _dispatch_tool(args: argparse.Namespace) -> int:
    if args.action == "add":
        return _cmd_tool_add(args)
    if args.action == "list":
        return _cmd_tool_list(args)
    if args.action == "remove":
        return _cmd_tool_remove(args)
    raise ValueError(f"Unsupported tool action: {args.action}")


def _dispatch_skill(args: argparse.Namespace) -> int:
    if args.action == "add":
        return _cmd_skill_add(args)
    if args.action == "list":
        return _cmd_skill_list(args)
    if args.action == "remove":
        return _cmd_skill_remove(args)
    raise ValueError(f"Unsupported skill action: {args.action}")


def _dispatch_library(args: argparse.Namespace) -> int:
    if args.action == "add":
        return _cmd_library_add(args)
    if args.action == "remove":
        return _cmd_library_remove(args)
    raise ValueError(f"Unsupported library action: {args.action}")


def _dispatch_mcp(args: argparse.Namespace) -> int:
    if args.action == "add":
        return _cmd_mcp_add(args)
    if args.action == "remove":
        return _cmd_mcp_remove(args)
    raise ValueError(f"Unsupported mcp action: {args.action}")


def _cmd_tool_add(args: argparse.Namespace) -> int:
    profile = _profile(args.profile)
    added = profile.add_tool(
        source=args.source,
        name=args.name,
        dependencies=args.dep or None,
    )
    print(f"Added tool: {added}")
    return 0


def _cmd_tool_list(args: argparse.Namespace) -> int:
    profile = _profile(args.profile)
    names = profile.tools.list()
    if not names:
        print("(no tools)")
        return 0

    for name in names:
        config_path = profile.config.mcp_config_path(name) / "config.json"
        tag = " [mcp]" if config_path.exists() else ""
        print(f"{name}{tag}")
    return 0


def _cmd_tool_remove(args: argparse.Namespace) -> int:
    profile = _profile(args.profile)
    removed = profile.tools.remove(args.name)
    if not removed:
        print(f"Tool not found: {args.name}", file=sys.stderr)
        return 1
    print(f"Removed tool: {args.name}")
    return 0


def _cmd_skill_add(args: argparse.Namespace) -> int:
    profile = _profile(args.profile)
    added = profile.add_skill(
        source=args.source,
        name=args.name,
        dependencies=args.dep or None,
    )
    print(f"Added skill: {added}")
    return 0


def _cmd_skill_list(args: argparse.Namespace) -> int:
    profile = _profile(args.profile)
    names = profile.skills.list()
    if not names:
        print("(no skills)")
        return 0
    for name in names:
        print(name)
    return 0


def _cmd_skill_remove(args: argparse.Namespace) -> int:
    profile = _profile(args.profile)
    removed = profile.skills.remove(args.name)
    if not removed:
        print(f"Skill not found: {args.name}", file=sys.stderr)
        return 1
    print(f"Removed skill: {args.name}")
    return 0


def _cmd_library_add(args: argparse.Namespace) -> int:
    profile = _profile(args.profile)
    added = profile.add_library(
        source=args.source,
        name=args.name,
        target_dir=args.target_dir,
    )
    print(f"Added library file: {added}")
    return 0


def _cmd_library_remove(args: argparse.Namespace) -> int:
    profile = _profile(args.profile)
    if profile.library.remove(args.name):
        print(f"Removed library file: {args.name}")
        return 0

    target = _resolve_library_target(profile, args.name)
    library_root = profile.library.config.library_dir.resolve()
    if target == library_root:
        print("Refusing to remove library root directory.", file=sys.stderr)
        return 1

    if target.is_dir():
        shutil.rmtree(target)
        print(f"Removed library directory: {args.name}")
        return 0

    print(f"Library path not found: {args.name}", file=sys.stderr)
    return 1


def _resolve_library_target(profile: Profile, name: str) -> Path:
    relative = Path(name)
    if relative.is_absolute():
        raise ValueError("Library path must be relative")
    for part in relative.parts:
        if part in ("", "."):
            continue
        if part == "..":
            raise ValueError("Library path cannot contain '..'")

    library_root = profile.library.config.library_dir.resolve()
    target = (library_root / relative).resolve()
    if target != library_root and library_root not in target.parents:
        raise ValueError("Library path escapes profile library root")
    return target


def _cmd_mcp_add(args: argparse.Namespace) -> int:
    profile = _profile(args.profile)
    payload = _load_json(Path(args.jsonfilepath))

    name = args.name or _pick_str(payload, "name") or Path(args.jsonfilepath).stem

    transport_value = _pick_str(payload, "transport") or "stdio"
    transport = MCPTransport(transport_value)

    command, cmd_args = _parse_command_fields(payload)
    env = _as_str_dict(payload.get("env"), field="env")
    headers = _as_str_dict(payload.get("headers"), field="headers")
    url = _pick_str(payload, "url")

    added = profile.mcp.add(
        name,
        command=command,
        args=cmd_args,
        env=env,
        url=url,
        headers=headers,
        transport=transport,
    )
    print(f"Added mcp server: {name} -> {added}")
    return 0


def _cmd_mcp_remove(args: argparse.Namespace) -> int:
    profile = _profile(args.profile)
    removed = profile.mcp.remove(args.name)
    if not removed:
        print(f"MCP server not found: {args.name}", file=sys.stderr)
        return 1
    print(f"Removed mcp server: {args.name}")
    return 0


def _load_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("MCP json config must be an object")
    return data


def _pick_str(payload: dict[str, Any], key: str) -> str | None:
    value = payload.get(key)
    if value is None:
        return None
    if not isinstance(value, str):
        raise ValueError(f"Field '{key}' must be a string")
    return value


def _as_str_dict(value: Any, *, field: str) -> dict[str, str] | None:
    if value is None:
        return None
    if not isinstance(value, dict):
        raise ValueError(f"Field '{field}' must be an object")
    return {str(k): str(v) for k, v in value.items()}


def _parse_command_fields(payload: dict[str, Any]) -> tuple[str | None, list[str] | None]:
    command_field = payload.get("command")
    args_field = payload.get("args")

    if command_field is None:
        if args_field is not None:
            raise ValueError("Field 'args' requires field 'command'")
        return (None, None)

    if isinstance(command_field, list):
        if not command_field:
            raise ValueError("Field 'command' list cannot be empty")
        command = str(command_field[0])
        cmd_args = [str(item) for item in command_field[1:]]
        return (command, cmd_args)

    if isinstance(command_field, str):
        if args_field is None:
            return (command_field, None)
        if not isinstance(args_field, list):
            raise ValueError("Field 'args' must be a list")
        return (command_field, [str(item) for item in args_field])

    raise ValueError("Field 'command' must be a string or list")


def _cmd_shell(args: argparse.Namespace) -> int:
    profile = _profile(args.profile)
    workspace = _workspace(args.workspace)
    aep = AEP(profile, workspace=workspace)
    session = aep._ensure_session("cli")
    print("AEP interactive shell. Type 'exit' or 'quit' to leave.")

    last_code = 0
    try:
        while True:
            try:
                line = input("aep> ").strip()
            except EOFError:
                print()
                break
            except KeyboardInterrupt:
                print()
                continue

            if not line:
                continue
            if line in {"exit", "quit"}:
                break

            result = asyncio.run(
                _run_command(
                    session,
                    line,
                    timeout_ms=args.timeout_ms,
                )
            )
            _print_result(result)
            last_code = _result_exit_code(result)
    finally:
        aep.detach()

    return last_code


async def _run_command(
    session,
    command: str,
    *,
    timeout_ms: int = 120_000,
    page_limit: int = 512,
) -> CommandResult:
    run_result = await session.run(command)
    wait_result = await session.wait(run_result.exec_id, timeout_ms=timeout_ms)

    cursor = 0
    stdout_parts: list[str] = []
    stderr_parts: list[str] = []
    exit_code = wait_result.exit_code

    while True:
        out = await session.output(run_result.exec_id, cursor=cursor, limit=page_limit)
        for chunk in out.chunks:
            if chunk.stream == "stdout":
                stdout_parts.append(chunk.content)
            else:
                stderr_parts.append(chunk.content)
        next_cursor = out.next_cursor
        if next_cursor == cursor and not out.is_running:
            if exit_code is None:
                exit_code = out.exit_code
            break
        cursor = next_cursor

    return CommandResult(
        status=wait_result.status,
        exit_code=exit_code,
        stdout="".join(stdout_parts),
        stderr="".join(stderr_parts),
    )


def _print_result(result: CommandResult) -> None:
    if result.stdout:
        sys.stdout.write(result.stdout)
        if not result.stdout.endswith("\n"):
            sys.stdout.write("\n")
    if result.stderr:
        sys.stderr.write(result.stderr)
        if not result.stderr.endswith("\n"):
            sys.stderr.write("\n")


def _result_exit_code(result: CommandResult) -> int:
    if result.exit_code is not None:
        return int(result.exit_code)
    if result.status == ExecutionStatus.EXITED:
        return 0
    return 1
