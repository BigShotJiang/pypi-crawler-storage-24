﻿"""
AEPSession 测试
"""

import os
from pathlib import Path

import pytest

from aep import AEP, Profile
from aep.datamodels.session import ExecResult
from aep.runtime.session import AEPSession, ExecutionStatus
from tests.async_exec import run_command


@pytest.fixture
def session(tmp_path: Path) -> AEPSession:
    """创建测试 session"""
    # 创建配置
    config = Profile(tmp_path / "config")

    # 添加工具
    tool = tmp_path / "calc.py"
    tool.write_text('''"""
calc - 计算工具

Usage:
    tools run "tools.calc.add(a, b)"
"""

def add(a, b):
    """加法"""
    return a + b

def mul(a, b):
    """乘法"""
    return a * b
''')
    config.add_tool(tool)

    # 添加技能
    skill_dir = tmp_path / "greeter"
    skill_dir.mkdir()
    (skill_dir / "main.py").write_text("""
import sys
name = sys.argv[1] if len(sys.argv) > 1 else "World"
print(f"Hello, {name}!")
""")
    (skill_dir / "SKILL.md").write_text(
        """---
name: greeter
description: Says hello to a provided name.
---

# Greeter Skill

Says hello.
"""
    )
    config.add_skill(skill_dir)

    config.index()

    # 创建工作区
    workspace = tmp_path / "workspace"
    workspace.mkdir()

    aep = AEP(config, workspace=workspace)
    try:
        yield aep._ensure_session("test-session")
    finally:
        aep.detach()


class TestExecResult:
    """测试 ExecResult 数据类"""

    def test_default_values(self):
        """默认值"""
        result = ExecResult()

        assert result.stdout == ""
        assert result.stderr == ""
        assert result.return_code == 0

    def test_custom_values(self):
        """自定义值"""
        result = ExecResult(stdout="output", stderr="error", return_code=1)

        assert result.stdout == "output"
        assert result.stderr == "error"
        assert result.return_code == 1


class TestSessionExecBasic:
    """测试 exec 基本功能"""

    def test_exec_empty_command(self, session: AEPSession):
        """空命令"""
        result = run_command(session, "")

        assert result.return_code == 0

    def test_exec_returns_exec_result(self, session: AEPSession):
        """返回 ExecResult"""
        result = run_command(session, "echo test")

        assert isinstance(result, ExecResult)


class TestSessionToolsCommand:
    """测试 tools 命令"""

    def test_tools_list(self, session: AEPSession):
        """tools list 列出工具"""
        result = run_command(session, "tools list")

        assert result.return_code == 0
        assert "calc" in result.stdout

    def test_tools_info(self, session: AEPSession):
        """tools info 显示工具详情"""
        result = run_command(session, "tools info calc")

        assert result.return_code == 0
        assert "calc" in result.stdout.lower()

    def test_tools_info_nonexistent(self, session: AEPSession):
        """tools info 不存在的工具"""
        result = run_command(session, "tools info nonexistent")

        assert result.return_code == 1

    def test_tools_run_simple(self, session: AEPSession):
        """tools run 简单表达式"""
        result = run_command(session, 'tools run "1 + 2"')

        assert result.return_code == 0
        assert "3" in result.stdout

    def test_tools_run_tool_function(self, session: AEPSession):
        """tools run 调用工具函数"""
        result = run_command(session, 'tools run "tools.calc.add(10, 20)"')

        assert result.return_code == 0
        assert "30" in result.stdout

    def test_tools_run_tool_chaining(self, session: AEPSession):
        """tools run 工具链"""
        result = run_command(session, 'tools run "tools.calc.add(tools.calc.mul(2, 3), 4)"')

        assert result.return_code == 0
        assert "10" in result.stdout  # 2*3 + 4 = 10

    def test_tools_run_multiline(self, session: AEPSession):
        """tools run 多语句代码"""
        # 使用分号分隔多语句
        result = run_command(session, 
            'tools run "result = tools.calc.add(1, 2); print(result)"'
        )

        assert result.return_code == 0
        assert "3" in result.stdout

    def test_tools_run_with_json(self, session: AEPSession):
        """tools run 使用 json 模块"""
        result = run_command(session, "tools run \"json.dumps({'a': 1})\"")

        assert result.return_code == 0
        assert '"a"' in result.stdout

    def test_tools_run_error(self, session: AEPSession):
        """tools run 代码错误"""
        result = run_command(session, 'tools run "1/0"')

        assert result.return_code == 1
        assert "ZeroDivision" in result.stderr

    def test_tools_usage_help(self, session: AEPSession):
        """tools 无参数显示帮助"""
        result = run_command(session, "tools")

        assert result.return_code == 1
        assert "Usage" in result.stderr


class TestSessionSkillsCommand:
    """测试 skills 命令"""

    def test_skills_list(self, session: AEPSession):
        """skills list 列出技能"""
        result = run_command(session, "skills list")

        assert result.return_code == 0
        assert "greeter" in result.stdout

    def test_skills_info(self, session: AEPSession):
        """skills info 显示技能详情"""
        result = run_command(session, "skills info greeter")

        assert result.return_code == 0
        assert "Greeter" in result.stdout

    def test_skills_info_nonexistent(self, session: AEPSession):
        """skills info 不存在的技能"""
        result = run_command(session, "skills info nonexistent")

        assert result.return_code == 1

    def test_skills_run(self, session: AEPSession):
        """skills run 执行技能"""
        result = run_command(session, "skills run greeter/main.py")

        assert result.return_code == 0
        assert "Hello" in result.stdout

    def test_skills_run_with_args(self, session: AEPSession):
        """skills run 带参数"""
        result = run_command(session, "skills run greeter/main.py AEP")

        assert result.return_code == 0
        assert "Hello, AEP" in result.stdout

    @pytest.mark.skipif(os.name != "nt", reason="Windows path separator behavior")
    def test_skills_run_backslash_path(self, session: AEPSession):
        """skills run 支持 Windows 反斜杠路径"""
        result = run_command(session, "skills run greeter\\main.py AEP")

        assert result.return_code == 0
        assert "Hello, AEP" in result.stdout

    def test_skills_run_nonexistent(self, session: AEPSession):
        """skills run 不存在的技能"""
        result = run_command(session, "skills run nonexistent/main.py")

        assert result.return_code == 1


class TestSessionCdCommand:
    """测试 cd 命令"""

    def test_cd_to_subdir(self, session: AEPSession):
        """cd 到子目录"""
        # 创建子目录
        subdir = session.workspace / "subdir"
        subdir.mkdir()

        result = run_command(session, "cd subdir")

        assert result.return_code == 0
        assert session.cwd == subdir

    def test_cd_to_agent_dir(self, session: AEPSession):
        """cd 到 .agents 目录"""
        result = run_command(session, "cd .agents")

        assert result.return_code == 0
        assert ".agents" in str(session.cwd)

    def test_cd_nonexistent(self, session: AEPSession):
        """cd 到不存在的目录"""
        result = run_command(session, "cd nonexistent")

        assert result.return_code == 1

    def test_cd_no_args_returns_to_workspace(self, session: AEPSession):
        """cd 无参数回到 workspace"""
        # 先 cd 到子目录
        subdir = session.workspace / "subdir"
        subdir.mkdir()
        run_command(session, "cd subdir")

        # cd 无参数
        result = run_command(session, "cd")

        assert session.cwd == session.workspace

    def test_cd_keeps_logical_path_for_symlink_dirs(self, session: AEPSession):
        """在 .agents symlink 目录中 cd .. 应保持 workspace 逻辑路径"""
        result = run_command(session, "cd .agents/tools")
        assert result.return_code == 0
        assert session.cwd == session.workspace / ".agents" / "tools"

        result = run_command(session, "cd ../..")
        assert result.return_code == 0
        assert session.cwd == session.workspace

    def test_cd_outside_workspace_warns(self, session: AEPSession):
        """离开工作区时给出回到 workspace 的提示"""
        result = run_command(session, "cd ../../..")

        assert result.return_code == 0
        assert "outside the workspace" in result.stdout.lower()
        assert "run `cd`" in result.stdout.lower()

    @pytest.mark.skipif(os.name != "nt", reason="Windows absolute path parsing")
    def test_cd_windows_absolute_path(self, session: AEPSession):
        """cd 支持 Windows 绝对路径写法 C:\\..."""
        system_root = Path(os.environ.get("SystemRoot", r"C:\Windows"))
        if not system_root.exists():
            pytest.skip("SystemRoot path does not exist in test environment")

        result = run_command(session, f"cd {system_root}")

        assert result.return_code == 0
        assert "outside the workspace" in result.stdout.lower()
        assert os.path.normcase(str(session.cwd)) == os.path.normcase(str(system_root))


class TestSessionExportCommand:
    """测试 export 命令"""

    def test_export_sets_env(self, session: AEPSession):
        """export 设置环境变量"""
        result = run_command(session, "export MY_VAR=hello")

        assert result.return_code == 0
        assert session.env["MY_VAR"] == "hello"

    def test_export_multiple(self, session: AEPSession):
        """export 多个变量"""
        result = run_command(session, "export A=1 B=2")

        assert session.env["A"] == "1"
        assert session.env["B"] == "2"

    def test_export_no_args_lists_env(self, session: AEPSession):
        """export 无参数列出变量"""
        session.env["TEST"] = "value"

        result = run_command(session, "export")

        assert "TEST=value" in result.stdout


class TestSessionShellPassthrough:
    """测试 shell 透传"""

    def test_echo(self, session: AEPSession):
        """echo 命令"""
        result = run_command(session, "echo hello world")

        assert result.return_code == 0
        assert "hello" in result.stdout.lower()
        assert "world" in result.stdout.lower()

    def test_dir_agent(self, session: AEPSession):
        """dir .agents"""
        result = run_command(session, "dir .agents")

        assert result.return_code == 0
        assert "tools" in result.stdout or "tools" in result.stdout.lower()

    def test_pwd_after_cd(self, session: AEPSession):
        """cd 后 pwd 显示新目录"""
        subdir = session.workspace / "mydir"
        subdir.mkdir()

        run_command(session, "cd mydir")
        result = run_command(session, "cd")  # 在 Windows 上 cd 无参数相当于 pwd

        # cwd 应该已更新
        assert "mydir" in str(session.cwd) or session.cwd == session.workspace


class TestSessionBuildContext:
    """测试 build_context 方法"""

    def test_build_context_includes_tools(self, session: AEPSession):
        """上下文包含工具索引"""
        aep = AEP(session.config, workspace=session.workspace)
        try:
            context = aep.build_context()
            assert "calc" in context
        finally:
            aep.detach()

    def test_build_context_includes_skills(self, session: AEPSession):
        """上下文包含技能索引"""
        aep = AEP(session.config, workspace=session.workspace)
        try:
            context = aep.build_context()
            assert "greeter" in context
        finally:
            aep.detach()

    def test_build_context_includes_environment_guide(self, session: AEPSession):
        """上下文包含环境指南"""
        aep = AEP(session.config, workspace=session.workspace)
        try:
            context = aep.build_context()
            assert "# AEP Agent Context" in context
            assert "## Exposed Tool Schemas" in context
            assert "tools run PY<<" in context
        finally:
            aep.detach()


class TestSessionCommandRegistry:
    """测试命令分发注册表"""

    def test_register_custom_command_handler(self, session: AEPSession):
        """可注册自定义命令处理器"""

        async def _hello_handler(
            _session: AEPSession,
            state,
            args: list[str],
            _raw_tools_run_arg: str | None,
        ) -> None:
            await state.append_output("stdout", f"hello {' '.join(args)}")
            state.finalize(ExecutionStatus.EXITED, 0)

        session._command_executor.register_handler("hello", _hello_handler)
        result = run_command(session, "hello world")

        assert result.return_code == 0
        assert "hello world" in result.stdout.lower()



