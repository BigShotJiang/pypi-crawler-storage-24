﻿"""CLI tests for grouped tool/skill/library/mcp/shell commands."""

from __future__ import annotations

import json
import sys
from pathlib import Path

from aep.cli import main


def _write_skill_dir(root: Path, name: str = "greeter") -> Path:
    skill_dir = root / name
    skill_dir.mkdir()
    (skill_dir / "main.py").write_text(
        "print('hello skill')\n",
        encoding="utf-8",
    )
    (skill_dir / "SKILL.md").write_text(
        """---
name: greeter
description: test greeter skill.
---

# Greeter
""",
        encoding="utf-8",
    )
    return skill_dir


def test_cli_index_generates_indexes(tmp_path: Path) -> None:
    profile = tmp_path / "profile"
    tool_src = tmp_path / "calc.py"
    tool_src.write_text("def add(a, b):\n    return a + b\n", encoding="utf-8")
    skill_dir = _write_skill_dir(tmp_path)
    doc = tmp_path / "guide.md"
    doc.write_text("# Guide\n", encoding="utf-8")

    assert (
        main(
            [
                "tool",
                "add",
                str(tool_src),
                "--name",
                "calc",
                "--profile",
                str(profile),
            ]
        )
        == 0
    )
    assert (
        main(
            [
                "skill",
                "add",
                str(skill_dir),
                "--name",
                "greeter",
                "--profile",
                str(profile),
            ]
        )
        == 0
    )
    assert (
        main(
            [
                "library",
                "add",
                str(doc),
                "--profile",
                str(profile),
            ]
        )
        == 0
    )

    assert main(["index", "--profile", str(profile)]) == 0
    assert (profile / "tools" / "index.md").exists()
    assert (profile / "skills" / "index.md").exists()
    assert (profile / "library" / "index.md").exists()


def test_cli_index_library_tuning_options(tmp_path: Path) -> None:
    profile = tmp_path / "profile"
    doc = tmp_path / "guide.md"
    doc.write_text(
        "\n".join(
            [
                "# Very Long Heading For Testing",
                "line one extra text",
                "line two extra text",
                "line three extra text",
                "line four extra text",
            ]
        ),
        encoding="utf-8",
    )

    assert (
        main(
            [
                "library",
                "add",
                str(doc),
                "--profile",
                str(profile),
            ]
        )
        == 0
    )

    assert (
        main(
            [
                "index",
                "--profile",
                str(profile),
                "--library-chunk-size-lines",
                "2",
                "--library-max-summary-chars",
                "12",
            ]
        )
        == 0
    )

    content = (profile / "library" / "index.md").read_text(encoding="utf-8")
    assert "range: lines 1-2" in content
    assert "range: lines 3-4" in content
    assert "range: lines 5-5" in content
    assert "..." in content


def test_cli_tool_add_list_remove(tmp_path: Path, capsys) -> None:
    profile = tmp_path / "profile"
    tool_src = tmp_path / "calc.py"
    tool_src.write_text("def add(a, b):\n    return a + b\n", encoding="utf-8")

    assert (
        main([
            "tool",
            "add",
            str(tool_src),
            "--name",
            "calc",
            "--profile",
            str(profile),
        ])
        == 0
    )

    capsys.readouterr()
    assert main(["tool", "list", "--profile", str(profile)]) == 0
    list_out = capsys.readouterr().out
    assert "calc" in list_out

    assert main(["tool", "remove", "calc", "--profile", str(profile)]) == 0
    assert main(["tool", "remove", "calc", "--profile", str(profile)]) == 1


def test_cli_skill_add_list_remove(tmp_path: Path, capsys) -> None:
    profile = tmp_path / "profile"
    skill_dir = _write_skill_dir(tmp_path)

    assert (
        main(
            [
                "skill",
                "add",
                str(skill_dir),
                "--name",
                "greeter",
                "--profile",
                str(profile),
            ]
        )
        == 0
    )

    capsys.readouterr()
    assert main(["skill", "list", "--profile", str(profile)]) == 0
    out = capsys.readouterr().out
    assert "greeter" in out

    assert main(["skill", "remove", "greeter", "--profile", str(profile)]) == 0
    assert main(["skill", "remove", "greeter", "--profile", str(profile)]) == 1


def test_cli_library_add_remove(tmp_path: Path, capsys) -> None:
    profile = tmp_path / "profile"
    doc = tmp_path / "guide.md"
    doc.write_text("# Guide\n", encoding="utf-8")

    assert (
        main(
            [
                "library",
                "add",
                str(doc),
                "--target-dir",
                "backend/auth",
                "--profile",
                str(profile),
            ]
        )
        == 0
    )

    rel_path = "backend/auth/guide.md"
    assert main(["library", "remove", rel_path, "--profile", str(profile)]) == 0
    assert main(["library", "remove", rel_path, "--profile", str(profile)]) == 1


def test_cli_library_remove_directory(tmp_path: Path, capsys) -> None:
    profile = tmp_path / "profile"
    doc1 = tmp_path / "a.md"
    doc2 = tmp_path / "b.md"
    doc1.write_text("# A\\n", encoding="utf-8")
    doc2.write_text("# B\\n", encoding="utf-8")

    assert (
        main(
            [
                "library",
                "add",
                str(doc1),
                "--target-dir",
                "backend/auth",
                "--profile",
                str(profile),
            ]
        )
        == 0
    )
    assert (
        main(
            [
                "library",
                "add",
                str(doc2),
                "--target-dir",
                "backend/auth",
                "--name",
                "b.md",
                "--profile",
                str(profile),
            ]
        )
        == 0
    )

    assert main(["library", "remove", "backend/auth", "--profile", str(profile)]) == 0


def test_cli_library_remove_root_blocked(tmp_path: Path) -> None:
    profile = tmp_path / "profile"
    doc = tmp_path / "guide.md"
    doc.write_text("# Guide\n", encoding="utf-8")

    assert (
        main(
            [
                "library",
                "add",
                str(doc),
                "--profile",
                str(profile),
            ]
        )
        == 0
    )

    assert main(["library", "remove", ".", "--profile", str(profile)]) == 1
    assert (profile / "library").is_dir()
    assert (profile / "library" / "guide.md").exists()


def test_cli_mcp_add_list_tag_remove(tmp_path: Path, capsys) -> None:
    profile = tmp_path / "profile"
    echo_server = Path(__file__).parent / "mcp" / "echo_server.py"

    mcp_json = tmp_path / "echo_mcp.json"
    mcp_json.write_text(
        json.dumps(
            {
                "name": "echo_mcp",
                "transport": "stdio",
                "command": sys.executable,
                "args": [str(echo_server)],
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    assert (
        main(
            [
                "mcp",
                "add",
                str(mcp_json),
                "--profile",
                str(profile),
            ]
        )
        == 0
    )

    capsys.readouterr()
    assert main(["tool", "list", "--profile", str(profile)]) == 0
    out = capsys.readouterr().out
    assert "echo_mcp [mcp]" in out

    assert main(["mcp", "remove", "echo_mcp", "--profile", str(profile)]) == 0
    assert main(["mcp", "remove", "echo_mcp", "--profile", str(profile)]) == 1
