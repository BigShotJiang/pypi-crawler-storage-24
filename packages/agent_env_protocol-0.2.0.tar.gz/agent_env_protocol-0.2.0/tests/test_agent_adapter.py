"""Tests for session-bound tool schemas and host-side tool dispatch."""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

import pytest

from aep import AEP, Profile


@pytest.fixture
def aep_instance(tmp_path: Path) -> AEP:
    profile = Profile(tmp_path / "config")
    profile.index()

    workspace = tmp_path / "workspace"
    workspace.mkdir()
    return AEP(profile, workspace=workspace)


def _python_cmd(code: str) -> str:
    exe = str(Path(sys.executable))
    return f'"{exe}" -c "{code}"'


def test_tool_schemas_expose_five_tools(aep_instance: AEP) -> None:
    try:
        binding = aep_instance.tool_schemas("agent-1")
        names = [tool["function"]["name"] for tool in binding.schemas]
        assert names == ["aep_exec", "aep_output", "aep_kill", "aep_history", "aep_env"]
    finally:
        aep_instance.detach()


def test_aep_exec_schema_describes_tools_run_workflows(aep_instance: AEP) -> None:
    try:
        binding = aep_instance.tool_schemas("agent-1")
        aep_exec = next(
            tool for tool in binding.schemas if tool["function"]["name"] == "aep_exec"
        )
        description = aep_exec["function"]["description"]
        command_description = aep_exec["function"]["parameters"]["properties"]["command"][
            "description"
        ]

        assert "tools run" in description
        assert "tools run" in command_description
        assert "print(tools.calc.add(1, 2))" in command_description
        assert "tools run PY<<" in command_description
    finally:
        aep_instance.detach()


def test_aep_exec_returns_terminal_result(aep_instance: AEP) -> None:
    try:
        result = asyncio.run(
            aep_instance.call_tool(
                "agent-1",
                "aep_exec",
                {"command": "echo binding-ok"},
            )
        )

        assert result["ok"] is True
        assert result["tool"] == "aep_exec"
        assert result["status"] == "exited"
        assert result["is_running"] is False
        assert result["timed_out"] is False
        assert result["exit_code"] == 0
        assert "binding-ok" in result["stdout"].lower()
    finally:
        aep_instance.detach()


def test_aep_exec_timeout_then_kill(aep_instance: AEP) -> None:
    command = _python_cmd("import time; print('start', flush=True); time.sleep(5)")

    async def _main() -> None:
        exec_result = await aep_instance.call_tool(
            "agent-1",
            "aep_exec",
            {
                "command": command,
                "timeout_ms": 30,
            },
        )

        assert exec_result["ok"] is True
        assert exec_result["tool"] == "aep_exec"
        assert exec_result["status"] in {"queued", "running"}
        assert exec_result["timed_out"] is True
        assert exec_result["is_running"] is True
        exec_id = exec_result["exec_id"]

        polled = await aep_instance.call_tool(
            "agent-1",
            "aep_output",
            {
                "exec_id": exec_id,
                "cursor": exec_result["next_cursor"],
            },
        )
        assert polled["ok"] is True
        assert polled["tool"] == "aep_output"

        killed = await aep_instance.call_tool(
            "agent-1",
            "aep_kill",
            {
                "exec_id": exec_id,
                "cursor": polled["next_cursor"],
            },
        )
        assert killed["ok"] is True
        assert killed["tool"] == "aep_kill"
        assert killed["status"] == "killed"
        assert killed["is_running"] is False

    try:
        asyncio.run(_main())
    finally:
        aep_instance.detach()


def test_unknown_tool_returns_error(aep_instance: AEP) -> None:
    try:
        result = asyncio.run(aep_instance.call_tool("agent-1", "aep_missing", {}))
        assert result["ok"] is False
        assert "Unknown tool" in result["error"]
    finally:
        aep_instance.detach()


def test_aep_history_returns_recent_records(aep_instance: AEP) -> None:
    async def _main() -> None:
        await aep_instance.call_tool("agent-1", "aep_exec", {"command": "echo first"})
        await aep_instance.call_tool("agent-1", "aep_exec", {"command": "echo second"})

        history = await aep_instance.call_tool(
            "agent-1",
            "aep_history",
            {"limit": 2, "include_output": True, "output_preview_chars": 80},
        )
        assert history["ok"] is True
        assert history["tool"] == "aep_history"
        assert history["count"] == 2
        assert len(history["items"]) == 2
        assert history["items"][0]["raw_command"] == "echo second"
        assert history["items"][1]["raw_command"] == "echo first"
        assert "stdout" in history["items"][0]

    try:
        asyncio.run(_main())
    finally:
        aep_instance.detach()


def test_aep_env_reads_current_custom_env(aep_instance: AEP) -> None:
    async def _main() -> None:
        await aep_instance.call_tool("agent-1", "aep_exec", {"command": "export A=1 B=2"})

        env_all = await aep_instance.call_tool("agent-1", "aep_env", {})
        assert env_all["ok"] is True
        assert env_all["env"]["A"] == "1"
        assert env_all["env"]["B"] == "2"

        env_partial = await aep_instance.call_tool(
            "agent-1",
            "aep_env",
            {"keys": ["A", "MISSING"]},
        )
        assert env_partial["ok"] is True
        assert env_partial["env"] == {"A": "1"}
        assert env_partial["missing"] == ["MISSING"]

    try:
        asyncio.run(_main())
    finally:
        aep_instance.detach()
