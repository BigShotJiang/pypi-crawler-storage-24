"""Tests for the public AEP runtime facade."""

from __future__ import annotations

import asyncio
from pathlib import Path

import pytest

from aep import AEP, Profile, ToolSchemaBinding


@pytest.fixture
def config(tmp_path: Path) -> Profile:
    profile = Profile(tmp_path / "config")
    tool = tmp_path / "calc.py"
    tool.write_text('"""calc"""\ndef add(a, b): return a + b\n', encoding="utf-8")
    profile.add_tool(tool)
    profile.index()
    return profile


@pytest.fixture
def workspace(tmp_path: Path) -> Path:
    ws = tmp_path / "workspace"
    ws.mkdir()
    return ws


class TestAEPAttach:
    def test_init_creates_agent_dir(self, workspace: Path, config: Profile) -> None:
        aep = AEP(config, workspace=workspace)
        try:
            assert (workspace / ".agents").exists()
        finally:
            aep.detach()

    def test_init_creates_symlinks(self, workspace: Path, config: Profile) -> None:
        aep = AEP(config, workspace=workspace)
        try:
            agent_dir = workspace / ".agents"
            assert (agent_dir / "tools").exists()
            assert (agent_dir / "skills").exists()
            assert (agent_dir / "library").exists()
        finally:
            aep.detach()

    def test_symlink_points_to_config(self, workspace: Path, config: Profile) -> None:
        aep = AEP(config, workspace=workspace)
        try:
            assert (workspace / ".agents" / "tools" / "calc.py").exists()
        finally:
            aep.detach()

    def test_supports_string_paths(self, workspace: Path, config: Profile) -> None:
        aep = AEP(str(config.config_dir), workspace=str(workspace))
        try:
            assert aep.workspace == workspace.resolve()
            assert aep.profile.config_dir == config.config_dir
        finally:
            aep.detach()


class TestAEPTools:
    def test_tool_schemas_returns_binding(self, workspace: Path, config: Profile) -> None:
        aep = AEP(config, workspace=workspace)
        try:
            binding = aep.tool_schemas("agent-1")
            assert isinstance(binding, ToolSchemaBinding)
            assert binding.session_id == "agent-1"
            assert [tool["function"]["name"] for tool in binding.schemas] == [
                "aep_exec",
                "aep_output",
                "aep_kill",
                "aep_history",
                "aep_env",
            ]
        finally:
            aep.detach()

    def test_build_context_includes_indexes_and_commands(
        self,
        workspace: Path,
        config: Profile,
    ) -> None:
        aep = AEP(config, workspace=workspace)
        try:
            context = aep.build_context()
            assert "# AEP Agent Context" in context
            assert "tools run" in context
            assert "skills run" in context
            assert "calc" in context
        finally:
            aep.detach()

    def test_sessions_are_isolated_by_session_id(
        self,
        workspace: Path,
        config: Profile,
    ) -> None:
        aep = AEP(config, workspace=workspace)

        async def _main() -> None:
            await aep.call_tool("agent-1", "aep_exec", {"command": "export A=1"})
            await aep.call_tool("agent-2", "aep_exec", {"command": "export B=2"})

            env1 = await aep.call_tool("agent-1", "aep_env", {})
            env2 = await aep.call_tool("agent-2", "aep_env", {})

            assert env1["env"] == {"A": "1"}
            assert env2["env"] == {"B": "2"}

        try:
            asyncio.run(_main())
        finally:
            aep.detach()


class TestAEPDetach:
    def test_detach_removes_symlinks(self, workspace: Path, config: Profile) -> None:
        aep = AEP(config, workspace=workspace)
        aep.detach()

        agent_dir = workspace / ".agents"
        assert not (agent_dir / "tools").exists()
        assert not (agent_dir / "skills").exists()
        assert not (agent_dir / "library").exists()
