"""
MCPHandler integration tests.

Use tests/mcp/echo_server.py as the real MCP server.
"""

import asyncio
import sys
from pathlib import Path

import pytest

from aep import Profile
from aep.capability.tool.mcp.handler import MCPHandler
from aep.capability.tool.mcp.stubgen import build_connect_code, build_http_connect_code
from aep.capability.tool.mcp.transport import MCPTransport
from aep.datamodels.config import MCPServerConfig

ECHO_SERVER = str(Path(__file__).parent.parent / "mcp" / "echo_server.py")


class TestMCPAddStdio:
    @pytest.fixture
    def manager(self, tmp_path: Path) -> Profile:
        return Profile(tmp_path / "config")

    @pytest.fixture
    def handler(self, manager: Profile) -> MCPHandler:
        return manager.mcp

    def test_add_discovers_tools(self, handler: MCPHandler) -> None:
        stub = handler.add(
            "echo",
            command=sys.executable,
            args=[ECHO_SERVER],
        )

        assert stub.exists()
        assert stub.name == "echo.py"
        content = stub.read_text(encoding="utf-8")
        assert "def echo(" in content
        assert "def add(" in content

    def test_no_manifest_generated(self, handler: MCPHandler) -> None:
        handler.add(
            "echo",
            command=sys.executable,
            args=[ECHO_SERVER],
        )

        config_dir = handler.config.mcp_config_path("echo")
        assert not (config_dir / "manifest.json").exists()

    def test_stub_contains_tool_functions(self, handler: MCPHandler) -> None:
        stub = handler.add(
            "echo",
            command=sys.executable,
            args=[ECHO_SERVER],
        )

        content = stub.read_text(encoding="utf-8")

        assert "def echo(" in content
        assert "def add(" in content
        assert "def call(" in content
        assert "from mcp import ClientSession" in content

    def test_stub_has_correct_params(self, handler: MCPHandler) -> None:
        stub = handler.add(
            "echo",
            command=sys.executable,
            args=[ECHO_SERVER],
        )

        content = stub.read_text(encoding="utf-8")

        assert "message" in content
        assert "a: int" in content
        assert "b: int" in content

    def test_config_saved(self, handler: MCPHandler) -> None:
        handler.add(
            "echo",
            command=sys.executable,
            args=[ECHO_SERVER],
        )

        config = handler.get_config("echo")
        assert config is not None
        assert config.transport == "stdio"
        assert config.command[0] == sys.executable
        assert ECHO_SERVER in config.command

    def test_no_prompt_docs_generated(self, handler: MCPHandler, manager: Profile) -> None:
        handler.add(
            "echo",
            command=sys.executable,
            args=[ECHO_SERVER],
        )

        skill_dir = manager.config.skills_dir / "echo"
        skill_md = skill_dir / "SKILL.md"
        assert not skill_md.exists()


class TestMCPList:
    @pytest.fixture
    def handler(self, tmp_path: Path) -> MCPHandler:
        manager = Profile(tmp_path / "config")
        return manager.mcp

    def test_list_empty(self, handler: MCPHandler) -> None:
        assert handler.list() == []

    def test_list_after_add(self, handler: MCPHandler) -> None:
        handler.add(
            "echo",
            command=sys.executable,
            args=[ECHO_SERVER],
        )

        servers = handler.list()
        assert "echo" in servers

    def test_list_multiple(self, handler: MCPHandler) -> None:
        handler.add("echo1", command=sys.executable, args=[ECHO_SERVER])
        handler.add("echo2", command=sys.executable, args=[ECHO_SERVER])

        servers = handler.list()
        assert "echo1" in servers
        assert "echo2" in servers


class TestMCPRemove:
    @pytest.fixture
    def manager(self, tmp_path: Path) -> Profile:
        return Profile(tmp_path / "config")

    @pytest.fixture
    def handler(self, manager: Profile) -> MCPHandler:
        return manager.mcp

    def test_remove_cleans_stub(self, handler: MCPHandler, manager: Profile) -> None:
        handler.add("echo", command=sys.executable, args=[ECHO_SERVER])

        stub = manager.config.tool_path("echo")
        assert stub.exists()

        handler.remove("echo")
        assert not stub.exists()

    def test_remove_cleans_config(self, handler: MCPHandler, manager: Profile) -> None:
        handler.add("echo", command=sys.executable, args=[ECHO_SERVER])

        config_dir = manager.config.mcp_config_path("echo")
        assert config_dir.exists()

        handler.remove("echo")
        assert not config_dir.exists()

    def test_remove_keeps_skills_untouched(self, handler: MCPHandler, manager: Profile) -> None:
        handler.add("echo", command=sys.executable, args=[ECHO_SERVER])

        skill_dir = manager.config.skills_dir / "echo"
        assert not skill_dir.exists()

        handler.remove("echo")
        assert not skill_dir.exists()

    def test_remove_nonexistent(self, handler: MCPHandler) -> None:
        assert handler.remove("nonexistent") is False

    def test_remove_unlists(self, handler: MCPHandler) -> None:
        handler.add("echo", command=sys.executable, args=[ECHO_SERVER])
        assert "echo" in handler.list()

        handler.remove("echo")
        assert "echo" not in handler.list()


class TestMCPRefresh:
    @pytest.fixture
    def handler(self, tmp_path: Path) -> MCPHandler:
        manager = Profile(tmp_path / "config")
        return manager.mcp

    def test_refresh_regenerates_stub(self, handler: MCPHandler) -> None:
        handler.add("echo", command=sys.executable, args=[ECHO_SERVER])

        stub = handler.refresh("echo")
        assert stub.exists()
        content = stub.read_text(encoding="utf-8")
        assert "def echo(" in content

    def test_refresh_nonexistent_raises(self, handler: MCPHandler) -> None:
        with pytest.raises(FileNotFoundError):
            handler.refresh("nonexistent")


class TestMCPValidation:
    @pytest.fixture
    def handler(self, tmp_path: Path) -> MCPHandler:
        manager = Profile(tmp_path / "config")
        return manager.mcp

    def test_stdio_requires_command(self, handler: MCPHandler) -> None:
        with pytest.raises(ValueError, match="command"):
            handler.add("test", transport=MCPTransport.STDIO)

    def test_http_requires_url(self, handler: MCPHandler) -> None:
        with pytest.raises(ValueError, match="url"):
            handler.add("test", transport=MCPTransport.HTTP)

    def test_command_not_found_raises(self, handler: MCPHandler) -> None:
        with pytest.raises(RuntimeError, match="Command not found"):
            handler.add("test", command="nonexistent_cmd_xyz_12345")

    def test_sync_add_in_running_loop_raises(self, handler: MCPHandler) -> None:
        async def _run() -> None:
            with pytest.raises(RuntimeError, match="running event loop"):
                handler.add("echo", command=sys.executable, args=[ECHO_SERVER])

        asyncio.run(_run())


class TestMCPHTTPConnectCode:
    def test_http_connect_code_uses_http_client_for_headers(self) -> None:
        config = MCPServerConfig(
            name="remote",
            transport="http",
            url="http://localhost:8000/mcp",
            headers={"Authorization": "Bearer token"},
        )

        connect_code = build_http_connect_code(config)

        assert "import httpx" in connect_code
        assert "httpx.AsyncClient(headers=_MCP_HEADERS or None)" in connect_code
        assert "streamable_http_client(_MCP_URL, http_client=http_client)" in connect_code
        assert "streamable_http_client(_MCP_URL, headers=" not in connect_code

    def test_build_connect_code_dispatches_by_transport(self) -> None:
        stdio_config = MCPServerConfig(
            name="echo",
            transport="stdio",
            command=[sys.executable, ECHO_SERVER],
        )
        http_config = MCPServerConfig(
            name="remote",
            transport="http",
            url="http://localhost:8000/mcp",
        )

        stdio_code = build_connect_code(MCPTransport.STDIO, stdio_config)
        http_code = build_connect_code(MCPTransport.HTTP, http_config)

        assert "stdio_client" in stdio_code
        assert "streamable_http_client" in http_code
