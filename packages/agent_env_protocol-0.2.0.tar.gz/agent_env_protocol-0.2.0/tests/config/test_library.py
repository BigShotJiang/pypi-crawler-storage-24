"""LibraryHandler tests."""

from pathlib import Path

import pytest

from aep import Profile


class TestLibraryHandler:
    """Test LibraryHandler."""

    @pytest.fixture
    def manager(self, tmp_path: Path) -> Profile:
        return Profile(tmp_path / "config")

    @pytest.fixture
    def sample_doc(self, tmp_path: Path) -> Path:
        doc = tmp_path / "api.md"
        doc.write_text("# API Documentation\n\nSome content here.", encoding="utf-8")
        return doc

    def test_add_library_copies_file(self, manager: Profile, sample_doc: Path) -> None:
        result = manager.library.add(sample_doc)

        assert result.exists()
        assert result.name == "api.md"
        assert result.parent == manager.config.library_dir

    def test_add_library_with_custom_name(self, manager: Profile, sample_doc: Path) -> None:
        result = manager.library.add(sample_doc, name="docs.md")
        assert result.name == "docs.md"

    def test_add_library_with_target_dir(self, manager: Profile, sample_doc: Path) -> None:
        result = manager.library.add(sample_doc, target_dir="backend/auth")

        assert result.exists()
        assert result == manager.config.library_dir / "backend" / "auth" / "api.md"

    def test_list_library_recursive(self, manager: Profile, sample_doc: Path) -> None:
        manager.library.add(sample_doc)
        manager.library.add(sample_doc, name="nested.md", target_dir="backend/auth")

        files = manager.library.list()
        assert "api.md" in files
        assert "backend/auth/nested.md" in files

    def test_remove_library(self, manager: Profile, sample_doc: Path) -> None:
        manager.library.add(sample_doc, target_dir="backend/auth")

        assert manager.library.remove("backend/auth/api.md")
        assert "backend/auth/api.md" not in manager.library.list()

    def test_generate_index_recursive(self, manager: Profile, tmp_path: Path) -> None:
        root_doc = tmp_path / "root.md"
        root_doc.write_text("# Root\n\nRoot content.", encoding="utf-8")

        nested_doc = tmp_path / "nested.md"
        nested_doc.write_text(
            "# Nested\n\nFirst part\nSecond part\nThird part",
            encoding="utf-8",
        )

        manager.library.add(root_doc)
        manager.library.add(nested_doc, target_dir="folder/sub")
        manager.index()

        root_index = manager.config.library_dir / "index.md"
        folder_index = manager.config.library_dir / "folder" / "index.md"
        sub_index = manager.config.library_dir / "folder" / "sub" / "index.md"

        assert root_index.exists()
        assert folder_index.exists()
        assert sub_index.exists()

        root_content = root_index.read_text(encoding="utf-8")
        folder_content = folder_index.read_text(encoding="utf-8")
        sub_content = sub_index.read_text(encoding="utf-8")

        assert "name: library" in root_content
        assert "index_link: ./folder/index.md" in root_content
        assert "index_link: ./sub/index.md" in folder_content
        assert "name: nested.md | type: file" in sub_content
        assert "chunk_id: nested#c001" in sub_content

    def test_generate_index_with_custom_chunk_and_summary(
        self,
        manager: Profile,
        tmp_path: Path,
    ) -> None:
        doc = tmp_path / "long.md"
        doc.write_text(
            "\n".join(
                [
                    "# Very Long Heading For Testing",
                    "line one extra text",
                    "line two extra text",
                    "line three extra text",
                    "line four extra text",
                ]
            ),
            encoding="utf-8",
        )
        manager.library.add(doc)

        manager.library.generate_index(chunk_size_lines=2, max_summary_chars=12)
        content = (manager.config.library_dir / "index.md").read_text(encoding="utf-8")

        assert "range: lines 1-2" in content
        assert "range: lines 3-4" in content
        assert "range: lines 5-5" in content
        assert "..." in content

    def test_generate_index_rejects_invalid_tuning(self, manager: Profile) -> None:
        with pytest.raises(ValueError, match="chunk_size_lines"):
            manager.library.generate_index(chunk_size_lines=0)

        with pytest.raises(ValueError, match="max_summary_chars"):
            manager.library.generate_index(max_summary_chars=0)
