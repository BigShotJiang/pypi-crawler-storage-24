"""Tests for Profile initialization, indexing, and convenience methods."""

from pathlib import Path
from unittest.mock import patch

import pytest

from aep import Profile
from aep.capability.library.handler import LibraryHandler
from aep.capability.skill.handler import SkillsHandler
from aep.capability.tool.handler import ToolsHandler


class TestEnvManagerInit:
    """Profile initialization behavior."""

    def test_init_creates_directories(self, tmp_path: Path) -> None:
        config_dir = tmp_path / "config"
        manager = Profile(config_dir)

        assert config_dir.exists()
        assert manager.config.tools_dir.exists()
        assert manager.config.skills_dir.exists()
        assert manager.config.library_dir.exists()
        assert manager.config.mcp_config_dir.exists()

    def test_init_with_existing_dir(self, tmp_path: Path) -> None:
        config_dir = tmp_path / "config"
        config_dir.mkdir()

        manager = Profile(config_dir)
        assert manager.config.config_dir == config_dir.resolve()

    def test_handlers_accessible(self, tmp_path: Path) -> None:
        manager = Profile(tmp_path / "config")

        assert isinstance(manager.tools, ToolsHandler)
        assert isinstance(manager.skills, SkillsHandler)
        assert isinstance(manager.library, LibraryHandler)


class TestEnvManagerIndex:
    """Profile.index() behavior."""

    @pytest.fixture
    def manager_with_content(self, tmp_path: Path) -> Profile:
        manager = Profile(tmp_path / "config")

        tool = tmp_path / "grep.py"
        tool.write_text('"""grep tool"""\ndef search(): pass', encoding="utf-8")
        manager.tools.add(tool)

        skill = tmp_path / "scraper"
        skill.mkdir()
        (skill / "main.py").write_text('print("scrape")', encoding="utf-8")
        (skill / "SKILL.md").write_text(
            """---
name: scraper
description: Scrape content from test pages.
---
""",
            encoding="utf-8",
        )
        manager.skills.add(skill)

        doc = tmp_path / "readme.md"
        doc.write_text("# README", encoding="utf-8")
        manager.library.add(doc)

        return manager

    def test_index_creates_tools_index(self, manager_with_content: Profile) -> None:
        manager_with_content.index()

        index = manager_with_content.config.tools_dir / "index.md"
        assert index.exists()
        content = index.read_text(encoding="utf-8")
        assert "grep" in content
        assert "requirements.txt" in content

    def test_tools_index_lists_shared_requirements(self, tmp_path: Path) -> None:
        manager = Profile(tmp_path / "config")

        tool = tmp_path / "grep.py"
        tool.write_text('"""grep tool"""\ndef search(): pass', encoding="utf-8")
        manager.tools.add(tool)

        with patch.object(manager.tools, "install_dependencies"):
            manager.add_tool_dependency("pandas", "requests>=2.0")

        manager.index()

        content = (manager.config.tools_dir / "index.md").read_text(encoding="utf-8")
        assert "requirements.txt" in content
        assert "pandas" in content
        assert "requests>=2.0" in content

    def test_index_creates_skills_index(self, manager_with_content: Profile) -> None:
        manager_with_content.index()

        index = manager_with_content.config.skills_dir / "index.md"
        assert index.exists()
        content = index.read_text(encoding="utf-8")
        assert "scraper" in content
        assert "Scrape content from test pages." in content
        assert "scraper/" in content

    def test_index_creates_library_index(self, manager_with_content: Profile) -> None:
        manager_with_content.index()

        index = manager_with_content.config.library_dir / "index.md"
        assert index.exists()
        content = index.read_text(encoding="utf-8")
        assert "readme.md" in content

    def test_index_forwards_library_index_tuning(
        self,
        manager_with_content: Profile,
    ) -> None:
        with patch.object(manager_with_content.library, "generate_index") as generate_index:
            manager_with_content.index(
                library_chunk_size_lines=12,
                library_max_summary_chars=34,
            )

        generate_index.assert_called_once_with(
            chunk_size_lines=12,
            max_summary_chars=34,
        )


class TestEnvManagerConvenienceMethods:
    """Convenience proxy methods on Profile."""

    @pytest.fixture
    def manager(self, tmp_path: Path) -> Profile:
        return Profile(tmp_path / "config")

    def test_add_tool_convenience(self, manager: Profile, tmp_path: Path) -> None:
        tool = tmp_path / "calc.py"
        tool.write_text("def add(a, b): return a + b", encoding="utf-8")

        result = manager.add_tool(tool)
        assert result.exists()

    def test_add_skill_convenience(self, manager: Profile, tmp_path: Path) -> None:
        skill = tmp_path / "analyzer.md"
        skill.write_text(
            """---
name: analyzer
description: Analyze data from markdown-only skill.
---

# Analyzer
""",
            encoding="utf-8",
        )

        result = manager.add_skill(skill)
        assert result.is_dir()

    def test_add_library_convenience(self, manager: Profile, tmp_path: Path) -> None:
        doc = tmp_path / "guide.md"
        doc.write_text("# Guide", encoding="utf-8")

        result = manager.add_library(doc)
        assert result.exists()

    def test_add_tool_dependency_convenience(self, manager: Profile) -> None:
        with patch.object(manager.tools, "install_dependencies"):
            result = manager.add_tool_dependency("aiohttp", "websockets>=10.0")

            assert result.exists()
            content = result.read_text(encoding="utf-8")
            assert "aiohttp" in content
            assert "websockets>=10.0" in content


class TestEnvManagerToolEnvironment:
    """tools runtime environment bootstrap behavior."""

    def test_init_tool_environment_with_defaults(self, tmp_path: Path) -> None:
        manager = Profile(tmp_path / "config")

        with patch.object(manager.tools, "ensure_venv"), patch.object(
            manager.tools,
            "install_dependencies",
        ):
            req = manager.init_tool_environment()

        content = req.read_text(encoding="utf-8")
        assert "numpy" in content
        assert "pandas" in content
        assert "matplotlib" in content
        assert "mcp" in content

    def test_init_tool_environment_with_custom_dependencies(self, tmp_path: Path) -> None:
        manager = Profile(tmp_path / "config")

        with patch.object(manager.tools, "ensure_venv"), patch.object(
            manager.tools,
            "install_dependencies",
        ):
            req = manager.init_tool_environment(
                dependencies=["seaborn", "numpy"],
                include_default=True,
            )

        lines = {
            line.strip()
            for line in req.read_text(encoding="utf-8").splitlines()
            if line.strip()
        }
        assert "seaborn" in lines
        assert "numpy" in lines
        assert len([x for x in lines if x == "numpy"]) == 1

    def test_auto_init_tool_env_calls_initializer(self, tmp_path: Path) -> None:
        with patch("aep.profile.Profile.init_tool_environment") as init_env:
            Profile(
                tmp_path / "config",
                auto_init_tool_env=True,
                include_default_tool_dependencies=False,
                tool_dependencies=["mcp"],
            )

        init_env.assert_called_once_with(
            dependencies=["mcp"],
            include_default=False,
        )


class TestEnvManagerLibraryTargetDir:
    """add_library convenience with target_dir."""

    @pytest.fixture
    def manager(self, tmp_path: Path) -> Profile:
        return Profile(tmp_path / "config")

    def test_add_library_convenience_with_target_dir(
        self,
        manager: Profile,
        tmp_path: Path,
    ) -> None:
        doc = tmp_path / "guide.md"
        doc.write_text("# Guide", encoding="utf-8")

        result = manager.add_library(doc, target_dir="guides/api")

        assert result.exists()
        assert result == manager.config.library_dir / "guides" / "api" / "guide.md"
