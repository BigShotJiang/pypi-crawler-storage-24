"""Tests for the reusable example agent runtime."""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from types import SimpleNamespace

EXAMPLE_AGENT_DIR = Path(__file__).resolve().parents[1] / "examples" / "example_agent"
if str(EXAMPLE_AGENT_DIR) not in sys.path:
    sys.path.insert(0, str(EXAMPLE_AGENT_DIR))

from agent_runtime import AgentEventHandler, OpenAIAEPAgent  # noqa: E402


def _chunk(
    *,
    content: str | None = None,
    reasoning: str | None = None,
    tool_calls: list[SimpleNamespace] | None = None,
) -> SimpleNamespace:
    delta = SimpleNamespace(
        content=content,
        reasoning_content=reasoning,
        reasoning=None,
        thinking_content=None,
        thinking=None,
        model_extra=None,
        tool_calls=tool_calls,
    )
    return SimpleNamespace(choices=[SimpleNamespace(delta=delta)])


class _FakeStream:
    def __init__(self, chunks: list[SimpleNamespace]) -> None:
        self._chunks = chunks
        self._index = 0

    def __aiter__(self) -> _FakeStream:
        return self

    async def __anext__(self) -> SimpleNamespace:
        if self._index >= len(self._chunks):
            raise StopAsyncIteration
        chunk = self._chunks[self._index]
        self._index += 1
        return chunk


class _FakeCompletions:
    def __init__(self, streams: list[list[SimpleNamespace]]) -> None:
        self._streams = list(streams)

    async def create(self, **_: object) -> _FakeStream:
        return _FakeStream(self._streams.pop(0))


class _FakeClient:
    def __init__(self, streams: list[list[SimpleNamespace]]) -> None:
        self.chat = SimpleNamespace(completions=_FakeCompletions(streams))


class _FakeAdapter:
    def __init__(self) -> None:
        self.calls: list[tuple[str, dict[str, object]]] = []

    async def call_tool(self, name: str, arguments: dict[str, object]) -> dict[str, object]:
        self.calls.append((name, arguments))
        return {"ok": True, "tool": name, "echo": arguments}


def _tool_schemas() -> list[dict[str, object]]:
    return [
        {
            "type": "function",
            "function": {
                "name": "demo_tool",
                "parameters": {"type": "object"},
            },
        }
    ]


class _RecordingHandler(AgentEventHandler):
    def __init__(self) -> None:
        self.reasoning: list[str] = []
        self.responses: list[str] = []
        self.tool_results: list[tuple[str, dict[str, object], dict[str, object]]] = []
        self.response_starts = 0
        self.response_ends = 0
        self.empty_responses = 0

    def on_reasoning_delta(self, text: str) -> None:
        self.reasoning.append(text)

    def on_response_start(self) -> None:
        self.response_starts += 1

    def on_response_delta(self, text: str) -> None:
        self.responses.append(text)

    def on_response_end(self) -> None:
        self.response_ends += 1

    def on_tool_result(
        self,
        *,
        tool_name: str,
        arguments: dict[str, object],
        result: dict[str, object],
    ) -> None:
        self.tool_results.append((tool_name, arguments, result))

    def on_empty_response(self) -> None:
        self.empty_responses += 1


def test_openai_aep_agent_runs_tool_loop_without_cli() -> None:
    tool_delta = SimpleNamespace(
        index=0,
        id="call_0",
        type="function",
        function=SimpleNamespace(name="demo_tool", arguments='{"value": 1}'),
    )
    client = _FakeClient(
        streams=[
            [
                _chunk(reasoning="plan"),
                _chunk(content="working "),
                _chunk(tool_calls=[tool_delta]),
            ],
            [
                _chunk(content="done"),
            ],
        ]
    )
    adapter = _FakeAdapter()
    handler = _RecordingHandler()
    agent = OpenAIAEPAgent(
        client=client,
        model="fake-model",
        tools=_tool_schemas(),
        call_tool=adapter.call_tool,
        system_prompt="system",
    )

    asyncio.run(agent.run_user_turn("hello", handler=handler))

    assert adapter.calls == [("demo_tool", {"value": 1})]
    assert handler.reasoning == ["plan"]
    assert "".join(handler.responses) == "working done"
    assert handler.response_starts == 2
    assert handler.response_ends == 2
    assert handler.empty_responses == 0

    messages = agent.messages
    assert [message["role"] for message in messages] == [
        "system",
        "user",
        "assistant",
        "tool",
        "assistant",
    ]
    assert messages[2]["tool_calls"][0]["function"]["name"] == "demo_tool"
    assert messages[3]["content"] == '{"ok": true, "tool": "demo_tool", "echo": {"value": 1}}'


def test_openai_aep_agent_reports_empty_response() -> None:
    client = _FakeClient(streams=[[SimpleNamespace(choices=[])]])
    handler = _RecordingHandler()
    agent = OpenAIAEPAgent(
        client=client,
        model="fake-model",
        tools=_tool_schemas(),
        call_tool=_FakeAdapter().call_tool,
        system_prompt="system",
    )

    asyncio.run(agent.run_user_turn("hello", handler=handler))

    assert handler.empty_responses == 1
