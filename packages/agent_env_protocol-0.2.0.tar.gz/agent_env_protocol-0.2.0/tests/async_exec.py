"""Test helper to run session commands via async lifecycle API."""

from __future__ import annotations

import asyncio

from aep.datamodels.session import ExecResult
from aep.runtime.session import AEPSession


def run_command(
    session: AEPSession,
    command: str,
    *,
    timeout_ms: int = 20_000,
    page_limit: int = 512,
) -> ExecResult:
    """Run one command through run/wait/output and return aggregated result."""

    async def _main() -> ExecResult:
        run_result = await session.run(command)
        exec_id = run_result.exec_id

        wait_result = await session.wait(exec_id, timeout_ms=timeout_ms)

        cursor = 0
        stdout_parts: list[str] = []
        stderr_parts: list[str] = []
        exit_code = wait_result.exit_code

        while True:
            out = await session.output(exec_id, cursor=cursor, limit=page_limit)
            for chunk in out.chunks:
                if chunk.stream == "stdout":
                    stdout_parts.append(chunk.content)
                else:
                    stderr_parts.append(chunk.content)

            next_cursor = out.next_cursor
            if next_cursor == cursor:
                if not out.is_running:
                    if exit_code is None:
                        exit_code = out.exit_code
                    break
            cursor = next_cursor

        return ExecResult(
            stdout="".join(stdout_parts),
            stderr="".join(stderr_parts),
            return_code=int(exit_code) if exit_code is not None else 0,
        )

    return asyncio.run(_main())
