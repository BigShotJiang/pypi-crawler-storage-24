"""Async session lifecycle tests."""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path

import pytest

from aep import Profile
from aep.runtime.session import AEPSession, ExecutionStatus


@pytest.fixture
def session(tmp_path: Path) -> AEPSession:
    profile = Profile(tmp_path / "config")
    profile.index()

    workspace = tmp_path / "workspace"
    workspace.mkdir()
    return AEPSession(workspace, profile)


def _python_cmd(code: str) -> str:
    exe = str(Path(sys.executable))
    return f'"{exe}" -c "{code}"'


def test_async_run_wait_output(session: AEPSession) -> None:
    async def _main() -> None:
        run_result = await session.run("echo hello-async")
        exec_id = run_result.exec_id

        wait_result = await session.wait(exec_id, timeout_ms=5_000)
        assert wait_result.status == ExecutionStatus.EXITED

        output_result = await session.output(exec_id, cursor=0, limit=100)
        text = "".join(
            chunk.content for chunk in output_result.chunks if chunk.stream == "stdout"
        )
        assert "hello-async" in text.lower()

    asyncio.run(_main())


def test_async_fifo_queue(tmp_path: Path) -> None:
    profile = Profile(tmp_path / "config")
    profile.index()
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    session = AEPSession(workspace, profile, max_queue_size=4)
    slow_cmd = _python_cmd("import time; print('first'); time.sleep(0.6); print('done')")
    fast_cmd = _python_cmd("print('second')")

    async def _main() -> None:
        first = await session.run(slow_cmd)
        second = await session.run(fast_cmd)

        assert first.status == ExecutionStatus.RUNNING
        assert second.status == ExecutionStatus.QUEUED
        assert second.queue_pos == 1

        await session.wait(first.exec_id, timeout_ms=5_000)
        await session.wait(second.exec_id, timeout_ms=5_000)

        second_output = await session.output(second.exec_id, cursor=0, limit=100)
        text = "".join(chunk.content for chunk in second_output.chunks)
        assert "second" in text

    asyncio.run(_main())


def test_async_kill_queued(tmp_path: Path) -> None:
    profile = Profile(tmp_path / "config")
    profile.index()
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    session = AEPSession(workspace, profile, max_queue_size=4)
    slow_cmd = _python_cmd("import time; time.sleep(2)")
    queued_cmd = _python_cmd("print('queued')")

    async def _main() -> None:
        first = await session.run(slow_cmd)
        second = await session.run(queued_cmd)

        killed = await session.kill(second.exec_id)
        assert killed.status_before == ExecutionStatus.QUEUED
        assert killed.status_after == ExecutionStatus.KILLED

        waited = await session.wait(second.exec_id, timeout_ms=500)
        assert waited.status == ExecutionStatus.KILLED

        await session.kill(first.exec_id)

    asyncio.run(_main())


def test_async_kill_running(tmp_path: Path) -> None:
    profile = Profile(tmp_path / "config")
    profile.index()
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    session = AEPSession(workspace, profile, max_queue_size=2)
    slow_cmd = _python_cmd("import time; time.sleep(5)")

    async def _main() -> None:
        run_result = await session.run(slow_cmd)
        exec_id = run_result.exec_id

        killed = await session.kill(exec_id)
        assert killed.status_before == ExecutionStatus.RUNNING
        assert killed.status_after == ExecutionStatus.KILLED

        waited = await session.wait(exec_id, timeout_ms=5_000)
        assert waited.status == ExecutionStatus.KILLED

    asyncio.run(_main())


def test_async_release_session(tmp_path: Path) -> None:
    profile = Profile(tmp_path / "config")
    profile.index()
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    session = AEPSession(workspace, profile, max_queue_size=4)
    slow_cmd = _python_cmd("import time; time.sleep(4)")
    queued_cmd = _python_cmd("print('after')")

    async def _main() -> None:
        first = await session.run(slow_cmd)
        second = await session.run(queued_cmd)

        released = await session.release()
        assert released == {"released": True}

        waited_first = await session.wait(first.exec_id, timeout_ms=5_000)
        waited_second = await session.wait(second.exec_id, timeout_ms=5_000)
        assert waited_first.status == ExecutionStatus.KILLED
        assert waited_second.status == ExecutionStatus.KILLED

    asyncio.run(_main())


def test_async_history_and_queue_limit(tmp_path: Path) -> None:
    profile = Profile(tmp_path / "config")
    profile.index()
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    session = AEPSession(workspace, profile, max_queue_size=1)
    slow_cmd = _python_cmd("import time; time.sleep(2)")

    async def _main() -> None:
        first = await session.run(slow_cmd)
        second = await session.run(slow_cmd)

        with pytest.raises(RuntimeError):
            await session.run(slow_cmd)

        await session.kill(first.exec_id)
        await session.kill(second.exec_id)

        fact = session.get_execution_fact(first.exec_id)
        assert fact is not None
        assert fact.exec_id == first.exec_id
        assert fact.aep_session_id == session.session_id
        assert fact.raw_command == slow_cmd
        assert fact.status.value in {"killed", "running", "failed", "exited"}

    asyncio.run(_main())
