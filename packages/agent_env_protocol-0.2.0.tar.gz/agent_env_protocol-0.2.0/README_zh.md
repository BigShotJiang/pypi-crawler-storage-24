<p align="right">
<a href="README.md">English</a>
</p>

# AEP - Agent Environment Protocol

<p align="center">
<img src="docs/aep-logo.svg" alt="AEP Logo" width="720" />
</p>

<p align="center">
<strong>当 Agent 能像写 Python 一样调用工具？AEP 正式发布！🚀</strong>

<em>为 Agent 提供统一的能力管理、发现与执行协议。</em>
</p>

---

## 🤔 为什么开发 AEP？

随着大模型的发展，我们逐渐发现了一些共性问题（如 Claude Skill、PageIndex 以及 OpenViking 的实践），现有的工具调用和 Agent 环境组织方式仍有诸多痛点。AEP 的诞生正是为了解决这些问题：

1. **顺应 Agent 的进化：用"文件系统"取代"硬编码"**
   随着大模型 Coding 和 Terminal 能力的跃升，Agent 已经具备了像人类一样操作电脑、查找资源的能力。在中等规模的数据场景下，让 Agent **自主浏览文件系统**往往比在 Prompt 里预先塞入结构化数据更智能。AEP 将工具（Tools）、技能（Skills）和知识库（Library）全部以文件系统的方式暴露，让 Agent 以最自然的方式进行访问和调度。

2. **拒绝上下文浪费：以 Pythonic 方式打破 MCP 的枷锁**
   传统的 MCP 和工具调用存在严重的上下文浪费：
   * *初始化浪费*：向大模型提供完整的工具描述和 Schema，往往会吃掉约 15% 的系统上下文。
   * *多轮调用灾难*：在顺序调用多个工具时，LLM 需要反复输出指令并接收中间结果。其实很多中间结果并不需要长期保留！

   AEP 提出了一种创新的思路：**让工具调用直接在 Python 执行环境中完成**。Agent 只需要写代码串联逻辑，极大地减少了多轮交互带来的 Token 消耗。

3. **彻底解决依赖冲突：像 `uv`/`npm` 一样管理 Skills**
   传统的 Skills 结构过于自由，多个带有脚本的 Skill 混在一起极易产生 Python 依赖冲突。AEP 借鉴了现代包管理工具的思路，为每个 Skill 提供**独立的虚拟环境（依赖隔离）**，在保持灵活性的同时保证了系统的绝对稳定。

---

## 💡 核心设计与创新点

AEP 将 Agent 的可用能力清晰地划分为三类，并针对每一类进行了深度优化：

### 🛠️ `tools/`：工具与 MCP 的统一

* **统一执行语义**：无论是本地 Python 工具还是远程 MCP 服务，Agent 统一通过 `tools run` 进行调用。单行调用使用 `tools run "tools.<tool>.<func>(...)"`，多行 Python 工作流使用 `tools run PY<< ... PY`。MCP 会被自动生成本地 Python Stub。
* **Agent 友好**：模型既可以只生成一个表达式，也可以一次性输出一个完整的 Python 代码块，而不必拆成多次工具调用。
* **可观测性**：通过 Session 的 `output / kill / history`，轻松追踪工具执行状态。

### 🧰 `skills/`：规范驱动的独立技能

* **依赖隔离**：每个 Skill 独享虚拟环境（`.venv`），彻底告别环境污染。
* **规范定义**：通过 `SKILL.md` 的 Frontmatter 进行严格的格式校验和字段声明。
* **执行明确**：使用 `skills run <skill/path.py> [args]` 即可精准调用。支持目录形式和单文件 `.md` 形式的导入。

### 📚 `library/`：树状结构的知识库

* **文件系统组织**：不再强制将知识塞入单文件数据库，而是按目录组织（支持任意子目录写入 `add_library`）。
* **递归索引**：每个目录拥有独立的 `index.md`，极其适合 LLM 进行分层阅读（先读目录索引，再按需深入具体文件）。

---

## 🏗️ 架构原理

AEP 采用清晰的**三层模型**设计：

1. **配置层 (`AEPProfile`)**：负责增删改查 Tools/Skills/Library/MCP 的配置，并生成统一索引 `index.md`。
2. **挂载层 (`AEPWorkspace`)**：将 Profile 的配置物理挂载到工作区（例如 `.agents/` 目录）。
3. **运行层 (`AEPSession`)**：统一的执行入口，支持命令队列、增量输出拉取、终止控制以及状态管理。

<details>
<summary>点击查看标准的 AEP Profile 目录结构</summary>

```text
config_dir/
├── tools/
│   ├── .venv/
│   ├── requirements.txt
│   ├── index.md
│   └── *.py
├── skills/
│   ├── index.md
│   └── <skill-name>/
│       ├── .venv/
│       ├── SKILL.md
│       ├── requirements.txt
│       └── scripts/...
├── library/
│   ├── index.md
│   └── ...
└── _mcp/
    └── <server>/config.json

```

</details>

---

## 🚀 快速开始

### 安装

待发布后即可通过 pip 安装：

```bash
pip install agent-env-protocol

```

本地开发：

```bash
git clone https://github.com/Slipstream-Max/Agent-Environment-Protocol
cd Agent-Environment-Protocol
uv sync --extra dev

```

### CLI 交互式体验（适合人类实验）

```bash
# 1. 初始化并生成索引
aep index --profile ./agent_config

# 2. 注入能力（工具/技能/文档）
aep tool add ./examples/calc.py --name calc --profile ./agent_config
aep skill add ./examples/greeter --name greeter --profile ./agent_config
aep library add ./docs/guide.md --target-dir intro --profile ./agent_config
aep index --profile ./agent_config

# 3. 进入交互式会话
aep shell --profile ./agent_config --workspace ./workspace

# 在 Shell 内，你可以直接像 Agent 一样测试：
# > tools list
# > tools run "tools.calc.add(1, 2)"
# > tools run PY<<
# > import pandas as pd
# > print(tools.calc.add(1, 2))
# > PY
# > skills run greeter/main.py

```

### Python API 极简示例

```python
import asyncio
from aep import AEPProfile, AEPWorkspace

async def main() -> None:
    # 1. 加载配置并构建索引
    profile = AEPProfile("./agent_capabilities")
    profile.index()

    # 2. 挂载工作区并创建会话
    aep = AEPWorkspace.attach(workspace="./my_project", config=profile)
    session = aep.create_session()

    # 3. 执行工具调用
    run_result = await session.run("tools list")
    await session.wait(run_result.exec_id, timeout_ms=5_000)
    
    # 4. 获取输出
    out = await session.output(run_result.exec_id, cursor=0, limit=200)
    print("".join(chunk.content for chunk in out.chunks))

asyncio.run(main())

```

---

## 🤖 接入你的大模型 Agent

AEP 提供了开箱即用的 Adapter，推荐按以下范式将 AEP 接入任意 LLM SDK：

1. **注入上下文**：通过 `profile.build_context()` 生成能力描述。
2. **注册工具**：暴露 `adapter.tool_schemas()` 给大模型。
3. **约束提示词**：使用 `adapter.usage_contract()` 告知模型如何正确使用 AEP。
4. **路由调用**：拦截模型的 Tool Call 并丢给 `adapter.call_tool(...)` 执行。

`profile.build_context()` 已经包含系统提示词的第二层和第三层：前面是 environment guide，后面是 tools / skills / library 的 indexes。Tools 共享 Python 依赖声明在 `tools/requirements.txt` 中，tools index 会提示这个位置。

```python
import asyncio
from aep import AEPProfile, AEPWorkspace, AEPSessionToolAdapter

async def run_with_llm(user_input: str) -> None:
    profile = AEPProfile("./agent_capabilities")
    profile.index()

    aep = AEPWorkspace.attach("./workspace", profile)
    session = aep.create_session()
    adapter = AEPSessionToolAdapter(session)

    # 获取给大模型的配置参数
    tools = adapter.tool_schemas()
    context = profile.build_context(include_tools=True, include_skills=True)
    usage_contract = adapter.usage_contract()

    system_prompt = f"{usage_contract}\n\nCapability context:\n{context}"

    # --- 伪代码：对接你自己的 LLM SDK ---
    # response = llm.chat(system=system_prompt, messages=[user_input], tools=tools)
    # for call in response.tool_calls:
    #     result = await adapter.call_tool(call.name, call.arguments)
    #     messages.append({"role": "tool", "content": str(result)})
    
if __name__ == "__main__":
    asyncio.run(run_with_llm("请列出当前可用工具"))

```

*注：`AEPSessionToolAdapter` 默认提供 5 个原子工具供模型编排：`aep_exec` (执行), `aep_output` (拉取输出), `aep_kill` (终止), `aep_history` (历史), `aep_env` (环境变量)。*

---

## 📖 参考资料

* 详细 API 文档: `docs/api.md`
* 架构深度解析: `docs/arch.md`
* 更多示例代码: `examples/README.md`, `examples/scripts/demo_tools.py`, `examples/example_agent/chat_openai_agent.py`

## 📄 License

[MIT License](https://www.google.com/search?q=LICENSE)
