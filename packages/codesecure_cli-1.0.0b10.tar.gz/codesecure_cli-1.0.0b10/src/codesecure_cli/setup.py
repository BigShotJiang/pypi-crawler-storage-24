"""
Setup utility to automatically configure CodeSecure PATH.
"""

import os
import sys
import platform
import subprocess
from pathlib import Path


def get_scripts_dir():
    """Detect where Python scripts are installed."""
    if platform.system() == "Windows":
        # Usually AppData\Roaming\Python\Python31x\Scripts for --user installs
        # or the Python installation directory for global installs
        import site
        user_base = site.getuserbase()
        if user_base:
            py_version = f"Python{sys.version_info.major}{sys.version_info.minor}"
            path = Path(user_base) / py_version / "Scripts"
            if path.exists():
                return path
        
        # Fallback to sys.executable's directory
        return Path(sys.executable).parent / "Scripts"
    else:
        # Linux/Mac
        return Path.home() / ".local" / "bin"


def setup_windows(scripts_path: Path):
    """Add path to Windows User Environment Variables."""
    try:
        scripts_dir = str(scripts_path.resolve())
        # Use PowerShell to safely add to User PATH
        cmd = f'[Environment]::SetEnvironmentVariable("Path", [Environment]::GetEnvironmentVariable("Path", "User") + ";{scripts_dir}", "User")'
        subprocess.run(["powershell", "-Command", cmd], check=True)
        return True
    except Exception as e:
        print(f"Error updating Windows PATH: {e}")
        return False


def setup_unix(scripts_path: Path):
    """Add path to shell profile for Linux/Mac."""
    try:
        scripts_dir = str(scripts_path.resolve())
        shell = os.environ.get("SHELL", "").split("/")[-1]
        
        if "zsh" in shell:
            profile = Path.home() / ".zshrc"
        elif "bash" in shell:
            profile = Path.home() / ".bashrc"
        else:
            profile = Path.home() / ".profile"

        line = f'\nexport PATH="$PATH:{scripts_dir}"\n'
        
        with open(profile, "a") as f:
            f.write(line)
        return True, profile
    except Exception as e:
        print(f"Error updating Unix PATH: {e}")
        return False, None


def main():
    print("🔧 CodeSecure CLI Setup")
    scripts_dir = get_scripts_dir()
    
    if not scripts_dir.exists():
        print(f"❌ Could not find scripts directory at {scripts_dir}")
        sys.exit(1)

    print(f"📍 Detected scripts directory: {scripts_dir}")
    
    confirm = input("Do you want to add this directory to your PATH? (y/n): ")
    if confirm.lower() != 'y':
        print("Setup cancelled.")
        return

    if platform.system() == "Windows":
        if setup_windows(scripts_dir):
            print("\n✅ PATH updated successfully!")
            print("👉 Please RESTART your terminal/PowerShell for changes to take effect.")
    else:
        success, profile = setup_unix(scripts_dir)
        if success:
            print(f"\n✅ PATH added to {profile}")
            print(f"👉 Run 'source {profile}' or restart your terminal.")


if __name__ == "__main__":
    main()
