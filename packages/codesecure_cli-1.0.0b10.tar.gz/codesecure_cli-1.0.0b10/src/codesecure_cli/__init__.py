"""
CLI Module for CodeSecure.

Cross-platform command-line interface.
"""

from .main import cli, main_entry

__all__ = ["cli", "main_entry"]
