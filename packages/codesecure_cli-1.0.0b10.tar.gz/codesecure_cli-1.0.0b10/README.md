# CodeSecure CLI (`codesecure-cli`)

The `codesecure-cli` package is the user-facing terminal interface for the CodeSecure monorepo. It wraps the functionality of the core orchestration engine within an interactive, rich terminal application.

## 🎯 Module Purpose

This package focuses entirely on **Developer Experience (DX)** inside the terminal and CI/CD environments. It parses CLI arguments using `Click`, dynamically structures interactive menus with `Rich`, and connects seamlessly to the Python business logic embedded in `codesecure-core`. 

*Note: The CLI is designed to be a "Thin Wrapper". Core scanning logic does not exist in this package.*

## 📦 Local Installation

Installing the CLI relies on standard Python setups but requires the workspace dependency mapped to `codesecure-core`.

```bash
cd packages/cli
python -m venv .venv
source .venv/bin/activate

# Recommended: Install via pip from the project root rather than locally
# This dynamically resolves workspace dependencies
cd ../../
pip install -e ./packages/cli
```

## 🔌 Exported Commands & Features

The entry point script installs a global binary command: `codesecure`. Check the top-level commands below.

```bash
# Validates the active scanners provided by Core
codesecure list-scanners

# Initializes Beta agreements
codesecure init

# Prompts setup for Gemini or Kiro CLI
codesecure login

# The main workhorse: Initiates an interactive async scan on a target path
codesecure scan ./my-project --provider kiro --output json,html
```

## 🛠️ Integration Example

Since the CLI is a consumption edge-node in the monorepo architecture, its integrations primarily concern reading from `core`. Below is a snippet of how the CLI bypasses MCP overhead to list scanners efficiently from the programmatic core.

```python
import click
from codesecure.common.models import ScanMode

@click.command()
def list_scanners():
    """List available security scanners from Core."""
    from codesecure.scanners.engine import get_scanner_engine
    engine = get_scanner_engine()
    
    try:
        local_scanners = engine.get_available_scanners(ScanMode.LOCAL)
        print(f"Available Local Scanners: {', '.join(local_scanners)}")
    except Exception as e:
        print(f"Failed to list scanners: {e}")
```
