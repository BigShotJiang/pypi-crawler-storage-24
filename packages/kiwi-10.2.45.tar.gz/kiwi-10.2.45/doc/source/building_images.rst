.. _building_types:

Building Images for Supported Types
===================================

.. note::

   This document provides an overview of how to build and use
   the {kiwi}-supported image types. All images that we provide
   for testing use the root password: `linux`.

.. toctree::
   :maxdepth: 1

   building_images/build_live_iso
   building_images/build_simple_disk
   building_images/build_expandable_disk
   building_images/build_container_image
   building_images/build_wsl_container
   building_images/build_kis
   building_images/build_enclave
