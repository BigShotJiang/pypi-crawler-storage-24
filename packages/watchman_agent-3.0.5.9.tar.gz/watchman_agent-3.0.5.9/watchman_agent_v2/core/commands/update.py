# ─────────────────────────────────────────────────────────────
#  COMMANDE : update (manuelle)
# ─────────────────────────────────────────────────────────────
import click

from watchman_agent_v2.updater.manager import run_update_flow


@click.command()
def update():
    """Mettre à jour Watchman Agent manuellement"""
    click.echo("Vérification des mises à jour...")
    run_update_flow()