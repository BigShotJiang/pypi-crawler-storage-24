"""Wrapper for running fake-gcs-server as a subprocess.

Binaries are bundled in the platform-specific wheels.

Usage::

    server = FakeGCSServer(port=9023)
    server.start()   # sets STORAGE_EMULATOR_HOST
    ...
    server.stop()    # terminates process, unsets env var

Or as a context manager::

    with FakeGCSServer(port=9023) as server:
        ...
"""

from __future__ import annotations

import os
import platform
import socket
import subprocess
import tempfile
import time
import traceback
import urllib.request
from pathlib import Path

_BIN_DIR = Path(__file__).parent / "vendor" / "fake-gcs-server" / "bin"


def _get_binary_path() -> Path:
    """
    Return the path of the appropriate fake-gcs-server binary for the current platform.
    """
    system = platform.system().lower()  # darwin, linux, windows
    machine = platform.machine()
    arch_map = {
        "x86_64": "amd64",
        "AMD64": "amd64",
        "aarch64": "arm64",
        "arm64": "arm64",
    }
    arch = arch_map.get(machine)
    if not arch:
        raise RuntimeError(f"Unsupported architecture: {machine}")
    suffix = ".exe" if system == "windows" else ""
    binary = _BIN_DIR / f"fake-gcs-server-{system}-{arch}{suffix}"
    if not binary.exists():
        raise RuntimeError(
            f"No bundled fake-gcs-server binary for {system}/{arch}. "
            f"Looked at: {binary}"
        )
    return binary


def _find_free_port() -> int:
    """
    Find a free port on the local host.
    """
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


class FakeGCSServer:
    """Manage a fake-gcs-server subprocess for testing.

    Start the server with an in-memory backend over HTTP, suitable for
    use with any client that respects the ``STORAGE_EMULATOR_HOST``
    environment variable (google-cloud-storage, gcsfs/fsspec, etc.).
    """

    host: str
    port: int
    _process: subprocess.Popen | None = None
    _tmpdir: tempfile.TemporaryDirectory | None = None

    def __init__(self, host: str = "127.0.0.1", port: int | None = None):
        self.host = host
        if port:
            self.port = port
        elif host == "127.0.0.1":
            self.port = _find_free_port()
        else:
            raise ValueError("Must specify a port when not binding to 127.0.0.1")

    @property
    def url(self) -> str:
        return f"http://{self.host}:{self.port}"

    def start(self) -> None:
        """Start the server and set ``STORAGE_EMULATOR_HOST``."""
        binary = _get_binary_path()
        self._tmpdir = tempfile.TemporaryDirectory()
        self._process = subprocess.Popen(
            [
                str(binary),
                "-scheme",
                "http",
                "-backend",
                "filesystem",
                "-filesystem-root",
                Path(self._tmpdir.name).resolve(),
                "-host",
                self.host,
                "-port",
                str(self.port),
                "-external-url",
                self.url,
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.PIPE,
        )
        self._wait_until_ready(timeout=10.0)
        os.environ["STORAGE_EMULATOR_HOST"] = self.url

    def stop(self) -> None:
        """
        Terminate the server, delete temporary storage dir, and unset ``STORAGE_EMULATOR_HOST``.
        """
        if self._process is not None:
            os.environ.pop("STORAGE_EMULATOR_HOST", None)
            try:
                self._process.terminate()
                try:
                    self._process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    self._process.kill()
                    self._process.wait()
            except Exception:
                traceback.print_exc()
            self._process = None

        if self._tmpdir is not None:
            try:
                self._tmpdir.cleanup()
            except Exception:
                traceback.print_exc()
            self._tmpdir = None

    def _wait_until_ready(self, timeout: float) -> None:
        """
        Wait until the fake-gcs-server subprocess is ready.
        """
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if rc := self._process.poll() is not None:
                stderr = self._process.stderr.read().decode(errors="replace")
                os.environ.pop("STORAGE_EMULATOR_HOST", None)
                self._process = None
                raise RuntimeError(
                    f"fake-gcs-server exited unexpectedly. {rc=}, stderr: {stderr}"
                )
            try:
                with urllib.request.urlopen(f"{self.url}/storage/v1/b") as resp:
                    if resp.status == 200:
                        return
            except (ConnectionRefusedError, urllib.error.URLError, OSError):
                pass
            time.sleep(0.1)

        # Timed out
        self.stop()
        raise RuntimeError(
            f"fake-gcs-server did not become ready within {timeout:.1f}s"
        )

    def __enter__(self) -> FakeGCSServer:
        self.start()
        return self

    def __exit__(self, *args: object) -> None:
        self.stop()

    def __del__(self) -> None:
        try:
            self.stop()
        except Exception:
            pass
