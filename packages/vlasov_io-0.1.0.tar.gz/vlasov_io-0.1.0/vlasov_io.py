import pathlib
import ctypes
import tqdm
import struct
import re
from dataclasses import dataclass

import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq

import concurrent.futures as confu

pc = 3.0856775807e+18
mpc = pc * 1.0e+6


# Utility functions
def dtda(a, cosm):
    om, ov = cosm.omega_m, cosm.omega_v
    ok = 1.0 - om - ov
    return np.sqrt(a / (om + ok * a + ov * a**3))


def atotime(a, cosm):
    result, _ = quad(dtda, 0, a, args=(cosm,))
    return result


def timetoa(t, cosm):
    def func(a): return atotime(a, cosm) - t
    return brentq(func, 1e-4, 2.0)


def timetoz(t, cosm):
    a = timetoa(t, cosm)
    return 1.0 / a - 1.0


def calc_norm(data, l=2):
    return np.linalg.norm(data, ord=l, axis=0)


@dataclass
class HeaderInfo:
    input_file: str
    prefix: str
    suffix: str
    head_size: int
    nd: int = 1
    hierarchy_level: int = 0


@dataclass
class DFHeaderInfo:
    input_file: str
    head_size: int
    df_size: int
    vel_grid_shape: tuple
    local_id_min: tuple
    local_id_max: tuple
    global_loc_start: tuple
    global_loc_end: tuple


def detect_hierarchy_level(prefix, dims=3):
    root_path = pathlib.Path(prefix)
    if dims == 3:
        hierarchy_list = [
            (0, lambda: list(root_path.glob("x000_*")), lambda ix, iy, iz: f"x{ix:03d}_y{iy:03d}_z{iz:03d}_"),
            (1, lambda: list((root_path / "x000").glob("y000_*")), lambda ix, iy, iz: f"x{ix:03d}/y{iy:03d}_z{iz:03d}_"),
            (2, lambda: list((root_path / "x000/y000").glob("z000*")), lambda ix, iy, iz: f"x{ix:03d}/y{iy:03d}/z{iz:03d}_"),
        ]
    elif dims == 2:
        hierarchy_list = [
            (0, lambda: list(root_path.glob("x000_*")), lambda ix, iy: f"x{ix:03d}_y{iy:03d}_"),
            (1, lambda: list((root_path / "x000").glob("y000*")), lambda ix, iy: f"x{ix:03d}/y{iy:03d}_"),
        ]
    else:
        raise ValueError("dims must be 2 or 3.")

    for level, test_func, prefix_func in hierarchy_list:
        if test_func():
            return level, prefix_func

    raise FileNotFoundError(f"Cannot detect hierarchy level for prefix={root_path} (dims={dims})")


def split_prefix_suffix_from_input_file(input_file, dims=3):
    p = str(pathlib.Path(input_file))
    if dims == 3:
        patterns = [
            (2, re.compile(r"^(?P<prefix>.+)/x\d{3}/y\d{3}/z\d{3}_(?P<suffix>[^/]+)$")),
            (1, re.compile(r"^(?P<prefix>.+)/x\d{3}/y\d{3}_z\d{3}_(?P<suffix>[^/]+)$")),
            (0, re.compile(r"^(?P<prefix>.+)/x\d{3}_y\d{3}_z\d{3}_(?P<suffix>[^/]+)$")),
        ]
    elif dims == 2:
        patterns = [
            (1, re.compile(r"^(?P<prefix>.+)/x\d{3}/y\d{3}_(?P<suffix>[^/]+)$")
             ), (0, re.compile(r"^(?P<prefix>.+)/x\d{3}_y\d{3}_(?P<suffix>[^/]+)$")),
        ]
    else:
        raise ValueError("dims must be 2 or 3.")

    for level, pat in patterns:
        m = pat.match(p)
        if m:
            return m.group("prefix"), m.group("suffix"), level

    raise ValueError(f"Cannot parse split-file path into prefix/suffix: {input_file}")


class ReprStructure(ctypes.Structure):
    def __repr__(self) -> str:
        values = ", ".join(f"{name}={value}" for name, value in self._asdict().items())
        return f"<{self.__class__.__name__}: {values}>"

    def _asdict(self) -> dict:
        return {field[0]: getattr(self, field[0]) for field in self._fields_}


class Meshes(ReprStructure):
    _pack_ = 1
    _fields_ = (
        ('x_total', ctypes.c_int32), ('y_total', ctypes.c_int32), ('z_total', ctypes.c_int32),
        ('x_local', ctypes.c_int32), ('y_local', ctypes.c_int32), ('z_local', ctypes.c_int32),
        ('x_loc_start', ctypes.c_int32), ('x_loc_end', ctypes.c_int32),
        ('y_loc_start', ctypes.c_int32), ('y_loc_end', ctypes.c_int32),
        ('z_loc_start', ctypes.c_int32), ('z_loc_end', ctypes.c_int32),
        ('loc_size', ctypes.c_int64),
    )


class NeutrinoParam(ReprStructure):
    # _pack_ = 1
    _fields_ = (
        ('mass_nu_mun', ctypes.c_int32),
        ('deg', ctypes.c_int * 3), ('sum_mass', ctypes.c_float),
        ('mass', ctypes.c_float * 3), ('frac', ctypes.c_float * 3)
    )


class CosmoParam(ReprStructure):
    # _pack_ = 1
    _fields_ = (
        ('omega_m', ctypes.c_float), ('omega_v', ctypes.c_float), ('omega_b', ctypes.c_float),
        ('omega_nu', ctypes.c_float), ('omega_r', ctypes.c_float),
        ('hubble', ctypes.c_float), ('tend', ctypes.c_float),
        ('nu', NeutrinoParam)
    )


class BaseHeader(ReprStructure):
    _pack_ = 1
    _fields_ = (
        ### base header ###
        ('cosmology_flag', ctypes.c_int32),
        ('canonical_flag', ctypes.c_int32),

        ('nnode_x', ctypes.c_int32), ('nnode_y', ctypes.c_int32), ('nnode_z', ctypes.c_int32),
        ('mpi_proc', ctypes.c_int32), ('mpi_rank', ctypes.c_int32),
        ('rank_x', ctypes.c_int32), ('rank_y', ctypes.c_int32), ('rank_z', ctypes.c_int32),

        ('xmin', ctypes.c_float), ('xmax', ctypes.c_float),
        ('ymin', ctypes.c_float), ('ymax', ctypes.c_float),
        ('zmin', ctypes.c_float), ('zmax', ctypes.c_float),
        ('xmin_local', ctypes.c_float), ('xmax_local', ctypes.c_float),
        ('ymin_local', ctypes.c_float), ('ymax_local', ctypes.c_float),
        ('zmin_local', ctypes.c_float), ('zmax_local', ctypes.c_float),

        ('lunit', ctypes.c_double), ('munit', ctypes.c_double), ('tunit', ctypes.c_double),
        ('tnow', ctypes.c_float), ('dtime', ctypes.c_float), ('step', ctypes.c_int32),
        ### base header ###
    )


class RunParam(ReprStructure):
    _pack_ = 1
    _fields_ = BaseHeader._fields_ + (
        ('nm', Meshes),
    )


class RunParamCOSM(ReprStructure):
    _pack_ = 1
    _fields_ = BaseHeader._fields_ + (
        ('cosm', CosmoParam),
        ('nm', Meshes),
    )


class PtclParam(ReprStructure):
    _pack_ = 1
    _fields_ = BaseHeader._fields_ + (
        ('npart', ctypes.c_uint64),
        ('npart_total', ctypes.c_uint64),
    )


class PtclParamCOSM(ReprStructure):
    _pack_ = 1
    _fields_ = BaseHeader._fields_ + (
        ('cosm', CosmoParam),
        ('npart', ctypes.c_uint64),
        ('npart_total', ctypes.c_uint64),
    )


class DFParam(ReprStructure):
    _pack_ = 1
    _fields_ = BaseHeader._fields_ + (
        ('nm', Meshes),
        ('nvx', ctypes.c_int32), ('nvy', ctypes.c_int32), ('nvz', ctypes.c_int32),
        ('vx_min', ctypes.c_float), ('vx_max', ctypes.c_float),
        ('vy_min', ctypes.c_float), ('vy_max', ctypes.c_float),
        ('vz_min', ctypes.c_float), ('vz_max', ctypes.c_float),
        ('delta_x', ctypes.c_float), ('delta_y', ctypes.c_float), ('delta_z', ctypes.c_float),
        ('delta_vx', ctypes.c_float), ('delta_vy', ctypes.c_float), ('delta_vz', ctypes.c_float),
    )


class DFParamCOSM(ReprStructure):
    _pack_ = 1
    _fields_ = BaseHeader._fields_ + (
        ('cosm', CosmoParam),
        ('nm', Meshes),
        ('nvx', ctypes.c_int32), ('nvy', ctypes.c_int32), ('nvz', ctypes.c_int32),
        ('vx_min', ctypes.c_float), ('vx_max', ctypes.c_float),
        ('vy_min', ctypes.c_float), ('vy_max', ctypes.c_float),
        ('vz_min', ctypes.c_float), ('vz_max', ctypes.c_float),
        ('delta_x', ctypes.c_float), ('delta_y', ctypes.c_float), ('delta_z', ctypes.c_float),
        ('delta_vx', ctypes.c_float), ('delta_vy', ctypes.c_float), ('delta_vz', ctypes.c_float),
    )


class VlasovMesh:
    def check_flag(self, input_file):
        with open(input_file, "rb") as read_file:
            cosmology_flag = read_file.read(ctypes.sizeof(ctypes.c_int32))
            cosmology_flag = struct.unpack('<i', cosmology_flag)[0]
            canonical_flag = read_file.read(ctypes.sizeof(ctypes.c_int32))
            canonical_flag = struct.unpack('<i', canonical_flag)[0]

        self.cosmology_flag = cosmology_flag
        self.canonical_flag = canonical_flag

    def read_header(self, input_file):
        self.check_flag(input_file)
        if self.cosmology_flag:
            this_run = RunParamCOSM()
            head_size = ctypes.sizeof(RunParamCOSM)
        else:
            this_run = RunParam()
            head_size = ctypes.sizeof(RunParam)

        with open(input_file, "rb") as read_file:
            read_file.readinto(this_run)

        this_run.delta_x = (this_run.xmax - this_run.xmin) / this_run.nm.x_total
        this_run.delta_y = (this_run.ymax - this_run.ymin) / this_run.nm.y_total
        this_run.delta_z = (this_run.zmax - this_run.zmin) / this_run.nm.z_total

        if this_run.cosmology_flag:
            this_run.znow = timetoz(this_run.tnow, this_run.cosm)
            this_run.anow = timetoa(this_run.tnow, this_run.cosm)
            this_run.box_size = this_run.lunit * this_run.cosm.hubble / mpc

            """
            # L/T to cm/s unit to km/s
            this_run.vunit = 1.0e-5 * (this_run.lunit / this_run.tunit)
            # on: canonical , off: peculiar
            if this_run.canonical_flag == 1:
                this_run.vunit /= this_run.anow

            keywords = ["nbody", "pm", "ngp", "cic", "tsc", "pcs"]
            if any(keyword in input_file for keyword in keywords):
                this_run.vunit *= this_run.anow
                if this_run.canonical_flag == 1:
                    # Revert the process for neutrinos above.
                    this_run.vunit *= this_run.anow
            """
            this_run.vunit = 1.0

        else:
            this_run.box_size = 1
            this_run.lunit = 1.0
            this_run.tunit = 1.0
            this_run.munit = 1.0
            this_run.vunit = this_run.lunit / this_run.tunit

        loc0 = this_run.nm.x_local * this_run.nm.y_local * this_run.nm.z_local
        n = self._detect_ncomp_from_file(input_file, head_size, loc0)

        prefix, suffix, hierarchy_level = split_prefix_suffix_from_input_file(input_file, dims=3)

        info = HeaderInfo(
            input_file=input_file,
            prefix=prefix,
            suffix=suffix,
            head_size=head_size,
            nd=n,
            hierarchy_level=hierarchy_level,
        )
        return this_run, info

    def _detect_ncomp_from_file(self, input_file, head_size, loc_num, dtype=np.float32):
        file_size = pathlib.Path(input_file).stat().st_size
        payload = file_size - head_size
        elem_bytes = np.dtype(dtype).itemsize
        unit = elem_bytes * int(loc_num)
        ncomp = payload // unit
        return int(ncomp)

    def read_volume(self, info: HeaderInfo):
        input_prefix = info.prefix
        suffix = info.suffix
        head_size = info.head_size
        n = info.nd

        hl, hb = detect_hierarchy_level(input_prefix)
        basefile = str(pathlib.Path(input_prefix, hb(0, 0, 0) + suffix))
        base_run, _base_info = self.read_header(basefile)

        vols = np.zeros(
            (n, base_run.nm.x_total, base_run.nm.y_total, base_run.nm.z_total),
            dtype=np.float32
        )

        for ix in tqdm.tqdm(range(base_run.nnode_x), leave=False):
            for iy in range(base_run.nnode_y):
                for iz in range(base_run.nnode_z):
                    input_file = str(pathlib.Path(input_prefix, hb(ix, iy, iz) + suffix))
                    tmp_run, _ = self.read_header(input_file)
                    loc_num = tmp_run.nm.x_local * tmp_run.nm.y_local * tmp_run.nm.z_local

                    with open(input_file, "rb") as f:
                        f.read(head_size)
                        buf = [np.fromfile(f, dtype=np.float32, count=int(loc_num)) for _ in range(n)]

                    for ii in range(n):
                        buf[ii].resize(tmp_run.nm.x_local, tmp_run.nm.y_local, tmp_run.nm.z_local)
                        vols[ii,
                             tmp_run.nm.x_loc_start:tmp_run.nm.x_loc_end,
                             tmp_run.nm.y_loc_start:tmp_run.nm.y_loc_end,
                             tmp_run.nm.z_loc_start:tmp_run.nm.z_loc_end] = buf[ii]

        if n == 1:
            self.volume = vols[0]
        else:
            self.volume = vols

        return base_run


def create_PosGrid(nvtot):
    class _PosGrid(ctypes.Structure):
        _fields_ = (
            ('vel_grid', ctypes.c_float * nvtot),
            ('dens', ctypes.c_float), ('pot', ctypes.c_float),
            ('vel_mean', ctypes.c_float * 3),
            ('acc', ctypes.c_float * 3)
        )
    return _PosGrid


class VlasovDF:
    def check_flag(self, input_file):
        with open(input_file, "rb") as read_file:
            cosmology_flag = read_file.read(ctypes.sizeof(ctypes.c_int32))
            cosmology_flag = struct.unpack('<i', cosmology_flag)[0]
            canonical_flag = read_file.read(ctypes.sizeof(ctypes.c_int32))
            canonical_flag = struct.unpack('<i', canonical_flag)[0]

        self.cosmology_flag = cosmology_flag
        self.canonical_flag = canonical_flag

    def read_header(self, input_file):
        self.check_flag(input_file)
        if self.cosmology_flag:
            this_run = DFParamCOSM()
            head_size = ctypes.sizeof(DFParamCOSM)
        else:
            this_run = DFParam()
            head_size = ctypes.sizeof(DFParam)

        with open(input_file, "rb") as read_file:
            read_file.readinto(this_run)

        if self.cosmology_flag:
            this_run.znow = timetoz(this_run.tnow, this_run.cosm)
            this_run.anow = timetoa(this_run.tnow, this_run.cosm)
            this_run.box_size = this_run.lunit * this_run.cosm.hubble / mpc

        # L/T to cm/s unit to km/s
        this_run.vunit = 1.0e-5 * (this_run.lunit / this_run.tunit)
        # on: canonical , off: peculiar
        if this_run.canonical_flag == 1:
            this_run.vunit /= this_run.anow

        mesh_num = int(this_run.nvx * this_run.nvy * this_run.nvz)
        pos_grid = create_PosGrid(mesh_num)
        df_size = ctypes.sizeof(pos_grid)

        info = DFHeaderInfo(
            input_file=input_file,
            head_size=head_size,
            df_size=df_size,
            vel_grid_shape=(int(this_run.nvx), int(this_run.nvy), int(this_run.nvz)),
            local_id_min=(0, 0, 0),
            local_id_max=(
                int(this_run.nm.x_local - 1),
                int(this_run.nm.y_local - 1),
                int(this_run.nm.z_local - 1),
            ),
            global_loc_start=(
                int(this_run.nm.x_loc_start),
                int(this_run.nm.y_loc_start),
                int(this_run.nm.z_loc_start),
            ),
            global_loc_end=(
                int(this_run.nm.x_loc_end),
                int(this_run.nm.y_loc_end),
                int(this_run.nm.z_loc_end),
            ),
        )
        return this_run, info

    def show_local_mesh(self, input_file):
        this_run, info = self.read_header(input_file)
        print("local nmesh  :", this_run.nm.x_local, this_run.nm.y_local, this_run.nm.z_local)
        print("local nvmesh :", this_run.nvx, this_run.nvy, this_run.nvz)
        print(
            "valid local_id range:",
            f"x={info.local_id_min[0]}..{info.local_id_max[0]},",
            f"y={info.local_id_min[1]}..{info.local_id_max[1]},",
            f"z={info.local_id_min[2]}..{info.local_id_max[2]}",
        )

    def read_df(self, info, local_id=(0, 0, 0)):
        this_run, _ = self.read_header(info.input_file)
        lix, liy, liz = (int(local_id[0]), int(local_id[1]), int(local_id[2]))

        nlocal_x = int(info.local_id_max[0] - info.local_id_min[0] + 1)
        nlocal_y = int(info.local_id_max[1] - info.local_id_min[1] + 1)
        nlocal_z = int(info.local_id_max[2] - info.local_id_min[2] + 1)
        self.PosGrid = create_PosGrid(int(np.prod(info.vel_grid_shape)))

        target_mesh = int(liz + nlocal_z * (liy + nlocal_y * lix))
        target_seek = int(info.head_size + info.df_size * target_mesh)

        with open(info.input_file, "rb") as read_file:
            read_file.seek(target_seek)

            df = self.PosGrid()
            read_file.readinto(df)

        data = np.array(df.vel_grid)
        data.resize(*info.vel_grid_shape)

        self.data = data
        self.dens = df.dens
        self.pot = df.pot
        self.velc = np.array(df.vel_mean, dtype=np.float32)
        self.acc = np.array(df.acc, dtype=np.float32)
        self.local_id = (lix, liy, liz)
        self.global_id = (
            info.global_loc_start[0] + lix,
            info.global_loc_start[1] + liy,
            info.global_loc_start[2] + liz,
        )
        self.df_info = info
        return this_run


ptcl_type = np.dtype([
    ("idx", np.uint64),
    ("mass", np.float32),
    ("pos", np.float32, (3,)),
    ("vel", np.float32, (3,)),
])


class VlasovPtcl:
    def check_flag(self, input_file):
        with open(input_file, "rb") as read_file:
            cosmology_flag = read_file.read(ctypes.sizeof(ctypes.c_int32))
            cosmology_flag = struct.unpack('<i', cosmology_flag)[0]
            canonical_flag = read_file.read(ctypes.sizeof(ctypes.c_int32))
            canonical_flag = struct.unpack('<i', canonical_flag)[0]

        self.cosmology_flag = cosmology_flag
        self.canonical_flag = canonical_flag

    def read_header(self, input_file):
        self.check_flag(input_file)
        if self.cosmology_flag:
            this_run = PtclParamCOSM()
            head_size = ctypes.sizeof(PtclParamCOSM)
        else:
            this_run = PtclParam()
            head_size = ctypes.sizeof(PtclParam)

        with open(input_file, "rb") as read_file:
            read_file.readinto(this_run)

        if this_run.cosmology_flag:
            this_run.znow = timetoz(this_run.tnow, this_run.cosm)
            this_run.anow = timetoa(this_run.tnow, this_run.cosm)
            this_run.box_size = this_run.lunit * this_run.cosm.hubble / mpc

            # L/T to cm/s unit to km/s
            this_run.vunit = 1.0e-5 * (this_run.lunit / this_run.tunit)
            # on: canonical , off: peculiar
            if this_run.canonical_flag == 1:
                this_run.vunit /= this_run.anow

            keywords = ["nbody", "pm", "ngp", "cic", "tsc", "pcs"]
            if any(keyword in input_file for keyword in keywords):
                this_run.vunit *= this_run.anow
                if this_run.canonical_flag == 1:
                    # Revert the process for neutrinos above.
                    this_run.vunit *= this_run.anow

        else:
            this_run.box_size = 1
            this_run.lunit = 1.0
            this_run.tunit = 1.0
            this_run.munit = 1.0
            this_run.vunit = this_run.lunit / this_run.tunit

        self.vunit = this_run.vunit
        prefix, suffix, hierarchy_level = split_prefix_suffix_from_input_file(input_file, dims=3)

        info = HeaderInfo(
            input_file=input_file,
            prefix=prefix,
            suffix=suffix,
            head_size=head_size,
            nd=int(this_run.npart),
            hierarchy_level=hierarchy_level,
        )
        return this_run, info

    @staticmethod
    def get_npart_from_file(input_file):
        with open(input_file, "rb") as f:
            cosmology_flag = struct.unpack("<i", f.read(4))[0]
            if cosmology_flag:
                f.seek(PtclParamCOSM.npart.offset)
                npart = struct.unpack("<Q", f.read(8))[0]
                head_size = ctypes.sizeof(PtclParamCOSM)
            else:
                f.seek(PtclParam.npart.offset)
                npart = struct.unpack("<Q", f.read(8))[0]
                head_size = ctypes.sizeof(PtclParam)
        return npart, head_size

    def read_ptcls(self, info: HeaderInfo, ranges=None, nwork=1):
        if int(nwork) <= 1:
            param = self._read_ptcls_serial(info, ranges=ranges)
        else:
            param = self._read_ptcls_parallel(info, ranges=ranges, nwork=nwork)

        self.ptcls["pos"] *= param.box_size  # Convert to physical unit
        self.ptcls["vel"] *= self.vunit  # Convert to physical unit [km/s]
        return param

    def _read_ptcls_serial(self, info: HeaderInfo, ranges=None):
        input_prefix = info.prefix
        suffix = info.suffix

        _hl, hb = detect_hierarchy_level(input_prefix)
        basefile = str(pathlib.Path(input_prefix, hb(0, 0, 0) + suffix))
        base_run, _base_info = self.read_header(basefile)

        if ranges is not None:
            xmin, xmax = ranges[0]
            ymin, ymax = ranges[1]
            zmin, zmax = ranges[2]

        pos = []
        vel = []
        idx = []
        mass = []

        for ix in tqdm.tqdm(range(base_run.nnode_x)):
            for iy in range(base_run.nnode_y):
                for iz in range(base_run.nnode_z):
                    input_file = str(pathlib.Path(input_prefix, hb(ix, iy, iz) + suffix))
                    tmp_run, tmp_info = self.read_header(input_file)

                    with open(input_file, "rb") as read_file:
                        read_file.read(tmp_info.head_size)
                        ptcl_num = tmp_run.npart
                        _ptcl = np.fromfile(read_file, dtype=ptcl_type, count=int(ptcl_num))

                    if ranges is not None:
                        _pos = _ptcl["pos"]
                        _ptcl = _ptcl[
                            (xmin <= _pos[:, 0]) & (_pos[:, 0] < xmax) &
                            (ymin <= _pos[:, 1]) & (_pos[:, 1] < ymax) &
                            (zmin <= _pos[:, 2]) & (_pos[:, 2] < zmax)
                        ]

                    if _ptcl.size == 0:
                        continue

                    _pos = _ptcl["pos"]  # * base_run.box_size  # Convert to physical unit
                    _vel = _ptcl["vel"]  # * self.vunit  # Convert to physical unit [km/s]

                    pos.append(_pos)
                    vel.append(_vel)
                    idx.append(_ptcl["idx"])
                    mass.append(_ptcl["mass"])

        idx = np.hstack(idx)
        mass = np.hstack(mass)
        pos = np.vstack(pos)
        vel = np.vstack(vel)

        ptcls = {
            "idx": idx,
            "mass": mass,
            "pos": pos,
            "vel": vel
        }

        self.ptcls = ptcls
        return base_run

    @staticmethod
    def _read_ptcl_chunk(task):
        input_files, ranges = task

        if ranges is not None:
            xmin, xmax = ranges[0]
            ymin, ymax = ranges[1]
            zmin, zmax = ranges[2]

        pos, vel, idx, mass = [], [], [], []

        for input_file in input_files:
            ptcl_num, head_size = VlasovPtcl.get_npart_from_file(input_file)

            with open(input_file, "rb") as read_file:
                read_file.read(head_size)
                _ptcl = np.fromfile(read_file, dtype=ptcl_type, count=int(ptcl_num))

            if ranges is not None:
                _pos = _ptcl["pos"]
                _ptcl = _ptcl[
                    (xmin <= _pos[:, 0]) & (_pos[:, 0] < xmax) &
                    (ymin <= _pos[:, 1]) & (_pos[:, 1] < ymax) &
                    (zmin <= _pos[:, 2]) & (_pos[:, 2] < zmax)
                ]

            if _ptcl.size == 0:
                continue

            pos.append(_ptcl["pos"])
            vel.append(_ptcl["vel"])
            idx.append(_ptcl["idx"])
            mass.append(_ptcl["mass"])

        return (
            idx,
            mass,
            pos,
            vel,
        )

    def _read_ptcls_parallel(self, info: HeaderInfo, ranges=None, nwork=8):
        input_prefix = info.prefix
        suffix = info.suffix

        _hl, hb = detect_hierarchy_level(input_prefix)
        basefile = str(pathlib.Path(input_prefix, hb(0, 0, 0) + suffix))
        base_run, base_info = self.read_header(basefile)

        input_files = []
        tasks = []

        total = base_run.nnode_x * base_run.nnode_y * base_run.nnode_z
        for idx in range(total):
            ix = idx // (base_run.nnode_y * base_run.nnode_z)
            rem = idx % (base_run.nnode_y * base_run.nnode_z)
            iy = rem // base_run.nnode_z
            iz = rem % base_run.nnode_z
            input_files.append(str(pathlib.Path(input_prefix, hb(ix, iy, iz) + suffix)))

        nchunks = min(nwork, len(input_files))
        q, r = divmod(len(input_files), nchunks)

        start = 0
        for i in range(nchunks):
            size = q + (1 if i < r else 0)
            end = start + size
            tasks.append((input_files[start:end], ranges))
            start = end

        pos, vel, idx, mass = [], [], [], []
        with confu.ProcessPoolExecutor(max_workers=int(nwork)) as ex:
            for chunk in tqdm.tqdm(ex.map(VlasovPtcl._read_ptcl_chunk, tasks), total=len(tasks), leave=False):
                if chunk is None:
                    continue
                _idx, _mass, _pos, _vel = chunk
                idx.extend(_idx)
                mass.extend(_mass)
                pos.extend(_pos)
                vel.extend(_vel)

        ptcls = {
            "idx": np.hstack(idx),
            "mass": np.hstack(mass),
            "pos": np.vstack(pos),
            "vel": np.vstack(vel),
        }

        self.ptcls = ptcls
        return base_run
