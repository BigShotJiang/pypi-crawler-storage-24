class ValidationWarning(UserWarning):
    """Warning raised for non-fatal validation issues."""

    pass
