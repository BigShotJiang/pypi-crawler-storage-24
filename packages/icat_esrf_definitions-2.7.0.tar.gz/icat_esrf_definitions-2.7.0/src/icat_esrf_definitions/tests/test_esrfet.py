import re
from importlib.metadata import version

import pytest

from ..errors import ValidationWarning
from ..models import IcatDatasetParameters


def test_esrfet_fields(input_dict, esrfet_version):
    input_dict["definition"] = "XAS XRF"
    input_dict["technique_pid"] = (
        "https://w3id.org/PaN/ESRFET#XAS https://w3id.org/PaN/ESRFET#XRF"
    )
    input_dict["technique_pid_esrfet_version"] = esrfet_version

    model = IcatDatasetParameters(**input_dict)
    assert model.definition == ["XAS", "XRF"]
    assert model.technique_pid == [
        "https://w3id.org/PaN/ESRFET#XAS",
        "https://w3id.org/PaN/ESRFET#XRF",
    ]
    assert model.technique_pid_esrfet_version == esrfet_version


def test_esrfet_fields_names_only(input_dict, esrfet_version):
    input_dict["definition"] = "XAS XRF"

    model = IcatDatasetParameters(**input_dict)
    assert model.definition == ["XAS", "XRF"]
    assert model.technique_pid == [
        "https://w3id.org/PaN/ESRFET#XAS",
        "https://w3id.org/PaN/ESRFET#XRF",
    ]
    assert model.technique_pid_esrfet_version == esrfet_version


def test_esrfet_fields_pids_only(input_dict, esrfet_version):
    input_dict["technique_pid"] = (
        "https://w3id.org/PaN/ESRFET#XAS https://w3id.org/PaN/ESRFET#XRF"
    )

    model = IcatDatasetParameters(**input_dict)
    assert model.definition == ["XAS", "XRF"]
    assert model.technique_pid == [
        "https://w3id.org/PaN/ESRFET#XAS",
        "https://w3id.org/PaN/ESRFET#XRF",
    ]
    assert model.technique_pid_esrfet_version == esrfet_version


def test_esrfet_fields_missing_name(input_dict, esrfet_version):
    input_dict["definition"] = "XAS"
    input_dict["technique_pid"] = (
        "https://w3id.org/PaN/ESRFET#XAS https://w3id.org/PaN/ESRFET#XRF"
    )
    input_dict["technique_pid_esrfet_version"] = esrfet_version

    model = IcatDatasetParameters(**input_dict)

    assert model.definition == ["XAS", "XRF"]
    assert model.technique_pid == [
        "https://w3id.org/PaN/ESRFET#XAS",
        "https://w3id.org/PaN/ESRFET#XRF",
    ]
    assert model.technique_pid_esrfet_version == esrfet_version


def test_esrfet_fields_missing_pid(input_dict, esrfet_version):
    input_dict["definition"] = "XAS XRF"
    input_dict["technique_pid"] = "https://w3id.org/PaN/ESRFET#XAS"
    input_dict["technique_pid_esrfet_version"] = esrfet_version

    model = IcatDatasetParameters(**input_dict)

    assert model.definition == ["XAS", "XRF"]
    assert model.technique_pid == [
        "https://w3id.org/PaN/ESRFET#XAS",
        "https://w3id.org/PaN/ESRFET#XRF",
    ]
    assert model.technique_pid_esrfet_version == esrfet_version


def test_esrfet_fields_only_unknown_name(input_dict, esrfet_version):
    input_dict["definition"] = "UNKNOWN1 UNKNOWN2"

    warning = f"""Invalid ESRF technique reference(s) detected.
Unknown technique names: UNKNOWN1, UNKNOWN2
These entries are not recognized in the ESRFET ontology and will be kept as-is.
Please choose valid techniques from:
https://esrf-ontologies.readthedocs.io/en/{version('icat-esrf-definitions')}/esrfet.html"""

    with pytest.warns(ValidationWarning, match=re.escape(warning)):
        model = IcatDatasetParameters(**input_dict)

    assert model.definition == ["UNKNOWN1", "UNKNOWN2"]
    assert model.technique_pid is None
    assert model.technique_pid_esrfet_version is None


def test_esrfet_fields_unknown_name(input_dict, esrfet_version):
    input_dict["definition"] = "XAS XRF UNKNOWN"
    input_dict["technique_pid"] = (
        "https://w3id.org/PaN/ESRFET#XAS https://w3id.org/PaN/ESRFET#XRF"
    )
    input_dict["technique_pid_esrfet_version"] = esrfet_version

    warning = f"""Invalid ESRF technique reference(s) detected.
Unknown technique names: UNKNOWN
These entries are not recognized in the ESRFET ontology and will be kept as-is.
Please choose valid techniques from:
https://esrf-ontologies.readthedocs.io/en/{version('icat-esrf-definitions')}/esrfet.html"""

    with pytest.warns(ValidationWarning, match=re.escape(warning)):
        model = IcatDatasetParameters(**input_dict)

    assert model.definition == ["XAS", "XRF", "UNKNOWN"]
    assert model.technique_pid == [
        "https://w3id.org/PaN/ESRFET#XAS",
        "https://w3id.org/PaN/ESRFET#XRF",
    ]
    assert model.technique_pid_esrfet_version == esrfet_version


def test_esrfet_fields_only_unknown_pid(input_dict):
    input_dict["technique_pid"] = (
        "https://w3id.org/PaN/ESRFET#UNKNOWN1 https://w3id.org/PaN/ESRFET#UNKNOWN2"
    )

    warning = f"""Invalid ESRF technique reference(s) detected.
Unknown technique PIDs: https://w3id.org/PaN/ESRFET#UNKNOWN1, https://w3id.org/PaN/ESRFET#UNKNOWN2
These entries are not recognized in the ESRFET ontology and will be kept as-is.
Please choose valid techniques from:
https://esrf-ontologies.readthedocs.io/en/{version('icat-esrf-definitions')}/esrfet.html"""

    with pytest.warns(ValidationWarning, match=re.escape(warning)):
        model = IcatDatasetParameters(**input_dict)

    assert model.definition is None
    assert model.technique_pid == [
        "https://w3id.org/PaN/ESRFET#UNKNOWN1",
        "https://w3id.org/PaN/ESRFET#UNKNOWN2",
    ]
    assert model.technique_pid_esrfet_version is None


def test_esrfet_fields_unknown_pid(input_dict, esrfet_version):
    input_dict["definition"] = "XAS XRF"
    input_dict["technique_pid"] = (
        "https://w3id.org/PaN/ESRFET#XAS https://w3id.org/PaN/ESRFET#XRF https://w3id.org/PaN/ESRFET#UNKNOWN"
    )
    input_dict["technique_pid_esrfet_version"] = esrfet_version

    warning = f"""Invalid ESRF technique reference(s) detected.
Unknown technique PIDs: https://w3id.org/PaN/ESRFET#UNKNOWN
These entries are not recognized in the ESRFET ontology and will be kept as-is.
Please choose valid techniques from:
https://esrf-ontologies.readthedocs.io/en/{version('icat-esrf-definitions')}/esrfet.html"""

    with pytest.warns(ValidationWarning, match=re.escape(warning)):
        model = IcatDatasetParameters(**input_dict)

    assert model.definition == ["XAS", "XRF"]
    assert model.technique_pid == [
        "https://w3id.org/PaN/ESRFET#XAS",
        "https://w3id.org/PaN/ESRFET#XRF",
        "https://w3id.org/PaN/ESRFET#UNKNOWN",
    ]
    assert model.technique_pid_esrfet_version == esrfet_version


def test_esrfet_empty_fields(input_dict, esrfet_version):
    input_dict["technique_pid_esrfet_version"] = esrfet_version
    model = IcatDatasetParameters(**input_dict)
    assert model.definition is None
    assert model.technique_pid is None
    assert model.technique_pid_esrfet_version is None


def test_esrfet_no_techique_fields(input_dict, esrfet_version):
    input_dict["technique_pid_esrfet_version"] = esrfet_version
    model = IcatDatasetParameters(**input_dict)
    assert model.definition is None
    assert model.technique_pid is None
    assert model.technique_pid_esrfet_version is None
