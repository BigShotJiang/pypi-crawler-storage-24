from silx.io.dictdump import dicttonx

from ..models import IcatDatasetParameters
from ..models.generate import generate_dataset
from . import compare


def test_nexus(tmp_path, ignore_pydantic_deprecation_warnings):
    dataset = generate_dataset()
    nxdict = dataset.to_nexus_dict()
    filename = str(tmp_path / "dataset.h5")
    dicttonx(nxdict, filename)


def test_icat(ignore_pydantic_deprecation_warnings):
    dataset = generate_dataset()
    icatdict = dataset.to_icat_dict()
    for key, value in icatdict.items():
        assert isinstance(key, str), key
        assert isinstance(value, str), f"{key} = {value}"


def test_roundtrip(ignore_pydantic_deprecation_warnings):
    dataset = generate_dataset()

    python_dict = dataset.model_dump(mode="python", exclude_unset=True, by_alias=True)
    new_dataset = IcatDatasetParameters(**python_dict)
    compare.assert_equal_pydantic_model(new_dataset, dataset)

    json_dict = dataset.model_dump(mode="json", exclude_unset=True, by_alias=True)
    new_dataset = IcatDatasetParameters(**json_dict)
    compare.assert_equal_pydantic_model(new_dataset, dataset)

    nexus_dict = dataset.to_nexus_dict()
    new_dataset = IcatDatasetParameters.from_nexus_dict(nexus_dict)
    compare.assert_equal_pydantic_model(new_dataset, dataset)

    icat_dict = dataset.to_icat_dict()
    new_dataset = IcatDatasetParameters.from_icat_dict(icat_dict)
    compare.assert_equal_pydantic_model(new_dataset, dataset)


def test_unknown_icat_fields(ignore_pydantic_deprecation_warnings):
    dataset = generate_dataset()
    icat_dict = dataset.to_icat_dict()
    icat_dict["UnitTest_unknown1"] = 10
    icat_dict["UnitTest_unknown2"] = 10
    new_dataset, unknown = IcatDatasetParameters.from_icat_dict_known_keys(icat_dict)
    compare.assert_equal_pydantic_model(new_dataset, dataset)
    assert set(unknown) == {"UnitTest_unknown1", "UnitTest_unknown2"}
