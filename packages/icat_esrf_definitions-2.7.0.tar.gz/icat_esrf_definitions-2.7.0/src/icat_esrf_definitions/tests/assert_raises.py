from contextlib import contextmanager
from typing import Any
from typing import Dict
from typing import List

import pytest
from pydantic import ValidationError


@contextmanager
def raises_validationerror(errors: List[Dict[str, Any]]):
    with pytest.raises(ValidationError) as exc_info:
        yield exc_info

    raised = exc_info.value.errors()
    for error in raised:
        _ = error.pop("url")

    assert _normalize_errors(raised) == _normalize_errors(errors)


def _normalize_errors(errors: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    normalized = []

    for err in errors:
        err = err.copy()

        if "ctx" in err:
            ctx = err["ctx"].copy()

            for k, v in ctx.items():
                if isinstance(v, Exception):
                    ctx[k] = _serialize_exception(v)

            err["ctx"] = ctx

        normalized.append(err)

    return normalized


def _serialize_exception(exc: Exception) -> dict:
    data = {
        "type": type(exc).__name__,
        "message": str(exc),
    }

    if exc.__cause__:
        data["cause"] = _serialize_exception(exc.__cause__)

    if exc.__context__ and not exc.__suppress_context__:
        data["context"] = _serialize_exception(exc.__context__)

    return data
