import datetime
import warnings

import pytest
from esrf_ontologies import technique

pytest.register_assert_rewrite("icat_esrf_definitions.tests.compare")
pytest.register_assert_rewrite("icat_esrf_definitions.tests.assert_raises")


@pytest.fixture
def ignore_pydantic_deprecation_warnings():
    """Ignore warnings from deprecated Pydantic fields."""
    with warnings.catch_warnings():
        warnings.filterwarnings(
            "ignore",
            category=DeprecationWarning,
            module="icat_esrf_definitions.models.base.model",
        )
        yield


@pytest.fixture(scope="session")
def esrfet_version() -> str:
    return technique.get_ontology_version_number()


@pytest.fixture()
def input_dict():
    return {
        "title": "dummy title",
        "proposal": "dummy proposal",
        "folder_path": "/dummy/folder/name",
        "start_time": "2032-04-23T10:20:30.400000+02:30",
        "end_time": "2032-04-23T10:20:30.400000+02:30",
        "sample": {"name": "dummy sample"},
    }


@pytest.fixture()
def python_dict():
    return {
        "title": "dummy title",
        "proposal": "dummy proposal",
        "folder_path": "/dummy/folder/name",
        "start_time": datetime.datetime.fromisoformat(
            "2032-04-23T10:20:30.400000+02:30"
        ),
        "end_time": datetime.datetime.fromisoformat("2032-04-23T10:20:30.400000+02:30"),
        "sample": {"name": "dummy sample"},
    }


@pytest.fixture()
def json_dict():
    return {
        "title": "dummy title",
        "proposal": "dummy proposal",
        "folder_path": "/dummy/folder/name",
        "start_time": "2032-04-23T10:20:30.400000+02:30",
        "end_time": "2032-04-23T10:20:30.400000+02:30",
        "sample": {"name": "dummy sample"},
    }


@pytest.fixture()
def nexus_dict():
    return {
        "@NX_class": "NXentry",
        "title": "dummy title",
        "proposal": "dummy proposal",
        "folder_path": "/dummy/folder/name",
        "start_time": "2032-04-23T10:20:30.400000+02:30",
        "end_time": "2032-04-23T10:20:30.400000+02:30",
        "sample": {"@NX_class": "NXsample", "name": "dummy sample"},
    }


@pytest.fixture()
def icat_dict():
    return {
        "datasetName": "dummy title",
        "proposal": "dummy proposal",
        "location": "/dummy/folder/name",
        "startDate": "2032-04-23T10:20:30.400000+02:30",
        "endDate": "2032-04-23T10:20:30.400000+02:30",
        "Sample_name": "dummy sample",
    }
