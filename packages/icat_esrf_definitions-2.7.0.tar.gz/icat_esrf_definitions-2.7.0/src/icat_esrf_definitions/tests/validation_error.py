from typing import Any
from typing import Dict
from typing import List
from typing import Tuple

from pint import DimensionalityError


def build_validation_error_dict(
    input_value: Any,
    error: Exception,
    loc: Tuple[str, ...],
    err_type: str = "value_error",
) -> List[Dict[str, Any]]:
    if err_type == "value_error":
        msg = f"Value error, {error}"
        ctx = {"error": error}
    else:
        msg = str(error)
        ctx = None
    entry = {
        "input": input_value,
        "loc": loc,
        "msg": msg,
        "type": err_type,
    }
    if ctx is not None:
        entry["ctx"] = ctx
    return [entry]


def dimensionality_error(
    input_value: Any,
    from_unit: str,
    to_unit: str,
    from_dim: str,
    to_dim: str,
    loc: Tuple[str, ...] = ("length",),
) -> List[Dict[str, Any]]:
    cause = DimensionalityError(from_unit, to_unit, from_dim, to_dim)
    error = ValueError(str(cause))
    error.__cause__ = cause
    return build_validation_error_dict(input_value, error, loc)


def dimensionless_error(
    input_value: Any, loc: Tuple[str, ...] = ("length",)
) -> List[Dict[str, Any]]:
    error = ValueError(f"{input_value} does not match dimensionality ''")
    return build_validation_error_dict(input_value, error, loc)


def magnitude_int_error(
    input_value: Any, magnitude: float, loc: Tuple[str, ...] = ("length",)
) -> List[Dict[str, Any]]:
    error = ValueError(f"Magnitude {magnitude} cannot be converted to type int")
    return build_validation_error_dict(input_value, error, loc)


def sequence_int_error(
    input_value: Any, item: float, loc: Tuple[str, ...] = ("length",)
) -> List[Dict[str, Any]]:
    error = ValueError(f"Sequence item {item} cannot be converted to type int")
    return build_validation_error_dict(input_value, error, loc)


def extra_forbidden_error(
    input_value: Any, field: str, model_name: str = "PTYCHO"
) -> List[Dict[str, Any]]:
    error = ValueError("Extra inputs are not permitted")
    return build_validation_error_dict(
        input_value, error, (model_name, field), err_type="extra_forbidden"
    )


def invalid_type_error(input_value: Any, loc: Tuple[str, ...]) -> List[Dict[str, Any]]:
    cause = TypeError(f"Invalid type {type(input_value)} (value={input_value!r})")
    error = ValueError(str(cause))
    error.__cause__ = cause
    return build_validation_error_dict(input_value, error, loc)


def min_length_error(
    input_value: Any, min_length: int, loc: Tuple[str, ...]
) -> List[Dict[str, Any]]:
    return [
        {
            "ctx": {"min_length": min_length},
            "input": input_value,
            "loc": loc,
            "msg": f"String should have at least {min_length} characters",
            "type": "string_too_short",
        }
    ]


def pattern_mismatch_error(
    input_value: Any, pattern: str, loc: Tuple[str, ...]
) -> List[Dict[str, Any]]:
    return [
        {
            "ctx": {"pattern": pattern},
            "input": input_value,
            "loc": loc,
            "msg": f"String should match pattern '{pattern}'",
            "type": "string_pattern_mismatch",
        }
    ]


def missing_error(input_value: Any, loc: Tuple[str, ...]) -> List[Dict[str, Any]]:
    return [
        {
            "input": input_value,
            "loc": loc,
            "msg": "Field required",
            "type": "missing",
        }
    ]
