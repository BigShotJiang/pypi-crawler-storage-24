import datetime
import re
from enum import Enum
from typing import Any
from typing import List
from typing import Optional
from typing import Tuple

from pint import Quantity

from .base.custom_types._metadata.quantity import QuantityMeta
from .base.field_utils import FieldConstraints
from .base.field_utils import get_field_metadata
from .base.field_utils import get_field_type
from .base.field_utils import is_renamed_field
from .dataset import IcatDatasetParameters


def generate_dataset(counter: int = 0) -> IcatDatasetParameters:
    icat_dict = dict()

    for icat_name, icat_field_info in IcatDatasetParameters.icat_fields().items():
        if is_renamed_field(icat_field_info):
            continue
        python_type = _python_type_from_annotation(icat_field_info.annotation)
        constraints = icat_field_info.constraints

        if icat_name == "definition":
            value = "XRAYS"
        elif icat_name == "technique_pid":
            value = "https://w3id.org/PaN/ESRFET#XRAYS"
        elif icat_name == "technique_pid_esrfet_version":
            value = "0.1.0"
        elif python_type is List[str]:
            value = [f"item{counter}"]
        elif python_type is List[List[str]]:
            value = [[f"item{counter}"]]
        elif python_type is List[Tuple[int, int]]:
            value = [(counter, counter + 1)]
        elif python_type is List[float]:
            value = [counter + 0.1]
        elif python_type is List[int]:
            value = [counter]
        elif not isinstance(python_type, type):
            raise NotImplementedError(
                f"{icat_name}: Unsupported field type {python_type}"
            )
        elif issubclass(python_type, Enum):
            enum_values = list(python_type)
            value = enum_values[counter % len(enum_values)].value
        elif issubclass(python_type, bool):
            value = bool(counter % 2)
        elif issubclass(python_type, int):
            value = counter
        elif issubclass(python_type, float):
            value = counter + 0.1
        elif issubclass(python_type, str):
            value = generate_string(counter, constraints)
        elif issubclass(python_type, datetime.datetime):
            value = datetime.datetime.fromtimestamp(1_700_000_000 + counter)
        elif issubclass(python_type, Any):
            value = f"any{counter}"
        else:
            raise NotImplementedError(
                f"{icat_name}: Unsupported field type {python_type}"
            )

        unit_info = icat_field_info.unit_info
        if unit_info is not None and unit_info.units is not None:
            value = value, unit_info.units

        icat_dict[icat_name] = value
        counter += 1

    return IcatDatasetParameters.from_icat_dict(icat_dict)


def generate_string(counter: int, constraints: FieldConstraints) -> str:
    min_length = constraints.min_length or 0
    max_length = constraints.max_length or None
    pattern = constraints.pattern

    base = _generate_string_for_pattern(counter, pattern)
    base = _apply_length_constraints(base, min_length, max_length)

    return base


def _generate_string_for_pattern(counter: int, pattern: Optional[str]) -> str:
    if pattern is None:
        return f"string{counter}"

    PATTERN_GENERATORS = [
        (r"^\^10\\\..*", lambda: f"10.1000/{counter}abc"),
    ]
    for pat_prefix, generator in PATTERN_GENERATORS:
        if re.match(pat_prefix, pattern):
            return generator()

    base = f"string{counter}"
    if re.fullmatch(pattern, base):
        return base
    raise NotImplementedError(
        f"No generator defined for pattern: {pattern!r}. "
        "Add an entry to PATTERN_GENERATORS in _generate_string_for_pattern."
    )


def _apply_length_constraints(
    base: str, min_length: int, max_length: Optional[int]
) -> str:
    if len(base) < min_length:
        base += "x" * (min_length - len(base))
    if max_length is not None and len(base) > max_length:
        base = base[:max_length]
    return base


_TYPES = (
    List[List[str]],
    List[Tuple[int, int]],
    List[str],
    Enum,
    str,
    bool,
    int,
    float,
    datetime.datetime,
    Any,
)


def _python_type_from_annotation(annotation) -> Any:
    for type_ in _TYPES:
        field_type = get_field_type(annotation, type_)
        if field_type is not None:
            return field_type

    qtype = get_field_type(annotation, Quantity)
    if qtype is not None:
        meta = get_field_metadata(annotation, QuantityMeta)
        return meta.value_type or float

    raise TypeError(annotation)
