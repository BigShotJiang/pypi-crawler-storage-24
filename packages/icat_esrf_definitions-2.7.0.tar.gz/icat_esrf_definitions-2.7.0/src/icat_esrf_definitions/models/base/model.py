"""Base model to represent ICAT schema's."""

import pathlib
import sys
from copy import deepcopy
from typing import Any
from typing import Dict
from typing import Generator
from typing import List
from typing import Tuple
from typing import Union

import pint
from pydantic import BaseModel
from pydantic import ValidationError
from pydantic import model_validator

if sys.version_info < (3, 11):
    from typing_extensions import Self
else:
    from typing import Self

try:
    import xmltodict
except ImportError:
    xmltodict = None

from . import field_utils
from . import icat
from .field_utils import extract_constraints
from .field_utils import has_custom_serialization
from .field_utils import is_renamed_field
from .field_utils import resolve_field_description

_ALLOWED_EXTRA_KEYS = {
    "icat_name": {"include_in_xml": False, "description": "ICAT field name"},
    "record": {"include_in_xml": True, "description": "Record type"},
    "include_nexus_url": {
        "include_in_xml": False,
        "description": "Flag to automatically generate the NeXus URL",
    },
    "rename_to": {
        "include_in_xml": False,
        "description": "Name of the field that replaces this deprecated field.",
    },
}

_ALLOWED_RECORD_VALUES = {"initial", "final"}


class IcatNexusBaseModel(BaseModel, extra="forbid", validate_assignment=True):
    """Base model for ICAT/NeXus metadata parameters.

    Model instances (i.e. includes values) can be converted to and from
    the following python dictionaries:

    - ICAT: flat dictionary with ICAT database key-value pairs.
    - NeXus: nested dictionary with Nexus groups, fields and attributes
             following the Silx dictdump schema.

    Numeric fields with units or unit dimensions are supported.

    Model classes (i.e. no values) can be converted to the following
    schema's

    - XML model: original ICAT dataset metadata XML description (without XSD schema).
    - Any schema supported by Pydantic like JSON schema.
    """

    @classmethod
    def __pydantic_init_subclass__(cls, *args, **kwargs) -> Any:
        """Validate the JSON extra keys of all fields."""
        result = super().__pydantic_init_subclass__(*args, **kwargs)
        for field_name, field_info in cls.model_fields.items():
            extras: Dict[str, Any] = field_info.json_schema_extra or {}

            allowed_keys = set(_ALLOWED_EXTRA_KEYS.keys())
            unknown_keys = set(extras) - allowed_keys
            if unknown_keys:
                raise ValueError(
                    f"Field '{field_name}' in '{cls.__name__}' contains invalid json_schema_extra keys: {unknown_keys}. "
                    f"Allowed keys are: {allowed_keys}"
                )

            if "record" in extras:
                record_value = extras["record"]
                if record_value not in _ALLOWED_RECORD_VALUES:
                    raise ValueError(
                        f"Field '{field_name}' in '{cls.__name__}' has invalid 'record' value: {record_value}. "
                        f"Allowed values are: {_ALLOWED_RECORD_VALUES}"
                    )

        return result

    @model_validator(mode="before")
    @classmethod
    def parse_nexus_style_units(cls, data: Any) -> Any:
        """
        Looks for NeXus-style quantity definitions (e.g., 'beamSize' and 'beamSize@units')
        in the input data and converts them into a format `BaseQuantityMeta` understands
        (e.g., {'beamSize': [magnitude, unit_str]}) before field validation.
        """
        if not isinstance(data, dict):
            return data

        modified_data = data.copy()
        keys_to_remove = set()

        for field_name, field_info in cls.model_fields.items():
            quantity_type = field_utils.get_field_type(
                field_info.annotation, pint.Quantity
            )
            if not quantity_type:
                continue

            # Field, attribute or group alias
            alias = field_info.alias or field_name
            units_key = f"{alias}@units"
            if alias in modified_data and units_key in modified_data:
                magnitude = modified_data[alias]
                unit_or_dimension = modified_data[units_key]
                modified_data[alias] = [magnitude, unit_or_dimension]
                keys_to_remove.add(units_key)

        for key in keys_to_remove:
            del modified_data[key]

        return modified_data

    @classmethod
    def icat_field_names(cls, parent_prefix: str = "") -> List[str]:
        return list(cls._iter_icat_names(parent_prefix))

    @classmethod
    def icat_field_names_with_validation_error(
        cls, error: ValidationError
    ) -> List[str]:
        locations = [e["loc"] for e in error.errors() if "loc" in e]
        return cls._locations_to_icat_names(locations, "")

    @classmethod
    def icat_fields(
        cls, parent_prefix: str = "", parent_nexus_nodes=()
    ) -> Dict[str, field_utils.IcatFieldInfo]:
        return {
            info.icat_name: info
            for info in cls._iter_icat_field_info(parent_prefix, parent_nexus_nodes)
        }

    def to_icat_dict(self, parent_prefix: str = "") -> Dict[str, str]:
        """Convert a Pydantic model instance to an ICAT-ingester-compliant dict."""
        return self._to_icat_dict(parent_prefix)

    @classmethod
    def from_icat_dict(
        cls, icat_data: Dict[str, Any], parent_prefix: str = ""
    ) -> "IcatNexusBaseModel":
        """Create a Pydantic model instance from an ICAT-ingester-compliant dict."""
        model_data, unknown_keys = cls._from_icat_dict(icat_data, parent_prefix)
        if unknown_keys:
            raise ValueError(f"Unknown ICAT fields: {unknown_keys}")
        return cls(**model_data)

    @classmethod
    def from_icat_dict_known_keys(
        cls, icat_data: Dict[str, Any], parent_prefix: str = ""
    ) -> Tuple["IcatNexusBaseModel", List[str]]:
        """Create a Pydantic model instance from the known keys of a ICAT-ingester-compliant dict."""
        model_data, unknown_keys = cls._from_icat_dict(icat_data, parent_prefix)
        return cls(**model_data), unknown_keys

    @classmethod
    def to_xml_model_dict(
        cls, group_name: str = "${entry}", parent_prefix: str = ""
    ) -> Dict[str, Any]:
        """Convert the Pydantic model to an XML dict following the
        original XML structure that tried to describe ICAT dataset
        parameters without an XSD schema.
        """
        return cls._to_xml_model_dict(group_name, parent_prefix)

    @classmethod
    def to_xml_model_file(
        cls,
        xml_file: Union[str, bytes, pathlib.Path],
        group_name: str = "${entry}",
        parent_prefix: str = "",
    ) -> None:
        """Convert the Pydantic model to an XML file following the
        original XML structure that tried to describe ICAT dataset
        parameters without an XSD schema.
        """
        with open(xml_file, mode="w", encoding="utf-8") as fh:
            fh.write(
                cls.to_xml_model_string(
                    group_name=group_name, parent_prefix=parent_prefix
                )
            )

    @classmethod
    def to_xml_model_string(
        cls, group_name: str = "${entry}", parent_prefix: str = ""
    ) -> str:
        """Convert the Pydantic model to an XML string following the
        original XML structure that tried to describe ICAT dataset
        parameters without an XSD schema.
        """
        xml_dict = cls.to_xml_model_dict(
            group_name=group_name, parent_prefix=parent_prefix
        )
        return cls._xml_dict_to_string(xml_dict)

    def to_nexus_dict(self) -> Dict[str, Any]:
        """Convert a Pydantic model instance to a NeXus-compliant dict."""
        return self._to_nexus_dict()

    @classmethod
    def from_nexus_dict(cls, nexus_data: Dict[str, Any]) -> "IcatNexusBaseModel":
        """Create a Pydantic model instance from a NeXus-compliant dict."""
        return cls(**nexus_data)

    def _to_icat_dict(self, parent_prefix: str) -> Dict[str, str]:
        icat_data = dict()
        modes = {"icat": set(), "json": set()}
        alias_to_icat_short_name = dict()

        for field_name, field_info in type(self).model_fields.items():
            # Field or group alias, skip attributes
            alias = field_info.alias or field_name
            if alias.startswith("@"):
                continue

            # ICAT field name with respect to parent group
            if field_info.json_schema_extra:
                short_icat_name = field_info.json_schema_extra.get("icat_name", alias)
            else:
                short_icat_name = alias
            alias_to_icat_short_name[alias] = short_icat_name

            # Dump value
            value = getattr(self, field_name)
            if isinstance(value, IcatNexusBaseModel):
                # Dump group
                field_prefix = icat.icat_field_prefix(parent_prefix, short_icat_name)
                icat_data.update(value._to_icat_dict(field_prefix))
            elif has_custom_serialization(field_info.annotation):
                # Dump field later
                modes["icat"].add(field_name)
            else:
                # Dump field later
                modes["json"].add(field_name)

        # Dump fields
        for mode, include in modes.items():
            fields = self.model_dump(
                exclude_none=True,
                by_alias=True,
                mode=mode,
                include=include,
            )
            # Full ICAT key names (including parent prefix) with values as strings
            icat_data.update(
                {
                    icat.icat_field_name(
                        parent_prefix, alias_to_icat_short_name.get(alias, alias)
                    ): _to_icat_value(alias, value)
                    for alias, value in fields.items()
                }
            )

        return icat_data

    @classmethod
    def _locations_to_icat_names(
        cls, locations: List[Tuple[str, ...]], parent_prefix: str
    ) -> List[str]:
        icat_names = []

        for loc in locations:
            field_name = loc[0]
            field_info = cls.model_fields[field_name]

            # Field or group alias, skip attributes
            alias = field_info.alias or field_name
            if alias.startswith("@"):
                continue

            # ICAT field name with respect to parent group
            if field_info.json_schema_extra:
                short_icat_name = field_info.json_schema_extra.get("icat_name", alias)
            else:
                short_icat_name = alias

            # Check if group
            group_model = field_utils.get_field_type(
                field_info.annotation, IcatNexusBaseModel
            )

            if group_model and len(loc) > 1:
                # Recurse into group
                field_prefix = icat.icat_field_prefix(parent_prefix, short_icat_name)
                icat_names.extend(
                    group_model._locations_to_icat_names([loc[1:]], field_prefix)
                )
                continue

            # Leaf field
            icat_name = icat.icat_field_name(parent_prefix, short_icat_name)
            icat_names.append(icat_name)

        return icat_names

    @classmethod
    def _from_icat_dict(
        cls, icat_data: Dict[str, Any], parent_prefix: str, _top: bool = True
    ) -> Tuple[Dict[str, Any], List[str]]:
        result = dict()

        if _top:
            icat_data = deepcopy(icat_data)

        for field_name, field_info in cls.model_fields.items():
            # Field or group alias
            alias = field_info.alias or field_name
            if alias.startswith("@"):
                continue

            # ICAT field name with respect to parent group
            if field_info.json_schema_extra:
                short_icat_name = field_info.json_schema_extra.get("icat_name", alias)
            else:
                short_icat_name = alias

            # Load group
            group_model = field_utils.get_field_type(
                field_info.annotation, IcatNexusBaseModel
            )
            if group_model:
                field_prefix = icat.icat_field_prefix(parent_prefix, short_icat_name)
                subdata, _ = group_model._from_icat_dict(
                    icat_data, field_prefix, _top=False
                )
                if subdata:
                    result[alias] = subdata
                continue

            # Pop field value
            icat_name = icat.icat_field_name(parent_prefix, short_icat_name)
            if icat_name in icat_data:
                result[alias] = icat_data.pop(icat_name)

        # Field keys which are not popped are unknown.

        return result, list(icat_data)

    @classmethod
    def _iter_icat_names(cls, parent_prefix: str) -> Generator[str, None, None]:
        for field_name, field_info in cls.model_fields.items():
            # Field or group alias
            alias = field_info.alias or field_name
            if alias.startswith("@"):
                continue

            # ICAT field name with respect to parent group
            if field_info.json_schema_extra:
                short_icat_name = field_info.json_schema_extra.get("icat_name", alias)
            else:
                short_icat_name = alias

            # Traverse group
            group_model = field_utils.get_field_type(
                field_info.annotation, IcatNexusBaseModel
            )
            if group_model:
                field_prefix = icat.icat_field_prefix(parent_prefix, short_icat_name)
                yield from group_model._iter_icat_names(field_prefix)
                continue

            # Full ICAT field name
            icat_name = icat.icat_field_name(parent_prefix, short_icat_name)
            yield icat_name

    @classmethod
    def _iter_icat_field_info(
        cls, parent_prefix: str, parent_nexus_nodes: Tuple[str, ...]
    ) -> Generator[field_utils.IcatFieldInfo, None, None]:
        for field_name, field_info in cls.model_fields.items():
            # Field or group alias
            alias = field_info.alias or field_name
            if alias.startswith("@"):
                continue
            # ICAT field name with respect to parent group
            if field_info.json_schema_extra:
                short_icat_name = field_info.json_schema_extra.get("icat_name", alias)
            else:
                short_icat_name = alias

            nexus_nodes = parent_nexus_nodes + (field_name,)

            # Traverse group
            group_model = field_utils.get_field_type(
                field_info.annotation, IcatNexusBaseModel
            )
            if group_model:
                field_prefix = icat.icat_field_prefix(parent_prefix, short_icat_name)
                yield from group_model._iter_icat_field_info(field_prefix, nexus_nodes)
                continue

            # Field info
            icat_name = icat.icat_field_name(parent_prefix, short_icat_name)

            unit_info = field_utils.get_unit_info(field_info.annotation)
            nexus_type = field_utils.get_nexus_type(field_info.annotation)

            if field_info.json_schema_extra:
                record = field_info.json_schema_extra.get("record", None)
                rename_to = field_info.json_schema_extra.get("rename_to", None)
            else:
                record = None
                rename_to = None
            rename_to_icat_name = None
            if rename_to is not None:
                rename_to_icat_name = icat.icat_field_name(parent_prefix, rename_to)
            constraints = extract_constraints(field_info)
            yield field_utils.IcatFieldInfo(
                icat_name=icat_name,
                nexus_nodes=nexus_nodes,
                description=resolve_field_description(
                    model_cls=cls,
                    field_name=field_name,
                    field_info=field_info,
                ),
                required=field_info.is_required(),
                unit_info=unit_info,
                nexus_type=nexus_type,
                annotation=field_info.annotation,
                record=record,
                deprecated=field_info.deprecated,
                rename_to=rename_to_icat_name,
                constraints=constraints,
            )

    @classmethod
    def _to_xml_model_dict(cls, group_name: str, parent_prefix: str) -> Dict[str, Any]:
        xml_group_data = {"@groupName": group_name}
        groups = list()
        for field_name, field_info in cls.model_fields.items():
            # Field, attribute or group alias
            alias = field_info.alias or field_name

            # Store attribute
            if alias.startswith("@"):
                xml_group_data[alias] = field_info.default
                continue

            # ICAT field name with respect to parent group
            if field_info.json_schema_extra:
                short_icat_name = field_info.json_schema_extra.get("icat_name", alias)
            else:
                short_icat_name = alias

            # Store group
            group_model = field_utils.get_field_type(
                field_info.annotation, IcatNexusBaseModel
            )
            if group_model:
                field_prefix = icat.icat_field_prefix(parent_prefix, short_icat_name)
                group_attrs = group_model._to_xml_model_dict(alias, field_prefix)

                if field_info.description is not None:
                    group_attrs["@ESRF_description"] = resolve_field_description(
                        model_cls=cls,
                        field_name=field_name,
                        field_info=field_info,
                    )

                groups.append(group_attrs)
                continue

            # Store field
            field_attrs = dict()
            if field_info.is_required():
                field_attrs["@ESRF_mandatory"] = "Mandatory"

            if field_info.description is not None:
                field_attrs["@ESRF_description"] = resolve_field_description(
                    model_cls=cls,
                    field_name=field_name,
                    field_info=field_info,
                )
            if field_info.deprecated:
                field_attrs["@ESRF_deprecated"] = field_info.deprecated

            field_attrs["@NAPItype"] = field_utils.get_nexus_type(field_info.annotation)

            unit_info = field_utils.get_unit_info(field_info.annotation)
            if unit_info is not None:
                field_attrs["@units"] = unit_info.as_str_xml()

            if field_info.json_schema_extra:
                for k, v in field_info.json_schema_extra.items():
                    if v is None:
                        continue
                    include_in_xml = _ALLOWED_EXTRA_KEYS.get(k, {}).get(
                        "include_in_xml", True
                    )
                    if not include_in_xml:
                        continue
                    field_attrs[f"@{k}"] = v

            icat_name = icat.icat_field_name(parent_prefix, short_icat_name)
            field_attrs["#text"] = f"${{{icat_name}}}"
            xml_group_data[field_name] = field_attrs

        # Copy groups
        if groups:
            if len(groups) == 1:
                xml_group_data["group"] = groups[0]
            else:
                xml_group_data["group"] = groups

        return xml_group_data

    @classmethod
    def _xml_string_to_dict(cls, xml_string: str) -> dict:
        if xmltodict is None:
            raise RuntimeError("Requires 'xmltodict'")
        data = xmltodict.parse(xml_string)[cls.__name__]
        if data is None:
            return dict()
        return data

    @classmethod
    def _xml_dict_to_string(cls, xml_dict: dict) -> str:
        if xmltodict is None:
            raise RuntimeError("Requires 'xmltodict'")
        return xmltodict.unparse({"group": xml_dict}, pretty=True, indent=4)

    def _to_nexus_dict(self) -> Dict[str, Any]:
        nexus_data = dict()
        modes = {"nexus": set(), "json": set()}

        for field_name, field_info in type(self).model_fields.items():
            # Field, attribute or group alias
            alias = field_info.alias or field_name

            # Dump value
            value = getattr(self, field_name)
            if isinstance(value, IcatNexusBaseModel):
                # Dump group
                nexus_data[alias] = value.to_nexus_dict()
            elif isinstance(value, pint.Quantity):
                # Dump field attributes now and field value later
                nexus_data[f"{alias}@units"] = str(value.units)
                modes["nexus"].add(field_name)
            elif has_custom_serialization(field_info.annotation):
                # Dump field later
                modes["nexus"].add(field_name)
            else:
                # Dump field later
                modes["json"].add(field_name)

        # Dump fields
        for mode, include in modes.items():
            fields = self.model_dump(
                exclude_none=True,
                by_alias=True,
                mode=mode,
                include=include,
            )
            nexus_data.update(fields)

        return nexus_data

    @classmethod
    def icat_fields_non_renamed(cls) -> Dict[str, field_utils.IcatFieldInfo]:
        """Return ICAT fields excluding renamed fields."""
        all_fields = cls.icat_fields()
        return {
            icat_name: field_info
            for icat_name, field_info in all_fields.items()
            if not is_renamed_field(field_info)
        }

    @model_validator(mode="after")
    def rename_fields(self) -> Self:
        for name, field in type(self).model_fields.items():

            extra = field.json_schema_extra or {}
            target = extra.get("rename_to")
            if not target:
                continue

            if name not in self.model_fields_set:
                continue

            value = getattr(self, name)

            if target in self.model_fields_set:
                continue

            setattr(self, target, value)
            self.model_fields_set.add(target)

            # unset deprecated field
            setattr(self, name, None)
            self.model_fields_set.discard(name)

        return self


def _to_icat_value(name: str, value: Union[str, int, float, bool]) -> str:
    if isinstance(value, str):
        return value
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    raise TypeError(
        f"Unsupported type for ICAT parameter: {name} = {type(value).__name__}"
    )
