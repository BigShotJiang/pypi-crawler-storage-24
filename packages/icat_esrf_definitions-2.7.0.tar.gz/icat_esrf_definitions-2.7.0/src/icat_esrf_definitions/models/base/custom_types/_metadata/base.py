from abc import ABC
from abc import abstractmethod
from typing import Any
from typing import Dict
from typing import Optional

import pydantic
from pydantic.json_schema import JsonSchemaValue
from pydantic_core import core_schema


class CustomTypeMetadata(ABC):
    """`Annotated` metadata class with custom validation and JSON/Python serialization.

    The `_validate` and `_serialize` methods need to be implemented by deriving a class.

    Usage:

    .. code-block:: python

        class MyModel(BaseModel):
            field: Annotated[..., CustomTypeMetadata({...})]
    """

    def __init__(self, json_schema: Dict[str, Any]) -> None:
        self._json_schema = json_schema

    def __get_pydantic_core_schema__(
        self, source: Any, handler: pydantic.GetCoreSchemaHandler
    ) -> core_schema.CoreSchema:
        """Custom validation and JSON/Python serialization for Pydantic."""
        validator = core_schema.no_info_plain_validator_function(
            self._validate_with_valueerror
        )
        return core_schema.json_or_python_schema(
            json_schema=validator,
            python_schema=validator,
            serialization=core_schema.plain_serializer_function_ser_schema(
                self._serialize, info_arg=True
            ),
        )

    def __get_pydantic_json_schema__(
        self, schema: core_schema.CoreSchema, handler: pydantic.GetJsonSchemaHandler
    ) -> JsonSchemaValue:
        """JSON schema for Pydantic."""
        return self._json_schema

    def _validate_with_valueerror(self, value: Any) -> Any:
        """
        Ensures validation only raises `ValueError`.

        :raises ValueError:
        """
        try:
            return self._validate(value)
        except Exception as ex:
            if isinstance(ex, ValueError):
                raise
            raise ValueError(str(ex)) from ex

    @abstractmethod
    def _validate(self, value: Any) -> Any:
        """Convert the value type that Pydantic can coerce to the field type.

        The value could be Python, JSON, ICAT or NeXus serialized.
        """
        pass

    def _serialize(self, value: Any, info: core_schema.SerializationInfo) -> Any:
        """JSON or Python serialization of the field value from the model instance."""
        if info.mode == "python":
            return self._python_serialize(value)
        if info.mode == "json":
            return self._json_serialize(value)
        if info.mode == "icat":
            return self._icat_serialize(value)
        if info.mode == "nexus":
            return self._nexus_serialize(value)
        raise ValueError(f"Unknown pydantic serialization mode {info.mode!r}")

    def _python_serialize(self, value: Any) -> Any:
        """Python serialization of the field value from the model instance."""
        return value

    def _json_serialize(self, value: Any) -> Any:
        """JSON serialization of the field value from the model instance."""
        return value

    def _nexus_serialize(self, value: Any) -> Any:
        """NeXus serialization of the field value from the model instance."""
        return value

    def _icat_serialize(self, value: Any) -> Optional[str]:
        """ICAT serialization of the field value from the model instance."""
        if value is None:
            return None
        if isinstance(value, (int, float, str)):
            return str(value)
        raise TypeError(
            f"{type(self)} has no ICAT serialization implemented for type {type(value)}"
        )
