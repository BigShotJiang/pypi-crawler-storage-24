import warnings
from importlib.metadata import version
from typing import List
from typing import Optional
from typing import Tuple

from esrf_ontologies import technique

from ...errors import ValidationWarning


def validate_fields(
    definition: Optional[List[str]],
    technique_pid: Optional[List[str]],
    technique_pid_esrfet_version: Optional[str],
) -> Tuple[Optional[List[str]], Optional[List[str]], Optional[str]]:
    """
    A `ValidationWarning` is emitted for each item of 'definition' and
    'technique_pid' that is not known by the ESRFET ontology.

    Missing 'definition' or 'technique_pid' items are added without warning.

    Missing 'technique_pid_esrfet_version' is added without warning.
    """
    if not definition and not technique_pid:
        return definition, technique_pid, None

    techniques = set()

    # Parse definition
    unknown_names = []
    for name in definition or []:
        try:
            techniques.add(technique.get_technique(name))
        except KeyError:
            unknown_names.append(name)

    # Parse technique_pid
    unknown_pids = []
    for pid in technique_pid or []:
        try:
            techniques.add(technique.get_technique(pid))
        except KeyError:
            unknown_pids.append(pid)

    # Warn about unknowns
    if unknown_names or unknown_pids:
        parts = []
        if unknown_names:
            parts.append(f"Unknown technique names: {', '.join(unknown_names)}")
        if unknown_pids:
            parts.append(f"Unknown technique PIDs: {', '.join(unknown_pids)}")

        warning = (
            "Invalid ESRF technique reference(s) detected.\n"
            + "\n".join(parts)
            + "\nThese entries are not recognized in the ESRFET ontology and will be kept as-is.\n"
            "Please choose valid techniques from:\n"
            f"https://esrf-ontologies.readthedocs.io/en/{version('icat-esrf-definitions')}/esrfet.html"
        )

        warnings.warn(warning, ValidationWarning, stacklevel=2)

    # Overwrite ICAT technique metadata
    if not techniques:
        return definition, technique_pid, technique_pid_esrfet_version

    metadata_generator = technique.TechniqueMetadata(techniques=techniques)
    metadata = metadata_generator.get_dataset_metadata()
    definition = metadata["definition"].split()
    technique_pid = metadata["technique_pid"].split()
    technique_pid_esrfet_version = metadata["technique_pid_esrfet_version"]
    if unknown_names:
        definition.extend(unknown_names)
    if unknown_pids:
        technique_pid.extend(unknown_pids)

    return definition, technique_pid, technique_pid_esrfet_version
