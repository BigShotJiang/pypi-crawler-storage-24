# (C) 2023 GoodData Corporation
import builtins

from attrs import define
from gooddata_api_client.model.dashboard_permissions import DashboardPermissions
from gooddata_api_client.model.granted_permission import GrantedPermission
from gooddata_api_client.model.rule_permission import RulePermission
from gooddata_api_client.model.user_group_permission import UserGroupPermission
from gooddata_api_client.model.user_permission import UserPermission

from gooddata_sdk.catalog.base import Base


@define(kw_only=True)
class CatalogGrantedPermission(Base):
    level: str
    source: str

    @staticmethod
    def client_class() -> type[GrantedPermission]:
        return GrantedPermission


@define(kw_only=True)
class CatalogUserPermission(Base):
    id: str
    name: str | None = None
    email: str | None = None
    permissions: list[CatalogGrantedPermission] | None = None

    @staticmethod
    def client_class() -> type[UserPermission]:
        return UserPermission


@define(kw_only=True)
class CatalogUserGroupPermission(Base):
    id: str
    name: str | None = None
    permissions: list[CatalogGrantedPermission] | None = None

    @staticmethod
    def client_class() -> type[UserGroupPermission]:
        return UserGroupPermission


@define(kw_only=True)
class CatalogRulePermission(Base):
    type: str
    permissions: list[str] | None = None

    @staticmethod
    def client_class() -> builtins.type[RulePermission]:  # noqa: UP006
        return RulePermission


@define(kw_only=True)
class CatalogDashboardPermissions(Base):
    rules: list[CatalogRulePermission]
    user_groups: list[CatalogUserGroupPermission]
    users: list[CatalogUserPermission]

    @staticmethod
    def client_class() -> type[DashboardPermissions]:
        return DashboardPermissions
