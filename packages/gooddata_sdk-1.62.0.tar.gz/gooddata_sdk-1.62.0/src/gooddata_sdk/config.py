# (C) 2024 GoodData Corporation
import os
from typing import Any, TypeVar

from attrs import asdict, define
from cattrs import structure
from cattrs.errors import ClassValidationError
from dotenv import load_dotenv

T = TypeVar("T", bound="ConfigBase")


@define
class ConfigBase:
    def to_dict(self) -> dict[str, str]:
        return asdict(self)

    @classmethod
    def from_dict(cls: type[T], data: dict[str, Any]) -> T:
        return structure(data, cls)

    @classmethod
    def can_structure(cls: type[T], data: dict[str, Any]) -> bool:
        try:
            cls.from_dict(data)
            return True
        except ClassValidationError:
            return False


@define
class Profile(ConfigBase):
    host: str
    token: str
    custom_headers: dict[str, str] | None = None
    extra_user_agent: str | None = None
    ssl_ca_cert: str | None = None

    def to_dict(self, use_env: bool = False) -> dict[str, str]:
        load_dotenv()
        if not use_env:
            return asdict(self)
        env_var = self.token[1:]
        if env_var not in os.environ:
            raise ValueError(f"Environment variable {env_var} not found")
        return {**asdict(self), "token": os.environ[env_var]}


@define
class AacConfig(ConfigBase):
    profiles: dict[str, Profile]
    default_profile: str
    access: dict[str, str]

    def ds_credentials(self) -> dict[str, str]:
        load_dotenv()
        return {k: os.environ.get(v[1:], v) for k, v in self.access.items()}
