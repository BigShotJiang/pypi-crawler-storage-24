Developing an intermediate layer library for Gstreamer
Currently in the development stage