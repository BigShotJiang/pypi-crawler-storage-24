from .exceptions import *
from .branch import FlowBranch

import gi  # noqa
gi.require_version('Gst', '1.0')  # noqa
from gi.repository import Gst, GLib


class BaseFlow:
    def __init__(self, flow_name: str):
        self.flow_name: str = flow_name
        self.pipeline: Gst.Pipeline = None
        self.bus: Gst.Bus = None
        self.loop = GLib.MainLoop()

    def _on_message(self, bus, message):
        if message.type == Gst.MessageType.EOS:
            self.loop.quit()
        elif message.type == Gst.MessageType.ERROR:
            self.loop.quit()
            error, debug = message.parse_error()
            raise BusMessageError(error, debug)
        elif message.type == Gst.MessageType.WARNING:
            warn, debug = message.parse_warning()
            print(f"总线消息警告: {warn}, {debug}")

    def _set_state(self, state: Gst.State):
        ret = self.pipeline.set_state(state)
        if ret == Gst.StateChangeReturn.FAILURE:
            raise PipelineSetStateError()

    def create_pipeline(self, pipeline_name: str):
        self.pipeline = Gst.Pipeline.new(pipeline_name)
        if not self.pipeline:
            raise PipelineCreateFailedError(self.name)
        self.bus = self.pipeline.get_bus()
        self.bus.add_signal_watch()
        self.bus.connect("message", self._on_message)

    def create_branch(self) -> FlowBranch:
        return FlowBranch(self.pipeline)

    def link_branch(self, branch1: FlowBranch, branch2: FlowBranch):
        if not Gst.Element.link(branch1.elements[-1], branch2.elements[0]):
            raise ElementLinkFailedError(
                branch1.elements[-1].name, branch2.elements[0].name)

    def start(self):
        try:
            self._set_state(Gst.State.PLAYING)
            self.loop.run()
            self._set_state(Gst.State.NULL)
        except KeyboardInterrupt:
            self.pipeline.send_event(Gst.Event.new_eos())

    def stop(self):
        if self.pipeline:
            self.pipeline.send_event(Gst.Event.new_eos())
            self.pipeline._set_state(Gst.State.NULL)
