from .exceptions import *

import gi  # noqa
gi.require_version('Gst', '1.0')  # noqa
from gi.repository import Gst, GLib


class FlowBranch:
    def __init__(self, pipeline: Gst.Pipeline):
        self.pipeline: Gst.Pipeline = pipeline
        self.elements: list[Gst.Element] = []

    def _link_element(self, element: Gst.Element):
        if self.elements:
            if not Gst.Element.link(self.elements[-1], element):
                raise ElementLinkFailedError(
                    self.elements[-1].name, element.name)
        self.elements.append(element)

    def append_element(self, factory_name: str, name: str, properties: dict = None):
        element = Gst.ElementFactory.make(factory_name, name)
        if not element:
            raise ElementCreateFailedError()
        if properties:
            for property_name, property_value in properties.items():
                element.set_property(property_name, property_value)
        self.pipeline.add(element)
        self._link_element(element)
        return element
