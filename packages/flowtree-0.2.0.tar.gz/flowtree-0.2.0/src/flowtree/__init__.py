__version__ = "0.2.0"

from .video_flow import VideoFlow
from .audio_flow import AudioFlow
from .media_flow import MediaFlow

import gi  # noqa
gi.require_version('Gst', '1.0')  # noqa
from gi.repository import Gst
Gst.init(None)  # 初始化GStreamer
