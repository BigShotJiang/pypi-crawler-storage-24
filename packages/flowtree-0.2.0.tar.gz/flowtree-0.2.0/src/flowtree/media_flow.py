from .core import BaseFlow
from .core import FlowBranch
from .core import ElementLinkFailedError

import gi  # noqa
gi.require_version('Gst', '1.0')  # noqa
from gi.repository import Gst


class MediaFlow(BaseFlow):
    def __init__(self, flow_name: str = "mediaflow"):
        super().__init__(flow_name)
        self.camera_path: str = None
        self.camera_type: str = None
        self.frame_width: int = None
        self.frame_height: int = None
        self.frame_rate: int = None

        self.microphone_device: str = None
        self.microphone_type: str = None
        self.microphone_samplerate: int = None
        self.microphone_channels: int = None

    def set_camera(self, camera_path: str, frame_type: str, frame_width: int, frame_height: int, frame_rate: int):
        self.camera_path = camera_path
        self.camera_type = frame_type
        self.frame_width = frame_width
        self.frame_height = frame_height
        self.frame_rate = frame_rate

    def set_microphone(self, microphone_device: str, frame_type: str, microphone_samplerate: int, microphone_channels: int):
        self.microphone_device = microphone_device
        self.microphone_type = frame_type
        self.microphone_samplerate = microphone_samplerate
        self.microphone_channels = microphone_channels

    def start(self):
        self.create_pipeline(self.flow_name+"_pipeline")

        video_branch = self.create_branch()
        audio_branch = self.create_branch()
        file_branch = self.create_branch()

        video_branch.append_element("v4l2src", "video_source", properties={
            "device": self.camera_path, "num-buffers": 300})
        video_branch.append_element("capsfilter", "video_capsfilter", properties={
            "caps": Gst.Caps.from_string(f"{self.camera_type},width={self.frame_width},height={self.frame_height},framerate={self.frame_rate}/1")})
        video_branch.append_element("mppjpegdec", "jpegdec")
        video_branch.append_element("videoconvert", "videoconvert")
        video_branch.append_element("queue", "video_queue1")
        video_branch.append_element("mpph264enc", "h264enc")
        video_branch.append_element("h264parse", "h264parse")
        video_branch.append_element("queue", "video_queue2")

        audio_branch.append_element("alsasrc", "audio_source", properties={
            "device": self.microphone_device})
        audio_branch.append_element("audioconvert", "audioconvert")
        audio_branch.append_element("capsfilter", "audio_capsfilter", properties={
            "caps": Gst.Caps.from_string(f"{self.microphone_type}, rate={self.microphone_samplerate}, channels={self.microphone_channels}")})
        audio_branch.append_element("lamemp3enc", "lamemp3enc", properties={
            "target": 1, "bitrate": 128, "cbr": True})
        audio_branch.append_element("queue", "audio_queue")

        file_branch.append_element("mp4mux", "mp4mux")
        file_branch.append_element("filesink", "sink", properties={
            "location": "output.mp4"})

        self.link_branch(video_branch, file_branch)
        self.link_branch(audio_branch, file_branch)

        super().start()
