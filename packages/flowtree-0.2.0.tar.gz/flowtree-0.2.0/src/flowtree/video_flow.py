from .core import BaseFlow
from .core import FlowBranch

import gi  # noqa
gi.require_version('Gst', '1.0')  # noqa
from gi.repository import Gst


class VideoFlow(BaseFlow):
    def __init__(self, flow_name: str = "videoflow"):
        super().__init__(flow_name)
        self.camera_path: str = None
        self.frame_type: str = None
        self.frame_width: int = None
        self.frame_height: int = None
        self.frame_rate: int = None

    def set_camera(self, camera_path: str, frame_type: str, frame_width: int, frame_height: int, frame_rate: int):
        self.camera_path = camera_path
        self.frame_type = frame_type
        self.frame_width = frame_width
        self.frame_height = frame_height
        self.frame_rate = frame_rate

    def start(self):
        self.create_pipeline(self.flow_name+"_pipeline")

        main_branch = self.create_branch()

        main_branch.append_element("v4l2src", "source", properties={
            "device": self.camera_path, "num-buffers": 300})
        main_branch.append_element("capsfilter", "capsfilter", properties={
            "caps": Gst.Caps.from_string(f"{self.frame_type},width={self.frame_width},height={self.frame_height},framerate={self.frame_rate}/1")})
        main_branch.append_element("mppjpegdec", "jpegdec")
        main_branch.append_element("videoconvert", "videoconvert")
        main_branch.append_element("queue", "queue")
        main_branch.append_element("mpph264enc", "h264enc")
        main_branch.append_element("h264parse", "h264parse")
        main_branch.append_element("mp4mux", "mp4mux")
        main_branch.append_element("filesink", "sink", properties={
            "location": "output.mp4"})

        super().start()
