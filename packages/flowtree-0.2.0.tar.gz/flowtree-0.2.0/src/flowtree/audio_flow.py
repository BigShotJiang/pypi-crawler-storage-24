from .core import BaseFlow
from .core import FlowBranch

import gi  # noqa
gi.require_version('Gst', '1.0')  # noqa
from gi.repository import Gst


class AudioFlow(BaseFlow):
    def __init__(self, flow_name: str = "audioflow"):
        super().__init__(flow_name)
        self.microphone_device: str = None
        self.frame_type: str = None
        self.microphone_samplerate: int = None
        self.microphone_channels: int = None

    def set_microphone(self, microphone_device: str, frame_type: str, microphone_samplerate: int, microphone_channels: int):
        self.microphone_device = microphone_device
        self.frame_type = frame_type
        self.microphone_samplerate = microphone_samplerate
        self.microphone_channels = microphone_channels

    def start(self):
        self.create_pipeline(self.flow_name+"_pipeline")

        main_branch = self.create_branch()

        main_branch.append_element("alsasrc", "source", properties={
            "device": self.microphone_device})
        main_branch.append_element("audioconvert", "audioconvert")
        main_branch.append_element("capsfilter", "capsfilter", properties={
            "caps": Gst.Caps.from_string(f"{self.frame_type}, rate={self.microphone_samplerate}, channels={self.microphone_channels}")})
        main_branch.append_element("lamemp3enc", "lamemp3enc", properties={
            "target": 1, "bitrate": 128, "cbr": True})
        main_branch.append_element("filesink", "sink", properties={
            "location": "recording.mp3"})

        super().start()
