"""Pending operation commands."""

from __future__ import annotations

from typing import Any

import typer

from cobo_agent_wallet.cli._common import get_context
from cobo_agent_wallet.cli._common import run_command
from cobo_agent_wallet.cli._output import emit
from cobo_agent_wallet.client import WalletAPIClient

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def list_pending(
    ctx: typer.Context,
    wallet_id: str | None = typer.Option(None, "--wallet-id", help="Filter by wallet UUID."),
    limit: int = typer.Option(50, min=1, max=200),
    offset: int = typer.Option(0, min=0),
) -> None:
    """List pending operations."""
    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_pending_operations(wallet_id=wallet_id, limit=limit, offset=offset)

    run_command(ctx, _operation)


@app.command("get")
def get_pending(
    ctx: typer.Context,
    operation_id: str = typer.Argument(..., help="Pending operation UUID."),
) -> None:
    """Get pending operation details."""
    async def _operation(client: WalletAPIClient) -> Any:
        return await client.get_pending_operation(operation_id)

    run_command(ctx, _operation)


@app.command("approve")
def approve(
    ctx: typer.Context,
    operation_id: str = typer.Argument(..., help="Pending operation UUID."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
) -> None:
    """Approve a pending operation."""
    context = get_context(ctx)

    if not yes:
        confirmed = typer.confirm(f"Approve pending operation {operation_id}?", default=False)
        if not confirmed:
            emit({"cancelled": True, "operation_id": operation_id}, context.output_format)
            return

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.approve_pending_operation(operation_id)

    run_command(ctx, _operation)


@app.command("reject")
def reject(
    ctx: typer.Context,
    operation_id: str = typer.Argument(..., help="Pending operation UUID."),
    reason: str | None = typer.Option(None, "--reason", help="Rejection reason."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
) -> None:
    """Reject a pending operation."""
    context = get_context(ctx)

    if not yes:
        confirmed = typer.confirm(f"Reject pending operation {operation_id}?", default=False)
        if not confirmed:
            emit({"cancelled": True, "operation_id": operation_id}, context.output_format)
            return

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.reject_pending_operation(operation_id, reason=reason)

    run_command(ctx, _operation)