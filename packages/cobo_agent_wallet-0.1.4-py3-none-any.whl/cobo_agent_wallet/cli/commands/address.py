"""Address management commands."""

from __future__ import annotations

from typing import Any

import typer

from cobo_agent_wallet.cli._common import run_command
from cobo_agent_wallet.client import WalletAPIClient

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def list_addresses(
    ctx: typer.Context,
    wallet_uuid: str = typer.Argument(..., help="Wallet UUID."),
) -> None:
    """List addresses for a wallet."""
    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_wallet_addresses(wallet_uuid)

    run_command(ctx, _operation)


@app.command("create")
def create_address(
    ctx: typer.Context,
    wallet_uuid: str = typer.Argument(..., help="Wallet UUID."),
    chain_id: str = typer.Option(..., "--chain", help="Chain ID for the new address."),
) -> None:
    """Create a new address for a wallet."""
    async def _operation(client: WalletAPIClient) -> Any:
        return await client.create_wallet_address(wallet_uuid, chain_id=chain_id)

    run_command(ctx, _operation)


@app.command("recent")
def recent_addresses(
    ctx: typer.Context,
    wallet_uuid: str = typer.Argument(..., help="Wallet UUID."),
    limit: int = typer.Option(50, min=1, max=200),
) -> None:
    """List recently used addresses."""
    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_recent_addresses(wallet_uuid, limit=limit)

    run_command(ctx, _operation)