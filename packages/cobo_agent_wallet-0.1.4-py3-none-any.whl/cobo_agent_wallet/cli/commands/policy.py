"""Policy management commands."""

from __future__ import annotations

from typing import Any

import typer

from cobo_agent_wallet.cli._common import get_context
from cobo_agent_wallet.cli._common import run_command
from cobo_agent_wallet.cli._output import emit
from cobo_agent_wallet.client import WalletAPIClient

app = typer.Typer(no_args_is_help=True)


@app.command("list")
def list_policies(
    ctx: typer.Context,
    delegation_id: str | None = typer.Option(None, "--delegation-id", help="Filter by delegation UUID."),
    limit: int = typer.Option(50, min=1, max=200),
    offset: int = typer.Option(0, min=0),
) -> None:
    """List policies."""
    async def _operation(client: WalletAPIClient) -> Any:
        return await client.list_policies(delegation_id=delegation_id, limit=limit, offset=offset)

    run_command(ctx, _operation)


@app.command("get")
def get_policy(
    ctx: typer.Context,
    policy_id: str = typer.Argument(..., help="Policy UUID."),
) -> None:
    """Get policy details by ID."""
    async def _operation(client: WalletAPIClient) -> Any:
        return await client.get_policy(policy_id)

    run_command(ctx, _operation)


@app.command("create")
def create_policy(
    ctx: typer.Context,
    delegation_id: str = typer.Option(..., "--delegation-id", help="Delegation UUID."),
    name: str = typer.Option(..., "--name", help="Policy name."),
    policy_type: str = typer.Option(..., "--type", help="Policy type (transfer, contract_call)."),
    rules: str = typer.Option(..., "--rules", help="Policy rules as JSON string."),
) -> None:
    """Create a new policy."""
    import json as json_module

    async def _operation(client: WalletAPIClient) -> Any:
        from cobo_agent_wallet_api.models.policy_create import PolicyCreate
        from cobo_agent_wallet_api.models.policy_type import PolicyType
        parsed_rules = json_module.loads(rules)
        policy = PolicyCreate(
            delegation_id=delegation_id,
            name=name,
            type=PolicyType(policy_type),
            rules=parsed_rules,
        )
        return await client.create_policy(policy)

    run_command(ctx, _operation)


@app.command("update")
def update_policy(
    ctx: typer.Context,
    policy_id: str = typer.Argument(..., help="Policy UUID."),
    name: str | None = typer.Option(None, "--name", help="New policy name."),
    rules: str | None = typer.Option(None, "--rules", help="New policy rules as JSON string."),
) -> None:
    """Update policy properties."""
    import json as json_module

    async def _operation(client: WalletAPIClient) -> Any:
        from cobo_agent_wallet_api.models.policy_update import PolicyUpdate
        parsed_rules = json_module.loads(rules) if rules else None
        update = PolicyUpdate(name=name, rules=parsed_rules)
        return await client.update_policy(policy_id, update)

    run_command(ctx, _operation)


@app.command("deactivate")
def deactivate_policy(
    ctx: typer.Context,
    policy_id: str = typer.Argument(..., help="Policy UUID."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
) -> None:
    """Deactivate a policy."""
    context = get_context(ctx)

    if not yes:
        confirmed = typer.confirm(f"Deactivate policy {policy_id}?", default=False)
        if not confirmed:
            emit({"cancelled": True, "policy_id": policy_id}, context.output_format)
            return

    async def _operation(client: WalletAPIClient) -> Any:
        return await client.deactivate_policy(policy_id)

    run_command(ctx, _operation)


@app.command("dry-run")
def dry_run_policy(
    ctx: typer.Context,
    policy_id: str = typer.Argument(..., help="Policy UUID."),
    action: str = typer.Option(..., "--action", help="Action to test (transfer, contract_call)."),
    params: str = typer.Option(..., "--params", help="Action parameters as JSON string."),
) -> None:
    """Dry-run a policy evaluation."""
    import json as json_module

    async def _operation(client: WalletAPIClient) -> Any:
        from cobo_agent_wallet_api.models.policy_dry_run_request import PolicyDryRunRequest
        parsed_params = json_module.loads(params)
        request = PolicyDryRunRequest(action=action, params=parsed_params)
        return await client.dry_run_policy(policy_id, request)

    run_command(ctx, _operation)