"""Onboarding commands (provision, init, self-test, demo)."""

from __future__ import annotations

import asyncio
import json
from contextlib import suppress
from pathlib import Path
from typing import Any

import typer

from cobo_agent_wallet.cli._common import (
    CAW_CONFIG_PATH,
    extract_text,
    get_context,
    make_client,
    OutputFormat,
    progress,
    require_text,
    run_async_operation,
    run_with_client,
)
from cobo_agent_wallet.cli._output import emit
from cobo_agent_wallet.cli.config import (
    load_config,
    resolve_config_path,
    save_config,
)
from cobo_agent_wallet.cli.tss import (
    DEFAULT_TSS_NODE_FILENAME,
    TSS_NODE_ENV_ENV,
    create_mpc_wallet,
    download_tss_node,
    init_tss_node,
    poll_wallet_status,
    start_tss_node,
)
from cobo_agent_wallet.client import WalletAPIClient
from cobo_agent_wallet.errors import APIError, PolicyDeniedError

app = typer.Typer(no_args_is_help=True)


@app.command("provision")
def provision(
    ctx: typer.Context,
    token: str = typer.Option(..., "--token", help="Setup token from owner Telegram flow."),
    config_path: str | None = typer.Option(
        None,
        "--config",
        envvar=CAW_CONFIG_PATH,
        help="Config path. Falls back to CAW_CONFIG_PATH or ~/.cobo-agent-wallet/config.",
    ),
    tss_node_path: str | None = typer.Option(
        None,
        "--tss-node-path",
        help="Path to store TSS-Node binary. Defaults to ~/.cobo-agent-wallet/tss-node.",
    ),
    tss_env: str | None = typer.Option(
        None,
        "--tss-env",
        envvar=TSS_NODE_ENV_ENV,
        help="TSS node env: dev (--dev), prod (--prod), sandbox (--sandbox). Default: dev.",
    ),
    vault_poll_interval: float = typer.Option(2.0, "--vault-poll-interval", min=0.0),
    vault_timeout: float = typer.Option(300.0, "--vault-timeout", min=1.0),
) -> None:
    """Path A provisioning: token bootstrap + vault keygen orchestration."""
    context = get_context(ctx)
    show_progress = context.output_format != OutputFormat.JSON
    resolved_config_path = resolve_config_path(config_path)
    resolved_tss_path = (
        Path(tss_node_path).expanduser()
        if tss_node_path
        else resolved_config_path.parent / DEFAULT_TSS_NODE_FILENAME
    )

    async def _operation() -> Any:
        progress("[1/4] Registering with Cobo backend...", enabled=show_progress)
        bootstrap_client = make_client(context, allow_unauthenticated=True)
        try:
            provision_result = await bootstrap_client.provision_agent(token=token)
        finally:
            await bootstrap_client.close()
        if not isinstance(provision_result, dict):
            raise RuntimeError("Invalid provisioning response")

        agent_id = require_text(provision_result, "agent_id")
        api_key = require_text(provision_result, "api_key")
        onboarding_session_id = require_text(provision_result, "onboarding_session_id")
        status_value = extract_text(provision_result, "status") or ""
        if status_value.lower() != "active":
            raise RuntimeError(f"Unexpected provisioning status: {status_value}")
        progress("[1/4] Registering with Cobo backend... done", enabled=show_progress)

        config_payload: dict[str, Any] = {
            "agent_id": agent_id,
            "api_key": api_key,
            "api_url": context.api_url,
            "status": status_value,
            "onboarding_session_id": onboarding_session_id,
            "activation_secret": None,
            "deep_link": None,
        }
        save_config(config_payload, resolved_config_path)

        progress("[2/4] Downloading TSS-Node...", enabled=show_progress)
        await asyncio.to_thread(
            download_tss_node,
            destination=resolved_tss_path,
            tss_env=tss_env,
            reporter=lambda message: progress(f"[TSS] {message}", enabled=show_progress),
        )
        progress("[2/4] Downloading TSS-Node... done", enabled=show_progress)

        progress("[3/4] Initializing TSS-Node...", enabled=show_progress)
        init_result = await asyncio.to_thread(
            init_tss_node,
            tss_binary_path=resolved_tss_path,
            config_path=resolved_config_path,
        )
        progress("[3/4] Initializing TSS-Node... done", enabled=show_progress)
        main_node_id = require_text(init_result, "tss_node_id")

        progress("[4/4] Starting TSS-Node and creating MPC wallet...", enabled=show_progress)
        await asyncio.to_thread(
            start_tss_node,
            tss_binary_path=resolved_tss_path,
            tss_env=tss_env,
            reporter=lambda message: progress(f"[TSS] {message}", enabled=show_progress),
        )
        client = make_client(context, api_key=api_key)
        try:
            wallet_payload = await create_mpc_wallet(
                client=client,
                main_node_id=main_node_id,
            )
            wallet_uuid = require_text(wallet_payload, "wallet_uuid", "uuid", "id")
            wallet_status_payload = await poll_wallet_status(
                client=client,
                wallet_uuid=wallet_uuid,
                poll_interval_seconds=vault_poll_interval,
                timeout_seconds=vault_timeout,
            )
        finally:
            await client.close()
        progress("[4/4] Starting TSS-Node and creating MPC wallet... done", enabled=show_progress)

        config_payload.update(
            {
                "wallet_uuid": wallet_uuid,
                "status": extract_text(wallet_status_payload, "status") or "active",
                "activation_secret": None,
            }
        )
        save_config(config_payload, resolved_config_path)
        return {
            "agent_id": agent_id,
            "status": config_payload["status"],
            "wallet_uuid": wallet_uuid,
            "onboarding_session_id": onboarding_session_id,
            "config_path": str(resolved_config_path),
            "tss_node_path": str(resolved_tss_path),
        }

    result = run_async_operation(context, _operation)
    emit(result, context.output_format)


@app.command("init")
def init(
    ctx: typer.Context,
    config_path: str | None = typer.Option(
        None,
        "--config",
        envvar=CAW_CONFIG_PATH,
        help="Config path. Falls back to CAW_CONFIG_PATH or ~/.cobo-agent-wallet/config.",
    ),
    tss_node_path: str | None = typer.Option(
        None,
        "--tss-node-path",
        help="Path to store TSS-Node binary. Defaults to ~/.cobo-agent-wallet/tss-node.",
    ),
    tss_env: str | None = typer.Option(
        None,
        "--tss-env",
        envvar=TSS_NODE_ENV_ENV,
        help="TSS node env: dev (--dev), prod (--prod), sandbox (--sandbox). Default: dev.",
    ),
    status_poll_interval: float = typer.Option(2.0, "--status-poll-interval", min=0.0),
    status_timeout: float = typer.Option(600.0, "--status-timeout", min=1.0),
    vault_poll_interval: float = typer.Option(2.0, "--vault-poll-interval", min=0.0),
    vault_timeout: float = typer.Option(300.0, "--vault-timeout", min=1.0),
) -> None:
    """Path B provisioning: temporary principal, deep link, then upgrade + vault."""
    context = get_context(ctx)
    show_progress = context.output_format != OutputFormat.JSON
    resolved_config_path = resolve_config_path(config_path)
    resolved_tss_path = (
        Path(tss_node_path).expanduser()
        if tss_node_path
        else resolved_config_path.parent / DEFAULT_TSS_NODE_FILENAME
    )

    async def _operation() -> Any:
        progress("[1/5] Registering with Cobo backend...", enabled=show_progress)
        bootstrap_client = make_client(context, allow_unauthenticated=True)
        try:
            provision_result = await bootstrap_client.provision_agent()
        finally:
            await bootstrap_client.close()
        if not isinstance(provision_result, dict):
            raise RuntimeError("Invalid provisioning response")

        agent_id = require_text(provision_result, "agent_id")
        api_key = require_text(provision_result, "api_key")
        activation_secret = require_text(provision_result, "activation_secret")
        deep_link = require_text(provision_result, "deep_link")
        status_value = (extract_text(provision_result, "status") or "").lower()
        if status_value != "temporary":
            raise RuntimeError(f"Unexpected init status: {status_value}")
        progress("[1/5] Registering with Cobo backend... done", enabled=show_progress)

        config_payload: dict[str, Any] = {
            "agent_id": agent_id,
            "api_key": api_key,
            "api_url": context.api_url,
            "status": status_value,
            "activation_secret": activation_secret,
            "deep_link": deep_link,
            "onboarding_session_id": None,
        }
        save_config(config_payload, resolved_config_path)

        progress("[2/5] Downloading TSS-Node in background...", enabled=show_progress)
        download_task = asyncio.create_task(
            asyncio.to_thread(
                download_tss_node,
                destination=resolved_tss_path,
                tss_env=tss_env,
                reporter=lambda message: progress(f"[TSS] {message}", enabled=show_progress),
            )
        )
        try:
            progress("Share this link with your wallet owner:", enabled=show_progress)
            progress(f"  {deep_link}", enabled=show_progress)

            progress("[3/5] Waiting for owner to connect...", enabled=show_progress)
            status_client = make_client(context, api_key=api_key)
            try:
                started_at = asyncio.get_running_loop().time()
                onboarding_session_id = ""
                while True:
                    status_payload = await status_client.get_agent_status(agent_id=agent_id)
                    if not isinstance(status_payload, dict):
                        raise RuntimeError("Invalid agent status response")
                    current_status = (extract_text(status_payload, "status") or "").lower()
                    if current_status == "active":
                        onboarding_session_id = require_text(
                            status_payload,
                            "onboarding_session_id",
                        )
                        break
                    if asyncio.get_running_loop().time() - started_at > status_timeout:
                        raise TimeoutError("Timed out waiting for owner activation")
                    await asyncio.sleep(max(0.0, status_poll_interval))
            finally:
                await status_client.close()
            progress("[3/5] Waiting for owner to connect... done", enabled=show_progress)

            await download_task
            progress("[TSS] Downloading TSS-Node in background... done", enabled=show_progress)

            progress("[4/5] Initializing TSS-Node...", enabled=show_progress)
            init_result = await asyncio.to_thread(
                init_tss_node,
                tss_binary_path=resolved_tss_path,
                config_path=resolved_config_path,
            )
            progress("[4/5] Initializing TSS-Node... done", enabled=show_progress)
            main_node_id = require_text(init_result, "tss_node_id")

            progress("[5/5] Starting TSS-Node and creating MPC wallet...", enabled=show_progress)
            await asyncio.to_thread(
                start_tss_node,
                tss_binary_path=resolved_tss_path,
                tss_env=tss_env,
                reporter=lambda message: progress(f"[TSS] {message}", enabled=show_progress),
            )
            active_client = make_client(context, api_key=api_key)
            try:
                wallet_payload = await create_mpc_wallet(
                    client=active_client,
                    main_node_id=main_node_id,
                    for_owner=True,
                )
                wallet_uuid = require_text(wallet_payload, "wallet_uuid", "uuid", "id")
                wallet_status_payload = await poll_wallet_status(
                    client=active_client,
                    wallet_uuid=wallet_uuid,
                    poll_interval_seconds=vault_poll_interval,
                    timeout_seconds=vault_timeout,
                )
            finally:
                await active_client.close()
            progress(
                "[5/5] Starting TSS-Node and creating MPC wallet... done", enabled=show_progress
            )
        finally:
            if not download_task.done():
                download_task.cancel()
                with suppress(asyncio.CancelledError):
                    await download_task

        config_payload.update(
            {
                "status": extract_text(wallet_status_payload, "status") or "active",
                "activation_secret": None,
                "onboarding_session_id": onboarding_session_id,
                "wallet_uuid": wallet_uuid,
            }
        )
        save_config(config_payload, resolved_config_path)
        return {
            "agent_id": agent_id,
            "status": config_payload["status"],
            "deep_link": deep_link,
            "wallet_uuid": wallet_uuid,
            "onboarding_session_id": onboarding_session_id,
            "config_path": str(resolved_config_path),
            "tss_node_path": str(resolved_tss_path),
        }

    try:
        result = run_async_operation(context, _operation)
    except KeyboardInterrupt as exc:
        typer.echo(
            "\nInterrupted. Run 'caw onboard init' again to restart onboarding setup.",
            err=True,
        )
        raise typer.Exit(code=130) from exc
    emit(result, context.output_format)


@app.command("self-test")
def self_test(
    ctx: typer.Context,
    wallet_uuid: str = typer.Option(..., "--wallet", help="Wallet UUID to test."),
    token: str = typer.Option("USDC", "--token", help="Token ID for transfer tests."),
    chain: str = typer.Option("BASE", "--chain", help="Chain ID for transfer tests."),
    blocked_amount: str = typer.Option("500", "--blocked-amount", help="Expected denied amount."),
    allowed_amount: str = typer.Option("2", "--allowed-amount", help="Expected allowed amount."),
    to: str = typer.Option(
        "0x1111111111111111111111111111111111111111",
        "--to",
        help="Destination address for transfer tests.",
    ),
) -> None:
    """Run blocked+allowed transfer checks for onboarding validation."""
    # api_key and api_url are already resolved from config by the global callback in app.py
    context = get_context(ctx)

    async def _operation(client: WalletAPIClient) -> Any:
        blocked: dict[str, Any]
        try:
            response = await client.transfer_tokens(
                wallet_uuid,
                chain_id=chain,
                dst_addr=to,
                token_id=token,
                amount=blocked_amount,
            )
            blocked = {
                "passed": False,
                "reason": "blocked transfer unexpectedly succeeded",
                "response": response,
            }
        except PolicyDeniedError as exc:
            blocked = {
                "passed": True,
                "code": exc.denial.code,
                "reason": exc.denial.reason,
                "details": exc.denial.details,
            }
        except APIError as exc:
            blocked = {
                "passed": False,
                "reason": f"blocked transfer failed with non-policy error ({exc.status_code})",
                "error": str(exc),
            }

        allowed: dict[str, Any]
        try:
            response = await client.transfer_tokens(
                wallet_uuid,
                chain_id=chain,
                dst_addr=to,
                token_id=token,
                amount=allowed_amount,
            )
            allowed_status = ""
            if isinstance(response, dict):
                allowed_status = (extract_text(response, "status") or "").lower()
            if allowed_status in {"denied", "failed", "rejected"}:
                allowed = {
                    "passed": False,
                    "reason": f"allowed transfer returned status={allowed_status}",
                    "response": response,
                }
            else:
                tx_identifier = ""
                if isinstance(response, dict):
                    tx_identifier = (
                        extract_text(response, "tx_id", "id", "request_id", "tx_hash") or ""
                    )
                allowed = {
                    "passed": True,
                    "status": allowed_status or "submitted",
                    "tx_id": tx_identifier or None,
                    "response": response,
                }
        except PolicyDeniedError as exc:
            allowed = {
                "passed": False,
                "reason": "allowed transfer was denied",
                "code": exc.denial.code,
                "details": exc.denial.details,
            }
        except APIError as exc:
            allowed = {
                "passed": False,
                "reason": f"allowed transfer failed ({exc.status_code})",
                "error": str(exc),
            }

        return {
            "wallet_uuid": wallet_uuid,
            "chain_id": chain,
            "token_id": token,
            "blocked_test": blocked,
            "allowed_test": allowed,
            "passed": bool(blocked.get("passed")) and bool(allowed.get("passed")),
        }

    result = run_with_client(context, _operation)
    emit(result, context.output_format)
    if isinstance(result, dict) and not result.get("passed", False):
        raise typer.Exit(code=1)


@app.command("health")
def health(ctx: typer.Context) -> None:
    """Check API health status."""
    context = get_context(ctx)

    async def _operation() -> Any:
        client = make_client(context, allow_unauthenticated=True)
        try:
            return await client.health_check()
        finally:
            await client.close()

    result = run_async_operation(context, _operation)
    emit(result, context.output_format)


def demo(ctx: typer.Context) -> None:
    """Run the P11 quickstart demo workflow."""
    context = get_context(ctx)
    from cobo_agent_wallet.demo import (
        DemoBackendUnavailableError,
        DemoExecutionError,
        format_demo_output,
        run_quickstart_demo,
    )

    try:
        result = asyncio.run(
            run_quickstart_demo(
                api_url=context.api_url,
                timeout=context.timeout,
            )
        )
    except DemoBackendUnavailableError as exc:
        payload = {
            "error": "BACKEND_UNAVAILABLE",
            "message": str(exc),
            "suggestion": exc.suggestion,
        }
        if context.output_format == OutputFormat.JSON:
            typer.echo(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=True), err=True)
        else:
            typer.echo(f"{payload['message']}\nSuggestion: {payload['suggestion']}", err=True)
        raise typer.Exit(code=1) from exc
    except DemoExecutionError as exc:
        payload = {"error": "DEMO_FAILED", "message": str(exc)}
        if context.output_format == OutputFormat.JSON:
            typer.echo(json.dumps(payload, indent=2, sort_keys=True, ensure_ascii=True), err=True)
        else:
            typer.echo(str(exc), err=True)
        raise typer.Exit(code=1) from exc

    if context.output_format == OutputFormat.TABLE:
        typer.echo(format_demo_output(result))
    else:
        emit(result, context.output_format)