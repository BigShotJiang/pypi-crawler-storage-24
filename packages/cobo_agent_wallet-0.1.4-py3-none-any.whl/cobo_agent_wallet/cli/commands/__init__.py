"""CLI command modules."""

from cobo_agent_wallet.cli.commands import (
    address,
    agent,
    audit,
    delegation,
    meta,
    onboard,
    pending,
    policy,
    tx,
    wallet,
)

__all__ = [
    "address",
    "agent",
    "audit",
    "delegation",
    "meta",
    "onboard",
    "pending",
    "policy",
    "tx",
    "wallet",
]