"""Persistent config helpers for onboarding CLI workflows."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

CONFIG_PATH_ENV_VAR = "CAW_CONFIG_PATH"
DEFAULT_CONFIG_DIR = ".cobo-agent-wallet"
DEFAULT_CONFIG_FILENAME = "config"


def resolve_config_path(path: str | Path | None = None) -> Path:
    """Resolve config path from explicit value, env var, or default location."""
    if path is not None:
        return Path(path).expanduser()
    env_path = os.getenv(CONFIG_PATH_ENV_VAR)
    if env_path:
        return Path(env_path).expanduser()
    return Path.home() / DEFAULT_CONFIG_DIR / DEFAULT_CONFIG_FILENAME


def config_exists(path: str | Path | None = None) -> bool:
    """Return whether the persisted config file exists."""
    return resolve_config_path(path).exists()


def load_config(path: str | Path | None = None) -> dict[str, Any]:
    """Load CLI config from disk."""
    config_path = resolve_config_path(path)
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")
    with config_path.open("r", encoding="utf-8") as fh:
        payload = json.load(fh)
    if not isinstance(payload, dict):
        raise ValueError(f"Invalid config payload: expected object, got {type(payload).__name__}")
    return payload


def save_config(payload: dict[str, Any], path: str | Path | None = None) -> Path:
    """Write CLI config atomically and return the final path."""
    config_path = resolve_config_path(path)
    config_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = config_path.with_suffix(f"{config_path.suffix}.tmp")
    with tmp_path.open("w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=2, sort_keys=True, ensure_ascii=True)
        fh.write("\n")
    tmp_path.replace(config_path)
    os.chmod(config_path, 0o600)
    return config_path


def update_config(path: str | Path | None = None, **kwargs: Any) -> dict[str, Any]:
    """Load config, merge updates, persist, and return the merged payload."""
    try:
        payload = load_config(path)
    except FileNotFoundError:
        payload = {}
    payload.update(kwargs)
    save_config(payload, path)
    return payload


def delete_config(path: str | Path | None = None) -> None:
    """Delete persisted config file if it exists."""
    config_path = resolve_config_path(path)
    if config_path.exists():
        config_path.unlink()
