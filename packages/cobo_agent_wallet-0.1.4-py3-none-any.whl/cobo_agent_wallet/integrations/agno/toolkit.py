"""Agno Toolkit adapter for Cobo Agent Wallet."""

from __future__ import annotations

import asyncio
import json
from typing import Any

from cobo_agent_wallet.client import WalletAPIClient
from cobo_agent_wallet.errors import APIError, PolicyDeniedError
from cobo_agent_wallet.integrations.agno.tools import build_tool_handler_map, format_denial_text
from cobo_agent_wallet.toolkit import AgentWalletToolkit, ToolHandler

try:
    from agno.tools.toolkit import Toolkit
except ImportError as exc:  # pragma: no cover - import guard
    raise ImportError(
        "agno is required for this integration. Install with: pip install 'cobo-agent-wallet[agno]'"
    ) from exc


class CoboAgentWalletTools(Toolkit):
    """Agno toolkit wrapper over :class:`AgentWalletToolkit`.

    This adapter keeps the canonical Cobo tool surface from ``AgentWalletToolkit``
    and maps policy denials to LLM-readable tool outputs so agents can self-correct.
    """

    def __init__(
        self,
        *,
        client: WalletAPIClient,
        name: str = "cobo_agent_wallet",
        all: bool = False,
        enable_list_wallets: bool = True,
        enable_get_balance: bool = True,
        enable_transfer_tokens: bool = True,
        enable_list_transactions: bool = True,
        enable_get_audit_logs: bool = True,
        enable_create_delegation: bool = True,
        include_tools: list[str] | None = None,
        exclude_tools: list[str] | None = None,
        **kwargs: Any,
    ) -> None:
        self._base_toolkit = AgentWalletToolkit(client)
        self._tool_definitions = {tool.name: tool for tool in self._base_toolkit.get_tools()}
        self._handlers: dict[str, ToolHandler] = build_tool_handler_map(self._base_toolkit)

        tools: list[Any] = []
        async_tools: list[tuple[Any, str]] = []
        if all or enable_list_wallets:
            tools.append(self.list_wallets)
            async_tools.append((self.alist_wallets, "list_wallets"))
        if all or enable_get_balance:
            tools.append(self.get_balance)
            async_tools.append((self.aget_balance, "get_balance"))
        if all or enable_transfer_tokens:
            tools.append(self.transfer_tokens)
            async_tools.append((self.atransfer_tokens, "transfer_tokens"))
        if all or enable_list_transactions:
            tools.append(self.list_transactions)
            async_tools.append((self.alist_transactions, "list_transactions"))
        if all or enable_get_audit_logs:
            tools.append(self.get_audit_logs)
            async_tools.append((self.aget_audit_logs, "get_audit_logs"))
        if all or enable_create_delegation:
            tools.append(self.create_delegation)
            async_tools.append((self.acreate_delegation, "create_delegation"))

        super().__init__(
            name=name,
            tools=tools,
            async_tools=async_tools,
            include_tools=include_tools,
            exclude_tools=exclude_tools,
            **kwargs,
        )
        self._hydrate_tool_metadata()

    def _hydrate_tool_metadata(self) -> None:
        """Populate Agno function descriptions/schemas from canonical tool definitions."""

        for registry in (self.functions, self.async_functions):
            for name, function in registry.items():
                definition = self._tool_definitions.get(name)
                if definition is None:
                    continue
                function.description = definition.description
                function.parameters = definition.parameters

    def _error_payload(self, exc: APIError) -> str:
        payload = {
            "error": "API_ERROR",
            "status_code": exc.status_code,
            "message": str(exc),
            "response": exc.response_body,
        }
        return json.dumps(payload, sort_keys=True)

    async def _invoke_async(self, tool_name: str, **kwargs: Any) -> Any:
        try:
            return await self._handlers[tool_name](**kwargs)
        except PolicyDeniedError as exc:
            return format_denial_text(self._base_toolkit, exc.denial)
        except APIError as exc:
            raise RuntimeError(self._error_payload(exc)) from exc

    def _invoke_sync(self, tool_name: str, **kwargs: Any) -> Any:
        try:
            asyncio.get_running_loop()
        except RuntimeError:
            return asyncio.run(self._invoke_async(tool_name, **kwargs))

        raise RuntimeError(
            "CoboAgentWalletTools are synchronous wrappers over async API calls. "
            "Call them from a sync context, or run them in a separate thread from async code."
        )

    def list_wallets(self, limit: int = 50, offset: int = 0, include_archived: bool = False) -> Any:
        """List wallets accessible to the caller."""

        return self._invoke_sync(
            "list_wallets",
            limit=limit,
            offset=offset,
            include_archived=include_archived,
        )

    def get_balance(self, wallet_uuid: str) -> Any:
        """Get wallet balances for a specific wallet."""

        return self._invoke_sync("get_balance", wallet_uuid=wallet_uuid)

    def transfer_tokens(
        self,
        wallet_uuid: str,
        dst_addr: str,
        token_id: str,
        amount: str,
        chain_id: str = "ETH",
        request_id: str | None = None,
        fee: dict[str, Any] | None = None,
    ) -> Any:
        """Transfer tokens to a destination address with policy enforcement."""

        return self._invoke_sync(
            "transfer_tokens",
            wallet_uuid=wallet_uuid,
            chain_id=chain_id,
            dst_addr=dst_addr,
            token_id=token_id,
            amount=amount,
            request_id=request_id,
            fee=fee,
        )

    def list_transactions(
        self,
        wallet_uuid: str,
        limit: int = 50,
        offset: int = 0,
        status: str | None = None,
    ) -> Any:
        """List transactions for a wallet with optional status filter."""

        return self._invoke_sync(
            "list_transactions",
            wallet_uuid=wallet_uuid,
            limit=limit,
            offset=offset,
            status=status,
        )

    def get_audit_logs(
        self,
        wallet_id: str | None = None,
        principal_id: str | None = None,
        action: str | None = None,
        result: str | None = None,
        start_time: str | None = None,
        end_time: str | None = None,
        cursor: str | None = None,
        limit: int = 50,
    ) -> Any:
        """Query audit logs with filters and cursor pagination."""

        return self._invoke_sync(
            "get_audit_logs",
            wallet_id=wallet_id,
            principal_id=principal_id,
            action=action,
            result=result,
            start_time=start_time,
            end_time=end_time,
            cursor=cursor,
            limit=limit,
        )

    def create_delegation(
        self,
        operator_id: str,
        wallet_id: str,
        permissions: list[str],
        policies: list[dict[str, Any]] | None = None,
        constraints: dict[str, Any] | None = None,
        expires_at: str | None = None,
    ) -> Any:
        """Create delegation granting an operator scoped wallet permissions."""

        return self._invoke_sync(
            "create_delegation",
            operator_id=operator_id,
            wallet_id=wallet_id,
            permissions=permissions,
            policies=policies,
            constraints=constraints,
            expires_at=expires_at,
        )

    async def alist_wallets(
        self, limit: int = 50, offset: int = 0, include_archived: bool = False
    ) -> Any:
        """List wallets accessible to the caller."""

        return await self._invoke_async(
            "list_wallets",
            limit=limit,
            offset=offset,
            include_archived=include_archived,
        )

    async def aget_balance(self, wallet_uuid: str) -> Any:
        """Get wallet balances for a specific wallet."""

        return await self._invoke_async("get_balance", wallet_uuid=wallet_uuid)

    async def atransfer_tokens(
        self,
        wallet_uuid: str,
        dst_addr: str,
        token_id: str,
        amount: str,
        chain_id: str = "ETH",
        request_id: str | None = None,
        fee: dict[str, Any] | None = None,
    ) -> Any:
        """Transfer tokens to a destination address with policy enforcement."""

        return await self._invoke_async(
            "transfer_tokens",
            wallet_uuid=wallet_uuid,
            chain_id=chain_id,
            dst_addr=dst_addr,
            token_id=token_id,
            amount=amount,
            request_id=request_id,
            fee=fee,
        )

    async def alist_transactions(
        self,
        wallet_uuid: str,
        limit: int = 50,
        offset: int = 0,
        status: str | None = None,
    ) -> Any:
        """List transactions for a wallet with optional status filter."""

        return await self._invoke_async(
            "list_transactions",
            wallet_uuid=wallet_uuid,
            limit=limit,
            offset=offset,
            status=status,
        )

    async def aget_audit_logs(
        self,
        wallet_id: str | None = None,
        principal_id: str | None = None,
        action: str | None = None,
        result: str | None = None,
        start_time: str | None = None,
        end_time: str | None = None,
        cursor: str | None = None,
        limit: int = 50,
    ) -> Any:
        """Query audit logs with filters and cursor pagination."""

        return await self._invoke_async(
            "get_audit_logs",
            wallet_id=wallet_id,
            principal_id=principal_id,
            action=action,
            result=result,
            start_time=start_time,
            end_time=end_time,
            cursor=cursor,
            limit=limit,
        )

    async def acreate_delegation(
        self,
        operator_id: str,
        wallet_id: str,
        permissions: list[str],
        policies: list[dict[str, Any]] | None = None,
        constraints: dict[str, Any] | None = None,
        expires_at: str | None = None,
    ) -> Any:
        """Create delegation granting an operator scoped wallet permissions."""

        return await self._invoke_async(
            "create_delegation",
            operator_id=operator_id,
            wallet_id=wallet_id,
            permissions=permissions,
            policies=policies,
            constraints=constraints,
            expires_at=expires_at,
        )

# Backward compatibility with earlier naming used during P8 scaffolding.
CoboAgentWalletToolkit = CoboAgentWalletTools

__all__ = ["CoboAgentWalletTools", "CoboAgentWalletToolkit"]
