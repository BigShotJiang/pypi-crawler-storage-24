"""SDK Client wrapper for the generated Cobo Agent Wallet API."""

from __future__ import annotations

# Generated SDK imports
from cobo_agent_wallet_api.configuration import Configuration
from cobo_agent_wallet_api.api_client_async import AsyncApiClient
from cobo_agent_wallet_api.api.wallets_api_async import AsyncWalletsApi
from cobo_agent_wallet_api.api.transactions_api_async import AsyncTransactionsApi
from cobo_agent_wallet_api.api.transaction_records_api_async import AsyncTransactionRecordsApi
from cobo_agent_wallet_api.api.delegations_api_async import AsyncDelegationsApi
from cobo_agent_wallet_api.api.audit_api_async import AsyncAuditApi
from cobo_agent_wallet_api.api.identity_api_async import AsyncIdentityApi
from cobo_agent_wallet_api.api.health_api_async import AsyncHealthApi
from cobo_agent_wallet_api.api.meta_api_async import AsyncMetaApi
from cobo_agent_wallet_api.api.policies_api_async import AsyncPoliciesApi
from cobo_agent_wallet_api.api.coin_price_api_async import AsyncCoinPriceApi
from cobo_agent_wallet_api.api.metadata_api_async import AsyncMetadataApi

# Mixin imports
from cobo_agent_wallet._mixins.base import BaseClient
from cobo_agent_wallet._mixins.wallet import WalletMixin
from cobo_agent_wallet._mixins.delegation import DelegationMixin
from cobo_agent_wallet._mixins.transaction import TransactionMixin
from cobo_agent_wallet._mixins.transaction_record import TransactionRecordMixin
from cobo_agent_wallet._mixins.policy import PolicyMixin
from cobo_agent_wallet._mixins.identity import IdentityMixin
from cobo_agent_wallet._mixins.audit import AuditMixin
from cobo_agent_wallet._mixins.coin_price import CoinPriceMixin
from cobo_agent_wallet._mixins.health import HealthMixin
from cobo_agent_wallet._mixins.metadata import MetadataMixin


class WalletAPIClient(
    WalletMixin,
    DelegationMixin,
    TransactionMixin,
    TransactionRecordMixin,
    PolicyMixin,
    IdentityMixin,
    AuditMixin,
    CoinPriceMixin,
    HealthMixin,
    MetadataMixin,
    BaseClient,
):
    """Async client wrapper for the generated SDK.

    This class provides a simplified interface to the generated SDK,
    matching the original WalletAPIClient API for backward compatibility.

    The class inherits from multiple mixins that provide domain-specific
    functionality:
    - WalletMixin: Wallet operations (list, get, create, update, archive)
    - DelegationMixin: Delegation operations (create, list, revoke, freeze)
    - TransactionMixin: Transaction operations (transfer, contract_call, etc.)
    - TransactionRecordMixin: Transaction record operations (list, get)
    - PolicyMixin: Policy and pending operation management
    - IdentityMixin: Identity and API key management
    - AuditMixin: Audit log operations
    - CoinPriceMixin: Coin price operations
    - HealthMixin: Health check operations
    - MetadataMixin: Metadata operations (chains, tokens)
    - BaseClient: Shared functionality (close, health check, result extraction)
    """

    def __init__(
        self,
        *,
        base_url: str,
        api_key: str | None = None,
        allow_unauthenticated: bool = False,
        timeout: float = 30.0,
        service_auth_key: str | None = None,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._api_key = api_key
        self._allow_unauthenticated = allow_unauthenticated
        self._timeout = timeout
        self._service_auth_key = service_auth_key

        # Initialize generated SDK client
        config = Configuration(
            host=self._base_url,
            api_key=api_key or "" if not allow_unauthenticated else "",
        )
        # Set timeout (rest_async.py checks for this attribute)
        config.request_timeout = timeout
        self._api_client = AsyncApiClient(configuration=config)

        # Initialize API objects
        self._wallets_api = AsyncWalletsApi(api_client=self._api_client)
        self._transactions_api = AsyncTransactionsApi(api_client=self._api_client)
        self._transaction_records_api = AsyncTransactionRecordsApi(api_client=self._api_client)
        self._delegations_api = AsyncDelegationsApi(api_client=self._api_client)
        self._audit_api = AsyncAuditApi(api_client=self._api_client)
        self._identity_api = AsyncIdentityApi(api_client=self._api_client)
        self._health_api = AsyncHealthApi(api_client=self._api_client)
        self._meta_api = AsyncMetaApi(api_client=self._api_client)
        self._policies_api = AsyncPoliciesApi(api_client=self._api_client)
        self._coin_price_api = AsyncCoinPriceApi(api_client=self._api_client)
        self._metadata_api = AsyncMetadataApi(api_client=self._api_client)

    async def __aenter__(self) -> "WalletAPIClient":
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.close()