"""Delegation operations mixin (auto-generated).

DO NOT EDIT MANUALLY. Run scripts/generate_mixins.py to regenerate.
"""

from __future__ import annotations

from typing import Any, TYPE_CHECKING

from cobo_agent_wallet_api.models.delegation_create import DelegationCreate
from cobo_agent_wallet_api.models.delegation_freeze_request import DelegationFreezeRequest

if TYPE_CHECKING:
    from cobo_agent_wallet._mixins.base import BaseClient


class DelegationMixin:
    """Delegation operations mixin (auto-generated)."""

    _extract_result: Any
    _delegations_api: Any

    async def create_delegation(self: "BaseClient", operator_id: str, wallet_id: str, permissions: List, policies: Any = None, expires_at: datetime | None = None) -> Any:
        """Create Delegation"""
        delegation_create = DelegationCreate(operator_id=operator_id, wallet_id=wallet_id, permissions=permissions, policies=policies, expires_at=expires_at)
        response = await self._delegations_api.create_delegation(delegation_create)
        return self._extract_result(response)

    async def freeze_delegations(self: "BaseClient", scope: Any, owner_id: str | None = None, wallet_id: str | None = None, delegation_id: str | None = None, reason: str | None = None) -> Any:
        """Freeze Delegations"""
        delegation_freeze_request = DelegationFreezeRequest(scope=scope, owner_id=owner_id, wallet_id=wallet_id, delegation_id=delegation_id, reason=reason)
        response = await self._delegations_api.freeze_delegations(delegation_freeze_request)
        return self._extract_result(response)

    async def get_delegation(self: "BaseClient", delegation_id: str) -> Any:
        """Get Delegation"""
        response = await self._delegations_api.get_delegation(delegation_id)
        return self._extract_result(response)

    async def list_delegations(self: "BaseClient", operator_id: str | None = None, wallet_id: str | None = None, status: Any = None, offset: int | None = None, limit: int | None = None) -> Any:
        """List Delegations"""
        response = await self._delegations_api.list_delegations(operator_id, wallet_id, status, offset, limit)
        return self._extract_result(response)

    async def list_received_delegations(self: "BaseClient", owner_id: str | None = None, wallet_id: str | None = None, status: Any = None, offset: int | None = None, limit: int | None = None) -> Any:
        """List Received Delegations"""
        response = await self._delegations_api.list_received_delegations(owner_id, wallet_id, status, offset, limit)
        return self._extract_result(response)

    async def revoke_delegation(self: "BaseClient", delegation_id: str) -> Any:
        """Revoke Delegation"""
        response = await self._delegations_api.revoke_delegation(delegation_id)
        return self._extract_result(response)

    async def unfreeze_delegations(self: "BaseClient", scope: Any, owner_id: str | None = None, wallet_id: str | None = None, delegation_id: str | None = None, reason: str | None = None) -> Any:
        """Unfreeze Delegations"""
        delegation_freeze_request = DelegationFreezeRequest(scope=scope, owner_id=owner_id, wallet_id=wallet_id, delegation_id=delegation_id, reason=reason)
        response = await self._delegations_api.unfreeze_delegations(delegation_freeze_request)
        return self._extract_result(response)

    async def update_delegation(self: "BaseClient", delegation_id: str, delegation_update: Any) -> Any:
        """Update Delegation"""
        response = await self._delegations_api.update_delegation(delegation_id, delegation_update)
        return self._extract_result(response)
