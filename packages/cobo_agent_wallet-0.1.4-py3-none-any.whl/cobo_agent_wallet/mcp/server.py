"""SDK-hosted MCP stdio server for Cobo Agent Wallet."""

from __future__ import annotations

import asyncio
import inspect
import json
import os
from contextlib import asynccontextmanager
from dataclasses import dataclass
from typing import Any, AsyncContextManager, AsyncIterator, Awaitable, Callable, Mapping, Protocol

from cobo_agent_wallet.client import WalletAPIClient
from cobo_agent_wallet.errors import APIError, PolicyDeniedError
from cobo_agent_wallet_api.exceptions import ApiException
from cobo_agent_wallet.mcp.compat import ensure_fastmcp_compat
from cobo_agent_wallet.tool_specs import list_tool_specs
from cobo_agent_wallet.toolkit import AgentWalletToolkit

ensure_fastmcp_compat()

try:
    from fastmcp import FastMCP
except ImportError as exc:  # pragma: no cover - import guard
    raise ImportError(
        "fastmcp is required for the MCP server. Install with: pip install 'cobo-agent-wallet[mcp]'"
    ) from exc


AGENT_WALLET_API_URL = "AGENT_WALLET_API_URL"
AGENT_WALLET_API_KEY = "AGENT_WALLET_API_KEY"
AGENT_WALLET_TIMEOUT = "AGENT_WALLET_TIMEOUT"


@dataclass(frozen=True)
class MCPServerConfig:
    """Runtime config for MCP stdio server."""

    api_url: str = "http://localhost:8000"
    timeout: float = 30.0
    api_key: str | None = None

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> MCPServerConfig:
        source = env or os.environ
        timeout = _parse_float(
            source.get(AGENT_WALLET_TIMEOUT),
            AGENT_WALLET_TIMEOUT,
            default=30.0,
        )
        return cls(
            api_url=source.get(AGENT_WALLET_API_URL, "http://localhost:8000"),
            timeout=timeout,
            api_key=source.get(AGENT_WALLET_API_KEY),
        )


def _parse_float(raw: str | None, env_key: str, *, default: float) -> float:
    if raw is None:
        return default
    try:
        value = float(raw)
    except ValueError as exc:
        raise ValueError(f"{env_key} must be a float, got: {raw!r}") from exc
    if value < 0:
        raise ValueError(f"{env_key} must be >= 0, got: {raw!r}")
    return value


def _python_type_annotation(
    property_schema: dict[str, Any],
    *,
    required: bool,
    default: Any,
    has_default: bool,
) -> Any:
    schema_type = property_schema.get("type")
    if schema_type == "string":
        annotation: Any = str
    elif schema_type == "integer":
        annotation = int
    elif schema_type == "boolean":
        annotation = bool
    elif schema_type == "object":
        annotation = dict[str, Any]
    elif schema_type == "array":
        items = property_schema.get("items")
        item_type = items.get("type") if isinstance(items, dict) else None
        annotation = list[str] if item_type == "string" else list[Any]
    else:
        annotation = Any

    default_is_none = has_default and default is None
    if (not required and not has_default) or default_is_none:
        return annotation | None
    return annotation


def _build_tool_wrapper(
    tool_name: str,
    parameters_schema: dict[str, Any],
    invoke_tool: Callable[..., Awaitable[Any]],
) -> Callable[..., Awaitable[Any]]:
    properties = parameters_schema.get("properties")
    if not isinstance(properties, dict):
        raise ValueError(f"Tool '{tool_name}' must define object properties.")

    required_list = parameters_schema.get("required") or []
    required_names = [name for name in required_list if isinstance(name, str) and name in properties]
    required_set = set(required_names)
    optional_names = [name for name in properties if name not in required_set]
    ordered_names = [*required_names, *optional_names]

    signature_params: list[inspect.Parameter] = []
    annotations: dict[str, Any] = {}
    for arg_name in ordered_names:
        raw_schema = properties.get(arg_name)
        property_schema = raw_schema if isinstance(raw_schema, dict) else {}
        has_default = "default" in property_schema
        default = property_schema.get("default")
        annotation = _python_type_annotation(
            property_schema,
            required=arg_name in required_set,
            default=default,
            has_default=has_default,
        )
        annotations[arg_name] = annotation
        if arg_name in required_set:
            signature_params.append(
                inspect.Parameter(
                    name=arg_name,
                    kind=inspect.Parameter.KEYWORD_ONLY,
                    annotation=annotation,
                )
            )
            continue

        signature_params.append(
            inspect.Parameter(
                name=arg_name,
                kind=inspect.Parameter.KEYWORD_ONLY,
                annotation=annotation,
                default=default if has_default else None,
            )
        )

    async def _wrapper(**kwargs: Any) -> Any:
        return await invoke_tool(tool_name, **kwargs)

    _wrapper.__signature__ = inspect.Signature(  # type: ignore[attr-defined]
        parameters=signature_params,
        return_annotation=Any,
    )
    annotations["return"] = Any
    _wrapper.__annotations__ = annotations
    _wrapper.__name__ = tool_name
    _wrapper.__doc__ = f"MCP wrapper for '{tool_name}'."
    return _wrapper


class ClientFactory(Protocol):
    """Constructs the SDK client context used by the MCP server."""

    def __call__(
        self,
        api_key: str,
        config: MCPServerConfig,
    ) -> AsyncContextManager[WalletAPIClient]: ...


@asynccontextmanager
async def _default_client_factory(
    api_key: str,
    config: MCPServerConfig,
) -> AsyncIterator[WalletAPIClient]:
    client = WalletAPIClient(
        base_url=config.api_url,
        api_key=api_key,
        timeout=config.timeout,
    )
    try:
        yield client
    finally:
        await client.close()


class AgentWalletMCPServer:
    """FastMCP stdio wrapper exposing wallet tools."""

    def __init__(
        self,
        *,
        config: MCPServerConfig | None = None,
        client_factory: ClientFactory | None = None,
        mcp_server: FastMCP | None = None,
    ) -> None:
        self._config = config or MCPServerConfig.from_env()
        self._client_factory = client_factory or _default_client_factory
        self._mcp = mcp_server or FastMCP("Cobo Agent Wallet")
        self._client_context: AsyncContextManager[WalletAPIClient] | None = None
        self._toolkit: AgentWalletToolkit | None = None
        self._tool_handlers: dict[str, Callable[..., Any]] | None = None
        self._client_lock = asyncio.Lock()
        self._register_tools()

    @property
    def mcp(self) -> FastMCP:
        return self._mcp

    async def get_tools(self) -> dict[str, Any]:
        tools = self._mcp.get_tools()
        if hasattr(tools, "__await__"):
            return await tools
        return tools

    def run(self) -> None:
        """Start MCP server with stdio transport only."""

        self._mcp.run(transport="stdio")

    async def aclose(self) -> None:
        """Close the cached SDK client context, if initialized."""

        async with self._client_lock:
            if self._client_context is None:
                return
            await self._client_context.__aexit__(None, None, None)
            self._client_context = None
            self._toolkit = None
            self._tool_handlers = None

    def _resolve_api_key(self) -> str:
        api_key = self._config.api_key or os.getenv(AGENT_WALLET_API_KEY)
        if not api_key:
            raise RuntimeError(
                f"Missing API key. Set {AGENT_WALLET_API_KEY} before starting the MCP stdio server."
            )
        return api_key

    async def _get_toolkit(self) -> AgentWalletToolkit:
        if self._toolkit is not None:
            return self._toolkit

        async with self._client_lock:
            if self._toolkit is None:
                api_key = self._resolve_api_key()
                client_context = self._client_factory(api_key, self._config)
                client = await client_context.__aenter__()
                self._client_context = client_context
                toolkit = AgentWalletToolkit(client)
                self._toolkit = toolkit
                self._tool_handlers = {tool.name: tool.handler for tool in toolkit.get_tools()}

        assert self._toolkit is not None
        return self._toolkit

    async def _invoke_tool(self, tool_name: str, **kwargs: Any) -> Any:
        await self._get_toolkit()
        assert self._tool_handlers is not None
        handler = self._tool_handlers[tool_name]
        try:
            return await handler(**kwargs)
        except PolicyDeniedError as exc:
            denial = exc.denial
            message = json.dumps(
                {
                    "error": "POLICY_DENIED",
                    "status_code": exc.status_code,
                    "message": str(exc),
                    "code": denial.code,
                    "reason": denial.reason,
                    "details": denial.details,
                    "suggestion": denial.suggestion,
                },
                sort_keys=True,
            )
            raise RuntimeError(message) from exc
        except ApiException as exc:
            # Safely parse body - may be JSON string, dict, or plain text/HTML
            body: Any = exc.body
            if isinstance(exc.body, str):
                try:
                    body = json.loads(exc.body)
                except (json.JSONDecodeError, ValueError):
                    body = {"raw": exc.body}

            # Check if this is a policy denial (403 with denial structure)
            if exc.status == 403 and isinstance(body, dict):
                from cobo_agent_wallet.errors import PolicyDenial

                denial = PolicyDenial.try_from_response(body)
                if denial:
                    message = json.dumps(
                        {
                            "error": "POLICY_DENIED",
                            "status_code": 403,
                            "message": denial.reason,
                            "code": denial.code,
                            "reason": denial.reason,
                            "details": denial.details,
                            "suggestion": denial.suggestion,
                        },
                        sort_keys=True,
                    )
                    raise RuntimeError(message) from exc

            message = json.dumps(
                {
                    "error": "API_ERROR",
                    "status_code": exc.status or 500,
                    "message": str(exc.reason or exc),
                    "response": body,
                },
                sort_keys=True,
            )
            raise RuntimeError(message) from exc
        except APIError as exc:
            message = json.dumps(
                {
                    "error": "API_ERROR",
                    "status_code": exc.status_code,
                    "message": str(exc),
                    "response": exc.response_body,
                },
                sort_keys=True,
            )
            raise RuntimeError(message) from exc

    def _register_tools(self) -> None:
        for tool_spec in list_tool_specs():
            wrapper = _build_tool_wrapper(
                tool_name=tool_spec.name,
                parameters_schema=tool_spec.parameters,
                invoke_tool=self._invoke_tool,
            )
            self._mcp.tool(
                wrapper,
                name=tool_spec.name,
                description=tool_spec.description,
            )


def create_server(
    *,
    config: MCPServerConfig | None = None,
    client_factory: ClientFactory | None = None,
    mcp_server: FastMCP | None = None,
) -> AgentWalletMCPServer:
    """Build an MCP stdio server instance."""

    return AgentWalletMCPServer(
        config=config,
        client_factory=client_factory,
        mcp_server=mcp_server,
    )


def run() -> None:
    """Entrypoint for ``python -m cobo_agent_wallet.mcp``."""

    create_server().run()


__all__ = [
    "AGENT_WALLET_API_KEY",
    "AGENT_WALLET_API_URL",
    "AGENT_WALLET_TIMEOUT",
    "AgentWalletMCPServer",
    "MCPServerConfig",
    "create_server",
    "run",
]
