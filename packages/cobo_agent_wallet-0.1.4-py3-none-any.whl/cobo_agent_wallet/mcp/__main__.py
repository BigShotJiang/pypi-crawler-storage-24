"""Module entrypoint for running MCP server via ``python -m cobo_agent_wallet.mcp``."""

from cobo_agent_wallet.mcp.server import run

if __name__ == "__main__":
    run()
