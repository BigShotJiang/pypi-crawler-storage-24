"""Compatibility shims for known FastMCP/MCP version skews."""

from __future__ import annotations

import importlib


def ensure_fastmcp_compat() -> None:
    """Patch MCP client naming drift expected by some FastMCP releases."""

    streamable_http = importlib.import_module("mcp.client.streamable_http")
    if hasattr(streamable_http, "streamable_http_client"):
        return
    legacy = getattr(streamable_http, "streamablehttp_client", None)
    if legacy is not None:
        setattr(streamable_http, "streamable_http_client", legacy)

