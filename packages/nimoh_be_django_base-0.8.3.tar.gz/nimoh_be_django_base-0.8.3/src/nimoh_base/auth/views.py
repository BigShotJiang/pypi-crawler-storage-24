"""Authentication views.

This module provides a clean interface for authentication views that have been
organized into logical modules within the view_modules/ directory structure.

Views Organization:
- authentication.py: Core auth (registration, login, logout)
- password.py: Password management (change, reset)
- email.py: Email verification
- tokens.py: JWT token management
- health.py: Health check endpoints
- totp.py: Two-factor authentication (TOTP)

Note: Onboarding-related views are handled by the dedicated onboarding app.
"""

# Import organized authentication views from modules
from .view_modules.authentication import login_view as LoginView
from .view_modules.authentication import logout_view as LogoutView
from .view_modules.authentication import register_view as UserRegistrationView
from .view_modules.email import EmailVerificationResendView, EmailVerificationView
from .view_modules.email_change import email_change_confirm_view as EmailChangeConfirmView
from .view_modules.email_change import email_change_request_view as EmailChangeRequestView
from .view_modules.password import PasswordResetConfirmView
from .view_modules.password import change_password_view as PasswordChangeView
from .view_modules.password import password_reset_request_view as PasswordResetRequestView
from .view_modules.sessions import list_sessions_view as ListSessionsView
from .view_modules.sessions import terminate_all_sessions_view as TerminateAllSessionsView
from .view_modules.sessions import terminate_session_view as TerminateSessionView
from .view_modules.tokens import ExchangeTokenView, RefreshTokenView, TokenVerifyView
from .view_modules.totp import (
    begin_setup_view as TOTPSetupView,
)
from .view_modules.totp import (
    confirm_setup_view as TOTPConfirmView,
)
from .view_modules.totp import (
    disable_view as TOTPDisableView,
)
from .view_modules.totp import (
    regenerate_backup_codes_view as TOTPRegenerateBackupCodesView,
)
from .view_modules.totp import (
    verify_view as TOTPVerifyView,
)

# Export all authentication views for module-level imports
__all__ = [
    "EmailChangeConfirmView",
    "EmailChangeRequestView",
    "EmailVerificationResendView",
    "EmailVerificationView",
    "ExchangeTokenView",
    "ListSessionsView",
    "LoginView",
    "LogoutView",
    "PasswordChangeView",
    "PasswordResetConfirmView",
    "PasswordResetRequestView",
    "RefreshTokenView",
    "TOTPConfirmView",
    "TOTPDisableView",
    "TOTPRegenerateBackupCodesView",
    "TOTPSetupView",
    "TOTPVerifyView",
    "TerminateAllSessionsView",
    "TerminateSessionView",
    "TokenVerifyView",
    "UserRegistrationView",
]
