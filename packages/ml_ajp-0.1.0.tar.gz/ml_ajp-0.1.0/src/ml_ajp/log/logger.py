"""The Interface for logging classes to meet"""

from typing import Union


class Logger:
    """The generic logging interface"""

    def log_record(self, record: dict[str, Union[str, float]], table_name: str):
        """Store record in a table incrementally

        Args:
            record (dict[str,float]): Mapping from column name to value to record
            table (str): The table in which to store the record
        """
        raise NotImplementedError("log_record not implemented")

    def log_text(self, string: str, table_name: str = "logs"):
        """Store text in a table incrementally

        Args:
            text (str): Text to save in table
            table_name (str): The table in which to store the record
        """
        raise NotImplementedError("log_text not implemented")
