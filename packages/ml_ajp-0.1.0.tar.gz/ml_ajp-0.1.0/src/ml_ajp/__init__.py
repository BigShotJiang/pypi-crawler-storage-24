"""Base level utility functions"""
