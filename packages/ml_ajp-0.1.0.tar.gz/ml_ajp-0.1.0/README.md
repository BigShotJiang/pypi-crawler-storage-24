# ML Base (ml_ajp)


![coverage](https://gitlab.perryfamily.house/all/ml-base/badges/main/coverage.svg)
![pipeline](https://gitlab.perryfamily.house/all/ml-base/badges/main/pipeline.svg)
[![Imports: isort](https://img.shields.io/badge/imports-isort-%231674b1?style=flat&labelColor=ef8336)](https://pycqa.github.io/isort/)

## Usage
Import this project into a domain specific repo and run utilities.

## Description
This package does not do the ML for you but provides tools to other ML projects which clean up code considerably.

## Development Installation
Install development dependencies with `make dev`

## Documentation
Automatically generated docs are available on the gitlab

<a href="https://pages.perryfamily.house/all/ml-base/html/index.html" target="_parent"><img src="https://gist.githubusercontent.com/cxmeel/0dbc95191f239b631c3874f4ccf114e2/raw/bb4634715f95ebb209b4e0bcdd4d2d98fe64c64c/documentation-compact.svg"/></a>

## Roadmap
- Logging with wandb
- Packaging and building to pypi
- Training with sagemaker
- Deployment to AWS

## Contributing
All members are free to submit pull requests.

## License
MIT Licenced
