"""Unit tests for core DexFatherBot API methods using MockBot.

Tests cover: send methods, edit/delete, reactions, reply_to_message_id
passthrough, handler decorators, dispatch routing, and exception
propagation in _dispatch.
"""

import pytest

from dexfather.testing import MockBot, TestClient
from dexfather.types import (
    Chat,
    Message,
    MessageReactionUpdated,
    ReactionType,
    Update,
    User,
)


@pytest.fixture
def bot():
    """A fresh MockBot for each test."""
    return MockBot()


# ── Send method tests ─────────────────────────────────────────────


@pytest.mark.asyncio
async def test_send_message(bot):
    """send_message records the correct API call."""
    await bot.send_message(123, "Hello!")
    assert len(bot.sent_messages) == 1
    call = bot.sent_messages[0]
    assert call["method"] == "sendMessage"
    assert call["chat_id"] == 123
    assert call["text"] == "Hello!"


@pytest.mark.asyncio
async def test_send_photo(bot):
    """send_photo records chat_id, photo_url, and caption."""
    await bot.send_photo(42, "https://example.com/pic.jpg", caption="Nice!")
    assert len(bot.sent_messages) == 1
    call = bot.sent_messages[0]
    assert call["method"] == "sendPhoto"
    assert call["chat_id"] == 42
    assert call["photo_url"] == "https://example.com/pic.jpg"
    assert call["caption"] == "Nice!"


@pytest.mark.asyncio
async def test_send_document(bot):
    """send_document records chat_id and document_url."""
    await bot.send_document(10, "https://example.com/file.pdf", caption="Report")
    assert len(bot.sent_messages) == 1
    call = bot.sent_messages[0]
    assert call["method"] == "sendDocument"
    assert call["chat_id"] == 10
    assert call["document_url"] == "https://example.com/file.pdf"
    assert call["caption"] == "Report"


# ── Edit/Delete tests ────────────────────────────────────────────


@pytest.mark.asyncio
async def test_edit_message_text(bot):
    """edit_message_text records the correct parameters."""
    await bot.edit_message_text(1, 42, "Updated text")
    call = bot.sent_messages[0]
    assert call["method"] == "editMessageText"
    assert call["chat_id"] == 1
    assert call["message_id"] == 42
    assert call["text"] == "Updated text"


@pytest.mark.asyncio
async def test_delete_message(bot):
    """delete_message records the correct parameters."""
    await bot.delete_message(1, 99)
    call = bot.sent_messages[0]
    assert call["method"] == "deleteMessage"
    assert call["chat_id"] == 1
    assert call["message_id"] == 99


# ── Reaction tests ───────────────────────────────────────────────


@pytest.mark.asyncio
async def test_set_message_reaction(bot):
    """set_message_reaction records chat_id, message_id, and reaction."""
    await bot.set_message_reaction(1, 42, reaction="thumbsup")
    call = bot.sent_messages[0]
    assert call["method"] == "setMessageReaction"
    assert call["chat_id"] == 1
    assert call["message_id"] == 42
    assert call["reaction"] == "thumbsup"


# ── reply_to_message_id passthrough ──────────────────────────────


@pytest.mark.asyncio
async def test_reply_to_message_id_passthrough(bot):
    """reply_to_message_id is passed through on send_message."""
    await bot.send_message(123, "Reply!", reply_to_message_id=42)
    call = bot.sent_messages[0]
    assert call.get("reply_to_message_id") == 42


@pytest.mark.asyncio
async def test_reply_to_message_id_none_not_recorded(bot):
    """reply_to_message_id=None is not recorded in the call."""
    await bot.send_message(123, "No reply")
    call = bot.sent_messages[0]
    # None values are filtered out by MockBot._request
    assert "reply_to_message_id" not in call


# ── Handler decorator tests ─────────────────────────────────────


@pytest.mark.asyncio
async def test_on_message_decorator(bot):
    """@bot.on_message() registers a handler that fires on text messages."""
    handled = []

    @bot.on_message()
    async def on_text(update, b):
        handled.append(update.message.text)

    update = Update(
        update_id=1,
        message=Message(
            message_id=1,
            chat=Chat(id=1, type="private"),
            from_user=User(id=1),
            text="hello from test",
            date=0,
        ),
    )
    await bot._dispatch(update)
    assert handled == ["hello from test"]


@pytest.mark.asyncio
async def test_on_callback_query_decorator(bot):
    """@bot.on_callback_query() registers a handler that fires on callbacks."""
    handled = []

    @bot.on_callback_query()
    async def on_cb(update, b):
        handled.append(update.callback_query.data)

    from dexfather.types import CallbackQuery

    update = Update(
        update_id=1,
        callback_query=CallbackQuery(
            id="cb1",
            from_user=User(id=1),
            data="test_data",
        ),
    )
    await bot._dispatch(update)
    assert handled == ["test_data"]


@pytest.mark.asyncio
async def test_on_message_reaction_decorator(bot):
    """@bot.on_message_reaction() registers a handler for reaction updates."""
    handled = []

    @bot.on_message_reaction()
    async def on_reaction(update, b):
        handled.append(update.message_reaction.message_id)

    update = Update(
        update_id=1,
        message_reaction=MessageReactionUpdated(
            chat=Chat(id=1, type="private"),
            message_id=42,
            user=User(id=1),
            date=0,
            new_reaction=[ReactionType(emoji="thumbsup")],
        ),
    )
    await bot._dispatch(update)
    assert handled == [42]


# ── Dispatch routing tests ───────────────────────────────────────


@pytest.mark.asyncio
async def test_dispatch_calls_matching_handler(bot):
    """Dispatch routes update to the first matching handler."""
    start_calls = []
    help_calls = []

    @bot.command("start")
    async def on_start(update, b):
        start_calls.append(1)

    @bot.command("help")
    async def on_help(update, b):
        help_calls.append(1)

    update = Update(
        update_id=1,
        message=Message(
            message_id=1,
            chat=Chat(id=1, type="private"),
            text="/help",
            date=0,
        ),
    )
    await bot._dispatch(update)
    assert start_calls == []
    assert help_calls == [1]


@pytest.mark.asyncio
async def test_dispatch_propagates_exceptions(bot):
    """MockBot._dispatch re-raises handler exceptions (not swallowed)."""

    @bot.on_message()
    async def on_msg(update, b):
        raise ValueError("intentional test error")

    update = Update(
        update_id=1,
        message=Message(
            message_id=1,
            chat=Chat(id=1, type="private"),
            from_user=User(id=1),
            text="trigger error",
            date=0,
        ),
    )
    with pytest.raises(ValueError, match="intentional test error"):
        await bot._dispatch(update)


# ── MockBot reset/state tests ───────────────────────────────────


@pytest.mark.asyncio
async def test_multiple_calls_accumulate(bot):
    """Multiple API calls are all recorded in sent_messages."""
    await bot.send_message(1, "First")
    await bot.send_message(2, "Second")
    await bot.send_photo(3, "https://example.com/pic.jpg")
    assert len(bot.sent_messages) == 3
    assert bot.sent_messages[0]["text"] == "First"
    assert bot.sent_messages[1]["text"] == "Second"
    assert bot.sent_messages[2]["method"] == "sendPhoto"


@pytest.mark.asyncio
async def test_bot_reset_clears_calls(bot):
    """MockBot.reset() clears all recorded calls."""
    await bot.send_message(1, "Hello")
    assert len(bot.sent_messages) == 1
    bot.reset()
    assert len(bot.sent_messages) == 0
