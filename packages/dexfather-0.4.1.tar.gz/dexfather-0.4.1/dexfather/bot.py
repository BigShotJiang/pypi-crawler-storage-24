"""DexFatherBot — Main bot class for the Dexster Bot API.

Supports both polling and webhook modes for receiving updates.
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac as hmac_mod
import json
import signal
from typing import Any, BinaryIO, Callable, Optional, Union

from ._logging import get_logger, setup_logging
from .client import DexFatherClient
from .exceptions import APIError
from .handlers import Handler
from .keyboards import (
    InlineKeyboardMarkup, ReplyKeyboardMarkup, ReplyKeyboardRemove, ForceReply,
)
from .middleware import BaseMiddleware
from .types import (
    ApiResponse, Update, Message, BotInfo, Poll, PollAnswer,
    ChatMember, ChatInfo, ChatPermissions, MenuButton, WebhookInfo,
    Dice, Contact, Venue, Location, InlineQuery,
    InlineQueryResultArticle, InlineQueryResultPhoto,
    BotFile, UserProfilePhotos,
)

# Backwards-compatible alias — old code using `from dexfather.bot import ApiError` still works.
ApiError = APIError

logger = get_logger("dexfather")

# Type alias for reply markup
ReplyMarkup = Union[InlineKeyboardMarkup, ReplyKeyboardMarkup, ReplyKeyboardRemove, ForceReply]

# Default Dexster API base URL
DEFAULT_API_BASE = "https://dexster.io/api/bot"


class MiddlewareContext:
    """Restricted bot proxy passed to middleware -- hides raw token.

    Exposes all public API methods (send_message, etc.) but raises
    AttributeError on ``token`` and ``_api`` access. This prevents
    third-party middleware from exfiltrating the bot token.
    """

    __slots__ = ('_bot',)

    def __init__(self, bot: 'DexFatherBot') -> None:
        object.__setattr__(self, '_bot', bot)

    def __getattr__(self, name: str) -> Any:
        if name in ('token', '_api', '_token'):
            raise AttributeError(
                f"Middleware cannot access '{name}' -- use bot API methods instead"
            )
        return getattr(object.__getattribute__(self, '_bot'), name)


class DexFatherBot:
    """Dexster Bot API client.

    Usage:
        bot = DexFatherBot("dxt_your_token_here")

        @bot.command("start")
        async def on_start(update, bot):
            await bot.send_message(update.message.chat.id, "Hello!")

        bot.run_polling()
    """

    def __init__(
        self,
        token: str,
        api_base: str = DEFAULT_API_BASE,
        timeout: float = 30.0,
    ) -> None:
        """Initialize the bot with an API token.

        Args:
            token: Bot API token in ``dxt_...`` format.
            api_base: Base URL for the Bot API (default: ``https://dexster.io/api/bot``).
            timeout: HTTP request timeout in seconds (default: 30).
        """
        self.token = token
        self.api_base = api_base.rstrip("/")
        self._api = DexFatherClient(token, api_base, timeout)
        self._handlers: list[Handler] = []
        self._middlewares: list[BaseMiddleware] = []
        self._running = False
        self._offset: int = 0
        self._error_handler: Optional[Callable] = None

    # ── Async Context Manager ────────────────────────────────────────

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.stop()
        return False

    # ── Error Handler ────────────────────────────────────────────────

    def catch(self, handler: Callable) -> None:
        """Register a global error handler for unhandled handler exceptions.

        The handler is called with ``(update, exception)`` when an exception
        propagates out of a handler callback.  If no error handler is
        registered, errors are logged and swallowed (default behaviour).

        Args:
            handler: An async or sync callable ``(update, error) -> None``.
        """
        self._error_handler = handler

    # ── Properties (backwards-compat proxies to DexFatherClient) ──────

    @property
    def _client(self) -> Any:
        """Proxy to the underlying httpx.AsyncClient for backwards compat."""
        return self._api._client

    @property
    def _ws(self) -> Any:
        """Proxy to the WebSocket connection."""
        return self._api._ws

    @_ws.setter
    def _ws(self, value: Any) -> None:
        self._api._ws = value

    @property
    def _pending_responses(self) -> dict[str, asyncio.Future[Any]]:
        """Proxy to pending WS response futures."""
        return self._api._pending_responses

    # ── Middleware ─────────────────────────────────────────────────────

    def add_middleware(self, middleware: BaseMiddleware) -> None:
        """Register a middleware for update processing.

        Middlewares execute in registration order (first registered =
        outermost).  Each middleware wraps the dispatch pipeline and can
        run pre/post processing around handler execution.

        Args:
            middleware: A :class:`~dexfather.middleware.BaseMiddleware`
                subclass instance.
        """
        self._middlewares.append(middleware)

    # ── Handler Registration ──────────────────────────────────────────

    def add_handler(self, handler: Handler) -> None:
        """Register an update handler."""
        self._handlers.append(handler)

    def command(self, cmd: Union[str, list[str]]) -> Callable:
        """Decorator to register a command handler.

        Usage:
            @bot.command("start")
            async def on_start(update, bot):
                ...
        """
        from .handlers import CommandHandler

        def decorator(func: Callable) -> Callable:
            self.add_handler(CommandHandler(cmd, func))
            return func

        return decorator

    def on_message(self, pattern: Optional[str] = None, *, filters=None) -> Callable:
        """Decorator to register a message handler.

        Usage:
            @bot.on_message()
            async def on_text(update, bot): ...

            @bot.on_message(filters=TEXT & ~COMMAND)
            async def on_non_cmd(update, bot): ...
        """
        from .handlers import MessageHandler

        def decorator(func: Callable) -> Callable:
            self.add_handler(MessageHandler(func, pattern=pattern, filters=filters))
            return func

        return decorator

    def on_callback_query(self, pattern: Optional[str] = None) -> Callable:
        """Decorator to register a callback query handler.

        Usage:
            @bot.on_callback_query(r"^confirm:")
            async def on_confirm(update, bot):
                ...
        """
        from .handlers import CallbackQueryHandler

        def decorator(func: Callable) -> Callable:
            self.add_handler(CallbackQueryHandler(func, pattern=pattern))
            return func

        return decorator

    def on_inline_query(self, pattern: Optional[str] = None) -> Callable:
        """Decorator to register an inline query handler.

        Usage:
            @bot.on_inline_query()
            async def on_inline(update, bot):
                ...
        """
        from .handlers import InlineQueryHandler

        def decorator(func: Callable) -> Callable:
            self.add_handler(InlineQueryHandler(func, pattern=pattern))
            return func

        return decorator

    def on_poll_answer(self) -> Callable:
        """Decorator to register a poll answer handler.

        Usage:
            @bot.on_poll_answer()
            async def on_vote(update, bot):
                ...
        """
        from .handlers import PollAnswerHandler

        def decorator(func: Callable) -> Callable:
            self.add_handler(PollAnswerHandler(func))
            return func

        return decorator

    def on_chat_member(self) -> Callable:
        """Decorator to register a chat member update handler.

        Usage:
            @bot.on_chat_member()
            async def on_member(update, bot):
                ...
        """
        from .handlers import ChatMemberHandler

        def decorator(func: Callable) -> Callable:
            self.add_handler(ChatMemberHandler(func))
            return func

        return decorator

    def on_chat_join_request(self) -> Callable:
        """Decorator to register a chat join request handler.

        Usage:
            @bot.on_chat_join_request()
            async def on_join(update, bot):
                ...
        """
        from .handlers import ChatJoinRequestHandler

        def decorator(func: Callable) -> Callable:
            self.add_handler(ChatJoinRequestHandler(func))
            return func

        return decorator

    def on_chosen_inline_result(self) -> Callable:
        """Decorator to register a chosen inline result handler.

        Usage:
            @bot.on_chosen_inline_result()
            async def on_chosen(update, bot):
                ...
        """
        from .handlers import ChosenInlineResultHandler

        def decorator(func: Callable) -> Callable:
            self.add_handler(ChosenInlineResultHandler(func))
            return func

        return decorator

    def on_message_reaction(self) -> Callable:
        """Register a handler for message reaction updates.

        Usage::

            @bot.on_message_reaction()
            async def handle_reaction(update, bot):
                print(f"Reaction: {update.message_reaction}")
        """
        from .handlers import TypeHandler

        def decorator(func: Callable) -> Callable:
            self.add_handler(TypeHandler("message_reaction", func))
            return func

        return decorator

    # ── API Methods ───────────────────────────────────────────────────

    async def _request(self, method: str, **kwargs: Any) -> ApiResponse:
        """Make an API request — delegates to DexFatherClient."""
        return await self._api._request(method, **kwargs)

    # ── Identity & Configuration (API-01) ─────────────────────────────

    async def get_me(self) -> BotInfo:
        """Get bot's own info."""
        resp = await self._request("getMe")
        return BotInfo.model_validate(resp.result)

    async def set_my_name(self, name: str) -> bool:
        """Set the bot's display name."""
        resp = await self._request("setMyName", name=name)
        return resp.ok

    async def get_my_name(self) -> str:
        """Get the bot's display name."""
        resp = await self._request("getMyName")
        return resp.result.get("name", "")

    async def set_my_description(self, description: str) -> bool:
        """Set the bot's description (shown in empty chat)."""
        resp = await self._request("setMyDescription", description=description)
        return resp.ok

    async def get_my_description(self) -> str:
        """Get the bot's description."""
        resp = await self._request("getMyDescription")
        return resp.result.get("description", "")

    async def set_my_short_description(self, short_description: str) -> bool:
        """Set the bot's short description (shown in profile)."""
        resp = await self._request("setMyShortDescription", short_description=short_description)
        return resp.ok

    async def get_my_short_description(self) -> str:
        """Get the bot's short description."""
        resp = await self._request("getMyShortDescription")
        return resp.result.get("short_description", "")

    async def set_my_profile_photo(self, photo_url: str) -> bool:
        """Set the bot's profile photo by URL."""
        resp = await self._request("setMyProfilePhoto", photo_url=photo_url)
        return resp.ok

    async def remove_my_profile_photo(self) -> bool:
        """Remove the bot's profile photo."""
        resp = await self._request("removeMyProfilePhoto")
        return resp.ok

    async def log_out(self) -> bool:
        """Log out from the bot API (revokes token)."""
        resp = await self._request("logOut")
        return resp.ok

    async def close(self) -> bool:
        """Close the bot instance (soft-deactivate)."""
        resp = await self._request("close")
        return resp.ok

    # ── Updates ───────────────────────────────────────────────────────

    async def get_updates(
        self,
        offset: Optional[int] = None,
        limit: int = 100,
        timeout: int = 30,
    ) -> list[Update]:
        """Long-poll for new updates."""
        resp = await self._request(
            "getUpdates",
            offset=offset,
            limit=limit,
            timeout=timeout,
        )
        if not resp.result:
            return []
        return [Update.model_validate(u) for u in resp.result]

    # ── Messaging ─────────────────────────────────────────────────────

    async def send_message(
        self,
        chat_id: int,
        text: str,
        reply_markup: Optional[ReplyMarkup] = None,
        reply_to_message_id: Optional[int] = None,
        parse_mode: Optional[str] = None,
    ) -> Message:
        """Send a text message."""
        resp = await self._request(
            "sendMessage",
            chat_id=chat_id,
            text=text,
            reply_markup=reply_markup,
            reply_to_message_id=reply_to_message_id,
            parse_mode=parse_mode,
        )
        msg = Message.model_validate(resp.result)
        msg._bind(self)
        return msg

    async def edit_message_text(
        self,
        chat_id: int,
        message_id: int,
        text: str,
        reply_markup: Optional[InlineKeyboardMarkup] = None,
        parse_mode: Optional[str] = None,
    ) -> Message:
        """Edit an existing message's text."""
        resp = await self._request(
            "editMessageText",
            chat_id=chat_id,
            message_id=message_id,
            text=text,
            reply_markup=reply_markup,
            parse_mode=parse_mode,
        )
        msg = Message.model_validate(resp.result)
        msg._bind(self)
        return msg

    async def edit_message_reply_markup(
        self,
        chat_id: int,
        message_id: int,
        reply_markup: Optional[InlineKeyboardMarkup] = None,
    ) -> Message:
        """Edit an existing message's inline keyboard."""
        resp = await self._request(
            "editMessageReplyMarkup",
            chat_id=chat_id,
            message_id=message_id,
            reply_markup=reply_markup,
        )
        msg = Message.model_validate(resp.result)
        msg._bind(self)
        return msg

    async def edit_message_caption(
        self,
        chat_id: int,
        message_id: int,
        caption: Optional[str] = None,
        reply_markup: Optional[InlineKeyboardMarkup] = None,
        parse_mode: Optional[str] = None,
    ) -> Message:
        """Edit the caption of a media message."""
        resp = await self._request(
            "editMessageCaption",
            chat_id=chat_id,
            message_id=message_id,
            caption=caption,
            reply_markup=reply_markup,
            parse_mode=parse_mode,
        )
        msg = Message.model_validate(resp.result)
        msg._bind(self)
        return msg

    async def edit_message_media(
        self,
        chat_id: int,
        message_id: int,
        media_type: str,
        media_url: str,
        caption: Optional[str] = None,
        reply_markup: Optional[InlineKeyboardMarkup] = None,
        parse_mode: Optional[str] = None,
    ) -> Message:
        """Replace the media on an existing message.

        Args:
            media_type: One of 'photo', 'video', 'document', 'animation'.
            media_url: URL of the new media file.
        """
        resp = await self._request(
            "editMessageMedia",
            chat_id=chat_id,
            message_id=message_id,
            media={"type": media_type, "url": media_url, "caption": caption, "parse_mode": parse_mode},
            reply_markup=reply_markup,
        )
        msg = Message.model_validate(resp.result)
        msg._bind(self)
        return msg

    async def send_sticker(
        self,
        chat_id: int,
        sticker_url: str,
        emoji: Optional[str] = None,
        reply_to_message_id: Optional[int] = None,
        reply_markup: Optional[InlineKeyboardMarkup] = None,
    ) -> Message:
        """Send a sticker message."""
        resp = await self._request(
            "sendSticker",
            chat_id=chat_id,
            sticker_url=sticker_url,
            emoji=emoji,
            reply_to_message_id=reply_to_message_id,
            reply_markup=reply_markup,
        )
        msg = Message.model_validate(resp.result)
        msg._bind(self)
        return msg

    async def get_user_profile_photos(self, user_id: int) -> UserProfilePhotos:
        """Get a user's profile photos.

        Returns:
            UserProfilePhotos with total_count and photos array.
        """
        resp = await self._request(
            "getUserProfilePhotos",
            user_id=user_id,
        )
        return UserProfilePhotos.model_validate(resp.result)

    async def get_file(self, file_id: str) -> BotFile:
        """Get file download URL by file ID.

        Returns:
            BotFile with file_id, file_url, and optional metadata.
        """
        resp = await self._request(
            "getFile",
            file_id=file_id,
        )
        return BotFile.model_validate(resp.result)

    async def upload_file(
        self,
        file: Union[str, bytes, BinaryIO],
        file_type: Optional[str] = None,
        filename: Optional[str] = None,
    ) -> BotFile:
        """Upload a file to the server and get a BotFile back.

        Args:
            file: File to upload. Accepts a local file path (str), raw bytes,
                or any file-like object with a ``.read()`` method (e.g. BytesIO).
            file_type: Optional explicit type hint (photo, document, video,
                audio, voice, animation, sticker, video_note).
            filename: Optional filename for the upload. Inferred from path
                when *file* is a string; defaults to ``"upload"`` otherwise.

        Returns:
            BotFile with file_id, file_url, and metadata.
        """
        import os

        if isinstance(file, str):
            # file is a filesystem path
            if filename is None:
                filename = os.path.basename(file)
            with open(file, "rb") as f:
                file_data = f.read()
        elif isinstance(file, bytes):
            file_data = file
            if filename is None:
                filename = "upload"
        elif hasattr(file, "read"):
            file_data = file.read()
            if isinstance(file_data, str):
                file_data = file_data.encode("utf-8")
            # Try to get name from file-like object
            if filename is None:
                filename = getattr(file, "name", None)
                if filename:
                    filename = os.path.basename(filename)
                else:
                    filename = "upload"
        else:
            raise TypeError(
                f"file must be a str path, bytes, or file-like object, got {type(file).__name__}"
            )

        # Use httpx multipart upload
        files = {"file": (filename, file_data)}
        data = {}
        if file_type:
            data["file_type"] = file_type

        resp = await self._api._client.post(
            f"{self.api_base}/uploadFile",
            files=files,
            data=data,
            headers={"Authorization": f"Bot {self.token}"},
        )
        result = resp.json()
        if not result.get("ok"):
            raise APIError(result.get("error_code", 500), result.get("description", "Upload failed"))
        return BotFile.model_validate(result["result"])

    async def set_chat_photo(self, chat_id: int, photo_url: str) -> bool:
        """Set a chat's profile photo."""
        resp = await self._request(
            "setChatPhoto",
            chat_id=chat_id,
            photo_url=photo_url,
        )
        return resp.ok

    async def create_chat_invite_link(
        self,
        chat_id: int,
        name: Optional[str] = None,
        expire_date: Optional[int] = None,
        member_limit: Optional[int] = None,
        creates_join_request: Optional[bool] = None,
    ) -> dict:
        """Create a new invite link for a chat.

        Args:
            expire_date: Unix timestamp when the link expires.
            member_limit: Max number of users that can join via this link.
            creates_join_request: If True, users need admin approval to join.
        """
        resp = await self._request(
            "createChatInviteLink",
            chat_id=chat_id,
            name=name,
            expire_date=expire_date,
            member_limit=member_limit,
            creates_join_request=creates_join_request,
        )
        return resp.result

    async def edit_chat_invite_link(
        self,
        chat_id: int,
        invite_link: str,
        name: Optional[str] = None,
        expire_date: Optional[int] = None,
        member_limit: Optional[int] = None,
        creates_join_request: Optional[bool] = None,
    ) -> dict:
        """Edit an existing invite link."""
        resp = await self._request(
            "editChatInviteLink",
            chat_id=chat_id,
            invite_link=invite_link,
            name=name,
            expire_date=expire_date,
            member_limit=member_limit,
            creates_join_request=creates_join_request,
        )
        return resp.result

    async def revoke_chat_invite_link(self, chat_id: int, invite_link: str) -> dict:
        """Revoke an existing invite link."""
        resp = await self._request(
            "revokeChatInviteLink",
            chat_id=chat_id,
            invite_link=invite_link,
        )
        return resp.result

    async def delete_message(self, chat_id: int, message_id: int) -> bool:
        """Delete a message."""
        resp = await self._request(
            "deleteMessages",
            chat_id=chat_id,
            message_ids=[message_id],
        )
        return resp.ok

    async def answer_callback_query(
        self,
        callback_query_id: str,
        text: Optional[str] = None,
        show_alert: bool = False,
    ) -> bool:
        """Answer a callback query (show toast/alert to user)."""
        resp = await self._request(
            "answerCallbackQuery",
            callback_query_id=callback_query_id,
            text=text,
            show_alert=show_alert,
        )
        return resp.ok

    async def send_chat_action(self, chat_id: int, action: str = "typing") -> bool:
        """Send a chat action (typing indicator, etc.)."""
        resp = await self._request(
            "sendChatAction",
            chat_id=chat_id,
            action=action,
        )
        return resp.ok

    async def send_document(
        self,
        chat_id: int,
        document_url: str,
        caption: Optional[str] = None,
        file_name: Optional[str] = None,
        reply_markup: Optional[ReplyMarkup] = None,
        reply_to_message_id: Optional[int] = None,
    ) -> Message:
        """Send a document by URL."""
        resp = await self._request(
            "sendDocument",
            chat_id=chat_id,
            document_url=document_url,
            caption=caption,
            file_name=file_name,
            reply_markup=reply_markup,
            reply_to_message_id=reply_to_message_id,
        )
        msg = Message.model_validate(resp.result)
        msg._bind(self)
        return msg

    async def send_animation(
        self,
        chat_id: int,
        animation_url: str,
        caption: Optional[str] = None,
        reply_markup: Optional[ReplyMarkup] = None,
        reply_to_message_id: Optional[int] = None,
    ) -> Message:
        """Send a GIF/animation by URL."""
        resp = await self._request(
            "sendAnimation",
            chat_id=chat_id,
            animation_url=animation_url,
            caption=caption,
            reply_markup=reply_markup,
            reply_to_message_id=reply_to_message_id,
        )
        msg = Message.model_validate(resp.result)
        msg._bind(self)
        return msg

    async def send_video(
        self,
        chat_id: int,
        video_url: str,
        caption: Optional[str] = None,
        reply_markup: Optional[ReplyMarkup] = None,
        reply_to_message_id: Optional[int] = None,
    ) -> Message:
        """Send a video by URL."""
        resp = await self._request(
            "sendVideo",
            chat_id=chat_id,
            video_url=video_url,
            caption=caption,
            reply_markup=reply_markup,
            reply_to_message_id=reply_to_message_id,
        )
        msg = Message.model_validate(resp.result)
        msg._bind(self)
        return msg

    async def send_location(
        self,
        chat_id: int,
        latitude: float,
        longitude: float,
        live_period: Optional[int] = None,
        heading: Optional[int] = None,
        horizontal_accuracy: Optional[float] = None,
        proximity_alert_radius: Optional[int] = None,
        name: Optional[str] = None,
        address: Optional[str] = None,
        reply_markup: Optional[ReplyMarkup] = None,
        reply_to_message_id: Optional[int] = None,
    ) -> Message:
        """Send a location. If live_period is set, sends a live location that can be updated."""
        resp = await self._request(
            "sendLocation",
            chat_id=chat_id,
            latitude=latitude,
            longitude=longitude,
            live_period=live_period,
            heading=heading,
            horizontal_accuracy=horizontal_accuracy,
            proximity_alert_radius=proximity_alert_radius,
            name=name,
            address=address,
            reply_markup=reply_markup,
            reply_to_message_id=reply_to_message_id,
        )
        msg = Message.model_validate(resp.result)
        msg._bind(self)
        return msg

    async def edit_message_live_location(
        self,
        chat_id: int,
        message_id: int,
        latitude: float,
        longitude: float,
        heading: Optional[int] = None,
        horizontal_accuracy: Optional[float] = None,
        proximity_alert_radius: Optional[int] = None,
        reply_markup: Optional[ReplyMarkup] = None,
    ) -> Message:
        """Update coordinates of a live location message."""
        resp = await self._request(
            "editMessageLiveLocation",
            chat_id=chat_id,
            message_id=message_id,
            latitude=latitude,
            longitude=longitude,
            heading=heading,
            horizontal_accuracy=horizontal_accuracy,
            proximity_alert_radius=proximity_alert_radius,
            reply_markup=reply_markup,
        )
        msg = Message.model_validate(resp.result)
        msg._bind(self)
        return msg

    async def stop_message_live_location(
        self,
        chat_id: int,
        message_id: int,
        reply_markup: Optional[ReplyMarkup] = None,
    ) -> Message:
        """Stop updating a live location message. The location becomes static."""
        resp = await self._request(
            "stopMessageLiveLocation",
            chat_id=chat_id,
            message_id=message_id,
            reply_markup=reply_markup,
        )
        msg = Message.model_validate(resp.result)
        msg._bind(self)
        return msg

    async def forward_message(
        self,
        chat_id: int,
        from_chat_id: int,
        message_id: int,
    ) -> Message:
        """Forward a message."""
        resp = await self._request(
            "forwardMessage",
            chat_id=chat_id,
            from_chat_id=from_chat_id,
            message_id=message_id,
        )
        msg = Message.model_validate(resp.result)
        msg._bind(self)
        return msg

    async def send_photo(self, chat_id: int, photo_url: str, caption: Optional[str] = None,
                         parse_mode: Optional[str] = None, reply_markup: Optional[ReplyMarkup] = None,
                         reply_to_message_id: Optional[int] = None) -> Message:
        """Send a photo by URL."""
        resp = await self._request("sendPhoto", chat_id=chat_id, photo_url=photo_url,
                                   caption=caption, parse_mode=parse_mode, reply_markup=reply_markup,
                                   reply_to_message_id=reply_to_message_id)
        msg = Message.model_validate(resp.result)
        msg._bind(self)
        return msg

    async def send_voice(self, chat_id: int, voice_url: str, caption: Optional[str] = None,
                         duration: Optional[int] = None, reply_markup: Optional[ReplyMarkup] = None,
                         reply_to_message_id: Optional[int] = None) -> Message:
        """Send a voice message by URL."""
        resp = await self._request("sendVoice", chat_id=chat_id, voice_url=voice_url,
                                   caption=caption, duration=duration, reply_markup=reply_markup,
                                   reply_to_message_id=reply_to_message_id)
        msg = Message.model_validate(resp.result)
        msg._bind(self)
        return msg

    async def send_audio(self, chat_id: int, audio_url: str, caption: Optional[str] = None,
                         duration: Optional[int] = None, performer: Optional[str] = None,
                         title: Optional[str] = None, reply_markup: Optional[ReplyMarkup] = None,
                         reply_to_message_id: Optional[int] = None) -> Message:
        """Send an audio file by URL."""
        resp = await self._request("sendAudio", chat_id=chat_id, audio_url=audio_url,
                                   caption=caption, duration=duration, performer=performer,
                                   title=title, reply_markup=reply_markup,
                                   reply_to_message_id=reply_to_message_id)
        msg = Message.model_validate(resp.result)
        msg._bind(self)
        return msg

    async def send_video_note(self, chat_id: int, video_note_url: str,
                              duration: Optional[int] = None, length: Optional[int] = None,
                              reply_markup: Optional[ReplyMarkup] = None,
                              reply_to_message_id: Optional[int] = None) -> Message:
        """Send a video note (circular video). No caption support per Telegram API spec."""
        resp = await self._request("sendVideoNote", chat_id=chat_id, video_note_url=video_note_url,
                                   duration=duration, length=length, reply_markup=reply_markup,
                                   reply_to_message_id=reply_to_message_id)
        msg = Message.model_validate(resp.result)
        msg._bind(self)
        return msg

    async def send_media_group(self, chat_id: int, media: list[dict],
                               reply_to_message_id: Optional[int] = None) -> list[Message]:
        """Send 2-10 photos/videos as an album."""
        resp = await self._request("sendMediaGroup", chat_id=chat_id, media=media,
                                   reply_to_message_id=reply_to_message_id)
        msgs = [Message.model_validate(m) for m in resp.result]
        for m in msgs:
            m._bind(self)
        return msgs

    async def send_contact(self, chat_id: int, phone_number: str, first_name: str,
                           last_name: Optional[str] = None, reply_markup: Optional[ReplyMarkup] = None,
                           reply_to_message_id: Optional[int] = None) -> Message:
        """Send a contact."""
        resp = await self._request("sendContact", chat_id=chat_id, phone_number=phone_number,
                                   first_name=first_name, last_name=last_name, reply_markup=reply_markup,
                                   reply_to_message_id=reply_to_message_id)
        msg = Message.model_validate(resp.result)
        msg._bind(self)
        return msg

    async def send_venue(self, chat_id: int, latitude: float, longitude: float,
                         title: str, address: str, reply_markup: Optional[ReplyMarkup] = None,
                         reply_to_message_id: Optional[int] = None) -> Message:
        """Send a venue."""
        resp = await self._request("sendVenue", chat_id=chat_id, latitude=latitude, longitude=longitude,
                                   title=title, address=address, reply_markup=reply_markup,
                                   reply_to_message_id=reply_to_message_id)
        msg = Message.model_validate(resp.result)
        msg._bind(self)
        return msg

    async def send_dice(self, chat_id: int, emoji: str = "\U0001f3b2",
                        reply_markup: Optional[ReplyMarkup] = None,
                        reply_to_message_id: Optional[int] = None) -> Message:
        """Send a dice animation."""
        resp = await self._request("sendDice", chat_id=chat_id, emoji=emoji, reply_markup=reply_markup,
                                   reply_to_message_id=reply_to_message_id)
        msg = Message.model_validate(resp.result)
        msg._bind(self)
        return msg

    async def send_poll(self, chat_id: int, question: str, options: list[str],
                        type: str = "regular", allows_multiple_answers: bool = False,
                        correct_option_id: Optional[int] = None, explanation: Optional[str] = None,
                        open_period: Optional[int] = None, is_anonymous: bool = True,
                        reply_markup: Optional[ReplyMarkup] = None,
                        reply_to_message_id: Optional[int] = None) -> Poll:
        """Send a poll. Returns the Poll object."""
        resp = await self._request("sendPoll", chat_id=chat_id, question=question, options=options,
                                   type=type, allows_multiple_answers=allows_multiple_answers,
                                   correct_option_id=correct_option_id, explanation=explanation,
                                   open_period=open_period, is_anonymous=is_anonymous, reply_markup=reply_markup,
                                   reply_to_message_id=reply_to_message_id)
        return Poll.model_validate(resp.result["poll"])

    async def stop_poll(self, chat_id: int, message_id: int) -> Poll:
        """Stop a poll and get final results."""
        resp = await self._request("stopPoll", chat_id=chat_id, message_id=message_id)
        return Poll.model_validate(resp.result)

    async def set_message_reaction(
        self,
        chat_id: int,
        message_id: int,
        reaction: Optional[str] = None,
    ) -> bool:
        """Set a reaction on a message.

        Args:
            chat_id: Chat containing the message.
            message_id: Message to react to.
            reaction: Emoji reaction string, or None to remove reaction.

        Returns:
            True on success.
        """
        resp = await self._request(
            "setMessageReaction",
            chat_id=chat_id,
            message_id=message_id,
            reaction=reaction,
        )
        return resp.ok

    async def copy_message(self, chat_id: int, from_chat_id: int, message_id: int,
                           caption: Optional[str] = None) -> dict:
        """Copy a message to another chat."""
        resp = await self._request("copyMessage", chat_id=chat_id, from_chat_id=from_chat_id,
                                   message_id=message_id, caption=caption)
        return resp.result

    # ── Batch Operations ──────────────────────────────────────────────

    async def delete_messages(self, chat_id: int, message_ids: list[int]) -> bool:
        """Delete multiple messages."""
        resp = await self._request("deleteMessages", chat_id=chat_id, message_ids=message_ids)
        return resp.ok

    async def forward_messages(self, chat_id: int, from_chat_id: int, message_ids: list[int]) -> list[Message]:
        """Forward multiple messages."""
        resp = await self._request("forwardMessages", chat_id=chat_id, from_chat_id=from_chat_id,
                                   message_ids=message_ids)
        msgs = [Message.model_validate(m) for m in resp.result]
        for m in msgs:
            m._bind(self)
        return msgs

    async def copy_messages(self, chat_id: int, from_chat_id: int, message_ids: list[int]) -> list[dict]:
        """Copy multiple messages to another chat."""
        resp = await self._request("copyMessages", chat_id=chat_id, from_chat_id=from_chat_id,
                                   message_ids=message_ids)
        return resp.result

    # ── Inline Query ──────────────────────────────────────────────────

    async def answer_inline_query(self, inline_query_id: str, results: list,
                                   cache_time: int = 300, is_personal: bool = False,
                                   next_offset: Optional[str] = None,
                                   button: Optional[dict] = None) -> bool:
        """Answer an inline query with results."""
        # Serialize Pydantic result objects if needed
        serialized = []
        for r in results:
            if hasattr(r, "model_dump"):
                serialized.append(r.model_dump(exclude_none=True))
            else:
                serialized.append(r)
        resp = await self._request("answerInlineQuery", inline_query_id=inline_query_id,
                                   results=serialized, cache_time=cache_time,
                                   is_personal=is_personal, next_offset=next_offset, button=button)
        return resp.ok

    # ── Scoped Commands ───────────────────────────────────────────────

    async def set_my_commands(self, commands: list[dict[str, str]],
                              scope: Optional[dict] = None,
                              language_code: Optional[str] = None) -> bool:
        """Set the bot's command list, optionally scoped."""
        resp = await self._request("setMyCommands", commands=commands,
                                   scope=scope, language_code=language_code)
        return resp.ok

    async def get_my_commands(self, scope: Optional[dict] = None,
                              language_code: Optional[str] = None) -> list[dict[str, str]]:
        """Get the bot's registered commands."""
        resp = await self._request("getMyCommands", scope=scope, language_code=language_code)
        return resp.result or []

    async def delete_my_commands(self, scope: Optional[dict] = None,
                                 language_code: Optional[str] = None) -> bool:
        """Delete the bot's commands, optionally scoped."""
        resp = await self._request("deleteMyCommands", scope=scope, language_code=language_code)
        return resp.ok

    # ── Menu Button ───────────────────────────────────────────────────

    async def set_chat_menu_button(self, chat_id: Optional[int] = None,
                                    menu_button: Optional[dict] = None) -> bool:
        """Set the menu button for a chat or the default menu button."""
        resp = await self._request("setChatMenuButton", chat_id=chat_id, menu_button=menu_button)
        return resp.ok

    async def get_chat_menu_button(self, chat_id: Optional[int] = None) -> MenuButton:
        """Get the menu button for a chat."""
        resp = await self._request("getChatMenuButton", chat_id=chat_id)
        return MenuButton.model_validate(resp.result)

    # ── Chat Management ───────────────────────────────────────────────

    async def ban_chat_member(self, chat_id: int, user_id: int,
                              until_date: Optional[int] = None,
                              revoke_messages: bool = False) -> bool:
        """Ban a user from a chat."""
        resp = await self._request("banChatMember", chat_id=chat_id, user_id=user_id,
                                   until_date=until_date, revoke_messages=revoke_messages)
        return resp.ok

    async def unban_chat_member(self, chat_id: int, user_id: int,
                                only_if_banned: bool = False) -> bool:
        """Unban a user from a chat."""
        resp = await self._request("unbanChatMember", chat_id=chat_id, user_id=user_id,
                                   only_if_banned=only_if_banned)
        return resp.ok

    async def restrict_chat_member(self, chat_id: int, user_id: int,
                                    permissions: dict, until_date: Optional[int] = None) -> bool:
        """Restrict a chat member's permissions."""
        resp = await self._request("restrictChatMember", chat_id=chat_id, user_id=user_id,
                                   permissions=permissions, until_date=until_date)
        return resp.ok

    async def promote_chat_member(self, chat_id: int, user_id: int, **rights: bool) -> bool:
        """Promote a user to admin with specified rights (can_delete_messages, can_ban_users, etc.)."""
        resp = await self._request("promoteChatMember", chat_id=chat_id, user_id=user_id, **rights)
        return resp.ok

    async def set_chat_administrator_custom_title(self, chat_id: int, user_id: int,
                                                   custom_title: str) -> bool:
        """Set a custom title for a chat administrator."""
        resp = await self._request("setChatAdministratorCustomTitle", chat_id=chat_id,
                                   user_id=user_id, custom_title=custom_title)
        return resp.ok

    async def get_chat(self, chat_id: int) -> ChatInfo:
        """Get full chat information."""
        resp = await self._request("getChat", chat_id=chat_id)
        return ChatInfo.model_validate(resp.result)

    async def get_chat_member(self, chat_id: int, user_id: int) -> ChatMember:
        """Get a chat member's info."""
        resp = await self._request("getChatMember", chat_id=chat_id, user_id=user_id)
        return ChatMember.model_validate(resp.result)

    async def get_chat_member_count(self, chat_id: int) -> int:
        """Get the number of members in a chat."""
        resp = await self._request("getChatMemberCount", chat_id=chat_id)
        return resp.result

    async def get_chat_administrators(self, chat_id: int) -> list[ChatMember]:
        """Get a list of chat administrators."""
        resp = await self._request("getChatAdministrators", chat_id=chat_id)
        return [ChatMember.model_validate(m) for m in resp.result]

    async def set_chat_title(self, chat_id: int, title: str) -> bool:
        """Set the chat title."""
        resp = await self._request("setChatTitle", chat_id=chat_id, title=title)
        return resp.ok

    async def set_chat_description(self, chat_id: int, description: str) -> bool:
        """Set the chat description."""
        resp = await self._request("setChatDescription", chat_id=chat_id, description=description)
        return resp.ok

    async def pin_chat_message(self, chat_id: int, message_id: int,
                                disable_notification: bool = False) -> bool:
        """Pin a message in a chat."""
        resp = await self._request("pinChatMessage", chat_id=chat_id, message_id=message_id,
                                   disable_notification=disable_notification)
        return resp.ok

    async def unpin_chat_message(self, chat_id: int, message_id: int) -> bool:
        """Unpin a message in a chat."""
        resp = await self._request("unpinChatMessage", chat_id=chat_id, message_id=message_id)
        return resp.ok

    async def unpin_all_chat_messages(self, chat_id: int) -> bool:
        """Unpin all messages in a chat."""
        resp = await self._request("unpinAllChatMessages", chat_id=chat_id)
        return resp.ok

    async def leave_chat(self, chat_id: int) -> bool:
        """Leave a chat."""
        resp = await self._request("leaveChat", chat_id=chat_id)
        return resp.ok

    async def set_chat_permissions(self, chat_id: int, permissions: dict) -> bool:
        """Set default permissions for all members in a chat."""
        resp = await self._request("setChatPermissions", chat_id=chat_id, permissions=permissions)
        return resp.ok

    async def export_chat_invite_link(self, chat_id: int) -> str:
        """Generate a new primary invite link for a chat."""
        resp = await self._request("exportChatInviteLink", chat_id=chat_id)
        # API returns the link as a plain string, not an object
        if isinstance(resp.result, str):
            return resp.result
        return resp.result.get("invite_link", "")

    async def approve_chat_join_request(self, chat_id: int, user_id: int) -> bool:
        """Approve a chat join request."""
        resp = await self._request("approveChatJoinRequest", chat_id=chat_id, user_id=user_id)
        return resp.ok

    async def decline_chat_join_request(self, chat_id: int, user_id: int) -> bool:
        """Decline a chat join request."""
        resp = await self._request("declineChatJoinRequest", chat_id=chat_id, user_id=user_id)
        return resp.ok

    # ── Webhook ───────────────────────────────────────────────────────

    async def set_webhook(self, url: str, secret_token: Optional[str] = None,
                          allowed_updates: Optional[list[str]] = None,
                          max_connections: Optional[int] = None,
                          drop_pending_updates: bool = False) -> bool:
        """Set the webhook URL for receiving updates."""
        resp = await self._request("setWebhook", url=url, secret_token=secret_token,
                                   allowed_updates=allowed_updates, max_connections=max_connections,
                                   drop_pending_updates=drop_pending_updates)
        return resp.ok

    async def delete_webhook(self, drop_pending_updates: bool = False) -> bool:
        """Remove the webhook (switch to polling mode)."""
        resp = await self._request("deleteWebhook", drop_pending_updates=drop_pending_updates)
        return resp.ok

    async def get_webhook_info(self) -> WebhookInfo:
        """Get current webhook configuration."""
        resp = await self._request("getWebhookInfo")
        return WebhookInfo.model_validate(resp.result)

    # ── Dispatch ──────────────────────────────────────────────────────

    def _bind_update(self, update: Update) -> None:
        """Bind bot reference to all models in an update for convenience methods."""
        if update.message:
            update.message._bind(self)
        if update.edited_message:
            update.edited_message._bind(self)
        if update.callback_query:
            update.callback_query._bind(self)
            if update.callback_query.message:
                update.callback_query.message._bind(self)

    async def _dispatch(self, update: Update) -> None:
        """Dispatch an update to matching handlers, wrapped by middlewares."""
        # Bind bot reference to update models for convenience methods
        self._bind_update(update)

        async def _inner_dispatch(update: Update, bot: DexFatherBot) -> Any:
            for handler in self._handlers:
                try:
                    if handler.check(update):
                        result = await handler.handle(update, bot)
                        return result  # First matching handler wins
                except Exception as e:
                    if self._error_handler is not None:
                        result = self._error_handler(update, e)
                        if asyncio.iscoroutine(result):
                            await result
                    else:
                        logger.error("handler_error", error=str(e), exc_info=True)
            return None

        # Build middleware chain (last registered = innermost)
        chain = _inner_dispatch
        for mw in reversed(self._middlewares):
            prev = chain
            chain = lambda u, b, _mw=mw, _prev=prev: _mw(_prev, u, b)

        # Pass restricted context to middleware (hides token), full bot to inner dispatch
        ctx = MiddlewareContext(self) if self._middlewares else self
        await chain(update, ctx)

    # ── Polling ───────────────────────────────────────────────────────

    async def _poll_loop(self) -> None:
        """Internal polling loop."""
        logger.info("polling_started")
        while self._running:
            try:
                updates = await self.get_updates(
                    offset=self._offset,
                    timeout=25,
                )
                for update in updates:
                    self._offset = update.update_id + 1
                    await self._dispatch(update)
            except Exception as e:
                if "timeout" in str(e).lower() or "timed out" in str(e).lower():
                    continue
                logger.error("polling_error", error=str(e))
                await asyncio.sleep(1)

    def run_polling(self, log_level: int = 20) -> None:
        """Start the bot in polling mode (blocking).

        Args:
            log_level: Logging level (default: 20 = INFO).

        Usage:
            bot.run_polling()
        """
        import logging as _logging
        setup_logging(level=_logging.getLevelName(log_level))
        self._running = True
        loop = asyncio.new_event_loop()

        def _shutdown(sig, frame):
            self._running = False
            logger.info("shutdown_signal", signal=sig)

        signal.signal(signal.SIGINT, _shutdown)
        signal.signal(signal.SIGTERM, _shutdown)

        try:
            loop.run_until_complete(self._poll_loop())
        finally:
            loop.run_until_complete(self.stop())
            loop.close()

    # ── WebSocket Mode ─────────────────────────────────────────────

    async def _ws_loop(self) -> None:
        """Internal WebSocket event loop -- receives updates as push, sends API calls as WS messages."""
        try:
            import websockets
        except ImportError:
            raise ImportError("WebSocket mode requires 'websockets'. Install with: pip install websockets")

        # Convert HTTP API base to WS URL
        ws_url = self.api_base.replace("http://", "ws://").replace("https://", "wss://")
        ws_url = ws_url.rsplit("/api/bot", 1)[0] + "/ws"

        logger.info("ws_connecting", url=ws_url)

        self._api._pending_responses = {}

        _ws_retries = 0

        while self._running:
            try:
                async with websockets.connect(ws_url, ping_interval=None, ping_timeout=None, close_timeout=5) as ws:
                    self._api._ws = ws

                    # Wait for auth_required signal, then send bot token
                    first_msg = json.loads(await asyncio.wait_for(ws.recv(), timeout=10))
                    if first_msg.get("type") == "auth_required":
                        logger.debug("ws_auth_required")
                    # Send auth regardless (server may or may not send auth_required first)
                    await ws.send(json.dumps({"type": "auth", "token": f"Bot {self.token}"}))

                    # Wait for auth response
                    auth_resp = json.loads(await asyncio.wait_for(ws.recv(), timeout=10))
                    if auth_resp.get("type") == "bot:authenticated":
                        logger.info("ws_authenticated", username=auth_resp.get("data", {}).get("username", "?"))
                    elif auth_resp.get("type") == "auth_failed":
                        logger.error("ws_auth_failed", error=auth_resp.get("error"))
                        return
                    else:
                        logger.warning("ws_unexpected_auth_response", type=auth_resp.get("type"))

                    # Reset backoff after successful connection
                    _ws_retries = 0

                    # Start app-level keepalive ping (server marks us alive on receiving ping)
                    async def _keepalive():
                        while self._running and self._api._ws is not None:
                            try:
                                await asyncio.sleep(20)
                                if self._api._ws:
                                    await self._api._ws.send(json.dumps({"type": "ping"}))
                            except Exception:
                                break
                    keepalive_task = asyncio.create_task(_keepalive())

                    try:
                        # Main receive loop
                        async for raw in ws:
                            msg = json.loads(raw)
                            msg_type = msg.get("type")

                            if msg_type == "bot:update":
                                # Incoming update -- dispatch to handlers
                                update = Update.model_validate(msg["data"])
                                self._offset = update.update_id + 1
                                asyncio.create_task(self._dispatch(update))

                            elif msg_type == "bot:api_response":
                                # Response to an API call we made
                                req_id = msg.get("id")
                                if req_id and req_id in self._api._pending_responses:
                                    self._api._pending_responses[req_id].set_result(msg)

                            elif msg_type in ("pong", "authenticated", "auth_required"):
                                pass  # Keepalive pong or initial messages
                    finally:
                        keepalive_task.cancel()

            except Exception as e:
                if not self._running:
                    break
                logger.warning("ws_connection_lost", error=str(e))
                self._api._ws = None
                backoff = min(2 ** _ws_retries, 30)  # 1, 2, 4, 8, 16, 30, 30...
                _ws_retries += 1
                logger.info("ws_reconnecting", delay=backoff, attempt=_ws_retries)
                await asyncio.sleep(backoff)

        self._api._ws = None

    def run_websocket(self, log_level: int = 20) -> None:
        """Start the bot in WebSocket mode (blocking).

        WebSocket mode provides instant update delivery -- no polling delay.
        Updates are pushed directly from the server. API calls are sent
        over the same connection. Falls back to HTTP if WS disconnects.

        Requires: pip install websockets

        Args:
            log_level: Logging level (default: 20 = INFO).

        Usage:
            bot.run_websocket()
        """
        import logging as _logging
        setup_logging(level=_logging.getLevelName(log_level))
        self._running = True
        loop = asyncio.new_event_loop()

        def _shutdown(sig, frame):
            self._running = False
            logger.info("shutdown_signal", signal=sig)

        signal.signal(signal.SIGINT, _shutdown)
        signal.signal(signal.SIGTERM, _shutdown)

        try:
            loop.run_until_complete(self._ws_loop())
        finally:
            loop.run_until_complete(self.stop())
            loop.close()

    async def start_polling(self) -> None:
        """Start polling (non-blocking, for use in async contexts)."""
        self._running = True
        asyncio.create_task(self._poll_loop())

    async def stop(self) -> None:
        """Stop the bot and close connections."""
        self._running = False
        await self._api.aclose()

    # ── Webhook Server ────────────────────────────────────────────────

    def run_webhook(
        self,
        host: str = "0.0.0.0",
        port: int = 8443,
        path: str = "/webhook",
        webhook_secret: Optional[str] = None,
        log_level: int = 20,
    ) -> None:
        """Start the bot in webhook mode with a local HTTP server (blocking).

        Requires the ``webhook`` extra: pip install dexfather[webhook]

        Args:
            host: Bind address.
            port: Bind port.
            path: URL path to listen on.
            webhook_secret: If set, verify X-Dexster-Bot-Api-Secret-Token header
                            using constant-time comparison before dispatching.
            log_level: Logging level.
        """
        try:
            import uvicorn
            from starlette.applications import Starlette
            from starlette.requests import Request
            from starlette.responses import JSONResponse
            from starlette.routing import Route
        except ImportError:
            raise ImportError(
                "Webhook mode requires extra dependencies. "
                "Install with: pip install dexfather[webhook]"
            )

        setup_logging()

        async def handle_webhook(request: Request) -> JSONResponse:
            body = await request.body()

            # Verify X-Dexster-Bot-Api-Secret-Token if webhook_secret is set (SDK-02)
            if webhook_secret:
                token_header = request.headers.get("X-Dexster-Bot-Api-Secret-Token", "")
                if not hmac_mod.compare_digest(token_header, webhook_secret):
                    logger.warning("webhook_signature_failed")
                    return JSONResponse({"ok": False, "description": "Forbidden"}, status_code=403)

            data = json.loads(body)
            update = Update.model_validate(data)
            await self._dispatch(update)
            return JSONResponse({"ok": True})

        app = Starlette(routes=[Route(path, handle_webhook, methods=["POST"])])
        logger.info("webhook_started", host=host, port=port, path=path)
        uvicorn.run(app, host=host, port=port)
