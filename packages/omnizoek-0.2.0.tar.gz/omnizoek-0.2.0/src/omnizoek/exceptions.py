"""
omnizoek.exceptions — Typed error hierarchy for the OmniZoek Python SDK.
"""

from __future__ import annotations


class OmniError(Exception):
    """Base class for all OmniZoek SDK errors."""

    def __init__(self, message: str, status_code: int | None = None) -> None:
        super().__init__(message)
        self.status_code = status_code


class OmniAuthError(OmniError):
    """Raised when the API key is missing or invalid (HTTP 401)."""


class OmniNotFoundError(OmniError):
    """Raised when the requested resource does not exist (HTTP 404)."""


class OmniRateLimitError(OmniError):
    """Raised when the rate limit is exceeded (HTTP 429)."""

    def __init__(self, message: str, retry_after: float | None = None) -> None:
        super().__init__(message, status_code=429)
        self.retry_after = retry_after


class OmniValidationError(OmniError):
    """Raised when the request parameters are invalid (HTTP 400/422)."""


class OmniServerError(OmniError):
    """Raised when the upstream API or OmniZoek server is unavailable (HTTP 5xx)."""
