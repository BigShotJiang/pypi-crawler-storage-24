"""omnizoek.hr — /v1/hr endpoints."""

from __future__ import annotations

from ._http import AsyncTransport, SyncTransport
from .models import HolidaySurchargeResponse, MinimumWageResponse


class HRClient:
    def __init__(self, transport: SyncTransport) -> None:
        self._t = transport

    def minimum_wage(self, age: int, date: str) -> MinimumWageResponse:
        """Return the Dutch statutory minimum wage (WML) for a given age and date."""
        data = self._t.get("/v1/hr/minimum-wage", params={"age": age, "date": date})
        return MinimumWageResponse.model_validate(data)

    def holiday_surcharge(self, date: str, industry: str) -> HolidaySurchargeResponse:
        """Return Dutch public holiday status and CAO wage surcharge for a date and industry."""
        data = self._t.get(
            "/v1/hr/holiday-surcharge",
            params={"date": date, "industry": industry},
        )
        return HolidaySurchargeResponse.model_validate(data)


class AsyncHRClient:
    def __init__(self, transport: AsyncTransport) -> None:
        self._t = transport

    async def minimum_wage(self, age: int, date: str) -> MinimumWageResponse:
        """Return the Dutch statutory minimum wage (WML) for a given age and date."""
        data = await self._t.get("/v1/hr/minimum-wage", params={"age": age, "date": date})
        return MinimumWageResponse.model_validate(data)

    async def holiday_surcharge(self, date: str, industry: str) -> HolidaySurchargeResponse:
        """Return Dutch public holiday status and CAO wage surcharge for a date and industry."""
        data = await self._t.get(
            "/v1/hr/holiday-surcharge",
            params={"date": date, "industry": industry},
        )
        return HolidaySurchargeResponse.model_validate(data)
