"""
omnizoek._http — Shared HTTP transport for sync and async clients.

Handles:
- X-API-Key injection
- Exponential back-off retry on 429 and 5xx
- Mapping HTTP status codes to typed exceptions
"""

from __future__ import annotations

import time
from typing import Any, TypeVar

import httpx

from .exceptions import (
    OmniAuthError,
    OmniError,
    OmniNotFoundError,
    OmniRateLimitError,
    OmniServerError,
    OmniValidationError,
)

_DEFAULT_BASE_URL = "https://api.omnizoek.nl"
_DEFAULT_TIMEOUT = 10.0
_DEFAULT_MAX_RETRIES = 3
_RETRY_STATUSES = {429, 500, 502, 503, 504}

T = TypeVar("T")


def _build_headers(api_key: str) -> dict[str, str]:
    return {
        "X-API-Key": api_key,
        "User-Agent": "omnizoek-python/0.1.0",
        "Accept": "application/json",
    }


def _raise_for_response(response: httpx.Response) -> None:
    if response.is_success:
        return

    try:
        detail = response.json().get("detail", response.text)
    except Exception:
        detail = response.text

    status = response.status_code

    if status == 401:
        raise OmniAuthError(f"Authentication failed: {detail}", status_code=status)
    if status == 404:
        raise OmniNotFoundError(f"Not found: {detail}", status_code=status)
    if status == 429:
        retry_after_raw = response.headers.get("Retry-After")
        retry_after = float(retry_after_raw) if retry_after_raw else None
        raise OmniRateLimitError(f"Rate limit exceeded: {detail}", retry_after=retry_after)
    if status in (400, 422):
        raise OmniValidationError(f"Invalid request: {detail}", status_code=status)
    if status >= 500:
        raise OmniServerError(f"Server error ({status}): {detail}", status_code=status)

    raise OmniError(f"Unexpected error ({status}): {detail}", status_code=status)


# ---------------------------------------------------------------------------
# Sync transport
# ---------------------------------------------------------------------------


class SyncTransport:
    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
        max_retries: int = _DEFAULT_MAX_RETRIES,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        self._client = httpx.Client(
            headers=_build_headers(api_key),
            timeout=timeout,
        )

    def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        url = f"{self._base_url}{path}"
        last_exc: Exception | None = None

        for attempt in range(self._max_retries + 1):
            try:
                response = self._client.get(url, params=params)
                if response.status_code in _RETRY_STATUSES and attempt < self._max_retries:
                    wait = 2 ** attempt
                    if response.status_code == 429:
                        retry_after = response.headers.get("Retry-After")
                        wait = float(retry_after) if retry_after else wait
                    time.sleep(wait)
                    last_exc = None
                    continue
                _raise_for_response(response)
                return response.json()
            except (OmniAuthError, OmniNotFoundError, OmniValidationError):
                raise  # never retry client errors
            except OmniError as exc:
                last_exc = exc
                if attempt < self._max_retries:
                    time.sleep(2 ** attempt)
            except httpx.RequestError as exc:
                last_exc = OmniError(f"Connection error: {exc}")
                if attempt < self._max_retries:
                    time.sleep(2 ** attempt)

        raise last_exc or OmniError("Request failed after retries")

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "SyncTransport":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


# ---------------------------------------------------------------------------
# Async transport
# ---------------------------------------------------------------------------


class AsyncTransport:
    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = _DEFAULT_TIMEOUT,
        max_retries: int = _DEFAULT_MAX_RETRIES,
    ) -> None:
        import asyncio
        self._asyncio = asyncio
        self._base_url = base_url.rstrip("/")
        self._max_retries = max_retries
        self._client = httpx.AsyncClient(
            headers=_build_headers(api_key),
            timeout=timeout,
        )

    async def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        url = f"{self._base_url}{path}"
        last_exc: Exception | None = None

        for attempt in range(self._max_retries + 1):
            try:
                response = await self._client.get(url, params=params)
                if response.status_code in _RETRY_STATUSES and attempt < self._max_retries:
                    wait = 2 ** attempt
                    if response.status_code == 429:
                        retry_after = response.headers.get("Retry-After")
                        wait = float(retry_after) if retry_after else wait
                    await self._asyncio.sleep(wait)
                    continue
                _raise_for_response(response)
                return response.json()
            except (OmniAuthError, OmniNotFoundError, OmniValidationError):
                raise
            except OmniError as exc:
                last_exc = exc
                if attempt < self._max_retries:
                    await self._asyncio.sleep(2 ** attempt)
            except httpx.RequestError as exc:
                last_exc = OmniError(f"Connection error: {exc}")
                if attempt < self._max_retries:
                    await self._asyncio.sleep(2 ** attempt)

        raise last_exc or OmniError("Request failed after retries")

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "AsyncTransport":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.aclose()
