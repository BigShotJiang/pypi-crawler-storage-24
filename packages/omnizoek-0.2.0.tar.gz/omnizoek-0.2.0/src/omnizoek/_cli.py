"""
omnizoek._cli — Command-line interface for quick terminal lookups.

Usage:
    omnizoek address 1012LG 1
    omnizoek iban NL91ABNA0417164300
    omnizoek vat NL 004495445B01
    omnizoek bsn 123456782
    omnizoek wage 21 2026-01-01
    omnizoek holiday 2026-04-27 horeca
    omnizoek label 1012LG 1
    omnizoek zone V-123-AB
    omnizoek transit ASD
    omnizoek grid NL
"""

from __future__ import annotations

import json
import sys


def main() -> None:
    import argparse

    from .client import OmniClient
    from .exceptions import OmniError

    parser = argparse.ArgumentParser(
        prog="omnizoek",
        description="OmniZoek CLI — Dutch government data from your terminal",
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("address", help="Enrich a Dutch address").add_argument(
        "args", nargs=2, metavar=("POSTCODE", "HOUSE_NUMBER")
    )
    sub.add_parser("iban", help="Resolve IBAN to BIC").add_argument("args", nargs=1, metavar="IBAN")
    sub.add_parser("vat", help="Verify EU VAT number").add_argument(
        "args", nargs=2, metavar=("COUNTRY_CODE", "VAT_NUMBER")
    )
    sub.add_parser("bsn", help="Validate a BSN number").add_argument("args", nargs=1, metavar="BSN")
    sub.add_parser("wage", help="Minimum wage lookup").add_argument(
        "args", nargs=2, metavar=("AGE", "DATE")
    )
    sub.add_parser("holiday", help="Holiday surcharge lookup").add_argument(
        "args", nargs=2, metavar=("DATE", "INDUSTRY")
    )
    sub.add_parser("label", help="Energy label lookup").add_argument(
        "args", nargs=2, metavar=("POSTCODE", "HOUSE_NUMBER")
    )
    sub.add_parser("zone", help="ZE emission zone check").add_argument(
        "args", nargs=1, metavar="KENTEKEN"
    )
    sub.add_parser("transit", help="NS transit disruptions").add_argument(
        "args", nargs=1, metavar="STATION_CODE"
    )
    sub.add_parser("grid", help="ENTSO-E grid trigger").add_argument(
        "args", nargs="?", metavar="COUNTRY_CODE", default="NL"
    )

    ns = parser.parse_args()

    try:
        client = OmniClient()
    except ValueError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)

    try:
        result = _dispatch(client, ns)
        print(json.dumps(result.model_dump(), indent=2, default=str))
    except OmniError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)
    finally:
        client.close()


def _dispatch(client: "OmniClient", ns: "argparse.Namespace") -> object:  # type: ignore[name-defined]
    cmd = ns.cmd
    args = ns.args if isinstance(ns.args, list) else [ns.args]

    if cmd == "address":
        return client.geo.enrich_address(postcode=args[0], house_number=args[1])
    if cmd == "iban":
        return client.finance.iban_to_bic(iban=args[0])
    if cmd == "vat":
        return client.finance.vat_verify(country_code=args[0], vat_number=args[1])
    if cmd == "bsn":
        return client.compliance.validate_finance(type="bsn", number=args[0])
    if cmd == "wage":
        return client.hr.minimum_wage(age=int(args[0]), date=args[1])
    if cmd == "holiday":
        return client.hr.holiday_surcharge(date=args[0], industry=args[1])
    if cmd == "label":
        return client.real_estate.energy_label(postcode=args[0], house_number=args[1])
    if cmd == "zone":
        return client.logistics.emission_zone(kenteken=args[0])
    if cmd == "transit":
        return client.logistics.transit_disruptions(station_code=args[0])
    if cmd == "grid":
        return client.energy.grid_trigger(country_code=args[0] if args[0] else "NL")
    raise ValueError(f"Unknown command: {cmd}")
