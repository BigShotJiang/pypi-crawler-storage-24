"""omnizoek.finance — /v1/finance endpoints."""

from __future__ import annotations

from ._http import AsyncTransport, SyncTransport
from .models import ExchangeRatesResponse, IbanToBicResponse, VatRatesResponse, VatVerifyResponse


class FinanceClient:
    def __init__(self, transport: SyncTransport) -> None:
        self._t = transport

    def iban_to_bic(self, iban: str) -> IbanToBicResponse:
        """Resolve a Dutch IBAN to its BIC/SWIFT code and bank name."""
        data = self._t.get("/v1/finance/iban-to-bic", params={"iban": iban})
        return IbanToBicResponse.model_validate(data)

    def vat_verify(self, country_code: str, vat_number: str) -> VatVerifyResponse:
        """Validate an EU VAT number via the EU Commission VIES API."""
        data = self._t.get(
            "/v1/finance/vat-verify",
            params={"country_code": country_code, "vat_number": vat_number},
        )
        return VatVerifyResponse.model_validate(data)

    def exchange_rates(self) -> ExchangeRatesResponse:
        """ECB daily euro foreign exchange reference rates."""
        data = self._t.get("/v1/finance/exchange-rates")
        return ExchangeRatesResponse.model_validate(data)

    def vat_rates(self, country: str = "NL") -> VatRatesResponse:
        """VAT rates for a given EU country (detailed category breakdown for NL)."""
        data = self._t.get("/v1/finance/vat-rates", params={"country": country})
        return VatRatesResponse.model_validate(data)


class AsyncFinanceClient:
    def __init__(self, transport: AsyncTransport) -> None:
        self._t = transport

    async def iban_to_bic(self, iban: str) -> IbanToBicResponse:
        """Resolve a Dutch IBAN to its BIC/SWIFT code and bank name."""
        data = await self._t.get("/v1/finance/iban-to-bic", params={"iban": iban})
        return IbanToBicResponse.model_validate(data)

    async def vat_verify(self, country_code: str, vat_number: str) -> VatVerifyResponse:
        """Validate an EU VAT number via the EU Commission VIES API."""
        data = await self._t.get(
            "/v1/finance/vat-verify",
            params={"country_code": country_code, "vat_number": vat_number},
        )
        return VatVerifyResponse.model_validate(data)

    async def exchange_rates(self) -> ExchangeRatesResponse:
        """ECB daily euro foreign exchange reference rates."""
        data = await self._t.get("/v1/finance/exchange-rates")
        return ExchangeRatesResponse.model_validate(data)

    async def vat_rates(self, country: str = "NL") -> VatRatesResponse:
        """VAT rates for a given EU country (detailed category breakdown for NL)."""
        data = await self._t.get("/v1/finance/vat-rates", params={"country": country})
        return VatRatesResponse.model_validate(data)
