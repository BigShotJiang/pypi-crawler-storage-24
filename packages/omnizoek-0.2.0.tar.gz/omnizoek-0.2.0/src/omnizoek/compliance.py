"""omnizoek.compliance — /v1/compliance endpoints."""

from __future__ import annotations

from typing import Literal

from ._http import AsyncTransport, SyncTransport
from .models import FinanceValidationResponse


class ComplianceClient:
    def __init__(self, transport: SyncTransport) -> None:
        self._t = transport

    def validate_finance(
        self, type: Literal["bsn", "iban"], number: str
    ) -> FinanceValidationResponse:
        """Validate a BSN or IBAN using Dutch mathematical algorithms (elfproef / MOD-97)."""
        data = self._t.get(
            "/v1/compliance/validate-finance",
            params={"type": type, "number": number},
        )
        return FinanceValidationResponse.model_validate(data)


class AsyncComplianceClient:
    def __init__(self, transport: AsyncTransport) -> None:
        self._t = transport

    async def validate_finance(
        self, type: Literal["bsn", "iban"], number: str
    ) -> FinanceValidationResponse:
        """Validate a BSN or IBAN using Dutch mathematical algorithms (elfproef / MOD-97)."""
        data = await self._t.get(
            "/v1/compliance/validate-finance",
            params={"type": type, "number": number},
        )
        return FinanceValidationResponse.model_validate(data)
