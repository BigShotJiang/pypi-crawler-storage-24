"""omnizoek.energy — /v1/energy endpoints."""

from __future__ import annotations

from ._http import AsyncTransport, SyncTransport
from .models import GridTriggerResponse


class EnergyClient:
    def __init__(self, transport: SyncTransport) -> None:
        self._t = transport

    def grid_trigger(self, country_code: str = "NL") -> GridTriggerResponse:
        """Return current ENTSO-E day-ahead price and negative-price trigger signal."""
        data = self._t.get("/v1/energy/grid-trigger", params={"country_code": country_code})
        return GridTriggerResponse.model_validate(data)


class AsyncEnergyClient:
    def __init__(self, transport: AsyncTransport) -> None:
        self._t = transport

    async def grid_trigger(self, country_code: str = "NL") -> GridTriggerResponse:
        """Return current ENTSO-E day-ahead price and negative-price trigger signal."""
        data = await self._t.get(
            "/v1/energy/grid-trigger", params={"country_code": country_code}
        )
        return GridTriggerResponse.model_validate(data)
