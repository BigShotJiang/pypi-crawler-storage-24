"""
omnizoek — Official Python SDK for the OmniZoek API.

Quick start::

    from omnizoek import OmniClient

    client = OmniClient(api_key="omni_live_...")
    address = client.geo.enrich_address(postcode="1012LG", house_number="1")
    print(address.street, address.city)
"""

from .client import AsyncOmniClient, OmniClient
from .exceptions import (
    OmniAuthError,
    OmniError,
    OmniNotFoundError,
    OmniRateLimitError,
    OmniServerError,
    OmniValidationError,
)
from .models import (
    AddressEnrichResponse,
    EmissionZoneResponse,
    EnergyLabelResponse,
    ExchangeRatesResponse,
    FinanceValidationResponse,
    GeocodeResponse,
    GeocodeResultItem,
    GridTriggerResponse,
    HolidaySurchargeResponse,
    IbanToBicResponse,
    LeiAddress,
    LeiLookupResponse,
    LeiSearchResponse,
    MinimumWageResponse,
    RecallItem,
    ReverseGeocodeResponse,
    TransitDisruptionItem,
    TransitDisruptionsResponse,
    VatCategoryItem,
    VatRatesResponse,
    VatVerifyResponse,
    VehicleHistoryResponse,
)

__version__ = "0.2.0"
__all__ = [
    "OmniClient",
    "AsyncOmniClient",
    # Exceptions
    "OmniError",
    "OmniAuthError",
    "OmniNotFoundError",
    "OmniRateLimitError",
    "OmniServerError",
    "OmniValidationError",
    # Models
    "AddressEnrichResponse",
    "EmissionZoneResponse",
    "EnergyLabelResponse",
    "ExchangeRatesResponse",
    "FinanceValidationResponse",
    "GeocodeResponse",
    "GeocodeResultItem",
    "GridTriggerResponse",
    "HolidaySurchargeResponse",
    "IbanToBicResponse",
    "LeiAddress",
    "LeiLookupResponse",
    "LeiSearchResponse",
    "MinimumWageResponse",
    "RecallItem",
    "ReverseGeocodeResponse",
    "TransitDisruptionItem",
    "TransitDisruptionsResponse",
    "VatCategoryItem",
    "VatRatesResponse",
    "VatVerifyResponse",
    "VehicleHistoryResponse",
]
