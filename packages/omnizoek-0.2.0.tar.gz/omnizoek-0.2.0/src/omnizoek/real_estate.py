"""omnizoek.real_estate — /v1/real-estate endpoints."""

from __future__ import annotations

from ._http import AsyncTransport, SyncTransport
from .models import EnergyLabelResponse


class RealEstateClient:
    def __init__(self, transport: SyncTransport) -> None:
        self._t = transport

    def energy_label(self, postcode: str, house_number: str) -> EnergyLabelResponse:
        """Return the official EP-Online energy label for a Dutch address."""
        data = self._t.get(
            "/v1/real-estate/energy-label",
            params={"postcode": postcode, "house_number": house_number},
        )
        return EnergyLabelResponse.model_validate(data)


class AsyncRealEstateClient:
    def __init__(self, transport: AsyncTransport) -> None:
        self._t = transport

    async def energy_label(self, postcode: str, house_number: str) -> EnergyLabelResponse:
        """Return the official EP-Online energy label for a Dutch address."""
        data = await self._t.get(
            "/v1/real-estate/energy-label",
            params={"postcode": postcode, "house_number": house_number},
        )
        return EnergyLabelResponse.model_validate(data)
