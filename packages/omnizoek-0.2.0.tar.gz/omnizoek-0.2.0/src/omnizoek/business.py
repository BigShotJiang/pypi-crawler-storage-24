"""omnizoek.business — /v1/business endpoints."""

from __future__ import annotations

from ._http import AsyncTransport, SyncTransport
from .models import LeiLookupResponse, LeiSearchResponse


class BusinessClient:
    def __init__(self, transport: SyncTransport) -> None:
        self._t = transport

    def lei_lookup(
        self,
        lei: str | None = None,
        *,
        name: str | None = None,
        country: str | None = None,
        rows: int = 10,
    ) -> LeiLookupResponse | LeiSearchResponse:
        """Look up a legal entity by LEI code, or search by name.

        Pass ``lei`` for a direct lookup (returns :class:`LeiLookupResponse`).
        Pass ``name`` for a name search (returns :class:`LeiSearchResponse`).
        """
        params: dict = {}
        if lei:
            params["lei"] = lei
        if name:
            params["name"] = name
        if country:
            params["country"] = country
        if rows != 10:
            params["rows"] = rows
        data = self._t.get("/v1/business/lei-lookup", params=params)
        if lei and not name:
            return LeiLookupResponse.model_validate(data)
        return LeiSearchResponse.model_validate(data)


class AsyncBusinessClient:
    def __init__(self, transport: AsyncTransport) -> None:
        self._t = transport

    async def lei_lookup(
        self,
        lei: str | None = None,
        *,
        name: str | None = None,
        country: str | None = None,
        rows: int = 10,
    ) -> LeiLookupResponse | LeiSearchResponse:
        """Look up a legal entity by LEI code, or search by name.

        Pass ``lei`` for a direct lookup (returns :class:`LeiLookupResponse`).
        Pass ``name`` for a name search (returns :class:`LeiSearchResponse`).
        """
        params: dict = {}
        if lei:
            params["lei"] = lei
        if name:
            params["name"] = name
        if country:
            params["country"] = country
        if rows != 10:
            params["rows"] = rows
        data = await self._t.get("/v1/business/lei-lookup", params=params)
        if lei and not name:
            return LeiLookupResponse.model_validate(data)
        return LeiSearchResponse.model_validate(data)
