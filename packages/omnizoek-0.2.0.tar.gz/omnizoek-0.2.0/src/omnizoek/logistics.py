"""omnizoek.logistics — /v1/logistics endpoints."""

from __future__ import annotations

from ._http import AsyncTransport, SyncTransport
from .models import EmissionZoneResponse, TransitDisruptionsResponse, VehicleHistoryResponse


class LogisticsClient:
    def __init__(self, transport: SyncTransport) -> None:
        self._t = transport

    def emission_zone(self, kenteken: str) -> EmissionZoneResponse:
        """Check whether a Dutch-registered vehicle may enter ZE zones."""
        data = self._t.get("/v1/logistics/emission-zone", params={"kenteken": kenteken})
        return EmissionZoneResponse.model_validate(data)

    def transit_disruptions(self, station_code: str) -> TransitDisruptionsResponse:
        """Return active NS rail disruptions and maintenance for a station."""
        data = self._t.get(
            "/v1/logistics/transit-disruptions",
            params={"station_code": station_code},
        )
        return TransitDisruptionsResponse.model_validate(data)

    def vehicle_history(self, kenteken: str) -> VehicleHistoryResponse:
        """Full vehicle registration record from RDW Open Data (4 datasets + recalls)."""
        data = self._t.get("/v1/logistics/vehicle-history", params={"kenteken": kenteken})
        return VehicleHistoryResponse.model_validate(data)


class AsyncLogisticsClient:
    def __init__(self, transport: AsyncTransport) -> None:
        self._t = transport

    async def emission_zone(self, kenteken: str) -> EmissionZoneResponse:
        """Check whether a Dutch-registered vehicle may enter ZE zones."""
        data = await self._t.get("/v1/logistics/emission-zone", params={"kenteken": kenteken})
        return EmissionZoneResponse.model_validate(data)

    async def transit_disruptions(self, station_code: str) -> TransitDisruptionsResponse:
        """Return active NS rail disruptions and maintenance for a station."""
        data = await self._t.get(
            "/v1/logistics/transit-disruptions",
            params={"station_code": station_code},
        )
        return TransitDisruptionsResponse.model_validate(data)

    async def vehicle_history(self, kenteken: str) -> VehicleHistoryResponse:
        """Full vehicle registration record from RDW Open Data (4 datasets + recalls)."""
        data = await self._t.get("/v1/logistics/vehicle-history", params={"kenteken": kenteken})
        return VehicleHistoryResponse.model_validate(data)
