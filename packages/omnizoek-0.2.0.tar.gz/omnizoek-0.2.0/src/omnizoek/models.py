"""
omnizoek.models — Pydantic response models mirroring the OmniZoek API contracts.

Field names are English, snake_case, and match the API JSON response keys exactly.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Compliance
# ---------------------------------------------------------------------------


class FinanceValidationResponse(BaseModel):
    """Result of a BSN or IBAN mathematical validation."""

    valid: bool
    type: Literal["bsn", "iban"]
    number: str
    algorithm: str
    detail: str


# ---------------------------------------------------------------------------
# Finance
# ---------------------------------------------------------------------------


class IbanToBicResponse(BaseModel):
    """BIC/SWIFT code and bank name resolved from a Dutch IBAN."""

    iban: str
    bic: str
    bank_name: str
    country_code: str


class VatVerifyResponse(BaseModel):
    """EU VIES VAT number validation result."""

    valid: bool
    status: Literal["valid", "invalid", "unavailable"]
    country_code: str
    vat_number: str
    company_name: str | None = None
    address: str | None = None
    checked_at: str


# ---------------------------------------------------------------------------
# Geo
# ---------------------------------------------------------------------------


class AddressEnrichResponse(BaseModel):
    """BAG-enriched address record for a Dutch postcode + house number."""

    street: str
    house_number: str
    house_letter: str | None = None
    house_addition: str | None = None
    postcode: str
    city: str
    municipality: str | None = None
    province: str | None = None
    lat: float | None = None
    lon: float | None = None
    bag_id: str
    surface_m2: int | None = None
    building_year: int | None = None
    usage_function: str | None = None
    status: str | None = None
    energy_label: str | None = None
    energy_label_registered: str | None = None
    energy_label_valid_until: str | None = None
    energy_label_calculation_type: str | None = None


# ---------------------------------------------------------------------------
# HR
# ---------------------------------------------------------------------------


class MinimumWageResponse(BaseModel):
    """Dutch statutory minimum wage (WML) for a given age and date."""

    age: int
    date: str
    hourly_eur: float
    daily_eur: float
    monthly_eur: float
    law_reference: str
    note: str | None = None


class HolidaySurchargeResponse(BaseModel):
    """Dutch public holiday status and applicable CAO wage surcharge."""

    date: str
    is_holiday: bool
    holiday_name: str | None = None
    industry: str
    surcharge_multiplier: float
    surcharge_basis: str
    disclaimer: str


# ---------------------------------------------------------------------------
# Real estate
# ---------------------------------------------------------------------------


class EnergyLabelResponse(BaseModel):
    """EP-Online energy label record for a Dutch address."""

    bag_id: str
    postcode: str
    house_number: str
    energy_label: str
    label_class: str
    calculation_type: str | None = None
    registered_at: str | None = None
    valid_until: str | None = None


# ---------------------------------------------------------------------------
# Logistics
# ---------------------------------------------------------------------------


class EmissionZoneResponse(BaseModel):
    """RDW-backed ZE zone compliance verdict for a Dutch license plate."""

    kenteken: str
    ze_compliant: bool
    fuel_types: list[str]
    euro_standard: str | None = None
    emission_category: str | None = None
    vehicle_category: str | None = None
    reason: str
    zones_checked: list[str]


class TransitDisruptionItem(BaseModel):
    """A single NS disruption or maintenance notice."""

    type: str
    title: str
    cause: str | None = None
    start: str | None = None
    end: str | None = None
    impact: str | None = None


class TransitDisruptionsResponse(BaseModel):
    """Active NS rail disruptions and maintenance for a station."""

    station_code: str
    disruptions: list[TransitDisruptionItem]
    retrieved_at: str


# ---------------------------------------------------------------------------
# Energy
# ---------------------------------------------------------------------------


class GridTriggerResponse(BaseModel):
    """ENTSO-E day-ahead electricity price and negative price trigger signal."""

    country_code: str
    current_price_eur_mwh: float
    negative_price: bool
    trigger: bool
    period_start: str | None = None
    period_end: str | None = None
    retrieved_at: str


# ---------------------------------------------------------------------------
# Sprint Immediate — /v1/finance/exchange-rates
# ---------------------------------------------------------------------------


class ExchangeRatesResponse(BaseModel):
    """ECB daily euro foreign exchange reference rates."""

    base: str
    date: str
    rates: dict[str, float]
    source: str


# ---------------------------------------------------------------------------
# Sprint Immediate — /v1/finance/vat-rates
# ---------------------------------------------------------------------------


class VatCategoryItem(BaseModel):
    """A single VAT category with its applicable rate."""

    name: str
    description: str
    rate: float
    examples: list[str]


class VatRatesResponse(BaseModel):
    """VAT rates for a given EU country."""

    country: str
    currency: str
    standard_rate: float
    reduced_rates: list[float]
    zero_rate: bool
    categories: list[VatCategoryItem]
    effective_date: str
    source: str
    note: str | None = None


# ---------------------------------------------------------------------------
# Sprint Immediate — /v1/geo/geocode + /v1/geo/reverse-geocode
# ---------------------------------------------------------------------------


class GeocodeResultItem(BaseModel):
    """A single geocoding result from PDOK Locatieserver."""

    display_name: str
    type: str
    lat: float | None = None
    lon: float | None = None
    postcode: str | None = None
    city: str | None = None
    municipality: str | None = None
    province: str | None = None
    street: str | None = None
    house_number: str | None = None
    bag_id: str | None = None
    score: float | None = None


class GeocodeResponse(BaseModel):
    """Forward geocoding results from PDOK Locatieserver."""

    query: str
    results: list[GeocodeResultItem]


class ReverseGeocodeResponse(BaseModel):
    """Reverse geocoding result from PDOK Locatieserver."""

    lat: float
    lon: float
    display_name: str
    type: str
    postcode: str | None = None
    city: str | None = None
    municipality: str | None = None
    province: str | None = None
    street: str | None = None
    house_number: str | None = None
    bag_id: str | None = None


# ---------------------------------------------------------------------------
# Sprint Immediate — /v1/business/lei-lookup
# ---------------------------------------------------------------------------


class LeiAddress(BaseModel):
    """Registered or headquarters address from a GLEIF LEI record."""

    lines: list[str]
    city: str | None = None
    region: str | None = None
    country: str | None = None
    postal_code: str | None = None


class LeiLookupResponse(BaseModel):
    """A GLEIF LEI record — Legal Entity Identifier data."""

    lei: str
    legal_name: str
    other_names: list[str]
    legal_form: str | None = None
    jurisdiction: str | None = None
    status: str
    registered_address: LeiAddress
    headquarters_address: LeiAddress
    registration_date: str | None = None
    last_updated: str | None = None
    next_renewal: str | None = None
    bic_codes: list[str]
    parent_lei: str | None = None


class LeiSearchResponse(BaseModel):
    """Results of a GLEIF LEI name search."""

    query: str
    country_filter: str | None = None
    results: list[LeiLookupResponse]


# ---------------------------------------------------------------------------
# Sprint Immediate — /v1/logistics/vehicle-history
# ---------------------------------------------------------------------------


class RecallItem(BaseModel):
    """A single RDW recall entry linked to a vehicle."""

    reference_code: str
    code_status: str
    status: str


class VehicleHistoryResponse(BaseModel):
    """Full vehicle registration record from RDW Open Data."""

    kenteken: str
    make: str | None = None
    commercial_name: str | None = None
    vehicle_type: str | None = None
    body_style: str | None = None
    eu_vehicle_category: str | None = None
    first_admission_date: str | None = None
    registration_date: str | None = None
    primary_color: str | None = None
    secondary_color: str | None = None
    seats: int | None = None
    doors: int | None = None
    cylinders: int | None = None
    engine_displacement_cc: int | None = None
    curb_weight_kg: int | None = None
    max_weight_kg: int | None = None
    catalog_price_eur: int | None = None
    bruto_bpm_eur: int | None = None
    wam_insured: bool | None = None
    fuel_types: list[str]
    euro_standard: str | None = None
    emission_class: str | None = None
    max_power_kw: float | None = None
    co2_combined_g_km: float | None = None
    fuel_consumption_combined_l100km: float | None = None
    noise_level_db: float | None = None
    apk_expiry_date: str | None = None
    apk_days_remaining: int | None = None
    open_recalls: list[RecallItem]
    open_recall_count: int
