"""
omnizoek.client — OmniClient and AsyncOmniClient.
"""

from __future__ import annotations

import os
from typing import Any

from ._http import AsyncTransport, SyncTransport
from .business import AsyncBusinessClient, BusinessClient
from .compliance import AsyncComplianceClient, ComplianceClient
from .energy import AsyncEnergyClient, EnergyClient
from .finance import AsyncFinanceClient, FinanceClient
from .geo import AsyncGeoClient, GeoClient
from .hr import AsyncHRClient, HRClient
from .logistics import AsyncLogisticsClient, LogisticsClient
from .real_estate import AsyncRealEstateClient, RealEstateClient

_DEFAULT_BASE_URL = "https://api.omnizoek.nl"


class OmniClient:
    """Synchronous OmniZoek API client.

    Usage::

        from omnizoek import OmniClient

        client = OmniClient(api_key="omni_live_...")
        address = client.geo.enrich_address(postcode="1012LG", house_number="1")
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = 10.0,
        max_retries: int = 3,
    ) -> None:
        resolved_key = api_key or os.environ.get("OMNIZOEK_API_KEY")
        if not resolved_key:
            raise ValueError(
                "No API key provided. Pass api_key= or set the OMNIZOEK_API_KEY environment variable."
            )

        transport = SyncTransport(
            api_key=resolved_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )

        self.geo = GeoClient(transport)
        self.finance = FinanceClient(transport)
        self.compliance = ComplianceClient(transport)
        self.hr = HRClient(transport)
        self.real_estate = RealEstateClient(transport)
        self.logistics = LogisticsClient(transport)
        self.energy = EnergyClient(transport)
        self.business = BusinessClient(transport)
        self._transport = transport

    def close(self) -> None:
        self._transport.close()

    def __enter__(self) -> "OmniClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


class AsyncOmniClient:
    """Asynchronous OmniZoek API client.

    Usage::

        from omnizoek import AsyncOmniClient

        async with AsyncOmniClient(api_key="omni_live_...") as client:
            address = await client.geo.enrich_address(postcode="1012LG", house_number="1")
    """

    def __init__(
        self,
        api_key: str | None = None,
        *,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = 10.0,
        max_retries: int = 3,
    ) -> None:
        resolved_key = api_key or os.environ.get("OMNIZOEK_API_KEY")
        if not resolved_key:
            raise ValueError(
                "No API key provided. Pass api_key= or set the OMNIZOEK_API_KEY environment variable."
            )

        transport = AsyncTransport(
            api_key=resolved_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )

        self.geo = AsyncGeoClient(transport)
        self.finance = AsyncFinanceClient(transport)
        self.compliance = AsyncComplianceClient(transport)
        self.hr = AsyncHRClient(transport)
        self.real_estate = AsyncRealEstateClient(transport)
        self.logistics = AsyncLogisticsClient(transport)
        self.energy = AsyncEnergyClient(transport)
        self.business = AsyncBusinessClient(transport)
        self._transport = transport

    async def aclose(self) -> None:
        await self._transport.aclose()

    async def __aenter__(self) -> "AsyncOmniClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.aclose()
