"""omnizoek.geo — /v1/geo endpoints."""

from __future__ import annotations

from ._http import AsyncTransport, SyncTransport
from .models import AddressEnrichResponse, GeocodeResponse, ReverseGeocodeResponse


class GeoClient:
    def __init__(self, transport: SyncTransport) -> None:
        self._t = transport

    def enrich_address(
        self,
        postcode: str,
        house_number: str,
        *,
        energy: bool = True,
    ) -> AddressEnrichResponse:
        """Enrich a Dutch address using postcode + house number (BAG + PDOK)."""
        data = self._t.get(
            "/v1/geo/address-enrich",
            params={"postcode": postcode, "house_number": house_number, "energy": energy},
        )
        return AddressEnrichResponse.model_validate(data)

    def geocode(self, q: str, *, rows: int = 5) -> GeocodeResponse:
        """Forward geocode a free-text query to coordinates (PDOK Locatieserver)."""
        data = self._t.get("/v1/geo/geocode", params={"q": q, "rows": rows})
        return GeocodeResponse.model_validate(data)

    def reverse_geocode(self, lat: float, lon: float) -> ReverseGeocodeResponse:
        """Reverse geocode WGS84 coordinates to a Dutch address (PDOK Locatieserver)."""
        data = self._t.get("/v1/geo/reverse-geocode", params={"lat": lat, "lon": lon})
        return ReverseGeocodeResponse.model_validate(data)


class AsyncGeoClient:
    def __init__(self, transport: AsyncTransport) -> None:
        self._t = transport

    async def enrich_address(
        self,
        postcode: str,
        house_number: str,
        *,
        energy: bool = True,
    ) -> AddressEnrichResponse:
        """Enrich a Dutch address using postcode + house number (BAG + PDOK)."""
        data = await self._t.get(
            "/v1/geo/address-enrich",
            params={"postcode": postcode, "house_number": house_number, "energy": energy},
        )
        return AddressEnrichResponse.model_validate(data)

    async def geocode(self, q: str, *, rows: int = 5) -> GeocodeResponse:
        """Forward geocode a free-text query to coordinates (PDOK Locatieserver)."""
        data = await self._t.get("/v1/geo/geocode", params={"q": q, "rows": rows})
        return GeocodeResponse.model_validate(data)

    async def reverse_geocode(self, lat: float, lon: float) -> ReverseGeocodeResponse:
        """Reverse geocode WGS84 coordinates to a Dutch address (PDOK Locatieserver)."""
        data = await self._t.get("/v1/geo/reverse-geocode", params={"lat": lat, "lon": lon})
        return ReverseGeocodeResponse.model_validate(data)
