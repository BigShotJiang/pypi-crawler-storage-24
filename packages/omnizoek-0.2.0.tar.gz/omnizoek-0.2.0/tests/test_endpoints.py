"""
tests/test_endpoints.py — Happy-path tests for every resource client.
"""

import pytest

from omnizoek import OmniClient


# ---------------------------------------------------------------------------
# Fixtures — one mock response per endpoint
# ---------------------------------------------------------------------------

ADDRESS_RESPONSE = {
    "street": "Damrak",
    "house_number": "1",
    "house_letter": None,
    "house_addition": None,
    "postcode": "1012LG",
    "city": "Amsterdam",
    "municipality": "Amsterdam",
    "province": "Noord-Holland",
    "lat": 52.3756,
    "lon": 4.8951,
    "bag_id": "0363010000000001",
    "surface_m2": 120,
    "building_year": 1920,
    "usage_function": "woonfunctie",
    "status": "Verblijfsobject in gebruik",
    "energy_label": "C",
    "energy_label_registered": "2021-03-15",
    "energy_label_valid_until": "2031-03-15",
    "energy_label_calculation_type": "Nader Voorschrift",
}

IBAN_RESPONSE = {
    "iban": "NL91ABNA0417164300",
    "bic": "ABNANL2A",
    "bank_name": "ABN AMRO Bank N.V.",
    "country_code": "NL",
}

VAT_RESPONSE = {
    "valid": True,
    "status": "valid",
    "country_code": "NL",
    "vat_number": "NL004495445B01",
    "company_name": "Example B.V.",
    "address": "Damrak 1, Amsterdam",
    "checked_at": "2026-03-09T10:00:00Z",
}

BSN_RESPONSE = {
    "valid": True,
    "type": "bsn",
    "number": "123456782",
    "algorithm": "elfproef",
    "detail": "BSN 123456782 passes the 11-proof algorithm.",
}

WAGE_RESPONSE = {
    "age": 21,
    "date": "2026-01-01",
    "hourly_eur": 14.06,
    "daily_eur": 112.48,
    "monthly_eur": 2069.40,
    "law_reference": "WML 2026-H1",
    "note": None,
}

HOLIDAY_RESPONSE = {
    "date": "2026-04-27",
    "is_holiday": True,
    "holiday_name": "Koningsdag",
    "industry": "horeca",
    "surcharge_multiplier": 1.5,
    "surcharge_basis": "Public holiday",
    "disclaimer": "Reference values only.",
}

ENERGY_LABEL_RESPONSE = {
    "bag_id": "0363010000000001",
    "postcode": "1012LG",
    "house_number": "1",
    "energy_label": "C",
    "label_class": "C",
    "calculation_type": "Nader Voorschrift",
    "registered_at": "2021-03-15",
    "valid_until": "2031-03-15",
}

EMISSION_RESPONSE = {
    "kenteken": "V-123-AB",
    "ze_compliant": False,
    "fuel_types": ["Diesel"],
    "euro_standard": "Euro 5",
    "emission_category": "D",
    "vehicle_category": "N1",
    "reason": "Euro 5 diesel — not permitted.",
    "zones_checked": ["Amsterdam", "Rotterdam", "Utrecht", "Den Haag", "Eindhoven"],
}

TRANSIT_RESPONSE = {
    "station_code": "ASD",
    "disruptions": [
        {
            "type": "maintenance",
            "title": "Werkzaamheden Amsterdam CS",
            "cause": "Railvervanging",
            "start": "2026-03-07T22:00:00+01:00",
            "end": "2026-03-08T06:00:00+01:00",
            "impact": "Rijdt niet: IC Amsterdam – Utrecht.",
        }
    ],
    "retrieved_at": "2026-03-06T14:00:00Z",
}

GRID_RESPONSE = {
    "country_code": "NL",
    "current_price_eur_mwh": -12.50,
    "negative_price": True,
    "trigger": True,
    "period_start": "2026-03-06T13:00:00Z",
    "period_end": "2026-03-06T14:00:00Z",
    "retrieved_at": "2026-03-06T13:15:00Z",
}


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_geo_enrich_address(api_key, httpx_mock):
    httpx_mock.add_response(json=ADDRESS_RESPONSE)
    with OmniClient(api_key=api_key) as client:
        r = client.geo.enrich_address(postcode="1012LG", house_number="1")
    assert r.street == "Damrak"
    assert r.city == "Amsterdam"
    assert r.energy_label == "C"
    assert r.lat == 52.3756


def test_finance_iban_to_bic(api_key, httpx_mock):
    httpx_mock.add_response(json=IBAN_RESPONSE)
    with OmniClient(api_key=api_key) as client:
        r = client.finance.iban_to_bic(iban="NL91ABNA0417164300")
    assert r.bic == "ABNANL2A"
    assert r.bank_name == "ABN AMRO Bank N.V."


def test_finance_vat_verify(api_key, httpx_mock):
    httpx_mock.add_response(json=VAT_RESPONSE)
    with OmniClient(api_key=api_key) as client:
        r = client.finance.vat_verify(country_code="NL", vat_number="004495445B01")
    assert r.valid is True
    assert r.company_name == "Example B.V."


def test_compliance_validate_bsn(api_key, httpx_mock):
    httpx_mock.add_response(json=BSN_RESPONSE)
    with OmniClient(api_key=api_key) as client:
        r = client.compliance.validate_finance(type="bsn", number="123456782")
    assert r.valid is True
    assert r.algorithm == "elfproef"


def test_hr_minimum_wage(api_key, httpx_mock):
    httpx_mock.add_response(json=WAGE_RESPONSE)
    with OmniClient(api_key=api_key) as client:
        r = client.hr.minimum_wage(age=21, date="2026-01-01")
    assert r.hourly_eur == 14.06
    assert r.law_reference == "WML 2026-H1"


def test_hr_holiday_surcharge(api_key, httpx_mock):
    httpx_mock.add_response(json=HOLIDAY_RESPONSE)
    with OmniClient(api_key=api_key) as client:
        r = client.hr.holiday_surcharge(date="2026-04-27", industry="horeca")
    assert r.is_holiday is True
    assert r.surcharge_multiplier == 1.5
    assert r.holiday_name == "Koningsdag"


def test_real_estate_energy_label(api_key, httpx_mock):
    httpx_mock.add_response(json=ENERGY_LABEL_RESPONSE)
    with OmniClient(api_key=api_key) as client:
        r = client.real_estate.energy_label(postcode="1012LG", house_number="1")
    assert r.energy_label == "C"
    assert r.bag_id == "0363010000000001"


def test_logistics_emission_zone(api_key, httpx_mock):
    httpx_mock.add_response(json=EMISSION_RESPONSE)
    with OmniClient(api_key=api_key) as client:
        r = client.logistics.emission_zone(kenteken="V-123-AB")
    assert r.ze_compliant is False
    assert "Amsterdam" in r.zones_checked


def test_logistics_transit_disruptions(api_key, httpx_mock):
    httpx_mock.add_response(json=TRANSIT_RESPONSE)
    with OmniClient(api_key=api_key) as client:
        r = client.logistics.transit_disruptions(station_code="ASD")
    assert r.station_code == "ASD"
    assert len(r.disruptions) == 1
    assert r.disruptions[0].type == "maintenance"


def test_energy_grid_trigger(api_key, httpx_mock):
    httpx_mock.add_response(json=GRID_RESPONSE)
    with OmniClient(api_key=api_key) as client:
        r = client.energy.grid_trigger(country_code="NL")
    assert r.negative_price is True
    assert r.trigger is True
    assert r.current_price_eur_mwh == -12.50
