"""
tests/test_client.py — OmniClient initialisation and error handling.
"""

import pytest

from omnizoek import OmniClient
from omnizoek.exceptions import (
    OmniAuthError,
    OmniNotFoundError,
    OmniRateLimitError,
    OmniServerError,
    OmniValidationError,
)


def test_raises_without_api_key(monkeypatch):
    monkeypatch.delenv("OMNIZOEK_API_KEY", raising=False)
    with pytest.raises(ValueError, match="No API key"):
        OmniClient()


def test_uses_env_var(monkeypatch):
    monkeypatch.setenv("OMNIZOEK_API_KEY", "omni_test_env")
    client = OmniClient()
    client.close()


def test_context_manager(api_key):
    with OmniClient(api_key=api_key) as client:
        assert client.geo is not None


def test_auth_error(api_key, httpx_mock):
    httpx_mock.add_response(
        status_code=401,
        json={"error": "unauthorized", "detail": "Invalid API key"},
    )
    with OmniClient(api_key=api_key) as client:
        with pytest.raises(OmniAuthError):
            client.geo.enrich_address(postcode="1012LG", house_number="1")


def test_not_found_error(api_key, httpx_mock):
    httpx_mock.add_response(
        status_code=404,
        json={"error": "not_found", "detail": "Address not found"},
    )
    with OmniClient(api_key=api_key) as client:
        with pytest.raises(OmniNotFoundError):
            client.geo.enrich_address(postcode="9999XX", house_number="1")


def test_rate_limit_error(api_key, httpx_mock):
    httpx_mock.add_response(
        status_code=429,
        headers={"Retry-After": "0"},
        json={"error": "rate_limit", "detail": "Too many requests"},
    )
    with OmniClient(api_key=api_key, max_retries=0) as client:
        with pytest.raises(OmniRateLimitError) as exc_info:
            client.geo.enrich_address(postcode="1012LG", house_number="1")
    assert exc_info.value.retry_after == 0.0


def test_server_error(api_key, httpx_mock):
    httpx_mock.add_response(status_code=503, json={"error": "unavailable", "detail": "BAG unavailable"})
    with OmniClient(api_key=api_key, max_retries=0) as client:
        with pytest.raises(OmniServerError):
            client.geo.enrich_address(postcode="1012LG", house_number="1")


def test_validation_error(api_key, httpx_mock):
    httpx_mock.add_response(
        status_code=422,
        json={"error": "validation_error", "detail": "Invalid postcode"},
    )
    with OmniClient(api_key=api_key) as client:
        with pytest.raises(OmniValidationError):
            client.geo.enrich_address(postcode="bad", house_number="1")
