"""
tests/conftest.py — Shared fixtures for the omnizoek SDK tests.
"""

import pytest
from pytest_httpx import HTTPXMock


@pytest.fixture
def api_key() -> str:
    return "omni_test_sdk_pytest"
