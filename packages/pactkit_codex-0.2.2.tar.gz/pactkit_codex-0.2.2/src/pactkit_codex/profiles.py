"""FormatProfile — single source of truth for all environment-specific paths and behaviors.

STORY-slim-005: Replaces scattered if-else format branching and hardcoded paths.

Adding a new tool integration:
    1. Add a FormatProfile entry to FORMAT_PROFILES.
    2. All downstream code (deployer, config, CLI) auto-picks it up via VALID_FORMATS.
    3. No other files need modification.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal


@dataclass(frozen=True)
class FormatProfile:
    """Immutable environment-specific configuration profile.

    All environment-dependent paths and capabilities live here.
    No caller should ever hardcode "~/.codex" — use this profile.

    Template Variable Reference (used in prompt templates via _render_prompt()):
    ┌─────────────────────┬───────────────────────────┬──────────────────────────────────────┐
    │ Variable            │ FormatProfile Field        │ Example (codex)                      │
    ├─────────────────────┼───────────────────────────┼──────────────────────────────────────┤
    │ {SKILLS_ROOT}       │ skills_dir                 │ ~/.codex/skills                      │
    │ {RULES_ROOT}        │ rules_dir                  │ ~/.codex/rules                       │
    │ {GLOBAL_CONFIG_DIR} │ global_config_dir          │ ~/.codex                             │
    │ {PROJECT_CONFIG_DIR}│ project_config_dir         │ .codex                               │
    │ {INSTRUCTIONS_FILE} │ project_instructions_file  │ AGENTS.md                            │
    │ {PACTKIT_YAML}      │ pactkit_yaml_path          │ .codex/pactkit.yaml                  │
    │ {DISPLAY_NAME}      │ display_name               │ Codex CLI                            │
    ├─────────────────────┼───────────────────────────┼──────────────────────────────────────┤
    │ {VISUALIZE_CMD}     │ (derived from skills_dir)  │ python3 ~/.codex/skills/pactkit-...  │
    │ {BOARD_CMD}         │ (derived from skills_dir)  │ python3 ~/.codex/skills/pactkit-...  │
    │ {SCAFFOLD_CMD}      │ (derived from skills_dir)  │ python3 ~/.codex/skills/pactkit-...  │
    │ {GLOBAL_INSTRUCTIONS│ (derived: dir/file)        │ ~/.codex/AGENTS.md                   │
    └─────────────────────┴───────────────────────────┴──────────────────────────────────────┘

    Adding a new format:
        1. Add a FormatProfile entry to FORMAT_PROFILES below.
        2. All template variables auto-derive from the profile fields.
        3. No prompt files (skills.py, commands.py, workflows.py) need modification.

    Usage rules:
        - Use {VAR_NAME} in prompt source files (str.format_map syntax).
        - Call _render_prompt(template, profile) in deployer to inject values.
        - JSON literal braces in templates must be escaped as {{ and }}.
        - When adding a new variable: (a) add field to FormatProfile,
          (b) add to _render_prompt() vars dict, (c) update this table.
    """

    # Identity
    name: str
    """Canonical format name: 'codex'."""
    display_name: str
    """Human-readable tool name: 'Codex CLI'."""

    # Directory Structure
    global_config_dir: str
    """Global config root. e.g. '~/.codex'."""
    project_config_dir: str
    """Project config dir name. e.g. '.codex'."""
    skills_dir: str
    """Where skills are deployed globally. e.g. '~/.codex/skills'."""
    agents_dir: str | None
    """Where agent definitions are deployed. None if format is single-agent."""
    commands_dir: str | None
    """Where command playbooks are deployed. None if format has no custom commands."""
    rules_dir: str | None
    """Where rule files are deployed. None if rules are inlined."""
    prompts_dir: str | None
    """Where custom slash command prompts are deployed. None if not supported."""

    # File Names
    project_instructions_file: str
    """Project-level instructions file name. 'AGENTS.md'."""
    global_instructions_file: str
    """Global instructions file name. 'AGENTS.md'."""
    pactkit_yaml_path: str
    """Relative path to pactkit.yaml from project root. e.g. '.codex/pactkit.yaml'."""

    # Format & Serialization
    agent_format: Literal["md", "toml"]
    """Agent definition format: 'toml' (Codex)."""
    rules_import_style: Literal["@import", "instructions", "inline"]
    """How rules are loaded: 'inline' (Codex)."""
    excluded_agent_fields: frozenset
    """Agent YAML fields to exclude for this format. Replaces CLAUDE_ONLY_FIELDS."""

    # Capabilities
    has_custom_commands: bool
    """Whether the tool supports custom slash commands."""
    supports_model_routing: bool
    """Whether per-agent model routing is supported."""
    supports_mcp: bool
    """Whether MCP server configuration is supported."""

    # Playbook Variables
    skills_path_var: str
    """Skills path used in deployed playbook templates. e.g. '~/.codex/skills'."""


# ---------------------------------------------------------------------------
# Registry: add a new FormatProfile here to support a new tool
# ---------------------------------------------------------------------------

FORMAT_PROFILES: dict[str, FormatProfile] = {
    "codex": FormatProfile(
        name="codex",
        display_name="Codex CLI",
        global_config_dir="~/.codex",
        project_config_dir=".codex",
        skills_dir="~/.codex/skills",
        agents_dir=None,  # Codex is single-agent — no agent files
        commands_dir="~/.codex/prompts",  # Codex slash commands via prompts/
        rules_dir=None,  # Codex uses inline rules in AGENTS.md
        prompts_dir="~/.codex/prompts",  # Codex custom slash commands
        project_instructions_file="AGENTS.md",
        global_instructions_file="AGENTS.md",
        pactkit_yaml_path=".codex/pactkit.yaml",
        agent_format="md",  # AGENTS.md is plain markdown
        rules_import_style="inline",
        excluded_agent_fields=frozenset({"permissionMode", "memory", "skills", "hooks"}),
        has_custom_commands=True,  # Codex supports slash commands via prompts/
        supports_model_routing=False,  # Single model per session
        supports_mcp=True,
        skills_path_var="~/.codex/skills",
    ),
}

# All valid --format values (Codex-only project)
VALID_FORMATS: frozenset[str] = frozenset(FORMAT_PROFILES.keys())

# Candidate paths for pactkit.yaml discovery
PACTKIT_YAML_CANDIDATES: list[str] = [
    FORMAT_PROFILES["codex"].pactkit_yaml_path,
]


def get_profile(format: str) -> FormatProfile:
    """Return the FormatProfile for a given format name.

    Raises:
        ValueError: If format is not a registered environment profile
                    (use is_environment_format() to check first if needed).
    """
    if format not in FORMAT_PROFILES:
        valid = ", ".join(sorted(FORMAT_PROFILES.keys()))
        raise ValueError(f"Unknown format: {format!r}. Valid environment profiles: {valid}")
    return FORMAT_PROFILES[format]


def is_environment_format(format: str) -> bool:
    """Return True if format is an environment profile (not a deployment mode)."""
    return format in FORMAT_PROFILES
