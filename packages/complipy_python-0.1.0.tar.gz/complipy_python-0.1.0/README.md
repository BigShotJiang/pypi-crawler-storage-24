# complipy

A python library that makes python *(slightly)* harder (compared to what python is).
It includes:
- Colors for text
..thats all i wanted to say thats worth mentioning actually

### How to use

Install by using `pip install complipy` (dude you should know this already)

If you want to print text, first import iolib (`from complipy import iolib`), then import system (`from complipy import system`)

You print by writing `iolib.printc("")`, for example, this is a "hello world" in complipy:
```
from complipy import iolib
from complipy import system

iolib.printc("Hello world!" + iolib.endl)

system.returnc(0)
```
`returnc` is important, as the code will not run without it:
```Could not find system.returnc!
Exception ignored in atexit callback <function verexit at 0x7f7b9ac5f5e0>:
Traceback (most recent call last):
  File "/home/nkf/Documents/complicatedpy/complipy/system/__init__.py", line 18, in verexit
    sys.exit(1)
SystemExit: 1
```
This is what the code looks being run in KDE's terminal app *(Arch linux)*
![idk bro just see it or smth](https://file.garden/ZskyutRXvkqRnlD-/Screenshot_20260323_211554.png)
If you want colored text, use colorprint (through iolib), for example if you want green as a text color:
```
from complipy import iolib
from complipy import system

iolib.colorprint("This is green text!", iolib.GREEN)

system.returnc(0)
```
In the terminal, it looks like this:
![again im not gonna put alt text](https://file.garden/ZskyutRXvkqRnlD-/Screenshot_20260323_212818.png)
If you want a green background, you use `iolib.colorprint("green background bro", iolib.BG_GREEN)`
And if you want to make the script wait a little.. just a little before continuing, use timelib, by now you already should know how to fucking import.. so ill skip that, just use this:
`timelib.pause(1)`, or `timelib.sleep(1)`

oh and yeah you clear the screen using `iolib.clear()`

---
complipy is in a very early stage and ill be making updates frequently