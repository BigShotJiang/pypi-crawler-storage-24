import sys
import os
import atexit

returncl = False

def __ZQKUILSystemReturncClearTerminalScreenForAnyReturncError():
    if os.name == "nt":
        os.system("cls")
    else:
        os.system("clear")

def verexit():
    if not returncl:

        __ZQKUILSystemReturncClearTerminalScreenForAnyReturncError()
        sys.stderr.write("Could not find system.returnc!\n")
        sys.exit(1)

atexit.register(verexit)

def returnc(code):
    global returncl
    if not isinstance(code, int):
        raise TypeError(f"system.returnc requires <int>, got <{type(code).__name__}>")
    
    returncl = True
    sys.exit(code)