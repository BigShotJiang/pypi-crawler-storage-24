import time

def pause(number):
    if not isinstance(number, (int, float)):
        raise TypeError(f"timelib.pause expects <int> or <float>, got <{type(number).__name__}>")
    time.sleep(number)

def sleep(number):
    if not isinstance(number, (int, float)):
        raise TypeError(f"timelib.sleep expects <int> or <float>, got <{type(number).__name__}>")
    time.sleep(number)