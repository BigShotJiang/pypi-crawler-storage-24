import sys
import os

RED = "\033[31m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
RESET = "\033[0m"
BG_RED = "\033[41m"
BG_GREEN = "\033[42m"
BG_YELLOW = "\033[43m"
BG_BLUE = "\033[44m"
endl = "\n"

def colorprint(data, color):
    if not isinstance(data, str) or not isinstance(color, str):
        raise TypeError("iolib.colorprint requires <str> for both data and color.")
    
    sys.stdout.write(color + data + RESET + endl)

def printc(data):
    if not isinstance(data, str):
        raise TypeError(f"io.printc expects <str>, got <{type(data).__name__}>")
    sys.stdout.write(data)


def clear():
    if os.name == "nt":
        os.system("cls")
    else:
        os.system("clear")