import click
import subprocess

VM_NAME = "de-bootcamp-vm"
ZONE = "us-central1-a"
CHALLENGE_PATH = "/home/jyothi.hosamani/code/jyothihosamani/data-engineering-challenges"


@click.command()
def start():
    """Start your vm"""
    subprocess.run(
        ["gcloud", "compute", "instances", "start", VM_NAME, "--zone", ZONE],
        check=True,
    )


@click.command()
def stop():
    """Stop your vm"""
    subprocess.run(
        ["gcloud", "compute", "instances", "stop", VM_NAME, "--zone", ZONE],
        check=True,
    )


@click.command()
def connect():
    """Connect to your vm in vscode inside your ~/code/jyothihosamani folder"""
    subprocess.run(
        [
            "code",
            "--folder-uri",
            f"vscode-remote://ssh-remote+{VM_NAME}{CHALLENGE_PATH}",
        ],
        check=True,
    )
