# jyothihosamani-de-toolkit

A Python CLI toolkit to start, stop, and connect to a GCP VM.

## Commands

- `deng start` — start the VM
- `deng stop` — stop the VM
- `deng connect` — connect to the VM in VS Code
