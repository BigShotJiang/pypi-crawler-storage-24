"""SEC EDGAR public API client.

Thin wrapper around data.sec.gov JSON APIs. No auth required — just a User-Agent string.
Rate limited to 10 req/sec per SEC policy.
"""

from __future__ import annotations

import asyncio
import re
from typing import Any

import httpx

SEC_DATA = "https://data.sec.gov"
SEC_WWW = "https://www.sec.gov"
TICKERS_URL = f"{SEC_WWW}/files/company_tickers.json"

# Key us-gaap concepts for the snapshot tool
KEY_CONCEPTS = [
    "Revenues",
    "RevenueFromContractWithCustomerExcludingAssessedTax",
    "NetIncomeLoss",
    "OperatingIncomeLoss",
    "GrossProfit",
    "CostOfGoodsAndServicesSold",
    "Assets",
    "AssetsCurrent",
    "Liabilities",
    "LiabilitiesCurrent",
    "StockholdersEquity",
    "CashAndCashEquivalentsAtCarryingValue",
    "EarningsPerShareBasic",
    "EarningsPerShareDiluted",
    "CommonStockSharesOutstanding",
    "LongTermDebt",
    "LongTermDebtNoncurrent",
    "NetCashProvidedByOperatingActivities",
    "PaymentsOfDividends",
    "ResearchAndDevelopmentExpense",
]

# Section aliases for filing_section tool
SECTION_ALIASES: dict[str, str] = {
    "business": "1",
    "risk factors": "1A",
    "risk": "1A",
    "cybersecurity": "1C",
    "properties": "2",
    "legal": "3",
    "legal proceedings": "3",
    "mda": "7",
    "md&a": "7",
    "management discussion": "7",
    "management's discussion": "7",
    "market risk": "7A",
    "quantitative": "7A",
    "financial statements": "8",
    "controls": "9A",
    "controls and procedures": "9A",
}

# Regex for Item headers in SEC filings
ITEM_HEADER = re.compile(
    r"^[\s]*(?:ITEM|Item)\s+(\d+[A-Ca-c]?)[\.\s:]+[-\u2014\u2013]?\s*(.+?)$",
    re.MULTILINE,
)


class EdgarClient:
    """Async client for SEC EDGAR public APIs."""

    def __init__(self, user_agent: str):
        self.user_agent = user_agent
        self._headers = {
            "User-Agent": user_agent,
            "Accept-Encoding": "gzip, deflate",
        }
        self._semaphore = asyncio.Semaphore(10)
        self._ticker_map: dict[str, int] | None = None
        self._http: httpx.AsyncClient | None = None

    def _client(self) -> httpx.AsyncClient:
        if self._http is None or self._http.is_closed:
            self._http = httpx.AsyncClient(
                headers=self._headers,
                timeout=30.0,
                follow_redirects=True,
            )
        return self._http

    async def _get(self, url: str) -> httpx.Response:
        async with self._semaphore:
            r = await self._client().get(url)
            r.raise_for_status()
            return r

    async def _json(self, url: str) -> dict:
        return (await self._get(url)).json()

    async def _text(self, url: str) -> str:
        return (await self._get(url)).text

    # ── Identity ──────────────────────────────────────────────────────

    async def _load_tickers(self) -> dict[str, int]:
        if self._ticker_map is None:
            raw = await self._json(TICKERS_URL)
            self._ticker_map = {
                v["ticker"].upper(): int(v["cik_str"]) for v in raw.values()
            }
        return self._ticker_map

    async def resolve_cik(self, identifier: str) -> int:
        """Ticker or CIK string -> integer CIK."""
        clean = identifier.strip().upper()
        try:
            return int(clean)
        except ValueError:
            tmap = await self._load_tickers()
            if clean in tmap:
                return tmap[clean]
            raise ValueError(f"Unknown ticker: {identifier}")

    @staticmethod
    def pad_cik(cik: int) -> str:
        return str(cik).zfill(10)

    # ── SEC Data APIs ─────────────────────────────────────────────────

    async def submissions(self, cik: int) -> dict:
        """Filing history and company metadata."""
        return await self._json(
            f"{SEC_DATA}/submissions/CIK{self.pad_cik(cik)}.json"
        )

    async def company_facts(self, cik: int) -> dict:
        """All XBRL financial facts for a company."""
        return await self._json(
            f"{SEC_DATA}/api/xbrl/companyfacts/CIK{self.pad_cik(cik)}.json"
        )

    async def company_concept(
        self, cik: int, concept: str, taxonomy: str = "us-gaap"
    ) -> dict:
        """Time series for one XBRL concept."""
        return await self._json(
            f"{SEC_DATA}/api/xbrl/companyconcept/"
            f"CIK{self.pad_cik(cik)}/{taxonomy}/{concept}.json"
        )

    async def frames(
        self,
        concept: str,
        period: str,
        currency: str = "USD",
        taxonomy: str = "us-gaap",
    ) -> dict:
        """One concept across all companies for a period."""
        return await self._json(
            f"{SEC_DATA}/api/xbrl/frames/{taxonomy}/{concept}/{currency}/{period}.json"
        )

    async def filing_document(
        self, cik: int, accession: str, filename: str
    ) -> str:
        """Fetch a specific document from a filing archive."""
        acc_clean = accession.replace("-", "")
        url = f"{SEC_WWW}/Archives/edgar/data/{cik}/{acc_clean}/{filename}"
        return await self._text(url)

    # ── Helpers ────────────────────────────────────────────────────────

    async def find_primary_doc(self, cik: int, accession: str) -> str | None:
        """Look up the primary document filename from submissions."""
        subs = await self.submissions(cik)
        recent = subs.get("filings", {}).get("recent", {})
        accs = recent.get("accessionNumber", [])
        docs = recent.get("primaryDocument", [])
        for i, acc in enumerate(accs):
            if acc == accession and i < len(docs):
                return docs[i]
        return None

    def extract_snapshot(self, facts: dict) -> dict[str, Any]:
        """Extract key financial metrics from companyfacts."""
        us_gaap = facts.get("facts", {}).get("us-gaap", {})
        metrics: dict[str, Any] = {}
        for concept in KEY_CONCEPTS:
            if concept not in us_gaap:
                continue
            units = us_gaap[concept].get("units", {})
            for unit_name, datapoints in units.items():
                if not datapoints:
                    continue
                latest = max(datapoints, key=lambda d: d.get("end", ""))
                metrics[concept] = {
                    "value": latest["val"],
                    "end": latest.get("end"),
                    "fiscal_year": latest.get("fy"),
                    "period": latest.get("fp"),
                    "form": latest.get("form"),
                    "filed": latest.get("filed"),
                    "unit": unit_name,
                    "label": us_gaap[concept].get("label", concept),
                }
                break  # first unit type only
        return metrics

    def extract_concept_index(self, facts: dict) -> dict[str, Any]:
        """Build a compact index of all available concepts."""
        result: dict[str, Any] = {}
        for taxonomy, concepts in facts.get("facts", {}).items():
            names = sorted(concepts.keys())
            result[taxonomy] = {
                "count": len(names),
                "concepts": names,
            }
        return result

    def parse_filing_sections(self, html: str) -> dict[str, dict[str, str]]:
        """Parse 10-K/10-Q HTML into sections by Item number."""
        import warnings
        from bs4 import BeautifulSoup, XMLParsedAsHTMLWarning

        warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)
        soup = BeautifulSoup(html, "lxml")
        for tag in soup(["script", "style"]):
            tag.decompose()

        text = soup.get_text(separator="\n")
        text = text.replace("\xa0", " ")
        text = re.sub(r"\n{3,}", "\n\n", text)

        matches = list(ITEM_HEADER.finditer(text))
        if not matches:
            return {}

        sections: dict[str, dict[str, str]] = {}
        for i, m in enumerate(matches):
            item_num = m.group(1).upper()
            title = m.group(2).strip()
            start = m.end()
            end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
            content = text[start:end].strip()

            # Skip ToC entries — real sections have substantial content
            if len(content) < 500:
                continue

            # Keep longest version (handles ToC reference + actual content)
            if item_num not in sections or len(content) > len(
                sections[item_num]["content"]
            ):
                sections[item_num] = {"title": title, "content": content}

        return sections

    @staticmethod
    def resolve_section_key(section: str) -> str:
        """Resolve section name/alias to Item number."""
        clean = section.strip().lower()
        if clean in SECTION_ALIASES:
            return SECTION_ALIASES[clean]
        return section.strip().upper()
