"""SEC Engine - LLM-optimized SEC EDGAR MCP server."""
