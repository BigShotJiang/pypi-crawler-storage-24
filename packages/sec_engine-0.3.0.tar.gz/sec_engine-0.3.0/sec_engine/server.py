"""SEC Engine — LLM-optimized SEC EDGAR MCP server.

6 tools, each a thin wrapper around SEC's public JSON APIs:
  resolve          → company identity
  filings          → filing navigation
  snapshot         → latest key metrics + concept discovery
  concept_history  → time series for one metric
  cross_company    → peer comparison across all filers
  filing_section   → narrative text extraction from filings
"""

from __future__ import annotations

import os

import httpx
from mcp.server.fastmcp import FastMCP

from .edgar import EdgarClient

USER_AGENT = os.environ.get("SEC_EDGAR_USER_AGENT", "SEC-Engine/0.1 (sec-engine-mcp)")

mcp = FastMCP(
    "sec-engine",
    instructions=(
        "SEC EDGAR data for financial analysis. "
        "Start with resolve() to get a CIK, then use snapshot() for key metrics, "
        "concept_history() for time series, or filings() + filing_section() for narrative content. "
        "All data comes directly from SEC.gov with no authentication required."
    ),
)

client = EdgarClient(USER_AGENT)


@mcp.tool()
async def resolve(identifier: str) -> dict:
    """Resolve a ticker symbol or CIK to full company identity.

    Returns CIK, name, SIC code, fiscal year end, tickers, exchanges.
    Call this first to confirm you have the right entity.

    Args:
        identifier: Ticker symbol (e.g. 'AAPL') or CIK number (e.g. '320193')
    """
    try:
        cik = await client.resolve_cik(identifier)
    except ValueError as e:
        return {"error": str(e)}

    try:
        subs = await client.submissions(cik)
    except httpx.HTTPStatusError as e:
        return {"error": f"SEC API returned {e.response.status_code} for CIK {cik}"}

    return {
        "cik": cik,
        "name": subs.get("name"),
        "entity_type": subs.get("entityType"),
        "sic": subs.get("sic"),
        "sic_description": subs.get("sicDescription"),
        "tickers": subs.get("tickers", []),
        "exchanges": subs.get("exchanges", []),
        "fiscal_year_end": subs.get("fiscalYearEnd"),
        "category": subs.get("category"),
    }


@mcp.tool()
async def filings(
    identifier: str,
    form_type: str | None = None,
    start_date: str | None = None,
    end_date: str | None = None,
    limit: int = 20,
) -> dict:
    """List SEC filings for a company.

    Returns accession numbers needed by filing_section() and other metadata.

    Args:
        identifier: Ticker symbol or CIK number
        form_type: Filter by form type — '10-K', '10-Q', '8-K', '4', 'DEF 14A', etc.
        start_date: Only filings on or after this date (YYYY-MM-DD)
        end_date: Only filings on or before this date (YYYY-MM-DD)
        limit: Max results (default 20)
    """
    try:
        cik = await client.resolve_cik(identifier)
        subs = await client.submissions(cik)
    except (ValueError, httpx.HTTPStatusError) as e:
        return {"error": str(e)}

    recent = subs.get("filings", {}).get("recent", {})
    accs = recent.get("accessionNumber", [])
    forms = recent.get("form", [])
    dates = recent.get("filingDate", [])
    reports = recent.get("reportDate", [])
    docs = recent.get("primaryDocument", [])

    results = []
    for i in range(len(accs)):
        if form_type and forms[i] != form_type:
            continue
        if start_date and dates[i] < start_date:
            continue
        if end_date and dates[i] > end_date:
            continue
        results.append({
            "accession_number": accs[i],
            "form_type": forms[i],
            "filing_date": dates[i],
            "report_date": reports[i] if i < len(reports) else None,
            "primary_document": docs[i] if i < len(docs) else None,
        })
        if len(results) >= limit:
            break

    return {
        "cik": cik,
        "name": subs.get("name"),
        "count": len(results),
        "filings": results,
    }


@mcp.tool()
async def snapshot(identifier: str) -> dict:
    """Get key financial metrics and discover all available XBRL concepts.

    Returns latest values for ~20 common metrics (revenue, net income, assets, etc.)
    plus a complete index of every XBRL concept the company reports.
    Use concept names with concept_history() for detailed time series.

    Args:
        identifier: Ticker symbol or CIK number
    """
    try:
        cik = await client.resolve_cik(identifier)
        facts = await client.company_facts(cik)
    except (ValueError, httpx.HTTPStatusError) as e:
        return {"error": str(e)}

    return {
        "cik": cik,
        "name": facts.get("entityName"),
        "key_metrics": client.extract_snapshot(facts),
        "available_concepts": client.extract_concept_index(facts),
    }


@mcp.tool()
async def concept_history(
    identifier: str,
    concept: str,
    taxonomy: str = "us-gaap",
    form_type: str | None = None,
    start_year: int | None = None,
    end_year: int | None = None,
) -> dict:
    """Get the full time series for one XBRL concept across all filings.

    This is the core temporal analysis tool. Returns every reported value
    for a concept across time, directly from SEC XBRL data.

    Use snapshot() to discover available concept names.

    Common concepts: Revenues, NetIncomeLoss, Assets, Liabilities,
    StockholdersEquity, EarningsPerShareDiluted, CashAndCashEquivalentsAtCarryingValue,
    OperatingIncomeLoss, CommonStockSharesOutstanding, LongTermDebt.

    Args:
        identifier: Ticker symbol or CIK number
        concept: XBRL concept name (e.g. 'Revenues', 'Assets', 'NetIncomeLoss')
        taxonomy: XBRL taxonomy (default 'us-gaap'; also 'dei', 'ifrs-full', 'srt')
        form_type: Filter to specific form — '10-K' for annual, '10-Q' for quarterly
        start_year: Filter to fiscal years >= this
        end_year: Filter to fiscal years <= this
    """
    try:
        cik = await client.resolve_cik(identifier)
    except ValueError as e:
        return {"error": str(e)}

    try:
        data = await client.company_concept(cik, concept, taxonomy)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            return {
                "error": f"Concept '{concept}' not found for this company in {taxonomy}",
                "hint": "Use snapshot() to discover available concept names",
            }
        return {"error": f"SEC API returned {e.response.status_code}"}

    result_units: dict[str, list] = {}
    for unit_name, datapoints in data.get("units", {}).items():
        filtered = datapoints
        if form_type:
            filtered = [d for d in filtered if d.get("form") == form_type]
        if start_year:
            filtered = [d for d in filtered if (d.get("fy") or 0) >= start_year]
        if end_year:
            filtered = [d for d in filtered if (d.get("fy") or 9999) <= end_year]
        filtered.sort(key=lambda d: d.get("end", ""))
        result_units[unit_name] = filtered

    return {
        "cik": cik,
        "entity": data.get("entityName"),
        "concept": concept,
        "taxonomy": taxonomy,
        "label": data.get("label"),
        "description": data.get("description"),
        "units": result_units,
    }


@mcp.tool()
async def cross_company(
    concept: str,
    year: int,
    quarter: int | None = None,
    instantaneous: bool = False,
    currency: str = "USD",
    taxonomy: str = "us-gaap",
    limit: int = 100,
) -> dict:
    """Compare one financial metric across ALL reporting companies for a period.

    Uses the SEC XBRL frames API. Powerful for peer analysis and sector screening.

    Period logic:
    - Annual: year=2024 → CY2024 (income/cash flow items)
    - Quarterly: year=2024, quarter=3 → CY2024Q3
    - Instantaneous: add instantaneous=True for balance sheet items (Assets, Liabilities)

    Args:
        concept: XBRL concept name (e.g. 'Assets', 'Revenues', 'NetIncomeLoss')
        year: Calendar year
        quarter: Quarter 1-4 (omit for annual)
        instantaneous: True for point-in-time (balance sheet), False for period (income/CF)
        currency: Currency code (default 'USD')
        taxonomy: XBRL taxonomy (default 'us-gaap')
        limit: Max companies returned, sorted by absolute value descending (default 100)
    """
    period = f"CY{year}"
    if quarter:
        period += f"Q{quarter}"
    if instantaneous:
        period += "I"

    try:
        data = await client.frames(concept, period, currency, taxonomy)
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            return {
                "error": f"No data for {concept}/{period}. Check concept name and period format.",
                "hint": "Balance sheet items need instantaneous=True. Income items don't.",
            }
        return {"error": f"SEC API returned {e.response.status_code}"}

    entries = data.get("data", [])
    entries.sort(key=lambda e: abs(e.get("val", 0)), reverse=True)
    truncated = entries[:limit]

    return {
        "concept": concept,
        "period": period,
        "label": data.get("label"),
        "description": data.get("description"),
        "total_companies": data.get("pts", len(entries)),
        "showing": len(truncated),
        "data": [
            {
                "cik": e.get("cik"),
                "entity": e.get("entityName"),
                "value": e.get("val"),
                "end": e.get("end"),
            }
            for e in truncated
        ],
    }


@mcp.tool()
async def filing_section(
    identifier: str,
    accession_number: str,
    section: str | None = None,
) -> dict:
    """Extract a narrative section from a 10-K or 10-Q filing as clean text.

    If section is omitted, returns a list of sections found in the filing.
    Use filings() first to get the accession_number.

    Sections can be specified by Item number or common name:
      '7' or 'mda'          → Management's Discussion and Analysis
      '1A' or 'risk factors' → Risk Factors
      '1' or 'business'      → Business Description
      '1C' or 'cybersecurity' → Cybersecurity
      '8' or 'financial statements' → Financial Statements
      '9A' or 'controls'     → Controls and Procedures

    Args:
        identifier: Ticker symbol or CIK number
        accession_number: Filing accession number (from filings() tool)
        section: Item number or name (omit to list available sections)
    """
    try:
        cik = await client.resolve_cik(identifier)
    except ValueError as e:
        return {"error": str(e)}

    # Find and fetch the primary HTML document
    try:
        primary_doc = await client.find_primary_doc(cik, accession_number)
    except httpx.HTTPStatusError as e:
        return {"error": f"Failed to look up filing: {e.response.status_code}"}

    if not primary_doc:
        return {"error": f"Primary document not found for {accession_number}"}

    try:
        html = await client.filing_document(cik, accession_number, primary_doc)
    except httpx.HTTPStatusError as e:
        return {"error": f"Failed to fetch document: {e.response.status_code}"}

    # Parse sections from HTML
    sections = client.parse_filing_sections(html)

    if not sections:
        return {
            "error": "Could not parse sections. Filing may use non-standard formatting.",
            "accession_number": accession_number,
            "document": primary_doc,
            "document_size": len(html),
        }

    if section is None:
        return {
            "cik": cik,
            "accession_number": accession_number,
            "sections": {
                k: {"title": v["title"], "characters": len(v["content"])}
                for k, v in sorted(sections.items())
            },
        }

    key = client.resolve_section_key(section)
    if key not in sections:
        return {
            "error": f"Section '{section}' (Item {key}) not found in this filing",
            "available": list(sections.keys()),
        }

    content = sections[key]["content"]
    truncated = False
    if len(content) > 50_000:
        content = content[:50_000]
        truncated = True

    return {
        "cik": cik,
        "accession_number": accession_number,
        "item": key,
        "title": sections[key]["title"],
        "content": content,
        "characters": len(sections[key]["content"]),
        "truncated": truncated,
    }


def main():
    transport = os.environ.get("SEC_ENGINE_TRANSPORT", "stdio")
    host = os.environ.get("SEC_ENGINE_HOST", "127.0.0.1")
    port = int(os.environ.get("SEC_ENGINE_PORT", "8000"))
    path = os.environ.get("SEC_ENGINE_PATH", "/mcp")

    if transport == "streamable-http":
        from mcp.server.transport_security import TransportSecuritySettings

        allowed = os.environ.get("SEC_ENGINE_ALLOWED_HOSTS", "")
        if allowed == "*":
            security = TransportSecuritySettings(
                enable_dns_rebinding_protection=False,
            )
        elif allowed:
            security = TransportSecuritySettings(
                allowed_hosts=[h.strip() for h in allowed.split(",")],
            )
        else:
            security = None

        mcp.settings.host = host
        mcp.settings.port = port
        mcp.settings.streamable_http_path = path
        mcp.settings.transport_security = security
        mcp.run(transport="streamable-http")
    else:
        mcp.run(transport="stdio")
