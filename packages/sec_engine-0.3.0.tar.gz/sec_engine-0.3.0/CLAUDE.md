# CLAUDE.md

## Project

sec-engine is an MCP server that exposes SEC EDGAR financial data to LLMs. It runs over stdio and provides 6 tools for company lookup, filing navigation, XBRL metrics, and narrative text extraction.

## Structure

```
sec_engine/
  server.py   — FastMCP server, defines all 6 tools
  edgar.py    — SEC EDGAR API client (async httpx, rate-limited)
  __main__.py — CLI entry point
  __init__.py
```

## Build & Run

```bash
uv pip install -e .    # install in dev mode
sec-engine             # run the MCP server (stdio)
```

Build system is hatchling. Dependencies: mcp, httpx, beautifulsoup4, lxml.

## Key Details

- Python >= 3.11 required
- SEC API has a 10 req/sec rate limit; EdgarClient handles this
- SEC requires a descriptive User-Agent header (configurable via `SEC_EDGAR_USER_AGENT` env var)
- No tests yet
- No auth needed — all SEC APIs are public