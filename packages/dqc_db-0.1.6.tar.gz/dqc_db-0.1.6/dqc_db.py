"""
DbClient - A thread-safe SQLite wrapper for multithreaded applications.

Architecture:
    - A single writer thread processes all write operations (INSERT, UPDATE, DELETE, etc.).
      Write requests are submitted via a queue.Queue and executed sequentially.
      This avoids SQLite write contention between threads.

    - Each thread gets its own reader connection via threading.local().
      This allows multiple threads to read concurrently without blocking each other.

    - The write queue accepts callable tasks. Each task runs on the writer thread's
      dedicated connection. Results (or errors) are sent back through a response queue.

    - When SQLite returns SQLITE_BUSY or SQLITE_LOCKED errors, write operations
      are retried with exponential backoff and jitter. This handles transient lock
      conflicts gracefully.

    - During a pinned transaction, a lock prevents other threads from submitting
      writes until the transaction commits or rolls back. This ensures isolation.
"""

import sqlite3
import threading
import queue
import time
import random
from typing import Any, Iterator
from contextlib import contextmanager


# SQLite error codes that indicate a retryable lock conflict.
SQLITE_BUSY = 5
SQLITE_LOCKED = 6


class DbClient:
    """Thread-safe SQLite wrapper with a single writer thread and thread-local readers."""

    def __init__(
        self,
        db_path: str = ":memory:",
        busy_timeout: int = 5000,
        max_retries: int = 10,
        pragmas: dict[str, Any] | None = None,
    ):
        self._db_path = db_path
        self._busy_timeout = busy_timeout
        self._max_retries = max_retries
        self._user_pragmas = pragmas or {}

        # Build the connection URI for :memory: databases so that
        # multiple connections share the same in-memory database.
        self._connection_uri = self._build_connection_uri(db_path)

        # Thread-local storage for reader connections and transaction state.
        self._local = threading.local()

        # Registry of all reader connections so we can close them all on shutdown.
        self._reader_connections: list[sqlite3.Connection] = []
        self._reader_connections_lock = threading.Lock()

        # Lock that ensures only the pinned-transaction owner can submit writes.
        # Other threads block until the pinned transaction commits or rolls back.
        self._pinned_lock = threading.Lock()
        # Tracks which thread currently owns the pinned transaction.
        self._pinned_owner: int | None = None

        # The write queue holds (task_function, response_queue) tuples.
        self._write_queue: queue.Queue = queue.Queue()

        # Create the writer connection and start the writer thread.
        self._writer_connection = self._create_connection()
        self._writer_thread = threading.Thread(
            target=self._writer_loop,
            name="db-writer",
            daemon=True,
        )
        self._writer_thread.start()

    # -------------------------------------------------------------------------
    # Connection helpers
    # -------------------------------------------------------------------------

    def _build_connection_uri(self, db_path: str) -> str | None:
        """For :memory: databases, return a shared-cache URI so all connections
        see the same data. For file databases, return None (use path directly)."""
        if db_path == ":memory:":
            return "file:shared_mem?mode=memory&cache=shared"
        return None

    def _create_connection(self) -> sqlite3.Connection:
        """Create and configure a new SQLite connection."""
        if self._connection_uri is not None:
            connection = sqlite3.connect(
                self._connection_uri,
                uri=True,
                check_same_thread=False,
                isolation_level=None,  # Manual transaction control.
            )
        else:
            connection = sqlite3.connect(
                self._db_path,
                check_same_thread=False,
                isolation_level=None,
            )

        # Use Row factory so results support dictionary-style access.
        connection.row_factory = sqlite3.Row

        self._apply_pragmas(connection)
        return connection

    def _apply_pragmas(self, connection: sqlite3.Connection) -> None:
        """Apply default and user-specified PRAGMAs to a connection."""
        default_pragmas = {
            "journal_mode": "WAL",
            "synchronous": "NORMAL",
            "foreign_keys": "ON",
            "busy_timeout": str(self._busy_timeout),
            "temp_store": "MEMORY",
            "wal_autocheckpoint": "1000",
        }

        # User pragmas override defaults.
        merged_pragmas = {**default_pragmas, **self._user_pragmas}

        for pragma_name, pragma_value in merged_pragmas.items():
            connection.execute(f"PRAGMA {pragma_name} = {pragma_value}")

    def _get_reader_connection(self) -> sqlite3.Connection:
        """Return the thread-local reader connection, creating it if needed."""
        connection = getattr(self._local, "reader_connection", None)
        if connection is None:
            connection = self._create_connection()
            self._local.reader_connection = connection

            # Register so close() can clean up all reader connections.
            with self._reader_connections_lock:
                self._reader_connections.append(connection)

        return connection

    # -------------------------------------------------------------------------
    # Writer thread
    # -------------------------------------------------------------------------

    def _writer_loop(self) -> None:
        """Main loop for the writer thread. Processes tasks from the write queue."""
        while True:
            item = self._write_queue.get()

            # A None item is the shutdown signal.
            if item is None:
                self._write_queue.task_done()
                break

            task_function, response_queue = item
            try:
                result = task_function(self._writer_connection)
                response_queue.put(("ok", result))
            except Exception as error:
                response_queue.put(("error", error))
            finally:
                self._write_queue.task_done()

    def _submit_write(self, task_function) -> Any:
        """Submit a task to the writer thread and wait for the result.

        If a pinned transaction is active on another thread, this blocks until
        that transaction finishes. The pinned-transaction owner skips the lock
        because it already holds it.
        """
        current_thread = threading.current_thread().ident

        # If this thread owns the pinned lock, skip acquiring it again.
        # Otherwise, acquire it to wait for any active pinned transaction.
        already_holds_lock = (self._pinned_owner == current_thread)

        if not already_holds_lock:
            self._pinned_lock.acquire()

        try:
            response_queue: queue.Queue = queue.Queue()
            self._write_queue.put((task_function, response_queue))
            status, result = response_queue.get()
        finally:
            if not already_holds_lock:
                self._pinned_lock.release()

        if status == "error":
            raise result
        return result

    # -------------------------------------------------------------------------
    # Retry logic
    # -------------------------------------------------------------------------

    def _is_retryable_error(self, error: sqlite3.OperationalError) -> bool:
        """Check if an SQLite error is a retryable lock error."""
        error_code = getattr(error, "sqlite_errorcode", None)
        if error_code is None:
            return False

        # Mask to get the primary error code from extended error codes.
        primary_code = error_code & 0xFF
        return primary_code in (SQLITE_BUSY, SQLITE_LOCKED)

    def _execute_with_retry(self, connection: sqlite3.Connection, operation) -> Any:
        """Execute an operation with retry logic for transient lock errors."""
        last_error = None

        for attempt in range(self._max_retries):
            try:
                return operation(connection)
            except sqlite3.OperationalError as error:
                if not self._is_retryable_error(error):
                    raise
                last_error = error

                # Exponential backoff: 10ms, 20ms, 40ms, ... with random jitter.
                base_delay = 0.01 * (2 ** attempt)
                jitter = random.uniform(0, base_delay)
                time.sleep(base_delay + jitter)

        # All retries exhausted.
        raise last_error  # type: ignore[misc]

    # -------------------------------------------------------------------------
    # Public API: Write operations
    # -------------------------------------------------------------------------

    def execute(self, sql: str, params: tuple | None = None) -> int:
        """Execute a single write statement. Returns the number of rows affected.

        This is routed through the writer queue for thread safety.
        Inside a batched transaction, the statement is collected and executed
        atomically when the transaction context exits.
        """
        # If a batched transaction is active on this thread, collect instead.
        collector = getattr(self._local, "batch_collector", None)
        if collector is not None:
            collector.add_execute(sql, params)
            return 0  # Actual rowcount not available until commit.

        def operation(connection: sqlite3.Connection) -> int:
            def do_execute(conn: sqlite3.Connection) -> int:
                cursor = conn.execute(sql, params or ())
                rowcount = cursor.rowcount
                cursor.close()
                return rowcount

            return self._execute_with_retry(connection, do_execute)

        return self._submit_write(operation)

    def executemany(self, sql: str, params_list: list[tuple]) -> int:
        """Execute a statement with multiple parameter sets. Returns total rows affected.

        This is routed through the writer queue for thread safety.
        For best performance, use inside a transaction() context.
        """
        # If a batched transaction is active on this thread, collect instead.
        collector = getattr(self._local, "batch_collector", None)
        if collector is not None:
            collector.add_executemany(sql, params_list)
            return 0  # Actual rowcount not available until commit.

        def operation(connection: sqlite3.Connection) -> int:
            def do_executemany(conn: sqlite3.Connection) -> int:
                cursor = conn.executemany(sql, params_list)
                rowcount = cursor.rowcount
                cursor.close()
                return rowcount

            return self._execute_with_retry(connection, do_executemany)

        return self._submit_write(operation)

    # -------------------------------------------------------------------------
    # Public API: Read operations
    # -------------------------------------------------------------------------

    def query(self, sql: str, params: tuple | None = None) -> list[sqlite3.Row]:
        """Execute a read query and return all rows immediately.

        Uses the thread-local reader connection. The cursor is closed right away
        to keep the read transaction short.
        """
        connection = self._get_reader_connection()
        cursor = connection.execute(sql, params or ())
        rows = cursor.fetchall()
        cursor.close()
        return rows

    def query_one(self, sql: str, params: tuple | None = None) -> sqlite3.Row | None:
        """Execute a read query and return the first row, or None if empty."""
        connection = self._get_reader_connection()
        cursor = connection.execute(sql, params or ())
        row = cursor.fetchone()
        cursor.close()
        return row

    def stream(
        self, sql: str, params: tuple | None = None, chunk_size: int = 10000
    ) -> Iterator[list[sqlite3.Row]]:
        """Stream query results in chunks to avoid loading everything into memory.

        Yields lists of rows (each list up to chunk_size rows).

        WARNING: Long-running streaming reads keep a WAL snapshot open,
        which can delay WAL checkpoints and increase disk usage.
        Keep streaming iterations as short as possible.
        """
        connection = self._get_reader_connection()
        cursor = connection.execute(sql, params or ())

        try:
            while True:
                chunk = cursor.fetchmany(chunk_size)
                if not chunk:
                    break
                yield chunk
        finally:
            cursor.close()

    # -------------------------------------------------------------------------
    # Public API: Transactions
    # -------------------------------------------------------------------------

    @contextmanager
    def transaction(self, mode: str = "batched"):
        """Context manager for transactions.

        Modes:
            "batched"  - Collects statements and executes them atomically on exit.
                         Call db.execute() / db.executemany() as usual inside the block.
                         Statements are buffered and committed together on exit.
            "pinned"   - Executes statements immediately on the writer connection
                         with explicit BEGIN IMMEDIATE / COMMIT / ROLLBACK.
                         Other threads' writes are blocked until this transaction ends.

        Nested transactions are not supported and will raise RuntimeError.
        """
        # Check for nested transactions.
        if getattr(self._local, "transaction_active", False):
            raise RuntimeError(
                "Nested transactions are not supported. "
                "A transaction is already active in this thread."
            )

        if mode == "batched":
            yield from self._batched_transaction()
        elif mode == "pinned":
            yield from self._pinned_transaction()
        else:
            raise ValueError(f"Unknown transaction mode: {mode!r}. Use 'batched' or 'pinned'.")

    def _batched_transaction(self):
        """Collect statements during the context, then execute them atomically.

        Sets a thread-local batch collector so that execute() and executemany()
        buffer statements instead of submitting them immediately.
        """
        collector = _BatchCollector()
        self._local.batch_collector = collector
        self._local.transaction_active = True

        try:
            yield self
        except Exception:
            # If the user code raises, discard the batch and re-raise.
            self._local.batch_collector = None
            self._local.transaction_active = False
            raise

        # Stop collecting — subsequent execute() calls go to the writer directly.
        self._local.batch_collector = None

        # Execute all collected statements in a single atomic transaction.
        try:
            statements = collector.statements

            def operation(connection: sqlite3.Connection) -> None:
                def do_batch(conn: sqlite3.Connection) -> None:
                    conn.execute("BEGIN IMMEDIATE")
                    try:
                        for sql, params, use_many in statements:
                            if use_many:
                                conn.executemany(sql, params)
                            else:
                                conn.execute(sql, params or ())
                        conn.execute("COMMIT")
                    except Exception:
                        conn.execute("ROLLBACK")
                        raise

                self._execute_with_retry(connection, do_batch)

            if statements:
                self._submit_write(operation)
        finally:
            self._local.transaction_active = False

    def _pinned_transaction(self):
        """Execute statements immediately on the writer connection with explicit
        BEGIN IMMEDIATE / COMMIT / ROLLBACK.

        Acquires _pinned_lock so that other threads' writes are blocked
        until this transaction commits or rolls back.
        """
        self._local.transaction_active = True

        # Acquire the pinned lock so no other thread can submit writes.
        self._pinned_lock.acquire()
        self._pinned_owner = threading.current_thread().ident

        # Begin the transaction on the writer thread.
        def begin(connection: sqlite3.Connection) -> None:
            def do_begin(conn: sqlite3.Connection) -> None:
                conn.execute("BEGIN IMMEDIATE")

            self._execute_with_retry(connection, do_begin)

        try:
            self._submit_write(begin)
        except Exception:
            self._pinned_owner = None
            self._pinned_lock.release()
            self._local.transaction_active = False
            raise

        try:
            yield self
        except Exception:
            # Roll back on error.
            def rollback(connection: sqlite3.Connection) -> None:
                connection.execute("ROLLBACK")

            try:
                self._submit_write(rollback)
            finally:
                self._pinned_owner = None
                self._pinned_lock.release()
                self._local.transaction_active = False
            raise

        # Commit on success.
        def commit(connection: sqlite3.Connection) -> None:
            connection.execute("COMMIT")

        try:
            self._submit_write(commit)
        finally:
            self._pinned_owner = None
            self._pinned_lock.release()
            self._local.transaction_active = False

    # -------------------------------------------------------------------------
    # Shutdown and context manager
    # -------------------------------------------------------------------------

    def close(self) -> None:
        """Shut down the writer thread and close all connections.

        Waits for all queued writes to finish before stopping.
        """
        # Wait until every task already in the queue has been processed.
        self._write_queue.join()

        # Now send the shutdown signal and wait for the writer thread to exit.
        self._write_queue.put(None)
        self._writer_thread.join()

        # Close the writer connection.
        self._writer_connection.close()

        # Close all reader connections from every thread.
        with self._reader_connections_lock:
            for connection in self._reader_connections:
                try:
                    connection.close()
                except Exception:
                    pass  # Best-effort cleanup.
            self._reader_connections.clear()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False


class _BatchCollector:
    """Collects SQL statements for a batched transaction.

    Statements are stored and then executed atomically when the
    transaction context manager exits.
    """

    def __init__(self):
        # Each entry is (sql, params, use_many).
        self.statements: list[tuple[str, Any, bool]] = []

    def add_execute(self, sql: str, params: tuple | None = None) -> None:
        """Add a single statement to the batch."""
        self.statements.append((sql, params, False))

    def add_executemany(self, sql: str, params_list: list[tuple]) -> None:
        """Add an executemany statement to the batch."""
        self.statements.append((sql, params_list, True))
