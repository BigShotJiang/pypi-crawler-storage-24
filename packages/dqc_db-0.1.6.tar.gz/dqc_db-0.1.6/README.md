<p align="center">
  <img src="https://dev.dataqualitycompany.app/favicon/DQC-Logo-801x331.png" alt="Data Quality Company" width="200">
</p>

# dqc-db

A thread-safe SQLite wrapper for Python with a single-writer, multi-reader architecture. Built by [Data Quality Company](https://dataqualitycompany.app).

## Features

- **Single writer, many readers** — all writes go through a background writer thread via a queue; each reading thread gets its own connection for parallel reads
- **Two transaction modes** — batched (collects statements, commits at once) and pinned (immediate execution, blocks other writers)
- **Automatic retry** — write operations retry with exponential backoff + jitter on `SQLITE_BUSY` / `SQLITE_LOCKED`
- **Streaming** — fetch large result sets in chunks without loading everything into memory
- **Zero dependencies** — only Python 3.11+ standard library

## Installation

```bash
pip install dqc-db
```

## Quick start

```python
from dqc_db import DbClient

with DbClient("my.db") as db:
    db.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, name TEXT, age INTEGER)")
    db.execute("INSERT INTO users (name, age) VALUES (?, ?)", ("Alice", 30))

    users = db.query("SELECT * FROM users")
    print(users[0]["name"])  # "Alice"
```

## API

### Writes

```python
db.execute("INSERT INTO users (name, age) VALUES (?, ?)", ("Alice", 30))
db.executemany("INSERT INTO users (name, age) VALUES (?, ?)", [("Bob", 25), ("Eve", 42)])
```

### Reads

```python
db.query("SELECT * FROM users")                          # list of rows
db.query_one("SELECT * FROM users WHERE id = ?", (1,))   # single row or None

for chunk in db.stream("SELECT * FROM big_table", chunk_size=5000):
    process(chunk)
```

### Transactions

```python
# Batched (default) — commits everything at once
with db.transaction():
    db.executemany("INSERT INTO users (name, age) VALUES (?, ?)", big_list)

# Pinned — each statement runs immediately, blocks other writers
with db.transaction(mode="pinned"):
    db.execute("INSERT INTO users (name, age) VALUES (?, ?)", ("Alice", 30))
    db.execute("UPDATE users SET age = 31 WHERE name = ?", ("Alice",))
```

### Constructor options

```python
DbClient(
    db_path=":memory:",
    busy_timeout=5000,
    max_retries=10,
    pragmas={"cache_size": "-20000"},
)
```

### Default PRAGMAs

These are set on every connection automatically:

```
journal_mode = WAL
synchronous = NORMAL
foreign_keys = ON
busy_timeout = 5000
temp_store = MEMORY
wal_autocheckpoint = 1000
```

Override any default via the `pragmas` constructor parameter:

```python
db = DbClient("my.db", pragmas={"synchronous": "FULL", "cache_size": "-20000"})
```

## Advanced examples

### Bulk inserts with transactions

When you need to insert many rows at once, wrapping them in a `transaction()` makes it much faster. Without a transaction, each insert is saved to disk individually. With a transaction, all rows are collected and saved in one go at the end.

This is the recommended pattern for any batch of inserts, updates, or deletes:

```python
users = [("Alice", 30), ("Bob", 25), ("Eve", 42), ("Charlie", 35)]

with db.transaction():
    db.execute("CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, name TEXT, age INTEGER)")
    db.executemany("INSERT INTO users (name, age) VALUES (?, ?)", users)
# When the "with" block ends, all 4 rows are saved to disk at once.
# If anything goes wrong inside the block, nothing is saved — the database stays unchanged.
```

### Multi-step writes with pinned transactions

Sometimes you need to run several writes that depend on each other. For example: create an order, update the user's order count, and log the action. These steps should either all succeed together or all fail together.

Use `mode="pinned"` for this. In pinned mode, each statement runs right away (not collected for later), and no other part of your program can write to the database until you're done:

```python
with db.transaction(mode="pinned"):
    db.execute("INSERT INTO orders (user_id, total) VALUES (?, ?)", (1, 99.99))
    db.execute("UPDATE users SET order_count = order_count + 1 WHERE id = ?", (1,))
    db.execute("INSERT INTO audit_log (action, user_id) VALUES (?, ?)", ("new_order", 1))
# All three changes are saved together when the block ends.
# If any step fails, all three are undone automatically.
```

**When to use which mode:**
- **Batched** (default) — best for simple inserts where you don't need to read back values between writes. Faster because it saves everything in one batch.
- **Pinned** — use when writes depend on each other, or when you need each write to happen immediately inside the block.

### Concurrent reads from multiple threads

You can safely read from the database in many threads at the same time. Each thread automatically gets its own separate connection, so reads never slow each other down.

This is useful in web servers or any program where multiple things are happening at once:

```python
import threading

def read_users(db, thread_name):
    users = db.query("SELECT * FROM users WHERE age > ?", (25,))
    print(f"{thread_name}: found {len(users)} users")

with DbClient("my.db") as db:
    # Start 5 threads, all reading from the same database at the same time
    threads = [
        threading.Thread(target=read_users, args=(db, f"T{i}"))
        for i in range(5)
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
# All 5 threads read in parallel — no waiting, no conflicts.
```

### Streaming large result sets

If your table has millions of rows, loading them all into memory at once could use too much RAM and slow down your program. The `stream()` method fetches rows in small batches (chunks), so only a small number of rows are in memory at any time:

```python
total = 0
for chunk in db.stream("SELECT * FROM events", chunk_size=10000):
    # Each chunk is a list of up to 10,000 rows.
    # Process them, then the next chunk is loaded.
    for row in chunk:
        total += row["amount"]
print(f"Total: {total}")
# Even with 10 million rows, memory usage stays low because
# only 10,000 rows are loaded at a time.
```

### Multi-threaded writes

Multiple threads can write to the database at the same time. You don't need to worry about conflicts — all writes are automatically sent to a single background writer that processes them one by one in order.

Each thread can use its own transaction, and they will be executed safely without mixing up:

```python
import threading

def insert_batch(db, batch, thread_name):
    with db.transaction():
        db.executemany("INSERT INTO logs (source, message) VALUES (?, ?)", batch)
    print(f"{thread_name}: inserted {len(batch)} rows")

with DbClient("app.db") as db:
    db.execute("CREATE TABLE logs (id INTEGER PRIMARY KEY, source TEXT, message TEXT)")

    # Create 4 batches of 1,000 rows each
    batches = [
        [(f"service_{i}", f"msg_{j}") for j in range(1000)]
        for i in range(4)
    ]

    # Run 4 threads, each inserting its own batch
    threads = [
        threading.Thread(target=insert_batch, args=(db, batch, f"T{i}"))
        for i, batch in enumerate(batches)
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    # All 4,000 rows are inserted safely. Each thread's transaction is
    # handled one at a time by the background writer — no data corruption.
```

### In-memory database

Instead of saving to a file, you can create a database that lives entirely in memory. This is great for tests or temporary data that doesn't need to survive after your program exits.

All threads share the same in-memory data, just like with a file-based database:

```python
with DbClient(":memory:") as db:
    db.execute("CREATE TABLE temp (id INTEGER PRIMARY KEY, value TEXT)")
    db.execute("INSERT INTO temp (value) VALUES (?)", ("hello",))
    print(db.query_one("SELECT * FROM temp")["value"])  # "hello"
# When the "with" block ends, the in-memory database is gone.
# Nothing is saved to disk.
```

## Architecture

```
Thread A ──► queue ──► Writer Thread ──► SQLite
Thread B ──►
Thread C ──►
```

- Writes are serialized through a single background writer thread
- Reads use thread-local connections for parallel access
- In-memory databases use shared-cache URIs so all connections see the same data

## License

Proprietary. Copyright Data Quality Company. All rights reserved.
