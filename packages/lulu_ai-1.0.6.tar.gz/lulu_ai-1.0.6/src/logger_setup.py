import logging
import sys
import os
from logging.handlers import RotatingFileHandler

# Set absolute log path in AppData
APP_DATA_DIR = os.path.join(os.getenv('LOCALAPPDATA'), 'LuluApp', 'logs')
os.makedirs(APP_DATA_DIR, exist_ok=True)
log_file_path = os.path.join(APP_DATA_DIR, 'app.log')

# Clear existing handlers
for handler in logging.root.handlers[:]:
    logging.root.removeHandler(handler)

# ---------------------------------------------------------------------------
# Rotating file handler
#
# Keeps at most 3 log files (app.log, app.log.1, app.log.2),
# each capped at 5 MB. Total max disk usage: 15 MB.
# Once app.log hits 5 MB it is renamed to app.log.1, old app.log.1
# becomes app.log.2, and old app.log.2 is deleted automatically.
# ---------------------------------------------------------------------------

_file_handler = RotatingFileHandler(
    log_file_path,
    maxBytes=5 * 1024 * 1024,   # 5 MB per file
    backupCount=3,               # keep 3 rotated files
    encoding='utf-8',
)

_log_format = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
_file_handler.setFormatter(_log_format)

_console_handler = logging.StreamHandler(sys.stdout)
_console_handler.setFormatter(_log_format)

# Configure root logger
logging.root.setLevel(logging.INFO)
logging.root.addHandler(_file_handler)
logging.root.addHandler(_console_handler)

logger = logging.getLogger(__name__)
logger.propagate = True


# ---------------------------------------------------------------------------
# Uncaught exception hook — logs crash tracebacks to the rotating file
# ---------------------------------------------------------------------------

def handle_exception(exc_type, exc_value, exc_traceback):
    if issubclass(exc_type, KeyboardInterrupt):
        sys.__excepthook__(exc_type, exc_value, exc_traceback)
        return
    logger.error("Uncaught exception", exc_info=(exc_type, exc_value, exc_traceback))

sys.excepthook = handle_exception
