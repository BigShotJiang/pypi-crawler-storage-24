import threading
import os
import re
import pyautogui
from PIL import Image
import config
import state
from logger_setup import logger
from utils import capture_single_click
from ai_core import generate_content_with_fallback
import ai_core
import explanation_window
import prompts


# ---------------------------------------------------------------------------
# Image cache — avoids re-opening the same files from disk on every AI call
# ---------------------------------------------------------------------------

_cached_image_paths: list[str] = []
_cached_images: list[Image.Image] = []


def _get_images(paths: list[str]) -> list[Image.Image]:
    """Return PIL Image objects for *paths*, re-using the cache when paths are unchanged."""
    global _cached_image_paths, _cached_images
    if paths != _cached_image_paths:
        _cached_images = [Image.open(p) for p in paths]
        _cached_image_paths = list(paths)
    return _cached_images


# ---------------------------------------------------------------------------
# Screenshot capture
# ---------------------------------------------------------------------------

# Maximum number of screenshots allowed in a single session.
# Prevents unbounded memory growth if the user captures many screenshots
# without clearing. Prompt them to press Ctrl+Alt+R to reset.
MAX_SCREENSHOTS = 20


def capture_subjective_screenshot() -> None:
    """
    Captures a screenshot for coding/subjective question.
    Triggered by Ctrl+Alt+S.
    Can be called multiple times — stores screenshots in order.
    Capped at MAX_SCREENSHOTS per session to prevent unbounded memory growth.
    """
    # --- Guard: enforce cap before doing anything ---
    if len(state.subjective_screenshots) >= MAX_SCREENSHOTS:
        logger.warning(
            f"⚠️ Maximum of {MAX_SCREENSHOTS} screenshots reached for this session. "
            f"Press Ctrl+Alt+R to clear and start a new session."
        )
        return

    logger.info("🖼️  CAPTURE SUBJECTIVE SCREENSHOT: Please click TOP-LEFT...")
    top_left = capture_single_click()
    if not top_left:
        logger.error("❌ Capture cancelled.")
        return

    logger.info("MouseClicked Please click BOTTOM-RIGHT...")
    bottom_right = capture_single_click()
    if not bottom_right:
        logger.error("❌ Capture cancelled.")
        return

    x1, y1 = top_left
    x2, y2 = bottom_right
    width = x2 - x1
    height = y2 - y1

    if width <= 0 or height <= 0:
        logger.error("❌ Invalid region.")
        return

    try:
        idx = len(state.subjective_screenshots) + 1
        filename = f"{idx}.png"
        filepath = os.path.join(config.SUBJECTIVE_SCREENSHOT_DIR, filename)

        screenshot = pyautogui.screenshot(region=(x1, y1, width, height))
        screenshot.save(filepath)
        state.subjective_screenshots.append(filepath)

        logger.info(f"✅ Saved screenshot {idx} to {filepath}")
        logger.info(f"📊 Total screenshots captured: {len(state.subjective_screenshots)}")
    except Exception as e:
        logger.error(f"❌ Failed to save screenshot: {e}")


# ---------------------------------------------------------------------------
# AI response generation
# ---------------------------------------------------------------------------

def generate_ai_response() -> None:
    """
    Sends all captured subjective screenshots to Gemini and stores response.
    Runs in background — doesn't block hotkey system.
    """
    if not state.subjective_screenshots:
        logger.error("❌ No screenshots captured. Press Ctrl+Alt+S first.")
        return

    # Record how many screenshots we have now, so we know any FUTURE screenshots are errors
    state.screenshots_count_at_generation = len(state.subjective_screenshots)
    logger.info(f"🧠 Sending {len(state.subjective_screenshots)} screenshots to Gemini...")

    # Reset event
    state.ai_response_ready_subjective.clear()

    def ai_worker():
        try:
            # Load images — uses cache if paths haven't changed
            images = _get_images(state.subjective_screenshots)
            current_count = len(state.subjective_screenshots)

            # --- STEP 1: Classify Question Type ---
            if state.cached_question_type and state.cached_question_type_count == current_count:
                question_type = state.cached_question_type
                logger.info(f"♻️ Reusing cached question type: {question_type.upper()}")
            else:
                logger.info("🔍 Classifying question type...")
                classification_content = [prompts.CLASSIFICATION_PROMPT] + images
                classification_response = generate_content_with_fallback(classification_content)
                question_type = classification_response.text.strip().lower()

            # Clean up response just in case
            if 'sql' in question_type:
                question_type = 'sql'
            elif 'non-coding' in question_type:
                question_type = 'non-coding'
            elif 'dsa' in question_type or 'coding' in question_type:
                question_type = 'dsa'
            else:
                question_type = 'non-coding'

            logger.info(f"✅ Question classified as: {question_type.upper()}")
            state.cached_question_type = question_type
            state.cached_question_type_count = current_count

            # --- STEP 2: Select Prompt based on Type ---
            prompt = ""

            if question_type == 'dsa':
                prompt = prompts.DSA_CODING_PROMPT
            elif question_type == 'sql':
                prompt = prompts.SQL_PROMPT
            else:  # non-coding
                prompt = prompts.NON_CODING_PROMPT

            # --- STEP 3: Generate Final Response ---
            logger.info(f"🧠 Generating answer using {question_type.upper()} prompt...")
            if question_type in ('dsa', 'sql'):
                # Coding / SQL path: first extract full question/template text
                # from screenshots, then generate answer using text-only model(s).
                if state.cached_coding_sql_question_text and state.cached_coding_sql_question_text_count == current_count:
                    question_text = state.cached_coding_sql_question_text
                    logger.info(f"♻️ Reusing cached coding/SQL extraction ({len(question_text)} chars).")
                else:
                    logger.info("📷 Extracting coding/SQL question text from screenshots (Gemini)...")
                    extract_content = [prompts.CODING_SQL_EXTRACT_PROMPT] + images
                    extracted = generate_content_with_fallback(extract_content)
                    question_text = extracted.text.strip()
                    state.cached_coding_sql_question_text = question_text
                    state.cached_coding_sql_question_text_count = current_count

                if question_text:
                    logger.info(f"📝 Extracted coding/SQL question ({len(question_text)} chars), routing to code generator...")
                    full_prompt = prompt + "\n\nQuestion/Template:\n" + question_text
                    raw_response = ai_core.generate_code_answer(full_prompt)
                else:
                    logger.warning("⚠️ Coding/SQL extraction returned empty text. Falling back to instruction-only prompt.")
                    raw_response = ai_core.generate_code_answer(prompt)
            else:
                # Non-coding two-step: Gemini extracts question text from images,
                # then Groq generates the answer (text-only, no image needed).
                if state.cached_non_coding_question_text and state.cached_non_coding_question_text_count == current_count:
                    question_text = state.cached_non_coding_question_text
                    logger.info(f"♻️ Reusing cached non-coding extraction ({len(question_text)} chars).")
                else:
                    logger.info("📷 Extracting question text from screenshots (Gemini)...")
                    extract_content = [prompts.NON_CODING_EXTRACT_PROMPT] + images
                    extracted = generate_content_with_fallback(extract_content)
                    question_text = extracted.text.strip()
                    state.cached_non_coding_question_text = question_text
                    state.cached_non_coding_question_text_count = current_count

                logger.info(f"📝 Extracted question ({len(question_text)} chars), routing to Groq...")
                full_prompt = prompt + "\n\nQuestion:\n" + question_text
                raw_response = ai_core.generate_theory_answer(full_prompt)

            raw_response = raw_response.strip()

            # Clean response to avoid triggering editor auto-indent
            cleaned_response = re.sub(r'\s+$', '', raw_response, flags=re.MULTILINE)
            cleaned_response = re.sub(r'\n{2,}', '\n', cleaned_response)

            state.ai_response_text = cleaned_response

            # Log the full AI response (not truncated)
            logger.info("✅ AI Response Received:")
            logger.info("=" * 50)
            logger.info("FULL AI RESPONSE:")
            logger.info("-" * 50)
            logger.info(state.ai_response_text)
            logger.info("-" * 50)
            logger.info(f"Response length: {len(state.ai_response_text)} characters")
            logger.info("=" * 50)
            logger.info("✅ Press Ctrl+Alt+T to auto-type this response.")

        except Exception as e:
            logger.error(f"❌ Error with Gemini: {e}")
            state.ai_response_text = None
        finally:
            state.subjective_question_answered = True
            state.ai_response_ready_subjective.set()

    # Run in background
    threading.Thread(target=ai_worker, daemon=True).start()
    logger.info("⏳ AI is working... You can press Ctrl+Alt+T later when ready.")


# ---------------------------------------------------------------------------
# Retry
# ---------------------------------------------------------------------------

def retry_ai_response() -> None:
    """
    Retries the AI response by sending the previous answer and the latest screenshot(s) (error).
    """
    if not state.ai_response_text:
        logger.error("❌ No previous AI response found to retry.")
        return

    if not state.subjective_screenshots:
        logger.error("❌ No screenshots found. Capture the error using Ctrl+Alt+S.")
        return

    # Identify error screenshots: Any screenshot captured AFTER the last generation
    if len(state.subjective_screenshots) > state.screenshots_count_at_generation:
        error_paths = state.subjective_screenshots[state.screenshots_count_at_generation:]
        logger.info(f"🔄 Detected {len(error_paths)} new error screenshot(s).")
    else:
        # Fallback: Use the very last screenshot if no new ones were detected
        error_paths = [state.subjective_screenshots[-1]]
        logger.info("🔄 No new screenshots detected since generation. Using the last one as error.")

    logger.info(f"📤 Sending previous AI response + {len(error_paths)} Error Screenshot(s) to Gemini...")

    # Reset event
    state.ai_response_ready_subjective.clear()

    def ai_worker():
        try:
            # Error images are always new paths — load fresh, don't use main cache
            error_images = [Image.open(p) for p in error_paths]

            # Step 1: Gemini extracts the error text from the screenshots
            logger.info("📷 Extracting error from screenshots (Gemini)...")
            extracted = generate_content_with_fallback([prompts.RETRY_ERROR_EXTRACT_PROMPT] + error_images)
            error_description = extracted.text.strip()
            logger.info(f"📝 Extracted error ({len(error_description)} chars), routing fix to OpenRouter...")

            # Step 2: Route code fix through ai_core.generate_code_answer (→ OpenRouter)
            fix_prompt = prompts.build_retry_fix_prompt(state.ai_response_text, error_description)
            raw_response = ai_core.generate_code_answer(fix_prompt)
            raw_response = raw_response.strip()

            # Clean response
            cleaned_response = re.sub(r'\s+$', '', raw_response, flags=re.MULTILINE)
            cleaned_response = re.sub(r'\n{2,}', '\n', cleaned_response)

            state.ai_response_text = cleaned_response

            logger.info("✅ AI Retry Response Received:")
            logger.info("=" * 50)
            logger.info(state.ai_response_text)
            logger.info("=" * 50)
            logger.info("✅ Press Ctrl+Alt+T to auto-type this corrected response.")

        except Exception as e:
            logger.error(f"❌ Error with Retry: {e}")
        finally:
            state.subjective_question_answered = True
            state.ai_response_ready_subjective.set()

    threading.Thread(target=ai_worker, daemon=True).start()
    logger.info("⏳ AI is fixing the solution...")


# ---------------------------------------------------------------------------
# Code explanation
# ---------------------------------------------------------------------------

def generate_code_explanation() -> None:
    """
    Generates a summary, step-by-step approach, dry run, and complexity analysis
    for the current code solution.
    Triggered by Ctrl+Alt+J.
    """
    if not state.ai_response_text:
        logger.warning("⚠️ No code solution found to explain. Please generate a solution first.")
        explanation_window.show_explanation("No code solution found to explain.\nPlease generate a solution first using Ctrl+Alt+G.")
        explanation_window.toggle_explanation()
        return

    logger.info("🧠 Generating code explanation...")
    explanation_window.show_explanation("Generating explanation... Please wait.")
    explanation_window.toggle_explanation()  # Show window immediately

    def ai_worker():
        try:
            # Route through ai_core.explain_code so Groq is used when configured
            explanation_text = ai_core.explain_code(state.ai_response_text, extra_context=None)

            logger.info("✅ Explanation generated.")
            explanation_window.show_explanation(explanation_text)

        except Exception as e:
            logger.error(f"❌ Error generating explanation: {e}")
            explanation_window.show_explanation(f"Error generating explanation:\n{e}")

    threading.Thread(target=ai_worker, daemon=True).start()


# ---------------------------------------------------------------------------
# Step-by-step solution
# ---------------------------------------------------------------------------

def generate_step_by_step_response() -> None:
    """
    Generates a step-by-step solution for the captured subjective screenshots.
    Triggered by Ctrl+Alt+O.
    """
    if not state.subjective_screenshots:
        logger.error("❌ No screenshots captured. Press Ctrl+Alt+S first.")
        explanation_window.show_explanation("No screenshots captured.\nPlease capture the question first using Ctrl+Alt+S.")
        explanation_window.toggle_explanation()
        return

    logger.info(f"🧠 Generating step-by-step solution for {len(state.subjective_screenshots)} screenshots...")
    explanation_window.show_explanation("Generating step-by-step solution... Please wait.")
    explanation_window.toggle_explanation()  # Show window immediately

    def ai_worker():
        try:
            # Load images — uses cache if paths haven't changed
            images = _get_images(state.subjective_screenshots)

            if config.USE_GROQ_FOR_EXPLANATION and config.GROQ_API_KEY:
                # Two-step: Gemini extracts question text from screenshots,
                # then Groq generates the step-by-step answer (text-only).
                logger.info("📷 Extracting question text from screenshots (Gemini)...")
                extracted = generate_content_with_fallback([prompts.STEP_BY_STEP_EXTRACT_PROMPT] + images)
                question_text = extracted.text.strip()
                logger.info(f"📝 Extracted question ({len(question_text)} chars), routing to Groq...")
                full_prompt = prompts.STEP_BY_STEP_PROMPT + "\n\nQuestion/Problem:\n" + question_text
                explanation_text = ai_core.generate_theory_answer(full_prompt)
            else:
                content = [prompts.STEP_BY_STEP_PROMPT] + images
                response = generate_content_with_fallback(content)
                explanation_text = response.text.strip()

            logger.info("✅ Step-by-step solution generated.")
            explanation_window.show_explanation(explanation_text)

        except Exception as e:
            logger.error(f"❌ Error generating step-by-step solution: {e}")
            explanation_window.show_explanation(f"Error generating solution:\n{e}")
        finally:
            state.subjective_question_answered = True

    threading.Thread(target=ai_worker, daemon=True).start()