"""ai_core.py — AI provider routing with Gemini, Groq, and OpenRouter.

Uses the new google-genai SDK (replaces deprecated google-generativeai).
"""
from __future__ import annotations

import io
import time
import threading
from typing import Optional, Any, List
from PIL import Image

import config
from logger_setup import logger
from openrouter_client import generate_code_from_openrouter, OpenRouterError
from groq_client import chat_with_groq, explain_code_with_groq, GroqError

# ---------------------------------------------------------------------------
# New google-genai SDK client cache
#
# The new SDK uses a Client object per API key instead of a global configure()
# call. We cache one Client per key so we never recreate it on each request.
# The lock only covers client construction — not the actual API call — so
# concurrent threads are never serialised during the network round-trip.
# ---------------------------------------------------------------------------

from google import genai
from google.genai import types as genai_types

_client_lock: threading.Lock = threading.Lock()
_client_cache: dict[str, genai.Client] = {}


def _get_client(api_key: str) -> genai.Client:
    """Return a cached genai.Client for *api_key*, creating if needed."""
    if api_key in _client_cache:
        return _client_cache[api_key]
    with _client_lock:
        if api_key not in _client_cache:
            _client_cache[api_key] = genai.Client(api_key=api_key)
    return _client_cache[api_key]


# ---------------------------------------------------------------------------
# Custom exceptions
# ---------------------------------------------------------------------------

class AIProviderError(Exception):
    """Base exception for all AI-provider failures."""


class GeminiError(AIProviderError):
    """Raised specifically for Google Gemini API failures."""


AIError = AIProviderError   # backward-compatible alias


# ---------------------------------------------------------------------------
# Retry with exponential backoff
# ---------------------------------------------------------------------------

_MAX_RETRIES = 3
_BASE_DELAY  = 1.0


def _with_backoff(fn, *args, provider: str = "API", **kwargs):
    """Call fn retrying up to _MAX_RETRIES times on rate-limit errors."""
    last_error = None
    for attempt in range(1, _MAX_RETRIES + 1):
        try:
            return fn(*args, **kwargs)
        except Exception as exc:
            last_error = exc
            if not _is_rate_limit_error(exc):
                raise
            if attempt == _MAX_RETRIES:
                logger.error(f"❌ {provider} rate limit — all {_MAX_RETRIES} retries exhausted.")
                raise
            wait = _BASE_DELAY * (2 ** (attempt - 1))
            logger.warning(f"⚠️ {provider} rate limit (attempt {attempt}/{_MAX_RETRIES}). Retrying in {wait:.0f}s...")
            time.sleep(wait)
    if last_error:
        raise last_error


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------

def _get_configured_api_keys() -> List[str]:
    keys = []
    primary   = (config.API_KEY or "").strip()
    secondary = (getattr(config, "API_KEY_SECONDARY", "") or "").strip()
    if primary:
        keys.append(primary)
    if secondary and secondary not in keys:
        keys.append(secondary)
    return keys


def _is_rate_limit_error(error: Exception) -> bool:
    msg = str(error).lower()
    return any(m in msg for m in ["429", "rate limit", "too many requests",
                                   "quota", "resource_exhausted", "limit exceeded"])


def _mask_key(key: str) -> str:
    return "****" if len(key) <= 8 else key[:4] + "..." + key[-4:]


def _pil_to_part(img: Image.Image) -> genai_types.Part:
    """Convert a PIL Image to a genai Part for inline image input."""
    buf = io.BytesIO()
    # Convert to RGB if needed (JPEG doesn't support RGBA/P)
    if img.mode in ("RGBA", "P", "LA"):
        img = img.convert("RGB")
    elif img.mode != "RGB":
        img = img.convert("RGB")
    img.save(buf, format="JPEG", quality=85, optimize=True)
    return genai_types.Part.from_bytes(data=buf.getvalue(), mime_type="image/jpeg")


def _build_contents(parts: list) -> list:
    """Convert a mixed list of strings and PIL Images into genai content parts."""
    content_parts = []
    for part in parts:
        if isinstance(part, str):
            content_parts.append(part)
        elif isinstance(part, Image.Image):
            content_parts.append(_pil_to_part(part))
        else:
            content_parts.append(part)
    return content_parts


# ---------------------------------------------------------------------------
# Core Gemini generation helper
# ---------------------------------------------------------------------------

def generate_content_with_fallback(content: Any):
    """Call Gemini with per-key retry + automatic secondary key fallback."""
    api_keys = _get_configured_api_keys()
    if not api_keys:
        raise ValueError("No Gemini API key configured. Open settings panel (Ctrl+Alt+M) to add your key.")

    # Convert mixed list to genai-compatible format
    if isinstance(content, list):
        content = _build_contents(content)

    last_error = None

    for idx, api_key in enumerate(api_keys):
        try:
            client = _get_client(api_key)
            label  = "primary" if idx == 0 else "secondary"

            def _call():
                return client.models.generate_content(
                    model=config.MODEL_NAME,
                    contents=content,
                )

            result = _with_backoff(_call, provider=f"Gemini {label} key")
            logger.info(f"✅ Gemini response via {label} key [{_mask_key(api_key)}]")
            return result

        except Exception as error:
            last_error = error
            is_last_key = idx == len(api_keys) - 1
            if not is_last_key:
                logger.warning(
                    f"⚠️ API key {idx + 1} failed ({type(error).__name__}). "
                    f"Switching to backup key..."
                )
                continue
            raise

    if last_error:
        raise last_error
    raise RuntimeError("Failed to generate content with Gemini")


# ---------------------------------------------------------------------------
# Provider-agnostic public API
# ---------------------------------------------------------------------------

def solve_mcq_with_vision(
    question_image: bytes,
    options_images: list[bytes],
    context_image: bytes | None = None,
) -> int:
    """Solve a multiple-choice question from raw image bytes."""
    try:
        num_options  = len(options_images)
        question_img = Image.open(io.BytesIO(question_image))
        option_imgs  = [Image.open(io.BytesIO(b)) for b in options_images]

        context_note = "The first image provides context/passage for the question. " if context_image else ""
        prompt = (
            f"{context_note}"
            "Analyze the multiple-choice question carefully. "
            f"There are {num_options} answer options provided as separate images after the question. "
            f"Your task is to return ONLY the index number (1, 2, ..., {num_options}) "
            "corresponding to the correct option. "
            "Output format: Just the integer number. No text, no explanation, no punctuation."
        )

        parts: list = [prompt]
        if context_image:
            parts.append(Image.open(io.BytesIO(context_image)))
        parts.append(question_img)
        parts.extend(option_imgs)

        response    = generate_content_with_fallback(parts)
        answer_text = response.text.strip()
        logger.info(f"🤖 Gemini says: {answer_text}")

        index = int(answer_text)
        if 1 <= index <= num_options:
            return index
        raise GeminiError(f"Option index {index} out of range [1, {num_options}]")

    except GeminiError:
        raise
    except Exception as exc:
        raise GeminiError(f"solve_mcq_with_vision failed: {exc}") from exc


def generate_code_answer(prompt: str) -> str:
    """Generate a coding answer — Groq → OpenRouter → Gemini fallback."""
    logger.info(f"generate_code_answer: GROQ_API_KEY set={bool(config.GROQ_API_KEY)}, USE_GROQ_FOR_CODE={config.USE_GROQ_FOR_CODE}")

    if config.USE_GROQ_FOR_CODE and config.GROQ_API_KEY:
        try:
            logger.info("🔀 Routing code generation to Groq")
            return _with_backoff(chat_with_groq, prompt, model=config.GROQ_DEFAULT_MODEL, provider="Groq")
        except GroqError as exc:
            logger.warning(f"⚠️ Groq failed, falling through to OpenRouter: {exc}")

    if config.USE_OPENROUTER_FOR_CODE and config.OPENROUTER_API_KEY:
        try:
            logger.info("🔀 Routing code generation to OpenRouter")
            return _with_backoff(generate_code_from_openrouter, prompt, provider="OpenRouter")
        except OpenRouterError as exc:
            raise AIProviderError(f"generate_code_answer (OpenRouter) failed: {exc}") from exc

    try:
        response = generate_content_with_fallback([prompt])
        return response.text
    except Exception as exc:
        raise GeminiError(f"generate_code_answer failed: {exc}") from exc


def generate_theory_answer(prompt: str) -> str:
    """Generate a theory/essay answer — Groq → Gemini fallback."""
    if config.USE_GROQ_FOR_EXPLANATION and config.GROQ_API_KEY:
        try:
            logger.info("🔀 Routing theory answer to Groq")
            return _with_backoff(chat_with_groq, prompt, model=config.GROQ_DEFAULT_MODEL, provider="Groq")
        except GroqError as exc:
            raise AIProviderError(f"generate_theory_answer (Groq) failed: {exc}") from exc
    try:
        response = generate_content_with_fallback([prompt])
        return response.text
    except Exception as exc:
        raise GeminiError(f"generate_theory_answer failed: {exc}") from exc


def explain_code(code: str, extra_context: str | None = None) -> str:
    """Return a natural-language explanation of code — Groq → Gemini fallback."""
    if config.USE_GROQ_FOR_EXPLANATION and config.GROQ_API_KEY:
        try:
            logger.info("🔀 Routing code explanation to Groq")
            return _with_backoff(
                explain_code_with_groq, code, extra_context=extra_context, provider="Groq"
            )
        except GroqError as exc:
            raise AIProviderError(f"explain_code (Groq) failed: {exc}") from exc
    try:
        full_prompt = f"Explain the following code:\n\n{code}"
        if extra_context:
            full_prompt += f"\n\nAdditional context:\n{extra_context}"
        response = generate_content_with_fallback([full_prompt])
        return response.text
    except Exception as exc:
        raise GeminiError(f"explain_code failed: {exc}") from exc


# ---------------------------------------------------------------------------
# Legacy path-based helpers (backward compatibility)
# ---------------------------------------------------------------------------

def get_correct_option_index(image_path: str, num_options: int = 4) -> Optional[int]:
    """Single-image mode — for standalone MCQs."""
    try:
        image  = Image.open(image_path)
        prompt = (
            f"Analyze the multiple-choice question in the image carefully.\n"
            f"There are {num_options} options listed.\n"
            "Identify the correct answer based on your knowledge.\n"
            f"Return ONLY the index number (1–{num_options}). Just the integer, nothing else."
        )
        response    = generate_content_with_fallback([prompt, image])
        answer_text = response.text.strip()
        logger.info(f"🤖 Gemini says: {answer_text}")
        index = int(answer_text)
        if 1 <= index <= num_options:
            return index
        logger.error(f"❌ Invalid option index: {index}")
        return None
    except Exception as e:
        logger.error(f"❌ Gemini error: {e}")
        return None


def get_correct_option_index_with_context(
    context_image_path: str,
    question_image_path: str,
    num_options: int = 4,
) -> Optional[int]:
    """Two-image mode — for comprehension-based MCQs."""
    try:
        context_img  = Image.open(context_image_path)
        question_img = Image.open(question_image_path)
        prompt = (
            "Analyze the context (first image) and question (second image) carefully.\n"
            f"There are {num_options} options listed in the question image.\n"
            "Identify the correct answer based on the context.\n"
            f"Return ONLY the index number (1–{num_options}). Just the integer, nothing else."
        )
        response    = generate_content_with_fallback([prompt, context_img, question_img])
        answer_text = response.text.strip()
        logger.info(f"🤖 Gemini says: {answer_text}")
        index = int(answer_text)
        if 1 <= index <= num_options:
            return index
        logger.error(f"❌ Invalid option index: {index}")
        return None
    except Exception as e:
        logger.error(f"❌ Gemini error: {e}")
        return None