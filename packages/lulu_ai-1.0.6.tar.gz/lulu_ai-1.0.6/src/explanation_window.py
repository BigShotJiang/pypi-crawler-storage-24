import tkinter as tk
from tkinter import scrolledtext
import ctypes
import threading
from logger_setup import logger
import settings_manager

class ExplanationWindow:
    def __init__(self, master=None):
        if master:
            self.root = tk.Toplevel(master)
        else:
            self.root = tk.Tk()
            
        self.root.title("Code Explanation")
        
        # Load size from settings
        settings = settings_manager.load_settings()
        width = settings['window_size']['explanation_width']
        height = settings['window_size']['explanation_height']
        self.root.geometry(f"{width}x{height}")
        
        self.root.configure(bg='#1e1e1e') 
        self.root.attributes("-topmost", True)
        self.root.attributes("-alpha", 0.85)
        self.root.overrideredirect(True) 
        
        self.text_area = tk.Text(
            self.root, 
            wrap=tk.WORD, 
            font=("Arial", 14),
            bg="#2d2d2d", 
            fg="#e0e0e0", 
            insertbackground='white', 
            selectbackground='#404040', 
            highlightthickness=0,
            borderwidth=0,
            padx=15, 
            pady=15
        )
        self.text_area.pack(expand=True, fill='both', padx=5, pady=5)
        
        self.apply_hidden_affinity()
        self.hide_from_taskbar()
        
        self.root.withdraw()
        self.is_visible = False

    def set_text(self, text):
        self.text_area.delete("1.0", tk.END)
        self.text_area.insert("1.0", text)
        self.show_window()

    def hide_from_taskbar(self):
        try:
            self.root.update()
            hwnd = ctypes.windll.user32.GetParent(self.root.winfo_id())
            if hwnd == 0:
                hwnd = self.root.winfo_id()
            
            GWL_EXSTYLE = -20
            WS_EX_TOOLWINDOW = 0x00000080
            WS_EX_APPWINDOW = 0x00040000

            style = ctypes.windll.user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
            style = style | WS_EX_TOOLWINDOW
            style = style & ~WS_EX_APPWINDOW
            
            ctypes.windll.user32.SetWindowLongW(hwnd, GWL_EXSTYLE, style)
        except Exception as e:
            logger.error(f"❌ Error hiding explanation from taskbar: {e}")

    def apply_hidden_affinity(self):
        try:
            WDA_EXCLUDEFROMCAPTURE = 0x00000011
            self.root.update()
            hwnd = ctypes.windll.user32.GetParent(self.root.winfo_id())
            if hwnd == 0:
                hwnd = self.root.winfo_id()
            ctypes.windll.user32.SetWindowDisplayAffinity(hwnd, WDA_EXCLUDEFROMCAPTURE)
        except Exception as e:
            logger.error(f"❌ Error setting explanation window affinity: {e}")

    def toggle(self):
        if self.is_visible:
            self.hide_window()
        else:
            self.show_window()

    def show_window(self):
        self.root.deiconify()
        self.is_visible = True
        self.root.attributes("-topmost", True)
        self.text_area.focus_set()

    def hide_window(self):
        self.root.withdraw()
        self.is_visible = False

    def move(self, dx, dy):
        if not self.is_visible:
            return
        try:
            x = self.root.winfo_x()
            y = self.root.winfo_y()
            new_x = x + dx
            new_y = y + dy
            w = self.root.winfo_width()
            h = self.root.winfo_height()
            self.root.geometry(f"{w}x{h}+{new_x}+{new_y}")
        except Exception as e:
            logger.error(f"Error moving explanation window: {e}")

    def run(self):
        self.root.mainloop()

# Global instance
explanation_app = None

def show_explanation(text):
    if explanation_app:
        explanation_app.root.after(0, lambda: explanation_app.set_text(text))

def toggle_explanation():
    if explanation_app:
        explanation_app.root.after(0, explanation_app.toggle)

def move_explanation(dx, dy):
    if explanation_app:
        explanation_app.root.after(0, lambda: explanation_app.move(dx, dy))
