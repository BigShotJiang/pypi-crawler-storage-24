"""settings_manager.py

Settings are stored in LOCALAPPDATA/LuluApp/settings.json (Windows) or
~/.config/LuluApp/settings.json (macOS/Linux).

This means the app works from ANY directory — no project folder required.
First-time users just run `lulu start`, the settings panel opens automatically,
they enter their API keys once, and lulu start works from anywhere forever.
"""
import copy
import json
import os
import sys
import tempfile
import shutil


# ---------------------------------------------------------------------------
# App data directory — platform aware, always the same location
# ---------------------------------------------------------------------------

def _get_app_data_dir() -> str:
    if sys.platform == "win32":
        base = os.getenv("LOCALAPPDATA", os.path.expanduser("~"))
    elif sys.platform == "darwin":
        base = os.path.expanduser("~/Library/Application Support")
    else:
        base = os.path.expanduser("~/.config")
    app_dir = os.path.join(base, "LuluApp")
    os.makedirs(app_dir, exist_ok=True)
    return app_dir


APP_DATA_DIR         = _get_app_data_dir()
SETTINGS_FILE        = os.path.join(APP_DATA_DIR, "settings.json")
SETTINGS_BACKUP_FILE = os.path.join(APP_DATA_DIR, "settings.backup.json")

# BASE_DIR for screenshots and other data files — all go into app-data
# so nothing is written to the project/install folder
if getattr(sys, "frozen", False):
    BASE_DIR = os.path.dirname(sys.executable)
else:
    BASE_DIR = APP_DATA_DIR


# ---------------------------------------------------------------------------
# Default settings — API keys are empty, filled via settings panel
# ---------------------------------------------------------------------------

DEFAULT_SETTINGS = {
    # API keys — user enters these in the settings panel on first run
    "api_key":            "",   # Gemini primary
    "api_key_secondary":  "",   # Gemini secondary (failover)
    "groq_api_key":       "",   # Groq
    "openrouter_api_key": "",   # OpenRouter
    "model_name":         "gemini-2.5-flash",
    "hotkeys": {
        "capture_context":       "<ctrl>+<alt>+c",
        "capture_question":      "<ctrl>+<alt>+p",
        "clear_context":         "<ctrl>+<alt>+r",
        "exit":                  "<ctrl>+<alt>+e",
        "capture_subjective":    "<ctrl>+<alt>+s",
        "generate_response":     "<ctrl>+<alt>+g",
        "type_response":         "<ctrl>+<alt>+t",
        "resume_typing":         "<ctrl>+<alt>+z",
        "retry_subjective":      "<ctrl>+<alt>+k",
        "toggle_notes":          "<ctrl>+<alt>+n",
        "toggle_explanation":    "<ctrl>+<alt>+a",
        "explain_code":          "<ctrl>+<alt>+j",
        "control_panel":         "<ctrl>+<alt>+m",
        "step_by_step_solution": "<ctrl>+<alt>+o",
        "move_notes_up":         "<ctrl>+<alt>+<up>",
        "move_notes_down":       "<ctrl>+<alt>+<down>",
        "move_notes_left":       "<ctrl>+<alt>+<left>",
        "move_notes_right":      "<ctrl>+<alt>+<right>",
    },
    "features": {
        "notes_enabled":       True,
        "explanation_enabled": True,
    },
    "typing": {
        "min_delay": 0.03,
        "max_delay": 0.08,
    },
    "window_size": {
        "notes_width":        400,
        "notes_height":       300,
        "explanation_width":  500,
        "explanation_height": 400,
    },
    "first_run": True,
}


# ---------------------------------------------------------------------------
# Load
# ---------------------------------------------------------------------------

def load_settings() -> dict:
    """Load settings from app-data, falling back to backup then defaults."""
    settings = _try_load_file(SETTINGS_FILE)

    if settings is None and os.path.exists(SETTINGS_BACKUP_FILE):
        print("⚠️ settings.json unreadable — attempting backup restore...")
        settings = _try_load_file(SETTINGS_BACKUP_FILE)
        if settings is not None:
            print("✅ Settings restored from backup.")
            save_settings(settings)

    if settings is None:
        settings = copy.deepcopy(DEFAULT_SETTINGS)
        save_settings(settings)
        return settings

    # Deep merge so new keys added in updates always exist
    merged = copy.deepcopy(DEFAULT_SETTINGS)
    for key, value in settings.items():
        if isinstance(value, dict) and key in merged and isinstance(merged[key], dict):
            merged[key].update(value)
        else:
            merged[key] = value

    return merged


def _try_load_file(path: str) -> dict | None:
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Save — atomic write, crash-safe
# ---------------------------------------------------------------------------

def save_settings(settings: dict) -> None:
    try:
        dir_name = os.path.dirname(SETTINGS_FILE) or "."
        fd, tmp_path = tempfile.mkstemp(dir=dir_name, suffix=".tmp", prefix="settings_")
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(settings, f, indent=4)
        except Exception:
            os.unlink(tmp_path)
            raise
        if os.path.exists(SETTINGS_FILE) and _try_load_file(SETTINGS_FILE) is not None:
            shutil.copy2(SETTINGS_FILE, SETTINGS_BACKUP_FILE)
        shutil.move(tmp_path, SETTINGS_FILE)
    except Exception as e:
        print(f"Error saving settings: {e}")


# ---------------------------------------------------------------------------
# Global instance + helpers
# ---------------------------------------------------------------------------

current_settings = load_settings()


def get_setting(key, default=None):
    return current_settings.get(key, default)


def update_setting(key, value):
    current_settings[key] = value
    save_settings(current_settings)


def is_first_run() -> bool:
    """True if no Gemini API key has been set yet."""
    return not bool(current_settings.get("api_key", "").strip())


def mark_setup_complete() -> None:
    """Call this after the user saves their API keys."""
    current_settings["first_run"] = False
    save_settings(current_settings)