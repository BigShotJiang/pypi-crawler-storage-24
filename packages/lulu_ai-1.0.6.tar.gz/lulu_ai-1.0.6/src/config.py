"""config.py

Key resolution order (each setting tries the next if empty):
  1. settings.json (set via the settings panel — primary source)
  2. Environment variable / .env file (optional, for power users)

Fresh install works with zero files — user opens settings panel
(Ctrl+Alt+M) and enters their keys once. Done.
"""
import os
import sys

# Load .env as optional fallback — won't fail if file doesn't exist
try:
    from dotenv import load_dotenv
    from settings_manager import APP_DATA_DIR as _APP_DATA_DIR
    for _env_path in [
        os.path.join(_APP_DATA_DIR, ".env"),
        os.path.join(os.path.dirname(__file__), "..", ".env"),
        os.path.join(os.getcwd(), ".env"),
    ]:
        if os.path.exists(_env_path):
            load_dotenv(dotenv_path=_env_path)
            break
except Exception:
    pass

from settings_manager import current_settings, APP_DATA_DIR

# ---------------------------------------------------------------------------
# Directories — all inside app-data
# ---------------------------------------------------------------------------

SCREENSHOT_DIR = os.path.join(APP_DATA_DIR, "screenshots")
os.makedirs(SCREENSHOT_DIR, exist_ok=True)

SUBJECTIVE_SCREENSHOT_DIR = os.path.join(SCREENSHOT_DIR, "subjective")
os.makedirs(SUBJECTIVE_SCREENSHOT_DIR, exist_ok=True)

QUESTION_IMAGE_PATH = os.path.join(SCREENSHOT_DIR, "question.png")
CONTEXT_IMAGE_PATH  = os.path.join(SCREENSHOT_DIR, "context.png")
QUESTION_IMAGE_NAME = "question.png"
CONTEXT_IMAGE_NAME  = "context.png"
NOTES_FILE          = os.path.join(APP_DATA_DIR, "hidden_notes.txt")

# ---------------------------------------------------------------------------
# Gemini — settings panel first, .env fallback
# ---------------------------------------------------------------------------

API_KEY = (
    current_settings.get("api_key", "").strip()
    or os.environ.get("GEMINI_API_KEY_PRIMARY", "").strip()
    or os.environ.get("GEMINI_API_KEY", "").strip()
)

API_KEY_SECONDARY = (
    current_settings.get("api_key_secondary", "").strip()
    or os.environ.get("GEMINI_API_KEY_SECONDARY", "").strip()
)

MODEL_NAME = current_settings.get("model_name", "gemini-2.5-flash")

# ---------------------------------------------------------------------------
# Groq — settings panel first, env fallback
# ---------------------------------------------------------------------------

GROQ_API_KEY: str = (
    current_settings.get("groq_api_key", "").strip()
    or os.environ.get("GROQ_API_KEY", "").strip()
)
GROQ_BASE_URL:             str  = "https://api.groq.com/openai/v1"
USE_GROQ_FOR_EXPLANATION:  bool = True
USE_GROQ_FOR_CODE:         bool = True
GROQ_DEFAULT_MODEL:        str  = "llama-3.3-70b-versatile"
GROQ_EXPLANATION_FALLBACK: str  = "deepseek-r1-distill-llama-70b"

# ---------------------------------------------------------------------------
# OpenRouter — settings panel first, env fallback
# ---------------------------------------------------------------------------

OPENROUTER_API_KEY: str = (
    current_settings.get("openrouter_api_key", "").strip()
    or os.environ.get("OPENROUTER_API_KEY", "").strip()
)
OPENROUTER_BASE_URL:     str  = "https://openrouter.ai/api/v1"
USE_OPENROUTER_FOR_CODE: bool = True
OPENROUTER_CODE_MODEL:   str  = os.environ.get(
    "OPENROUTER_CODE_MODEL", "meta-llama/llama-3.3-70b-instruct:free"
)
OPENROUTER_CODE_FALLBACKS: list[str] = [
    "mistralai/devstral-2512:free",
    "xiaomi/mimo-v2-flash-309b:free",
]

# ---------------------------------------------------------------------------
# Hotkeys
# ---------------------------------------------------------------------------

CAPTURE_CONTEXT_HOTKEY       = current_settings["hotkeys"]["capture_context"]
CAPTURE_QUESTION_HOTKEY      = current_settings["hotkeys"]["capture_question"]
CLEAR_CONTEXT_HOTKEY         = current_settings["hotkeys"]["clear_context"]
EXIT_HOTKEY                  = current_settings["hotkeys"]["exit"]
CAPTURE_SUBJECTIVE_HOTKEY    = current_settings["hotkeys"]["capture_subjective"]
GENERATE_RESPONSE_HOTKEY     = current_settings["hotkeys"]["generate_response"]
TYPE_RESPONSE_HOTKEY         = current_settings["hotkeys"]["type_response"]
RESUME_TYPING_HOTKEY         = current_settings["hotkeys"]["resume_typing"]
RETRY_SUBJECTIVE_HOTKEY      = current_settings["hotkeys"]["retry_subjective"]
TOGGLE_NOTES_HOTKEY          = current_settings["hotkeys"]["toggle_notes"]
TOGGLE_EXPLANATION_HOTKEY    = current_settings["hotkeys"]["toggle_explanation"]
CONTROL_PANEL_HOTKEY         = current_settings["hotkeys"]["control_panel"]
STEP_BY_STEP_SOLUTION_HOTKEY = current_settings["hotkeys"]["step_by_step_solution"]
EXPLAIN_CODE_HOTKEY          = current_settings["hotkeys"]["explain_code"]
MOVE_NOTES_UP_HOTKEY    = current_settings["hotkeys"].get("move_notes_up",    "<ctrl>+<alt>+<up>")
MOVE_NOTES_DOWN_HOTKEY  = current_settings["hotkeys"].get("move_notes_down",  "<ctrl>+<alt>+<down>")
MOVE_NOTES_LEFT_HOTKEY  = current_settings["hotkeys"].get("move_notes_left",  "<ctrl>+<alt>+<left>")
MOVE_NOTES_RIGHT_HOTKEY = current_settings["hotkeys"].get("move_notes_right", "<ctrl>+<alt>+<right>")

# ---------------------------------------------------------------------------
# Typing
# ---------------------------------------------------------------------------

TYPING_DELAY_MIN = current_settings.get("typing", {}).get("min_delay", 0.03)
TYPING_DELAY_MAX = current_settings.get("typing", {}).get("max_delay", 0.08)