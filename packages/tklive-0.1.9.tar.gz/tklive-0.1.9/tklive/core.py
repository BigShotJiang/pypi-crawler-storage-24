import os
import sys
import time
import tempfile
import traceback
import inspect
import tkinter as tk

from .state import save_state, restore_state
from .serializer import save_script_state, load_script_state

try:
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler
    HAS_WATCHDOG = True
except ImportError:
    HAS_WATCHDOG = False


class _FileHandler(FileSystemEventHandler):
    def __init__(self, paths, callback):
        self._paths = [os.path.abspath(p) for p in paths]
        self._callback = callback
        self._last = 0

    def on_modified(self, event):
        if not event.is_directory and event.src_path.endswith(".py"):
            if os.path.abspath(event.src_path) in self._paths:
                now = time.time()
                if now - self._last > 0.5:
                    self._last = now
                    self._callback()


def _cancel_all_after(root: tk.Tk):
    try:
        after_ids = root.tk.call("after", "info")
        if after_ids:
            for after_id in root.tk.splitlist(after_ids):
                try:
                    root.after_cancel(after_id)
                except Exception:
                    pass
    except Exception:
        pass


def _patch_customtkinter(root):
    patches = []
    try:
        import customtkinter as _ctk
        original_ctk = _ctk.CTk
        class _FakeCTk:
            def __new__(cls, *args, **kwargs):
                return root
        _ctk.CTk = _FakeCTk
        patches.append((_ctk, 'CTk', original_ctk))

        try:
            from customtkinter.windows.widgets.appearance_mode import appearance_mode_tracker as _amt
            original = _amt.AppearanceModeTracker.get_tk_root_of_widget
            @classmethod
            def _p1(cls, widget): return root
            _amt.AppearanceModeTracker.get_tk_root_of_widget = _p1
            patches.append((_amt.AppearanceModeTracker, 'get_tk_root_of_widget', original))
        except Exception:
            pass

        try:
            from customtkinter.windows.widgets.scaling import scaling_tracker as _st
            original = _st.ScalingTracker.get_window_root_of_widget
            @classmethod
            def _p2(cls, widget): return root
            _st.ScalingTracker.get_window_root_of_widget = _p2
            patches.append((_st.ScalingTracker, 'get_window_root_of_widget', original))
        except Exception:
            pass

    except ImportError:
        pass
    return patches


def _unpatch(patches):
    for obj, attr, original in patches:
        try:
            setattr(obj, attr, original)
        except Exception:
            pass


_TEMP_STATE_FILE = os.path.join(tempfile.gettempdir(), "tklive_script_state.json")
_script_globals = {}


def live(root: tk.Tk, script_path: str, watch_files: list = None, auto: bool = True):
    global _script_globals

    abs_path = os.path.abspath(script_path)

    all_files = [abs_path]
    if watch_files:
        for f in watch_files:
            p = os.path.abspath(f)
            if p not in all_files:
                all_files.append(p)

    caller_frame = inspect.stack()[1][0]
    _script_globals = caller_frame.f_globals

    def do_reload():
        try:
            save_script_state(_script_globals, _TEMP_STATE_FILE)
            root.after(0, _do_rebuild)
        except Exception:
            traceback.print_exc()

    def _do_rebuild():
        global _script_globals

        # Schritt 1: Alle after() Callbacks canceln
        _cancel_all_after(root)

        # Schritt 2: Alle Widgets zerstören
        for w in root.winfo_children():
            try:
                w.destroy()
            except Exception:
                pass

        # Schritt 3: root komplett zurücksetzen
        try:
            root.configure(bg="")
        except Exception:
            pass

        # Schritt 4: Gespeicherten State laden
        saved_data = load_script_state(_TEMP_STATE_FILE)

        script_globals = {
            "__file__": abs_path,
            "__name__": "__main__",
            "__builtins__": __builtins__,
        }
        script_globals.update(saved_data)

        # Patches setzen
        import tkinter as _tk
        original_tk = _tk.Tk
        class _FakeTk:
            def __new__(cls, *args, **kwargs):
                return root
        _tk.Tk = _FakeTk

        # ttk.Style patch
        original_style_init = None
        try:
            original_style_init = _tk.ttk.Style.__init__
            _root_ref = root
            def _patched_style_init(self_s, master=None):
                original_style_init(self_s, _root_ref)
            _tk.ttk.Style.__init__ = _patched_style_init
        except Exception:
            pass

        ctk_patches = _patch_customtkinter(root)

        original_mainloop = root.mainloop
        root.mainloop = lambda: None

        import tklive as _tklive
        original_live = _tklive.live
        _tklive.live = lambda *a, **kw: None

        error = None
        try:
            with open(abs_path, "r", encoding="utf-8") as f:
                source = f.read()
            exec(compile(source, abs_path, "exec"), script_globals)
            _script_globals = script_globals

            # Nach exec: root neu zeichnen erzwingen
            root.update_idletasks()

        except Exception:
            error = traceback.format_exc()
        finally:
            _tk.Tk = original_tk
            if original_style_init:
                try:
                    _tk.ttk.Style.__init__ = original_style_init
                except Exception:
                    pass
            root.mainloop = original_mainloop
            _tklive.live = original_live
            _unpatch(ctk_patches)

        if error:
            print(f"\n[tklive] Reload Error:\n{error}")

    root.bind_all("<Control-r>", lambda e: do_reload())

    if auto:
        if not HAS_WATCHDOG:
            return

        watched_folders = set(os.path.dirname(f) for f in all_files)
        handler = _FileHandler(all_files, do_reload)
        observer = Observer()
        for folder in watched_folders:
            observer.schedule(handler, folder, recursive=False)
        observer.daemon = True
        observer.start()

        def on_close():
            observer.stop()
            try:
                os.remove(_TEMP_STATE_FILE)
            except Exception:
                pass
            root.destroy()

        root.protocol("WM_DELETE_WINDOW", on_close)
