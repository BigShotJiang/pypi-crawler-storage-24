"""
Automatische Serialisierung von Script-Variablen vor dem Reload.
"""

import json
import os
import tkinter as tk


_SKIP_MODULES = {
    "tkinter", "customtkinter", "tklive", "watchdog",
    "sqlite3", "pymysql", "psycopg2", "PIL", "cv2",
}


def _is_skippable(key: str, value) -> bool:
    if key.startswith("_"):
        return True
    import types
    if isinstance(value, (type, types.ModuleType, types.FunctionType, types.MethodType)):
        return True
    try:
        if isinstance(value, (tk.BaseWidget, tk.Tk)):
            return True
    except Exception:
        pass
    type_mod = type(value).__module__ or ""
    for mod in _SKIP_MODULES:
        if type_mod.startswith(mod):
            return True
    return False


def _try_serialize(value, _seen=None):
    """Versucht einen Wert zu serialisieren. Gibt (True, wert) oder (False, None) zurück."""
    if _seen is None:
        _seen = set()

    # Zirkuläre Referenzen verhindern
    obj_id = id(value)
    if obj_id in _seen:
        return False, None

    if value is None:
        return True, None
    if isinstance(value, bool):
        return True, value
    if isinstance(value, (int, float)):
        return True, value
    if isinstance(value, str):
        return True, value

    # Ab hier: komplexe Typen in _seen eintragen
    _seen = _seen | {obj_id}

    if isinstance(value, (list, tuple)):
        result = []
        for item in value:
            ok, v = _try_serialize(item, _seen)
            if ok:
                result.append(v)
            # nicht serialisierbare Items einfach überspringen
        return True, result

    if isinstance(value, dict):
        result = {}
        for k, v in value.items():
            if not isinstance(k, str):
                continue
            ok, sv = _try_serialize(v, _seen)
            if ok:
                result[k] = sv
        return True, result

    if isinstance(value, set):
        result = []
        for item in value:
            ok, v = _try_serialize(item, _seen)
            if ok:
                result.append(v)
        return True, {"__set__": result}

    # Klassen-Instanzen
    if hasattr(value, "__dict__") and not isinstance(value, type):
        result = {}
        for attr_key, attr_val in value.__dict__.items():
            if _is_skippable(attr_key, attr_val):
                continue
            ok, sv = _try_serialize(attr_val, _seen)
            if ok:
                result[attr_key] = sv
        if result:
            return True, {"__obj__": type(value).__name__, "__attrs__": result}

    return False, None


def save_script_state(script_globals: dict, temp_path: str):
    state = {}
    for key, value in script_globals.items():
        if _is_skippable(key, value):
            continue
        try:
            ok, serialized = _try_serialize(value)
            if ok:
                state[key] = serialized
        except Exception:
            pass  # einzelne Fehler still überspringen

    try:
        with open(temp_path, "w", encoding="utf-8") as f:
            json.dump(state, f, ensure_ascii=False, indent=2)
    except Exception as e:
        print(f"[tklive] State speichern fehlgeschlagen: {e}")


def load_script_state(temp_path: str) -> dict:
    if not os.path.exists(temp_path):
        return {}
    try:
        with open(temp_path, "r", encoding="utf-8") as f:
            raw = json.load(f)
        return _deserialize_dict(raw)
    except Exception as e:
        print(f"[tklive] State laden fehlgeschlagen: {e}")
        return {}


def _deserialize_dict(data: dict) -> dict:
    return {k: _deserialize_value(v) for k, v in data.items()}


def _deserialize_value(value):
    if isinstance(value, dict):
        if "__set__" in value:
            return set(_deserialize_value(i) for i in value["__set__"])
        if "__obj__" in value and "__attrs__" in value:
            from types import SimpleNamespace
            obj = SimpleNamespace()
            for k, v in value["__attrs__"].items():
                setattr(obj, k, _deserialize_value(v))
            return obj
        return {k: _deserialize_value(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_deserialize_value(i) for i in value]
    return value
