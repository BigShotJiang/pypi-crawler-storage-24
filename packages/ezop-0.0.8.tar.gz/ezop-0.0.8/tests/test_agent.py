from unittest.mock import patch, MagicMock
import pytest
from ezop import Agent
from ezop.models import AgentModel, AgentVersion, AgentRun, Event


AGENT_RESP = {"success": True, "error": None, "data": {
    "id": "agent-uuid-123",
    "name": "support-bot",
    "owner": "growth-team",
    "runtime": "langchain",
    "description": "Handles support tickets",
    "default_permissions": ["read:tickets"],
}}

VERSION_RESP = {"success": True, "error": None, "data": {
    "id": "version-uuid-456",
    "version": "v0.3",
    "permissions": ["read:tickets", "write:replies"],
    "changelog": "Initial release",
}}

RUN_RESP = {"success": True, "error": None, "data": {
    "id": "run-uuid-789",
    "status": "running",
}}


def make_agent():
    with patch("ezop.client.EzopClient.register_agent", return_value=AGENT_RESP), \
         patch("ezop.client.EzopClient.create_version", return_value=VERSION_RESP), \
         patch("ezop.client.EzopClient.start_run", return_value=RUN_RESP):
        return Agent.init(
            name="support-bot",
            owner="growth-team",
            version="v0.3",
            runtime="langchain",
            description="Handles support tickets",
            default_permissions=["read:tickets"],
            permissions=["read:tickets", "write:replies"],
            changelog="Initial release",
        )


class TestAgentInit:
    def test_returns_agent_instance(self):
        agent = make_agent()
        assert isinstance(agent, Agent)

    def test_model_populated(self):
        agent = make_agent()
        assert agent.model.id == "agent-uuid-123"
        assert agent.model.name == "support-bot"
        assert agent.model.owner == "growth-team"
        assert agent.model.runtime == "langchain"
        assert agent.model.description == "Handles support tickets"
        assert agent.model.default_permissions == ["read:tickets"]

    def test_version_populated(self):
        agent = make_agent()
        assert agent.version.id == "version-uuid-456"
        assert agent.version.agent_id == "agent-uuid-123"
        assert agent.version.version == "v0.3"
        assert agent.version.permissions == ["read:tickets", "write:replies"]
        assert agent.version.changelog == "Initial release"

    def test_run_started_on_init(self):
        agent = make_agent()
        assert agent.current_run is not None
        assert agent.current_run.id == "run-uuid-789"
        assert agent.current_run.status == "running"
        assert agent.current_run.agent_id == "agent-uuid-123"
        assert agent.current_run.version_id == "version-uuid-456"

    def test_calls_register_agent_with_correct_payload(self):
        with patch("ezop.client.EzopClient.register_agent", return_value=AGENT_RESP) as mock_register, \
             patch("ezop.client.EzopClient.create_version", return_value=VERSION_RESP), \
             patch("ezop.client.EzopClient.start_run", return_value=RUN_RESP):
            Agent.init(name="support-bot", owner="growth-team", version="v0.3", runtime="langchain",
                       description="Handles support tickets", default_permissions=["read:tickets"])
            mock_register.assert_called_once_with({
                "name": "support-bot",
                "owner": "growth-team",
                "runtime": "langchain",
                "description": "Handles support tickets",
                "default_permissions": ["read:tickets"],
            })

    def test_calls_create_version_with_correct_payload(self):
        with patch("ezop.client.EzopClient.register_agent", return_value=AGENT_RESP), \
             patch("ezop.client.EzopClient.create_version", return_value=VERSION_RESP) as mock_version, \
             patch("ezop.client.EzopClient.start_run", return_value=RUN_RESP):
            Agent.init(name="support-bot", owner="growth-team", version="v0.3", runtime="langchain",
                       permissions=["read:tickets"], changelog="Initial release")
            mock_version.assert_called_once_with("agent-uuid-123", {
                "version": "v0.3",
                "permissions": ["read:tickets"],
                "changelog": "Initial release",
            })

    def test_calls_start_run_with_correct_args(self):
        with patch("ezop.client.EzopClient.register_agent", return_value=AGENT_RESP), \
             patch("ezop.client.EzopClient.create_version", return_value=VERSION_RESP), \
             patch("ezop.client.EzopClient.start_run", return_value=RUN_RESP) as mock_run:
            Agent.init(name="support-bot", owner="growth-team", version="v0.3", runtime="langchain")
            mock_run.assert_called_once_with("agent-uuid-123", "version-uuid-456")

    def test_optional_fields_default_to_empty(self):
        with patch("ezop.client.EzopClient.register_agent", return_value={**AGENT_RESP, "data": {**AGENT_RESP["data"], "default_permissions": None}}), \
             patch("ezop.client.EzopClient.create_version", return_value={**VERSION_RESP, "data": {**VERSION_RESP["data"], "permissions": None}}), \
             patch("ezop.client.EzopClient.start_run", return_value=RUN_RESP):
            agent = Agent.init(name="support-bot", owner="growth-team", version="v0.3", runtime="langchain")
            assert agent.model.default_permissions == []
            assert agent.version.permissions == []

    def test_raises_on_api_error(self):
        with patch("ezop.client.EzopClient.register_agent", side_effect=Exception("Ezop API error: 401")):
            with pytest.raises(Exception, match="Ezop API error"):
                Agent.init(name="support-bot", owner="growth-team", version="v0.3", runtime="langchain")


class TestAgentClose:
    def test_close_updates_status(self):
        agent = make_agent()
        end_resp = {"success": True, "error": None, "data": {"status": "success", "total_tokens": 500, "total_cost": 0.01, "metadata": None}}
        with patch("ezop.client.EzopClient.end_run", return_value=end_resp):
            run = agent.close(status="success", total_tokens=500, total_cost=0.01)
        assert run.status == "success"
        assert run.total_tokens == 500
        assert run.total_cost == 0.01

    def test_close_failed_status(self):
        agent = make_agent()
        end_resp = {"success": True, "error": None, "data": {"status": "failed", "total_tokens": None, "total_cost": None, "metadata": {"error": "timeout"}, "message": "Rate limit exceeded"}}
        with patch("ezop.client.EzopClient.end_run", return_value=end_resp):
            run = agent.close(status="failed", metadata={"error": "timeout"}, message="Rate limit exceeded")
        assert run.status == "failed"
        assert run.metadata == {"error": "timeout"}
        assert run.message == "Rate limit exceeded"

    def test_close_calls_client_with_correct_args(self):
        agent = make_agent()
        end_resp = {"success": True, "error": None, "data": {"status": "success", "total_tokens": 100, "total_cost": 0.005, "metadata": {"k": "v"}, "message": None}}
        with patch("ezop.client.EzopClient.end_run", return_value=end_resp) as mock_end:
            agent.close(status="success", total_tokens=100, total_cost=0.005, metadata={"k": "v"})
            mock_end.assert_called_once_with(
                "run-uuid-789",
                status="success",
                total_tokens=100,
                total_cost=0.005,
                metadata={"k": "v"},
                message=None,
            )

    def test_close_without_run_raises(self):
        agent = make_agent()
        agent.current_run = None
        with pytest.raises(RuntimeError, match="No active run"):
            agent.close()


class TestAgentEmit:
    def test_emit_returns_event(self):
        agent = make_agent()
        with patch("ezop.client.EzopClient.emit_event", return_value={}):
            event = agent.emit(name="llm.call", category="llm")
        assert isinstance(event, Event)
        assert event.run_id == "run-uuid-789"
        assert event.name == "llm.call"
        assert event.category == "llm"

    def test_emit_generates_event_id(self):
        agent = make_agent()
        with patch("ezop.client.EzopClient.emit_event", return_value={}):
            event = agent.emit(name="llm.call", category="llm")
        assert event.id is not None

    def test_emit_sets_timestamp(self):
        agent = make_agent()
        with patch("ezop.client.EzopClient.emit_event", return_value={}):
            event = agent.emit(name="llm.call", category="llm")
        assert event.timestamp is not None

    def test_emit_optional_fields(self):
        agent = make_agent()
        with patch("ezop.client.EzopClient.emit_event", return_value={}):
            event = agent.emit(
                name="llm.call",
                category="llm",
                span_id="span-123",
                status="ok",
                input={"prompt": "hello"},
                output={"text": "hi"},
                metadata={"model": "claude"},
                error=None,
            )
        assert event.span_id == "span-123"
        assert event.status == "ok"
        assert event.input == {"prompt": "hello"}
        assert event.output == {"text": "hi"}
        assert event.metadata == {"model": "claude"}

    def test_emit_span_id_optional(self):
        agent = make_agent()
        with patch("ezop.client.EzopClient.emit_event", return_value={}):
            event = agent.emit(name="llm.call", category="llm")
        assert event.span_id is None

    def test_emit_calls_client_with_correct_payload(self):
        agent = make_agent()
        with patch("ezop.client.EzopClient.emit_event", return_value={}) as mock_emit:
            agent.emit(
                name="llm.call",
                category="llm",
                span_id="span-123",
                status="ok",
                input={"prompt": "hello"},
                output={"text": "hi"},
                metadata={"model": "claude"},
                error="oops",
            )
        call_args = mock_emit.call_args
        assert call_args[0][0] == "run-uuid-789"
        body = call_args[0][1]
        assert body["name"] == "llm.call"
        assert body["category"] == "llm"
        assert body["span_id"] == "span-123"
        assert body["status"] == "ok"
        assert body["input"] == {"prompt": "hello"}
        assert body["output"] == {"text": "hi"}
        assert body["metadata"] == {"model": "claude"}
        assert body["error"] == "oops"

    def test_emit_omits_none_fields_from_payload(self):
        agent = make_agent()
        with patch("ezop.client.EzopClient.emit_event", return_value={}) as mock_emit:
            agent.emit(name="llm.call", category="llm")
        body = mock_emit.call_args[0][1]
        assert "span_id" not in body
        assert "status" not in body
        assert "input" not in body
        assert "output" not in body
        assert "metadata" not in body
        assert "error" not in body

    def test_emit_without_run_raises(self):
        agent = make_agent()
        agent.current_run = None
        with pytest.raises(RuntimeError, match="No active run"):
            agent.emit(name="llm.call", category="llm")

    def test_emit_uses_current_span_as_parent(self):
        agent = make_agent()
        agent.current_run._current_span_id = "active-span-id"
        with patch("ezop.client.EzopClient.emit_event", return_value={}) as mock_emit:
            event = agent.emit(name="decision", category="reasoning")
        assert event.parent_id == "active-span-id"
        assert mock_emit.call_args[0][1]["parent_id"] == "active-span-id"

    def test_emit_explicit_parent_id_overrides_current_span(self):
        agent = make_agent()
        agent.current_run._current_span_id = "active-span-id"
        with patch("ezop.client.EzopClient.emit_event", return_value={}):
            event = agent.emit(name="decision", category="reasoning", parent_id="explicit-parent")
        assert event.parent_id == "explicit-parent"


class TestAgentSpan:
    def test_span_emits_two_events(self):
        agent = make_agent()
        with patch("ezop.client.EzopClient.emit_event", return_value={}) as mock_emit:
            with agent.span("llm.call", category="llm"):
                pass
        assert mock_emit.call_count == 2

    def test_span_opening_event_is_in_progress(self):
        agent = make_agent()
        with patch("ezop.client.EzopClient.emit_event", return_value={}) as mock_emit:
            with agent.span("llm.call", category="llm"):
                pass
        opening = mock_emit.call_args_list[0][0][1]
        assert opening["status"] == "in_progress"

    def test_span_closing_event_is_ok_on_success(self):
        agent = make_agent()
        with patch("ezop.client.EzopClient.emit_event", return_value={}) as mock_emit:
            with agent.span("llm.call", category="llm"):
                pass
        closing = mock_emit.call_args_list[1][0][1]
        assert closing["status"] == "ok"

    def test_span_closing_event_is_error_on_exception(self):
        agent = make_agent()
        with patch("ezop.client.EzopClient.emit_event", return_value={}) as mock_emit:
            with pytest.raises(ValueError):
                with agent.span("llm.call", category="llm"):
                    raise ValueError("bad input")
        closing = mock_emit.call_args_list[1][0][1]
        assert closing["status"] == "error"
        assert closing["error"] == "bad input"

    def test_span_does_not_suppress_exception(self):
        agent = make_agent()
        with patch("ezop.client.EzopClient.emit_event", return_value={}):
            with pytest.raises(RuntimeError, match="boom"):
                with agent.span("llm.call", category="llm"):
                    raise RuntimeError("boom")

    def test_span_both_events_share_span_id(self):
        agent = make_agent()
        with patch("ezop.client.EzopClient.emit_event", return_value={}) as mock_emit:
            with agent.span("llm.call", category="llm"):
                pass
        opening = mock_emit.call_args_list[0][0][1]
        closing = mock_emit.call_args_list[1][0][1]
        assert opening["span_id"] == closing["span_id"]

    def test_span_closing_event_includes_output(self):
        agent = make_agent()
        with patch("ezop.client.EzopClient.emit_event", return_value={}) as mock_emit:
            with agent.span("llm.call", category="llm") as s:
                s.set_output({"text": "hello"})
        closing = mock_emit.call_args_list[1][0][1]
        assert closing["output"] == {"text": "hello"}

    def test_span_sets_current_span_id_during_execution(self):
        agent = make_agent()
        captured = {}
        with patch("ezop.client.EzopClient.emit_event", return_value={}):
            with agent.span("llm.call", category="llm") as s:
                captured["during"] = agent.current_run._current_span_id
        assert captured["during"] == s.span_id

    def test_span_restores_current_span_id_after_exit(self):
        agent = make_agent()
        agent.current_run._current_span_id = "outer-span"
        with patch("ezop.client.EzopClient.emit_event", return_value={}):
            with agent.span("llm.call", category="llm"):
                pass
        assert agent.current_run._current_span_id == "outer-span"

    def test_nested_spans_set_parent_id(self):
        agent = make_agent()
        with patch("ezop.client.EzopClient.emit_event", return_value={}) as mock_emit:
            with agent.span("outer", category="llm") as outer:
                with agent.span("inner", category="tool") as inner:
                    pass
        inner_opening = mock_emit.call_args_list[1][0][1]
        assert inner_opening["parent_id"] == outer.span_id
        assert inner_opening["span_id"] == inner.span_id

    def test_nested_spans_restore_parent_on_exit(self):
        agent = make_agent()
        with patch("ezop.client.EzopClient.emit_event", return_value={}):
            with agent.span("outer", category="llm") as outer:
                with agent.span("inner", category="tool"):
                    pass
                assert agent.current_run._current_span_id == outer.span_id

    def test_span_without_run_raises(self):
        agent = make_agent()
        agent.current_run = None
        with pytest.raises(RuntimeError, match="No active run"):
            with agent.span("llm.call", category="llm"):
                pass
