def compute_calibration() -> dict:
    return {
        "status": "ok",
        "calibration": {
            "value": 1.0,
            "unit": "ratio",
        },
    }
