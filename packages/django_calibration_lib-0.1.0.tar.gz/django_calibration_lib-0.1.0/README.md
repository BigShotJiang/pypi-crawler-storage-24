# django-calibration-lib

Minimal Python package intended to be installed in Django projects.

## Install

```bash
pip install django-calibration-lib
```

## Usage

```python
from django_calibration_lib import compute_calibration

result = compute_calibration()
```

`result` is a JSON-compatible Python dictionary.

## Publish

Build distributions:

```bash
python -m build
```

Upload with Twine:

```bash
twine upload dist/*
```
