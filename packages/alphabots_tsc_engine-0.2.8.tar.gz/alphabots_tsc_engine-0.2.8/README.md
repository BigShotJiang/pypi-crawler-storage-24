# alphabots-tsc-engine

A high-performance columnar time-series data compression engine.

## Overview
Working with large datasets (especially financial data) can quickly become a bottleneck due to massive file sizes, slow read/write speeds, and high memory usage. Traditional formats like Parquet or CSV are great general-purpose tools, but they often struggle to handle extreme volumes of time-series data efficiently.

`alphabots-tsc-engine` provides a custom-built compression format (`.tsc`) designed to solve these issues. It achieves smaller file sizes, faster processing, and significantly lower memory overhead compared to standard formats.

### Key Benefits
- **Extreme Compression**: Compresses time-series data to a fraction of the size of standard Parquet files.
- **Low Memory Footprint**: Streams data chunk-by-chunk under the hood, meaning you can process datasets that are much larger than your available RAM.
- **Hardware Profiles**: Choose between `max_speed` (for rapid loading using all CPU cores), `max_compression` (for archival storage), or `balanced` (for standard usage).
- **Easy to Use**: A simple Python API and CLI tool that works directly with your existing Pandas, DuckDB, Parquet, or CSV workflows.

## Installation

You can install the pre-compiled extension directly via pip (once published):

```bash
pip install alphabots-tsc-engine
```

## Quick Start

### Using the Command Line Interface (CLI)

You can easily convert existing `.parquet`, `.duckdb`, or `.csv` files into the optimized `.tsc` format:

```bash
# Compress a Parquet file (default balanced profile)
tsc-engine compress data.parquet data.tsc

# Compress a DuckDB database (loads first table by default)
tsc-engine compress data.duckdb data.tsc

# Compress with maximum compression for archival
tsc-engine compress data.parquet data.tsc --profile max_compression

# Decompress back to DuckDB
tsc-engine decompress data.tsc restored_data.duckdb
```

### Using the Python API

Integrate the engine directly into your Python scripts:

```python
import pandas as pd
from alphabots_tsc_engine import TSCompressor, TSDecompressor

# Load your dataframe
df = pd.read_parquet('data.parquet')

# Compress
comp = TSCompressor(profile='balanced')
comp.compress_dataframe(df, 'data.tsc')

# Decompress
decomp = TSDecompressor(profile='balanced')
df_restored = decomp.decompress_dataframe('data.tsc')
```

## Architecture Summary
Under the hood, `alphabots-tsc-engine` is powered by a compiled **Rust** core. This ensures that the heavy lifting (data parsing, memory allocation, and compression) is done safely and at maximum speed, bypassing Python's Global Interpreter Lock (GIL). It leverages zero-copy memory buffers via Apache Arrow and Polars, meaning data is handed off to Python instantly without unnecessary duplication.
