import argparse
import pandas as pd
import time
import os
from .compressor import TSCompressor, TSDecompressor

def main():
    parser = argparse.ArgumentParser(description="High-Frequency Time-Series Compression CLI")
    parser.add_argument('action', choices=['compress', 'decompress'], help="Action to perform")
    parser.add_argument('input', help="Input file path")
    parser.add_argument('output', help="Output file path")
    parser.add_argument('--profile', choices=['balanced', 'max_speed', 'max_compression'], 
                        default='balanced', help="Compression profile to use (default: balanced)")
    parser.add_argument('--table', type=str, help="Table name to read from DuckDB (optional, defaults to first table)")
    
    args = parser.parse_args()
    
    if args.action == 'compress':
        print(f"Reading {args.input}...")
        t0 = time.time()
        
        if args.input.endswith('.parquet'):
            df = pd.read_parquet(args.input)
        elif args.input.endswith('.csv'):
            df = pd.read_csv(args.input)
        elif args.input.endswith('.duckdb'):
            import duckdb
            conn = duckdb.connect(args.input, read_only=True)
            if args.table:
                df = conn.execute(f"SELECT * FROM {args.table}").df()
            else:
                tables = conn.execute("SHOW TABLES").fetchall()
                if not tables:
                    raise ValueError("No tables found in the DuckDB file.")
                table_name = tables[0][0]
                print(f"No table specified, using first table: {table_name}")
                df = conn.execute(f"SELECT * FROM {table_name}").df()
            conn.close()
        else:
            raise ValueError("Input format not supported. Use .parquet, .csv, or .duckdb")
            
        t1 = time.time()
        print(f"Loaded {len(df)} rows in {t1-t0:.3f}s")
        
        print(f"Compressing to {args.output} using profile '{args.profile}'...")
        t0 = time.time()
        comp = TSCompressor(profile=args.profile)
        comp.compress_dataframe(df, args.output)
        t1 = time.time()
        
        orig_size = os.path.getsize(args.input) / (1024 * 1024)
        new_size = os.path.getsize(args.output) / (1024 * 1024)
        
        print(f"Compression complete in {t1-t0:.3f}s")
        print(f"Size reduction: {orig_size:.2f} MB -> {new_size:.2f} MB ({(1 - new_size/orig_size)*100:.1f}%)")
        
    elif args.action == 'decompress':
        print(f"Decompressing {args.input} with profile '{args.profile}'...")
        t0 = time.time()
        
        decomp = TSDecompressor(profile=args.profile)
        df = decomp.decompress_dataframe(args.input)
        
        t1 = time.time()
        print(f"Decompressed {len(df)} rows in {t1-t0:.3f}s")
        
        print(f"Saving to {args.output}...")
        t0 = time.time()
        if args.output.endswith('.parquet'):
            df.to_parquet(args.output)
        elif args.output.endswith('.csv'):
            df.to_csv(args.output, index=False)
        elif args.output.endswith('.duckdb'):
            import duckdb
            conn = duckdb.connect(args.output)
            table_name = args.table if args.table else "data"
            conn.execute(f"CREATE TABLE {table_name} AS SELECT * FROM df")
            conn.close()
            print(f"Data saved to table '{table_name}' in DuckDB")
        else:
            raise ValueError("Output format not supported. Use .parquet, .csv, or .duckdb")
        t1 = time.time()
        print(f"Save complete in {t1-t0:.3f}s")

if __name__ == '__main__':
    main()
