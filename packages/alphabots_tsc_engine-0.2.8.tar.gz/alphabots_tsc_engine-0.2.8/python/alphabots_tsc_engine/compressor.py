import json
import struct
import numpy as np
import pandas as pd
import polars as pl
import psutil
import warnings

try:
    from . import tsc_engine
except ImportError:
    raise ImportError("The 'tsc_engine' Rust extension is not installed. Please install it via 'pip install alphabots-tsc-engine' or build from source.")

class TSCompressor:
    def __init__(self, profile='balanced'):
        self.profile = profile
        
        # Hardware Pre-flight Check
        mem_info = psutil.virtual_memory()
        total_ram_gb = mem_info.total / (1024**3)
        available_ram_gb = mem_info.available / (1024**3)
        
        if profile == 'max_speed':
            self.zstd_level = 1
            self.use_delta = True 
            self.chunk_size = 5_000_000 # Massive chunks for parallel throughput, high RAM
            
            expected_ram = 10.0 # GB
            if available_ram_gb < expected_ram:
                warnings.warn(f"WARNING: 'max_speed' profile expects ~{expected_ram}GB of free RAM for massive datasets. You only have {available_ram_gb:.1f}GB available. This may cause swapping or OOM errors.")
                
        elif profile == 'max_compression':
            self.zstd_level = 9
            self.use_delta = True
            self.chunk_size = 500_000 # Larger chunks give Zstd a bigger window for dictionary building (more RAM but better ratio)
            
            expected_ram = 5.0 # GB
            if available_ram_gb < expected_ram:
                warnings.warn(f"WARNING: 'max_compression' profile expects ~{expected_ram}GB of free RAM. You only have {available_ram_gb:.1f}GB available.")
                
        else: # balanced
            self.zstd_level = 3
            self.use_delta = True
            
            # Dynamic chunking based on available RAM to prevent OOM on lower-end systems
            # 100k chunk ~ 50MB RAM. We want to use at most 20% of available RAM for chunk buffering
            safe_ram_buffer = available_ram_gb * 0.2
            if safe_ram_buffer > 2.0:
                self.chunk_size = 200_000 
            elif safe_ram_buffer > 1.0:
                self.chunk_size = 100_000
            elif safe_ram_buffer > 0.5:
                self.chunk_size = 50_000
            else:
                self.chunk_size = 25_000 # Very aggressive chunking for low RAM
            
            expected_ram = (self.chunk_size / 100_000) * 1.0 # Rough estimate GB
            if available_ram_gb < expected_ram:
                warnings.warn(f"WARNING: 'balanced' profile expects ~{expected_ram:.1f}GB of free RAM. You only have {available_ram_gb:.1f}GB available.")

    def _get_precision_factor(self, series: np.ndarray) -> int:
        """Dynamically detect the required precision factor to losslessly convert float to int."""
        valid = series[~np.isnan(series)]
        if len(valid) == 0:
            return 1
        
        # Test common financial multipliers
        for factor in [100, 10000, 1000000]:
            diff = np.abs(valid * factor - np.round(valid * factor))
            if np.max(diff) < 1e-5:
                return factor
        return 1000000 # Fallback

    def compress_dataframe(self, df: pd.DataFrame, file_path: str):
        self._compress_rust(df, file_path)

    def _compress_rust(self, df: pd.DataFrame, file_path: str):
        meta = {
            'num_rows': len(df),
            'columns': []
        }
        
        # In V2, Rust takes a Polars DataFrame where dictionaries are mapped to uint32
        pldf_dict = {}

        for col in df.columns:
            s = df[col]
            col_meta = {'name': col, 'dtype': str(s.dtype)}
            
            if s.dtype == np.float64 or s.dtype == np.float32:
                col_meta['type_class'] = 'float'
                pldf_dict[col] = pl.Series(col, np.asarray(s), dtype=pl.Float64)
                
            elif str(s.dtype) in ['string', 'string[python]', 'string[pyarrow]']:
                cat_s = df[col].astype('category')
                uniques = cat_s.cat.categories.astype(str).tolist()
                indices = cat_s.cat.codes.to_numpy() + 1
                uniques.insert(0, "") # Handle NaN as empty string at index 0
                
                col_meta['type_class'] = 'dict'
                col_meta['dict_values'] = uniques
                
                if len(uniques) < 256:
                    col_meta['index_dtype'] = 'uint8'
                elif len(uniques) < 65536:
                    col_meta['index_dtype'] = 'uint16'
                else:
                    col_meta['index_dtype'] = 'int32'
                    
                pldf_dict[col] = pl.Series(col, indices.astype(np.int64).tolist(), dtype=pl.Int64)
            elif (hasattr(s.dtype, 'kind') and s.dtype.kind in 'iu') or str(s.dtype).startswith('int') or str(s.dtype).startswith('datetime64'):
                if 'datetime64' in str(s.dtype):
                    s = np.asarray(s).view(np.int64)
                    col_meta['dtype'] = 'datetime64[ns]'
                col_meta['type_class'] = 'int'
                pldf_dict[col] = pl.Series(col, np.asarray(s), dtype=pl.Int64)
                
            elif s.dtype == np.uint8 or s.dtype == bool:
                col_meta['type_class'] = 'uint8'
                # Convert to int64 directly and wrap in a generic Polars series
                pldf_dict[col] = pl.Series(col, s.astype(np.int64).tolist(), dtype=pl.Int64)
                
            elif s.dtype == object or isinstance(s.dtype, pd.CategoricalDtype):
                if not isinstance(df[col].dtype, pd.CategoricalDtype):
                    cat_s = df[col].astype('category')
                else:
                    cat_s = df[col]
                    
                uniques = cat_s.cat.categories.astype(str).tolist()
                indices = cat_s.cat.codes.to_numpy() + 1
                uniques.insert(0, "") # Handle NaN as empty string at index 0
                
                col_meta['type_class'] = 'dict'
                col_meta['dict_values'] = uniques
                
                if len(uniques) < 256:
                    col_meta['index_dtype'] = 'uint8'
                elif len(uniques) < 65536:
                    col_meta['index_dtype'] = 'uint16'
                else:
                    col_meta['index_dtype'] = 'int32'
                    
                pldf_dict[col] = pl.Series(col, indices.astype(np.int64).tolist(), dtype=pl.Int64)
            else:
                if not isinstance(df[col].dtype, pd.CategoricalDtype):
                    cat_s = df[col].astype('category')
                else:
                    cat_s = df[col]
                    
                uniques = cat_s.cat.categories.astype(str).tolist()
                indices = cat_s.cat.codes.to_numpy() + 1
                uniques.insert(0, "") # Handle NaN as empty string at index 0
                
                col_meta['type_class'] = 'dict'
                col_meta['dict_values'] = uniques
                
                if len(uniques) < 256:
                    col_meta['index_dtype'] = 'uint8'
                elif len(uniques) < 65536:
                    col_meta['index_dtype'] = 'uint16'
                else:
                    col_meta['index_dtype'] = 'int32'
                    
                pldf_dict[col] = pl.Series(col, indices.astype(np.int64).tolist(), dtype=pl.Int64)
                
            meta['columns'].append(col_meta)

        pldf = pl.DataFrame(pldf_dict)
        meta_json_str = json.dumps(meta)
        tsc_engine.compress_to_file(file_path, self.zstd_level, self.use_delta, meta_json_str, pldf, self.chunk_size)

class TSDecompressor:
    def __init__(self, profile='balanced'):
        self.profile = profile

    def decompress_dataframe(self, file_path: str) -> pd.DataFrame:
        return self._decompress_rust(file_path)

    def _decompress_rust(self, file_path: str) -> pd.DataFrame:
        parallel_mode = (self.profile == 'max_speed')
        reader = tsc_engine.TSChunkReader(file_path, parallel_mode)
        meta = json.loads(reader.meta_json())
        
        if parallel_mode:
            chunks = reader.read_all_chunks()
        else:
            chunks = []
            while True:
                chunk = reader.next_chunk()
                if chunk is None:
                    break
                chunks.append(chunk)
            
        if not chunks:
            return pd.DataFrame()
            
        pldf = pl.concat(chunks)
        df_dict = pldf.to_dict()
        
        # Convert dictionary formats
        for col_meta in meta['columns']:
            name = col_meta['name']
            dtype_str = col_meta['dtype']
            
            if 'datetime' in dtype_str:
                df_dict[name] = pd.to_datetime(df_dict[name].to_numpy())
            elif col_meta.get('type_class') == 'uint8':
                # Downcast the workaround UInt32 back to uint8/bool
                if dtype_str == 'bool':
                    df_dict[name] = df_dict[name].to_numpy().astype(bool)
                else:
                    df_dict[name] = df_dict[name].to_numpy().astype(np.uint8)
            elif col_meta.get('type_class') == 'dict':
                uniques = np.array(col_meta['dict_values'])
                indices = df_dict[name].to_numpy()
                df_dict[name] = uniques[indices]
            else:
                df_dict[name] = df_dict[name].to_numpy()
                
        return pd.DataFrame(df_dict)

