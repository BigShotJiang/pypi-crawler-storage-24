use pyo3::prelude::*;
use std::fs::File;
use std::io::{Read, Seek, SeekFrom};
use serde_json::Value;
use polars::prelude::*;
use pyo3_polars::PyDataFrame;
use rayon::prelude::*;

#[pyclass]
pub struct TSChunkReader {
    file_path: String,
    meta: Value,
    current_chunk: usize,
    num_chunks: usize,
    parallel_mode: bool,
}

#[pymethods]
impl TSChunkReader {
    #[new]
    fn new(file_path: &str, parallel_mode: Option<bool>) -> PyResult<Self> {
        let mut file = File::open(file_path)?;
        
        file.seek(SeekFrom::End(-4))?;
        let mut len_buf = [0u8; 4];
        file.read_exact(&mut len_buf)?;
        let meta_len = u32::from_le_bytes(len_buf) as u64;

        file.seek(SeekFrom::End(-(4 + meta_len as i64)))?;
        let mut meta_bytes = vec![0u8; meta_len as usize];
        file.read_exact(&mut meta_bytes)?;
        let meta_json_str = String::from_utf8(meta_bytes).unwrap();
        let meta: Value = serde_json::from_str(&meta_json_str).unwrap();
        
        let num_chunks = meta["num_chunks"].as_u64().unwrap() as usize;

        Ok(Self {
            file_path: file_path.to_string(),
            meta,
            current_chunk: 0,
            num_chunks,
            parallel_mode: parallel_mode.unwrap_or(false),
        })
    }

    fn meta_json(&self) -> String {
        serde_json::to_string(&self.meta).unwrap()
    }

    fn read_all_chunks(&self, _py: Python) -> PyResult<Vec<PyDataFrame>> {
        if !self.parallel_mode {
            let mut frames = Vec::with_capacity(self.num_chunks);
            // Non-parallel implementation (useful for low-RAM streaming)
            let mut file = File::open(&self.file_path)?;
            for i in 0..self.num_chunks {
                frames.push(self.read_chunk_internal(&mut file, i)?);
            }
            return Ok(frames);
        }

        // PARALLEL MODE (Max Speed)
        // We will read all chunks into memory in parallel using Rayon
        // Note: PyO3 objects cannot be created in Rayon threads, so we decode to Polars Series
        // in parallel, then construct PyDataFrames on the main thread.
        
        let chunk_indices: Vec<usize> = (0..self.num_chunks).collect();
        let path = self.file_path.clone();
        let meta = self.meta.clone();

        let decoded_chunks: Vec<Result<DataFrame, std::io::Error>> = chunk_indices.into_par_iter().map(|idx| {
            let mut local_file = File::open(&path)?;
            
            let chunk_meta = &meta["chunks"][idx];
            let start_offset = chunk_meta["start"].as_u64().unwrap();
            let end_offset = chunk_meta["end"].as_u64().unwrap();
            let chunk_len = chunk_meta["length"].as_u64().unwrap() as usize;
            
            local_file.seek(SeekFrom::Start(start_offset))?;
            let comp_len = (end_offset - start_offset) as usize;
            let mut comp_buf = vec![0u8; comp_len];
            local_file.read_exact(&mut comp_buf)?;
            
            let mut decoder = zstd::stream::read::Decoder::new(&comp_buf[..])?;
            let mut chunk_data = Vec::new();
            decoder.read_to_end(&mut chunk_data)?;
            
            let cols_meta = meta["columns"].as_array().unwrap();
            let mut ptr = 0;
            
            let mut series_vec = Vec::with_capacity(cols_meta.len());
            
            for col_meta in cols_meta {
                let name = col_meta["name"].as_str().unwrap();
                let type_class = col_meta["type_class"].as_str().unwrap();
                
                if type_class == "float" {
                    let encoding = col_meta["encoding"].as_str().unwrap();
                    let factor = col_meta["factor"].as_f64().unwrap();
                    let has_nans = col_meta["has_nans"].as_bool().unwrap();
                    
                    let mut int_vals = vec![0i64; chunk_len];
                    
                    if encoding == "delta" {
                        let mut first_val_buf = [0u8; 8];
                        first_val_buf.copy_from_slice(&chunk_data[ptr..ptr+8]);
                        let first_val = i64::from_le_bytes(first_val_buf);
                        ptr += 8;
                        
                        let diff_dtype = chunk_data[ptr];
                        ptr += 1;
                        
                        if chunk_len > 0 {
                            int_vals[0] = first_val;
                            let mut current = first_val;
                            
                            if diff_dtype == 4 {
                                for i in 1..chunk_len {
                                    let mut b = [0u8; 4];
                                    b.copy_from_slice(&chunk_data[ptr..ptr+4]);
                                    ptr += 4;
                                    current = current.wrapping_add(i32::from_le_bytes(b) as i64);
                                    int_vals[i] = current;
                                }
                            } else {
                                for i in 1..chunk_len {
                                    let mut b = [0u8; 8];
                                    b.copy_from_slice(&chunk_data[ptr..ptr+8]);
                                    ptr += 8;
                                    current = current.wrapping_add(i64::from_le_bytes(b));
                                    int_vals[i] = current;
                                }
                            }
                        }
                    } else {
                        for i in 0..chunk_len {
                            let mut b = [0u8; 8];
                            b.copy_from_slice(&chunk_data[ptr..ptr+8]);
                            ptr += 8;
                            int_vals[i] = i64::from_le_bytes(b);
                        }
                    }
                    
                    let mut float_vals = vec![0.0f64; chunk_len];
                    for i in 0..chunk_len {
                        float_vals[i] = int_vals[i] as f64 / factor;
                    }
                    
                    if has_nans {
                        for i in 0..chunk_len {
                            let bit_idx = i % 8;
                            let byte = chunk_data[ptr + i / 8];
                            if (byte & (1 << (7 - bit_idx))) != 0 {
                                float_vals[i] = f64::NAN;
                            }
                        }
                        ptr += (chunk_len + 7) / 8;
                    }
                    
                    let s = Series::new(name.into(), float_vals);
                    series_vec.push(s);
                    
                } else if type_class == "int" {
                    let encoding = col_meta["encoding"].as_str().unwrap();
                    let mut int_vals = vec![0i64; chunk_len];
                    
                    if encoding == "delta" {
                        if chunk_len > 0 {
                            let mut first_val_buf = [0u8; 8];
                            first_val_buf.copy_from_slice(&chunk_data[ptr..ptr+8]);
                            let first_val = i64::from_le_bytes(first_val_buf);
                            ptr += 8;
                            
                            let diff_dtype = chunk_data[ptr];
                            ptr += 1;
                            
                            int_vals[0] = first_val;
                            let mut current = first_val;
                            
                            if diff_dtype == 4 {
                                for i in 1..chunk_len {
                                    let mut b = [0u8; 4];
                                    b.copy_from_slice(&chunk_data[ptr..ptr+4]);
                                    ptr += 4;
                                    current = current.wrapping_add(i32::from_le_bytes(b) as i64);
                                    int_vals[i] = current;
                                }
                            } else {
                                for i in 1..chunk_len {
                                    let mut b = [0u8; 8];
                                    b.copy_from_slice(&chunk_data[ptr..ptr+8]);
                                    ptr += 8;
                                    current = current.wrapping_add(i64::from_le_bytes(b));
                                    int_vals[i] = current;
                                }
                            }
                        }
                    } else {
                        for i in 0..chunk_len {
                            let mut b = [0u8; 8];
                            b.copy_from_slice(&chunk_data[ptr..ptr+8]);
                            ptr += 8;
                            int_vals[i] = i64::from_le_bytes(b);
                        }
                    }
                    
                    let s = Series::new(name.into(), int_vals);
                    series_vec.push(s);
                    
                } else if type_class == "uint8" {
                    let mut u8_vals = vec![0u8; chunk_len];
                    u8_vals.copy_from_slice(&chunk_data[ptr..ptr+chunk_len]);
                    ptr += chunk_len;
                    let ca = UInt32Chunked::from_vec(name.into(), u8_vals.into_iter().map(|v| v as u32).collect());
                    series_vec.push(ca.into_series());
                    
                } else if type_class == "dict" {
                    let index_dtype = col_meta["index_dtype"].as_str().unwrap();
                    let mut u32_vals = vec![0u32; chunk_len];
                    
                    if index_dtype == "uint8" {
                        for i in 0..chunk_len {
                            u32_vals[i] = chunk_data[ptr] as u32;
                            ptr += 1;
                        }
                    } else if index_dtype == "uint16" {
                        for i in 0..chunk_len {
                            let mut b = [0u8; 2];
                            b.copy_from_slice(&chunk_data[ptr..ptr+2]);
                            ptr += 2;
                            u32_vals[i] = u16::from_le_bytes(b) as u32;
                        }
                    } else {
                        for i in 0..chunk_len {
                            let mut b = [0u8; 4];
                            b.copy_from_slice(&chunk_data[ptr..ptr+4]);
                            ptr += 4;
                            u32_vals[i] = i32::from_le_bytes(b) as u32;
                        }
                    }
                    
                    let ca = UInt32Chunked::from_slice(name.into(), &u32_vals);
                    series_vec.push(ca.into_series());
                }
            }
            
            Ok(DataFrame::new(series_vec).unwrap())
        }).collect();

        // Convert to PyDataFrames
        let mut py_frames = Vec::with_capacity(self.num_chunks);
        for res in decoded_chunks {
            let df = res?;
            py_frames.push(PyDataFrame(df));
        }
        
        Ok(py_frames)
    }

    fn next_chunk(&mut self, _py: Python) -> PyResult<Option<PyDataFrame>> {
        if self.current_chunk >= self.num_chunks {
            return Ok(None);
        }
        let mut file = File::open(&self.file_path)?;
        let df = self.read_chunk_internal(&mut file, self.current_chunk)?;
        self.current_chunk += 1;
        Ok(Some(df))
    }
}

impl TSChunkReader {
    fn read_chunk_internal(&self, file: &mut File, chunk_idx: usize) -> PyResult<PyDataFrame> {
        let chunk_meta = &self.meta["chunks"][chunk_idx];
        let start_offset = chunk_meta["start"].as_u64().unwrap();
        let end_offset = chunk_meta["end"].as_u64().unwrap();
        let chunk_len = chunk_meta["length"].as_u64().unwrap() as usize;
        
        file.seek(SeekFrom::Start(start_offset))?;
        let comp_len = (end_offset - start_offset) as usize;
        let mut comp_buf = vec![0u8; comp_len];
        file.read_exact(&mut comp_buf)?;
        
        let mut decoder = zstd::stream::read::Decoder::new(&comp_buf[..])?;
        let mut chunk_data = Vec::new();
        decoder.read_to_end(&mut chunk_data)?;
        
        let cols_meta = self.meta["columns"].as_array().unwrap();
        let mut ptr = 0;
        
        let mut series_vec = Vec::with_capacity(cols_meta.len());
        
        for col_meta in cols_meta {
            let name = col_meta["name"].as_str().unwrap();
            let type_class = col_meta["type_class"].as_str().unwrap();
            
            if type_class == "float" {
                let encoding = col_meta["encoding"].as_str().unwrap();
                let factor = col_meta["factor"].as_f64().unwrap();
                let has_nans = col_meta["has_nans"].as_bool().unwrap();
                
                let mut int_vals = vec![0i64; chunk_len];
                
                if encoding == "delta" {
                    let mut first_val_buf = [0u8; 8];
                    first_val_buf.copy_from_slice(&chunk_data[ptr..ptr+8]);
                    let first_val = i64::from_le_bytes(first_val_buf);
                    ptr += 8;
                    
                    let diff_dtype = chunk_data[ptr];
                    ptr += 1;
                    
                    if chunk_len > 0 {
                        int_vals[0] = first_val;
                        let mut current = first_val;
                        
                        if diff_dtype == 4 {
                                for i in 1..chunk_len {
                                    let mut b = [0u8; 4];
                                    b.copy_from_slice(&chunk_data[ptr..ptr+4]);
                                    ptr += 4;
                                    current = current.wrapping_add(i32::from_le_bytes(b) as i64);
                                    int_vals[i] = current;
                                }
                            } else {
                                for i in 1..chunk_len {
                                    let mut b = [0u8; 8];
                                    b.copy_from_slice(&chunk_data[ptr..ptr+8]);
                                    ptr += 8;
                                    current = current.wrapping_add(i64::from_le_bytes(b));
                                    int_vals[i] = current;
                                }
                            }
                    }
                } else {
                    for i in 0..chunk_len {
                        let mut b = [0u8; 8];
                        b.copy_from_slice(&chunk_data[ptr..ptr+8]);
                        ptr += 8;
                        int_vals[i] = i64::from_le_bytes(b);
                    }
                }
                
                let mut float_vals = vec![0.0f64; chunk_len];
                for i in 0..chunk_len {
                    float_vals[i] = int_vals[i] as f64 / factor;
                }
                
                if has_nans {
                    for i in 0..chunk_len {
                        let bit_idx = i % 8;
                        let byte = chunk_data[ptr + i / 8];
                        if (byte & (1 << (7 - bit_idx))) != 0 {
                            float_vals[i] = f64::NAN;
                        }
                    }
                    ptr += (chunk_len + 7) / 8;
                }
                
                let s = Series::new(name.into(), float_vals);
                series_vec.push(s);
                
            } else if type_class == "int" {
                let encoding = col_meta["encoding"].as_str().unwrap();
                let mut int_vals = vec![0i64; chunk_len];
                
                if encoding == "delta" {
                    if chunk_len > 0 {
                        let mut first_val_buf = [0u8; 8];
                        first_val_buf.copy_from_slice(&chunk_data[ptr..ptr+8]);
                        let first_val = i64::from_le_bytes(first_val_buf);
                        ptr += 8;
                        
                        let diff_dtype = chunk_data[ptr];
                        ptr += 1;
                        
                        int_vals[0] = first_val;
                        let mut current = first_val;
                        
                        if diff_dtype == 4 {
                            for i in 1..chunk_len {
                                let mut b = [0u8; 4];
                                b.copy_from_slice(&chunk_data[ptr..ptr+4]);
                                ptr += 4;
                                current = current.wrapping_add(i32::from_le_bytes(b) as i64);
                                int_vals[i] = current;
                            }
                        } else {
                            for i in 1..chunk_len {
                                let mut b = [0u8; 8];
                                b.copy_from_slice(&chunk_data[ptr..ptr+8]);
                                ptr += 8;
                                current = current.wrapping_add(i64::from_le_bytes(b));
                                int_vals[i] = current;
                            }
                        }
                    }
                } else {
                    for i in 0..chunk_len {
                        let mut b = [0u8; 8];
                        b.copy_from_slice(&chunk_data[ptr..ptr+8]);
                        ptr += 8;
                        int_vals[i] = i64::from_le_bytes(b);
                    }
                }
                
                let s = Series::new(name.into(), int_vals);
                series_vec.push(s);
                
            } else if type_class == "uint8" {
                let mut u8_vals = vec![0u8; chunk_len];
                u8_vals.copy_from_slice(&chunk_data[ptr..ptr+chunk_len]);
                ptr += chunk_len;
                let ca = UInt32Chunked::from_vec(name.into(), u8_vals.into_iter().map(|v| v as u32).collect());
                series_vec.push(ca.into_series());
                
            } else if type_class == "dict" {
                let index_dtype = col_meta["index_dtype"].as_str().unwrap();
                let mut u32_vals = vec![0u32; chunk_len];
                
                if index_dtype == "uint8" {
                    for i in 0..chunk_len {
                        u32_vals[i] = chunk_data[ptr] as u32;
                        ptr += 1;
                    }
                } else if index_dtype == "uint16" {
                    for i in 0..chunk_len {
                        let mut b = [0u8; 2];
                        b.copy_from_slice(&chunk_data[ptr..ptr+2]);
                        ptr += 2;
                        u32_vals[i] = u16::from_le_bytes(b) as u32;
                    }
                } else {
                    for i in 0..chunk_len {
                        let mut b = [0u8; 4];
                        b.copy_from_slice(&chunk_data[ptr..ptr+4]);
                        ptr += 4;
                        u32_vals[i] = i32::from_le_bytes(b) as u32;
                    }
                }
                
                let ca = UInt32Chunked::from_slice(name.into(), &u32_vals);
                series_vec.push(ca.into_series());
            }
        }
        
        let chunk_df = DataFrame::new(series_vec).unwrap();
        Ok(PyDataFrame(chunk_df))
    }
}
