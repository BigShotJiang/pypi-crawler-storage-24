use pyo3::prelude::*;
use std::fs::File;
use std::io::{Write, Seek, SeekFrom};
use serde_json::{Value, json};
use polars::prelude::*;
use pyo3_polars::PyDataFrame;

// For writing chunks we will take python Polars DataFrame as input (passed via pyo3_polars)
// but to make it easy, we can also just accept the DataFrame from python and iterate chunks

fn get_precision_factor(slice: &[f64]) -> i64 {
    let factors = [100.0, 10000.0, 1000000.0];
    for &factor in &factors {
        let mut ok = true;
        for &v in slice {
            if !v.is_nan() {
                if (v * factor - (v * factor).round()).abs() > 1e-5 {
                    ok = false;
                    break;
                }
            }
        }
        if ok {
            return factor as i64;
        }
    }
    1000000
}

#[pyfunction]
fn compress_to_file(
    py: Python,
    file_path: &str,
    zstd_level: i32,
    use_delta: bool,
    meta_json_str: &str,
    pydf: PyDataFrame,
    chunk_size: usize,
) -> PyResult<String> {
    let df: DataFrame = pydf.into();
    let mut meta: Value = serde_json::from_str(meta_json_str).unwrap();
    
    let num_rows = df.height();
    meta["num_rows"] = json!(num_rows);
    let num_chunks = (num_rows + chunk_size - 1) / chunk_size;
    meta["chunk_size"] = json!(chunk_size);
    meta["num_chunks"] = json!(num_chunks);
    
    let cols_meta = meta["columns"].as_array_mut().unwrap();
    let mut file = File::create(file_path)?;
    file.write_all(b"TSC3")?; // New magic for chunked format

    let mut chunk_offsets = Vec::new();
    
    for chunk_idx in 0..num_chunks {
        let offset = chunk_idx * chunk_size;
        let len = std::cmp::min(chunk_size, num_rows - offset);
        
        let chunk_df = df.slice(offset as i64, len);
        
        let mut encoder = zstd::stream::write::Encoder::new(Vec::new(), zstd_level)?;
        
        for (_, col_meta) in cols_meta.iter_mut().enumerate() {
            let col_name = col_meta["name"].as_str().unwrap();
            let series = chunk_df.column(col_name).unwrap();
            let type_class = col_meta["type_class"].as_str().unwrap();
            
            if type_class == "float" {
                let s_f64 = series.cast(&DataType::Float64).unwrap();
                let f64_ca = s_f64.f64().unwrap();
                
                // We need to collect to slice or handle nulls
                // Let's forward fill in rust or just handle nulls as NaNs
                // In Polars, nulls are not NaNs. We can fill nulls with NaNs
                let mut slice_vec: Vec<f64> = Vec::with_capacity(len);
                for opt_val in f64_ca.into_iter() {
                    slice_vec.push(opt_val.unwrap_or(f64::NAN));
                }
                
                let slice = &slice_vec;
                
                let factor = if chunk_idx == 0 {
                    let f = get_precision_factor(slice);
                    col_meta["factor"] = json!(f);
                    f
                } else {
                    col_meta["factor"].as_i64().unwrap()
                };
                
                let mut has_nans = false;
                for &v in slice {
                    if v.is_nan() {
                        has_nans = true;
                        break;
                    }
                }
                
                if chunk_idx == 0 {
                    col_meta["has_nans"] = json!(has_nans);
                }
                
                if use_delta {
                    if chunk_idx == 0 { col_meta["encoding"] = json!("delta"); }
                    
                    let mut first_val: i64 = 0;
                    let mut max_abs_diff: i64 = 0;
                    if !slice.is_empty() {
                        first_val = if slice[0].is_nan() { 0 } else { (slice[0] * (factor as f64)).round() as i64 };
                        let mut last_val = first_val;
                        
                        for &v in slice.iter().skip(1) {
                            let current_val = if v.is_nan() { last_val } else { (v * (factor as f64)).round() as i64 };
                            let diff = current_val.wrapping_sub(last_val);
                            if diff.unsigned_abs() > max_abs_diff as u64 {
                                max_abs_diff = diff.unsigned_abs() as i64;
                            }
                            last_val = current_val;
                        }
                    }
                    
                    encoder.write_all(&first_val.to_le_bytes())?;
                    
                    let use_int32 = max_abs_diff < i32::MAX as i64;
                    let flag: u8 = if use_int32 { 4 } else { 8 };
                    encoder.write_all(&[flag])?;
                    
                    if !slice.is_empty() {
                        let mut last_val = first_val;
                        for &v in slice.iter().skip(1) {
                            let current_val = if v.is_nan() { last_val } else { (v * (factor as f64)).round() as i64 };
                            let diff = current_val.wrapping_sub(last_val);
                            if use_int32 {
                                encoder.write_all(&(diff as i32).to_le_bytes())?;
                            } else {
                                encoder.write_all(&diff.to_le_bytes())?;
                            }
                            last_val = current_val;
                        }
                    }
                } else {
                    if chunk_idx == 0 { col_meta["encoding"] = json!("raw"); }
                    let mut last_val: i64 = 0;
                    for &v in slice {
                        let mut current_val = last_val;
                        if !v.is_nan() {
                            current_val = (v * (factor as f64)).round() as i64;
                        }
                        encoder.write_all(&current_val.to_le_bytes())?;
                        last_val = current_val;
                    }
                }
                
                if has_nans {
                    let mut nan_bits = Vec::with_capacity((slice.len() + 7) / 8);
                    let mut current_byte: u8 = 0;
                    for (idx, &v) in slice.iter().enumerate() {
                        let bit_idx = idx % 8;
                        if v.is_nan() {
                            current_byte |= 1 << (7 - bit_idx);
                        }
                        if bit_idx == 7 || idx == slice.len() - 1 {
                            nan_bits.push(current_byte);
                            current_byte = 0;
                        }
                    }
                    encoder.write_all(&nan_bits)?;
                }
                
            } else if type_class == "int" {
                let s_i64 = series.cast(&DataType::Int64).unwrap();
                let i64_ca = s_i64.i64().unwrap();
                let slice_vec: Vec<i64> = i64_ca.into_iter().map(|v| v.unwrap_or(0)).collect();
                let slice = &slice_vec;
                
                if use_delta {
                    if chunk_idx == 0 { col_meta["encoding"] = json!("delta"); }
                    let first_val = if slice.is_empty() { 0 } else { slice[0] };
                    
                    let mut max_abs_diff: i64 = 0;
                    if !slice.is_empty() {
                        let mut last_val = slice[0];
                        for &v in slice.iter().skip(1) {
                            let diff = v.wrapping_sub(last_val);
                            if diff.unsigned_abs() > max_abs_diff as u64 {
                                max_abs_diff = diff.unsigned_abs() as i64;
                            }
                            last_val = v;
                        }
                    }
                    
                    encoder.write_all(&first_val.to_le_bytes())?;
                    let use_int32 = max_abs_diff < i32::MAX as i64;
                    let flag: u8 = if use_int32 { 4 } else { 8 };
                    encoder.write_all(&[flag])?;
                    
                    if !slice.is_empty() {
                        let mut last_val = slice[0];
                        for &v in slice.iter().skip(1) {
                            let diff = v.wrapping_sub(last_val);
                            if use_int32 {
                                encoder.write_all(&(diff as i32).to_le_bytes())?;
                            } else {
                                encoder.write_all(&diff.to_le_bytes())?;
                            }
                            last_val = v;
                        }
                    }
                } else {
                    if chunk_idx == 0 { col_meta["encoding"] = json!("raw"); }
                    for &v in slice {
                        encoder.write_all(&v.to_le_bytes())?;
                    }
                }
            } else if type_class == "uint8" {
                if chunk_idx == 0 { col_meta["encoding"] = json!("raw"); }
                // We passed it as Int64 from Python to avoid pyo3_polars UInt8 casting bug
                let s_i64 = series.cast(&DataType::Int64).unwrap();
                let i64_ca = s_i64.i64().unwrap();
                for opt_val in i64_ca.into_iter() {
                    encoder.write_all(&[opt_val.unwrap_or(0) as u8])?;
                }
            } else if type_class == "dict" {
                if chunk_idx == 0 { col_meta["encoding"] = json!("dict"); }
                let index_dtype = col_meta["index_dtype"].as_str().unwrap();
                
                // We passed as Int64 from Python to avoid Polars UInt casting bugs
                let s_i64 = series.cast(&DataType::Int64).unwrap();
                let ca = s_i64.i64().unwrap();
                
                if index_dtype == "uint8" {
                    for v in ca.into_iter() {
                        encoder.write_all(&[v.unwrap_or(0) as u8])?;
                    }
                } else if index_dtype == "uint16" {
                    for v in ca.into_iter() {
                        encoder.write_all(&(v.unwrap_or(0) as u16).to_le_bytes())?;
                    }
                } else {
                    for v in ca.into_iter() {
                        encoder.write_all(&(v.unwrap_or(0) as i32).to_le_bytes())?;
                    }
                }
            }
        }
        
        let chunk_bytes = encoder.finish()?;
        let start_offset = file.stream_position()?;
        file.write_all(&chunk_bytes)?;
        let end_offset = file.stream_position()?;
        
        chunk_offsets.push(json!({
            "start": start_offset,
            "end": end_offset,
            "length": len
        }));
    }
    
    meta["chunks"] = Value::Array(chunk_offsets);
    
    let final_meta_json = serde_json::to_string(&meta).unwrap();
    let meta_bytes = final_meta_json.as_bytes();
    file.write_all(meta_bytes)?;
    file.write_all(&(meta_bytes.len() as u32).to_le_bytes())?;

    Ok(final_meta_json)
}

mod reader;
use reader::TSChunkReader;

#[pymodule]
fn tsc_engine(_py: Python, m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(compress_to_file, m)?)?;
    m.add_class::<TSChunkReader>()?;
    Ok(())
}
