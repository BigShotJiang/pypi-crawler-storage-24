"""Auto-generated stub for module: weapon_detection."""
from typing import Any, Dict, Optional

from ..advanced_tracker import AdvancedTracker
from ..advanced_tracker.config import TrackerConfig
from ..core.base import BaseProcessor, ProcessingContext, ProcessingResult, ConfigProtocol
from ..core.config import BaseConfig, AlertConfig
from ..utils import filter_by_confidence, filter_by_categories, apply_category_mapping, count_objects_by_category, calculate_counting_summary, match_results_structure, bbox_smoothing, BBoxSmoothingConfig, BBoxSmoothingTracker

# Classes
class WeaponDetectionConfig:
    # Configuration for weapon detection use case.

    ...
class WeaponDetectionUseCase:
    def __init__(self: Any) -> None: ...

    def get_total_counts(self: Any) -> Any:
        """
        Return total unique track_id count for each category.
        """
        ...

    def process(self: Any, data: Any, config: Any, context: Optional[Any] = None, stream_info: Optional[Dict[str, Any]] = None) -> Any:
        """
        Main entry point for weapon detection post-processing.
        Applies category mapping, smoothing, tracking, counting, alerting, and summary generation.
        """
        ...

