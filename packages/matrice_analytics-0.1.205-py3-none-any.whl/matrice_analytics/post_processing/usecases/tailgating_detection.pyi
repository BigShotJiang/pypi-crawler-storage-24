"""Auto-generated stub for module: tailgating_detection."""
from typing import Any, Dict, List, Optional

from ..core.base import BaseProcessor, ProcessingContext, ProcessingResult, ConfigProtocol
from ..core.config import BaseConfig, ZoneConfig, AlertConfig
from ..utils import filter_by_confidence, match_results_structure, point_in_polygon, get_bbox_center, get_bbox_bottom25_center
from ..utils.tailgating_utils import DoorRuntime, CrossingRecord, AccessEventManager, analyze_passage, detect_crossing, compute_entry_normal, motion_vector, signed_distance, segment_intersects_line

# Classes
class TailgatingConfig:
    # Configuration container for tailgating detection.
    #
    # Holds thresholds, zones, and timing parameters controlling
    # event grouping and follower detection.

    def __init__(self: Any, usecase: str = 'tailgating_detection', category: str = 'security', confidence_threshold: float = 0.5, target_categories: Optional[List[str]] = None, zones: Optional[Dict[str, Any]] = None, access_window_sec: float = 5.0, silence_timeout_sec: float = 2.0, cooldown_sec: float = 4.0, allowed_persons_per_event: int = 1, max_follow_time_delta_sec: float = 3, alert_config: Optional[Any] = None, **kwargs: Any) -> None: ...

class TailgatingDetectionUseCase:
    # Main processor implementing tailgating detection.
    #
    # Tracks crossings across configured doors and groups them into
    # events, then detects followers.

    def __init__(self: Any) -> None: ...

    def create_default_config(self: Any, **overrides: Any) -> Any:
        """
        Return default config template.
        """
        ...

    def process(self: Any, data: Any, config: Any, context: Optional[Any] = None, stream_info: Optional[Any] = None) -> Any:
        """
        Entry point for processor execution.
        Routes data to frame or multi-frame processing.
        """
        ...

