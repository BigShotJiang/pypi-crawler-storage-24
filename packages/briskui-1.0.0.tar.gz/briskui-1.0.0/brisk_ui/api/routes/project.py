"""Project settings API routes.

Reads and writes project configuration from the .brisk/project.json file.
"""

import os
import re
import shutil
import sqlite3

import fastapi
import pydantic

from brisk_ui.config import Settings
from brisk_ui.services.project_config import ProjectConfigService

# Temp storage for files uploaded during create mode (before project dir exists)
_pending_uploads: dict[str, bytes] = {}


def get_settings(request: fastapi.Request) -> Settings:
    """Get application settings from request state."""
    return request.app.state.settings


def sanitize_directory_name(name: str) -> str:
    """Convert a project name to a valid directory name.
    
    - Converts to lowercase
    - Replaces spaces and special chars with hyphens
    - Removes consecutive hyphens
    - Strips leading/trailing hyphens
    """
    # Convert to lowercase and replace spaces/special chars with hyphens
    sanitized = re.sub(r'[^a-zA-Z0-9]+', '-', name.lower())
    # Remove consecutive hyphens
    sanitized = re.sub(r'-+', '-', sanitized)
    # Strip leading/trailing hyphens
    sanitized = sanitized.strip('-')
    return sanitized or "project"

router = fastapi.APIRouter()


class ProjectSettings(pydantic.BaseModel):
    """Project settings model."""
    project_name: str = ""
    project_path: str = ""
    project_description: str = ""
    project_type: str = "classification"  # "classification" or "regression"


class ProjectSettingsUpdate(pydantic.BaseModel):
    """Partial update model for project settings."""
    project_name: str | None = None
    project_path: str | None = None
    project_description: str | None = None
    project_type: str | None = None


@router.get("", response_model=ProjectSettings)
async def get_project_settings(request: fastapi.Request):
    """Get project settings from project.json file."""
    settings = request.app.state.settings
    config_service = ProjectConfigService(settings.project_path)
    
    config_data = config_service.read()
    
    return ProjectSettings(
        project_name=config_data.get("project_name", ""),
        project_path=config_data.get("project_path", str(settings.project_path)),
        project_description=config_data.get("project_description", ""),
        project_type=config_data.get("project_type", "classification"),
    )


class CreateProjectRequest(pydantic.BaseModel):
    """Request model for creating/initializing a project."""
    project_name: str
    project_path: str = ""
    project_description: str = ""
    project_type: str = "classification"  # "classification" or "regression"


class CreateProjectResponse(pydantic.BaseModel):
    """Response model for project creation."""
    project_name: str
    project_path: str
    project_description: str
    project_type: str
    directory_name: str


@router.post("", response_model=CreateProjectResponse)
async def create_project(
    request: fastapi.Request,
    data: CreateProjectRequest,
):
    """Create or initialize project settings.
    
    In create mode (BRISK_UI_CREATE_MODE=true):
    - Creates a new directory named after the sanitized project name
    - The project_path setting is the parent directory
    
    In normal mode:
    - Creates .brisk directory and project.json file in existing project directory
    """
    settings = request.app.state.settings
    create_mode = os.environ.get("BRISK_UI_CREATE_MODE", "false") == "true"
    
    if create_mode:
        # In create mode, use user-provided project_path if given, else settings.project_path
        import pathlib
        parent_dir = pathlib.Path(data.project_path) if data.project_path else settings.project_path
        
        # Validate parent directory exists
        if not parent_dir.exists():
            raise fastapi.HTTPException(
                status_code=400,
                detail=f"Parent directory does not exist: {parent_dir}"
            )
        if not parent_dir.is_dir():
            raise fastapi.HTTPException(
                status_code=400,
                detail=f"Path is not a directory: {parent_dir}"
            )
        
        # Create a subdirectory named after the project
        dir_name = sanitize_directory_name(data.project_name)
        project_dir = parent_dir / dir_name
        
        # Check if directory already exists
        if project_dir.exists():
            raise fastapi.HTTPException(
                status_code=400,
                detail=f"Project directory already exists: {project_dir}"
            )
        
        # Create the project directory, .brisk subdirectory, and datasets directory
        brisk_dir = project_dir / ".brisk"
        brisk_dir.mkdir(parents=True, exist_ok=True)
        (project_dir / "datasets").mkdir(exist_ok=True)
        
        # Create empty brisk.sqlite database
        sqlite3.connect(str(brisk_dir / "brisk.sqlite")).close()
        
        # Flush any files uploaded during the wizard into the new datasets/ dir
        global _pending_uploads
        if _pending_uploads:
            datasets_dir = project_dir / "datasets"
            for fname, content in _pending_uploads.items():
                (datasets_dir / fname).write_bytes(content)
            _pending_uploads = {}
        
        # Switch to the new project immediately so subsequent writes target it
        os.environ["BRISK_UI_CREATE_MODE"] = "false"
        request.app.state.settings = Settings(project_path=project_dir)
        
        config_service = ProjectConfigService(project_dir)
        actual_project_path = str(project_dir)
    else:
        # Normal mode - use existing project directory
        dir_name = settings.project_path.name
        brisk_dir = settings.project_path / ".brisk"
        brisk_dir.mkdir(parents=True, exist_ok=True)
        (settings.project_path / "datasets").mkdir(exist_ok=True)
        
        # Create empty brisk.sqlite database if it doesn't exist
        db_path = brisk_dir / "brisk.sqlite"
        if not db_path.exists():
            sqlite3.connect(str(db_path)).close()
        
        config_service = ProjectConfigService(settings.project_path)
        actual_project_path = data.project_path or str(settings.project_path)
    
    # Write project settings to project.json
    config_data = {
        "project_name": data.project_name,
        "project_path": actual_project_path,
        "project_description": data.project_description,
        "project_type": data.project_type,
    }
    config_service.write(config_data)
    
    return CreateProjectResponse(
        project_name=config_data["project_name"],
        project_path=config_data["project_path"],
        project_description=config_data["project_description"],
        project_type=config_data["project_type"],
        directory_name=dir_name,
    )


@router.patch("", response_model=ProjectSettings)
async def update_project_settings(
    request: fastapi.Request,
    update: ProjectSettingsUpdate,
):
    """Update project settings in project.json file."""
    settings = request.app.state.settings
    config_service = ProjectConfigService(settings.project_path)
    
    config_data = config_service.read()
    
    # Update only provided fields
    if update.project_name is not None:
        config_data["project_name"] = update.project_name
    if update.project_path is not None:
        config_data["project_path"] = update.project_path
    if update.project_description is not None:
        config_data["project_description"] = update.project_description
    if update.project_type is not None:
        config_data["project_type"] = update.project_type
    
    config_service.write(config_data)
    
    return ProjectSettings(
        project_name=config_data.get("project_name", ""),
        project_path=config_data.get("project_path", str(settings.project_path)),
        project_description=config_data.get("project_description", ""),
        project_type=config_data.get("project_type", "classification"),
    )


class MoveProjectRequest(pydantic.BaseModel):
    """Request model for moving project to a new location."""
    new_path: str
    new_description: str | None = None  # Optionally update description during move


class MoveProjectResponse(pydantic.BaseModel):
    """Response model for project move operation."""
    success: bool
    old_path: str
    new_path: str
    message: str


@router.post("/move", response_model=MoveProjectResponse)
async def move_project(
    request: fastapi.Request,
    data: MoveProjectRequest,
):
    """Move the project directory to a new location.
    
    This will:
    1. Create parent directories if they don't exist
    2. Move the entire project directory to the new path
    3. Update project.json with the new path
    
    After this operation, the backend needs to be restarted with the new path.
    """
    import pathlib
    
    settings = request.app.state.settings
    old_path = settings.project_path
    new_path = pathlib.Path(data.new_path)
    
    # Normalize paths for comparison
    old_path_resolved = old_path.resolve()
    new_path_resolved = new_path.resolve()
    
    # Check if paths are the same
    if old_path_resolved == new_path_resolved:
        return MoveProjectResponse(
            success=True,
            old_path=str(old_path),
            new_path=str(new_path),
            message="Paths are the same, no move needed",
        )
    
    # Check if new path already exists
    if new_path.exists():
        raise fastapi.HTTPException(
            status_code=400,
            detail=f"Destination path already exists: {new_path}"
        )
    
    # Check if new path is inside old path (would cause issues)
    try:
        new_path_resolved.relative_to(old_path_resolved)
        raise fastapi.HTTPException(
            status_code=400,
            detail="Cannot move project into a subdirectory of itself"
        )
    except ValueError:
        pass  # Not a subdirectory, which is what we want
    
    # Create parent directories if they don't exist
    new_path.parent.mkdir(parents=True, exist_ok=True)
    
    try:
        # Move the entire project directory
        shutil.move(str(old_path), str(new_path))
        
        # Update project.json with new path and optionally description
        config_service = ProjectConfigService(new_path)
        config_data = config_service.read()
        config_data["project_path"] = str(new_path)
        if data.new_description is not None:
            config_data["project_description"] = data.new_description
        config_service.write(config_data)
        
        return MoveProjectResponse(
            success=True,
            old_path=str(old_path),
            new_path=str(new_path),
            message=f"Project moved successfully. Please restart the UI with the new path: {new_path}",
        )
    except OSError as e:
        raise fastapi.HTTPException(
            status_code=500,
            detail=f"Failed to move project: {str(e)}"
        )


# ============================================================================
# Safe zone helpers for preserving user code
# ============================================================================

import pathlib

SAFE_ZONE_MARKER = "# ---- BRISK UI MANAGED BELOW (do not edit) ----"


def _merge_with_safe_zone(existing_path: pathlib.Path, new_content: str) -> str:
    """Preserve user code above the safe zone marker.

    If the file already exists:
      - Content above the marker is kept exactly as-is.
      - Everything from the marker down is replaced with the new content.
      - If no marker is found, the entire existing file is treated as user
        code and placed above a new marker + generated content.
    If the file does not exist, return marker + new content.
    """
    if not existing_path.exists():
        return f"{SAFE_ZONE_MARKER}\n{new_content}"

    existing = existing_path.read_text()
    marker_idx = existing.find(SAFE_ZONE_MARKER)

    if marker_idx == -1:
        user_code = existing.rstrip("\n")
        if user_code:
            return f"{user_code}\n\n{SAFE_ZONE_MARKER}\n{new_content}"
        return f"{SAFE_ZONE_MARKER}\n{new_content}"

    user_code = existing[:marker_idx].rstrip("\n")
    if user_code:
        return f"{user_code}\n\n{SAFE_ZONE_MARKER}\n{new_content}"
    return f"{SAFE_ZONE_MARKER}\n{new_content}"


def _extract_existing_wrappers(content: str) -> list[dict]:
    """Extract AlgorithmWrapper definitions from existing algorithms.py.

    Returns a list of dicts with ``name`` (the wrapper's name= value) and
    ``text`` (the complete ``AlgorithmWrapper(...)`` source including indentation).
    Uses a balanced-parentheses counter so nested dicts/lists are handled.
    """
    results: list[dict] = []
    search_start = 0
    while True:
        idx = content.find("AlgorithmWrapper(", search_start)
        if idx == -1:
            break
        # Walk back to capture leading whitespace
        line_start = content.rfind("\n", 0, idx)
        line_start = 0 if line_start == -1 else line_start + 1
        leading = content[line_start:idx]

        # Find the matching closing paren using a depth counter
        paren_start = idx + len("AlgorithmWrapper")
        depth = 0
        i = paren_start
        while i < len(content):
            ch = content[i]
            if ch in ("(", "[", "{"):
                depth += 1
            elif ch in (")", "]", "}"):
                depth -= 1
                if depth == 0:
                    break
            elif ch == '"' or ch == "'":
                quote = ch
                i += 1
                while i < len(content) and content[i] != quote:
                    if content[i] == "\\":
                        i += 1
                    i += 1
            i += 1

        full_text = leading + content[idx:i + 1]

        # Extract the name= value
        name_match = re.search(r'name\s*=\s*["\']([^"\']+)["\']', full_text)
        name = name_match.group(1) if name_match else ""

        results.append({"name": name, "text": full_text})
        search_start = i + 1

    return results


def _merge_algorithm_wrappers(
    existing_path: pathlib.Path, new_content: str, ui_wrapper_names: list[str]
) -> str:
    """Merge unknown AlgorithmWrapper instances from existing algorithms.py.

    If the file exists, any AlgorithmWrapper whose ``name`` is NOT in
    ``ui_wrapper_names`` is appended into the generated ``ALGORITHM_CONFIG``.
    Extra import lines from above the managed zone are also preserved.
    """
    if not existing_path.exists():
        return new_content

    existing = existing_path.read_text()

    # Strip managed-zone marker to get just the managed section
    marker_idx = existing.find(SAFE_ZONE_MARKER)
    managed_section = existing[marker_idx + len(SAFE_ZONE_MARKER):] if marker_idx != -1 else existing

    existing_wrappers = _extract_existing_wrappers(managed_section)
    ui_names_lower = {n.lower() for n in ui_wrapper_names}
    unknown_wrappers = [
        w for w in existing_wrappers if w["name"].lower() not in ui_names_lower
    ]

    if not unknown_wrappers:
        return new_content

    # Collect extra import lines from the managed section that aren't in new_content
    extra_imports: list[str] = []
    for line in managed_section.splitlines():
        stripped = line.strip()
        if stripped.startswith(("from ", "import ")) and stripped not in new_content:
            extra_imports.append(stripped)

    # Append unknown wrappers into ALGORITHM_CONFIG before the closing ")"
    closing = "\n)"
    closing_idx = new_content.rfind(closing)
    if closing_idx == -1:
        closing = ")"
        closing_idx = new_content.rfind(closing)

    if closing_idx != -1:
        unknown_text = ",\n".join(w["text"] for w in unknown_wrappers)
        new_content = (
            new_content[:closing_idx].rstrip()
            + ",\n"
            + unknown_text
            + "\n"
            + new_content[closing_idx:]
        )

    # Prepend extra imports after the existing import block
    if extra_imports:
        import_block_end = 0
        for line in new_content.splitlines(keepends=True):
            stripped = line.strip()
            if stripped.startswith(("from ", "import ", "#")) or stripped == "":
                import_block_end += len(line)
            else:
                break
        extra_block = "\n".join(extra_imports) + "\n"
        new_content = new_content[:import_block_end] + extra_block + new_content[import_block_end:]

    return new_content


# ============================================================================
# File write models and endpoints
# ============================================================================

class DataManagerConfig(pydantic.BaseModel):
    """DataManager configuration model matching Python DataManager class."""
    test_size: float = 0.2
    n_splits: int = 5
    split_method: str = "shuffle"  # "shuffle" or "kfold"
    group_column: str | None = None
    stratified: bool = False
    random_state: int | None = None


class WriteDataFileRequest(pydantic.BaseModel):
    """Request model for writing data.py file."""
    base_data_manager: DataManagerConfig


class WriteDataFileResponse(pydantic.BaseModel):
    """Response model for data.py file creation."""
    success: bool
    file_path: str


def _generate_data_content(data: WriteDataFileRequest) -> str:
    """Generate data.py file content from configuration."""
    dm = data.base_data_manager
    params = []

    params.append(f"    test_size = {dm.test_size}")
    if dm.n_splits != 5:
        params.append(f"    n_splits = {dm.n_splits}")
    if dm.split_method != "shuffle":
        params.append(f'    split_method = "{dm.split_method}"')
    if dm.group_column:
        params.append(f'    group_column = "{dm.group_column}"')
    if dm.stratified:
        params.append(f"    stratified = {dm.stratified}")
    if dm.random_state is not None:
        params.append(f"    random_state = {dm.random_state}")

    params_str = ",\n".join(params)

    return f'''# data.py
from brisk.data.data_manager import DataManager

BASE_DATA_MANAGER = DataManager(
{params_str}
)
'''


@router.post("/data-file", response_model=WriteDataFileResponse)
async def write_data_file(
    request: fastapi.Request,
    data: WriteDataFileRequest,
):
    """Write the data.py file with BASE_DATA_MANAGER configuration."""
    settings = request.app.state.settings
    project_dir = settings.project_path
    data_file_path = project_dir / "data.py"
    raw_content = _generate_data_content(data)
    file_content = _merge_with_safe_zone(data_file_path, raw_content)

    try:
        with open(data_file_path, "w") as f:
            f.write(file_content)
        return WriteDataFileResponse(success=True, file_path=str(data_file_path))
    except Exception as e:
        raise fastapi.HTTPException(
            status_code=500,
            detail=f"Failed to write data.py: {str(e)}"
        )


class AlgorithmWrapperConfig(pydantic.BaseModel):
    """Configuration for a single AlgorithmWrapper."""
    name: str  # Unique identifier
    display_name: str  # Human-readable name
    class_name: str  # Python class name (e.g., "Ridge")
    class_module: str  # Python module (e.g., "sklearn.linear_model")
    default_params: dict[str, str | int | float | bool | None] = {}
    search_space: dict[str, list[str | int | float | bool]] = {}  # Hyperparameter search space (arrays)
    use_defaults: bool = True


class WriteAlgorithmsFileRequest(pydantic.BaseModel):
    """Request model for writing algorithms.py file."""
    wrappers: list[AlgorithmWrapperConfig]


class WriteAlgorithmsFileResponse(pydantic.BaseModel):
    """Response model for algorithms.py file creation."""
    success: bool
    file_path: str


def _generate_algorithms_content(data: WriteAlgorithmsFileRequest) -> str:
    """Generate algorithms.py file content from configuration."""
    imports_by_module: dict[str, set[str]] = {}
    for wrapper in data.wrappers:
        if wrapper.class_module not in imports_by_module:
            imports_by_module[wrapper.class_module] = set()
        imports_by_module[wrapper.class_module].add(wrapper.class_name)

    import_lines = ["from brisk.configuration.algorithm_wrapper import AlgorithmWrapper"]
    import_lines.append("import brisk")
    for module, classes in sorted(imports_by_module.items()):
        classes_str = ", ".join(sorted(classes))
        import_lines.append(f"from {module} import {classes_str}")
    imports_str = "\n".join(import_lines)

    wrapper_strs = []
    for wrapper in data.wrappers:
        params_parts = [
            f'        name="{wrapper.name}"',
            f'        display_name="{wrapper.display_name}"',
            f'        algorithm_class={wrapper.class_name}',
        ]
        if wrapper.default_params and not wrapper.use_defaults:
            params_dict_str = _format_params_dict(wrapper.default_params)
            params_parts.append(f'        default_params={params_dict_str}')
        if wrapper.search_space:
            search_space_str = _format_search_space_dict(wrapper.search_space, indent=12)
            if search_space_str != "{}":
                params_parts.append(f'        hyperparam_grid={search_space_str}')
        params_str = ",\n".join(params_parts)
        wrapper_strs.append(f"    AlgorithmWrapper(\n{params_str},\n    )")

    wrappers_str = ",\n".join(wrapper_strs)

    return f'''# algorithms.py
{imports_str}

ALGORITHM_CONFIG = brisk.AlgorithmCollection(
{wrappers_str}
)
'''


@router.post("/algorithms-file", response_model=WriteAlgorithmsFileResponse)
async def write_algorithms_file(
    request: fastapi.Request,
    data: WriteAlgorithmsFileRequest,
):
    """Write the algorithms.py file with ALGORITHM_CONFIG."""
    settings = request.app.state.settings
    project_dir = settings.project_path
    algorithms_file_path = project_dir / "algorithms.py"
    raw_content = _generate_algorithms_content(data)
    ui_names = [w.name for w in data.wrappers]
    merged = _merge_algorithm_wrappers(algorithms_file_path, raw_content, ui_names)
    file_content = _merge_with_safe_zone(algorithms_file_path, merged)

    try:
        with open(algorithms_file_path, "w") as f:
            f.write(file_content)
        return WriteAlgorithmsFileResponse(success=True, file_path=str(algorithms_file_path))
    except Exception as e:
        raise fastapi.HTTPException(
            status_code=500,
            detail=f"Failed to write algorithms.py: {str(e)}"
        )


def _format_params_dict(params: dict[str, str | int | float | bool | None]) -> str:
    """Format a params dict as a Python dict literal."""
    if not params:
        return "{}"
    
    parts = []
    for key, value in params.items():
        if isinstance(value, str) and value.lower() == "none":
            parts.append(f'"{key}": None')
        elif isinstance(value, str):
            parts.append(f'"{key}": "{value}"')
        elif isinstance(value, bool):
            parts.append(f'"{key}": {value}')
        elif value is None:
            parts.append(f'"{key}": None')
        else:
            parts.append(f'"{key}": {value}')
    
    return "{" + ", ".join(parts) + "}"


def _format_search_space_dict(
    search_space: dict[str, list[str | int | float | bool]],
    indent: int = 0,
) -> str:
    """Format a search space dict as a multi-line Python dict literal with lists."""
    if not search_space:
        return "{}"
    
    parts = []
    for key, values in search_space.items():
        if not values:
            continue
        
        formatted_values = []
        for v in values:
            if isinstance(v, str):
                formatted_values.append(f'"{v}"')
            elif isinstance(v, bool):
                formatted_values.append(str(v))
            else:
                formatted_values.append(str(v))
        
        list_str = "[" + ", ".join(formatted_values) + "]"
        parts.append(f'"{key}": {list_str}')
    
    if not parts:
        return "{}"
    
    inner_indent = " " * indent
    closing_indent = " " * (indent - 4) if indent >= 4 else ""
    entries = (",\n" + inner_indent).join(parts)
    return "{\n" + inner_indent + entries + "\n" + closing_indent + "}"


def _get_project_dir(settings, create_mode: bool = False):
    """Get the project directory. Settings.project_path is always up-to-date
    because create_project updates it immediately after project creation."""
    return settings.project_path


class WriteMetricsFileRequest(pydantic.BaseModel):
    """Request model for writing metrics.py file."""
    problem_type: str  # "classification" or "regression"


class WriteMetricsFileResponse(pydantic.BaseModel):
    """Response model for metrics.py file creation."""
    success: bool
    file_path: str


def _generate_metrics_content(data: WriteMetricsFileRequest) -> str:
    """Generate metrics.py file content from configuration."""
    if data.problem_type == "classification":
        metrics_line = "*brisk.CLASSIFICATION_METRICS"
    else:
        metrics_line = "*brisk.REGRESSION_METRICS"

    return f'''# metrics.py
import brisk

METRIC_CONFIG = brisk.MetricManager(
    {metrics_line}
)
'''


@router.post("/metrics-file", response_model=WriteMetricsFileResponse)
async def write_metrics_file(
    request: fastapi.Request,
    data: WriteMetricsFileRequest,
):
    """Write the metrics.py file based on problem type."""
    settings = request.app.state.settings
    project_dir = settings.project_path
    metrics_file_path = project_dir / "metrics.py"
    raw_content = _generate_metrics_content(data)
    file_content = _merge_with_safe_zone(metrics_file_path, raw_content)

    try:
        with open(metrics_file_path, "w") as f:
            f.write(file_content)
        return WriteMetricsFileResponse(success=True, file_path=str(metrics_file_path))
    except Exception as e:
        raise fastapi.HTTPException(
            status_code=500,
            detail=f"Failed to write metrics.py: {str(e)}"
        )


class WriteEvaluatorsFileResponse(pydantic.BaseModel):
    """Response model for evaluators.py file creation."""
    success: bool
    file_path: str


@router.post("/evaluators-file", response_model=WriteEvaluatorsFileResponse)
async def write_evaluators_file(request: fastapi.Request):
    """Write the evaluators.py file (template).
    
    Creates a boilerplate evaluators.py file in the project directory
    for custom evaluator registration.
    """
    settings = request.app.state.settings
    project_dir = settings.project_path
    evaluators_file_path = project_dir / "evaluators.py"
    
    file_content = '''# evaluators.py
# Define custom evaluation methods here to integrate with Brisk's builtin tools
from brisk.evaluation.evaluators.registry import EvaluatorRegistry
from brisk import PlotEvaluator, MeasureEvaluator

def register_custom_evaluators(registry: EvaluatorRegistry, plot_settings) -> None:
    # registry.register(
    # Initalize an evaluator instance here to register
    # )
    pass
'''
    
    try:
        with open(evaluators_file_path, "w") as f:
            f.write(file_content)
        
        return WriteEvaluatorsFileResponse(
            success=True,
            file_path=str(evaluators_file_path)
        )
    except Exception as e:
        raise fastapi.HTTPException(
            status_code=500,
            detail=f"Failed to write evaluators.py: {str(e)}"
        )


# --- Workflow file ---

class WorkflowStepConfig(pydantic.BaseModel):
    """A single workflow step (evaluator call)."""
    evaluator_id: str
    method_name: str
    args: dict = {}


class WriteWorkflowFileRequest(pydantic.BaseModel):
    """Request model for writing workflows/<problem_type>.py file."""
    problem_type: str  # "classification" or "regression"
    steps: list[WorkflowStepConfig]


class WriteWorkflowFileResponse(pydantic.BaseModel):
    """Response model for workflow file creation."""
    success: bool
    file_path: str


# Methods that take X, y as np.ndarray (emit X.values, y.values)
_WORKFLOW_ARRAY_DATA_METHODS = frozenset({
    "confusion_matrix",
    "plot_confusion_heatmap",
    "plot_roc_curve",
    "plot_precision_recall_curve",
})


def _format_workflow_step_call(step: WorkflowStepConfig, problem_type: str) -> str:
    """Format a single workflow step as a Python method call.
    Uses self.model for model arg; X_train, X_test, y_train, y_test from workflow params.
    """
    method = step.method_name
    args = step.args or {}

    def get_data_var(key: str, default: str = "X_test") -> str:
        v = args.get(key)
        if v is None or v == "":
            return default
        return str(v)

    if method == "fit_model":
        X = get_data_var("X", "X_train")
        y = get_data_var("y", "y_train")
        return f'        self.model.fit({X}, {y})'
    if method == "evaluate_model":
        X = get_data_var("X", "X_test")
        y = get_data_var("y", "y_test")
        metrics_raw = args.get("metrics") or "MAE"
        if isinstance(metrics_raw, list):
            metrics_str = ", ".join(f'"{m}"' for m in metrics_raw)
        else:
            parts = [s.strip() for s in str(metrics_raw).split(",") if s.strip()]
            metrics_str = ", ".join(f'"{p}"' for p in parts) if parts else '"MAE"'
        filename = args.get("filename") or "evaluate_model"
        return f'        self.evaluate_model(self.model, {X}, {y}, [{metrics_str}], "{filename}")'
    if method == "evaluate_model_cv":
        X = get_data_var("X", "X_train")
        y = get_data_var("y", "y_train")
        metrics_raw = args.get("metrics") or "MAE"
        if isinstance(metrics_raw, list):
            metrics_str = ", ".join(f'"{m}"' for m in metrics_raw)
        else:
            parts = [s.strip() for s in str(metrics_raw).split(",") if s.strip()]
            metrics_str = ", ".join(f'"{p}"' for p in parts) if parts else '"MAE"'
        filename = args.get("filename") or "evaluate_model_cv"
        cv = args.get("cv")
        cv_val = int(cv) if cv is not None and str(cv).strip() != "" else 5
        return f'        self.evaluate_model_cv(self.model, {X}, {y}, [{metrics_str}], "{filename}", cv={cv_val})'
    if method == "plot_pred_vs_obs":
        X = get_data_var("X", "X_test")
        y = get_data_var("y", "y_test")
        filename = args.get("filename") or "pred_vs_obs"
        return f'        self.plot_pred_vs_obs(self.model, {X}, {y}, "{filename}")'
    if method == "plot_learning_curve":
        X_train = get_data_var("X", "X_train")
        y_train = get_data_var("y", "y_train")
        filename = args.get("filename") or "learning_curve"
        cv = args.get("cv")
        cv_val = int(cv) if cv is not None and str(cv).strip() != "" else 5
        num_repeats = args.get("num_repeats")
        num_repeats_val = int(num_repeats) if num_repeats is not None and str(num_repeats).strip() != "" else 1
        n_jobs = args.get("n_jobs")
        n_jobs_val = int(n_jobs) if n_jobs is not None and str(n_jobs).strip() != "" else -1
        metric = args.get("metric") or "MAE"
        return f'        self.plot_learning_curve(self.model, {X_train}, {y_train}, filename="{filename}", cv={cv_val}, num_repeats={num_repeats_val}, n_jobs={n_jobs_val}, metric="{metric}")'
    if method == "plot_feature_importance":
        X = get_data_var("X", "X_train")
        y = get_data_var("y", "y_train")
        threshold = args.get("threshold")
        thresh_val = int(threshold) if threshold is not None and str(threshold).strip() != "" else 10
        filename = args.get("filename") or "feature_importance"
        metric = args.get("metric") or "MAE"
        num_rep = args.get("num_rep")
        num_rep_val = int(num_rep) if num_rep is not None and str(num_rep).strip() != "" else 5
        return f'        self.plot_feature_importance(self.model, {X}, {y}, {thresh_val}, feature_names, "{filename}", metric="{metric}", num_rep={num_rep_val})'
    if method == "plot_residuals":
        X = get_data_var("X", "X_test")
        y = get_data_var("y", "y_test")
        filename = args.get("filename") or "residuals"
        add_fit = args.get("add_fit_line")
        add_fit_val = "True" if add_fit else "False"
        return f'        self.plot_residuals(self.model, {X}, {y}, "{filename}", add_fit_line={add_fit_val})'
    if method == "hyperparameter_tuning":
        X_train = get_data_var("X", "X_train")
        y_train = get_data_var("y", "y_train")
        method_type = args.get("method") or "grid"
        scorer = args.get("scorer") or "MAE"
        kf = args.get("kf")
        kf_val = int(kf) if kf is not None and str(kf).strip() != "" else 5
        num_rep = args.get("num_rep")
        num_rep_val = int(num_rep) if num_rep is not None and str(num_rep).strip() != "" else 3
        n_jobs = args.get("n_jobs")
        n_jobs_val = int(n_jobs) if n_jobs is not None and str(n_jobs).strip() != "" else -1
        plot_res = args.get("plot_results")
        plot_res_val = "True" if plot_res else "False"
        return f'        self.model = self.hyperparameter_tuning(self.model, "{method_type}", {X_train}, {y_train}, "{scorer}", {kf_val}, {num_rep_val}, {n_jobs_val}, plot_results={plot_res_val})'
    if method == "confusion_matrix":
        X = get_data_var("X", "X_test")
        y = get_data_var("y", "y_test")
        filename = args.get("filename") or "confusion_matrix"
        return f'        self.confusion_matrix(self.model, {X}.values, {y}.values, "{filename}")'
    if method == "plot_confusion_heatmap":
        X = get_data_var("X", "X_test")
        y = get_data_var("y", "y_test")
        filename = args.get("filename") or "confusion_heatmap"
        return f'        self.plot_confusion_heatmap(self.model, {X}.values, {y}.values, "{filename}")'
    if method == "plot_roc_curve":
        X = get_data_var("X", "X_test")
        y = get_data_var("y", "y_test")
        filename = args.get("filename") or "roc_curve"
        pos_label = args.get("pos_label")
        pos_val = int(pos_label) if pos_label is not None and str(pos_label).strip() != "" else 1
        return f'        self.plot_roc_curve(self.model, {X}.values, {y}.values, "{filename}", pos_label={pos_val})'
    if method == "plot_precision_recall_curve":
        X = get_data_var("X", "X_test")
        y = get_data_var("y", "y_test")
        filename = args.get("filename") or "precision_recall_curve"
        pos_label = args.get("pos_label")
        pos_val = int(pos_label) if pos_label is not None and str(pos_label).strip() != "" else 1
        return f'        self.plot_precision_recall_curve(self.model, {X}.values, {y}.values, "{filename}", pos_label={pos_val})'
    if method == "plot_shapley_values":
        X = get_data_var("X", "X_test")
        y = get_data_var("y", "y_test")
        filename = args.get("filename") or "shapley_values"
        plot_type = args.get("plot_type") or "bar"
        return f'        self.plot_shapley_values(self.model, {X}, {y}, filename="{filename}", plot_type="{plot_type}")'
    if method == "save_model":
        filename = args.get("filename") or "model"
        return f'        self.save_model(self.model, "{filename}")'
    return ""


def _generate_workflow_content(data: WriteWorkflowFileRequest) -> str:
    """Generate workflow file content from configuration."""
    problem_type = data.problem_type
    if problem_type not in ("classification", "regression"):
        problem_type = "regression"
    class_name = problem_type.capitalize()

    step_lines = []
    for step in data.steps:
        line = _format_workflow_step_call(step, problem_type)
        if line:
            step_lines.append(line)

    body = "\n".join(step_lines) if step_lines else "        pass"

    return f'''# workflow.py
# Define the workflow for training and evaluating models

from brisk.training.workflow import Workflow


class {class_name}(Workflow):
    def workflow(self, X_train, X_test, y_train, y_test, output_dir, feature_names):
{body}
'''


@router.post("/workflow-file", response_model=WriteWorkflowFileResponse)
async def write_workflow_file(
    request: fastapi.Request,
    data: WriteWorkflowFileRequest,
):
    """Write the workflow file to workflows/<problem_type>.py."""
    settings = request.app.state.settings
    project_dir = settings.project_path
    workflows_dir = project_dir / "workflows"
    workflows_dir.mkdir(parents=True, exist_ok=True)
    problem_type = data.problem_type
    if problem_type not in ("classification", "regression"):
        problem_type = "regression"
    workflow_file_path = workflows_dir / f"{problem_type}.py"
    raw_content = _generate_workflow_content(data)
    file_content = _merge_with_safe_zone(workflow_file_path, raw_content)

    try:
        with open(workflow_file_path, "w") as f:
            f.write(file_content)
        return WriteWorkflowFileResponse(success=True, file_path=str(workflow_file_path))
    except Exception as e:
        raise fastapi.HTTPException(
            status_code=500,
            detail=f"Failed to write workflow file: {str(e)}"
        )


# --- Read Workflow Steps ---

class WorkflowStepInfo(pydantic.BaseModel):
    """Information about a single workflow step parsed from file."""
    evaluator_id: str
    method_name: str
    args: dict = {}


class WorkflowDataResponse(pydantic.BaseModel):
    """Response model for workflow data."""
    steps: list[WorkflowStepInfo]
    problem_type: str


def _parse_workflow_step(line: str) -> WorkflowStepInfo | None:
    """Parse a workflow step from a Python method call line.
    
    Attempts to extract the method name and arguments from lines like:
        self.evaluate_model(self.model, X_test, y_test, ["MAE"], "evaluate_model")
        self.plot_pred_vs_obs(self.model, X_train, y_train, "pred_vs_obs")
    """
    import re
    
    # Match method calls on self
    line = line.strip()

    # Handle self.model.fit(X, y)
    if line.startswith("self.model.fit("):
        args: dict = {}
        if "X_train" in line:
            args["X"] = "X_train"
        elif "X_test" in line:
            args["X"] = "X_test"
        if "y_train" in line:
            args["y"] = "y_train"
        elif "y_test" in line:
            args["y"] = "y_test"
        return WorkflowStepInfo(
            evaluator_id="fit_model",
            method_name="fit_model",
            args=args,
        )

    # Handle self.model = self.hyperparameter_tuning(...)
    if line.startswith("self.model") and "self.hyperparameter_tuning(" in line:
        line = line.replace("self.model", "", 1).lstrip().lstrip("=").strip()

    if not line.startswith("self."):
        return None
    
    # Extract method name
    method_match = re.match(r"self\.(\w+)\(", line)
    if not method_match:
        return None
    
    method_name = method_match.group(1)
    
    # Skip methods that aren't workflow evaluators
    known_methods = {
        "evaluate_model", "evaluate_model_cv", "plot_pred_vs_obs",
        "plot_learning_curve", "plot_feature_importance", "plot_residuals",
        "hyperparameter_tuning", "confusion_matrix", "plot_confusion_heatmap",
        "plot_roc_curve", "plot_precision_recall_curve",
        "save_model", "plot_shapley_values",
    }
    if method_name not in known_methods:
        return None
    
    # Parse arguments (basic parsing)
    args: dict = {}
    
    # Map method_name to evaluator_id
    evaluator_id = method_name
    
    # Extract common args patterns
    # Look for filename argument (usually last quoted string)
    filename_match = re.search(r'"([^"]+)"(?:\s*\)|\s*,\s*\w+=)', line)
    if filename_match:
        args["filename"] = filename_match.group(1)
    
    # Look for X and y variables
    if "X_train" in line:
        args["X"] = "X_train"
    elif "X_test" in line:
        args["X"] = "X_test"
    
    if "y_train" in line:
        args["y"] = "y_train"
    elif "y_test" in line:
        args["y"] = "y_test"
    
    # Look for metrics array
    metrics_match = re.search(r'\[(["\'][^"\']+["\'](?:\s*,\s*["\'][^"\']+["\'])*)\]', line)
    if metrics_match:
        metrics_str = metrics_match.group(1)
        # Parse individual metrics
        metrics = re.findall(r'["\']([^"\']+)["\']', metrics_str)
        if metrics:
            args["metrics"] = metrics
    
    # Look for cv parameter
    cv_match = re.search(r'cv=(\d+)', line)
    if cv_match:
        args["cv"] = int(cv_match.group(1))
    
    # Look for n_jobs parameter
    n_jobs_match = re.search(r'n_jobs=(-?\d+)', line)
    if n_jobs_match:
        args["n_jobs"] = int(n_jobs_match.group(1))
    
    # Look for num_repeats/num_rep parameter (preserve original key name)
    num_rep_match = re.search(r'(num_rep(?:eats)?)=(\d+)', line)
    if num_rep_match:
        args[num_rep_match.group(1)] = int(num_rep_match.group(2))
    
    # Look for metric parameter (for learning curve, feature importance)
    metric_match = re.search(r'metric="([^"]+)"', line)
    if metric_match:
        args["metric"] = metric_match.group(1)
    
    # Look for add_fit_line parameter
    if "add_fit_line=True" in line:
        args["add_fit_line"] = True
    elif "add_fit_line=False" in line:
        args["add_fit_line"] = False
    
    # Look for plot_results parameter
    if "plot_results=True" in line:
        args["plot_results"] = True
    elif "plot_results=False" in line:
        args["plot_results"] = False
    
    # Look for method parameter (for hyperparameter_tuning)
    method_type_match = re.search(r'"(grid|random)"', line)
    if method_name == "hyperparameter_tuning" and method_type_match:
        args["method"] = method_type_match.group(1)
    
    # Look for scorer parameter (named or positional)
    scorer_match = re.search(r'scorer="([^"]+)"', line)
    if not scorer_match and method_name == "hyperparameter_tuning":
        # Scorer is the 2nd quoted string (after method type "grid"/"random")
        all_quoted = re.findall(r'"([^"]+)"', line)
        if len(all_quoted) >= 2:
            args["scorer"] = all_quoted[1]
    elif scorer_match:
        args["scorer"] = scorer_match.group(1)
    
    return WorkflowStepInfo(
        evaluator_id=evaluator_id,
        method_name=method_name,
        args=args
    )


@router.get("/workflow-data", response_model=WorkflowDataResponse)
async def get_workflow_data(settings: Settings = fastapi.Depends(get_settings)):
    """Get workflow steps from the current workflow file.
    
    Parses the workflow Python file and extracts evaluator steps.
    """
    project_dir = settings.project_path
    if not project_dir:
        raise fastapi.HTTPException(status_code=400, detail="Project path not set")
    
    # Get project type from config
    config_path = project_dir / ".brisk" / "project.json"
    project_type = "classification"
    if config_path.exists():
        try:
            import json
            with open(config_path) as f:
                config = json.load(f)
                project_type = config.get("project_type", "classification")
        except Exception:
            pass
    
    # Read workflow file
    workflow_file = project_dir / "workflows" / f"{project_type}.py"
    
    steps: list[WorkflowStepInfo] = []
    
    if workflow_file.exists():
        try:
            with open(workflow_file) as f:
                content = f.read()
            
            # Parse each line looking for self.method_name() calls
            for line in content.split("\n"):
                step = _parse_workflow_step(line)
                if step:
                    steps.append(step)
        except Exception as e:
            # Return empty on parse error
            pass
    
    return WorkflowDataResponse(
        steps=steps,
        problem_type=project_type
    )


# --- Plot Settings API ---

class PlotSettingsResponse(pydantic.BaseModel):
    """Response model for plot settings."""
    file_format: str = "png"
    transparent: bool = False
    width: int = 10
    height: int = 8
    dpi: int = 300
    primary_color: str = "#1175D5"
    secondary_color: str = "#00A878"
    accent_color: str = "#DE6B48"


def _parse_plot_settings_from_file(content: str) -> PlotSettingsResponse:
    """Parse PlotSettings from settings.py content."""
    result = PlotSettingsResponse()
    
    # Look for PlotSettings(...) instantiation
    plot_settings_match = re.search(r'PlotSettings\s*\(([^)]*)\)', content, re.DOTALL)
    if not plot_settings_match:
        return result
    
    args_str = plot_settings_match.group(1)
    
    # Parse individual arguments
    # file_format="png"
    fmt_match = re.search(r'file_format\s*=\s*["\']([^"\']+)["\']', args_str)
    if fmt_match:
        result.file_format = fmt_match.group(1)
    
    # transparent=True/False
    trans_match = re.search(r'transparent\s*=\s*(True|False)', args_str)
    if trans_match:
        result.transparent = trans_match.group(1) == "True"
    
    # width=10
    width_match = re.search(r'width\s*=\s*(\d+)', args_str)
    if width_match:
        result.width = int(width_match.group(1))
    
    # height=8
    height_match = re.search(r'height\s*=\s*(\d+)', args_str)
    if height_match:
        result.height = int(height_match.group(1))
    
    # dpi=300
    dpi_match = re.search(r'dpi\s*=\s*(\d+)', args_str)
    if dpi_match:
        result.dpi = int(dpi_match.group(1))
    
    # primary_color="#..."
    primary_match = re.search(r'primary_color\s*=\s*["\']([^"\']+)["\']', args_str)
    if primary_match:
        result.primary_color = primary_match.group(1)
    
    # secondary_color="#..."
    secondary_match = re.search(r'secondary_color\s*=\s*["\']([^"\']+)["\']', args_str)
    if secondary_match:
        result.secondary_color = secondary_match.group(1)
    
    # accent_color="#..."
    accent_match = re.search(r'accent_color\s*=\s*["\']([^"\']+)["\']', args_str)
    if accent_match:
        result.accent_color = accent_match.group(1)
    
    return result


@router.get("/plot-settings", response_model=PlotSettingsResponse)
async def get_plot_settings(settings: Settings = fastapi.Depends(get_settings)):
    """Get plot settings from settings.py file.
    
    Returns default values if settings.py doesn't exist or doesn't have PlotSettings.
    """
    project_dir = settings.project_path
    if not project_dir:
        return PlotSettingsResponse()
    
    settings_file = project_dir / "settings.py"
    if not settings_file.exists():
        return PlotSettingsResponse()
    
    try:
        content = settings_file.read_text()
        return _parse_plot_settings_from_file(content)
    except Exception:
        return PlotSettingsResponse()


class ExperimentGroupDataConfig(pydantic.BaseModel):
    """DataManager config for an experiment group (data_config parameter)."""
    test_size: float | None = None
    n_splits: int | None = None
    split_method: str | None = None
    group_column: str | None = None
    stratified: bool | None = None
    random_state: int | None = None
    preprocessors: list[dict] | None = None  # list of {type, config} for each preprocessor


class ExperimentGroupConfig(pydantic.BaseModel):
    """Configuration for a single experiment group."""
    name: str
    description: str = ""
    dataset_file_name: str
    dataset_table_name: str | None = None
    algorithms: list[str]
    use_default_data_manager: bool = True
    data_config: ExperimentGroupDataConfig | None = None


class PlotSettingsPayload(pydantic.BaseModel):
    """PlotSettings payload; only non-default values are written."""
    file_format: str | None = None
    transparent: bool | None = None
    width: int | None = None
    height: int | None = None
    dpi: int | None = None
    primary_color: str | None = None
    secondary_color: str | None = None
    accent_color: str | None = None


class CategoricalFeaturesEntry(pydantic.BaseModel):
    """Entry for categorical features mapping."""
    dataset_file_name: str  # e.g., "data.csv" or "data.sqlite"
    table_name: str | None = None  # for SQLite, the table name
    features: list[str]  # list of categorical feature names


class WriteSettingsFileRequest(pydantic.BaseModel):
    """Request model for writing settings.py file."""
    problem_type: str  # "classification" or "regression"
    default_algorithms: list[str]  # list of all algorithm names
    experiment_groups: list[ExperimentGroupConfig]
    categorical_features: list[CategoricalFeaturesEntry] | None = None  # optional categorical features mapping
    plot_settings: PlotSettingsPayload | None = None


class WriteSettingsFileResponse(pydantic.BaseModel):
    """Response model for settings.py file creation."""
    success: bool
    file_path: str


def _format_preprocessor_instance(preproc_type: str, config: dict, problem_type: str) -> str:
    """Format a single preprocessor as Python instantiation code.
    Maps frontend preprocessor types/config to Brisk class constructors.
    Brisk pipeline order: Missing Data -> Categorical Encoding -> Scaling -> Feature Selection.
    """
    if preproc_type == "missing-data":
        strategy = config.get("strategy", "mean")
        if strategy == "drop":
            return "MissingDataPreprocessor(strategy=\"drop_rows\")"
        # strategy is impute with impute_method
        impute_method = strategy if strategy != "most_frequent" else "mode"
        constant_value = config.get("fillValue")
        if impute_method == "constant" and constant_value is not None:
            try:
                cv = float(constant_value)
                return f"MissingDataPreprocessor(strategy=\"impute\", impute_method=\"constant\", constant_value={cv})"
            except (TypeError, ValueError):
                return f"MissingDataPreprocessor(strategy=\"impute\", impute_method=\"constant\", constant_value=\"{constant_value}\")"
        return f"MissingDataPreprocessor(strategy=\"impute\", impute_method=\"{impute_method}\")"
    if preproc_type == "scaling":
        method = config.get("method", "standard")
        return f"ScalingPreprocessor(method=\"{method}\")"
    if preproc_type == "encoding":
        method = config.get("method", "label")
        if method == "target":
            method = "label"
        return f"CategoricalEncodingPreprocessor(method=\"{method}\")"
    if preproc_type == "feature-selection":
        method = config.get("method", "selectkbest")
        # Map frontend method to Brisk: variance|univariate -> selectkbest, recursive -> rfecv, lasso -> sequential
        brisk_method = {"variance": "selectkbest", "univariate": "selectkbest", "recursive": "rfecv", "lasso": "sequential"}.get(method, "selectkbest")
        n_features = config.get("nFeatures", 5)
        if n_features == "auto":
            n_features = 5
        try:
            n_features = int(n_features)
        except (TypeError, ValueError):
            n_features = 5
        return f"FeatureSelectionPreprocessor(method=\"{brisk_method}\", n_features_to_select={n_features}, feature_selection_cv=3, problem_type=\"{problem_type}\")"
    return ""


def _format_preprocessors_list(preprocessors: list[dict], problem_type: str) -> str | None:
    """Format preprocessors list for data_config. Returns Python code for the list or None."""
    if not preprocessors:
        return None
    # Brisk pipeline order: missing-data -> encoding -> scaling -> feature-selection
    order = ("missing-data", "encoding", "scaling", "feature-selection")
    ordered = []
    for key in order:
        for p in preprocessors:
            if p.get("type") == key:
                code = _format_preprocessor_instance(key, p.get("config") or {}, problem_type)
                if code:
                    ordered.append(f"            {code},")
                break
    if not ordered:
        return None
    return "[\n" + "\n".join(ordered) + "\n        ]"


def _generate_settings_content(data: WriteSettingsFileRequest) -> str:
    """Generate settings.py file content from configuration."""
    _plot_defaults = {
        "file_format": "png",
        "transparent": False,
        "width": 10,
        "height": 8,
        "dpi": 300,
        "primary_color": "#1175D5",
        "secondary_color": "#00A878",
        "accent_color": "#DE6B48",
    }
    plot_kwargs: dict[str, str | int | bool] = {}
    if data.plot_settings:
        ps = data.plot_settings
        if ps.file_format is not None and ps.file_format != _plot_defaults["file_format"]:
            plot_kwargs["file_format"] = ps.file_format
        if ps.transparent is not None and ps.transparent != _plot_defaults["transparent"]:
            plot_kwargs["transparent"] = ps.transparent
        if ps.width is not None and ps.width != _plot_defaults["width"]:
            plot_kwargs["width"] = ps.width
        if ps.height is not None and ps.height != _plot_defaults["height"]:
            plot_kwargs["height"] = ps.height
        if ps.dpi is not None and ps.dpi != _plot_defaults["dpi"]:
            plot_kwargs["dpi"] = ps.dpi
        if ps.primary_color is not None and ps.primary_color != _plot_defaults["primary_color"]:
            plot_kwargs["primary_color"] = ps.primary_color
        if ps.secondary_color is not None and ps.secondary_color != _plot_defaults["secondary_color"]:
            plot_kwargs["secondary_color"] = ps.secondary_color
        if ps.accent_color is not None and ps.accent_color != _plot_defaults["accent_color"]:
            plot_kwargs["accent_color"] = ps.accent_color

    algorithms_str = ", ".join(f'"{a}"' for a in data.default_algorithms)

    needs_preprocessors_import = any(
        group.data_config and group.data_config.preprocessors
        for group in data.experiment_groups
    )

    group_strs = []
    for group in data.experiment_groups:
        parts = [f'        name="{group.name}"']
        if group.description:
            parts.append(f'        description="{group.description}"')
        if group.dataset_table_name:
            parts.append(f'        datasets=[("{group.dataset_file_name}", "{group.dataset_table_name}")]')
        else:
            parts.append(f'        datasets=["{group.dataset_file_name}"]')
        alg_str = ", ".join(f'"{a}"' for a in group.algorithms)
        parts.append(f'        algorithms=[{alg_str}]')
        dc = group.data_config
        has_dc_params = dc and (
            dc.test_size is not None or dc.n_splits is not None or dc.split_method is not None
            or dc.group_column is not None or dc.stratified is not None or dc.random_state is not None
        )
        has_preprocessors = dc and dc.preprocessors
        if has_preprocessors or (not group.use_default_data_manager and has_dc_params):
            dc_parts = []
            if dc:
                if dc.test_size is not None:
                    dc_parts.append(f'"test_size": {dc.test_size}')
                if dc.n_splits is not None:
                    dc_parts.append(f'"n_splits": {dc.n_splits}')
                if dc.split_method is not None:
                    dc_parts.append(f'"split_method": "{dc.split_method}"')
                if dc.group_column is not None:
                    dc_parts.append(f'"group_column": "{dc.group_column}"')
                if dc.stratified is not None:
                    dc_parts.append(f'"stratified": {dc.stratified}')
                if dc.random_state is not None:
                    dc_parts.append(f'"random_state": {dc.random_state}')
                preprocessors_code = _format_preprocessors_list(dc.preprocessors or [], data.problem_type)
                if preprocessors_code:
                    dc_parts.append(f'"preprocessors": {preprocessors_code}')
            if dc_parts:
                dc_str = ", ".join(dc_parts)
                parts.append(f'        data_config={{{dc_str}}}')
        params_str = ",\n".join(parts)
        group_strs.append(f"    config.add_experiment_group(\n{params_str},\n    )")

    groups_code = "\n\n".join(group_strs)

    preprocessors_import = ""
    if needs_preprocessors_import:
        preprocessors_import = "\nfrom brisk.data.preprocessing import (\n    MissingDataPreprocessor,\n    ScalingPreprocessor,\n    CategoricalEncodingPreprocessor,\n    FeatureSelectionPreprocessor,\n)\n"

    plot_settings_import = ""
    plot_settings_var = ""
    config_plot_arg = ""
    if plot_kwargs:
        plot_settings_import = "\nfrom brisk.theme.plot_settings import PlotSettings\n"
        kwargs_str = ", ".join(
            f'{k}="{v}"' if isinstance(v, str) else f"{k}={v}"
            for k, v in plot_kwargs.items()
        )
        plot_settings_var = f"\n    plot_settings = PlotSettings({kwargs_str})\n"
        config_plot_arg = ",\n        plot_settings=plot_settings"

    cat_entries = []
    if data.categorical_features:
        for entry in data.categorical_features:
            if not entry.features:
                continue
            features_str = ", ".join(f'"{f}"' for f in entry.features)
            if entry.table_name:
                cat_entries.append(f'            ("{entry.dataset_file_name}", "{entry.table_name}"): [{features_str}]')
            else:
                cat_entries.append(f'            "{entry.dataset_file_name}": [{features_str}]')
    if cat_entries:
        categorical_features_arg = ",\n        categorical_features={\n" + ",\n".join(cat_entries) + ",\n        }"
    else:
        categorical_features_arg = ",\n        categorical_features={}"

    return f'''# settings.py
from brisk.configuration.configuration import Configuration
from brisk.configuration.configuration_manager import ConfigurationManager
{preprocessors_import}{plot_settings_import}

def create_configuration() -> ConfigurationManager:
{plot_settings_var}    config = Configuration(
        default_workflow="{data.problem_type}",
        default_algorithms=[{algorithms_str}]{categorical_features_arg}{config_plot_arg}
    )

{groups_code}

    return config.build()
'''


@router.post("/settings-file", response_model=WriteSettingsFileResponse)
async def write_settings_file(
    request: fastapi.Request,
    data: WriteSettingsFileRequest,
):
    """Write the settings.py file with Configuration."""
    settings = request.app.state.settings
    project_dir = settings.project_path
    settings_file_path = project_dir / "settings.py"
    raw_content = _generate_settings_content(data)
    file_content = _merge_with_safe_zone(settings_file_path, raw_content)

    try:
        with open(settings_file_path, "w") as f:
            f.write(file_content)
        return WriteSettingsFileResponse(success=True, file_path=str(settings_file_path))
    except Exception as e:
        raise fastapi.HTTPException(
            status_code=500,
            detail=f"Failed to write settings.py: {str(e)}"
        )


# ============================================================================
# Preview endpoint
# ============================================================================

class PreviewFilesRequest(pydantic.BaseModel):
    """Combined request for previewing all generated files."""
    data_file: WriteDataFileRequest | None = None
    algorithms_file: WriteAlgorithmsFileRequest | None = None
    metrics_file: WriteMetricsFileRequest | None = None
    settings_file: WriteSettingsFileRequest | None = None
    workflow_file: WriteWorkflowFileRequest | None = None


class PreviewFilesResponse(pydantic.BaseModel):
    """Response containing generated file contents."""
    files: dict[str, str]


def _read_existing_file(path: pathlib.Path) -> str | None:
    """Read an existing file and return its content, or None if missing/empty."""
    try:
        if path.exists() and path.stat().st_size > 0:
            return path.read_text()
    except OSError:
        pass
    return None


@router.post("/preview-files", response_model=PreviewFilesResponse)
async def preview_files(
    request: fastapi.Request,
    data: PreviewFilesRequest,
):
    """Generate file contents without writing to disk.

    For each file type: if the request includes config data, generate a preview
    with safe-zone merging. Otherwise, fall back to the current on-disk content
    so the Files page always shows all managed files regardless of which pages
    have been visited.
    """
    settings = request.app.state.settings
    project_dir = settings.project_path
    files: dict[str, str] = {}

    # data.py
    if data.data_file:
        raw = _generate_data_content(data.data_file)
        files["data.py"] = _merge_with_safe_zone(project_dir / "data.py", raw)
    else:
        existing = _read_existing_file(project_dir / "data.py")
        if existing is not None:
            files["data.py"] = existing

    # algorithms.py
    if data.algorithms_file:
        raw = _generate_algorithms_content(data.algorithms_file)
        ui_names = [w.name for w in data.algorithms_file.wrappers]
        merged = _merge_algorithm_wrappers(project_dir / "algorithms.py", raw, ui_names)
        files["algorithms.py"] = _merge_with_safe_zone(project_dir / "algorithms.py", merged)
    else:
        existing = _read_existing_file(project_dir / "algorithms.py")
        if existing is not None:
            files["algorithms.py"] = existing

    # metrics.py
    if data.metrics_file:
        raw = _generate_metrics_content(data.metrics_file)
        files["metrics.py"] = _merge_with_safe_zone(project_dir / "metrics.py", raw)
    else:
        existing = _read_existing_file(project_dir / "metrics.py")
        if existing is not None:
            files["metrics.py"] = existing

    # settings.py
    if data.settings_file:
        raw = _generate_settings_content(data.settings_file)
        files["settings.py"] = _merge_with_safe_zone(project_dir / "settings.py", raw)
    else:
        existing = _read_existing_file(project_dir / "settings.py")
        if existing is not None:
            files["settings.py"] = existing

    # workflow files
    if data.workflow_file:
        problem_type = data.workflow_file.problem_type
        if problem_type not in ("classification", "regression"):
            problem_type = "regression"
        filename = f"workflows/{problem_type}.py"
        raw = _generate_workflow_content(data.workflow_file)
        files[filename] = _merge_with_safe_zone(
            project_dir / "workflows" / f"{problem_type}.py", raw
        )
    else:
        workflows_dir = project_dir / "workflows"
        if workflows_dir.is_dir():
            for wf_path in sorted(workflows_dir.glob("*.py")):
                existing = _read_existing_file(wf_path)
                if existing is not None:
                    files[f"workflows/{wf_path.name}"] = existing

    return PreviewFilesResponse(files=files)


class DeleteResponse(pydantic.BaseModel):
    """Response model for project deletion."""
    success: bool
    message: str
    deleted_path: str


@router.delete("", response_model=DeleteResponse)
async def delete_project(request: fastapi.Request):
    """Delete the entire project directory.
    
    WARNING: This is a destructive operation that cannot be undone.
    It deletes the entire project directory, not just the .brisk folder.
    """
    settings = request.app.state.settings
    project_path = settings.project_path
    
    if not project_path.exists():
        raise fastapi.HTTPException(
            status_code=404,
            detail=f"Project directory not found: {project_path}"
        )
    
    # Safety check: ensure we're deleting a brisk project
    brisk_dir = project_path / ".brisk"
    if not brisk_dir.exists():
        raise fastapi.HTTPException(
            status_code=400,
            detail="Not a valid brisk project (missing .brisk directory)"
        )
    
    try:
        deleted_path = str(project_path)
        shutil.rmtree(project_path)
        return DeleteResponse(
            success=True,
            message="Project deleted successfully",
            deleted_path=deleted_path
        )
    except PermissionError:
        raise fastapi.HTTPException(
            status_code=403,
            detail="Permission denied: cannot delete project directory"
        )
    except Exception as e:
        raise fastapi.HTTPException(
            status_code=500,
            detail=f"Failed to delete project: {str(e)}"
        )


class ProjectStats(pydantic.BaseModel):
    """Project statistics model."""
    groups: int = 0
    experiments: int = 0
    datasets: int = 0
    algorithms: int = 0
    workflow_steps: int = 0


def _count_experiment_groups_and_experiments(settings_content: str) -> tuple[int, int]:
    """Parse settings.py to count experiment groups and calculate total experiments.
    
    An experiment = number of datasets × number of algorithms in each group.
    """
    # Count add_experiment_group calls
    group_pattern = r'config\.add_experiment_group\s*\('
    groups = len(re.findall(group_pattern, settings_content))
    
    # Find each add_experiment_group call and extract datasets/algorithms
    total_experiments = 0
    
    # Pattern to match add_experiment_group with its arguments
    # This is a simplified parser - looks for datasets=[...] and algorithms=[...]
    group_calls = re.finditer(
        r'config\.add_experiment_group\s*\((.*?)\)\s*(?=config\.|return|\Z)',
        settings_content,
        re.DOTALL
    )
    
    for match in group_calls:
        call_content = match.group(1)
        
        # Count datasets - look for datasets=[...] or datasets=["..."]
        datasets_match = re.search(r'datasets\s*=\s*\[(.*?)\]', call_content, re.DOTALL)
        if datasets_match:
            datasets_str = datasets_match.group(1)
            # Count items (strings or tuples)
            # Simple approach: count quoted strings or tuple patterns
            dataset_items = re.findall(r'(?:"[^"]*"|\'[^\']*\'|\([^)]+\))', datasets_str)
            num_datasets = len(dataset_items) if dataset_items else 0
        else:
            num_datasets = 0
        
        # Count algorithms - look for algorithms=[...]
        algorithms_match = re.search(r'algorithms\s*=\s*\[(.*?)\]', call_content, re.DOTALL)
        if algorithms_match:
            algorithms_str = algorithms_match.group(1)
            # Count quoted strings
            algorithm_items = re.findall(r'(?:"[^"]*"|\'[^\']*\')', algorithms_str)
            num_algorithms = len(algorithm_items) if algorithm_items else 0
        else:
            num_algorithms = 0
        
        total_experiments += num_datasets * num_algorithms
    
    return groups, total_experiments


def _count_datasets(project_path) -> int:
    """Count dataset files (.csv, .xlsx) and sqlite tables in datasets/ directory."""
    import sqlite3
    
    datasets_dir = project_path / "datasets"
    count = 0
    
    if not datasets_dir.exists():
        return 0
    
    for item in datasets_dir.iterdir():
        if item.is_file():
            suffix = item.suffix.lower()
            if suffix in ('.csv', '.xlsx', '.xls'):
                count += 1
            elif suffix in ('.sqlite', '.db', '.sqlite3'):
                # Count tables in sqlite database
                try:
                    conn = sqlite3.connect(str(item))
                    cursor = conn.execute(
                        "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
                    )
                    table_count = cursor.fetchone()[0]
                    count += table_count
                    conn.close()
                except Exception:
                    pass  # Skip if can't read database
    
    return count


def _count_algorithm_wrappers(algorithms_content: str) -> int:
    """Count AlgorithmWrapper instances in algorithms.py."""
    # Count AlgorithmWrapper( occurrences
    pattern = r'AlgorithmWrapper\s*\('
    return len(re.findall(pattern, algorithms_content))


def _count_workflow_steps(workflow_content: str) -> int:
    """Count self.method_name() calls inside the workflow method body."""
    pattern = r'self\.\w+\s*\('
    return len(re.findall(pattern, workflow_content))


@router.get("/stats", response_model=ProjectStats)
async def get_project_stats(request: fastapi.Request):
    """Get project statistics by parsing project files.
    
    Returns counts for:
    - groups: Number of experiment groups in settings.py
    - experiments: Total experiments (datasets × algorithms per group)
    - datasets: Number of dataset files (.csv, .xlsx) + sqlite tables
    - algorithms: Number of AlgorithmWrapper instances in algorithms.py
    - metrics: Number of metrics in metrics.py
    """
    settings = request.app.state.settings
    project_path = settings.project_path
    
    stats = ProjectStats()
    
    # Parse settings.py for groups and experiments
    settings_file = project_path / "settings.py"
    if settings_file.exists():
        try:
            content = settings_file.read_text()
            stats.groups, stats.experiments = _count_experiment_groups_and_experiments(content)
        except Exception:
            pass
    
    # Count datasets from project.json
    config_service = ProjectConfigService(project_path)
    config_data = config_service.read()
    stats.datasets = len(config_data.get("datasets", []))
    
    # Parse algorithms.py
    algorithms_file = project_path / "algorithms.py"
    if algorithms_file.exists():
        try:
            content = algorithms_file.read_text()
            stats.algorithms = _count_algorithm_wrappers(content)
        except Exception:
            pass
    
    # Count workflow steps from workflow file
    config_data_for_type = config_service.read()
    project_type = config_data_for_type.get("project_type", "classification")
    workflow_file = project_path / "workflows" / f"{project_type}.py"
    if workflow_file.exists():
        try:
            content = workflow_file.read_text()
            stats.workflow_steps = _count_workflow_steps(content)
        except Exception:
            pass
    
    return stats


# ============================================================================
# File Preview Endpoints
# ============================================================================

class ProjectFileInfo(pydantic.BaseModel):
    """Information about a project file."""
    id: str
    name: str
    path: str
    exists: bool
    size: int = 0


class ProjectFilesResponse(pydantic.BaseModel):
    """Response containing list of project files."""
    files: list[ProjectFileInfo]
    project_type: str


class FileContentResponse(pydantic.BaseModel):
    """Response containing file content."""
    name: str
    content: str
    exists: bool


# The standard project files to show (workflow file name depends on project_type)
PROJECT_FILES = [
    ("settings.py", "settings.py"),
    ("algorithms.py", "algorithms.py"),
    ("metrics.py", "metrics.py"),
    ("data.py", "data.py"),
    ("evaluators.py", "evaluators.py"),
]


@router.get("/files", response_model=ProjectFilesResponse)
async def get_project_files(request: fastapi.Request):
    """Get list of project configuration files with their status.
    
    Returns the standard project files plus the workflow file
    (regression.py or classification.py based on project type).
    """
    import pathlib
    
    settings = request.app.state.settings
    project_path = settings.project_path
    
    # Get project type from project.json
    config_service = ProjectConfigService(project_path)
    config_data = config_service.read()
    project_type = config_data.get("project_type", "classification")
    
    files: list[ProjectFileInfo] = []
    
    # Add standard files (skip evaluators.py if missing or empty)
    for file_id, filename in PROJECT_FILES:
        file_path = project_path / filename
        exists = file_path.exists()
        size = file_path.stat().st_size if exists else 0
        if filename == "evaluators.py" and (not exists or size == 0):
            continue
        files.append(ProjectFileInfo(
            id=file_id,
            name=filename,
            path=str(file_path),
            exists=exists,
            size=size,
        ))
    
    # Add workflow file based on project type
    workflow_filename = f"{project_type}.py"
    workflow_path = project_path / "workflows" / workflow_filename
    exists = workflow_path.exists()
    size = workflow_path.stat().st_size if exists else 0
    files.append(ProjectFileInfo(
        id="workflow",
        name=workflow_filename,
        path=str(workflow_path),
        exists=exists,
        size=size,
    ))
    
    return ProjectFilesResponse(files=files, project_type=project_type)


@router.get("/files/{file_id}/content", response_model=FileContentResponse)
async def get_file_content(file_id: str, request: fastapi.Request):
    """Get the content of a specific project file.
    
    file_id can be: settings.py, algorithms.py, metrics.py, data.py, evaluators.py, or workflow
    """
    import pathlib
    
    settings = request.app.state.settings
    project_path = settings.project_path
    
    # Get project type for workflow file
    config_service = ProjectConfigService(project_path)
    config_data = config_service.read()
    project_type = config_data.get("project_type", "classification")
    
    # Determine the file path
    if file_id == "workflow":
        workflow_filename = f"{project_type}.py"
        file_path = project_path / "workflows" / workflow_filename
        name = workflow_filename
    else:
        # file_id is the filename itself (e.g., "settings.py")
        file_path = project_path / file_id
        name = file_id
    
    if not file_path.exists():
        return FileContentResponse(
            name=name,
            content="",
            exists=False,
        )
    
    try:
        content = file_path.read_text(encoding="utf-8")
        return FileContentResponse(
            name=name,
            content=content,
            exists=True,
        )
    except Exception as e:
        raise fastapi.HTTPException(
            status_code=500,
            detail=f"Failed to read file: {str(e)}"
        )


@router.post("/files/{file_id}/download")
async def download_file(file_id: str, request: fastapi.Request):
    """Download a project file.
    
    Returns the file as an attachment for download.
    """
    from fastapi.responses import FileResponse
    import pathlib
    
    settings = request.app.state.settings
    project_path = settings.project_path
    
    # Get project type for workflow file
    config_service = ProjectConfigService(project_path)
    config_data = config_service.read()
    project_type = config_data.get("project_type", "classification")
    
    # Determine the file path
    if file_id == "workflow":
        workflow_filename = f"{project_type}.py"
        file_path = project_path / "workflows" / workflow_filename
    else:
        file_path = project_path / file_id
    
    if not file_path.exists():
        raise fastapi.HTTPException(
            status_code=404,
            detail=f"File not found: {file_id}"
        )
    
    return FileResponse(
        path=str(file_path),
        filename=file_path.name,
        media_type="text/x-python",
    )


# ============================================================================
# Experiments Data Endpoints
# ============================================================================

class DatasetInfo(pydantic.BaseModel):
    """Information about a dataset file."""
    name: str  # filename without extension (used as identifier)
    filename: str  # full filename
    file_type: str  # csv, xlsx, sqlite, etc.


class AlgorithmInfo(pydantic.BaseModel):
    """Information about a configured algorithm."""
    name: str  # internal name
    display_name: str
    class_name: str  # Python class name (e.g., "Ridge")
    class_module: str  # Python module (e.g., "sklearn.linear_model")
    default_params: dict = {}  # Default parameters
    search_space: dict[str, list] = {}  # Hyperparameter grid
    use_defaults: bool = True  # Whether using catalog defaults


class ExperimentGroupInfo(pydantic.BaseModel):
    """Information about an experiment group from settings.py."""
    name: str
    description: str
    datasets: list[str]
    algorithms: list[str]


class ExperimentsDataResponse(pydantic.BaseModel):
    """Response containing all data needed for experiments page."""
    datasets: list[DatasetInfo]
    algorithms: list[AlgorithmInfo]
    experiment_groups: list[ExperimentGroupInfo]


def _parse_algorithms_from_file(content: str) -> list[AlgorithmInfo]:
    """Parse algorithm info from algorithms.py content."""
    algorithms = []
    
    # Parse import statements to build a module map
    # Pattern: from sklearn.xxx import ClassName1, ClassName2
    import_pattern = r'from\s+([\w.]+)\s+import\s+([^#\n]+)'
    import_matches = re.findall(import_pattern, content)
    
    class_to_module = {}
    for module, classes_str in import_matches:
        # Split by comma and strip whitespace
        classes = [c.strip() for c in classes_str.split(',')]
        for class_name in classes:
            if class_name:
                class_to_module[class_name] = module
    
    # Match individual AlgorithmWrapper instantiations
    # Pattern captures the entire AlgorithmWrapper(...) block
    wrapper_pattern = r'AlgorithmWrapper\s*\(([\s\S]*?)\)'
    wrapper_matches = re.finditer(wrapper_pattern, content)
    
    for match in wrapper_matches:
        wrapper_content = match.group(1)
        
        # Extract name
        name_match = re.search(r'name\s*=\s*["\']([^"\']+)["\']', wrapper_content)
        name = name_match.group(1) if name_match else ""
        
        # Extract display_name
        display_name_match = re.search(r'display_name\s*=\s*["\']([^"\']+)["\']', wrapper_content)
        display_name = display_name_match.group(1) if display_name_match else name
        
        # Extract algorithm_class (the class reference, not quoted)
        class_match = re.search(r'algorithm_class\s*=\s*(\w+)', wrapper_content)
        class_name = class_match.group(1) if class_match else ""
        
        # Get module from our import map
        class_module = class_to_module.get(class_name, "sklearn")
        
        # Extract default_params if present
        default_params = {}
        params_match = re.search(r'default_params\s*=\s*\{([^}]*)\}', wrapper_content)
        if params_match:
            params_str = params_match.group(1)
            # Parse simple key-value pairs
            param_pattern = r'["\'](\w+)["\']\s*:\s*([^,}]+)'
            param_matches = re.findall(param_pattern, params_str)
            for param_name, param_value in param_matches:
                # Try to parse the value
                param_value = param_value.strip()
                if param_value.startswith('"') or param_value.startswith("'"):
                    # String value
                    default_params[param_name] = param_value.strip('"\'')
                elif param_value.lower() == 'true':
                    default_params[param_name] = True
                elif param_value.lower() == 'false':
                    default_params[param_name] = False
                elif param_value.lower() == 'none':
                    default_params[param_name] = None
                else:
                    try:
                        # Try as number
                        if '.' in param_value or 'e' in param_value.lower():
                            default_params[param_name] = float(param_value)
                        else:
                            default_params[param_name] = int(param_value)
                    except ValueError:
                        default_params[param_name] = param_value
        
        # Extract hyperparam_grid (or legacy hyperparameters) if present
        search_space: dict[str, list] = {}
        grid_match = re.search(r'(?:hyperparam_grid|hyperparameters)\s*=\s*\{', wrapper_content)
        if grid_match:
            brace_start = grid_match.end() - 1
            depth = 0
            i = brace_start
            while i < len(wrapper_content):
                ch = wrapper_content[i]
                if ch == "{":
                    depth += 1
                elif ch == "}":
                    depth -= 1
                    if depth == 0:
                        break
                i += 1
            grid_str = wrapper_content[brace_start + 1:i]
            grid_entries = re.findall(r'["\']([^"\']+)["\']\s*:\s*\[([^\]]*)\]', grid_str)
            for param_name, values_str in grid_entries:
                values: list = []
                for v in re.findall(r'[^,\s]+', values_str):
                    v = v.strip().strip('"\'')
                    try:
                        if '.' in v or 'e' in v.lower():
                            values.append(float(v))
                        else:
                            values.append(int(v))
                    except ValueError:
                        values.append(v)
                if values:
                    search_space[param_name] = values

        # If default_params is empty, assume using defaults
        use_defaults = len(default_params) == 0
        
        if name:  # Only add if we have a name
            algorithms.append(AlgorithmInfo(
                name=name,
                display_name=display_name,
                class_name=class_name,
                class_module=class_module,
                default_params=default_params,
                search_space=search_space,
                use_defaults=use_defaults,
            ))
    
    return algorithms


def _parse_experiment_groups_from_file(content: str) -> list[ExperimentGroupInfo]:
    """Parse experiment groups from settings.py content."""
    groups = []
    
    # Match add_experiment_group calls
    # Pattern is complex due to multi-line and various argument formats
    pattern = r'config\.add_experiment_group\s*\((.*?)\)'
    matches = re.findall(pattern, content, re.DOTALL)
    
    for match in matches:
        # Extract name
        name_match = re.search(r'name\s*=\s*["\']([^"\']+)["\']', match)
        name = name_match.group(1) if name_match else "Unknown"
        
        # Extract description
        desc_match = re.search(r'description\s*=\s*["\']([^"\']*)["\']', match)
        description = desc_match.group(1) if desc_match else ""
        
        # Extract datasets (can be a list)
        datasets_match = re.search(r'datasets\s*=\s*\[([^\]]*)\]', match)
        datasets = []
        if datasets_match:
            datasets_str = datasets_match.group(1)
            datasets = re.findall(r'["\']([^"\']+)["\']', datasets_str)
        
        # Extract algorithms (can be a list)
        algorithms_match = re.search(r'algorithms\s*=\s*\[([^\]]*)\]', match)
        algorithms = []
        if algorithms_match:
            algorithms_str = algorithms_match.group(1)
            algorithms = re.findall(r'["\']([^"\']+)["\']', algorithms_str)
        
        groups.append(ExperimentGroupInfo(
            name=name,
            description=description,
            datasets=datasets,
            algorithms=algorithms,
        ))
    
    return groups


@router.get("/experiments-data", response_model=ExperimentsDataResponse)
async def get_experiments_data(request: fastapi.Request):
    """Get all data needed for the experiments page.
    
    Returns:
    - Available datasets from the datasets folder
    - Configured algorithms from algorithms.py
    - Existing experiment groups from settings.py
    """
    settings = request.app.state.settings
    project_path = settings.project_path
    
    # Get datasets from project.json
    datasets: list[DatasetInfo] = []
    config_service = ProjectConfigService(project_path)
    config_data = config_service.read()
    for stored in config_data.get("datasets", []):
        file_name = stored.get("file_name", "")
        if not file_name:
            continue
        name = file_name.rsplit(".", 1)[0] if "." in file_name else file_name
        datasets.append(DatasetInfo(
            name=name,
            filename=file_name,
            file_type=stored.get("file_type", "csv"),
        ))
    
    # Get algorithms from algorithms.py
    algorithms: list[AlgorithmInfo] = []
    algorithms_file = project_path / "algorithms.py"
    if algorithms_file.exists():
        try:
            content = algorithms_file.read_text()
            algorithms = _parse_algorithms_from_file(content)
        except Exception:
            pass
    
    # Get experiment groups from settings.py
    experiment_groups: list[ExperimentGroupInfo] = []
    settings_file = project_path / "settings.py"
    if settings_file.exists():
        try:
            content = settings_file.read_text()
            experiment_groups = _parse_experiment_groups_from_file(content)
        except Exception:
            pass
    
    return ExperimentsDataResponse(
        datasets=datasets,
        algorithms=algorithms,
        experiment_groups=experiment_groups,
    )


# ============================================================================
# Dataset File Parsing API
# ============================================================================

class FeatureInfo(pydantic.BaseModel):
    """Information about a single feature/column in a dataset."""
    name: str
    data_type: str  # "str", "int", or "float"
    categorical: bool = False  # User will mark this manually


class ParsedDatasetInfo(pydantic.BaseModel):
    """Parsed metadata from a dataset file."""
    file_name: str
    file_type: str  # "csv" or "xlsx"
    features: list[FeatureInfo]
    target_feature: str  # Last column name
    feature_count: int
    row_count: int  # Estimated row count


def _infer_dtype(values: list) -> str:
    """Infer data type from a sample of values.
    
    Returns "int", "float", or "str".
    """
    # Filter out None/empty values
    valid_values = [v for v in values if v is not None and str(v).strip() != ""]
    
    if not valid_values:
        return "str"
    
    # Try int first
    try:
        for v in valid_values:
            int(v)
        return "int"
    except (ValueError, TypeError):
        pass
    
    # Try float
    try:
        for v in valid_values:
            float(v)
        return "float"
    except (ValueError, TypeError):
        pass
    
    return "str"


@router.post("/parse-dataset-file", response_model=ParsedDatasetInfo)
async def parse_dataset_file(
    request: fastapi.Request,
    file: fastapi.UploadFile = fastapi.File(...),
):
    """Parse a dataset file and return metadata, and save it to datasets/ directory.
    
    Supports CSV and XLSX files. Reads only the first few rows to infer column types.
    The target feature is assumed to be the last column.
    Also saves the file to the project's datasets/ directory if the project path exists.
    """
    if not file.filename:
        raise fastapi.HTTPException(status_code=400, detail="No filename provided")
    
    file_ext = file.filename.split(".")[-1].lower() if "." in file.filename else ""
    
    if file_ext not in ("csv", "xlsx", "xls"):
        raise fastapi.HTTPException(
            status_code=400,
            detail=f"Unsupported file type: {file_ext}. Only CSV and XLSX are supported."
        )
    
    # Read the raw content so we can both parse and save
    raw_content = await file.read()
    await file.seek(0)
    
    try:
        if file_ext == "csv":
            result = await _parse_csv_file(file)
        else:  # xlsx or xls
            result = await _parse_xlsx_file(file)
    except Exception as e:
        raise fastapi.HTTPException(
            status_code=500,
            detail=f"Failed to parse file: {str(e)}"
        )
    
    # Save file: in create mode, hold in memory until project is created;
    # in edit mode, write directly to datasets/ directory
    create_mode = os.environ.get("BRISK_UI_CREATE_MODE", "false") == "true"
    if create_mode:
        global _pending_uploads
        _pending_uploads[file.filename] = raw_content
    else:
        settings = request.app.state.settings
        datasets_dir = settings.project_path / "datasets"
        try:
            datasets_dir.mkdir(parents=True, exist_ok=True)
            (datasets_dir / file.filename).write_bytes(raw_content)
        except Exception:
            pass
    
    return result


async def _parse_csv_file(file: fastapi.UploadFile) -> ParsedDatasetInfo:
    """Parse CSV file metadata without loading entire file."""
    import csv
    import io
    
    # Read the file content - we need to do this to process it
    content = await file.read()
    
    # Now parse just the first few rows for column info
    text_content = content.decode('utf-8')
    reader = csv.reader(io.StringIO(text_content))
    
    # Get header
    try:
        header = next(reader)
    except StopIteration:
        raise fastapi.HTTPException(status_code=400, detail="Empty file")
    
    if not header:
        raise fastapi.HTTPException(status_code=400, detail="No columns found")
    
    # Read sample rows for type inference (up to 100 rows) and count total rows
    sample_rows = []
    row_count = 0
    for row in reader:
        row_count += 1
        if len(sample_rows) < 100:
            sample_rows.append(row)
    
    target_feature = header[-1].strip() if header else ""
    
    # Infer types for each column, excluding the target (last) column
    features: list[FeatureInfo] = []
    for col_idx, col_name in enumerate(header[:-1]):
        col_values = [row[col_idx] for row in sample_rows if col_idx < len(row)]
        dtype = _infer_dtype(col_values)
        features.append(FeatureInfo(name=col_name.strip(), data_type=dtype))
    
    return ParsedDatasetInfo(
        file_name=file.filename or "unknown.csv",
        file_type="csv",
        features=features,
        target_feature=target_feature,
        feature_count=len(features),
        row_count=row_count,
    )


async def _parse_xlsx_file(file: fastapi.UploadFile) -> ParsedDatasetInfo:
    """Parse XLSX file metadata without loading entire file."""
    try:
        from openpyxl import load_workbook
    except ImportError:
        raise fastapi.HTTPException(
            status_code=500,
            detail="openpyxl is required for XLSX parsing. Install with: pip install openpyxl"
        )
    
    import io
    
    # Read file content
    content = await file.read()
    
    # Load workbook in read-only mode for memory efficiency
    wb = load_workbook(io.BytesIO(content), read_only=True, data_only=True)
    ws = wb.active
    
    if ws is None:
        raise fastapi.HTTPException(status_code=400, detail="No active worksheet found")
    
    # Get header row (first row)
    header = []
    first_row = next(ws.iter_rows(min_row=1, max_row=1, values_only=True), None)
    if first_row is None:
        raise fastapi.HTTPException(status_code=400, detail="Empty file")
    
    header = [str(cell) if cell is not None else "" for cell in first_row]
    header = [h.strip() for h in header if h.strip()]
    
    if not header:
        raise fastapi.HTTPException(status_code=400, detail="No columns found")
    
    # Read sample rows for type inference (rows 2-101)
    sample_rows = []
    for row in ws.iter_rows(min_row=2, max_row=101, values_only=True):
        sample_rows.append(list(row))
    
    # Count total rows (this requires iterating but in read-only mode it's efficient)
    row_count = 0
    for _ in ws.iter_rows(min_row=2, values_only=True):
        row_count += 1
    
    wb.close()
    
    target_feature = header[-1] if header else ""
    
    # Infer types for each column, excluding the target (last) column
    features: list[FeatureInfo] = []
    for col_idx, col_name in enumerate(header[:-1]):
        col_values = [row[col_idx] for row in sample_rows if col_idx < len(row)]
        dtype = _infer_dtype(col_values)
        features.append(FeatureInfo(name=col_name, data_type=dtype))
    
    return ParsedDatasetInfo(
        file_name=file.filename or "unknown.xlsx",
        file_type="xlsx",
        features=features,
        target_feature=target_feature,
        feature_count=len(features),
        row_count=row_count,
    )


# ============================================================================
# Dataset Configuration Storage (project.json)
# ============================================================================

class StoredFeatureInfo(pydantic.BaseModel):
    """Stored feature information."""
    name: str
    data_type: str = "str"  # "str", "int", "float"
    categorical: bool = False


class StoredDataManagerConfig(pydantic.BaseModel):
    """Per-dataset data manager configuration."""
    test_size: float | None = None
    n_splits: int | None = None
    split_method: str | None = None
    group_column: str | None = None
    stratified: bool | None = None
    random_state: int | None = None


class StoredPreprocessorConfig(pydantic.BaseModel):
    """Preprocessor configuration for a dataset."""
    type: str  # "missing-data", "scaling", "encoding", "feature-selection"
    config: dict = {}


class StoredDatasetConfig(pydantic.BaseModel):
    """Complete stored configuration for a dataset.
    
    The ID is based on filename (and table name for SQLite).
    This ensures consistent IDs across sessions.
    """
    id: str  # filename or "filename:tablename" for sqlite
    file_name: str
    table_name: str | None = None
    file_type: str = "csv"  # "csv", "xlsx", "sqlite"
    target_feature: str = ""
    features_count: int = 0
    observations_count: int = 0
    features: list[StoredFeatureInfo] = []
    data_manager: StoredDataManagerConfig | None = None
    preprocessors: list[StoredPreprocessorConfig] = []


class StoredDatasetsResponse(pydantic.BaseModel):
    """Response containing stored datasets merged with file system."""
    datasets: list[StoredDatasetConfig]
    base_data_manager: StoredDataManagerConfig | None = None


class SaveDatasetsRequest(pydantic.BaseModel):
    """Request to save datasets configuration to project.json."""
    datasets: list[StoredDatasetConfig]
    base_data_manager: StoredDataManagerConfig | None = None


class SaveDatasetsResponse(pydantic.BaseModel):
    """Response for saving datasets."""
    success: bool
    saved_count: int


def _get_dataset_id(filename: str, table_name: str | None = None) -> str:
    """Generate a consistent dataset ID from filename and optional table name."""
    if table_name:
        return f"{filename}:{table_name}"
    return filename


def _list_dataset_files(project_path) -> list[dict]:
    """List dataset files in the datasets/ directory.
    
    Returns a list of dicts with file info.
    """
    import sqlite3
    
    datasets_dir = project_path / "datasets"
    files = []
    
    if not datasets_dir.exists():
        return files
    
    for item in datasets_dir.iterdir():
        if item.is_file():
            suffix = item.suffix.lower()
            if suffix in ('.csv', '.xlsx', '.xls'):
                files.append({
                    "id": item.name,
                    "file_name": item.name,
                    "table_name": None,
                    "file_type": "xlsx" if suffix in ('.xlsx', '.xls') else "csv",
                })
            elif suffix in ('.sqlite', '.db', '.sqlite3'):
                # For SQLite, list all tables
                try:
                    conn = sqlite3.connect(str(item))
                    cursor = conn.execute(
                        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
                    )
                    tables = [row[0] for row in cursor.fetchall()]
                    conn.close()
                    
                    for table in tables:
                        files.append({
                            "id": f"{item.name}:{table}",
                            "file_name": item.name,
                            "table_name": table,
                            "file_type": "sqlite",
                        })
                except Exception:
                    # If can't read database, just add the file
                    files.append({
                        "id": item.name,
                        "file_name": item.name,
                        "table_name": None,
                        "file_type": "sqlite",
                    })
    
    return files


@router.get("/datasets", response_model=StoredDatasetsResponse)
async def get_datasets(request: fastapi.Request):
    """Get datasets from project.json stored configuration.
    
    Returns only datasets that have been explicitly configured and saved.
    """
    settings = request.app.state.settings
    project_path = settings.project_path
    
    config_service = ProjectConfigService(project_path)
    config_data = config_service.read()
    stored_datasets = config_data.get("datasets", [])
    
    result_datasets: list[StoredDatasetConfig] = []
    for stored in stored_datasets:
        if not stored.get("id"):
            continue
        result_datasets.append(StoredDatasetConfig(
            id=stored["id"],
            file_name=stored.get("file_name", ""),
            table_name=stored.get("table_name"),
            file_type=stored.get("file_type", "csv"),
            target_feature=stored.get("target_feature", ""),
            features_count=stored.get("features_count", 0),
            observations_count=stored.get("observations_count", 0),
            features=[StoredFeatureInfo(**f) for f in stored.get("features", [])],
            data_manager=StoredDataManagerConfig(**stored["data_manager"]) if stored.get("data_manager") else None,
            preprocessors=[StoredPreprocessorConfig(**p) for p in stored.get("preprocessors", [])],
        ))
    
    stored_base_dm = config_data.get("base_data_manager")
    base_dm = StoredDataManagerConfig(**stored_base_dm) if stored_base_dm else None
    
    return StoredDatasetsResponse(datasets=result_datasets, base_data_manager=base_dm)


@router.patch("/datasets", response_model=SaveDatasetsResponse)
async def save_datasets(
    request: fastapi.Request,
    data: SaveDatasetsRequest,
):
    """Save datasets configuration to project.json.
    
    This persists all dataset metadata, data manager configs, and preprocessor configs.
    """
    settings = request.app.state.settings
    project_path = settings.project_path
    
    config_service = ProjectConfigService(project_path)
    config_data = config_service.read()
    
    # Convert to dict format for JSON storage
    datasets_to_store = []
    for ds in data.datasets:
        ds_dict = {
            "id": ds.id,
            "file_name": ds.file_name,
            "table_name": ds.table_name,
            "file_type": ds.file_type,
            "target_feature": ds.target_feature,
            "features_count": ds.features_count,
            "observations_count": ds.observations_count,
            "features": [f.model_dump() for f in ds.features],
        }
        
        if ds.data_manager:
            ds_dict["data_manager"] = ds.data_manager.model_dump(exclude_none=True)
        
        if ds.preprocessors:
            ds_dict["preprocessors"] = [p.model_dump() for p in ds.preprocessors]
        
        datasets_to_store.append(ds_dict)
    
    config_data["datasets"] = datasets_to_store
    
    if data.base_data_manager:
        config_data["base_data_manager"] = data.base_data_manager.model_dump(exclude_none=True)
    
    config_service.write(config_data)
    
    return SaveDatasetsResponse(
        success=True,
        saved_count=len(datasets_to_store),
    )
