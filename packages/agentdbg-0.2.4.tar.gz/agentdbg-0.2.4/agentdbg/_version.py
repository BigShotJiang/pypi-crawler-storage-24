# This file is managed by dynamic versioning. Do not edit manually.
version = "0.2.4"