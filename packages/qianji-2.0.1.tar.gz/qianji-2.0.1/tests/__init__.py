"""Tests for qianji package."""
