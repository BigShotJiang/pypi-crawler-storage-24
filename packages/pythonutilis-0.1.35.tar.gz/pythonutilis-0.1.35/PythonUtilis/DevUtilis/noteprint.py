import os
import sys
import colorama
from pathlib import Path
import json
import subprocess
import platform
import shutil
from functools import wraps
import atexit
import signal

colorama.init(autoreset=True)

def cleanup_temp_files():
    """Clean up temporary files created by noteprint."""
    try:
        if Path(".temp_note_script.py").exists():
            Path(".temp_note_script.py").unlink()
        if Path(".temp_note_wrapper.sh").exists():
            Path(".temp_note_wrapper.sh").unlink()
        if Path(".temp_note_result.txt").exists():
            Path(".temp_note_result.txt").unlink()
        if Path(".temp_note_complete.marker").exists():
            Path(".temp_note_complete.marker").unlink()
    except Exception as e:
        print(f"Error cleaning up temporary files: {e}")

def get_terminal_command(script_path):
    """Returns the command list to open a new terminal running the script."""
    system = platform.system()
    
    if system == "Windows":
        return ["cmd", "/c", f"start /wait python3 {script_path} & pause"]
    
    elif system == "Darwin":  # macOS
        cmd = f"""
        tell application "Terminal"
            do script "python3 '{script_path}'; echo ''; echo 'Press Enter to close...'; read; exit"
            activate
        end tell
        """
        return ["osascript", "-e", cmd]
    
    elif system == "Linux":
        # List of terminals to try, in order of preference
        terminals = [
            "gnome-terminal",
            "konsole",
            "xfce4-terminal",
            "xterm",
            "x-terminal-emulator" # Generic symlink often found on Debian/Ubuntu
        ]
        
        terminal_executable = None
        
        # Find which terminal is available
        for term in terminals:
            if shutil.which(term):
                terminal_executable = term
                break
        
        if terminal_executable:
            # Create a wrapper script that will run the temp script and pause
            wrapper_script = f"""#!/bin/bash
# Create a marker file to indicate the script completed normally
touch .temp_note_complete.marker

python3 {script_path}

# Clean up the marker file when done
rm -f .temp_note_complete.marker

echo ""
echo "Press Enter to close..."
read
"""
            wrapper_path = Path(".temp_note_wrapper.sh")
            wrapper_path.write_text(wrapper_script)
            wrapper_path.chmod(0o755)  # Make it executable
            
            # Construct the command based on the terminal found
            if terminal_executable == "gnome-terminal":
                return [terminal_executable, "--", wrapper_path.resolve()]
            
            elif terminal_executable == "konsole":
                return [terminal_executable, "-e", wrapper_path.resolve()]
            
            elif terminal_executable == "xfce4-terminal":
                return [terminal_executable, "-e", wrapper_path.resolve()]
            
            elif terminal_executable == "xterm":
                return [terminal_executable, "-e", wrapper_path.resolve()]
            
            else:
                # Fallback for generic terminals
                return [terminal_executable, "-e", wrapper_path.resolve()]
        else:
            raise EnvironmentError("No compatible terminal emulator found. Please install gnome-terminal, konsole, or xterm.")

    else:
        raise NotImplementedError(f"Unsupported OS: {system}")

def create_script(func_name, docs_strings, status, note):
    # Escape special characters in the arguments
    safe_func_name = func_name.replace('"', '\\"')
    safe_docs_strings = (docs_strings or "").replace('"', '\\"').replace('\n', '\\n')
    safe_status = status.replace('"', '\\"')
    safe_note = note.replace('"', '\\"').replace('\n', '\\n')
    
    script = f"""
import os
import sys
import colorama

YELLOW = colorama.Fore.YELLOW
CYAN = colorama.Fore.CYAN
WHITE = colorama.Fore.WHITE
GREEN = colorama.Fore.GREEN
RED = colorama.Fore.RED
MAGENTA = colorama.Fore.MAGENTA
RESET = colorama.Fore.RESET

func_name = "{safe_func_name}"
docs_strings = "{safe_docs_strings}"
status = "{safe_status}"
note = "{safe_note}"

if status.title().strip() == "Complete":
    status = f"{{GREEN}}Complete"
elif status.title().strip() == "Working":
    status = f"{{GREEN}}Working"
elif status.title().strip() == "Incomplete":
    status = f"{{RED}}Incomplete"
elif status.title().strip() == "Testing":
    status = f"{{CYAN}}Testing"
elif status.title().strip() == "In Progress":
    status = f"{{CYAN}}In Progress"
elif status.title().strip() == "Bugged":
    status = f"{{RED}}Bugged"
else:
    status = f"{{MAGENTA}}{status.title().strip()}"

print(MAGENTA + "-" * 5 + "NOTEPRINT" + "-" * 5 + RESET)
print(YELLOW + "Function Name: " + RESET + f"{{func_name}}")
print(YELLOW + f"Status: {{status}}")
print(YELLOW + f"\\n{{docs_strings}}\\n")
print(MAGENTA + f"\\n{{note}}\\n")

result = input("-" * 50 + "\\nDo you want to execute the function? (y/n): ")

with open('.temp_note_result.txt', 'w') as f:
    f.write(result)
"""

    Path(".temp_note_script.py").write_text(script)

def noteprint(note="No note provided", status="Complete", enable=True):
    """
    A decorator that displays function information and prompts for user confirmation before execution.
    
    This decorator creates an interactive terminal session that shows:
    - Function name
    - Current status (Complete/Incomplete/Testing/In Progress/Working/Bugged)
    - Function's docstring
    - Custom note message
    
    The decorator prompts the user to confirm whether they want to execute the decorated function.
    If the user declines (enters 'n'), the function execution is skipped and None is returned.
    
    Args:
        note (str, optional): Custom note message to display. Defaults to "No note provided".
            Can be multi-line and will be formatted in the terminal display.
        status (str, optional): Status indicator for the function. Accepted values (case-insensitive):
            - "Complete": Displayed in green
            - "Incomplete": Displayed in red
            - "Testing": Displayed in cyan
            - "In Progress": Displayed in white
            Defaults to "Complete".
        enable (bool, optional): Whether to enable the noteprint functionality. 
            When False, the function executes normally without any prompts. 
            Defaults to True.
    
    Returns:
        function: A decorated function that will display information and prompt before execution.
    
    Usage Examples:
        Basic usage:
        ```python
        @noteprint(note="This function processes user data", status="Complete")
        def process_data(data):
            '''Process the input data and return results.'''
            return data.upper()
        ```
        
        With custom status:
        ```python
        @noteprint(note="Work in progress - needs testing", status="In Progress")
        def experimental_feature():
            '''An experimental feature under development.'''
            return "test result"
        ```
        
        Disabled decorator (function executes normally):
        ```python
        @noteprint(enable=False)
        def auto_run_function():
            '''This function runs without prompts.'''
            return "executed"
        ```
    
    Important Notes:
        - The decorator creates temporary files in the current directory:
            * .temp_note_script.py
            * .temp_note_wrapper.sh (Linux only)
            * .temp_note_result.txt
            * .temp_note_complete.marker (Linux only)
        
        - These files are normally cleaned up automatically after the function completes.
        
        - MANUAL CLEANUP REQUIRED: If the script terminates abnormally (e.g., 
          KeyboardInterrupt, system crash, or terminal force-close), temporary 
          files may remain in the directory. You should manually delete these 
          files if they persist:
            ```
            rm -f .temp_note_script.py .temp_note_wrapper.sh .temp_note_result.txt .temp_note_complete.marker
            ```
        
        - The decorator works across different operating systems:
            * Windows: Uses cmd with start /wait
            * macOS: Uses AppleScript with Terminal
            * Linux: Attempts multiple terminal emulators (gnome-terminal, konsole, xfce4-terminal, xterm)
        
        - The terminal window will remain open after function execution, waiting for 
          the user to press Enter before closing.
    
    Raises:
        EnvironmentError: If no compatible terminal emulator is found on Linux.
        NotImplementedError: If the operating system is not supported.
        subprocess.CalledProcessError: If there's an error running the terminal command.
    
    Side Effects:
        - Creates and removes temporary files in the current working directory
        - Opens a new terminal window for the interactive prompt
        - May leave temporary files if the script terminates abnormally
    """

    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if enable:
                docs_strings = func.__doc__
                func_name = func.__name__
                create_script(func_name=func_name, docs_strings=docs_strings, status=status, note=note)
                script_path = Path(".temp_note_script.py").resolve()
                
                try:
                    command = get_terminal_command(script_path)
                    subprocess.run(command, check=True)
                    
                    # When the subprocess close
                    with open('.temp_note_result.txt', 'r') as f:
                        result = f.read().strip()
                    
                    # Clean up temporary files
                    cleanup_temp_files()
                    
                    if result.lower() == "y":
                        return func(*args, **kwargs)
                    else:
                        print(colorama.Fore.MAGENTA + "NOTEPRINT: Function execution skipped." + colorama.Fore.RESET)
                        return None
                except subprocess.CalledProcessError as e:
                    print(f"Error running terminal: {e}")
                    # Clean up temporary files even if there was an error
                    cleanup_temp_files()
                    return None
                except Exception as e:
                    print(f"Unexpected error: {e}")
                    # Clean up temporary files even if there was an error
                    cleanup_temp_files()
                    return None
            else:
                return func(*args, **kwargs)

        return wrapper

    return decorator