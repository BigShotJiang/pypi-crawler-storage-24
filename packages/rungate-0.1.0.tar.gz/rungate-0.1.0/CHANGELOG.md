# Changelog

All notable changes to the Rungate Python SDK will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-03-17

Initial release. Full-featured Python SDK for the Rungate governance proxy.

### Added

#### Client (Phase 4)
- Synchronous and asynchronous clients (`RunGate`, `AsyncRunGate`)
- Governance error hierarchy (10 error types mapping to proxy HTTP responses)
- Two-tier streaming: `stream()` for raw SSE chunks, `stream_completion()` for parsed deltas with `get_final_completion()`
- Run lifecycle management: create, get, list, close, resume
- Budget tracking and tool call logging within runs
- Context manager support for automatic resource cleanup

#### Admin Client (Phase 4)
- Full CRUD for all management endpoints (51 endpoints)
- Agents, policies, provider keys, webhooks, admin tokens, approval requests, alert rules
- Synchronous and asynchronous variants (`AdminClient`, `AsyncAdminClient`)

#### Analytics + Provider Health (Phase 5)
- 6 analytics methods: costs, latency, errors, throughput, provider reliability, run stats
- Enhanced cost tracking with model-level breakdown
- Provider health monitoring via `client.providers.health()`

### Test Coverage
- 197 unit tests + 21 integration tests
