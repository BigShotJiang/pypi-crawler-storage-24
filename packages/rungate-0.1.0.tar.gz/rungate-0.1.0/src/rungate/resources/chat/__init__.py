from __future__ import annotations

from typing import TYPE_CHECKING

from .completions import AsyncCompletions, Completions

if TYPE_CHECKING:
    from ..._client import AsyncRungate, Rungate


class Chat:
    """Chat resource namespace — provides access to chat completions."""

    def __init__(self, client: Rungate) -> None:
        self.completions = Completions(client)


class AsyncChat:
    """Async chat resource namespace."""

    def __init__(self, client: AsyncRungate) -> None:
        self.completions = AsyncCompletions(client)
