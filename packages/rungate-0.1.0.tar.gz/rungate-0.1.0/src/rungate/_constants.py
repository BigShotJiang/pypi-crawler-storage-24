from __future__ import annotations

DEFAULT_BASE_URL = "http://localhost:8080"
DEFAULT_TIMEOUT = 60.0
DEFAULT_MAX_RETRIES = 2

# Request headers
HEADER_API_KEY = "Authorization"
HEADER_RUN_ID = "X-Rungate-Run-Id"

# Response headers (lowercase — httpx normalizes response headers)
HEADER_RESP_RUN_ID = "x-rungate-run-id"
HEADER_RESP_STEP_ID = "x-rungate-step-id"
HEADER_RESP_PROVIDER = "x-rungate-provider"
HEADER_RESP_MODEL = "x-rungate-model"
HEADER_RESP_TOKENS = "x-rungate-tokens-used"
HEADER_RESP_COST = "x-rungate-cost-usd"
HEADER_RESP_BUDGET_REMAINING_USD = "x-rungate-budget-remaining-usd"
HEADER_RESP_BUDGET_REMAINING_TOKENS = "x-rungate-budget-remaining-tokens"
HEADER_RESP_FAILOVER = "x-rungate-failover"
HEADER_RESP_WARNING = "x-rungate-warning"
HEADER_RESP_GOVERNANCE = "x-rungate-governance"
