from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field

from ..rungate_metadata import RungateMetadata


class ChatCompletion(BaseModel):
    """Chat completion response from the Rungate proxy.

    Contains the standard OpenAI chat completion fields plus Rungate
    governance metadata (cost, budget, run tracking).
    """

    # Standard OpenAI fields
    id: str
    object: str = "chat.completion"
    model: str
    choices: list[dict[str, Any]]
    usage: dict[str, Any] | None = None
    created: int | None = None
    system_fingerprint: str | None = None

    # Rungate governance metadata
    rungate: RungateMetadata = Field(default_factory=RungateMetadata)
