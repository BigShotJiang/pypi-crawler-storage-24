from __future__ import annotations

from pydantic import BaseModel


class RungateMetadata(BaseModel):
    """Metadata extracted from Rungate response headers.

    Available on every successful proxy response. Fields are None when
    the corresponding header is not present.
    """

    run_id: str | None = None
    step_id: str | None = None
    provider: str | None = None
    model: str | None = None
    tokens_used: int | None = None
    cost_usd: float | None = None
    budget_remaining_usd: float | None = None
    budget_remaining_tokens: int | None = None
    failover_count: int | None = None
    warning: str | None = None
    governance: str | None = None
