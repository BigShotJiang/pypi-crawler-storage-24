from __future__ import annotations

from pydantic import BaseModel


class BudgetStatus(BaseModel):
    """Real-time budget tracking for a run.

    Updated after each LLM call from Rungate response headers.
    For streaming calls, updated after the stream is fully consumed.
    """

    remaining_usd: float | None = None
    remaining_tokens: int | None = None
    total_cost: float = 0.0
    total_tokens: int = 0
    at_limit: bool = False
