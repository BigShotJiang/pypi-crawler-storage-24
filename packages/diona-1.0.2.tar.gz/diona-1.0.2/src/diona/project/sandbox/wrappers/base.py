"""Wrapper base classes for sandbox modules"""

from abc import ABC, abstractmethod
from typing import List


class ModuleWrapper(ABC):
    """Base class for module wrappers"""
    
    @property
    @abstractmethod
    def name(self) -> str:
        """Module name to wrap"""
        pass
    
    @abstractmethod
    def get_import_code(self) -> str:
        """Code to import the module (e.g., 'import os as _os_module')"""
        pass
    
    @abstractmethod
    def get_wrapper_code(self) -> str:
        """Code that creates the safe wrapper and replaces the module"""
        pass
    
    @abstractmethod
    def get_dependencies(self) -> List[str]:
        """Other module wrappers this wrapper depends on"""
        return []


class BuiltinWrapper(ABC):
    """Base class for builtin function wrappers"""
    
    @abstractmethod
    def get_restricted_builtins(self) -> List[str]:
        """List of allowed builtin names"""
        pass
    
    @abstractmethod
    def get_wrapper_code(self) -> str:
        """Code that wraps builtin functions"""
        pass
