"""OS module wrapper for sandbox"""

from typing import List
from diona.project.sandbox.wrappers.base import ModuleWrapper


class OSWrapper(ModuleWrapper):
    """Safe os module wrapper - read-only operations only"""
    
    @property
    def name(self) -> str:
        return "os"
    
    def get_import_code(self) -> str:
        return "import os as _os_module"
    
    def get_dependencies(self) -> List[str]:
        return []
    
    def get_wrapper_code(self) -> str:
        return '''class _SafeOS:
    """Safe os module wrapper - read-only operations only"""
    name = _os_module.name
    curdir = _os_module.curdir
    pardir = _os_module.pardir
    sep = _os_module.sep
    altsep = _os_module.altsep
    extsep = _os_module.extsep
    linesep = _os_module.linesep
    devnull = _os_module.devnull
    pathsep = _os_module.pathsep
    defpath = _os_module.defpath
    
    environ = _os_module.environ
    
    @staticmethod
    def getenv(key, default=None):
        return _os_module.getenv(key, default)
    
    @staticmethod
    def listdir(path='.'):
        return _os_module.listdir(path)
    
    @staticmethod
    def walk(top, topdown=True, onerror=None, followlinks=False):
        return _os_module.walk(top, topdown, onerror, followlinks)
    
    @staticmethod
    def getcwd():
        return _os_module.getcwd()
    
    @staticmethod
    def abort():
        raise PermissionError("os.abort() is not allowed in sandbox")
    
    @staticmethod
    def chdir(path):
        raise PermissionError("os.chdir() is not allowed in sandbox")
    
    @staticmethod
    def chmod(path, mode):
        raise PermissionError("os.chmod() is not allowed in sandbox")
    
    @staticmethod
    def chown(path, uid, gid):
        raise PermissionError("os.chown() is not allowed in sandbox")
    
    @staticmethod
    def chroot(path):
        raise PermissionError("os.chroot() is not allowed in sandbox")
    
    @staticmethod
    def close(fd):
        raise PermissionError("os.close() is not allowed in sandbox")
    
    @staticmethod
    def creat(path, mode):
        raise PermissionError("os.creat() is not allowed in sandbox")
    
    @staticmethod
    def dup(fd):
        raise PermissionError("os.dup() is not allowed in sandbox")
    
    @staticmethod
    def dup2(fd, fd2):
        raise PermissionError("os.dup2() is not allowed in sandbox")
    
    @staticmethod
    def execl(path, *args):
        raise PermissionError("os.execl() is not allowed in sandbox")
    
    @staticmethod
    def execle(path, *args):
        raise PermissionError("os.execle() is not allowed in sandbox")
    
    @staticmethod
    def execlp(file, *args):
        raise PermissionError("os.execlp() is not allowed in sandbox")
    
    @staticmethod
    def execlpe(file, *args):
        raise PermissionError("os.execlpe() is not allowed in sandbox")
    
    @staticmethod
    def execv(path, args):
        raise PermissionError("os.execv() is not allowed in sandbox")
    
    @staticmethod
    def execve(path, args, env):
        raise PermissionError("os.execve() is not allowed in sandbox")
    
    @staticmethod
    def execvp(file, args):
        raise PermissionError("os.execvp() is not allowed in sandbox")
    
    @staticmethod
    def execvpe(file, args, env):
        raise PermissionError("os.execvpe() is not allowed in sandbox")
    
    @staticmethod
    def fork():
        raise PermissionError("os.fork() is not allowed in sandbox")
    
    @staticmethod
    def forkpty():
        raise PermissionError("os.forkpty() is not allowed in sandbox")
    
    @staticmethod
    def kill(pid, sig):
        raise PermissionError("os.kill() is not allowed in sandbox")
    
    @staticmethod
    def link(src, dst):
        raise PermissionError("os.link() is not allowed in sandbox")
    
    @staticmethod
    def login_tty(fd):
        raise PermissionError("os.login_tty() is not allowed in sandbox")
    
    @staticmethod
    def lseek(fd, pos, how):
        raise PermissionError("os.lseek() is not allowed in sandbox")
    
    @staticmethod
    def lstat(path):
        raise PermissionError("os.lstat() is not allowed in sandbox")
    
    @staticmethod
    def mkdir(path, mode=0o777):
        raise PermissionError("os.mkdir() is not allowed in sandbox")
    
    @staticmethod
    def makedirs(path, mode=0o777, exist_ok=False):
        raise PermissionError("os.makedirs() is not allowed in sandbox")
    
    @staticmethod
    def mkfifo(path, mode=0o666):
        raise PermissionError("os.mkfifo() is not allowed in sandbox")
    
    @staticmethod
    def mknod(path, mode=0o666, device=0):
        raise PermissionError("os.mknod() is not allowed in sandbox")
    
    @staticmethod
    def open(path, flags, mode=0o777):
        raise PermissionError("os.open() is not allowed in sandbox")
    
    @staticmethod
    def openpty():
        raise PermissionError("os.openpty() is not allowed in sandbox")
    
    @staticmethod
    def pathconf(path, name):
        raise PermissionError("os.pathconf() is not allowed in sandbox")
    
    @staticmethod
    def pipe():
        raise PermissionError("os.pipe() is not allowed in sandbox")
    
    @staticmethod
    def popen(cmd, mode='r', buffering=-1):
        raise PermissionError("os.popen() is not allowed in sandbox")
    
    @staticmethod
    def putenv(name, value):
        raise PermissionError("os.putenv() is not allowed in sandbox")
    
    @staticmethod
    def read(fd, n):
        raise PermissionError("os.read() is not allowed in sandbox")
    
    @staticmethod
    def remove(path):
        raise PermissionError("os.remove() is not allowed in sandbox")
    
    @staticmethod
    def removedirs(path):
        raise PermissionError("os.removedirs() is not allowed in sandbox")
    
    @staticmethod
    def rename(src, dst):
        raise PermissionError("os.rename() is not allowed in sandbox")
    
    @staticmethod
    def renames(old, new):
        raise PermissionError("os.renames() is not allowed in sandbox")
    
    @staticmethod
    def rmdir(path):
        raise PermissionError("os.rmdir() is not allowed in sandbox")
    
    @staticmethod
    def setpgrp():
        raise PermissionError("os.setpgrp() is not allowed in sandbox")
    
    @staticmethod
    def setpgid(pid, pgid):
        raise PermissionError("os.setpgid() is not allowed in sandbox")
    
    @staticmethod
    def setsid():
        raise PermissionError("os.setsid() is not allowed in sandbox")
    
    @staticmethod
    def setuid(uid):
        raise PermissionError("os.setuid() is not allowed in sandbox")
    
    @staticmethod
    def setgid(gid):
        raise PermissionError("os.setgid() is not allowed in sandbox")
    
    @staticmethod
    def spawnl(mode, path, *args):
        raise PermissionError("os.spawnl() is not allowed in sandbox")
    
    @staticmethod
    def spawnle(mode, path, *args):
        raise PermissionError("os.spawnle() is not allowed in sandbox")
    
    @staticmethod
    def spawnv(mode, path, args):
        raise PermissionError("os.spawnv() is not allowed in sandbox")
    
    @staticmethod
    def spawnve(mode, path, args, env):
        raise PermissionError("os.spawnve() is not allowed in sandbox")
    
    @staticmethod
    def stat(path):
        return _os_module.stat(path)
    
    @staticmethod
    def stat_float_times(new=True):
        raise PermissionError("os.stat_float_times() is not allowed in sandbox")
    
    @staticmethod
    def statvfs(path):
        return _os_module.statvfs(path)
    
    @staticmethod
    def strerror(code):
        return _os_module.strerror(code)
    
    @staticmethod
    def symlink(src, dst):
        raise PermissionError("os.symlink() is not allowed in sandbox")
    
    @staticmethod
    def system(command):
        raise PermissionError("os.system() is not allowed in sandbox")
    
    @staticmethod
    def times():
        return _os_module.times()
    
    @staticmethod
    def tmpnam():
        raise PermissionError("os.tmpnam() is not allowed in sandbox")
    
    @staticmethod
    def tmpfile():
        raise PermissionError("os.tmpfile() is not allowed in sandbox")
    
    @staticmethod
    def truncate(path, length):
        raise PermissionError("os.truncate() is not allowed in sandbox")
    
    @staticmethod
    def umask(mask):
        return _os_module.umask(mask)
    
    @staticmethod
    def unlink(path):
        raise PermissionError("os.unlink() is not allowed in sandbox")
    
    @staticmethod
    def unsetenv(name):
        raise PermissionError("os.unsetenv() is not allowed in sandbox")
    
    @staticmethod
    def urandom(size):
        return _os_module.urandom(size)
    
    @staticmethod
    def utime(path, times):
        raise PermissionError("os.utime() is not allowed in sandbox")
    
    @staticmethod
    def waitpid(pid, options):
        raise PermissionError("os.waitpid() is not allowed in sandbox")
    
    @staticmethod
    def write(fd, str):
        raise PermissionError("os.write() is not allowed in sandbox")
    
    @staticmethod
    def fchmod(fd, mode):
        raise PermissionError("os.fchmod() is not allowed in sandbox")
    
    @staticmethod
    def fchown(fd, uid, gid):
        raise PermissionError("os.fchown() is not allowed in sandbox")
    
    @staticmethod
    def fdopen(fd, mode='r', buffering=-1, encoding=None, errors=None, newline=None, closefd=True, opener=None):
        raise PermissionError("os.fdopen() is not allowed in sandbox")
    
    path = _os_module.path

_safe_os = _SafeOS()

import sys
sys.modules['os'] = _safe_os
'''
