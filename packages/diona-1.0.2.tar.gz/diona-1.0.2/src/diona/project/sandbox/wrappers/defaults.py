"""Default wrappers registration"""

from diona.project.sandbox.wrappers.registry import get_registry
from diona.project.sandbox.wrappers.os_wrapper import OSWrapper
from diona.project.sandbox.wrappers.io_wrapper import IOWrapper
from diona.project.sandbox.wrappers.import_wrapper import ImportWrapper


def register_default_wrappers() -> None:
    """Register all default wrappers"""
    registry = get_registry()
    
    registry.register_module(OSWrapper)
    registry.register_builtin(ImportWrapper)
