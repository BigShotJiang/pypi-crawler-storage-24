"""IO module wrapper for sandbox - controls file open()"""

from diona.project.sandbox.wrappers.base import ModuleWrapper


class IOWrapper(ModuleWrapper):
    """IO wrapper - controls file operations through builtins.open"""
    
    @property
    def name(self) -> str:
        return "io"
    
    def get_import_code(self) -> str:
        return ""
    
    def get_dependencies(self) -> list:
        return []
    
    def get_wrapper_code(self) -> str:
        return '''_original_open = builtins.open
def _safe_open(*args, **kwargs):
    mode = kwargs.get('mode', 'r' if len(args) < 2 else args[1])
    if 'w' in mode or 'a' in mode or 'x' in mode:
        raise PermissionError("Writing to files is not allowed in sandbox")
    return _original_open(*args, **kwargs)

builtins.open = _safe_open
'''
