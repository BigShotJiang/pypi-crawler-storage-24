"""Sandbox configuration"""

from dataclasses import dataclass, field
from typing import Dict


@dataclass
class SandboxConfig:
    """Sandbox configuration"""
    timeout: float = 30.0
    memory_limit_mb: int = 256
    allow_network: bool = False
    allowed_dirs: list[str] = field(default_factory=list)
    env_vars: Dict[str, str] = field(default_factory=dict)
