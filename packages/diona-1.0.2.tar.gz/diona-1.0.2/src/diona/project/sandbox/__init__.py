"""Sandbox package for safe Python code execution"""

from diona.project.sandbox.config import SandboxConfig
from diona.project.sandbox.result import SandboxResult
from diona.project.sandbox.core import Sandbox

from diona.project.sandbox.core import Sandbox as _Sandbox
from diona.project.sandbox.config import SandboxConfig as _SandboxConfig


def execute_python(content: str, **kwargs) -> SandboxResult:
    """Convenience function to execute Python code.
    
    Args:
        content: Python code to execute
        **kwargs: SandboxConfig parameters
        
    Returns:
        SandboxResult: Contains return value, stdout, stderr
    """
    config = _SandboxConfig(**kwargs) if kwargs else _SandboxConfig()
    sandbox = _Sandbox(config)
    return sandbox.execute_with_timeout(content)


__all__ = [
    'Sandbox',
    'SandboxConfig', 
    'SandboxResult',
    'execute_python',
]
