"""Sandbox execution result"""

from typing import Any, Optional


class SandboxResult:
    """Sandbox execution result"""
    
    def __init__(
        self,
        return_value: Any = None,
        stdout: str = "",
        stderr: str = "",
        timed_out: bool = False,
        memory_exceeded: bool = False,
        error: Optional[str] = None,
    ):
        self.return_value = return_value
        self.stdout = stdout
        self.stderr = stderr
        self.timed_out = timed_out
        self.memory_exceeded = memory_exceeded
        self.error = error
    
    def __repr__(self):
        return (
            f"SandboxResult("
            f"return_value={self.return_value!r}, "
            f"stdout={self.stdout!r}, "
            f"stderr={self.stderr!r}, "
            f"timed_out={self.timed_out}, "
            f"memory_exceeded={self.memory_exceeded}, "
            f"error={self.error!r})"
        )
