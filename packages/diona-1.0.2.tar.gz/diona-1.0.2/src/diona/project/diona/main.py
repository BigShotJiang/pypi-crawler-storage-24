"""Main entry point for the diona command"""

import sys


def main():
    """Main function for the diona command"""
    args = sys.argv[1:]
    
    if "--webserver" in args or "-w" in args:
        from diona.project.cli.web import run_server
        run_server()
        return
    
    
    from diona.project.ui.loading import get_loading_bar
    loadingBar = get_loading_bar()
    loadingBar.start()
    from diona.project.cli import CLI
    cli = CLI()
    loadingBar.stop()
    cli.run()
    return



if __name__ == '__main__':
    main()
