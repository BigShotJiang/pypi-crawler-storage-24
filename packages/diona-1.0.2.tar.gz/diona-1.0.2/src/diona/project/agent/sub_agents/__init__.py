from .registry import SubAgentRegistry, get_sub_agent_registry
from .test import TestAgent, get_test_agent

registry = get_sub_agent_registry()

registry.register(
    name="test",
    description="A test agent that echoes your input",
    create_func=get_test_agent
)

__all__ = [
    "SubAgentRegistry",
    "get_sub_agent_registry",
    "TestAgent",
    "get_test_agent",
]
