from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional
from agents import Agent
from diona.project.agent.model import BaseModelProvider


@dataclass
class SubAgentInfo:
    name: str
    description: str
    create_func: Callable[[Optional[BaseModelProvider]], Agent]
    metadata: dict = field(default_factory=dict)


class SubAgentRegistry:
    _instance: Optional[SubAgentRegistry] = None

    def __new__(cls) -> SubAgentRegistry:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._agents: dict[str, SubAgentInfo] = {}
        self._initialized = True

    def register(
        self,
        name: str,
        description: str,
        create_func: Callable[[Optional[BaseModelProvider]], Agent],
        metadata: Optional[dict] = None
    ) -> None:
        self._agents[name] = SubAgentInfo(
            name=name,
            description=description,
            create_func=create_func,
            metadata=metadata or {}
        )

    def unregister(self, name: str) -> bool:
        if name in self._agents:
            del self._agents[name]
            return True
        return False

    def get(self, name: str) -> Optional[SubAgentInfo]:
        return self._agents.get(name)

    def list_all(self) -> list[SubAgentInfo]:
        return list(self._agents.values())

    def get_descriptions(self) -> list[dict[str, str]]:
        return [
            {"name": agent.name, "description": agent.description}
            for agent in self._agents.values()
        ]

    def clear(self) -> None:
        self._agents.clear()


_registry: Optional[SubAgentRegistry] = None


def get_sub_agent_registry() -> SubAgentRegistry:
    global _registry
    if _registry is None:
        _registry = SubAgentRegistry()
    return _registry
