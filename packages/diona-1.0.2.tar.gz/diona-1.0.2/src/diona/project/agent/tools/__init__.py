from diona.project.agent.tools.registry import get_tool_registry

from .global_memory_tool import global_memory_tool
from .sqlite_tool import sqlite_tool
from .file_storage_tool import write_file, read_file, write_diona_file, edit_file
from .shell_tool import shell_tool
from .skills_tool import skills_tool
from .todo_task_tool import todo_task_tool
from .python_sandbox_tool import python_sandbox_tool

_registry = get_tool_registry()

_registry.register(
    name="global_memory",
    description="Store and retrieve global memory",
    tool=global_memory_tool
)

_registry.register(
    name="sqlite",
    description="Execute SQLite database queries",
    tool=sqlite_tool
)

_registry.register(
    name="write_file",
    description="Write content to a file in any directory",
    tool=write_file
)

_registry.register(
    name="write_diona_file",
    description="Write content to a file in ~/.diona directory",
    tool=write_diona_file
)

_registry.register(
    name="read_file",
    description="Read content from a file",
    tool=read_file
)

_registry.register(
    name="edit_file",
    description="Edit file by line range with original content verification",
    tool=edit_file
)

_registry.register(
    name="shell",
    description="Execute shell commands with security protections",
    tool=shell_tool
)

_registry.register(
    name="python_sandbox",
    description="Execute Python code in a secure sandbox environment",
    tool=python_sandbox_tool
)

_registry.register(
    name="skills",
    description="List and retrieve AI skills for specialized capabilities",
    tool=skills_tool
)

_registry.register(
    name="todo_task",
    description="Manage global todo tasks",
    tool=todo_task_tool
)

__all__ = [
    'global_memory_tool',
    'sqlite_tool',
    'write_file',
    'write_diona_file',
    'edit_file',
    'read_file',
    'shell_tool',
    'python_sandbox_tool',
    'skills_tool',
    'todo_task_tool',
    'get_tool_registry',
]
