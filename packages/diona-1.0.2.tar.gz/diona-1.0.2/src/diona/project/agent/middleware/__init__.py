from .base import Middleware
from .context import MiddlewareContext, AgentResult
from .moderation import ModerationMiddleware, get_moderation_middleware
from .storage import MiddlewareStorage, get_middleware_storage
from .registry import MiddlewareRegistry, get_middleware_registry

registry = get_middleware_registry()

registry.register(
    name="moderation",
    description="Checks user input for dangerous or inappropriate content",
    create_func=get_moderation_middleware,
    metadata={"pre_agent": True}
)

__all__ = [
    "Middleware",
    "MiddlewareContext",
    "AgentResult",
    "ModerationMiddleware",
    "get_moderation_middleware",
    "MiddlewareStorage",
    "get_middleware_storage",
    "MiddlewareRegistry",
    "get_middleware_registry",
]
