from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable, Optional
from agents import Agent
from diona.project.agent.model import BaseModelProvider


@dataclass
class HandoffAgentInfo:
    name: str
    description: str
    create_func: Callable[[Optional[BaseModelProvider]], Agent]
    metadata: dict = field(default_factory=dict)


class HandoffRegistry:
    _instance: Optional[HandoffRegistry] = None

    def __new__(cls) -> HandoffRegistry:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self):
        if self._initialized:
            return
        self._agents: dict[str, HandoffAgentInfo] = {}
        self._initialized = True

    def register(
        self,
        name: str,
        description: str,
        create_func: Callable[[Optional[BaseModelProvider]], Agent],
        metadata: Optional[dict] = None
    ) -> None:
        self._agents[name] = HandoffAgentInfo(
            name=name,
            description=description,
            create_func=create_func,
            metadata=metadata or {}
        )

    def unregister(self, name: str) -> bool:
        if name in self._agents:
            del self._agents[name]
            return True
        return False

    def get(self, name: str) -> Optional[HandoffAgentInfo]:
        return self._agents.get(name)

    def list_all(self) -> list[HandoffAgentInfo]:
        return list(self._agents.values())

    def get_descriptions(self) -> list[dict[str, str]]:
        return [
            {"name": agent.name, "description": agent.description}
            for agent in self._agents.values()
        ]

    def clear(self) -> None:
        self._agents.clear()


_registry: Optional[HandoffRegistry] = None


def get_handoff_registry() -> HandoffRegistry:
    global _registry
    if _registry is None:
        _registry = HandoffRegistry()
    return _registry
