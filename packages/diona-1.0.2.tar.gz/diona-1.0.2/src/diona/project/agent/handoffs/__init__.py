from .registry import HandoffRegistry, get_handoff_registry
from .learning_agent import get_learning_agent
from .data_analysis_agent import get_data_analysis_agent

registry = get_handoff_registry()

registry.register(
    name="learning",
    description="Helps users learn through Socratic questioning method",
    create_func=get_learning_agent
)

registry.register(
    name="data_analysis",
    description="Analyzes data from SQLite databases and command-line input",
    create_func=get_data_analysis_agent
)

__all__ = [
    "HandoffRegistry",
    "get_handoff_registry",
    "get_learning_agent",
    "get_data_analysis_agent",
]
