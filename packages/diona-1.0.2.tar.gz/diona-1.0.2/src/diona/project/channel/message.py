"""Message model for channel communication"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Any, Optional, Dict
from enum import Enum
import uuid


class MessagePriority(Enum):
    LOW = "low"
    NORMAL = "normal"
    HIGH = "high"
    CRITICAL = "critical"


class MessageType(Enum):
    REQUEST = "request"
    RESPONSE = "response"
    EVENT = "event"
    BROADCAST = "broadcast"
    NOTIFICATION = "notification"


@dataclass
class Message:
    """Base message model for channel communication"""
    
    id: str = field(default_factory=lambda: str(uuid.uuid4()))
    channel: str = ""
    type: MessageType = MessageType.EVENT
    priority: MessagePriority = MessagePriority.NORMAL
    payload: Any = None
    sender: str = ""
    receiver: str = ""
    timestamp: datetime = field(default_factory=datetime.now)
    correlation_id: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)
    
    def reply(self, payload: Any, **metadata) -> "Message":
        """Create a reply message"""
        return Message(
            channel=self.channel,
            type=MessageType.RESPONSE,
            payload=payload,
            sender=self.receiver,
            receiver=self.sender,
            correlation_id=self.id,
            metadata=metadata
        )
    
    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "channel": self.channel,
            "type": self.type.value,
            "priority": self.priority.value,
            "payload": self.payload,
            "sender": self.sender,
            "receiver": self.receiver,
            "timestamp": self.timestamp.isoformat(),
            "correlation_id": self.correlation_id,
            "metadata": self.metadata
        }


@dataclass
class RequestMessage(Message):
    """Request message with expected response"""
    
    def __init__(self, channel: str, payload: Any, sender: str = "", receiver: str = "", **kwargs):
        super().__init__(
            channel=channel,
            type=MessageType.REQUEST,
            payload=payload,
            sender=sender,
            receiver=receiver,
            **kwargs
        )


@dataclass
class ResponseMessage(Message):
    """Response message"""
    
    success: bool = True
    error: Optional[str] = None
    
    def __init__(self, channel: str, payload: Any, success: bool = True, error: Optional[str] = None, **kwargs):
        super().__init__(
            channel=channel,
            type=MessageType.RESPONSE,
            payload=payload,
            **kwargs
        )
        self.success = success
        self.error = error


@dataclass
class EventMessage(Message):
    """Event message for pub/sub"""
    
    def __init__(self, channel: str, event_name: str, payload: Any = None, **kwargs):
        super().__init__(
            channel=channel,
            type=MessageType.EVENT,
            payload={"event_name": event_name, "data": payload},
            **kwargs
        )
        self.event_name = event_name
