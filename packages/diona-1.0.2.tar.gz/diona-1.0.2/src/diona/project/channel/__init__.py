"""
Channel Module - Async message communication for Diona

Quick Start:
```python
from diona.project.channel import Channel, Message, get_channel_manager

# Get or create channel
manager = get_channel_manager()
channel = await manager.get_channel("my_channel")

# Subscribe to messages
async def handler(msg):
    print(f"Received: {msg.payload}")

channel.subscribe("my_channel", handler)

# Send message
await channel.send("my_channel", "Hello World!")

# Or use handlers
from diona.project.channel.handlers import EventListener, RequestHandler

class MyHandler(EventListener):
    async def on_event(self, event_name, data, message):
        print(f"Event: {event_name}, Data: {data}")

handler = MyHandler(channel)
```

Architecture:
- message.py: Message models (Message, RequestMessage, ResponseMessage, EventMessage)
- subscriber.py: Subscription management (Subscriber, SubscriberRegistry)
- channel.py: Core channel implementation (Channel, ChannelOptions)
- manager.py: Channel management (ChannelManager, get_channel_manager)
- handlers.py: Quick handlers via inheritance (MessageHandler, EventListener, RequestHandler)
"""

from .message import (
    Message,
    MessageType,
    MessagePriority,
    RequestMessage,
    ResponseMessage,
    EventMessage
)
from .subscriber import Subscriber, SubscriberRegistry, SubscriptionType
from .channel import Channel, ChannelOptions
from .manager import ChannelManager, get_channel_manager
from .handlers import (
    MessageHandler,
    EventListener,
    RequestHandler,
    ChannelClient,
    SyncMessageHandler
)

__all__ = [
    # Message models
    "Message",
    "MessageType",
    "MessagePriority",
    "RequestMessage",
    "ResponseMessage",
    "EventMessage",
    # Subscriber
    "Subscriber",
    "SubscriberRegistry",
    "SubscriptionType",
    # Channel
    "Channel",
    "ChannelOptions",
    # Manager
    "ChannelManager",
    "get_channel_manager",
    # Handlers
    "MessageHandler",
    "EventListener",
    "RequestHandler",
    "ChannelClient",
    "SyncMessageHandler",
]
