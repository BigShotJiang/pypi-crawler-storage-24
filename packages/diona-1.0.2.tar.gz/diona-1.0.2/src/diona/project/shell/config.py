"""Configuration for shell commander"""

import sys
import os
from dataclasses import dataclass, field
from typing import List, Dict, Optional


def _get_default_encoding() -> str:
    """Get platform-specific default encoding"""
    if sys.platform == "win32":
        return "gbk"
    return "utf-8"


def _get_default_blacklist() -> List[str]:
    """Get platform-specific default blacklist"""
    
    common = [
        "eval", "exec", "system", "passthru", "shell_exec",
        "base64", "decode", "encode",
        "sudo", "su ",
        "| rm ", "| del ", "| rmdir",
        "&& rm", "&& del", "&& rmdir",
        "; rm", "; del", "; rmdir",
        "0>/dev/null", ">NUL", ">NUL",
        "chmod 777", "chmod -r", "chmod -w",
        "icacls", "takeown", "cacls", "python",
        " rm ", "rm -", "rm -rf", "rm -r", "rm -f", "rm -fr",
        " del ", "del /", "del -",
    ]
    
    if sys.platform == "win32":
        return common + [
            "del ", "del /f", "del /s", "del /q", "del /f /s /q",
            "rd /s", "rd /q", "rd /s /q", "rmdir /s /q",
            "erase", "erase /f", "erase /q",
            "format", "format.com",
            "diskpart", "diskpart.exe",
            "reg delete", "reg add", "regedit",
            "net user", "net localgroup", "net account",
            "net session", "net stop", "net start",
            "runas", "runas.exe",
            "schtasks", "at.exe", "tasklist",
            "taskkill", "taskkill /f", "tskill",
            "wmic", "wmic.exe",
            "powershell", "powershell.exe", "pwsh",
            "cmd /c", "cmd.exe /c",
            "cscript", "wscript",
            "mshta", "mshta.exe",
            "rundll32", "rundll32.exe",
            "msiexec", "msiexec.exe",
            "bcdedit", "bootrec", "bootrec.exe",
            "shutdown", "shutdown.exe",
            "restart-computer", "stop-computer",
            "systeminfo", "systeminfo.exe",
            "driverquery",
            "typeperf", "logman",
            "wevtutil",
            "curl.exe", "Invoke-WebRequest", "Invoke-Expression",
            "iex ", "iex( ",
            "New-Object.*Net.WebClient",
            "bitsadmin", "bitsadmin.exe",
            "certutil",
            "ftp", "ftp.exe",
            "tftp", "tftp.exe",
            "netcat", "nc.exe", "ncat",
            "telnet", "rcmd", "rsh",
            "finger", "whoami /all",
            "quser", "query user",
        ]
    else:
        return common + [
            "rm -rf", "rm -r", "rm -f", "rmdir",
            "rm -fr", "rm -rf /", "rm -rf .",
            "del ", "erase ",
            "mv /dev/null", ">/dev/sd",
            "dd if=", "dd of=",
            "mkfs", "mkfs.ext", "mkfs.xfs",
            "fdisk", "parted", "gparted",
            "losetup", "cryptsetup", "luksFormat",
            "mount -o loop", "umount -f",
            "chroot", "pivot_root",
            "init 0", "init 1", "init 6",
            "telinit 0", "telinit 6",
            "reboot", "systemctl reboot",
            "shutdown -h", "shutdown -r", "poweroff",
            "halt", "pwoff",
            "useradd", "userdel", "usermod",
            "groupadd", "groupdel", "groupmod",
            "passwd", "chpasswd",
            "visudo", "sudoedit",
            "wget ", "curl ", "fetch",
            "lynx -dump", "w3m",
            "nc ", "netcat ", "socat",
            "ssh ", "scp ", "sftp ",
            "ftp ", "tftp ",
            "nmap", "nikto", "sqlmap",
            "python -c", "perl -e", "ruby -e",
            "bash -c", "sh -c", "zsh -c",
            "fish -c",
            "source /etc/passwd",
            "cat /etc/shadow", "unshadow",
            "chmod u+s", "chmod +s", "chmod 4777",
            "chown", "chgrp",
            "setfacl", "getfacl",
            "killall", "killall -9",
            "pkill -9", "pkill -f",
            "reboot", "shutdown",
            "systemctl", "service ",
            "journalctl",
            "crontab -r", "crontab -e",
            "at ", "atrm",
            "screen -dm", "tmux new-session",
            "nohup &",
            "disown -a",
            "export PATH=", "export HOME=",
            "ln -sf", "ln -nsf",
            "mount --bind", "mount -o bind",
        ]


@dataclass
class ShellConfig:
    """Shell commander configuration"""
    encoding: str = field(default_factory=_get_default_encoding)
    
    command_blacklist: Optional[List[str]] = field(default_factory=_get_default_blacklist)
    
    cwd: Optional[str] = None
    cwd_whitelist: Optional[List[str]] = None
    
    env: Optional[Dict[str, str]] = field(default_factory=dict)
    
    timeout: Optional[int] = 60
    
    allow_absolute_paths: bool = False
    allowed_dirs: Optional[List[str]] = None
    
    block_home_directory: bool = True
    expand_home_directory: bool = True
