"""Web mode handler for remote CLI execution"""

from typing import AsyncIterator
from diona.project.cli.web.base import BaseWebExecutor
from diona.project.cli.engine.result import StreamChunk


class WebModeHandler(BaseWebExecutor):
    """Handler for web mode - executes commands via HTTP to remote CLI server"""

    async def execute(self, user_input: str) -> AsyncIterator[StreamChunk]:
        if user_input == "$exit":
            from diona.project.cli.modes import get_mode_manager
            from diona.project.cli.engine.constants import CLIConstants
            get_mode_manager().set_mode(CLIConstants.MODE_CLIENT)
            yield StreamChunk(content="Exited to client mode.\n", is_final=True)
            return

        async for chunk in self.execute_remote(user_input):
            yield chunk


_handler: "WebModeHandler" = None


def get_web_mode_handler() -> WebModeHandler:
    global _handler
    if _handler is None:
        _handler = WebModeHandler()
    return _handler
