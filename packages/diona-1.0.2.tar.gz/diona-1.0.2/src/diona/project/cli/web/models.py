"""Web models for CLI web server"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class CommandRequest:
    """Request model for command execution"""
    command: str


@dataclass
class CommandResponse:
    """Response model for command execution"""
    success: bool
    return_code: int
    stdout: str
    stderr: str
    error_message: Optional[str] = None
