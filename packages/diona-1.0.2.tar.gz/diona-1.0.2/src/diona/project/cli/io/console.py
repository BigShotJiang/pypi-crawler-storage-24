def display_banner():
    print(r"""
  _____  _                   
 |  __ \(_)                  
 | |  | |_  ___  _ __   __ _ 
 | |  | | |/ _ \| '_ \ / _` |
 | |__| | | (_) | | | | (_| |
 |_____/|_|\___/|_| |_|\__,_|                      
    """)
    print("Welcome to Diona CLI!")
    print("Type /help for available commands.\n")


def get_prompt(is_agent_mode: bool = False) -> str:
    if is_agent_mode:
        return "agent> "
    return "> "
