from ..base import Command
import os


class EnvCommand(Command):
    name = "env"
    description = "Show environment variables"

    def execute(self, args):
        if args:
            key = args[0]
            value = os.environ.get(key, "(not set)")
            print(f"{key}={value}")
        else:
            print("Environment variables:")
            for key, value in sorted(os.environ.items()):
                print(f"  {key}={value}")
        return False
