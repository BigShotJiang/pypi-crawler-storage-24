from ..base import Command


class EchoCommand(Command):
    name = "echo"
    description = "Echo the input"

    def execute(self, args):
        print(" ".join(args) if args else "")
        return False
