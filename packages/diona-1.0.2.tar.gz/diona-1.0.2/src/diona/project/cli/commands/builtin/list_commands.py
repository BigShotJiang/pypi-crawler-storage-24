from ..base import Command
from diona.project.cli.commands import get_command_registry


class ListCommandsCommand(Command):
    name = "list-commands"
    description = "List all registered commands (from CommandModel)"

    def execute(self, args):
        registry = get_command_registry()
        registered_commands = registry.list_registered()
        
        if not registered_commands:
            print("No registered commands found.")
            print("Use CommandModel to register commands from your modules.")
            return False
        
        print("Registered commands:")
        for cmd in registered_commands:
            print(f"  /{cmd.name}: {cmd.description}")
            if cmd.parameters:
                print(f"    Parameters:")
                for param in cmd.parameters:
                    required = "required" if param.required else "optional"
                    print(f"      - {param.name} ({param.param_type}, {required}): {param.description}")
        
        print(f"\nTotal: {len(registered_commands)} registered commands")
        return False
