from ..base import Command
from diona.project.agent.globals import get_global_memory


class GlobalMemoryCommand(Command):
    name = "global-memory"
    description = "Query global memory"

    def execute(self, args):
        memory = get_global_memory()
        count = memory.get_memory_count()
        char_count = memory.get_memory_char_count()
        
        print(f"Global Memory Statistics:")
        print(f"- Total entries: {count}")
        print(f"- Total characters: {char_count}")
        
        if count > 0:
            print("\nGlobal Memory Entries:")
            memories = memory.list_memories(1, 10)
            for key, value in memories:
                print(f"- {key}: {value}")
        
        return False
