from ..base import Command
from diona.project.agent import get_agent_facade


class SessionCommand(Command):
    name = "session"
    description = "Manage agent sessions"

    def execute(self, args):
        facade = get_agent_facade()
        
        if not args:
            print("Usage: /session <create|list|delete|set> [args]")
            return False
        
        action = args[0]
        
        if action == "create":
            session_id = facade.create_session()
            print(f"Created session: {session_id}")
        
        elif action == "list":
            sessions = facade.list_sessions()
            print("Sessions:")
            for s in sessions:
                print(f"  - {s.session_id}: {s.name}")
        
        elif action == "delete":
            if len(args) < 2:
                print("Usage: /session delete <session_id>")
                return False
            facade.delete_session(args[1])
            print(f"Deleted session: {args[1]}")
        
        elif action == "set":
            if len(args) < 2:
                print("Usage: /session set <session_id>")
                return False
            facade.set_current_session(args[1])
            print(f"Set current session: {args[1]}")
        
        else:
            print(f"Unknown action: {action}")
        
        return False
