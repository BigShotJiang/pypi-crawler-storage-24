from ..base import Command
from datetime import datetime


class DateCommand(Command):
    name = "date"
    description = "Show current date"

    def execute(self, args):
        now = datetime.now()
        print(f"Current date: {now.strftime('%Y-%m-%d')}")
        return False
