from ..base import Command
from diona.project.agent.globals import get_global_knowledge_center, IMPORTANCE_LEVELS


class GlobalKnowledgeCommand(Command):
    name = "global-knowledge"
    description = "Manage global knowledge"

    def execute(self, args):
        center = get_global_knowledge_center()
        
        if not args:
            print("Usage: /global-knowledge <list|query> [args]")
            return False
        
        action = args[0]
        
        if action == "list":
            categories = center.list_categories()
            count = center.get_count()
            print(f"Total knowledge: {count}")
            print(f"Categories: {len(categories)}")
            for cat in categories:
                cat_count = center.get_count(cat)
                print(f"- {cat}: {cat_count}")
        
        elif action == "query":
            results = center.query_knowledge(keyword=" ".join(args[1:]) if len(args) > 1 else None)
            for knowledge in results:
                print(f"[ID: {knowledge.id}] {knowledge.category}: {knowledge.content[:50]}...")
        
        else:
            print(f"Unknown action: {action}")
        
        return False
