from ..base import Command


class ExitCommand(Command):
    name = "exit"
    description = "Exit the CLI"

    def execute(self, args):
        return True
