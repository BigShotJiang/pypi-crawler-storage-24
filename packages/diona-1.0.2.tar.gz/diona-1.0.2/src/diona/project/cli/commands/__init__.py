from .base import (
    Command,
    CommandRegistry,
    CommandParameter,
    CommandModel,
    get_command_registry
)
from .executor import (
    BuiltinExecutor,
    RegisteredExecutor,
    SystemExecutor,
    AgentExecutor
)

registry = get_command_registry()

from .builtin.exit import ExitCommand
from .builtin.help import HelpCommand
from .builtin.time import TimeCommand
from .builtin.date import DateCommand
from .builtin.echo import EchoCommand
from .builtin.env import EnvCommand
from .builtin.list_commands import ListCommandsCommand

registry.register("exit", ExitCommand())
registry.register("help", HelpCommand())
registry.register("time", TimeCommand())
registry.register("date", DateCommand())
registry.register("echo", EchoCommand())
registry.register("env", EnvCommand())
registry.register("list-commands", ListCommandsCommand())

try:
    from .builtin.session import SessionCommand
    registry.register("session", SessionCommand())
except Exception:
    pass

try:
    from .builtin.sub import SubCommand
    registry.register("sub", SubCommand())
except Exception:
    pass

try:
    from .builtin.global_memory import GlobalMemoryCommand
    registry.register("global-memory", GlobalMemoryCommand())
except Exception:
    pass

try:
    from .builtin.global_knowledge import GlobalKnowledgeCommand
    registry.register("global-knowledge", GlobalKnowledgeCommand())
except Exception:
    pass

try:
    from .builtin.agent_task import AgentTaskCommand
    registry.register("task", AgentTaskCommand())
except Exception:
    pass

try:
    from .builtin.model_provider import ModelProviderCommand
    registry.register("model", ModelProviderCommand())
except Exception:
    pass

try:
    from .builtin.todo import TodoCommand
    registry.register("todo", TodoCommand())
except Exception:
    pass

try:
    from .builtin.skill import SkillCommand
    registry.register("skill", SkillCommand())
except Exception:
    pass

from . import register_sensitive

__all__ = [
    "Command",
    "CommandRegistry",
    "CommandParameter",
    "CommandModel",
    "get_command_registry",
    "BuiltinExecutor",
    "RegisteredExecutor",
    "SystemExecutor",
    "AgentExecutor",
]
