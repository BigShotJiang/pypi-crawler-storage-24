from ..base import Command
from diona.project.cli.commands import get_command_registry


class HelpCommand(Command):
    name = "help"
    description = "Show help information"

    def execute(self, args):
        registry = get_command_registry()
        print("Available commands:")
        for cmd in registry.list_all():
            print(f"  /{cmd.name}: {cmd.description}")
        return False
