from ..base import Command
from diona.project.agent import get_sub_agent_registry


class SubCommand(Command):
    name = "sub"
    description = "Call a sub-agent"

    def execute(self, args):
        if not args:
            print("Usage: /sub <agent_name> [input]")
            return False
        
        agent_name = args[0]
        user_input = " ".join(args[1:]) if len(args) > 1 else ""
        
        registry = get_sub_agent_registry()
        agent_info = registry.get(agent_name)
        
        if not agent_info:
            print(f"Sub-agent '{agent_name}' not found")
            return False
        
        try:
            result = agent_info.callable(user_input)
            print(result)
        except Exception as e:
            print(f"Error: {e}")
        
        return False
