from ..base import Command
from datetime import datetime


class TimeCommand(Command):
    name = "time"
    description = "Show current time"

    def execute(self, args):
        now = datetime.now()
        print(f"Current time: {now.strftime('%H:%M:%S')}")
        return False
