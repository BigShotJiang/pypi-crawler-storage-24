"""Web mode adapter - only supports remote command execution"""

from typing import AsyncIterator
from diona.project.cli.web.base import BaseWebExecutor
from diona.project.cli.engine.result import StreamChunk


class WebAdapter(BaseWebExecutor):
    """Web mode adapter - minimal implementation
    
    Supports:
    - Remote command execution via HTTP to web server
    """

    async def execute(self, user_input: str) -> AsyncIterator[StreamChunk]:
        if user_input == "$exit":
            yield StreamChunk(content="Exited to client mode.\n", is_final=True)
            return

        async for chunk in self.execute_remote(user_input):
            yield chunk


_adapter: "WebAdapter" = None


def get_web_adapter() -> WebAdapter:
    global _adapter
    if _adapter is None:
        _adapter = WebAdapter()
    return _adapter
