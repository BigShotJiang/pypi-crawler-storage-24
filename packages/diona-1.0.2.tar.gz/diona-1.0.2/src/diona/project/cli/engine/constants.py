class CLIConstants:
    MODE_PREFIX = "$"
    LOCAL_PREFIX = "/local "
    
    MODE_AGENT = "agent"
    MODE_WEB = "web"
    MODE_CLIENT = "client"
    MODE_EXIT = "exit"
