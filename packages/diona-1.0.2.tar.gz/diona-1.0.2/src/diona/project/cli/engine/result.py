from enum import Enum
from dataclasses import dataclass
from typing import Any, Optional


class InputType(Enum):
    BUILTIN = "builtin"
    REGISTERED = "registered"
    AGENT = "agent"
    SYSTEM = "system"


@dataclass
class ParsedInput:
    raw_input: str
    input_type: InputType
    command_name: str
    args: list
    is_exit: bool = False


@dataclass
class StreamChunk:
    content: str = ""
    is_final: bool = False
    is_error: bool = False


@dataclass
class ExecutionResult:
    success: bool = True
    output: str = ""
    error: Optional[str] = None
