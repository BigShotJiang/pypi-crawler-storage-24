from .manager import Mode


class WebMode(Mode):
    @property
    def name(self) -> str:
        return "web"

    @property
    def prompt_prefix(self) -> str:
        return "web> "

    def should_exit(self, user_input: str) -> bool:
        return user_input.strip() == "$exit"
