from .manager import Mode


class AgentMode(Mode):
    @property
    def name(self) -> str:
        return "agent"

    @property
    def prompt_prefix(self) -> str:
        return "agent> "

    def should_exit(self, user_input: str) -> bool:
        return user_input.strip() in ("$exit", "/exit")
