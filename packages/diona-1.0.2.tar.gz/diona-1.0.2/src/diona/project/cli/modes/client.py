from .manager import Mode


class ClientMode(Mode):
    @property
    def name(self) -> str:
        return "client"

    @property
    def prompt_prefix(self) -> str:
        return "> "

    def should_exit(self, user_input: str) -> bool:
        return False


class AgentMode(Mode):
    @property
    def name(self) -> str:
        return "agent"

    @property
    def prompt_prefix(self) -> str:
        return "agent> "

    def should_exit(self, user_input: str) -> bool:
        return user_input.strip() in ("$exit", "/exit")


class WebMode(Mode):
    @property
    def name(self) -> str:
        return "web"

    @property
    def prompt_prefix(self) -> str:
        return "web> "

    def should_exit(self, user_input: str) -> bool:
        return user_input.strip() == "$exit"
