from diona.project.cli.engine import get_engine
from diona.project.cli.commands import get_command_registry
from diona.project.cli.facade import CLIFacade, get_cli_facade

_engine = None


def get_cli_engine():
    global _engine
    if _engine is None:
        _engine = get_engine()
    return _engine


class CLI:
    def __init__(self):
        self.running = False
        self._engine = get_cli_engine()

    def run(self):
        from diona.project.cli.io import display_banner
        
        self.running = True
        display_banner()

        while self.running:
            prompt = f"{self._engine.get_prompt_prefix()} "
            try:
                user_input = input(prompt)
                if not user_input.strip():
                    continue

                self._engine.execute_sync(user_input)
            except KeyboardInterrupt:
                print("\nExiting...")
                self.running = False
            except EOFError:
                print("\nExiting...")
                self.running = False

        print("Goodbye!")


__all__ = [
    "CLI",
    "get_cli_engine",
    "get_command_registry",
    "CLIFacade",
    "get_cli_facade",
]
