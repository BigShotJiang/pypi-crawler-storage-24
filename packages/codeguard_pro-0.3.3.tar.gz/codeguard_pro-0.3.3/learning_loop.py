"""Reviewable learning loop for new threats and missed detections.

Stores suspicious samples as JSON artifacts, generates issue-ready markdown,
and summarizes the local learning corpus. This is intentionally review-first:
it does not auto-modify detection rules.
"""

import json
import os
import re
import time
from collections import Counter
from typing import Dict, List, Optional


DEFAULT_CORPUS_DIR = "learning"


def _safe_slug(text: str, fallback: str = "sample") -> str:
    slug = re.sub(r"[^a-zA-Z0-9]+", "-", text.strip().lower()).strip("-")
    return slug[:60] or fallback


def _ensure_dirs(corpus_dir: str) -> Dict[str, str]:
    base = os.path.abspath(corpus_dir)
    candidates = os.path.join(base, "candidates")
    issues = os.path.join(base, "issues")
    os.makedirs(candidates, exist_ok=True)
    os.makedirs(issues, exist_ok=True)
    return {"base": base, "candidates": candidates, "issues": issues}


def record_candidate(
    title: str,
    code: str,
    language: str = "python",
    source: str = "manual",
    expected_behavior: str = "",
    regex_findings: Optional[List[Dict]] = None,
    ai_findings: Optional[List[Dict]] = None,
    corpus_dir: str = DEFAULT_CORPUS_DIR,
) -> Dict:
    """Persist a suspicious sample for later review."""
    dirs = _ensure_dirs(corpus_dir)
    ts = time.strftime("%Y%m%d-%H%M%S")
    slug = _safe_slug(title)
    candidate_id = f"{ts}-{slug}"
    path = os.path.join(dirs["candidates"], f"{candidate_id}.json")

    data = {
        "id": candidate_id,
        "title": title,
        "language": language,
        "source": source,
        "expected_behavior": expected_behavior,
        "created_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "regex_findings": regex_findings or [],
        "ai_findings": ai_findings or [],
        "code": code,
        "status": "triage",
    }

    with open(path, "w") as f:
        json.dump(data, f, indent=2)
        f.write("\n")

    return {
        "status": "RECORDED",
        "id": candidate_id,
        "path": path,
        "regex_findings": len(data["regex_findings"]),
        "ai_findings": len(data["ai_findings"]),
    }


def load_candidate(candidate_path: str) -> Dict:
    with open(candidate_path, "r") as f:
        return json.load(f)


def generate_issue_markdown(candidate_path: str, corpus_dir: str = DEFAULT_CORPUS_DIR) -> Dict:
    """Generate a GitHub-issue-ready markdown report from a candidate."""
    dirs = _ensure_dirs(corpus_dir)
    candidate = load_candidate(candidate_path)
    regex_count = len(candidate.get("regex_findings", []))
    ai_count = len(candidate.get("ai_findings", []))
    capability = "unknown"
    if ai_count and not regex_count:
        capability = "AI-only detection"
    elif regex_count and ai_count:
        capability = "Both layers detected"
    elif regex_count:
        capability = "Regex-only detection"

    md = "\n".join([
        f"# Detection Gap: {candidate.get('title', candidate.get('id', 'unknown'))}",
        "",
        "## Summary",
        f"- Candidate ID: `{candidate.get('id', 'unknown')}`",
        f"- Language: `{candidate.get('language', 'unknown')}`",
        f"- Source: `{candidate.get('source', 'unknown')}`",
        f"- Expected behavior: {candidate.get('expected_behavior', 'n/a') or 'n/a'}",
        f"- Current capability: {capability}",
        f"- Regex findings: {regex_count}",
        f"- AI findings: {ai_count}",
        "",
        "## Why This Matters",
        "This sample should be reviewed to determine whether it warrants a new deterministic detector, an AST rule, a red-team test, or a documentation-only limitation.",
        "",
        "## Reproduction Sample",
        f"```{candidate.get('language', 'text')}",
        candidate.get("code", ""),
        "```",
        "",
        "## Current Findings",
        "```json",
        json.dumps({
            "regex_findings": candidate.get("regex_findings", []),
            "ai_findings": candidate.get("ai_findings", []),
        }, indent=2),
        "```",
        "",
        "## Acceptance Criteria",
        "- Add or document the expected detector behavior.",
        "- Add a regression test covering this sample.",
        "- Avoid introducing false positives on clean code.",
    ])

    issue_path = os.path.join(dirs["issues"], f"{candidate['id']}.md")
    with open(issue_path, "w") as f:
        f.write(md)
        f.write("\n")

    return {"status": "ISSUE_READY", "path": issue_path, "candidate_id": candidate["id"]}


def corpus_summary(corpus_dir: str = DEFAULT_CORPUS_DIR) -> Dict:
    """Summarize all stored learning artifacts."""
    dirs = _ensure_dirs(corpus_dir)
    candidates = []
    for fname in sorted(os.listdir(dirs["candidates"])):
        if not fname.endswith(".json"):
            continue
        try:
            candidates.append(load_candidate(os.path.join(dirs["candidates"], fname)))
        except Exception:
            continue

    by_language = Counter(c.get("language", "unknown") for c in candidates)
    by_source = Counter(c.get("source", "unknown") for c in candidates)
    by_status = Counter(c.get("status", "triage") for c in candidates)
    ai_only = sum(1 for c in candidates if c.get("ai_findings") and not c.get("regex_findings"))
    regex_only = sum(1 for c in candidates if c.get("regex_findings") and not c.get("ai_findings"))
    both = sum(1 for c in candidates if c.get("regex_findings") and c.get("ai_findings"))

    return {
        "corpus_dir": dirs["base"],
        "total_candidates": len(candidates),
        "issue_drafts": len([f for f in os.listdir(dirs["issues"]) if f.endswith(".md")]),
        "by_language": dict(by_language),
        "by_source": dict(by_source),
        "by_status": dict(by_status),
        "coverage": {
            "ai_only": ai_only,
            "regex_only": regex_only,
            "both": both,
        },
    }
