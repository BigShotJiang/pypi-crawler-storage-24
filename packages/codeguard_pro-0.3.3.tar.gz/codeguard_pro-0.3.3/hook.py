#!/usr/bin/env python3
"""CodeGuard Pro — Git pre-commit hook.

Scans staged files for hardcoded secrets before they reach git history.
Install: codeguard install (or copy this to .git/hooks/pre-commit)
"""

import subprocess
import sys
import os

# Add codeguard to path
CODEGUARD_DIR = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, CODEGUARD_DIR)

from secret_scanner import scan_diff, scan_secrets, format_findings, SecretFinding

# ANSI colors
RED = "\033[91m"
YELLOW = "\033[93m"
GREEN = "\033[92m"
BOLD = "\033[1m"
RESET = "\033[0m"


def get_staged_diff() -> str:
    """Get the diff of staged changes."""
    try:
        result = subprocess.run(
            ["git", "diff", "--cached", "--diff-filter=ACMR"],
            capture_output=True, text=True, timeout=30
        )
        return result.stdout
    except Exception:
        return ""


def get_staged_files() -> list:
    """Get list of staged file paths."""
    try:
        result = subprocess.run(
            ["git", "diff", "--cached", "--name-only", "--diff-filter=ACMR"],
            capture_output=True, text=True, timeout=10
        )
        return [f.strip() for f in result.stdout.strip().split("\n") if f.strip()]
    except Exception:
        return []


def scan_staged_files() -> list:
    """Scan all staged files for secrets."""
    all_findings = []

    # Method 1: Scan the diff (catches secrets in added lines)
    diff = get_staged_diff()
    if diff:
        diff_findings = scan_diff(diff)
        all_findings.extend(diff_findings)

    # Method 2: Also scan full staged files for .env patterns
    files = get_staged_files()
    for filepath in files:
        basename = os.path.basename(filepath)

        # Block .env files entirely
        if basename.startswith('.env') and basename != '.env.example':
            all_findings.append(SecretFinding(
                line=0, column=0,
                secret_type=".env File",
                severity="CRITICAL",
                matched=filepath,
                raw_line=f"Attempting to commit {filepath}",
                fix=f"Add {filepath} to .gitignore",
                confidence=1.0,
            ))

    return all_findings


def main():
    """Pre-commit hook entry point."""
    print(f"{BOLD}CodeGuard Pro{RESET} — scanning for secrets...")

    findings = scan_staged_files()

    critical = [f for f in findings if f.severity == "CRITICAL"]
    high = [f for f in findings if f.severity == "HIGH"]

    if critical:
        print(f"\n{RED}{BOLD}BLOCKED{RESET} — {len(critical)} critical secret(s) found.\n")
        print(format_findings(findings, block_mode=True))
        print(f"\n{YELLOW}Fix the issues above, then: git add . && git commit{RESET}")
        sys.exit(1)

    if high:
        print(f"\n{YELLOW}WARNING{RESET} — {len(high)} potential secret(s) found.\n")
        print(format_findings(findings, block_mode=False))
        print(f"{YELLOW}Proceeding with commit (warnings only).{RESET}")

    if not findings:
        print(f"{GREEN}PASS{RESET} — No secrets detected.\n")

    sys.exit(0)


if __name__ == "__main__":
    main()
