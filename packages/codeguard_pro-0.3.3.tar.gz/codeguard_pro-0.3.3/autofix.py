"""LLM-powered auto-fix engine for CodeGuard Pro.

Takes code + security findings, generates exact fixes via MiniMax M2.7.
Falls back to pattern-based fixes when LLM is unavailable.
"""
import json, os, re, urllib.request, urllib.error
from dataclasses import dataclass
from typing import List, Optional
from secret_scanner import SecretFinding, scan_secrets

@dataclass(frozen=True)
class AutofixResult:
    """Immutable result from the autofix engine."""
    original_code: str
    fixed_code: str
    explanation: str
    used_llm: bool
    findings_fixed: int

def _load_api_key() -> Optional[str]:
    """Load MiniMax API key from env or /root/ai-factory/.env."""
    key = os.environ.get("MINIMAX_API_KEY")
    if key:
        return key
    env_path = "/root/ai-factory/.env"
    if os.path.exists(env_path):
        with open(env_path) as f:
            for line in f:
                if line.strip().startswith("MINIMAX_API_KEY="):
                    return line.strip().split("=", 1)[1].strip("'\" \n")
    return None

def _call_minimax(code: str, findings: List[SecretFinding]) -> Optional[str]:
    """Call MiniMax M2.7 to generate fixed code. Returns fixed code or None."""
    api_key = _load_api_key()
    if not api_key:
        return None
    findings_text = "\n".join(
        f"- Line {f.line}: {f.secret_type} ({f.severity}) — {f.fix}" for f in findings
    )
    messages = [
        {"role": "system", "content": (
            "You are a security-focused code fixer. Return ONLY the fixed code. "
            "No markdown fences, no explanation. Preserve formatting, comments, and logic. "
            "Only change lines with security issues. Add 'import os' if needed."
        )},
        {"role": "user", "content": (
            f"Fix these security issues:\n\nFINDINGS:\n{findings_text}\n\nCODE:\n{code}"
        )},
    ]
    payload = json.dumps({
        "model": "MiniMax-M2.7", "messages": messages,
        "temperature": 0.1, "max_tokens": 4096,
    }).encode()
    req = urllib.request.Request(
        "https://api.minimaxi.chat/v1/text/chatcompletion_v2",
        data=payload, method="POST",
        headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"},
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            data = json.loads(resp.read().decode())
        content = data["choices"][0]["message"]["content"]
        content = re.sub(r"^```\w*\n", "", content)
        content = re.sub(r"\n```$", "", content)
        return content.strip()
    except (urllib.error.URLError, KeyError, IndexError, json.JSONDecodeError):
        return None

# --- Pattern-based fallback fixes ---
_SECRET_TO_ENV = {
    "OpenAI API Key": "OPENAI_API_KEY", "Anthropic API Key": "ANTHROPIC_API_KEY",
    "GitHub Token": "GITHUB_TOKEN", "GitHub OAuth": "GITHUB_OAUTH_TOKEN",
    "Google API Key": "GOOGLE_API_KEY", "Stripe Secret Key": "STRIPE_SECRET_KEY",
    "Slack Token": "SLACK_TOKEN", "MiniMax API Key": "MINIMAX_API_KEY",
    "SendGrid Key": "SENDGRID_API_KEY", "Supabase Key": "SUPABASE_KEY",
    "Vercel Token": "VERCEL_TOKEN", "Generic API Key": "API_KEY",
    "Hardcoded Password": "APP_PASSWORD", "Database URL": "DATABASE_URL",
    "AWS Access Key": "AWS_ACCESS_KEY_ID",
}


def _fallback_fix(code: str, findings: List[SecretFinding]) -> str:
    """Apply pattern-based fixes when LLM is unavailable."""
    lines, needs_os = code.split("\n"), False
    for f in findings:
        if f.line < 1 or f.line > len(lines):
            continue
        env_name = _SECRET_TO_ENV.get(f.secret_type)
        if not env_name:
            m = re.search(r'os\.environ\["([^"]+)"\]', f.fix)
            env_name = m.group(1) if m else f.secret_type.upper().replace(" ", "_")
        replaced = re.sub(r"""(['"])[^\s'"]{8,}\1""", f'os.environ["{env_name}"]', lines[f.line - 1], count=1)
        if replaced != lines[f.line - 1]:
            needs_os = True
            lines[f.line - 1] = replaced
    # Fix SQL injection: f-string in cursor.execute -> parameterized
    for i, line in enumerate(lines):
        if "cursor.execute" in line and ("f'" in line or 'f"' in line):
            fixed = re.sub(
                r'''f(["\'])(.*?)\{(\w+)\}(.*?)\1''',
                lambda m: f'{m.group(1)}{m.group(2)}?{m.group(4)}{m.group(1)}, ({m.group(3)},)', line)
            if fixed != line:
                lines[i] = fixed
    result = "\n".join(lines)
    if needs_os and not re.search(r"^import os\b", result, re.MULTILINE):
        result = "import os\n" + result
    return result

def autofix(code: str, findings: Optional[List[SecretFinding]] = None) -> AutofixResult:
    """Generate fixes for security findings in code."""
    if findings is None:
        findings = scan_secrets(code)
    if not findings:
        return AutofixResult(original_code=code, fixed_code=code,
                             explanation="No security issues found.", used_llm=False, findings_fixed=0)
    llm_result = _call_minimax(code, findings)
    if llm_result:
        return AutofixResult(original_code=code, fixed_code=llm_result,
                             explanation=f"Fixed {len(findings)} finding(s) using MiniMax M2.7.",
                             used_llm=True, findings_fixed=len(findings))
    fixed = _fallback_fix(code, findings)
    return AutofixResult(original_code=code, fixed_code=fixed,
                         explanation=f"Fixed {len(findings)} finding(s) using pattern-based fallback.",
                         used_llm=False, findings_fixed=len(findings))


if __name__ == "__main__":
    sample = (
        'import requests\n\n'
        'API_KEY = "sk-proj-abc123def456ghi789jkl012mno345"\n'
        'DB_URL = "postgres://admin:supersecret@db.example.com:5432/prod"\n'
        'password = "hunter2isMyP@ss!"\n\n'
        'def get_data():\n'
        '    headers = {"Authorization": f"Bearer {API_KEY}"}\n'
        '    return requests.get("https://api.example.com/data", headers=headers)\n'
    )
    print("=" * 60)
    print("CodeGuard Pro — Auto-Fix Engine Demo")
    print("=" * 60)
    print(f"\nORIGINAL CODE:\n{sample}")
    result = autofix(sample)
    engine = "MiniMax M2.7" if result.used_llm else "Pattern-based fallback"
    print(f"Engine: {engine} | Findings fixed: {result.findings_fixed}")
    print(f"\nFIXED CODE:\n{result.fixed_code}")
    print(f"\n{result.explanation}")
