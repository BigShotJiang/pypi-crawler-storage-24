"""Smart code review tools — catches what linters miss."""

import re
import os
from typing import List, Dict, Any
from collections import Counter


def review_code(code: str, language: str = "python") -> str:
    """Run all review checks on code, return structured report."""
    issues = []

    lines = code.split("\n")

    # 1. Duplicate function detection
    func_names = _extract_functions(code, language)
    dupes = [name for name, count in Counter(func_names).items() if count > 1]
    if dupes:
        issues.append({"severity": "HIGH", "rule": "duplicate-function",
                       "message": f"Duplicate function definitions: {', '.join(dupes)}"})

    # 2. Hardcoded secrets detection
    secret_patterns = [
        (r'(?:api[_-]?key|apikey)\s*[=:]\s*["\'][a-zA-Z0-9_\-]{20,}["\']', "API key"),
        (r'(?:password|passwd|pwd)\s*[=:]\s*["\'][^"\']{8,}["\']', "Password"),
        (r'(?:secret|token)\s*[=:]\s*["\'][a-zA-Z0-9_\-]{20,}["\']', "Secret/Token"),
        (r'sk-[a-zA-Z0-9]{20,}', "OpenAI API key"),
        (r'ghp_[a-zA-Z0-9]{36}', "GitHub token"),
        (r'gho_[a-zA-Z0-9]{36}', "GitHub OAuth token"),
        (r'AKIA[0-9A-Z]{16}', "AWS Access Key"),
        (r'xox[bpors]-[a-zA-Z0-9\-]{10,}', "Slack token"),
    ]
    for pattern, label in secret_patterns:
        matches = re.finditer(pattern, code, re.IGNORECASE)
        for m in matches:
            line_num = code[:m.start()].count("\n") + 1
            issues.append({"severity": "CRITICAL", "rule": "hardcoded-secret",
                           "message": f"Possible {label} on line {line_num}", "line": line_num})

    # 3. Long function detection (>50 lines)
    long_funcs = _find_long_functions(code, language, threshold=50)
    for name, length in long_funcs:
        issues.append({"severity": "MEDIUM", "rule": "long-function",
                       "message": f"Function '{name}' is {length} lines (max recommended: 50)"})

    # 4. Deep nesting detection (>4 levels)
    deep_lines = _find_deep_nesting(lines, language, threshold=4)
    for line_num, depth in deep_lines:
        issues.append({"severity": "MEDIUM", "rule": "deep-nesting",
                       "message": f"Line {line_num}: nesting depth {depth} (max recommended: 4)",
                       "line": line_num})

    # 5. Inconsistent naming
    naming_issues = _check_naming(code, language)
    issues.extend(naming_issues)

    # 6. TODO/FIXME/HACK detection
    for i, line in enumerate(lines, 1):
        for marker in ["TODO", "FIXME", "HACK", "XXX", "TEMP"]:
            if marker in line.upper() and not line.strip().startswith("#!"):
                issues.append({"severity": "LOW", "rule": "tech-debt-marker",
                               "message": f"Line {i}: {marker} found — {line.strip()[:80]}",
                               "line": i})

    # 7. Unused imports (Python only)
    if language == "python":
        unused = _find_unused_imports(code)
        for imp in unused:
            issues.append({"severity": "LOW", "rule": "unused-import",
                           "message": f"Possibly unused import: {imp}"})

    # 8. Print/console.log left in code
    debug_patterns = {
        "python": [r'^\s*print\(', r'^\s*breakpoint\(\)'],
        "javascript": [r'console\.(log|debug|info)\(', r'debugger;'],
        "typescript": [r'console\.(log|debug|info)\(', r'debugger;'],
    }
    for pattern in debug_patterns.get(language, []):
        for i, line in enumerate(lines, 1):
            if re.search(pattern, line):
                issues.append({"severity": "LOW", "rule": "debug-statement",
                               "message": f"Line {i}: Debug statement left in code",
                               "line": i})

    return _format_report(issues, len(lines))


def review_file(file_path: str) -> str:
    """Review a file from disk."""
    if not os.path.isfile(file_path):
        return f"Error: File not found: {file_path}"

    with open(file_path, "r", errors="ignore") as f:
        code = f.read()

    ext_map = {
        ".py": "python", ".js": "javascript", ".ts": "typescript",
        ".tsx": "typescript", ".jsx": "javascript", ".go": "go",
        ".rs": "rust", ".java": "java", ".rb": "ruby",
    }
    ext = os.path.splitext(file_path)[1].lower()
    language = ext_map.get(ext, "unknown")

    return f"File: {file_path}\nLanguage: {language}\n\n{review_code(code, language)}"


def review_diff(diff_text: str) -> str:
    """Review a git diff — only checks added lines."""
    added_lines = []
    for line in diff_text.split("\n"):
        if line.startswith("+") and not line.startswith("+++"):
            added_lines.append(line[1:])

    if not added_lines:
        return "No added lines found in diff."

    code = "\n".join(added_lines)
    return f"Diff Review (added lines only):\n\n{review_code(code)}"


def _extract_functions(code: str, language: str) -> List[str]:
    """Extract function names from code."""
    patterns = {
        "python": r'def\s+(\w+)\s*\(',
        "javascript": r'(?:function\s+(\w+)|(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?(?:\([^)]*\)|[^=])\s*=>)',
        "typescript": r'(?:function\s+(\w+)|(?:const|let|var)\s+(\w+)\s*=\s*(?:async\s+)?(?:\([^)]*\)|[^=])\s*=>)',
        "go": r'func\s+(?:\([^)]+\)\s+)?(\w+)\s*\(',
    }
    pattern = patterns.get(language, patterns["python"])
    matches = re.findall(pattern, code)
    # Flatten tuples from alternation groups
    names = []
    for m in matches:
        if isinstance(m, tuple):
            names.extend([n for n in m if n])
        else:
            names.append(m)
    return names


def _find_long_functions(code: str, language: str, threshold: int = 50) -> List[tuple]:
    """Find functions longer than threshold lines."""
    results = []
    if language == "python":
        lines = code.split("\n")
        func_starts = []
        for i, line in enumerate(lines):
            m = re.match(r'^(\s*)def\s+(\w+)', line)
            if m:
                func_starts.append((i, len(m.group(1)), m.group(2)))

        for idx, (start, indent, name) in enumerate(func_starts):
            # Find end of function
            end = len(lines)
            if idx + 1 < len(func_starts):
                end = func_starts[idx + 1][0]
            else:
                # Scan for next line at same or lesser indent
                for j in range(start + 1, len(lines)):
                    stripped = lines[j].strip()
                    if stripped and not stripped.startswith("#"):
                        line_indent = len(lines[j]) - len(lines[j].lstrip())
                        if line_indent <= indent and not lines[j].strip().startswith("@"):
                            end = j
                            break

            length = end - start
            if length > threshold:
                results.append((name, length))

    return results


def _find_deep_nesting(lines: List[str], language: str, threshold: int = 4) -> List[tuple]:
    """Find lines with deep nesting."""
    results = []
    indent_size = 4 if language == "python" else 2

    for i, line in enumerate(lines, 1):
        stripped = line.lstrip()
        if not stripped or stripped.startswith("#") or stripped.startswith("//"):
            continue
        indent = len(line) - len(stripped)
        depth = indent // indent_size
        if depth > threshold:
            results.append((i, depth))

    # Limit to first 5 to avoid noise
    return results[:5]


def _check_naming(code: str, language: str) -> List[Dict]:
    """Check for naming inconsistencies."""
    issues = []

    if language == "python":
        # Check for camelCase functions (should be snake_case)
        funcs = re.findall(r'def\s+([a-z][a-zA-Z]*[A-Z][a-zA-Z]*)\s*\(', code)
        for func in funcs:
            issues.append({"severity": "LOW", "rule": "naming-convention",
                           "message": f"Function '{func}' uses camelCase — Python convention is snake_case"})

        # Check for non-UPPER constants
        consts = re.findall(r'^([A-Z][a-z_]+)\s*=\s*(?:[\d"\'\[\{])', code, re.MULTILINE)
        # This is less reliable, skip for now

    elif language in ("javascript", "typescript"):
        # Check for snake_case functions (should be camelCase)
        funcs = re.findall(r'function\s+([a-z]+_[a-z_]+)\s*\(', code)
        for func in funcs:
            issues.append({"severity": "LOW", "rule": "naming-convention",
                           "message": f"Function '{func}' uses snake_case — JS convention is camelCase"})

    return issues


def _find_unused_imports(code: str) -> List[str]:
    """Find potentially unused Python imports."""
    unused = []
    lines = code.split("\n")

    for line in lines:
        # Simple import
        m = re.match(r'^\s*import\s+(\w+)', line)
        if m:
            name = m.group(1)
            # Count usage (excluding import line itself)
            rest = code.replace(line, "", 1)
            if name not in rest:
                unused.append(name)

        # from X import Y
        m = re.match(r'^\s*from\s+\S+\s+import\s+(.+)', line)
        if m:
            imports_str = m.group(1)
            # Handle "import X as Y"
            for imp in imports_str.split(","):
                imp = imp.strip()
                if " as " in imp:
                    name = imp.split(" as ")[1].strip()
                else:
                    name = imp.strip()
                if name and name not in ("*",):
                    rest = code.replace(line, "", 1)
                    if re.search(r'\b' + re.escape(name) + r'\b', rest) is None:
                        unused.append(name)

    return unused


def _format_report(issues: List[Dict], total_lines: int) -> str:
    """Format issues into a readable report."""
    if not issues:
        return f"Code Review: PASS\n{total_lines} lines scanned, no issues found."

    # Sort by severity
    severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    issues.sort(key=lambda x: severity_order.get(x["severity"], 99))

    counts = Counter(i["severity"] for i in issues)

    report = [
        f"Code Review Report",
        f"{'='*50}",
        f"Lines scanned: {total_lines}",
        f"Issues found: {len(issues)}",
        f"  CRITICAL: {counts.get('CRITICAL', 0)}",
        f"  HIGH: {counts.get('HIGH', 0)}",
        f"  MEDIUM: {counts.get('MEDIUM', 0)}",
        f"  LOW: {counts.get('LOW', 0)}",
        f"",
        f"Grade: {'F' if counts.get('CRITICAL', 0) > 0 else 'D' if counts.get('HIGH', 0) > 0 else 'C' if counts.get('MEDIUM', 0) > 2 else 'B' if counts.get('LOW', 0) > 3 else 'A'}",
        f"{'='*50}",
        "",
    ]

    for issue in issues:
        line_info = f" (line {issue['line']})" if "line" in issue else ""
        report.append(f"[{issue['severity']}] {issue['rule']}{line_info}")
        report.append(f"  {issue['message']}")
        report.append("")

    return "\n".join(report)
