"""Security scanner — OWASP Top 10 + MCP server audit."""

import re
import os
import json
from typing import List, Dict, Any
from collections import Counter


def scan_security(code: str, language: str = "python") -> str:
    """Scan code for OWASP Top 10 and common security vulnerabilities."""
    vulns = []
    lines = code.split("\n")

    # A01: Broken Access Control
    _check_access_control(code, language, lines, vulns)

    # A02: Cryptographic Failures
    _check_crypto(code, language, lines, vulns)

    # A03: Injection (SQL, Command, LDAP, XPath)
    _check_injection(code, language, lines, vulns)

    # A04: Insecure Design — checked via review tool

    # A05: Security Misconfiguration
    _check_misconfig(code, language, lines, vulns)

    # A06: Vulnerable Components — checked via dependency scan

    # A07: Auth Failures
    _check_auth(code, language, lines, vulns)

    # A08: Data Integrity — checked via review tool

    # A09: Logging & Monitoring Failures
    _check_logging(code, language, lines, vulns)

    # A10: SSRF
    _check_ssrf(code, language, lines, vulns)

    # Additional: Path Traversal
    _check_path_traversal(code, language, lines, vulns)

    # Additional: Deserialization
    _check_deserialization(code, language, lines, vulns)

    return _format_security_report(vulns, len(lines))


def scan_file(file_path: str) -> str:
    """Scan a file for security vulnerabilities."""
    if not os.path.isfile(file_path):
        return f"Error: File not found: {file_path}"

    with open(file_path, "r", errors="ignore") as f:
        code = f.read()

    ext_map = {
        ".py": "python", ".js": "javascript", ".ts": "typescript",
        ".tsx": "typescript", ".jsx": "javascript", ".go": "go",
    }
    ext = os.path.splitext(file_path)[1].lower()
    language = ext_map.get(ext, "unknown")

    return f"Security Scan: {file_path}\n\n{scan_security(code, language)}"


def scan_directory(dir_path: str, extensions: str = ".py,.js,.ts") -> str:
    """Scan all matching files in a directory."""
    if not os.path.isdir(dir_path):
        return f"Error: Directory not found: {dir_path}"

    ext_list = [e.strip() for e in extensions.split(",")]
    all_vulns = []
    files_scanned = 0

    for root, dirs, files in os.walk(dir_path):
        # Skip common non-source dirs
        dirs[:] = [d for d in dirs if d not in ("node_modules", ".git", "__pycache__", ".venv", "venv", "dist", "build")]
        for fname in files:
            if any(fname.endswith(ext) for ext in ext_list):
                fpath = os.path.join(root, fname)
                try:
                    with open(fpath, "r", errors="ignore") as f:
                        code = f.read()
                    files_scanned += 1

                    ext = os.path.splitext(fname)[1].lower()
                    ext_map = {".py": "python", ".js": "javascript", ".ts": "typescript",
                               ".tsx": "typescript", ".jsx": "javascript"}
                    lang = ext_map.get(ext, "unknown")

                    file_vulns = _scan_internal(code, lang)
                    for v in file_vulns:
                        v["file"] = os.path.relpath(fpath, dir_path)
                    all_vulns.extend(file_vulns)
                except Exception:
                    continue

    if files_scanned == 0:
        return f"No files with extensions {extensions} found in {dir_path}"

    return _format_dir_report(all_vulns, files_scanned, dir_path)


def audit_mcp_server(file_path: str) -> str:
    """Audit an MCP server for security best practices."""
    if not os.path.isfile(file_path):
        return f"Error: File not found: {file_path}"

    with open(file_path, "r", errors="ignore") as f:
        code = f.read()

    findings = []

    # 1. Input validation
    if "@mcp.tool()" in code:
        tool_funcs = re.findall(r'@mcp\.tool\(\)\s*\n\s*(?:async\s+)?def\s+(\w+)\(([^)]*)\)', code)
        for name, params in tool_funcs:
            # Check if function body has any validation
            func_match = re.search(rf'def\s+{name}\([^)]*\).*?(?=\ndef\s|\Z)', code, re.DOTALL)
            if func_match:
                body = func_match.group()
                has_validation = any(kw in body for kw in [
                    "if not ", "raise ValueError", "raise TypeError",
                    "validate", "assert ", "schema", "pydantic",
                    "if len(", "if isinstance("
                ])
                if not has_validation and "str" in params:
                    findings.append({
                        "severity": "HIGH", "category": "input-validation",
                        "message": f"Tool '{name}' accepts string input but has no validation"
                    })

    # 2. Error handling
    tool_count = code.count("@mcp.tool()")
    try_count = code.count("try:")
    if tool_count > 0 and try_count < tool_count:
        findings.append({
            "severity": "MEDIUM", "category": "error-handling",
            "message": f"{tool_count} tools but only {try_count} try/except blocks — errors may leak stack traces"
        })

    # 3. File system access
    fs_ops = re.findall(r'(?:open|os\.path|os\.remove|os\.rmdir|shutil\.|pathlib\.Path)\s*\(', code)
    if fs_ops:
        has_path_check = "os.path.abspath" in code or "resolve()" in code or ".." in code
        if not has_path_check:
            findings.append({
                "severity": "HIGH", "category": "path-traversal",
                "message": f"File system operations found ({len(fs_ops)}) but no path sanitization"
            })

    # 4. Network requests
    net_ops = re.findall(r'(?:urllib|requests|httpx|aiohttp|fetch)\b', code)
    if net_ops:
        has_timeout = "timeout" in code
        if not has_timeout:
            findings.append({
                "severity": "MEDIUM", "category": "timeout",
                "message": "Network requests without timeout — could hang indefinitely"
            })

    # 5. Shell execution
    shell_ops = re.findall(r'(?:os\.system|subprocess\.|os\.popen)\s*\(', code)
    if shell_ops:
        findings.append({
            "severity": "CRITICAL", "category": "command-injection",
            "message": f"Shell execution found ({len(shell_ops)} calls) — ensure inputs are sanitized"
        })

    # 6. Sensitive data in responses
    if re.search(r'traceback|\.format_exc|exc_info', code):
        findings.append({
            "severity": "MEDIUM", "category": "info-disclosure",
            "message": "Stack traces may be returned to client — sanitize error responses"
        })

    # 7. Rate limiting
    has_rate_limit = any(kw in code for kw in ["rate_limit", "throttle", "semaphore", "Semaphore"])
    if tool_count > 3 and not has_rate_limit:
        findings.append({
            "severity": "LOW", "category": "rate-limiting",
            "message": f"{tool_count} tools exposed with no rate limiting"
        })

    # 8. Auth check
    has_auth = any(kw in code for kw in ["auth", "token", "api_key", "authenticate", "authorize"])
    if not has_auth:
        findings.append({
            "severity": "LOW", "category": "authentication",
            "message": "No authentication mechanism detected — MCP server is open to any client"
        })

    return _format_mcp_audit(findings, file_path, tool_count)


def _scan_internal(code: str, language: str) -> List[Dict]:
    """Internal scan that returns raw vulns list."""
    vulns = []
    lines = code.split("\n")
    _check_injection(code, language, lines, vulns)
    _check_crypto(code, language, lines, vulns)
    _check_ssrf(code, language, lines, vulns)
    _check_path_traversal(code, language, lines, vulns)
    _check_deserialization(code, language, lines, vulns)
    _check_misconfig(code, language, lines, vulns)
    _check_email_injection(code, language, lines, vulns)
    _check_template_injection(code, language, lines, vulns)
    _check_header_injection(code, language, lines, vulns)
    _check_ldap_injection(code, language, lines, vulns)

    # Quick secret scan
    secret_patterns = [
        (r'sk-[a-zA-Z0-9]{20,}', "OpenAI key"),
        (r'ghp_[a-zA-Z0-9]{36}', "GitHub token"),
        (r'AKIA[0-9A-Z]{16}', "AWS key"),
    ]
    for pattern, label in secret_patterns:
        if re.search(pattern, code):
            vulns.append({"severity": "CRITICAL", "category": "hardcoded-secret",
                          "message": f"Hardcoded {label} found"})

    return vulns


def _check_injection(code: str, language: str, lines: List[str], vulns: List[Dict]):
    """Check for injection vulnerabilities."""
    # SQL injection
    sql_patterns = [
        (r'f["\'].*(?:SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER)\s.*\{', "f-string SQL"),
        (r'["\'].*(?:SELECT|INSERT|UPDATE|DELETE).*["\']\s*%\s', "%-format SQL"),
        (r'["\'].*(?:SELECT|INSERT|UPDATE|DELETE).*["\']\s*\+\s', "concatenated SQL"),
        (r'\.execute\(\s*f["\']', "execute with f-string"),
        (r'\.execute\(\s*["\'].*%s.*["\']\s*%', "execute with % formatting"),
    ]
    for pattern, label in sql_patterns:
        for i, line in enumerate(lines, 1):
            if re.search(pattern, line, re.IGNORECASE):
                vulns.append({"severity": "CRITICAL", "category": "sql-injection",
                              "message": f"Line {i}: {label} — use parameterized queries",
                              "line": i})

    # Command injection
    cmd_patterns = [
        (r'os\.system\(\s*f["\']', "os.system with f-string"),
        (r'os\.system\(\s*[^"\']+\+', "os.system with concatenation"),
        (r'subprocess\.\w+\(\s*f["\']', "subprocess with f-string"),
        (r'subprocess\.\w+\([^)]*shell\s*=\s*True', "subprocess with shell=True"),
        (r'exec\(\s*(?:f["\']|[^"\']+\+)', "exec with dynamic input"),
        (r'eval\(\s*(?:f["\']|[^"\']+\+)', "eval with dynamic input"),
    ]
    for pattern, label in cmd_patterns:
        for i, line in enumerate(lines, 1):
            if re.search(pattern, line):
                vulns.append({"severity": "CRITICAL", "category": "command-injection",
                              "message": f"Line {i}: {label}", "line": i})

    # XSS (JS/TS)
    if language in ("javascript", "typescript"):
        xss_patterns = [
            (r'innerHTML\s*=', "innerHTML assignment"),
            (r'document\.write\(', "document.write"),
            (r'dangerouslySetInnerHTML', "React dangerouslySetInnerHTML"),
            (r'\.html\(\s*[^"\'<]', "jQuery .html() with variable"),
        ]
        for pattern, label in xss_patterns:
            for i, line in enumerate(lines, 1):
                if re.search(pattern, line):
                    vulns.append({"severity": "HIGH", "category": "xss",
                                  "message": f"Line {i}: {label} — sanitize input",
                                  "line": i})

    # ── Email / Header Injection (CWE-93) ── FBI LEEP-class vulns
    _check_email_injection(code, language, lines, vulns)

    # ── Template Injection (SSTI, CWE-1336) ──
    _check_template_injection(code, language, lines, vulns)

    # ── HTTP Header Injection (CWE-113) ──
    _check_header_injection(code, language, lines, vulns)

    # ── LDAP Injection (CWE-90) ──
    _check_ldap_injection(code, language, lines, vulns)


def _check_email_injection(code: str, language: str, lines: List[str], vulns: List[Dict]):
    """Check for email/SMTP header injection (CWE-93). The FBI LEEP portal hack class."""
    # Python: user input flowing into email construction
    email_sink_patterns = [
        # Django send_mail / EmailMessage with dynamic subject/body/recipient
        (r'send_mail\(\s*(?:request\.|form\.|data\[|params\[|input)', "CRITICAL",
         "send_mail() with user input — validate and sanitize subject/body/recipients"),
        (r'EmailMessage\(\s*subject\s*=\s*(?:request\.|form\.|data\[)', "CRITICAL",
         "EmailMessage subject from user input — sanitize to prevent header injection"),
        (r'EmailMessage\(\s*(?:[^)]*,\s*){2,}to\s*=\s*(?:request\.|form\.|data\[)', "CRITICAL",
         "EmailMessage recipients from user input — validate email addresses"),
        # smtplib: user input in sendmail/send_message
        (r'\.sendmail\(\s*(?:request\.|form\.|data\[|params\[|user)', "CRITICAL",
         "SMTP sendmail() with user input — validate all parameters"),
        (r'\.send_message\(\s*(?:request\.|form\.|data\[)', "CRITICAL",
         "SMTP send_message() with user input — validate message object"),
        # Direct header manipulation with user input
        (r'msg\[[\'"]\w+[\'"]\]\s*=\s*(?:request\.|form\.|data\[|params\[|input\()', "CRITICAL",
         "Email header set from user input — strip newlines (\\r\\n) to prevent injection"),
        (r'["\'](?:Subject|To|From|Cc|Bcc|Reply-To)["\']\s*[:=]\s*(?:request\.|form\.|data\[)', "CRITICAL",
         "Email header field from user input — FBI LEEP-class vulnerability"),
        # Flask-Mail / generic patterns
        (r'Message\(\s*subject\s*=\s*(?:request\.|form\.|data\[)', "HIGH",
         "Mail subject from user input — sanitize to prevent header injection"),
        # Newlines in email fields (the actual injection mechanism)
        (r'(?:subject|to_addr|from_addr)\s*=.*\\r|\\n', "HIGH",
         "Email field contains literal newline — potential header injection payload"),
    ]
    for pattern, severity, message in email_sink_patterns:
        for i, line in enumerate(lines, 1):
            if re.search(pattern, line, re.IGNORECASE):
                vulns.append({"severity": severity, "category": "email-injection",
                              "message": f"Line {i}: {message}", "line": i})

    # Node.js / JS email patterns
    if language in ("javascript", "typescript"):
        js_email_patterns = [
            (r'sendMail\(\s*\{[^}]*subject\s*:\s*(?:req\.|params\.|body\.)', "CRITICAL",
             "nodemailer subject from user input — sanitize to prevent header injection"),
            (r'sendMail\(\s*\{[^}]*to\s*:\s*(?:req\.|params\.|body\.)', "CRITICAL",
             "nodemailer recipient from user input — validate email format"),
            (r'transporter\.sendMail\(\s*\{[^}]*(?:from|to|subject)\s*:\s*(?:req\.|ctx\.)', "CRITICAL",
             "nodemailer fields from request — validate and sanitize all fields"),
        ]
        for pattern, severity, message in js_email_patterns:
            if re.search(pattern, code, re.DOTALL):
                vulns.append({"severity": severity, "category": "email-injection",
                              "message": message})


def _check_template_injection(code: str, language: str, lines: List[str], vulns: List[Dict]):
    """Check for Server-Side Template Injection (SSTI, CWE-1336)."""
    # Python SSTI patterns
    ssti_patterns = [
        # Jinja2 / Flask
        (r'render_template_string\(\s*(?:request\.|form\.|data\[|user)', "CRITICAL",
         "render_template_string() with user input — SSTI allows RCE"),
        (r'Template\(\s*(?:request\.|form\.|data\[|user|input)', "CRITICAL",
         "Template() constructed from user input — SSTI allows RCE"),
        (r'from_string\(\s*(?:request\.|form\.|data\[)', "CRITICAL",
         "Jinja2 from_string() with user input — SSTI allows RCE"),
        (r'Environment\(\)\.from_string\(', "HIGH",
         "Jinja2 Environment.from_string() — ensure input is not user-controlled"),
        # Mako
        (r'mako\.template\.Template\(\s*(?:request\.|form\.|data\[)', "CRITICAL",
         "Mako template from user input — SSTI allows RCE"),
        # String format as template (weaker but still dangerous)
        (r'\.format\(\s*\*\*(?:request\.|form\.|data)', "HIGH",
         ".format() with user-controlled kwargs — potential format string attack"),
    ]
    for pattern, severity, message in ssti_patterns:
        for i, line in enumerate(lines, 1):
            if re.search(pattern, line, re.IGNORECASE):
                vulns.append({"severity": severity, "category": "template-injection",
                              "message": f"Line {i}: {message}", "line": i})

    # JS/TS SSTI patterns
    if language in ("javascript", "typescript"):
        js_ssti = [
            (r'new\s+Function\(\s*(?:req\.|params\.|body\.)', "CRITICAL",
             "new Function() with user input — equivalent to eval()"),
            (r'ejs\.render\(\s*(?:req\.|params\.|body\.)', "CRITICAL",
             "EJS render with user input — SSTI allows RCE"),
            (r'pug\.render\(\s*(?:req\.|params\.|body\.)', "CRITICAL",
             "Pug render with user input — SSTI allows RCE"),
            (r'handlebars\.compile\(\s*(?:req\.|params\.|body\.)', "HIGH",
             "Handlebars compile with user input — potential SSTI"),
            (r'nunjucks\.renderString\(\s*(?:req\.|params\.|body\.)', "CRITICAL",
             "Nunjucks renderString with user input — SSTI allows RCE"),
        ]
        for pattern, severity, message in js_ssti:
            for i, line in enumerate(lines, 1):
                if re.search(pattern, line):
                    vulns.append({"severity": severity, "category": "template-injection",
                                  "message": f"Line {i}: {message}", "line": i})


def _check_header_injection(code: str, language: str, lines: List[str], vulns: List[Dict]):
    """Check for HTTP response header injection (CWE-113)."""
    header_patterns = [
        # Python: setting response headers from user input
        (r'response\.headers\[\s*[^]]+\]\s*=\s*(?:request\.|form\.|data\[|params\[)', "HIGH",
         "HTTP response header set from user input — strip \\r\\n to prevent injection"),
        (r'response\[[\'"]\w+[\'"]\]\s*=\s*(?:request\.|form\.|data\[)', "HIGH",
         "Response header from user input — validate and strip newlines"),
        (r'set_cookie\(\s*[^,]+,\s*(?:value\s*=\s*)?(?:request\.|form\.|data\[)', "HIGH",
         "Cookie value from user input — sanitize to prevent header injection"),
        # Redirect with user-controlled URL (open redirect + header injection)
        (r'redirect\(\s*(?:request\.|form\.|data\[|params\[|url)', "HIGH",
         "Redirect URL from user input — validate against allowlist (open redirect)"),
        (r'Location["\']?\s*[:=]\s*(?:request\.|form\.|data\[)', "HIGH",
         "Location header from user input — open redirect + header injection risk"),
        # Flask/Django specific
        (r'make_response\([^)]*\).*\.headers\[', "MEDIUM",
         "Manual header manipulation — ensure values are sanitized"),
        (r'HttpResponse\(\s*[^)]*headers\s*=\s*\{[^}]*(?:request\.|form\.)', "HIGH",
         "Django HttpResponse headers from user input — sanitize values"),
    ]
    for pattern, severity, message in header_patterns:
        for i, line in enumerate(lines, 1):
            if re.search(pattern, line, re.IGNORECASE):
                vulns.append({"severity": severity, "category": "header-injection",
                              "message": f"Line {i}: {message}", "line": i})

    # JS/TS header injection
    if language in ("javascript", "typescript"):
        js_header = [
            (r'res\.set(?:Header)?\(\s*[^,]+,\s*(?:req\.|params\.|body\.)', "HIGH",
             "Response header from user input — sanitize to prevent CRLF injection"),
            (r'res\.redirect\(\s*(?:req\.|params\.|body\.)', "HIGH",
             "Redirect from user input — validate URL against allowlist"),
            (r'res\.cookie\(\s*[^,]+,\s*(?:req\.|params\.|body\.)', "HIGH",
             "Cookie from user input — sanitize value"),
        ]
        for pattern, severity, message in js_header:
            for i, line in enumerate(lines, 1):
                if re.search(pattern, line):
                    vulns.append({"severity": severity, "category": "header-injection",
                                  "message": f"Line {i}: {message}", "line": i})


def _check_ldap_injection(code: str, language: str, lines: List[str], vulns: List[Dict]):
    """Check for LDAP injection (CWE-90)."""
    ldap_patterns = [
        (r'\.search\w*\([^)]*f["\'].*\{', "CRITICAL",
         "LDAP search with f-string filter — use ldap.filter.escape_filter_chars()"),
        (r'\.search\w*\([^)]*["\'].*%s.*["\']\s*%', "CRITICAL",
         "LDAP search with %-format filter — use parameterized filters"),
        (r'\.search\w*\([^)]*["\'].*["\']\s*\+', "CRITICAL",
         "LDAP search with concatenated filter — use parameterized filters"),
        (r'search_filter\s*=\s*f["\'].*\(.*\{', "HIGH",
         "LDAP filter built with f-string — escape user input"),
        (r'filterstr\s*=\s*(?:f["\']|[^"\']+\+|.*%s)', "HIGH",
         "LDAP filterstr from dynamic input — use escape_filter_chars()"),
    ]
    for pattern, severity, message in ldap_patterns:
        for i, line in enumerate(lines, 1):
            if re.search(pattern, line, re.IGNORECASE):
                vulns.append({"severity": severity, "category": "ldap-injection",
                              "message": f"Line {i}: {message}", "line": i})



def _check_crypto(code: str, language: str, lines: List[str], vulns: List[Dict]):
    """Check for cryptographic failures."""
    weak_crypto = [
        (r'\bmd5\b', "MD5 — use SHA-256+"),
        (r'\bsha1\b', "SHA-1 — use SHA-256+"),
        (r'\bDES\b', "DES — use AES"),
        (r'\bRC4\b', "RC4 — use AES-GCM"),
        (r'ECB\b', "ECB mode — use CBC or GCM"),
    ]
    for pattern, label in weak_crypto:
        if re.search(pattern, code, re.IGNORECASE):
            vulns.append({"severity": "HIGH", "category": "weak-crypto",
                          "message": f"Weak cryptography: {label}"})

    # Hardcoded crypto keys
    if re.search(r'(?:AES|DES|Fernet)\s*\(\s*b?["\'][^"\']+["\']', code):
        vulns.append({"severity": "CRITICAL", "category": "hardcoded-key",
                      "message": "Cryptographic key hardcoded in source"})


def _check_access_control(code: str, language: str, lines: List[str], vulns: List[Dict]):
    """Check for broken access control."""
    # CORS wildcards
    if re.search(r'(?:Access-Control-Allow-Origin|cors).*\*', code, re.IGNORECASE):
        vulns.append({"severity": "HIGH", "category": "cors-wildcard",
                      "message": "CORS allows all origins (*) — restrict to specific domains"})

    # Debug mode in production
    if re.search(r'DEBUG\s*=\s*True', code):
        vulns.append({"severity": "HIGH", "category": "debug-mode",
                      "message": "DEBUG=True — disable in production"})


def _check_misconfig(code: str, language: str, lines: List[str], vulns: List[Dict]):
    """Check for security misconfigurations."""
    # SSL verification disabled
    if re.search(r'verify\s*=\s*False', code):
        vulns.append({"severity": "HIGH", "category": "ssl-disabled",
                      "message": "SSL verification disabled — vulnerable to MITM"})

    # Binding to 0.0.0.0
    if re.search(r'(?:host|bind)\s*=\s*["\']0\.0\.0\.0', code):
        vulns.append({"severity": "MEDIUM", "category": "bind-all",
                      "message": "Binding to 0.0.0.0 — consider restricting to localhost"})


def _check_auth(code: str, language: str, lines: List[str], vulns: List[Dict]):
    """Check for authentication failures."""
    # JWT without verification
    if "jwt" in code.lower():
        if re.search(r'verify\s*=\s*False|algorithms\s*=\s*\[.*none', code, re.IGNORECASE):
            vulns.append({"severity": "CRITICAL", "category": "jwt-bypass",
                          "message": "JWT verification disabled or 'none' algorithm allowed"})

    # Timing-safe comparison missing
    if re.search(r'(?:token|password|secret)\s*==\s*', code):
        vulns.append({"severity": "MEDIUM", "category": "timing-attack",
                      "message": "String comparison for secrets — use hmac.compare_digest()"})


def _check_logging(code: str, language: str, lines: List[str], vulns: List[Dict]):
    """Check for logging failures."""
    if re.search(r'logging.*(?:password|token|secret|key|credential)', code, re.IGNORECASE):
        vulns.append({"severity": "HIGH", "category": "sensitive-logging",
                      "message": "Sensitive data may be logged — mask before logging"})


def _check_ssrf(code: str, language: str, lines: List[str], vulns: List[Dict]):
    """Check for SSRF vulnerabilities."""
    # URL from user input used in requests
    url_patterns = [
        r'requests\.\w+\(\s*(?:url|f["\']|[^"\']+\+)',
        r'urllib\.request\.urlopen\(\s*(?:url|f["\'])',
        r'httpx\.\w+\(\s*(?:url|f["\'])',
        r'fetch\(\s*(?:url|`)',
    ]
    for pattern in url_patterns:
        if re.search(pattern, code):
            vulns.append({"severity": "HIGH", "category": "ssrf",
                          "message": "URL may come from user input — validate against allowlist"})
            break


def _check_path_traversal(code: str, language: str, lines: List[str], vulns: List[Dict]):
    """Check for path traversal vulnerabilities."""
    if re.search(r'open\(\s*(?:f["\']|[^"\']+\+|os\.path\.join\([^)]*(?:request|param|input))', code):
        vulns.append({"severity": "HIGH", "category": "path-traversal",
                      "message": "File path may include user input — use os.path.abspath and validate"})


def _check_deserialization(code: str, language: str, lines: List[str], vulns: List[Dict]):
    """Check for insecure deserialization."""
    if re.search(r'pickle\.loads?\(|yaml\.load\(\s*[^)]*(?!Loader)', code):
        vulns.append({"severity": "CRITICAL", "category": "deserialization",
                      "message": "Insecure deserialization — use json or yaml.safe_load()"})


def _format_security_report(vulns: List[Dict], total_lines: int) -> str:
    """Format security scan results."""
    if not vulns:
        return f"Security Scan: PASS\n{total_lines} lines scanned, no vulnerabilities found.\nGrade: A"

    severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    vulns.sort(key=lambda x: severity_order.get(x["severity"], 99))
    counts = Counter(v["severity"] for v in vulns)

    grade = "F" if counts.get("CRITICAL", 0) > 0 else "D" if counts.get("HIGH", 0) > 1 else "C" if counts.get("HIGH", 0) > 0 else "B" if counts.get("MEDIUM", 0) > 2 else "A"

    report = [
        f"Security Scan Report",
        f"{'='*50}",
        f"Lines scanned: {total_lines}",
        f"Vulnerabilities: {len(vulns)}",
        f"  CRITICAL: {counts.get('CRITICAL', 0)}",
        f"  HIGH: {counts.get('HIGH', 0)}",
        f"  MEDIUM: {counts.get('MEDIUM', 0)}",
        f"  LOW: {counts.get('LOW', 0)}",
        f"",
        f"Security Grade: {grade}",
        f"{'='*50}",
        "",
    ]

    for v in vulns:
        line_info = f" (line {v['line']})" if "line" in v else ""
        report.append(f"[{v['severity']}] {v['category']}{line_info}")
        report.append(f"  {v['message']}")
        report.append("")

    return "\n".join(report)


def _format_dir_report(vulns: List[Dict], files_scanned: int, dir_path: str) -> str:
    """Format directory scan results."""
    if not vulns:
        return f"Directory Scan: PASS\n{files_scanned} files scanned in {dir_path}, no vulnerabilities found.\nGrade: A"

    severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    vulns.sort(key=lambda x: severity_order.get(x["severity"], 99))
    counts = Counter(v["severity"] for v in vulns)

    grade = "F" if counts.get("CRITICAL", 0) > 0 else "D" if counts.get("HIGH", 0) > 1 else "C"

    report = [
        f"Directory Security Scan: {dir_path}",
        f"{'='*50}",
        f"Files scanned: {files_scanned}",
        f"Vulnerabilities: {len(vulns)}",
        f"  CRITICAL: {counts.get('CRITICAL', 0)}",
        f"  HIGH: {counts.get('HIGH', 0)}",
        f"  MEDIUM: {counts.get('MEDIUM', 0)}",
        f"  LOW: {counts.get('LOW', 0)}",
        f"",
        f"Security Grade: {grade}",
        f"{'='*50}",
        "",
    ]

    for v in vulns:
        file_info = f" [{v.get('file', '?')}]" if "file" in v else ""
        report.append(f"[{v['severity']}] {v['category']}{file_info}")
        report.append(f"  {v['message']}")
        report.append("")

    return "\n".join(report)


def _format_mcp_audit(findings: List[Dict], file_path: str, tool_count: int) -> str:
    """Format MCP audit results."""
    if not findings:
        return f"MCP Server Audit: PASS\nFile: {file_path}\nTools: {tool_count}\nNo security issues found.\nGrade: A"

    severity_order = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    findings.sort(key=lambda x: severity_order.get(x["severity"], 99))
    counts = Counter(f["severity"] for f in findings)

    grade = "F" if counts.get("CRITICAL", 0) > 0 else "D" if counts.get("HIGH", 0) > 1 else "C" if counts.get("HIGH", 0) > 0 else "B"

    report = [
        f"MCP Server Security Audit",
        f"{'='*50}",
        f"File: {file_path}",
        f"Tools exposed: {tool_count}",
        f"Findings: {len(findings)}",
        f"  CRITICAL: {counts.get('CRITICAL', 0)}",
        f"  HIGH: {counts.get('HIGH', 0)}",
        f"  MEDIUM: {counts.get('MEDIUM', 0)}",
        f"  LOW: {counts.get('LOW', 0)}",
        f"",
        f"Security Grade: {grade}",
        f"{'='*50}",
        "",
    ]

    for f in findings:
        report.append(f"[{f['severity']}] {f['category']}")
        report.append(f"  {f['message']}")
        report.append("")

    report.append("Recommendations:")
    if any(f["category"] == "input-validation" for f in findings):
        report.append("  - Add input validation to all tool parameters")
    if any(f["category"] == "command-injection" for f in findings):
        report.append("  - Replace shell execution with subprocess.run(args_list)")
    if any(f["category"] == "path-traversal" for f in findings):
        report.append("  - Sanitize file paths with os.path.abspath() + allowlist")
    if any(f["category"] == "rate-limiting" for f in findings):
        report.append("  - Add asyncio.Semaphore for rate limiting")
    if any(f["category"] == "email-injection" for f in findings):
        report.append("  - Strip \\r\\n from all email fields, validate recipients against allowlist")
    if any(f["category"] == "template-injection" for f in findings):
        report.append("  - Never pass user input to template constructors — use render_template() with named files")
    if any(f["category"] == "header-injection" for f in findings):
        report.append("  - Strip \\r\\n from header values, validate redirect URLs against allowlist")
    if any(f["category"] == "ldap-injection" for f in findings):
        report.append("  - Use ldap.filter.escape_filter_chars() on all user input in LDAP queries")

    return "\n".join(report)
