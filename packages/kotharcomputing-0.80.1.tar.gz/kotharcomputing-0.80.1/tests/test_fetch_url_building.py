from __future__ import annotations

from pathlib import Path
import sys
from urllib import parse as urllib_parse

import pytest

SRC_DIR = Path(__file__).resolve().parents[1] / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from kotharcomputing.fetch import ApiTransport


def test_build_url_encodes_path_params_and_bool_query_values() -> None:
    transport = ApiTransport("https://api.example.com", access_token=None, timeout=30.0)

    url = transport.build_url(
        "v1/workspaces/:workspaceId/files/:filePath",
        path_params={"workspaceId": "personal", "filePath": "folder/hello world.txt"},
        search_params={"withUsernames": True, "limit": 25},
    )

    assert (
        url
        == "https://api.example.com/v1/workspaces/personal/files/folder%2Fhello%20world.txt?withUsernames=true&limit=25"
    )


def test_build_url_expands_list_query_params_and_skips_none_values() -> None:
    transport = ApiTransport("https://api.example.com", access_token=None, timeout=30.0)

    url = transport.build_url(
        "v1/users/me/credits/transactions",
        search_params={
            "references": ["job-1", "job-2"],
            "active": False,
            "next": None,
        },
    )

    query_pairs = urllib_parse.parse_qsl(
        urllib_parse.urlsplit(url).query, keep_blank_values=True
    )
    assert query_pairs == [
        ("references", "job-1"),
        ("references", "job-2"),
        ("active", "false"),
    ]


def test_build_url_preserves_existing_query_and_appends_new_params() -> None:
    transport = ApiTransport("https://api.example.com", access_token=None, timeout=30.0)

    url = transport.build_url(
        "v1/jobs?next=cursor-1",
        search_params={"withAgents": True},
    )

    assert (
        url == "https://api.example.com/v1/jobs?next=cursor-1&withAgents=true"
    )


def test_build_url_rejects_absolute_url_outside_base_url() -> None:
    transport = ApiTransport("https://api.example.com", access_token=None, timeout=30.0)

    with pytest.raises(ValueError, match="does not start with the base URL"):
        transport.build_url(
            "https://malicious.example.com/v1/jobs",
            absolute_url=True,
        )
