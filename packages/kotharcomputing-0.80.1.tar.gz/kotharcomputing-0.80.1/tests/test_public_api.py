from __future__ import annotations

import importlib
from pathlib import Path
import sys


SRC_DIR = Path(__file__).resolve().parents[1] / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))


def test_package_import_and_public_exports() -> None:
    module = importlib.import_module("kotharcomputing")

    expected_exports = {
        "KOTHAR_ERROR_TYPE_BASE_URL",
        "KotharApiError",
        "KotharClient",
        "KotharClientOptions",
        "RawResponse",
        "ExecuteResult",
    }

    assert set(module.__all__) == expected_exports
    for name in expected_exports:
        assert hasattr(module, name)


def test_kothar_client_uses_default_base_url() -> None:
    module = importlib.import_module("kotharcomputing")

    client = module.KotharClient()

    assert client._transport.base_url == "https://api.kotharcomputing.com/"
