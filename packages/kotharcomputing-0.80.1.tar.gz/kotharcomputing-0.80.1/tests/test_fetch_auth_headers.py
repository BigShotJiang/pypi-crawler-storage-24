from __future__ import annotations

from pathlib import Path
import sys
from typing import Any


SRC_DIR = Path(__file__).resolve().parents[1] / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

from kotharcomputing.fetch import ApiTransport


class _DummyResponse:
    headers = {}

    def __enter__(self) -> "_DummyResponse":
        return self

    def __exit__(self, *_args: Any) -> bool:
        return False

    def read(self) -> bytes:
        return b"{}"

    def getcode(self) -> int:
        return 200


class _DummyOpener:
    def __init__(self) -> None:
        self.last_request: Any | None = None

    def open(self, request: Any, timeout: float | None = None) -> _DummyResponse:
        self.last_request = request
        return _DummyResponse()


def _authorization_header(access_token: str | None) -> str | None:
    transport = ApiTransport(
        "https://api.kotharcomputing.com", access_token=access_token, timeout=30.0
    )
    opener = _DummyOpener()
    transport._opener = opener

    transport.raw("get", "v1/workspaces/:workspaceId/jobs", path_params={"workspaceId": "personal"})
    return opener.last_request.headers.get("Authorization")


def test_raw_adds_bearer_prefix_to_plain_access_token() -> None:
    assert _authorization_header("abc.def.ghi") == "Bearer abc.def.ghi"


def test_raw_does_not_double_prefix_bearer_access_token() -> None:
    assert _authorization_header("Bearer abc.def.ghi") == "Bearer abc.def.ghi"
