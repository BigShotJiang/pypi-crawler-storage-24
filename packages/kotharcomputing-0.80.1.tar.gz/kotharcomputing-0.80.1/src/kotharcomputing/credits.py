from __future__ import annotations

from datetime import date, datetime
from typing import NotRequired, TypedDict, cast

from .common import JSONValue
from .fetch import ApiTransport, to_optional_iso


class CreditBalance(TypedDict):
    ownerId: str
    balance: float
    timestamp: str


class CreditTransaction(TypedDict):
    id: str
    ownerId: str
    amount: float
    description: NotRequired[str]
    reference: NotRequired[str]
    timestamp: NotRequired[str]
    metadata: NotRequired[JSONValue]


class CreditTransactionsPage(TypedDict):
    items: list[CreditTransaction]
    next: NotRequired[str]


class CreditsClient:
    def __init__(self, transport: ApiTransport, user_id: str) -> None:
        self._transport = transport
        self._user_id = user_id

    def get_balance(self) -> CreditBalance:
        return cast(
            CreditBalance,
            self._transport.get_json(
                "v1/users/:userId/credits/balance",
                path_params={"userId": self._user_id},
            ),
        )

    def list_transactions(
        self,
        *,
        next: str | None = None,
        references: list[str] | None = None,
        start: date | datetime | str | None = None,
        end: date | datetime | str | None = None,
        limit: int | None = None,
    ) -> CreditTransactionsPage:
        return cast(
            CreditTransactionsPage,
            self._transport.get_json(
                "v1/users/:userId/credits/transactions",
                path_params={"userId": self._user_id},
                search_params={
                    "next": next,
                    "references": references,
                    "start": to_optional_iso(start),
                    "end": to_optional_iso(end),
                    "limit": limit,
                },
            ),
        )

    def checkout(
        self, *, success_url: str | None = None, cancel_url: str | None = None
    ) -> str:
        payload = cast(
            dict[str, str],
            self._transport.post_json(
                "v1/users/:userId/credits/$checkout",
                path_params={"userId": self._user_id},
                json_data={"successUrl": success_url, "cancelUrl": cancel_url},
            ),
        )
        return payload["url"]
