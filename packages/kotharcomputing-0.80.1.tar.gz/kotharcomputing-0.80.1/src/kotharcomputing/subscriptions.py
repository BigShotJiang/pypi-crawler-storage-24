from __future__ import annotations

from typing import TYPE_CHECKING, Literal, NotRequired, TypeAlias, TypedDict, cast

from .fetch import ApiTransport

if TYPE_CHECKING:
    from .users import UserKind, UserSubscription


SubscriptionStatus: TypeAlias = Literal[
    "active",
    "canceled",
    "incomplete",
    "incomplete_expired",
    "past_due",
    "paused",
    "trialing",
    "unpaid",
]
SubscriptionInterval: TypeAlias = Literal["month", "year"]


class Subscription(TypedDict):
    id: str
    status: SubscriptionStatus
    amount: float
    currency: str
    credits: float
    interval: SubscriptionInterval
    userKind: "UserKind"
    userSubscription: "UserSubscription"


class SubscriptionOption(TypedDict):
    id: str
    name: str
    amount: float
    currency: str
    credits: float
    interval: SubscriptionInterval
    userKind: "UserKind"
    userSubscription: "UserSubscription"
    description: NotRequired[str]
    maxNumberOfPersonalAgents: NotRequired[int]


class SubscriptionsClient:
    def __init__(self, transport: ApiTransport, user_id: str) -> None:
        self._transport = transport
        self._user_id = user_id

    def get_subscriptions(self) -> list[Subscription]:
        return cast(
            list[Subscription],
            self._transport.get_json(
                "v1/users/:userId/subscriptions",
                path_params={"userId": self._user_id},
            ),
        )

    def get_subscription_options(self) -> list[SubscriptionOption]:
        return cast(
            list[SubscriptionOption],
            self._transport.get_json(
                "v1/users/:userId/subscriptions/options",
                path_params={"userId": self._user_id},
            ),
        )

    def create_subscription_checkout(
        self, *, option_id: str, success_url: str, cancel_url: str | None = None
    ) -> str:
        payload = cast(
            dict[str, str],
            self._transport.post_json(
                "v1/users/:userId/subscriptions/options/:optionId/$checkout",
                path_params={"userId": self._user_id, "optionId": option_id},
                json_data={
                    "successUrl": success_url,
                    "cancelUrl": cancel_url,
                },
            ),
        )
        return payload["url"]
