from __future__ import annotations

from typing import Literal, NotRequired, TypeAlias, TypedDict

from .jobs import JobStatus


class KotharApiWorkspaceJobUpdatedEvent(TypedDict):
    type: Literal["job:updated"]
    workspaceId: str
    jobId: str
    userId: str
    status: JobStatus


class KotharApiWorkspaceFileCreatedEvent(TypedDict):
    type: Literal["file:created"]
    workspaceId: str
    path: str
    isFolder: NotRequired[bool]


class KotharApiWorkspaceFileUpdatedEvent(TypedDict):
    type: Literal["file:updated"]
    workspaceId: str
    path: str


class KotharApiWorkspaceFileDeletedEvent(TypedDict):
    type: Literal["file:deleted"]
    workspaceId: str
    path: str


class KotharApiWorkspaceFileMovedEvent(TypedDict):
    type: Literal["file:moved"]
    workspaceId: str
    sourcePath: str
    targetPath: str


KotharApiWorkspaceEvent: TypeAlias = (
    KotharApiWorkspaceJobUpdatedEvent
    | KotharApiWorkspaceFileCreatedEvent
    | KotharApiWorkspaceFileUpdatedEvent
    | KotharApiWorkspaceFileDeletedEvent
    | KotharApiWorkspaceFileMovedEvent
)


__all__ = [
    "KotharApiWorkspaceEvent",
    "KotharApiWorkspaceFileCreatedEvent",
    "KotharApiWorkspaceFileDeletedEvent",
    "KotharApiWorkspaceFileMovedEvent",
    "KotharApiWorkspaceFileUpdatedEvent",
    "KotharApiWorkspaceJobUpdatedEvent",
]
