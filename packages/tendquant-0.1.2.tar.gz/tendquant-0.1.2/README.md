# tendQuant

一个用于tendQuant的MQTT客户端库，支持MQTTv5和WebSocket协议。

## 功能特性

- **MQTTv5支持**：默认使用MQTTv5协议
- **WebSocket支持**：支持通过WebSocket协议连接
- **自动重连**：断开连接后自动尝试重连
- **简单API**：简洁的订阅/取消订阅接口
- **错误处理**：详细的错误信息和处理机制

## 安装方法

```bash
pip install tendquant
```

## 使用示例

### 基本用法

```python
from tendquant import Client

# 创建客户端实例
client = Client(
    username="test",
    password="test",
)

# 连接到broker
client.connect()

# 订阅主题
client.subscribe("lv1/tradeList/600089")
client.subscribe("lv1/tradeList/600111")

# 取消订阅
client.unsubscribe("lv1/tradeList/600089")

# 断开连接
client.disconnect()
```

### 自定义消息处理器

```python
from tendquant import Client
import json

def custom_on_message(client, userdata, msg):
    topic = msg.topic
    payload = msg.payload.decode('utf-8')
    data = json.loads(payload)
    print(f"收到消息: {topic} -> {data}")

# 创建客户端
client = Client(
    username="test",
    password="test",
)

# 设置自定义消息处理器
client.client.on_message = custom_on_message

# 连接
client.connect()
```

## API参考

### Client

#### __init__(username=None, password=None, keepalive=60, use_ws=False, ws_path="/mqtt")

创建一个新的MQTT客户端实例。

- `username`: 认证用户名
- `password`: 认证密码
- `keepalive`: 心跳间隔（秒）
- `use_ws`: 是否使用WebSocket协议
- `ws_path`: WebSocket路径

#### connect()

连接到MQTT broker。

#### subscribe(topic, qos=1)

订阅主题。

- `topic`: 要订阅的主题
- `qos`: 服务质量等级（0, 1, 2）

#### unsubscribe(topic)

取消订阅主题。

- `topic`: 要取消订阅的主题

#### disconnect()

断开与MQTT broker的连接。

## 许可证

MIT License

## 贡献

欢迎贡献代码！请提交Pull Request。