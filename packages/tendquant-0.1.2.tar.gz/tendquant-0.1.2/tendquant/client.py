import paho.mqtt.client as mqtt
import random
import string
import time

class Client:
    def __init__(self, username=None, password=None, keepalive=60, use_ws=True, ws_path="/mqtt"):
        self.broker    = "203.195.240.220"
        self.port      = 8083
        self.username  = username
        self.password  = password
        self.keepalive = keepalive
        self.use_ws    = use_ws
        self.ws_path   = ws_path
        self.client    = None
        self.connected = False
        
        # 生成随机CLIENT_ID
        self.client_id = self._generate_client_id()
        
        # 初始化客户端
        self._init_client()
        
    def _generate_client_id(self):
        # 生成随机字符串作为CLIENT_ID
        return 'client-' + ''.join(random.choices(string.ascii_letters + string.digits, k=10))
    
    def _init_client(self):
        # 使用MqttV5版本和VERSION2回调API
        self.client = mqtt.Client(
            callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
            transport="websockets" if self.use_ws else "tcp",
            client_id=self.client_id,
            protocol=mqtt.MQTTv5
        )
        
        # 设置用户名和密码
        if self.username and self.password:
            self.client.username_pw_set(self.username, self.password)
        
        # 如果使用WebSocket协议
        if self.use_ws:
            self.client.ws_set_options(path=self.ws_path)
        
        # 设置回调函数
        self.client.on_connect = self._on_connect
        self.client.on_disconnect = self._on_disconnect
        self.client.on_message = self._on_message
        
    def _on_connect(self, client, userdata, flags, rc, properties=None):
        if rc == 0:
            print(f">>> 成功连接到行情服务器")
            self.connected = True
            
            # 重新订阅之前的主题
            if hasattr(self, 'subscribed_topics'):
                for topic, qos in self.subscribed_topics:
                    client.subscribe(topic, qos)
                    print(f">>> 已订阅主题: {topic}")
        else:
            print(f"!!! 连接失败，错误码: {rc}")
    
    def _on_disconnect(self, client, *args, **kwargs):
        """断开连接回调"""
        # args 通常包含 (userdata, rc, properties)
        # 我们尝试获取 rc，它是第二个参数 (索引为1)
        rc = 0
        if len(args) >= 2:
            rc = args[1]
        
        if rc != 0:
            print(f"### 意外断开连接，错误码: {rc}")
        else:
            print("### 连接已正常关闭")
            
        self.connected = False
        # 尝试重连
        self._reconnect()
    
    def _on_message(self, client, userdata, msg):
        # 默认消息处理，可以在子类中重写
        print(f"Received message on topic {msg.topic}: {msg.payload.decode()}")
    
    def _reconnect(self):
        while not self.connected:
            try:
                print(f"### 已断线，尝试重连中")
                self.client.reconnect()
                self.connected = True
            except Exception as e:
                print(f"Reconnection failed: {e}")
                time.sleep(5)
    
    def connect(self, on_message=None):
        try:
            # 设置消息回调
            if on_message:
                self.client.on_message = on_message
            
            # 配置 MQTT 5 连接属性
            connect_props = mqtt.Properties(mqtt.PacketTypes.CONNECT)
            connect_props.SessionExpiryInterval = 0
            
            # print(f"正在连接到 {self.broker}:{self.port} (Path: {self.ws_path if self.use_ws else 'TCP'}) ...")
            self.client.connect(self.broker, self.port, self.keepalive, properties=connect_props)
            self.client.loop_start()

            time.sleep(2)
            
            return None
        except Exception as e:
            print(f"发生错误: {e}")
            self._reconnect()
            return None
    
    def subscribe(self, topic, qos=1):
        if self.connected:
            try:
                result, mid = self.client.subscribe(topic, qos)
                if result == mqtt.MQTT_ERR_SUCCESS:
                    # 保存订阅的主题以便重连后重新订阅
                    if not hasattr(self, 'subscribed_topics'):
                        self.subscribed_topics = set()
                    self.subscribed_topics.add((topic, qos))
                    print(f">>> 已订阅主题: {topic}")
                else:
                    error_messages = {
                        mqtt.MQTT_ERR_NO_CONN: "未连接到MQTT broker",
                        mqtt.MQTT_ERR_QUEUE_SIZE: "队列已满",
                        mqtt.MQTT_ERR_INVAL: "无效参数",
                        mqtt.MQTT_ERR_NOMEM: "内存不足",
                        mqtt.MQTT_ERR_PROTOCOL: "协议错误",
                        mqtt.MQTT_ERR_NOT_SUPPORTED: "不支持的操作",
                        mqtt.MQTT_ERR_TLS: "TLS错误",
                        mqtt.MQTT_ERR_PAYLOAD_SIZE: "负载大小超出限制",
                        mqtt.MQTT_ERR_NOT_AUTHORIZED: "未授权访问",
                        mqtt.MQTT_ERR_UNKNOWN: "未知错误"
                    }
                    error_msg = error_messages.get(result, f"错误码: {result}")
                    print(f"!!! 订阅失败: {error_msg}")
            except Exception as e:
                print(f"!!! 订阅时出错: {e}")
        else:
            print("!!! 未连接到MQTT broker")
    
    def unsubscribe(self, topic):
        if self.connected:
            try:
                result, mid = self.client.unsubscribe(topic)
                if result == mqtt.MQTT_ERR_SUCCESS:
                    # 从保存的主题中移除
                    if hasattr(self, 'subscribed_topics'):
                        # 移除所有匹配该主题的订阅
                        self.subscribed_topics = {(t, q) for t, q in self.subscribed_topics if t != topic}
                    print(f">>> 已取消订阅主题: {topic}")
                else:
                    print(f"!!! 取消订阅失败，错误码: {result}")
            except Exception as e:
                print(f"!!! 取消订阅时出错: {e}")
        else:
            print("!!! 未连接到MQTT broker")
    
    def disconnect(self):
        self.client.loop_stop()
        self.client.disconnect()
        self.connected = False
        print("### 已断开与行情服务器的连接")