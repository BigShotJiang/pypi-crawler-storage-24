#!/usr/bin/env python3
"""
tendQuant CLI tool
"""
import argparse
from . import Client

def main():
    parser = argparse.ArgumentParser(description="tendQuant MQTT Client CLI")
    parser.add_argument("--username", help="MQTT username")
    parser.add_argument("--password", help="MQTT password")
    parser.add_argument("--use-ws", action="store_true", help="Use WebSocket protocol")
    parser.add_argument("--ws-path", default="/mqtt", help="WebSocket path")
    parser.add_argument("--subscribe", help="Topic to subscribe")
    parser.add_argument("--topic", help="Topic for publishing")
    
    args = parser.parse_args()
    
    # Create client
    client = Client(
        username=args.username,
        password=args.password,
        use_ws=args.use_ws,
        ws_path=args.ws_path
    )
    
    # Connect
    client.connect()
    
    # Subscribe
    if args.subscribe:
        client.subscribe(args.subscribe)
        print(f"Subscribed to {args.subscribe}")
    
    # Keep running
    try:
        while True:
            pass
    except KeyboardInterrupt:
        client.disconnect()
        print("\nDisconnected")

if __name__ == "__main__":
    main()