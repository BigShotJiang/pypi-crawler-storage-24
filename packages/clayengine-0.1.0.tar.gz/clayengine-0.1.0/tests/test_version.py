import unittest

import clayengine


class ClayEnginePublicApiTests(unittest.TestCase):
    def test_version_api(self) -> None:
        self.assertEqual(clayengine.__version__, "0.1.0")
        self.assertEqual(clayengine.version(), "0.1.0")


if __name__ == "__main__":
    unittest.main()
