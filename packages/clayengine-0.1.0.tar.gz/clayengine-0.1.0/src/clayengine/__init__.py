__all__ = ["__version__", "version"]

__version__ = "0.1.0"


def version() -> str:
    return __version__
