# clayengine

`clayengine` is the future Python SDK for Clay Engine runtime and editor automation.

Version `0.1.0` is a name-claim scaffold. It intentionally ships only package metadata and a tiny version API while Clay Engine's public local automation protocol is still being defined.

## Install

```bash
pip install clayengine
```

## Usage

```python
import clayengine

print(clayengine.version())
```

## Status

The runtime/editor automation client API will land after the public protocol, session model, and transport are versioned and shipped.

## Local Development

```bash
uv build
uv run python -m unittest discover -s tests -v
uv publish --dry-run
```
