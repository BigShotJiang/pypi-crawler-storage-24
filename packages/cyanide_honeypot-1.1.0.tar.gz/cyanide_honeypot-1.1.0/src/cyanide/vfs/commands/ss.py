import asyncio

from .base import Command


class SsCommand(Command):
    # Function 265: Executes the 'ss' command logic within the virtual filesystem.
    async def execute(self, args, input_data=""):
        await asyncio.sleep(0)
        connections = self.get_random_connections()
        output = (
            "Netid  State      Recv-Q Send-Q Local Address:Port               Peer Address:Port\n"
        )
        for conn in connections:
            output += f"{conn['proto']:<5}  {conn['state']:<10} 0      128    {conn['local']:<30} {conn['remote']:<30}\n"
        return output, "", 0
