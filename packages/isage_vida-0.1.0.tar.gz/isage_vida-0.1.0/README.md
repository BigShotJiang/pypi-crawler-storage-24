# sage-vida

**Vida Agent** — 24/7 持久化自主 Agent，SAGE 生态 L4 应用层包。

## 概述

Vida (Virtually Intelligent Daemon Agent) 是 SAGE 生态中负责 7×24 小时持续运行的自主
Agent 框架。整合三层记忆（工作/情节/语义）、周期性自我反思与多源触发管理。

## 层次关系

```
sage.vida (L4)
  └── sage.middleware (L3)  — VidaMemoryBridge 通过 sage.middleware.components.sage_mem
  └── isage-neuromem (L3)   — 三层记忆服务（可选，动态加载）
  └── sage.common (L1)
```

## 核心组件

| 组件 | 说明 |
|------|------|
| `VidaAgent` | 24/7 守护进程，统一编排事件循环、记忆联动与反思 |
| `VidaMemoryBridge` | 三层记忆接入（工作/情节/语义） |
| `VidaReflectionEngine` | 周期性自我反思与语义记忆整合 |
| `TriggerManager` | 多源触发器管理（定时/Webhook/文件/自定义） |

## 快速开始

```bash
pip install isage-vida
# 含记忆后端（需要 isage-neuromem）
pip install "isage-vida[neuromem]"
```

```python
from sage.vida import VidaAgent, VidaMemoryBridge, VidaReflectionEngine

bridge = VidaMemoryBridge(config={"data_dir": "/tmp/vida"})
agent = VidaAgent(react_loop=my_loop, memory_bridge=bridge)

await agent.start()
result = await agent.ask("user1", "今天天气如何？")
print(result.answer)
await agent.shutdown()
```

## 开发环境

```bash
./quickstart.sh        # 安装 hooks + pip install -e .[dev]
./quickstart.sh --doctor
```

## 测试

```bash
pytest tests/ -v
```

> 注意：`VidaMemoryBridge` 相关测试需要 `isage-neuromem` 已安装，否则自动跳过。

## 许可证

Apache-2.0
