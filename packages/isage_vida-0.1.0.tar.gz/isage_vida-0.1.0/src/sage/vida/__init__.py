"""sage.vida — Vida Agent 24/7 持久化自主 Agent 包

Vida (Virtually Intelligent Daemon Agent) 是 SAGE 生态中负责 7×24
小时持续运行的自主 Agent 框架，整合三层记忆、周期反思与多源触发。

核心组件：

- ``VidaAgent``:           24/7 守护进程 Agent，统一编排事件循环、记忆联动与反思。
- ``VidaMemoryBridge``:    三层记忆接入 operator（工作/情节/语义记忆）。
- ``VidaReflectionEngine``:周期性自我反思与记忆整合 operator。
- ``TriggerManager``:      多源触发器管理器（定时/Webhook/文件/自定义）。
- ``VidaMessage``:         Agent 队列消息数据类。
- ``VidaResult``:          Agent 处理结果数据类。
- ``VidaEvent``:           触发器统一事件格式。
- ``LLMProtocol``:         最小 LLM 调用协议（Protocol）。

依赖层次：
    sage.vida (L4) → sage.middleware (L3) → sage.common (L1)
    sage.vida (L4) → isage-neuromem (L3, 可选)

典型用法::

    from sage.vida import (
        VidaAgent,
        VidaMemoryBridge,
        VidaReflectionEngine,
        TriggerManager,
    )

    bridge = VidaMemoryBridge(config={"data_dir": "/tmp/vida"})
    agent = VidaAgent(react_loop=my_loop, memory_bridge=bridge)
    await agent.start()
    result = await agent.ask("user1", "今天天气如何？")
    await agent.shutdown()
"""

from __future__ import annotations

from sage.vida._version import __version__
from sage.vida.vida_agent import VidaAgent, VidaMessage, VidaResult
from sage.vida.vida_memory_bridge import VidaMemoryBridge
from sage.vida.vida_reflection_engine import LLMProtocol, VidaReflectionEngine
from sage.vida.vida_trigger_manager import TriggerManager, VidaEvent

__all__ = [
    "__version__",
    "LLMProtocol",
    "TriggerManager",
    "VidaAgent",
    "VidaEvent",
    "VidaMemoryBridge",
    "VidaMessage",
    "VidaReflectionEngine",
    "VidaResult",
]
