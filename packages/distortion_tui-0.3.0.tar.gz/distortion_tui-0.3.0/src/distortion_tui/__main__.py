"""Entry point for `uv run -m distortion_tui`."""

from distortion_tui.tui import main

main()
