"""Utility functions."""

from itertools import pairwise

import librosa
import numpy as np


def get_cycles(waveform: np.ndarray) -> tuple[list[np.ndarray], np.ndarray]:
    """
    Get waveform cycles by zero crossings.

    Args:
        waveform (np.ndarray): Waveform to analyze.

    Returns:
        tuple[list[np.ndarray], np.ndarray]: A tuple containing a list of waveform
            cycles and an array of crossing indices.

    """
    zero_crossings = librosa.zero_crossings(waveform)
    crossing_indices = np.where(zero_crossings)[0]
    cycles = [waveform[start:end] for start, end in pairwise(crossing_indices)]
    return cycles, crossing_indices
