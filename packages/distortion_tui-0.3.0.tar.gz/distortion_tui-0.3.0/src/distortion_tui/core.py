"""Script containing the main class of the package."""

import sys as _sys
from abc import ABC, abstractmethod
from typing import ClassVar

import numpy as np
from scipy.signal import resample

from distortion_tui.utils import get_cycles


class DistortionFunction(ABC):
    """Abstract base class for audio distortion functions."""

    display_name: ClassVar[str]
    name: ClassVar[str]
    suffix: ClassVar[str]

    @abstractmethod
    def __call__(self, waveform: np.ndarray) -> np.ndarray:
        """
        Apply the distortion to a waveform.

        Args:
            waveform (np.ndarray): Input waveform.

        Returns:
            np.ndarray: Distorted waveform.

        """


class IsochronousTimeWarping(DistortionFunction):
    """Make waveform isochronous by resampling each cycle to average cycle length."""

    display_name = "Isochronous Time Warping"
    name = "isochronous_time_warping"
    suffix = "_isochronous"

    def __call__(self, waveform: np.ndarray) -> np.ndarray:
        """
        Make waveform isochronous.

        Args:
            waveform (np.ndarray): Input waveform.

        Returns:
            np.ndarray: Isochronous waveform.

        """
        cycles, _ = get_cycles(waveform)
        avg_cycle_length = int(np.mean([len(cycle) for cycle in cycles]))
        out = []
        for cycle in cycles:
            warped_cycle = resample(cycle, avg_cycle_length)
            out.append(warped_cycle)
        return np.concatenate(out)


class InfinitePeakClipping(DistortionFunction):
    """Replace every sample with +1 or -1 based on its sign."""

    display_name = "Infinite Peak Clipping"
    name = "infinite_peak_clipping"
    suffix = "_clipping"

    def __call__(self, waveform: np.ndarray) -> np.ndarray:
        """
        Make waveform infinite peak clipping.

        Args:
            waveform (np.ndarray): Input waveform.

        Returns:
            np.ndarray: Infinite peak clipping waveform.

        """
        return np.where(waveform >= 0, 1.0, -1.0).astype(np.float32)


for _cls in DistortionFunction.__subclasses__():
    setattr(_sys.modules[__name__], _cls.name, _cls())

__all__ = [cls.name for cls in DistortionFunction.__subclasses__()]
del _sys
