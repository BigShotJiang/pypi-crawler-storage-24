from pathlib import Path

import pytest
from pymultirole_plugins.v1.schema import Document, DocumentList
from starlette.datastructures import Headers, UploadFile

from pyconverters_whisperx.whisperx import (
    WhisperXConverter,
    WhisperXParameters,
)


def test_whisperx():
    model = WhisperXConverter.get_model()
    assert model is WhisperXParameters


@pytest.mark.skip(reason="Not a test")
def test_whisperx_yaml():
    model = WhisperXConverter.get_model()
    assert model is WhisperXParameters
    converter = WhisperXConverter()
    parameters = WhisperXParameters()
    testdir = Path(__file__).parent
    source = Path(testdir, "data/mindspeak.yaml")
    with source.open("rb") as fin:
        docs: list[Document] = converter.convert(
            UploadFile(file=fin, filename=source.name, headers=Headers({"content-type": "application/x-yaml"})),
            parameters,
        )
        assert len(docs) == 1
        json_file = source.with_suffix(".json")
        dl = DocumentList(root=docs)
        with json_file.open("w") as fout:
            print(dl.model_dump_json(exclude_none=True, exclude_unset=True, indent=2), file=fout)
