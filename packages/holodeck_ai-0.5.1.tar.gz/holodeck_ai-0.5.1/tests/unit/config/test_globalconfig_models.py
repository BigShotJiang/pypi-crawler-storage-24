"""Tests for GlobalConfig model in holodeck.models.config."""

import pytest
from pydantic import ValidationError

from holodeck.models.config import GlobalConfig, VectorstoreConfig
from holodeck.models.deployment import DeploymentConfig
from holodeck.models.llm import LLMProvider, ProviderEnum


def _make_deployment_config(**kwargs) -> DeploymentConfig:
    """Create a minimal valid DeploymentConfig for testing."""
    defaults = {
        "registry": {"url": "ghcr.io", "repository": "org/agent"},
        "target": {"provider": "aws", "aws": {"region": "us-east-1"}},
    }
    defaults.update(kwargs)
    return DeploymentConfig(**defaults)


class TestVectorstoreConfig:
    """Tests for VectorstoreConfig model."""

    def test_vectorstore_config_valid(self) -> None:
        """Test creating a valid VectorstoreConfig."""
        config = VectorstoreConfig(
            provider="postgres",
            connection_string="postgresql://localhost/holodeck",
        )
        assert config.provider == "postgres"
        assert config.connection_string == "postgresql://localhost/holodeck"

    def test_vectorstore_config_with_options(self) -> None:
        """Test VectorstoreConfig with options."""
        config = VectorstoreConfig(
            provider="postgres",
            connection_string="postgresql://localhost/db",
            options={"pool_size": 10, "timeout": 30},
        )
        assert config.options == {"pool_size": 10, "timeout": 30}

    def test_vectorstore_config_options_default_none(self) -> None:
        """Test that options default to None when omitted."""
        config = VectorstoreConfig(
            provider="redis",
            connection_string="redis://localhost",
        )
        assert config.options is None or isinstance(config.options, dict)

    @pytest.mark.parametrize(
        "kwargs",
        [
            pytest.param(
                {"connection_string": "connection"},
                id="missing_provider",
            ),
            pytest.param(
                {"provider": "postgres"},
                id="missing_connection_string",
            ),
        ],
    )
    def test_vectorstore_config_required_fields(self, kwargs: dict) -> None:
        """Test that required fields raise ValidationError when missing."""
        with pytest.raises(ValidationError):
            VectorstoreConfig(**kwargs)


class TestDeploymentConfig:
    """Tests for DeploymentConfig model.

    Note: Comprehensive tests for the DeploymentConfig model are in
    tests/unit/deploy/test_models.py. These tests verify basic integration
    with GlobalConfig.
    """

    def test_deployment_config_valid(self) -> None:
        """Test creating a valid DeploymentConfig."""
        config = _make_deployment_config()
        assert config.registry.url == "ghcr.io"
        assert config.registry.repository == "org/agent"
        assert config.target.provider.value == "aws"

    @pytest.mark.parametrize(
        "kwargs",
        [
            pytest.param(
                {"target": {"provider": "aws", "aws": {"region": "us-east-1"}}},
                id="missing_registry",
            ),
            pytest.param(
                {"registry": {"url": "ghcr.io", "repository": "org/agent"}},
                id="missing_target",
            ),
        ],
    )
    def test_deployment_config_required_fields(self, kwargs: dict) -> None:
        """Test that required fields raise ValidationError when missing."""
        with pytest.raises(ValidationError):
            DeploymentConfig(**kwargs)

    def test_deployment_config_with_environment(self) -> None:
        """Test DeploymentConfig with environment variables."""
        config = _make_deployment_config(
            environment={"DEBUG": "true", "LOG_LEVEL": "info"}
        )
        assert config.environment == {"DEBUG": "true", "LOG_LEVEL": "info"}


class TestGlobalConfig:
    """Tests for GlobalConfig model."""

    def test_global_config_empty_creation(self) -> None:
        """Test creating an empty GlobalConfig (all optional)."""
        config = GlobalConfig()
        assert config.providers is None or isinstance(config.providers, dict)
        assert config.vectorstores is None or isinstance(config.vectorstores, dict)
        assert config.deployment is None

    def test_global_config_with_providers(self) -> None:
        """Test GlobalConfig with providers."""
        provider = LLMProvider(
            provider=ProviderEnum.OPENAI,
            name="gpt-4o",
        )
        config = GlobalConfig(providers={"default": provider})
        assert "default" in config.providers
        assert config.providers["default"].provider == ProviderEnum.OPENAI

    def test_global_config_with_vectorstores(self) -> None:
        """Test GlobalConfig with vectorstores."""
        vectorstore = VectorstoreConfig(
            provider="postgres",
            connection_string="postgresql://localhost/holodeck",
        )
        config = GlobalConfig(vectorstores={"knowledge_base": vectorstore})
        assert "knowledge_base" in config.vectorstores
        assert config.vectorstores["knowledge_base"].provider == "postgres"

    def test_global_config_with_deployment(self) -> None:
        """Test GlobalConfig with deployment config."""
        deployment = _make_deployment_config()
        config = GlobalConfig(deployment=deployment)
        assert config.deployment is not None
        assert config.deployment.registry.url == "ghcr.io"

    def test_global_config_all_fields(self) -> None:
        """Test GlobalConfig with all fields."""
        provider = LLMProvider(
            provider=ProviderEnum.ANTHROPIC,
            name="claude-3-opus",
        )
        vectorstore = VectorstoreConfig(
            provider="redis",
            connection_string="redis://localhost",
        )
        deployment = _make_deployment_config(
            port=3000,
            environment={"NAMESPACE": "holodeck"},
        )

        config = GlobalConfig(
            providers={"anthropic": provider},
            vectorstores={"cache": vectorstore},
            deployment=deployment,
        )

        assert len(config.providers) == 1
        assert len(config.vectorstores) == 1
        assert config.deployment.port == 3000

    def test_global_config_multiple_providers(self) -> None:
        """Test GlobalConfig with multiple providers."""
        provider1 = LLMProvider(
            provider=ProviderEnum.OPENAI,
            name="gpt-4o",
        )
        provider2 = LLMProvider(
            provider=ProviderEnum.ANTHROPIC,
            name="claude-3-opus",
        )
        config = GlobalConfig(
            providers={
                "openai": provider1,
                "anthropic": provider2,
            }
        )
        assert len(config.providers) == 2
        assert config.providers["openai"].provider == ProviderEnum.OPENAI
        assert config.providers["anthropic"].provider == ProviderEnum.ANTHROPIC

    def test_global_config_multiple_vectorstores(self) -> None:
        """Test GlobalConfig with multiple vectorstores."""
        vs1 = VectorstoreConfig(
            provider="postgres",
            connection_string="postgresql://localhost/db1",
        )
        vs2 = VectorstoreConfig(
            provider="redis",
            connection_string="redis://localhost",
        )
        config = GlobalConfig(
            vectorstores={
                "postgres_db": vs1,
                "redis_cache": vs2,
            }
        )
        assert len(config.vectorstores) == 2
        assert config.vectorstores["postgres_db"].provider == "postgres"
        assert config.vectorstores["redis_cache"].provider == "redis"
