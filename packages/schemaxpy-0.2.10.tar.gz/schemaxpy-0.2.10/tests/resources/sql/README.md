## SQL Fixtures

### `unity_import_fixture.sql`

Unity Catalog fixture DDL/DML used to seed realistic provider metadata for import testing.

It creates:

- 2 catalogs
- multiple schemas
- tables with PK/FK constraints
- table/view comments and properties
- table and column tags
- dependent views

Use this when validating `schemax import` behavior end-to-end.

### `unity_command_fixture.sql`

Unity Catalog fixture used by live command-matrix tests.

It creates:

- catalog + schemas
- tables with PK/FK constraints
- table properties
- table and column tags
- a dependent view with tags

Use this when validating multi-command live workflows (`import`, `sql`, `validate`, `diff`, `apply --dry-run`, `rollback --dry-run`, snapshots).

### `unity_uc_objects_fixture.sql`

Unity Catalog fixture for schema-level objects (volume, function, materialized view, view, partitioned table).

It creates:

- catalog + schema
- base table (`base_fact`) with varied column types (BIGINT, STRING, DATE, DECIMAL, VARIANT) and PK
- second table (`events_partitioned`) with PARTITIONED BY (dt) (Databricks does not allow both PARTITIONED BY and CLUSTER BY on the same table)
- permanent view (`base_fact_view`) over base_fact
- managed volume
- SQL function (returns INT)
- Python UDF (live_e2e_py_udf)
- materialized view (depends on base table)
- materialized view with REFRESH EVERY 1 DAY

Use this for live E2E tests that verify import discovers volumes/functions/MVs/views and that validate/sql work. Tokens: `test_uc_objects` → catalog name, `__MANAGED_ROOT__` → managed location path. Optional: `__EXTERNAL_LOCATION__` for external volume (commented out by default).

### Optional live integration tests

There are opt-in pytest integration tests that apply these fixture SQL files and run live commands against Databricks.

Required environment variables:

- `SCHEMAX_RUN_LIVE_COMMAND_TESTS=1`
- `DATABRICKS_PROFILE`
- `DATABRICKS_WAREHOUSE_ID`
- `DATABRICKS_MANAGED_LOCATION` (example: `abfss://test@mneudlsdevashish001.dfs.core.windows.net/`)

Run:

```bash
cd packages/python-sdk
uv run pytest tests/integration/test_live_command_matrix.py -v
uv run pytest tests/integration/test_import_live_databricks.py -v
```

Live tests create uniquely-suffixed catalogs per run, append a random subdirectory under `DATABRICKS_MANAGED_LOCATION`, and clean up fixture catalogs in teardown.
