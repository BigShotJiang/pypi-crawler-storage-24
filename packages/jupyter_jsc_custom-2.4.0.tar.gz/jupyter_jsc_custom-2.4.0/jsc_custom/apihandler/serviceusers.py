import asyncio
import re

from forwardbasespawner.utils import check_custom_scopes
from jupyterhub.apihandlers import APIHandler
from jupyterhub.apihandlers import default_handlers
from jupyterhub.roles import assign_default_roles
from jupyterhub.roles import grant_role
from jupyterhub.utils import maybe_future
from tornado import web

from ..misc import get_custom_config
from .misc import generate_random_id


class ServiceUsersAPIHandler(APIHandler):
    required_scopes = ["custom:serviceusers"]

    @web.authenticated
    async def post(self, user_name, server_name=""):
        check_custom_scopes(self)
        service = self.current_user
        custom_config = get_custom_config()
        user_name = f"service:{service.name}:{user_name}"
        user = self.find_user(user_name)
        data = self.get_json_body()

        create_user_default = (
            custom_config.get("serviceaccounts", {})
            .get(service.name, {})
            .get(user_name, {})
            .get("create_user_default", None)
        )
        if create_user_default is None:
            create_user_default = (
                custom_config.get("serviceaccounts", {})
                .get(service.name, {})
                .get("default", {})
                .get("create_user_default", True)
            )
        if user is None and data.get("create_user", create_user_default):
            try:
                self.log.info(
                    f"Received request to create service user {user_name} from {service.name}",
                    extra={
                        "service": service.name,
                        "user_name": user_name,
                        "action": "service_user_create",
                    },
                )
                user = self.user_from_username(user_name)
                assign_default_roles(self.db, entity=user)
                groups = ["service-account", f"{service.name}-user"]
                for group in groups:
                    grant_role(self.db, user, group)
                groups.append(f"email:{user_name}")
                auth_state = await user.get_auth_state()
                if auth_state is None:
                    auth_state = {}
                auth_state["groups"] = groups
                await user.save_auth_state(auth_state)
                self.db.commit()
                await maybe_future(self.authenticator.add_user(user))
            except Exception:
                self.log.exception("Failed to create service user %s", user_name)
                try:
                    self.users.delete(user)
                except:
                    pass
                raise web.HTTPError(400, f"Failed to create service user {user_name}")
            self.log.info("Created service user %s with groups %s", user_name, groups)
        elif user is None and not data.get("create_user", True):
            raise web.HTTPError(
                400, f"User {user_name} does not exist and create_user is False"
            )
        else:
            self.log.info("Service user %s already exists", user_name)

        start_server_default = (
            custom_config.get("serviceaccounts", {})
            .get(service.name, {})
            .get(user_name, {})
            .get("start_server_default", None)
        )
        if start_server_default is None:
            start_server_default = (
                custom_config.get("serviceaccounts", {})
                .get(service.name, {})
                .get("default", {})
                .get("start_server_default", True)
            )
        if not data.get("start_server", start_server_default):
            self.set_status(204)
            return
        else:
            service_name_as_server_name = (
                custom_config.get("serviceaccounts", {})
                .get(service.name, {})
                .get(user_name, {})
                .get("service_name_as_server_name", None)
            )
            if service_name_as_server_name is None:
                service_name_as_server_name = (
                    custom_config.get("serviceaccounts", {})
                    .get(service.name, {})
                    .get("default", {})
                    .get("service_name_as_server_name", False)
                )
            if service_name_as_server_name:
                server_name = service.name
            elif not server_name:
                server_name = generate_random_id()
            log_name = f"service:{service.name}:{user_name}:{server_name}"

            # Start Server
            user_options = data.get("user_options", {})

            service_user_options = (
                custom_config.get("serviceaccounts", {})
                .get(service.name, {})
                .get(user_name, {})
                .get("user_options", {})
            )
            if not service_user_options:
                service_user_options = (
                    custom_config.get("serviceaccounts", {})
                    .get(service.name, {})
                    .get("default", {})
                    .get("user_options", {})
                )

            pattern = re.compile(r"\$(.*?)\$")

            def replace_placeholders(data, user_options):
                if isinstance(data, dict):
                    return {
                        k: replace_placeholders(v, user_options)
                        for k, v in data.items()
                    }

                if isinstance(data, list):
                    return [replace_placeholders(v, user_options) for v in data]

                if isinstance(data, str):
                    self.log.debug(
                        f"{log_name}: Replacing placeholders in {data} with user options {user_options}"
                    )
                    return pattern.sub(
                        lambda m: str(user_options.get(m.group(1), "")), data
                    )

                return data

            service_user_options = replace_placeholders(
                service_user_options, user_options
            )
            user_options.update(service_user_options)

            service_environment = (
                custom_config.get("serviceaccounts", {})
                .get(service.name, {})
                .get(user_name, {})
                .get("env", {})
            )
            if not service_environment:
                service_environment = (
                    custom_config.get("serviceaccounts", {})
                    .get(service.name, {})
                    .get("default", {})
                    .get("env", {})
                )

            self.log.info(
                f"{log_name}: Received request to start server",
                extra={
                    "service": service.name,
                    "user_name": user_name,
                    "action": "service_server_create",
                    "server_name": server_name,
                },
            )
            named_spawners = list(user.all_spawners(include_default=False))
            named_server_limit_per_user = (
                custom_config.get("serviceaccounts", {})
                .get(service.name, {})
                .get(user_name, {})
                .get("named_server_limit_per_user", None)
            )
            if not named_server_limit_per_user:
                named_server_limit_per_user = (
                    custom_config.get("serviceaccounts", {})
                    .get(service.name, {})
                    .get("default", {})
                    .get("named_server_limit_per_user", 5)
                )

            if named_server_limit_per_user <= len(named_spawners):
                raise web.HTTPError(
                    400,
                    f"User {user_name} already has the maximum of {named_server_limit_per_user} named servers."
                    "  One must be deleted before a new server can be created",
                )
            spawner = user.get_spawner(server_name, replace_failed=True)
            pending = spawner.pending
            if pending == "spawn":
                self.log.info(f"{spawner._log_name} is already spawning")
                self.write(
                    {
                        "progress_url": f"https://{self.request.host}{progress_url}",
                        "server_url": f"https://{self.request.host}{user.server_url(server_name)}?token={spawner.api_token}",
                        "token": spawner.api_token,
                    }
                )
                self.set_header("Content-Type", "text/plain")
                self.set_status(202)
                return
            elif pending:
                self.log.info(f"{spawner._log_name} is pending {pending}")
                raise web.HTTPError(400, f"{spawner._log_name} is pending {pending}")

            if spawner.ready:
                # include notify, so that a server that died is noticed immediately
                # set _spawn_pending flag to prevent races while we wait
                spawner._spawn_pending = True
                try:
                    state = await spawner.poll_and_notify()
                finally:
                    spawner._spawn_pending = False
                if state is None:
                    self.log.info(f"{spawner._log_name} is already running")
                    server_url = f"https://{self.request.host}{user.server_url(server_name)}?token={spawner.api_token}"
                    self.set_header("Location", server_url)
                    self.write({"server_url": server_url, "token": spawner.api_token})
                    return

            if service_environment:
                spawner.env.update(service_environment)
            await self.spawn_single_user(user, server_name, options=user_options)
            server_url = f"https://{self.request.host}{user.server_url(server_name)}?token={spawner.api_token}"
            progress_url = user.progress_url(server_name)
            self.write(
                {
                    "progress_url": f"https://{self.request.host}{progress_url}",
                    "server_url": server_url,
                    "token": spawner.api_token,
                }
            )
            self.set_header("Content-Type", "application/json")
            self.set_header("Location", progress_url)
            status = 202 if spawner.pending == "spawn" else 201
            self.set_status(status)

    @web.authenticated
    async def delete(self, user_name, server_name=""):
        check_custom_scopes(self)
        service = self.current_user
        user_name = f"service:{service.name}:{user_name}"
        user = self.find_user(user_name)
        if user is None:
            raise web.HTTPError(404, f"User {user_name} not found")

        custom_config = get_custom_config()
        service_name_as_server_name = (
            custom_config.get("serviceaccounts", {})
            .get(service.name, {})
            .get(user_name, {})
            .get("service_name_as_server_name", None)
        )
        if service_name_as_server_name is None:
            service_name_as_server_name = (
                custom_config.get("serviceaccounts", {})
                .get(service.name, {})
                .get("default", {})
                .get("service_name_as_server_name", False)
            )
        if service_name_as_server_name:
            server_name = service.name

        if server_name:
            spawner = user.spawners[server_name]
            if spawner.pending == "stop":
                self.log.info(f"{spawner._log_name} is already stopping")
                self.set_header("Content-Type", "text/plain")
                self.set_status(202)
                return

            if spawner.pending:
                spawner_future = spawner._spawn_future
                if spawner_future:
                    spawner_future.cancel()
                await asyncio.sleep(1)
                await self.stop_single_user(user, server_name)

            elif spawner.ready:
                status = await spawner.poll_and_notify()
                if status is None:
                    await self.stop_single_user(user, server_name)

            status = 202 if spawner._stop_pending else 204
            self.set_header("Content-Type", "text/plain")
            self.set_status(status)

        if (
            self.request.query_arguments.get("delete_user", [b"false"])[0].lower()
            == b"true"
        ):
            if user.spawner._stop_pending:
                raise web.HTTPError(
                    400,
                    f"{user_name}'s server is in the process of stopping, please wait.",
                )
            if user.running:
                await self.stop_single_user(user)
                if user.spawner._stop_pending:
                    raise web.HTTPError(
                        400,
                        f"{user_name}'s server is in the process of stopping, please wait.",
                    )

            self.log.info(
                f"Deleting service user {user_name} and all associated servers",
                extra={
                    "service": service.name,
                    "user_name": user_name,
                    "action": "service_user_delete",
                },
            )
            await maybe_future(self.authenticator.delete_user(user))

            await user.delete_spawners()
            # remove from registry
            self.users.delete(user)
            self.set_status(204)


default_handlers.append((r"/api/serviceuser/([^/]+)", ServiceUsersAPIHandler))
