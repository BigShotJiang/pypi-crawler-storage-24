"""Backtesting app entrypoints."""
