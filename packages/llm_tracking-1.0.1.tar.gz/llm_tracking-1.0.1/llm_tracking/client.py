import os
import httpx
from typing import Optional


class LLMRtrackingClient:
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: str = "http://localhost:8000/v1",
        timeout: float = 30.0,
    ):
        self.api_key = api_key or os.environ.get("LLM_TRACKING_API_KEY")
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

        if not self.api_key:
            raise ValueError("api_key must be provided or set via LLM_TRACKING_API_KEY")

    def _request(self, method: str, path: str, **kwargs):
        url = f"{self.base_url}{path}"
        headers = {"Authorization": f"Bearer {self.api_key}"}
        if "headers" in kwargs:
            headers.update(kwargs.pop("headers"))

        with httpx.Client(timeout=self.timeout) as client:
            response = client.request(method, url, headers=headers, **kwargs)
            response.raise_for_status()
            return response.json()

    def create_trace(self, trace_data: dict) -> dict:
        return self._request("POST", "/traces", json=trace_data)

    def get_trace(self, trace_id: str) -> dict:
        return self._request("GET", f"/traces/{trace_id}")

    def list_traces(
        self, page: int = 1, page_size: int = 50, session_id: Optional[str] = None
    ) -> dict:
        params = {"page": page, "page_size": page_size}
        if session_id:
            params["session_id"] = session_id
        return self._request("GET", "/traces", params=params)

    def create_run(self, run_data: dict) -> dict:
        return self._request("POST", "/runs", json=run_data)

    def update_run(self, run_id: str, run_data: dict) -> dict:
        return self._request("PATCH", f"/runs/{run_id}", json=run_data)

    def get_run(self, run_id: str) -> dict:
        return self._request("GET", f"/runs/{run_id}")

    def create_token_usage(self, token_data: dict) -> dict:
        return self._request("POST", "/runs/tokens", json=token_data)

    def create_feedback(self, feedback_data: dict) -> dict:
        return self._request("POST", "/feedback", json=feedback_data)

    def create_dataset(self, dataset_data: dict) -> dict:
        return self._request("POST", "/datasets", json=dataset_data)

    def get_dataset(self, dataset_id: str) -> dict:
        return self._request("GET", f"/datasets/{dataset_id}")

    def create_example(self, dataset_id: str, example_data: dict) -> dict:
        return self._request(
            "POST", f"/datasets/{dataset_id}/examples", json=example_data
        )


_client: Optional[LLMRtrackingClient] = None


def get_client() -> LLMRtrackingClient:
    global _client
    if _client is None:
        _client = LLMRtrackingClient()
    return _client


def set_client(client: LLMRtrackingClient):
    global _client
    _client = client
