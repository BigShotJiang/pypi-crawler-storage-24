import contextvars
from datetime import datetime
from typing import Optional, Any
from uuid import uuid4


_current_trace_id: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "current_trace_id", default=None
)
_current_run_id: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "current_run_id", default=None
)
_current_project: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar(
    "current_project", default=None
)


class TraceContext:
    def __init__(
        self,
        project: Optional[str] = None,
        trace_id: Optional[str] = None,
        session_id: Optional[str] = None,
        metadata: Optional[dict] = None,
        client=None,
    ):
        self.project = project
        self.trace_id = trace_id or _current_trace_id.get()
        self.session_id = session_id
        self.metadata = metadata or {}
        self.client = client

    def __enter__(self):
        if not self.trace_id:
            self.trace_id = str(uuid4())
        _current_trace_id.set(self.trace_id)
        if self.project:
            _current_project.set(self.project)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        _current_trace_id.set(None)
        _current_run_id.set(None)
        return False

    async def __aenter__(self):
        return self.__enter__()

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        return self.__exit__(exc_type, exc_val, exc_tb)

    def log_input(self, input_data: Any):
        self.metadata["input"] = input_data

    def log_output(self, output_data: Any):
        self.metadata["output"] = output_data


def get_current_trace_id() -> Optional[str]:
    return _current_trace_id.get()


def get_current_run_id() -> Optional[str]:
    return _current_run_id.get()


def get_current_project() -> Optional[str]:
    return _current_project.get()


def set_current_run_id(run_id: str):
    _current_run_id.set(run_id)
