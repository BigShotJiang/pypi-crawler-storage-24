import asyncio
import functools
import inspect
import os
from datetime import datetime, timezone
from typing import Any, Callable, Optional
from uuid import uuid4

from llm_tracking.client import get_client, LLMRtrackingClient
from llm_tracking.context import (
    get_current_trace_id,
    get_current_project,
    set_current_run_id,
    TraceContext,
)


def traceable(
    name: Optional[str] = None,
    run_type: str = "generic",
    project: Optional[str] = None,
):
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def sync_wrapper(*args, **kwargs):
            client = get_client()
            trace_name = name or func.__name__
            proj = (
                project
                or get_current_project()
                or os.environ.get("LLM_TRACKING_PROJECT", "default")
            )

            trace_id = get_current_trace_id()
            if not trace_id:
                trace_id = str(uuid4())
                trace = client.create_trace(
                    {
                        "name": trace_name,
                        "extra_metadata": {"function": func.__name__},
                    }
                )
                trace_id = trace["id"]

            start_time = datetime.now(timezone.utc)

            input_data = {"args": str(args), "kwargs": str(kwargs)}

            run_response = client.create_run(
                {
                    "trace_id": trace_id,
                    "name": trace_name,
                    "run_type": run_type,
                    "input": input_data,
                    "start_time": start_time.isoformat(),
                }
            )
            run_id = run_response["id"]

            try:
                result = func(*args, **kwargs)
                end_time = datetime.now(timezone.utc)

                client.update_run(
                    run_id,
                    {
                        "output": {"result": str(result)},
                        "end_time": end_time.isoformat(),
                    },
                )

                return result

            except Exception as e:
                end_time = datetime.now(timezone.utc)
                client.update_run(
                    run_id,
                    {
                        "error": str(e),
                        "end_time": end_time.isoformat(),
                    },
                )
                raise

        return sync_wrapper

    return decorator
