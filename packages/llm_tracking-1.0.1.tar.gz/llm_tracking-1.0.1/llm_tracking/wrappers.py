import os
from datetime import datetime
from typing import Any, Dict, Optional, Union
from uuid import uuid4

from llm_tracking.client import get_client
from llm_tracking.context import (
    get_current_trace_id,
    get_current_run_id,
    set_current_run_id,
)


def wrap_openai(client: Any, project: Optional[str] = None) -> Any:
    original_create = client.chat.completions.create
    original_create_async = getattr(client.chat.completions, "create", None)

    trace_id = get_current_trace_id()
    proj = project or os.environ.get("LLM_TRACKING_PROJECT", "default")

    async def traced_create(*args, **kwargs):
        tracking_client = get_client()

        trace_id = get_current_trace_id()
        if not trace_id:
            trace_id = str(uuid4())
            trace = await tracking_client.create_trace(
                {"name": kwargs.get("model", "openai-chat")}
            )
            trace_id = trace["id"]

        start_time = datetime.utcnow()
        run_id = str(uuid4())

        set_current_run_id(run_id)

        input_data = {
            "model": kwargs.get("model"),
            "messages": kwargs.get("messages", []),
            "temperature": kwargs.get("temperature"),
            "max_tokens": kwargs.get("max_tokens"),
        }

        await tracking_client.create_run(
            {
                "trace_id": trace_id,
                "name": f"OpenAI: {kwargs.get('model', 'unknown')}",
                "run_type": "llm",
                "input": input_data,
                "start_time": start_time.isoformat(),
            }
        )

        try:
            response = await original_create(*args, **kwargs)
            end_time = datetime.utcnow()

            output_data = {
                "content": response.choices[0].message.content
                if response.choices
                else None,
                "usage": (
                    {
                        "prompt_tokens": response.usage.prompt_tokens,
                        "completion_tokens": response.usage.completion_tokens,
                        "total_tokens": response.usage.total_tokens,
                    }
                    if response.usage
                    else None
                ),
            }

            await tracking_client.update_run(
                run_id,
                {
                    "output": output_data,
                    "end_time": end_time.isoformat(),
                },
            )

            if response.usage:
                await tracking_client.create_token_usage(
                    {
                        "run_id": run_id,
                        "prompt_tokens": response.usage.prompt_tokens,
                        "completion_tokens": response.usage.completion_tokens,
                        "total_tokens": response.usage.total_tokens,
                        "model": kwargs.get("model"),
                    }
                )

            return response

        except Exception as e:
            end_time = datetime.utcnow()
            await tracking_client.update_run(
                run_id,
                {
                    "error": str(e),
                    "end_time": end_time.isoformat(),
                },
            )
            raise

    def traced_create_sync(*args, **kwargs):
        import asyncio

        tracking_client = get_client()

        trace_id = get_current_trace_id()
        if not trace_id:
            trace_id = str(uuid4())
            trace = asyncio.run(
                tracking_client.create_trace(
                    {"name": kwargs.get("model", "openai-chat")}
                )
            )
            trace_id = trace["id"]

        start_time = datetime.utcnow()
        run_id = str(uuid4())

        input_data = {
            "model": kwargs.get("model"),
            "messages": kwargs.get("messages", []),
            "temperature": kwargs.get("temperature"),
            "max_tokens": kwargs.get("max_tokens"),
        }

        asyncio.run(
            tracking_client.create_run(
                {
                    "trace_id": trace_id,
                    "name": f"OpenAI: {kwargs.get('model', 'unknown')}",
                    "run_type": "llm",
                    "input": input_data,
                    "start_time": start_time.isoformat(),
                }
            )
        )

        try:
            response = original_create(*args, **kwargs)
            end_time = datetime.utcnow()

            output_data = {
                "content": response.choices[0].message.content
                if response.choices
                else None,
                "usage": (
                    {
                        "prompt_tokens": response.usage.prompt_tokens,
                        "completion_tokens": response.usage.completion_tokens,
                        "total_tokens": response.usage.total_tokens,
                    }
                    if response.usage
                    else None
                ),
            }

            asyncio.run(
                tracking_client.update_run(
                    run_id,
                    {
                        "output": output_data,
                        "end_time": end_time.isoformat(),
                    },
                )
            )

            if response.usage:
                asyncio.run(
                    tracking_client.create_token_usage(
                        {
                            "run_id": run_id,
                            "prompt_tokens": response.usage.prompt_tokens,
                            "completion_tokens": response.usage.completion_tokens,
                            "total_tokens": response.usage.total_tokens,
                            "model": kwargs.get("model"),
                        }
                    )
                )

            return response

        except Exception as e:
            end_time = datetime.utcnow()
            asyncio.run(
                tracking_client.update_run(
                    run_id,
                    {
                        "error": str(e),
                        "end_time": end_time.isoformat(),
                    },
                )
            )
            raise

    if asyncio.iscoroutinefunction(original_create):
        client.chat.completions.create = traced_create
    else:
        client.chat.completions.create = traced_create_sync

    return client


def wrap_anthropic(client: Any, project: Optional[str] = None) -> Any:
    original_messages_create = client.messages.create
    original_messages_create_async = getattr(client.messages, "create", None)

    async def traced_messages_create(*args, **kwargs):
        tracking_client = get_client()

        trace_id = get_current_trace_id()
        if not trace_id:
            trace_id = str(uuid4())
            trace = await tracking_client.create_trace(
                {"name": kwargs.get("model", "anthropic")}
            )
            trace_id = trace["id"]

        start_time = datetime.utcnow()
        run_id = str(uuid4())

        input_data = {
            "model": kwargs.get("model"),
            "messages": kwargs.get("messages", []),
            "max_tokens": kwargs.get("max_tokens"),
        }

        await tracking_client.create_run(
            {
                "trace_id": trace_id,
                "name": f"Anthropic: {kwargs.get('model', 'unknown')}",
                "run_type": "llm",
                "input": input_data,
                "start_time": start_time.isoformat(),
            }
        )

        try:
            response = await original_messages_create(*args, **kwargs)
            end_time = datetime.utcnow()

            output_data = {
                "content": [block.model_dump() for block in response.content]
                if response.content
                else [],
                "usage": (
                    {
                        "input_tokens": response.usage.input_tokens,
                        "output_tokens": response.usage.output_tokens,
                    }
                    if response.usage
                    else None
                ),
            }

            await tracking_client.update_run(
                run_id,
                {
                    "output": output_data,
                    "end_time": end_time.isoformat(),
                },
            )

            if response.usage:
                await tracking_client.create_token_usage(
                    {
                        "run_id": run_id,
                        "prompt_tokens": response.usage.input_tokens,
                        "completion_tokens": response.usage.output_tokens,
                        "total_tokens": response.usage.input_tokens
                        + response.usage.output_tokens,
                        "model": kwargs.get("model"),
                    }
                )

            return response

        except Exception as e:
            end_time = datetime.utcnow()
            await tracking_client.update_run(
                run_id,
                {
                    "error": str(e),
                    "end_time": end_time.isoformat(),
                },
            )
            raise

    if asyncio.iscoroutinefunction(original_messages_create):
        client.messages.create = traced_messages_create
    else:
        client.messages.create = traced_messages_create

    return client


import asyncio
