from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional

import torch
from torch import Tensor, nn

from spflow.exceptions import ScopeError
from spflow.meta.data import Scope
from spflow.modules.module import Module
from spflow.modules.module_shape import ModuleShape
from spflow.modules.ops.split import Split
from spflow.utils.cache import Cache
from spflow.utils.sampling_context import (
    SamplingContext,
)


class BaseProduct(Module, ABC):
    """Base class for product operations in probabilistic circuits.

    Computes joint distributions via factorization. Assumes conditional independence
    between disjoint input scopes. Abstract class requiring mapping method implementations.

    Attributes:
        inputs: Input modules to multiply.
        input_is_split: Whether input is a split operation.
        num_splits: Number of splits if input is split.
        scope: Combined scope of all inputs.
    """

    def __init__(
        self,
        inputs: list[Module] | Module,
    ) -> None:
        """Initialize product module.

        Args:
            inputs: Input module(s) with pairwise disjoint scopes.

        Raises:
            ValueError: No inputs provided.
            ScopeError: Input scopes not pairwise disjoint.
        """
        super().__init__()

        # ========== 1. INPUT VALIDATION ==========
        # Validate before processing to avoid indexing errors
        if isinstance(inputs, list) and not inputs:
            raise ValueError(f"'{self.__class__.__name__}' requires at least one input to be specified.")

        # ========== 2. INPUT TYPE PROCESSING ==========
        # Check if input is Split type and handle accordingly
        if isinstance(inputs, Split):
            self.input_is_split = True
            self.num_splits = inputs.num_splits
            inputs = [inputs]
        else:
            self.input_is_split = False
            # Determine num_splits from first input's features
            if inputs[0].out_shape.features == 1:
                self.num_splits = 1
            else:
                self.num_splits = None

        # ========== 3. CONFIGURATION VALIDATION ==========
        # Validate scopes are pairwise disjoint
        if not Scope.all_pairwise_disjoint([inp.scope for inp in inputs]):
            raise ScopeError("Input scopes must be disjoint.")

        # ========== 4. INPUT MODULE SETUP ==========
        self.inputs = nn.ModuleList(inputs)

        # ========== 5. ATTRIBUTE INITIALIZATION ==========
        # Join all input scopes to create combined scope
        self.scope = Scope.join_all([inp.scope for inp in self.inputs])

        # Set in_shape early so subclasses can use in_shape.channels
        # in_channels = max channels across all inputs (for broadcasting)
        in_channels = max(inp.out_shape.channels for inp in self.inputs)
        self.in_shape = ModuleShape(
            self.inputs[0].out_shape.features, in_channels, self.inputs[0].out_shape.repetitions
        )
        # Note: out_shape must be set by subclasses

    @abstractmethod
    def map_out_channels_to_in_channels(self, output_ids: Tensor) -> Tensor:
        """Map output channel indices to input channel indices.

        Args:
            output_ids: Tensor containing output channel indices.

        Returns:
            Tensor: Mapped input channel indices.
        """
        pass

    @abstractmethod
    def map_out_mask_to_in_mask(self, mask: Tensor) -> Tensor:
        """Map output mask to input mask.

        Args:
            mask: Output mask tensor.

        Returns:
            Tensor: Mapped input mask tensor.
        """
        pass

    def extra_repr(self) -> str:
        return f"{super().extra_repr()}"

    def _sample(
        self,
        data: Tensor,
        sampling_ctx: SamplingContext,
        cache: Cache,
    ) -> Tensor:
        """Generate samples from product module.

        Args:
            num_samples: Number of samples to generate.
            data: Optional data tensor to store samples.
            is_mpe: Whether to perform most probable explanation.
            cache: Optional cache for computation.
            sampling_ctx: Optional sampling context.

        Returns:
            Tensor: Generated samples.
        """
        # Prepare data tensor

        # initialize contexts
        sampling_ctx.validate_sampling_context(
            num_samples=data.shape[0],
            num_features=self.out_shape.features,
            num_channels=self.out_shape.channels,
            num_repetitions=self.out_shape.repetitions,
            allowed_feature_widths=(1, self.out_shape.features),
        )
        sampling_ctx.broadcast_feature_width(
            target_features=self.out_shape.features,
            allow_from_one=True,
        )

        # Map to (i, j) to index left/right inputs
        channel_index = self.map_out_channels_to_in_channels(sampling_ctx.channel_index)
        mask = self.map_out_mask_to_in_mask(sampling_ctx.mask)

        # Iterate over inputs and route child-local indices/masks.
        channel_input_dim = -2 if sampling_ctx.is_differentiable else -1
        mask_input_dim = -1
        for i, inp in enumerate(self.inputs):
            cid = channel_index.select(dim=channel_input_dim, index=i)
            child_mask = mask.select(dim=mask_input_dim, index=i)

            if cid.ndim == 1:
                cid = cid.unsqueeze(1)
            if child_mask.ndim == 1:
                child_mask = child_mask.unsqueeze(1)

            child_channels = int(inp.out_shape.channels)
            if sampling_ctx.is_differentiable:
                if child_channels == 1:
                    cid = torch.ones(
                        (*cid.shape[:-1], 1),
                        dtype=cid.dtype,
                        device=cid.device,
                    )
                else:
                    cid = cid[..., :child_channels]
                    mass = cid.sum(dim=-1, keepdim=True)
                    eps = torch.finfo(cid.dtype).eps
                    cid = torch.where(
                        mass > 0,
                        cid / mass.clamp_min(eps),
                        torch.zeros_like(cid),
                    )
            else:
                if child_channels == 1:
                    cid = torch.zeros_like(cid)

            child_ctx = sampling_ctx.with_routing(channel_index=cid, mask=child_mask)
            inp._sample(
                data=data,
                cache=cache,
                sampling_ctx=child_ctx,
            )

        return data

    def marginalize(
        self,
        marg_rvs: list[int],
        prune: bool = True,
        cache: Cache | None = None,
    ) -> Optional["BaseProduct | Module"]:
        """Marginalize specified variables (must be implemented by subclasses).

        Args:
            marg_rvs: List of variable indices to marginalize.
            prune: Whether to prune the resulting structure.
            cache: Optional cache for computation.

        Returns:
            Optional[BaseProduct | Module]: Marginalized module or None.
        """
        # This is not yet implemented for BaseProduct
        # Reasons: Marginalization over the element-product has a couple of challenges:
        # - If the input is a single module, we need to ensure the splits are still equally sized
        # - We need to eventually update the split_indices (non-trivial mapping)
        # - If the input are two modules, we need to ensure both inputs have the same number of features
        raise NotImplementedError(
            "Not implemented for BaseProduct -- needs to be called on subclasses of BaseProduct."
        )

    @abstractmethod
    def log_likelihood(
        self,
        data: Tensor,
        cache: Cache | None = None,
    ) -> Tensor:
        """Compute log likelihood.

        Args:
            data: Input data tensor.
            cache: Optional cache for computation.

        Returns:
            Tensor: Log likelihood values.
        """
        pass

    def _get_input_log_likelihoods(
        self,
        data: Tensor,
        cache: Cache | None = None,
    ) -> list[Tensor]:
        """Prepare input log-likelihoods.

        Args:
            data: Input data tensor.
            cache: Optional cache for computation.

        Returns:
            list[Tensor]: List of log-likelihood tensors for each input.
        """
        if self.input_is_split:
            lls = self.inputs[0].log_likelihood(
                data,
                cache=cache,
            )

        else:
            lls = []
            for inp in self.inputs:
                ll = inp.log_likelihood(
                    data,
                    cache=cache,
                )
                lls.append(ll)

        return lls
