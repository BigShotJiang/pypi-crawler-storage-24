# -*- coding-utf8 -*-
import numpy as np
from lazylinop.butterfly import Chain, fuse, ksm
try:
    import torch
except ModuleNotFoundError:
    torch = None
import time
from array_api_compat import (
    array_namespace, is_cupy_array, is_numpy_array, is_torch_array)


def _benchmark(op, x, n1, n2, **kwargs):
    """
    To benchmark op @ x.
    """
    # Warmup
    for _ in range(n2):
        y = op @ x
    # Benchmark
    xp = array_namespace(x)
    device = x.device
    duration = {
        "cpu": [0.0] * n1,
        "gpu": [0.0] * n1,
        "op": [0.0] * n1,
    }

    if is_cupy_array(x):
        # CUDA event to measure kernel execution time.
        start = xp.cuda.Event()
        end = xp.cuda.Event()
    elif is_torch_array(x) and x.device.type == "cuda":
        # CUDA event to measure kernel execution time.
        start = xp.Event(device=x.device, enable_timing=True)
        end = xp.Event(device=x.device, enable_timing=True)
    # Run n1 times n2 repeats.
    for i in range(n1):
        # Record before the n2 repeats.
        if is_cupy_array(x):
            start.record()
        elif is_torch_array(x) and x.device.type == "cuda":
            start.record()
        else:
            t0 = time.time()
        # Run n2 repeats.
        for _ in range(n2):
            op @ x
            # Check if op has attributes from _multiple_ksm fn.
            if hasattr(op, "ksm_data") and hasattr(op.ksm_data, "duration"):
                duration["op"][i] += (
                    sum(op.ksm_data.duration["ksmm"]) +
                    op.ksm_data.duration["perm"] +
                    op.ksm_data.duration["copy"]
                ) / n2
        # Record after the end of the n2 repeats.
        if is_cupy_array(x):
            end.record()
            end.synchronize()
            duration[
                "gpu"][i] = 1e-3 * xp.cuda.get_elapsed_time(start, end) / n2
        elif is_torch_array(x) and x.device.type == "cuda":
            end.record()
            torch.cuda.synchronize()
            duration["gpu"][i] = 1e-3 * start.elapsed_time(end) / n2
        else:
            duration["cpu"][i] = (time.time() - t0) / n2

    return duration, y


def optimize(x, strategy: str, params: dict, verbose: bool = True):
    r"""
    Adaptively fuse:

    - a list ``x`` of chainable 4D arrays
      (see :py:func:`lazylinop.butterfly.Chain` for more details)
    - an instance of :py:class:`lazylinop.butterfly.Chain`
      according to ``strategy`` argument and return:

    - a new list ``res`` of ``ks_values``.
      The resulting list ``res`` of 4D arrays
      is of length ``n_factors <= len(x)`` and satisfies
      ``ksm(x).toarray() == ksm(res).toarray()``.
    - a new chain.

    This function is a utility to optimize the implementation of butterfly
    matrices: while being frugal in memory, butterfly matrices implemented
    via many (chainable) Kronecker sparse factors are sometimes less
    computationally efficient than their (exact) fused
    implementation using fewer factors.

    Args:
        x: ``list`` of 4D arrays or :py:class:`lazylinop.butterfly.Chain`
            List of chainable 4D arrays or an instance of
            :py:class:`lazylinop.butterfly.Chain`.
        strategy, params: ``str`` and ``dict``
            It could be:

            - ``'benchmark'``
              recursively fuses two consecutive elements
              if the resulting fused factor gives better performance
              than the sum of the two.
              :octicon:`info;1em;sd-text-success` It might takes some
              times depending on the size of the factors,
              on the backend (see :py:func:`lazylinop.butterfly.ksm`
              for more details), on the dtype
              and on the device of the ``ks_values``.
              The value of ``params`` depends on the type of ``x``:

              - If ``x`` is a chain, the four arguments
                ``params = {"backend": backend,
                "array_namespace": array_namespace,
                "dtype": dtype,
                "device": device}`` are mandatory.
              - If ``x`` is a list of ``ks_values``,
                ``params = {"backend": backend}``
                argument is mandatory while ``array_namespace, dtype, device``
                are determined using the ``ks_values``.
              Possible values of ``array_namespace`` are

              - ``cp`` using ``import cupy as cp``
              - ``np`` using ``import numpy as np``
              - ``torch`` using ``import torch``
              Possible values of ``dtype`` and ``device`` depend on the
              array namespace.
              Please refer to the documentation of CuPy, NumPy and PyTorch.
            - ``'memory'`` find the two consecutive elements
              that minimize the memory of the resulting fused.
              The strategy expects ``params = {"n_factors": n_factors}``
              where ``n_factors`` is the number of factors returned
              by the function.
            - ``'sparsity'`` find the two consecutive elements that
              minimize the ratio $\frac{1}{ad}$ of the resulting fused.
              The strategy expects ``params = {"n_factors": n_factors}``
              where ``n_factors`` is the number of factors returned
              by the function.
            - ``'speed'`` find the two consecutive elements that
              minimize the ratio $\frac{bc}{b+c}$ of the resulting fused.
              The strategy expects ``params = {"n_factors": n_factors}``
              where ``n_factors`` is the number of factors returned
              by the function.
            - ``balanced`` fuse from left to right and right to left ($n>3$).
              The strategy expects ``params = {"n_factors": n_factors}``
              where ``n_factors`` is the number of factors returned
              by the function.

              - Case ``n = 6`` and ``n_factors = 2``:

                - step 0: 0 1 2 3 4 5
                - step 1: 01 2 3 45
                - step 2: 012 345
              - Case ``n = 7`` and ``n_factors = 2``:

                - step 0: 0 1 2 3 4 5 6
                - step 1: 01 2 3 4 56
                - step 2: 012 3 456
                - step 3: 0123 456
              - Case ``n = 7`` and ``n_factors = 3``:

                - step 0: 0 1 2 3 4 5 6
                - step 1: 01 2 3 4 56
                - step 2: 012 3 456
            - ``consecutive`` fuse from left to right.
              The strategy expects ``params = {"n_factors": n_factors}``
              where ``n_factors`` is the number of factors returned
              by the function.
              - Case ``n = 6`` and ``n_factors = 3``:

                - step 0: 0 1 2 3 4 5
                - step 1: 01 2 3 4 5
                - step 2: 01 23 4 5
                - step 3: 01 23 45
              - Case ``n = 7`` and ``n_factors = 2``:

                - step 0: 0 1 2 3 4 5 6
                - step 1: 01 2 3 4 5 6
                - step 2: 01 23 4 5 6
                - step 3: 01 23 45 6
                - step 4: 0123 45 6
                - step 5: 0123 456
        verbose: ``bool``, optional
            Print fuse steps.
            Default value is ``True``.

    Returns:
        - If ``x`` is a list of 4d arrays return
          a list ``res`` of chainable 4D arrays
          of length ``len(res) = n_factors`` that satisfies
          ``ksm(x).toarray() == ksm(res).toarray()``.
        - If ``x`` is :py:func:`lazylinop.butterfly.Chain` return
          a new chain of length ``res.n_patterns = n_factors``.

    .. seealso::
        - :py:func:`lazylinop.butterfly.fuse`,
        - :py:func:`lazylinop.butterfly.ksm`,
        - :py:class:`lazylinop.butterfly.Chain`.

    Examples:
        >>> import numpy as np
        >>> from lazylinop.butterfly import ksm
        >>> from lazylinop.wip.butterfly.optimize import optimize
        >>> a1, b1, c1, d1 = 2, 2, 2, 4
        >>> a2, b2, c2, d2 = 4, 2, 2, 2
        >>> v1 = np.random.randn(a1, b1, c1, d1)
        >>> v2 = np.random.randn(a2, b2, c2, d2)
        >>> v = optimize([v1, v2], strategy='memory', n_factors=1)
               ['0', '1']
        step=0 ['01']
        >>> v[0].shape
        (2, 4, 4, 2)
        >>> L = ksm(v)
        >>> L1 = ksm(v1)
        >>> L2 = ksm(v2)
        >>> x = np.random.randn(L.shape[1])
        >>> np.allclose(L @ x, L1 @ L2 @ x)
        True
        >>> # Consecutive strategy.
        >>> n = 5
        >>> ksv = [np.random.randn(2, 2, 2, 2)] * n
        >>> v = optimize(ksv, strategy='consecutive', n_factors=2)
               ['0', '1', '2', '3', '4']
        step=0 ['01', '2', '3', '4']
        step=1 ['01', '23', '4']
        step=2 ['0123', '4']
    """

    _is_list, _is_chain = False, False
    if isinstance(x, list):
        _is_list = True
        n = len(x)
        for i in range(n):
            if len(x[i].shape) != 4:
                raise Exception(
                    "Each element of ks_values must be a 4D array.")
        chain = Chain([x[i].shape for i in range(n)])
        if not chain.chainable or not chain.valid:
            raise Exception("Each element of ks must be" +
                            " chainable and valid.")
    elif isinstance(x, Chain):
        _is_chain = True
        n = x.n_patterns
    else:
        raise Exception("x must be a list or a Chain.")

    n_factors = None
    if strategy != "benchmark" and "n_factors" not in params.keys():
        raise Exception(f"{strategy} expects number of factors.")
    if strategy != "benchmark" and "n_factors" in params.keys():
        n_factors = params["n_factors"]

    if (n_factors is not None and n == n_factors) or n == 1:
        # Nothing to fuse.
        if _is_list:
            return x.copy()
        elif _is_chain:
            return Chain([k for k in x.ks_patterns])
    else:
        # Copy the input list.
        if _is_list:
            _x = x.copy()
        elif _is_chain:
            _x = Chain([k for k in x.ks_patterns])
        m, target = n, n
        if strategy == 'balanced':
            if n <= 3:
                raise Exception("strategy 'balanced' does" +
                                " not work when len(ks_values) <= 3.")
            # Fuse from left to right and from right to left.
            step = 0
            idx = [str(i) for i in range(n)]
            if verbose:
                print(f"      ", idx)
            lpos, rpos, left = 0, m - 1, True
            while True:
                if left and target > n_factors:
                    # From left to right.
                    idx[lpos] = idx[lpos] + idx[lpos + 1]
                    idx.pop(lpos + 1)
                    if _is_list:
                        _x[lpos] = fuse([_x[lpos], _x[lpos + 1]])
                        _x.pop(lpos + 1)
                    elif _is_chain:
                        _x = _x.fuse(lpos)
                    target -= 1
                    lpos += 1
                    rpos -= 1
                if not left and target > n_factors and rpos > lpos:
                    # From right to left.
                    idx[rpos - 1] = idx[rpos - 1] + idx[rpos]
                    idx.pop(rpos)
                    if _is_list:
                        _x[rpos - 1] = fuse([_x[rpos - 1], _x[rpos]])
                        _x.pop(rpos)
                    elif _is_chain:
                        _x = _x.fuse(rpos - 1)
                    target -= 1
                    rpos -= 2
                left = not left
                if lpos >= rpos:
                    lpos, rpos = 0, target - 1
                if verbose:
                    print(f"step={step}", idx)
                step += 1
                if target == n_factors:
                    break
            return _x
        elif strategy == 'consecutive':
            # Fuse from left to right.
            step = 0
            idx = [str(i) for i in range(n)]
            if verbose:
                print(f"      ", idx)
            lpos = 0
            while True:
                if target > n_factors:
                    # From left to right.
                    idx[lpos] = idx[lpos] + idx[lpos + 1]
                    idx.pop(lpos + 1)
                    if _is_list:
                        _x[lpos] = fuse([_x[lpos], _x[lpos + 1]])
                        _x.pop(lpos + 1)
                    elif _is_chain:
                        _x = _x.fuse(lpos)
                    target -= 1
                    lpos += 1
                if lpos + 1 >= len(idx):
                    lpos, m = 0, len(idx)
                if verbose:
                    print(f"step={step}", idx)
                step += 1
                if target == n_factors:
                    break
            if _is_list:
                return _x[:n_factors]
            elif _is_chain:
                return Chain([k for k in _x.ks_patterns[:n_factors]])
        elif strategy in ('memory', 'speed', 'sparsity'):
            step = 0
            idx = [str(i) for i in range(n)]
            if verbose:
                print(f"      ", idx)
            n_fuses = 0
            while True:
                # Build memory list.
                heuristic = np.full(n - n_fuses - 1, 0.0)
                memory = np.full(n - n_fuses - 1, 0)
                sparsity = np.full(n - n_fuses - 1, 0.0)
                for i in range(n - n_fuses - 1):
                    if _is_list:
                        a1, b1, c1, d1 = _x[i].shape
                        a2, b2, c2, d2 = _x[i + 1].shape
                    elif _is_chain:
                        a1, b1, c1, d1 = _x.ks_patterns[i]
                        a2, b2, c2, d2 = _x.ks_patterns[i + 1]
                    b = (b1 * d1) // d2
                    c = (a2 * c2) // a1
                    memory[i] = a1 * b * c * d2
                    # Because of argmin, compute the inverse.
                    heuristic[i] = 1.0 / ((b + c) / (b * c))
                    sparsity[i] = 1.0 / (a1 * d2)
                # Find argmin.
                if strategy == 'memory':
                    # argmin = np.argmin(memory)
                    tmp = np.where(memory == memory[np.argmin(memory)])[0]
                    if n_fuses % 2 == 0:
                        argmin = tmp[0]
                    else:
                        argmin = tmp[-1]
                elif strategy == 'speed':
                    # argmin = np.argmin(heuristic)
                    tmp = np.where(
                        heuristic == heuristic[np.argmin(heuristic)])[0]
                    if n_fuses % 2 == 0:
                        argmin = tmp[0]
                    else:
                        argmin = tmp[-1]
                elif strategy == 'sparsity':
                    # argmin = np.argmin(sparsity)
                    tmp = np.where(
                        sparsity == sparsity[np.argmin(sparsity)])[0]
                    if n_fuses % 2 == 0:
                        argmin = tmp[0]
                    else:
                        argmin = tmp[-1]
                # Fuse argmin and argmin + 1.
                if _is_list:
                    _x[argmin] = fuse([_x[argmin], _x[argmin + 1]])
                elif _is_chain:
                    _x = _x.fuse(argmin)
                idx[argmin] = idx[argmin] + idx[argmin + 1]
                n_fuses += 1
                # Delete argmin + 1.
                if _is_list:
                    _x.pop(argmin + 1)
                idx.pop(argmin + 1)
                target -= 1
                if verbose:
                    print(f"step={step}", idx)
                step += 1
                if target == n_factors:
                    break
            return _x
        elif strategy == "benchmark":
            n1, n2 = 30, 10
            if _is_list:
                if len(params.keys()) != 1:
                    raise Exception(
                        "strategy expects params to be a dict" +
                        " with only one key 'backend'.")
                xp = array_namespace(_x[0])
                dtype = _x[0].dtype
                device = _x[0].device
            elif _is_chain:
                if len(params.keys()) != 4:
                    raise Exception(
                        "strategy expects params to be a dict" +
                        " with four keys 'backend', 'array_namespace'," +
                        " 'dtype', 'device'.")
                xp = params["array_namespace"]
                dtype = params["dtype"]
                device = params["device"]
            _backend = params["backend"]
            ok_fuse = [1] * (len(_x) - 1)
            i = 0
            while 1:
                # i = int(np.random.randint(0, high=len(_x) - 1))
                j = i + 1
                # Benchmark i + j against fuse(i, j).
                if _is_list:
                    L2 = ksm([_x[i], _x[j]], backend=_backend)
                    ksv = fuse([_x[i], _x[j]])
                elif _is_chain:
                    ksv1 = np.random.randn(*(_x.ks_patterns[i]))
                    ksv2 = np.random.randn(*(_x.ks_patterns[j]))
                    L2 = ksm([ksv1, ksv2], backend=_backend)
                    # Do not need to fuse two 4d arrays here.
                    ksv = np.random.randn(*(_x.fuse(i).ks_patterns[i]))
                L = ksm(ksv, backend=_backend)
                u = xp.asarray(
                    np.random.randn(L2.shape[1]), dtype=dtype, device=device)
                d12, _ = _benchmark(L2, u, n1, n2)
                d, _ = _benchmark(L, u, n1, n2)
                d12 = sum(d12["cpu"]) + sum(d12["gpu"])
                d = sum(d["cpu"]) + sum(d["gpu"])
                # Keep fuse(i, i + 1) if duration is less than 0.95
                # the duration of i + 1 followed by i.
                if d < 0.95 * d12:
                    # print(i, j, len(_ts), d, d12)
                    if _is_list:
                        _x[i] = ksv
                        _x.pop(j)
                    elif _is_chain:
                        _x = _x.fuse(i)
                    ok_fuse[i] = 1
                    if j < len(ok_fuse):
                        ok_fuse.pop(j)
                    if (_is_list and len(_x) == 2) or (
                            _is_chain and _x.n_patterns == 2):
                        # Stop before to fuse the last two factors.
                        break
                else:
                    ok_fuse[i] = 0
                    if sum(ok_fuse) == 0:
                        break
                i += 1
                # Restart from the current first factor.
                if (_is_list and (i + 1) >= len(_x)) or (
                        _is_chain and (i + 1) >= _x.n_patterns):
                    i = 0
                    ok_fuse = [1] * (len(_x) - 1)
            return _x
        else:
            raise Exception(
                "strategy must be either 'balanced'," +
                " 'consecutive', 'memory', 'sparsity'" +
                " 'speed' or" +
                " ('benchmark', backend, array_namespace, dtype, device).")
