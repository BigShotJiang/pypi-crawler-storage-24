"""
Build provenance record — auto-generated, do not edit.

This file is embedded by the CI/CD pipeline at build time.
It provides hash verification and optional cryptographic
signature verification for this package distribution.
"""

PROVENANCE = {
    'schema_version': '1.0',
    'artifact_hash': 'sha512:efbe2db5548940220faa17c96266898e2f6dbb7e62e6a12d1587599e5162dba52c3d9c151e34d6186b49ea6e4a1903886833272d7ecb1045b58fb51544f2f19d',
    'version': '0.3.9',
    'registry': 'pypi',
    'package_name': 'kevros',
    'build_timestamp': '2026-03-23T20:40:37Z',
    'build_host_hash': 'sha256:662b791465090e83f3f5d452c444c6d307bbda0b81137b466308aac435ab32db',
    'git_commit': 'd525cd8daae702f9718ac400d11f71a73fa0785c',
    'git_branch': 'sdk-v0.3.9',
    'signer': 'github-actions-oidc',
    'signature_algorithm': '',
    'signature': '',
    'public_key': '',
    'dependencies_hash': 'sha256:af7fec709272282e760a52a64e345086b314eadfec8a6ffa005187a67e5601b6',
}


def get_provenance() -> dict:
    """Return a copy of the build provenance record."""
    return dict(PROVENANCE)
