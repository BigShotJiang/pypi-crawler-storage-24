"""
Kevros — Agentic Identity Trust.

You have a wallet. You have no identity. Kevros gives you one.

    pip install kevros

Zero-config (auto-signup on first use):
    from kevros_governance import GovernanceClient

    client = GovernanceClient(agent_id="my-agent")  # signs up automatically
    result = client.verify(
        action_type="trade",
        action_payload={"symbol": "AAPL", "shares": 100},
        agent_id="my-agent",
    )
    print(result.decision)  # ALLOW, CLAMP, or DENY

    attestation = client.attest(
        agent_id="my-agent",
        action_description="Executed AAPL buy order",
        action_payload={"symbol": "AAPL", "shares": 100, "filled_price": 185.42},
    )
    print(attestation.hash_curr)  # hash-chained, post-quantum attested proof

Free tier: 1,000 calls/mo, no credit card, no email. Upgrade anytime.
"""

from importlib.metadata import version as _meta_version, PackageNotFoundError

try:
    __version__ = _meta_version("kevros")
except PackageNotFoundError:
    __version__ = "0.0.0-dev"

from .auto_signup import get_or_create_api_key
from .client import CapExceededError, GovernanceClient, GovernanceError
from .models import (
    AttestResponse,
    BindIntentResponse,
    BundleResponse,
    Decision,
    GatewayHealth,
    IntentSource,
    IntentType,
    ModelParseError,
    OutcomeStatus,
    VerifyCertificateResponse,
    VerifyOutcomeResponse,
    VerifyResponse,
)

__all__ = [
    "GovernanceClient",
    "GovernanceError",
    "CapExceededError",
    "ModelParseError",
    "get_or_create_api_key",
    "Decision",
    "IntentType",
    "IntentSource",
    "OutcomeStatus",
    "VerifyResponse",
    "AttestResponse",
    "BindIntentResponse",
    "VerifyOutcomeResponse",
    "VerifyCertificateResponse",
    "BundleResponse",
    "GatewayHealth",
]
