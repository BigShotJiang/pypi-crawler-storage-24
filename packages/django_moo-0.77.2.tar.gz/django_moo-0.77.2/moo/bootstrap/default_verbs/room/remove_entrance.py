#!moo verb remove_entrance --on $room

# pylint: disable=return-outside-function,undefined-variable,no-name-in-module

"""
Perform the opposite function to the `add_entrance` verb. It removes `entrance`` from the room``s list of
entrances. If it is not possible to remove `entrance`` from the room``s entrance list (normally because the object
that invoked the verb does not have the required permission) then the verb returns `False`. Otherwise, a successful
addition returns `True`.
"""

from moo.core import NoSuchPropertyError

entrance = args[0]

try:
    entrances = this.get_property("entrances")
except NoSuchPropertyError:
    entrances = []

entrances.remove(entrance)
this.set_property("entrances", entrances)

return True
