from typing import Final, Sequence

from utils import test
from cardy import n_sorts

BELL_NUMBERS: Final[tuple[int, ...]] = (
    1, 1, 2, 5, 15, 52, 203, 877, 4140, 21147, 115975, 678570, 4213597,
    27644437, 190899322, 1382958545, 10480142147, 82864869804, 682076806159,
    5832742205057, 51724158235372, 474869816156751, 4506715738447323,
    44152005855084346, 445958869294805289, 4638590332229999353,
    49631246523618756274
)

# A table of the number of sorts for a C by G card sort.
# The row number represents the number of cards (1-based)
# The column represents the number of groups (1-based)
# @formatter:off
C_BY_G: Final[Sequence[Sequence[int]]] = [
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2],
    [1, 4, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5, 5],
    [1, 8, 14, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15, 15],
    [1, 16, 41, 51, 52, 52, 52, 52, 52, 52, 52, 52, 52, 52],
    [1, 32, 122, 187, 202, 203, 203, 203, 203, 203, 203, 203, 203, 203],
    [1, 64, 365, 715, 855, 876, 877, 877, 877, 877, 877, 877, 877, 877],
    [1, 128, 1094, 2795, 3845, 4111, 4139, 4140, 4140, 4140, 4140, 4140, 4140, 4140],
    [1, 256, 3281, 11051, 18002, 20648, 21110, 21146, 21147, 21147, 21147, 21147, 21147, 21147],
    [1, 512, 9842, 43947, 86472, 109299, 115179, 115929, 115974, 115975, 115975, 115975, 115975, 115975],
    [1, 1024, 29525, 175275, 422005, 601492, 665479, 677359, 678514, 678569, 678570, 678570, 678570, 678570],
    [1, 2048, 88574, 700075, 2079475, 3403127, 4030523, 4189550, 4211825, 4213530, 4213596, 4213597, 4213597, 4213597],
    [1, 4096, 265721, 2798251, 10306752, 19628064, 25343488, 27243100, 27602602, 27641927, 27644358, 27644436, 27644437, 27644437],
    [1, 8192, 797162, 11188907, 51263942, 114700315, 164029595, 184941915, 190077045, 190829797, 190895863, 190899230, 190899321, 190899322]
]
# @formatter:on

@test
def the_number_of_sorts_is_the_bell_number_for_the_number_of_cards():
    for i in range(len(BELL_NUMBERS)):
        assert n_sorts(i) == BELL_NUMBERS[i]


@test
def the_number_of_ways_to_sort_n_cards_into_at_most_n_groups_is_the_bell_number():
    for i in range(len(BELL_NUMBERS)):
        assert n_sorts(i, i) == BELL_NUMBERS[i]


@test
def there_is_one_way_to_sort_no_cards_into_no_groups():
    assert n_sorts(0, 0) == 1


@test
def there_are_no_ways_to_sort_cards_into_no_groups():
    for i in range(1, len(BELL_NUMBERS)):
        assert n_sorts(i, 0) == 0


@test
def there_is_one_way_to_sort_one_card_into_groups():
    for i in range(1, len(BELL_NUMBERS)):
        assert n_sorts(1, i) == 1


@test
def sorts_with_limited_groups_are_counted():
    for i in range(1, len(C_BY_G) + 1):
        for j in range(1, len(C_BY_G[i - 1]) + 1):
            # C_BY_G is 1-indexed
            assert n_sorts(i, j) == C_BY_G[i - 1][j - 1]
