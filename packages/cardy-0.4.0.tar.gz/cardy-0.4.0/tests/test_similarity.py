from utils import test
from cardy import similarity_matrix, similarity_mapping, dissimilarity_matrix, \
    dissimilarity_mapping

sort1 = ((1, 2), (3, 4, 5), (6, 7, 8))
sort2 = ((1, 2), (3, 4, 5), (6, 7, 8))
sort3 = ((1, 3, 4), (2, 5), (6, 7, 8))
sort4 = ((1, 3), (2, 4, 5), (6, 7, 8))


@test
def similarity_and_dissimilarity_of_empty_sorts():
    assert similarity_matrix([]) == [[None]]
    assert dissimilarity_matrix([]) == [[None]]
    assert similarity_mapping([]) == {}
    assert dissimilarity_mapping([]) == {}
    assert similarity_matrix([], scale=True) == [[None]]
    assert dissimilarity_matrix([], scale=True) == [[None]]
    assert similarity_mapping([], scale=True) == {}
    assert dissimilarity_mapping([], scale=True) == {}


@test
def similarity_and_dissimilarity_of_one_sort():
    sort1_similarity = [
        [None, 1, 2, 3, 4, 5, 6, 7, 8],
        [1, 1, 1, 0, 0, 0, 0, 0, 0],
        [2, 1, 1, 0, 0, 0, 0, 0, 0],
        [3, 0, 0, 1, 1, 1, 0, 0, 0],
        [4, 0, 0, 1, 1, 1, 0, 0, 0],
        [5, 0, 0, 1, 1, 1, 0, 0, 0],
        [6, 0, 0, 0, 0, 0, 1, 1, 1],
        [7, 0, 0, 0, 0, 0, 1, 1, 1],
        [8, 0, 0, 0, 0, 0, 1, 1, 1],
    ]
    assert similarity_matrix([sort1]) == sort1_similarity
    assert similarity_matrix([sort1], scale=True) == sort1_similarity
    sort1_dissimilarity = [
        [None, 1, 2, 3, 4, 5, 6, 7, 8],
        [1, 0, 0, 1, 1, 1, 1, 1, 1],
        [2, 0, 0, 1, 1, 1, 1, 1, 1],
        [3, 1, 1, 0, 0, 0, 1, 1, 1],
        [4, 1, 1, 0, 0, 0, 1, 1, 1],
        [5, 1, 1, 0, 0, 0, 1, 1, 1],
        [6, 1, 1, 1, 1, 1, 0, 0, 0],
        [7, 1, 1, 1, 1, 1, 0, 0, 0],
        [8, 1, 1, 1, 1, 1, 0, 0, 0],
    ]
    assert dissimilarity_matrix([sort1]) == sort1_dissimilarity
    assert dissimilarity_matrix([sort1], scale=True) == sort1_dissimilarity
    sort1_similarity_map = {
        1: {1: 1, 2: 1, 3: 0, 4: 0, 5: 0, 6: 0, 7: 0, 8: 0},
        2: {1: 1, 2: 1, 3: 0, 4: 0, 5: 0, 6: 0, 7: 0, 8: 0},
        3: {1: 0, 2: 0, 3: 1, 4: 1, 5: 1, 6: 0, 7: 0, 8: 0},
        4: {1: 0, 2: 0, 3: 1, 4: 1, 5: 1, 6: 0, 7: 0, 8: 0},
        5: {1: 0, 2: 0, 3: 1, 4: 1, 5: 1, 6: 0, 7: 0, 8: 0},
        6: {1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 1, 7: 1, 8: 1},
        7: {1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 1, 7: 1, 8: 1},
        8: {1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 1, 7: 1, 8: 1},
    }
    assert similarity_mapping([sort1]) == sort1_similarity_map
    assert similarity_mapping([sort1], scale=True) == sort1_similarity_map
    sort1_dissimilarity_map = {
        1: {1: 0, 2: 0, 3: 1, 4: 1, 5: 1, 6: 1, 7: 1, 8: 1},
        2: {1: 0, 2: 0, 3: 1, 4: 1, 5: 1, 6: 1, 7: 1, 8: 1},
        3: {1: 1, 2: 1, 3: 0, 4: 0, 5: 0, 6: 1, 7: 1, 8: 1},
        4: {1: 1, 2: 1, 3: 0, 4: 0, 5: 0, 6: 1, 7: 1, 8: 1},
        5: {1: 1, 2: 1, 3: 0, 4: 0, 5: 0, 6: 1, 7: 1, 8: 1},
        6: {1: 1, 2: 1, 3: 1, 4: 1, 5: 1, 6: 0, 7: 0, 8: 0},
        7: {1: 1, 2: 1, 3: 1, 4: 1, 5: 1, 6: 0, 7: 0, 8: 0},
        8: {1: 1, 2: 1, 3: 1, 4: 1, 5: 1, 6: 0, 7: 0, 8: 0},
    }
    assert dissimilarity_mapping([sort1]) == sort1_dissimilarity_map
    assert dissimilarity_mapping([sort1], scale=True) == sort1_dissimilarity_map


@test
def similarity_matrices_can_be_created_for_multiple_sorts():
    assert similarity_matrix([sort1, sort2, sort3, sort4]) == [
        [None, 1, 2, 3, 4, 5, 6, 7, 8],
        [1, 4, 2, 2, 1, 0, 0, 0, 0],
        [2, 2, 4, 0, 1, 2, 0, 0, 0],
        [3, 2, 0, 4, 3, 2, 0, 0, 0],
        [4, 1, 1, 3, 4, 3, 0, 0, 0],
        [5, 0, 2, 2, 3, 4, 0, 0, 0],
        [6, 0, 0, 0, 0, 0, 4, 4, 4],
        [7, 0, 0, 0, 0, 0, 4, 4, 4],
        [8, 0, 0, 0, 0, 0, 4, 4, 4],
    ]


@test
def similarity_mappings_can_be_created_for_multiple_sorts():
    assert similarity_mapping([sort1, sort2, sort3, sort4]) == {
        1: {1: 4, 2: 2, 3: 2, 4: 1, 5: 0, 6: 0, 7: 0, 8: 0},
        2: {1: 2, 2: 4, 3: 0, 4: 1, 5: 2, 6: 0, 7: 0, 8: 0},
        3: {1: 2, 2: 0, 3: 4, 4: 3, 5: 2, 6: 0, 7: 0, 8: 0},
        4: {1: 1, 2: 1, 3: 3, 4: 4, 5: 3, 6: 0, 7: 0, 8: 0},
        5: {1: 0, 2: 2, 3: 2, 4: 3, 5: 4, 6: 0, 7: 0, 8: 0},
        6: {1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 4, 7: 4, 8: 4},
        7: {1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 4, 7: 4, 8: 4},
        8: {1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 4, 7: 4, 8: 4},
    }


@test
def scaled_similarity_matrices_can_be_created_for_multiple_sorts():
    assert similarity_matrix([sort1, sort2, sort3, sort4], scale=True) == [
        [None, 1, 2, 3, 4, 5, 6, 7, 8],
        [1, 1, 0.5, 0.5, 0.25, 0, 0, 0, 0],
        [2, 0.5, 1, 0, 0.25, 0.5, 0, 0, 0],
        [3, 0.5, 0, 1, 0.75, 0.5, 0, 0, 0],
        [4, 0.25, 0.25, 0.75, 1, 0.75, 0, 0, 0],
        [5, 0, 0.5, 0.5, 0.75, 1, 0, 0, 0],
        [6, 0, 0, 0, 0, 0, 1, 1, 1],
        [7, 0, 0, 0, 0, 0, 1, 1, 1],
        [8, 0, 0, 0, 0, 0, 1, 1, 1],
    ]


@test
def scaled_similarity_mappings_can_be_created_for_multiple_sorts():
    assert similarity_mapping([sort1, sort2, sort3, sort4], scale=True) == {
        1: {1: 1, 2: 0.5, 3: 0.5, 4: 0.25, 5: 0, 6: 0, 7: 0, 8: 0},
        2: {1: 0.5, 2: 1, 3: 0, 4: 0.25, 5: 0.5, 6: 0, 7: 0, 8: 0},
        3: {1: 0.5, 2: 0, 3: 1, 4: 0.75, 5: 0.5, 6: 0, 7: 0, 8: 0},
        4: {1: 0.25, 2: 0.25, 3: 0.75, 4: 1, 5: 0.75, 6: 0, 7: 0, 8: 0},
        5: {1: 0, 2: 0.5, 3: 0.5, 4: 0.75, 5: 1, 6: 0, 7: 0, 8: 0},
        6: {1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 1, 7: 1, 8: 1},
        7: {1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 1, 7: 1, 8: 1},
        8: {1: 0, 2: 0, 3: 0, 4: 0, 5: 0, 6: 1, 7: 1, 8: 1},
    }


@test
def dissimilarity_matrices_can_be_created_for_multiple_sorts():
    assert dissimilarity_matrix([sort1, sort2, sort3, sort4]) == [
        [None, 1, 2, 3, 4, 5, 6, 7, 8],
        [1, 0, 2, 2, 3, 4, 4, 4, 4],
        [2, 2, 0, 4, 3, 2, 4, 4, 4],
        [3, 2, 4, 0, 1, 2, 4, 4, 4],
        [4, 3, 3, 1, 0, 1, 4, 4, 4],
        [5, 4, 2, 2, 1, 0, 4, 4, 4],
        [6, 4, 4, 4, 4, 4, 0, 0, 0],
        [7, 4, 4, 4, 4, 4, 0, 0, 0],
        [8, 4, 4, 4, 4, 4, 0, 0, 0],
    ]


@test
def dissimilarity_mappings_can_be_created_for_multiple_sorts():
    assert dissimilarity_mapping([sort1, sort2, sort3, sort4]) == {
        1: {1: 0, 2: 2, 3: 2, 4: 3, 5: 4, 6: 4, 7: 4, 8: 4},
        2: {1: 2, 2: 0, 3: 4, 4: 3, 5: 2, 6: 4, 7: 4, 8: 4},
        3: {1: 2, 2: 4, 3: 0, 4: 1, 5: 2, 6: 4, 7: 4, 8: 4},
        4: {1: 3, 2: 3, 3: 1, 4: 0, 5: 1, 6: 4, 7: 4, 8: 4},
        5: {1: 4, 2: 2, 3: 2, 4: 1, 5: 0, 6: 4, 7: 4, 8: 4},
        6: {1: 4, 2: 4, 3: 4, 4: 4, 5: 4, 6: 0, 7: 0, 8: 0},
        7: {1: 4, 2: 4, 3: 4, 4: 4, 5: 4, 6: 0, 7: 0, 8: 0},
        8: {1: 4, 2: 4, 3: 4, 4: 4, 5: 4, 6: 0, 7: 0, 8: 0},
    }


@test
def scaled_dissimilarity_matrices_can_be_created_for_multiple_sorts():
    assert dissimilarity_matrix([sort1, sort2, sort3, sort4], scale=True) == [
        [None, 1, 2, 3, 4, 5, 6, 7, 8],
        [1, 0, 0.5, 0.5, 0.75, 1, 1, 1, 1],
        [2, 0.5, 0, 1, 0.75, 0.5, 1, 1, 1],
        [3, 0.5, 1, 0, 0.25, 0.5, 1, 1, 1],
        [4, 0.75, 0.75, 0.25, 0, 0.25, 1, 1, 1],
        [5, 1, 0.5, 0.5, 0.25, 0, 1, 1, 1],
        [6, 1, 1, 1, 1, 1, 0, 0, 0],
        [7, 1, 1, 1, 1, 1, 0, 0, 0],
        [8, 1, 1, 1, 1, 1, 0, 0, 0],
    ]


@test
def scaled_dissimilarity_mappings_can_be_created_for_multiple_sorts():
    assert dissimilarity_mapping([sort1, sort2, sort3, sort4], scale=True) == {
        1: {1: 0, 2: 0.5, 3: 0.5, 4: 0.75, 5: 1, 6: 1, 7: 1, 8: 1},
        2: {1: 0.5, 2: 0, 3: 1, 4: 0.75, 5: 0.5, 6: 1, 7: 1, 8: 1},
        3: {1: 0.5, 2: 1, 3: 0, 4: 0.25, 5: 0.5, 6: 1, 7: 1, 8: 1},
        4: {1: 0.75, 2: 0.75, 3: 0.25, 4: 0, 5: 0.25, 6: 1, 7: 1, 8: 1},
        5: {1: 1, 2: 0.5, 3: 0.5, 4: 0.25, 5: 0, 6: 1, 7: 1, 8: 1},
        6: {1: 1, 2: 1, 3: 1, 4: 1, 5: 1, 6: 0, 7: 0, 8: 0},
        7: {1: 1, 2: 1, 3: 1, 4: 1, 5: 1, 6: 0, 7: 0, 8: 0},
        8: {1: 1, 2: 1, 3: 1, 4: 1, 5: 1, 6: 0, 7: 0, 8: 0},
    }
