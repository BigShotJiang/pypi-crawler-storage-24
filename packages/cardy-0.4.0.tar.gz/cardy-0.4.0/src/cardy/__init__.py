# Copyright 2026 Cardy Contributors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


from .distance import distance, norm_distance, max_distance
from .neighbourhood import neighbourhood
from .clique import clique
from .orthogonality import orthogonality
from .similarity import (
    similarity_matrix,
    similarity_mapping,
    dissimilarity_matrix,
    dissimilarity_mapping,
)
from .counting import n_sorts
from .types import *


__version__ = "0.4.0"
