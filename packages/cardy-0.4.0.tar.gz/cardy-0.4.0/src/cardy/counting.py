from functools import lru_cache
from math import comb

def n_sorts(n_cards: int, n_groups: int | None = None) -> int:
    if n_groups is None:
        return bell(n_cards)
    else:
        return bell_lim(n_cards, n_groups)


@lru_cache
def bell(n):
    if n == 0 or n == 1:
        return 1
    else:
        return sum(comb(n - 1, k) * bell(k) for k in range(n))


@lru_cache
def bell_lim(n, g):
    if g == 0 and n > 0:
        return 0
    elif n == 0 or n == 1:
        return 1
    else:
        return sum(comb(n - 1, k) * bell_lim(k, g - 1) for k in range(n))
