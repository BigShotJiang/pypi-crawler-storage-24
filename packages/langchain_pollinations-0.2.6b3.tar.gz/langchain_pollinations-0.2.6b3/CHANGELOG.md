# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Beta]

### [0.2.6b3] - 2026-03-08

#### Fixed
- ImagePollinations correctly inherits from langchain_core.runnables.Runnable

### [0.2.6b2] - 2026-03-07

#### Fixed
- Security: Bumped langgraph to 1.0.10 to resolve Dependabot alert 

### [0.2.6b1] - 2026-03-02

#### Fixed
- Dynamic load of model names 
- MessageContentPart support completed
- Documentation updated

#### Added
- New 402 API error handling 
- AccountInformation output types 

### [0.2.5b2] - 2026-02-21

#### Fixed
- Security: Bumped langchain-core to 1.2.11 to resolve Dependabot alert 
- Fixed: docs/project_structure.md and README.md

### [0.2.5b1] - 2026-02-19

#### Fixed
- Coding style fixed 
- Documentation fixed and updated
- Project prepared for PyPI publishing

#### Added
- API Reference

### [0.2.4] - 2026-02-18

#### Fixed
- Code intra-documentation fixed 
- Documentation updated

#### Added
- API Reference

### [0.2.3] - 2026-02-17

#### Added
- Backend error handling incorporated as a structured object
- New unit tests for error handling

### [0.2.2] - 2026-02-16

#### Fixed
- Response parsing fixes in account.py

#### Added
- New methods to get available text and image models in models.py
- New unit tests for new methods in models.py

### [0.2.1] - 2026-02-14

#### Fixed
- Handling potential empty responses in AIMessage.content

#### Added
- Integration tests for multimodal use of ChatPollinations class

### [0.2.0] - 2026-02-14

#### Added
- PollinAPI updates: new models.
- PollinAPI updates: add support to response content_blocks.

### [0.1.7] - 2026-02-13

#### Fixed
- Coding style fixes.

### [0.1.6] - 2026-02-12

#### Changed
- Readme updated.

### [0.1.5] - 2026-02-12

#### Fixed
- _parse_tool_calls() bug.

### [0.1.4] - 2026-02-11

#### Changed
- Unit tests remake.

### [0.1.3] - 2026-02-11

#### Fixed
- with_*() methods support bugs.

### [0.1.2] - 2026-02-10

#### Fixed
- Chat completions structured output bugs.

#### Added
- Structured output examples.

### [0.1.1] - 2026-02-10

#### Fixed
- Streaming custom/values bugs. 
- Async+tool messages Pollinations API compatibility bugs.

#### Added
- Multimodality, streaming and function calling examples.

### [0.1.0] - 2026-02-09

#### Added
- Initial commit with basic functionality.
