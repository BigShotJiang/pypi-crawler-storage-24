# cleanrbx

cleanrbx compares a Rekordbox XML export against a folder on disk and finds files that are no longer referenced by your Rekordbox library.

## Features

- Simulation mode by default (safe preview)
- Optional deletion mode with confirmation
- Path filtering with `--skip`
- Detailed output on screen or in a file
- XML path validation with `--check-xml`
- Interactive folder selection when `--folder` is not provided

## Installation

```bash
pip install cleanrbx
```

## Quick Start

Simulate what would be removed:

```bash
cleanrbx rekordbox.xml
```

Clean a specific folder:

```bash
cleanrbx rekordbox.xml --folder "D:\\Music\\Rekordbox" --clean
```

Skip selected path fragments:

```bash
cleanrbx rekordbox.xml --skip backups,samples
```

Check XML paths that do not exist locally:

```bash
cleanrbx rekordbox.xml --check-xml
```

Show all options:

```bash
cleanrbx --help
```

## Notes

- Streaming URLs in the XML are ignored.
- `--clean` deletes files, so run without it first to review results.
- Back up your library before using deletion mode.
