import argparse
import os
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path
from typing import List
from urllib.parse import unquote

import prompt_toolkit
import prompt_toolkit.completion

from . import __version__

SEP = os.path.sep
AutocompleteDict = dict[str, "AutocompleteDict | None"]


def parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="cleanrbx",
        description=(
            "Deletes files from your Rekordbox folder which are not in the library "
            "based on an exported Rekordbox XML"
        ),
        add_help=True,
    )
    parser.add_argument(
        "rekordbox_xml",
        help="The file name of the XML file from Rekordbox",
    )
    parser.add_argument(
        "-c", "--clean", action="store_true", help="do the cleaning", default=False
    )
    parser.add_argument(
        "-s",
        "--simulate",
        action="store_true",
        help="simulate the cleaning to see what would be deleted (default behaviour)",
        default=True,
    )
    parser.add_argument(
        "-f",
        "--folder",
        "--f",
        dest="folder",
        type=str,
        action="store",
        default=None,
        help=(
            "the folder to clean. If it is not given, the user will be able to set "
            "the common folder based on the XML"
        ),
    )
    parser.add_argument(
        "--skip",
        type=str,
        action="store",
        default=None,
        help=(
            "skip the cleaning for these strings in the folder paths, divided by ',' "
            "(applies to both the local files and the paths in the XML file)"
        ),
    )
    parser.add_argument(
        "--details",
        action="store_true",
        help="show the detailed results (per file) on console instead of a summary",
        default=False,
    )
    parser.add_argument(
        "--details-file",
        action="store_true",
        help=(
            "write the detailed results to a text file: either clean_results_<datetime>.txt "
            "or simulate_results_<datetime>.txt"
        ),
        default=False,
    )
    parser.add_argument(
        "--check-xml",
        action="store_true",
        help="check if the XML has any URLs which does not exist in the filesystem",
        default=False,
    )
    parser.add_argument(
        "-v", "--version", action="version", version=f"%(prog)s {__version__}"
    )
    return parser.parse_args(argv)


def should_skip_path(input_arg: Path | str, skip_list: List[str] | None) -> bool:
    try:
        input_path = Path(input_arg)
    except Exception:
        return True

    parent_str = str(input_path.parent).lower()
    if not skip_list:
        return False

    for skip in skip_list:
        if skip and skip.lower() in parent_str:
            return True
    return False


def get_path_list_from_rekordbox_xml(xml_filename: str) -> List[str]:
    try:
        with open(xml_filename, "r", encoding="utf-8") as rxml:
            xml_tree = ET.parse(rxml)
    except FileNotFoundError:
        print("XML file not found")
        raise SystemExit(1)
    except ET.ParseError:
        print("Invalid XML file")
        raise SystemExit(1)

    xml_tracks = list(xml_tree.iter("TRACK"))
    if not xml_tracks:
        print("No TRACK elements found in the XML file")
        raise SystemExit(1)

    xml_paths: List[str] = []
    for track in xml_tracks:
        location = track.get("Location")
        if location:
            raw_path = unquote(location.replace("file://localhost/", ""))
            if (
                raw_path.startswith("tidal:")
                or raw_path.startswith("soundcloud:")
                or raw_path.startswith("itunes:")
                or raw_path.startswith("beatsource:")
                or raw_path.startswith("beatport:")
            ):
                continue
            xml_paths.append(raw_path.replace("/", SEP))

    return xml_paths


def determine_common_path(paths: List[str]) -> str:
    if not paths:
        return ""
    try:
        return os.path.commonpath(paths)
    except ValueError:
        return ""


def autocomplete_dict(path: Path) -> None | AutocompleteDict:
    iter_dir = [item for item in path.iterdir() if item.is_dir()]
    if len(iter_dir) == 0:
        return None

    folder_dict: AutocompleteDict = {}
    for item in iter_dir:
        try:
            folder_dict[item.name + SEP] = autocomplete_dict(item)
        except PermissionError:
            folder_dict[item.name + SEP] = None
    return folder_dict


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)

    xml_paths = get_path_list_from_rekordbox_xml(args.rekordbox_xml)
    common_path = ""

    if args.folder:
        if not os.path.exists(args.folder):
            print("Error: The given path does not exist. Please enter a valid path.\n")
            return 1
        in_xml = False
        for path in xml_paths:
            if args.folder in path:
                common_path = args.folder
                in_xml = True
                break
        if not in_xml:
            print("Error: There are no files for the given path in the XML.\n")
            return 1

    if common_path == "":
        initial_common_path = determine_common_path(xml_paths)
        try:
            autocomplete_data = autocomplete_dict(Path(initial_common_path))
        except PermissionError:
            print("ERROR: No permission to process common path in XML")
            return 1
        common_path = initial_common_path
        if autocomplete_data is not None:
            print(
                "\nSet the folder you want to clean starting with the common folder for all "
                "the files in the XML file. Press TAB to see the folders on a current level "
                "and SPACE to get to the next level. You can set the path by pressing ENTER.\n"
            )

            completer = prompt_toolkit.completion.NestedCompleter.from_nested_dict(
                autocomplete_data
            )

            while True:
                print("SELECT THE PATH:")
                input_raw = prompt_toolkit.prompt(initial_common_path, completer=completer)
                input_path = input_raw.strip().replace(" ", "")
                common_path = initial_common_path + input_path
                if not os.path.exists(common_path):
                    print("The path does not exist. Please enter a valid path.\n")
                    continue
                print(
                    f"\nThe selected path is\n{common_path}\nIS THE PATH OKAY? (Y)es / (N)o:",
                    end=" ",
                )
                inp = input().lower()
                if inp not in ("y", "n"):
                    print("Please enter 'Y' or 'N' to answer the question:", end=" ")
                elif inp == "y":
                    break

    print(
        f"\nStarting to {'clean' if args.clean else 'simulate cleaning'} from folder {common_path}"
    )
    file_postfix = ""
    if args.details_file:
        file_postfix = datetime.now().strftime("%Y%m%d_%H%M%S")
        print(
            "The details will be written to the following file: "
            f"{'clean' if args.clean else 'simulate'}_details_{file_postfix}.txt"
        )

    if args.clean:
        print(
            "\nWE ARE ABOUT TO DELETE FILES FROM YOUR REKORDBOX LIBRARY! MAKE SURE YOUR LIBRARY "
            "IS BACKED UP\nDo you want to proceed?\n\n(Y)es / (N)o"
        )
        while True:
            inp = input().lower()
            if inp not in ("y", "n"):
                print("Please enter 'Y' or 'N' to answer the question")
            else:
                break
        if inp == "n":
            print("\nOk, bye!")
            return 0

    deleted_files = 0
    deleted_details = (
        "\n\nDeleted files:\n--------------\n"
        if args.clean
        else "\n\nFiles to be deleted:\n--------------------\n"
    )
    skipped_files = 0
    skipped_details = "\n\n\nSkipped files:\n--------------\n"

    skip_list: List[str] | None = None
    if args.skip:
        skip_list = [item.strip() for item in args.skip.split(",") if item.strip()]

    for path in Path(common_path).rglob("*"):
        if not path.is_file():
            continue

        resolved = str(path)
        if should_skip_path(resolved, skip_list):
            skipped_files += 1
            skipped_details += f"\nS: {resolved.replace(common_path, '')}"
            continue

        if resolved not in xml_paths:
            deleted_files += 1
            rel = resolved.replace(common_path, "")
            deleted_details += f"\nD: {rel}  (not listed in Rekordbox XML export)"
            if args.clean:
                path.unlink()

    results = (
        f"\nSUMMARY:\n========\n"
        f"{'Deleted files' if args.clean else 'Files to be deleted'}: {deleted_files}\n"
        f"Skipped files: {skipped_files}\n"
    )

    xml_paths_not_found: List[str] = []
    xml_paths_not_found_details = ""
    if args.check_xml:
        for xml_path in xml_paths:
            if not os.path.exists(xml_path):
                xml_paths_not_found.append(xml_path)
        if len(xml_paths_not_found) > 0:
            results += f"Paths in XML not found: {len(xml_paths_not_found)}"
            if args.details or args.details_file:
                xml_paths_not_found_details += (
                    "\n\n\nPaths in the XML file not found:\n"
                    "---------------------------------\n"
                )
                for notfound in xml_paths_not_found:
                    xml_paths_not_found_details += f"\nX: {notfound}"

    print(results)

    if args.details or args.details_file:
        details = ""
        if deleted_files:
            details += deleted_details
        if skipped_files:
            details += skipped_details
        if args.check_xml and xml_paths_not_found:
            details += xml_paths_not_found_details
        if args.details:
            print(details)
        if args.details_file:
            results += details
            with open(
                f"{'clean' if args.clean else 'simulate'}_details_{file_postfix}.txt",
                "w",
                encoding="utf-8",
            ) as details_file:
                details_file.write(results)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
