# from .gen import linear_regression, logistic_regression
from .ai_helper import ask_llm
from .pink import pink
from .america  import america
from .iran import iran
from .momo import momo

from .koko import koko
from .code import code
from .sf import sf
from .abc import abc
from .liti import liti

__all__ = ["ask_llm", "pink", "america", "iran", "momo", "koko", "code", "sf", "abc", "liti"]