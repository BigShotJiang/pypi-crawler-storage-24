import logging
from dataclasses import dataclass
from typing import Any, Dict, Optional, Protocol

import requests

logger = logging.getLogger(__name__)


class TokenProvider(Protocol):
    """
    Minimal protocol for objects that can provide and refresh an HH OAuth2 access token.

    This matches your existing OrganizationHHAccount usage:
    - get_valid_access_token()
    - refresh_access_token()
    """

    def get_valid_access_token(self) -> str:  # pragma: no cover - protocol definition
        ...

    def refresh_access_token(self) -> str:  # pragma: no cover - protocol definition
        ...


class HHAPIError(ValueError):
    """Domain-specific error raised for HeadHunter API problems."""


@dataclass
class HHAPIClientConfig:
    """
    Configuration for HHAPIClient.

    Attributes:
        base_url: Base API URL (defaults to hh.uz public API).
                  Override this if you need api.hh.ru or a custom endpoint.
        user_agent: User-Agent header to send with requests.
        timeout: Per-request timeout in seconds.
    """

    base_url: str = "https://api.hh.uz"
    user_agent: str = "hh-api-client/0.1.0"
    timeout: int = 30


class HHAPIClient:
    """
    HeadHunter API client for making requests to HH API.

    Features:
    - Works with either:
        * a TokenProvider (recommended; supports automatic refresh), or
        * a raw OAuth2 access_token string.
    - Small typed interface focused on vacancies, employer info, and resumes.
    - No hard dependency on Django; can be used in any Python app.

    The interface is kept compatible with your existing usage
    (organization_hh_account + access_token) so you can drop it into
    your Django project with minimal changes.
    """

    def __init__(
        self,
        organization_hh_account: Optional[TokenProvider] = None,
        access_token: Optional[str] = None,
        organization_id: Optional[int] = None,
        config: Optional[HHAPIClientConfig] = None,
        session: Optional[requests.Session] = None,
    ) -> None:
        """
        Initialize HH API client.

        Args:
            organization_hh_account: Any object implementing TokenProvider
                (e.g. your OrganizationHHAccount model instance).
            access_token: Raw HH OAuth2 access token (fallback if account not provided).
            organization_id: Optional organization identifier for logging/debugging.
            config: Optional HHAPIClientConfig override.
            session: Optional pre-configured requests.Session (useful for testing).
        """
        if organization_hh_account:
            self.organization_hh_account = organization_hh_account
            # Best-effort organization identifier for logging; safe if missing.
            self.organization_id = (
                organization_id
                or getattr(getattr(organization_hh_account, "organization", None), "id", None)
                or getattr(organization_hh_account, "organization_id", None)
            )
            self._access_token: Optional[str] = None
        elif access_token:
            self.organization_hh_account = None
            self.organization_id = organization_id
            self._access_token = access_token
        else:
            raise ValueError("Either organization_hh_account or access_token must be provided")

        self.config = config or HHAPIClientConfig()
        self.base_url = self.config.base_url.rstrip("/")

        self.session = session or requests.Session()
        self.session.headers.update(
            {
                "User-Agent": self.config.user_agent,
                "Content-Type": "application/json",
            }
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _get_access_token(self) -> str:
        """Get a valid access token, refreshing if necessary (via TokenProvider)."""
        if getattr(self, "organization_hh_account", None):
            return self.organization_hh_account.get_valid_access_token()
        if not self._access_token:
            raise HHAPIError("Access token is not set")
        return self._access_token

    def _request(
        self,
        method: str,
        endpoint: str,
        params: Optional[Dict[str, Any]] = None,
        data: Optional[Dict[str, Any]] = None,
        retry_on_401: bool = True,
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """
        Make a request to HH API with automatic token refresh on 401 (if TokenProvider is used).

        Args:
            method: HTTP method (GET, POST, PUT, DELETE).
            endpoint: API endpoint (e.g., '/vacancies').
            params: Query parameters.
            data: JSON body.
            retry_on_401: Whether to retry once after token refresh on 401.

        Returns:
            Parsed JSON response.

        Raises:
            HHAPIError: For HTTP errors or token refresh failures.
            requests.RequestException: For low-level networking errors.
        """
        url = f"{self.base_url}{endpoint}"
        access_token = self._get_access_token()

        headers = kwargs.pop("headers", {}) or {}
        headers["Authorization"] = f"Bearer {access_token}"

        timeout = kwargs.pop("timeout", self.config.timeout)

        try:
            response = self.session.request(
                method,
                url,
                params=params,
                json=data,
                headers=headers,
                timeout=timeout,
                **kwargs,
            )
            response.raise_for_status()
            # HH API always returns JSON on success for documented endpoints.
            return response.json()

        except requests.HTTPError as e:
            # Try to extract HH error payload (never log tokens).
            try:
                hh_error: Any = response.json()
            except Exception:  # noqa: BLE001
                hh_error = response.text

            status_code = response.status_code

            # Handle 401 - try refreshing token once when we have a TokenProvider.
            if (
                status_code == 401
                and retry_on_401
                and getattr(self, "organization_hh_account", None) is not None
            ):
                logger.warning(
                    "HH API 401 for organization %s, attempting token refresh...",
                    self.organization_id,
                )
                try:
                    access_token = self.organization_hh_account.refresh_access_token()
                    headers["Authorization"] = f"Bearer {access_token}"
                    retry_response = self.session.request(
                        method,
                        url,
                        params=params,
                        json=data,
                        headers=headers,
                        timeout=timeout,
                        **kwargs,
                    )
                    retry_response.raise_for_status()
                    return retry_response.json()
                except Exception as refresh_error:  # noqa: BLE001
                    logger.error(
                        "Token refresh failed for organization %s: %s",
                        self.organization_id,
                        refresh_error,
                    )
                    raise HHAPIError(f"Token refresh failed: {refresh_error}") from refresh_error

            error_msg = f"HH API {status_code} Error - Response: {hh_error}"
            logger.error("%s | URL: %s %s", error_msg, method, url)
            raise HHAPIError(error_msg) from e

        except requests.RequestException as e:
            # Network/transport-level errors.
            logger.error("HH API request error: %s %s - %s", method, url, e)
            raise

    # ------------------------------------------------------------------
    # Public high-level methods (kept compatible with your existing usage)
    # ------------------------------------------------------------------
    def get_user_info(self) -> Dict[str, Any]:
        """Get current user information including employer details."""
        return self._request("GET", "/me")

    def get_employer_info(self) -> Dict[str, Any]:
        """
        Get current employer information.

        Returns:
            Employer data including ID, name, and other details.

        Raises:
            HHAPIError: If user is not an employer.
        """
        user_info = self.get_user_info()

        if "employer" not in user_info or not user_info["employer"]:
            raise HHAPIError("User is not associated with an employer account")

        return user_info["employer"]

    def get_managers(self) -> Dict[str, Any]:
        """Get list of managers for the employer account."""
        employer_info = self.get_employer_info()
        employer_id = employer_info.get("id")

        if not employer_id:
            raise HHAPIError("Could not determine employer_id")

        return self._request("GET", f"/employers/{employer_id}/managers")

    def get_default_manager_id(self) -> str:
        """
        Get the default manager ID for vacancy posting.

        Returns:
            Manager ID as string.

        Raises:
            HHAPIError: If no managers found.
        """
        managers_data = self.get_managers()
        managers = managers_data.get("items", [])

        if not managers:
            raise HHAPIError("No managers found for this employer account")

        return str(managers[0]["id"])

    def get_employer_services(self) -> Dict[str, Any]:
        """Get employer's active services and publications."""
        employer_info = self.get_employer_info()
        employer_id = employer_info.get("id")

        if not employer_id:
            raise HHAPIError("Could not determine employer_id")

        return self._request("GET", f"/employers/{employer_id}/services")

    def get_publication_status(self) -> Dict[str, Any]:
        """
        Get detailed publication status for the employer.

        Returns:
            Dict with free/paid publication counts and availability.
        """
        try:
            services = self.get_employer_services()

            free_count = 0
            paid_count = 0

            if "items" in services:
                for service in services["items"]:
                    if service.get("type") == "publication":
                        if service.get("is_free", False):
                            free_count += int(service.get("count", 0) or 0)
                        else:
                            paid_count += int(service.get("count", 0) or 0)

            return {
                "free_publications_available": free_count,
                "paid_publications_available": paid_count,
                "total_publications_available": free_count + paid_count,
                "can_post_free": free_count > 0,
                "can_post_paid": paid_count > 0,
            }
        except Exception as e:  # noqa: BLE001
            logger.warning("Could not fetch publication status: %s", e)
            return {
                "free_publications_available": -1,
                "paid_publications_available": -1,
                "total_publications_available": -1,
                "can_post_free": None,
                "can_post_paid": None,
                "error": str(e),
            }

    def test_connection(self) -> Dict[str, Any]:
        """
        Test the connection to HH API by fetching employer info.

        Returns:
            Dict with success status and employer info or error.
        """
        try:
            employer_info = self.get_employer_info()
            return {
                "success": True,
                "employer_info": employer_info,
                "organization_id": getattr(self, "organization_id", None),
            }
        except Exception as e:  # noqa: BLE001
            return {
                "success": False,
                "error": str(e),
                "organization_id": getattr(self, "organization_id", None),
            }

    # -----------------------------
    # Vacancies
    # -----------------------------
    def create_vacancy(self, vacancy_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new vacancy on HH."""
        return self._request("POST", "/vacancies", data=vacancy_data)

    def update_vacancy(self, vacancy_id: str, vacancy_data: Dict[str, Any]) -> Dict[str, Any]:
        """Update an existing vacancy."""
        return self._request("PUT", f"/vacancies/{vacancy_id}", data=vacancy_data)

    def archive_vacancy(self, vacancy_id: str) -> Dict[str, Any]:
        """Archive (close) a vacancy."""
        return self._request("PUT", f"/vacancies/{vacancy_id}/archive")

    def publish_vacancy(self, vacancy_id: str) -> Dict[str, Any]:
        """Publish a vacancy (make it active)."""
        return self._request("PUT", f"/vacancies/{vacancy_id}/publish")

    def extend_vacancy(self, vacancy_id: str) -> Dict[str, Any]:
        """Extend a vacancy publication period."""
        return self._request("PUT", f"/vacancies/{vacancy_id}/extend")

    def get_vacancy(self, vacancy_id: str) -> Dict[str, Any]:
        """Get vacancy details."""
        return self._request("GET", f"/vacancies/{vacancy_id}")

    def get_vacancies(
        self,
        page: int = 0,
        per_page: int = 20,
        archived: Optional[bool] = None,
    ) -> Dict[str, Any]:
        """Get list of vacancies for the employer."""
        params: Dict[str, Any] = {"page": page, "per_page": min(per_page, 100)}
        if archived is not None:
            params["archived"] = str(archived).lower()
        return self._request("GET", "/vacancies", params=params)

    # -----------------------------
    # Negotiations & candidates
    # -----------------------------
    def get_negotiations(
        self,
        vacancy_id: Optional[str] = None,
        page: int = 0,
        per_page: int = 20,
    ) -> Dict[str, Any]:
        """Get negotiations (applications) for vacancies."""
        params: Dict[str, Any] = {"page": page, "per_page": min(per_page, 100)}
        if vacancy_id:
            params["vacancy_id"] = vacancy_id
        return self._request("GET", "/negotiations", params=params)

    def get_vacancy_candidates(
        self,
        vacancy_id: str,
        page: int = 0,
        per_page: int = 20,
    ) -> Dict[str, Any]:
        """Get candidates for a specific vacancy."""
        params = {"page": page, "per_page": per_page}
        return self._request("GET", f"/vacancies/{vacancy_id}/candidates", params=params)

    # -----------------------------
    # Resumes
    # -----------------------------
    def search_resumes(
        self,
        search_params: Dict[str, Any],
        page: int = 0,
        per_page: int = 20,
    ) -> Dict[str, Any]:
        """Search resumes (requires paid HH subscription)."""
        params = {**search_params, "page": page, "per_page": min(per_page, 100)}
        return self._request("GET", "/resumes", params=params)

    def get_resume(self, resume_id: str) -> Dict[str, Any]:
        """Get resume details (requires paid HH subscription)."""
        return self._request("GET", f"/resumes/{resume_id}")

