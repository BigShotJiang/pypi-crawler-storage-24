Guide
=====

.. include:: ../README.rst
