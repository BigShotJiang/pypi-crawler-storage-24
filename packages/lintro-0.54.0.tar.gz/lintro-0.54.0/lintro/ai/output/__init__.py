"""AI output format modules."""
