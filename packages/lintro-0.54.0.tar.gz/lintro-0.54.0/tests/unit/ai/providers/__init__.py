"""Tests for AI providers."""
