"""Tests for AI exceptions."""

from __future__ import annotations

from assertpy import assert_that

from lintro.ai.exceptions import (
    AIAuthenticationError,
    AIError,
    AINotAvailableError,
    AIProviderError,
    AIRateLimitError,
)
from lintro.exceptions.errors import LintroError


def test_exceptions_hierarchy():
    """Verify all AI exception classes inherit from the correct parent classes."""
    assert_that(AIError("x")).is_instance_of(LintroError)
    assert_that(AINotAvailableError("x")).is_instance_of(AIError)
    assert_that(AIProviderError("x")).is_instance_of(AIError)
    assert_that(AIAuthenticationError("x")).is_instance_of(AIProviderError)
    assert_that(AIRateLimitError("x")).is_instance_of(AIProviderError)
