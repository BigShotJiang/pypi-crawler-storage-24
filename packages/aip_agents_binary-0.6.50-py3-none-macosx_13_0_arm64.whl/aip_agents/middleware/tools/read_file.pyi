from langchain_core.tools import BaseTool
from pydantic import BaseModel, SkipValidation as SkipValidation
from typing import Annotated, Any

READ_FILE_TOOL_DESCRIPTION: str
MAX_READ_FILE_CHARS_HARD_LIMIT: int
MAX_READ_FILE_CHARS_DEFAULT: int
MIN_READ_FILE_CHARS: int
LINE_BASED_RESULT_CHAR_WARN_THRESHOLD = MAX_READ_FILE_CHARS_DEFAULT

class ReadFileInput(BaseModel):
    """Input schema for read_file tool."""
    path: str
    line_offset: int | None
    limit: int | None
    char_offset: int | None
    max_chars: int | None

class ReadFileTool(BaseTool):
    """Tool for reading file contents with optional pagination."""
    name: str
    description: str
    args_schema: type[BaseModel]
    backend: Annotated[Any, SkipValidation]
