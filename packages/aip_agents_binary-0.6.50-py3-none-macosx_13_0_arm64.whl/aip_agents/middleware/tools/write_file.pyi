from langchain_core.tools import BaseTool
from pydantic import BaseModel, SkipValidation as SkipValidation
from typing import Annotated, Any

WRITE_FILE_TOOL_DESCRIPTION: str

class WriteFileInput(BaseModel):
    """Input schema for ``write_file``.

    Attributes:
        path (str): Absolute destination path for the new file.
        content (str): UTF-8 text content to write.
    """
    path: str
    content: str

class WriteFileTool(BaseTool):
    """Create a new file in the configured filesystem backend.

    This tool enforces create-only semantics: if the target path already exists,
    it returns an error instead of overwriting the file.

    Attributes:
        name (str): Tool identifier exposed to the model.
        description (str): Human-readable usage guidance for the model.
        args_schema (type[BaseModel]): Pydantic schema for tool arguments.
        backend (Any): Filesystem backend implementing ``read`` and ``write``.
    """
    name: str
    description: str
    args_schema: type[BaseModel]
    backend: Annotated[Any, None]
