from langchain_core.tools import BaseTool
from pydantic import BaseModel, SkipValidation as SkipValidation
from typing import Annotated, Any

EDIT_FILE_TOOL_DESCRIPTION: str

class EditFileInput(BaseModel):
    """Input schema for edit_file tool."""
    file_path: str
    old_string: str
    new_string: str
    replace_all: bool

class EditFileTool(BaseTool):
    """Tool for performing exact string replacements in existing files."""
    name: str
    description: str
    args_schema: type[BaseModel]
    backend: Annotated[Any, None]
