from _typeshed import Incomplete
from aip_agents.middleware.base import AgentMiddleware as AgentMiddleware, ModelRequest as ModelRequest
from aip_agents.utils.logger import get_logger as get_logger
from langchain_core.tools import BaseTool as BaseTool
from typing import Any

logger: Incomplete

class MiddlewareManager:
    """Orchestrates multiple middleware components and manages hook execution.

    The manager collects tools from all middleware, builds enhanced system prompts,
    and executes lifecycle hooks in the configured order:
    forward for run-level hooks and before/modify model hooks, reverse for after_model.

    Attributes:
        middleware: List of middleware components in registration order.
    """
    middleware: Incomplete
    def __init__(self, middleware: list[AgentMiddleware]) -> None:
        """Initialize the middleware manager.

        Args:
            middleware: List of middleware components to manage. Order matters:
                       hooks execute forward (first to last) for run-level hooks and
                       before/modify model hooks; after_model executes in reverse order.
        """
    def __bool__(self) -> bool:
        """Return True when at least one middleware is configured."""
    def get_all_tools(self) -> list[BaseTool]:
        """Collect tools from all registered middleware.

        Returns:
            Combined list of all tools contributed by all middleware components.
            Empty list if no middleware or if middleware provide no tools.
        """
    def build_system_prompt(self, base_instruction: str) -> str:
        """Build enhanced system prompt by concatenating base instruction with middleware additions.

        Args:
            base_instruction: The base system prompt for the agent.

        Returns:
            Enhanced system prompt with all middleware additions appended.
            If no middleware provide additions, returns base_instruction unchanged.
        """
    def modify_model_request(self, request: ModelRequest, state: dict[str, Any]) -> ModelRequest:
        """Execute modify_model_request hooks for all middleware in forward order.

        Each middleware receives the request modified by previous middleware,
        allowing them to build on each other's changes.

        Args:
            request: The model request to be modified.
            state: Current agent state for context.

        Returns:
            Final modified request after all middleware have processed it.
        """
    def before_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Execute before_model hooks for all middleware in forward order.

        Hooks run first to last, allowing earlier middleware to prepare state
        for later middleware.

        Args:
            state: Current agent state.

        Returns:
            Merged dictionary of all state updates from all middleware.
            Updates are accumulated in order of execution.
        """
    async def abefore_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Asynchronously execute before_model hooks for all middleware."""
    def after_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Execute after_model hooks for all middleware in reverse order.

        Hooks run last to first (reverse of registration order), allowing
        proper cleanup and unwinding of middleware operations.

        Args:
            state: Current agent state after model invocation.

        Returns:
            Merged dictionary of all state updates from all middleware.
            Updates are accumulated in reverse order of execution.
        """
    async def aafter_model(self, state: dict[str, Any]) -> dict[str, Any]:
        """Asynchronously execute after_model hooks for all middleware in reverse order."""
    async def abefore_run(self, state: dict[str, Any], config: dict[str, Any] | None) -> dict[str, Any]:
        """Execute before_run hooks for all middleware in forward order.

        Hooks are optional; only executed if middleware defines them.
        Best-effort execution: exceptions are logged and execution continues.

        Args:
            state: Current agent state.
            config: Optional run configuration dict.

        Returns:
            Merged dictionary of all state updates from all middleware.
        """
    async def aafter_run(self, *, final_state: dict[str, Any], output: str | None, config: dict[str, Any] | None, error: Exception | None) -> None:
        """Execute after_run hooks for all middleware in forward order.

        Hooks are optional; only executed if middleware defines them.
        Best-effort execution: exceptions are logged and execution continues.

        Args:
            final_state: Final agent state after run completion.
            output: The final output string from the agent, or None if failed.
            config: Optional run configuration dict.
            error: Exception if the run failed, None if successful.
        """
    async def aon_final_response(self, content: str, context: dict[str, Any]) -> None:
        """Invoke streaming final-response hooks (best-effort).

        Called when an A2A FINAL_RESPONSE event is captured during streaming.

        Args:
            content: The final response content.
            context: Context dict (thread_id, original_query, memory_user_id, etc.).
        """
