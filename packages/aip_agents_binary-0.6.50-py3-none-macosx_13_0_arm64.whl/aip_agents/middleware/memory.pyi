from _typeshed import Incomplete
from aip_agents.constants import TEXT_PREVIEW_LENGTH as TEXT_PREVIEW_LENGTH
from aip_agents.memory import BaseMemory as BaseMemory
from aip_agents.middleware.base import AgentMiddleware as AgentMiddleware
from aip_agents.tools.memory_search import Mem0DeleteTool as Mem0DeleteTool, Mem0SearchTool as Mem0SearchTool
from aip_agents.utils.logger import get_logger as get_logger
from typing import Any

logger: Incomplete
MAX_QUERY_LENGTH: int
DEFAULT_MEMORY_LIMIT: int
FORGET_WORD_PATTERN: str

class MemoryMiddleware(AgentMiddleware):
    """Middleware for automatic memory recall and persistence.

    This middleware replaces the dedicated memory graph entry node by using
    middleware lifecycle hooks to:
    1. Recall relevant memories before the agent runs (abefore_run hook)
    2. Persist interactions after the agent completes (aafter_run hook)

    The middleware handles memory retrieval logic directly, maintaining backward
    compatibility with existing memory configuration.

    Attributes:
        tools: Empty list - memory middleware doesn't contribute tools.
        system_prompt_additions: None - no prompt additions needed.
    """
    tools: list[Any]
    system_prompt_additions: str | None
    def __init__(self, memory: BaseMemory | None, memory_agent_id: str, save_interaction_to_memory: bool = True, memory_retrieval_limit: int = ...) -> None:
        """Initialize the MemoryMiddleware.

        Args:
            memory: The memory backend instance (Mem0Memory or compatible).
            memory_agent_id: The agent ID used for memory scoping.
            save_interaction_to_memory: Whether to save interactions to memory.
            memory_retrieval_limit: Maximum memories to retrieve per recall.
        """
    @property
    def memory_enabled(self) -> bool:
        """Check whether memory is enabled.

        Returns:
            True when a memory adapter is set.
        """
    async def abefore_run(self, state: dict[str, Any], config: dict[str, Any] | None) -> dict[str, Any]:
        """Execute memory recall before the agent run.

        Extracts the user query from state messages, retrieves relevant memories
        directly using the memory search tool, and enhances the query with
        formatted memory context.

        Args:
            state: Initial agent state containing messages.
            config: Optional run configuration.

        Returns:
            State updates with enhanced message if memories were found.
        """
    async def aafter_run(self, *, final_state: dict[str, Any], output: str | None, config: dict[str, Any] | None, error: Exception | None) -> None:
        """Execute memory persistence after the agent run."""
    async def aon_final_response(self, content: str, context: dict[str, Any]) -> None:
        """Persist memory early during streaming final response (best-effort)."""
