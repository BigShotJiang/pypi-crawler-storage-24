"""Public cross-package integration facade for `glaip-sdk` consumers.

Only the `aip_agents.integration` namespace is part of the boundary contract for
cross-package local-runtime integrations. Deep module paths remain implementation
details and non-contract surfaces, even when the facade re-exports types sourced
from those modules.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

from aip_agents.integration import agent, guardrails, hitl, ptc, skills, storage
from aip_agents.integration.version import (
    CONTRACT_EXPORTS,
    CONTRACT_MODULES,
    CONTRACT_NAMESPACE,
    INTEGRATION_FACADE_MODULES,
    NON_CONTRACT_SURFACE_PATTERNS,
    integration_contract_version,
)

__all__ = [
    "agent",
    "guardrails",
    "hitl",
    "ptc",
    "skills",
    "storage",
    "CONTRACT_EXPORTS",
    "CONTRACT_MODULES",
    "CONTRACT_NAMESPACE",
    "INTEGRATION_FACADE_MODULES",
    "NON_CONTRACT_SURFACE_PATTERNS",
    "integration_contract_version",
]
