"""Public skills contracts for cross-package integrations.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from aip_agents.skills import Skill


_IMPORT_MAP = {
    "Skill": "aip_agents.skills",
}

__all__ = ["Skill"]


def __getattr__(name: str) -> Any:
    """Lazy-load public skills contracts."""
    module_name = _IMPORT_MAP.get(name)
    if module_name is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    module = importlib.import_module(module_name)
    value = getattr(module, name)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    """Return module attributes for dir()."""
    return sorted(__all__)
