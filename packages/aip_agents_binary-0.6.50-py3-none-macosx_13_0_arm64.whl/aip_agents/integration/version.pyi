from _typeshed import Incomplete

__all__ = ['CONTRACT_EXPORTS', 'CONTRACT_MODULES', 'CONTRACT_NAMESPACE', 'INTEGRATION_FACADE_MODULES', 'NON_CONTRACT_SURFACE_PATTERNS', 'integration_contract_version']

CONTRACT_NAMESPACE: str
INTEGRATION_FACADE_MODULES: Incomplete
integration_contract_version: str
CONTRACT_MODULES: Incomplete
CONTRACT_EXPORTS: Incomplete
NON_CONTRACT_SURFACE_PATTERNS: Incomplete
