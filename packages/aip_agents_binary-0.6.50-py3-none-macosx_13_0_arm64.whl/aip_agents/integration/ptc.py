"""Public PTC contracts for cross-package integrations.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING, Any, Protocol

if TYPE_CHECKING:
    from aip_agents.ptc import PromptConfig, PTCCustomToolConfig, PTCSandboxConfig
    from aip_agents.ptc.custom_tools import (
        PTCCustomToolValidationError,
        PTCFileToolDef,
        PTCPackageToolDef,
        PTCToolDef,
        check_name_collisions,
        enrich_tool_def_with_metadata,
        extract_tool_metadata,
        validate_custom_tool_config,
    )
    from aip_agents.ptc.naming import sanitize_function_name
    from aip_agents.ptc.tool_def_helpers import file_tool, package_tool


class PromptBuilderProtocol(Protocol):
    """Callable contract for building PTC usage guidance."""

    def __call__(
        self,
        mcp_client: Any | None = None,
        config: PromptConfig | None = None,
        custom_tools_config: PTCCustomToolConfig | None = None,
    ) -> str:
        """Build a prompt describing the available PTC tool surface."""
        ...


_PTC_MODULE = "aip_agents.ptc"
_PTC_CUSTOM_TOOLS_MODULE = "aip_agents.ptc.custom_tools"
_PTC_NAMING_MODULE = "aip_agents.ptc.naming"

_IMPORT_MAP = {
    "PTCFileToolDef": _PTC_CUSTOM_TOOLS_MODULE,
    "PTCPackageToolDef": _PTC_CUSTOM_TOOLS_MODULE,
    "PTCSandboxConfig": _PTC_MODULE,
    "PTCToolDef": _PTC_CUSTOM_TOOLS_MODULE,
    "PTCCustomToolConfig": _PTC_MODULE,
    "PTCCustomToolValidationError": _PTC_MODULE,
    "PromptConfig": _PTC_MODULE,
    "check_name_collisions": _PTC_CUSTOM_TOOLS_MODULE,
    "enrich_tool_def_with_metadata": _PTC_MODULE,
    "extract_tool_metadata": _PTC_MODULE,
    "file_tool": _PTC_MODULE,
    "package_tool": _PTC_MODULE,
    "sanitize_function_name": _PTC_NAMING_MODULE,
    "validate_custom_tool_config": _PTC_MODULE,
}

__all__ = [
    "PTCFileToolDef",
    "PTCPackageToolDef",
    "PTCSandboxConfig",
    "PTCToolDef",
    "PTCCustomToolConfig",
    "PTCCustomToolValidationError",
    "PromptBuilderProtocol",
    "PromptConfig",
    "check_name_collisions",
    "enrich_tool_def_with_metadata",
    "extract_tool_metadata",
    "file_tool",
    "package_tool",
    "sanitize_function_name",
    "validate_custom_tool_config",
]


def __getattr__(name: str) -> Any:
    """Lazy-load public PTC contracts."""
    module_name = _IMPORT_MAP.get(name)
    if module_name is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    module = importlib.import_module(module_name)
    value = getattr(module, name)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    """Return module attributes for dir()."""
    return sorted(__all__)
