"""Versioned metadata for the public integration facade.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

CONTRACT_NAMESPACE = "aip_agents.integration"

INTEGRATION_FACADE_MODULES = (
    "agent",
    "guardrails",
    "hitl",
    "ptc",
    "skills",
    "storage",
)

integration_contract_version = "v1"

CONTRACT_MODULES = tuple(f"{CONTRACT_NAMESPACE}.{module_name}" for module_name in INTEGRATION_FACADE_MODULES)

CONTRACT_EXPORTS = {
    "agent": (
        "AgentInterface",
        "AgentRunProtocol",
        "LangGraphReactAgent",
    ),
    "guardrails": (
        "GuardrailManager",
        "GuardrailMode",
        "NemoGuardrailEngine",
        "PhraseMatcherEngine",
    ),
    "hitl": (
        "ApprovalDecision",
        "ApprovalDecisionType",
        "ApprovalManager",
        "ApprovalRequest",
        "BasePromptHandler",
        "PromptHandlerProtocol",
    ),
    "ptc": (
        "PTCFileToolDef",
        "PTCPackageToolDef",
        "PTCSandboxConfig",
        "PTCToolDef",
        "PTCCustomToolConfig",
        "PTCCustomToolValidationError",
        "PromptBuilderProtocol",
        "PromptConfig",
        "check_name_collisions",
        "enrich_tool_def_with_metadata",
        "extract_tool_metadata",
        "file_tool",
        "package_tool",
        "sanitize_function_name",
        "validate_custom_tool_config",
    ),
    "skills": ("Skill",),
    "storage": (
        "InMemoryStorageProvider",
        "MinioConfig",
        "MinioObjectStorage",
        "ObjectStorageProvider",
        "StoreOutputParams",
        "ToolOutputConfig",
        "ToolOutputManager",
        "ToolOutputManagerProtocol",
    ),
}

NON_CONTRACT_SURFACE_PATTERNS = (
    "aip_agents.agent.hitl.*",
    "aip_agents.guardrails.engines.*",
    "aip_agents.guardrails.manager",
    "aip_agents.guardrails.schemas",
    "aip_agents.ptc.custom_tools",
    "aip_agents.ptc.naming",
    "aip_agents.ptc.tool_def_helpers",
    "aip_agents.storage.clients.*",
    "aip_agents.storage.providers.*",
    "aip_agents.utils.langgraph.tool_output_management",
)

__all__ = [
    "CONTRACT_EXPORTS",
    "CONTRACT_MODULES",
    "CONTRACT_NAMESPACE",
    "INTEGRATION_FACADE_MODULES",
    "NON_CONTRACT_SURFACE_PATTERNS",
    "integration_contract_version",
]
