from aip_agents.agent.hitl.manager import ApprovalManager as ApprovalManager
from aip_agents.agent.hitl.prompt import BasePromptHandler as BasePromptHandler
from aip_agents.schema.hitl import ApprovalDecision as ApprovalDecision, ApprovalDecisionType as ApprovalDecisionType, ApprovalRequest as ApprovalRequest
from typing import Protocol

__all__ = ['ApprovalDecision', 'ApprovalDecisionType', 'ApprovalManager', 'ApprovalRequest', 'BasePromptHandler', 'PromptHandlerProtocol']

class PromptHandlerProtocol(Protocol):
    """Minimal HITL prompt contract used by SDK-side prompt handlers."""
    def attach_manager(self, manager: ApprovalManager) -> None:
        """Attach the approval manager coordinating the prompt handler."""
    async def prompt_for_decision(self, request: ApprovalRequest, timeout_seconds: int, context_keys: list[str] | None = None) -> ApprovalDecision:
        """Return an approval decision for a pending HITL request."""
