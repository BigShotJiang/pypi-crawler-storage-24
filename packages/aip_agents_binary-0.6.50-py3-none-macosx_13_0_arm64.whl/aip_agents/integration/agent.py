"""Public agent runtime contracts for cross-package integrations.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING, Any, Protocol

if TYPE_CHECKING:
    from aip_agents.agent import AgentInterface, LangGraphReactAgent


class AgentRunProtocol(Protocol):
    """Minimal async agent execution contract used by integration callers."""

    async def arun(self, *args: Any, **kwargs: Any) -> Any:
        """Run the agent and return the final result."""
        raise NotImplementedError  # pragma: no cover

    async def arun_stream(self, *args: Any, **kwargs: Any) -> Any:
        """Run the agent and stream incremental results."""
        raise NotImplementedError  # pragma: no cover

    async def arun_sse_stream(self, *args: Any, **kwargs: Any) -> Any:
        """Run the agent and stream SSE-compatible incremental results."""
        raise NotImplementedError  # pragma: no cover


_IMPORT_MAP = {
    "AgentInterface": "aip_agents.agent",
    "LangGraphReactAgent": "aip_agents.agent",
}

__all__ = [
    "AgentInterface",
    "AgentRunProtocol",
    "LangGraphReactAgent",
]


def __getattr__(name: str) -> Any:
    """Lazy-load public agent contracts."""
    module_name = _IMPORT_MAP.get(name)
    if module_name is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    module = importlib.import_module(module_name)
    value = getattr(module, name)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    """Return module attributes for dir()."""
    return sorted(__all__)
