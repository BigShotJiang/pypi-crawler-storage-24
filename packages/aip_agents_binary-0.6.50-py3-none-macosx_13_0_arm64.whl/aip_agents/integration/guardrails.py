"""Public guardrail contracts for cross-package integrations.

Authors:
    Raymond Christopher (raymond.christopher@gdplabs.id)
"""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from aip_agents.guardrails.engines.nemo import NemoGuardrailEngine
    from aip_agents.guardrails.engines.phrase_matcher import PhraseMatcherEngine
    from aip_agents.guardrails.manager import GuardrailManager
    from aip_agents.guardrails.schemas import GuardrailMode


_GUARDRAILS_MODULE = "aip_agents.guardrails"
_GUARDRAILS_NEMO_MODULE = "aip_agents.guardrails.engines.nemo"
_GUARDRAILS_PHRASE_MATCHER_MODULE = "aip_agents.guardrails.engines.phrase_matcher"

_IMPORT_MAP = {
    "GuardrailManager": _GUARDRAILS_MODULE,
    "GuardrailMode": _GUARDRAILS_MODULE,
    "NemoGuardrailEngine": _GUARDRAILS_NEMO_MODULE,
    "PhraseMatcherEngine": _GUARDRAILS_PHRASE_MATCHER_MODULE,
}

__all__ = [
    "GuardrailManager",
    "GuardrailMode",
    "NemoGuardrailEngine",
    "PhraseMatcherEngine",
]


def __getattr__(name: str) -> Any:
    """Lazy-load public guardrail contracts."""
    module_name = _IMPORT_MAP.get(name)
    if module_name is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

    module = importlib.import_module(module_name)
    value = getattr(module, name)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    """Return module attributes for dir()."""
    return sorted(__all__)
