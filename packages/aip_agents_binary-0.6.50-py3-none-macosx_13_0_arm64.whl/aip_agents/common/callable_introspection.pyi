from typing import Any

def callable_accepts_keyword(target: Any, keyword: str) -> bool:
    """Return whether ``target`` accepts ``keyword`` in its signature."""
