from aip_agents.common.callable_introspection import callable_accepts_keyword as callable_accepts_keyword

__all__ = ['callable_accepts_keyword']
