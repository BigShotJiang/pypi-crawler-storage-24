from aip_agents.agent import LangGraphReactAgent as LangGraphReactAgent
from aip_agents.middleware.backends.in_memory import InMemoryBackend as InMemoryBackend

def create_sample_files(backend: InMemoryBackend) -> None:
    """Create sample files for the agent to read.

    Args:
        backend: The filesystem backend to write files to.
    """
def main() -> None:
    """Run the filesystem hello world example."""
