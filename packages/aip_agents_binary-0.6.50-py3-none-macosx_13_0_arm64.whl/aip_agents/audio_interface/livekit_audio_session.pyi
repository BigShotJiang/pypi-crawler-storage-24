from _typeshed import Incomplete
from aip_agents.audio_interface.audio_agent_adapter import AIPAudioAgentAdapter as AIPAudioAgentAdapter
from aip_agents.audio_interface.config import AudioSessionConfig as AudioSessionConfig, LiveKitConfig as LiveKitConfig
from aip_agents.audio_interface.errors import AudioConfigError as AudioConfigError, AudioSessionUnavailableError as AudioSessionUnavailableError
from aip_agents.utils.logger import get_logger as get_logger
from typing import Any

logger: Incomplete

class LiveKitAudioSession:
    """Manage a LiveKit room connection and stream audio to/from an agent."""
    def __init__(self, config: AudioSessionConfig) -> None:
        """Create a session for the given `AudioSessionConfig`."""
    async def start(self, aip_agent: Any, *, instructions: str) -> None:
        """Connect to LiveKit and start the voice pipeline."""
    async def stop(self) -> None:
        """Stop the session and release LiveKit resources."""
    async def wait_closed(self) -> None:
        """Wait until the LiveKit session signals close."""
