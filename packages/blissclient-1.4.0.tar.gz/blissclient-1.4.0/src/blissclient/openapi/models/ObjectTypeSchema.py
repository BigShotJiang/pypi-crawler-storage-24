from typing import *

from pydantic import BaseModel, Field


class ObjectTypeSchema(BaseModel):
    """
    ObjectTypeSchema model

    """

    model_config = {"populate_by_name": True, "validate_assignment": True}

    callables: Optional[Dict[str, Any]] = Field(
        validation_alias="callables", default=None
    )

    properties: Any = Field(validation_alias="properties")

    properties_ui_meta: dict[str, Any] = Field(
        validation_alias="properties_ui_meta", default_factory=dict
    )

    state_ok: List[str] = Field(validation_alias="state_ok")

    type: str = Field(validation_alias="type")

    super: Optional[str] = Field(validation_alias="super", default=None)
