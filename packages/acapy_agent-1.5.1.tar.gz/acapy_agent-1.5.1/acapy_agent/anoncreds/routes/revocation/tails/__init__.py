"""AnonCreds tails file routes."""
