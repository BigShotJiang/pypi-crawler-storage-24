"""Dreadnode Agent Server.

FastAPI server with REST endpoints and SSE streaming for agent communication.
"""

from __future__ import annotations

import asyncio
import os
import tempfile
import time
import typing as t
from collections import deque
from contextlib import asynccontextmanager, suppress
from dataclasses import dataclass, field
from datetime import datetime, timezone
from functools import cache
from pathlib import Path
from uuid import UUID, uuid4

import uvicorn
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from loguru import logger
from starlette.responses import JSONResponse, StreamingResponse

from dreadnode.app.api.models import (
    CapabilityAgentInfo,
    CapabilityInfo,
    ChatRequest,
    ComponentStatusInfo,
    HealthResponse,
    HumanInputResponse,
    HumanPrompt,
    RuntimeInfoResponse,
    SessionCreateRequest,
    SessionInfo,
    SessionMessage,
    SessionRestoreRequest,
    SessionRestoreResponse,
    SkillContentResponse,
    SkillsResponse,
    ToolInfo,
    ToolsResponse,
)
from dreadnode.app.api.models import (
    SkillInfo as SkillInfoModel,
)
from dreadnode.app.server.auth import SandboxAuthMiddleware
from dreadnode.app.server.utils import safe_json_dumps
from dreadnode.tracing.span import bind_session_id

if t.TYPE_CHECKING:
    from dreadnode.agents import Agent
    from dreadnode.agents.events import AgentEvent
    from dreadnode.capabilities.capability import Capability
    from dreadnode.capabilities.types import AgentDef
    from dreadnode.generators.generator import Generator
    from dreadnode.generators.message import Message
    from dreadnode.storage import SessionRecord, SessionStore

EventPayload = dict[str, t.Any]
_TERMINAL_CHAT_EVENT_TYPES = frozenset({"agentend", "error"})
DEFAULT_MODEL = "anthropic/claude-sonnet-4-20250514"
_DREADNODE_LLM_BASE_ENV = "DREADNODE_LLM_BASE"
_DREADNODE_LLM_API_KEY_ENV = "DREADNODE_LLM_API_KEY"


def _log_chat_timing(session_id: str, stage: str, started_at: float) -> None:
    """Emit a coarse timing marker for chat turn diagnostics."""
    elapsed_ms = round((time.perf_counter() - started_at) * 1000)
    logger.debug("Chat timing session={} stage={} elapsed_ms={}", session_id, stage, elapsed_ms)


@dataclass(frozen=True, slots=True)
class TurnModelConfig:
    """Canonical and execution-time model config for a single chat turn."""

    canonical_model: str
    generator_model: str
    api_base: str | None = None
    api_key: str | None = None

    @property
    def is_platform_proxy(self) -> bool:
        return self.canonical_model.startswith("dn/")


def _resolve_canonical_turn_model(
    requested_model: str | None,
    remembered_model: str | None,
    agent_def: AgentDef | None,
) -> str:
    """Resolve the canonical model id for a turn.

    Priority: user-selected model > session model > agent-defined model.
    The agent's model acts as a fallback, not an override — the user's
    choice in the UI / TUI always wins when present.
    """
    if requested_model:
        return requested_model
    if remembered_model:
        return remembered_model
    if agent_def and agent_def.model and agent_def.model != "inherit":
        return agent_def.model
    agent_name = agent_def.name if agent_def else "default"
    raise ValueError(
        f"Agent '{agent_name}' does not define a model. Pass one explicitly before running a turn."
    )


def _resolve_turn_model_config(
    requested_model: str | None,
    remembered_model: str | None,
    agent_def: AgentDef | None,
) -> TurnModelConfig:
    """Resolve canonical and execution-time model config for a turn."""
    canonical_model = _resolve_canonical_turn_model(requested_model, remembered_model, agent_def)
    if canonical_model.startswith("dn/"):
        api_base = os.environ.get(_DREADNODE_LLM_BASE_ENV, "").strip() or None
        api_key = os.environ.get(_DREADNODE_LLM_API_KEY_ENV, "").strip() or None
        return TurnModelConfig(
            canonical_model=canonical_model,
            generator_model=canonical_model,
            api_base=api_base,
            api_key=api_key,
        )
    return TurnModelConfig(
        canonical_model=canonical_model,
        generator_model=canonical_model,
    )


def _validate_model_environment(config: TurnModelConfig) -> str | None:
    """Return a clean error message if required env vars are missing, else None."""
    if config.is_platform_proxy:
        missing: list[str] = []
        if not config.api_base:
            missing.append(_DREADNODE_LLM_BASE_ENV)
        if not config.api_key:
            missing.append(_DREADNODE_LLM_API_KEY_ENV)
        if missing:
            keys = ", ".join(missing)
            return f"Missing proxy configuration — set {keys} to use {config.canonical_model}"
        return None

    model = config.generator_model
    if isinstance(model, str):
        try:
            from litellm import validate_environment

            result = validate_environment(model)
            if not result.get("keys_in_environment"):
                missing = result.get("missing_keys", [])
                keys = ", ".join(missing) if missing else "the required API key"
                return f"Missing API key — set {keys} to use {model}"
        except Exception:
            return None
    return None


@dataclass(slots=True)
class CapabilityRegistry:
    """Registry of capabilities available to the local server."""

    capabilities: dict[str, Capability] = field(default_factory=dict)
    disabled_local: dict[str, Capability] = field(default_factory=dict)
    default_capability_name: str | None = None
    mcp_manager: MCPLifecycleManager | None = None
    runtime_bindings: list[dict[str, t.Any]] = field(default_factory=list)
    load_failures: list[dict[str, t.Any]] = field(default_factory=list)
    local_capability_records: dict[str, dict[str, t.Any]] = field(default_factory=dict)
    _skills_cache: list[t.Any] | None = field(default=None, init=False, repr=False)

    def get(self, name: str | None) -> Capability | None:
        if not name:
            return None
        return self.capabilities.get(name)

    def default(self) -> Capability | None:
        if self.default_capability_name:
            return self.capabilities.get(self.default_capability_name)
        if self.capabilities:
            return next(iter(self.capabilities.values()))
        return None

    def resolve(
        self,
        *,
        capability_name: str | None = None,
        agent_name: str | None = None,
    ) -> tuple[str | None, Capability | None, AgentDef | None]:
        """Resolve a capability + agent pair for a new session."""
        if capability_name:
            capability = self.get(capability_name)
            if capability is None:
                raise ValueError(f"Unknown capability: {capability_name}")

            if agent_name:
                agent_def = next(
                    (agent for agent in capability.agents if agent.name == agent_name), None
                )
                if agent_def is None:
                    raise ValueError(
                        f"Agent '{agent_name}' is not defined in capability '{capability_name}'"
                    )
                return capability_name, capability, agent_def

            agent_def = capability.agents[0] if capability.agents else None
            if agent_def is None:
                raise ValueError(f"Capability '{capability_name}' does not define an entry agent")
            return capability_name, capability, agent_def

        if agent_name:
            matches = [
                (loaded_capability_name, capability, agent_def)
                for loaded_capability_name, capability in self.capabilities.items()
                for agent_def in capability.agents
                if agent_def.name == agent_name
            ]
            if len(matches) == 1:
                return matches[0]
            if len(matches) > 1:
                matched_capabilities = ", ".join(
                    sorted(capability_name for capability_name, _, _ in matches)
                )
                raise ValueError(
                    f"Agent '{agent_name}' is defined in multiple capabilities: "
                    f"{matched_capabilities}. Choose a capability explicitly."
                )
            logger.warning(
                "Requested agent '{}' was not found in loaded capabilities; "
                "falling back to the default capability",
                agent_name,
            )

        capability = self.default()
        if capability is None:
            return None, None, None
        capability_name = self.default_capability_name
        if capability_name is None and self.capabilities:
            capability_name = next(iter(self.capabilities))
        agent_def = capability.agents[0] if capability.agents else None
        return capability_name, capability, agent_def

    def all_tools(self) -> list[t.Any]:
        """All tools from all capabilities + MCP servers, deduped by name."""
        seen: set[str] = set()
        tools: list[t.Any] = []
        # Python tools first
        for cap in self.capabilities.values():
            for tool in cap.tools:
                name = _tool_name(tool)
                if name and name not in seen:
                    tools.append(tool)
                    seen.add(name)
                elif name in seen:
                    logger.debug(
                        "Tool '{}' already registered, skipping duplicate",
                        name,
                    )
        # MCP tools
        if self.mcp_manager:
            for tool in self.mcp_manager.all_tools():
                name = _tool_name(tool)
                if name and name not in seen:
                    tools.append(tool)
                    seen.add(name)
                elif name in seen:
                    logger.debug("Tool '{}' already registered (MCP), skipping", name)
        return tools

    def all_skills(self) -> list[t.Any]:
        """Discover skills from all capabilities' skills_paths, deduped by name.

        Last-wins: if two capabilities define a skill with the same name,
        the later capability's version is used and the earlier one gets a
        degraded component health entry.

        Results are cached for the lifetime of this registry instance.
        """
        if self._skills_cache is not None:
            return self._skills_cache

        from dreadnode.agents.skills import Skill, discover_skills

        # Track which capability provided each skill
        skill_map: dict[str, tuple[str, Skill]] = {}  # name -> (cap_name, skill)
        for cap_name, cap in self.capabilities.items():
            for skills_path in cap.skills_paths or []:
                for skill in discover_skills(skills_path):
                    if skill.name in skill_map:
                        prev_cap_name, _ = skill_map[skill.name]
                        # Only record cross-capability collisions
                        if prev_cap_name != cap_name:
                            logger.warning(
                                "Skill '{}' from '{}' overrides same-named skill from '{}'",
                                skill.name,
                                cap_name,
                                prev_cap_name,
                            )
                            # Record degraded health on the overridden capability
                            prev_cap = self.capabilities.get(prev_cap_name)
                            if prev_cap is not None:
                                health = getattr(prev_cap, "component_health", None)
                                if health is not None:
                                    detail = f"Overridden by same-named skill from '{cap_name}'"
                                    # Update existing entry rather than appending a duplicate
                                    for entry in health:
                                        if (
                                            isinstance(entry, dict)
                                            and entry.get("kind") == "skill"
                                            and entry.get("name") == skill.name
                                        ):
                                            entry["status"] = "degraded"
                                            entry["detail"] = detail
                                            break
                                    else:
                                        health.append(
                                            {
                                                "kind": "skill",
                                                "name": skill.name,
                                                "status": "degraded",
                                                "error": None,
                                                "detail": detail,
                                            }
                                        )
                    skill_map[skill.name] = (cap_name, skill)

        self._skills_cache = [skill for _, skill in skill_map.values()]
        return self._skills_cache

    def find_agent(self, agent_name: str) -> tuple[str, t.Any, AgentDef] | None:
        """Find an agent by name across all capabilities.

        Returns (capability_name, capability, agent_def) or None.
        """
        for cap_name, cap in self.capabilities.items():
            for agent_def in cap.agents:
                if agent_def.name == agent_name:
                    return (cap_name, cap, agent_def)
        return None

    def to_runtime_info(self, *, working_dir: Path) -> RuntimeInfoResponse:
        """Serialize registry state for CLI/runtime introspection (CAP-LOAD-022)."""
        from dreadnode.capabilities.sync import bare_capability_name

        def _provenance_for(*, bare_name: str, source: str) -> str | None:
            if source == "runtime":
                return None
            record = self.local_capability_records.get(bare_name, {})
            persisted = record.get("source")
            if persisted in {"org", "public"}:
                return t.cast("str", persisted)
            return "local"

        def _display_identity(
            *,
            bare_name: str,
            source: str,
            binding: dict[str, t.Any] | None = None,
        ) -> tuple[str, str | None]:
            canonical_name = None
            if binding is not None:
                binding_name = binding.get("capability_name")
                if isinstance(binding_name, str) and binding_name.strip():
                    canonical_name = binding_name
            if canonical_name is not None:
                return canonical_name, canonical_name
            if source in {"local", "package"}:
                record = self.local_capability_records.get(bare_name, {})
                artifact_identity = record.get("artifact_identity")
                if isinstance(artifact_identity, str) and artifact_identity.strip():
                    return bare_name, artifact_identity
                return bare_name, None
            return f"{source}/{bare_name}", None

        def _capability_metadata(
            capability: t.Any,
        ) -> tuple[str | None, dict[str, t.Any] | None, str | None, dict[str, t.Any] | None]:
            contract = getattr(capability, "contract", None)
            description = getattr(capability, "description", None)
            if description is None and contract is not None:
                description = getattr(contract, "description", None)

            author = getattr(capability, "author", None)
            if author is None and contract is not None:
                author = getattr(contract, "author", None)

            license_name = getattr(capability, "license", None)
            if license_name is None and contract is not None:
                license_name = getattr(contract, "license", None)

            origin = getattr(capability, "origin", None)
            if origin is None and contract is not None:
                repository = getattr(contract, "repository", None)
                if isinstance(repository, str) and repository.strip():
                    origin = {"type": "repository", "url": repository}

            return description, author, license_name, origin

        capabilities_out: list[CapabilityInfo] = []

        # Build binding lookup: bare_name -> binding dict
        binding_by_bare: dict[str, dict[str, t.Any]] = {}
        for binding in self.runtime_bindings:
            bare = bare_capability_name(binding.get("capability_name", ""))
            binding_by_bare[bare] = binding

        # 1. Effective capabilities
        for name, capability in self.capabilities.items():
            source = getattr(capability, "source", "local")
            version = getattr(capability, "version", None)
            health = getattr(capability, "component_health", [])

            # Match binding by bare name
            binding = binding_by_bare.pop(name, None)
            binding_id = binding.get("id") if binding else None
            display_name, canonical_name = _display_identity(
                bare_name=name,
                source=source,
                binding=binding,
            )
            description, author, license_name, origin = _capability_metadata(capability)

            capabilities_out.append(
                CapabilityInfo(
                    name=name,
                    display_name=display_name,
                    canonical_name=canonical_name,
                    source=source,
                    provenance=_provenance_for(bare_name=name, source=source),
                    version=version,
                    description=description,
                    author=author,
                    license=license_name,
                    origin=origin,
                    enabled=True,
                    binding_id=binding_id,
                    components=[ComponentStatusInfo(**entry) for entry in health],
                    entry_agent=None,
                    skills_paths=[
                        str(p)
                        for p in (
                            capability.skills_paths
                            or ([] if capability.skills_path is None else [capability.skills_path])
                        )
                    ],
                    agents=[
                        CapabilityAgentInfo(
                            name=a.name,
                            description=a.description,
                            model=a.model,
                            capability=name,
                        )
                        for a in capability.agents
                    ],
                )
            )

        # 2. Disabled workspace bindings (remaining in binding_by_bare after effective caps consumed theirs)
        for bare, binding in binding_by_bare.items():
            if not binding.get("enabled", True):
                display_name, canonical_name = _display_identity(
                    bare_name=bare,
                    source="runtime",
                    binding=binding,
                )
                capabilities_out.append(
                    CapabilityInfo(
                        name=bare,
                        display_name=display_name,
                        canonical_name=canonical_name,
                        source="runtime",
                        provenance=None,
                        version=binding.get("version"),
                        enabled=False,
                        binding_id=binding.get("id"),
                        components=[],
                    )
                )

        # 3. Disabled local capabilities
        for name, capability in self.disabled_local.items():
            source = getattr(capability, "source", "local")
            version = getattr(capability, "version", None)
            display_name, canonical_name = _display_identity(
                bare_name=name,
                source=source,
                binding=None,
            )
            description, author, license_name, origin = _capability_metadata(capability)
            capabilities_out.append(
                CapabilityInfo(
                    name=name,
                    display_name=display_name,
                    canonical_name=canonical_name,
                    source=source,
                    provenance=_provenance_for(bare_name=name, source=source),
                    version=version,
                    description=description,
                    author=author,
                    license=license_name,
                    origin=origin,
                    enabled=False,
                    components=[],
                )
            )

        # 4. Load failures
        for failure in self.load_failures:
            name = failure.get("name", "unknown")
            display_name, canonical_name = _display_identity(
                bare_name=name,
                source="local",
                binding=None,
            )
            capabilities_out.append(
                CapabilityInfo(
                    name=name,
                    display_name=display_name,
                    canonical_name=canonical_name,
                    source="local",
                    provenance=_provenance_for(bare_name=name, source="local"),
                    enabled=True,
                    components=[
                        ComponentStatusInfo(
                            kind="capability",
                            name=name,
                            status="error",
                            error=failure.get("error"),
                            detail="Check capability.yaml format and directory structure",
                        )
                    ],
                )
            )

        runtime_id = os.environ.get("DREADNODE_RUNTIME_ID", "").strip() or None
        host = "sandbox" if runtime_id else "local"
        from dreadnode.version import VERSION

        return RuntimeInfoResponse(
            runtime_id=runtime_id,
            host_type=host,
            version=VERSION,
            working_dir=str(working_dir),
            default_capability=self.default_capability_name,
            capabilities=capabilities_out,
        )


@dataclass
class MCPLifecycleManager:
    """Manages MCP server connections for all capabilities.

    Owns connect/disconnect lifecycle. Tools from connected servers
    are exposed via all_tools().
    """

    _clients: dict[str, t.Any] = field(default_factory=dict)

    async def start(self, registry: CapabilityRegistry) -> None:
        """Connect to all MCP servers from all capabilities (CAP-MCP-007: best-effort)."""
        from dreadnode.agents.mcp.client import MCPClient

        for cap in registry.capabilities.values():
            cap_health = getattr(cap, "component_health", None)

            for server_def in cap.mcp_server_defs:
                qualified = f"{cap.name}:{server_def.name}"
                try:
                    config = server_def.to_server_config()
                    client = MCPClient.from_config(config)
                    await client.connect()
                    self._clients[qualified] = client
                    logger.info("MCP server connected: {}", qualified)
                except Exception as exc:
                    logger.warning(
                        "MCP server '%s' failed to start — skipping",
                        qualified,
                        exc_info=True,
                    )
                    # Update component_health entry for this server
                    if cap_health is not None:
                        for entry in cap_health:
                            if (
                                entry.get("kind") == "mcp_server"
                                and entry.get("name") == server_def.name
                            ):
                                entry["status"] = "error"
                                entry["error"] = str(exc)
                                entry["detail"] = (
                                    "Check server command/URL and authentication credentials"
                                )
                                break

    async def stop(self) -> None:
        """Disconnect all MCP servers."""
        for name, client in self._clients.items():
            await self._disconnect_client(name, client)
        self._clients.clear()

    async def _disconnect_client(self, name: str, client: t.Any) -> None:
        """Disconnect one MCP client without interrupting the rest."""
        try:
            await client.disconnect()
        except Exception:
            logger.opt(exception=True).warning("Error disconnecting MCP server '{}'", name)

    def all_tools(self) -> list[t.Any]:
        """Collect tools from all connected MCP servers."""
        tools: list[t.Any] = []
        for client in self._clients.values():
            tools.extend(client.tools)
        return tools


def _format_session_binding(
    capability_name: str | None,
    agent_name: str | None,
) -> str:
    """Render a human-readable capability/agent binding."""
    parts: list[str] = []
    if capability_name:
        parts.append(f"capability '{capability_name}'")
    if agent_name:
        parts.append(f"agent '{agent_name}'")
    return " / ".join(parts) if parts else "the default runtime"


def _resolve_turn_model(
    requested_model: str | None,
    remembered_model: str | None,
    agent_def: AgentDef | None,
) -> str:
    """Resolve the canonical model id to use for a turn."""
    return _resolve_turn_model_config(requested_model, remembered_model, agent_def).canonical_model


def _tool_name(tool: t.Any) -> str:
    """Get the name of a tool object."""
    return getattr(tool, "name", "")


def _hook_name(hook: t.Any) -> str:
    """Get the canonical name of a hook object."""
    return getattr(hook, "__name__", getattr(hook, "name", ""))


def _make_agent_link_tool(
    *,
    model: str | Generator | None,
    capability: Capability,
    target_agent: AgentDef,
    extra_tools: list[t.Any] | None,
    kind: str,
) -> t.Any:
    """Create a synthetic tool that delegates work to another capability agent."""
    from dreadnode.agents.tools import Tool

    async def _link_tool(task: str) -> str:
        delegated_agent = create_agent(
            model,
            capability=capability,
            agent_def=target_agent,
            extra_tools=extra_tools,
            system_prompt_append=get_state().system_prompt_append,
        )
        return await delegated_agent.chat(task)  # ty: ignore[unresolved-attribute] - .chat() is on ChatAgent subclass

    _link_tool.__name__ = f"{kind}_to_{target_agent.name}"
    description = (
        f"{kind.title()} work to the '{target_agent.name}' agent in capability "
        f"'{getattr(capability, 'name', 'unknown')}'."
    )
    return Tool.from_callable(_link_tool, description=description)


@cache
def _get_core_system_prompt() -> str:
    """Read the core system prompt, cached after first load."""
    prompt_path = Path(__file__).parent / "system-prompt.md"
    return prompt_path.read_text().strip() if prompt_path.exists() else ""


def _final_assistant_message(trajectory: t.Any) -> str:
    """Extract the last assistant message text from a trajectory."""
    for message in reversed(trajectory.messages):
        if getattr(message, "role", None) == "assistant":
            content = getattr(message, "content", "")
            if isinstance(content, str):
                return content
            if isinstance(content, list):
                texts = [
                    block.get("text", "") if isinstance(block, dict) else str(block)
                    for block in content
                ]
                return "".join(texts)
    return ""


def create_agent(
    model: str | Generator,
    *,
    capability: Capability | None = None,
    agent_def: AgentDef | None = None,
    extra_tools: list[t.Any] | None = None,
    system_prompt_append: str | None = None,
) -> Agent:
    """Create an agent from a loaded capability.

    Tool assembly order:
    1. Inherent tools (from default_tools()) — always present
    2. Extra tools (from global capability pool) — additive, skip duplicates
    3. Agent tool rules filter the combined pool (empty rules = all tools)
    """
    from dreadnode.agents import Agent
    from dreadnode.capabilities.tool_rules import filter_tools
    from dreadnode.tools import default_tools

    if not model or model == "inherit":
        raise ValueError(
            f"Agent '{agent_def.name if agent_def else 'dreadnode-agent'}' does not define a model"
        )

    working_dir = Path.cwd()
    home_dir = Path.home()
    context = f"\nYour working directory is {working_dir}.\nYour home directory is {home_dir}.\n"

    # System prompt: agent_def overrides core prompt; capability prompt layers on top
    core_prompt = _get_core_system_prompt()
    agent_prompt = agent_def.system_prompt if agent_def and agent_def.system_prompt else ""
    base_prompt = agent_prompt or core_prompt
    instructions = base_prompt + context
    capability_system_prompt = (
        _read_capability_system_prompt(capability.path) if capability is not None else ""
    )
    if capability_system_prompt:
        instructions = instructions + "\n" + capability_system_prompt

    # Append CLI --system-prompt content as the final layer
    if system_prompt_append:
        instructions = instructions + "\n\n" + system_prompt_append

    # 1. Inherent tools — always present
    base = default_tools()

    pool: list[t.Any] = list(base.values())
    pool_names = set(base.keys())

    # 2. Extra tools from global capability pool — skip duplicates
    for tool in extra_tools or []:
        name = _tool_name(tool)
        if name and name not in pool_names:
            pool.append(tool)
            pool_names.add(name)

    if capability is not None and agent_def is not None:
        links = getattr(capability, "links", []) or []
        target_agents = {
            candidate.name: candidate for candidate in getattr(capability, "agents", [])
        }
        for link in links:
            if getattr(link, "source", None) != agent_def.name:
                continue
            if getattr(link, "kind", None) not in {"delegate", "subagent"}:
                continue
            target_name = getattr(link, "target", None)
            if not target_name:
                continue
            target_agent = target_agents.get(target_name)
            if target_agent is None:
                logger.warning(
                    f"Capability link target '{target_name}' not found for agent '{agent_def.name}'"
                )
                continue

            tool = _make_agent_link_tool(
                model=model,
                capability=capability,
                target_agent=target_agent,
                extra_tools=extra_tools,
                kind=link.kind,
            )
            name = _tool_name(tool)
            if name and name not in pool_names:
                pool.append(tool)
                pool_names.add(name)

    # 3. Apply agent's tool rules (empty dict = all tools pass)
    rules = agent_def.tools if agent_def else {}
    tools = filter_tools(pool, rules, name_fn=_tool_name)

    # Core hooks — always present
    from dreadnode.agents.hooks import default_hooks

    hooks = default_hooks()
    hook_names = {_hook_name(hook) for hook in hooks}

    if capability is not None and agent_def is not None:
        requested_hooks = set(getattr(agent_def, "hooks", []) or [])
        available_hooks = getattr(capability, "hooks", []) or []
        for hook in available_hooks:
            name = _hook_name(hook)
            if name and name in requested_hooks and name not in hook_names:
                hooks.append(hook)
                hook_names.add(name)

    return Agent(
        name=agent_def.name if agent_def else "dreadnode-agent",
        model=model,
        instructions=instructions,
        tools=tools,
        hooks=hooks,
        max_steps=500,
    )


@dataclass(slots=True)
class QueuedChatRequest:
    """Single chat turn waiting to be processed for a session."""

    message: str
    model: str | None
    agent: str | None
    reset: bool
    event_queue: asyncio.Queue[EventPayload | None]
    generate_params_extra: dict[str, t.Any] | None = None
    queued_at_monotonic: float = field(default_factory=time.perf_counter)


# =============================================================================
# FastAPI Application
# =============================================================================


def _warm_litellm() -> None:
    """Import litellm so the first chat turn doesn't pay the cold-import cost.

    litellm eagerly loads ~2200 modules and makes a network call to fetch
    model pricing on first import.  We skip the network call (the runtime
    doesn't need fresh pricing — cost tracking lives on the platform API)
    and run this at startup in a thread to shift the cost out of the
    user-visible request path.
    """
    _t0 = time.perf_counter()
    try:
        # Skip the httpx.get() to GitHub for model pricing on import.
        os.environ.setdefault("LITELLM_LOCAL_MODEL_COST_MAP", "True")
        import litellm
        import litellm.exceptions  # noqa: F401 - warm submodule import

        elapsed = round((time.perf_counter() - _t0) * 1000)
        logger.info("litellm warmed in {}ms", elapsed)
    except Exception:
        elapsed = round((time.perf_counter() - _t0) * 1000)
        logger.debug("litellm warm failed after {}ms", elapsed)


@asynccontextmanager
async def _lifespan(_app_instance: t.Any) -> t.AsyncIterator[None]:
    """FastAPI lifespan: populate registry + start MCP servers on startup.

    Registry population is done here (rather than only in ``run_server()``)
    so that uvicorn ``--reload`` and externalized uvicorn invocations work:
    on reload the module is reimported and ``app.state`` is fresh, so the
    lifespan re-discovers capabilities automatically.
    """
    from dreadnode import _get_default_instance

    state = get_state()

    # Populate registry if not already done (supports both direct and reload paths).
    # When run_server() is used, it populates before uvicorn starts and we skip.
    # When uvicorn is invoked directly (e.g. from Docker provider), we populate here.
    if state.capability_registry is None:
        instance = _get_default_instance()
        if not instance._initialized:
            instance.configure()
        await asyncio.to_thread(_populate_registry, instance)

    registry = state.capability_registry
    if registry and registry.mcp_manager is None:
        registry.mcp_manager = MCPLifecycleManager()
    if registry and registry.mcp_manager:
        await registry.mcp_manager.start(registry)

    # Warm litellm in a background thread — don't await, so the health
    # endpoint goes live immediately.  The ~2s import finishes before the
    # first chat request arrives (user still has to pass the frontend
    # health-check round-trip + type/send their message).
    asyncio.get_running_loop().run_in_executor(None, _warm_litellm)

    yield
    if registry and registry.mcp_manager:
        await registry.mcp_manager.stop()


app = FastAPI(
    title="Dreadnode Agent Server",
    description="REST + SSE server for Dreadnode agents",
    version="1.0.0",
    lifespan=_lifespan,
)

# CORS must be at module level so it survives uvicorn --reload (module reimport).
app.add_middleware(
    CORSMiddleware,
    allow_origin_regex=r".*",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.add_middleware(SandboxAuthMiddleware)


class ServerState:
    """Server state container stored on app.state."""

    def __init__(self) -> None:
        self.capability_registry: CapabilityRegistry | None = None
        self._sessions: dict[str, SessionRuntime] = {}
        # CLI overrides — sticky across /reload
        self.capability_dirs: list[str] | None = None
        self.enabled_capabilities: list[str] | None = None
        self.system_prompt_append: str | None = None

    def _get_session_store(self) -> SessionStore | None:
        try:
            from dreadnode import _get_default_instance
            from dreadnode.storage import SessionStore

            storage = _get_default_instance().storage
            session_store = getattr(storage, "session_store", None)
            return session_store if isinstance(session_store, SessionStore) else None
        except Exception:
            logger.debug("Session store unavailable", exc_info=True)
            return None

    def _resolve_persisted_binding(
        self,
        capability_name: str | None,
        agent_name: str | None,
    ) -> tuple[str | None, Capability | None, AgentDef | None]:
        if self.capability_registry is None:
            return capability_name, None, None

        if capability_name or agent_name:
            try:
                return self.capability_registry.resolve(
                    capability_name=capability_name,
                    agent_name=agent_name,
                )
            except ValueError:
                logger.warning(
                    "Persisted session binding could not be fully resolved: capability={} agent={}",
                    capability_name,
                    agent_name,
                )

        capability = self.capability_registry.get(capability_name) if capability_name else None
        agent_def = None

        if capability is not None and agent_name is not None:
            agent_def = next(
                (agent for agent in capability.agents if agent.name == agent_name), None
            )
        elif capability is None and agent_name is not None:
            found = self.capability_registry.find_agent(agent_name)
            if found is not None:
                return found

        return capability_name, capability, agent_def

    def _session_info_from_record(
        self, record: SessionRecord, preview: str | None = None
    ) -> SessionInfo:
        session_dir: str | None = None
        try:
            from dreadnode import _get_default_instance

            session_dir = str(_get_default_instance().storage.session_path(record.session_id))
        except Exception:
            logger.debug("Session directory unavailable", exc_info=True)

        return SessionInfo(
            session_id=record.session_id,
            project=record.project,
            created_at=record.created_at,
            message_count=record.message_count,
            session_dir=session_dir,
            capability=record.capability,
            agent=record.agent,
            title=record.title,
            preview=preview,
        )

    def _hydrate_session_record(self, record: SessionRecord) -> SessionRuntime:
        capability_name, capability_obj, agent_def = self._resolve_persisted_binding(
            record.capability,
            record.agent,
        )
        session = SessionRuntime(
            record.session_id,
            model=record.model,
            project=record.project,
            registry=self.capability_registry,
            capability_name=capability_name or record.capability,
            capability=capability_obj,
            agent_def=agent_def,
        )
        session.created_at = record.created_at
        session.title = record.title
        session._message_count = record.message_count
        session._last_turn_agent = record.agent
        if agent_def is None and record.agent is not None:
            session._agent_name_override = record.agent
        if record.trajectory is not None:
            session.restore_trajectory(record.trajectory, persist=False)
        session.persist_manifest()
        self._sessions[record.session_id] = session
        return session

    def get_session(self, session_id: str) -> SessionRuntime | None:
        """Get a session by ID."""
        session = self._sessions.get(session_id)
        if session is not None:
            return session

        session_store = self._get_session_store()
        if session_store is None:
            return None

        record = session_store.get_session(session_id)
        if record is None:
            return None

        return self._hydrate_session_record(record)

    def has_session(self, session_id: str) -> bool:
        """Check if a session exists."""
        return session_id in self._sessions

    def list_sessions(self) -> list[SessionRuntime]:
        """List all sessions."""
        return list(self._sessions.values())

    def list_session_infos(self) -> list[SessionInfo]:
        """List active sessions plus persisted sessions known to the session store."""
        sessions = {session.session_id: session.to_info() for session in self._sessions.values()}
        session_store = self._get_session_store()
        if session_store is not None:
            stored_records = session_store.list_sessions()
            # Only need previews for sessions not already in memory
            store_only_ids = [r.session_id for r in stored_records if r.session_id not in sessions]
            previews = session_store.first_user_messages(store_only_ids) if store_only_ids else {}
            for record in stored_records:
                sessions.setdefault(
                    record.session_id,
                    self._session_info_from_record(record, preview=previews.get(record.session_id)),
                )
        return sorted(sessions.values(), key=lambda session: session.created_at, reverse=True)

    def create_session(
        self,
        *,
        session_id: str | None = None,
        model: str | None = None,
        project: str | None = None,
        capability: str | None = None,
        agent: str | None = None,
        messages: list[SessionMessage] | None = None,
    ) -> SessionRuntime:
        """Create a new session or return an existing compatible one."""
        if session_id is not None and not session_id:
            raise ValueError("session_id must be a non-empty string")
        resolved_id = session_id or str(uuid4())

        if resolved_id in self._sessions:
            session = self._sessions[resolved_id]
            if agent is not None and session.agent_name is not None and agent != session.agent_name:
                raise ValueError(
                    f"Session '{resolved_id}' already started with agent '{session.agent_name}'. "
                    f"Create a new session to start with agent '{agent}'."
                )
            if model is not None and model != session.model:
                session.model = model
                session._persist_state(update_messages=False)
            return session

        session_store = self._get_session_store()
        if session_store is not None:
            record = session_store.get_session(resolved_id)
            if record is not None:
                if agent is not None and record.agent is not None and agent != record.agent:
                    raise ValueError(
                        f"Session '{resolved_id}' already started with agent '{record.agent}'. "
                        f"Create a new session to start with agent '{agent}'."
                    )
                session = self._hydrate_session_record(record)
                if model is not None and model != session.model:
                    session.model = model
                    session._persist_state(update_messages=False)
                return session

        if self.capability_registry is not None and (capability is not None or agent is not None):
            capability_name, capability_obj, agent_def = self.capability_registry.resolve(
                capability_name=capability,
                agent_name=agent,
            )
        else:
            capability_name, capability_obj, agent_def = (None, None, None)

        session = SessionRuntime(
            resolved_id,
            model=model,
            project=project,
            registry=self.capability_registry,
            capability_name=capability_name,
            capability=capability_obj,
            agent_def=agent_def,
        )
        self._sessions[resolved_id] = session
        if messages:
            session.restore_messages(messages, model=model)
        else:
            session._persist_state(update_messages=False)

        # Best-effort registration with platform
        _register_session_with_platform(session, bootstrap_model=model)

        # Eagerly create the agent so first chat doesn't pay tool-assembly cost
        try:
            session.get_agent(model=model)
        except Exception:
            logger.debug("Eager agent creation deferred", exc_info=True)

        return session

    def delete_session(self, session_id: str) -> bool:
        """Delete a session. Returns True if deleted, False if not found."""
        deleted = False
        session = self._sessions.pop(session_id, None)
        if session is not None:
            session.close()
            deleted = True

        session_store = self._get_session_store()
        if session_store is not None:
            deleted = session_store.delete_session(session_id) or deleted

        return deleted


def _is_sandbox_mode() -> bool:
    """True when running inside a platform sandbox (not local TUI)."""
    return bool(os.environ.get("DREADNODE_RUNTIME_ID", "").strip())


def _register_session_with_platform(
    session: SessionRuntime, *, bootstrap_model: str | None = None
) -> None:
    """Best-effort registration of a new session with the platform API.

    Fire-and-forget: logs warnings on failure but never raises.
    Only runs in sandbox mode — local TUI sessions skip platform sync.
    """
    if not _is_sandbox_mode():
        return

    try:
        from dreadnode import _get_default_instance

        instance = _get_default_instance()
        if not instance.can_sync:
            logger.debug("Session registration skipped: can_sync=False")
            return

        api = instance.api
        org = instance.organization
        ws = instance.workspace

        if not isinstance(org, str) or not isinstance(ws, str):
            logger.debug("Session registration skipped: org={!r}, ws={!r}", org, ws)
            return

        project_key = session.project_key
        if project_key is None:
            default_project_key = getattr(instance, "project", None)
            if isinstance(default_project_key, str):
                project_key = default_project_key

        project_id: str | None = None
        active_session = getattr(instance, "session", None)
        active_project = getattr(active_session, "project", None)
        active_project_id = getattr(active_project, "id", None)
        active_project_key = getattr(active_project, "key", None)
        if (
            project_key
            and active_project_id is not None
            and (active_project_key is None or active_project_key == project_key)
        ):
            project_id = str(active_project_id)
        elif project_key:
            project = api.get_project(org, ws, project_key)
            project_id = str(project.id)

        api.save_session(
            org,
            ws,
            session.session_id,
            _resolve_turn_model_config(
                bootstrap_model,
                session.model,
                session._agent_def,
            ).canonical_model,
            agent=session.agent_name,
            title=session.title,
            message_count=session.message_count,
            project_id=project_id,
        )
        session._platform_registered = True
    except Exception:
        logger.opt(exception=True).warning("Failed to register session with platform")


def _sync_accepted_turn_with_platform(
    session: SessionRuntime,
    *,
    model: str | None = None,
    agent: str | None = None,
) -> None:
    """Best-effort sync of the accepted turn snapshot to platform storage."""
    if not _is_sandbox_mode():
        return

    if model is None and agent is None:
        return

    try:
        # Lazy registration: if the session wasn't registered during creation
        # (e.g. because the Dreadnode instance wasn't fully configured yet),
        # register it now before attempting the update.
        if not session._platform_registered:
            _register_session_with_platform(session, bootstrap_model=model or session.model)
            if not session._platform_registered:
                return  # Still can't register — give up silently

        from dreadnode import _get_default_instance

        instance = _get_default_instance()

        if not instance.can_sync:
            return

        org = instance.organization
        ws = instance.workspace
        if not isinstance(org, str) or not isinstance(ws, str):
            return

        instance.api.update_session(
            org,
            ws,
            session.session_id,
            model=model,
            agent=agent,
        )
    except Exception:
        logger.opt(exception=True).warning("Failed to sync accepted turn with platform")


def get_state() -> ServerState:
    """Get the server state from app.state."""
    if not hasattr(app.state, "server"):
        app.state.server = ServerState()
    return app.state.server


# =============================================================================
# Session Runtime
# =============================================================================


class SessionRuntime:
    """Encapsulates the runtime state for a single persisted session."""

    def __init__(
        self,
        session_id: str,
        *,
        model: str | None = None,
        project: str | None = None,
        registry: CapabilityRegistry | None = None,
        capability_name: str | None = None,
        capability: Capability | None = None,
        agent_def: AgentDef | None = None,
    ) -> None:
        self.session_id = session_id
        self.model = model or ""
        self.project_key = project
        self.created_at = datetime.now(timezone.utc)
        self.title: str | None = None

        self._agent: Agent | None = None
        self._session_dir: Path | None = None
        self._queue: deque[QueuedChatRequest] = deque()
        self._queue_lock = asyncio.Lock()
        self._processing_task: asyncio.Task[None] | None = None
        self._registry = registry
        self._capability_name = capability_name
        self._capability = capability
        self._agent_def = agent_def
        self._generate_params_extra: dict[str, t.Any] = {}
        self._message_count: int = 0
        self._agent_name_override: str | None = None
        self._last_turn_agent: str | None = None
        # Session owns the trajectory — agents are ephemeral
        from dreadnode.agents.trajectory import Trajectory as TrajectoryModel

        self._trajectory = TrajectoryModel()

        # Permission handling
        self._pending_permissions: dict[str, asyncio.Event] = {}
        self._permission_decisions: dict[str, str] = {}
        self._session_allowlist: set[str] = set()

        # Compaction state
        self._compacting: bool = False

        # Platform sync
        self._platform_registered: bool = False

        # Human prompt handling
        self._pending_human_prompts: dict[str, HumanPrompt] = {}
        self._pending_human_inputs: dict[str, asyncio.Future[HumanInputResponse]] = {}
        self._resolved_human_inputs: dict[str, HumanInputResponse] = {}

    @property
    def _storage(self) -> t.Any:
        from dreadnode import _get_default_instance

        return _get_default_instance().storage

    @property
    def manifest_file(self) -> Path:
        """Path to the minimal session manifest."""
        return self._storage.session_runtime_path(self.session_id, ext="json")

    @property
    def capability_name(self) -> str | None:
        """Name of the capability bound to this session."""
        return self._capability_name

    @property
    def agent_name(self) -> str | None:
        """Name of the agent last used in this session."""
        if self._last_turn_agent is not None:
            return self._last_turn_agent
        return self._agent_def.name if self._agent_def else self._agent_name_override

    @property
    def _session_store(self) -> SessionStore | None:
        try:
            from dreadnode.storage import SessionStore

            session_store = getattr(self._storage, "session_store", None)
            return session_store if isinstance(session_store, SessionStore) else None
        except Exception:
            logger.debug("Session store unavailable", exc_info=True)
            return None

    def _agent_def_for_turn(self, agent_name: str | None = None) -> AgentDef | None:
        """Resolve the agent definition that will handle a turn."""
        agent_def = self._agent_def
        if agent_name and self._registry is not None:
            _, _, agent_def = self._registry.resolve(agent_name=agent_name)
        return agent_def

    def is_compatible(self) -> bool:
        """Check whether the session can be reused.

        Sessions are no longer scoped to a single capability — all
        capability tools are globally visible via the registry.
        """
        return True

    def _ensure_session_dir(self) -> Path:
        """Create and return the session directory."""
        if self._session_dir is None:
            self._session_dir = self._storage.session_path(self.session_id)
            self._session_dir.mkdir(parents=True, exist_ok=True)
        return self._session_dir

    def _create_agent(
        self,
        *,
        model: str | None = None,
        agent_name: str | None = None,
        generate_params_extra: dict[str, t.Any] | None = None,
    ) -> Agent:
        """Create a fresh agent for this turn.

        Agents are ephemeral — created per-turn with current params.
        Trajectory lives on the session, not the agent.
        """
        self._ensure_session_dir()
        capability = self._capability
        agent_def = self._agent_def_for_turn(agent_name)
        if agent_name and self._registry is not None:
            _, capability, _ = self._registry.resolve(agent_name=agent_name)
        extra_tools = self._registry.all_tools() if self._registry else []

        model_config = _resolve_turn_model_config(model, self.model, agent_def)
        effective_model: str | Generator = model_config.generator_model
        if model_config.is_platform_proxy:
            from dreadnode.generators.generator import GenerateParams, get_generator

            generator = get_generator(
                model_config.generator_model,
                params=GenerateParams(
                    api_base=model_config.api_base,
                    extra={"custom_llm_provider": "openai"},
                ),
            )
            generator.api_key = model_config.api_key
            effective_model = generator

        agent = create_agent(
            effective_model,
            capability=capability,
            agent_def=agent_def,
            extra_tools=extra_tools,
            system_prompt_append=get_state().system_prompt_append,
        )

        self._wire_server_tools(agent)

        # Apply generate_params_extra (per-message overrides session default)
        effective_extra = generate_params_extra or self._generate_params_extra
        if effective_extra:
            agent.generate_params_extra = dict(effective_extra)

        return agent

    def get_agent(self, *, model: str | None = None) -> Agent:
        """Get or create agent (backward compat for restore paths).

        For chat turns, use _create_agent() which creates fresh agents.
        """
        if self._agent is None:
            self._agent = self._create_agent(model=model)
        return self._agent

    def _wire_server_tools(self, agent: Agent) -> None:
        """Add tools that need server context to an already-created agent."""
        from dreadnode.agents.subagent import create_subagent_tool

        agent.tools.append(create_subagent_tool(agent))

        # Skills — pooled from all capabilities, or standalone capability
        all_skills: list = []
        if self._registry:
            all_skills = self._registry.all_skills()
        elif self._capability:
            from dreadnode.agents.skills import discover_skills

            for skills_path in getattr(self._capability, "skills_paths", None) or []:
                all_skills.extend(discover_skills(skills_path))

        if all_skills:
            from dreadnode.agents.skills import create_skill_tool

            agent.tools.append(create_skill_tool(all_skills))

        # Trajectory search (requires storage)
        try:
            from dreadnode.tools.trajectory_search import TrajectorySearch

            storage = self._storage
            if storage is not None:
                agent.tools.append(TrajectorySearch(storage=storage))
        except Exception:
            logger.debug("TrajectorySearch not available", exc_info=True)

    @property
    def trajectory(self) -> t.Any:
        """Get session trajectory (owned by session, not agent)."""
        return self._trajectory

    @property
    def message_count(self) -> int:
        """Number of completed chat turns."""
        return self._message_count

    @property
    def is_busy(self) -> bool:
        """Whether the session has an active turn or compaction in progress."""
        task_running = self._processing_task is not None and not self._processing_task.done()
        return task_running or self._compacting

    @staticmethod
    def _is_compaction_react(event: AgentEvent) -> bool:
        """Check if an event is a ReactStep whose Retry carries a compaction marker."""
        from dreadnode.agents.events import ReactStep
        from dreadnode.agents.reactions import Retry

        if not isinstance(event, ReactStep) or not isinstance(event.reaction, Retry):
            return False
        if not event.reaction.messages:
            return False
        return any(m.metadata.get("compaction") for m in event.reaction.messages)

    @staticmethod
    def _extract_compaction_trigger(event: AgentEvent) -> str:
        """Extract the compaction trigger from a ReactStep's Retry messages."""
        from dreadnode.agents.events import ReactStep
        from dreadnode.agents.reactions import Retry

        if (
            isinstance(event, ReactStep)
            and isinstance(event.reaction, Retry)
            and event.reaction.messages
        ):
            for m in event.reaction.messages:
                trigger = m.metadata.get("trigger")
                if m.metadata.get("compaction") and isinstance(trigger, str):
                    return trigger
        return "threshold"

    async def compact_session(
        self,
        *,
        trigger: str = "manual",
        guidance: str = "",
    ) -> dict[str, t.Any]:
        """Compact the session conversation history.

        Summarizes older messages while preserving a recent protected window.
        Uses the same model resolution as normal turns.

        Returns:
            Structured result with ``status`` (completed/skipped/failed),
            ``messages_before``, ``messages_after``, and optional ``reason``.
        """
        if self.is_busy:
            reason = "already_in_progress" if self._compacting else "turn_in_progress"
            return {"status": "skipped", "reason": reason}

        self._compacting = True
        try:
            return await self._do_compact(trigger=trigger, guidance=guidance)
        except Exception as exc:
            logger.exception("Compaction failed for session {}", self.session_id)
            return {"status": "failed", "reason": str(exc)}
        finally:
            self._compacting = False

    async def _do_compact(
        self,
        *,
        trigger: str,
        guidance: str,
    ) -> dict[str, t.Any]:
        """Internal compaction implementation."""
        from dreadnode.agents.hooks import find_summarization_boundary, summarize_conversation

        # Resolve model the same way turns do, including proxy setup (CMP-SUM-004)
        agent_def = self._agent_def_for_turn()
        model_config = _resolve_turn_model_config(None, self.model, agent_def)
        if not model_config.canonical_model:
            return {"status": "failed", "reason": "no_model_configured"}

        # Build a configured generator for proxy models, same as _create_agent
        summarizer_model: str | Generator = model_config.generator_model
        if model_config.is_platform_proxy:
            from dreadnode.generators.generator import GenerateParams, get_generator

            gen = get_generator(
                model_config.generator_model,
                params=GenerateParams(
                    api_base=model_config.api_base,
                    extra={"custom_llm_provider": "openai"},
                ),
            )
            gen.api_key = model_config.api_key
            summarizer_model = gen

        messages = self._trajectory.messages
        messages_before = len(messages)

        # Pop system message if present
        work_messages = list(messages)
        if work_messages and work_messages[0].role == "system":
            work_messages.pop(0)

        if len(work_messages) <= 6:
            return {"status": "skipped", "reason": "insufficient_messages"}

        boundary = find_summarization_boundary(work_messages, min_messages_to_keep=6)
        if boundary == 0:
            return {"status": "skipped", "reason": "no_valid_boundary"}

        to_summarize = work_messages[:boundary]
        to_keep = work_messages[boundary:]

        # Check for prior compaction marker to incorporate (CMP-SUM-006)
        summarize_input = "\n".join(str(msg) for msg in to_summarize)
        prior_markers = [m for m in to_summarize if m.metadata and m.metadata.get("compaction")]
        if prior_markers:
            summarize_input = (
                "IMPORTANT: The conversation below contains a prior compaction summary. "
                "Incorporate, update, and extend it rather than regenerating context from scratch.\n\n"
                + summarize_input
            )

        summary = await summarize_conversation.bind(summarizer_model)(  # ty: ignore[unresolved-attribute]
            summarize_input,
            guidance=guidance,
        )

        # Build compaction marker message (CMP-PERS-001)
        from dreadnode.generators.message import make_compaction_message

        summary_message = make_compaction_message(
            summary.summary,
            messages_compacted=len(to_summarize),
            trigger=trigger,
        )

        # Rebuild trajectory preserving event types (avoid trajectory_from_openai_format)
        self._rebuild_compacted_trajectory(summary_message, to_keep)

        self._persist_state()

        messages_after = len(self._trajectory.messages)
        return {
            "status": "completed",
            "messages_before": messages_before,
            "messages_after": messages_after,
        }

    def _rebuild_compacted_trajectory(
        self,
        summary_message: Message,
        kept_messages: list[Message],
    ) -> None:
        """Replace trajectory with compaction summary + events for kept messages.

        Uses UUID-based event mapping to preserve original event types
        (GenerationStep, ToolStep, etc.) rather than flattening to generic AgentSteps.
        """
        from dreadnode.agents.events import AgentStep, GenerationStep
        from dreadnode.agents.trajectory import Trajectory
        from dreadnode.generators.generator import Usage

        kept_msg_uuids = {m.uuid for m in kept_messages}

        # Find events that produced any kept message
        kept_events: list[AgentEvent] = [
            event
            for event in self._trajectory.events
            if isinstance(event, AgentStep)
            and hasattr(event, "messages")
            and any(m.uuid in kept_msg_uuids for m in event.messages)
        ]

        # Synthetic step for the compaction summary
        step_kwargs: dict[str, t.Any] = {
            "step": 0,
            "messages": [summary_message],
            "usage": Usage(input_tokens=0, output_tokens=0, total_tokens=0),
        }
        if self._trajectory.agent_id is not None:
            step_kwargs["agent_id"] = self._trajectory.agent_id
        compaction_step = GenerationStep(**step_kwargs)

        self._trajectory = Trajectory(
            session_id=self._trajectory.session_id,
            agent_id=self._trajectory.agent_id,
            system_prompt=self._trajectory.system_prompt,
            events=[compaction_step, *kept_events],
        )

    def _persist_state(self, *, update_messages: bool = True) -> None:
        """Persist the canonical session snapshot and searchable messages."""
        self.persist_manifest()
        session_store = self._session_store
        if session_store is None:
            return

        trajectory = self._trajectory.to_dict() if self._trajectory is not None else None
        messages = None
        if update_messages and self._trajectory is not None:
            messages = self._trajectory.messages
        session_store.persist_session(
            session_id=self.session_id,
            model=self.model,
            project=self.project_key,
            capability=self.capability_name,
            agent=self.agent_name,
            title=self.title,
            created_at=self.created_at,
            message_count=self.message_count,
            trajectory=trajectory,
            messages=messages,
        )

    def reset(self, *, persist: bool = True) -> None:
        """Reset the conversation history."""
        from dreadnode.agents.trajectory import Trajectory as TrajectoryModel

        self._trajectory = TrajectoryModel()
        self._message_count = 0
        self._agent = None
        if persist:
            self._persist_state()

    def restore_messages(
        self,
        messages: list[SessionMessage],
        *,
        model: str | None = None,
        persist: bool = True,
    ) -> None:
        """Seed the session agent trajectory from a simple message list."""
        from dreadnode.agents.trajectory import trajectory_from_openai_format

        if not messages:
            if model is not None:
                self.model = model
                if persist:
                    self._persist_state(update_messages=False)
            return

        if model is not None:
            self.model = model
        trajectory = trajectory_from_openai_format(
            [
                {
                    "role": message.role,
                    "content": message.content,
                }
                for message in messages
            ]
        )
        with suppress(ValueError):
            trajectory.session_id = UUID(self.session_id)
        self._trajectory = trajectory
        self._agent = None  # Clear so next turn creates fresh
        if persist:
            self._persist_state()

    def restore_trajectory(
        self,
        trajectory_data: dict[str, t.Any],
        *,
        model: str | None = None,
        persist: bool = True,
    ) -> None:
        """Restore the session agent from a serialized trajectory."""
        from dreadnode.agents.trajectory import Trajectory as TrajectoryModel

        if model is not None:
            self.model = model
        trajectory = TrajectoryModel.from_dict(trajectory_data)
        with suppress(ValueError):
            trajectory.session_id = UUID(self.session_id)
        self._trajectory = trajectory
        self._agent = None
        if persist:
            self._persist_state()

    def resolve_permission(self, request_id: str, decision: str) -> None:
        """Resolve a pending permission request with a user decision."""
        self._permission_decisions[request_id] = decision
        if decision == "allow_session":
            # Store the tool name for auto-approval
            self._session_allowlist.add(request_id)
        event = self._pending_permissions.get(request_id)
        if event is not None:
            event.set()

    def register_human_prompt(self, prompt: HumanPrompt) -> asyncio.Future[HumanInputResponse]:
        """Register a pending human prompt and return its response future."""
        existing = self._pending_human_inputs.get(prompt.request_id)
        if existing is not None:
            return existing
        loop = asyncio.get_running_loop()
        future: asyncio.Future[HumanInputResponse] = loop.create_future()
        self._pending_human_prompts[prompt.request_id] = prompt
        self._pending_human_inputs[prompt.request_id] = future
        return future

    def resolve_human_input_response(self, response: HumanInputResponse) -> bool:
        """Resolve a pending human prompt response. Returns True if applied."""
        request_id = response.request_id
        if request_id in self._resolved_human_inputs:
            return True
        future = self._pending_human_inputs.pop(request_id, None)
        self._pending_human_prompts.pop(request_id, None)
        if future is None:
            return False
        if not future.done():
            future.set_result(response)
        self._resolved_human_inputs[request_id] = response
        return True

    def resolve_human_response(self, response: HumanInputResponse) -> bool:
        """Resolve a human response against prompts or permissions."""
        if self.resolve_human_input_response(response):
            return True
        if response.action in {"approve", "deny", "allow_session"} and (
            response.request_id in self._pending_permissions
        ):
            decision_map = {
                "approve": "allow",
                "deny": "deny",
                "allow_session": "allow_session",
            }
            self.resolve_permission(response.request_id, decision_map[response.action])
            return True
        return False

    def close(self) -> None:
        """Stop any background processing associated with this session."""
        if self._processing_task is not None and not self._processing_task.done():
            self._processing_task.cancel()

    def persist_manifest(self) -> None:
        """Persist minimal runtime metadata needed to rebind the session."""
        self._ensure_session_dir()

        data: dict[str, t.Any] = {
            "session_id": self.session_id,
            "project": self.project_key,
            "created_at": self.created_at.isoformat(),
        }
        if self.capability_name is not None:
            data["capability"] = self.capability_name
        if self.agent_name is not None:
            data["agent"] = self.agent_name

        target = self.manifest_file
        fd, tmp = tempfile.mkstemp(dir=target.parent, suffix=".tmp")
        closed = False
        try:
            os.write(fd, safe_json_dumps(data).encode())
            os.fsync(fd)
            os.close(fd)
            closed = True
            Path(tmp).replace(target)
        except BaseException:
            if not closed:
                os.close(fd)
            Path(tmp).unlink(missing_ok=True)
            raise

    async def enqueue_chat(
        self,
        message: str,
        *,
        model: str | None = None,
        agent: str | None = None,
        reset: bool = False,
        generate_params_extra: dict[str, t.Any] | None = None,
    ) -> asyncio.Queue[EventPayload | None]:
        """Queue a chat turn and ensure the session processor is running."""
        event_queue: asyncio.Queue[EventPayload | None] = asyncio.Queue()
        request = QueuedChatRequest(
            message=message,
            model=model,
            agent=agent,
            reset=reset,
            event_queue=event_queue,
            generate_params_extra=generate_params_extra,
        )

        async with self._queue_lock:
            self._queue.append(request)
            task_running = self._processing_task is not None and not self._processing_task.done()
            if not task_running:
                self._processing_task = asyncio.create_task(self._process_queue())
            else:
                logger.debug(
                    "Session {}: queued message (task still running, queue={})",
                    self.session_id[:8],
                    len(self._queue),
                )

        return event_queue

    async def _process_queue(self) -> None:
        """Process queued chat turns sequentially for this session."""
        while True:
            async with self._queue_lock:
                if not self._queue:
                    self._processing_task = None
                    return
                request = self._queue.popleft()

            logger.debug(
                "Session {}: processing chat (message={}...)",
                self.session_id[:8],
                request.message[:40],
            )
            _log_chat_timing(self.session_id, "processor_start", request.queued_at_monotonic)

            try:
                if request.model is not None and request.model != self.model:
                    self.model = request.model
                    self._persist_state(update_messages=False)

                # Fresh agent per turn — reads current params
                model_config = _resolve_turn_model_config(
                    request.model,
                    self.model,
                    self._agent_def_for_turn(request.agent),
                )
                _log_chat_timing(
                    self.session_id,
                    "model_config_resolved",
                    request.queued_at_monotonic,
                )
                validation_error = _validate_model_environment(model_config)
                if validation_error:
                    await request.event_queue.put(
                        {
                            "type": "generationerror",
                            "data": {
                                "error": validation_error,
                                "error_type": "AuthenticationError",
                            },
                        }
                    )
                    continue

                agent = self._create_agent(
                    model=request.model,
                    agent_name=request.agent,
                    generate_params_extra=request.generate_params_extra,
                )
                _log_chat_timing(self.session_id, "agent_created", request.queued_at_monotonic)

                from dreadnode.tools.interaction import (
                    reset_human_prompt_handler,
                    set_human_prompt_handler,
                )

                _log_chat_timing(
                    self.session_id,
                    "interaction_handlers_ready",
                    request.queued_at_monotonic,
                )

                async def _human_prompt_handler(
                    prompt: HumanPrompt,
                    event_queue: asyncio.Queue[EventPayload | None] = request.event_queue,
                ) -> HumanInputResponse:
                    future = self.register_human_prompt(prompt)
                    await event_queue.put(
                        {
                            "type": "userinputrequired",
                            "data": prompt.model_dump(),
                        }
                    )
                    return await future

                token = set_human_prompt_handler(_human_prompt_handler)
                turn_was_compacted = False
                try:
                    with bind_session_id(self.session_id):
                        # Session owns the trajectory — agent operates on it directly
                        async with agent.stream(
                            request.message,
                            reset=request.reset,
                            trajectory=self._trajectory,
                        ) as stream:
                            _log_chat_timing(
                                self.session_id,
                                "agent_stream_opened",
                                request.queued_at_monotonic,
                            )
                            async for event in stream:
                                event_dict = event.as_dict()
                                # Detect auto-compaction: a ReactStep whose Retry
                                # carries a message with compaction metadata.
                                if not turn_was_compacted and self._is_compaction_react(event):
                                    turn_was_compacted = True
                                    from dreadnode.agents.events import CompactionEvent

                                    trigger = self._extract_compaction_trigger(event)
                                    ce = CompactionEvent(
                                        trigger=trigger,
                                        compaction_status="completed",
                                    )
                                    await request.event_queue.put(ce.as_dict())
                                await request.event_queue.put(event_dict)
                finally:
                    reset_human_prompt_handler(token)

                self._last_turn_agent = request.agent
                self._message_count += 1

                # Clear cached agent so restore paths create fresh
                self._agent = None
                self._persist_state()
            except Exception as exc:
                logger.exception("Error during chat for session {}", self.session_id)
                await request.event_queue.put({"type": "error", "error": str(exc)})
            finally:
                logger.debug("Session {}: chat turn complete", self.session_id[:8])
                _log_chat_timing(self.session_id, "processor_complete", request.queued_at_monotonic)
                await request.event_queue.put(None)

    def _first_user_preview(self, max_len: int = 200) -> str | None:
        """Extract preview text from the first user message in the trajectory."""
        for msg in self._trajectory.messages:
            if getattr(msg, "role", None) == "user":
                content = getattr(msg, "content", "")
                if isinstance(content, str):
                    text = content.strip().replace("\n", " ")
                    if len(text) > max_len:
                        return text[: max_len - 1] + "\u2026"
                    return text or None
        return None

    def to_info(self) -> SessionInfo:
        """Convert to SessionInfo for API responses."""
        return SessionInfo(
            session_id=self.session_id,
            project=self.project_key,
            created_at=self.created_at,
            message_count=self.message_count,
            session_dir=str(self._session_dir) if self._session_dir else None,
            capability=self.capability_name,
            agent=self.agent_name,
            title=self.title,
            preview=self._first_user_preview(),
        )


# =============================================================================
# Routes
# =============================================================================


@app.get("/api/sessions", response_model=list[SessionInfo])
async def list_sessions() -> list[SessionInfo]:
    """List all active agent sessions."""
    return get_state().list_session_infos()


@app.post("/api/sessions", response_model=SessionInfo)
async def create_session(request: SessionCreateRequest) -> SessionInfo:
    """Create or resolve a capability-bound session runtime."""
    try:
        session = get_state().create_session(
            session_id=request.session_id,
            model=request.model,
            project=request.project,
            capability=request.capability,
            agent=request.agent,
            messages=request.messages,
        )
    except ValueError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc
    return session.to_info()


@app.post("/api/sessions/{session_id}/restore", response_model=SessionRestoreResponse)
async def restore_session(
    session_id: str,
    request: SessionRestoreRequest,
) -> SessionRestoreResponse:
    """Restore a bound session runtime from saved messages or trajectory data."""
    try:
        session = get_state().create_session(
            session_id=session_id,
            model=request.model,
            project=request.project,
            capability=request.capability,
            agent=request.agent,
        )
        if request.trajectory is not None:
            session.restore_trajectory(request.trajectory, model=request.model)
        elif request.messages:
            session.restore_messages(request.messages, model=request.model)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    step_count = len(session.trajectory.steps) if session.trajectory is not None else 0
    return SessionRestoreResponse(
        session_id=session.session_id,
        message_count=session.message_count,
        step_count=step_count,
        capability=session.capability_name,
        agent=session.agent_name,
        project=session.project_key,
    )


@app.get("/api/sessions/{session_id}", response_model=SessionInfo)
async def get_session(session_id: str) -> SessionInfo:
    """Get information about a specific session."""
    session = get_state().get_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail=f"Session not found: {session_id}")
    return session.to_info()


@app.get("/api/sessions/{session_id}/messages")
async def get_session_messages(session_id: str) -> JSONResponse:
    """Return the conversation messages for a session."""
    session = get_state().get_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail=f"Session not found: {session_id}")
    messages = session._trajectory.messages if session._trajectory is not None else []
    return JSONResponse(
        content=[
            {
                "role": msg.role,
                "content": msg.content or "",
                "metadata": msg.metadata or None,
                "tool_call_id": msg.tool_call_id,
            }
            for msg in messages
        ]
    )


@app.delete("/api/sessions/{session_id}")
async def delete_session(session_id: str) -> JSONResponse:
    """Delete an agent session."""
    if not get_state().delete_session(session_id):
        raise HTTPException(status_code=404, detail=f"Session not found: {session_id}")
    return JSONResponse(content={"status": "deleted", "session_id": session_id})


@app.post("/api/chat", response_model=None)
async def chat_endpoint(request: ChatRequest) -> StreamingResponse | JSONResponse:
    """Send a message to the agent with SSE streaming."""
    request_started_at = time.perf_counter()
    session = get_state().get_session(request.session_id)
    if session is None:
        # Auto-create session if it doesn't exist (e.g. frontend sends chat before POST /api/sessions)
        session = get_state().create_session(session_id=request.session_id)
    _log_chat_timing(session.session_id, "request_received", request_started_at)

    # Handle human input response
    if request.human_input_response is not None:
        if session.resolve_human_response(request.human_input_response):
            return JSONResponse({"status": "human_prompt_resolved"})
        raise HTTPException(
            status_code=409,
            detail=f"Unknown or expired request_id: {request.human_input_response.request_id}",
        )

    # Handle permission response
    if request.permission_response is not None:
        session.resolve_permission(
            request.permission_response.request_id,
            request.permission_response.decision,
        )
        return JSONResponse({"status": "permission_resolved"})

    event_queue = await session.enqueue_chat(
        request.message,
        model=request.model,
        agent=request.agent,
        reset=request.reset,
        generate_params_extra=request.generate_params_extra,
    )
    _log_chat_timing(session.session_id, "request_enqueued", request_started_at)

    # Fire-and-forget: best-effort sync that already swallows all exceptions.
    # Previously this was awaited, blocking the SSE response for seconds due to
    # GIL starvation while agent creation held the event loop.
    # Only runs in sandbox mode — local TUI skips platform sync entirely.
    if _is_sandbox_mode():
        asyncio.get_running_loop().run_in_executor(
            None,
            lambda: _sync_accepted_turn_with_platform(
                session, model=request.model, agent=request.agent
            ),
        )

    async def generate_events() -> t.AsyncIterator[str]:
        saw_first_event = False
        while True:
            event = await event_queue.get()
            if event is None:
                break
            if not saw_first_event:
                saw_first_event = True
                _log_chat_timing(session.session_id, "first_event", request_started_at)
            yield f"data: {safe_json_dumps(event)}\n\n"
            event_type = str(event.get("type", "")).lower()
            if event_type in _TERMINAL_CHAT_EVENT_TYPES:
                _log_chat_timing(session.session_id, "terminal_event", request_started_at)
                break

    return StreamingResponse(
        generate_events(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
    )


@app.post("/api/sessions/{session_id}/title")
async def set_session_title(session_id: str, body: dict[str, t.Any]) -> JSONResponse:
    """Set the session title."""
    session = get_state().get_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail=f"Session not found: {session_id}")
    title = body.get("title", "")
    session.title = title or None
    session._persist_state(update_messages=False)
    return JSONResponse({"status": "ok", "session_id": session_id, "title": session.title})


@app.post("/api/sessions/{session_id}/reset")
async def reset_session(session_id: str) -> JSONResponse:
    """Reset the agent conversation."""
    session = get_state().get_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail=f"Session not found: {session_id}")
    session.reset()
    return JSONResponse(content={"status": "reset", "session_id": session_id})


@app.post("/api/sessions/{session_id}/compact")
async def compact_session(session_id: str, body: dict[str, t.Any] | None = None) -> JSONResponse:
    """Compact a session's conversation history (CMP-API-001)."""
    session = get_state().get_session(session_id)
    if session is None:
        raise HTTPException(status_code=404, detail=f"Session not found: {session_id}")
    if session.is_busy:
        return JSONResponse(content={"status": "skipped", "reason": "turn_in_progress"})
    guidance = (body or {}).get("guidance", "")
    result = await session.compact_session(trigger="manual", guidance=guidance)
    return JSONResponse(content=result)


# =============================================================================
# File & Shell Endpoints
# =============================================================================

IGNORED_NAMES = frozenset(
    {
        ".git",
        ".hg",
        ".svn",
        "node_modules",
        "__pycache__",
        ".venv",
        "venv",
        ".tox",
        ".mypy_cache",
        ".pytest_cache",
        ".ruff_cache",
        "dist",
        "build",
        ".eggs",
    }
)


@app.get("/api/files")
async def list_files(
    path: str | None = None,
    depth: int = 10,
) -> JSONResponse:
    """List directory contents recursively."""

    # When DREADNODE_PROJECT_ROOT is set (E2B sandboxes), scope the file
    # browser to the workspace directory instead of showing the entire
    # home directory (which may contain pip-installed SDK source trees).
    project_root = os.environ.get("DREADNODE_PROJECT_ROOT")
    if project_root:
        base = Path(project_root)
    elif path:
        base = Path(path)
    else:
        base = Path.cwd()
    if not base.is_dir():
        return JSONResponse({"path": str(base), "entries": [], "error": "Not a directory"})

    entries: list[dict[str, t.Any]] = []

    async def _walk(dir_path: Path, current_depth: int) -> None:
        try:
            items = sorted(dir_path.iterdir())
        except PermissionError:
            return
        for item in items:
            if item.name.startswith(".") or item.name in IGNORED_NAMES:
                continue
            is_dir = item.is_dir()
            size = None
            if not is_dir:
                with suppress(OSError):
                    size = item.stat().st_size
            entries.append(
                {
                    "name": item.name,
                    "path": str(item.relative_to(base)),
                    "isDir": is_dir,
                    "size": size,
                }
            )
            if is_dir and current_depth < depth:
                await _walk(item, current_depth + 1)

    await _walk(base, 0)
    return JSONResponse({"path": str(base), "entries": entries})


@app.get("/api/files/read")
async def read_file(path: str) -> JSONResponse:
    """Read a file's content."""
    file_path = Path(path)
    if not file_path.is_file():
        return JSONResponse(
            {"path": path, "content": "", "error": "File not found"}, status_code=404
        )
    try:
        content = file_path.read_text(encoding="utf-8", errors="replace")
        return JSONResponse({"path": path, "content": content})
    except Exception as exc:
        return JSONResponse({"path": path, "content": "", "error": str(exc)}, status_code=500)


@app.post("/api/shell")
async def execute_shell(
    command: str = "",
    cwd: str | None = None,
    timeout: int = 30,
) -> JSONResponse:
    """Execute a shell command directly (not through agent)."""
    import asyncio as _asyncio

    if not command.strip():
        return JSONResponse({"error": "Empty command"}, status_code=400)

    work_dir = cwd or str(Path.cwd())
    try:
        proc = await _asyncio.create_subprocess_shell(
            command,
            stdout=_asyncio.subprocess.PIPE,
            stderr=_asyncio.subprocess.PIPE,
            cwd=work_dir,
        )
        stdout_bytes, stderr_bytes = await _asyncio.wait_for(proc.communicate(), timeout=timeout)
        return JSONResponse(
            {
                "stdout": stdout_bytes.decode("utf-8", errors="replace"),
                "stderr": stderr_bytes.decode("utf-8", errors="replace"),
                "exitCode": proc.returncode,
                "command": command,
            }
        )
    except _asyncio.TimeoutError:
        proc.kill()
        return JSONResponse(
            {"error": f"Command timed out after {timeout}s", "command": command}, status_code=408
        )
    except Exception as exc:
        return JSONResponse({"error": str(exc), "command": command}, status_code=500)


@app.get("/api/health", response_model=HealthResponse)
async def health_check() -> HealthResponse:
    """Health check endpoint."""
    return HealthResponse(status="ok")


@app.get("/api/runtime", response_model=RuntimeInfoResponse)
async def runtime_info() -> RuntimeInfoResponse:
    """Expose loaded capability metadata for CLI/runtime synchronization."""
    registry = get_state().capability_registry
    if registry is None:
        return RuntimeInfoResponse(working_dir=str(Path.cwd()))
    return registry.to_runtime_info(working_dir=Path.cwd())


@app.get("/api/tools", response_model=ToolsResponse)
async def list_tools() -> ToolsResponse:
    """List all available tools grouped by source capability."""
    from dreadnode.tools import default_tools

    registry = get_state().capability_registry
    items: list[ToolInfo] = []

    # Built-in tools
    for name, tool in default_tools().items():
        desc = ""
        if hasattr(tool, "description"):
            desc = tool.description or ""
        elif hasattr(tool, "__doc__"):
            desc = (tool.__doc__ or "").split("\n")[0]
        items.append(ToolInfo(name=name, description=desc, capability="built-in"))

    if registry is None:
        return ToolsResponse(tools=items)

    # Capability tools
    for cap_name, capability in registry.capabilities.items():
        for tool in capability.tools:
            name = _tool_name(tool)
            desc = ""
            if hasattr(tool, "description"):
                desc = tool.description or ""
            elif hasattr(tool, "__doc__"):
                desc = (tool.__doc__ or "").split("\n")[0]
            items.append(ToolInfo(name=name or "?", description=desc, capability=cap_name))

    # MCP tools
    if registry.mcp_manager:
        for tool in registry.mcp_manager.all_tools():
            name = _tool_name(tool)
            desc = getattr(tool, "description", "") or ""
            items.append(ToolInfo(name=name or "?", description=desc, capability="mcp"))

    # Session-scoped tools (always present when skills/subagents available)
    all_skills = registry.all_skills()
    if all_skills:
        skill_names = ", ".join(s.name for s in all_skills[:5])
        suffix = f" (+{len(all_skills) - 5} more)" if len(all_skills) > 5 else ""
        items.append(
            ToolInfo(
                name="load_skill",
                description=f"Load skill instructions ({skill_names}{suffix})",
                capability="session",
            )
        )
    items.append(
        ToolInfo(
            name="spawn_agent",
            description="Spawn a sub-agent for task delegation",
            capability="session",
        )
    )

    return ToolsResponse(tools=items)


@app.get("/api/skills", response_model=SkillsResponse)
async def list_skills() -> SkillsResponse:
    """List all available skills from loaded capabilities."""
    registry = get_state().capability_registry
    if registry is None:
        return SkillsResponse()
    return SkillsResponse(
        skills=[
            SkillInfoModel(name=s.name, description=s.description)
            for s in sorted(registry.all_skills(), key=lambda s: s.name)
        ]
    )


@app.get("/api/skills/{name}", response_model=SkillContentResponse)
async def get_skill(name: str) -> SkillContentResponse:
    """Get full skill content by name.

    Returns both raw instructions and rendered content (matching load_skill tool output).
    """
    registry = get_state().capability_registry
    if registry is None:
        raise HTTPException(status_code=404, detail="No capabilities loaded")
    for skill in registry.all_skills():
        if skill.name == name:
            return SkillContentResponse(
                name=skill.name,
                description=skill.description,
                instructions=skill.instructions,
                allowed_tools=skill.allowed_tools,
                rendered=skill.render_content(),
            )
    raise HTTPException(status_code=404, detail=f"Skill '{name}' not found")


@app.post("/api/reload", response_model=RuntimeInfoResponse)
async def reload_capabilities() -> RuntimeInfoResponse:
    """Re-discover capabilities and rebuild the registry.

    Active sessions detect the change on their next turn and recreate
    agents with the updated tool/skill set.
    """
    from dreadnode import _get_default_instance

    # Stop old MCP servers before replacing the registry
    old_registry = get_state().capability_registry
    if old_registry and old_registry.mcp_manager:
        await old_registry.mcp_manager.stop()

    instance = _get_default_instance()
    await asyncio.to_thread(_populate_registry, instance)

    # Start MCP servers for the new registry
    registry = get_state().capability_registry
    if registry:
        registry.mcp_manager = MCPLifecycleManager()
        await registry.mcp_manager.start(registry)

    if registry is None:
        return RuntimeInfoResponse(working_dir=str(Path.cwd()))
    return registry.to_runtime_info(working_dir=Path.cwd())


# =============================================================================
# Server Entry Point
# =============================================================================


def _read_capability_system_prompt(path: Path) -> str:
    """Read and normalize an optional capability-level system prompt."""
    import re

    prompt_file = path / "system-prompt.md"
    if not prompt_file.exists():
        return ""

    content = prompt_file.read_text().strip()
    frontmatter_match = re.match(r"^---\s*\n[\s\S]*?\n---\s*\n([\s\S]*)", content)
    if frontmatter_match:
        content = frontmatter_match.group(1).strip()
    return content


def _sync_runtime_capabilities_if_available(
    instance: t.Any,
) -> tuple[Path | None, list[dict[str, t.Any]]]:
    """Sync runtime-scoped capabilities if platform credentials are available.

    Returns (runtime_cache_dir, runtime_bindings).
    """
    runtime_id = os.environ.get("DREADNODE_RUNTIME_ID", "").strip()
    if not instance.can_sync or not runtime_id:
        logger.info(
            "Capability sync skipped (can_sync={}, runtime_id={})",
            instance.can_sync,
            runtime_id or "<empty>",
        )
        return None, []

    from dreadnode.capabilities.sync import CapabilitySyncClient

    try:
        cache_dir = instance.storage.workspace_capabilities_path
        # asyncio.run() is safe here because _populate_registry runs inside
        # asyncio.to_thread(), which means we're in a thread pool worker with
        # no running event loop. asyncio.run() creates a fresh loop.
        client = CapabilitySyncClient(
            api=instance.api,
            org=instance.session.org_key,
            workspace=instance.session.workspace_key,
            runtime_id=runtime_id,
            cache_dir=cache_dir,
        )
        result = asyncio.run(client.sync())
        if result.synced:
            logger.info("Synced workspace capabilities: {}", result.synced)
        if result.removed:
            logger.info("Removed stale workspace capabilities: {}", result.removed)
        if result.errors:
            for err in result.errors:
                logger.warning("Failed to sync '{}': {}", err.name, err.error)
    except Exception:
        logger.warning("Runtime capability sync failed — using local only", exc_info=True)
        return None, []
    else:
        return (
            cache_dir,
            result.bindings,
        )  # partial sync: returns bindings even when some errors occurred


def _populate_registry(instance: t.Any) -> None:
    """Discover capabilities and install them into app state."""
    from dreadnode.capabilities import Capability
    from dreadnode.capabilities.capability import read_local_capability_records

    state = get_state()
    registry = CapabilityRegistry()

    # 1. Sync runtime capabilities if platform credentials are available
    workspace_dir, runtime_bindings = _sync_runtime_capabilities_if_available(instance)
    registry.runtime_bindings = runtime_bindings

    # 2. Determine host type: sandbox if runtime binding env is set, local otherwise
    host = "sandbox" if os.environ.get("DREADNODE_RUNTIME_ID", "").strip() else "local"

    # 3. Discover with host-exclusive source (CAP-LOAD-014)
    try:
        result = Capability.discover(
            cwd=Path.cwd(),
            storage=instance.storage,
            capability_dirs=state.capability_dirs,
            workspace_dir=workspace_dir,
            host=host,
        )
        for cap in result.capabilities.values():
            registry.capabilities[cap.name] = cap
        registry.disabled_local = result.disabled
        registry.load_failures = result.failures
        registry.local_capability_records = read_local_capability_records(
            instance.storage.local_capability_state_path
        )
    except Exception:
        logger.exception("Failed to discover capabilities")

    # Apply exclusive capability filter from CLI --capability flags
    if state.enabled_capabilities:
        allowed = set(state.enabled_capabilities)
        to_disable = {n: c for n, c in registry.capabilities.items() if n not in allowed}
        for name, cap in to_disable.items():
            registry.disabled_local[name] = cap
            del registry.capabilities[name]

    if registry.capabilities:
        registry.default_capability_name = next(iter(registry.capabilities))

    state.capability_registry = registry
    logger.info(
        "Loaded {} capabilities: {}",
        len(registry.capabilities),
        list(registry.capabilities.keys()) or "(none)",
    )
    if registry.load_failures:
        for f in registry.load_failures:
            logger.warning(
                "Capability load failure: {} at {} — {}", f["name"], f["path"], f["error"]
            )


def initialize_app(
    *,
    server: str | None = None,
    api_key: str | None = None,
    organization: str | None = None,
    workspace: str | None = None,
    project: str | None = None,
    load_profile: bool = True,
    capability_dirs: list[str] | None = None,
    enabled_capabilities: list[str] | None = None,
    system_prompt_append: str | None = None,
) -> None:
    """Initialize app state: configure a Dreadnode instance and discover capabilities.

    Creates a fresh ``Dreadnode`` instance (bypassing the singleton's idempotent
    guard) and replaces ``DEFAULT_INSTANCE`` so that server-side code using
    ``_get_default_instance()`` picks up the new credentials.

    Must be called via ``asyncio.to_thread()`` from async contexts because
    ``Capability.discover()`` internally calls ``asyncio.run()``.
    """
    import dreadnode.app.main as main_mod

    instance = main_mod.Dreadnode()
    instance.configure(
        server=server,
        api_key=api_key,
        organization=organization,
        workspace=workspace,
        project=project,
        load_profile=load_profile,
    )
    main_mod.DEFAULT_INSTANCE = instance

    # Store CLI overrides on state so they persist across /reload
    state = get_state()
    state.capability_dirs = capability_dirs
    state.enabled_capabilities = enabled_capabilities
    state.system_prompt_append = system_prompt_append

    _populate_registry(instance)


def reset_app_state() -> None:
    """Clear all server state: close sessions and reset the capability registry.

    Called before re-running ``initialize_app()`` on restart.
    """
    if not hasattr(app.state, "server"):
        return

    state: ServerState = app.state.server

    # Stop MCP servers if running (best-effort, sync context)
    if state.capability_registry and state.capability_registry.mcp_manager:
        manager = state.capability_registry.mcp_manager
        try:
            asyncio.get_running_loop()
            # In async context — schedule and let it complete
            asyncio.create_task(manager.stop())  # noqa: RUF006
        except RuntimeError:
            # No running loop — safe to run synchronously
            asyncio.run(manager.stop())

    for session in state.list_sessions():
        session.close()

    app.state.server = ServerState()


def run_server(
    instance: t.Any | None = None,
    *,
    host: str | None = None,
    port: int | None = None,
    server: str | None = None,
    api_key: str | None = None,
    organization: str | None = None,
    workspace: str | None = None,
    project: str | None = None,
) -> None:
    """Run the FastAPI server with uvicorn."""
    from dreadnode import _get_default_instance

    if instance is None:
        instance = _get_default_instance()
    instance.configure(
        server=server,
        api_key=api_key,
        organization=organization,
        workspace=workspace,
        project=project,
    )

    _populate_registry(instance)

    resolved_host = host or os.environ.get("DREADNODE_SERVER_HOST", "127.0.0.1")
    resolved_port = port or int(os.environ.get("DREADNODE_SERVER_PORT", "8787"))
    logger.info(f"Starting server at http://{resolved_host}:{resolved_port}")

    uvicorn.run(app, host=resolved_host, port=resolved_port, log_config=None)
