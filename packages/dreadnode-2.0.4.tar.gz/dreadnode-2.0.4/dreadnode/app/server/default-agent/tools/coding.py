"""Coding tools for the default agent."""

import asyncio
import base64
import mimetypes
import re
import typing as t
from pathlib import Path

import aiofiles

from dreadnode.agents.tools import tool


@tool(catch=True)
async def read(
    file_path: t.Annotated[str, "Path to the file to read (relative to workspace)"],
    offset: t.Annotated[int | None, "Line number to start reading from (1-indexed)"] = None,
    limit: t.Annotated[int | None, "Number of lines to read"] = None,
) -> dict[str, t.Any]:
    """
    Read a file and return its contents with line numbers.

    Features:
    - Text files: Returns content with line numbers (1-indexed)
    - Images: Returns base64-encoded data with media type
    - Large files: Use offset/limit to read specific sections

    Args:
        file_path: Path to the file (relative to workspace).
        offset: Starting line number (1-indexed). Default: 1
        limit: Number of lines to read. Default: 2000

    Returns:
        Dict with path and content.

    Example output:
        {"path": "src/agent/main.py", "content": "1→import os\\n2→..."}
    """
    base_path = Path(file_path)

    mime_type, _ = mimetypes.guess_type(str(base_path))
    if mime_type and mime_type.startswith("image/"):
        async with aiofiles.open(base_path, "rb") as f:
            content = await f.read()
        encoded = base64.b64encode(content).decode("utf-8")
        return {
            "path": base_path,
            "content": f"[Image: {mime_type}]\nBase64: {encoded[:100]}... ({len(encoded)} chars total)",
        }

    async with aiofiles.open(base_path, errors="replace") as f:
        lines = await f.readlines()

    start = (offset or 1) - 1  # Convert to 0-indexed
    end = start + (limit or 2000)

    selected_lines = lines[start:end]

    # Format with line numbers
    result_lines = []
    for i, line in enumerate(selected_lines, start=start + 1):
        # Truncate long lines
        line_content = line.rstrip("\n\r")
        if len(line_content) > 2000:
            line_content = line_content[:2000] + "..."
        result_lines.append(f"{i:>6}→{line_content}")

    return {
        "path": base_path,
        "content": "\n".join(result_lines),
    }


@tool(catch=True)
async def glob(
    pattern: t.Annotated[str, "Glob pattern to match files against"],
    path: t.Annotated[str | None, "Directory to search in (default: working directory)"] = None,
    max_results: t.Annotated[int, "Maximum number of results to return"] = 100,
) -> list[dict[str, t.Any]]:
    """
    Find files matching a glob pattern.

    Supports standard glob patterns:
    - * matches any characters except /
    - ** matches any characters including /
    - ? matches a single character
    - [abc] matches any character in brackets

    Args:
        pattern: Glob pattern to match files against.
        path: Directory to search in. Defaults to working directory (set by init_package).
        max_results: Maximum results to return (default: 100).

    Returns:
        List of matching files with name, path, size, and modified time.

    Example:
        glob("**/*.py")  # Find all Python files recursively
        glob("src/**/*.ts", path="/project")  # Find TypeScript files in src/
    """

    base_path = Path(path) if path is not None else Path.cwd()

    # Find matching files
    matches = list(base_path.glob(pattern))

    # Sort by modification time (newest first)
    matches.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)

    # Limit results
    matches = matches[:max_results]

    results = []
    for match in matches:
        try:
            stat = match.stat()
            results.append(
                {
                    "name": match.name,
                    "path": str(match),
                    "relative": str(match.relative_to(base_path))
                    if match.is_relative_to(base_path)
                    else str(match),
                    "size": stat.st_size,
                    "is_dir": match.is_dir(),
                }
            )
        except (OSError, ValueError):
            results.append(
                {
                    "name": match.name,
                    "path": str(match),
                    "error": "Could not stat file",
                }
            )

    return results


@tool(catch=True)
async def grep(
    pattern: t.Annotated[str, "Regular expression pattern to search for"],
    path: t.Annotated[
        str | None, "File or directory to search in (default: working directory)"
    ] = None,
    *,
    glob_pattern: t.Annotated[str | None, "Glob pattern to filter files (e.g., '*.py')"] = None,
    ignore_case: t.Annotated[bool, "Case insensitive search"] = False,
    max_results: t.Annotated[int, "Maximum number of matches to return"] = 100,
    context_lines: t.Annotated[int, "Number of context lines before/after match"] = 1,
) -> list[dict[str, t.Any]]:
    """
    Search for a pattern in files using regular expressions.

    Args:
        pattern: Regex pattern to search for.
        path: File or directory to search in. Defaults to working directory (set by init_package).
        glob_pattern: Filter files by glob pattern (e.g., "*.py", "*.ts").
        ignore_case: Case insensitive search (default: False).
        max_results: Maximum matches to return (default: 100).
        context_lines: Lines of context around each match (default: 1).

    Returns:
        List of matches with file path, line number, content, and context.

    Example:
        grep("def.*async", "src", glob_pattern="*.py")
        grep("TODO", ignore_case=True)
    """

    base_path = Path(path) if path is not None else Path.cwd()

    if not base_path.exists():
        raise ValueError(f"Path does not exist: {base_path}")

    # Compile regex
    flags = re.IGNORECASE if ignore_case else 0
    try:
        regex = re.compile(pattern, flags)
    except re.error as e:
        raise ValueError(f"Invalid regex pattern: {e}") from e

    # Get files to search
    if base_path.is_file():
        files = [base_path]
    elif glob_pattern:
        files = list(base_path.rglob(glob_pattern))
    else:
        files = [f for f in base_path.rglob("*") if f.is_file()]

    # Filter to text files only (skip binary)
    text_files = []
    for f in files:
        if f.is_file() and f.stat().st_size < 5 * 1024 * 1024:  # Skip files > 5MB
            mime_type, _ = mimetypes.guess_type(str(f))
            if (
                mime_type is None
                or mime_type.startswith("text/")
                or mime_type
                in [
                    "application/json",
                    "application/javascript",
                    "application/xml",
                    "application/x-python",
                    "application/x-yaml",
                ]
            ):
                text_files.append(f)

    results = []

    async def search_file(file_path: Path) -> list[dict[str, t.Any]]:
        matches = []
        try:
            async with aiofiles.open(file_path, errors="replace") as f:
                lines = await f.readlines()

            for i, line in enumerate(lines):
                if regex.search(line):
                    # Get context
                    start = max(0, i - context_lines)
                    end = min(len(lines), i + context_lines + 1)
                    context = []
                    for j in range(start, end):
                        prefix = ">" if j == i else " "
                        context.append(f"{prefix} {j + 1}: {lines[j].rstrip()[:100]}")

                    matches.append(
                        {
                            "file": str(file_path),
                            "line": i + 1,
                            "content": line.rstrip()[:200],
                            "context": context,
                        }
                    )

                    if len(matches) >= max_results:
                        break
        except Exception:  # noqa: S110
            pass

        return matches

    # Search files concurrently
    tasks = [search_file(f) for f in text_files[:50]]  # Limit to 50 files
    file_results = await asyncio.gather(*tasks)

    for file_matches in file_results:
        results.extend(file_matches)
        if len(results) >= max_results:
            break

    return results[:max_results]


@tool(catch=True)
async def todo(
    action: t.Annotated[str, "Action: 'list', 'add', 'complete'"],
    *,
    task: t.Annotated[
        str | None, "Task description (for 'add') or task number (for 'complete')"
    ] = None,
    tasks: t.Annotated[list[str] | None, "Multiple tasks to add at once"] = None,
) -> dict[str, t.Any]:
    """
    Track tasks and progress during development.

    Actions:
    - list: Show all tasks with status
    - add: Add a new task (use 'task' or 'tasks' parameter)
    - complete: Mark a task as done (by number)

    Args:
        action: The action to perform.
        task: Task description for 'add', or task number for 'complete'.
        tasks: List of tasks to add at once.

    Returns:
        Current task list and status.

    Example:
        todo("add", task="Implement login flow")
        todo("add", tasks=["Write tests", "Update docs", "Deploy"])
        todo("complete", task="1")
        todo("list")
    """

    todo_file = Path.cwd() / "TODO.json"

    # Load existing todos
    import json

    todos: list[dict[str, t.Any]] = []
    if todo_file.exists():
        try:
            todos = json.loads(todo_file.read_text())
        except Exception:
            todos = []

    if action == "list":
        return {
            "todos": todos,
            "total": len(todos),
            "completed": sum(1 for item in todos if item.get("done")),
            "pending": sum(1 for item in todos if not item.get("done")),
        }

    if action == "add":
        new_tasks = []
        if tasks:
            new_tasks = tasks
        elif task:
            new_tasks = [task]
        else:
            return {"error": "Provide 'task' or 'tasks' parameter"}

        for new_task in new_tasks:
            todos.append({"task": new_task, "done": False})

        todo_file.write_text(json.dumps(todos, indent=2))
        return {
            "added": new_tasks,
            "total": len(todos),
        }

    if action == "complete":
        if not task:
            return {"error": "Provide task number to complete"}

        try:
            idx = int(task) - 1
        except ValueError:
            return {"error": f"Invalid task number: {task}"}
        if 0 <= idx < len(todos):
            todos[idx]["done"] = True
            todo_file.write_text(json.dumps(todos, indent=2))
            return {
                "completed": todos[idx]["task"],
                "total": len(todos),
                "remaining": sum(1 for item in todos if not item.get("done")),
            }
        return {"error": f"Invalid task number: {task}"}

    if action == "clear":
        todos = [item for item in todos if not item.get("done")]
        todo_file.write_text(json.dumps(todos, indent=2))
        return {
            "cleared": "completed tasks",
            "remaining": len(todos),
        }

    return {"error": f"Unknown action: {action}. Use: list, add, complete, clear"}


@tool(catch=True)
async def write(
    path: t.Annotated[str, "Path to the file to write (relative to working directory or absolute)"],
    content: t.Annotated[str, "Content to write to the file"],
) -> dict[str, t.Any]:
    """
    Write content to a file, creating it if it doesn't exist.

    Parent directories are created automatically if needed.

    Args:
        path: Path to the file (relative paths resolve against working directory).
        content: Content to write to the file.

    Returns:
        Dict with path, size, and lines written.

    Example:
        write("src/agent.py", "print('hello')")
    """
    base_path = Path(path)

    if not base_path.parent.exists():
        base_path.parent.mkdir(parents=True, exist_ok=True)

    async with aiofiles.open(path, "w") as f:
        await f.write(content)

    return {
        "path": base_path,
        "size": len(content),
        "lines": content.count("\n") + 1,
    }


@tool(catch=True)
async def edit(
    path: t.Annotated[str, "Path to the file to edit (relative to workspace)"],
    old_string: t.Annotated[str, "Exact string to replace (must match exactly)"],
    new_string: t.Annotated[str, "Replacement string"],
    *,
    replace_all: t.Annotated[bool, "Replace all occurrences (default: False)"] = False,
) -> dict[str, t.Any]:
    """
    Perform surgical text replacement in a file.

    The old_string must match EXACTLY (including whitespace/indentation).
    By default, old_string must appear exactly once in the file.

    Args:
        path: Path to the file (relative to workspace).
        old_string: Exact text to find and replace.
        new_string: Text to replace it with.
        replace_all: If True, replace all occurrences.

    Returns:
        Dict with path, old_string, new_string, and count.

    Example:
        edit("src/agent.py", "old_func()", "new_func()")
        edit("src/agent.py", "TODO", "DONE", replace_all=True)
    """
    base_path = Path(path)

    if not base_path.exists():
        raise FileNotFoundError(f"File not found: {base_path}")

    async with aiofiles.open(base_path) as f:
        content = await f.read()

    count = content.count(old_string)

    if count == 0:
        preview = old_string[:100] + "..." if len(old_string) > 100 else old_string
        raise ValueError(f"String not found in {base_path}. Looking for: {preview!r}")

    if count > 1 and not replace_all:
        raise ValueError(
            f"String appears {count} times. Use replace_all=True or provide more context."
        )

    if replace_all:
        new_content = content.replace(old_string, new_string)
    else:
        new_content = content.replace(old_string, new_string, 1)

    async with aiofiles.open(path, "w") as f:
        await f.write(new_content)

    return {
        "path": base_path,
        "old_string": old_string,
        "new_string": new_string,
        "replacements": count,
    }


@tool(catch=True)
async def bash(
    command: t.Annotated[str, "Shell command to execute"],
    *,
    timeout: t.Annotated[int, "Timeout in seconds"] = 120,
    input_text: t.Annotated[str | None, "Text to send to stdin"] = None,
) -> dict[str, t.Any]:
    """
    Execute a shell command and return the output.

    Args:
        command: Shell command to execute.
        cwd: Working directory for the command. Defaults to working directory (set by init_package).
        timeout: Maximum execution time in seconds (default: 120).
        input_text: Optional text to send to the command's stdin.

    Returns:
        Dict with stdout, stderr, return_code.

    Example:
        bash("ls -la")
        bash("git status")
        bash("python script.py", timeout=300)
    """
    import os

    env = os.environ.copy()

    # Use working directory if set and no explicit cwd provided

    effective_cwd = Path.cwd()

    proc = await asyncio.create_subprocess_shell(
        command,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
        stdin=asyncio.subprocess.PIPE if input_text else None,
        cwd=effective_cwd,
        env=env,
    )

    try:
        stdout, stderr = await asyncio.wait_for(
            proc.communicate(input=input_text.encode() if input_text else None),
            timeout=timeout,
        )
    except asyncio.TimeoutError:
        proc.kill()
        return {
            "error": f"Command timed out after {timeout} seconds",
            "return_code": -1,
        }

    return {
        "stdout": stdout.decode(errors="replace"),
        "stderr": stderr.decode(errors="replace"),
        "return_code": proc.returncode,
    }


@tool(catch=True)
async def web_fetch(
    url: t.Annotated[str, "URL to fetch"],
    *,
    extract_text: t.Annotated[bool, "Extract text content from HTML"] = True,
    max_length: t.Annotated[int, "Maximum content length to return"] = 50000,
) -> dict[str, t.Any]:
    """
    Fetch content from a URL.

    Args:
        url: URL to fetch.
        extract_text: If True, extract text from HTML (default: True).
        max_length: Maximum content length to return.

    Returns:
        Dict with content, status_code, content_type.

    Example:
        web_fetch("https://example.com")
        web_fetch("https://api.example.com/data", extract_text=False)
    """
    try:
        import httpx
    except ImportError:
        return {"error": "httpx not installed. Run: pip install httpx"}

    try:
        async with httpx.AsyncClient(follow_redirects=True, timeout=30) as client:
            response = await client.get(url)

        content = response.text
        content_type = response.headers.get("content-type", "")

        # Extract text from HTML if requested
        if extract_text and "text/html" in content_type:
            try:
                from bs4 import BeautifulSoup

                soup = BeautifulSoup(content, "html.parser")
                # Remove script and style elements
                for tag in soup(["script", "style", "nav", "footer", "header"]):
                    tag.decompose()
                content = soup.get_text(separator="\n", strip=True)
            except ImportError:
                # BeautifulSoup not available, return raw content
                pass

        # Truncate if needed
        if len(content) > max_length:
            content = content[:max_length] + f"\n... (truncated, {len(response.text)} total chars)"

        return {
            "content": content,
            "status_code": response.status_code,
            "content_type": content_type,
            "url": str(response.url),
        }
    except Exception as e:
        return {"error": str(e)}


@tool(catch=True)
async def web_search(
    query: t.Annotated[str, "Search query"],
    *,
    max_results: t.Annotated[int, "Maximum number of results"] = 10,
) -> list[dict[str, t.Any]]:
    """
    Search the web using DuckDuckGo.

    Args:
        query: Search query.
        max_results: Maximum number of results to return.

    Returns:
        List of search results with title, url, snippet.

    Example:
        web_search("python asyncio tutorial")
        web_search("dreadnode SDK documentation")
    """
    try:
        from duckduckgo_search import DDGS
    except ImportError:
        return [{"error": "duckduckgo-search not installed. Run: pip install duckduckgo-search"}]

    try:
        with DDGS() as ddgs:
            results = list(ddgs.text(query, max_results=max_results))

        return [
            {
                "title": r.get("title", ""),
                "url": r.get("href", ""),
                "snippet": r.get("body", ""),
            }
            for r in results
        ]
    except Exception as e:
        return [{"error": str(e)}]


@tool(catch=True)
async def ask_the_user(
    question: t.Annotated[str, "Question to ask the user"],
    *,
    options: t.Annotated[list[str] | None, "Optional list of choices"] = None,
) -> str:
    """
    Ask the user a question and wait for their response.

    In interactive mode (when a HumanInputManager is available), this tool
    will pause execution and wait for the user to respond via the UI.

    In non-interactive mode, it will return a placeholder message.

    Args:
        question: The question to ask.
        options: Optional list of choices to present.

    Returns:
        The user's response.

    Example:
        ask("What model should I use?", options=["gpt-4", "claude-3", "llama-3"])
        ask("What's the project name?")
    """
    from dreadnode.tools.interaction import ask_user

    return await ask_user(question, options=options)


@tool(catch=True)
async def subagent(
    task: t.Annotated[str, "Task description for the subagent"],
    *,
    agent_type: t.Annotated[
        str, "Type of agent: 'explore', 'plan', 'bash', 'research'"
    ] = "explore",
    max_steps: t.Annotated[int, "Maximum steps for the subagent"] = 20,
) -> dict[str, t.Any]:
    """
    Launch a specialized subagent to handle a complex task.

    Agent types:
    - explore: Explore codebase, find files, understand structure
    - plan: Create implementation plans
    - bash: Execute shell commands
    - research: Search and gather information

    Args:
        task: Task description for the subagent.
        agent_type: Type of specialized agent to launch.
        max_steps: Maximum steps for the subagent (default: 20).

    Returns:
        Dict with subagent results.

    Example:
        subagent("Find all files that handle authentication", agent_type="explore")
        subagent("Plan the implementation of a login feature", agent_type="plan")
    """
    from dreadnode.agents import Agent

    # Create a lightweight agent for the specific task
    agent_configs = {
        "explore": {
            "instructions": "You are a code explorer. Find files, understand patterns, and report findings.",
            "tools_needed": ["read", "glob", "grep"],
        },
        "plan": {
            "instructions": "You are a software architect. Create detailed implementation plans.",
            "tools_needed": ["read", "glob"],
        },
        "bash": {
            "instructions": "You execute shell commands to accomplish tasks. Be careful and precise.",
            "tools_needed": ["bash"],
        },
        "research": {
            "instructions": "You research topics using web search and fetch. Summarize findings.",
            "tools_needed": ["web_search", "web_fetch"],
        },
    }

    config = agent_configs.get(agent_type, agent_configs["explore"])

    # Get the relevant tools
    tool_map = {
        "read": read,
        "glob": glob,
        "grep": grep,
        "bash": bash,
        "web_search": web_search,
        "web_fetch": web_fetch,
    }
    tools = [tool_map[t] for t in config["tools_needed"] if t in tool_map]

    from dreadnode.agents import stopping

    subagent = Agent(
        name=f"subagent-{agent_type}",
        model="anthropic/claude-haiku-4-5-20251001",
        instructions=config["instructions"],
        tools=tools,
        hooks=[stopping.step_count(max_steps)],
    )

    try:
        result = await subagent.run(task)
        # Get the last assistant message as the result
        for msg in reversed(result.messages):
            if msg.role == "assistant" and msg.content:
                return {
                    "agent_type": agent_type,
                    "task": task,
                    "result": msg.content,
                    "steps": len(result.steps),
                }
        return {
            "agent_type": agent_type,
            "task": task,
            "result": "(No response)",
            "steps": len(result.steps),
        }
    except Exception as e:
        return {
            "agent_type": agent_type,
            "task": task,
            "error": str(e),
        }


@tool(catch=True)
async def data_designer(
    action: t.Annotated[str, "Action: 'generate', 'preview', 'from_pydantic', 'save'"],
    *,
    columns: t.Annotated[list[dict[str, t.Any]] | None, "Column definitions for generation"] = None,
    num_records: t.Annotated[int, "Number of records to generate"] = 50,
    model: t.Annotated[str, "Model for LLM columns"] = "anthropic/claude-haiku-4-5-20251001",
    schema_code: t.Annotated[str | None, "Python code defining a Pydantic model"] = None,
    instructions: t.Annotated[str | None, "Instructions for generation"] = None,
    samplers: t.Annotated[
        dict[str, list[str]] | None, "Field name -> category values mapping"
    ] = None,
    data: t.Annotated[list[dict[str, t.Any]] | None, "Data to save (for 'save' action)"] = None,
    output_path: t.Annotated[str | None, "Path to save data (jsonl or parquet)"] = None,
) -> dict[str, t.Any]:
    """
        Generate synthetic datasets using statistical sampling and LLM generation.

        Actions:
        - generate: Generate data from column definitions
        - preview: Generate a small preview (5 records)
        - from_pydantic: Generate from a Pydantic model definition
        - save: Save generated data to file (jsonl or parquet)

        Column types for 'generate':
        - sampler: Statistical sampling (category, uniform, gaussian, etc.)
        - llm: LLM-generated text using Jinja2 templates

        Args:
            action: The action to perform.
            columns: List of column definitions for 'generate' action.
            num_records: Number of records to generate.
            model: Model for LLM columns (litellm format).
            schema_code: Python code with Pydantic model for 'from_pydantic'.
            instructions: Instructions for generation.
            samplers: Field -> category values for 'from_pydantic'.
            data: Data to save for 'save' action.
            output_path: Path to save file (.jsonl or .parquet).

        Returns:
            Dict with generated records and metadata.

        Example - Generate with columns:
            data_designer(
                "generate",
                columns=[
                    {"name": "difficulty", "type": "sampler", "sampler_type": "category",
                     "values": ["easy", "medium", "hard"]},
                    {"name": "topic", "type": "sampler", "sampler_type": "category",
                     "values": ["math", "science", "history"]},
                    {"name": "question", "type": "llm",
                     "prompt": "Generate a {{ difficulty }} question about {{ topic }}"}
                ],
                num_records=100
            )

        Example - Generate from Pydantic:
            data_designer(
                "from_pydantic",
                schema_code='''
    class TestCase(BaseModel):
        input: str
        expected_output: str
        difficulty: str
    ''',
                samplers={"difficulty": ["easy", "medium", "hard"]},
                instructions="Generate test cases for a calculator"
            )

        Example - Save data:
            data_designer("save", data=records, output_path="/path/to/data.jsonl")
    """
    from dreadnode.integrations.data_designer import (
        DatasetGenerator,
        DatasetSchema,
        LLMColumn,
        ModelConfig,
        SamplerColumn,
        SamplerType,
    )

    generator = DatasetGenerator(default_model=model)

    if action in {"generate", "preview"}:
        if not columns:
            return {"error": "Provide 'columns' for generate action"}

        # Build column configs from dict definitions
        column_configs = []
        for col_def in columns:
            col_type = col_def.get("type", "sampler")
            name = col_def.get("name")

            if not name:
                return {"error": f"Column missing 'name': {col_def}"}

            if col_type == "sampler":
                sampler_type_str = col_def.get("sampler_type", "category")
                try:
                    sampler_type = SamplerType(sampler_type_str)
                except ValueError:
                    return {"error": f"Invalid sampler_type: {sampler_type_str}"}

                column_configs.append(
                    SamplerColumn(
                        name=name,
                        sampler_type=sampler_type,
                        values=col_def.get("values"),
                        weights=col_def.get("weights"),
                        min_value=col_def.get("min_value"),
                        max_value=col_def.get("max_value"),
                        mean=col_def.get("mean"),
                        std=col_def.get("std"),
                    )
                )

            elif col_type == "llm":
                prompt = col_def.get("prompt", "")
                column_configs.append(
                    LLMColumn(
                        name=name,
                        prompt=prompt,
                        model_alias="text",
                    )
                )

        schema = DatasetSchema(
            columns=column_configs,
            models=[ModelConfig(alias="text", model=model)],
        )

        is_preview = action == "preview"
        records = await generator.generate(
            schema,
            num_records=5 if is_preview else num_records,
            preview=is_preview,
        )

        return {
            "records": records,
            "num_records": len(records),
            "columns": [c.name for c in column_configs],
            "model": model,
            "preview": is_preview,
        }

    if action == "from_pydantic":
        if not schema_code:
            return {"error": "Provide 'schema_code' for from_pydantic action"}

        # Execute the schema code to get the Pydantic model
        local_ns: dict[str, t.Any] = {}
        exec_globals = {"BaseModel": __import__("pydantic").BaseModel}

        try:
            exec(schema_code, exec_globals, local_ns)  # noqa: S102
        except Exception as e:
            return {"error": f"Failed to execute schema_code: {e}"}

        # Find the Pydantic model class
        model_class = None
        for obj in local_ns.values():
            if isinstance(obj, type) and hasattr(obj, "model_json_schema"):
                model_class = obj
                break

        if not model_class:
            return {"error": "No Pydantic model found in schema_code"}

        # Convert samplers dict
        sampler_configs = dict(samplers) if samplers else {}

        records = await generator.from_schema(
            output_type=model_class,
            num_records=num_records,
            instructions=instructions,
            samplers=sampler_configs or None,
            model=model,
        )

        return {
            "records": records,
            "num_records": len(records),
            "schema": model_class.__name__,
            "model": model,
        }

    if action == "save":
        if not data:
            return {"error": "Provide 'data' for save action"}
        if not output_path:
            return {"error": "Provide 'output_path' for save action"}

        import json

        path = Path(output_path)
        path.parent.mkdir(parents=True, exist_ok=True)

        if path.suffix == ".jsonl":
            async with aiofiles.open(path, "w") as f:
                for record in data:
                    await f.write(json.dumps(record) + "\n")
        elif path.suffix == ".parquet":
            try:
                import pandas as pd

                df = pd.DataFrame(data)
                df.to_parquet(path)
            except ImportError:
                return {"error": "pandas required for parquet. Use .jsonl instead."}
        elif path.suffix == ".json":
            async with aiofiles.open(path, "w") as f:
                await f.write(json.dumps(data, indent=2))
        else:
            return {"error": f"Unsupported format: {path.suffix}. Use .jsonl, .json, or .parquet"}

        return {
            "saved": str(path),
            "num_records": len(data),
            "format": path.suffix.lstrip("."),
        }

    return {"error": f"Unknown action: {action}. Use: generate, preview, from_pydantic, save"}
