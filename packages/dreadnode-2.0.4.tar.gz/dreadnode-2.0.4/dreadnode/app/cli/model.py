"""Model subcommands for the cyclopts CLI."""

import typing as t

import cyclopts

from dreadnode.app.cli.shared import (
    RegistryConfig,
    _parse_versioned_ref,
    _print_json,
    _render_package_list,
    configured_dreadnode,
    require_registry_context,
)

cli = cyclopts.App(name="model", help="Manage models.")


# ---------------------------------------------------------------------------
# push
# ---------------------------------------------------------------------------


@cli.command()
def push(
    path: str,
    *,
    name: str | None = None,
    skip_upload: t.Annotated[bool, cyclopts.Parameter(negative=())] = False,
    registry: RegistryConfig = RegistryConfig(),
) -> None:
    """Build and push a model artifact."""
    dn = configured_dreadnode(registry)
    result = dn.push_model(path, name=name, skip_upload=skip_upload)
    if not result.success:
        raise SystemExit("; ".join(result.errors) or "Model push failed")

    if result.package_name is None or result.package_version is None:
        raise SystemExit("Model push returned incomplete metadata")

    display_name = result.package_name
    display_version = result.package_version
    if skip_upload or not dn.can_sync:
        print(f"Built {display_name}@{display_version}")
        return
    digest = result.manifest_digest or "unknown"
    print(f"Pushed {display_name}@{display_version} ({digest})")


# ---------------------------------------------------------------------------
# list
# ---------------------------------------------------------------------------


@cli.command(name="list")
def list_(
    *,
    as_json: t.Annotated[bool, cyclopts.Parameter(name="--json", negative=())] = False,
    registry: RegistryConfig = RegistryConfig(),
) -> None:
    """List model artifacts in the organization."""
    dn = configured_dreadnode(registry)
    org, client = require_registry_context(dn)
    packages = client.list_models(org)
    _render_package_list(packages, as_json=as_json)


# ---------------------------------------------------------------------------
# get
# ---------------------------------------------------------------------------


@cli.command()
def get(
    ref: str,
    *,
    registry: RegistryConfig = RegistryConfig(),
) -> None:
    """Get details of a model artifact (NAME@VERSION)."""
    dn = configured_dreadnode(registry)
    org, client = require_registry_context(dn)
    name, version = _parse_versioned_ref(ref, field_name="ref")
    package = client.get_model(org, name, version)
    _print_json(package)


# ---------------------------------------------------------------------------
# delete
# ---------------------------------------------------------------------------


@cli.command()
def delete(
    ref: str,
    *,
    registry: RegistryConfig = RegistryConfig(),
) -> None:
    """Delete a model artifact (NAME@VERSION)."""
    dn = configured_dreadnode(registry)
    org, client = require_registry_context(dn)
    name, version = _parse_versioned_ref(ref, field_name="ref")
    client.delete_model(org, name, version)
    print(f"Deleted {org}/{name}@{version}")
