"""Shared config dataclasses and utility functions for the cyclopts CLI."""

import json
import secrets
import time
import typing as t
from dataclasses import dataclass

import cyclopts

if t.TYPE_CHECKING:
    from dreadnode.app.api.models import RewardRecipe

# ---------------------------------------------------------------------------
# Section 1: Config dataclasses
# ---------------------------------------------------------------------------

PLATFORM_GROUP = cyclopts.Group("Platform")
REGISTRY_GROUP = cyclopts.Group("Registry")
SESSION_GROUP = cyclopts.Group("Session")


@cyclopts.Parameter(name="*")
@dataclass
class PlatformConfig:
    """Platform connection flags (--server, --api-key, --organization, --workspace, --project)."""

    server: t.Annotated[
        str | None,
        cyclopts.Parameter(
            group=PLATFORM_GROUP,
            help="Platform API URL override for authentication and hosted job access",
        ),
    ] = None
    api_key: t.Annotated[
        str | None,
        cyclopts.Parameter(group=PLATFORM_GROUP, help="API key for authentication"),
    ] = None
    organization: t.Annotated[
        str | None,
        cyclopts.Parameter(group=PLATFORM_GROUP, help="Organization slug override"),
    ] = None
    workspace: t.Annotated[
        str | None,
        cyclopts.Parameter(group=PLATFORM_GROUP, help="Workspace slug override"),
    ] = None
    project: t.Annotated[
        str | None,
        cyclopts.Parameter(group=PLATFORM_GROUP, help="Project slug override"),
    ] = None


@cyclopts.Parameter(name="*")
@dataclass
class RegistryConfig:
    """Registry connection flags (--server, --api-key, --organization)."""

    server: t.Annotated[
        str | None,
        cyclopts.Parameter(
            group=REGISTRY_GROUP,
            help="Platform API URL override for registry access",
        ),
    ] = None
    api_key: t.Annotated[
        str | None,
        cyclopts.Parameter(group=REGISTRY_GROUP, help="API key for authentication"),
    ] = None
    organization: t.Annotated[
        str | None,
        cyclopts.Parameter(group=REGISTRY_GROUP, help="Organization slug override"),
    ] = None


@cyclopts.Parameter(name="*")
@dataclass
class SessionConfig:
    """Root-level session flags for launching the TUI or headless mode."""

    server: t.Annotated[
        str | None,
        cyclopts.Parameter(
            alias="-s",
            group=SESSION_GROUP,
            help="Runtime server URL override (disables local auto-start; not the platform API)",
        ),
    ] = None
    platform: t.Annotated[
        str | None,
        cyclopts.Parameter(
            alias="-p",
            group=SESSION_GROUP,
            help="Platform API URL override for authentication and profiles",
        ),
    ] = None
    resume: t.Annotated[
        str | None,
        cyclopts.Parameter(
            alias="-r",
            group=SESSION_GROUP,
            help="Resume a previous session by ID (prefix match supported)",
        ),
    ] = None
    model: t.Annotated[
        str | None,
        cyclopts.Parameter(group=SESSION_GROUP, help="Select model at launch"),
    ] = None
    agent: t.Annotated[
        str | None,
        cyclopts.Parameter(group=SESSION_GROUP, help="Select agent at launch"),
    ] = None
    capabilities_dirs: t.Annotated[
        list[str] | None,
        cyclopts.Parameter(
            name="--capabilities-dir",
            group=SESSION_GROUP,
            negative_iterable=(),
            help="Additional capabilities directory (repeatable)",
        ),
    ] = None
    capabilities: t.Annotated[
        list[str] | None,
        cyclopts.Parameter(
            name="--capability",
            group=SESSION_GROUP,
            negative_iterable=(),
            help="Enable specific capability (repeatable, exclusive)",
        ),
    ] = None
    prompt: t.Annotated[
        str | None,
        cyclopts.Parameter(
            group=SESSION_GROUP,
            help="Prompt to send (auto-sends in TUI, executes with --print)",
        ),
    ] = None
    system_prompt: t.Annotated[
        str | None,
        cyclopts.Parameter(
            group=SESSION_GROUP,
            help="Append custom instructions to generated system prompt",
        ),
    ] = None
    print_mode: t.Annotated[
        bool,
        cyclopts.Parameter(
            name="--print",
            group=SESSION_GROUP,
            negative=(),
            help="Headless mode: execute --prompt, print response to stdout, exit",
        ),
    ] = False


# ---------------------------------------------------------------------------
# Section 2: Utility functions
# ---------------------------------------------------------------------------


def configured_dreadnode(config: PlatformConfig | RegistryConfig) -> t.Any:
    """Build a configured Dreadnode instance from a config dataclass."""
    from dreadnode.app.main import Dreadnode

    return Dreadnode().configure(
        server=config.server,
        api_key=config.api_key,
        organization=config.organization,
        workspace=getattr(config, "workspace", None),
        project=getattr(config, "project", None),
    )


def _new_device_login_api_key_name() -> str:
    return f"dreadnode-{secrets.token_hex(3)}"


def _render_profile_context(profile: t.Any) -> str:
    parts = [
        part
        for part in (
            getattr(profile, "default_organization", None),
            getattr(profile, "default_workspace", None),
            getattr(profile, "default_project", None),
        )
        if part
    ]
    return "/".join(parts)


def require_registry_context(dreadnode: t.Any) -> tuple[str, t.Any]:
    if not dreadnode.can_sync:
        raise SystemExit(
            "Registry commands require platform credentials. Configure server, api key, and organization."
        )
    return dreadnode.session.org_key, dreadnode.api


def _jsonable(value: t.Any) -> t.Any:
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    if isinstance(value, list):
        return [_jsonable(item) for item in value]
    if isinstance(value, dict):
        return {key: _jsonable(item) for key, item in value.items()}
    if hasattr(value, "__dict__"):
        return {
            key: _jsonable(item) for key, item in vars(value).items() if not key.startswith("_")
        }
    return value


def _print_json(value: t.Any) -> None:
    print(json.dumps(_jsonable(value), indent=2, sort_keys=True))


def _parse_versioned_ref(value: str, *, field_name: str) -> tuple[str, str]:
    if "@" not in value:
        raise SystemExit(f"{field_name} must be in NAME@VERSION form")
    name, version = value.rsplit("@", 1)
    normalized_name = name.strip().strip("/")
    normalized_version = version.strip().strip("/")
    if not normalized_name or not normalized_version:
        raise SystemExit(f"{field_name} must include both name and version")
    return normalized_name, normalized_version


def _parse_task_ref(value: str, *, field_name: str, organization: str) -> tuple[str, str]:
    normalized_name, version = _parse_versioned_ref(value, field_name=field_name)

    if "/" in normalized_name:
        org_prefix, task_name = normalized_name.split("/", 1)
        normalized_name = task_name.strip().strip("/")
        if org_prefix != organization:
            raise SystemExit(
                f"{field_name} organization prefix must match active organization '{organization}'"
            )

    if version != "latest":
        raise SystemExit(f"{field_name} must use version 'latest' for task refs")

    if not normalized_name or "/" in normalized_name:
        raise SystemExit(f"{field_name} must resolve to a single task name")
    return normalized_name, version


def _parse_json_option(
    value: str | None,
    *,
    field_name: str,
) -> t.Any:
    if value is None:
        return None
    try:
        return json.loads(value)
    except json.JSONDecodeError as exc:
        raise SystemExit(f"{field_name} must be valid JSON") from exc


def _parse_json_object_option(
    value: str | None,
    *,
    field_name: str,
) -> dict[str, t.Any] | None:
    parsed = _parse_json_option(value, field_name=field_name)
    if parsed is None:
        return None
    if not isinstance(parsed, dict):
        raise SystemExit(f"{field_name} must decode to a JSON object")
    return parsed


def _list_all_tasks(client: t.Any, org: str, *, page_size: int = 100) -> list[dict[str, t.Any]]:
    tasks: list[dict[str, t.Any]] = []
    page = 1
    while True:
        payload = client.list_tasks(org, page=page, limit=page_size)
        page_tasks = payload.get("tasks", [])
        if isinstance(page_tasks, list):
            tasks.extend(page_tasks)
        if not payload.get("has_next"):
            return tasks
        page += 1


def require_workspace_context(dreadnode: t.Any, *, label: str) -> tuple[str, str, t.Any]:
    """Require platform credentials and an active workspace. Returns (org, workspace, api)."""
    if not dreadnode.can_sync:
        raise SystemExit(
            f"{label} commands require platform credentials. Configure server, api key, "
            "organization, and workspace."
        )
    session = dreadnode.session
    workspace = getattr(session, "workspace_key", None)
    if not workspace:
        raise SystemExit(f"{label} commands require an active workspace")
    return session.org_key, workspace, dreadnode.api


# Backwards-compatible aliases — all delegate to require_workspace_context
def require_training_context(dreadnode: t.Any) -> tuple[str, str, t.Any]:
    return require_workspace_context(dreadnode, label="Hosted training")


def require_optimization_context(dreadnode: t.Any) -> tuple[str, str, t.Any]:
    return require_workspace_context(dreadnode, label="Hosted optimization")


def require_evaluation_context(dreadnode: t.Any) -> tuple[str, str, t.Any]:
    return require_workspace_context(dreadnode, label="Evaluation")


def _build_optional_reward_recipe(
    reward_recipe: str | None,
    reward_params: str | None,
) -> "RewardRecipe | None":
    from dreadnode.app.api.models import RewardRecipe

    if not reward_recipe:
        return None
    params: dict[str, t.Any] = {}
    if reward_params:
        try:
            raw_params = json.loads(reward_params)
        except json.JSONDecodeError as exc:
            raise SystemExit("--reward-params must be valid JSON") from exc
        if not isinstance(raw_params, dict):
            raise SystemExit("--reward-params must decode to a JSON object")
        params = raw_params
    return RewardRecipe(name=reward_recipe, params=params)


# ---------------------------------------------------------------------------
# Render helpers
# ---------------------------------------------------------------------------

SummaryFn = t.Callable[[dict[str, t.Any]], str]
"""Takes a JSON-serializable dict, returns a one-line human summary."""


def _to_payload(obj: t.Any) -> t.Any:
    """Normalize a response object (Pydantic model or raw dict/list) to JSON-serializable form."""
    if hasattr(obj, "model_dump"):
        return obj.model_dump(mode="json")
    if isinstance(obj, list):
        return [_to_payload(item) for item in obj]
    if isinstance(obj, dict):
        return obj
    if hasattr(obj, "__dict__"):
        return _jsonable(obj)
    return obj


def _render(obj: t.Any, *, as_json: bool, summary: SummaryFn) -> None:
    """Render a single item as JSON or a one-line summary."""
    payload = _to_payload(obj)
    if as_json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        print(summary(payload))


def _render_list(
    obj: t.Any,
    *,
    as_json: bool,
    summary: SummaryFn,
    empty_msg: str,
    items_key: str = "items",
) -> None:
    """Render a paginated list as JSON or per-item summaries."""
    payload = _to_payload(obj)
    if as_json:
        print(json.dumps(payload, indent=2, sort_keys=True))
        return
    items = payload.get(items_key, []) if isinstance(payload, dict) else payload
    if not items:
        print(empty_msg)
        return
    for item in items:
        print(summary(_jsonable(item) if not isinstance(item, dict) else item))


def _render_logs(obj: t.Any, *, as_json: bool) -> None:
    """Render a log response (training or optimization)."""
    payload = _to_payload(obj)
    if as_json:
        print(json.dumps(payload, indent=2, sort_keys=True))
        return
    for entry in payload.get("items", []):
        print(f"{entry['timestamp']} [{entry['level']}] {entry['message']}")


def _render_artifacts(obj: t.Any, *, as_json: bool) -> None:
    """Render an artifacts response (training or optimization)."""
    payload = _to_payload(obj)
    if as_json:
        print(json.dumps(payload, indent=2, sort_keys=True))
        return
    print(json.dumps(payload.get("artifacts", {}), indent=2, sort_keys=True))


# --- Per-domain summary functions ---


def _summarize_training_job(p: dict[str, t.Any]) -> str:
    name = p.get("name") or f"{p.get('backend')}/{p.get('trainer_type')}"
    return f"{p.get('id', 'unknown')} {p.get('status', 'unknown')} {name}"


def _summarize_optimization_job(p: dict[str, t.Any]) -> str:
    name = p.get("name") or f"{p.get('backend')}/{p.get('target_kind')}"
    return f"{p.get('id', 'unknown')} {p.get('status', 'unknown')} {name}"


def _summarize_airt_assessment(p: dict[str, t.Any]) -> str:
    return f"{p.get('id', 'unknown')} {p.get('status', 'unknown')} {p.get('name') or 'unnamed-assessment'}"


def _summarize_airt_report(p: dict[str, t.Any]) -> str:
    return f"{p.get('id', 'unknown')} {p.get('report_type', 'unknown')} {p.get('created_at', 'unknown')}"


def _summarize_world_job(p: dict[str, t.Any]) -> str:
    return f"{p.get('id', 'unknown')} {p.get('status', 'unknown')} {p.get('kind', 'unknown')} {p.get('resource_type') or 'resource'}"


def _summarize_world_manifest(p: dict[str, t.Any]) -> str:
    return f"{p.get('id', 'unknown')} {p.get('preset') or 'custom'} {p.get('name') or 'unnamed-manifest'}"


def _summarize_world_trajectory(p: dict[str, t.Any]) -> str:
    success = p.get("success")
    success_text = "success" if success else "pending" if success is None else "failed"
    return f"{p.get('id', 'unknown')} {success_text} {p.get('goal', 'unknown')}"


def _summarize_package(p: dict[str, t.Any]) -> str:
    name = p.get("full_name") or p.get("name", "unknown")
    version = p.get("latest_version") or p.get("version", "unknown")
    visibility = p.get("visibility", "private")
    return f"{name}@{version} [{visibility}]"


def _summarize_capability(p: dict[str, t.Any]) -> str:
    name = p.get("name", "unknown")
    version = p.get("version", "unknown")
    visibility = "public" if p.get("is_public") else "private"
    description = p.get("description")
    suffix = f" - {description}" if description else ""
    return f"{name}@{version} [{visibility}]{suffix}"


def _summarize_task(p: dict[str, t.Any], *, org: str) -> str:
    name = p.get("name", "unknown")
    version = p.get("version", "unknown")
    visibility = "public" if p.get("is_public") else "private"
    return f"{org}/{name}@{version} [{visibility}]"


def _summarize_evaluation(p: dict[str, t.Any]) -> str:
    return f"{p.get('id', 'unknown')} {p.get('status', 'unknown')} {p.get('name', 'unnamed')}"


def _summarize_runtime(p: dict[str, t.Any]) -> str:
    state = p.get("state", "unknown")
    return f"{p.get('id', 'unknown')} {state} {p.get('name') or p.get('runtime_type', 'unknown')}"


# --- Convenience wrappers (keep call-site imports stable) ---


def _render_training_job(job: t.Any, *, as_json: bool) -> None:
    _render(job, as_json=as_json, summary=_summarize_training_job)


def _render_training_job_list(job_list: t.Any, *, as_json: bool) -> None:
    _render_list(
        job_list,
        as_json=as_json,
        summary=_summarize_training_job,
        empty_msg="No training jobs found",
    )


def _render_training_logs(logs: t.Any, *, as_json: bool) -> None:
    _render_logs(logs, as_json=as_json)


def _render_training_artifacts(artifacts: t.Any, *, as_json: bool) -> None:
    _render_artifacts(artifacts, as_json=as_json)


def _render_optimization_job(job: t.Any, *, as_json: bool) -> None:
    _render(job, as_json=as_json, summary=_summarize_optimization_job)


def _render_optimization_job_list(job_list: t.Any, *, as_json: bool) -> None:
    _render_list(
        job_list,
        as_json=as_json,
        summary=_summarize_optimization_job,
        empty_msg="No optimization jobs found",
    )


def _render_optimization_logs(logs: t.Any, *, as_json: bool) -> None:
    _render_logs(logs, as_json=as_json)


def _render_optimization_artifacts(artifacts: t.Any, *, as_json: bool) -> None:
    _render_artifacts(artifacts, as_json=as_json)


def _render_airt_assessment(assessment: t.Any, *, as_json: bool) -> None:
    _render(assessment, as_json=as_json, summary=_summarize_airt_assessment)


def _render_airt_assessment_list(assessments: t.Any, *, as_json: bool) -> None:
    _render_list(
        assessments,
        as_json=as_json,
        summary=_summarize_airt_assessment,
        empty_msg="No AIRT assessments found",
    )


def _render_airt_reports(reports: t.Any, *, as_json: bool) -> None:
    _render_list(
        reports, as_json=as_json, summary=_summarize_airt_report, empty_msg="No AIRT reports found"
    )


def _render_world_job(job: t.Any, *, as_json: bool) -> None:
    _render(job, as_json=as_json, summary=_summarize_world_job)


def _render_world_job_list(jobs: t.Any, *, as_json: bool) -> None:
    _render_list(
        jobs, as_json=as_json, summary=_summarize_world_job, empty_msg="No Worlds jobs found"
    )


def _render_world_manifest(manifest: t.Any, *, as_json: bool) -> None:
    _render(manifest, as_json=as_json, summary=_summarize_world_manifest)


def _render_world_manifest_list(manifests: t.Any, *, as_json: bool) -> None:
    _render_list(
        manifests,
        as_json=as_json,
        summary=_summarize_world_manifest,
        empty_msg="No Worlds manifests found",
    )


def _render_world_trajectory(trajectory: t.Any, *, as_json: bool) -> None:
    _render(trajectory, as_json=as_json, summary=_summarize_world_trajectory)


def _render_world_trajectory_list(trajectories: t.Any, *, as_json: bool) -> None:
    _render_list(
        trajectories,
        as_json=as_json,
        summary=_summarize_world_trajectory,
        empty_msg="No Worlds trajectories found",
    )


def _render_package_list(packages: t.Any, *, as_json: bool) -> None:
    _render_list(
        packages, as_json=as_json, summary=_summarize_package, empty_msg="No packages found"
    )


def _render_capability_list(capabilities: t.Any, *, as_json: bool) -> None:
    _render_list(
        capabilities,
        as_json=as_json,
        summary=_summarize_capability,
        empty_msg="No capabilities found",
    )


def _render_evaluation(evaluation: t.Any, *, as_json: bool) -> None:
    _render(evaluation, as_json=as_json, summary=_summarize_evaluation)


def _render_evaluation_list(evaluations: t.Any, *, as_json: bool) -> None:
    _render_list(
        evaluations,
        as_json=as_json,
        summary=_summarize_evaluation,
        empty_msg="No evaluations found",
    )


def _render_runtime(runtime: t.Any, *, as_json: bool) -> None:
    _render(runtime, as_json=as_json, summary=_summarize_runtime)


def _render_runtime_list(runtimes: t.Any, *, as_json: bool) -> None:
    _render_list(
        runtimes,
        as_json=as_json,
        summary=_summarize_runtime,
        empty_msg="No runtimes found",
    )


# ---------------------------------------------------------------------------
# Wait / poll helpers
# ---------------------------------------------------------------------------


_TERMINAL_STATUSES = {"completed", "failed", "cancelled"}


def _get_status(obj: t.Any) -> str | None:
    """Extract status from a Pydantic model (.status) or raw dict (.get('status'))."""
    if hasattr(obj, "status"):
        return obj.status
    if isinstance(obj, dict):
        return obj.get("status")
    return None


def _wait_for_job(
    poll_fn: t.Callable[[], t.Any],
    *,
    job_id: str,
    label: str,
    poll_interval_sec: float,
    timeout_sec: float | None,
) -> t.Any:
    """Generic poll-until-terminal loop. ``poll_fn`` takes no args and returns the job."""
    deadline = None if timeout_sec is None else time.monotonic() + timeout_sec
    while True:
        job = poll_fn()
        if _get_status(job) in _TERMINAL_STATUSES:
            return job
        if deadline is not None and time.monotonic() >= deadline:
            raise SystemExit(f"Timed out waiting for {label} job {job_id}")
        time.sleep(poll_interval_sec)


def _wait_for_training_job(
    client: t.Any,
    *,
    org: str,
    workspace: str,
    job_id: str,
    poll_interval_sec: float,
    timeout_sec: float | None,
) -> t.Any:
    return _wait_for_job(
        lambda: client.get_training_job(org, workspace, job_id),
        job_id=job_id,
        label="training",
        poll_interval_sec=poll_interval_sec,
        timeout_sec=timeout_sec,
    )


def _wait_for_optimization_job(
    client: t.Any,
    *,
    org: str,
    workspace: str,
    job_id: str,
    poll_interval_sec: float,
    timeout_sec: float | None,
) -> t.Any:
    return _wait_for_job(
        lambda: client.get_optimization_job(org, workspace, job_id),
        job_id=job_id,
        label="optimization",
        poll_interval_sec=poll_interval_sec,
        timeout_sec=timeout_sec,
    )


def _wait_for_world_job(
    client: t.Any,
    *,
    org: str,
    workspace: str,
    job_id: str,
    poll_interval_sec: float,
    timeout_sec: float | None,
) -> dict[str, t.Any]:
    return _wait_for_job(
        lambda: client.get_world_job(org, workspace, job_id),
        job_id=job_id,
        label="world",
        poll_interval_sec=poll_interval_sec,
        timeout_sec=timeout_sec,
    )


def _sync_progress(name: str, status: str, error: str | None) -> None:
    if status == "uploaded":
        print(f"  OK   {name}")
    elif status == "skipped":
        print(f"  SKIP {name}")
    elif status == "failed":
        print(f"  FAIL {name}: {error}")
