"""Root cyclopts App with top-level commands (tui, login, serve)."""

import importlib.metadata
import os
import sys
import time
import typing as t

import cyclopts

from dreadnode.app.cli.airt import cli as airt_cli
from dreadnode.app.cli.capability import cli as capability_cli
from dreadnode.app.cli.dataset import cli as dataset_cli
from dreadnode.app.cli.evaluation import cli as evaluation_cli
from dreadnode.app.cli.model import cli as model_cli
from dreadnode.app.cli.optimize import cli as optimize_cli
from dreadnode.app.cli.runtime import cli as runtime_cli
from dreadnode.app.cli.shared import (
    SessionConfig,
    _new_device_login_api_key_name,
    _render_profile_context,
)
from dreadnode.app.cli.task import cli as task_cli
from dreadnode.app.cli.train import cli as train_cli
from dreadnode.app.cli.worlds import cli as worlds_cli

# ---------------------------------------------------------------------------
# Root app
# ---------------------------------------------------------------------------

cli = cyclopts.App(
    name="dreadnode",
    help="Dreadnode CLI — agent development and platform tooling.",
    version=importlib.metadata.version("dreadnode"),
    help_on_error=True,
)
cli.register_install_completion_command()

# Move meta flags (--help, --version, --install-completion) out of Commands
cli["--help"].group = "Meta"
cli["--version"].group = "Meta"
cli["--install-completion"].group = "Meta"

# ---------------------------------------------------------------------------
# Subcommands
# ---------------------------------------------------------------------------

cli.command(airt_cli)
cli.command(capability_cli)
cli.command(dataset_cli)
cli.command(evaluation_cli)
cli.command(model_cli)
cli.command(optimize_cli)
cli.command(runtime_cli)
cli.command(task_cli)
cli.command(train_cli)
cli.command(worlds_cli)


# ---------------------------------------------------------------------------
# Default command — handles bare `dn` (no subcommand) or `dn --model x ...`
# ---------------------------------------------------------------------------


@cli.default
def _default(*, session: SessionConfig = SessionConfig()) -> None:
    """Launch the TUI (default) or headless print mode."""
    if session.print_mode:
        _run_print(session)
    else:
        _run_tui(session)


# ---------------------------------------------------------------------------
# Internal TUI / print helpers
# ---------------------------------------------------------------------------


def _run_tui(session: SessionConfig) -> None:
    from dreadnode.app.tui.app import DreadnodeTextualApp

    app = DreadnodeTextualApp(
        server_url=session.server,
        platform_url=session.platform,
        resume_session_id=session.resume,
        initial_model=session.model,
        initial_agent=session.agent,
        initial_prompt=session.prompt,
        capabilities_dirs=session.capabilities_dirs,
        capabilities=session.capabilities,
        system_prompt=session.system_prompt,
    )
    app.run()

    if app.active_session_id:
        print(
            f"\nTo resume this session, run: dreadnode --resume {app.active_session_id}",
            file=sys.stderr,
        )


def _run_print(session: SessionConfig) -> None:
    import asyncio

    from dreadnode.app.print_mode import run_print_mode

    if not session.prompt:
        print("Error: --print requires --prompt", file=sys.stderr)
        raise SystemExit(1)

    asyncio.run(
        run_print_mode(
            prompt=session.prompt,
            model=session.model,
            agent=session.agent,
            capabilities_dirs=session.capabilities_dirs,
            capabilities=session.capabilities,
            system_prompt=session.system_prompt,
            server_url=session.server,
            platform_url=session.platform,
        )
    )


# ---------------------------------------------------------------------------
# login command
# ---------------------------------------------------------------------------


@cli.command()
def login(
    api_key: t.Annotated[
        str | None,
        cyclopts.Parameter(
            help="API key to save locally. Omit to use browser-based device login.",
        ),
    ] = None,
    *,
    server: t.Annotated[
        str | None,
        cyclopts.Parameter(help="Platform API URL override for login and profile storage"),
    ] = None,
    organization: str | None = None,
    workspace: str | None = None,
    project: str | None = None,
    poll_interval_sec: t.Annotated[
        float,
        cyclopts.Parameter(help="Polling interval for browser-based device login"),
    ] = 2.0,
    timeout_sec: t.Annotated[
        float | None,
        cyclopts.Parameter(help="Optional timeout for browser-based device login"),
    ] = None,
) -> None:
    """Authenticate with the Dreadnode platform."""
    from dreadnode.app.tui.commands import DEFAULT_PLATFORM_URL, _login_with_api_key

    server_url = (server or DEFAULT_PLATFORM_URL).rstrip("/")

    try:
        if api_key:
            profile = _login_with_api_key(
                server_url,
                api_key,
                organization=organization,
                workspace=workspace,
                project=project,
            )
        else:
            profile = _login_with_device_code(
                server_url=server_url,
                organization=organization,
                workspace=workspace,
                project=project,
                poll_interval_sec=poll_interval_sec,
                timeout_sec=timeout_sec,
            )
    except (RuntimeError, ValueError) as exc:
        raise SystemExit(str(exc)) from exc

    identity = getattr(profile, "username", None) or getattr(profile, "user_key", None) or "unknown"
    print(f"Logged in to {profile.url} as {identity}")
    context = _render_profile_context(profile)
    if context:
        print(f"Active context: {context}")


# ---------------------------------------------------------------------------
# Device-code login helper
# ---------------------------------------------------------------------------


def _login_with_device_code(
    *,
    server_url: str,
    organization: str | None,
    workspace: str | None,
    project: str | None,
    poll_interval_sec: float,
    timeout_sec: float | None,
) -> t.Any:
    from dreadnode.app.api.client import ApiClient
    from dreadnode.app.tui.commands import _login_with_api_key

    api = ApiClient(server_url)
    payload = api.create_device_code()

    user_code = payload.get("user_code")
    device_code = payload.get("device_code")
    if not isinstance(user_code, str) or not user_code:
        raise SystemExit("Device login response missing user code")
    if not isinstance(device_code, str) or not device_code:
        raise SystemExit("Device login response missing device code")

    verification_url = payload.get("verification_url")
    if not isinstance(verification_url, str) or not verification_url:
        verification_url = f"{server_url}/login/device?code={user_code}"

    print(f"Open this URL in your browser: {verification_url}")
    print(f"Code: {user_code}")
    print("Waiting for browser authorization...")

    timeout_deadline: float | None = None
    if timeout_sec is not None:
        timeout_deadline = time.monotonic() + timeout_sec
    expires_in = payload.get("expires_in")
    if isinstance(expires_in, (int, float)):
        expires_deadline = time.monotonic() + float(expires_in)
        timeout_deadline = (
            expires_deadline
            if timeout_deadline is None
            else min(timeout_deadline, expires_deadline)
        )

    consecutive_failures = 0
    while True:
        if timeout_deadline is not None and time.monotonic() >= timeout_deadline:
            raise SystemExit("Device login timed out before authorization completed")

        try:
            status_code, poll_payload = api.poll_device_code(device_code)
        except Exception as exc:
            consecutive_failures += 1
            if consecutive_failures >= 3:
                raise SystemExit(f"Device login polling failed: {exc}") from exc
            time.sleep(poll_interval_sec)
            continue

        if status_code >= 500:
            consecutive_failures += 1
            if consecutive_failures >= 3:
                raise SystemExit("Device login polling failed")
            time.sleep(poll_interval_sec)
            continue

        consecutive_failures = 0
        if poll_payload and poll_payload.get("user_id"):
            break
        time.sleep(poll_interval_sec)

    tokens = api.exchange_device_code(device_code)
    access_token = tokens.get("access_token")
    if not isinstance(access_token, str) or not access_token:
        raise SystemExit("Device login did not return an access token")

    created = api.create_api_key_with_jwt(
        access_token,
        _new_device_login_api_key_name(),
        allow_self_revoke=True,
    )
    api_key = created.get("key") or created.get("api_key")
    if not isinstance(api_key, str) or not api_key:
        raise SystemExit("Device login failed to create an API key")

    return _login_with_api_key(
        server_url,
        api_key,
        organization=organization,
        workspace=workspace,
        project=project,
    )


# ---------------------------------------------------------------------------
# serve command
# ---------------------------------------------------------------------------


@cli.command()
def serve(
    *,
    host: t.Annotated[str | None, cyclopts.Parameter(help="Server bind host")] = None,
    port: t.Annotated[int | None, cyclopts.Parameter(help="Server bind port")] = None,
    working_dir: t.Annotated[
        str | None, cyclopts.Parameter(help="Working directory for the server")
    ] = None,
    platform_server: t.Annotated[
        str | None, cyclopts.Parameter(help="Platform API URL override")
    ] = None,
    api_key: t.Annotated[
        str | None, cyclopts.Parameter(help="API key for platform authentication")
    ] = None,
    organization: t.Annotated[
        str | None, cyclopts.Parameter(help="Organization slug override")
    ] = None,
    workspace: t.Annotated[str | None, cyclopts.Parameter(help="Workspace slug override")] = None,
    project: t.Annotated[str | None, cyclopts.Parameter(help="Project slug override")] = None,
    verbose: t.Annotated[
        bool,
        cyclopts.Parameter(negative=(), help="Enable verbose trace logging for the local server"),
    ] = False,
) -> None:
    """Host a runtime server for the TUI."""
    from dreadnode.app.server import run_server
    from dreadnode.core.log import configure_server_logging

    configure_server_logging("trace" if verbose else None)
    if working_dir:
        os.chdir(working_dir)
    run_server(
        host=host,
        port=port,
        server=platform_server,
        api_key=api_key,
        organization=organization,
        workspace=workspace,
        project=project,
    )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def run(argv: list[str] | None = None) -> None:
    """CLI entry point."""
    try:
        if argv is not None:
            cli(argv)
        else:
            cli()
    except SystemExit as exc:
        if exc.code != 0:
            raise
