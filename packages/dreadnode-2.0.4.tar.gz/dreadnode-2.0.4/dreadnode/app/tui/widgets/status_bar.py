"""Zone 4 — Global nav bar with runtime health and app navigation.

Always visible, even on pushed full-screen views. Shows:
  Left:  ✓ local · org/workspace         (or ✓ remote · abc123, ✗ error)
  Right: ^B sessions  ^P capabilities  ^R runtimes  ^T traces  ^E evals
"""

from __future__ import annotations

from rich.cells import cell_len
from rich.text import Text
from textual.reactive import reactive
from textual.widgets import Static

from dreadnode.app.tui.theme import (
    ACCENT,
    BG,
    ERROR,
    FG_FAINTEST,
    FG_MUTED,
    WARNING,
)


def _pad_right(left: Text, right: Text, width: int, padding: int = 4) -> Text:
    """Join left and right text with space-fill to target width."""
    gap = max(width - cell_len(left.plain) - cell_len(right.plain) - padding, 1)
    result = Text(no_wrap=True, overflow="ellipsis")
    result.append_text(left)
    result.append(" " * gap)
    result.append_text(right)
    return result


class StatusBar(Static):
    """Single-line global nav bar — runtime health + navigation."""

    DEFAULT_CSS = f"""
    StatusBar {{
        height: auto;
        max-height: 2;
        padding: 1 2 0 2;
        color: {FG_FAINTEST};
        background: {BG};
    }}
    """

    connection: reactive[str] = reactive("local")
    workspace_label: reactive[str] = reactive("")
    runtime_health: reactive[str] = reactive("")
    update_available: reactive[str] = reactive("")
    remote_info: reactive[str] = reactive("")

    def render(self) -> Text:
        w = self.size.width

        # === Left: runtime health ===
        left = Text(no_wrap=True, overflow="ellipsis")

        if self.runtime_health:
            left.append("✗ ", style=ERROR)
            left.append(self.runtime_health, style=ERROR)
        else:
            left.append("✓ ", style=ACCENT)
            left.append(self.connection, style=FG_MUTED)

        if self.workspace_label and not self.runtime_health:
            left.append(" · ", style=FG_FAINTEST)
            left.append(self.workspace_label, style=FG_MUTED)

        if self.update_available:
            left.append(" · ", style=FG_FAINTEST)
            left.append(f"↑ {self.update_available}", style=WARNING)

        # === Right: navigation shortcuts ===
        # At narrow widths, drop labels and show keys only
        left_len = cell_len(left.plain)
        nav_items = [
            ("^P", "capabilities"),
            ("^B", "sessions"),
            ("^O", "workspaces"),
            ("^R", "runtimes"),
            ("^T", "traces"),
            ("^E", "evals"),
        ]
        # Full labels need ~60 chars, keys-only needs ~20
        show_labels = (w - left_len) > 65

        right = Text(no_wrap=True)
        for i, (key, label) in enumerate(nav_items):
            right.append(key, style=FG_FAINTEST)
            if show_labels:
                right.append(f" {label}", style=FG_FAINTEST)
            if i < len(nav_items) - 1:
                right.append("  ", style=FG_FAINTEST)

        return _pad_right(left, right, w)
