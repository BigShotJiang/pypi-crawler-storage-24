"""MCP server status dialog — shows health of all MCP servers."""

from __future__ import annotations

import typing as t

from rich.text import Text
from textual.widgets.option_list import Option

from dreadnode.app.tui.theme import ACCENT, ERROR, FG, FG_FAINTEST, FG_MUTED, WARNING
from dreadnode.app.tui.widgets.overlay_mixin import OverlayMixin


class McpDialog(OverlayMixin):
    """Popup dialog triggered by /mcp — lists MCP server health status."""

    def __init__(self, **kwargs: t.Any) -> None:
        super().__init__(**kwargs)

    def show_servers(self, servers: list[dict[str, str | None]]) -> None:
        """Populate with server data and show.

        Each dict has keys: name, status, error, detail.
        """
        self.clear_options()

        if not servers:
            self.add_option(
                Option(
                    Text("No MCP servers configured", style=f"italic {FG_MUTED}"),
                    disabled=True,
                )
            )
            self.border_title = "MCP Servers"
            self.add_class("-visible")
            return

        for s in servers:
            line = Text()
            status = s.get("status", "?")

            # Status dot
            if status == "ok":
                line.append(" \u25cf ", style=ACCENT)
            elif status == "error":
                line.append(" \u2717 ", style=ERROR)
            else:
                line.append(" \u25cf ", style=WARNING)

            # Server name
            line.append(s.get("name", "?"), style=f"bold {FG}")

            # Status detail
            if s.get("error"):
                detail = str(s["error"] or "")
                if s.get("detail"):
                    detail += f" ({s['detail']})"
                line.append(f"  \u00b7  {detail}", style=FG_MUTED)
            elif status == "ok":
                line.append("  \u00b7  connected", style=FG_FAINTEST)
            else:
                line.append(f"  \u00b7  {status}", style=FG_MUTED)

            self.add_option(Option(line, id=s.get("name"), disabled=True))

        self.border_title = f"MCP Servers ({len(servers)})"
        self.highlighted = 0
        self.add_class("-visible")
