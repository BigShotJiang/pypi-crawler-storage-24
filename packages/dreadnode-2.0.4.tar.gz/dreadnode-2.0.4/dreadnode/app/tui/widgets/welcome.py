"""Welcome screen shown on startup before first interaction."""

from __future__ import annotations

from typing import TYPE_CHECKING

from rich.text import Text
from textual.reactive import reactive
from textual.widgets import Static

from dreadnode.app.tui.theme import (
    BG,
    BRAND,
    FG_FAINTEST,
    FG_MUTED,
    WARNING,
    pick_logo,
)

if TYPE_CHECKING:
    from dreadnode.app.tui.update_check import UpdateInfo


class Welcome(Static):
    """Centered welcome screen with branding and key hints."""

    DEFAULT_CSS = f"""
    Welcome {{
        height: 1fr;
        content-align: center middle;
        background: {BG};
        padding: 0 2;
    }}
    Welcome.-hidden {{
        display: none;
    }}
    """

    version: reactive[str] = reactive("")
    working_dir: reactive[str] = reactive("")
    update_info: reactive[UpdateInfo | None] = reactive(None)

    def render(self) -> Text:
        w = self.size.width
        t = Text(justify="center")

        # Logo — biggest variant that fits, falling back to plain text
        logo = pick_logo(w)
        if logo is not None:
            for line in logo.splitlines():
                t.append(line, style=BRAND)
                t.append("\n")
        else:
            t.append("DREADNODE", style=f"bold {BRAND}")
            t.append("\n")

        # Version
        if self.version:
            t.append(f"\n{self.version}\n", style=FG_FAINTEST)
        t.append("\n")

        # Update banner
        if self.update_info is not None:
            t.append(
                f"Update available: {self.update_info.current} → {self.update_info.latest}\n",
                style=f"bold {WARNING}",
            )
            t.append("Run /update\n", style=FG_MUTED)
            t.append("\n")

        # Tagline
        t.append("Type a message to get started.\n", style=FG_MUTED)
        t.append(
            "Browse capabilities (Ctrl+P) to add skills, tools, and agents.\n\n", style=FG_MUTED
        )

        # Key hints — adapt column width to available space
        hints = [
            ("Enter", "send message"),
            ("\\ + Enter", "new line"),
            ("/", "commands"),
            ("@", "mention agent"),
            ("!", "shell mode"),
            ("Ctrl+P", "capabilities"),
            ("?", "help"),
            ("Esc", "dismiss / clear / interrupt"),
        ]

        col = min(16, max(w // 4, 10))
        for key, desc in hints:
            t.append(f"  {key:<{col}}", style=BRAND)
            t.append(f"{desc}\n", style=FG_FAINTEST)

        # Working dir
        if self.working_dir:
            t.append(f"\n{self.working_dir}", style=FG_FAINTEST)

        return t

    def dismiss(self) -> None:
        """Hide the welcome screen."""
        self.add_class("-hidden")

    @property
    def is_visible(self) -> bool:
        return not self.has_class("-hidden")
