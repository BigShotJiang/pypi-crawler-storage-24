"""Multi-line composer with Enter to submit and overlay-aware key routing.

Multiline input methods (matching Claude Code / Droid conventions):
  - \\ + Enter  — universal, works in all terminals
  - Shift+Enter — works in terminals that send distinct escape sequence
  - Ctrl+J      — line feed, always works

Overlay navigation (when slash/mention overlay is visible):
  - Up/Down     — navigate overlay items
  - Tab/Enter   — select highlighted item
  - Esc         — dismiss overlay

Shell mode:
  - Text starting with '!' enters shell mode (visual indicator)
"""

from __future__ import annotations

import re
import typing as t
from dataclasses import dataclass

from rich.segment import Segment
from rich.style import Style
from textual import on
from textual.binding import Binding
from textual.message import Message
from textual.reactive import reactive
from textual.strip import Strip
from textual.widgets import TextArea

if t.TYPE_CHECKING:
    from textual.events import Key, Paste

    from dreadnode.app.tui.widgets.overlay_mixin import OverlayMixin


@dataclass(slots=True)
class PastedSegment:
    content: str
    line_count: int


_PASTE_RE = re.compile(r"\[pasted ~(\d+) lines?\]")


class ComposerInput(TextArea):
    """Multi-line input with overlay-aware key routing."""

    BINDINGS: t.ClassVar[list[Binding]] = [
        Binding("ctrl+a", "app.select_agent", "Agent", show=False),
        Binding("ctrl+k", "app.select_model", "Model", show=False),
        Binding("ctrl+shift+k", "app.cycle_effort", "Effort", show=False),
        Binding("ctrl+b", "app.open_sessions", "Sessions", show=False),
        Binding("ctrl+p", "app.open_capabilities", "Caps", show=False),
        Binding("ctrl+r", "app.open_runtimes", "Runs", show=False),
        Binding("ctrl+t", "app.open_traces", "Traces", show=False),
        Binding("ctrl+e", "app.open_evaluations", "Evals", show=False),
        Binding("f5", "app.open_console", "Console", show=False),
        Binding("ctrl+n", "app.new_session", "New", show=False),
        Binding("ctrl+c", "app.request_quit", "Quit", show=False),
        # Alt/Option key bindings (Kitty keyboard protocol — Ghostty, WezTerm, Kitty)
        Binding("alt+backspace", "delete_word_left", "Delete word left", show=False),
        Binding("alt+delete", "delete_word_right", "Delete word right", show=False),
        Binding("alt+left", "cursor_word_left", "Word left", show=False),
        Binding("alt+right", "cursor_word_right", "Word right", show=False),
        Binding("alt+shift+left", "cursor_word_left(True)", "Select word left", show=False),
        Binding("alt+shift+right", "cursor_word_right(True)", "Select word right", show=False),
        Binding("alt+enter", "newline", "New line", show=False),
    ]

    class Submitted(Message):
        """Posted when the user presses Enter to submit."""

        def __init__(self, text_area: ComposerInput, value: str) -> None:
            self.value = value
            self.input = text_area
            super().__init__()

    class HelpRequested(Message):
        """Posted when ? is pressed in an empty composer."""

    DEFAULT_CSS = """
    ComposerInput {
        height: auto;
        min-height: 1;
        max-height: 6;
        border: none;
        background: transparent;
        padding: 0;
        width: 1fr;
    }
    """

    shell_mode: reactive[bool] = reactive(False)

    def __init__(self, placeholder: str = "", **kwargs: t.Any) -> None:
        kwargs.setdefault("highlight_cursor_line", False)
        super().__init__(**kwargs)
        self._placeholder = placeholder
        self._pastes: list[PastedSegment] = []

    @property
    def value(self) -> str:
        """Compatibility with Input API."""
        return self.text

    @value.setter
    def value(self, text: str) -> None:
        self.load_text(text)

    def watch_shell_mode(self, shell: bool) -> None:
        """Toggle shell mode visual class."""
        self.set_class(shell, "-shell")

    def action_newline(self) -> None:
        """Insert a newline at the cursor."""
        self.insert("\n")

    def clear_pastes(self) -> None:
        """Clear tracked pasted segments."""
        self._pastes.clear()

    async def _on_paste(self, event: Paste) -> None:
        pasted = event.text
        line_count = pasted.count("\n") + 1
        if line_count < 2:
            await super()._on_paste(event)
            return

        event.prevent_default()
        event.stop()
        self._pastes.append(PastedSegment(content=pasted, line_count=line_count))
        placeholder = f"[pasted ~{line_count} line{'s' if line_count != 1 else ''}]"
        self.insert(placeholder)

    def _resolve_pastes(self, display_text: str) -> str:
        pastes = iter(self._pastes)

        def replacer(match: re.Match[str]) -> str:
            segment = next(pastes, None)
            return segment.content if segment else match.group(0)

        return _PASTE_RE.sub(replacer, display_text)

    def _sync_pastes(self, display_text: str) -> None:
        placeholder_count = len(_PASTE_RE.findall(display_text))
        if placeholder_count < len(self._pastes):
            self._pastes = self._pastes[:placeholder_count]

    @on(TextArea.Changed)
    def _on_text_changed(self, event: TextArea.Changed) -> None:
        self._sync_pastes(event.text_area.text)

    def _paste_style(self) -> Style:
        if self.app:
            color = self.app.get_css_variables().get("fg-muted")
            if color:
                return Style(color=color)
        return Style(dim=True)

    def _on_key(self, event: Key) -> None:  # ty: ignore[invalid-method-override]
        overlay = self._get_active_overlay()

        # === Overlay-aware key routing ===
        if overlay is not None:
            if event.key in ("up", "down"):
                event.prevent_default()
                event.stop()
                overlay.move_highlight(-1 if event.key == "up" else 1)
                return

            if event.key in ("tab", "enter"):
                event.prevent_default()
                event.stop()
                overlay.select_highlighted()
                return

            if event.key == "escape":
                event.prevent_default()
                event.stop()
                overlay.hide()
                return

        # === Multiline: \ + Enter ===
        if event.key == "enter":
            raw = self.text
            if raw.endswith("\\"):
                # Replace trailing \ with newline
                event.prevent_default()
                event.stop()
                self.load_text(raw[:-1] + "\n")
                # Move cursor to end
                self.move_cursor_relative(rows=9999, columns=9999)
                return

            # Normal Enter = submit (if text is non-empty)
            resolved = self._resolve_pastes(raw)
            text = resolved.strip()
            event.prevent_default()
            event.stop()
            if text:
                self.post_message(self.Submitted(self, text))
                self.load_text("")
                self.clear_pastes()
            return

        # === Multiline: Shift+Enter, Ctrl+J ===
        if event.key in ("shift+enter", "ctrl+j"):
            # Let TextArea handle it naturally (inserts newline)
            return

        # === ? toggles help when composer is empty ===
        if event.key == "question_mark" and not self.text:
            event.prevent_default()
            event.stop()
            # Bubble up to app — post a custom message
            self.post_message(self.HelpRequested())
            return

        super()._on_key(event)  # ty: ignore[unused-awaitable]

        # Update shell mode based on content
        self.shell_mode = self.text.startswith("!")

    def _render_line(self, y: int) -> Strip:
        strip = super()._render_line(y)
        if y >= self.document.line_count:
            return strip
        line_text = self.document.get_line(y)
        matches = list(_PASTE_RE.finditer(line_text))
        if not matches:
            return strip

        ranges = [(match.start(), match.end()) for match in matches]
        cuts = sorted({pos for start, end in ranges for pos in (start, end)} | {strip.cell_length})
        if not cuts:
            return strip

        style = self._paste_style()
        segments = list(strip._segments)
        partitions = list(Segment.divide(segments, cuts))
        boundaries = [0, *cuts, strip.cell_length]
        styled_segments: list[Segment] = []

        for idx, segment_group in enumerate(partitions):
            start = boundaries[idx]
            end = boundaries[idx + 1]
            is_placeholder = any(
                start >= rng_start and end <= rng_end for rng_start, rng_end in ranges
            )
            if is_placeholder:
                styled_segments.extend(Segment.apply_style(segment_group, post_style=style))
            else:
                styled_segments.extend(segment_group)

        return Strip(Segment.simplify(styled_segments), strip.cell_length)

    def _get_active_overlay(self) -> OverlayMixin | None:
        from textual.css.query import NoMatches

        from dreadnode.app.tui.screens.model_picker import ModelPickerOverlay
        from dreadnode.app.tui.widgets.agent_dialog import AgentDialog
        from dreadnode.app.tui.widgets.mcp_dialog import McpDialog
        from dreadnode.app.tui.widgets.mention_overlay import MentionOverlay
        from dreadnode.app.tui.widgets.skills_dialog import SkillsDialog
        from dreadnode.app.tui.widgets.slash_overlay import SlashOverlay
        from dreadnode.app.tui.widgets.tools_dialog import ToolsDialog

        try:
            for overlay_type in (
                SlashOverlay,
                MentionOverlay,
                ModelPickerOverlay,
                AgentDialog,
                McpDialog,
                SkillsDialog,
                ToolsDialog,
            ):
                for overlay in self.screen.query(overlay_type):
                    if overlay.is_visible:
                        return overlay
        except NoMatches:
            pass
        return None
