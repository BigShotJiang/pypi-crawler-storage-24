"""A widget for displaying a tool call."""

from __future__ import annotations

from typing import TYPE_CHECKING

from rich.text import Text
from textual.widget import Widget

from dreadnode.app.tui.theme import ACCENT, FG_FAINTEST, FG_MUTED

if TYPE_CHECKING:
    from rich.console import RenderableType


class ToolCall(Widget):
    """A widget to display a tool call."""

    def __init__(
        self,
        *,
        name: str,
        details: str,
        meta: str | None = None,
        **kwargs,
    ) -> None:
        super().__init__(**kwargs)
        self.tool_name = name
        self.details = details
        self.meta = meta

    def render(self) -> RenderableType:
        """Render the tool call."""
        import re

        text = Text()
        # First line: prepend "│ " in FG_FAINTEST
        text.append("│ ", style=FG_FAINTEST)

        # Parse name and args from "name(args)" format
        match = re.match(r"^([a-zA-Z0-9_-]+)\((.*)\)$", self.tool_name)
        if match:
            name, args = match.groups()
            text.append(f"{name}", style=f"{ACCENT}")
            text.append(f"({args})", style=FG_MUTED)
        else:
            text.append(f"{self.tool_name}", style=f"{ACCENT}")

        if self.meta:
            text.append("\n│ ↳ ", style=FG_FAINTEST)
            text.append(f"{self.meta}", style=FG_FAINTEST)

        if self.details:
            lines = self.details.splitlines()
            prefix = "\n│   " if self.meta else "\n│ ↳ "
            text.append(f"{prefix}{lines[0]}", style=FG_FAINTEST)
            for line in lines[1:]:
                text.append(f"\n│   {line}", style=FG_FAINTEST)

        return text
