from __future__ import annotations

import asyncio
import contextlib
import json
import os
import shlex
import subprocess
import tempfile
import time
import typing as t
from dataclasses import dataclass, field
from pathlib import Path

import httpx
from loguru import logger

DEFAULT_SERVER_HOST = str(os.environ.get("DREADNODE_SERVER_HOST", "127.0.0.1"))
DEFAULT_SERVER_PORT = int(os.environ.get("DREADNODE_SERVER_PORT", "8787"))
DEFAULT_SERVER_URL = f"http://{DEFAULT_SERVER_HOST}:{DEFAULT_SERVER_PORT}"
DEFAULT_MODEL = "anthropic/claude-sonnet-4-20250514"
DEFAULT_START_TIMEOUT_S = 20.0
_TERMINAL_CHAT_EVENT_TYPES = frozenset({"agentend", "error"})

_SENTINEL = object()

if t.TYPE_CHECKING:
    from dreadnode.app.api.models import HumanInputResponse
    from dreadnode.app.server.session import ServerConfig


class _AsyncQueueStream(httpx.AsyncByteStream):
    """Async byte stream backed by an asyncio.Queue."""

    def __init__(self, queue: asyncio.Queue[bytes | object]) -> None:
        self._queue = queue

    async def __aiter__(self) -> t.AsyncIterator[bytes]:
        while True:
            chunk = await self._queue.get()
            if chunk is _SENTINEL:
                break
            assert isinstance(chunk, bytes)
            yield chunk


class StreamingASGITransport(httpx.AsyncBaseTransport):
    """ASGI transport that streams response bodies incrementally.

    ``httpx.ASGITransport`` buffers the entire response before returning,
    which breaks SSE streaming.  This transport pushes body chunks through
    an ``asyncio.Queue`` so the caller receives them as the ASGI app yields
    them.
    """

    def __init__(
        self,
        app: t.Any,
        *,
        raise_app_exceptions: bool = True,
        root_path: str = "",
        client: tuple[str, int] = ("127.0.0.1", 0),
    ) -> None:
        self.app = app
        self.raise_app_exceptions = raise_app_exceptions
        self.root_path = root_path
        self.client = client

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        scope = {
            "type": "http",
            "asgi": {"version": "3.0"},
            "http_version": "1.1",
            "method": request.method,
            "headers": [(k.lower(), v) for (k, v) in request.headers.raw],
            "scheme": request.url.scheme,
            "path": request.url.path,
            "raw_path": request.url.raw_path.split(b"?")[0],
            "query_string": request.url.query,
            "server": (request.url.host, request.url.port),
            "client": self.client,
            "root_path": self.root_path,
        }

        # Request body
        request_body_chunks = request.stream.__aiter__()  # ty: ignore[unresolved-attribute]
        request_complete = False
        response_complete = asyncio.Event()

        # Response state — filled by send()
        status_code: int | None = None
        response_headers: list[tuple[bytes, bytes]] | None = None
        body_queue: asyncio.Queue[bytes | object] = asyncio.Queue()

        async def receive() -> dict[str, t.Any]:
            nonlocal request_complete
            if request_complete:
                await response_complete.wait()
                return {"type": "http.disconnect"}
            try:
                body = await request_body_chunks.__anext__()
            except StopAsyncIteration:
                request_complete = True
                return {"type": "http.request", "body": b"", "more_body": False}
            return {"type": "http.request", "body": body, "more_body": True}

        async def send(message: dict[str, t.Any]) -> None:
            nonlocal status_code, response_headers
            if message["type"] == "http.response.start":
                status_code = message["status"]
                response_headers = message.get("headers", [])
            elif message["type"] == "http.response.body":
                body = message.get("body", b"")
                more_body = message.get("more_body", False)
                if body and request.method != "HEAD":
                    await body_queue.put(body)
                if not more_body:
                    await body_queue.put(_SENTINEL)
                    response_complete.set()

        async def run_app() -> None:
            try:
                await self.app(scope, receive, send)
            except Exception:
                if self.raise_app_exceptions:
                    await body_queue.put(_SENTINEL)
                    response_complete.set()
                    raise
                # Fallback: synthesize 500
                logger.opt(exception=True).debug("ASGI app exception suppressed, synthesizing 500")
                nonlocal status_code, response_headers
                if status_code is None:
                    status_code = 500
                if response_headers is None:
                    response_headers = []
                await body_queue.put(_SENTINEL)
                response_complete.set()

        # Start the ASGI app in the background so we can return the
        # response as soon as headers arrive and stream body chunks.
        app_task = asyncio.create_task(run_app())

        # Wait until the ASGI app has sent http.response.start
        while status_code is None:
            if app_task.done():
                app_task.result()  # re-raise if crashed
                break
            await asyncio.sleep(0)

        assert status_code is not None
        assert response_headers is not None

        stream = _AsyncQueueStream(body_queue)

        return httpx.Response(
            status_code,
            headers=response_headers,
            stream=stream,
        )


@dataclass(slots=True)
class CapabilityAgentInfo:
    """Agent metadata returned by the runtime API."""

    name: str
    description: str
    model: str
    capability: str

    @classmethod
    def from_dict(cls, data: dict[str, t.Any]) -> CapabilityAgentInfo:
        return cls(
            name=str(data.get("name", "")),
            description=str(data.get("description", "")),
            model=str(data.get("model", "inherit")),
            capability=str(data.get("capability", "")),
        )


@dataclass(slots=True)
class CapabilityInfo:
    """Capability metadata returned by the runtime API."""

    name: str
    display_name: str
    canonical_name: str | None = None
    entry_agent: str | None = None
    skills_paths: list[str] = field(default_factory=list)
    agents: list[CapabilityAgentInfo] = field(default_factory=list)
    source: str | None = None
    provenance: str | None = None
    version: str | None = None
    description: str | None = None
    author: dict[str, t.Any] | None = None
    license: str | None = None
    origin: dict[str, t.Any] | None = None
    enabled: bool = True
    binding_id: str | None = None
    components: list[dict[str, t.Any]] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, t.Any]) -> CapabilityInfo:
        return cls(
            name=str(data.get("name", "")),
            display_name=str(data.get("display_name") or data.get("name", "")),
            canonical_name=(
                str(data["canonical_name"]) if data.get("canonical_name") is not None else None
            ),
            entry_agent=str(data["entry_agent"]) if data.get("entry_agent") else None,
            skills_paths=[str(path) for path in data.get("skills_paths", [])],
            agents=[
                CapabilityAgentInfo.from_dict(item)
                for item in data.get("agents", [])
                if isinstance(item, dict)
            ],
            source=data.get("source"),
            provenance=(str(data["provenance"]) if data.get("provenance") is not None else None),
            version=data.get("version"),
            description=str(data["description"]) if data.get("description") is not None else None,
            author=data.get("author") if isinstance(data.get("author"), dict) else None,
            license=str(data["license"]) if data.get("license") is not None else None,
            origin=data.get("origin") if isinstance(data.get("origin"), dict) else None,
            enabled=data.get("enabled", True),
            binding_id=data.get("binding_id"),
            components=data.get("components", []),
        )


@dataclass(slots=True)
class SkillInfo:
    """Skill metadata from the server."""

    name: str
    description: str

    @staticmethod
    def from_dict(data: dict[str, t.Any]) -> SkillInfo:
        return SkillInfo(name=str(data["name"]), description=str(data.get("description", "")))


@dataclass(slots=True)
class RuntimeInfo:
    """Summary of the connected server runtime."""

    status: str
    version: str
    runtime_id: str | None = None
    host_type: str = "local"
    working_dir: str = ""
    default_capability: str | None = None
    capabilities: list[CapabilityInfo] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: dict[str, t.Any]) -> RuntimeInfo:
        return cls(
            status=str(data.get("status", "unknown")),
            version=str(data.get("version", "unknown")),
            runtime_id=(str(data["runtime_id"]) if data.get("runtime_id") else None),
            host_type=str(data.get("host_type", "local")),
            working_dir=str(data.get("working_dir", "")),
            default_capability=(
                str(data["default_capability"]) if data.get("default_capability") else None
            ),
            capabilities=[
                CapabilityInfo.from_dict(item)
                for item in data.get("capabilities", [])
                if isinstance(item, dict)
            ],
        )


@dataclass(slots=True)
class SessionInfo:
    """Server-side session metadata."""

    session_id: str
    project: str | None
    created_at: str
    message_count: int = 0
    session_dir: str | None = None
    capability: str | None = None
    agent: str | None = None
    title: str | None = None
    preview: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, t.Any]) -> SessionInfo:
        return cls(
            session_id=str(data.get("session_id", "")),
            project=str(data["project"]) if data.get("project") else None,
            created_at=str(data.get("created_at", "")),
            message_count=int(data.get("message_count", 0)),
            session_dir=str(data["session_dir"]) if data.get("session_dir") else None,
            capability=str(data["capability"]) if data.get("capability") else None,
            agent=str(data["agent"]) if data.get("agent") else None,
            title=str(data["title"]) if data.get("title") else None,
            preview=str(data["preview"]) if data.get("preview") else None,
        )


class RuntimeServerClient:
    """Async client for the Dreadnode runtime server."""

    def __init__(
        self,
        server_url: str | None = None,
        auto_start: bool = True,
        transport: httpx.AsyncBaseTransport | None = None,
        capability_dirs: list[str] | None = None,
        enabled_capabilities: list[str] | None = None,
        system_prompt_append: str | None = None,
        auth_token: str | None = None,
    ) -> None:
        self.server_url = (server_url or DEFAULT_SERVER_URL).rstrip("/")
        self.auto_start = auto_start
        self._in_process = auto_start and transport is None and server_url is None
        self._auth_token = auth_token
        self._client = httpx.AsyncClient(
            base_url=self.server_url,
            timeout=None,  # noqa: S113 - long-lived local runtime client intentionally disables global timeout
            transport=transport,
            headers=self._build_auth_headers(),
        )
        self._owned_process: subprocess.Popen[t.Any] | None = None
        self._owned_log_file: t.Any = None
        self._started = False
        self._platform_server: str | None = None
        self._platform_api_key: str | None = None
        self._platform_organization: str | None = None
        self._platform_workspace: str | None = None
        self._platform_project: str | None = None
        # CLI overrides threaded to initialize_app()
        self._capability_dirs = capability_dirs
        self._enabled_capabilities = enabled_capabilities
        self._system_prompt_append = system_prompt_append

    def _build_auth_headers(self) -> dict[str, str]:
        if self._auth_token:
            return {"Authorization": f"Bearer {self._auth_token}"}
        return {}

    def set_platform_profile(self, profile: ServerConfig) -> None:
        """Store the active platform profile for local server startup."""
        self._platform_server = profile.url
        self._platform_api_key = profile.api_key
        self._platform_organization = profile.default_organization
        self._platform_workspace = profile.default_workspace
        self._platform_project = profile.default_project

    def clear_platform_profile(self) -> None:
        """Clear any stored platform profile for local-only runtime startup."""
        self._platform_server = None
        self._platform_api_key = None
        self._platform_organization = None
        self._platform_workspace = None
        self._platform_project = None

    @property
    def is_started(self) -> bool:
        """Whether the runtime client has an active started connection."""
        return self._started

    async def _start_in_process(self) -> None:
        """Initialize the FastAPI app in-process and connect via ASGI transport."""
        logger.info("Starting in-process runtime server")
        from dreadnode.app.server.app import _warm_litellm, initialize_app
        from dreadnode.app.server.app import app as server_app

        # Warm litellm in background — the lifespan does this for uvicorn,
        # but in-process mode skips lifespan events. Fire before initialize_app
        # so the ~2s import overlaps with app init and boot network calls.
        loop = asyncio.get_running_loop()
        loop.run_in_executor(None, _warm_litellm)

        await asyncio.to_thread(
            initialize_app,
            server=self._platform_server,
            api_key=self._platform_api_key,
            organization=self._platform_organization,
            workspace=self._platform_workspace,
            project=self._platform_project,
            load_profile=False,
            capability_dirs=self._capability_dirs,
            enabled_capabilities=self._enabled_capabilities,
            system_prompt_append=self._system_prompt_append,
        )

        self._client = httpx.AsyncClient(
            transport=StreamingASGITransport(app=server_app),
            base_url=self.server_url,
            timeout=None,  # noqa: S113 - in-process transport should not enforce request timeouts
            headers=self._build_auth_headers(),
        )

    async def start(self) -> None:
        """Ensure the target server is reachable, auto-starting the default local one if needed."""
        if self._started:
            return

        if self._in_process:
            logger.info("Server start | mode=in-process | url={}", self.server_url)
            await self._start_in_process()
            self._started = True
            return

        if await self._is_healthy():
            logger.info("Server start | mode=external | url={}", self.server_url)
            self._started = True
            return

        if not self.auto_start:
            logger.error("Server unreachable | url={} | auto_start=false", self.server_url)
            raise RuntimeError(
                "Could not connect to Dreadnode runtime server at "
                f"{self.server_url}. The TUI --server flag overrides the local runtime "
                "endpoint, not the platform API. Omit --server to auto-start the local "
                "runtime, and use /login --server <url> to set the platform API."
            )

        logger.info("Server start | mode=spawned | url={}", self.server_url)
        self._spawn_local_server()
        await self._wait_until_healthy()
        self._started = True

    async def close(self) -> None:
        """Close network resources and any owned local server process."""
        logger.info("Closing runtime client")
        await self._client.aclose()

        if self._in_process:
            from dreadnode.app.server.app import reset_app_state

            reset_app_state()
            logger.debug("In-process server state reset")
            return

        if self._owned_process is not None and self._owned_process.poll() is None:
            logger.info("Terminating spawned server | pid={}", self._owned_process.pid)
            self._owned_process.terminate()
            with contextlib.suppress(subprocess.TimeoutExpired):
                self._owned_process.wait(timeout=5)
            if self._owned_process.poll() is None:
                logger.warning(
                    "Server did not terminate gracefully, killing | pid={}", self._owned_process.pid
                )
                self._owned_process.kill()
                with contextlib.suppress(subprocess.TimeoutExpired):
                    self._owned_process.wait(timeout=2)

        if self._owned_log_file is not None:
            log_name = self._owned_log_file.name
            self._owned_log_file.close()
            with contextlib.suppress(OSError):
                Path(log_name).unlink()

    async def restart(self) -> None:
        """Restart the server so it picks up fresh platform context."""
        logger.info("Restarting runtime server | in_process={}", self._in_process)
        if self._in_process:
            await self._client.aclose()

            from dreadnode.app.server.app import reset_app_state

            reset_app_state()

            self._started = False
            await self._start_in_process()
            self._started = True
            return

        await self.close()
        self._owned_process = None
        self._owned_log_file = None
        self._started = False
        self._client = httpx.AsyncClient(
            base_url=self.server_url,
            timeout=None,  # noqa: S113 - long-lived local runtime client intentionally disables global timeout
            headers=self._build_auth_headers(),
        )
        await self.start()

    async def fetch_runtime_info(self) -> RuntimeInfo:
        """Fetch runtime metadata from the connected server."""
        logger.debug("Fetching runtime info")
        await self.start()
        response = await self._client.get("/api/runtime")
        response.raise_for_status()
        info = RuntimeInfo.from_dict(response.json())
        logger.debug(
            "Runtime info | status={} | version={} | capabilities={}",
            info.status,
            info.version,
            len(info.capabilities),
        )
        return info

    async def fetch_tools(self) -> list[dict[str, str]]:
        """Fetch available tools from runtime."""
        logger.debug("Fetching tools")
        await self.start()
        resp = await self._client.get("/api/tools")
        resp.raise_for_status()
        tools = resp.json().get("tools", [])
        logger.debug("Fetched tools | count={}", len(tools))
        return tools

    async def fetch_skills(self) -> list[SkillInfo]:
        """Fetch available skills from runtime."""
        logger.debug("Fetching skills")
        await self.start()
        resp = await self._client.get("/api/skills")
        resp.raise_for_status()
        skills = [SkillInfo.from_dict(s) for s in resp.json().get("skills", [])]
        logger.debug("Fetched skills | count={}", len(skills))
        return skills

    async def fetch_skill_content(self, name: str) -> str:
        """Fetch rendered skill content by name.

        Returns the same rich content the load_skill tool would produce,
        including skill files listing, allowed tools, and base directory.
        """
        logger.debug("Fetching skill content | name={}", name)
        await self.start()
        resp = await self._client.get(f"/api/skills/{name}")
        resp.raise_for_status()
        data = resp.json()
        return str(data.get("rendered", "") or data.get("instructions", ""))

    async def reload_capabilities(self) -> RuntimeInfo:
        """Tell the server to re-discover capabilities and return updated runtime info."""
        logger.info("Reloading capabilities")
        await self.start()
        response = await self._client.post("/api/reload")
        response.raise_for_status()
        info = RuntimeInfo.from_dict(response.json())
        logger.info("Capabilities reloaded | count={}", len(info.capabilities))
        return info

    async def list_sessions(self) -> list[SessionInfo]:
        """List active sessions from the connected server."""
        logger.debug("Listing sessions")
        await self.start()
        response = await self._client.get("/api/sessions")
        response.raise_for_status()
        sessions = [SessionInfo.from_dict(item) for item in response.json()]
        logger.debug("Listed sessions | count={}", len(sessions))
        return sessions

    async def create_session(
        self,
        *,
        agent: str | None = None,
        model: str | None = None,
        project: str | None = None,
        generate_params_extra: dict[str, t.Any] | None = None,
    ) -> SessionInfo:
        """Create or resolve a session runtime on the server."""
        logger.debug("Creating session | agent={} | model={} | project={}", agent, model, project)
        await self.start()
        payload: dict[str, t.Any] = {}
        if agent is not None:
            payload["agent"] = agent
        if model is not None:
            payload["model"] = model
        resolved_project = project or self._platform_project
        if resolved_project is not None:
            payload["project"] = resolved_project
        if generate_params_extra is not None:
            payload["generate_params_extra"] = generate_params_extra
        response = await self._client.post("/api/sessions", json=payload)
        response.raise_for_status()
        session = SessionInfo.from_dict(response.json())
        logger.info(
            "Session created | session_id={} | capability={}",
            session.session_id[:8],
            session.capability,
        )
        return session

    async def reset_session(self, session_id: str) -> None:
        """Reset a server session."""
        logger.info("Resetting session | session_id={}", session_id[:8])
        await self.start()
        response = await self._client.post(
            f"/api/sessions/{session_id}/reset",
        )
        response.raise_for_status()

    async def compact_session(self, session_id: str, *, guidance: str = "") -> dict[str, t.Any]:
        """Request manual compaction of a session."""
        logger.info("Compacting session | session_id={}", session_id[:8])
        await self.start()
        payload: dict[str, t.Any] = {}
        if guidance:
            payload["guidance"] = guidance
        response = await self._client.post(
            f"/api/sessions/{session_id}/compact",
            json=payload,
        )
        response.raise_for_status()
        return response.json()

    async def fetch_session_messages(self, session_id: str) -> list[dict[str, t.Any]]:
        """Fetch conversation messages for a session."""
        logger.debug("Fetching session messages | session_id={}", session_id[:8])
        await self.start()
        response = await self._client.get(f"/api/sessions/{session_id}/messages")
        response.raise_for_status()
        messages = response.json()
        logger.debug(
            "Fetched session messages | session_id={} | count={}", session_id[:8], len(messages)
        )
        return messages

    async def delete_session(self, session_id: str) -> None:
        """Delete a server session."""
        logger.info("Deleting session | session_id={}", session_id[:8])
        await self.start()
        response = await self._client.delete(
            f"/api/sessions/{session_id}",
        )
        response.raise_for_status()

    async def stream_chat(
        self,
        *,
        session_id: str,
        message: str,
        model: str | None = None,
        agent: str | None = None,
        reset: bool = False,
        generate_params_extra: dict[str, t.Any] | None = None,
    ) -> t.AsyncIterator[dict[str, t.Any]]:
        """Stream SSE chat events for one session turn."""
        logger.debug(
            "SSE stream starting | session={} | model={} | agent={}", session_id[:8], model, agent
        )
        await self.start()
        payload: dict[str, t.Any] = {"sessionId": session_id, "message": message, "reset": reset}
        if model is not None:
            payload["model"] = model
        if agent is not None:
            payload["agent"] = agent
        if generate_params_extra is not None:
            payload["generate_params_extra"] = generate_params_extra
        event_count = 0
        async with self._client.stream(
            "POST",
            "/api/chat",
            json=payload,
        ) as response:
            if response.status_code >= 400:
                body = ""
                with contextlib.suppress(Exception):
                    body = (await response.aread()).decode(errors="replace")
                logger.error(
                    "SSE stream HTTP error | session={} | status={} | body={}",
                    session_id[:8],
                    response.status_code,
                    body[:200] if body else "",
                )
                raise httpx.HTTPStatusError(
                    f"HTTP {response.status_code}: {body or response.reason_phrase}",
                    request=response.request,
                    response=response,
                )
            async for line in response.aiter_lines():
                if not line or not line.startswith("data: "):
                    continue
                raw_data = line[6:].strip()
                if not raw_data:
                    continue
                try:
                    parsed = json.loads(raw_data)
                except json.JSONDecodeError:
                    logger.warning(
                        "SSE JSON parse error | session={} | data={}",
                        session_id[:8],
                        raw_data[:100],
                    )
                    continue
                if isinstance(parsed, dict):
                    event_count += 1
                    event_type = str(parsed.get("type", "")).lower()
                    logger.debug("SSE event | type={} | session={}", event_type, session_id[:8])
                    yield parsed
                    if event_type in _TERMINAL_CHAT_EVENT_TYPES:
                        break
        logger.debug("SSE stream complete | session={} | events={}", session_id[:8], event_count)

    async def send_permission_response(
        self,
        session_id: str,
        request_id: str,
        decision: str,
    ) -> None:
        """Send a permission decision back to the server via the chat endpoint."""
        logger.debug(
            "Sending permission response | session={} | request_id={} | decision={}",
            session_id[:8],
            request_id,
            decision,
        )
        await self.start()
        response = await self._client.post(
            "/api/chat",
            json={
                "sessionId": session_id,
                "message": "",
                "permissionResponse": {
                    "request_id": request_id,
                    "decision": decision,
                },
            },
        )
        response.raise_for_status()

    async def send_human_input_response(
        self,
        session_id: str,
        response: HumanInputResponse,
    ) -> None:
        """Send a human input response back to the server via the chat endpoint."""
        logger.debug("Sending human input response | session={}", session_id[:8])
        await self.start()
        payload = {
            "sessionId": session_id,
            "message": "",
            "humanInputResponse": response.model_dump(),
        }
        response_obj = await self._client.post("/api/chat", json=payload)
        response_obj.raise_for_status()

    async def list_files(
        self,
        path: str | None = None,
        depth: int = 10,
    ) -> list[dict[str, t.Any]]:
        """List files in a directory on the server."""
        logger.debug("Listing files | path={} | depth={}", path, depth)
        await self.start()
        params: dict[str, t.Any] = {"depth": depth}
        if path:
            params["path"] = path
        response = await self._client.get("/api/files", params=params)
        response.raise_for_status()
        return response.json().get("entries", [])

    async def read_file(self, path: str) -> str:
        """Read a file's content from the server."""
        logger.debug("Reading file | path={}", path)
        await self.start()
        response = await self._client.get("/api/files/read", params={"path": path})
        response.raise_for_status()
        return response.json().get("content", "")

    async def execute_shell(
        self,
        command: str,
        *,
        cwd: str | None = None,
        timeout: int = 30,
    ) -> dict[str, t.Any]:
        """Execute a shell command on the server."""
        logger.debug("Executing shell command | cwd={} | timeout={}", cwd, timeout)
        await self.start()
        response = await self._client.post(
            "/api/shell",
            params={"command": command, "timeout": timeout, **({"cwd": cwd} if cwd else {})},
        )
        response.raise_for_status()
        return response.json()

    async def _is_healthy(self) -> bool:
        try:
            response = await self._client.get("/api/health", timeout=1.0)
        except httpx.HTTPError as exc:
            logger.debug("Health check failed | error={}", exc)
            return False
        healthy = response.status_code == 200
        logger.debug("Health check | status={} | healthy={}", response.status_code, healthy)
        return healthy

    async def _wait_until_healthy(self, timeout_s: float = DEFAULT_START_TIMEOUT_S) -> None:
        deadline = time.monotonic() + timeout_s
        attempts = 0
        start_time = time.monotonic()
        while time.monotonic() < deadline:
            attempts += 1
            if self._owned_process is not None and self._owned_process.poll() is not None:
                logger.error(
                    "Spawned server exited early | exit_code={} | attempts={}",
                    self._owned_process.returncode,
                    attempts,
                )
                log_tail = self._read_log_tail()
                details = f"\n\n{log_tail}" if log_tail else ""
                raise RuntimeError(
                    f"Local Dreadnode server exited with status {self._owned_process.returncode}.{details}"
                )
            if await self._is_healthy():
                elapsed = time.monotonic() - start_time
                logger.info("Server healthy | attempts={} | elapsed={:.1f}s", attempts, elapsed)
                return
            await asyncio.sleep(0.1)

        elapsed = time.monotonic() - start_time
        logger.error(
            "Server health timeout | url={} | attempts={} | elapsed={:.1f}s",
            self.server_url,
            attempts,
            elapsed,
        )
        log_tail = self._read_log_tail()
        details = f"\n\n{log_tail}" if log_tail else ""
        raise RuntimeError(
            f"Timed out waiting for local Dreadnode server at {self.server_url}.{details}"
        )

    def _spawn_local_server(self) -> None:
        """Spawn the agent server as a subprocess."""
        command = [
            "uv",
            "run",
            "dreadnode",
            "serve",
            "--host",
            DEFAULT_SERVER_HOST,
            "--port",
            str(DEFAULT_SERVER_PORT),
        ]
        if self._platform_server:
            command.extend(["--platform-server", shlex.quote(self._platform_server)])
        if self._platform_api_key:
            command.extend(["--api-key", shlex.quote(self._platform_api_key)])
        if self._platform_organization:
            command.extend(["--organization", shlex.quote(self._platform_organization)])
        if self._platform_workspace:
            command.extend(["--workspace", shlex.quote(self._platform_workspace)])
        if self._platform_project:
            command.extend(["--project", shlex.quote(self._platform_project)])

        self._owned_log_file = tempfile.NamedTemporaryFile(  # noqa: SIM115 - manually owned across subprocess lifecycle
            mode="w+",
            encoding="utf-8",
            prefix="dreadnode-tui-server-",
            suffix=".log",
            delete=False,
        )
        self._owned_process = subprocess.Popen(  # noqa: S603 - command is assembled from fixed local runtime arguments
            command,
            stdout=self._owned_log_file,
            stderr=subprocess.STDOUT,
            env=os.environ.copy(),
        )
        logger.info(
            "Spawned local server | pid={} | cmd={} | log={}",
            self._owned_process.pid,
            " ".join(command),
            self._owned_log_file.name,
        )

    def _read_log_tail(self, max_chars: int = 4000) -> str:
        if self._owned_log_file is None:
            return ""
        with contextlib.suppress(OSError):
            return Path(self._owned_log_file.name).read_text(encoding="utf-8")[-max_chars:].strip()
        return ""
