"""Provider-based variant registry for thinking/reasoning effort levels.

Maps (provider, effort_label) → provider-specific API params that get
passed through GenerateParams.extra → LiteLLM acompletion() kwargs.

Provider is inferred from the model string. The platform catalog's
"reasoning" capability gates which models actually support variants.
When catalog is unavailable, variants are offered optimistically —
LiteLLM's drop_params:true silently drops unsupported params.
"""

from __future__ import annotations

import typing as t

# ---------------------------------------------------------------------------
# Provider → effort → API params
# ---------------------------------------------------------------------------

_ANTHROPIC_VARIANTS: dict[str, dict[str, t.Any]] = {
    "low": {"thinking": {"type": "adaptive"}, "effort": "low"},
    "medium": {"thinking": {"type": "adaptive"}, "effort": "medium"},
    "high": {"thinking": {"type": "adaptive"}, "effort": "high"},
    "max": {"thinking": {"type": "adaptive"}, "effort": "max"},
}

_OPENAI_VARIANTS: dict[str, dict[str, t.Any]] = {
    "low": {"reasoning_effort": "low"},
    "medium": {"reasoning_effort": "medium"},
    "high": {"reasoning_effort": "high"},
}

_GOOGLE_VARIANTS: dict[str, dict[str, t.Any]] = {
    "high": {"thinking_config": {"include_thoughts": True, "thinking_budget": 16000}},
    "max": {"thinking_config": {"include_thoughts": True, "thinking_budget": 24576}},
}

_PROVIDER_VARIANTS: dict[str, dict[str, dict[str, t.Any]]] = {
    "anthropic": _ANTHROPIC_VARIANTS,
    "openai": _OPENAI_VARIANTS,
    "google": _GOOGLE_VARIANTS,
}

# ---------------------------------------------------------------------------
# Model string → provider
# ---------------------------------------------------------------------------

# Known providers (for explicit provider/ prefix validation)
_KNOWN_PROVIDERS = {"anthropic", "openai", "google", "groq"}

# Known model prefixes that map to providers without explicit provider/ prefix
_BARE_MODEL_PROVIDERS: list[tuple[str, str]] = [
    ("claude-", "anthropic"),
    ("gemini-", "google"),
    ("gpt-", "openai"),
    ("o1-", "openai"),
    ("o3-", "openai"),
    ("o4-", "openai"),
]

# dn/ prefix models → real provider (platform-hosted via LiteLLM proxy)
_DN_PREFIX_PROVIDERS: list[tuple[str, str]] = [
    ("dn/claude-", "anthropic"),
    ("dn/gpt-", "openai"),
    ("dn/gemini-", "google"),
    ("dn/o1-", "openai"),
    ("dn/o3-", "openai"),
    ("dn/o4-", "openai"),
]


def infer_provider(model: str) -> str | None:
    """Infer the LLM provider from a model identifier string.

    Handles formats: "provider/model", "dn/model", "model" (bare).
    """
    lower = model.lower()

    # Explicit provider/ prefix
    if "/" in lower and not lower.startswith("dn/"):
        provider = lower.split("/", 1)[0]
        # Normalize gemini → google
        if provider == "gemini":
            provider = "google"
        # Only return known providers
        if provider in _KNOWN_PROVIDERS:
            return provider
        return None

    # dn/ prefix (platform proxy)
    for prefix, provider in _DN_PREFIX_PROVIDERS:
        if lower.startswith(prefix):
            return provider

    # Bare model name
    for prefix, provider in _BARE_MODEL_PROVIDERS:
        if lower.startswith(prefix):
            return provider

    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def get_variants(
    model: str,
    *,
    reasoning: bool | None = None,
) -> dict[str, dict[str, t.Any]]:
    """Return available effort variants for a model.

    Args:
        model: Model identifier string (e.g. "anthropic/claude-opus-4-6")
        reasoning: Whether model supports reasoning (from platform catalog).
            True = yes, return provider variants.
            False = no, return empty dict.
            None = unknown (no catalog), optimistically return provider variants.
    """
    if reasoning is False:
        return {}

    provider = infer_provider(model)
    if provider is None:
        return {}

    return dict(_PROVIDER_VARIANTS.get(provider, {}))


def cycle_variant(
    variants: dict[str, dict[str, t.Any]],
    current: str | None,
) -> str | None:
    """Advance to the next variant label, wrapping to None after last."""
    if not variants:
        return None
    keys = list(variants.keys())
    if current is None:
        return keys[0]
    try:
        idx = keys.index(current)
    except ValueError:
        return keys[0]
    next_idx = idx + 1
    if next_idx >= len(keys):
        return None
    return keys[next_idx]


# ---------------------------------------------------------------------------
# Human-friendly display names
# ---------------------------------------------------------------------------

# Map model ID substrings → short display names.
# Order: more specific patterns first so longest match wins naturally.
_MODEL_DISPLAY_NAMES: dict[str, str] = {
    # Anthropic — versioned (e.g. claude-opus-4-6) and base (e.g. claude-sonnet-4-20250514)
    "claude-opus-4-6": "Opus 4.6",
    "claude-sonnet-4-5": "Sonnet 4.5",
    "claude-haiku-4-5": "Haiku 4.5",
    "claude-haiku-3-5": "Haiku 3.5",
    "claude-sonnet-3-5": "Sonnet 3.5",
    "claude-opus-4": "Opus 4",
    "claude-sonnet-4": "Sonnet 4",
    "claude-haiku-4": "Haiku 4",
    # OpenAI
    "gpt-5.2": "GPT-5.2",
    "gpt-5-nano": "GPT-5 Nano",
    "gpt-4.1-mini": "GPT-4.1 Mini",
    "gpt-4.1-nano": "GPT-4.1 Nano",
    "gpt-4.1": "GPT-4.1",
    "gpt-4o-mini": "GPT-4o Mini",
    "gpt-4o": "GPT-4o",
    "o3-mini": "o3 Mini",
    "o4-mini": "o4 Mini",
    "o3": "o3",
    # Google
    "gemini-2.5-pro": "Gemini 2.5 Pro",
    "gemini-2.5-flash": "Gemini 2.5 Flash",
    "gemini-2.0-flash": "Gemini 2.0 Flash",
}

# Ordered list of common model IDs for the model picker fallback.
KNOWN_MODELS: list[str] = [
    "anthropic/claude-opus-4-6",
    "anthropic/claude-sonnet-4-5",
    "openai/gpt-4.1",
    "openai/gpt-4.1-mini",
    "openai/gpt-4.1-nano",
    "openai/o3",
    "openai/o4-mini",
    "gemini/gemini-2.5-pro",
    "gemini/gemini-2.5-flash",
]


def _strip_provider(model: str) -> str:
    """Strip provider prefix (e.g. 'anthropic/', 'dn/') from a model string."""
    if "/" in model:
        return model.split("/", 1)[1]
    return model


def display_name(model: str) -> str:
    """Return a short human-friendly display name for a model.

    Strips the provider prefix, then looks up the longest matching
    substring in ``_MODEL_DISPLAY_NAMES``.  Falls back to the
    stripped model ID when no match is found.
    """
    bare = _strip_provider(model).lower()

    best_key: str | None = None
    for key in _MODEL_DISPLAY_NAMES:
        if key in bare:
            if best_key is None or len(key) > len(best_key):
                best_key = key

    if best_key is not None:
        return _MODEL_DISPLAY_NAMES[best_key]

    return _strip_provider(model)


def display_name_with_effort(model: str, effort: str | None) -> str:
    """Return display name optionally suffixed with the effort level.

    Example: ``"Opus 4.6 (High)"`` when *effort* is ``"high"``.
    Returns plain ``display_name(model)`` when *effort* is None or empty.
    """
    name = display_name(model)
    if effort:
        return f"{name} ({effort.capitalize()})"
    return name
