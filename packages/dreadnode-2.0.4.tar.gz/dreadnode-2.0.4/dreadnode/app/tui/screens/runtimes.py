"""Runtimes Browser screen -- discover, manage, and connect to workspace runtimes.

Single-column layout matching the capabilities screen pattern:
  List view:   header -> summary -> scrollable item list with cursor
  Detail view: runtime info -> action list with cursor
  Enter/c/s:   drill in or quick-action from list
  Esc:         detail->list or dismiss
"""

from __future__ import annotations

import asyncio
import typing as t
from datetime import datetime, timezone

from loguru import logger
from rich.text import Text
from textual import events, work
from textual.containers import VerticalScroll
from textual.widgets import Static

from dreadnode.app.tui.screens.base import DreadnodeScreen
from dreadnode.app.tui.theme import (
    ACCENT,
    ERROR,
    FG,
    FG_FAINTEST,
    FG_MUTED,
    FG_SUBTLE,
    INFO,
    SUCCESS,
    TEAL,
    WARNING,
)

if t.TYPE_CHECKING:
    from textual.app import ComposeResult
    from textual.events import Key
    from textual.timer import Timer

    from dreadnode.app.api.client import ApiClient
    from dreadnode.app.tui.client import RuntimeInfo
    from dreadnode.app.tui.connection import RuntimeConnectionManager


# ── Helpers ──────────────────────────────────────────────────────────────────

_PAUSE_REASONS: dict[str, str] = {
    "timeout": "timed out",
    "user": "by user",
    "insufficient_credits": "out of credits",
    "member_limit_exceeded": "member limit",
}

_STATE_ORDER = {"running": 0, "paused": 1, "idle": 2}


def _fmt_duration(seconds: int) -> str:
    if seconds < 60:
        return f"{seconds}s"
    minutes = seconds // 60
    if minutes < 60:
        return f"{minutes}m"
    hours = minutes // 60
    mins = minutes % 60
    if hours < 24:
        return f"{hours}h{mins:02d}m" if mins else f"{hours}h"
    days = hours // 24
    remaining_hours = hours % 24
    if remaining_hours:
        return f"{days}d {remaining_hours}h"
    return f"{days}d"


def _expires_seconds(ts: str | datetime | None) -> int | None:
    """Seconds until expiration, or None if unknown."""
    if ts is None:
        return None
    if isinstance(ts, str):
        try:
            dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        except ValueError:
            return None
    else:
        dt = ts
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return int((dt - datetime.now(tz=timezone.utc)).total_seconds())


def _expires_label(seconds: int | None) -> str:
    if seconds is None:
        return ""
    if seconds <= 0:
        return "expired"
    return _fmt_duration(seconds)


def _expires_style(seconds: int | None) -> str:
    """Color urgency: red < 15m, yellow < 1h, default otherwise."""
    if seconds is None:
        return FG_SUBTLE
    if seconds <= 0:
        return ERROR
    if seconds < 900:  # 15 minutes
        return ERROR
    if seconds < 3600:  # 1 hour
        return WARNING
    return FG_SUBTLE


def _fmt_timestamp(ts: str | datetime | None) -> str:
    if ts is None:
        return ""
    if isinstance(ts, str):
        try:
            dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        except ValueError:
            return ts[:19]
    else:
        dt = ts
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def _relative_time(ts: str | datetime | None) -> str:
    """Human-friendly relative time like '3h ago' or 'just now'."""
    if ts is None:
        return ""
    if isinstance(ts, str):
        try:
            dt = datetime.fromisoformat(ts.replace("Z", "+00:00"))
        except ValueError:
            return ""
    else:
        dt = ts
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    delta = int((datetime.now(tz=timezone.utc) - dt).total_seconds())
    if delta < 60:
        return "just now"
    if delta < 3600:
        return f"{delta // 60}m ago"
    if delta < 86400:
        return f"{delta // 3600}h ago"
    return f"{delta // 86400}d ago"


_STATE_STYLE: dict[str, tuple[str, str]] = {
    "running": (SUCCESS, "●"),
    "paused": (WARNING, "●"),
    "idle": (FG_FAINTEST, "◯"),
}


def _state_dot_and_style(state: str) -> tuple[str, str]:
    return _STATE_STYLE.get(state, (FG_FAINTEST, "◯"))


def _build_actions(
    runtime: dict[str, t.Any],
    *,
    is_connected: bool,
    is_any_remote: bool,
) -> list[tuple[str, str]]:
    """Return (action_id, label) pairs relevant to this runtime's state."""
    state = runtime.get("status", "unknown")
    actions: list[tuple[str, str]] = []

    if state == "idle":
        actions.append(("start", "Start runtime"))
    elif state == "running":
        if is_connected:
            actions.append(("disconnect", "Disconnect"))
        else:
            actions.append(("connect", "Connect to runtime"))
        actions.append(("pause", "Pause runtime"))
        actions.append(("keepalive", "Extend expiration (+5 min)"))
    elif state == "paused":
        actions.append(("resume", "Resume runtime"))

    if state in ("running", "paused"):
        actions.append(("logs", "View server logs"))
        actions.append(("reset", "Reset (destroy sandbox)"))

    if is_any_remote and not is_connected:
        actions.append(("disconnect_other", "Disconnect from current remote"))

    return actions


# ── Main screen ──────────────────────────────────────────────────────────────


class RuntimeScreen(DreadnodeScreen):
    """Full-screen runtime manager -- browse, connect, manage."""

    def __init__(
        self,
        api: ApiClient,
        org: str,
        workspace: str,
        connection_manager: RuntimeConnectionManager | None = None,
        **kwargs: t.Any,
    ) -> None:
        super().__init__(**kwargs)
        self._api = api
        self._org = org
        self._workspace = workspace
        self._connection_manager = connection_manager

        self._runtimes: list[dict[str, t.Any]] = []
        self._project_names: dict[str, str] = {}  # project_id -> name
        self._refresh_timer: Timer | None = None

        # View state
        self._view: str = "list"  # "list", "detail", or "logs"
        self._cursor: int = 0
        self._action_cursor: int = 0
        self._selected_runtime: dict[str, t.Any] | None = None
        self._current_actions: list[tuple[str, str]] = []
        self._detail_notice: tuple[str, str] | None = None
        self._logs_content: str | None = None

    # ── Connected runtime helpers ────────────────────────────────────────

    @property
    def _connected_id(self) -> str | None:
        if self._connection_manager:
            return self._connection_manager.connected_runtime_id
        return None

    @property
    def _is_any_remote(self) -> bool:
        if self._connection_manager:
            return self._connection_manager.is_remote
        return False

    @property
    def _remote_info(self) -> RuntimeInfo | None:
        if self._connection_manager:
            return self._connection_manager.remote_runtime_info
        return None

    def _project_name(self, runtime: dict[str, t.Any]) -> str:
        """Resolve project name from runtime data, falling back to cached or short ID."""
        # Prefer project_name/project_key from API response (no extra call needed)
        name = runtime.get("project_name") or runtime.get("project_key")
        if name:
            return name
        # Fall back to cached resolution
        project_id = str(runtime.get("project_id", ""))
        if not project_id:
            return ""
        return self._project_names.get(project_id, project_id[:8])

    # ── Compose ──────────────────────────────────────────────────────────

    def compose_content(self) -> ComposeResult:
        yield Static(id="rt-header")
        with VerticalScroll(id="rt-scroll"):
            yield Static(id="rt-content")
        yield Static(id="rt-hint-bar")

    def on_mount(self) -> None:
        super().on_mount()
        self._render_header()
        self._render_hints()
        self._load_data()
        self._start_refresh_timer()

    def on_unmount(self) -> None:
        self._stop_refresh_timer()

    def on_screen_suspend(self, _event: events.ScreenSuspend) -> None:
        self._stop_refresh_timer()

    def on_screen_resume(self, _event: events.ScreenResume) -> None:
        self._load_data()
        self._start_refresh_timer()

    def _start_refresh_timer(self) -> None:
        if self._refresh_timer is None:
            self._refresh_timer = self.set_interval(10.0, self._load_data)

    def _stop_refresh_timer(self) -> None:
        if self._refresh_timer is not None:
            self._refresh_timer.stop()
            self._refresh_timer = None

    # ── Keyboard handling ────────────────────────────────────────────────

    def on_key(self, event: Key) -> None:
        key = event.key

        # Let control sequences and function keys pass through
        if key.startswith("ctrl+") or (key.startswith("f") and key[1:].isdigit()):
            return

        if self._view == "logs":
            self._handle_logs_key(key)
        elif self._view == "detail":
            self._handle_detail_key(key)
        else:
            self._handle_list_key(key)

        event.prevent_default()
        event.stop()

    def _handle_list_key(self, key: str) -> None:
        if key in ("up", "k"):
            if self._runtimes:
                self._cursor = max(0, self._cursor - 1)
                self._render_current_view()
        elif key in ("down", "j"):
            if self._runtimes:
                self._cursor = min(len(self._runtimes) - 1, self._cursor + 1)
                self._render_current_view()
        elif key == "enter":
            self._open_detail()
        elif key == "c":
            self._quick_connect()
        elif key == "s":
            self._quick_start()
        elif key == "escape":
            self._stop_refresh_timer()
            self.dismiss()
        elif key == "r":
            self._load_data()

    def _handle_logs_key(self, key: str) -> None:
        if key == "r":
            self._do_fetch_logs()
        elif key == "escape":
            self._logs_content = None
            self._view = "detail"
            self._render_current_view()

    def _handle_detail_key(self, key: str) -> None:
        total_actions = len(self._current_actions) + 1  # +1 for "Back"
        if key == "up":
            self._action_cursor = max(0, self._action_cursor - 1)
            self._render_current_view()
        elif key == "down":
            self._action_cursor = min(total_actions - 1, self._action_cursor + 1)
            self._render_current_view()
        elif key == "enter":
            if self._action_cursor >= len(self._current_actions):
                self._back_to_list()
            else:
                action_id = self._current_actions[self._action_cursor][0]
                self._execute_action(action_id)
        elif key == "escape":
            self._back_to_list()

    def _open_detail(self) -> None:
        if self._runtimes and 0 <= self._cursor < len(self._runtimes):
            self._selected_runtime = self._runtimes[self._cursor]
            self._detail_notice = None
            self._action_cursor = 0
            self._view = "detail"
            self._render_current_view()

    def _quick_connect(self) -> None:
        """Connect directly from list — skip detail view for running runtimes."""
        if self._is_app_busy():
            return
        selected = self._selected_list_runtime()
        if not selected:
            return
        state = selected.get("status", "")
        runtime_id = str(selected.get("id", ""))
        if state == "running" and runtime_id != self._connected_id:
            self._selected_runtime = selected
            self._detail_notice = None
            self._view = "detail"
            self._do_connect(runtime_id, selected)
        elif runtime_id == self._connected_id:
            # Already connected — open detail to show disconnect option
            self._open_detail()

    def _quick_start(self) -> None:
        """Start directly from list — skip detail view for idle runtimes."""
        if self._is_app_busy():
            return
        selected = self._selected_list_runtime()
        if not selected:
            return
        if selected.get("status") == "idle":
            self._selected_runtime = selected
            self._detail_notice = None
            self._view = "detail"
            self._do_start(str(selected.get("id", "")))

    def _selected_list_runtime(self) -> dict[str, t.Any] | None:
        if self._runtimes and 0 <= self._cursor < len(self._runtimes):
            return self._runtimes[self._cursor]
        return None

    def _back_to_list(self) -> None:
        self._view = "list"
        self._detail_notice = None
        self._render_current_view()

    # ── Rendering ────────────────────────────────────────────────────────

    def _render_current_view(self) -> None:
        self._render_header()
        if self._view == "logs":
            self._render_logs_view()
        elif self._view == "detail":
            self._render_detail_view()
        else:
            self._render_list_view()
        self._render_hints()

    def _render_header(self) -> None:
        text = Text()
        text.append(" Runtimes", style=f"bold {FG}")
        if self._runtimes:
            text.append(f"  {len(self._runtimes)}", style=FG_MUTED)
        text.append("\n")
        text.append(" Manage cloud sandbox runtimes for your workspace", style=FG_FAINTEST)
        self.query_one("#rt-header", Static).update(text)

    def _render_hints(self) -> None:
        if self._view == "logs":
            hints = [("R", "refresh"), ("Esc", "back")]
        elif self._view == "detail":
            hints = [("Enter", "select"), ("Esc", "back")]
        else:
            hints: list[tuple[str, str]] = [("Enter", "details")]
            # Show contextual quick-action hints based on cursor
            selected = self._selected_list_runtime()
            if selected:
                state = selected.get("status", "")
                rid = str(selected.get("id", ""))
                if state == "running" and rid != self._connected_id:
                    hints.append(("C", "connect"))
                elif state == "idle":
                    hints.append(("S", "start"))
            hints.extend([("R", "refresh"), ("Esc", "close")])
        text = Text()
        text.append(" ")
        for i, (key, action) in enumerate(hints):
            if i > 0:
                text.append("  ", style=FG_FAINTEST)
            text.append(key, style=f"bold {FG_MUTED}")
            text.append(f" {action}", style=FG_FAINTEST)
        self.query_one("#rt-hint-bar", Static).update(text)

    def _render_list_view(self) -> None:
        self._cursor = min(self._cursor, max(0, len(self._runtimes) - 1))
        text = Text()

        if not self._runtimes:
            text.append("  No runtimes found\n\n", style=FG_MUTED)
            text.append(
                "  Create a runtime from the platform UI or via the API.\n",
                style=FG_FAINTEST,
            )
            self.query_one("#rt-content", Static).update(text)
            return

        # Summary line
        counts: dict[str, int] = {}
        for rt in self._runtimes:
            s = rt.get("status", "unknown")
            counts[s] = counts.get(s, 0) + 1
        summary_parts: list[tuple[str, str]] = []
        if counts.get("running"):
            summary_parts.append((f"{counts['running']} running", ACCENT))
        if counts.get("paused"):
            summary_parts.append((f"{counts['paused']} paused", WARNING))
        if counts.get("idle"):
            summary_parts.append((f"{counts['idle']} idle", FG_SUBTLE))
        if summary_parts:
            text.append("  ")
            for i, (label, style) in enumerate(summary_parts):
                if i > 0:
                    text.append(" · ", style=FG_FAINTEST)
                text.append(label, style=style)
            text.append("\n\n")

        connected_id = self._connected_id

        for i, runtime in enumerate(self._runtimes):
            runtime_id = str(runtime.get("id", "?"))
            state = runtime.get("status", "unknown")
            instance = runtime.get("instance") or {}
            provider = instance.get("provider", "")
            is_connected = runtime_id == connected_id
            project = self._project_name(runtime)
            dot_style, dot = _state_dot_and_style(state)
            state_style = {"running": ACCENT, "paused": WARNING, "idle": FG_SUBTLE}.get(
                state, FG_SUBTLE
            )

            # Cursor marker
            if i == self._cursor:
                text.append(" ❯ ", style=f"bold {ACCENT}")
            else:
                text.append("   ")

            # Status dot + project name (or short ID if no project)
            text.append(f"{dot} ", style=dot_style)
            if project and project != runtime_id[:8]:
                text.append(project, style=FG)
                text.append(f" · {runtime_id[:8]}", style=FG_FAINTEST)
            else:
                text.append(runtime_id[:8], style=FG)

            # State
            text.append(" · ", style=FG_FAINTEST)
            text.append(state, style=state_style)

            # Provider
            if provider:
                text.append(f" · {provider}", style=FG_MUTED)

            # Connected badge
            if is_connected:
                text.append(" · ", style=FG_FAINTEST)
                text.append("connected", style=ACCENT)

            text.append("\n")

            # Second line: contextual metadata
            meta = Text()
            meta.append("     ")

            # Expiration with urgency coloring
            exp_secs = _expires_seconds(instance.get("expires_at"))
            exp_label = _expires_label(exp_secs)
            if exp_label:
                meta.append(f"expires {exp_label}", style=_expires_style(exp_secs))

            # Pause reason
            pause_reason = instance.get("pause_reason")
            if state == "paused" and pause_reason:
                reason_label = _PAUSE_REASONS.get(pause_reason, pause_reason)
                if exp_label:
                    meta.append(" · ", style=FG_FAINTEST)
                meta.append(f"paused {reason_label}", style=WARNING)

            # Runtime duration
            runtime_secs = int(instance.get("total_runtime_seconds", 0))
            if runtime_secs:
                if len(meta) > 5:  # more than just indent
                    meta.append(" · ", style=FG_FAINTEST)
                meta.append(f"{_fmt_duration(runtime_secs)} runtime", style=FG_MUTED)

            # Created relative
            created = runtime.get("created_at")
            if created:
                rel = _relative_time(created)
                if rel and len(meta) > 5:
                    meta.append(" · ", style=FG_FAINTEST)
                    meta.append(f"created {rel}", style=FG_FAINTEST)

            if len(meta) > 5:
                text.append_text(meta)
                text.append("\n")

            text.append("\n")

        self.query_one("#rt-content", Static).update(text)

    def _render_detail_view(self) -> None:
        runtime = self._selected_runtime
        if not runtime:
            return

        runtime_id = str(runtime.get("id", "?"))
        state = runtime.get("status", "unknown")
        instance = runtime.get("instance") or {}
        is_connected = runtime_id == self._connected_id
        project_id = str(runtime.get("project_id", ""))
        project = self._project_name(runtime)

        text = Text()

        # Notice (action feedback)
        if self._detail_notice is not None:
            message, severity = self._detail_notice
            notice_style = {
                "error": ERROR,
                "success": SUCCESS,
                "warning": WARNING,
            }.get(severity, INFO)
            text.append(f" {message}\n\n", style=notice_style)

        # Header: project name + state
        dot_style, dot = _state_dot_and_style(state)
        state_style = {"running": ACCENT, "paused": WARNING, "idle": FG_SUBTLE}.get(
            state, FG_SUBTLE
        )
        text.append(f" {dot} ", style=dot_style)
        if project and project != runtime_id[:8]:
            text.append(project, style=f"bold {FG}")
            text.append(f" · {runtime_id[:8]}", style=FG_FAINTEST)
        else:
            text.append(runtime_id[:8], style=f"bold {FG}")
        text.append(" · ", style=FG_FAINTEST)
        text.append(state, style=state_style)
        if is_connected:
            text.append(" · ", style=FG_FAINTEST)
            text.append("connected", style=SUCCESS)

        # Pause reason inline with header
        pause_reason = instance.get("pause_reason")
        if state == "paused" and pause_reason:
            reason_label = _PAUSE_REASONS.get(pause_reason, pause_reason)
            text.append(" · ", style=FG_FAINTEST)
            text.append(reason_label, style=WARNING)

        text.append("\n")

        # Provider + expiration as a compact subtitle
        provider = instance.get("provider", "")
        exp_secs = _expires_seconds(instance.get("expires_at"))
        exp_label = _expires_label(exp_secs)
        subtitle_parts: list[tuple[str, str]] = []
        if provider:
            subtitle_parts.append((provider, FG_MUTED))
        if exp_label:
            subtitle_parts.append((f"expires {exp_label}", _expires_style(exp_secs)))
        runtime_secs = int(instance.get("total_runtime_seconds", 0))
        if runtime_secs:
            subtitle_parts.append((f"{_fmt_duration(runtime_secs)} runtime", FG_MUTED))
        if subtitle_parts:
            text.append("   ")
            for j, (part, sty) in enumerate(subtitle_parts):
                if j > 0:
                    text.append(" · ", style=FG_FAINTEST)
                text.append(part, style=sty)
            text.append("\n")
        text.append("\n")

        # ── Actions (primary — what the user came here to do) ────────
        actions = _build_actions(
            runtime,
            is_connected=is_connected,
            is_any_remote=self._is_any_remote,
        )
        self._current_actions = actions

        for i, (action_id, label) in enumerate(actions):
            if i == self._action_cursor:
                text.append(" ❯ ", style=f"bold {ACCENT}")
            else:
                text.append("   ")
            if action_id in ("reset",):
                text.append(f"{label}\n", style=ERROR)
            elif action_id in ("connect", "start", "resume"):
                text.append(f"{label}\n", style=INFO)
            elif action_id in ("disconnect", "disconnect_other"):
                text.append(f"{label}\n", style=WARNING)
            else:
                text.append(f"{label}\n", style=FG)

        # "Back to list" always last
        back_idx = len(actions)
        if self._action_cursor == back_idx:
            text.append(" ❯ ", style=f"bold {ACCENT}")
        else:
            text.append("   ")
        text.append("Back to runtime list\n", style=FG_SUBTLE)
        text.append("\n")

        # ── Connected runtime info (from RuntimeInfo) ────────────────
        remote_info = self._remote_info if is_connected else None
        if remote_info:
            text.append(" Runtime Info\n", style=f"bold {FG_SUBTLE}")
            if remote_info.version:
                text.append("   Version   ", style=FG_MUTED)
                text.append(f"{remote_info.version}\n", style=FG_SUBTLE)
            if remote_info.host_type:
                text.append("   Host      ", style=FG_MUTED)
                text.append(f"{remote_info.host_type}\n", style=FG_SUBTLE)
            if remote_info.working_dir:
                text.append("   Dir       ", style=FG_MUTED)
                text.append(f"{remote_info.working_dir}\n", style=FG_FAINTEST)
            if remote_info.default_capability:
                text.append("   Default   ", style=FG_MUTED)
                text.append(f"{remote_info.default_capability}\n", style=FG_SUBTLE)
            if remote_info.capabilities:
                agent_count = sum(len(cap.agents) for cap in remote_info.capabilities if cap.agents)
                cap_count = len(remote_info.capabilities)
                text.append("   Loaded    ", style=FG_MUTED)
                parts = [f"{cap_count} capability" + ("" if cap_count == 1 else "s")]
                if agent_count:
                    parts.append(f"{agent_count} agent" + ("" if agent_count == 1 else "s"))
                text.append(" · ".join(parts) + "\n", style=TEAL)
            text.append("\n")

        # ── Details (reference info) ─────────────────────────────────
        text.append(" Details\n", style=f"bold {FG_SUBTLE}")
        created = _fmt_timestamp(runtime.get("created_at"))
        created_rel = _relative_time(runtime.get("created_at"))
        if created:
            text.append("   Created   ", style=FG_MUTED)
            text.append(created, style=FG_SUBTLE)
            if created_rel:
                text.append(f" · {created_rel}", style=FG_FAINTEST)
            text.append("\n")
        if provider:
            text.append("   Provider  ", style=FG_MUTED)
            text.append(f"{provider}\n", style=FG_SUBTLE)
        sandbox_url = instance.get("sandbox_url", "")
        if sandbox_url:
            text.append("   URL       ", style=FG_MUTED)
            text.append(f"{sandbox_url}\n", style=FG_FAINTEST)

        # Credits
        billed = instance.get("billed_credits", 0)
        estimated = instance.get("estimated_total_credits", 0)
        if estimated:
            text.append("   Credits   ", style=FG_MUTED)
            text.append(f"{estimated} estimated\n", style=FG_SUBTLE)
        elif billed:
            text.append("   Credits   ", style=FG_MUTED)
            text.append(f"{billed} billed\n", style=FG_SUBTLE)

        # IDs (subtle, at the very bottom)
        text.append("   ID        ", style=FG_MUTED)
        text.append(f"{runtime_id}\n", style=FG_FAINTEST)
        if project_id:
            text.append("   Project   ", style=FG_MUTED)
            if project and project != project_id[:8]:
                text.append(f"{project}", style=FG_SUBTLE)
                text.append(f" · {project_id}\n", style=FG_FAINTEST)
            else:
                text.append(f"{project_id}\n", style=FG_FAINTEST)
        provider_id = instance.get("provider_sandbox_id", "")
        if provider_id:
            text.append("   Sandbox   ", style=FG_MUTED)
            text.append(f"{provider_id}\n", style=FG_FAINTEST)
        text.append("\n")

        self.query_one("#rt-content", Static).update(text)

    def _render_logs_view(self) -> None:
        runtime = self._selected_runtime
        if not runtime:
            return

        runtime_id = str(runtime.get("id", "?"))
        project = self._project_name(runtime)
        text = Text()

        # Header
        text.append(" Server Logs", style=f"bold {FG_SUBTLE}")
        label = project if project and project != runtime_id[:8] else runtime_id[:8]
        text.append(f"  {label}\n\n", style=FG_MUTED)

        if self._logs_content is None:
            text.append("  Loading…\n", style=FG_MUTED)
        elif not self._logs_content.strip():
            text.append("  No logs available\n", style=FG_MUTED)
        else:
            for line in self._logs_content.splitlines():
                text.append(f"  {line}\n", style=FG_SUBTLE)

        self.query_one("#rt-content", Static).update(text)

    # ── Data loading ─────────────────────────────────────────────────────

    @work(exclusive=True, group="runtimes")
    async def _load_data(self) -> None:
        try:
            data = await asyncio.to_thread(
                self._api.list_runtimes,
                self._org,
                self._workspace,
                state="idle,running,paused",
                limit=50,
            )
            runtimes = data.get("items", [])
            # Sort: running first, then paused, then idle
            runtimes.sort(key=lambda r: _STATE_ORDER.get(r.get("status", ""), 99))
            self._runtimes = runtimes
        except Exception as exc:
            logger.warning("Failed to load runtimes: {}", exc)
            self._runtimes = []

        # Resolve project names (once, then cached)
        if not self._project_names and self._runtimes:
            self._resolve_project_names()

        # If we're in detail or logs view, refresh the selected runtime data
        if self._view in ("detail", "logs") and self._selected_runtime:
            sel_id = str(self._selected_runtime.get("id", ""))
            for rt in self._runtimes:
                if str(rt.get("id", "")) == sel_id:
                    self._selected_runtime = rt
                    break
            # Auto-refresh logs while viewing them
            if self._view == "logs":
                self._do_fetch_logs()

        self._render_current_view()

    @work(exclusive=True, group="project-resolve")
    async def _resolve_project_names(self) -> None:
        """Fetch project list to map project_id -> name."""
        try:
            projects = await asyncio.to_thread(self._api.list_projects, self._org, self._workspace)
            for p in projects:
                pid = str(getattr(p, "id", ""))
                name = getattr(p, "name", "") or getattr(p, "key", "")
                if pid and name:
                    self._project_names[pid] = name
            # Re-render now that we have names
            self._render_current_view()
        except Exception as exc:
            logger.debug("Could not resolve project names: {}", exc)

    # ── Action execution ─────────────────────────────────────────────────

    def _execute_action(self, action_id: str) -> None:
        if self._is_app_busy():
            return
        runtime = self._selected_runtime
        if not runtime:
            return
        runtime_id = str(runtime.get("id", ""))

        if action_id == "start":
            self._do_start(runtime_id)
        elif action_id == "connect":
            self._do_connect(runtime_id, runtime)
        elif action_id in ("disconnect", "disconnect_other"):
            self._do_disconnect()
        elif action_id == "pause":
            self._do_pause(runtime_id)
        elif action_id == "resume":
            self._do_resume(runtime_id)
        elif action_id == "reset":
            self._do_reset(runtime_id)
        elif action_id == "keepalive":
            self._do_keepalive(runtime_id)
        elif action_id == "logs":
            self._view = "logs"
            self._logs_content = None
            self._render_current_view()
            self._do_fetch_logs()

    def _is_app_busy(self) -> bool:
        if hasattr(self.app, "busy") and self.app.busy:
            self._detail_notice = ("Cannot act while a turn is active", "warning")
            self._render_current_view()
            return True
        return False

    def _show_action_notice(self, message: str, severity: str = "info") -> None:
        self._detail_notice = (message, severity)
        self._render_current_view()

    # ── Runtime actions ──────────────────────────────────────────────────

    @work(exclusive=True, group="runtime-action")
    async def _do_pause(self, runtime_id: str) -> None:
        self._show_action_notice(f"Pausing {runtime_id[:8]}…", "warning")
        try:
            await asyncio.to_thread(self._api.pause_runtime, self._org, self._workspace, runtime_id)
            self._show_action_notice(f"Paused {runtime_id[:8]}", "success")
        except Exception as exc:
            self._show_action_notice(f"Pause failed: {exc}", "error")
        self._load_data()

    @work(exclusive=True, group="runtime-action")
    async def _do_resume(self, runtime_id: str) -> None:
        self._show_action_notice(f"Resuming {runtime_id[:8]}…", "info")
        try:
            await asyncio.to_thread(
                self._api.resume_runtime, self._org, self._workspace, runtime_id
            )
            self._show_action_notice(f"Resumed {runtime_id[:8]}", "success")
        except Exception as exc:
            self._show_action_notice(f"Resume failed: {exc}", "error")
        self._load_data()

    @work(exclusive=True, group="runtime-action")
    async def _do_reset(self, runtime_id: str) -> None:
        self._show_action_notice(f"Resetting {runtime_id[:8]}…", "error")
        try:
            if (
                self._connection_manager
                and self._connection_manager.connected_runtime_id == runtime_id
            ):
                await self._connection_manager.disconnect()

            await asyncio.to_thread(self._api.reset_runtime, self._org, self._workspace, runtime_id)

            from dreadnode.app.tui.runtime_cache import RuntimeTokenCache

            RuntimeTokenCache().remove(runtime_id)
            self._show_action_notice(f"Reset {runtime_id[:8]}", "success")
        except Exception as exc:
            self._show_action_notice(f"Reset failed: {exc}", "error")
        self._load_data()

    @work(exclusive=True, group="runtime-action")
    async def _do_keepalive(self, runtime_id: str) -> None:
        self._show_action_notice(f"Extending {runtime_id[:8]}…", "info")
        try:
            await asyncio.to_thread(
                self._api.keepalive_runtime,
                self._org,
                self._workspace,
                runtime_id,
                extend_seconds=300,
            )
            self._show_action_notice(f"Extended {runtime_id[:8]} by 5 min", "success")
        except Exception as exc:
            self._show_action_notice(f"Keepalive failed: {exc}", "error")
        self._load_data()

    def _cache_start_result(self, runtime_id: str, result: dict[str, t.Any]) -> bool:
        """Cache connection info from a start_runtime response. Returns True if cached."""
        from dreadnode.app.tui.runtime_cache import RuntimeTokenCache

        sandbox_token = result.get("sandbox_token")
        instance = result.get("instance") or {}
        sandbox_url = instance.get("sandbox_url")
        provider_sandbox_id = instance.get("provider_sandbox_id")

        logger.info(
            "start_runtime response for {}: token={}, url={}, provider_id={}",
            runtime_id[:8],
            "present" if sandbox_token else "null",
            sandbox_url or "null",
            provider_sandbox_id or "null",
        )

        if sandbox_url and provider_sandbox_id:
            RuntimeTokenCache().put(
                runtime_id,
                sandbox_url=sandbox_url,
                token=sandbox_token or "",
                provider_sandbox_id=provider_sandbox_id,
            )
            return True
        return False

    @work(exclusive=True, group="runtime-action")
    async def _do_start(self, runtime_id: str) -> None:
        self._show_action_notice(f"Starting {runtime_id[:8]}…", "info")
        try:
            result = await asyncio.to_thread(
                self._api.start_runtime,
                self._org,
                self._workspace,
                runtime_id,
            )
            if self._cache_start_result(runtime_id, result):
                self._show_action_notice(f"Started {runtime_id[:8]}", "success")
            elif not (result.get("instance") or {}).get("sandbox_url"):
                self._show_action_notice("Started but no URL available — try refreshing", "warning")
            else:
                self._show_action_notice(
                    f"Started {runtime_id[:8]} (token not returned)", "warning"
                )
        except Exception as exc:
            logger.warning("start_runtime failed for {}: {}", runtime_id[:8], exc)
            self._show_action_notice(f"Start failed: {exc}", "error")
        self._load_data()

    @work(exclusive=True, group="runtime-action")
    async def _do_connect(self, runtime_id: str, runtime: dict[str, t.Any]) -> None:
        if self._connection_manager is None:
            self._show_action_notice("Connection manager not available", "error")
            return

        self._show_action_notice(f"Connecting to {runtime_id[:8]}…", "info")

        from dreadnode.app.tui.runtime_cache import RuntimeTokenCache

        cache = RuntimeTokenCache()
        cached = cache.get(runtime_id)

        # Validate provider_sandbox_id hasn't changed (sandbox reprovisioned)
        if cached is not None:
            instance = runtime.get("instance") or {}
            current_provider_id = instance.get("provider_sandbox_id")
            if current_provider_id and cached.get("provider_sandbox_id") != current_provider_id:
                cache.remove(runtime_id)
                cached = None
                logger.info("Evicted stale token for {} (sandbox reprovisioned)", runtime_id[:8])

        # No cached token — try calling start_runtime to obtain one
        if cached is None:
            logger.info("No cached token for {}, attempting start_runtime", runtime_id[:8])
            self._show_action_notice(f"Obtaining token for {runtime_id[:8]}…", "info")
            try:
                result = await asyncio.to_thread(
                    self._api.start_runtime,
                    self._org,
                    self._workspace,
                    runtime_id,
                )
                self._cache_start_result(runtime_id, result)
                cached = cache.get(runtime_id)
            except Exception as exc:
                logger.warning(
                    "start_runtime failed during connect for {}: {}", runtime_id[:8], exc
                )

        if cached is None:
            logger.warning("Cannot connect to {}: no token available", runtime_id[:8])
            self._show_action_notice(
                "Cannot obtain token — runtime may need to be restarted", "error"
            )
            return

        try:
            await self._connection_manager.connect(
                runtime_id=runtime_id,
                sandbox_url=cached["sandbox_url"],
                token=cached["token"],
            )
            self._stop_refresh_timer()
            self.dismiss()
        except ConnectionError as exc:
            logger.warning("Connect failed for {}: {}", runtime_id[:8], exc)
            self._show_action_notice(f"Connect failed: {exc}", "error")

    @work(exclusive=True, group="logs-fetch")
    async def _do_fetch_logs(self) -> None:
        runtime = self._selected_runtime
        if not runtime:
            return
        instance = runtime.get("instance") or {}
        provider_sandbox_id = instance.get("provider_sandbox_id", "")
        if not provider_sandbox_id:
            self._logs_content = ""
            self._render_current_view()
            return
        try:
            logs = await asyncio.to_thread(
                self._api.get_sandbox_logs,
                self._org,
                provider_sandbox_id,
            )
            self._logs_content = logs
        except Exception as exc:
            logger.warning("Failed to fetch logs: {}", exc)
            self._logs_content = f"Error fetching logs: {exc}"
        if self._view == "logs":
            self._render_current_view()

    @work(exclusive=True, group="runtime-action")
    async def _do_disconnect(self) -> None:
        if self._connection_manager is None:
            return
        self._show_action_notice("Disconnecting…", "info")
        await self._connection_manager.disconnect()
        self._show_action_notice("Disconnected — back to local", "success")
        self._load_data()
