"""Version check and upgrade detection for the Dreadnode CLI.

Pure async + HTTP module with no TUI dependencies.
"""

from __future__ import annotations

import shutil
import subprocess
from dataclasses import dataclass

import httpx
from loguru import logger
from packaging.version import Version

from dreadnode.version import VERSION

_PACKAGE_NAME = "dreadnode"
_TIMEOUT = 3.0


@dataclass(frozen=True, slots=True)
class UpdateInfo:
    """Holds version comparison result."""

    current: str
    latest: str


async def check_for_update(pypi_url: str = "https://pypi.org") -> UpdateInfo | None:
    """Check PyPI for a newer version of dreadnode.

    Returns UpdateInfo if a newer version exists, None otherwise.
    Swallows all exceptions — never degrades the TUI experience.

    This function is pure async (no blocking subprocess calls) so it is
    safe to run from a Textual worker without blocking the event loop.
    Installer detection (detect_upgrade_command) is deferred to /update
    time because it shells out to ``uv tool list`` / ``pipx list``.
    """
    if VERSION == "0.0.0+local":
        logger.debug("Skipping update check for dev build")
        return None

    try:
        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            resp = await client.get(f"{pypi_url}/pypi/{_PACKAGE_NAME}/json")
            resp.raise_for_status()

        data = resp.json()
        latest_str = data["info"]["version"]
        current = Version(VERSION)
        latest = Version(latest_str)

        if latest > current:
            logger.debug("Update available: {} -> {}", VERSION, latest_str)
            return UpdateInfo(current=VERSION, latest=latest_str)
    except Exception:
        logger.opt(exception=True).debug("Update check failed")
        return None
    else:
        logger.debug("Up to date: {} (pypi={})", VERSION, latest_str)
        return None


def detect_upgrade_command() -> list[str] | str:
    """Detect which package manager owns the dreadnode install.

    Returns a list of args for create_subprocess_exec (uv/pipx),
    or a shell string for create_subprocess_shell (install script fallback).
    """
    if shutil.which("uv"):
        try:
            result = subprocess.run(
                ["uv", "tool", "list"],  # noqa: S607
                capture_output=True,
                text=True,
                timeout=5,
                check=False,
            )
            if _PACKAGE_NAME in result.stdout:
                return ["uv", "tool", "upgrade", _PACKAGE_NAME]
        except Exception:
            logger.opt(exception=True).debug("uv tool list failed")

    if shutil.which("pipx"):
        try:
            result = subprocess.run(
                ["pipx", "list", "--short"],  # noqa: S607
                capture_output=True,
                text=True,
                timeout=5,
                check=False,
            )
            if _PACKAGE_NAME in result.stdout:
                return ["pipx", "upgrade", _PACKAGE_NAME]
        except Exception:
            logger.opt(exception=True).debug("pipx list failed")

    # Fallback to install script
    if shutil.which("curl"):
        return "curl -fsSL https://dreadnode.io/install.sh | bash"
    if shutil.which("wget"):
        return "wget -qO- https://dreadnode.io/install.sh | bash"
    return "curl -fsSL https://dreadnode.io/install.sh | bash"
