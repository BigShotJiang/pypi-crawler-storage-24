"""
MCP client — connecting to MCP servers and discovering tools.

Supports stdio and streamable-http transports, with SSE as an internal
fallback for streamable-http connections.
"""

import asyncio
import typing as t
import warnings
from contextlib import AsyncExitStack
from dataclasses import dataclass
from pathlib import Path
from types import TracebackType

import httpx
from loguru import logger

from dreadnode.agents.mcp.config import (
    DEFAULT_HTTP_TIMEOUT,
    DEFAULT_INIT_TIMEOUT,
    DEFAULT_SSE_READ_TIMEOUT,
    MCPStatus,
    ServerConfig,
    SSEConnection,
    StdioConnection,
    StdioServerConfig,
    Transport,
)
from dreadnode.agents.tools import Tool

if t.TYPE_CHECKING:
    from mcp import ClientSession
    from mcp.types import CallToolResult

    from dreadnode.generators.message import Content


def _convert_mcp_result_to_message_parts(result: "CallToolResult") -> list[t.Any]:
    from mcp.types import TextResourceContents

    from dreadnode.generators.message import ContentImageUrl, ContentText

    parts: list[Content] = []
    for content in result.content:
        if content.type == "text":
            parts.append(ContentText(text=content.text))  # ty: ignore[unresolved-attribute]  # ty can't narrow MCP union by .type discriminator
        elif content.type == "image":
            parts.append(ContentImageUrl.from_url(f"data:{content.mimeType};base64,{content.data}"))  # ty: ignore[unresolved-attribute]  # ty can't narrow MCP union by .type discriminator
        elif content.type == "resource":
            resource = content.resource  # ty: ignore[unresolved-attribute]  # ty can't narrow MCP union by .type discriminator
            resource_text = (
                resource.text if isinstance(resource, TextResourceContents) else resource.blob
            )
            parts.append(ContentText(text=resource_text))
        else:
            raise ValueError(f"Unknown content type: {content.type}")
    return parts


@dataclass
class MCPClient:
    """A client for communicating with MCP servers.

    Supports stdio and streamable-http transports. For streamable-http,
    SSE is used as an automatic fallback if the server doesn't support
    the streamable HTTP protocol.

    Can be used as an async context manager or via explicit connect/disconnect:

        # Context manager (existing pattern)
        async with mcp("stdio", command="uv", args=["run", "server"]) as client:
            agent = Agent(tools=list(client.tools))

        # Explicit lifecycle (for managed servers)
        client = MCPClient.from_config(StdioServerConfig(command="uv"))
        await client.connect()
        try:
            ...
        finally:
            await client.disconnect()
    """

    transport: Transport
    """The transport type"""
    connection: StdioConnection | SSEConnection | dict[str, t.Any]
    """Connection configuration"""
    tools: list[Tool[..., t.Any]]
    """Tools discovered from the server"""

    _status: MCPStatus
    _error: str | None
    _exit_stack: AsyncExitStack
    _session: "ClientSession | None"
    _oauth_config: t.Any  # OAuthConfig | None

    def __init__(
        self,
        transport: Transport | t.Literal["sse"],
        connection: "StdioConnection | SSEConnection | dict[str, t.Any]",
        *,
        oauth: t.Any = None,
        init_timeout: float = DEFAULT_INIT_TIMEOUT,
    ) -> None:
        # Handle deprecated "sse" transport
        if transport == "sse":
            warnings.warn(
                'Transport "sse" is deprecated, use "streamable-http" instead. '
                "SSE is used as an automatic fallback.",
                DeprecationWarning,
                stacklevel=2,
            )
            transport = "streamable-http"

        self.transport = transport
        self.connection = connection
        self.tools = []
        self._status = MCPStatus.DISCONNECTED
        self._error = None
        self._exit_stack = AsyncExitStack()
        self._session = None
        self._oauth_config = oauth
        self._init_timeout = init_timeout

    @classmethod
    def from_config(cls, config: ServerConfig) -> "MCPClient":
        """Create a client from a typed server config."""
        if isinstance(config, StdioServerConfig):
            connection: StdioConnection = StdioConnection(
                command=config.command,
                args=config.args,
                cwd=config.cwd,
                env=config.env,
            )
            return cls("stdio", connection, init_timeout=config.init_timeout)

        # HttpServerConfig
        connection_dict: dict[str, t.Any] = {
            "url": config.url,
            "headers": config.headers,
            "timeout": config.timeout,
            "sse_read_timeout": config.sse_read_timeout,
        }
        return cls(
            "streamable-http",
            connection_dict,
            oauth=config.oauth,
            init_timeout=config.init_timeout,
        )

    @property
    def status(self) -> MCPStatus:
        return self._status

    @property
    def error(self) -> str | None:
        """Error message if status is FAILED or NEEDS_AUTH."""
        return self._error

    @property
    def session(self) -> "ClientSession":
        if self._session is None:
            raise RuntimeError("Session not initialized — call connect() first")
        return self._session

    def _make_execute_on_server(self, tool_name: str) -> t.Callable[..., t.Any]:
        async def execute_on_server(**kwargs: t.Any) -> t.Any:
            result = await self.session.call_tool(tool_name, kwargs)
            return _convert_mcp_result_to_message_parts(result)

        return execute_on_server

    async def _load_tools(self) -> None:
        mcp_tool_result = await self.session.list_tools()

        self.tools.clear()
        self.tools = [
            Tool(
                name=tool.name,
                description=tool.description or "",
                parameters_schema=tool.inputSchema,
                fn=self._make_execute_on_server(tool.name),
            )
            for tool in mcp_tool_result.tools
        ]

    async def _connect_via_stdio(self, connection: StdioConnection) -> "ClientSession":
        from mcp import ClientSession, StdioServerParameters
        from mcp.client.stdio import stdio_client

        server_params = StdioServerParameters(**connection)
        read, write = await self._exit_stack.enter_async_context(stdio_client(server_params))
        return await self._exit_stack.enter_async_context(ClientSession(read, write))

    async def _probe_supports_streamable_http(
        self,
        url: str,
        headers: dict[str, str] | None,
        http_timeout: float,
        auth: t.Any,
    ) -> bool:
        """Probe whether a URL supports streamable HTTP (POST).

        Returns True if the server likely supports streamable HTTP, False if it
        clearly doesn't (4xx excluding auth errors). Connectivity errors also
        return False (server unreachable via POST, try SSE). Auth and SSL errors
        are allowed to propagate — they would affect SSE equally.
        """
        try:
            probe_headers = dict(headers) if headers else {}
            probe_headers.update(
                {
                    "Content-Type": "application/json",
                    "Accept": "application/json, text/event-stream",
                }
            )
            async with httpx.AsyncClient(timeout=min(http_timeout, 5), auth=auth) as probe:
                r = await probe.post(url, content=b"{}", headers=probe_headers)
                # 400 = bad request (SSE-only server doesn't understand POST body)
                # 404 = endpoint not found for POST
                # 405 = method not allowed (explicitly rejects POST)
                # 415 = unsupported media type (doesn't accept JSON)
                if r.status_code in (400, 404, 405, 415):
                    logger.debug(
                        "Streamable HTTP probe got {} for {}, using SSE",
                        r.status_code,
                        url,
                    )
                    return False
        except (httpx.ConnectError, httpx.TimeoutException) as e:
            logger.debug("Streamable HTTP probe failed for {} ({}), using SSE", url, e)
            return False

        return True

    async def _connect_via_streamable_http(self, connection: dict[str, t.Any]) -> "ClientSession":
        """Connect via streamable HTTP, falling back to SSE on failure."""
        from mcp import ClientSession
        from mcp.client.streamable_http import streamablehttp_client

        url = connection["url"]
        headers = connection.get("headers")
        timeout = connection.get("timeout", DEFAULT_HTTP_TIMEOUT)
        sse_read_timeout = connection.get("sse_read_timeout", DEFAULT_SSE_READ_TIMEOUT)

        auth = self._build_auth_provider(url)

        # Probe the URL before entering the streamable-http context manager.
        # SSE-only servers (e.g. Burp Suite MCP) return 4xx on POST, and the
        # upstream MCP SDK's streamable-http transport crashes during cleanup
        # with an uncatchable BaseExceptionGroup. Skip straight to SSE when
        # the server clearly doesn't accept POST.
        if not await self._probe_supports_streamable_http(url, headers, timeout, auth):
            return await self._connect_via_sse_internal(connection)

        try:
            ctx = streamablehttp_client(
                url=url,
                headers=headers,
                timeout=timeout,
                sse_read_timeout=sse_read_timeout,
                auth=auth,
            )
            read, write, _ = await self._exit_stack.enter_async_context(ctx)
            return await self._exit_stack.enter_async_context(ClientSession(read, write))
        except (TimeoutError, ConnectionError, OSError) as e:
            logger.debug("Streamable HTTP failed for {}, trying SSE fallback: {}", url, e)

        # Fall back to SSE
        return await self._connect_via_sse_internal(connection)

    async def _connect_via_sse_internal(self, connection: dict[str, t.Any]) -> "ClientSession":
        """Connect via SSE transport (internal fallback)."""
        from mcp import ClientSession
        from mcp.client.sse import sse_client

        url = connection["url"]
        headers = connection.get("headers")
        timeout = connection.get("timeout", DEFAULT_HTTP_TIMEOUT)
        sse_read_timeout = connection.get("sse_read_timeout", DEFAULT_SSE_READ_TIMEOUT)

        ctx = sse_client(
            url=url,
            headers=headers,
            timeout=timeout,
            sse_read_timeout=sse_read_timeout,
        )
        read, write = await self._exit_stack.enter_async_context(ctx)
        return await self._exit_stack.enter_async_context(ClientSession(read, write))

    def _build_auth_provider(self, url: str) -> t.Any:
        """Build an httpx.Auth provider if OAuth is configured."""
        if self._oauth_config is None:
            return None

        from dreadnode.agents.mcp.auth import create_oauth_provider

        return create_oauth_provider(server_url=url, config=self._oauth_config)

    async def connect(self) -> None:
        """Connect to the MCP server and discover tools.

        Sets status to CONNECTED on success, FAILED or NEEDS_AUTH on error.
        """
        try:
            if self.transport == "stdio":
                self._session = await self._connect_via_stdio(
                    t.cast("StdioConnection", self.connection),
                )
            elif self.transport == "streamable-http":
                self._session = await self._connect_via_streamable_http(
                    t.cast("dict[str, t.Any]", self.connection),
                )
            else:
                raise TypeError(  # noqa: TRY301 - intentional routing through shared connection failure handling
                    f"Unsupported transport: {self.transport}. "
                    "Must be 'stdio' or 'streamable-http'",
                )

            await asyncio.wait_for(self.session.initialize(), timeout=self._init_timeout)
            await asyncio.wait_for(self._load_tools(), timeout=self._init_timeout)

            self._status = MCPStatus.CONNECTED
            self._error = None

        except Exception as e:
            await self._shutdown()
            error_msg = str(e)

            # Check for auth-related failures
            error_lower = error_msg.lower()
            if "unauthorized" in error_lower or "401" in error_lower or "oauth" in error_lower:
                self._status = MCPStatus.NEEDS_AUTH
            else:
                self._status = MCPStatus.FAILED

            self._error = error_msg
            raise

    async def disconnect(self) -> None:
        """Disconnect from the MCP server."""
        await self._shutdown()

    async def _shutdown(self) -> None:
        await self._exit_stack.aclose()
        self._session = None
        self.tools.clear()
        if self._status == MCPStatus.CONNECTED:
            self._status = MCPStatus.DISCONNECTED

    async def __aenter__(self) -> "MCPClient":
        await self.connect()
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        await self._shutdown()
        self._status = MCPStatus.DISCONNECTED


# --- Factory function ---


@t.overload
def mcp(
    transport: t.Literal["stdio"],
    *,
    command: str,
    args: list[str] | None = None,
    cwd: str | Path | None = None,
    env: dict[str, str] | None = None,
    init_timeout: float = DEFAULT_INIT_TIMEOUT,
) -> MCPClient: ...


@t.overload
def mcp(
    transport: t.Literal["streamable-http"],
    *,
    url: str,
    headers: dict[str, str] | None = None,
    oauth: t.Any = None,
    timeout: float = DEFAULT_HTTP_TIMEOUT,
    sse_read_timeout: float = DEFAULT_SSE_READ_TIMEOUT,
    init_timeout: float = DEFAULT_INIT_TIMEOUT,
) -> MCPClient: ...


@t.overload
def mcp(
    transport: t.Literal["sse"],
    *,
    url: str,
    headers: dict[str, str] | None = None,
    timeout: float = DEFAULT_HTTP_TIMEOUT,
    sse_read_timeout: float = DEFAULT_SSE_READ_TIMEOUT,
    init_timeout: float = DEFAULT_INIT_TIMEOUT,
) -> MCPClient: ...


def mcp(transport: "Transport | t.Literal['sse']", **kwargs: t.Any) -> MCPClient:
    """Create an MCP client.

    Args:
        transport: Transport type — "stdio" or "streamable-http".
            "sse" is accepted but deprecated (routes to streamable-http
            with SSE fallback).

    Returns:
        An MCPClient instance (use as async context manager or call connect()).

    Examples:
        ```python
        # stdio transport
        async with mcp("stdio", command="uv", args=["run", "weather-mcp"]) as client:
            agent = Agent(tools=list(client.tools))

        # streamable-http transport
        async with mcp("streamable-http", url="https://api.example.com/mcp") as client:
            agent = Agent(tools=list(client.tools))

        # streamable-http with OAuth
        from dreadnode.agents.mcp import OAuthConfig
        async with mcp("streamable-http", url="https://...", oauth=OAuthConfig()) as client:
            agent = Agent(tools=list(client.tools))
        ```
    """
    oauth = kwargs.pop("oauth", None)
    init_timeout = kwargs.pop("init_timeout", DEFAULT_INIT_TIMEOUT)
    connection = t.cast("StdioConnection | SSEConnection | dict[str, t.Any]", kwargs)
    return MCPClient(transport, connection, oauth=oauth, init_timeout=init_timeout)
