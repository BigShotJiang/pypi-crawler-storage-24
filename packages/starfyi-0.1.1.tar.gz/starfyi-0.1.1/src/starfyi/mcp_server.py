"""MCP server for starfyi — AI assistant tools for starfyi.com.

Run: uvx --from "starfyi[mcp]" python -m starfyi.mcp_server
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("StarFYI")


@mcp.tool()
def list_constellations(limit: int = 20, offset: int = 0) -> str:
    """List constellations from starfyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from starfyi.api import StarFYI

    with StarFYI() as api:
        data = api.list_constellations(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No constellations found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def get_constellation(slug: str) -> str:
    """Get detailed information about a specific constellation.

    Args:
        slug: URL slug identifier for the constellation.
    """
    from starfyi.api import StarFYI

    with StarFYI() as api:
        data = api.get_constellation(slug)
        return str(data)


@mcp.tool()
def list_exoplanets(limit: int = 20, offset: int = 0) -> str:
    """List exoplanets from starfyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from starfyi.api import StarFYI

    with StarFYI() as api:
        data = api.list_exoplanets(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No exoplanets found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def search_star(query: str) -> str:
    """Search starfyi.com for stars, constellations, exoplanets, and deep-sky objects.

    Args:
        query: Search query string.
    """
    from starfyi.api import StarFYI

    with StarFYI() as api:
        data = api.search(query)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return f"No results found for \"{query}\"."
        items = results[:10] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


def main() -> None:
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
