"""HTTP API client for starfyi.com REST endpoints.

Requires the ``api`` extra: ``pip install starfyi[api]``

Usage::

    from starfyi.api import StarFYI

    with StarFYI() as api:
        items = api.list_constellations()
        detail = api.get_constellation("example-slug")
        results = api.search("query")
"""

from __future__ import annotations

from typing import Any

import httpx


class StarFYI:
    """API client for the starfyi.com REST API.

    Provides typed access to all starfyi.com endpoints including
    list, detail, and search operations.

    Args:
        base_url: API base URL. Defaults to ``https://starfyi.com``.
        timeout: Request timeout in seconds. Defaults to ``10.0``.
    """

    def __init__(
        self,
        base_url: str = "https://starfyi.com",
        timeout: float = 10.0,
    ) -> None:
        self._client = httpx.Client(base_url=base_url, timeout=timeout)

    def _get(self, path: str, **params: Any) -> dict[str, Any]:
        resp = self._client.get(
            path,
            params={k: v for k, v in params.items() if v is not None},
        )
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    # -- Endpoints -----------------------------------------------------------

    def list_comparisons(self, **params: Any) -> dict[str, Any]:
        """List all comparisons."""
        return self._get("/api/v1/comparisons/", **params)

    def get_comparison(self, slug: str) -> dict[str, Any]:
        """Get comparison by slug."""
        return self._get(f"/api/v1/comparisons/" + slug + "/")

    def list_constellations(self, **params: Any) -> dict[str, Any]:
        """List all constellations."""
        return self._get("/api/v1/constellations/", **params)

    def get_constellation(self, slug: str) -> dict[str, Any]:
        """Get constellation by slug."""
        return self._get(f"/api/v1/constellations/" + slug + "/")

    def list_deep_sky(self, **params: Any) -> dict[str, Any]:
        """List all deep sky."""
        return self._get("/api/v1/deep-sky/", **params)

    def get_deep_sky(self, slug: str) -> dict[str, Any]:
        """Get deep sky by slug."""
        return self._get(f"/api/v1/deep-sky/" + slug + "/")

    def list_exoplanets(self, **params: Any) -> dict[str, Any]:
        """List all exoplanets."""
        return self._get("/api/v1/exoplanets/", **params)

    def get_exoplanet(self, slug: str) -> dict[str, Any]:
        """Get exoplanet by slug."""
        return self._get(f"/api/v1/exoplanets/" + slug + "/")

    def list_faqs(self, **params: Any) -> dict[str, Any]:
        """List all faqs."""
        return self._get("/api/v1/faqs/", **params)

    def get_faq(self, slug: str) -> dict[str, Any]:
        """Get faq by slug."""
        return self._get(f"/api/v1/faqs/" + slug + "/")

    def list_glossary(self, **params: Any) -> dict[str, Any]:
        """List all glossary."""
        return self._get("/api/v1/glossary/", **params)

    def get_term(self, slug: str) -> dict[str, Any]:
        """Get term by slug."""
        return self._get(f"/api/v1/glossary/" + slug + "/")

    def list_glossary_categories(self, **params: Any) -> dict[str, Any]:
        """List all glossary categories."""
        return self._get("/api/v1/glossary-categories/", **params)

    def get_glossary_category(self, slug: str) -> dict[str, Any]:
        """Get glossary category by slug."""
        return self._get(f"/api/v1/glossary-categories/" + slug + "/")

    def list_guide_series(self, **params: Any) -> dict[str, Any]:
        """List all guide series."""
        return self._get("/api/v1/guide-series/", **params)

    def get_guide_sery(self, slug: str) -> dict[str, Any]:
        """Get guide sery by slug."""
        return self._get(f"/api/v1/guide-series/" + slug + "/")

    def list_guides(self, **params: Any) -> dict[str, Any]:
        """List all guides."""
        return self._get("/api/v1/guides/", **params)

    def get_guide(self, slug: str) -> dict[str, Any]:
        """Get guide by slug."""
        return self._get(f"/api/v1/guides/" + slug + "/")

    def list_spectral_classes(self, **params: Any) -> dict[str, Any]:
        """List all spectral classes."""
        return self._get("/api/v1/spectral-classes/", **params)

    def get_spectral_classe(self, slug: str) -> dict[str, Any]:
        """Get spectral classe by slug."""
        return self._get(f"/api/v1/spectral-classes/" + slug + "/")

    def list_stars(self, **params: Any) -> dict[str, Any]:
        """List all stars."""
        return self._get("/api/v1/stars/", **params)

    def get_star(self, slug: str) -> dict[str, Any]:
        """Get star by slug."""
        return self._get(f"/api/v1/stars/" + slug + "/")

    def search(self, query: str, **params: Any) -> dict[str, Any]:
        """Search across all content."""
        return self._get(f"/api/v1/search/", q=query, **params)

    # -- Lifecycle -----------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> StarFYI:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
