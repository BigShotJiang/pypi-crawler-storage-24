"""Command-line interface for starfyi."""

from __future__ import annotations

import json

import typer

from starfyi.api import StarFYI

app = typer.Typer(help="StarFYI — Stars, constellations and astronomy API client.")


@app.command()
def search(query: str) -> None:
    """Search starfyi.com."""
    with StarFYI() as api:
        result = api.search(query)
        typer.echo(json.dumps(result, indent=2))
