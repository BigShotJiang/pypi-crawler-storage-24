"""Python API client for starfyi.com."""

__version__ = "0.1.0"
