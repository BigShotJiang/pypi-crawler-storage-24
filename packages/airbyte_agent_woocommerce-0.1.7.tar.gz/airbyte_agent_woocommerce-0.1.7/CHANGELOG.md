# Woocommerce changelog

## [0.1.7] - 2026-03-26
- Updated connector definition (YAML version 1.0.1)
- Source commit: 20f00dda
- SDK version: 0.1.0

## [0.1.6] - 2026-03-25
- Updated connector definition (YAML version 1.0.1)
- Source commit: bbb46256
- SDK version: 0.1.0

## [0.1.5] - 2026-03-23
- Updated connector definition (YAML version 1.0.1)
- Source commit: 6ad04bc3
- SDK version: 0.1.0

## [0.1.4] - 2026-03-23
- Updated connector definition (YAML version 1.0.1)
- Source commit: 5718dee3
- SDK version: 0.1.0

## [0.1.3] - 2026-03-12
- Updated connector definition (YAML version 1.0.1)
- Source commit: b541ca65
- SDK version: 0.1.0

## [0.1.2] - 2026-03-11
- Updated connector definition (YAML version 1.0.1)
- Source commit: 44677ecb
- SDK version: 0.1.0

## [0.1.1] - 2026-03-05
- Updated connector definition (YAML version 1.0.1)
- Source commit: e50d6dd2
- SDK version: 0.1.0

## [0.1.0] - 2026-03-05
- Updated connector definition (YAML version 1.0.1)
- Source commit: 1dca927b
- SDK version: 0.1.0
