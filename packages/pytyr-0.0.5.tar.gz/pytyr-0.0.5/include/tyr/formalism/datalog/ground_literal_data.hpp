/*
 * Copyright (C) 2025 Dominik Drexler
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 */

#ifndef TYR_FORMALISM_DATALOG_GROUND_LITERAL_DATA_HPP_
#define TYR_FORMALISM_DATALOG_GROUND_LITERAL_DATA_HPP_

#include "tyr/common/types.hpp"
#include "tyr/common/types_utils.hpp"
#include "tyr/formalism/datalog/declarations.hpp"
#include "tyr/formalism/datalog/ground_atom_index.hpp"
#include "tyr/formalism/datalog/ground_literal_index.hpp"

namespace tyr
{

template<formalism::FactKind T>
struct Data<formalism::datalog::GroundLiteral<T>>
{
    Index<formalism::datalog::GroundLiteral<T>> index;
    Index<formalism::datalog::GroundAtom<T>> atom;
    bool polarity;

    Data() = default;
    Data(Index<formalism::datalog::GroundLiteral<T>> index, Index<formalism::datalog::GroundAtom<T>> atom, bool polarity) :
        index(index),
        atom(atom),
        polarity(polarity)
    {
    }
    Data(const Data& other) = default;
    Data& operator=(const Data& other) = default;
    Data(Data&& other) = default;
    Data& operator=(Data&& other) = default;

    void clear() noexcept
    {
        tyr::clear(index);
        tyr::clear(atom);
        tyr::clear(polarity);
    }

    auto cista_members() const noexcept { return std::tie(index, atom, polarity); }
    auto identifying_members() const noexcept { return std::tie(atom, polarity); }
};

static_assert(uses_trivial_storage_v<formalism::datalog::GroundLiteral<formalism::StaticTag>>);
}

#endif
