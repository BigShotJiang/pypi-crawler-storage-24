"""Celery task queue integration."""
