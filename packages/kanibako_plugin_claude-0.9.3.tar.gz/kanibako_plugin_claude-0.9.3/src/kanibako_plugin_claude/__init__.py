"""kanibako-plugin-claude: Claude Code target plugin for kanibako."""

from kanibako_plugin_claude.target import ClaudeTarget

__version__ = "0.9.3"

__all__ = ["ClaudeTarget", "__version__"]
