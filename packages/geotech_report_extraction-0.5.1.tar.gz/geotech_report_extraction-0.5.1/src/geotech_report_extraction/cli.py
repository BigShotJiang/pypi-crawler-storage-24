"""Command-line interface for geotechnical report extraction."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from geotech_report_extraction.extract import extract_report


def main(argv: list[str] | None = None) -> None:
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        prog="geotech-extract",
        description="Extract geotechnical borehole data from PDF reports and output DIGGS XML.",
    )
    parser.add_argument(
        "input",
        help="Path to the geotechnical report PDF file.",
    )
    parser.add_argument(
        "-f", "--firm",
        choices=["langan", "schnabel"],
        default=None,
        help="Geotechnical firm (auto-detected if not specified).",
    )
    parser.add_argument(
        "-o", "--output",
        default=None,
        help="Output path for DIGGS XML file (default: input file with .xml extension).",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        dest="output_json",
        help="Output extracted data as JSON instead of DIGGS XML.",
    )
    parser.add_argument(
        "--no-xml",
        action="store_true",
        help="Do not write DIGGS XML output file.",
    )
    parser.add_argument(
        "--locations",
        action="store_true",
        help="Extract boring coordinates from location plan pages (requires API key).",
    )
    parser.add_argument(
        "--ref-lat",
        type=float,
        default=None,
        help="Reference latitude for site center (converts plan coords to lat/long).",
    )
    parser.add_argument(
        "--ref-long",
        type=float,
        default=None,
        help="Reference longitude for site center (converts plan coords to lat/long).",
    )
    parser.add_argument(
        "--address",
        type=str,
        default=None,
        help="Site address for geocoding (alternative to --ref-lat/--ref-long).",
    )
    parser.add_argument(
        "--output-geojson",
        type=str,
        default=None,
        help="Export boring locations to a GeoJSON file.",
    )
    parser.add_argument(
        "--output-shapefile",
        type=str,
        default=None,
        help="Export boring locations to an Esri Shapefile.",
    )
    parser.add_argument(
        "--output-map",
        type=str,
        default=None,
        help="Export interactive HTML map of boring locations.",
    )

    args = parser.parse_args(argv)

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: File not found: {input_path}", file=sys.stderr)
        sys.exit(1)

    # Resolve reference coordinates from address if needed
    ref_lat = args.ref_lat
    ref_long = args.ref_long
    if args.address and ref_lat is None and ref_long is None:
        try:
            from geotech_report_extraction.geo import geocode_address
            result_geo = geocode_address(args.address)
            if result_geo:
                ref_lat, ref_long = result_geo
                print(f"Geocoded '{args.address}' -> ({ref_lat}, {ref_long})")
            else:
                print(f"Warning: Could not geocode '{args.address}'",
                      file=sys.stderr)
        except ImportError:
            print("Warning: geopy not installed, cannot geocode address",
                  file=sys.stderr)

    try:
        result = extract_report(
            file_path=input_path,
            firm=args.firm,
            output_diggs=not args.no_xml,
            output_path=args.output,
            extract_locations=args.locations,
            ref_lat=ref_lat,
            ref_long=ref_long,
        )
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)

    # Summary output
    print(f"Source: {result.source_file}")
    if result.project.firm:
        print(f"Firm: {result.project.firm}")
    if result.project.name:
        print(f"Project: {result.project.name}")
    print(f"Boreholes extracted: {len(result.boreholes)}")

    for bh in result.boreholes:
        coord_str = ""
        if bh.latitude is not None and bh.longitude is not None:
            coord_str = f", coords=({bh.latitude}, {bh.longitude})"
        print(f"  {bh.boring_id}: depth={bh.depth_ft} ft, "
              f"samples={len(bh.samples)}, layers={len(bh.soil_layers)}"
              f"{coord_str}")

    if result.extraction_warnings:
        print(f"\nWarnings ({len(result.extraction_warnings)}):")
        for w in result.extraction_warnings:
            print(f"  - {w}")

    if args.output_json:
        print("\n--- JSON Output ---")
        print(result.model_dump_json(indent=2))

    if not args.no_xml:
        out_path = args.output or input_path.with_suffix(".xml")
        print(f"\nDIGGS XML written to: {out_path}")

    # GIS exports (only if boreholes have coordinates)
    gis_coords = {
        bh.boring_id: (bh.latitude, bh.longitude)
        for bh in result.boreholes
        if bh.latitude is not None and bh.longitude is not None
    }

    if gis_coords:
        if args.output_geojson:
            try:
                from geotech_report_extraction.geo import export_geojson
                export_geojson(gis_coords, args.output_geojson)
                print(f"GeoJSON written to: {args.output_geojson}")
            except ImportError:
                print("Warning: geopandas not installed, skipping GeoJSON",
                      file=sys.stderr)

        if args.output_shapefile:
            try:
                from geotech_report_extraction.geo import export_shapefile
                export_shapefile(gis_coords, args.output_shapefile)
                print(f"Shapefile written to: {args.output_shapefile}")
            except ImportError:
                print("Warning: geopandas not installed, skipping Shapefile",
                      file=sys.stderr)

        if args.output_map:
            try:
                from geotech_report_extraction.geo import create_boring_map
                m = create_boring_map(
                    gis_coords,
                    title=result.project.name or "Boring Locations",
                )
                m.save(args.output_map)
                print(f"Interactive map written to: {args.output_map}")
            except ImportError:
                print("Warning: folium not installed, skipping map",
                      file=sys.stderr)


if __name__ == "__main__":
    main()
