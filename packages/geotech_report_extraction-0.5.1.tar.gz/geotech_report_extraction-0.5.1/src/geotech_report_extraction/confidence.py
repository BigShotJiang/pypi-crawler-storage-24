"""Confidence scoring for extracted geotechnical data.

Evaluates the plausibility and completeness of extracted boring log data
by running a suite of domain-specific checks. Each check contributes to
an overall confidence score.

The scoring considers:
- Data completeness (depth, blow counts, soil descriptions)
- Physical plausibility (N-values within expected ranges, depths ordered)
- Internal consistency (sample depths within boring depth, layers continuous)
- Extraction method quality (graphical scale vs fallback, text vs OCR)
"""

from __future__ import annotations

from geotech_report_extraction.models import (
    Borehole,
    ConfidenceLevel,
    ExtractionConfidence,
    Sample,
)


def score_sample(sample: Sample, boring_depth: float = 0.0) -> ExtractionConfidence:
    """Score confidence for a single sample extraction."""
    checks: list[str] = []
    score = 0.5  # start at neutral

    # Check 1: Depth is positive and within boring depth
    if sample.depth_top_ft >= 0:
        checks.append("depth_positive")
        score += 0.05
    else:
        checks.append("FAIL:depth_negative")
        score -= 0.2

    if boring_depth > 0 and sample.depth_top_ft <= boring_depth:
        checks.append("depth_within_boring")
        score += 0.05
    elif boring_depth > 0:
        checks.append("FAIL:depth_exceeds_boring")
        score -= 0.15

    # Check 2: Sample interval is reasonable (0.5-5 ft typical)
    interval = sample.depth_bottom_ft - sample.depth_top_ft
    if 0.5 <= interval <= 5.0:
        checks.append("interval_reasonable")
        score += 0.05
    else:
        checks.append("WARN:interval_unusual")

    # Check 3: SPT data completeness
    if sample.spt:
        spt = sample.spt
        if spt.first_6in is not None and spt.second_6in is not None and spt.third_6in is not None:
            checks.append("spt_complete_3part")
            score += 0.15
        elif spt.n_value is not None:
            checks.append("spt_n_value_only")
            score += 0.10
        else:
            checks.append("WARN:spt_incomplete")
            score -= 0.05

        # Check N-value plausibility (0-100 typical, up to 200 in dense materials)
        n = spt.n_value
        if n is not None:
            if 0 <= n <= 100:
                checks.append("n_value_plausible")
                score += 0.10
            elif 100 < n <= 200:
                checks.append("n_value_high_but_possible")
                score += 0.05
            else:
                checks.append("FAIL:n_value_implausible")
                score -= 0.20

        # Check N-value matches sum of 2nd+3rd
        if spt.second_6in is not None and spt.third_6in is not None and spt.n_value is not None:
            expected = spt.second_6in + spt.third_6in
            if spt.n_value == expected:
                checks.append("n_value_consistent")
                score += 0.10
            else:
                checks.append("FAIL:n_value_inconsistent")
                score -= 0.15

        # Individual blow counts plausibility (each 0-100)
        for label, val in [
            ("first", spt.first_6in),
            ("second", spt.second_6in),
            ("third", spt.third_6in),
        ]:
            if val is not None:
                if 0 <= val <= 100:
                    pass  # fine
                else:
                    checks.append(f"FAIL:{label}_blow_implausible")
                    score -= 0.10
    else:
        checks.append("WARN:no_spt_data")
        score -= 0.10

    # Check 4: Sample type present
    if sample.sample_type:
        checks.append("sample_type_present")
        score += 0.05

    # Clamp and determine level
    score = max(0.0, min(1.0, score))
    level = _score_to_level(score)

    notes = None
    fails = [c for c in checks if c.startswith("FAIL:")]
    if fails:
        notes = f"Issues: {', '.join(c.replace('FAIL:', '') for c in fails)}"

    return ExtractionConfidence(
        level=level,
        score=round(score, 2),
        checks=checks,
        notes=notes,
    )


def score_borehole(borehole: Borehole) -> ExtractionConfidence:
    """Score overall confidence for a borehole extraction."""
    checks: list[str] = []
    score = 0.5

    # Check 1: Has boring ID
    if borehole.boring_id and borehole.boring_id != "UNKNOWN":
        checks.append("boring_id_present")
        score += 0.05
    else:
        checks.append("FAIL:boring_id_missing")
        score -= 0.15

    # Check 2: Total depth is positive
    if borehole.depth_ft > 0:
        checks.append("depth_positive")
        score += 0.05
    else:
        checks.append("WARN:depth_zero")
        score -= 0.10

    # Check 3: Has samples
    if borehole.samples:
        checks.append(f"has_{len(borehole.samples)}_samples")
        score += 0.10
    else:
        checks.append("FAIL:no_samples")
        score -= 0.25

    # Check 4: Samples are ordered by depth
    if len(borehole.samples) >= 2:
        depths = [s.depth_top_ft for s in borehole.samples]
        if all(depths[i] <= depths[i + 1] for i in range(len(depths) - 1)):
            checks.append("samples_depth_ordered")
            score += 0.10
        else:
            checks.append("WARN:samples_not_ordered")
            score -= 0.05

    # Check 5: Sample depths within total depth
    if borehole.depth_ft > 0 and borehole.samples:
        max_sample_depth = max(s.depth_bottom_ft for s in borehole.samples)
        if max_sample_depth <= borehole.depth_ft + 2.0:
            checks.append("samples_within_depth")
            score += 0.05
        else:
            checks.append("WARN:samples_exceed_depth")
            score -= 0.05

    # Check 6: Has soil layers
    if borehole.soil_layers:
        checks.append(f"has_{len(borehole.soil_layers)}_layers")
        score += 0.05
    else:
        checks.append("WARN:no_soil_layers")

    # Check 7: Sample confidence average
    if borehole.samples:
        sample_scores = []
        for s in borehole.samples:
            if s.confidence:
                sample_scores.append(s.confidence.score)
        if sample_scores:
            avg_sample = sum(sample_scores) / len(sample_scores)
            if avg_sample >= 0.7:
                checks.append("high_sample_confidence")
                score += 0.10
            elif avg_sample >= 0.5:
                checks.append("medium_sample_confidence")
                score += 0.05
            else:
                checks.append("WARN:low_sample_confidence")
                score -= 0.10

    # Check 8: Expected sample spacing
    # SPT is typically every 2.5-5ft. If we have far fewer samples
    # than expected, data may be missing.
    if borehole.depth_ft >= 10 and borehole.samples:
        expected_min = borehole.depth_ft / 7.5  # at least every 7.5ft
        if len(borehole.samples) >= expected_min:
            checks.append("sample_density_adequate")
            score += 0.05
        else:
            checks.append("WARN:sparse_samples")
            score -= 0.05

    score = max(0.0, min(1.0, score))
    level = _score_to_level(score)

    notes = None
    fails = [c for c in checks if c.startswith("FAIL:")]
    if fails:
        notes = f"Issues: {', '.join(c.replace('FAIL:', '') for c in fails)}"

    return ExtractionConfidence(
        level=level,
        score=round(score, 2),
        checks=checks,
        notes=notes,
    )


def _score_to_level(score: float) -> ConfidenceLevel:
    """Convert numeric score to confidence level."""
    if score >= 0.75:
        return ConfidenceLevel.HIGH
    elif score >= 0.50:
        return ConfidenceLevel.MEDIUM
    elif score >= 0.30:
        return ConfidenceLevel.LOW
    else:
        return ConfidenceLevel.FLAGGED
