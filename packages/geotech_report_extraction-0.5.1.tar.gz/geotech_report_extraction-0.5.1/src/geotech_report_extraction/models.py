"""Data models for geotechnical report extraction.

These Pydantic models represent the structured data extracted from
boring logs in geotechnical reports. They serve as the intermediate
representation between PDF parsing and DIGGS XML serialization.
"""

from __future__ import annotations

from datetime import date
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class SampleType(str, Enum):
    """Standard geotechnical sample types."""
    SPLIT_SPOON = "SS"        # Split-spoon (SPT) sample
    SHELBY_TUBE = "ST"        # Thin-walled Shelby tube
    ROCK_CORE = "RC"          # Rock core
    GRAB = "GB"               # Grab / bulk sample
    AUGER = "AU"              # Auger cutting
    CONTINUOUS = "CS"         # Continuous sample
    NO_RECOVERY = "NR"        # Attempted but no recovery
    OTHER = "OT"


class USCSClassification(str, Enum):
    """Unified Soil Classification System (USCS) groups."""
    GW = "GW"    # Well-graded gravel
    GP = "GP"    # Poorly graded gravel
    GM = "GM"    # Silty gravel
    GC = "GC"    # Clayey gravel
    SW = "SW"    # Well-graded sand
    SP = "SP"    # Poorly graded sand
    SM = "SM"    # Silty sand
    SC = "SC"    # Clayey sand
    ML = "ML"    # Silt (low plasticity)
    CL = "CL"    # Clay (low plasticity)
    OL = "OL"    # Organic silt/clay (low plasticity)
    MH = "MH"    # Silt (high plasticity)
    CH = "CH"    # Clay (high plasticity)
    OH = "OH"    # Organic silt/clay (high plasticity)
    PT = "PT"    # Peat


class Consistency(str, Enum):
    """Consistency descriptions for cohesive soils."""
    VERY_SOFT = "very soft"
    SOFT = "soft"
    MEDIUM_STIFF = "medium stiff"
    STIFF = "stiff"
    VERY_STIFF = "very stiff"
    HARD = "hard"


class RelativeDensity(str, Enum):
    """Relative density descriptions for granular soils."""
    VERY_LOOSE = "very loose"
    LOOSE = "loose"
    MEDIUM_DENSE = "medium dense"
    DENSE = "dense"
    VERY_DENSE = "very dense"


class MoistureCondition(str, Enum):
    """Soil moisture condition descriptions."""
    DRY = "dry"
    MOIST = "moist"
    WET = "wet"
    SATURATED = "saturated"


class SPTBlowCounts(BaseModel):
    """Standard Penetration Test blow count data.

    SPT is performed by driving a split-spoon sampler 18 inches
    using a 140-lb hammer falling 30 inches. Blows are recorded
    per 6-inch increment.
    """
    first_6in: Optional[int] = Field(None, description="Blows for first 6 inches (seating)")
    second_6in: Optional[int] = Field(None, description="Blows for second 6 inches")
    third_6in: Optional[int] = Field(None, description="Blows for third 6 inches")
    n_value: Optional[int] = Field(
        None,
        description="N-value: sum of second and third 6-inch blow counts"
    )
    refusal: bool = Field(False, description="Whether refusal was encountered (50 blows in <=6 in)")

    def compute_n_value(self) -> Optional[int]:
        if self.second_6in is not None and self.third_6in is not None:
            return self.second_6in + self.third_6in
        return self.n_value


class ConfidenceLevel(str, Enum):
    """Extraction confidence level for a data element."""
    HIGH = "high"          # Multiple signals agree, plausible values
    MEDIUM = "medium"      # Extracted but with some uncertainty
    LOW = "low"            # Significant uncertainty, may need review
    FLAGGED = "flagged"    # Likely wrong or needs human review


class ExtractionConfidence(BaseModel):
    """Confidence assessment for an extracted data element."""
    level: ConfidenceLevel = ConfidenceLevel.MEDIUM
    score: float = Field(
        0.5, ge=0.0, le=1.0,
        description="Numeric confidence 0.0 (no confidence) to 1.0 (certain)"
    )
    checks: list[str] = Field(
        default_factory=list,
        description="List of checks passed/failed, e.g. 'depth_from_scale', 'n_value_plausible'"
    )
    notes: Optional[str] = Field(
        None, description="Human-readable note about confidence issues"
    )


class Sample(BaseModel):
    """A soil or rock sample collected from a borehole."""
    sample_number: Optional[str] = None
    sample_type: Optional[SampleType] = None
    depth_top_ft: float = Field(..., description="Top of sample interval (feet)")
    depth_bottom_ft: float = Field(..., description="Bottom of sample interval (feet)")
    recovery_in: Optional[float] = Field(None, description="Length of sample recovered (inches)")
    recovery_pct: Optional[float] = Field(None, description="Recovery percentage")
    spt: Optional[SPTBlowCounts] = Field(None, description="SPT blow counts if split-spoon sample")
    rqd_pct: Optional[float] = Field(None, description="Rock Quality Designation (%) for rock core")
    water_content_pct: Optional[float] = Field(None, description="Water content (%)")
    dry_unit_weight_pcf: Optional[float] = Field(None, description="Dry unit weight (pcf)")
    liquid_limit: Optional[int] = Field(None, description="Atterberg liquid limit (LL)")
    plastic_limit: Optional[int] = Field(None, description="Atterberg plastic limit (PL)")
    plasticity_index: Optional[int] = Field(None, description="Atterberg plasticity index (PI)")
    fines_pct: Optional[float] = Field(None, description="Percent passing No. 200 sieve (fines %)")
    qu_psf: Optional[float] = Field(None, description="Unconfined compressive strength (psf)")
    confidence: Optional[ExtractionConfidence] = Field(
        None, description="Confidence assessment for this sample's data"
    )


class SoilLayer(BaseModel):
    """A distinct soil or rock layer identified in the boring log."""
    depth_top_ft: float = Field(..., description="Top of layer (feet below ground surface)")
    depth_bottom_ft: Optional[float] = Field(None, description="Bottom of layer (feet)")
    description: str = Field(..., description="Full soil/rock description from the log")
    uscs_classification: Optional[USCSClassification] = None
    color: Optional[str] = None
    moisture: Optional[MoistureCondition] = None
    consistency: Optional[Consistency] = None
    relative_density: Optional[RelativeDensity] = None


class WaterLevelObservation(BaseModel):
    """Groundwater observation during or after drilling."""
    depth_ft: float = Field(..., description="Depth to water (feet)")
    date_observed: Optional[date] = None
    is_during_drilling: bool = Field(
        False,
        description="True if observed during drilling, False if measured after"
    )
    is_stabilized: bool = Field(
        False,
        description="True if water level had stabilized (e.g., 24-hour reading)"
    )
    notes: Optional[str] = None


class DrillingDetails(BaseModel):
    """Information about the drilling method and equipment."""
    method: Optional[str] = Field(None, description="Drilling method (e.g., hollow stem auger, mud rotary)")
    rig_type: Optional[str] = None
    hammer_type: Optional[str] = Field(None, description="SPT hammer type (e.g., automatic, safety, donut)")
    hammer_weight_lb: Optional[float] = Field(None, description="Hammer weight in pounds (typically 140)")
    hammer_drop_in: Optional[float] = Field(None, description="Hammer drop in inches (typically 30)")
    borehole_diameter_in: Optional[float] = None
    driller: Optional[str] = None
    logged_by: Optional[str] = None


class Borehole(BaseModel):
    """A single borehole (test boring) from a geotechnical investigation."""
    boring_id: str = Field(..., description="Boring designation (e.g., B-1, BH-1)")
    depth_ft: float = Field(..., description="Total depth of boring (feet)")
    elevation_ft: Optional[float] = Field(None, description="Ground surface elevation (feet)")
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    date_started: Optional[date] = None
    date_completed: Optional[date] = None
    drilling: Optional[DrillingDetails] = None
    samples: list[Sample] = Field(default_factory=list)
    soil_layers: list[SoilLayer] = Field(default_factory=list)
    water_levels: list[WaterLevelObservation] = Field(default_factory=list)
    confidence: Optional[ExtractionConfidence] = Field(
        None, description="Overall confidence for this borehole extraction"
    )


class Project(BaseModel):
    """Project-level metadata from the geotechnical report."""
    name: Optional[str] = Field(None, description="Project name")
    number: Optional[str] = Field(None, description="Project number")
    client: Optional[str] = None
    location: Optional[str] = None
    report_date: Optional[date] = None
    firm: Optional[str] = Field(None, description="Geotechnical firm name (e.g., Langan, Schnabel)")


class BoreholeLog(BaseModel):
    """Complete extraction result from a geotechnical report.

    Contains project metadata and all boreholes extracted from the report.
    """
    project: Project = Field(default_factory=Project)
    boreholes: list[Borehole] = Field(default_factory=list)
    source_file: Optional[str] = None
    extraction_warnings: list[str] = Field(default_factory=list)
    lab_tests: list = Field(
        default_factory=list,
        description="Lab test results (LabTestResult objects) extracted from "
        "report figures/plots",
    )
