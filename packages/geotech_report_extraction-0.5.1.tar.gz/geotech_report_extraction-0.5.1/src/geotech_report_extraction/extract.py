"""Main API entry point for geotechnical report extraction.

Provides a simple interface for extracting borehole data from PDF reports
and optionally converting to DIGGS XML. Supports three extraction modes:

1. Rule-based only (default, fast, free)
2. Vision LLM only (accurate, requires API key or LLM backend)
3. Dual mode with cross-validation (highest accuracy + confidence scores)

Supports pluggable LLM backends via the ``llm_backend`` parameter:

    from geotech_report_extraction.llm_backend import FunhouseBackend
    result = extract_report("report.pdf", use_vision=True,
                            llm_backend=FunhouseBackend(model="gpt-4.1"))
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from geotech_report_extraction.llm_backend import LLMBackend

from geotech_report_extraction.diggs import to_diggs_xml
from geotech_report_extraction.models import BoreholeLog, ConfidenceLevel
from geotech_report_extraction.parsers.registry import detect_firm, get_parser
from geotech_report_extraction.pdf_parser import (
    PDFContent,
    group_boring_log_pages,
    read_pdf,
)

logger = logging.getLogger(__name__)


def extract_report(
    file_path: str | Path,
    firm: Optional[str] = None,
    output_diggs: bool = False,
    output_path: Optional[str | Path] = None,
    use_vision: bool = False,
    vision_api_key: Optional[str] = None,
    vision_model: str = "claude-sonnet-4-20250514",
    cross_validate: bool = False,
    extract_locations: bool = False,
    ref_lat: Optional[float] = None,
    ref_long: Optional[float] = None,
    extract_lab: bool = False,
    llm_backend: Optional["LLMBackend"] = None,
) -> BoreholeLog:
    """Extract borehole data from a geotechnical report PDF.

    Args:
        file_path: Path to the PDF report file.
        firm: Geotechnical firm name (e.g., 'langan', 'schnabel').
              If None, auto-detection is attempted.
        output_diggs: If True, also write DIGGS XML output.
        output_path: Path for DIGGS XML output file.
        use_vision: If True, use vision LLM for extraction.
        vision_api_key: Anthropic API key for vision extraction.
            Ignored when ``llm_backend`` is provided.
        vision_model: Model to use for vision extraction.
            Ignored when ``llm_backend`` is provided.
        cross_validate: If True, run BOTH rule-based and vision extraction,
                       then compare results for confidence scoring.
        extract_locations: If True, find boring location plan pages and
                          use vision LLM to extract boring coordinates.
        ref_lat: Reference latitude for coordinate conversion (plan center).
        ref_long: Reference longitude for coordinate conversion (plan center).
        extract_lab: If True, find lab test pages and use vision LLM to
                     digitize X-Y plot data from consolidation, grain size,
                     triaxial, and other lab test figures.
        llm_backend: Optional pluggable LLM backend (e.g., FunhouseBackend).
            When provided, ``vision_api_key`` and ``vision_model`` are ignored
            and the backend handles all LLM calls. Implies ``use_vision=True``
            if neither ``use_vision`` nor ``cross_validate`` are already set
            and no ``vision_api_key`` is provided.

    Returns:
        BoreholeLog containing all extracted data with confidence scores.
    """
    file_path = Path(file_path)
    pdf_content = read_pdf(file_path)

    # When a backend is provided, enable vision mode automatically
    if llm_backend is not None and not use_vision and not cross_validate:
        use_vision = True

    if firm is None:
        firm = detect_firm(pdf_content)

    parser = get_parser(firm)
    project = parser.parse_project_info(pdf_content)
    boring_groups = group_boring_log_pages(pdf_content)
    boreholes = []
    warnings: list[str] = []

    if cross_validate:
        # Dual mode: run both methods and cross-validate
        boreholes, warnings = _extract_cross_validated(
            pdf_content, boring_groups, parser,
            api_key=vision_api_key, model=vision_model,
            backend=llm_backend,
        )
    elif use_vision:
        # Vision-only mode
        boreholes, warnings = _extract_with_vision(
            pdf_content, boring_groups,
            api_key=vision_api_key, model=vision_model,
            backend=llm_backend,
        )
    else:
        # Rule-based only (default)
        for boring_id, pages in boring_groups.items():
            try:
                borehole = parser.parse_boring_log(pages)
                boreholes.append(borehole)
            except Exception as e:
                warnings.append(f"Failed to parse boring {boring_id}: {e}")

    # Extract boring coordinates from location plan pages
    if extract_locations:
        from geotech_report_extraction.location_plan import extract_plan_coordinates

        plan_coords = extract_plan_coordinates(
            pdf_content, api_key=vision_api_key, model=vision_model,
            ref_lat=ref_lat, ref_long=ref_long, backend=llm_backend,
        )
        if plan_coords:
            matched = 0
            for bh in boreholes:
                if bh.boring_id in plan_coords:
                    coord = plan_coords[bh.boring_id]
                    if ref_lat is not None and ref_long is not None:
                        bh.latitude, bh.longitude = coord
                    else:
                        # Store site-relative coords (easting, northing)
                        bh.latitude, bh.longitude = coord
                    matched += 1
            logger.info(
                "Assigned coordinates to %d/%d boreholes from plan",
                matched, len(boreholes),
            )
            if matched < len(boreholes):
                unmatched = [
                    bh.boring_id for bh in boreholes
                    if bh.boring_id not in plan_coords
                ]
                warnings.append(
                    f"Plan coordinates not found for: {', '.join(unmatched[:10])}"
                )
        else:
            warnings.append("No boring coordinates extracted from plan pages")

    # Extract lab test data from plot/figure pages
    lab_results = []
    if extract_lab:
        from geotech_report_extraction.lab_tests import extract_lab_tests

        lab_results = extract_lab_tests(
            pdf_content, api_key=vision_api_key, model=vision_model,
            backend=llm_backend,
        )
        if lab_results:
            logger.info("Extracted %d lab test results", len(lab_results))
        else:
            warnings.append("No lab test data extracted")

    result = BoreholeLog(
        project=project,
        boreholes=boreholes,
        source_file=str(file_path),
        extraction_warnings=warnings,
        lab_tests=lab_results,
    )

    if output_diggs:
        if output_path is None:
            output_path = file_path.with_suffix(".xml")
        xml_str = to_diggs_xml(result)
        Path(output_path).write_text(xml_str, encoding="utf-8")

    return result


def _extract_with_vision(
    pdf_content: PDFContent,
    boring_groups: dict,
    api_key: Optional[str] = None,
    model: str = "claude-sonnet-4-20250514",
    backend: Optional["LLMBackend"] = None,
) -> tuple[list, list[str]]:
    """Extract using vision LLM only."""
    import fitz

    from geotech_report_extraction.confidence import score_borehole, score_sample
    from geotech_report_extraction.vision_extractor import (
        extract_page_with_vision,
        vision_result_to_borehole,
    )

    boreholes = []
    warnings: list[str] = []

    doc = fitz.open(pdf_content.file_path)

    for boring_id, pages in boring_groups.items():
        all_samples = []
        all_layers = []
        boring_depth = 0.0
        elevation = None

        for page_content in pages:
            page = doc[page_content.page_number - 1]
            pix = page.get_pixmap(dpi=150)
            import base64
            img_b64 = base64.b64encode(pix.tobytes("png")).decode("ascii")

            result = extract_page_with_vision(
                img_b64, api_key=api_key, model=model, backend=backend,
            )
            if result:
                page_bh = vision_result_to_borehole(result)
                all_samples.extend(page_bh.samples)
                all_layers.extend(page_bh.soil_layers)
                if page_bh.depth_ft > boring_depth:
                    boring_depth = page_bh.depth_ft
                if page_bh.elevation_ft is not None:
                    elevation = page_bh.elevation_ft
                if page_bh.boring_id != "UNKNOWN":
                    boring_id = page_bh.boring_id
            else:
                warnings.append(
                    f"Vision extraction failed for {boring_id} page {page_content.page_number}"
                )

        # Score confidence
        from geotech_report_extraction.models import Borehole, DrillingDetails
        borehole = Borehole(
            boring_id=boring_id,
            depth_ft=boring_depth,
            elevation_ft=elevation,
            samples=all_samples,
            soil_layers=all_layers,
        )
        for s in borehole.samples:
            s.confidence = score_sample(s, boring_depth=boring_depth)
        borehole.confidence = score_borehole(borehole)
        boreholes.append(borehole)

    doc.close()
    return boreholes, warnings


def _extract_cross_validated(
    pdf_content: PDFContent,
    boring_groups: dict,
    parser,
    api_key: Optional[str] = None,
    model: str = "claude-sonnet-4-20250514",
    backend: Optional["LLMBackend"] = None,
) -> tuple[list, list[str]]:
    """Run both rule-based and vision extraction, cross-validate results."""
    import fitz

    from geotech_report_extraction.confidence import score_borehole, score_sample
    from geotech_report_extraction.vision_extractor import (
        compare_extractions,
        extract_page_with_vision,
        vision_result_to_borehole,
    )

    boreholes = []
    warnings: list[str] = []

    doc = fitz.open(pdf_content.file_path)

    for boring_id, pages in boring_groups.items():
        # Rule-based extraction
        try:
            rb_borehole = parser.parse_boring_log(pages)
        except Exception as e:
            rb_borehole = None
            warnings.append(f"Rule-based failed for {boring_id}: {e}")

        # Vision extraction
        v_samples = []
        v_layers = []
        v_depth = 0.0
        v_elevation = None
        v_boring_id = boring_id

        for page_content in pages:
            page = doc[page_content.page_number - 1]
            pix = page.get_pixmap(dpi=150)
            import base64
            img_b64 = base64.b64encode(pix.tobytes("png")).decode("ascii")

            result = extract_page_with_vision(
                img_b64, api_key=api_key, model=model, backend=backend,
            )
            if result:
                page_bh = vision_result_to_borehole(result)
                v_samples.extend(page_bh.samples)
                v_layers.extend(page_bh.soil_layers)
                if page_bh.depth_ft > v_depth:
                    v_depth = page_bh.depth_ft
                if page_bh.elevation_ft is not None:
                    v_elevation = page_bh.elevation_ft
                if page_bh.boring_id != "UNKNOWN":
                    v_boring_id = page_bh.boring_id

        from geotech_report_extraction.models import Borehole
        v_borehole = Borehole(
            boring_id=v_boring_id,
            depth_ft=v_depth,
            elevation_ft=v_elevation,
            samples=v_samples,
            soil_layers=v_layers,
        )

        # Cross-validate and choose best result
        if rb_borehole and v_borehole:
            cross_conf = compare_extractions(rb_borehole, v_borehole)

            # Use the result with more data; prefer rule-based when tied
            # (since it's deterministic and has proper column detection)
            rb_has_more = len(rb_borehole.samples) >= len(v_borehole.samples)

            if cross_conf.level == ConfidenceLevel.HIGH:
                # Methods agree — use rule-based (deterministic)
                chosen = rb_borehole
                method_note = "rule-based (cross-validated: HIGH)"
            elif rb_has_more:
                chosen = rb_borehole
                method_note = f"rule-based (cross-validation: {cross_conf.level.value})"
            else:
                chosen = v_borehole
                method_note = f"vision (cross-validation: {cross_conf.level.value})"

            # Apply cross-validation confidence
            for s in chosen.samples:
                s.confidence = score_sample(s, boring_depth=chosen.depth_ft)
            chosen.confidence = cross_conf
            if chosen.confidence.notes:
                chosen.confidence.notes += f" | Method: {method_note}"
            else:
                chosen.confidence.notes = f"Method: {method_note}"

            boreholes.append(chosen)
        elif rb_borehole:
            for s in rb_borehole.samples:
                s.confidence = score_sample(s, boring_depth=rb_borehole.depth_ft)
            rb_borehole.confidence = score_borehole(rb_borehole)
            boreholes.append(rb_borehole)
        elif v_borehole.samples:
            for s in v_borehole.samples:
                s.confidence = score_sample(s, boring_depth=v_borehole.depth_ft)
            v_borehole.confidence = score_borehole(v_borehole)
            boreholes.append(v_borehole)

    doc.close()
    return boreholes, warnings
