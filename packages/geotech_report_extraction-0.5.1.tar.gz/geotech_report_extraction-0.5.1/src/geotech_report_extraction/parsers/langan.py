"""Langan Engineering boring log parser.

Langan's boring log template uses a standard geotechnical log format with:
- Header block: project name, number, boring ID, dates, location, client
- Columnar data: depth | sample no. | type | blow counts | recovery | description
- Footer: groundwater info, drilling details, remarks

This parser uses word-position-based extraction since boring logs are
graphical templates with precise column layouts rather than flowing text.
"""

from __future__ import annotations

import re
from typing import Optional

from geotech_report_extraction.models import (
    Borehole,
    DrillingDetails,
    MoistureCondition,
    Sample,
    SampleType,
    SoilLayer,
    SPTBlowCounts,
    USCSClassification,
    WaterLevelObservation,
)
from geotech_report_extraction.parsers.base import BaseBoringLogParser
from geotech_report_extraction.pdf_parser import PageContent, PDFContent
from geotech_report_extraction.models import Project


class LanganParser(BaseBoringLogParser):
    """Parser for Langan Engineering boring log templates."""

    firm_name = "Langan Engineering"

    # Approximate x-coordinate ranges for columns (as fraction of page width).
    # These will be calibrated per-page based on detected header labels.
    DEFAULT_COLUMNS = {
        "depth": (0.0, 0.10),
        "sample_no": (0.10, 0.18),
        "sample_type": (0.18, 0.24),
        "blow_counts": (0.24, 0.35),
        "recovery": (0.35, 0.42),
        "description": (0.42, 1.0),
    }

    def parse_project_info(self, pdf_content: PDFContent) -> Project:
        """Extract project info from early narrative pages of a Langan report.

        Langan reports have a cover page and early narrative pages with project
        name, number, client, and location. The gINT boring log headers also
        contain some of this info but mixed with column labels, so we prefer
        extracting from narrative pages.
        """
        project = Project(firm=self.firm_name)

        # Scan first 10 pages (narrative section) for project metadata
        for page in pdf_content.pages[:10]:
            if page.is_boring_log:
                continue
            text = page.text

            # Langan Project No.: 700114101
            if project.number is None:
                num_match = re.search(
                    r"(?i)(?:langan\s+)?project\s*(?:no\.?|number|#)\s*:?\s*(\d{6,})",
                    text,
                )
                if num_match:
                    project.number = num_match.group(1)

            # Project name often follows "for" on the cover page
            if project.name is None:
                name_match = re.search(
                    r"(?i)(?:GEOTECHNICAL\s+(?:INVESTIGATION|ENGINEERING)\s+"
                    r"(?:REPORT|STUDY))\s+(?:for\s+)?(.+?)(?:\n|$)",
                    text,
                )
                if name_match:
                    name = name_match.group(1).strip()
                    if name and len(name) > 3:
                        project.name = name

            # "Prepared For:" line gives the client
            if project.client is None:
                client_match = re.search(
                    r"(?i)prepared\s+for\s*:?\s*\n\s*(.+?)(?:\n|$)", text
                )
                if client_match:
                    project.client = client_match.group(1).strip()

            # Location from the cover page (typically city, state)
            if project.location is None:
                loc_match = re.search(
                    r"(?i)(?:located\s+(?:in|at)|(?:,\s*)?(?:California|New\s+Hampshire|"
                    r"New\s+York|New\s+Jersey|Washington|Virginia|Maryland|"
                    r"Pennsylvania|Connecticut|Massachusetts|North\s+Carolina|"
                    r"South\s+Carolina|Georgia|Florida|Texas|Ohio|Illinois|"
                    r"Colorado|DC|D\.C\.))\b.*",
                    text,
                )
                if loc_match:
                    project.location = loc_match.group(0).strip()

        # Fallback: try boring log headers if narrative pages didn't work
        if project.number is None or project.name is None:
            for page in pdf_content.boring_log_pages[:3]:
                text = page.text
                if project.number is None:
                    num_match = re.search(r"(?i)project\s*(?:no\.?)?\s*:?\s*(\d{6,})", text)
                    if num_match:
                        project.number = num_match.group(1)
                if project.name is None:
                    name_match = re.search(
                        r"(?i)(?:^|\n)\s*project\s*\n\s*(.+?)(?:\n|$)", text
                    )
                    if name_match:
                        name = name_match.group(1).strip()
                        # Filter out gINT paths and column headers
                        if name and len(name) > 5 and "\\" not in name and "SYMBOL" not in name.upper():
                            project.name = name

        return project

    def parse_boring_log(self, pages: list[PageContent]) -> Borehole:
        """Parse a Langan boring log from one or more pages."""
        if not pages:
            raise ValueError("No pages provided for boring log parsing")

        first_page = pages[0]
        boring_id = first_page.boring_id or "UNKNOWN"

        # Extract header info from first page
        header = self._parse_header(first_page)

        # Extract samples and soil layers from all pages
        all_samples: list[Sample] = []
        all_layers: list[SoilLayer] = []
        all_water: list[WaterLevelObservation] = []

        for page in pages:
            columns = self._detect_columns(page)
            samples, layers = self._parse_data_rows(page, columns)
            all_samples.extend(samples)
            all_layers.extend(layers)
            water = self._parse_water_levels(page)
            all_water.extend(water)

        return Borehole(
            boring_id=boring_id,
            depth_ft=header.get("depth", self._infer_total_depth(all_samples)),
            elevation_ft=header.get("elevation"),
            latitude=header.get("latitude"),
            longitude=header.get("longitude"),
            date_started=self.parse_date(header.get("date_started", "")),
            date_completed=self.parse_date(header.get("date_completed", "")),
            drilling=DrillingDetails(
                method=header.get("drill_method"),
                hammer_type=header.get("hammer_type"),
                driller=header.get("driller"),
                logged_by=header.get("logged_by"),
            ),
            samples=all_samples,
            soil_layers=all_layers,
            water_levels=all_water,
        )

    def _parse_header(self, page: PageContent) -> dict:
        """Extract header fields from the first page of a boring log."""
        header: dict = {}
        text = page.text

        # Total depth
        depth_match = re.search(
            r"(?i)(?:total\s+)?depth\s*:?\s*([\d.]+)\s*(?:ft|feet|')?", text
        )
        if depth_match:
            header["depth"] = float(depth_match.group(1))

        # Elevation
        elev_match = re.search(
            r"(?i)(?:ground\s+)?(?:surface\s+)?elev(?:ation)?\s*:?\s*(\d+\.?\d*)", text
        )
        if elev_match:
            header["elevation"] = float(elev_match.group(1))

        # Dates
        date_match = re.search(
            r"(?i)date\s*(?:started|drilled|begun)\s*:?\s*(\S+)", text
        )
        if date_match:
            header["date_started"] = date_match.group(1)

        date_match = re.search(
            r"(?i)date\s*(?:completed|finished)\s*:?\s*(\S+)", text
        )
        if date_match:
            header["date_completed"] = date_match.group(1)

        # Drilling method
        method_match = re.search(
            r"(?i)(?:drilling\s+)?method\s*:?\s*(.+?)(?:\n|$)", text
        )
        if method_match:
            header["drill_method"] = method_match.group(1).strip()

        # Hammer type
        hammer_match = re.search(
            r"(?i)hammer\s*(?:type)?\s*:?\s*(.+?)(?:\n|$)", text
        )
        if hammer_match:
            header["hammer_type"] = hammer_match.group(1).strip()

        # Driller
        driller_match = re.search(
            r"(?i)driller\s*:?\s*(.+?)(?:\n|$)", text
        )
        if driller_match:
            header["driller"] = driller_match.group(1).strip()

        # Logged by
        logged_match = re.search(
            r"(?i)logged\s*by\s*:?\s*(.+?)(?:\n|$)", text
        )
        if logged_match:
            header["logged_by"] = logged_match.group(1).strip()

        # Coordinates
        lat_match = re.search(r"(?i)lat(?:itude)?\s*:?\s*([\d.]+)", text)
        lon_match = re.search(r"(?i)lon(?:gitude)?\s*:?\s*(-?[\d.]+)", text)
        if lat_match:
            header["latitude"] = float(lat_match.group(1))
        if lon_match:
            header["longitude"] = float(lon_match.group(1))

        return header

    def _detect_columns(self, page: PageContent) -> dict[str, tuple[float, float]]:
        """Detect column boundaries from header labels and line positions.

        Falls back to default column positions if detection fails.
        """
        if not page.words:
            return self.DEFAULT_COLUMNS

        columns = dict(self.DEFAULT_COLUMNS)
        width = page.width or 612  # Default letter-size width in points

        # Look for column header keywords to calibrate positions
        header_words = [w for w in page.words if w.get("top", 0) < page.height * 0.25]

        for word in header_words:
            text = word.get("text", "").lower()
            x0 = word.get("x0", 0) / width
            x1 = word.get("x1", 0) / width

            if "depth" in text and "sample" not in text:
                columns["depth"] = (max(0, x0 - 0.02), x1 + 0.02)
            elif "sample" in text and "no" in text:
                columns["sample_no"] = (x0 - 0.02, x1 + 0.02)
            elif "type" in text:
                columns["sample_type"] = (x0 - 0.02, x1 + 0.02)
            elif "blow" in text or "spt" in text or "n-value" in text:
                columns["blow_counts"] = (x0 - 0.02, x1 + 0.05)
            elif "recov" in text:
                columns["recovery"] = (x0 - 0.02, x1 + 0.03)
            elif "description" in text or "classification" in text:
                columns["description"] = (x0 - 0.02, 1.0)

        return columns

    def _parse_data_rows(
        self, page: PageContent, columns: dict[str, tuple[float, float]]
    ) -> tuple[list[Sample], list[SoilLayer]]:
        """Extract sample data and soil layers from a boring log page."""
        samples: list[Sample] = []
        layers: list[SoilLayer] = []

        if not page.words:
            return samples, layers

        width = page.width or 612

        # Filter to data area (below header, above footer)
        data_words = [
            w for w in page.words
            if page.height * 0.20 < w.get("top", 0) < page.height * 0.88
        ]

        # Group words by approximate y-position (same row)
        rows = self._group_words_by_row(data_words)

        # Extract descriptions (right side of the log)
        desc_col = columns.get("description", (0.42, 1.0))
        current_desc_lines: list[str] = []
        current_desc_top: Optional[float] = None
        current_depth: Optional[float] = None

        for y_pos, row_words in sorted(rows.items()):
            row_data: dict[str, list[str]] = {col: [] for col in columns}

            for word in row_words:
                x_center = ((word.get("x0", 0) + word.get("x1", 0)) / 2) / width
                text = word.get("text", "").strip()
                if not text:
                    continue

                for col_name, (x_min, x_max) in columns.items():
                    if x_min <= x_center <= x_max:
                        row_data[col_name].append(text)
                        break

            # Parse depth
            depth_text = " ".join(row_data.get("depth", []))
            depth = self.parse_depth(depth_text)

            # Parse description text
            desc_text = " ".join(row_data.get("description", []))

            # Check if this row has sample data (blow counts or sample number)
            blow_text = " ".join(row_data.get("blow_counts", []))
            sample_no_text = " ".join(row_data.get("sample_no", []))
            sample_type_text = " ".join(row_data.get("sample_type", []))
            recovery_text = " ".join(row_data.get("recovery", []))

            if sample_no_text or blow_text:
                spt = self.parse_blow_counts(blow_text) if blow_text else None
                sample_type = self._parse_sample_type(sample_type_text)
                recovery = self.parse_depth(recovery_text)

                # Determine sample depth interval
                sample_top = depth if depth is not None else (
                    current_depth if current_depth is not None else 0.0
                )
                sample_bottom = sample_top + 1.5  # Standard SPT interval

                samples.append(Sample(
                    sample_number=sample_no_text or None,
                    sample_type=sample_type,
                    depth_top_ft=sample_top,
                    depth_bottom_ft=sample_bottom,
                    recovery_in=recovery,
                    spt=spt,
                ))

            # Track soil descriptions for layer building
            if desc_text and not self._is_header_text(desc_text):
                if self._is_new_layer_description(desc_text):
                    # Save previous layer
                    if current_desc_lines and current_depth is not None:
                        layer = self._build_soil_layer(
                            current_depth, depth, current_desc_lines
                        )
                        if layer:
                            layers.append(layer)
                    current_desc_lines = [desc_text]
                    current_desc_top = y_pos
                    if depth is not None:
                        current_depth = depth
                else:
                    current_desc_lines.append(desc_text)

            if depth is not None:
                current_depth = depth

        # Don't forget the last layer
        if current_desc_lines and current_depth is not None:
            layer = self._build_soil_layer(current_depth, None, current_desc_lines)
            if layer:
                layers.append(layer)

        return samples, layers

    def _parse_water_levels(self, page: PageContent) -> list[WaterLevelObservation]:
        """Extract groundwater observations from a boring log page."""
        water_levels: list[WaterLevelObservation] = []
        text = page.text

        # Look for water level patterns
        patterns = [
            r"(?i)(?:ground)?water\s*(?:level|encountered|observed)\s*(?:at)?\s*(\d+\.?\d*)\s*(?:ft|feet|')?",
            r"(?i)water\s*(?:table|surface)\s*(?:at)?\s*(\d+\.?\d*)\s*(?:ft|feet|')?",
            r"(?i)GW[LE]?\s*(?:=|@|at)\s*(\d+\.?\d*)",
        ]

        for pattern in patterns:
            for match in re.finditer(pattern, text):
                try:
                    depth = float(match.group(1))
                except ValueError:
                    continue
                is_during = bool(re.search(
                    r"(?i)during\s+drilling|while\s+drilling", text
                ))
                is_stabilized = bool(re.search(
                    r"(?i)stabili[sz]ed|24\s*(?:hr|hour)", text
                ))
                water_levels.append(WaterLevelObservation(
                    depth_ft=depth,
                    is_during_drilling=is_during,
                    is_stabilized=is_stabilized,
                ))

        return water_levels

    def _group_words_by_row(
        self, words: list[dict], tolerance: float = 3.0
    ) -> dict[float, list[dict]]:
        """Group words that share approximately the same y-position."""
        rows: dict[float, list[dict]] = {}
        for word in words:
            y = word.get("top", 0)
            # Find existing row within tolerance
            matched = False
            for row_y in list(rows.keys()):
                if abs(y - row_y) <= tolerance:
                    rows[row_y].append(word)
                    matched = True
                    break
            if not matched:
                rows[y] = [word]
        return rows

    @staticmethod
    def _parse_sample_type(text: str) -> Optional[SampleType]:
        """Parse sample type abbreviation."""
        text = text.strip().upper()
        mapping = {
            "SS": SampleType.SPLIT_SPOON,
            "ST": SampleType.SHELBY_TUBE,
            "RC": SampleType.ROCK_CORE,
            "GB": SampleType.GRAB,
            "GRAB": SampleType.GRAB,
            "AU": SampleType.AUGER,
            "NX": SampleType.ROCK_CORE,
            "HQ": SampleType.ROCK_CORE,
            "SPT": SampleType.SPLIT_SPOON,
            "CS": SampleType.CONTINUOUS,
        }
        return mapping.get(text)

    @staticmethod
    def _is_header_text(text: str) -> bool:
        """Check if text is a column header rather than data."""
        headers = {
            "depth", "sample", "type", "blow", "recovery", "description",
            "classification", "material", "count", "n-value", "spt",
            "number", "remarks", "graphic", "log", "elev",
        }
        return text.strip().lower() in headers

    @staticmethod
    def _is_new_layer_description(text: str) -> bool:
        """Heuristic: does this text start a new soil layer description?

        New layers typically start with a soil type in caps (SAND, CLAY, etc.)
        or a USCS classification.
        """
        soil_keywords = [
            "SAND", "CLAY", "SILT", "GRAVEL", "FILL", "TOPSOIL",
            "PEAT", "LOAM", "TILL", "ROCK", "SHALE", "SANDSTONE",
            "LIMESTONE", "GRANITE", "GNEISS", "SCHIST", "BASALT",
            "MUDSTONE", "SILTSTONE", "WEATHERED", "DECOMPOSED",
            "ORGANIC", "COBBLES", "BOULDERS", "BEDROCK",
        ]
        text_upper = text.strip().upper()
        return any(text_upper.startswith(kw) for kw in soil_keywords)

    def _build_soil_layer(
        self,
        depth_top: float,
        depth_bottom: Optional[float],
        desc_lines: list[str],
    ) -> Optional[SoilLayer]:
        """Build a SoilLayer model from accumulated description lines."""
        description = " ".join(desc_lines).strip()
        if not description:
            return None

        # Try to extract USCS classification
        uscs = None
        for cls in USCSClassification:
            if re.search(rf"\b{cls.value}\b", description):
                uscs = cls
                break

        # Try to extract color
        color = None
        color_match = re.search(
            r"(?i)\b(brown|gray|grey|tan|red|orange|yellow|black|white|dark|light)\b"
            r"(?:\s+(?:brown|gray|grey|tan|red|orange|to)\b)*",
            description,
        )
        if color_match:
            color = color_match.group(0).strip().lower()

        # Try to extract moisture
        moisture = None
        for mc in MoistureCondition:
            if re.search(rf"(?i)\b{mc.value}\b", description):
                moisture = mc
                break

        return SoilLayer(
            depth_top_ft=depth_top,
            depth_bottom_ft=depth_bottom,
            description=description,
            uscs_classification=uscs,
            color=color,
            moisture=moisture,
        )

    @staticmethod
    def _infer_total_depth(samples: list[Sample]) -> float:
        """Infer total boring depth from deepest sample."""
        if not samples:
            return 0.0
        return max(s.depth_bottom_ft for s in samples)
