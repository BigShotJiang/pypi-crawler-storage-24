"""Langan Engineering boring log parser for DI JSON data.

Purpose-built for the Langan gINT boring log format, which uses a consistent
template across their reports. This parser works directly with Azure Document
Intelligence word positions rather than relying on generic column detection.

Supports two template variants:

1. gINT LANGAN-METRIC template (LB-series borings):
   Page size: 612x792 (standard letter portrait)
   MATERIAL SYMBOL    | x_frac: 0.07 - 0.12  (USCS graphic)
   ELEVATION (m)      | x_frac: 0.12 - 0.17  (Elev values like +1200.5)
   SAMPLE DESCRIPTION | x_frac: 0.17 - 0.53  (soil descriptions, USCS in [brackets])
   DEPTH SCALE (m)    | x_frac: 0.53 - 0.58  (0, 1, 2, 3, 4...)
   SAMPLE NUMBER      | x_frac: 0.58 - 0.61  (S1, S-1, S2, G1 etc.)
   SAMPLE TYPE        | x_frac: 0.61 - 0.63  (SS, GRAB)
   RECOVERY (cm)      | x_frac: 0.63 - 0.66  (recovery in cm)
   PENETRATION        | x_frac: 0.66 - 0.68  (penetration depth)
   BL/15cm            | x_frac: 0.68 - 0.71  (individual blow counts per 15cm)
   N-VALUE (Blows/30) | x_frac: 0.69 - 0.77  (the summed SPT N-value)
   REMARKS            | x_frac: 0.78 - 0.96  (lab results, drilling notes)

2. ECS/Older template (A-*, SB-* borings):
   Different layout with description in the middle — handled as fallback.

Notes:
- Depths are in METERS (converted to feet for output)
- Blow counts appear as individual numbers per 15cm increment
- USCS in brackets at end of description: [SC], [CH], [CL]
- Multi-page borings have "(continued)" marker
- gINT watermark text appears rotated along the left edge
"""

from __future__ import annotations

import re
from typing import Optional

from geotech_report_extraction.models import (
    Borehole,
    DrillingDetails,
    MoistureCondition,
    Project,
    Sample,
    SampleType,
    SoilLayer,
    SPTBlowCounts,
    USCSClassification,
    WaterLevelObservation,
)
from geotech_report_extraction.parsers.base import BaseBoringLogParser
from geotech_report_extraction.pdf_parser import PageContent, PDFContent


# Meters-to-feet conversion
METERS_TO_FEET = 3.28084

# Footer area is bottom 10% of page
FOOTER_Y_FRAC = 0.90

# Default column boundaries as fractions of page width for gINT LANGAN-METRIC.
# Measured from actual DI data (Kampala report, page width = 8.5 inches).
# These are used as fallback when dynamic column detection fails.
_DEFAULT_COLUMNS_METRIC = {
    "material":     (0.07, 0.12),
    "elevation":    (0.12, 0.17),
    "description":  (0.17, 0.535),
    "depth":        (0.535, 0.585),
    "sample_no":    (0.585, 0.615),
    "sample_type":  (0.615, 0.635),
    "recovery":     (0.635, 0.660),
    "penetration":  (0.660, 0.680),
    "bl_15cm":      (0.680, 0.710),
    "n_value":      (0.710, 0.780),
    "remarks":      (0.780, 0.960),
}

# Default column boundaries for ECS/Older template.
# Measured from actual DI data (Kampala A-3, SB-* borings, page width = 8.5 inches).
# ECS borings use: DEPTH | SAMPLE NO | SAMPLE TYPE | SAMPLE DIST | RECOVERY |
#                  DESCRIPTION | ELEVATION | BLOW COUNTS | N-VALUE | REC%
_DEFAULT_COLUMNS_ECS = {
    "depth":        (0.04, 0.10),
    "sample_no":    (0.10, 0.13),
    "sample_type":  (0.13, 0.16),
    "penetration":  (0.16, 0.19),
    "recovery":     (0.19, 0.22),
    "description":  (0.22, 0.55),
    "elevation":    (0.55, 0.65),
    "bl_15cm":      (0.65, 0.75),
    "n_value":      (0.75, 0.88),
    "remarks":      (0.88, 0.96),
}

# Column header keywords used to detect end of header area.
_COLUMN_HEADER_KEYWORDS = {
    "depth", "scale", "number", "type", "description",
    "sample", "material", "symbol", "remarks", "n-value",
    "bl/15cm", "blows/30cm", "(blows/30cm)", "recov.", "penetr.",
    "(cm)", "(m)", "data", "elev.",
}

# Column header label patterns for dynamic detection.
# NOTE: Many Langan headers are rotated (vertical text), which means their
# x0/x1 positions represent the narrow dimension. We use specific labels
# to avoid mismatch. The "depth" label is used for the Depth Scale column
# (mid-page), not the left-side depth markers.
_COLUMN_HEADER_LABELS: dict[str, set[str]] = {
    "material":     {"material"},
    "elevation":    {"elev."},
    "description":  {"sample description"},
    "depth":        {"depth"},
    "sample_no":    set(),  # "Number" is too generic, rely on defaults
    "sample_type":  set(),  # "Type" is too generic, rely on defaults
    "recovery":     {"recov."},
    "penetration":  {"penetr."},
    "bl_15cm":      {"bl/15cm"},
    "n_value":      {"n-value"},
    "remarks":      {"remarks"},
}

# gINT watermark text that appears rotated along the left edge.
_GINT_WATERMARK_PATTERNS = [
    re.compile(r"(?i)LANGAN\.COM"),
    re.compile(r"(?i)\\GINTLOGS\\"),
    re.compile(r"(?i)\.GPJ\b"),
    re.compile(r"(?i)\.GDT\b"),
    re.compile(r"(?i)LANGAN-METRIC"),
    re.compile(r"(?i)Report:\s+Log"),
    re.compile(r"(?i)PROJECT\s+DATA"),
]

# General watermark patterns
_GINT_WATERMARK_GENERAL = re.compile(
    r"(?i)^(?:\d{1,2}/\d{1,2}/\d{2,4}|[A-Z]{2,}\.(?:GPJ|GDT)|[A-Z]{3,}|(?:19|20)\d{2})$"
)

# Valid USCS codes for extraction from descriptions
_VALID_USCS = {cls.value for cls in USCSClassification}


class LanganDIParser(BaseBoringLogParser):
    """Parser for Langan boring logs from DI JSON data."""

    firm_name = "Langan Engineering"

    def __init__(self, unit: str = "auto"):
        """
        Args:
            unit: Depth unit in the boring logs. "m" for meters, "ft" for feet,
                  "auto" to detect from page content.
        """
        self._unit = unit

    # Words that indicate the match is a section heading, not a project name
    _PROJECT_NAME_BLOCKLIST = {
        "DESCRIPTION", "INFORMATION", "PLANS", "MANAGEMENT",
        "DATA", "CONDITIONS", "NUMBER", "SYMBOL", "NO", "NO.",
        "SUMMARY", "REPORT", "SCOPE",
    }

    @staticmethod
    def _is_valid_project_name(name: str) -> bool:
        """Check if extracted project name is a real name, not a heading."""
        if not name or len(name) <= 2:
            return False
        upper = name.upper().strip()
        if upper in LanganDIParser._PROJECT_NAME_BLOCKLIST:
            return False
        return True

    def parse_project_info(self, pdf_content: PDFContent) -> Project:
        """Extract project info from Langan report pages."""
        project = Project(firm=self.firm_name)

        for page in pdf_content.pages[:10]:
            if page.is_boring_log:
                continue
            text = page.text

            if project.number is None:
                m = re.search(
                    r"(?i)(?:project|contract)\s*(?:no\.?|number|#)\s*:?\s*(\S+)",
                    text,
                )
                if m:
                    project.number = m.group(1).strip()

            if project.name is None:
                # Require colon to avoid matching "PROJECT DESCRIPTION" headings
                m = re.search(r"(?i)project\s*:\s*(.+?)(?:\n|$)", text)
                if m and self._is_valid_project_name(m.group(1)):
                    project.name = m.group(1).strip()

            if project.client is None:
                m = re.search(
                    r"(?i)(?:prepared\s+for|client)\s*:?\s*(.+?)(?:\n|$)", text
                )
                if m:
                    project.client = m.group(1).strip()

            if project.location is None:
                m = re.search(r"(?i)location\s*:?\s*(.+?)(?:\n|$)", text)
                if m:
                    project.location = m.group(1).strip()

        # Fallback: try boring log headers — Langan headers use
        # "Project\n<name>" (no colon, value on next line)
        if project.name is None or project.number is None:
            for page in pdf_content.boring_log_pages[:3]:
                text = page.text
                if project.name is None:
                    # Try with colon first
                    m = re.search(r"(?i)project\s*:\s*(.+?)(?:\n|$)", text)
                    if not m or not self._is_valid_project_name(m.group(1)):
                        # Try "Project\n<value>" (value on next line)
                        m = re.search(
                            r"(?i)^Project\n(.+?)$", text, re.MULTILINE
                        )
                    if m and self._is_valid_project_name(m.group(1)):
                        project.name = m.group(1).strip()
                if project.number is None:
                    m = re.search(
                        r"(?i)project\s*(?:no\.?|number)\s*:?\s*(\S+)", text
                    )
                    if m:
                        project.number = m.group(1).strip()
                if project.location is None:
                    m = re.search(r"(?i)location\s*:?\s*(.+?)(?:\n|$)", text)
                    if m:
                        loc = m.group(1).strip()
                        if loc and len(loc) > 2:
                            project.location = loc

        return project

    def parse_boring_log(self, pages: list[PageContent]) -> Borehole:
        """Parse a Langan boring log from one or more pages."""
        if not pages:
            raise ValueError("No pages provided")

        first_page = pages[0]
        boring_id = first_page.boring_id or "UNKNOWN"

        # Detect unit from page content
        unit = self._detect_unit(first_page) if self._unit == "auto" else self._unit

        # Detect template variant
        template = self._detect_template(first_page)

        # Parse header
        header = self._parse_header(first_page)

        all_samples: list[Sample] = []
        all_layers: list[SoilLayer] = []
        all_water: list[WaterLevelObservation] = []

        for page in pages:
            samples, layers = self._parse_data_area(page, unit, template)
            all_samples.extend(samples)
            all_layers.extend(layers)
            water = self._parse_water_levels(page, unit)
            all_water.extend(water)

        # Deduplicate samples that appear on multiple pages (e.g., when
        # a boring's pages are split across PDF sections). Samples with
        # the same sample_number at nearly the same depth are duplicates.
        all_samples = self._deduplicate_samples(all_samples)
        all_layers = self._deduplicate_layers(all_layers)

        # Convert total depth
        total_depth = header.get("depth")
        if total_depth and unit == "m":
            total_depth *= METERS_TO_FEET
        if total_depth is None:
            total_depth = self._infer_total_depth(all_samples)
        # Text-based depth fallback (defense-in-depth)
        if not total_depth:
            for p in pages:
                m = re.search(
                    r"(?i)(?:total\s+)?depth\s*(?:of\s+boring)?\s*:?\s*"
                    r"(\d+\.?\d*)\s*(?:ft|feet|m|meters?|')?",
                    p.text,
                )
                if m:
                    val = float(m.group(1))
                    if unit == "m":
                        val *= METERS_TO_FEET
                    total_depth = val
                    break
        if not total_depth:
            for p in pages:
                m = re.search(
                    r"(?i)(?:boring|hole)\s+terminated\s+at\s+(\d+\.?\d*)",
                    p.text,
                )
                if m:
                    val = float(m.group(1))
                    if unit == "m":
                        val *= METERS_TO_FEET
                    total_depth = val
                    break

        # Convert elevation
        elevation = header.get("elevation")
        if elevation and unit == "m":
            elevation *= METERS_TO_FEET

        return Borehole(
            boring_id=boring_id,
            depth_ft=total_depth or 0.0,
            elevation_ft=elevation,
            latitude=header.get("latitude"),
            longitude=header.get("longitude"),
            date_started=self.parse_date(header.get("date_started", "")),
            date_completed=self.parse_date(header.get("date_completed", "")),
            drilling=DrillingDetails(
                method=header.get("drill_method"),
                rig_type=header.get("rig_type"),
                hammer_type=header.get("hammer_type"),
                driller=header.get("driller"),
                logged_by=header.get("logged_by"),
            ),
            samples=all_samples,
            soil_layers=all_layers,
            water_levels=all_water,
        )

    # ─── Template and Unit Detection ───────────────────────────────

    @staticmethod
    def _detect_template(page: PageContent) -> str:
        """Detect which Langan template variant this page uses.

        Returns:
            "metric" for gINT LANGAN-METRIC template
            "ecs" for the ECS/older template
        """
        text = page.text
        if re.search(r"(?i)LANGAN-METRIC", text):
            return "metric"
        if re.search(r"(?i)BL/15cm", text):
            return "metric"
        # Check for ECS template markers
        if re.search(r"(?i)Blows/6", text):
            return "ecs"
        # ECS template: starts with "CLIENT" at top, has "BORING LOG" in caps
        if re.search(r"(?i)^CLIENT\b", text.strip()):
            return "ecs"
        if re.search(r"BORING\s+LOG\s+OF\s+SOIL", text):
            return "ecs"
        # ECS borings typically have A- or SB- prefix
        if page.boring_id and re.match(r"^(A|SB)-", page.boring_id):
            return "ecs"
        # Default to metric for LB-series borings
        if page.boring_id and page.boring_id.startswith("LB"):
            return "metric"
        return "metric"

    def _detect_unit(self, page: PageContent) -> str:
        """Detect whether depths are in meters or feet."""
        text = page.text.lower()
        if re.search(r"\bdepth\s*\(m\)", text):
            return "m"
        if re.search(r"\bdepth\s*\(ft\)", text):
            return "ft"
        if "(meters)" in text or "(metres)" in text or "(m)" in text:
            return "m"
        if "(feet)" in text:
            return "ft"
        if re.search(r"(?i)langan-metric", text):
            return "m"
        # Default to meters for Langan international projects
        return "m"

    # ─── Header Parsing ────────────────────────────────────────────

    def _parse_header(self, page: PageContent) -> dict:
        """Extract header fields from first page of boring log."""
        header: dict = {}
        text = page.text

        # Total depth
        m = re.search(
            r"(?i)(?:total\s+)?depth\s*(?:of\s+boring)?\s*:?\s*([\d.]+)", text
        )
        if m:
            header["depth"] = float(m.group(1))

        # Elevation - Langan format: "Approx. el 1200.5 (MSL)" or other datums
        # like (WGS 84), (Malawi Trig), or no datum at all
        m = re.search(
            r"(?i)(?:approx\.?\s+)?el\.?\s+(\d+\.?\d*)\s*(?:m\s*)?(?:\([^)]*\))?",
            text,
        )
        if not m:
            m = re.search(
                r"(?i)(?:ground\s+)?(?:surface\s+)?elev(?:ation)?\s*:?\s*(\d+\.?\d*)",
                text,
            )
        if m:
            val_str = m.group(1)
            if val_str and val_str != ".":
                try:
                    header["elevation"] = float(val_str)
                except ValueError:
                    pass

        # Dates
        m = re.search(r"(?i)date\s*started\s*:?\s*(\S+)", text)
        if m:
            header["date_started"] = m.group(1)
        m = re.search(r"(?i)(?:date\s*)?(?:finished|completed)\s*:?\s*(\S+)", text)
        if m:
            header["date_completed"] = m.group(1)

        # Drilling agency
        m = re.search(r"(?i)drilling\s+agency\s*:?\s*(.+?)(?:\n|$)", text)
        if m:
            header["driller"] = m.group(1).strip()

        # Drilling equipment
        m = re.search(r"(?i)drilling\s+equipment\s*:?\s*(.+?)(?:\n|$)", text)
        if m:
            header["rig_type"] = m.group(1).strip()

        # Drilling method
        m = re.search(r"(?i)drilling\s+method\s*:?\s*(.+?)(?:\n|$)", text)
        if m:
            header["drill_method"] = m.group(1).strip()

        # Hammer type
        m = re.search(r"(?i)hammer\s*(?:type)?\s*:?\s*(.+?)(?:\n|$)", text)
        if m:
            header["hammer_type"] = m.group(1).strip()

        # Inspecting engineer / Logged by
        m = re.search(
            r"(?i)(?:inspecting\s+engineer|logged\s+by)\s*:?\s*(.+?)(?:\n|$)", text
        )
        if m:
            header["logged_by"] = m.group(1).strip()

        return header

    # ─── Column Detection ──────────────────────────────────────────

    @staticmethod
    def _detect_header_end(page: PageContent) -> float:
        """Detect the y-position where the header ends and data begins.

        Looks for column header keywords and returns a y-position just below
        the last one.
        """
        max_header_y = 0.0
        for w in page.words:
            word_lower = w["text"].strip().lower()
            if word_lower in _COLUMN_HEADER_KEYWORDS:
                if w["top"] < page.height * 0.45:
                    max_header_y = max(max_header_y, w["bottom"])

        if max_header_y > 0:
            return max_header_y + 5.0

        # Fallback: ~38% for first pages with full header, ~17% for continuation
        text = page.text
        if re.search(r"(?i)\(continued\)", text):
            return page.height * 0.17
        return page.height * 0.38

    @staticmethod
    def _detect_columns(
        page: PageContent, template: str
    ) -> dict[str, tuple[float, float]]:
        """Get column boundaries for the page.

        The Langan gINT templates have many rotated (vertical) column headers,
        which makes dynamic column detection unreliable from x-coordinates.
        Instead, we use well-calibrated default column positions measured from
        actual DI exports. The defaults are consistent across reports because
        Langan uses standardized gINT templates.

        For ECS templates, we use separate calibrated defaults.
        """
        if template == "metric":
            return dict(_DEFAULT_COLUMNS_METRIC)
        else:
            return dict(_DEFAULT_COLUMNS_ECS)

    # ─── Data Extraction ───────────────────────────────────────────

    def _filter_data_words(self, page: PageContent) -> list[dict]:
        """Filter page words to data area only, excluding watermarks."""
        width = page.width
        height = page.height
        header_end = self._detect_header_end(page)
        data_words = []
        for w in page.words:
            if w["top"] < header_end or w["top"] > height * FOOTER_Y_FRAC:
                continue
            x_frac = w["x0"] / width
            # Skip gINT watermark text (rotated along left edge, x < 0.09)
            if x_frac < 0.09:
                text = w["text"]
                if any(p.search(text) for p in _GINT_WATERMARK_PATTERNS):
                    continue
                if _GINT_WATERMARK_GENERAL.match(text):
                    continue
                # Very far left, non-numeric text is likely watermark
                if x_frac < 0.05 and not re.match(r"^[+-]?\d+\.?\d*$", text.strip()):
                    continue
                # Long strings at left edge are watermark paths
                if len(text) > 20:
                    continue
            data_words.append(w)
        return data_words

    def _classify_row_words(
        self,
        row_words: list[dict],
        width: float,
        columns: dict[str, tuple[float, float]],
    ) -> dict[str, list[str]]:
        """Classify words in a row into columns based on x-position."""
        row_data: dict[str, list[str]] = {col: [] for col in columns}
        for w in row_words:
            x_center = ((w["x0"] + w["x1"]) / 2) / width
            text = w["text"].strip()
            if not text:
                continue
            for col_name, (x_min, x_max) in columns.items():
                if x_min <= x_center <= x_max:
                    row_data[col_name].append(text)
                    break
        return row_data

    @staticmethod
    def _group_words_by_row(
        words: list[dict], tolerance: float = 5.0
    ) -> dict[float, list[dict]]:
        """Group words sharing approximately the same y-position."""
        rows: dict[float, list[dict]] = {}
        for word in sorted(words, key=lambda w: w["top"]):
            y = word["top"]
            matched = False
            for row_y in list(rows.keys()):
                if abs(y - row_y) <= tolerance:
                    rows[row_y].append(word)
                    matched = True
                    break
            if not matched:
                rows[y] = [word]
        return rows

    def _build_depth_scale(
        self,
        rows: dict[float, list[dict]],
        width: float,
        columns: dict[str, tuple[float, float]],
    ) -> list[tuple[float, float]]:
        """Build depth calibration points: list of (y_position, depth_value).

        Filters out implausible values (years, page numbers) and enforces
        monotonically increasing depth with y-position.
        """
        raw_points: list[tuple[float, float]] = []
        for y_pos, row_words in sorted(rows.items()):
            row_data = self._classify_row_words(row_words, width, columns)
            for word in row_data.get("depth", []):
                depth = self._parse_numeric(word)
                # Reject negative depths and implausible values (years,
                # page numbers, etc.).  200m ≈ 656ft covers the deepest
                # embassy borings with margin.
                if depth is not None and 0 <= depth <= 200:
                    raw_points.append((y_pos, depth))
                    break

        if len(raw_points) <= 1:
            return raw_points

        # Filter to monotonically increasing depth with y-position.
        points: list[tuple[float, float]] = [raw_points[0]]
        for y, d in raw_points[1:]:
            prev_y, prev_d = points[-1]
            if d >= prev_d and y > prev_y:
                points.append((y, d))
            elif d == prev_d:
                points.append((y, d))

        return points

    def _interpolate_depth(
        self, y: float, scale_points: list[tuple[float, float]]
    ) -> Optional[float]:
        """Interpolate depth at y-position using linear depth scale.

        Clamps extrapolation to never produce negative depths.
        """
        if not scale_points:
            return None
        if len(scale_points) == 1:
            return scale_points[0][1]

        pts = sorted(scale_points)

        # Extrapolate above first point — clamp to >= 0
        if y <= pts[0][0]:
            y0, d0 = pts[0]
            y1, d1 = pts[1]
            if y1 == y0:
                return d0
            rate = (d1 - d0) / (y1 - y0)
            return max(0.0, d0 + rate * (y - y0))

        # Extrapolate below last point
        if y >= pts[-1][0]:
            y0, d0 = pts[-2]
            y1, d1 = pts[-1]
            if y1 == y0:
                return d1
            rate = (d1 - d0) / (y1 - y0)
            return max(0.0, d1 + rate * (y - y1))

        # Interpolate between bracketing points
        for i in range(len(pts) - 1):
            y0, d0 = pts[i]
            y1, d1 = pts[i + 1]
            if y0 <= y <= y1:
                if y1 == y0:
                    return d0
                frac = (y - y0) / (y1 - y0)
                return d0 + frac * (d1 - d0)

        return None

    def _parse_data_area(
        self, page: PageContent, unit: str, template: str
    ) -> tuple[list[Sample], list[SoilLayer]]:
        """Extract samples and soil layers from the data area of a boring log page.

        Uses depth scale calibration: first collects depth markers from the depth
        column, then interpolates the depth for every row based on y-position.
        """
        samples: list[Sample] = []
        layers: list[SoilLayer] = []

        if not page.words:
            return samples, layers

        width = page.width
        columns = self._detect_columns(page, template)
        data_words = self._filter_data_words(page)

        # Group words into rows by y-position
        rows = self._group_words_by_row(data_words, tolerance=5.0)

        # PASS 1: Build depth scale from depth column markers
        scale_points = self._build_depth_scale(rows, width, columns)

        # PASS 2: Scan all rows to collect per-row data
        row_info: list[dict] = []  # sorted by y_pos
        for y_pos, row_words in sorted(rows.items()):
            row_data = self._classify_row_words(row_words, width, columns)

            sample_no_text = " ".join(row_data.get("sample_no", []))
            sample_no = self._clean_sample_no(sample_no_text)

            sample_type_text = " ".join(row_data.get("sample_type", []))
            sample_type_raw = sample_type_text.strip().upper() if sample_type_text.strip() else ""
            # Validate sample type
            if sample_type_raw not in {"SS", "GRAB", "ST", "RC", "AU", "CS", "NR", ""}:
                sample_type_raw = ""

            recovery_text = " ".join(row_data.get("recovery", []))
            recovery_val = recovery_text.strip() if recovery_text.strip() else ""

            # Blow counts from bl_15cm column
            blow_vals = []
            for text in row_data.get("bl_15cm", []):
                text_clean = text.strip().rstrip(":")
                if re.match(r"^\d{1,3}$", text_clean):
                    blow_vals.append(int(text_clean))

            # N-value from n_value column
            n_val_str = ""
            for text in row_data.get("n_value", []):
                text_clean = text.strip().rstrip(":'")
                m = re.match(r"^(\d{1,3})$", text_clean)
                if m:
                    n_val_str = m.group(1)
                elif re.match(r"^\d+/\d+", text_clean):
                    n_val_str = text_clean

            desc_text = " ".join(row_data.get("description", []))

            row_info.append({
                "y": y_pos,
                "sample_no": sample_no,
                "sample_type": sample_type_raw,
                "recovery": recovery_val,
                "blow_vals": blow_vals,
                "n_val_str": n_val_str,
                "desc": desc_text,
            })

        # PASS 3: Identify sample clusters.
        # A sample is anchored by a row with a valid sample number.
        # We collect nearby blow count values and the sample type from
        # rows within a vertical tolerance.
        sample_anchor_indices: list[int] = []
        for i, ri in enumerate(row_info):
            if ri["sample_no"]:
                sample_anchor_indices.append(i)

        # For each sample anchor, gather blow counts from nearby rows
        used_blow_rows: set[int] = set()
        for anchor_idx in sample_anchor_indices:
            anchor = row_info[anchor_idx]
            anchor_y = anchor["y"]
            depth = self._interpolate_depth(anchor_y, scale_points)
            if depth is None:
                continue

            depth_ft = depth * METERS_TO_FEET if unit == "m" else depth

            # Find sample type (from same row or very nearby)
            sample_type_str = anchor["sample_type"]
            if not sample_type_str:
                for ri in row_info:
                    if abs(ri["y"] - anchor_y) < 15.0 and ri["sample_type"]:
                        sample_type_str = ri["sample_type"]
                        break

            st = self._parse_sample_type(sample_type_str)

            # Find recovery from same row or nearby
            recovery_str = anchor["recovery"]
            if not recovery_str:
                for ri in row_info:
                    if abs(ri["y"] - anchor_y) < 15.0 and ri["recovery"]:
                        recovery_str = ri["recovery"]
                        break

            # Standard SPT interval
            if unit == "m":
                interval_ft = 0.45 * METERS_TO_FEET
            else:
                interval_ft = 1.5

            # Collect blow counts from nearby rows (within ~30pt = ~0.5m on page)
            y_tolerance = 30.0
            nearby_blows: list[tuple[float, int]] = []
            nearby_n: list[tuple[float, str]] = []

            for j, ri in enumerate(row_info):
                if abs(ri["y"] - anchor_y) < y_tolerance:
                    if j not in used_blow_rows:
                        for bv in ri["blow_vals"]:
                            nearby_blows.append((ri["y"], bv))
                        if ri["n_val_str"]:
                            nearby_n.append((ri["y"], ri["n_val_str"]))

            nearby_blows.sort(key=lambda t: t[0])

            # Mark blow rows as used
            for j, ri in enumerate(row_info):
                if abs(ri["y"] - anchor_y) < y_tolerance and ri["blow_vals"]:
                    used_blow_rows.add(j)

            spt = self._build_spt_from_blows(nearby_blows, nearby_n)

            # Parse recovery
            recovery_in = None
            if recovery_str:
                rv = self._parse_numeric(recovery_str)
                if rv is not None:
                    # Recovery is in cm for metric, convert to inches
                    if unit == "m":
                        recovery_in = rv / 2.54
                    else:
                        recovery_in = rv

            samples.append(Sample(
                sample_number=anchor["sample_no"],
                sample_type=st,
                depth_top_ft=round(depth_ft, 1),
                depth_bottom_ft=round(depth_ft + interval_ft, 1),
                spt=spt,
                recovery_in=round(recovery_in, 1) if recovery_in is not None else None,
            ))

        # PASS 4: Build soil layers from description text
        current_desc_lines: list[str] = []
        current_layer_start: Optional[float] = None

        for ri in row_info:
            desc_text = ri["desc"]
            depth = self._interpolate_depth(ri["y"], scale_points)

            if desc_text and not self._is_header_text(desc_text):
                if self._is_new_layer_description(desc_text):
                    if current_desc_lines and current_layer_start is not None:
                        layer = self._build_soil_layer(
                            current_layer_start, depth, current_desc_lines, unit
                        )
                        if layer:
                            layers.append(layer)
                    current_desc_lines = [desc_text]
                    current_layer_start = depth
                else:
                    current_desc_lines.append(desc_text)

        # Don't forget last layer
        if current_desc_lines and current_layer_start is not None:
            last_depth = scale_points[-1][1] if scale_points else None
            layer = self._build_soil_layer(
                current_layer_start, last_depth, current_desc_lines, unit
            )
            if layer:
                layers.append(layer)

        return samples, layers

    def _parse_water_levels(
        self, page: PageContent, unit: str
    ) -> list[WaterLevelObservation]:
        """Extract groundwater observations from the page."""
        water_levels: list[WaterLevelObservation] = []
        text = page.text

        patterns = [
            r"(?i)(?:ground)?water\s*(?:level|encountered|observed)\s*(?:at)?\s*([\d.]+)\s*(?:m|ft|feet)?",
            r"(?i)water\s*(?:table|surface)\s*(?:at)?\s*([\d.]+)",
            r"(?i)seepage\s*(?:at|@)\s*([\d.]+)",
        ]

        for pattern in patterns:
            for match in re.finditer(pattern, text):
                depth_val = float(match.group(1))
                if unit == "m":
                    depth_val *= METERS_TO_FEET

                is_during = bool(
                    re.search(r"(?i)during\s+drilling|while\s+drilling", text)
                )
                is_stabilized = bool(
                    re.search(r"(?i)stabili[sz]ed|24\s*(?:hr|hour)", text)
                )

                water_levels.append(WaterLevelObservation(
                    depth_ft=depth_val,
                    is_during_drilling=is_during,
                    is_stabilized=is_stabilized,
                ))

        return water_levels

    # ─── Blow Count and SPT Parsing ────────────────────────────────

    @staticmethod
    def _build_spt_from_blows(
        nearby_blows: list[tuple[float, int]],
        nearby_n: list[tuple[float, str]],
    ) -> Optional[SPTBlowCounts]:
        """Build SPT blow count data from individual blow values and N-value.

        Langan format has individual blow counts per 15cm increment arranged
        vertically. Typically 3 values for a standard SPT:
          - 1st 15cm (seating)
          - 2nd 15cm
          - 3rd 15cm
        N-value = sum of 2nd + 3rd increments

        Sometimes there are 4+ values for deeper penetration tests.
        """
        # Try to get N-value from the N-value column
        n_val = None
        refusal = False
        for _, nv in nearby_n:
            if "/" in nv:
                # Refusal format like "50/24-"
                refusal = True
                m = re.match(r"(\d+)", nv)
                if m:
                    n_val = int(m.group(1))
            else:
                try:
                    n_val = int(nv)
                except ValueError:
                    pass

        if n_val is not None and n_val >= 50:
            refusal = True

        blow_values = [b[1] for b in nearby_blows]

        if len(blow_values) >= 3:
            # Standard SPT: first is seating, next two are the N-value increments
            b1 = blow_values[0]
            b2 = blow_values[1]
            b3 = blow_values[2]
            computed_n = b2 + b3
            return SPTBlowCounts(
                first_6in=b1,
                second_6in=b2,
                third_6in=b3,
                n_value=n_val if n_val is not None else computed_n,
                refusal=refusal or computed_n >= 50,
            )
        elif len(blow_values) == 2:
            b1 = blow_values[0]
            b2 = blow_values[1]
            return SPTBlowCounts(
                first_6in=b1,
                second_6in=b2,
                n_value=n_val,
                refusal=refusal,
            )
        elif len(blow_values) == 1:
            return SPTBlowCounts(
                first_6in=blow_values[0],
                n_value=n_val,
                refusal=refusal,
            )
        elif n_val is not None:
            return SPTBlowCounts(
                n_value=n_val,
                refusal=refusal,
            )

        return None

    # ─── Helper Methods ────────────────────────────────────────────

    @staticmethod
    def _parse_numeric(text: str) -> Optional[float]:
        """Parse a numeric value from text."""
        if not text:
            return None
        text = text.strip()
        m = re.match(r"^[+-]?(\d+\.?\d*)$", text)
        if m:
            return float(m.group(1))
        return None

    @staticmethod
    def _clean_sample_no(text: str) -> Optional[str]:
        """Clean up sample number text."""
        if not text:
            return None
        text = text.strip()
        if not text:
            return None
        # Filter out header words and description fragments
        if text.lower() in {
            "depth", "data", "sample", "no", "no.", "number",
            "type", "scale", "(m)", "-", "ss", "grab", "st", "rc",
        }:
            return None
        if text.startswith("-") or text.startswith("(") or text.startswith("["):
            return None
        # Must look like a sample number: S1, S-1, G1, or bare digit
        m = re.match(r"^[A-Z]-?\d+$", text, re.IGNORECASE)
        if m:
            return text
        if text.isdigit():
            return text
        # Reject anything that doesn't look like a sample ID
        # (avoids soil descriptions, USCS codes, etc.)
        return None

    @staticmethod
    def _parse_sample_type(text: str) -> Optional[SampleType]:
        """Parse sample type from text."""
        if not text:
            return None
        text = text.strip().upper()
        if text == "SS":
            return SampleType.SPLIT_SPOON
        if text == "GRAB":
            return SampleType.GRAB
        if text == "ST":
            return SampleType.SHELBY_TUBE
        if text == "RC":
            return SampleType.ROCK_CORE
        if text == "AU":
            return SampleType.AUGER
        if text in {"CS", "CONT"}:
            return SampleType.CONTINUOUS
        if text == "NR":
            return SampleType.NO_RECOVERY
        if text:
            return SampleType.OTHER
        return None

    @staticmethod
    def _extract_uscs_from_description(text: str) -> Optional[USCSClassification]:
        """Extract USCS classification from description text.

        Langan gINT template: USCS in brackets at end: [SC], [CH], [CL]
        ECS template: USCS in parentheses at start: (CH), (SC)
        Also check for standalone USCS codes like TOPSOIL, FILL
        """
        # Brackets: [SC], [CH], [CL-ML]
        m = re.search(r"\[([A-Z]{2}(?:-[A-Z]{2})?)\]", text)
        if m:
            code = m.group(1).split("-")[0]  # Take first part of dual classification
            if code in _VALID_USCS:
                return USCSClassification(code)

        # Parentheses: (CH), (SC)
        m = re.search(r"\(([A-Z]{2}(?:-[A-Z]{2})?)\)", text)
        if m:
            code = m.group(1).split("-")[0]
            if code in _VALID_USCS:
                return USCSClassification(code)

        # Standalone USCS codes in text
        for cls in USCSClassification:
            if re.search(rf"\b{cls.value}\b", text):
                return cls

        return None

    @staticmethod
    def _is_header_text(text: str) -> bool:
        """Check if text is a column header."""
        headers = {
            "depth", "sample", "type", "blow", "recovery", "description",
            "classification", "material", "count", "n-value", "spt",
            "number", "remarks", "graphic", "log", "elev", "boring",
            "symbol", "sampling", "data", "bl/15cm", "(blows/30cm)",
            "continued", "next", "page", "scale", "(m)", "(cm)",
            "recov.", "penetr.", "sample data", "sample description",
            "depth scale", "10 20 30 40", "50",
        }
        return text.strip().lower() in headers

    @staticmethod
    def _is_new_layer_description(text: str) -> bool:
        """Heuristic: does this text start a new soil layer?"""
        soil_keywords = [
            "SAND", "CLAY", "SILT", "GRAVEL", "FILL", "TOPSOIL",
            "PEAT", "LOAM", "TILL", "ROCK", "SHALE", "SANDSTONE",
            "LIMESTONE", "GRANITE", "GNEISS", "SCHIST", "BASALT",
            "MUDSTONE", "SILTSTONE", "WEATHERED", "DECOMPOSED",
            "ORGANIC", "COBBLES", "BOULDERS", "BEDROCK", "RESIDUUM",
            "FAT CLAY", "LEAN CLAY", "SILTY", "SANDY", "CLAYEY",
            "ASPHALT", "CONCRETE", "AGGREGATE", "LATERITE",
            "DARK", "BROWN", "GRAY", "GREY", "RED", "TAN",
        ]
        text_upper = text.strip().upper()
        # Skip if it's clearly a continuation line (starts lowercase or with parens)
        first_char = text.strip()[0] if text.strip() else ""
        if first_char.islower() or first_char in "([":
            return False
        return any(text_upper.startswith(kw) for kw in soil_keywords)

    def _build_soil_layer(
        self,
        depth_top: Optional[float],
        depth_bottom: Optional[float],
        desc_lines: list[str],
        unit: str,
    ) -> Optional[SoilLayer]:
        """Build a SoilLayer from accumulated description lines."""
        description = " ".join(desc_lines).strip()
        if not description:
            return None

        # Convert depths
        if depth_top is None:
            depth_top = 0.0
        if unit == "m":
            top_ft = depth_top * METERS_TO_FEET
            bottom_ft = depth_bottom * METERS_TO_FEET if depth_bottom is not None else None
        else:
            top_ft = depth_top
            bottom_ft = depth_bottom

        # Extract USCS from description
        uscs = self._extract_uscs_from_description(description)

        # Extract color
        color = None
        color_match = re.search(
            r"(?i)\b(brown|gray|grey|tan|red|orange|yellow|black|white|dark|light)\b"
            r"(?:\s+(?:brown|gray|grey|tan|red|orange|to)\b)*",
            description,
        )
        if color_match:
            color = color_match.group(0).strip().lower()

        # Extract moisture
        moisture = None
        for mc in MoistureCondition:
            if re.search(rf"(?i)\b{mc.value}\b", description):
                moisture = mc
                break

        return SoilLayer(
            depth_top_ft=top_ft,
            depth_bottom_ft=bottom_ft,
            description=description,
            uscs_classification=uscs,
            color=color,
            moisture=moisture,
        )

    @staticmethod
    def _deduplicate_samples(samples: list[Sample]) -> list[Sample]:
        """Remove duplicate samples (same sample_number at similar depth)."""
        if not samples:
            return samples
        seen: dict[str, Sample] = {}
        result: list[Sample] = []
        for s in samples:
            key = f"{s.sample_number}_{round(s.depth_top_ft, 0)}"
            if key in seen:
                # Keep the one with more data (prefer one with SPT or recovery)
                existing = seen[key]
                if (s.spt and not existing.spt) or (s.recovery_in and not existing.recovery_in):
                    seen[key] = s
                    result = [x for x in result if not (
                        x.sample_number == s.sample_number
                        and abs(x.depth_top_ft - s.depth_top_ft) < 1.0
                    )]
                    result.append(s)
            else:
                seen[key] = s
                result.append(s)
        return result

    @staticmethod
    def _deduplicate_layers(layers: list[SoilLayer]) -> list[SoilLayer]:
        """Remove duplicate soil layers (same description at similar depth)."""
        if not layers:
            return layers
        result: list[SoilLayer] = []
        for layer in layers:
            is_dup = False
            for existing in result:
                if (abs(existing.depth_top_ft - layer.depth_top_ft) < 1.0
                        and existing.description[:40] == layer.description[:40]):
                    is_dup = True
                    break
            if not is_dup:
                result.append(layer)
        return result

    @staticmethod
    def _infer_total_depth(samples: list[Sample]) -> float:
        """Infer total boring depth from deepest sample."""
        if not samples:
            return 0.0
        return max(s.depth_bottom_ft for s in samples)
