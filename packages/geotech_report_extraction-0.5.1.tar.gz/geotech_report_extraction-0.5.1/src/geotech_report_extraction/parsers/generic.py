"""Generic boring log parser for any geotechnical firm.

Uses spatial layout data from PyMuPDF to determine data positions:
- Identifies the graphical depth scale by finding columns of monotonically
  increasing numbers with a linear y-position relationship
- Maps any data element's Y-position to a depth via this linear scale
- Detects column boundaries from vertical line dividers or data clustering
- Classifies columns by content: blow counts, descriptions, sample types
"""

from __future__ import annotations

import re
from collections import defaultdict
from typing import Optional

from geotech_report_extraction.confidence import score_borehole, score_sample
from geotech_report_extraction.models import (
    Borehole,
    DrillingDetails,
    MoistureCondition,
    Sample,
    SampleType,
    SoilLayer,
    SPTBlowCounts,
    USCSClassification,
    WaterLevelObservation,
)
from geotech_report_extraction.parsers.base import BaseBoringLogParser
from geotech_report_extraction.pdf_parser import PageContent


_SOIL_START_KEYWORDS = [
    "SAND", "CLAY", "SILT", "GRAVEL", "FILL", "TOPSOIL",
    "PEAT", "LOAM", "TILL", "ROCK", "SHALE", "SANDSTONE",
    "LIMESTONE", "MUDSTONE", "SILTSTONE", "WEATHERED",
    "ORGANIC", "COBBLES", "BOULDERS", "BEDROCK", "LEAN CLAY",
    "FAT CLAY", "SILTY", "SANDY", "CLAYEY", "ASPHALT",
    "CONCRETE", "AGGREGATE",
]

_SAMPLE_TYPE_CODES = {"SS", "ST", "AU", "RC", "NX", "HQ", "RB", "SA", "CS"}

_BLOW_COUNT_RE = re.compile(r"^\d{1,2}-\d{1,2}-\d{1,3}$")
_N_VALUE_RE = re.compile(r"^N\s*=\s*\d+$", re.IGNORECASE)
_STANDALONE_NVAL_RE = re.compile(r"^\d{1,3}$")  # single integer N-value
_DEPTH_RE = re.compile(r"^\d{1,3}(?:\.\d)?$")


class GenericParser(BaseBoringLogParser):
    """Parser that handles any boring log format using spatial layout data."""

    firm_name = "Generic"

    def __init__(self) -> None:
        super().__init__()
        # Set by _detect_columns when stacked blow count columns are found.
        # List of (x_left, x_right) tuples for each sub-column.
        self._stacked_blow_columns: Optional[list[tuple[float, float]]] = None

    def parse_boring_log(self, pages: list[PageContent]) -> Borehole:
        if not pages:
            raise ValueError("No pages provided")

        first_page = pages[0]
        boring_id = first_page.boring_id or "UNKNOWN"

        header = self._parse_header(first_page)
        all_samples: list[Sample] = []
        all_layers: list[SoilLayer] = []
        all_water: list[WaterLevelObservation] = []

        last_depth: Optional[float] = None
        for page in pages:
            columns = self._detect_columns(page)
            depth_scale = self._detect_depth_scale(page)
            samples, layers, last_depth = self._parse_data_rows(
                page, columns, carry_depth=last_depth,
                depth_scale=depth_scale,
            )
            all_samples.extend(samples)
            all_layers.extend(layers)
            water = self._parse_water_levels(page)
            all_water.extend(water)

        # Deduplicate water levels by depth
        seen_water_depths: set[float] = set()
        unique_water: list[WaterLevelObservation] = []
        for w in all_water:
            if w.depth_ft not in seen_water_depths:
                seen_water_depths.add(w.depth_ft)
                unique_water.append(w)
        all_water = unique_water

        total_depth = header.get("depth", 0.0)
        if not total_depth and all_samples:
            total_depth = max(s.depth_bottom_ft for s in all_samples)
        if not total_depth:
            for page in pages:
                m = re.search(
                    r"(?i)(?:boring|hole)\s+terminated\s+at\s+(\d+\.?\d*)\s*(?:ft|feet)",
                    page.text,
                )
                if m:
                    total_depth = float(m.group(1))
                    break

        depth = total_depth or 0.0

        # Score confidence for each sample
        for sample in all_samples:
            sample.confidence = score_sample(sample, boring_depth=depth)

        borehole = Borehole(
            boring_id=boring_id,
            depth_ft=depth,
            elevation_ft=header.get("elevation"),
            latitude=header.get("latitude"),
            longitude=header.get("longitude"),
            date_started=self.parse_date(header.get("date_started", "")),
            date_completed=self.parse_date(header.get("date_completed", "")),
            drilling=DrillingDetails(
                method=header.get("drill_method"),
                hammer_type=header.get("hammer_type"),
                driller=header.get("driller"),
            ),
            samples=all_samples,
            soil_layers=all_layers,
            water_levels=all_water,
        )

        # Score overall borehole confidence
        borehole.confidence = score_borehole(borehole)

        return borehole

    def _parse_header(self, page: PageContent) -> dict:
        """Extract header fields from text using common patterns."""
        header: dict = {}
        text = page.text

        # Total depth
        for pattern in [
            r"(?i)(?:total\s+)?depth\s*:?\s*(\d+\.?\d*)\s*(?:ft|feet|')?",
            r"(?i)(?:boring|hole)\s+terminated\s+at\s+(\d+\.?\d*)\s*(?:ft|feet)",
        ]:
            m = re.search(pattern, text)
            if m:
                header["depth"] = float(m.group(1))
                break

        # Elevation (various formats)
        for pattern in [
            r"(?i)(?:ground\s+)?(?:surface\s+)?elev(?:ation)?\s*:?\s*(-?\d+\.?\d*)",
            r"(?i)elev\.\s*:?\s*(-?\d+\.?\d*)",
        ]:
            m = re.search(pattern, text)
            if m:
                header["elevation"] = float(m.group(1))
                break

        # Latitude / Longitude
        # Pattern: "Latitude: 33.75744°" or "Lat: 33.75744"
        m = re.search(
            r"(?i)lat(?:itude)?\s*:?\s*(-?\d+\.\d{3,7})°?",
            text,
        )
        if m:
            header["latitude"] = float(m.group(1))
        m = re.search(
            r"(?i)lon(?:gitude)?\s*:?\s*(-?\d+\.\d{3,7})°?",
            text,
        )
        if m:
            header["longitude"] = float(m.group(1))

        # Coordinate pairs: "N: 699450.801  E: 1108734.334" (state plane)
        # These are NOT lat/long; skip for now.

        # Dates — support multiple formats
        # Covers: "Date Started:", "Boring Started:", "Start Date:", etc.
        for pattern in [
            r"(?i)date\s*(?:started|drilled|begun)\s*:?\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})",
            r"(?i)(?:boring|hole)?\s*started?\s*:?\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})",
            r"(?i)(?:start|begin)\s*(?:date)?\s*:?\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})",
        ]:
            m = re.search(pattern, text)
            if m:
                header["date_started"] = m.group(1)
                break
        for pattern in [
            r"(?i)date\s*(?:completed|finished|ended)\s*:?\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})",
            r"(?i)(?:boring|hole)?\s*completed?\s*:?\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})",
            r"(?i)(?:end|completion)\s*(?:date)?\s*:?\s*(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})",
        ]:
            m = re.search(pattern, text)
            if m:
                header["date_completed"] = m.group(1)
                break

        # Drilling method
        m = re.search(r"(?i)(?:drilling\s+)?method\s*:?\s*(.+?)(?:\n|$)", text)
        if m:
            header["drill_method"] = m.group(1).strip()
        m = re.search(r"(?i)hammer\s*(?:type)?\s*:?\s*(.+?)(?:\n|$)", text)
        if m:
            header["hammer_type"] = m.group(1).strip()
        m = re.search(r"(?i)driller\s*:?\s*(.+?)(?:\n|$)", text)
        if m:
            header["driller"] = m.group(1).strip()

        # Also search word-level data for coords (sometimes not in plain text)
        if "latitude" not in header and page.words:
            self._parse_header_from_words(page, header)

        return header

    @staticmethod
    def _parse_header_from_words(page: PageContent, header: dict) -> None:
        """Extract header fields from word positions when text parsing misses them."""
        width = page.width or 612.0
        height = page.height or 792.0

        # Only look in header zone (top 25% of page)
        header_words = [
            w for w in page.words
            if w.get("top", 0) < height * 0.25
        ]

        for i, w in enumerate(header_words):
            text = w.get("text", "").strip().lower()

            # Look for "Latitude:" followed by a number
            if text.startswith("lat") and "latitude" not in header:
                for j in range(i + 1, min(i + 4, len(header_words))):
                    nxt = header_words[j].get("text", "").strip()
                    nxt = nxt.rstrip("°")
                    try:
                        val = float(nxt)
                        if 20 <= abs(val) <= 90:
                            header["latitude"] = val
                            break
                    except ValueError:
                        continue

            if text.startswith("lon") and "longitude" not in header:
                for j in range(i + 1, min(i + 4, len(header_words))):
                    nxt = header_words[j].get("text", "").strip()
                    nxt = nxt.rstrip("°")
                    try:
                        val = float(nxt)
                        if 20 <= abs(val) <= 180:
                            header["longitude"] = val
                            break
                    except ValueError:
                        continue

    def _detect_columns(self, page: PageContent) -> dict[str, tuple[float, float]]:
        """Detect column boundaries using vertical line dividers and data patterns.

        First attempts to use vertical line drawings (column dividers) for
        precise boundaries, then falls back to data pattern analysis.
        """
        if not page.words:
            return self._default_columns()

        width = page.width or 612.0
        height = page.height or 792.0

        # Try line-based detection first (more accurate)
        line_cols = self._detect_columns_from_lines(page, width, height)
        if line_cols:
            # Always check for stacked blow count columns — they may exist
            # even when line detection found a "blow_counts" column (which
            # could be a misidentified recovery/RQD column).
            data_words = [
                w for w in page.words
                if height * 0.15 < w.get("top", 0) < height * 0.90
            ]
            d_xs = [
                w.get("x0", 0) / width for w in data_words
                if _DEPTH_RE.match(w.get("text", "").strip())
                and w.get("x0", 0) / width < 0.25
            ]
            stacked = self._find_stacked_blow_count_columns(
                data_words, width, d_xs,
            )
            if stacked:
                group_xs = stacked[0]
                bc_left = min(group_xs) - 0.02
                bc_right = max(group_xs) + 0.02
                line_cols["blow_counts"] = (bc_left, bc_right)
                self._stacked_blow_columns = [
                    (gx - 0.02, gx + 0.02) for gx in group_xs
                ]
            else:
                self._stacked_blow_columns = None
            return line_cols

        # Fall back to data-driven detection
        data_words = [
            w for w in page.words
            if height * 0.15 < w.get("top", 0) < height * 0.90
        ]

        # Classify each word by what it looks like
        depth_xs: list[float] = []
        blow_count_xs: list[float] = []
        sample_type_xs: list[float] = []
        description_xs: list[float] = []

        for w in data_words:
            text = w.get("text", "").strip()
            x0 = w.get("x0", 0) / width
            if not text:
                continue

            if _BLOW_COUNT_RE.match(text) or _N_VALUE_RE.match(text):
                # Exclude rightmost 20% of page (Atterberg Limits LL-PL-PI
                # has the same format as blow counts)
                if x0 < 0.80:
                    blow_count_xs.append(x0)
            elif text.upper() in _SAMPLE_TYPE_CODES:
                sample_type_xs.append(x0)
            elif _DEPTH_RE.match(text) and x0 < 0.25:
                depth_xs.append(x0)
            elif any(text.upper().startswith(kw) for kw in _SOIL_START_KEYWORDS):
                description_xs.append(x0)

        # If no blow counts found via pattern matching, try two approaches:
        # 1. Stacked blow count columns (three adjacent integer columns)
        # 2. Standalone N-value column (single column of varied integers)
        if not blow_count_xs:
            stacked = self._find_stacked_blow_count_columns(
                data_words, width, depth_xs
            )
            if stacked:
                # Use the first triplet/pair found
                group_xs = stacked[0]
                # Register as separate blow count sub-columns
                # The leftmost column in the group represents the first 6-inch
                for gx in group_xs:
                    blow_count_xs.append(gx)
                # Store stacked column info for _parse_data_rows
                self._stacked_blow_columns = [
                    (gx - 0.02, gx + 0.02) for gx in group_xs
                ]
            else:
                nval_cols = self._find_standalone_nvalue_column(
                    data_words, width, depth_xs
                )
                if nval_cols:
                    blow_count_xs = nval_cols
                self._stacked_blow_columns = None
        else:
            self._stacked_blow_columns = None

        # Build column positions from median x-positions
        col_positions: dict[str, float] = {}
        if depth_xs:
            col_positions["depth"] = sorted(depth_xs)[len(depth_xs) // 2]
        if description_xs:
            col_positions["description"] = sorted(description_xs)[
                len(description_xs) // 2
            ]
        if blow_count_xs:
            col_positions["blow_counts"] = sorted(blow_count_xs)[
                len(blow_count_xs) // 2
            ]
        if sample_type_xs:
            col_positions["sample_type"] = sorted(sample_type_xs)[
                len(sample_type_xs) // 2
            ]

        if not col_positions:
            return self._default_columns()

        # Build non-overlapping column ranges sorted by position
        sorted_cols = sorted(col_positions.items(), key=lambda x: x[1])
        columns: dict[str, tuple[float, float]] = {}

        for i, (col_name, x_pos) in enumerate(sorted_cols):
            # Left boundary: midpoint between this and previous column
            if i == 0:
                left = max(0, x_pos - 0.03)
            else:
                prev_pos = sorted_cols[i - 1][1]
                left = (prev_pos + x_pos) / 2

            # Right boundary: midpoint between this and next column
            if i + 1 < len(sorted_cols):
                next_pos = sorted_cols[i + 1][1]
                right = (x_pos + next_pos) / 2
            else:
                right = 1.0 if col_name == "description" else x_pos + 0.08

            columns[col_name] = (left, min(right, 1.0))

        # Ensure we have at least depth and description
        if "depth" not in columns:
            columns["depth"] = (0.0, 0.12)
        if "description" not in columns:
            columns["description"] = (0.10, 0.40)

        return columns

    def _detect_columns_from_lines(
        self, page: PageContent, width: float, height: float,
    ) -> Optional[dict[str, tuple[float, float]]]:
        """Detect columns using vertical line dividers in the page drawings.

        Boring logs use heavy vertical rules to separate columns.
        This method finds those lines and identifies column types
        by checking what data patterns appear in each gap.
        """
        if not page.lines:
            return None

        # Find vertical lines that span > 30% of page height
        from collections import Counter

        vert_xs: list[float] = []
        for line_data in page.lines:
            x0, y0 = line_data.get("x0", 0), line_data.get("y0", 0)
            x1, y1 = line_data.get("x1", 0), line_data.get("y1", 0)
            # Vertical line: nearly same x, significant y span
            if abs(x0 - x1) < 2 and abs(y0 - y1) > height * 0.3:
                vert_xs.append(round(x0 / width, 3))

        if len(vert_xs) < 3:
            return None

        # Deduplicate close x-values
        unique_xs = sorted(set(vert_xs))
        dividers: list[float] = []
        for x in unique_xs:
            if not dividers or x - dividers[-1] > 0.01:
                dividers.append(x)

        if len(dividers) < 3:
            return None

        # Create column gaps between dividers
        gaps: list[tuple[float, float]] = []
        for i in range(len(dividers) - 1):
            gaps.append((dividers[i], dividers[i + 1]))

        # Identify what type of data is in each gap
        data_words = [
            w for w in page.words
            if height * 0.20 < w.get("top", 0) < height * 0.85
        ]

        columns: dict[str, tuple[float, float]] = {}
        for gap_left, gap_right in gaps:
            gap_words = [
                w for w in data_words
                if gap_left - 0.01 <= w.get("x0", 0) / width <= gap_right + 0.01
            ]

            if not gap_words:
                continue

            # Count data types in this gap
            bc_count = 0
            depth_count = 0
            desc_count = 0
            sample_type_count = 0

            for w in gap_words:
                text = w.get("text", "").strip()
                if not text:
                    continue
                if _BLOW_COUNT_RE.match(text) or _N_VALUE_RE.match(text):
                    bc_count += 1
                elif text.upper() in _SAMPLE_TYPE_CODES:
                    sample_type_count += 1
                elif _DEPTH_RE.match(text):
                    depth_count += 1
                elif any(
                    text.upper().startswith(kw) for kw in _SOIL_START_KEYWORDS
                ):
                    desc_count += 1

            gap_width = gap_right - gap_left

            # Assign column type based on what dominates the gap
            if bc_count >= 1 and "blow_counts" not in columns:
                columns["blow_counts"] = (gap_left, gap_right)
            elif sample_type_count >= 2 and "sample_type" not in columns:
                columns["sample_type"] = (gap_left, gap_right)
            elif depth_count >= 3 and gap_width < 0.15 and "depth" not in columns:
                columns["depth"] = (gap_left, gap_right)
            elif desc_count >= 2 and gap_width > 0.10 and "description" not in columns:
                columns["description"] = (gap_left, gap_right)

        if "description" not in columns and "depth" not in columns:
            return None

        # If description column is wide and contains depth values at its
        # left edge, split it into depth + description sub-columns.
        # This handles formats where the depth scale is embedded in the
        # graphic log column (common in Terracon, GeoEngineers, etc.).
        if "description" in columns:
            desc_left, desc_right = columns["description"]
            left_depths = [
                w for w in data_words
                if (desc_left - 0.01
                    <= w.get("x0", 0) / width
                    <= desc_left + 0.04)
                and _DEPTH_RE.match(w.get("text", "").strip())
            ]
            if left_depths and desc_right - desc_left > 0.15:
                split_x = desc_left + 0.04
                # Only assign layer depth if sample depth isn't already
                # found. If depth already exists (e.g. from a sample depth
                # column near blow counts), keep it and store layer depth
                # separately for soil layer boundaries.
                if "depth" not in columns:
                    columns["depth"] = (desc_left, split_x)
                else:
                    columns["layer_depth"] = (desc_left, split_x)
                columns["description"] = (split_x, desc_right)

        if "depth" not in columns:
            columns["depth"] = (0.0, 0.12)
        if "description" not in columns:
            columns["description"] = (0.10, 0.40)

        # Detect lab test columns from header labels
        self._detect_lab_columns(page, width, height, columns)

        return columns

    def _detect_lab_columns(
        self, page: PageContent, width: float, height: float,
        columns: dict[str, tuple[float, float]],
    ) -> None:
        """Detect lab test columns (water content, unit weight, Atterberg, fines).

        Uses a two-step approach:
        1. Find column header labels in the top 25% of the page
        2. Find actual data values in the right portion of the page
        3. Match data clusters to the closest header label
        """
        header_words = [
            w for w in page.words
            if w.get("top", 0) < height * 0.25
        ]
        data_words = [
            w for w in page.words
            if height * 0.20 < w.get("top", 0) < height * 0.85
        ]

        # Step 1: Find header label positions
        label_positions: dict[str, float] = {}
        label_searches = [
            (["content", "w(%)"], "water_content"),
            (["(pcf)", "weight"], "dry_unit_weight"),
            (["atterberg", "ll-pl-pi"], "atterberg"),
            (["fines", "#200", "no.200"], "fines"),
        ]

        for keywords, col_name in label_searches:
            for w in header_words:
                text = w.get("text", "").strip().lower().rstrip(":")
                x_norm = w.get("x0", 0) / width
                if x_norm < 0.60:
                    continue
                if any(kw in text for kw in keywords):
                    label_positions[col_name] = x_norm
                    break

        if not label_positions:
            return

        # Step 2: Find numeric data clusters in the right portion
        # Group standalone numbers and Atterberg-format strings by x-bucket
        right_data: dict[int, list[tuple[float, str]]] = defaultdict(list)
        for w in data_words:
            x_norm = w.get("x0", 0) / width
            if x_norm < 0.70:
                continue
            text = w.get("text", "").strip()
            if re.match(r"^\d+\.?\d*$", text) or re.match(r"^\d+-\d+-\d+$", text):
                bucket = int(x_norm * 100)  # 0.01 resolution
                right_data[bucket].append((w.get("top", 0), text))

        if not right_data:
            return

        # Step 3: Assign each data cluster to the nearest header label
        for bucket, points in sorted(right_data.items()):
            if len(points) < 1:
                continue
            data_x = bucket / 100.0

            # Find the closest header label
            best_label = None
            best_dist = 999.0
            for col_name, label_x in label_positions.items():
                dist = abs(data_x - label_x)
                if dist < best_dist and dist < 0.06:
                    best_dist = dist
                    best_label = col_name

            if best_label and best_label not in columns:
                # Use wider range for Atterberg (text like "31-20-11" is wide)
                margin = 0.05 if best_label == "atterberg" else 0.02
                columns[best_label] = (data_x - 0.02, data_x + margin)

    def _default_columns(self) -> dict[str, tuple[float, float]]:
        return {
            "depth": (0.0, 0.12),
            "description": (0.10, 0.40),
            "blow_counts": (0.55, 0.70),
        }

    @staticmethod
    def _find_integer_columns(
        data_words: list[dict],
        width: float,
        known_depth_xs: list[float],
    ) -> dict[int, list[tuple[float, int]]]:
        """Group small integers by x-position bucket, excluding depth columns.

        Returns dict mapping x-bucket -> [(y_pos, value), ...] for each column
        of small integers (1-100) that is not in the depth column position.
        """
        x_groups: dict[int, list[tuple[float, int]]] = defaultdict(list)
        depth_median = (
            sorted(known_depth_xs)[len(known_depth_xs) // 2]
            if known_depth_xs
            else -1.0
        )

        for w in data_words:
            text = w.get("text", "").strip()
            x_norm = w.get("x0", 0) / width
            if not re.match(r"^\d{1,3}$", text):
                continue
            val = int(text)
            if val > 100 or val == 0:
                continue
            if abs(x_norm - depth_median) < 0.05:
                continue
            bucket = int(x_norm * 50)  # 0.02 resolution
            x_groups[bucket].append((w.get("top", 0), val))

        return x_groups

    @staticmethod
    def _is_monotonic_or_sequential(
        points: list[tuple[float, int]], strict: bool = False,
    ) -> bool:
        """Check if a column of (y, value) points is depth-like or sample-number-like.

        Args:
            strict: If True, require >= 5 monotonic points (reduces false positives
                    for small columns that happen to be increasing but are blow counts).
        """
        if len(points) < 3:
            return False
        points_sorted = sorted(points)
        values = [v for _, v in points_sorted]

        # Monotonically increasing with significant range → depth column
        if all(values[i] <= values[i + 1] for i in range(len(values) - 1)):
            if values[-1] - values[0] >= 4:
                # In strict mode, require more points to be sure
                if strict and len(points) < 5:
                    return False
                return True

        # Strictly sequential (1,2,3... or 11,12,13...) → sample numbers
        diffs = [values[i + 1] - values[i] for i in range(len(values) - 1)]
        if all(d == 1 for d in diffs):
            return True

        return False

    @staticmethod
    def _find_standalone_nvalue_column(
        data_words: list[dict],
        width: float,
        known_depth_xs: list[float],
    ) -> list[float]:
        """Find columns of standalone N-values (single integers, not dash-separated).

        Some firms (e.g. GeoEngineers) show only the N-value as a single number
        rather than three dash-separated blow counts. These columns are identified
        by exclusion:
        - Collect columns of small integers (1-100)
        - Exclude depth columns (monotonically increasing)
        - Exclude sample number columns (strictly sequential like 1,2,3...)
        - Remaining columns with sufficient values are likely N-values
        """
        x_groups = GenericParser._find_integer_columns(
            data_words, width, known_depth_xs
        )

        best_xs: list[float] = []
        for bucket, points in x_groups.items():
            if len(points) < 3:
                continue
            if GenericParser._is_monotonic_or_sequential(points):
                continue

            x_norm_pos = bucket / 50
            best_xs.extend([x_norm_pos] * len(points))

        return best_xs

    @staticmethod
    def _find_stacked_blow_count_columns(
        data_words: list[dict],
        width: float,
        known_depth_xs: list[float],
    ) -> Optional[list[tuple[float, float, float]]]:
        """Detect stacked blow count columns (three adjacent narrow columns).

        Many firms (TxDOT, others) show SPT blow counts as three separate
        columns for the three 6-inch intervals, at slightly offset x-positions
        (e.g., x=0.80, x=0.84, x=0.88). This method identifies such triplets.

        Returns:
            List of (x_bucket_1, x_bucket_2, x_bucket_3) normalized x-positions,
            or None if no stacked pattern is found.
            Each tuple represents the x-buckets of the three blow count columns.
        """
        x_groups = GenericParser._find_integer_columns(
            data_words, width, known_depth_xs
        )

        # Filter to columns with >= 3 values that aren't clearly depth/sample-no.
        # Use strict=True so small monotonic sequences (3-4 points that happen
        # to increase) aren't excluded — they could be blow counts.
        candidate_buckets: list[int] = []
        for bucket, points in sorted(x_groups.items()):
            if len(points) < 3:
                continue
            if GenericParser._is_monotonic_or_sequential(points, strict=True):
                continue
            candidate_buckets.append(bucket)

        if len(candidate_buckets) < 2:
            return None

        # Look for groups of 2-3 adjacent buckets (within 0.10 normalized)
        # that have similar row counts (same number of SPT tests)
        triplets: list[tuple[int, ...]] = []
        i = 0
        while i < len(candidate_buckets):
            group = [candidate_buckets[i]]
            j = i + 1
            while j < len(candidate_buckets) and j < i + 3:
                if candidate_buckets[j] - candidate_buckets[i] <= 5:  # within 0.10
                    group.append(candidate_buckets[j])
                    j += 1
                else:
                    break

            if len(group) >= 2:
                group_points = [sorted(x_groups[b]) for b in group]
                counts = [len(p) for p in group_points]

                # Counts should be within 50% of each other
                if max(counts) > 2 * min(counts):
                    i += 1
                    continue

                # Reject if ANY column in the group looks evenly spaced
                # (depth-like: values at regular intervals like 5,10,15,20)
                has_depth_like = False
                for b in group:
                    pts = sorted(x_groups[b])
                    vals = [v for _, v in pts]
                    if len(vals) >= 3:
                        diffs = [vals[k + 1] - vals[k] for k in range(len(vals) - 1)]
                        if len(set(diffs)) == 1 and diffs[0] > 0:
                            has_depth_like = True
                            break
                if has_depth_like:
                    i += 1
                    continue

                # Verify columns share y-positions (blow counts at same depth)
                # At least half the y-positions in one column should have a
                # match (within 15px) in another column.
                ref_ys = [y for y, _ in group_points[0]]
                other_ys = [y for y, _ in group_points[-1]]
                matches = sum(
                    1 for ry in ref_ys
                    if any(abs(ry - oy) < 15 for oy in other_ys)
                )
                if matches < len(ref_ys) * 0.4:
                    i += 1
                    continue

                triplets.append(tuple(group))
                i = j
                continue
            i += 1

        if not triplets:
            return None

        # Return as normalized x-positions
        result = []
        for group in triplets:
            xs = tuple(b / 50.0 for b in group)
            result.append(xs)

        return result

    @staticmethod
    def _detect_depth_scale(
        page: PageContent,
    ) -> Optional[tuple[float, float]]:
        """Detect the graphical depth scale from page layout.

        Boring logs use a vertical graphical scale where depth is linearly
        mapped to Y-position. This method finds columns of monotonically
        increasing numbers and fits a linear model: depth = scale * y + offset.

        Returns:
            (scale, offset) tuple for the linear mapping, or None if no
            valid depth scale is found. Use as: depth = scale * y + offset
        """
        if not page.words:
            return None

        width = page.width or 612.0
        height = page.height or 792.0

        # Collect all numeric values in the data zone, grouped by x-position
        x_groups: dict[int, list[tuple[float, float]]] = defaultdict(list)
        for w in page.words:
            y = w.get("top", 0)
            if not (height * 0.10 < y < height * 0.95):
                continue
            text = w.get("text", "").strip()
            if not _DEPTH_RE.match(text):
                continue
            try:
                val = float(text)
            except ValueError:
                continue
            if val > 200:  # too large for depth
                continue
            x_norm = w.get("x0", 0) / width
            # Round to 2 decimals to group nearby x-positions
            x_bucket = int(x_norm * 50)  # 0.02 resolution
            x_groups[x_bucket].append((y, val))

        if not x_groups:
            return None

        best_scale: Optional[tuple[float, float]] = None
        best_points = 0

        for x_bucket, points in x_groups.items():
            if len(points) < 3:
                continue

            # Sort by y-position (top to bottom on page)
            points.sort(key=lambda p: p[0])

            # Check monotonically increasing values
            values = [v for _, v in points]
            if not all(values[i] <= values[i + 1] for i in range(len(values) - 1)):
                continue

            # Check that values span a reasonable range (at least 5 ft)
            if values[-1] - values[0] < 4:
                continue

            # Fit linear model: depth = scale * y + offset
            # Using simple two-point fit from first and last
            y0, v0 = points[0]
            y_last, v_last = points[-1]
            if abs(y_last - y0) < 10:
                continue

            scale = (v_last - v0) / (y_last - y0)
            offset = v0 - scale * y0

            # Scale must be positive (depth increases going down page)
            if scale <= 0:
                continue

            # Verify fit quality: all points should be close to the line
            max_err = 0.0
            for y, v in points:
                predicted = scale * y + offset
                max_err = max(max_err, abs(predicted - v))

            if max_err > 2.0:  # allow up to 2 ft error
                continue

            # Prefer the scale with the most points
            if len(points) > best_points:
                best_points = len(points)
                best_scale = (scale, offset)

        return best_scale

    def _parse_data_rows(
        self, page: PageContent, columns: dict[str, tuple[float, float]],
        carry_depth: Optional[float] = None,
        depth_scale: Optional[tuple[float, float]] = None,
    ) -> tuple[list[Sample], list[SoilLayer], Optional[float]]:
        """Parse data rows from a single page.

        Uses the graphical depth scale (if available) to determine depth
        from Y-position. Falls back to column-based depth matching.

        Returns:
            (samples, layers, last_depth) where last_depth can be passed
            to the next page for depth continuity.
        """
        samples: list[Sample] = []
        layers: list[SoilLayer] = []

        if not page.words:
            return samples, layers, carry_depth

        width = page.width or 612.0
        height = page.height or 792.0

        data_words = [
            w for w in page.words
            if height * 0.15 < w.get("top", 0) < height * 0.90
        ]

        rows = self._group_words_by_row(data_words)

        current_depth: Optional[float] = carry_depth
        current_desc_lines: list[str] = []
        current_layer_depth: Optional[float] = None

        for y_pos, row_words in sorted(rows.items()):
            row_data: dict[str, list[str]] = {col: [] for col in columns}

            for word in row_words:
                x_center = (
                    (word.get("x0", 0) + word.get("x1", 0)) / 2
                ) / width
                text = word.get("text", "").strip()
                if not text:
                    continue

                for col_name, (x_min, x_max) in columns.items():
                    if x_min <= x_center <= x_max:
                        row_data[col_name].append(text)
                        break

            # Determine depth from graphical scale or column data
            scale_depth: Optional[float] = None
            if depth_scale is not None:
                scale_m, scale_b = depth_scale
                computed = round(scale_m * y_pos + scale_b, 1)
                if computed >= 0:
                    scale_depth = computed

            # Column-based depth as fallback
            depth_text = " ".join(row_data.get("depth", []))
            col_depth = self._parse_depth_value(depth_text)

            # Layer depth from separate column (if exists)
            layer_depth_text = " ".join(row_data.get("layer_depth", []))
            layer_depth = self._parse_depth_value(layer_depth_text)

            # Parse description
            desc_text = " ".join(row_data.get("description", []))

            # Parse blow count — two modes:
            # 1. Stacked: separate integers in adjacent sub-columns
            # 2. Standard: single text like "5-8-12" or "N=15" or "25"
            spt: Optional[SPTBlowCounts] = None

            if self._stacked_blow_columns:
                # Stacked mode: read individual integers from sub-columns
                stacked_vals: list[Optional[int]] = []
                for sc_left, sc_right in self._stacked_blow_columns:
                    val = None
                    for word in row_words:
                        wx = (
                            (word.get("x0", 0) + word.get("x1", 0)) / 2
                        ) / width
                        if sc_left <= wx <= sc_right:
                            txt = word.get("text", "").strip()
                            if _STANDALONE_NVAL_RE.match(txt):
                                val = int(txt)
                                break
                    stacked_vals.append(val)

                non_none = [v for v in stacked_vals if v is not None]
                if len(non_none) >= 2:
                    if len(stacked_vals) >= 3:
                        spt = SPTBlowCounts(
                            first_6in=stacked_vals[0],
                            second_6in=stacked_vals[1],
                            third_6in=stacked_vals[2] if len(stacked_vals) > 2 else None,
                        )
                    elif len(stacked_vals) == 2:
                        spt = SPTBlowCounts(
                            first_6in=stacked_vals[0],
                            second_6in=stacked_vals[1],
                        )
                    if spt:
                        n = spt.compute_n_value()
                        if n is not None:
                            spt.n_value = n
            else:
                blow_text = " ".join(row_data.get("blow_counts", []))

                # Accept: dash-separated ("5-8-12"), N= format ("N=15"),
                # or standalone integer in a recognized blow_counts column.
                is_blow_count = blow_text and (
                    _BLOW_COUNT_RE.match(blow_text)
                    or _N_VALUE_RE.match(blow_text)
                    or _STANDALONE_NVAL_RE.match(blow_text)
                )
                if is_blow_count:
                    spt = self.parse_blow_counts(blow_text)

            # Validate: N-values > 200 are almost certainly misread data
            if spt and spt.n_value is not None and spt.n_value > 200:
                spt = None

            # Parse sample info
            sample_no = " ".join(row_data.get("sample_no", []))
            sample_type_text = " ".join(row_data.get("sample_type", []))
            recovery_text = " ".join(row_data.get("recovery", []))

            if spt:
                sample_type = self._parse_sample_type(sample_type_text)

                recovery = None
                if recovery_text and re.match(r"^\d+$", recovery_text):
                    recovery = float(recovery_text)

                # Depth priority: (1) graphical scale, (2) column depth,
                # (3) running depth, (4) 0.0
                if scale_depth is not None:
                    sample_top = scale_depth
                elif col_depth is not None:
                    sample_top = col_depth
                elif current_depth is not None:
                    sample_top = current_depth
                else:
                    sample_top = 0.0

                sample_bottom = sample_top + 1.5

                # Lab test data from additional columns
                water_content = self._parse_float_field(
                    row_data.get("water_content", [])
                )
                dry_unit_weight = self._parse_float_field(
                    row_data.get("dry_unit_weight", [])
                )
                fines = self._parse_float_field(
                    row_data.get("fines", [])
                )

                # Atterberg limits: "31-20-11" → LL=31, PL=20, PI=11
                ll, pl, pi = None, None, None
                atterberg_text = " ".join(row_data.get("atterberg", []))
                att_m = re.match(r"(\d+)-(\d+)-(\d+)", atterberg_text)
                if att_m:
                    ll = int(att_m.group(1))
                    pl = int(att_m.group(2))
                    pi = int(att_m.group(3))

                samples.append(Sample(
                    sample_number=sample_no or None,
                    sample_type=sample_type,
                    depth_top_ft=sample_top,
                    depth_bottom_ft=sample_bottom,
                    recovery_in=recovery,
                    spt=spt,
                    water_content_pct=water_content,
                    dry_unit_weight_pcf=dry_unit_weight,
                    liquid_limit=ll,
                    plastic_limit=pl,
                    plasticity_index=pi,
                    fines_pct=fines,
                ))

            # Layer depth: prefer column-based layer_depth, then scale
            effective_layer_depth = (
                layer_depth if layer_depth is not None
                else scale_depth if scale_depth is not None
                else col_depth
            )

            # Track soil descriptions
            if desc_text and len(desc_text) > 2 and not self._is_header_text(desc_text):
                if self._is_new_layer(desc_text):
                    if current_desc_lines and current_layer_depth is not None:
                        layer = self._build_soil_layer(
                            current_layer_depth, effective_layer_depth,
                            current_desc_lines,
                        )
                        if layer:
                            layers.append(layer)
                    current_desc_lines = [desc_text]
                    current_layer_depth = (
                        effective_layer_depth if effective_layer_depth is not None
                        else current_depth
                    )
                else:
                    current_desc_lines.append(desc_text)

            if scale_depth is not None:
                current_depth = scale_depth
            elif col_depth is not None:
                current_depth = col_depth

        # Save last layer
        if current_desc_lines and current_layer_depth is not None:
            layer = self._build_soil_layer(
                current_layer_depth, None, current_desc_lines
            )
            if layer:
                layers.append(layer)

        # Post-process: match lab test data to nearest samples by y-position.
        # Lab data (water content, Atterberg, etc.) often appears on a different
        # row than the blow counts, but at a nearby y-position for the same sample.
        if samples:
            self._match_lab_data_to_samples(
                samples, data_words, columns, width, depth_scale,
            )

        return samples, layers, current_depth

    def _match_lab_data_to_samples(
        self,
        samples: list[Sample],
        data_words: list[dict],
        columns: dict[str, tuple[float, float]],
        width: float,
        depth_scale: Optional[tuple[float, float]],
    ) -> None:
        """Match lab test values to the nearest sample by y-position.

        Lab data columns (water content, dry weight, Atterberg, fines) may
        appear on different rows than the blow counts. This method scans
        each lab column for numeric values and assigns them to the sample
        whose row is closest in y-position.
        """
        lab_columns = {
            "water_content": ("water_content_pct", r"^\d+\.?\d*$"),
            "dry_unit_weight": ("dry_unit_weight_pcf", r"^\d+\.?\d*$"),
            "atterberg": (None, r"^\d+-\d+-\d+$"),  # special handling
            "fines": ("fines_pct", r"^\d+\.?\d*$"),
        }

        for col_name, (attr_name, pattern) in lab_columns.items():
            if col_name not in columns:
                continue

            col_left, col_right = columns[col_name]

            # Collect all values from this column with their y-positions
            col_values: list[tuple[float, str]] = []
            for w in data_words:
                x_center = ((w.get("x0", 0) + w.get("x1", 0)) / 2) / width
                if col_left <= x_center <= col_right:
                    text = w.get("text", "").strip()
                    if re.match(pattern, text):
                        col_values.append((w.get("top", 0), text))

            if not col_values:
                continue

            # Build y-position to sample index mapping
            # We need the y-positions where samples were found. Since we
            # don't store y_pos on samples, use the depth_scale to compute
            # expected y from sample depth, or use a simple nearest-match.
            for y_pos, value_text in col_values:
                # Find which sample is nearest to this y-position.
                # Use depth_scale to convert y_pos to depth, then find
                # the sample at that depth.
                if depth_scale is not None:
                    scale_m, scale_b = depth_scale
                    val_depth = scale_m * y_pos + scale_b
                    best_sample = None
                    best_dist = 999.0
                    for s in samples:
                        dist = abs(s.depth_top_ft - val_depth)
                        if dist < best_dist:
                            best_dist = dist
                            best_sample = s
                    if best_sample is None or best_dist > 5.0:
                        continue
                else:
                    # Without depth scale, can't reliably match
                    continue

                # Assign value to sample
                if col_name == "atterberg":
                    att_m = re.match(r"(\d+)-(\d+)-(\d+)", value_text)
                    if att_m and best_sample:
                        best_sample.liquid_limit = int(att_m.group(1))
                        best_sample.plastic_limit = int(att_m.group(2))
                        best_sample.plasticity_index = int(att_m.group(3))
                elif attr_name and best_sample:
                    try:
                        setattr(best_sample, attr_name, float(value_text))
                    except ValueError:
                        pass

    def _parse_water_levels(self, page: PageContent) -> list[WaterLevelObservation]:
        water_levels: list[WaterLevelObservation] = []
        text = page.text

        patterns = [
            r"(?i)(?:ground)?water\s*(?:level|encountered|observed)\s*(?:at)?\s*(\d+\.?\d*)\s*(?:ft|feet|')?",
            r"(?i)water\s*(?:table|surface)\s*(?:at)?\s*(\d+\.?\d*)\s*(?:ft|feet|')?",
            r"(?i)GW[LE]?\s*(?:=|@|at)\s*(\d+\.?\d*)",
            r"(?i)water\s+level\s*:?\s*(\d+\.?\d*)\s*(?:ft|feet|')?",
            r"(?i)(?:no\s+)?water\s+(?:seepage|encountered)\s+(?:at|to)\s+(\d+\.?\d*)",
            r"(?i)encountered\s+@\s+(\d+\.?\d*)'?",
            r"(?i)(?:at|@)\s+(\d+\.?\d*)\s*(?:ft|feet|')\s*(?:bgs|below)",
        ]

        seen_depths: set[float] = set()
        for pattern in patterns:
            for match in re.finditer(pattern, text):
                depth = float(match.group(1))
                if depth in seen_depths:
                    continue
                seen_depths.add(depth)

                is_during = bool(re.search(r"(?i)during\s+drilling", text))
                is_stabilized = bool(
                    re.search(r"(?i)(?:24\s*hr|stabilized|after\s+drilling)", text)
                )

                water_levels.append(WaterLevelObservation(
                    depth_ft=depth,
                    is_during_drilling=is_during,
                    is_stabilized=is_stabilized,
                ))

        # Also check the WATER LEVEL column if it exists (from header)
        # Some formats show the water depth as a number in a "LEVEL" column
        if page.words:
            width = page.width or 612.0
            height = page.height or 792.0
            # Look for a column labeled "LEVEL" or "WATER" near the header
            for w in page.words:
                if w.get("top", 0) > height * 0.20:
                    continue
                txt = w.get("text", "").strip().upper()
                if txt in ("LEVEL", "WATER"):
                    x_norm = w.get("x0", 0) / width
                    if 0.45 <= x_norm <= 0.60:
                        # Check data zone for numbers in this column
                        for dw in page.words:
                            if not (height * 0.20 < dw.get("top", 0) < height * 0.85):
                                continue
                            dw_x = dw.get("x0", 0) / width
                            if abs(dw_x - x_norm) < 0.03:
                                dw_text = dw.get("text", "").strip()
                                if re.match(r"^\d+\.?\d*$", dw_text):
                                    d = float(dw_text)
                                    if 0 < d < 200 and d not in seen_depths:
                                        seen_depths.add(d)
                                        water_levels.append(WaterLevelObservation(
                                            depth_ft=d,
                                        ))
                        break

        return water_levels

    def _group_words_by_row(
        self, words: list[dict], tolerance: float = 4.0
    ) -> dict[float, list[dict]]:
        rows: dict[float, list[dict]] = {}
        for word in words:
            y = word.get("top", 0)
            matched = False
            for row_y in list(rows.keys()):
                if abs(y - row_y) <= tolerance:
                    rows[row_y].append(word)
                    matched = True
                    break
            if not matched:
                rows[y] = [word]
        return rows

    @staticmethod
    def _parse_depth_value(text: str) -> Optional[float]:
        """Parse a depth value, being strict about what counts as depth."""
        text = text.strip()
        if not text:
            return None
        if _DEPTH_RE.match(text):
            try:
                return float(text)
            except ValueError:
                return None
        return None

    @staticmethod
    def _parse_sample_type(text: str) -> Optional[SampleType]:
        text = text.strip().upper()
        mapping = {
            "SS": SampleType.SPLIT_SPOON,
            "ST": SampleType.SHELBY_TUBE,
            "RC": SampleType.ROCK_CORE,
            "GB": SampleType.GRAB,
            "AU": SampleType.AUGER,
            "NX": SampleType.ROCK_CORE,
            "HQ": SampleType.ROCK_CORE,
            "RB": SampleType.ROCK_CORE,
            "SA": SampleType.AUGER,
        }
        return mapping.get(text)

    @staticmethod
    def _is_header_text(text: str) -> bool:
        headers = {
            "depth", "sample", "type", "blow", "recovery", "description",
            "classification", "material", "count", "n-value", "spt",
            "number", "remarks", "graphic", "log", "elev", "no.",
            "ft", "feet", "in", "pct", "%", "field", "test", "results",
        }
        return text.strip().lower() in headers

    @staticmethod
    def _is_new_layer(text: str) -> bool:
        text_upper = text.strip().upper()
        return any(text_upper.startswith(kw) for kw in _SOIL_START_KEYWORDS)

    def _build_soil_layer(
        self,
        depth_top: float,
        depth_bottom: Optional[float],
        desc_lines: list[str],
    ) -> Optional[SoilLayer]:
        description = " ".join(desc_lines).strip()
        if not description:
            return None

        uscs = None
        # Prefer parenthesized USCS codes like "(CL)" or "(SP-SM)" —
        # these are explicit classifications, not accidental word matches
        # (e.g. "SANDY" matching SP).
        paren_match = re.search(
            r"\(("
            r"(?:GW|GP|GM|GC|SW|SP|SM|SC|ML|CL|OL|MH|CH|OH|PT)"
            r"(?:\s*[-/]\s*(?:GW|GP|GM|GC|SW|SP|SM|SC|ML|CL|OL|MH|CH|OH|PT))?)"
            r"\)",
            description,
        )
        if paren_match:
            code = paren_match.group(1).replace(" ", "")
            for cls in USCSClassification:
                if cls.value == code:
                    uscs = cls
                    break
        if uscs is None:
            for cls in USCSClassification:
                if re.search(rf"\b{cls.value}\b", description):
                    uscs = cls
                    break

        color = None
        color_match = re.search(
            r"(?i)\b(brown|gray|grey|tan|red|orange|yellow|black|white|dark|light)"
            r"(?:\s+(?:brown|gray|grey|tan|red|orange|to)\b)*",
            description,
        )
        if color_match:
            color = color_match.group(0).strip().lower()

        moisture = None
        for mc in MoistureCondition:
            if re.search(rf"(?i)\b{mc.value}\b", description):
                moisture = mc
                break

        # Consistency (cohesive soils): very soft, soft, medium stiff, etc.
        # Match multi-word values first (longest match wins)
        consistency = None
        from geotech_report_extraction.models import Consistency
        for con in [
            Consistency.VERY_SOFT,
            Consistency.MEDIUM_STIFF,
            Consistency.VERY_STIFF,
            Consistency.SOFT,
            Consistency.STIFF,
            Consistency.HARD,
        ]:
            pattern = rf"(?i)\b{re.escape(con.value)}\b"
            if re.search(pattern, description):
                consistency = con
                break

        # Relative density (granular soils): very loose, loose, etc.
        relative_density = None
        from geotech_report_extraction.models import RelativeDensity
        for rd in [
            RelativeDensity.VERY_LOOSE,
            RelativeDensity.MEDIUM_DENSE,
            RelativeDensity.VERY_DENSE,
            RelativeDensity.LOOSE,
            RelativeDensity.DENSE,
        ]:
            pattern = rf"(?i)\b{re.escape(rd.value)}\b"
            if re.search(pattern, description):
                relative_density = rd
                break

        return SoilLayer(
            depth_top_ft=depth_top,
            depth_bottom_ft=depth_bottom,
            description=description,
            uscs_classification=uscs,
            color=color,
            moisture=moisture,
            consistency=consistency,
            relative_density=relative_density,
        )

    @staticmethod
    def _parse_float_field(values: list[str]) -> Optional[float]:
        """Parse a single float from column values, or None."""
        text = " ".join(values).strip()
        if not text:
            return None
        m = re.match(r"^(\d+\.?\d*)$", text)
        if m:
            return float(m.group(1))
        return None
