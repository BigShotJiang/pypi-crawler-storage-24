"""DIGGS 2.6 XML serializer for geotechnical borehole data.

Converts the internal BoreholeLog data model to DIGGS 2.6 compliant XML.
DIGGS (Data Interchange for Geotechnical and Geoenvironmental Specialists)
is an XML-based standard for exchanging geotechnical data.

Reference: http://www.diggsml.org/
Schema:    http://diggsml.org/schemas/2.6/Diggs.xsd
"""

from __future__ import annotations

import re
from datetime import date
from typing import Optional

from lxml import etree

from geotech_report_extraction.lab_tests import (
    AtterbergResult,
    ConsolidationResult,
    GrainSizeResult,
    LabTestResult,
    LabTestType,
    MoistureDensityResult,
    StrengthTestResult,
)
from geotech_report_extraction.models import (
    Borehole,
    BoreholeLog,
    Sample,
    SoilLayer,
    WaterLevelObservation,
)

# DIGGS 2.6 namespaces
DIGGS_NS = "http://diggsml.org/schemas/2.6"
DIGGS_GEO_NS = "http://diggsml.org/schemas/2.6/geotechnical"
GML_NS = "http://www.opengis.net/gml/3.2"
XSI_NS = "http://www.w3.org/2001/XMLSchema-instance"
XLINK_NS = "http://www.w3.org/1999/xlink"
DIGGS_SCHEMA_LOCATION = (
    "http://diggsml.org/schemas/2.6 "
    "http://diggsml.org/schemas/2.6/Diggs.xsd"
)

NSMAP = {
    "diggs": DIGGS_NS,
    "diggs_geo": DIGGS_GEO_NS,
    "gml": GML_NS,
    "xsi": XSI_NS,
    "xlink": XLINK_NS,
}


def _qn(ns: str, tag: str) -> str:
    """Create a qualified name {namespace}tag."""
    return f"{{{ns}}}{tag}"


def _d(tag: str) -> str:
    """Shorthand for DIGGS namespace tag."""
    return _qn(DIGGS_NS, tag)


def _g(tag: str) -> str:
    """Shorthand for GML namespace tag."""
    return _qn(GML_NS, tag)


def _geo(tag: str) -> str:
    """Shorthand for DIGGS geotechnical namespace tag."""
    return _qn(DIGGS_GEO_NS, tag)


def _sub(parent: etree._Element, tag: str, text: str = None,
         uom: str = None) -> etree._Element:
    """Add a DIGGS-namespaced subelement with optional text and uom."""
    el = etree.SubElement(parent, _d(tag))
    if text is not None:
        el.text = str(text)
    if uom:
        el.set("uom", uom)
    return el


def _sub_geo(parent: etree._Element, tag: str, text: str = None,
             uom: str = None) -> etree._Element:
    """Add a DIGGS geotechnical-namespaced subelement."""
    el = etree.SubElement(parent, _geo(tag))
    if text is not None:
        el.text = str(text)
    if uom:
        el.set("uom", uom)
    return el


def _safe_id(text: str) -> str:
    """Convert text to a valid XML ID (NCName)."""
    result = re.sub(r"[^a-zA-Z0-9._-]", "-", text)
    if result and not result[0].isalpha() and result[0] != "_":
        result = f"id-{result}"
    result = re.sub(r"-+", "-", result)
    return result.strip("-") or "id-unknown"


# =========================================================================
# Public API
# =========================================================================

def to_diggs_xml(log: BoreholeLog, pretty_print: bool = True) -> str:
    """Convert a BoreholeLog to DIGGS 2.6 XML string."""
    root = _build_root(log)
    return etree.tostring(
        root,
        pretty_print=pretty_print,
        xml_declaration=True,
        encoding="UTF-8",
    ).decode("utf-8")


def to_diggs_etree(log: BoreholeLog) -> etree._Element:
    """Convert a BoreholeLog to an lxml Element tree."""
    return _build_root(log)


# =========================================================================
# Root document builder
# =========================================================================

def _build_root(log: BoreholeLog) -> etree._Element:
    """Build the DIGGS root element with all content.

    Root element ordering per DiggsType schema:
      1. documentInformation (required, exactly 1)
      2. project (0..*)
      3. program (0..*)
      4. samplingFeature (0..*)
      5. samplingActivity (0..*)
      6. sample (0..*)
      7. observation (0..*)
      8. measurement (0..*)
      9. constructionActivity (0..*)
     10. group (0..*)
    """
    root = etree.Element(_d("Diggs"), nsmap=NSMAP)
    root.set(_qn(XSI_NS, "schemaLocation"), DIGGS_SCHEMA_LOCATION)
    root.set(_g("id"), "diggs-document")

    # 1. documentInformation (required)
    _add_document_info(root, log)

    # 2. project
    project_id = None
    if log.project:
        project_id = _add_project(root, log)

    # 4. samplingFeature (boreholes)
    for borehole in log.boreholes:
        _add_borehole(root, borehole, project_id)

    # 5. samplingActivity (samples)
    for borehole in log.boreholes:
        for i, sample in enumerate(borehole.samples):
            _add_sampling_activity(root, borehole.boring_id, sample, i,
                                   project_id)

    # 8. measurement (SPT tests, lab properties, water levels, lab tests)
    for borehole in log.boreholes:
        for i, sample in enumerate(borehole.samples):
            if sample.spt:
                _add_spt_test(root, borehole.boring_id, sample, i,
                              project_id)
            _add_sample_lab_properties(root, borehole.boring_id, sample, i,
                                       project_id)
        for i, wl in enumerate(borehole.water_levels):
            _add_water_level(root, borehole.boring_id, wl, i, project_id)

    # Lab test results (consolidation, grain size, Atterberg, etc.)
    for i, lab_test in enumerate(log.lab_tests):
        _add_lab_test(root, lab_test, i, project_id)

    return root


# =========================================================================
# Document information
# =========================================================================

def _add_document_info(parent: etree._Element, log: BoreholeLog) -> None:
    """Add documentInformation element.

    DocumentInformationType extends AbstractFeatureBaseType:
      inherited: gml:description, gml:identifier
      own: creationDate (required), effectiveDate, expirationDate,
           author, disclaimer, sourceSoftware, ...
    """
    doc_info_el = _sub(parent, "documentInformation")
    di = _sub(doc_info_el, "DocumentInformation")
    di.set(_g("id"), "doc-info")

    # gml:description — use source file as description
    if log.source_file:
        desc = etree.SubElement(di, _g("description"))
        desc.text = f"Extracted from {log.source_file}"

    # creationDate (required)
    _sub(di, "creationDate", date.today().isoformat())


# =========================================================================
# Project
# =========================================================================

def _add_project(parent: etree._Element, log: BoreholeLog) -> str:
    """Add project element. Returns the project gml:id for cross-references.

    ProjectType extends AbstractNamedFeatureType:
      inherited: gml:description, gml:identifier, gml:name (required, 1+),
                 internalIdentifier, status, implementationStatus,
                 associatedFile, role, remark
      from AbstractProjectType: referencePoint, linearExtent, arealExtent,
                 projectDateTimeSpan, locality, purpose, projectEvent
    """
    project_el = _sub(parent, "project")
    proj = _sub(project_el, "Project")

    gml_id = _safe_id(log.project.number or "project-1")
    proj.set(_g("id"), gml_id)

    # gml:identifier (before gml:name)
    if log.project.number:
        identifier = etree.SubElement(proj, _g("identifier"))
        identifier.set("codeSpace", "urn:diggs:projectNumber")
        identifier.text = log.project.number

    # gml:name (required, at least one)
    name_el = etree.SubElement(proj, _g("name"))
    name_el.text = log.project.name or log.project.number or "Unknown Project"

    # role elements (Client, Consultant)
    if log.project.client:
        _add_role(proj, "Client", log.project.client)
    if log.project.firm:
        _add_role(proj, "Consultant", log.project.firm)

    # remark — project location as a remark since Locality requires structured address
    if log.project.location:
        remark_el = _sub(proj, "remark")
        remark = _sub(remark_el, "Remark")
        _sub(remark, "content", f"Location: {log.project.location}")

    return gml_id


def _add_role(
    parent: etree._Element, role_type: str, name: str,
) -> None:
    """Add a role (Client, Consultant, etc.) to a project."""
    role = _sub(parent, "role")
    role_detail = _sub(role, "Role")
    _sub(role_detail, "rolePerformed", role_type)
    business = _sub(role_detail, "businessAssociate")
    ba = _sub(business, "BusinessAssociate")
    ba.set(_g("id"), _safe_id(f"{role_type.lower()}-{name}"))
    ba_name = etree.SubElement(ba, _g("name"))
    ba_name.text = name


# =========================================================================
# Borehole (sampling feature)
# =========================================================================

def _add_borehole(
    parent: etree._Element,
    borehole: Borehole,
    project_id: Optional[str],
) -> None:
    """Add a borehole (sampling feature) to the DIGGS document.

    BoreholeType extends AbstractLinearSamplingFeatureType extends
    AbstractSamplingFeatureType extends AbstractNamedFeatureType:

    Ordering:
      inherited: gml:description, gml:identifier, gml:name (required),
                 internalIdentifier, status, implementationStatus,
                 associatedFile, role, remark
      AbstractSamplingFeatureType: investigationTarget (required),
                 projectRef (required), originalProjectRef,
                 associatedProjectRef, programRef, environment,
                 otherSamplingFeatureProperty, locality,
                 referencePoint (required), localCoordinates
      AbstractLinearSamplingFeatureType: centerLine (required),
                 linearReferencing, plunge, bearing
      BoreholeType: whenConstructed, whenDestroyed, totalMeasuredDepth,
                 holeBearing, holePlunge, boreholePurpose, boreholeType, ...
    """
    sf_el = _sub(parent, "samplingFeature")
    hole = _sub(sf_el, "Borehole")
    boring_id_safe = _safe_id(borehole.boring_id)
    hole.set(_g("id"), boring_id_safe)

    # --- AbstractNamedFeatureType ---

    # gml:name (required)
    name_el = etree.SubElement(hole, _g("name"))
    name_el.text = borehole.boring_id

    # --- AbstractSamplingFeatureType ---

    # investigationTarget (required)
    _sub(hole, "investigationTarget", "Natural Ground")

    # projectRef (required)
    proj_ref = _sub(hole, "projectRef")
    if project_id:
        proj_ref.set(_qn(XLINK_NS, "href"), f"#{project_id}")

    # referencePoint (required) — even if we don't have coordinates
    ref_point = _sub(hole, "referencePoint")
    point_loc = _sub(ref_point, "PointLocation")
    point_loc.set(_g("id"), _safe_id(f"{borehole.boring_id}-point"))
    if borehole.latitude is not None and borehole.longitude is not None:
        point_loc.set("srsName", "urn:ogc:def:crs:EPSG::4326")
        point_loc.set("srsDimension", "2")
        pos = etree.SubElement(point_loc, _g("pos"))
        pos.text = f"{borehole.latitude} {borehole.longitude}"
    else:
        # Unknown location — use a placeholder SRS
        point_loc.set("srsName", "urn:ogc:def:crs:EPSG::4326")
        point_loc.set("srsDimension", "2")
        pos = etree.SubElement(point_loc, _g("pos"))
        pos.text = "0 0"

    # localCoordinates — elevation goes here (no gml:id on LocalCoordinate)
    if borehole.elevation_ft is not None:
        local_coords = _sub(hole, "localCoordinates")
        lc = _sub(local_coords, "LocalCoordinate")
        _sub(lc, "elevation", str(borehole.elevation_ft), uom="ft")

    # --- AbstractLinearSamplingFeatureType ---

    # centerLine (required) — vertical borehole from 0 to total depth
    center = _sub(hole, "centerLine")
    lin_ext = _sub(center, "LinearExtent")
    lin_ext.set(_g("id"), _safe_id(f"{borehole.boring_id}-centerline"))
    lin_ext.set("srsName", f"#{boring_id_safe}")
    lin_ext.set("srsDimension", "1")
    pos_list = etree.SubElement(lin_ext, _g("posList"))
    pos_list.text = f"0 {borehole.depth_ft}"

    # --- BoreholeType ---

    # whenConstructed — TimeIntervalType order: (gml:name, status, remark), start (required), end
    if borehole.date_started or borehole.date_completed:
        when = _sub(hole, "whenConstructed")
        ti = _sub(when, "TimeInterval")
        ti.set(_g("id"), _safe_id(f"{borehole.boring_id}-construction"))
        # start is required — use date_started if available, else date_completed
        start_date = borehole.date_started or borehole.date_completed
        _sub(ti, "start", start_date.isoformat())
        if borehole.date_completed and borehole.date_completed != start_date:
            _sub(ti, "end", borehole.date_completed.isoformat())

    # totalMeasuredDepth
    if borehole.depth_ft is not None:
        _sub(hole, "totalMeasuredDepth", str(borehole.depth_ft), uom="ft")


# =========================================================================
# Sampling activity (samples)
# =========================================================================

def _add_sampling_activity(
    parent: etree._Element,
    boring_id: str,
    sample: Sample,
    index: int,
    project_id: Optional[str],
) -> None:
    """Add a sampling activity for a sample.

    SamplingActivityType extends AbstractSamplingActivityType:
      inherited from AbstractFeatureType: gml:name, ...
      investigationTarget (required), projectRef (required),
      programRef, constructionActivityRef,
      choice: (samplingFeatureRef + samplingLocation) | (associatedProjectRef + originalProjectRef)
      sourceSampleRef, activityType (required), ...
    """
    sa_el = _sub(parent, "samplingActivity")
    activity = _sub(sa_el, "SamplingActivity")
    sample_id = _safe_id(f"{boring_id}-sample-{index}")
    activity.set(_g("id"), sample_id)

    # gml:name
    if sample.sample_number:
        act_name = etree.SubElement(activity, _g("name"))
        act_name.text = f"Sample {sample.sample_number}"

    # investigationTarget (required)
    _sub(activity, "investigationTarget", "Natural Ground")

    # projectRef (required)
    proj_ref = _sub(activity, "projectRef")
    if project_id:
        proj_ref.set(_qn(XLINK_NS, "href"), f"#{project_id}")

    # samplingFeatureRef (choice branch 1)
    sf_ref = _sub(activity, "samplingFeatureRef")
    sf_ref.set(_qn(XLINK_NS, "href"), f"#{_safe_id(boring_id)}")

    # samplingLocation (required with samplingFeatureRef)
    samp_loc = _sub(activity, "samplingLocation")
    samp_point = _sub(samp_loc, "PointLocation")
    samp_point.set(_g("id"), _safe_id(f"{sample_id}-loc"))
    samp_point.set("srsName", f"#{_safe_id(boring_id)}")
    samp_point.set("srsDimension", "1")
    samp_pos = etree.SubElement(samp_point, _g("pos"))
    samp_pos.text = str(sample.depth_top_ft)

    # activityType (required)
    _sub(activity, "activityType", "collect")


# =========================================================================
# SPT test (measurement/Test)
# =========================================================================

def _add_spt_test(
    parent: etree._Element,
    boring_id: str,
    sample: Sample,
    index: int,
    project_id: Optional[str],
) -> None:
    """Add an SPT in-situ test as a measurement/Test.

    TestType extends AbstractMeasurementType:
      inherited: investigationTarget (required), projectRef (required),
                 programRef, samplingFeatureRef, sampleRef,
                 constructionActivityRef, otherMeasurementProperty
      TestType own: samplingTime, resultTime, validTime,
                    outcome (required), procedure
    """
    spt = sample.spt
    if spt is None:
        return

    test_id = _safe_id(f"{boring_id}-spt-{index}")

    test_el = _sub(parent, "measurement")
    test = _sub(test_el, "Test")
    test.set(_g("id"), test_id)

    # gml:name
    proc_name = etree.SubElement(test, _g("name"))
    proc_name.text = "Standard Penetration Test"

    # investigationTarget (required)
    _sub(test, "investigationTarget", "Natural Ground")

    # projectRef (required)
    proj_ref = _sub(test, "projectRef")
    if project_id:
        proj_ref.set(_qn(XLINK_NS, "href"), f"#{project_id}")

    # samplingFeatureRef
    sf_ref = _sub(test, "samplingFeatureRef")
    sf_ref.set(_qn(XLINK_NS, "href"), f"#{_safe_id(boring_id)}")

    # outcome (required) — TestResult with SPT data as properties
    outcome = _sub(test, "outcome")
    result = _sub(outcome, "TestResult")
    result.set(_g("id"), _safe_id(f"{test_id}-result"))

    # Location (depth)
    loc = _sub(result, "location")
    point = _sub(loc, "PointLocation")
    point.set(_g("id"), _safe_id(f"{test_id}-loc"))
    point.set("srsDimension", "1")
    point.set("srsName", f"#{_safe_id(boring_id)}")
    pos = etree.SubElement(point, _g("pos"))
    pos.text = str(sample.depth_top_ft)

    # Results as PropertyParameters + dataValues
    props: list[tuple[str, str, str, str]] = []
    if spt.first_6in is not None:
        props.append(("Blow Count 1st 6in", "blowCount1",
                       str(spt.first_6in), ""))
    if spt.second_6in is not None:
        props.append(("Blow Count 2nd 6in", "blowCount2",
                       str(spt.second_6in), ""))
    if spt.third_6in is not None:
        props.append(("Blow Count 3rd 6in", "blowCount3",
                       str(spt.third_6in), ""))
    if spt.n_value is not None:
        props.append(("N-Value", "nValue", str(spt.n_value), ""))
    if spt.refusal:
        props.append(("Refusal", "refusal", "true", ""))

    if props:
        results_el = _sub(result, "results")
        result_set = _sub(results_el, "ResultSet")
        params_el = _sub(result_set, "parameters")
        prop_params = _sub(params_el, "PropertyParameters")
        prop_params.set(_g("id"), _safe_id(f"{test_id}-params"))
        properties = _sub(prop_params, "properties")

        values_parts = []
        for idx, (name, prop_class, value, uom) in enumerate(props, 1):
            prop = _sub(properties, "Property")
            prop.set("index", str(idx))
            prop.set(_g("id"), _safe_id(f"{test_id}-p{idx}"))
            _sub(prop, "propertyName", name)
            _sub(prop, "typeData", "int" if prop_class != "refusal" else "boolean")
            pc = _sub(prop, "propertyClass", prop_class)
            pc.set("codeSpace",
                   "http://diggsml.org/dictionaries/DIGGSTestPropertyDefinitions.xml"
                   f"#{prop_class}")
            values_parts.append(value)

        dv = _sub(result_set, "dataValues", ",".join(values_parts))
        dv.set("cs", ",")
        dv.set("decimal", ".")
        dv.set("ts", " ")


# =========================================================================
# Sample-level lab properties (measurement/Test)
# =========================================================================

def _add_sample_lab_properties(
    parent: etree._Element,
    boring_id: str,
    sample: Sample,
    index: int,
    project_id: Optional[str],
) -> None:
    """Add sample-level lab test properties as a measurement/Test."""
    props: list[tuple[str, str, str, str]] = []

    if sample.water_content_pct is not None:
        props.append(("Water Content", "water_content",
                       str(sample.water_content_pct), "%"))
    if sample.dry_unit_weight_pcf is not None:
        props.append(("Dry Unit Weight", "dry_unit_weight",
                       str(sample.dry_unit_weight_pcf), "pcf"))
    if sample.liquid_limit is not None:
        props.append(("LL", "liquid_limit",
                       str(sample.liquid_limit), "%"))
    if sample.plastic_limit is not None:
        props.append(("PL", "plastic_limit",
                       str(sample.plastic_limit), "%"))
    if sample.plasticity_index is not None:
        props.append(("PI", "plasticity_index",
                       str(sample.plasticity_index), "%"))
    if sample.fines_pct is not None:
        props.append(("Fines Content", "percent_fines",
                       str(sample.fines_pct), "%"))
    if sample.qu_psf is not None:
        props.append(("Unconfined Compressive Strength", "qu",
                       str(sample.qu_psf), "psf"))

    if not props:
        return

    test_id = _safe_id(f"{boring_id}-labprops-{index}")

    test_el = _sub(parent, "measurement")
    test = _sub(test_el, "Test")
    test.set(_g("id"), test_id)

    test_name = etree.SubElement(test, _g("name"))
    test_name.text = "Sample Laboratory Properties"

    # investigationTarget (required)
    _sub(test, "investigationTarget", "Natural Ground")

    # projectRef (required)
    proj_ref = _sub(test, "projectRef")
    if project_id:
        proj_ref.set(_qn(XLINK_NS, "href"), f"#{project_id}")

    # samplingFeatureRef
    sf_ref = _sub(test, "samplingFeatureRef")
    sf_ref.set(_qn(XLINK_NS, "href"), f"#{_safe_id(boring_id)}")

    # outcome (required)
    outcome = _sub(test, "outcome")
    result = _sub(outcome, "TestResult")
    result.set(_g("id"), _safe_id(f"{test_id}-result"))

    # Location (depth)
    loc = _sub(result, "location")
    point = _sub(loc, "PointLocation")
    point.set(_g("id"), _safe_id(f"{test_id}-loc"))
    point.set("srsDimension", "1")
    point.set("srsName", f"#{_safe_id(boring_id)}")
    pos = etree.SubElement(point, _g("pos"))
    pos.text = str(sample.depth_top_ft)

    # Results as PropertyParameters + dataValues
    results_el = _sub(result, "results")
    result_set = _sub(results_el, "ResultSet")
    params_el = _sub(result_set, "parameters")
    prop_params = _sub(params_el, "PropertyParameters")
    prop_params.set(_g("id"), _safe_id(f"{test_id}-params"))
    properties = _sub(prop_params, "properties")

    values_parts = []
    for idx, (name, prop_class, value, uom) in enumerate(props, 1):
        prop = _sub(properties, "Property")
        prop.set("index", str(idx))
        prop.set(_g("id"), _safe_id(f"{test_id}-p{idx}"))
        _sub(prop, "propertyName", name)
        _sub(prop, "typeData", "double")
        pc = _sub(prop, "propertyClass", prop_class)
        pc.set("codeSpace",
               "http://diggsml.org/dictionaries/DIGGSTestPropertyDefinitions.xml"
               f"#{prop_class}")
        if uom:
            _sub(prop, "uom", uom)
        values_parts.append(value)

    dv = _sub(result_set, "dataValues", ",".join(values_parts))
    dv.set("cs", ",")
    dv.set("decimal", ".")
    dv.set("ts", " ")


# =========================================================================
# Water level observations (measurement/Test)
# =========================================================================

def _add_water_level(
    parent: etree._Element,
    boring_id: str,
    wl: WaterLevelObservation,
    index: int,
    project_id: Optional[str],
) -> None:
    """Add a groundwater level observation as measurement/Test."""
    test_id = _safe_id(f"{boring_id}-gwl-{index}")

    wl_el = _sub(parent, "measurement")
    test = _sub(wl_el, "Test")
    test.set(_g("id"), test_id)

    test_name = etree.SubElement(test, _g("name"))
    test_name.text = "Water Level Observation"

    # investigationTarget (required)
    _sub(test, "investigationTarget", "Natural Ground")

    # projectRef (required)
    proj_ref = _sub(test, "projectRef")
    if project_id:
        proj_ref.set(_qn(XLINK_NS, "href"), f"#{project_id}")

    # samplingFeatureRef
    sf_ref = _sub(test, "samplingFeatureRef")
    sf_ref.set(_qn(XLINK_NS, "href"), f"#{_safe_id(boring_id)}")

    # outcome (required)
    outcome = _sub(test, "outcome")
    result = _sub(outcome, "TestResult")
    result.set(_g("id"), _safe_id(f"{test_id}-result"))

    # Location (water depth)
    loc = _sub(result, "location")
    point = _sub(loc, "PointLocation")
    point.set(_g("id"), _safe_id(f"{test_id}-loc"))
    point.set("srsDimension", "1")
    point.set("srsName", f"#{_safe_id(boring_id)}")
    pos = etree.SubElement(point, _g("pos"))
    pos.text = str(wl.depth_ft)

    # Results
    props: list[tuple[str, str, str, str]] = []
    props.append(("Water Depth", "water_depth", str(wl.depth_ft), "ft"))
    if wl.is_during_drilling:
        props.append(("Observation Type", "observation_type",
                       "during_drilling", ""))
    elif wl.is_stabilized:
        props.append(("Observation Type", "observation_type",
                       "stabilized", ""))
    if wl.notes:
        props.append(("Remarks", "remarks", wl.notes, ""))

    results_el = _sub(result, "results")
    result_set = _sub(results_el, "ResultSet")
    params_el = _sub(result_set, "parameters")
    prop_params = _sub(params_el, "PropertyParameters")
    prop_params.set(_g("id"), _safe_id(f"{test_id}-params"))
    properties = _sub(prop_params, "properties")

    values_parts = []
    for idx, (name, prop_class, value, uom) in enumerate(props, 1):
        prop = _sub(properties, "Property")
        prop.set("index", str(idx))
        prop.set(_g("id"), _safe_id(f"{test_id}-p{idx}"))
        _sub(prop, "propertyName", name)
        dtype = "string" if prop_class in ("observation_type", "remarks") else "double"
        _sub(prop, "typeData", dtype)
        pc = _sub(prop, "propertyClass", prop_class)
        pc.set("codeSpace",
               "http://diggsml.org/dictionaries/DIGGSTestPropertyDefinitions.xml"
               f"#{prop_class}")
        if uom:
            _sub(prop, "uom", uom)
        values_parts.append(value)

    dv = _sub(result_set, "dataValues", ",".join(values_parts))
    dv.set("cs", ",")
    dv.set("decimal", ".")
    dv.set("ts", " ")


# =========================================================================
# Lab test dispatcher and helpers
# =========================================================================

def _make_test_shell(
    parent: etree._Element,
    test_id: str,
    test_name: str,
    boring_id: str | None,
    depth_ft: float | None,
    project_id: str | None,
) -> tuple[etree._Element, etree._Element]:
    """Create the common measurement/Test/outcome/TestResult shell.

    Returns (test_element, test_result_element).
    """
    meas = _sub(parent, "measurement")
    test = _sub(meas, "Test")
    test.set(_g("id"), test_id)

    name_el = etree.SubElement(test, _g("name"))
    name_el.text = test_name

    _sub(test, "investigationTarget", "Natural Ground")

    proj_ref = _sub(test, "projectRef")
    if project_id:
        proj_ref.set(_qn(XLINK_NS, "href"), f"#{project_id}")

    if boring_id:
        sf_ref = _sub(test, "samplingFeatureRef")
        sf_ref.set(_qn(XLINK_NS, "href"), f"#{_safe_id(boring_id)}")

    outcome = _sub(test, "outcome")
    result = _sub(outcome, "TestResult")
    result.set(_g("id"), _safe_id(f"{test_id}-result"))

    if depth_ft is not None:
        loc = _sub(result, "location")
        point = _sub(loc, "PointLocation")
        point.set(_g("id"), _safe_id(f"{test_id}-loc"))
        point.set("srsDimension", "1")
        if boring_id:
            point.set("srsName", f"#{_safe_id(boring_id)}")
        pos = etree.SubElement(point, _g("pos"))
        pos.text = str(depth_ft)

    return test, result


def _add_specification(parent: etree._Element, astm_code: str) -> None:
    """Add a Specification element with an ASTM method code."""
    spec_el = _sub(parent, "Specification")
    spec_el.set(_g("id"), _safe_id(f"spec-{astm_code}"))
    spec_name = etree.SubElement(spec_el, _g("name"))
    spec_name.text = astm_code


def _add_soil_specimen(
    parent: etree._Element, test_id: str, description: str,
) -> None:
    """Add a SoilSpecimen element with soil description."""
    specimen = _sub(parent, "SoilSpecimen")
    specimen.set(_g("id"), _safe_id(f"{test_id}-specimen"))
    _sub(specimen, "soilDescription", description)


def _add_property_params(
    result: etree._Element,
    test_id: str,
    props: list[tuple[str, str, str, str, str]],
) -> None:
    """Add PropertyParameters + dataValues to a TestResult.

    props: list of (name, prop_class, value, type_data, uom)
    """
    results_el = _sub(result, "results")
    result_set = _sub(results_el, "ResultSet")
    params_el = _sub(result_set, "parameters")
    prop_params = _sub(params_el, "PropertyParameters")
    prop_params.set(_g("id"), _safe_id(f"{test_id}-params"))
    properties = _sub(prop_params, "properties")

    values_parts = []
    for idx, (name, prop_class, value, type_data, uom) in enumerate(props, 1):
        prop = _sub(properties, "Property")
        prop.set("index", str(idx))
        prop.set(_g("id"), _safe_id(f"{test_id}-p{idx}"))
        _sub(prop, "propertyName", name)
        _sub(prop, "typeData", type_data)
        pc = _sub(prop, "propertyClass", prop_class)
        pc.set(
            "codeSpace",
            "http://diggsml.org/dictionaries/DIGGSTestPropertyDefinitions.xml"
            f"#{prop_class}",
        )
        if uom:
            _sub(prop, "uom", uom)
        values_parts.append(value)

    dv = _sub(result_set, "dataValues", ",".join(values_parts))
    dv.set("cs", ",")
    dv.set("decimal", ".")
    dv.set("ts", " ")


# =========================================================================
# Lab test serialization — dispatcher
# =========================================================================

_ASTM_CODES = {
    LabTestType.CONSOLIDATION: "D2435",
    LabTestType.GRAIN_SIZE: "D6913",
    LabTestType.ATTERBERG_LIMITS: "D4318",
    LabTestType.TRIAXIAL_UU: "D2850",
    LabTestType.TRIAXIAL_CU: "D4767",
    LabTestType.TRIAXIAL_CD: "D7181",
    LabTestType.UNCONFINED_COMPRESSION: "D2166",
    LabTestType.DIRECT_SHEAR: "D3080",
    LabTestType.MOISTURE_DENSITY: "D698",
}

_DISPATCHERS = {}  # populated below


def _add_lab_test(
    parent: etree._Element,
    lab: LabTestResult,
    index: int,
    project_id: str | None,
) -> None:
    """Dispatch a LabTestResult to the appropriate serializer."""
    handler = _DISPATCHERS.get(lab.test_type)
    if handler:
        handler(parent, lab, index, project_id)
    else:
        _add_generic_lab_test(parent, lab, index, project_id)


# =========================================================================
# Consolidation test
# =========================================================================

def _add_consolidation_test(
    parent: etree._Element,
    lab: LabTestResult,
    index: int,
    project_id: str | None,
) -> None:
    c = lab.consolidation
    if c is None:
        return
    test_id = _safe_id(f"{lab.boring_id or 'unk'}-consol-{index}")
    test, result = _make_test_shell(
        parent, test_id, "Consolidation Test",
        lab.boring_id, lab.sample_depth_ft, project_id,
    )

    # Procedure element with trial data
    proc = _sub_geo(result, "ConsolidationTest")
    if c.e_log_p_curve and c.e_log_p_curve.points:
        for pt in c.e_log_p_curve.points:
            trial = _sub_geo(proc, "ConsolidationTrial")
            _sub_geo(trial, "loadingStress", str(pt.x), uom="tsf")
            _sub_geo(trial, "voidRatio", str(pt.y))

    # Specification
    _add_specification(result, "D2435")

    # SoilSpecimen
    if c.soil_description:
        _add_soil_specimen(result, test_id, c.soil_description)

    # Derived parameters as PropertyParameters
    props: list[tuple[str, str, str, str, str]] = []
    if c.initial_void_ratio is not None:
        props.append(("Initial Void Ratio", "e0", str(c.initial_void_ratio), "double", ""))
    if c.preconsolidation_pressure_tsf is not None:
        props.append(("Preconsolidation Pressure", "Pc", str(c.preconsolidation_pressure_tsf), "double", "tsf"))
    if c.compression_index_cc is not None:
        props.append(("Compression Index", "Cc", str(c.compression_index_cc), "double", ""))
    if c.recompression_index_cr is not None:
        props.append(("Recompression Index", "Cr", str(c.recompression_index_cr), "double", ""))
    if c.swell_index_cs is not None:
        props.append(("Swell Index", "Cs", str(c.swell_index_cs), "double", ""))
    if c.coefficient_of_consolidation_cv is not None:
        props.append(("Coefficient of Consolidation", "cv", str(c.coefficient_of_consolidation_cv), "double", "ft2/day"))

    if props:
        _add_property_params(result, test_id, props)


# =========================================================================
# Grain size test
# =========================================================================

def _add_grain_size_test(
    parent: etree._Element,
    lab: LabTestResult,
    index: int,
    project_id: str | None,
) -> None:
    gs = lab.grain_size
    if gs is None:
        return
    test_id = _safe_id(f"{lab.boring_id or 'unk'}-grainsize-{index}")
    test, result = _make_test_shell(
        parent, test_id, "Grain Size Analysis",
        lab.boring_id, lab.sample_depth_ft, project_id,
    )

    # Procedure element with grading data
    proc = _sub_geo(result, "ParticleSizeTest")
    if gs.gradation_curve and gs.gradation_curve.points:
        for pt in gs.gradation_curve.points:
            grading = _sub_geo(proc, "Grading")
            _sub_geo(grading, "particleSize", str(pt.x), uom="mm")
            _sub_geo(grading, "percentPassing", str(pt.y), uom="%")

    # Specification
    _add_specification(result, "D6913")

    # Derived parameters
    props: list[tuple[str, str, str, str, str]] = []
    if gs.d10_mm is not None:
        props.append(("D10", "D10", str(gs.d10_mm), "double", "mm"))
    if gs.d30_mm is not None:
        props.append(("D30", "D30", str(gs.d30_mm), "double", "mm"))
    if gs.d50_mm is not None:
        props.append(("D50", "D50", str(gs.d50_mm), "double", "mm"))
    if gs.d60_mm is not None:
        props.append(("D60", "D60", str(gs.d60_mm), "double", "mm"))
    if gs.cu is not None:
        props.append(("Uniformity Coefficient", "Cu", str(gs.cu), "double", ""))
    if gs.cc is not None:
        props.append(("Coefficient of Curvature", "Cc_grain", str(gs.cc), "double", ""))
    if gs.percent_gravel is not None:
        props.append(("Percent Gravel", "percent_gravel", str(gs.percent_gravel), "double", "%"))
    if gs.percent_sand is not None:
        props.append(("Percent Sand", "percent_sand", str(gs.percent_sand), "double", "%"))
    if gs.percent_fines is not None:
        props.append(("Percent Fines", "percent_fines", str(gs.percent_fines), "double", "%"))

    if props:
        _add_property_params(result, test_id, props)


# =========================================================================
# Atterberg limits test
# =========================================================================

def _add_atterberg_test(
    parent: etree._Element,
    lab: LabTestResult,
    index: int,
    project_id: str | None,
) -> None:
    att = lab.atterberg
    if att is None:
        return
    test_id = _safe_id(f"{lab.boring_id or 'unk'}-atterberg-{index}")
    test, result = _make_test_shell(
        parent, test_id, "Atterberg Limits Test",
        lab.boring_id, lab.sample_depth_ft, project_id,
    )

    # Procedure element with Casagrande trial data
    proc = _sub_geo(result, "AtterbergLimitsTest")
    if att.flow_curve and att.flow_curve.points:
        for pt in att.flow_curve.points:
            trial = _sub_geo(proc, "CasagrandeTrial")
            _sub_geo(trial, "blowCount", str(int(pt.x) if pt.x == int(pt.x) else pt.x))
            _sub_geo(trial, "waterContent", str(pt.y), uom="%")

    # Specification
    _add_specification(result, "D4318")

    # Derived parameters
    props: list[tuple[str, str, str, str, str]] = []
    if att.liquid_limit is not None:
        props.append(("Liquid Limit", "LL", str(att.liquid_limit), "int", "%"))
    if att.plastic_limit is not None:
        props.append(("Plastic Limit", "PL", str(att.plastic_limit), "int", "%"))
    if att.plasticity_index is not None:
        props.append(("Plasticity Index", "PI", str(att.plasticity_index), "int", "%"))
    if att.natural_moisture_pct is not None:
        props.append(("Natural Moisture Content", "wn", str(att.natural_moisture_pct), "double", "%"))
    if att.uscs_classification is not None:
        props.append(("USCS Classification", "USCS", att.uscs_classification, "string", ""))

    if props:
        _add_property_params(result, test_id, props)


# =========================================================================
# Triaxial test (UU, CU, CD)
# =========================================================================

def _add_triaxial_test(
    parent: etree._Element,
    lab: LabTestResult,
    index: int,
    project_id: str | None,
) -> None:
    s = lab.strength
    if s is None:
        return
    test_id = _safe_id(f"{lab.boring_id or 'unk'}-triaxial-{s.test_type or 'unk'}-{index}")
    test, result = _make_test_shell(
        parent, test_id, f"Triaxial Test ({s.test_type})",
        lab.boring_id, lab.sample_depth_ft, project_id,
    )

    # Procedure element
    proc = _sub_geo(result, "TriaxialTest")
    if s.test_type:
        _sub_geo(proc, "triaxialTestType", s.test_type)
    if s.confining_pressure_psf is not None:
        _sub_geo(proc, "cellPressure", str(s.confining_pressure_psf), uom="psf")

    # Shearing increments from stress-strain curve
    if s.stress_strain_curve and s.stress_strain_curve.points:
        for pt in s.stress_strain_curve.points:
            inc = _sub_geo(proc, "TriaxialShearingIncrement")
            _sub_geo(inc, "axialStrain", str(pt.x), uom="%")
            _sub_geo(inc, "deviatorStress", str(pt.y), uom="psf")

    # Specification
    astm = _ASTM_CODES.get(lab.test_type, "D2850")
    _add_specification(result, astm)

    # Derived parameters
    props: list[tuple[str, str, str, str, str]] = []
    if s.undrained_shear_strength_psf is not None:
        props.append(("Undrained Shear Strength", "su", str(s.undrained_shear_strength_psf), "double", "psf"))
    if s.friction_angle_deg is not None:
        props.append(("Friction Angle", "phi", str(s.friction_angle_deg), "double", "deg"))
    if s.cohesion_psf is not None:
        props.append(("Cohesion", "c", str(s.cohesion_psf), "double", "psf"))
    if s.peak_deviator_stress_psf is not None:
        props.append(("Peak Deviator Stress", "peak_deviator", str(s.peak_deviator_stress_psf), "double", "psf"))
    if s.strain_at_failure_pct is not None:
        props.append(("Strain at Failure", "strain_failure", str(s.strain_at_failure_pct), "double", "%"))

    if props:
        _add_property_params(result, test_id, props)


# =========================================================================
# Unconfined compression test
# =========================================================================

def _add_uc_test(
    parent: etree._Element,
    lab: LabTestResult,
    index: int,
    project_id: str | None,
) -> None:
    s = lab.strength
    if s is None:
        return
    test_id = _safe_id(f"{lab.boring_id or 'unk'}-uc-{index}")
    test, result = _make_test_shell(
        parent, test_id, "Unconfined Compression Test",
        lab.boring_id, lab.sample_depth_ft, project_id,
    )

    # Procedure element
    proc = _sub_geo(result, "UnconfinedCompressiveStrengthTest")

    # Compression increments
    if s.stress_strain_curve and s.stress_strain_curve.points:
        for pt in s.stress_strain_curve.points:
            inc = _sub_geo(proc, "CompressionIncrement")
            _sub_geo(inc, "totalStrain", str(pt.x), uom="%")
            _sub_geo(inc, "stress", str(pt.y), uom="psf")

    if s.strain_at_failure_pct is not None:
        _sub_geo(proc, "axialStrainAtFailure", str(s.strain_at_failure_pct), uom="%")

    # Specification
    _add_specification(result, "D2166")

    # Derived parameters
    props: list[tuple[str, str, str, str, str]] = []
    if s.peak_deviator_stress_psf is not None:
        props.append(("Unconfined Compressive Strength", "qu", str(s.peak_deviator_stress_psf), "double", "psf"))
    if s.undrained_shear_strength_psf is not None:
        props.append(("Undrained Shear Strength", "su", str(s.undrained_shear_strength_psf), "double", "psf"))
    if s.strain_at_failure_pct is not None:
        props.append(("Strain at Failure", "strain_failure", str(s.strain_at_failure_pct), "double", "%"))

    if props:
        _add_property_params(result, test_id, props)


# =========================================================================
# Direct shear test
# =========================================================================

def _add_direct_shear_test(
    parent: etree._Element,
    lab: LabTestResult,
    index: int,
    project_id: str | None,
) -> None:
    s = lab.strength
    if s is None:
        return
    test_id = _safe_id(f"{lab.boring_id or 'unk'}-directshear-{index}")
    test, result = _make_test_shell(
        parent, test_id, "Direct Shear Test",
        lab.boring_id, lab.sample_depth_ft, project_id,
    )

    # Procedure element
    proc = _sub_geo(result, "DirectShearTest")
    if s.confining_pressure_psf is not None:
        _sub_geo(proc, "normalStressApplied", str(s.confining_pressure_psf), uom="psf")

    # Shear increments
    if s.stress_strain_curve and s.stress_strain_curve.points:
        for pt in s.stress_strain_curve.points:
            inc = _sub_geo(proc, "DirectShearTestIncrement")
            _sub_geo(inc, "horizontalDisplacement", str(pt.x), uom="in")
            _sub_geo(inc, "shearStress", str(pt.y), uom="psf")

    # Specification
    _add_specification(result, "D3080")

    # Derived parameters
    props: list[tuple[str, str, str, str, str]] = []
    if s.friction_angle_deg is not None:
        props.append(("Friction Angle", "phi", str(s.friction_angle_deg), "double", "deg"))
    if s.cohesion_psf is not None:
        props.append(("Cohesion", "c", str(s.cohesion_psf), "double", "psf"))

    if props:
        _add_property_params(result, test_id, props)


# =========================================================================
# Moisture-density (Proctor) test
# =========================================================================

def _add_proctor_test(
    parent: etree._Element,
    lab: LabTestResult,
    index: int,
    project_id: str | None,
) -> None:
    md = lab.moisture_density
    if md is None:
        return
    test_id = _safe_id(f"{lab.boring_id or 'unk'}-proctor-{index}")
    test, result = _make_test_shell(
        parent, test_id, "Laboratory Compaction Test",
        lab.boring_id, lab.sample_depth_ft, project_id,
    )

    # Procedure element with trial data
    proc = _sub_geo(result, "LabCompactionTest")
    if md.compaction_curve and md.compaction_curve.points:
        for pt in md.compaction_curve.points:
            trial = _sub_geo(proc, "LabCompactionTestTrial")
            _sub_geo(trial, "moistureContent", str(pt.x), uom="%")
            _sub_geo(trial, "dryDensity", str(pt.y), uom="pcf")

    # Specification
    _add_specification(result, "D698")

    # Derived parameters
    props: list[tuple[str, str, str, str, str]] = []
    if md.optimum_moisture_pct is not None:
        props.append(("Optimum Moisture Content", "OMC", str(md.optimum_moisture_pct), "double", "%"))
    if md.max_dry_density_pcf is not None:
        props.append(("Maximum Dry Density", "MDD", str(md.max_dry_density_pcf), "double", "pcf"))

    if props:
        _add_property_params(result, test_id, props)


# =========================================================================
# Generic/unknown lab test (fallback)
# =========================================================================

def _add_generic_lab_test(
    parent: etree._Element,
    lab: LabTestResult,
    index: int,
    project_id: str | None,
) -> None:
    test_id = _safe_id(f"{lab.boring_id or 'unk'}-labtest-{index}")
    test, result = _make_test_shell(
        parent, test_id, f"Laboratory Test ({lab.test_type})",
        lab.boring_id, lab.sample_depth_ft, project_id,
    )
    _sub_geo(result, "LaboratoryTestProcedure")


# =========================================================================
# Dispatcher registry
# =========================================================================

_DISPATCHERS.update({
    LabTestType.CONSOLIDATION: _add_consolidation_test,
    LabTestType.GRAIN_SIZE: _add_grain_size_test,
    LabTestType.ATTERBERG_LIMITS: _add_atterberg_test,
    LabTestType.TRIAXIAL_UU: _add_triaxial_test,
    LabTestType.TRIAXIAL_CU: _add_triaxial_test,
    LabTestType.TRIAXIAL_CD: _add_triaxial_test,
    LabTestType.UNCONFINED_COMPRESSION: _add_uc_test,
    LabTestType.DIRECT_SHEAR: _add_direct_shear_test,
    LabTestType.MOISTURE_DENSITY: _add_proctor_test,
})
