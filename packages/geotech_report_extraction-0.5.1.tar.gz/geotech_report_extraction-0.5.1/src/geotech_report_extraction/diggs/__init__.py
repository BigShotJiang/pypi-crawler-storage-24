from geotech_report_extraction.diggs.serializer import to_diggs_xml
from geotech_report_extraction.diggs.validator import validate_diggs_xml

__all__ = ["to_diggs_xml", "validate_diggs_xml"]
