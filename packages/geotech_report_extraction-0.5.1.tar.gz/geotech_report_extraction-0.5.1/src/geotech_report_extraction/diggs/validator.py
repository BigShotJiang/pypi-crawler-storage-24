"""DIGGS XML validation.

Validates generated DIGGS XML against the XSD schema using pydiggs
(if available) and performs structural sanity checks.

pydiggs is an optional dependency. When unavailable, validation falls
back to lxml well-formedness parsing and structural checks only.
"""

from __future__ import annotations

import io
import logging
import os
import sys
import tempfile
from dataclasses import dataclass, field

from lxml import etree

logger = logging.getLogger(__name__)

DIGGS_NS = "http://diggsml.org/schemas/2.6"
GML_NS = "http://www.opengis.net/gml/3.2"


@dataclass
class ValidationResult:
    """Result of DIGGS XML validation."""

    valid: bool = True
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def summary(self) -> str:
        if self.valid and not self.warnings:
            return "VALID"
        if self.valid and self.warnings:
            return f"VALID ({len(self.warnings)} warnings)"
        return f"INVALID ({len(self.errors)} errors)"


def validate_diggs_xml(
    xml_string: str,
    schema_path: str | None = None,
) -> ValidationResult:
    """Validate a DIGGS XML string.

    Runs three levels of validation:
      1. XML well-formedness (lxml parse)
      2. Structural checks (required elements present)
      3. XSD schema validation via pydiggs (if installed)

    Args:
        xml_string: The DIGGS XML document as a string.
        schema_path: Optional path to a custom XSD schema file.
            If None, pydiggs uses its bundled DIGGS schema.

    Returns:
        ValidationResult with valid flag, errors, and warnings.
    """
    result = ValidationResult()

    # --- Level 1: Well-formedness ---
    try:
        root = etree.fromstring(xml_string.encode("utf-8"))
    except etree.XMLSyntaxError as e:
        result.valid = False
        result.errors.append(f"XML syntax error: {e}")
        return result

    # --- Level 2: Structural checks ---
    _check_structure(root, result)

    # --- Level 3: XSD schema validation via pydiggs ---
    _check_schema_pydiggs(xml_string, schema_path, result)

    return result


def _check_structure(root: etree._Element, result: ValidationResult) -> None:
    """Check that required DIGGS elements are present and correctly ordered."""
    ns = {"d": DIGGS_NS, "g": GML_NS}

    # Root must be diggs:Diggs
    expected_root = f"{{{DIGGS_NS}}}Diggs"
    if root.tag != expected_root:
        result.valid = False
        result.errors.append(f"Root element is {root.tag}, expected {expected_root}")
        return

    # documentInformation is required (exactly 1)
    doc_infos = root.findall("d:documentInformation", ns)
    if len(doc_infos) != 1:
        result.valid = False
        result.errors.append(
            f"Expected exactly 1 documentInformation, found {len(doc_infos)}"
        )

    # Check documentInformation has creationDate
    for di in doc_infos:
        di_obj = di.find("d:DocumentInformation", ns)
        if di_obj is not None:
            creation = di_obj.find("d:creationDate", ns)
            if creation is None:
                result.valid = False
                result.errors.append("DocumentInformation missing required creationDate")

    # Check each Borehole has required elements
    boreholes = root.findall(".//d:Borehole", ns)
    for bh in boreholes:
        bh_id = bh.get(f"{{{GML_NS}}}id", "unknown")

        if bh.find("g:name", ns) is None:
            result.errors.append(f"Borehole {bh_id}: missing required gml:name")
            result.valid = False

        if bh.find("d:investigationTarget", ns) is None:
            result.errors.append(
                f"Borehole {bh_id}: missing required investigationTarget"
            )
            result.valid = False

        if bh.find("d:projectRef", ns) is None:
            result.errors.append(f"Borehole {bh_id}: missing required projectRef")
            result.valid = False

        if bh.find("d:referencePoint", ns) is None:
            result.errors.append(f"Borehole {bh_id}: missing required referencePoint")
            result.valid = False

        if bh.find("d:centerLine", ns) is None:
            result.errors.append(f"Borehole {bh_id}: missing required centerLine")
            result.valid = False

        # Check element ordering: name before investigationTarget before
        # projectRef before referencePoint before centerLine
        _check_child_order(
            bh,
            [
                f"{{{GML_NS}}}name",
                f"{{{DIGGS_NS}}}investigationTarget",
                f"{{{DIGGS_NS}}}projectRef",
                f"{{{DIGGS_NS}}}referencePoint",
                f"{{{DIGGS_NS}}}centerLine",
            ],
            f"Borehole {bh_id}",
            result,
        )

    # Check each Test has required outcome
    tests = root.findall(".//d:Test", ns)
    for test in tests:
        test_id = test.get(f"{{{GML_NS}}}id", "unknown")
        if test.find("d:outcome", ns) is None:
            result.errors.append(f"Test {test_id}: missing required outcome")
            result.valid = False

    # Check each SamplingActivity has required activityType
    activities = root.findall(".//d:SamplingActivity", ns)
    for act in activities:
        act_id = act.get(f"{{{GML_NS}}}id", "unknown")
        if act.find("d:activityType", ns) is None:
            result.errors.append(
                f"SamplingActivity {act_id}: missing required activityType"
            )
            result.valid = False

    # Sanity: at least one borehole
    if not boreholes:
        result.warnings.append("No Borehole elements found in document")

    # Check for duplicate gml:id values
    all_ids: dict[str, int] = {}
    for el in root.iter():
        gml_id = el.get(f"{{{GML_NS}}}id")
        if gml_id:
            all_ids[gml_id] = all_ids.get(gml_id, 0) + 1
    dupes = {k: v for k, v in all_ids.items() if v > 1}
    if dupes:
        result.valid = False
        for dup_id, count in dupes.items():
            result.errors.append(f"Duplicate gml:id '{dup_id}' ({count} occurrences)")


def _check_child_order(
    parent: etree._Element,
    expected_tags: list[str],
    context: str,
    result: ValidationResult,
) -> None:
    """Verify that child elements appear in the expected order."""
    child_tags = [c.tag for c in parent]
    positions = []
    for tag in expected_tags:
        try:
            pos = child_tags.index(tag)
            positions.append(pos)
        except ValueError:
            continue  # missing elements checked elsewhere

    for i in range(len(positions) - 1):
        if positions[i] > positions[i + 1]:
            result.warnings.append(f"{context}: element ordering may be incorrect")
            break


def _check_schema_pydiggs(
    xml_string: str,
    schema_path: str | None,
    result: ValidationResult,
) -> None:
    """Run XSD validation via pydiggs if available."""
    try:
        from pydiggs import validator
    except ImportError:
        result.warnings.append(
            "pydiggs not installed — skipping XSD schema validation. "
            "Install with: pip install pydiggs"
        )
        return

    # pydiggs requires a file path, so write to a temp file
    tmp_fd, tmp_path = tempfile.mkstemp(suffix=".xml")
    try:
        with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
            f.write(xml_string)

        kwargs = {}
        if schema_path:
            kwargs["schema_path"] = schema_path

        v = validator(tmp_path, **kwargs)

        # pydiggs prints to stdout; capture and discard
        captured = io.StringIO()
        old_stdout = sys.stdout
        try:
            sys.stdout = captured
            v.schema_check()
        finally:
            sys.stdout = old_stdout

        if v.syntax_error_log:
            result.valid = False
            result.errors.append(f"pydiggs syntax error: {v.syntax_error_log}")

        if v.schema_validation_log:
            result.valid = False
            result.errors.append(
                f"pydiggs schema validation error: {v.schema_validation_log}"
            )

    except Exception as e:
        result.warnings.append(f"pydiggs validation failed: {e}")
    finally:
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
