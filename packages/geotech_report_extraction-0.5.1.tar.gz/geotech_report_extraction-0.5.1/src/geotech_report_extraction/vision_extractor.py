"""Vision LLM extraction for boring log pages.

Uses Claude's vision capabilities to extract structured geotechnical
data from boring log page images. This serves as:
1. A high-accuracy extraction method for any format
2. A validation oracle to compare against rule-based results
3. A fallback for formats the rule-based parser can't handle

The vision model sees the page exactly as a human would, so it handles
format diversity naturally — different column layouts, stacked blow counts,
graphical elements, encoded fonts, etc.
"""

from __future__ import annotations

import base64
import io
import json
import logging
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from geotech_report_extraction.llm_backend import LLMBackend

from geotech_report_extraction.models import (
    Borehole,
    ConfidenceLevel,
    DrillingDetails,
    ExtractionConfidence,
    Sample,
    SampleType,
    SoilLayer,
    SPTBlowCounts,
    USCSClassification,
)

logger = logging.getLogger(__name__)

_EXTRACTION_PROMPT = """\
You are a geotechnical engineer reviewing a boring log page. Extract ALL data \
from this boring log page image into structured JSON.

Return a JSON object with these fields:
{
  "boring_id": "string (e.g., B-1, BH-2, GB-3)",
  "total_depth_ft": number or null,
  "elevation_ft": number or null,
  "page_number": "string (e.g., '1 of 3')",
  "samples": [
    {
      "depth_top_ft": number,
      "depth_bottom_ft": number,
      "sample_type": "SS|ST|RC|AU|GB" or null,
      "sample_number": "string" or null,
      "blow_count_1": integer or null (first 6-inch interval),
      "blow_count_2": integer or null (second 6-inch interval),
      "blow_count_3": integer or null (third 6-inch interval),
      "n_value": integer or null (N-value = sum of 2nd + 3rd blows),
      "recovery_in": number or null,
      "refusal": boolean
    }
  ],
  "soil_layers": [
    {
      "depth_top_ft": number,
      "depth_bottom_ft": number or null,
      "description": "string (full soil description)",
      "uscs_code": "string (e.g., CL, SP, SM)" or null,
      "color": "string" or null
    }
  ],
  "water_level_ft": number or null,
  "driller": "string" or null,
  "date_started": "string" or null,
  "date_completed": "string" or null,
  "drill_method": "string" or null
}

Important rules:
- Extract EVERY sample visible on this page, even partial ones
- For SPT blow counts, look for three numbers (dash-separated like "5-8-12", \
stacked vertically, or in separate columns)
- The N-value is the sum of the 2nd and 3rd 6-inch blow counts
- Look for the graphical depth scale on the left side to determine depths
- If blow counts show refusal (e.g., "50/4\\""), set refusal=true
- For soil layers, include the COMPLETE description text
- Return ONLY valid JSON, no markdown formatting or explanation
"""


def _render_page_to_base64(page) -> str:
    """Render a PyMuPDF page to a base64-encoded PNG."""
    import fitz  # noqa: F811

    pix = page.get_pixmap(dpi=150)
    img_bytes = pix.tobytes("png")
    return base64.b64encode(img_bytes).decode("ascii")


def extract_page_with_vision(
    page_image_b64: str,
    api_key: Optional[str] = None,
    model: str = "claude-sonnet-4-20250514",
    backend: Optional["LLMBackend"] = None,
) -> Optional[dict]:
    """Extract boring log data from a page image using vision LLM.

    Args:
        page_image_b64: Base64-encoded PNG image of the boring log page
        api_key: Anthropic API key. If None, reads from ANTHROPIC_API_KEY env var.
            Ignored when ``backend`` is provided.
        model: Model to use (default: claude-sonnet-4-20250514 for cost/quality balance).
            Ignored when ``backend`` is provided.
        backend: Optional LLMBackend instance (AnthropicBackend, FunhouseBackend, etc.).
            When provided, ``api_key`` and ``model`` are ignored and the backend
            handles the LLM call directly.

    Returns:
        Parsed JSON dict with extracted data, or None on failure.
    """
    if backend is not None:
        return backend.vision_extract(page_image_b64, _EXTRACTION_PROMPT, max_tokens=4096)

    # Legacy path: direct Anthropic API call (backward-compatible)
    try:
        import anthropic
    except ImportError:
        logger.error("anthropic package not installed. Install with: pip install anthropic")
        return None

    client = anthropic.Anthropic(api_key=api_key)

    try:
        response = client.messages.create(
            model=model,
            max_tokens=4096,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": "image/png",
                                "data": page_image_b64,
                            },
                        },
                        {
                            "type": "text",
                            "text": _EXTRACTION_PROMPT,
                        },
                    ],
                }
            ],
        )

        # Parse the response
        text = response.content[0].text

        # Strip markdown code fences if present
        text = text.strip()
        if text.startswith("```"):
            text = text.split("\n", 1)[1] if "\n" in text else text[3:]
        if text.endswith("```"):
            text = text[:-3]
        text = text.strip()

        return json.loads(text)

    except json.JSONDecodeError as e:
        logger.warning("Failed to parse vision LLM response as JSON: %s", e)
        return None
    except Exception as e:
        logger.error("Vision extraction failed: %s", e)
        return None


def vision_result_to_borehole(data: dict) -> Borehole:
    """Convert vision LLM extraction result to a Borehole model."""
    samples = []
    for s in data.get("samples", []):
        spt = None
        bc1 = s.get("blow_count_1")
        bc2 = s.get("blow_count_2")
        bc3 = s.get("blow_count_3")
        n_val = s.get("n_value")
        refusal = s.get("refusal", False)

        if any(v is not None for v in [bc1, bc2, bc3, n_val]):
            spt = SPTBlowCounts(
                first_6in=bc1,
                second_6in=bc2,
                third_6in=bc3,
                n_value=n_val if n_val else (
                    (bc2 or 0) + (bc3 or 0) if bc2 is not None and bc3 is not None else None
                ),
                refusal=refusal,
            )

        sample_type = None
        st_text = s.get("sample_type", "")
        if st_text:
            type_map = {
                "SS": SampleType.SPLIT_SPOON,
                "ST": SampleType.SHELBY_TUBE,
                "RC": SampleType.ROCK_CORE,
                "AU": SampleType.AUGER,
                "GB": SampleType.GRAB,
            }
            sample_type = type_map.get(st_text.upper())

        depth_top = s.get("depth_top_ft", 0.0)
        depth_bottom = s.get("depth_bottom_ft", depth_top + 1.5)

        samples.append(Sample(
            sample_number=s.get("sample_number"),
            sample_type=sample_type,
            depth_top_ft=depth_top,
            depth_bottom_ft=depth_bottom,
            recovery_in=s.get("recovery_in"),
            spt=spt,
        ))

    soil_layers = []
    for layer in data.get("soil_layers", []):
        uscs = None
        uscs_code = layer.get("uscs_code", "")
        if uscs_code:
            try:
                uscs = USCSClassification(uscs_code)
            except ValueError:
                pass

        soil_layers.append(SoilLayer(
            depth_top_ft=layer.get("depth_top_ft", 0.0),
            depth_bottom_ft=layer.get("depth_bottom_ft"),
            description=layer.get("description", ""),
            uscs_classification=uscs,
            color=layer.get("color"),
        ))

    boring_id = data.get("boring_id", "UNKNOWN")
    total_depth = data.get("total_depth_ft") or 0.0

    return Borehole(
        boring_id=boring_id,
        depth_ft=total_depth,
        elevation_ft=data.get("elevation_ft"),
        drilling=DrillingDetails(
            method=data.get("drill_method"),
            driller=data.get("driller"),
        ),
        samples=samples,
        soil_layers=soil_layers,
    )


def compare_extractions(
    rule_based: Borehole,
    vision: Borehole,
) -> ExtractionConfidence:
    """Compare rule-based and vision LLM extractions to produce a confidence score.

    High confidence = both methods agree on key values.
    Medium = minor discrepancies (depth off by a few feet, different layer count).
    Low = major disagreement (different sample counts, very different depths).
    Flagged = one method found nothing while the other found data.
    """
    checks: list[str] = []
    score = 0.5

    # Compare boring ID
    rb_id = rule_based.boring_id.upper()
    v_id = vision.boring_id.upper()
    if rb_id == v_id:
        checks.append("boring_id_match")
        score += 0.05
    elif rb_id == "UNKNOWN" and v_id != "UNKNOWN":
        checks.append("vision_has_id")
        score += 0.02
    elif rb_id != "UNKNOWN" and v_id == "UNKNOWN":
        checks.append("rules_has_id")
        score += 0.02
    else:
        checks.append("WARN:boring_id_mismatch")
        score -= 0.05

    # Compare total depth
    rb_depth = rule_based.depth_ft
    v_depth = vision.depth_ft
    if rb_depth > 0 and v_depth > 0:
        if abs(rb_depth - v_depth) < 2.0:
            checks.append("depth_close_match")
            score += 0.10
        elif abs(rb_depth - v_depth) < 5.0:
            checks.append("depth_approximate_match")
            score += 0.05
        else:
            checks.append("WARN:depth_mismatch")
            score -= 0.10

    # Compare sample counts
    rb_count = len(rule_based.samples)
    v_count = len(vision.samples)
    if rb_count > 0 and v_count > 0:
        ratio = min(rb_count, v_count) / max(rb_count, v_count)
        if ratio >= 0.8:
            checks.append("sample_count_match")
            score += 0.15
        elif ratio >= 0.5:
            checks.append("sample_count_approximate")
            score += 0.05
        else:
            checks.append("WARN:sample_count_mismatch")
            score -= 0.10
    elif rb_count == 0 and v_count > 0:
        checks.append("FAIL:rules_missed_samples")
        score -= 0.20
    elif rb_count > 0 and v_count == 0:
        checks.append("WARN:vision_missed_samples")
        score -= 0.05

    # Compare N-values where both have samples at similar depths
    matched_nvals = 0
    mismatched_nvals = 0
    for rb_s in rule_based.samples:
        if not rb_s.spt or rb_s.spt.n_value is None:
            continue
        # Find closest vision sample by depth
        best_v = None
        best_dist = 999
        for v_s in vision.samples:
            dist = abs(rb_s.depth_top_ft - v_s.depth_top_ft)
            if dist < best_dist:
                best_dist = dist
                best_v = v_s
        if best_v and best_dist < 3.0 and best_v.spt and best_v.spt.n_value is not None:
            if rb_s.spt.n_value == best_v.spt.n_value:
                matched_nvals += 1
            elif abs(rb_s.spt.n_value - best_v.spt.n_value) <= 2:
                matched_nvals += 1  # close enough (rounding)
            else:
                mismatched_nvals += 1

    if matched_nvals + mismatched_nvals > 0:
        match_ratio = matched_nvals / (matched_nvals + mismatched_nvals)
        if match_ratio >= 0.8:
            checks.append(f"n_values_match({matched_nvals}/{matched_nvals + mismatched_nvals})")
            score += 0.15
        elif match_ratio >= 0.5:
            checks.append(f"n_values_partial({matched_nvals}/{matched_nvals + mismatched_nvals})")
            score += 0.05
        else:
            checks.append(f"WARN:n_values_disagree({mismatched_nvals})")
            score -= 0.15

    score = max(0.0, min(1.0, score))

    if score >= 0.75:
        level = ConfidenceLevel.HIGH
    elif score >= 0.50:
        level = ConfidenceLevel.MEDIUM
    elif score >= 0.30:
        level = ConfidenceLevel.LOW
    else:
        level = ConfidenceLevel.FLAGGED

    notes = None
    fails = [c for c in checks if c.startswith("FAIL:")]
    warns = [c for c in checks if c.startswith("WARN:")]
    if fails:
        notes = f"Issues: {', '.join(c.replace('FAIL:', '') for c in fails)}"
    elif warns:
        notes = f"Warnings: {', '.join(c.replace('WARN:', '') for c in warns)}"

    return ExtractionConfidence(
        level=level,
        score=round(score, 2),
        checks=checks,
        notes=notes,
    )
