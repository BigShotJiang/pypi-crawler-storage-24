"""Azure Document Intelligence JSON reader.

Reads the JSON output from Azure Document Intelligence's prebuilt-layout
model and converts it into PageContent / PDFContent objects that are
compatible with the existing parser pipeline.

This module replaces pdf_parser.read_pdf() for Palantir Foundry workflows
where only the DI JSON export is available (no PyMuPDF / fitz dependency).

Azure DI provides:
  - pages[].words[]  with polygon bounding boxes (in inches)
  - pages[].lines[]  with polygon bounding boxes (in inches)
  - pages[].width/height  in inches
  - tables[]  with cells and bounding regions
  - content  full document text

This module converts DI coordinates (inches) to points (72 pts/inch)
to match the coordinate system expected by the existing parsers.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Optional, Union

from geotech_report_extraction.pdf_parser import (
    BORING_ID_PATTERNS,
    PageContent,
    PDFContent,
    _BORING_LOG_TITLE_PATTERNS,
    _HARD_DISQUALIFIERS,
    _SOFT_DISQUALIFIERS,
    _SOIL_KEYWORDS,
    _count_blow_counts,
    _detect_firm,
    _extract_boring_id,
)

# Conversion factor: DI uses inches, parsers expect points (72 pts/inch)
INCHES_TO_POINTS = 72.0


def _polygon_to_bbox(polygon: list) -> tuple[float, float, float, float]:
    """Convert a DI polygon to (x0, top, x1, bottom).

    Handles both API formats:
      - 2023-07-31: list of {x, y} dicts  e.g. [{"x": 1.0, "y": 2.0}, ...]
      - 2024-11-30: flat list of floats   e.g. [x1, y1, x2, y2, ...]

    DI polygons are 4 corners in clockwise order from top-left.
    Returns coordinates in inches.
    """
    if not polygon:
        return 0.0, 0.0, 0.0, 0.0
    if isinstance(polygon[0], dict):
        # 2023-07-31 format: [{x, y}, ...]
        xs = [p["x"] for p in polygon]
        ys = [p["y"] for p in polygon]
    else:
        # 2024-11-30 format: [x1, y1, x2, y2, ...]
        xs = polygon[0::2]
        ys = polygon[1::2]
    return min(xs), min(ys), max(xs), max(ys)


def _di_word_to_parser_word(word: dict, scale: float = INCHES_TO_POINTS) -> dict:
    """Convert a DI word dict to the format expected by parsers.

    Parser word format: {text, x0, top, x1, bottom} in points.
    """
    x0, top, x1, bottom = _polygon_to_bbox(word["polygon"])
    return {
        "text": word["content"],
        "x0": x0 * scale,
        "top": top * scale,
        "x1": x1 * scale,
        "bottom": bottom * scale,
    }


def _reconstruct_page_text(di_page: dict) -> str:
    """Reconstruct page text from DI lines.

    DI lines are ordered top-to-bottom, left-to-right on each page.
    """
    lines = di_page.get("lines", [])
    return "\n".join(line["content"] for line in lines)



# _detect_firm and _extract_boring_id are imported from pdf_parser.py


def _classify_boring_log_page(page: PageContent) -> tuple[bool, float]:
    """Classify whether a page is a boring log using multiple signals.

    This is adapted from pdf_parser._classify_boring_log_page but works
    without drawing objects (which DI doesn't provide). The classification
    relies more heavily on text content signals.
    """
    text = page.text or ""
    text_upper = text.upper()

    if len(text.strip()) < 30:
        return False, -5.0

    # --- PHASE 1: HARD DISQUALIFIERS ---
    for pattern in _HARD_DISQUALIFIERS:
        if pattern.search(text):
            return False, -3.0

    if re.search(r"(?i)APPENDIX\s+[A-Z0-9]", text) and len(text.strip()) < 300:
        return False, -3.0

    unique_uscs = len(set(re.findall(
        r"\b(GW|GP|GM|GC|SW|SP|SM|SC|ML|CL|OL|MH|CH|OH|PT)\b", text
    )))
    if unique_uscs >= 10:
        return False, -3.0

    boring_id_matches = set(re.findall(
        r"\b(?:B|BH|BN|TB|GB|GC|BOR|LB|HA|TP|DCP|LDCP|MDCP|WDCP"
        r"|CS|CPT|FP|MW|WB|SB|SS)-\d+[A-Za-z]?\b", text
    ))
    if len(boring_id_matches) > 5:
        return False, -3.0

    text_lines = text.split("\n")
    long_lines = sum(1 for line in text_lines if len(line) > 80)
    if long_lines >= 8:
        return False, -2.0

    # --- PHASE 2: DATA SIGNAL DETECTION ---
    blow_count_matches = _count_blow_counts(text)
    sample_type_matches = len(re.findall(
        r"\bSS\b|\bST\b|\bAU\b|\bRC\b|\bNX\b|\bHQ\b|\bGRAB\b|\bSPT\b", text
    ))
    soil_hits = sum(1 for kw in _SOIL_KEYWORDS if kw in text_upper)
    uscs_matches = len(re.findall(
        r"\b(?:GW|GP|GM|GC|SW|SP|SM|SC|ML|CL|OL|MH|CH|OH|PT)"
        r"(?:\s*[-/]\s*(?:GW|GP|GM|GC|SW|SP|SM|SC|ML|CL|OL|MH|CH|OH|PT))?\b",
        text,
    ))

    has_continuation = bool(
        re.search(r"(?i)\(continued\)", text) and soil_hits >= 1
    )

    has_title = any(p.search(text) for p in _BORING_LOG_TITLE_PATTERNS)
    has_title_at_top = any(
        p.search(text[:300]) for p in _BORING_LOG_TITLE_PATTERNS
    )

    has_strong_data = blow_count_matches >= 2 or (
        blow_count_matches >= 1 and sample_type_matches >= 1
    )
    has_some_data = (
        blow_count_matches >= 1
        or sample_type_matches >= 2
        or has_continuation
        or (has_title_at_top and soil_hits >= 2)
        or (uscs_matches >= 3 and soil_hits >= 2)
    )

    if not has_strong_data:
        for pattern in _SOFT_DISQUALIFIERS:
            if pattern.search(text):
                return False, -1.0

    if not has_some_data:
        return False, 0.0

    # --- PHASE 3: CONFIDENCE SCORING ---
    score = 0.0

    # DI doesn't provide drawing objects, but we compensate with
    # word density — boring logs have many short text items
    if page.words:
        word_count = len(page.words)
        if word_count >= 100:
            score += 1.5
        elif word_count >= 50:
            score += 0.5

    # Text layout: many short lines = tabular data
    if text_lines:
        avg_line_len = sum(len(line) for line in text_lines) / len(text_lines)
        short_lines = sum(1 for line in text_lines if 0 < len(line) <= 25)
        if avg_line_len < 25 and short_lines >= 15:
            score += 1.5

    if has_title:
        score += 2.0
    if blow_count_matches >= 3:
        score += 2.5
    elif blow_count_matches >= 1:
        score += 1.0
    if sample_type_matches >= 3:
        score += 1.5
    elif sample_type_matches >= 1:
        score += 0.5
    if soil_hits >= 3:
        score += 1.5
    elif soil_hits >= 1:
        score += 0.5
    if uscs_matches >= 1 and soil_hits >= 1:
        score += 1.0

    depth_matches = len(re.findall(
        r"(?:^|\s)(\d{1,2}(?:\.[05])?)\s*$", text, re.MULTILINE
    ))
    if depth_matches >= 3:
        score += 1.0
    if has_continuation:
        score += 2.0
    if re.search(r"(?i)\brecov(?:ery)?\b", text) and blow_count_matches >= 1:
        score += 0.5
    if long_lines >= 4:
        score -= 1.5

    # DI-specific boost: if DI detected tables on this page AND it has
    # boring log signals, that's a strong indicator
    if hasattr(page, '_di_has_tables') and page._di_has_tables:
        if has_some_data:
            score += 1.0

    return score >= 3.0, score


def _convert_di_page(
    di_page: dict,
    scale: float = INCHES_TO_POINTS,
    use_ml: bool = True,
) -> PageContent:
    """Convert a single DI page to a PageContent object."""
    page_number = di_page.get("page_number") or di_page.get("pageNumber")
    width_in = di_page.get("width", 8.5)
    height_in = di_page.get("height", 11.0)

    # Convert words
    words = [
        _di_word_to_parser_word(w, scale)
        for w in di_page.get("words", [])
        if "polygon" in w and w.get("content", "").strip()
    ]

    # Reconstruct text from lines
    text = _reconstruct_page_text(di_page)

    pc = PageContent(
        page_number=page_number,
        text=text,
        words=words,
        lines=[],  # DI doesn't provide drawing objects
        width=width_in * scale,
        height=height_in * scale,
    )

    # Classify using ML model (with heuristic fallback)
    if use_ml:
        from geotech_report_extraction.ml_classifier import classify_page
        pc.is_boring_log, pc.classification_score = classify_page(pc)
    else:
        pc.is_boring_log, pc.classification_score = _classify_boring_log_page(pc)

    if pc.is_boring_log:
        pc.boring_id = _extract_boring_id(text)

    return pc


def read_di_json(
    source: Union[str, Path, dict],
    file_label: Optional[str] = None,
    classify: bool = True,
) -> PDFContent:
    """Read an Azure Document Intelligence JSON export and return PDFContent.

    This is the DI-equivalent of pdf_parser.read_pdf(). It produces the
    same PageContent / PDFContent objects so the parser pipeline can work
    identically whether the input is a PDF or DI JSON.

    Args:
        source: Either a file path to the DI JSON, or the already-parsed
                dict. Supports both str paths and Path objects.
        file_label: Optional label for the source file (used in PDFContent.file_path).
        classify: If True (default), run ML classification on each page.
                  Set to False when only text/metadata are needed (e.g.,
                  flattening for a downstream classification step).

    Returns:
        PDFContent with all pages extracted and classified.
    """
    if isinstance(source, dict):
        data = source
        label = file_label or "di_json_input"
    else:
        source = Path(source)
        if not source.exists():
            raise FileNotFoundError(f"DI JSON not found: {source}")
        label = file_label or str(source)
        with open(source, "r", encoding="utf-8") as f:
            data = json.load(f)

    content = PDFContent(file_path=label)

    di_pages = data.get("pages", [])
    content.total_pages = len(di_pages)

    # Identify which pages have tables (from document-level table data)
    pages_with_tables: set[int] = set()
    for table in data.get("tables", []):
        regions = table.get("bounding_regions") or table.get("boundingRegions", [])
        for region in regions:
            pg = region.get("page_number") or region.get("pageNumber")
            if pg is not None:
                pages_with_tables.add(pg)

    # Convert all pages
    for di_page in di_pages:
        pc = _convert_di_page(di_page, use_ml=classify)

        # Tag pages that have DI-detected tables
        pc._di_has_tables = pc.page_number in pages_with_tables

        content.pages.append(pc)

    # Detect firm from first few pages
    for page in content.pages[:5]:
        firm = _detect_firm(page.text)
        if firm:
            content.detected_firm = firm
            break

    # If not found in first 5 pages, check boring log pages
    if classify and content.detected_firm is None:
        for page in content.boring_log_pages[:3]:
            firm = _detect_firm(page.text)
            if firm:
                content.detected_firm = firm
                break

    return content


def extract_from_di_json(
    source: Union[str, Path, dict],
    firm: Optional[str] = None,
    output_diggs: bool = False,
    output_path: Optional[Union[str, Path]] = None,
    file_label: Optional[str] = None,
):
    """Extract borehole data from a DI JSON export.

    This is the DI-equivalent of extract.extract_report(). It uses
    read_di_json() instead of read_pdf(), then runs the same parser
    pipeline.

    Args:
        source: Path to DI JSON file or parsed dict.
        firm: Firm name override ('schnabel', 'langan', or None for auto-detect).
        output_diggs: If True, write DIGGS XML output.
        output_path: Path for DIGGS XML output.
        file_label: Optional label for the source.

    Returns:
        BoreholeLog with all extracted data.
    """
    from geotech_report_extraction.diggs import to_diggs_xml
    from geotech_report_extraction.models import BoreholeLog
    from geotech_report_extraction.parsers.registry import get_di_parser
    from geotech_report_extraction.pdf_parser import group_boring_log_pages

    pdf_content = read_di_json(source, file_label=file_label)

    if firm is None:
        firm = pdf_content.detected_firm

    parser = get_di_parser(firm)
    project = parser.parse_project_info(pdf_content)
    boring_groups = group_boring_log_pages(pdf_content)
    boreholes = []
    warnings: list[str] = []

    for boring_id, pages in boring_groups.items():
        # Skip test pits — they have different data format (no SPT)
        if re.match(r"(?i)^TP-?\d", boring_id):
            warnings.append(f"Skipped test pit {boring_id}")
            continue
        try:
            borehole = parser.parse_boring_log(pages)
            # Ensure boring_id matches the group key (handles UNKNOWN-p* pages)
            if borehole.boring_id != boring_id:
                borehole.boring_id = boring_id
            if not borehole.samples:
                warnings.append(f"Boring {boring_id}: 0 samples extracted")
            boreholes.append(borehole)
        except Exception as e:
            warnings.append(f"Failed to parse boring {boring_id}: {e}")

    result = BoreholeLog(
        project=project,
        boreholes=boreholes,
        source_file=pdf_content.file_path,
        extraction_warnings=warnings,
    )

    if output_diggs:
        if output_path is None and not isinstance(source, dict):
            output_path = Path(source).with_suffix(".xml")
        if output_path:
            xml_str = to_diggs_xml(result)
            Path(output_path).write_text(xml_str, encoding="utf-8")

    return result
