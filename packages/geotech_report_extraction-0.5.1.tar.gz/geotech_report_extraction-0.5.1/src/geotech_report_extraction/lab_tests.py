"""Lab test extraction from geotechnical report pages.

Identifies lab test pages (consolidation, grain size, Atterberg limits,
triaxial, direct shear, unconfined compression, etc.) and uses Claude
vision to digitize X-Y plot data and extract tabulated results.

Many lab tests only appear as figures/plots with no tabular data in the
report.  The vision-based digitizer reads axis labels, scale, and data
points directly from the plot image.
"""

from __future__ import annotations

import base64
import json
import logging
import re
from typing import TYPE_CHECKING, Optional

from pydantic import BaseModel, Field

if TYPE_CHECKING:
    from geotech_report_extraction.llm_backend import LLMBackend

from geotech_report_extraction.pdf_parser import PageContent, PDFContent

logger = logging.getLogger(__name__)


# =========================================================================
# Data models for lab test results
# =========================================================================

class LabTestType:
    """Known lab test types."""
    CONSOLIDATION = "consolidation"
    GRAIN_SIZE = "grain_size"
    ATTERBERG_LIMITS = "atterberg_limits"
    TRIAXIAL_UU = "triaxial_uu"
    TRIAXIAL_CU = "triaxial_cu"
    TRIAXIAL_CD = "triaxial_cd"
    UNCONFINED_COMPRESSION = "unconfined_compression"
    DIRECT_SHEAR = "direct_shear"
    MOISTURE_DENSITY = "moisture_density"
    PERMEABILITY = "permeability"
    CBR = "cbr"
    EXPANSION_INDEX = "expansion_index"
    R_VALUE = "r_value"
    PH = "ph"
    RESISTIVITY = "resistivity"
    CORROSION = "corrosion"
    OTHER = "other"


class XYDataPoint(BaseModel):
    """A single data point from an X-Y plot."""
    x: float
    y: float


class XYSeries(BaseModel):
    """A series of X-Y data points from a plot."""
    label: Optional[str] = Field(
        None, description="Series label (e.g., boring ID, sample depth)"
    )
    points: list[XYDataPoint] = Field(default_factory=list)


class PlotAxes(BaseModel):
    """Axis information extracted from a lab test plot."""
    x_label: Optional[str] = Field(
        None, description="X-axis label (e.g., 'Pressure (tsf)')"
    )
    y_label: Optional[str] = Field(
        None, description="Y-axis label (e.g., 'Void Ratio')"
    )
    x_unit: Optional[str] = Field(None, description="X-axis unit")
    y_unit: Optional[str] = Field(None, description="Y-axis unit")
    x_log_scale: bool = Field(False, description="True if x-axis is logarithmic")
    y_log_scale: bool = Field(False, description="True if y-axis is logarithmic")


class ConsolidationResult(BaseModel):
    """Results from a 1-D consolidation (oedometer) test."""
    boring_id: Optional[str] = None
    sample_depth_ft: Optional[float] = None
    soil_description: Optional[str] = None
    initial_void_ratio: Optional[float] = None
    preconsolidation_pressure_tsf: Optional[float] = Field(
        None, description="Preconsolidation pressure (Pc, tsf)"
    )
    compression_index_cc: Optional[float] = Field(
        None, description="Compression index (Cc)"
    )
    recompression_index_cr: Optional[float] = Field(
        None, description="Recompression index (Cr)"
    )
    swell_index_cs: Optional[float] = Field(
        None, description="Swell index (Cs)"
    )
    coefficient_of_consolidation_cv: Optional[float] = Field(
        None, description="Coefficient of consolidation (cv, ft²/day)"
    )
    e_log_p_curve: Optional[XYSeries] = Field(
        None, description="e vs. log(p) curve data"
    )


class GrainSizeResult(BaseModel):
    """Results from a grain size distribution (sieve + hydrometer) test."""
    boring_id: Optional[str] = None
    sample_depth_ft: Optional[float] = None
    soil_description: Optional[str] = None
    d10_mm: Optional[float] = Field(None, description="D10 particle size (mm)")
    d30_mm: Optional[float] = Field(None, description="D30 particle size (mm)")
    d50_mm: Optional[float] = Field(None, description="D50 (median) particle size (mm)")
    d60_mm: Optional[float] = Field(None, description="D60 particle size (mm)")
    cu: Optional[float] = Field(None, description="Coefficient of uniformity (Cu = D60/D10)")
    cc: Optional[float] = Field(None, description="Coefficient of curvature (Cc)")
    percent_gravel: Optional[float] = None
    percent_sand: Optional[float] = None
    percent_fines: Optional[float] = None
    gradation_curve: Optional[XYSeries] = Field(
        None, description="Grain size vs. percent passing curve"
    )


class AtterbergResult(BaseModel):
    """Results from Atterberg limits testing."""
    boring_id: Optional[str] = None
    sample_depth_ft: Optional[float] = None
    soil_description: Optional[str] = None
    liquid_limit: Optional[int] = None
    plastic_limit: Optional[int] = None
    plasticity_index: Optional[int] = None
    natural_moisture_pct: Optional[float] = None
    uscs_classification: Optional[str] = None
    flow_curve: Optional[XYSeries] = Field(
        None, description="Blow count vs. water content (flow curve)"
    )


class StrengthTestResult(BaseModel):
    """Results from a strength test (triaxial, UC, direct shear)."""
    boring_id: Optional[str] = None
    sample_depth_ft: Optional[float] = None
    soil_description: Optional[str] = None
    test_type: Optional[str] = Field(
        None,
        description="UU, CU, CD, UC, or DS"
    )
    confining_pressure_psf: Optional[float] = Field(
        None, description="Cell/confining pressure (psf)"
    )
    peak_deviator_stress_psf: Optional[float] = Field(
        None, description="Peak deviator stress (psf)"
    )
    undrained_shear_strength_psf: Optional[float] = Field(
        None, description="Undrained shear strength su (psf)"
    )
    friction_angle_deg: Optional[float] = Field(
        None, description="Friction angle phi (degrees)"
    )
    cohesion_psf: Optional[float] = Field(
        None, description="Cohesion c (psf)"
    )
    strain_at_failure_pct: Optional[float] = None
    stress_strain_curve: Optional[XYSeries] = Field(
        None, description="Axial strain vs. deviator stress"
    )
    mohr_circle_data: Optional[list[XYSeries]] = Field(
        None, description="Mohr circle or p-q data"
    )


class MoistureDensityResult(BaseModel):
    """Results from a Proctor / moisture-density test."""
    boring_id: Optional[str] = None
    sample_depth_ft: Optional[float] = None
    soil_description: Optional[str] = None
    test_method: Optional[str] = Field(
        None, description="Standard Proctor, Modified Proctor, etc."
    )
    optimum_moisture_pct: Optional[float] = None
    max_dry_density_pcf: Optional[float] = None
    compaction_curve: Optional[XYSeries] = Field(
        None, description="Moisture content vs. dry density"
    )


class LabTestResult(BaseModel):
    """Container for any lab test result with type discrimination."""
    test_type: str = Field(..., description="Lab test type from LabTestType")
    page_number: Optional[int] = None
    boring_id: Optional[str] = None
    sample_depth_ft: Optional[float] = None
    consolidation: Optional[ConsolidationResult] = None
    grain_size: Optional[GrainSizeResult] = None
    atterberg: Optional[AtterbergResult] = None
    strength: Optional[StrengthTestResult] = None
    moisture_density: Optional[MoistureDensityResult] = None
    raw_plot_data: Optional[dict] = Field(
        None, description="Raw extracted plot data for test types without "
        "a specialized model"
    )


# =========================================================================
# Lab test page detection
# =========================================================================

_LAB_TEST_PATTERNS: list[tuple[re.Pattern, str]] = [
    # Consolidation
    (re.compile(r"(?i)consolidation\s+test"), LabTestType.CONSOLIDATION),
    (re.compile(r"(?i)e[\s-]*(?:vs\.?|versus)\s*log\s*p"), LabTestType.CONSOLIDATION),
    (re.compile(r"(?i)void\s+ratio\s+vs\.?\s+(?:log\s+)?pressure"), LabTestType.CONSOLIDATION),
    (re.compile(r"(?i)oedometer\s+test"), LabTestType.CONSOLIDATION),
    (re.compile(r"(?i)swell[\s-]*(?:consolidation|pressure)"), LabTestType.CONSOLIDATION),
    # Grain size
    (re.compile(r"(?i)grain\s+size\s+(?:distribution|analysis)"), LabTestType.GRAIN_SIZE),
    (re.compile(r"(?i)sieve\s+analysis"), LabTestType.GRAIN_SIZE),
    (re.compile(r"(?i)particle\s+size\s+(?:distribution|analysis)"), LabTestType.GRAIN_SIZE),
    (re.compile(r"(?i)gradation\s+(?:test|curve|analysis)"), LabTestType.GRAIN_SIZE),
    (re.compile(r"(?i)hydrometer\s+analysis"), LabTestType.GRAIN_SIZE),
    # Atterberg limits
    (re.compile(r"(?i)atterberg\s+limits?"), LabTestType.ATTERBERG_LIMITS),
    (re.compile(r"(?i)liquid\s+limit.*plastic\s+limit"), LabTestType.ATTERBERG_LIMITS),
    (re.compile(r"(?i)plasticity\s+(?:chart|index)"), LabTestType.ATTERBERG_LIMITS),
    # Triaxial — specific types MUST come before generic pattern
    (re.compile(r"(?i)\bUU\b\s+triaxial"), LabTestType.TRIAXIAL_UU),
    (re.compile(r"(?i)\bCU\b\s+triaxial"), LabTestType.TRIAXIAL_CU),
    (re.compile(r"(?i)\bCD\b\s+triaxial"), LabTestType.TRIAXIAL_CD),
    (re.compile(r"(?i)triaxial\s+(?:test|compression|shear)"), LabTestType.TRIAXIAL_UU),
    (re.compile(r"(?i)unconsolidated[\s-]*undrained"), LabTestType.TRIAXIAL_UU),
    (re.compile(r"(?i)consolidated[\s-]*undrained"), LabTestType.TRIAXIAL_CU),
    (re.compile(r"(?i)consolidated[\s-]*drained"), LabTestType.TRIAXIAL_CD),
    # Unconfined compression
    (re.compile(r"(?i)unconfined\s+compressive?\s+(?:strength|test)"), LabTestType.UNCONFINED_COMPRESSION),
    (re.compile(r"(?i)\bUCS\b\s+test"), LabTestType.UNCONFINED_COMPRESSION),
    # Direct shear
    (re.compile(r"(?i)direct\s+shear\s+test"), LabTestType.DIRECT_SHEAR),
    # Moisture-density / compaction
    (re.compile(r"(?i)(?:standard|modified)\s+proctor"), LabTestType.MOISTURE_DENSITY),
    (re.compile(r"(?i)moisture[\s-]*density"), LabTestType.MOISTURE_DENSITY),
    (re.compile(r"(?i)compaction\s+(?:test|curve)"), LabTestType.MOISTURE_DENSITY),
    # Permeability
    (re.compile(r"(?i)permeability\s+test"), LabTestType.PERMEABILITY),
    (re.compile(r"(?i)hydraulic\s+conductivity\s+test"), LabTestType.PERMEABILITY),
    # CBR
    (re.compile(r"(?i)\bCBR\b\s+(?:test|results?)"), LabTestType.CBR),
    (re.compile(r"(?i)california\s+bearing\s+ratio"), LabTestType.CBR),
    # Expansion / swell
    (re.compile(r"(?i)expansion\s+index"), LabTestType.EXPANSION_INDEX),
    # R-value
    (re.compile(r"(?i)\bR[\s-]*value\s+test"), LabTestType.R_VALUE),
    # Corrosion / chemical
    (re.compile(r"(?i)(?:corrosion|corrosivity)\s+(?:test|evaluation)"), LabTestType.CORROSION),
    (re.compile(r"(?i)(?:pH|resistivity|sulfate|chloride)\s+(?:test|results?)"), LabTestType.CORROSION),
]


def detect_lab_test_type(text: str) -> Optional[str]:
    """Detect the lab test type from page text.

    Returns the first matching LabTestType constant, or None.
    """
    for pattern, test_type in _LAB_TEST_PATTERNS:
        if pattern.search(text):
            return test_type
    return None


def find_lab_test_pages(
    pdf_content: PDFContent,
) -> list[tuple[PageContent, str, float]]:
    """Find lab test pages in the report with test type and confidence.

    Returns a list of (page, test_type, confidence) tuples for pages
    that appear to contain lab test results.

    Detection signals:
    - Lab test title/keywords in text
    - Not a boring log page
    - Plot-like characteristics (axis labels, grid lines)
    """
    results: list[tuple[PageContent, str, float]] = []

    for page in pdf_content.pages:
        if page.is_boring_log:
            continue

        text = page.text or ""
        text_len = len(text.strip())

        test_type = detect_lab_test_type(text)
        if not test_type:
            continue

        # Score confidence
        score = 0.0

        # Strong: test type keyword match
        score += 0.35

        # Has plot axis indicators
        if re.search(r"(?i)(?:percent|strain|stress|pressure|void|ratio|density|moisture)", text):
            score += 0.15

        # Has sample/boring ID reference
        if re.search(r"\b(?:B|BH|BOR|HA|TP)-\d+", text):
            score += 0.10

        # Has depth reference
        if re.search(r"(?i)(?:depth|sample)\s*[:=]?\s*\d+", text):
            score += 0.10

        # Has drawing elements (plot grid lines)
        if len(page.lines) > 100:
            score += 0.10

        # Has embedded image (scanned plot)
        if page.image_count >= 1:
            score += 0.10

        # Low text density suggests a figure page
        if text_len < 500:
            score += 0.10

        score = min(1.0, score)
        results.append((page, test_type, round(score, 3)))

    # Sort by confidence descending
    results.sort(key=lambda x: x[2], reverse=True)
    return results


# =========================================================================
# Vision-based plot digitizer
# =========================================================================

_PLOT_DIGITIZE_PROMPT = """\
You are a geotechnical engineer analyzing a lab test figure from a \
geotechnical report. Extract ALL data from this plot/figure.

Identify:
1. The test type (consolidation, grain size, triaxial, etc.)
2. The boring ID and sample depth the test was performed on
3. All axis labels, units, and whether axes are log-scale
4. ALL data points visible on the plot — trace each curve carefully

For EACH data series (curve) on the plot, digitize the data points by \
reading their X and Y coordinates from the axes.

Return ONLY valid JSON in this format:
{
  "test_type": "consolidation|grain_size|atterberg|triaxial_uu|triaxial_cu|\
triaxial_cd|unconfined_compression|direct_shear|moisture_density|\
permeability|cbr|other",
  "boring_id": "B-1" or null,
  "sample_depth_ft": 15.0 or null,
  "soil_description": "Gray silty CLAY (CL)" or null,
  "axes": {
    "x_label": "Pressure (tsf)",
    "y_label": "Void Ratio",
    "x_unit": "tsf",
    "y_unit": "dimensionless",
    "x_log_scale": true,
    "y_log_scale": false
  },
  "data_series": [
    {
      "label": "Loading",
      "points": [
        {"x": 0.1, "y": 0.85},
        {"x": 0.25, "y": 0.84},
        {"x": 0.5, "y": 0.82},
        {"x": 1.0, "y": 0.78},
        {"x": 2.0, "y": 0.70},
        {"x": 4.0, "y": 0.58}
      ]
    }
  ],
  "derived_parameters": {
    "description": "key parameters readable from the plot or noted on the figure",
    "values": {}
  },
  "tabulated_data": {
    "description": "any tabulated data shown alongside the plot",
    "rows": []
  },
  "notes": "any observations about the test or data quality"
}

Important:
- Read data points carefully from the plot axes — precision matters
- For log-scale axes, note the actual values (e.g., 0.1, 1.0, 10.0)
- For grain size plots: X is grain diameter (mm, log scale), Y is percent passing
- For consolidation: X is pressure (tsf or psf, log scale), Y is void ratio or strain
- For triaxial: capture both stress-strain curve AND Mohr circle data if shown
- Include ALL curves if multiple samples are plotted together
- Extract any derived parameters noted on the figure (Cc, Cr, Pc, phi, c, etc.)
- If there is a data table alongside the plot, extract that too
- Return ONLY the JSON, no markdown fences
"""


def digitize_lab_plot(
    page_image_b64: str,
    api_key: Optional[str] = None,
    model: str = "claude-sonnet-4-20250514",
    backend: Optional["LLMBackend"] = None,
) -> Optional[dict]:
    """Use vision LLM to digitize a lab test plot.

    Sends a high-resolution page image to the LLM and asks it to read
    all data points from the X-Y plot, including axis labels and
    derived parameters.

    Args:
        page_image_b64: Base64-encoded PNG of the lab test page.
        api_key: Anthropic API key. Ignored when ``backend`` is provided.
        model: Model to use for digitization. Ignored when ``backend`` is provided.
        backend: Optional LLMBackend instance. When provided, ``api_key`` and
            ``model`` are ignored.

    Returns:
        Parsed JSON dict with axes, data series, and parameters,
        or None on failure.
    """
    if backend is not None:
        return backend.vision_extract(page_image_b64, _PLOT_DIGITIZE_PROMPT, max_tokens=8192)

    # Legacy path: direct Anthropic API call (backward-compatible)
    try:
        import anthropic
    except ImportError:
        logger.error("anthropic package required for lab plot digitization")
        return None

    client = anthropic.Anthropic(api_key=api_key)

    try:
        response = client.messages.create(
            model=model,
            max_tokens=8192,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": "image/png",
                                "data": page_image_b64,
                            },
                        },
                        {
                            "type": "text",
                            "text": _PLOT_DIGITIZE_PROMPT,
                        },
                    ],
                }
            ],
        )

        text = response.content[0].text.strip()
        # Strip markdown code fences if present
        if text.startswith("```"):
            text = text.split("\n", 1)[1] if "\n" in text else text[3:]
        if text.endswith("```"):
            text = text[:-3]
        text = text.strip()

        return json.loads(text)

    except json.JSONDecodeError as e:
        logger.warning("Failed to parse lab digitization response as JSON: %s", e)
        return None
    except Exception as e:
        logger.error("Lab plot digitization failed: %s", e)
        return None


# =========================================================================
# Result parsing — convert raw vision JSON to typed models
# =========================================================================

def _get_param(d: dict, *keys):
    """Get a value from dict trying multiple keys, distinguishing 0 from None."""
    for k in keys:
        val = d.get(k)
        if val is not None:
            return val
    return None


def _parse_xy_series(raw_series: dict) -> XYSeries:
    """Convert raw JSON series to XYSeries model."""
    points = [
        XYDataPoint(x=p["x"], y=p["y"])
        for p in raw_series.get("points", [])
        if "x" in p and "y" in p
    ]
    return XYSeries(label=raw_series.get("label"), points=points)


def _parse_axes(raw_axes: dict) -> PlotAxes:
    """Convert raw JSON axes to PlotAxes model."""
    return PlotAxes(
        x_label=raw_axes.get("x_label"),
        y_label=raw_axes.get("y_label"),
        x_unit=raw_axes.get("x_unit"),
        y_unit=raw_axes.get("y_unit"),
        x_log_scale=raw_axes.get("x_log_scale", False),
        y_log_scale=raw_axes.get("y_log_scale", False),
    )


def parse_consolidation(raw: dict) -> ConsolidationResult:
    """Parse vision output into a ConsolidationResult."""
    derived = raw.get("derived_parameters", {}).get("values", {})

    e_log_p = None
    series_list = raw.get("data_series", [])
    if series_list:
        # Use the first (or "Loading") series as the e-log-p curve
        for s in series_list:
            label = (s.get("label") or "").lower()
            if "load" in label or "virgin" in label or not e_log_p:
                e_log_p = _parse_xy_series(s)

    return ConsolidationResult(
        boring_id=raw.get("boring_id"),
        sample_depth_ft=raw.get("sample_depth_ft"),
        soil_description=raw.get("soil_description"),
        initial_void_ratio=_get_param(derived, "e0", "initial_void_ratio"),
        preconsolidation_pressure_tsf=_get_param(
            derived, "Pc", "pc", "preconsolidation_pressure",
        ),
        compression_index_cc=_get_param(
            derived, "Cc", "cc", "compression_index",
        ),
        recompression_index_cr=_get_param(
            derived, "Cr", "cr", "recompression_index",
        ),
        swell_index_cs=_get_param(derived, "Cs", "cs"),
        coefficient_of_consolidation_cv=_get_param(derived, "cv"),
        e_log_p_curve=e_log_p,
    )


def parse_grain_size(raw: dict) -> GrainSizeResult:
    """Parse vision output into a GrainSizeResult."""
    derived = raw.get("derived_parameters", {}).get("values", {})

    gradation = None
    series_list = raw.get("data_series", [])
    if series_list:
        gradation = _parse_xy_series(series_list[0])

    return GrainSizeResult(
        boring_id=raw.get("boring_id"),
        sample_depth_ft=raw.get("sample_depth_ft"),
        soil_description=raw.get("soil_description"),
        d10_mm=_get_param(derived, "D10", "d10"),
        d30_mm=_get_param(derived, "D30", "d30"),
        d50_mm=_get_param(derived, "D50", "d50"),
        d60_mm=_get_param(derived, "D60", "d60"),
        cu=_get_param(derived, "Cu", "cu"),
        cc=_get_param(derived, "Cc", "cc"),
        percent_gravel=_get_param(derived, "percent_gravel", "gravel"),
        percent_sand=_get_param(derived, "percent_sand", "sand"),
        percent_fines=_get_param(derived, "percent_fines", "fines"),
        gradation_curve=gradation,
    )


def parse_atterberg(raw: dict) -> AtterbergResult:
    """Parse vision output into an AtterbergResult."""
    derived = raw.get("derived_parameters", {}).get("values", {})

    flow_curve = None
    series_list = raw.get("data_series", [])
    if series_list:
        flow_curve = _parse_xy_series(series_list[0])

    return AtterbergResult(
        boring_id=raw.get("boring_id"),
        sample_depth_ft=raw.get("sample_depth_ft"),
        soil_description=raw.get("soil_description"),
        liquid_limit=_get_param(derived, "LL", "liquid_limit"),
        plastic_limit=_get_param(derived, "PL", "plastic_limit"),
        plasticity_index=_get_param(derived, "PI", "plasticity_index"),
        natural_moisture_pct=_get_param(derived, "natural_moisture", "wn"),
        uscs_classification=_get_param(derived, "USCS", "classification"),
        flow_curve=flow_curve,
    )


def parse_strength_test(raw: dict) -> StrengthTestResult:
    """Parse vision output into a StrengthTestResult."""
    derived = raw.get("derived_parameters", {}).get("values", {})

    stress_strain = None
    mohr_circles = None
    series_list = raw.get("data_series", [])
    for s in series_list:
        label = (s.get("label") or "").lower()
        if "mohr" in label or "circle" in label:
            if mohr_circles is None:
                mohr_circles = []
            mohr_circles.append(_parse_xy_series(s))
        elif "stress" in label or "strain" in label or not stress_strain:
            stress_strain = _parse_xy_series(s)

    test_type_str = raw.get("test_type", "")
    test_code = None
    if "uu" in test_type_str.lower():
        test_code = "UU"
    elif "cu" in test_type_str.lower():
        test_code = "CU"
    elif "cd" in test_type_str.lower():
        test_code = "CD"
    elif "unconfined" in test_type_str.lower():
        test_code = "UC"
    elif "direct" in test_type_str.lower() or "shear" in test_type_str.lower():
        test_code = "DS"

    return StrengthTestResult(
        boring_id=raw.get("boring_id"),
        sample_depth_ft=raw.get("sample_depth_ft"),
        soil_description=raw.get("soil_description"),
        test_type=test_code,
        confining_pressure_psf=_get_param(derived, "confining_pressure"),
        peak_deviator_stress_psf=_get_param(derived, "peak_deviator_stress"),
        undrained_shear_strength_psf=_get_param(
            derived, "su", "undrained_shear_strength",
        ),
        friction_angle_deg=_get_param(derived, "phi", "friction_angle"),
        cohesion_psf=_get_param(derived, "c", "cohesion"),
        strain_at_failure_pct=_get_param(derived, "strain_at_failure"),
        stress_strain_curve=stress_strain,
        mohr_circle_data=mohr_circles,
    )


def parse_moisture_density(raw: dict) -> MoistureDensityResult:
    """Parse vision output into a MoistureDensityResult."""
    derived = raw.get("derived_parameters", {}).get("values", {})

    compaction_curve = None
    series_list = raw.get("data_series", [])
    if series_list:
        compaction_curve = _parse_xy_series(series_list[0])

    return MoistureDensityResult(
        boring_id=raw.get("boring_id"),
        sample_depth_ft=raw.get("sample_depth_ft"),
        soil_description=raw.get("soil_description"),
        test_method=_get_param(derived, "test_method", "method"),
        optimum_moisture_pct=_get_param(derived, "optimum_moisture", "OMC"),
        max_dry_density_pcf=_get_param(derived, "max_dry_density", "MDD"),
        compaction_curve=compaction_curve,
    )


def vision_result_to_lab_test(raw: dict, page_number: int) -> LabTestResult:
    """Convert raw vision JSON to a typed LabTestResult.

    Dispatches to the appropriate parser based on test_type.
    """
    test_type = raw.get("test_type", LabTestType.OTHER)

    result = LabTestResult(
        test_type=test_type,
        page_number=page_number,
        boring_id=raw.get("boring_id"),
        sample_depth_ft=raw.get("sample_depth_ft"),
    )

    if test_type == LabTestType.CONSOLIDATION:
        result.consolidation = parse_consolidation(raw)
    elif test_type == LabTestType.GRAIN_SIZE:
        result.grain_size = parse_grain_size(raw)
    elif test_type in (LabTestType.ATTERBERG_LIMITS,):
        result.atterberg = parse_atterberg(raw)
    elif test_type in (
        LabTestType.TRIAXIAL_UU, LabTestType.TRIAXIAL_CU,
        LabTestType.TRIAXIAL_CD, LabTestType.UNCONFINED_COMPRESSION,
        LabTestType.DIRECT_SHEAR,
    ):
        result.strength = parse_strength_test(raw)
    elif test_type == LabTestType.MOISTURE_DENSITY:
        result.moisture_density = parse_moisture_density(raw)
    else:
        # Store raw data for unknown test types
        result.raw_plot_data = raw

    return result


# =========================================================================
# End-to-end extraction
# =========================================================================

def extract_lab_tests(
    pdf_content: PDFContent,
    api_key: Optional[str] = None,
    model: str = "claude-sonnet-4-20250514",
    backend: Optional["LLMBackend"] = None,
) -> list[LabTestResult]:
    """End-to-end lab test extraction from a geotechnical report.

    1. Identifies lab test pages via text pattern matching
    2. Renders each lab page at high resolution
    3. Sends to vision LLM for plot digitization
    4. Parses results into typed data models

    Args:
        pdf_content: Parsed PDF content from read_pdf().
        api_key: Anthropic API key (required for digitization unless backend
            is provided). Ignored when ``backend`` is provided.
        model: Model for vision extraction. Ignored when ``backend`` is provided.
        backend: Optional LLMBackend instance. When provided, ``api_key`` and
            ``model`` are ignored.

    Returns:
        List of LabTestResult objects, one per lab test page.
    """
    import fitz

    lab_pages = find_lab_test_pages(pdf_content)
    if not lab_pages:
        logger.info("No lab test pages found")
        return []

    if backend is None and not api_key:
        logger.warning(
            "Found %d lab test pages but no API key or backend for digitization",
            len(lab_pages),
        )
        return []

    logger.info("Found %d lab test pages to digitize", len(lab_pages))

    doc = fitz.open(pdf_content.file_path)
    results: list[LabTestResult] = []

    try:
        for page_content, test_type, confidence in lab_pages:
            if confidence < 0.30:
                logger.debug(
                    "Skipping page %d (confidence=%.2f below 0.30)",
                    page_content.page_number, confidence,
                )
                continue

            logger.info(
                "Digitizing %s test on page %d (confidence=%.2f)",
                test_type, page_content.page_number, confidence,
            )

            fitz_page = doc[page_content.page_number - 1]
            pix = fitz_page.get_pixmap(dpi=200)
            img_b64 = base64.b64encode(pix.tobytes("png")).decode("ascii")

            raw = digitize_lab_plot(
                img_b64, api_key=api_key, model=model, backend=backend,
            )
            if not raw:
                logger.warning(
                    "Vision digitization returned no data for page %d",
                    page_content.page_number,
                )
                continue

            lab_result = vision_result_to_lab_test(
                raw, page_content.page_number,
            )
            results.append(lab_result)
    finally:
        doc.close()

    logger.info("Extracted %d lab test results", len(results))
    return results
