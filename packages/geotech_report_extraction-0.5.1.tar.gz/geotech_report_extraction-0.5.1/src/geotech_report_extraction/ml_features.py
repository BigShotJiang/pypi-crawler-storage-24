"""Feature extraction for boring log page classification.

Extracts numerical features from PageContent objects for use with
an ML classifier (XGBoost). Features mirror the signals used in the
hand-tuned heuristic classifier but are returned as a flat dict of
floats suitable for model training and inference.

Includes optional TF-IDF features when a vocabulary file is available.
"""

from __future__ import annotations

import math
import re

import numpy as np
from pathlib import Path
from typing import Optional

from geotech_report_extraction.pdf_parser import (
    BORING_ID_PATTERNS,
    PageContent,
    _BORING_LOG_TITLE_PATTERNS,
    _HARD_DISQUALIFIERS,
    _SOFT_DISQUALIFIERS,
    _SOIL_KEYWORDS,
    _count_blow_counts,
)

# ---------------------------------------------------------------------------
# TF-IDF feature support
# ---------------------------------------------------------------------------

_PACKAGE_DATA_DIR = Path(__file__).parent / "data"
_TFIDF_VOCAB_PATH = _PACKAGE_DATA_DIR / "tfidf_vocab.txt"
_TFIDF_IDF_PATH = _PACKAGE_DATA_DIR / "tfidf_idf.txt"

# Lazy-loaded globals
_tfidf_vocab: Optional[list[str]] = None
_tfidf_idf: Optional[dict[str, float]] = None
_tfidf_loaded: bool = False


def _load_tfidf():
    """Load TF-IDF vocabulary and IDF weights from package data."""
    global _tfidf_vocab, _tfidf_idf, _tfidf_loaded
    _tfidf_loaded = True

    if not _TFIDF_VOCAB_PATH.exists() or not _TFIDF_IDF_PATH.exists():
        _tfidf_vocab = None
        _tfidf_idf = None
        return

    _tfidf_vocab = [
        line.strip() for line in _TFIDF_VOCAB_PATH.read_text().strip().split("\n")
        if line.strip()
    ]
    idf_lines = _TFIDF_IDF_PATH.read_text().strip().split("\n")
    _tfidf_idf = {}
    for line in idf_lines:
        parts = line.strip().split("\t")
        if len(parts) == 2:
            _tfidf_idf[parts[0]] = float(parts[1])


def get_tfidf_vocab() -> Optional[list[str]]:
    """Return the TF-IDF vocabulary (list of terms), or None if not available."""
    if not _tfidf_loaded:
        _load_tfidf()
    return _tfidf_vocab


def compute_tfidf_features(text: str) -> dict[str, float]:
    """Compute TF-IDF features for a page's text using the saved vocabulary.

    Returns a dict of {tfidf_<term>: score} for each term in the vocabulary.
    Returns empty dict if TF-IDF files are not available.
    """
    if not _tfidf_loaded:
        _load_tfidf()

    if _tfidf_vocab is None or _tfidf_idf is None:
        return {}

    # Tokenize: lowercase, split on non-alphanumeric, keep tokens 2+ chars
    tokens = re.findall(r"[a-z][a-z0-9]+", text.lower())
    total_tokens = len(tokens)
    if total_tokens == 0:
        return {f"tfidf_{term}": 0.0 for term in _tfidf_vocab}

    # Count term frequencies
    tf_counts: dict[str, int] = {}
    for token in tokens:
        if token in _tfidf_idf:
            tf_counts[token] = tf_counts.get(token, 0) + 1

    # Also check bigrams
    for i in range(len(tokens) - 1):
        bigram = f"{tokens[i]}_{tokens[i+1]}"
        if bigram in _tfidf_idf:
            tf_counts[bigram] = tf_counts.get(bigram, 0) + 1

    # Compute TF-IDF: tf(t) = count(t) / total_tokens, tfidf = tf * idf
    result = {}
    for term in _tfidf_vocab:
        tf = tf_counts.get(term, 0) / total_tokens
        idf = _tfidf_idf.get(term, 0.0)
        result[f"tfidf_{term}"] = tf * idf

    return result


def extract_features(
    page: PageContent,
    total_pages: int = 0,
    page_index: int = -1,
) -> dict[str, float]:
    """Extract classification features from a single page.

    Args:
        page: The page to extract features from.
        total_pages: Total pages in the document (0 if unknown).
        page_index: 0-based index of this page in the document (-1 if unknown).

    Returns a dict of feature_name -> float value. All features are
    numerical (int counts cast to float, booleans as 0.0/1.0).

    Feature groups:
    - Text statistics (length, line counts, word count)
    - Content signals (blow counts, sample types, soil keywords, USCS codes)
    - Title/header signals
    - Layout signals (short/long lines, avg line length)
    - Disqualifier signals (hard/soft matches)
    - Boring ID signals (count of distinct IDs on page)
    - DI-specific signals (table detection)
    """
    text = page.text or ""
    text_upper = text.upper()
    text_lines = text.split("\n")
    text_stripped_len = len(text.strip())

    # --- Text statistics ---
    word_count = len(page.words) if page.words else len(text.split())
    line_count = len(text_lines)
    non_empty_lines = sum(1 for line in text_lines if line.strip())

    # --- Line length distribution ---
    line_lengths = [len(line) for line in text_lines]
    avg_line_len = sum(line_lengths) / max(len(line_lengths), 1)
    short_lines = sum(1 for ll in line_lengths if 0 < ll <= 25)
    long_lines = sum(1 for ll in line_lengths if ll > 80)
    very_long_lines = sum(1 for ll in line_lengths if ll > 120)

    # --- Content signals ---
    blow_count_matches = _count_blow_counts(text)

    sample_type_matches = len(re.findall(
        r"\bSS\b|\bST\b|\bAU\b|\bRC\b|\bNX\b|\bHQ\b|\bGRAB\b|\bSPT\b", text
    ))

    soil_hits = sum(1 for kw in _SOIL_KEYWORDS if kw in text_upper)

    uscs_matches = len(re.findall(
        r"\b(?:GW|GP|GM|GC|SW|SP|SM|SC|ML|CL|OL|MH|CH|OH|PT)"
        r"(?:\s*[-/]\s*(?:GW|GP|GM|GC|SW|SP|SM|SC|ML|CL|OL|MH|CH|OH|PT))?\b",
        text,
    ))

    unique_uscs = len(set(re.findall(
        r"\b(GW|GP|GM|GC|SW|SP|SM|SC|ML|CL|OL|MH|CH|OH|PT)\b", text
    )))

    # Depth column values (numbers at end of line, 0-99 with .0 or .5)
    depth_matches = len(re.findall(
        r"(?:^|\s)(\d{1,2}(?:\.[05])?)\s*$", text, re.MULTILINE
    ))

    # Recovery mention with blow counts
    has_recovery = bool(
        re.search(r"(?i)\brecov(?:ery)?\b", text) and blow_count_matches >= 1
    )

    # Continuation page signal
    has_continuation = bool(
        re.search(r"(?i)\(continued\)", text) and soil_hits >= 1
    )

    # --- Title/header signals ---
    has_title = float(any(p.search(text) for p in _BORING_LOG_TITLE_PATTERNS))
    has_title_at_top = float(any(
        p.search(text[:300]) for p in _BORING_LOG_TITLE_PATTERNS
    ))

    # --- Disqualifier signals ---
    hard_disqualifier_hit = float(any(
        p.search(text) for p in _HARD_DISQUALIFIERS
    ))

    soft_disqualifier_hit = float(any(
        p.search(text) for p in _SOFT_DISQUALIFIERS
    ))

    is_appendix_divider = float(
        bool(re.search(r"(?i)APPENDIX\s+[A-Z0-9]", text))
        and text_stripped_len < 300
    )

    # --- Boring ID signals ---
    boring_id_set = set(re.findall(
        r"\b(?:B|BH|BN|TB|GB|GC|BOR|LB|HA|TP|DCP|LDCP|MDCP|WDCP"
        r"|CS|CPT|FP|MW|WB|SB|SS)-\d+[A-Za-z]?\b", text
    ))
    distinct_boring_ids = len(boring_id_set)

    # Can we extract a boring ID from this page?
    has_boring_id = 0.0
    for pattern in BORING_ID_PATTERNS:
        if pattern.search(text):
            has_boring_id = 1.0
            break

    # --- Drawing/structure signals ---
    drawing_count = len(page.lines) if page.lines else 0

    # --- DI-specific signals ---
    di_has_tables = float(
        getattr(page, '_di_has_tables', False)
    )

    # --- Numeric pattern density ---
    # Boring logs have dense numeric data (depths, blow counts, percentages)
    numeric_tokens = len(re.findall(r"\b\d+\.?\d*\b", text))
    numeric_ratio = numeric_tokens / max(word_count, 1)

    # --- Water level mentions ---
    water_level_mentions = len(re.findall(
        r"(?i)\bwater\s+level\b|\bgroundwater\b|\bwater\s+table\b", text
    ))

    # --- Elevation/coordinate mentions ---
    elevation_mentions = len(re.findall(
        r"(?i)\belev(?:ation)?\b\.?\s*:?\s*\d", text
    ))

    # --- "Page X of Y" pattern (common on boring log forms) ---
    has_page_of = float(bool(
        re.search(r"(?i)\bpage\s+\d+\s+of\s+\d+\b", text)
    ))

    # --- Foreign language indicator ---
    # French/other non-English text in subcontractor logs
    foreign_word_count = len(re.findall(
        r"(?i)\b(?:essai|forage|profondeur|échantillon|sondage"
        r"|résultat|argile|sable|limon|roche|nappe)\b", text
    ))

    # --- Photo page indicators ---
    # Core sample photo pages have "Photo No.", "Box X of Y", "Caisse"
    photo_mentions = len(re.findall(
        r"(?i)\bphoto\s*(?:no\.?|number|#)|\bbox\s+\d+\s+of\s+\d+\b"
        r"|\bcaisse\b|\bcore\s+(?:photo|box)\b", text
    ))

    # --- Lab test page indicators ---
    lab_test_mentions = len(re.findall(
        r"(?i)\bATTERBERG\b|\bLIQUID\s+LIMIT\b|\bPLASTIC\s+LIMIT\b"
        r"|\bGRAIN\s+SIZE\b|\bSIEVE\b|\bTRIAXIAL\b|\bCONSOLIDATION\b"
        r"|\bDIRECT\s+SHEAR\b|\bPH\s+VALUE\s+TEST\b|\bMOISTURE\s+CONTENT\b"
        r"|\bSPECIFIC\s+GRAVITY\b|\bCOMPACTION\s+TEST\b"
        r"|\bUNCONFINED\s+COMPRESSIVE\b|\bCBR\b", text
    ))

    # --- Cross-section/plan page indicators ---
    # These pages mention multiple boring IDs with elevation data
    cross_section_signal = float(bool(
        re.search(r"(?i)\bG\.?S\.?E\.?\b", text)  # Ground Surface Elevation
        and distinct_boring_ids >= 2
    ))

    # --- "Sheet X of Y" pattern (standard boring log form header) ---
    has_sheet_of = float(bool(
        re.search(r"(?i)\bsheet\s+\d+\s+of\s+\d+\b", text)
    ))

    # --- Firm name on page (Schnabel/Langan header = strong boring log signal) ---
    has_firm_name = float(bool(
        re.search(r"(?i)\bSCHNABEL\b|\bLANGAN\b", text)
    ))

    # --- Comma-separated decimals (European number format, common in foreign logs) ---
    european_decimals = len(re.findall(r"\d+,\d{2}\b", text))

    # --- Non-ASCII character ratio (OCR artifacts from photos/foreign text) ---
    if text_stripped_len > 0:
        non_ascii_chars = sum(1 for c in text if ord(c) > 127)
        non_ascii_ratio = non_ascii_chars / text_stripped_len
    else:
        non_ascii_ratio = 0.0

    # ---------------------------------------------------------------
    # Multi-class features (added for 16-class page type classifier)
    # ---------------------------------------------------------------

    # --- Calculation page indicators ---
    # Safety factors, slope stability output, engineering software output
    safety_factor_mentions = len(re.findall(
        r"(?i)\bF\.?S\.?\b|\bfactor\s+of\s+safety\b|\bsafety\s+factor\b", text
    ))
    # Coordinates/tabular numeric data (X, Y pairs or sequential numbers)
    coordinate_pairs = len(re.findall(
        r"\b\d+\.\d+\s+\d+\.\d+\b", text
    ))
    # Engineering calculation keywords (calc-specific, avoiding shared terms)
    calc_keywords = len(re.findall(
        r"(?i)\bbearing\s+capacity\b|\blateral\s+earth\s+pressure\b"
        r"|\bslope\s+stability\b|\bsettlement\b"
        r"|\bfooting\b|\bretaining\s+wall\b|\bpile\s+capacity\b"
        r"|\bbishop\b|\brankin\b|\bfactor\s+of\s+safety\b"
        r"|\belliptical\b|\bschmertmann\b|\boverturning\b"
        r"|\bsliding\b|\buplift\b|\bdemand\b|\bcapacity\b", text
    ))
    # Software/file path indicators (common in calc output)
    has_file_path = float(bool(re.search(
        r"[a-zA-Z]:\\|\.pl2\b|\.out\b|Run\s+By:", text
    )))

    # --- Narrative indicators ---
    # Section numbering (1.0, 2.1, 3.2.1, etc.)
    section_numbers = len(re.findall(
        r"(?m)^\s*\d{1,2}\.\d(?:\.\d)?\s+[A-Z]", text
    ))
    # Paragraph density: long blocks of prose separated by blank lines
    paragraphs = len(re.findall(r"\n\s*\n", text))
    # Average words per non-empty line (proxy for prose vs tabular)
    words_per_line = word_count / max(non_empty_lines, 1)

    # --- Cover page indicators ---
    # Very sparse text with project-identifying keywords
    has_project_label = float(bool(re.search(
        r"(?i)\bnew\s+embassy\b|\bembassy\s+compound\b|\bgeotechnical\b.*\breport\b"
        r"|\bdesign.?build\b|\bprepared\s+(?:for|by)\b", text
    )))
    # Low content density (cover pages have sparse, centered text)
    content_density = len(text.replace(" ", "").replace("\n", "")) / max(len(text), 1)

    # --- Table of contents indicators ---
    toc_header = float(bool(re.search(
        r"(?i)\btable\s+of\s+contents\b|\blist\s+of\s+(?:tables|figures|appendices)\b",
        text
    )))
    # Page number references at end of lines (e.g., "Section Title   23")
    page_ref_lines = len(re.findall(
        r"(?m)\S\s+\d{1,3}\s*$", text
    ))

    # --- Cover letter indicators ---
    letter_signals = len(re.findall(
        r"(?i)\bdear\s+\w+\b|\bsincerely\b|\brespectfully\b"
        r"|\bsubject:\b|\bsubmitted\b|\bherewith\b|\benclosed\b"
        r"|\bcc:\b|\bre:\b.*(?:report|geotechnical)", text
    ))
    has_date_line = float(bool(re.search(
        r"(?i)(?:January|February|March|April|May|June|July|August"
        r"|September|October|November|December)\s+\d{1,2},?\s+\d{4}", text
    )))

    # --- Appended report indicators ---
    # Presence of another firm's report letterhead or standard structures
    has_prepared_by = float(bool(re.search(
        r"(?i)\bprepared\s+(?:by|for)\b.*(?:Ltd|LLC|Inc|Corp|S\.A\.|Pty)",
        text
    )))
    # Langan/Schnabel specific patterns for identifying appended vs main
    has_langan_header = float(bool(re.search(
        r"(?i)\bLangan\s+Project\s+No\b|\bLangan\s+Engineering\b", text
    )))

    # --- Test location plan indicators ---
    location_plan_signal = float(bool(re.search(
        r"(?i)\blocation\s+plan\b|\binvestigation\s+(?:location|plan)\b"
        r"|\bboring\s+location\b|\btest\s+location\b", text
    )))

    # --- Appendix cover page indicators ---
    appendix_label = float(bool(re.search(
        r"(?i)^\s*APPENDIX\s+[A-Z]\b", text, re.MULTILINE
    )))
    is_short_page = float(text_stripped_len < 500)

    # --- Infiltration/drainage test indicators ---
    infiltration_signal = len(re.findall(
        r"(?i)\binfiltration\b|\bpercolation\b|\bpermeability\b"
        r"|\bflood\s+(?:data|test)\b|\bbasin\b.*\btest\b", text
    ))

    # --- Test pit indicators ---
    test_pit_signal = float(bool(re.search(
        r"(?i)\btest\s+pit\b|\bTP[-\s]?\d", text
    )))

    # --- ASTM standard references ---
    astm_count = len(re.findall(r"(?i)\bASTM\s*[A-Z]?\s*[-]?\s*\d", text))

    # --- Scientific notation (common in calculations/lab data) ---
    scientific_notation = len(re.findall(r"\d+\.?\d*[eE][+-]?\d+", text))

    # --- Lab-specific: external lab headers, test result formatting ---
    has_lab_header = float(bool(re.search(
        r"(?i)\bLaborat(?:ory|oire)\b|\bClient\s*:|\bWorkorder\s*:"
        r"|\bSample\s*(?:ID|Type)\b|\bTest\s+Results?\b"
        r"|\bJob\s+No\s*[.:]", text
    )))
    # Sieve/grain size data (percent passing with mesh sizes)
    sieve_data = len(re.findall(
        r"(?i)\b(?:No\.\s*\d+|#\s*\d+)\b.*\b\d+\.?\d*\s*%", text
    )) + len(re.findall(r"(?i)\bpercent\s+(?:passing|retained|finer)\b", text))
    # Moisture/water content as percentage
    moisture_data = len(re.findall(
        r"(?i)\bmoisture\s+content\b|\bwater\s+content\b|\bw\s*[=:]\s*\d", text
    ))

    # Lab-exclusive vocabulary (high frequency in lab, rare in calc)
    lab_vocab_hits = len(re.findall(
        r"(?i)\bspecimen\b|\bcontainer\b|\bparticle\b|\bfiner\b"
        r"|\bmould\b|\bswell\b|\bshelby\b|\bplastic\s+limit\b"
        r"|\bliquid\s+limit\b|\bhydrometer\b|\bproctor\b"
        r"|\bretained\b|\bdry\s+density\b|\bmass\s+of\b"
        r"|\bsample\s+no\b|\bfine\s+medium\b|\bmedium\s+coarse\b"
        r"|\bdry\s+soil\b|\bparticle\s+size\b|\bapproved\b"
        r"|\breading\b|\blaboratories\b|\btriaxial\b"
        r"|\bcompaction\b|\bpermeability\b|\bspecific\s+gravity\b", text
    ))

    # --- Calc-specific: engineering analysis output ---
    has_calc_header = float(bool(re.search(
        r"(?i)\bJob\s+Name\s*:|\bDate\s*:.*\bBy\s*:", text
    )))
    # Structural/geotechnical calculation keywords
    structural_keywords = len(re.findall(
        r"(?i)\bmicropile\b|\bdrilled\s+shaft\b|\bspread\s+footing\b"
        r"|\bmat\s+foundation\b|\bearth\s+pressure\b|\bsurcharge\b"
        r"|\boverburden\b|\bsubgrade\s+reaction\b|\ballowable\b"
        r"|\bultimate\b.*\bcapacity\b|\bdesign\s+load\b", text
    ))

    # Calc-exclusive vocabulary (high frequency in calc, rare in lab)
    calc_vocab_hits = len(re.findall(
        r"(?i)\bschmertmann\b|\bpile\b|\bfooting\b|\bbending\b"
        r"|\bshaft\b|\bpsf\b|\bwall\b|\bseismic\b|\bstiffness\b"
        r"|\bsubgrade\b|\bsteel\b|\bmoment\b|\blateral\b"
        r"|\bunit\s+weight\b|\bpile\s+head\b|\bload\s+case\b"
        r"|\bbending\s+moment\b|\bshear\s+force\b|\beffective\s+unit\b"
        r"|\bbottom\s+of\b|\bactive\b|\bpassive\b|\bembedment\b"
        r"|\bkips\b|\bplf\b|\bklf\b|\btributary\b|\bdeflection\b"
        r"|\btip\s+resistance\b|\bskin\s+friction\b|\bdowndrag\b", text
    ))

    # --- Figure/drawing indicators ---
    scale_mentions = len(re.findall(
        r"(?i)\bscale\s*[=:]\s*\d|\bnot\s+to\s+scale\b|\bN\.?T\.?S\.?\b", text
    ))

    # --- Other/misc class: highly variable content ---
    has_reference_list = float(bool(re.search(
        r"(?i)\breferences?\s*:?\s*$|\bbibliography\b", text, re.MULTILINE
    )))

    features = {
        # Text statistics
        "text_length": float(text_stripped_len),
        "word_count": float(word_count),
        "line_count": float(line_count),
        "non_empty_lines": float(non_empty_lines),

        # Line length distribution
        "avg_line_len": avg_line_len,
        "short_lines": float(short_lines),
        "long_lines": float(long_lines),
        "very_long_lines": float(very_long_lines),

        # Content signals
        "blow_count_matches": float(blow_count_matches),
        "sample_type_matches": float(sample_type_matches),
        "soil_hits": float(soil_hits),
        "uscs_matches": float(uscs_matches),
        "unique_uscs": float(unique_uscs),
        "depth_matches": float(depth_matches),
        "has_recovery": float(has_recovery),
        "has_continuation": float(has_continuation),

        # Title/header
        "has_title": has_title,
        "has_title_at_top": has_title_at_top,

        # Disqualifiers
        "hard_disqualifier_hit": hard_disqualifier_hit,
        "soft_disqualifier_hit": soft_disqualifier_hit,
        "is_appendix_divider": is_appendix_divider,

        # Boring ID signals
        "distinct_boring_ids": float(distinct_boring_ids),
        "has_boring_id": has_boring_id,

        # Structure
        "drawing_count": float(drawing_count),

        # DI-specific
        "di_has_tables": di_has_tables,

        # Numeric density
        "numeric_tokens": float(numeric_tokens),
        "numeric_ratio": numeric_ratio,

        # Domain-specific
        "water_level_mentions": float(water_level_mentions),
        "elevation_mentions": float(elevation_mentions),
        "has_page_of": has_page_of,
        "foreign_word_count": float(foreign_word_count),

        # Photo/lab/plan page indicators
        "photo_mentions": float(photo_mentions),
        "lab_test_mentions": float(lab_test_mentions),
        "cross_section_signal": cross_section_signal,

        # Form structure indicators
        "has_sheet_of": has_sheet_of,
        "has_firm_name": has_firm_name,

        # Foreign format indicators
        "european_decimals": float(european_decimals),
        "non_ascii_ratio": non_ascii_ratio,

        # --- Multi-class features ---

        # Calculation indicators
        "safety_factor_mentions": float(safety_factor_mentions),
        "coordinate_pairs": float(coordinate_pairs),
        "calc_keywords": float(calc_keywords),
        "has_file_path": has_file_path,
        "scientific_notation": float(scientific_notation),

        # Narrative indicators
        "section_numbers": float(section_numbers),
        "paragraphs": float(paragraphs),
        "words_per_line": words_per_line,

        # Cover page indicators
        "has_project_label": has_project_label,
        "content_density": content_density,

        # Table of contents indicators
        "toc_header": toc_header,
        "page_ref_lines": float(page_ref_lines),

        # Cover letter indicators
        "letter_signals": float(letter_signals),
        "has_date_line": has_date_line,

        # Appended report indicators
        "has_prepared_by": has_prepared_by,
        "has_langan_header": has_langan_header,

        # Test location plan
        "location_plan_signal": location_plan_signal,

        # Appendix cover page
        "appendix_label": appendix_label,
        "is_short_page": is_short_page,

        # Specialized test indicators
        "infiltration_signal": float(infiltration_signal),
        "test_pit_signal": test_pit_signal,
        "astm_count": float(astm_count),

        # Lab vs calc distinguishers
        "has_lab_header": has_lab_header,
        "sieve_data": float(sieve_data),
        "moisture_data": float(moisture_data),
        "lab_vocab_hits": float(lab_vocab_hits),
        "has_calc_header": has_calc_header,
        "structural_keywords": float(structural_keywords),
        "calc_vocab_hits": float(calc_vocab_hits),

        # Figure/drawing
        "scale_mentions": float(scale_mentions),

        # Other
        "has_reference_list": has_reference_list,

        # Positional features
        "page_position": float(page_index / max(total_pages - 1, 1))
            if total_pages > 0 and page_index >= 0 else 0.5,
        "page_number_raw": float(page_index) if page_index >= 0 else 0.0,
        "total_pages": float(total_pages),
        "is_first_10pct": float(
            page_index < max(total_pages * 0.1, 1)
        ) if total_pages > 0 and page_index >= 0 else 0.0,
        "is_last_25pct": float(
            page_index >= total_pages * 0.75
        ) if total_pages > 0 and page_index >= 0 else 0.0,
    }

    # TF-IDF features (appended dynamically based on saved vocabulary)
    tfidf = compute_tfidf_features(text)
    features.update(tfidf)

    return features


BASE_FEATURE_NAMES = [
    # Original binary classifier features (38)
    "text_length", "word_count", "line_count", "non_empty_lines",
    "avg_line_len", "short_lines", "long_lines", "very_long_lines",
    "blow_count_matches", "sample_type_matches", "soil_hits",
    "uscs_matches", "unique_uscs", "depth_matches", "has_recovery",
    "has_continuation",
    "has_title", "has_title_at_top",
    "hard_disqualifier_hit", "soft_disqualifier_hit", "is_appendix_divider",
    "distinct_boring_ids", "has_boring_id",
    "drawing_count",
    "di_has_tables",
    "numeric_tokens", "numeric_ratio",
    "water_level_mentions", "elevation_mentions",
    "has_page_of", "foreign_word_count",
    "photo_mentions", "lab_test_mentions", "cross_section_signal",
    "has_sheet_of", "has_firm_name",
    "european_decimals", "non_ascii_ratio",
    # Multi-class features (21)
    "safety_factor_mentions", "coordinate_pairs", "calc_keywords",
    "has_file_path", "scientific_notation",
    "section_numbers", "paragraphs", "words_per_line",
    "has_project_label", "content_density",
    "toc_header", "page_ref_lines",
    "letter_signals", "has_date_line",
    "has_prepared_by", "has_langan_header",
    "location_plan_signal",
    "appendix_label", "is_short_page",
    "infiltration_signal", "test_pit_signal", "astm_count",
    # Lab vs calc distinguishers (9)
    "has_lab_header", "sieve_data", "moisture_data", "lab_vocab_hits",
    "has_calc_header", "structural_keywords", "calc_vocab_hits",
    "scale_mentions", "has_reference_list",
    # Positional features (5)
    "page_position", "page_number_raw", "total_pages",
    "is_first_10pct", "is_last_25pct",
]

# Sequence feature names for the second-stage model
SEQUENCE_FEATURE_NAMES = [
    # Predictions from neighbors (15 classes × 5 positions = 75 features)
    # prev2, prev1, current, next1, next2 — each as 15-class probability vector
] + [
    f"seq_{pos}_{cls}"
    for pos in ["prev2", "prev1", "curr", "next1", "next2"]
    for cls in [
        "appendix_cover_page", "boring_log", "calculation", "cover_letter",
        "cover_page", "field_photos", "figure", "informational_appendix",
        "lab_testing", "main_report_narrative", "other", "subsurface_profile",
        "table_of_contents", "test_location_plan", "test_pit_log",
    ]
] + [
    # Transition features
    "seq_prev1_same_as_curr",   # Does prev page have same predicted class?
    "seq_next1_same_as_curr",   # Does next page have same predicted class?
    "seq_run_length",           # How many consecutive pages with same prediction?
    "seq_curr_confidence",      # XGBoost confidence for current page
    "seq_prev1_confidence",     # XGBoost confidence for previous page
    "seq_next1_confidence",     # XGBoost confidence for next page
]


def build_sequence_features(
    all_probs: np.ndarray,
    class_names: list[str],
) -> np.ndarray:
    """Build second-stage features from first-stage XGBoost probability predictions.

    Args:
        all_probs: (n_pages, n_classes) array of predicted probabilities
        class_names: list of class names matching the columns of all_probs

    Returns:
        (n_pages, n_seq_features) array of sequence features
    """
    n_pages, n_classes = all_probs.shape
    n_positions = 5  # prev2, prev1, curr, next1, next2
    offsets = [-2, -1, 0, 1, 2]

    # Neighbor probability features (75)
    neighbor_feats = np.zeros((n_pages, n_positions * n_classes))
    for i in range(n_pages):
        for j, offset in enumerate(offsets):
            idx = i + offset
            if 0 <= idx < n_pages:
                neighbor_feats[i, j * n_classes:(j + 1) * n_classes] = all_probs[idx]

    # Transition features (6)
    preds = all_probs.argmax(axis=1)
    confs = all_probs.max(axis=1)
    trans_feats = np.zeros((n_pages, 6))

    for i in range(n_pages):
        # prev1 same as curr
        trans_feats[i, 0] = float(preds[i - 1] == preds[i]) if i > 0 else 0.0
        # next1 same as curr
        trans_feats[i, 1] = float(preds[i + 1] == preds[i]) if i < n_pages - 1 else 0.0
        # Run length: count consecutive same predictions around current page
        run = 1
        for k in range(i - 1, -1, -1):
            if preds[k] == preds[i]:
                run += 1
            else:
                break
        for k in range(i + 1, n_pages):
            if preds[k] == preds[i]:
                run += 1
            else:
                break
        trans_feats[i, 2] = float(run)
        # Confidences
        trans_feats[i, 3] = confs[i]
        trans_feats[i, 4] = confs[i - 1] if i > 0 else 0.0
        trans_feats[i, 5] = confs[i + 1] if i < n_pages - 1 else 0.0

    return np.hstack([neighbor_feats, trans_feats])


def get_feature_names() -> list[str]:
    """Return the full feature name list including TF-IDF terms if available."""
    vocab = get_tfidf_vocab()
    if vocab:
        return BASE_FEATURE_NAMES + [f"tfidf_{term}" for term in vocab]
    return list(BASE_FEATURE_NAMES)


# For backward compatibility — populated once TF-IDF vocab is loaded
FEATURE_NAMES = BASE_FEATURE_NAMES
