"""Report structure analysis via appendix cover page template detection.

**Approach** (template-first):

1. Collect all pages the XGBoost classifier predicted as ``appendix_cover_page``.
2. Extract a structural fingerprint from each (header lines, footer lines,
   word count, presence of "APPENDIX [letter]").
3. Cluster the fingerprints to find the dominant template — the shared
   header/footer pattern that real appendix covers in this report use.
4. Confirm each classifier prediction against the template.  Pages that
   don't match (e.g., a figure page the classifier wasn't sure about)
   are dropped.
5. Scan the rest of the document for pages the classifier missed but that
   match the confirmed template (regex + template similarity fallback).
6. Extract metadata: appendix letter, title, semantic type, page ranges.

This is report-specific — the template adapts to whatever firm/format the
report uses.  It also flags appended sub-reports that use a *different*
cover template.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Optional


# ---------------------------------------------------------------------------
# Regex patterns
# ---------------------------------------------------------------------------

_APPENDIX_LETTER_RE = re.compile(
    r"(?i)\bAPPENDIX\s+([A-Z]\d?)\b"
)

_SKIP_LINE_RE = re.compile(
    r"(?i)^\s*(?:"
    r"(?:schnabel|langan|hwa|geoengineering|ch2m|ngi|terracon|aecom)"
    r"|project\s+\d"
    r"|\d{1,2}[/\-]\d{1,2}[/\-]\d{2,4}"
    r"|(?:january|february|march|april|may|june|july|august"
    r"|september|october|november|december)\s+\d"
    r"|©\d{4}"
    r"|all\s+rights\s+reserved"
    r"|unclassified|confidential|draft"
    r"|llc|inc\.|corp\."
    r")\b"
)

# ---------------------------------------------------------------------------
# Semantic type mapping
# ---------------------------------------------------------------------------

_APPENDIX_TYPE_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("subsurface_exploration", re.compile(
        r"(?i)(?:subsurface|boring|borehole|test\s*hole|exploration)\s+"
        r"(?:exploration|data|log|record)"
    )),
    ("boring_logs", re.compile(
        r"(?i)\bboring\s+logs?\b"
    )),
    ("test_pit_logs", re.compile(
        r"(?i)\btest\s+pit\s+logs?\b"
    )),
    ("laboratory_data", re.compile(
        r"(?i)(?:laboratory|lab)\s+(?:test|data|result)"
    )),
    ("field_testing", re.compile(
        r"(?i)(?:field\s+test|in[\s-]?situ\s+test|cpt|spt|dcp|vane\s+shear)"
    )),
    ("infiltration_testing", re.compile(
        r"(?i)(?:infiltration|percolation|drainage|permeability)\s+test"
    )),
    ("calculations", re.compile(
        r"(?i)\bcalculation"
    )),
    ("figures", re.compile(
        r"(?i)\bfigures?\b"
    )),
    ("photos", re.compile(
        r"(?i)(?:photo|photograph)"
    )),
    ("site_plan", re.compile(
        r"(?i)(?:site\s+plan|location\s+plan|plot\s+plan|test\s+location)"
    )),
    ("seismic", re.compile(
        r"(?i)(?:seismic|geophysic|masw|refraction|downhole)"
    )),
    ("geotechnical_report", re.compile(
        r"(?i)(?:geotechnical|geotech)\s+(?:report|investigation|study)"
    )),
    ("factual_report", re.compile(
        r"(?i)factual\s+report"
    )),
    ("environmental", re.compile(
        r"(?i)(?:environmental|contamination|hazmat)"
    )),
    ("subsurface_profile", re.compile(
        r"(?i)subsurface\s+profile"
    )),
]


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class CoverTemplate:
    """Structural fingerprint of appendix cover pages in a report.

    Built from confirmed classifier predictions, then used to find
    pages the classifier missed.
    """

    header_lines: list[str]
    """Normalized header lines shared across covers (before APPENDIX line)."""

    footer_lines: list[str]
    """Normalized footer lines shared across covers (after content list)."""

    typical_word_count: tuple[int, int]
    """(min, max) word count range across confirmed covers."""

    has_appendix_keyword: bool = True
    """Whether covers contain 'APPENDIX [letter]' (always True for now)."""

    source_pages: list[int] = field(default_factory=list)
    """0-based page indices used to build this template."""


@dataclass
class AppendixSection:
    """A single appendix within a geotechnical report."""

    letter: str
    """Appendix letter (e.g. 'A', 'B', 'C', 'A1')."""

    title: str
    """Raw title text extracted from the cover page."""

    semantic_type: str
    """Mapped content type (e.g. 'boring_logs', 'laboratory_data', 'unknown')."""

    cover_page: int
    """0-based page index of the appendix cover page."""

    start_page: int
    """0-based page index of the first content page (cover_page + 1)."""

    end_page: int
    """0-based page index of the last page in this appendix (inclusive)."""

    page_count: int
    """Total pages including cover."""

    matched_template: bool = True
    """Whether this cover matched the report's dominant template."""

    page_types: dict[str, int] = field(default_factory=dict)
    """Count of each page type within this appendix (from classifier output)."""


@dataclass
class ReportStructure:
    """Hierarchical structure of a geotechnical report."""

    total_pages: int
    """Total pages in the document."""

    main_body_end: int
    """0-based page index where the main body ends (last page before first appendix)."""

    template: Optional[CoverTemplate] = None
    """The detected appendix cover template for this report (None if no covers found)."""

    appendices: list[AppendixSection] = field(default_factory=list)
    """Detected appendices in document order."""

    def get_appendix(self, letter: str) -> Optional[AppendixSection]:
        """Look up an appendix by letter."""
        letter = letter.upper()
        for a in self.appendices:
            if a.letter.upper() == letter:
                return a
        return None

    def page_appendix(self, page_idx: int) -> Optional[AppendixSection]:
        """Return which appendix a page belongs to, or None if main body."""
        for a in self.appendices:
            if a.cover_page <= page_idx <= a.end_page:
                return a
        return None

    def summary(self) -> str:
        """Human-readable summary."""
        lines = [
            f"Report: {self.total_pages} pages, "
            f"main body ends at page {self.main_body_end + 1}"
        ]
        if self.template:
            hdr = " | ".join(self.template.header_lines[:3]) or "(none)"
            ftr = " | ".join(self.template.footer_lines[:2]) or "(none)"
            lines.append(f"  Template: header=[{hdr}], footer=[{ftr}], "
                         f"words={self.template.typical_word_count}")
        for a in self.appendices:
            flag = "" if a.matched_template else " [NO TEMPLATE MATCH]"
            lines.append(
                f"  Appendix {a.letter}: \"{a.title}\" [{a.semantic_type}] "
                f"pp.{a.cover_page + 1}-{a.end_page + 1} "
                f"({a.page_count} pages){flag}"
            )
            if a.page_types:
                top = sorted(a.page_types.items(), key=lambda x: -x[1])[:3]
                lines.append(
                    f"    Content: "
                    f"{', '.join(f'{t}({n})' for t, n in top)}"
                )
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Fingerprinting helpers
# ---------------------------------------------------------------------------

def _normalize_line(line: str) -> str:
    """Normalize a line for template comparison.

    Strips whitespace, lowercases, and removes variable parts like
    dates, page numbers, and appendix letters so that the structural
    skeleton remains.
    """
    s = line.strip().lower()
    # Remove dates
    s = re.sub(r"\b\d{1,2}[/\-]\d{1,2}[/\-]\d{2,4}\b", "<DATE>", s)
    s = re.sub(
        r"\b(?:january|february|march|april|may|june|july|august"
        r"|september|october|november|december)\s+\d{1,2},?\s*\d{4}\b",
        "<DATE>", s,
    )
    # Remove appendix letter (so "APPENDIX A" and "APPENDIX D" match)
    s = re.sub(r"(?i)\bappendix\s+[a-z]\d?\b", "appendix <x>", s)
    # Remove project numbers
    s = re.sub(r"\b\d{5,}[\.\-]?\d*\b", "<PROJNUM>", s)
    return s.strip()


def _get_non_empty_lines(text: str) -> list[str]:
    """Return non-empty stripped lines from page text."""
    return [ln.strip() for ln in text.splitlines() if ln.strip()]


def _extract_fingerprint(text: str) -> dict:
    """Extract structural fingerprint from a page.

    Returns dict with:
      - header: normalized lines before the APPENDIX line
      - footer: normalized lines at the very end
      - word_count: total word count
      - has_appendix: whether APPENDIX [letter] is present
      - appendix_line_idx: index of the APPENDIX line in non-empty lines
      - raw_lines: all non-empty lines (not normalized)
    """
    lines = _get_non_empty_lines(text)
    norm = [_normalize_line(ln) for ln in lines]

    appendix_idx = None
    for i, n in enumerate(norm):
        if "appendix <x>" in n:
            appendix_idx = i
            break

    header = norm[:appendix_idx] if appendix_idx is not None else []
    # Footer: last 1-2 lines (often "DRAFT", copyright, firm name)
    # Skip lines that are part of the content listing
    footer = norm[-2:] if len(norm) > 3 else []

    return {
        "header": header,
        "footer": footer,
        "word_count": len(text.split()),
        "has_appendix": appendix_idx is not None,
        "appendix_line_idx": appendix_idx,
        "raw_lines": lines,
    }


# ---------------------------------------------------------------------------
# Template building
# ---------------------------------------------------------------------------

def _build_template(
    fingerprints: list[dict],
    page_indices: list[int],
) -> Optional[CoverTemplate]:
    """Build a cover template from confirmed cover page fingerprints.

    Finds the common header and footer lines across all fingerprints.
    Requires at least 2 fingerprints to establish a pattern; with 1,
    uses that single page's structure directly.
    """
    if not fingerprints:
        return None

    # Filter to only pages that actually have APPENDIX keyword
    valid = [(fp, idx) for fp, idx in zip(fingerprints, page_indices)
             if fp["has_appendix"]]
    if not valid:
        return None

    fps = [v[0] for v in valid]
    idxs = [v[1] for v in valid]

    if len(fps) == 1:
        fp = fps[0]
        return CoverTemplate(
            header_lines=fp["header"],
            footer_lines=fp["footer"],
            typical_word_count=(
                max(1, fp["word_count"] - 20),
                fp["word_count"] + 50,
            ),
            source_pages=idxs,
        )

    # Find common header: lines that appear in the same position across
    # all fingerprints (allowing for minor variation).
    max_header_len = min(len(fp["header"]) for fp in fps) if fps else 0
    common_header: list[str] = []
    for pos in range(max_header_len):
        lines_at_pos = [fp["header"][pos] for fp in fps]
        if len(set(lines_at_pos)) == 1:
            common_header.append(lines_at_pos[0])
        else:
            break  # Stop at first divergence

    # Find common footer (from the end)
    max_footer_len = min(len(fp["footer"]) for fp in fps) if fps else 0
    common_footer: list[str] = []
    for pos in range(1, max_footer_len + 1):
        lines_at_pos = [fp["footer"][-pos] for fp in fps]
        if len(set(lines_at_pos)) == 1:
            common_footer.insert(0, lines_at_pos[0])
        else:
            break

    wc_values = [fp["word_count"] for fp in fps]

    return CoverTemplate(
        header_lines=common_header,
        footer_lines=common_footer,
        typical_word_count=(
            max(1, min(wc_values) - 20),
            max(wc_values) + 50,
        ),
        source_pages=idxs,
    )


def _matches_template(
    fingerprint: dict,
    template: CoverTemplate,
) -> bool:
    """Check if a page fingerprint matches the cover template.

    A page matches if:
    - It has the APPENDIX keyword
    - Its word count is within the template range (with tolerance)
    - It shares the common header OR footer lines (at least one)
    """
    if not fingerprint["has_appendix"]:
        return False

    # A page listing multiple different appendix letters is a TOC/listing
    # page, not a single appendix cover.
    raw_text = "\n".join(fingerprint["raw_lines"])
    all_letters = _APPENDIX_LETTER_RE.findall(raw_text)
    if len(set(l.upper() for l in all_letters)) > 1:
        return False

    # Word count check (generous range)
    wc = fingerprint["word_count"]
    wc_min, wc_max = template.typical_word_count
    # Allow 2x the max for covers with longer content listings
    if wc > wc_max * 2:
        return False

    # Header match: check if the page starts with the template header
    if template.header_lines:
        page_header = fingerprint["header"][:len(template.header_lines)]
        header_match = page_header == template.header_lines
    else:
        header_match = False

    # Footer match
    if template.footer_lines:
        page_footer = fingerprint["footer"][-len(template.footer_lines):]
        footer_match = page_footer == template.footer_lines
    else:
        footer_match = False

    # Structural match: at least one of header/footer must match
    has_structural_match = header_match or footer_match

    # For minimal templates (no header AND no footer — e.g., Langan style
    # with just "APPENDIX A / BORING LOGS"), the fingerprint is only
    # the APPENDIX keyword.  In this case, require very sparse pages
    # (real minimal covers are typically < 20 words) and that "APPENDIX"
    # appears within the first few lines.
    if not template.header_lines and not template.footer_lines:
        if wc > 30:
            return False
        # APPENDIX line must be near the top (within first 3 non-empty lines)
        idx = fingerprint.get("appendix_line_idx")
        if idx is not None and idx > 3:
            return False
        return True

    return has_structural_match


# ---------------------------------------------------------------------------
# Title and type extraction
# ---------------------------------------------------------------------------

def _extract_appendix_letter(text: str) -> Optional[str]:
    """Extract appendix letter from page text (e.g. 'A', 'B1')."""
    m = _APPENDIX_LETTER_RE.search(text)
    return m.group(1).upper() if m else None


def _extract_appendix_title(text: str) -> str:
    """Extract the appendix title from the cover page text.

    Looks for lines immediately following the "APPENDIX X" line,
    skipping firm names, dates, project numbers, etc.
    """
    lines = text.strip().splitlines()
    found_appendix = False
    title_parts: list[str] = []

    for line in lines:
        stripped = line.strip()
        if not stripped:
            if found_appendix and title_parts:
                break
            continue

        if _APPENDIX_LETTER_RE.search(stripped):
            found_appendix = True
            after = _APPENDIX_LETTER_RE.sub("", stripped).strip()
            if after and not _SKIP_LINE_RE.match(after):
                title_parts.append(after)
            continue

        if found_appendix:
            if _SKIP_LINE_RE.match(stripped):
                continue
            if re.match(r"^(?:\d+\s+|[-•]\s)", stripped):
                break
            title_parts.append(stripped)
            if len(title_parts) >= 2:
                break

    return " ".join(title_parts).strip()


def _classify_appendix_type(title: str, page_text: str) -> str:
    """Map an appendix title (and full page text) to a semantic type."""
    combined = f"{title}\n{page_text}"
    for type_name, pattern in _APPENDIX_TYPE_PATTERNS:
        if pattern.search(combined):
            return type_name
    return "unknown"


# ---------------------------------------------------------------------------
# Main analysis
# ---------------------------------------------------------------------------

def analyze_report_structure(
    page_texts: list[str],
    page_classifications: list[str],
    *,
    page_probs: Optional[list[dict[str, float]]] = None,
) -> ReportStructure:
    """Analyze report structure using template-based appendix cover detection.

    **Algorithm:**

    1. Collect pages the classifier predicted as ``appendix_cover_page``.
    2. Fingerprint each and build a template from those that contain
       "APPENDIX [letter]".
    3. Re-check all classifier predictions against the template — drop
       pages that don't match (false positives from the classifier).
    4. Scan remaining pages for template matches the classifier missed.
    5. Build appendix sections with page ranges and metadata.

    Args:
        page_texts: Text content for each page (0-indexed).
        page_classifications: Predicted class names (same length).
        page_probs: Optional probability dicts from the classifier.

    Returns:
        :class:`ReportStructure` with detected appendices and template info.
    """
    total = len(page_texts)
    assert len(page_classifications) == total

    # ------------------------------------------------------------------
    # Step 1: Gather seed pages for template building.
    # Two sources:
    #   a) Pages the classifier predicted as appendix_cover_page
    #   b) Sparse pages where "APPENDIX [letter]" appears prominently
    #      (catches covers the classifier missed — common with PyMuPDF
    #      text where spatial features are absent)
    # ------------------------------------------------------------------
    _MAX_SEED_WORDS = 150  # Generous limit for cover pages

    predicted_covers: list[int] = [
        i for i in range(total)
        if page_classifications[i] == "appendix_cover_page"
    ]

    # Also find high-confidence regex candidates: sparse pages where
    # "APPENDIX X" appears on its own line near the top.
    regex_candidates: list[int] = []
    for i in range(total):
        if i in predicted_covers:
            continue
        text = page_texts[i]
        if not _APPENDIX_LETTER_RE.search(text):
            continue
        wc = len(text.split())
        if wc > _MAX_SEED_WORDS:
            continue
        # Require APPENDIX on its own prominent line (starts the line)
        lines = _get_non_empty_lines(text)
        for j, ln in enumerate(lines):
            if (
                _APPENDIX_LETTER_RE.search(ln)
                and re.match(r"(?i)^\s*APPENDIX\s+", ln)
                and len(ln.split()) <= 6
            ):
                # Must not list multiple appendix letters (that's a TOC)
                all_letters = _APPENDIX_LETTER_RE.findall(text)
                if len(set(l.upper() for l in all_letters)) <= 1:
                    regex_candidates.append(i)
                break

    # Combine into seed pool
    seed_pages = sorted(set(predicted_covers) | set(regex_candidates))

    # Fingerprint all seeds
    seed_fps = {i: _extract_fingerprint(page_texts[i]) for i in seed_pages}

    # ------------------------------------------------------------------
    # Step 2: Build template from seeds that have APPENDIX keyword.
    # ------------------------------------------------------------------
    seeds_with_appendix = [
        i for i in seed_pages
        if seed_fps[i]["has_appendix"]
    ]
    template = _build_template(
        [seed_fps[i] for i in seeds_with_appendix],
        seeds_with_appendix,
    )

    # ------------------------------------------------------------------
    # Step 3: Validate seed pages against template.
    # Keep pages that either:
    #   a) Match the template (if we have one), OR
    #   b) Have APPENDIX keyword (if template couldn't be built)
    # ------------------------------------------------------------------
    confirmed_covers: list[int] = []

    if template and len(seeds_with_appendix) >= 2:
        # We have a reliable template — use it to filter all seeds
        for i in seed_pages:
            fp = seed_fps[i]
            if _matches_template(fp, template):
                confirmed_covers.append(i)

        # Also scan ALL pages for template matches the seeds missed
        confirmed_set = set(confirmed_covers)
        for i in range(total):
            if i in confirmed_set:
                continue
            if not _APPENDIX_LETTER_RE.search(page_texts[i]):
                continue
            if len(page_texts[i].split()) > template.typical_word_count[1] * 2:
                continue
            fp = _extract_fingerprint(page_texts[i])
            if _matches_template(fp, template):
                confirmed_covers.append(i)
    else:
        # Not enough data for template — trust seeds with APPENDIX keyword
        confirmed_covers = list(seeds_with_appendix)

    # Sort by page order
    confirmed_covers.sort()

    # ------------------------------------------------------------------
    # Step 5: Deduplicate consecutive same-letter pages.
    # ------------------------------------------------------------------
    deduped: list[int] = []
    for i, page_idx in enumerate(confirmed_covers):
        if i > 0 and page_idx == confirmed_covers[i - 1] + 1:
            prev_letter = _extract_appendix_letter(page_texts[confirmed_covers[i - 1]])
            curr_letter = _extract_appendix_letter(page_texts[page_idx])
            if prev_letter == curr_letter:
                continue
        deduped.append(page_idx)
    confirmed_covers = deduped

    # ------------------------------------------------------------------
    # Step 6: Build AppendixSection objects.
    # ------------------------------------------------------------------
    appendices: list[AppendixSection] = []
    for i, cover_idx in enumerate(confirmed_covers):
        letter = _extract_appendix_letter(page_texts[cover_idx])
        if letter is None:
            continue

        title = _extract_appendix_title(page_texts[cover_idx])
        semantic_type = _classify_appendix_type(title, page_texts[cover_idx])

        # Did this cover match the template?
        matched = True
        if template and len(seeds_with_appendix) >= 2:
            fp = seed_fps.get(cover_idx) or _extract_fingerprint(page_texts[cover_idx])
            matched = _matches_template(fp, template)

        # End page: one before the next cover, or last page
        if i + 1 < len(confirmed_covers):
            end_idx = confirmed_covers[i + 1] - 1
        else:
            end_idx = total - 1

        start_idx = min(cover_idx + 1, end_idx)

        type_counts: dict[str, int] = {}
        for j in range(cover_idx, end_idx + 1):
            cls = page_classifications[j]
            type_counts[cls] = type_counts.get(cls, 0) + 1

        appendices.append(AppendixSection(
            letter=letter,
            title=title,
            semantic_type=semantic_type,
            cover_page=cover_idx,
            start_page=start_idx,
            end_page=end_idx,
            page_count=end_idx - cover_idx + 1,
            matched_template=matched,
            page_types=type_counts,
        ))

    # ------------------------------------------------------------------
    # Step 7: Merge duplicate letters (sub-section headers within appendix).
    # ------------------------------------------------------------------
    merged: list[AppendixSection] = []
    seen_letters: dict[str, int] = {}
    for a in appendices:
        key = a.letter.upper()
        if key in seen_letters:
            prev = merged[seen_letters[key]]
            between = merged[seen_letters[key] + 1:]
            different_between = [x for x in between if x.letter.upper() != key]
            if not different_between:
                prev.end_page = a.end_page
                prev.page_count = prev.end_page - prev.cover_page + 1
                for cls, cnt in a.page_types.items():
                    prev.page_types[cls] = prev.page_types.get(cls, 0) + cnt
                continue
        seen_letters[key] = len(merged)
        merged.append(a)
    appendices = merged

    main_body_end = appendices[0].cover_page - 1 if appendices else total - 1

    return ReportStructure(
        total_pages=total,
        main_body_end=main_body_end,
        template=template,
        appendices=appendices,
    )
