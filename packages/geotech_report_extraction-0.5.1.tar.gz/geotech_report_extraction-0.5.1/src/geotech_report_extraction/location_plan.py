"""Boring location plan extraction using Claude vision.

Identifies boring/exploration location plan pages in geotechnical reports
and uses Claude's vision capabilities to extract boring positions, scale,
and orientation.  The result is a set of site-relative coordinates (in feet)
for each boring, which can optionally be converted to lat/long when a
project reference point is known.
"""

from __future__ import annotations

import base64
import json
import logging
import math
import re
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from geotech_report_extraction.llm_backend import LLMBackend

from geotech_report_extraction.pdf_parser import PageContent, PDFContent

logger = logging.getLogger(__name__)

# Page titles that indicate a boring location plan
_PLAN_TITLE_PATTERNS = [
    re.compile(r"(?i)(?:boring|exploration|investigation|test)\s+location\s+plan"),
    re.compile(r"(?i)(?:boring|exploration|investigation)\s+plan"),
    re.compile(r"(?i)(?:boring|borehole)\s+location\s+(?:map|diagram)"),
    re.compile(r"(?i)site\s+(?:exploration|investigation)\s+plan"),
    re.compile(r"(?i)(?:conceptual\s+)?site\s+plan"),
]

# Patterns that indicate a page is a cross-section, NOT a location plan
_CROSS_SECTION_PATTERNS = [
    re.compile(r"(?i)cross\s+section"),
    re.compile(r"(?i)geologic\s+(?:cross[- ]?section|profile)"),
    re.compile(r"(?i)subsurface\s+profile"),
    re.compile(r"(?i)soil\s+liquefaction"),
]

# Boring ID pattern used for counting IDs on a page.
# Covers standard borehole prefixes plus supplementary test locations
# (monitoring wells, CPT soundings, foundation pits) that commonly appear
# on exploration plans alongside traditional borings.
_BORING_ID_PATTERN = re.compile(
    r"\b(?:B|BH|BN|TB|GB|GC|BOR|LB|HA|TP|DCP|LDCP|MDCP|WDCP"
    r"|CS|CPT|FP|MW|WB|SB|SS)-\d+[A-Za-z]?\b"
)

_PAGE_CLASSIFICATION_PROMPT = """\
Classify this page from a geotechnical report. What type of page is this?

Answer with ONLY one of these labels:
- SITE_PLAN: A plan-view map/drawing showing boring or test locations spatially \
(bird's eye view of the site with boring markers, scale bar, north arrow)
- BORING_LOG: A detailed log of a single boring showing depth, soil types, blow counts
- CROSS_SECTION: A vertical cross-section or profile showing subsurface layers
- TABLE: A data table (lab results, summary of borings, etc.)
- NARRATIVE: Text-heavy page (report body, methodology, conclusions)
- FIGURE: Other figure, photo, or diagram (not a site plan)
- TITLE: Title page, cover page, or table of contents
- OTHER: Anything else

Answer with ONLY the label, nothing else.
"""

_PLAN_EXTRACTION_PROMPT = """\
You are a geotechnical engineer analyzing a boring location plan / \
exploration plan drawing. Your task is to identify every boring or \
test location shown on the plan and estimate its position.

For EACH boring visible on the plan, report:
1. The boring ID label (e.g., B-1, BOR-03, LDCP-4, GC-1, TP-7)
2. Its approximate horizontal position as a fraction of the image width \
(0.0 = left edge, 1.0 = right edge)
3. Its approximate vertical position as a fraction of the image height \
(0.0 = top edge, 1.0 = bottom edge)

Also identify:
- The scale bar: what real-world distance does it represent? \
Report the total length shown and the unit (feet or meters).
- North arrow: which direction does north point? Report as clock \
direction (12 = up, 3 = right, 6 = down, 9 = left) or degrees \
from vertical (0 = up/north, 90 = right/east).
- Any coordinate grid labels or survey reference points visible \
(e.g., state plane coordinates, lat/long tick marks).

Return ONLY valid JSON in this exact format:
{
  "scale": {
    "bar_length_on_image_fraction": 0.15,
    "real_world_distance": 100,
    "unit": "feet"
  },
  "north_direction_degrees": 0,
  "borings": [
    {
      "id": "B-1",
      "x_fraction": 0.35,
      "y_fraction": 0.22
    }
  ],
  "coordinate_references": [
    {
      "description": "State plane northing label",
      "value": "699450.8",
      "x_fraction": 0.0,
      "y_fraction": 0.5
    }
  ],
  "notes": "any relevant observations about the plan"
}

Important:
- Be precise with position fractions (use 2 decimal places)
- Include ALL boring/test locations visible, even partially labeled ones
- If no scale bar is visible, set scale to null
- If no north arrow is visible, set north_direction_degrees to 0 (assume north = up)
- For the scale bar, estimate what fraction of the image width it spans
- Return ONLY the JSON, no markdown fences or explanation
"""


# ---------------------------------------------------------------------------
# Signal weights for plan page confidence scoring
# ---------------------------------------------------------------------------
# Each signal contributes an additive weight (positive = more plan-like,
# negative = less plan-like).  The raw sum is clamped to [0, 1].

_W_PLAN_TITLE = 0.30          # Regex title match (strong positive)
_W_BORING_ID = 0.05           # Per distinct boring ID found
_W_BORING_ID_MAX = 0.30       # Cap on boring-ID contribution
_W_DRAWINGS_MODERATE = 0.10   # >1,000 drawing lines
_W_DRAWINGS_HIGH = 0.25       # >50,000 drawing lines (CAD export)
_W_RASTER_IMAGE = 0.15        # Embedded raster image present
_W_LOW_TEXT = 0.10             # Sparse text (<200 chars)
_W_TEXT_HEAVY_PENALTY = -0.35  # Lots of text + few lines
_W_CROSS_SECTION_PENALTY = -0.50  # Cross-section / profile indicator
_W_ELEVATION_PENALTY = -0.50  # Elevation axis label
_W_HAIKU_SITE_PLAN = 0.40     # Haiku vision classified as SITE_PLAN


def score_plan_page(page: PageContent, vision_label: Optional[str] = None) -> float:
    """Compute a plan-page confidence score for a single page.

    Combines multiple heuristic signals into a single 0–1 score.
    Higher = more likely to be a boring location plan.

    Args:
        page: Parsed page content.
        vision_label: Optional Haiku vision classification label.

    Returns:
        Confidence score clamped to [0.0, 1.0].
    """
    if page.is_boring_log:
        return 0.0

    text = page.text or ""
    text_stripped = text.strip()
    text_len = len(text_stripped)
    line_count = len(page.lines)

    score = 0.0

    # --- Positive signals ---

    # Plan title match
    has_plan_title = any(p.search(text) for p in _PLAN_TITLE_PATTERNS)
    if has_plan_title:
        score += _W_PLAN_TITLE

    # Boring ID count (capped)
    boring_ids = set(_BORING_ID_PATTERN.findall(text))
    id_contribution = min(len(boring_ids) * _W_BORING_ID, _W_BORING_ID_MAX)
    score += id_contribution

    # Drawing object count
    if line_count > 50000:
        score += _W_DRAWINGS_HIGH
    elif line_count > 1000:
        score += _W_DRAWINGS_MODERATE

    # Raster image present
    if page.image_count >= 1:
        score += _W_RASTER_IMAGE

    # Low text density (plan pages are mostly graphics)
    if text_len < 200:
        score += _W_LOW_TEXT

    # --- Negative signals ---

    # Text-heavy page (narrative / TOC)
    if text_len > 1000 and line_count < 500:
        score += _W_TEXT_HEAVY_PENALTY

    # Cross-section / profile indicators (only penalize if no plan title)
    if not has_plan_title:
        if any(p.search(text) for p in _CROSS_SECTION_PATTERNS):
            score += _W_CROSS_SECTION_PENALTY

    # Elevation axis label
    if re.search(r"(?i)elevation\s*\(feet", text):
        score += _W_ELEVATION_PENALTY

    # --- Vision signal ---
    if vision_label == "SITE_PLAN":
        score += _W_HAIKU_SITE_PLAN

    return max(0.0, min(1.0, score))


def find_plan_pages(
    pdf_content: PDFContent,
    confidence_threshold: float = 0.25,
    vision_label_map: Optional[dict[int, str]] = None,
) -> list[tuple[PageContent, float]]:
    """Find boring location plan pages in the report with confidence scores.

    Each page is scored by combining multiple heuristic signals
    (title patterns, boring ID counts, drawing density, text density,
    raster images) and an optional Haiku vision label.  Pages scoring
    above ``confidence_threshold`` are returned, sorted by confidence
    descending.

    Args:
        pdf_content: Parsed PDF content.
        confidence_threshold: Minimum score to include (default 0.25).
        vision_label_map: Optional dict mapping page_number -> Haiku
            classification label.  When provided, the SITE_PLAN label
            adds +0.40 to a page's score.

    Returns:
        List of (PageContent, confidence) tuples, sorted by confidence
        descending.  Confidence is a float in [0.0, 1.0].
    """
    if vision_label_map is None:
        vision_label_map = {}

    scored: list[tuple[PageContent, float]] = []

    for page in pdf_content.pages:
        vision_label = vision_label_map.get(page.page_number)
        conf = score_plan_page(page, vision_label=vision_label)
        if conf >= confidence_threshold:
            scored.append((page, round(conf, 3)))

    # Sort by confidence descending
    scored.sort(key=lambda x: x[1], reverse=True)

    return scored


def classify_page_vision(
    page_image_b64: str,
    api_key: Optional[str] = None,
    model: str = "claude-haiku-4-5-20251001",
    backend: Optional["LLMBackend"] = None,
) -> Optional[str]:
    """Classify a single page using vision LLM.

    Sends a low-res page thumbnail to a fast model and asks it to classify the
    page type (SITE_PLAN, BORING_LOG, CROSS_SECTION, etc.).

    Args:
        page_image_b64: Base64-encoded PNG of the page (low DPI is fine).
        api_key: Anthropic API key. Ignored when ``backend`` is provided.
        model: Model to use (default: Haiku for speed/cost). Ignored when
            ``backend`` is provided.
        backend: Optional LLMBackend instance. When provided, uses
            ``backend.classify_page()`` which routes to the classification model.

    Returns:
        Classification label string, or None on failure.
    """
    if backend is not None:
        raw = backend.classify_page(page_image_b64, _PAGE_CLASSIFICATION_PROMPT)
        if raw is None:
            return None
        label = raw.upper()
        if "SITE" in label and "PLAN" in label:
            return "SITE_PLAN"
        if label in (
            "SITE_PLAN", "BORING_LOG", "CROSS_SECTION",
            "TABLE", "NARRATIVE", "FIGURE", "TITLE", "OTHER",
        ):
            return label
        logger.debug("Unexpected classification label: %s", label)
        return label

    # Legacy path: direct Anthropic API call (backward-compatible)
    try:
        import anthropic
    except ImportError:
        return None

    client = anthropic.Anthropic(api_key=api_key)

    try:
        response = client.messages.create(
            model=model,
            max_tokens=20,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": "image/png",
                                "data": page_image_b64,
                            },
                        },
                        {
                            "type": "text",
                            "text": _PAGE_CLASSIFICATION_PROMPT,
                        },
                    ],
                }
            ],
        )

        label = response.content[0].text.strip().upper()
        # Normalize: accept slight variations
        if "SITE" in label and "PLAN" in label:
            return "SITE_PLAN"
        if label in (
            "SITE_PLAN", "BORING_LOG", "CROSS_SECTION",
            "TABLE", "NARRATIVE", "FIGURE", "TITLE", "OTHER",
        ):
            return label
        logger.debug("Unexpected classification label: %s", label)
        return label

    except Exception as e:
        logger.debug("Page classification failed: %s", e)
        return None


def classify_pages_vision(
    pdf_content: PDFContent,
    api_key: Optional[str] = None,
    model: str = "claude-haiku-4-5-20251001",
    backend: Optional["LLMBackend"] = None,
) -> dict[int, str]:
    """Classify all non-boring-log pages via vision LLM.

    Returns a mapping of page_number -> label that can be fed into
    ``find_plan_pages(vision_label_map=...)``.

    Args:
        pdf_content: Parsed PDF content.
        api_key: Anthropic API key. Ignored when ``backend`` is provided.
        model: Classification model (default: Haiku). Ignored when ``backend``
            is provided.
        backend: Optional LLMBackend instance.

    Returns:
        Dict mapping page_number -> classification label string.
    """
    import fitz

    doc = fitz.open(pdf_content.file_path)
    labels: dict[int, str] = {}

    try:
        for page_content in pdf_content.pages:
            if page_content.is_boring_log:
                continue

            fitz_page = doc[page_content.page_number - 1]
            # Low-res thumbnail: 72 DPI keeps images small (~30-80 KB)
            pix = fitz_page.get_pixmap(dpi=72)
            img_b64 = base64.b64encode(pix.tobytes("png")).decode("ascii")

            label = classify_page_vision(
                img_b64, api_key=api_key, model=model, backend=backend,
            )
            if label:
                labels[page_content.page_number] = label
                logger.debug(
                    "Page %d classified as: %s",
                    page_content.page_number, label,
                )
    finally:
        doc.close()

    return labels


def extract_boring_locations(
    plan_page_image_b64: str,
    api_key: Optional[str] = None,
    model: str = "claude-sonnet-4-20250514",
    backend: Optional["LLMBackend"] = None,
) -> Optional[dict]:
    """Use vision LLM to extract boring positions from a plan page image.

    Args:
        plan_page_image_b64: Base64-encoded PNG of the plan page.
        api_key: Anthropic API key. Ignored when ``backend`` is provided.
        model: Model to use. Ignored when ``backend`` is provided.
        backend: Optional LLMBackend instance.

    Returns:
        Parsed JSON dict with scale, north direction, and boring positions,
        or None on failure.
    """
    if backend is not None:
        return backend.vision_extract(
            plan_page_image_b64, _PLAN_EXTRACTION_PROMPT, max_tokens=4096,
        )

    # Legacy path: direct Anthropic API call (backward-compatible)
    try:
        import anthropic
    except ImportError:
        logger.error("anthropic package not installed. Install with: pip install anthropic")
        return None

    client = anthropic.Anthropic(api_key=api_key)

    try:
        response = client.messages.create(
            model=model,
            max_tokens=4096,
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": "image/png",
                                "data": plan_page_image_b64,
                            },
                        },
                        {
                            "type": "text",
                            "text": _PLAN_EXTRACTION_PROMPT,
                        },
                    ],
                }
            ],
        )

        text = response.content[0].text.strip()
        # Strip markdown code fences if present
        if text.startswith("```"):
            text = text.split("\n", 1)[1] if "\n" in text else text[3:]
        if text.endswith("```"):
            text = text[:-3]
        text = text.strip()

        return json.loads(text)

    except json.JSONDecodeError as e:
        logger.warning("Failed to parse plan extraction response as JSON: %s", e)
        return None
    except Exception as e:
        logger.error("Plan location extraction failed: %s", e)
        return None


def compute_site_coordinates(
    vision_result: dict,
    page_width_pts: float,
    page_height_pts: float,
) -> dict[str, tuple[float, float]]:
    """Convert vision-extracted boring positions to site-relative coordinates.

    Uses the scale bar and north arrow from the vision result to convert
    image-fraction positions into real-world offsets in feet.

    The coordinate system is:
    - X axis: positive = East
    - Y axis: positive = North
    - Origin: center of the plan page

    Args:
        vision_result: Output from extract_boring_locations().
        page_width_pts: Page width in PDF points (72 pts/inch).
        page_height_pts: Page height in PDF points.

    Returns:
        Dict mapping boring_id -> (easting_ft, northing_ft) relative
        to the plan center. Returns empty dict if scale is unavailable.
    """
    scale_info = vision_result.get("scale")
    if not scale_info or not scale_info.get("real_world_distance"):
        logger.warning("No scale bar detected — cannot compute coordinates")
        return {}

    # Compute the scale factor: real-world feet per image-fraction unit
    bar_fraction = scale_info.get("bar_length_on_image_fraction", 0)
    real_distance = scale_info.get("real_world_distance", 0)
    unit = scale_info.get("unit", "feet")

    if bar_fraction <= 0 or real_distance <= 0:
        logger.warning("Invalid scale bar values: fraction=%s, distance=%s",
                        bar_fraction, real_distance)
        return {}

    # Convert to feet if needed
    if unit.lower() in ("meters", "meter", "m"):
        real_distance *= 3.28084

    # Page dimensions in inches (72 pts/inch)
    page_width_in = page_width_pts / 72.0
    page_height_in = page_height_pts / 72.0

    # Scale: real-world feet per fraction of image width
    # bar_fraction is the fraction of image width the scale bar spans
    # That fraction corresponds to real_distance feet
    ft_per_x_fraction = real_distance / bar_fraction

    # Y axis: adjust for aspect ratio since fractions are of different dimensions
    ft_per_y_fraction = ft_per_x_fraction * (page_height_in / page_width_in)

    # North rotation (degrees clockwise from image-up)
    north_deg = vision_result.get("north_direction_degrees", 0) or 0
    north_rad = math.radians(north_deg)

    # Compute coordinates for each boring
    # Image fractions: (0,0) = top-left, (1,1) = bottom-right
    # We'll compute relative to image center, then rotate to true north
    coords: dict[str, tuple[float, float]] = {}

    for boring in vision_result.get("borings", []):
        boring_id = boring.get("id", "")
        x_frac = boring.get("x_fraction", 0.5)
        y_frac = boring.get("y_fraction", 0.5)

        # Offset from center in image-fraction units
        dx_frac = x_frac - 0.5
        dy_frac = -(y_frac - 0.5)  # Flip Y: image Y increases downward

        # Convert to feet (in image orientation)
        dx_ft = dx_frac * ft_per_x_fraction
        dy_ft = dy_frac * ft_per_y_fraction

        # Rotate from image space to geographic space.
        # north_deg is the clockwise angle from image-up to true north.
        # To un-rotate: apply CCW rotation by north_deg.
        easting = dx_ft * math.cos(north_rad) - dy_ft * math.sin(north_rad)
        northing = dx_ft * math.sin(north_rad) + dy_ft * math.cos(north_rad)

        coords[boring_id] = (round(easting, 1), round(northing, 1))

    return coords


def coords_to_latlong(
    site_coords: dict[str, tuple[float, float]],
    ref_lat: float,
    ref_long: float,
) -> dict[str, tuple[float, float]]:
    """Convert site-relative coordinates (ft) to lat/long.

    Uses pyproj's Azimuthal Equidistant projection for accurate
    geodetic conversion when available, falling back to a simple
    equirectangular approximation otherwise.

    Args:
        site_coords: Dict of boring_id -> (easting_ft, northing_ft)
                     from compute_site_coordinates().
        ref_lat: Latitude of the plan center (reference point).
        ref_long: Longitude of the plan center (reference point).

    Returns:
        Dict mapping boring_id -> (latitude, longitude).
    """
    from geotech_report_extraction.geo import coords_to_latlong_geodetic

    return coords_to_latlong_geodetic(site_coords, ref_lat, ref_long)


def extract_plan_coordinates(
    pdf_content: PDFContent,
    api_key: Optional[str] = None,
    model: str = "claude-sonnet-4-20250514",
    ref_lat: Optional[float] = None,
    ref_long: Optional[float] = None,
    backend: Optional["LLMBackend"] = None,
) -> dict[str, tuple[float, float]]:
    """End-to-end extraction of boring coordinates from a report's plan pages.

    Finds plan pages, sends them to the vision LLM, and computes
    site-relative coordinates. If ref_lat/ref_long are provided,
    returns lat/long; otherwise returns (easting_ft, northing_ft)
    relative to the plan center.

    Args:
        pdf_content: Parsed PDF content from read_pdf().
        api_key: Anthropic API key. Ignored when ``backend`` is provided.
        model: Model for vision extraction. Ignored when ``backend`` is provided.
        ref_lat: Optional reference latitude for the site center.
        ref_long: Optional reference longitude for the site center.
        backend: Optional LLMBackend instance.

    Returns:
        Dict mapping boring_id -> (lat, long) or (easting_ft, northing_ft).
    """
    import fitz

    # Score pages with rule-based signals only first
    scored_pages = find_plan_pages(pdf_content)

    # If no candidates above threshold and API key or backend available,
    # add vision classification signals and re-score
    if not scored_pages and (api_key or backend is not None):
        logger.info(
            "Rule-based plan detection found no candidates; "
            "adding vision classification signals"
        )
        vision_labels = classify_pages_vision(
            pdf_content, api_key=api_key, backend=backend,
        )
        scored_pages = find_plan_pages(
            pdf_content, vision_label_map=vision_labels,
        )

    if not scored_pages:
        logger.info("No boring location plan pages found")
        return {}

    # Best page = highest confidence (already sorted)
    best_page, best_conf = scored_pages[0]

    logger.info(
        "Using plan page %d for coordinate extraction (confidence=%.2f)",
        best_page.page_number, best_conf,
    )

    # Render the page to an image
    doc = fitz.open(pdf_content.file_path)
    try:
        fitz_page = doc[best_page.page_number - 1]
        pix = fitz_page.get_pixmap(dpi=200)
        img_b64 = base64.b64encode(pix.tobytes("png")).decode("ascii")
    finally:
        doc.close()

    # Extract positions via vision LLM
    vision_result = extract_boring_locations(
        img_b64, api_key=api_key, model=model, backend=backend,
    )
    if not vision_result:
        logger.warning("Vision extraction returned no results for plan page")
        return {}

    # Compute site-relative coordinates
    site_coords = compute_site_coordinates(
        vision_result,
        page_width_pts=best_page.width,
        page_height_pts=best_page.height,
    )

    if not site_coords:
        return {}

    # Convert to lat/long if reference point provided
    if ref_lat is not None and ref_long is not None:
        return coords_to_latlong(site_coords, ref_lat, ref_long)

    return site_coords
