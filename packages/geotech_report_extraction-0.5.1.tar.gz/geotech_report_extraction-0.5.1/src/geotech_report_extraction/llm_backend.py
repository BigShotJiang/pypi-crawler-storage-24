"""Pluggable LLM backend abstraction for vision-based extraction.

Supports two backends:
1. AnthropicBackend — Claude via the Anthropic API (default, existing behavior)
2. FunhouseBackend — GPT-4o/4.1 via Palantir Funhouse's fh_prompter API

All vision-calling modules (vision_extractor, lab_tests, location_plan) use
this abstraction so the same codebase works in both environments.

Usage — Anthropic (default, unchanged behavior):
    backend = AnthropicBackend(api_key="sk-...")
    result = backend.vision_extract(image_b64, prompt, max_tokens=4096)

Usage — Funhouse:
    backend = FunhouseBackend(model="gpt-4.1")
    result = backend.vision_extract(image_b64, prompt, max_tokens=4096)

Usage — pass backend through extract_report():
    from geotech_report_extraction.extract import extract_report
    from geotech_report_extraction.llm_backend import FunhouseBackend

    result = extract_report(
        "report.pdf",
        use_vision=True,
        llm_backend=FunhouseBackend(model="gpt-4.1"),
    )
"""

from __future__ import annotations

import json
import logging
from abc import ABC, abstractmethod
from typing import Optional

logger = logging.getLogger(__name__)


def _strip_json_fences(text: str) -> str:
    """Strip markdown code fences and extract JSON from LLM response text."""
    text = text.strip()
    if text.startswith("```"):
        # Remove opening fence (```json or ```)
        text = text.split("\n", 1)[1] if "\n" in text else text[3:]
    if text.endswith("```"):
        text = text[:-3]
    return text.strip()


class LLMBackend(ABC):
    """Abstract interface for vision LLM calls.

    All geotechnical extraction modules call ``vision_extract()`` to send a
    page image + prompt to the LLM and get back parsed JSON.
    """

    @abstractmethod
    def vision_extract(
        self,
        image_b64: str,
        prompt: str,
        max_tokens: int = 4096,
    ) -> Optional[dict]:
        """Send a base64-encoded PNG image and a text prompt to the LLM.

        Args:
            image_b64: Base64-encoded PNG image data.
            prompt: Text prompt describing what to extract.
            max_tokens: Maximum tokens in the response.

        Returns:
            Parsed JSON dict from the LLM response, or None on failure.
        """

    @abstractmethod
    def classify_page(
        self,
        image_b64: str,
        prompt: str,
    ) -> Optional[str]:
        """Send a page image for simple text classification (not JSON).

        Used for page-type classification (SITE_PLAN, BORING_LOG, etc.)
        where the response is a single label, not structured JSON.

        Args:
            image_b64: Base64-encoded PNG image data.
            prompt: Classification prompt.

        Returns:
            Raw text response string, or None on failure.
        """


class AnthropicBackend(LLMBackend):
    """Backend using the Anthropic Claude API (existing behavior)."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: str = "claude-sonnet-4-20250514",
        classify_model: str = "claude-haiku-4-5-20251001",
    ):
        self.api_key = api_key
        self.model = model
        self.classify_model = classify_model

    def _call(
        self,
        image_b64: str,
        prompt: str,
        max_tokens: int,
        model: Optional[str] = None,
    ) -> Optional[str]:
        """Make an Anthropic messages API call with an image."""
        try:
            import anthropic
        except ImportError:
            logger.error(
                "anthropic package not installed. "
                "Install with: pip install anthropic"
            )
            return None

        client = anthropic.Anthropic(api_key=self.api_key)
        model = model or self.model

        try:
            response = client.messages.create(
                model=model,
                max_tokens=max_tokens,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "image",
                                "source": {
                                    "type": "base64",
                                    "media_type": "image/png",
                                    "data": image_b64,
                                },
                            },
                            {
                                "type": "text",
                                "text": prompt,
                            },
                        ],
                    }
                ],
            )
            return response.content[0].text
        except Exception as e:
            logger.error("Anthropic API call failed: %s", e)
            return None

    def vision_extract(
        self,
        image_b64: str,
        prompt: str,
        max_tokens: int = 4096,
    ) -> Optional[dict]:
        text = self._call(image_b64, prompt, max_tokens)
        if text is None:
            return None
        try:
            return json.loads(_strip_json_fences(text))
        except json.JSONDecodeError as e:
            logger.warning("Failed to parse LLM response as JSON: %s", e)
            return None

    def classify_page(
        self,
        image_b64: str,
        prompt: str,
    ) -> Optional[str]:
        text = self._call(
            image_b64, prompt, max_tokens=20, model=self.classify_model,
        )
        return text.strip() if text else None


class FunhouseBackend(LLMBackend):
    """Backend using Palantir Funhouse's fh_prompter API (GPT-4o/4.1).

    This adapter translates the extraction pipeline's vision calls into
    fh_prompter calls.  The fh_prompter API uses the OpenAI chat-completion
    message format with base64 image_url content blocks.

    Typical fh_prompter usage::

        from fh_prompter import Prompter
        prompter = Prompter(model="gpt-4.1")
        response = prompter.chat(messages=[...])
        text = response.choices[0].message.content

    If your Funhouse environment uses a different API shape, override the
    ``_call`` method or adjust the message construction below.
    """

    def __init__(
        self,
        model: str = "gpt-4.1",
        classify_model: str = "gpt-4o",
        prompter: object | None = None,
    ):
        """
        Args:
            model: Model name for extraction (default: gpt-4.1).
            classify_model: Model name for page classification (default: gpt-4o).
            prompter: Pre-configured fh_prompter.Prompter instance.
                      If None, one will be created on first call.
        """
        self.model = model
        self.classify_model = classify_model
        self._prompter = prompter
        self._classify_prompter = None

    def _get_prompter(self, model: str):
        """Lazy-initialize the fh_prompter Prompter."""
        from fh_prompter import Prompter  # type: ignore[import-untyped]
        return Prompter(model=model)

    def _call(
        self,
        image_b64: str,
        prompt: str,
        max_tokens: int,
        model: Optional[str] = None,
    ) -> Optional[str]:
        """Make an fh_prompter chat call with an image.

        Uses the OpenAI-style message format that fh_prompter expects:
        a user message with an image_url content block (base64 data URI)
        plus a text content block.
        """
        model = model or self.model

        try:
            prompter = self._get_prompter(model)

            # OpenAI-style messages with base64 image
            messages = [
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/png;base64,{image_b64}",
                            },
                        },
                        {
                            "type": "text",
                            "text": prompt,
                        },
                    ],
                }
            ]

            response = prompter.chat(
                messages=messages,
                max_tokens=max_tokens,
            )

            # Extract text from OpenAI-style response
            return response.choices[0].message.content

        except ImportError:
            logger.error(
                "fh_prompter package not available. "
                "This backend requires the Palantir Funhouse environment."
            )
            return None
        except Exception as e:
            logger.error("Funhouse API call failed: %s", e)
            return None

    def vision_extract(
        self,
        image_b64: str,
        prompt: str,
        max_tokens: int = 4096,
    ) -> Optional[dict]:
        # GPT-4o/4.1 supports json_schema response format, but for
        # compatibility with the existing prompts (which say "Return ONLY
        # valid JSON"), we parse the text response the same way.
        text = self._call(image_b64, prompt, max_tokens)
        if text is None:
            return None
        try:
            return json.loads(_strip_json_fences(text))
        except json.JSONDecodeError as e:
            logger.warning("Failed to parse Funhouse response as JSON: %s", e)
            return None

    def classify_page(
        self,
        image_b64: str,
        prompt: str,
    ) -> Optional[str]:
        text = self._call(
            image_b64, prompt, max_tokens=20, model=self.classify_model,
        )
        return text.strip() if text else None


def get_default_backend(
    api_key: Optional[str] = None,
    model: str = "claude-sonnet-4-20250514",
) -> AnthropicBackend:
    """Create the default Anthropic backend (preserves existing behavior)."""
    return AnthropicBackend(api_key=api_key, model=model)
