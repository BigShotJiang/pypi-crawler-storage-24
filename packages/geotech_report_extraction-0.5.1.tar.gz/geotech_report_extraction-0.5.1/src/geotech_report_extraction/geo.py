"""Geospatial utilities for boring coordinate management.

Provides proper geodetic transformations (replacing flat-earth math),
geocoding, State Plane / UTM conversions, map visualization, geometric
analysis, and export to GIS formats (GeoJSON, Shapefile).

All heavy imports are deferred so the module loads quickly even when
optional packages are not installed.
"""

from __future__ import annotations

import logging
import math
from typing import Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Geodetic coordinate conversions  (pyproj)
# ---------------------------------------------------------------------------

def coords_to_latlong_geodetic(
    site_coords: dict[str, tuple[float, float]],
    ref_lat: float,
    ref_long: float,
) -> dict[str, tuple[float, float]]:
    """Convert site-relative coordinates (ft) to lat/long using pyproj.

    Uses a local Azimuthal Equidistant projection centred on the reference
    point so that easting/northing in feet map accurately to lat/long at
    any distance (not just < 1 mile).

    Falls back to the simple equirectangular approximation if pyproj is
    not installed.

    Args:
        site_coords: Dict of boring_id -> (easting_ft, northing_ft).
        ref_lat:  Latitude of the plan centre (reference point).
        ref_long: Longitude of the plan centre (reference point).

    Returns:
        Dict mapping boring_id -> (latitude, longitude).
    """
    try:
        from pyproj import Transformer

        # Local Azimuthal Equidistant in US survey feet
        aeqd_proj = (
            f"+proj=aeqd +lat_0={ref_lat} +lon_0={ref_long} "
            "+datum=WGS84 +units=us-ft"
        )
        transformer = Transformer.from_crs(
            aeqd_proj, "EPSG:4326", always_xy=True,
        )

        result: dict[str, tuple[float, float]] = {}
        for boring_id, (easting_ft, northing_ft) in site_coords.items():
            lon, lat = transformer.transform(easting_ft, northing_ft)
            result[boring_id] = (round(lat, 6), round(lon, 6))
        return result

    except ImportError:
        logger.debug("pyproj not installed — using flat-earth approximation")
        return _coords_to_latlong_flat(site_coords, ref_lat, ref_long)


def _coords_to_latlong_flat(
    site_coords: dict[str, tuple[float, float]],
    ref_lat: float,
    ref_long: float,
) -> dict[str, tuple[float, float]]:
    """Flat-earth fallback (original implementation)."""
    ft_per_deg_lat = 364000.0
    ft_per_deg_long = 364000.0 * math.cos(math.radians(ref_lat))
    result: dict[str, tuple[float, float]] = {}
    for boring_id, (easting_ft, northing_ft) in site_coords.items():
        lat = ref_lat + (northing_ft / ft_per_deg_lat)
        lon = ref_long + (easting_ft / ft_per_deg_long)
        result[boring_id] = (round(lat, 6), round(lon, 6))
    return result


def state_plane_to_latlong(
    easting: float,
    northing: float,
    epsg: int,
) -> tuple[float, float]:
    """Convert State Plane coordinates to WGS-84 lat/long.

    Args:
        easting:  State Plane easting (feet or metres, as EPSG dictates).
        northing: State Plane northing.
        epsg:     EPSG code for the State Plane zone
                  (e.g. 2229 = NAD83 California Zone 5, US ft).

    Returns:
        (latitude, longitude) in WGS-84.

    Raises:
        ImportError: if pyproj is not installed.
    """
    from pyproj import Transformer

    transformer = Transformer.from_crs(
        f"EPSG:{epsg}", "EPSG:4326", always_xy=True,
    )
    lon, lat = transformer.transform(easting, northing)
    return (round(lat, 6), round(lon, 6))


def latlong_to_state_plane(
    lat: float,
    lon: float,
    epsg: int,
) -> tuple[float, float]:
    """Convert WGS-84 lat/long to State Plane coordinates.

    Returns:
        (easting, northing) in the units defined by the EPSG code.
    """
    from pyproj import Transformer

    transformer = Transformer.from_crs(
        "EPSG:4326", f"EPSG:{epsg}", always_xy=True,
    )
    easting, northing = transformer.transform(lon, lat)
    return (round(easting, 2), round(northing, 2))


def latlong_to_utm(
    lat: float, lon: float,
) -> tuple[float, float, int, str]:
    """Convert WGS-84 lat/long to UTM.

    Returns:
        (easting, northing, zone_number, zone_letter).
    """
    import utm as _utm

    easting, northing, zone_num, zone_letter = _utm.from_latlon(lat, lon)
    return (round(easting, 2), round(northing, 2), zone_num, zone_letter)


def utm_to_latlong(
    easting: float,
    northing: float,
    zone_number: int,
    zone_letter: str,
) -> tuple[float, float]:
    """Convert UTM to WGS-84 lat/long.

    Returns:
        (latitude, longitude).
    """
    import utm as _utm

    lat, lon = _utm.to_latlon(easting, northing, zone_number, zone_letter)
    return (round(lat, 6), round(lon, 6))


def latlong_to_mgrs(lat: float, lon: float, precision: int = 5) -> str:
    """Convert WGS-84 lat/long to MGRS grid reference.

    Args:
        lat: Latitude in decimal degrees.
        lon: Longitude in decimal degrees.
        precision: Number of digits per coordinate (5 = 1 m accuracy).

    Returns:
        MGRS grid reference string (e.g. "18SUJ2337106519").
    """
    import mgrs as _mgrs

    m = _mgrs.MGRS()
    return m.toMGRS(lat, lon, MGRSPrecision=precision)


def mgrs_to_latlong(mgrs_string: str) -> tuple[float, float]:
    """Convert MGRS grid reference to WGS-84 lat/long."""
    import mgrs as _mgrs

    m = _mgrs.MGRS()
    lat, lon = m.toLatLon(mgrs_string)
    return (round(lat, 6), round(lon, 6))


# ---------------------------------------------------------------------------
# Geodesic distance  (geopy)
# ---------------------------------------------------------------------------

def geodesic_distance_ft(
    lat1: float, lon1: float,
    lat2: float, lon2: float,
) -> float:
    """Accurate geodesic distance between two points, in feet.

    Uses the WGS-84 ellipsoid via geopy.
    Falls back to a Haversine approximation if geopy is unavailable.
    """
    try:
        from geopy.distance import geodesic

        d = geodesic((lat1, lon1), (lat2, lon2))
        return round(d.feet, 1)

    except ImportError:
        # Haversine fallback
        R_ft = 20_902_231  # mean Earth radius in feet
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        a = (math.sin(dlat / 2) ** 2
             + math.cos(math.radians(lat1))
             * math.cos(math.radians(lat2))
             * math.sin(dlon / 2) ** 2)
        return round(R_ft * 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a)), 1)


# ---------------------------------------------------------------------------
# Geocoding  (geopy)
# ---------------------------------------------------------------------------

def geocode_address(
    address: str,
    *,
    user_agent: str = "geotech-report-extraction",
) -> Optional[tuple[float, float]]:
    """Geocode a street address or place name to (lat, long).

    Uses the free OpenStreetMap Nominatim geocoder.

    Args:
        address: Full or partial street address / place name.
        user_agent: Nominatim requires a custom user-agent string.

    Returns:
        (latitude, longitude) or None if not found.
    """
    from geopy.geocoders import Nominatim

    try:
        geo = Nominatim(user_agent=user_agent, timeout=10)
        loc = geo.geocode(address)
        if loc:
            return (round(loc.latitude, 6), round(loc.longitude, 6))
        logger.warning("Geocoding returned no results for: %s", address)
        return None
    except Exception as e:
        logger.warning("Geocoding failed for '%s': %s", address, e)
        return None


# ---------------------------------------------------------------------------
# Geometric analysis  (shapely)
# ---------------------------------------------------------------------------

def boring_convex_hull(
    coords: dict[str, tuple[float, float]],
) -> Optional[list[tuple[float, float]]]:
    """Compute the convex hull enclosing all boring locations.

    Args:
        coords: Dict of boring_id -> (lat, long) or (easting, northing).

    Returns:
        List of (x, y) vertices of the convex hull polygon,
        or None if fewer than 3 points.
    """
    from shapely.geometry import MultiPoint

    if len(coords) < 3:
        return None

    points = list(coords.values())
    hull = MultiPoint(points).convex_hull
    if hull.geom_type == "Polygon":
        return list(hull.exterior.coords)
    return None


def boring_centroid(
    coords: dict[str, tuple[float, float]],
) -> tuple[float, float]:
    """Compute the centroid (geometric centre) of all boring locations.

    Args:
        coords: Dict of boring_id -> (lat, long) or (easting, northing).

    Returns:
        (x, y) centroid coordinates.
    """
    from shapely.geometry import MultiPoint

    points = list(coords.values())
    c = MultiPoint(points).centroid
    return (round(c.x, 6), round(c.y, 6))


def point_in_boundary(
    lat: float,
    lon: float,
    boundary: list[tuple[float, float]],
) -> bool:
    """Check whether a point lies within a site boundary polygon.

    Args:
        lat: Point latitude (or easting).
        lon: Point longitude (or northing).
        boundary: List of (x, y) polygon vertices.

    Returns:
        True if point is inside the polygon.
    """
    from shapely.geometry import Point, Polygon

    return Polygon(boundary).contains(Point(lat, lon))


def site_area_acres(
    boundary: list[tuple[float, float]],
    ref_lat: Optional[float] = None,
) -> float:
    """Compute the area of a site boundary polygon in acres.

    If coordinates are in lat/long, pass ref_lat to convert properly.
    If coordinates are in feet, the result is direct.

    Args:
        boundary: List of (x, y) polygon vertices.
        ref_lat: If provided, treats coordinates as (lat, long) and
                 converts to a local projection for area computation.

    Returns:
        Area in acres.
    """
    from shapely.geometry import Polygon

    poly = Polygon(boundary)

    if ref_lat is not None:
        # Project to a local coordinate system for accurate area
        try:
            from pyproj import Transformer
            centroid = poly.centroid
            aeqd = (
                f"+proj=aeqd +lat_0={centroid.x} +lon_0={centroid.y} "
                "+datum=WGS84 +units=us-ft"
            )
            transformer = Transformer.from_crs(
                "EPSG:4326", aeqd, always_xy=True,
            )
            from shapely.ops import transform
            projected = transform(
                lambda x, y: transformer.transform(x, y), poly,
            )
            area_sqft = projected.area
        except ImportError:
            # Approximate: 1 deg lat ~ 364000 ft, 1 deg lon ~ 364000*cos(lat) ft
            # Scale lat/lon to feet and compute
            cos_lat = math.cos(math.radians(ref_lat))
            scaled_coords = [
                (x * 364000, y * 364000 * cos_lat) for x, y in boundary
            ]
            area_sqft = Polygon(scaled_coords).area
    else:
        # Assume coordinates are already in feet
        area_sqft = poly.area

    return round(area_sqft / 43560.0, 2)


# ---------------------------------------------------------------------------
# Map visualisation  (folium)
# ---------------------------------------------------------------------------

def create_boring_map(
    coords: dict[str, tuple[float, float]],
    *,
    title: str = "Boring Locations",
    zoom_start: int = 17,
    tile: str = "OpenStreetMap",
    add_satellite: bool = True,
    show_hull: bool = True,
) -> "folium.Map":
    """Create an interactive Leaflet map of boring locations.

    Args:
        coords: Dict of boring_id -> (latitude, longitude).
        title: Map title shown in the HTML page.
        zoom_start: Initial zoom level (17 = building-scale).
        tile: Base tile layer name.
        add_satellite: Add an Esri satellite imagery layer.
        show_hull: Draw a convex hull polygon around the borings.

    Returns:
        A folium.Map object.  Call ``.save("map.html")`` to export.
    """
    import folium

    if not coords:
        raise ValueError("No coordinates to map")

    # Centre on the centroid of all borings
    lats = [c[0] for c in coords.values()]
    lons = [c[1] for c in coords.values()]
    center = (sum(lats) / len(lats), sum(lons) / len(lons))

    m = folium.Map(
        location=center,
        zoom_start=zoom_start,
        tiles=tile,
    )

    # Add satellite layer
    if add_satellite:
        folium.TileLayer(
            tiles="https://server.arcgisonline.com/ArcGIS/rest/services/"
                  "World_Imagery/MapServer/tile/{z}/{y}/{x}",
            attr="Esri",
            name="Satellite",
        ).add_to(m)

    # Add boring markers
    for boring_id, (lat, lon) in coords.items():
        folium.CircleMarker(
            location=(lat, lon),
            radius=6,
            color="red",
            fill=True,
            fill_color="red",
            fill_opacity=0.7,
            popup=folium.Popup(f"<b>{boring_id}</b><br>{lat:.6f}, {lon:.6f}"),
            tooltip=boring_id,
        ).add_to(m)

    # Draw convex hull
    if show_hull and len(coords) >= 3:
        hull_verts = boring_convex_hull(coords)
        if hull_verts:
            # hull_verts are (lat, lon) tuples — folium expects [lat, lon]
            folium.Polygon(
                locations=hull_verts,
                color="blue",
                fill=True,
                fill_color="blue",
                fill_opacity=0.05,
                weight=2,
                dash_array="5",
            ).add_to(m)

    # Layer control
    folium.LayerControl().add_to(m)

    # Title
    title_html = f"""
    <div style="position:fixed; top:10px; left:60px; z-index:9999;
         background:white; padding:6px 12px; border-radius:4px;
         box-shadow:0 2px 6px rgba(0,0,0,0.3); font-family:sans-serif;">
        <b>{title}</b> — {len(coords)} borings
    </div>"""
    m.get_root().html.add_child(folium.Element(title_html))

    return m


# ---------------------------------------------------------------------------
# GIS export  (geopandas)
# ---------------------------------------------------------------------------

def to_geodataframe(
    coords: dict[str, tuple[float, float]],
    *,
    crs: str = "EPSG:4326",
    extra_fields: Optional[dict[str, dict]] = None,
) -> "geopandas.GeoDataFrame":
    """Convert boring coordinates to a GeoDataFrame.

    Args:
        coords: Dict of boring_id -> (latitude, longitude).
        crs: Coordinate reference system (default WGS-84).
        extra_fields: Optional dict of boring_id -> {field: value}
                      for attaching additional attributes per boring.

    Returns:
        A GeoDataFrame with Point geometries.
    """
    import geopandas as gpd
    from shapely.geometry import Point

    rows = []
    for boring_id, (lat, lon) in coords.items():
        row = {"boring_id": boring_id, "latitude": lat, "longitude": lon}
        if extra_fields and boring_id in extra_fields:
            row.update(extra_fields[boring_id])
        row["geometry"] = Point(lon, lat)  # GIS convention: x=lon, y=lat
        rows.append(row)

    return gpd.GeoDataFrame(rows, crs=crs)


def export_geojson(
    coords: dict[str, tuple[float, float]],
    output_path: str,
    *,
    extra_fields: Optional[dict[str, dict]] = None,
) -> str:
    """Export boring locations to a GeoJSON file.

    Returns:
        The path written.
    """
    gdf = to_geodataframe(coords, extra_fields=extra_fields)
    gdf.to_file(output_path, driver="GeoJSON")
    return output_path


def export_shapefile(
    coords: dict[str, tuple[float, float]],
    output_path: str,
    *,
    extra_fields: Optional[dict[str, dict]] = None,
) -> str:
    """Export boring locations to an Esri Shapefile.

    Returns:
        The path written (directory for .shp + sidecars).
    """
    gdf = to_geodataframe(coords, extra_fields=extra_fields)
    gdf.to_file(output_path)
    return output_path


# ---------------------------------------------------------------------------
# Basemap / static map  (contextily + matplotlib)
# ---------------------------------------------------------------------------

def plot_borings_static(
    coords: dict[str, tuple[float, float]],
    *,
    output_path: Optional[str] = None,
    title: str = "Boring Locations",
    figsize: tuple[int, int] = (12, 10),
    basemap: bool = True,
) -> "matplotlib.figure.Figure":
    """Create a static matplotlib plot with optional basemap tiles.

    Args:
        coords: Dict of boring_id -> (latitude, longitude).
        output_path: If provided, save the figure to this path.
        title: Plot title.
        figsize: Figure size in inches.
        basemap: If True, fetch contextily basemap tiles.

    Returns:
        The matplotlib Figure object.
    """
    import geopandas as gpd
    import matplotlib.pyplot as plt
    from shapely.geometry import Point

    rows = []
    for boring_id, (lat, lon) in coords.items():
        rows.append({
            "boring_id": boring_id,
            "geometry": Point(lon, lat),
        })
    gdf = gpd.GeoDataFrame(rows, crs="EPSG:4326")

    # Project to Web Mercator for basemap compatibility
    gdf_wm = gdf.to_crs(epsg=3857)

    fig, ax = plt.subplots(figsize=figsize)
    gdf_wm.plot(ax=ax, color="red", markersize=50, zorder=5)

    # Label each boring
    for _, row in gdf_wm.iterrows():
        ax.annotate(
            row["boring_id"],
            xy=(row.geometry.x, row.geometry.y),
            xytext=(5, 5),
            textcoords="offset points",
            fontsize=8,
            fontweight="bold",
        )

    if basemap:
        try:
            import contextily as cx
            cx.add_basemap(ax, source=cx.providers.Esri.WorldImagery)
        except Exception as e:
            logger.warning("Could not add basemap: %s", e)

    ax.set_title(title, fontsize=14, fontweight="bold")
    ax.set_axis_off()

    if output_path:
        fig.savefig(output_path, dpi=150, bbox_inches="tight")

    return fig


# ---------------------------------------------------------------------------
# Common EPSG codes for US State Plane zones used in geotechnical work
# ---------------------------------------------------------------------------

# Mapping of (state, zone_name) -> EPSG code for NAD83 US-ft projections.
# This is a convenience reference, not exhaustive.
STATE_PLANE_EPSG = {
    ("CA", "Zone 5"): 2229,
    ("CA", "Zone 6"): 2230,
    ("CA", "Zone 1"): 2225,
    ("CA", "Zone 2"): 2226,
    ("CA", "Zone 3"): 2227,
    ("CA", "Zone 4"): 2228,
    ("DC", ""): 2234,          # Maryland (DC uses MD State Plane)
    ("MD", ""): 2234,
    ("NH", ""): 2823,          # NAD83(HARN) NH, metres → use 3437 for ft
    ("NH", "ft"): 3437,
    ("NJ", ""): 2236,
    ("NY", "Long Island"): 2263,
    ("NY", "East"): 2260,
    ("NY", "Central"): 2261,
    ("NY", "West"): 2262,
    ("VA", "North"): 2283,
    ("VA", "South"): 2284,
    ("MA", "Mainland"): 2249,
    ("MA", "Island"): 2250,
    ("TX", "Central"): 2277,
    ("TX", "North Central"): 2276,
    ("TX", "South Central"): 2278,
    ("FL", "East"): 2236,
    ("FL", "West"): 2237,
    ("FL", "North"): 2238,
    ("PA", "North"): 2271,
    ("PA", "South"): 2272,
    ("IL", "East"): 3443,
    ("IL", "West"): 3444,
    ("GA", "East"): 2239,
    ("GA", "West"): 2240,
    ("WA", "North"): 2285,
    ("WA", "South"): 2286,
    ("OR", "North"): 2269,
    ("OR", "South"): 2270,
}


def lookup_state_plane_epsg(state: str, zone: str = "") -> Optional[int]:
    """Look up the EPSG code for a US State Plane zone.

    Args:
        state: Two-letter state abbreviation (e.g. "CA", "NH").
        zone:  Zone name (e.g. "Zone 5", "North", "Long Island").

    Returns:
        EPSG code or None if not found.
    """
    key = (state.upper(), zone)
    epsg = STATE_PLANE_EPSG.get(key)
    if epsg is None and zone:
        # Try without zone
        epsg = STATE_PLANE_EPSG.get((state.upper(), ""))
    return epsg
