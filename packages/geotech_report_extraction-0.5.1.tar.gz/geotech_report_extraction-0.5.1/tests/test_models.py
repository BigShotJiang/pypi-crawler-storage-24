"""Tests for Pydantic data models."""

from datetime import date

from geotech_report_extraction.models import (
    Borehole,
    BoreholeLog,
    DrillingDetails,
    MoistureCondition,
    Project,
    RelativeDensity,
    Sample,
    SampleType,
    SoilLayer,
    SPTBlowCounts,
    USCSClassification,
    WaterLevelObservation,
)


class TestSPTBlowCounts:
    def test_compute_n_value(self):
        spt = SPTBlowCounts(first_6in=5, second_6in=8, third_6in=12)
        assert spt.compute_n_value() == 20

    def test_compute_n_value_with_explicit(self):
        spt = SPTBlowCounts(n_value=25)
        assert spt.compute_n_value() == 25

    def test_compute_n_value_missing_counts(self):
        spt = SPTBlowCounts(first_6in=5)
        assert spt.compute_n_value() is None

    def test_refusal_flag(self):
        spt = SPTBlowCounts(first_6in=20, second_6in=30, third_6in=25, refusal=True)
        assert spt.refusal is True
        assert spt.compute_n_value() == 55


class TestSample:
    def test_split_spoon_sample(self):
        sample = Sample(
            sample_number="S-1",
            sample_type=SampleType.SPLIT_SPOON,
            depth_top_ft=5.0,
            depth_bottom_ft=6.5,
            recovery_in=12.0,
            spt=SPTBlowCounts(first_6in=3, second_6in=5, third_6in=7, n_value=12),
        )
        assert sample.sample_number == "S-1"
        assert sample.sample_type == SampleType.SPLIT_SPOON
        assert sample.spt.n_value == 12

    def test_minimal_sample(self):
        sample = Sample(depth_top_ft=10.0, depth_bottom_ft=11.5)
        assert sample.sample_number is None
        assert sample.sample_type is None
        assert sample.spt is None


class TestSoilLayer:
    def test_full_layer(self):
        layer = SoilLayer(
            depth_top_ft=0.0,
            depth_bottom_ft=5.0,
            description="Brown, moist, medium dense SAND with gravel (SP)",
            uscs_classification=USCSClassification.SP,
            color="brown",
            moisture=MoistureCondition.MOIST,
            relative_density=RelativeDensity.MEDIUM_DENSE,
        )
        assert layer.uscs_classification == USCSClassification.SP
        assert layer.color == "brown"


class TestBorehole:
    def test_borehole_creation(self):
        bh = Borehole(
            boring_id="B-1",
            depth_ft=50.0,
            elevation_ft=125.5,
            date_started=date(2024, 1, 15),
            samples=[
                Sample(depth_top_ft=0.0, depth_bottom_ft=1.5),
                Sample(depth_top_ft=5.0, depth_bottom_ft=6.5),
            ],
            soil_layers=[
                SoilLayer(depth_top_ft=0.0, depth_bottom_ft=10.0, description="FILL"),
            ],
        )
        assert bh.boring_id == "B-1"
        assert len(bh.samples) == 2
        assert len(bh.soil_layers) == 1


class TestBoreholeLog:
    def test_full_log(self):
        log = BoreholeLog(
            project=Project(name="Test Project", number="P-001", firm="Langan"),
            boreholes=[
                Borehole(boring_id="B-1", depth_ft=30.0),
                Borehole(boring_id="B-2", depth_ft=45.0),
            ],
            source_file="test_report.pdf",
        )
        assert len(log.boreholes) == 2
        assert log.project.name == "Test Project"

    def test_empty_log(self):
        log = BoreholeLog()
        assert len(log.boreholes) == 0
        assert log.source_file is None
