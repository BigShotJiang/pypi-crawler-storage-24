"""Tests for PDF parser utilities (non-PDF-dependent tests)."""

from geotech_report_extraction.pdf_parser import (
    PageContent,
    PDFContent,
    _count_blow_counts,
    _detect_firm,
    _extract_boring_id,
    _is_boring_log_page,
    group_boring_log_pages,
)


class TestBoringLogDetection:
    def test_boring_log_page(self):
        assert _is_boring_log_page("BORING LOG\nB-1\nDepth Sample Description")
        assert _is_boring_log_page("Log of Test Boring B-1")
        assert _is_boring_log_page("Record of Boring")
        assert _is_boring_log_page("SUBSURFACE EXPLORATION LOG")
        assert _is_boring_log_page("Borehole Log BH-3")

    def test_non_boring_log_page(self):
        assert not _is_boring_log_page("Table of Contents")
        assert not _is_boring_log_page("Laboratory Test Results")
        assert not _is_boring_log_page("Site Plan")


class TestCountBlowCounts:
    def test_dash_separated(self):
        assert _count_blow_counts("5-8-12") == 1
        assert _count_blow_counts("7-7-3\n46-25-21") == 2

    def test_n_value(self):
        assert _count_blow_counts("N=15") == 1
        assert _count_blow_counts("N: 20") == 1

    def test_mixed(self):
        assert _count_blow_counts("5-8-12\nN=20") == 2

    def test_excludes_slash_dates(self):
        # Slash-separated patterns like dates should NOT count
        assert _count_blow_counts("2/13/15") == 0
        assert _count_blow_counts("11/15/12") == 0

    def test_excludes_cross_line(self):
        # Axis values spanning lines should NOT count
        assert _count_blow_counts("10\n-8\n-6") == 0

    def test_excludes_date_context(self):
        # Dash-separated preceded by "Date:" should NOT count
        assert _count_blow_counts("Date: 03-17-08") == 0
        assert _count_blow_counts("Dated 01-15-20") == 0

    def test_real_blow_counts_not_excluded(self):
        # Real blow counts should still be counted
        assert _count_blow_counts("7-7-3") == 1
        assert _count_blow_counts("46-25-21") == 1
        assert _count_blow_counts("25-18-7") == 1

    def test_empty(self):
        assert _count_blow_counts("") == 0
        assert _count_blow_counts("No blow counts here") == 0


class TestBoringIdExtraction:
    def test_extract_b_pattern(self):
        assert _extract_boring_id("Boring No. B-1") == "B-1"
        assert _extract_boring_id("Boring No.: B-2") == "B-2"

    def test_extract_bh_pattern(self):
        assert _extract_boring_id("Borehole No. BH-3") == "BH-3"

    def test_extract_bn_pattern(self):
        assert _extract_boring_id("BORING LOG NO. BN-3") == "BN-3"
        assert _extract_boring_id("Boring Log No BN-5") == "BN-5"

    def test_extract_standalone(self):
        assert _extract_boring_id("Some text B-5 more text") == "B-5"
        assert _extract_boring_id("Data for BH-10") == "BH-10"
        assert _extract_boring_id("Test boring TB-1") == "TB-1"

    def test_no_boring_id(self):
        assert _extract_boring_id("No boring identifier here") is None

    def test_drill_rig_excluded(self):
        # "B-61" preceded by "Drill Rig:" should be skipped
        text = "Drill Rig: B-61\nBoring Started: 1/18/2016\nBORING LOG NO. BN-3"
        assert _extract_boring_id(text) == "BN-3"


class TestFirmDetection:
    def test_detect_langan(self):
        assert _detect_firm("Report by Langan Engineering") == "langan"
        assert _detect_firm("LANGAN") == "langan"

    def test_detect_schnabel(self):
        assert _detect_firm("Schnabel Engineering report") == "schnabel"
        assert _detect_firm("SCHNABEL ENGINEERING") == "schnabel"

    def test_detect_terracon(self):
        assert _detect_firm("Terracon Consultants") == "terracon"

    def test_detect_geoengineers(self):
        assert _detect_firm("GeoEngineers, Inc.") == "geoengineers"

    def test_no_firm(self):
        assert _detect_firm("Generic report text") is None


class TestGroupBoringLogPages:
    def test_single_boring(self):
        pdf = PDFContent(file_path="test.pdf", pages=[
            PageContent(page_number=1, text="intro", is_boring_log=False),
            PageContent(page_number=2, text="Boring Log B-1", is_boring_log=True, boring_id="B-1"),
            PageContent(page_number=3, text="appendix", is_boring_log=False),
        ])
        groups = group_boring_log_pages(pdf)
        assert "B-1" in groups
        assert len(groups["B-1"]) == 1

    def test_multiple_borings(self):
        pdf = PDFContent(file_path="test.pdf", pages=[
            PageContent(page_number=1, text="B-1 log", is_boring_log=True, boring_id="B-1"),
            PageContent(page_number=2, text="B-2 log", is_boring_log=True, boring_id="B-2"),
            PageContent(page_number=3, text="B-3 log", is_boring_log=True, boring_id="B-3"),
        ])
        groups = group_boring_log_pages(pdf)
        assert len(groups) == 3

    def test_multi_page_boring(self):
        pdf = PDFContent(file_path="test.pdf", pages=[
            PageContent(page_number=1, text="B-1 p1", is_boring_log=True, boring_id="B-1"),
            PageContent(page_number=2, text="B-1 p2", is_boring_log=True, boring_id="B-1"),
            PageContent(page_number=3, text="B-2 p1", is_boring_log=True, boring_id="B-2"),
        ])
        groups = group_boring_log_pages(pdf)
        assert len(groups["B-1"]) == 2
        assert len(groups["B-2"]) == 1

    def test_continuation_page_no_id(self):
        pdf = PDFContent(file_path="test.pdf", pages=[
            PageContent(page_number=1, text="B-1", is_boring_log=True, boring_id="B-1"),
            PageContent(page_number=2, text="continued", is_boring_log=True, boring_id=None),
        ])
        groups = group_boring_log_pages(pdf)
        assert len(groups["B-1"]) == 2

    def test_no_boring_logs(self):
        pdf = PDFContent(file_path="test.pdf", pages=[
            PageContent(page_number=1, text="intro", is_boring_log=False),
        ])
        groups = group_boring_log_pages(pdf)
        assert len(groups) == 0

    def test_boring_log_pages_property(self):
        pdf = PDFContent(file_path="test.pdf", pages=[
            PageContent(page_number=1, text="intro", is_boring_log=False),
            PageContent(page_number=2, text="boring", is_boring_log=True, boring_id="B-1"),
            PageContent(page_number=3, text="other", is_boring_log=False),
            PageContent(page_number=4, text="boring", is_boring_log=True, boring_id="B-2"),
        ])
        assert len(pdf.boring_log_pages) == 2
