"""Tests for Stage 3b: flattened samples, soil layers, water levels."""

from datetime import date

import pandas as pd
import pytest

from geotech_report_extraction.foundry import (
    SAMPLE_COLUMNS,
    SOIL_LAYER_COLUMNS,
    WATER_LEVEL_COLUMNS,
    _report_id,
    process_report_samples,
    process_report_soil_layers,
    process_report_water_levels,
)


def _make_pages_df() -> pd.DataFrame:
    """Create a minimal pages DataFrame with known boring log content."""
    # Simulate a Schnabel boring log page with identifiable content
    page_text = (
        "SCHNABEL ENGINEERING\n"
        "LOG OF BORING B-1\n"
        "Project: Test Project  Project No: P-001\n"
        "Location: Test Site\n"
        "Elevation: 125.5 ft  Total Depth: 30.0 ft\n"
        "Date Started: 01/15/2024  Date Completed: 01/16/2024\n\n"
        "DEPTH  SAMPLE  BLOWS  DESCRIPTION\n"
        " 5.0   S-1     3/5/7  Brown SAND, fine to medium, moist\n"
        "                      N=12\n"
        "10.0   S-2     5/8/10 Gray CLAY, stiff\n"
        "                      N=18\n"
        "WATER LEVEL\n"
        "Encountered at 12.0 ft during drilling\n"
        "Stabilized at 8.5 ft on 01/16/2024\n"
    )
    return pd.DataFrame([{
        "source_file": "test_report.json",
        "page_number": 1,
        "page_text": page_text,
        "page_width": 8.5,
        "page_height": 11.0,
        "word_count": 50,
        "has_tables": False,
        "words_json": "[]",
    }])


class TestReportId:
    def test_deterministic(self):
        assert _report_id("foo.json") == _report_id("foo.json")

    def test_different_files(self):
        assert _report_id("a.json") != _report_id("b.json")

    def test_length(self):
        assert len(_report_id("test.json")) == 16


class TestSampleColumns:
    def test_columns_defined(self):
        assert "report_id" in SAMPLE_COLUMNS
        assert "boring_id" in SAMPLE_COLUMNS
        assert "spt_n_value" in SAMPLE_COLUMNS
        assert "depth_top_ft" in SAMPLE_COLUMNS

    def test_empty_input(self):
        df = process_report_samples(pd.DataFrame())
        assert list(df.columns) == SAMPLE_COLUMNS
        assert len(df) == 0


class TestSoilLayerColumns:
    def test_columns_defined(self):
        assert "report_id" in SOIL_LAYER_COLUMNS
        assert "description" in SOIL_LAYER_COLUMNS
        assert "uscs_classification" in SOIL_LAYER_COLUMNS

    def test_empty_input(self):
        df = process_report_soil_layers(pd.DataFrame())
        assert list(df.columns) == SOIL_LAYER_COLUMNS
        assert len(df) == 0


class TestWaterLevelColumns:
    def test_columns_defined(self):
        assert "report_id" in WATER_LEVEL_COLUMNS
        assert "depth_ft" in WATER_LEVEL_COLUMNS
        assert "is_stabilized" in WATER_LEVEL_COLUMNS

    def test_empty_input(self):
        df = process_report_water_levels(pd.DataFrame())
        assert list(df.columns) == WATER_LEVEL_COLUMNS
        assert len(df) == 0


class TestFlattenOnRealDI:
    """Integration tests using Banjul DI file (Schnabel, 4 borings)."""

    DI_PATH = "sample_reports/Reports_DI/DI_data_2023_0310_Banjul_TDD_Geotech_Report.json"

    @pytest.fixture(autouse=True)
    def _check_file(self):
        import os
        if not os.path.exists(self.DI_PATH):
            pytest.skip("Banjul DI file not available")

    def _get_extraction_df(self):
        """Get the Stage 3 extraction to compare counts."""
        from geotech_report_extraction.foundry import process_di_json_to_extraction
        return process_di_json_to_extraction(self.DI_PATH, "banjul.json")

    def test_samples_flat(self):
        from geotech_report_extraction.foundry import process_di_json_to_samples
        samples_df = process_di_json_to_samples(self.DI_PATH, "banjul.json")

        assert len(samples_df) > 0
        assert "report_id" in samples_df.columns
        assert samples_df["report_id"].nunique() == 1

        # Compare against Stage 3 aggregate
        extraction_df = self._get_extraction_df()
        total_samples_stage3 = extraction_df["num_samples"].sum()
        assert len(samples_df) == total_samples_stage3

        # Check all borings present
        extraction_borings = set(extraction_df["boring_id"])
        sample_borings = set(samples_df["boring_id"])
        # Sample borings should be a subset (borings with 0 samples won't appear)
        assert sample_borings <= extraction_borings

    def test_soil_layers_flat(self):
        from geotech_report_extraction.foundry import process_di_json_to_soil_layers
        layers_df = process_di_json_to_soil_layers(self.DI_PATH, "banjul.json")

        assert len(layers_df) > 0
        assert "report_id" in layers_df.columns

        extraction_df = self._get_extraction_df()
        total_layers_stage3 = extraction_df["num_soil_layers"].sum()
        assert len(layers_df) == total_layers_stage3

    def test_water_levels_flat(self):
        from geotech_report_extraction.foundry import process_di_json_to_water_levels
        wl_df = process_di_json_to_water_levels(self.DI_PATH, "banjul.json")

        assert "report_id" in wl_df.columns

        extraction_df = self._get_extraction_df()
        total_wl_stage3 = extraction_df["num_water_levels"].sum()
        assert len(wl_df) == total_wl_stage3

    def test_report_id_consistent(self):
        from geotech_report_extraction.foundry import (
            process_di_json_to_samples,
            process_di_json_to_soil_layers,
            process_di_json_to_water_levels,
        )
        samples = process_di_json_to_samples(self.DI_PATH, "banjul.json")
        layers = process_di_json_to_soil_layers(self.DI_PATH, "banjul.json")
        wl = process_di_json_to_water_levels(self.DI_PATH, "banjul.json")

        # All should have the same report_id
        rid = samples["report_id"].iloc[0]
        assert layers["report_id"].iloc[0] == rid
        if len(wl) > 0:
            assert wl["report_id"].iloc[0] == rid
