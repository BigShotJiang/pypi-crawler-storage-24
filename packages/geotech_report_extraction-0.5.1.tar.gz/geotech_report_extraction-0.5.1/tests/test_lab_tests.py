"""Tests for lab test page detection, plot digitization, and result parsing."""

from geotech_report_extraction.lab_tests import (
    AtterbergResult,
    ConsolidationResult,
    GrainSizeResult,
    LabTestResult,
    LabTestType,
    MoistureDensityResult,
    StrengthTestResult,
    XYDataPoint,
    XYSeries,
    detect_lab_test_type,
    find_lab_test_pages,
    parse_atterberg,
    parse_consolidation,
    parse_grain_size,
    parse_moisture_density,
    parse_strength_test,
    vision_result_to_lab_test,
)
from geotech_report_extraction.pdf_parser import PDFContent, PageContent


def _make_page(page_number, text="", is_boring_log=False, lines=0,
               image_count=0):
    page = PageContent(
        page_number=page_number,
        text=text,
        is_boring_log=is_boring_log,
        lines=[{"x0": 0, "y0": 0, "x1": 1, "y1": 1}] * lines,
    )
    page.image_count = image_count
    return page


# ---------------------------------------------------------------------------
# detect_lab_test_type
# ---------------------------------------------------------------------------

class TestDetectLabTestType:
    def test_consolidation(self):
        assert detect_lab_test_type("CONSOLIDATION TEST RESULTS") == LabTestType.CONSOLIDATION

    def test_consolidation_e_log_p(self):
        assert detect_lab_test_type("e vs. log p curve") == LabTestType.CONSOLIDATION

    def test_consolidation_void_ratio(self):
        assert detect_lab_test_type("Void Ratio vs. Log Pressure") == LabTestType.CONSOLIDATION

    def test_oedometer(self):
        assert detect_lab_test_type("OEDOMETER TEST") == LabTestType.CONSOLIDATION

    def test_swell_consolidation(self):
        assert detect_lab_test_type("SWELL-CONSOLIDATION TEST") == LabTestType.CONSOLIDATION

    def test_grain_size(self):
        assert detect_lab_test_type("GRAIN SIZE DISTRIBUTION") == LabTestType.GRAIN_SIZE

    def test_sieve_analysis(self):
        assert detect_lab_test_type("SIEVE ANALYSIS RESULTS") == LabTestType.GRAIN_SIZE

    def test_particle_size(self):
        assert detect_lab_test_type("PARTICLE SIZE ANALYSIS") == LabTestType.GRAIN_SIZE

    def test_hydrometer(self):
        assert detect_lab_test_type("HYDROMETER ANALYSIS") == LabTestType.GRAIN_SIZE

    def test_atterberg(self):
        assert detect_lab_test_type("ATTERBERG LIMITS RESULTS") == LabTestType.ATTERBERG_LIMITS

    def test_plasticity_chart(self):
        assert detect_lab_test_type("PLASTICITY CHART") == LabTestType.ATTERBERG_LIMITS

    def test_triaxial_uu(self):
        assert detect_lab_test_type("TRIAXIAL COMPRESSION TEST") == LabTestType.TRIAXIAL_UU

    def test_triaxial_cu(self):
        assert detect_lab_test_type("CU TRIAXIAL TEST") == LabTestType.TRIAXIAL_CU

    def test_unconsolidated_undrained(self):
        assert detect_lab_test_type("UNCONSOLIDATED-UNDRAINED") == LabTestType.TRIAXIAL_UU

    def test_consolidated_undrained(self):
        assert detect_lab_test_type("CONSOLIDATED-UNDRAINED") == LabTestType.TRIAXIAL_CU

    def test_unconfined_compression(self):
        assert detect_lab_test_type("UNCONFINED COMPRESSIVE STRENGTH TEST") == LabTestType.UNCONFINED_COMPRESSION

    def test_direct_shear(self):
        assert detect_lab_test_type("DIRECT SHEAR TEST RESULTS") == LabTestType.DIRECT_SHEAR

    def test_proctor(self):
        assert detect_lab_test_type("STANDARD PROCTOR TEST") == LabTestType.MOISTURE_DENSITY

    def test_moisture_density(self):
        assert detect_lab_test_type("MOISTURE-DENSITY RELATIONSHIP") == LabTestType.MOISTURE_DENSITY

    def test_cbr(self):
        assert detect_lab_test_type("CBR TEST RESULTS") == LabTestType.CBR

    def test_california_bearing(self):
        assert detect_lab_test_type("CALIFORNIA BEARING RATIO TEST") == LabTestType.CBR

    def test_permeability(self):
        assert detect_lab_test_type("PERMEABILITY TEST") == LabTestType.PERMEABILITY

    def test_expansion_index(self):
        assert detect_lab_test_type("EXPANSION INDEX TEST") == LabTestType.EXPANSION_INDEX

    def test_r_value(self):
        assert detect_lab_test_type("R-VALUE TEST RESULTS") == LabTestType.R_VALUE

    def test_corrosion(self):
        assert detect_lab_test_type("CORROSION TEST RESULTS") == LabTestType.CORROSION

    def test_ph(self):
        assert detect_lab_test_type("pH TEST RESULTS") == LabTestType.CORROSION

    def test_resistivity(self):
        assert detect_lab_test_type("RESISTIVITY TEST REPORT") == LabTestType.CORROSION

    def test_no_match(self):
        assert detect_lab_test_type("Some random text about the project.") is None

    def test_boring_log_not_matched(self):
        assert detect_lab_test_type("BORING LOG B-1\n5-8-12") is None


# ---------------------------------------------------------------------------
# find_lab_test_pages
# ---------------------------------------------------------------------------

class TestFindLabTestPages:
    def test_finds_consolidation_page(self):
        page = _make_page(
            15, text="CONSOLIDATION TEST\nB-1 Depth: 10 ft\nVoid Ratio",
            lines=200, image_count=1,
        )
        pdf = PDFContent(file_path="test.pdf", pages=[page])
        results = find_lab_test_pages(pdf)
        assert len(results) == 1
        assert results[0][0].page_number == 15
        assert results[0][1] == LabTestType.CONSOLIDATION
        assert results[0][2] >= 0.5

    def test_finds_grain_size_page(self):
        page = _make_page(
            20, text="GRAIN SIZE DISTRIBUTION\nB-3 Sample at 25 ft\nPercent Passing",
            lines=300,
        )
        pdf = PDFContent(file_path="test.pdf", pages=[page])
        results = find_lab_test_pages(pdf)
        assert len(results) == 1
        assert results[0][1] == LabTestType.GRAIN_SIZE

    def test_skips_boring_log_pages(self):
        page = _make_page(
            5, text="CONSOLIDATION TEST\nB-1",
            is_boring_log=True, lines=500,
        )
        pdf = PDFContent(file_path="test.pdf", pages=[page])
        assert len(find_lab_test_pages(pdf)) == 0

    def test_skips_narrative_pages(self):
        page = _make_page(
            3, text="The site consists of clay. No lab tests were performed.",
            lines=10,
        )
        pdf = PDFContent(file_path="test.pdf", pages=[page])
        assert len(find_lab_test_pages(pdf)) == 0

    def test_multiple_lab_pages(self):
        consol = _make_page(
            15, text="CONSOLIDATION TEST\nVoid Ratio vs Pressure",
            lines=200,
        )
        grain = _make_page(
            18, text="SIEVE ANALYSIS\nPercent Passing",
            lines=200,
        )
        triax = _make_page(
            22, text="TRIAXIAL TEST\nStress vs Strain",
            lines=200,
        )
        pdf = PDFContent(file_path="test.pdf", pages=[consol, grain, triax])
        results = find_lab_test_pages(pdf)
        assert len(results) == 3
        types = {r[1] for r in results}
        assert LabTestType.CONSOLIDATION in types
        assert LabTestType.GRAIN_SIZE in types
        assert LabTestType.TRIAXIAL_UU in types

    def test_higher_confidence_with_more_signals(self):
        """Page with more signals should score higher."""
        minimal = _make_page(10, text="CONSOLIDATION TEST")
        rich = _make_page(
            11,
            text="CONSOLIDATION TEST\nB-1 Depth: 10 ft\nVoid Ratio vs Pressure",
            lines=300, image_count=1,
        )
        pdf = PDFContent(file_path="test.pdf", pages=[minimal, rich])
        results = find_lab_test_pages(pdf)
        assert len(results) == 2
        # Rich page should score higher
        rich_result = [r for r in results if r[0].page_number == 11][0]
        minimal_result = [r for r in results if r[0].page_number == 10][0]
        assert rich_result[2] > minimal_result[2]


# ---------------------------------------------------------------------------
# parse_consolidation
# ---------------------------------------------------------------------------

class TestParseConsolidation:
    def test_basic_consolidation(self):
        raw = {
            "test_type": "consolidation",
            "boring_id": "B-1",
            "sample_depth_ft": 12.5,
            "soil_description": "Gray silty CLAY (CL)",
            "data_series": [
                {
                    "label": "Loading",
                    "points": [
                        {"x": 0.1, "y": 0.85},
                        {"x": 0.5, "y": 0.82},
                        {"x": 1.0, "y": 0.78},
                        {"x": 2.0, "y": 0.70},
                        {"x": 4.0, "y": 0.58},
                    ],
                }
            ],
            "derived_parameters": {
                "values": {
                    "e0": 0.85,
                    "Pc": 1.2,
                    "Cc": 0.35,
                    "Cr": 0.05,
                }
            },
        }
        result = parse_consolidation(raw)
        assert result.boring_id == "B-1"
        assert result.sample_depth_ft == 12.5
        assert result.initial_void_ratio == 0.85
        assert result.preconsolidation_pressure_tsf == 1.2
        assert result.compression_index_cc == 0.35
        assert result.recompression_index_cr == 0.05
        assert result.e_log_p_curve is not None
        assert len(result.e_log_p_curve.points) == 5
        assert result.e_log_p_curve.points[0].x == 0.1
        assert result.e_log_p_curve.points[0].y == 0.85

    def test_empty_derived_params(self):
        raw = {
            "boring_id": "B-2",
            "data_series": [],
            "derived_parameters": {"values": {}},
        }
        result = parse_consolidation(raw)
        assert result.boring_id == "B-2"
        assert result.compression_index_cc is None
        assert result.e_log_p_curve is None


# ---------------------------------------------------------------------------
# parse_grain_size
# ---------------------------------------------------------------------------

class TestParseGrainSize:
    def test_basic_grain_size(self):
        raw = {
            "boring_id": "B-3",
            "sample_depth_ft": 8.0,
            "soil_description": "Brown SAND with gravel (SW)",
            "data_series": [
                {
                    "label": "B-3 @ 8 ft",
                    "points": [
                        {"x": 75.0, "y": 100.0},
                        {"x": 25.0, "y": 95.0},
                        {"x": 4.75, "y": 82.0},
                        {"x": 2.0, "y": 68.0},
                        {"x": 0.425, "y": 35.0},
                        {"x": 0.075, "y": 8.0},
                    ],
                }
            ],
            "derived_parameters": {
                "values": {
                    "D10": 0.12,
                    "D60": 2.5,
                    "Cu": 20.8,
                    "percent_gravel": 18.0,
                    "percent_sand": 74.0,
                    "percent_fines": 8.0,
                }
            },
        }
        result = parse_grain_size(raw)
        assert result.boring_id == "B-3"
        assert result.d10_mm == 0.12
        assert result.d60_mm == 2.5
        assert result.cu == 20.8
        assert result.percent_gravel == 18.0
        assert result.percent_fines == 8.0
        assert result.gradation_curve is not None
        assert len(result.gradation_curve.points) == 6


# ---------------------------------------------------------------------------
# parse_atterberg
# ---------------------------------------------------------------------------

class TestParseAtterberg:
    def test_basic_atterberg(self):
        raw = {
            "boring_id": "B-1",
            "sample_depth_ft": 5.0,
            "data_series": [
                {
                    "label": "Flow curve",
                    "points": [
                        {"x": 15, "y": 38.2},
                        {"x": 20, "y": 36.1},
                        {"x": 25, "y": 34.5},
                        {"x": 30, "y": 33.0},
                    ],
                }
            ],
            "derived_parameters": {
                "values": {
                    "LL": 34,
                    "PL": 18,
                    "PI": 16,
                    "USCS": "CL",
                }
            },
        }
        result = parse_atterberg(raw)
        assert result.liquid_limit == 34
        assert result.plastic_limit == 18
        assert result.plasticity_index == 16
        assert result.uscs_classification == "CL"
        assert result.flow_curve is not None


# ---------------------------------------------------------------------------
# parse_strength_test
# ---------------------------------------------------------------------------

class TestParseStrengthTest:
    def test_triaxial_uu(self):
        raw = {
            "test_type": "triaxial_uu",
            "boring_id": "B-2",
            "sample_depth_ft": 15.0,
            "data_series": [
                {
                    "label": "Stress-Strain",
                    "points": [
                        {"x": 0, "y": 0},
                        {"x": 2, "y": 1200},
                        {"x": 5, "y": 2100},
                        {"x": 10, "y": 2400},
                        {"x": 15, "y": 2350},
                    ],
                }
            ],
            "derived_parameters": {
                "values": {
                    "su": 1200,
                    "phi": 0,
                    "strain_at_failure": 10.0,
                }
            },
        }
        result = parse_strength_test(raw)
        assert result.test_type == "UU"
        assert result.undrained_shear_strength_psf == 1200
        assert result.friction_angle_deg == 0
        assert result.stress_strain_curve is not None
        assert len(result.stress_strain_curve.points) == 5

    def test_direct_shear(self):
        raw = {
            "test_type": "direct_shear",
            "boring_id": "B-4",
            "data_series": [],
            "derived_parameters": {
                "values": {
                    "phi": 32,
                    "cohesion": 50,
                }
            },
        }
        result = parse_strength_test(raw)
        assert result.test_type == "DS"
        assert result.friction_angle_deg == 32
        assert result.cohesion_psf == 50

    def test_unconfined_compression(self):
        raw = {
            "test_type": "unconfined_compression",
            "data_series": [
                {
                    "label": "Stress vs Strain",
                    "points": [{"x": 0, "y": 0}, {"x": 5, "y": 3000}],
                }
            ],
            "derived_parameters": {
                "values": {
                    "peak_deviator_stress": 3000,
                }
            },
        }
        result = parse_strength_test(raw)
        assert result.test_type == "UC"
        assert result.peak_deviator_stress_psf == 3000

    def test_mohr_circle_data(self):
        raw = {
            "test_type": "triaxial_cu",
            "boring_id": "B-5",
            "data_series": [
                {
                    "label": "Stress-Strain Specimen 1",
                    "points": [{"x": 0, "y": 0}, {"x": 5, "y": 2000}],
                },
                {
                    "label": "Mohr Circle 1",
                    "points": [{"x": 500, "y": 0}, {"x": 1500, "y": 500}],
                },
            ],
            "derived_parameters": {"values": {"phi": 28, "c": 200}},
        }
        result = parse_strength_test(raw)
        assert result.test_type == "CU"
        assert result.stress_strain_curve is not None
        assert result.mohr_circle_data is not None
        assert len(result.mohr_circle_data) == 1


# ---------------------------------------------------------------------------
# parse_moisture_density
# ---------------------------------------------------------------------------

class TestParseMoistureDensity:
    def test_proctor(self):
        raw = {
            "boring_id": "B-1",
            "data_series": [
                {
                    "label": "Compaction Curve",
                    "points": [
                        {"x": 8, "y": 108},
                        {"x": 10, "y": 112},
                        {"x": 12, "y": 115},
                        {"x": 14, "y": 114},
                        {"x": 16, "y": 111},
                    ],
                }
            ],
            "derived_parameters": {
                "values": {
                    "method": "Standard Proctor",
                    "optimum_moisture": 12.0,
                    "max_dry_density": 115.0,
                }
            },
        }
        result = parse_moisture_density(raw)
        assert result.test_method == "Standard Proctor"
        assert result.optimum_moisture_pct == 12.0
        assert result.max_dry_density_pcf == 115.0
        assert result.compaction_curve is not None
        assert len(result.compaction_curve.points) == 5


# ---------------------------------------------------------------------------
# vision_result_to_lab_test
# ---------------------------------------------------------------------------

class TestVisionResultToLabTest:
    def test_consolidation_dispatch(self):
        raw = {
            "test_type": "consolidation",
            "boring_id": "B-1",
            "sample_depth_ft": 10.0,
            "data_series": [{"label": "Loading", "points": [{"x": 1, "y": 0.8}]}],
            "derived_parameters": {"values": {"Cc": 0.3}},
        }
        result = vision_result_to_lab_test(raw, page_number=15)
        assert result.test_type == LabTestType.CONSOLIDATION
        assert result.page_number == 15
        assert result.consolidation is not None
        assert result.consolidation.compression_index_cc == 0.3

    def test_grain_size_dispatch(self):
        raw = {
            "test_type": "grain_size",
            "boring_id": "B-3",
            "data_series": [{"label": "curve", "points": [{"x": 1.0, "y": 50}]}],
            "derived_parameters": {"values": {"percent_fines": 12}},
        }
        result = vision_result_to_lab_test(raw, page_number=20)
        assert result.grain_size is not None
        assert result.grain_size.percent_fines == 12

    def test_atterberg_dispatch(self):
        raw = {
            "test_type": "atterberg_limits",
            "data_series": [],
            "derived_parameters": {"values": {"LL": 45, "PL": 22, "PI": 23}},
        }
        result = vision_result_to_lab_test(raw, page_number=25)
        assert result.atterberg is not None
        assert result.atterberg.liquid_limit == 45

    def test_triaxial_dispatch(self):
        raw = {
            "test_type": "triaxial_uu",
            "data_series": [],
            "derived_parameters": {"values": {"su": 1500}},
        }
        result = vision_result_to_lab_test(raw, page_number=30)
        assert result.strength is not None
        assert result.strength.undrained_shear_strength_psf == 1500

    def test_unknown_type_stores_raw(self):
        raw = {
            "test_type": "cbr",
            "boring_id": "B-1",
            "data_series": [{"label": "CBR", "points": [{"x": 0.1, "y": 5}]}],
            "derived_parameters": {"values": {"CBR_value": 5}},
        }
        result = vision_result_to_lab_test(raw, page_number=35)
        assert result.raw_plot_data is not None
        assert result.raw_plot_data["test_type"] == "cbr"

    def test_direct_shear_dispatch(self):
        raw = {
            "test_type": "direct_shear",
            "data_series": [],
            "derived_parameters": {"values": {"phi": 30}},
        }
        result = vision_result_to_lab_test(raw, page_number=40)
        assert result.strength is not None
        assert result.strength.test_type == "DS"

    def test_moisture_density_dispatch(self):
        raw = {
            "test_type": "moisture_density",
            "data_series": [{"label": "curve", "points": [{"x": 12, "y": 115}]}],
            "derived_parameters": {"values": {"OMC": 12, "MDD": 115}},
        }
        result = vision_result_to_lab_test(raw, page_number=45)
        assert result.moisture_density is not None
        assert result.moisture_density.optimum_moisture_pct == 12


# ---------------------------------------------------------------------------
# XY data models
# ---------------------------------------------------------------------------

class TestXYModels:
    def test_xy_data_point(self):
        pt = XYDataPoint(x=1.5, y=0.82)
        assert pt.x == 1.5
        assert pt.y == 0.82

    def test_xy_series(self):
        series = XYSeries(
            label="Loading",
            points=[
                XYDataPoint(x=0.1, y=0.85),
                XYDataPoint(x=1.0, y=0.78),
            ],
        )
        assert series.label == "Loading"
        assert len(series.points) == 2

    def test_empty_series(self):
        series = XYSeries()
        assert series.label is None
        assert series.points == []
