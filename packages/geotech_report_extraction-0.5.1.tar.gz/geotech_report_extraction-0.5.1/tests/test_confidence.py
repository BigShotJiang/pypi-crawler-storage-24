"""Tests for confidence scoring."""

from geotech_report_extraction.confidence import score_borehole, score_sample
from geotech_report_extraction.models import (
    Borehole,
    ConfidenceLevel,
    Sample,
    SampleType,
    SPTBlowCounts,
)


class TestSampleConfidence:
    def test_high_confidence_complete_sample(self):
        """Complete SPT sample with plausible values should be high confidence."""
        sample = Sample(
            sample_number="S-1",
            sample_type=SampleType.SPLIT_SPOON,
            depth_top_ft=5.0,
            depth_bottom_ft=6.5,
            spt=SPTBlowCounts(
                first_6in=5, second_6in=8, third_6in=12, n_value=20,
            ),
        )
        conf = score_sample(sample, boring_depth=50.0)
        assert conf.level == ConfidenceLevel.HIGH
        assert conf.score >= 0.75
        assert "spt_complete_3part" in conf.checks
        assert "n_value_consistent" in conf.checks

    def test_medium_confidence_n_value_only(self):
        """Sample with only N-value (no individual blows) should be medium."""
        sample = Sample(
            depth_top_ft=10.0,
            depth_bottom_ft=11.5,
            spt=SPTBlowCounts(n_value=25),
        )
        conf = score_sample(sample, boring_depth=50.0)
        assert conf.level in (ConfidenceLevel.MEDIUM, ConfidenceLevel.HIGH)
        assert "spt_n_value_only" in conf.checks

    def test_low_confidence_no_spt(self):
        """Sample with no SPT data should be lower confidence."""
        sample = Sample(
            depth_top_ft=5.0,
            depth_bottom_ft=6.5,
        )
        conf = score_sample(sample)
        assert conf.score < 0.75

    def test_flagged_implausible_n_value(self):
        """Sample with implausible N-value should be flagged."""
        sample = Sample(
            depth_top_ft=5.0,
            depth_bottom_ft=6.5,
            spt=SPTBlowCounts(n_value=500),
        )
        conf = score_sample(sample)
        assert "FAIL:n_value_implausible" in conf.checks
        assert conf.notes is not None

    def test_depth_exceeds_boring(self):
        """Sample deeper than boring depth should lose confidence."""
        sample = Sample(
            depth_top_ft=60.0,
            depth_bottom_ft=61.5,
            spt=SPTBlowCounts(first_6in=5, second_6in=8, third_6in=12, n_value=20),
        )
        conf = score_sample(sample, boring_depth=50.0)
        assert "FAIL:depth_exceeds_boring" in conf.checks

    def test_inconsistent_n_value(self):
        """N-value not matching sum of 2nd+3rd should be flagged."""
        sample = Sample(
            depth_top_ft=5.0,
            depth_bottom_ft=6.5,
            spt=SPTBlowCounts(
                first_6in=5, second_6in=8, third_6in=12,
                n_value=99,  # should be 20
            ),
        )
        conf = score_sample(sample)
        assert "FAIL:n_value_inconsistent" in conf.checks


class TestBoreholeConfidence:
    def test_high_confidence_borehole(self):
        """Borehole with good data should be high confidence."""
        samples = [
            Sample(
                depth_top_ft=i * 5.0,
                depth_bottom_ft=i * 5.0 + 1.5,
                spt=SPTBlowCounts(
                    first_6in=5, second_6in=8, third_6in=12, n_value=20,
                ),
            )
            for i in range(1, 8)
        ]
        for s in samples:
            s.confidence = score_sample(s, boring_depth=50.0)

        borehole = Borehole(
            boring_id="B-1",
            depth_ft=50.0,
            samples=samples,
        )
        conf = score_borehole(borehole)
        assert conf.level == ConfidenceLevel.HIGH
        assert conf.score >= 0.75

    def test_low_confidence_no_samples(self):
        """Borehole with no samples should be low confidence."""
        borehole = Borehole(
            boring_id="B-1",
            depth_ft=50.0,
            samples=[],
        )
        conf = score_borehole(borehole)
        assert conf.level in (ConfidenceLevel.LOW, ConfidenceLevel.FLAGGED)
        assert "FAIL:no_samples" in conf.checks

    def test_unknown_id_lowers_confidence(self):
        """Unknown boring ID should lower confidence."""
        borehole = Borehole(
            boring_id="UNKNOWN",
            depth_ft=50.0,
            samples=[],
        )
        conf = score_borehole(borehole)
        assert "FAIL:boring_id_missing" in conf.checks
