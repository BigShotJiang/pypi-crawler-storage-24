"""Tests for boring location plan extraction."""

import math
from unittest.mock import MagicMock, patch

from geotech_report_extraction.location_plan import (
    classify_page_vision,
    classify_pages_vision,
    compute_site_coordinates,
    coords_to_latlong,
    find_plan_pages,
    score_plan_page,
)
from geotech_report_extraction.pdf_parser import PDFContent, PageContent


def _make_page(page_number, text="", is_boring_log=False, lines=0,
               image_count=0):
    page = PageContent(
        page_number=page_number,
        text=text,
        is_boring_log=is_boring_log,
        lines=[{"x0": 0, "y0": 0, "x1": 1, "y1": 1}] * lines,
    )
    page.image_count = image_count
    return page


# ---------------------------------------------------------------------------
# score_plan_page — individual signal tests
# ---------------------------------------------------------------------------

class TestScorePlanPage:
    """Tests for the weighted confidence scoring function."""

    def test_boring_log_always_zero(self):
        page = _make_page(1, text="EXPLORATION PLAN\nB-1 B-2 B-3",
                          is_boring_log=True, lines=5000)
        assert score_plan_page(page) == 0.0

    def test_plan_title_adds_weight(self):
        with_title = _make_page(1, text="EXPLORATION LOCATION PLAN")
        without_title = _make_page(2, text="Some random text")
        assert score_plan_page(with_title) > score_plan_page(without_title)

    def test_boring_ids_add_weight(self):
        few = _make_page(1, text="B-1 B-2")
        many = _make_page(2, text="B-1 B-2 B-3 B-4 B-5 B-6 B-7 B-8")
        assert score_plan_page(many) > score_plan_page(few)

    def test_boring_id_contribution_capped(self):
        """Boring ID contribution should plateau — 20 IDs shouldn't score
        much higher than 6."""
        ids_6 = " ".join(f"B-{i}" for i in range(1, 7))
        ids_20 = " ".join(f"B-{i}" for i in range(1, 21))
        page_6 = _make_page(1, text=ids_6)
        page_20 = _make_page(2, text=ids_20)
        score_6 = score_plan_page(page_6)
        score_20 = score_plan_page(page_20)
        # Both should be at or near the cap
        assert score_20 == score_6  # Both hit 0.30 cap

    def test_drawing_lines_add_weight(self):
        no_lines = _make_page(1, text="B-1 B-2 B-3", lines=10)
        mod_lines = _make_page(2, text="B-1 B-2 B-3", lines=2000)
        high_lines = _make_page(3, text="B-1 B-2 B-3", lines=60000)
        s_none = score_plan_page(no_lines)
        s_mod = score_plan_page(mod_lines)
        s_high = score_plan_page(high_lines)
        assert s_high > s_mod > s_none

    def test_raster_image_adds_weight(self):
        no_img = _make_page(1, text="BORING LOCATION PLAN")
        with_img = _make_page(2, text="BORING LOCATION PLAN", image_count=1)
        assert score_plan_page(with_img) > score_plan_page(no_img)

    def test_low_text_adds_weight(self):
        sparse = _make_page(1, text="Fig 2", lines=2000)
        verbose = _make_page(2, text="x" * 500, lines=2000)
        assert score_plan_page(sparse) > score_plan_page(verbose)

    def test_text_heavy_penalizes(self):
        """Lots of text + few drawing lines = narrative, not a plan."""
        heavy = _make_page(1, text="word " * 300, lines=100)
        assert score_plan_page(heavy) < 0.1

    def test_cross_section_penalizes(self):
        page = _make_page(1, text="CROSS SECTION A-A'\nB-1 B-2 B-3 B-4",
                          lines=5000)
        assert score_plan_page(page) < 0.15

    def test_cross_section_not_penalized_with_plan_title(self):
        """If page has BOTH a plan title and cross-section text, don't
        penalize (CAD filename edge case)."""
        page = _make_page(
            1,
            text="Site Plan\nCROSS SECTION reference\nB-1 B-2 B-3",
            lines=2000,
        )
        assert score_plan_page(page) >= 0.25

    def test_elevation_penalizes(self):
        page = _make_page(
            1, text="ELEVATION (FEET, MSL)\nB-1 B-2 B-3 B-4 B-5 B-6",
            lines=5000,
        )
        assert score_plan_page(page) < 0.15

    def test_haiku_site_plan_boosts_score(self):
        page = _make_page(1, text="Figure 2", lines=100)
        without_vision = score_plan_page(page)
        with_vision = score_plan_page(page, vision_label="SITE_PLAN")
        assert with_vision - without_vision >= 0.35

    def test_haiku_non_plan_no_boost(self):
        page = _make_page(1, text="Figure 2", lines=100)
        without = score_plan_page(page)
        with_narrative = score_plan_page(page, vision_label="NARRATIVE")
        assert with_narrative == without

    def test_score_clamped_to_0_1(self):
        """Score should never go below 0 or above 1."""
        # Strong positive: title + many IDs + drawings + image + vision
        strong = _make_page(
            1,
            text="EXPLORATION LOCATION PLAN\n" + " ".join(
                f"B-{i}" for i in range(1, 20)),
            lines=60000,
            image_count=2,
        )
        assert score_plan_page(strong, vision_label="SITE_PLAN") <= 1.0

        # Strong negative: elevation + cross section + text-heavy
        weak = _make_page(
            2,
            text="CROSS SECTION\nELEVATION (FEET, MSL)\n" + "text " * 300,
            lines=100,
        )
        assert score_plan_page(weak) >= 0.0

    def test_typical_plan_page_above_threshold(self):
        """A typical plan page should score well above the 0.25 threshold."""
        page = _make_page(
            5,
            text="EXPLORATION LOCATION PLAN\nB-1 B-2 B-3 B-4",
            lines=2000,
        )
        assert score_plan_page(page) >= 0.5

    def test_typical_narrative_below_threshold(self):
        """A narrative page should score below the 0.25 threshold."""
        page = _make_page(2, text="The site investigation was performed "
                          "in accordance with..." + " text" * 200,
                          lines=50)
        assert score_plan_page(page) < 0.25


# ---------------------------------------------------------------------------
# find_plan_pages — integration tests (returns scored tuples)
# ---------------------------------------------------------------------------

class TestFindPlanPages:
    def test_detects_plan_with_title_and_ids(self):
        page = _make_page(
            5,
            text="EXPLORATION LOCATION PLAN\nB-1 B-2 B-3 B-4",
            lines=2000,
        )
        pdf = PDFContent(file_path="test.pdf", pages=[page])
        plans = find_plan_pages(pdf)
        assert len(plans) == 1
        assert plans[0][0].page_number == 5
        assert plans[0][1] >= 0.5  # Good confidence

    def test_detects_plan_with_many_ids_and_drawings(self):
        page = _make_page(
            10,
            text="B-1 B-2 B-3 B-4 B-5 B-6 B-7 B-8",
            lines=5000,
        )
        pdf = PDFContent(file_path="test.pdf", pages=[page])
        plans = find_plan_pages(pdf)
        assert len(plans) == 1

    def test_skips_boring_log_pages(self):
        page = _make_page(
            3,
            text="EXPLORATION PLAN\nB-1 B-2 B-3",
            is_boring_log=True,
            lines=2000,
        )
        pdf = PDFContent(file_path="test.pdf", pages=[page])
        plans = find_plan_pages(pdf)
        assert len(plans) == 0

    def test_skips_narrative_mentioning_plan(self):
        """A text-heavy narrative page that mentions 'boring location plan'
        in body text should not be detected as a plan page."""
        page = _make_page(
            2,
            text=(
                "The boring location plan is shown on Figure 2. "
                "A total of twelve test borings were drilled at the site. "
                + "Additional narrative text. " * 40  # >1000 chars
            ),
            lines=10,
        )
        pdf = PDFContent(file_path="test.pdf", pages=[page])
        plans = find_plan_pages(pdf)
        assert len(plans) == 0

    def test_high_drawing_low_text_detected(self):
        """Engineering drawing pages with minimal text should score above
        threshold."""
        page = _make_page(
            8,
            text="Langan\nwww.langan.com\n",
            lines=100000,
        )
        pdf = PDFContent(file_path="test.pdf", pages=[page])
        plans = find_plan_pages(pdf)
        assert len(plans) == 1

    def test_skips_cross_section_pages(self):
        """Pages with 'CROSS SECTION' + elevation should be excluded."""
        page = _make_page(
            7,
            text="CROSS SECTION A-A'\nELEVATION (FEET, MSL)\nB-1 B-2 B-3 B-4 B-5 B-6 B-7",
            lines=5000,
        )
        pdf = PDFContent(file_path="test.pdf", pages=[page])
        plans = find_plan_pages(pdf)
        assert len(plans) == 0

    def test_cross_section_in_filename_not_excluded(self):
        """'CROSS SECTION' in a CAD filename should not exclude a plan page
        that also has a plan title."""
        page = _make_page(
            5,
            text="SITE PLAN AND CROSS SECTIONS.dwg\nSite Plan\nB-1 B-2 B-3 B-4 B-5 B-6 B-7 B-8",
            lines=5000,
        )
        pdf = PDFContent(file_path="test.pdf", pages=[page])
        plans = find_plan_pages(pdf)
        assert len(plans) == 1

    def test_skips_elevation_profile_pages(self):
        """Pages with elevation axes are cross-section profiles."""
        page = _make_page(
            9,
            text="ELEVATION (FEET, MSL)\n1200\n1190\n1180\nB-1 B-2 B-3 B-4 B-5 B-6 B-7",
            lines=8000,
        )
        pdf = PDFContent(file_path="test.pdf", pages=[page])
        plans = find_plan_pages(pdf)
        assert len(plans) == 0

    def test_skips_liquefaction_pages(self):
        """Soil liquefaction evaluation pages should be excluded."""
        page = _make_page(
            12,
            text="SOIL LIQUEFACTION EVALUATION\nBOR-01 BOR-02 BOR-03 BOR-04 BOR-05 BOR-06",
            lines=6000,
        )
        pdf = PDFContent(file_path="test.pdf", pages=[page])
        plans = find_plan_pages(pdf)
        assert len(plans) == 0

    def test_detects_plan_with_supplementary_ids(self):
        """Plan pages with CPT, monitoring well, or foundation pit IDs."""
        page = _make_page(
            6,
            text="EXPLORATION PLAN\nCS-1 CS-2 MW-1 MW-2 FP-1 FP-2",
            lines=3000,
        )
        pdf = PDFContent(file_path="test.pdf", pages=[page])
        plans = find_plan_pages(pdf)
        assert len(plans) == 1

    def test_detects_plan_with_mixed_id_types(self):
        """Pages with a mix of boring and supplementary IDs (6+)."""
        page = _make_page(
            7,
            text="B-1 B-2 B-3 CS-1 CS-2 MW-1",
            lines=5000,
        )
        pdf = PDFContent(file_path="test.pdf", pages=[page])
        plans = find_plan_pages(pdf)
        assert len(plans) == 1

    def test_raster_image_with_plan_title(self):
        """Raster plan pages with a plan title should be detected."""
        page = _make_page(23, text="BORING LOCATION PLAN",
                          lines=0, image_count=1)
        pdf = PDFContent(file_path="test.pdf", pages=[page])
        plans = find_plan_pages(pdf)
        assert len(plans) == 1
        assert plans[0][0].page_number == 23

    def test_raster_image_only_page(self):
        """A raster-only page with no text should be detected."""
        page = _make_page(15, text="", lines=0, image_count=1)
        pdf = PDFContent(file_path="test.pdf", pages=[page])
        plans = find_plan_pages(pdf)
        assert len(plans) == 1

    def test_best_page_ranked_first(self):
        """When both a text-plan and raster page exist, the higher-scoring
        one should be first."""
        text_plan = _make_page(
            5,
            text="EXPLORATION PLAN\nB-1 B-2 B-3 B-4",
            lines=2000,
        )
        raster_page = _make_page(10, text="", lines=0, image_count=1)
        pdf = PDFContent(file_path="test.pdf", pages=[text_plan, raster_page])
        plans = find_plan_pages(pdf)
        assert plans[0][0].page_number == 5
        assert plans[0][1] >= plans[-1][1]  # Sorted descending

    def test_vision_label_map_boosts_score(self):
        """Passing a vision_label_map with SITE_PLAN should boost a page
        that otherwise wouldn't score above threshold."""
        page = _make_page(8, text="Figure 2", lines=100)
        pdf = PDFContent(file_path="test.pdf", pages=[page])
        # Without vision: below threshold
        assert len(find_plan_pages(pdf)) == 0
        # With vision: should now be above threshold
        plans = find_plan_pages(pdf, vision_label_map={8: "SITE_PLAN"})
        assert len(plans) == 1
        assert plans[0][1] >= 0.4

    def test_returns_confidence_scores(self):
        """All returned results should include confidence floats."""
        page = _make_page(
            5,
            text="EXPLORATION LOCATION PLAN\nB-1 B-2 B-3",
            lines=2000,
        )
        pdf = PDFContent(file_path="test.pdf", pages=[page])
        plans = find_plan_pages(pdf)
        for pg, conf in plans:
            assert isinstance(conf, float)
            assert 0.0 <= conf <= 1.0


class TestComputeSiteCoordinates:
    def test_basic_coordinates(self):
        result = {
            "scale": {
                "bar_length_on_image_fraction": 0.10,
                "real_world_distance": 50,
                "unit": "feet",
            },
            "north_direction_degrees": 0,
            "borings": [
                {"id": "B-1", "x_fraction": 0.5, "y_fraction": 0.5},
            ],
        }
        coords = compute_site_coordinates(result, 612, 792)
        assert "B-1" in coords
        # Center of plan = origin
        assert coords["B-1"] == (0.0, -0.0) or coords["B-1"] == (0.0, 0.0)

    def test_east_west_positioning(self):
        result = {
            "scale": {
                "bar_length_on_image_fraction": 0.10,
                "real_world_distance": 100,
                "unit": "feet",
            },
            "north_direction_degrees": 0,
            "borings": [
                {"id": "WEST", "x_fraction": 0.2, "y_fraction": 0.5},
                {"id": "EAST", "x_fraction": 0.8, "y_fraction": 0.5},
            ],
        }
        coords = compute_site_coordinates(result, 612, 792)
        assert coords["WEST"][0] < 0  # West = negative easting
        assert coords["EAST"][0] > 0  # East = positive easting
        # Both at same northing
        assert abs(coords["WEST"][1] - coords["EAST"][1]) < 0.1

    def test_north_south_positioning(self):
        result = {
            "scale": {
                "bar_length_on_image_fraction": 0.10,
                "real_world_distance": 100,
                "unit": "feet",
            },
            "north_direction_degrees": 0,
            "borings": [
                {"id": "NORTH", "x_fraction": 0.5, "y_fraction": 0.2},
                {"id": "SOUTH", "x_fraction": 0.5, "y_fraction": 0.8},
            ],
        }
        coords = compute_site_coordinates(result, 612, 792)
        assert coords["NORTH"][1] > 0  # North = positive northing
        assert coords["SOUTH"][1] < 0  # South = negative northing

    def test_no_scale_returns_empty(self):
        result = {
            "scale": None,
            "north_direction_degrees": 0,
            "borings": [
                {"id": "B-1", "x_fraction": 0.5, "y_fraction": 0.5},
            ],
        }
        coords = compute_site_coordinates(result, 612, 792)
        assert coords == {}

    def test_rotation_90_degrees(self):
        """When north points right (90 degrees), image-right = north."""
        result = {
            "scale": {
                "bar_length_on_image_fraction": 0.10,
                "real_world_distance": 100,
                "unit": "feet",
            },
            "north_direction_degrees": 90,
            "borings": [
                # Point to the right of center in image space
                {"id": "B-1", "x_fraction": 0.7, "y_fraction": 0.5},
            ],
        }
        coords = compute_site_coordinates(result, 612, 792)
        # Image-right with 90° rotation = north
        assert coords["B-1"][1] > 0  # Should have positive northing

    def test_meters_conversion(self):
        result = {
            "scale": {
                "bar_length_on_image_fraction": 0.10,
                "real_world_distance": 30,
                "unit": "meters",
            },
            "north_direction_degrees": 0,
            "borings": [
                {"id": "B-1", "x_fraction": 0.6, "y_fraction": 0.5},
            ],
        }
        coords = compute_site_coordinates(result, 612, 792)
        # 30 meters = ~98.4 ft. 0.1 fraction = 98.4 ft
        # B-1 is at 0.6 (0.1 fraction right of center)
        # Expected easting ≈ 98.4 ft
        assert 90 < coords["B-1"][0] < 110


class TestCoordsToLatLong:
    def test_center_stays_at_reference(self):
        site_coords = {"B-1": (0.0, 0.0)}
        result = coords_to_latlong(site_coords, 38.9220, -77.0366)
        assert abs(result["B-1"][0] - 38.9220) < 0.0001
        assert abs(result["B-1"][1] - (-77.0366)) < 0.0001

    def test_northing_increases_latitude(self):
        site_coords = {
            "NORTH": (0.0, 100.0),
            "SOUTH": (0.0, -100.0),
        }
        result = coords_to_latlong(site_coords, 38.9220, -77.0366)
        assert result["NORTH"][0] > 38.9220
        assert result["SOUTH"][0] < 38.9220

    def test_easting_changes_longitude(self):
        site_coords = {
            "EAST": (100.0, 0.0),
            "WEST": (-100.0, 0.0),
        }
        result = coords_to_latlong(site_coords, 38.9220, -77.0366)
        assert result["EAST"][1] > -77.0366
        assert result["WEST"][1] < -77.0366

    def test_small_offsets_produce_small_latlong_changes(self):
        """100 ft offset should produce very small lat/long changes."""
        site_coords = {"B-1": (100.0, 100.0)}
        result = coords_to_latlong(site_coords, 38.9220, -77.0366)
        lat_diff = abs(result["B-1"][0] - 38.9220)
        lon_diff = abs(result["B-1"][1] - (-77.0366))
        # 100 ft / 364000 ft/deg ≈ 0.000275 degrees
        assert lat_diff < 0.001
        assert lon_diff < 0.001


# ---------------------------------------------------------------------------
# Haiku vision page classifier
# ---------------------------------------------------------------------------

def _mock_anthropic_response(text: str):
    """Build a mock Anthropic messages.create response."""
    content_block = MagicMock()
    content_block.text = text
    response = MagicMock()
    response.content = [content_block]
    return response


class TestClassifyPageVision:
    """Tests for the Haiku-based page classifier."""

    def _call_with_mock(self, response_text: str, *, raise_exc=None):
        """Helper: patch anthropic import inside classify_page_vision."""
        mock_anthropic = MagicMock()
        client = MagicMock()
        mock_anthropic.Anthropic.return_value = client
        if raise_exc:
            client.messages.create.side_effect = raise_exc
        else:
            client.messages.create.return_value = _mock_anthropic_response(
                response_text
            )
        with patch.dict("sys.modules", {"anthropic": mock_anthropic}):
            return classify_page_vision("dummyb64", api_key="test-key")

    def test_site_plan_label(self):
        assert self._call_with_mock("SITE_PLAN") == "SITE_PLAN"

    def test_boring_log_label(self):
        assert self._call_with_mock("BORING_LOG") == "BORING_LOG"

    def test_normalizes_site_plan_variations(self):
        """Haiku might respond 'Site Plan' instead of 'SITE_PLAN'."""
        assert self._call_with_mock("Site Plan") == "SITE_PLAN"

    def test_cross_section_label(self):
        assert self._call_with_mock("CROSS_SECTION") == "CROSS_SECTION"

    def test_table_label(self):
        assert self._call_with_mock("TABLE") == "TABLE"

    def test_api_failure_returns_none(self):
        result = self._call_with_mock("", raise_exc=Exception("API error"))
        assert result is None

    def test_missing_anthropic_returns_none(self):
        """Should return None if anthropic is not installed."""
        with patch.dict("sys.modules", {"anthropic": None}):
            result = classify_page_vision("dummyb64", api_key="test-key")
            assert result is None


class TestClassifyPagesVision:
    """Tests for the batch vision classifier (with mocked API)."""

    @staticmethod
    def _mock_fitz():
        """Create a mock fitz module that returns a fake doc/pixmap."""
        mock_fitz_mod = MagicMock()
        mock_doc = MagicMock()
        mock_fitz_mod.open.return_value = mock_doc
        mock_pix = MagicMock()
        mock_pix.tobytes.return_value = b"fake_png"
        mock_page = MagicMock()
        mock_page.get_pixmap.return_value = mock_pix
        mock_doc.__getitem__ = MagicMock(return_value=mock_page)
        return mock_fitz_mod

    @patch("geotech_report_extraction.location_plan.classify_page_vision")
    def test_returns_label_map(self, mock_classify):
        """Should return a dict mapping page numbers to labels."""
        call_count = {"n": 0}

        def classify_side_effect(img_b64, api_key=None, model=None, backend=None):
            call_count["n"] += 1
            if call_count["n"] == 1:
                return "NARRATIVE"
            if call_count["n"] == 2:
                return "SITE_PLAN"
            return "TABLE"

        mock_classify.side_effect = classify_side_effect

        pages = [
            PageContent(page_number=3, text="intro", is_boring_log=True),
            PageContent(page_number=5, text="fig 1"),
            PageContent(page_number=7, text="plan view"),
            PageContent(page_number=10, text="table"),
        ]
        pdf = PDFContent(file_path="test.pdf", pages=pages)

        with patch.dict("sys.modules", {"fitz": self._mock_fitz()}):
            labels = classify_pages_vision(pdf, api_key="test-key")
        assert labels[5] == "NARRATIVE"
        assert labels[7] == "SITE_PLAN"
        assert labels[10] == "TABLE"
        assert 3 not in labels  # Boring log skipped

    @patch("geotech_report_extraction.location_plan.classify_page_vision")
    def test_skips_boring_log_pages(self, mock_classify):
        """Boring log pages should not be sent to the classifier."""
        mock_classify.return_value = "SITE_PLAN"

        pages = [
            PageContent(page_number=1, text="log", is_boring_log=True),
            PageContent(page_number=2, text="log", is_boring_log=True),
        ]
        pdf = PDFContent(file_path="test.pdf", pages=pages)

        with patch.dict("sys.modules", {"fitz": self._mock_fitz()}):
            labels = classify_pages_vision(pdf, api_key="test-key")
        assert labels == {}
        mock_classify.assert_not_called()

    @patch("geotech_report_extraction.location_plan.classify_page_vision")
    def test_handles_none_labels(self, mock_classify):
        """Pages where classify_page_vision returns None should be omitted."""
        mock_classify.return_value = None

        pages = [
            PageContent(page_number=1, text="text"),
            PageContent(page_number=2, text="text"),
        ]
        pdf = PDFContent(file_path="test.pdf", pages=pages)

        with patch.dict("sys.modules", {"fitz": self._mock_fitz()}):
            labels = classify_pages_vision(pdf, api_key="test-key")
        assert labels == {}
