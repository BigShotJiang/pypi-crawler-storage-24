"""Tests for geospatial utilities (geo.py)."""

import math
import os
import tempfile

import pytest

from geotech_report_extraction.geo import (
    boring_centroid,
    boring_convex_hull,
    coords_to_latlong_geodetic,
    create_boring_map,
    export_geojson,
    export_shapefile,
    geodesic_distance_ft,
    geocode_address,
    latlong_to_mgrs,
    latlong_to_state_plane,
    latlong_to_utm,
    lookup_state_plane_epsg,
    mgrs_to_latlong,
    plot_borings_static,
    point_in_boundary,
    site_area_acres,
    state_plane_to_latlong,
    to_geodataframe,
    utm_to_latlong,
)


# ---------------------------------------------------------------------------
# Test data: Meridian Hill Park, Washington DC
# ---------------------------------------------------------------------------
MERIDIAN_HILL_COORDS = {
    "LDCP-1": (0.0, 0.0),       # at center
    "LDCP-2": (100.0, 0.0),     # 100 ft east
    "LDCP-3": (0.0, 100.0),     # 100 ft north
    "LDCP-4": (-100.0, 50.0),   # 100 ft west, 50 ft north
    "LDCP-5": (50.0, -150.0),   # 50 ft east, 150 ft south
}

REF_LAT = 38.9220
REF_LONG = -77.0366


# ---------------------------------------------------------------------------
# Geodetic coordinate conversion
# ---------------------------------------------------------------------------

class TestCoordsToLatlongGeodetic:
    def test_center_stays_at_reference(self):
        coords = {"B-1": (0.0, 0.0)}
        result = coords_to_latlong_geodetic(coords, REF_LAT, REF_LONG)
        assert abs(result["B-1"][0] - REF_LAT) < 0.0001
        assert abs(result["B-1"][1] - REF_LONG) < 0.0001

    def test_northing_increases_latitude(self):
        coords = {"NORTH": (0.0, 500.0), "SOUTH": (0.0, -500.0)}
        result = coords_to_latlong_geodetic(coords, REF_LAT, REF_LONG)
        assert result["NORTH"][0] > REF_LAT
        assert result["SOUTH"][0] < REF_LAT

    def test_easting_increases_longitude(self):
        coords = {"EAST": (500.0, 0.0), "WEST": (-500.0, 0.0)}
        result = coords_to_latlong_geodetic(coords, REF_LAT, REF_LONG)
        assert result["EAST"][1] > REF_LONG
        assert result["WEST"][1] < REF_LONG

    def test_small_offsets_produce_small_changes(self):
        coords = {"B-1": (100.0, 100.0)}
        result = coords_to_latlong_geodetic(coords, REF_LAT, REF_LONG)
        lat_diff = abs(result["B-1"][0] - REF_LAT)
        lon_diff = abs(result["B-1"][1] - REF_LONG)
        assert lat_diff < 0.001
        assert lon_diff < 0.001

    def test_multiple_borings(self):
        result = coords_to_latlong_geodetic(MERIDIAN_HILL_COORDS, REF_LAT, REF_LONG)
        assert len(result) == 5
        # LDCP-3 (north) should have higher lat than LDCP-5 (south)
        assert result["LDCP-3"][0] > result["LDCP-5"][0]


# ---------------------------------------------------------------------------
# State Plane conversion
# ---------------------------------------------------------------------------

class TestStatePlane:
    def test_dc_round_trip(self):
        """Convert DC lat/long to MD State Plane and back."""
        epsg = 2234  # NAD83 Maryland, US ft
        e, n = latlong_to_state_plane(REF_LAT, REF_LONG, epsg)
        lat, lon = state_plane_to_latlong(e, n, epsg)
        assert abs(lat - REF_LAT) < 0.0001
        assert abs(lon - REF_LONG) < 0.0001

    def test_california_zone_5(self):
        """Santa Ana is in CA Zone 5 (EPSG:2229)."""
        lat, lon = 33.7537, -117.8870
        e, n = latlong_to_state_plane(lat, lon, 2229)
        # State Plane coordinates should be positive and large
        assert e > 0
        assert n > 0
        # Round trip
        lat2, lon2 = state_plane_to_latlong(e, n, 2229)
        assert abs(lat2 - lat) < 0.0001
        assert abs(lon2 - lon) < 0.0001


# ---------------------------------------------------------------------------
# UTM conversion
# ---------------------------------------------------------------------------

class TestUTM:
    def test_dc_utm(self):
        e, n, zone, letter = latlong_to_utm(REF_LAT, REF_LONG)
        assert zone == 18
        assert letter == "S"
        assert e > 0
        assert n > 0

    def test_round_trip(self):
        e, n, zone, letter = latlong_to_utm(REF_LAT, REF_LONG)
        lat, lon = utm_to_latlong(e, n, zone, letter)
        assert abs(lat - REF_LAT) < 0.0001
        assert abs(lon - REF_LONG) < 0.0001


# ---------------------------------------------------------------------------
# MGRS conversion
# ---------------------------------------------------------------------------

class TestMGRS:
    def test_dc_mgrs(self):
        mgrs_str = latlong_to_mgrs(REF_LAT, REF_LONG)
        assert isinstance(mgrs_str, str)
        assert len(mgrs_str) > 5
        assert mgrs_str.startswith("18S")

    def test_round_trip(self):
        mgrs_str = latlong_to_mgrs(REF_LAT, REF_LONG)
        lat, lon = mgrs_to_latlong(mgrs_str)
        assert abs(lat - REF_LAT) < 0.001
        assert abs(lon - REF_LONG) < 0.001


# ---------------------------------------------------------------------------
# Geodesic distance
# ---------------------------------------------------------------------------

class TestGeodesicDistance:
    def test_zero_distance(self):
        d = geodesic_distance_ft(REF_LAT, REF_LONG, REF_LAT, REF_LONG)
        assert d == 0.0

    def test_known_distance(self):
        """DC to Baltimore is ~35 miles = ~184,800 ft."""
        baltimore = (39.2904, -76.6122)
        d = geodesic_distance_ft(REF_LAT, REF_LONG, *baltimore)
        # Should be roughly 150,000-200,000 ft
        assert 140_000 < d < 220_000

    def test_short_distance(self):
        """Two points 100 ft apart (north-south)."""
        # 100 ft ≈ 0.000275 degrees latitude
        lat2 = REF_LAT + 0.000275
        d = geodesic_distance_ft(REF_LAT, REF_LONG, lat2, REF_LONG)
        assert 90 < d < 110  # Should be close to 100 ft


# ---------------------------------------------------------------------------
# Geometric analysis (shapely)
# ---------------------------------------------------------------------------

class TestGeometricAnalysis:
    def _make_latlong_coords(self):
        return coords_to_latlong_geodetic(
            MERIDIAN_HILL_COORDS, REF_LAT, REF_LONG,
        )

    def test_convex_hull(self):
        hull = boring_convex_hull(MERIDIAN_HILL_COORDS)
        assert hull is not None
        assert len(hull) >= 4  # At least 3 unique vertices + closing point

    def test_convex_hull_too_few_points(self):
        coords = {"B-1": (0.0, 0.0), "B-2": (1.0, 1.0)}
        assert boring_convex_hull(coords) is None

    def test_centroid(self):
        centroid = boring_centroid(MERIDIAN_HILL_COORDS)
        # Centroid should be near (10, 0) based on our test data
        assert isinstance(centroid, tuple)
        assert len(centroid) == 2

    def test_point_in_boundary(self):
        boundary = [(0, 0), (100, 0), (100, 100), (0, 100), (0, 0)]
        assert point_in_boundary(50, 50, boundary) is True
        assert point_in_boundary(150, 150, boundary) is False

    def test_site_area_in_feet(self):
        # 100x100 ft square = 10,000 sq ft ≈ 0.23 acres
        boundary = [(0, 0), (100, 0), (100, 100), (0, 100), (0, 0)]
        area = site_area_acres(boundary)
        assert 0.20 < area < 0.25


# ---------------------------------------------------------------------------
# Map visualisation (folium)
# ---------------------------------------------------------------------------

class TestMapping:
    def test_create_boring_map(self):
        coords = coords_to_latlong_geodetic(
            MERIDIAN_HILL_COORDS, REF_LAT, REF_LONG,
        )
        m = create_boring_map(coords, title="Test Map")
        # folium.Map has _repr_html_ for Jupyter rendering
        html = m._repr_html_()
        assert "Test Map" in html
        assert "LDCP-1" in html

    def test_save_map_to_file(self):
        coords = coords_to_latlong_geodetic(
            MERIDIAN_HILL_COORDS, REF_LAT, REF_LONG,
        )
        m = create_boring_map(coords)
        with tempfile.NamedTemporaryFile(suffix=".html", delete=False) as f:
            m.save(f.name)
            assert os.path.getsize(f.name) > 1000
            os.unlink(f.name)

    def test_empty_coords_raises(self):
        with pytest.raises(ValueError):
            create_boring_map({})


# ---------------------------------------------------------------------------
# GIS export (geopandas)
# ---------------------------------------------------------------------------

class TestGISExport:
    def _latlong_coords(self):
        return coords_to_latlong_geodetic(
            MERIDIAN_HILL_COORDS, REF_LAT, REF_LONG,
        )

    def test_to_geodataframe(self):
        coords = self._latlong_coords()
        gdf = to_geodataframe(coords)
        assert len(gdf) == 5
        assert "boring_id" in gdf.columns
        assert gdf.crs.to_epsg() == 4326

    def test_to_geodataframe_with_extra_fields(self):
        coords = self._latlong_coords()
        extras = {"LDCP-1": {"depth_ft": 25.0, "elevation_ft": 180.5}}
        gdf = to_geodataframe(coords, extra_fields=extras)
        ldcp1 = gdf[gdf.boring_id == "LDCP-1"].iloc[0]
        assert ldcp1["depth_ft"] == 25.0

    def test_export_geojson(self):
        coords = self._latlong_coords()
        with tempfile.NamedTemporaryFile(suffix=".geojson", delete=False) as f:
            export_geojson(coords, f.name)
            assert os.path.getsize(f.name) > 100
            os.unlink(f.name)

    def test_export_shapefile(self):
        coords = self._latlong_coords()
        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, "borings.shp")
            export_shapefile(coords, path)
            assert os.path.exists(path)


# ---------------------------------------------------------------------------
# Static plot (contextily + matplotlib)
# ---------------------------------------------------------------------------

class TestStaticPlot:
    def test_plot_borings_no_basemap(self):
        """Test plotting without basemap (no network required)."""
        import matplotlib
        matplotlib.use("Agg")  # Non-interactive backend

        coords = coords_to_latlong_geodetic(
            MERIDIAN_HILL_COORDS, REF_LAT, REF_LONG,
        )
        fig = plot_borings_static(coords, basemap=False, title="Test Plot")
        assert fig is not None

    def test_plot_borings_save_file(self):
        import matplotlib
        matplotlib.use("Agg")

        coords = coords_to_latlong_geodetic(
            MERIDIAN_HILL_COORDS, REF_LAT, REF_LONG,
        )
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
            plot_borings_static(
                coords, output_path=f.name, basemap=False,
            )
            assert os.path.getsize(f.name) > 1000
            os.unlink(f.name)


# ---------------------------------------------------------------------------
# State Plane EPSG lookup
# ---------------------------------------------------------------------------

class TestStatePlaneEPSG:
    def test_ca_zone_5(self):
        assert lookup_state_plane_epsg("CA", "Zone 5") == 2229

    def test_dc(self):
        assert lookup_state_plane_epsg("DC") == 2234

    def test_ny_long_island(self):
        assert lookup_state_plane_epsg("NY", "Long Island") == 2263

    def test_case_insensitive(self):
        assert lookup_state_plane_epsg("ca", "Zone 5") == 2229

    def test_unknown(self):
        assert lookup_state_plane_epsg("ZZ", "Unknown") is None
