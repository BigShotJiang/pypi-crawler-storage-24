"""Tests for vision LLM extractor (no API calls needed)."""

from geotech_report_extraction.models import (
    Borehole,
    ConfidenceLevel,
    Sample,
    SoilLayer,
    SPTBlowCounts,
)
from geotech_report_extraction.vision_extractor import (
    compare_extractions,
    vision_result_to_borehole,
)


class TestVisionResultToBorehole:
    def test_basic_conversion(self):
        data = {
            "boring_id": "B-1",
            "total_depth_ft": 50.0,
            "elevation_ft": 120.3,
            "samples": [
                {
                    "depth_top_ft": 5.0,
                    "depth_bottom_ft": 6.5,
                    "sample_type": "SS",
                    "blow_count_1": 5,
                    "blow_count_2": 8,
                    "blow_count_3": 12,
                    "n_value": 20,
                    "refusal": False,
                },
                {
                    "depth_top_ft": 10.0,
                    "depth_bottom_ft": 11.5,
                    "sample_type": "SS",
                    "blow_count_1": 10,
                    "blow_count_2": 15,
                    "blow_count_3": 20,
                    "n_value": 35,
                    "refusal": False,
                },
            ],
            "soil_layers": [
                {
                    "depth_top_ft": 0.0,
                    "depth_bottom_ft": 8.0,
                    "description": "SAND, brown, fine to medium, moist, loose",
                    "uscs_code": "SP",
                    "color": "brown",
                },
            ],
        }
        bh = vision_result_to_borehole(data)
        assert bh.boring_id == "B-1"
        assert bh.depth_ft == 50.0
        assert len(bh.samples) == 2
        assert bh.samples[0].spt.n_value == 20
        assert bh.samples[0].spt.first_6in == 5
        assert bh.samples[1].depth_top_ft == 10.0
        assert len(bh.soil_layers) == 1
        assert bh.soil_layers[0].uscs_classification.value == "SP"

    def test_empty_data(self):
        data = {"boring_id": "B-1", "total_depth_ft": 30.0}
        bh = vision_result_to_borehole(data)
        assert bh.boring_id == "B-1"
        assert len(bh.samples) == 0

    def test_n_value_computed_from_blows(self):
        data = {
            "boring_id": "B-1",
            "samples": [
                {
                    "depth_top_ft": 5.0,
                    "blow_count_2": 8,
                    "blow_count_3": 12,
                    "n_value": None,
                },
            ],
        }
        bh = vision_result_to_borehole(data)
        assert bh.samples[0].spt.n_value == 20


class TestCompareExtractions:
    def test_identical_results_high_confidence(self):
        """Both methods agree perfectly -> high confidence."""
        samples = [
            Sample(
                depth_top_ft=5.0, depth_bottom_ft=6.5,
                spt=SPTBlowCounts(first_6in=5, second_6in=8, third_6in=12, n_value=20),
            ),
            Sample(
                depth_top_ft=10.0, depth_bottom_ft=11.5,
                spt=SPTBlowCounts(first_6in=10, second_6in=15, third_6in=20, n_value=35),
            ),
        ]
        rb = Borehole(boring_id="B-1", depth_ft=50.0, samples=samples)
        vis = Borehole(boring_id="B-1", depth_ft=50.0, samples=samples)
        conf = compare_extractions(rb, vis)
        assert conf.level == ConfidenceLevel.HIGH
        assert conf.score >= 0.75

    def test_rules_missed_samples(self):
        """Rules found nothing, vision found samples -> flagged."""
        rb = Borehole(boring_id="B-1", depth_ft=50.0, samples=[])
        vis = Borehole(
            boring_id="B-1", depth_ft=50.0,
            samples=[
                Sample(
                    depth_top_ft=5.0, depth_bottom_ft=6.5,
                    spt=SPTBlowCounts(n_value=20),
                ),
            ],
        )
        conf = compare_extractions(rb, vis)
        assert "FAIL:rules_missed_samples" in conf.checks

    def test_depth_mismatch(self):
        """Different total depths -> warning."""
        rb = Borehole(boring_id="B-1", depth_ft=50.0, samples=[])
        vis = Borehole(boring_id="B-1", depth_ft=80.0, samples=[])
        conf = compare_extractions(rb, vis)
        assert "WARN:depth_mismatch" in conf.checks

    def test_n_values_disagree(self):
        """Different N-values at same depth -> warning."""
        rb = Borehole(
            boring_id="B-1", depth_ft=50.0,
            samples=[
                Sample(
                    depth_top_ft=5.0, depth_bottom_ft=6.5,
                    spt=SPTBlowCounts(n_value=20),
                ),
            ],
        )
        vis = Borehole(
            boring_id="B-1", depth_ft=50.0,
            samples=[
                Sample(
                    depth_top_ft=5.0, depth_bottom_ft=6.5,
                    spt=SPTBlowCounts(n_value=50),
                ),
            ],
        )
        conf = compare_extractions(rb, vis)
        assert any("n_values_disagree" in c for c in conf.checks)
