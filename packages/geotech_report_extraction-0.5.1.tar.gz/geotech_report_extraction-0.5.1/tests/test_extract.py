"""Tests for the main extract API."""

import pytest

from geotech_report_extraction.extract import extract_report


class TestExtractReport:
    def test_file_not_found(self):
        with pytest.raises(FileNotFoundError):
            extract_report("nonexistent_file.pdf")

    def test_non_pdf_file(self, tmp_path):
        txt_file = tmp_path / "test.txt"
        txt_file.write_text("not a pdf")
        with pytest.raises(ValueError, match="Expected a PDF"):
            extract_report(str(txt_file))
