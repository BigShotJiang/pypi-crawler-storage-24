# assigno

A no-nonsense CLI assignment tracker for students.

## Install

```
pip install .
```

## Usage

```
assigno add
assigno list
assigno list --pending
assigno filter 25/03/26
assigno done 1
assigno delete 1
assigno summary
```
