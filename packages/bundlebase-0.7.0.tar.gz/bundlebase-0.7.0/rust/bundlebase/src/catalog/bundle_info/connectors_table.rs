use crate::bundle::BundleFacade;
use arrow::array::{BooleanArray, RecordBatch, StringArray};
use arrow_schema::{DataType, Field, Schema, SchemaRef};
use async_trait::async_trait;
use datafusion::catalog::Session;
use datafusion::datasource::{MemTable, TableProvider, TableType};
use datafusion::error::Result;
use datafusion::logical_expr::Expr;
use datafusion::physical_plan::ExecutionPlan;
use std::any::Any;
use std::sync::{Arc, Weak};

/// TableProvider that exposes connector entries in the `bundle_info.connectors` table.
pub(super) struct BundleConnectorsTable {
    facade: Weak<dyn BundleFacade>,
    schema: SchemaRef,
}

impl std::fmt::Debug for BundleConnectorsTable {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("BundleConnectorsTable")
            .field("schema", &self.schema)
            .finish()
    }
}

impl BundleConnectorsTable {
    pub fn new(facade: Weak<dyn BundleFacade>) -> Self {
        Self {
            facade,
            schema: Self::table_schema(),
        }
    }

    fn facade(&self) -> Result<Arc<dyn BundleFacade>> {
        self.facade.upgrade().ok_or_else(|| {
            datafusion::error::DataFusionError::Internal("Bundle has been dropped (while accessing bundle_info.connectors)".to_string())
        })
    }

    fn table_schema() -> SchemaRef {
        Arc::new(Schema::new(vec![
            Field::new("id", DataType::Utf8, false),
            Field::new("name", DataType::Utf8, false),
            Field::new("runtime", DataType::Utf8, false),
            Field::new("entrypoint", DataType::Utf8, false),
            Field::new("platform", DataType::Utf8, false),
            Field::new("temporary", DataType::Boolean, false),
        ]))
    }

    fn build_batch(&self) -> Result<RecordBatch> {
        let mut entries = self.facade()?.connector_registry().read().entries().to_vec();

        // Sort by name then platform for consistent ordering
        entries.sort_by(|a, b| {
            a.name.to_string().cmp(&b.name.to_string())
                .then_with(|| a.platform.to_string().cmp(&b.platform.to_string()))
        });

        let ids: Vec<String> = entries.iter().map(|e| e.id.to_string()).collect();
        let names: Vec<String> = entries.iter().map(|e| e.name.to_string()).collect();
        let runtimes: Vec<String> = entries.iter().map(|e| e.from.runtime_name().to_string()).collect();
        let entrypoints: Vec<String> = entries.iter().map(|e| e.from.to_entrypoint_string()).collect();
        let platforms: Vec<String> = entries.iter().map(|e| e.platform.to_string()).collect();
        let temporaries: Vec<bool> = entries.iter().map(|e| e.temporary).collect();

        let batch = RecordBatch::try_new(
            Arc::clone(&self.schema),
            vec![
                Arc::new(StringArray::from(ids.iter().map(|s| s.as_str()).collect::<Vec<_>>())),
                Arc::new(StringArray::from(names.iter().map(|s| s.as_str()).collect::<Vec<_>>())),
                Arc::new(StringArray::from(runtimes.iter().map(|s| s.as_str()).collect::<Vec<_>>())),
                Arc::new(StringArray::from(entrypoints.iter().map(|s| s.as_str()).collect::<Vec<_>>())),
                Arc::new(StringArray::from(platforms.iter().map(|s| s.as_str()).collect::<Vec<_>>())),
                Arc::new(BooleanArray::from(temporaries)),
            ],
        )?;

        Ok(batch)
    }
}

#[async_trait]
impl TableProvider for BundleConnectorsTable {
    fn as_any(&self) -> &dyn Any {
        self
    }

    fn schema(&self) -> SchemaRef {
        Arc::clone(&self.schema)
    }

    fn table_type(&self) -> TableType {
        TableType::Base
    }

    async fn scan(
        &self,
        state: &dyn Session,
        projection: Option<&Vec<usize>>,
        filters: &[Expr],
        limit: Option<usize>,
    ) -> Result<Arc<dyn ExecutionPlan>> {
        let batch = self.build_batch()?;
        let mem_table = MemTable::try_new(self.schema.clone(), vec![vec![batch]])?;
        mem_table.scan(state, projection, filters, limit).await
    }
}
