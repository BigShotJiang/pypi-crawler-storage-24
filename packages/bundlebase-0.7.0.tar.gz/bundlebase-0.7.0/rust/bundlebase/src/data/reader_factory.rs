use crate::bundle::BundleFacade;
use crate::data::plugin::{BundlebasePlugin, CsvPlugin, JsonPlugin, ParquetPlugin, ReaderPlugin};
use crate::data::{BlockId, DataReader};
use crate::io::DataStorage;
use crate::BundlebaseError;
use arrow_schema::SchemaRef;
use datafusion::common::DataFusionError;
use std::collections::HashMap;
use std::sync::Arc;

pub struct DataReaderFactory {
    plugins: Vec<Arc<dyn ReaderPlugin>>,
    storage: Arc<DataStorage>,
}

impl DataReaderFactory {
    pub fn new(
        storage: Arc<DataStorage>,
    ) -> Self {
        Self {
            storage: storage.clone(),
            plugins: vec![
                Arc::new(CsvPlugin::default()),
                Arc::new(BundlebasePlugin),
                Arc::new(JsonPlugin::default()),
                Arc::new(ParquetPlugin::default()),
            ],
        }
    }

    pub fn storage(&self) -> &Arc<DataStorage> {
        &self.storage
    }

    /// Create a reader for the given source.
    ///
    /// # Arguments
    /// * `source` - URL or path to the data source
    /// * `block_id` - ID of the block being read
    /// * `bundle` - Bundle context (as trait object for flexibility)
    /// * `schema` - Optional schema (if already known)
    /// * `layout` - Optional layout file path
    /// * `expected_version` - If provided, validates version on first data access.
    ///   This is used to detect when source files have changed since the bundle was created.
    pub async fn reader(
        &self,
        source: &str,
        block_id: &BlockId,
        bundle: &dyn BundleFacade,
        schema: Option<SchemaRef>,
        layout: Option<String>,
        expected_version: Option<String>,
        read_options: Option<&HashMap<String, String>>,
    ) -> Result<Arc<dyn DataReader>, BundlebaseError> {
        for plugin in &self.plugins {
            if let Some(reader) = plugin
                .reader(
                    source,
                    block_id,
                    bundle,
                    schema.clone(),
                    layout.clone(),
                    expected_version.clone(),
                    read_options,
                )
                .await?
            {
                return Ok(reader);
            }
        }
        Err(DataFusionError::NotImplemented(format!("No reader found for {}", source)).into())
    }
}
