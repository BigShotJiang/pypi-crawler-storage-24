# tanml/analysis/drift.py
"""
Feature drift analysis module for internal and external validation.

This module provides statistical tools to detect whether the distribution of
machine learning features has changed between two points in time or between
two datasets (e.g., Training vs. Serving).

Key Metrics:
    - PSI (Population Stability Index): A single number indicating the
      magnitude of the shift.
    - KS Test (Kolmogorov-Smirnov): A non-parametric test to determine if
      two samples come from different distributions.

Example:
    >>> import pandas as pd
    >>> from tanml.analysis.drift import analyze_drift
    >>>
    >>> # Compare Training and Serving data
    >>> results = analyze_drift(train_df, serving_df)
    >>> for col, metrics in results.items():
    ...     if metrics["has_drift"]:
    ...         print(f"Drift detected in {col}: PSI={metrics['psi']:.3f}")
"""

from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd


def calculate_psi(
    expected: pd.Series,
    actual: pd.Series,
    bins: int = 10,
) -> float:
    """
    Calculate Population Stability Index (PSI) between two distributions.

    PSI measures how much a distribution has shifted. Thresholds:
        - PSI < 0.1: No significant shift
        - 0.1 <= PSI < 0.2: Moderate shift (investigate)
        - PSI >= 0.2: Large shift (action needed)

    Args:
        expected: Expected/baseline distribution (e.g., training data)
        actual: Actual/new distribution (e.g., test data)
        bins: Number of bins for discretization

    Returns:
        PSI value (float)
    """
    # Handle edge cases
    expected = expected.dropna()
    actual = actual.dropna()

    if len(expected) == 0 or len(actual) == 0:
        return np.nan

    # Create bins from expected distribution
    try:
        _, bin_edges = np.histogram(expected, bins=bins)
    except ValueError:
        return np.nan

    # Calculate proportions in each bin
    expected_counts = np.histogram(expected, bins=bin_edges)[0]
    actual_counts = np.histogram(actual, bins=bin_edges)[0]

    # Convert to proportions (avoid division by zero)
    expected_pct = expected_counts / len(expected)
    actual_pct = actual_counts / len(actual)

    # Replace zeros with small value to avoid log(0)
    eps = 1e-8
    expected_pct = np.where(expected_pct == 0, eps, expected_pct)
    actual_pct = np.where(actual_pct == 0, eps, actual_pct)

    # Calculate PSI
    psi = np.sum((actual_pct - expected_pct) * np.log(actual_pct / expected_pct))

    return float(psi)


def calculate_ks(
    expected: pd.Series,
    actual: pd.Series,
) -> tuple[float, float]:
    """
    Calculate Kolmogorov-Smirnov statistic between two distributions.

    Args:
        expected: Expected/baseline distribution
        actual: Actual/new distribution

    Returns:
        Tuple of (KS statistic, p-value)
    """
    from scipy import stats

    expected = expected.dropna()
    actual = actual.dropna()

    if len(expected) == 0 or len(actual) == 0:
        return np.nan, np.nan

    try:
        ks_stat, p_value = stats.ks_2samp(expected, actual)
        return float(ks_stat), float(p_value)
    except Exception:
        return np.nan, np.nan


def analyze_drift(
    train_df: pd.DataFrame,
    test_df: pd.DataFrame,
    numeric_cols: list[str] | None = None,
    psi_threshold: float = 0.1,
    ks_threshold: float = 0.05,
) -> dict[str, dict[str, Any]]:
    """
    Perform a comprehensive drift analysis on all continuous features.

    This function iterates through the numeric columns, calculates both
    PSI and KS statistics, and flags features that exceed regulatory or
    statistical thresholds.

    Args:
        train_df: The baseline/reference dataset (e.g., historical training data).
        test_df: The target dataset to check for drift (e.g., current production batch).
        numeric_cols: List of columns to analyze. If None, all numeric columns
            common to both datasets will be checked.
        psi_threshold: The PSI value above which drift is considered "moderate".
            Default is 0.1.
        ks_threshold: The p-value below which the KS test is considered
            statistically significant (identifying a difference). Default is 0.05.

    Returns:
        A dictionary mapping column names to their drift metadata:
            - `psi`: The calculated Population Stability Index.
            - `ks_statistic`: The Kolmogorov-Smirnov distance.
            - `ks_pvalue`: The p-value from the KS test.
            - `has_drift`: Boolean flag if PSI >= psi_threshold.
            - `drift_level`: String enum ("none", "moderate", "severe").
    """
    if numeric_cols is None:
        numeric_cols = train_df.select_dtypes(include=[np.number]).columns.tolist()

    # Get common columns
    common_cols = [c for c in numeric_cols if c in train_df.columns and c in test_df.columns]

    results = {}
    for col in common_cols:
        psi = calculate_psi(train_df[col], test_df[col])
        ks_stat, ks_pval = calculate_ks(train_df[col], test_df[col])

        # Determine drift level
        if np.isnan(psi):
            drift_level = "unknown"
            has_drift = False
        elif psi >= 0.2:
            drift_level = "severe"
            has_drift = True
        elif psi >= psi_threshold:
            drift_level = "moderate"
            has_drift = True
        else:
            drift_level = "none"
            has_drift = False

        results[col] = {
            "psi": psi,
            "ks_statistic": ks_stat,
            "ks_pvalue": ks_pval,
            "has_drift": has_drift,
            "drift_level": drift_level,
        }

    return results


def get_drift_summary(drift_results: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """
    Summarize drift analysis results.

    Args:
        drift_results: Output from analyze_drift()

    Returns:
        Summary dictionary with counts and lists of drifted features
    """
    severe = [col for col, metrics in drift_results.items() if metrics["drift_level"] == "severe"]
    moderate = [
        col for col, metrics in drift_results.items() if metrics["drift_level"] == "moderate"
    ]

    return {
        "total_features": len(drift_results),
        "severe_drift_count": len(severe),
        "moderate_drift_count": len(moderate),
        "severe_drift_features": severe,
        "moderate_drift_features": moderate,
        "overall_status": "fail" if severe else ("warning" if moderate else "pass"),
    }
