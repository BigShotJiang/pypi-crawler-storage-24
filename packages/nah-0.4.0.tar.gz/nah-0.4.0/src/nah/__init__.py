"""nah: Context-aware safety guard for Claude Code."""

__version__ = "0.4.0"
