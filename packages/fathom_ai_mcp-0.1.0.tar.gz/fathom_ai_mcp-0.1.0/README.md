# Fathom MCP Server

An MCP server for the [Fathom AI](https://fathom.video) meeting intelligence API, built with [FastMCP](https://gofastmcp.com).

Responses are optimized for LLM consumption -- compact plaintext instead of raw JSON, with playback URLs stripped and transcripts chunked by time window.

## Tools

| Tool | Description |
|------|-------------|
| `list_meetings` | List meetings with filtering by date, team, domain, recorder, and pagination |
| `get_transcript` | Get transcript for a recording, with optional time-window chunking (`start_time`/`end_time`) |
| `get_summary` | Get the AI-generated summary for a recording (clean markdown, no playback URLs) |
| `list_teams` | List all teams |
| `list_team_members` | List team members, optionally filtered by team |

## Prerequisites

- [uv](https://docs.astral.sh/uv/getting-started/installation/) installed
- A Fathom API key (generate one in the **API Access** section of your [Fathom User Settings](https://fathom.video/settings))

## Quick Start

No cloning or installing required. Just add the server to your MCP client config:

### Claude Code

```bash
claude mcp add fathom -e FATHOM_API_KEY=your-api-key -- uvx fathom-ai-mcp
```

### Claude Desktop / Cursor / Windsurf

Add to your MCP config file:

- **Claude Desktop**: `~/Library/Application Support/Claude/claude_desktop_config.json` (macOS) or `%APPDATA%\Claude\claude_desktop_config.json` (Windows)
- **Cursor**: `.cursor/mcp.json` in your project root
- **Windsurf**: `~/.codeium/windsurf/mcp_config.json`

```json
{
  "mcpServers": {
    "fathom": {
      "command": "uvx",
      "args": ["fathom-ai-mcp"],
      "env": {
        "FATHOM_API_KEY": "your-api-key"
      }
    }
  }
}
```

### Environment Variables

| Variable | Required | Default | Description |
|----------|----------|---------|-------------|
| `FATHOM_API_KEY` | Yes | - | Your Fathom API key |
| `FATHOM_TIMEOUT` | No | `30` | HTTP request timeout in seconds |

## Development

```bash
git clone https://github.com/jerichosequitin/fathom-ai-mcp.git
cd fathom-ai-mcp
uv sync
uv run server.py
```

## License

MIT
