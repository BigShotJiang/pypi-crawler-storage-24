from ultralytics import YOLO
import cv2
import numpy as np
import os


class YoloSegmenter:

    def __init__(self, model_path, device="cpu"):
        self.device = device

        self.models = []
        self.names = {}

        if os.path.isdir(model_path):

            model_files = [
                os.path.join(model_path, f)
                for f in os.listdir(model_path)
                if f.endswith(".pt")
            ]

            if not model_files:
                raise ValueError(f"Nenhum modelo .pt encontrado em: {model_path}")

            for path in model_files:
                model = YOLO(path)
                self.models.append(model)

                for k, v in model.names.items():
                    self.names[k] = v

        else:
            model = YOLO(model_path)
            self.models.append(model)
            self.names = model.names

    def segment(self, frame, track=False):

        detections = []

        for model in self.models:

            if track:
                results = model.track(
                    frame,
                    device=self.device,
                    persist=True,
                    verbose=False
                )
            else:
                results = model(
                    frame,
                    device=self.device,
                    verbose=False
                )

            for r in results:

                boxes = r.boxes
                masks = r.masks

                if boxes is None:
                    continue

                classes = boxes.cls
                confs = boxes.conf
                xyxy = boxes.xyxy

                if hasattr(boxes, "id") and boxes.id is not None:
                    track_ids = boxes.id.int().cpu().tolist()
                else:
                    track_ids = [None] * len(classes)

                if masks is not None:

                    for mask, cls, conf, box, track_id in zip(
                        masks.data,
                        classes,
                        confs,
                        xyxy,
                        track_ids
                    ):

                        label = model.names[int(cls)]

                        mask = mask.cpu().numpy()
                        mask = cv2.resize(mask, (frame.shape[1], frame.shape[0]))
                        mask = (mask > 0.5).astype("uint8") * 255

                        x1, y1, x2, y2 = box.cpu().numpy().astype(int)

                        detections.append({
                            "label": label,
                            "confidence": float(conf),
                            "score": float(conf),
                            "mask": mask,
                            "bbox": {
                                "x1": int(x1),
                                "y1": int(y1),
                                "x2": int(x2),
                                "y2": int(y2)
                            },
                            "track_id": int(track_id) if track_id is not None else None
                        })

                else:

                    for box, cls, conf, track_id in zip(
                        xyxy,
                        classes,
                        confs,
                        track_ids
                    ):

                        label = model.names[int(cls)]

                        x1, y1, x2, y2 = box.cpu().numpy().astype(int)

                        mask = np.zeros(
                            (frame.shape[0], frame.shape[1]),
                            dtype="uint8"
                        )

                        cv2.rectangle(
                            mask,
                            (x1, y1),
                            (x2, y2),
                            255,
                            -1
                        )

                        detections.append({
                            "label": label,
                            "confidence": float(conf),
                            "score": float(conf),
                            "mask": mask,
                            "bbox": {
                                "x1": int(x1),
                                "y1": int(y1),
                                "x2": int(x2),
                                "y2": int(y2)
                            },
                            "track_id": int(track_id) if track_id is not None else None
                        })

        return detections