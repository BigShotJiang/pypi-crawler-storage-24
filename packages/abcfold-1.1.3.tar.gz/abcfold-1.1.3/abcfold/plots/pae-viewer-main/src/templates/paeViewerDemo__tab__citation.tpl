<div class="card-body">
    <div class="accordion" id="helpCite">
        <div class="accordion-item">
            <h2 class="accordion-header" id="helpCitationHeading">
                <button class="accordion-button collapsed" type="button"
                        data-bs-toggle="collapse" data-bs-target="#helpCitation"
                        aria-expanded="true" aria-controls="helpCitation">
                <span class="fw-bold">Citations</span>
                </button>
            </h2>
            <div id="helpCitation" class="accordion-collapse collapse"
                aria-labelledby="helpCitationHeading"
                data-bs-parent="#helpCite">
                <div class="accordion-body">

                <p>If you use ABCFold for your research, please cite the following papers:</p>

                <h5>ABCFold:</h5>
                <p>
                    <cite style="font-style: normal">
                        Elliott L and Simpkin A <i>et al</i>.
                        <br>
                        ABCFold: easier running and comparison of AlphaFold 3, Boltz-1, and Chai-1
                        <br>
                        Bioinformatic advances. 2025;5(1):vbaf153.
                        <br>
                        doi: <a href="https://doi.org/10.1093/bioadv/vbaf153" target="_blank">10.1038/s41586-024-07487-w</a>.
                        PMID: 40708869;
                        PMCID: <a href="https://pubmed.ncbi.nlm.nih.gov/40708869/" target="_blank">PMC11168924</a>.
                    </cite>
                </p>

                <h5>Alphafold3:</h5>
                <p>
                    <cite style="font-style: normal">
                        Abramson J, <i>et al</i>.
                        <br>
                        Accurate structure prediction of biomolecular interactions with AlphaFold 3
                        <br>
                        Nature. 2024 May 8;630:493-500.
                        <br>
                        doi: <a href="https://doi.org/10.1038/s41586-024-07487-w" target="_blank">10.1038/s41586-024-07487-w</a>.
                        PMID: 38718835;
                        PMCID: <a href="https://pubmed.ncbi.nlm.nih.gov/38718835/" target="_blank">PMC11168924</a>.
                    </cite>
                </p>

                <h5>Boltz:</h5>
                <p>
                    <cite style="font-style: normal">
                        Wohlwend J, <i>et al</i>.
                        <br>
                        Boltz-1: Democratizing Biomolecular Interaction Modeling.
                        <br>
                        BioRxiv [preprint]. 2024 Dec 27.
                        <br>
                        doi: <a href="https://doi.org/10.1101/2024.11.19.624167" target="_blank">10.1101/2024.11.19.624167</a>.
                        PMID: 39605745;
                        PMCID: <a href="http://www.ncbi.nlm.nih.gov/pmc/articles/39605745/" target="_blank">PMC11601547</a>.
                    </cite>
                </p>

                <h5>Chai-1:</h5>
                <p>
                    <cite style="font-style: normal">
                        Chai Discovery.
                        <br>
                        Chai-1: Decoding the molecular interactions of life.
                        <br>
                        BioRxiv [preprint]. 2024 Dec 27.
                        <br>
                        doi: <a href="https://doi.org/10.1101/2024.10.10.615955" target="_blank">10.1101/2024.10.10.615955</a>.
                    </cite>
                </p>

                <h5>OpenFold3:</h5>
                <p>
                    <cite style="font-style: normal">
                        The OpenFold3 Team.
                        <br>
                        OpenFold3-preview.
                        <br>
                        zenodo. 2025.
                        <br>
                        doi: <a href="https://doi.org/10.5281/zenodo.17485510" target="_blank">10.5281/zenodo.17485510</a>.
                    </cite>
                </p>

                <h5>Protenix:</h5>
                <p>
                    <cite style="font-style: normal">
                        ByteDance AML AI4Science Team and Chen X, <i>et al</i>.
                        <br>
                        Protenix - Advancing Structure Prediction Through a Comprehensive AlphaFold3 Reproduction.
                        <br>
                        BioRxiv [preprint]. 2025.
                        <br>
                        doi: <a href="https://doi.org/10.1101/2025.01.08.631967" target="_blank">10.1101/2025.01.08.631967</a>.
                    </cite>
                </p>

                <h5>ipSAE:</h5>
                <p>
                    <cite style="font-style: normal">
                        Dunbrack Jr. RL.
                        <br>
                        Rēs ipSAE loquunt: What’s wrong with AlphaFold’s ipTM score and how to fix it.
                        <br>
                        BioRxiv [preprint]. 2025.
                        <br>
                        doi: <a href="https://doi.org/10.1101/2025.02.10.637595" target="_blank">10.1101/2025.01.08.631967</a>.
                    </cite>
                </p>

                <h5>PAE Viewer:</h5>
                <p>
                    <cite style="font-style: normal">
                        Elfmann C, Stülke J.
                        <br>
                        PAE viewer: a webserver for the interactive visualization of the predicted
                        aligned error for multimer structure predictions and crosslinks.
                        <br>
                        Nucleic Acids Res. 2023 Jul 5;51(W1):W404-W410.
                        <br>
                        doi: <a href="https://doi.org/10.1093/nar/gkad350" target="_blank">10.1093/nar/gkad350</a>.
                        PMID: 37140053;
                        PMCID: <a href="http://www.ncbi.nlm.nih.gov/pmc/articles/pmc10320053/" target="_blank">PMC10320053</a>.
                    </cite>
                </p>
            </div>
        </div>
    </div>
</div>
