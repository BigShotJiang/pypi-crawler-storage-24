import logging
import logging.config
import json
from pathlib import Path
from typing import Dict, Any
from datetime import datetime, timezone

_logging_config: Dict[str, Any] = {}
_current_log_level = logging.INFO


def setup_logging() -> Dict[str, Any]:
    global _logging_config, _current_log_level

    current_dir = Path(__file__).parent.absolute()
    config_path = current_dir / "logging.json"

    if not config_path.exists():
        raise FileNotFoundError(f"Logging config not found at: {config_path}")

    with open(config_path, 'r', encoding='utf-8') as f:
        _logging_config = json.load(f)

    _current_log_level = _logging_config.get('root', {}).get('level', logging.INFO)
    if isinstance(_current_log_level, str):
        _current_log_level = logging.getLevelName(_current_log_level.upper())

    _apply_logging_config()
    return _logging_config


def _apply_logging_config():
    logging.config.dictConfig(_logging_config)

    for logger_name in logging.root.manager.loggerDict:
        logger = logging.getLogger(logger_name)
        if not logger.handlers:
            logger.setLevel(_current_log_level)


def set_log_level(level: str | int):
    global _current_log_level, _logging_config

    if isinstance(level, str):
        level = level.upper()
        try:
            level = logging.getLevelName(level) if level.isdigit() else getattr(logging, level)
        except AttributeError:
            raise ValueError(f"Invalid log level: {level}")

    if level not in (logging.DEBUG, logging.INFO, logging.WARNING, logging.ERROR, logging.CRITICAL):
        raise ValueError(f"Invalid log level value: {level}")

    _current_log_level = level
    if 'root' in _logging_config:
        _logging_config['root']['level'] = logging.getLevelName(level)

    _apply_logging_config()
    logging.info(f"Log level changed to {logging.getLevelName(level)}")


def get_log_level() -> str:
    return logging.getLevelName(_current_log_level)

class ColorFormatter(logging.Formatter):
    COLORS = {
        'timestamp': '\x1b[38;5;244m',  #浅灰色时间戳
        'debug': '\x1b[36m',  # Cyan
        'info': '\x1b[32m',  # Green
        'warning': '\x1b[33m',  # Yellow
        'error': '\x1b[31m',  # Red
        'critical': '\x1b[41;1m',  # 红色背景
        'module': '\x1b[38;5;33m',  # 亮蓝色
        'thread': '\x1b[38;5;33m',  # 亮蓝色
        'reset': '\x1b[0m'
    }

    def format(self, record):
        colors = {
            'timestamp': self.COLORS['timestamp'],
            'level': self.COLORS.get(record.levelname.lower(), ''),
            'module': self.COLORS['module'],
            'thread': self.COLORS['thread'],
            'reset': self.COLORS['reset']
        }

        timestamp = datetime.fromtimestamp(record.created, tz=timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.%f')[:23] + 'Z'

        message = self._format_message(record)

        log_template = (
            "{timestamp_color}{timestamp}{reset} "
            "[{level_color}{levelname}{reset}] "
            "{message} "
            "[{module_color}{module}{reset}] "
            "thread_name={thread_color}{thread}{reset}"
        )

        return log_template.format(
            timestamp_color=colors['timestamp'],
            timestamp=timestamp,
            reset=colors['reset'],
            level_color=colors['level'],
            levelname=record.levelname.lower(),
            message=message,
            module_color=colors['module'],
            module=record.module,
            thread_color=colors['thread'],
            thread=record.threadName
        )

    @staticmethod
    def _format_message(record):
        try:
            if record.args:
                if isinstance(record.args, (tuple, dict)):
                    return record.msg % record.args
                elif isinstance(record.args, dict):
                    return record.msg.format(**record.args)
        except Exception:
            pass
        return record.msg