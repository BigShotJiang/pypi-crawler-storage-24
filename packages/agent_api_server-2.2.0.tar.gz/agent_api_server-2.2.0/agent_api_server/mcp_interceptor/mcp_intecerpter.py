from langchain_mcp_adapters.interceptors import MCPToolCallRequest

async def inject_authorization(
    request: MCPToolCallRequest,
    handler,
):
    """Inject user credentials into MCP tool calls."""
    runtime = request.runtime
    authorization = runtime.context.ei_token
    tenant_id = runtime.context.ts_tenant

    if request.headers:
        headers = {**request.headers, "TSTenant": tenant_id, "Authorization": f"Bearer {authorization}"}
    else:
        headers = {"TSTenant": tenant_id, "Authorization": f"Bearer {authorization}"}
    # Add user context to tool arguments
    modified_request = request.override(
        headers={**headers}
    )
    return await handler(modified_request)