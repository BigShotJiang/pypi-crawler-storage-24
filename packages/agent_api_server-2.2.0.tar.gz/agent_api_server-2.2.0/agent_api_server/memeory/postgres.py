import os
import asyncio
import logging
import weakref
from typing import Optional, cast, Dict, Any
from psycopg_pool import AsyncConnectionPool
from psycopg.rows import dict_row
from psycopg import OperationalError, AsyncConnection
from agent_api_server.configs import global_config
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
)
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver
from langgraph.store.postgres import AsyncPostgresStore

logger = logging.getLogger(__name__)

class AsyncPostgresCheckpointer:
    _instances = weakref.WeakSet()
    _shutdown_lock = asyncio.Lock()
    _worker_instances = weakref.WeakValueDictionary()

    def __init__(self, max_retries: int = 3, retry_delay: float = 1.0):
        self.worker_pid = os.getpid()
        logger.info(
            f"Initializing checkpointer for worker {self.worker_pid} "
            f"(max_retries={max_retries}, retry_delay={retry_delay:.1f}s)"
        )

        self.conn_str = self._get_conn_str()
        self.pool: Optional[AsyncConnectionPool] = None
        self.saver: Optional[AsyncPostgresSaver] = None
        self.max_retries = max(max_retries, 1)
        self.retry_delay = max(retry_delay, 0.1)
        self._lock = asyncio.Lock()
        self._is_initialized = False

        # Connection pool configuration with validation
        self.pool_min_size = max(1, int(global_config.POSTGRES_POOL_MIN_SIZE))
        self.pool_max_size = max(self.pool_min_size, int(global_config.POSTGRES_POOL_MAX_SIZE))
        self.pool_timeout = max(1.0, float(global_config.POSTGRES_POOL_TIMEOUT))
        self.pool_recycle = max(60, int(global_config.POSTGRES_POOL_RECYCLE))

        logger.debug(
            f"Worker {self.worker_pid} pool config: "
            f"min_size={self.pool_min_size}, max_size={self.pool_max_size}, "
            f"timeout={self.pool_timeout:.1f}, recycle={self.pool_recycle}"
        )

        AsyncPostgresCheckpointer._instances.add(self)
        AsyncPostgresCheckpointer._worker_instances[self.worker_pid] = self
        logger.debug(f"New checkpointer instance registered for worker {self.worker_pid}")

    @classmethod
    def get_worker_instance(cls) -> 'AsyncPostgresCheckpointer':
        """Get or create instance for current worker process"""
        worker_pid = os.getpid()
        if worker_pid not in cls._worker_instances:
            instance = cls()
            cls._worker_instances[worker_pid] = instance
            logger.debug(f"Created new checkpointer instance for worker {worker_pid}")
        return cls._worker_instances[worker_pid]

    @classmethod
    async def close_worker_instance(cls):
        """Close instance for current worker process"""
        worker_pid = os.getpid()
        if worker_pid in cls._worker_instances:
            instance = cls._worker_instances.pop(worker_pid)
            await instance.close()

    @staticmethod
    def _get_conn_str() -> str:
        """获取安全的连接字符串（隐藏密码）"""
        conn_str = global_config.POSTGRES_URL
        safe_conn_str = conn_str.split('@')[0] + '@[REDACTED]' if '@' in conn_str else conn_str
        logger.debug("Using connection string: %s", safe_conn_str)
        return conn_str

    @classmethod
    async def close_all(cls):
        logger.info("Initiating shutdown of all checkpointer instances")

        async with cls._shutdown_lock:
            instances = list(cls._instances)
            if not instances:
                logger.debug("No active instances to close")
                return

            logger.debug("Closing %d active instance(s)", len(instances))
            for instance in instances:
                try:
                    await instance.close()
                    logger.debug("Instance closed successfully")
                except Exception as e:
                    logger.warning(
                        "Error closing instance: %s",
                        str(e),
                        exc_info=logger.isEnabledFor(logging.DEBUG)
                    )

    async def initialize(self) -> None:
        """Initialize connection pool and database schema"""
        async with self._lock:
            if self._is_initialized:
                logger.debug("Already initialized, skipping")
                return

            logger.info("Starting connection pool initialization")

            try:
                self.pool = AsyncConnectionPool(
                    self.conn_str,
                    min_size=self.pool_min_size,
                    max_size=self.pool_max_size,
                    timeout=self.pool_timeout,
                    open=False,
                    kwargs={"row_factory": dict_row},
                )
                logger.debug("Connection pool created")

                await self.pool.open()
                logger.debug("Connection pool opened")

                pool_with_dict_conn = cast(AsyncConnectionPool[AsyncConnection[Dict[str, Any]]], self.pool)
                self.saver = AsyncPostgresSaver(pool_with_dict_conn)
                self._is_initialized = True
                logger.info("Checkpointer initialized successfully")

            except Exception as e:
                logger.error("Initialization failed", exc_info=True)
                await self._safe_close()
                raise RuntimeError("Checkpointer initialization failed") from e

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=4, max=10),
        retry=retry_if_exception_type(OperationalError),
        before_sleep=lambda _: logger.warning("Retrying schema initialization..."),
    )
    async def initialize_schema_with_retry(self):
        logger.debug("Starting schema initialization")

        async with self.pool.connection() as conn:
            try:
                await conn.set_autocommit(True)
                logger.debug("Autocommit enabled for schema setup")

                await AsyncPostgresStore(conn).setup()
                await AsyncPostgresSaver(conn).setup()
                logger.debug("Schema setup completed")

            finally:
                await conn.set_autocommit(False)
                logger.debug("Autocommit restored to default")

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=1, max=10),
        retry=retry_if_exception_type(OperationalError),
    )
    async def checkpointer(self) -> AsyncPostgresSaver | None:
        if not self._is_initialized or self.saver is None:
            logger.debug("Checkpointer not ready, initializing...")
            await self.initialize()
            return self.saver

        try:
            async with self.pool.connection() as conn:
                await conn.execute("SELECT 1")  # 简单心跳检测
        except OperationalError:
            logger.warning("Connection pool invalid, reinitializing...")
            await self._safe_close()
            await self.initialize()

        return self.saver

    async def _safe_close(self) -> None:
        logger.debug("Starting safe cleanup")

        if self.pool:
            try:
                if not self.pool.closed:
                    await self.pool.close()
            except Exception as e:
                logger.warning(f"Error closing pool with an error {str(e)}", exc_info=True)

        self.pool = None
        self.saver = None
        self._is_initialized = False
        logger.info("Resources cleaned up")

    async def close(self) -> None:
        """关闭所有连接并清理资源"""
        async with self._lock:
            if not self._is_initialized:
                logger.debug("Already closed, skipping")
                return

            logger.info("Starting graceful shutdown")

            try:
                if self.pool and not self.pool.closed:
                    logger.debug("Closing connection pool gracefully")
                    await self.pool.close()
                    logger.info("Connection pool closed gracefully")

            except Exception as e:
                logger.error(
                    "Error during shutdown: %s",
                    str(e),
                    exc_info=logger.isEnabledFor(logging.DEBUG)
                )
            finally:
                await self._safe_close()
                AsyncPostgresCheckpointer._instances.discard(self)
                logger.debug("Instance unregistered")

    async def __aenter__(self) -> AsyncPostgresSaver:
        logger.debug("Entering context manager")
        await self.initialize()
        return await self.checkpointer()

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        logger.debug("Exiting context manager")
        await self.close()

    @property
    def is_initialized(self):
        return self._is_initialized