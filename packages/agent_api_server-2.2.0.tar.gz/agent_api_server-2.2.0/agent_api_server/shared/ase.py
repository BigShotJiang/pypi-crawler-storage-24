import base64
import hashlib
import os

from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes


class AESCipher:
    def __init__(self, key_string):
        self.key = hashlib.sha256(key_string.encode()).digest()
        self.backend = default_backend()

    def encrypt(self, plaintext):
        iv = os.urandom(16)
        plaintext_bytes = plaintext.encode("utf-8")

        encryptor = Cipher(algorithms.AES(self.key), modes.CBC(iv), backend=self.backend).encryptor()
        padder = self._create_padder()

        padded_plaintext = padder.update(plaintext_bytes) + padder.finalize()
        ciphertext = encryptor.update(padded_plaintext) + encryptor.finalize()
        encrypted_data = base64.b64encode(iv + ciphertext).decode("utf-8")

        return encrypted_data

    def decrypt(self, encrypted_data):
        try:
            encrypted_bytes = base64.b64decode(encrypted_data)

            iv = encrypted_bytes[:16]
            ciphertext = encrypted_bytes[16:]

            decryptor = Cipher(algorithms.AES(self.key), modes.CBC(iv), backend=self.backend).decryptor()
            padded_plaintext = decryptor.update(ciphertext) + decryptor.finalize()

            unpadder = self._create_unpadder()
            plaintext_bytes = unpadder.update(padded_plaintext) + unpadder.finalize()

            plaintext = plaintext_bytes.decode("utf-8")

            return plaintext
        except Exception as e:
            raise ValueError(f"Decryption failed: {str(e)}")

    @staticmethod
    def _create_padder():
        from cryptography.hazmat.primitives.padding import PKCS7
        return PKCS7(algorithms.AES.block_size).padder()

    @staticmethod
    def _create_unpadder():
        from cryptography.hazmat.primitives.padding import PKCS7
        return PKCS7(algorithms.AES.block_size).unpadder()
