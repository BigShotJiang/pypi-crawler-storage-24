from __future__ import annotations
from typing import Dict, Set
from enum import Enum


class ConfigCategory(Enum):
    CHAT_PROVIDER = "CHAT_PROVIDER"
    CHAT_MODEL = "CHAT_MODEL"
    CHAT_CREDENTIALS = "CHAT_CREDENTIALS"

    EMBEDDING_PROVIDER = "EMBEDDING_PROVIDER"
    EMBEDDING_MODEL = "EMBEDDING_MODEL"
    EMBEDDING_CREDENTIALS = "EMBEDDING_CREDENTIALS"

    RERANK_PROVIDER = "RERANK_PROVIDER"
    RERANK_MODEL = "RERANK_MODEL"
    RERANK_CREDENTIALS = "RERANK_CREDENTIALS"

    AGENT_ID = "AGENT_ID"

MODEL_SUFFIX_MAP = {
    "CHAT_PROVIDER": "llm",
    "EMBEDDING_PROVIDER": "text-embedding",
    "RERANK_PROVIDER": "rerank",
}

PROVIDER_FIELDS = {
    ConfigCategory.CHAT_PROVIDER.value: "llm",
    ConfigCategory.EMBEDDING_PROVIDER.value: "text-embedding",
    ConfigCategory.RERANK_PROVIDER.value: "rerank"
}

def process_model_from_config_dict(input_dict: Dict) -> Dict:
    result = {
        "models": {},
        "required": {}
    }

    if input_dict is None:
        return result

    properties = input_dict.get('properties', {})

    tool_model_map: Dict[str, Set[str]] = {}

    for prop_name, prop_def in properties.items():
        prop_name_upper = prop_name.upper()

        if prop_name_upper in PROVIDER_FIELDS:
            tool_name = "default"
            model_type = PROVIDER_FIELDS[prop_name_upper]
            if tool_name not in tool_model_map:
                tool_model_map[tool_name] = set()
            tool_model_map[tool_name].add(model_type)
            continue

        if prop_name_upper.endswith("_CHAT_PROVIDER"):
            tool_name = prop_name_upper[:-len("_CHAT_PROVIDER")].lower()
            if not tool_name:
                tool_name = "default"
            model_type = "llm"
        elif prop_name_upper.endswith("_EMBEDDING_PROVIDER"):
            tool_name = prop_name_upper[:-len("_EMBEDDING_PROVIDER")].lower()
            if not tool_name:
                tool_name = "default"
            model_type = "text-embedding"
        elif prop_name_upper.endswith("_RERANK_PROVIDER"):
            tool_name = prop_name_upper[:-len("_RERANK_PROVIDER")].lower()
            if not tool_name:
                tool_name = "default"
            model_type = "rerank"
        else:
            continue

        if tool_name:
            if tool_name not in tool_model_map:
                tool_model_map[tool_name] = set()
            tool_model_map[tool_name].add(model_type)

    standard_fields = ['CHAT_PROVIDER', 'EMBEDDING_PROVIDER']
    for field in standard_fields:
        if field in properties:
            tool_name = "default"
            model_type = "llm" if field == "CHAT_PROVIDER" else "text-embedding"
            if tool_name not in tool_model_map:
                tool_model_map[tool_name] = set()
            tool_model_map[tool_name].add(model_type)

    if not tool_model_map:
        for prop_name in properties.keys():
            prop_name_upper = prop_name.upper()
            if 'CHAT' in prop_name_upper and 'PROVIDER' in prop_name_upper:
                tool_name = "default"
                model_type = "llm"
                if tool_name not in tool_model_map:
                    tool_model_map[tool_name] = set()
                tool_model_map[tool_name].add(model_type)
            elif 'EMBEDDING' in prop_name_upper and 'PROVIDER' in prop_name_upper:
                tool_name = "default"
                model_type = "text-embedding"
                if tool_name not in tool_model_map:
                    tool_model_map[tool_name] = set()
                tool_model_map[tool_name].add(model_type)

    for tool, model_types in tool_model_map.items():
        model_list = list(model_types)
        result['models'][tool] = model_list
        result['required'][tool] = model_list.copy()

    return result