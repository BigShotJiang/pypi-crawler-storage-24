from langchain_core.language_models import BaseChatModel
from langchain_openai import ChatOpenAI
from llm_sdk.llm import ModelInstance
from llm_sdk.model_providers.base import ConfigType
from pydantic import SecretStr

from agent_api_server.dynamic_llm.dynamic_llm import DynamicLLM
from agent_api_server.schema.context import Context

def get_init_model()->BaseChatModel:
    """
    Get the initial chat model instance.
    """
    return ChatOpenAI(
        model="gpt-4o-2024-05-13",
        max_tokens=20000,
        api_key=SecretStr("xxx")
    )

def get_chat_model_instance(context: Context)-> ModelInstance:
    """"
    Get the chat model instance for the given context.
    """

    dynamic_llm = DynamicLLM(tool_name="default",config_type=ConfigType.CHAT,use_sys_llm=context.use_system_llm)

    llm_config = {
        "agent_id":context.graph_name,
        "ts_tenant":context.ts_tenant,
        "provider":context.config.get(dynamic_llm._get_config_key("PROVIDER", context.ts_tenant)),
        "model": context.config.get(dynamic_llm._get_config_key("MODEL", context.ts_tenant)),
        "credentials": context.config.get(dynamic_llm._get_config_key("CREDENTIALS", context.ts_tenant)),
    }
    with dynamic_llm._get_model_instance(llm_config,config={}) as model_instance:
        return model_instance


def get_model_credentials(context: Context)-> dict:
    """
    Get the model credentials for the given context.
    """
    model_instance = get_chat_model_instance(context)
    return model_instance.unified_credential()
