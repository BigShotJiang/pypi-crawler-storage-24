import unittest
from service_hub import (
    ServiceHubCredentialParser,
    ServiceHubCredentials,
    PostgresCredential,
    RedisCredential,
    BlobstoreCredential,
    CredentialNotFoundError,
    InvalidCredentialError
)


class TestServiceHubCredentialParser(unittest.TestCase):
    def test_parse_postgres(self):
        data = {
            "postgresql": [{
                "async": False,
                "binding_name": "iothub",
                "credentials": {
                    "database": "iothub-qa",
                    "externalHosts": "10.1.17.126:5432",
                    "host": "10.1.17.126",
                    "internalHosts": "10.1.17.126:5432",
                    "password": "i1t5ykL3Voh7zy8OcOq1XLiGp",
                    "port": 5432,
                    "uri": "postgres://c800e6b9-1061-42ce-8517-b534ecce095e:i1t5ykL3Voh7zy8OcOq1XLiGp@10.1.17.126:5432/iothub-qa",
                    "username": "c800e6b9-1061-42ce-8517-b534ecce095e"
                },
                "instance_name": "PostgreSQL-APPBUY",
                "label": "PostgreSQL",
                "plan": "Dedicated-Single-Small",
                "serviceInstanceId": "acd174dd-4098-4967-a492-b336337f8d0a",
                "subscriptionId": "2425c243ebd369a03381439378ac78b4"
            }]
        }

        credentials = ServiceHubCredentialParser.parse(data)
        self.assertEqual(len(credentials.postgres), 1)
        self.assertEqual(credentials.postgres[0].database, "iothub-qa")
        self.assertEqual(credentials.postgres[0].uri,
                         "postgres://c800e6b9-1061-42ce-8517-b534ecce095e:i1t5ykL3Voh7zy8OcOq1XLiGp@10.1.17.126:5432/iothub-qa")

    def test_parse_redis(self):
        data = {
            "redis": [{
                "binding_name": "fms",
                "credentials": {
                    "externalHosts": "",
                    "host": "redis-6a3adc0c-05ad-44ab-a780-ee943ff7808e-master.wiseiot.svc",
                    "internalHosts": "redis-6a3adc0c-05ad-44ab-a780-ee943ff7808e-master.wiseiot.svc",
                    "password": "xxxxx",
                    "port": 6379
                },
                "instance_name": "Redis",
                "label": "Redis",
                "plan": "Containerized-V2",
                "serviceInstanceId": "6a3adc0c-05ad-44ab-a780-ee943ff7808e",
                "subscriptionId": "77cc3194-b37a-5c91-9063-99c82e57b385"
            }]
        }

        credentials = ServiceHubCredentialParser.parse(data)
        self.assertEqual(len(credentials.redis), 1)
        self.assertEqual(credentials.redis[0].host, "redis-6a3adc0c-05ad-44ab-a780-ee943ff7808e-master.wiseiot.svc")
        self.assertEqual(credentials.redis[0].port, 6379)

    def test_parse_redis_with_username(self):
        data = {
            "redis": [{
                "binding_name": "fms",
                "credentials": {
                    "externalHosts": "",
                    "host": "redis.example.com",
                    "internalHosts": "redis.internal.example.com",
                    "password": "pass123",
                    "username": "user1",
                    "port": 6379
                }
            }]
        }

        credentials = ServiceHubCredentialParser.parse(data)
        self.assertEqual(len(credentials.redis), 1)
        self.assertEqual(credentials.redis[0].username, "user1")

    def test_parse_blobstore(self):
        """Test parsing blobstore credentials"""
        data = {
            "blobstore": [{
                "binding_name": "storage",
                "credentials": {
                    "accessKey": "AKIAIOSFODNN7EXAMPLE",
                    "secretKey": "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
                    "endpoint": "https://s3.example.com",
                    "externalHosts": "s3.example.com",
                    "internalHosts": "s3.internal.example.com",
                    "signature-version": "s3v4",
                    "type": "s3"
                },
                "instance_name": "Blobstore-Example",
                "label": "Blobstore",
                "plan": "Standard",
                "serviceInstanceId": "12345678-1234-1234-1234-123456789012",
                "subscriptionId": "abcdef123456"
            }]
        }

        credentials = ServiceHubCredentialParser.parse(data)
        self.assertEqual(len(credentials.blobstore), 1)
        blobstore_cred = credentials.blobstore[0]
        self.assertEqual(blobstore_cred.binding_name, "storage")
        self.assertEqual(blobstore_cred.access_key, "AKIAIOSFODNN7EXAMPLE")
        self.assertEqual(blobstore_cred.secret_key, "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY")
        self.assertEqual(blobstore_cred.endpoint, "https://s3.example.com")
        self.assertEqual(blobstore_cred.external_hosts, "s3.example.com")
        self.assertEqual(blobstore_cred.internal_hosts, "s3.internal.example.com")
        self.assertEqual(blobstore_cred.signature_version, "s3v4")
        self.assertEqual(blobstore_cred.type, "s3")
        self.assertEqual(blobstore_cred.instance_name, "Blobstore-Example")
        self.assertEqual(blobstore_cred.service_instance_id, "12345678-1234-1234-1234-123456789012")

    def test_parse_blobstore_with_minimal_fields(self):
        """Test parsing blobstore with minimal required fields"""
        data = {
            "blobstore": [{
                "binding_name": "minimal-storage",
                "credentials": {
                    "accessKey": "minimal-access-key",
                    "secretKey": "minimal-secret-key",
                    "endpoint": "https://minimal.s3.com",
                    "externalHosts": "minimal.s3.com",
                    "internalHosts": "minimal.internal.s3.com",
                    "signature-version": "s3",
                    "type": "s3"
                }
            }]
        }

        credentials = ServiceHubCredentialParser.parse(data)
        self.assertEqual(len(credentials.blobstore), 1)
        blobstore_cred = credentials.blobstore[0]
        self.assertEqual(blobstore_cred.binding_name, "minimal-storage")
        self.assertEqual(blobstore_cred.access_key, "minimal-access-key")
        self.assertEqual(blobstore_cred.secret_key, "minimal-secret-key")
        self.assertEqual(blobstore_cred.endpoint, "https://minimal.s3.com")
        # 测试默认值
        self.assertEqual(blobstore_cred.instance_name, "")
        self.assertEqual(blobstore_cred.service_instance_id, "")

    def test_parse_multiple_blobstores(self):
        """Test parsing multiple blobstore entries"""
        data = {
            "blobstore": [
                {
                    "binding_name": "storage1",
                    "credentials": {
                        "accessKey": "key1",
                        "secretKey": "secret1",
                        "endpoint": "https://s3-1.example.com",
                        "externalHosts": "s3-1.example.com",
                        "internalHosts": "s3-1.internal.example.com",
                        "signature-version": "s3v4",
                        "type": "s3"
                    }
                },
                {
                    "binding_name": "storage2",
                    "credentials": {
                        "accessKey": "key2",
                        "secretKey": "secret2",
                        "endpoint": "https://s3-2.example.com",
                        "externalHosts": "s3-2.example.com",
                        "internalHosts": "s3-2.internal.example.com",
                        "signature-version": "s3",
                        "type": "s3"
                    }
                }
            ]
        }

        credentials = ServiceHubCredentialParser.parse(data)
        self.assertEqual(len(credentials.blobstore), 2)
        self.assertEqual(credentials.blobstore[0].binding_name, "storage1")
        self.assertEqual(credentials.blobstore[1].binding_name, "storage2")
        self.assertEqual(credentials.blobstore[0].access_key, "key1")
        self.assertEqual(credentials.blobstore[1].access_key, "key2")

    def test_parse_all_service_types(self):
        data = {
            "postgresql": [{
                "binding_name": "db",
                "credentials": {
                    "database": "testdb",
                    "host": "localhost",
                    "internalHosts": "localhost:5432",
                    "password": "dbpass",
                    "port": 5432,
                    "username": "dbuser"
                }
            }],
            "redis": [{
                "binding_name": "cache",
                "credentials": {
                    "host": "localhost",
                    "internalHosts": "localhost:6379",
                    "password": "redpass",
                    "port": 6379
                }
            }],
            "blobstore": [{
                "binding_name": "storage",
                "credentials": {
                    "accessKey": "test-key",
                    "secretKey": "test-secret",
                    "endpoint": "https://test.s3.com",
                    "externalHosts": "test.s3.com",
                    "internalHosts": "test.internal.s3.com",
                    "signature-version": "s3v4",
                    "type": "s3"
                }
            }]
        }

        credentials = ServiceHubCredentialParser.parse(data)
        self.assertEqual(len(credentials.postgres), 1)
        self.assertEqual(len(credentials.redis), 1)
        self.assertEqual(len(credentials.blobstore), 1)
        self.assertEqual(credentials.postgres[0].database, "testdb")
        self.assertEqual(credentials.redis[0].host, "localhost")
        self.assertEqual(credentials.blobstore[0].access_key, "test-key")

    def test_parse_invalid_json(self):
        with self.assertRaises(InvalidCredentialError):
            ServiceHubCredentialParser.parse("invalid json")

    def test_parse_invalid_data_type(self):
        with self.assertRaises(InvalidCredentialError):
            ServiceHubCredentialParser.parse(["not", "a", "dict"])

    def test_parse_json_string(self):
        json_str = '''
        {
            "blobstore": [{
                "binding_name": "json-string-storage",
                "credentials": {
                    "accessKey": "json-key",
                    "secretKey": "json-secret",
                    "endpoint": "https://json.s3.com",
                    "externalHosts": "json.s3.com",
                    "internalHosts": "json.internal.s3.com",
                    "signature-version": "s3v4",
                    "type": "s3"
                }
            }]
        }
        '''
        credentials = ServiceHubCredentialParser.parse(json_str)
        self.assertEqual(len(credentials.blobstore), 1)
        self.assertEqual(credentials.blobstore[0].binding_name, "json-string-storage")

    def test_parse_json_bytes(self):
        json_bytes = b'''{
            "blobstore": [{
                "binding_name": "bytes-storage",
                "credentials": {
                    "accessKey": "bytes-key",
                    "secretKey": "bytes-secret",
                    "endpoint": "https://bytes.s3.com",
                    "externalHosts": "bytes.s3.com",
                    "internalHosts": "bytes.internal.s3.com",
                    "signature-version": "s3v4",
                    "type": "s3"
                }
            }]
        }'''
        credentials = ServiceHubCredentialParser.parse(json_bytes)
        self.assertEqual(len(credentials.blobstore), 1)
        self.assertEqual(credentials.blobstore[0].binding_name, "bytes-storage")

    def test_parse_empty_data(self):
        credentials = ServiceHubCredentialParser.parse({})
        self.assertEqual(len(credentials.postgres), 0)
        self.assertEqual(len(credentials.redis), 0)
        self.assertEqual(len(credentials.blobstore), 0)


class TestServiceHubCredentials(unittest.TestCase):
    def setUp(self):
        self.postgres_cred = PostgresCredential(
            async_flag=False,
            binding_name="iothub",
            database="iothub-qa",
            external_hosts="10.1.17.126:5432",
            host="10.1.17.126",
            internal_hosts="10.1.17.126:5432",
            password="i1t5ykL3Voh7zy8OcOq1XLiGp",
            port=5432,
            uri="postgres://c800e6b9-1061-42ce-8517-b534ecce095e:i1t5ykL3Voh7zy8OcOq1XLiGp@10.1.17.126:5432/iothub-qa",
            username="c800e6b9-1061-42ce-8517-b534ecce095e",
            instance_name="PostgreSQL-APPBUY",
            label="PostgreSQL",
            plan="Dedicated-Single-Small",
            service_instance_id="acd174dd-4098-4967-a492-b336337f8d0a",
            subscription_id="2425c243ebd369a03381439378ac78b4"
        )

        self.redis_cred_with_password = RedisCredential(
            binding_name="fms",
            external_hosts="",
            host="redis-6a3adc0c-05ad-44ab-a780-ee943ff7808e-master.wiseiot.svc",
            internal_hosts="redis-6a3adc0c-05ad-44ab-a780-ee943ff7808e-master.wiseiot.svc",
            password="xxxxx",
            port=6379,
            instance_name="Redis",
            label="Redis",
            plan="Containerized-V2",
            service_instance_id="6a3adc0c-05ad-44ab-a780-ee943ff7808e",
            subscription_id="77cc3194-b37a-5c91-9063-99c82e57b385"
        )

        self.redis_cred_with_username_password = RedisCredential(
            binding_name="fms",
            external_hosts="",
            host="redis.example.com",
            internal_hosts="redis.internal.example.com",
            password="pass123",
            username="user1",
            port=6379
        )

        self.redis_cred_with_username_no_password = RedisCredential(
            binding_name="fms",
            external_hosts="",
            host="redis.example.com",
            internal_hosts="redis.internal.example.com",
            password="",
            username="user1",
            port=6379
        )

        self.redis_cred_no_auth = RedisCredential(
            binding_name="fms",
            external_hosts="",
            host="redis.example.com",
            internal_hosts="redis.internal.example.com",
            password="",
            username="",
            port=6379
        )

        self.blobstore_cred_full = BlobstoreCredential(
            binding_name="storage",
            access_key="AKIAIOSFODNN7EXAMPLE",
            secret_key="wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
            endpoint="https://s3.example.com",
            external_hosts="s3.example.com",
            internal_hosts="s3.internal.example.com",
            signature_version="s3v4",
            type="s3",
            instance_name="Blobstore-Example",
            label="Blobstore",
            plan="Standard",
            service_instance_id="12345678-1234-1234-1234-123456789012",
            subscription_id="abcdef123456"
        )

        self.blobstore_cred_minimal = BlobstoreCredential(
            binding_name="minimal-storage",
            access_key="minimal-access-key",
            secret_key="minimal-secret-key",
            endpoint="https://minimal.s3.com",
            external_hosts="minimal.s3.com",
            internal_hosts="minimal.internal.s3.com",
            signature_version="s3",
            type="s3"
        )

    def test_to_postgres_dsn(self):
        credentials = ServiceHubCredentials(postgres=[self.postgres_cred])
        dsn = credentials.to_postgres_dsn()
        expected = "postgresql://c800e6b9-1061-42ce-8517-b534ecce095e:i1t5ykL3Voh7zy8OcOq1XLiGp@10.1.17.126:5432/iothub-qa"
        self.assertEqual(dsn, expected)

    def test_to_postgres_dsn_no_credentials(self):
        credentials = ServiceHubCredentials()
        with self.assertRaises(CredentialNotFoundError) as context:
            credentials.to_postgres_dsn()
        self.assertIn("PostgreSQL credentials not found", str(context.exception))

    def test_to_redis_dsn_with_password(self):
        credentials = ServiceHubCredentials(redis=[self.redis_cred_with_password])
        dsn = credentials.to_redis_dsn()
        expected = "redis://:xxxxx@redis-6a3adc0c-05ad-44ab-a780-ee943ff7808e-master.wiseiot.svc:6379"
        self.assertEqual(dsn, expected)

    def test_to_redis_dsn_with_username_password(self):
        credentials = ServiceHubCredentials(redis=[self.redis_cred_with_username_password])
        dsn = credentials.to_redis_dsn()
        expected = "redis://user1:pass123@redis.internal.example.com:6379"
        self.assertEqual(dsn, expected)

    def test_to_redis_dsn_with_username_no_password(self):
        credentials = ServiceHubCredentials(redis=[self.redis_cred_with_username_no_password])
        dsn = credentials.to_redis_dsn()
        expected = "redis://user1@redis.internal.example.com:6379"
        self.assertEqual(dsn, expected)

    def test_to_redis_dsn_no_auth(self):
        credentials = ServiceHubCredentials(redis=[self.redis_cred_no_auth])
        dsn = credentials.to_redis_dsn()
        expected = "redis://redis.internal.example.com:6379"
        self.assertEqual(dsn, expected)

    def test_to_redis_dsn_no_credentials(self):
        credentials = ServiceHubCredentials()
        with self.assertRaises(CredentialNotFoundError) as context:
            credentials.to_redis_dsn()
        self.assertIn("Redis credentials not found", str(context.exception))

    def test_get_blobstore_s3_config_full(self):
        credentials = ServiceHubCredentials(blobstore=[self.blobstore_cred_full])
        config = credentials.get_blobstore_s3_config()

        expected = {
            "access_key": "AKIAIOSFODNN7EXAMPLE",
            "secret_key": "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY",
            "endpoint": "https://s3.example.com",
            "external_hosts": "s3.example.com",
            "internal_hosts": "s3.internal.example.com",
            "signature_version": "s3v4",
            "type": "s3"
        }

        self.assertEqual(config, expected)
        self.assertEqual(config["access_key"], "AKIAIOSFODNN7EXAMPLE")
        self.assertEqual(config["secret_key"], "wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY")
        self.assertEqual(config["endpoint"], "https://s3.example.com")

    def test_get_blobstore_s3_config_minimal(self):
        """Test getting minimal blobstore S3 configuration"""
        credentials = ServiceHubCredentials(blobstore=[self.blobstore_cred_minimal])
        config = credentials.get_blobstore_s3_config()

        expected = {
            "access_key": "minimal-access-key",
            "secret_key": "minimal-secret-key",
            "endpoint": "https://minimal.s3.com",
            "external_hosts": "minimal.s3.com",
            "internal_hosts": "minimal.internal.s3.com",
            "signature_version": "s3",
            "type": "s3"
        }

        self.assertEqual(config, expected)
        self.assertEqual(config["access_key"], "minimal-access-key")
        self.assertEqual(config["secret_key"], "minimal-secret-key")
        self.assertEqual(config["signature_version"], "s3")

    def test_get_blobstore_s3_config_no_credentials(self):
        credentials = ServiceHubCredentials()
        with self.assertRaises(CredentialNotFoundError) as context:
            credentials.get_blobstore_s3_config()
        self.assertIn("Blobstore credentials not found", str(context.exception))

    def test_get_blobstore_s3_config_multiple_blobstores(self):
        blobstore1 = BlobstoreCredential(
            binding_name="first",
            access_key="first-key",
            secret_key="first-secret",
            endpoint="https://first.s3.com",
            external_hosts="first.s3.com",
            internal_hosts="first.internal.s3.com",
            signature_version="s3v4",
            type="s3"
        )

        blobstore2 = BlobstoreCredential(
            binding_name="second",
            access_key="second-key",
            secret_key="second-secret",
            endpoint="https://second.s3.com",
            external_hosts="second.s3.com",
            internal_hosts="second.internal.s3.com",
            signature_version="s3",
            type="s3"
        )

        credentials = ServiceHubCredentials(blobstore=[blobstore1, blobstore2])
        config = credentials.get_blobstore_s3_config()

        self.assertEqual(config["access_key"], "first-key")
        self.assertEqual(config["secret_key"], "first-secret")
        self.assertEqual(config["endpoint"], "https://first.s3.com")
        self.assertEqual(config["signature_version"], "s3v4")

    def test_get_service_instance_id_from_postgres(self):
        credentials = ServiceHubCredentials(postgres=[self.postgres_cred])
        instance_id = credentials.get_service_instance_id()
        self.assertEqual(instance_id, "acd174dd-4098-4967-a492-b336337f8d0a")

    def test_get_service_instance_id_from_redis(self):
        credentials = ServiceHubCredentials(redis=[self.redis_cred_with_password])
        instance_id = credentials.get_service_instance_id()
        self.assertEqual(instance_id, "6a3adc0c-05ad-44ab-a780-ee943ff7808e")

    def test_get_service_instance_id_from_blobstore(self):
        credentials = ServiceHubCredentials(blobstore=[self.blobstore_cred_full])
        instance_id = credentials.get_service_instance_id()
        self.assertEqual(instance_id, "12345678-1234-1234-1234-123456789012")

    def test_get_service_instance_id_precedence(self):
        blobstore_without_id = BlobstoreCredential(
            binding_name="no-id-storage",
            access_key="key",
            secret_key="secret",
            endpoint="https://s3.com",
            external_hosts="s3.com",
            internal_hosts="s3.internal.com",
            signature_version="s3v4",
            type="s3"
        )

        credentials1 = ServiceHubCredentials(blobstore=[blobstore_without_id])
        with self.assertRaises(CredentialNotFoundError):
            credentials1.get_service_instance_id()

        credentials2 = ServiceHubCredentials(
            redis=[self.redis_cred_with_password],
            blobstore=[blobstore_without_id]
        )
        instance_id2 = credentials2.get_service_instance_id()
        self.assertEqual(instance_id2, "6a3adc0c-05ad-44ab-a780-ee943ff7808e")

        credentials3 = ServiceHubCredentials(
            postgres=[self.postgres_cred],
            redis=[self.redis_cred_with_password],
            blobstore=[self.blobstore_cred_full]
        )
        instance_id3 = credentials3.get_service_instance_id()
        self.assertEqual(instance_id3, "acd174dd-4098-4967-a492-b336337f8d0a")

    def test_get_service_instance_id_no_credentials(self):
        credentials = ServiceHubCredentials()
        with self.assertRaises(CredentialNotFoundError) as context:
            credentials.get_service_instance_id()
        self.assertIn("No service instance ID found", str(context.exception))

    def test_multiple_service_types_together(self):
        credentials = ServiceHubCredentials(
            postgres=[self.postgres_cred],
            redis=[self.redis_cred_with_password],
            blobstore=[self.blobstore_cred_full]
        )

        dsn = credentials.to_postgres_dsn()
        self.assertIn("postgresql://", dsn)

        redis_dsn = credentials.to_redis_dsn()
        self.assertIn("redis://", redis_dsn)

        blobstore_config = credentials.get_blobstore_s3_config()
        self.assertIn("access_key", blobstore_config)
        self.assertEqual(blobstore_config["access_key"], "AKIAIOSFODNN7EXAMPLE")

        instance_id = credentials.get_service_instance_id()
        self.assertEqual(instance_id, "acd174dd-4098-4967-a492-b336337f8d0a")

    def test_parse_blobstore_real_example(self):
        data = {
            "blobstore": [{
                "async": False,
                "binding_name": "ewm-axa-liding",
                "credentials": {
                    "accessKey": "bafH4uDnLYHNfZqcY9dTnvl5",
                    "endpoint": "minio.ensaas-db.svc.cluster.local:8999",
                    "externalHosts": "172.21.92.232:8999",
                    "internalHosts": "minio.ensaas-db.svc.cluster.local:8999",
                    "secretKey": "yJxEEEO2wUlf3ZmlsDHQp415",
                    "signatureVersion": "v2",
                    "type": "s3-compatible"
                },
                "instance_name": "Blobstore",
                "label": "Blobstore",
                "plan": "Standard",
                "serviceInstanceId": "75aebf90-d792-4992-8f5c-4ada33f32fd6",
                "subscriptionId": "1289a66b-5833-4ccd-830b-4b03ea1fc77a-axa.wise-paas.com.cn"
            }]
        }

        credentials = ServiceHubCredentialParser.parse(data)
        self.assertEqual(len(credentials.blobstore), 1)
        blobstore_cred = credentials.blobstore[0]

        # 验证基本字段
        self.assertEqual(blobstore_cred.binding_name, "ewm-axa-liding")
        self.assertEqual(blobstore_cred.instance_name, "Blobstore")
        self.assertEqual(blobstore_cred.label, "Blobstore")
        self.assertEqual(blobstore_cred.plan, "Standard")
        self.assertEqual(blobstore_cred.service_instance_id, "75aebf90-d792-4992-8f5c-4ada33f32fd6")
        self.assertEqual(blobstore_cred.subscription_id, "1289a66b-5833-4ccd-830b-4b03ea1fc77a-axa.wise-paas.com.cn")

        # 验证凭证字段
        self.assertEqual(blobstore_cred.access_key, "bafH4uDnLYHNfZqcY9dTnvl5")
        self.assertEqual(blobstore_cred.secret_key, "yJxEEEO2wUlf3ZmlsDHQp415")
        self.assertEqual(blobstore_cred.endpoint, "minio.ensaas-db.svc.cluster.local:8999")
        self.assertEqual(blobstore_cred.external_hosts, "172.21.92.232:8999")
        self.assertEqual(blobstore_cred.internal_hosts, "minio.ensaas-db.svc.cluster.local:8999")
        self.assertEqual(blobstore_cred.signature_version, "v2")
        self.assertEqual(blobstore_cred.type, "s3-compatible")

    def test_blobstore_credential_creation_real_example(self):
        """Test creating BlobstoreCredential with real example data"""
        blobstore_cred = BlobstoreCredential(
            binding_name="ewm-axa-liding",
            access_key="bafH4uDnLYHNfZqcY9dTnvl5",
            secret_key="yJxEEEO2wUlf3ZmlsDHQp415",
            endpoint="minio.ensaas-db.svc.cluster.local:8999",
            external_hosts="172.21.92.232:8999",
            internal_hosts="minio.ensaas-db.svc.cluster.local:8999",
            signature_version="v2",
            type="s3-compatible",
            instance_name="Blobstore",
            label="Blobstore",
            plan="Standard",
            service_instance_id="75aebf90-d792-4992-8f5c-4ada33f32fd6",
            subscription_id="1289a66b-5833-4ccd-830b-4b03ea1fc77a-axa.wise-paas.com.cn"
        )

        self.assertEqual(blobstore_cred.binding_name, "ewm-axa-liding")
        self.assertEqual(blobstore_cred.access_key, "bafH4uDnLYHNfZqcY9dTnvl5")
        self.assertEqual(blobstore_cred.secret_key, "yJxEEEO2wUlf3ZmlsDHQp415")
        self.assertEqual(blobstore_cred.endpoint, "minio.ensaas-db.svc.cluster.local:8999")
        self.assertEqual(blobstore_cred.signature_version, "v2")
        self.assertEqual(blobstore_cred.type, "s3-compatible")
        self.assertEqual(blobstore_cred.service_instance_id, "75aebf90-d792-4992-8f5c-4ada33f32fd6")

    def test_get_blobstore_s3_config_real_example(self):
        blobstore_cred = BlobstoreCredential(
            binding_name="ewm-axa-liding",
            access_key="bafH4uDnLYHNfZqcY9dTnvl5",
            secret_key="yJxEEEO2wUlf3ZmlsDHQp415",
            endpoint="minio.ensaas-db.svc.cluster.local:8999",
            external_hosts="172.21.92.232:8999",
            internal_hosts="minio.ensaas-db.svc.cluster.local:8999",
            signature_version="v2",
            type="s3-compatible",
            instance_name="Blobstore",
            label="Blobstore",
            plan="Standard",
            service_instance_id="75aebf90-d792-4992-8f5c-4ada33f32fd6",
            subscription_id="1289a66b-5833-4ccd-830b-4b03ea1fc77a-axa.wise-paas.com.cn"
        )

        credentials = ServiceHubCredentials(blobstore=[blobstore_cred])
        config = credentials.get_blobstore_s3_config()

        expected = {
            "access_key": "bafH4uDnLYHNfZqcY9dTnvl5",
            "secret_key": "yJxEEEO2wUlf3ZmlsDHQp415",
            "endpoint": "minio.ensaas-db.svc.cluster.local:8999",
            "external_hosts": "172.21.92.232:8999",
            "internal_hosts": "minio.ensaas-db.svc.cluster.local:8999",
            "signature_version": "v2",
            "type": "s3-compatible"
        }

        self.assertEqual(config, expected)
        self.assertEqual(config["signature_version"], "v2")
        self.assertEqual(config["type"], "s3-compatible")

    def test_parse_blobstore_with_signature_version_field(self):
        """Test parsing blobstore with 'signatureVersion' field (camelCase)"""
        data = {
            "blobstore": [{
                "async": False,
                "binding_name": "test-minio",
                "credentials": {
                    "accessKey": "test-access-key",
                    "secretKey": "test-secret-key",
                    "endpoint": "minio.local:9000",
                    "externalHosts": "minio.local:9000",
                    "internalHosts": "minio.internal:9000",
                    "signatureVersion": "v4",  # 注意：这是camelCase
                    "type": "s3-compatible"
                },
                "instance_name": "MinIO-Storage",
                "label": "Blobstore"
            }]
        }

        credentials = ServiceHubCredentialParser.parse(data)
        self.assertEqual(len(credentials.blobstore), 1)
        blobstore_cred = credentials.blobstore[0]

        self.assertEqual(blobstore_cred.signature_version, "v4")
        self.assertEqual(blobstore_cred.type, "s3-compatible")


if __name__ == '__main__':
    unittest.main()