import os
import base64
import json
import logging
from typing import List, Optional, Dict, Any

import httpx
from .sdk import SSOClient, get_sso_client_id_and_secret

logger = logging.getLogger(__name__)


class SSOConfig:
    def __init__(self, sso_address: str, client_id: str, client_secret: str):
        self.sso_address = sso_address
        self.client_id = client_id
        self.client_secret = client_secret


def get_client_info_by_client_token(token: str) -> Dict[str, Any]:
    parts = token.split(".")
    if len(parts) != 3:
        raise ValueError("Invalid token format")

    try:
        decoded = base64.urlsafe_b64decode(parts[1] + "==").decode("utf-8")
        info = json.loads(decoded)
        if info.get("tokenType") != "client":
            raise ValueError("Not a client token")
        return info
    except Exception as e:
        raise ValueError(f"Failed to decode token: {e}")


def is_client_token(token: str) -> bool:
    try:
        info = get_client_info_by_client_token(token)
        return info.get("tokenType") == "client"
    except ValueError:
        return False


def verify_client_token(token: str) -> None:
    info = get_client_info_by_client_token(token)
    if info.get("isOperation"):
        return

    if (
            info.get("namespace") == os.getenv("namespace")
            and info.get("workspace") == os.getenv("workspace")
            and info.get("datacenter") == os.getenv("datacenter")
    ):
        return
    raise ValueError("Invalid client token")


class SSOService:
    def __init__(self, sso_config: SSOConfig):
        self.sso_config = sso_config
        self.client_token = None

        # Initialize SSOClient
        self.sso_client = SSOClient()
        self.sso_config.client_id, self.sso_config.client_secret = get_sso_client_id_and_secret(
            sso_config.sso_address, ""
        )

    def get_client_token(self) -> Optional[str]:
        return self.client_token

    def verify_token(self, token: str) -> None:
        url = f"{self.sso_config.sso_address}/tokenvalidation"
        headers = {"Content-Type": "application/json"}
        data = {"Token": token}

        with httpx.Client() as client:
            response = client.post(url, headers=headers, json=data)
            if response.status_code != httpx.codes.OK:
                raise ValueError(f"Failed to verify SSO token: {response.text}")

    def get_user_info(self, token: str) -> Dict[str, Any]:
        url = f"{self.sso_config.sso_address}/users/me"
        headers = {"Authorization": f"Bearer {token}"}

        with httpx.Client() as client:
            response = client.get(url, headers=headers)
            if response.status_code != httpx.codes.OK:
                raise ValueError(f"Failed to get SSO user info: {response.text}")

            # 获取 JSON 数据
            user_info = response.json()
            return user_info

    def refresh_token(self, token: str) -> str:
        url = f"{self.sso_config.sso_address}/token"
        headers = {"Content-Type": "application/json"}
        data = {"token": token}

        with httpx.Client() as client:
            response = client.post(url, headers=headers, json=data)
            if response.status_code != httpx.codes.OK:
                raise ValueError(f"Failed to refresh SSO token: {response.text}")

            # 获取 JSON 数据
            token_data = response.json()
            return token_data.get("accessToken")

    def verify_username_password(self, username: str, password: str) -> tuple[List[Dict[str, Any]], str]:
        url = f"{self.sso_config.sso_address}/auth/native"
        headers = {"Content-Type": "application/json"}
        data = {"username": username, "password": password}

        with httpx.Client() as client:
            response = client.post(url, headers=headers, json=data)
            if response.status_code != httpx.codes.OK:
                raise ValueError(f"Failed to verify username/password: {response.text}")

            # 获取 JSON 数据
            response_data = response.json()
            access_token = response_data.get("accessToken")
            if not access_token:
                raise ValueError("Failed to get SSO token")

            # Simulate cookies (adjust as needed)
            cookies = [
                {"name": "SSOEINameCookie", "value": "sso", "path": "/"},
                {"name": "SSOEITokenCookie", "value": access_token, "path": "/", "httpOnly": True},
                {"name": "SSOWISEUserCookie", "value": username, "path": "/"},
            ]
            return cookies, access_token

    def username_to_user_id(self, username: str) -> str:
        url = f"{self.sso_config.sso_address}/users/userId/{username}"
        headers = {"Content-Type": "application/json"}

        with httpx.Client() as client:
            response = client.get(url, headers=headers)
            if response.status_code != httpx.codes.OK:
                raise ValueError(f"Failed to get user ID: {response.text}")

            # 获取 JSON 数据
            user_data = response.json()
            return user_data.get("userId")

    def check_username_existence(self, username: str) -> bool:
        url = f"{self.sso_config.sso_address}/validators/users/{username}"
        headers = {"Content-Type": "application/json"}

        with httpx.Client() as client:
            response = client.get(url, headers=headers)
            if response.status_code != httpx.codes.OK:
                raise ValueError(f"Failed to check username existence: {response.text}")

            # 获取 JSON 数据
            existence_data = response.json()
            return existence_data.get("existing")

    def generate_client_token(self, client_id: str, client_secret: str) -> str:
        url = f"{self.sso_config.sso_address}/oauth/token"
        params = {
            "grant_type": "client_credentials",
            "duration": "eternal",
            "client_id": client_id,
            "client_secret": client_secret,
        }

        with httpx.Client() as client:
            response = client.post(url, params=params)
            if response.status_code != httpx.codes.OK:
                raise ValueError(f"Failed to generate client token: {response.text}")

            # 获取 JSON 数据
            token_data = response.json()
            return token_data.get("accessToken")

    def get_client_id_and_secret(self) -> tuple[str, str]:
        return self.sso_config.client_id, self.sso_config.client_secret
