
_callbacks = []

def register_callback(callback):
    """
    注册一个回调函数
    """
    _callbacks.append(callback)

def notify_callbacks(**kwargs):
    """
    当模型配置更新时，通知所有注册的回调
    """
    for callback in _callbacks:
        try:
            callback(**kwargs)
        except Exception as e:
            print(f"[ERROR] Callback execution failed: {e}")