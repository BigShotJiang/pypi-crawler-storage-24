# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ShowConfigSettingRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'task_id': 'str',
        'config_key': 'str'
    }

    attribute_map = {
        'task_id': 'task_id',
        'config_key': 'config_key'
    }

    def __init__(self, task_id=None, config_key=None):
        r"""ShowConfigSettingRequest

        The model defined in huaweicloud sdk

        :param task_id: 任务id
        :type task_id: str
        :param config_key: 具体请求配置项
        :type config_key: str
        """
        
        

        self._task_id = None
        self._config_key = None
        self.discriminator = None

        self.task_id = task_id
        if config_key is not None:
            self.config_key = config_key

    @property
    def task_id(self):
        r"""Gets the task_id of this ShowConfigSettingRequest.

        任务id

        :return: The task_id of this ShowConfigSettingRequest.
        :rtype: str
        """
        return self._task_id

    @task_id.setter
    def task_id(self, task_id):
        r"""Sets the task_id of this ShowConfigSettingRequest.

        任务id

        :param task_id: The task_id of this ShowConfigSettingRequest.
        :type task_id: str
        """
        self._task_id = task_id

    @property
    def config_key(self):
        r"""Gets the config_key of this ShowConfigSettingRequest.

        具体请求配置项

        :return: The config_key of this ShowConfigSettingRequest.
        :rtype: str
        """
        return self._config_key

    @config_key.setter
    def config_key(self, config_key):
        r"""Sets the config_key of this ShowConfigSettingRequest.

        具体请求配置项

        :param config_key: The config_key of this ShowConfigSettingRequest.
        :type config_key: str
        """
        self._config_key = config_key

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ShowConfigSettingRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
