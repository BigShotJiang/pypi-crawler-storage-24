# ⚡ swift-eda

> One line. Full picture.

**swift** is a zero-config Python EDA library that turns any pandas DataFrame into a beautiful, interactive HTML report — complete with smart profiling, auto-selected charts, correlation analysis, and data quality alerts.

```python
import swift
swift.analyse(df)
```

That's it.

---

## Install

```bash
pip install swift-eda
```


[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/)
[![License: CC BY-NC 4.0](https://img.shields.io/badge/License-CC_BY_NC_4.0-green.svg)](LICENSE)

---

## Usage

```python
import swift

# Minimal — opens report in browser automatically
swift.analyse(df)

# Custom title
swift.analyse(df, title="Q3 Sales Data")

# Dark theme
swift.analyse(df, theme="dark")

# Save to a file path instead of a temp file
swift.analyse(df, export="reports/my_report.html")

# Don't auto-open browser
swift.analyse(df, open_browser=False)

# Skip columns (IDs, UUIDs, irrelevant fields)
swift.analyse(df, exclude=["id", "uuid", "row_number"])

# Tune categorical detection threshold
swift.analyse(df, max_cat_unique=30)

# Combine options
swift.analyse(
    df,
    title="Customer Churn Analysis",
    theme="dark",
    exclude=["customer_id"],
    export="churn_report.html",
)
```

---

## What you get

Every swift report contains four sections:

**Overview**
- Summary stat cards: rows, columns, missing values, duplicate rows
- Null heatmap — visualize where data is missing across rows and columns
- Null % bar chart — ranked by missingness

**Columns**
- Grouped by type: Numeric, Categorical, Datetime, Boolean, Text, Constant
- Per-column: dtype badge, key stat chips, and an auto-selected interactive chart
- Data quality alerts shown inline (high nulls, skew, outliers, imbalance, etc.)

**Correlations**
- Pearson correlation heatmap with annotation
- Spearman correlation matrix
- Top correlated pairs ranked by |r|
- Cramér's V for categorical associations
- Point-biserial for numeric × categorical pairs

**Alerts**
- Color-coded, icon-tagged, filterable by severity (critical / warning / info)
- Covers: high nulls, constant columns, skewed distributions, outliers, imbalanced classes, mixed types, possible ID columns, and more

---

## How it works

swift runs a 5-step pipeline under the hood:

1. **Ingest** — smart dtype inference beyond raw pandas dtypes (detects constants, high-cardinality text, low-cardinality integer categoricals, parseable datetimes)
2. **Profile** — computes full stats per column: mean/median/IQR/skewness for numerics, top values/entropy for categoricals, date range for datetimes
3. **Correlate** — Pearson & Spearman matrices, Cramér's V for cat pairs, point-biserial for mixed pairs
4. **Visualize** — auto-selects the right Plotly chart per dtype (histogram+box, horizontal bar, donut, time series, length distribution)
5. **Report** — assembles everything into a self-contained HTML file with a fixed sidebar, smooth scroll-spy, and full responsive layout — no external dependencies except Plotly CDN

---

## Comparison

| Feature | `df.describe()` | ydata-profiling | sweetviz | **swift** |
|---|---|---|---|---|
| One-line API | ✅ | ✅ | ✅ | ✅ |
| Interactive charts | ❌ | partial | ❌ | ✅ |
| Auto chart selection | ❌ | ❌ | partial | ✅ |
| Correlation types | Pearson only | Pearson + Spearman | Pearson | Pearson + Spearman + Cramér's V + point-biserial |
| Alert system | ❌ | ✅ | ❌ | ✅ |
| Dark theme | ❌ | ❌ | ❌ | ✅ |
| Self-contained HTML | ❌ | ✅ | ✅ | ✅ |
| Report size | — | Large (often 5–50 MB) | Medium | Small |
| Speed (1k rows) | Instant | Slow | Medium | Fast |

---

## Contributing

Contributions are welcome! Please open an issue first to discuss what you'd like to change.

```bash
# Clone and install in dev mode
git clone https://github.com/yourusername/swift-eda
cd swift-eda
pip install -e ".[dev]"

# Run tests
pytest
```

---

## License

See [LICENSE](LICENSE) for details.
