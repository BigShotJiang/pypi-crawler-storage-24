"""Data quality alert scanning for swift EDA."""

from __future__ import annotations

import pandas as pd


def scan(df: pd.DataFrame, meta: dict, profile: dict) -> list[dict]:
    """Scan the DataFrame for data quality issues and return a list of alert dicts."""
    alerts: list[dict] = []
    rows = meta["shape"][0]
    cols = meta["shape"][1]

    # --- Dataset-level alerts ---

    if rows < 10:
        alerts.append({
            "level": "critical",
            "col": None,
            "message": f"Dataset has only {rows} rows — results may not be statistically meaningful.",
            "type": "single_row",
        })

    if cols > 200:
        alerts.append({
            "level": "info",
            "col": None,
            "message": f"Dataset has {cols} columns — consider subsetting for faster analysis.",
            "type": "too_wide",
        })

    if meta["duplicate_pct"] > 10:
        alerts.append({
            "level": "critical",
            "col": None,
            "message": (
                f"Dataset has {meta['duplicate_rows']:,} duplicate rows "
                f"({meta['duplicate_pct']:.1f}%) — this is unusually high."
            ),
            "type": "many_duplicates",
        })
    elif meta["duplicate_pct"] > 1:
        alerts.append({
            "level": "warning",
            "col": None,
            "message": (
                f"Dataset has {meta['duplicate_rows']:,} duplicate rows "
                f"({meta['duplicate_pct']:.1f}%)."
            ),
            "type": "duplicate_rows",
        })

    # --- Per-column alerts ---

    for col in meta["columns"]:
        dtype = meta["dtypes"].get(col, "text")
        null_pct = meta["null_pct"].get(col, 0.0)
        stats = profile.get(col, {})

        # Null alerts
        if null_pct > 40:
            alerts.append({
                "level": "critical",
                "col": col,
                "message": f"Column '{col}' has {null_pct:.1f}% missing values.",
                "type": "high_nulls",
            })
        elif null_pct > 5:
            alerts.append({
                "level": "warning",
                "col": col,
                "message": f"Column '{col}' has {null_pct:.1f}% missing values.",
                "type": "moderate_nulls",
            })

        # Constant column
        if dtype == "constant":
            alerts.append({
                "level": "critical",
                "col": col,
                "message": f"Column '{col}' has only one unique value — it carries no information.",
                "type": "constant_column",
            })

        # Possible ID column
        id_keywords = ("id", "uuid", "key", "index")
        col_lower = col.lower()
        is_id_name = any(kw in col_lower for kw in id_keywords)
        row_count = meta["shape"][0]
        unique_count = stats.get("unique", 0)
        if is_id_name or (dtype in ("text", "categorical") and unique_count == row_count):
            alerts.append({
                "level": "info",
                "col": col,
                "message": (
                    f"Column '{col}' has {unique_count} unique values ({unique_count/max(row_count,1)*100:.0f}%)"
                    " — likely an ID or key column, consider dropping."
                ),
                "type": "possible_id_column",
            })

        # High cardinality (categorical)
        if dtype == "categorical" and unique_count > 0:
            if unique_count / max(row_count, 1) > 0.95:
                alerts.append({
                    "level": "warning",
                    "col": col,
                    "message": (
                        f"Column '{col}' has {unique_count} unique values "
                        f"({unique_count/max(row_count,1)*100:.0f}% of rows) — very high cardinality."
                    ),
                    "type": "high_cardinality",
                })

        # Numeric-specific alerts
        if dtype == "numeric":
            skewness = stats.get("skewness")
            outlier_pct = stats.get("outlier_pct", 0.0)
            zeros_pct = stats.get("zeros_pct", 0.0)
            negative_count = stats.get("negative_count", 0)

            if skewness is not None:
                if abs(skewness) > 5:
                    alerts.append({
                        "level": "critical",
                        "col": col,
                        "message": (
                            f"Column '{col}' is extremely skewed (skewness={skewness:.2f}). "
                            "Consider log or power transformation."
                        ),
                        "type": "extreme_skew",
                    })
                elif abs(skewness) > 2:
                    alerts.append({
                        "level": "warning",
                        "col": col,
                        "message": (
                            f"Column '{col}' is highly skewed (skewness={skewness:.2f}). "
                            "Consider transformation."
                        ),
                        "type": "high_skew",
                    })

            if outlier_pct > 5:
                alerts.append({
                    "level": "warning",
                    "col": col,
                    "message": (
                        f"Column '{col}' has {stats.get('outlier_count', 0):,} outliers "
                        f"({outlier_pct:.1f}% of values)."
                    ),
                    "type": "many_outliers",
                })

            if zeros_pct == 100.0:
                alerts.append({
                    "level": "critical",
                    "col": col,
                    "message": f"Column '{col}' is entirely zeros.",
                    "type": "all_zeros",
                })
            elif zeros_pct > 80:
                alerts.append({
                    "level": "warning",
                    "col": col,
                    "message": f"Column '{col}' is {zeros_pct:.1f}% zeros.",
                    "type": "mostly_zeros",
                })

            # Negative values in columns where they are suspicious
            negative_keywords = ("age", "count", "price", "salary", "revenue", "amount", "quantity", "weight", "height")
            if negative_count > 0 and any(kw in col.lower() for kw in negative_keywords):
                alerts.append({
                    "level": "warning",
                    "col": col,
                    "message": (
                        f"Column '{col}' has {negative_count:,} negative values, "
                        "which may be unexpected for this field."
                    ),
                    "type": "negative_values",
                })

        # Boolean imbalance
        if dtype == "boolean":
            true_pct = stats.get("true_pct", 50.0)
            false_pct = 100.0 - true_pct
            minority_pct = min(true_pct, false_pct)
            if minority_pct < 10:
                alerts.append({
                    "level": "warning",
                    "col": col,
                    "message": (
                        f"Column '{col}' is heavily imbalanced: "
                        f"{true_pct:.1f}% True, {false_pct:.1f}% False."
                    ),
                    "type": "imbalanced_binary",
                })

        # Categorical imbalance
        if dtype == "categorical":
            top_pct = stats.get("top_value_pct", 0.0)
            if top_pct > 90:
                alerts.append({
                    "level": "warning",
                    "col": col,
                    "message": (
                        f"Column '{col}' is dominated by '{stats.get('top_value')}' "
                        f"({top_pct:.1f}% of values)."
                    ),
                    "type": "imbalanced_categorical",
                })

            entropy = stats.get("entropy", 1.0)
            if 0 < entropy < 0.5:
                alerts.append({
                    "level": "info",
                    "col": col,
                    "message": (
                        f"Column '{col}' has low entropy ({entropy:.2f}) — "
                        "values are concentrated in very few categories."
                    ),
                    "type": "low_entropy",
                })

        # Mixed types suspected
        if dtype == "text" or (dtype == "categorical" and str(df[col].dtype) == "object"):
            sample = df[col].dropna().head(500).astype(str)
            numeric_like = sample.str.match(r"^-?\d+(\.\d+)?$").sum()
            if 0 < numeric_like < len(sample) and numeric_like / len(sample) > 0.1:
                alerts.append({
                    "level": "warning",
                    "col": col,
                    "message": (
                        f"Column '{col}' appears to contain a mix of numeric and string values "
                        "— may need cleaning."
                    ),
                    "type": "mixed_types_suspected",
                })

    return alerts
