"""Correlation and association analysis for swift EDA."""

from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import stats


def correlate(df: pd.DataFrame, meta: dict) -> dict:
    """Compute correlations between columns and return a structured result dict."""
    numeric_cols = meta["numeric_cols"]
    categorical_cols = meta["categorical_cols"]

    numeric_matrix = pd.DataFrame()
    spearman_matrix = pd.DataFrame()
    top_pairs: list[dict] = []
    cat_associations: list[dict] = []
    mixed_pairs: list[dict] = []

    # Numeric correlations
    if len(numeric_cols) >= 2:
        num_df = df[numeric_cols].apply(pd.to_numeric, errors="coerce")
        numeric_matrix = num_df.corr(method="pearson")
        spearman_matrix = num_df.corr(method="spearman")

        # Top pairs
        seen: set[frozenset] = set()
        pairs: list[dict] = []
        for i, col_a in enumerate(numeric_cols):
            for col_b in numeric_cols[i + 1:]:
                key = frozenset([col_a, col_b])
                if key in seen:
                    continue
                seen.add(key)
                try:
                    pearson_r = numeric_matrix.loc[col_a, col_b]
                    spearman_r = spearman_matrix.loc[col_a, col_b]
                    if pd.isna(pearson_r):
                        continue
                    if abs(pearson_r) > 0.1:
                        pairs.append({
                            "col_a": col_a,
                            "col_b": col_b,
                            "pearson": round(float(pearson_r), 4),
                            "spearman": round(float(spearman_r), 4) if not pd.isna(spearman_r) else None,
                        })
                except Exception:
                    continue

        pairs.sort(key=lambda x: abs(x["pearson"]), reverse=True)
        top_pairs = pairs[:15]

    # Categorical associations (Cramér's V)
    if len(categorical_cols) >= 2:
        for i, col_a in enumerate(categorical_cols):
            for col_b in categorical_cols[i + 1:]:
                try:
                    v = _cramers_v(df[col_a], df[col_b])
                    if v is not None and v > 0.05:
                        cat_associations.append({
                            "col_a": col_a,
                            "col_b": col_b,
                            "cramers_v": round(float(v), 4),
                        })
                except Exception:
                    continue
        cat_associations.sort(key=lambda x: x["cramers_v"], reverse=True)
        cat_associations = cat_associations[:15]

    # Mixed pairs (point-biserial: numeric + categorical)
    for num_col in numeric_cols:
        for cat_col in categorical_cols:
            try:
                num_series = pd.to_numeric(df[num_col], errors="coerce").dropna()
                cat_series = df[cat_col]
                # Only binary or small cardinality
                unique_cats = cat_series.dropna().unique()
                if len(unique_cats) != 2:
                    continue
                aligned = pd.DataFrame({"num": num_series, "cat": cat_series}).dropna()
                if len(aligned) < 10:
                    continue
                binary = (aligned["cat"] == unique_cats[0]).astype(int)
                r, p = stats.pointbiserialr(binary, aligned["num"])
                if abs(r) > 0.1:
                    mixed_pairs.append({
                        "numeric": num_col,
                        "categorical": cat_col,
                        "correlation": round(float(r), 4),
                        "p_value": round(float(p), 6),
                    })
            except Exception:
                continue
    mixed_pairs.sort(key=lambda x: abs(x["correlation"]), reverse=True)
    mixed_pairs = mixed_pairs[:15]

    return {
        "numeric_matrix": numeric_matrix,
        "spearman_matrix": spearman_matrix,
        "top_pairs": top_pairs,
        "cat_associations": cat_associations,
        "mixed_pairs": mixed_pairs,
    }


def _cramers_v(x: pd.Series, y: pd.Series) -> float | None:
    """Compute Cramér's V association between two categorical series."""
    df_ct = pd.crosstab(x.fillna("__NULL__"), y.fillna("__NULL__"))
    if df_ct.shape[0] < 2 or df_ct.shape[1] < 2:
        return None
    chi2, _, _, _ = stats.chi2_contingency(df_ct)
    n = df_ct.values.sum()
    phi2 = chi2 / n
    r, k = df_ct.shape
    phi2corr = max(0.0, phi2 - ((k - 1) * (r - 1)) / (n - 1))
    rcorr = r - ((r - 1) ** 2) / (n - 1)
    kcorr = k - ((k - 1) ** 2) / (n - 1)
    denom = min((kcorr - 1), (rcorr - 1))
    if denom <= 0:
        return None
    return float(np.sqrt(phi2corr / denom))
