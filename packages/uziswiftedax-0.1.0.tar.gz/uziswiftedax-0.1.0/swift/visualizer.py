"""Plotly chart generation for swift EDA."""

from __future__ import annotations

import warnings

import numpy as np
import pandas as pd
import plotly.graph_objects as go

from .themes import get_theme


def visualize(
    df: pd.DataFrame,
    meta: dict,
    profile: dict,
    correlations: dict,
    theme: str = "light",
) -> list[dict]:
    """Generate Plotly figures for every column and overview charts."""
    t = get_theme(theme)
    results: list[dict] = []

    SAMPLE_LIMIT = 50_000
    df_viz = df.sample(SAMPLE_LIMIT, random_state=42) if len(df) > SAMPLE_LIMIT else df

    font_family = "DM Sans, sans-serif"

    # base_layout: kwargs OVERRIDE defaults (fixes showlegend duplicate-key crash)
    def base_layout(**kwargs) -> dict:
        defaults = dict(
            font=dict(family=font_family, color=t["text_primary"]),
            plot_bgcolor=t["plot_bg"],
            paper_bgcolor=t["paper_bg"],
            margin=dict(l=40, r=20, t=50, b=40),
            height=380,
            showlegend=False,
        )
        defaults.update(kwargs)
        return defaults

    def style_axes(fig, is_categorical_x=False, is_categorical_y=False):
        for axis in ["xaxis", "yaxis", "xaxis2", "yaxis2"]:
            update = dict(
                gridcolor=t["grid_color"],
                zerolinecolor=t["grid_color"],
                tickfont=dict(color=t["text_secondary"], size=11),
                title=dict(font=dict(color=t["text_secondary"])),
                linecolor=t["border"],
            )
            if (axis.startswith("x") and is_categorical_x) or (
                axis.startswith("y") and is_categorical_y
            ):
                update["showgrid"] = False
            fig.update_layout(**{axis: update})

    # ---- Per-column charts ----
    for col in meta["columns"]:
        dtype = meta["dtypes"].get(col, "text")
        col_profile = profile.get(col, {})
        series = df_viz[col]

        if dtype == "constant":
            continue
        if series.dropna().empty:
            continue

        fig = None
        try:
            if dtype == "numeric":
                fig = _numeric_chart(series, col, col_profile, t, font_family, base_layout, style_axes)
            elif dtype == "categorical":
                fig = _categorical_chart(series, col, t, font_family, base_layout, style_axes)
            elif dtype == "datetime":
                fig = _datetime_chart(series, col, t, font_family, base_layout, style_axes)
            elif dtype == "boolean":
                fig = _boolean_chart(series, col, t, font_family, base_layout)
            elif dtype == "text":
                fig = _text_chart(series, col, t, font_family, base_layout, style_axes)
        except Exception as _chart_err:
            warnings.warn(f"swift: chart skipped for '{col}' ({dtype}): {_chart_err}", stacklevel=2)
            fig = None

        if fig is not None:
            results.append({
                "col": col,
                "dtype": dtype,
                "section": "distributions",
                "title": f"{col} — distribution",
                "fig": fig,
                "fig_json": fig.to_json(),
            })

    # ---- Overview charts ----
    null_fig = _null_heatmap(df_viz, meta, t, font_family)
    if null_fig is not None:
        results.append({"col": "__null_heatmap__", "dtype": "overview", "section": "overview",
                        "title": "Missing values heatmap", "fig": null_fig, "fig_json": null_fig.to_json()})

    null_bar = _null_bar(meta, t, font_family, base_layout, style_axes)
    if null_bar is not None:
        results.append({"col": "__null_bar__", "dtype": "overview", "section": "overview",
                        "title": "Missing % per column", "fig": null_bar, "fig_json": null_bar.to_json()})

    # ---- Correlation charts ----
    if not correlations["numeric_matrix"].empty:
        corr_fig = _correlation_heatmap(correlations["numeric_matrix"], t, font_family)
        results.append({"col": "__corr_heatmap__", "dtype": "overview", "section": "correlations",
                        "title": "Pearson correlation heatmap", "fig": corr_fig, "fig_json": corr_fig.to_json()})

    if correlations["top_pairs"]:
        top_corr = _top_corr_bar(correlations["top_pairs"], t, font_family, base_layout, style_axes)
        results.append({"col": "__top_corr_bar__", "dtype": "overview", "section": "correlations",
                        "title": "Strongest correlations", "fig": top_corr, "fig_json": top_corr.to_json()})

    return results


# ══════════════════════════════════════════════════════════════════════════════
# Per-column chart functions
# ══════════════════════════════════════════════════════════════════════════════

def _numeric_chart(series, col, col_profile, t, font_family, base_layout, style_axes):
    """Histogram (left, 75%) + box plot (right, 25%) via xaxis domains.

    Uses domain-based axis split instead of make_subplots so fig.to_json()
    round-trips cleanly through Plotly.newPlot() in the HTML report.
    """
    clean = pd.to_numeric(series.dropna(), errors="coerce").dropna().tolist()

    hist_trace = go.Histogram(
        x=clean,
        name="distribution",
        xaxis="x", yaxis="y",
        marker=dict(color=t["histogram_color"], opacity=0.85),
        hovertemplate="%{x:.2f}: %{y:,} values<extra></extra>",
        showlegend=False,
    )

    box_trace = go.Box(
        y=clean,
        name=col,
        xaxis="x2", yaxis="y2",
        marker=dict(color=t["box_color"], size=3, opacity=0.6),
        line=dict(color=t["box_color"]),
        fillcolor=_adjust_opacity(t["box_color"], 0.18),
        boxmean="sd",
        hovertemplate="%{y:.2f}<extra></extra>",
        showlegend=False,
    )

    layout = base_layout(
        title=dict(text=col, font=dict(size=14, color=t["text_primary"])),
        xaxis=dict(
            domain=[0, 0.73],
            gridcolor=t["grid_color"],
            zerolinecolor=t["grid_color"],
            tickfont=dict(color=t["text_secondary"], size=11),
            linecolor=t["border"],
        ),
        yaxis=dict(
            domain=[0, 1],
            gridcolor=t["grid_color"],
            zerolinecolor=t["grid_color"],
            tickfont=dict(color=t["text_secondary"], size=11),
            linecolor=t["border"],
        ),
        xaxis2=dict(
            domain=[0.77, 1.0],
            showgrid=False,
            showticklabels=False,
            linecolor=t["border"],
        ),
        yaxis2=dict(
            domain=[0, 1],
            anchor="x2",
            gridcolor=t["grid_color"],
            zerolinecolor=t["grid_color"],
            tickfont=dict(color=t["text_secondary"], size=11),
            linecolor=t["border"],
        ),
    )

    return go.Figure(data=[hist_trace, box_trace], layout=layout)


def _categorical_chart(series, col, t, font_family, base_layout, style_axes):
    """Horizontal bar chart sorted by frequency."""
    counts = series.value_counts().head(20)
    labels = [str(x) for x in counts.index.tolist()]
    values = counts.values.tolist()
    n = len(labels)
    colors = [
        t["bar_color"] if i == 0 else _adjust_opacity(t["bar_color"], max(0.35, 1.0 - i / n * 0.65))
        for i in range(n)
    ]

    fig = go.Figure(go.Bar(
        x=values[::-1], y=labels[::-1], orientation="h",
        marker_color=colors[::-1],
        hovertemplate="%{y}: %{x:,}<extra></extra>",
        showlegend=False,
    ))
    fig.update_layout(**base_layout(title=dict(text=col, font=dict(size=14, color=t["text_primary"]))))
    style_axes(fig, is_categorical_y=True)
    return fig


def _datetime_chart(series, col, t, font_family, base_layout, style_axes):
    """Line chart of record count by month."""
    try:
        parsed = pd.to_datetime(series, errors="coerce").dropna()
        if len(parsed) < 2:
            return None
        counts = parsed.dt.to_period("M").value_counts().sort_index()
        x = [str(p) for p in counts.index]
        y = counts.values.tolist()
    except Exception:
        return None

    fig = go.Figure(go.Scatter(
        x=x, y=y, mode="lines+markers",
        line=dict(color=t["bar_color"], width=2),
        marker=dict(color=t["bar_color"], size=5),
        fill="tozeroy", fillcolor=_adjust_opacity(t["bar_color"], 0.12),
        hovertemplate="%{x}: %{y:,} records<extra></extra>",
        showlegend=False,
    ))
    fig.update_layout(**base_layout(title=dict(text=col, font=dict(size=14, color=t["text_primary"]))))
    style_axes(fig)
    return fig


def _boolean_chart(series, col, t, font_family, base_layout):
    """Donut chart for True/False split."""
    try:
        bool_series = series.dropna().astype(bool)
    except Exception:
        bool_series = series.dropna().map(lambda x: str(x).lower() in ("true", "1", "yes"))

    true_count = int(bool_series.sum())
    false_count = int((~bool_series).sum())

    fig = go.Figure(go.Pie(
        labels=["True", "False"],
        values=[true_count, false_count],
        hole=0.55,
        marker_colors=[t["donut_colors"][0], t["donut_colors"][1]],
        hovertemplate="%{label}: %{value:,} (%{percent})<extra></extra>",
        textfont=dict(color=t["text_primary"]),
    ))

    # showlegend=True overrides the default False safely via dict.update()
    fig.update_layout(**base_layout(
        title=dict(text=col, font=dict(size=14, color=t["text_primary"])),
        showlegend=True,
        legend=dict(font=dict(color=t["text_secondary"])),
    ))
    return fig


def _text_chart(series, col, t, font_family, base_layout, style_axes):
    """Histogram of string character lengths."""
    clean = series.dropna().astype(str)
    lengths = clean.str.len().tolist()

    fig = go.Figure(go.Histogram(
        x=lengths, nbinsx=30,
        marker=dict(color=t["bar_color"], opacity=0.85),
        hovertemplate="len %{x}: %{y:,} values<extra></extra>",
        showlegend=False,
    ))
    fig.update_layout(**base_layout(
        title=dict(text=f"{col} — string lengths", font=dict(size=14, color=t["text_primary"])),
    ))
    style_axes(fig)
    fig.update_xaxes(title_text="Character length")
    return fig


# ══════════════════════════════════════════════════════════════════════════════
# Overview + correlation charts
# ══════════════════════════════════════════════════════════════════════════════

def _null_heatmap(df_viz, meta, t, font_family):
    sample = df_viz.sample(min(500, len(df_viz)), random_state=1) if len(df_viz) > 500 else df_viz
    null_matrix = sample.isnull().astype(int)
    cols_with_nulls = [c for c in meta["columns"] if meta["null_counts"].get(c, 0) > 0]
    display_cols = (cols_with_nulls or meta["columns"])[:30]
    z = null_matrix[display_cols].T.values.tolist()

    fig = go.Figure(go.Heatmap(
        z=z, x=list(range(len(sample))), y=display_cols,
        colorscale=[[0, t["plot_bg"]], [1, t["danger"]]],
        showscale=False, hovertemplate="Row %{x} — %{y}: %{z}<extra></extra>",
    ))
    fig.update_layout(
        title=dict(text="Missing values", font=dict(size=14, color=t["text_primary"])),
        font=dict(family=font_family, color=t["text_primary"]),
        plot_bgcolor=t["plot_bg"], paper_bgcolor=t["paper_bg"],
        margin=dict(l=120, r=20, t=50, b=40),
        height=max(200, min(500, 30 * len(display_cols) + 80)),
        yaxis=dict(tickfont=dict(size=11, color=t["text_secondary"]), linecolor=t["border"]),
        xaxis=dict(showticklabels=False, linecolor=t["border"]),
    )
    return fig


def _null_bar(meta, t, font_family, base_layout, style_axes):
    cols = meta["columns"]
    null_pcts = [meta["null_pct"].get(c, 0.0) for c in cols]
    if max(null_pcts) == 0:
        return None
    sorted_pairs = sorted(zip(null_pcts, cols), reverse=True)[:30]
    pcts, names = zip(*sorted_pairs)
    colors = [t["danger"] if p > 40 else (t["warning"] if p > 5 else t["bar_color"]) for p in pcts]

    fig = go.Figure(go.Bar(
        x=list(pcts)[::-1], y=list(names)[::-1], orientation="h",
        marker_color=colors[::-1],
        hovertemplate="%{y}: %{x:.1f}% missing<extra></extra>",
        showlegend=False,
    ))
    fig.update_layout(**base_layout(title=dict(text="Null % per column", font=dict(size=14, color=t["text_primary"]))))
    style_axes(fig, is_categorical_y=True)
    return fig


def _correlation_heatmap(matrix, t, font_family):
    cols = list(matrix.columns)
    z = matrix.values.tolist()
    annotations = [
        dict(x=cols[j], y=cols[i], text=f"{val:.2f}", showarrow=False,
             font=dict(size=10, color=t["text_primary"]))
        for i, row in enumerate(z) for j, val in enumerate(row) if not np.isnan(val)
    ]

    fig = go.Figure(go.Heatmap(
        z=z, x=cols, y=cols, colorscale=t["colorscale"],
        zmid=0, zmin=-1, zmax=1,
        colorbar=dict(tickfont=dict(color=t["text_secondary"])),
        hovertemplate="%{y} × %{x}: %{z:.3f}<extra></extra>",
    ))
    fig.update_layout(
        title=dict(text="Pearson correlation matrix", font=dict(size=14, color=t["text_primary"])),
        font=dict(family=font_family, color=t["text_primary"]),
        plot_bgcolor=t["plot_bg"], paper_bgcolor=t["paper_bg"],
        margin=dict(l=80, r=40, t=60, b=80),
        height=max(380, 40 * len(cols) + 100),
        annotations=annotations,
        xaxis=dict(tickangle=-45, tickfont=dict(size=11, color=t["text_secondary"]), linecolor=t["border"]),
        yaxis=dict(tickfont=dict(size=11, color=t["text_secondary"]), linecolor=t["border"]),
    )
    return fig


def _top_corr_bar(top_pairs, t, font_family, base_layout, style_axes):
    pairs = top_pairs[:10]
    labels = [f"{p['col_a']} × {p['col_b']}" for p in pairs]
    values = [abs(p["pearson"]) for p in pairs]
    raw_vals = [p["pearson"] for p in pairs]
    colors = [t["danger"] if v < 0 else t["bar_color"] for v in raw_vals]

    fig = go.Figure(go.Bar(
        x=values[::-1], y=labels[::-1], orientation="h",
        marker_color=colors[::-1],
        hovertemplate="%{y}: |r|=%{x:.3f}<extra></extra>",
        showlegend=False,
    ))
    fig.update_layout(**base_layout(title=dict(
        text="Strongest correlations (|Pearson r|)", font=dict(size=14, color=t["text_primary"])
    )))
    style_axes(fig, is_categorical_y=True)
    fig.update_xaxes(range=[0, 1])
    return fig


def _adjust_opacity(hex_color: str, opacity: float) -> str:
    """Convert hex to rgba()."""
    hex_color = hex_color.lstrip("#")
    r, g, b = (int(hex_color[i:i+2], 16) for i in (0, 2, 4))
    return f"rgba({r},{g},{b},{opacity:.2f})"
