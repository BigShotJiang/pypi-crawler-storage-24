"""swift — one-line automated EDA with interactive visual reports."""

from __future__ import annotations

import os
import sys
import tempfile
import traceback
import webbrowser
from typing import List, Optional

import pandas as pd
from rich.console import Console
from rich.table import Table
from rich import box

from .ingestor import ingest
from .profiler import profile as _profile
from .correlator import correlate
from .visualizer import visualize
from .alerts import scan
from .reporter import build
from .themes import get_theme

__version__ = "0.1.0"
__all__ = ["analyse", "display"]

_console = Console()


def analyse(
    df: pd.DataFrame,
    title: str = "Dataset",
    theme: str = "light",
    export: Optional[str] = None,
    open_browser: bool = True,
    exclude: Optional[List[str]] = None,
    max_cat_unique: int = 50,
) -> str:
    """Run a full EDA on df and produce an interactive HTML report.

    Args:
        df: The pandas DataFrame to analyse.
        title: Report title shown in the sidebar and browser tab.
        theme: Color theme — 'light' or 'dark'.
        export: If given, save the HTML to this file path instead of a temp file.
        open_browser: Whether to auto-open the report in the browser.
        exclude: List of column names to skip.
        max_cat_unique: Max unique values for a column to be treated as categorical.

    Returns:
        The path to the generated HTML file.
    """
    _console.print(f"\n[bold]{_lightning()}  swift[/bold] [dim]v{__version__}[/dim]")

    if not isinstance(df, pd.DataFrame):
        raise TypeError(f"Expected a pandas DataFrame, got {type(df).__name__}.")
    if df.empty:
        raise ValueError("The DataFrame is empty. swift.analyse() requires at least 1 row.")

    # ---- Warn on sampling ----
    SAMPLE_LIMIT = 50_000
    if len(df) > SAMPLE_LIMIT:
        _console.print(
            f"[yellow]⚡ Sampling notice:[/yellow] DataFrame has {len(df):,} rows. "
            f"Charts will be based on a random sample of {SAMPLE_LIMIT:,} rows. "
            f"Statistics are computed on the full dataset."
        )

    # ---- Ingestor ----
    try:
        _console.print("[dim]→ Ingesting...[/dim]")
        meta = ingest(df, max_cat_unique=max_cat_unique, exclude=exclude or [])
    except Exception as e:
        _console.print(f"[red]✗ Ingestor failed:[/red] {e}")
        raise

    # ---- Print terminal summary ----
    _print_summary(meta, _console)

    # ---- Profiler ----
    try:
        _console.print("[dim]→ Profiling columns...[/dim]")
        col_profile = _profile(df, meta)
    except Exception as e:
        _console.print(f"[yellow]⚠ Profiler error (partial results):[/yellow] {e}")
        col_profile = {}

    # ---- Correlator ----
    try:
        _console.print("[dim]→ Computing correlations...[/dim]")
        correlations = correlate(df, meta)
    except Exception as e:
        _console.print(f"[yellow]⚠ Correlator error (skipped):[/yellow] {e}")
        correlations = {"numeric_matrix": pd.DataFrame(), "spearman_matrix": pd.DataFrame(),
                        "top_pairs": [], "cat_associations": [], "mixed_pairs": []}

    # ---- Visualizer ----
    try:
        _console.print("[dim]→ Generating charts...[/dim]")
        theme_dict = get_theme(theme)
        figures = visualize(df, meta, col_profile, correlations, theme=theme)
    except Exception as e:
        _console.print(f"[yellow]⚠ Visualizer error (partial charts):[/yellow] {e}")
        traceback.print_exc()
        figures = []
        theme_dict = get_theme(theme)

    # ---- Alerts ----
    try:
        _console.print("[dim]→ Scanning for issues...[/dim]")
        alerts = scan(df, meta, col_profile)
    except Exception as e:
        _console.print(f"[yellow]⚠ Alerts error (skipped):[/yellow] {e}")
        alerts = []

    # ---- Reporter ----
    try:
        _console.print("[dim]→ Building report...[/dim]")
        html = build(meta, col_profile, correlations, figures, alerts, title=title, theme=theme_dict)
    except Exception as e:
        _console.print(f"[red]✗ Reporter failed:[/red] {e}")
        traceback.print_exc()
        raise

    # ---- Write to file ----
    if export:
        output_path = os.path.abspath(export)
        os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else ".", exist_ok=True)
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html)
    else:
        tmp = tempfile.NamedTemporaryFile(
            suffix=".html", prefix="swift_report_", delete=False, mode="w", encoding="utf-8"
        )
        tmp.write(html)
        tmp.close()
        output_path = tmp.name

    # ---- Summarise alerts ----
    if alerts:
        critical = sum(1 for a in alerts if a["level"] == "critical")
        warnings = sum(1 for a in alerts if a["level"] == "warning")
        infos = sum(1 for a in alerts if a["level"] == "info")
        parts = []
        if critical:
            parts.append(f"[red]{critical} critical[/red]")
        if warnings:
            parts.append(f"[yellow]{warnings} warnings[/yellow]")
        if infos:
            parts.append(f"[blue]{infos} info[/blue]")
        _console.print(f"[dim]→ Alerts:[/dim] {', '.join(parts)}")

    _console.print(f"[green]✓ Report ready:[/green] {output_path}")

    if open_browser and not export:
        webbrowser.open(f"file://{output_path}")
    elif open_browser and export:
        webbrowser.open(f"file://{output_path}")

    return output_path


def _print_summary(meta: dict, console: Console) -> None:
    """Print a rich terminal summary table."""
    table = Table(
        title=None,
        box=box.SIMPLE_HEAD,
        show_header=True,
        header_style="bold dim",
        border_style="dim",
        pad_edge=False,
        show_edge=False,
    )
    table.add_column("Column", style="bold", no_wrap=True)
    table.add_column("Type", style="cyan")
    table.add_column("Nulls", justify="right")
    table.add_column("Null %", justify="right")

    for col in meta["columns"]:
        dtype = meta["dtypes"].get(col, "?")
        nulls = meta["null_counts"].get(col, 0)
        pct = meta["null_pct"].get(col, 0.0)
        null_style = "red" if pct > 40 else ("yellow" if pct > 5 else "")
        table.add_row(
            col,
            dtype,
            f"{nulls:,}",
            f"[{null_style}]{pct:.1f}%[/{null_style}]" if null_style else f"{pct:.1f}%",
        )

    console.print(table)
    console.print(
        f"[dim]{meta['shape'][0]:,} rows × {meta['shape'][1]:,} cols — "
        f"{meta['duplicate_rows']:,} duplicates ({meta['duplicate_pct']:.1f}%) — "
        f"{meta['memory_mb']:.2f} MB[/dim]\n"
    )


def _lightning() -> str:
    return "⚡"


def display(
    df: pd.DataFrame,
    title: str = "Dataset",
    theme: str = "light",
    exclude=None,
    max_cat_unique: int = 50,
    height: int = 800,
) -> None:
    """Render the swift report inline inside a Jupyter / IPython notebook cell.

    Usage::

        import swift
        swift.display(df)                         # inline in notebook
        swift.display(df, theme="dark", height=900)

    Falls back to opening a browser tab if IPython is not available.
    """
    try:
        from IPython.display import display as ip_display, IFrame
    except ImportError:
        _console.print(
            "[yellow]IPython not found — falling back to browser.[/yellow] "
            "Install it with: pip install ipython"
        )
        analyse(df, title=title, theme=theme, exclude=exclude,
                max_cat_unique=max_cat_unique, open_browser=True)
        return

    html_path = analyse(
        df,
        title=title,
        theme=theme,
        exclude=exclude,
        max_cat_unique=max_cat_unique,
        open_browser=False,
    )

    ip_display(IFrame(src=f"file://{html_path}", width="100%", height=height))
