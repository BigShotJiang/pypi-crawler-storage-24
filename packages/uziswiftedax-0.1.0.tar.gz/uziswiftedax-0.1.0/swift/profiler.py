"""Per-column statistical profiling for swift EDA."""

from __future__ import annotations

import math

import numpy as np
import pandas as pd


def profile(df: pd.DataFrame, meta: dict) -> dict:
    """Profile every column and return a dict of per-column stats keyed by column name."""
    result: dict[str, dict] = {}

    for col in meta["columns"]:
        dtype = meta["dtypes"].get(col, "text")
        series = df[col]

        if dtype == "numeric":
            result[col] = _profile_numeric(series)
        elif dtype == "categorical":
            result[col] = _profile_categorical(series)
        elif dtype == "datetime":
            result[col] = _profile_datetime(series, df)
        elif dtype == "text":
            result[col] = _profile_text(series)
        elif dtype == "boolean":
            result[col] = _profile_boolean(series)
        elif dtype == "constant":
            result[col] = _profile_constant(series)
        else:
            result[col] = {"dtype": dtype, "count": int(series.count()), "null_count": int(series.isnull().sum())}

    return result


def _profile_numeric(series: pd.Series) -> dict:
    """Profile a numeric column."""
    clean = series.dropna()
    count = int(series.count())
    null_count = int(series.isnull().sum())
    null_pct = round(null_count / max(len(series), 1) * 100, 2)

    if len(clean) == 0:
        return {
            "dtype": "numeric", "count": count, "null_count": null_count,
            "null_pct": null_pct, "mean": None, "median": None, "std": None,
            "min": None, "max": None, "q1": None, "q3": None, "iqr": None,
            "skewness": None, "kurtosis": None, "outlier_count": 0,
            "outlier_pct": 0.0, "zeros": 0, "zeros_pct": 0.0, "negative_count": 0,
        }

    q1 = float(clean.quantile(0.25))
    q3 = float(clean.quantile(0.75))
    iqr = q3 - q1
    lower_fence = q1 - 1.5 * iqr
    upper_fence = q3 + 1.5 * iqr
    outliers = clean[(clean < lower_fence) | (clean > upper_fence)]
    zeros = int((clean == 0).sum())
    negatives = int((clean < 0).sum())

    try:
        skewness = float(clean.skew())
    except Exception:
        skewness = 0.0
    try:
        kurtosis = float(clean.kurtosis())
    except Exception:
        kurtosis = 0.0

    return {
        "dtype": "numeric",
        "count": count,
        "null_count": null_count,
        "null_pct": null_pct,
        "mean": round(float(clean.mean()), 4),
        "median": round(float(clean.median()), 4),
        "std": round(float(clean.std()), 4),
        "min": round(float(clean.min()), 4),
        "max": round(float(clean.max()), 4),
        "q1": round(q1, 4),
        "q3": round(q3, 4),
        "iqr": round(iqr, 4),
        "skewness": round(skewness, 4),
        "kurtosis": round(kurtosis, 4),
        "outlier_count": int(len(outliers)),
        "outlier_pct": round(len(outliers) / max(len(clean), 1) * 100, 2),
        "zeros": zeros,
        "zeros_pct": round(zeros / max(len(clean), 1) * 100, 2),
        "negative_count": negatives,
    }


def _profile_categorical(series: pd.Series) -> dict:
    """Profile a categorical column."""
    clean = series.dropna()
    count = int(series.count())
    null_count = int(series.isnull().sum())
    null_pct = round(null_count / max(len(series), 1) * 100, 2)
    unique = int(clean.nunique())

    value_counts = clean.value_counts()
    top_values = [[str(k), int(v)] for k, v in value_counts.head(10).items()]
    top_value = str(value_counts.index[0]) if len(value_counts) > 0 else None
    top_value_pct = round(value_counts.iloc[0] / max(len(clean), 1) * 100, 2) if len(value_counts) > 0 else 0.0

    # Shannon entropy
    probs = value_counts / value_counts.sum()
    entropy = float(-sum(p * math.log2(p) for p in probs if p > 0))

    return {
        "dtype": "categorical",
        "count": count,
        "null_count": null_count,
        "null_pct": null_pct,
        "unique": unique,
        "top_values": top_values,
        "top_value": top_value,
        "top_value_pct": top_value_pct,
        "entropy": round(entropy, 4),
    }


def _profile_datetime(series: pd.Series, df: pd.DataFrame) -> dict:
    """Profile a datetime column."""
    try:
        parsed = pd.to_datetime(series, errors="coerce")
    except Exception:
        parsed = series

    clean = parsed.dropna()
    count = int(series.count())
    null_count = int(series.isnull().sum())

    if len(clean) == 0:
        return {
            "dtype": "datetime", "count": count, "null_count": null_count,
            "min_date": None, "max_date": None, "range_days": None,
            "most_common_year": None, "most_common_month": None, "gaps_detected": False,
        }

    min_date = clean.min()
    max_date = clean.max()
    range_days = (max_date - min_date).days

    most_common_year = None
    most_common_month = None
    gaps_detected = False

    try:
        most_common_year = int(clean.dt.year.value_counts().idxmax())
        most_common_month = int(clean.dt.month.value_counts().idxmax())
        sorted_dates = clean.sort_values()
        diffs = sorted_dates.diff().dropna()
        median_diff = diffs.median()
        if median_diff and median_diff.total_seconds() > 0:
            gaps_detected = bool((diffs > median_diff * 3).any())
    except Exception:
        pass

    return {
        "dtype": "datetime",
        "count": count,
        "null_count": null_count,
        "min_date": str(min_date.date()) if hasattr(min_date, "date") else str(min_date)[:10],
        "max_date": str(max_date.date()) if hasattr(max_date, "date") else str(max_date)[:10],
        "range_days": range_days,
        "most_common_year": most_common_year,
        "most_common_month": most_common_month,
        "gaps_detected": gaps_detected,
    }


def _profile_text(series: pd.Series) -> dict:
    """Profile a high-cardinality text column."""
    clean = series.dropna().astype(str)
    count = int(series.count())
    null_count = int(series.isnull().sum())
    null_pct = round(null_count / max(len(series), 1) * 100, 2)

    if len(clean) == 0:
        return {
            "dtype": "text", "count": count, "null_count": null_count,
            "null_pct": null_pct, "avg_length": 0, "min_length": 0,
            "max_length": 0, "unique": 0,
        }

    lengths = clean.str.len()
    return {
        "dtype": "text",
        "count": count,
        "null_count": null_count,
        "null_pct": null_pct,
        "avg_length": round(float(lengths.mean()), 2),
        "min_length": int(lengths.min()),
        "max_length": int(lengths.max()),
        "unique": int(clean.nunique()),
    }


def _profile_boolean(series: pd.Series) -> dict:
    """Profile a boolean column."""
    null_count = int(series.isnull().sum())
    clean = series.dropna()
    count = int(len(clean))

    # Normalise to bool
    try:
        bool_series = clean.astype(bool)
    except Exception:
        bool_series = clean.map(lambda x: str(x).lower() in ("true", "1", "yes"))

    true_count = int(bool_series.sum())
    false_count = count - true_count
    true_pct = round(true_count / max(count, 1) * 100, 2)

    return {
        "dtype": "boolean",
        "count": count,
        "true_count": true_count,
        "false_count": false_count,
        "true_pct": true_pct,
        "null_count": null_count,
    }


def _profile_constant(series: pd.Series) -> dict:
    """Profile a constant (single unique value) column."""
    unique_vals = series.dropna().unique()
    constant_value = str(unique_vals[0]) if len(unique_vals) > 0 else None
    return {
        "dtype": "constant",
        "count": int(series.count()),
        "null_count": int(series.isnull().sum()),
        "constant_value": constant_value,
    }
