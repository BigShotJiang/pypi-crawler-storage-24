"""Theme definitions for swift EDA reports."""


def get_theme(name: str) -> dict:
    """Return a theme dict for the given theme name ('light' or 'dark')."""
    themes = {
        "light": {
            "name": "light",
            "bg": "#ffffff",
            "surface": "#f8f8f6",
            "surface2": "#f0efeb",
            "border": "#e5e4df",
            "text_primary": "#1a1a18",
            "text_secondary": "#6b6a65",
            "text_muted": "#9b9a95",
            "accent": "#5b5bd6",
            "accent_light": "#eeedf8",
            "success": "#1d9e75",
            "warning": "#ba7517",
            "danger": "#a32d2d",
            "info": "#185fa5",
            "plot_bg": "#ffffff",
            "paper_bg": "#ffffff",
            "grid_color": "#ebebeb",
            "colorscale": "RdBu",
            "bar_color": "#5b5bd6",
            "histogram_color": "#5b5bd6",
            "box_color": "#1d9e75",
            "donut_colors": ["#5b5bd6", "#d85a30", "#1d9e75", "#ba7517", "#185fa5"],
        },
        "dark": {
            "name": "dark",
            "bg": "#0f1117",
            "surface": "#1a1c23",
            "surface2": "#22242d",
            "border": "#2e3040",
            "text_primary": "#e8e8e6",
            "text_secondary": "#9b9a95",
            "text_muted": "#6b6a65",
            "accent": "#7c7ce8",
            "accent_light": "#2a2a4a",
            "success": "#2dbe8e",
            "warning": "#e09030",
            "danger": "#d44a4a",
            "info": "#3a8fd6",
            "plot_bg": "#1a1c23",
            "paper_bg": "#1a1c23",
            "grid_color": "#2e3040",
            "colorscale": "RdBu",
            "bar_color": "#7c7ce8",
            "histogram_color": "#7c7ce8",
            "box_color": "#2dbe8e",
            "donut_colors": ["#7c7ce8", "#e07050", "#2dbe8e", "#e09030", "#3a8fd6"],
        },
    }
    if name not in themes:
        raise ValueError(f"Unknown theme '{name}'. Choose 'light' or 'dark'.")
    return themes[name]
