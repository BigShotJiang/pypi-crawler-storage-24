"""HTML report builder for swift EDA."""

from __future__ import annotations

import json
import html as html_module
from typing import Any


def build(
    meta: dict,
    profile: dict,
    correlations: dict,
    figures: list[dict],
    alerts: list[dict],
    title: str,
    theme: dict,
) -> str:
    """Build a self-contained HTML EDA report and return it as a string."""
    t = theme

    # ------------------------------------------------------------------ helpers
    def h(s: str) -> str:
        return html_module.escape(str(s))

    def fmt(v: Any, decimals: int = 2) -> str:
        if v is None:
            return "—"
        if isinstance(v, float):
            return f"{v:,.{decimals}f}"
        if isinstance(v, int):
            return f"{v:,}"
        return h(str(v))

    # ------------------------------------------------------------------ figures index
    fig_by_col: dict[str, list[dict]] = {}
    overview_figs: list[dict] = []
    corr_figs: list[dict] = []

    for f in figures:
        col = f["col"]
        section = f.get("section", "distributions")
        if section == "overview":
            overview_figs.append(f)
        elif section == "correlations":
            corr_figs.append(f)
        else:
            fig_by_col.setdefault(col, []).append(f)

    # ------------------------------------------------------------------ dtype badge
    dtype_badge_colors = {
        "numeric": "#7c3aed",
        "categorical": "#0d9488",
        "datetime": "#d97706",
        "text": "#6b7280",
        "boolean": "#db2777",
        "constant": "#dc2626",
    }

    dtype_dot_colors = {
        "numeric": "#7c3aed",
        "categorical": "#0d9488",
        "datetime": "#d97706",
        "text": "#6b7280",
        "boolean": "#db2777",
        "constant": "#dc2626",
    }

    def dtype_badge(dtype: str) -> str:
        color = dtype_badge_colors.get(dtype, "#6b7280")
        return (
            f'<span style="background:{color}20;color:{color};border:1px solid {color}40;'
            f'border-radius:4px;padding:2px 8px;font-size:11px;font-weight:500;'
            f'font-family:DM Mono,monospace;">{h(dtype)}</span>'
        )

    def chip(label: str, value: str) -> str:
        return (
            f'<span class="chip"><span class="chip-label">{h(label)}</span>'
            f'<span class="chip-value">{h(value)}</span></span>'
        )

    # ------------------------------------------------------------------ alert rendering
    alert_level_styles = {
        "critical": {"border": t["danger"], "bg": f"{t['danger']}14", "icon": "circle-x"},
        "warning": {"border": t["warning"], "bg": f"{t['warning']}14", "icon": "triangle"},
        "info": {"border": t["info"], "bg": f"{t['info']}14", "icon": "info"},
    }

    def alert_icon(icon_name: str, color: str) -> str:
        if icon_name == "circle-x":
            return (
                f'<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="{color}" '
                f'stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
                f'<circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/>'
                f'<line x1="9" y1="9" x2="15" y2="15"/></svg>'
            )
        elif icon_name == "triangle":
            return (
                f'<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="{color}" '
                f'stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
                f'<path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>'
                f'<line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>'
            )
        else:
            return (
                f'<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="{color}" '
                f'stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
                f'<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/>'
                f'<line x1="12" y1="16" x2="12.01" y2="16"/></svg>'
            )

    def render_alert(alert: dict) -> str:
        level = alert.get("level", "info")
        style = alert_level_styles.get(level, alert_level_styles["info"])
        col = alert.get("col")
        icon_svg = alert_icon(style["icon"], style["border"])
        col_pill = (
            f'<span style="background:{t["surface2"]};border:1px solid {t["border"]};'
            f'border-radius:4px;padding:1px 7px;font-size:11px;font-family:DM Mono,monospace;'
            f'margin-right:6px;">{h(col)}</span>'
            if col else ""
        )
        return (
            f'<div style="display:flex;align-items:flex-start;gap:10px;padding:10px 14px;'
            f'margin:6px 0;border-left:3px solid {style["border"]};background:{style["bg"]};'
            f'border-radius:0 6px 6px 0;">'
            f'<span style="margin-top:1px;flex-shrink:0;">{icon_svg}</span>'
            f'<div style="font-size:13px;color:{t["text_primary"]};line-height:1.5;">'
            f'{col_pill}{h(alert["message"])}</div></div>'
        )

    # ------------------------------------------------------------------ stats chips by dtype
    def render_chips(col: str, col_profile: dict) -> str:
        dtype = col_profile.get("dtype", "")
        chips = []
        if dtype == "numeric":
            chips = [
                ("mean", fmt(col_profile.get("mean"))),
                ("median", fmt(col_profile.get("median"))),
                ("std", fmt(col_profile.get("std"))),
                ("min", fmt(col_profile.get("min"))),
                ("max", fmt(col_profile.get("max"))),
                ("nulls", f"{fmt(col_profile.get('null_pct'))}%"),
                ("outliers", f"{fmt(col_profile.get('outlier_pct'))}%"),
                ("skew", fmt(col_profile.get("skewness"))),
            ]
        elif dtype == "categorical":
            chips = [
                ("unique", fmt(col_profile.get("unique"))),
                ("top", h(str(col_profile.get("top_value", "—"))[:20])),
                ("top%", f"{fmt(col_profile.get('top_value_pct'))}%"),
                ("nulls", f"{fmt(col_profile.get('null_pct'))}%"),
                ("entropy", fmt(col_profile.get("entropy"))),
            ]
        elif dtype == "datetime":
            chips = [
                ("from", h(str(col_profile.get("min_date", "—")))),
                ("to", h(str(col_profile.get("max_date", "—")))),
                ("span", f"{fmt(col_profile.get('range_days'))} days"),
                ("nulls", f"{fmt(col_profile.get('null_pct', 0))}%"),
            ]
        elif dtype == "boolean":
            chips = [
                ("true", f"{fmt(col_profile.get('true_pct'))}%"),
                ("false", f"{fmt(100 - (col_profile.get('true_pct') or 0))}%"),
                ("nulls", fmt(col_profile.get("null_count"))),
            ]
        elif dtype == "text":
            chips = [
                ("unique", fmt(col_profile.get("unique"))),
                ("avg_len", fmt(col_profile.get("avg_length"))),
                ("max_len", fmt(col_profile.get("max_length"))),
                ("nulls", f"{fmt(col_profile.get('null_pct'))}%"),
            ]
        elif dtype == "constant":
            chips = [("value", h(str(col_profile.get("constant_value", "—"))[:30]))]

        return "".join(f'<span class="chip"><span class="chip-label">{l}</span><span class="chip-value">{v}</span></span>' for l, v in chips)

    # ------------------------------------------------------------------ columns grouped by dtype
    dtype_groups = [
        ("numeric", "Numeric columns"),
        ("categorical", "Categorical columns"),
        ("datetime", "Datetime columns"),
        ("boolean", "Boolean columns"),
        ("text", "Text columns"),
        ("constant", "Constant columns"),
    ]

    def render_figure(fig_dict: dict, fig_id: str) -> str:
        div_id = f"chart-{fig_id}"
        data_id = f"data-{fig_id}"
        json_data = fig_dict["fig_json"]
        return (
            f'<div id="{div_id}" style="width:100%;min-height:380px;"></div>'
            f'<script type="application/json" id="{data_id}">{json_data}</script>'
        )

    # ------------------------------------------------------------------ sidebar nav
    def render_sidebar_col_links() -> str:
        html_parts = []
        for dtype, group_label in dtype_groups:
            cols_in_group = [c for c in meta["columns"] if meta["dtypes"].get(c) == dtype]
            if not cols_in_group:
                continue
            dot_color = dtype_dot_colors.get(dtype, "#6b7280")
            html_parts.append(
                f'<div class="nav-group-label" style="color:{t["text_muted"]};font-size:11px;'
                f'font-weight:600;text-transform:uppercase;letter-spacing:.06em;'
                f'padding:10px 16px 4px;">{h(group_label.split()[0])}</div>'
            )
            for col in cols_in_group:
                html_parts.append(
                    f'<a href="#col-{h(col)}" class="nav-col-link" '
                    f'style="display:flex;align-items:center;gap:7px;padding:4px 16px 4px 20px;'
                    f'font-size:13px;color:{t["text_secondary"]};text-decoration:none;'
                    f'white-space:nowrap;overflow:hidden;text-overflow:ellipsis;border-radius:6px;'
                    f'transition:background .15s;" '
                    f'onmouseover="this.style.background=\'{t["surface2"]}\'" '
                    f'onmouseout="this.style.background=\'transparent\'">'
                    f'<span style="width:7px;height:7px;border-radius:50%;background:{dot_color};'
                    f'flex-shrink:0;"></span>'
                    f'<span style="overflow:hidden;text-overflow:ellipsis;">{h(col)}</span></a>'
                )
        return "\n".join(html_parts)

    # ------------------------------------------------------------------ sections HTML
    # Overview
    total_missing = sum(meta["null_counts"].values())
    total_cells = meta["shape"][0] * meta["shape"][1]
    missing_pct = round(total_missing / max(total_cells, 1) * 100, 2)

    stat_cards = [
        ("Rows", f"{meta['shape'][0]:,}", ""),
        ("Columns", f"{meta['shape'][1]:,}", ""),
        ("Missing values", f"{total_missing:,}", f"({missing_pct:.1f}% of cells)"),
        ("Duplicate rows", f"{meta['duplicate_rows']:,}", f"({meta['duplicate_pct']:.1f}%)"),
    ]

    cards_html = "".join(
        f'<div class="stat-card">'
        f'<div style="font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:.06em;color:{t["text_muted"]};margin-bottom:6px;">{h(label)}</div>'
        f'<div style="font-size:26px;font-weight:600;color:{t["text_primary"]};line-height:1;">{h(value)}</div>'
        f'<div style="font-size:12px;color:{t["text_muted"]};margin-top:4px;">{h(sub)}</div>'
        f'</div>'
        for label, value, sub in stat_cards
    )

    overview_chart_html = ""
    for f in overview_figs:
        fig_id = f["col"].replace("_", "-").lstrip("-")
        overview_chart_html += (
            f'<div class="card" style="flex:1;min-width:300px;">'
            f'<div style="font-size:13px;font-weight:500;color:{t["text_secondary"]};margin-bottom:12px;">{h(f["title"])}</div>'
            f'{render_figure(f, fig_id)}</div>'
        )

    overview_section = (
        f'<section id="section-overview">'
        f'<h2 class="section-header">Overview</h2>'
        f'<div class="stat-cards-row">{cards_html}</div>'
        f'<div style="display:flex;gap:16px;flex-wrap:wrap;margin-top:16px;">'
        f'{overview_chart_html}</div></section>'
    )

    # Columns section
    col_sections_html = '<section id="section-columns"><h2 class="section-header">Columns</h2>'

    for dtype, group_label in dtype_groups:
        cols_in_group = [c for c in meta["columns"] if meta["dtypes"].get(c) == dtype]
        if not cols_in_group:
            continue

        col_sections_html += (
            f'<div style="margin:24px 0 8px;padding-bottom:8px;border-bottom:1px solid {t["border"]};">'
            f'<span style="font-size:13px;font-weight:600;color:{t["text_muted"]};'
            f'text-transform:uppercase;letter-spacing:.06em;">{h(group_label)}</span></div>'
        )

        for col in cols_in_group:
            col_profile = profile.get(col, {})
            col_alerts = [a for a in alerts if a.get("col") == col]
            figs_for_col = fig_by_col.get(col, [])

            alerts_html = "".join(render_alert(a) for a in col_alerts)
            chips_html = render_chips(col, col_profile)

            chart_html = ""
            for idx, fig_dict in enumerate(figs_for_col):
                fig_id = f"{col}-{idx}".replace(" ", "_").replace("/", "_")
                chart_html += render_figure(fig_dict, fig_id)

            col_sections_html += (
                f'<div class="card col-card" id="col-{h(col)}" style="margin-bottom:16px;">'
                f'<div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;flex-wrap:wrap;">'
                f'<code style="font-size:14px;font-weight:500;color:{t["text_primary"]};'
                f'font-family:DM Mono,monospace;">{h(col)}</code>'
                f'{dtype_badge(dtype)}</div>'
                f'<div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px;">{chips_html}</div>'
                f'{alerts_html}'
                f'{chart_html}</div>'
            )

    col_sections_html += "</section>"

    # Correlations section
    corr_section = f'<section id="section-correlations"><h2 class="section-header">Correlations</h2>'
    for f in corr_figs:
        fig_id = f["col"].replace("_", "-").lstrip("-")
        corr_section += (
            f'<div class="card" style="margin-bottom:16px;">'
            f'<div style="font-size:13px;font-weight:500;color:{t["text_secondary"]};margin-bottom:12px;">{h(f["title"])}</div>'
            f'{render_figure(f, fig_id)}</div>'
        )

    # Cramér's V table
    if correlations["cat_associations"]:
        rows = "".join(
            f'<tr><td><code>{h(r["col_a"])}</code></td><td><code>{h(r["col_b"])}</code></td>'
            f'<td style="color:{t["accent"]};font-weight:500;">{r["cramers_v"]:.4f}</td></tr>'
            for r in correlations["cat_associations"]
        )
        corr_section += (
            f'<div class="card" style="margin-bottom:16px;">'
            f'<div style="font-size:13px;font-weight:500;color:{t["text_secondary"]};margin-bottom:12px;">Categorical associations (Cramér\'s V)</div>'
            f'<table class="data-table"><thead><tr><th>Column A</th><th>Column B</th><th>Cramér\'s V</th></tr></thead>'
            f'<tbody>{rows}</tbody></table></div>'
        )

    # Mixed pairs table
    if correlations["mixed_pairs"]:
        rows = "".join(
            f'<tr><td><code>{h(r["numeric"])}</code></td><td><code>{h(r["categorical"])}</code></td>'
            f'<td style="color:{t["accent"]};font-weight:500;">{r["correlation"]:.4f}</td>'
            f'<td style="color:{t["text_muted"]};">{r["p_value"]:.4f}</td></tr>'
            for r in correlations["mixed_pairs"]
        )
        corr_section += (
            f'<div class="card" style="margin-bottom:16px;">'
            f'<div style="font-size:13px;font-weight:500;color:{t["text_secondary"]};margin-bottom:12px;">Mixed associations (point-biserial)</div>'
            f'<table class="data-table"><thead><tr><th>Numeric</th><th>Categorical</th><th>r</th><th>p-value</th></tr></thead>'
            f'<tbody>{rows}</tbody></table></div>'
        )

    corr_section += "</section>"

    # Alerts section
    alerts_section = f'<section id="section-alerts"><h2 class="section-header">Alerts <span style="background:{t["surface2"]};color:{t["text_muted"]};font-size:12px;padding:2px 8px;border-radius:10px;font-weight:400;margin-left:8px;">{len(alerts)}</span></h2>'
    if alerts:
        for alert in alerts:
            alerts_section += render_alert(alert)
    else:
        alerts_section += f'<p style="color:{t["text_muted"]};font-size:14px;">No issues detected. Your data looks clean!</p>'
    alerts_section += "</section>"

    # ------------------------------------------------------------------ CSS
    css = f"""
    *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}
    html {{ scroll-behavior: smooth; font-size: 14px; }}
    body {{
        font-family: 'DM Sans', sans-serif;
        background: {t["bg"]};
        color: {t["text_primary"]};
        display: flex;
        min-height: 100vh;
    }}
    /* Sidebar */
    #sidebar {{
        width: 220px;
        min-width: 220px;
        background: {t["surface"]};
        border-right: 1px solid {t["border"]};
        position: fixed;
        top: 0; left: 0; bottom: 0;
        overflow-y: auto;
        z-index: 100;
        display: flex;
        flex-direction: column;
    }}
    #sidebar-header {{
        padding: 20px 16px 12px;
        border-bottom: 1px solid {t["border"]};
    }}
    .sidebar-logo {{
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 8px;
    }}
    .sidebar-logo-text {{
        font-size: 18px;
        font-weight: 600;
        color: {t["accent"]};
        letter-spacing: -0.02em;
    }}
    .sidebar-title {{
        font-size: 12px;
        color: {t["text_muted"]};
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }}
    .nav-section-link {{
        display: block;
        padding: 7px 16px;
        font-size: 13px;
        font-weight: 500;
        color: {t["text_secondary"]};
        text-decoration: none;
        border-radius: 6px;
        transition: background .15s, color .15s;
        margin: 1px 8px;
    }}
    .nav-section-link:hover, .nav-section-link.active {{
        background: {t["accent_light"]};
        color: {t["accent"]};
    }}
    #sidebar-meta {{
        margin-top: auto;
        padding: 12px 16px;
        border-top: 1px solid {t["border"]};
        font-size: 11px;
        color: {t["text_muted"]};
        line-height: 1.8;
    }}
    /* Main content */
    #main {{
        margin-left: 220px;
        flex: 1;
        padding: 32px 36px;
        max-width: 1100px;
    }}
    /* Cards */
    .card {{
        background: {t["surface"]};
        border: 1px solid {t["border"]};
        border-radius: 12px;
        padding: 1.5rem;
        margin-bottom: 16px;
    }}
    /* Stat cards */
    .stat-cards-row {{
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
        gap: 12px;
        margin-bottom: 16px;
    }}
    .stat-card {{
        background: {t["surface"]};
        border: 1px solid {t["border"]};
        border-radius: 12px;
        padding: 1.25rem 1.5rem;
    }}
    /* Chips */
    .chip {{
        display: inline-flex;
        align-items: center;
        background: {t["surface2"]};
        border-radius: 6px;
        font-size: 12px;
        overflow: hidden;
    }}
    .chip-label {{
        padding: 3px 6px 3px 10px;
        color: {t["text_muted"]};
        font-weight: 500;
    }}
    .chip-value {{
        padding: 3px 10px 3px 4px;
        color: {t["text_primary"]};
        font-weight: 500;
        font-family: 'DM Mono', monospace;
    }}
    /* Section headers */
    .section-header {{
        font-size: 18px;
        font-weight: 500;
        color: {t["text_primary"]};
        padding-bottom: 12px;
        border-bottom: 1px solid {t["border"]};
        margin-bottom: 20px;
        margin-top: 36px;
    }}
    /* Tables */
    .data-table {{
        width: 100%;
        border-collapse: collapse;
        font-size: 13px;
    }}
    .data-table th {{
        text-align: left;
        padding: 8px 12px;
        color: {t["text_muted"]};
        font-weight: 600;
        font-size: 11px;
        text-transform: uppercase;
        letter-spacing: .05em;
        border-bottom: 1px solid {t["border"]};
    }}
    .data-table td {{
        padding: 8px 12px;
        border-bottom: 1px solid {t["border"]};
        color: {t["text_primary"]};
    }}
    .data-table tr:last-child td {{ border-bottom: none; }}
    .data-table tr:hover td {{ background: {t["surface2"]}; }}
    /* Mobile */
    #mobile-nav-toggle {{
        display: none;
        position: fixed;
        top: 12px; left: 12px;
        z-index: 200;
        background: {t["accent"]};
        color: white;
        border: none;
        border-radius: 8px;
        padding: 8px 12px;
        font-size: 14px;
        cursor: pointer;
    }}
    #mobile-nav-overlay {{
        display: none;
    }}
    @media (max-width: 768px) {{
        #sidebar {{ display: none; }}
        #main {{ margin-left: 0; padding: 60px 16px 24px; }}
        #mobile-nav-toggle {{ display: block; }}
        #mobile-nav-overlay.open {{
            display: block;
            position: fixed;
            inset: 0;
            background: rgba(0,0,0,0.5);
            z-index: 150;
        }}
        #mobile-nav-panel {{
            position: fixed;
            top: 0; left: 0; bottom: 0;
            width: 260px;
            background: {t["surface"]};
            overflow-y: auto;
            z-index: 160;
            padding: 20px 0;
        }}
    }}
    """

    # ------------------------------------------------------------------ JS
    js = """
    document.addEventListener('DOMContentLoaded', function() {
        // Render all Plotly charts
        document.querySelectorAll('[id^="data-"]').forEach(function(scriptEl) {
            var dataId = scriptEl.id;
            var divId = 'chart-' + dataId.slice(5);
            var chartDiv = document.getElementById(divId);
            if (!chartDiv) return;
            try {
                var figData = JSON.parse(scriptEl.textContent);
                Plotly.newPlot(chartDiv, figData.data, figData.layout, {
                    responsive: true,
                    displayModeBar: false,
                });
            } catch(e) {
                console.warn('Chart render failed for ' + divId, e);
            }
        });

        // Scroll-spy for sidebar
        var sections = ['overview', 'columns', 'correlations', 'alerts'];
        var sectionEls = sections.map(function(s) {
            return document.getElementById('section-' + s);
        });
        var navLinks = document.querySelectorAll('.nav-section-link');

        function updateActive() {
            var scrollY = window.scrollY + 80;
            var active = 0;
            sectionEls.forEach(function(el, i) {
                if (el && el.offsetTop <= scrollY) active = i;
            });
            navLinks.forEach(function(link, i) {
                link.classList.toggle('active', i === active);
            });
        }

        window.addEventListener('scroll', updateActive, { passive: true });
        updateActive();

        // Mobile nav
        var toggle = document.getElementById('mobile-nav-toggle');
        var overlay = document.getElementById('mobile-nav-overlay');
        if (toggle && overlay) {
            toggle.addEventListener('click', function() {
                overlay.classList.add('open');
            });
            overlay.addEventListener('click', function(e) {
                if (!document.getElementById('mobile-nav-panel').contains(e.target)) {
                    overlay.classList.remove('open');
                }
            });
            overlay.querySelectorAll('a').forEach(function(a) {
                a.addEventListener('click', function() {
                    overlay.classList.remove('open');
                });
            });
        }
    });
    """

    # ------------------------------------------------------------------ assemble
    lightning_svg = (
        f'<svg width="22" height="22" viewBox="0 0 24 24" fill="{t["accent"]}" '
        f'xmlns="http://www.w3.org/2000/svg"><path d="M13 2L4.5 13.5H11L10 22L19.5 10.5H13L13 2Z"/></svg>'
    )

    sidebar_html = f"""
    <div id="sidebar">
      <div id="sidebar-header">
        <div class="sidebar-logo">
          {lightning_svg}
          <span class="sidebar-logo-text">swift</span>
        </div>
        <div class="sidebar-title" title="{h(title)}">{h(title)}</div>
      </div>
      <div style="padding: 8px 0 4px;">
        <a href="#section-overview" class="nav-section-link active">Overview</a>
        <a href="#section-columns" class="nav-section-link">Columns</a>
        <a href="#section-correlations" class="nav-section-link">Correlations</a>
        <a href="#section-alerts" class="nav-section-link">Alerts
          <span style="float:right;background:{t['surface2']};border-radius:10px;
          padding:0 6px;font-size:11px;color:{t['text_muted']};">{len(alerts)}</span>
        </a>
        <div style="margin-top:4px;border-top:1px solid {t['border']};padding-top:4px;">
          {render_sidebar_col_links()}
        </div>
      </div>
      <div id="sidebar-meta">
        <div>{meta['shape'][0]:,} rows &times; {meta['shape'][1]:,} cols</div>
        <div>{meta['memory_mb']:.2f} MB in memory</div>
      </div>
    </div>
    """

    mobile_nav_panel = f"""
    <div id="mobile-nav-overlay">
      <div id="mobile-nav-panel">
        <div style="padding: 16px;">
          <div class="sidebar-logo" style="margin-bottom:12px;">
            {lightning_svg}<span class="sidebar-logo-text">swift</span>
          </div>
          <a href="#section-overview" class="nav-section-link" style="display:block;">Overview</a>
          <a href="#section-columns" class="nav-section-link" style="display:block;">Columns</a>
          <a href="#section-correlations" class="nav-section-link" style="display:block;">Correlations</a>
          <a href="#section-alerts" class="nav-section-link" style="display:block;">Alerts</a>
        </div>
      </div>
    </div>
    """

    html_out = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<title>{h(title)} — swift EDA</title>
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&family=DM+Mono:wght@400;500&display=swap" rel="stylesheet"/>
<script src="https://cdn.plot.ly/plotly-2.27.0.min.js"></script>
<style>{css}</style>
</head>
<body>
<button id="mobile-nav-toggle">&#9776; Menu</button>
{mobile_nav_panel}
{sidebar_html}
<main id="main">
  {overview_section}
  {col_sections_html}
  {corr_section}
  {alerts_section}
</main>
<script>{js}</script>
</body>
</html>"""

    return html_out
