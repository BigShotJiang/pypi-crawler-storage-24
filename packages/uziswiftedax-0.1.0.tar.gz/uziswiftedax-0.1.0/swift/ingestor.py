"""DataFrame ingestion and metadata extraction for swift EDA."""

from __future__ import annotations

import pandas as pd
import numpy as np


def ingest(df: pd.DataFrame, max_cat_unique: int = 50, exclude: list | None = None) -> dict:
    """Ingest a DataFrame and return a metadata dictionary with smart dtype inference."""
    if df.empty:
        raise ValueError(
            "The DataFrame is empty (0 rows). swift.analyse() requires at least 1 row of data."
        )
    if len(df.columns) == 0:
        raise ValueError("The DataFrame has no columns.")

    exclude = exclude or []
    df = df.drop(columns=[c for c in exclude if c in df.columns], errors="ignore")

    shape = df.shape
    columns = list(df.columns)
    null_counts = df.isnull().sum().to_dict()
    null_pct = {c: round(null_counts[c] / shape[0] * 100, 2) for c in columns}
    duplicate_rows = int(df.duplicated().sum())
    duplicate_pct = round(duplicate_rows / shape[0] * 100, 2)
    memory_mb = round(df.memory_usage(deep=True).sum() / 1024**2, 3)

    dtypes: dict[str, str] = {}
    numeric_cols: list[str] = []
    categorical_cols: list[str] = []
    datetime_cols: list[str] = []
    text_cols: list[str] = []
    boolean_cols: list[str] = []
    constant_cols: list[str] = []

    for col in columns:
        series = df[col]
        n_unique = series.nunique(dropna=True)

        # Constant column (only 1 unique non-null value OR all null)
        if n_unique <= 1:
            dtypes[col] = "constant"
            constant_cols.append(col)
            continue

        raw_dtype = str(series.dtype)

        # Boolean
        if raw_dtype == "bool" or set(series.dropna().unique()).issubset({True, False, 0, 1}):
            if n_unique <= 2 and raw_dtype in ("bool", "object", "int64", "float64"):
                if raw_dtype == "bool" or (
                    n_unique <= 2
                    and set(series.dropna().unique()).issubset({True, False, 0, 1, "True", "False"})
                ):
                    dtypes[col] = "boolean"
                    boolean_cols.append(col)
                    continue

        # Datetime
        if "datetime" in raw_dtype:
            dtypes[col] = "datetime"
            datetime_cols.append(col)
            continue

        # Try parsing object columns as datetimes
        if raw_dtype == "object":
            sample = series.dropna().head(100)
            try:
                parsed = pd.to_datetime(sample, errors="coerce")
                if len(parsed) > 0:
                    dtypes[col] = "datetime"
                    datetime_cols.append(col)
                    continue
            except Exception:
                pass

        # Numeric
        if raw_dtype in ("int64", "int32", "int16", "int8", "float64", "float32"):
            # If very few unique values and it looks categorical
            if n_unique <= 10 and raw_dtype.startswith("int"):
                dtypes[col] = "categorical"
                categorical_cols.append(col)
            else:
                dtypes[col] = "numeric"
                numeric_cols.append(col)
            continue

        # Object / string columns
        if raw_dtype == "object":
            if n_unique <= max_cat_unique:
                dtypes[col] = "categorical"
                categorical_cols.append(col)
            else:
                dtypes[col] = "text"
                text_cols.append(col)
            continue

        # Fallback: treat as categorical
        if n_unique <= max_cat_unique:
            dtypes[col] = "categorical"
            categorical_cols.append(col)
        else:
            dtypes[col] = "text"
            text_cols.append(col)

    return {
        "shape": shape,
        "columns": columns,
        "dtypes": dtypes,
        "null_counts": null_counts,
        "null_pct": null_pct,
        "duplicate_rows": duplicate_rows,
        "duplicate_pct": duplicate_pct,
        "memory_mb": memory_mb,
        "numeric_cols": numeric_cols,
        "categorical_cols": categorical_cols,
        "datetime_cols": datetime_cols,
        "text_cols": text_cols,
        "boolean_cols": boolean_cols,
        "constant_cols": constant_cols,
    }
