"""Demo script — generates a synthetic dataset and runs swift.analyse()."""

import numpy as np
import pandas as pd
from datetime import datetime, timedelta

import swift


def make_demo_df(n: int = 1_000) -> pd.DataFrame:
    """Create a synthetic DataFrame with a variety of column types."""
    rng = np.random.default_rng(2024)

    # Numeric — normal distribution
    age = rng.integers(18, 75, n).astype(float)
    age[rng.integers(0, n, 20)] = np.nan  # some nulls

    # Numeric — skewed (like revenue or clicks)
    revenue = np.expm1(rng.normal(8, 1.5, n))
    revenue[rng.integers(0, n, 5)] = -50  # a few negatives to trigger alert

    # Numeric — with many outliers
    score = rng.normal(50, 10, n)
    score[rng.integers(0, n, 30)] = rng.uniform(200, 500, 30)  # outliers

    # Categorical
    country = rng.choice(["USA", "UK", "Germany", "France", "Japan", "Brazil"], n, p=[0.4, 0.2, 0.15, 0.1, 0.1, 0.05])
    plan = rng.choice(["Free", "Pro", "Enterprise"], n, p=[0.7, 0.2, 0.1])

    # Datetime
    base_date = datetime(2020, 1, 1)
    joined_at = [base_date + timedelta(days=int(d)) for d in rng.integers(0, 4 * 365, n)]

    # Boolean — imbalanced
    churned = rng.choice([True, False], n, p=[0.08, 0.92])

    # Text — high cardinality
    notes = [f"Customer {i}: " + ("Premium account with special requirements. " * rng.integers(1, 4)) for i in range(n)]

    # Constant column (no useful info)
    data_source = ["internal_db"] * n

    # Numeric — constant via near-constant (triggers mostly_zeros alert)
    feature_x = np.zeros(n)
    feature_x[rng.integers(0, n, 20)] = rng.uniform(0.1, 1.0, 20)

    # Potential ID column
    user_id = [f"USR-{10000 + i}" for i in range(n)]

    # Low-cardinality integer (should be treated as categorical)
    rating = rng.integers(1, 6, n)

    df = pd.DataFrame({
        "user_id": user_id,
        "age": age,
        "revenue": revenue,
        "score": score,
        "country": country,
        "plan": plan,
        "joined_at": joined_at,
        "churned": churned,
        "notes": notes,
        "data_source": data_source,
        "feature_x": feature_x,
        "rating": rating,
    })

    return df


if __name__ == "__main__":
    print("Generating synthetic demo dataset...")
    df = make_demo_df(n=1_000)
    print(f"DataFrame shape: {df.shape}")

    swift.analyse(
        df,
        title="Swift Demo",
        theme="light",
        open_browser=True,
    )
