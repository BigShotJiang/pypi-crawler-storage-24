"""Tests for swift.reporter module."""

import pytest
import numpy as np
import pandas as pd

from swift.ingestor import ingest
from swift.profiler import profile
from swift.correlator import correlate
from swift.visualizer import visualize
from swift.alerts import scan
from swift.reporter import build
from swift.themes import get_theme


@pytest.fixture
def full_report_args():
    rng = np.random.default_rng(99)
    df = pd.DataFrame({
        "revenue": rng.normal(10000, 3000, 200),
        "region": rng.choice(["North", "South", "East", "West"], 200),
        "closed": rng.choice([True, False], 200),
    })
    meta = ingest(df)
    col_profile = profile(df, meta)
    corr = correlate(df, meta)
    figs = visualize(df, meta, col_profile, corr, theme="light")
    alert_list = scan(df, meta, col_profile)
    theme = get_theme("light")
    return meta, col_profile, corr, figs, alert_list, theme


def test_returns_string(full_report_args):
    meta, col_profile, corr, figs, alert_list, theme = full_report_args
    result = build(meta, col_profile, corr, figs, alert_list, title="Test Report", theme=theme)
    assert isinstance(result, str)


def test_non_empty(full_report_args):
    meta, col_profile, corr, figs, alert_list, theme = full_report_args
    result = build(meta, col_profile, corr, figs, alert_list, title="Test Report", theme=theme)
    assert len(result) > 1000


def test_contains_doctype(full_report_args):
    meta, col_profile, corr, figs, alert_list, theme = full_report_args
    result = build(meta, col_profile, corr, figs, alert_list, title="Test Report", theme=theme)
    assert "<!DOCTYPE html" in result


def test_contains_html_tag(full_report_args):
    meta, col_profile, corr, figs, alert_list, theme = full_report_args
    result = build(meta, col_profile, corr, figs, alert_list, title="Test Report", theme=theme)
    assert "<html" in result


def test_contains_title(full_report_args):
    meta, col_profile, corr, figs, alert_list, theme = full_report_args
    result = build(meta, col_profile, corr, figs, alert_list, title="My Custom Title", theme=theme)
    assert "My Custom Title" in result


def test_contains_plotly_script(full_report_args):
    meta, col_profile, corr, figs, alert_list, theme = full_report_args
    result = build(meta, col_profile, corr, figs, alert_list, title="Test", theme=theme)
    assert "plotly" in result.lower()


def test_contains_column_names(full_report_args):
    meta, col_profile, corr, figs, alert_list, theme = full_report_args
    result = build(meta, col_profile, corr, figs, alert_list, title="Test", theme=theme)
    for col in meta["columns"]:
        assert col in result


def test_dark_theme_report(full_report_args):
    meta, col_profile, corr, figs, alert_list, _ = full_report_args
    dark_theme = get_theme("dark")
    figs_dark = []  # reuse existing figs, just swap theme in build
    result = build(meta, col_profile, corr, figs, alert_list, title="Dark Test", theme=dark_theme)
    assert dark_theme["bg"] in result


def test_no_alerts_shows_clean_message(full_report_args):
    meta, col_profile, corr, figs, _, theme = full_report_args
    result = build(meta, col_profile, corr, figs, [], title="Clean", theme=theme)
    assert "No issues detected" in result


def test_html_is_closed_properly(full_report_args):
    meta, col_profile, corr, figs, alert_list, theme = full_report_args
    result = build(meta, col_profile, corr, figs, alert_list, title="Test", theme=theme)
    assert "</html>" in result
