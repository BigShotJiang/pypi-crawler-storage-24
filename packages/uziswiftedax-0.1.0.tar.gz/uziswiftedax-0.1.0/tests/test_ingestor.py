"""Tests for swift.ingestor module."""

import pytest
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

from swift.ingestor import ingest


@pytest.fixture
def mixed_df():
    """A synthetic DataFrame with all dtype varieties."""
    n = 200
    rng = np.random.default_rng(42)
    return pd.DataFrame({
        "age": rng.integers(18, 80, n).astype(float),
        "salary": rng.normal(50000, 15000, n),
        "country": rng.choice(["USA", "UK", "DE", "FR", "JP"], n),
        "joined_at": [datetime(2020, 1, 1) + timedelta(days=int(d)) for d in rng.integers(0, 1500, n)],
        "is_active": rng.choice([True, False], n),
        "notes": ["Note " + str(i) * 10 for i in range(n)],  # high cardinality text
        "constant_col": ["same_value"] * n,
        "low_int_cat": rng.integers(1, 5, n),  # low cardinality int -> categorical
    })


def test_shape(mixed_df):
    meta = ingest(mixed_df)
    assert meta["shape"] == mixed_df.shape


def test_columns(mixed_df):
    meta = ingest(mixed_df)
    assert set(meta["columns"]) == set(mixed_df.columns)


def test_numeric_cols(mixed_df):
    meta = ingest(mixed_df)
    assert "salary" in meta["numeric_cols"]
    assert "age" in meta["numeric_cols"]


def test_categorical_cols(mixed_df):
    meta = ingest(mixed_df)
    assert "country" in meta["categorical_cols"]


def test_datetime_cols(mixed_df):
    meta = ingest(mixed_df)
    assert "joined_at" in meta["datetime_cols"]


def test_boolean_cols(mixed_df):
    meta = ingest(mixed_df)
    assert "is_active" in meta["boolean_cols"]


def test_text_cols(mixed_df):
    meta = ingest(mixed_df)
    assert "notes" in meta["text_cols"]


def test_constant_cols(mixed_df):
    meta = ingest(mixed_df)
    assert "constant_col" in meta["constant_cols"]
    assert meta["dtypes"]["constant_col"] == "constant"


def test_null_counts_zero_when_no_nulls(mixed_df):
    meta = ingest(mixed_df)
    for col in mixed_df.columns:
        assert meta["null_counts"][col] == int(mixed_df[col].isnull().sum())


def test_null_counts_with_nulls():
    df = pd.DataFrame({"a": [1.0, None, 3.0, None, 5.0]})
    meta = ingest(df)
    assert meta["null_counts"]["a"] == 2
    assert meta["null_pct"]["a"] == 40.0


def test_duplicate_detection():
    df = pd.DataFrame({"a": [1, 1, 2, 3, 4]})
    meta = ingest(df)
    assert meta["duplicate_rows"] == 1


def test_memory_mb_positive(mixed_df):
    meta = ingest(mixed_df)
    assert meta["memory_mb"] > 0


def test_empty_dataframe_raises():
    df = pd.DataFrame()
    with pytest.raises(ValueError, match="empty"):
        ingest(df)


def test_exclude_columns(mixed_df):
    meta = ingest(mixed_df, exclude=["notes", "constant_col"])
    assert "notes" not in meta["columns"]
    assert "constant_col" not in meta["columns"]


def test_max_cat_unique(mixed_df):
    # With max_cat_unique=2, notes (high cardinality) should still be text
    meta = ingest(mixed_df, max_cat_unique=2)
    assert "notes" in meta["text_cols"]


def test_low_cardinality_int_becomes_categorical(mixed_df):
    meta = ingest(mixed_df)
    # low_int_cat has values 1-4 — should be categorical
    assert "low_int_cat" in meta["categorical_cols"]
