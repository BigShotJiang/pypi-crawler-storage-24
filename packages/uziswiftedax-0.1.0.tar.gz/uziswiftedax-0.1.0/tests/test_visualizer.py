"""Tests for swift.visualizer module."""

import json
import pytest
import numpy as np
import pandas as pd

from swift.ingestor import ingest
from swift.profiler import profile
from swift.correlator import correlate
from swift.visualizer import visualize


@pytest.fixture
def full_setup():
    rng = np.random.default_rng(7)
    df = pd.DataFrame({
        "price": rng.normal(200, 50, 300),
        "category": rng.choice(["X", "Y", "Z"], 300),
        "active": rng.choice([True, False], 300),
        "quantity": rng.integers(1, 100, 300).astype(float),
    })
    meta = ingest(df)
    col_profile = profile(df, meta)
    corr = correlate(df, meta)
    return df, meta, col_profile, corr


def test_returns_list(full_setup):
    df, meta, col_profile, corr = full_setup
    result = visualize(df, meta, col_profile, corr, theme="light")
    assert isinstance(result, list)


def test_each_item_has_fig_json(full_setup):
    df, meta, col_profile, corr = full_setup
    result = visualize(df, meta, col_profile, corr, theme="light")
    for item in result:
        assert "fig_json" in item, f"Missing fig_json in {item.get('col')}"


def test_fig_json_is_valid_json(full_setup):
    df, meta, col_profile, corr = full_setup
    result = visualize(df, meta, col_profile, corr, theme="light")
    for item in result:
        try:
            parsed = json.loads(item["fig_json"])
            assert "data" in parsed
            assert "layout" in parsed
        except json.JSONDecodeError as e:
            pytest.fail(f"Invalid JSON in fig_json for column {item.get('col')}: {e}")


def test_numeric_col_has_chart(full_setup):
    df, meta, col_profile, corr = full_setup
    result = visualize(df, meta, col_profile, corr)
    col_names = [r["col"] for r in result]
    assert "price" in col_names


def test_categorical_col_has_chart(full_setup):
    df, meta, col_profile, corr = full_setup
    result = visualize(df, meta, col_profile, corr)
    col_names = [r["col"] for r in result]
    assert "category" in col_names


def test_boolean_col_has_chart(full_setup):
    df, meta, col_profile, corr = full_setup
    result = visualize(df, meta, col_profile, corr)
    col_names = [r["col"] for r in result]
    assert "active" in col_names


def test_overview_charts_present(full_setup):
    df, meta, col_profile, corr = full_setup
    result = visualize(df, meta, col_profile, corr)
    sections = [r.get("section") for r in result]
    assert "overview" in sections


def test_dark_theme_runs(full_setup):
    df, meta, col_profile, corr = full_setup
    result = visualize(df, meta, col_profile, corr, theme="dark")
    assert len(result) > 0


def test_constant_col_excluded():
    df = pd.DataFrame({
        "x": [1.0, 2.0, 3.0],
        "const": ["same", "same", "same"],
    })
    meta = ingest(df)
    col_profile = profile(df, meta)
    corr = correlate(df, meta)
    result = visualize(df, meta, col_profile, corr)
    col_names = [r["col"] for r in result]
    assert "const" not in col_names


def test_all_null_col_excluded():
    df = pd.DataFrame({
        "valid": [1.0, 2.0, 3.0, 4.0, 5.0],
        "all_null": [None, None, None, None, None],
    })
    meta = ingest(df)
    col_profile = profile(df, meta)
    corr = correlate(df, meta)
    result = visualize(df, meta, col_profile, corr)
    col_names = [r["col"] for r in result]
    assert "all_null" not in col_names
