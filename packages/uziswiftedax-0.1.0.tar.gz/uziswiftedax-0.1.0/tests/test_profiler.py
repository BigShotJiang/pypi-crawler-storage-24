"""Tests for swift.profiler module."""

import pytest
import numpy as np
import pandas as pd

from swift.ingestor import ingest
from swift.profiler import profile


@pytest.fixture
def df_and_meta():
    rng = np.random.default_rng(0)
    df = pd.DataFrame({
        "score": rng.normal(50, 10, 500),
        "category": rng.choice(["A", "B", "C", "D"], 500),
        "score_with_nulls": [float(x) if i % 10 != 0 else None for i, x in enumerate(rng.normal(0, 1, 500))],
    })
    meta = ingest(df)
    return df, meta


def test_profile_returns_all_columns(df_and_meta):
    df, meta = df_and_meta
    result = profile(df, meta)
    for col in meta["columns"]:
        assert col in result


def test_numeric_mean(df_and_meta):
    df, meta = df_and_meta
    result = profile(df, meta)
    np_mean = float(df["score"].mean())
    assert abs(result["score"]["mean"] - np_mean) < 0.01


def test_numeric_median(df_and_meta):
    df, meta = df_and_meta
    result = profile(df, meta)
    np_median = float(df["score"].median())
    assert abs(result["score"]["median"] - np_median) < 0.01


def test_numeric_null_count():
    df = pd.DataFrame({"x": [1.0, 2.0, None, 4.0, None]})
    meta = ingest(df)
    result = profile(df, meta)
    assert result["x"]["null_count"] == 2
    assert result["x"]["null_pct"] == 40.0


def test_numeric_outliers():
    # Most values are normal, add an obvious outlier
    df = pd.DataFrame({"x": list(range(100)) + [10000]})
    meta = ingest(df)
    result = profile(df, meta)
    assert result["x"]["outlier_count"] >= 1


def test_categorical_top_values(df_and_meta):
    df, meta = df_and_meta
    result = profile(df, meta)
    assert "top_values" in result["category"]
    assert isinstance(result["category"]["top_values"], list)
    assert len(result["category"]["top_values"]) <= 10


def test_categorical_unique(df_and_meta):
    df, meta = df_and_meta
    result = profile(df, meta)
    assert result["category"]["unique"] == 4


def test_categorical_entropy(df_and_meta):
    df, meta = df_and_meta
    result = profile(df, meta)
    assert result["category"]["entropy"] > 0


def test_categorical_top_value(df_and_meta):
    df, meta = df_and_meta
    result = profile(df, meta)
    assert result["category"]["top_value"] in ["A", "B", "C", "D"]


def test_all_null_numeric():
    df = pd.DataFrame({"x": [None, None, None]})
    meta = ingest(df)
    result = profile(df, meta)
    # Should not crash; most stats should be None
    assert result["x"]["null_count"] == 3


def test_boolean_profile():
    df = pd.DataFrame({"flag": [True, True, False, True, False]})
    meta = ingest(df)
    result = profile(df, meta)
    assert result["flag"]["true_count"] == 3
    assert result["flag"]["false_count"] == 2
    assert result["flag"]["true_pct"] == 60.0


def test_text_profile():
    df = pd.DataFrame({"comment": [f"This is comment number {i} with some words" for i in range(100)]})
    meta = ingest(df, max_cat_unique=5)
    result = profile(df, meta)
    assert result["comment"]["avg_length"] > 0
    assert result["comment"]["min_length"] > 0
    assert result["comment"]["max_length"] >= result["comment"]["min_length"]
