# swift-eda — Documentation

## Table of Contents

- [Installation](#installation)
- [Quick start](#quick-start)
- [API reference](#api-reference)
  - [swift.analyse()](#swiftanalyse)
  - [swift.display()](#swiftdisplay)
- [Report sections](#report-sections)
- [Module reference](#module-reference)
  - [ingestor](#ingestor)
  - [profiler](#profiler)
  - [correlator](#correlator)
  - [visualizer](#visualizer)
  - [alerts](#alerts)
  - [reporter](#reporter)
  - [themes](#themes)
- [Alert types](#alert-types)
- [Themes](#themes-1)
- [Configuration tips](#configuration-tips)
- [Extending swift](#extending-swift)

---

## Installation

```bash
pip install swift-eda
```

**Dependencies** (auto-installed):

| Package | Min version | Purpose |
|---|---|---|
| pandas | 1.3.0 | DataFrames |
| numpy | 1.21.0 | Numerics |
| plotly | 5.0.0 | Interactive charts |
| scipy | 1.7.0 | Statistics (Pearson, Spearman, Cramér's V) |
| rich | 12.0.0 | Terminal output |
| jinja2 | 3.0.0 | (reserved for future template features) |

**Python:** 3.8 and above.

---

## Quick start

```python
import pandas as pd
import swift

df = pd.read_csv("my_data.csv")
swift.analyse(df)
```

One call. The report opens in your default browser automatically.

---

## API reference

### `swift.analyse()`

```python
swift.analyse(
    df,
    title="Dataset",
    theme="light",
    export=None,
    open_browser=True,
    exclude=None,
    max_cat_unique=50,
)
```

**Parameters**

| Parameter | Type | Default | Description |
|---|---|---|---|
| `df` | `pd.DataFrame` | required | The DataFrame to analyse |
| `title` | `str` | `"Dataset"` | Title shown in the report header and browser tab |
| `theme` | `str` | `"light"` | Color theme: `"light"` or `"dark"` |
| `export` | `str \| None` | `None` | File path to save the HTML to. If `None`, a temp file is used |
| `open_browser` | `bool` | `True` | Whether to open the report in the default browser |
| `exclude` | `list[str] \| None` | `None` | Column names to skip entirely |
| `max_cat_unique` | `int` | `50` | Max unique values for an object column to be treated as categorical. Columns with more are treated as text |

**Returns** `str` — the absolute path to the generated HTML file.

**Example**

```python
# Full customisation
path = swift.analyse(
    df,
    title="Q3 Customer Churn",
    theme="dark",
    export="reports/churn_q3.html",
    open_browser=False,
    exclude=["customer_id", "row_hash"],
    max_cat_unique=30,
)
print(f"Saved to: {path}")
```

---

### `swift.display()`

Renders the report **inline inside a Jupyter or IPython notebook cell** using an IFrame.

```python
swift.display(
    df,
    title="Dataset",
    theme="light",
    exclude=None,
    max_cat_unique=50,
    height=800,
)
```

**Parameters** — same as `analyse()` plus:

| Parameter | Type | Default | Description |
|---|---|---|---|
| `height` | `int` | `800` | IFrame height in pixels |

**Example**

```python
# In a Jupyter cell:
import swift
swift.display(df, theme="dark", height=1000)
```

If IPython is not available, falls back to `swift.analyse()` with `open_browser=True`.

---

## Report sections

Every generated report contains four navigable sections accessible via the fixed sidebar.

### Overview

- **Stat cards**: total rows, total columns, total missing cells (with %), duplicate rows (with %)
- **Null heatmap**: shows the pattern of missing values across all rows (sampled to 500 for performance)
- **Null % bar chart**: columns ranked by missingness, color-coded by severity

### Columns

One card per column, grouped by inferred type:

- **Numeric** — histogram + box plot, stat chips (mean, median, std, min, max, nulls, outlier %, skewness)
- **Categorical** — horizontal frequency bar, stat chips (unique, top value, top %, entropy)
- **Datetime** — monthly record count line chart, stat chips (date range, span in days)
- **Boolean** — donut chart (True vs False), stat chips (true %, null count)
- **Text** — string length histogram, stat chips (unique, avg/min/max length)
- **Constant** — no chart (value carries no information), alert fires automatically

Inline alerts appear above each column's chart.

### Correlations

- **Pearson correlation heatmap** — annotated, diverging colorscale (−1 to +1)
- **Top correlations bar chart** — top 10 pairs by |r|, color-coded negative vs positive
- **Cramér's V table** — categorical pair associations (0 = no association, 1 = perfect)
- **Point-biserial table** — numeric × binary categorical associations

### Alerts

All data quality alerts with severity badges, icons, column pills, and messages. Severities:

- 🔴 **critical** — data is likely unusable as-is (constant column, extreme nulls, extreme skew)
- 🟡 **warning** — potential issue worth investigating (high skew, outliers, imbalance)
- 🔵 **info** — informational observation (possible ID column, low entropy)

---

## Module reference

### ingestor

**`ingest(df, max_cat_unique=50, exclude=None) → dict`**

Smart dtype inference. Returns a metadata dict with keys:

```
shape, columns, dtypes, null_counts, null_pct,
duplicate_rows, duplicate_pct, memory_mb,
numeric_cols, categorical_cols, datetime_cols,
text_cols, boolean_cols, constant_cols
```

**Inference rules:**

| pandas dtype | Inferred as |
|---|---|
| `float64`, `int64` with many unique values | `"numeric"` |
| `int64` with ≤ 10 unique values | `"categorical"` |
| `bool` | `"boolean"` |
| `datetime64` or parseable date strings | `"datetime"` |
| `object` with ≤ `max_cat_unique` unique values | `"categorical"` |
| `object` with > `max_cat_unique` unique values | `"text"` |
| Any column with exactly 1 unique value | `"constant"` |

---

### profiler

**`profile(df, meta) → dict`**

Returns a dict keyed by column name. Each value is a stats dict whose keys depend on the inferred dtype.

Key stats by dtype:

- **numeric**: `mean`, `median`, `std`, `min`, `max`, `q1`, `q3`, `iqr`, `skewness`, `kurtosis`, `outlier_count`, `outlier_pct`, `zeros`, `zeros_pct`, `negative_count`
- **categorical**: `unique`, `top_values` (top 10 as `[[value, count]]`), `top_value`, `top_value_pct`, `entropy`
- **datetime**: `min_date`, `max_date`, `range_days`, `most_common_year`, `most_common_month`, `gaps_detected`
- **text**: `avg_length`, `min_length`, `max_length`, `unique`
- **boolean**: `true_count`, `false_count`, `true_pct`

---

### correlator

**`correlate(df, meta) → dict`**

Returns:

```python
{
    "numeric_matrix": pd.DataFrame,   # Pearson r matrix
    "spearman_matrix": pd.DataFrame,  # Spearman ρ matrix
    "top_pairs": [...],               # Top 15 numeric pairs by |r|
    "cat_associations": [...],        # Cramér's V for categorical pairs
    "mixed_pairs": [...],             # Point-biserial for numeric × binary
}
```

---

### visualizer

**`visualize(df, meta, profile, correlations, theme="light") → list[dict]`**

Auto-selects charts by dtype. Each list item:

```python
{
    "col": "age",
    "dtype": "numeric",
    "section": "distributions",   # or "overview" or "correlations"
    "title": "age — distribution",
    "fig": <plotly Figure>,
    "fig_json": "...",             # fig.to_json() — embedded in HTML
}
```

---

### alerts

**`scan(df, meta, profile) → list[dict]`**

Each alert:

```python
{
    "level": "warning",       # "critical" | "warning" | "info"
    "col": "email",           # None for dataset-level alerts
    "message": "...",
    "type": "high_cardinality"
}
```

See [Alert types](#alert-types) for the full list.

---

### reporter

**`build(meta, profile, correlations, figures, alerts, title, theme) → str`**

Assembles everything into a self-contained HTML string. The only external resource is the Plotly CDN script tag. Everything else (CSS, fonts, chart data) is inline.

---

### themes

**`get_theme(name) → dict`**

Returns a theme dict for `"light"` or `"dark"`. Keys:

```
bg, surface, surface2, border,
text_primary, text_secondary, text_muted,
accent, accent_light, success, warning, danger, info,
plot_bg, paper_bg, grid_color, colorscale,
bar_color, histogram_color, box_color, donut_colors
```

---

## Alert types

| Type | Condition | Level |
|---|---|---|
| `high_nulls` | null % > 40% | critical |
| `moderate_nulls` | null % between 5–40% | warning |
| `constant_column` | only 1 unique value | critical |
| `high_cardinality` | categorical with unique > 95% of rows | warning |
| `possible_id_column` | name contains "id/uuid/key/index" or unique == row count | info |
| `high_skew` | \|skewness\| > 2 | warning |
| `extreme_skew` | \|skewness\| > 5 | critical |
| `many_outliers` | outlier % > 5% | warning |
| `all_zeros` | zeros % = 100% | critical |
| `mostly_zeros` | zeros % > 80% | warning |
| `duplicate_rows` | duplicate % > 1% | warning |
| `many_duplicates` | duplicate % > 10% | critical |
| `imbalanced_binary` | boolean minority class < 10% | warning |
| `imbalanced_categorical` | top category > 90% of rows | warning |
| `low_entropy` | categorical entropy < 0.5 | info |
| `single_row` | df has < 10 rows | critical |
| `too_wide` | df has > 200 columns | info |
| `mixed_types_suspected` | object column mixing numeric and string values | warning |
| `negative_values` | numeric column named "age/price/count/…" has negatives | warning |

---

## Themes

**Light** (default): white background, soft surfaces, purple accent (`#5b5bd6`).

**Dark**: deep navy background (`#0f1117`), raised surface (`#1a1c23`), brighter purple accent.

```python
swift.analyse(df, theme="dark")
```

---

## Configuration tips

**Skip ID / UUID columns**
```python
swift.analyse(df, exclude=["id", "user_uuid", "session_key"])
```

**Tune categorical detection** (default treats object columns with ≤ 50 unique values as categorical)
```python
# Stricter — only up to 20 unique values treated as categorical
swift.analyse(df, max_cat_unique=20)
```

**Large DataFrames** — swift automatically samples to 50,000 rows for charts, but computes stats on the full dataset. You'll see a notice in the terminal when this happens.

**Save without opening browser**
```python
path = swift.analyse(df, export="report.html", open_browser=False)
```

---

## Extending swift

Each module is a plain Python file with a single public function — easy to fork and customise.

**Add a custom alert:**
```python
# in swift/alerts.py, inside scan():
if some_condition:
    alerts.append({
        "level": "warning",
        "col": col,
        "message": "Your custom message.",
        "type": "my_custom_alert",
    })
```

**Add a custom chart:**
```python
# in swift/visualizer.py, add a new function and call it in the main loop
def _my_chart(series, col, t, font_family, base_layout, style_axes):
    fig = go.Figure(...)
    fig.update_layout(**base_layout(...))
    return fig
```

**Use the pipeline programmatically:**
```python
from swift.ingestor import ingest
from swift.profiler import profile
from swift.correlator import correlate
from swift.alerts import scan
from swift.themes import get_theme

meta = ingest(df)
prof = profile(df, meta)
corr = correlate(df, meta)
alerts = scan(df, meta, prof)
# Use the structured data however you like
```
