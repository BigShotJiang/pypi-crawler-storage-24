"""Moved to clausal.modules.regex. Import from there directly."""
from clausal.modules.regex import *  # noqa: F401,F403
