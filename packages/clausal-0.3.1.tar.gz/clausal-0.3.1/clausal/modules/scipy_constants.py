"""Alias: clausal.modules.scipy_constants → clausal.modules.py.scipy_constants."""
from clausal.modules.py.scipy_constants import *  # noqa: F401,F403
from clausal.modules.py.scipy_constants import (  # noqa: F401
    Value, Unit, Precision, Lookup, Find, AllNames,
    SpeedOfLight, PlanckConstant, ReducedPlanckConstant,
    GravitationalConstant, AvogadroConstant, BoltzmannConstant,
    ElementaryCharge, ElectronMass, ProtonMass,
    ElectronVolt, StandardAtmosphere,
    Kilo, Mega, Giga,
)
