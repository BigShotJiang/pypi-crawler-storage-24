"""Alias: clausal.modules.scipy_integrate → clausal.modules.py.scipy_integrate."""
from clausal.modules.py.scipy_integrate import *  # noqa: F401,F403
from clausal.modules.py.scipy_integrate import (  # noqa: F401
    Quad, DoubleQuad, TripleQuad, NQuad, QuadVec,
    SolveInitialValueProblem, OdeIntegrate,
    CumulativeTrapezoid, Trapezoid, Simpson,
    ResultGet,
)
