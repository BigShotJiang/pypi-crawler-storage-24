"""Alias: clausal.modules.scipy_cluster → clausal.modules.py.scipy_cluster."""
from clausal.modules.py.scipy_cluster import *  # noqa: F401,F403
from clausal.modules.py.scipy_cluster import (  # noqa: F401
    Linkage, FlatCluster, Dendrogram, Cophenet, Inconsistent,
    KMeans2, KMeans, VectorQuantize, Whiten,
    ResultGet,
)
