"""Alias: clausal.modules.scipy_fft → clausal.modules.py.scipy_fft."""
from clausal.modules.py.scipy_fft import *  # noqa: F401,F403
from clausal.modules.py.scipy_fft import (  # noqa: F401
    FFTransform,
    FFTransform2D,
    FFTransformND,
    RealFFT,
    DiscreteCosineTransform,
    DiscreteSineTransform,
    FFTFrequencies, RealFFTFrequencies,
    FFTShift,
)
