"""Alias: clausal.modules.scipy_differentiate → clausal.modules.py.scipy_differentiate."""
from clausal.modules.py.scipy_differentiate import *  # noqa: F401,F403
from clausal.modules.py.scipy_differentiate import (  # noqa: F401
    Derivative, Jacobian, Hessian, ResultGet,
)
