"""Alias: clausal.modules.scipy_ndimage → clausal.modules.py.scipy_ndimage."""
from clausal.modules.py.scipy_ndimage import *  # noqa: F401,F403
from clausal.modules.py.scipy_ndimage import (  # noqa: F401
    GaussianFilter,
    UniformFilter,
    MedianFilter,
    Convolve,
    Label,
    BinaryErosion,
    BinaryDilation,
    BinaryOpening,
    BinaryClosing,
    Zoom,
    Rotate,
    Shift,
    FindObjects,
    CenterOfMass,
)
