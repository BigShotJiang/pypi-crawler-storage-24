# clausal.tools — developer utilities for inspecting and debugging clausal predicates
