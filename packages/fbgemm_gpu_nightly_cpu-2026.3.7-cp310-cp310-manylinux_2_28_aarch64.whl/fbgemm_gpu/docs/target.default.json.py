
{
    "version": "2026.3.7",
    "target": "default",
    "variant": "cpu"
}
