"""Tests for the API module."""

from io import BytesIO
from unittest.mock import MagicMock, patch

import httpx
import pytest

from dimitra_core.api.utils import APIClient


@pytest.fixture
def mock_httpx_client():
    """Create and inject a mock httpx Client."""
    mock_client = MagicMock()
    with patch("httpx.Client", return_value=mock_client):
        yield mock_client


class TestAPIClientInit:
    """Test APIClient initialization."""

    def test_init_with_api_key(self, mock_httpx_client):
        """Test that Authorization header is set when api_key is provided."""
        client = APIClient(base_url="https://api.example.com", api_key="my-secret-key")

        assert client.api_key == "my-secret-key"
        assert client.base_url == "https://api.example.com"

    def test_init_without_api_key(self, mock_httpx_client):
        """Test that api_key defaults to None and no Authorization header is set."""
        client = APIClient(base_url="https://api.example.com")

        assert client.api_key is None

    def test_init_default_timeout(self, mock_httpx_client):
        """Test that DEFAULT_TIMEOUT is used when timeout is not specified."""
        from dimitra_core.api.constants import DEFAULT_TIMEOUT

        client = APIClient(base_url="https://api.example.com")

        assert client.timeout == DEFAULT_TIMEOUT

    def test_init_custom_timeout(self, mock_httpx_client):
        """Test that a custom timeout value is applied."""
        client = APIClient(base_url="https://api.example.com", timeout=60)

        assert client.timeout == 60


class TestCallApi:
    """Test call_api method."""

    @pytest.fixture
    def api_client(self, mock_httpx_client):
        """Create an APIClient backed by a mock httpx Client."""
        client = APIClient(base_url="https://api.example.com", api_key="test-key")
        return client, mock_httpx_client

    def test_call_api_get_success(self, api_client):
        """Test successful GET request returns parsed data, is_ok=True, and status code."""
        client, mock_http = api_client

        mock_response = MagicMock()
        mock_response.json.return_value = {"message": "hello"}
        mock_response.status_code = 200
        mock_http.request.return_value = mock_response

        data, is_ok, status_code = client.call_api(method="GET", endpoint="/hello")

        assert data == {"message": "hello"}
        assert is_ok is True
        assert status_code == 200

    def test_call_api_post_with_json_body(self, api_client):
        """Test POST request sends JSON body and returns correct response."""
        client, mock_http = api_client

        mock_response = MagicMock()
        mock_response.json.return_value = {"id": 1}
        mock_response.status_code = 201
        mock_http.request.return_value = mock_response

        data, is_ok, status_code = client.call_api(
            method="POST", endpoint="/items", body={"name": "test"}
        )

        mock_http.request.assert_called_once_with(
            method="POST", url="/items", params=None, json={"name": "test"}, data=None, files=None
        )
        assert data == {"id": 1}
        assert is_ok is True
        assert status_code == 201

    def test_call_api_with_form_data(self, api_client):
        """Test POST request sends form data instead of JSON body."""
        client, mock_http = api_client

        mock_response = MagicMock()
        mock_response.json.return_value = {"success": True}
        mock_response.status_code = 200
        mock_http.request.return_value = mock_response

        data, is_ok, status_code = client.call_api(
            method="POST", endpoint="/submit", form_data={"field": "value"}
        )

        mock_http.request.assert_called_once_with(
            method="POST", url="/submit", params=None, json=None, data={"field": "value"}, files=None
        )
        assert is_ok is True

    def test_call_api_with_file_like_object(self, api_client):
        """Test that form_data with a file-like object sends as multipart/form-data."""
        client, mock_http = api_client

        mock_response = MagicMock()
        mock_response.json.return_value = {"uploaded": True}
        mock_response.status_code = 200
        mock_http.request.return_value = mock_response

        file_obj = BytesIO(b"file content")
        data, is_ok, status_code = client.call_api(
            method="POST",
            endpoint="/upload",
            form_data={"file": file_obj, "name": "test.txt"},
        )

        mock_http.request.assert_called_once_with(
            method="POST",
            url="/upload",
            params=None,
            json=None,
            data={"name": "test.txt"},
            files={"file": file_obj},
        )
        assert is_ok is True
        assert status_code == 200

    def test_call_api_with_tuple_file(self, api_client):
        """Test that form_data with a tuple value sends as multipart/form-data."""
        client, mock_http = api_client

        mock_response = MagicMock()
        mock_response.json.return_value = {"uploaded": True}
        mock_response.status_code = 200
        mock_http.request.return_value = mock_response

        file_obj = BytesIO(b"image data")
        file_tuple = ("photo.png", file_obj, "image/png")
        data, is_ok, status_code = client.call_api(
            method="POST",
            endpoint="/upload",
            form_data={"file": file_tuple, "app": "diseases", "crop": "avocado"},
        )

        mock_http.request.assert_called_once_with(
            method="POST",
            url="/upload",
            params=None,
            json=None,
            data={"app": "diseases", "crop": "avocado"},
            files={"file": file_tuple},
        )
        assert is_ok is True

    def test_call_api_with_only_file_no_regular_fields(self, api_client):
        """Test that form_data with only file fields sends files without data."""
        client, mock_http = api_client

        mock_response = MagicMock()
        mock_response.json.return_value = {"uploaded": True}
        mock_response.status_code = 200
        mock_http.request.return_value = mock_response

        file_obj = BytesIO(b"content")
        data, is_ok, status_code = client.call_api(
            method="POST",
            endpoint="/upload",
            form_data={"file": file_obj},
        )

        mock_http.request.assert_called_once_with(
            method="POST",
            url="/upload",
            params=None,
            json=None,
            data=None,
            files={"file": file_obj},
        )
        assert is_ok is True

    def test_call_api_with_query_params(self, api_client):
        """Test GET request passes query parameters to the underlying request."""
        client, mock_http = api_client

        mock_response = MagicMock()
        mock_response.json.return_value = []
        mock_response.status_code = 200
        mock_http.request.return_value = mock_response

        client.call_api(method="GET", endpoint="/search", params={"q": "test", "page": 1})

        mock_http.request.assert_called_once_with(
            method="GET", url="/search", params={"q": "test", "page": 1}, json=None, data=None, files=None
        )

    def test_call_api_error_response(self, api_client):
        """Test that 4xx responses return is_ok=False with the correct status code."""
        client, mock_http = api_client

        mock_response = MagicMock()
        mock_response.json.return_value = {"error": "not found"}
        mock_response.status_code = 404
        mock_http.request.return_value = mock_response

        data, is_ok, status_code = client.call_api(method="GET", endpoint="/missing")

        assert data == {"error": "not found"}
        assert is_ok is False
        assert status_code == 404

    def test_call_api_server_error_response(self, api_client):
        """Test that 5xx responses return is_ok=False."""
        client, mock_http = api_client

        mock_response = MagicMock()
        mock_response.json.return_value = {"error": "internal server error"}
        mock_response.status_code = 500
        mock_http.request.return_value = mock_response

        data, is_ok, status_code = client.call_api(method="GET", endpoint="/broken")

        assert is_ok is False
        assert status_code == 500

    def test_call_api_non_json_response(self, api_client):
        """Test that non-JSON responses return data=None with correct is_ok and status code."""
        client, mock_http = api_client

        mock_response = MagicMock()
        mock_response.json.side_effect = Exception("Not JSON")
        mock_response.status_code = 200
        mock_http.request.return_value = mock_response

        data, is_ok, status_code = client.call_api(method="GET", endpoint="/text")

        assert data is None
        assert is_ok is True
        assert status_code == 200

    def test_call_api_timeout(self, api_client):
        """Test that a TimeoutException returns (None, False, 408)."""
        client, mock_http = api_client

        mock_http.request.side_effect = httpx.TimeoutException("")

        data, is_ok, status_code = client.call_api(method="GET", endpoint="/slow")

        assert data is None
        assert is_ok is False
        assert status_code == 408

    def test_call_api_connection_error(self, api_client):
        """Test that a RequestError returns (None, False, 503)."""
        client, mock_http = api_client

        mock_http.request.side_effect = httpx.RequestError("")

        data, is_ok, status_code = client.call_api(method="GET", endpoint="/unreachable")

        assert data is None
        assert is_ok is False
        assert status_code == 503


class TestCallApiAsync:
    """Test call_api_async method."""

    @pytest.fixture
    def api_client(self, mock_httpx_client):
        """Create an APIClient backed by a mock httpx Client."""
        client = APIClient(base_url="https://api.example.com", api_key="test-key")
        return client, mock_httpx_client

    def test_call_api_async_returns_future(self, api_client):
        """Test that call_api_async returns a Future immediately."""
        from concurrent.futures import Future

        client, mock_http = api_client

        mock_response = MagicMock()
        mock_response.json.return_value = {"message": "hello"}
        mock_response.status_code = 200
        mock_http.request.return_value = mock_response

        future = client.call_api_async(method="GET", endpoint="/hello")

        assert isinstance(future, Future)

    def test_call_api_async_result_matches_call_api(self, api_client):
        """Test that the Future resolves to the same tuple as call_api."""
        client, mock_http = api_client

        mock_response = MagicMock()
        mock_response.json.return_value = {"id": 42}
        mock_response.status_code = 200
        mock_http.request.return_value = mock_response

        future = client.call_api_async(method="GET", endpoint="/items/42")
        data, is_ok, status_code = future.result(timeout=5)

        assert data == {"id": 42}
        assert is_ok is True
        assert status_code == 200

    def test_call_api_async_timeout_returns_408(self, api_client):
        """Test that a timeout in the background thread resolves to (None, False, 408)."""
        client, mock_http = api_client

        mock_http.request.side_effect = httpx.TimeoutException("")

        future = client.call_api_async(method="GET", endpoint="/slow")
        data, is_ok, status_code = future.result(timeout=5)

        assert data is None
        assert is_ok is False
        assert status_code == 408

    def test_call_api_async_done_callback(self, api_client):
        """Test that add_done_callback is invoked when the Future completes."""
        client, mock_http = api_client

        mock_response = MagicMock()
        mock_response.json.return_value = {}
        mock_response.status_code = 200
        mock_http.request.return_value = mock_response

        results = []
        future = client.call_api_async(method="GET", endpoint="/ping")
        future.add_done_callback(lambda f: results.append(f.result()))
        future.result(timeout=5)  # ensure completion before asserting

        assert len(results) == 1
        assert results[0][1] is True  # is_ok
