from concurrent.futures import Future, ThreadPoolExecutor
from http import HTTPStatus
from typing import Any

from dimitra_core.api.constants import DEFAULT_TIMEOUT


class APIClient:
    def __init__(
        self, base_url: str, timeout: int = DEFAULT_TIMEOUT, api_key: str | None = None
    ) -> None:
        """Initialize the API client with base URL and optional authentication.

        Args:
            base_url: Base URL for all API requests (e.g. "https://api.example.com").
            timeout: Request timeout in seconds. Defaults to DEFAULT_TIMEOUT.
            api_key: Optional API key for Bearer token authentication.
                     If provided, sets the Authorization header on all requests.
        """
        import httpx

        self.base_url = base_url
        self.api_key = api_key
        self.timeout = timeout

        headers = {"Accept": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {api_key}"

        self.client = httpx.Client(
            base_url=self.base_url, headers=headers, timeout=self.timeout
        )
        self.executor = ThreadPoolExecutor(max_workers=10)

    @staticmethod
    def _split_form_data(
        form_data: dict,
    ) -> tuple[dict[str, Any], dict[str, Any]]:
        """Split form_data into regular fields and file fields.

        A value is considered a file if it has a `read` method (file-like object)
        or is a tuple (httpx file upload format: (filename, file_obj[, content_type])).

        Args:
            form_data: Dictionary of form fields to split.

        Returns:
            tuple: (regular_fields, file_fields) where each is a dict.
        """
        regular_fields: dict[str, Any] = {}
        file_fields: dict[str, Any] = {}

        for key, value in form_data.items():
            if hasattr(value, "read") or isinstance(value, tuple):
                file_fields[key] = value
            else:
                regular_fields[key] = value

        return regular_fields, file_fields

    def call_api(
        self,
        method: str,
        endpoint: str,
        params: dict | None = None,
        body: Any = None,
        form_data: dict | None = None,
    ) -> tuple[Any, bool, int]:
        """Make an HTTP request and return the parsed response.

        Args:
            method: HTTP method (e.g. "GET", "POST", "PUT", "DELETE").
            endpoint: API endpoint path relative to base_url.
            params: Query parameters to append to the request URL.
            body: JSON-serializable request body. Sent as application/json.
                  Sets Content-Type to application/json automatically.
            form_data: Form fields to send. Auto-detects encoding:
                       - If any value is a file-like object (has `read`) or a tuple,
                         sends as multipart/form-data.
                       - Otherwise, sends as application/x-www-form-urlencoded.

        Returns:
            tuple: A 3-tuple of (data, is_ok, status_code) where:
                - data (Any): Parsed JSON response body, or None if not JSON-parseable.
                - is_ok (bool): True if the response status code indicates success (2xx).
                - status_code (int): HTTP status code as an integer.
        """
        import httpx
        from httpx import codes

        # Split form_data into regular fields and file fields if present
        data: dict[str, Any] | None = None
        files: dict[str, Any] | None = None
        if form_data:
            regular_fields, file_fields = self._split_form_data(form_data)
            if file_fields:
                files = file_fields
                data = regular_fields if regular_fields else None
            else:
                data = regular_fields

        try:
            response = self.client.request(
                method=method,
                url=endpoint,
                params=params,
                json=body,
                data=data,
                files=files,
            )
        except httpx.TimeoutException:
            return None, False, HTTPStatus.REQUEST_TIMEOUT.value
        except httpx.RequestError:
            return None, False, HTTPStatus.SERVICE_UNAVAILABLE.value

        try:
            data = response.json()
        except Exception:
            data = None

        is_ok = codes.is_success(response.status_code)
        return data, is_ok, response.status_code

    def call_api_async(
        self,
        method: str,
        endpoint: str,
        params: dict | None = None,
        body: Any = None,
        form_data: dict | None = None,
    ) -> Future:
        """Submit an API request to a background thread and return a Future.

        Behaves like call_api but runs in a thread pool, returning immediately
        with a Future that resolves to the same (data, is_ok, status_code) tuple.
        Use future.result() to block and retrieve the response when needed.

        Args:
            method: HTTP method (e.g. "GET", "POST", "PUT", "DELETE").
            endpoint: API endpoint path relative to base_url.
            params: Query parameters to append to the request URL.
            body: JSON-serializable request body. Sent as application/json.
            form_data: Form fields to send. Auto-detects multipart vs urlencoded.

        Returns:
            Future: A concurrent.futures.Future that resolves to a 3-tuple
                (data, is_ok, status_code) identical to call_api's return value.

        Example:
            future = api_client.call_api_async(method="GET", endpoint="/data")
            # do other work ...
            data, is_ok, status = future.result()
        """
        return self.executor.submit(
            self.call_api, method, endpoint, params, body, form_data
        )
