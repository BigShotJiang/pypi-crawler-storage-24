"""
Clore.ai Python SDK and CLI

A modern Python SDK for interacting with the Clore.ai GPU marketplace API.
"""

from clore_ai.client import CloreAI, AsyncCloreAI
from clore_ai.exceptions import (
    CloreAPIError,
    RateLimitError,
    AuthError,
    InvalidInputError,
    DBError,
    InvalidEndpointError,
    FieldError,
)
from clore_ai.models import (
    MarketplaceServer,
    MyServer,
    Order,
    ServerConfig,
    SpotMarket,
    Wallet,
)

# Backward-compatible alias
Server = MarketplaceServer

__version__ = "0.1.0"
__all__ = [
    "CloreAI",
    "AsyncCloreAI",
    "CloreAPIError",
    "RateLimitError",
    "AuthError",
    "InvalidInputError",
    "DBError",
    "InvalidEndpointError",
    "FieldError",
    "MarketplaceServer",
    "Server",
    "MyServer",
    "Order",
    "ServerConfig",
    "SpotMarket",
    "Wallet",
]
