#!/usr/bin/env bash
# BeeQ install script
# curl -fsSL https://beeq.run/install | bash

set -e

BEEQ_VERSION="1.0.0"
BOLD="\033[1m"
GREEN="\033[0;32m"
YELLOW="\033[0;33m"
DIM="\033[2m"
RESET="\033[0m"

echo ""
echo -e "${BOLD}${YELLOW}◈ BeeQ${RESET} ${DIM}— The First AI Hive${RESET}"
echo -e "${DIM}Every action signed. You remain sovereign.${RESET}"
echo ""

# Detect system
OS=$(uname -s)
ARCH=$(uname -m)
echo -e "[1/4] ${DIM}Detecting system...${RESET}          ${OS} ${ARCH} ✓"

# Check Python 3.10+
if ! command -v python3 &>/dev/null; then
    echo "Python 3.10+ is required. Please install it first."
    echo "https://www.python.org/downloads/"
    exit 1
fi

PY_VER=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
PY_MAJOR=$(python3 -c "import sys; print(sys.version_info.major)")
PY_MINOR=$(python3 -c "import sys; print(sys.version_info.minor)")

if [ "$PY_MAJOR" -lt 3 ] || [ "$PY_MINOR" -lt 10 ]; then
    echo "Python 3.10+ required. Found: $PY_VER"
    exit 1
fi
echo -e "[2/4] ${DIM}Checking Python...${RESET}           ${PY_VER} ✓"

# Install BeeQ
echo -e "[3/4] ${DIM}Installing BeeQ...${RESET}"
pip install beeq --quiet 2>/dev/null || pip3 install beeq --quiet
echo -e "      ${GREEN}✓${RESET}"

# Choose LLM provider
echo ""
echo -e "[4/4] ${BOLD}Connect your AI:${RESET}"
echo -e "      ${YELLOW}1.${RESET} Ollama ${DIM}(local — free, private, recommended)${RESET}"
echo -e "      ${YELLOW}2.${RESET} Claude ${DIM}(Anthropic API key required)${RESET}"
echo -e "      ${YELLOW}3.${RESET} OpenAI ${DIM}(API key required)${RESET}"
echo -e "      ${YELLOW}4.${RESET} Skip — configure later"
echo ""
read -rp "      > " CHOICE

case "$CHOICE" in
    1)
        if ! command -v ollama &>/dev/null; then
            echo -e "      ${DIM}Installing Ollama...${RESET}"
            curl -fsSL https://ollama.ai/install.sh | sh
        fi
        echo -e "      ${DIM}Pulling llama3 model (may take a few minutes)...${RESET}"
        ollama pull llama3 2>/dev/null || true
        beeq connect ollama
        ;;
    2)
        read -rp "      Anthropic API key (sk-ant-...): " API_KEY
        beeq connect claude --key "$API_KEY"
        ;;
    3)
        read -rp "      OpenAI API key (sk-...): " API_KEY
        beeq connect openai --key "$API_KEY"
        ;;
    4|*)
        echo -e "      ${DIM}Skipped. Run: beeq connect <claude|openai|ollama>${RESET}"
        ;;
esac

# Done
echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${RESET}"
echo -e "${BOLD}BeeQ is ready.${RESET}"
echo ""
echo -e "  Start your hive:  ${BOLD}beeq start${RESET}"
echo -e "  Give a mission:   ${BOLD}beeq mission \"your task here\"${RESET}"
echo -e "  Dashboard:        ${BOLD}http://localhost:7935${RESET}"
echo -e "  Verify actions:   ${BOLD}https://beeq.run/verify/<hash>${RESET}"
echo -e "  Docs:             ${BOLD}https://beeq.run/docs/${RESET}"
echo ""
