"""
BeeQ MCP Server — exposes the Hive as a MCP server.

Any MCP client (Claude Desktop, Cursor, Continue...) can plug into BeeQ.
BeeQ appears as a single "super-tool" with full orchestration behind it.

Tools exposed:
  - beeq_mission : give a mission to the hive
  - beeq_recall  : search sovereign memory
  - beeq_audit   : get audit chain status
  - beeq_workers : list active workers
"""

from mcp.server import Server
from mcp.server.models import InitializationOptions
from mcp.types import Tool, TextContent
import mcp.types as types
import json


def create_mcp_server(hive) -> Server:
    """Create a MCP server exposing the BeeQ hive."""
    server = Server("beeq")

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return [
            Tool(
                name="beeq_mission",
                description=(
                    "Give a mission to the BeeQ hive. "
                    "The Queen decomposes it, delegates to specialist workers, "
                    "and returns a consolidated result. Every action is signed and auditable."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "mission": {"type": "string", "description": "The mission in natural language"},
                        "context": {"type": "object", "description": "Optional context"},
                    },
                    "required": ["mission"],
                },
            ),
            Tool(
                name="beeq_recall",
                description="Search the hive's sovereign memory.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {"type": "string", "description": "What to search for"},
                        "top_k": {"type": "integer", "default": 5},
                    },
                    "required": ["query"],
                },
            ),
            Tool(
                name="beeq_audit",
                description="Get the hive audit chain status — actions signed, chain integrity.",
                inputSchema={"type": "object", "properties": {}},
            ),
            Tool(
                name="beeq_remember",
                description="Store something in sovereign memory.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "content": {"type": "string"},
                        "tags":    {"type": "array", "items": {"type": "string"}},
                    },
                    "required": ["content"],
                },
            ),
        ]

    @server.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[TextContent]:
        if name == "beeq_mission":
            mission = arguments["mission"]
            ctx     = arguments.get("context")
            result  = await hive.execute(mission, ctx)
            # Collect all worker outputs
            outputs = []
            for r in result.results:
                outputs.append(f"[{r.worker}] {r.output}")
            audit = hive.audit()
            text  = "\n\n".join(outputs) if outputs else "Mission completed."
            text += f"\n\n---\n✅ {audit['actions']} actions · Chain: {'INTACT' if audit['valid'] else 'ERROR'}"
            return [TextContent(type="text", text=text)]

        elif name == "beeq_recall":
            memories = await hive.recall(arguments["query"], arguments.get("top_k", 5))
            if not memories:
                return [TextContent(type="text", text="Nothing found in memory.")]
            text = "\n\n".join(f"[{m['id'][:8]}] {m['content']}" for m in memories)
            return [TextContent(type="text", text=text)]

        elif name == "beeq_audit":
            audit = hive.audit()
            text  = json.dumps(audit, indent=2)
            return [TextContent(type="text", text=text)]

        elif name == "beeq_remember":
            mem_id = await hive.remember(
                arguments["content"],
                arguments.get("tags", []),
            )
            return [TextContent(type="text", text=f"Stored. ID: {mem_id}")]

        return [TextContent(type="text", text=f"Unknown tool: {name}")]

    return server
