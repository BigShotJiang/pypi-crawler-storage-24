"""
BeeQ MCP Client — connects the hive to external MCP servers.

BeeQ can plug into any MCP server (Gmail, GitHub, Notion, Slack, filesystem...)
and make those tools available to the Queen and workers.

Usage:
    manager = MCPClientManager()
    await manager.connect("gmail", "https://gmail.mcp.example.com/sse")
    tools = await manager.list_all_tools()
"""

from dataclasses import dataclass, field
from typing import Any


@dataclass
class MCPConnection:
    name:    str
    url:     str
    tools:   list[dict] = field(default_factory=list)
    active:  bool       = False


class MCPClientManager:
    """
    Manages connections to external MCP servers.
    Gives the Queen access to the entire MCP ecosystem.
    """

    def __init__(self):
        self._connections: dict[str, MCPConnection] = {}

    async def connect(self, name: str, url: str) -> bool:
        """Connect to an external MCP server."""
        try:
            conn = MCPConnection(name=name, url=url)
            # TODO Phase 2: real MCP SSE/WebSocket connection
            # For now: register the connection
            conn.active = True
            self._connections[name] = conn
            return True
        except Exception:
            return False

    def disconnect(self, name: str):
        if name in self._connections:
            self._connections[name].active = False

    async def list_all_tools(self) -> list[dict]:
        """List all tools available from connected MCP servers."""
        tools = []
        for name, conn in self._connections.items():
            if conn.active:
                for tool in conn.tools:
                    tools.append({**tool, "_server": name})
        return tools

    async def call_tool(self, server: str, tool: str, args: dict) -> Any:
        """Call a tool on a connected MCP server."""
        conn = self._connections.get(server)
        if not conn or not conn.active:
            raise ValueError(f"MCP server not connected: {server}")
        # TODO Phase 2: real MCP call
        raise NotImplementedError(f"MCP call to {server}/{tool} — Phase 2")

    @property
    def connected(self) -> list[str]:
        return [n for n, c in self._connections.items() if c.active]

    def status(self) -> dict:
        return {
            "connected": self.connected,
            "total":     len(self._connections),
        }
