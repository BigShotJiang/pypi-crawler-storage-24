"""
AAP — Agent Accountability Protocol
Python SDK v0.1 — Reference Implementation

https://aap-protocol.dev
License: MIT
"""
from .identity import AAPIdentity, AAPKeyPair
from .authorization import AAPAuthorization, AuthorizationLevel
from .provenance import AAPProvenance
from .audit import AAPAuditChain, AAPAuditEntry
from .exceptions import (
    AAPError, AAPValidationError, AAPSignatureError,
    AAPPhysicalWorldViolation, AAPScopeError, AAPRevocationError
)

__version__ = "0.1.0"
__all__ = [
    "AAPIdentity", "AAPKeyPair",
    "AAPAuthorization", "AuthorizationLevel",
    "AAPProvenance",
    "AAPAuditChain", "AAPAuditEntry",
    "AAPError", "AAPValidationError", "AAPSignatureError",
    "AAPPhysicalWorldViolation", "AAPScopeError", "AAPRevocationError",
]
