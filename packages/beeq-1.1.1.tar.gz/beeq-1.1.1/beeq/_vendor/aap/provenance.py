"""AAP Provenance — immutable origin record for agent-produced artifacts."""
from __future__ import annotations

import hashlib, json, uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import ClassVar

from .exceptions import AAPValidationError
from .identity import _signable, _verify_signature, AAPKeyPair


def sha256_of(data: bytes | str) -> str:
    if isinstance(data, str):
        data = data.encode()
    return f"sha256:{hashlib.sha256(data).hexdigest()}"


@dataclass
class AAPProvenance:
    """
    Provenance record for an artifact produced by an agent.
    Proves: who produced it, from what instruction, under what authorization.
    Immutable once created.
    """
    AAP_VERSION: ClassVar[str] = "0.1"

    artifact_id: str         # uuid
    agent_id: str
    action: str              # verb:resource
    input_hash: str          # sha256:...
    output_hash: str         # sha256:...
    authorization_id: str    # uuid (session_id of AAPAuthorization)
    timestamp: datetime
    signature: str
    target: str | None = None
    parent_artifact_id: str | None = None

    def to_dict(self) -> dict:
        d = {
            "aap_version": self.AAP_VERSION,
            "artifact_id": self.artifact_id,
            "agent_id": self.agent_id,
            "action": self.action,
            "input_hash": self.input_hash,
            "output_hash": self.output_hash,
            "authorization_id": self.authorization_id,
            "timestamp": self.timestamp.isoformat(),
            "signature": self.signature,
        }
        if self.target:
            d["target"] = self.target
        if self.parent_artifact_id:
            d["parent_artifact_id"] = self.parent_artifact_id
        return d

    @classmethod
    def from_dict(cls, data: dict) -> "AAPProvenance":
        required = {"aap_version", "artifact_id", "agent_id", "action",
                    "input_hash", "output_hash", "authorization_id", "timestamp", "signature"}
        missing = required - set(data.keys())
        if missing:
            raise AAPValidationError(f"Missing required fields: {missing}")
        return cls(
            artifact_id=data["artifact_id"],
            agent_id=data["agent_id"],
            action=data["action"],
            input_hash=data["input_hash"],
            output_hash=data["output_hash"],
            authorization_id=data["authorization_id"],
            timestamp=datetime.fromisoformat(data["timestamp"]),
            signature=data["signature"],
            target=data.get("target"),
            parent_artifact_id=data.get("parent_artifact_id"),
        )

    def verify_signature(self, agent_public_key: str) -> None:
        _verify_signature(agent_public_key, _signable(self.to_dict()), self.signature)

    @classmethod
    def create(
        cls,
        agent_id: str,
        action: str,
        input_data: bytes,
        output_data: bytes,
        authorization_id: str,
        agent_keypair: AAPKeyPair,
        target: str | None = None,
        parent_artifact_id: str | None = None,
    ) -> "AAPProvenance":
        """Create and sign provenance for a produced artifact."""
        prov = cls(
            artifact_id=str(uuid.uuid4()),
            agent_id=agent_id,
            action=action,
            input_hash=sha256_of(input_data),
            output_hash=sha256_of(output_data),
            authorization_id=authorization_id,
            timestamp=datetime.now(timezone.utc),
            signature="",
            target=target,
            parent_artifact_id=parent_artifact_id,
        )
        doc = prov.to_dict()
        prov.signature = agent_keypair.sign(_signable(doc))
        return prov
