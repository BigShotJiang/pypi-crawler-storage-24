"""AAP Authorization — human-granted permission for an agent to act."""
from __future__ import annotations

import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import IntEnum
from typing import ClassVar

from .exceptions import AAPPhysicalWorldViolation, AAPValidationError, AAPRevocationError
from .identity import _signable, _verify_signature, AAPKeyPair


class AuthorizationLevel(IntEnum):
    OBSERVE    = 0  # Read-only. No side effects.
    SUGGEST    = 1  # Propose actions. Human executes.
    ASSISTED   = 2  # Agent executes. Human confirms each action.
    SUPERVISED = 3  # Agent executes. Human can intervene.
    AUTONOMOUS = 4  # Agent executes within scope. Full audit required.

    @property
    def name_str(self) -> str:
        return self.name.lower()


PHYSICAL_MAX_LEVEL = AuthorizationLevel.SUPERVISED


@dataclass
class AAPAuthorization:
    """
    Authorization token granting an agent permission to act.
    Signed by a human supervisor.

    PHYSICAL WORLD RULE: Level 4 (Autonomous) is FORBIDDEN for physical nodes.
    This is enforced at construction time. It is not configurable.
    """
    AAP_VERSION: ClassVar[str] = "0.1"

    agent_id: str
    level: AuthorizationLevel
    scope: list[str]
    granted_by: str          # did:key:z...
    granted_at: datetime
    signature: str
    physical: bool = False
    expires_at: datetime | None = None
    session_id: str = field(default_factory=lambda: str(uuid.uuid4()))
    _revoked: bool = field(default=False, init=False, repr=False)

    def __post_init__(self) -> None:
        self._enforce_physical_world_rule()

    def _enforce_physical_world_rule(self) -> None:
        """
        PHYSICAL WORLD RULE: Autonomous (Level 4) is forbidden for physical nodes.
        This rule cannot be bypassed, overridden, or configured away.
        """
        if self.physical and self.level > PHYSICAL_MAX_LEVEL:
            raise AAPPhysicalWorldViolation(self.agent_id)

    def revoke(self) -> None:
        """Revoke this authorization."""
        self._revoked = True

    @property
    def is_revoked(self) -> bool:
        return self._revoked

    def is_expired(self) -> bool:
        if not self.expires_at:
            return False
        return datetime.now(timezone.utc) > self.expires_at

    def is_valid(self) -> bool:
        return not self.is_revoked and not self.is_expired()

    def check(self) -> None:
        """Raise if this authorization is not valid."""
        if self.is_revoked:
            raise AAPRevocationError(f"Authorization '{self.session_id}' has been revoked")
        if self.is_expired():
            raise AAPRevocationError(f"Authorization '{self.session_id}' has expired")

    def to_dict(self) -> dict:
        d = {
            "aap_version": self.AAP_VERSION,
            "agent_id": self.agent_id,
            "level": int(self.level),
            "level_name": self.level.name_str,
            "scope": self.scope,
            "physical": self.physical,
            "granted_by": self.granted_by,
            "granted_at": self.granted_at.isoformat(),
            "session_id": self.session_id,
            "signature": self.signature,
        }
        if self.expires_at:
            d["expires_at"] = self.expires_at.isoformat()
        return d

    @classmethod
    def from_dict(cls, data: dict) -> "AAPAuthorization":
        required = {"aap_version", "agent_id", "level", "scope", "granted_by", "granted_at", "signature"}
        missing = required - set(data.keys())
        if missing:
            raise AAPValidationError(f"Missing required fields: {missing}")
        return cls(
            agent_id=data["agent_id"],
            level=AuthorizationLevel(data["level"]),
            scope=data["scope"],
            physical=data.get("physical", False),
            granted_by=data["granted_by"],
            granted_at=datetime.fromisoformat(data["granted_at"]),
            signature=data["signature"],
            session_id=data.get("session_id", str(uuid.uuid4())),
            expires_at=datetime.fromisoformat(data["expires_at"]) if data.get("expires_at") else None,
        )

    def verify_signature(self, supervisor_public_key: str) -> None:
        _verify_signature(supervisor_public_key, _signable(self.to_dict()), self.signature)

    @classmethod
    def create(
        cls,
        agent_id: str,
        level: AuthorizationLevel,
        scope: list[str],
        supervisor_keypair: AAPKeyPair,
        supervisor_did: str,
        physical: bool = False,
        expires_at: datetime | None = None,
    ) -> "AAPAuthorization":
        """Create and sign a new authorization. Raises AAPPhysicalWorldViolation if applicable."""
        now = datetime.now(timezone.utc)
        auth = cls(
            agent_id=agent_id,
            level=level,
            scope=scope,
            physical=physical,
            granted_by=supervisor_did,
            granted_at=now,
            signature="",
            expires_at=expires_at,
        )
        doc = auth.to_dict()
        auth.signature = supervisor_keypair.sign(_signable(doc))
        return auth
