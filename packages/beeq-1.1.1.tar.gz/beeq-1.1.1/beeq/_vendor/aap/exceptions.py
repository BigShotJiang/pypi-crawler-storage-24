"""AAP exception hierarchy."""


class AAPError(Exception):
    """Base class for all AAP errors."""
    code: str = "AAP-000"

    def __init__(self, message: str, field: str | None = None, detail: str | None = None):
        super().__init__(message)
        self.field = field
        self.detail = detail

    def to_dict(self) -> dict:
        d = {"code": self.code, "message": str(self)}
        if self.field:
            d["field"] = self.field
        if self.detail:
            d["detail"] = self.detail
        return d


class AAPValidationError(AAPError):
    """Schema validation failed."""
    code = "AAP-001"


class AAPSignatureError(AAPError):
    """Cryptographic signature is invalid."""
    code = "AAP-002"


class AAPPhysicalWorldViolation(AAPError):
    """Physical World Rule violation: Level 4 forbidden for physical nodes."""
    code = "AAP-003"

    def __init__(self, agent_id: str):
        super().__init__(
            f"Physical World Rule: Autonomous (Level 4) is forbidden for physical agent '{agent_id}'. "
            f"Maximum level for physical nodes is Supervised (Level 3). "
            f"This rule is not configurable.",
            field="level"
        )


class AAPScopeError(AAPError):
    """Action is outside the agent's authorized scope."""
    code = "AAP-004"


class AAPRevocationError(AAPError):
    """Identity or authorization has been revoked."""
    code = "AAP-005"


class AAPChainError(AAPError):
    """Audit chain integrity violation."""
    code = "AAP-006"
