"""
AAP Identity — cryptographic agent identity.
"""
from __future__ import annotations

import base64
import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import ClassVar

from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey, Ed25519PublicKey
)
from cryptography.hazmat.primitives.serialization import (
    Encoding, PublicFormat, PrivateFormat, NoEncryption
)
from cryptography.exceptions import InvalidSignature

from .exceptions import AAPValidationError, AAPSignatureError, AAPRevocationError

ID_PATTERN = re.compile(
    r"^aap://[a-z0-9\-\.]+/[a-z0-9\-]+/[a-z0-9\-\.]+@\d+\.\d+\.\d+$"
)
SCOPE_PATTERN = re.compile(r"^[a-z]+:[a-z0-9_\-\*]+$")


@dataclass
class AAPKeyPair:
    """Ed25519 keypair for signing AAP documents."""
    private_key: Ed25519PrivateKey
    public_key: Ed25519PublicKey

    @classmethod
    def generate(cls) -> "AAPKeyPair":
        """Generate a new Ed25519 keypair."""
        private = Ed25519PrivateKey.generate()
        return cls(private_key=private, public_key=private.public_key())

    @property
    def public_key_b64(self) -> str:
        """Public key in AAP wire format: 'ed25519:<base64>'"""
        raw = self.public_key.public_bytes(Encoding.Raw, PublicFormat.Raw)
        return f"ed25519:{base64.b64encode(raw).decode()}"

    def sign(self, data: bytes) -> str:
        """Sign data, return signature in AAP wire format."""
        sig = self.private_key.sign(data)
        return f"ed25519:{base64.b64encode(sig).decode()}"


def _verify_signature(public_key_str: str, data: bytes, signature_str: str) -> None:
    """Verify Ed25519 signature. Raises AAPSignatureError on failure."""
    try:
        pub_bytes = base64.b64decode(public_key_str.removeprefix("ed25519:"))
        sig_bytes = base64.b64decode(signature_str.removeprefix("ed25519:"))
        public_key = Ed25519PublicKey.from_public_bytes(pub_bytes)
        public_key.verify(sig_bytes, data)
    except (InvalidSignature, Exception) as e:
        raise AAPSignatureError(f"Signature verification failed: {e}")


def _signable(doc: dict) -> bytes:
    """Canonical serialization for signing: sorted keys, no 'signature' field."""
    d = {k: v for k, v in doc.items() if k != "signature"}
    return json.dumps(d, sort_keys=True, separators=(",", ":")).encode()


@dataclass
class AAPIdentity:
    """
    Cryptographic identity for an AI agent.
    Signed by a human supervisor (parent key).

    Address format: aap://org/type/name@semver
    """
    AAP_VERSION: ClassVar[str] = "0.1"

    id: str
    public_key: str          # ed25519:<base64>
    parent: str              # did:key:z...
    scope: list[str]
    issued_at: datetime
    signature: str           # ed25519:<base64>
    expires_at: datetime | None = None
    revoked: bool = False
    metadata: dict = field(default_factory=dict)

    def __post_init__(self) -> None:
        self._validate()

    def _validate(self) -> None:
        if not ID_PATTERN.match(self.id):
            raise AAPValidationError(
                f"Invalid identity id format: '{self.id}'. "
                f"Expected: aap://org/type/name@semver",
                field="id"
            )
        for s in self.scope:
            if not SCOPE_PATTERN.match(s):
                raise AAPValidationError(
                    f"Invalid scope item: '{s}'. Expected: verb:resource",
                    field="scope"
                )
        if not self.scope:
            raise AAPValidationError("scope must contain at least one item", field="scope")

    def to_dict(self) -> dict:
        d = {
            "aap_version": self.AAP_VERSION,
            "id": self.id,
            "public_key": self.public_key,
            "parent": self.parent,
            "scope": self.scope,
            "issued_at": self.issued_at.isoformat(),
            "signature": self.signature,
            "revoked": self.revoked,
        }
        if self.expires_at:
            d["expires_at"] = self.expires_at.isoformat()
        if self.metadata:
            d["metadata"] = self.metadata
        return d

    @classmethod
    def from_dict(cls, data: dict) -> "AAPIdentity":
        required = {"aap_version", "id", "public_key", "parent", "scope", "issued_at", "signature"}
        missing = required - set(data.keys())
        if missing:
            raise AAPValidationError(f"Missing required fields: {missing}")
        if data.get("aap_version") != "0.1":
            raise AAPValidationError(f"Unsupported aap_version: {data.get('aap_version')}")
        return cls(
            id=data["id"],
            public_key=data["public_key"],
            parent=data["parent"],
            scope=data["scope"],
            issued_at=datetime.fromisoformat(data["issued_at"]),
            signature=data["signature"],
            expires_at=datetime.fromisoformat(data["expires_at"]) if data.get("expires_at") else None,
            revoked=data.get("revoked", False),
            metadata=data.get("metadata", {}),
        )

    def verify_signature(self, parent_public_key: str) -> None:
        """Verify this identity was signed by the given parent public key."""
        if self.revoked:
            raise AAPRevocationError(f"Identity '{self.id}' has been revoked", field="revoked")
        _verify_signature(parent_public_key, _signable(self.to_dict()), self.signature)

    def is_expired(self) -> bool:
        if not self.expires_at:
            return False
        return datetime.now(timezone.utc) > self.expires_at

    def allows_action(self, action: str) -> bool:
        """Check if action is in this identity's scope."""
        verb, resource = action.split(":", 1) if ":" in action else (action, "")
        for s in self.scope:
            sv, sr = s.split(":", 1)
            if sv == verb and (sr == "*" or sr == resource):
                return True
        return False

    @classmethod
    def create(
        cls,
        id: str,
        scope: list[str],
        agent_keypair: AAPKeyPair,
        parent_keypair: AAPKeyPair,
        parent_did: str,
        expires_at: datetime | None = None,
        metadata: dict | None = None,
    ) -> "AAPIdentity":
        """
        Create and sign a new AAPIdentity.
        parent_keypair signs the identity (supervisor approval).
        agent_keypair provides the agent's public key.
        """
        now = datetime.now(timezone.utc)
        identity = cls(
            id=id,
            public_key=agent_keypair.public_key_b64,
            parent=parent_did,
            scope=scope,
            issued_at=now,
            signature="",  # placeholder
            expires_at=expires_at,
            metadata=metadata or {},
        )
        # Sign with parent key
        doc = identity.to_dict()
        identity.signature = parent_keypair.sign(_signable(doc))
        return identity
