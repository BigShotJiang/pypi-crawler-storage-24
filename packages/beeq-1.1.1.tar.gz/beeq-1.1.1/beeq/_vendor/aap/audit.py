"""AAP AuditChain — tamper-evident append-only log of all agent actions."""
from __future__ import annotations

import hashlib, json, uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import ClassVar

from .exceptions import AAPChainError, AAPValidationError
from .identity import _signable, _verify_signature, AAPKeyPair


def _hash_entry(entry_dict: dict) -> str:
    canonical = json.dumps(entry_dict, sort_keys=True, separators=(",", ":")).encode()
    return f"sha256:{hashlib.sha256(canonical).hexdigest()}"


@dataclass
class AAPAuditEntry:
    """A single tamper-evident entry in the audit chain."""
    AAP_VERSION: ClassVar[str] = "0.1"

    entry_id: str
    prev_hash: str       # sha256:... or "genesis"
    agent_id: str
    action: str
    result: str          # success | failure | blocked | revoked
    timestamp: datetime
    provenance_id: str
    signature: str
    authorization_level: int = 0
    physical: bool = False
    result_detail: str | None = None

    VALID_RESULTS: ClassVar[frozenset] = frozenset({"success", "failure", "blocked", "revoked"})

    def __post_init__(self) -> None:
        if self.result not in self.VALID_RESULTS:
            raise AAPValidationError(
                f"Invalid result: '{self.result}'. Must be one of: {self.VALID_RESULTS}",
                field="result"
            )

    def to_dict(self) -> dict:
        d = {
            "aap_version": self.AAP_VERSION,
            "entry_id": self.entry_id,
            "prev_hash": self.prev_hash,
            "agent_id": self.agent_id,
            "action": self.action,
            "result": self.result,
            "timestamp": self.timestamp.isoformat(),
            "provenance_id": self.provenance_id,
            "authorization_level": self.authorization_level,
            "physical": self.physical,
            "signature": self.signature,
        }
        if self.result_detail:
            d["result_detail"] = self.result_detail
        return d

    @classmethod
    def from_dict(cls, data: dict) -> "AAPAuditEntry":
        return cls(
            entry_id=data["entry_id"],
            prev_hash=data["prev_hash"],
            agent_id=data["agent_id"],
            action=data["action"],
            result=data["result"],
            timestamp=datetime.fromisoformat(data["timestamp"]),
            provenance_id=data["provenance_id"],
            signature=data["signature"],
            authorization_level=data.get("authorization_level", 0),
            physical=data.get("physical", False),
            result_detail=data.get("result_detail"),
        )

    def verify_signature(self, agent_public_key: str) -> None:
        _verify_signature(agent_public_key, _signable(self.to_dict()), self.signature)


class AAPAuditChain:
    """
    Tamper-evident audit chain.
    Append-only. Each entry hashes the previous.
    Tampering any entry breaks all subsequent hashes.
    """

    def __init__(self, storage_path: Path | None = None) -> None:
        self._entries: list[AAPAuditEntry] = []
        self._storage_path = storage_path
        if storage_path and storage_path.exists():
            self._load(storage_path)

    def append(
        self,
        agent_id: str,
        action: str,
        result: str,
        provenance_id: str,
        agent_keypair: AAPKeyPair,
        authorization_level: int = 0,
        physical: bool = False,
        result_detail: str | None = None,
    ) -> AAPAuditEntry:
        """Append a new entry. Signs it with the agent's key."""
        prev_hash = self._last_hash()
        entry = AAPAuditEntry(
            entry_id=str(uuid.uuid4()),
            prev_hash=prev_hash,
            agent_id=agent_id,
            action=action,
            result=result,
            timestamp=datetime.now(timezone.utc),
            provenance_id=provenance_id,
            signature="",
            authorization_level=authorization_level,
            physical=physical,
            result_detail=result_detail,
        )
        doc = entry.to_dict()
        entry.signature = agent_keypair.sign(_signable(doc))
        self._entries.append(entry)
        if self._storage_path:
            self._persist(entry)
        return entry

    def verify(self) -> tuple[bool, int, str | None]:
        """
        Verify chain integrity.
        Returns: (valid, entries_checked, broken_at_entry_id)
        """
        prev_hash = "genesis"
        for i, entry in enumerate(self._entries):
            expected_prev = prev_hash
            if entry.prev_hash != expected_prev:
                return False, i, entry.entry_id
            prev_hash = _hash_entry(entry.to_dict())
        return True, len(self._entries), None

    def _last_hash(self) -> str:
        if not self._entries:
            return "genesis"
        return _hash_entry(self._entries[-1].to_dict())

    def to_list(self) -> list[dict]:
        return [e.to_dict() for e in self._entries]

    def __len__(self) -> int:
        return len(self._entries)

    def _persist(self, entry: AAPAuditEntry) -> None:
        with open(self._storage_path, "a") as f:
            f.write(json.dumps(entry.to_dict()) + "\n")

    def _load(self, path: Path) -> None:
        for line in path.read_text().splitlines():
            if line.strip():
                self._entries.append(AAPAuditEntry.from_dict(json.loads(line)))
