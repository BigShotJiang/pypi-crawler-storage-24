# BeeQ vendored dependencies
# AAP (Agent Accountability Protocol) — MIT License
# Bundled to ensure zero external dependency at install time
