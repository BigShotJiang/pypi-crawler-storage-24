"""
BeeQ Core — The Hive.

Single entry point wiring together:
  - Governance (AAP) — identity, delegation, audit chain
  - Provider manager — LLM selection per task
  - Queen — orchestration engine
  - Workers — specialized agents
  - MCP — universal plug (server + client simultaneously)
"""

import json
import os
from pathlib import Path
from .governance.hive   import HiveGovernance
from .providers.manager import ProviderManager
from .providers.claude  import ClaudeProvider
from .providers.ollama  import OllamaProvider
from .providers.openai_p import OpenAIProvider
from .queen.queen       import Queen, Mission
from .workers.research  import ResearchWorker
from .workers.code      import CodeWorker
from .workers.writer    import WriterWorker
from .workers.ops       import OpsWorker
from .workers.memory    import MemoryWorker
from .workers.hardware  import HardwareWorker


CONFIG_PATH = Path.home() / ".beeq" / "config.json"
VERSION     = "1.0.0"


class BeeQ:
    """
    The Hive.

    Usage:
        hive = BeeQ()
        await hive.setup()
        result = await hive.execute("prepare my weekly report")

    Or with explicit provider:
        hive = BeeQ()
        await hive.setup(provider="claude")
        result = await hive.execute("search latest AI papers and summarize")
    """

    def __init__(self):
        self.governance = HiveGovernance()
        self.providers  = ProviderManager()
        self.queen: Queen | None = None
        self.memory: MemoryWorker | None = None

    async def setup(self, provider: str | None = None) -> None:
        """Wire up the hive from config + env."""
        config   = self._load_config()
        default  = provider or config.get("default_provider") or self._detect_provider()
        prov_cfg = config.get("providers", {})

        # ── Register providers ──────────────────────────────────────────
        # Claude
        claude_key = (prov_cfg.get("claude", {}).get("api_key")
                      or os.environ.get("ANTHROPIC_API_KEY"))
        if claude_key or default == "claude":
            self.providers.register(ClaudeProvider(
                api_key=claude_key,
                model=prov_cfg.get("claude", {}).get("model", "claude-sonnet-4-20250514"),
            ))

        # OpenAI
        openai_key = (prov_cfg.get("openai", {}).get("api_key")
                      or os.environ.get("OPENAI_API_KEY"))
        if openai_key or default == "openai":
            self.providers.register(OpenAIProvider(
                api_key=openai_key,
                model=prov_cfg.get("openai", {}).get("model", "gpt-4o-mini"),
            ))

        # Ollama — always register as local fallback
        ollama_cfg = prov_cfg.get("ollama", {})
        self.providers.register(OllamaProvider(
            host=ollama_cfg.get("host", "http://localhost:11434"),
            model=ollama_cfg.get("model", "llama3"),
        ), local=True)

        # ── Assemble workers ────────────────────────────────────────────
        worker_classes = [
            ResearchWorker,
            CodeWorker,
            WriterWorker,
            OpsWorker,
            MemoryWorker,
            HardwareWorker,
        ]

        self.queen = Queen(
            providers=self.providers,
            governance=self.governance,
        )

        for WC in worker_classes:
            w = WC(governance=self.governance, providers=self.providers)
            self.queen.add_worker(w)
            if isinstance(w, MemoryWorker):
                self.memory = w   # shortcut for direct memory access

    async def execute(self, mission: str, context: dict | None = None) -> Mission:
        """Give a mission to the hive. Returns consolidated Mission."""
        if not self.queen:
            await self.setup()
        # Auto-store the mission in memory
        if self.memory:
            self.memory.store(
                content=f"Mission: {mission}",
                tags=["mission", "history"],
                source="user",
            )
        return await self.queen.execute(mission, context)

    async def remember(self, content: str, tags: list[str] = ()) -> str:
        """Directly store something in sovereign memory."""
        if not self.memory:
            await self.setup()
        return self.memory.store(content, list(tags))

    async def recall(self, query: str, top_k: int = 5) -> list[dict]:
        """Directly search sovereign memory."""
        if not self.memory:
            await self.setup()
        return self.memory.search(query, top_k)

    def session_set(self, key: str, value: str):
        """Save session state (persists between restarts)."""
        if self.memory:
            self.memory.session_set(key, value)

    def session_get(self, key: str) -> str | None:
        """Get session state."""
        if self.memory:
            return self.memory.session_get(key)
        return None

    def audit(self) -> dict:
        """Return audit chain status."""
        valid, count, broken = self.governance.verify_chain()
        return {
            "valid":   valid,
            "actions": count,
            "broken_at": broken,
            "workers": list(self.governance.workers.keys()),
        }

    def _detect_provider(self) -> str:
        """Auto-detect available provider from environment."""
        if os.environ.get("ANTHROPIC_API_KEY"):  return "claude"
        if os.environ.get("OPENAI_API_KEY"):      return "openai"
        return "ollama"  # Zero-friction local fallback

    def _load_config(self) -> dict:
        if CONFIG_PATH.exists():
            try:
                return json.loads(CONFIG_PATH.read_text())
            except Exception:
                return {}
        return {}
