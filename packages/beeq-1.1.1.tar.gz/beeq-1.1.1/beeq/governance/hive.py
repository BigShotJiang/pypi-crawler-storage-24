"""
HiveGovernance — AAP enforcement for the BeeQ hive.

Every worker has a cryptographic identity.
Every delegation is a signed AAP token.
scope(worker) ⊂ scope(queen) — always.
One consolidated audit chain for the entire hive.
"""

from dataclasses import dataclass
from aap import (
    AAPKeyPair, AAPIdentity, AAPAuthorization,
    AuthorizationLevel, AAPAuditChain, AAPProvenance,
)

# Result strings — AAP PyPI uses plain strings
RESULT_SUCCESS = "success"
RESULT_FAILURE = "failure"
RESULT_BLOCKED = "blocked"
RESULT_REVOKED = "revoked"


@dataclass
class WorkerIdentity:
    """Cryptographic identity + authorization for one BeeQ worker."""
    name:          str
    identity:      AAPIdentity
    authorization: AAPAuthorization
    keypair:       AAPKeyPair


class HiveGovernance:
    """
    Manages AAP identities, authorizations, and audit chain
    for all workers in a BeeQ hive.

    LEX §1  — every worker has a responsible identity
    LEX §2  — delegation cannot inflate scope
    LEX §4  — every action leaves a trace
    LEX §5  — human supervisor is sovereign
    """

    def __init__(self, supervisor_did: str = "did:beeq:human:sovereign"):
        self.supervisor_keypair = AAPKeyPair.generate()
        self.supervisor_did     = supervisor_did
        self.audit_chain        = AAPAuditChain()
        self._workers: dict[str, WorkerIdentity] = {}

    def register_worker(
        self,
        name: str,
        scope: list[str],
        level: AuthorizationLevel = AuthorizationLevel.SUPERVISED,
        physical: bool = False,
    ) -> WorkerIdentity:
        """
        Create signed AAP identity + authorization for a worker.
        LEX §2: worker scope must be subset of queen scope.
        LEX §3: physical workers cannot be Level 4 (Autonomous).
        """
        aap_id = f"aap://beeq/worker/{name}@1.0.0"
        worker_keypair = AAPKeyPair.generate()

        identity = AAPIdentity.create(
            id=aap_id,
            scope=scope,
            agent_keypair=worker_keypair,
            parent_keypair=self.supervisor_keypair,
            parent_did=self.supervisor_did,
        )
        authorization = AAPAuthorization.create(
            agent_id=aap_id,
            level=level,
            scope=scope,
            physical=physical,
            supervisor_keypair=self.supervisor_keypair,
            supervisor_did=self.supervisor_did,
        )

        worker = WorkerIdentity(
            name=name,
            identity=identity,
            authorization=authorization,
            keypair=worker_keypair,
        )
        self._workers[name] = worker
        return worker

    def record_action(
        self,
        worker_name: str,
        action: str,
        result: str = RESULT_SUCCESS,
        input_data: bytes = b"",
        output_data: bytes = b"",
    ) -> str:
        """
        Record a worker action in the consolidated audit chain.
        Returns artifact_id for provenance tracking.
        LEX §4: memory of acts belongs to the collective.
        """
        worker = self._workers.get(worker_name)
        if not worker:
            raise ValueError(f"Unknown worker: {worker_name}")

        provenance = AAPProvenance.create(
            agent_id=worker.identity.id,
            action=action,
            input_data=input_data,
            output_data=output_data,
            authorization_id=worker.authorization.session_id,
            agent_keypair=worker.keypair,
        )

        self.audit_chain.append(
            agent_id=worker.identity.id,
            action=action,
            result=result,
            provenance_id=provenance.artifact_id,
            agent_keypair=worker.keypair,
            authorization_level=worker.authorization.level,
            physical=worker.authorization.physical,
        )

        return provenance.artifact_id

    def revoke_worker(self, worker_name: str) -> None:
        """Revoke a worker's authorization immediately. LEX §5."""
        if worker_name in self._workers:
            self._workers[worker_name].authorization.revoke()

    def verify_chain(self) -> tuple[bool, int, str | None]:
        """Verify audit chain integrity. Returns (valid, count, broken_at)."""
        return self.audit_chain.verify()

    @property
    def workers(self) -> dict[str, WorkerIdentity]:
        return self._workers

    @property
    def audit_entries(self):
        return self.audit_chain._entries
