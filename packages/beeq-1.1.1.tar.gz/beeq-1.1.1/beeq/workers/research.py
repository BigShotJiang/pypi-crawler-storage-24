"""
Worker-Research — web search, page scraping, document analysis.

Scope: read:web · search:* · read:docs

Search: DuckDuckGo (zero API key)
Scrape: httpx + BeautifulSoup (real page content)
Arxiv:  direct API for scientific papers
"""

import re
import asyncio
import ssl
import httpx
from pathlib import Path
from .base import BaseWorker, WorkerResult

# SSL context with certifi if available
def _ssl_ctx():
    try:
        import certifi
        ctx = ssl.create_default_context(cafile=certifi.where())
        return ctx
    except ImportError:
        return True  # default SSL

_SSL = _ssl_ctx()

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
        "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    )
}
MAX_PAGE_CHARS = 6000
MAX_RESULTS    = 5


class ResearchWorker(BaseWorker):
    name          = "research"
    description   = "Web search (DDG), page scraping, arxiv papers, local document reading"
    default_scope = ["read:web", "search:*", "read:docs"]

    async def execute(self, task: str, context: dict | None = None) -> WorkerResult:
        ctx = context or {}
        try:
            # Detect research type
            task_lower = task.lower()

            if "arxiv" in task_lower or "paper" in task_lower or "scientific" in task_lower:
                results = await self._arxiv_search(task)
            elif self._is_url(task):
                results = await self._scrape_page(task.strip())
            else:
                # Web search + scrape top result
                query   = self._extract_query(task)
                results = await self._web_search_with_content(query)

            # Synthesize with LLM
            if results:
                prompt = f"Task: {task}\n\nSources:\n{results}"
                resp = await self.providers.complete(
                    messages=[{"role": "user", "content": prompt}],
                    system=(
                        "You are a research specialist. Based on the sources provided, "
                        "give a clear, accurate, well-structured answer. "
                        "Cite facts. Be concise. If sources are insufficient, say so."
                    ),
                    max_tokens=2048,
                )
                output = resp.content
            else:
                # Direct LLM if no web results
                resp = await self.providers.complete(
                    messages=[{"role": "user", "content": task}],
                    system="You are a research specialist. Answer accurately and concisely.",
                    max_tokens=2048,
                )
                output = resp.content

            artifact = self._record("search:web", True,
                                   task.encode(), output[:200].encode())
            return WorkerResult(self.name, "search:web", True, output,
                               artifacts=[artifact])

        except Exception as e:
            self._record("search:web", False, task.encode(), str(e).encode())
            return WorkerResult(self.name, "search:web", False, "", error=str(e))

    # ── WEB SEARCH ────────────────────────────────────────────────────────

    async def _web_search_with_content(self, query: str) -> str:
        """DDG search + scrape top pages for full content."""
        snippets = await self._search_web(query)

        # Extract URLs from DDG results
        urls = await self._extract_urls_from_ddg(query)

        # Scrape top 2 pages for real content
        page_contents = []
        for url in urls[:2]:
            try:
                content = await self._scrape_page(url)
                if content and len(content) > 200:
                    page_contents.append(f"[{url}]\n{content[:2000]}")
            except Exception:
                pass

        combined = snippets
        if page_contents:
            combined += "\n\n## Full page content:\n\n" + "\n\n---\n\n".join(page_contents)

        return combined

    async def _search_web(self, query: str) -> str:
        """DuckDuckGo HTML search — zero API key."""
        try:
            async with httpx.AsyncClient(timeout=15, follow_redirects=True,
                                          headers=HEADERS, verify=_SSL) as client:
                r = await client.get(
                    "https://html.duckduckgo.com/html/",
                    params={"q": query}
                )
                if r.status_code != 200:
                    return ""

                text    = r.text
                results = []

                # Parse results
                title_blocks   = re.findall(
                    r'class="result__title"[^>]*>.*?<a[^>]+>(.*?)</a>',
                    text, re.DOTALL
                )
                snippet_blocks = re.findall(
                    r'class="result__snippet"[^>]*>(.*?)</a>',
                    text, re.DOTALL
                )

                for i, (title, snippet) in enumerate(
                    zip(title_blocks[:MAX_RESULTS], snippet_blocks[:MAX_RESULTS])
                ):
                    t = re.sub(r"<[^>]+>", "", title).strip()
                    s = re.sub(r"<[^>]+>", "", snippet).strip()
                    s = re.sub(r"\s+", " ", s)
                    if t and s:
                        results.append(f"{i+1}. **{t}**\n   {s}")

                return "\n\n".join(results) if results else ""
        except Exception:
            return ""

    async def _extract_urls_from_ddg(self, query: str) -> list[str]:
        """Extract URLs from DuckDuckGo results."""
        try:
            async with httpx.AsyncClient(timeout=15, follow_redirects=True,
                                          headers=HEADERS, verify=_SSL) as client:
                r = await client.get(
                    "https://html.duckduckgo.com/html/",
                    params={"q": query}
                )
                if r.status_code != 200:
                    return []

                # Extract result URLs (duckduckgo redirects)
                urls = re.findall(
                    r'uddg=([^&"]+)',
                    r.text
                )
                decoded = []
                for u in urls[:5]:
                    try:
                        from urllib.parse import unquote
                        url = unquote(u)
                        if url.startswith("http") and not any(
                            skip in url for skip in ["duckduckgo.com", "javascript:"]
                        ):
                            decoded.append(url)
                    except Exception:
                        pass
                return decoded[:3]
        except Exception:
            return []

    # ── PAGE SCRAPING ─────────────────────────────────────────────────────

    async def _scrape_page(self, url: str) -> str:
        """Fetch and extract clean text from a URL."""
        try:
            async with httpx.AsyncClient(timeout=15, follow_redirects=True,
                                          headers=HEADERS, verify=_SSL) as client:
                r = await client.get(url)
                if r.status_code != 200:
                    return ""

                html = r.text

                # Try BeautifulSoup if available
                try:
                    from bs4 import BeautifulSoup
                    soup = BeautifulSoup(html, "html.parser")
                    # Remove noise
                    for tag in soup(["script", "style", "nav", "header",
                                     "footer", "aside", "form", "iframe"]):
                        tag.decompose()
                    # Get main content
                    main = (soup.find("main") or
                            soup.find("article") or
                            soup.find("div", {"id": re.compile("content|main|article", re.I)}) or
                            soup.find("body"))
                    if main:
                        text = main.get_text(separator="\n", strip=True)
                    else:
                        text = soup.get_text(separator="\n", strip=True)
                except ImportError:
                    # Fallback: regex strip HTML
                    text = re.sub(r"<script[^>]*>.*?</script>", "", html, flags=re.DOTALL)
                    text = re.sub(r"<style[^>]*>.*?</style>", "", text, flags=re.DOTALL)
                    text = re.sub(r"<[^>]+>", " ", text)
                    text = re.sub(r"\s+", " ", text)

                # Clean up
                text = re.sub(r"\n{3,}", "\n\n", text.strip())
                return text[:MAX_PAGE_CHARS]

        except Exception as e:
            return f"[Scrape error: {e}]"

    # ── ARXIV ─────────────────────────────────────────────────────────────

    async def _arxiv_search(self, query: str) -> str:
        """Search arxiv for scientific papers."""
        search_terms = self._extract_query(query)
        try:
            async with httpx.AsyncClient(timeout=20, follow_redirects=True, verify=_SSL) as client:
                r = await client.get(
                    "https://export.arxiv.org/api/query",
                    params={
                        "search_query": f"all:{search_terms}",
                        "start": 0,
                        "max_results": 5,
                        "sortBy": "relevance",
                    }
                )
                if r.status_code != 200:
                    return ""

                # Parse Atom XML
                entries = re.findall(
                    r"<entry>(.*?)</entry>", r.text, re.DOTALL
                )
                results = []
                for entry in entries[:5]:
                    title   = re.search(r"<title>(.*?)</title>", entry)
                    summary = re.search(r"<summary>(.*?)</summary>", entry, re.DOTALL)
                    authors = re.findall(r"<name>(.*?)</name>", entry)
                    link    = re.search(r'href="(https://arxiv[^"]+)"', entry)

                    if title and summary:
                        t = re.sub(r"\s+", " ", title.group(1)).strip()
                        s = re.sub(r"\s+", " ", summary.group(1)).strip()[:500]
                        auth = ", ".join(authors[:3])
                        url  = link.group(1) if link else ""
                        results.append(f"**{t}** — {auth}\n{s}\n{url}")

                return "\n\n---\n\n".join(results) if results else ""
        except Exception:
            return ""

    # ── LOCAL FILES ───────────────────────────────────────────────────────

    async def read_file(self, path: str) -> str:
        """Read a local file (ARCHE paths supported)."""
        try:
            content = Path(path).read_text(encoding="utf-8", errors="ignore")
            return content[:MAX_PAGE_CHARS]
        except Exception as e:
            return f"[Cannot read {path}: {e}]"

    # ── HELPERS ───────────────────────────────────────────────────────────

    def _extract_query(self, task: str) -> str:
        """Extract clean search query from task description."""
        # Remove instruction words
        task = re.sub(
            r"(search|find|look up|research|google|cherche|trouve|qu'est-ce que)[:\s]+",
            "", task, flags=re.I
        ).strip()
        # Take first 10 words
        words = task.split()[:10]
        return " ".join(words)

    def _is_url(self, text: str) -> bool:
        return bool(re.match(r"https?://", text.strip()))
