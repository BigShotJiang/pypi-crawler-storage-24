"""
Worker-Code — file system, code execution, git operations.

Scope: read:files · write:files · exec:code

LEX §9: backup before every write.
LEX §8: minimal footprint — only declared roots.
Real execution: subprocess sandbox, not LLM simulation.
"""

import os
import re
import subprocess
import shutil
import tempfile
from pathlib import Path
from datetime import datetime
from .base import BaseWorker, WorkerResult


BACKUP_DIR   = Path.home() / ".beeq" / "backups"
ALLOWED_ROOT = [
    Path.home(),
    Path("/tmp"),
    Path("/mnt/data"),
    Path("/var/www"),
]
EXEC_TIMEOUT = 10   # seconds — LEX §8 proportional
MAX_OUTPUT   = 4000 # chars


class CodeWorker(BaseWorker):
    name          = "code"
    description   = "File read/write with backup, sandboxed Python/bash execution, git operations"
    default_scope = ["read:files", "write:files", "exec:code"]

    async def execute(self, task: str, context: dict | None = None) -> WorkerResult:
        ctx    = context or {}
        action = ctx.get("action", "auto")
        target = ctx.get("target", "")

        try:
            # Direct action from context
            if action == "read" and target:
                return await self._read_file(target, task)
            if action == "exec" and target:
                return await self._exec_direct(target)
            if action == "write" and target:
                content = ctx.get("content", "")
                return await self._write_file(target, content, task)
            if action == "git" and target:
                return await self._git_op(target, task)

            # Auto-detect from task text
            detected = self._detect_action(task)
            if detected == "read":
                path = self._extract_path(task)
                return await self._read_file(path, task) if path else await self._llm_task(task, ctx)
            if detected == "exec":
                code = self._extract_code(task)
                return await self._exec_direct(code) if code else await self._llm_task(task, ctx)
            if detected == "git":
                return await self._git_op(self._extract_path(task) or ".", task)

            return await self._llm_task(task, ctx)

        except Exception as e:
            self._record("exec:code", success=False,
                        input_data=task.encode(), output_data=str(e).encode())
            return WorkerResult(
                worker=self.name, action="exec:code",
                success=False, output="", error=str(e),
            )

    # ── FILE READ ────────────────────────────────────────────────────────

    async def _read_file(self, path: str, task: str) -> WorkerResult:
        p = Path(path).expanduser().resolve()
        if not p.exists():
            return WorkerResult(self.name, "read:files", False, "",
                                error=f"File not found: {path}")
        try:
            content = p.read_text(encoding="utf-8", errors="ignore")
            if len(content) > 8000:
                content = content[:8000] + f"\n... [truncated, total {len(content)} chars]"
            artifact = self._record("read:files", True,
                                   path.encode(), content[:500].encode())
            return WorkerResult(self.name, "read:files", True, content, artifacts=[artifact])
        except Exception as e:
            return WorkerResult(self.name, "read:files", False, "", error=str(e))

    # ── FILE WRITE ───────────────────────────────────────────────────────

    async def _write_file(self, path: str, content: str, task: str) -> WorkerResult:
        p = Path(path).expanduser().resolve()
        # LEX §9 — backup before write
        if p.exists():
            BACKUP_DIR.mkdir(parents=True, exist_ok=True)
            ts  = datetime.now().strftime("%Y%m%d_%H%M%S")
            bak = BACKUP_DIR / f"{p.name}.{ts}.bak"
            shutil.copy2(p, bak)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(content, encoding="utf-8")
        artifact = self._record("write:files", True,
                               path.encode(), content[:200].encode())
        return WorkerResult(self.name, "write:files", True,
                           f"Written: {path} ({len(content)} chars)",
                           artifacts=[artifact])

    # ── CODE EXECUTION (real sandbox) ────────────────────────────────────

    async def _exec_direct(self, code: str) -> WorkerResult:
        """
        Execute Python or bash code in a real subprocess sandbox.
        No LLM intermediary — direct execution.
        """
        # Detect language
        lang = self._detect_lang(code)

        with tempfile.TemporaryDirectory(prefix="beeq_exec_") as tmpdir:
            if lang == "python":
                # Write to temp file and execute
                script = Path(tmpdir) / "script.py"
                script.write_text(code, encoding="utf-8")
                result = subprocess.run(
                    ["python3", str(script)],
                    capture_output=True, text=True,
                    timeout=EXEC_TIMEOUT,
                    cwd=tmpdir,
                    env={**os.environ, "HOME": tmpdir},  # isolate home
                )
            else:
                # Bash
                script = Path(tmpdir) / "script.sh"
                script.write_text(code, encoding="utf-8")
                result = subprocess.run(
                    ["bash", str(script)],
                    capture_output=True, text=True,
                    timeout=EXEC_TIMEOUT,
                    cwd=tmpdir,
                )

        stdout = (result.stdout or "")[:MAX_OUTPUT]
        stderr = (result.stderr or "")[:1000]
        success = result.returncode == 0

        output = stdout
        if stderr and not success:
            output = f"STDOUT:\n{stdout}\n\nSTDERR:\n{stderr}"
        elif stderr:
            output = stdout + (f"\n[stderr]: {stderr}" if stderr.strip() else "")

        artifact = self._record(
            "exec:code", success,
            code[:200].encode(), output[:200].encode()
        )
        return WorkerResult(
            self.name, "exec:code", success, output,
            error=stderr if not success else None,
            artifacts=[artifact],
        )

    # ── GIT ──────────────────────────────────────────────────────────────

    async def _git_op(self, path: str, task: str) -> WorkerResult:
        """Basic git operations: status, log, diff, branch."""
        p = Path(path).expanduser().resolve()
        if not (p / ".git").exists():
            # Try to find git root
            for parent in p.parents:
                if (parent / ".git").exists():
                    p = parent
                    break

        task_lower = task.lower()
        if "log" in task_lower:
            cmd = ["git", "log", "--oneline", "-20"]
        elif "diff" in task_lower:
            cmd = ["git", "diff", "--stat"]
        elif "branch" in task_lower:
            cmd = ["git", "branch", "-a"]
        elif "status" in task_lower or True:
            cmd = ["git", "status", "--short"]

        result = subprocess.run(
            cmd, capture_output=True, text=True,
            timeout=10, cwd=str(p)
        )
        output = result.stdout or result.stderr or "No output"
        artifact = self._record("read:files", result.returncode == 0,
                               path.encode(), output[:200].encode())
        return WorkerResult(
            self.name, "read:files", result.returncode == 0, output,
            artifacts=[artifact]
        )

    # ── LLM FALLBACK ─────────────────────────────────────────────────────

    async def _llm_task(self, task: str, ctx: dict) -> WorkerResult:
        """For tasks that need LLM reasoning about code (design, explain, refactor)."""
        # Read relevant files if mentioned
        paths = re.findall(r"(?:file|fichier|path)[\s:]+([/~\w\-.]+)", task, re.I)
        file_context = ""
        for path in paths[:3]:
            try:
                p = Path(path).expanduser()
                if p.exists():
                    content = p.read_text(encoding="utf-8", errors="ignore")[:3000]
                    file_context += f"\n\n[{path}]:\n{content}"
            except Exception:
                pass

        prompt = task + file_context
        resp = await self.providers.complete(
            messages=[{"role": "user", "content": prompt}],
            system=(
                "You are a code specialist. Analyze, explain, or design code. "
                "For execution requests, provide the exact code to run. "
                "Be precise and concise."
            ),
            max_tokens=2048,
        )
        artifact = self._record("exec:code", True,
                               task.encode(), resp.content[:200].encode())
        return WorkerResult(self.name, "exec:code", True, resp.content,
                           artifacts=[artifact])

    # ── DETECTION ────────────────────────────────────────────────────────

    def _detect_action(self, task: str) -> str:
        t = task.lower()
        if any(k in t for k in ["read", "open", "cat", "show file", "content of", "lire"]):
            return "read"
        if any(k in t for k in ["execute", "run", "exec", "python", "bash", "script", "print(", "import "]):
            return "exec"
        if any(k in t for k in ["git", "commit", "branch", "diff", "status"]):
            return "git"
        return "llm"

    def _extract_path(self, task: str) -> str | None:
        # Match file paths
        m = re.search(r"([~/][\w/\-\.]+)", task)
        return m.group(1) if m else None

    def _extract_code(self, task: str) -> str | None:
        """
        Extract executable code from a task string.
        Priority:
          1. Markdown code block
          2. Inline backtick block
          3. Text after last ":" where remaining is pure code
          4. Pure code text (>60% code lines)
          5. First code-starting line onward
        """
        # 1. Markdown fence — highest priority
        m = re.search(r"```(?:python|bash|sh|py)?\n(.*?)```", task, re.DOTALL)
        if m:
            return m.group(1).strip()

        # 2. Backtick block with newlines
        m = re.search(r"`([^`]+)`", task)
        if m and "\n" in m.group(1):
            return m.group(1).strip()

        stripped = task.strip()

        # 3. "NL text: code" — extract after last colon if rest is code
        if ":" in stripped:
            # Try splitting on last colon in first line
            first_line = stripped.split("\n")[0]
            if ":" in first_line:
                after_colon = stripped[stripped.index(":") + 1:].strip()
                if after_colon and self._is_code(after_colon):
                    return after_colon

        # 4. Pure code text (>60% code lines)
        if self._is_code(stripped):
            return stripped

        # 5. Find first code-starting line
        lines = stripped.split("\n")
        CODE_STARTERS = ["import ", "from ", "print(", "def ", "class ",
                         "for ", "while ", "return ", "#!/", "if __"]
        for i, line in enumerate(lines):
            sl = line.strip()
            if any(sl.startswith(kw) for kw in CODE_STARTERS):
                return "\n".join(lines[i:]).strip()
            # Assignment: x = ... or x=...
            if re.match(r"^[a-zA-Z_]\w*\s*=\s*\S", sl):
                return "\n".join(lines[i:]).strip()

        return None

    def _is_code(self, text: str) -> bool:
        """True if text looks like code (>60% of non-empty lines are code-like)."""
        lines = [l for l in text.split("\n") if l.strip()]
        if not lines:
            return False
        CODE_KW = ["print(", "import ", "def ", "class ", "for ", "if ",
                   "while ", "return ", "from ", "#", "=", "(", ")"]
        code_count = sum(1 for l in lines if any(kw in l for kw in CODE_KW))
        # Additional check: no long natural language sentences
        has_nl_sentences = any(
            len(l.split()) > 8 and not any(l.strip().startswith(kw)
            for kw in ["#", "import", "from", "def", "class"])
            for l in lines
        )
        return code_count / len(lines) > 0.6 and not has_nl_sentences

    def _detect_lang(self, code: str) -> str:
        if any(kw in code for kw in ["import ", "def ", "print(", "class ", "elif"]):
            return "python"
        return "bash"
