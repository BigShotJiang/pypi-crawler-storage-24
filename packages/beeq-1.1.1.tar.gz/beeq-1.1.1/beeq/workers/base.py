"""
BaseWorker — base class for all BeeQ workers.

Each worker has:
  - A name and specialization
  - An AAP identity (signed by human supervisor)
  - An authorized scope it cannot exceed
  - A connection to the provider manager

LEX §6: freedom is real within the authorized scope.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from ..providers.manager import ProviderManager
    from ..governance.hive import HiveGovernance, WorkerIdentity


@dataclass
class WorkerResult:
    worker:    str
    action:    str
    success:   bool
    output:    str
    artifacts: list[str] = field(default_factory=list)
    error:     str | None = None


class BaseWorker(ABC):
    """
    Base class for all BeeQ workers.

    Workers are specialized agents that execute specific types of tasks.
    Each worker operates within its authorized scope — it cannot exceed
    what the Queen has delegated. This is enforced by AAP.
    """

    name:        str = "base"
    description: str = "Base worker"
    default_scope: list[str] = []

    def __init__(
        self,
        governance: "HiveGovernance",
        providers:  "ProviderManager",
    ):
        self.governance = governance
        self.providers  = providers
        self._identity: "WorkerIdentity | None" = None

    def register(self) -> None:
        """Register this worker with the governance layer (AAP identity)."""
        self._identity = self.governance.register_worker(
            name=self.name,
            scope=self.default_scope,
        )

    @abstractmethod
    async def execute(self, task: str, context: dict | None = None) -> WorkerResult:
        """Execute a task. Returns WorkerResult."""
        ...

    @property
    def identity(self):
        return self._identity

    def _record(self, action: str, success: bool,
                input_data: bytes = b"", output_data: bytes = b"") -> str:
        """Record action in the consolidated audit chain."""
        
        result = "success" if success else "failure"
        return self.governance.record_action(
            worker_name=self.name,
            action=action,
            result=result,
            input_data=input_data,
            output_data=output_data,
        )
