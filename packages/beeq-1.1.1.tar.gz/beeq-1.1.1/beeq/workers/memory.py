"""
Worker-Memory — Sovereign persistent memory.

Scope: read:memory · write:memory · index:knowledge

Search: BM25 + synonym expansion + fuzzy matching
        No GPU. No cloud. Pure Python.
        Local-first. Sovereign. Cryptographic integrity.
"""

import json
import math
import re
import sqlite3
import hashlib
from pathlib import Path
from datetime import datetime
from collections import Counter, defaultdict
from .base import BaseWorker, WorkerResult

MEMORY_DIR = Path.home() / ".beeq" / "memory"
MEMORY_DB  = MEMORY_DIR / "memory.db"

# Synonym map for Z-domain terms
SYNONYMS = {
    "z":         ["z-equation", "z_measure", "information", "signal"],
    "equation":  ["formula", "math", "measure", "theory"],
    "beeq":      ["hive", "queen", "workers", "ruche"],
    "queen":     ["reine", "orchestrator", "hive"],
    "worker":    ["ouvriere", "agent", "specialist"],
    "memory":    ["memoire", "souvenir", "recall", "remember"],
    "mission":   ["task", "tache", "goal", "objectif"],
    "research":  ["search", "find", "web", "query"],
    "code":      ["exec", "python", "script", "execute"],
    "lex":       ["law", "loi", "rule", "governance"],
    "phy":       ["physical", "physique", "hardware", "sensor"],
    "aap":       ["accountability", "audit", "identity", "signature"],
    "arche":     ["server", "serveur", "infrastructure"],
    "labo":      ["laboratory", "research", "experiment"],
    "amsra":     ["eden", "morocco", "maroc", "desert"],
}


class MemoryWorker(BaseWorker):
    name          = "memory"
    description   = "Persistent sovereign memory — store, recall, session state across all sessions"
    default_scope = ["read:memory", "write:memory", "index:knowledge"]

    def __init__(self, governance, providers):
        super().__init__(governance, providers)
        MEMORY_DIR.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _init_db(self):
        con = sqlite3.connect(MEMORY_DB)
        con.executescript("""
            CREATE TABLE IF NOT EXISTS memories (
                id        TEXT PRIMARY KEY,
                content   TEXT NOT NULL,
                tags      TEXT DEFAULT '',
                source    TEXT DEFAULT '',
                created   TEXT NOT NULL,
                accessed  TEXT NOT NULL,
                access_n  INTEGER DEFAULT 0
            );
            CREATE INDEX IF NOT EXISTS idx_content ON memories(content);
            CREATE TABLE IF NOT EXISTS session_state (
                key   TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                ts    TEXT NOT NULL
            );
        """)
        con.commit()
        con.close()

    # ── EXECUTE ──────────────────────────────────────────────────────────

    async def execute(self, task: str, context: dict | None = None) -> WorkerResult:
        ctx    = context or {}
        action = ctx.get("action", "auto")

        try:
            if action == "store" or self._is_store(task):
                content = ctx.get("content", task)
                tags    = ctx.get("tags", [])
                mem_id  = self.store(content, tags, source=ctx.get("source",""))
                output  = f"Stored. ID: {mem_id}"

            elif action == "recall" or self._is_recall(task):
                query   = ctx.get("query", task)
                results = self.search(query, top_k=5)
                if results:
                    output = "Memory recall:\n\n" + "\n\n---\n\n".join(
                        f"[{r['id'][:8]}] {r['content']}" for r in results
                    )
                else:
                    output = f"Nothing found for: {query}"

            elif action == "session_get":
                key   = ctx.get("key", "")
                value = self.session_get(key)
                output = value or f"[No session state: {key}]"

            elif action == "session_set":
                self.session_set(ctx.get("key",""), ctx.get("value",""))
                output = f"Session saved: {ctx.get('key','')}"

            elif action == "summary":
                output = self.summary()

            elif action == "export":
                path = ctx.get("path", str(MEMORY_DIR / "export.json"))
                output = self.export(path)

            else:
                # Auto: store if looks like fact, else search
                if len(task) > 30 and not self._is_recall(task):
                    mem_id = self.store(task, source="auto")
                    results = self.search(task, top_k=3)
                    output = f"Stored (ID: {mem_id[:8]})"
                    if results:
                        output += "\n\nRelated memories:\n" + "\n".join(
                            f"- {r['content'][:100]}" for r in results
                        )
                else:
                    results = self.search(task, top_k=5)
                    if results:
                        output = "\n".join(f"- {r['content'][:120]}" for r in results)
                    else:
                        # Ask LLM with memory context
                        ctx_items = self._recent(5)
                        ctx_text  = "\n".join(f"- {c}" for c in ctx_items)
                        resp = await self.providers.complete(
                            messages=[{"role":"user","content": task}],
                            system=(
                                "You are the memory worker. Recent stored memories:\n" + ctx_text +
                                "\n\nAnswer using memory when relevant. Be concise."
                            ),
                            max_tokens=512,
                        )
                        output = resp.content

            artifact = self._record("read:memory", True,
                                   task.encode(), output[:200].encode())
            return WorkerResult(self.name, "read:memory", True, output,
                               artifacts=[artifact])

        except Exception as e:
            self._record("read:memory", False, task.encode(), str(e).encode())
            return WorkerResult(self.name, "read:memory", False, "", error=str(e))

    # ── STORE ────────────────────────────────────────────────────────────

    def store(self, content: str, tags: list = (), source: str = "") -> str:
        """Store a memory. Returns its ID."""
        mem_id   = hashlib.sha256(
            f"{content}{datetime.utcnow().isoformat()}".encode()
        ).hexdigest()[:16]
        now      = datetime.utcnow().isoformat()
        tags_str = ",".join(tags) if tags else ""
        con      = sqlite3.connect(MEMORY_DB)
        con.execute("INSERT OR REPLACE INTO memories VALUES (?,?,?,?,?,?,?)",
                    (mem_id, content, tags_str, source, now, now, 0))
        con.commit()
        con.close()
        return mem_id

    # ── SEARCH (BM25 + synonym expansion) ────────────────────────────────

    def search(self, query: str, top_k: int = 5) -> list[dict]:
        """
        BM25 search with synonym expansion.
        k1=1.5, b=0.75 (standard BM25 params).
        Falls back to substring match if BM25 returns nothing.
        """
        con  = sqlite3.connect(MEMORY_DB)
        rows = con.execute("SELECT id, content, tags, created FROM memories").fetchall()
        con.close()
        if not rows:
            return []

        docs = [(r[0], r[1] + " " + r[2], r[1], r[3]) for r in rows]

        # Expand query with synonyms
        q_tokens = self._expand_tokens(self._tokenize(query))
        if not q_tokens:
            return []

        # BM25 parameters
        k1 = 1.5
        b  = 0.75
        N  = len(docs)

        # Build corpus stats
        doc_tokens  = []
        doc_lengths = []
        df: Counter = Counter()

        for _, full_text, _, _ in docs:
            tokens = self._expand_tokens(self._tokenize(full_text))
            doc_tokens.append(Counter(tokens))
            doc_lengths.append(len(tokens))
            df.update(set(tokens))

        avgdl = sum(doc_lengths) / max(N, 1)

        # Score each document
        scores = []
        for i, (mem_id, _, content, created) in enumerate(docs):
            score = 0.0
            dl    = doc_lengths[i]
            tf    = doc_tokens[i]

            for token in q_tokens:
                if token not in tf:
                    continue
                f   = tf[token]
                idf = math.log((N - df[token] + 0.5) / (df[token] + 0.5) + 1)
                tfn = (f * (k1 + 1)) / (f + k1 * (1 - b + b * dl / max(avgdl, 1)))
                score += idf * tfn

            if score > 0:
                scores.append((score, mem_id, content, created))

        scores.sort(reverse=True)

        # Fallback: substring match if BM25 empty
        if not scores:
            q_lower = query.lower()
            for mem_id, _, content, created in docs:
                if q_lower in content.lower():
                    scores.append((0.1, mem_id, content, created))

        # Update access stats
        results = []
        now     = datetime.utcnow().isoformat()
        if scores:
            con = sqlite3.connect(MEMORY_DB)
            for score, mem_id, content, created in scores[:top_k]:
                con.execute("UPDATE memories SET accessed=?, access_n=access_n+1 WHERE id=?",
                           (now, mem_id))
                results.append({"id": mem_id, "content": content,
                               "created": created, "score": round(score, 3)})
            con.commit()
            con.close()

        return results

    # ── SESSION STATE ─────────────────────────────────────────────────────

    def session_get(self, key: str) -> str | None:
        con = sqlite3.connect(MEMORY_DB)
        row = con.execute("SELECT value FROM session_state WHERE key=?", (key,)).fetchone()
        con.close()
        return row[0] if row else None

    def session_set(self, key: str, value: str):
        now = datetime.utcnow().isoformat()
        con = sqlite3.connect(MEMORY_DB)
        con.execute("INSERT OR REPLACE INTO session_state VALUES (?,?,?)", (key, value, now))
        con.commit()
        con.close()

    def session_all(self) -> dict:
        con  = sqlite3.connect(MEMORY_DB)
        rows = con.execute("SELECT key, value FROM session_state").fetchall()
        con.close()
        return {r[0]: r[1] for r in rows}

    def summary(self) -> str:
        con        = sqlite3.connect(MEMORY_DB)
        mem_count  = con.execute("SELECT COUNT(*) FROM memories").fetchone()[0]
        sess_count = con.execute("SELECT COUNT(*) FROM session_state").fetchone()[0]
        top        = con.execute(
            "SELECT content FROM memories ORDER BY access_n DESC, accessed DESC LIMIT 5"
        ).fetchall()
        con.close()
        lines = [f"Memory: {mem_count} items · {sess_count} session keys", ""]
        for row in top:
            lines.append("  · " + row[0][:90] + ("..." if len(row[0]) > 90 else ""))
        return "\n".join(lines)

    def export(self, path: str) -> str:
        con  = sqlite3.connect(MEMORY_DB)
        mems = con.execute("SELECT * FROM memories").fetchall()
        sess = con.execute("SELECT * FROM session_state").fetchall()
        con.close()
        data = {
            "version":  "1.1",
            "exported": datetime.utcnow().isoformat(),
            "memories": [{"id":r[0],"content":r[1],"tags":r[2],"source":r[3],
                          "created":r[4],"accessed":r[5],"access_n":r[6]} for r in mems],
            "session":  [{"key":r[0],"value":r[1],"ts":r[2]} for r in sess],
        }
        Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False))
        return path

    # ── PRIVATE ───────────────────────────────────────────────────────────

    def _tokenize(self, text: str) -> list[str]:
        # Keep unicode (Arabic, Chinese, etc.) + latin
        return re.findall(r"[a-zA-ZÀ-ÿ\u0600-\u06FF\u4e00-\u9fff\u3040-\u309f]{2,}", text.lower())

    def _expand_tokens(self, tokens: list[str]) -> list[str]:
        """Expand with synonyms for better recall."""
        expanded = list(tokens)
        for token in tokens:
            if token in SYNONYMS:
                expanded.extend(SYNONYMS[token])
            # Reverse lookup
            for key, syns in SYNONYMS.items():
                if token in syns:
                    expanded.append(key)
        return list(set(expanded))

    def _recent(self, n: int) -> list[str]:
        con  = sqlite3.connect(MEMORY_DB)
        rows = con.execute(
            "SELECT content FROM memories ORDER BY accessed DESC LIMIT ?", (n,)
        ).fetchall()
        con.close()
        return [r[0] for r in rows]

    def _is_store(self, task: str) -> bool:
        kw = ["remember", "store", "save", "note", "mémorise", "enregistre",
              "souviens-toi", "garde", "keep in mind"]
        return any(k in task.lower() for k in kw)

    def _is_recall(self, task: str) -> bool:
        kw = ["recall", "what do you know", "search memory", "find in memory",
              "rappelle", "souviens", "mémorisé", "qu'est-ce que tu sais",
              "do you remember", "tu te souviens"]
        return any(k in task.lower() for k in kw)
