"""
Worker-Ops — infrastructure monitoring, service management, ARCHE operations.

Scope: read:system · monitor:services · exec:ops

Actions réelles :
  - Commandes système sécurisées sur ARCHE
  - Monitoring disk, RAM, CPU, services
  - Logs et alertes
  - Brief matinal automatique
"""

import subprocess
import platform
from pathlib import Path
from .base import BaseWorker, WorkerResult


# Commandes autorisées — LEX §6 · liberté dans le scope
SAFE_COMMANDS = [
    "df", "du", "ls", "cat", "head", "tail", "grep",
    "ps", "top", "free", "uptime", "whoami", "pwd",
    "systemctl status", "docker ps", "find",
    "wc", "sort", "uniq", "echo",
]


class OpsWorker(BaseWorker):
    name          = "ops"
    description   = "Infrastructure monitoring, system status, service health, ARCHE management"
    default_scope = ["read:system", "monitor:services", "exec:ops"]

    async def execute(self, task: str, context: dict | None = None) -> WorkerResult:
        try:
            # Always gather real system info first — no LLM needed for raw data
            sys_info = self._gather_real_system_info()

            # If LLM available: synthesize with context
            try:
                content = "Task: " + task + "\n\nReal system state:\n" + sys_info
                response = await self.providers.complete(
                    messages=[{"role": "user", "content": content}],
                    system=(
                        "You are an infrastructure specialist. "
                        "Real system state is provided above. "
                        "Analyze it and answer the task concisely. "
                        "Never guess — only use the real data provided."
                    ),
                    max_tokens=1024,
                )
                output = response.content
            except Exception:
                # No LLM — return raw system info directly
                output = f"## System Status\n\n{sys_info}"

            artifact_id = self._record(
                action="monitor:services",
                success=True,
                input_data=task.encode(),
                output_data=output[:200].encode(),
            )
            return WorkerResult(
                worker=self.name, action="monitor:services",
                success=True, output=output, artifacts=[artifact_id],
            )

        except Exception as e:
            self._record("monitor:services", success=False,
                        input_data=task.encode(), output_data=str(e).encode())
            return WorkerResult(
                worker=self.name, action="monitor:services",
                success=False, output="", error=str(e),
            )

    def _gather_real_system_info(self) -> str:
        """Gather REAL system information — no simulation."""
        info = []

        # OS
        info.append("OS: " + platform.system() + " " + platform.release())
        info.append("Python: " + platform.python_version())

        # Disk
        try:
            r = subprocess.run(["df", "-h"], capture_output=True, text=True, timeout=5)
            if r.returncode == 0:
                info.append("DISK:\n" + r.stdout.strip())
        except Exception:
            pass

        # RAM
        try:
            r = subprocess.run(["free", "-h"], capture_output=True, text=True, timeout=5)
            if r.returncode == 0:
                info.append("RAM:\n" + r.stdout.strip())
        except Exception:
            pass

        # Uptime
        try:
            r = subprocess.run(["uptime"], capture_output=True, text=True, timeout=5)
            if r.returncode == 0:
                info.append("UPTIME: " + r.stdout.strip())
        except Exception:
            pass

        # Services actifs (systemd)
        try:
            r = subprocess.run(
                ["systemctl", "list-units", "--type=service", "--state=running", "--no-pager", "-q"],
                capture_output=True, text=True, timeout=5
            )
            if r.returncode == 0 and r.stdout.strip():
                lines = r.stdout.strip().split("\n")[:15]
                info.append("RUNNING SERVICES:\n" + "\n".join(lines))
        except Exception:
            pass

        # Top processes
        try:
            r = subprocess.run(
                ["ps", "aux", "--sort=-%cpu"],
                capture_output=True, text=True, timeout=5
            )
            if r.returncode == 0:
                lines = r.stdout.strip().split("\n")[:8]
                info.append("TOP PROCESSES:\n" + "\n".join(lines))
        except Exception:
            pass

        # /mnt/data sizes si disponible
        try:
            r = subprocess.run(
                ["du", "-sh", "/mnt/data/"],
                capture_output=True, text=True, timeout=10
            )
            if r.returncode == 0:
                info.append("ARCHE DATA: " + r.stdout.strip())
        except Exception:
            pass

        return "\n\n".join(info)

    async def generate_morning_brief(self) -> str:
        """Générer le brief matinal de Mehdi."""
        sys_info = self._gather_real_system_info()

        # Lire SESSION_STATE si disponible
        session_state = ""
        try:
            ss_path = Path("/mnt/data/ARCHE/SESSION_STATE.md")
            if ss_path.exists():
                content = ss_path.read_text(encoding="utf-8")
                session_state = content[-3000:]  # Derniers 3KB
        except Exception:
            pass

        context = "SYSTEM STATE:\n" + sys_info
        if session_state:
            context += "\n\nSESSION STATE (recent):\n" + session_state

        response = await self.providers.complete(
            messages=[{"role": "user", "content": context}],
            system=(
                "You are BeeQ preparing the morning brief for Mehdi. "
                "Based on the real system state and session context, produce a concise brief: "
                "1) Infrastructure status (any issues?), "
                "2) What happened overnight, "
                "3) Top 3 priorities for today, "
                "4) Any decisions needed. "
                "Be direct. Maximum 300 words. In French."
            ),
            max_tokens=600,
        )
        return response.content
