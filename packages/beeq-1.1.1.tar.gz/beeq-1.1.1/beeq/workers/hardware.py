"""
Worker-Hardware — NRP bridge to the physical world.

Scope: read:sensors · observe:nrp

LEX §3 + PHY §2: physical workers CANNOT be Level 4 (Autonomous).
Level 3 (Supervised) maximum. Every physical action requires human approval.

For now: READ-ONLY (observe). Write/act comes in Phase 4 with NRP production.
"""
from .base import BaseWorker, WorkerResult


class HardwareWorker(BaseWorker):
    name          = "hardware"
    description   = "Read-only sensor observation via NRP. Physical actions require explicit approval."
    default_scope = ["read:sensors", "observe:nrp"]

    async def execute(self, task: str, context: dict | None = None) -> WorkerResult:
        # Phase 0: observe only — no physical actions yet
        # Phase 4: NRP production connection
        output = (
            "[Hardware Worker — Phase 0]\n"
            "Read-only sensor observation mode.\n"
            "Physical actions require NRP production setup (Phase 4).\n\n"
            f"Task received: {task}\n"
            "Status: queued for Phase 4 implementation."
        )
        artifact_id = self._record(
            action="observe:nrp", success=True,
            input_data=task.encode(), output_data=output.encode(),
        )
        return WorkerResult(
            worker=self.name, action="observe:nrp",
            success=True, output=output,
            artifacts=[artifact_id],
        )
