"""
Worker-Write — emails, articles, reports, documentation.

Scope: write:email · write:report · write:doc

Actions réelles :
  - Génération de vrais fichiers Markdown/PDF
  - Sauvegarde dans ~/.beeq/outputs/
  - Formatage structuré selon le type
"""

from pathlib import Path
from datetime import datetime
from .base import BaseWorker, WorkerResult


OUTPUT_DIR = Path.home() / ".beeq" / "outputs"


class WriterWorker(BaseWorker):
    name          = "write"
    description   = "Emails, articles, reports, documentation, summaries — produces real files"
    default_scope = ["write:email", "write:report", "write:doc"]

    async def execute(self, task: str, context: dict | None = None) -> WorkerResult:
        try:
            doc_type = self._detect_type(task)

            response = await self.providers.complete(
                messages=[{"role": "user", "content": task}],
                system=self._system_prompt(doc_type),
                max_tokens=4096,
            )

            output = response.content

            # Sauvegarder le fichier réellement
            file_path = self._save_output(output, doc_type, task)

            artifact_id = self._record(
                action="write:" + doc_type,
                success=True,
                input_data=task.encode(),
                output_data=output.encode(),
            )

            result_msg = output
            if file_path:
                result_msg = output + "\n\n[Saved to: " + file_path + "]"

            return WorkerResult(
                worker=self.name,
                action="write:" + doc_type,
                success=True,
                output=result_msg,
                artifacts=[artifact_id, file_path] if file_path else [artifact_id],
            )

        except Exception as e:
            self._record("write:doc", success=False,
                        input_data=task.encode(), output_data=str(e).encode())
            return WorkerResult(
                worker=self.name, action="write:doc",
                success=False, output="", error=str(e),
            )

    def _detect_type(self, task: str) -> str:
        t = task.lower()
        if any(w in t for w in ["email", "mail", "message", "lettre"]):
            return "email"
        if any(w in t for w in ["report", "rapport", "analyse", "analysis"]):
            return "report"
        if any(w in t for w in ["article", "blog", "post", "hal", "paper"]):
            return "article"
        if any(w in t for w in ["résumé", "summary", "synthèse"]):
            return "summary"
        return "doc"

    def _system_prompt(self, doc_type: str) -> str:
        prompts = {
            "email": "You are a writing specialist. Write a professional, clear email. Include Subject line. Be concise and effective.",
            "report": "You are a writing specialist. Write a structured report with: Executive Summary, Key Findings, Recommendations. Be precise and factual.",
            "article": "You are a writing specialist. Write a well-structured article with introduction, body sections, and conclusion. Academic tone when appropriate.",
            "summary": "You are a writing specialist. Produce a clear, concise summary highlighting the most important points. Use bullet points where appropriate.",
            "doc": "You are a writing specialist. Produce clear, professional, well-structured written content. Adapt tone to context.",
        }
        return prompts.get(doc_type, prompts["doc"])

    def _save_output(self, content: str, doc_type: str, task: str) -> str:
        """Sauvegarder le document dans ~/.beeq/outputs/"""
        try:
            OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
            ts = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = doc_type + "_" + ts + ".md"
            filepath = OUTPUT_DIR / filename
            # Ajouter le contexte de la tâche en en-tête
            full_content = "# BeeQ Output — " + doc_type.upper() + "\n"
            full_content += "Task: " + task[:100] + "\n"
            full_content += "Generated: " + datetime.now().isoformat() + "\n\n---\n\n"
            full_content += content
            filepath.write_text(full_content, encoding="utf-8")
            return str(filepath)
        except Exception:
            return ""
