"""
BeeQ Brief Matinal — Ops quotidien automatique.

Tourne via cron à 7h00.
Collecte l'état de tous les systèmes ARCHE.
Envoie un résumé structuré sur Telegram (si configuré).
Sauve dans SESSION_STATE.

Z = dI/d(log s) · exp(iθ)
  dI : delta information depuis hier
  s  : échelle du brief (quotidien)
  θ  : alignement avec la mission du jour
"""

import asyncio
import json
import subprocess
import hashlib
from datetime import datetime
from pathlib import Path


BRIEF_LOG = Path.home() / ".beeq" / "briefs"
BRIEF_LOG.mkdir(parents=True, exist_ok=True)


async def collect_system_state() -> dict:
    """Collect real system state — no LLM, pure data."""
    state = {}

    # Disk
    try:
        r = subprocess.run(["df", "-h", "--output=target,pcent,avail"],
                          capture_output=True, text=True, timeout=5)
        state["disk"] = r.stdout.strip()
    except Exception:
        state["disk"] = "unavailable"

    # Memory
    try:
        r = subprocess.run(["free", "-h"], capture_output=True, text=True, timeout=5)
        state["memory"] = r.stdout.strip()
    except Exception:
        state["memory"] = "unavailable"

    # Services
    services = ["z-mcp-connector", "z-mcp-server", "zmcp", "echo",
                "gitea", "invoke"]
    service_status = {}
    for svc in services:
        try:
            r = subprocess.run(["systemctl", "is-active", svc],
                              capture_output=True, text=True, timeout=3)
            service_status[svc] = r.stdout.strip()
        except Exception:
            service_status[svc] = "unknown"
    state["services"] = service_status

    # Load average
    try:
        r = subprocess.run(["uptime"], capture_output=True, text=True, timeout=3)
        state["uptime"] = r.stdout.strip()
    except Exception:
        state["uptime"] = "unavailable"

    # LABO_Z scans in progress
    try:
        r = subprocess.run(["ls", "-la", "/mnt/data/LABO_Z/"],
                          capture_output=True, text=True, timeout=3)
        state["labo_z"] = r.stdout.strip()[-500:]
    except Exception:
        state["labo_z"] = "unavailable"

    # Recent git activity
    try:
        r = subprocess.run(
            ["git", "log", "--oneline", "-5"],
            capture_output=True, text=True, timeout=5,
            cwd="/mnt/data/ElmadaniS/beeq"
        )
        state["beeq_git"] = r.stdout.strip()
    except Exception:
        state["beeq_git"] = "unavailable"

    return state


async def generate_brief(hive, system_state: dict) -> str:
    """Ask the Queen to synthesize the state into an actionable brief."""
    state_text = json.dumps(system_state, indent=2, ensure_ascii=False)

    resp = await hive.providers.complete(
        messages=[{
            "role": "user",
            "content": (
                f"Current system state as of {datetime.utcnow().isoformat()}Z:\n\n"
                f"{state_text}"
            )
        }],
        system=(
            "You are BeeQ's morning brief generator for Mehdi (researcher/engineer in Pau, France).\n"
            "Generate a concise morning brief in French with:\n"
            "1. 🔴 URGENT (if any critical issues)\n"
            "2. 📊 ÉTAT SYSTÈME (key metrics, anomalies)\n"
            "3. 📋 ACTIONS SUGGÉRÉES (max 3, ordered by priority)\n"
            "4. 🎯 FOCUS DU JOUR (one recommendation)\n\n"
            "Be direct. Use Z principle: minimum words, maximum information.\n"
            "If everything is fine, say so clearly in 2 lines.\n"
            "Format for Telegram (supports Markdown)."
        ),
        max_tokens=512,
    )
    return resp.content


async def run_brief(send_telegram: bool = False):
    """Main brief function — usable standalone or via cron."""
    from beeq.core import BeeQ

    ts = datetime.utcnow().isoformat()
    print(f"\n🐝 BeeQ Brief — {ts}Z\n")

    # Collect state
    state = await collect_system_state()

    # Setup hive
    hive = BeeQ()
    await hive.setup()

    # Generate brief
    brief = await generate_brief(hive, state)

    # Save to log
    brief_file = BRIEF_LOG / f"brief_{datetime.utcnow().strftime('%Y%m%d_%H%M')}.md"
    brief_content = f"# BeeQ Brief — {ts}Z\n\n{brief}\n\n## System State\n```json\n{json.dumps(state, indent=2)}\n```\n"
    brief_file.write_text(brief_content, encoding="utf-8")

    # Save to memory
    if hive.memory:
        hive.memory.store(
            f"Brief {ts[:10]}: {brief[:200]}",
            tags=["brief", "daily", "system"],
            source="brief_matinal"
        )
        hive.memory.session_set("last_brief", ts)
        hive.memory.session_set("last_brief_path", str(brief_file))

    # Print
    print(brief)
    print(f"\n✅ Saved: {brief_file}")

    # Telegram
    if send_telegram:
        await send_telegram_brief(brief)

    return brief


async def send_telegram_brief(text: str):
    """Send brief to Telegram if token configured."""
    cfg_path = Path.home() / ".beeq" / "config.json"
    if not cfg_path.exists():
        return
    try:
        cfg = json.loads(cfg_path.read_text())
        token   = cfg.get("telegram_token")
        chat_id = cfg.get("telegram_chat_id")
        if not token or not chat_id:
            return
        import httpx
        async with httpx.AsyncClient(timeout=10) as client:
            await client.post(
                f"https://api.telegram.org/bot{token}/sendMessage",
                json={"chat_id": chat_id, "text": text, "parse_mode": "Markdown"}
            )
    except Exception:
        pass


def install_cron():
    """Install cron job for daily brief at 7:00 AM."""
    import subprocess
    beeq_path = subprocess.run(["which", "beeq"], capture_output=True, text=True).stdout.strip()
    if not beeq_path:
        beeq_path = "beeq"

    cron_line = f"0 7 * * * {beeq_path} brief --telegram 2>&1 | logger -t beeq-brief\n"

    # Read existing crontab
    result = subprocess.run(["crontab", "-l"], capture_output=True, text=True)
    existing = result.stdout if result.returncode == 0 else ""

    if "beeq brief" not in existing:
        new_crontab = existing + cron_line
        proc = subprocess.run(["crontab", "-"], input=new_crontab, text=True,
                             capture_output=True)
        if proc.returncode == 0:
            print("✅ Cron installed: brief every day at 7:00 AM")
        else:
            print(f"❌ Cron error: {proc.stderr}")
    else:
        print("ℹ️ Cron already installed")


if __name__ == "__main__":
    asyncio.run(run_brief())
