"""
BaseProvider — LLM-agnostic interface.

The Queen is a role, not a model.
Any LLM can play the Queen or any Worker.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass


@dataclass
class ProviderResponse:
    content:    str
    model:      str
    provider:   str
    input_tokens:  int = 0
    output_tokens: int = 0


LLMResponse = ProviderResponse  # alias

class BaseProvider(ABC):
    """Base class for all LLM providers."""

    name: str = "base"

    @abstractmethod
    async def complete(
        self,
        messages: list[dict],
        system:   str | None = None,
        max_tokens: int = 4096,
    ) -> ProviderResponse:
        """Send messages, return completion."""
        ...

    @abstractmethod
    async def health(self) -> bool:
        """Return True if provider is available."""
        ...
