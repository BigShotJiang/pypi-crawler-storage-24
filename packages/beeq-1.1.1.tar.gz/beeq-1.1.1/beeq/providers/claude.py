"""Claude API provider — Anthropic."""

import os
from .base import BaseProvider, ProviderResponse


class ClaudeProvider(BaseProvider):
    name = "claude"

    def __init__(self, api_key: str | None = None, model: str = "claude-sonnet-4-20250514"):
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY", "")
        self.model   = model

    async def complete(self, messages, system=None, max_tokens=4096):
        try:
            import anthropic
            client = anthropic.AsyncAnthropic(api_key=self.api_key)
            kwargs = dict(model=self.model, max_tokens=max_tokens, messages=messages)
            if system:
                kwargs["system"] = system
            response = await client.messages.create(**kwargs)
            return ProviderResponse(
                content=response.content[0].text,
                model=self.model,
                provider="claude",
                input_tokens=response.usage.input_tokens,
                output_tokens=response.usage.output_tokens,
            )
        except Exception as e:
            raise RuntimeError(f"Claude error: {e}")

    async def health(self) -> bool:
        return bool(self.api_key)
