"""Ollama provider — local, free, private."""

from .base import BaseProvider, ProviderResponse


class OllamaProvider(BaseProvider):
    name = "ollama"

    def __init__(self, host: str = "http://localhost:11434", model: str = "llama3"):
        self.host  = host
        self.model = model

    async def complete(self, messages, system=None, max_tokens=4096):
        try:
            import httpx
            prompt_messages = []
            if system:
                prompt_messages.append({"role": "system", "content": system})
            prompt_messages.extend(messages)

            async with httpx.AsyncClient(timeout=120) as client:
                r = await client.post(
                    f"{self.host}/api/chat",
                    json={
                        "model":    self.model,
                        "messages": prompt_messages,
                        "stream":   False,
                        "options":  {"num_predict": max_tokens},
                    }
                )
                r.raise_for_status()
                data = r.json()
                return ProviderResponse(
                    content=data["message"]["content"],
                    model=self.model,
                    provider="ollama",
                )
        except Exception as e:
            raise RuntimeError(f"Ollama error: {e}")

    async def health(self) -> bool:
        try:
            import httpx
            async with httpx.AsyncClient(timeout=5) as client:
                r = await client.get(f"{self.host}/api/tags")
                return r.status_code == 200
        except:
            return False
