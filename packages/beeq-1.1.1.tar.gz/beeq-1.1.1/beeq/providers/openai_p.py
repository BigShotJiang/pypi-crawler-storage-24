"""OpenAI provider for BeeQ."""
import os
from .base import BaseProvider, ProviderResponse

class OpenAIProvider(BaseProvider):
    name = "openai"

    def __init__(self, api_key: str | None = None, model: str = "gpt-4o-mini"):
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY", "")
        self.model   = model

    async def complete(self, messages: list[dict], system: str | None = None,
                       max_tokens: int = 4096, **kwargs) -> ProviderResponse:
        import httpx
        msgs = messages
        if system:
            msgs = [{"role": "system", "content": system}] + messages
        async with httpx.AsyncClient(timeout=60) as client:
            r = await client.post(
                "https://api.openai.com/v1/chat/completions",
                headers={"Authorization": f"Bearer {self.api_key}"},
                json={"model": self.model, "messages": msgs, "max_tokens": max_tokens},
            )
            r.raise_for_status()
            data = r.json()
            return ProviderResponse(
                content=data["choices"][0]["message"]["content"],
                model=self.model,
                provider=self.name,
                input_tokens=data["usage"]["prompt_tokens"],
                output_tokens=data["usage"]["completion_tokens"],
            )

    async def health(self) -> bool:
        if not self.api_key: return False
        try:
            import httpx
            async with httpx.AsyncClient(timeout=5) as c:
                r = await c.get("https://api.openai.com/v1/models",
                                headers={"Authorization": f"Bearer {self.api_key}"})
                return r.status_code == 200
        except: return False
