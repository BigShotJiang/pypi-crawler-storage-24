"""
ProviderManager — selects the right LLM for each task.

User configures available providers once.
The Queen decides which provider per task based on:
  1. Data sensitivity (confidential → local only)
  2. Task complexity (reasoning → best model)
  3. Cost (routine → cheapest)
  4. Availability (fallback chain)

LEX §8: response is proportional to the task.
"""

import asyncio
from .base import BaseProvider, ProviderResponse


class ProviderManager:

    def __init__(self):
        self._providers: list[BaseProvider] = []
        self._local:     list[BaseProvider] = []

    def register(self, provider: BaseProvider, local: bool = False) -> None:
        self._providers.append(provider)
        if local:
            self._local.append(provider)

    async def complete(
        self,
        messages:    list[dict],
        system:      str | None = None,
        max_tokens:  int = 4096,
        local_only:  bool = False,
        complexity:  str = "medium",   # low / medium / high
    ) -> ProviderResponse:
        """
        Select provider and complete.
        Tries providers in order, falls back on failure.
        """
        pool = self._local if local_only else self._providers
        if not pool:
            raise RuntimeError(
                "No LLM provider configured. "
                "Run: beeq connect claude  OR  beeq connect ollama"
            )

        for provider in pool:
            try:
                if await provider.health():
                    return await provider.complete(
                        messages, system=system, max_tokens=max_tokens
                    )
            except Exception as e:
                continue   # try next in fallback chain

        raise RuntimeError(
            f"All providers unavailable. "
            f"Configured: {[p.name for p in pool]}"
        )

    async def health_all(self) -> dict[str, bool]:
        results = {}
        for p in self._providers:
            results[p.name] = await p.health()
        return results
