# BeeQ

**The first AI hive. One curl. One queen. An army that works.**

```bash
curl -fsSL https://beeq.run/install | bash
```

```
BeeQ Hive Status
┏━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━┓
┃ Component       ┃ Status            ┃
┡━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━┩
│ Queen           │ ready             │
│ Audit chain     │ valid — 0 entries │
│ Worker-research │ active            │
│ Worker-code     │ active            │
│ Worker-write    │ active            │
│ Worker-ops      │ active            │
└─────────────────┴───────────────────┘
```

Every action signed. Every action traceable.
Every action reversible. You remain sovereign.

---

## Install

```bash
# Option 1 — one curl (recommended)
curl -fsSL https://beeq.run/install | bash

# Option 2 — pip
pip install beeq
beeq connect ollama   # or: beeq connect claude --key sk-ant-...
beeq start
```

## Usage

```bash
beeq start                        # start your hive interactively
beeq mission "prepare my weekly report"   # single mission
beeq status                       # hive status
beeq audit                        # view full audit chain
beeq revoke research              # revoke a worker (LEX §5)
```

## What makes BeeQ different

| | Others | BeeQ |
|---|---|---|
| Agent cryptographic identity | ✗ | ✅ AAP |
| Signed delegation chain | ✗ | ✅ scope(worker) ⊂ scope(queen) |
| Tamper-evident audit | ✗ | ✅ hash chain |
| Physical world (robots/IoT) | ✗ | ✅ NRP |
| Physical World Rule | ✗ | ✅ Level 4 forbidden |
| LLM-agnostic | partial | ✅ Claude/OpenAI/Ollama/GGUF |
| Local-first | ✗ | ✅ your data never leaves |
| Single curl install | partial | ✅ |

## Architecture

```
HUMAN  (sovereign — gives mission, validates decisions)
  ↓
QUEEN  (orchestrates — decomposes, delegates, reports)
  ↓
WORKERS (execute within signed AAP scope)
  ├─ research   web · APIs · documents
  ├─ code       files · git · execution
  ├─ write      emails · articles · reports
  └─ ops        infrastructure · monitoring
```

## Governed by

- **LEX** — 11 civilizational laws (MIT)
- **PHY** — 7 physical laws for embodied agents (MIT)
- **AAP** — Agent Accountability Protocol (MIT)
- **NRP** — Node Reach Protocol for physical world (MIT)

## License

BSL-1.1 — Free for individuals, research, open source.
Commercial use requires a license.

See [beeq.run](https://beeq.run) for details.
