# Proposal Harness Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a proposal harness that turns any Claude Code or Codex session into a multi-agent proposal writing system with section-level SSOT management, 4-person agent teams, and structured generate-verify-revise loops.

**Architecture:** The harness is a set of instruction files (`AGENTS.md`, `CLAUDE.md`, agent prompts, skills) that configure Codex or Claude Code to behave as the Proposal Harness. SSOT documents are markdown files with YAML frontmatter. All orchestration logic lives in skill/prompt instructions — no application code.

**Tech Stack:** Agent instruction files (markdown), YAML frontmatter, Mermaid diagrams, shell scripts (validation)

**Spec:** `docs/superpowers/specs/2026-03-13-proposal-harness-design.md`

---

## File Structure

```
proposal-harness/
├── AGENTS.md                        # Codex harness entry point (~100 lines, map role)
├── CLAUDE.md                        # Claude Code harness entry point
├── ARCHITECTURE.md                  # System topology, file map
├── agents/
│   ├── overseer.md                  # EA Overseer system prompt
│   ├── team-lead.md                 # Team Lead system prompt (parameterized by domain)
│   ├── writer.md                    # Writer system prompt
│   ├── researcher.md                # Researcher system prompt
│   └── critic.md                    # Critic system prompt
├── skills/
│   ├── design.md                    # /design command skill
│   ├── write.md                     # /write command skill (state detection + session loop)
│   ├── diagnose.md                  # /diagnose command skill
│   ├── verify.md                    # /verify command skill
│   ├── status.md                    # /status command skill + Proposal Guide renderer
│   └── output.md                    # Output assembly + format rendering
├── templates/
│   ├── ssot.md                      # SSOT document template with full metadata schema
│   ├── ideation-note.md             # Ideation note template
│   └── init/
│       ├── proposal-meta.yaml       # Project metadata template
│       ├── glossary.yaml            # Glossary template
│       ├── outline.yaml             # TOC + SSOT ordering template
│       └── rfp-trace-matrix.md      # RFP requirements traceability template
├── reference/
│   ├── state-machine.md             # SSOT state transitions + rules
│   ├── quality-criteria.md          # Verification checklist per domain
│   ├── proposal-guide-format.md     # Proposal Guide rendering spec
│   ├── impact-rules.md              # Impact propagation severity rules
│   ├── skills-catalog.md            # All agent skills mapped to roles
│   ├── cross-team-communication.md  # Inter-team communication protocol
│   └── error-handling.md            # Error scenarios + graceful degradation
└── scripts/
    └── verify-harness.sh            # Harness integrity validation
```

---

## Chunk 1: Foundation

### Task 1: CLAUDE.md — Harness Entry Point

**Files:**
- Create: `CLAUDE.md`

This is the ~100-line map file. Progressive disclosure — agents start here, follow links deeper.

- [ ] **Step 1: Write CLAUDE.md**

```markdown
# Proposal Harness

Multi-agent system for financial IT proposal writing.

## Identity

You are a Proposal Harness — a team of specialized agents that help Proposal PMs
write 100+ page technical proposals through collaborative dialogue.

## Agent Roles

- **Overseer (EA)**: Strategy, cross-SSOT consistency, final approval. See `agents/overseer.md`
- **Team Lead**: Per-domain orchestrator. See `agents/team-lead.md`
- **Writer**: Drafts content. See `agents/writer.md`
- **Researcher**: Gathers data. See `agents/researcher.md`
- **Critic**: Verifies quality. See `agents/critic.md`

## Commands

| Command | Purpose | Skill |
|---------|---------|-------|
| /design | New proposal strategy + TOC | skills/design.md |
| /write <section> | Work on a section (mode auto-detected) | skills/write.md |
| /diagnose | Full quality diagnosis | skills/diagnose.md |
| /verify | Cross-SSOT consistency check | skills/verify.md |
| /status | Progress dashboard | skills/status.md |

Output generation is triggered via natural language (e.g., "PDF로 출력해줘"). See `skills/output.md`.

Natural language input is always accepted and routed automatically.

## SSOT Documents

Each proposal section is an independent SSOT (Single Source of Truth) document.
- Template: `templates/ssot.md`
- State machine: `reference/state-machine.md`
- Storage: `ssot/<team>/<id>.md`

## Key Rules

1. User is the decision-maker. Agents recommend, user approves.
2. Background work is always parallel. User-facing interactions are sequential.
3. Every SSOT goes through the session loop: generate -> verify -> revise -> user confirm -> Overseer review.
4. Always show the Proposal Guide at the bottom of every response. See `reference/proposal-guide-format.md`.

## Project Structure

See `ARCHITECTURE.md` for full file map.
```

- [ ] **Step 2: Verify file parses correctly**

Run: `head -5 CLAUDE.md`
Expected: `# Proposal Harness` on first line

- [ ] **Step 3: Commit**

```bash
git add CLAUDE.md
git commit -m "feat: add CLAUDE.md harness entry point"
```

---

### Task 2: ARCHITECTURE.md — System Map

**Files:**
- Create: `ARCHITECTURE.md`

- [ ] **Step 1: Write ARCHITECTURE.md**

```markdown
# Architecture

## System Topology

```
Overseer (EA)
├── BA Team (4 agents) — business/requirements SSOTs
├── DA Team (4 agents) — data architecture SSOTs
├── TA Team (4 agents) — tech architecture SSOTs
└── SA Team (4 agents) — solution/product SSOTs
```

## Directory Map

| Path | Purpose |
|------|---------|
| `CLAUDE.md` | Harness entry point (read this first) |
| `agents/` | Agent system prompts (Overseer, Team Lead, Writer, Researcher, Critic) |
| `skills/` | Command implementations (/design, /write, /diagnose, /verify, /status) |
| `templates/` | SSOT template, project initialization templates |
| `reference/` | State machine, quality criteria, impact rules |
| `scripts/` | Validation scripts |

## Project Directory (created per proposal)

| Path | Purpose |
|------|---------|
| `meta/` | Project metadata, glossary, outline, RFP traceability |
| `ssot/<team>/` | SSOT documents per domain team |
| `ideation/` | Pre-SSOT exploration notes |
| `assets/` | Diagrams, images, certificates |
| `templates/` | Company PPT/PDF/HTML templates |
| `output/` | Generated deliverables |

## Data Flow

1. User input -> Skill routes to scenario (Design/Explore/Write/Diagnose)
2. Team Lead orchestrates Writer + Researcher + Critic
3. Session loop: draft -> verify -> revise -> user confirm -> Overseer review
4. Confirmed SSOTs assembled into final proposal via output pipeline
```

- [ ] **Step 2: Commit**

```bash
git add ARCHITECTURE.md
git commit -m "feat: add ARCHITECTURE.md system map"
```

---

### Task 3: SSOT Template + State Machine

**Files:**
- Create: `templates/ssot.md`
- Create: `reference/state-machine.md`

- [ ] **Step 1: Write SSOT template**

`templates/ssot.md` — the template that every SSOT document starts from. Includes full YAML metadata schema with all fields from spec Section 3.1, plus body structure from Section 3.2.

- [ ] **Step 2: Write state machine reference**

`reference/state-machine.md` — the complete SSOT state transition rules from spec Section 3.3. Includes:
- State diagram (ASCII)
- Transition rules with session loop step references
- Auto-detect mode table (empty/ideation -> Create, draft -> Edit, verified/tentative -> Revise, confirmed -> Re-edit, existing -> Enhance)
- Impact propagation severity rules (High/Medium/Low)

- [ ] **Step 3: Commit**

```bash
git add templates/ssot.md reference/state-machine.md
git commit -m "feat: add SSOT template and state machine reference"
```

---

### Task 4: Project Initialization Templates

**Files:**
- Create: `templates/init/proposal-meta.yaml`
- Create: `templates/init/glossary.yaml`
- Create: `templates/init/outline.yaml`
- Create: `templates/ideation-note.md`

- [ ] **Step 1: Write proposal-meta.yaml template**

Project-level metadata: customer name, project name, timeline, team assignments, RFP reference.

- [ ] **Step 2: Write glossary.yaml template**

Unified glossary structure: term, definition, standard_name, category, source_ssot.

- [ ] **Step 3: Write outline.yaml template**

TOC structure: section ordering, SSOT assignments, priority, dependencies.

- [ ] **Step 4: Write ideation-note.md template**

Pre-SSOT exploration note: direction, alternatives considered, key decisions, transition readiness.

- [ ] **Step 5: Write rfp-trace-matrix.md template**

RFP requirements traceability: requirement ID, description, mapped SSOT, coverage status, notes.

- [ ] **Step 6: Commit**

```bash
git add templates/
git commit -m "feat: add project initialization and ideation templates"
```

---

### Task 5: Reference Documents

**Files:**
- Create: `reference/proposal-guide-format.md`
- Create: `reference/quality-criteria.md`
- Create: `reference/impact-rules.md`
- Create: `reference/skills-catalog.md`
- Create: `reference/cross-team-communication.md`
- Create: `reference/error-handling.md`

- [ ] **Step 1: Write Proposal Guide format reference**

`reference/proposal-guide-format.md` — rendering spec from spec Section 9:
- Format template (Project/Done/In Progress/Recommended)
- Status icons ([v], [~], [>], [ ], [!])
- Recommendation logic table
- Single recommendation rule (highest priority only)
- Must appear at bottom of every response from every skill

- [ ] **Step 2: Write quality criteria reference**

`reference/quality-criteria.md` — verification checklist per domain from spec Section 12:
- Product specifications criteria
- Solution architecture criteria
- Platform details criteria
- Implementation plan criteria
- Reference case criteria
- Regulatory compliance criteria

- [ ] **Step 3: Write impact rules reference**

`reference/impact-rules.md` — impact propagation rules from spec Section 5.4:
- Severity classification (High/Medium/Low)
- Action per severity
- Examples

- [ ] **Step 4: Write skills catalog reference**

`reference/skills-catalog.md` — all agent skills from spec Section 6, mapped to roles:
- Essential Skills (6.1): Mermaid, Table Generator, FP/Cost Estimation, RFP Traceability Matrix, Document Parser
- Quality Differentiation Skills (6.2): Glossary, Regulatory Checklist, Reference Manager, Competitive Analysis
- Output Skills (6.3): MD -> PPT/PDF/HTML, Version Diff, Executive Summary
- Mermaid Diagram Types (6.4): flowchart, sequenceDiagram, erDiagram, gantt, stateDiagram, architecture, pie/quadrantChart
- Each skill: purpose, primary teams, invocation guidance

- [ ] **Step 5: Write cross-team communication reference**

`reference/cross-team-communication.md` — from spec Section 10:
- Four channels: dependency notification, glossary sync, escalation, impact broadcast
- Conflict resolution protocol (4 steps)
- Participant mapping per channel

- [ ] **Step 6: Write error handling reference**

`reference/error-handling.md` — guidance for deferred concerns from spec Section 11:
- What happens when a dependency SSOT doesn't exist yet (proceed with placeholder, flag for later)
- Session persistence (SSOT files on disk are the persistence layer)
- Partial failure recovery (resume session loop from last completed step)
- Rollback guidance (revert SSOT to previous version via git history)

- [ ] **Step 7: Commit**

```bash
git add reference/
git commit -m "feat: add reference documents (guide, quality, impact, skills, communication, errors)"
```

---

### Task 6: Validation Script

**Files:**
- Create: `scripts/verify-harness.sh`

- [ ] **Step 1: Write verify-harness.sh**

Checks:
- All required files exist (CLAUDE.md, ARCHITECTURE.md, all agents, all skills, all templates, all references)
- YAML frontmatter in templates parses correctly
- Cross-references in CLAUDE.md point to existing files
- No broken internal links

- [ ] **Step 2: Make executable and run**

```bash
chmod +x scripts/verify-harness.sh
./scripts/verify-harness.sh
```

Expected: All checks pass (some will fail until later tasks create remaining files)

- [ ] **Step 3: Commit**

```bash
git add scripts/verify-harness.sh
git commit -m "feat: add harness integrity validation script"
```

---

## Chunk 2: Agent Prompts

### Task 7: Overseer (EA) Agent Prompt

**Files:**
- Create: `agents/overseer.md`

- [ ] **Step 1: Write Overseer prompt**

`agents/overseer.md` — system prompt for the EA Overseer agent. Covers:
- Identity: Enterprise Architect overseeing entire proposal
- Responsibilities: strategy, cross-SSOT consistency, final approval
- Design scenario behavior (spec Section 5.2): context dialogue -> strategy -> TOC -> section direction -> proposal brief
- Cross-review behavior (spec Section 4, step 10): consistency checks, directive issuance
- `/verify` broad review behavior (spec Section 8.3)
- Conflict resolution protocol (spec Section 10.2)
- Glossary authority
- Tone: authoritative but collaborative, always explains rationale

- [ ] **Step 2: Commit**

```bash
git add agents/overseer.md
git commit -m "feat: add Overseer (EA) agent prompt"
```

---

### Task 8: Team Lead Agent Prompt

**Files:**
- Create: `agents/team-lead.md`

- [ ] **Step 1: Write Team Lead prompt**

`agents/team-lead.md` — parameterized by domain (BA/DA/TA/SA). Covers:
- Identity: domain team orchestrator (domain injected at runtime)
- Session loop orchestration (spec Section 4, steps 1-2, 8-9): context gathering, directing team, presenting to user
- State detection and mode selection (spec Section 5.4)
- Explore scenario behavior (spec Section 5.3): exploratory dialogue, Explore-to-Write transition
- User interaction patterns: 1-2 questions with recommended options, summary presentations
- Reporting to Overseer
- Auto-split rule (spec Section 3.4)
- Proposal Guide rendering (reference to `reference/proposal-guide-format.md`)

- [ ] **Step 2: Commit**

```bash
git add agents/team-lead.md
git commit -m "feat: add Team Lead agent prompt"
```

---

### Task 9: Writer Agent Prompt

**Files:**
- Create: `agents/writer.md`

- [ ] **Step 1: Write Writer prompt**

`agents/writer.md` — Covers:
- Identity: proposal content writer
- Drafting behavior (spec Section 4, step 4): structured content, tables, Mermaid diagrams
- Revision behavior (spec Section 4, step 6): apply Critic feedback, incorporate additional research
- Skills: Mermaid diagram types (spec Section 6.4), table generation, FP/cost estimation
- Output format: follows SSOT body structure (spec Section 3.2)
- Quality target: product specs, solution architecture, platform details (spec Section 12)
- Tone: precise, data-driven, professional Korean proposal style

- [ ] **Step 2: Commit**

```bash
git add agents/writer.md
git commit -m "feat: add Writer agent prompt"
```

---

### Task 10: Researcher Agent Prompt

**Files:**
- Create: `agents/researcher.md`

- [ ] **Step 1: Write Researcher prompt**

`agents/researcher.md` — Covers:
- Identity: data gatherer and fact verifier
- Research behavior (spec Section 4, step 3): product specs, reference cases, certifications, pricing, regulatory data
- Skills: reference manager, competitive analysis, document parser
- Output: structured research results with sources and confidence levels
- Supporting Evidence section population (spec Section 3.2)
- Works in parallel with Writer during revision (spec Section 4, step 6)

- [ ] **Step 2: Commit**

```bash
git add agents/researcher.md
git commit -m "feat: add Researcher agent prompt"
```

---

### Task 11: Critic Agent Prompt

**Files:**
- Create: `agents/critic.md`

- [ ] **Step 1: Write Critic prompt**

`agents/critic.md` — Covers:
- Identity: independent quality verifier
- Verification behavior (spec Section 4, step 5): RFP requirements met, data accuracy, gaps, cross-SSOT consistency
- Skills: glossary enforcement, regulatory checklist, RFP traceability matrix
- Output: structured issue list with severity and suggested fixes
- Verification Log population (spec Section 3.2)
- Re-verify behavior (spec Section 4, step 7)
- Independence: does not take direction from Writer, only from Team Lead

- [ ] **Step 2: Commit**

```bash
git add agents/critic.md
git commit -m "feat: add Critic agent prompt"
```

---

## Chunk 3: Core Commands

### Task 12: /design Skill

**Files:**
- Create: `skills/design.md`

- [ ] **Step 1: Write /design skill**

`skills/design.md` — implements Design scenario (spec Section 5.2):
1. Activates Overseer agent
2. Context dialogue: asks about project scope, competitors, strengths
3. Strategy exploration: 2-3 options with recommendations
4. TOC co-design: propose structure, user adjusts
5. Section direction: quick alignment per section
6. Proposal brief: generate SSOT structure (all `ideation`), assign teams, priority order
7. Initialize project directory (`meta/`, `ssot/`, `ideation/`, `assets/`)
8. Populate `meta/proposal-meta.yaml`, `meta/outline.yaml`, `meta/glossary.yaml`, `meta/rfp-trace-matrix.md`
9. Transition: show Proposal Guide with first `/write` recommendation

Handles input sources (spec Appendix A): RFP upload, conversational, existing proposal, or combination.

Must render Proposal Guide at bottom of every response (see `reference/proposal-guide-format.md`).

- [ ] **Step 2: Commit**

```bash
git add skills/design.md
git commit -m "feat: add /design command skill"
```

---

### Task 13: /write Skill

**Files:**
- Create: `skills/write.md`

- [ ] **Step 1: Write /write skill**

`skills/write.md` — the most complex skill. Implements Write scenario (spec Section 5.4) + session loop (spec Section 4):

**State detection logic:**
- Read target SSOT metadata
- Map status to mode (Create/Edit/Revise/Re-edit/Enhance) per state machine
- For Re-edit: show warning + run impact analysis before proceeding
- For no-direction sections: auto-enter Explore first (spec Section 5.3)

**Session loop orchestration:**
- Steps 1-2: Team Lead gathers context, directs Researcher
- Step 3: Researcher gathers data (parallel with any other background work)
- Step 4: Writer drafts content
- Steps 5-7: Critic verifies, Writer+Researcher revise if needed, re-verify loop
- Step 8: Team Lead presents to user with summary + recommendations
- Step 9: User approves -> tentative confirmation
- Step 10: Overseer cross-review -> confirmed or directive

**SSOT lifecycle:**
- Create/update SSOT file with proper metadata
- Update version, status, history on each transition
- Update `meta/outline.yaml` and `meta/glossary.yaml` as needed

**Proposal Guide:**
- Show at bottom of every response per `reference/proposal-guide-format.md`

- [ ] **Step 2: Commit**

```bash
git add skills/write.md
git commit -m "feat: add /write command skill with session loop"
```

---

### Task 14: /status Skill + Proposal Guide

**Files:**
- Create: `skills/status.md`

- [ ] **Step 1: Write /status skill**

`skills/status.md` — implements progress dashboard:
- Read all SSOT files in `ssot/` directory
- Read `meta/outline.yaml` for ordering
- Generate full status view:
  - Per-team breakdown with SSOT statuses
  - Overall progress (confirmed / total)
  - Blocked items (dependency issues)
  - Active work (in-progress SSOTs with current activity)
- Render Proposal Guide at bottom

- [ ] **Step 2: Commit**

```bash
git add skills/status.md
git commit -m "feat: add /status command skill"
```

---

## Chunk 4: Advanced Commands

### Task 15: /diagnose Skill

**Files:**
- Create: `skills/diagnose.md`

- [ ] **Step 1: Write /diagnose skill**

`skills/diagnose.md` — implements Diagnose scenario (spec Section 5.5):

**Parse mode** (existing proposal uploaded):
1. Parse document (PDF/DOCX/PPTX) into section-level SSOTs with status `existing`
2. Create SSOT files in `ssot/<team>/` with parsed content

**Diagnosis mode** (current project or parsed):
1. Overseer grades each SSOT (A/B/C/D)
2. Identify issues per section
3. Identify cross-cutting problems (terminology, data mismatches)
4. Present diagnosis report

**Improvement mode:**
1. User selects: full / selective / cross-cutting only / re-prioritize
2. Sequential improvement via session loop per selected SSOT
3. Final integration review: before/after comparison, residual issues, final grading

Must render Proposal Guide at bottom of every response (see `reference/proposal-guide-format.md`).

- [ ] **Step 2: Commit**

```bash
git add skills/diagnose.md
git commit -m "feat: add /diagnose command skill"
```

---

### Task 16: /verify Skill

**Files:**
- Create: `skills/verify.md`

- [ ] **Step 1: Write /verify skill**

`skills/verify.md` — implements on-demand cross-SSOT verification (spec Section 8.3):

Broader than automatic Overseer review:
- Scope: all confirmed/tentative SSOTs together
- Checks: terminology consistency, data accuracy, redundancy, gap analysis, narrative flow
- Cross-team communication: dependency notifications, glossary sync
- Output: structured report with issues grouped by severity
- Action items: specific SSOTs to revise with directives

- [ ] **Step 2: Commit**

```bash
git add skills/verify.md
git commit -m "feat: add /verify command skill"
```

---

## Chunk 5: Output Pipeline

### Task 17: Output Assembly Skill

**Files:**
- Create: `skills/output.md`

- [ ] **Step 1: Write output skill**

`skills/output.md` — implements output pipeline (spec Section 7):

**Assembly engine logic:**
1. Read `meta/outline.yaml` for SSOT ordering
2. Collect all confirmed SSOTs from `ssot/<team>/`
3. Generate TOC from outline
4. Resolve cross-references between SSOTs
5. Insert glossary from `meta/glossary.yaml`
6. Generate unified markdown (`output/proposal-vN.md`)

**Format rendering:**
- Markdown: always generated, the editable source of truth
- PPT: company template mapping (`templates/company-ppt.pptx`), slide layout per section
- PDF: page numbers, watermark, TOC auto-generation (`templates/pdf-style.css`)
- HTML: hyperlinks between sections, search, status badges (`templates/html-theme/`)

User selects format(s) at output time.

**Quick Edit Workflow (spec Section 7.3):**
1. Edit source SSOT
2. Impact check via `affects` metadata
3. Cascade edits to affected SSOTs
4. Incremental rebuild (PPT: replace slides, PDF: full regen, HTML: partial rebuild)

**Version Diff skill:**
- Compare SSOT versions side-by-side
- Highlight changes between versions

**Executive Summary skill:**
- Generate 1-page summary of long SSOTs for PM overview

Must render Proposal Guide at bottom of every response.

- [ ] **Step 2: Commit**

```bash
git add skills/output.md
git commit -m "feat: add output assembly and format rendering skill"
```

---

## Chunk 6: Integration & Validation

### Task 18: Natural Language Router

**Files:**
- Modify: `CLAUDE.md` (add routing rules section)

- [ ] **Step 1: Add natural language routing rules to CLAUDE.md**

Add section that maps natural language patterns to commands (spec Section 8.2):
```
"RFP 받았는데..." -> /design
"이행계획 어떻게..." -> /write impl
"HSM 모델 변경..." -> /write hsm (re-edit)
"전체적으로 좀 약한..." -> /diagnose
"이전 버전이랑 비교..." -> version diff
"PDF로 출력해줘" -> output generation
```

- [ ] **Step 2: Commit**

```bash
git add CLAUDE.md
git commit -m "feat: add natural language routing rules to CLAUDE.md"
```

---

### Task 19: Full Harness Validation

**Files:**
- Modify: `scripts/verify-harness.sh` (update with all files now created)

- [ ] **Step 1: Update verify-harness.sh with complete file list**

All required files should now exist. Update the validation script to check:
- All 5 agent prompts exist and have required sections
- All 6 skills exist and reference correct agent prompts
- All templates have valid YAML
- CLAUDE.md references all files correctly
- ARCHITECTURE.md is up to date
- Cross-references between files resolve

- [ ] **Step 2: Run full validation**

```bash
./scripts/verify-harness.sh
```

Expected: All checks pass

- [ ] **Step 3: Commit**

```bash
git add scripts/verify-harness.sh
git commit -m "feat: complete harness validation with all files"
```

---

### Task 20: Final Review

**Files:**
- Modify: `CLAUDE.md` (final polish)
- Modify: `ARCHITECTURE.md` (verify accuracy)

- [ ] **Step 1: Walk through the full harness**

Read every file in order: CLAUDE.md -> ARCHITECTURE.md -> each agent -> each skill -> each template -> each reference. Verify:
- No broken cross-references
- Consistent terminology
- No contradictions with spec
- Progressive disclosure works (entry point -> details)

- [ ] **Step 2: Fix any issues found**

- [ ] **Step 3: Final commit**

```bash
git add CLAUDE.md ARCHITECTURE.md agents/ skills/ templates/ reference/ scripts/
git commit -m "feat: complete Proposal Harness v1.0"
```
