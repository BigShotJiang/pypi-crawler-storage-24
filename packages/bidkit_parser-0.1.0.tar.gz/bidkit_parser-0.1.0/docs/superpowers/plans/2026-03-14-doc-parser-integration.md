# Doc-Parser Core Extraction Integration Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Integrate doc-parser's document extraction capabilities (PDF, DOCX, PPTX, XLSX) into the Harness project, removing AWS Bedrock dependency while preserving extraction quality and parallel processing performance.

**Architecture:** Port the pure extraction layer from daekeun-ml/doc-parser as a `parser/` module. The PDF pipeline uses Docling for high-fidelity extraction; the Office pipeline uses python-pptx/docx/openpyxl with AST-based parsing. All AI summarization is removed — Harness agents (Researcher, Writer) handle summarization natively. A unified `parse()` entry point auto-dispatches by file extension.

**Tech Stack:** Python 3.12+, docling, pdfplumber, python-docx, python-pptx, openpyxl, Pillow, uv

---

## Source Reference

All code is ported from https://github.com/daekeun-ml/doc-parser. The key seam: extraction (pure) vs summarization (AWS Bedrock). We keep extraction, remove summarization.

### What to Port (Pure Extraction)

| Source File | Purpose | AWS-Free? |
|-------------|---------|-----------|
| `pdf_parser/converter.py` | Docling-based PDF extraction | Yes |
| `pdf_parser/utils.py` | Bbox helpers, figure categories | Yes |
| `pdf_parser/markdown_builder.py` | PDF → Markdown assembly | Yes (accepts empty summaries) |
| `office_parser/types.py` | AST data structures | Yes |
| `office_parser/parser.py` | DOCX/PPTX/XLSX/RTF extraction | Mixed — remove summarization blocks |
| `office_parser/worker.py` | Multiprocessing wrapper | Yes |

### What to Remove

| Source File | Reason |
|-------------|--------|
| `pdf_parser/summarizer.py` | Entirely AWS Bedrock |
| `mcp_server.py` | MCP server (not needed — Harness is the agent) |
| All `_summarize_*()` methods in `office_parser/parser.py` | AWS Bedrock calls |
| `boto3`, `langchain`, `strands-agents` dependencies | AWS/unused |

---

## File Structure

```
parser/
├── __init__.py              # Unified parse() entry point + auto-dispatch
├── pdf_converter.py         # Docling-based PDF extraction (from pdf_parser/converter.py)
├── pdf_utils.py             # Bbox helpers, figure categories (from pdf_parser/utils.py)
├── pdf_markdown.py          # PDF → Markdown builder (from pdf_parser/markdown_builder.py)
├── office_parser.py         # DOCX/PPTX/XLSX/RTF extraction (from office_parser/parser.py, stripped)
├── office_types.py          # AST data structures (from office_parser/types.py)
├── office_worker.py         # Multiprocessing wrapper (from office_parser/worker.py)
├── run.py                   # CLI entry point
└── requirements.txt         # Pure extraction dependencies only
tests/
└── parser/
    ├── test_parse_dispatch.py   # Auto-dispatch tests
    ├── test_pdf_converter.py    # PDF extraction tests
    └── test_office_parser.py    # Office extraction tests
```

---

## Chunk 1: Foundation

### Task 1: Project Setup — Dependencies and Module Structure

**Files:**
- Create: `parser/__init__.py`
- Create: `parser/requirements.txt`
- Create: `parser/run.py`

- [ ] **Step 1: Create `parser/requirements.txt`**

```
docling>=2.76.0
pdfplumber>=0.10.0
pdf2image>=1.17.0
pytesseract>=0.3.10
python-docx>=0.8.11
python-pptx>=0.6.21
openpyxl>=3.0.0
striprtf>=0.0.26
pillow>=12.1.1
pandas>=2.3.3
tabulate>=0.9.0
```

No boto3, no langchain, no strands-agents.

- [ ] **Step 2: Create `parser/__init__.py`** with unified interface

```python
"""Document parser for Proposal Harness.

Extracts text, tables, and images from PDF, DOCX, PPTX, XLSX files.
Ported from https://github.com/daekeun-ml/doc-parser (extraction-only, no AWS).
"""

from pathlib import Path
from typing import Union

SUPPORTED_EXTENSIONS = {
    '.pdf': 'pdf',
    '.docx': 'office', '.pptx': 'office', '.xlsx': 'office',
    '.odt': 'office', '.odp': 'office', '.ods': 'office',
    '.rtf': 'office',
}


def parse(file_path: Union[str, Path], output_dir: Union[str, Path] = "output",
          output_format: str = "markdown", table_mode: str = "accurate") -> str:
    """Parse a document and return extracted content as markdown/html/text.

    Args:
        file_path: Path to document file.
        output_dir: Directory for extracted assets (images, tables).
        output_format: One of "markdown", "html", "text".
        table_mode: PDF table extraction mode — "accurate" or "fast".

    Returns:
        Extracted content as string in requested format.

    Raises:
        ValueError: If file extension is not supported.
        FileNotFoundError: If file does not exist.
    """
    file_path = Path(file_path)
    output_dir = Path(output_dir)

    if not file_path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    ext = file_path.suffix.lower()
    parser_type = SUPPORTED_EXTENSIONS.get(ext)

    if parser_type is None:
        raise ValueError(
            f"Unsupported file extension: {ext}. "
            f"Supported: {', '.join(SUPPORTED_EXTENSIONS.keys())}"
        )

    if parser_type == 'pdf':
        return _parse_pdf(file_path, output_dir, table_mode)
    else:
        return _parse_office(file_path, output_dir, output_format)


def _parse_pdf(file_path: Path, output_dir: Path, table_mode: str) -> str:
    from .pdf_converter import DoclingConverter
    from .pdf_markdown import MarkdownBuilder

    converter = DoclingConverter(table_mode=table_mode)
    parsed = converter.convert(str(file_path))

    asset_dir = output_dir / file_path.stem
    asset_dir.mkdir(parents=True, exist_ok=True)
    parsed.save_assets(asset_dir)

    builder = MarkdownBuilder(parsed, asset_dir)
    return builder.build({}, {}, {})


def _parse_office(file_path: Path, output_dir: Path, output_format: str) -> str:
    from .office_parser import OfficeParser
    from .office_types import OfficeParserConfig

    config = OfficeParserConfig(summarize=False, extract_attachments=True)
    ast = OfficeParser.parse_office(str(file_path), config)

    asset_dir = output_dir / file_path.stem
    image_dir = asset_dir / "pictures"
    image_dir.mkdir(parents=True, exist_ok=True)

    if output_format == "html":
        return ast.to_html(image_dir=str(image_dir))
    elif output_format == "text":
        return ast.to_text()
    else:
        return ast.to_markdown(image_dir=str(image_dir))
```

- [ ] **Step 3: Create `parser/run.py`** CLI entry point

```python
"""CLI entry point for document parsing."""

import argparse
import sys
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor


def main():
    parser = argparse.ArgumentParser(description="Parse documents (PDF, DOCX, PPTX, XLSX)")
    parser.add_argument("input", help="File or directory path")
    parser.add_argument("-o", "--output", default="output", help="Output directory")
    parser.add_argument("--workers", type=int, default=2, help="Parallel workers for batch")
    parser.add_argument("--table-mode", choices=["accurate", "fast"], default="accurate")
    parser.add_argument("--format", choices=["markdown", "html", "text"], default="markdown",
                        dest="output_format")
    args = parser.parse_args()

    input_path = Path(args.input)

    if input_path.is_file():
        from parser import parse
        result = parse(input_path, args.output, args.output_format, args.table_mode)
        out_file = Path(args.output) / input_path.stem / f"{input_path.stem}.md"
        out_file.parent.mkdir(parents=True, exist_ok=True)
        out_file.write_text(result, encoding="utf-8")
        print(f"Output: {out_file}")

    elif input_path.is_dir():
        from parser import SUPPORTED_EXTENSIONS, parse
        files = [f for f in input_path.iterdir()
                 if f.suffix.lower() in SUPPORTED_EXTENSIONS]
        if not files:
            print("No supported files found.")
            sys.exit(1)

        def process(f):
            try:
                result = parse(f, args.output, args.output_format, args.table_mode)
                out_file = Path(args.output) / f.stem / f"{f.stem}.md"
                out_file.parent.mkdir(parents=True, exist_ok=True)
                out_file.write_text(result, encoding="utf-8")
                return f.name, True
            except Exception as e:
                return f.name, str(e)

        with ProcessPoolExecutor(max_workers=args.workers) as executor:
            for name, status in executor.map(process, files):
                icon = "✓" if status is True else "✗"
                print(f"  {icon} {name}" + ("" if status is True else f" — {status}"))
    else:
        print(f"Not found: {input_path}")
        sys.exit(1)


if __name__ == "__main__":
    main()
```

- [ ] **Step 4: Commit**

```bash
git add parser/__init__.py parser/requirements.txt parser/run.py
git commit -m "feat(parser): add module structure with unified parse interface"
```

---

### Task 2: Port PDF Extraction — Converter and Utils

**Files:**
- Create: `parser/pdf_converter.py` (from `pdf_parser/converter.py`)
- Create: `parser/pdf_utils.py` (from `pdf_parser/utils.py`)

- [ ] **Step 1: Port `pdf_utils.py`**

Fetch from https://raw.githubusercontent.com/daekeun-ml/doc-parser/main/pdf_parser/utils.py and copy as-is. This file is pure utility (bounding box extraction, figure category mapping). No AWS dependency.

- [ ] **Step 2: Port `pdf_converter.py`**

Fetch from https://raw.githubusercontent.com/daekeun-ml/doc-parser/main/pdf_parser/converter.py and copy as-is. This file wraps Docling and produces `ParsedDocument`. No AWS dependency. Adjust import paths: `from pdf_parser.utils` → `from .pdf_utils`.

- [ ] **Step 3: Verify no AWS imports exist**

Run: `grep -r "boto3\|bedrock\|langchain" parser/pdf_converter.py parser/pdf_utils.py`
Expected: No matches.

- [ ] **Step 4: Commit**

```bash
git add parser/pdf_converter.py parser/pdf_utils.py
git commit -m "feat(parser): port PDF extraction from doc-parser (Docling-based)"
```

---

### Task 3: Port PDF Markdown Builder

**Files:**
- Create: `parser/pdf_markdown.py` (from `pdf_parser/markdown_builder.py`)

- [ ] **Step 1: Port `pdf_markdown.py`**

Fetch from https://raw.githubusercontent.com/daekeun-ml/doc-parser/main/pdf_parser/markdown_builder.py. Adjust import paths: `from pdf_parser.utils` → `from .pdf_utils`. This file accepts empty summary dicts `{}` — when summaries are empty, it outputs structural metadata only (image category, bbox, table markdown) without AI-generated text.

- [ ] **Step 2: Verify it works with empty summaries**

The `build(page_summaries, image_summaries, table_summaries)` method must accept three empty dicts `{}, {}, {}` and still produce valid markdown. Check that summary-dependent sections use `.get()` with defaults.

- [ ] **Step 3: Commit**

```bash
git add parser/pdf_markdown.py
git commit -m "feat(parser): port PDF markdown builder (works without AI summaries)"
```

---

## Chunk 2: Office Parser

### Task 4: Port Office Types

**Files:**
- Create: `parser/office_types.py` (from `office_parser/types.py`)

- [ ] **Step 1: Port `office_types.py`**

Fetch from https://raw.githubusercontent.com/daekeun-ml/doc-parser/main/office_parser/types.py. This file is pure data structures (dataclasses). No AWS dependency.

- [ ] **Step 2: Modify `OfficeParserConfig`**

Change the default for `summarize` from `True` to `False`. Remove `bedrock_model_id` and `bedrock_region` fields entirely — they are AWS-specific. Keep all other fields.

```python
# Before
@dataclass
class OfficeParserConfig:
    summarize: bool = True
    bedrock_model_id: str = "..."
    bedrock_region: str = "us-east-1"
    extract_attachments: bool = True
    ...

# After
@dataclass
class OfficeParserConfig:
    summarize: bool = False
    extract_attachments: bool = True
    ...
```

- [ ] **Step 3: Verify no AWS imports**

Run: `grep -r "boto3\|bedrock\|langchain" parser/office_types.py`
Expected: No matches.

- [ ] **Step 4: Commit**

```bash
git add parser/office_types.py
git commit -m "feat(parser): port office AST types (removed Bedrock config)"
```

---

### Task 5: Port Office Parser — Extraction Only

**Files:**
- Create: `parser/office_parser.py` (from `office_parser/parser.py`, ~42KB → ~25KB after stripping)

This is the largest and most critical task. The source file mixes extraction and summarization. We keep extraction, remove summarization.

- [ ] **Step 1: Fetch and strip `office_parser/parser.py`**

Fetch from https://raw.githubusercontent.com/daekeun-ml/doc-parser/main/office_parser/parser.py.

**Remove these methods entirely:**
- `_get_bedrock_client()` and the `_bedrock_client` cache
- `_summarize_image()`
- `_summarize_slide_image()`
- `_summarize_document()`
- `_summarize_text()`
- `_summarize_table()`
- Any `ThreadPoolExecutor` blocks that only dispatch summarization

**Remove these imports:**
- `boto3`
- `langchain` / `langchain_aws`
- `json` (only if used solely for Bedrock response parsing)

**Remove summarization blocks inside parse methods:**
In `_parse_docx()`, `_parse_pptx()`, `_parse_xlsx()` — find blocks guarded by `if config.summarize:` or `if self.config.summarize:` and remove them entirely. The extraction code around them stays.

- [ ] **Step 2: Fix import paths**

Change all `from office_parser.types` → `from .office_types`.

- [ ] **Step 3: Verify no AWS imports remain**

Run: `grep -r "boto3\|bedrock\|langchain\|_summarize" parser/office_parser.py`
Expected: No matches.

- [ ] **Step 4: Verify `summarize=False` path works**

The stripped parser should behave identically to the original with `summarize=False`. All extraction paths (text, tables, images, charts, formatting, merged cells, slide notes) must be preserved.

- [ ] **Step 5: Commit**

```bash
git add parser/office_parser.py
git commit -m "feat(parser): port office parser extraction (removed AWS summarization)"
```

---

### Task 6: Port Office Worker (Batch Processing)

**Files:**
- Create: `parser/office_worker.py` (from `office_parser/worker.py`)

- [ ] **Step 1: Port `office_worker.py`**

Fetch from https://raw.githubusercontent.com/daekeun-ml/doc-parser/main/office_parser/worker.py. Fix import paths: `from office_parser` → `from .office_parser` and `from .office_types`. This is a small (~2KB) multiprocessing helper.

- [ ] **Step 2: Commit**

```bash
git add parser/office_worker.py
git commit -m "feat(parser): port office batch worker"
```

---

## Chunk 3: Integration

### Task 7: Integration Tests

**Files:**
- Create: `tests/parser/test_parse_dispatch.py`

- [ ] **Step 1: Write dispatch and validation tests**

```python
"""Tests for parser auto-dispatch and validation."""
import pytest
from parser import parse, SUPPORTED_EXTENSIONS


def test_supported_extensions_complete():
    assert '.pdf' in SUPPORTED_EXTENSIONS
    assert '.docx' in SUPPORTED_EXTENSIONS
    assert '.pptx' in SUPPORTED_EXTENSIONS
    assert '.xlsx' in SUPPORTED_EXTENSIONS


def test_unsupported_extension_raises():
    with pytest.raises(ValueError, match="Unsupported file extension"):
        parse("test.xyz")


def test_missing_file_raises():
    with pytest.raises(FileNotFoundError):
        parse("nonexistent.pdf")
```

- [ ] **Step 2: Run tests**

Run: `python -m pytest tests/parser/test_parse_dispatch.py -v`
Expected: All pass.

- [ ] **Step 3: Commit**

```bash
git add tests/parser/test_parse_dispatch.py
git commit -m "test(parser): add dispatch and validation tests"
```

---

### Task 8: Harness Integration — Update Skills and Architecture

**Files:**
- Modify: `skills/design.md`
- Modify: `skills/write.md`
- Modify: `ARCHITECTURE.md`

- [ ] **Step 1: Update `skills/design.md`**

In step 2 (Accept input), add document parsing guidance:

```markdown
When the user provides an RFP document (PDF, DOCX, PPTX, XLSX):
- Parse the document using `parser/` module: `from parser import parse`
- Extract text, tables, and images into structured markdown
- Use extracted content to inform strategy and TOC generation
- Store raw parsed output in `assets/rfp/` for Researcher reference
```

- [ ] **Step 2: Update `skills/write.md`**

In the Researcher directive section, add:

```markdown
When source documents (RFP, prior proposals, reference materials) are provided:
- Parse using `parser/` module for structured extraction
- Researcher uses parsed output as primary source material
- Extracted tables and images are available in `assets/` directory
```

- [ ] **Step 3: Update `ARCHITECTURE.md`**

Add `parser/` to the file map:

```markdown
| **`parser/`** | |
| `parser/__init__.py` | Unified `parse()` entry point — auto-dispatches PDF vs Office |
| `parser/pdf_converter.py` | Docling-based PDF extraction (text, tables, images) |
| `parser/pdf_utils.py` | Bounding box helpers, figure category mapping |
| `parser/pdf_markdown.py` | PDF content → Markdown assembly |
| `parser/office_parser.py` | DOCX/PPTX/XLSX/RTF extraction via AST |
| `parser/office_types.py` | Office AST data structures |
| `parser/office_worker.py` | Batch processing worker |
| `parser/run.py` | CLI entry point for standalone parsing |
| `parser/requirements.txt` | Python dependencies (no AWS) |
```

- [ ] **Step 4: Commit**

```bash
git add skills/design.md skills/write.md ARCHITECTURE.md
git commit -m "feat(parser): integrate parser with harness skills and architecture"
```

---

### Task 9: Validation — Verify Harness Integrity

**Files:**
- No new files

- [ ] **Step 1: Run harness validation**

Run: `bash scripts/verify-harness.sh`
Expected: All checks pass (73/73 or more).

- [ ] **Step 2: Verify no AWS dependency in parser/**

Run: `grep -r "boto3\|bedrock\|langchain\|aws" parser/`
Expected: No matches (comments referencing the source repo are acceptable).

- [ ] **Step 3: Final commit if any fixes needed**

---

## Summary

| Metric | Value |
|--------|-------|
| New files | 10 (8 parser + 1 test + 1 requirements) |
| Modified files | 3 (design.md, write.md, ARCHITECTURE.md) |
| Deleted dependencies | boto3, langchain, strands-agents |
| Kept capabilities | PDF/DOCX/PPTX/XLSX extraction, tables, images, batch processing |
| Removed capabilities | AI summarization (handled by Harness agents) |
| Performance preserved | ProcessPoolExecutor batch, Docling parallel, unchanged extraction |
