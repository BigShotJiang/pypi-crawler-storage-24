# Harness Plugin Packaging Implementation Plan

> **For agentic workers:** REQUIRED: Use superpowers:subagent-driven-development (if subagents available) or superpowers:executing-plans to implement this plan. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Package the Proposal Harness as a Claude Code plugin (`ph`) with dependency detection and Codex compatibility.

**Architecture:** Restructure skills from flat files (`skills/design.md`) to plugin folder format (`skills/design/SKILL.md`), add plugin manifest, dependency detection script, setup skill, and update all references across CLAUDE.md, AGENTS.md, ARCHITECTURE.md, and proposal-guide-format.md.

**Tech Stack:** Bash (check-deps.sh), Markdown (skills, entrypoints), JSON (plugin.json)

**Spec:** `docs/superpowers/specs/2026-03-15-harness-plugin-packaging-design.md`

---

## File Structure

```
New files:
  .claude-plugin/plugin.json           — Plugin manifest
  skills/setup/SKILL.md                — Environment check skill
  scripts/check-deps.sh                — Dependency detection

Restructured (move + content add):
  skills/design.md    → skills/design/SKILL.md
  skills/write.md     → skills/write/SKILL.md
  skills/diagnose.md  → skills/diagnose/SKILL.md
  skills/verify.md    → skills/verify/SKILL.md
  skills/status.md    → skills/status/SKILL.md
  skills/output.md    → skills/output/SKILL.md

Modified (content only):
  CLAUDE.md
  AGENTS.md
  ARCHITECTURE.md
  reference/proposal-guide-format.md
  scripts/verify-harness.sh
  scripts/validate-harness-contracts.js
```

---

## Chunk 1: Foundation

### Task 1: Create plugin manifest and check-deps script

**Files:**
- Create: `.claude-plugin/plugin.json`
- Create: `scripts/check-deps.sh`

- [ ] **Step 1: Create `.claude-plugin/plugin.json`**

```json
{
  "name": "ph",
  "version": "1.0.0",
  "description": "Proposal Harness — 금융 IT 제안서 멀티에이전트 작성 시스템",
  "author": {
    "name": "hwai"
  }
}
```

- [ ] **Step 2: Create `scripts/check-deps.sh`**

```bash
#!/bin/bash
# Dependency detection for Proposal Harness
# Outputs JSON with required/optional tool availability

check() {
  if "$@" >/dev/null 2>&1; then echo "true"; else echo "false"; fi
}

GIT=$(check command -v git)
PARSER=$(check pip show harness-parser)
PANDOC=$(check command -v pandoc)
NODE=$(check command -v node)

cat <<EOF
{
  "required": {
    "git": $GIT
  },
  "optional": {
    "harness-parser": $PARSER,
    "pandoc": $PANDOC,
    "node": $NODE
  }
}
EOF
```

- [ ] **Step 3: Make executable and test**

Run: `chmod +x scripts/check-deps.sh && bash scripts/check-deps.sh`
Expected: Valid JSON with true/false values.

- [ ] **Step 4: Commit**

```bash
git add .claude-plugin/plugin.json scripts/check-deps.sh
git commit -m "feat(plugin): add plugin manifest and dependency detection script"
```

---

### Task 2: Restructure skills to folder format

**Files:**
- Move: all 6 `skills/*.md` → `skills/*/SKILL.md`

- [ ] **Step 1: Create skill directories and move files**

```bash
for skill in design write diagnose verify status output; do
  mkdir -p "skills/$skill"
  git mv "skills/$skill.md" "skills/$skill/SKILL.md"
done
```

- [ ] **Step 2: Verify structure**

Run: `ls skills/*/SKILL.md`
Expected:
```
skills/design/SKILL.md
skills/diagnose/SKILL.md
skills/output/SKILL.md
skills/status/SKILL.md
skills/verify/SKILL.md
skills/write/SKILL.md
```

- [ ] **Step 3: Verify no orphan .md files left**

Run: `ls skills/*.md 2>/dev/null`
Expected: No output (all moved).

- [ ] **Step 4: Commit**

```bash
git add -A skills/
git commit -m "refactor(plugin): restructure skills to folder format for plugin packaging"
```

---

### Task 3: Create setup skill

**Files:**
- Create: `skills/setup/SKILL.md`

- [ ] **Step 1: Create `skills/setup/SKILL.md`**

```markdown
---
name: setup
description: Check development environment and guide installation of optional tools
---

# Environment Setup Check

Run `bash scripts/check-deps.sh` and present the results.

## Output Format

Present results as a checklist with installation instructions for missing tools:

- ✅ / ❌ for each tool
- For missing tools, show the install command
- Group by required vs optional
- End with a reassurance that most features work without optional tools

## Example Output

```
환경 점검 결과:

[필수]
✅ git — 설치됨

[선택]
❌ harness-parser — PPTX/DOCX/XLSX 파싱
   설치: pip install harness-parser
❌ pandoc — PDF 출력
   설치: brew install pandoc (macOS) / apt install pandoc (Linux)
✅ node — 고급 계약 검증

필요한 것만 설치하시면 됩니다.
harness-parser 없이도 PDF RFP는 바로 사용 가능합니다.
```

## After Check

Show the Proposal Guide footer with:
```
Recommended: /ph:design — 새 제안서 프로젝트를 시작합니다
```
```

- [ ] **Step 2: Commit**

```bash
git add skills/setup/SKILL.md
git commit -m "feat(plugin): add /ph:setup environment check skill"
```

---

## Chunk 2: Dependency Check Sections in Skills

### Task 4: Add dependency check to design, write, diagnose skills

**Files:**
- Modify: `skills/design/SKILL.md`
- Modify: `skills/write/SKILL.md`
- Modify: `skills/diagnose/SKILL.md`

- [ ] **Step 1: Add dependency check section to `skills/design/SKILL.md`**

Add after the existing prerequisites section (before step 1 of the workflow):

```markdown
## Dependency Check

When the user provides a document file (PPTX, DOCX, XLSX) as RFP input:
1. Run `bash scripts/check-deps.sh`
2. If `harness-parser` is `false`, inform the user:
   "PPTX/DOCX 파일을 읽으려면 parser 설치가 필요합니다.
    터미널에서 실행: pip install harness-parser
    설치 후 다시 파일을 제공해주세요.
    PDF 형식의 RFP라면 바로 진행 가능합니다."
3. If `true`, parse the document using `from parser import parse` and proceed.
```

- [ ] **Step 2: Add same section to `skills/write/SKILL.md`**

Add after prerequisites, adapted for write context:

```markdown
## Dependency Check

When source documents (RFP, prior proposals, reference materials) are PPTX, DOCX, or XLSX:
1. Run `bash scripts/check-deps.sh`
2. If `harness-parser` is `false`, inform the user:
   "PPTX/DOCX 파일을 읽으려면 parser 설치가 필요합니다.
    터미널에서 실행: pip install harness-parser
    설치 후 다시 시도해주세요."
3. If `true`, parse and provide to Researcher as structured input.
```

- [ ] **Step 3: Add same section to `skills/diagnose/SKILL.md`**

Add in Path A (existing proposal uploaded) section:

```markdown
## Dependency Check

When the user uploads an existing proposal as PPTX, DOCX, or XLSX:
1. Run `bash scripts/check-deps.sh`
2. If `harness-parser` is `false`, inform the user:
   "PPTX/DOCX 파일을 읽으려면 parser 설치가 필요합니다.
    터미널에서 실행: pip install harness-parser
    설치 후 다시 파일을 제공해주세요.
    PDF 형식이라면 바로 진단 가능합니다."
3. If `true`, parse and create SSOT files from extracted content.
```

- [ ] **Step 4: Commit**

```bash
git add skills/design/SKILL.md skills/write/SKILL.md skills/diagnose/SKILL.md
git commit -m "feat(plugin): add dependency detection to design, write, diagnose skills"
```

---

### Task 5: Add dependency check to output and verify skills

**Files:**
- Modify: `skills/output/SKILL.md`
- Modify: `skills/verify/SKILL.md`

- [ ] **Step 1: Add dependency check to `skills/output/SKILL.md`**

Add before the Assembly Engine section:

```markdown
## Dependency Check

When the user requests output in a specific format:
1. Run `bash scripts/check-deps.sh`
2. **PDF requested** and `pandoc` is `false`:
   "PDF 출력을 위해 pandoc이 필요합니다.
    설치: brew install pandoc (macOS) / apt install pandoc (Linux)
    Markdown 출력은 바로 가능합니다."
3. **PPTX requested** and `harness-parser` is `false`:
   "PPTX 출력을 위해 harness-parser가 필요합니다.
    설치: pip install harness-parser
    Markdown 출력은 바로 가능합니다."
4. If tools available, proceed with requested format.
```

- [ ] **Step 2: Add dependency check + Node.js graceful fallback to `skills/verify/SKILL.md`**

Add before the verification workflow:

```markdown
## Dependency Check

Before running cross-SSOT verification:
1. Run `bash scripts/check-deps.sh`
2. If `node` is `false`:
   - Skip `scripts/validate-harness-contracts.js` (enhanced contract validation)
   - Continue with all other verification checks
   - Note in the report: "고급 계약 검증이 생략되었습니다 (Node.js 미설치). 핵심 검증은 정상 수행됩니다."
3. If `node` is `true`, run full verification including contract validation.
```

- [ ] **Step 3: Commit**

```bash
git add skills/output/SKILL.md skills/verify/SKILL.md
git commit -m "feat(plugin): add dependency detection to output and verify skills"
```

---

## Chunk 3: Update References

### Task 6: Update Proposal Guide format

**Files:**
- Modify: `reference/proposal-guide-format.md`

- [ ] **Step 1: Update the Format section**

Change the Recommended line from:
```
Recommended: /command copy-pasteable example input
```
To:
```
Recommended: /ph:command args — 다음에 할 일 설명
```

- [ ] **Step 2: Update the Recommendation Logic table**

Add `/ph:` prefix and ` — explanation` to all commands:

| Priority | Current State | Recommended |
|----------|---|---|
| 1 | No project | `/ph:design — 새 제안서 프로젝트를 시작합니다` |
| 2 | Design complete, all SSOTs empty | `/ph:write <section> — 첫 번째 섹션 작성을 시작합니다` |
| 3 | Some sections in draft | `/ph:write <section> — 미완성 섹션을 이어서 작성합니다` |
| 4 | 2+ confirmed | `/ph:verify — 교차 검증으로 일관성을 확인합니다` |
| 5 | All confirmed | `"최종 출력을 요청해주세요" — 예: "PDF로 출력해줘"` |
| 6-9 | (natural language entries unchanged) | |

- [ ] **Step 3: Add Platform Divergence section at the end**

```markdown
## Platform Divergence

The Recommended line is the only place where Claude Code and Codex responses differ:

**Claude Code:**
```
Recommended: /ph:write sa-hsm-001 — HSM 솔루션 초안을 이어서 작성합니다
```

**Codex:**
```
Recommended: "HSM 솔루션 초안 작성을 이어서 진행해주세요" (sa-hsm-001)
```

When rendering Proposal Guide, detect the current platform:
- If CLAUDE.md is the entry point → use `/ph:` command format
- If AGENTS.md is the entry point → use natural language format
```

- [ ] **Step 4: Add rule about explanation being mandatory**

In the Rules section, add:
```markdown
- Recommended line MUST include both the command and a human-readable explanation separated by ` — `.
```

- [ ] **Step 5: Commit**

```bash
git add reference/proposal-guide-format.md
git commit -m "feat(plugin): update Proposal Guide with /ph: prefix and explanations"
```

---

### Task 7: Update CLAUDE.md

**Files:**
- Modify: `CLAUDE.md`

- [ ] **Step 1: Update Commands table**

Change:
```markdown
| `/design` | New proposal strategy + TOC generation | `skills/design.md` |
| `/write <section>` | Work on a section (draft/revise auto-detected) | `skills/write.md` |
| `/diagnose` | Full quality diagnosis across all SSOTs | `skills/diagnose.md` |
| `/verify` | Cross-SSOT consistency and compliance check | `skills/verify.md` |
| `/status` | Progress dashboard for all sections | `skills/status.md` |
```

To:
```markdown
| `/ph:design` | New proposal strategy + TOC generation | `skills/design/SKILL.md` |
| `/ph:write <section>` | Work on a section (draft/revise auto-detected) | `skills/write/SKILL.md` |
| `/ph:diagnose` | Full quality diagnosis across all SSOTs | `skills/diagnose/SKILL.md` |
| `/ph:verify` | Cross-SSOT consistency and compliance check | `skills/verify/SKILL.md` |
| `/ph:status` | Progress dashboard for all sections | `skills/status/SKILL.md` |
| `/ph:setup` | Environment check and guided installation | `skills/setup/SKILL.md` |
```

- [ ] **Step 2: Update Natural Language Routing table**

Add `/ph:` prefix to all routed commands:

```markdown
| "RFP 받았는데 어디서부터?" | `/ph:design` | |
| "제안서 만들어야 해" | `/ph:design` | |
| "이행계획 어떻게 할지 고민 중이야" | `/ph:write impl` | auto-enters explore |
...
```

- [ ] **Step 3: Update output reference**

Change `See \`skills/output.md\`.` to `See \`skills/output/SKILL.md\`.`

- [ ] **Step 4: Update Quick Start**

```markdown
1. Run `/ph:setup` to check your environment
2. Run `/ph:design` to create a new proposal strategy and TOC
3. Run `/ph:write <section>` to begin drafting sections
4. Run `/ph:status` to check progress across all sections
5. Run `/ph:diagnose` to find quality issues
6. Run `/ph:verify` for final consistency checks before output
```

- [ ] **Step 5: Update Project Structure**

Update `skills/` section to show folder structure:
```markdown
skills/                    # Command implementations (plugin skill format)
  design/SKILL.md
  write/SKILL.md
  diagnose/SKILL.md
  verify/SKILL.md
  status/SKILL.md
  output/SKILL.md
  setup/SKILL.md
```

- [ ] **Step 6: Update Key Rules #7**

Change: `During \`/design\` and exploratory \`/write\``
To: `During \`/ph:design\` and exploratory \`/ph:write\``

- [ ] **Step 7: Commit**

```bash
git add CLAUDE.md
git commit -m "feat(plugin): update CLAUDE.md with /ph: prefix and folder skill paths"
```

---

### Task 8: Update AGENTS.md

**Files:**
- Modify: `AGENTS.md`

- [ ] **Step 1: Update Commands table with new skill paths**

Same structure as CLAUDE.md but keep command names without `/ph:` prefix (Codex uses natural language). Update skill file paths to folder format:
```markdown
| `design` | ... | `skills/design/SKILL.md` |
| `write <section>` | ... | `skills/write/SKILL.md` |
...
| `setup` | Environment check and guided installation | `skills/setup/SKILL.md` |
```

- [ ] **Step 2: Add dependency detection note**

Add after the Commands table:
```markdown
When a skill requires an optional tool that is not installed, run
`bash scripts/check-deps.sh` and guide the user through installation.
See individual skill files for specific detection logic.
```

- [ ] **Step 3: Update Natural Language Routing table**

Routing targets stay as skill names (no `/ph:` prefix for Codex).

- [ ] **Step 4: Update Project Structure section**

Same folder structure as CLAUDE.md.

- [ ] **Step 5: Update Quick Start section**

Use natural language instead of `/ph:` commands:
```markdown
1. Say "환경 점검해줘" to check your setup
2. Say "제안서 만들어야 해" or describe your RFP to start
3. Describe which section to work on
4. Ask "진행 상황 알려줘" for status
5. Ask "전체적으로 봐줘" for diagnosis
6. Ask "교차 검증해줘" for final checks
```

- [ ] **Step 6: Commit**

```bash
git add AGENTS.md
git commit -m "feat(plugin): update AGENTS.md with folder skill paths and dep detection"
```

---

### Task 9: Update ARCHITECTURE.md and validation scripts

**Files:**
- Modify: `ARCHITECTURE.md`
- Modify: `scripts/verify-harness.sh`
- Modify: `scripts/validate-harness-contracts.js`

- [ ] **Step 1: Update `ARCHITECTURE.md` file map**

Change all `skills/*.md` references to `skills/*/SKILL.md` format. Add `.claude-plugin/` and `scripts/check-deps.sh` entries.

- [ ] **Step 2: Update `scripts/verify-harness.sh`**

Change all skill file checks from:
```bash
check_file "skills/design.md"
```
To:
```bash
check_file "skills/design/SKILL.md"
```

Add checks for:
```bash
check_file ".claude-plugin/plugin.json"
check_file "skills/setup/SKILL.md"
check_file "scripts/check-deps.sh"
```

- [ ] **Step 3: Update `scripts/validate-harness-contracts.js`**

Change all `read('skills/design.md')` to `read('skills/design/SKILL.md')` etc.

- [ ] **Step 4: Run validation**

Run: `bash scripts/verify-harness.sh`
Expected: All checks pass (count will increase with new files).

- [ ] **Step 5: Commit**

```bash
git add ARCHITECTURE.md scripts/verify-harness.sh scripts/validate-harness-contracts.js
git commit -m "feat(plugin): update architecture and validation for plugin structure"
```

---

## Chunk 4: Final Verification

### Task 10: End-to-end verification

**Files:** None (verification only)

- [ ] **Step 1: Verify plugin structure**

Run: `ls .claude-plugin/plugin.json skills/*/SKILL.md scripts/check-deps.sh`
Expected: All 9 files listed (plugin.json + 7 skills + check-deps.sh).

- [ ] **Step 2: Run dependency detection**

Run: `bash scripts/check-deps.sh`
Expected: Valid JSON output.

- [ ] **Step 3: Run harness validation**

Run: `bash scripts/verify-harness.sh`
Expected: All checks pass.

- [ ] **Step 4: Verify no stale references**

Run: `grep -r "skills/design\.md\|skills/write\.md\|skills/diagnose\.md\|skills/verify\.md\|skills/status\.md\|skills/output\.md" CLAUDE.md AGENTS.md ARCHITECTURE.md reference/ scripts/`
Expected: No matches (all updated to folder format).

- [ ] **Step 5: Verify /ph: prefix in entrypoints**

Run: `grep "/ph:" CLAUDE.md | head -10`
Expected: All command references use `/ph:` prefix.

- [ ] **Step 6: Verify no bare /design or /write in Proposal Guide**

Run: `grep "Recommended:" reference/proposal-guide-format.md`
Expected: All use `/ph:` prefix with ` — ` explanation.
