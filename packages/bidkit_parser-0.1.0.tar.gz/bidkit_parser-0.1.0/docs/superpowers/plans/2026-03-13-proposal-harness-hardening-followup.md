# Proposal Harness Hardening Follow-Up Plan

> **Purpose:** Record the minimum follow-up work required to close the remaining contract gaps after the first usability and validation pass. This document is intentionally narrow: fix the important gaps without expanding into heavy PDCA/plugin infrastructure.

**Status:** Done  
**Date:** 2026-03-13  
**Related spec:** `docs/superpowers/specs/2026-03-13-proposal-harness-design.md`  
**Related plan:** `docs/superpowers/plans/2026-03-13-proposal-harness.md`

---

## Goal

Stabilize the current harness so that:

1. user-facing status text does not become stale,
2. output gating remains safe for both new and existing projects,
3. validation works gracefully in environments without Node.js.

---

## Non-Goals

- Do **not** add full PDCA orchestration.
- Do **not** add complex hook/event systems.
- Do **not** add plugin marketplace packaging.
- Do **not** redesign the current role structure.

---

## Current Gaps

### Gap 1 — Runtime State Is Only Half-Specified

`runtime/session-state.json` exists as a template, and some skills read it, but
the harness does not yet fully define when it must be updated or when it should
be ignored.

**Risk:** `/status` can show a stale `Current:` label.

### Gap 2 — `required_for_output` Needs Safe Defaulting

`skills/output.md` now expects `required_for_output`, but older or manually
created `meta/outline.yaml` files may not include it.

**Risk:** important incomplete sections may be excluded from warnings.

### Gap 3 — Contract Validation Assumes Node.js

`scripts/verify-harness.sh` now invokes `scripts/validate-harness-contracts.js`
unconditionally.

**Risk:** validation fails in otherwise-usable environments that do not have
Node installed.

---

## Decisions To Preserve

These decisions are already agreed and should remain unchanged:

- Keep the harness lightweight.
- Keep user-facing responses situation-first.
- Keep `/design` and exploratory `/write` in one-question-at-a-time mode.
- Keep `runtime/session-state.json` as a lightweight helper, not a large runtime system.
- Keep output gating conservative rather than permissive.

---

## Follow-Up Approach

### 1. Treat Runtime State As An Optional Hint

**Decision:** `runtime/session-state.json` should be used only as a hint. If it
is missing, stale, or inconsistent with current SSOT state, the harness should
derive the current situation from SSOT metadata instead.

**Implementation tasks**

- [x] Update `skills/status.md` to define runtime fallback explicitly.
- [x] Update `skills/write.md` to state that runtime state is advisory only.
- [x] Update `skills/design.md` to initialize runtime state with the first user-facing label.
- [x] Update `ARCHITECTURE.md` to describe runtime state as optional helper state.
- [x] Add validator checks that the docs use the words `optional` or `fallback` around runtime state handling.

**Expected outcome**

- `Current:` becomes reliable even if runtime state is absent or outdated.

### 2. Make Output Gating Default To Safe Behavior

**Decision:** If `required_for_output` is absent in `meta/outline.yaml`, treat
that section as `true`.

**Implementation tasks**

- [x] Update `skills/output.md` to say: missing `required_for_output` defaults to `true`.
- [x] Update `templates/init/outline.yaml` to document that new projects should always set the field explicitly.
- [x] Update `scripts/validate-harness-contracts.js` to verify that this fallback rule is documented.
- [x] Add a short compatibility note in `ARCHITECTURE.md` or `skills/design.md` for older projects.

**Expected outcome**

- Existing projects remain safe without migration.

### 3. Make Contract Validation Graceful Without Node.js

**Decision:** `scripts/verify-harness.sh` should run contract validation only if
`node` is available. If not, it should print a warning and continue with the
shell-based checks.

**Implementation tasks**

- [x] Add `command -v node` guard to `scripts/verify-harness.sh`.
- [x] Print a clear warning when contract validation is skipped.
- [x] Count the skip as informational, not as a hard failure.
- [x] Add a short note in `ARCHITECTURE.md` that enhanced contract validation uses Node when available.

**Expected outcome**

- Validation remains usable in lighter environments.

---

## Recommended Order

1. **Output gating fallback**
   Reason: this is the highest safety issue.
2. **Node graceful fallback**
   Reason: this prevents avoidable validation failures.
3. **Runtime-state fallback wording**
   Reason: this improves correctness and reduces stale status risk.

---

## Acceptance Criteria

- [x] `skills/output.md` explicitly states that missing `required_for_output` means `true`.
- [x] `scripts/verify-harness.sh` no longer hard-fails solely because Node is unavailable.
- [x] `skills/status.md` explicitly says runtime state is optional and falls back to SSOT-derived status.
- [x] `scripts/validate-harness-contracts.js` checks the revised contract wording.
- [x] `bash scripts/verify-harness.sh` still passes after the follow-up changes.

---

## Out Of Scope For This Follow-Up

Leave these for later unless a real usage problem appears:

- automatic runtime state writers,
- full eval runner implementation,
- output rendering engines,
- advanced cross-project migration tooling,
- deeper orchestration or subagent automation.
