# Proposal Harness - Design Specification

> Multi-agent system for financial IT proposal writing with collaborative human-AI workflow.

**Date**: 2026-03-13
**Status**: Draft
**Author**: hwaa + Claude/Codex

---

## 1. Overview

### 1.1 Problem

Financial IT proposals (e.g., SI/SM bids for Korean banks) require 100+ page technical documents covering architecture, product specs, implementation plans, cost estimation, and regulatory compliance. Currently, proposal PMs with limited technical backgrounds must coordinate across multiple domains, resulting in inconsistent quality and high time pressure.

### 1.2 Solution

A multi-agent system where specialized architect teams collaboratively write proposal sections through structured dialogue with the user. Each section is an independent SSOT (Single Source of Truth) document that goes through a generate-verify-revise loop before assembly into a final proposal.

### 1.3 Key Principles

- **User is the decision-maker**: Agents recommend, user approves/rejects/redirects.
- **Section-level SSOT**: Each section is an independent document with its own state, version, and verification criteria. The final proposal is an assembly of confirmed SSOTs.
- **Always-parallel background work**: Researchers, writers, and critics work in parallel. Only user-facing interactions are sequential.
- **Partial entry**: Users can start at any section, any phase. The system adapts.

### 1.4 Target User

Proposal PM / Business Manager with limited technical background. The system handles technical judgment; the user provides business context and decisions.

---

## 2. System Topology

```
+--------------------------------------------------------------+
|                                                              |
|                     Overseer Agent (EA)                      |
|          Strategy / Cross-SSOT consistency / Final approval  |
|                                                              |
+--------+-----------+-----------+-----------+-----------------+
         |           |           |           |
    +----v----+ +----v----+ +---v-----+ +---v-----+
    | BA Team | | DA Team | | TA Team | | SA Team |  ...N teams
    | 4 agents| | 4 agents| | 4 agents| | 4 agents|
    |         | |         | |         | |         |
    | SSOT    | | SSOT    | | SSOT    | | SSOT    |
    | SSOT    | | SSOT    | | SSOT    | | SSOT    |
    | ...     | | ...     | | ...     | | ...     |
    +---------+ +---------+ +---------+ +---------+
```

### 2.1 Agent Roles

| Agent | Role | Responsible SSOTs (examples) |
|-------|------|----------------------------|
| **EA (Overseer)** | Overall strategy, cross-SSOT consistency, final approval | Proposal TOC, strategy/overview (also writes directly) |
| **BA Team** | Business/requirements analysis | Proposal overview, requirements analysis, business process design |
| **DA Team** | Data architecture/migration | Data model, migration strategy, data security |
| **TA Team** | Technical architecture/infrastructure | System architecture, implementation plan, contingency plan, cost estimation |
| **SA Team** | Solutions/products | HSM, DID, blockchain, each product spec/reference/license |

### 2.2 Team Composition (4 agents per SSOT team)

| Role | Responsibility |
|------|---------------|
| **Writer** | Drafts content, structures tables, creates Mermaid diagrams |
| **Researcher** | Gathers product specs, reference cases, certifications, pricing, regulatory data |
| **Critic** | Independently verifies against RFP requirements, checks data accuracy, finds gaps, cross-checks with other SSOTs |
| **Team Lead** | Orchestrates workflow, makes pass/revise decisions, interfaces with user, reports to Overseer |

---

## 3. SSOT Document Structure

### 3.1 Metadata

```yaml
---
id: sa-hsm-001
title: "Products - HSM"
team: SA
status: existing | ideation | draft | verifying | verified | tentative | reviewing | revision | confirmed
version: 3
parent: sa-equipment              # parent SSOT if split
dependencies:                      # SSOTs this one references
  - ta-infra-001                  # TA infra design -> HSM installation location
  - ba-requirements-001           # BA requirements -> HSM adoption rationale
affects:                           # SSOTs impacted when this changes
  - ta-cost-001                   # cost estimation
  - ta-implementation-001         # implementation plan
verification:
  checklist_passed: 8/10
  critic_issues: ["Certificate expiry date needs confirmation"]
  user_approved: true
  overseer_approved: false
  overseer_directive: "Server naming inconsistent with TA infra SSOT - unify"
history:
  - v1: "Initial draft (2026-03-13)"
  - v2: "Critic feedback applied - certificates added"
  - v3: "Overseer directive applied - server names unified"
ideation:                          # present only during ideation phase
  notes: "ideation/ta-implementation-notes.md"
  direction: "Staged rollout + Rollback plan"
  alternatives_considered:
    - "Big bang - rejected due to high risk"
skills_used:
  - type: mermaid
    artifacts: ["system-topology.mmd"]
  - type: table
    artifacts: ["hsm-spec-comparison.md"]
  - type: fp_estimation
    artifacts: ["fp-calculation.md"]
glossary_terms:
  - term: "HSM"
    definition: "Hardware Security Module"
    standard_name: "Luna Network HSM S750"
diagrams:
  - type: flowchart
    id: system-topology
    description: "System architecture diagram"
---
```

### 3.2 Body Structure

```markdown
# [Section Title]

## Summary
> 1-2 sentence summary of this section's key point.

## Content
(Actual proposal content - tables, specs, descriptions, diagrams)

## Supporting Evidence
(References, sources, data collected by Researcher)

## Verification Log
| Round | Critic Issue | Action | Status |
|-------|-------------|--------|--------|
| 1st   | RFP required TPS not met | Changed to 2x S750 for production | Resolved |

## Overseer Review Log
| Round | Directive | Action | Status |
|-------|----------|--------|--------|
| 1st   | Server name mismatch with TA | Unified to 'HSM-WAS-01' | Resolved |
```

### 3.3 State Transitions

```
existing --+
            |
            v
ideation -> draft -> verifying -> verified -> tentative -> reviewing -> confirmed
                        |            |                        |
                        +-- fail --> draft (revise)           |
                                                             +-- directive --> revision -> verifying
```

- `existing`: Loaded from a prior proposal via `/diagnose`. Enters session loop at step (5) for initial verification.
- `ideation` -> `draft`: Team begins writing after direction is established.
- `verifying` -> `verified`: Critic passes all checks at step (7).
- `verified` -> `tentative`: User approves at step (8).
- `tentative` -> `reviewing`: Queued for Overseer cross-review at step (10).
- `reviewing` -> `confirmed`: Overseer passes.
- `reviewing` -> `revision`: Overseer issues directive, returns to step (6).

### 3.4 Auto-Split Rule

When an SSOT's content exceeds ~30 pages or contains 3+ independently verifiable sub-items, the Team Lead proposes splitting to the user. On approval, child SSOTs are created with `parent` links maintained.

---

## 4. Session Loop

The core workflow for producing a single SSOT. Every SSOT goes through this loop.

```
User: "Write the HSM product section"
|
v
+-- Team Lead --------------------------------------------------+
| (1) Context gathering                                         |
|     - Check SSOT current state (empty? existing draft?)       |
|     - Check dependencies (other SSOTs to reference)           |
|     - Ask user 1-2 questions with recommended options         |
|                                                               |
| (2) Direct Researcher                                         |
|     "Gather HSM specs, competitor cases, cert requirements"   |
+---------------------------------------------------------------+
         |
    +----v--------+
    | Researcher   |
    | (3) Gather   |
    |  - Specs     |
    |  - Cases     |
    |  - Certs     |
    |  - Pricing   |
    +----+--------+
         | research results
    +----v--------+
    | Writer       |
    | (4) Draft    |
    |  - Content   |
    |  - Tables    |
    |  - Mermaid   |
    +----+--------+
         | draft
    +----v--------+
    | Critic       |                                      +--+
    | (5) Verify   |<-------------------------------------+  |
    |  - RFP met?  |                                      |  |
    |  - Data ok?  |                                      |  |
    |  - Gaps?     |                                      |  |
    |  - Cross-ref?|                                      |  |
    +----+--------+                                       |  |
         | issue list                                     |  |
    +----v--------------+                                 |  |
    | Writer + Researcher|                                |  |
    | (6) Revise         +--- revision done ---> (7) Re-verify
    | (additional research if needed)                     |
    +-------------------+                                 |
         |                                                |
         | verification passed                            |
         v                                                |
+-- Team Lead ----------------------------------------------+
| (8) Present to user                                       |
|     - Show summary                                        |
|     - Highlight key decisions                             |
|     - Present recommendation + alternatives               |
|                                                           |
|     User response:                                        |
|     -> Approve ---> (9) Tentative confirmation            |
|     -> Request changes ---> back to (6)                   |
|     -> Change direction ---> back to (4)                  |
+-----------------------------------------------------------+
         | tentative confirmation
         v
+-- Overseer Agent (EA) ------------------------------------+
| (10) Cross-review                                         |
|      - Consistency with other SSOTs (terms, numbers, names)|
|      - Alignment with overall proposal strategy           |
|      - Missing RFP requirements                           |
|      - Regulatory compliance                              |
|                                                           |
|      Verdict:                                             |
|      -> Pass ---> SSOT status = "confirmed"               |
|      -> Needs revision ---> Issue directive               |
|         (specific changes + rationale)                    |
|         ---> back to (6)                                  |
+-----------------------------------------------------------+
```

### 4.1 Parallelism Model

Background work runs in parallel across teams. Only user-facing interactions are sequential.

```
Timeline --->

BA Researcher  ========
BA Writer               ============
BA Critic                            ====
BA User Confirm                          ======    <- user 1st

TA Researcher  ============                        <- parallel
TA Writer                  ==========
TA Critic                            ======
TA User Confirm                                ======  <- user 2nd

SA Researcher  ======                              <- parallel
SA Writer            ================
SA Critic                            ====
SA User Confirm                                      ======  <- user 3rd
```

User confirmations are queued sequentially; everything else runs in parallel.

---

## 5. Usage Scenarios

### 5.1 Scenario Overview (4 core scenarios)

| Scenario | What | Led by | Entry point |
|----------|------|--------|-------------|
| **Design** | Proposal strategy + TOC + direction from scratch | Overseer (EA) | Context dialogue |
| **Explore** | Section-level ideation (brainstorm direction) | Team Lead | Exploratory dialogue |
| **Write** | Section create/edit/re-edit (state auto-detected) | Team Lead | Session loop |
| **Diagnose** | Full proposal quality diagnosis + improvement | Overseer (EA) | Analysis + sequential improvement |

### 5.2 Scenario: Design (most common entry point)

User provides rough context ("I need a proposal for Woori Bank blockchain project") with optional RFP.

1. **Context dialogue**: Overseer asks about project scope, competitors, strengths
2. **Strategy exploration**: Present 2-3 strategic options with recommendations
3. **TOC co-design**: Propose proposal structure, user adjusts
4. **Section direction**: Quickly align on each section's direction (not deep)
5. **Proposal brief**: Generate SSOT structure (all in `ideation` state), assign teams, agree on priority order
6. **Transition**: Teams begin session loops in priority order

### 5.3 Scenario: Explore

User wants to brainstorm a specific section without committing to write.

1. Team Lead conducts exploratory dialogue
2. Researcher gathers background data
3. Team Lead presents options with trade-offs and recommendations
4. Iterative discussion until direction is confirmed
5. Output: Ideation notes (pre-SSOT artifact)
6. Transitions to Write when user is ready (or stays as ideation)

**Explore-to-Write transition**: When direction is confirmed, the Team Lead asks: "Ready to start writing this section?" If yes, the SSOT transitions from `ideation` to `draft` and the session loop begins at step (1). If no, the ideation notes are saved for later.

Note: If user runs `/write` on a section with no direction, the system automatically enters Explore first.

### 5.4 Scenario: Write

User selects a section to work on. System auto-detects the appropriate mode:

| SSOT State | Mode | Behavior |
|-----------|------|----------|
| Empty / ideation | **Create** | Full session loop from (1) |
| draft | **Edit** | Session loop from (6), other SSOTs unchanged |
| verified / tentative | **Revise** | Session loop from (6), re-verification required |
| confirmed | **Re-edit** | Warning + impact analysis, then session loop from (6). Affected SSOTs flagged |
| existing | **Enhance** | Existing content as starting draft, session loop from (5) for initial verification |

Impact propagation on re-edit:

| Severity | Example | Action |
|----------|---------|--------|
| High | Product model change -> price/spec overhaul | Force re-verify affected SSOTs |
| Medium | Server name change -> possible inconsistency | Notify user, let them decide |
| Low | Wording change -> no cross-SSOT impact | Log only |

### 5.5 Scenario: Diagnose

User uploads existing proposal OR wants quality check on current work.

1. **Parse & decompose**: Parse document into section-level SSOTs (status: "existing")
2. **Diagnosis report**: Overseer grades each section (A/B/C/D), identifies issues, cross-cutting problems (terminology inconsistency, data mismatches)
3. **User choice**:
   - Full improvement: All sections in priority order
   - Selective: Pick specific sections
   - Cross-cutting only: Fix terminology/data issues first
   - Re-prioritize: User sets the order
4. **Sequential improvement**: Each selected SSOT goes through session loop
5. **Final integration review**: Before/after comparison, residual issue check, final grading

---

## 6. Agent Skills

### 6.1 Essential Skills (all teams)

| Skill | Purpose | Primary teams |
|-------|---------|--------------|
| **Mermaid** | Flowcharts, sequence diagrams, ERD, Gantt, state diagrams, architecture diagrams | All |
| **Table Generator** | Complex comparison tables, spec tables, pricing tables | All |
| **FP/Cost Estimation** | Function point calculation, development cost, TCO analysis | BA, TA |
| **RFP Traceability Matrix** | Map RFP requirements to proposal sections | BA, Overseer |
| **Document Parser** | Parse existing PDF/DOCX/PPTX into SSOTs | All |

### 6.2 Quality Differentiation Skills

| Skill | Purpose | Primary teams |
|-------|---------|--------------|
| **Glossary** | Unified terminology/abbreviation/server name management across all SSOTs | Overseer, Critic |
| **Regulatory Checklist** | Auto-check against financial security guidelines (e.g., network separation roadmap) | Overseer, Critic |
| **Reference Manager** | Structured storage and reuse of delivery cases, certifications, track records | Researcher |
| **Competitive Analysis** | Generate comparison tables showing advantages over competitors | SA |

### 6.3 Output Skills

| Skill | Purpose | Primary teams |
|-------|---------|--------------|
| **MD -> PPT/PDF/HTML** | Render confirmed SSOTs into final deliverable format | All |
| **Version Diff** | Visualize changes between SSOT versions | Team Lead |
| **Executive Summary** | Generate 1-page summary of long SSOTs for PM overview | Team Lead, Overseer |

### 6.4 Mermaid Diagram Types

| Diagram Type | Use Case | Primary teams |
|-------------|----------|--------------|
| `flowchart` | Business process, system flow | BA, TA |
| `sequenceDiagram` | API call flows, integration points | TA, SA |
| `erDiagram` | Data model, entity relationships | DA |
| `gantt` | Implementation schedule, milestones | TA |
| `stateDiagram` | System state transitions, failure handling | TA |
| `architecture` | System topology, network layout | TA, SA |
| `pie` / `quadrantChart` | Cost breakdown, solution comparison | SA, BA |

---

## 7. Output Pipeline

### 7.1 Architecture

```
+-----------------------------------------------------------+
|                    Source Layer (always maintained)         |
|                                                           |
|  ssot/ba/*.md  ssot/da/*.md  ssot/ta/*.md  ssot/sa/*.md  |
|  meta/glossary.yaml    meta/rfp-trace-matrix.md           |
|  meta/outline.yaml     assets/diagrams/*.mmd              |
+----------------------------+------------------------------+
                             |
                    +--------v--------+
                    |  Assembly Engine |
                    |                 |
                    |  1. Generate TOC |
                    |  2. Order SSOTs  |
                    |  3. Page numbers |
                    |  4. Resolve xrefs|
                    |  5. Insert       |
                    |     glossary     |
                    +--------+--------+
                             |
                +------------+------------+
                v            v            v
          +----------+ +----------+ +----------+
          |    PPT   | |    PDF   | |   HTML   |
          | Template | | Print    | | Internal |
          | mapping  | | layout   | | sharing  |
          +----------+ +----------+ +----------+
```

User selects output format(s). Source markdown is always generated.

### 7.2 Directory Structure

```
proposal-project/
|-- meta/
|   |-- proposal-meta.yaml      # Project info (customer, project name, timeline)
|   |-- glossary.yaml           # Unified glossary
|   |-- rfp-trace-matrix.md     # Requirements traceability matrix
|   +-- outline.yaml            # TOC + SSOT ordering
|
|-- ssot/
|   |-- ba/
|   |   |-- ba-overview.md
|   |   |-- ba-requirements.md
|   |   +-- ba-process.md
|   |-- da/
|   |   |-- da-model.md
|   |   +-- da-migration.md
|   |-- ta/
|   |   |-- ta-architecture.md
|   |   |-- ta-implementation.md
|   |   |-- ta-contingency.md
|   |   +-- ta-cost.md
|   +-- sa/
|       |-- sa-hsm.md
|       |-- sa-did.md
|       +-- sa-blockchain.md
|
|-- ideation/                    # Pre-SSOT exploration notes
|   +-- ta-implementation-notes.md
|
|-- assets/
|   |-- diagrams/               # Mermaid source + rendered images
|   |-- certs/                  # Certificate images
|   +-- product-images/         # Product photos
|
|-- templates/
|   |-- company-ppt.pptx        # Company PPT master
|   |-- pdf-style.css           # PDF rendering style
|   +-- html-theme/             # HTML theme
|
+-- output/
    |-- proposal-v3.pptx
    |-- proposal-v3.pdf
    |-- proposal-v3.md           # Always generated (source)
    +-- proposal-v3/             # HTML (static site)
        |-- index.html
        +-- sections/...
```

### 7.3 Quick Edit Workflow

```
"Change HSM model to S780"
  |
  v
(1) Edit source: ssot/sa/sa-hsm.md
  |
  v
(2) Impact check: affects -> ta-cost.md, ta-implementation.md
  |
  v
(3) Cascade edits: fix affected SSOTs (auto or user-directed)
  |
  v
(4) Incremental rebuild:
    - PPT: replace affected slides only
    - PDF: full regeneration (page numbers)
    - HTML: rebuild affected sections only
```

---

## 8. Commands

### 8.1 Core Commands (5)

| Command | Purpose | When to use |
|---------|---------|-------------|
| `/design` | Proposal strategy + TOC setup | Starting a new project |
| `/write <section>` | Work on a section (mode auto-detected) | Writing/editing any section |
| `/diagnose` | Full quality diagnosis + improvement plan | Mid-check or wrap-up |
| `/verify` | On-demand cross-SSOT consistency check (broader than automatic Overseer review) | After multiple sections completed |
| `/status` | Progress dashboard | Anytime |

### 8.2 Natural Language (always available)

The system accepts natural language input and routes to the appropriate function:

```
"RFP 받았는데 어디서부터?"              -> /design
"이행계획 어떻게 할지 고민 중이야"        -> /write impl (auto-enters explore mode)
"HSM 모델 변경해야 해"                  -> /write hsm (auto-enters re-edit mode)
"전체적으로 좀 약한 것 같아"              -> /diagnose
"이전 버전이랑 비교해줘"                 -> diff function
"RFP 보완공고 나왔어"                   -> apply function
"PDF로 출력해줘"                        -> output generation
```

### 8.3 `/verify` vs Automatic Overseer Review

| | Automatic Overseer Review | `/verify` Command |
|---|---|---|
| **Trigger** | Automatic on tentative confirmation (step 10) | User-initiated |
| **Scope** | Single SSOT vs its dependencies | All confirmed/tentative SSOTs together |
| **Focus** | This SSOT fits into the whole | Cross-cutting issues across multiple SSOTs |
| **Checks** | Terminology, data, strategy alignment | + Redundancy, gap analysis, narrative flow |
| **When** | Every SSOT, every time | After 2+ sections completed, or before final output |

### 8.4 Automatic Behaviors (no command needed)

- Background parallel work across teams
- SSOT state detection -> appropriate mode selection
- In-session verification loop
- Impact propagation analysis on edits
- Overseer cross-review on tentative confirmation
- Auto-explore when writing a section with no direction

---

## 9. Harness Guide

An always-present contextual guide at the bottom of every response, showing progress and recommending next actions with copy-pasteable examples.

### 9.1 Format

```
-------------------------------------------------
Project: [project name]
-------------------------------------------------
✅ Done: [v] section1 (team), [v] section2 (team)
🔄 In Progress: [~] section3 (team) -- current activity details
💡 Recommended: /command copy-pasteable example input
-------------------------------------------------
```

### 9.2 Status Icons

```
[v] confirmed
[~] in progress (draft / verifying / verified / tentative / reviewing)
[>] ideation
[ ] not started
[!] revision (Overseer directive or re-edit of confirmed)
```

### 9.3 Recommendation Logic

| Current State | Recommended |
|--------------|-----------------|
| No project | `/design` to start |
| Design complete, all SSOTs empty | `/write <first priority section>` |
| Some sections in draft | `/write` on incomplete sections |
| 2+ sections confirmed | `/verify` for cross-check |
| All confirmed | `/diagnose` for final check, then output |
| External input received | Natural language to apply changes |
| Ideation sections exist | `/write <section>` to continue exploration |

### 9.4 Example: No Project

```
-------------------------------------------------
Project: (none)
-------------------------------------------------
✅ Done: --
🔄 In Progress: --
💡 Recommended: /design 우리은행 블록체인 플랫폼 구축 제안서 만들어야 해. RFP는 여기 있어 /path/to/rfp.pdf
-------------------------------------------------
```

### 9.5 Example: Mid-Project

```
-------------------------------------------------
Project: Woori Bank Blockchain Platform Proposal
-------------------------------------------------
✅ Done: [v] Proposal Overview (BA), [v] Requirements (BA)
🔄 In Progress: [~] Tech Architecture (TA) -- Critic reviewing, [~] HSM (SA) -- Researcher gathering data
💡 Recommended: /write did DID 솔루션은 라온시큐어 OmniOne 기반으로 작성해줘. 납품사례는 금융기관 위주로 넣어줘
-------------------------------------------------
```

### 9.6 Example: All Complete

```
-------------------------------------------------
Project: Woori Bank Blockchain Platform Proposal
-------------------------------------------------
✅ Done: [v] Overview, [v] Requirements, [v] Architecture, [v] HSM, [v] DID, [v] Blockchain, [v] Implementation, [v] Cost
🔄 In Progress: --
💡 Recommended: /verify 최종 교차 검증해줘
-------------------------------------------------
```

---

## 10. Cross-Team Communication

### 10.1 Communication Channels

| Channel | Purpose | Participants |
|---------|---------|-------------|
| **Dependency notification** | When SSOT content changes, notify teams whose SSOTs list it in `dependencies` | Team Lead -> Team Lead |
| **Glossary sync** | New term defined or existing term changed | Any Critic -> Overseer -> all teams |
| **Escalation** | Conflict between teams on shared data (e.g., TA says 4 servers, SA says 6) | Team Leads -> Overseer arbitrates |
| **Impact broadcast** | Re-edit of confirmed SSOT triggers impact analysis | Overseer -> affected Team Leads |

### 10.2 Conflict Resolution

When two SSOTs contain contradictory information:

1. Overseer detects (via `/verify` or automatic review)
2. Overseer identifies the authoritative source (e.g., SA owns product specs, TA owns infrastructure counts)
3. Non-authoritative SSOT is flagged for revision
4. If authority is ambiguous, Overseer asks user to decide

---

## 11. Implementation Notes

These concerns are intentionally deferred to the implementation plan phase:

| Concern | Notes |
|---------|-------|
| **Error handling** | Agent failures, LLM timeouts, partial writes. Implementation should define retry policies, graceful degradation, and user notification. |
| **Concurrency control** | Multiple agents editing related SSOTs simultaneously. Implementation should define locking strategy (optimistic vs pessimistic) and conflict resolution. |
| **Persistence** | SSOT storage format, session state persistence across restarts, backup strategy. |
| **Agent prompt engineering** | Specific system prompts for each role (Writer, Researcher, Critic, Team Lead, Overseer). |
| **RFP parsing detail** | PDF/DOCX extraction pipeline, requirement classification, ambiguity detection. |
| **Rollback** | How to undo Overseer-approved changes, version restoration mechanics. |
| **Performance** | Expected token usage per SSOT, cost estimation, parallelism limits. |

---

## 12. Reference Quality Target

The system targets proposal quality comparable to top-tier Korean SI firms. Each SSOT should include:

- **Product specifications**: Model names, quantities, TPS, certifications (CC EAL4+, FIPS 140-2)
- **Solution architecture**: Component lists, installation targets, license policies
- **Platform details**: Feature tables, pricing (perpetual/subscription), TCO calculations
- **Implementation plans**: Milestone timelines, staged rollout, rollback procedures
- **Reference cases**: Delivery history with dates, client names, current usage status
- **Maintenance**: Support conditions, SLA, EOL/EOS policies
- **Regulatory compliance**: Financial security guidelines, network separation requirements

---

## Appendix A: Input Sources

The system accepts three types of input:

1. **RFP upload**: Parse and analyze RFP document to extract requirements
2. **Conversational**: Agents ask questions to gather context when no RFP exists
3. **Existing proposal**: Load prior proposal as baseline for enhancement

All three can be combined (e.g., RFP + existing proposal + conversational clarification).

## Appendix B: Output Formats

| Format | Use Case | Characteristics |
|--------|----------|----------------|
| **Markdown** | Source / quick edit | Always generated, the editable source of truth |
| **PPT** | Client submission, presentation | Company template mapping, slide layout |
| **PDF** | Official submission, print | Page numbers, watermark, TOC auto-generation |
| **HTML** | Internal review, real-time sharing | Hyperlinks between sections, search, status badges |

User selects desired format(s) at output time.

## Appendix C: Glossary

| Term | Definition |
|------|-----------|
| SSOT | Single Source of Truth - an independently versioned section document |
| Overseer | The EA (Enterprise Architect) agent that manages overall strategy and cross-SSOT consistency |
| Session Loop | The generate-verify-revise cycle within a single SSOT |
| Team Lead | The agent within each 4-person team that interfaces with the user and Overseer |
| Harness Guide | The always-present contextual guide showing progress and next actions |
