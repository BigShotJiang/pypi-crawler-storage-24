# Harness Plugin Packaging + Dependency Detection Design

**Date:** 2026-03-15
**Status:** Draft
**Related:** `CLAUDE.md`, `AGENTS.md`, `ARCHITECTURE.md`

---

## Goal

Package the Proposal Harness as a Claude Code plugin (`ph`) with automatic dependency detection and guided installation, while maintaining Codex compatibility via AGENTS.md. Target user: financial IT proposal PMs who may be new to Claude Code.

## Architecture

The existing Harness file structure becomes the plugin root. Skills are restructured from flat files to folder-based format required by Claude Code plugins. Four new files/dirs are added; ten existing files are modified.

### Plugin Skill Structure

Claude Code plugins require skills as folders with `SKILL.md`:

```
# Before (current)
skills/design.md

# After (plugin format)
skills/design/SKILL.md
```

Each existing `skills/<name>.md` is moved to `skills/<name>/SKILL.md`. Content is unchanged — only the file path changes.

### New Files

#### `.claude-plugin/plugin.json`

```json
{
  "name": "ph",
  "version": "1.0.0",
  "description": "Proposal Harness — 금융 IT 제안서 멀티에이전트 작성 시스템",
  "author": {
    "name": "hwai"
  }
}
```

The `name` field becomes the namespace prefix: all skills are accessed as `/ph:<skill>`.

#### `skills/setup/SKILL.md`

Environment check skill. When invoked (`/ph:setup`), runs `bash scripts/check-deps.sh` and presents results in a user-friendly format:

```
환경 점검 결과:
✅ git
❌ harness-parser → pip install harness-parser
❌ pandoc → brew install pandoc (macOS) / apt install pandoc (Linux)
✅ node

필요한 것만 설치하시면 됩니다.
harness-parser 없이도 PDF RFP는 바로 사용 가능합니다.
```

The skill is supplementary (approach B). Users can also rely on per-skill detection (approach A) and never run `/ph:setup` at all.

#### `scripts/check-deps.sh`

Detects installed dependencies and outputs JSON:

```json
{
  "required": {
    "git": true
  },
  "optional": {
    "harness-parser": false,
    "pandoc": false,
    "node": true
  }
}
```

Detection methods:

| Tool | Detection | Required/Optional | Purpose |
|------|-----------|-------------------|---------|
| git | `command -v git` | Required | SSOT version control |
| harness-parser | `pip show harness-parser >/dev/null 2>&1` | Optional | PPTX/DOCX/XLSX reading |
| pandoc | `command -v pandoc` | Optional | PDF output |
| node | `command -v node` | Optional | Advanced contract validation |

Note: `from parser import parse` cannot be used for detection because `parser` is a Python stdlib module. Use `pip show harness-parser` instead.

---

## Dependency Detection: Two-Layer Approach

### Layer A (Primary): Per-Skill Detection

Each skill that depends on optional tools includes a pre-check section. The skill instructs the agent to run `bash scripts/check-deps.sh` when a dependency is needed and guide the user if it is missing.

**Which skills check what:**

| Skill | Checks for | When |
|-------|------------|------|
| `design/SKILL.md` | harness-parser | User provides PPTX/DOCX/XLSX file |
| `write/SKILL.md` | harness-parser | Source documents are PPTX/DOCX/XLSX |
| `output/SKILL.md` | pandoc | User requests PDF output |
| `output/SKILL.md` | python-pptx (via harness-parser) | User requests PPTX output |
| `verify/SKILL.md` | node | Contract validation step |

**Format for skill pre-check sections:**

```markdown
## Dependency Check

When the user provides a document file (PPTX, DOCX, XLSX):
1. Run `bash scripts/check-deps.sh`
2. If `harness-parser` is `false`, inform the user:
   "PPTX/DOCX 파일을 읽으려면 parser 설치가 필요합니다.
    터미널에서 실행: pip install harness-parser
    설치 후 다시 시도해주세요."
3. If `true`, proceed with parsing.
```

### Layer B (Supplementary): `/ph:setup`

For users who want to check everything at once. Runs `check-deps.sh` and shows a complete overview. Does not auto-install anything — only informs and guides.

---

## Command Mapping

| Command | Skill File | Purpose |
|---------|------------|---------|
| `/ph:design` | `skills/design/SKILL.md` | Proposal strategy + TOC |
| `/ph:write` | `skills/write/SKILL.md` | Section draft/revise |
| `/ph:diagnose` | `skills/diagnose/SKILL.md` | Quality diagnosis |
| `/ph:verify` | `skills/verify/SKILL.md` | Cross-SSOT consistency |
| `/ph:status` | `skills/status/SKILL.md` | Progress dashboard |
| `/ph:setup` | `skills/setup/SKILL.md` | Environment check (new) |

Output is triggered via natural language only (e.g., "PDF로 출력해줘"). The output skill exists at `skills/output/SKILL.md` but is not exposed as a slash command — agents invoke it via natural language routing.

Natural language routing remains unchanged — users can still say "제안서 만들어야 해" and it routes to `/ph:design`.

---

## Proposal Guide Format

Every user-facing response includes the Proposal Guide footer.

### Before (current `reference/proposal-guide-format.md`)

```
Recommended: /command copy-pasteable example input
```

### After (updated)

```
Recommended: /ph:command args — 다음에 할 일 설명
```

**Changes to `reference/proposal-guide-format.md`:**
1. All command examples gain `/ph:` prefix
2. Recommended line format changes: command + ` — ` + human-readable explanation (mandatory)
3. New section: Platform Divergence (Claude Code vs Codex)

### Full footer format:

```
-------------------------------------------------
Project: [project name]
-------------------------------------------------
Current: [situation label]
Done: [v] section (team)
In Progress: [~] section (team) -- activity detail
Recommended: /ph:command args — 다음에 할 일 설명
-------------------------------------------------
```

### Platform Divergence

The Proposal Guide is the only place where Claude Code and Codex differ:

```
# Claude Code
Recommended: /ph:write sa-hsm-001 — HSM 솔루션 초안을 이어서 작성합니다

# Codex
Recommended: "HSM 솔루션 초안 작성을 이어서 진행해주세요" (sa-hsm-001)
```

Everything else (skills, agents, templates, scripts) is 100% shared.

---

## Codex Compatibility

| Aspect | Claude Code | Codex |
|--------|-------------|-------|
| Entry point | CLAUDE.md + plugin.json | AGENTS.md |
| Commands | `/ph:design`, `/ph:write`, etc. | Natural language only |
| Dep detection | Skills call `check-deps.sh` | Agents call `check-deps.sh` |
| Proposal Guide | `/ph:` commands in Recommended | Natural language in Recommended |

AGENTS.md is updated to reference the same dependency detection approach and natural-language Recommended format.

---

## Files: New

| File | Description |
|------|-------------|
| `.claude-plugin/plugin.json` | Plugin manifest (name: "ph") |
| `skills/setup/SKILL.md` | Environment check skill |
| `scripts/check-deps.sh` | Dependency detection script |

## Files: Restructured

| Before | After | Content Change |
|--------|-------|---------------|
| `skills/design.md` | `skills/design/SKILL.md` | + dependency check section |
| `skills/write.md` | `skills/write/SKILL.md` | + dependency check section |
| `skills/diagnose.md` | `skills/diagnose/SKILL.md` | + dependency check section |
| `skills/verify.md` | `skills/verify/SKILL.md` | + dependency check section + Node.js graceful fallback |
| `skills/status.md` | `skills/status/SKILL.md` | + `/ph:` prefix in Recommended examples |
| `skills/output.md` | `skills/output/SKILL.md` | + dependency check section for pandoc/python-pptx |

Note: `verify/SKILL.md` needs Node.js graceful fallback logic written from scratch — it does not currently exist in `skills/verify.md`.

## Files: Modified (content only)

| File | Change |
|------|--------|
| `CLAUDE.md` | Command table uses `/ph:` prefix, add `/ph:setup`, update skill file paths |
| `AGENTS.md` | Add dep detection reference, natural-language Recommended format, update skill file paths |
| `ARCHITECTURE.md` | Update skills/ file paths to folder structure |
| `reference/proposal-guide-format.md` | `/ph:` prefix, command + explanation rule (mandatory), Codex divergence section |

## Files: Not Changed

- `agents/` — Agent role definitions unchanged
- `templates/` — SSOT and output templates unchanged
- `parser/` — Remains as optional pip package, no modification
- `evals/` — Test fixtures unchanged
- `reference/` (except proposal-guide-format.md) — Unchanged
- `scripts/verify-harness.sh` — Updated separately to handle new skill paths
- `scripts/validate-harness-contracts.js` — Updated separately to handle new skill paths

---

## What We Don't Build

- Rendering engines — agents call pandoc/python-pptx directly
- Auto-installer — only inform, never auto-install
- Parser bundling inside plugin — parser stays as separate pip package
- Plugin marketplace hosting — submit to Anthropic's official marketplace
