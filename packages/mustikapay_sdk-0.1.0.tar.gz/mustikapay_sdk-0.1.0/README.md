# MustikaPay Python SDK

Library Python resmi untuk [MustikaPay](https://mustikapayment.com) Payment Gateway. 
Memudahkan Anda mengintegrasikan pembayaran QRIS, Virtual Account (VA), dan sistem Pencairan Saldo (Payout/Disbursement) ke dalam aplikasi Python Anda.

## 🚀 Fitur Utama

- ✅ **Payment API**: Buat & Cek Status QRIS dan Virtual Account.
- ✅ **Payout API**: Transfer Bank & Topup E-Wallet otomatis.
- ✅ **Utility**: Cek Saldo & Validasi Nama Rekening Tujuan.
- ✅ **Type Hinting (Mypy Ready)**: Mendukung *autocomplete* penuh di IDE modern (VSCode / PyCharm).
- ✅ **Custom Exceptions**: Penanganan error yang spesifik dan rapi.
- ✅ **Enums Built-in**: Tidak perlu menebak kode bank atau e-wallet.

---

## 📦 Instalasi

Install melalui pip:

```bash
pip install mustikapay-sdk
```

---

## 🛠️ Penggunaan Cepat (Quick Start)

### Inisialisasi Client

```python
from mustikapay import MustikaPay

# Masukkan API Key yang didapat dari Dashboard MustikaPay
mp = MustikaPay(api_key="MP-xxxx-xxxx")
```

### 1. Membuat Pembayaran QRIS

```python
try:
    # Membuat QRIS sebesar Rp 10.000
    qris = mp.create_qris(amount=10000)
    
    print(f"Ref No: {qris['ref_no']}")
    print(f"Link Bayar: {qris['payment_link']}")
    
except Exception as e:
    print(f"Error: {e}")
```

### 2. Membuat Virtual Account (VA)

Dilengkapi dengan Enum agar Anda tidak salah memasukkan kode bank.

```python
from mustikapay import MustikaPay, BankCode

mp = MustikaPay(api_key="MP-xxxx")

va = mp.create_va(
    amount=50000, 
    bank_code=BankCode.BCA, # Menggunakan Enum BankCode (BCA: 014)
    name="Budi Santoso",
    phone="08123456789"
)

print(va)
```

### 3. Penarikan Saldo (Payout / Disbursement)

Penarikan saldo di MustikaPay memerlukan **2 langkah** demi keamanan:
1. Request OTP (akan dikirim ke Telegram/Email akun MustikaPay).
2. Eksekusi Penarikan dengan kode OTP tersebut.

```python
from mustikapay import MustikaPay, PayoutType, BankCode, EwalletCode

mp = MustikaPay(api_key="MP-xxxx")

# LANGKAH 1: Request OTP
# OTP akan dikirim ke kontak yang terdaftar
req_otp = mp.request_withdraw_otp(
    tipe=PayoutType.EWALLET, 
    kode=EwalletCode.DANA, 
    rek="081234567890", 
    amount=50000
)
print(req_otp['message']) # "OTP telah dikirim ke Telegram Anda."

# LANGKAH 2: Eksekusi Penarikan (Setelah user menginput OTP)
kode_otp = input("Masukkan OTP: ")

wd_result = mp.withdraw(
    tipe=PayoutType.EWALLET, 
    kode=EwalletCode.DANA, 
    rek="081234567890", 
    amount=50000,
    otp=kode_otp
)
print("Berhasil ditarik:", wd_result)
```

### 4. Validasi Rekening / E-Wallet

Memastikan nomor rekening valid dan menampilkan nama pemilik sebelum melakukan transfer.

```python
# Cek Nama Pemilik Rekening BCA
cek_rekening = mp.validate_account(
    tipe=PayoutType.BANK,
    kode=BankCode.BCA,
    rek="1234567890"
)
print("Nama Pemilik:", cek_rekening['account_name'])
```

---

## ⚠️ Penanganan Error (Error Handling)

Library ini dilengkapi dengan Custom Exceptions agar Anda bisa menangani error dengan presisi:

```python
from mustikapay import (
    MustikaPay, 
    MustikaPayAuthError, 
    MustikaPayValidationError, 
    MustikaPayError
)

mp = MustikaPay(api_key="MP-SALAH-KEY")

try:
    # Sengaja nominal kurang dari Rp 1000
    qris = mp.create_qris(amount=500) 
    
except MustikaPayValidationError as e:
    print("Validasi Gagal:", e)
    
except MustikaPayAuthError as e:
    print("API Key Salah/Ditolak:", e)
    
except MustikaPayError as e:
    print("Error Umum MustikaPay:", e)
    # Anda juga bisa melihat response mentah (raw JSON) dari server
    print("Raw Response:", e.raw_response)
```

## Referensi API

Untuk referensi API yang lebih lengkap, silakan kunjungi:
👉 [Dokumentasi Resmi MustikaPay](https://mustikapayment.com/api-guide)
