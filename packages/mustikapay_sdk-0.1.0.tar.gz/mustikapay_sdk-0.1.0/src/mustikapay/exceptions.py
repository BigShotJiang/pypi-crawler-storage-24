class MustikaPayError(Exception):
    """Base exception untuk semua error MustikaPay."""
    def __init__(self, message, raw_response=None):
        super().__init__(message)
        self.raw_response = raw_response

class MustikaPayAuthError(MustikaPayError):
    """Error ketika API Key tidak valid atau otorisasi gagal."""
    pass

class MustikaPayValidationError(MustikaPayError):
    """Error ketika parameter yang dikirim tidak sesuai (contoh: amount kurang dari batas)."""
    pass

class MustikaPayNetworkError(MustikaPayError):
    """Error koneksi jaringan atau timeout."""
    pass
