import requests
from typing import Dict, Any, Optional, Union
from urllib.parse import urljoin
from .exceptions import MustikaPayError, MustikaPayAuthError, MustikaPayNetworkError, MustikaPayValidationError

class MustikaPay:
    """
    MustikaPay Python SDK
    Library resmi untuk integrasi API Pembayaran & Penarikan MustikaPay.
    """

    def __init__(self, api_key: str, base_url: str = "https://mustikapayment.com", timeout: int = 30):
        """
        Inisialisasi Client MustikaPay.
        
        :param api_key: API Key dari Dashboard (format: MP-xxxx).
        :param base_url: URL Utama API MustikaPay.
        :param timeout: Batas waktu (detik) untuk setiap HTTP request.
        """
        if not api_key or not api_key.startswith("MP-"):
            raise MustikaPayValidationError("API Key tidak valid! Format API Key harus dimulai dengan 'MP-'.")
        
        self.api_key = api_key
        self.base_url = base_url.rstrip('/')
        self.timeout = timeout
        
        self._session = requests.Session()
        self._session.headers.update({
            'X-Api-Key': self.api_key,
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'MustikaPay-Python-SDK/0.1.0'
        })

    def _handle_response(self, response: requests.Response) -> Dict[str, Any]:
        """Menangani response dari server dan memunculkan error yang sesuai."""
        try:
            data = response.json()
        except ValueError:
            raise MustikaPayError(f"Server mengembalikan format non-JSON. Status Code: {response.status_code}", raw_response=response.text)
        
        if response.status_code in [401, 403]:
            raise MustikaPayAuthError(data.get("message", data.get("detail", "Unauthorized")), raw_response=data)
        
        if response.status_code == 422:
            raise MustikaPayValidationError("Validasi Data Gagal", raw_response=data)

        if not str(response.status_code).startswith('2'):
            msg = data.get("message", data.get("detail", f"HTTP Error {response.status_code}"))
            raise MustikaPayError(msg, raw_response=data)
            
        # Kadang API mengembalikan code 200 tapi di dalam JSON tertulis status="error"
        if data.get("status") == "error":
            raise MustikaPayError(data.get("message", "Terjadi kesalahan pada request."), raw_response=data)

        return data

    def _request(self, method: str, endpoint: str, data: Optional[Dict] = None, params: Optional[Dict] = None) -> Dict[str, Any]:
        url = urljoin(self.base_url + "/", endpoint.lstrip('/'))
        try:
            if method.upper() == "GET":
                response = self._session.get(url, params=params, timeout=self.timeout)
            else:
                # Membersihkan data dari nilai None
                clean_data = {k: v for k, v in data.items() if v is not None} if data else {}
                response = self._session.post(url, data=clean_data, timeout=self.timeout)
            
            return self._handle_response(response)
            
        except requests.exceptions.Timeout:
            raise MustikaPayNetworkError(f"Request ke {url} timeout setelah {self.timeout} detik.")
        except requests.exceptions.ConnectionError as e:
            raise MustikaPayNetworkError(f"Gagal terhubung ke MustikaPay: {str(e)}")
        except requests.exceptions.RequestException as e:
            raise MustikaPayError(f"Terjadi kesalahan request: {str(e)}")

    # ==========================================
    # 1. PAYMENT API (Menerima Pembayaran)
    # ==========================================

    def create_qris(self, amount: int, user: Optional[str] = None) -> Dict[str, Any]:
        """
        Membuat Pembayaran QRIS Dinamis.
        
        :param amount: Nominal tagihan (Minimal Rp 1.000).
        :param user: (Opsional) Username akun (jika ingin assign spesifik, jarang digunakan jika pakai X-Api-Key).
        :return: Dict berisi data QRIS ('ref_no', 'qr_content', 'qr_url', 'payment_link').
        """
        if amount < 1000:
            raise MustikaPayValidationError("Nominal QRIS minimal Rp 1.000")
            
        payload = {'amount': amount}
        if user:
            payload['user'] = user
            
        return self._request('POST', '/api/createpay', data=payload)

    def check_qris_status(self, ref_no: str) -> Dict[str, Any]:
        """
        Mengecek status pembayaran QRIS.
        
        :param ref_no: Reference Number (cth: QR170...).
        :return: Dict berisi status (cth: {'status': 'SUCCESS', ...}).
        """
        return self._request('GET', '/api/cekpay', params={'ref_no': ref_no})

    def create_va(self, amount: int, bank_code: str, name: str, phone: str = "08123456789") -> Dict[str, Any]:
        """
        Membuat Pembayaran Virtual Account (VA).
        
        :param amount: Nominal tagihan.
        :param bank_code: Kode Bank (cth: '014' untuk BCA, '008' untuk Mandiri). Bisa dari enum BankCode.
        :param name: Nama Pelanggan (Minimal 3 Karakter).
        :param phone: Nomor HP Pelanggan.
        :return: Dict data Virtual Account.
        """
        if len(name) < 3:
            raise MustikaPayValidationError("Nama pelanggan minimal 3 karakter.")
            
        return self._request('POST', '/create/va', data={
            'amount': amount,
            'bank_code': bank_code,
            'name': name,
            'phone': phone
        })

    def check_va_status(self, ref_no: str) -> Dict[str, Any]:
        """
        Mengecek status pembayaran Virtual Account (VA).
        
        :param ref_no: Reference Number VA.
        """
        return self._request('GET', '/cekva', params={'ref_no': ref_no})

    # ==========================================
    # 2. PAYOUT API (Kirim Uang / Penarikan)
    # ==========================================

    def request_withdraw_otp(self, tipe: str, kode: str, rek: str, amount: int) -> Dict[str, Any]:
        """
        (Langkah 1) Meminta kode OTP untuk penarikan saldo.
        Ini akan memicu pengiriman OTP ke Telegram/Email yang terhubung dengan akun MustikaPay Anda.
        """
        return self.withdraw(tipe=tipe, kode=kode, rek=rek, amount=amount, otp=None)

    def withdraw(self, tipe: str, kode: str, rek: str, amount: int, otp: Optional[str] = None) -> Dict[str, Any]:
        """
        (Langkah 2) Mengeksekusi penarikan (Pencairan) dengan kode OTP.
        
        :param tipe: 'bank' atau 'ewallet'. (Bisa dari enum PayoutType).
        :param kode: Kode bank (cth: '014') atau kode E-wallet (cth: 'dana', 'ovo').
        :param rek: Nomor rekening tujuan atau nomor HP E-Wallet.
        :param amount: Nominal yang akan ditarik.
        :param otp: 6 digit kode OTP. Biarkan kosong jika hanya ingin merequest (meminta) OTP.
        """
        payload = {
            'tipe': tipe,
            'kode': kode,
            'rek': rek,
            'amount': amount
        }
        if otp:
            payload['otp'] = otp
            
        return self._request('POST', '/api/wd', data=payload)

    def check_withdraw_status(self, ref_no: str) -> Dict[str, Any]:
        """
        Mengecek status proses penarikan saldo (Payout).
        
        :param ref_no: Reference Number transaksi WD.
        """
        return self._request('GET', '/api/cekwd', params={'ref_no': ref_no})

    def validate_account(self, tipe: str, kode: str, rek: str) -> Dict[str, Any]:
        """
        Mengecek/Memvalidasi Nomor Rekening atau Nomor E-Wallet.
        Berguna untuk memastikan nama tujuan valid sebelum ditarik.
        
        :param tipe: 'bank' atau 'ewallet'.
        :param kode: Kode bank/e-wallet.
        :param rek: Nomor Rekening / HP.
        :return: Menghasilkan informasi akun tujuan (Nama Pemilik, dll).
        """
        return self._request('GET', '/api/validate-bank', params={
            'tipe': tipe,
            'kode': kode,
            'rek': rek
        })

    # ==========================================
    # 3. UTILITY API
    # ==========================================

    def get_balance(self, username: str) -> Dict[str, Any]:
        """
        Mengecek Saldo Akun MustikaPay Anda (Available & Pending).
        
        :param username: Username akun MustikaPay Anda.
        """
        return self._request('GET', '/api/saldo', params={'user': username})
