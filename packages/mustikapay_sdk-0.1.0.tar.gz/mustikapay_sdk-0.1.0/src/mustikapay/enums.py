from enum import Enum

class BankCode(str, Enum):
    BCA = "014"
    MANDIRI = "008"
    BNI = "002"
    BRI = "002" # Sesuaikan jika beda
    CIMB = "022"
    PERMATA = "022"
    BSI = "451"
    BJB = "011"
    DANAMON = "011"
    BNC = "490"
    
class EwalletCode(str, Enum):
    DANA = "dana"
    OVO = "ovo"
    GOPAY = "gopay"
    SHOPEEPAY = "shopeepay"
    LINKAJA = "linkaja"

class PayoutType(str, Enum):
    BANK = "bank"
    EWALLET = "ewallet"
