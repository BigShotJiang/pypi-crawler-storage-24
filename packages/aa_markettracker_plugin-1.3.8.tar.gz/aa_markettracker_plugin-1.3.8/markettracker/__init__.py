"""Initialize the app"""

__version__ = "1.3.8"
__title__ = "Markettracker"
