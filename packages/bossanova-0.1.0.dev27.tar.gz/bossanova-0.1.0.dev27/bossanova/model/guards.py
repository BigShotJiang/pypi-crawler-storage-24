"""Decorator guards for model state validation.

Each decorator checks a precondition on the model instance and raises
``ModelStateError`` if the condition is not met.  Decorators compose
their prerequisites internally — e.g. ``requires_mixed_fit`` includes
``requires_fit`` — so you never need to stack them.

Usage on properties::

    @property
    @requires_fit
    def params(self) -> pl.DataFrame:
        ...

Usage on methods::

    @requires_fit
    def summary(self, ...) -> str:
        ...
"""

from __future__ import annotations

from collections.abc import Callable
from functools import wraps
from typing import Any, TypeVar

_F = TypeVar("_F", bound=Callable[..., Any])

__all__ = [
    "ModelStateError",
    "requires_data",
    "requires_explore",
    "requires_fit",
    "requires_mixed_data",
    "requires_mixed_fit",
    "requires_predict",
    "requires_simulations",
    "requires_varying",
]


class ModelStateError(RuntimeError):
    """Exception raised when a model operation requires a different state.

    Raised when attempting to access results or perform operations that
    require the model to be in a specific state (e.g., fitted, explored,
    predicted).  The error message guides the user to the needed state
    transition.

    State machine flow:
        construction -> data -> fit -> explore/predict/simulate -> infer

    Args:
        message: Error message describing the required state transition.
    """

    pass


# ---------------------------------------------------------------------------
# Leaf guards (no prerequisites)
# ---------------------------------------------------------------------------


def requires_data(fn: _F) -> _F:
    """Guard: ensure data is available (bundle or raw data)."""

    @wraps(fn)
    def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        if self._bundle is None and self.data is None:
            raise ModelStateError(
                "No data available. Either:\n"
                "  - Provide data: model('y ~ x', data)\n"
                "  - Generate data: model('y ~ x').simulate(n=100)"
            )
        return fn(self, *args, **kwargs)

    return wrapper  # type: ignore[return-value]


def requires_fit(fn: _F) -> _F:
    """Guard: ensure model has been fitted."""

    @wraps(fn)
    def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        if self._fit is None:
            raise ModelStateError("Model not fitted. Call .fit() first.")
        return fn(self, *args, **kwargs)

    return wrapper  # type: ignore[return-value]


def requires_explore(fn: _F) -> _F:
    """Guard: ensure marginal effects have been computed."""

    @wraps(fn)
    def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        if self._mee is None:
            raise ModelStateError(
                "No marginal effects computed. Call .explore(focal_var) first."
            )
        return fn(self, *args, **kwargs)

    return wrapper  # type: ignore[return-value]


def requires_predict(fn: _F) -> _F:
    """Guard: ensure predictions have been computed."""

    @wraps(fn)
    def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        if self._pred is None:
            raise ModelStateError("No predictions computed. Call .predict() first.")
        return fn(self, *args, **kwargs)

    return wrapper  # type: ignore[return-value]


def requires_simulations(fn: _F) -> _F:
    """Guard: ensure simulations are available."""

    @wraps(fn)
    def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        if self._simulations is None:
            raise ModelStateError("No simulations available. Call .simulate() first.")
        return fn(self, *args, **kwargs)

    return wrapper  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# Composite guards (include prerequisite checks)
# ---------------------------------------------------------------------------


def requires_mixed_fit(fn: _F) -> _F:
    """Guard: ensure model is fitted **and** has random effects.

    Composes ``requires_fit`` — no need to stack.
    """

    @wraps(fn)
    def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        if self._fit is None:
            raise ModelStateError("Model not fitted. Call .fit() first.")
        if not self._spec.has_random_effects:
            raise ModelStateError(
                "Model has no random effects. Use a formula with (1|group) syntax "
                "for mixed models. For fixed effects, use .params instead."
            )
        return fn(self, *args, **kwargs)

    return wrapper  # type: ignore[return-value]


def requires_varying(fn: _F) -> _F:
    """Guard: ensure varying state (BLUPs and variance components) is computed.

    Composes ``requires_mixed_fit`` — no need to stack.
    """

    @wraps(fn)
    def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        if self._fit is None:
            raise ModelStateError("Model not fitted. Call .fit() first.")
        if not self._spec.has_random_effects:
            raise ModelStateError(
                "Model has no random effects. Use a formula with (1|group) syntax "
                "for mixed models. For fixed effects, use .params instead."
            )
        if self._varying_offsets is None or self._varying_spread is None:
            raise ModelStateError(
                "Varying state not computed. This may indicate a fitting issue."
            )
        return fn(self, *args, **kwargs)

    return wrapper  # type: ignore[return-value]


def requires_mixed_data(fn: _F) -> _F:
    """Guard: ensure data with random-effects metadata is available.

    Composes ``requires_data`` — no need to stack.
    """

    @wraps(fn)
    def wrapper(self: Any, *args: Any, **kwargs: Any) -> Any:
        if self._bundle is None and self.data is None:
            raise ModelStateError(
                "No data available. Either:\n"
                "  - Provide data: model('y ~ x', data)\n"
                "  - Generate data: model('y ~ x').simulate(n=100)"
            )
        if self._bundle is None or self._bundle.re_metadata is None:
            raise ModelStateError(
                "Model has no random effects. Use a formula with (1|group) syntax."
            )
        return fn(self, *args, **kwargs)

    return wrapper  # type: ignore[return-value]
