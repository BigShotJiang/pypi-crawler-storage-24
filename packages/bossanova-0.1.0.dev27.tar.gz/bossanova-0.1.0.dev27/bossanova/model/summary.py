"""Summary formatting for model results.

Provides functions to format model summaries in R-like and compact styles.
Adapts output based on the last operation performed (fit vs explore) and
the inference method used (asymptotic, bootstrap, permutation, CV).

Used by the model.summary() method.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

from bossanova.internal.fit.diagnostics import compute_r_squared
from bossanova.internal.maths.inference import compute_aic, compute_bic

# Human-readable model type names
_MODEL_TYPE_DISPLAY: dict[str, str] = {
    "lm": "Linear Model",
    "glm": "Generalized Linear Model",
    "lmer": "Linear Mixed Model",
    "glmer": "Generalized Linear Mixed Model",
}

if TYPE_CHECKING:
    from bossanova.internal.containers import (
        CVState,
        DataBundle,
        FitState,
        InferenceState,
        JointTestState,
        MeeState,
        ModelSpec,
        VaryingSpreadState,
    )


__all__ = ["FormattedText", "format_summary"]


class FormattedText(str):
    """String subclass that displays without quotes in the REPL.

    Returned by :meth:`model.summary` so that typing ``m.summary()``
    in a REPL or notebook displays the formatted output directly,
    without needing ``print()``.  All ``str`` operations (``in``,
    ``len``, slicing, etc.) work as expected.
    """

    def __repr__(self) -> str:
        return str(self)


# =============================================================================
# Significance codes and p-value formatting
# =============================================================================

_SIGNIF_LEGEND = "Signif. codes:  0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1"


def _significance_code(p: float) -> str:
    """Return significance code for p-value (R-style).

    Args:
        p: P-value.

    Returns:
        Significance code: '***', '**', '*', '.', or ' '.
    """
    if p < 0.001:
        return "***"
    if p < 0.01:
        return "**"
    if p < 0.05:
        return "*"
    if p < 0.1:
        return "."
    return " "


def _format_pvalue(p: float, digits: int = 4) -> str:
    """Format p-value for display.

    Args:
        p: P-value.
        digits: Number of decimal places for numeric p-values.

    Returns:
        Formatted string, e.g., '<2e-16' for very small values.
    """
    if p <= 2.3e-16:
        return "<2.2e-16"
    if p < 0.001:
        return f"{p:.2e}"
    return f"{p:.{digits}f}"


def _model_type_name(spec: ModelSpec) -> str:
    """Get human-readable model type name.

    Args:
        spec: Model specification.

    Returns:
        Model type name string.
    """
    if spec.has_random_effects:
        model_type = "lmer" if spec.family == "gaussian" else "glmer"
    else:
        model_type = "lm" if spec.family == "gaussian" else "glm"
    base_name = _MODEL_TYPE_DISPLAY[model_type]
    if spec.family == "gaussian":
        return base_name
    return f"{base_name} ({spec.family})"


def _is_glm(spec: ModelSpec) -> bool:
    """Check if model uses z-statistics (GLM/GLMM)."""
    return spec.family != "gaussian"


def _has_finite_df(inf: InferenceState) -> bool:
    """Check if inference has finite df (not all-Inf, as in GLM z-tests)."""
    return inf.df is not None and np.all(np.isfinite(inf.df))


def _stat_label(spec: ModelSpec) -> str:
    """Return 't value' or 'z value' depending on model family."""
    return "z value" if _is_glm(spec) else "t value"


def _p_label(spec: ModelSpec) -> str:
    """Return 'Pr(>|t|)' or 'Pr(>|z|)' depending on model family."""
    return "Pr(>|z|)" if _is_glm(spec) else "Pr(>|t|)"


# =============================================================================
# Shared formatting helpers
# =============================================================================


def _format_residuals(spec: ModelSpec, fit: FitState, digits: int) -> list[str]:
    """Format residual 5-number summary.

    For mixed models, uses scaled residuals (residuals / sigma) to match R's
    lme4 summary. For LM/GLM, uses raw residuals.

    Args:
        spec: Model specification.
        fit: Fitting results.
        digits: Decimal places.

    Returns:
        List of formatted lines.
    """
    if spec.has_random_effects and fit.sigma is not None and fit.sigma > 0:
        resid = fit.residuals / fit.sigma
        label = "Scaled residuals:"
    else:
        resid = fit.residuals
        label = "Residuals:"

    quartiles = np.percentile(resid, [0, 25, 50, 75, 100])
    col_w = digits + 4
    return [
        label,
        "    Min      1Q  Median      3Q     Max",
        (
            f"{quartiles[0]:>{col_w}.{digits}f} {quartiles[1]:>{col_w}.{digits}f} "
            f"{quartiles[2]:>{col_w}.{digits}f} "
            f"{quartiles[3]:>{col_w}.{digits}f} {quartiles[4]:>{col_w}.{digits}f}"
        ),
        "",
    ]


def _ci_header(conf_level: float) -> tuple[str, str]:
    """Build CI column headers from confidence level.

    Args:
        conf_level: Confidence level (e.g. 0.95).

    Returns:
        Tuple of (lower_label, upper_label), e.g. ("2.5%", "97.5%").
    """
    alpha = 1 - conf_level
    lo_pct = alpha / 2 * 100
    hi_pct = (1 - alpha / 2) * 100
    return f"{lo_pct:g}%", f"{hi_pct:g}%"


def _infer_method_desc(method: str | None, n_resamples: int | None = None) -> str:
    """Human-readable inference method description.

    Args:
        method: Inference method string.
        n_resamples: Number of resamples (boot/perm).

    Returns:
        Description string.
    """
    if method == "asymp":
        return "Asymptotic (Wald)"
    if method == "boot":
        n = f" ({n_resamples} resamples)" if n_resamples else ""
        return f"Bootstrap{n}"
    if method == "perm":
        n = f" ({n_resamples} permutations)" if n_resamples else ""
        return f"Permutation{n}"
    return method or "None"


def _format_df(df_val: float) -> str:
    """Format a df value: integer if whole, else 1 decimal."""
    if df_val == int(df_val):
        return f"{int(df_val)}"
    return f"{df_val:.1f}"


# =============================================================================
# R-style summary: params path
# =============================================================================


def _format_r_params(
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    params_inference: InferenceState | None,
    cv: CVState | None,
    varying_spread: VaryingSpreadState | None,
    digits: int,
) -> str:
    """Format R-style summary for the params/fit path.

    For mixed models, follows lme4/lmerTest section order:
    header → fitting info → random effects → obs counts → fixed effects → model stats.

    For fixed-effects models, follows base R order:
    header → residuals → coefficients → model stats.

    Args:
        spec: Model specification.
        bundle: Data bundle.
        fit: Fitting results.
        params_inference: Optional inference state.
        cv: Optional cross-validation state.
        varying_spread: Optional variance components.
        digits: Decimal places.

    Returns:
        Formatted summary string.
    """
    lines: list[str] = []
    d = digits
    is_mixed = spec.has_random_effects

    # Header
    if is_mixed:
        method_label = spec.method.upper() if spec.method else "REML"
        lines.append(f"{_model_type_name(spec)} fit by {method_label}: {spec.formula}")
        # Observation and group counts (under model name for mixed models)
        re_meta = bundle.re_metadata
        if re_meta is not None:
            group_parts = []
            for gvar in re_meta.grouping_vars:
                n_g = re_meta.n_groups.get(gvar, "?")
                group_parts.append(f"{gvar}, {n_g}")
            groups_str = "; ".join(group_parts)
            lines.append(f"Number of obs: {bundle.n}, groups:  {groups_str}")
    else:
        lines.append(f"{_model_type_name(spec)}: {spec.formula}")
    lines.append("")

    # --- Mixed model: fitting info + random effects first (R's lme4 order) ---
    if is_mixed:
        # REML/ML criterion
        criterion_label = (
            "REML criterion" if spec.method == "reml" else "Log-likelihood"
        )
        criterion_val = -2 * float(fit.loglik)
        lines.append(f"{criterion_label} at convergence: {criterion_val:.{d}f}")
        lines.append("")

        # Scaled residuals
        lines.extend(_format_residuals(spec, fit, d))

        # Varying effects table (R-style grouped format)
        if varying_spread is not None:
            lines.extend(_format_variance_components(varying_spread, bundle, d))
            lines.append("")

        # Inference method note for fixed effects
        if params_inference is not None and params_inference.method == "asymp":
            if _has_finite_df(params_inference):
                lines.append("Fixed effects (Satterthwaite df):")
            else:
                lines.append("Fixed effects:")
        elif params_inference is not None:
            lines.append("Fixed effects:")
        else:
            lines.append("Fixed effects:")

    else:
        # --- Fixed-effects model: residuals first ---
        lines.extend(_format_residuals(spec, fit, d))
        lines.append("Coefficients:")

    # Coefficient table
    lines.extend(_format_coef_table(spec, bundle, fit, params_inference, digits=d))
    lines.append("")

    # Inference method note (non-asymptotic only)
    if params_inference is not None:
        lines.extend(_format_params_method_note(params_inference, cv))

    # Significance codes (not for CV mode which has no p-values)
    if params_inference is not None and params_inference.method != "cv":
        lines.append("---")
        lines.append(_SIGNIF_LEGEND)
        lines.append("")

    # CV metrics section
    if cv is not None:
        lines.extend(_format_cv_metrics(cv, d))
        lines.append("")

    # Fixed effects correlation matrix
    if params_inference is not None and params_inference.method != "cv":
        lines.extend(_format_fixed_effects_corr(bundle, fit, digits=d))

    # Model-level statistics
    lines.extend(_format_model_stats(spec, bundle, fit, digits=d))

    # Variance components for non-mixed models would not exist, but guard anyway
    if not is_mixed and varying_spread is not None:
        lines.append("")
        lines.append("---")
        lines.extend(_format_variance_components(varying_spread, bundle, d))

    return "\n".join(lines)


def _format_coef_table(
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    params_inference: InferenceState | None,
    *,
    digits: int = 3,
) -> list[str]:
    """Format coefficient table adapted to inference method.

    Args:
        spec: Model specification.
        bundle: Data bundle with term names.
        fit: Fitting results.
        params_inference: Optional inference state.
        digits: Decimal places.

    Returns:
        List of formatted table lines.
    """
    if params_inference is None:
        return _coef_table_bare(bundle, fit, digits)
    method = params_inference.method
    if method == "cv":
        return _coef_table_cv(bundle, fit, params_inference, digits)
    if method == "perm":
        return _coef_table_perm(spec, bundle, fit, params_inference, digits)
    # asymp or boot — both have CIs
    return _coef_table_full(spec, bundle, fit, params_inference, digits)


def _coef_table_bare(bundle: DataBundle, fit: FitState, digits: int) -> list[str]:
    """Coefficient table without inference (estimate only).

    Args:
        bundle: Data bundle.
        fit: Fitting results.
        digits: Decimal places.

    Returns:
        List of formatted lines.
    """
    lines: list[str] = []
    term_names = bundle.X_names
    estimates = fit.coef
    d = digits
    est_w = d + 5
    max_tw = max(max(len(n) for n in term_names), 11)

    lines.append(f"{'':>{max_tw}}  Estimate")
    for i, name in enumerate(term_names):
        lines.append(f"{name:>{max_tw}}  {estimates[i]:>{est_w}.{d}f}")
    return lines


def _coef_table_full(
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    inf: InferenceState,
    digits: int,
) -> list[str]:
    """Coefficient table with SEs, CIs, df, t/z-stat, and p-value (asymp/boot).

    Shows df column when finite df are available (LM, mixed models).
    Uses 'z value'/'Pr(>|z|)' for GLM, 't value'/'Pr(>|t|)' otherwise.

    Args:
        spec: Model specification.
        bundle: Data bundle.
        fit: Fitting results.
        inf: Inference state.
        digits: Decimal places.

    Returns:
        List of formatted lines.
    """
    lines: list[str] = []
    term_names = bundle.X_names
    estimates = fit.coef
    d = digits
    est_w = d + 5
    se_w = d + 4
    ci_w = d + 5
    stat_w = d + 4
    max_tw = max(max(len(n) for n in term_names), 11)

    show_df = _has_finite_df(inf)
    stat_lbl = _stat_label(spec)
    p_lbl = _p_label(spec)

    # Compute df column width if needed
    if show_df:
        df_strs = [_format_df(inf.df[i]) for i in range(len(term_names))]
        df_w = max(max(len(s) for s in df_strs), 4)
    else:
        df_strs = []
        df_w = 0

    lo_lbl, hi_lbl = _ci_header(inf.conf_level)
    header_parts = [
        f"{'':>{max_tw}}  {'Estimate':>{est_w}}  {'Std.Err':>{se_w}}  ",
        f"{'[' + lo_lbl:>{ci_w}}  {hi_lbl + ']':>{ci_w}}  ",
    ]
    if show_df:
        header_parts.append(f"{'df':>{df_w}}  ")
    header_parts.append(f"{stat_lbl:>{stat_w}}  {p_lbl:>8}    ")
    lines.append("".join(header_parts))

    for i, name in enumerate(term_names):
        sig = _significance_code(inf.p_value[i])
        p_str = _format_pvalue(inf.p_value[i], digits=d)
        row_parts = [
            f"{name:>{max_tw}}  {estimates[i]:>{est_w}.{d}f}  ",
            f"{inf.se[i]:>{se_w}.{d}f}  ",
            f"{inf.ci_lower[i]:>{ci_w}.{d}f}  {inf.ci_upper[i]:>{ci_w}.{d}f}  ",
        ]
        if show_df:
            row_parts.append(f"{df_strs[i]:>{df_w}}  ")
        row_parts.append(
            f"{inf.statistic[i]:>{stat_w}.{max(d - 1, 1)}f}  {p_str:>8} {sig}"
        )
        lines.append("".join(row_parts))
    return lines


def _coef_table_perm(
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    inf: InferenceState,
    digits: int,
) -> list[str]:
    """Coefficient table for permutation inference (no CIs).

    Args:
        spec: Model specification.
        bundle: Data bundle.
        fit: Fitting results.
        inf: Inference state.
        digits: Decimal places.

    Returns:
        List of formatted lines.
    """
    lines: list[str] = []
    term_names = bundle.X_names
    estimates = fit.coef
    d = digits
    est_w = d + 5
    se_w = d + 4
    stat_w = d + 4
    max_tw = max(max(len(n) for n in term_names), 11)

    stat_lbl = _stat_label(spec)
    p_lbl = _p_label(spec)

    header = (
        f"{'':>{max_tw}}  {'Estimate':>{est_w}}  {'Std.Err':>{se_w}}  "
        f"{stat_lbl:>{stat_w}}  {p_lbl:>8}    "
    )
    lines.append(header)

    for i, name in enumerate(term_names):
        sig = _significance_code(inf.p_value[i])
        p_str = _format_pvalue(inf.p_value[i], digits=d)
        lines.append(
            f"{name:>{max_tw}}  {estimates[i]:>{est_w}.{d}f}  "
            f"{inf.se[i]:>{se_w}.{d}f}  "
            f"{inf.statistic[i]:>{stat_w}.{max(d - 1, 1)}f}  {p_str:>8} {sig}"
        )
    return lines


def _coef_table_cv(
    bundle: DataBundle,
    fit: FitState,
    inf: InferenceState,
    digits: int,
) -> list[str]:
    """Coefficient table for CV inference (PRE columns).

    Args:
        bundle: Data bundle.
        fit: Fitting results.
        inf: Inference state with PRE fields.
        digits: Decimal places.

    Returns:
        List of formatted lines.
    """
    lines: list[str] = []
    term_names = bundle.X_names
    estimates = fit.coef
    d = digits
    est_w = d + 5
    pre_w = d + 4
    max_tw = max(max(len(n) for n in term_names), 11)

    header = (
        f"{'':>{max_tw}}  {'Estimate':>{est_w}}  {'PRE':>{pre_w}}  {'PRE_sd':>{pre_w}}"
    )
    lines.append(header)

    pre = inf.pre if inf.pre is not None else np.full(len(estimates), np.nan)
    pre_sd = inf.pre_sd if inf.pre_sd is not None else np.full(len(estimates), np.nan)

    for i, name in enumerate(term_names):
        lines.append(
            f"{name:>{max_tw}}  {estimates[i]:>{est_w}.{d}f}"
            f"  {pre[i]:>{pre_w}.{d}f}  {pre_sd[i]:>{pre_w}.{d}f}"
        )
    return lines


def _format_params_method_note(inf: InferenceState, cv: CVState | None) -> list[str]:
    """Inference method annotation for params path.

    Args:
        inf: Inference state.
        cv: Optional CV state.

    Returns:
        List of note lines (empty for asymptotic).
    """
    method = inf.method
    if method == "asymp":
        return []
    if method == "boot":
        n = inf.n_resamples or 0
        return [f"Bootstrap inference ({n} resamples, BCa CIs)", ""]
    if method == "perm":
        n = inf.n_resamples or 0
        return [f"Permutation inference ({n} permutations)", ""]
    if method == "cv":
        k = cv.k if cv is not None else "?"
        return [f"CV inference ({k}-fold), PRE = Proportion Reduction in Error", ""]
    return []


def _format_cv_metrics(cv: CVState, digits: int) -> list[str]:
    """Format cross-validation metrics section.

    Args:
        cv: CV state with OOS metrics.
        digits: Decimal places.

    Returns:
        List of formatted lines.
    """
    d = digits
    lines: list[str] = [f"Cross-Validation Metrics ({cv.k}-fold, out-of-sample):"]
    lines.append(f"  MSE:          {cv.mse:.{d}f}")
    lines.append(f"  RMSE:         {cv.rmse:.{d}f}")
    lines.append(f"  MAE:          {cv.mae:.{d}f}")
    lines.append(f"  R\u00b2 (OOS):     {cv.r_squared:.{d}f}")
    if cv.deviance is not None:
        lines.append(f"  Deviance:     {cv.deviance:.{d}f}")
    if cv.accuracy is not None:
        lines.append(f"  Accuracy:     {cv.accuracy:.{d}f}")
        if cv.sensitivity is not None:
            lines.append(f"  Sensitivity:  {cv.sensitivity:.{d}f}")
        if cv.specificity is not None:
            lines.append(f"  Specificity:  {cv.specificity:.{d}f}")
        if cv.f1 is not None:
            lines.append(f"  F1:           {cv.f1:.{d}f}")
        if cv.auc is not None:
            lines.append(f"  AUC:          {cv.auc:.{d}f}")
    return lines


def _format_variance_components(
    vs: VaryingSpreadState, bundle: DataBundle, digits: int
) -> list[str]:
    """Format variance components for mixed models in R's lme4 grouped style.

    Produces a table with Groups, Name, Variance, Std.Dev., and Corr columns,
    matching R's ``summary.merMod`` output. Includes observation and group
    counts.

    Args:
        vs: Variance spread state.
        bundle: Data bundle (for group counts).
        digits: Decimal places.

    Returns:
        List of formatted lines.
    """
    d = digits
    has_ci = vs.has_inference
    lines: list[str] = ["Varying effects:"]

    # Build rows: list of (group, name, variance, std_dev, corr_str)
    rows: list[tuple[str, str, float, float, str]] = []

    # Random effect variances — parse from tau2 dict
    # tau2 keys are like "Subject:Intercept", "Subject:Days"
    # Group them by grouping variable
    from collections import OrderedDict

    groups_terms: OrderedDict[str, list[str]] = OrderedDict()
    for key in vs.tau2:
        parts = key.split(":", 1)
        if len(parts) == 2:
            grp, term = parts
        else:
            # No group prefix (e.g., just "Intercept") — use as both
            grp, term = key, key
        groups_terms.setdefault(grp, []).append(term)

    for grp, terms in groups_terms.items():
        for j, term in enumerate(terms):
            # Try "Group:Term" key first, then bare key
            key = f"{grp}:{term}"
            if key in vs.tau2:
                var = vs.tau2[key]
            else:
                var = vs.tau2[grp]  # bare key (no group prefix)
            sd = np.sqrt(var) if var >= 0 else 0.0
            # Correlation: only for 2nd+ term in a group
            corr_str = ""
            if j > 0 and vs.rho:
                # Find matching correlation
                for rho_key, rho_val in vs.rho.items():
                    rho_parts = rho_key.split(":")
                    if len(rho_parts) == 2:
                        t1, t2 = rho_parts
                        if (t1 in terms and t2 in terms) and t2 == term:
                            corr_str = f"{rho_val:.{max(d - 1, 2)}f}"
                            break
            # Show group name only on first term of a group
            grp_label = grp if j == 0 else ""
            rows.append((grp_label, term, var, sd, corr_str))

    # Residual row
    rows.append(("Residual", "", vs.sigma2, np.sqrt(vs.sigma2), ""))

    # Compute column widths
    grp_w = max(max(len(r[0]) for r in rows), 6)
    name_w = max(max(len(r[1]) for r in rows), 4)
    var_w = max(d + 5, 8)
    sd_w = max(d + 4, 8)

    if has_ci:
        conf = int(round((vs.conf_level or 0.95) * 100))
        method_note = vs.ci_method or "profile"
        lines.append(
            f" {'Groups':<{grp_w}}  {'Name':<{name_w}}  "
            f"{'Variance':>{var_w}}  {'Std.Dev.':>{sd_w}}  {'Corr':>6}"
            f"  CI [{conf}%] ({method_note})"
        )
    else:
        lines.append(
            f" {'Groups':<{grp_w}}  {'Name':<{name_w}}  "
            f"{'Variance':>{var_w}}  {'Std.Dev.':>{sd_w}}  {'Corr':>6}"
        )

    for grp_label, term, var, sd, corr_str in rows:
        base = (
            f" {grp_label:<{grp_w}}  {term:<{name_w}}  "
            f"{var:>{var_w}.{d}f}  {sd:>{sd_w}.{d}f}  {corr_str:>6}"
        )
        # Append CI if available
        if has_ci and vs.ci_lower is not None:
            # Determine component key for CI lookup
            if term == "":
                comp_key = "sigma2"
            else:
                comp_key = f"tau2_{grp_label or ''}{':' + term if grp_label else term}"
                # Try exact match first
                if comp_key not in (vs.ci_lower or {}):
                    # Fallback: search for matching key
                    for ckey in vs.ci_lower:
                        if term in ckey:
                            comp_key = ckey
                            break
            if comp_key in (vs.ci_lower or {}):
                lo = vs.ci_lower[comp_key]
                hi = (
                    vs.ci_upper[comp_key]
                    if vs.ci_upper is not None and comp_key in vs.ci_upper
                    else float("nan")
                )
                base += f"  [{lo:.{d}f}, {hi:.{d}f}]"
        lines.append(base)

    # ICC line (our addition, not in R)
    if vs.icc is not None:
        lines.append(f" ICC: {vs.icc:.{d}f}")

    return lines


def _format_fixed_effects_corr(
    bundle: DataBundle,
    fit: FitState,
    *,
    digits: int = 3,
) -> list[str]:
    """Format correlation matrix of fixed effects (lower triangle).

    Matches R's ``Correlation of Fixed Effects`` section.

    Args:
        bundle: Data bundle with term names.
        fit: Fitting results with vcov matrix.
        digits: Decimal places.

    Returns:
        List of formatted lines (empty if only 1 coefficient).
    """
    term_names = bundle.X_names
    p = len(term_names)
    if p < 2 or fit.vcov is None:
        return []

    # Compute correlation from vcov
    vcov = np.asarray(fit.vcov, dtype=float)
    diag = np.sqrt(np.diag(vcov))
    # Guard against zero diag
    diag = np.where(diag == 0, 1.0, diag)
    corr = vcov / np.outer(diag, diag)

    lines: list[str] = ["Correlation of Fixed Effects:"]

    # Abbreviate names for column headers (R uses 6-char abbreviations)
    abbrev_len = min(max(6, digits + 3), 10)
    abbrevs = [n[:abbrev_len] for n in term_names]
    # Only show columns 0..p-2 (lower triangle reference columns)
    col_w = max(abbrev_len, digits + 3)
    row_w = max(max(len(n) for n in term_names), 8)

    # Header: row label + column headers for terms 0..p-2
    header = f"{'':>{row_w}}"
    for j in range(p - 1):
        header += f"  {abbrevs[j]:>{col_w}}"
    lines.append(header)

    # Rows: term[1]..term[p-1], showing lower triangle
    for i in range(1, p):
        row = f"{term_names[i]:>{row_w}}"
        for j in range(min(i, p - 1)):
            row += f"  {corr[i, j]:>{col_w}.{digits}f}"
        lines.append(row)

    lines.append("")
    return lines


# =============================================================================
# R-style summary: explore path
# =============================================================================


def _format_r_explore(
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    mee: MeeState | JointTestState,
    digits: int,
) -> str:
    """Format R-style summary for the explore path.

    Args:
        spec: Model specification.
        bundle: Data bundle.
        fit: Fitting results.
        mee: Marginal effects or joint test state.
        digits: Decimal places.

    Returns:
        Formatted summary string.
    """
    from bossanova.internal.containers import JointTestState as JTS

    lines: list[str] = []
    d = digits

    # Header
    lines.append(f"{_model_type_name(spec)}: {spec.formula}")
    lines.append("")

    # Branch on state type
    if isinstance(mee, JTS):
        lines.extend(_format_joint_test_table(mee, digits=d))
        lines.append("")
        lines.extend(_format_model_stats_brief(spec, bundle, fit, digits=d))
        return "\n".join(lines)

    # MeeState branch — section header
    how_label = "MEM" if mee.how == "mem" else "AME"
    type_label = mee.type.capitalize()
    scale_note = (
        f" [{mee.effect_scale} scale]" if mee.effect_scale == "response" else ""
    )
    lines.append(
        f"Marginal {type_label} ({how_label}): {mee.explore_formula}{scale_note}"
    )

    if mee.has_inference:
        desc = _infer_method_desc(mee.inference_method)
        lines.append(f"Inference: {desc}")

    if mee.contrast_method is not None and mee.n_contrast_levels is not None:
        adj = mee.contrast_method.capitalize()
        lines.append(f"P-value adjustment: {adj} ({mee.n_contrast_levels} levels)")

    lines.append("")

    # Effects table
    lines.extend(_format_effects_table(mee, digits=d))
    lines.append("")

    # Significance codes
    if mee.p_value is not None:
        lines.append("---")
        lines.append(_SIGNIF_LEGEND)
        lines.append("")

    # Brief model stats footer
    lines.extend(_format_model_stats_brief(spec, bundle, fit, digits=d))

    return "\n".join(lines)


def _format_effects_table(mee: MeeState, *, digits: int = 3) -> list[str]:
    """Format effects table for MeeState.

    Adapts columns based on inference method: full (asymp/boot) includes CIs,
    perm omits CIs, bare shows only estimate.

    Args:
        mee: Marginal effects state.
        digits: Decimal places.

    Returns:
        List of formatted table lines.
    """
    d = digits
    grid_cols = mee.grid.columns
    grid_data = mee.grid.to_dicts()
    estimates = mee.estimate

    # Build grid key strings to determine column width
    all_keys = [" | ".join(str(row[c]) for c in grid_cols) for row in grid_data]
    col_label = " | ".join(grid_cols)
    key_w = max(max(len(k) for k in all_keys), len(col_label))
    key_w = max(key_w, 12)

    est_w = d + 5
    se_w = d + 4
    ci_w = d + 5
    stat_w = d + 4
    lines: list[str] = []

    if not mee.has_inference:
        # Bare: grid + estimate
        header = f"{col_label:>{key_w}}  {'estimate':>{est_w}}"
        lines.append(header)
        for i, key in enumerate(all_keys):
            lines.append(f"{key:>{key_w}}  {estimates[i]:>{est_w}.{d}f}")

    elif mee.inference_method == "perm":
        # Perm: no CIs
        header = (
            f"{col_label:>{key_w}}  {'estimate':>{est_w}}  {'se':>{se_w}}  "
            f"{'t value':>{stat_w}}  {'Pr(>|t|)':>8}    "
        )
        lines.append(header)
        for i, key in enumerate(all_keys):
            p_str = _format_pvalue(mee.p_value[i], digits=d)
            sig = _significance_code(mee.p_value[i])
            lines.append(
                f"{key:>{key_w}}  {estimates[i]:>{est_w}.{d}f}  "
                f"{mee.se[i]:>{se_w}.{d}f}  "
                f"{mee.statistic[i]:>{stat_w}.{max(d - 1, 1)}f}  "
                f"{p_str:>8} {sig}"
            )

    else:
        # Full: asymp or boot — includes CIs
        lo_lbl, hi_lbl = _ci_header(mee.conf_level or 0.95)
        header = (
            f"{col_label:>{key_w}}  {'estimate':>{est_w}}  {'se':>{se_w}}  "
            f"{'[' + lo_lbl:>{ci_w}}  {hi_lbl + ']':>{ci_w}}  "
            f"{'t value':>{stat_w}}  {'Pr(>|t|)':>8}    "
        )
        lines.append(header)
        for i, key in enumerate(all_keys):
            p_str = _format_pvalue(mee.p_value[i], digits=d)
            sig = _significance_code(mee.p_value[i])
            ci_lo = mee.ci_lower[i] if mee.ci_lower is not None else float("nan")
            ci_hi = mee.ci_upper[i] if mee.ci_upper is not None else float("nan")
            lines.append(
                f"{key:>{key_w}}  {estimates[i]:>{est_w}.{d}f}  "
                f"{mee.se[i]:>{se_w}.{d}f}  "
                f"{ci_lo:>{ci_w}.{d}f}  {ci_hi:>{ci_w}.{d}f}  "
                f"{mee.statistic[i]:>{stat_w}.{max(d - 1, 1)}f}  "
                f"{p_str:>8} {sig}"
            )

    return lines


def _format_joint_test_table(jt: JointTestState, *, digits: int = 3) -> list[str]:
    """Format ANOVA-style joint test table.

    Args:
        jt: Joint test state.
        digits: Decimal places.

    Returns:
        List of formatted lines.
    """
    d = digits
    lines: list[str] = [f"Analysis of Variance (Type {jt.ss_type})", ""]

    stat_col = "F" if jt.test_type == "F" else "Chisq"
    has_df2 = jt.df2 is not None
    p_col = "Pr(>F)" if jt.test_type == "F" else "Pr(>Chisq)"
    max_tw = max(max(len(t) for t in jt.terms), 12)

    if has_df2:
        header = (
            f"{'':>{max_tw}}  {'df1':>5}  {'df2':>6}  {stat_col:>10}  {p_col:>9}    "
        )
    else:
        header = f"{'':>{max_tw}}  {'df1':>5}  {stat_col:>10}  {p_col:>10}    "
    lines.append(header)

    for i, term in enumerate(jt.terms):
        p_str = _format_pvalue(jt.p_value[i], digits=d)
        sig = _significance_code(jt.p_value[i])
        if has_df2:
            lines.append(
                f"{term:>{max_tw}}  {jt.df1[i]:>5.0f}  {jt.df2[i]:>6.1f}  "
                f"{jt.statistic[i]:>10.{d}f}  {p_str:>9} {sig}"
            )
        else:
            lines.append(
                f"{term:>{max_tw}}  {jt.df1[i]:>5.0f}  "
                f"{jt.statistic[i]:>10.{d}f}  {p_str:>10} {sig}"
            )

    lines.append("")
    lines.append("---")
    lines.append(_SIGNIF_LEGEND)
    return lines


def _format_model_stats_brief(
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    *,
    digits: int = 3,
) -> list[str]:
    """One-line model statistics footer for explore path.

    Args:
        spec: Model specification.
        bundle: Data bundle.
        fit: Fitting results.
        digits: Decimal places.

    Returns:
        List of formatted lines.
    """
    d = digits
    k = len(fit.coef)
    if fit.theta is not None:
        k += len(fit.theta)
    aic = compute_aic(float(fit.loglik), k)

    if spec.family == "gaussian" and not spec.has_random_effects:
        r_sq, _ = compute_r_squared(bundle.y, fit.residuals, bundle.n, bundle.p)
        return [
            f"Model: {_model_type_name(spec)}, n={bundle.n}, "
            f"R\u00b2={r_sq:.{d}f}, AIC={aic:.{max(d - 2, 1)}f}"
        ]
    return [
        f"Model: {_model_type_name(spec)}, n={bundle.n}, AIC={aic:.{max(d - 2, 1)}f}"
    ]


# =============================================================================
# R-style summary: top-level dispatcher
# =============================================================================


def _format_r_style(
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    params_inference: InferenceState | None,
    mee: MeeState | JointTestState | None,
    cv: CVState | None,
    varying_spread: VaryingSpreadState | None,
    last_op: str | None,
    digits: int = 3,
) -> str:
    """Format model summary in R style, dispatching on last operation.

    Args:
        spec: Model specification.
        bundle: Data bundle.
        fit: Fitting results.
        params_inference: Optional inference state.
        mee: Optional marginal effects or joint test state.
        cv: Optional CV state.
        varying_spread: Optional variance components.
        last_op: Last operation performed.
        digits: Decimal places.

    Returns:
        Formatted summary string.
    """
    if last_op == "explore" and mee is not None:
        return _format_r_explore(spec, bundle, fit, mee, digits)
    return _format_r_params(
        spec, bundle, fit, params_inference, cv, varying_spread, digits
    )


# =============================================================================
# Compact summary
# =============================================================================


def _format_compact_params(
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    params_inference: InferenceState | None,
    cv: CVState | None,
    digits: int,
) -> str:
    """Format compact summary for params path.

    Args:
        spec: Model specification.
        bundle: Data bundle.
        fit: Fitting results.
        params_inference: Optional inference state.
        cv: Optional CV state.
        digits: Decimal places.

    Returns:
        Formatted compact string.
    """
    lines: list[str] = []
    d = digits

    # First line: model info
    model_info_parts = [f"model({spec.formula})"]
    if spec.family == "gaussian" and not spec.has_random_effects:
        r_squared, _ = compute_r_squared(bundle.y, fit.residuals, bundle.n, bundle.p)
        model_info_parts.append(f"R2={r_squared:.{d}f}")
    else:
        k = len(fit.coef)
        if fit.theta is not None:
            k += len(fit.theta)
        model_info_parts.append(
            f"AIC={compute_aic(float(fit.loglik), k):.{max(d - 2, 1)}f}"
        )
    model_info_parts.append(f"n={bundle.n}")
    lines.append(": ".join([model_info_parts[0], ", ".join(model_info_parts[1:])]))

    # Second line: coefficient summary
    coef_parts: list[str] = []
    term_names = bundle.X_names
    estimates = fit.coef
    method = params_inference.method if params_inference is not None else None

    if (
        method == "cv"
        and params_inference is not None
        and params_inference.pre is not None
    ):
        for i, name in enumerate(term_names):
            coef_parts.append(
                f"{name}: {estimates[i]:.{d}f} (PRE={params_inference.pre[i]:.{d}f})"
            )
    elif params_inference is not None:
        for i, name in enumerate(term_names):
            p = params_inference.p_value[i]
            if p < 0.001:
                p_str = "p<0.001"
            elif p < 0.01:
                p_str = "p<0.01"
            elif p < 0.05:
                p_str = "p<0.05"
            else:
                p_str = f"p={p:.{max(d - 1, 1)}f}"
            coef_parts.append(f"{name}: {estimates[i]:.{d}f} ({p_str})")
    else:
        for i, name in enumerate(term_names):
            coef_parts.append(f"{name}: {estimates[i]:.{d}f}")
    lines.append(", ".join(coef_parts))

    # CV metrics if available
    if cv is not None:
        lines.append(
            f"CV ({cv.k}-fold): MSE={cv.mse:.{d}f}, "
            f"RMSE={cv.rmse:.{d}f}, "
            f"MAE={cv.mae:.{d}f}, R\u00b2(OOS)={cv.r_squared:.{d}f}"
        )

    return "\n".join(lines)


def _format_compact_explore(
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    mee: MeeState | JointTestState,
    digits: int,
) -> str:
    """Format compact summary for explore path.

    Args:
        spec: Model specification.
        bundle: Data bundle.
        fit: Fitting results.
        mee: Marginal effects or joint test state.
        digits: Decimal places.

    Returns:
        Formatted compact string.
    """
    from bossanova.internal.containers import JointTestState as JTS

    lines: list[str] = []
    d = digits

    # Line 1: model + quick stats
    k = len(fit.coef) + (len(fit.theta) if fit.theta is not None else 0)
    aic = compute_aic(float(fit.loglik), k)
    if spec.family == "gaussian" and not spec.has_random_effects:
        r_sq, _ = compute_r_squared(bundle.y, fit.residuals, bundle.n, bundle.p)
        lines.append(f"model({spec.formula}): R2={r_sq:.{d}f}, n={bundle.n}")
    else:
        lines.append(
            f"model({spec.formula}): AIC={aic:.{max(d - 2, 1)}f}, n={bundle.n}"
        )

    # Line 2: explore result
    if isinstance(mee, JTS):
        n_sig = int(np.sum(mee.p_value < 0.05))
        lines.append(
            f"ANOVA (Type {mee.ss_type}): {len(mee.terms)} terms, "
            f"{n_sig} significant (p<0.05)"
        )
    else:
        sig_info = ""
        if mee.p_value is not None:
            n_sig = int(np.sum(mee.p_value < 0.05))
            sig_info = f", {n_sig} significant (p<0.05)"
        infer_info = ""
        if mee.has_inference and mee.inference_method:
            infer_info = f" [{mee.inference_method}]"
        lines.append(
            f"{mee.type.capitalize()} ({mee.focal_var}): "
            f"{len(mee.estimate)} estimates{sig_info}{infer_info}"
        )

    return "\n".join(lines)


def _format_compact(
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    params_inference: InferenceState | None,
    mee: MeeState | JointTestState | None,
    cv: CVState | None,
    last_op: str | None,
    digits: int = 3,
) -> str:
    """Format model summary in compact style, dispatching on last operation.

    Args:
        spec: Model specification.
        bundle: Data bundle.
        fit: Fitting results.
        params_inference: Optional inference state.
        mee: Optional marginal effects or joint test state.
        cv: Optional CV state.
        last_op: Last operation performed.
        digits: Decimal places.

    Returns:
        Formatted summary string.
    """
    if last_op == "explore" and mee is not None:
        return _format_compact_explore(spec, bundle, fit, mee, digits)
    return _format_compact_params(spec, bundle, fit, params_inference, cv, digits)


# =============================================================================
# Model-level statistics (kept as public for backward compat)
# =============================================================================


def _format_model_stats(
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    *,
    digits: int = 3,
) -> list[str]:
    """Format model-level statistics.

    Args:
        spec: Model specification.
        bundle: Data bundle.
        fit: Fitting results.
        digits: Decimal places.

    Returns:
        List of formatted statistics lines.
    """
    lines: list[str] = []
    d = digits

    if not spec.has_random_effects:
        # LM/GLM: show residual std error or dispersion
        if fit.sigma is not None:
            lines.append(
                f"Residual std error: {fit.sigma:.{d}f} on {fit.df_resid:.0f} df"
            )
        elif fit.dispersion is not None:
            lines.append(f"Dispersion parameter: {fit.dispersion:.{d}f}")

    if spec.family == "gaussian" and not spec.has_random_effects:
        r_squared, adj_r_squared = compute_r_squared(
            bundle.y, fit.residuals, bundle.n, bundle.p
        )
        lines.append(
            f"Multiple R-squared: {r_squared:.{d}f}, "
            f"Adjusted R-squared: {adj_r_squared:.{d}f}"
        )

    k = len(fit.coef)
    if fit.theta is not None:
        k += len(fit.theta)
    aic = compute_aic(float(fit.loglik), k)
    bic = compute_bic(float(fit.loglik), k, bundle.n)
    lines.append(f"AIC: {aic:.{max(d - 2, 1)}f}, BIC: {bic:.{max(d - 2, 1)}f}")

    return lines


# =============================================================================
# Main entry point
# =============================================================================


def format_summary(
    *,
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    params_inference: InferenceState | None = None,
    mee: MeeState | JointTestState | None = None,
    cv: CVState | None = None,
    varying_spread: VaryingSpreadState | None = None,
    last_op: str | None = None,
    style: str = "r",
    digits: int = 3,
) -> FormattedText:
    """Format a model summary.

    Adapts output based on ``last_op``: when the last operation was
    ``"explore"``, shows an effects-focused summary; otherwise shows
    the standard params-focused summary. Handles all inference methods
    (asymptotic, bootstrap, permutation, cross-validation).

    Args:
        spec: Model specification.
        bundle: Data bundle with design matrices.
        fit: Fitting results.
        params_inference: Optional inference state for parameters.
        mee: Optional marginal effects or joint test state.
        cv: Optional cross-validation state.
        varying_spread: Optional variance components for mixed models.
        last_op: Last operation performed on the model.
        style: Output style ("r" or "compact").
        digits: Number of decimal places for numeric output.

    Returns:
        FormattedText that displays without needing ``print()``.

    Raises:
        ValueError: If style is not recognized.

    Examples:
        >>> m = model("y ~ x", data).fit().infer()
        >>> m.summary()  # Params-focused R-style summary

        >>> m.explore("pairwise(treatment)").infer()
        >>> m.summary()  # Effects-focused summary
    """
    if style == "r":
        text = _format_r_style(
            spec,
            bundle,
            fit,
            params_inference,
            mee,
            cv,
            varying_spread,
            last_op,
            digits=digits,
        )
    elif style == "compact":
        text = _format_compact(
            spec,
            bundle,
            fit,
            params_inference,
            mee,
            cv,
            last_op,
            digits=digits,
        )
    else:
        raise ValueError(f"Unknown summary style: {style!r}. Use 'r' or 'compact'.")
    return FormattedText(text)
