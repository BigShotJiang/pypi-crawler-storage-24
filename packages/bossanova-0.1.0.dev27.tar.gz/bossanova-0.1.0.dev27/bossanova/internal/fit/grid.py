"""Prediction grid construction for formula-mode predictions.

Provides ``parse_predict_formula()`` which translates an explore-style
formula into a prediction grid (Polars DataFrame), and
``build_predict_grid()`` which assembles the Cartesian-product grid from
column specifications.

Shared by ``model.predict()`` (formula mode) and ``viz/predict.py``
(``plot_predict``).
"""

from __future__ import annotations

from itertools import product
from typing import TYPE_CHECKING, Any, Literal

import numpy as np
import polars as pl

__all__ = [
    "build_predict_grid",
    "compute_predictions_from_formula",
    "parse_predict_formula",
    "resolve_condition_values",
]


if TYPE_CHECKING:
    from bossanova.internal.containers import PredictionState
    from bossanova.internal.containers.structs.explore import Condition


# ---------------------------------------------------------------------------
# Condition resolver (extracted from viz/predict.py)
# ---------------------------------------------------------------------------


def resolve_condition_values(
    cond: Condition,
    data: pl.DataFrame,
) -> list | None:
    """Resolve a :class:`Condition` to concrete values or ``None``.

    Args:
        cond: A ``Condition`` from :func:`parse_explore_formula`.
        data: The model's training data.

    Returns:
        A list of concrete values if the condition specifies explicit
        values (``at_values``, ``at_range``, ``at_quantile``), or
        ``None`` for bare conditions (use all unique levels).
    """
    if cond.at_values is not None:
        return list(cond.at_values)
    if cond.at_range is not None:
        col_data = data[cond.var].drop_nulls().to_numpy()
        return list(
            np.linspace(np.nanmin(col_data), np.nanmax(col_data), cond.at_range)
        )
    if cond.at_quantile is not None:
        col_data = data[cond.var].drop_nulls().to_numpy()
        quantiles = np.linspace(0, 1, cond.at_quantile + 2)[1:-1]
        return list(np.quantile(col_data, quantiles))
    return None


# ---------------------------------------------------------------------------
# Categorical detection (matches viz/core_viz.py logic)
# ---------------------------------------------------------------------------


def _is_categorical(data: pl.DataFrame, col_name: str) -> bool:
    """Check if a column is categorical.

    Args:
        data: DataFrame containing the column.
        col_name: Column name.

    Returns:
        True if the column is string/categorical dtype or has <10 unique values.
    """
    dtype = data[col_name].dtype
    return (
        dtype in (pl.Categorical, pl.Utf8, pl.String) or data[col_name].n_unique() < 10
    )


# ---------------------------------------------------------------------------
# Grid builder
# ---------------------------------------------------------------------------


def build_predict_grid(
    data: pl.DataFrame,
    focal_var: str,
    response_col: str,
    grouping_factors: tuple[str, ...],
    *,
    focal_values: list[float | str] | None = None,
    n_points: int | Literal["data"] = 50,
    varying_vars: list[str] | None = None,
    at: dict[str, Any] | None = None,
) -> pl.DataFrame:
    """Build a Cartesian-product prediction grid.

    Creates a grid where the focal variable is varied, condition variables
    are expanded, and all other predictors are held at reference values
    (mean for continuous, first sorted level for categorical). Grouping
    factors and the response column are excluded.

    Args:
        data: Training data (Polars DataFrame).
        focal_var: The predictor to vary across the grid.
        response_col: Response column name (excluded from grid).
        grouping_factors: Random-effect grouping variables (excluded).
        focal_values: Explicit values for the focal variable. Overrides
            default linspace/unique-levels logic.
        n_points: Number of grid points for continuous focal variables.
            Use ``"data"`` to use actual observed unique values.
        varying_vars: Condition variables to expand (all unique levels).
        at: Dict of pinned values. Scalar = single constant, list = expand.

    Returns:
        Polars DataFrame with the Cartesian-product prediction grid.
    """
    at = at or {}
    varying_vars = varying_vars or []
    grid_data: dict[str, list] = {}

    for col_name in data.columns:
        if col_name == response_col:
            continue
        if col_name in grouping_factors:
            continue

        if col_name == focal_var:
            # Focal variable: vary across grid
            if focal_values is not None:
                grid_data[col_name] = list(focal_values)
            elif _is_categorical(data, col_name):
                grid_data[col_name] = data[col_name].unique().sort().to_list()
            elif n_points == "data":
                grid_data[col_name] = sorted(
                    data[col_name].unique().drop_nulls().to_list()
                )
            else:
                col_data = data[col_name].to_numpy()
                grid_data[col_name] = list(
                    np.linspace(np.nanmin(col_data), np.nanmax(col_data), n_points)
                )
        elif col_name in at:
            # Pinned or expanded via at dict
            val = at[col_name]
            grid_data[col_name] = list(val) if isinstance(val, list) else [val]
        elif col_name in varying_vars:
            # Condition variable: all unique levels
            grid_data[col_name] = data[col_name].unique().sort().to_list()
        else:
            # Reference value: mean for continuous, first sorted level for categorical
            if _is_categorical(data, col_name):
                grid_data[col_name] = [data[col_name].unique().sort().to_list()[0]]
            else:
                grid_data[col_name] = [float(data[col_name].mean())]

    # Cartesian product
    keys = list(grid_data.keys())
    values = [grid_data[k] for k in keys]
    rows = [dict(zip(keys, combo)) for combo in product(*values)]
    return pl.DataFrame(rows)


# ---------------------------------------------------------------------------
# Formula parser / orchestrator
# ---------------------------------------------------------------------------


def parse_predict_formula(
    formula: str,
    data: pl.DataFrame,
    response_col: str,
    grouping_factors: tuple[str, ...],
    *,
    n_points: int | Literal["data"] = 50,
) -> tuple[pl.DataFrame, list[str]]:
    """Parse an explore-style formula and build a prediction grid.

    Translates the formula via :func:`parse_explore_formula`, rejects
    contrast formulas, and delegates to :func:`build_predict_grid`.

    Args:
        formula: Explore-style formula (e.g. ``"wt ~ cyl"``).
        data: Training data.
        response_col: Response column name.
        grouping_factors: Random-effect grouping variables.
        n_points: Number of grid points for continuous focal variables.

    Returns:
        Tuple of (grid DataFrame, list of grid column names for output).
        The grid column names are the focal var plus any condition vars
        (the columns that vary across the grid, excluding reference-value
        columns).

    Raises:
        ValueError: If the formula contains contrasts.
    """
    from bossanova.internal.marginal import parse_explore_formula

    spec = parse_explore_formula(formula)

    # Reject contrast formulas — they belong in explore()
    if spec.has_contrast:
        raise ValueError(
            f"Contrast formula {formula!r} is not supported by predict(). "
            "Use explore() for contrasts like pairwise(), sequential(), etc."
        )
    if spec.has_rhs_contrasts:
        raise ValueError(
            f"Contrast formula {formula!r} is not supported by predict(). "
            "Use explore() for contrasts like Drug[A - B]."
        )

    # Resolve focal variable modifiers
    focal_values: list[float | str] | None = None
    effective_n_points = n_points

    if spec.focal_at_range is not None:
        effective_n_points = spec.focal_at_range
    elif spec.focal_at_values is not None:
        focal_values = list(spec.focal_at_values)
    elif spec.focal_at_quantile is not None:
        col_data = data[spec.focal_var].drop_nulls().to_numpy()
        quantiles = np.linspace(0, 1, spec.focal_at_quantile + 2)[1:-1]
        focal_values = list(np.quantile(col_data, quantiles))

    # Classify conditions into varying vars vs at-pinned
    at: dict[str, Any] = {}
    varying_vars: list[str] = []

    for cond in spec.conditions:
        resolved = resolve_condition_values(cond, data)
        if resolved is not None and len(resolved) == 1:
            # Single pinned value
            at[cond.var] = resolved[0]
        else:
            varying_vars.append(cond.var)
            if resolved is not None:
                at[cond.var] = resolved

    # Build the full prediction grid (all model columns, reference values)
    full_grid = build_predict_grid(
        data=data,
        focal_var=spec.focal_var,
        response_col=response_col,
        grouping_factors=grouping_factors,
        focal_values=focal_values,
        n_points=effective_n_points,
        varying_vars=varying_vars,
        at=at,
    )

    # Determine which columns are "grid columns" for output display.
    # These are columns that actually vary across the grid (focal + conditions).
    grid_cols = [spec.focal_var] + varying_vars
    # Also include at-pinned conditions with multiple values
    for cond in spec.conditions:
        if (
            cond.var not in grid_cols
            and cond.var in at
            and isinstance(at[cond.var], list)
        ):
            grid_cols.append(cond.var)

    return full_grid, grid_cols


# ---------------------------------------------------------------------------
# Formula-mode predict: parse → grid → predict → attach grid columns
# ---------------------------------------------------------------------------


def compute_predictions_from_formula(
    formula: str,
    data: pl.DataFrame,
    spec: object,
    bundle: object,
    fit: object,
    formula_spec: object,
    pred_type: str,
    varying: str,
    allow_new_levels: bool,
    n_points: int | Literal["data"],
) -> "PredictionState":
    """Parse a predict formula, build the grid, compute predictions, and attach grid columns.

    Combines ``parse_predict_formula``, ``compute_predictions``, and
    grid-column attachment into a single call for ``model.predict()``
    formula mode.

    Args:
        formula: Explore-style formula (e.g. ``"wt ~ cyl"``).
        data: Training data.
        spec: Model specification.
        bundle: Data bundle.
        fit: Fitted model state.
        formula_spec: Learned formula spec for newdata evaluation.
        pred_type: Prediction scale (``"response"`` or ``"link"``).
        varying: RE handling (``"exclude"`` or ``"include"``).
        allow_new_levels: If True, new groups predict at population level.
        n_points: Number of grid points for continuous focal variables.

    Returns:
        PredictionState with grid columns attached.
    """
    import attrs

    from bossanova.internal.fit.predict import compute_predictions

    response_col = spec.response_var
    grouping = bundle.re_metadata.grouping_vars if spec.has_random_effects else ()

    full_grid, grid_cols = parse_predict_formula(
        formula, data, response_col, grouping, n_points=n_points
    )

    pred = compute_predictions(
        spec=spec,
        bundle=bundle,
        fit=fit,
        formula_spec=formula_spec,
        training_data=data,
        newdata=full_grid,
        pred_type=pred_type,
        varying=varying,
        allow_new_levels=allow_new_levels,
    )

    # Attach output grid (only the varying columns)
    output_grid = full_grid.select([c for c in grid_cols if c in full_grid.columns])
    return attrs.evolve(pred, grid=output_grid)
