"""Model fitting, diagnostics, convergence, varying parameters, and prediction.

Call chain:
    model.fit() -> fit_model() -> resolve_solver() -> fit_ols_qr / fit_glm_irls / fit_lmer_pls / fit_glmer_pirls
"""

from bossanova.internal.fit.convergence import check_convergence
from bossanova.internal.fit.diagnostics import (
    augment_data_with_diagnostics,
    compute_diagnostics,
    compute_metadata,
    compute_optimizer_diagnostics,
    compute_r_squared,
)
from bossanova.internal.fit.dispatch import (
    VALID_SOLVERS,
    fit_model,
    parse_fit_kwargs,
    resolve_solver,
    validate_fit_method,
)
from bossanova.internal.fit.grid import (
    build_predict_grid,
    compute_predictions_from_formula,
    parse_predict_formula,
    resolve_condition_values,
)
from bossanova.internal.fit.glm import (
    fit_glm_irls,
)
from bossanova.internal.fit.glmer import (
    fit_glmer_pirls,
)
from bossanova.internal.fit.lmer import (
    fit_lmer_pls,
)
from bossanova.internal.fit.ols import (
    fit_ols_qr,
)
from bossanova.internal.fit.lifecycle import FitResult, execute_fit
from bossanova.internal.fit.varying import (
    build_mixed_post_fit_state,
    compute_varying_spread_state,
    compute_varying_state,
    per_factor_re_info,
)
from bossanova.internal.maths.solvers.heuristics import get_theta_lower_bounds

__all__ = [
    "VALID_SOLVERS",
    "FitResult",
    "augment_data_with_diagnostics",
    "build_mixed_post_fit_state",
    "build_predict_grid",
    "check_convergence",
    "compute_diagnostics",
    "compute_metadata",
    "compute_optimizer_diagnostics",
    "compute_predictions_from_formula",
    "compute_r_squared",
    "compute_varying_spread_state",
    "compute_varying_state",
    "execute_fit",
    "fit_glm_irls",
    "fit_glmer_pirls",
    "fit_lmer_pls",
    "fit_model",
    "fit_ols_qr",
    "get_theta_lower_bounds",
    "parse_fit_kwargs",
    "parse_predict_formula",
    "per_factor_re_info",
    "resolve_condition_values",
    "resolve_solver",
    "validate_fit_method",
]
