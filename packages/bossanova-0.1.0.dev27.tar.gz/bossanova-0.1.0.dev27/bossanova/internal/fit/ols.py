"""OLS fitting via QR decomposition."""

from __future__ import annotations

import numpy as np

from bossanova.internal.containers import (
    DataBundle,
    FitState,
    ModelSpec,
    build_fit_state,
)
from bossanova.internal.maths.inference.diagnostics import compute_leverage
from bossanova.internal.maths.linalg import qr_solve

__all__ = ["fit_ols_qr"]


def fit_ols_qr(
    spec: ModelSpec,  # noqa: ARG001
    bundle: DataBundle,
) -> FitState:
    """Fit ordinary or weighted least squares using QR decomposition.

    Supports observation weights (WLS) and offset terms. When weights
    are present, solves the transformed system sqrt(W)*X, sqrt(W)*y
    via QR decomposition, which yields WLS coefficients and vcov
    directly. Offsets are subtracted from y before fitting and added
    back to fitted values.

    Algorithm:
        1. Subtract offset from y (if present): y_adj = y - offset
        2. Apply weights (if present): X_w = sqrt(w)*X, y_w = sqrt(w)*y_adj
        3. QR decompose X_w with column pivoting for stability
        4. Solve R * beta = Q.T @ y_w via back-substitution
        5. Recompute original-scale: fitted = X @ beta + offset, resid = y - fitted
        6. vcov = sigma_w^2 * (X'WX)^{-1}
        7. Leverage from (possibly weighted) hat matrix

    Weighted Log-Likelihood:
        Matches R's ``logLik.lm`` formula::

            L = 0.5*sum(log(w)) - n/2 * (log(2*pi) + log(RSS_w/n) + 1)

        The ``0.5*sum(log(w))`` term is the Jacobian from the weight
        transformation.

    Args:
        spec: Model specification (unused for OLS, included for interface
            consistency with other fitters).
        bundle: Data bundle containing:
            - X: Design matrix (n x p)
            - y: Response vector (n,)
            - weights: Observation weights (n,) or None for OLS
            - offset: Offset vector (n,) or None

    Returns:
        FitState containing:
            - coef: Coefficient estimates, shape (p,)
            - vcov: Variance-covariance matrix, shape (p, p)
            - fitted: Fitted values X @ coef + offset, shape (n,)
            - residuals: y - fitted, shape (n,)
            - leverage: Hat matrix diagonal, shape (n,)
            - df_resid: Residual degrees of freedom (n - rank)
            - loglik: Gaussian log-likelihood (weighted if applicable)
            - sigma: Residual standard deviation
            - converged: Always True (closed-form solution)
            - n_iter: Always 1 (single step)

    Examples:
        >>> import numpy as np
        >>> from bossanova.internal.containers import build_model_spec, DataBundle
        >>> spec = build_model_spec(
        ...     formula="y ~ x",
        ...     response_var="y",
        ...     fixed_terms=["Intercept", "x"],
        ... )
        >>> bundle = DataBundle(
        ...     X=np.array([[1.0, 1.0], [1.0, 2.0], [1.0, 3.0]]),
        ...     y=np.array([2.0, 4.0, 6.0]),
        ...     X_names=["Intercept", "x"],
        ...     y_name="y",
        ...     valid_mask=np.array([True, True, True]),
        ...     n_total=3,
        ... )
        >>> state = fit_ols_qr(spec, bundle)
        >>> np.allclose(state.fitted + state.residuals, bundle.y)
        True
        >>> np.allclose(state.coef, [0.0, 2.0])  # Perfect fit: y = 2x
        True
    """
    X, y = bundle.X, bundle.y
    n = X.shape[0]
    weights = bundle.weights
    offset = bundle.offset

    # Apply offset: adjust response before fitting
    y_adj = y - offset if offset is not None else y

    # Apply weights: transform to WLS via sqrt(W) pre-multiplication
    if weights is not None:
        w_sqrt = np.sqrt(weights)
        X_w = w_sqrt[:, None] * X
        y_w = w_sqrt * y_adj
    else:
        X_w = X
        y_w = y_adj

    # Solve via QR decomposition on (possibly transformed) system
    result = qr_solve(X_w, y_w)

    # Recompute original-scale quantities
    coef = result.coef
    fitted = X @ coef
    if offset is not None:
        fitted = fitted + offset
    residuals = y - fitted

    # Degrees of freedom
    df_resid = result.df_resid

    # Weighted residual sum of squares for sigma
    if weights is not None:
        w_resid = residuals
        rss_w = float(np.sum(weights * w_resid**2))
    else:
        rss_w = float(np.sum(residuals**2))

    sigma = float(np.sqrt(rss_w / df_resid)) if df_resid > 0 else 0.0

    # Variance-covariance: sigma^2 * (X'WX)^{-1}
    # qr_solve gives vcov = sigma2_transformed * (R'R)^{-1} = (X_w'X_w)^{-1} * sigma2_w
    # We need sigma^2 * (X_w'X_w)^{-1} where sigma^2 is our weighted sigma
    # Extract (X_w'X_w)^{-1} by dividing out qr_solve's sigma2
    if result.sigma2 > 0:
        XtWX_inv = result.vcov / result.sigma2
    else:
        XtWX_inv = result.vcov
    vcov = sigma**2 * XtWX_inv

    # Leverage from (possibly weighted) design matrix
    leverage = compute_leverage(X, weights=weights)

    # Log-likelihood (Gaussian)
    # Unweighted: L = -n/2 * (log(2π) + log(RSS/n) + 1)
    # Weighted:   L = 0.5*Σlog(w) - n/2 * (log(2π) + log(RSS_w/n) + 1)
    if rss_w > 0:
        loglik = -n / 2 * (np.log(2 * np.pi) + np.log(rss_w / n) + 1)
        if weights is not None:
            loglik += 0.5 * float(np.sum(np.log(weights)))
    else:
        loglik = np.inf

    return build_fit_state(
        coef=coef,
        vcov=vcov,
        fitted=fitted,
        residuals=residuals,
        leverage=leverage,
        df_resid=float(df_resid),
        loglik=float(loglik),
        sigma=sigma,
        converged=True,
        n_iter=1,
    )
