"""Model-level diagnostics computation.

Pure functions that compute model diagnostics from containers. These were
extracted from ``model/core.py`` to keep the model class as thin glue.

Functions:
    compute_diagnostics: Build the diagnostics DataFrame for any model type.
    compute_optimizer_diagnostics: Build optimizer convergence diagnostics.
    augment_data_with_diagnostics: Add fitted, resid, hat, etc. columns.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import polars as pl

from bossanova.internal.containers.schemas import (
    AugmentedDataCols,
    Col,
    DiagnosticsGaussian,
    DiagnosticsGlm,
    DiagnosticsLmer,
    MetadataBase,
    MetadataMixed,
)
from bossanova.internal.maths.family import ESTIMATED_DISPERSION_FAMILIES

# Schema lookup for compute_diagnostics — each model type maps to its
# canonical diagnostics schema (used as ``schema=`` in pl.DataFrame).
_DIAGNOSTICS_SCHEMA = {
    "lm": DiagnosticsGaussian,
    "glm": DiagnosticsGlm,
    "lmer": DiagnosticsLmer,
    "glmer": DiagnosticsLmer,
}

if TYPE_CHECKING:
    import numpy as np

    from bossanova.internal.containers import (
        CVState,
        DataBundle,
        FitState,
        ModelSpec,
        VaryingSpreadState,
    )

__all__ = [
    "augment_data_with_diagnostics",
    "compute_diagnostics",
    "compute_metadata",
    "compute_optimizer_diagnostics",
    "compute_r_squared",
]


def compute_metadata(
    *,
    bundle: DataBundle,
) -> pl.DataFrame:
    """Compute model metadata as a single-row DataFrame.

    Returns sample/structural info about the model: observation counts,
    parameter count, and group counts (for mixed models).

    Args:
        bundle: Data bundle (for n, n_total, p, re_metadata).

    Returns:
        Single-row Polars DataFrame with model metadata.
    """
    data: dict[str, list] = {
        Col.NOBS: [bundle.n],
        Col.NOBS_TOTAL: [bundle.n_total],
        Col.NOBS_MISSING: [bundle.n_total - bundle.n],
        Col.NPARAMS: [bundle.p],
    }

    if bundle.re_metadata is not None:
        data[Col.NGROUPS] = [sum(bundle.re_metadata.n_groups.values())]

    schema = MetadataMixed if bundle.re_metadata is not None else MetadataBase
    return pl.DataFrame(data, schema=schema)


def compute_diagnostics(
    *,
    model_type: str,
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    coef_for_predict: np.ndarray,
    varying_spread: VaryingSpreadState | None,
    cv: CVState | None,
    has_intercept: bool = True,
) -> pl.DataFrame:
    """Compute model-level diagnostics as a single-row DataFrame.

    Builds goodness-of-fit diagnostics from fitted model state, with
    columns varying by model type (lm, glm, lmer, glmer).

    Args:
        model_type: One of "lm", "glm", "lmer", "glmer".
        spec: Model specification (for family).
        bundle: Data bundle (for n, rank, X, y, re_metadata).
        fit: Fitted state (for coefficients, residuals, loglik, etc.).
        coef_for_predict: Coefficients safe for matrix multiplication
            (NaN replaced by 0 for rank-deficient models).
        varying_spread: Random effects variance components (mixed models).
        cv: Cross-validation state, or None.
        has_intercept: Whether the model includes an intercept. Affects
            R² computation (centered vs uncentered SS_tot).

    Returns:
        Single-row Polars DataFrame with model diagnostics. See
        ``model.diagnostics`` for full column documentation.
    """
    from bossanova.internal.maths.inference import (
        compute_aic,
        compute_bic,
    )

    n = bundle.n
    rank = bundle.rank
    # Exclude intercept from model df (if present)
    df_model = float(rank - 1) if has_intercept else float(rank)
    df_resid = fit.df_resid
    loglik = fit.loglik

    k = rank  # Only estimable params count for AIC/BIC
    if fit.theta is not None:
        k += len(fit.theta)
    # Families with estimated dispersion count it as an extra parameter
    if spec.family in ESTIMATED_DISPERSION_FAMILIES:
        k += 1
    aic = compute_aic(loglik, k)
    bic = compute_bic(loglik, k, n)

    # Base data for all models
    data: dict[str, list] = {
        Col.DF_MODEL: [df_model],
        Col.DF_RESID: [df_resid],
    }

    if model_type == "lm":
        data.update(_lm_diagnostics(bundle, fit, df_model, df_resid, n, has_intercept))
    elif model_type == "glm":
        data.update(_glm_diagnostics(fit, loglik))
    elif model_type in ("lmer", "glmer"):
        data.update(
            _mixed_diagnostics(bundle, fit, loglik, coef_for_predict, varying_spread)
        )

    data.update({Col.AIC: [aic], Col.BIC: [bic], Col.LOGLIK: [loglik]})

    # Build base diagnostics with schema validation
    df = pl.DataFrame(data, schema=_DIAGNOSTICS_SCHEMA[model_type])

    # CV metrics are dynamic (depend on fold_metrics availability),
    # so append them after schema-validated base construction.
    if cv is not None:
        cv_data: dict[str, list] = {}
        _add_cv_metrics(cv_data, cv)
        df = df.hstack(pl.DataFrame(cv_data))

    return df


def compute_r_squared(
    y: np.ndarray,
    residuals: np.ndarray,
    n: int,
    p: int,
    has_intercept: bool = True,
) -> tuple[float, float]:
    """Compute R-squared and adjusted R-squared from raw arrays.

    For models with an intercept, uses centered SS_tot = sum((y - mean(y))^2).
    For no-intercept models, uses uncentered SS_tot = sum(y^2), matching R's
    ``summary.lm()`` behavior.

    Args:
        y: Response vector of shape (n,).
        residuals: Residual vector of shape (n,).
        n: Number of observations.
        p: Number of parameters (including intercept if present).
        has_intercept: Whether the model includes an intercept.

    Returns:
        Tuple of (R-squared, adjusted R-squared).
    """
    import numpy as np

    ss_res = float(np.sum(residuals**2))

    if has_intercept:
        ss_tot = float(np.sum((y - np.mean(y)) ** 2))
        r_squared = 1 - ss_res / ss_tot if ss_tot > 0 else 0.0
        adj_r_squared = 1 - (1 - r_squared) * (n - 1) / (n - p) if (n - p) > 0 else 0.0
    else:
        # Uncentered R²: 1 - SS_res / SS_tot where SS_tot = sum(y^2)
        ss_tot = float(np.sum(y**2))
        r_squared = 1 - ss_res / ss_tot if ss_tot > 0 else 0.0
        adj_r_squared = 1 - (1 - r_squared) * n / (n - p) if (n - p) > 0 else 0.0

    return r_squared, adj_r_squared


def _lm_diagnostics(
    bundle: DataBundle,
    fit: FitState,
    df_model: float,
    df_resid: float,
    n: int,
    has_intercept: bool = True,
) -> dict[str, list]:
    """Compute OLS-specific diagnostics (R², F-statistic, sigma).

    Args:
        bundle: Data bundle with response vector.
        fit: Fitted state with residuals.
        df_model: Model degrees of freedom.
        df_resid: Residual degrees of freedom.
        n: Number of observations.
        has_intercept: Whether the model includes an intercept.

    Returns:
        Dict of diagnostic columns for an OLS model.
    """
    import numpy as np

    y = bundle.y
    residuals = fit.residuals

    rsquared, rsquared_adj = compute_r_squared(y, residuals, n, bundle.p, has_intercept)

    # F-statistic: (SS_reg / df_model) / (SS_res / df_resid)
    ss_res = float(np.sum(residuals**2))
    if has_intercept:
        ss_tot = float(np.sum((y - np.mean(y)) ** 2))
    else:
        ss_tot = float(np.sum(y**2))
    ss_reg = ss_tot - ss_res
    if df_model > 0 and df_resid > 0 and ss_reg > 0:
        fstatistic = (ss_reg / df_model) / (ss_res / df_resid)
        from bossanova.internal.maths.inference import compute_f_pvalue

        fstatistic_pvalue = compute_f_pvalue(fstatistic, df_model, df_resid)
    else:
        fstatistic = float("nan")
        fstatistic_pvalue = float("nan")

    sigma = fit.sigma if fit.sigma is not None else np.sqrt(ss_res / df_resid)

    # Deviance stats: for Gaussian, deviance = SS_res, null_deviance = SS_tot.
    # Use FitState values if available (method="ml"), otherwise compute directly.
    deviance = fit.deviance if fit.deviance is not None else ss_res
    if has_intercept:
        null_deviance = (
            fit.null_deviance
            if fit.null_deviance is not None
            else float(np.sum((y - np.mean(y)) ** 2))
        )
    else:
        null_deviance = (
            fit.null_deviance if fit.null_deviance is not None else float(np.sum(y**2))
        )

    mse = ss_res / n

    return {
        Col.RSQUARED: [rsquared],
        Col.RSQUARED_ADJ: [rsquared_adj],
        Col.FSTATISTIC: [fstatistic],
        Col.FSTATISTIC_PVALUE: [fstatistic_pvalue],
        Col.SIGMA: [sigma],
        Col.NULL_DEVIANCE: [null_deviance],
        Col.DEVIANCE: [deviance],
        Col.DISPERSION: [sigma**2],
        Col.MSE: [mse],
        Col.PSEUDO_RSQUARED: [
            1.0 - deviance / null_deviance if null_deviance > 0 else float("nan")
        ],
    }


def _glm_diagnostics(
    fit: FitState,
    loglik: float,
) -> dict[str, list]:
    """Compute GLM-specific diagnostics (deviance, dispersion).

    Args:
        fit: Fitted state with dispersion estimate and residual deviance.
        loglik: Log-likelihood at convergence.

    Returns:
        Dict of diagnostic columns for a GLM model.
    """
    # Use true residual deviance from IRLS solver (sum of unit deviances),
    # falling back to -2*loglik only if not available
    if fit.deviance is not None:
        deviance = fit.deviance
    else:
        from bossanova.internal.maths.inference import compute_deviance

        deviance = compute_deviance(loglik)

    dispersion = fit.dispersion if fit.dispersion is not None else 1.0

    null_deviance = fit.null_deviance if fit.null_deviance is not None else float("nan")
    pseudo_rsquared = (
        1.0 - (deviance / null_deviance)
        if fit.null_deviance is not None and null_deviance > 0
        else float("nan")
    )

    import numpy as np

    mse = (
        float(np.mean(fit.residuals**2)) if fit.residuals is not None else float("nan")
    )

    return {
        Col.NULL_DEVIANCE: [null_deviance],
        Col.DEVIANCE: [deviance],
        Col.DISPERSION: [dispersion],
        Col.MSE: [mse],
        Col.PSEUDO_RSQUARED: [pseudo_rsquared],
    }


def _mixed_diagnostics(
    bundle: DataBundle,
    fit: FitState,
    loglik: float,
    coef_for_predict: np.ndarray,
    varying_spread: VaryingSpreadState | None,
) -> dict[str, list]:
    """Compute mixed model diagnostics (Nakagawa R², ICC).

    Args:
        bundle: Data bundle with design matrix and RE metadata.
        fit: Fitted state with sigma, theta.
        loglik: Log-likelihood at convergence.
        coef_for_predict: Coefficients safe for X @ beta.
        varying_spread: Variance component estimates, or None.

    Returns:
        Dict of diagnostic columns for a mixed model.
    """
    import math

    import numpy as np

    from bossanova.internal.maths.inference import compute_deviance

    deviance = compute_deviance(loglik)
    sigma = fit.sigma if fit.sigma is not None else float("nan")

    # R² marginal/conditional and ICC via Nakagawa & Schielzeth (2013)
    if math.isnan(sigma):
        rsquared_marginal = float("nan")
        rsquared_conditional = float("nan")
        icc = float("nan")
    else:
        # Variance of fixed effects: var(X @ beta)
        fixed_fitted = bundle.X @ coef_for_predict
        var_fixed = float(np.var(fixed_fitted, ddof=0))

        # Sum of random effect variances
        if varying_spread is not None and varying_spread.tau2:
            var_random = sum(varying_spread.tau2.values())
        else:
            # Fallback: use sigma^2 * theta^2 for simple RE structures
            var_random = 0.0
            if fit.theta is not None and sigma > 0:
                var_random = float(np.sum((fit.theta * sigma) ** 2))

        # Residual variance
        var_resid = sigma**2

        # Total variance
        var_total = var_fixed + var_random + var_resid

        if var_total > 0:
            rsquared_marginal = var_fixed / var_total
            rsquared_conditional = (var_fixed + var_random) / var_total
        else:
            rsquared_marginal = 0.0
            rsquared_conditional = 0.0

        # ICC = var_random / (var_random + var_resid)
        var_group_resid = var_random + var_resid
        icc = var_random / var_group_resid if var_group_resid > 0 else 0.0

    mse = (
        float(np.mean(fit.residuals**2)) if fit.residuals is not None else float("nan")
    )

    return {
        Col.SIGMA: [sigma],
        Col.DEVIANCE: [deviance],
        Col.MSE: [mse],
        Col.RSQUARED_MARGINAL: [rsquared_marginal],
        Col.RSQUARED_CONDITIONAL: [rsquared_conditional],
        Col.ICC: [icc],
    }


def _add_cv_metrics(data: dict[str, list], cv: CVState) -> None:
    """Add cross-validation metrics to the diagnostics dict.

    Args:
        data: Mutable diagnostics dict to extend.
        cv: Cross-validation state with RMSE, MAE, R², fold metrics.
    """
    import numpy as np

    data[Col.CV_MSE] = [cv.mse]
    data[Col.CV_RMSE] = [cv.rmse]
    data[Col.CV_MAE] = [cv.mae]
    data[Col.CV_RSQUARED] = [cv.r_squared]
    data[Col.CV_K] = [cv.k]

    if cv.fold_metrics:
        if "mse" in cv.fold_metrics:
            data[Col.CV_MSE_SD] = [float(np.std(cv.fold_metrics["mse"]))]
        if "rmse" in cv.fold_metrics:
            data[Col.CV_RMSE_SD] = [float(np.std(cv.fold_metrics["rmse"]))]
        if "mae" in cv.fold_metrics:
            data[Col.CV_MAE_SD] = [float(np.std(cv.fold_metrics["mae"]))]
        if "r_squared" in cv.fold_metrics:
            data[Col.CV_RSQUARED_SD] = [float(np.std(cv.fold_metrics["r_squared"]))]

    if cv.deviance is not None:
        data[Col.CV_DEVIANCE] = [cv.deviance]


def compute_optimizer_diagnostics(
    *,
    model_type: str,
    fit: FitState,
) -> pl.DataFrame:
    """Compute optimizer convergence diagnostics as a single-row DataFrame.

    Args:
        model_type: One of "lm", "glm", "lmer", "glmer".
        fit: Fitted state with convergence info, theta, dispersion.

    Returns:
        Single-row Polars DataFrame with optimizer diagnostics.
    """
    from bossanova.internal.maths.config import is_singular

    data: dict[str, list] = {
        Col.CONVERGED: [fit.converged],
        Col.N_ITER: [fit.n_iter],
    }

    if model_type == "lm":
        data[Col.OPTIMIZER] = ["qr"]
    elif model_type == "glm":
        data[Col.OPTIMIZER] = ["irls"]
        if fit.dispersion is not None:
            data[Col.DISPERSION] = [fit.dispersion]
    elif model_type in ("lmer", "glmer"):
        data[Col.OPTIMIZER] = ["nloptwrap"]
        data[Col.IS_SINGULAR] = [is_singular(fit.theta)]
        data[Col.N_THETA] = [len(fit.theta) if fit.theta is not None else 0]

    return pl.DataFrame(data)


def augment_data_with_diagnostics(
    *,
    raw_data: pl.DataFrame,
    fit: FitState,
    bundle: DataBundle,
) -> pl.DataFrame:
    """Augment raw data with diagnostic columns after fit.

    Adds fitted, resid, hat, std_resid, cooksd columns (names from
    ``AugmentedDataCols`` schema). Values are NaN for rows dropped
    due to missing data.

    Args:
        raw_data: Original data DataFrame (pre-NA-drop).
        fit: Fitted state with residuals, fitted values, leverage.
        bundle: Data bundle with valid_mask, n_total, p.

    Returns:
        DataFrame with diagnostic columns appended.
    """
    import numpy as np

    from bossanova.internal.maths.inference.diagnostics import (
        compute_cooks_distance,
        compute_studentized_residuals,
    )

    # Resolve sigma for standardized residuals and Cook's distance
    if fit.sigma is not None:
        sigma = fit.sigma
    elif fit.dispersion is not None:
        sigma = float(np.sqrt(fit.dispersion))
    elif fit.df_resid > 0:
        sigma = float(np.sqrt(np.sum(fit.residuals**2) / fit.df_resid))
    else:
        sigma = 1.0

    # Compute diagnostics (valid rows only)
    std_resid = compute_studentized_residuals(fit.residuals, fit.leverage, sigma)
    cooksd = compute_cooks_distance(fit.residuals, fit.leverage, sigma, bundle.p)

    # Expand valid-only arrays to full dataset length
    def expand(valid_values: np.ndarray) -> np.ndarray:
        full = np.full(bundle.n_total, np.nan)
        full[bundle.valid_mask] = valid_values
        return full

    # Drop any prior augmented columns, then add fresh ones
    df = raw_data.drop([c for c in AugmentedDataCols if c in raw_data.columns])

    col_fitted, col_resid, col_hat, col_std_resid, col_cooksd = AugmentedDataCols
    return df.with_columns(
        pl.Series(col_fitted, expand(fit.fitted)),
        pl.Series(col_resid, expand(fit.residuals)),
        pl.Series(col_hat, expand(fit.leverage)),
        pl.Series(col_std_resid, expand(std_resid)),
        pl.Series(col_cooksd, expand(cooksd)),
    )
