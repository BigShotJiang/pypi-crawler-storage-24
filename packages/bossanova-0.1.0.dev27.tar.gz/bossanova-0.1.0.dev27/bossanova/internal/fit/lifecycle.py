"""Fit lifecycle orchestration.

Owns the multi-step fit sequence: bundle rebuild → fit → post-fit state →
diagnostics augmentation. Called by ``model.fit()`` so the model class stays
a thin facade.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import polars as pl
from attrs import frozen

from bossanova.internal.fit.diagnostics import augment_data_with_diagnostics
from bossanova.internal.fit.dispatch import fit_model
from bossanova.internal.fit.varying import build_mixed_post_fit_state
from bossanova.internal.formula.bundle import build_bundle_from_data

if TYPE_CHECKING:
    from bossanova.internal.containers import (
        DataBundle,
        FitState,
        ModelSpec,
        VaryingSpreadState,
        VaryingState,
    )

__all__ = ["FitResult", "execute_fit"]


@frozen
class FitResult:
    """Immutable result of the fit lifecycle.

    Attributes:
        fit: Fitted model state (coefficients, residuals, etc.).
        bundle: Data bundle used for fitting (may be rebuilt).
        formula_spec: Learned formula spec for newdata evaluation.
        raw_data: Original data snapshot (pre-augmentation).
        augmented_data: Data with diagnostic columns, or None.
        varying_offsets: BLUPs for mixed models, or None.
        varying_spread: Variance components for mixed models, or None.
    """

    fit: FitState
    bundle: DataBundle
    formula_spec: object
    raw_data: pl.DataFrame | None
    augmented_data: pl.DataFrame | None
    varying_offsets: VaryingState | None = None
    varying_spread: VaryingSpreadState | None = None


def execute_fit(
    spec: ModelSpec,
    bundle: DataBundle | None,
    data: pl.DataFrame,
    raw_data: pl.DataFrame | None,
    formula: str,
    custom_contrasts: dict | None,
    weights_col: str | None,
    offset_col: str | None,
    missing: str,
    is_mixed: bool,
    solver_override: str | None,
    fit_kwargs: dict,
) -> FitResult:
    """Execute the full fit lifecycle: bundle rebuild → fit → post-fit state → diagnostics.

    Args:
        spec: Model specification.
        bundle: Existing data bundle, or None to force rebuild.
        data: Current data (raw_data-restored by caller).
        raw_data: Original pre-augmentation snapshot, or None.
        formula: Formula string for bundle building.
        custom_contrasts: User contrast matrices, or None.
        weights_col: Weights column name, or None.
        offset_col: Offset column name, or None.
        missing: Missing value handling (``"drop"`` or ``"fail"``).
        is_mixed: Whether this is a mixed-effects model.
        solver_override: Explicit solver, or None for auto.
        fit_kwargs: Additional kwargs for ``fit_model()``.

    Returns:
        FitResult with all state the model needs to assign.
    """
    # Build DataBundle if not already built
    formula_spec = None
    if bundle is None:
        bundle, formula_spec = build_bundle_from_data(
            spec=spec,
            formula=formula,
            data=data,
            custom_contrasts=custom_contrasts,
            weights_col=weights_col,
            offset_col=offset_col,
            missing=missing,
        )

    # Fit
    fit = fit_model(spec, bundle, solver=solver_override, **fit_kwargs)

    # Mixed model post-fit state (BLUPs, variance components, convergence)
    varying_offsets = None
    varying_spread = None
    if is_mixed:
        varying_offsets, varying_spread = build_mixed_post_fit_state(
            fit=fit, bundle=bundle, data=data, stacklevel=4
        )

    # Augment data with diagnostic columns
    augmented_data = None
    if raw_data is not None:
        augmented_data = augment_data_with_diagnostics(
            raw_data=raw_data, fit=fit, bundle=bundle
        )

    return FitResult(
        fit=fit,
        bundle=bundle,
        formula_spec=formula_spec,
        raw_data=raw_data,
        augmented_data=augmented_data,
        varying_offsets=varying_offsets,
        varying_spread=varying_spread,
    )
