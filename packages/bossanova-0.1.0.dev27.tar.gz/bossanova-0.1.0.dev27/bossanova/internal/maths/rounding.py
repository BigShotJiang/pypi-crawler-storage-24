"""Significant-figures rounding for display output.

Provides vectorized rounding to N significant figures, matching R's
``signif()`` behavior. Used at the user-facing API boundary to produce
clean DataFrame output without altering internal computation precision.
"""

from __future__ import annotations

import numpy as np
import polars as pl

__all__ = [
    "round_float_columns",
    "round_sigfigs",
]


def round_sigfigs(x: np.ndarray, n: int = 4) -> np.ndarray:
    """Round array values to *n* significant figures.

    Matches R's ``signif()`` behavior: the *n* most significant digits
    are preserved regardless of magnitude.

    Args:
        x: Input array (float64). May contain NaN or inf values.
        n: Number of significant figures. Must be >= 1.

    Returns:
        Array of the same shape with values rounded to *n* significant
        figures. NaN and inf values are passed through unchanged.

    Examples:
        >>> round_sigfigs(np.array([0.00012345, 3.14159, 12345.68]), n=4)
        array([1.235e-04, 3.142e+00, 1.235e+04])
    """
    x = np.asarray(x, dtype=np.float64)
    result = x.copy()

    # Only round finite, non-zero values
    mask = np.isfinite(x) & (x != 0)
    if not mask.any():
        return result

    vals = x[mask]
    magnitude = np.floor(np.log10(np.abs(vals)))
    shift = 10.0 ** (magnitude - n + 1)
    result[mask] = np.round(vals / shift) * shift

    return result


def round_float_columns(df: pl.DataFrame, digits: int = 4) -> pl.DataFrame:
    """Round all Float64 columns to *digits* significant figures.

    Non-float columns (String, Int32, Int64, etc.) are passed through
    unchanged. Null values within float columns are preserved.

    Args:
        df: Input DataFrame.
        digits: Number of significant figures. Must be >= 1.

    Returns:
        New DataFrame with Float64 columns rounded.
    """
    float_cols = [c for c in df.columns if df[c].dtype == pl.Float64]
    if not float_cols:
        return df

    replacements = []
    for col_name in float_cols:
        series = df[col_name]
        if series.null_count() == len(series):
            # All nulls — nothing to round
            replacements.append(series)
            continue

        arr = series.to_numpy(allow_copy=True)
        rounded = round_sigfigs(arr, n=digits)

        # Preserve nulls from the original series
        new_series = pl.Series(col_name, rounded)
        if series.null_count() > 0:
            null_mask = series.is_null()
            new_series = new_series.set(null_mask, None)

        replacements.append(new_series)

    return df.with_columns(replacements)
