"""Model-specific fitting algorithms (IRLS, PLS, PIRLS)."""

from bossanova.internal.maths.solvers.glm import fit_glm_irls
from bossanova.internal.maths.solvers.lmer import (
    PLSInvariants,
    apply_sqrt_weights,
    compute_pls_invariants,
    lmm_deviance_sparse,
    solve_pls_sparse,
)
from bossanova.internal.maths.solvers.glmer import (
    compute_irls_quantities,
    fit_glmm_pirls,
    glmm_deviance,
    glmm_deviance_objective,
    pirls_sparse,
    solve_weighted_pls_sparse,
)
from bossanova.internal.maths.solvers.quadrature import compute_agq_deviance
from bossanova.internal.maths.solvers.lambda_builder import (
    LambdaTemplate,
    PatternTemplate,
    build_lambda_sparse,
    build_lambda_template,
    theta_to_cholesky_block,
    update_lambda_from_template,
)
from bossanova.internal.maths.solvers.optimize import optimize_theta

__all__ = [
    "LambdaTemplate",
    "PLSInvariants",
    "PatternTemplate",
    "apply_sqrt_weights",
    "build_lambda_sparse",
    "build_lambda_template",
    "compute_agq_deviance",
    "compute_irls_quantities",
    "compute_pls_invariants",
    "fit_glm_irls",
    "fit_glmm_pirls",
    "glmm_deviance",
    "glmm_deviance_objective",
    "lmm_deviance_sparse",
    "optimize_theta",
    "pirls_sparse",
    "solve_pls_sparse",
    "solve_weighted_pls_sparse",
    "theta_to_cholesky_block",
    "update_lambda_from_template",
]
