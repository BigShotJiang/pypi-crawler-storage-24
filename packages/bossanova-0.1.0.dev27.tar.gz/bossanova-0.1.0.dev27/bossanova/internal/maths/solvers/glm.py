"""GLM IRLS fitting algorithm.

This module implements the Iteratively Reweighted Least Squares (IRLS) algorithm
for GLM fitting. The algorithm supports both JAX and NumPy backends:

- JAX backend: Uses lax.while_loop for JIT-compiled, efficient iteration
- NumPy backend: Uses regular Python loops for Pyodide compatibility

All functions are designed to work with Family objects from bossanova.internal.maths.family.
"""

from typing import Any

import numpy as np

from bossanova.internal.maths.backend import get_backend
from bossanova.internal.maths.family import Family

__all__ = [
    "compute_loglik",
    "compute_null_deviance",
    "fit_glm_irls",
]


def fit_glm_irls(
    y: np.ndarray,
    X: np.ndarray,
    family: Family,
    weights: np.ndarray | None = None,
    max_iter: int = 25,
    tol: float = 1e-8,
) -> dict:
    """Fit GLM using IRLS algorithm.

    Implements Iteratively Reweighted Least Squares for generalized linear
    models. The algorithm iterates until convergence (relative deviance change
    < tol) or max_iter is reached.

    The core fitting loop is JIT-compiled for efficiency. All family-specific
    operations (link, variance, deviance) are pure JAX functions from the
    Family object.

    Args:
        y: Response values (n,)
        X: Design matrix (n, p)
        family: Family object with link, variance, and deviance functions
        weights: Prior observation weights (n,) or None for equal weights
        max_iter: Maximum IRLS iterations (default: 25)
        tol: Convergence tolerance for relative deviance change (default: 1e-8)

    Returns:
        Dictionary with keys:
            - coef: Coefficient estimates (p,)
            - vcov: Variance-covariance matrix (p, p)
            - dispersion: Dispersion parameter estimate
            - fitted: Fitted values μ on response scale (n,)
            - linear_predictor: Linear predictor η on link scale (n,)
            - residuals: Response residuals y - μ (n,)
            - deviance: Residual deviance
            - null_deviance: Null model deviance
            - df_residual: Residual degrees of freedom
            - loglik: Log-likelihood
            - converged: True if converged, False otherwise
            - n_iter: Number of iterations performed
            - has_separation: Separation detection (binomial only, None otherwise)
            - irls_weights: Final IRLS weights (n,)

    Notes:
        - Uses while_loop for early stopping on convergence
        - Clips IRLS weights to [1e-10, 1e10] for numerical stability
        - Clips μ values based on family type (binomial: [1e-10, 1-1e-10],
          poisson: [1e-10, inf])
        - Adds small regularization (1e-10) to diagonal of XtWX
        - Separation detection checks if fitted probabilities are extremely
          close to 0 or 1 (< 1e-6 or > 1-1e-6) for binomial models
    """
    # Dispatch to backend-specific implementation
    # Use NumPy for families with robust weights (e.g., t-distribution)
    # since JAX JIT doesn't easily support the residual-dependent weights
    backend = get_backend()
    if backend == "jax" and family.robust_weights is None:
        return fit_glm_irls_jax(y, X, family, weights, max_iter, tol)
    else:
        return fit_glm_irls_numpy(y, X, family, weights, max_iter, tol)


# =============================================================================
# Shared IRLS Step (Backend-Agnostic)
# =============================================================================


def irls_step(
    mu: np.ndarray,
    eta: np.ndarray,
    y: np.ndarray,
    X: np.ndarray,
    prior_weights: np.ndarray,
    family: Family,
    p: int,
    xp: Any,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Single IRLS iteration (backend-agnostic).

    Computes the core weighted least squares update for one IRLS iteration.
    This function is called by both JAX and NumPy backends.

    Args:
        mu: Current fitted values on response scale (n,).
        eta: Current linear predictor (n,).
        y: Response values (n,).
        X: Design matrix (n, p).
        prior_weights: Observation weights (n,).
        family: Family object with link and variance functions.
        p: Number of parameters.
        xp: Array module (numpy or jax.numpy).

    Returns:
        Tuple of (mu_new, eta_new, coef, deviance, irls_weights, XtWX).
    """
    # Link derivative and variance
    deta_dmu = family.link_deriv(mu)
    var_mu = family.variance(mu)

    # Working response (pseudo-response)
    working_response = eta + (y - mu) * deta_dmu

    # IRLS weights (clip for numerical stability)
    irls_weights = prior_weights / (var_mu * deta_dmu**2 + 1e-10)
    irls_weights = xp.clip(irls_weights, 1e-10, 1e10)

    # Weighted normal equations
    XtWX = xp.einsum("ni,n,nj->ij", X, irls_weights, X)
    XtWz = xp.einsum("ni,n,n->i", X, irls_weights, working_response)

    # Solve via Cholesky with small regularization
    XtWX_reg = XtWX + 1e-10 * xp.eye(p)
    L = xp.linalg.cholesky(XtWX_reg)
    coef = xp.linalg.solve(L.T, xp.linalg.solve(L, XtWz))

    # Update predictions
    eta_new = X @ coef
    mu_new = family.link_inverse(eta_new)

    # Clip μ based on family type
    if family.name == "binomial":
        mu_new = xp.clip(mu_new, 1e-10, 1 - 1e-10)
    elif family.name == "poisson":
        mu_new = xp.clip(mu_new, 1e-10, xp.inf)

    # Compute deviance
    dev_contributions = family.deviance(y, mu_new)
    deviance = xp.sum(dev_contributions)

    return mu_new, eta_new, coef, deviance, irls_weights, XtWX


# =============================================================================
# JAX Backend Implementation
# =============================================================================


def fit_glm_irls_jax(
    y: np.ndarray,
    X: np.ndarray,
    family: Family,
    weights: np.ndarray | None = None,
    max_iter: int = 25,
    tol: float = 1e-8,
) -> dict:
    """JAX-optimized IRLS implementation using lax.while_loop."""
    import jax.numpy as jnp

    n, p = X.shape

    # Convert to JAX arrays
    X_jax = jnp.array(X)
    y_jax = jnp.array(y)

    # Handle weights
    if weights is None:
        prior_weights = jnp.ones(n)
    else:
        prior_weights = jnp.array(weights)

    # Initialize μ and η (pass weights for binomial family)
    mu_init = family.initialize(y_jax, prior_weights)
    eta_init = family.link(mu_init)

    # JIT-compiled core fitting loop
    result = fit_glm_irls_jit(
        X_jax, y_jax, mu_init, eta_init, prior_weights, family, max_iter, tol, p
    )

    mu = result["mu"]
    eta = result["eta"]
    coef = result["coef"]
    deviance = result["deviance"]
    converged = bool(result["converged"])
    n_iter = int(result["n_iter"])
    XtWX = result["XtWX"]
    irls_weights = result["irls_weights"]

    # Compute final outputs
    residuals = y_jax - mu
    df_residual = n - p

    # Dispersion parameter
    dispersion = family.dispersion(y_jax, mu, df_residual)

    # Variance-covariance matrix
    XtWX_inv = jnp.linalg.inv(XtWX + 1e-10 * jnp.eye(p))
    vcov = dispersion * XtWX_inv

    # Null deviance (intercept-only model)
    null_deviance = compute_null_deviance(y_jax, family, jnp)

    # Log-likelihood
    loglik = compute_loglik(y_jax, mu, deviance, dispersion, family, n, jnp)

    # Separation detection (binomial only)
    # Check for:
    # 1. Complete separation: fitted probabilities at 0 or 1
    # 2. Quasi-complete separation: score (gradient) not converging to zero
    has_separation = None
    if family.name == "binomial":
        # Check for extreme fitted values (complete separation)
        extreme_fitted = bool(jnp.any((mu < 1e-6) | (mu > 1 - 1e-6)))

        # Check for score not converging (quasi-complete separation)
        # For binomial GLM with canonical logit link, score = X' @ (y - mu)
        score = X_jax.T @ residuals
        max_score = float(jnp.max(jnp.abs(score)))
        # Threshold based on problem scale
        score_threshold = max(1e-4, 1e-8 * n * float(jnp.abs(X_jax).max()))
        score_not_converged = converged and (max_score > score_threshold)

        has_separation = extreme_fitted or score_not_converged

    return {
        "coef": np.array(coef),
        "vcov": np.array(vcov),
        "dispersion": float(dispersion),
        "fitted": np.array(mu),
        "linear_predictor": np.array(eta),
        "residuals": np.array(residuals),
        "deviance": float(deviance),
        "null_deviance": float(null_deviance),
        "df_residual": df_residual,
        "loglik": float(loglik),
        "converged": converged,
        "n_iter": n_iter,
        "has_separation": has_separation,
        "irls_weights": np.array(irls_weights),
        "XtWX_inv": np.array(XtWX_inv),
    }


# Cache for JIT-compiled function
_jit_cache: dict = {}


def get_jit_fn() -> Any:
    """Lazily create and return the JIT-compiled IRLS function.

    Returns:
        JIT-compiled IRLS core function.
    """
    if "jit_fn" not in _jit_cache:
        import jax
        import jax.lax as lax
        import jax.numpy as jnp

        def _irls_core(
            X, y, mu_init, eta_init, prior_weights, family, max_iter, tol, p
        ):
            """IRLS core loop using lax.while_loop."""

            def cond_fn(state):
                """Return True to continue looping."""
                _, _, deviance_current, iteration, _, _, _, deviance_prev = state
                continue_iterating = iteration < max_iter

                def check_convergence():
                    dev_change = jnp.abs(deviance_current - deviance_prev)
                    rel_change = dev_change / (jnp.abs(deviance_prev) + 1e-10)
                    return rel_change >= tol

                should_continue = lax.cond(
                    jnp.isinf(deviance_prev),
                    lambda: True,
                    check_convergence,
                )
                return continue_iterating & should_continue

            def body_fn(state):
                """Single IRLS iteration."""
                mu, eta, deviance_current, iteration, _, _, _, _ = state

                # Use shared IRLS step
                mu_new, eta_new, coef, deviance_new, irls_weights, XtWX = irls_step(
                    mu, eta, y, X, prior_weights, family, p, jnp
                )

                return (
                    mu_new,
                    eta_new,
                    deviance_new,
                    iteration + 1,
                    coef,
                    XtWX,
                    irls_weights,
                    deviance_current,
                )

            init_state = (
                mu_init,
                eta_init,
                jnp.inf,
                0,
                jnp.zeros(p),
                jnp.eye(p),
                jnp.ones(len(y)),
                jnp.inf,
            )

            final_state = lax.while_loop(cond_fn, body_fn, init_state)

            (
                mu_final,
                eta_final,
                deviance_final,
                n_iter,
                coef_final,
                XtWX_final,
                weights_final,
                _,
            ) = final_state

            converged = n_iter < max_iter

            return {
                "mu": mu_final,
                "eta": eta_final,
                "coef": coef_final,
                "deviance": deviance_final,
                "converged": converged,
                "n_iter": n_iter,
                "XtWX": XtWX_final,
                "irls_weights": weights_final,
            }

        _jit_cache["jit_fn"] = jax.jit(
            _irls_core,
            static_argnames=("family", "max_iter", "p"),
            donate_argnums=(2, 3, 4),
        )
    return _jit_cache["jit_fn"]


def fit_glm_irls_jit(
    X: np.ndarray,
    y: np.ndarray,
    mu_init: np.ndarray,
    eta_init: np.ndarray,
    prior_weights: np.ndarray,
    family: Family,
    max_iter: int,
    tol: float,
    p: int,
) -> dict[str, np.ndarray]:
    """Wrapper that calls the lazily-created JIT function.

    Args:
        X: Design matrix, shape (n, p).
        y: Response values, shape (n,).
        mu_init: Initial fitted values, shape (n,).
        eta_init: Initial linear predictor, shape (n,).
        prior_weights: Observation weights, shape (n,).
        family: Family object with link and variance functions.
        max_iter: Maximum number of IRLS iterations.
        tol: Convergence tolerance for relative deviance change.
        p: Number of parameters.

    Returns:
        Dictionary with keys: mu, eta, coef, deviance, converged, n_iter,
        XtWX, irls_weights.
    """
    jit_fn = get_jit_fn()
    return jit_fn(X, y, mu_init, eta_init, prior_weights, family, max_iter, tol, p)


def compute_null_deviance(y: np.ndarray, family: Family, xp: Any) -> np.ndarray | float:
    """Compute null deviance for the intercept-only model.

    The null deviance measures how well the response is predicted by a model
    with only an intercept (the mean). It is used as a baseline for assessing
    model fit improvement.

    Args:
        y: Response values, shape (n,).
        family: Family object with deviance function.
        xp: Array module (numpy or jax.numpy).

    Returns:
        Null deviance as a scalar.
    """
    if family.name == "binomial":
        y_mean = xp.mean(y)
        null_mu = xp.clip(y_mean, 1e-10, 1 - 1e-10) * xp.ones_like(y)
    elif family.name == "tdist":
        # For t-distribution, use median for robustness
        null_mu = xp.median(y) * xp.ones_like(y)
    else:
        # gaussian, poisson, and other families
        null_mu = xp.mean(y) * xp.ones_like(y)

    null_dev_contributions = family.deviance(y, null_mu)
    return xp.sum(null_dev_contributions)


def compute_loglik(
    y: np.ndarray,
    mu: np.ndarray,
    deviance: float | np.ndarray,
    dispersion: float | np.ndarray,
    family: Family,
    n: int,
    xp: Any,
) -> np.ndarray | float:
    """Compute log-likelihood for a fitted GLM.

    Uses family-specific formulas for exact log-likelihood computation.
    Falls back to the deviance-based approximation for unknown families.

    Args:
        y: Response values, shape (n,).
        mu: Fitted values on response scale, shape (n,).
        deviance: Residual deviance (scalar).
        dispersion: Dispersion parameter estimate (scalar).
        family: Family object with name attribute.
        n: Number of observations.
        xp: Array module (numpy or jax.numpy).

    Returns:
        Log-likelihood as a scalar.
    """
    if family.name == "gaussian":
        mle_dispersion = deviance / n
        return -0.5 * n * (xp.log(2 * xp.pi) + xp.log(mle_dispersion) + 1)
    elif family.name == "binomial":
        mu_clipped = xp.clip(mu, 1e-10, 1 - 1e-10)
        return xp.sum(y * xp.log(mu_clipped) + (1 - y) * xp.log(1 - mu_clipped))
    elif family.name == "poisson":
        mu_clipped = xp.clip(mu, 1e-10, xp.inf)
        # Use backend-appropriate gammaln
        gammaln = _get_gammaln(xp)
        return xp.sum(y * xp.log(mu_clipped) - mu_clipped - gammaln(y + 1))
    elif family.name == "gamma":
        # Full Gamma density: Gamma(y | shape=1/φ, scale=μ*φ)
        # where φ_mle = deviance/n, matching R's logLik.glm convention.
        y_clipped = xp.clip(y, 1e-10, xp.inf)
        mu_clipped = xp.clip(mu, 1e-10, xp.inf)
        mle_disp = float(deviance) / n
        shape = 1.0 / mle_disp
        scale = mu_clipped * mle_disp
        gammaln = _get_gammaln(xp)
        return float(
            xp.sum(
                (shape - 1) * xp.log(y_clipped)
                - y_clipped / scale
                - shape * xp.log(scale)
                - gammaln(shape)
            )
        )
    elif family.name == "tdist":
        df = family.df
        residuals_sq = (y - mu) ** 2 / (dispersion + 1e-10)
        gammaln = _get_gammaln(xp)
        return xp.sum(
            gammaln((df + 1) / 2)
            - gammaln(df / 2)
            - 0.5 * xp.log(df * xp.pi * dispersion)
            - 0.5 * (df + 1) * xp.log(1 + residuals_sq / df)
        )
    else:
        return -deviance / (2 * dispersion)


def _get_gammaln(xp: Any) -> Any:
    """Get the gammaln function for the given array module.

    Args:
        xp: Array module (numpy or jax.numpy).

    Returns:
        gammaln function from the corresponding scipy module.
    """
    if hasattr(xp, "__name__") and "jax" in xp.__name__:
        import jax.scipy as jsp

        return jsp.special.gammaln
    else:
        from scipy import special as sp_special

        return sp_special.gammaln


# =============================================================================
# NumPy Backend Implementation
# =============================================================================


def fit_glm_irls_numpy(
    y: np.ndarray,
    X: np.ndarray,
    family: Family,
    weights: np.ndarray | None = None,
    max_iter: int = 25,
    tol: float = 1e-8,
) -> dict:
    """NumPy IRLS implementation using regular Python loops."""
    n, p = X.shape

    # Handle weights
    if weights is None:
        prior_weights = np.ones(n)
    else:
        prior_weights = np.asarray(weights)

    # Initialize μ and η
    mu = family.initialize(y, prior_weights)
    eta = family.link(mu)

    # Check if family has robust weights (e.g., t-distribution)
    has_robust_weights = family.robust_weights is not None

    # Initial scale estimate for robust families (MAD-based)
    if has_robust_weights:
        residuals = y - mu
        scale = np.median(np.abs(residuals - np.median(residuals))) / 0.6745
        scale = max(scale, 1e-10)
    else:
        scale = 1.0

    # Initial deviance
    deviance_prev = np.inf
    converged = False

    # IRLS iteration
    for iteration in range(max_iter):
        if has_robust_weights:
            # Robust families (t-distribution): custom logic with robust weights
            deta_dmu = family.link_deriv(mu)
            var_mu = family.variance(mu)
            working_response = eta + (y - mu) * deta_dmu

            # Base IRLS weights
            irls_weights = prior_weights / (var_mu * deta_dmu**2 + 1e-10)

            # Apply robust weights (has_robust_weights ensures this is not None)
            assert family.robust_weights is not None
            robust_w = family.robust_weights(y, mu, scale)
            irls_weights = irls_weights * robust_w
            irls_weights = np.clip(irls_weights, 1e-10, 1e10)

            # Weighted least squares
            XtWX = np.einsum("ni,n,nj->ij", X, irls_weights, X)
            XtWz = np.einsum("ni,n,n->i", X, irls_weights, working_response)

            # Solve via Cholesky
            XtWX_reg = XtWX + 1e-10 * np.eye(p)
            L = np.linalg.cholesky(XtWX_reg)
            coef = np.linalg.solve(L.T, np.linalg.solve(L, XtWz))

            # Update predictions
            eta = X @ coef
            mu = family.link_inverse(eta)

            # Clip μ based on family type
            if family.name == "binomial":
                mu = np.clip(mu, 1e-10, 1 - 1e-10)
            elif family.name == "poisson":
                mu = np.clip(mu, 1e-10, np.inf)

            # Update scale estimate
            residuals = y - mu
            scale = np.median(np.abs(residuals - np.median(residuals))) / 0.6745
            scale = max(scale, 1e-10)

            # Compute deviance
            dev_contributions = family.deviance(y, mu)
            deviance = np.sum(dev_contributions)
        else:
            # Standard families: use shared IRLS step
            mu, eta, coef, deviance, irls_weights, XtWX = irls_step(
                mu, eta, y, X, prior_weights, family, p, np
            )

        # Check convergence
        if iteration > 0:
            dev_change = np.abs(deviance - deviance_prev)
            rel_change = dev_change / (np.abs(deviance_prev) + 1e-10)
            if rel_change < tol:
                converged = True
                break

        deviance_prev = deviance

    n_iter = iteration + 1

    # Compute final outputs
    residuals = y - mu
    df_residual = n - p

    # Dispersion parameter
    dispersion = family.dispersion(y, mu, df_residual)

    # Variance-covariance matrix
    XtWX_inv = np.linalg.inv(XtWX + 1e-10 * np.eye(p))
    vcov = dispersion * XtWX_inv

    # Null deviance
    null_deviance = compute_null_deviance(y, family, np)

    # Log-likelihood
    loglik = compute_loglik(y, mu, deviance, dispersion, family, n, np)

    # Separation detection (binomial only)
    # Check for:
    # 1. Complete separation: fitted probabilities at 0 or 1
    # 2. Quasi-complete separation: score (gradient) not converging to zero
    has_separation = None
    if family.name == "binomial":
        # Check for extreme fitted values (complete separation)
        extreme_fitted = bool(np.any((mu < 1e-6) | (mu > 1 - 1e-6)))

        # Check for score not converging (quasi-complete separation)
        # For binomial GLM with canonical logit link, score = X' @ (y - mu)
        score = X.T @ residuals
        max_score = float(np.max(np.abs(score)))
        # Threshold based on problem scale
        score_threshold = max(1e-4, 1e-8 * n * np.abs(X).max())
        score_not_converged = converged and (max_score > score_threshold)

        has_separation = extreme_fitted or score_not_converged

    return {
        "coef": np.asarray(coef),
        "vcov": np.asarray(vcov),
        "dispersion": float(dispersion),
        "fitted": np.asarray(mu),
        "linear_predictor": np.asarray(eta),
        "residuals": np.asarray(residuals),
        "deviance": float(deviance),
        "null_deviance": float(null_deviance),
        "df_residual": df_residual,
        "loglik": float(loglik),
        "converged": converged,
        "n_iter": n_iter,
        "has_separation": has_separation,
        "irls_weights": np.asarray(irls_weights),
        "XtWX_inv": np.asarray(XtWX_inv),
    }
