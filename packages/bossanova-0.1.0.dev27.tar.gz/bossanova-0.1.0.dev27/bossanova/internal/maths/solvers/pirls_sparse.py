"""Sparse PIRLS (Penalized Iteratively Reweighted Least Squares) core routines.

This module contains the inner-loop routines for fitting generalized linear mixed
models via the Laplace approximation. These are called by the orchestrator in
``glmer.py`` and are not intended for direct use.

Functions:
    compute_irls_quantities: IRLS working weights and pseudo-response.
    solve_weighted_pls_sparse: Weighted penalized least squares via sparse Cholesky.
    compute_glmm_loglik: Laplace log-likelihood.
    glmm_deviance: Laplace deviance.
    pirls_sparse: Full PIRLS iteration loop.

Reference:
    lme4 external.cpp (pwrssUpdate), MixedModels.jl pirls!
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import scipy.sparse as sp

from bossanova.internal.maths.family import Family
from bossanova.internal.maths.linalg.sparse import compute_sparse_cholesky

if TYPE_CHECKING:
    from bossanova.internal.maths.linalg.sparse import SparseFactorization
    from bossanova.internal.maths.solvers.lambda_builder import PatternTemplate

__all__ = [
    "compute_glmm_loglik",
    "compute_irls_quantities",
    "glmm_deviance",
    "pirls_sparse",
    "solve_weighted_pls_sparse",
]


def compute_irls_quantities(
    y: np.ndarray,
    eta: np.ndarray,
    family: Family,
) -> tuple[np.ndarray, np.ndarray]:
    """Compute IRLS working weights and working response.

    Args:
        y: Response values (n,)
        eta: Linear predictor (n,)
        family: GLM family object

    Returns:
        working_weights: IRLS weights w = 1 / (V(mu) * (deta/dmu)^2)
        working_response: Pseudo-response z = eta + (y - mu) * deta/dmu
    """
    # Compute mu from eta via inverse link
    mu = np.asarray(family.link_inverse(eta))

    # Link derivative and variance
    deta_dmu = np.asarray(family.link_deriv(mu))
    var_mu = np.asarray(family.variance(mu))

    # Working weights (clip for numerical stability)
    working_weights = 1.0 / (var_mu * deta_dmu**2 + 1e-10)
    working_weights = np.clip(working_weights, 1e-10, 1e10)

    # Working response
    working_response = eta + (y - mu) * deta_dmu

    return working_weights, working_response


def solve_weighted_pls_sparse(
    X: np.ndarray,
    Z: sp.csc_matrix,
    Lambda: sp.csc_matrix,
    z: np.ndarray,
    weights: np.ndarray,
    beta_fixed: np.ndarray | None = None,
    ZL: sp.csc_matrix | None = None,
    ZL_dense: np.ndarray | None = None,
    factor_S22: "SparseFactorization | None" = None,
    factor_S: "SparseFactorization | None" = None,
    pattern_template: "PatternTemplate | None" = None,
) -> dict:
    """Solve weighted Penalized Least Squares for GLMM.

    Solves the weighted augmented system:
        [X'WX        X'WZL    ] [beta]   [X'Wz  ]
        [L'Z'WX   L'Z'WZL + I ] [u]    = [L'Z'Wz]

    using sparse Cholesky factorization.

    If beta_fixed is provided, solves only for u with beta held constant:
        [L'Z'WZL + I] [u] = [L'Z'W(z - X*beta)]

    This is critical for Stage 2 optimization where we need to evaluate
    deviance at arbitrary (theta, beta) points without PIRLS re-optimizing beta.

    Args:
        X: Fixed effects design matrix (n, p)
        Z: Random effects design matrix (n, q), scipy sparse CSC
        Lambda: Cholesky-like factor (q, q), scipy sparse CSC
        z: Working response (n,)
        weights: IRLS weights (n,)
        beta_fixed: If provided, solve only for u with beta fixed to this value.
        ZL: Pre-computed Z @ Lambda (sparse). If provided, avoids redundant
            computation when called repeatedly with same Z and Lambda.
        ZL_dense: Pre-computed ``ZL.toarray()`` (dense). If provided, avoids
            repeated sparse-to-dense materialization on each call.
        factor_S22: Cached Cholesky factor for S22 block. If provided, uses
            cholesky_inplace() to update with new values (same sparsity pattern).
            This avoids expensive symbolic analysis on repeated calls.
        factor_S: Cached Cholesky factor for full augmented system S.
            Only used in full solve mode (when beta_fixed is None).
        pattern_template: PatternTemplate for preserving sparsity patterns.
            When provided, ensures S22 has consistent pattern for cross-theta
            caching. Required when using factor_S22 with cross-theta caching.

    Returns:
        Dictionary with keys:
        - beta: Fixed effects coefficients (p,)
        - u: Spherical random effects (q,)
        - logdet_L: Log-determinant of (L'Z'WZL + I)
        - fitted_z: Fitted working response X*beta + Z*L*u
        - factor_S22: Cholesky factor for S22 (for caching)
        - factor_S: Cholesky factor for full system S (for caching, full mode only)
    """
    # Ensure CSC format
    if not sp.isspmatrix_csc(Z):
        Z = Z.tocsc()
    if not sp.isspmatrix_csc(Lambda):
        Lambda = Lambda.tocsc()

    n, p = X.shape
    q = Lambda.shape[0]

    # Use pre-computed ZL if provided, otherwise compute it
    # When pattern_template is provided, use pattern-preserving computation
    if ZL is None:
        if pattern_template is not None:
            from bossanova.internal.maths.solvers.lambda_builder import (
                compute_zl_preserve_pattern,
            )

            ZL = compute_zl_preserve_pattern(Z, Lambda, pattern_template.ZL_pattern)
        else:
            ZL = Z @ Lambda

    # Materialize ZL to dense once (avoids repeated .toarray() per call)
    if ZL_dense is None:
        ZL_dense = ZL.toarray()

    # Weight ZL via sparse element-wise multiply (avoids constructing diagonal W)
    ZL_weighted = ZL.multiply(weights[:, None])

    # Bottom-right: L'Z'WZL + I (sparse) - needed for both modes
    # When pattern_template is provided, preserve sparsity pattern for caching
    if pattern_template is not None:
        from bossanova.internal.maths.solvers.lambda_builder import (
            compute_s22_preserve_pattern,
        )

        # Pattern preservation needs sparse W matrix
        W = sp.diags(weights, format="csc")
        S22 = compute_s22_preserve_pattern(ZL, W, pattern_template.S22_pattern)
    else:
        ZLtWZL = ZL.T @ ZL_weighted
        S22 = ZLtWZL + sp.eye(q, format="csc")

    # Compute log-determinant of S22 block (L'Z'WZL + I)
    if not sp.isspmatrix_csc(S22):
        S22 = S22.tocsc()

    # Use cached factor if provided, otherwise create new
    if factor_S22 is not None:
        # Reuse symbolic analysis, only do numeric factorization
        factor_S22.cholesky_inplace(S22)
    else:
        factor_S22 = compute_sparse_cholesky(S22)
    logdet_L = factor_S22.logdet()

    if beta_fixed is not None:
        # U-only mode: solve [L'Z'WZL + I] [u] = [L'Z'W(z - X*beta)]
        # This matches lme4's approach in Stage 2 where beta is in the offset
        z_adjusted = z - X @ beta_fixed
        ZLtWz_adj = ZL.T @ (weights * z_adjusted)

        # Solve for u only
        u = factor_S22(ZLtWz_adj)
        beta = beta_fixed

        # Compute fitted working response
        fitted_z = X @ beta + ZL_dense @ u

        return {
            "beta": beta,
            "u": u,
            "logdet_L": float(logdet_L),
            "fitted_z": fitted_z,
            "factor_S22": factor_S22,
        }

    # Full solve mode: solve for both beta and u

    # Build augmented system components using broadcasting (no sparse W needed)
    # Top-left: X'WX (dense, typically small)
    Xw = X * weights[:, None]
    XtWX = Xw.T @ X

    # Top-right: X'WZL (mixed, using pre-computed dense ZL)
    XtWZL = Xw.T @ ZL_dense

    # Right-hand side
    XtWz = X.T @ (weights * z)
    ZLtWz = ZL.T @ (weights * z)

    # Build full augmented system
    S11 = sp.csc_matrix(XtWX)
    S12 = sp.csc_matrix(XtWZL)
    S = sp.bmat([[S11, S12], [S12.T, S22]], format="csc")

    rhs = np.concatenate([XtWz, ZLtWz])

    # Sparse Cholesky factorization with caching
    if factor_S is not None:
        # Reuse symbolic analysis, only do numeric factorization
        factor_S.cholesky_inplace(S)
    else:
        factor_S = compute_sparse_cholesky(S)
    solution = factor_S(rhs)

    beta = solution[:p]
    u = solution[p:]

    # Compute fitted working response
    fitted_z = X @ beta + ZL_dense @ u

    return {
        "beta": beta,
        "u": u,
        "logdet_L": float(logdet_L),
        "fitted_z": fitted_z,
        "factor_S22": factor_S22,
        "factor_S": factor_S,
    }


def compute_glmm_loglik(
    y: np.ndarray,
    mu: np.ndarray,
    family: Family,
    sqrL: float,
    logdet: float,
    prior_weights: np.ndarray | None = None,
) -> float:
    """Compute GLMM log-likelihood via Laplace approximation.

    Matches lme4's logLik() for GLMMs:
        loglik = cond_loglik - 0.5 * (||u||^2 + logdet)

    where cond_loglik is the full conditional log-likelihood including
    normalizing constants (log(y!), log(choose(m,y)), etc.).

    For weighted binomial (grouped), uses the full binomial log-likelihood
    with log(choose(m, y_counts)) to match lme4's aic() function.

    Args:
        y: Response values (n,). For weighted binomial, these are proportions.
        mu: Fitted values (n,).
        family: GLM family with loglik method.
        sqrL: Sum of squared spherical random effects ||u||^2.
        logdet: Log-determinant log|L'Z'WZL + I|.
        prior_weights: Prior weights (n,). For binomial proportions, the
            number of trials per observation.

    Returns:
        Log-likelihood (scalar).
    """
    from scipy import special

    if family.name == "binomial" and prior_weights is not None:
        # Grouped binomial: full log-likelihood with binomial coefficients
        # lme4 formula: sum((wt/m) * dbinom(y_counts, m, mu, log=TRUE))
        m = prior_weights  # number of trials
        y_counts = np.round(m * y)  # actual successes
        mu_clipped = np.clip(mu, 1e-10, 1 - 1e-10)

        ll_obs = (
            special.gammaln(m + 1)
            - special.gammaln(y_counts + 1)
            - special.gammaln(m - y_counts + 1)
            + y_counts * np.log(mu_clipped)
            + (m - y_counts) * np.log(1 - mu_clipped)
        )
        # lme4 uses (wt/m) weighting, but wt = m so this simplifies
        cond_loglik = float(np.sum((m / m) * ll_obs))
    else:
        # Use family loglik (includes normalizing constants for Poisson, etc.)
        ll_obs = np.asarray(family.loglik(y, mu))
        if prior_weights is not None:
            ll_obs = prior_weights * ll_obs
        cond_loglik = float(np.sum(ll_obs))

    return cond_loglik - 0.5 * (sqrL + logdet)


def glmm_deviance(
    y: np.ndarray,
    mu: np.ndarray,
    family: Family,
    logdet: float,
    sqrL: float,
    prior_weights: np.ndarray | None = None,
) -> float:
    """Compute GLMM deviance via Laplace approximation.

    The Laplace approximation to -2 log L:
        deviance_GLMM = sum(dev_resid) + logdet + ||u||^2

    Args:
        y: Response values (n,)
        mu: Fitted values mu = g^{-1}(eta) (n,)
        family: GLM family
        logdet: Log-determinant log|L'Z'WZL + I|
        sqrL: Sum of squared spherical random effects ||u||^2
        prior_weights: Prior weights for observations (n,). For binomial with
            proportions, this is the number of trials.

    Returns:
        GLMM deviance (scalar)
    """
    # Compute GLM deviance residuals
    dev_resids = np.asarray(family.deviance(y, mu))

    # Weight deviance residuals by prior weights
    if prior_weights is None:
        deviance_glm = np.sum(dev_resids)
    else:
        deviance_glm = np.sum(prior_weights * dev_resids)

    # Laplace approximation
    return float(deviance_glm + logdet + sqrL)


def pirls_sparse(
    X: np.ndarray,
    Z: sp.csc_matrix,
    Lambda: sp.csc_matrix,
    y: np.ndarray,
    family: Family,
    eta_init: np.ndarray | None = None,
    prior_weights: np.ndarray | None = None,
    beta_fixed: np.ndarray | None = None,
    max_iter: int = 30,
    tol: float = 1e-7,
    verbose: bool = False,
    factor_S22: "SparseFactorization | None" = None,
    factor_S: "SparseFactorization | None" = None,
    pattern_template: "PatternTemplate | None" = None,
) -> dict:
    """Penalized Iteratively Reweighted Least Squares using sparse operations.

    For fixed variance parameters encoded in Lambda, iteratively solves for beta and u
    using weighted penalized least squares. This is the inner loop of GLMM optimization.

    Args:
        X: Fixed effects design matrix (n, p)
        Z: Random effects design matrix (n, q), scipy sparse
        Lambda: Cholesky-like factor from theta (q, q), scipy sparse
        y: Response vector (n,)
        family: GLM family (binomial, poisson)
        eta_init: Initial linear predictor (optional)
        prior_weights: Prior observation weights (n,). For binomial with
            proportions, this should be the number of trials.
        beta_fixed: If provided, solve only for u with beta held fixed.
            This is used in Stage 2 optimization to evaluate deviance at
            arbitrary (theta, beta) points without re-optimizing beta.
        max_iter: Maximum PIRLS iterations
        tol: Convergence tolerance on relative deviance change (1e-7 matches lme4)
        verbose: Print iteration info
        factor_S22: Cached Cholesky factor for S22 block (L'Z'WZL + I).
            If provided, reuses symbolic analysis across calls. Useful for
            caching across theta evaluations in the optimizer.
        factor_S: Cached Cholesky factor for full augmented system.
            Only used when beta_fixed is None (full solve mode).
        pattern_template: PatternTemplate for preserving sparsity patterns.
            When provided, ensures S22 has consistent pattern for cross-theta
            caching. This is required for cross-theta factor caching to work
            correctly when theta has boundary values (theta=0).

    Returns:
        Dictionary with keys:
        - beta: Fixed effects coefficients (p,)
        - u: Spherical random effects (q,)
        - eta: Final linear predictor (n,)
        - mu: Final fitted values (n,)
        - deviance: GLMM deviance at convergence
        - converged: Whether PIRLS converged
        - n_iter: Number of iterations
        - logdet_L: Log-determinant
        - factor_S22: Cholesky factor for S22 (for caching)
        - factor_S: Cholesky factor for full system (for caching, full mode only)
    """
    n, p = X.shape

    # Initialize prior weights
    if prior_weights is None:
        prior_weights = np.ones(n)
    else:
        prior_weights = np.asarray(prior_weights).ravel()

    # Initialize linear predictor
    if eta_init is None:
        if beta_fixed is not None:
            # When beta is fixed, initialize eta from beta
            eta = X @ beta_fixed
        else:
            # Use GLM initialization with prior weights (matches lme4's behavior)
            # For binomial: mustart = (weights * y + 0.5) / (weights + 1)
            mu_init = np.asarray(family.initialize(y, prior_weights))
            eta = np.asarray(family.link(mu_init))
    else:
        eta = eta_init.copy()

    # Initialize deviance tracking
    dev_old = np.inf
    converged = False
    max_step_halving = 20  # Match lme4's PIRLS step-halving limit

    # Track u for step-halving (needed when beta is fixed)
    u = np.zeros(Lambda.shape[0])

    # Pre-compute ZL (sparse) and ZL_dense once (constant during PIRLS iterations)
    ZL = Z @ Lambda
    ZL_dense = ZL.toarray()

    # factor_S22 and factor_S are passed as parameters for cross-call caching
    # They will be updated in-place during iterations and returned for reuse

    for iteration in range(max_iter):
        eta_old = eta.copy()
        u_old = u.copy()

        # Compute IRLS quantities
        working_weights, working_response = compute_irls_quantities(y, eta, family)

        # Combine prior weights with IRLS working weights
        total_weights = prior_weights * working_weights

        # Solve weighted PLS (with beta_fixed if provided, reuse pre-computed ZL/ZL_dense)
        # Pass cached factors and pattern_template to avoid repeated symbolic analysis
        pls_result = solve_weighted_pls_sparse(
            X,
            Z,
            Lambda,
            working_response,
            total_weights,
            beta_fixed=beta_fixed,
            ZL=ZL,
            ZL_dense=ZL_dense,
            factor_S22=factor_S22,
            factor_S=factor_S,
            pattern_template=pattern_template,
        )

        beta = pls_result["beta"]
        u = pls_result["u"]
        logdet_L = pls_result["logdet_L"]

        # Cache factors for next iteration (avoids repeated symbolic analysis)
        factor_S22 = pls_result.get("factor_S22")
        factor_S = pls_result.get("factor_S")

        # Update linear predictor: eta = X*beta + Z*L*u
        eta_new = X @ beta + ZL_dense @ u

        # Compute deviance for convergence check
        mu_new = np.asarray(family.link_inverse(eta_new))
        sqrL = np.sum(u**2)
        dev_new = glmm_deviance(y, mu_new, family, logdet_L, sqrL, prior_weights)

        # Step-halving if deviance increased
        n_halving = 0
        while (np.isnan(dev_new) or dev_new > dev_old) and n_halving < max_step_halving:
            n_halving += 1
            # Halve both eta and u steps
            eta_new = (eta_new + eta_old) / 2.0
            u = (u + u_old) / 2.0
            mu_new = np.asarray(family.link_inverse(eta_new))
            sqrL = np.sum(u**2)
            dev_new = glmm_deviance(y, mu_new, family, logdet_L, sqrL, prior_weights)

            if verbose:
                print(f"  Step-halving {n_halving}: deviance = {dev_new:.6f}")

        # Check convergence
        dev_change = np.abs(dev_new - dev_old)
        rel_change = dev_change / (np.abs(dev_new) + 1e-10)

        if verbose:
            print(
                f"PIRLS iter {iteration + 1}: "
                f"deviance = {dev_new:.6f}, "
                f"rel_change = {rel_change:.2e}"
            )

        if rel_change < tol:
            converged = True
            if verbose:
                print(f"PIRLS converged after {iteration + 1} iterations")
            break

        eta = eta_new
        dev_old = dev_new

    # Final values
    mu_final = np.asarray(family.link_inverse(eta))
    sqrL_final = np.sum(u**2)
    deviance = glmm_deviance(y, mu_final, family, logdet_L, sqrL_final, prior_weights)

    return {
        "beta": beta,
        "u": u,
        "eta": eta,
        "mu": mu_final,
        "deviance": float(deviance),
        "converged": converged,
        "n_iter": iteration + 1,
        "logdet_L": logdet_L,
        "factor_S22": factor_S22,
        "factor_S": factor_S,
    }
