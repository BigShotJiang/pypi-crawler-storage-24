"""Lambda matrix construction from theta parameters.

This module is a re-export facade. Implementation lives in:
- lambda_template: Template/pattern caching for efficient optimization
- lambda_sparse: Sparse matrix construction and theta-Cholesky conversions

All public names are re-exported here for backward compatibility.
"""

from bossanova.internal.maths.solvers.lambda_sparse import (
    build_lambda_sparse,
    cholesky_block_to_theta,
    theta_to_cholesky_block,
    theta_to_variance_params,
)
from bossanova.internal.maths.solvers.lambda_template import (
    LambdaTemplate,
    PatternTemplate,
    build_lambda_template,
    build_pattern_template,
    compute_s22_preserve_pattern,
    compute_zl_preserve_pattern,
    update_lambda_from_template,
)

__all__ = [
    "LambdaTemplate",
    "PatternTemplate",
    "build_lambda_sparse",
    "build_lambda_template",
    "build_pattern_template",
    "cholesky_block_to_theta",
    "compute_s22_preserve_pattern",
    "compute_zl_preserve_pattern",
    "theta_to_cholesky_block",
    "theta_to_variance_params",
    "update_lambda_from_template",
]
