"""Sparse Lambda matrix construction and theta-Cholesky conversions.

Lambda is the Cholesky-like factor of the random effects covariance matrix.
It is block-diagonal, with blocks corresponding to grouping factors.

Theta Parameterization (lme4-compatible):
-----------------------------------------
Theta contains elements of the lower triangular Cholesky factor L, where
the random effects covariance is Sigma = sigma^2 * Lambda * Lambda' and Lambda
is built from theta.

Theta is on the **relative scale** (divided by sigma), following lme4's convention.

Examples:
- Random intercept (1|group): theta = [tau/sigma], dim = 1
- Correlated slopes (1+x|group): theta = [L00/sigma, L10/sigma, L11/sigma], dim = 3
- Uncorrelated slopes (1+x||group): theta = [L00/sigma, L11/sigma], dim = 2
- Nested (1|school/class): theta = [tau1/sigma, tau2/sigma], dim = 2
- Crossed (1|subject) + (1|item): theta = [tau1/sigma, tau2/sigma], dim = 2

During optimization, theta is constrained:
- Diagonal elements: theta >= 0 (ensures PSD)
- Off-diagonal elements: -inf < theta < inf
"""

from __future__ import annotations

import numpy as np
import scipy.sparse as sp

__all__ = [
    "build_lambda_sparse",
    "cholesky_block_to_theta",
    "theta_to_cholesky_block",
    "theta_to_variance_params",
]


def theta_to_cholesky_block(theta: np.ndarray, dim: int) -> np.ndarray:
    """Convert theta vector to lower-triangular Cholesky block.

    Args:
        theta: Cholesky factor elements (lower triangle, column-major).
            For 2x2: [L00, L10, L11], length = 3
            For 3x3: [L00, L10, L11, L20, L21, L22], length = 6
        dim: Dimension of the Cholesky block (2, 3, etc.).

    Returns:
        Lower triangular Cholesky block, shape (dim, dim).

    Examples:
        >>> theta = np.array([1.5, 0.3, 1.2])
        >>> L = theta_to_cholesky_block(theta, 2)
        >>> L
        array([[1.5, 0. ],
               [0.3, 1.2]])

    Notes:
        - Fills lower triangle column-by-column (Fortran order)
        - Diagonal elements should be positive for valid Cholesky
    """
    # Verify theta length
    expected_len = dim * (dim + 1) // 2
    if len(theta) != expected_len:
        raise ValueError(
            f"theta length ({len(theta)}) does not match expected "
            f"length ({expected_len}) for dim={dim}"
        )

    # Build lower triangular matrix
    L = np.zeros((dim, dim))
    idx = 0
    for col in range(dim):
        for row in range(col, dim):
            L[row, col] = theta[idx]
            idx += 1

    return L


def cholesky_block_to_theta(L: np.ndarray) -> np.ndarray:
    """Convert lower-triangular Cholesky block to theta vector.

    Args:
        L: Lower triangular Cholesky block, shape (dim, dim).

    Returns:
        Theta vector (lower triangle elements, column-major).

    Examples:
        >>> L = np.array([[1.5, 0.0], [0.3, 1.2]])
        >>> theta = cholesky_block_to_theta(L)
        >>> theta
        array([1.5, 0.3, 1.2])

    Notes:
        - Extracts lower triangle column-by-column
        - Inverse of theta_to_cholesky_block
    """
    dim = L.shape[0]
    theta = []

    for col in range(dim):
        for row in range(col, dim):
            theta.append(L[row, col])

    return np.array(theta)


def theta_to_variance_params(
    theta: np.ndarray, is_diagonal: bool = False
) -> tuple[np.ndarray, np.ndarray]:
    """Convert theta (Cholesky elements) to variance parameters.

    Computes standard deviations and correlations from Cholesky factor.

    Args:
        theta: Cholesky factor elements (lower triangle, column-major).
            For intercept: [L00], length = 1
            For slopes (2D): [L00, L10, L11], length = 3
            For diagonal (2D): [L00, L11], length = 2
        is_diagonal: If True, theta contains only diagonal elements (|| syntax).

    Returns:
        Tuple of (standard_deviations, correlations):
        - standard_deviations: sqrt(diag(Sigma)), shape (n,)
        - correlations: off-diagonal correlations, shape (n*(n-1)/2,)

    Examples:
        >>> # Correlated slopes
        >>> theta = np.array([1.5, 0.3, 1.2])
        >>> sds, rhos = theta_to_variance_params(theta)
        >>> sds  # sqrt(diag(L @ L.T))
        array([1.5       , 1.23693169])
        >>> rhos  # correlation between intercept and slope
        array([0.24253563])

        >>> # Uncorrelated slopes
        >>> theta = np.array([1.5, 1.2])
        >>> sds, rhos = theta_to_variance_params(theta, is_diagonal=True)
        >>> sds
        array([1.5, 1.2])
        >>> rhos  # empty for diagonal structure
        array([])

    Notes:
        - For diagonal structures, SDs are just theta values
        - For full structures, computes Sigma = L @ L.T then extracts params
    """
    n_theta = len(theta)

    # Simple intercept: single parameter
    if n_theta == 1:
        return theta, np.array([])

    # Diagonal structure: no correlations
    if is_diagonal:
        return theta, np.array([])

    # Full structure: compute from Cholesky
    # Determine dimension: n*(n+1)/2 = n_theta => n = (-1 + sqrt(1 + 8*n_theta)) / 2
    dim = int((-1 + np.sqrt(1 + 8 * n_theta)) / 2)

    if dim * (dim + 1) // 2 != n_theta:
        raise ValueError(
            f"Invalid theta length {n_theta}. Must be triangular number (1, 3, 6, ...)"
        )

    # Reconstruct Cholesky block
    L = theta_to_cholesky_block(theta, dim)

    # Compute covariance: Sigma = L @ L.T
    Sigma = L @ L.T

    # Extract standard deviations
    sds = np.sqrt(np.diag(Sigma))

    # Extract correlations (lower triangle, excluding diagonal)
    rhos = []
    for i in range(dim):
        for j in range(i):
            denom = sds[i] * sds[j]
            if denom > 0:
                rho = Sigma[i, j] / denom
            else:
                rho = 0.0
            rhos.append(rho)

    return sds, np.array(rhos)


def build_lambda_sparse(
    theta: np.ndarray,
    n_groups_list: list[int],
    re_structure: str,
    metadata: dict | None = None,
) -> sp.csc_matrix:
    """Build sparse block-diagonal Lambda matrix from theta.

    Lambda is constructed based on the random effects structure:
    - Intercept: Diagonal with theta[i] repeated
    - Diagonal: Block-diagonal with diagonal blocks
    - Slope: Block-diagonal with full Cholesky blocks
    - Nested/Crossed: Concatenated blocks per grouping factor

    Args:
        theta: Cholesky factor elements (lower triangle, column-major).
        n_groups_list: Number of groups per grouping factor.
            For simple models: [n_groups]
            For nested/crossed: [n_groups_factor1, n_groups_factor2, ...]
        re_structure: Random effects structure type.
            Options: "intercept", "slope", "diagonal", "nested", "crossed", "mixed"
        metadata: Optional metadata dict with structure information.
            May contain 're_structures_list' for mixed models.

    Returns:
        Sparse block-diagonal Lambda matrix, CSC format.

    Examples:
        >>> # Random intercept: (1|group)
        >>> theta = np.array([1.5])
        >>> Lambda = build_lambda_sparse(theta, [10], "intercept")
        >>> Lambda.shape
        (10, 10)

        >>> # Correlated slopes: (1+x|group)
        >>> theta = np.array([1.5, 0.3, 1.2])  # [L00, L10, L11]
        >>> Lambda = build_lambda_sparse(theta, [18], "slope")
        >>> Lambda.shape
        (36, 36)  # 18 groups x 2 RE per group

        >>> # Uncorrelated slopes: (1+x||group)
        >>> theta = np.array([1.5, 1.2])  # [L00, L11]
        >>> Lambda = build_lambda_sparse(theta, [18], "diagonal")
        >>> Lambda.shape
        (36, 36)

    Notes:
        - Returns CSC format for compatibility with CHOLMOD
        - Blocks are arranged per lme4's conventions
        - For diagonal structures, uses blocked layout (all intercepts, then slopes)
    """
    if metadata is None:
        metadata = {}

    if re_structure == "intercept":
        # Diagonal Lambda with repeated theta values
        if len(n_groups_list) == 1:
            # Simple intercept: (1|group)
            tau = theta[0]
            n_groups = n_groups_list[0]
            return sp.diags([tau], offsets=0, shape=(n_groups, n_groups), format="csc")
        else:
            # Multiple factors (crossed/nested intercepts)
            # theta = [tau1, tau2, ...]
            blocks = []
            for i, (tau, n_groups) in enumerate(zip(theta, n_groups_list)):
                block = sp.diags(
                    [tau], offsets=0, shape=(n_groups, n_groups), format="csc"
                )
                blocks.append(block)
            return sp.block_diag(blocks, format="csc")

    elif re_structure == "diagonal":
        # Uncorrelated slopes: blocked diagonal structure
        # theta = [L00, L11, L22, ...] for k RE per group
        # Layout: [group1_re1, group2_re1, ..., group1_re2, group2_re2, ...]
        n_groups = n_groups_list[0]
        k = len(theta)  # Number of RE per group
        q = n_groups * k

        # Build diagonal with blocked structure
        diag_values = []
        for tau in theta:
            diag_values.extend([tau] * n_groups)

        return sp.diags(diag_values, offsets=0, shape=(q, q), format="csc")

    elif re_structure == "slope":
        # Correlated slopes: block-diagonal with Cholesky blocks
        # theta = [L00, L10, L11, ...] (lower triangle)
        n_theta = len(theta)
        dim = int((-1 + np.sqrt(1 + 8 * n_theta)) / 2)

        if dim * (dim + 1) // 2 != n_theta:
            raise ValueError(
                f"Invalid theta length {n_theta} for slope structure. "
                f"Must be triangular number (3, 6, 10, ...)"
            )

        # Build Cholesky block
        L = theta_to_cholesky_block(theta, dim)

        # Repeat block for each group
        n_groups = n_groups_list[0]
        block_sparse = sp.csc_matrix(L)
        blocks = [block_sparse for _ in range(n_groups)]

        return sp.block_diag(blocks, format="csc")

    elif re_structure in ("nested", "crossed"):
        # Each grouping factor gets its own block
        # For intercepts: one diagonal block per factor
        # For slopes: multiple Cholesky blocks per factor
        re_structures_list = metadata.get("re_structures_list", None)
        re_dims_list = metadata.get("re_dims_list", None)

        if re_structures_list is None:
            # Default: assume all intercepts
            re_structures_list = ["intercept"] * len(n_groups_list)

        blocks = []
        theta_offset = 0

        for fi, (n_groups, factor_structure) in enumerate(
            zip(n_groups_list, re_structures_list)
        ):
            if factor_structure == "intercept":
                # Single variance parameter
                tau = theta[theta_offset]
                block = sp.diags(
                    [tau], offsets=0, shape=(n_groups, n_groups), format="csc"
                )
                theta_offset += 1

            elif factor_structure == "slope":
                dim = re_dims_list[fi] if re_dims_list else 2
                n_params = dim * (dim + 1) // 2
                theta_factor = theta[theta_offset : theta_offset + n_params]
                L = theta_to_cholesky_block(theta_factor, dim)

                # Repeat for each group in this factor
                block_sparse = sp.csc_matrix(L)
                factor_blocks = [block_sparse for _ in range(n_groups)]
                block = sp.block_diag(factor_blocks, format="csc")
                theta_offset += n_params

            elif factor_structure == "diagonal":
                dim = re_dims_list[fi] if re_dims_list else 2
                # Diagonal: dim independent variance parameters
                diag_vals = np.repeat(
                    theta[theta_offset : theta_offset + dim], n_groups
                )
                q = n_groups * dim
                block = sp.diags(diag_vals, offsets=0, shape=(q, q), format="csc")
                theta_offset += dim

            else:
                raise ValueError(f"Unknown factor structure: {factor_structure}")

            blocks.append(block)

        return sp.block_diag(blocks, format="csc")

    elif re_structure == "mixed":
        # Mixed structures require per-factor metadata
        re_structures_list = metadata.get("re_structures_list", None)
        re_dims_list = metadata.get("re_dims_list", None)
        if re_structures_list is None:
            raise ValueError(
                "Mixed structure requires 're_structures_list' in metadata"
            )

        blocks = []
        theta_offset = 0

        for fi, (n_groups, factor_structure) in enumerate(
            zip(n_groups_list, re_structures_list)
        ):
            if factor_structure == "intercept":
                tau = theta[theta_offset]
                block = sp.diags(
                    [tau], offsets=0, shape=(n_groups, n_groups), format="csc"
                )
                theta_offset += 1

            elif factor_structure == "slope":
                dim = re_dims_list[fi] if re_dims_list else 2
                n_params = dim * (dim + 1) // 2
                theta_factor = theta[theta_offset : theta_offset + n_params]
                L = theta_to_cholesky_block(theta_factor, dim)

                block_sparse = sp.csc_matrix(L)
                factor_blocks = [block_sparse for _ in range(n_groups)]
                block = sp.block_diag(factor_blocks, format="csc")
                theta_offset += n_params

            elif factor_structure == "diagonal":
                dim = re_dims_list[fi] if re_dims_list else 2
                diag_vals = np.repeat(
                    theta[theta_offset : theta_offset + dim], n_groups
                )
                q = n_groups * dim
                block = sp.diags(diag_vals, offsets=0, shape=(q, q), format="csc")
                theta_offset += dim

            else:
                raise ValueError(f"Unknown factor structure: {factor_structure}")

            blocks.append(block)

        return sp.block_diag(blocks, format="csc")

    else:
        raise ValueError(f"Unknown re_structure: {re_structure}")
