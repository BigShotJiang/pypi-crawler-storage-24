"""Statistical inference utilities for bossanova."""

# Estimation
from .estimation import (
    InferenceResult,
    compute_ci,
    compute_coefficient_inference,
    compute_se_from_vcov,
    compute_t_critical,
    compute_z_critical,
    delta_method_se,
    parse_conf_int,
)

# Hypothesis testing
from .hypothesis import (
    Chi2TestResult,
    FTestResult,
    TTestResult,
    adjust_pvalues,
    compute_chi2_test,
    compute_contrast_variance,
    compute_f_pvalue,
    compute_f_test,
    compute_pvalue,
    compute_t_test,
    compute_wald_statistic,
    format_pvalue_with_stars,
)

# Information criteria
from .information_criteria import (
    compute_aic,
    compute_akaike_weights,
    compute_bic,
    compute_deviance,
)

# Diagnostics
from .diagnostics import (
    compute_cooks_distance,
    compute_leverage,
    compute_studentized_residuals,
    compute_vif,
)

# Sandwich estimators
from .sandwich import (
    compute_cr_vcov,
    compute_glm_cr_vcov,
    compute_glm_hc_vcov,
    compute_hc_vcov,
)

# Satterthwaite degrees of freedom
from .satterthwaite import (
    compute_satterthwaite_summary_table,
    compute_satterthwaite_df,
    satterthwaite_df_for_contrasts,
    compute_satterthwaite_t_test,
)

# Welch-Satterthwaite
from .welch import (
    CellInfo,
    compute_cell_info,
    extract_factors_from_formula,
    compute_welch_satterthwaite_df_per_coef,
)

# Wald variance
from .wald_variance import (
    build_cholesky_with_derivs,
    compute_sd_jacobian,
    compute_wald_ci_varying,
)

# Multiplicity adjustment
from .multiplicity import (
    compute_mvt_critical,
    compute_tukey_critical,
)

# Profile likelihood
from .profile import (
    extract_ci_bound,
    get_sigpar_bounds,
    profile_likelihood_sigpar,
    profile_theta_parameter,
    sigpar_to_theta,
    theta_to_sigpar,
)

__all__ = [
    "CellInfo",
    "Chi2TestResult",
    "FTestResult",
    "InferenceResult",
    "TTestResult",
    "adjust_pvalues",
    "build_cholesky_with_derivs",
    "compute_aic",
    "compute_akaike_weights",
    "compute_bic",
    "compute_cell_info",
    "compute_chi2_test",
    "compute_ci",
    "compute_coefficient_inference",
    "compute_contrast_variance",
    "compute_cooks_distance",
    "compute_cr_vcov",
    "compute_deviance",
    "compute_f_pvalue",
    "compute_f_test",
    "compute_glm_cr_vcov",
    "compute_glm_hc_vcov",
    "compute_hc_vcov",
    "compute_leverage",
    "compute_mvt_critical",
    "compute_pvalue",
    "compute_satterthwaite_df",
    "compute_satterthwaite_summary_table",
    "compute_satterthwaite_t_test",
    "compute_sd_jacobian",
    "compute_se_from_vcov",
    "compute_studentized_residuals",
    "compute_t_critical",
    "compute_t_test",
    "compute_tukey_critical",
    "compute_vif",
    "compute_wald_ci_varying",
    "compute_wald_statistic",
    "compute_welch_satterthwaite_df_per_coef",
    "compute_z_critical",
    "delta_method_se",
    "extract_ci_bound",
    "extract_factors_from_formula",
    "format_pvalue_with_stars",
    "get_sigpar_bounds",
    "parse_conf_int",
    "profile_likelihood_sigpar",
    "profile_theta_parameter",
    "satterthwaite_df_for_contrasts",
    "sigpar_to_theta",
    "theta_to_sigpar",
]
