"""Profile likelihood for variance components in mixed-effects models.

This module implements the profile likelihood algorithm for computing
confidence intervals for variance components (theta parameters and sigma)
in linear mixed-effects models.

The algorithm follows MixedModels.jl and lme4:
1. For each theta parameter, step bidirectionally from the MLE
2. At each step, fix that theta and re-optimize all other thetas
3. Sigma is derived analytically at each step (profile concentrated likelihood)
4. Compute the signed likelihood root: zeta = sign * sqrt(dev - dev_opt)
5. Fit B-splines for interpolation
6. Extract CIs where |zeta| = sqrt(chi2(conf_level, df=1))

References:
    - Bates et al. (2015). Fitting Linear Mixed-Effects Models Using lme4.
    - MixedModels.jl: https://github.com/JuliaStats/MixedModels.jl
"""

from typing import Callable

__all__ = [
    "extract_ci_bound",
    "get_sigpar_bounds",
    "profile_likelihood_sigpar",
    "profile_theta_parameter",
    "sigpar_to_theta",
    "theta_to_sigpar",
]

import numpy as np
import polars as pl
from scipy import stats
from scipy.interpolate import UnivariateSpline


def profile_theta_parameter(
    param_idx: int,
    param_name: str,
    param_opt: float,
    theta_opt: np.ndarray,
    dev_opt: float,
    deviance_fn: Callable[[np.ndarray], float],
    lower_bounds: np.ndarray,
    n_steps: int,
    threshold: float,
    verbose: bool,
) -> dict:
    """Profile a single parameter bidirectionally from its MLE.

    Generic stepping routine: fixes one parameter, re-optimizes the rest,
    records (focal, zeta) pairs. Works on any parameter vector (theta or
    sigpar) — the caller provides the appropriate deviance function and
    bounds.

    Args:
        param_idx: Index of parameter in the vector.
        param_name: Human-readable name.
        param_opt: Optimal value of this parameter.
        theta_opt: Full optimal parameter vector.
        dev_opt: Optimal deviance.
        deviance_fn: Function param_vector -> deviance.
        lower_bounds: Lower bounds for ALL parameters.
        n_steps: Steps in each direction.
        threshold: Maximum |zeta| to profile.
        verbose: Print progress.

    Returns:
        Dict with 'rows', 'focal', 'zeta' lists.
    """
    from scipy.optimize import minimize

    rows: list[dict] = []
    focal_values: list[float] = []
    zeta_values: list[float] = []

    n_params = len(theta_opt)
    lower_bound = lower_bounds[param_idx]

    # Start with optimal point
    rows.append({"param": param_name, "focal": param_opt, "zeta": 0.0})
    focal_values.append(param_opt)
    zeta_values.append(0.0)

    # Create mask for non-focal parameters
    non_focal_mask = np.ones(n_params, dtype=bool)
    non_focal_mask[param_idx] = False
    non_focal_bounds = [
        (lower_bounds[j], None) for j in range(n_params) if j != param_idx
    ]

    def conditional_deviance(non_focal_params: np.ndarray, focal_value: float) -> float:
        """Deviance with focal parameter fixed."""
        params = np.empty(n_params)
        params[non_focal_mask] = non_focal_params
        params[param_idx] = focal_value
        return deviance_fn(params)

    def profile_at_focal(
        focal: float, init_non_focal: np.ndarray
    ) -> tuple[float, np.ndarray]:
        """Find conditional MLE deviance at fixed focal value."""
        if len(init_non_focal) == 0:
            return deviance_fn(np.array([focal])), np.array([])

        result = minimize(
            conditional_deviance,
            init_non_focal,
            args=(focal,),
            method="L-BFGS-B",
            bounds=non_focal_bounds,
            options={"maxiter": 100, "ftol": 1e-8},
        )
        return result.fun, result.x

    # Step size: geometric spacing from 10% of param value (min 0.05)
    base_step = max(abs(param_opt) * 0.1, 0.05)

    # Track last successful non-focal params for warm-starting
    last_non_focal = theta_opt[non_focal_mask].copy()

    # Profile downward (toward lower bound)
    for step in range(1, n_steps + 1):
        focal = param_opt - base_step * (1.3 ** (step - 1))
        focal = max(focal, lower_bound + 1e-8)

        try:
            dev, new_non_focal = profile_at_focal(focal, last_non_focal)
        except Exception:
            break

        if np.isinf(dev) or np.isnan(dev):
            break

        dev_diff = dev - dev_opt
        if dev_diff < -1e-6:
            dev_diff = 0.0
        zeta = -np.sqrt(max(0, dev_diff))

        rows.append({"param": param_name, "focal": focal, "zeta": zeta})
        focal_values.append(focal)
        zeta_values.append(zeta)

        if len(new_non_focal) > 0:
            last_non_focal = new_non_focal

        if abs(zeta) > threshold:
            break
        if focal <= lower_bound + 1e-7:
            break

    # Reset for upward profiling
    last_non_focal = theta_opt[non_focal_mask].copy()

    # Profile upward (away from lower bound)
    for step in range(1, n_steps + 1):
        focal = param_opt + base_step * (1.3 ** (step - 1))

        try:
            dev, new_non_focal = profile_at_focal(focal, last_non_focal)
        except Exception:
            break

        if np.isinf(dev) or np.isnan(dev):
            break

        dev_diff = dev - dev_opt
        if dev_diff < -1e-6:
            dev_diff = 0.0
        zeta = np.sqrt(max(0, dev_diff))

        rows.append({"param": param_name, "focal": focal, "zeta": zeta})
        focal_values.append(focal)
        zeta_values.append(zeta)

        if len(new_non_focal) > 0:
            last_non_focal = new_non_focal

        if abs(zeta) > threshold:
            break

    return {"rows": rows, "focal": focal_values, "zeta": zeta_values}


# =============================================================================
# Sigpar-scale conversions (theta <-> SD/corr + sigma)
# =============================================================================


def _parse_re_structure(
    re_structure: str | list[str],
    group_names: list[str],
    random_names: list[str] | dict[str, list[str]],
) -> tuple[dict[str, str], dict[str, list[str]]]:
    """Normalize re_structure and random_names to per-group dicts."""
    if isinstance(re_structure, str):
        structure_dict = {gn: re_structure for gn in group_names}
    else:
        structure_dict = dict(zip(group_names, re_structure))

    if isinstance(random_names, list):
        names_dict = {gn: random_names for gn in group_names}
    else:
        names_dict = random_names

    return structure_dict, names_dict


def _sdcor2cov(m: np.ndarray) -> np.ndarray:
    """Convert SD/correlation matrix to covariance matrix.

    Matching lme4's ``sdcor2cov``: diagonal holds SDs, off-diagonal holds
    correlations.  Returns ``diag(SD) @ R @ diag(SD)``.
    """
    sds = np.diag(m).copy()
    D = np.diag(sds)
    # Build correlation matrix: diagonal=1, off-diagonal=correlations
    R = m.copy()
    np.fill_diagonal(R, 1.0)
    return D @ R @ D


def _cov2sdcor(V: np.ndarray) -> np.ndarray:
    """Convert covariance matrix to SD/correlation matrix.

    Diagonal holds SDs, off-diagonal holds correlations.
    """
    sds = np.sqrt(np.diag(V))
    dim = len(sds)
    result = np.zeros((dim, dim))
    np.fill_diagonal(result, sds)
    for i in range(dim):
        for j in range(i):
            result[i, j] = (
                V[i, j] / (sds[i] * sds[j]) if sds[i] > 0 and sds[j] > 0 else 0.0
            )
            result[j, i] = result[i, j]
    return result


def theta_to_sigpar(
    theta: np.ndarray,
    sigma: float,
    re_structure: str | list[str],
    group_names: list[str],
    random_names: list[str] | dict[str, list[str]],
) -> np.ndarray:
    """Convert theta (relative Cholesky) + sigma to sigpar (SD/corr + sigma).

    Sigpar layout: ``[sd_g1_re1, sd_g1_re2, ..., corr_g1..., sd_g2..., sigma]``

    For intercept/diagonal groups, ``SD_i = sigma * |theta_i|``.
    For slope groups, reconstruct ``L``, compute ``Sigma_rel = L @ L.T``,
    convert to SD/corr, then ``SD_i = sigma * rel_SD_i``.

    Args:
        theta: Relative Cholesky factor vector (column-major).
        sigma: Residual standard deviation.
        re_structure: Per-group RE structure.
        group_names: Grouping factor names.
        random_names: RE names per group.

    Returns:
        Flat sigpar vector with sigma as final element.
    """
    structure_dict, names_dict = _parse_re_structure(
        re_structure, group_names, random_names
    )

    sigpar_parts: list[float] = []
    theta_idx = 0

    for gn in group_names:
        structure = structure_dict[gn]
        re_names = names_dict[gn]
        n_re = len(re_names)

        if structure == "intercept":
            sigpar_parts.append(sigma * abs(theta[theta_idx]))
            theta_idx += 1

        elif structure == "diagonal":
            for j in range(n_re):
                sigpar_parts.append(sigma * abs(theta[theta_idx + j]))
            theta_idx += n_re

        elif structure == "slope":
            n_theta_group = n_re * (n_re + 1) // 2
            group_theta = theta[theta_idx : theta_idx + n_theta_group]

            # Reconstruct L (column-major fill)
            L = np.zeros((n_re, n_re))
            k = 0
            for col in range(n_re):
                for row in range(col, n_re):
                    L[row, col] = group_theta[k]
                    k += 1

            # Sigma_rel = L @ L.T, then convert to SD/corr
            Sigma_rel = L @ L.T
            sdcor = _cov2sdcor(Sigma_rel)

            # Append SDs (sigma * rel_SD)
            for j in range(n_re):
                sigpar_parts.append(sigma * sdcor[j, j])

            # Append lower-triangle correlations (column-major)
            for col in range(n_re):
                for row in range(col + 1, n_re):
                    sigpar_parts.append(sdcor[row, col])

            theta_idx += n_theta_group
        else:
            raise ValueError(f"Unknown RE structure: {structure}")

    sigpar_parts.append(sigma)
    return np.array(sigpar_parts)


def sigpar_to_theta(
    sigpar: np.ndarray,
    re_structure: str | list[str],
    group_names: list[str],
    random_names: list[str] | dict[str, list[str]],
) -> tuple[np.ndarray, float]:
    """Convert sigpar (SD/corr + sigma) back to theta + sigma.

    Inverse of ``theta_to_sigpar``.

    Args:
        sigpar: Flat sigpar vector (SDs, correlations, sigma as last element).
        re_structure: Per-group RE structure.
        group_names: Grouping factor names.
        random_names: RE names per group.

    Returns:
        Tuple of (theta, sigma).
    """
    structure_dict, names_dict = _parse_re_structure(
        re_structure, group_names, random_names
    )

    sigma = float(sigpar[-1])
    theta_parts: list[float] = []
    sp_idx = 0

    for gn in group_names:
        structure = structure_dict[gn]
        re_names = names_dict[gn]
        n_re = len(re_names)

        if structure == "intercept":
            sd = sigpar[sp_idx]
            theta_parts.append(sd / sigma if sigma > 0 else 0.0)
            sp_idx += 1

        elif structure == "diagonal":
            for j in range(n_re):
                sd = sigpar[sp_idx + j]
                theta_parts.append(sd / sigma if sigma > 0 else 0.0)
            sp_idx += n_re

        elif structure == "slope":
            # Read SDs
            sds = sigpar[sp_idx : sp_idx + n_re]
            sp_idx += n_re

            # Read correlations (lower-triangle, column-major)
            n_corr = n_re * (n_re - 1) // 2
            corrs = sigpar[sp_idx : sp_idx + n_corr]
            sp_idx += n_corr

            # Build sdcor matrix
            sdcor = np.zeros((n_re, n_re))
            np.fill_diagonal(sdcor, sds)
            k = 0
            for col in range(n_re):
                for row in range(col + 1, n_re):
                    sdcor[row, col] = corrs[k]
                    sdcor[col, row] = corrs[k]
                    k += 1

            # sdcor -> cov -> divide by sigma^2 -> cholesky -> flatten
            cov = _sdcor2cov(sdcor)
            Sigma_rel = cov / (sigma**2) if sigma > 0 else cov

            # Ensure PSD before Cholesky
            eigvals = np.linalg.eigvalsh(Sigma_rel)
            if np.any(eigvals < -1e-10):
                # Force PSD by clamping eigenvalues
                eigvals_clamped = np.maximum(eigvals, 0.0)
                eigvecs = np.linalg.eigh(Sigma_rel)[1]
                Sigma_rel = eigvecs @ np.diag(eigvals_clamped) @ eigvecs.T
            elif np.any(eigvals < 0):
                Sigma_rel = Sigma_rel - np.eye(n_re) * min(eigvals)

            L = np.linalg.cholesky(Sigma_rel)

            # Flatten column-major
            for col in range(n_re):
                for row in range(col, n_re):
                    theta_parts.append(L[row, col])
        else:
            raise ValueError(f"Unknown RE structure: {structure}")

    return np.array(theta_parts), sigma


def get_sigpar_bounds(
    re_structure: str | list[str],
    group_names: list[str],
    random_names: list[str] | dict[str, list[str]],
) -> list[tuple[float, float | None]]:
    """Get optimizer bounds for sigpar vector (for L-BFGS-B).

    SD params: ``[0.0, None]``; correlation params: ``[-1.0, 1.0]``;
    sigma: ``[1e-8, None]``.

    Args:
        re_structure: Per-group RE structure.
        group_names: Grouping factor names.
        random_names: RE names per group.

    Returns:
        List of ``(lower, upper)`` tuples, one per sigpar element.
    """
    structure_dict, names_dict = _parse_re_structure(
        re_structure, group_names, random_names
    )

    bounds: list[tuple[float, float | None]] = []

    for gn in group_names:
        structure = structure_dict[gn]
        re_names = names_dict[gn]
        n_re = len(re_names)

        if structure == "intercept":
            bounds.append((0.0, None))

        elif structure == "diagonal":
            for _ in range(n_re):
                bounds.append((0.0, None))

        elif structure == "slope":
            # SDs
            for _ in range(n_re):
                bounds.append((0.0, None))
            # Correlations
            n_corr = n_re * (n_re - 1) // 2
            for _ in range(n_corr):
                bounds.append((-1.0, 1.0))
        else:
            raise ValueError(f"Unknown RE structure: {structure}")

    # sigma
    bounds.append((1e-8, None))
    return bounds


# =============================================================================
# Sigpar-scale profile likelihood
# =============================================================================


def _build_sigpar_param_names(
    group_names: list[str],
    random_names: list[str] | dict[str, list[str]],
    re_structure: str | list[str],
) -> list[str]:
    """Build human-readable parameter names for the sigpar vector."""
    structure_dict, names_dict = _parse_re_structure(
        re_structure, group_names, random_names
    )

    names: list[str] = []
    for gn in group_names:
        structure = structure_dict[gn]
        re_names = names_dict[gn]
        n_re = len(re_names)

        if structure in ("intercept", "diagonal"):
            for rn in re_names:
                names.append(f"sd|{gn}:{rn}")
        elif structure == "slope":
            for rn in re_names:
                names.append(f"sd|{gn}:{rn}")
            for col in range(n_re):
                for row in range(col + 1, n_re):
                    names.append(f"cor|{gn}:{re_names[row]}.{re_names[col]}")

    names.append("sigma")
    return names


def profile_likelihood_sigpar(
    sigpar_opt: np.ndarray,
    sigpar_deviance_fn: Callable[[np.ndarray], float],
    sigpar_bounds: list[tuple[float, float | None]],
    dev_opt: float,
    conf_level: float = 0.95,
    threshold: float = 4.0,
    n_steps: int = 15,
    verbose: bool = False,
    *,
    group_names: list[str],
    random_names: list[str] | dict[str, list[str]],
    re_structure: str | list[str],
) -> dict:
    """Profile likelihood CIs on the sigpar (SD/corr + sigma) scale.

    Profiles each sigpar parameter directly using ``profile_theta_parameter``
    (generic stepping) and extracts CIs via spline interpolation.

    Args:
        sigpar_opt: Optimal sigpar vector.
        sigpar_deviance_fn: Non-profiled ML deviance as function of sigpar.
        sigpar_bounds: Optimizer bounds for each sigpar element.
        dev_opt: Deviance at ``sigpar_opt``.
        conf_level: Confidence level for CIs.
        threshold: Maximum |zeta| to profile.
        n_steps: Steps per direction from MLE.
        verbose: Print progress.
        group_names: Grouping factor names.
        random_names: RE names per group.
        re_structure: Per-group RE structure.

    Returns:
        Dict with keys matching ProfileState fields.
    """
    zeta_crit = np.sqrt(stats.chi2.ppf(conf_level, df=1))
    n_sigpar = len(sigpar_opt)

    param_names = _build_sigpar_param_names(group_names, random_names, re_structure)
    lower_bounds = np.array([b[0] for b in sigpar_bounds])

    all_rows: list[dict] = []
    spline_forward: dict[str, UnivariateSpline] = {}
    spline_reverse: dict[str, UnivariateSpline] = {}
    ci_sigpar: dict[str, tuple[float, float]] = {}

    for i in range(n_sigpar):
        pname = param_names[i]
        param_opt = sigpar_opt[i]
        lb = lower_bounds[i]

        if verbose:
            print(f"Profiling {pname}...")

        profile_data = profile_theta_parameter(
            param_idx=i,
            param_name=pname,
            param_opt=param_opt,
            theta_opt=sigpar_opt,
            dev_opt=dev_opt,
            deviance_fn=sigpar_deviance_fn,
            lower_bounds=lower_bounds,
            n_steps=n_steps,
            threshold=threshold,
            verbose=verbose,
        )

        all_rows.extend(profile_data["rows"])

        focal_values = np.array(profile_data["focal"])
        zeta_values = np.array(profile_data["zeta"])

        if len(focal_values) >= 4:
            sort_idx = np.argsort(focal_values)
            focal_sorted = focal_values[sort_idx]
            zeta_sorted = zeta_values[sort_idx]

            try:
                spline_fwd = UnivariateSpline(focal_sorted, zeta_sorted, k=3, s=0)
                spline_forward[pname] = spline_fwd

                zeta_sort_idx = np.argsort(zeta_sorted)
                spline_rev = UnivariateSpline(
                    zeta_sorted[zeta_sort_idx],
                    focal_sorted[zeta_sort_idx],
                    k=3,
                    s=0,
                )
                spline_reverse[pname] = spline_rev

                ci_lower = extract_ci_bound(spline_rev, -zeta_crit, lb, param_opt)
                ci_upper = extract_ci_bound(spline_rev, zeta_crit, lb, param_opt * 3)
                ci_sigpar[pname] = (ci_lower, ci_upper)

            except Exception as e:
                if verbose:
                    print(f"  Warning: spline fitting failed for {pname}: {e}")
                ci_lower = float(np.interp(-zeta_crit, zeta_sorted, focal_sorted))
                ci_upper = float(np.interp(zeta_crit, zeta_sorted, focal_sorted))
                ci_sigpar[pname] = (max(lb, ci_lower), ci_upper)
        else:
            if verbose:
                print(f"  Warning: insufficient data for {pname}, using wide CI")
            ci_sigpar[pname] = (lb, param_opt * 3)

    # Build ci_sd and ci_theta dicts from sigpar CIs
    structure_dict, names_dict = _parse_re_structure(
        re_structure, group_names, random_names
    )

    ci_sd: dict[str, tuple[float, float]] = {}
    ci_lower_list: list[float] = []
    ci_upper_list: list[float] = []

    sp_idx = 0
    for gn in group_names:
        structure = structure_dict[gn]
        re_names = names_dict[gn]
        n_re = len(re_names)

        if structure in ("intercept", "diagonal"):
            for rn in re_names:
                pname = param_names[sp_idx]
                lo, hi = ci_sigpar[pname]
                key = f"{gn}:{rn}"
                ci_sd[key] = (lo, hi)
                ci_lower_list.append(lo)
                ci_upper_list.append(hi)
                sp_idx += 1
        elif structure == "slope":
            for rn in re_names:
                pname = param_names[sp_idx]
                lo, hi = ci_sigpar[pname]
                key = f"{gn}:{rn}"
                ci_sd[key] = (lo, hi)
                ci_lower_list.append(lo)
                ci_upper_list.append(hi)
                sp_idx += 1
            # Skip correlation params
            n_corr = n_re * (n_re - 1) // 2
            sp_idx += n_corr

    # Residual (sigma)
    sigma_name = param_names[-1]
    ci_sd["Residual"] = ci_sigpar[sigma_name]
    ci_lower_list.append(ci_sigpar[sigma_name][0])
    ci_upper_list.append(ci_sigpar[sigma_name][1])

    # Build profile table
    table = pl.DataFrame(all_rows) if all_rows else pl.DataFrame()

    return {
        "table": table,
        "spline_forward": spline_forward,
        "spline_reverse": spline_reverse,
        "ci_theta": ci_sigpar,
        "ci_sd": ci_sd,
        "ci_lower_sd": np.array(ci_lower_list),
        "ci_upper_sd": np.array(ci_upper_list),
        "conf_level": conf_level,
        "dev_opt": dev_opt,
        "threshold": threshold,
    }


def extract_ci_bound(
    spline: UnivariateSpline,
    zeta_target: float,
    lower_bound: float,
    upper_guess: float,
) -> float:
    """Extract CI bound by finding where spline equals target zeta.

    Args:
        spline: Reverse spline (zeta -> param).
        zeta_target: Target zeta value (negative for lower, positive for upper).
        lower_bound: Parameter lower bound.
        upper_guess: Upper search bound guess.

    Returns:
        Parameter value where zeta = zeta_target.
    """
    try:
        # Evaluate spline at target
        result = float(spline(zeta_target))
        # Ensure within bounds
        return max(lower_bound, result)
    except Exception:
        # Fallback: linear extrapolation from spline endpoints
        return lower_bound if zeta_target < 0 else upper_guess
