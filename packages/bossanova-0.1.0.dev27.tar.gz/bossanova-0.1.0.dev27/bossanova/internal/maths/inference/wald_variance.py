"""Wald confidence intervals for variance components using delta method.

This module computes asymptotic (Wald) confidence intervals for variance
components in mixed-effects models. It uses the delta method to transform
the asymptotic covariance of variance parameters (theta, sigma) to the
standard deviation scale.

The key insight is that the Hessian of the deviance w.r.t. variance parameters
is already computed for Satterthwaite inference, and we can reuse it here:
    vcov_varpar = 2 * H^{-1}

For transformation from theta scale to SD scale, we use:
    SD[i] = sigma * sqrt(diag(L @ L.T)[i])

where L is the Cholesky factor reconstructed from theta.
"""

from __future__ import annotations

__all__ = [
    "build_cholesky_with_derivs",
    "compute_sd_jacobian",
    "compute_wald_ci_varying",
]

import numpy as np
from scipy import stats


def compute_wald_ci_varying(
    theta: np.ndarray,
    sigma: float,
    vcov_varpar: np.ndarray,
    group_names: list[str],
    random_names: list[str] | dict[str, list[str]],
    re_structure: str | list[str] | dict[str, str],
    conf_level: float = 0.95,
) -> tuple[np.ndarray, np.ndarray]:
    """Compute Wald CIs for variance components on SD scale.

    Uses the delta method to transform asymptotic variance from varpar
    (theta, sigma) scale to the standard deviation scale.

    Args:
        theta: Optimized theta parameters (relative scale).
        sigma: Residual standard deviation.
        vcov_varpar: Asymptotic covariance of [theta, sigma], shape (k, k)
            where k = len(theta) + 1. This is 2 * H^{-1} from Satterthwaite.
        group_names: Names of grouping factors.
        random_names: Names of random effects per group.
        re_structure: RE structure type(s) per group.
        conf_level: Confidence level (default 0.95).

    Returns:
        Tuple of (ci_lower, ci_upper) arrays on SD scale.
        Length = number of variance components + 1 (for residual).

    Notes:
        The delta method approximation assumes:
        1. Asymptotic normality of theta and sigma estimates
        2. Sample size large enough for the approximation to hold

        For variance components near zero (boundary), profile likelihood
        CIs are more accurate as they respect the parameter bounds.
    """
    # Compute SDs and their Jacobian w.r.t. varpar = [theta, sigma]
    sds, jacobian = compute_sd_jacobian(
        theta=theta,
        sigma=sigma,
        group_names=group_names,
        random_names=random_names,
        re_structure=re_structure,
    )

    # Delta method: Var(SD) = J @ vcov_varpar @ J.T
    # jacobian has shape (n_sds, n_theta + 1)
    vcov_sd = jacobian @ vcov_varpar @ jacobian.T

    # Standard errors on SD scale
    se_sd = np.sqrt(np.maximum(np.diag(vcov_sd), 0.0))

    # Critical value for normal distribution (Wald uses z, not t)
    z_crit = stats.norm.ppf((1 + conf_level) / 2)

    # Compute CIs
    ci_lower = sds - z_crit * se_sd
    ci_upper = sds + z_crit * se_sd

    # Truncate lower bounds at 0 (SDs are non-negative)
    ci_lower = np.maximum(ci_lower, 0.0)

    return ci_lower, ci_upper


def compute_sd_jacobian(
    theta: np.ndarray,
    sigma: float,
    group_names: list[str],
    random_names: list[str] | dict[str, list[str]],
    re_structure: str | list[str] | dict[str, str],
) -> tuple[np.ndarray, np.ndarray]:
    """Compute SDs and Jacobian of SDs w.r.t. varpar = [theta, sigma].

    For LMM with variance components:
        Sigma = sigma^2 * L @ L.T
        SD[i] = sqrt(Sigma[i,i]) = sigma * sqrt((L @ L.T)[i,i])

    The Jacobian has shape (n_sds, n_theta + 1) where the last column
    corresponds to sigma.

    Args:
        theta: Theta parameters (relative Cholesky factors).
        sigma: Residual standard deviation.
        group_names: Grouping factor names.
        random_names: Random effect names per group.
        re_structure: RE structure per group.

    Returns:
        Tuple of (sds, jacobian) where:
        - sds: Array of SD values, length = n_variance_components + 1
        - jacobian: Shape (n_sds, n_theta + 1)
    """
    n_theta = len(theta)

    # Parse structures
    if isinstance(re_structure, str):
        structure_dict = {gn: re_structure for gn in group_names}
    elif isinstance(re_structure, list):
        structure_dict = dict(zip(group_names, re_structure))
    else:
        structure_dict = re_structure

    if isinstance(random_names, list):
        if isinstance(re_structure, list) and len(random_names) == len(group_names):
            names_dict = {gn: [random_names[i]] for i, gn in enumerate(group_names)}
        else:
            names_dict = {gn: random_names for gn in group_names}
    else:
        names_dict = random_names

    # Collect SDs and Jacobian rows
    sds_list: list[float] = []
    jac_rows: list[np.ndarray] = []

    theta_idx = 0

    for group_name in group_names:
        structure = structure_dict[group_name]
        re_names = names_dict[group_name]
        n_re = len(re_names)

        # Extract theta indices for this group
        if structure == "intercept":
            n_group_theta = 1
        elif structure == "diagonal":
            n_group_theta = n_re
        elif structure == "slope":
            n_group_theta = n_re * (n_re + 1) // 2
        else:
            raise ValueError(f"Unknown RE structure: {structure}")

        group_theta = theta[theta_idx : theta_idx + n_group_theta]

        # Compute L and its derivatives
        L, dL_dtheta = build_cholesky_with_derivs(group_theta, n_re, structure)

        # Sigma = sigma^2 * L @ L.T
        # SD[i] = sigma * sqrt((L @ L.T)[i,i])
        LLT = L @ L.T
        diag_LLT = np.diag(LLT)

        for i in range(n_re):
            # SD[i] = sigma * sqrt(diag_LLT[i])
            sqrt_diag_i = np.sqrt(diag_LLT[i]) if diag_LLT[i] > 0 else 0.0
            sd_i = sigma * sqrt_diag_i
            sds_list.append(sd_i)

            # Jacobian row for SD[i] w.r.t. [theta, sigma]
            jac_row = np.zeros(n_theta + 1)

            if sqrt_diag_i > 1e-10:
                # d(SD[i])/d(theta_j) = sigma * d(sqrt(diag_LLT[i]))/d(theta_j)
                #                     = sigma / (2 * sqrt(diag_LLT[i])) * d(diag_LLT[i])/d(theta_j)
                #
                # diag_LLT[i] = sum_k L[i,k]^2
                # d(diag_LLT[i])/d(theta_j) = 2 * sum_k L[i,k] * dL[i,k]/d(theta_j)
                for j in range(n_group_theta):
                    # d(diag_LLT[i])/d(theta_j)
                    d_diag_d_theta_j = 2.0 * np.sum(L[i, :] * dL_dtheta[j][i, :])
                    # d(SD[i])/d(theta_j)
                    jac_row[theta_idx + j] = (
                        sigma / (2.0 * sqrt_diag_i) * d_diag_d_theta_j
                    )

                # d(SD[i])/d(sigma) = sqrt(diag_LLT[i])
                jac_row[-1] = sqrt_diag_i
            else:
                # At boundary (SD = 0), derivative is technically undefined
                # Use one-sided derivative approximation
                jac_row[-1] = 0.0

            jac_rows.append(jac_row)

        theta_idx += n_group_theta

    # Add residual SD
    sds_list.append(sigma)
    jac_residual = np.zeros(n_theta + 1)
    jac_residual[-1] = 1.0  # d(sigma)/d(sigma) = 1
    jac_rows.append(jac_residual)

    return np.array(sds_list), np.array(jac_rows)


def build_cholesky_with_derivs(
    theta_group: np.ndarray,
    n_re: int,
    structure: str,
) -> tuple[np.ndarray, list[np.ndarray]]:
    """Build Cholesky factor L and its derivatives w.r.t. theta.

    Args:
        theta_group: Theta values for this group.
        n_re: Number of random effects.
        structure: "intercept", "diagonal", or "slope".

    Returns:
        Tuple of (L, dL_dtheta) where:
        - L: Cholesky factor, shape (n_re, n_re)
        - dL_dtheta: List of derivative matrices, one per theta element
    """
    dL_dtheta: list[np.ndarray] = []

    if structure == "intercept":
        # L = [[theta[0]]]
        L = np.array([[theta_group[0]]])
        # dL/d(theta[0]) = [[1]]
        dL_dtheta.append(np.array([[1.0]]))

    elif structure == "diagonal":
        # L = diag(theta)
        L = np.diag(theta_group)
        for j in range(n_re):
            dL_j = np.zeros((n_re, n_re))
            dL_j[j, j] = 1.0
            dL_dtheta.append(dL_j)

    elif structure == "slope":
        # L is lower triangular, filled column by column
        L = np.zeros((n_re, n_re))
        k = 0
        for j in range(n_re):
            for i in range(j, n_re):
                L[i, j] = theta_group[k]
                # Derivative w.r.t. theta[k]
                dL_k = np.zeros((n_re, n_re))
                dL_k[i, j] = 1.0
                dL_dtheta.append(dL_k)
                k += 1

    else:
        raise ValueError(f"Unknown RE structure: {structure}")

    return L, dL_dtheta
