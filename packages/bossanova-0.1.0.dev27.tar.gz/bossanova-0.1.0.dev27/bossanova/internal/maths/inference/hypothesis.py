"""Statistical hypothesis tests (F, chi-square, t) for linear contrasts."""

from dataclasses import dataclass

import numpy as np
from scipy import stats

# Minimum p-value floor matching R's convention (~machine epsilon).
# Prevents displaying p = 0.0 from float64 underflow.
_P_MIN: float = np.finfo(np.float64).eps

__all__ = [
    "Chi2TestResult",
    "FTestResult",
    "TTestResult",
    "adjust_pvalues",
    "compute_chi2_test",
    "compute_contrast_variance",
    "compute_f_pvalue",
    "compute_f_test",
    "compute_pvalue",
    "compute_t_test",
    "compute_wald_statistic",
    "format_pvalue_with_stars",
]


# =============================================================================
# Result Containers
# =============================================================================


@dataclass(frozen=True, slots=True)
class FTestResult:
    """Result container for F-test.

    Attributes:
        num_df: Numerator degrees of freedom (q, number of contrasts).
        den_df: Denominator degrees of freedom (residual df).
        F_value: F-statistic value.
        p_value: P-value from F-distribution.
    """

    num_df: int
    den_df: float
    F_value: float
    p_value: float


@dataclass(frozen=True, slots=True)
class Chi2TestResult:
    """Result container for chi-square test.

    Attributes:
        num_df: Degrees of freedom (q, number of contrasts).
        chi2: Wald chi-square statistic.
        p_value: P-value from chi-square distribution.
    """

    num_df: int
    chi2: float
    p_value: float


@dataclass(frozen=True, slots=True)
class TTestResult:
    """Result container for t-test.

    Attributes:
        estimate: Contrast estimate.
        se: Standard error.
        t_value: t-statistic.
        df: Degrees of freedom.
        p_value: Two-tailed p-value.
    """

    estimate: float
    se: float
    t_value: float
    df: float
    p_value: float


# =============================================================================
# Core Functions
# =============================================================================


def compute_contrast_variance(L: np.ndarray, vcov: np.ndarray) -> np.ndarray:
    """Compute variance-covariance of linear contrasts L @ β.

    For a contrast matrix L and coefficient vcov V, computes:
        Var(L @ β) = L @ V @ L'

    Args:
        L: Contrast matrix of shape (q, p).
        vcov: Variance-covariance matrix of shape (p, p).

    Returns:
        Variance-covariance of contrasts, shape (q, q).

    Examples:
        >>> L = np.array([[-1, 1, 0], [-1, 0, 1]])
        >>> vcov = np.diag([1.0, 1.5, 2.0])
        >>> var_L = compute_contrast_variance(L, vcov)
        >>> var_L.shape
        (2, 2)
    """
    return L @ vcov @ L.T


def compute_wald_statistic(
    contrast_values: np.ndarray,
    contrast_vcov: np.ndarray,
) -> float:
    """Compute Wald statistic for testing L @ β = 0.

    Computes: W = (L @ β)' @ (L @ V @ L')⁻¹ @ (L @ β)

    Uses solve for efficiency, with pinv fallback for singular matrices.

    Args:
        contrast_values: Contrast estimates L @ β, shape (q,).
        contrast_vcov: Variance of contrasts L @ V @ L', shape (q, q).

    Returns:
        Wald statistic value.

    Examples:
        >>> contrast_values = np.array([2.0, 5.0])
        >>> contrast_vcov = np.array([[2.5, 0.5], [0.5, 3.0]])
        >>> W = compute_wald_statistic(contrast_values, contrast_vcov)
        >>> W > 0
        True
    """
    try:
        return float(
            contrast_values.T @ np.linalg.solve(contrast_vcov, contrast_values)
        )
    except np.linalg.LinAlgError:
        # Matrix is singular - use pseudo-inverse
        return float(
            contrast_values.T @ np.linalg.pinv(contrast_vcov) @ contrast_values
        )


# =============================================================================
# Test Functions
# =============================================================================


def compute_f_test(
    L: np.ndarray,
    coef: np.ndarray,
    vcov: np.ndarray,
    df_resid: float,
) -> FTestResult:
    """Compute F-test for linear hypothesis L @ β = 0.

    Uses the Wald statistic divided by the number of constraints
    to produce an F-statistic with appropriate degrees of freedom.

    Args:
        L: Contrast matrix of shape (q, p) where q is the number of
            constraints (contrasts) and p is the number of coefficients.
        coef: Coefficient estimates of shape (p,).
        vcov: Variance-covariance matrix of coefficients, shape (p, p).
        df_resid: Residual degrees of freedom (denominator df for F-test).

    Returns:
        FTestResult containing num_df, den_df, F_value, p_value.

    Note:
        The Wald statistic is:
            W = (L @ β)' @ (L @ V @ L')⁻¹ @ (L @ β)

        The F-statistic is F = W / q, distributed as F(q, df_resid).

    Examples:
        >>> L = np.array([[-1, 1, 0], [-1, 0, 1]])  # 2 contrasts
        >>> coef = np.array([10.0, 12.0, 15.0])
        >>> vcov = np.diag([1.0, 1.5, 2.0])
        >>> result = compute_f_test(L, coef, vcov, df_resid=97)
        >>> result.num_df
        2
    """
    # Ensure inputs are arrays
    L = np.atleast_2d(L)
    coef = np.atleast_1d(coef)
    vcov = np.atleast_2d(vcov)

    # Number of constraints
    num_df = L.shape[0]

    if num_df == 0:
        # No contrasts - return null result
        return FTestResult(
            num_df=0,
            den_df=float(df_resid),
            F_value=float(np.nan),
            p_value=float(np.nan),
        )

    # Compute contrast estimates and variance
    L_beta = L @ coef
    L_vcov_L = compute_contrast_variance(L, vcov)

    # Compute Wald statistic and convert to F
    wald_stat = compute_wald_statistic(L_beta, L_vcov_L)
    F_stat = wald_stat / num_df

    # Compute p-value from F-distribution (sf is more precise than 1-cdf)
    p_value = float(np.clip(stats.f.sf(F_stat, num_df, df_resid), _P_MIN, 1.0))

    return FTestResult(
        num_df=int(num_df),
        den_df=float(df_resid),
        F_value=float(F_stat),
        p_value=p_value,
    )


def compute_chi2_test(
    L: np.ndarray,
    coef: np.ndarray,
    vcov: np.ndarray,
) -> Chi2TestResult:
    """Compute Wald chi-square test for L @ β = 0.

    Used for GLMs and GLMMs where we don't have residual df.
    The Wald statistic is asymptotically chi-squared distributed.

    Args:
        L: Contrast matrix of shape (q, p).
        coef: Coefficient estimates of shape (p,).
        vcov: Variance-covariance matrix of shape (p, p).

    Returns:
        Chi2TestResult containing num_df, chi2, p_value.

    Examples:
        >>> L = np.array([[-1, 1, 0], [-1, 0, 1]])
        >>> coef = np.array([0.5, 1.2, 0.8])
        >>> vcov = np.diag([0.1, 0.15, 0.12])
        >>> result = compute_chi2_test(L, coef, vcov)
        >>> result.num_df
        2
    """
    # Ensure inputs are arrays
    L = np.atleast_2d(L)
    coef = np.atleast_1d(coef)
    vcov = np.atleast_2d(vcov)

    # Number of constraints
    num_df = L.shape[0]

    if num_df == 0:
        return Chi2TestResult(
            num_df=0,
            chi2=float(np.nan),
            p_value=float(np.nan),
        )

    # Compute contrast estimates and variance
    L_beta = L @ coef
    L_vcov_L = compute_contrast_variance(L, vcov)

    # Compute Wald chi-square statistic
    chi2_stat = compute_wald_statistic(L_beta, L_vcov_L)

    # Compute p-value from chi-square distribution (sf is more precise than 1-cdf)
    p_value = float(np.clip(stats.chi2.sf(chi2_stat, num_df), _P_MIN, 1.0))

    return Chi2TestResult(
        num_df=int(num_df),
        chi2=float(chi2_stat),
        p_value=p_value,
    )


def compute_t_test(
    L: np.ndarray,
    coef: np.ndarray,
    vcov: np.ndarray,
    df: float,
) -> TTestResult:
    """Compute t-test for a single contrast L @ β = 0.

    For a single contrast (q=1), returns t-statistic instead of F.

    Args:
        L: Contrast vector of shape (1, p) or (p,).
        coef: Coefficient estimates of shape (p,).
        vcov: Variance-covariance matrix of shape (p, p).
        df: Degrees of freedom for t-distribution.

    Returns:
        TTestResult containing estimate, se, t_value, df, p_value.

    Examples:
        >>> L = np.array([-1, 1, 0])  # Compare coef[1] to coef[0]
        >>> coef = np.array([10.0, 12.0, 15.0])
        >>> vcov = np.diag([1.0, 1.5, 2.0])
        >>> result = compute_t_test(L, coef, vcov, df=97)
        >>> result.estimate
        2.0
    """
    L = np.atleast_1d(L).flatten()
    coef = np.atleast_1d(coef)
    vcov = np.atleast_2d(vcov)

    # Contrast estimate
    estimate = float(L @ coef)

    # Standard error
    var_contrast = float(L @ vcov @ L)
    se = np.sqrt(var_contrast)

    # t-statistic
    t_value = estimate / se if se > 0 else np.nan

    # Two-tailed p-value
    p_value = (
        2 * (1 - stats.t.cdf(np.abs(t_value), df)) if not np.isnan(t_value) else np.nan
    )

    return TTestResult(
        estimate=estimate,
        se=float(se),
        t_value=float(t_value),
        df=float(df),
        p_value=float(p_value),
    )


# =============================================================================
# P-value Computation and Adjustment
# =============================================================================


def compute_pvalue(
    statistic: np.ndarray,
    df: float | np.ndarray | None = None,
    alternative: str = "two-sided",
) -> np.ndarray:
    """Compute p-values from test statistics.

    Uses t-distribution if df is provided, otherwise uses normal distribution.
    Supports two-sided, greater, and less alternatives.

    Args:
        statistic: Test statistics (t or z values).
        df: Degrees of freedom for t-distribution (scalar or per-coefficient
            array). If None, uses normal distribution.
        alternative: Direction of the alternative hypothesis.
            - "two-sided": H₁: β ≠ null (default)
            - "greater": H₁: β > null (upper tail)
            - "less": H₁: β < null (lower tail)

    Returns:
        P-values for the specified alternative.

    Examples:
        >>> statistic = np.array([2.5, -1.8])
        >>> p = compute_pvalue(statistic, df=20)
        >>> all((p >= 0) & (p <= 1))
        True
    """
    if df is not None:
        dist = stats.t(df=df)
    else:
        dist = stats.norm

    if alternative == "two-sided":
        p_values = 2 * dist.sf(np.abs(statistic))
    elif alternative == "greater":
        p_values = dist.sf(statistic)
    elif alternative == "less":
        p_values = dist.cdf(statistic)
    else:
        raise ValueError(
            f"alternative must be 'two-sided', 'greater', or 'less', got {alternative!r}"
        )

    return np.clip(p_values, _P_MIN, 1.0)


def compute_f_pvalue(f_stat: float, df1: int, df2: float) -> float:
    """Compute p-value from F-statistic.

    Uses the upper tail of the F-distribution: P(F > f_stat | df1, df2).

    Args:
        f_stat: F-statistic value.
        df1: Numerator degrees of freedom (number of restrictions).
        df2: Denominator degrees of freedom (residual df).

    Returns:
        Upper-tail p-value from F-distribution.

    Examples:
        >>> p = compute_f_pvalue(4.0, df1=2, df2=97)
        >>> 0 < p < 0.05
        True
        >>> compute_f_pvalue(0.0, df1=1, df2=100)
        1.0
    """
    return float(np.clip(stats.f.sf(f_stat, df1, df2), _P_MIN, 1.0))


def adjust_pvalues(
    pvalues: np.ndarray,
    method: str = "none",
) -> np.ndarray:
    """Adjust p-values for multiple comparisons.

    Implements standard p-value adjustment methods matching R's p.adjust().

    Args:
        pvalues: Raw p-values, shape (n,).
        method: Adjustment method. One of:
            - "none": No adjustment (return raw p-values)
            - "bonferroni": Bonferroni correction (p * n)
            - "holm": Holm step-down (default in many R packages)
            - "hochberg": Hochberg step-up
            - "bh" or "fdr": Benjamini-Hochberg FDR control
            - "by": Benjamini-Yekutieli FDR (conservative, handles dependence)

    Returns:
        Adjusted p-values, clipped to [0, 1].

    Examples:
        >>> p = np.array([0.01, 0.04, 0.03, 0.005])
        >>> adjust_pvalues(p, method="bonferroni")
        array([0.04, 0.16, 0.12, 0.02])
        >>> adjust_pvalues(p, method="holm")
        array([0.03, 0.08, 0.06, 0.02])
    """
    p = np.asarray(pvalues).copy()
    n = len(p)

    if n == 0:
        return p

    method = method.lower()

    if method == "none":
        return p

    elif method == "bonferroni":
        # Simple: multiply all p-values by n
        return np.minimum(p * n, 1.0)

    elif method == "holm":
        # Holm step-down: order p-values, adjust by position, enforce monotonicity
        order = np.argsort(p)
        sorted_p = p[order]
        adjusted = np.zeros(n)

        for i in range(n):
            adjusted[i] = sorted_p[i] * (n - i)

        # Enforce monotonicity (each adjusted p >= previous)
        for i in range(1, n):
            adjusted[i] = max(adjusted[i], adjusted[i - 1])

        # Restore original order
        result = np.zeros(n)
        result[order] = adjusted
        return np.minimum(result, 1.0)

    elif method == "hochberg":
        # Hochberg step-up: like Holm but works backwards
        order = np.argsort(p)[::-1]  # Descending order
        sorted_p = p[order]
        adjusted = np.zeros(n)

        for i in range(n):
            rank = n - i  # Rank from largest
            adjusted[i] = sorted_p[i] * rank

        # Enforce monotonicity (going backwards)
        for i in range(1, n):
            adjusted[i] = min(adjusted[i], adjusted[i - 1])

        # Restore original order
        result = np.zeros(n)
        result[order] = adjusted
        return np.minimum(result, 1.0)

    elif method in ("bh", "fdr"):
        # Benjamini-Hochberg: control FDR
        # Use scipy's implementation for correctness
        from scipy.stats import false_discovery_control

        return false_discovery_control(p, method="bh")

    elif method == "by":
        # Benjamini-Yekutieli: conservative FDR for dependent tests
        from scipy.stats import false_discovery_control

        return false_discovery_control(p, method="by")

    else:
        valid = ["none", "bonferroni", "holm", "hochberg", "bh", "fdr", "by"]
        raise ValueError(f"Unknown p_adjust method: {method!r}. Valid: {valid}")


def format_pvalue_with_stars(p_val: float) -> str:
    """Format p-value with R-style significance codes.

    Args:
        p_val: The p-value to format.

    Returns:
        Formatted string with p-value and significance stars (fixed 12-char width).
        Uses R's significance coding: '***' < 0.001 < '**' < 0.01 < '*' < 0.05 < '.' < 0.1

    Examples:
        >>> format_pvalue_with_stars(0.0001)
        '< 0.001 *** '
        >>> format_pvalue_with_stars(0.023)
        '  0.023 *   '
    """
    if p_val < 0.001:
        return "< 0.001 *** "
    elif p_val < 0.01:
        return f"{p_val:7.3f} **  "
    elif p_val < 0.05:
        return f"{p_val:7.3f} *   "
    elif p_val < 0.1:
        return f"{p_val:7.3f} .   "
    else:
        return f"{p_val:7.3f}     "
