"""Probability result class and visualization helpers."""

from __future__ import annotations

import base64
from dataclasses import dataclass
from io import BytesIO
from typing import TYPE_CHECKING

from scipy.stats._distn_infrastructure import rv_continuous_frozen, rv_discrete_frozen

if TYPE_CHECKING:
    from matplotlib.figure import Figure

__all__ = [
    "MC_SAMPLES",
    "Probability",
    "figure_to_html",
    "rv_frozen",
]

# Type alias for frozen scipy distributions
rv_frozen = rv_continuous_frozen | rv_discrete_frozen

# Default sample size for Monte Carlo methods
MC_SAMPLES = 100_000


@dataclass(frozen=True, slots=True)
class Probability:
    """Rich probability result from distribution queries.

    Returned by comparison operators on distributions (e.g., `normal() > 1.96`).
    Behaves like a float for numeric operations while providing descriptive display.

    Args:
        value: The probability value (between 0 and 1).
        expr: Expression describing the event (e.g., "X > 1.96").
        dist_name: Display name of the distribution (e.g., "Normal(0, 1)").

    Examples:
        ```python
        d = normal()
        p = d > 1.96
        p
        # P(X > 1.96) = 0.025
        float(p)
        # 0.025
        p < 0.05  # threshold check
        # True
        ```
    """

    value: float
    expr: str
    dist_name: str

    def __float__(self) -> float:
        """Convert to float for numeric use."""
        return self.value

    def __repr__(self) -> str:
        """Display as P(expr) = value."""
        return f"P({self.expr}) = {self.value:.4g}"

    def _repr_html_(self) -> str:
        """Rich HTML display for notebooks."""
        return (
            f'<span style="font-family: serif; font-size: 1.1em;">'
            f"P({self.expr}) = <b>{self.value:.4g}</b>"
            f"</span>"
            f'<br><span style="color: #666; font-size: 0.9em;">'
            f"where X ~ {self.dist_name}</span>"
        )

    # Comparison operators for threshold checks
    def __lt__(self, other: float | "Probability") -> bool:
        return self.value < float(other)

    def __le__(self, other: float | "Probability") -> bool:
        return self.value <= float(other)

    def __gt__(self, other: float | "Probability") -> bool:
        return self.value > float(other)

    def __ge__(self, other: float | "Probability") -> bool:
        return self.value >= float(other)

    def __eq__(self, other: object) -> bool:
        if isinstance(other, Probability):
            return self.value == other.value
        if isinstance(other, (int, float)):
            return self.value == float(other)
        return NotImplemented

    # Arithmetic with other probabilities or floats
    def __add__(self, other: float | "Probability") -> float:
        return self.value + float(other)

    def __radd__(self, other: float) -> float:
        return float(other) + self.value

    def __sub__(self, other: float | "Probability") -> float:
        return self.value - float(other)

    def __rsub__(self, other: float) -> float:
        return float(other) - self.value

    def __mul__(self, other: float | "Probability") -> float:
        return self.value * float(other)

    def __rmul__(self, other: float) -> float:
        return float(other) * self.value

    def __truediv__(self, other: float | "Probability") -> float:
        return self.value / float(other)

    def __rtruediv__(self, other: float) -> float:
        return float(other) / self.value

    def __bool__(self) -> bool:
        """Truthiness based on whether probability is nonzero."""
        return self.value > 0


def figure_to_html(fig: Figure, dpi: int = 100) -> str:
    """Convert matplotlib figure to base64-encoded HTML img tag.

    Args:
        fig: Matplotlib figure to convert.
        dpi: Resolution for the PNG image.

    Returns:
        HTML string with embedded base64 PNG.
    """
    import matplotlib.pyplot as plt

    buf = BytesIO()
    fig.savefig(
        buf,
        format="png",
        dpi=dpi,
        bbox_inches="tight",
        facecolor="white",
        edgecolor="none",
    )
    buf.seek(0)
    img_base64 = base64.b64encode(buf.read()).decode("utf-8")
    buf.close()
    plt.close(fig)

    return f'<img src="data:image/png;base64,{img_base64}" />'
