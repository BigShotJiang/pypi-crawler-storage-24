"""Backend abstraction layer for JAX/NumPy compatibility."""

from bossanova.internal.maths.backend.protocol import ArrayOps
from bossanova.internal.maths.backend.dispatch import (
    BackendName,
    backend,
    clear_ops_cache,
    get_backend,
    get_ops,
    set_backend,
    lock_backend,
    reset_backend,
)

__all__ = [
    "ArrayOps",
    "BackendName",
    "backend",
    "clear_ops_cache",
    "get_backend",
    "get_ops",
    "lock_backend",
    "reset_backend",
    "set_backend",
]
