"""Backend detection, switching, and ArrayOps dispatch."""

from __future__ import annotations

import sys
from collections.abc import Iterator
from contextlib import contextmanager
from typing import TYPE_CHECKING, Literal

__all__ = [
    "BackendName",
    "backend",
    "clear_ops_cache",
    "get_backend",
    "get_ops",
    "lock_backend",
    "reset_backend",
    "set_backend",
]

if TYPE_CHECKING:
    from bossanova.internal.maths.backend.protocol import ArrayOps

# ---------------------------------------------------------------------------
# Type alias
# ---------------------------------------------------------------------------

BackendName = Literal["jax", "numpy"]

# ---------------------------------------------------------------------------
# Global state
# ---------------------------------------------------------------------------

_backend: BackendName | None = None
_backend_locked: bool = False

# Cache for backend instances (created once per backend)
_ops_cache: dict[str, "ArrayOps"] = {}

# ---------------------------------------------------------------------------
# Backend detection / accessors
# ---------------------------------------------------------------------------


def detect_backend() -> BackendName:
    """Auto-detect the best available backend.

    Detection order:
    1. If running in Pyodide (emscripten), use numpy (JAX not available)
    2. Try to import JAX - if successful, use jax
    3. Fall back to numpy

    Returns:
        The detected backend name.
    """
    # Pyodide detection
    if sys.platform == "emscripten":
        return "numpy"

    # Try JAX
    try:
        import jax  # noqa: F401 — probe availability only; x64 set in __init__.py

        return "jax"
    except (ImportError, AttributeError):
        # ImportError: JAX not installed
        # AttributeError: JAX partially initialized (circular import during init)
        return "numpy"


def get_backend() -> BackendName:
    """Get the current backend name.

    If no backend has been explicitly set, auto-detects the best available
    backend on first call.

    Returns:
        The current backend name ('jax' or 'numpy').

    Examples:
        ```python
        import bossanova
        bossanova.get_backend()
        # 'jax'
        ```
    """
    global _backend
    if _backend is None:
        _backend = detect_backend()
    return _backend


def set_backend(name: BackendName) -> None:
    """Set the backend to use for computations.

    Must be called before any model fitting occurs. Once a model has been
    fitted, the backend is locked and cannot be changed.

    Args:
        name: Backend name, either 'jax' or 'numpy'.

    Raises:
        RuntimeError: If called after a model has been fitted.
        ValueError: If name is not 'jax' or 'numpy'.
        ImportError: If 'jax' is requested but JAX is not installed.

    Examples:
        ```python
        import bossanova
        bossanova.set_backend("numpy")
        bossanova.get_backend()
        # 'numpy'
        ```
    """
    global _backend, _backend_locked
    if _backend_locked:
        raise RuntimeError(
            "Cannot change backend after models have been fitted. "
            "Call set_backend() before any model fitting."
        )
    if name not in ("jax", "numpy"):
        raise ValueError(f"Unknown backend: {name}. Use 'jax' or 'numpy'.")

    # Validate JAX availability early if requested
    if name == "jax":
        try:
            import jax  # noqa: F401 — probe availability only; x64 set in __init__.py
        except (ImportError, AttributeError) as e:
            raise ImportError(
                "JAX is not available. Install it with 'pip install jax jaxlib' "
                "or use set_backend('numpy')."
            ) from e

    _backend = name


def lock_backend() -> None:
    """Lock the backend to prevent switching after model fitting.

    This is called internally when models are fitted to ensure consistent
    behavior throughout a session.
    """
    global _backend, _backend_locked
    # Ensure backend is initialized before locking
    if _backend is None:
        _backend = detect_backend()
    _backend_locked = True


def reset_backend() -> None:
    """Reset backend state (for testing only).

    Warning:
        This should only be used in tests. Using it in production code
        can lead to inconsistent behavior.
    """
    global _backend, _backend_locked
    _backend = None
    _backend_locked = False


@contextmanager
def backend(name: BackendName) -> Iterator[None]:
    """Context manager for temporary backend switching.

    This is primarily intended for testing. It temporarily switches the
    backend and restores the previous state on exit.

    Args:
        name: Backend name to use within the context.

    Context Manager:
        Yields None; restores previous backend on exit.

    Examples:
        ```python
        import bossanova
        with bossanova.backend("numpy"):
            print(bossanova.get_backend())
        # 'numpy'
        ```
    """
    global _backend, _backend_locked
    old_backend = _backend
    old_locked = _backend_locked

    # Temporarily switch
    _backend = name
    _backend_locked = False

    try:
        yield
    finally:
        # Restore previous state
        _backend = old_backend
        _backend_locked = old_locked


# ---------------------------------------------------------------------------
# ArrayOps dispatch
# ---------------------------------------------------------------------------


def get_ops() -> "ArrayOps":
    """Get array operations for the current backend.

    Returns the appropriate backend instance (NumPyBackend or JAXBackend)
    based on the current backend setting. The instance is cached so that
    repeated calls return the same object.

    Returns:
        ArrayOps instance for the current backend.

    Examples:
        >>> from bossanova.internal.maths import get_ops
        >>> ops = get_ops()
        >>> X = ops.asarray([[1, 2], [3, 4]])
        >>> L = ops.cholesky(X @ X.T)
    """
    current = get_backend()

    if current not in _ops_cache:
        if current == "jax":
            from bossanova.internal.maths.backend.jax import JAXBackend

            _ops_cache[current] = JAXBackend()
        else:
            from bossanova.internal.maths.backend.numpy import NumPyBackend

            _ops_cache[current] = NumPyBackend()

    return _ops_cache[current]


def clear_ops_cache() -> None:
    """Clear the backend operations cache.

    This is primarily for testing purposes. Clears the cached backend
    instances so that the next call to get_ops() creates a fresh instance.

    Warning:
        This should only be used in tests. Using it in production code
        can lead to inconsistent behavior.
    """
    global _ops_cache
    _ops_cache = {}
