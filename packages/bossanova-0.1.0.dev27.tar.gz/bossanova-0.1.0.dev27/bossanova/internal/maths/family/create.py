"""Family object construction from string names."""

from bossanova.internal.maths.family.binomial import binomial
from bossanova.internal.maths.family.gamma import gamma
from bossanova.internal.maths.family.gaussian import gaussian
from bossanova.internal.maths.family.poisson import poisson
from bossanova.internal.maths.family.schema import Family

__all__ = [
    "build_family",
]


def build_family(family_name: str, link_name: str | None = None) -> Family:
    """Create a Family object from family and link names.

    This is a convenience function that dispatches to the appropriate
    family factory function based on the family name string.

    Args:
        family_name: Name of the family ("gaussian", "binomial", "poisson", "gamma").
            Note: "tdist" is not supported here as it requires a df parameter.
        link_name: Optional link function name. If None, uses the canonical link
            for each family:
            - gaussian: "identity"
            - binomial: "logit"
            - poisson: "log"
            - gamma: "inverse"

    Returns:
        Family configuration object

    Raises:
        ValueError: If family_name is not recognized

    Examples:
        >>> fam = build_family("gaussian")
        >>> fam.name
        'gaussian'

        >>> fam = build_family("binomial", "probit")
        >>> fam.link_name
        'probit'

        >>> fam = build_family("gamma", "log")
        >>> fam.name
        'gamma'
    """
    if family_name == "gaussian":
        return gaussian(link_name)
    elif family_name == "binomial":
        return binomial(link_name)
    elif family_name == "poisson":
        return poisson(link_name)
    elif family_name == "gamma":
        return gamma(link_name)
    else:
        raise ValueError(
            f"Unsupported family: {family_name}. "
            f"Supported families: 'gaussian', 'binomial', 'poisson', 'gamma'"
        )
