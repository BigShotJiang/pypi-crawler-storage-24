"""Gamma family functions for GLM fitting."""

# Conditional JAX import for Pyodide compatibility
try:
    import jax
    import jax.numpy as jnp
except (ImportError, AttributeError):
    import numpy as jnp  # type: ignore[no-redef]

    # No-op decorator when JAX is not available
    class FakeJax:
        @staticmethod
        def jit(fn):
            return fn

    jax = FakeJax()  # type: ignore[assignment]

from bossanova.internal.maths.family.links import (
    inverse_link,
    inverse_link_deriv,
    inverse_link_inverse,
    log_link,
    log_link_deriv,
    log_link_inverse,
)
from bossanova.internal.maths.family.schema import Family

__all__ = [
    "gamma",
    "gamma_deviance",
    "gamma_dispersion",
    "gamma_initialize",
    "gamma_loglik",
    "gamma_variance",
]


# ============================================================================
# Gamma Family Functions
# ============================================================================


@jax.jit
def gamma_variance(mu: jnp.ndarray) -> jnp.ndarray:
    """Gamma variance function: V(μ) = μ².

    Args:
        mu: Mean values (n,), must be positive

    Returns:
        Variance values (n,)
    """
    mu_clipped = jnp.clip(mu, 1e-10, jnp.inf)
    return mu_clipped**2


@jax.jit
def gamma_deviance(y: jnp.ndarray, mu: jnp.ndarray) -> jnp.ndarray:
    """Gamma unit deviance: d(y, μ) = 2[-log(y/μ) + (y - μ)/μ].

    Uses log-space arithmetic for numerical stability.

    Args:
        y: Response values (n,), must be positive
        mu: Fitted mean values (n,), must be positive

    Returns:
        Unit deviance values (n,)
    """
    y_clipped = jnp.clip(y, 1e-10, jnp.inf)
    mu_clipped = jnp.clip(mu, 1e-10, jnp.inf)

    # d(y, μ) = 2 * [-log(y/μ) + (y - μ)/μ]
    #         = 2 * [-log(y) + log(μ) + y/μ - 1]
    return 2 * (-jnp.log(y_clipped) + jnp.log(mu_clipped) + y_clipped / mu_clipped - 1)


@jax.jit
def gamma_loglik(y: jnp.ndarray, mu: jnp.ndarray) -> jnp.ndarray:
    """Gamma conditional log-likelihood (per observation).

    Computes log p(y|μ) for Gamma distribution with shape parameter k and
    scale θ = μ/k, parameterized by mean μ. Ignores terms involving k.

    The kernel is: (k-1)*log(y) - y/θ - k*log(θ)
    Which simplifies to proportional terms: -y/μ - log(μ) (ignoring k-dependent terms)

    Args:
        y: Response values (n,), must be positive
        mu: Fitted mean values (n,), must be positive

    Returns:
        Per-observation log-likelihood values (n,), NOT summed
    """
    y_clipped = jnp.clip(y, 1e-10, jnp.inf)
    mu_clipped = jnp.clip(mu, 1e-10, jnp.inf)

    # Log-likelihood kernel: log(y) - y/μ - log(μ)
    return jnp.log(y_clipped) - y_clipped / mu_clipped - jnp.log(mu_clipped)


def gamma_initialize(y: jnp.ndarray, weights: jnp.ndarray | None = None) -> jnp.ndarray:
    """Initialize μ for Gamma family.

    Uses y directly as the starting value, ensuring positive values.

    Args:
        y: Response values (n,), must be positive
        weights: Optional prior weights (n,). Unused for Gamma, included
            for API consistency with other families.

    Returns:
        Initial mean values (n,)
    """
    # Ensure positive starting values
    return jnp.clip(y, 1e-10, jnp.inf)


def gamma_dispersion(y: jnp.ndarray, mu: jnp.ndarray, df_resid: int) -> float:
    """Estimate dispersion parameter for Gamma family.

    Uses Pearson χ² / df_resid. For Gamma, the dispersion parameter
    is 1/shape, so the shape parameter is 1/dispersion.

    Args:
        y: Response values (n,)
        mu: Fitted mean values (n,)
        df_resid: Residual degrees of freedom

    Returns:
        Dispersion estimate φ̂
    """
    var = gamma_variance(mu)
    pearson_resid = (y - mu) / jnp.sqrt(var + 1e-10)
    pearson_chi2 = jnp.sum(pearson_resid**2)
    return float(pearson_chi2 / df_resid) if df_resid > 0 else 1.0


# ============================================================================
# Family Factory Function
# ============================================================================


def gamma(link: str | None = None) -> Family:
    """Create Gamma family for positive continuous data.

    The Gamma family is appropriate for positive continuous response data
    where variance increases with the mean (V(μ) = μ²). Commonly used for
    modeling waiting times, insurance claims, or other positive-valued data.

    Args:
        link: Link function name. Options are "inverse" (canonical, default)
            or "log". Defaults to "inverse" if None.

    Returns:
        Gamma family configuration

    Raises:
        ValueError: If link is not None, "inverse", or "log"

    Examples:
        >>> # Gamma with inverse link (canonical)
        >>> fam = gamma()
        >>> fam.name
        'gamma'
        >>> fam.link_name
        'inverse'

        >>> # Gamma with log link
        >>> fam = gamma("log")
        >>> fam.link_name
        'log'
    """
    if link is None or link == "inverse":
        return Family(
            name="gamma",
            link_name="inverse",
            link=inverse_link,
            link_inverse=inverse_link_inverse,
            link_deriv=inverse_link_deriv,
            variance=gamma_variance,
            deviance=gamma_deviance,
            loglik=gamma_loglik,
            initialize=gamma_initialize,
            dispersion=gamma_dispersion,
        )
    elif link == "log":
        return Family(
            name="gamma",
            link_name="log",
            link=log_link,
            link_inverse=log_link_inverse,
            link_deriv=log_link_deriv,
            variance=gamma_variance,
            deviance=gamma_deviance,
            loglik=gamma_loglik,
            initialize=gamma_initialize,
            dispersion=gamma_dispersion,
        )
    else:
        raise ValueError(
            f"Invalid link '{link}' for gamma family. Supported links: 'inverse', 'log'"
        )
