"""QR-based least squares solver with rank deficiency detection."""

from dataclasses import dataclass
from typing import Any

import numpy as np

from bossanova.internal.maths.backend import get_backend
from bossanova.internal.maths.backend.dispatch import get_ops

# Type alias for arrays (could be np.ndarray or jax.Array)
Array = Any

__all__ = [
    "QRSolveResult",
    "qr_solve",
    "qr_solve_jax",
]


@dataclass(frozen=True, slots=True)
class QRSolveResult:
    """Result container for QR solve.

    Attributes:
        coef: Coefficient estimates, shape (p,). NaN for dropped columns.
        vcov: Variance-covariance matrix, shape (p, p). NaN for dropped columns.
        sigma2: Residual variance (scalar).
        fitted: Fitted values, shape (n,).
        residuals: Residuals, shape (n,).
        df_resid: Residual degrees of freedom (n - rank).
        rank: Effective rank of design matrix.
        R: R matrix from QR decomposition (upper triangular, permuted).
        pivot: Column permutation from pivoted QR, shape (p,).
    """

    coef: Array
    vcov: Array
    sigma2: Array
    fitted: Array
    residuals: Array
    df_resid: int
    rank: int
    R: Array
    pivot: Array


# Cache for JIT-compiled functions per backend
_qr_solve_full_rank_cache: dict[str, Any] = {}


def make_qr_solve_full_rank_fn(ops: Any) -> Any:
    """Create QR solve function for full-rank case (JIT-compatible).

    This is the fast path used when the matrix has full column rank.
    """
    xp = ops.np

    def _core(
        X: Array, y: Array, Q: Array, R: Array, rank: int
    ) -> tuple[Array, Array, Array, Array, Array]:
        """QR solve core for full-rank case.

        Returns: (coef, vcov, sigma2, fitted, residuals)
        """
        n, p = X.shape

        # Solve R β = Q^T y via backsubstitution
        Qty = Q.T @ y
        coef = ops.solve_triangular(R, Qty, lower=False)

        # Fitted values and residuals
        fitted = X @ coef
        residuals = y - fitted

        # Residual variance
        df_resid = n - rank
        sigma2 = xp.where(df_resid > 0, xp.sum(residuals**2) / df_resid, 0.0)

        # Variance-covariance matrix: σ² (R^T R)^{-1}
        R_inv = ops.solve_triangular(R, ops.eye(p), lower=False)
        vcov = sigma2 * (R_inv @ R_inv.T)

        return coef, vcov, sigma2, fitted, residuals

    return ops.jit(_core)


def get_qr_solve_full_rank_fn() -> Any:
    """Get JIT-compiled QR solve function for full-rank case."""
    backend = get_backend()
    if backend not in _qr_solve_full_rank_cache:
        ops = get_ops()
        _qr_solve_full_rank_cache[backend] = make_qr_solve_full_rank_fn(ops)
    return _qr_solve_full_rank_cache[backend]


def qr_solve_rank_deficient(
    X: np.ndarray,
    y: np.ndarray,
    Q: np.ndarray,
    R: np.ndarray,
    pivot: np.ndarray,
    rank: int,
) -> tuple[np.ndarray, np.ndarray, float, np.ndarray, np.ndarray]:
    """QR solve for rank-deficient case (not JIT-compiled).

    Handles rank deficiency by:
    1. Solving the reduced system for the first `rank` columns
    2. Setting dropped columns to NaN
    3. Permuting back to original column order

    This matches R's lm() behavior.
    """
    n, p = X.shape

    # Extract the "good" part of R (rank x rank upper triangular)
    R_reduced = R[:rank, :rank]
    Q_reduced = Q[:, :rank]

    # Solve reduced system: R_reduced @ coef_reduced = Q_reduced^T @ y
    Qty_reduced = Q_reduced.T @ y
    coef_reduced = np.linalg.solve(R_reduced, Qty_reduced)

    # Build full coefficient vector with NaN for dropped columns
    coef_permuted = np.full(p, np.nan)
    coef_permuted[:rank] = coef_reduced

    # Unpermute to original column order
    coef = np.empty(p)
    coef[pivot] = coef_permuted

    # Fitted values and residuals (only use non-NaN coefficients)
    # X @ coef where NaN cols contribute 0
    coef_for_fit = np.where(np.isnan(coef), 0.0, coef)
    fitted = X @ coef_for_fit
    residuals = y - fitted

    # Residual variance (using effective rank)
    df_resid = n - rank
    if df_resid > 0:
        sigma2 = float(np.sum(residuals**2) / df_resid)
    else:
        sigma2 = 0.0

    # Variance-covariance matrix
    # For kept columns: σ² (R_reduced^T R_reduced)^{-1}
    # For dropped columns: NaN
    R_reduced_inv = np.linalg.solve(R_reduced, np.eye(rank))
    vcov_reduced = sigma2 * (R_reduced_inv @ R_reduced_inv.T)

    # Build full vcov with NaN for dropped columns
    vcov_permuted = np.full((p, p), np.nan)
    vcov_permuted[:rank, :rank] = vcov_reduced

    # Unpermute to original column order
    vcov = np.full((p, p), np.nan)
    vcov[np.ix_(pivot, pivot)] = vcov_permuted

    return coef, vcov, sigma2, fitted, residuals


def detect_rank(R: np.ndarray, tol: float | None = None) -> int:
    """Detect numerical rank from R diagonal of pivoted QR.

    Uses R's tolerance: eps * max(n, p) * |R[0,0]|

    Args:
        R: Upper triangular matrix from pivoted QR.
        tol: Optional custom tolerance. If None, uses R's default.

    Returns:
        Numerical rank (number of "good" columns).
    """
    r_diag = np.abs(np.diag(R))
    if len(r_diag) == 0:
        return 0

    if tol is None:
        # R's default tolerance
        m, n = R.shape
        tol = np.finfo(R.dtype).eps * max(m, n) * r_diag[0]

    rank = int(np.sum(r_diag > tol))
    return rank


def qr_solve_jax(X: Array, y: Array) -> QRSolveResult:
    """Solve least squares via pivoted QR decomposition (returns backend arrays).

    Uses pivoted QR to detect and handle rank deficiency:
    - Full rank: Uses fast JIT-compiled path
    - Rank deficient: Falls back to numpy path, sets NaN for dropped columns

    This matches R's lm() behavior for collinear predictors.

    Args:
        X: Design matrix of shape (n, p), as backend array.
        y: Response variable of shape (n,), as backend array.

    Returns:
        QRSolveResult with backend arrays.
    """
    ops = get_ops()
    n, p = X.shape

    # Convert to numpy for pivoted QR (rank detection is not JIT-compatible)
    X_np = np.asarray(X)
    y_np = np.asarray(y)

    # Pivoted QR decomposition
    Q, R, pivot = ops.qr_pivoted(ops.asarray(X_np))
    Q_np = np.asarray(Q)
    R_np = np.asarray(R)
    pivot_np = np.asarray(pivot)

    # Detect rank from R diagonal
    rank = detect_rank(R_np)

    if rank == p:
        # Full rank: use fast JIT path
        qr_fn = get_qr_solve_full_rank_fn()
        coef, vcov, sigma2, fitted, residuals = qr_fn(
            ops.asarray(X_np[:, pivot_np]),  # Permuted X
            ops.asarray(y_np),
            ops.asarray(Q_np),
            ops.asarray(R_np),
            rank,
        )
        # Unpermute coefficients and vcov
        coef_np = np.asarray(coef)
        vcov_np = np.asarray(vcov)

        coef_unpermuted = np.empty(p)
        coef_unpermuted[pivot_np] = coef_np

        vcov_unpermuted = np.empty((p, p))
        vcov_unpermuted[np.ix_(pivot_np, pivot_np)] = vcov_np

        return QRSolveResult(
            coef=ops.asarray(coef_unpermuted),
            vcov=ops.asarray(vcov_unpermuted),
            sigma2=sigma2,
            fitted=fitted,
            residuals=residuals,
            df_resid=n - rank,
            rank=rank,
            R=ops.asarray(R_np),
            pivot=ops.asarray(pivot_np),
        )
    else:
        # Rank deficient: use numpy path with NaN for dropped columns
        coef, vcov, sigma2, fitted, residuals = qr_solve_rank_deficient(
            X_np, y_np, Q_np, R_np, pivot_np, rank
        )
        return QRSolveResult(
            coef=ops.asarray(coef),
            vcov=ops.asarray(vcov),
            sigma2=ops.asarray(sigma2),
            fitted=ops.asarray(fitted),
            residuals=ops.asarray(residuals),
            df_resid=n - rank,
            rank=rank,
            R=ops.asarray(R_np),
            pivot=ops.asarray(pivot_np),
        )


def qr_solve(X: np.ndarray, y: np.ndarray) -> QRSolveResult:
    """Solve least squares via pivoted QR decomposition.

    Uses pivoted QR for numerical stability and rank detection. This matches
    R's lm() behavior: rank-deficient columns get NaN coefficients.

    Args:
        X: Design matrix of shape (n, p).
        y: Response variable of shape (n,).

    Returns:
        QRSolveResult containing:

        - coef: Coefficient estimates, shape (p,). NaN for dropped columns.
        - vcov: Variance-covariance matrix, shape (p, p). NaN for dropped columns.
        - sigma2: Residual variance
        - fitted: Fitted values, shape (n,)
        - residuals: Residuals, shape (n,)
        - df_resid: Residual degrees of freedom (n - rank)
        - rank: Effective rank of design matrix
        - R: R matrix from QR decomposition (upper triangular, permuted)
        - pivot: Column permutation indices, shape (p,)

    Note:
        Uses pivoted Householder QR decomposition for rank detection.
        X[:, pivot] = Q @ R where Q is orthogonal and R is upper triangular.

        For rank-deficient matrices, columns with |R_ii| < tol are dropped
        and their coefficients set to NaN (matching R's lm() behavior).

    Examples:
        >>> X = np.array([[1, 2], [1, 3], [1, 4]])
        >>> y = np.array([1.0, 2.0, 3.0])
        >>> result = qr_solve(X, y)
        >>> result.coef
        array([-1.,  1.])

        >>> # Rank-deficient case
        >>> X = np.array([[1, 2, 2], [1, 3, 3], [1, 4, 4]])  # col 3 = col 2
        >>> result = qr_solve(X, y)
        >>> result.rank
        2
        >>> np.isnan(result.coef).sum()  # One coefficient is NaN
        1
    """
    # Convert to backend arrays, compute, convert back
    ops = get_ops()
    X_arr = ops.asarray(X)
    y_arr = ops.asarray(y)

    result = qr_solve_jax(X_arr, y_arr)

    return QRSolveResult(
        coef=np.asarray(result.coef),
        vcov=np.asarray(result.vcov),
        sigma2=float(result.sigma2),
        fitted=np.asarray(result.fitted),
        residuals=np.asarray(result.residuals),
        df_resid=result.df_resid,
        rank=result.rank,
        R=np.asarray(result.R),
        pivot=np.asarray(result.pivot),
    )
