"""Rank deficiency detection for design matrices."""

import warnings

import numpy as np
from scipy.linalg import qr as scipy_qr

from bossanova.internal.containers.structs.data import RankInfo

__all__ = [
    "detect_rank_deficiency",
]


def detect_rank_deficiency(
    X: np.ndarray,
    X_names: tuple[str, ...],
) -> RankInfo | None:
    """Detect rank deficiency in a design matrix via pivoted QR.

    Uses scipy's pivoted QR decomposition to detect numerically zero
    columns. Applies R's tolerance: ``eps * max(m, n) * |R[0,0]|``.

    Args:
        X: Design matrix of shape (n, p).
        X_names: Column names of X (length p).

    Returns:
        RankInfo if X is rank-deficient, None if full rank.

    Examples:
        >>> import numpy as np
        >>> X = np.array([[1, 2, 2], [1, 3, 3], [1, 4, 4]])
        >>> info = detect_rank_deficiency(X, ("Intercept", "x1", "x2"))
        >>> info is not None
        True
        >>> info.rank
        2
        >>> info.dropped_names
        ('x2',)
    """
    n, p = X.shape

    if p == 0:
        return None

    # Pivoted QR: X[:, pivot] = Q @ R
    _, R, pivot = scipy_qr(X, pivoting=True)

    # Detect rank from R diagonal using R's tolerance
    r_diag = np.abs(np.diag(R[: min(n, p), :]))
    if len(r_diag) == 0 or r_diag[0] == 0:
        # All-zero matrix
        rank = 0
    else:
        tol = np.finfo(X.dtype).eps * max(n, p) * r_diag[0]
        rank = int(np.sum(r_diag > tol))

    if rank == p:
        return None

    # Identify which original columns are kept vs dropped
    # pivot[:rank] are the "good" columns (in pivoted order)
    kept = np.sort(pivot[:rank])
    dropped = np.sort(pivot[rank:])

    dropped_names = tuple(X_names[i] for i in dropped)

    warnings.warn(
        f"Model matrix is rank-deficient (rank {rank} < {p} columns). "
        f"Dropping: {', '.join(dropped_names)}. "
        f"Coefficients for dropped terms will be NaN.",
        UserWarning,
        stacklevel=2,
    )

    return RankInfo(
        rank=rank,
        p=p,
        kept_indices=kept,
        dropped_indices=tuple(int(i) for i in dropped),
        dropped_names=dropped_names,
    )
