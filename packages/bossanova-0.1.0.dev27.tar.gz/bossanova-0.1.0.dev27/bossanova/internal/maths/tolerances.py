"""Numerical tolerances derived from backward error analysis.

This module provides principled tolerance functions for numerical testing,
based on standard backward error bounds from numerical linear algebra.

Error Bounds (Golub & Van Loan, Matrix Computations, 4th ed.)
=============================================================

QR Factorization (§5.2):
    The computed Q̂, R̂ satisfy A + δA = Q̂R̂ where ‖δA‖ ≤ O(ε)‖A‖

Triangular Solve (§3.1):
    (R + δR)x̂ = b where ‖δR‖ ≤ O(nε)‖R‖

QR Solve Combined:
    Forward error: ‖x - x̂‖/‖x‖ ≤ O(κ(A) × ε)

Residual Orthogonality:
    At OLS solution: X'e = 0 theoretically
    Computed: ‖X'ê‖ ≤ O(ε × κ(X) × ‖X‖ × ‖y‖ × n)

Design Principles
=================
1. Filter pathological cases with assume() at generation time
2. Tolerances derived from theory, not empirical tuning
3. Include safety factors for implementation variations
4. Document error bound source for each function

References
----------
.. [golub2013] Golub, Van Loan. Matrix Computations (2013), 4th ed.
.. [higham2002] Higham. Accuracy and Stability of Numerical Algorithms (2002).
"""

import numpy as np
from numpy.typing import ArrayLike

__all__ = [
    "DEFAULT_SAFETY",
    "EPS",
    "MAX_COND",
    "MAX_COND_INVERSE",
    "algorithm_comparison_atol",
    "algorithm_comparison_rtol",
    "decomposition_atol",
    "fitted_atol",
    "glm_score_atol",
    "has_full_rank",
    "hat_matrix_atol",
    "inference_atol",
    "is_well_conditioned",
    "orthogonality_atol",
    "residual_atol",
    "solve_atol",
    "solve_rtol",
]

# =============================================================================
# Constants
# =============================================================================

#: Machine epsilon for float64 (~2.22e-16)
EPS: float = np.finfo(np.float64).eps

#: Maximum condition number for which we expect stable solutions.
#: Beyond this, loss of precision is expected and tests should use assume().
#: Value of 1e10 means we expect ~6 digits of precision loss (log10(1e10) = 10).
MAX_COND: float = 1e10

#: Stricter condition number threshold for operations involving (X'X)^{-1}.
#: Computing the inverse squares the condition number, so κ(X)=1e5 gives κ(X'X)=1e10.
#: Use this for hat matrix, leverage, Cook's distance computations.
MAX_COND_INVERSE: float = 1e5

#: Default safety factor to account for implementation variations
#: and accumulated rounding in multi-step algorithms.
#:
#: NOTE: R uses sqrt(.Machine$double.eps) ≈ 1.49e-8 as a common tolerance threshold.
#: Our current safety=10 with EPS≈2.2e-16 yields tolerances ~2.2e-15 for simple ops,
#: which is tighter than R. If we encounter flaky tests or need looser tolerances
#: to match R's behavior (e.g., in parity tests), consider reducing this to 5.0.
#: See: https://stat.ethz.ch/R-manual/R-devel/library/base/html/zMachine.html
DEFAULT_SAFETY: float = 10.0


# =============================================================================
# Tolerance Functions
# =============================================================================


def solve_rtol(cond: float, safety: float = DEFAULT_SAFETY) -> float:
    """Relative tolerance for linear solve operations.

    Based on forward error bound for QR/SVD solve:
        ‖x - x̂‖/‖x‖ ≤ O(κ(A) × ε)

    Parameters
    ----------
    cond : float
        Condition number of the system matrix.
    safety : float, default=10.0
        Safety factor for implementation variations.

    Returns
    -------
    float
        Relative tolerance for comparing solutions.

    Examples
    --------
    >>> cond = 1e6
    >>> rtol = solve_rtol(cond)
    >>> np.testing.assert_allclose(computed, expected, rtol=rtol)
    """
    return cond * EPS * safety


def solve_atol(
    scale: float, cond: float, n: int = 1, safety: float = DEFAULT_SAFETY
) -> float:
    """Absolute tolerance for linear solve operations.

    For near-zero solutions where relative tolerance is meaningless.

    Parameters
    ----------
    scale : float
        Characteristic scale of the problem (e.g., max(|X|, |y|)).
    cond : float
        Condition number of the system matrix.
    n : int, default=1
        Problem dimension (for accumulated rounding).
    safety : float, default=10.0
        Safety factor.

    Returns
    -------
    float
        Absolute tolerance with minimum floor.
    """
    # Theoretical bound with minimum floor for numerical operations
    theoretical = scale * EPS * cond * n * safety
    # Minimum floor ~2.2e-14, accounts for basic floating ops.
    # NOTE: R typically uses sqrt(.Machine$double.eps) ≈ 1.49e-8 for "near-zero".
    # Our floor is tighter. If parity tests fail on edge cases, consider 1e-10.
    minimum_floor = EPS * 100
    return max(theoretical, minimum_floor)


def residual_atol(
    X: ArrayLike,
    y: ArrayLike,
    cond: float,
    safety: float = DEFAULT_SAFETY,
) -> float:
    """Absolute tolerance for residual orthogonality checks.

    For verifying X'e ≈ 0 (normal equations).

    Based on bound: ‖X'ê‖ ≤ O(ε × κ(X) × ‖X‖ × ‖y‖ × n)

    Parameters
    ----------
    X : array-like
        Design matrix (n × p).
    y : array-like
        Response vector (n,).
    cond : float
        Condition number of X.
    safety : float, default=10.0
        Safety factor.

    Returns
    -------
    float
        Absolute tolerance for residual orthogonality.

    Examples
    --------
    >>> result = qr_solve(X, y)
    >>> score = X.T @ result.residuals
    >>> np.testing.assert_allclose(score, 0, atol=residual_atol(X, y, cond))
    """
    X_arr = np.asarray(X)
    y_arr = np.asarray(y)

    # Scale from problem magnitudes
    scale = max(np.abs(X_arr).max(), np.abs(y_arr).max(), 1.0)
    n = X_arr.shape[0]

    # Theoretical bound with minimum floor
    theoretical = scale * EPS * cond * n * safety
    minimum_floor = EPS * 100
    return max(theoretical, minimum_floor)


def decomposition_atol(
    A: ArrayLike,
    safety: float = DEFAULT_SAFETY,
) -> float:
    """Absolute tolerance for decomposition properties.

    For verifying properties like Q'Q = I, R is upper triangular, etc.

    Based on backward error: ‖δA‖ ≤ O(ε × ‖A‖ × n)

    Parameters
    ----------
    A : array-like
        Matrix being decomposed.
    safety : float, default=10.0
        Safety factor.

    Returns
    -------
    float
        Absolute tolerance for decomposition checks.
    """
    A_arr = np.asarray(A)
    scale = max(np.abs(A_arr).max(), 1.0)
    n = max(A_arr.shape)

    theoretical = scale * EPS * n * safety
    minimum_floor = EPS * 100
    return max(theoretical, minimum_floor)


def fitted_atol(
    X: ArrayLike,
    y: ArrayLike,
    cond: float,
    safety: float = DEFAULT_SAFETY,
) -> float:
    """Absolute tolerance for fitted value comparisons.

    For verifying ŷ = Xβ̂ and y = ŷ + e.

    Parameters
    ----------
    X : array-like
        Design matrix.
    y : array-like
        Response vector.
    cond : float
        Condition number of X.
    safety : float, default=10.0
        Safety factor.

    Returns
    -------
    float
        Absolute tolerance for fitted value checks.
    """
    X_arr = np.asarray(X)
    y_arr = np.asarray(y)

    scale = max(np.abs(X_arr).max(), np.abs(y_arr).max(), 1.0)
    n = X_arr.shape[0]

    # Fitted values accumulate error from both solve and matrix multiply
    theoretical = scale * EPS * cond * n * safety * 2
    minimum_floor = EPS * 100
    return max(theoretical, minimum_floor)


def hat_matrix_atol(
    X: ArrayLike,
    cond: float,
    safety: float = DEFAULT_SAFETY,
) -> float:
    """Absolute tolerance for hat matrix property checks.

    For verifying H² = H (idempotence) and H' = H (symmetry).

    The hat matrix H = X(X'X)^{-1}X' involves inverting X'X, which has
    condition number κ(X)². Additionally, checking H² = H involves
    matrix multiplication that accumulates error.

    Error bound: O(ε × κ(X)² × n²)

    Parameters
    ----------
    X : array-like
        Design matrix (n × p).
    cond : float
        Condition number of X.
    safety : float, default=10.0
        Safety factor.

    Returns
    -------
    float
        Absolute tolerance for hat matrix checks.

    Notes
    -----
    For well-conditioned tests, use assume(is_well_conditioned(X, MAX_COND_INVERSE))
    to filter cases where κ(X) > 1e5 (meaning κ(X'X) > 1e10).

    Examples
    --------
    >>> H = X @ np.linalg.inv(X.T @ X) @ X.T
    >>> cond = np.linalg.cond(X)
    >>> np.testing.assert_allclose(H @ H, H, atol=hat_matrix_atol(X, cond))
    """
    X_arr = np.asarray(X)
    n = X_arr.shape[0]

    # Error grows as κ² for inverse, and another factor of n for matrix multiply
    # H² involves: H computation (κ²), then H @ H (n multiplies)
    theoretical = EPS * cond**2 * n * safety
    minimum_floor = EPS * 100
    return max(theoretical, minimum_floor)


def algorithm_comparison_atol(
    scale: float,
    cond: float,
    safety: float = DEFAULT_SAFETY,
) -> float:
    """Absolute tolerance for comparing different algorithms.

    When comparing results from two different numerical methods (e.g., QR vs SVD),
    each method has its own rounding pattern. The difference between them is
    bounded by the sum of their individual errors.

    Error bound: O(2 × ε × κ × scale)

    Parameters
    ----------
    scale : float
        Characteristic scale of the result (e.g., max(|coef|)).
    cond : float
        Condition number of the problem.
    safety : float, default=10.0
        Safety factor.

    Returns
    -------
    float
        Absolute tolerance for algorithm comparison.

    Examples
    --------
    >>> result_qr = qr_solve(X, y)
    >>> result_svd = svd_solve(X, y)
    >>> cond = np.linalg.cond(X)
    >>> scale = max(np.abs(result_qr.coef).max(), 1.0)
    >>> atol = algorithm_comparison_atol(scale, cond)
    >>> np.testing.assert_allclose(result_qr.coef, result_svd.coef, atol=atol)
    """
    # Each algorithm has error O(κε), comparing two gives 2×
    theoretical = 2 * scale * EPS * cond * safety
    minimum_floor = EPS * 100
    return max(theoretical, minimum_floor)


def algorithm_comparison_rtol(cond: float, safety: float = DEFAULT_SAFETY) -> float:
    """Relative tolerance for comparing different algorithms.

    Parameters
    ----------
    cond : float
        Condition number of the problem.
    safety : float, default=10.0
        Safety factor.

    Returns
    -------
    float
        Relative tolerance for algorithm comparison.
    """
    return 2 * cond * EPS * safety


def orthogonality_atol(
    n: int,
    safety: float = DEFAULT_SAFETY,
) -> float:
    """Absolute tolerance for orthogonality checks.

    For verifying Q'Q = I or P'P = I where Q/P is an orthonormal matrix.

    Based on backward error for orthogonal matrices: O(ε × n).

    Parameters
    ----------
    n : int
        Dimension of the orthogonal matrix (number of rows).
    safety : float, default=10.0
        Safety factor.

    Returns
    -------
    float
        Absolute tolerance for orthogonality checks.

    Examples
    --------
    >>> Q, R = np.linalg.qr(X)
    >>> n = Q.shape[0]
    >>> np.testing.assert_allclose(Q.T @ Q, np.eye(Q.shape[1]), atol=orthogonality_atol(n))
    """
    theoretical = EPS * n * safety
    minimum_floor = EPS * 100
    return max(theoretical, minimum_floor)


def glm_score_atol(
    X: ArrayLike,
    y: ArrayLike,
    cond: float,
    weights: ArrayLike | None = None,
    *,
    iterative: bool = False,
    safety: float = DEFAULT_SAFETY,
) -> float:
    """Absolute tolerance for GLM score equation checks.

    For verifying X'W(y - μ) ≈ 0 at IRLS convergence.

    GLMs use iterative fitting (IRLS), which accumulates more numerical
    error than closed-form OLS. Non-Gaussian families need looser tolerances
    because the score function is nonlinear in the coefficients.

    Error bound: O(ε × κ(X) × ‖X‖ × ‖y‖ × ‖W‖ × n × safety × irls_factor)

    Parameters
    ----------
    X : array-like
        Design matrix (n × p).
    y : array-like
        Response vector (n,).
    cond : float
        Condition number of X.
    weights : array-like, optional
        Weight vector or None for unweighted.
    iterative : bool, default=False
        If True, uses looser tolerance suitable for iterative algorithms
        like IRLS (e.g., Poisson, Gamma). Set True for non-Gaussian families.
    safety : float, default=10.0
        Safety factor.

    Returns
    -------
    float
        Absolute tolerance for score equation checks.

    Examples
    --------
    >>> result = fit_glm(X, y, family='binomial')
    >>> score = X.T @ (y - result.mu)
    >>> atol = glm_score_atol(X, y, np.linalg.cond(X))
    >>> np.testing.assert_allclose(score, 0, atol=atol)
    """
    X_arr = np.asarray(X)
    y_arr = np.asarray(y)

    scale = max(np.abs(X_arr).max() * np.abs(y_arr).max(), 1.0)
    if weights is not None:
        scale *= np.asarray(weights).max()

    n = X_arr.shape[0]

    if iterative:
        # Looser tolerance for iterative fitting (IRLS)
        # Convergence tolerance dominates machine precision
        theoretical = scale * n * 1e-5 * safety
        minimum_floor = 1e-4
    else:
        # Standard GLM (Gaussian or converged logistic/Poisson)
        theoretical = scale * cond * n * EPS * safety * 100
        minimum_floor = 1e-6

    return max(theoretical, minimum_floor)


def inference_atol(
    coef: ArrayLike,
    safety: float = DEFAULT_SAFETY,
) -> float:
    """Absolute tolerance for inference result comparisons.

    For verifying CI midpoints, t-statistics, and other inference quantities
    that depend on coefficient estimates.

    Error bound: O(ε × max(|β|) × safety)

    Parameters
    ----------
    coef : array-like
        Coefficient estimates (the scale reference).
    safety : float, default=10.0
        Safety factor.

    Returns
    -------
    float
        Absolute tolerance for inference comparisons.

    Examples
    --------
    >>> result = infer(coef, vcov, df)
    >>> ci_midpoint = (result.ci_lower + result.ci_upper) / 2
    >>> np.testing.assert_allclose(ci_midpoint, coef, atol=inference_atol(coef))
    """
    coef_arr = np.asarray(coef)
    scale = max(np.abs(coef_arr).max(), 1.0)

    theoretical = EPS * scale * safety
    minimum_floor = EPS * 100
    return max(theoretical, minimum_floor)


# =============================================================================
# Condition Number Utilities
# =============================================================================


def is_well_conditioned(A: ArrayLike, threshold: float = MAX_COND) -> bool:
    """Check if matrix is well-conditioned for stable computation.

    Use with hypothesis.assume() to filter pathological test cases.

    Parameters
    ----------
    A : array-like
        Matrix to check.
    threshold : float, default=MAX_COND
        Maximum acceptable condition number.

    Returns
    -------
    bool
        True if condition number is below threshold.

    Examples
    --------
    >>> from hypothesis import assume
    >>> assume(is_well_conditioned(X))
    """
    A_arr = np.asarray(A)
    try:
        cond = np.linalg.cond(A_arr)
        return np.isfinite(cond) and cond < threshold
    except np.linalg.LinAlgError:
        return False


def has_full_rank(A: ArrayLike) -> bool:
    """Check if matrix has full column rank.

    Parameters
    ----------
    A : array-like
        Matrix to check (n × p where n ≥ p).

    Returns
    -------
    bool
        True if rank(A) == min(n, p).
    """
    A_arr = np.asarray(A)
    rank = np.linalg.matrix_rank(A_arr)
    return rank == min(A_arr.shape)
