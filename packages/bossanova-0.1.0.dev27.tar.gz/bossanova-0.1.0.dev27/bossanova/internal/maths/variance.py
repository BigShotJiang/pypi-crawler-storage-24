"""Variance component conversion utilities.

Pure math: converts theta (Cholesky factors) and sigma to named variance
components for use in bootstrap DataFrames and diagnostics.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

__all__ = [
    "theta_to_variance_components",
]

if TYPE_CHECKING:
    import numpy as np


def theta_to_variance_components(
    theta: np.ndarray,
    sigma: float,
    group_names: list[str],
    random_names: list[str] | dict[str, list[str]],
    re_structure: str | list[str] | dict[str, str],
) -> tuple[list[str], list[float]]:
    """Convert theta parameters to named variance components.

    This function converts the raw Cholesky factor (theta) and residual
    standard deviation (sigma) to interpretable variance component values
    with standardized naming for use in bootstrap DataFrames.

    Args:
        theta: Optimized theta parameters (Cholesky factors, relative scale).
        sigma: Residual standard deviation.
        group_names: Names of grouping factors (e.g., ["Subject"]).
        random_names: Names of random effects per group.
            For single-structure models: list of names applied to all groups.
            For mixed-structure models: dict mapping group to names.
        re_structure: Random effects structure.
            "intercept", "slope", "diagonal" for single structure.
            List or dict for mixed structures.

    Returns:
        Tuple of (term_names, values) where:
        - term_names: List of standardized term names
        - values: List of corresponding SD or correlation values

    Naming convention:
        - Random effect SDs: "{Group}:{RE_name}_sd"
          e.g., "Subject:Intercept_sd", "Subject:Days_sd"
        - Correlations: "{Group}:corr_{RE1}:{RE2}"
          e.g., "Subject:corr_Intercept:Days"
        - Residual SD: "Residual_sd"

    Examples:
        >>> import numpy as np
        >>> theta = np.array([0.967, 0.015, 0.231])  # 2x2 Cholesky
        >>> sigma = 25.59
        >>> group_names = ["Subject"]
        >>> random_names = ["Intercept", "Days"]
        >>> re_structure = "slope"
        >>> names, values = theta_to_variance_components(
        ...     theta, sigma, group_names, random_names, re_structure
        ... )
        >>> names  # doctest: +SKIP
        ['Subject:Intercept_sd', 'Subject:Days_sd', 'Subject:corr_Intercept:Days', 'Residual_sd']
    """
    import numpy as np

    term_names = []
    values = []

    # Parse RE structure for each group
    if isinstance(re_structure, str):
        structure_dict = {gn: re_structure for gn in group_names}
    elif isinstance(re_structure, list):
        structure_dict = dict(zip(group_names, re_structure))
    else:
        structure_dict = re_structure

    # Parse random effect names
    if isinstance(random_names, list):
        if isinstance(re_structure, list) and len(random_names) == len(group_names):
            names_dict = {gn: [random_names[i]] for i, gn in enumerate(group_names)}
        else:
            names_dict = {gn: random_names for gn in group_names}
    else:
        names_dict = random_names

    theta_idx = 0

    for group_name in group_names:
        structure = structure_dict[group_name]
        re_names = names_dict[group_name]
        n_re = len(re_names)

        # Extract theta for this group and build Cholesky factor
        if structure == "intercept":
            L = np.array([[theta[theta_idx]]])
            theta_idx += 1
        elif structure == "diagonal":
            L = np.diag(theta[theta_idx : theta_idx + n_re])
            theta_idx += n_re
        elif structure == "slope":
            n_theta = n_re * (n_re + 1) // 2
            L = np.zeros((n_re, n_re))
            k = theta_idx
            for j in range(n_re):
                for i in range(j, n_re):
                    L[i, j] = theta[k]
                    k += 1
            theta_idx += n_theta
        else:
            raise ValueError(f"Unknown RE structure: {structure}")

        # Compute variance-covariance matrix: Σ = σ² × L @ L.T
        Sigma = sigma**2 * (L @ L.T)

        # Add SD terms
        for i, re_name in enumerate(re_names):
            sd = float(np.sqrt(Sigma[i, i]))
            term_names.append(f"{group_name}:{re_name}_sd")
            values.append(sd)

        # Add correlation terms (only for "slope" structure with multiple REs)
        # Diagonal and intercept structures have no correlations
        if structure == "slope" and n_re > 1:
            for i in range(n_re):
                for j in range(i + 1, n_re):
                    denom = np.sqrt(Sigma[i, i] * Sigma[j, j])
                    corr = float(Sigma[i, j] / denom) if denom > 0 else 0.0
                    term_names.append(f"{group_name}:corr_{re_names[i]}:{re_names[j]}")
                    values.append(corr)

    # Add residual SD
    term_names.append("Residual_sd")
    values.append(float(sigma))

    return term_names, values
