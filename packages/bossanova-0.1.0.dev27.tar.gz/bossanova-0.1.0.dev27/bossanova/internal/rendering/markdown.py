"""Markdown table and equation rendering for report export.

Pure functions that convert Polars DataFrames and LaTeX equations into
pipe-delimited GitHub Flavored Markdown / Quarto-compatible text.
Used by ``ModelResult.to_markdown()``, ``MathDisplay.to_markdown()``,
and the top-level ``bossanova.to_markdown()`` utility.
"""

from __future__ import annotations

from pathlib import Path

import polars as pl

__all__ = [
    "dataframe_to_markdown",
    "equation_to_markdown",
    "to_markdown",
    "write_text",
]


def dataframe_to_markdown(
    df: pl.DataFrame,
    caption: str | None = None,
) -> str:
    """Convert a Polars DataFrame to a pipe-delimited markdown table.

    Produces GitHub Flavored Markdown (GFM) table syntax that renders
    correctly in Quarto, GitHub, and most markdown environments. Columns
    are padded to align visually. Null values render as empty cells.

    No additional numeric formatting is applied — the DataFrame is assumed
    to be pre-rounded (as all bossanova result DataFrames are).

    Args:
        df: Polars DataFrame to convert.
        caption: Optional table caption. Rendered as ``Table: {caption}``
            above the table (Quarto cross-reference syntax).

    Returns:
        Pipe-delimited markdown table as a string.

    Examples:
        >>> import polars as pl
        >>> df = pl.DataFrame({"x": [1, 2], "y": [3.14, 2.72]})
        >>> print(dataframe_to_markdown(df))
        | x | y    |
        |---|------|
        | 1 | 3.14 |
        | 2 | 2.72 |
    """
    cols = df.columns

    # Convert all values to strings, rendering nulls as empty
    str_rows: list[list[str]] = []
    for row in df.iter_rows():
        str_rows.append([("" if v is None else str(v)) for v in row])

    # Compute column widths (minimum 3 for the separator dashes)
    widths = [max(3, len(c)) for c in cols]
    for row in str_rows:
        for i, cell in enumerate(row):
            widths[i] = max(widths[i], len(cell))

    # Build table lines
    header = "| " + " | ".join(c.ljust(widths[i]) for i, c in enumerate(cols)) + " |"
    separator = "|" + "|".join("-" * (w + 2) for w in widths) + "|"
    data_lines = [
        "| " + " | ".join(cell.ljust(widths[i]) for i, cell in enumerate(row)) + " |"
        for row in str_rows
    ]

    parts: list[str] = []
    if caption is not None:
        parts.append(f"Table: {caption}")
        parts.append("")
    parts.append(header)
    parts.append(separator)
    parts.extend(data_lines)
    return "\n".join(parts)


def equation_to_markdown(
    equation: str,
    explanations: tuple[str, ...] = (),
    *,
    include_explanations: bool = True,
) -> str:
    r"""Wrap a LaTeX equation in display math delimiters for Quarto.

    Produces ``$$...$$`` display math that Quarto renders natively in
    Typst, HTML, and PDF output. Optionally appends term explanations
    as plain text below the equation block.

    Args:
        equation: LaTeX equation string (without ``$$`` delimiters).
        explanations: Term explanation strings from ``MathDisplay``.
        include_explanations: If True (default), append explanations
            as plain text lines below the equation.

    Returns:
        Markdown string with display math block and optional explanations.

    Examples:
        >>> print(equation_to_markdown(r"y = \beta_0 + \beta_1 x"))
        $$
        y = \beta_0 + \beta_1 x
        $$
    """
    parts = [f"$$\n{equation}\n$$"]
    if include_explanations and explanations:
        parts.append("")
        for exp in explanations:
            parts.append(f"- {exp}")
    return "\n".join(parts)


def write_text(text: str, path: str | Path) -> None:
    """Write text content to a file, creating parent directories.

    Args:
        path: Destination file path. Parent directories are created
            automatically if they don't exist.
        text: Text content to write.
    """
    dest = Path(path)
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_text(text, encoding="utf-8")


def to_markdown(
    df: pl.DataFrame,
    path: str | Path | None = None,
    caption: str | None = None,
) -> str:
    """Convert a Polars DataFrame to a markdown table, optionally saving to file.

    Standalone utility for DataFrames not wrapped in ``ModelResult`` —
    such as results from ``compare()``, ``model.jointtest()``,
    ``model.vif()``, ``model.to_odds_ratio()``, etc.

    For ``ModelResult`` objects (returned by ``.fit()``, ``.infer()``,
    etc.), use ``result.to_markdown()`` instead.

    Args:
        df: Polars DataFrame to convert.
        path: Optional file path. If given, writes the markdown and
            creates parent directories automatically.
        caption: Optional table caption (``Table: ...`` Quarto syntax).

    Returns:
        Pipe-delimited markdown table as a string.

    Examples:
        >>> from bossanova import compare, to_markdown
        >>> to_markdown(compare(m1, m2), "comparison.md", caption="Model Comparison")
        >>> md = to_markdown(m.jointtest())  # string only
    """
    text = dataframe_to_markdown(df, caption=caption)
    if path is not None:
        write_text(text, path)
    return text
