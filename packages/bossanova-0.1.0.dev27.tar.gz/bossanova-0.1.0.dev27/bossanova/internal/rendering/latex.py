"""LaTeX equation generation from model containers.

Pure functions that accept ModelSpec, DataBundle, and FormulaSpec containers
and produce MathDisplay output. Works pre-data (spec-only) and post-data
(with full factor/contrast/transform metadata).
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from bossanova.internal.containers.structs.display import MathDisplay, TermInfo

if TYPE_CHECKING:
    from bossanova.internal.containers.structs.data import DataBundle
    from bossanova.internal.containers.structs.formula import FormulaSpec
    from bossanova.internal.containers.structs.specs import ModelSpec

__all__ = ["build_equation"]


# =============================================================================
# Regex patterns
# =============================================================================

_FACTOR_PATTERN = re.compile(r"^([a-zA-Z_][a-zA-Z0-9_]*)\[([^\]]+)\]$")
_TRANSFORM_PATTERN = re.compile(
    r"^(center|scale|standardize|zscore|norm|log|rank|signed_rank)\((.+)\)$"
)
_POLY_PATTERN = re.compile(r"^([a-zA-Z_][a-zA-Z0-9_]*)(\.L|\.Q|\.C|\.\^[0-9]+)$")
_INTERACTION_PATTERN = re.compile(r":")


# =============================================================================
# LaTeX helpers
# =============================================================================


def escape_latex(text: str) -> str:
    """Escape text for LaTeX."""
    return text.replace("_", r"\_")


def format_variable_latex(name: str, subscript: str = "i") -> str:
    """Format variable name for LaTeX."""
    escaped = escape_latex(name)
    return rf"\text{{{escaped}}}_{{{subscript}}}"


# =============================================================================
# Term categorization
# =============================================================================


def categorize_term(
    term_name: str,
    term_idx: int,
    *,
    factors: dict[str, tuple[str, ...]] | None = None,
    contrast_types: dict[str, str] | None = None,
    transform_state: dict[str, dict] | None = None,
) -> TermInfo:
    """Parse a term name and return its categorization.

    Args:
        term_name: Column name (e.g., "Intercept", "center(x1)", "group[B]").
        term_idx: Index of this term (for beta subscript).
        factors: Factor name → ordered level tuple (from FormulaSpec.factors).
        contrast_types: Factor name → contrast type string (from FormulaSpec.contrast_types).
        transform_state: Transform key → state dict (from FormulaSpec.transform_state).

    Returns:
        TermInfo with parsed metadata.
    """
    factors = factors or {}
    contrast_types = contrast_types or {}
    transform_state = transform_state or {}

    beta_sub = str(term_idx)
    symbol = rf"\beta_{{{beta_sub}}}"

    # --- Intercept ---
    if term_name == "Intercept":
        return TermInfo(
            name=term_name,
            term_type="intercept",
            base_var="Intercept",
            symbol=r"\beta_0",
            latex=r"\beta_0",
            explanation=r"$\beta_0$: Intercept (expected response when all predictors = 0)",
        )

    # --- Interaction (contains :) ---
    if _INTERACTION_PATTERN.search(term_name):
        parts = term_name.split(":")
        latex_parts = []
        for p in parts:
            factor_match = _FACTOR_PATTERN.match(p)
            if factor_match:
                latex_parts.append(rf"\mathbb{{1}}_{{[{escape_latex(p)}]}}")
            else:
                latex_parts.append(format_variable_latex(p))
        interaction_latex = r" \cdot ".join(latex_parts)
        return TermInfo(
            name=term_name,
            term_type="interaction",
            base_var=term_name,
            symbol=symbol,
            latex=rf"{symbol} ({interaction_latex})",
            explanation=rf"${symbol}$: {term_name} - interaction effect",
        )

    # --- Polynomial contrast (e.g., cyl.L, cyl.Q) ---
    poly_match = _POLY_PATTERN.match(term_name)
    if poly_match:
        var_name, poly_suffix = poly_match.groups()
        poly_type = {"L": "linear", "Q": "quadratic", "C": "cubic"}.get(
            poly_suffix.lstrip("."), f"degree {poly_suffix.lstrip('.^')}"
        )
        return TermInfo(
            name=term_name,
            term_type="poly",
            base_var=var_name,
            symbol=symbol,
            latex=rf"{symbol} \, {escape_latex(term_name)}_i",
            explanation=rf"${symbol}$: {var_name} - {poly_type} polynomial contrast",
        )

    # --- Factor level (e.g., group[B]) ---
    factor_match = _FACTOR_PATTERN.match(term_name)
    if factor_match:
        var_name, level = factor_match.groups()
        contrast_type = contrast_types.get(var_name, "treatment")
        levels = factors.get(var_name, ())

        if contrast_type == "treatment":
            ref_level = levels[0] if levels else "?"
            exp = (
                rf"${symbol}$: {var_name}[{level}] - "
                rf"treatment contrast ({level} vs {ref_level} [reference])"
            )
            if levels:
                non_ref = ", ".join(lv for lv in levels if lv != ref_level)
                exp += f"\n     Levels: {ref_level} [ref], {non_ref}"
        elif contrast_type == "sum":
            omitted = levels[-1] if levels else "?"
            exp = (
                rf"${symbol}$: {var_name}[{level}] - "
                r"sum contrast (deviation from grand mean)"
            )
            if levels:
                exp += f"\n     Omitted level: {omitted}"
        else:
            exp = rf"${symbol}$: {var_name}[{level}] - {contrast_type} contrast"

        return TermInfo(
            name=term_name,
            term_type="factor",
            base_var=var_name,
            symbol=symbol,
            latex=rf"{symbol} \, \mathbb{{1}}_{{[{escape_latex(term_name)}]}}",
            explanation=exp,
        )

    # --- Transform (e.g., center(x), scale(x)) ---
    transform_match = _TRANSFORM_PATTERN.match(term_name)
    if transform_match:
        transform_name, var_name = transform_match.groups()
        state = transform_state.get(term_name, {})
        params = state.get("params", {})

        if transform_name == "center":
            mean_val = params.get("mean", "?")
            mean_str = (
                f"{mean_val:.3g}"
                if isinstance(mean_val, (int, float))
                else str(mean_val)
            )
            superscript = "c"
            exp = rf"${symbol}$: {var_name} (centered, mean = {mean_str})"
        elif transform_name == "scale":
            std_val = params.get("std", "?")
            std_str = (
                f"{std_val:.3g}" if isinstance(std_val, (int, float)) else str(std_val)
            )
            superscript = "s"
            exp = rf"${symbol}$: {var_name} (scaled, std = {std_str})"
        elif transform_name in ("standardize", "zscore"):
            mean_val = params.get("mean", "?")
            std_val = params.get("std", "?")
            mean_str = (
                f"{mean_val:.3g}"
                if isinstance(mean_val, (int, float))
                else str(mean_val)
            )
            std_str = (
                f"{std_val:.3g}" if isinstance(std_val, (int, float)) else str(std_val)
            )
            superscript = "z"
            exp = rf"${symbol}$: {var_name} (standardized, mean = {mean_str}, std = {std_str})"
        elif transform_name == "log":
            superscript = ""
            exp = rf"${symbol}$: log({var_name})"
        elif transform_name == "rank":
            superscript = "r"
            exp = rf"${symbol}$: {var_name} (average-method rank)"
        elif transform_name == "signed_rank":
            superscript = "sr"
            exp = rf"${symbol}$: {var_name} (signed rank: sign × rank of |x|)"
        elif transform_name == "norm":
            std_val = params.get("std", "?")
            std_str = (
                f"{std_val:.3g}" if isinstance(std_val, (int, float)) else str(std_val)
            )
            superscript = "n"
            exp = rf"${symbol}$: {var_name} (normalized, std = {std_str})"
        else:
            superscript = ""
            exp = rf"${symbol}$: {term_name}"

        if superscript:
            var_latex = rf"{format_variable_latex(var_name)}^{{{superscript}}}"
        else:
            var_latex = rf"\log({format_variable_latex(var_name)})"

        return TermInfo(
            name=term_name,
            term_type="transform",
            base_var=var_name,
            symbol=symbol,
            latex=rf"{symbol} \, {var_latex}",
            explanation=exp,
        )

    # --- Default: continuous variable ---
    return TermInfo(
        name=term_name,
        term_type="continuous",
        base_var=term_name,
        symbol=symbol,
        latex=rf"{symbol} \, {format_variable_latex(term_name)}",
        explanation=rf"${symbol}$: {term_name} - effect per unit increase",
    )


# =============================================================================
# Equation builders
# =============================================================================


def build_lm_equation(terms: list[TermInfo]) -> str:
    """Build equation for linear model."""
    fixed_effects = " + ".join(t.latex for t in terms)
    return rf"y_i = {fixed_effects} + \varepsilon_i, \quad \varepsilon_i \sim N(0, \sigma^2)"


def build_glm_equation(terms: list[TermInfo], family: str, link: str) -> str:
    """Build equation for generalized linear model."""
    link_latex = {
        "identity": r"\mu_i",
        "logit": r"\log\left(\frac{\mu_i}{1-\mu_i}\right)",
        "log": r"\log(\mu_i)",
        "probit": r"\Phi^{-1}(\mu_i)",
        "cloglog": r"\log(-\log(1-\mu_i))",
        "inverse": r"\frac{1}{\mu_i}",
        "sqrt": r"\sqrt{\mu_i}",
    }.get(link, r"g(\mu_i)")

    family_latex = {
        "gaussian": r"y_i \sim N(\mu_i, \sigma^2)",
        "binomial": r"y_i \sim \text{Binomial}(n_i, \mu_i)",
        "poisson": r"y_i \sim \text{Poisson}(\mu_i)",
        "gamma": r"y_i \sim \text{Gamma}(\mu_i, \phi)",
        "inverse_gaussian": r"y_i \sim \text{InverseGaussian}(\mu_i, \phi)",
        "tdist": r"y_i \sim t_\nu(\mu_i, \sigma^2)",
    }.get(family, rf"y_i \sim \text{{{family}}}(\mu_i)")

    fixed_effects = " + ".join(t.latex for t in terms)
    return rf"{link_latex} = {fixed_effects} \quad \text{{where }} {family_latex}"


def build_mixed_equation(
    terms: list[TermInfo],
    family: str,
    link: str,
    grouping_vars: list[str],
    random_names: list[str],
) -> str:
    """Build equation for mixed model (LMM or GLMM)."""
    fixed_effects = " + ".join(t.latex for t in terms)

    re_parts: list[str] = []
    re_dist_parts: list[str] = []
    n_groups = len(grouping_vars)

    if n_groups == 1:
        group_name = grouping_vars[0]
        j_sub = "j"
        for r_idx, re_term in enumerate(random_names):
            if re_term == "Intercept":
                re_parts.append(rf"u_{{0{j_sub}}}")
            else:
                re_parts.append(
                    rf"u_{{{r_idx}{j_sub}}} \, {format_variable_latex(re_term, 'i' + j_sub)}"
                )
        if len(random_names) == 1:
            re_dist_parts.append(
                rf"u_{{0{j_sub}}} \sim N(0, \sigma_{{u,{escape_latex(group_name)}}}^2)"
            )
        else:
            re_dist_parts.append(
                rf"\mathbf{{u}}_{{{j_sub}}} \sim N(\mathbf{{0}}, "
                rf"\Sigma_{{{escape_latex(group_name)}}})"
            )
    else:
        for g_idx, group_name in enumerate(grouping_vars):
            j_sub = chr(ord("j") + g_idx)
            re_term = random_names[g_idx] if g_idx < len(random_names) else "Intercept"
            if re_term == "Intercept":
                re_parts.append(rf"u_{{0{j_sub}}}")
            else:
                re_parts.append(
                    rf"u_{{1{j_sub}}} \, {format_variable_latex(re_term, 'i' + j_sub)}"
                )
            re_dist_parts.append(
                rf"u_{{0{j_sub}}} \sim N(0, \sigma_{{u,{escape_latex(group_name)}}}^2)"
            )

    random_effects = " + ".join(re_parts)
    re_distribution = ", \\quad ".join(re_dist_parts)

    is_glm = family != "gaussian"

    if is_glm:
        link_latex = {
            "identity": r"\mu_{ij}",
            "logit": r"\log\left(\frac{\mu_{ij}}{1-\mu_{ij}}\right)",
            "log": r"\log(\mu_{ij})",
            "probit": r"\Phi^{-1}(\mu_{ij})",
        }.get(link, r"g(\mu_{ij})")

        family_latex = {
            "binomial": r"y_{ij} \sim \text{Binomial}(n_{ij}, \mu_{ij})",
            "poisson": r"y_{ij} \sim \text{Poisson}(\mu_{ij})",
        }.get(family, rf"y_{{ij}} \sim \text{{{family}}}(\mu_{{ij}})")

        return (
            rf"{link_latex} = {fixed_effects} + {random_effects}"
            rf" \\ \text{{where }} {re_distribution}, \quad {family_latex}"
        )
    else:
        return (
            rf"y_{{ij}} = {fixed_effects} + {random_effects} + \varepsilon_{{ij}}"
            rf" \\ \text{{where }} {re_distribution},"
            rf" \quad \varepsilon_{{ij}} \sim N(0, \sigma^2)"
        )


# =============================================================================
# Public API
# =============================================================================


def build_equation(
    spec: ModelSpec,
    bundle: DataBundle | None = None,
    formula_spec: FormulaSpec | None = None,
    *,
    explanations: bool = True,
) -> MathDisplay:
    """Build a structural LaTeX equation from model containers.

    Works in two modes:
    - **Spec-only** (no data): generic symbols from ``spec.fixed_terms``.
    - **With bundle**: full rendering using ``bundle.X_names`` for exact
      column names, factor levels, contrast types, and transform parameters.

    Args:
        spec: Model specification (always available).
        bundle: Data bundle (None before data is attached).
        formula_spec: Learned formula encoding (None before data is attached).
        explanations: Include term explanations in the output.

    Returns:
        MathDisplay with equation, explanations, and rich display methods.
    """
    # Determine term names — prefer bundle (exact columns) over spec (generic)
    if bundle is not None:
        term_names = list(bundle.X_names)
    else:
        term_names = list(spec.fixed_terms)

    # Extract metadata dicts from formula_spec if available
    factors = dict(formula_spec.factors) if formula_spec is not None else {}
    contrast_types_dict = (
        dict(formula_spec.contrast_types) if formula_spec is not None else {}
    )
    transform_state_dict = (
        dict(formula_spec.transform_state) if formula_spec is not None else {}
    )

    # Categorize all terms
    terms = [
        categorize_term(
            name,
            idx,
            factors=factors,
            contrast_types=contrast_types_dict,
            transform_state=transform_state_dict,
        )
        for idx, name in enumerate(term_names)
    ]

    # Determine model type and build equation
    family = spec.family
    link = spec.link
    is_mixed = spec.has_random_effects

    if is_mixed:
        # Extract random effects structure
        if bundle is not None and bundle.re_metadata is not None:
            grouping_vars = list(bundle.re_metadata.grouping_vars)
            random_names = list(bundle.re_metadata.random_names)
        else:
            # Spec-only: parse grouping from random_terms strings
            grouping_vars, random_names = parse_random_terms_from_spec(
                spec.random_terms
            )

        equation = build_mixed_equation(
            terms, family, link, grouping_vars, random_names
        )
    elif family != "gaussian":
        equation = build_glm_equation(terms, family, link)
    else:
        equation = build_lm_equation(terms)

    exp_list = tuple(t.explanation for t in terms) if explanations else ()

    return MathDisplay(equation=equation, explanations=exp_list)


def parse_random_terms_from_spec(
    random_terms: tuple[str, ...],
) -> tuple[list[str], list[str]]:
    """Extract grouping vars and random names from spec random_terms strings.

    Parses strings like "(1|subject)", "(1+time|subject)" into grouping
    variables and the random effect names.

    Args:
        random_terms: Tuple of random effect specification strings.

    Returns:
        Tuple of (grouping_vars, random_names).
    """
    grouping_vars: list[str] = []
    random_names: list[str] = []

    re_pattern = re.compile(r"\(([^|]+)\|([^)]+)\)")
    for term in random_terms:
        match = re_pattern.search(term)
        if match:
            lhs, group = match.group(1).strip(), match.group(2).strip()
            grouping_vars.append(group)
            # Parse LHS: "1" → Intercept, "1+time" → [Intercept, time]
            lhs_parts = [p.strip() for p in lhs.split("+")]
            for part in lhs_parts:
                if part == "1":
                    random_names.append("Intercept")
                elif part == "0":
                    pass  # No intercept
                else:
                    random_names.append(part)

    # Deduplicate grouping vars while preserving order
    seen: set[str] = set()
    unique_groups: list[str] = []
    for g in grouping_vars:
        if g not in seen:
            seen.add(g)
            unique_groups.append(g)

    if not random_names:
        random_names = ["Intercept"]

    return unique_groups, random_names
