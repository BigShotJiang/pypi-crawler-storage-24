"""Inference for marginal effects using the delta method.

This module provides inference computation for MeeState results.
Uses the delta method: SE = sqrt(diag(L @ vcov @ L'))

Internal exports:
    compute_mee_inference: Add inference to MeeState via delta method
    compute_mee_se: Compute SEs for MEE (means or slopes)
    compute_mee_inference_fallback: Fallback inference without L_matrix
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from attrs import evolve

from bossanova.internal.maths.inference import (
    compute_ci,
    compute_mvt_critical,
    compute_pvalue,
    compute_t_critical,
    compute_tukey_critical,
    compute_z_critical,
    delta_method_se,
)

if TYPE_CHECKING:
    import polars as pl

    from bossanova.internal.containers import DataBundle, FitState
    from bossanova.internal.containers.structs.marginal import MeeState

__all__ = [
    "compute_mee_inference",
    "compute_mee_inference_fallback",
    "compute_mee_se",
]


def compute_mee_inference(
    mee: MeeState,
    vcov: np.ndarray,
    df_resid: float | np.ndarray | None,
    conf_level: float = 0.95,
    null: float = 0.0,
    alternative: str = "two-sided",
) -> MeeState:
    """Compute delta method inference for marginal effects.

    Uses the delta method to compute standard errors for EMMs and slopes:
        SE = sqrt(diag(L @ vcov @ L'))

    where L is the design matrix (X_ref for EMMs, selector for slopes).

    Applies multiplicity adjustment for contrast CIs to match R's emmeans:
    - Tukey HSD for pairwise contrasts.
    - Multivariate-t (MVT) for sequential, treatment, sum, helmert contrasts.
    - No adjustment for polynomial contrasts or non-contrast MEEs.

    For response-scale EMMs (``effect_scale="response"``), CIs are computed on the
    link scale then back-transformed via the inverse link function,
    matching R's emmeans behavior.

    Args:
        mee: MeeState with L_matrix from compute_emm or compute_slopes.
        vcov: Variance-covariance matrix of coefficients, shape (p, p).
        df_resid: Degrees of freedom for t-distribution.  Can be:
            - ``None``: z-distribution (asymptotic normality).
            - scalar ``float``: single df for all estimates (residual df).
            - ``np.ndarray``: per-estimate Satterthwaite df (mixed models).
        conf_level: Confidence level for intervals (default 0.95).
        null: Null hypothesis value (default 0.0).
        alternative: Alternative hypothesis direction (default "two-sided").

    Returns:
        MeeState augmented with inference fields (se, df, statistic,
        p_value, ci_lower, ci_upper, conf_level).

    Raises:
        ValueError: If mee.L_matrix is None (delta method requires design matrix).

    Examples:
        Compute inference for EMMs::

            from bossanova.internal.marginal import compute_emm
            from bossanova.internal.marginal.inference import compute_mee_inference

            mee = compute_emm(bundle, fit, "treatment", "treatment")
            mee_with_inf = compute_mee_inference(mee, fit.vcov, fit.df_resid)
            # mee_with_inf.se: standard errors
            # mee_with_inf.ci_lower, mee_with_inf.ci_upper: confidence bounds

    Note:
        For EMMs, L_matrix is the reference design matrix X_ref.
        For slopes, L_matrix is a selector row that picks the coefficient.
        For contrasts, L_matrix is the contrast matrix applied to EMMs.
    """
    if mee.L_matrix is None:
        raise ValueError(
            "Cannot compute delta method inference: L_matrix is None. "
            "Ensure the MEE was computed with compute_emm() or compute_slopes() "
            "which store the design matrix."
        )

    L = mee.L_matrix
    estimate = mee.estimate
    n_estimates = len(estimate)

    # Compute standard errors via delta method (on response scale if effect_scale="response")
    se = delta_method_se(L, vcov)

    # For response-scale EMMs, compute link-scale quantities for CIs and tests.
    # R's emmeans performs tests on the link scale and back-transforms CIs.
    has_link = mee.link is not None and mee.L_matrix_link is not None
    if has_link:
        from bossanova.internal.maths.family.links import (
            apply_link,
            apply_link_inverse,
        )

        L_link = mee.L_matrix_link
        link_se = delta_method_se(L_link, vcov)
        link_estimate = np.asarray(apply_link(mee.link, estimate))
        # Test statistics and p-values on link scale (matches R)
        link_null = 0.0 if null == 0.0 else np.log(null) if null > 0 else 0.0
        centered = link_estimate - link_null
        statistic = np.divide(
            centered, link_se, out=np.full_like(estimate, np.nan), where=link_se > 0
        )
    else:
        # Standard: test on same scale as estimates
        centered = estimate - null
        statistic = np.divide(
            centered, se, out=np.full_like(estimate, np.nan), where=se > 0
        )

    # Handle per-estimate df array (Satterthwaite) vs scalar/None
    is_array_df = isinstance(df_resid, np.ndarray)

    if is_array_df:
        df_arr = np.asarray(df_resid, dtype=np.float64)
        p_value = _pvalue_per_df(statistic, df_arr, alternative)

        if has_link:
            # Back-transformed CIs: compute on link scale, inverse-link
            ci_lower, ci_upper = _ci_per_df(
                link_estimate,
                link_se,
                df_arr,
                conf_level,
                alternative,
                mee=mee,
                vcov=vcov,
            )
            ci_lower = np.asarray(apply_link_inverse(mee.link, ci_lower))
            ci_upper = np.asarray(apply_link_inverse(mee.link, ci_upper))
        else:
            ci_lower, ci_upper = _ci_per_df(
                estimate,
                se,
                df_arr,
                conf_level,
                alternative,
                mee=mee,
                vcov=vcov,
            )
        df = df_arr
    else:
        # Scalar df or None (z-distribution)
        use_t = df_resid is not None and np.isfinite(df_resid)
        scalar_df = df_resid if use_t else float("inf")

        p_value = compute_pvalue(
            statistic, df=df_resid if use_t else None, alternative=alternative
        )

        # Compute critical value (with multiplicity adjustment for contrasts)
        crit = _compute_critical_value(
            mee, vcov, conf_level, scalar_df, use_t, alternative
        )

        if has_link:
            # Back-transformed CIs: compute on link scale, inverse-link
            ci_lower, ci_upper = compute_ci(
                link_estimate, link_se, crit, alternative=alternative
            )
            ci_lower = np.asarray(apply_link_inverse(mee.link, ci_lower))
            ci_upper = np.asarray(apply_link_inverse(mee.link, ci_upper))
        else:
            ci_lower, ci_upper = compute_ci(estimate, se, crit, alternative=alternative)

        df = np.full(n_estimates, scalar_df)

    # Return evolved MeeState with inference fields
    return evolve(
        mee,
        se=se,
        df=df,
        statistic=statistic,
        p_value=p_value,
        ci_lower=ci_lower,
        ci_upper=ci_upper,
        conf_level=conf_level,
    )


def _compute_critical_value(
    mee: MeeState,
    vcov: np.ndarray,
    conf_level: float,
    df: float,
    use_t: bool,
    alternative: str,
) -> float:
    """Compute the critical value, applying multiplicity adjustment for contrasts.

    Matches R's emmeans defaults:
    - ``pairs()`` → Tukey HSD (studentized range).
    - ``contrast("consec")`` → multivariate-t (MVT).
    - ``contrast("poly")`` and non-contrasts → no adjustment.

    Args:
        mee: MeeState with optional contrast_method and n_contrast_levels.
        vcov: Variance-covariance matrix of coefficients, shape (p, p).
        conf_level: Confidence level (e.g. 0.95).
        df: Degrees of freedom (scalar).
        use_t: Whether to use t-distribution (vs z).
        alternative: Alternative hypothesis direction.

    Returns:
        Critical value for CI computation.
    """
    method = mee.contrast_method

    if method == "pairwise" and mee.n_contrast_levels is not None:
        # Tukey HSD: uses studentized range with k=n_contrast_levels
        return compute_tukey_critical(conf_level, k=mee.n_contrast_levels, df=df)

    if (
        method in ("sequential", "treatment", "sum", "helmert")
        and mee.L_matrix is not None
    ):
        # MVT: compute correlation matrix of contrasts, then find critical value
        L = mee.L_matrix
        cov_contrasts = L @ vcov @ L.T
        se_diag = np.sqrt(np.diag(cov_contrasts))
        # Normalize to correlation matrix
        outer_se = np.outer(se_diag, se_diag)
        corr = cov_contrasts / outer_se
        # Clip to valid correlation range
        np.clip(corr, -1.0, 1.0, out=corr)
        np.fill_diagonal(corr, 1.0)
        return compute_mvt_critical(conf_level, corr, df=df)

    # No adjustment (poly, non-contrast, or missing info)
    if use_t:
        return compute_t_critical(conf_level, df=df, alternative=alternative)
    return compute_z_critical(conf_level, alternative=alternative)


def _pvalue_per_df(
    statistic: np.ndarray,
    df: np.ndarray,
    alternative: str,
) -> np.ndarray:
    """Compute p-values element-wise with per-estimate df.

    Args:
        statistic: Test statistics, shape (n,).
        df: Per-estimate degrees of freedom, shape (n,).
        alternative: ``"two-sided"``, ``"greater"``, or ``"less"``.

    Returns:
        P-values, shape (n,).
    """
    from scipy import stats

    p_min = np.finfo(np.float64).eps

    if alternative == "two-sided":
        p_values = 2 * stats.t.sf(np.abs(statistic), df=df)
    elif alternative == "greater":
        p_values = stats.t.sf(statistic, df=df)
    elif alternative == "less":
        p_values = stats.t.cdf(statistic, df=df)
    else:
        raise ValueError(
            f"alternative must be 'two-sided', 'greater', or 'less', "
            f"got {alternative!r}"
        )
    return np.clip(p_values, p_min, 1.0)


def _ci_per_df(
    estimate: np.ndarray,
    se: np.ndarray,
    df: np.ndarray,
    conf_level: float,
    alternative: str,
    *,
    mee: MeeState | None = None,
    vcov: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Compute confidence intervals element-wise with per-estimate df.

    Applies multiplicity adjustment if ``mee`` has contrast info:
    - Tukey HSD for pairwise (per-estimate df).
    - MVT for sequential, treatment, sum, helmert (uses minimum df).

    Args:
        estimate: Point estimates, shape (n,).
        se: Standard errors, shape (n,).
        df: Per-estimate degrees of freedom, shape (n,).
        conf_level: Confidence level (e.g. 0.95).
        alternative: ``"two-sided"``, ``"greater"``, or ``"less"``.
        mee: Optional MeeState for multiplicity adjustment info.
        vcov: Variance-covariance matrix (needed for MVT correlation).

    Returns:
        Tuple of (ci_lower, ci_upper) arrays, each shape (n,).
    """
    # Determine per-estimate critical values
    crits = _per_estimate_critical_values(df, conf_level, mee, vcov)

    if alternative == "two-sided":
        ci_lower = estimate - crits * se
        ci_upper = estimate + crits * se
    elif alternative == "greater":
        ci_lower = estimate - crits * se
        ci_upper = np.full_like(estimate, float("inf"))
    elif alternative == "less":
        ci_lower = np.full_like(estimate, float("-inf"))
        ci_upper = estimate + crits * se
    else:
        raise ValueError(
            f"alternative must be 'two-sided', 'greater', or 'less', "
            f"got {alternative!r}"
        )
    return ci_lower, ci_upper


def _per_estimate_critical_values(
    df: np.ndarray,
    conf_level: float,
    mee: MeeState | None,
    vcov: np.ndarray | None,
) -> np.ndarray:
    """Compute per-estimate critical values with optional multiplicity adjustment.

    Args:
        df: Per-estimate degrees of freedom, shape (n,).
        conf_level: Confidence level.
        mee: Optional MeeState for contrast info.
        vcov: Variance-covariance matrix (for MVT correlation).

    Returns:
        Array of critical values, shape (n,).
    """
    from scipy import stats

    alpha = 1.0 - conf_level
    n = len(df)

    method = mee.contrast_method if mee is not None else None

    if method == "pairwise" and mee.n_contrast_levels is not None:
        # Tukey HSD per-estimate: each contrast gets its own df
        crits = np.empty(n, dtype=np.float64)
        for i in range(n):
            crits[i] = compute_tukey_critical(
                conf_level, k=mee.n_contrast_levels, df=df[i]
            )
        return crits

    if (
        method in ("sequential", "treatment", "sum", "helmert")
        and mee is not None
        and mee.L_matrix is not None
        and vcov is not None
    ):
        # MVT: use minimum df (conservative) since MVT requires single df
        min_df = float(np.min(df))
        L = mee.L_matrix
        cov_contrasts = L @ vcov @ L.T
        se_diag = np.sqrt(np.diag(cov_contrasts))
        outer_se = np.outer(se_diag, se_diag)
        corr = cov_contrasts / outer_se
        np.clip(corr, -1.0, 1.0, out=corr)
        np.fill_diagonal(corr, 1.0)
        crit = compute_mvt_critical(conf_level, corr, df=min_df)
        return np.full(n, crit)

    # No adjustment — standard per-df t critical values
    return stats.t.ppf(1 - alpha / 2, df=df)


def compute_mee_se(
    mee: "MeeState",
    bundle: "DataBundle",
    fit: "FitState",
    data: "pl.DataFrame",
) -> np.ndarray:
    """Compute standard errors for MEE estimates (means or slopes).

    When an L_matrix is available, uses the delta method:
    ``SE = sqrt(diag(L @ vcov @ L'))``.  This correctly handles
    multi-row L_matrices (e.g. per-group conditional slopes).

    Otherwise falls back to simplified type-based dispatch:
    - ``"means"``: SE = sqrt(MSE / n_per_group) for each group level
    - ``"slopes"``: SE = sqrt(vcov[idx, idx]) from coefficient vcov diagonal

    Args:
        mee: MeeState with type ("means" or "slopes") and focal_var.
        bundle: Data bundle with X_names.
        fit: Fit state with sigma, dispersion, residuals, vcov, df_resid.
        data: Original data frame for group counting.

    Returns:
        Array of standard errors, one per estimate.
    """
    # Prefer delta method when L_matrix is available (handles all shapes)
    if mee.L_matrix is not None:
        return delta_method_se(mee.L_matrix, fit.vcov)

    if mee.type == "means":
        return _compute_se_means(mee, fit, data)
    elif mee.type == "slopes":
        return _compute_se_slopes(mee, bundle, fit)
    else:
        return np.full(len(mee.estimate), np.nan)


def _compute_se_means(
    mee: "MeeState",
    fit: "FitState",
    data: "pl.DataFrame",
) -> np.ndarray:
    """Compute standard errors for EMM means.

    For categorical EMMs, computes SE as sqrt(MSE / n_per_group).

    Args:
        mee: MeeState with focal_var and grid.
        fit: Fit state with sigma, dispersion, residuals, df_resid.
        data: Original data frame for group counting.

    Returns:
        Array of standard errors for each EMM.
    """
    focal_var = mee.focal_var
    levels = mee.grid[focal_var].to_list()

    # Get residual variance
    if fit.sigma is not None:
        mse = fit.sigma**2
    elif fit.dispersion is not None:
        mse = fit.dispersion
    else:
        residuals = fit.residuals
        mse = np.sum(residuals**2) / fit.df_resid

    # Compute SE for each level
    ses = []
    for level in levels:
        mask = data[focal_var] == level
        n_obs = mask.sum()
        se = np.sqrt(mse / n_obs) if n_obs > 0 else np.nan
        ses.append(se)

    return np.array(ses)


def _compute_se_slopes(
    mee: "MeeState",
    bundle: "DataBundle",
    fit: "FitState",
) -> np.ndarray:
    """Compute standard errors for marginal slopes.

    For continuous marginal effects, the SE comes directly from
    the vcov diagonal for the focal variable's coefficient.

    Args:
        mee: MeeState with focal_var.
        bundle: Data bundle with X_names.
        fit: Fit state with vcov.

    Returns:
        Array of standard errors for each slope.
    """
    focal_var = mee.focal_var

    if focal_var in bundle.X_names:
        idx = list(bundle.X_names).index(focal_var)
        se = np.sqrt(fit.vcov[idx, idx])
        return np.array([se])
    else:
        return np.array([np.nan])


def compute_mee_inference_fallback(
    mee: "MeeState",
    bundle: "DataBundle",
    fit: "FitState",
    data: "pl.DataFrame",
    df_resid: float | None,
    conf_level: float = 0.95,
    null: float = 0.0,
    alternative: str = "two-sided",
) -> "MeeState":
    """Compute inference for MEE without L_matrix (fallback path).

    Used when L_matrix is not available (legacy MEE). Computes simplified
    SEs via ``compute_mee_se``, then builds test statistics, p-values,
    and confidence intervals.

    Args:
        mee: MeeState without L_matrix.
        bundle: Data bundle with X_names.
        fit: Fit state with vcov, sigma, etc.
        data: Original data frame for group counting.
        df_resid: Residual degrees of freedom (None for z-distribution).
        conf_level: Confidence level for intervals.
        null: Null hypothesis value (default 0.0).
        alternative: Alternative hypothesis direction (default "two-sided").

    Returns:
        MeeState augmented with inference fields.
    """
    estimate = mee.estimate
    n_estimates = len(estimate)
    df_val = df_resid if df_resid is not None else float("inf")
    use_t = df_resid is not None

    # Compute SEs via consolidated dispatch
    se = compute_mee_se(mee, bundle, fit, data)

    # Compute test statistics: (estimate - null) / se
    centered = estimate - null
    statistic = np.divide(
        centered, se, out=np.full_like(estimate, np.nan), where=se != 0
    )

    # Compute p-values
    p_value = compute_pvalue(statistic, df=df_resid, alternative=alternative)

    # Compute confidence intervals
    if use_t:
        crit = compute_t_critical(conf_level, df=df_val, alternative=alternative)
    else:
        crit = compute_z_critical(conf_level, alternative=alternative)

    ci_lower, ci_upper = compute_ci(estimate, se, crit, alternative=alternative)

    # Create df array
    df = np.full(n_estimates, df_val)

    return evolve(
        mee,
        se=se,
        df=df,
        statistic=statistic,
        p_value=p_value,
        ci_lower=ci_lower,
        ci_upper=ci_upper,
        conf_level=conf_level,
    )
