"""Reference grid construction for marginal effects."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import polars as pl

if TYPE_CHECKING:
    from bossanova.internal.containers.structs.data import DataBundle

__all__ = [
    "build_reference_grid",
]


def build_reference_grid(
    bundle: DataBundle,
    focal_vars: list[str],
    *,
    at: dict[str, Any] | None = None,
    covariate_means: dict[str, float] | None = None,
) -> pl.DataFrame:
    """Construct reference grid for marginal effects evaluation.

    Creates a grid of covariate values at which to evaluate predictions.
    This function transforms the parsed explore formula's conditions into
    a concrete evaluation grid.

    The grid construction follows emmeans conventions:
    - Focal variables: vary across their unique levels/values from data
    - Non-focal continuous: set to their overall mean from the data
    - Non-focal categorical: create rows for all levels (equal weight averaging)
    - Conditioned variables (@ spec): use the specified values

    Args:
        bundle: DataBundle with model data and metadata. Used to extract:
            - factor_levels: dict mapping categorical vars to their levels
            - X_names: column names for identifying variable types
        focal_vars: Variables to vary across their range/levels. These become
            the rows of the output grid.
        at: Fixed values for conditioning variables. Keys are variable names,
            values are the conditioning value(s). This dict is typically
            built from the ``Condition`` objects in the parsed explore formula.
        covariate_means: Pre-computed means for continuous covariates. If not
            provided, covariates will be omitted from the grid (caller must
            handle them separately or pass via ``at``).

    Returns:
        Polars DataFrame with one row per grid point. Columns include:
        - All focal variables
        - All conditioned variables (if any)
        The number of rows is the Cartesian product of focal variable levels.

    Raises:
        ValueError: If focal_var not found in bundle's factor_levels.

    Integration with explore():
        Called from ``model._compute_marginal_effects()`` after parsing::

            # From parsed explore formula "treatment ~ age@50"
            parsed = ExploreFormulaSpec(
                focal_var="treatment",
                conditions=[Condition(var="age", at_values=(50,))]
            )

            # Convert conditions to at dict
            at_dict = {"age": 50.0}

            # Build grid
            grid = build_reference_grid(
                bundle=self._bundle,
                focal_vars=["treatment"],
                at=at_dict,
            )
            # grid: pl.DataFrame with columns ["treatment"] and rows ["A", "B", "C"]
            # age is NOT in the grid (it's held fixed at 50)

    Examples:
        Grid for categorical focal::

            grid = build_reference_grid(bundle, ["treatment"])
            # Returns grid with one row per treatment level

        Grid with conditioning::

            grid = build_reference_grid(bundle, ["treatment"], at={"age": 50})
            # Returns grid at age=50

        Multiple focal variables (interaction EMMs)::

            grid = build_reference_grid(bundle, ["treatment", "sex"])
            # Returns Cartesian product: treatment x sex levels
    """
    at = at or {}
    covariate_means = covariate_means or {}

    # Validate focal variables exist in factor_levels
    for var in focal_vars:
        if var not in bundle.factor_levels:
            available = list(bundle.factor_levels.keys())
            raise ValueError(
                f"Focal variable '{var}' not found in factor_levels. "
                f"Available factors: {available}"
            )

    # Build factor level lists for focal vars
    factor_levels: dict[str, list[str]] = {}
    for var in focal_vars:
        if var in at:
            # Use specified levels (subset)
            specified = at[var]
            if not isinstance(specified, (list, tuple)):
                specified = [specified]
            factor_levels[var] = list(specified)
        else:
            # Get levels from bundle
            factor_levels[var] = list(bundle.factor_levels[var])

    # Create cartesian product of factor levels
    grid = build_cartesian_product(factor_levels)

    # Handle edge case: no factors but covariates with multiple values
    if grid.is_empty() and at:
        # Find first variable with multiple values to seed the grid
        for var, value in at.items():
            if isinstance(value, (list, tuple)) and len(value) > 1:
                grid = pl.DataFrame({var: list(value)})
                at = {k: v for k, v in at.items() if k != var}
                break

    # Add covariates (from `at` or from means)
    for var, value in at.items():
        if var in focal_vars:
            # Already handled in focal var processing
            continue

        if isinstance(value, (list, tuple)) and len(value) > 1:
            # Multiple values specified - expand grid
            grid = expand_grid_for_values(grid, var, list(value))
        else:
            # Single value - add as constant
            if isinstance(value, (list, tuple)):
                value = value[0]
            grid = grid.with_columns(pl.lit(value).alias(var))

    # Add covariate means for any continuous variables not in `at`
    for var, mean_val in covariate_means.items():
        if var not in at and var not in focal_vars:
            grid = grid.with_columns(pl.lit(mean_val).alias(var))

    return grid


def expand_grid_for_values(
    grid: pl.DataFrame, var_name: str, values: list
) -> pl.DataFrame:
    """Expand grid to include all specified values for a variable.

    Creates a cross product of existing grid rows with the specified values.

    Args:
        grid: Existing reference grid.
        var_name: Variable name to expand.
        values: List of values to include.

    Returns:
        Expanded grid with one row per original row × value combination.

    Examples:
        >>> grid = pl.DataFrame({"cyl": [4, 6, 8]})
        >>> expand_grid_for_values(grid, "wt", [3.0, 4.0])
        # shape: (6, 2)
        # ┌─────┬─────┐
        # │ cyl ┆ wt  │
        # │ i64 ┆ f64 │
        # ╞═════╪═════╡
        # │ 4   ┆ 3.0 │
        # │ 4   ┆ 4.0 │
        # │ 6   ┆ 3.0 │
        # │ 6   ┆ 4.0 │
        # │ 8   ┆ 3.0 │
        # │ 8   ┆ 4.0 │
        # └─────┴─────┘
    """
    if grid.is_empty():
        return pl.DataFrame({var_name: values})

    # Create DataFrame with the values
    values_df = pl.DataFrame({var_name: values})

    # Cross join to expand
    return grid.join(values_df, how="cross")


def build_cartesian_product(level_dict: dict[str, list]) -> pl.DataFrame:
    """Create cartesian product of factor levels.

    Args:
        level_dict: Mapping from factor name to list of levels.

    Returns:
        DataFrame with cartesian product of all factor levels.

    Examples:
        >>> build_cartesian_product({"A": [1, 2], "B": ["x", "y"]})
        # shape: (4, 2)
        # ┌─────┬─────┐
        # │ A   ┆ B   │
        # ╞═════╪═════╡
        # │ 1   ┆ x   │
        # │ 1   ┆ y   │
        # │ 2   ┆ x   │
        # │ 2   ┆ y   │
        # └─────┴─────┘
    """
    if not level_dict:
        return pl.DataFrame()

    # Start with first factor
    factors = list(level_dict.keys())
    result = pl.DataFrame({factors[0]: level_dict[factors[0]]})

    # Cross join with remaining factors
    for factor in factors[1:]:
        other = pl.DataFrame({factor: level_dict[factor]})
        result = result.join(other, how="cross")

    return result
