"""Explore formula scanner/tokenizer.

Extends the formula scanner with ``@`` token support for explore-specific
at-spec syntax (e.g., ``Days@50``, ``Income@range(5)``).
"""

__all__ = [
    "ExploreScanner",
]

from bossanova.internal.formula.parser.scanner import (
    Scanner,
    ScanError,
    format_error_context,
)
from bossanova.internal.formula.parser.token import Token


class ExploreScanner(Scanner):
    """Scanner for explore formulas.

    Extends the base formula scanner to:
    1. Recognize ``@`` as an ``AT`` token.
    2. Skip intercept insertion (explore formulas have no implicit intercept).
    3. Allow multiple tildes check to be skipped (explore ``~`` separates
       LHS/RHS, not response/predictors).

    Args:
        code: The explore formula string to scan.

    Raises:
        ScanError: If the code is empty or contains unexpected characters.
    """

    def scan_token(self) -> None:
        """Scan a single token, adding ``@`` support."""
        char = self.code[self.current]
        if char == "@":
            self.current += 1
            self.add_token("AT")
        else:
            super().scan_token()

    def scan(self, add_intercept: bool = False) -> list[Token]:
        """Scan explore formula string.

        Overrides base to skip intercept insertion and skip the
        multiple-tilde validation (explore formulas use ``~`` differently).

        Args:
            add_intercept: Ignored; always False for explore formulas.

        Returns:
            A list of Token objects.

        Raises:
            ScanError: If scanning fails.
        """
        while not self.at_end():
            self.start = self.current
            self.scan_token()

        self.tokens.append(Token("EOF", "", position=len(self.code)))

        # Validate at most one tilde
        tilde_count = sum(1 for t in self.tokens if t.kind == "TILDE")
        if tilde_count > 1:
            # Find position of second tilde for error pointer
            second_pos = [t.position for t in self.tokens if t.kind == "TILDE"][1]
            raise ScanError(
                format_error_context(
                    self.code,
                    second_pos,
                    "Multiple '~' symbols found in explore formula.",
                )
                + "\n\nAn explore formula should have at most one '~' separating "
                "the focal term (left) from conditions (right).\n"
                "Example: 'pairwise(treatment) ~ age@50'"
            )

        return self.tokens
