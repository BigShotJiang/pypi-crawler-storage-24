"""Condition resolution for explore formula RHS conditioning.

Resolves parsed ``Condition`` objects into typed buckets that downstream
EMM / slope / contrast computation can consume:

- ``at_overrides``: single numeric pins (``Income@50``)
- ``set_categoricals``: single categorical pins (``Ethnicity@Asian``)
- ``grid_categoricals``: multi-level categoricals to cross (bare ``Ethnicity``)
- ``grid_numerics``: multi-value numerics to cross (``Income@:range(5)``)
"""

from __future__ import annotations

import warnings
from typing import TYPE_CHECKING

import numpy as np
import polars as pl
from attrs import Factory, frozen

if TYPE_CHECKING:
    from bossanova.internal.containers.structs.data import DataBundle
    from bossanova.internal.containers.structs.explore import Condition, ContrastExpr

__all__ = [
    "ResolvedConditions",
    "combine_resolved",
    "get_column_values",
    "resolve_conditions",
]


@frozen
class ResolvedConditions:
    """Typed buckets for resolved conditioning specifications.

    Attributes:
        at_overrides: Single numeric pin per variable (e.g. ``Income@50``).
        set_categoricals: Single categorical pin per variable
            (e.g. ``Ethnicity@Asian``).
        grid_categoricals: Multi-level categoricals to cross
            (e.g. bare ``Ethnicity`` → all levels, or
            ``Ethnicity@(Asian, Caucasian)`` → those two levels).
        grid_numerics: Multi-value numerics to cross
            (e.g. ``Income@(10, 20)`` or ``Income@:range(5)``).
    """

    at_overrides: dict[str, float]
    set_categoricals: dict[str, str]
    grid_categoricals: dict[str, list[str]]
    grid_numerics: dict[str, list[float]]
    raw_at_overrides: dict[str, float] = Factory(dict)
    """Pre-transform at-overrides with original (raw) variable names.

    Populated by the dispatch layer after ``_resolve_at_overrides`` remaps
    keys to design-matrix names.  The slopes path needs raw keys because it
    operates on a data grid with raw column names, not design-matrix names.
    Empty when no transform resolution was applied.
    """

    @property
    def has_grid(self) -> bool:
        """Return True if any condition requires grid expansion."""
        return bool(self.grid_categoricals or self.grid_numerics)


def resolve_conditions(
    conditions: tuple[Condition, ...],
    bundle: DataBundle,
    data: pl.DataFrame,
) -> ResolvedConditions:
    """Classify each Condition into the appropriate typed bucket.

    Uses ``bundle.factor_levels`` to distinguish categorical from continuous
    variables, and the ``data`` DataFrame to compute range / quantile grids
    for continuous variables.

    Args:
        conditions: Parsed Condition objects from the explore formula.
        bundle: DataBundle with factor_levels metadata.
        data: Original data DataFrame for computing range/quantile values.

    Returns:
        ResolvedConditions with conditions classified into typed buckets.
    """
    at_overrides: dict[str, float] = {}
    set_categoricals: dict[str, str] = {}
    grid_categoricals: dict[str, list[str]] = {}
    grid_numerics: dict[str, list[float]] = {}
    _seen_vars: set[str] = set()

    for cond in conditions:
        if cond.var in _seen_vars:
            warnings.warn(
                f"Duplicate condition variable '{cond.var}' — "
                f"using last value. Each variable should appear "
                f"only once on the RHS.",
                UserWarning,
                stacklevel=5,
            )
        _seen_vars.add(cond.var)

        is_cat = bundle.factor_levels is not None and cond.var in bundle.factor_levels

        # Bracket contrast on condition: extract levels for grid
        if cond.contrast_expr is not None:
            grid_categoricals[cond.var] = _extract_contrast_levels(
                cond.contrast_expr,
                list(bundle.factor_levels[cond.var])
                if is_cat and bundle.factor_levels
                else [],
            )
            continue

        if cond.at_range is not None:
            # :range(n) → grid of n evenly-spaced values across data range
            col_vals = get_column_values(data, bundle, cond.var)
            grid_numerics[cond.var] = np.linspace(
                float(np.min(col_vals)),
                float(np.max(col_vals)),
                cond.at_range,
            ).tolist()

        elif cond.at_quantile is not None:
            # :quantile(n) → n quantile values
            col_vals = get_column_values(data, bundle, cond.var)
            n = cond.at_quantile
            probs = np.linspace(0.0, 1.0, n + 2)[1:-1]  # exclude 0 and 1
            grid_numerics[cond.var] = [float(v) for v in np.quantile(col_vals, probs)]

        elif cond.at_values is not None:
            # Explicit at-values: classify by type and count
            vals = cond.at_values
            if len(vals) == 1:
                v = vals[0]
                if isinstance(v, str):
                    set_categoricals[cond.var] = v
                elif isinstance(v, (int, float)):
                    at_overrides[cond.var] = float(v)
            else:
                # Multiple values
                if all(isinstance(v, str) for v in vals):
                    grid_categoricals[cond.var] = list(vals)
                else:
                    grid_numerics[cond.var] = [float(v) for v in vals]

        else:
            # Bare condition (no at-values, no range, no quantile)
            if is_cat:
                # Bare categorical → grid over all levels
                grid_categoricals[cond.var] = list(bundle.factor_levels[cond.var])  # type: ignore[index]
            else:
                # Bare continuous → no-op (marginalized at mean)
                warnings.warn(
                    f"Bare continuous condition '{cond.var}' has no effect "
                    f"(marginalized at mean). Did you mean "
                    f"'{cond.var}@value', '{cond.var}@[v1, v2]', "
                    f"or '{cond.var}@range(n)'?",
                    UserWarning,
                    stacklevel=5,
                )

    return ResolvedConditions(
        at_overrides=at_overrides,
        set_categoricals=set_categoricals,
        grid_categoricals=grid_categoricals,
        grid_numerics=grid_numerics,
        raw_at_overrides=dict(at_overrides),
    )


def combine_resolved(
    a: ResolvedConditions,
    b: ResolvedConditions,
) -> ResolvedConditions:
    """Merge two ResolvedConditions, with *b* taking precedence on conflicts.

    Args:
        a: First resolved conditions.
        b: Second resolved conditions (takes precedence).

    Returns:
        Merged ResolvedConditions.
    """
    return ResolvedConditions(
        at_overrides={**a.at_overrides, **b.at_overrides},
        set_categoricals={**a.set_categoricals, **b.set_categoricals},
        grid_categoricals={**a.grid_categoricals, **b.grid_categoricals},
        grid_numerics={**a.grid_numerics, **b.grid_numerics},
        raw_at_overrides={**a.raw_at_overrides, **b.raw_at_overrides},
    )


def get_column_values(
    data: pl.DataFrame,
    bundle: DataBundle,
    var: str,
) -> np.ndarray:
    """Extract a data column as a numpy array for range/quantile computation.

    Looks in the original ``data`` DataFrame first, falling back to the
    design matrix column if the variable name matches an X_names entry.

    Args:
        data: Original data DataFrame.
        bundle: DataBundle with design matrix.
        var: Variable name.

    Returns:
        1-D numpy array of column values.

    Raises:
        ValueError: If the variable cannot be found.
    """
    if var in data.columns:
        return data[var].drop_nulls().to_numpy().astype(float)
    # Fallback: check X_names for a continuous column
    X_names_list = list(bundle.X_names)
    if var in X_names_list:
        idx = X_names_list.index(var)
        return bundle.X[:, idx]
    raise ValueError(
        f"Cannot resolve data for condition variable '{var}'. "
        f"Not found in data or X_names."
    )


def _extract_contrast_levels(
    expr: ContrastExpr,
    all_levels: list[str],
) -> list[str]:
    """Extract the levels needed for a bracket contrast expression.

    If any operand is a wildcard, all factor levels are returned (since
    the wildcard will expand to all unmentioned levels at contrast-build
    time).  Otherwise, returns the unique explicitly-mentioned levels in
    order of first appearance.

    Args:
        expr: ContrastExpr from the parser.
        all_levels: All factor levels for this variable.

    Returns:
        List of level names to include in the grid.
    """
    for item in expr.items:
        if item.left.is_wildcard or item.right.is_wildcard:
            return all_levels

    mentioned: list[str] = []
    seen: set[str] = set()
    for item in expr.items:
        for lv in item.left.levels + item.right.levels:
            if lv not in seen:
                mentioned.append(lv)
                seen.add(lv)
    return mentioned
