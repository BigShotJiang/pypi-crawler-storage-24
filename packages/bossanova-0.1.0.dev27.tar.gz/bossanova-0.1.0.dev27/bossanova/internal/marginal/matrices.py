"""Contrast matrix builders for EMM comparisons.

Provides functions to build hypothesis contrast matrices used in marginal
effects computation. These matrices transform EMM vectors into contrast
estimates (e.g., pairwise differences, sequential differences, polynomial
trends).

Distinct from ``design.coding`` which builds *design matrix* coding matrices
for categorical variable encoding during model fitting.

Created by: absorbed from ``maths/inference/contrasts.py`` (zero consumers
outside marginal/) + ``poly_contrasts`` from ``contrasts.py``.
Consumed by: ``marginal/contrasts.py`` (apply_contrasts, apply_contrasts_grouped).
"""

from itertools import combinations

import numpy as np

__all__ = [
    "build_all_pairwise_matrix",
    "build_contrast_matrix",
    "build_helmert_matrix",
    "build_pairwise_matrix",
    "build_poly_matrix",
    "build_sequential_matrix",
    "build_sum_to_zero_matrix",
    "build_treatment_matrix",
    "compose_contrast_matrix",
    "get_contrast_labels",
]


# =============================================================================
# Contrast Matrix Builders
# =============================================================================


def build_pairwise_matrix(n_levels: int) -> np.ndarray:
    """Build (n-1) linearly independent pairwise contrasts.

    Creates "treatment-style" contrasts comparing each level to the
    first (reference) level. This produces n_levels - 1 contrasts that
    span the space of all pairwise differences.

    Args:
        n_levels: Number of EMM levels (factor levels).

    Returns:
        Contrast matrix of shape (n_levels - 1, n_levels).
        Row i compares level i+1 to level 0.

    Raises:
        ValueError: If n_levels < 1.

    Examples:
        >>> C = build_pairwise_matrix(3)
        >>> C
        array([[-1.,  1.,  0.],
               [-1.,  0.,  1.]])
    """
    if n_levels < 1:
        raise ValueError(f"n_levels must be >= 1, got {n_levels}")

    if n_levels == 1:
        return np.zeros((0, 1))

    C = np.zeros((n_levels - 1, n_levels))

    for i in range(n_levels - 1):
        C[i, 0] = -1
        C[i, i + 1] = 1

    return C


def build_all_pairwise_matrix(n_levels: int) -> np.ndarray:
    """Build all pairwise contrasts between EMM levels.

    Creates C(n, 2) = n*(n-1)/2 contrasts for all unique pairs.
    Unlike build_pairwise_matrix(), this includes all pairs,
    not just comparisons to the reference level.

    Args:
        n_levels: Number of EMM levels (factor levels).

    Returns:
        Contrast matrix of shape (n*(n-1)/2, n_levels).
        Each row compares two levels (level_j - level_i where j > i).

    Raises:
        ValueError: If n_levels < 1.

    Examples:
        >>> C = build_all_pairwise_matrix(3)
        >>> C
        array([[-1.,  1.,  0.],
               [-1.,  0.,  1.],
               [ 0., -1.,  1.]])
    """
    if n_levels < 1:
        raise ValueError(f"n_levels must be >= 1, got {n_levels}")

    if n_levels == 1:
        return np.zeros((0, 1))

    n_contrasts = n_levels * (n_levels - 1) // 2
    C = np.zeros((n_contrasts, n_levels))

    row = 0
    for i, j in combinations(range(n_levels), 2):
        C[row, i] = -1
        C[row, j] = 1
        row += 1

    return C


def build_sequential_matrix(n_levels: int) -> np.ndarray:
    """Build sequential (successive differences) contrasts.

    Creates n_levels - 1 contrasts comparing each level to the previous one.

    Args:
        n_levels: Number of EMM levels (factor levels).

    Returns:
        Contrast matrix of shape (n_levels - 1, n_levels).
        Row i compares level i+1 to level i.

    Raises:
        ValueError: If n_levels < 1.

    Examples:
        >>> C = build_sequential_matrix(3)
        >>> C
        array([[-1.,  1.,  0.],
               [ 0., -1.,  1.]])

        >>> C = build_sequential_matrix(4)
        >>> C
        array([[-1.,  1.,  0.,  0.],
               [ 0., -1.,  1.,  0.],
               [ 0.,  0., -1.,  1.]])
    """
    if n_levels < 1:
        raise ValueError(f"n_levels must be >= 1, got {n_levels}")

    if n_levels == 1:
        return np.zeros((0, 1))

    n_contrasts = n_levels - 1
    C = np.zeros((n_contrasts, n_levels))

    for i in range(n_contrasts):
        C[i, i] = -1
        C[i, i + 1] = 1

    return C


def build_sum_to_zero_matrix(n_levels: int) -> np.ndarray:
    """Build sum-to-zero contrasts (deviation coding).

    Creates contrasts comparing each level to the grand mean.

    Args:
        n_levels: Number of EMM levels.

    Returns:
        Contrast matrix of shape (n_levels - 1, n_levels).

    Raises:
        ValueError: If n_levels < 1.

    Examples:
        >>> C = build_sum_to_zero_matrix(3)
        >>> C
        array([[ 0.667, -0.333, -0.333],
               [-0.333,  0.667, -0.333]])
    """
    if n_levels < 1:
        raise ValueError(f"n_levels must be >= 1, got {n_levels}")

    if n_levels == 1:
        return np.zeros((0, 1))

    C = np.zeros((n_levels - 1, n_levels))

    for i in range(n_levels - 1):
        C[i, i] = (n_levels - 1) / n_levels
        for j in range(n_levels):
            if j != i:
                C[i, j] = -1 / n_levels

    return C


def build_treatment_matrix(n_levels: int, ref_idx: int = 0) -> np.ndarray:
    """Build treatment (Dunnett-style) contrasts against a reference level.

    Creates n_levels - 1 contrasts, each comparing one non-reference level
    to the specified reference level.

    Args:
        n_levels: Number of EMM levels (factor levels).
        ref_idx: Index of the reference level (0-based).

    Returns:
        Contrast matrix of shape (n_levels - 1, n_levels).

    Raises:
        ValueError: If n_levels < 1 or ref_idx out of range.

    Examples:
        >>> C = build_treatment_matrix(3, ref_idx=0)
        >>> C
        array([[-1.,  1.,  0.],
               [-1.,  0.,  1.]])

        >>> C = build_treatment_matrix(3, ref_idx=2)
        >>> C
        array([[ 1.,  0., -1.],
               [ 0.,  1., -1.]])
    """
    if n_levels < 1:
        raise ValueError(f"n_levels must be >= 1, got {n_levels}")
    if ref_idx < 0 or ref_idx >= n_levels:
        raise ValueError(f"ref_idx must be in [0, {n_levels - 1}], got {ref_idx}")

    if n_levels == 1:
        return np.zeros((0, 1))

    C = np.zeros((n_levels - 1, n_levels))
    row = 0
    for i in range(n_levels):
        if i == ref_idx:
            continue
        C[row, ref_idx] = -1
        C[row, i] = 1
        row += 1

    return C


def build_helmert_matrix(n_levels: int) -> np.ndarray:
    """Build Helmert contrasts (each level vs mean of previous levels).

    Creates n_levels - 1 contrasts where level k is compared to
    the mean of levels 0, 1, ..., k-1.

    Args:
        n_levels: Number of EMM levels (factor levels).

    Returns:
        Contrast matrix of shape (n_levels - 1, n_levels).

    Raises:
        ValueError: If n_levels < 1.

    Examples:
        >>> C = build_helmert_matrix(3)
        >>> C
        array([[-1. ,  1. ,  0. ],
               [-0.5, -0.5,  1. ]])

        >>> C = build_helmert_matrix(4)
        >>> C
        array([[-1.        ,  1.        ,  0.        ,  0.        ],
               [-0.5       , -0.5       ,  1.        ,  0.        ],
               [-0.33333333, -0.33333333, -0.33333333,  1.        ]])
    """
    if n_levels < 1:
        raise ValueError(f"n_levels must be >= 1, got {n_levels}")

    if n_levels == 1:
        return np.zeros((0, 1))

    C = np.zeros((n_levels - 1, n_levels))
    for k in range(1, n_levels):
        C[k - 1, :k] = -1.0 / k
        C[k - 1, k] = 1.0

    return C


def build_poly_matrix(n_levels: int, degree: int | None = None) -> np.ndarray:
    """Build orthogonal polynomial contrast matrix for EMMs.

    Creates orthogonal polynomial contrasts for ordered factors. Tests for
    linear, quadratic, cubic (etc.) trends across the factor levels.

    Args:
        n_levels: Number of factor levels. Must be >= 2.
        degree: Maximum polynomial degree. If None, uses n_levels - 1.

    Returns:
        Contrast matrix of shape (degree, n_levels).
        Rows are orthonormal polynomial basis vectors.

    Raises:
        ValueError: If n_levels < 2, degree > n_levels - 1, or degree < 1.

    Examples:
        >>> build_poly_matrix(5)  # 4x5 matrix
        >>> build_poly_matrix(5, degree=2)  # 2x5 matrix (linear + quadratic)
    """
    if n_levels < 2:
        raise ValueError(
            f"n_levels must be >= 2 for polynomial contrasts, got {n_levels}"
        )

    max_degree = n_levels - 1
    if degree is None:
        degree = max_degree
    elif degree > max_degree:
        raise ValueError(f"degree ({degree}) cannot exceed n_levels - 1 ({max_degree})")
    elif degree < 1:
        raise ValueError(f"degree must be >= 1, got {degree}")

    # Orthogonal polynomial contrasts via Gram-Schmidt
    x = np.arange(n_levels, dtype=float)
    x = x - x.mean()

    basis = np.zeros((degree, n_levels))

    for d in range(degree):
        poly = x ** (d + 1)

        # Gram-Schmidt: subtract projections onto previous basis vectors
        for prev_d in range(d):
            proj = np.dot(poly, basis[prev_d]) / np.dot(basis[prev_d], basis[prev_d])
            poly = poly - proj * basis[prev_d]

        # Subtract projection onto constant (mean = 0 constraint)
        poly = poly - poly.mean()

        # Normalize to unit length
        norm = np.linalg.norm(poly)
        if norm > 1e-10:
            poly = poly / norm

        basis[d] = poly

    return basis


def build_contrast_matrix(
    contrast_type: str | dict,
    levels: list,
    normalize: bool = False,
) -> np.ndarray:
    """Build a contrast matrix based on contrast type.

    Dispatcher function that builds the appropriate contrast matrix
    based on the contrast type specification.

    Args:
        contrast_type: Type of contrast:
            - "pairwise": All pairwise comparisons (k(k-1)/2 contrasts)
            - "trt.vs.ctrl" or "treatment": Compare each level to first level
            - "sequential": Successive differences (level[i+1] - level[i])
            - "sum": Each level vs grand mean (deviation coding)
            - "helmert": Each level vs mean of previous levels
            - dict: Custom contrasts with names as keys and weights as values
        levels: List of factor levels.
        normalize: If True, normalize custom contrasts to sum to 1/-1.

    Returns:
        Contrast matrix of shape (n_contrasts, n_levels).

    Raises:
        ValueError: If unknown contrast type.

    Examples:
        >>> build_contrast_matrix("pairwise", ["A", "B", "C"])
        array([[-1.,  1.,  0.],
               [-1.,  0.,  1.],
               [ 0., -1.,  1.]])
    """
    n_levels = len(levels)

    if isinstance(contrast_type, dict):
        contrasts = []
        for weights in contrast_type.values():
            if isinstance(weights, np.ndarray):
                c = weights.astype(float)
            else:
                c = np.array(weights, dtype=float)
            if normalize:
                l2_norm = np.linalg.norm(c)
                if l2_norm > 0:
                    c = c / l2_norm
            contrasts.append(c)
        return np.array(contrasts)

    elif contrast_type == "pairwise":
        return build_all_pairwise_matrix(n_levels)

    elif contrast_type in ("trt.vs.ctrl", "treatment"):
        return build_pairwise_matrix(n_levels)

    elif contrast_type == "sequential":
        return build_sequential_matrix(n_levels)

    elif contrast_type == "sum":
        return build_sum_to_zero_matrix(n_levels)

    elif contrast_type == "helmert":
        return build_helmert_matrix(n_levels)

    else:
        raise ValueError(
            f"Unknown contrast type: {contrast_type!r}\n\n"
            "Supported types:\n"
            "  - 'pairwise': All pairwise comparisons\n"
            "  - 'sequential': Successive differences (level[i+1] - level[i])\n"
            "  - 'trt.vs.ctrl' / 'treatment': Each level vs first level\n"
            "  - 'sum': Each level vs grand mean\n"
            "  - 'helmert': Each level vs mean of previous levels\n"
            "  - dict: Custom contrasts {name: weights}"
        )


# =============================================================================
# Composition and Utilities
# =============================================================================


def compose_contrast_matrix(
    C: np.ndarray,
    X_ref: np.ndarray,
) -> np.ndarray:
    """Compose contrast matrix with prediction matrix.

    Produces L_emm that maps coefficients directly to contrast estimates:
        L_emm @ beta = C @ (X_ref @ beta) = C @ EMMs

    Args:
        C: Contrast matrix of shape (n_contrasts, n_emms).
        X_ref: Prediction matrix of shape (n_emms, n_coef).

    Returns:
        Composed contrast matrix L_emm of shape (n_contrasts, n_coef).
    """
    return C @ X_ref


def get_contrast_labels(
    levels: list[str],
    contrast_type: str = "pairwise",
) -> list[str]:
    """Generate human-readable labels for contrasts.

    Args:
        levels: List of factor level names.
        contrast_type: Type of contrast ("pairwise", "all_pairwise", or "sequential").

    Returns:
        List of contrast labels like "B - A", "C - A", etc.

    Examples:
        >>> get_contrast_labels(["A", "B", "C"], "pairwise")
        ['B - A', 'C - A']
        >>> get_contrast_labels(["A", "B", "C"], "all_pairwise")
        ['B - A', 'C - A', 'C - B']
    """
    n = len(levels)

    if contrast_type == "pairwise":
        return [f"{levels[i + 1]} - {levels[0]}" for i in range(n - 1)]

    elif contrast_type == "all_pairwise":
        return [f"{levels[j]} - {levels[i]}" for i, j in combinations(range(n), 2)]

    elif contrast_type == "sequential":
        return [f"{levels[i + 1]} - {levels[i]}" for i in range(n - 1)]

    else:
        raise ValueError(f"Unknown contrast_type: {contrast_type}")
