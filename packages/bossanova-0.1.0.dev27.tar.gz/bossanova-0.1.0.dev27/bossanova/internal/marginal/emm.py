"""Estimated marginal means computation.

This module provides EMM computation for categorical focal variables.

Internal exports:
    compute_emm: Compute estimated marginal means at grid points
"""

from __future__ import annotations

import warnings
from typing import TYPE_CHECKING

import numpy as np
import polars as pl

from bossanova.internal.containers.builders.state import build_mee_state
from bossanova.internal.containers.schemas import Col
from bossanova.internal.containers.structs.marginal import MeeState
from bossanova.internal.design.reference import (
    build_counterfactual_design_matrices,
    build_reference_design_matrix,
)
from bossanova.internal.marginal.factors import get_factor_levels
from bossanova.internal.marginal.validation import validate_focal_var

if TYPE_CHECKING:
    from bossanova.internal.containers.structs.data import DataBundle
    from bossanova.internal.containers.structs.specs import ModelSpec
    from bossanova.internal.containers.structs.fit import FitState
    from bossanova.internal.marginal.conditions import ResolvedConditions

__all__ = [
    "compute_conditional_emm",
    "compute_emm",
    "compute_emm_crossed",
]


def compute_emm(
    bundle: "DataBundle",
    fit: "FitState",
    focal_var: str,
    explore_formula: str,
    *,
    levels: list[str] | None = None,
    at_overrides: dict[str, float] | None = None,
    set_categoricals: dict[str, str] | None = None,
    spec: object | None = None,
    how: str = "mem",
    effect_scale: str = "link",
) -> MeeState:
    """Compute estimated marginal means for a categorical focal variable.

    Supports two averaging methods via the ``how`` parameter:

    - ``"mem"`` (default): Marginal Estimated Mean.  Balanced reference grid
      (emmeans-style).  Predictions at a grid where covariates are at their
      means.
    - ``"ame"``: Average Marginal Effect / g-computation.  For each focal
      level, sets every observation to that level and averages the resulting
      predictions.  Preserves the observed covariate distribution.

    For linear models (identity link), both approaches give identical results.
    For GLMs (non-identity link), they diverge because
    ``mean(g⁻¹(Xᵢβ)) ≠ g⁻¹(mean(Xᵢ) · β)``.

    Args:
        bundle: DataBundle with model data and metadata. Used to extract:
            - X: design matrix for computing covariate means
            - X_names: column names to identify variable types
            - factor_levels: level metadata for categorical variables
        fit: FitState with fitted coefficients (fit.coef array).
        focal_var: Name of the categorical variable to compute EMMs for.
        explore_formula: The explore formula string (for result metadata).
        levels: Optional list of levels to compute EMMs for. If None,
            uses all levels from bundle.factor_levels.
        at_overrides: Optional dict of ``{variable: value}`` to fix specific
            covariates at given values instead of their means. Used for
            conditioning (e.g., ``cyl ~ wt@[3.0]`` fixes wt at 3.0).
        set_categoricals: Optional dict mapping non-focal categorical variable
            names to specific levels to pin them at (instead of marginalizing
            at column means). E.g. ``{"Ethnicity": "Asian"}``.
        spec: ModelSpec with link/family info (needed for effect_scale="response").
        how: Averaging method: ``"mem"`` for balanced reference grid
            (emmeans-style), ``"ame"`` for g-computation over observed data.
        effect_scale: Scale of estimates: ``"link"`` or ``"response"``.

    Returns:
        MeeState with grid of levels and their estimated means.

    Raises:
        ValueError: If focal_var not found in bundle.factor_levels.

    Examples:
        Compute EMMs with default (reference grid) averaging::

            mee = compute_emm(bundle, fit, "treatment", "treatment")

        G-computation averaging for a logistic regression::

            mee = compute_emm(bundle, fit, "treatment", "treatment",
                              spec=spec, how="ame", effect_scale="response")

    Note:
        For ``how="ame"`` with ``effect_scale="response"`` on a non-identity
        link, confidence intervals use the response-scale delta method
        (symmetric CIs) rather than the link-scale back-transformation
        (asymmetric CIs) used by ``how="mem"``.
    """
    validate_focal_var(bundle, focal_var)

    # Get levels from bundle or use provided
    if levels is None:
        levels = get_factor_levels(bundle, focal_var)

    # Apply at-value overrides for conditioning
    X_means = bundle.X.mean(axis=0).copy()
    if at_overrides:
        X_names_list = list(bundle.X_names)
        for var_name, value in at_overrides.items():
            if var_name in X_names_list:
                idx = X_names_list.index(var_name)
                X_means[idx] = value

        unmatched = set(at_overrides) - set(X_names_list)
        if unmatched:
            warnings.warn(
                f"at-override keys {unmatched} don't match any model column; "
                f"overrides ignored. If the variable has a transform "
                f"(e.g. center(x)), use the raw name with "
                f"inverse_transforms=True (default).",
                stacklevel=4,
            )

    # G-computation path: how="ame" with non-identity link on response scale.
    # For link scale or identity link, the two approaches are mathematically
    # equivalent, so we fall through to the reference grid path for efficiency.
    use_gcomp = (
        how == "ame"
        and effect_scale == "response"
        and spec is not None
        and spec.link != "identity"
    )

    if use_gcomp:
        return _compute_emm_gcomp(
            bundle=bundle,
            fit=fit,
            focal_var=focal_var,
            explore_formula=explore_formula,
            levels=levels,
            spec=spec,
            at_overrides=at_overrides,
            set_categoricals=set_categoricals,
        )

    # Reference grid path (how="mem" or equivalent cases)
    X_ref = build_reference_design_matrix(
        X_names=bundle.X_names,
        focal_var=focal_var,
        levels=levels,
        X_means=X_means,
        set_categoricals=set_categoricals,
    )

    # Compute predictions: EMM = X_ref @ coef
    estimates_link = X_ref @ fit.coef
    estimates = estimates_link
    L_matrix = X_ref

    # Track link-scale L_matrix for CI back-transformation
    link_name: str | None = None
    L_matrix_link: np.ndarray | None = None

    if effect_scale == "response" and spec is not None and spec.link != "identity":
        from bossanova.internal.maths.family.links import (
            apply_link_inverse,
            apply_link_inverse_deriv,
        )

        estimates = np.asarray(apply_link_inverse(spec.link, estimates_link))
        # Delta method: L_data = diag(dμ/dη) @ X_ref
        d = np.asarray(apply_link_inverse_deriv(spec.link, estimates_link))
        L_matrix = d[:, np.newaxis] * X_ref
        # Store link-scale L_matrix for CI back-transformation at infer() time
        link_name = spec.link
        L_matrix_link = X_ref

    # Create grid DataFrame with conditioning columns first
    grid = _build_emm_grid(focal_var, levels, at_overrides, set_categoricals)

    return build_mee_state(
        grid=grid,
        estimate=estimates,
        explore_formula=explore_formula,
        focal_var=focal_var,
        mee_type="means",
        how="mem",
        effect_scale=effect_scale,
        L_matrix=L_matrix,
        link=link_name,
        L_matrix_link=L_matrix_link,
    )


def _compute_emm_gcomp(
    bundle: "DataBundle",
    fit: "FitState",
    focal_var: str,
    explore_formula: str,
    levels: list[str],
    spec: object,
    *,
    at_overrides: dict[str, float] | None = None,
    set_categoricals: dict[str, str] | None = None,
) -> MeeState:
    """G-computation EMMs: average counterfactual predictions over observed data.

    For each focal level k:
        1. Build counterfactual X_cf_k (all N rows, focal set to level k)
        2. η_k = X_cf_k @ β  (N linear predictors)
        3. pred_k = g⁻¹(η_k)  (N response-scale predictions)
        4. emm_k = mean(pred_k)
        5. L_k = mean(dμ/dη(η_k)[:, None] * X_cf_k, axis=0)  (delta method)

    Args:
        bundle: DataBundle with model data and design matrix.
        fit: FitState with fitted coefficients.
        focal_var: Name of the categorical focal variable.
        explore_formula: Explore formula string for metadata.
        levels: Focal variable levels to compute EMMs for.
        spec: ModelSpec with link function info.
        at_overrides: Optional covariate overrides (applied before
            counterfactual construction).
        set_categoricals: Optional non-focal categorical pins.

    Returns:
        MeeState with g-computation estimates and response-scale L_matrix.
    """
    from bossanova.internal.maths.family.links import (
        apply_link_inverse,
        apply_link_inverse_deriv,
    )

    X = bundle.X

    # Apply at_overrides: replace column values in X before counterfactual
    if at_overrides:
        X = X.copy()
        X_names_list = list(bundle.X_names)
        for var_name, value in at_overrides.items():
            if var_name in X_names_list:
                idx = X_names_list.index(var_name)
                X[:, idx] = value

    # Apply set_categoricals: pin non-focal categoricals in X
    if set_categoricals:
        from bossanova.internal.design.names import parse_design_column_name

        X = X if at_overrides else X.copy()  # ensure we have a copy
        for j, name in enumerate(bundle.X_names):
            info = parse_design_column_name(name)
            if info.column_type == "categorical" and info.base_term in set_categoricals:
                X[:, j] = 1.0 if info.level == set_categoricals[info.base_term] else 0.0

    # Build counterfactual design matrices
    cf_matrices = build_counterfactual_design_matrices(
        X=X,
        X_names=bundle.X_names,
        focal_var=focal_var,
        levels=levels,
    )

    # Vectorized g-computation: batch all K counterfactual matmuls
    X_all = np.stack(cf_matrices)  # (K, N, p)
    eta_all = np.einsum("knp,p->kn", X_all, fit.coef)  # (K, N)
    pred_all = np.asarray(apply_link_inverse(spec.link, eta_all))  # (K, N)
    estimates = pred_all.mean(axis=1)  # (K,)

    # Delta method: L_k = mean(dμ/dη(η_k)[:, None] * X_cf_k, axis=0)
    d_all = np.asarray(apply_link_inverse_deriv(spec.link, eta_all))  # (K, N)
    L_matrix = np.einsum("knp,kn->kp", X_all, d_all) / X_all.shape[1]  # (K, p)

    # Build grid DataFrame
    grid = _build_emm_grid(focal_var, levels, at_overrides, set_categoricals)

    # G-computation: no link/L_matrix_link — inference uses response-scale
    # delta method directly (symmetric CIs on response scale).
    return build_mee_state(
        grid=grid,
        estimate=estimates,
        explore_formula=explore_formula,
        focal_var=focal_var,
        mee_type="means",
        how="ame",
        effect_scale="response",
        L_matrix=L_matrix,
        link=None,
        L_matrix_link=None,
    )


def _build_emm_grid(
    focal_var: str,
    levels: list[str],
    at_overrides: dict[str, float] | None,
    set_categoricals: dict[str, str] | None,
) -> pl.DataFrame:
    """Build the grid DataFrame for EMM results.

    Args:
        focal_var: Name of the focal variable.
        levels: Focal variable levels.
        at_overrides: Optional covariate overrides to include as columns.
        set_categoricals: Optional categorical pins to include as columns.

    Returns:
        Polars DataFrame with condition columns first, then focal column.
    """
    grid = pl.DataFrame({focal_var: levels})

    if set_categoricals:
        for cond_var, cond_level in set_categoricals.items():
            grid = grid.with_columns(pl.lit(cond_level).alias(cond_var))

    if at_overrides:
        for cond_var, cond_val in at_overrides.items():
            grid = grid.with_columns(pl.lit(cond_val).alias(cond_var))

    # Reorder: condition columns first, then focal
    cond_cols = list(set_categoricals or {}) + list(at_overrides or {})
    if cond_cols:
        grid = grid.select(cond_cols + [c for c in grid.columns if c not in cond_cols])

    return grid


def compute_conditional_emm(
    bundle: "DataBundle",
    fit: "FitState",
    focal_var: str,
    explore_formula: str,
    *,
    spec: object,
    varying_offsets: object,
    grouping_var: str,
    effect_scale: str = "link",
    levels: list[str] | None = None,
    at_overrides: dict[str, float] | None = None,
    set_categoricals: dict[str, str] | None = None,
) -> MeeState:
    """Compute per-group conditional EMMs incorporating intercept BLUPs.

    For each group g and each focal level, the conditional EMM is:
        η_g = X_ref_row @ β + b_intercept_g  (+ other BLUP contributions)

    When effect_scale="response": estimates = g⁻¹(η_g).

    Args:
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        focal_var: Name of the categorical variable.
        explore_formula: The explore formula string.
        spec: ModelSpec with link function info.
        varying_offsets: VaryingState with BLUPs per group.
        grouping_var: Name of the grouping variable.
        effect_scale: Scale of estimates: ``"link"`` or ``"response"``.
        levels: Optional list of focal levels.
        at_overrides: Optional covariate overrides.
        set_categoricals: Optional dict pinning non-focal categoricals.

    Returns:
        MeeState with per-(level, group) estimates.
    """
    from bossanova.internal.containers.structs.mixed import VaryingState

    validate_focal_var(bundle, focal_var)

    if levels is None:
        levels = get_factor_levels(bundle, focal_var)

    # Build reference X matrix as usual
    X_means = bundle.X.mean(axis=0).copy()
    if at_overrides:
        X_names_list = list(bundle.X_names)
        for var_name, value in at_overrides.items():
            if var_name in X_names_list:
                i = X_names_list.index(var_name)
                X_means[i] = value

    X_ref = build_reference_design_matrix(
        X_names=bundle.X_names,
        focal_var=focal_var,
        levels=levels,
        X_means=X_means,
        set_categoricals=set_categoricals,
    )

    assert isinstance(varying_offsets, VaryingState)
    n_groups = varying_offsets.n_groups

    # Compute per-group BLUP offsets: vectorized over all groups at once
    b_intercept = varying_offsets.effects.get("Intercept", np.zeros(n_groups))
    blup_offsets = b_intercept.copy()  # (G,)
    X_names_list = list(bundle.X_names)
    for effect_name, blups in varying_offsets.effects.items():
        if effect_name == "Intercept":
            continue
        if effect_name in X_names_list:
            cov_idx = X_names_list.index(effect_name)
            blup_offsets += blups * X_means[cov_idx]  # (G,) broadcast

    # Vectorized per-level, per-group linear predictor
    base_link = X_ref @ fit.coef  # (K,)
    # estimates_link[lev, g] = base_link[lev] + blup_offsets[g]
    estimates_link_2d = base_link[:, np.newaxis] + blup_offsets[np.newaxis, :]  # (K, G)
    estimates_link = estimates_link_2d.ravel()  # matches lev*n_groups+g indexing

    # L_matrix: each X_ref[lev] repeated n_groups times
    L_matrix = np.repeat(X_ref, n_groups, axis=0)  # (K*G, p)

    estimates = estimates_link
    link_name: str | None = None
    L_matrix_link: np.ndarray | None = None

    if effect_scale == "response" and spec.link != "identity":
        from bossanova.internal.maths.family.links import (
            apply_link_inverse,
            apply_link_inverse_deriv,
        )

        estimates = np.asarray(apply_link_inverse(spec.link, estimates_link))
        d = np.asarray(apply_link_inverse_deriv(spec.link, estimates_link))
        link_name = spec.link
        L_matrix_link = L_matrix.copy()
        L_matrix = d[:, np.newaxis] * L_matrix

    # Build crossed grid: focal_var × grouping_var
    group_levels = varying_offsets.grid[Col.LEVEL].to_list()
    grid_focal = []
    grid_group = []
    for lev in levels:
        for gl in group_levels:
            grid_focal.append(lev)
            grid_group.append(gl)

    grid = pl.DataFrame({focal_var: grid_focal, grouping_var: grid_group})
    if at_overrides:
        for cond_var, cond_val in at_overrides.items():
            grid = grid.with_columns(pl.lit(cond_val).alias(cond_var))
        cond_cols = list(at_overrides.keys())
        grid = grid.select(cond_cols + [c for c in grid.columns if c not in cond_cols])

    return build_mee_state(
        grid=grid,
        estimate=estimates,
        explore_formula=explore_formula,
        focal_var=focal_var,
        mee_type="means",
        effect_scale=effect_scale,
        L_matrix=L_matrix,
        link=link_name,
        L_matrix_link=L_matrix_link,
    )


def compute_emm_crossed(
    bundle: DataBundle,
    fit: FitState,
    focal_var: str,
    *,
    resolved: ResolvedConditions,
    levels: list[str] | None = None,
    spec: ModelSpec | None = None,
    effect_scale: str = "link",
    how: str = "mem",
) -> MeeState:
    """Compute crossed EMMs over focal levels x condition grid.

    Builds a Cartesian product of focal levels with all grid conditions,
    computing one EMM row per combination.

    Supports two averaging methods via ``how``:

    - ``"mem"``: Reference grid at covariate means (emmeans-style).
    - ``"ame"``: G-computation over observed data rows with counterfactual
      treatment assignment per combo.

    Args:
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        focal_var: Name of the categorical focal variable.
        resolved: ResolvedConditions with grid and scalar conditions.
        levels: Optional subset of focal levels to include (e.g. from
            ``treatment@[A, B]``). If None, all levels are used.
        spec: ModelSpec with link info (for effect_scale="response").
        effect_scale: Scale of estimates: ``"link"`` or ``"response"``.
        how: Averaging method: ``"mem"`` or ``"ame"``.

    Returns:
        MeeState with ``n_focal x n_grid`` rows and condition columns.
    """
    from itertools import product as cartesian

    validate_focal_var(bundle, focal_var)
    focal_levels = get_factor_levels(bundle, focal_var)
    if levels is not None:
        focal_levels = [lv for lv in focal_levels if lv in levels]

    # Collect grid variables and their levels/values
    grid_vars: list[str] = []
    grid_vals: list[list[object]] = []
    for var, levels in resolved.grid_categoricals.items():
        grid_vars.append(var)
        grid_vals.append(levels)
    for var, values in resolved.grid_numerics.items():
        grid_vars.append(var)
        grid_vals.append(values)

    grid_combos = list(cartesian(*grid_vals)) if grid_vals else [()]

    # Route to g-computation when how="ame" + non-identity link + response
    use_gcomp = (
        how == "ame"
        and effect_scale == "response"
        and spec is not None
        and spec.link != "identity"
    )

    if use_gcomp:
        return _compute_emm_crossed_gcomp(
            bundle=bundle,
            fit=fit,
            focal_var=focal_var,
            focal_levels=focal_levels,
            grid_vars=grid_vars,
            grid_combos=grid_combos,
            resolved=resolved,
            spec=spec,
        )

    # MEM path: reference grid at covariate means
    return _compute_emm_crossed_mem(
        bundle=bundle,
        fit=fit,
        focal_var=focal_var,
        focal_levels=focal_levels,
        grid_vars=grid_vars,
        grid_combos=grid_combos,
        resolved=resolved,
        spec=spec,
        effect_scale=effect_scale,
    )


def _compute_emm_crossed_mem(
    bundle: DataBundle,
    fit: FitState,
    focal_var: str,
    focal_levels: list[str],
    grid_vars: list[str],
    grid_combos: list[tuple[object, ...]],
    resolved: ResolvedConditions,
    spec: ModelSpec | None,
    effect_scale: str,
) -> MeeState:
    """MEM path for crossed EMMs: reference grid at covariate means.

    Args:
        bundle: DataBundle with model data and metadata.
        fit: FitState with fitted coefficients.
        focal_var: Name of the categorical focal variable.
        focal_levels: Levels of the focal variable.
        grid_vars: Condition variable names.
        grid_combos: Cartesian product of condition levels/values.
        resolved: ResolvedConditions with scalar overrides.
        spec: ModelSpec with link info.
        effect_scale: ``"link"`` or ``"response"``.

    Returns:
        MeeState with MEM estimates.
    """
    from bossanova.internal.design.reference import build_reference_row

    X_means = bundle.X.mean(axis=0).copy()
    X_names_list = list(bundle.X_names)

    # Apply scalar numeric overrides to X_means
    for var_name, value in resolved.at_overrides.items():
        if var_name in X_names_list:
            X_means[X_names_list.index(var_name)] = value

    if resolved.at_overrides:
        unmatched = set(resolved.at_overrides) - set(X_names_list)
        if unmatched:
            warnings.warn(
                f"at-override keys {unmatched} don't match any model column; "
                f"overrides ignored. If the variable has a transform "
                f"(e.g. center(x)), use the raw name with "
                f"inverse_transforms=True (default).",
                stacklevel=4,
            )

    n_focal = len(focal_levels)
    n_total = n_focal * len(grid_combos)
    p = len(bundle.X_names)
    X_ref = np.zeros((n_total, p), dtype=np.float64)

    grid_data: dict[str, list[object]] = {focal_var: []}
    for gv in grid_vars:
        grid_data[gv] = []

    row_idx = 0
    for combo in grid_combos:
        combo_cats = dict(resolved.set_categoricals)
        row_X_means = X_means.copy()
        for i, gv in enumerate(grid_vars):
            val = combo[i]
            if isinstance(val, str):
                combo_cats[gv] = val
            elif gv in X_names_list:
                row_X_means[X_names_list.index(gv)] = float(val)

        for focal_level in focal_levels:
            X_ref[row_idx] = build_reference_row(
                bundle.X_names,
                focal_var,
                focal_level,
                row_X_means,
                set_categoricals=combo_cats or None,
            )
            grid_data[focal_var].append(focal_level)
            for i, gv in enumerate(grid_vars):
                grid_data[gv].append(combo[i])
            row_idx += 1

    # Compute estimates
    estimates_link = X_ref @ fit.coef
    estimates, L_matrix = estimates_link, X_ref
    link_name: str | None = None
    L_matrix_link: np.ndarray | None = None
    if effect_scale == "response" and spec is not None and spec.link != "identity":
        from bossanova.internal.maths.family.links import (
            apply_link_inverse,
            apply_link_inverse_deriv,
        )

        estimates = np.asarray(apply_link_inverse(spec.link, estimates_link))
        d = np.asarray(apply_link_inverse_deriv(spec.link, estimates_link))
        link_name = spec.link
        L_matrix_link = X_ref.copy()
        L_matrix = d[:, np.newaxis] * X_ref

    grid = pl.DataFrame(grid_data)

    # Add scalar-pinned conditions as constant columns (set_categoricals
    # and at_overrides are applied to the design matrix but must also
    # appear in the output grid so users can see the pinned values).
    if resolved.set_categoricals:
        for cond_var, cond_level in resolved.set_categoricals.items():
            if cond_var not in grid.columns:
                grid = grid.with_columns(pl.lit(cond_level).alias(cond_var))
    if resolved.at_overrides:
        for cond_var, cond_val in resolved.at_overrides.items():
            if cond_var not in grid.columns:
                grid = grid.with_columns(pl.lit(cond_val).alias(cond_var))

    # Reorder: grid_vars + pinned conditions first, then focal
    pin_cols = list(resolved.set_categoricals) + list(resolved.at_overrides)
    leading = grid_vars + [c for c in pin_cols if c not in grid_vars]
    if leading:
        grid = grid.select(leading + [c for c in grid.columns if c not in leading])

    cond_str = " ~ " + ", ".join(grid_vars) if grid_vars else ""
    return build_mee_state(
        grid=grid,
        estimate=estimates,
        explore_formula=f"{focal_var}{cond_str}",
        focal_var=focal_var,
        mee_type="means",
        effect_scale=effect_scale,
        how="mem",
        L_matrix=L_matrix,
        link=link_name,
        L_matrix_link=L_matrix_link,
    )


def _compute_emm_crossed_gcomp(
    bundle: DataBundle,
    fit: FitState,
    focal_var: str,
    focal_levels: list[str],
    grid_vars: list[str],
    grid_combos: list[tuple[object, ...]],
    resolved: ResolvedConditions,
    spec: ModelSpec,
) -> MeeState:
    """G-computation path for crossed EMMs over observed data.

    For each (focal_level, grid_combo) combination:
        1. Build counterfactual X: set focal to level, pin combo conditions
        2. eta = X_cf @ coef -> pred = g^-1(eta) -> estimate = mean(pred)
        3. L_row = mean(dmu/deta[:, None] * X_cf, axis=0)  (delta method)

    Args:
        bundle: DataBundle with model data and design matrix.
        fit: FitState with fitted coefficients.
        focal_var: Name of the categorical focal variable.
        focal_levels: Levels of the focal variable.
        grid_vars: Condition variable names.
        grid_combos: Cartesian product of condition levels/values.
        resolved: ResolvedConditions with scalar overrides.
        spec: ModelSpec with link info.

    Returns:
        MeeState with g-computation estimates on response scale.
    """
    from bossanova.internal.design.names import parse_design_column_name
    from bossanova.internal.maths.family.links import (
        apply_link_inverse,
        apply_link_inverse_deriv,
    )

    X = bundle.X.copy()
    X_names_list = list(bundle.X_names)

    # Apply scalar at_overrides to X
    for var_name, value in resolved.at_overrides.items():
        if var_name in X_names_list:
            X[:, X_names_list.index(var_name)] = value

    # Apply scalar set_categoricals to X
    for j, name in enumerate(bundle.X_names):
        info = parse_design_column_name(name)
        if (
            info.column_type == "categorical"
            and info.base_term in resolved.set_categoricals
        ):
            X[:, j] = (
                1.0 if info.level == resolved.set_categoricals[info.base_term] else 0.0
            )

    # Build counterfactual X per focal level (all N rows, focal set to level)
    cf_matrices = build_counterfactual_design_matrices(
        X=X,
        X_names=bundle.X_names,
        focal_var=focal_var,
        levels=focal_levels,
    )

    # Pre-build all C*K patched counterfactual matrices, then batch matmul
    all_matrices: list[np.ndarray] = []
    grid_data: dict[str, list[object]] = {focal_var: []}
    for gv in grid_vars:
        grid_data[gv] = []

    for combo in grid_combos:
        for k, X_cf_k in enumerate(cf_matrices):
            X_combo = X_cf_k.copy()

            # Apply grid combo conditions (O(p) column patching, not O(N*p))
            for i, gv in enumerate(grid_vars):
                val = combo[i]
                if isinstance(val, str):
                    for j, name in enumerate(bundle.X_names):
                        info = parse_design_column_name(name)
                        if info.column_type == "categorical" and info.base_term == gv:
                            X_combo[:, j] = 1.0 if info.level == val else 0.0
                elif gv in X_names_list:
                    X_combo[:, X_names_list.index(gv)] = float(val)

            all_matrices.append(X_combo)
            grid_data[focal_var].append(focal_levels[k])
            for i, gv in enumerate(grid_vars):
                grid_data[gv].append(combo[i])

    # Batched matmul + link computation over all C*K matrices
    X_all = np.stack(all_matrices)  # (C*K, N, p)
    eta_all = np.einsum("mnp,p->mn", X_all, fit.coef)  # (C*K, N)
    pred_all = np.asarray(apply_link_inverse(spec.link, eta_all))  # (C*K, N)
    estimates = pred_all.mean(axis=1)  # (C*K,)

    d_all = np.asarray(apply_link_inverse_deriv(spec.link, eta_all))  # (C*K, N)
    L_matrix = np.einsum("mnp,mn->mp", X_all, d_all) / X_all.shape[1]  # (C*K, p)

    grid = pl.DataFrame(grid_data)

    # Add scalar-pinned conditions as constant columns (mirrors MEM path)
    if resolved.set_categoricals:
        for cond_var, cond_level in resolved.set_categoricals.items():
            if cond_var not in grid.columns:
                grid = grid.with_columns(pl.lit(cond_level).alias(cond_var))
    if resolved.at_overrides:
        for cond_var, cond_val in resolved.at_overrides.items():
            if cond_var not in grid.columns:
                grid = grid.with_columns(pl.lit(cond_val).alias(cond_var))

    pin_cols = list(resolved.set_categoricals) + list(resolved.at_overrides)
    leading = grid_vars + [c for c in pin_cols if c not in grid_vars]
    if leading:
        grid = grid.select(leading + [c for c in grid.columns if c not in leading])

    cond_str = " ~ " + ", ".join(grid_vars) if grid_vars else ""
    return build_mee_state(
        grid=grid,
        estimate=estimates,
        explore_formula=f"{focal_var}{cond_str}",
        focal_var=focal_var,
        mee_type="means",
        how="ame",
        effect_scale="response",
        L_matrix=L_matrix,
        link=None,
        L_matrix_link=None,
    )
