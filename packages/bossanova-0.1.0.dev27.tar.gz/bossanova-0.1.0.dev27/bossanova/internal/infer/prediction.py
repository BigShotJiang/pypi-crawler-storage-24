"""Prediction inference dispatch.

Routes prediction inference requests to the appropriate method: asymptotic
(delta method), bootstrap, or cross-validation.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import numpy as np

    from bossanova.internal.containers.structs import (
        CVState,
        DataBundle,
        FitState,
        ModelSpec,
        PredictionState,
    )

__all__ = [
    "dispatch_prediction_inference",
]


def dispatch_prediction_inference(
    *,
    how: str,
    pred: PredictionState,
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    conf_level: float,
    n_boot: int = 1000,
    ci_type: str = "percentile",
    seed: int | None = None,
    k: int | str = 10,
    holdout_group_ids: np.ndarray | None = None,
) -> tuple[PredictionState, CVState | None]:
    """Dispatch prediction inference to the appropriate method.

    Args:
        how: Inference method (``"asymp"``, ``"boot"``, ``"cv"``).
        pred: Current prediction state.
        spec: Model specification.
        bundle: Data bundle with design matrices.
        fit: Fit state with coefficients and vcov.
        conf_level: Confidence level for intervals.
        n_boot: Number of bootstrap samples (default: 1000).
        ci_type: Bootstrap CI type (default: ``"percentile"``).
        seed: Random seed for reproducibility.
        k: Number of CV folds or ``"loo"`` (default: 10).

    Returns:
        Tuple of (augmented PredictionState, CVState or None). CVState is
        populated only for ``how="cv"``.

    Raises:
        NotImplementedError: For unsupported inference methods.
        ValueError: If ``k`` is invalid for cross-validation.
    """
    if how == "cv":
        from attrs import evolve

        from bossanova.internal.infer.cv import compute_cv_metrics

        if k != "loo" and (not isinstance(k, int) or k < 2):
            raise ValueError("k must be an integer >= 2 or 'loo' for cross-validation")
        cv = compute_cv_metrics(
            spec,
            bundle,
            k=k,
            seed=seed,
            holdout_group_ids=holdout_group_ids,
        )
        augmented = evolve(
            pred,
            cv_fitted=cv.oos_predictions,
            cv_residual=cv.oos_residuals,
            cv_fold=cv.fold_assignments,
        )
        return augmented, cv

    if how == "boot":
        from bossanova.internal.infer.bootstrap import (
            compute_prediction_bootstrap,
        )

        return compute_prediction_bootstrap(
            spec=spec,
            bundle=bundle,
            pred=pred,
            conf_level=conf_level,
            n_boot=n_boot,
            ci_type=ci_type,
            seed=seed,
        ), None

    if how != "asymp":
        raise NotImplementedError(
            f"Inference method '{how}' not yet implemented for predictions. "
            "Only 'asymp' (asymptotic), 'boot' (bootstrap), and 'cv' (cross-validation) "
            "are supported."
        )

    from bossanova.internal.infer.asymptotic import (
        compute_prediction_asymptotic,
    )

    return compute_prediction_asymptotic(
        pred=pred,
        bundle=bundle,
        fit=fit,
        spec=spec,
        conf_level=conf_level,
    ), None
