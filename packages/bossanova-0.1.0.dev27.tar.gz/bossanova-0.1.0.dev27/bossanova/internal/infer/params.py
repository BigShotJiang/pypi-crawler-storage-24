"""Parameter inference dispatch.

Routes parameter inference requests to the appropriate method: asymptotic
(Wald-based), bootstrap, permutation, or cross-validation.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import polars as pl

    from bossanova.internal.containers.structs import (
        DataBundle,
        FitState,
        InferenceState,
        ModelSpec,
    )

__all__ = [
    "dispatch_params_inference",
]


def dispatch_params_inference(
    *,
    how: str,
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    data: pl.DataFrame | None,
    conf_level: float,
    errors: str = "iid",
    null: float = 0.0,
    alternative: str = "two-sided",
    link_override: str | None = None,
    n_boot: int = 1000,
    n_perm: int = 1000,
    ci_type: str = "bca",
    seed: int | None = None,
    n_jobs: int = 1,
    save_resamples: bool = True,
    k: int | str = 10,
) -> InferenceState:
    """Dispatch parameter inference to the appropriate method.

    Args:
        how: Inference method (``"asymp"``, ``"boot"``, ``"perm"``, ``"cv"``).
        spec: Model specification.
        bundle: Data bundle with design matrices.
        fit: Fit state with coefficients and vcov.
        data: Original data DataFrame (needed for CV and robust SEs).
        conf_level: Confidence level for intervals.
        errors: Error type for robust SEs (e.g. ``"HC3"``, ``"hetero"``,
            ``"unequal_var"``).
        null: Null hypothesis value.
        alternative: Alternative hypothesis direction.
        link_override: Non-default link function override for CV (None uses spec).
        n_boot: Number of bootstrap samples (default: 1000).
        n_perm: Number of permutation samples (default: 1000).
        ci_type: Bootstrap CI type (``"bca"``, ``"percentile"``, ``"basic"``).
        seed: Random seed for reproducibility.
        n_jobs: Number of parallel jobs (default: 1).
        save_resamples: Whether to store raw resample arrays (default: True).
        k: Number of CV folds or ``"loo"`` (default: 10).

    Returns:
        InferenceState with SE, statistics, p-values, and CIs.

    Raises:
        NotImplementedError: For unsupported inference methods.
    """
    if how == "boot":
        if spec.has_random_effects:
            from bossanova.internal.infer.bootstrap import (
                compute_params_bootstrap_mixed,
            )

            return compute_params_bootstrap_mixed(
                spec=spec,
                bundle=bundle,
                fit=fit,
                conf_level=conf_level,
                n_boot=n_boot,
                ci_type=ci_type,
                seed=seed,
                save_resamples=save_resamples,
                n_jobs=n_jobs,
                null=null,
                alternative=alternative,
            )
        else:
            from bossanova.internal.infer.bootstrap import (
                compute_params_bootstrap,
            )

            return compute_params_bootstrap(
                spec=spec,
                bundle=bundle,
                fit=fit,
                conf_level=conf_level,
                n_boot=n_boot,
                ci_type=ci_type,
                seed=seed,
                save_resamples=save_resamples,
                n_jobs=n_jobs,
                null=null,
                alternative=alternative,
            )

    if how == "perm":
        from bossanova.internal.infer.permutation import (
            compute_params_permutation,
        )

        return compute_params_permutation(
            spec=spec,
            bundle=bundle,
            fit=fit,
            conf_level=conf_level,
            n_perm=n_perm,
            seed=seed,
            save_resamples=save_resamples,
            null=null,
            alternative=alternative,
        )

    if how != "asymp":
        raise NotImplementedError(
            f"Inference method '{how}' not yet implemented. "
            "Only 'asymp' (asymptotic), 'boot' (bootstrap), and 'perm' (permutation) are supported."
        )

    from bossanova.internal.infer.asymptotic import (
        compute_params_asymptotic,
    )

    return compute_params_asymptotic(
        spec=spec,
        bundle=bundle,
        fit=fit,
        conf_level=conf_level,
        errors=errors,
        data=data,
        null=null,
        alternative=alternative,
    )
