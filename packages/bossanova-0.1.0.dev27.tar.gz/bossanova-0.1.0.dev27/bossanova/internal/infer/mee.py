"""Marginal effects inference dispatch.

Routes MEE inference requests to the appropriate method: asymptotic
(delta method), bootstrap, or permutation.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from attrs import evolve

if TYPE_CHECKING:
    import polars as pl

    from bossanova.internal.containers.structs import (
        DataBundle,
        FitState,
        MeeState,
        ModelSpec,
    )

__all__ = [
    "dispatch_mee_inference",
]


def dispatch_mee_inference(
    *,
    how: str,
    mee: MeeState,
    spec: ModelSpec,
    bundle: DataBundle,
    fit: FitState,
    data: pl.DataFrame,
    conf_level: float,
    errors: str = "iid",
    null: float = 0.0,
    alternative: str = "two-sided",
    n_boot: int = 1000,
    n_perm: int = 1000,
    ci_type: str = "bca",
    seed: int | None = None,
    save_resamples: bool = True,
) -> "tuple[MeeState, np.ndarray | None]":
    """Dispatch marginal effects inference to the appropriate method.

    Args:
        how: Inference method (``"asymp"``, ``"boot"``, ``"perm"``).
        mee: Current MeeState from explore().
        spec: Model specification.
        bundle: Data bundle with design matrices.
        fit: Fit state with coefficients and vcov.
        data: Original data as Polars DataFrame.
        conf_level: Confidence level for intervals.
        errors: Error type for robust SEs (e.g. ``"HC3"``, ``"hetero"``,
            ``"unequal_var"``).
        null: Null hypothesis value.
        alternative: Alternative hypothesis direction.
        n_boot: Number of bootstrap samples (default: 1000).
        n_perm: Number of permutation samples (default: 1000).
        ci_type: Bootstrap CI type (``"bca"``, ``"percentile"``, ``"basic"``).
        seed: Random seed for reproducibility.
        save_resamples: Whether to store raw resample arrays (default: True).

    Returns:
        Tuple of (MeeState augmented with inference, raw resample array
        or None). The second element is non-None only for boot/perm
        with save_resamples=True.

    Raises:
        NotImplementedError: For unsupported inference methods.
    """

    if how == "perm":
        from bossanova.internal.infer.permutation import (
            compute_mee_permutation,
        )
        from bossanova.internal.marginal.inference import (
            compute_mee_se,
        )

        se_obs = compute_mee_se(mee, bundle, fit, data)
        augmented, samples = compute_mee_permutation(
            spec=spec,
            bundle=bundle,
            fit=fit,
            mee=mee,
            data=data,
            conf_level=conf_level,
            se_obs=se_obs,
            n_perm=n_perm,
            seed=seed,
            null=null,
            alternative=alternative,
            save_resamples=save_resamples,
        )
        return evolve(augmented, inference_method="perm"), samples

    if how == "boot":
        from bossanova.internal.infer.bootstrap import (
            compute_mee_bootstrap,
        )

        augmented, samples = compute_mee_bootstrap(
            spec=spec,
            bundle=bundle,
            mee=mee,
            data=data,
            conf_level=conf_level,
            n_boot=n_boot,
            ci_type=ci_type,
            seed=seed,
            null=null,
            alternative=alternative,
            save_resamples=save_resamples,
        )
        return evolve(augmented, inference_method="boot"), samples

    if how != "asymp":
        raise NotImplementedError(
            f"Inference method '{how}' not yet implemented for MEE. "
            "Only 'asymp' (asymptotic), 'boot' (bootstrap), and 'perm' (permutation) "
            "are currently supported."
        )

    from bossanova.internal.infer.asymptotic import (
        resolve_df,
        resolve_vcov,
        resolve_welch,
    )
    from bossanova.internal.marginal.inference import (
        compute_mee_inference,
        compute_mee_inference_fallback,
    )

    if errors == "unequal_var":
        vcov, df_per_coef = resolve_welch(spec, bundle, fit, data)

        if mee.L_matrix is not None:
            # Compute per-contrast Satterthwaite df from L matrix rows
            import polars as pl

            from bossanova.internal.maths.inference.welch import (
                compute_cell_info,
                extract_factors_from_formula,
                compute_welch_satterthwaite_df_for_L,
            )

            factors = extract_factors_from_formula(spec.formula, data)
            valid_data = data.filter(pl.Series(bundle.valid_mask))
            cell_info = compute_cell_info(fit.residuals, valid_data, factors)
            df_resid: float | np.ndarray | None = compute_welch_satterthwaite_df_for_L(
                mee.L_matrix,
                bundle.X,
                cell_info,
            )
        else:
            # Fallback path (no L_matrix): conservative scalar
            df_resid = float(np.min(df_per_coef))
    elif errors and errors not in ("iid", "auto"):
        vcov = resolve_vcov(spec, bundle, fit, errors)
        df_resid = resolve_df(spec, bundle, fit, errors, data)
    else:
        vcov = fit.vcov
        df_resid = resolve_df(spec, bundle, fit, errors, data)

    # For Gaussian mixed models with L_matrix, always compute Satterthwaite
    # df per EMM row. The per-coefficient df from resolve_df() has shape (p,)
    # which doesn't match the number of EMM estimates — we need one df per
    # row of L_matrix instead.
    if (
        spec.has_random_effects
        and spec.family == "gaussian"
        and mee.L_matrix is not None
        and fit.theta is not None
    ):
        from bossanova.internal.infer.satterthwaite_emm import (
            compute_satterthwaite_emm_df,
        )

        df_resid = compute_satterthwaite_emm_df(
            bundle=bundle, fit=fit, spec=spec, L=mee.L_matrix
        )

    if mee.L_matrix is not None:
        augmented = compute_mee_inference(
            mee=mee,
            vcov=vcov,
            df_resid=df_resid,
            conf_level=conf_level,
            null=null,
            alternative=alternative,
        )
        return evolve(augmented, inference_method="asymp"), None

    augmented = compute_mee_inference_fallback(
        mee=mee,
        bundle=bundle,
        fit=fit,
        data=data,
        df_resid=df_resid,
        conf_level=conf_level,
        null=null,
        alternative=alternative,
    )
    return evolve(augmented, inference_method="asymp"), None
