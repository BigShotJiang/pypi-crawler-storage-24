"""Internal resampling operations.

Provides bootstrap procedures for bossanova models.

Module layout:
- ``core.py``          — index generation, p-values, CI methods
- ``common.py``        — shared bootstrap execution loop, NaN handling
- ``results.py``       — result container (BootstrapResult)
- ``simulate.py``      — family-specific response simulation
- ``lm_operators.py``  — hat-matrix operator for LM
- ``lmer.py``          — LMER parametric bootstrap
- ``glmer.py``         — GLMER parametric bootstrap
"""

from bossanova.internal.infer.resample.core import (
    BCa_MIN_NBOOT,
    compute_bootstrap_ci_basic,
    compute_bootstrap_ci_bca,
    compute_bootstrap_ci_percentile,
    compute_pvalues,
    generate_bootstrap_indices,
    generate_kfold_indices,
    generate_loo_indices,
    generate_permutation_indices,
)
from bossanova.internal.infer.resample.glmer import glmer_bootstrap
from bossanova.internal.infer.resample.glm_operators import (
    compute_batched_glm_bootstrap,
)
from bossanova.internal.infer.resample.lm_operators import (
    build_lm_coefficient_operator,
    compute_batched_ols_bootstrap,
)
from bossanova.internal.infer.resample.lmer import lmer_bootstrap
from bossanova.internal.infer.resample.results import BootstrapResult
from bossanova.internal.infer.resample.simulate import simulate_response

__all__ = [
    "BCa_MIN_NBOOT",
    "BootstrapResult",
    "build_lm_coefficient_operator",
    "compute_batched_glm_bootstrap",
    "compute_batched_ols_bootstrap",
    "compute_bootstrap_ci_basic",
    "compute_bootstrap_ci_bca",
    "compute_bootstrap_ci_percentile",
    "compute_pvalues",
    "generate_bootstrap_indices",
    "generate_kfold_indices",
    "generate_loo_indices",
    "generate_permutation_indices",
    "glmer_bootstrap",
    "lmer_bootstrap",
    "simulate_response",
]
