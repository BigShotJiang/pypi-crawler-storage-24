"""Linear model coefficient operator (hat-matrix trick).

Provides ``build_lm_coefficient_operator`` which pre-computes the expensive
factorization of (X'X) once and returns a lightweight function that maps
any response vector Y to OLS coefficients. Used by hypothesis property
tests (BS.4) and the generic bootstrap engine.
"""

from typing import Any, Callable, Literal

import numpy as np
import scipy.linalg as la
from bossanova.internal.maths.backend import get_backend

# Type alias for arrays (works with both JAX and NumPy)
Array = Any

__all__ = [
    "Array",
    "build_lm_coefficient_operator",
    "compute_batched_ols_bootstrap",
]


# =============================================================================
# Helpers
# =============================================================================


def _ensure_2d(xp: Any, Y: Array) -> tuple[Array, bool]:
    """Convert Y to 2d, returning (Y_2d, was_1d)."""
    is_1d = Y.ndim == 1
    if is_1d:
        Y = Y[:, xp.newaxis]
    return Y, is_1d


def _squeeze_if_1d(xp: Any, coef: Array, is_1d: bool) -> Array:
    """Squeeze trailing dim if input was 1d."""
    if is_1d:
        return xp.squeeze(coef, axis=-1)
    return coef


def _make_cholesky_operator(
    xp: Any, X: Array, cho_solve: Callable[..., Array]
) -> Callable[[Array], Array]:
    """Build a Cholesky-based coefficient operator.

    Args:
        xp: Array module (numpy or jax.numpy).
        X: Design matrix, shape (n, p).
        cho_solve: Cholesky solve function (scipy or jax.scipy).

    Returns:
        Function mapping Y -> coefficients.
    """
    XtX = X.T @ X
    L = xp.linalg.cholesky(XtX)

    def apply(Y: Array) -> Array:
        Y = xp.asarray(Y)
        Y, is_1d = _ensure_2d(xp, Y)
        coef = cho_solve((L, True), X.T @ Y)
        return _squeeze_if_1d(xp, coef, is_1d)

    return apply


def _make_qr_operator(
    xp: Any,
    X: Array,
    qr_fn: Callable[..., tuple[Array, Array]],
    solve_tri: Callable[..., Array],
) -> Callable[[Array], Array]:
    """Build a QR-based coefficient operator.

    Args:
        xp: Array module (numpy or jax.numpy).
        X: Design matrix, shape (n, p).
        qr_fn: QR decomposition function.
        solve_tri: Triangular solve function.

    Returns:
        Function mapping Y -> coefficients.
    """
    Q, R = qr_fn(X)

    def apply(Y: Array) -> Array:
        Y = xp.asarray(Y)
        Y, is_1d = _ensure_2d(xp, Y)
        coef = solve_tri(R, Q.T @ Y, lower=False)
        return _squeeze_if_1d(xp, coef, is_1d)

    return apply


# =============================================================================
# Coefficient Operator (Hat-Matrix Trick)
# =============================================================================


def build_lm_coefficient_operator(
    X: Array,
    method: Literal["cholesky", "qr"] = "cholesky",
) -> Callable[[Array], Array]:
    """Create reusable linear operator Y -> coefficients.

    Precomputes and caches the expensive factorization. Returns a function
    that maps Y -> coefficients.

    This implements the "hat-matrix trick" for efficient permutation testing:
    For fixed design matrix X, coefficients are a linear map from Y -> beta_hat:
    beta_hat = (X'X)^-1 X'y. We precompute the factorization of (X'X) once
    and reuse it for all permuted/bootstrapped Y values.

    Args:
        X: Design matrix, shape (n, p).
        method: Factorization method.
            - 'cholesky': Uses Cholesky decomposition of X'X (faster, more stable).
            - 'qr': Uses QR decomposition of X (handles rank deficiency better).

    Returns:
        Function that maps Y (shape [n] or [n, m]) to coefficients.

    Examples:
        ```python
        X = np.array([[1, 2], [1, 3], [1, 4]])
        operator = build_lm_coefficient_operator(X)
        y = np.array([5, 8, 11])
        coef = operator(y)
        ```
    """
    backend = get_backend()

    if backend == "jax":
        import jax.numpy as jnp
        import jax.scipy.linalg as jsp

        X_arr = jnp.asarray(X)
        xp = jnp

        if method == "cholesky":
            return _make_cholesky_operator(xp, X_arr, jsp.cho_solve)
        elif method == "qr":
            return _make_qr_operator(xp, X_arr, jnp.linalg.qr, jsp.solve_triangular)
        else:
            raise ValueError(f"method must be 'cholesky' or 'qr', got {method}")

    else:
        X_arr = np.asarray(X)
        xp = np

        if method == "cholesky":
            return _make_cholesky_operator(xp, X_arr, la.cho_solve)
        elif method == "qr":
            return _make_qr_operator(
                xp,
                X_arr,
                lambda x: la.qr(x, mode="economic"),
                la.solve_triangular,
            )
        else:
            raise ValueError(f"method must be 'cholesky' or 'qr', got {method}")


# =============================================================================
# JIT-Cached OLS from Indices (Bootstrap Fast Path)
# =============================================================================

_ols_from_indices_cache: dict[str, Any] = {}


def _make_ols_core_fn(ops: Any) -> Callable:
    """Create raw OLS solver that indexes into X and y.

    The returned function takes ``(indices, X, y)`` and computes OLS
    coefficients via Cholesky factorization of ``X[indices]``. This is
    the inner kernel for ``compute_batched_ols_bootstrap`` — it gets
    vmap'd and then JIT-compiled over the bootstrap index array.

    On JAX, Cholesky returns NaN (not an exception) for singular input,
    so rank-deficient bootstrap samples naturally produce NaN coefficients.

    Args:
        ops: Backend ArrayOps (numpy or JAX).

    Returns:
        Raw function ``(indices, X, y) -> coef`` (not JIT-compiled).
    """
    xp = ops.np

    def _core(indices: Array, X: Array, y: Array) -> Array:
        X_b = X[indices]
        y_b = y[indices]
        XtX = X_b.T @ X_b
        Xty = X_b.T @ y_b
        L = xp.linalg.cholesky(XtX)
        # Solve L @ z = Xty, then L.T @ coef = z
        z = ops.solve_triangular(L, Xty, lower=True)
        coef = ops.solve_triangular(L.T, z, lower=False)
        return coef

    return _core


def _get_batched_ols_fn() -> Callable:
    """Get JIT-compiled vmapped OLS function for current backend.

    Composes ``jit(vmap(core), donate_argnums=(0,))`` so that the
    per-chunk index buffer is donated to XLA for memory reuse. The
    ``X`` and ``y`` arguments (args 1-2) are broadcast across the
    batch dimension and NOT donated.

    Returns:
        Cached JIT-compiled vmapped function
        ``(idx_chunk, X, y) -> coef_chunk``.
    """
    from bossanova.internal.maths.backend import get_ops

    backend = get_backend()
    if backend not in _ols_from_indices_cache:
        ops = get_ops()
        core = _make_ols_core_fn(ops)
        vmapped = ops.vmap(core, in_axes=(0, None, None))
        _ols_from_indices_cache[backend] = ops.jit(vmapped, donate_argnums=(0,))
    return _ols_from_indices_cache[backend]


def compute_batched_ols_bootstrap(
    boot_indices: np.ndarray,
    X: np.ndarray,
    y: np.ndarray,
    chunk_size: int | None = None,
) -> np.ndarray:
    """Compute bootstrap OLS coefficients using chunked vmap.

    For LM models (gaussian family, identity link, no random effects),
    each bootstrap replicate is an independent OLS solve. This function
    batches those solves via ``ops.vmap`` — on JAX, this compiles to
    a single XLA program; on NumPy, it degrades to a loop+stack
    (equivalent to sequential but without Python overhead from
    ``fit_model``).

    Memory safety is ensured by chunking: ``compute_batch_size``
    determines how many solves to batch at once based on available
    memory.

    Args:
        boot_indices: Bootstrap index array, shape ``(n_boot, n)``.
        X: Design matrix, shape ``(n, p)``.
        y: Response vector, shape ``(n,)``.
        chunk_size: Number of bootstrap samples per chunk. If ``None``,
            computed automatically from available memory.

    Returns:
        Coefficient array, shape ``(n_boot, p)``.
    """
    from bossanova.internal.maths.backend import get_ops
    from bossanova.internal.maths.batching import compute_batch_size

    ops = get_ops()
    n_boot = boot_indices.shape[0]
    n, p = X.shape

    # Compute chunk size if not provided
    if chunk_size is None:
        # Memory per bootstrap sample: X_b(n*p) + y_b(n) + XtX(p*p) + L(p*p) + Xty(p) + coef(p)
        bytes_per_item = (n * p + n + 2 * p * p + 2 * p) * 8
        chunk_size = compute_batch_size(n_items=n_boot, bytes_per_item=bytes_per_item)

    # Get JIT-compiled vmapped OLS function (with donate_argnums for idx_chunk)
    batched_ols = _get_batched_ols_fn()

    # Convert to backend arrays
    X_arr = ops.asarray(X)
    y_arr = ops.asarray(y)

    # Process in chunks — idx_chunk buffer is donated to XLA each iteration
    results = []
    for start in range(0, n_boot, chunk_size):
        end = min(start + chunk_size, n_boot)
        idx_chunk = ops.asarray(boot_indices[start:end])
        chunk_coefs = batched_ols(idx_chunk, X_arr, y_arr)
        results.append(np.asarray(chunk_coefs))

    return np.concatenate(results, axis=0)
