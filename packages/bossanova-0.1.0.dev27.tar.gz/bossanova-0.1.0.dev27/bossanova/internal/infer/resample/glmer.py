"""GLMER bootstrap with full PIRLS refitting.

This module provides parametric bootstrap for generalized linear mixed-effects
models (GLMER). Each bootstrap iteration simulates a new response from the
fitted model and refits via PIRLS optimization.

Key characteristics:
- Sequential loop (cannot vmap due to scipy.sparse operations)
- Parametric bootstrap: simulate random effects b* ~ N(0, LL'), then response
- Full PIRLS refit per sample (expensive but necessary)
- Optional parallelization via joblib
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

import numpy as np
import scipy.sparse as sp

# Type alias for arrays (works with both JAX and NumPy)
if TYPE_CHECKING:
    from jax import Array

from bossanova.internal.maths.family import Family
from bossanova.internal.maths.rng import RNG
from bossanova.internal.maths.solvers.glmer import fit_glmm_pirls
from bossanova.internal.maths.solvers.lambda_builder import (
    build_lambda_sparse,
    build_lambda_template,
)
from bossanova.internal.infer.resample.common import (
    collect_boot_samples,
    compute_bootstrap_ci,
    run_bootstrap_iterations,
)
from bossanova.internal.infer.resample.simulate import simulate_response
from bossanova.internal.infer.resample.results import BootstrapResult

__all__ = [
    "glmer_bootstrap",
    "glmer_bootstrap_single_iteration",
    "simulate_from_glmer",
]


# =============================================================================
# Simulation
# =============================================================================


def simulate_from_glmer(
    rng: RNG,
    X: np.ndarray,
    Z: sp.csc_matrix,
    beta: np.ndarray,
    theta: np.ndarray,
    family: Family,
    n_groups_list: list[int],
    re_structure: str,
    metadata: dict,
    weights: np.ndarray | None = None,
) -> "Array":
    """Simulate response from fitted GLMER model.

    Algorithm:
    1. Simulate random effects: b* ~ N(0, LL')
    2. Compute linear predictor: eta* = X beta_hat + Z b*
    3. Compute mean: mu* = g^{-1}(eta*)
    4. Simulate response from family distribution

    Args:
        rng: RNG object for random number generation.
        X: Fixed effects design matrix (n, p).
        Z: Random effects design matrix (sparse CSC, n, q).
        beta: Fixed effects coefficients (p,).
        theta: Variance parameters (n_theta,).
        family: GLM family object.
        n_groups_list: List of group sizes per RE term.
        re_structure: Random effects structure metadata.
        metadata: Additional metadata for Lambda construction.
        weights: Prior observation weights (only for binomial trials).

    Returns:
        Simulated response (n,) as numpy/JAX array.
    """
    # Build Lambda from theta
    Lambda = build_lambda_sparse(theta, n_groups_list, re_structure, metadata)

    # Simulate spherical random effects: u* ~ N(0, I_q)
    q = Lambda.shape[0]
    u_star = rng.normal(shape=(q,))

    # Transform to original scale: b* = Lu*
    b_star = Lambda @ u_star

    # Compute linear predictor: eta* = X beta + Z b*
    Zb = Z @ b_star
    if sp.issparse(Zb):
        Zb = Zb.toarray().ravel()
    else:
        Zb = np.asarray(Zb).ravel()
    eta_star = X @ beta + Zb

    # Compute mean: mu* = g^{-1}(eta*)
    mu_star = np.asarray(family.link_inverse(eta_star))

    # Simulate response from family distribution
    _, rng_response = rng.split_one()
    y_star = simulate_response(
        rng_response,
        mu_star,
        family,
        dispersion=1.0,  # GLMMs have fixed dispersion
        weights=weights,
    )

    return y_star


# =============================================================================
# Single Iteration (standalone for joblib)
# =============================================================================


def glmer_bootstrap_single_iteration(
    rng: RNG,
    X_np: np.ndarray,
    Z_sparse: sp.csc_matrix,
    beta_np: np.ndarray,
    theta_np: np.ndarray,
    family: Family,
    n_groups_list: list[int],
    re_structure: str,
    metadata: dict,
    weights_np: np.ndarray | None,
    boot_type: str,
    max_iter: int,
    tol: float,
    max_outer_iter: int,
    nAGQ: int,
    p: int,
    lambda_template: object | None = None,
) -> np.ndarray:
    """Execute a single GLMER bootstrap iteration.

    This is a standalone function (not a closure) to enable joblib parallelization.

    Args:
        rng: RNG object for random number generation.
        X_np: Fixed effects design matrix as numpy array (n, p).
        Z_sparse: Random effects design matrix as sparse CSC.
        beta_np: Fixed effects as numpy array (p,).
        theta_np: Variance parameters as numpy array.
        family: GLM family object.
        n_groups_list: List of group sizes per RE term.
        re_structure: Random effects structure metadata.
        metadata: Additional metadata for Lambda construction.
        weights_np: Prior weights as numpy array or None.
        boot_type: Only ``"parametric"`` is supported.
        max_iter: Maximum PIRLS iterations.
        tol: Convergence tolerance.
        max_outer_iter: Maximum BOBYQA iterations.
        nAGQ: Number of adaptive Gauss-Hermite quadrature points (0 or 1).
        p: Number of fixed effects coefficients.
        lambda_template: Pre-built Lambda template for efficient updates.

    Returns:
        Bootstrap coefficient estimates (p,), or NaN array if failed.
    """
    try:
        # Parametric bootstrap: simulate from fitted model
        y_boot_jax = simulate_from_glmer(
            rng,
            X_np,
            Z_sparse,
            beta_np,
            theta_np,
            family,
            n_groups_list,
            re_structure,
            metadata,
            weights_np,
        )
        y_boot = np.asarray(y_boot_jax)

        # Refit model with simulated y
        result = fit_glmm_pirls(
            X=X_np,
            Z=Z_sparse,
            y=y_boot,
            family=family,
            n_groups_list=n_groups_list,
            re_structure=re_structure,
            metadata=metadata,
            prior_weights=weights_np,
            max_outer_iter=max_outer_iter,
            pirls_max_iter=max_iter * 4,
            pirls_tol=tol * 10,
            verbose=False,
            two_stage=(nAGQ >= 1),
            lambda_template=lambda_template,
        )

        # Check convergence and extract coefficients
        if result["converged"]:
            return result["beta"]
        else:
            return np.full(p, np.nan)

    except Exception:
        return np.full(p, np.nan)


# =============================================================================
# Main Entry Point
# =============================================================================


def glmer_bootstrap(
    X: "Array",
    Z: sp.csc_matrix | "Array",
    y: "Array",
    X_names: list[str],
    theta: "Array",
    beta: "Array",
    family: Family,
    n_groups_list: list[int],
    re_structure: str,
    metadata: dict,
    weights: "Array | None" = None,
    n_boot: int = 999,
    seed: int | None = None,
    boot_type: Literal["parametric"] = "parametric",
    ci_type: Literal["percentile", "basic", "bca"] = "percentile",
    level: float = 0.95,
    max_iter: int = 25,
    tol: float = 1e-8,
    max_outer_iter: int = 10000,
    nAGQ: int = 0,
    verbose: bool = False,
    n_jobs: int = 1,
) -> BootstrapResult:
    """Bootstrap inference for GLMER coefficients.

    Each bootstrap iteration requires full PIRLS optimization.
    Supports parallel execution via joblib.

    Uses parametric bootstrap: simulate b* ~ N(0, LL'), compute
    eta* = X beta + Z b*, then y* from the family distribution and refit.
    This is the standard approach for mixed models, matching R's
    ``lme4::bootMer(type="parametric")``.

    Note:
        Only parametric bootstrap is supported for mixed models, matching
        R/lme4. Residual and case bootstrap are not applicable because the
        residual structure involves multiple variance components (within-group
        and between-group). Parametric bootstrap properly accounts for this
        hierarchical structure by simulating new random effects.

    Args:
        X: Fixed effects design matrix, shape (n, p).
        Z: Random effects design matrix, sparse CSC or dense array (n, q).
        y: Response vector, shape (n,).
        X_names: Fixed effects coefficient names.
        theta: Variance parameters from fitted model (n_theta,).
        beta: Fixed effects from fitted model (p,).
        family: GLM family object (binomial or poisson).
        n_groups_list: List of group sizes per RE term.
        re_structure: Random effects structure metadata.
        metadata: Additional metadata for Lambda construction.
        weights: Prior observation weights (n,) or None.
            For binomial: number of trials per observation.
        n_boot: Number of bootstrap samples.
        seed: Random seed for reproducibility.
        boot_type: Type of bootstrap. Only ``"parametric"`` is supported.
        ci_type: Confidence interval type: "percentile", "basic", or "bca".
        level: Confidence level (e.g., 0.95 for 95% CI).
        max_iter: Maximum PIRLS iterations per refit.
        tol: Convergence tolerance for PIRLS.
        max_outer_iter: Maximum BOBYQA iterations for theta optimization.
        nAGQ: Number of adaptive Gauss-Hermite quadrature points. Default 0
            (Stage 1 only) for faster bootstrap. Use 1 for full two-stage
            optimization matching lme4 default.
        verbose: If True, show tqdm progress bar.
        n_jobs: Number of parallel jobs. Default 1 (sequential). Use -1 for all cores.

    Returns:
        BootstrapResult with observed stats, bootstrap samples, and CIs.

    Raises:
        ValueError: If boot_type is not ``"parametric"``.
        ValueError: If ci_type is not "percentile", "basic", or "bca".
        RuntimeError: If all bootstrap iterations fail to converge.

    Examples:
        ```python
        from bossanova.internal.maths.family import binomial
        family = binomial()
        result = glmer_bootstrap(
            X, Z, y, ["Intercept", "x"],
            theta=theta_hat, beta=beta_hat,
            family=family, n_groups_list=[15],
            re_structure=[{"type": "intercept"}],
            metadata={}, n_boot=999
        )
        print(result.ci)
        ```
    """
    # Input validation
    if boot_type != "parametric":
        raise ValueError(
            f"boot_type must be 'parametric' for mixed models, got {boot_type!r}"
        )
    if ci_type == "bca":
        raise ValueError(
            "BCa confidence intervals are not supported for mixed models. "
            "Use ci_type='percentile' or ci_type='basic' instead."
        )
    if ci_type not in ("percentile", "basic"):
        raise ValueError(
            f"ci_type must be 'percentile' or 'basic' for mixed models, got {ci_type}"
        )

    # Convert to appropriate types
    X_np = np.asarray(X)
    theta_np = np.asarray(theta)
    beta_np = np.asarray(beta)
    n, p = X_np.shape

    # Convert Z to sparse CSC if needed
    if not sp.isspmatrix_csc(Z):
        Z_sparse = sp.csc_matrix(np.asarray(Z))
    else:
        Z_sparse = Z

    if weights is not None:
        weights_np = np.asarray(weights)
    else:
        weights_np = None

    rng = RNG.from_seed(seed)

    # Observed coefficients (from input)
    coef_obs = np.asarray(beta_np)

    # Generate all RNGs upfront
    rngs = rng.split(n_boot)

    # Pre-build lambda template for efficient updates
    lambda_template = build_lambda_template(n_groups_list, re_structure, metadata)

    # Shared iteration arguments
    iter_kwargs = {
        "X_np": X_np,
        "Z_sparse": Z_sparse,
        "beta_np": beta_np,
        "theta_np": theta_np,
        "family": family,
        "n_groups_list": n_groups_list,
        "re_structure": re_structure,
        "metadata": metadata,
        "weights_np": weights_np,
        "boot_type": boot_type,
        "max_iter": max_iter,
        "tol": tol,
        "max_outer_iter": max_outer_iter,
        "nAGQ": nAGQ,
        "p": p,
        "lambda_template": lambda_template,
    }

    # Run iterations using shared execution loop
    boot_samples_list = run_bootstrap_iterations(
        iteration_fn=glmer_bootstrap_single_iteration,
        rngs=rngs,
        n_boot=n_boot,
        iter_kwargs=iter_kwargs,
        n_jobs=n_jobs,
        verbose=verbose,
    )

    # Collect samples, check failures
    boot_samples, valid_mask, n_failed = collect_boot_samples(boot_samples_list, n_boot)
    boot_samples_valid = boot_samples[valid_mask]
    n_valid = int(np.sum(valid_mask))

    # Check if we have enough valid samples
    if n_valid == 0:
        raise RuntimeError(
            "All bootstrap iterations failed to converge. "
            "Cannot compute confidence intervals. "
            f"Consider increasing max_outer_iter (currently {max_outer_iter}) "
            f"or max_iter (currently {max_iter})."
        )
    elif n_valid < 50:
        import warnings

        warnings.warn(
            f"Only {n_valid}/{n_boot} bootstrap iterations succeeded. "
            f"Confidence intervals may be unreliable. "
            "Consider increasing max_outer_iter or max_iter.",
            RuntimeWarning,
        )

    ci_lower, ci_upper = compute_bootstrap_ci(
        coef_obs, boot_samples_valid, ci_type, level
    )

    return BootstrapResult(
        observed=coef_obs,
        boot_samples=boot_samples,
        ci_lower=ci_lower,
        ci_upper=ci_upper,
        param_names=X_names,
        n_boot=n_boot,
        ci_type=ci_type,
        level=level,
        term_types=["fixef"] * p,
    )
