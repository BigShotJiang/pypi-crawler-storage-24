"""Response simulation for parametric bootstrap.

Provides family-specific response simulation used by GLMER and LMER
parametric bootstrap procedures. Each function simulates observations
from a fitted mean vector using the appropriate distribution.
"""

from typing import Any

import numpy as np

from bossanova.internal.maths.family import Family
from bossanova.internal.maths.rng import RNG

# Type alias for arrays (works with both JAX and NumPy)
Array = Any

__all__ = [
    "simulate_binomial",
    "simulate_gaussian",
    "simulate_poisson",
    "simulate_response",
]


def simulate_gaussian(
    rng: RNG,
    mu: Array,
    dispersion: float,
) -> Array:
    """Simulate Gaussian response from fitted values.

    Args:
        rng: RNG object for random sampling.
        mu: Fitted values (n,).
        dispersion: Dispersion parameter (phi). For Gaussian family, phi = sigma^2.

    Returns:
        Simulated response (n,).
    """
    mu_np = np.asarray(mu)
    sigma = np.sqrt(dispersion)
    noise = rng.normal(shape=mu_np.shape)
    return mu_np + sigma * np.asarray(noise)


def simulate_binomial(
    rng: RNG,
    mu: Array,
    weights: Array | None = None,
) -> Array:
    """Simulate binomial response from fitted probabilities.

    For standard Bernoulli trials (weights=1), samples 0/1.
    For binomial with n trials, samples proportion.

    Args:
        rng: RNG object for random sampling.
        mu: Fitted probabilities (n,), must be in (0, 1).
        weights: Number of trials per observation. If None, uses 1 (Bernoulli).

    Returns:
        Simulated response (n,) as proportions in [0, 1].
    """
    mu_np = np.asarray(mu)
    n = mu_np.shape[0]

    # Sample counts from binomial using uniform comparison (Bernoulli case)
    u = rng.uniform(shape=(n,))
    counts = (np.asarray(u) < mu_np).astype(np.float64)

    return counts


def simulate_poisson(
    rng: RNG,
    mu: Array,
) -> Array:
    """Simulate Poisson response from fitted rates.

    Args:
        rng: RNG object for random sampling.
        mu: Fitted rates (n,), must be positive.

    Returns:
        Simulated response (n,) as counts.
    """
    mu_np = np.asarray(mu)
    return np.asarray(rng.poisson(mu_np)).astype(np.float64)


def simulate_response(
    rng: RNG,
    mu: Array,
    family: Family,
    dispersion: float = 1.0,
    weights: Array | None = None,
) -> Array:
    """Simulate response from GLM fitted values.

    Dispatches to family-specific simulation functions.

    Args:
        rng: RNG object for random sampling.
        mu: Fitted values on response scale (n,).
        family: GLM family object.
        dispersion: Dispersion parameter (phi). For Gaussian family,
            dispersion = sigma^2. For other families, typically fixed at 1.0.
        weights: Prior weights (only used for binomial trials).

    Returns:
        Simulated response (n,).

    Raises:
        ValueError: If family is not supported.
    """
    if family.name == "gaussian":
        return simulate_gaussian(rng, mu, dispersion)
    elif family.name == "binomial":
        return simulate_binomial(rng, mu, weights)
    elif family.name == "poisson":
        return simulate_poisson(rng, mu)
    else:
        raise ValueError(f"Unsupported family: {family.name}")
