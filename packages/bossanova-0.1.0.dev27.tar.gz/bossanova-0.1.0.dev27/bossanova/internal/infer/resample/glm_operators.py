"""GLM bootstrap operators (vmap-accelerated IRLS).

Provides ``compute_batched_glm_bootstrap`` which runs bootstrap IRLS solves
in parallel via ``jax.vmap`` on the JAX backend. Memory safety is ensured
by chunking via ``compute_batch_size``.

This mirrors ``lm_operators.py`` but for GLM models (binomial, poisson,
gamma). Each bootstrap replicate runs an independent IRLS solve. On JAX,
``lax.while_loop`` inside ``vmap`` runs all lanes in parallel — converged
lanes just check the condition and skip (minimal cost under XLA).

Only used when:
- Backend is JAX
- Family has no robust_weights (excludes t-distribution)
- Model has no random effects (excludes LMER/GLMER)
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Callable

import numpy as np

if TYPE_CHECKING:
    from bossanova.internal.maths.family.schema import Family

Array = Any

__all__ = [
    "compute_batched_glm_bootstrap",
]

# Cache keyed by (family_name, link_name, max_iter, p)
_irls_from_indices_cache: dict[tuple, Any] = {}


def _make_irls_bootstrap_core(
    family: Family, max_iter: int, tol: float, p: int
) -> Callable:
    """Create bootstrap IRLS core that indexes into X and y.

    The returned function takes ``(indices, X, y, prior_weights)`` and runs
    IRLS to convergence, returning only the coefficient vector. This is the
    inner kernel for ``compute_batched_glm_bootstrap`` — it gets vmapped
    over the bootstrap index array.

    On JAX, non-convergence produces coefficients from the last iteration
    (not NaN), matching the sequential path behavior. Singular bootstrap
    samples produce NaN coefficients via Cholesky failure.

    Args:
        family: Family object with link and variance functions.
        max_iter: Maximum IRLS iterations.
        tol: Convergence tolerance for relative deviance change.
        p: Number of parameters.

    Returns:
        Function ``(indices, X, y, prior_weights) -> coef`` of shape ``(p,)``.
    """
    import jax.lax as lax
    import jax.numpy as jnp

    from bossanova.internal.maths.solvers.glm import irls_step

    def _core(indices: Array, X: Array, y: Array, prior_weights: Array) -> Array:
        X_b = X[indices]
        y_b = y[indices]
        w_b = prior_weights[indices]
        n = indices.shape[0]

        # Initialize mu and eta (family methods are pure JAX ops)
        mu_init = family.initialize(y_b, w_b)
        eta_init = family.link(mu_init)

        # 8-element state: (mu, eta, dev_curr, iteration, coef, XtWX, weights, dev_prev)
        init_state = (
            mu_init,
            eta_init,
            jnp.array(jnp.inf),
            jnp.array(0, dtype=jnp.int32),
            jnp.zeros(p),
            jnp.eye(p),
            jnp.ones(n),
            jnp.array(jnp.inf),
        )

        def cond_fn(state):
            """Return True to continue looping."""
            _, _, dev_curr, iteration, _, _, _, dev_prev = state
            not_done = iteration < max_iter

            should_continue = lax.cond(
                jnp.isinf(dev_prev),
                lambda: True,
                lambda: (
                    jnp.abs(dev_curr - dev_prev) / (jnp.abs(dev_prev) + 1e-10) >= tol
                ),
            )
            return not_done & should_continue

        def body_fn(state):
            """Single IRLS iteration."""
            mu, eta, dev_curr, iteration, _, _, _, _ = state
            mu_new, eta_new, coef, dev_new, w, XtWX = irls_step(
                mu, eta, y_b, X_b, w_b, family, p, jnp
            )
            return (
                mu_new,
                eta_new,
                dev_new,
                iteration + 1,
                coef,
                XtWX,
                w,
                dev_curr,
            )

        final_state = lax.while_loop(cond_fn, body_fn, init_state)
        return final_state[4]  # coef only

    return _core


def _get_batched_irls_fn(family: Family, max_iter: int, tol: float, p: int) -> Callable:
    """Get JIT-compiled vmapped IRLS function, cached per configuration.

    Composes ``jit(vmap(core), donate_argnums=(0,))`` so that the
    per-chunk index buffer is donated to XLA for memory reuse.

    Args:
        family: Family object (determines link/variance functions).
        max_iter: Maximum IRLS iterations.
        tol: Convergence tolerance.
        p: Number of parameters.

    Returns:
        Cached JIT-compiled vmapped function
        ``(idx_chunk, X, y, prior_weights) -> coef_chunk``.
    """
    import jax

    cache_key = (family.name, family.link_name, max_iter, p)
    if cache_key not in _irls_from_indices_cache:
        core = _make_irls_bootstrap_core(family, max_iter, tol, p)
        vmapped = jax.vmap(core, in_axes=(0, None, None, None))
        _irls_from_indices_cache[cache_key] = jax.jit(vmapped, donate_argnums=(0,))
    return _irls_from_indices_cache[cache_key]


def compute_batched_glm_bootstrap(
    boot_indices: np.ndarray,
    X: np.ndarray,
    y: np.ndarray,
    family: Family,
    *,
    weights: np.ndarray | None = None,
    max_iter: int = 25,
    tol: float = 1e-8,
    chunk_size: int | None = None,
) -> np.ndarray:
    """Compute bootstrap GLM coefficients using chunked vmap.

    For GLM models (non-robust, no random effects), each bootstrap replicate
    is an independent IRLS solve. This function batches those solves via
    ``jax.vmap`` — on JAX, this compiles to a single XLA program where each
    lane runs its own ``lax.while_loop``.

    Memory safety is ensured by chunking: ``compute_batch_size`` determines
    how many solves to batch at once based on available memory. The IRLS
    state tuple is larger than OLS, so chunk sizes are smaller.

    Args:
        boot_indices: Bootstrap index array, shape ``(n_boot, n)``.
        X: Design matrix, shape ``(n, p)``.
        y: Response vector, shape ``(n,)``.
        family: Family object with link, variance, and deviance functions.
        weights: Optional prior observation weights, shape ``(n,)``.
            If None, equal weights (ones) are used.
        max_iter: Maximum IRLS iterations per bootstrap sample.
        tol: Convergence tolerance for relative deviance change.
        chunk_size: Number of bootstrap samples per chunk. If ``None``,
            computed automatically from available memory.

    Returns:
        Coefficient array, shape ``(n_boot, p)``.
    """
    import jax.numpy as jnp

    from bossanova.internal.maths.batching import compute_batch_size

    n_boot = boot_indices.shape[0]
    n, p = X.shape

    # Compute chunk size if not provided
    if chunk_size is None:
        # Memory per bootstrap lane (IRLS state + intermediates):
        #   State tuple: mu(n) + eta(n) + coef(p) + XtWX(p²) + irls_w(n) + 3 scalars
        #   irls_step intermediates: deta_dmu(n) + var_mu(n) + working_resp(n)
        #       + irls_w(n) + XtWX(p²) + XtWz(p) + L(p²) + coef(p)
        #   Resampled data: X_b(n*p) + y_b(n) + w_b(n)
        state_bytes = (3 * n + p + p * p + 3) * 8
        step_bytes = (4 * n + 3 * p * p + 2 * p) * 8
        data_bytes = (n * p + 2 * n) * 8
        bytes_per_item = state_bytes + step_bytes + data_bytes
        chunk_size = compute_batch_size(n_items=n_boot, bytes_per_item=bytes_per_item)

    # Convert to JAX arrays (kept in JAX across all chunks)
    X_jax = jnp.asarray(X)
    y_jax = jnp.asarray(y)
    if weights is None:
        w_jax = jnp.ones(n)
    else:
        w_jax = jnp.asarray(weights)

    # Get JIT-compiled vmapped IRLS function
    batched_irls = _get_batched_irls_fn(family, max_iter, tol, p)

    # Process in chunks — idx_chunk buffer is donated to XLA each iteration
    results = []
    for start in range(0, n_boot, chunk_size):
        end = min(start + chunk_size, n_boot)
        idx_chunk = jnp.asarray(boot_indices[start:end])
        chunk_coefs = batched_irls(idx_chunk, X_jax, y_jax, w_jax)
        results.append(np.asarray(chunk_coefs))

    return np.concatenate(results, axis=0)
