"""LMER bootstrap with full PLS refitting.

This module provides parametric bootstrap for linear mixed-effects models
(LMER). Each bootstrap iteration simulates y* = X beta + Z b* + eps* and
refits via PLS optimization of the deviance / REML criterion.

Key characteristics:
- Sequential loop (cannot vmap due to scipy.sparse operations)
- Parametric bootstrap: simulate b* ~ N(0, sigma^2 LL'), eps* ~ N(0, sigma^2 I)
- Full PLS refit per sample (expensive but necessary)
- Optional parallelization via joblib
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

import numpy as np
import scipy.sparse as sp

# Type alias for arrays (works with both JAX and NumPy)
if TYPE_CHECKING:
    from jax import Array

from bossanova.internal.maths.rng import RNG
from bossanova.internal.maths.solvers import optimize_theta
from bossanova.internal.maths.solvers.lambda_builder import (
    build_lambda_sparse,
    build_lambda_template,
)
from bossanova.internal.maths.solvers.lmer import (
    PLSInvariants,
    lmm_deviance_sparse,
    solve_pls_sparse,
)
from bossanova.internal.infer.resample.common import (
    collect_boot_samples,
    compute_bootstrap_ci,
    run_bootstrap_iterations,
)
from bossanova.internal.infer.resample.results import BootstrapResult

__all__ = [
    "lmer_bootstrap",
    "lmer_bootstrap_single_iteration",
    "simulate_from_lmer",
]


# =============================================================================
# Simulation
# =============================================================================


def simulate_from_lmer(
    rng: RNG,
    X: np.ndarray,
    Z: sp.csc_matrix,
    beta: np.ndarray,
    theta: np.ndarray,
    sigma: float,
    n_groups_list: list[int],
    re_structure: str,
    metadata: dict | None = None,
) -> np.ndarray:
    """Simulate response from fitted lmer model.

    Generates y* = X beta + Z b* + eps* where:
    - b* ~ N(0, sigma^2 LL') are simulated random effects
    - eps* ~ N(0, sigma^2 I) are simulated residuals

    Args:
        rng: RNG object for random number generation.
        X: Fixed effects design matrix, shape (n, p).
        Z: Random effects design matrix, shape (n, q), scipy sparse CSC.
        beta: Fixed effects coefficients, shape (p,).
        theta: Variance parameters for Lambda.
        sigma: Residual standard deviation.
        n_groups_list: Number of groups per grouping factor.
        re_structure: Random effects structure type.
        metadata: Additional metadata for complex structures.

    Returns:
        Simulated response vector, shape (n,).
    """
    # Build Lambda from theta
    Lambda = build_lambda_sparse(theta, n_groups_list, re_structure, metadata)

    # Simulate spherical random effects: u* ~ N(0, I)
    q = Lambda.shape[0]
    rng_u, rng_eps = rng.split_one()
    u_star = rng_u.normal(shape=(q,))

    # Transform to b* = sigma L u* ~ N(0, sigma^2 LL')
    # Note: theta are relative to sigma, so we must scale by sigma
    b_star = sigma * (Lambda @ u_star)

    # Simulate residuals: eps* ~ N(0, sigma^2 I)
    n = X.shape[0]
    eps_star = sigma * rng_eps.normal(shape=(n,))

    # Compute fitted + random effects + residuals
    # y* = X beta + Z b* + eps*
    y_star = X @ beta + Z.toarray() @ b_star + eps_star

    return np.asarray(y_star)


# =============================================================================
# Single Iteration (standalone for joblib)
# =============================================================================


def lmer_bootstrap_single_iteration(
    rng: RNG,
    X_np: np.ndarray,
    Z_sparse: sp.csc_matrix,
    beta_np: np.ndarray,
    theta_np: np.ndarray,
    sigma: float,
    n_groups_list: list[int],
    re_structure: str,
    metadata: dict | None,
    method: str,
    lower_bounds: list[float],
    upper_bounds: list[float],
    max_iter: int,
    lambda_template: object | None,
    X_arr: np.ndarray,
    XtX: np.ndarray,
    n: int,
    p: int,
    n_params: int,
    which: str,
    group_names: list[str] | None,
    random_names: list[str] | None,
) -> np.ndarray:
    """Execute a single LMER bootstrap iteration.

    This is a standalone function (not a closure) to enable joblib parallelization.
    All arguments are passed explicitly to avoid pickling issues.

    Args:
        rng: RNG object for random number generation.
        X_np: Fixed effects design matrix.
        Z_sparse: Random effects design matrix (sparse CSC).
        beta_np: Fixed effects coefficients.
        theta_np: Variance parameters (starting values).
        sigma: Residual standard deviation.
        n_groups_list: Number of groups per factor.
        re_structure: Random effects structure type.
        metadata: Model metadata.
        method: Estimation method ("REML" or "ML").
        lower_bounds: Lower bounds for theta optimization.
        upper_bounds: Upper bounds for theta optimization.
        max_iter: Maximum optimizer iterations.
        lambda_template: Pre-built Lambda template (or None).
        X_arr: X as array (pre-computed).
        XtX: X'X matrix (pre-computed).
        n: Number of observations.
        p: Number of fixed effects.
        n_params: Number of parameters to return.
        which: Which parameters ("fixef", "ranef", or "all").
        group_names: Names of grouping factors.
        random_names: Names of random effects.

    Returns:
        Array of bootstrap estimates, or NaN array if iteration failed.
    """
    try:
        # Parametric bootstrap: simulate from fitted model
        y_boot = simulate_from_lmer(
            rng=rng,
            X=X_np,
            Z=Z_sparse,
            beta=beta_np,
            theta=theta_np,
            sigma=sigma,
            n_groups_list=n_groups_list,
            re_structure=re_structure,
            metadata=metadata,
        )

        # Build PLS invariants for this bootstrap sample
        # X'X is pre-computed (constant), only X'y changes with y_boot
        y_boot_arr = np.asarray(y_boot)
        Xty_boot = X_arr.T @ y_boot_arr
        pls_invariants = PLSInvariants(
            XtX=XtX,
            Xty=Xty_boot,
            X_backend=X_arr,
            y_backend=y_boot_arr,
        )

        # Deviance function for this bootstrap sample
        def deviance_fn_boot(theta_boot: np.ndarray) -> float:
            return lmm_deviance_sparse(
                theta=theta_boot,
                X=X_np,
                Z=Z_sparse,
                y=y_boot,
                n_groups_list=n_groups_list,
                re_structure=re_structure,
                method=method,
                lambda_template=lambda_template,
                pls_invariants=pls_invariants,
                metadata=metadata,
            )

        # Optimize theta
        result = optimize_theta(
            objective=deviance_fn_boot,
            theta0=theta_np,
            lower=lower_bounds,
            upper=upper_bounds,
            rhobeg=2e-3,
            rhoend=2e-7,
            maxfun=max_iter,
            verbose=False,
        )

        if not result["converged"]:
            return np.full(n_params, np.nan)

        # Extract estimates at optimal theta
        theta_boot = result["theta"]
        Lambda_boot = build_lambda_sparse(
            theta_boot, n_groups_list, re_structure, metadata
        )
        pls_result_boot = solve_pls_sparse(
            X_np,
            Z_sparse,
            Lambda_boot,
            y_boot,
            pls_invariants=pls_invariants,
        )

        if which == "fixef":
            return pls_result_boot["beta"]

        # For ranef or all, need sigma_boot and variance components
        from bossanova.internal.maths.variance import (
            theta_to_variance_components,
        )

        u_boot = pls_result_boot["u"]
        rss_boot = pls_result_boot["rss"]
        pwrss_boot = rss_boot + np.sum(u_boot**2)

        if method == "REML":
            sigma_boot = np.sqrt(pwrss_boot / (n - p))
        else:
            sigma_boot = np.sqrt(pwrss_boot / n)

        _, vc_values = theta_to_variance_components(
            theta=theta_boot,
            sigma=sigma_boot,
            group_names=group_names,
            random_names=random_names,
            re_structure=re_structure,
        )

        if which == "ranef":
            return np.array(vc_values)
        else:  # which == "all"
            return np.concatenate([pls_result_boot["beta"], np.array(vc_values)])

    except Exception:
        # Numerical failure: return NaN
        return np.full(n_params, np.nan)


# =============================================================================
# Main Entry Point
# =============================================================================


def lmer_bootstrap(
    X: "Array",
    Z: sp.csc_matrix | "Array",
    y: "Array",
    X_names: list[str],
    theta: "Array",
    beta: "Array",
    sigma: float,
    n_groups_list: list[int],
    re_structure: str,
    metadata: dict | None = None,
    lower_bounds: list[float] | None = None,
    n_boot: int = 999,
    seed: int | None = None,
    boot_type: Literal["parametric"] = "parametric",
    ci_type: Literal["percentile", "basic", "bca"] = "percentile",
    level: float = 0.95,
    method: Literal["REML", "ML"] = "REML",
    max_iter: int = 10000,
    tol: float = 1e-8,
    verbose: bool = False,
    which: Literal["fixef", "ranef", "all"] = "fixef",
    group_names: list[str] | None = None,
    random_names: list[str] | None = None,
    n_jobs: int = 1,
) -> BootstrapResult:
    """Bootstrap inference for lmer parameters.

    Supports parallel execution via joblib for significant speedups on
    multi-core machines. Each bootstrap iteration requires a full PLS
    optimization, making parallelization highly beneficial.

    Uses parametric bootstrap: simulate y* from the fitted model
    (y* = X beta_hat + Z b* + eps*) and refit. This is the standard approach
    for mixed models, matching R's ``lme4::bootMer(type="parametric")``.

    Note:
        Only parametric bootstrap is supported for mixed models, matching
        R/lme4. Residual and case bootstrap are not applicable because the
        residual structure involves multiple variance components (within-group
        and between-group). Parametric bootstrap properly accounts for this
        hierarchical structure by simulating new random effects.

    Args:
        X: Fixed effects design matrix, shape (n, p).
        Z: Random effects design matrix, shape (n, q), scipy sparse CSC.
        y: Response vector, shape (n,).
        X_names: Fixed effects coefficient names.
        theta: Variance parameters from fitted model.
        beta: Fixed effects coefficients from fitted model.
        sigma: Residual standard deviation from fitted model.
        n_groups_list: Number of groups per grouping factor.
        re_structure: Random effects structure type.
        metadata: Additional metadata for complex structures.
        lower_bounds: Lower bounds for theta optimization. If None, uses 0 for all.
        n_boot: Number of bootstrap samples.
        seed: Random seed for reproducibility.
        boot_type: Type of bootstrap. Only ``"parametric"`` is supported.
        ci_type: Confidence interval type: "percentile", "basic", or "bca".
        level: Confidence level (e.g., 0.95 for 95% CI).
        method: Estimation method for refitting: "REML" or "ML".
        max_iter: Maximum optimizer iterations for each refit.
        tol: Convergence tolerance for optimizer.
        verbose: Print progress information.
        which: Which parameters to bootstrap:
            - "fixef": Fixed effects coefficients (default).
            - "ranef": Variance components (SDs and correlations).
            - "all": Both fixed effects and variance components.
        group_names: Grouping factor names (required if which="ranef" or "all").
        random_names: Random effect names (required if which="ranef" or "all").
        n_jobs: Number of parallel jobs. Default 1 (sequential).
            Use -1 for all available cores. Parallelization uses joblib
            with the loky backend for process-based parallelism.

    Returns:
        BootstrapResult with observed stats, bootstrap samples, and CIs.
        For which="ranef", param_names are variance component names
        (e.g., "Subject:Intercept_sd", "Subject:corr_Intercept:Days", "Residual_sd").
        For which="all", fixed effects come first, then variance components.

    Raises:
        ValueError: If boot_type is not ``"parametric"``.
        ValueError: If ci_type is not "percentile", "basic", or "bca".
        ValueError: If which="ranef" but group_names or random_names not provided.

    Examples:
        ```python
        # Parametric bootstrap for fixed effects
        result = lmer_bootstrap(
            X, Z, y, ["Intercept", "Days"], theta, beta, sigma,
            n_groups_list=[18], re_structure="slope",
            n_boot=999, boot_type="parametric"
        )
        print(result.ci)

        # Bootstrap for variance components
        result = lmer_bootstrap(
            X, Z, y, ["Intercept", "Days"], theta, beta, sigma,
            n_groups_list=[18], re_structure="slope",
            n_boot=999, which="ranef",
            group_names=["Subject"], random_names=["Intercept", "Days"]
        )
        ```

    Warning:
        Bootstrap refitting can fail to converge for some samples. Convergence
        failures > 10% will trigger a warning. Failed samples are excluded from
        CI computation.
    """
    # Input validation
    if boot_type != "parametric":
        raise ValueError(
            f"boot_type must be 'parametric' for mixed models, got {boot_type!r}"
        )
    if ci_type == "bca":
        raise ValueError(
            "BCa confidence intervals are not supported for mixed models. "
            "Use ci_type='percentile' or ci_type='basic' instead."
        )
    if ci_type not in ("percentile", "basic"):
        raise ValueError(
            f"ci_type must be 'percentile' or 'basic' for mixed models, got {ci_type}"
        )
    if which not in ("fixef", "ranef", "all"):
        raise ValueError(f"which must be 'fixef', 'ranef', or 'all', got {which}")
    if which in ("ranef", "all") and (group_names is None or random_names is None):
        raise ValueError(
            "group_names and random_names are required when which='ranef' or 'all'"
        )

    # Setup
    X_np = np.asarray(X)
    theta_np = np.asarray(theta)
    beta_np = np.asarray(beta)
    n, p = X_np.shape
    n_theta = len(theta_np)

    # Convert Z to sparse CSC if needed
    if not sp.isspmatrix_csc(Z):
        Z_sparse = sp.csc_matrix(np.asarray(Z))
    else:
        Z_sparse = Z

    if lower_bounds is None:
        lower_bounds = [0.0] * n_theta
    upper_bounds = [np.inf] * n_theta

    rng = RNG.from_seed(seed)

    # Compute observed values, param names, and term types based on which
    if which == "fixef":
        observed = np.asarray(beta_np)
        param_names = X_names
        term_types = ["fixef"] * p
        n_params = p
    elif which == "ranef":
        from bossanova.internal.maths.variance import (
            theta_to_variance_components,
        )

        param_names, obs_values = theta_to_variance_components(
            theta=theta_np,
            sigma=sigma,
            group_names=group_names,
            random_names=random_names,
            re_structure=re_structure,
        )
        observed = np.asarray(obs_values)
        term_types = ["ranef"] * len(param_names)
        n_params = len(param_names)
    else:  # which == "all"
        from bossanova.internal.maths.variance import (
            theta_to_variance_components,
        )

        vc_names, vc_values = theta_to_variance_components(
            theta=theta_np,
            sigma=sigma,
            group_names=group_names,
            random_names=random_names,
            re_structure=re_structure,
        )
        # Fixed effects first, then variance components
        param_names = list(X_names) + vc_names
        term_types = ["fixef"] * p + ["ranef"] * len(vc_names)
        observed = np.concatenate([np.asarray(beta_np), np.asarray(vc_values)])
        n_params = len(param_names)

    # Generate all RNGs upfront
    rngs = rng.split(n_boot)

    # Pre-compute invariants for optimization (PERFORMANCE CRITICAL)
    lambda_template = build_lambda_template(n_groups_list, re_structure, metadata)

    X_arr = np.asarray(X_np)
    XtX = X_arr.T @ X_arr

    # Shared iteration arguments
    iter_kwargs = dict(
        X_np=X_np,
        Z_sparse=Z_sparse,
        beta_np=beta_np,
        theta_np=theta_np,
        sigma=sigma,
        n_groups_list=n_groups_list,
        re_structure=re_structure,
        metadata=metadata,
        method=method,
        lower_bounds=lower_bounds,
        upper_bounds=upper_bounds,
        max_iter=max_iter,
        lambda_template=lambda_template,
        X_arr=X_arr,
        XtX=XtX,
        n=n,
        p=p,
        n_params=n_params,
        which=which,
        group_names=group_names,
        random_names=random_names,
    )

    # Run iterations using shared execution loop
    boot_samples_list = run_bootstrap_iterations(
        iteration_fn=lmer_bootstrap_single_iteration,
        rngs=rngs,
        n_boot=n_boot,
        iter_kwargs=iter_kwargs,
        n_jobs=n_jobs,
        verbose=verbose,
    )

    # Collect samples, check failures
    boot_samples, valid_mask, _ = collect_boot_samples(boot_samples_list, n_boot)
    boot_samples_valid = boot_samples[valid_mask]

    ci_lower, ci_upper = compute_bootstrap_ci(
        observed, boot_samples_valid, ci_type, level
    )

    return BootstrapResult(
        observed=observed,
        boot_samples=boot_samples,
        ci_lower=ci_lower,
        ci_upper=ci_upper,
        param_names=param_names,
        n_boot=n_boot,
        ci_type=ci_type,
        level=level,
        term_types=term_types,
    )
