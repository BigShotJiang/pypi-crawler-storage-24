"""Profile likelihood inference for variance components.

Builds a non-profiled ML deviance on the sigpar (SD/corr + sigma) scale
and runs ``profile_likelihood_sigpar()`` to compute CIs directly on the
SD scale, matching lme4's ``devfun2`` approach.

Internal exports:
    compute_profile_inference: Profile likelihood CIs for mixed models.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from bossanova.internal.containers import DataBundle, FitState, ModelSpec
    from bossanova.internal.containers.structs.mixed import ProfileState

__all__ = [
    "compute_profile_inference",
]


def compute_profile_inference(
    spec: "ModelSpec",
    bundle: "DataBundle",
    fit: "FitState",
    conf_level: float = 0.95,
    *,
    n_steps: int = 20,
    verbose: bool = False,
    threshold: float | None = None,
) -> "ProfileState":
    """Compute profile likelihood CIs for variance components.

    Profiles on the sigpar (SD/corr + sigma) scale using a non-profiled ML
    deviance, matching lme4's ``devfun2``. This avoids theta-to-SD conversion
    errors and produces CIs directly on the SD scale.

    Following lme4, profiling always uses ML deviance regardless of
    whether the model was fitted with REML. If the model was fit with
    REML, theta is re-optimized under ML before profiling.

    Args:
        spec: Model specification.
        bundle: Data bundle with X, Z, y, and re_metadata.
        fit: Fit state with theta, sigma, and variance components.
        conf_level: Confidence level for profile CIs.
        n_steps: Number of profiling steps (default: 20).
        verbose: Print profiling progress (default: False).
        threshold: Custom deviance threshold for CIs (default: None, uses
            chi-squared quantile).

    Returns:
        ProfileState with profile traces and CIs.
    """
    from scipy.optimize import minimize as sp_minimize

    from bossanova.internal.containers.structs.mixed import ProfileState
    from bossanova.internal.fit.varying import (
        per_factor_re_info,
    )  # Deferred: avoid circular import between infer ↔ fit
    from bossanova.internal.maths.inference.profile import (
        get_sigpar_bounds,
        profile_likelihood_sigpar,
        sigpar_to_theta,
        theta_to_sigpar,
    )
    from bossanova.internal.maths.solvers.lambda_builder import (
        build_lambda_template,
        update_lambda_from_template,
    )
    from bossanova.internal.maths.solvers.lmer import (
        compute_pls_invariants,
        lmm_deviance_sparse,
        solve_pls_sparse,
    )

    re_meta = bundle.re_metadata
    X = bundle.X
    Z = bundle.Z
    y = bundle.y
    theta_reml = fit.theta
    n, p = X.shape

    group_names = list(re_meta.grouping_vars)
    n_groups_list = re_meta.n_groups_list
    re_structure = re_meta.re_structure
    metadata = re_meta.metadata

    conv_re_structure, conv_random_names = per_factor_re_info(re_meta, group_names)

    # Build lambda template for efficient updates
    lambda_template = build_lambda_template(n_groups_list, re_structure, metadata)
    pls_invariants = compute_pls_invariants(X, y)

    # Following lme4: always profile using ML deviance (refitML).
    def ml_deviance_fn(th: np.ndarray) -> float:
        return lmm_deviance_sparse(
            theta=th,
            X=X,
            Z=Z,
            y=y,
            n_groups_list=n_groups_list,
            re_structure=re_structure,
            method="ML",
            lambda_template=lambda_template,
            pls_invariants=pls_invariants,
            metadata=metadata,
        )

    # Sigma from PLS solve (ML denominator: n)
    def _compute_sigma_ml(th: np.ndarray) -> float:
        Lambda = update_lambda_from_template(lambda_template, th)
        result = solve_pls_sparse(X, Z, Lambda, y, pls_invariants=pls_invariants)
        pwrss = result["rss"] + np.sum(result["u"] ** 2)
        return float(np.sqrt(pwrss / n))

    # --- ML refit (or REML fallback) ---
    from bossanova.internal.maths.solvers.heuristics import get_theta_lower_bounds

    lower_bounds = get_theta_lower_bounds(len(theta_reml), re_structure, metadata)
    use_ml = True

    if spec.method == "reml":
        ml_result = sp_minimize(
            ml_deviance_fn,
            theta_reml,
            method="L-BFGS-B",
            bounds=[(lb, None) for lb in lower_bounds],
        )
        theta_ml = ml_result.x

        # Check if ML refit is degenerate
        diag_mask = np.array([lb >= 0.0 for lb in lower_bounds])
        reml_positive = theta_reml[diag_mask] > 1e-4
        ml_boundary = theta_ml[diag_mask] < 1e-6
        if np.any(reml_positive & ml_boundary):
            import warnings

            warnings.warn(
                "ML refit produced boundary estimates for variance components. "
                "Falling back to REML-based profiling. Profile CIs may be wider "
                "than standard ML-based profile CIs.",
                stacklevel=3,
            )
            use_ml = False

    if use_ml and spec.method == "reml":
        theta = theta_ml
    else:
        theta = theta_reml

    # Compute sigma at optimal theta
    if use_ml:
        sigma_ml = _compute_sigma_ml(theta)
        sigma_denom = n
    else:
        # REML fallback: sigma uses (n - p) denominator
        Lambda = update_lambda_from_template(lambda_template, theta)
        result = solve_pls_sparse(X, Z, Lambda, y, pls_invariants=pls_invariants)
        pwrss = result["rss"] + np.sum(result["u"] ** 2)
        sigma_ml = float(np.sqrt(pwrss / (n - p)))
        sigma_denom = n - p

    # Convert to sigpar
    sigpar_opt = theta_to_sigpar(
        theta, sigma_ml, conv_re_structure, group_names, conv_random_names
    )

    # Build non-profiled deviance on sigpar scale (lme4's devfun2)
    # dev = ldL2(theta) + pwrss(theta)/sigma^2 + n*log(2*pi*sigma^2)
    def sigpar_deviance(sigpar: np.ndarray) -> float:
        th, sig = sigpar_to_theta(
            sigpar, conv_re_structure, group_names, conv_random_names
        )
        Lambda = update_lambda_from_template(lambda_template, th)
        pls = solve_pls_sparse(X, Z, Lambda, y, pls_invariants=pls_invariants)
        ldL2 = pls["logdet_L"]
        pwrss = pls["rss"] + np.sum(pls["u"] ** 2)

        if use_ml:
            return float(ldL2 + pwrss / sig**2 + n * np.log(2 * np.pi * sig**2))
        else:
            # REML: add logdet_RX, use (n-p) for sigma denominator
            return float(
                ldL2
                + pls["logdet_RX"]
                + pwrss / sig**2
                + sigma_denom * np.log(2 * np.pi * sig**2)
            )

    sigpar_bounds = get_sigpar_bounds(conv_re_structure, group_names, conv_random_names)
    dev_opt = sigpar_deviance(sigpar_opt)

    # Profile on sigpar scale
    profile_kwargs: dict[str, object] = {"n_steps": n_steps, "verbose": verbose}
    if threshold is not None:
        profile_kwargs["threshold"] = threshold

    profile_data = profile_likelihood_sigpar(
        sigpar_opt=sigpar_opt,
        sigpar_deviance_fn=sigpar_deviance,
        sigpar_bounds=sigpar_bounds,
        dev_opt=dev_opt,
        conf_level=conf_level,
        group_names=group_names,
        random_names=conv_random_names,
        re_structure=conv_re_structure,
        **profile_kwargs,
    )

    return ProfileState(**profile_data)
