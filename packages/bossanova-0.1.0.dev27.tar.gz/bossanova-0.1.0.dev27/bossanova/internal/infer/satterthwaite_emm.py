"""Satterthwaite degrees of freedom for EMM contrasts in linear mixed models.

Computes per-EMM denominator df using the Satterthwaite approximation,
matching lmerTest's approach where derivatives are taken w.r.t. the full
variance parameter vector ``varpar = [theta, sigma]``.

Hybrid analytical/numerical strategy:
    The REML deviance separates into theta-dependent and sigma-dependent parts.
    ``logdet_L``, ``logdet_RX2``, and ``pwrss`` depend on theta only (not sigma),
    so sigma's contributions can be computed analytically:

    - ``d²dev/dsigma² = -2*df_dev/sigma² + 6*pwrss_0/sigma⁴`` (fully analytical)
    - ``d²dev/(dtheta_i dsigma) = -2/sigma³ * dpwrss/dtheta_i`` (central diff on pwrss)
    - ``dvcov/dsigma = (2/sigma) * fit.vcov`` (analytical, free)

    This reduces Hessian evals from 25 to ~11 and Jacobian evals from 17 to ~9
    for a single random-intercept model (52% reduction overall).

Algorithm:
    1. Compute ``pwrss_0`` at fitted theta (seeds cache)
    2. Define ``deviance_theta(th)`` — sigma fixed from fit
    3. Compute theta-only Hessian via Richardson extrapolation
    4. Compute ``dpwrss/dtheta`` via central difference (2m evals)
    5. Assemble full ``(m+1) x (m+1)`` Hessian with analytical sigma block
    6. ``vcov_varpar = 2 * H_full^{-1}``
    7. Compute theta-only Jacobian via Richardson extrapolation
    8. Append analytical sigma column: ``(2/sigma) * fit.vcov``
    9. Call ``satterthwaite_df_for_contrasts(L, vcov, vcov_varpar, jac_list)``
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np
import scipy.sparse as sp

if TYPE_CHECKING:
    from bossanova.internal.containers.structs import DataBundle, FitState, ModelSpec
    from bossanova.internal.maths.linalg.sparse import SparseFactorization

__all__ = [
    "compute_satterthwaite_emm_df",
]


def compute_satterthwaite_emm_df(
    bundle: DataBundle,
    fit: FitState,
    spec: ModelSpec,
    L: np.ndarray,
) -> np.ndarray:
    """Compute Satterthwaite denominator df for EMM contrast rows.

    For each row of the contrast matrix L, computes the Satterthwaite
    approximation to the denominator degrees of freedom.

    Uses a hybrid approach: differentiates numerically w.r.t. theta only,
    then fills in sigma's contributions analytically. This produces
    identical results to the full numerical approach but with ~52% fewer
    function evaluations for single random-intercept models.

    Args:
        bundle: Data bundle with X, Z, y, and re_metadata.
        fit: Fit state with theta, vcov, and sigma.
        spec: Model specification (method, family, etc.).
        L: Contrast matrix, shape ``(n_contrasts, n_coef)``.

    Returns:
        Array of Satterthwaite df, shape ``(n_contrasts,)``.

    Raises:
        ValueError: If fit has no theta/sigma or bundle has no Z/re_metadata.
    """
    from bossanova.internal.maths.differentiation import (
        compute_hessian_richardson,
        compute_jacobian_richardson,
    )
    from bossanova.internal.maths.inference.satterthwaite import (
        satterthwaite_df_for_contrasts,
    )
    from bossanova.internal.maths.linalg.sparse import compute_sparse_cholesky
    from bossanova.internal.maths.solvers.lambda_builder import (
        build_lambda_sparse,
    )
    from bossanova.internal.maths.solvers.lmer import apply_sqrt_weights

    # --- Validate inputs ---------------------------------------------------
    if fit.theta is None:
        raise ValueError("Satterthwaite df requires theta from a fitted mixed model.")
    if fit.sigma is None:
        raise ValueError("Satterthwaite df requires sigma from a fitted mixed model.")
    if bundle.Z is None or bundle.re_metadata is None:
        raise ValueError(
            "Satterthwaite df requires Z matrix and re_metadata in DataBundle."
        )

    theta = fit.theta
    sigma = fit.sigma
    sigma2 = sigma**2
    X = bundle.X
    Z = bundle.Z
    y = bundle.y
    re_meta = bundle.re_metadata
    n_groups_list = re_meta.n_groups_list
    re_structure = re_meta.re_structure
    metadata = re_meta.metadata

    # Apply sqrt(weights) transformation for weighted models.
    # The Satterthwaite derivatives must use the same weighted data as the solver.
    X_w, Z_w, y_w, sqrtwts = apply_sqrt_weights(X, Z, y, bundle.weights)

    n, p = X.shape
    m = len(theta)
    method = spec.method.upper() if spec.method else "REML"
    if method not in ("REML", "ML"):
        method = "REML"
    df_dev = (n - p) if method == "REML" else n

    # --- Precompute theta-independent constants ----------------------------
    XtX = X_w.T @ X_w  # (p, p)
    Xty = X_w.T @ y_w  # (p,)
    q = Z_w.shape[1]
    I_q = sp.eye(q, format="csc")  # (q, q)

    # --- Shared cache for Lambda/ZL/factor across closures -----------------
    _cache: dict[str, Any] = {"th": None, "factor": None, "ZL": None}

    def _get_or_rebuild(th: np.ndarray) -> tuple[sp.spmatrix, SparseFactorization]:
        """Return (ZL, factor_S22), rebuilding only when theta changes."""
        if _cache["th"] is not None and np.array_equal(th, _cache["th"]):
            return _cache["ZL"], _cache["factor"]

        Lambda = build_lambda_sparse(th, n_groups_list, re_structure, metadata)
        ZL = Z_w @ Lambda
        S22 = (ZL.T @ ZL).tocsc() + I_q

        if _cache["factor"] is not None:
            _cache["factor"].cholesky_inplace(S22)
            factor = _cache["factor"]
        else:
            factor = compute_sparse_cholesky(S22)

        _cache["th"] = th.copy()
        _cache["ZL"] = ZL
        _cache["factor"] = factor
        return ZL, factor

    def _solve_at_theta(
        th: np.ndarray,
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray, float, float, float]:
        """Solve the mixed model at a given theta, returning key quantities.

        Args:
            th: Theta parameter vector.

        Returns:
            Tuple of (beta, u, schur, pwrss, logdet_L, logdet_RX2).
        """
        ZL, factor_S22 = _get_or_rebuild(th)

        logdet_L = factor_S22.logdet()

        # Solve for beta and u
        ZLty = ZL.T @ y_w
        cu = factor_S22(ZLty)
        XtZL = (ZL.T @ X_w).T
        S22_inv_XtZL_T = factor_S22(XtZL.T)
        schur = XtX - XtZL @ S22_inv_XtZL_T
        rhs = Xty - XtZL @ cu

        try:
            beta = np.linalg.solve(schur, rhs)
        except np.linalg.LinAlgError:
            beta = np.linalg.lstsq(schur, rhs, rcond=None)[0]
        u = cu - S22_inv_XtZL_T @ beta

        fitted_w = X_w @ beta + ZL @ u
        resid_w = y_w - fitted_w
        rss = float(np.sum(resid_w**2))
        pwrss = rss + float(np.sum(u**2))

        try:
            chol_schur = np.linalg.cholesky(schur)
        except np.linalg.LinAlgError:
            schur_reg = schur + 1e-8 * np.eye(schur.shape[0])
            chol_schur = np.linalg.cholesky(schur_reg)
        logdet_RX2 = float(2 * np.sum(np.log(np.abs(np.diag(chol_schur)))))

        return beta, u, schur, pwrss, logdet_L, logdet_RX2

    # --- 1. Compute pwrss_0 at fitted theta (seeds cache) ------------------
    _, _, _, pwrss_0, _, _ = _solve_at_theta(theta)

    # --- 2. Deviance as a function of theta only (sigma fixed) -------------
    # Uses transformed data (X_w, Z_w, y_w) so weights are implicit, matching
    # the solver. Adds the Jacobian correction -log|W| for weighted models.
    def deviance_theta(th: np.ndarray) -> float:
        """Deviance as function of theta with sigma fixed at fitted value."""
        _, _, _, pwrss, logdet_L, logdet_RX2 = _solve_at_theta(th)

        if method == "REML":
            dev = (
                df_dev * np.log(2 * np.pi * sigma2)
                + pwrss / sigma2
                + logdet_L
                + logdet_RX2
            )
        else:
            dev = n * np.log(2 * np.pi * sigma2) + pwrss / sigma2 + logdet_L

        # Weight adjustment: -log|W| = -2*sum(log(sqrtwts))
        if sqrtwts is not None:
            dev = dev - 2.0 * np.sum(np.log(sqrtwts))

        return float(dev)

    # --- 3. Theta-only Hessian via Richardson extrapolation -----------------
    H_tt = compute_hessian_richardson(deviance_theta, theta)  # (m, m)

    # --- 4. Cross-derivative d²dev/(dtheta_i dsigma) via central diff ------
    # dpwrss/dtheta_i via central difference, then:
    #   d²dev/(dtheta_i dsigma) = -2/sigma³ * dpwrss/dtheta_i
    # Step sizes match differentiation.py:275
    _d = 1e-4
    _eps = 1e-4
    _zero_tol = np.sqrt(np.finfo(float).eps / 7e-7)

    def _pwrss_theta(th: np.ndarray) -> float:
        """Compute pwrss at given theta (lightweight, skips logdets)."""
        ZL, factor_S22 = _get_or_rebuild(th)

        ZLty = ZL.T @ y_w
        cu = factor_S22(ZLty)
        XtZL = (ZL.T @ X_w).T
        S22_inv_XtZL_T = factor_S22(XtZL.T)
        schur = XtX - XtZL @ S22_inv_XtZL_T
        rhs = Xty - XtZL @ cu

        try:
            beta = np.linalg.solve(schur, rhs)
        except np.linalg.LinAlgError:
            beta = np.linalg.lstsq(schur, rhs, rcond=None)[0]
        u = cu - S22_inv_XtZL_T @ beta

        fitted_w = X_w @ beta + ZL @ u
        resid_w = y_w - fitted_w
        return float(np.sum(resid_w**2) + np.sum(u**2))

    dpwrss_dtheta = np.zeros(m, dtype=np.float64)
    h_steps = np.abs(_d * theta) + _eps * (np.abs(theta) < _zero_tol)
    for i in range(m):
        e_i = np.zeros(m, dtype=np.float64)
        e_i[i] = h_steps[i]
        dpwrss_dtheta[i] = (_pwrss_theta(theta + e_i) - _pwrss_theta(theta - e_i)) / (
            2.0 * h_steps[i]
        )

    H_theta_sigma = -2.0 / (sigma**3) * dpwrss_dtheta  # (m,)

    # --- 5. Analytical sigma-sigma second derivative -----------------------
    # d²dev/dsigma² = -2*df_dev/sigma² + 6*pwrss_0/sigma⁴
    d2dev_dsig2 = -2.0 * df_dev / sigma2 + 6.0 * pwrss_0 / (sigma2**2)

    # --- 6. Assemble full (m+1) x (m+1) Hessian ---------------------------
    k = m + 1
    H_full = np.zeros((k, k), dtype=np.float64)
    H_full[:m, :m] = H_tt
    H_full[:m, m] = H_theta_sigma
    H_full[m, :m] = H_theta_sigma
    H_full[m, m] = d2dev_dsig2

    # vcov_varpar = 2 * H_full^{-1} (Moore-Penrose for robustness)
    tol = 1e-8
    eig_vals, eig_vecs = np.linalg.eigh(H_full)
    pos = eig_vals > tol
    if np.any(pos):
        eig_vecs_pos = eig_vecs[:, pos]
        eig_vals_pos = eig_vals[pos]
        H_inv = eig_vecs_pos @ np.diag(1.0 / eig_vals_pos) @ eig_vecs_pos.T
    else:
        H_inv = np.linalg.pinv(H_full + np.eye(k) * 1e-6)
    vcov_vp = 2.0 * H_inv

    # Reset cache between Hessian and Jacobian phases so the first Jacobian
    # call does a full rebuild (theta from perturbation won't match).
    _cache["th"] = None

    # --- 7. vcov(beta) as a function of theta only (sigma fixed) -----------
    # Uses transformed data (weights implicit in X_w, Z_w).
    def vcov_theta_fn(th: np.ndarray) -> np.ndarray:
        """Compute vcov(beta) for given theta with sigma fixed."""
        ZL, factor_S22 = _get_or_rebuild(th)

        XtZL = (ZL.T @ X_w).T
        S22_inv_XtZL_T = factor_S22(XtZL.T)
        schur = XtX - XtZL @ S22_inv_XtZL_T

        try:
            schur_inv = np.linalg.inv(schur)
        except np.linalg.LinAlgError:
            schur_inv = np.linalg.pinv(schur)
        return sigma2 * schur_inv

    # --- 8. Theta-only Jacobian + analytical sigma column ------------------
    jac_theta = compute_jacobian_richardson(vcov_theta_fn, theta)  # (p, p, m)

    # dvcov/dsigma = (2/sigma) * fit.vcov (analytical, free)
    jac_sigma = (2.0 / sigma) * fit.vcov  # (p, p)

    jac_full = np.zeros((p, p, k), dtype=np.float64)
    jac_full[:, :, :m] = jac_theta
    jac_full[:, :, m] = jac_sigma

    # Convert (p, p, k) array to list of k matrices
    jac_list = [jac_full[:, :, i] for i in range(k)]

    # --- 9. Compute per-contrast Satterthwaite df --------------------------
    df = satterthwaite_df_for_contrasts(
        L=L,
        vcov_beta=fit.vcov,
        vcov_varpar=vcov_vp,
        jac_list=jac_list,
    )

    return np.atleast_1d(np.asarray(df, dtype=np.float64))
