"""Cross-validation comparison with Nadeau-Bengio corrected t-test.

Compares models using k-fold (or LOO) cross-validation with the corrected
variance estimator from Nadeau & Bengio (2003) to account for overlapping
training sets.

Supports group-aware splitting via ``holdout_group`` to prevent data leakage
from random-effects structure.
"""

from typing import Any

import numpy as np
import polars as pl
from scipy import stats

from bossanova.internal.containers.schemas import Col, ComparisonCv
from bossanova.internal.infer.cv import (
    generate_group_kfold_splits,
    generate_kfold_splits,
    resolve_holdout_group_ids,
)

__all__ = [
    "compare_cv",
    "compute_cv_fold_score",
]


def compute_cv_fold_score(
    model: Any,
    train_idx: np.ndarray,
    test_idx: np.ndarray,
    metric: str,
) -> float:
    """Compute CV score for a single fold.

    Refits the model on training data and evaluates on test data.

    Args:
        model: A fitted model (lm or glm) to clone and refit.
        train_idx: Training set indices.
        test_idx: Test set indices.
        metric: Error metric ("mse", "rmse", "mae").

    Returns:
        Test set error for this fold.
    """
    # Get original data
    data = model.data
    formula = model.formula

    # Subset data for training and testing
    train_data = data[train_idx.tolist()]
    test_data = data[test_idx.tolist()]

    # Refit on training data using unified model()
    from bossanova.model import model as model_cls

    new_model = model_cls(
        formula, train_data, family=model.family, link=model.link
    ).fit()

    # Predict on test data
    new_model.predict(newdata=test_data)
    y_pred = new_model.predictions[Col.FITTED].to_numpy()

    # Get actual test values
    y_true = test_data[model._spec.response_var].to_numpy()

    # Compute error metric
    errors = y_true - y_pred

    if metric == "mse":
        return float(np.mean(errors**2))
    elif metric == "rmse":
        return float(np.sqrt(np.mean(errors**2)))
    elif metric == "mae":
        return float(np.mean(np.abs(errors)))
    else:
        raise ValueError(f"Unknown metric: {metric}. Use 'mse', 'rmse', or 'mae'.")


def _resolve_compare_splits(
    models: list[Any],
    cv: int | str,
    seed: int | None,
    holdout_group: str | None,
) -> tuple[list[tuple[np.ndarray, np.ndarray]], int]:
    """Resolve fold splits for model comparison.

    Checks all models for RE structure and resolves group-aware splitting.
    For cross-type comparisons (lm vs lmer), the mixed model's grouping
    governs splits for all models.

    Args:
        models: List of fitted models.
        cv: Number of folds or ``"loo"``.
        seed: Random seed.
        holdout_group: User-specified grouping column, or None.

    Returns:
        Tuple of (splits list, effective integer k).
    """
    import warnings

    n = models[0]._bundle.n

    # Find the first model with RE structure (for cross-type comparisons)
    group_ids = None
    for m in models:
        group_ids = resolve_holdout_group_ids(holdout_group, m.data, m._spec, m._bundle)
        if group_ids is not None:
            break

    if group_ids is not None:
        n_groups = len(np.unique(group_ids))

        if cv == "loo":
            splits = generate_group_kfold_splits(group_ids, k=n_groups, seed=seed)
            return splits, n_groups

        k = int(cv)
        if k > n_groups:
            warnings.warn(
                f"k={k} exceeds number of groups ({n_groups}); using k={n_groups}",
                stacklevel=4,
            )
            k = n_groups
        splits = generate_group_kfold_splits(group_ids, k=k, seed=seed)
        return splits, k

    # No group structure — naive splits
    if cv == "loo":
        from bossanova.internal.infer.resample.core import generate_loo_indices

        return generate_loo_indices(n), n

    k = int(cv)
    return generate_kfold_splits(n, k, seed=seed), k


def compare_cv(
    models: list[Any],
    cv: int | str = 5,
    seed: int | None = None,
    metric: str = "mse",
    holdout_group: str | None = None,
) -> pl.DataFrame:
    """Compare models using cross-validation with Nadeau-Bengio corrected t-test.

    Uses the corrected variance estimator from Nadeau & Bengio (2003) to account
    for the non-independence of CV folds (overlapping training sets).

    When models have random effects, uses group-aware fold splitting to prevent
    data leakage. For crossed random effects, ``holdout_group`` must be specified.

    Args:
        models: List of fitted models to compare.
        cv: Number of folds, or "loo" for leave-one-out.
        seed: Random seed for reproducible fold splits.
        metric: Error metric ("mse", "rmse", "mae").
        holdout_group: Column name to use for group-aware fold splitting.
            Required for crossed random effects. Can reference any column
            in the model's data, even if not in the formula.

    Returns:
        DataFrame with columns: model, PRE, t_stat, cv_score, cv_se,
        diff, diff_se, p_value.

    Notes:
        The Nadeau-Bengio correction accounts for the fact that k-fold CV
        training sets overlap by approximately (k-2)/(k-1) fraction.

        With group-aware splits, fold sizes may be unequal. The correction
        uses the mean n_test/n_train ratio across folds.

    References:
        Nadeau & Bengio (2003) "Inference for the Generalization Error"
    """
    n_models = len(models)

    # Generate shared fold splits for fair comparison
    splits, k = _resolve_compare_splits(models, cv, seed, holdout_group)

    # Compute mean n_test/n_train ratio for Nadeau-Bengio correction
    # (handles unequal fold sizes from group splits)
    ratios = [len(test) / len(train) for train, test in splits]
    mean_ratio = float(np.mean(ratios))

    # Collect per-fold scores for each model
    fold_scores: dict[int, list[float]] = {i: [] for i in range(n_models)}

    for train_idx, test_idx in splits:
        for i, model in enumerate(models):
            score = compute_cv_fold_score(model, train_idx, test_idx, metric)
            fold_scores[i].append(score)

    # Convert to arrays
    scores_array = {i: np.array(fold_scores[i]) for i in range(n_models)}

    # Initialize result lists
    formulas: list[str] = []
    cv_scores: list[float] = []
    cv_ses: list[float] = []
    diffs: list[float | None] = []
    diff_ses: list[float | None] = []
    t_stats: list[float | None] = []
    p_values: list[float | None] = []
    pres: list[float | None] = []

    # Reference model (first)
    ref_scores = scores_array[0]
    ref_mean = np.mean(ref_scores)
    ref_se = np.std(ref_scores, ddof=1) / np.sqrt(k)

    formulas.append(models[0].formula)
    cv_scores.append(float(ref_mean))
    cv_ses.append(float(ref_se))
    diffs.append(None)
    diff_ses.append(None)
    t_stats.append(None)
    p_values.append(None)
    pres.append(None)

    # Compare each model to reference
    for i in range(1, n_models):
        model_scores = scores_array[i]
        model_mean = np.mean(model_scores)
        model_se = np.std(model_scores, ddof=1) / np.sqrt(k)

        # Difference from reference (positive = reference is better)
        diff_vals = ref_scores - model_scores
        mean_diff = np.mean(diff_vals)
        var_diff = np.var(diff_vals, ddof=1)

        # Nadeau-Bengio correction with mean ratio for unequal folds
        var_corrected = var_diff * (1 / k + mean_ratio)
        se_corrected = np.sqrt(var_corrected)

        # t-statistic and p-value
        if se_corrected > 0:
            t_stat = mean_diff / se_corrected
            p_val = 2 * (1 - stats.t.cdf(np.abs(t_stat), df=k - 1))
        else:
            t_stat = 0.0
            p_val = 1.0

        # PRE: Proportional reduction in error
        # (error_ref - error_model) / error_ref
        # Positive PRE means model is better (lower error)
        pre = (ref_mean - model_mean) / ref_mean if ref_mean != 0 else 0.0

        formulas.append(models[i].formula)
        cv_scores.append(float(model_mean))
        cv_ses.append(float(model_se))
        diffs.append(float(mean_diff))
        diff_ses.append(float(se_corrected))
        t_stats.append(float(t_stat))
        p_values.append(float(p_val))
        pres.append(float(pre))

    # Build DataFrame
    return pl.DataFrame(
        {
            Col.MODEL: formulas,
            Col.PRE_R: pres,
            Col.T_STAT: t_stats,
            Col.CV_SCORE: cv_scores,
            Col.CV_SE: cv_ses,
            Col.DIFF: diffs,
            Col.DIFF_SE: diff_ses,
            Col.P_VALUE: p_values,
        },
        schema=ComparisonCv,
    )
