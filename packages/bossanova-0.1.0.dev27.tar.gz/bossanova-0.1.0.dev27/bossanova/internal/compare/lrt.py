"""Likelihood ratio test for comparing nested mixed models."""

from typing import Any

import polars as pl

from bossanova.internal.compare.compare import compare

__all__ = ["lrt"]


def lrt(*models: Any, sort: bool = True) -> pl.DataFrame:
    """Likelihood ratio test for comparing nested mixed models.

    Convenience wrapper for `compare(*models, method="lrt")` specifically
    designed for comparing lmer and glmer models.

    Args:
        *models: Two or more fitted mixed models to compare.
            Models should be nested (simpler model is a subset of complex model).
        sort: If True (default), sort models by complexity (fewest parameters first),
            matching R's anova() behavior. Set to False to preserve input order.

    Returns:
        DataFrame with columns:
            - model: Model formula string
            - chi2: Chi-squared statistic (deviance difference)
            - npar: Number of parameters
            - AIC: Akaike Information Criterion
            - BIC: Bayesian Information Criterion
            - loglik: Log-likelihood
            - deviance: -2 * log-likelihood
            - df: Degrees of freedom (parameter difference)
            - p_value: P-value from chi-squared distribution

    Raises:
        ValueError: If fewer than 2 models are provided.
        TypeError: If any model is not an lmer or glmer model (e.g., lm or glm
            models are passed).

    Notes:
        For valid likelihood ratio tests with different fixed effects, models
        must be fit with ML estimation (not REML). REML is accepted when all
        models share the same fixed effects (comparing random effects structures
        only). A ValueError is raised otherwise — refit models with
        ``method='ml'`` or use ``compare(..., refit=True)`` to auto-refit.

    Examples:
        ```python
        from bossanova import model, lrt
        m1 = model("Reaction ~ Days + (1|Subject)", data=sleepstudy).fit(method="ML")
        m2 = model("Reaction ~ Days + (Days|Subject)", data=sleepstudy).fit(method="ML")
        lrt(m1, m2)
        # ┌───────────────────────────────┬───────┬──────┬────────┬────────┬─────────┬──────────┬────┬──────────┐
        # │ model                         ┆ chi2  ┆ npar ┆ AIC    ┆ BIC    ┆ loglik  ┆ deviance ┆ df ┆ p_value  │
        # ├───────────────────────────────┼───────┼──────┼────────┼────────┼─────────┼──────────┼────┼──────────┤
        # │ Reaction ~ Days + (1|Subject) ┆       ┆ 4    ┆ 1802.1 ┆ 1814.8 ┆ -897.04 ┆ 1794.1   ┆    ┆          │
        # │ Reaction ~ Days + (Days|Subj) ┆ 42.14 ┆ 6    ┆ 1763.9 ┆ 1783.1 ┆ -875.97 ┆ 1751.9   ┆ 2  ┆ 7.07e-10 │
        # └───────────────────────────────┴───────┴──────┴────────┴────────┴─────────┴──────────┴────┴──────────┘
        ```
    """
    # Validate model types
    for model in models:
        model_type = model._model_type
        if model_type not in ("lmer", "glmer"):
            raise TypeError(
                f"lrt() requires lmer or glmer models, got {model_type}. "
                "For lm models, use compare(..., method='f'). "
                "For glm models, use compare(..., method='deviance')."
            )

    return compare(*models, method="lrt", sort=sort)
