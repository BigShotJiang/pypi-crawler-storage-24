"""F-test implementation for comparing nested lm models.

Performs sequential F-tests matching R's ``anova(m1, m2, ...)`` behavior.
"""

from typing import Any

import numpy as np
import polars as pl
from scipy import stats

from bossanova.internal.containers.schemas import Col, ComparisonFTest
from bossanova.internal.compare.helpers import check_nested

__all__ = [
    "compare_f_test",
    "compute_rss",
]


def compute_rss(model: Any) -> float:
    """Compute residual sum of squares for a model.

    Args:
        model: Fitted lm model.

    Returns:
        RSS = sum(residuals^2).
    """
    return float(np.sum(model._fit.residuals**2))


def compare_f_test(models: list[Any]) -> pl.DataFrame:
    """Perform sequential F-tests for nested lm models.

    Computes F-statistics comparing each model to the previous (simpler) model
    in the sequence. This matches R's anova(m1, m2, ...) behavior.

    Args:
        models: List of fitted lm models, sorted by complexity (simplest first).

    Returns:
        DataFrame with columns:
        - model: Formula string
        - PRE: Proportional reduction in error
        - F: F-statistic
        - rss: Residual sum of squares
        - ss: Sum of squares explained (RSS_compact - RSS_augmented)
        - df: Degrees of freedom for this comparison (df_compact - df_augmented)
        - df_resid: Residual degrees of freedom
        - p_value: p-value from F distribution

    Notes:
        The F-statistic is computed as:
            F = (SS / df) / (RSS_augmented / df_resid_augmented)

        For a single-parameter comparison, F = t^2 where t is the t-statistic
        for the added parameter in the augmented model.
    """
    n_models = len(models)

    # Initialize result lists
    formulas: list[str] = []
    df_resids: list[float] = []
    rss_values: list[float] = []
    dfs: list[float | None] = []
    ss_values: list[float | None] = []
    f_stats: list[float | None] = []
    p_values: list[float | None] = []
    pre_values: list[float | None] = []

    # First model (baseline)
    m0 = models[0]
    rss0 = compute_rss(m0)

    formulas.append(m0.formula)
    df_resids.append(float(m0._fit.df_resid))
    rss_values.append(rss0)
    dfs.append(None)
    ss_values.append(None)
    f_stats.append(None)
    p_values.append(None)
    pre_values.append(None)

    # Compute MSE from final (most complex) model - used for all comparisons
    # This matches R's anova() behavior for sequential model comparison
    m_final = models[-1]
    rss_final = compute_rss(m_final)
    df_final = m_final._fit.df_resid
    mse_final = rss_final / df_final

    # Compare each model to previous
    for i in range(1, n_models):
        m_prev = models[i - 1]
        m_curr = models[i]

        rss_prev = compute_rss(m_prev)
        rss_curr = compute_rss(m_curr)

        df_prev = m_prev._fit.df_resid
        df_curr = m_curr._fit.df_resid

        # Degrees of freedom for this comparison
        df_diff = df_prev - df_curr

        # Sum of squares explained
        ss = rss_prev - rss_curr

        # F-statistic: (SS / df) / MSE_final
        # Uses MSE from final model for all comparisons (matches R's anova())
        f_stat = (ss / df_diff) / mse_final if df_diff > 0 and mse_final > 0 else 0.0

        # p-value from F distribution (using df_final for denominator)
        p_val = 1.0 - stats.f.cdf(f_stat, df_diff, df_final)

        # PRE: Proportional Reduction in Error
        # (RSS_compact - RSS_augmented) / RSS_compact
        pre = ss / rss_prev if rss_prev > 0 else 0.0

        formulas.append(m_curr.formula)
        df_resids.append(float(df_curr))
        rss_values.append(rss_curr)
        dfs.append(float(df_diff))
        ss_values.append(float(ss))
        f_stats.append(float(f_stat))
        p_values.append(float(p_val))
        pre_values.append(float(pre))

    # Check for non-nested models
    check_nested(dfs, ss_values, formulas, method="f")

    # Build DataFrame
    return pl.DataFrame(
        {
            Col.MODEL: formulas,
            Col.PRE_R: pre_values,
            Col.F_STAT: f_stats,
            Col.RSS: rss_values,
            Col.SS: ss_values,
            Col.DF: dfs,
            Col.DF_RESID: df_resids,
            Col.P_VALUE: p_values,
        },
        schema=ComparisonFTest,
    )
