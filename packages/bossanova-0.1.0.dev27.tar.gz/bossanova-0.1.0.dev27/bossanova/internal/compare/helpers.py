"""Shared helpers for model comparison.

Provides validation, sorting, nesting checks, and method inference
used across all comparison strategies (F-test, deviance, LRT, CV).
"""

from __future__ import annotations

from typing import Any

__all__ = [
    "check_nested",
    "get_model_family_group",
    "get_model_type",
    "resolve_method",
    "sort_models_by_complexity",
    "validate_models",
]


# =============================================================================
# Model Type Helper
# =============================================================================


def get_model_type(model: Any) -> str:
    """Get the model type string for a fitted model.

    Args:
        model: A fitted model instance.

    Returns:
        Model type: 'lm', 'glm', 'lmer', or 'glmer'.
    """
    return model._model_type


def get_model_family_group(model: Any) -> str:
    """Get the family group for cross-type compatibility checking.

    Models in the same family group can be compared via LRT because
    the fixed-only model is nested within the mixed model (zero variance
    components). Models in different family groups have incompatible
    likelihoods and cannot be compared via hypothesis tests.

    Args:
        model: A fitted model instance.

    Returns:
        Family group string: 'gaussian' for lm/lmer, or the family name
        (e.g. 'binomial', 'poisson', 'gamma') for glm/glmer.
    """
    return model._spec.family


# =============================================================================
# Validation and Sorting Helpers
# =============================================================================


def validate_models(
    models: tuple[Any, ...], method: str = "auto", refit: bool = False
) -> tuple[Any, ...]:
    """Validate that models can be compared, auto-fitting if needed.

    Checks:
    - At least 2 models provided
    - All models are fitted (auto-fits unfitted models)
    - All models are the same type
    - All models have the same response variable
    - All models have the same number of observations
    - For LRT: All models use ML estimation (not REML), unless refit=True
      or all models share the same fixed effects (REML LRT is valid for
      comparing random effects structures with identical fixed effects)

    Args:
        models: Tuple of model objects (fitted or unfitted).
        method: Comparison method (used to check REML for LRT).
        refit: If True, skip REML validation (models will be refitted).

    Returns:
        Tuple of fitted model objects.

    Raises:
        ValueError: If validation fails.
    """
    if len(models) < 2:
        raise ValueError("compare() requires at least 2 models")

    # Auto-fit unfitted models (mutates in place)
    for m in models:
        if not getattr(m, "_is_fitted", False):
            m.fit()

    # Check type compatibility
    model_types = [get_model_type(m) for m in models]
    if len(set(model_types)) > 1:
        # Cross-type comparisons are allowed for:
        # - lm + lmer (both Gaussian) via LRT
        # - glm + glmer (same family) via LRT
        # - Any combination via AIC/BIC/CV (non-hypothesis methods)
        #
        # Disallowed cross-type pairs (different likelihoods):
        # - lm + glm, lm + glmer, glm + lmer, lmer + glmer
        type_set = set(model_types)
        family_groups = {get_model_family_group(m) for m in models}

        is_valid_cross_type = len(family_groups) == 1 and (
            type_set <= {"lm", "lmer"} or type_set <= {"glm", "glmer"}
        )
        is_ic_or_cv = method in ("aic", "bic", "cv")

        if not is_valid_cross_type and not is_ic_or_cv:
            raise ValueError(
                f"Cannot compare models of types {', '.join(model_types)} "
                f"with method='{method}'. Cross-type hypothesis tests require "
                "compatible families (lm+lmer or glm+glmer with same family). "
                "Use method='aic', 'bic', or 'cv' for non-nested comparison."
            )

    # Check same response
    responses = [m._spec.response_var for m in models]
    if len(set(responses)) > 1:
        raise ValueError(
            f"All models must have the same response variable. Got: {', '.join(responses)}"
        )

    # Check same n observations
    n_obs = [m._bundle.n for m in models]
    if len(set(n_obs)) > 1:
        raise ValueError(
            f"All models must have the same number of observations. Got: {n_obs}"
        )

    # For LRT, check that all models use ML estimation (unless refit=True)
    type_set = set(model_types)
    inferred_method = (
        method if method != "auto" else resolve_method(models[0], model_types=type_set)
    )
    has_mixed = any(t in ("lmer", "glmer") for t in model_types)

    if inferred_method == "lrt" and has_mixed and not refit:
        methods = [m._spec.method for m in models]
        reml_models = [m for m, meth in zip(models, methods) if meth == "reml"]
        if reml_models:
            # REML LRT is valid when all models share the same fixed effects
            # and differ only in random effects structure (see lme4 docs).
            fixed_terms_sets = [set(m._spec.fixed_terms) for m in models]
            same_fixed = all(ft == fixed_terms_sets[0] for ft in fixed_terms_sets)
            if not same_fixed:
                raise ValueError(
                    "LRT requires ML estimation when models have different "
                    "fixed effects, but some models use REML. "
                    "Refit models with method='ml' for valid likelihood ratio "
                    "comparison, or use compare(..., refit=True) to auto-refit. "
                    f"Resolved methods: {methods}"
                )

    return models


def sort_models_by_complexity(models: tuple[Any, ...]) -> list[Any]:
    """Sort models from simplest (fewest parameters) to most complex.

    This matches R's anova() behavior which orders models by df.

    Args:
        models: Tuple of fitted model objects.

    Returns:
        List of models sorted by number of parameters (ascending).
    """

    def get_total_params(m: Any) -> int:
        """Get total parameter count for sorting."""
        model_type = get_model_type(m)
        n_fixed = m._bundle.p
        if model_type == "lmer":
            # Fixed effects + theta + sigma
            return n_fixed + len(m._fit.theta) + 1
        elif model_type == "glmer":
            # Fixed effects + theta (no sigma)
            return n_fixed + len(m._fit.theta)
        else:
            # lm/glm: just fixed effects
            return n_fixed

    return sorted(models, key=get_total_params)


def resolve_method(model: Any, *, model_types: set[str] | None = None) -> str:
    """Infer the appropriate comparison method for a model type.

    For same-type comparisons, reads ``model._model_type`` to determine
    the method. For cross-type comparisons (lm+lmer or glm+glmer),
    returns ``"lrt"`` since the fixed-only model is nested within the
    mixed model via zero variance components.

    Args:
        model: A fitted model object with a ``_model_type`` attribute
            (one of ``"lm"``, ``"glm"``, ``"lmer"``, ``"glmer"``).
        model_types: Set of all model types being compared. When provided,
            enables cross-type method resolution.

    Returns:
        Comparison method: ``"f"`` for lm, ``"lrt"`` for lmer/glmer
        (and cross-type lm+lmer or glm+glmer), ``"deviance"`` for glm.

    Raises:
        ValueError: If the model type cannot be mapped to a comparison method.
    """
    # Cross-type: lm+lmer or glm+glmer → always LRT
    if model_types is not None and len(model_types) > 1:
        return "lrt"

    if model._model_type == "lm":
        return "f"
    elif model._model_type == "glm":
        return "deviance"
    elif model._model_type in ("lmer", "glmer"):
        return "lrt"
    else:
        raise ValueError(f"Unknown model type: {model._model_type}")


def check_nested(
    df_diffs: list[float | int | None],
    stat_diffs: list[float | None],
    model_formulas: list[str],
    method: str,
) -> None:
    """Check that models appear to be nested and raise error if not.

    Non-nested models are detected by:
    - df <= 0: No additional parameters in augmented model
    - stat_diff < 0: Augmented model fits worse (negative SS, deviance reduction, or chi2)

    Args:
        df_diffs: List of df differences for each comparison (None for first model).
        stat_diffs: List of statistic differences (SS, dev_diff, or chi2).
        model_formulas: List of model formula strings.
        method: Comparison method ("f", "deviance", or "lrt").

    Raises:
        ValueError: If models don't appear nested.
    """
    for i, (df, stat) in enumerate(zip(df_diffs, stat_diffs)):
        if df is None:
            continue  # First model has no comparison

        # Check for non-nested indicators
        if df <= 0:
            raise ValueError(
                f"Models don't appear to be nested: df={df} for comparison "
                f"'{model_formulas[i - 1]}' vs '{model_formulas[i]}'. "
                "Nested models should have strictly increasing parameters. "
                "Use method='cv' for cross-validation comparison of non-nested models."
            )

        if stat is not None and stat < 0:
            stat_name = {"f": "SS", "deviance": "deviance reduction", "lrt": "chi2"}[
                method
            ]
            raise ValueError(
                f"Models don't appear to be nested: {stat_name}={stat:.4f} < 0 for "
                f"comparison '{model_formulas[i - 1]}' vs '{model_formulas[i]}'. "
                "The augmented model fits worse than the compact model. "
                "Use method='cv' for cross-validation comparison of non-nested models."
            )
