"""Model comparison utilities for nested model testing.

This module provides the main ``compare()`` entry point that dispatches to
the appropriate comparison strategy based on model type:

- lm: F-test (``f_test.py``)
- glm: Deviance test (``deviance.py``)
- lmer/glmer: Likelihood ratio test (``lrt_compare.py``)
- Any: Cross-validation with Nadeau-Bengio correction (``cv.py``)

Examples:
    ```python
    from bossanova import model, compare, load_dataset
    mtcars = load_dataset("mtcars")
    compact = model("mpg ~ 1", mtcars).fit()
    augmented = model("mpg ~ wt", mtcars).fit()
    compare(compact, augmented)
    # +───────────+──────────+─────────+────+─────────+─────────+──────────+───────+
    # | model     | df_resid | rss     | df | ss      | F       | p_value  | PRE   |
    # +───────────+──────────+─────────+────+─────────+─────────+──────────+───────+
    # | mpg ~ 1   | 31       | 1126.05 |    |         |         |          |       |
    # | mpg ~ wt  | 30       | 278.32  | 1  | 847.73  | 91.375  | 1.29e-10 | 0.753 |
    # +───────────+──────────+─────────+────+─────────+─────────+──────────+───────+
    ```

Notes:
    For single-parameter comparisons, the F-statistic equals t^2:
        F = t^2 where t is the t-statistic for the added parameter.
    This identity is verified in the parity tests.
"""

from typing import Any

import polars as pl

from bossanova.internal.maths.config import get_display_digits
from bossanova.internal.maths.rounding import round_float_columns
from bossanova.internal.compare.cv import compare_cv
from bossanova.internal.compare.deviance import compare_deviance
from bossanova.internal.compare.f_test import compare_f_test
from bossanova.internal.compare.helpers import (
    resolve_method,
    sort_models_by_complexity,
    validate_models,
)
from bossanova.internal.compare.ic import compare_aic, compare_bic
from bossanova.internal.compare.lrt_compare import compare_lrt
from bossanova.internal.compare.refit import refit_with_ml

__all__ = ["compare"]


def compare(
    *models: Any,
    method: str = "auto",
    sort: bool = True,
    test: str = "chisq",
    refit: bool = False,
    cv: int | str = 5,
    seed: int | None = None,
    metric: str = "mse",
    digits: int | None = None,
    holdout_group: str | None = None,
) -> pl.DataFrame:
    """Compare nested statistical models.

    Performs sequential hypothesis tests comparing nested models.
    The appropriate test method is inferred from model type:

    - lm: F-test (equivalent to R's anova())
    - glm: Deviance test (chi-squared)
    - lmer/glmer: Likelihood ratio test
    - cv: Cross-validation with Nadeau-Bengio corrected t-test

    Cross-type comparisons (e.g., glm vs glmer) are supported when models
    share the same family. The fixed-only model is treated as nested within
    the mixed model via zero variance components.

    | Model Pair | Hypothesis Test | AIC/BIC | CV |
    |------------|-----------------|---------|-----|
    | lm vs lm | F-test | Yes | Yes |
    | glm vs glm | Deviance | Yes | Yes |
    | lmer vs lmer | LRT | Yes | Yes |
    | glmer vs glmer | LRT | Yes | Yes |
    | lm vs lmer | LRT | Yes | Yes |
    | glm vs glmer | LRT | Yes | Yes |
    | Different families | — | Yes | Yes |

    Args:
        *models: Two or more fitted model objects.
        method: Comparison method. Options:
            - "auto": Infer from model type (default)
            - "f": F-test (for lm)
            - "lrt": Likelihood ratio test (for mixed models)
            - "deviance": Deviance test (for glm)
            - "cv": Cross-validation comparison (any model type)
            - "aic": AIC comparison with delta-AIC and Akaike weights
            - "bic": BIC comparison with delta-BIC and Schwarz weights
        sort: If True, sort models by complexity before comparing.
            This ensures proper nesting order. Default True.
        refit: If True and models are lmer/glmer with REML estimation,
            automatically refit with ML for valid LRT comparison.
            Original models are not mutated. Default False.
            Note: REML models are accepted without refitting when all
            models share the same fixed effects (valid for comparing
            random effects structures only).
        test: For GLM deviance comparisons only. Options:
            - "chisq": Chi-squared test (default)
            - "f": F-test (for quasi-families with estimated dispersion)
        cv: For CV comparison only. Number of folds or "loo" for leave-one-out.
        seed: For CV comparison only. Random seed for reproducible splits.
        metric: For CV comparison only. Error metric ("mse", "rmse", "mae").
        digits: Number of significant figures for float columns.
            Default ``None`` uses the global setting from
            ``set_display_digits()`` (4 by default).  Pass ``0`` to
            disable rounding entirely.

    Returns:
        DataFrame with comparison results. Columns depend on method:

        For F-test (lm):
            - model: Formula string
            - PRE: Proportional reduction in error
            - F: F-statistic
            - rss: Residual sum of squares
            - ss: Sum of squares explained
            - df: Degrees of freedom for comparison
            - df_resid: Residual degrees of freedom
            - p_value: p-value

        For deviance test (glm):
            - model: Formula string
            - chi2 (or F): Test statistic
            - dev_diff: Deviance reduction
            - deviance: Residual deviance
            - df: Degrees of freedom for comparison
            - df_resid: Residual degrees of freedom
            - p_value: p-value

        For LRT (lmer/glmer):
            - model: Formula string
            - chi2: Likelihood ratio chi-squared statistic
            - npar: Number of parameters
            - AIC: Akaike Information Criterion
            - BIC: Bayesian Information Criterion
            - loglik: Log-likelihood
            - deviance: Deviance (-2 * loglik)
            - df: Degrees of freedom for comparison
            - p_value: p-value

        For CV comparison:
            - model: Formula string
            - PRE: Proportional reduction in error
            - t_stat: Corrected t-statistic
            - cv_score: Mean CV error
            - cv_se: Standard error of CV error
            - diff: Difference from reference (first model)
            - diff_se: Nadeau-Bengio corrected standard error
            - p_value: Two-sided p-value

        For AIC/BIC comparison:
            - model: Formula string
            - npar: Number of estimated parameters
            - loglik: Log-likelihood
            - deviance: Deviance (-2 * loglik)
            - AIC/BIC: Information criteria
            - delta_AIC/delta_BIC: Difference from best model
            - weight: Akaike/Schwarz weight (model probability)

    Raises:
        ValueError: If models are not valid for comparison.

    Examples:
        ```python
        from bossanova import model, compare, load_dataset
        mtcars = load_dataset("mtcars")
        sleepstudy = load_dataset("sleepstudy")

        # Models are auto-fitted if needed (calls .fit() with defaults)
        compare(model("mpg ~ 1", mtcars), model("mpg ~ wt", mtcars))

        # Equivalent to explicit .fit() calls:
        compare(model("mpg ~ 1", mtcars).fit(), model("mpg ~ wt", mtcars).fit())

        # Model objects are fitted in-place, so they're usable after compare()
        compact = model("mpg ~ 1", mtcars)
        full = model("mpg ~ wt", mtcars)
        compare(compact, full)
        full.params  # Works - model was auto-fitted

        # glm example (deviance test)
        compare(
            model("am ~ 1", mtcars, family="binomial"),
            model("am ~ wt", mtcars, family="binomial"),
        )

        # lmer example (likelihood ratio test)
        compare(
            model("Reaction ~ Days + (1|Subject)", sleepstudy).fit(method="ML"),
            model("Reaction ~ Days + (Days|Subject)", sleepstudy).fit(method="ML"),
        )

        # CV example (Nadeau-Bengio corrected)
        compare(
            model("mpg ~ 1", mtcars),
            model("mpg ~ wt", mtcars),
            method="cv", cv=5, seed=42,
        )
        ```

    Notes:
        For single-parameter comparisons in lm models:
            F = t^2
        where t is the t-statistic for the added parameter.
        This identity is fundamental and verified in parity tests.

        For GLM, the deviance difference follows a chi-squared distribution:
            chi2 = deviance_compact - deviance_augmented
        with df = df_compact - df_augmented degrees of freedom.

        For mixed models (lmer/glmer), the LRT statistic is:
            chi2 = 2 * (loglik_augmented - loglik_compact)
        with df = npar_augmented - npar_compact degrees of freedom.
        REML models are accepted when all models share the same fixed
        effects (comparing random effects structures only). Otherwise,
        ML estimation is required — use ``refit=True`` to auto-refit.

        A warning is emitted when any model has singular (boundary) variance
        components, as the chi-squared p-values may be conservative.
        See Self & Liang (1987).

        For CV comparison, the Nadeau-Bengio correction accounts for
        overlapping training sets in k-fold CV:
            var_corrected = var(diff) * (1/k + n_test/n_train)
        This prevents the underestimation of variance that occurs with
        naive paired t-tests on CV folds.

    See Also:
        - lrt: Likelihood ratio test for mixed models
    """
    # Validate and auto-fit models (pass method and refit for REML check)
    models = validate_models(models, method=method, refit=refit)

    # Sort if requested (not applicable for CV or IC methods which sort internally)
    if sort and method not in ("cv", "aic", "bic"):
        model_list = sort_models_by_complexity(models)
    else:
        model_list = list(models)

    # Infer method if auto
    if method == "auto":
        type_set = {m._model_type for m in model_list}
        method = resolve_method(model_list[0], model_types=type_set)

    # For LRT with refit=True, refit REML models with ML
    if method == "lrt" and refit:
        model_list = [refit_with_ml(m) for m in model_list]

    # Dispatch to appropriate comparison function
    if method == "f":
        result = compare_f_test(model_list)
    elif method == "lrt":
        result = compare_lrt(model_list)
    elif method == "deviance":
        result = compare_deviance(model_list, test=test)
    elif method == "cv":
        result = compare_cv(
            model_list,
            cv=cv,
            seed=seed,
            metric=metric,
            holdout_group=holdout_group,
        )
    elif method == "aic":
        result = compare_aic(model_list)
    elif method == "bic":
        result = compare_bic(model_list)
    else:
        raise ValueError(
            f"Unknown method: {method}. "
            "Use 'auto', 'f', 'lrt', 'deviance', 'cv', 'aic', or 'bic'."
        )

    # Round float columns to significant figures (digits=0 disables rounding)
    effective_digits = digits if digits is not None else get_display_digits()
    if effective_digits > 0:
        result = round_float_columns(result, effective_digits)

    return result
