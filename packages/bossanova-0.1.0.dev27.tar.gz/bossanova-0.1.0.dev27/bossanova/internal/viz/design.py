"""Design matrix structure visualization."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

import numpy as np

from bossanova.internal.viz.core import (
    BOSSANOVA_STYLE,
    create_single_panel,
    format_display_labels,
)

if TYPE_CHECKING:
    import seaborn as sns

    from bossanova.model.core import model as BaseModel

__all__ = ["plot_design"]


# =============================================================================
# Column Type Detection
# =============================================================================


def parse_column_type(
    name: str,
) -> Literal["constant", "continuous", "factor"]:
    """Infer the type of a design matrix column from its name.

    Detection rules:
    - "Intercept" -> constant
    - Contains "[" and "]" -> factor (categorical dummy or interaction with categorical)
    - Otherwise -> continuous (including continuous x continuous interactions)

    Args:
        name: Column name from the design matrix.

    Returns:
        Column type as a string literal.
    """
    if name == "Intercept":
        return "constant"
    # Brackets indicate categorical variable (e.g., "cyl[6]" or "cyl[6]:wt")
    if "[" in name and "]" in name:
        return "factor"
    # Everything else is continuous (including "wt:hp" interactions)
    return "continuous"


def group_columns_by_term(X_names: list[str]) -> dict[str, list[int]]:
    """Group design matrix columns by their parent term.

    For example, a factor with 3 levels produces multiple columns like
    "cyl[6]", "cyl[8]" which all belong to term "cyl".

    Args:
        X_names: Column names from the design matrix.

    Returns:
        Dictionary mapping term names to lists of column indices.
    """
    groups: dict[str, list[int]] = {}

    for i, name in enumerate(X_names):
        # Extract base term name
        if name == "Intercept":
            term = "Intercept"
        elif "[" in name and "]" in name:
            # Categorical: "cyl[6]" -> "cyl"
            # Interaction with categorical: "cyl[6]:wt" -> "cyl:wt"
            parts = []
            for part in name.split(":"):
                if "[" in part:
                    parts.append(part.split("[")[0])
                else:
                    parts.append(part)
            term = ":".join(parts)
        elif ":" in name:
            # Continuous interaction: keep as-is
            term = name
        else:
            # Continuous or transformed: use full name as term
            term = name

        if term not in groups:
            groups[term] = []
        groups[term].append(i)

    return groups


def get_contrast_info(model: BaseModel) -> dict[str, str]:
    """Extract contrast/reference level info from model.

    Args:
        model: A bossanova model (fitted or unfitted).

    Returns:
        Dictionary mapping factor names to reference info strings.
        E.g., {"cyl": "Ref: 4", "am": "Ref: 0"}
    """
    info: dict[str, str] = {}

    # Get factors and their levels from bundle
    if not hasattr(model, "_bundle") or model._bundle is None:
        return info

    factor_levels = model._bundle.factor_levels
    contrast_types = dict(getattr(model._bundle, "contrast_types", {}))

    # Merge in FormulaSpec contrast types as fallback (covers set_contrasts())
    formula_spec = getattr(model, "_formula_spec", None)
    if formula_spec is not None:
        fs_types = getattr(formula_spec, "contrast_types", {})
        for factor, ct in fs_types.items():
            if factor not in contrast_types:
                contrast_types[factor] = ct

    for factor, levels in factor_levels.items():
        if len(levels) == 0:
            continue
        ct = contrast_types.get(factor, "treatment")
        if ct == "sum":
            info[factor] = f"Sum (Omit: {levels[-1]})"
        elif ct == "poly":
            info[factor] = "Poly"
        elif ct == "full":
            info[factor] = "Full rank"
        elif ct == "custom":
            info[factor] = "Custom"
        else:
            # treatment (default)
            info[factor] = f"Treatment (Ref: {levels[0]})"

    return info


# =============================================================================
# Main Plot Function
# =============================================================================


_DESIGN_DEFAULT_HEIGHT = 4.0
_DESIGN_DEFAULT_ASPECT = 1.2


def plot_design(
    model: BaseModel,
    *,
    max_rows: int | None = 20,
    annotate_terms: bool = True,
    show_contrast_info: bool = True,
    prettify: bool = False,
    cmap: str | None = None,
    height: float = _DESIGN_DEFAULT_HEIGHT,
    aspect: float = _DESIGN_DEFAULT_ASPECT,
) -> sns.FacetGrid:
    """Plot design matrix as an annotated heatmap.

    Visualizes the structure of the model's design matrix with:
    - Grayscale heatmap (column-normalized so all predictors are visible)
    - Column grouping annotations showing which columns belong to each term
    - Reference level annotations for categorical variables
    - Colored type strip distinguishing constant, continuous, and factor columns

    Works on unfitted models since the design matrix is built at initialization.

    Args:
        model: A bossanova model. Can be fitted or unfitted.
        max_rows: Maximum number of rows to display. If None, shows all rows.
            Large datasets are subsampled evenly for readability.
        annotate_terms: Show term grouping brackets above the heatmap.
        show_contrast_info: Show reference level annotations for categorical terms.
        prettify: Convert term names to human-readable labels (e.g.,
            "wt_hp_ratio" -> "Wt Hp Ratio"). Default False.
        cmap: Matplotlib colormap name. If None (default), uses ``"gray"``
            (grayscale). Pass ``"viridis"`` for a perceptually-uniform
            alternative, or any valid matplotlib colormap name.
        height: Figure height in inches. When both height and aspect are at their
            defaults, sizing adapts to the design matrix dimensions.
        aspect: Width-to-height ratio. When both height and aspect are at their
            defaults, sizing adapts to the design matrix dimensions.

    Returns:
        Seaborn FacetGrid containing the plot.

    Examples:
        ```python
        from bossanova import model, load_dataset
        cars = load_dataset("mtcars")
        m = model("mpg ~ factor(cyl) + wt + wt:cyl", cars)
        # Works before fitting
        m.plot_design()
        # Also works after fitting
        m.fit().plot_design()
        ```
    """
    import matplotlib.pyplot as plt

    # Get design matrix
    X = model._bundle.X
    X_names = model._bundle.X_names

    n_obs, n_cols = X.shape

    # Subsample rows if too many
    if max_rows is not None and n_obs > max_rows:
        # Even sampling across the dataset
        indices = np.linspace(0, n_obs - 1, max_rows, dtype=int)
        X_plot = X[indices]
        row_labels = [f"row {i}" for i in indices]
    else:
        X_plot = X
        row_labels = [f"row {i}" for i in range(n_obs)]

    n_rows_display = X_plot.shape[0]

    # Compute figure size
    if height == _DESIGN_DEFAULT_HEIGHT and aspect == _DESIGN_DEFAULT_ASPECT:
        # Data-adaptive sizing when both params are at defaults
        fig_width = max(6, min(14, 1.0 + n_cols * 0.8))
        fig_height = max(4, min(10, 1.5 + n_rows_display * 0.25))
        figsize = (fig_width, fig_height)
    else:
        figsize = (height * aspect, height)

    # Create single-panel FacetGrid
    g, ax = create_single_panel(figsize)
    style = BOSSANOVA_STYLE

    # Detect data range to choose normalization strategy and colormap
    data_min = np.nanmin(X_plot)
    data_max = np.nanmax(X_plot)
    has_negative = data_min < 0
    has_positive = data_max > 0

    # Column-wise normalization so factors (0/1) and continuous variables
    # are equally visible.  Signed data preserves zero; unsigned maps to [0, 1].
    X_norm = np.empty_like(X_plot, dtype=np.float64)
    for c in range(X_plot.shape[1]):
        col = X_plot[:, c]
        col_min, col_max = np.nanmin(col), np.nanmax(col)
        if col_max - col_min > 0:
            if has_negative and has_positive:
                # Signed: preserve zero, scale symmetrically to [-1, 1]
                abs_max = max(abs(col_min), abs(col_max))
                X_norm[:, c] = col / abs_max
            else:
                X_norm[:, c] = (col - col_min) / (col_max - col_min)
        else:
            # Constant column (e.g. Intercept): map to 1.0
            X_norm[:, c] = 1.0 if col_max != 0 else 0.0

    # Determine normalization range — adapt to data range
    if has_negative and has_positive:
        vmin, vmax = -1.0, 1.0
    elif has_negative:
        vmin, vmax = -1.0, 0.0
    else:
        vmin, vmax = 0, 1.0

    # Default to grayscale; user can override with any matplotlib cmap
    cmap = cmap if cmap is not None else "gray"

    # Column type colors (muted palette, solid fill)
    col_types = [parse_column_type(name) for name in X_names]
    type_colors = {
        "constant": "#9E9E9E",  # Medium gray
        "continuous": "#78909C",  # Blue-gray
        "factor": "#A1887F",  # Warm gray/taupe
    }

    # Plot heatmap (column-normalized so all predictors are visible)
    ax.imshow(
        X_norm,
        aspect="auto",
        cmap=cmap,
        vmin=vmin,
        vmax=vmax,
        interpolation="nearest",
    )

    # Add faint grid lines between rows and columns for clarity
    for row in range(n_rows_display + 1):
        ax.axhline(y=row - 0.5, color="white", linewidth=0.5, alpha=0.6)
    for col in range(n_cols + 1):
        ax.axvline(x=col - 0.5, color="white", linewidth=0.5, alpha=0.6)

    # Add thin colored strip above heatmap for predictor types
    strip_height = 0.4  # Height of the colored strip in data units
    for i, ctype in enumerate(col_types):
        rect = plt.Rectangle(
            (i - 0.5, -0.5 - strip_height),  # Position above the heatmap
            1,
            strip_height,
            facecolor=type_colors[ctype],
            edgecolor="white",
            linewidth=0.5,
            clip_on=False,
        )
        ax.add_patch(rect)

    # Remove x-axis tick labels (term annotations provide the labels)
    ax.set_xticks([])
    ax.set_xticklabels([])

    ax.set_yticks(np.arange(n_rows_display))
    ax.set_yticklabels(row_labels, fontsize=style["font_size"] - 1)

    # Add term grouping annotations above the color strip
    if annotate_terms:
        term_groups = group_columns_by_term(X_names)
        contrast_info = get_contrast_info(model) if show_contrast_info else {}

        # Build display name mapping for terms
        raw_terms = list(term_groups.keys())
        display_terms = format_display_labels(
            raw_terms, max_chars=200, prettify=prettify
        )
        term_display_map = dict(zip(raw_terms, display_terms))

        # Position for term labels (above color strip and column labels)
        y_label = -0.5 - strip_height - 0.3  # Just above the color strip

        for term, col_indices in term_groups.items():
            if len(col_indices) == 0:
                continue

            # Get x position for the term label (center of its columns)
            x_start = min(col_indices)
            x_end = max(col_indices)
            x_center = (x_start + x_end) / 2

            # Build label with optional contrast info
            label = term_display_map.get(term, term)
            base_term = term.split(":")[0] if ":" in term else term
            if base_term in contrast_info:
                label = f"{label}\n({contrast_info[base_term]})"

            # Add bracket/span if term has multiple columns
            if len(col_indices) > 1:
                # Draw bracket line
                bracket_y = -0.5 - strip_height - 0.15
                ax.plot(
                    [x_start - 0.3, x_end + 0.3],
                    [bracket_y, bracket_y],
                    color="#666666",
                    lw=1.5,
                    clip_on=False,
                )
                # Add vertical ticks at ends
                tick_height = 0.1
                ax.plot(
                    [x_start - 0.3, x_start - 0.3],
                    [bracket_y, bracket_y + tick_height],
                    color="#666666",
                    lw=1.5,
                    clip_on=False,
                )
                ax.plot(
                    [x_end + 0.3, x_end + 0.3],
                    [bracket_y, bracket_y + tick_height],
                    color="#666666",
                    lw=1.5,
                    clip_on=False,
                )
                y_label_this = bracket_y - 0.15
            else:
                y_label_this = y_label

            # Add term label
            ax.text(
                x_center,
                y_label_this,
                label,
                ha="center",
                va="bottom",
                fontsize=style["font_size"] - 1,
                clip_on=False,
            )

    # Add title with formula
    title = f"{model.formula}"
    if len(title) > 60:
        # Truncate long formulas
        title = f"{model.formula[:55]}..."
    ax.set_title(title, fontsize=style["title_size"], pad=40 if annotate_terms else 10)

    # Add observation count below heatmap
    obs_text = f"N = {n_obs}"

    # For mixed models, add group counts
    if (
        hasattr(model, "_bundle")
        and model._bundle is not None
        and model._bundle.re_metadata is not None
    ):
        re_meta = model._bundle.re_metadata
        if re_meta.grouping_vars and re_meta.n_groups_list:
            group_counts = [
                f"{name}: {n}"
                for name, n in zip(re_meta.grouping_vars, re_meta.n_groups_list)
            ]
            obs_text += f"  |  Groups: {', '.join(group_counts)}"

    ax.text(
        0.5,
        -0.02,
        obs_text,
        transform=ax.transAxes,
        ha="center",
        va="top",
        fontsize=style["font_size"] - 1,
        color="#666666",
    )

    # Clean border frame — all 4 spines visible
    for spine in ax.spines.values():
        spine.set_visible(True)
        spine.set_linewidth(0.8)
        spine.set_color("#333333")

    g.tight_layout()

    return g
