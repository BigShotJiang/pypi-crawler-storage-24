"""Figure sizing utilities for bossanova visualizations.

Provides functions to compute figure dimensions based on item counts
and layout configurations.
"""

from __future__ import annotations

from typing import Any, Literal

import numpy as np

__all__ = [
    "BOSSANOVA_STYLE",
    "compute_figsize",
    "compute_grid_figsize",
    "compute_heatmap_figsize",
]


# =============================================================================
# Styling Constants
# =============================================================================

BOSSANOVA_STYLE: dict[str, Any] = {
    # Point/marker settings
    "point_size": 80,
    "point_marker": "o",
    "point_edgecolor": "white",
    "point_linewidth": 0.5,
    # Line/whisker settings
    "line_width": 1.5,
    "capsize": 0,
    # Confidence band settings
    "ci_alpha": 0.3,
    # Reference line settings
    "ref_line_color": "#888888",
    "ref_line_style": "--",
    "ref_line_width": 1.0,
    # Font settings
    "font_size": 10,
    "title_size": 12,
    "label_size": 10,
    # Color palette
    "palette": "tab10",
    # Grid settings
    "grid_alpha": 0.3,
    "grid_style": "-",
    # Heatmap sizing (VIF, design, correlation)
    "heatmap_cell_size": 0.7,
    "heatmap_min_size": 3.5,
    "heatmap_max_width": 10.0,
    "heatmap_max_height": 12.0,
    "heatmap_colorbar_pad": 0.12,
}


# =============================================================================
# Sizing Utilities
# =============================================================================


def compute_figsize(
    n_items: int,
    orientation: Literal["horizontal", "vertical"] = "horizontal",
    item_size: float = 0.4,
    min_size: float = 3.0,
    max_size: float = 12.0,
    base_width: float = 8.0,
    max_label_len: int = 0,
) -> tuple[float, float]:
    """Compute figure size based on number of items.

    Creates readable plots for 15-20 parameters by default.
    Clamps dimensions to prevent too-small or too-large figures.

    Args:
        n_items: Number of items (parameters, groups, etc.) to display.
        orientation: Plot orientation.
            - "horizontal": Items on y-axis (forest plot style).
            - "vertical": Items on x-axis (bar chart style).
        item_size: Inches per item. Default 0.4 works well for forest plots.
        min_size: Minimum dimension in inches.
        max_size: Maximum dimension in inches.
        base_width: Base width for horizontal orientation (height for vertical).
        max_label_len: Longest label character count. For horizontal (forest)
            plots, increases base_width when labels exceed 12 chars.

    Returns:
        Tuple of (width, height) in inches.

    Examples:
        ```python
        compute_figsize(15)  # 15 parameters
        # (8.0, 6.0)
        compute_figsize(30)  # Clamped to max
        # (8.0, 12.0)
        ```
    """
    computed = np.clip(n_items * item_size, min_size, max_size)

    # Widen for long labels in horizontal (forest) plots
    effective_width = base_width
    if orientation == "horizontal" and max_label_len > 12:
        effective_width = base_width + (max_label_len - 12) * 0.08

    if orientation == "horizontal":
        return (effective_width, computed)
    return (computed, effective_width)


def compute_grid_figsize(
    n_rows: int,
    n_cols: int,
    cell_width: float = 4.0,
    cell_height: float = 3.5,
) -> tuple[float, float]:
    """Compute figure size for grid/subplot layouts.

    Args:
        n_rows: Number of subplot rows.
        n_cols: Number of subplot columns.
        cell_width: Width per cell in inches.
        cell_height: Height per cell in inches.

    Returns:
        Tuple of (width, height) in inches.

    Examples:
        ```python
        compute_grid_figsize(2, 2)  # 2x2 diagnostic grid
        # (8.0, 7.0)
        ```
    """
    return (n_cols * cell_width, n_rows * cell_height)


def compute_heatmap_figsize(
    n_rows: int,
    n_cols: int,
    *,
    cell_size: float | None = None,
    include_colorbar: bool = True,
    annotation_lines: int = 0,
    annotation_height: float = 0.18,
    max_label_len: int = 0,
) -> tuple[float, float]:
    """Compute figure size for heatmaps (VIF, design, correlation).

    Uses rectangular scaling (not square) to prevent oversized plots
    when there are few items but annotation text above.

    Args:
        n_rows: Number of heatmap rows.
        n_cols: Number of heatmap columns.
        cell_size: Size per cell in inches (uses style default if None).
        include_colorbar: Reserve space for colorbar.
        annotation_lines: Number of text lines above the heatmap.
        annotation_height: Height per annotation line in inches.
        max_label_len: Longest tick-label character count. Reserves extra
            height for rotated x-tick labels when labels are long.

    Returns:
        Tuple of (width, height) in inches.

    Examples:
        ```python
        compute_heatmap_figsize(3, 3)  # 3x3 correlation matrix
        # (2.35, 3.2)
        compute_heatmap_figsize(3, 3, annotation_lines=3)  # With VIF text
        # (2.35, 3.74)
        compute_heatmap_figsize(10, 10)  # Larger matrix
        # (7.84, 8.1)
        ```
    """
    style = BOSSANOVA_STYLE
    cell = cell_size if cell_size is not None else style["heatmap_cell_size"]

    # Base dimensions from cell count
    width = n_cols * cell
    height = n_rows * cell

    # Colorbar adds width
    if include_colorbar:
        width *= 1 + style["heatmap_colorbar_pad"]

    # Annotation text above plot
    if annotation_lines > 0:
        height += annotation_lines * annotation_height

    # Space for rotated x-tick labels — adaptive to label length
    label_space = max(0.6, max_label_len * 0.055) if max_label_len > 0 else 0.6
    height += label_space

    # Clamp to style limits
    width = max(style["heatmap_min_size"], min(style["heatmap_max_width"], width))
    height = max(style["heatmap_min_size"], min(style["heatmap_max_height"], height))

    return (width, height)
