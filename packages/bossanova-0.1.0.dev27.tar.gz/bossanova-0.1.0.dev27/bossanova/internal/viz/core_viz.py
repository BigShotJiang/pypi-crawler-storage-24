"""Plot helper utilities, label formatting, type inference, and FacetGrid support.

Provides low-level helpers used by individual plot modules:
- Axes setup and reference lines
- P-value formatting
- Label prettification
- Categorical type detection
- Column dtype coercion
- FacetGrid kwargs building and finalization
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Literal

import polars as pl

from bossanova.internal.viz.core_sizing import BOSSANOVA_STYLE

if TYPE_CHECKING:
    from matplotlib.axes import Axes
    from matplotlib.figure import Figure

__all__ = [
    "add_ref_line",
    "build_facetgrid_kwargs",
    "coerce_to_column_dtype",
    "create_multi_panel",
    "create_single_panel",
    "finalize_facetgrid",
    "format_display_label",
    "format_display_labels",
    "format_pvalue_annotation",
    "is_categorical",
    "prettify_label",
    "prettify_labels",
    "setup_ax",
    "strip_transform_wrapper",
]


# =============================================================================
# Label Utilities
# =============================================================================


def strip_transform_wrapper(label: str) -> str:
    """Strip transform wrapper(s) from a term name, keeping the inner variable.

    Recursively removes outer transform calls to expose the original
    variable name used in the data.

    Args:
        label: Term name, possibly wrapped in transforms.

    Returns:
        The innermost variable name with transforms removed.

    Examples:
        ```python
        strip_transform_wrapper("center(reaction_time)")  # "reaction_time"
        strip_transform_wrapper("scale(log(income))")     # "income"
        strip_transform_wrapper("poly(x, 2).1")           # "x.1"
        strip_transform_wrapper("wt")                     # "wt"
        strip_transform_wrapper("cyl[6]")                 # "cyl[6]"
        strip_transform_wrapper("center(x):wt")           # "x:wt"
        ```
    """
    if not label:
        return label

    # Interaction terms: strip each part independently
    if ":" in label:
        parts = label.split(":")
        return ":".join(strip_transform_wrapper(p) for p in parts)

    # Transform wrapper: func(inner) or func(inner, args)
    if "(" in label and label.endswith(")"):
        paren_idx = label.index("(")
        inner = label[paren_idx + 1 : -1]
        # For poly(x, 2) style: extract the variable (first arg before comma)
        if ", " in inner:
            inner = inner.split(", ")[0]
        # Recurse to handle nested transforms like scale(log(x))
        return strip_transform_wrapper(inner)

    # poly(x, 2).1 style suffix (already partially stripped above)
    # Handle "func(inner).suffix" — e.g. the full label "poly(x, 2).1"
    if "(" in label and ")." in label:
        base, suffix = label.rsplit(").", 1)
        inner = base[base.index("(") + 1 :]
        if ", " in inner:
            inner = inner.split(", ")[0]
        return f"{strip_transform_wrapper(inner)}.{suffix}"

    return label


def prettify_label(label: str) -> str:
    """Convert column/term name to human-readable label.

    Transformations applied:
    - Transform wrappers preserved: center(reaction_time) -> center(Reaction Time)
    - snake_case -> Title Case
    - Interaction terms (wt:hp -> wt x hp)
    - Preserves already-formatted labels (starts uppercase, no underscores)

    Args:
        label: Raw column or term name.

    Returns:
        Prettified label string.

    Examples:
        ```python
        prettify_label("wt_hp_ratio")  # "Wt Hp Ratio"
        prettify_label("log_income")   # "Log Income"
        prettify_label("wt:hp")        # "wt x hp"
        prettify_label("Income")       # "Income" (preserved)
        prettify_label("hp")           # "Hp"
        prettify_label("center(reaction_time)")  # "center(Reaction Time)"
        ```
    """
    if not label:
        return label

    # Transform wrappers: center(reaction_time) -> center(Reaction Time)
    if "(" in label and label.endswith(")"):
        paren_idx = label.index("(")
        wrapper = label[:paren_idx]
        inner = label[paren_idx + 1 : -1]
        return f"{wrapper}({prettify_label(inner)})"

    # Already formatted (starts uppercase, no underscores or colons)
    if label[0].isupper() and "_" not in label and ":" not in label:
        return label

    # R-style interaction terms
    if ":" in label:
        parts = label.split(":")
        return " \u00d7 ".join(prettify_label(p) for p in parts)

    # Snake case to title case
    words = label.replace("_", " ").split()
    return " ".join(w.capitalize() for w in words)


def prettify_labels(labels: list[str]) -> list[str]:
    """Prettify a list of labels.

    Args:
        labels: List of raw column or term names.

    Returns:
        List of prettified label strings.

    Examples:
        ```python
        prettify_labels(["wt", "hp", "wt:hp"])
        # ["Wt", "Hp", "wt x hp"]
        ```
    """
    return [prettify_label(lbl) for lbl in labels]


def format_display_label(label: str, max_chars: int = 25) -> str:
    """Truncate label for tick display, preserving transform structure.

    Handles long labels from transformed variables (e.g.,
    ``center(reaction_time_ms)``) by truncating while keeping the
    transform wrapper visible.

    Args:
        label: Label string (raw or prettified).
        max_chars: Maximum character length. Labels within this limit
            are returned unchanged.

    Returns:
        Label truncated to fit within *max_chars*, with ellipsis if needed.

    Examples:
        ```python
        format_display_label("center(reaction_time_ms)", 20)
        # "center(reaction_t\u2026)"
        format_display_label("short", 25)
        # "short"
        ```
    """
    if len(label) <= max_chars:
        return label

    # Transform wrapper: truncate inner, keep wrapper name
    if "(" in label and label.endswith(")"):
        paren_idx = label.index("(")
        wrapper = label[:paren_idx]
        inner = label[paren_idx + 1 : -1]
        # Budget: wrapper + "(" + inner + ")" — need at least 3 chars for inner
        inner_budget = max_chars - len(wrapper) - 3  # parens + ellipsis
        if inner_budget >= 3:
            return f"{wrapper}({format_display_label(inner, inner_budget)})"

    return label[: max_chars - 1] + "\u2026"


def format_display_labels(
    labels: list[str],
    *,
    max_chars: int = 25,
    prettify: bool = False,
    strip_transforms: bool = True,
) -> list[str]:
    """Strip transforms + prettify + truncate + deduplicate labels for display.

    Unified entry point for tick-label formatting. Applies transform
    stripping (by default), optional prettification, truncation, and
    deduplication in sequence.

    Args:
        labels: Raw column or term names.
        max_chars: Maximum character length per label.
        prettify: Apply ``prettify_label`` before truncation.
        strip_transforms: Remove transform wrappers (e.g.
            ``center(x)`` → ``x``) before other formatting.
            Default True.

    Returns:
        List of display-ready label strings. If truncation creates
        duplicates, numeric suffixes are appended.

    Examples:
        ```python
        format_display_labels(["wt", "hp"], prettify=True)
        # ["Wt", "Hp"]
        format_display_labels(["center(x)", "scale(y)"])
        # ["x", "y"]
        format_display_labels(
            ["center(long_variable_name)", "scale(long_variable_name)"],
            max_chars=20,
            strip_transforms=False,
        )
        # ["center(long_varia\u2026)", "scale(long_variab\u2026)"]
        ```
    """
    result = labels
    if strip_transforms:
        result = [strip_transform_wrapper(lbl) for lbl in result]
    if prettify:
        result = prettify_labels(result)
    result = [format_display_label(lbl, max_chars) for lbl in result]

    # Deduplicate: if truncation created collisions, append numeric suffix
    seen: dict[str, int] = {}
    deduped: list[str] = []
    for lbl in result:
        if lbl in seen:
            seen[lbl] += 1
            deduped.append(f"{lbl} ({seen[lbl]})")
        else:
            seen[lbl] = 0
            deduped.append(lbl)

    # Only use deduped if there were actual collisions
    if any(v > 0 for v in seen.values()):
        return deduped
    return result


# =============================================================================
# FacetGrid Panel Helpers
# =============================================================================


def create_single_panel(
    figsize: tuple[float, float],
) -> tuple[Any, Any]:
    """Create a single-panel FacetGrid for matplotlib-native plots.

    Wraps a plain matplotlib axes in a FacetGrid so that all plot
    functions return a consistent type.

    Args:
        figsize: Desired (width, height) in inches.

    Returns:
        Tuple of (FacetGrid, Axes) where the FacetGrid wraps a single
        panel and the Axes is ready for direct matplotlib drawing.
    """
    import seaborn as sns

    height = figsize[1]
    aspect = figsize[0] / figsize[1] if figsize[1] > 0 else 1.0
    g = sns.FacetGrid(
        data=pl.DataFrame({"_": [0]}),
        height=height,
        aspect=aspect,
    )
    ax = g.axes.flat[0]
    return g, ax


def create_multi_panel(
    n_panels: int,
    *,
    col_wrap: int = 3,
    height: float = 4.0,
    aspect: float = 1.0,
) -> tuple[Any, list[Any]]:
    """Create a multi-panel FacetGrid for matplotlib-native plots.

    Args:
        n_panels: Number of panels to create.
        col_wrap: Number of columns before wrapping.
        height: Height of each panel in inches.
        aspect: Aspect ratio of each panel.

    Returns:
        Tuple of (FacetGrid, list[Axes]) where each Axes is ready for
        direct matplotlib drawing.
    """
    import seaborn as sns

    dummy = pl.DataFrame({"_panel": list(range(n_panels))})
    g = sns.FacetGrid(
        dummy,
        col="_panel",
        col_wrap=min(col_wrap, n_panels),
        height=height,
        aspect=aspect,
    )
    return g, list(g.axes.flat)


# =============================================================================
# Plot Helpers
# =============================================================================


def setup_ax(
    ax: "Axes | None",
    figsize: tuple[float, float] | None = None,
) -> "tuple[Figure, Axes]":
    """Set up matplotlib axes, creating figure if needed.

    Args:
        ax: Existing axes or None to create new figure.
        figsize: Figure size if creating new figure.

    Returns:
        Tuple of (figure, axes).
    """
    import matplotlib.pyplot as plt

    if ax is None:
        fig, ax = plt.subplots(figsize=figsize)
    else:
        fig = ax.get_figure()

    return fig, ax


def add_ref_line(
    ax: "Axes",
    value: float = 0.0,
    orientation: Literal["horizontal", "vertical"] = "vertical",
) -> None:
    """Add reference line to axes.

    Args:
        ax: Matplotlib axes.
        value: Position of reference line.
        orientation: Line orientation.
    """
    style = BOSSANOVA_STYLE

    if orientation == "vertical":
        ax.axvline(
            value,
            color=style["ref_line_color"],
            linestyle=style["ref_line_style"],
            linewidth=style["ref_line_width"],
            zorder=0,
        )
    else:
        ax.axhline(
            value,
            color=style["ref_line_color"],
            linestyle=style["ref_line_style"],
            linewidth=style["ref_line_width"],
            zorder=0,
        )


def format_pvalue_annotation(p: float) -> str:
    """Format p-value for plot annotation.

    Args:
        p: P-value.

    Returns:
        Formatted string with significance stars.
    """
    if p < 0.001:
        return "***"
    elif p < 0.01:
        return "**"
    elif p < 0.05:
        return "*"
    elif p < 0.1:
        return "."
    return ""


# =============================================================================
# Type Inference Helpers
# =============================================================================


def coerce_to_column_dtype(
    values: list[Any],
    data: pl.DataFrame,
    column: str,
) -> list[Any]:
    """Coerce user-provided values to match a data column's dtype.

    Handles type mismatches between user input (often strings) and actual
    column types (integers, floats, categoricals). This enables user-friendly
    APIs where users can write ``groups=["308", "309"]`` even when the column
    contains integers.

    Args:
        values: User-provided values to coerce.
        data: DataFrame containing the target column.
        column: Column name to match dtype against.

    Returns:
        Values coerced to match the column dtype. Returns original values
        if coercion fails or dtype is not recognized.

    Examples:
        ```python
        # Integer column with string input
        df = pl.DataFrame({"id": [1, 2, 3]})
        coerce_to_column_dtype(["1", "2"], df, "id")
        # [1, 2]

        # Float column
        df = pl.DataFrame({"value": [1.0, 2.0]})
        coerce_to_column_dtype(["1.5", 2], df, "value")
        # [1.5, 2.0]

        # String column (no change needed)
        df = pl.DataFrame({"name": ["a", "b"]})
        coerce_to_column_dtype([1, 2], df, "name")
        # ["1", "2"]
        ```
    """
    if not values:
        return values

    dtype = data[column].dtype

    try:
        # Integer types
        if dtype in (
            pl.Int8,
            pl.Int16,
            pl.Int32,
            pl.Int64,
            pl.UInt8,
            pl.UInt16,
            pl.UInt32,
            pl.UInt64,
        ):
            return [int(v) for v in values]
        # Float types
        elif dtype in (pl.Float32, pl.Float64):
            return [float(v) for v in values]
        # String types
        elif dtype in (pl.String, pl.Utf8):
            return [str(v) for v in values]
        # Categorical/Enum - coerce to string (physical representation)
        elif dtype == pl.Categorical or isinstance(dtype, pl.Enum):
            return [str(v) for v in values]
        else:
            # Unknown dtype, return as-is
            return values
    except (ValueError, TypeError):
        # Coercion failed, return original values
        return values


def is_categorical(data: pl.DataFrame, term: str) -> bool:
    """Check if a term is categorical.

    A term is considered categorical if:
    - Its dtype is Categorical, Utf8, or String
    - It has fewer than 10 unique values (heuristic for integer codes)

    Args:
        data: Polars DataFrame containing the term.
        term: Column name to check.

    Returns:
        True if the term is categorical.

    Examples:
        ```python
        is_categorical(df, "species")  # String column -> True
        is_categorical(df, "cyl")      # 3 unique ints -> True
        is_categorical(df, "mpg")      # Many unique floats -> False
        ```
    """
    dtype = data[term].dtype
    return dtype in (pl.Categorical, pl.Utf8, pl.String) or data[term].n_unique() < 10


# =============================================================================
# FacetGrid Helpers
# =============================================================================


def build_facetgrid_kwargs(
    data: pl.DataFrame,
    height: float,
    aspect: float,
    col_wrap: int | None = None,
    hue: str | None = None,
    col: str | None = None,
    row: str | None = None,
    palette: str | None = None,
    sharex: bool = True,
    sharey: bool = True,
) -> dict[str, Any]:
    """Build standardized kwargs dict for FacetGrid/relplot/catplot.

    Creates a kwargs dictionary with consistent parameter handling for
    seaborn grid-based plotting functions.

    Args:
        data: Polars DataFrame to plot (passed directly to seaborn).
        height: Height of each facet in inches.
        aspect: Aspect ratio of each facet (width = height * aspect).
        col_wrap: Wrap column facets after this many columns. Ignored if row is set.
        hue: Variable name for color grouping.
        col: Variable name for column faceting.
        row: Variable name for row faceting.
        palette: Color palette name (uses BOSSANOVA_STYLE default if hue set but no palette).
        sharex: Share x-axis across facets.
        sharey: Share y-axis across facets.

    Returns:
        Dictionary of kwargs ready for sns.FacetGrid, relplot, or catplot.

    Examples:
        ```python
        kwargs = build_facetgrid_kwargs(df, height=4.0, aspect=1.2, col="group")
        g = sns.FacetGrid(**kwargs)
        ```
    """
    kwargs: dict[str, Any] = {
        "data": data,
        "height": height,
        "aspect": aspect,
        "sharex": sharex,
        "sharey": sharey,
    }

    if col is not None:
        kwargs["col"] = col
    if row is not None:
        kwargs["row"] = row
    if col_wrap is not None and row is None:
        kwargs["col_wrap"] = col_wrap
    if hue is not None:
        kwargs["hue"] = hue
        kwargs["palette"] = palette or BOSSANOVA_STYLE["palette"]

    return kwargs


def finalize_facetgrid(
    g: Any,  # sns.FacetGrid or sns.PairGrid
    title: str | None = None,
    xlabel: str | None = None,
    ylabel: str | None = None,
) -> Any:
    """Apply standard styling and layout to a FacetGrid.

    Applies consistent bossanova styling: despine, tight_layout, and title.

    Args:
        g: Seaborn FacetGrid or PairGrid object.
        title: Optional title to add above the plot.
        xlabel: Optional x-axis label.
        ylabel: Optional y-axis label.

    Returns:
        The same FacetGrid/PairGrid object (for chaining).

    Examples:
        ```python
        g = sns.FacetGrid(df, col="group")
        g.map_dataframe(my_plot_func)
        finalize_facetgrid(g, title="My Plot", xlabel="X", ylabel="Y")
        ```
    """
    import seaborn as sns

    style = BOSSANOVA_STYLE

    if xlabel or ylabel:
        g.set_axis_labels(xlabel or "", ylabel or "")

    if title:
        g.figure.suptitle(title, y=1.02, fontsize=style["title_size"])

    sns.despine()
    g.tight_layout()

    return g
