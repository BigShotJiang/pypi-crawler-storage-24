"""Marginal effects visualization for bossanova models.

This module provides plot_explore() for visualizing marginal estimated effects
(MEEs) from model.explore() output. Supports three result types:
- **means**: Categorical EMMs (point + error bar) or continuous trends (line + ribbon)
- **slopes**: Marginal effects as forest plot (single) or per-condition (crossed)
- **contrasts**: Pairwise/sequential/custom comparisons as forest plot

The slopes and contrasts drawing logic lives in ``mem_forest.py``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

import numpy as np
import polars as pl

from bossanova.internal.containers.schemas import Col
from bossanova.internal.viz.core import (
    BOSSANOVA_STYLE,
    format_display_label,
)

if TYPE_CHECKING:
    from typing import Any

    import seaborn as sns
    from matplotlib.axes import Axes


__all__ = ["plot_explore"]


# =============================================================================
# Stat columns (used to identify grid vs. data columns)
# =============================================================================

_STAT_COLS = frozenset(
    {
        Col.ESTIMATE,
        Col.SE,
        Col.DF,
        "t_value",
        Col.P_VALUE,
        Col.CI_LOWER,
        Col.CI_UPPER,
        Col.TERM,
        Col.LEVEL,
        Col.STATISTIC,
    }
)


# =============================================================================
# Main entry point
# =============================================================================


def plot_explore(
    model: "Any",
    specs: str,
    *,
    hue: str | None = None,
    col: str | None = None,
    row: str | None = None,
    effect_scale: Literal["link", "response"] = "response",
    conf_int: float = 0.95,
    prettify: bool = False,
    height: float = 4.0,
    aspect: float = 1.2,
    palette: str | None = None,
    col_wrap: int | None = None,
    show_pvalue: bool = False,
    ref_line: float | None = None,
    precomputed_emm: pl.DataFrame | None = None,
) -> sns.FacetGrid:
    """Plot marginal estimated effects.

    Dispatches to the appropriate plot type based on the result of
    ``model.explore(specs)``:

    - **means** (categorical focal): Point + error bar per level, or
      line + CI ribbon when focal variable is numeric with >2 values.
    - **slopes** (continuous focal): Forest-plot style for single
      slopes; point + error bar per condition for crossed slopes.
    - **contrasts** (``pairwise()``, ``sequential()``, etc.): Forest
      plot with a reference line at 0.

    When ``precomputed_emm`` is provided, the function skips the
    ``model.explore().infer()`` call and uses the supplied DataFrame
    directly, inferring the plot type from column structure.

    Args:
        model: A fitted bossanova model.
        specs: Explore formula, e.g. ``"treatment"``, ``"x"``,
            ``"pairwise(treatment)"``, ``"x ~ z"``.
        hue: Color encoding variable for grouping (dodged on same plot).
            Auto-detected from conditioning columns when None.
        col: Column faceting variable.
        row: Row faceting variable.
        effect_scale: ``"link"`` or ``"response"`` (default).
            Matches ``model.explore(effect_scale=...)``.
        conf_int: Confidence level (default 0.95).
        prettify: Convert axis labels to human-readable format.
        height: Height of each facet in inches.
        aspect: Aspect ratio of each facet.
        palette: Color palette name (default: BOSSANOVA_STYLE palette).
        col_wrap: Number of columns before wrapping facets to a new row.
            Only used when ``col`` is set.
        show_pvalue: Add significance stars (for contrasts/slopes).
        ref_line: Reference line position. Auto-set to 0 for
            contrasts/slopes if not specified.
        precomputed_emm: Pre-computed effects DataFrame (from
            ``model.effects``). Skips ``explore().infer()``.

    Returns:
        Seaborn FacetGrid containing the plot.

    Raises:
        RuntimeError: If model is not fitted.
        AttributeError: If model doesn't have explore method and no
            pre-computed data is provided.

    Examples:
        ::

            from bossanova import model, viz, load_dataset
            mtcars = load_dataset("mtcars")
            m = model("mpg ~ factor(cyl) + wt + hp", mtcars).fit()

            # Categorical EMMs
            m.explore("cyl").infer()
            m.plot_explore("cyl")

            # Continuous slope
            m.explore("wt").infer()
            m.plot_explore("wt")

            # Pairwise contrasts (forest plot)
            m.explore("pairwise(cyl)").infer()
            m.plot_explore("pairwise(cyl)")

            # Crossed: slopes at multiple levels
            m.explore("wt ~ cyl").infer()
            m.plot_explore("wt ~ cyl")

    See Also:
        plot_predict: Marginal predictions across predictor range.
        plot_params: Fixed effects forest plot.
    """
    from bossanova.internal.viz.mem_forest import _plot_contrasts, _plot_slopes

    if not model._is_fitted:
        raise RuntimeError("Model must be fitted before plotting effects")

    style = BOSSANOVA_STYLE
    if palette is None:
        palette = style["palette"]

    # Compute or retrieve effects data
    if precomputed_emm is not None:
        effects_df = precomputed_emm
        result_type = _infer_type_from_df(effects_df)
        focal_var = _infer_focal_from_df(effects_df)
    else:
        if not hasattr(model, "explore"):
            raise AttributeError(f"{type(model).__name__} does not have explore method")

        # Save model state so plot_explore doesn't clobber _mee/_last_op.
        # Follows the predict.py:274-279 pattern.
        from bossanova.model.result import ModelResult

        _core = model._model if isinstance(model, ModelResult) else model
        saved_mee = _core._mee
        saved_last_op = _core._last_op

        # Compute MEEs via explore().infer()
        model.explore(specs, effect_scale=effect_scale).infer(conf_level=conf_int)
        effects_df = model.effects
        mee = model._mee
        result_type = mee.type
        focal_var = mee.focal_var

        # Restore model state
        _core._mee = saved_mee
        _core._last_op = saved_last_op

    # Add faceting columns validation
    if col is not None and col not in effects_df.columns:
        raise ValueError(f"Column '{col}' not found in data")
    if row is not None and row not in effects_df.columns:
        raise ValueError(f"Row '{row}' not found in data")

    # Dispatch to the appropriate plot type
    if result_type == "contrasts":
        return _plot_contrasts(
            effects_df,
            focal_var=focal_var,
            specs=specs,
            col=col,
            row=row,
            prettify=prettify,
            height=height,
            aspect=aspect,
            palette=palette,
            col_wrap=col_wrap,
            style=style,
            show_pvalue=show_pvalue,
            ref_line=ref_line if ref_line is not None else 0.0,
        )
    elif result_type == "slopes":
        return _plot_slopes(
            effects_df,
            focal_var=focal_var,
            specs=specs,
            hue=hue,
            col=col,
            row=row,
            prettify=prettify,
            height=height,
            aspect=aspect,
            palette=palette,
            col_wrap=col_wrap,
            style=style,
            show_pvalue=show_pvalue,
            ref_line=ref_line if ref_line is not None else 0.0,
        )
    else:
        # means
        return _plot_means(
            effects_df,
            focal_var=focal_var,
            specs=specs,
            hue=hue,
            col=col,
            row=row,
            prettify=prettify,
            height=height,
            aspect=aspect,
            palette=palette,
            col_wrap=col_wrap,
            style=style,
        )


# =============================================================================
# Type and focal variable inference (for precomputed data)
# =============================================================================


def _infer_type_from_df(df: pl.DataFrame) -> str:
    """Infer the explore result type from DataFrame columns.

    Args:
        df: Effects DataFrame.

    Returns:
        ``"contrasts"``, ``"slopes"``, or ``"means"``.
    """
    if Col.CONTRAST in df.columns:
        return "contrasts"
    # Single-row with "marginal_effect" in a grid column → slopes
    grid_cols = _grid_columns(df)
    for col_name in grid_cols:
        vals = df[col_name].to_list()
        if any(str(v) == "marginal_effect" for v in vals):
            return "slopes"
    return "means"


def _infer_focal_from_df(df: pl.DataFrame) -> str:
    """Infer the focal variable from DataFrame columns.

    Args:
        df: Effects DataFrame.

    Returns:
        Name of the focal variable column.
    """
    if Col.CONTRAST in df.columns:
        return Col.CONTRAST
    grid_cols = _grid_columns(df)
    # Focal variable is the last grid column (conditions come first)
    if grid_cols:
        return grid_cols[-1]
    return Col.TERM


def _grid_columns(df: pl.DataFrame) -> list[str]:
    """Extract grid columns (non-statistic columns) from effects DataFrame.

    Args:
        df: Effects DataFrame.

    Returns:
        List of column names that are part of the grid.
    """
    return [c for c in df.columns if c not in _STAT_COLS]


def condition_columns(df: pl.DataFrame, focal_var: str) -> list[str]:
    """Extract condition columns (grid columns excluding focal variable).

    Args:
        df: Effects DataFrame.
        focal_var: Name of the focal variable.

    Returns:
        List of condition column names.
    """
    return [c for c in _grid_columns(df) if c != focal_var]


def _is_numeric_focal(df: pl.DataFrame, focal_var: str) -> bool:
    """Check if the focal variable values are numeric.

    Args:
        df: Effects DataFrame.
        focal_var: Column name to check.

    Returns:
        True if the column is numeric or has >2 values that parse as floats.
    """
    if focal_var not in df.columns:
        return False
    dtype = df[focal_var].dtype
    if dtype.is_float() or dtype.is_integer():
        return True
    # Try parsing string values as numbers
    vals = df[focal_var].unique().to_list()
    try:
        [float(v) for v in vals]
        return len(vals) > 2
    except (ValueError, TypeError):
        return False


def prettify_if(label: str, prettify: bool) -> str:
    """Apply single-label prettification if enabled.

    Args:
        label: Raw label string.
        prettify: Whether to apply formatting.

    Returns:
        Formatted or original label.
    """
    if prettify:
        return format_display_label(label)
    return label


# =============================================================================
# Means plot (categorical EMMs or continuous trend)
# =============================================================================


def _plot_means(
    df: pl.DataFrame,
    *,
    focal_var: str,
    specs: str,
    hue: str | None,
    col: str | None,
    row: str | None,
    prettify: bool,
    height: float,
    aspect: float,
    palette: str,
    col_wrap: int | None,
    style: dict,
) -> "sns.FacetGrid":
    """Plot estimated marginal means.

    Categorical focal variables are plotted as points + error bars.
    Numeric focal variables (e.g., ``x@range(5)``) are plotted as
    lines + CI ribbon.

    Args:
        df: Effects DataFrame with grid + estimate + inference columns.
        focal_var: Name of the focal variable column.
        specs: Original explore formula string.
        hue: Hue grouping variable (auto-detected from conditions if None).
        col: Faceting column variable.
        row: Faceting row variable.
        prettify: Apply label prettification.
        height: Facet height in inches.
        aspect: Facet aspect ratio.
        palette: Color palette name.
        col_wrap: Number of columns before wrapping facets.
        style: BOSSANOVA_STYLE dictionary.

    Returns:
        Seaborn FacetGrid.
    """
    import seaborn as sns

    # Detect if we should use line + ribbon for numeric focal
    use_line = _is_numeric_focal(df, focal_var)

    # Auto-detect hue and col from condition columns
    cond_cols = condition_columns(df, focal_var)
    if cond_cols:
        available = [c for c in cond_cols if c != col and c != row]
        if hue is None and available:
            hue = available[0]
            available = available[1:]
        if col is None and available:
            col = available[0]

    # Build FacetGrid
    facet_kwargs: dict[str, Any] = {
        "data": df,
        "height": height,
        "aspect": aspect,
    }
    if hue is not None and hue in df.columns:
        facet_kwargs["hue"] = hue
        facet_kwargs["palette"] = palette
    if col is not None:
        facet_kwargs["col"] = col
    if row is not None:
        facet_kwargs["row"] = row
    if col_wrap is not None:
        facet_kwargs["col_wrap"] = col_wrap

    g = sns.FacetGrid(**facet_kwargs)

    if use_line:
        g.map_dataframe(
            _draw_means_line,
            focal_var=focal_var,
            style=style,
        )
    else:
        g.map_dataframe(
            _draw_means_points,
            focal_var=focal_var,
            hue=hue,
            style=style,
            palette=palette,
        )

    # Labels
    focal_label = prettify_if(focal_var, prettify)
    specs_label = prettify_if(specs, prettify)
    g.set_axis_labels(focal_label, "Estimated Marginal Mean")
    g.figure.suptitle(
        f"Estimated Marginal Means: {specs_label}",
        y=1.02,
        fontsize=style["title_size"],
    )

    if hue is not None:
        g.add_legend(title=prettify_if(hue, prettify))

    sns.despine()
    g.tight_layout()
    return g


def _draw_means_points(
    data: "Any",
    *,
    focal_var: str,
    hue: str | None,
    style: dict,
    palette: str,
    **kwargs: "Any",
) -> None:
    """Draw EMM points + error bars for categorical focal variable."""
    import matplotlib.pyplot as plt
    import seaborn as sns

    ax = plt.gca()

    factor_col = np.asarray(data[focal_var])
    categories = list(dict.fromkeys(factor_col))  # Preserve order, dedupe
    x_positions = np.arange(len(categories))

    if hue is not None and hue in data.columns:
        _draw_dodged_points(
            ax, data, focal_var, categories, x_positions, hue, style, palette
        )
    else:
        estimates, ci_lo, ci_hi = _extract_by_category(data, factor_col, categories)
        yerr = _build_yerr(estimates, ci_lo, ci_hi)

        ax.errorbar(
            x_positions,
            estimates,
            yerr=yerr,
            fmt="o",
            markersize=8,
            capsize=5,
            color=sns.color_palette(palette)[0],
            ecolor=style["ref_line_color"],
            elinewidth=style["line_width"],
        )

    ax.set_xticks(x_positions)
    ax.set_xticklabels([str(c) for c in categories])


def _draw_dodged_points(
    ax: "Axes",
    data: "Any",
    factor: str,
    categories: list,
    x_positions: np.ndarray,
    hue: str,
    style: dict,
    palette: str,
) -> None:
    """Draw EMMs with hue grouping — dodged points + error bars."""
    import seaborn as sns

    hue_col = np.asarray(data[hue])
    factor_col = np.asarray(data[factor])

    hue_levels = list(dict.fromkeys(hue_col))
    n_groups = len(hue_levels)
    colors = sns.color_palette(palette, n_colors=max(n_groups, 1))

    dodge = 0.2
    total_width = dodge * (n_groups - 1)
    offsets = np.linspace(-total_width / 2, total_width / 2, n_groups)

    for i, hue_level in enumerate(hue_levels):
        hue_mask = hue_col == hue_level
        masked_factor = factor_col.copy()
        masked_factor[~hue_mask] = None  # Mask out non-matching rows

        estimates, ci_lo, ci_hi = _extract_by_category(
            data, factor_col, categories, extra_mask=hue_mask
        )
        yerr = _build_yerr(estimates, ci_lo, ci_hi)

        ax.errorbar(
            x_positions + offsets[i],
            estimates,
            yerr=yerr,
            fmt="o",
            markersize=8,
            capsize=4,
            color=colors[i],
            ecolor=colors[i],
            elinewidth=style["line_width"],
            label=str(hue_level),
        )


def _draw_means_line(
    data: "Any",
    *,
    focal_var: str,
    style: dict,
    **kwargs: "Any",
) -> None:
    """Draw line + CI ribbon for numeric focal variable (e.g., x@range)."""
    import matplotlib.pyplot as plt

    ax = plt.gca()

    # Sort by focal value for line continuity
    x_vals = np.asarray(data[focal_var], dtype=float)
    estimates = np.asarray(data[Col.ESTIMATE])
    sort_idx = np.argsort(x_vals)
    x_sorted = x_vals[sort_idx]
    est_sorted = estimates[sort_idx]

    color = kwargs.get("color", "C0")

    ax.plot(
        x_sorted,
        est_sorted,
        color=color,
        linewidth=style["line_width"] + 0.5,
        marker="o",
        markersize=5,
    )

    if Col.CI_LOWER in data.columns and Col.CI_UPPER in data.columns:
        ci_lo = np.asarray(data[Col.CI_LOWER])[sort_idx]
        ci_hi = np.asarray(data[Col.CI_UPPER])[sort_idx]
        ax.fill_between(
            x_sorted,
            ci_lo,
            ci_hi,
            alpha=style["ci_alpha"],
            color=color,
        )


# =============================================================================
# Shared extraction helpers
# =============================================================================


def _extract_by_category(
    data: "Any",
    factor_col: np.ndarray,
    categories: list,
    *,
    extra_mask: np.ndarray | None = None,
) -> tuple[np.ndarray, np.ndarray | None, np.ndarray | None]:
    """Extract estimates and CI bounds aligned to category order.

    Args:
        data: DataFrame (Polars or pandas) with estimate/CI columns.
        factor_col: Array of factor values.
        categories: Ordered list of category values.
        extra_mask: Optional boolean mask to combine with category match.

    Returns:
        Tuple of (estimates, ci_lower, ci_upper). CI arrays are None
        if the columns are not present.
    """
    estimate_col = np.asarray(data[Col.ESTIMATE])
    has_ci = Col.CI_LOWER in data.columns and Col.CI_UPPER in data.columns

    estimates = []
    ci_lowers = [] if has_ci else None
    ci_uppers = [] if has_ci else None

    for cat in categories:
        mask = factor_col == cat
        if extra_mask is not None:
            mask = mask & extra_mask
        if mask.any():
            idx = np.where(mask)[0][0]
            estimates.append(estimate_col[idx])
            if has_ci:
                ci_lowers.append(np.asarray(data[Col.CI_LOWER])[idx])
                ci_uppers.append(np.asarray(data[Col.CI_UPPER])[idx])
        else:
            estimates.append(np.nan)
            if has_ci:
                ci_lowers.append(np.nan)
                ci_uppers.append(np.nan)

    est_arr = np.array(estimates)
    ci_lo_arr = np.array(ci_lowers) if ci_lowers is not None else None
    ci_hi_arr = np.array(ci_uppers) if ci_uppers is not None else None
    return est_arr, ci_lo_arr, ci_hi_arr


def _build_yerr(
    estimates: np.ndarray,
    ci_lower: np.ndarray | None,
    ci_upper: np.ndarray | None,
) -> list[np.ndarray] | None:
    """Build yerr array for matplotlib errorbar from estimates and CI bounds.

    Args:
        estimates: Point estimates.
        ci_lower: Lower CI bounds (or None).
        ci_upper: Upper CI bounds (or None).

    Returns:
        ``[lower_err, upper_err]`` list or None if no CIs.
    """
    if ci_lower is None or ci_upper is None:
        return None
    return [estimates - ci_lower, ci_upper - estimates]
