"""Data generating process for generalized linear models."""

from __future__ import annotations

from collections.abc import Sequence
from typing import TYPE_CHECKING, Literal

import numpy as np
import polars as pl

from bossanova.internal.maths.family import apply_link_inverse
from bossanova.internal.maths.rng import RNG

if TYPE_CHECKING:
    from bossanova.internal.simulation.dgp.generate import Distribution

# Type alias for array-like inputs
ArrayLike = Sequence[float] | np.ndarray
FamilyType = Literal["gaussian", "binomial", "poisson"]
LinkType = Literal["identity", "logit", "probit", "log"] | None

__all__ = ["generate_glm_data"]


def get_canonical_link(
    family: FamilyType,
) -> Literal["identity", "logit", "log"]:
    """Return canonical link function for a family."""
    if family == "gaussian":
        return "identity"
    elif family == "binomial":
        return "logit"
    else:  # poisson
        return "log"


def generate_glm_data(
    n: int,
    beta: ArrayLike,
    family: FamilyType = "gaussian",
    link: LinkType = None,
    sigma: float = 1.0,
    x_type: Literal["gaussian", "uniform", "binary"] = "gaussian",
    distributions: dict[str, Distribution] | None = None,
    seed: int | None = None,
) -> tuple[pl.DataFrame, dict]:
    """Generate GLM data with known parameters.

    Creates synthetic data from a generalized linear model:
        g(E[y]) = X @ beta
    where g is the link function determined by family/link.

    Args:
        n: Number of observations to generate.
        beta: True coefficients as [intercept, slope1, slope2, ...].
            Length determines number of predictors (len(beta) - 1).
        family: Response distribution:
            - "gaussian": Normal distribution (default)
            - "binomial": Binary outcomes (0/1)
            - "poisson": Count data
        link: Link function. If None, uses canonical link for family:
            - gaussian: "identity"
            - binomial: "logit"
            - poisson: "log"
        sigma: Residual SD (only used for gaussian family, default 1.0).
        x_type: Distribution for predictors:
            - "gaussian": Standard normal N(0, 1)
            - "uniform": Uniform on [0, 1]
            - "binary": Bernoulli(0.5), values in {0, 1}
        distributions: Mapping of variable names to Distribution objects.
            When provided, these override x_type for the specified variables.
            Variable names should match x1, x2, etc. Categorical distributions
            are stored as separate columns (not in X matrix).
        seed: Random seed for reproducibility. If None, uses random state.

    Returns:
        A tuple of (data, true_params) where:
        - data: polars DataFrame with columns y, x1, x2, ...
        - true_params: dict with keys "beta", "family", "link", and
            "sigma" (for gaussian)

    Examples:
        Old API (still works)::

            # Logistic regression
            data, params = generate_glm_data(
                n=200, beta=[0.0, 1.5], family="binomial"
            )
            data["y"].mean()  # Should be ~0.5 (balanced)

            # Poisson regression
            data, params = generate_glm_data(
                n=100, beta=[1.0, 0.5], family="poisson"
            )

        New API with distribution objects::

            from bossanova.distributions import normal, uniform

            data, params = generate_glm_data(
                n=200,
                beta=[0.0, 1.5],
                family="binomial",
                distributions={"x1": uniform(-2, 2)},
            )
    """
    beta = np.asarray(beta, dtype=np.float64)
    n_predictors = len(beta) - 1

    if n_predictors < 1:
        raise ValueError("beta must have at least 2 elements [intercept, slope]")

    # Resolve link function
    resolved_link: str = link if link is not None else get_canonical_link(family)

    # Validate sigma for gaussian
    if family == "gaussian" and sigma <= 0:
        raise ValueError("sigma must be positive for gaussian family")

    # Initialize RNG (works with both JAX and NumPy backends)
    rng = RNG.from_seed(seed)

    # Split keys
    rng_x, rng_y = rng.split()

    # Generate predictors from distributions if provided
    if distributions is not None:
        from bossanova.internal.simulation.dgp.generate import (
            generate_predictors,
        )

        # Get numpy generator from RNG for distribution sampling
        np_rng = rng_x.key if hasattr(rng_x.key, "random") else rng_x.key
        if not isinstance(np_rng, np.random.Generator):
            # For JAX backend, create a numpy generator from seed
            np_rng = np.random.default_rng(seed)

        dist_predictors = generate_predictors(distributions, n, np_rng)

        # Build X matrix, using distributions where provided, x_type as fallback
        X_cols = []
        extra_cols: dict[str, np.ndarray] = {}

        for i in range(n_predictors):
            col_name = f"x{i + 1}"
            if col_name in dist_predictors:
                values = dist_predictors[col_name]
                # Check if categorical (string dtype)
                if values.dtype.kind in ("U", "O", "S"):
                    # Store categorical separately, don't include in X matrix
                    extra_cols[col_name] = values
                    # Use zeros as placeholder in X (not used in linear predictor)
                    X_cols.append(np.zeros(n))
                else:
                    X_cols.append(np.asarray(values, dtype=np.float64))
            else:
                # Fall back to x_type for this column
                if x_type == "gaussian":
                    X_cols.append(np.asarray(rng_x.normal(shape=(n,))))
                elif x_type == "uniform":
                    X_cols.append(np.asarray(rng_x.uniform(shape=(n,))))
                elif x_type == "binary":
                    X_cols.append(
                        np.asarray(rng_x.bernoulli(p=0.5, shape=(n,))).astype(
                            np.float64
                        )
                    )
                else:
                    raise ValueError(f"Unknown x_type: {x_type}")

        X = np.column_stack(X_cols) if X_cols else np.empty((n, 0))
    else:
        # Original behavior: generate all predictors from x_type
        extra_cols = {}
        if x_type == "gaussian":
            X = rng_x.normal(shape=(n, n_predictors))
        elif x_type == "uniform":
            X = rng_x.uniform(shape=(n, n_predictors))
        elif x_type == "binary":
            X = rng_x.bernoulli(p=0.5, shape=(n, n_predictors)).astype(np.float64)
        else:
            raise ValueError(f"Unknown x_type: {x_type}")

    # Ensure X is a NumPy array for consistent operations
    X = np.asarray(X)

    # Build design matrix with intercept
    intercept = np.ones((n, 1))
    X_full = np.hstack([intercept, X])

    # Compute linear predictor: eta = X @ beta
    eta = X_full @ beta

    # Apply inverse link to get mean: mu = g^{-1}(eta)
    mu = np.asarray(apply_link_inverse(resolved_link, eta))

    # Generate response based on family
    if family == "gaussian":
        y = mu + np.asarray(rng_y.normal(shape=(n,))) * sigma
    elif family == "binomial":
        # Bernoulli sampling with array of probabilities: y_i ~ Bernoulli(mu_i)
        y = np.asarray(rng_y.bernoulli(p=mu)).astype(np.float64)
    elif family == "poisson":
        # Poisson sampling: y ~ Poisson(mu)
        y = rng_y.poisson(lam=mu)
    else:
        raise ValueError(f"Unknown family: {family}")

    # Ensure y is a NumPy array
    y = np.asarray(y)

    # Build DataFrame
    data_dict: dict[str, np.ndarray] = {"y": y}
    for i in range(n_predictors):
        col_name = f"x{i + 1}"
        if col_name in extra_cols:
            # Use categorical values
            data_dict[col_name] = extra_cols[col_name]
        else:
            data_dict[col_name] = np.asarray(X[:, i])

    data = pl.DataFrame(data_dict)

    true_params = {
        "beta": np.asarray(beta),
        "family": family,
        "link": resolved_link,
    }
    if family == "gaussian":
        true_params["sigma"] = float(sigma)

    return data, true_params
