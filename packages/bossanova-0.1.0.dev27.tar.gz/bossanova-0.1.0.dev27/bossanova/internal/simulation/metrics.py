"""Metrics for Monte Carlo simulation studies."""

import numpy as np
from numpy.typing import ArrayLike

__all__ = [
    "bias",
    "compute_wilson_ci",
    "coverage",
    "empirical_se",
    "mean_se",
    "rejection_rate",
    "rmse",
]


def bias(estimates: ArrayLike, true_value: float) -> float:
    """Compute bias: E[beta_hat] - beta_true.

    Args:
        estimates: Array of parameter estimates from simulations.
        true_value: True parameter value.

    Returns:
        Bias (positive = overestimate, negative = underestimate).

    Examples:
        ```python
        estimates = np.array([1.02, 0.98, 1.01, 0.99, 1.00])
        bias(estimates, true_value=1.0)
        # 0.0
        ```
    """
    estimates = np.asarray(estimates)
    return float(np.mean(estimates) - true_value)


def rmse(estimates: ArrayLike, true_value: float) -> float:
    """Compute root mean squared error.

    RMSE = sqrt(E[(beta_hat - beta)^2]) = sqrt(Var(beta_hat) + Bias^2)

    Args:
        estimates: Array of parameter estimates from simulations.
        true_value: True parameter value.

    Returns:
        RMSE value.

    Examples:
        ```python
        estimates = np.array([1.1, 0.9, 1.0, 1.0, 1.0])
        rmse(estimates, true_value=1.0)
        # 0.063...
        ```
    """
    estimates = np.asarray(estimates)
    return float(np.sqrt(np.mean((estimates - true_value) ** 2)))


def mean_se(std_errors: ArrayLike) -> float:
    """Compute mean of standard errors across simulations.

    Args:
        std_errors: Array of SE estimates from simulations.

    Returns:
        Mean SE.
    """
    std_errors = np.asarray(std_errors)
    return float(np.mean(std_errors))


def empirical_se(estimates: ArrayLike) -> float:
    """Compute empirical standard error (SD of estimates).

    This is the "true" standard error as estimated from the
    simulation distribution.

    Args:
        estimates: Array of parameter estimates from simulations.

    Returns:
        Empirical SE (standard deviation of estimates).
    """
    estimates = np.asarray(estimates)
    return float(np.std(estimates, ddof=1))


def coverage(
    ci_lower: ArrayLike,
    ci_upper: ArrayLike,
    true_value: float,
) -> float:
    """Compute coverage probability.

    Coverage = P(CI_lower <= beta_true <= CI_upper)

    For a correctly calibrated 95% CI, coverage should be ~0.95.

    Args:
        ci_lower: Array of CI lower bounds from simulations.
        ci_upper: Array of CI upper bounds from simulations.
        true_value: True parameter value.

    Returns:
        Coverage probability (0 to 1).

    Examples:
        ```python
        ci_lower = np.array([0.8, 0.9, 0.85, 0.95, 0.88])
        ci_upper = np.array([1.2, 1.1, 1.15, 1.05, 1.12])
        coverage(ci_lower, ci_upper, true_value=1.0)
        # 1.0
        ```
    """
    ci_lower = np.asarray(ci_lower)
    ci_upper = np.asarray(ci_upper)
    covered = (ci_lower <= true_value) & (true_value <= ci_upper)
    return float(np.mean(covered))


def rejection_rate(p_values: ArrayLike, alpha: float = 0.05) -> float:
    """Compute rejection rate (proportion of p-values < alpha).

    For null effects (beta=0), this estimates Type I error rate.
    For non-null effects (beta!=0), this estimates power.

    Args:
        p_values: Array of p-values from simulations.
        alpha: Significance level (default 0.05).

    Returns:
        Rejection rate (0 to 1).

    Examples:
        ```python
        p_values = np.array([0.01, 0.06, 0.03, 0.12, 0.04])
        rejection_rate(p_values, alpha=0.05)
        # 0.6
        ```
    """
    if not (0 < alpha < 1):
        raise ValueError(f"alpha must be in (0, 1), got {alpha}")

    p_values = np.asarray(p_values)
    return float(np.mean(p_values < alpha))


def compute_wilson_ci(p_hat: float, n: int, level: float = 0.95) -> tuple[float, float]:
    """Wilson score confidence interval for a binomial proportion.

    Better coverage than the Wald interval near p=0 or p=1.

    Args:
        p_hat: Observed proportion (0 to 1).
        n: Number of trials.
        level: Confidence level (default 0.95).

    Returns:
        Tuple of (lower, upper) bounds.

    Examples:
        ```python
        compute_wilson_ci(0.8, n=100, level=0.95)
        # (0.711..., 0.868...)
        ```
    """
    from scipy.stats import norm

    z = norm.ppf(1 - (1 - level) / 2)
    denom = 1 + z**2 / n
    center = (p_hat + z**2 / (2 * n)) / denom
    margin = z * np.sqrt(p_hat * (1 - p_hat) / n + z**2 / (4 * n**2)) / denom
    return (max(0.0, center - margin), min(1.0, center + margin))
