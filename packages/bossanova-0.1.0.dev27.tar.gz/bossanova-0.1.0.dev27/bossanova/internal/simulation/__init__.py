"""Simulation utilities for parameter recovery and Monte Carlo studies.

Call chain:
    model.simulate(n=...) -> generate_{lm,glm,lmer,glmer}_data() (pre-fit DGP)
    model.simulate(nsim=...) -> simulate_responses_from_fit() (post-fit parametric bootstrap)
    run_power_study(formula, ...) -> run_power_analysis() -> expand_sweep_grid()
"""

from bossanova.internal.simulation.dgp import (
    generate_glm_data,
    generate_glmer_data,
    generate_lm_data,
    generate_lmer_data,
)
from bossanova.internal.simulation.lifecycle import SimulateResult, execute_simulate
from bossanova.internal.simulation.harness import (
    MonteCarloResult,
    compute_mc_iteration,
    run_monte_carlo,
)
from bossanova.internal.simulation.model_sim import (
    compute_mu_with_new_re,
    generate_data_from_spec,
    simulate_responses_from_fit,
)
from bossanova.internal.simulation.metrics import (
    bias,
    coverage,
    empirical_se,
    mean_se,
    rejection_rate,
    rmse,
    compute_wilson_ci,
)
from bossanova.internal.simulation.power import (
    expand_sweep_grid,
    run_power_analysis,
    run_power_study,
)

__all__ = [
    "MonteCarloResult",
    "SimulateResult",
    "bias",
    "compute_mc_iteration",
    "compute_mu_with_new_re",
    "compute_wilson_ci",
    "coverage",
    "empirical_se",
    "execute_simulate",
    "expand_sweep_grid",
    "generate_data_from_spec",
    "generate_glm_data",
    "generate_glmer_data",
    "generate_lm_data",
    "generate_lmer_data",
    "mean_se",
    "rejection_rate",
    "rmse",
    "run_monte_carlo",
    "run_power_analysis",
    "run_power_study",
    "simulate_responses_from_fit",
]
