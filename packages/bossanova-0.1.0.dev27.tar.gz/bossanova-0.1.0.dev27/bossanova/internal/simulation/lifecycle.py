"""Simulate lifecycle orchestration.

Owns the three-branch simulate dispatch: power analysis, post-fit simulation,
and pre-fit data generation. Called by ``model.simulate()`` so the model class
stays a thin facade.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import polars as pl
from attrs import frozen

from bossanova.model.guards import ModelStateError

if TYPE_CHECKING:
    from bossanova.internal.containers import DataBundle, FitState, ModelSpec
    from bossanova.internal.simulation.harness import MonteCarloResult

__all__ = ["SimulateResult", "execute_simulate"]


@frozen
class SimulateResult:
    """Immutable result of the simulate lifecycle.

    Attributes:
        mode: One of ``"power"``, ``"simulate"``, or ``"generate"``.
        simulations: Simulated response DataFrame (post-fit mode).
        generated_data: Generated DataFrame (pre-fit mode).
        power: Monte Carlo power result (power mode).
    """

    mode: str
    simulations: pl.DataFrame | None = None
    generated_data: pl.DataFrame | None = None
    power: MonteCarloResult | None = None


def execute_simulate(
    spec: ModelSpec,
    bundle: DataBundle | None,
    fit: FitState | None,
    data: pl.DataFrame | None,
    formula: str,
    is_mixed: bool,
    n: int | None,
    nsim: int | None,
    seed: int | None,
    coef: dict[str, float] | None,
    sigma: float,
    varying: str,
    power: int | dict[str, Any] | None,
    var_specs: dict,
) -> SimulateResult:
    """Execute simulation: power analysis, post-fit sampling, or pre-fit generation.

    Args:
        spec: Model specification.
        bundle: Data bundle (None if pre-fit).
        fit: Fitted state (None if pre-fit).
        data: Current data (None if simulation-first).
        formula: Formula string.
        is_mixed: Whether this is a mixed-effects model.
        n: Sample size for pre-fit generation or power analysis.
        nsim: Number of simulated response vectors (post-fit).
        seed: Random seed.
        coef: True coefficient values (pre-fit mode).
        sigma: Residual SD (pre-fit gaussian).
        varying: RE handling in post-fit (``"fitted"`` or ``"sample"``).
        power: Power analysis config (int or dict), or None.
        var_specs: Distribution specs for predictors.

    Returns:
        SimulateResult with populated fields for the chosen mode.

    Raises:
        ValueError: If args are invalid for the chosen mode.
        ModelStateError: If model state doesn't support the chosen mode.
    """
    # Power analysis mode
    if power is not None:
        if n is None:
            raise ValueError("n= is required for power analysis")

        from bossanova.internal.simulation.power import run_power_analysis

        mc_result = run_power_analysis(
            formula=formula,
            family=spec.family,
            response_var=spec.response_var,
            power=power,
            n=n,
            seed=seed,
            coef=coef,
            sigma=sigma,
            var_specs=var_specs,
        )
        return SimulateResult(mode="power", power=mc_result)

    # Validate mutual exclusivity
    if n is not None and nsim is not None:
        raise ValueError(
            "Specify n= (generate data) or nsim= (simulate from fit), not both"
        )

    # Post-fit simulation mode
    if nsim is not None:
        if nsim < 1:
            raise ValueError(f"nsim must be at least 1, got {nsim}")
        if varying not in ("fitted", "sample"):
            raise ValueError(f"varying must be 'fitted' or 'sample', got '{varying}'")
        if varying == "sample" and not is_mixed:
            raise ValueError(
                "varying='sample' only applies to mixed models (with random effects)"
            )
        if fit is None:
            raise ModelStateError("Model not fitted. Call .fit() first.")

        from bossanova.internal.simulation.model_sim import (
            simulate_responses_from_fit,
        )

        simulations = simulate_responses_from_fit(
            fit=fit, bundle=bundle, spec=spec, nsim=nsim, seed=seed, varying=varying
        )
        return SimulateResult(mode="simulate", simulations=simulations)

    # Pre-fit data generation mode
    if bundle is not None or data is not None:
        raise ModelStateError(
            "Data already provided. Use nsim= to simulate from fitted model."
        )
    if n is None:
        raise ValueError("Must specify n= for data generation")

    from bossanova.internal.containers.builders.specs import (
        build_simulation_spec_from_formula,
    )

    sim_spec = build_simulation_spec_from_formula(
        formula=formula,
        n=n,
        distributions=var_specs if var_specs else None,
        coef=coef,
        sigma=sigma,
        seed=seed,
    )

    from bossanova.internal.simulation.model_sim import generate_data_from_spec

    generated = generate_data_from_spec(
        sim_spec=sim_spec, family=spec.family, response_var=spec.response_var
    )
    return SimulateResult(mode="generate", generated_data=generated)
