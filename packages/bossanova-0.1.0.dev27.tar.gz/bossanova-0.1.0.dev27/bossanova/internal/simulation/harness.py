"""Monte Carlo simulation harness for parameter recovery studies.

Provides infrastructure for running simulation studies and collecting
results for bias, coverage, and power analysis.
"""

from collections.abc import Callable
from typing import Any

import numpy as np
import polars as pl
from attrs import field, frozen
from joblib import Parallel, delayed
from tqdm import tqdm

from bossanova.internal.containers.schemas import Col
from bossanova.internal.containers.validators import is_ndarray
from bossanova.internal.infer.resample.common import warn_on_failures
from bossanova.internal.simulation import metrics

__all__ = ["MonteCarloResult", "compute_mc_iteration", "run_monte_carlo"]


@frozen
class MonteCarloResult:
    """Results from a Monte Carlo simulation study.

    Stores estimates, standard errors, confidence intervals, and p-values
    from repeated simulations, along with ground truth parameters.

    Created by: run_monte_carlo()
    Consumed by: User analysis code (bias, coverage, power methods)
    Augmented by: Never (immutable result container)

    Attributes:
        estimates: Array of shape (n_sims, n_params) with coefficient estimates.
        std_errors: Array of shape (n_sims, n_params) with standard errors.
        ci_lower: Array of shape (n_sims, n_params) with CI lower bounds.
        ci_upper: Array of shape (n_sims, n_params) with CI upper bounds.
        p_values: Array of shape (n_sims, n_params) with p-values.
        true_values: Named mapping of true parameter values
            (e.g., {"Intercept": 0.0, "x": 0.5}).
        param_names: Tuple of parameter names matching array columns.
        n_sims: Number of successful simulations.
        n_failed: Number of simulations that failed to converge.

    Examples:
        ```python
        result = run_monte_carlo(
            dgp_fn=generate_lm_data,
            dgp_params={"n": 100, "beta": [1.0, 2.0], "sigma": 1.0},
            fit_fn=lambda d: model("y ~ x1", data=d).fit(),
            n_sims=500,
        )
        result.bias("x1")  # Should be close to 0
        result.coverage("x1")  # Should be close to 0.95
        ```
    """

    estimates: np.ndarray = field(validator=is_ndarray)
    std_errors: np.ndarray = field(validator=is_ndarray)
    ci_lower: np.ndarray = field(validator=is_ndarray)
    ci_upper: np.ndarray = field(validator=is_ndarray)
    p_values: np.ndarray = field(validator=is_ndarray)
    true_values: dict[str, float] = field(factory=dict)
    param_names: tuple[str, ...] = field(converter=tuple, factory=tuple)
    n_sims: int = field(default=0)
    n_failed: int = field(default=0)
    _param_index: dict[str, int] = field(factory=dict, repr=False, eq=False)

    def __attrs_post_init__(self) -> None:
        """Build parameter name to index mapping."""
        object.__setattr__(
            self,
            "_param_index",
            {name: i for i, name in enumerate(self.param_names)},
        )

    def get_idx(self, param: str | int) -> int:
        """Get array index for a parameter.

        Args:
            param: Parameter name or index.

        Returns:
            Integer index into the parameter arrays.

        Raises:
            KeyError: If param is a string not found in param_names.
        """
        if isinstance(param, int):
            return param
        if param not in self._param_index:
            raise KeyError(
                f"Unknown parameter '{param}'. "
                f"Available: {list(self._param_index.keys())}"
            )
        return self._param_index[param]

    def get_true_value(self, param: str | int) -> float:
        """Get true value for a parameter.

        Args:
            param: Parameter name or index.

        Returns:
            True parameter value.

        Raises:
            KeyError: If param not found in true_values.
        """
        if isinstance(param, int):
            name = self.param_names[param]
        else:
            name = param
        return self.true_values[name]

    def bias(self, param: str | int) -> float:
        """Compute bias for a parameter: E[beta_hat] - beta_true.

        Args:
            param: Parameter name or index.

        Returns:
            Bias value.
        """
        idx = self.get_idx(param)
        true_value = self.get_true_value(param)
        return metrics.bias(self.estimates[:, idx], true_value)

    def rmse(self, param: str | int) -> float:
        """Compute RMSE for a parameter.

        Args:
            param: Parameter name or index.

        Returns:
            Root mean squared error.
        """
        idx = self.get_idx(param)
        true_value = self.get_true_value(param)
        return metrics.rmse(self.estimates[:, idx], true_value)

    def mean_se(self, param: str | int) -> float:
        """Compute mean estimated standard error for a parameter.

        Args:
            param: Parameter name or index.

        Returns:
            Mean SE across simulations.
        """
        idx = self.get_idx(param)
        return metrics.mean_se(self.std_errors[:, idx])

    def empirical_se(self, param: str | int) -> float:
        """Compute empirical SE (SD of estimates) for a parameter.

        Args:
            param: Parameter name or index.

        Returns:
            Empirical SE.
        """
        idx = self.get_idx(param)
        return metrics.empirical_se(self.estimates[:, idx])

    def coverage(self, param: str | int, level: float = 0.95) -> float:
        """Compute coverage probability for a parameter.

        Args:
            param: Parameter name or index.
            level: Confidence level (default 0.95). Currently only used
                for documentation; actual CIs come from the model.

        Returns:
            Coverage probability (0 to 1).
        """
        idx = self.get_idx(param)
        true_value = self.get_true_value(param)
        return metrics.coverage(
            self.ci_lower[:, idx],
            self.ci_upper[:, idx],
            true_value,
        )

    def type1_rate(self, param: str | int, alpha: float = 0.05) -> float:
        """Compute Type I error rate for a parameter.

        This is the rejection rate when the true effect is zero.
        Use this for parameters where true_value = 0.

        Args:
            param: Parameter name or index.
            alpha: Significance level (default 0.05).

        Returns:
            Type I error rate (should be ~ alpha if correctly calibrated).
        """
        idx = self.get_idx(param)
        return metrics.rejection_rate(self.p_values[:, idx], alpha)

    def power(self, param: str | int, alpha: float = 0.05) -> float:
        """Compute power for a parameter.

        This is the rejection rate when the true effect is non-zero.
        Use this for parameters where true_value != 0.

        Args:
            param: Parameter name or index.
            alpha: Significance level (default 0.05).

        Returns:
            Power (probability of correctly rejecting H0).
        """
        # Power is computed the same way as type1_rate, just interpreted
        # differently based on whether the true effect is zero or not
        return self.type1_rate(param, alpha)

    def summary(self) -> pl.DataFrame:
        """Return summary DataFrame with all metrics for all parameters.

        Returns:
            DataFrame with columns: param, true_value, mean_est, bias,
            rmse, mean_se, empirical_se, coverage, rejection_rate.
        """
        rows = []
        for name in self.param_names:
            idx = self.get_idx(name)
            true_val = self.get_true_value(name)
            rows.append(
                {
                    "param": name,
                    "true_value": true_val,
                    "mean_est": float(np.mean(self.estimates[:, idx])),
                    "bias": self.bias(name),
                    "rmse": self.rmse(name),
                    "mean_se": self.mean_se(name),
                    "empirical_se": self.empirical_se(name),
                    "coverage": self.coverage(name),
                    "rejection_rate": self.type1_rate(name),
                }
            )
        return pl.DataFrame(rows)


# =============================================================================
# Single iteration (standalone for joblib serialization)
# =============================================================================


def compute_mc_iteration(
    seed: int,
    dgp_fn: Callable[..., tuple[pl.DataFrame, dict[str, Any]]],
    dgp_params: dict[str, Any],
    fit_fn: Callable[[pl.DataFrame], Any],
) -> dict[str, Any] | None:
    """Execute a single Monte Carlo iteration.

    Standalone function (not a closure) for joblib serialization
    compatibility. Returns None if fitting fails.

    Args:
        seed: Random seed for this iteration.
        dgp_fn: Data generating function returning (data, true_params).
        dgp_params: Parameters to pass to dgp_fn (excluding seed).
        fit_fn: Function that takes a DataFrame and returns a fitted model.

    Returns:
        Dictionary with 'params_df' and 'true_params' on success, or
        None if the model fit fails.
    """
    data, params = dgp_fn(**dgp_params, seed=seed)
    try:
        fitted = fit_fn(data)
    except Exception:
        return None

    # Extract from fitted.params DataFrame
    params_df = fitted.params
    return {
        "params_df": params_df,
        "true_params": params,
    }


# =============================================================================
# Main harness
# =============================================================================


def run_monte_carlo(
    dgp_fn: Callable[..., tuple[pl.DataFrame, dict[str, Any]]],
    dgp_params: dict[str, Any],
    fit_fn: Callable[[pl.DataFrame], Any],
    n_sims: int = 1000,
    seed: int = 42,
    n_jobs: int = 1,
    verbose: bool = False,
) -> MonteCarloResult:
    """Run a Monte Carlo simulation study.

    Generates data from a DGP, fits models, and collects results
    for parameter recovery analysis.

    Args:
        dgp_fn: Data generating function that returns (data, true_params).
            Must accept a ``seed`` parameter.
        dgp_params: Parameters to pass to dgp_fn (excluding seed).
        fit_fn: Function that takes a DataFrame and returns a fitted model.
            The model must expose a ``.params`` property returning a
            Polars DataFrame with columns matching ``Col.TERM``,
            ``Col.ESTIMATE``, etc.
        n_sims: Number of simulations to run (default 1000).
        seed: Base random seed (default 42). Each simulation uses seed + i.
        n_jobs: Number of parallel jobs. 1 = sequential, >1 = parallel
            via joblib (default 1).
        verbose: If True, show tqdm progress bar (default False).

    Returns:
        MonteCarloResult with collected estimates and metrics.

    Examples:
        ```python
        from bossanova import model
        from bossanova.internal.simulation import generate_lm_data
        result = run_monte_carlo(
            dgp_fn=generate_lm_data,
            dgp_params={"n": 100, "beta": [1.0, 2.0], "sigma": 1.0},
            fit_fn=lambda d: model("y ~ x1", d).fit().infer(),
            n_sims=500,
        )
        abs(result.bias("x1")) < 0.1
        # True
        ```
    """
    if n_sims < 1:
        raise ValueError(f"n_sims must be at least 1, got {n_sims}")

    # Run iterations (sequential or parallel)
    seeds = [seed + i for i in range(n_sims)]
    iter_kwargs = {
        "dgp_fn": dgp_fn,
        "dgp_params": dgp_params,
        "fit_fn": fit_fn,
    }

    if n_jobs == 1:
        # Sequential with optional tqdm progress bar
        raw_results: list[dict[str, Any] | None] = []
        for s in tqdm(seeds, desc="Monte Carlo", disable=not verbose):
            result = compute_mc_iteration(seed=s, **iter_kwargs)
            raw_results.append(result)
    else:
        # Parallel execution with joblib
        if verbose:
            print(f"Running {n_sims} Monte Carlo iterations with {n_jobs} workers...")
        gen = Parallel(n_jobs=n_jobs, return_as="generator")(
            delayed(compute_mc_iteration)(seed=s, **iter_kwargs) for s in seeds
        )
        raw_results = list(
            tqdm(gen, total=n_sims, desc="Monte Carlo", disable=not verbose)
        )

    # Separate successes from failures
    successful = [r for r in raw_results if r is not None]
    n_failed = len(raw_results) - len(successful)

    warn_on_failures(n_failed, n_sims, context="Monte Carlo")

    if not successful:
        # All iterations failed — return empty result
        return MonteCarloResult(
            estimates=np.empty((0, 0)),
            std_errors=np.empty((0, 0)),
            ci_lower=np.empty((0, 0)),
            ci_upper=np.empty((0, 0)),
            p_values=np.empty((0, 0)),
            true_values={},
            param_names=(),
            n_sims=0,
            n_failed=n_failed,
        )

    # Extract param_names from first successful result
    first_df = successful[0]["params_df"]
    param_names = first_df[Col.TERM].to_list()
    n_params = len(param_names)

    # Build true_values from first successful result's true_params
    true_params = successful[0]["true_params"]
    beta = true_params.get("beta", [])
    true_values = {
        name: float(beta[i]) if i < len(beta) else 0.0
        for i, name in enumerate(param_names)
    }

    # Collect arrays from all successful results
    all_estimates = []
    all_std_errors = []
    all_ci_lower = []
    all_ci_upper = []
    all_p_values = []

    for res in successful:
        params_df: pl.DataFrame = res["params_df"]

        all_estimates.append(params_df[Col.ESTIMATE].to_numpy())

        all_std_errors.append(
            params_df[Col.SE].to_numpy()
            if Col.SE in params_df.columns
            else np.full(n_params, np.nan)
        )

        all_p_values.append(
            params_df[Col.P_VALUE].to_numpy()
            if Col.P_VALUE in params_df.columns
            else np.full(n_params, np.nan)
        )

        all_ci_lower.append(
            params_df[Col.CI_LOWER].to_numpy()
            if Col.CI_LOWER in params_df.columns
            else np.full(n_params, np.nan)
        )

        all_ci_upper.append(
            params_df[Col.CI_UPPER].to_numpy()
            if Col.CI_UPPER in params_df.columns
            else np.full(n_params, np.nan)
        )

    return MonteCarloResult(
        estimates=np.vstack(all_estimates),
        std_errors=np.vstack(all_std_errors),
        ci_lower=np.vstack(all_ci_lower),
        ci_upper=np.vstack(all_ci_upper),
        p_values=np.vstack(all_p_values),
        true_values=true_values,
        param_names=tuple(param_names),
        n_sims=len(successful),
        n_failed=n_failed,
    )
