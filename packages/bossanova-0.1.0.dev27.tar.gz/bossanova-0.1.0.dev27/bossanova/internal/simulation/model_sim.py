"""Model-level simulation operations.

Provides pre-fit data generation (``generate_data_from_spec``) and post-fit
response simulation (``simulate_responses_from_fit``) as pure functions on
containers. Extracted from ``model/core.py`` to enforce the "model is glue"
boundary.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import polars as pl

if TYPE_CHECKING:
    from bossanova.internal.containers import (
        DataBundle,
        FitState,
        ModelSpec,
        SimulationSpec,
    )

__all__ = [
    "compute_mu_with_new_re",
    "generate_data_from_spec",
    "simulate_responses_from_fit",
]


def generate_data_from_spec(
    sim_spec: "SimulationSpec",
    family: str,
    response_var: str,
) -> pl.DataFrame:
    """Generate a synthetic dataset from a simulation specification.

    Implements the data-generating process (DGP): samples predictors from
    their distributions, constructs the design matrix, computes the linear
    predictor, and draws response values from the appropriate family.

    Args:
        sim_spec: Simulation specification with sample size, distributions,
            coefficients, and random effect structure.
        family: GLM family name (e.g. "gaussian", "binomial", "poisson").
        response_var: Name for the response column in the output DataFrame.

    Returns:
        Polars DataFrame with generated predictor and response columns.

    Raises:
        TypeError: If ``sim_spec`` is not a ``SimulationSpec``.
    """
    from bossanova.internal.containers import SimulationSpec as SimSpecType
    from bossanova.internal.maths.family import apply_link_inverse
    from bossanova.internal.maths.family.response import (
        CANONICAL_LINKS,
        sample_response,
    )

    if not isinstance(sim_spec, SimSpecType):
        raise TypeError(
            f"Expected SimulationSpec, got {type(sim_spec).__name__}. "
            "This is an internal error - please report it."
        )

    rng = np.random.default_rng(sim_spec.seed)

    # Generate predictor values from distributions
    # Use duck typing to distinguish Varying (has generate_groups) from
    # regular distributions (have sample) — avoids importing user-facing module
    data_dict: dict[str, np.ndarray] = {}
    for var_name, dist in sim_spec.distributions.items():
        generate_fn = getattr(dist, "generate_groups", None)
        if generate_fn is not None:
            data_dict[var_name] = generate_fn(sim_spec.n, rng)
        else:
            data_dict[var_name] = dist.sample(sim_spec.n, rng)

    # Handle random effects grouping variables
    re_effects: dict[str, np.ndarray] = {}
    for var_name, varying_spec in sim_spec.re_spec.items():
        group_labels = np.repeat(
            np.arange(varying_spec.n), sim_spec.n // varying_spec.n + 1
        )[: sim_spec.n]
        rng.shuffle(group_labels)
        data_dict[var_name] = np.array([f"group_{i + 1}" for i in group_labels])

        effects = rng.normal(0, varying_spec.sd, varying_spec.n)
        re_effects[var_name] = effects[group_labels]

    # Build design matrix from continuous predictors
    continuous_vars = [
        k
        for k, v in data_dict.items()
        if isinstance(v, np.ndarray) and v.dtype.kind == "f"
    ]

    # Build interaction columns from coef keys (e.g. "x1:x2" → x1 * x2)
    obs_n = sim_spec.n
    interaction_cols: dict[str, np.ndarray] = {}
    for name in sim_spec.coef:
        if ":" not in name:
            continue
        parts = name.split(":")
        # All parts must be sampled continuous variables
        if not all(p in data_dict and data_dict[p].dtype.kind == "f" for p in parts):
            continue
        col = np.ones(obs_n)
        for p in parts:
            col = col * data_dict[p]
        interaction_cols[name] = col

    # Build X: intercept + main effects + interactions
    interaction_names = list(interaction_cols.keys())
    columns = [np.ones(obs_n)]
    columns.extend(data_dict[v] for v in continuous_vars)
    columns.extend(interaction_cols[name] for name in interaction_names)
    X = np.column_stack(columns) if columns else np.ones((obs_n, 1))

    coef_names = ["Intercept"] + continuous_vars + interaction_names
    coef_values = np.array([sim_spec.coef.get(name, 0.0) for name in coef_names])

    # Linear predictor
    eta = X @ coef_values

    # Add random effects contribution
    for re_contribution in re_effects.values():
        eta = eta + re_contribution

    # Convert eta → mu via canonical inverse link, then sample response
    link = CANONICAL_LINKS.get(family, "identity")
    mu = np.asarray(apply_link_inverse(link, eta))
    y = sample_response(family, mu, sim_spec.sigma, rng)

    # Build DataFrame
    data_dict[response_var] = y
    return pl.DataFrame(data_dict)


def simulate_responses_from_fit(
    fit: "FitState",
    bundle: "DataBundle",
    spec: "ModelSpec",
    nsim: int,
    seed: int | None,
    varying: str = "fitted",
) -> pl.DataFrame:
    """Simulate new responses from a fitted model.

    Uses the fitted coefficients and estimated residual variance to generate
    new response values. For gaussian models, adds normally distributed errors.
    For GLMs, generates from the appropriate distribution.

    Args:
        fit: Fitted model state with coefficients, fitted values, and sigma.
        bundle: Data bundle with design matrix and RE metadata.
        spec: Model specification with family and link information.
        nsim: Number of simulations to generate.
        seed: Random seed for reproducibility, or None.
        varying: How to handle random effects. ``"fitted"`` uses estimated
            BLUPs, ``"sample"`` draws new random effects each simulation.

    Returns:
        DataFrame with columns ``sim_1``, ``sim_2``, ..., ``sim_nsim``.
    """
    from bossanova.internal.maths.family.response import resolve_sigma, sample_response

    rng = np.random.default_rng(seed)
    sigma = resolve_sigma(fit.sigma)

    sim_data: dict[str, list[float]] = {}

    for i in range(nsim):
        col_name = f"sim_{i + 1}"

        if varying == "sample" and spec.has_random_effects:
            mu = compute_mu_with_new_re(bundle, fit, spec, rng)
        else:
            mu = fit.fitted

        sim_values = sample_response(spec.family, mu, sigma, rng)
        sim_data[col_name] = sim_values.tolist()

    return pl.DataFrame(sim_data)


def compute_mu_with_new_re(
    bundle: "DataBundle",
    fit: "FitState",
    spec: "ModelSpec",
    rng: np.random.Generator,
) -> np.ndarray:
    """Compute conditional mean with newly sampled random effects.

    Draws ``u_new ~ N(0, I)``, transforms via the relative covariance factor
    Lambda to get new BLUPs, then computes ``mu = X @ coef + Z @ (Lambda @ u_new * sigma)``.

    Args:
        bundle: Data bundle with X, Z matrices and RE metadata.
        fit: Fit state with theta, sigma, and coefficients.
        spec: Model specification with family and link info.
        rng: NumPy random generator for reproducibility.

    Returns:
        New mu values on the response scale, shape ``(n,)``.
    """
    from bossanova.internal.maths.family import apply_link_inverse
    from bossanova.internal.maths.family.response import resolve_sigma
    from bossanova.internal.maths.solvers.lambda_builder import build_lambda_sparse

    re_meta = bundle.re_metadata
    theta = fit.theta
    sigma = resolve_sigma(fit.sigma)

    # Build Lambda (relative covariance factor)
    Lambda = build_lambda_sparse(
        theta=theta,
        n_groups_list=re_meta.n_groups_list,
        re_structure=re_meta.re_structure,
        metadata=re_meta.metadata,
    )

    # Draw new spherical random effects and transform
    q = Lambda.shape[0]
    u_new = rng.standard_normal(q)
    b_new = (Lambda @ u_new) * sigma

    # Coefficients safe for matrix multiplication (NaN → 0 for rank-deficient)
    coef = fit.coef
    if bundle.rank_info is not None and bundle.rank_info.is_deficient:
        coef = np.where(np.isnan(coef), 0.0, coef)

    # Linear predictor: eta = X @ coef + Z @ b_new
    eta = bundle.X @ coef + bundle.Z @ b_new

    # Apply inverse link for non-gaussian families
    if spec.family != "gaussian":
        return np.asarray(apply_link_inverse(spec.link, eta))
    return eta
