"""Power analysis via simulation sweep grids.

Provides utilities for constructing full-factorial parameter grids and
running simulation-based power analyses across those grids. Each grid
point triggers a Monte Carlo study via ``run_monte_carlo()``, and the
results are aggregated into a Polars DataFrame with per-parameter
power, coverage, bias, RMSE, and other diagnostics.
"""

import itertools
from collections.abc import Callable
from typing import Any

import polars as pl

from bossanova.internal.containers.schemas import Col
from bossanova.internal.simulation.harness import run_monte_carlo
from bossanova.internal.simulation.metrics import compute_wilson_ci

__all__ = ["expand_sweep_grid", "run_power_analysis", "run_power_study"]


# Control keys that are NOT sweep axes — filtered out when building the grid
_CONTROL_KEYS = frozenset(
    {"n_sims", "alpha", "conf_level", "n_jobs", "verbose", "seed"}
)


def expand_sweep_grid(
    base_n: int,
    base_coef: dict[str, float],
    base_sigma: float,
    base_varying: dict[str, dict[str, Any]],
    power_config: dict[str, Any],
) -> list[dict[str, Any]]:
    """Full factorial grid from base DGP + power sweep overrides.

    Uses ``itertools.product`` for Cartesian expansion. Handles nested
    coef dict merging (e.g., sweeping one coefficient while keeping
    others fixed).

    Args:
        base_n: Base sample size.
        base_coef: Base coefficient values (e.g., ``{"Intercept": 0.0, "x": 0.5}``).
        base_sigma: Base residual standard deviation.
        base_varying: Base random effect specs (empty dict for fixed-effects models).
        power_config: Sweep configuration dict. Keys are sweep axes
            (``"n"``, ``"coef"``, ``"sigma"``, ``"varying"``). Non-sweep control
            keys (``"n_sims"``, ``"alpha"``, ``"conf_level"``, ``"n_jobs"``,
            ``"verbose"``, ``"seed"``) are ignored.

    Returns:
        List of grid point dicts, each with keys: ``"n"``, ``"coef"``,
        ``"sigma"``, ``"varying"``.

    Examples:
        >>> grid = expand_sweep_grid(
        ...     base_n=100, base_coef={"x": 0.5}, base_sigma=1.0,
        ...     base_varying={},
        ...     power_config={"n": [50, 100, 200]},
        ... )
        >>> len(grid)
        3
        >>> grid[0]["n"]
        50
    """
    # Separate sweep axes from control keys
    sweep_axes: dict[str, Any] = {
        k: v for k, v in power_config.items() if k not in _CONTROL_KEYS
    }

    # If no sweep axes, return single grid point with base values
    if not sweep_axes:
        return [
            {
                "n": base_n,
                "coef": dict(base_coef),
                "sigma": base_sigma,
                "varying": dict(base_varying),
            }
        ]

    # Build per-axis value lists for Cartesian product
    axis_names: list[str] = []
    axis_values: list[list[Any]] = []

    for axis, spec in sweep_axes.items():
        if axis == "coef":
            # spec is a dict mapping param names to lists of values
            # e.g., {"x": [0.1, 0.3, 0.5], "z": [1.0, 2.0]}
            # Each param becomes its own axis in the Cartesian product
            for param_name, param_values in spec.items():
                if isinstance(param_values, (list, tuple)):
                    axis_names.append(("coef", param_name))  # type: ignore[arg-type]
                    axis_values.append(list(param_values))
                else:
                    # Single value override, not a sweep
                    axis_names.append(("coef", param_name))  # type: ignore[arg-type]
                    axis_values.append([param_values])

        elif axis == "varying":
            # spec is a dict of dicts mirroring base_varying structure
            # e.g., {"subject": {"sd": [0.1, 0.5, 1.0]}}
            for group_name, group_spec in spec.items():
                for var_key, var_values in group_spec.items():
                    if isinstance(var_values, (list, tuple)):
                        axis_names.append(("varying", group_name, var_key))  # type: ignore[arg-type]
                        axis_values.append(list(var_values))
                    else:
                        axis_names.append(("varying", group_name, var_key))  # type: ignore[arg-type]
                        axis_values.append([var_values])

        elif isinstance(spec, (list, tuple)):
            axis_names.append(axis)  # type: ignore[arg-type]
            axis_values.append(list(spec))
        else:
            # Scalar override (not a sweep), wrap in list
            axis_names.append(axis)  # type: ignore[arg-type]
            axis_values.append([spec])

    # Full factorial expansion
    grid: list[dict[str, Any]] = []
    for combo in itertools.product(*axis_values):
        point: dict[str, Any] = {
            "n": base_n,
            "coef": dict(base_coef),
            "sigma": base_sigma,
            "varying": _deep_copy_varying(base_varying),
        }

        for axis_name, value in zip(axis_names, combo):
            if isinstance(axis_name, tuple) and axis_name[0] == "coef":
                # ("coef", param_name)
                point["coef"][axis_name[1]] = value
            elif isinstance(axis_name, tuple) and axis_name[0] == "varying":
                # ("varying", group_name, var_key)
                _, group_name, var_key = axis_name
                if group_name not in point["varying"]:
                    point["varying"][group_name] = {}
                point["varying"][group_name][var_key] = value
            else:
                # Simple axis like "n" or "sigma"
                point[axis_name] = value

        grid.append(point)

    return grid


def _deep_copy_varying(varying: dict[str, dict[str, Any]]) -> dict[str, dict[str, Any]]:
    """Create a deep copy of a varying-effects spec dict.

    Args:
        varying: Nested dict of random effect specs.

    Returns:
        Deep copy of the varying dict (one level of nesting).
    """
    return {group: dict(spec) for group, spec in varying.items()}


def run_power_study(
    sweep_grid: list[dict[str, Any]],
    dgp_fn: Callable[..., tuple[pl.DataFrame, dict[str, Any]]],
    fit_fn: Callable[[pl.DataFrame], Any],
    n_sims: int,
    seed: int,
    alpha: float = 0.05,
    ci_level: float = 0.95,
    n_jobs: int = 1,
    verbose: bool = False,
) -> pl.DataFrame:
    """Run power analysis across a sweep grid.

    For each grid point, calls ``run_monte_carlo()`` to run ``n_sims``
    simulations, then extracts per-parameter metrics (power, coverage,
    bias, RMSE, etc.) and adds Wilson confidence intervals on power
    estimates. Returns a Polars DataFrame with one row per grid point
    per parameter.

    Args:
        sweep_grid: List of grid point dicts from ``expand_sweep_grid()``.
            Each dict has keys ``"n"``, ``"coef"``, ``"sigma"``, ``"varying"``.
        dgp_fn: Data generating function that returns ``(data, true_params)``.
            Must accept a ``seed`` parameter.
        fit_fn: Function that takes a DataFrame and returns a fitted model
            with a ``.params`` property.
        n_sims: Number of simulations per grid point.
        seed: Base random seed. Each grid point offsets by ``i * n_sims``.
        alpha: Significance level for power (default 0.05).
        ci_level: Confidence level for Wilson CIs on power (default 0.95).
        n_jobs: Number of parallel jobs for ``run_monte_carlo()`` (default 1).
        verbose: Show progress (default False).

    Returns:
        Polars DataFrame with one row per grid point per parameter.
        Columns include sweep axes (``n``, ``sigma``), parameter info
        (``term``, ``true_value``), power metrics (``power``,
        ``power_ci_lower``, ``power_ci_upper``), and diagnostics
        (``coverage``, ``bias``, ``rmse``, ``mean_se``, ``empirical_se``,
        ``n_sims``, ``n_failed``).
    """
    rows: list[dict[str, Any]] = []

    for i, grid_point in enumerate(sweep_grid):
        dgp_params = dict(grid_point)

        mc = run_monte_carlo(
            dgp_fn=dgp_fn,
            dgp_params=dgp_params,
            fit_fn=fit_fn,
            n_sims=n_sims,
            seed=seed + i * n_sims,
            n_jobs=n_jobs,
            verbose=verbose,
        )

        # Skip grid points where all iterations failed
        if mc.n_sims == 0:
            continue

        for param in mc.param_names:
            power_val = mc.power(param, alpha)
            ci_lo, ci_hi = compute_wilson_ci(power_val, mc.n_sims, ci_level)
            rows.append(
                {
                    Col.N: grid_point["n"],
                    Col.SIGMA: grid_point["sigma"],
                    Col.TERM: param,
                    Col.TRUE_VALUE: mc.get_true_value(param),
                    Col.POWER: power_val,
                    Col.POWER_CI_LOWER: ci_lo,
                    Col.POWER_CI_UPPER: ci_hi,
                    Col.COVERAGE: mc.coverage(param),
                    Col.BIAS: mc.bias(param),
                    Col.RMSE: mc.rmse(param),
                    Col.MEAN_SE: mc.mean_se(param),
                    Col.EMPIRICAL_SE: mc.empirical_se(param),
                    Col.N_SIMS: mc.n_sims,
                    Col.N_FAILED: mc.n_failed,
                }
            )

    return pl.DataFrame(rows)


def run_power_analysis(
    *,
    formula: str,
    family: str,
    response_var: str,
    power: int | dict[str, Any],
    n: int,
    seed: int | None,
    coef: dict[str, float] | None,
    sigma: float,
    var_specs: dict[str, object],
) -> pl.DataFrame:
    """Run simulation-based power analysis for a model formula.

    Pure-function extraction of the power analysis logic from the model class.
    Builds a sweep grid, constructs DGP and fit closures, and delegates to
    ``run_power_study()``.

    Args:
        formula: R-style model formula string.
        family: Response distribution family name.
        response_var: Name of the response variable.
        power: Power config — int (n_sims) or dict with sweep axes and
            control params (``n_sims``, ``alpha``, ``conf_level``, ``n_jobs``,
            ``verbose``, ``seed``).
        n: Base sample size.
        seed: Random seed (used as fallback if power config has no seed).
        coef: Base coefficient values (or None for defaults).
        sigma: Base residual standard deviation.
        var_specs: Distribution specs for predictors (may include
            ``Varying`` instances for random effects).

    Returns:
        Polars DataFrame with one row per grid point per parameter.
        Columns include sweep axes, power metrics, and diagnostics.
    """
    from bossanova.internal.containers.builders.specs import (
        build_simulation_spec_from_formula,
    )
    from bossanova.internal.simulation.model_sim import (
        generate_data_from_spec,
    )

    # Normalize power config
    if isinstance(power, int):
        power_config: dict[str, Any] = {"n_sims": power}
    else:
        power_config = dict(power)

    # Extract control params
    n_sims = power_config.pop("n_sims", 1000)
    alpha = power_config.pop("alpha", 0.05)
    ci_level = power_config.pop("conf_level", 0.95)
    n_jobs = power_config.pop("n_jobs", 1)
    verbose = power_config.pop("verbose", False)
    power_seed = power_config.pop("seed", seed if seed is not None else 42)

    # Build base params
    base_coef = coef or {}
    base_varying: dict[str, dict[str, Any]] = {}

    # Separate varying specs from distribution specs
    from bossanova.distributions import Varying

    distributions: dict[str, object] = {}
    for name, spec in var_specs.items():
        if isinstance(spec, Varying):
            base_varying[name] = {
                "n": spec.n,
                "sd": spec.effective_intercept_sd,
                "slope_sds": dict(spec.slope_sds),
            }
        distributions[name] = spec

    # Build sweep grid
    sweep_grid = expand_sweep_grid(
        base_n=n,
        base_coef=base_coef,
        base_sigma=sigma,
        base_varying=base_varying,
        power_config=power_config,
    )

    # Capture formula context for closures
    captured_formula = formula
    captured_family = family
    captured_response_var = response_var

    # DGP function (closure)
    def dgp_fn(
        n: int,
        coef: dict[str, float],
        sigma: float,
        seed: int,
        varying: dict[str, dict[str, Any]] | None = None,
    ) -> tuple[pl.DataFrame, dict[str, Any]]:
        sim_spec = build_simulation_spec_from_formula(
            formula=captured_formula,
            n=n,
            distributions=distributions if distributions else None,
            coef=coef if coef else None,
            sigma=sigma,
            seed=seed,
        )
        data = generate_data_from_spec(
            sim_spec=sim_spec,
            family=captured_family,
            response_var=captured_response_var,
        )
        # Build beta in the same order the model uses: Intercept + continuous vars.
        # sim_spec.coef.get(name, 0.0) mirrors generate_data_from_spec logic.
        coef_names = ["Intercept"] + [
            k
            for k in sim_spec.distributions
            if not hasattr(sim_spec.distributions[k], "k")  # skip categoricals
        ]
        beta = [sim_spec.coef.get(name, 0.0) for name in coef_names]
        true_params = {"beta": beta}
        return data, true_params

    # Fit function (closure with lazy import to avoid circular dependency)
    def fit_fn(data: pl.DataFrame) -> Any:
        from bossanova.model.core import model as model_cls

        m = model_cls(captured_formula, data, family=captured_family)
        return m.fit().infer()

    # Run power study
    return run_power_study(
        sweep_grid=sweep_grid,
        dgp_fn=dgp_fn,
        fit_fn=fit_fn,
        n_sims=n_sims,
        seed=power_seed,
        alpha=alpha,
        ci_level=ci_level,
        n_jobs=n_jobs,
        verbose=verbose,
    )
