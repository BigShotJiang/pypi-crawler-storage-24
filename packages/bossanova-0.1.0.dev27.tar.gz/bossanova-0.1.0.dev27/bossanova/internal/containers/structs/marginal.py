"""Marginal effects containers."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from attrs import field, frozen, validators

from bossanova.internal.containers.validators import (
    is_ndarray,
    is_optional_conf_level,
    is_optional_ndarray,
    is_optional_positive_int,
    is_optional_str,
    normalize_optional_conf_level,
)

if TYPE_CHECKING:
    import polars as pl

__all__ = ["MeeState"]


@frozen
class MeeState:
    """Marginal effects / estimated marginal means results.

    Created by: build_mee_state(), dispatch_marginal_computation()
    Consumed by: build_effects_dataframe(), model.effects, compute_mee_inference()
    Augmented by: attrs.evolve() after infer() adds SEs/CIs
    """

    grid: "pl.DataFrame" = field(repr=False)
    estimate: np.ndarray = field(validator=is_ndarray)
    explore_formula: str = field(validator=validators.instance_of(str))
    focal_var: str = field(validator=validators.instance_of(str))
    type: str = field(validator=validators.in_(("means", "slopes", "contrasts")))
    how: str = field(default="mem", validator=validators.in_(("mem", "ame")))
    effect_scale: str = field(
        default="link", validator=validators.in_(("link", "response"))
    )
    L_matrix: np.ndarray | None = field(
        default=None, repr=False, validator=is_optional_ndarray
    )
    contrast_method: str | None = field(
        default=None,
        validator=validators.optional(
            validators.in_(
                (
                    "pairwise",
                    "sequential",
                    "poly",
                    "treatment",
                    "sum",
                    "helmert",
                    "custom",
                )
            )
        ),
    )
    n_contrast_levels: int | None = field(
        default=None, validator=is_optional_positive_int
    )
    link: str | None = field(default=None, validator=is_optional_str)
    L_matrix_link: np.ndarray | None = field(
        default=None, repr=False, validator=is_optional_ndarray
    )
    _boot_X_plus: np.ndarray | None = field(
        default=None, repr=False, validator=is_optional_ndarray
    )
    _boot_X_minus: np.ndarray | None = field(
        default=None, repr=False, validator=is_optional_ndarray
    )
    _boot_delta: float | None = field(
        default=None,
        repr=False,
        validator=validators.optional(validators.instance_of((int, float))),
    )
    inference_method: str | None = field(
        default=None,
        validator=validators.optional(validators.in_(("asymp", "boot", "perm"))),
    )
    se: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    df: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    statistic: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    p_value: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    ci_lower: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    ci_upper: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    conf_level: float | None = field(
        default=None,
        converter=normalize_optional_conf_level,
        validator=is_optional_conf_level,
    )

    @property
    def has_inference(self) -> bool:
        """Check if inference has been computed."""
        return self.se is not None
