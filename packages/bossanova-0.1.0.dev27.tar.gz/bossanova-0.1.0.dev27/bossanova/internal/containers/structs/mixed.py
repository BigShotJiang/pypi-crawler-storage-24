"""Mixed-model post-fit containers."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np
from attrs import field, frozen, validators

from bossanova.internal.containers.validators import (
    is_conf_level,
    is_ndarray,
    is_optional_conf_level,
    is_positive_int,
    normalize_conf_level,
    normalize_optional_conf_level,
)

if TYPE_CHECKING:
    import polars as pl
    from numpy.typing import NDArray

__all__ = ["ProfileState", "VaryingSpreadState", "VaryingState"]


@frozen
class VaryingState:
    """Random effects (BLUPs) for mixed models.

    Created by: build_varying_state(), build_mixed_post_fit_state()
    Consumed by: build_varying_offsets_dataframe(), model.varying_offsets, model.varying_params
    Augmented by: attrs.evolve() after infer() adds prediction intervals
    """

    grid: "pl.DataFrame" = field(repr=False)
    effects: dict[str, np.ndarray] = field(validator=validators.instance_of(dict))
    grouping_var: str = field(validator=validators.instance_of(str))
    n_groups: int = field(validator=is_positive_int)
    pi_lower: dict[str, np.ndarray] | None = field(
        default=None, validator=validators.optional(validators.instance_of(dict))
    )
    pi_upper: dict[str, np.ndarray] | None = field(
        default=None, validator=validators.optional(validators.instance_of(dict))
    )
    conf_level: float | None = field(
        default=None,
        converter=normalize_optional_conf_level,
        validator=is_optional_conf_level,
    )

    @property
    def has_inference(self) -> bool:
        """Check if prediction intervals have been computed."""
        return self.pi_lower is not None


@frozen
class VaryingSpreadState:
    """Variance components for mixed models.

    Created by: build_varying_spread_state(), build_mixed_post_fit_state()
    Consumed by: build_varying_spread_dataframe(), model.varying_spread, model.varying_corr
    Augmented by: attrs.evolve() after infer() adds confidence intervals
    """

    components: "pl.DataFrame" = field(repr=False)
    sigma2: float = field(validator=validators.instance_of((int, float)))
    tau2: dict[str, float] = field(validator=validators.instance_of(dict))
    rho: dict[str, float] = field(factory=dict, validator=validators.instance_of(dict))
    icc: float | None = field(
        default=None,
        validator=validators.optional(validators.instance_of((int, float))),
    )
    ci_lower: dict[str, float] | None = field(
        default=None, validator=validators.optional(validators.instance_of(dict))
    )
    ci_upper: dict[str, float] | None = field(
        default=None, validator=validators.optional(validators.instance_of(dict))
    )
    conf_level: float | None = field(
        default=None,
        converter=normalize_optional_conf_level,
        validator=is_optional_conf_level,
    )
    ci_method: str | None = field(
        default=None,
        validator=validators.optional(validators.in_(("profile", "wald"))),
    )

    @property
    def has_inference(self) -> bool:
        """Check if confidence intervals have been computed."""
        return self.ci_lower is not None


@frozen
class ProfileState:
    """Profile likelihood state for variance component CIs.

    Created by: profile_likelihood(), ProfileState(**profile_data)
    Consumed by: infer_profile_variance_components(), plot_profile()
    Augmented by: Never
    """

    table: "pl.DataFrame" = field(repr=False)
    spline_forward: dict[str, Any] = field(
        repr=False, validator=validators.instance_of(dict)
    )
    spline_reverse: dict[str, Any] = field(
        repr=False, validator=validators.instance_of(dict)
    )
    ci_theta: dict[str, tuple[float, float]] = field(
        validator=validators.instance_of(dict)
    )
    ci_sd: dict[str, tuple[float, float]] = field(
        validator=validators.instance_of(dict)
    )
    ci_lower_sd: NDArray[np.floating] = field(repr=False, validator=is_ndarray)
    ci_upper_sd: NDArray[np.floating] = field(repr=False, validator=is_ndarray)
    conf_level: float = field(
        converter=normalize_conf_level,
        validator=is_conf_level,
    )
    dev_opt: float = field(validator=validators.instance_of((int, float)))
    threshold: float = field(
        default=4.0,
        validator=[validators.instance_of((int, float)), validators.gt(0)],
    )
