"""Simulation result containers."""

from __future__ import annotations

import numpy as np
from attrs import field, frozen, validators

from bossanova.internal.containers.validators import (
    is_optional_ndarray,
    is_positive_int,
)

__all__ = ["SimulationInferenceState"]


@frozen
class SimulationInferenceState:
    """Simulation inference results for post-fit or power analysis simulations.

    Created by: build_simulation_inference_state(), compute_simulation_inference()
    Consumed by: build_simulations_dataframe(), model.simulations
    Augmented by: Never
    """

    sim_type: str = field(validator=validators.in_(("post_fit", "power_analysis")))
    n_sims: int = field(validator=is_positive_int)
    sim_mean: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    sim_sd: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    sim_quantiles: dict[str, np.ndarray] = field(
        factory=dict, validator=validators.instance_of(dict)
    )
    power: dict[str, float] = field(
        factory=dict, validator=validators.instance_of(dict)
    )
    coverage: dict[str, float] = field(
        factory=dict, validator=validators.instance_of(dict)
    )
    bias: dict[str, float] = field(factory=dict, validator=validators.instance_of(dict))
    rmse: dict[str, float] = field(factory=dict, validator=validators.instance_of(dict))
    alpha: float = field(
        default=0.05,
        validator=[
            validators.instance_of((int, float)),
            validators.gt(0),
            validators.lt(1),
        ],
    )
    true_coef: dict[str, float] = field(
        factory=dict, validator=validators.instance_of(dict)
    )
