"""Fitting result containers."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from attrs import field, frozen, validators

from bossanova.internal.containers.validators import is_ndarray, is_optional_ndarray

if TYPE_CHECKING:
    from numpy.typing import NDArray

__all__ = ["FitState"]


@frozen
class FitState:
    """Immutable fitting result.

    Contains all state produced by fitting a model, including coefficients,
    variance-covariance matrix, fitted values, residuals, and model-specific
    parameters.

    Created by: build_fit_state(), fit_model()
    Consumed by: model.params, model.summary(), dispatch_infer()
    Augmented by: Never

    Attributes:
        coef: Coefficient estimates (1D array of length p).
        vcov: Variance-covariance matrix (p x p array).
        fitted: Fitted values (1D array of length n).
        residuals: Residuals (1D array of length n).
        leverage: Hat matrix diagonal / leverage values (1D array of length n).
        df_resid: Residual degrees of freedom.
        loglik: Log-likelihood at convergence.
        converged: Whether the optimization converged.
        n_iter: Number of iterations (1 for closed-form solutions).
        sigma: Residual standard deviation (OLS models only).
        dispersion: Dispersion parameter (GLM models only).
        null_deviance: Null model deviance (GLM models only).
        deviance: Residual deviance, sum of unit deviances (GLM models only).
        theta: Random effect variance parameters (mixed models only).
        u: Spherical random effects (mixed models only).
        irls_weights: IRLS weights from GLM fit (GLM sandwich estimator).
        XtWX_inv: Inverse of X'WX from GLM fit (GLM sandwich estimator).

    Examples:
        >>> import numpy as np
        >>> from bossanova.internal.containers.structs.fit import FitState
        >>> state = FitState(
        ...     coef=np.array([1.0, 2.0]),
        ...     vcov=np.eye(2),
        ...     fitted=np.array([1.0, 2.0, 3.0]),
        ...     residuals=np.array([0.1, -0.1, 0.0]),
        ...     leverage=np.array([0.3, 0.3, 0.4]),
        ...     df_resid=1.0,
        ...     loglik=-10.0,
        ... )
    """

    coef: NDArray[np.floating] = field(validator=is_ndarray)
    vcov: NDArray[np.floating] = field(validator=is_ndarray)
    fitted: NDArray[np.floating] = field(validator=is_ndarray)
    residuals: NDArray[np.floating] = field(validator=is_ndarray)
    leverage: NDArray[np.floating] = field(validator=is_ndarray)

    df_resid: float = field(validator=validators.instance_of((int, float)))
    loglik: float = field(validator=validators.instance_of((int, float)))

    converged: bool = field(default=True, validator=validators.instance_of(bool))
    n_iter: int = field(default=1, validator=validators.instance_of(int))

    sigma: float | None = field(
        default=None,
        validator=validators.optional(validators.instance_of((int, float))),
    )
    dispersion: float | None = field(
        default=None,
        validator=validators.optional(validators.instance_of((int, float))),
    )
    null_deviance: float | None = field(
        default=None,
        validator=validators.optional(validators.instance_of((int, float))),
    )
    deviance: float | None = field(
        default=None,
        validator=validators.optional(validators.instance_of((int, float))),
    )
    theta: NDArray[np.floating] | None = field(
        default=None,
        validator=is_optional_ndarray,
    )
    u: NDArray[np.floating] | None = field(
        default=None,
        validator=is_optional_ndarray,
    )
    irls_weights: NDArray[np.floating] | None = field(
        default=None,
        validator=is_optional_ndarray,
    )
    XtWX_inv: NDArray[np.floating] | None = field(
        default=None,
        validator=is_optional_ndarray,
    )
