"""Prediction result containers."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np
from attrs import field, frozen, validators

from bossanova.internal.containers.validators import (
    is_choice_str,
    is_ndarray,
    is_optional_conf_level,
    is_optional_ndarray,
    normalize_optional_conf_level,
)

if TYPE_CHECKING:
    import polars as pl

__all__ = ["PredictionConfig", "PredictionState"]


@frozen
class PredictionConfig:
    """Configuration that produced a PredictionState.

    Created by: model.predict(), build_prediction_state()
    Consumed by: dispatch_prediction_inference(), compute_prediction_bootstrap()
    Augmented by: Never
    """

    pred_type: str = field(validator=validators.in_(("response", "link")))
    varying: str = field(
        default="exclude", validator=validators.in_(("exclude", "include"))
    )
    allow_new_levels: bool = field(
        default=False, validator=validators.instance_of(bool)
    )
    newdata: "pl.DataFrame | None" = field(default=None, repr=False)
    formula_spec: Any = field(default=None, repr=False)
    training_data: "pl.DataFrame | None" = field(default=None, repr=False)


@frozen
class PredictionState:
    """Prediction results with optional intervals.

    Created by: build_prediction_state(), model.predict()
    Consumed by: build_predictions_dataframe(), model.predictions, plot_predict()
    Augmented by: attrs.evolve() after infer() adds intervals/CV outputs
    """

    fitted: np.ndarray = field(validator=is_ndarray)
    link: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    X_pred: np.ndarray | None = field(
        default=None, validator=is_optional_ndarray, repr=False
    )
    config: PredictionConfig | None = field(
        default=None,
        repr=False,
        validator=validators.optional(validators.instance_of(PredictionConfig)),
    )
    se: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    ci_lower: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    ci_upper: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    interval_type: str | None = field(
        default=None,
        validator=validators.optional(is_choice_str(("confidence", "prediction"))),
    )
    conf_level: float | None = field(
        default=None,
        converter=normalize_optional_conf_level,
        validator=is_optional_conf_level,
    )
    grid: "pl.DataFrame | None" = field(default=None, repr=False)
    cv_fitted: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    cv_residual: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    cv_fold: np.ndarray | None = field(default=None, validator=is_optional_ndarray)

    @property
    def has_inference(self) -> bool:
        """Check if inference has been computed."""
        return self.se is not None

    @property
    def has_cv(self) -> bool:
        """Check if CV inference has been computed."""
        return self.cv_fitted is not None
