"""Inference result containers."""

from __future__ import annotations

import numpy as np
from attrs import field, frozen, validators

from bossanova.internal.containers.validators import (
    is_choice_str,
    is_conf_level,
    is_ndarray,
    is_optional_ndarray,
    is_optional_positive_int,
    is_tuple_of_str,
    normalize_conf_level,
    to_tuple,
)

__all__ = [
    "CVState",
    "InferenceState",
    "JointTestState",
    "ResamplesState",
]


@frozen
class InferenceState:
    """Inference results that augment params or estimates.

    Contains standard errors, test statistics, p-values, and confidence
    intervals computed by .infer() on a fitted model.

    Created by: build_inference_state(), dispatch_params_inference()
    Consumed by: build_params_dataframe(), model.params, format_summary()
    Augmented by: Never
    """

    se: np.ndarray = field(validator=is_ndarray)
    statistic: np.ndarray = field(validator=is_ndarray)
    df: np.ndarray = field(validator=is_ndarray)
    p_value: np.ndarray = field(validator=is_ndarray)
    ci_lower: np.ndarray = field(validator=is_ndarray)
    ci_upper: np.ndarray = field(validator=is_ndarray)

    conf_level: float = field(
        default=0.95, converter=normalize_conf_level, validator=is_conf_level
    )
    method: str = field(
        default="asymp", validator=is_choice_str(("asymp", "boot", "perm", "cv"))
    )
    null: float = field(default=0.0, validator=validators.instance_of((int, float)))
    alternative: str = field(
        default="two-sided",
        validator=is_choice_str(("two-sided", "less", "greater")),
    )
    n_resamples: int | None = field(default=None, validator=is_optional_positive_int)
    boot_samples: np.ndarray | None = field(
        default=None, repr=False, validator=is_optional_ndarray
    )
    perm_samples: np.ndarray | None = field(
        default=None, repr=False, validator=is_optional_ndarray
    )
    pre: np.ndarray | None = field(default=None, validator=is_optional_ndarray)
    pre_sd: np.ndarray | None = field(default=None, validator=is_optional_ndarray)


@frozen
class JointTestState:
    """Joint hypothesis test results for model terms.

    Created by: build_joint_test_state(), compute_joint_test()
    Consumed by: build_joint_test_dataframe(), model.effects
    Augmented by: Never
    """

    terms: tuple[str, ...] = field(
        converter=to_tuple,
        validator=validators.deep_iterable(
            member_validator=validators.instance_of(str)
        ),
    )
    df1: np.ndarray = field(validator=is_ndarray)
    statistic: np.ndarray = field(validator=is_ndarray)
    p_value: np.ndarray = field(validator=is_ndarray)
    test_type: str = field(default="F", validator=validators.in_(("F", "chi2")))
    ss_type: str = field(default="III", validator=validators.in_(("II", "III")))
    df2: np.ndarray | None = field(default=None, validator=is_optional_ndarray)


@frozen
class CVState:
    """Cross-validation results for model evaluation.

    Created by: build_cv_state(), compute_prediction_cv_inference()
    Consumed by: model.cv_metrics, format_summary()
    Augmented by: Never
    """

    k: int = field(validator=[validators.instance_of(int), validators.gt(0)])
    mse: float = field(
        validator=[validators.instance_of((int, float)), validators.ge(0)]
    )
    rmse: float = field(
        validator=[validators.instance_of((int, float)), validators.ge(0)]
    )
    mae: float = field(
        validator=[validators.instance_of((int, float)), validators.ge(0)]
    )
    r_squared: float = field(validator=validators.instance_of((int, float)))
    deviance: float | None = field(
        default=None,
        validator=validators.optional(
            [validators.instance_of((int, float)), validators.ge(0)]
        ),
    )
    accuracy: float | None = field(
        default=None,
        validator=validators.optional(
            [validators.instance_of((int, float)), validators.ge(0), validators.le(1)]
        ),
    )
    sensitivity: float | None = field(
        default=None,
        validator=validators.optional(
            [validators.instance_of((int, float)), validators.ge(0), validators.le(1)]
        ),
    )
    specificity: float | None = field(
        default=None,
        validator=validators.optional(
            [validators.instance_of((int, float)), validators.ge(0), validators.le(1)]
        ),
    )
    f1: float | None = field(
        default=None,
        validator=validators.optional(
            [validators.instance_of((int, float)), validators.ge(0), validators.le(1)]
        ),
    )
    auc: float | None = field(
        default=None,
        validator=validators.optional(
            [validators.instance_of((int, float)), validators.ge(0), validators.le(1)]
        ),
    )
    fold_metrics: dict[str, np.ndarray] = field(factory=dict, repr=False)
    oos_predictions: np.ndarray | None = field(
        default=None, repr=False, validator=is_optional_ndarray
    )
    oos_residuals: np.ndarray | None = field(
        default=None, repr=False, validator=is_optional_ndarray
    )
    fold_assignments: np.ndarray | None = field(
        default=None, repr=False, validator=is_optional_ndarray
    )


@frozen
class ResamplesState:
    """Unified resampling results from bootstrap or permutation inference.

    Created by: build_resamples_state(), build_params_resamples(), build_mee_resamples()
    Consumed by: build_resamples_dataframe(), model.resamples
    Augmented by: Never
    """

    samples: np.ndarray = field(validator=is_ndarray)
    observed: np.ndarray = field(validator=is_ndarray)
    names: tuple[str, ...] = field(converter=to_tuple, validator=is_tuple_of_str)
    method: str = field(validator=validators.in_(("boot", "perm")))
    n_resamples: int = field(validator=[validators.instance_of(int), validators.gt(0)])
    context: str = field(validator=validators.in_(("params", "effects")))
