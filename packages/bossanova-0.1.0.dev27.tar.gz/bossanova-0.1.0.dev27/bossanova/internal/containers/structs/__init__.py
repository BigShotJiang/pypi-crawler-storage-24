"""Pure frozen data classes — zero logic beyond validation."""

from bossanova.internal.containers.structs.data import DataBundle, REInfo, RankInfo
from bossanova.internal.containers.structs.display import MathDisplay, TermInfo
from bossanova.internal.containers.structs.formula import FormulaSpec
from bossanova.internal.containers.structs.explore import (
    Condition,
    ExploreFormulaSpec,
    ExploreFormulaError,
)
from bossanova.internal.containers.structs.specs import (
    FAMILIES,
    FAMILY_DEFAULT_LINKS,
    LINKS,
    METHODS,
    Distribution,
    ModelSpec,
    SimulationSpec,
    VaryingSpec,
)
from bossanova.internal.containers.structs.fit import FitState
from bossanova.internal.containers.structs.inference import (
    CVState,
    InferenceState,
    JointTestState,
    ResamplesState,
)
from bossanova.internal.containers.structs.marginal import MeeState
from bossanova.internal.containers.structs.mixed import (
    ProfileState,
    VaryingSpreadState,
    VaryingState,
)
from bossanova.internal.containers.structs.prediction import (
    PredictionConfig,
    PredictionState,
)
from bossanova.internal.containers.structs.simulation import SimulationInferenceState

__all__ = [
    "FAMILIES",
    "FAMILY_DEFAULT_LINKS",
    "LINKS",
    "METHODS",
    "CVState",
    "Condition",
    "DataBundle",
    "Distribution",
    "ExploreFormulaError",
    "ExploreFormulaSpec",
    "FitState",
    "FormulaSpec",
    "InferenceState",
    "JointTestState",
    "MathDisplay",
    "MeeState",
    "ModelSpec",
    "PredictionConfig",
    "PredictionState",
    "ProfileState",
    "REInfo",
    "RankInfo",
    "ResamplesState",
    "SimulationInferenceState",
    "SimulationSpec",
    "TermInfo",
    "VaryingSpec",
    "VaryingSpreadState",
    "VaryingState",
]
