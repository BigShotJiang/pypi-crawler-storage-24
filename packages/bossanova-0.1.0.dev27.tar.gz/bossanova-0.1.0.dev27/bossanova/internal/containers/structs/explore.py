"""Parsing result containers for explore formulas."""

from attrs import field, frozen, validators

from bossanova.internal.containers.validators import (
    is_choice_str,
    is_optional_positive_int,
    is_optional_str,
    is_optional_tuple_of_str,
    is_tuple_of_str,
)

__all__ = [
    "Condition",
    "ContrastExpr",
    "ContrastItem",
    "ContrastOperand",
    "ExploreFormulaError",
    "ExploreFormulaSpec",
]


# =====================================================================
# Bracket contrast expression containers
# =====================================================================


@frozen
class ContrastOperand:
    """One side of a bracket contrast item.

    Represents a single operand in a contrast like ``A - B`` or
    ``(A + B) - C``.

    Created by: parse_explore_formula(), ExploreParser
    Consumed by: dispatch_bracket_contrasts(), apply_rhs_bracket_contrast()
    Augmented by: Never

    Attributes:
        levels: Level names for this operand. Empty tuple for wildcard.
            Multiple levels indicate a grouped mean (e.g., ``(A + B)``
            produces ``levels=("A", "B")``).
        is_wildcard: True for the ``*`` operator, which expands to all
            levels not mentioned on the other side.
    """

    levels: tuple[str, ...] = field(
        factory=tuple, converter=tuple, validator=is_tuple_of_str
    )
    is_wildcard: bool = field(default=False, validator=validators.instance_of(bool))


@frozen
class ContrastItem:
    """A single contrast: left operand minus right operand.

    Represents one ``left - right`` comparison in a bracket contrast
    expression like ``Drug[Active - Placebo]``.

    Created by: parse_explore_formula(), ExploreParser
    Consumed by: dispatch_bracket_contrasts(), apply_rhs_bracket_contrast()
    Augmented by: Never

    Attributes:
        left: Left operand (positive side).
        right: Right operand (negative side).
    """

    left: ContrastOperand = field(validator=validators.instance_of(ContrastOperand))
    right: ContrastOperand = field(validator=validators.instance_of(ContrastOperand))


@frozen
class ContrastExpr:
    """Bracket contrast expression: ``Drug[A - B, C - D]``.

    Represents a complete bracket contrast specification parsed from
    explore formula syntax.

    Created by: parse_explore_formula(), ExploreParser
    Consumed by: dispatch_bracket_contrasts(), apply_rhs_bracket_contrast()
    Augmented by: Never

    Attributes:
        var: Variable name (e.g., ``"Drug"``).
        items: Tuple of contrast items to compute.
    """

    var: str = field(validator=validators.instance_of(str))
    items: tuple[ContrastItem, ...] = field(
        converter=tuple,
        validator=validators.deep_iterable(
            member_validator=validators.instance_of(ContrastItem)
        ),
    )


@frozen
class Condition:
    """A conditioning specification in explore formula.

    Represents a variable to condition on, optionally with specific values,
    a method for generating values, or a bracket contrast expression.

    Created by: parse_explore_formula(), ExploreParser
    Consumed by: resolve_all_conditions(), dispatch_marginal_computation()
    Augmented by: Never

    Attributes:
        var: Variable name to condition on.
        at_values: Specific values to evaluate at (e.g., (50.0,) or ("A", "B")).
        at_range: Number of evenly-spaced values across the variable's range.
        at_quantile: Number of quantile values to use.
        contrast_expr: Bracket contrast expression on this condition variable
            (e.g., from ``Dose[High - Low]`` on the RHS). When set, the
            variable is treated as a grid categorical during condition
            resolution, and the contrast is applied as a post-processing step.
    """

    var: str = field(validator=validators.instance_of(str))
    at_values: tuple | None = field(default=None)
    at_range: int | None = field(default=None, validator=is_optional_positive_int)
    at_quantile: int | None = field(default=None, validator=is_optional_positive_int)
    contrast_expr: ContrastExpr | None = field(
        default=None,
        validator=validators.optional(validators.instance_of(ContrastExpr)),
    )


@frozen
class ExploreFormulaSpec:
    """Parsed explore formula.

    Represents a parsed explore formula with focal variable, optional contrast
    type, and conditioning specifications.

    Created by: parse_explore_formula()
    Consumed by: dispatch_marginal_computation(), plot_predict(), plot_explore()
    Augmented by: attrs.evolve() in resolve_focal_at_spec() materializes focal at-values

    Attributes:
        focal_var: The variable to compute marginal effects for.
        contrast_type: Type of contrast (pairwise, sequential, poly, treatment,
            sum, helmert, custom) or None for simple EMMs. Set to ``"custom"``
            for bracket contrast expressions.
        contrast_degree: Degree parameter for polynomial contrasts (default None
            means use n_levels - 1, i.e., maximum degree).
        contrast_ref: Reference level for treatment/dummy contrasts
            (e.g., ``"Placebo"`` from ``treatment(Drug, ref=Placebo)``).
        contrast_level_ordering: Explicit level ordering for order-dependent
            contrasts (helmert, sequential, poly). Parsed from bracket list
            syntax, e.g. ``poly(dose, [low, med, high])``.
        contrast_expr: Bracket contrast expression AST (e.g., from
            ``Drug[Active - Placebo]`` syntax). None for named contrast
            functions or simple EMMs.
        conditions: Tuple of Condition objects specifying conditioning variables.
        focal_at_values: Specific values to evaluate the focal variable at
            (e.g., from ``Days@[0, 3, 6, 9]`` syntax). None means use all levels.
        focal_at_range: Number of evenly-spaced values across the focal variable's
            range (e.g., from ``Days@range(5)`` syntax). None means not set.
        focal_at_quantile: Number of quantile values for the focal variable
            (e.g., from ``Days@quantile(3)`` syntax). None means not set.
    """

    focal_var: str = field(validator=validators.instance_of(str))
    contrast_type: str | None = field(
        default=None,
        validator=validators.optional(
            is_choice_str(
                (
                    "pairwise",
                    "sequential",
                    "poly",
                    "treatment",
                    "sum",
                    "helmert",
                    "custom",
                )
            )
        ),
    )
    contrast_degree: int | None = field(
        default=None, validator=is_optional_positive_int
    )
    contrast_ref: str | None = field(default=None, validator=is_optional_str)
    contrast_level_ordering: tuple[str, ...] | None = field(
        default=None, validator=is_optional_tuple_of_str
    )
    contrast_expr: ContrastExpr | None = field(default=None)
    conditions: tuple[Condition, ...] = field(factory=tuple, converter=tuple)
    focal_at_values: tuple[float | str, ...] | None = field(default=None)
    focal_at_range: int | None = field(default=None, validator=is_optional_positive_int)
    focal_at_quantile: int | None = field(
        default=None, validator=is_optional_positive_int
    )

    def __attrs_post_init__(self) -> None:
        """Validate at most one focal at-spec is set."""
        n_set = sum(
            x is not None
            for x in (self.focal_at_values, self.focal_at_range, self.focal_at_quantile)
        )
        if n_set > 1:
            raise ValueError(
                "At most one of focal_at_values, focal_at_range, focal_at_quantile "
                "may be set."
            )

    @property
    def has_contrast(self) -> bool:
        """Return True if any contrast is specified (named function or bracket expr)."""
        return self.contrast_type is not None or self.contrast_expr is not None

    @property
    def has_contrast_expr(self) -> bool:
        """Return True if a bracket contrast expression is specified."""
        return self.contrast_expr is not None

    @property
    def has_conditions(self) -> bool:
        """Return True if conditioning variables are specified."""
        return len(self.conditions) > 0

    @property
    def has_rhs_contrasts(self) -> bool:
        """Return True if any RHS condition has a bracket contrast expression."""
        return any(c.contrast_expr is not None for c in self.conditions)


class ExploreFormulaError(ValueError):
    """Error in explore formula syntax.

    Provides helpful error messages with position indicators for syntax errors.

    Args:
        message: Error description.
        formula: The formula that caused the error.
        position: Character position of the error (optional).
    """

    def __init__(
        self,
        message: str,
        formula: str,
        position: int | None = None,
    ) -> None:
        """Initialize ExploreFormulaError.

        Args:
            message: Error description.
            formula: The formula that caused the error.
            position: Character position of the error.
        """
        self.formula = formula
        self.position = position
        if position is not None:
            pointer = " " * position + "^"
            message = f"{message}\n  {formula}\n  {pointer}"
        super().__init__(message)
