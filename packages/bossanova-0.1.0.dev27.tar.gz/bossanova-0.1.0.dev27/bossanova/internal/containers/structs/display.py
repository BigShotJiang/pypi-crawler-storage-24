"""Display containers for LaTeX equation rendering."""

from __future__ import annotations

from typing import TYPE_CHECKING

from attrs import field, frozen, validators

if TYPE_CHECKING:
    from pathlib import Path

__all__ = [
    "MathDisplay",
    "TermInfo",
]


@frozen
class TermInfo:
    """Parsed information about a single model term.

    Created by: categorize_term()
    Consumed by: build_lm_equation(), build_glm_equation(), build_mixed_equation()
    Augmented by: Never

    Attributes:
        name: Original term name (e.g., "center(x1)", "group[B]").
        term_type: Category — "intercept", "continuous", "factor",
            "interaction", "transform", or "poly".
        base_var: Underlying variable name (e.g., "x1" for "center(x1)").
        symbol: LaTeX symbol (e.g., r"\\beta_1").
        latex: Full LaTeX term (e.g., r"\\beta_1 x_{1i}").
        explanation: Human-readable explanation string.
    """

    name: str = field(validator=validators.instance_of(str))
    term_type: str = field(validator=validators.instance_of(str))
    base_var: str = field(validator=validators.instance_of(str))
    symbol: str = field(validator=validators.instance_of(str))
    latex: str = field(validator=validators.instance_of(str))
    explanation: str = field(validator=validators.instance_of(str))


@frozen
class MathDisplay:
    """Display wrapper for model equation with IPython rich display.

    Renders as LaTeX in Jupyter notebooks and Quarto documents.
    Falls back to HTML+MathJax or plain text in other environments.

    Created by: build_equation()
    Consumed by: model.show_math(), MathDisplay.to_markdown(), notebook display hooks
    Augmented by: Never

    Attributes:
        equation: LaTeX equation string (without $$ delimiters).
        explanations: Term explanation strings.

    Examples:
        >>> display = m.show_math()
        >>> display.to_latex()   # raw LaTeX string
        >>> display              # renders in Jupyter
    """

    equation: str = field(validator=validators.instance_of(str))
    explanations: tuple[str, ...] = field(
        factory=tuple,
        validator=validators.deep_iterable(
            member_validator=validators.instance_of(str)
        ),
    )

    def _repr_latex_(self) -> str:
        """LaTeX representation for Jupyter rendering."""
        return f"$${self.equation}$$"

    def _repr_html_(self) -> str:
        """HTML representation with MathJax fallback."""
        parts = [
            '<script id="MathJax-script" async '
            'src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>',
            f'<div style="font-size: 1.2em; margin: 1em 0;">$${self.equation}$$</div>',
        ]
        if self.explanations:
            parts.append('<div style="margin-top: 1em;">')
            parts.append("<strong>Terms:</strong>")
            parts.append('<ul style="list-style: none; padding-left: 0;">')
            for exp in self.explanations:
                parts.append(f"<li>{exp}</li>")
            parts.append("</ul>")
            parts.append("</div>")
        return "\n".join(parts)

    def __repr__(self) -> str:
        """Plain text representation."""
        parts = [self.equation]
        if self.explanations:
            parts.append("")
            parts.append("Terms:")
            for exp in self.explanations:
                parts.append(f"  {exp}")
        return "\n".join(parts)

    def __str__(self) -> str:
        """String representation."""
        return self.__repr__()

    def to_latex(self) -> str:
        """Get raw LaTeX equation string.

        Returns:
            LaTeX equation without $$ delimiters.
        """
        return self.equation

    def to_markdown(
        self,
        path: str | Path | None = None,
        *,
        include_explanations: bool = True,
    ) -> str:
        """Export equation as Quarto-compatible display math markdown.

        Wraps the equation in ``$$...$$`` display math delimiters. When
        *include_explanations* is True, appends the term explanations as
        a bulleted list below the equation block.

        Suitable for embedding in ``.qmd`` files via Quarto's
        ``{{< include >}}`` shortcode.

        Args:
            path: Optional file path to write the markdown. Parent
                directories are created automatically. If None, returns
                the string without writing.
            include_explanations: If True (default), append term
                explanations below the equation.

        Returns:
            Markdown string with ``$$equation$$`` and optional
            explanations.

        Examples:
            >>> m.show_math().to_markdown("equations/model_eq.md")
            >>> md = m.show_math().to_markdown(include_explanations=False)
        """
        from bossanova.internal.rendering.markdown import (
            equation_to_markdown,
            write_text,
        )

        text = equation_to_markdown(
            self.equation,
            self.explanations,
            include_explanations=include_explanations,
        )
        if path is not None:
            write_text(text, path)
        return text
