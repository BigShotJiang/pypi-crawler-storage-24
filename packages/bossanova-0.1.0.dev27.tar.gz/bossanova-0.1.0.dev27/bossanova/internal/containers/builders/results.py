"""Result DataFrame assembly utilities.

Shared helpers for building user-facing DataFrames from internal state
containers. These are used by the model property accessors (``effects``,
``predictions``, etc.) to assemble Polars DataFrames with optional
inference columns.
"""

from __future__ import annotations

import polars as pl

from bossanova.internal.containers.schemas import Col

__all__ = [
    "append_inference_columns",
]

# Standard inference column names, in canonical display order.
# Estimation group (se, CIs) first, then testing group (statistic, df, p_value).
_INFERENCE_COLS: tuple[str, ...] = (
    Col.SE,
    Col.CI_LOWER,
    Col.CI_UPPER,
    Col.STATISTIC,
    Col.DF,
    Col.P_VALUE,
)

# Columns excluded per inference method.
_BOOT_EXCLUDE: frozenset[str] = frozenset()
_PERM_EXCLUDE: frozenset[str] = frozenset({Col.CI_LOWER, Col.CI_UPPER})


def append_inference_columns(
    df: pl.DataFrame,
    state: object,
    method: str | None = None,
) -> pl.DataFrame:
    """Append standard inference columns to a DataFrame if available.

    Checks ``state.has_inference`` and, when True, adds each inference
    column that is not None on *state*. Columns are added in canonical
    order: se, ci_lower, ci_upper, statistic, df, p_value.

    When *method* is ``"perm"``, the ``ci_lower`` and ``ci_upper``
    columns are excluded.

    Args:
        df: Base DataFrame to augment (not mutated).
        state: Object with a ``has_inference`` bool and optional ``se``,
            ``statistic``, ``df``, ``p_value``, ``ci_lower``,
            ``ci_upper`` array attributes.
        method: Inference method (``"asymp"``, ``"boot"``, ``"perm"``,
            or ``None``). Controls which columns are included.

    Returns:
        A new DataFrame with inference columns appended (or the
        original DataFrame unchanged if inference is not available).
    """
    if not getattr(state, "has_inference", False):
        return df

    if method == "boot":
        exclude = _BOOT_EXCLUDE
    elif method == "perm":
        exclude = _PERM_EXCLUDE
    else:
        exclude = frozenset()

    for col_name in _INFERENCE_COLS:
        if col_name in exclude:
            continue
        values = getattr(state, col_name, None)
        if values is not None:
            df = df.with_columns(pl.Series(col_name, values))

    return df
