"""Builder functions for computation state containers."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np


from bossanova.internal.containers.structs.fit import FitState
from bossanova.internal.containers.structs.inference import (
    CVState,
    InferenceState,
    JointTestState,
)
from bossanova.internal.containers.structs.marginal import MeeState
from bossanova.internal.containers.structs.mixed import (
    VaryingSpreadState,
    VaryingState,
)
from bossanova.internal.containers.structs.prediction import (
    PredictionConfig,
    PredictionState,
)
from bossanova.internal.containers.structs.simulation import (
    SimulationInferenceState,
)

if TYPE_CHECKING:
    import polars as pl
    from numpy.typing import NDArray

__all__ = [
    "build_cv_state",
    "build_fit_state",
    "build_inference_state",
    "build_joint_test_state",
    "build_mee_state",
    "build_prediction_state",
    "build_simulation_inference_state",
    "build_varying_spread_state",
    "build_varying_state",
]


def build_fit_state(
    *,
    coef: NDArray[np.floating],
    vcov: NDArray[np.floating],
    fitted: NDArray[np.floating],
    residuals: NDArray[np.floating],
    leverage: NDArray[np.floating],
    df_resid: float,
    loglik: float,
    converged: bool = True,
    n_iter: int = 1,
    sigma: float | None = None,
    dispersion: float | None = None,
    null_deviance: float | None = None,
    deviance: float | None = None,
    theta: NDArray[np.floating] | None = None,
    u: NDArray[np.floating] | None = None,
    irls_weights: NDArray[np.floating] | None = None,
    XtWX_inv: NDArray[np.floating] | None = None,
) -> FitState:
    """Build a FitState instance with validation.

    This builder function provides a keyword-only interface for constructing
    FitState instances, ensuring all required fields are explicitly provided.

    Args:
        coef: Coefficient estimates (1D array of length p).
        vcov: Variance-covariance matrix (p x p array).
        fitted: Fitted values (1D array of length n).
        residuals: Residuals (1D array of length n).
        leverage: Hat matrix diagonal / leverage values (1D array of length n).
        df_resid: Residual degrees of freedom.
        loglik: Log-likelihood at convergence.
        converged: Whether the optimization converged.
        n_iter: Number of iterations (1 for closed-form solutions).
        sigma: Residual standard deviation (OLS models only).
        dispersion: Dispersion parameter (GLM models only).
        null_deviance: Null model deviance (GLM models only).
        deviance: Residual deviance, sum of unit deviances (GLM models only).
        theta: Random effect variance parameters (mixed models only).
        u: Spherical random effects (mixed models only).
        irls_weights: IRLS weights from GLM fit (GLM sandwich estimator).
        XtWX_inv: Inverse of X'WX from GLM fit (GLM sandwich estimator).

    Returns:
        A new FitState instance.

    Examples:
        >>> import numpy as np
        >>> from bossanova.internal.containers.builders.state import build_fit_state
        >>> state = build_fit_state(
        ...     coef=np.array([1.0, 2.0]),
        ...     vcov=np.eye(2),
        ...     fitted=np.array([1.0, 2.0, 3.0]),
        ...     residuals=np.array([0.1, -0.1, 0.0]),
        ...     leverage=np.array([0.3, 0.3, 0.4]),
        ...     df_resid=1.0,
        ...     loglik=-10.0,
        ...     sigma=0.5,
        ... )
        >>> state.sigma
        0.5
    """
    return FitState(
        coef=coef,
        vcov=vcov,
        fitted=fitted,
        residuals=residuals,
        leverage=leverage,
        df_resid=df_resid,
        loglik=loglik,
        converged=converged,
        n_iter=n_iter,
        sigma=sigma,
        dispersion=dispersion,
        null_deviance=null_deviance,
        deviance=deviance,
        theta=theta,
        u=u,
        irls_weights=irls_weights,
        XtWX_inv=XtWX_inv,
    )


def build_inference_state(
    se: np.ndarray,
    statistic: np.ndarray,
    df: np.ndarray,
    p_value: np.ndarray,
    ci_lower: np.ndarray,
    ci_upper: np.ndarray,
    *,
    conf_level: float = 0.95,
    method: str = "asymp",
    null: float = 0.0,
    alternative: str = "two-sided",
    n_resamples: int | None = None,
    boot_samples: np.ndarray | None = None,
    perm_samples: np.ndarray | None = None,
    pre: np.ndarray | None = None,
    pre_sd: np.ndarray | None = None,
) -> InferenceState:
    """Build an InferenceState from computed inference values.

    Args:
        se: Standard errors for each coefficient.
        statistic: Test statistics (t or z).
        df: Degrees of freedom.
        p_value: P-values.
        ci_lower: Lower confidence interval bounds.
        ci_upper: Upper confidence interval bounds.
        conf_level: Confidence level (default 0.95).
        method: Inference method ("asymp", "boot", "perm", "cv").
        null: Null hypothesis value (default 0.0).
        alternative: Alternative hypothesis direction (default "two-sided").
        n_resamples: Number of bootstrap/permutation resamples.
        boot_samples: Raw bootstrap samples.
        perm_samples: Null distribution of test statistics from permutation tests.
        pre: PRE (Proportion Reduction in Error) per coefficient (CV ablation).
        pre_sd: Standard deviation of PRE across CV folds (CV ablation).

    Returns:
        Frozen InferenceState instance.

    Examples:
        >>> state = build_inference_state(
        ...     se=np.array([0.1, 0.2]),
        ...     statistic=np.array([5.0, 2.5]),
        ...     df=np.array([98.0, 98.0]),
        ...     p_value=np.array([0.001, 0.014]),
        ...     ci_lower=np.array([0.3, 0.1]),
        ...     ci_upper=np.array([0.7, 0.9]),
        ... )
    """
    return InferenceState(
        se=se,
        statistic=statistic,
        df=df,
        p_value=p_value,
        ci_lower=ci_lower,
        ci_upper=ci_upper,
        conf_level=conf_level,
        method=method,
        null=null,
        alternative=alternative,
        n_resamples=n_resamples,
        boot_samples=boot_samples,
        perm_samples=perm_samples,
        pre=pre,
        pre_sd=pre_sd,
    )


def build_mee_state(
    grid: "pl.DataFrame",
    estimate: np.ndarray,
    explore_formula: str,
    focal_var: str,
    mee_type: str,
    *,
    how: str = "mem",
    effect_scale: str = "link",
    L_matrix: np.ndarray | None = None,
    contrast_method: str | None = None,
    n_contrast_levels: int | None = None,
    link: str | None = None,
    L_matrix_link: np.ndarray | None = None,
    boot_X_plus: np.ndarray | None = None,
    boot_X_minus: np.ndarray | None = None,
    boot_delta: float | None = None,
    se: np.ndarray | None = None,
    df: np.ndarray | None = None,
    statistic: np.ndarray | None = None,
    p_value: np.ndarray | None = None,
    ci_lower: np.ndarray | None = None,
    ci_upper: np.ndarray | None = None,
    conf_level: float | None = None,
) -> MeeState:
    """Build a MeeState from marginal effects computation.

    Args:
        grid: Polars DataFrame with the evaluation grid.
        estimate: Point estimates for each grid row.
        explore_formula: The explore formula string.
        focal_var: The primary variable being explored.
        mee_type: Type of effect ("means", "slopes", "contrasts").
        how: Averaging method: ``"mem"`` (Marginal Estimated Mean,
            balanced reference grid) or ``"ame"`` (Average Marginal
            Effect, g-computation over observed data).
        effect_scale: Scale of estimates: ``"link"`` (linear predictor)
            or ``"response"`` (inverse-link / data scale).
        L_matrix: Design matrix for delta method inference (optional).
            Shape (n_estimates, n_coef). For EMMs this is X_ref.
        contrast_method: Original contrast type for multiplicity adjustment
            ("pairwise", "sequential", "poly", "treatment", "sum",
            "helmert", or None).
        n_contrast_levels: Number of EMM levels before contrasting (family size).
        link: Link function name for response-scale CI back-transformation.
        L_matrix_link: Link-scale L_matrix for CI back-transformation.
        boot_X_plus: Per-combo average design matrix at focal_var + delta/2.
            For exact response-scale bootstrap AME recomputation.
        boot_X_minus: Per-combo average design matrix at focal_var - delta/2.
        boot_delta: Finite-difference step size for bootstrap slope recomputation.
        se: Standard errors (optional, from .infer()).
        df: Degrees of freedom (optional).
        statistic: Test statistics (optional).
        p_value: P-values (optional).
        ci_lower: Lower CI bounds (optional).
        ci_upper: Upper CI bounds (optional).
        conf_level: Confidence level (optional).

    Returns:
        Frozen MeeState instance.

    Examples:
        >>> import polars as pl
        >>> grid = pl.DataFrame({"treatment": ["A", "B", "C"]})
        >>> state = build_mee_state(
        ...     grid=grid,
        ...     estimate=np.array([1.0, 2.0, 3.0]),
        ...     explore_formula="treatment",
        ...     focal_var="treatment",
        ...     mee_type="means",
        ... )
        >>> state.has_inference
        False
    """
    return MeeState(
        grid=grid,
        estimate=estimate,
        explore_formula=explore_formula,
        focal_var=focal_var,
        type=mee_type,
        how=how,
        effect_scale=effect_scale,
        L_matrix=L_matrix,
        contrast_method=contrast_method,
        n_contrast_levels=n_contrast_levels,
        link=link,
        L_matrix_link=L_matrix_link,
        boot_X_plus=boot_X_plus,
        boot_X_minus=boot_X_minus,
        boot_delta=boot_delta,
        se=se,
        df=df,
        statistic=statistic,
        p_value=p_value,
        ci_lower=ci_lower,
        ci_upper=ci_upper,
        conf_level=conf_level,
    )


def build_joint_test_state(
    terms: tuple[str, ...] | list[str],
    df1: np.ndarray,
    statistic: np.ndarray,
    p_value: np.ndarray,
    *,
    test_type: str = "F",
    ss_type: str = "III",
    df2: np.ndarray | None = None,
) -> JointTestState:
    """Build a JointTestState from computed joint test values.

    Args:
        terms: Names of terms being tested.
        df1: Numerator degrees of freedom per term.
        statistic: Test statistic values (F or chi2).
        p_value: P-values for each term.
        test_type: Type of test ("F" for linear models, "chi2" for GLMs).
        ss_type: Sum of squares type ("II" or "III").
        df2: Denominator degrees of freedom (required for F-tests).

    Returns:
        Frozen JointTestState instance.

    Raises:
        ValueError: If test_type is "F" and df2 is None.
        ValueError: If array lengths don't match number of terms.

    Examples:
        F-test results (linear model)::

            >>> state = build_joint_test_state(
            ...     terms=("a", "b", "a:b"),
            ...     df1=np.array([2, 1, 2]),
            ...     df2=np.array([94, 94, 94]),
            ...     statistic=np.array([5.2, 12.1, 0.8]),
            ...     p_value=np.array([0.007, 0.001, 0.45]),
            ...     test_type="F",
            ... )

        Chi-square results (GLM)::

            >>> state = build_joint_test_state(
            ...     terms=("a", "b"),
            ...     df1=np.array([2, 1]),
            ...     statistic=np.array([8.5, 15.2]),
            ...     p_value=np.array([0.014, 0.0001]),
            ...     test_type="chi2",
            ... )
    """
    # Convert list to tuple if needed
    if isinstance(terms, list):
        terms = tuple(terms)

    # Validate
    n_terms = len(terms)
    if len(df1) != n_terms:
        raise ValueError(f"df1 length ({len(df1)}) must match terms count ({n_terms})")
    if len(statistic) != n_terms:
        raise ValueError(
            f"statistic length ({len(statistic)}) must match terms count ({n_terms})"
        )
    if len(p_value) != n_terms:
        raise ValueError(
            f"p_value length ({len(p_value)}) must match terms count ({n_terms})"
        )

    if test_type == "F" and df2 is None and n_terms > 0:
        raise ValueError("df2 is required for F-tests")

    if df2 is not None and len(df2) != n_terms:
        raise ValueError(f"df2 length ({len(df2)}) must match terms count ({n_terms})")

    if test_type not in ("F", "chi2"):
        raise ValueError(f"test_type must be 'F' or 'chi2', got {test_type!r}")

    if ss_type not in ("II", "III"):
        raise ValueError(f"ss_type must be 'II' or 'III', got {ss_type!r}")

    return JointTestState(
        terms=terms,
        df1=df1,
        statistic=statistic,
        p_value=p_value,
        test_type=test_type,
        ss_type=ss_type,
        df2=df2,
    )


def build_prediction_state(
    fitted: np.ndarray,
    *,
    link: np.ndarray | None = None,
    X_pred: np.ndarray | None = None,
    config: PredictionConfig | None = None,
    se: np.ndarray | None = None,
    ci_lower: np.ndarray | None = None,
    ci_upper: np.ndarray | None = None,
    interval_type: str | None = None,
    conf_level: float | None = None,
    grid: "pl.DataFrame | None" = None,
) -> PredictionState:
    """Build a PredictionState from prediction computation.

    Args:
        fitted: Predicted values on response scale.
        link: Predicted values on link scale (for GLM/GLMM).
        X_pred: Design matrix used for predictions. Stored so that
            ``.infer()`` can compute delta-method SEs on the correct X.
        config: Prediction configuration for bootstrap replay.
        se: Standard errors of predictions.
        ci_lower: Lower interval bounds.
        ci_upper: Upper interval bounds.
        interval_type: Type of interval ("confidence" or "prediction").
        conf_level: Confidence level for intervals.
        grid: Grid DataFrame for formula-mode predictions. When present,
            ``build_predictions_dataframe()`` prepends these columns.

    Returns:
        Frozen PredictionState instance.

    Examples:
        >>> state = build_prediction_state(
        ...     fitted=np.array([1.0, 2.0, 3.0]),
        ... )
        >>> state.has_inference
        False
        >>> # With inference
        >>> state = build_prediction_state(
        ...     fitted=np.array([1.0, 2.0, 3.0]),
        ...     se=np.array([0.1, 0.1, 0.1]),
        ...     ci_lower=np.array([0.8, 1.8, 2.8]),
        ...     ci_upper=np.array([1.2, 2.2, 3.2]),
        ...     interval_type="confidence",
        ...     conf_level=0.95,
        ... )
        >>> state.has_inference
        True
    """
    return PredictionState(
        fitted=fitted,
        link=link,
        X_pred=X_pred,
        config=config,
        se=se,
        ci_lower=ci_lower,
        ci_upper=ci_upper,
        interval_type=interval_type,
        conf_level=conf_level,
        grid=grid,
    )


def build_cv_state(
    k: int,
    mse: float,
    rmse: float,
    mae: float,
    r_squared: float,
    *,
    deviance: float | None = None,
    accuracy: float | None = None,
    sensitivity: float | None = None,
    specificity: float | None = None,
    f1: float | None = None,
    auc: float | None = None,
    fold_metrics: dict[str, np.ndarray] | None = None,
    oos_predictions: np.ndarray | None = None,
    oos_residuals: np.ndarray | None = None,
    fold_assignments: np.ndarray | None = None,
) -> CVState:
    """Build a CVState from cross-validation computation.

    Args:
        k: Number of folds used.
        mse: Mean squared error (out-of-sample).
        rmse: Root mean squared error.
        mae: Mean absolute error.
        r_squared: Coefficient of determination.
        deviance: Mean deviance (GLM only).
        accuracy: Classification accuracy (binomial only).
        sensitivity: Sensitivity / true positive rate (binomial only).
        specificity: Specificity / true negative rate (binomial only).
        f1: F1 score (binomial only).
        auc: Area under ROC curve (binomial only).
        fold_metrics: Per-fold metrics dictionary.
        oos_predictions: Out-of-sample predictions.
        oos_residuals: Out-of-sample residuals.
        fold_assignments: Array indicating which fold each observation belongs to.

    Returns:
        Frozen CVState instance.

    Examples:
        >>> state = build_cv_state(
        ...     k=10,
        ...     mse=0.274,
        ...     rmse=0.523,
        ...     mae=0.412,
        ...     r_squared=0.891,
        ... )
    """
    return CVState(
        k=k,
        mse=mse,
        rmse=rmse,
        mae=mae,
        r_squared=r_squared,
        deviance=deviance,
        accuracy=accuracy,
        sensitivity=sensitivity,
        specificity=specificity,
        f1=f1,
        auc=auc,
        fold_metrics=fold_metrics if fold_metrics is not None else {},
        oos_predictions=oos_predictions,
        oos_residuals=oos_residuals,
        fold_assignments=fold_assignments,
    )


def build_simulation_inference_state(
    sim_type: str,
    n_sims: int,
    *,
    sim_mean: np.ndarray | None = None,
    sim_sd: np.ndarray | None = None,
    sim_quantiles: dict[str, np.ndarray] | None = None,
    power: dict[str, float] | None = None,
    coverage: dict[str, float] | None = None,
    bias: dict[str, float] | None = None,
    rmse: dict[str, float] | None = None,
    alpha: float = 0.05,
    true_coef: dict[str, float] | None = None,
) -> SimulationInferenceState:
    """Build a SimulationInferenceState from computed values.

    Args:
        sim_type: Type of simulation ("post_fit" or "power_analysis").
        n_sims: Number of simulations.
        sim_mean: Mean of simulated values per observation.
        sim_sd: SD of simulated values per observation.
        sim_quantiles: Dict of quantile name -> array mappings.
        power: Dict of term name -> power mappings.
        coverage: Dict of term name -> coverage mappings.
        bias: Dict of term name -> bias mappings.
        rmse: Dict of term name -> RMSE mappings.
        alpha: Significance level for power calculation.
        true_coef: True coefficient values for coverage/bias.

    Returns:
        Frozen SimulationInferenceState instance.

    Examples:
        >>> state = build_simulation_inference_state(
        ...     sim_type="post_fit",
        ...     n_sims=100,
        ...     sim_mean=np.array([1.0, 2.0, 3.0]),
        ...     sim_sd=np.array([0.1, 0.2, 0.3]),
        ... )
    """
    return SimulationInferenceState(
        sim_type=sim_type,
        n_sims=n_sims,
        sim_mean=sim_mean,
        sim_sd=sim_sd,
        sim_quantiles=sim_quantiles if sim_quantiles is not None else {},
        power=power if power is not None else {},
        coverage=coverage if coverage is not None else {},
        bias=bias if bias is not None else {},
        rmse=rmse if rmse is not None else {},
        alpha=alpha,
        true_coef=true_coef if true_coef is not None else {},
    )


def build_varying_state(
    grid: "pl.DataFrame",
    effects: dict[str, np.ndarray],
    grouping_var: str,
    n_groups: int,
    *,
    pi_lower: dict[str, np.ndarray] | None = None,
    pi_upper: dict[str, np.ndarray] | None = None,
    conf_level: float | None = None,
) -> VaryingState:
    """Build a VaryingState from computed BLUPs.

    Args:
        grid: Polars DataFrame with group identifiers.
        effects: Dict mapping effect names to BLUP arrays.
        grouping_var: Name of the grouping variable.
        n_groups: Number of groups.
        pi_lower: Lower prediction interval bounds (optional).
        pi_upper: Upper prediction interval bounds (optional).
        conf_level: Confidence level for intervals (optional).

    Returns:
        Frozen VaryingState instance.

    Examples:
        >>> state = build_varying_state(
        ...     grid=pl.DataFrame({"subject": ["S1", "S2", "S3"]}),
        ...     effects={"Intercept": np.array([0.5, -0.3, 0.1])},
        ...     grouping_var="subject",
        ...     n_groups=3,
        ... )
    """
    return VaryingState(
        grid=grid,
        effects=effects,
        grouping_var=grouping_var,
        n_groups=n_groups,
        pi_lower=pi_lower,
        pi_upper=pi_upper,
        conf_level=conf_level,
    )


def build_varying_spread_state(
    components: "pl.DataFrame",
    sigma2: float,
    tau2: dict[str, float],
    *,
    rho: dict[str, float] | None = None,
    icc: float | None = None,
    ci_lower: dict[str, float] | None = None,
    ci_upper: dict[str, float] | None = None,
    conf_level: float | None = None,
    ci_method: str | None = None,
) -> VaryingSpreadState:
    """Build a VaryingSpreadState from variance component estimates.

    Args:
        components: Polars DataFrame with component estimates.
        sigma2: Residual variance.
        tau2: Dict mapping effect names to variance estimates.
        rho: Dict mapping effect pairs to correlations (optional).
        icc: Intraclass correlation coefficient (optional).
        ci_lower: Lower CI bounds (optional, from .infer()).
        ci_upper: Upper CI bounds (optional, from .infer()).
        conf_level: Confidence level (optional).
        ci_method: CI method used (optional).

    Returns:
        Frozen VaryingSpreadState instance.

    Examples:
        >>> import polars as pl
        >>> components = pl.DataFrame({
        ...     "component": ["sigma2", "tau2_Intercept", "icc"],
        ...     "estimate": [1.0, 0.5, 0.33],
        ... })
        >>> state = build_varying_spread_state(
        ...     components=components,
        ...     sigma2=1.0,
        ...     tau2={"Intercept": 0.5},
        ...     icc=0.33,
        ... )
    """
    return VaryingSpreadState(
        components=components,
        sigma2=sigma2,
        tau2=tau2,
        rho=rho if rho is not None else {},
        icc=icc,
        ci_lower=ci_lower,
        ci_upper=ci_upper,
        conf_level=conf_level,
        ci_method=ci_method,
    )
