"""Reference design matrix (X_ref) construction for marginal effects."""

import numpy as np

from bossanova.internal.design.names import (
    identify_column_type,
    parse_design_column_name,
)

__all__ = [
    "build_continuous_reference_matrix",
    "build_counterfactual_design_matrices",
    "build_reference_design_matrix",
    "build_reference_row",
]


def build_reference_design_matrix(
    X_names: tuple[str, ...] | list[str],
    focal_var: str,
    levels: list[str],
    X_means: np.ndarray,
    *,
    set_categoricals: dict[str, str] | None = None,
) -> np.ndarray:
    """Build design matrix for reference grid points.

    Creates an X_ref matrix with one row per focal variable level. Each row
    represents a reference point where the focal variable is set to that level
    and all other covariates are set to their reference values.

    Reference value conventions:
    - Intercept: 1.0
    - Focal variable dummies: 1.0 if matching level, 0.0 otherwise
    - Continuous covariates: column mean from X_means
    - Non-focal categorical dummies: column mean (marginalize over observed proportions)

    Args:
        X_names: Column names from the design matrix, in order.
        focal_var: Name of the categorical variable to vary across levels.
        levels: List of levels for the focal variable, defining row order.
        X_means: Column means of the original design matrix, shape (p,).
            Used for continuous covariate reference values.
        set_categoricals: Optional dict mapping non-focal categorical variable
            names to specific levels to pin them at (instead of marginalizing
            at X_means). E.g. ``{"Ethnicity": "Asian"}`` sets the Ethnicity
            dummies to indicator values for "Asian".

    Returns:
        Reference design matrix X_ref, shape (n_levels, p).

    Examples:
        Compute X_ref for treatment EMMs::

            X_names = ("Intercept", "x", "treatment[A]", "treatment[B]")
            X_means = np.array([1.0, 2.5, 0.33, 0.33])  # means from data
            levels = ["ref", "A", "B"]

            X_ref = build_reference_design_matrix(X_names, "treatment", levels, X_means)
            # X_ref[0] = [1.0, 2.5, 0.0, 0.0]  # reference level
            # X_ref[1] = [1.0, 2.5, 1.0, 0.0]  # level A
            # X_ref[2] = [1.0, 2.5, 0.0, 1.0]  # level B

    Note:
        The first level is typically the reference level (omitted from dummy
        coding), so its row has all 0s for the focal variable dummies.
    """
    p = len(X_names)
    n_levels = len(levels)

    X_ref = np.zeros((n_levels, p), dtype=np.float64)

    for i, level in enumerate(levels):
        X_ref[i] = build_reference_row(
            X_names, focal_var, level, X_means, set_categoricals=set_categoricals
        )

    return X_ref


def build_reference_row(
    X_names: tuple[str, ...] | list[str],
    focal_var: str,
    focal_level: str,
    X_means: np.ndarray,
    *,
    set_categoricals: dict[str, str] | None = None,
) -> np.ndarray:
    """Build a single row of the reference design matrix.

    Creates one reference point where the focal variable is set to the
    specified level and other covariates are at reference values.

    For interaction columns involving the focal variable (e.g.,
    ``Income:Student[Yes]`` when ``focal_var="Student"``), the value is
    computed as the product of component values rather than using the
    empirical mean of the interaction column.

    Args:
        X_names: Column names from the design matrix.
        focal_var: Name of the focal categorical variable.
        focal_level: Level value to set for the focal variable.
        X_means: Column means for continuous covariate reference values.
        set_categoricals: Optional dict mapping non-focal categorical variable
            names to specific levels for indicator encoding. When a non-focal
            categorical's ``base_term`` matches a key, the dummy is set to
            ``1.0`` if the level matches, ``0.0`` otherwise (instead of using
            the column mean for marginalization).

    Returns:
        Reference row, shape (p,).
    """
    p = len(X_names)
    row = np.zeros(p, dtype=np.float64)
    X_names_list = list(X_names)

    for j, name in enumerate(X_names):
        info = parse_design_column_name(name)

        if info.column_type == "intercept":
            row[j] = 1.0
        elif info.is_interaction:
            row[j] = _resolve_interaction_value(
                name,
                X_names_list,
                X_means,
                focal_var=focal_var,
                focal_level=focal_level,
                set_categoricals=set_categoricals,
            )
        elif info.column_type == "categorical":
            if info.base_term == focal_var:
                row[j] = 1.0 if info.level == focal_level else 0.0
            elif set_categoricals and info.base_term in set_categoricals:
                row[j] = 1.0 if info.level == set_categoricals[info.base_term] else 0.0
            else:
                row[j] = X_means[j]
        else:
            row[j] = X_means[j]

    return row


def build_slope_reference_matrix(
    X_names: tuple[str, ...] | list[str],
    focal_var: str,
    X_means: np.ndarray,
    *,
    delta: float = 1.0,
) -> tuple[np.ndarray, np.ndarray]:
    """Build reference matrices for computing marginal slopes.

    Creates two reference rows: one at the mean and one at mean + delta
    for the focal continuous variable. The slope is then (y1 - y0) / delta.

    For interaction columns involving the focal variable (e.g.,
    ``x:z`` when ``focal_var="x"``), the interaction value is properly
    computed as a product of component values, so the perturbed row
    reflects the interaction contribution to the slope.

    Args:
        X_names: Column names from the design matrix.
        focal_var: Name of the continuous variable for slope computation.
        X_means: Column means of the original design matrix.
        delta: Step size for numerical differentiation (default 1.0).

    Returns:
        Tuple of (X_ref_0, X_ref_1) where:
        - X_ref_0: Reference point at mean of focal_var
        - X_ref_1: Reference point at mean + delta of focal_var

    Raises:
        ValueError: If focal_var is not found in X_names.
    """
    X_names_list = list(X_names)
    if focal_var not in X_names_list:
        raise ValueError(
            f"Focal variable '{focal_var}' not found in X_names. "
            f"Available continuous variables: "
            f"{[n for n in X_names if identify_column_type(n) == 'continuous']}"
        )

    focal_idx = X_names_list.index(focal_var)
    focal_mean = float(X_means[focal_idx])

    row_0 = _build_continuous_reference_row(
        X_names_list,
        X_means,
        focal_var,
        focal_mean,
    )
    row_1 = _build_continuous_reference_row(
        X_names_list,
        X_means,
        focal_var,
        focal_mean + delta,
    )

    return row_0.reshape(1, -1), row_1.reshape(1, -1)


def build_continuous_reference_matrix(
    X_names: tuple[str, ...] | list[str],
    focal_var: str,
    at_values: tuple[float, ...],
    X_means: np.ndarray,
    *,
    set_categoricals: dict[str, str] | None = None,
) -> np.ndarray:
    """Build reference matrix for a continuous focal variable at specific values.

    Creates one row per value in ``at_values``. Each row has covariates at
    their means except the focal variable, which is set to the specified value.

    For interaction columns involving the focal variable, the interaction
    value is properly computed as a product of component values at each
    ``at_value``.

    Args:
        X_names: Column names from the design matrix.
        focal_var: Name of the continuous focal variable.
        at_values: Specific values to evaluate the focal variable at.
        X_means: Column means of the original design matrix, shape (p,).
        set_categoricals: Optional dict mapping non-focal categorical variable
            names to specific levels for indicator encoding instead of
            marginalizing at column means.

    Returns:
        Reference design matrix X_ref, shape (n_values, p).

    Raises:
        ValueError: If focal_var is not found in X_names.
    """
    X_names_list = list(X_names)
    if focal_var not in X_names_list:
        raise ValueError(
            f"Focal variable '{focal_var}' not found in X_names. "
            f"Available continuous variables: "
            f"{[n for n in X_names if identify_column_type(n) == 'continuous']}"
        )

    n_values = len(at_values)
    p = len(X_names)
    X_ref = np.zeros((n_values, p), dtype=np.float64)

    for i, val in enumerate(at_values):
        X_ref[i] = _build_continuous_reference_row(
            X_names_list,
            X_means,
            focal_var,
            val,
            set_categoricals=set_categoricals,
        )

    return X_ref


def build_counterfactual_design_matrices(
    X: np.ndarray,
    X_names: tuple[str, ...] | list[str],
    focal_var: str,
    levels: list[str],
) -> list[np.ndarray]:
    """Build counterfactual design matrices for g-computation.

    For each focal level, creates a modified copy of the full design matrix
    ``X`` where the focal variable's indicator columns are set to match that
    level and interaction columns involving the focal variable are recomputed
    from component values.  Non-focal columns are left unchanged, preserving
    the observed covariate distribution.

    This is the core building block for ``weights="observed"``
    (g-computation / counterfactual prediction).  Each returned matrix answers:
    "What would the design matrix look like if every observation were assigned
    to this focal level?"

    Args:
        X: Original design matrix, shape ``(N, p)``.
        X_names: Column names from the design matrix, in order.
        focal_var: Name of the categorical focal variable.
        levels: List of levels to compute counterfactuals for.

    Returns:
        List of counterfactual design matrices (one per level), each shape
        ``(N, p)``.  Order matches ``levels``.

    Examples:
        For a model ``y ~ treatment + x + treatment:x`` with
        ``X_names = ("Intercept", "x", "treatment[B]", "x:treatment[B]")``::

            mats = build_counterfactual_design_matrices(X, X_names, "treatment", ["ref", "B"])
            # mats[0]: treatment set to ref for all rows (treatment[B]=0, x:treatment[B]=0)
            # mats[1]: treatment set to B for all rows (treatment[B]=1, x:treatment[B]=x_i)
    """
    X_names_list = list(X_names)
    N, p = X.shape

    # Pre-parse column metadata once
    col_infos = [parse_design_column_name(name) for name in X_names_list]

    # Identify focal dummy columns and their levels
    focal_col_indices: list[int] = []
    focal_col_levels: list[str | None] = []
    for j, info in enumerate(col_infos):
        if info.column_type == "categorical" and info.base_term == focal_var:
            focal_col_indices.append(j)
            focal_col_levels.append(info.level)

    # Identify interaction columns involving the focal variable
    interaction_cols: list[int] = []
    for j, info in enumerate(col_infos):
        if info.is_interaction:
            parts = X_names_list[j].split(":")
            if any(
                parse_design_column_name(part).base_term == focal_var for part in parts
            ):
                interaction_cols.append(j)

    result: list[np.ndarray] = []
    for level in levels:
        X_cf = X.copy()

        # Set focal dummy columns
        for j, lvl in zip(focal_col_indices, focal_col_levels):
            X_cf[:, j] = 1.0 if lvl == level else 0.0

        # Recompute interaction columns involving the focal variable
        for j in interaction_cols:
            parts = X_names_list[j].split(":")
            col_product = np.ones(N, dtype=np.float64)
            for part in parts:
                pinfo = parse_design_column_name(part)
                if pinfo.base_term == focal_var:
                    # Focal component: use counterfactual indicator
                    if pinfo.column_type == "categorical":
                        col_product *= 1.0 if pinfo.level == level else 0.0
                    elif part in X_names_list:
                        # Continuous focal in interaction (rare but possible)
                        col_product *= X[:, X_names_list.index(part)]
                elif part in X_names_list:
                    # Non-focal component: use original observed values
                    col_product *= X[:, X_names_list.index(part)]
            X_cf[:, j] = col_product

        result.append(X_cf)

    return result


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _resolve_interaction_value(
    col_name: str,
    X_names_list: list[str],
    X_means: np.ndarray,
    focal_var: str,
    *,
    focal_level: str | None = None,
    focal_value: float | None = None,
    set_categoricals: dict[str, str] | None = None,
) -> float:
    """Compute reference value for an interaction column.

    If the interaction involves the focal variable or a pinned categorical,
    computes the product of component values. Otherwise, returns the
    empirical column mean for marginalization.

    Args:
        col_name: Interaction column name (e.g., ``"Income:Student[Yes]"``).
        X_names_list: Design matrix column names as list.
        X_means: Column means of the design matrix.
        focal_var: Name of the focal variable.
        focal_level: Level for categorical focal (mutually exclusive with
            ``focal_value``).
        focal_value: Value for continuous focal (mutually exclusive with
            ``focal_level``).
        set_categoricals: Dict mapping non-focal categorical names to
            pinned levels. When an interaction part's base_term matches,
            the indicator value is used instead of the column mean.

    Returns:
        Computed reference value for the interaction column.
    """
    parts = col_name.split(":")

    # Check if any part involves the focal variable or a pinned categorical
    involves_focal = any(
        parse_design_column_name(p).base_term == focal_var for p in parts
    )
    involves_pinned = set_categoricals is not None and any(
        parse_design_column_name(p).base_term in set_categoricals for p in parts
    )

    if not involves_focal and not involves_pinned:
        # Non-focal, non-pinned interaction: use empirical column mean
        return float(X_means[X_names_list.index(col_name)])

    # Decompose and compute product of component values
    product = 1.0
    for part in parts:
        pinfo = parse_design_column_name(part)
        if pinfo.base_term == focal_var:
            # Focal component
            if focal_level is not None and pinfo.column_type == "categorical":
                product *= 1.0 if pinfo.level == focal_level else 0.0
            elif focal_value is not None:
                product *= focal_value
            elif part in X_names_list:
                product *= float(X_means[X_names_list.index(part)])
        elif (
            set_categoricals
            and pinfo.column_type == "categorical"
            and pinfo.base_term in set_categoricals
        ):
            # Pinned categorical component: use indicator
            product *= 1.0 if pinfo.level == set_categoricals[pinfo.base_term] else 0.0
        elif part in X_names_list:
            # Non-focal component: use its column mean
            product *= float(X_means[X_names_list.index(part)])
        else:
            # Can't decompose; fall back to empirical interaction mean
            return float(X_means[X_names_list.index(col_name)])

    return product


def _build_continuous_reference_row(
    X_names_list: list[str],
    X_means: np.ndarray,
    focal_var: str,
    focal_value: float,
    *,
    set_categoricals: dict[str, str] | None = None,
) -> np.ndarray:
    """Build one reference row for a continuous focal variable.

    Sets the focal variable to ``focal_value`` and all other covariates
    to their column means.  Interaction columns involving the focal
    variable are computed as products of component values.

    When ``set_categoricals`` is provided, non-focal categorical dummies
    are set to indicator values for the specified levels rather than using
    their column means.  This enables conditioning (e.g., evaluating EMMs
    at specific values of a continuous variable while pinning a categorical
    to a specific level).

    Args:
        X_names_list: Design matrix column names as list.
        X_means: Column means of the design matrix.
        focal_var: Name of the continuous focal variable.
        focal_value: Value to set for the focal variable.
        set_categoricals: Optional dict mapping non-focal categorical variable
            names to specific levels for indicator encoding.

    Returns:
        Reference row, shape (p,).
    """
    p = len(X_names_list)
    row = np.zeros(p, dtype=np.float64)

    for j, name in enumerate(X_names_list):
        info = parse_design_column_name(name)
        if info.column_type == "intercept":
            row[j] = 1.0
        elif info.is_interaction:
            row[j] = _resolve_interaction_value(
                name,
                X_names_list,
                X_means,
                focal_var=focal_var,
                focal_value=focal_value,
                set_categoricals=set_categoricals,
            )
        elif name == focal_var:
            row[j] = focal_value
        elif (
            set_categoricals
            and info.column_type == "categorical"
            and info.base_term in set_categoricals
        ):
            row[j] = 1.0 if info.level == set_categoricals[info.base_term] else 0.0
        else:
            row[j] = X_means[j]

    return row
