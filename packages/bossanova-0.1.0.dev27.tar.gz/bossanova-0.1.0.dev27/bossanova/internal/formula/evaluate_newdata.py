"""Newdata evaluation — apply learned encoding to new observations."""

from __future__ import annotations

import warnings
from typing import TYPE_CHECKING

import numpy as np
import polars as pl
from numpy.typing import NDArray

from bossanova.internal.formula.parser.expr import (
    Binary,
    Call,
    Grouping,
    Literal,
    QuotedName,
    Variable,
)
from bossanova.internal.maths.transforms import STATEFUL_TRANSFORMS
from bossanova.internal.formula.contrast_registry import (
    MODEL_CONTRAST_FUNCTIONS,
)
from bossanova.internal.formula.helpers import extract_name

if TYPE_CHECKING:
    from bossanova.internal.containers.structs.formula import FormulaSpec

__all__ = [
    "evaluate_newdata",
]


def evaluate_newdata(
    spec: FormulaSpec,
    data: pl.DataFrame,
    *,
    on_unseen_level: str = "error",
) -> NDArray[np.float64]:
    """Apply learned encoding from FormulaSpec to new data.

    Pure function: reads factor levels, contrast matrices, and transform
    state from spec. No mutation.

    Args:
        spec: FormulaSpec with learned encoding from build_design_matrices().
        data: New data as Polars DataFrame.
        on_unseen_level: How to handle unseen categorical levels.
            - "error": Raise ValueError (default)
            - "warn": Warn and encode as zeros
            - "ignore": Silently encode as zeros

    Returns:
        X matrix for new observations, shape (n_new, n_features).
        Column order matches the original build_design_matrices() output.

    Raises:
        ValueError: If required columns are missing from data.
        ValueError: If on_unseen_level="error" and unseen levels found.
    """
    n_obs = len(data)
    columns: list[NDArray[np.float64]] = []

    # Add intercept if model has one
    if spec.has_intercept:
        columns.append(np.ones(n_obs, dtype=np.float64))

    # Evaluate each term with new data
    for term in spec.rhs_terms:
        col_data = evaluate_term_new_data(
            term,
            data,
            spec,
            on_unseen_level,
        )
        if col_data.ndim == 1:
            columns.append(col_data)
        else:
            for i in range(col_data.shape[1]):
                columns.append(col_data[:, i])

    if columns:
        return np.column_stack(columns)
    else:
        return np.empty((n_obs, 0), dtype=np.float64)


def evaluate_term_new_data(
    term: object,
    data: pl.DataFrame,
    spec: FormulaSpec,
    on_unseen_level: str,
) -> NDArray[np.float64]:
    """Evaluate a term on new data using stored state from spec.

    Args:
        term: AST node representing the term.
        data: New data DataFrame.
        spec: FormulaSpec with learned encoding.
        on_unseen_level: How to handle unseen categorical levels.

    Returns:
        Evaluated data array.
    """
    if isinstance(term, Variable):
        return evaluate_variable_new_data(
            term.name.lexeme,
            data,
            spec,
            on_unseen_level,
        )

    if isinstance(term, QuotedName):
        return evaluate_variable_new_data(
            term.expression.lexeme,
            data,
            spec,
            on_unseen_level,
        )

    if isinstance(term, Call):
        return evaluate_call_new_data(term, data, spec, on_unseen_level)

    if isinstance(term, Grouping):
        return evaluate_term_new_data(term.expression, data, spec, on_unseen_level)

    if isinstance(term, Binary):
        if term.operator.kind == "COLON":
            return evaluate_interaction_new_data(term, data, spec, on_unseen_level)
        if term.operator.kind == "STAR":
            return evaluate_star_new_data(term, data, spec, on_unseen_level)
        if term.operator.kind in ("STAR_STAR", "CARET"):
            return evaluate_power_new_data(term, data, spec, on_unseen_level)
        raise ValueError(f"Unsupported binary operator: {term.operator.kind}")

    if isinstance(term, Literal):
        n_obs = len(data)
        val = float(term.value) if isinstance(term.value, (int, float)) else 0.0
        return np.full(n_obs, val, dtype=np.float64)

    raise ValueError(f"Unsupported term type: {type(term)}")


def evaluate_variable_new_data(
    name: str,
    data: pl.DataFrame,
    spec: FormulaSpec,
    on_unseen_level: str,
) -> NDArray[np.float64]:
    """Evaluate a variable on new data.

    Args:
        name: Column name.
        data: New data DataFrame.
        spec: FormulaSpec with learned encoding.
        on_unseen_level: How to handle unseen categorical levels.

    Returns:
        Evaluated data array.
    """
    if name not in data.columns:
        raise ValueError(f"Variable '{name}' not found in new data")

    series = data[name]

    # Check if this was treated as categorical during build
    if name in spec.factors:
        return evaluate_categorical_new_data(name, series, spec, on_unseen_level)

    return series.to_numpy().astype(np.float64)


def evaluate_categorical_new_data(
    name: str,
    series: pl.Series,
    spec: FormulaSpec,
    on_unseen_level: str,
) -> NDArray[np.float64]:
    """Evaluate categorical on new data using stored levels and contrast.

    Args:
        name: Variable name.
        series: New data series.
        spec: FormulaSpec with learned encoding.
        on_unseen_level: How to handle unseen levels.

    Returns:
        Encoded array using stored contrast matrix.
    """
    stored_levels = list(spec.factors[name])
    contrast = spec.contrast_matrices[name]

    # Check for unseen levels
    new_values = [str(v) for v in series.unique().to_list()]
    unseen = set(new_values) - set(stored_levels)

    if unseen:
        msg = f"Unseen levels {unseen} for variable '{name}'"
        if on_unseen_level == "error":
            raise ValueError(msg)
        elif on_unseen_level == "warn":
            warnings.warn(msg, UserWarning, stacklevel=4)

    # Encode using stored levels
    n_obs = len(series)
    n_cols = contrast.shape[1]

    values = [str(v) for v in series.to_list()]
    result = np.zeros((n_obs, n_cols), dtype=np.float64)

    for i, val in enumerate(values):
        if val in stored_levels:
            level_idx = stored_levels.index(val)
            result[i, :] = contrast[level_idx, :]

    return result


def evaluate_call_new_data(
    call: Call,
    data: pl.DataFrame,
    spec: FormulaSpec,
    on_unseen_level: str,
) -> NDArray[np.float64]:
    """Evaluate a function call on new data.

    Args:
        call: Call AST node.
        data: New data DataFrame.
        spec: FormulaSpec with learned encoding.
        on_unseen_level: How to handle unseen categorical levels.

    Returns:
        Evaluated data array.
    """
    if not isinstance(call.callee, Variable):
        raise ValueError(f"Unsupported callee type: {type(call.callee)}")

    func_name = call.callee.name.lexeme

    # Contrast encoding functions: treatment, sum, helmert, sequential, poly, etc.
    if func_name in MODEL_CONTRAST_FUNCTIONS:
        var_name = extract_name(call.args[0])
        if var_name is None:
            raise ValueError(f"Could not extract variable name from {call.args[0]}")
        return evaluate_variable_new_data(var_name, data, spec, on_unseen_level)

    # Identity function — evaluate contents as arithmetic
    if func_name == "transform":
        return evaluate_term_new_data(call.args[0], data, spec, on_unseen_level)

    # Stateful transforms - use stored transform
    if func_name in STATEFUL_TRANSFORMS:
        var_name = extract_name(call.args[0])
        if var_name is None:
            raise ValueError(f"Could not extract variable name from {call.args[0]}")
        transform_key = f"{func_name}({var_name})"

        if transform_key not in spec.transforms:
            raise RuntimeError(
                f"Transform '{transform_key}' not found. Was build_design_matrices() called?"
            )

        if var_name not in data.columns:
            raise ValueError(f"Variable '{var_name}' not found in new data")

        raw_data = data[var_name].to_numpy().astype(np.float64)
        transform = spec.transforms[transform_key]
        return transform.transform(raw_data).reshape(-1, 1)

    # Math transforms - stateless, just apply
    if func_name in ("log", "log10", "sqrt"):
        var_name = extract_name(call.args[0])
        if var_name not in data.columns:
            raise ValueError(f"Variable '{var_name}' not found in new data")

        raw_data = data[var_name].to_numpy().astype(np.float64)

        if func_name == "log":
            return np.log(raw_data).reshape(-1, 1)
        elif func_name == "log10":
            return np.log10(raw_data).reshape(-1, 1)
        elif func_name == "sqrt":
            return np.sqrt(raw_data).reshape(-1, 1)

    raise ValueError(f"Unknown function: {func_name}")


def evaluate_interaction_new_data(
    term: Binary,
    data: pl.DataFrame,
    spec: FormulaSpec,
    on_unseen_level: str,
) -> NDArray[np.float64]:
    """Evaluate interaction term on new data.

    Args:
        term: Binary AST node with COLON operator.
        data: New data DataFrame.
        spec: FormulaSpec with learned encoding.
        on_unseen_level: How to handle unseen categorical levels.

    Returns:
        Interaction data array.
    """
    left_data = evaluate_term_new_data(term.left, data, spec, on_unseen_level)
    right_data = evaluate_term_new_data(term.right, data, spec, on_unseen_level)

    if left_data.ndim == 1:
        left_data = left_data.reshape(-1, 1)
    if right_data.ndim == 1:
        right_data = right_data.reshape(-1, 1)

    n_left = left_data.shape[1]
    n_right = right_data.shape[1]
    n_obs = left_data.shape[0]

    result_cols = []
    for i in range(n_left):
        for j in range(n_right):
            result_cols.append(left_data[:, i] * right_data[:, j])

    if result_cols:
        return np.column_stack(result_cols)
    else:
        return np.empty((n_obs, 0), dtype=np.float64)


def evaluate_star_new_data(
    term: Binary,
    data: pl.DataFrame,
    spec: FormulaSpec,
    on_unseen_level: str,
) -> NDArray[np.float64]:
    """Evaluate star term (a * b = a + b + a:b) on new data.

    Args:
        term: Binary AST node with STAR operator.
        data: New data DataFrame.
        spec: FormulaSpec with learned encoding.
        on_unseen_level: How to handle unseen categorical levels.

    Returns:
        Combined data array.
    """
    left_data = evaluate_term_new_data(term.left, data, spec, on_unseen_level)
    right_data = evaluate_term_new_data(term.right, data, spec, on_unseen_level)
    int_data = evaluate_interaction_new_data(term, data, spec, on_unseen_level)

    all_cols = []

    for arr in (left_data, right_data, int_data):
        if arr.ndim == 1:
            all_cols.append(arr)
        else:
            for i in range(arr.shape[1]):
                all_cols.append(arr[:, i])

    if all_cols:
        return np.column_stack(all_cols)
    else:
        return np.empty((len(data), 0), dtype=np.float64)


def evaluate_power_new_data(
    term: Binary,
    data: pl.DataFrame,
    spec: FormulaSpec,
    on_unseen_level: str,
) -> NDArray[np.float64]:
    """Evaluate power term (x ** n) on new data.

    Args:
        term: Binary AST node with STAR_STAR operator.
        data: New data DataFrame.
        spec: FormulaSpec with learned encoding.
        on_unseen_level: How to handle unseen categorical levels.

    Returns:
        Data array with x raised to the power n.
    """
    left_data = evaluate_term_new_data(term.left, data, spec, on_unseen_level)
    right_data = evaluate_term_new_data(term.right, data, spec, on_unseen_level)

    if right_data.ndim > 0 and len(np.unique(right_data)) == 1:
        exponent = right_data.flat[0]
    else:
        exponent = right_data

    if left_data.ndim > 1:
        left_data = left_data.flatten()

    result = np.power(left_data, exponent)
    return result.reshape(-1, 1)
