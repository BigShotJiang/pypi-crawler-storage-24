"""Contrast function registry for explore formulas.

Centralizes the vocabulary of contrast function names, aliases,
and parameter requirements. Used by the explore parser and contrast
dispatch logic to ensure consistent naming.
"""

from __future__ import annotations

__all__ = [
    "CONTRAST_ALIASES",
    "DEGREE_FUNCTIONS",
    "MODEL_CONTRAST_FUNCTIONS",
    "OMIT_FUNCTIONS",
    "ORDER_DEPENDENT",
    "REF_FUNCTIONS",
    "VALID_CONTRAST_FUNCTIONS",
    "resolve_contrast_name",
]

# Canonical names and their aliases.
# Keys = alias, Values = canonical name.
CONTRAST_ALIASES: dict[str, str] = {
    "pairwise": "pairwise",
    "sequential": "sequential",
    "poly": "poly",
    "treatment": "treatment",
    "dummy": "treatment",
    "sum": "sum",
    "deviation": "sum",
    "helmert": "helmert",
}

# All valid contrast function names (canonical + aliases)
VALID_CONTRAST_FUNCTIONS: frozenset[str] = frozenset(CONTRAST_ALIASES.keys())

# Functions that accept a ``degree`` parameter
DEGREE_FUNCTIONS: frozenset[str] = frozenset({"poly"})

# Functions that accept a ``ref`` keyword parameter
REF_FUNCTIONS: frozenset[str] = frozenset({"treatment", "dummy"})

# Functions that accept an ``omit`` keyword parameter
OMIT_FUNCTIONS: frozenset[str] = frozenset({"sum", "deviation"})

# Order-dependent functions (level ordering matters)
ORDER_DEPENDENT: frozenset[str] = frozenset({"sequential", "poly", "helmert"})

# Contrast functions valid in model formulas (excludes pairwise — explore only)
MODEL_CONTRAST_FUNCTIONS: frozenset[str] = frozenset(
    {k for k, v in CONTRAST_ALIASES.items() if v != "pairwise"}
)


def resolve_contrast_name(name: str) -> str:
    """Resolve a contrast function name to its canonical form.

    Args:
        name: Contrast function name (may be an alias).

    Returns:
        Canonical contrast name.

    Raises:
        ValueError: If name is not a recognized contrast function.
    """
    canonical = CONTRAST_ALIASES.get(name)
    if canonical is None:
        valid = ", ".join(sorted(VALID_CONTRAST_FUNCTIONS))
        raise ValueError(f"Unknown contrast function '{name}'. Valid options: {valid}")
    return canonical
