"""Transform evaluation — stateful, math, and polynomial transforms.

Extracted from evaluate.py to keep file sizes manageable and provide
a clean home for nested transform evaluation logic.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import polars as pl
from numpy.typing import NDArray

from bossanova.internal.maths.transforms import (
    build_transform,
)
from bossanova.internal.formula.helpers import (
    extract_name,
    variable_not_found_error,
)
from bossanova.internal.formula.parser.expr import (
    Call,
)

if TYPE_CHECKING:
    from bossanova.internal.formula.evaluate import TermResult

__all__ = [
    "evaluate_math_transform",
    "evaluate_stateful_transform",
    "resolve_transform_arg",
]


def resolve_transform_arg(
    arg: object,
    data: pl.DataFrame,
    factors: dict[str, list[str]],
    contrast_matrices: dict[str, NDArray],
    transform_state: dict[str, dict],
    transforms: dict[str, object],
    custom_contrasts: dict[str, NDArray],
) -> tuple[NDArray[np.float64], str, dict]:
    """Resolve a transform argument to raw data, handling nested calls.

    If the argument is a simple variable, fetches it from the DataFrame.
    If the argument is a nested Call (e.g. rank(x) inside zscore(rank(x))),
    recursively evaluates the inner call first.

    Args:
        arg: AST node — Variable, QuotedName, or Call.
        data: Polars DataFrame.
        factors: Current factor levels mapping.
        contrast_matrices: Current contrast matrices.
        transform_state: Current transform state mapping.
        transforms: Current fitted transform instances.
        custom_contrasts: User-provided contrast matrices.

    Returns:
        (raw_data, label, inner_state_updates) where raw_data is a 1-D float64
        array, label is the display name (e.g. "x" or "rank(x)"), and
        inner_state_updates is any state produced by inner transforms.
    """
    # Simple variable — the common case
    var_name = extract_name(arg)
    if var_name is not None:
        if var_name not in data.columns:
            raise variable_not_found_error(var_name, data.columns)
        raw_data = data[var_name].to_numpy().astype(np.float64)
        return raw_data, var_name, {}

    # Nested call — e.g. rank(x) inside zscore(rank(x))
    if isinstance(arg, Call):
        # Import here to avoid circular import (evaluate imports us)
        from bossanova.internal.formula.evaluate import evaluate_call

        inner_result, _ = evaluate_call(
            arg,
            data,
            factors,
            contrast_matrices,
            transform_state,
            transforms,
            custom_contrasts,
            intercept_absorbed=True,  # irrelevant for transforms
        )
        # Inner result should be a single column
        cols = inner_result.columns
        if cols.ndim == 2:
            if cols.shape[1] != 1:
                raise ValueError(
                    "Nested transform produced multiple columns; "
                    "only single-column transforms can be nested"
                )
            raw_data = cols[:, 0]
        else:
            raw_data = cols
        label = inner_result.labels[0] if inner_result.labels else "?"
        return raw_data, label, inner_result.state_updates

    raise ValueError(
        f"Transform argument must be a variable or a nested transform call, "
        f"got {type(arg).__name__}"
    )


def evaluate_stateful_transform(
    func_name: str,
    arg: object,
    data: pl.DataFrame,
    factors: dict[str, list[str]],
    contrast_matrices: dict[str, NDArray],
    transform_state: dict[str, dict],
    transforms: dict[str, object],
    custom_contrasts: dict[str, NDArray],
) -> TermResult:
    """Evaluate a stateful transform like center(), scale(), rank().

    Supports nested calls: zscore(rank(x)) evaluates rank(x) first,
    then applies zscore to the result.

    Args:
        func_name: Transform name.
        arg: AST node for the argument (Variable or nested Call).
        data: Polars DataFrame.
        factors: Current factor levels mapping.
        contrast_matrices: Current contrast matrices.
        transform_state: Current transform state mapping.
        transforms: Current fitted transform instances.
        custom_contrasts: User-provided contrast matrices.

    Returns:
        TermResult with transformed data and state updates.
    """
    from bossanova.internal.formula.evaluate import TermResult

    raw_data, inner_label, inner_state = resolve_transform_arg(
        arg,
        data,
        factors,
        contrast_matrices,
        transform_state,
        transforms,
        custom_contrasts,
    )

    transform_key = f"{func_name}({inner_label})"
    transform = build_transform(func_name)
    transformed = transform.fit_transform(raw_data)

    state_updates: dict = {
        "transform_state": {
            transform_key: {
                "type": func_name,
                "variable": inner_label,
                "params": transform.state.params,
            }
        },
        "transforms": {transform_key: transform},
    }

    # Merge inner state (e.g. rank state inside zscore(rank(x)))
    for key, val in inner_state.items():
        if key in state_updates and isinstance(val, dict):
            state_updates[key].update(val)
        elif key not in state_updates:
            state_updates[key] = val

    return TermResult(
        columns=transformed.reshape(-1, 1),
        labels=[transform_key],
        state_updates=state_updates,
    )


def evaluate_math_transform(
    func_name: str,
    arg: object,
    data: pl.DataFrame,
    factors: dict[str, list[str]],
    contrast_matrices: dict[str, NDArray],
    transform_state: dict[str, dict],
    transforms: dict[str, object],
    custom_contrasts: dict[str, NDArray],
) -> TermResult:
    """Evaluate a math transform like log(), sqrt().

    Supports nested calls: log(rank(x)) evaluates rank(x) first,
    then applies log to the result.

    Args:
        func_name: Transform name.
        arg: AST node for the argument (Variable or nested Call).
        data: Polars DataFrame.
        factors: Current factor levels mapping.
        contrast_matrices: Current contrast matrices.
        transform_state: Current transform state mapping.
        transforms: Current fitted transform instances.
        custom_contrasts: User-provided contrast matrices.

    Returns:
        TermResult with transformed data.
    """
    from bossanova.internal.formula.evaluate import TermResult

    raw_data, inner_label, inner_state = resolve_transform_arg(
        arg,
        data,
        factors,
        contrast_matrices,
        transform_state,
        transforms,
        custom_contrasts,
    )

    if func_name == "log":
        transformed = np.log(raw_data)
    elif func_name == "log10":
        transformed = np.log10(raw_data)
    elif func_name == "sqrt":
        transformed = np.sqrt(raw_data)
    else:
        raise ValueError(f"Unknown math transform: {func_name}")

    transform_key = f"{func_name}({inner_label})"
    state_updates: dict = {
        "transform_state": {
            transform_key: {
                "type": func_name,
                "variable": inner_label,
                "params": {},
            }
        },
    }

    # Merge inner state
    for key, val in inner_state.items():
        if key in state_updates and isinstance(val, dict):
            state_updates[key].update(val)
        elif key not in state_updates:
            state_updates[key] = val

    return TermResult(
        columns=transformed.reshape(-1, 1),
        labels=[transform_key],
        state_updates=state_updates,
    )
