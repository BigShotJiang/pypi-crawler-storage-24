"""Random effects Z matrix construction from FormulaSpec."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import polars as pl
import scipy.sparse as sp
from numpy.typing import NDArray

from bossanova.internal.formula.parser.expr import (
    Binary,
    Call,
    Grouping,
    Literal,
    QuotedName,
    Unary,
    Variable,
)
from bossanova.internal.design.z_matrix import (
    RandomEffectsInfo,
    build_random_effects,
    build_z_simple,
)
from bossanova.internal.formula.helpers import (
    extract_name,
    variable_not_found_error,
)
from bossanova.internal.design.coding import treatment_coding
from bossanova.internal.formula.evaluate import evaluate_call

if TYPE_CHECKING:
    from bossanova.internal.containers.structs.formula import FormulaSpec

__all__ = [
    "build_random_effects_from_spec",
]


# =============================================================================
# Main entry point
# =============================================================================


def build_random_effects_from_spec(
    spec: FormulaSpec,
    data: pl.DataFrame,
) -> RandomEffectsInfo | None:
    """Build random effects design matrix from FormulaSpec.

    Args:
        spec: Parsed formula specification with re_terms.
        data: Training data (Polars DataFrame).

    Returns:
        RandomEffectsInfo with Z matrix and metadata, or None if no RE terms.
    """
    if not spec.re_terms:
        return None

    # Local mutable cache for transform data evaluated during RE parsing
    re_transform_data: dict[str, NDArray[np.float64]] = {}

    # Parse all RE terms and group by grouping factor
    re_term_infos = [
        parse_re_term(t, data, spec, re_transform_data) for t in spec.re_terms
    ]
    factors_seen: dict[str, list[dict]] = {}
    for info in re_term_infos:
        factors_seen.setdefault(info["group_name"], []).append(info)

    # Determine overall structure
    if len(factors_seen) == 1:
        # Single grouping factor — simple or diagonal
        factor_name = next(iter(factors_seen))
        terms_for_factor = factors_seen[factor_name]
        return build_re_simple(factor_name, terms_for_factor, data)
    else:
        # Multiple grouping factors — crossed effects
        return build_re_crossed(factors_seen, data)


def _evaluate_re_call(
    node: Call,
    data: pl.DataFrame,
    spec: "FormulaSpec",
) -> object:
    """Evaluate a Call node using FormulaSpec state, returning its TermResult.

    Args:
        node: Call AST node (e.g., center(x), factor(g)).
        data: Polars DataFrame.
        spec: FormulaSpec with factors, contrasts, transforms.

    Returns:
        TermResult with .columns (array) and .labels (list of str).
    """
    result, _ = evaluate_call(
        node,
        data,
        dict(spec.factors),
        dict(spec.contrast_matrices),
        dict(spec.transform_state),
        dict(spec.transforms),
        dict(spec.custom_contrasts),
        True,
    )
    return result


# =============================================================================
# Categorical RE helpers
# =============================================================================


def _is_categorical_column(
    col: pl.Series,
    var_name: str,
    spec: "FormulaSpec",
) -> bool:
    """Check if a column should be treated as categorical in random effects.

    Args:
        col: Polars Series for the variable.
        var_name: Name of the variable.
        spec: FormulaSpec with factor declarations.

    Returns:
        True if the column should receive contrast encoding.
    """
    if isinstance(col.dtype, (pl.Enum, pl.Categorical)):
        return True
    if col.dtype == pl.Utf8:
        return True
    return var_name in spec.factors


def _encode_categorical_re_slope(
    var_name: str,
    col: pl.Series,
    spec: "FormulaSpec",
) -> tuple[list[NDArray[np.float64]], list[str]]:
    """Encode a categorical column as RE slopes using reduced-rank contrast coding.

    Args:
        var_name: Column name.
        col: Polars Series with categorical data.
        spec: FormulaSpec with factor and contrast info.

    Returns:
        Tuple of (list of 1-D arrays, list of label strings).
    """
    # Determine levels
    if var_name in spec.factors:
        levels = list(spec.factors[var_name])
    else:
        levels = sorted(col.unique().to_list())

    # Determine contrast matrix (reduced-rank for RE slopes)
    if var_name in spec.custom_contrasts:
        contrast = spec.custom_contrasts[var_name]
        n_cols = contrast.shape[1]
        labels = [f"{var_name}[c{i + 1}]" for i in range(n_cols)]
    elif var_name in spec.contrast_matrices:
        contrast = spec.contrast_matrices[var_name]
        # If it's full-rank (identity), reduce to treatment coding
        if contrast.shape[0] == contrast.shape[1]:
            contrast = treatment_coding(levels)
        n_cols = contrast.shape[1]
        labels = [f"{var_name}[{lvl}]" for lvl in levels if lvl != levels[0]]
        # If custom contrast types changed label count, use generic labels
        if len(labels) != n_cols:
            labels = [f"{var_name}[c{i + 1}]" for i in range(n_cols)]
    else:
        contrast = treatment_coding(levels)
        labels = [f"{var_name}[{lvl}]" for lvl in levels[1:]]

    # Ensure column is Enum for encode_categorical
    if not isinstance(col.dtype, (pl.Enum, pl.Categorical)):
        col = col.cast(pl.Utf8).cast(pl.Enum(levels))

    # Encode: shape (n_obs, n_cols)
    from bossanova.internal.formula.encoding import encode_categorical

    encoded = encode_categorical(col, contrast)

    cols_out = [encoded[:, i] for i in range(encoded.shape[1])]
    return cols_out, labels


def _resolve_re_interaction_side(
    node: object,
    data: pl.DataFrame,
    spec: "FormulaSpec",
    re_transform_data: dict[str, NDArray[np.float64]],
) -> tuple[list[NDArray[np.float64]], list[str]]:
    """Resolve one side of a COLON interaction to arrays and names.

    Args:
        node: AST node (left or right side of ``:``).
        data: Polars DataFrame.
        spec: FormulaSpec for factors and contrasts.
        re_transform_data: Cache of already-evaluated transforms.

    Returns:
        Tuple of (list of 1-D arrays, list of labels).
    """
    if isinstance(node, (Variable, QuotedName)):
        name = (
            node.name.lexeme if isinstance(node, Variable) else node.expression.lexeme
        )
        if name in re_transform_data:
            return [re_transform_data[name]], [name]
        if name not in data.columns:
            raise ValueError(
                f"Interaction variable '{name}' not found in data columns."
            )
        col = data[name]
        if _is_categorical_column(col, name, spec):
            return _encode_categorical_re_slope(name, col, spec)
        return [col.to_numpy().astype(np.float64)], [name]

    if isinstance(node, Call):
        result = _evaluate_re_call(node, data, spec)
        data_array = result.columns
        n_cols = data_array.shape[1] if data_array.ndim > 1 else 1
        if n_cols == 1:
            arr = data_array.flatten()
            label = result.labels[0]
            re_transform_data[label] = arr
            return [arr], [label]
        # Multi-column (e.g., factor())
        cols_out = []
        for i in range(n_cols):
            re_transform_data[result.labels[i]] = data_array[:, i]
            cols_out.append(data_array[:, i])
        return cols_out, list(result.labels[:n_cols])

    raise ValueError(f"Unsupported node type in RE interaction: {type(node).__name__}")


def _compute_re_interaction(
    left_node: object,
    right_node: object,
    data: pl.DataFrame,
    spec: "FormulaSpec",
    re_transform_data: dict[str, NDArray[np.float64]],
    vars_found: list[str],
) -> None:
    """Resolve both sides, compute pairwise products, and register in caches.

    Args:
        left_node: AST node for the left operand.
        right_node: AST node for the right operand.
        data: Polars DataFrame.
        spec: FormulaSpec for factors and contrasts.
        re_transform_data: Mutable cache of evaluated transform data.
        vars_found: Mutable list accumulating slope variable names.
    """
    left_cols, left_names = _resolve_re_interaction_side(
        left_node, data, spec, re_transform_data
    )
    right_cols, right_names = _resolve_re_interaction_side(
        right_node, data, spec, re_transform_data
    )
    for li, lname in enumerate(left_names):
        for ri, rname in enumerate(right_names):
            name = f"{lname}:{rname}"
            re_transform_data[name] = left_cols[li] * right_cols[ri]
            vars_found.append(name)


# =============================================================================
# RE term parsing
# =============================================================================


def parse_re_term(
    term: Binary,
    data: pl.DataFrame,
    spec: FormulaSpec,
    re_transform_data: dict[str, NDArray[np.float64]],
) -> dict:
    """Parse a single random effect term into components.

    Args:
        term: Binary AST node with PIPE operator.
        data: Polars DataFrame with training data.
        spec: FormulaSpec for accessing factors, contrasts, transforms.
        re_transform_data: Mutable cache for transformed variable data.

    Returns:
        Dict with keys: group_name, re_vars, has_intercept, X_re,
        random_names, is_nested.
    """
    # Extract grouping factor name
    group_name = extract_name(term.right)
    if group_name is None:
        raise ValueError(f"Could not extract grouping factor from: {term}")

    # Handle interaction grouping factors (e.g., "school:class" from nested expansion)
    if ":" in group_name:
        component_factors = group_name.split(":")
        for comp in component_factors:
            if comp not in data.columns:
                raise variable_not_found_error(comp, data.columns)
    elif group_name not in data.columns:
        raise variable_not_found_error(group_name, data.columns)

    # Parse the RE expression (left side of |)
    re_vars, has_intercept = parse_re_expr(term.left, data, spec, re_transform_data)

    # Build X_re matrix
    n_obs = len(data)
    X_re_cols: list[NDArray[np.float64]] = []
    random_names: list[str] = []

    if has_intercept:
        X_re_cols.append(np.ones(n_obs, dtype=np.float64))
        random_names.append("Intercept")

    for var in re_vars:
        # Check if this is a transformed variable (e.g., "center(x)")
        if var in re_transform_data:
            X_re_cols.append(re_transform_data[var])
        elif var in data.columns:
            col = data[var]
            if _is_categorical_column(col, var, spec):
                # Categorical slope: expand to multiple dummy columns
                encoded_cols, encoded_names = _encode_categorical_re_slope(
                    var, col, spec
                )
                X_re_cols.extend(encoded_cols)
                random_names.extend(encoded_names)
                continue  # skip the append(var) below
            else:
                X_re_cols.append(col.to_numpy().astype(np.float64))
        else:
            raise ValueError(
                f"Random slope variable '{var}' not found in data. "
                f"For formula with ({var}|{group_name}), '{var}' must be in data."
            )
        random_names.append(var)

    if not X_re_cols:
        raise ValueError("Random effect term has no intercept and no slopes")

    X_re = np.column_stack(X_re_cols)

    return {
        "group_name": group_name,
        "re_vars": re_vars,
        "has_intercept": has_intercept,
        "X_re": X_re,
        "random_names": random_names,
        "is_nested": False,
    }


def parse_re_expr(
    expr: object,
    data: pl.DataFrame,
    spec: FormulaSpec,
    re_transform_data: dict[str, NDArray[np.float64]],
) -> tuple[list[str], bool]:
    """Parse the left side of a random effect term.

    Handles expressions like:
        - 1           -> ([], True)  - intercept only
        - x           -> (['x'], True)  - intercept + slope (implicit)
        - 1 + x       -> (['x'], True)  - intercept + slope
        - 0 + x       -> (['x'], False) - slope only
        - 1 + x + z   -> (['x', 'z'], True) - intercept + multiple slopes
        - center(x)   -> (['center(x)'], True) - transform in RE
        - x:z         -> (['x:z'], True)  - interaction slope
        - x*z         -> (['x', 'z', 'x:z'], True) - full factorial
        - a/b         -> (['a', 'a:b'], True) - nesting (a + a:b)
        - x**2, x^2   -> (['x**2'], True) - polynomial slope
        - factor(x)   -> (['x[B]', 'x[C]'], True) - categorical slopes

    Args:
        expr: AST node for the RE expression.
        data: Polars DataFrame.
        spec: FormulaSpec for accessing state needed by evaluate_call.
        re_transform_data: Mutable cache for transformed variable data.

    Returns:
        Tuple of (list of slope variable names, has_intercept bool).
    """
    vars_found: list[str] = []
    has_intercept = True  # Default: include intercept

    def traverse(node: object) -> None:
        nonlocal has_intercept

        if isinstance(node, Literal):
            if node.value in (0, "0"):
                has_intercept = False
            # value of 1 means intercept (already default True)

        elif isinstance(node, Variable):
            vars_found.append(node.name.lexeme)

        elif isinstance(node, QuotedName):
            vars_found.append(node.expression.lexeme)

        elif isinstance(node, Binary):
            if node.operator.kind == "PLUS":
                traverse(node.left)
                traverse(node.right)
            elif node.operator.kind == "MINUS":
                traverse(node.left)
                # Check if subtracting 1 (removes intercept)
                if isinstance(node.right, Literal) and node.right.value in (1, "1"):
                    has_intercept = False
            elif node.operator.kind == "COLON":
                # Interaction: x:z → element-wise product of columns
                _compute_re_interaction(
                    node.left,
                    node.right,
                    data,
                    spec,
                    re_transform_data,
                    vars_found,
                )
            elif node.operator.kind == "STAR":
                # Full factorial: x*z → x + z + x:z
                traverse(node.left)
                traverse(node.right)
                _compute_re_interaction(
                    node.left,
                    node.right,
                    data,
                    spec,
                    re_transform_data,
                    vars_found,
                )
            elif node.operator.kind == "SLASH":
                # Nesting: a/b → a + a:b (left main effect + interaction)
                traverse(node.left)
                _compute_re_interaction(
                    node.left,
                    node.right,
                    data,
                    spec,
                    re_transform_data,
                    vars_found,
                )
            elif node.operator.kind in ("STAR_STAR", "CARET"):
                # Power/polynomial: x**2 or x^2 → numeric exponentiation
                left_cols, left_names = _resolve_re_interaction_side(
                    node.left, data, spec, re_transform_data
                )
                if not isinstance(node.right, Literal) or not isinstance(
                    node.right.value, (int, float)
                ):
                    raise ValueError(
                        "Power operator in random effects requires a "
                        "numeric exponent (e.g., 'x^2', 'x**3')."
                    )
                exponent = node.right.value
                exp_label = (
                    int(exponent)
                    if isinstance(exponent, float) and exponent.is_integer()
                    else exponent
                )
                for col_arr, col_name in zip(left_cols, left_names):
                    name = f"{col_name}**{exp_label}"
                    re_transform_data[name] = np.power(col_arr, exponent)
                    vars_found.append(name)
            else:
                raise ValueError(
                    f"Operator '{node.operator.lexeme}' is not supported "
                    f"in random effects formulas.\n\n"
                    f"Supported operators: +, -, :, *, /, **, ^\n"
                    f"Examples: (1+x|g), (x:z|g), (x*z|g), (a/b|g), (x^2|g)"
                )

        elif isinstance(node, Grouping):
            traverse(node.expression)

        elif isinstance(node, Unary):
            if node.operator.kind == "MINUS":
                name = extract_name(node.right)
                if name in ("0", "1"):
                    has_intercept = False
            elif node.operator.kind == "PLUS":
                traverse(node.right)

        elif isinstance(node, Call):
            # Transform in RE term, e.g., center(x) or factor(g)
            result = _evaluate_re_call(node, data, spec)
            arr = result.columns
            n_cols = arr.shape[1] if arr.ndim > 1 else 1
            if n_cols > 1:
                for i in range(n_cols):
                    re_transform_data[result.labels[i]] = arr[:, i]
                    vars_found.append(result.labels[i])
            else:
                re_transform_data[result.labels[0]] = arr.flatten()
                vars_found.append(result.labels[0])

    traverse(expr)
    return vars_found, has_intercept


# =============================================================================
# Group info extraction
# =============================================================================


def extract_group_info(
    group_series: pl.Series, n_obs: int
) -> tuple[list, NDArray[np.intp]]:
    """Extract group levels and integer IDs from a grouping factor series.

    Handles Enum, Categorical, and plain string columns consistently.

    Args:
        group_series: Polars Series containing group labels.
        n_obs: Total number of observations in the dataset.

    Returns:
        Tuple of (levels, group_ids) where:
            - levels: List of unique group level names in sorted order
            - group_ids: Integer array mapping each observation to its group index
    """
    if isinstance(group_series.dtype, pl.Enum):
        levels = list(group_series.dtype.categories)
    else:
        levels = sorted(group_series.unique().to_list())

    n_groups = len(levels)

    if n_groups < 2:
        raise ValueError(
            f"Grouping variable '{group_series.name}' has only {n_groups} level. "
            f"Random effects require at least 2 levels to estimate variance components."
        )

    if n_groups >= n_obs:
        raise ValueError(
            f"Grouping variable '{group_series.name}' has {n_groups} levels for "
            f"{n_obs} observations — overparameterized. "
            f"Use the grouping variable as a fixed effect instead."
        )

    group_values = group_series.to_list()
    level_to_idx = {lvl: i for i, lvl in enumerate(levels)}
    group_ids = np.array([level_to_idx[v] for v in group_values], dtype=np.intp)

    return levels, group_ids


# =============================================================================
# Structure-specific builders
# =============================================================================


def build_re_simple(
    factor_name: str,
    terms: list[dict],
    data: pl.DataFrame,
) -> RandomEffectsInfo:
    """Build random effects for single grouping factor.

    Args:
        factor_name: Name of the grouping factor.
        terms: List of parsed RE term dicts for this factor.
        data: Polars DataFrame with training data.

    Returns:
        RandomEffectsInfo with Z matrix and metadata.
    """
    group_series = data[factor_name]
    levels, group_ids = extract_group_info(group_series, n_obs=len(data))
    n_groups = len(levels)

    if len(terms) == 1:
        # Single term: use directly
        info = terms[0]
        X_re = info["X_re"]
        random_names = info["random_names"]

        # Determine structure: "intercept" for intercept-only, "slope" otherwise
        if random_names == ["Intercept"]:
            re_structure = "intercept"
        else:
            re_structure = "slope"

        return build_random_effects(
            group_ids_list=[group_ids],
            n_groups_list=[n_groups],
            group_names=[factor_name],
            random_names=random_names,
            re_structure=re_structure,
            X_re=X_re,
            group_levels_list=[levels],
        )

    # Multiple terms for same factor: likely || expansion (uncorrelated)
    random_names = []
    for t in terms:
        random_names.extend(t["random_names"])
    re_structure = "diagonal"

    # Build Z for each term separately and hstack
    Z_blocks = []
    for t in terms:
        Z_i = build_z_simple(group_ids, n_groups, X_re=t["X_re"], layout="blocked")
        Z_blocks.append(Z_i)

    Z = sp.hstack(Z_blocks, format="csc")

    return RandomEffectsInfo(
        Z=Z,
        group_ids_list=[group_ids],
        n_groups_list=[n_groups],
        group_names=[factor_name],
        random_names=random_names,
        re_structure=re_structure,
        X_re=[t["X_re"] for t in terms],
        column_labels=generate_re_labels(
            [factor_name], [levels], [random_names], "blocked"
        ),
    )


def build_re_crossed(
    factors: dict[str, list[dict]],
    data: pl.DataFrame,
) -> RandomEffectsInfo:
    """Build random effects for crossed (multiple) grouping factors.

    Args:
        factors: Dict mapping factor names to their parsed RE term lists.
        data: Polars DataFrame with training data.

    Returns:
        RandomEffectsInfo with horizontally stacked Z matrices.
    """
    group_ids_list: list[NDArray[np.intp]] = []
    n_groups_list: list[int] = []
    group_names: list[str] = []
    group_levels_list: list[list] = []
    all_random_names: list[str] = []
    Z_blocks: list[sp.csc_matrix] = []
    re_structures: list[str] = []
    re_dims: list[int] = []

    for factor_name, terms in factors.items():
        # Handle interaction grouping factors (e.g., "school:class" from nested expansion)
        if ":" in factor_name:
            component_factors = factor_name.split(":")
            for comp in component_factors:
                if comp not in data.columns:
                    raise variable_not_found_error(comp, data.columns)
            # Create combined grouping via string concatenation
            group_series = data.select(
                pl.concat_str(
                    [pl.col(f).cast(pl.Utf8) for f in component_factors],
                    separator=":",
                ).alias("__interaction__")
            ).get_column("__interaction__")
        else:
            group_series = data[factor_name]

        levels, group_ids = extract_group_info(group_series, n_obs=len(data))
        n_groups = len(levels)

        group_ids_list.append(group_ids)
        n_groups_list.append(n_groups)
        group_names.append(factor_name)
        group_levels_list.append(levels)

        # Build Z for this factor's terms
        if len(terms) == 1:
            info = terms[0]
            X_re = info["X_re"]
            random_names = info["random_names"]
            layout = "interleaved"
            re_struct = "slope" if len(random_names) > 1 else "intercept"
        else:
            # Multiple terms: diagonal (uncorrelated)
            random_names = []
            for t in terms:
                random_names.extend(t["random_names"])
            layout = "blocked"
            re_struct = "diagonal"
            # Build each term's Z separately and stack into single factor block
            term_blocks = []
            for t in terms:
                Z_i = build_z_simple(
                    group_ids, n_groups, X_re=t["X_re"], layout="blocked"
                )
                term_blocks.append(Z_i)
            Z_blocks.append(sp.hstack(term_blocks, format="csc"))
            all_random_names.extend(random_names)
            re_structures.append(re_struct)
            re_dims.append(len(random_names))
            continue

        Z_i = build_z_simple(group_ids, n_groups, X_re=X_re, layout=layout)
        Z_blocks.append(Z_i)
        all_random_names.extend(random_names)
        re_structures.append(re_struct)
        re_dims.append(len(random_names))

    # Compute term permutation: sort by n_groups descending (largest first)
    # This optimizes Cholesky factorization by putting larger blocks first
    n_factors = len(n_groups_list)
    if n_factors > 1:
        perm = np.argsort([-n for n in n_groups_list])
        term_permutation = np.array(perm, dtype=np.intp)

        # Apply permutation to all lists
        group_ids_list = [group_ids_list[i] for i in perm]
        n_groups_list = [n_groups_list[i] for i in perm]
        group_names = [group_names[i] for i in perm]
        group_levels_list = [group_levels_list[i] for i in perm]
        Z_blocks = [Z_blocks[i] for i in perm]
        re_structures = [re_structures[i] for i in perm]
        re_dims = [re_dims[i] for i in perm]
    else:
        term_permutation = None

    # Stack all Z blocks horizontally
    Z = sp.hstack(Z_blocks, format="csc")

    return RandomEffectsInfo(
        Z=Z,
        group_ids_list=group_ids_list,
        n_groups_list=n_groups_list,
        group_names=group_names,
        random_names=all_random_names,
        re_structure="crossed",
        re_structures_list=re_structures,
        re_dims_list=re_dims,
        column_labels=generate_re_labels_crossed(
            group_names, group_levels_list, factors
        ),
        term_permutation=term_permutation,
    )


# =============================================================================
# Label generation
# =============================================================================


def generate_re_labels(
    group_names: list[str],
    levels_list: list[list],
    random_names_list: list[list[str]],
    layout: str,
) -> list[str]:
    """Generate column labels for Z matrix.

    Args:
        group_names: Names of grouping factors.
        levels_list: Level lists per factor.
        random_names_list: Random effect name lists per factor.
        layout: "interleaved" or "blocked".

    Returns:
        List of column labels.
    """
    labels: list[str] = []
    for gname, levels, rnames in zip(
        group_names, levels_list, random_names_list, strict=True
    ):
        if layout == "interleaved":
            for level in levels:
                for rname in rnames:
                    labels.append(f"{rname}|{gname}[{level}]")
        else:  # blocked
            for rname in rnames:
                for level in levels:
                    labels.append(f"{rname}|{gname}[{level}]")
    return labels


def generate_re_labels_crossed(
    group_names: list[str],
    levels_list: list[list],
    factors: dict[str, list[dict]],
) -> list[str]:
    """Generate column labels for crossed RE Z matrix.

    Args:
        group_names: Names of grouping factors (permuted order).
        levels_list: Level lists per factor (permuted order).
        factors: Original factor dict mapping factor names to term lists.

    Returns:
        List of column labels.
    """
    labels: list[str] = []
    for gname, levels in zip(group_names, levels_list, strict=True):
        terms = factors[gname]
        for t in terms:
            rnames = t["random_names"]
            for rname in rnames:
                for level in levels:
                    labels.append(f"{rname}|{gname}[{level}]")
    return labels
