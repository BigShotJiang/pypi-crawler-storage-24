"""Formula parsing, design matrix construction, and newdata evaluation.

Call chain:
    model(formula, data) -> parse_formula() -> build_bundle_from_data() -> build_design_matrices()
    model.predict(newdata=) -> evaluate_newdata() (applies learned encoding to new observations)
"""

from bossanova.internal.formula.design import (
    DesignResult,
    build_design_matrices,
)
from bossanova.internal.formula.evaluate import (
    TermResult,
)
from bossanova.internal.formula.evaluate_newdata import (
    evaluate_newdata,
)
from bossanova.internal.formula.parse import (
    FormulaError,
    expand_double_verts,
    expand_nested_syntax,
    parse_formula,
)
from bossanova.internal.formula.random_effects import (
    build_random_effects_from_spec,
)

__all__ = [
    "DesignResult",
    "FormulaError",
    "TermResult",
    "build_design_matrices",
    "build_random_effects_from_spec",
    "evaluate_newdata",
    "expand_double_verts",
    "expand_nested_syntax",
    "parse_formula",
]
