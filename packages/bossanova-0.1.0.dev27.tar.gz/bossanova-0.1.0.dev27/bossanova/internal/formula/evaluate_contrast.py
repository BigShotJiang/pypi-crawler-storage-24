"""Contrast function evaluation for formula-syntax categorical encoding.

Handles formula expressions like ``treatment(x, ref=B)``, ``sum(x, omit=A)``,
``helmert(x, [low, med, high])``, ``poly(x, [lo, hi], degree=2)``.

Each contrast function maps to a builder from ``design.coding`` and
a label generator. The function name in the formula IS the encoding scheme.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import polars as pl
from numpy.typing import NDArray

if TYPE_CHECKING:
    from bossanova.internal.formula.evaluate import TermResult

from bossanova.internal.design.coding import (
    helmert_coding,
    helmert_coding_labels,
    poly_coding,
    poly_coding_labels,
    sequential_coding,
    sequential_coding_labels,
    sum_coding,
    sum_coding_labels,
    treatment_coding,
    treatment_coding_labels,
)
from bossanova.internal.formula.contrast_registry import (
    DEGREE_FUNCTIONS,
    OMIT_FUNCTIONS,
    ORDER_DEPENDENT,
    REF_FUNCTIONS,
    resolve_contrast_name,
)
from bossanova.internal.formula.encoding import (
    encode_categorical,
    get_levels,
)
from bossanova.internal.formula.parser.expr import (
    Assign,
    Call,
    ListExpr,
    Literal,
    Variable,
)

__all__ = [
    "evaluate_contrast_call",
]


def evaluate_contrast_call(
    call: Call,
    func_name: str,
    data: pl.DataFrame,
    factors: dict[str, list[str]],
    contrast_matrices: dict[str, NDArray],
    custom_contrasts: dict[str, NDArray],
    intercept_absorbed: bool,
    *,
    spans_intercept: bool | None = None,
) -> tuple["TermResult", bool]:
    """Evaluate a contrast encoding function call.

    Dispatches to the appropriate contrast matrix builder based on the
    function name (treatment, sum, helmert, sequential, poly).

    Args:
        call: Call AST node (e.g., ``treatment(x, ref=B)``).
        func_name: Canonical function name (already resolved from aliases).
        data: Polars DataFrame with training data.
        factors: Current factor levels mapping.
        contrast_matrices: Current contrast matrices mapping.
        custom_contrasts: User-provided contrast matrices (ndarray overrides).
        intercept_absorbed: Whether intercept df has been absorbed.
        spans_intercept: Whether this categorical should span the intercept.
            If None, determined automatically from intercept_absorbed.

    Returns:
        (TermResult, updated_intercept_absorbed).

    Raises:
        ValueError: If variable not found, not categorical, or invalid arguments.
    """
    # Avoid circular import — TermResult and full_rank_contrast live in evaluate.py
    from bossanova.internal.formula.evaluate import (
        TermResult,
        full_rank_contrast,
    )
    from bossanova.internal.formula.helpers import (
        extract_name,
        variable_not_found_error,
    )

    canonical = resolve_contrast_name(func_name)

    # Extract variable name from first arg
    if not call.args:
        raise ValueError(f"{func_name}() requires at least one argument")
    var_name = extract_name(call.args[0])
    if var_name is None:
        raise ValueError(f"First argument to {func_name}() must be a variable name")
    if var_name not in data.columns:
        raise variable_not_found_error(var_name, data.columns)

    series = data[var_name]

    # Parse optional keyword/positional arguments
    ref_level = _extract_ref_level(call, canonical, func_name)
    omit_level = _extract_omit_level(call, canonical, func_name)
    level_ordering = _extract_level_ordering(call, canonical, func_name)
    degree = _extract_degree(call, canonical, func_name)

    # Get levels (respecting user-supplied ordering if given)
    if level_ordering is not None:
        levels = level_ordering
    elif var_name in factors:
        raw = factors[var_name]
        levels = list(raw) if isinstance(raw, tuple) else raw
    else:
        levels = get_levels(series)

    # Determine if this categorical spans the intercept
    if spans_intercept is None:
        spans_intercept = not intercept_absorbed

    state_updates: dict = {
        "factors": {},
        "contrast_matrices": {},
        "contrast_types": {},
    }

    # Build contrast matrix
    if spans_intercept:
        contrast = full_rank_contrast(levels)
        labels = [f"{var_name}[{lvl}]" for lvl in levels]
        actual_type = "full"
    elif var_name in custom_contrasts:
        contrast = custom_contrasts[var_name]
        actual_type = "custom"
        n_cols = contrast.shape[1]
        labels = [f"{var_name}[c{i + 1}]" for i in range(n_cols)]
    else:
        contrast, labels, actual_type = _build_contrast(
            canonical, var_name, levels, ref_level, omit_level, degree
        )

    state_updates["factors"][var_name] = levels
    state_updates["contrast_matrices"][var_name] = contrast
    state_updates["contrast_types"][var_name] = actual_type

    encoded = encode_categorical(series, contrast)
    result = TermResult(columns=encoded, labels=labels, state_updates=state_updates)

    new_absorbed = intercept_absorbed
    if actual_type == "full":
        new_absorbed = True

    return result, new_absorbed


# ---------------------------------------------------------------------------
# Argument extraction helpers
# ---------------------------------------------------------------------------


def _extract_ref_level(call: Call, canonical: str, func_name: str) -> str | None:
    """Extract ``ref=level`` keyword argument from call.

    Args:
        call: Call AST node.
        canonical: Canonical contrast name.
        func_name: Original function name (for error messages).

    Returns:
        Reference level string, or None if not specified.
    """
    for arg in call.args[1:]:
        if isinstance(arg, Assign) and _assign_key(arg) == "ref":
            if canonical not in REF_FUNCTIONS:
                raise ValueError(
                    f"'{func_name}()' does not accept a 'ref' argument.\n\n"
                    f"Only treatment/dummy contrasts accept 'ref'.\n"
                    f"Example: treatment({_first_arg_name(call)}, ref=B)"
                )
            return _assign_value_str(arg)
    return None


def _extract_omit_level(call: Call, canonical: str, func_name: str) -> str | None:
    """Extract ``omit=level`` keyword argument from call.

    Args:
        call: Call AST node.
        canonical: Canonical contrast name.
        func_name: Original function name (for error messages).

    Returns:
        Omit level string, or None if not specified.
    """
    for arg in call.args[1:]:
        if isinstance(arg, Assign) and _assign_key(arg) == "omit":
            if canonical not in OMIT_FUNCTIONS:
                raise ValueError(
                    f"'{func_name}()' does not accept an 'omit' argument.\n\n"
                    f"Only sum/deviation contrasts accept 'omit'.\n"
                    f"Example: sum({_first_arg_name(call)}, omit=A)"
                )
            return _assign_value_str(arg)
    return None


def _extract_level_ordering(
    call: Call, canonical: str, func_name: str
) -> list[str] | None:
    """Extract ``[level, ...]`` bracket list argument from call.

    Args:
        call: Call AST node.
        canonical: Canonical contrast name.
        func_name: Original function name (for error messages).

    Returns:
        List of level name strings, or None if not specified.
    """
    for arg in call.args[1:]:
        if isinstance(arg, ListExpr):
            if canonical not in ORDER_DEPENDENT:
                raise ValueError(
                    f"'{func_name}()' does not accept a level ordering list.\n\n"
                    f"Level ordering is only supported for order-dependent contrasts: "
                    f"helmert, sequential, poly.\n"
                    f"Example: helmert({_first_arg_name(call)}, [low, med, high])"
                )
            return [_element_to_str(el) for el in arg.elements]
    return None


def _extract_degree(call: Call, canonical: str, func_name: str) -> int | None:
    """Extract degree parameter (positional int or ``degree=N``) from call.

    Args:
        call: Call AST node.
        canonical: Canonical contrast name.
        func_name: Original function name (for error messages).

    Returns:
        Degree integer, or None if not specified.
    """
    for arg in call.args[1:]:
        # Keyword: degree=2
        if isinstance(arg, Assign) and _assign_key(arg) == "degree":
            if canonical not in DEGREE_FUNCTIONS:
                raise ValueError(
                    f"'{func_name}()' does not accept a 'degree' argument.\n\n"
                    f"Only poly() accepts 'degree'.\n"
                    f"Example: poly({_first_arg_name(call)}, degree=2)"
                )
            return _assign_value_int(arg)
        # Positional integer (not a ListExpr, not an Assign, not a Variable)
        if isinstance(arg, Literal) and isinstance(arg.value, (int, float)):
            if canonical not in DEGREE_FUNCTIONS:
                raise ValueError(
                    f"'{func_name}()' does not accept a numeric argument.\n\n"
                    f"Only poly() accepts a degree parameter.\n"
                    f"Example: poly({_first_arg_name(call)}, 2)"
                )
            return int(arg.value)
    return None


# ---------------------------------------------------------------------------
# Contrast builder dispatch
# ---------------------------------------------------------------------------


def _build_contrast(
    canonical: str,
    var_name: str,
    levels: list[str],
    ref_level: str | None,
    omit_level: str | None,
    degree: int | None,
) -> tuple[NDArray[np.float64], list[str], str]:
    """Build contrast matrix and labels for the given scheme.

    Args:
        canonical: Canonical contrast name.
        var_name: Variable name (for label formatting).
        levels: Ordered level list.
        ref_level: Reference level for treatment coding.
        omit_level: Omitted level for sum coding.
        degree: Polynomial degree (poly only).

    Returns:
        (contrast_matrix, labels, contrast_type_string).
    """
    if canonical == "treatment":
        contrast = treatment_coding(levels, reference=ref_level)
        non_ref = treatment_coding_labels(levels, reference=ref_level)
        labels = [f"{var_name}[{lvl}]" for lvl in non_ref]
        return contrast, labels, "treatment"

    if canonical == "sum":
        contrast = sum_coding(levels, omit=omit_level)
        non_omit = sum_coding_labels(levels, omit=omit_level)
        labels = [f"{var_name}[{lvl}]" for lvl in non_omit]
        return contrast, labels, "sum"

    if canonical == "helmert":
        contrast = helmert_coding(levels)
        hlabels = helmert_coding_labels(levels)
        labels = [f"{var_name}[{lbl}]" for lbl in hlabels]
        return contrast, labels, "helmert"

    if canonical == "sequential":
        contrast = sequential_coding(levels)
        slabels = sequential_coding_labels(levels)
        labels = [f"{var_name}[{lbl}]" for lbl in slabels]
        return contrast, labels, "sequential"

    if canonical == "poly":
        max_degree = len(levels) - 1
        if degree is not None:
            if degree < 1 or degree > max_degree:
                raise ValueError(
                    f"poly() degree must be between 1 and {max_degree} "
                    f"(n_levels - 1), got {degree}.\n\n"
                    f"Variable '{var_name}' has {len(levels)} levels: {levels}"
                )
        contrast = poly_coding(levels)
        plabels = poly_coding_labels(levels)
        if degree is not None and degree < max_degree:
            contrast = contrast[:, :degree]
            plabels = plabels[:degree]
        labels = [f"{var_name}{suffix}" for suffix in plabels]
        return contrast, labels, "poly"

    raise ValueError(f"Unsupported contrast type: {canonical}")


# ---------------------------------------------------------------------------
# AST value helpers
# ---------------------------------------------------------------------------


def _assign_key(node: Assign) -> str:
    """Get the keyword name from an Assign node."""
    return node.name.name.lexeme


def _assign_value_str(node: Assign) -> str:
    """Get the string value from an Assign node."""
    val = node.value
    if isinstance(val, Literal):
        return str(val.value)
    if isinstance(val, Variable):
        return val.name.lexeme
    raise ValueError(
        f"Expected a level name after '{_assign_key(node)}=', got {type(val).__name__}"
    )


def _assign_value_int(node: Assign) -> int:
    """Get the integer value from an Assign node."""
    val = node.value
    if isinstance(val, Literal) and isinstance(val.value, (int, float)):
        return int(val.value)
    raise ValueError(
        f"Expected an integer after '{_assign_key(node)}=', got {type(val).__name__}"
    )


def _element_to_str(element: object) -> str:
    """Convert a ListExpr element to a string level name."""
    if isinstance(element, Variable):
        return element.name.lexeme
    if isinstance(element, Literal):
        return str(element.value)
    raise ValueError(
        f"Level ordering elements must be identifiers or strings, "
        f"got {type(element).__name__}"
    )


def _first_arg_name(call: Call) -> str:
    """Get the first argument name for error messages."""
    if call.args:
        from bossanova.internal.formula.helpers import extract_name

        name = extract_name(call.args[0])
        if name:
            return name
    return "x"
