"""Categorical variable encoding using Polars Enum."""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
import polars as pl
from numpy.typing import NDArray

from bossanova.internal.formula.contrast_registry import (
    MODEL_CONTRAST_FUNCTIONS as _MODEL_CONTRAST_FUNCTIONS,
)

if TYPE_CHECKING:
    from bossanova.internal.formula.parser.expr import (
        Binary,
        Call,
        Variable,
    )

__all__ = [
    "detect_categoricals",
    "detect_levels",
    "encode_categorical",
    "ensure_enum",
    "get_levels",
]


def encode_categorical(
    series: pl.Series,
    contrast: NDArray[np.float64],
) -> NDArray[np.float64]:
    """Encode a categorical series using a contrast matrix.

    Takes a Polars series (must be Enum or Categorical type) and applies
    contrast encoding by indexing into the contrast matrix with the
    integer codes.

    Args:
        series: Polars series with Enum or Categorical dtype.
        contrast: Contrast matrix of shape (n_levels, n_columns).
            Row order must match the series' category order.

    Returns:
        Encoded array of shape (n_obs, n_columns).

    Raises:
        ValueError: If series is not categorical or has wrong number of levels.

    Examples:
        >>> import polars as pl
        >>> from bossanova.internal.design.coding import treatment_coding
        >>> series = pl.Series('x', ['B', 'A', 'C']).cast(pl.Enum(['A', 'B', 'C']))
        >>> contrast = treatment_coding(['A', 'B', 'C'])
        >>> encode_categorical(series, contrast)
        array([[1., 0.],
               [0., 0.],
               [0., 1.]])
    """
    # Validate dtype
    if not isinstance(series.dtype, (pl.Enum, pl.Categorical)):
        raise ValueError(f"Series must be Enum or Categorical, got {series.dtype}")

    # Get integer codes via to_physical()
    codes = series.to_physical().to_numpy()

    # Validate level count matches contrast matrix
    n_levels = contrast.shape[0]
    max_code = codes.max() if len(codes) > 0 else 0
    if max_code >= n_levels:
        raise ValueError(
            f"Series has codes up to {max_code} but contrast has only {n_levels} levels"
        )

    # Fancy indexing: select rows from contrast matrix
    return contrast[codes]


def ensure_enum(
    data: pl.DataFrame,
    factors: dict[str, list[str]],
) -> pl.DataFrame:
    """Convert columns to Enum type with specified level ordering.

    This function converts string/categorical columns to Polars Enum type,
    ensuring consistent level ordering. If a column is already an Enum with
    matching levels, it is left unchanged.

    For numeric columns, applies the same formatting as detect_levels() to
    ensure consistency (e.g., 6.0 -> "6").

    Args:
        data: DataFrame to modify.
        factors: Dict mapping column names to ordered level lists.
            Level order determines reference category (first = reference).

    Returns:
        DataFrame with specified columns converted to Enum type.

    Raises:
        ValueError: If a column contains values not in the specified levels.

    Examples:
        >>> import polars as pl
        >>> df = pl.DataFrame({'group': ['B', 'A', 'C', 'A', 'B']})
        >>> df = ensure_enum(df, {'group': ['A', 'B', 'C']})
        >>> df['group'].dtype
        Enum(categories=['A', 'B', 'C'])
    """
    if not factors:
        return data

    expressions = []
    for col_name, levels in factors.items():
        if col_name not in data.columns:
            raise ValueError(f"Column '{col_name}' not found in DataFrame")

        dtype = data[col_name].dtype

        # For numeric columns, map values through format_level for clean strings
        if dtype.is_float() or dtype.is_integer():
            # Build mapping from original string representation to clean level
            unique_vals = data[col_name].unique().to_list()
            mapping = {str(v): format_level(v) for v in unique_vals}
            expr = (
                pl.col(col_name).cast(pl.String).replace(mapping).cast(pl.Enum(levels))
            )
        else:
            # Cast to String first (handles existing categoricals), then to Enum
            expr = pl.col(col_name).cast(pl.String).cast(pl.Enum(levels))

        expressions.append(expr)

    return data.with_columns(*expressions)


def get_levels(series: pl.Series) -> list[str]:
    """Get the level ordering from an Enum or Categorical series.

    Args:
        series: Polars series with Enum or Categorical dtype.

    Returns:
        List of category levels in their defined order.

    Raises:
        ValueError: If series is not categorical.

    Examples:
        >>> import polars as pl
        >>> s = pl.Series('x', ['B', 'A']).cast(pl.Enum(['A', 'B', 'C']))
        >>> get_levels(s)
        ['A', 'B', 'C']
    """
    dtype = series.dtype
    if isinstance(dtype, pl.Enum):
        return list(dtype.categories)
    elif isinstance(dtype, pl.Categorical):
        # For Categorical, get unique values sorted
        return series.unique().sort().cast(pl.String).to_list()
    else:
        raise ValueError(f"Series must be Enum or Categorical, got {dtype}")


def format_level(value: object) -> str:
    """Format a level value as a clean string.

    For numeric values that are integers (e.g., 6.0), formats without
    the decimal point (e.g., "6"). This matches R's behavior where
    factor(cyl) produces levels like "4", "6", "8" not "4.0", "6.0", "8.0".

    Args:
        value: A level value (string, int, or float).

    Returns:
        String representation suitable for labels.
    """
    if isinstance(value, float):
        # Format integers without decimal point
        if value.is_integer():
            return str(int(value))
        return str(value)
    return str(value)


def detect_levels(series: pl.Series) -> list[str]:
    """Infer level ordering from a non-categorical series.

    For string columns that haven't been converted to Enum yet,
    infers levels by getting unique values and sorting them.

    For numeric columns used with factor(), formats integer values
    without decimal points (e.g., 6.0 becomes "6").

    Args:
        series: Polars series (any type).

    Returns:
        List of unique values, sorted alphabetically/numerically.

    Examples:
        >>> import polars as pl
        >>> s = pl.Series('x', ['B', 'A', 'C', 'A'])
        >>> detect_levels(s)
        ['A', 'B', 'C']
        >>> s = pl.Series('x', [6.0, 4.0, 8.0, 4.0])
        >>> detect_levels(s)
        ['4', '6', '8']
    """
    unique_vals = series.unique().sort().to_list()
    return [format_level(v) for v in unique_vals]


def _register_if_categorical(
    col_name: str,
    data: pl.DataFrame,
    categoricals: dict[str, list[str]],
) -> None:
    """Register a column in the categoricals dict if it is a categorical type.

    Checks that the column exists in data, has not already been registered,
    and is of string, Enum, or Categorical dtype. If all conditions are met,
    detects and stores its levels.

    Args:
        col_name: Column name to check.
        data: DataFrame containing the column.
        categoricals: Mutable dict mapping column names to level lists.
            Updated in-place when a categorical column is found.
    """
    if col_name not in data.columns:
        return
    if col_name in categoricals:
        return
    dtype = data[col_name].dtype
    if dtype != pl.String and not isinstance(dtype, (pl.Enum, pl.Categorical)):
        return
    if isinstance(dtype, pl.Enum):
        categoricals[col_name] = get_levels(data[col_name])
    else:
        categoricals[col_name] = detect_levels(data[col_name])


def _extract_list_levels(args: list[object]) -> list[str] | None:
    """Extract level ordering from a [a, b, c] bracket list in function args.

    Scans a list of AST argument nodes for a ListExpr and converts its
    elements to strings. Returns None if no ListExpr is found or any
    element is not a Variable or Literal.

    Args:
        args: List of AST argument nodes (typically tail of a Call's args).

    Returns:
        Ordered list of level strings, or None if not found.
    """
    from bossanova.internal.formula.parser.expr import ListExpr, Literal, Variable

    for arg in args:
        if not isinstance(arg, ListExpr):
            continue
        result = []
        for el in arg.elements:
            if isinstance(el, Variable):
                result.append(el.name.lexeme)
            elif isinstance(el, Literal):
                result.append(str(el.value))
            else:
                return None
        return result
    return None


def _visit_call(
    node: Call,
    data: pl.DataFrame,
    categoricals: dict[str, list[str]],
) -> None:
    """Handle a Call AST node for categorical detection.

    If the call is a contrast encoding function (treatment, sum, helmert,
    etc.), extracts the column name from the first argument and registers
    it in categoricals with the appropriate level ordering. Level ordering
    may be explicit (from a bracket list) or inferred from data.

    Does not recurse into child nodes — the caller is responsible for
    walking all arguments.

    Args:
        node: Call AST node to inspect.
        data: DataFrame used for level inference.
        categoricals: Mutable dict mapping column names to level lists.
            Updated in-place when a contrast column is found.
    """
    from bossanova.internal.formula.parser.expr import QuotedName, Variable

    callee = node.callee
    if not isinstance(callee, Variable):
        return

    func_name = callee.name.lexeme
    if func_name not in _MODEL_CONTRAST_FUNCTIONS:
        return
    if not node.args:
        return

    first_arg = node.args[0]
    col_name: str | None = None

    if isinstance(first_arg, Variable):
        col_name = first_arg.name.lexeme
    elif isinstance(first_arg, QuotedName):
        col_name = first_arg.expression.lexeme

    if not col_name or col_name not in data.columns:
        return

    levels = _extract_list_levels(node.args[1:])
    if levels is None:
        levels = detect_levels(data[col_name])
    categoricals[col_name] = levels


def detect_categoricals(
    ast: Binary | Call | Variable | object,
    data: pl.DataFrame,
) -> dict[str, list[str]]:
    """Detect categorical variables from a formula AST.

    Walks the AST to find:
    1. Explicit categorical markers: factor(x), T(x), S(x)
    2. String columns referenced in the formula

    For explicit markers, extracts level information if provided.
    For implicit string columns, infers levels from data.

    Args:
        ast: Parsed formula AST (from bossanova.internal.formula.parser).
        data: DataFrame to check column types against.

    Returns:
        Dict mapping column names to ordered level lists.

    Examples:
        >>> from bossanova.internal.formula.parser import Scanner, Parser
        >>> import polars as pl
        >>> tokens = Scanner('y ~ factor(group) + age').scan()
        >>> ast = Parser(tokens).parse()
        >>> df = pl.DataFrame({'y': [1, 2], 'group': ['A', 'B'], 'age': [30, 40]})
        >>> detect_categoricals(ast, df)
        {'group': ['A', 'B']}
    """
    # Import AST types here to avoid circular imports
    from bossanova.internal.formula.parser.expr import (
        Assign,
        Binary,
        Call,
        Grouping,
        Literal,
        QuotedName,
        Unary,
        Variable,
    )

    categoricals: dict[str, list[str]] = {}

    def _walk(node: object) -> None:
        """Recursively walk AST nodes."""
        if isinstance(node, Binary):
            _walk(node.left)
            _walk(node.right)

        elif isinstance(node, Unary):
            _walk(node.right)

        elif isinstance(node, Call):
            _visit_call(node, data, categoricals)
            for arg in node.args:
                _walk(arg)

        elif isinstance(node, Variable):
            _register_if_categorical(node.name.lexeme, data, categoricals)

        elif isinstance(node, Grouping):
            _walk(node.expression)

        elif isinstance(node, Assign):
            _walk(node.value)

        elif isinstance(node, QuotedName):
            _register_if_categorical(node.expression.lexeme, data, categoricals)

        elif isinstance(node, Literal):
            pass  # Leaf node

    _walk(ast)
    return categoricals
