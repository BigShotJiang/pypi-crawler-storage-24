"""Continuous distribution factories — thin facade over internal/maths/distributions/.

Re-exports internal Distribution factories with user-facing parameterization.
Users get rich Distribution objects with plotting, algebra, and probability queries.
"""

from bossanova.internal.maths.distributions.base import Distribution
from bossanova.internal.maths.distributions.factories import (
    exponential,
    gamma as _internal_gamma,
    normal,
    t,
    t_dist,
    uniform,
)


def gamma(shape: float, scale: float = 1.0) -> Distribution:
    """Create a gamma distribution (scale parameterization only).

    Args:
        shape: Shape parameter (must be positive).
        scale: Scale parameter (must be positive). Default is 1.0.

    Returns:
        Distribution object.

    Examples:
        ```python
        g = gamma(shape=2.0)  # Gamma(2, 1), mean = 2
        g = gamma(shape=2.0, scale=0.5)  # Gamma(2, 0.5), mean = 1
        ```
    """
    return _internal_gamma(shape=shape, scale=scale)


__all__ = [
    "Distribution",
    "exponential",
    "gamma",
    "normal",
    "t",
    "t_dist",
    "uniform",
]
