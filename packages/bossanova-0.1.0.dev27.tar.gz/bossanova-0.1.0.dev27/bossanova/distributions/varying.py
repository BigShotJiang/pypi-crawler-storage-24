"""Random effect grouping specification for simulation-first workflows."""

from attrs import frozen, field, validators
import numpy as np

__all__ = ["Varying", "varying"]


@frozen
class Varying:
    """Random effect grouping specification for simulation.

    Specifies how to generate grouping variables and their random effects.

    Args:
        n (int | None): Number of groups (e.g., 50 subjects).
        sd (float): Standard deviation for random intercept. Default 1.0.
        intercept_sd (float | None): Alias for sd (for clarity with random slopes).
        slope_sds (dict[str, float]): Dict mapping term names to their random slope SDs.
        corr (float): Correlation between intercept and slope(s). Applied
            uniformly across all term pairs. Default 0.0.
        n_per (int | None): For nested effects, number of sub-groups per parent group.

    Examples:
        ```python
        # Random intercept only: (1|subject)
        varying(n=50, sd=0.3)

        # Random intercept + slope: (1 + time|subject)
        varying(n=50, intercept_sd=0.3, slope_sds={"time": 0.1}, corr=0.2)

        # Nested effects: (1|school/class) - 3 classes per school
        varying(n=10, sd=0.4)     # schools
        varying(n_per=3, sd=0.2)  # classes nested in schools
        ```
    """

    n: int | None = field(default=None)
    sd: float = field(default=1.0, validator=validators.ge(0))

    # For random slopes
    intercept_sd: float | None = field(default=None)
    slope_sds: dict[str, float] = field(factory=dict)
    corr: float = field(default=0.0)

    # For nested effects
    n_per: int | None = field(default=None)

    def __attrs_post_init__(self) -> None:
        """Validate construction constraints."""
        # Must have either n or n_per
        if self.n is None and self.n_per is None:
            msg = "Must specify either n (number of groups) or n_per (for nested)"
            raise ValueError(msg)
        if self.n is not None and self.n_per is not None:
            msg = "Specify either n or n_per, not both"
            raise ValueError(msg)
        if self.n is not None and self.n <= 0:
            msg = f"n must be positive, got {self.n}"
            raise ValueError(msg)
        if self.n_per is not None and self.n_per <= 0:
            msg = f"n_per must be positive, got {self.n_per}"
            raise ValueError(msg)

        # Validate slope_sds values are non-negative
        for term, sd_val in self.slope_sds.items():
            if sd_val < 0:
                msg = f"slope_sds['{term}'] must be non-negative, got {sd_val}"
                raise ValueError(msg)

        # Validate correlation
        if isinstance(self.corr, dict):
            msg = (
                "Dict-form corr is not yet supported. "
                "Use a single scalar value for uniform correlation across all pairs."
            )
            raise NotImplementedError(msg)
        if not -1 <= self.corr <= 1:
            msg = f"corr must be in [-1, 1], got {self.corr}"
            raise ValueError(msg)

    @property
    def effective_intercept_sd(self) -> float:
        """Return intercept SD (intercept_sd if set, else sd)."""
        return self.intercept_sd if self.intercept_sd is not None else self.sd

    @property
    def has_random_slopes(self) -> bool:
        """Check if this specification includes random slopes."""
        return len(self.slope_sds) > 0

    @property
    def is_nested(self) -> bool:
        """Check if this is a nested effect specification (uses n_per)."""
        return self.n_per is not None

    @property
    def n_terms(self) -> int:
        """Number of random effect terms (1 for intercept + number of slopes)."""
        return 1 + len(self.slope_sds)

    def generate_groups(self, n_obs: int, rng: np.random.Generator) -> np.ndarray:
        """Generate group assignments for n observations.

        Creates balanced group assignments where each group gets roughly
        n_obs / n observations, then shuffles randomly.

        Args:
            n_obs (int): Number of observations to assign to groups.
            rng (np.random.Generator): NumPy random number generator for reproducibility.

        Returns:
            Array of group labels (group_1, group_2, ...).

        Raises:
            ValueError: If this is a nested effect (n_per) specification.
        """
        if self.n is None:
            msg = "Cannot generate groups for nested effect (n_per). Use parent group."
            raise ValueError(msg)

        # Balanced assignment: each group gets roughly n_obs / n observations
        group_ids = np.repeat(np.arange(self.n), n_obs // self.n + 1)[:n_obs]
        rng.shuffle(group_ids)
        return np.array([f"group_{i + 1}" for i in group_ids])

    def generate_effects(self, rng: np.random.Generator) -> np.ndarray:
        """Generate random effects for all groups.

        For intercept-only models, draws from N(0, sd^2).
        For models with slopes, draws from multivariate normal with
        covariance structure determined by SDs and correlations.

        Args:
            rng (np.random.Generator): NumPy random number generator for reproducibility.

        Returns:
            Array of shape (n_groups, n_terms) with random effects.
            For intercept-only: shape (n, 1)
            For intercept + slopes: shape (n, 1 + n_slopes)

        Raises:
            ValueError: If this is a nested effect (n_per) specification.
        """
        if self.n is None:
            msg = "Cannot generate effects for nested (n_per). Use parent."
            raise ValueError(msg)

        n_terms = self.n_terms

        if n_terms == 1:
            # Intercept only
            return rng.normal(0, self.effective_intercept_sd, (self.n, 1))

        # Build covariance matrix for multivariate normal
        sds = [self.effective_intercept_sd] + [
            self.slope_sds[t] for t in sorted(self.slope_sds)
        ]

        corr_matrix = np.full((n_terms, n_terms), self.corr)
        np.fill_diagonal(corr_matrix, 1.0)

        # Convert correlation to covariance: Cov = D @ Corr @ D
        D = np.diag(sds)
        cov = D @ corr_matrix @ D

        return rng.multivariate_normal(np.zeros(n_terms), cov, self.n)


def varying(
    n: int | None = None,
    *,
    sd: float = 1.0,
    intercept_sd: float | None = None,
    slope_sds: dict[str, float] | None = None,
    corr: float = 0.0,
    n_per: int | None = None,
) -> Varying:
    """Create a varying (random effect) distribution specification.

    Use this to specify random effect structure for mixed model simulations.

    Args:
        n (int | None): Number of groups (e.g., 50 subjects). Required for
            top-level grouping.
        sd (float): Standard deviation for random intercept. Default 1.0.
        intercept_sd (float | None): Alias for sd (for clarity with random slopes).
        slope_sds (dict[str, float] | None): Dict mapping term names to their
            random slope SDs.
        corr (float): Correlation between intercept and slope(s). Applied
            uniformly across all term pairs. Default 0.0.
        n_per (int | None): For nested effects, number of sub-groups per parent group.

    Returns:
        Varying specification for use in model.simulate().

    Examples:
        ```python
        from bossanova.distributions import varying

        # Random intercept only: (1|subject)
        v = varying(n=50, sd=0.3)  # v.n == 50, v.sd == 0.3

        # Random intercept + slope: (1 + time|subject)
        v = varying(n=50, intercept_sd=0.3, slope_sds={"time": 0.1}, corr=0.2)
        # v.has_random_slopes == True, v.n_terms == 2

        # Nested effects: (1|school/class) - 3 classes per school
        schools = varying(n=10, sd=0.4)
        classes = varying(n_per=3, sd=0.2)  # classes.is_nested == True
        ```
    """
    return Varying(
        n=n,
        sd=sd,
        intercept_sd=intercept_sd,
        slope_sds=slope_sds or {},
        corr=corr,
        n_per=n_per,
    )
