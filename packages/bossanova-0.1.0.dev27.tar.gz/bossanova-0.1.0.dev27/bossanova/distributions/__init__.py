"""Distribution factories for simulation and probability queries.

Users get rich Distribution objects with plotting, algebra, and probability::

    d = normal(0, 1)
    d               # In notebooks: renders PDF plot
    d + normal(3, 2)  # Convolution -> Normal(3, sqrt(5))
    d > 1.96        # P(X > 1.96) = 0.025
    d.pdf(0)        # 0.3989
"""

from bossanova.distributions.continuous import (
    Distribution,
    exponential,
    gamma,
    normal,
    t,
    t_dist,
    uniform,
)
from bossanova.distributions.discrete import (
    Categorical,
    binomial,
    categorical,
    poisson,
)
from bossanova.distributions.varying import Varying, varying

# Rich internal types also available
from bossanova.internal.maths.distributions import (
    ConvolvedDistribution,
    f_dist,
    FoldedDistribution,
    Probability,
    TransformedDistribution,
    TruncatedDistribution,
    beta,
    chi2,
)

__all__ = [
    "Categorical",
    "ConvolvedDistribution",
    "Distribution",
    "FoldedDistribution",
    "Probability",
    "TransformedDistribution",
    "TruncatedDistribution",
    "Varying",
    "beta",
    "binomial",
    "categorical",
    "chi2",
    "exponential",
    "f_dist",
    "gamma",
    "normal",
    "poisson",
    "t",
    "t_dist",
    "uniform",
    "varying",
]
