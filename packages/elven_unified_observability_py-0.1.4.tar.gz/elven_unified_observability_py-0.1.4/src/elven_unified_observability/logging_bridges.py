from __future__ import annotations

import importlib
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, cast

from .config import UnifiedObservabilityConfig, normalize_data, parse_bool

SUPPORTED_LOGGING_INTEGRATIONS = ("loguru", "structlog")
DEFAULT_EXCLUDED_LOGGER_PREFIXES = (
    "httpx",
    "httpcore",
    "urllib3",
    "h11",
    "h2",
    "hpack",
    "opentelemetry",
    "logs_interceptor",
    "elven_unified_observability",
)
_LOGURU_BRIDGE_ATTR = "_elven_uo_loguru_bridge_uninstall"
_STRUCTLOG_BRIDGE_ATTR = "_elven_uo_structlog_bridge_uninstall"


@dataclass(frozen=True)
class RequestedLoggingIntegration:
    name: str
    explicit: bool


def install_logging_integrations(
    config: UnifiedObservabilityConfig,
    logger_instance: Any,
    *,
    warn: Callable[[str], None],
) -> list[Callable[[], None]]:
    uninstallers: list[Callable[[], None]] = []
    for request in resolve_requested_logging_integrations(config):
        installer = _INSTALLERS.get(request.name)
        if installer is None:
            continue
        try:
            uninstaller = installer(config, logger_instance)
        except ModuleNotFoundError:
            if request.explicit:
                warn(
                    "Logging bridge "
                    f"'{request.name}' was requested but its dependency is not installed."
                )
            continue
        except Exception as exc:
            warn(f"Logging bridge '{request.name}' installation failed: {exc}")
            continue
        if uninstaller is not None:
            uninstallers.append(uninstaller)
    return uninstallers


def uninstall_logging_integrations(uninstallers: list[Callable[[], None]]) -> None:
    for uninstall in reversed(uninstallers):
        try:
            uninstall()
        except Exception:
            continue


def flush_logging_integrations(uninstallers: list[Callable[[], None]]) -> None:
    for uninstall in uninstallers:
        flush = getattr(uninstall, "_bridge_flush", None)
        if not callable(flush):
            continue
        try:
            flush()
        except Exception:
            continue


def resolve_requested_logging_integrations(
    config: UnifiedObservabilityConfig,
) -> list[RequestedLoggingIntegration]:
    integrations = _normalized_integrations_config(config)
    if not integrations:
        return []

    requested: dict[str, RequestedLoggingIntegration] = {}
    raw_values = integrations.get("auto_install")
    names = raw_values if isinstance(raw_values, list) else []
    normalized_names = {
        str(item).strip().lower()
        for item in names
        if isinstance(item, str) and str(item).strip()
    }

    if "none" in normalized_names:
        normalized_names.clear()
    if "auto" in normalized_names:
        for name in SUPPORTED_LOGGING_INTEGRATIONS:
            requested[name] = RequestedLoggingIntegration(name=name, explicit=False)
    for name in SUPPORTED_LOGGING_INTEGRATIONS:
        if name in normalized_names:
            requested[name] = RequestedLoggingIntegration(name=name, explicit=True)

    for name in SUPPORTED_LOGGING_INTEGRATIONS:
        raw_config = integrations.get(name)
        integration_config = raw_config if isinstance(raw_config, dict) else {}
        enabled = parse_bool(integration_config.get("enabled"))
        if enabled is True:
            requested[name] = RequestedLoggingIntegration(name=name, explicit=True)
        elif enabled is False:
            requested.pop(name, None)

    return [requested[name] for name in SUPPORTED_LOGGING_INTEGRATIONS if name in requested]


def _normalized_integrations_config(config: UnifiedObservabilityConfig) -> dict[str, Any]:
    normalized = normalize_data(config.logging_integrations or {})
    return normalized if isinstance(normalized, dict) else {}


def _install_loguru_bridge(
    config: UnifiedObservabilityConfig,
    logger_instance: Any,
) -> Callable[[], None] | None:
    integrations = _normalized_integrations_config(config)
    loguru_config = integrations.get("loguru")
    options = loguru_config if isinstance(loguru_config, dict) else {}
    excluded_prefixes = _resolve_excluded_prefixes(integrations, options)

    loguru_module = importlib.import_module("loguru")
    loguru_logger = cast(Any, loguru_module.logger)
    previous_uninstall = getattr(loguru_logger, _LOGURU_BRIDGE_ATTR, None)
    if callable(previous_uninstall):
        try:
            previous_uninstall()
        except Exception:
            pass

    integrations_module = importlib.import_module("logs_interceptor.integrations")

    sink = integrations_module.LoguruSink(
        logger_instance,
        exclude_prefixes=list(excluded_prefixes),
    )
    sink_kwargs = {
        "level": str(options.get("level", "DEBUG")),
        "enqueue": True if options.get("enqueue") is None else bool(options["enqueue"]),
        "backtrace": False if options.get("backtrace") is None else bool(options["backtrace"]),
        "diagnose": False if options.get("diagnose") is None else bool(options["diagnose"]),
        "filter": _build_loguru_filter(excluded_prefixes),
    }
    original_add = loguru_logger.add
    original_complete = getattr(loguru_logger, "complete", None)
    original_remove = loguru_logger.remove
    original_configure = getattr(loguru_logger, "configure", None)
    state: dict[str, Any] = {
        "sink_id": None,
        "syncing": False,
        "uninstalling": False,
    }

    def ensure_sink() -> None:
        if state["syncing"] or state["uninstalling"]:
            return

        state["syncing"] = True
        try:
            sink_id = state.get("sink_id")
            if sink_id is not None:
                try:
                    original_remove(sink_id)
                except Exception:
                    pass
            state["sink_id"] = original_add(sink, **sink_kwargs)
        finally:
            state["syncing"] = False

    def configure_proxy(*args: Any, **kwargs: Any) -> Any:
        if not callable(original_configure):
            return None
        result = original_configure(*args, **kwargs)
        ensure_sink()
        return result

    def flush_bridge() -> None:
        if callable(original_complete):
            original_complete()

    def remove_proxy(*args: Any, **kwargs: Any) -> Any:
        result = original_remove(*args, **kwargs)
        if state["uninstalling"]:
            return result

        target = args[0] if args else None
        remove_all = not args and not kwargs
        if remove_all or target == state.get("sink_id"):
            ensure_sink()
        return result

    ensure_sink()
    if callable(original_configure):
        loguru_logger.configure = configure_proxy
    loguru_logger.remove = remove_proxy

    def uninstall() -> None:
        try:
            state["uninstalling"] = True
            flush_bridge()
            if callable(original_configure):
                loguru_logger.configure = original_configure
            loguru_logger.remove = original_remove
            sink_id = state.get("sink_id")
            if sink_id is not None:
                original_remove(sink_id)
        except Exception:
            pass
        finally:
            current_uninstall = getattr(loguru_logger, _LOGURU_BRIDGE_ATTR, None)
            if current_uninstall is uninstall:
                try:
                    delattr(loguru_logger, _LOGURU_BRIDGE_ATTR)
                except Exception:
                    pass
            state["sink_id"] = None
            state["uninstalling"] = False

    setattr(uninstall, "_bridge_flush", flush_bridge)
    setattr(loguru_logger, _LOGURU_BRIDGE_ATTR, uninstall)
    return uninstall


def _install_structlog_bridge(
    _config: UnifiedObservabilityConfig,
    logger_instance: Any,
) -> Callable[[], None] | None:
    structlog_module = cast(Any, importlib.import_module("structlog"))
    previous_uninstall = getattr(structlog_module, _STRUCTLOG_BRIDGE_ATTR, None)
    if callable(previous_uninstall):
        try:
            previous_uninstall()
        except Exception:
            pass

    integrations_module = importlib.import_module("logs_interceptor.integrations")

    original_configure = structlog_module.configure
    original_configure_once = getattr(structlog_module, "configure_once", None)
    processor = integrations_module.StructlogProcessor(logger_instance)

    def ensure_processors(
        processors: Any,
        current_config: dict[str, Any] | None = None,
    ) -> list[Any]:
        current = list(processors) if isinstance(processors, list) else []
        if any(_is_structlog_processor(item) for item in current):
            result = current
        else:
            result = [processor, *current]

        logger_factory = current_config.get("logger_factory") if current_config else None
        if not current and _needs_structlog_terminal_renderer(logger_factory):
            result = [*result, _build_structlog_fallback_renderer(structlog_module)]
        return result

    def apply_config(processors: list[Any] | None = None) -> None:
        current = _get_structlog_config(structlog_module)
        resolved_processors = current.get("processors") if processors is None else processors
        structlog_module.configure(
            processors=ensure_processors(resolved_processors, current),
            wrapper_class=current.get("wrapper_class"),
            context_class=current.get("context_class"),
            logger_factory=current.get("logger_factory"),
            cache_logger_on_first_use=current.get("cache_logger_on_first_use"),
        )

    def configure_proxy(*args: Any, **kwargs: Any) -> Any:
        current = _get_structlog_config(structlog_module)
        forwarded = dict(kwargs)
        forwarded["processors"] = ensure_processors(
            forwarded.get("processors", current.get("processors")),
            current,
        )
        return original_configure(*args, **forwarded)

    def configure_once_proxy(*args: Any, **kwargs: Any) -> Any:
        if original_configure_once is None:
            return None
        current = _get_structlog_config(structlog_module)
        forwarded = dict(kwargs)
        forwarded["processors"] = ensure_processors(
            forwarded.get("processors", current.get("processors")),
            current,
        )
        return original_configure_once(*args, **forwarded)

    apply_config()
    structlog_module.configure = configure_proxy
    if callable(original_configure_once):
        structlog_module.configure_once = configure_once_proxy

    def uninstall() -> None:
        try:
            structlog_module.configure = original_configure
            if callable(original_configure_once):
                structlog_module.configure_once = original_configure_once
            current = _get_structlog_config(structlog_module)
            processors = [
                item
                for item in list(current.get("processors", []))
                if not _is_structlog_processor(item)
            ]
            structlog_module.configure(
                processors=processors,
                wrapper_class=current.get("wrapper_class"),
                context_class=current.get("context_class"),
                logger_factory=current.get("logger_factory"),
                cache_logger_on_first_use=current.get("cache_logger_on_first_use"),
            )
        except Exception:
            pass
        finally:
            current_uninstall = getattr(structlog_module, _STRUCTLOG_BRIDGE_ATTR, None)
            if current_uninstall is uninstall:
                try:
                    delattr(structlog_module, _STRUCTLOG_BRIDGE_ATTR)
                except Exception:
                    pass

    setattr(structlog_module, _STRUCTLOG_BRIDGE_ATTR, uninstall)
    return uninstall


def _get_structlog_config(structlog_module: Any) -> dict[str, Any]:
    getter = getattr(structlog_module, "get_config", None)
    if not callable(getter):
        return {}
    current = getter()
    return current if isinstance(current, dict) else {}


def _is_structlog_processor(value: Any) -> bool:
    return (
        value.__class__.__name__ == "StructlogProcessor"
        and value.__class__.__module__ == "logs_interceptor.integrations.structlog"
    )


def _needs_structlog_terminal_renderer(logger_factory: Any) -> bool:
    factory_type = getattr(logger_factory, "__class__", None)
    if factory_type is None:
        return False
    return (
        getattr(factory_type, "__name__", "") == "PrintLoggerFactory"
        and str(getattr(factory_type, "__module__", "")).startswith("structlog")
    )


def _build_structlog_fallback_renderer(structlog_module: Any) -> Any:
    processors = getattr(structlog_module, "processors", None)
    renderer_factory = getattr(processors, "KeyValueRenderer", None)
    if callable(renderer_factory):
        return renderer_factory(key_order=["event"])
    return lambda _logger, method_name, event_dict: str(event_dict.get("event", method_name))


def _resolve_excluded_prefixes(
    integrations: dict[str, Any],
    options: dict[str, Any],
) -> tuple[str, ...]:
    global_prefixes = _coerce_string_list(integrations.get("exclude_prefixes"))
    if not global_prefixes:
        global_prefixes = list(DEFAULT_EXCLUDED_LOGGER_PREFIXES)

    override_prefixes = _coerce_string_list(options.get("exclude_prefixes"))
    combined = [*global_prefixes, *override_prefixes]
    seen: set[str] = set()
    normalized: list[str] = []
    for item in combined:
        value = item.strip()
        if not value:
            continue
        lowered = value.lower()
        if lowered in seen:
            continue
        seen.add(lowered)
        normalized.append(value)
    return tuple(normalized)


def _build_loguru_filter(excluded_prefixes: tuple[str, ...]) -> Callable[[dict[str, Any]], bool]:
    lowered_prefixes = tuple(prefix.lower() for prefix in excluded_prefixes if prefix)

    def filter_record(record: dict[str, Any]) -> bool:
        name = str(record.get("name") or "").lower()
        module = str(record.get("module") or "").lower()
        extra = record.get("extra")
        logger_name = ""
        if isinstance(extra, dict):
            logger_name = str(extra.get("logger_name") or "").lower()

        for prefix in lowered_prefixes:
            if (
                name.startswith(prefix)
                or module.startswith(prefix)
                or logger_name.startswith(prefix)
            ):
                return False
        return True

    return filter_record


def _coerce_string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(item) for item in value if str(item).strip()]


_INSTALLERS: dict[str, Callable[[UnifiedObservabilityConfig, Any], Callable[[], None] | None]] = {
    "loguru": _install_loguru_bridge,
    "structlog": _install_structlog_bridge,
}
