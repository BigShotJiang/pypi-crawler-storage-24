# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateAnAppV2Response(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'id': 'str',
        'name': 'str',
        'remark': 'str',
        'creator': 'str',
        'update_time': 'datetime',
        'app_key': 'str',
        'related_domain_id': 'str',
        'related_project_id': 'str',
        'app_secret': 'str',
        'register_time': 'datetime',
        'status': 'int',
        'app_type': 'str',
        'roma_app_type': 'str'
    }

    attribute_map = {
        'id': 'id',
        'name': 'name',
        'remark': 'remark',
        'creator': 'creator',
        'update_time': 'update_time',
        'app_key': 'app_key',
        'related_domain_id': 'related_domain_id',
        'related_project_id': 'related_project_id',
        'app_secret': 'app_secret',
        'register_time': 'register_time',
        'status': 'status',
        'app_type': 'app_type',
        'roma_app_type': 'roma_app_type'
    }

    def __init__(self, id=None, name=None, remark=None, creator=None, update_time=None, app_key=None, related_domain_id=None, related_project_id=None, app_secret=None, register_time=None, status=None, app_type=None, roma_app_type=None):
        r"""CreateAnAppV2Response

        The model defined in huaweicloud sdk

        :param id: 编号
        :type id: str
        :param name: 名称
        :type name: str
        :param remark: 描述
        :type remark: str
        :param creator: APP的创建者 - USER：用户自行创建 - MARKET：云商店分配  暂不支持MARKET
        :type creator: str
        :param update_time: 更新时间
        :type update_time: datetime
        :param app_key: APP凭据的key。
        :type app_key: str
        :param related_domain_id: 凭据关联的账号ID。
        :type related_domain_id: str
        :param related_project_id: 凭据关联的项目ID。
        :type related_project_id: str
        :param app_secret: 密钥
        :type app_secret: str
        :param register_time: 注册时间
        :type register_time: datetime
        :param status: 状态   - 1： 有效
        :type status: int
        :param app_type: APP的类型。 - apig：APIG凭据应用  默认apig，暂不支持其他类型 
        :type app_type: str
        :param roma_app_type: ROMA_APP的类型： - subscription：订阅应用 - integration：集成应用  暂不支持
        :type roma_app_type: str
        """
        
        super().__init__()

        self._id = None
        self._name = None
        self._remark = None
        self._creator = None
        self._update_time = None
        self._app_key = None
        self._related_domain_id = None
        self._related_project_id = None
        self._app_secret = None
        self._register_time = None
        self._status = None
        self._app_type = None
        self._roma_app_type = None
        self.discriminator = None

        if id is not None:
            self.id = id
        if name is not None:
            self.name = name
        if remark is not None:
            self.remark = remark
        if creator is not None:
            self.creator = creator
        if update_time is not None:
            self.update_time = update_time
        if app_key is not None:
            self.app_key = app_key
        if related_domain_id is not None:
            self.related_domain_id = related_domain_id
        if related_project_id is not None:
            self.related_project_id = related_project_id
        if app_secret is not None:
            self.app_secret = app_secret
        if register_time is not None:
            self.register_time = register_time
        if status is not None:
            self.status = status
        if app_type is not None:
            self.app_type = app_type
        if roma_app_type is not None:
            self.roma_app_type = roma_app_type

    @property
    def id(self):
        r"""Gets the id of this CreateAnAppV2Response.

        编号

        :return: The id of this CreateAnAppV2Response.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this CreateAnAppV2Response.

        编号

        :param id: The id of this CreateAnAppV2Response.
        :type id: str
        """
        self._id = id

    @property
    def name(self):
        r"""Gets the name of this CreateAnAppV2Response.

        名称

        :return: The name of this CreateAnAppV2Response.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this CreateAnAppV2Response.

        名称

        :param name: The name of this CreateAnAppV2Response.
        :type name: str
        """
        self._name = name

    @property
    def remark(self):
        r"""Gets the remark of this CreateAnAppV2Response.

        描述

        :return: The remark of this CreateAnAppV2Response.
        :rtype: str
        """
        return self._remark

    @remark.setter
    def remark(self, remark):
        r"""Sets the remark of this CreateAnAppV2Response.

        描述

        :param remark: The remark of this CreateAnAppV2Response.
        :type remark: str
        """
        self._remark = remark

    @property
    def creator(self):
        r"""Gets the creator of this CreateAnAppV2Response.

        APP的创建者 - USER：用户自行创建 - MARKET：云商店分配  暂不支持MARKET

        :return: The creator of this CreateAnAppV2Response.
        :rtype: str
        """
        return self._creator

    @creator.setter
    def creator(self, creator):
        r"""Sets the creator of this CreateAnAppV2Response.

        APP的创建者 - USER：用户自行创建 - MARKET：云商店分配  暂不支持MARKET

        :param creator: The creator of this CreateAnAppV2Response.
        :type creator: str
        """
        self._creator = creator

    @property
    def update_time(self):
        r"""Gets the update_time of this CreateAnAppV2Response.

        更新时间

        :return: The update_time of this CreateAnAppV2Response.
        :rtype: datetime
        """
        return self._update_time

    @update_time.setter
    def update_time(self, update_time):
        r"""Sets the update_time of this CreateAnAppV2Response.

        更新时间

        :param update_time: The update_time of this CreateAnAppV2Response.
        :type update_time: datetime
        """
        self._update_time = update_time

    @property
    def app_key(self):
        r"""Gets the app_key of this CreateAnAppV2Response.

        APP凭据的key。

        :return: The app_key of this CreateAnAppV2Response.
        :rtype: str
        """
        return self._app_key

    @app_key.setter
    def app_key(self, app_key):
        r"""Sets the app_key of this CreateAnAppV2Response.

        APP凭据的key。

        :param app_key: The app_key of this CreateAnAppV2Response.
        :type app_key: str
        """
        self._app_key = app_key

    @property
    def related_domain_id(self):
        r"""Gets the related_domain_id of this CreateAnAppV2Response.

        凭据关联的账号ID。

        :return: The related_domain_id of this CreateAnAppV2Response.
        :rtype: str
        """
        return self._related_domain_id

    @related_domain_id.setter
    def related_domain_id(self, related_domain_id):
        r"""Sets the related_domain_id of this CreateAnAppV2Response.

        凭据关联的账号ID。

        :param related_domain_id: The related_domain_id of this CreateAnAppV2Response.
        :type related_domain_id: str
        """
        self._related_domain_id = related_domain_id

    @property
    def related_project_id(self):
        r"""Gets the related_project_id of this CreateAnAppV2Response.

        凭据关联的项目ID。

        :return: The related_project_id of this CreateAnAppV2Response.
        :rtype: str
        """
        return self._related_project_id

    @related_project_id.setter
    def related_project_id(self, related_project_id):
        r"""Sets the related_project_id of this CreateAnAppV2Response.

        凭据关联的项目ID。

        :param related_project_id: The related_project_id of this CreateAnAppV2Response.
        :type related_project_id: str
        """
        self._related_project_id = related_project_id

    @property
    def app_secret(self):
        r"""Gets the app_secret of this CreateAnAppV2Response.

        密钥

        :return: The app_secret of this CreateAnAppV2Response.
        :rtype: str
        """
        return self._app_secret

    @app_secret.setter
    def app_secret(self, app_secret):
        r"""Sets the app_secret of this CreateAnAppV2Response.

        密钥

        :param app_secret: The app_secret of this CreateAnAppV2Response.
        :type app_secret: str
        """
        self._app_secret = app_secret

    @property
    def register_time(self):
        r"""Gets the register_time of this CreateAnAppV2Response.

        注册时间

        :return: The register_time of this CreateAnAppV2Response.
        :rtype: datetime
        """
        return self._register_time

    @register_time.setter
    def register_time(self, register_time):
        r"""Sets the register_time of this CreateAnAppV2Response.

        注册时间

        :param register_time: The register_time of this CreateAnAppV2Response.
        :type register_time: datetime
        """
        self._register_time = register_time

    @property
    def status(self):
        r"""Gets the status of this CreateAnAppV2Response.

        状态   - 1： 有效

        :return: The status of this CreateAnAppV2Response.
        :rtype: int
        """
        return self._status

    @status.setter
    def status(self, status):
        r"""Sets the status of this CreateAnAppV2Response.

        状态   - 1： 有效

        :param status: The status of this CreateAnAppV2Response.
        :type status: int
        """
        self._status = status

    @property
    def app_type(self):
        r"""Gets the app_type of this CreateAnAppV2Response.

        APP的类型。 - apig：APIG凭据应用  默认apig，暂不支持其他类型 

        :return: The app_type of this CreateAnAppV2Response.
        :rtype: str
        """
        return self._app_type

    @app_type.setter
    def app_type(self, app_type):
        r"""Sets the app_type of this CreateAnAppV2Response.

        APP的类型。 - apig：APIG凭据应用  默认apig，暂不支持其他类型 

        :param app_type: The app_type of this CreateAnAppV2Response.
        :type app_type: str
        """
        self._app_type = app_type

    @property
    def roma_app_type(self):
        r"""Gets the roma_app_type of this CreateAnAppV2Response.

        ROMA_APP的类型： - subscription：订阅应用 - integration：集成应用  暂不支持

        :return: The roma_app_type of this CreateAnAppV2Response.
        :rtype: str
        """
        return self._roma_app_type

    @roma_app_type.setter
    def roma_app_type(self, roma_app_type):
        r"""Sets the roma_app_type of this CreateAnAppV2Response.

        ROMA_APP的类型： - subscription：订阅应用 - integration：集成应用  暂不支持

        :param roma_app_type: The roma_app_type of this CreateAnAppV2Response.
        :type roma_app_type: str
        """
        self._roma_app_type = roma_app_type

    def to_dict(self):
        import warnings
        warnings.warn("CreateAnAppV2Response.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateAnAppV2Response):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
