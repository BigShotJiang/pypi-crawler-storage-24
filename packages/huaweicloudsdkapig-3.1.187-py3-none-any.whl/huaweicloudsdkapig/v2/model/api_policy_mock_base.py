# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ApiPolicyMockBase:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'result_content': 'str'
    }

    attribute_map = {
        'result_content': 'result_content'
    }

    def __init__(self, result_content=None):
        r"""ApiPolicyMockBase

        The model defined in huaweicloud sdk

        :param result_content: 返回结果
        :type result_content: str
        """
        
        

        self._result_content = None
        self.discriminator = None

        if result_content is not None:
            self.result_content = result_content

    @property
    def result_content(self):
        r"""Gets the result_content of this ApiPolicyMockBase.

        返回结果

        :return: The result_content of this ApiPolicyMockBase.
        :rtype: str
        """
        return self._result_content

    @result_content.setter
    def result_content(self, result_content):
        r"""Sets the result_content of this ApiPolicyMockBase.

        返回结果

        :param result_content: The result_content of this ApiPolicyMockBase.
        :type result_content: str
        """
        self._result_content = result_content

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ApiPolicyMockBase):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
