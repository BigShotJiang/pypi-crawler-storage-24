# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class CreateRequestThrottlingPolicyV2Response(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'app_call_limits': 'int',
        'name': 'str',
        'time_unit': 'str',
        'remark': 'str',
        'api_call_limits': 'int',
        'type': 'int',
        'enable_adaptive_control': 'str',
        'user_call_limits': 'int',
        'time_interval': 'int',
        'ip_call_limits': 'int',
        'id': 'str',
        'bind_num': 'int',
        'is_inclu_special_throttle': 'int',
        'create_time': 'datetime'
    }

    attribute_map = {
        'app_call_limits': 'app_call_limits',
        'name': 'name',
        'time_unit': 'time_unit',
        'remark': 'remark',
        'api_call_limits': 'api_call_limits',
        'type': 'type',
        'enable_adaptive_control': 'enable_adaptive_control',
        'user_call_limits': 'user_call_limits',
        'time_interval': 'time_interval',
        'ip_call_limits': 'ip_call_limits',
        'id': 'id',
        'bind_num': 'bind_num',
        'is_inclu_special_throttle': 'is_inclu_special_throttle',
        'create_time': 'create_time'
    }

    def __init__(self, app_call_limits=None, name=None, time_unit=None, remark=None, api_call_limits=None, type=None, enable_adaptive_control=None, user_call_limits=None, time_interval=None, ip_call_limits=None, id=None, bind_num=None, is_inclu_special_throttle=None, create_time=None):
        r"""CreateRequestThrottlingPolicyV2Response

        The model defined in huaweicloud sdk

        :param app_call_limits: APP流量限制是指一个API在时长之内被每个APP访问的次数上限，该数值不超过用户流量限制值。输入的值不超过2147483647。正整数。 
        :type app_call_limits: int
        :param name: 流控策略名称。支持汉字，英文，数字，下划线，且只能以英文和汉字开头，3 ~ 64字符。 &gt; 中文字符必须为UTF-8或者unicode编码。
        :type name: str
        :param time_unit: 流控的时间单位
        :type time_unit: str
        :param remark: 流控策略描述字符长度不超过255。 &gt; 中文字符必须为UTF-8或者unicode编码。
        :type remark: str
        :param api_call_limits: API流量限制是指时长内一个API能够被访问的次数上限。该值不超过系统默认配额限制，系统默认配额为200tps，用户可根据实际情况修改该系统默认配额。输入的值不超过2147483647。正整数。
        :type api_call_limits: int
        :param type: 流控策略的类型 - 1：基础，表示绑定到流控策略的单个API流控时间内能够被调用多少次。 - 2：共享，表示绑定到流控策略的所有API流控时间内能够被调用多少次。
        :type type: int
        :param enable_adaptive_control: 是否开启动态流控： - TRUE - FALSE  暂不支持
        :type enable_adaptive_control: str
        :param user_call_limits: 用户流量限制是指一个API在时长之内每一个用户能访问的次数上限，该数值不超过API流量限制值。输入的值不超过2147483647。正整数。
        :type user_call_limits: int
        :param time_interval: 流量控制的时长单位。与“流量限制次数”配合使用，表示单位时间内的API请求次数上限。输入的值不超过2147483647。正整数。
        :type time_interval: int
        :param ip_call_limits: 源IP流量限制是指一个API在时长之内被每个IP访问的次数上限，该数值不超过API流量限制值。输入的值不超过2147483647。正整数。
        :type ip_call_limits: int
        :param id: 流控策略的ID
        :type id: str
        :param bind_num: 流控绑定的API数量
        :type bind_num: int
        :param is_inclu_special_throttle: 是否包含特殊流控配置 - 1：包含 - 2：不包含
        :type is_inclu_special_throttle: int
        :param create_time: 创建时间
        :type create_time: datetime
        """
        
        super().__init__()

        self._app_call_limits = None
        self._name = None
        self._time_unit = None
        self._remark = None
        self._api_call_limits = None
        self._type = None
        self._enable_adaptive_control = None
        self._user_call_limits = None
        self._time_interval = None
        self._ip_call_limits = None
        self._id = None
        self._bind_num = None
        self._is_inclu_special_throttle = None
        self._create_time = None
        self.discriminator = None

        if app_call_limits is not None:
            self.app_call_limits = app_call_limits
        self.name = name
        self.time_unit = time_unit
        if remark is not None:
            self.remark = remark
        self.api_call_limits = api_call_limits
        if type is not None:
            self.type = type
        if enable_adaptive_control is not None:
            self.enable_adaptive_control = enable_adaptive_control
        if user_call_limits is not None:
            self.user_call_limits = user_call_limits
        self.time_interval = time_interval
        if ip_call_limits is not None:
            self.ip_call_limits = ip_call_limits
        if id is not None:
            self.id = id
        if bind_num is not None:
            self.bind_num = bind_num
        if is_inclu_special_throttle is not None:
            self.is_inclu_special_throttle = is_inclu_special_throttle
        if create_time is not None:
            self.create_time = create_time

    @property
    def app_call_limits(self):
        r"""Gets the app_call_limits of this CreateRequestThrottlingPolicyV2Response.

        APP流量限制是指一个API在时长之内被每个APP访问的次数上限，该数值不超过用户流量限制值。输入的值不超过2147483647。正整数。 

        :return: The app_call_limits of this CreateRequestThrottlingPolicyV2Response.
        :rtype: int
        """
        return self._app_call_limits

    @app_call_limits.setter
    def app_call_limits(self, app_call_limits):
        r"""Sets the app_call_limits of this CreateRequestThrottlingPolicyV2Response.

        APP流量限制是指一个API在时长之内被每个APP访问的次数上限，该数值不超过用户流量限制值。输入的值不超过2147483647。正整数。 

        :param app_call_limits: The app_call_limits of this CreateRequestThrottlingPolicyV2Response.
        :type app_call_limits: int
        """
        self._app_call_limits = app_call_limits

    @property
    def name(self):
        r"""Gets the name of this CreateRequestThrottlingPolicyV2Response.

        流控策略名称。支持汉字，英文，数字，下划线，且只能以英文和汉字开头，3 ~ 64字符。 > 中文字符必须为UTF-8或者unicode编码。

        :return: The name of this CreateRequestThrottlingPolicyV2Response.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this CreateRequestThrottlingPolicyV2Response.

        流控策略名称。支持汉字，英文，数字，下划线，且只能以英文和汉字开头，3 ~ 64字符。 > 中文字符必须为UTF-8或者unicode编码。

        :param name: The name of this CreateRequestThrottlingPolicyV2Response.
        :type name: str
        """
        self._name = name

    @property
    def time_unit(self):
        r"""Gets the time_unit of this CreateRequestThrottlingPolicyV2Response.

        流控的时间单位

        :return: The time_unit of this CreateRequestThrottlingPolicyV2Response.
        :rtype: str
        """
        return self._time_unit

    @time_unit.setter
    def time_unit(self, time_unit):
        r"""Sets the time_unit of this CreateRequestThrottlingPolicyV2Response.

        流控的时间单位

        :param time_unit: The time_unit of this CreateRequestThrottlingPolicyV2Response.
        :type time_unit: str
        """
        self._time_unit = time_unit

    @property
    def remark(self):
        r"""Gets the remark of this CreateRequestThrottlingPolicyV2Response.

        流控策略描述字符长度不超过255。 > 中文字符必须为UTF-8或者unicode编码。

        :return: The remark of this CreateRequestThrottlingPolicyV2Response.
        :rtype: str
        """
        return self._remark

    @remark.setter
    def remark(self, remark):
        r"""Sets the remark of this CreateRequestThrottlingPolicyV2Response.

        流控策略描述字符长度不超过255。 > 中文字符必须为UTF-8或者unicode编码。

        :param remark: The remark of this CreateRequestThrottlingPolicyV2Response.
        :type remark: str
        """
        self._remark = remark

    @property
    def api_call_limits(self):
        r"""Gets the api_call_limits of this CreateRequestThrottlingPolicyV2Response.

        API流量限制是指时长内一个API能够被访问的次数上限。该值不超过系统默认配额限制，系统默认配额为200tps，用户可根据实际情况修改该系统默认配额。输入的值不超过2147483647。正整数。

        :return: The api_call_limits of this CreateRequestThrottlingPolicyV2Response.
        :rtype: int
        """
        return self._api_call_limits

    @api_call_limits.setter
    def api_call_limits(self, api_call_limits):
        r"""Sets the api_call_limits of this CreateRequestThrottlingPolicyV2Response.

        API流量限制是指时长内一个API能够被访问的次数上限。该值不超过系统默认配额限制，系统默认配额为200tps，用户可根据实际情况修改该系统默认配额。输入的值不超过2147483647。正整数。

        :param api_call_limits: The api_call_limits of this CreateRequestThrottlingPolicyV2Response.
        :type api_call_limits: int
        """
        self._api_call_limits = api_call_limits

    @property
    def type(self):
        r"""Gets the type of this CreateRequestThrottlingPolicyV2Response.

        流控策略的类型 - 1：基础，表示绑定到流控策略的单个API流控时间内能够被调用多少次。 - 2：共享，表示绑定到流控策略的所有API流控时间内能够被调用多少次。

        :return: The type of this CreateRequestThrottlingPolicyV2Response.
        :rtype: int
        """
        return self._type

    @type.setter
    def type(self, type):
        r"""Sets the type of this CreateRequestThrottlingPolicyV2Response.

        流控策略的类型 - 1：基础，表示绑定到流控策略的单个API流控时间内能够被调用多少次。 - 2：共享，表示绑定到流控策略的所有API流控时间内能够被调用多少次。

        :param type: The type of this CreateRequestThrottlingPolicyV2Response.
        :type type: int
        """
        self._type = type

    @property
    def enable_adaptive_control(self):
        r"""Gets the enable_adaptive_control of this CreateRequestThrottlingPolicyV2Response.

        是否开启动态流控： - TRUE - FALSE  暂不支持

        :return: The enable_adaptive_control of this CreateRequestThrottlingPolicyV2Response.
        :rtype: str
        """
        return self._enable_adaptive_control

    @enable_adaptive_control.setter
    def enable_adaptive_control(self, enable_adaptive_control):
        r"""Sets the enable_adaptive_control of this CreateRequestThrottlingPolicyV2Response.

        是否开启动态流控： - TRUE - FALSE  暂不支持

        :param enable_adaptive_control: The enable_adaptive_control of this CreateRequestThrottlingPolicyV2Response.
        :type enable_adaptive_control: str
        """
        self._enable_adaptive_control = enable_adaptive_control

    @property
    def user_call_limits(self):
        r"""Gets the user_call_limits of this CreateRequestThrottlingPolicyV2Response.

        用户流量限制是指一个API在时长之内每一个用户能访问的次数上限，该数值不超过API流量限制值。输入的值不超过2147483647。正整数。

        :return: The user_call_limits of this CreateRequestThrottlingPolicyV2Response.
        :rtype: int
        """
        return self._user_call_limits

    @user_call_limits.setter
    def user_call_limits(self, user_call_limits):
        r"""Sets the user_call_limits of this CreateRequestThrottlingPolicyV2Response.

        用户流量限制是指一个API在时长之内每一个用户能访问的次数上限，该数值不超过API流量限制值。输入的值不超过2147483647。正整数。

        :param user_call_limits: The user_call_limits of this CreateRequestThrottlingPolicyV2Response.
        :type user_call_limits: int
        """
        self._user_call_limits = user_call_limits

    @property
    def time_interval(self):
        r"""Gets the time_interval of this CreateRequestThrottlingPolicyV2Response.

        流量控制的时长单位。与“流量限制次数”配合使用，表示单位时间内的API请求次数上限。输入的值不超过2147483647。正整数。

        :return: The time_interval of this CreateRequestThrottlingPolicyV2Response.
        :rtype: int
        """
        return self._time_interval

    @time_interval.setter
    def time_interval(self, time_interval):
        r"""Sets the time_interval of this CreateRequestThrottlingPolicyV2Response.

        流量控制的时长单位。与“流量限制次数”配合使用，表示单位时间内的API请求次数上限。输入的值不超过2147483647。正整数。

        :param time_interval: The time_interval of this CreateRequestThrottlingPolicyV2Response.
        :type time_interval: int
        """
        self._time_interval = time_interval

    @property
    def ip_call_limits(self):
        r"""Gets the ip_call_limits of this CreateRequestThrottlingPolicyV2Response.

        源IP流量限制是指一个API在时长之内被每个IP访问的次数上限，该数值不超过API流量限制值。输入的值不超过2147483647。正整数。

        :return: The ip_call_limits of this CreateRequestThrottlingPolicyV2Response.
        :rtype: int
        """
        return self._ip_call_limits

    @ip_call_limits.setter
    def ip_call_limits(self, ip_call_limits):
        r"""Sets the ip_call_limits of this CreateRequestThrottlingPolicyV2Response.

        源IP流量限制是指一个API在时长之内被每个IP访问的次数上限，该数值不超过API流量限制值。输入的值不超过2147483647。正整数。

        :param ip_call_limits: The ip_call_limits of this CreateRequestThrottlingPolicyV2Response.
        :type ip_call_limits: int
        """
        self._ip_call_limits = ip_call_limits

    @property
    def id(self):
        r"""Gets the id of this CreateRequestThrottlingPolicyV2Response.

        流控策略的ID

        :return: The id of this CreateRequestThrottlingPolicyV2Response.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this CreateRequestThrottlingPolicyV2Response.

        流控策略的ID

        :param id: The id of this CreateRequestThrottlingPolicyV2Response.
        :type id: str
        """
        self._id = id

    @property
    def bind_num(self):
        r"""Gets the bind_num of this CreateRequestThrottlingPolicyV2Response.

        流控绑定的API数量

        :return: The bind_num of this CreateRequestThrottlingPolicyV2Response.
        :rtype: int
        """
        return self._bind_num

    @bind_num.setter
    def bind_num(self, bind_num):
        r"""Sets the bind_num of this CreateRequestThrottlingPolicyV2Response.

        流控绑定的API数量

        :param bind_num: The bind_num of this CreateRequestThrottlingPolicyV2Response.
        :type bind_num: int
        """
        self._bind_num = bind_num

    @property
    def is_inclu_special_throttle(self):
        r"""Gets the is_inclu_special_throttle of this CreateRequestThrottlingPolicyV2Response.

        是否包含特殊流控配置 - 1：包含 - 2：不包含

        :return: The is_inclu_special_throttle of this CreateRequestThrottlingPolicyV2Response.
        :rtype: int
        """
        return self._is_inclu_special_throttle

    @is_inclu_special_throttle.setter
    def is_inclu_special_throttle(self, is_inclu_special_throttle):
        r"""Sets the is_inclu_special_throttle of this CreateRequestThrottlingPolicyV2Response.

        是否包含特殊流控配置 - 1：包含 - 2：不包含

        :param is_inclu_special_throttle: The is_inclu_special_throttle of this CreateRequestThrottlingPolicyV2Response.
        :type is_inclu_special_throttle: int
        """
        self._is_inclu_special_throttle = is_inclu_special_throttle

    @property
    def create_time(self):
        r"""Gets the create_time of this CreateRequestThrottlingPolicyV2Response.

        创建时间

        :return: The create_time of this CreateRequestThrottlingPolicyV2Response.
        :rtype: datetime
        """
        return self._create_time

    @create_time.setter
    def create_time(self, create_time):
        r"""Sets the create_time of this CreateRequestThrottlingPolicyV2Response.

        创建时间

        :param create_time: The create_time of this CreateRequestThrottlingPolicyV2Response.
        :type create_time: datetime
        """
        self._create_time = create_time

    def to_dict(self):
        import warnings
        warnings.warn("CreateRequestThrottlingPolicyV2Response.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateRequestThrottlingPolicyV2Response):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
