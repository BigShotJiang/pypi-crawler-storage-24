# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class EnvInfo:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'create_time': 'datetime',
        'name': 'str',
        'remark': 'str',
        'id': 'str'
    }

    attribute_map = {
        'create_time': 'create_time',
        'name': 'name',
        'remark': 'remark',
        'id': 'id'
    }

    def __init__(self, create_time=None, name=None, remark=None, id=None):
        r"""EnvInfo

        The model defined in huaweicloud sdk

        :param create_time: 创建时间
        :type create_time: datetime
        :param name: 环境名称
        :type name: str
        :param remark: 描述信息
        :type remark: str
        :param id: 环境id
        :type id: str
        """
        
        

        self._create_time = None
        self._name = None
        self._remark = None
        self._id = None
        self.discriminator = None

        if create_time is not None:
            self.create_time = create_time
        if name is not None:
            self.name = name
        if remark is not None:
            self.remark = remark
        if id is not None:
            self.id = id

    @property
    def create_time(self):
        r"""Gets the create_time of this EnvInfo.

        创建时间

        :return: The create_time of this EnvInfo.
        :rtype: datetime
        """
        return self._create_time

    @create_time.setter
    def create_time(self, create_time):
        r"""Sets the create_time of this EnvInfo.

        创建时间

        :param create_time: The create_time of this EnvInfo.
        :type create_time: datetime
        """
        self._create_time = create_time

    @property
    def name(self):
        r"""Gets the name of this EnvInfo.

        环境名称

        :return: The name of this EnvInfo.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        r"""Sets the name of this EnvInfo.

        环境名称

        :param name: The name of this EnvInfo.
        :type name: str
        """
        self._name = name

    @property
    def remark(self):
        r"""Gets the remark of this EnvInfo.

        描述信息

        :return: The remark of this EnvInfo.
        :rtype: str
        """
        return self._remark

    @remark.setter
    def remark(self, remark):
        r"""Sets the remark of this EnvInfo.

        描述信息

        :param remark: The remark of this EnvInfo.
        :type remark: str
        """
        self._remark = remark

    @property
    def id(self):
        r"""Gets the id of this EnvInfo.

        环境id

        :return: The id of this EnvInfo.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        r"""Sets the id of this EnvInfo.

        环境id

        :param id: The id of this EnvInfo.
        :type id: str
        """
        self._id = id

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, EnvInfo):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
