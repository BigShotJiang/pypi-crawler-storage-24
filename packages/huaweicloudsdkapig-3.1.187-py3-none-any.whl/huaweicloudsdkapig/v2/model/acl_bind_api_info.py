# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class AclBindApiInfo:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'api_id': 'str',
        'api_name': 'str',
        'api_type': 'int',
        'api_remark': 'str',
        'env_id': 'str',
        'env_name': 'str',
        'bind_id': 'str',
        'group_name': 'str',
        'bind_time': 'datetime',
        'publish_id': 'str',
        'req_method': 'str',
        'tags': 'list[str]'
    }

    attribute_map = {
        'api_id': 'api_id',
        'api_name': 'api_name',
        'api_type': 'api_type',
        'api_remark': 'api_remark',
        'env_id': 'env_id',
        'env_name': 'env_name',
        'bind_id': 'bind_id',
        'group_name': 'group_name',
        'bind_time': 'bind_time',
        'publish_id': 'publish_id',
        'req_method': 'req_method',
        'tags': 'tags'
    }

    def __init__(self, api_id=None, api_name=None, api_type=None, api_remark=None, env_id=None, env_name=None, bind_id=None, group_name=None, bind_time=None, publish_id=None, req_method=None, tags=None):
        r"""AclBindApiInfo

        The model defined in huaweicloud sdk

        :param api_id: API编号
        :type api_id: str
        :param api_name: API名称
        :type api_name: str
        :param api_type: API类型。 - 1：公有API - 2：私有API 
        :type api_type: int
        :param api_remark: API的描述信息
        :type api_remark: str
        :param env_id: 生效的环境编号
        :type env_id: str
        :param env_name: 生效的环境名称
        :type env_name: str
        :param bind_id: 绑定关系编号
        :type bind_id: str
        :param group_name: API分组名称
        :type group_name: str
        :param bind_time: 绑定时间
        :type bind_time: datetime
        :param publish_id: API发布记录编号
        :type publish_id: str
        :param req_method: API请求方法
        :type req_method: str
        :param tags: API绑定的标签，标签配额默认10条，可以联系技术调整。
        :type tags: list[str]
        """
        
        

        self._api_id = None
        self._api_name = None
        self._api_type = None
        self._api_remark = None
        self._env_id = None
        self._env_name = None
        self._bind_id = None
        self._group_name = None
        self._bind_time = None
        self._publish_id = None
        self._req_method = None
        self._tags = None
        self.discriminator = None

        if api_id is not None:
            self.api_id = api_id
        if api_name is not None:
            self.api_name = api_name
        if api_type is not None:
            self.api_type = api_type
        if api_remark is not None:
            self.api_remark = api_remark
        if env_id is not None:
            self.env_id = env_id
        if env_name is not None:
            self.env_name = env_name
        if bind_id is not None:
            self.bind_id = bind_id
        if group_name is not None:
            self.group_name = group_name
        if bind_time is not None:
            self.bind_time = bind_time
        if publish_id is not None:
            self.publish_id = publish_id
        if req_method is not None:
            self.req_method = req_method
        if tags is not None:
            self.tags = tags

    @property
    def api_id(self):
        r"""Gets the api_id of this AclBindApiInfo.

        API编号

        :return: The api_id of this AclBindApiInfo.
        :rtype: str
        """
        return self._api_id

    @api_id.setter
    def api_id(self, api_id):
        r"""Sets the api_id of this AclBindApiInfo.

        API编号

        :param api_id: The api_id of this AclBindApiInfo.
        :type api_id: str
        """
        self._api_id = api_id

    @property
    def api_name(self):
        r"""Gets the api_name of this AclBindApiInfo.

        API名称

        :return: The api_name of this AclBindApiInfo.
        :rtype: str
        """
        return self._api_name

    @api_name.setter
    def api_name(self, api_name):
        r"""Sets the api_name of this AclBindApiInfo.

        API名称

        :param api_name: The api_name of this AclBindApiInfo.
        :type api_name: str
        """
        self._api_name = api_name

    @property
    def api_type(self):
        r"""Gets the api_type of this AclBindApiInfo.

        API类型。 - 1：公有API - 2：私有API 

        :return: The api_type of this AclBindApiInfo.
        :rtype: int
        """
        return self._api_type

    @api_type.setter
    def api_type(self, api_type):
        r"""Sets the api_type of this AclBindApiInfo.

        API类型。 - 1：公有API - 2：私有API 

        :param api_type: The api_type of this AclBindApiInfo.
        :type api_type: int
        """
        self._api_type = api_type

    @property
    def api_remark(self):
        r"""Gets the api_remark of this AclBindApiInfo.

        API的描述信息

        :return: The api_remark of this AclBindApiInfo.
        :rtype: str
        """
        return self._api_remark

    @api_remark.setter
    def api_remark(self, api_remark):
        r"""Sets the api_remark of this AclBindApiInfo.

        API的描述信息

        :param api_remark: The api_remark of this AclBindApiInfo.
        :type api_remark: str
        """
        self._api_remark = api_remark

    @property
    def env_id(self):
        r"""Gets the env_id of this AclBindApiInfo.

        生效的环境编号

        :return: The env_id of this AclBindApiInfo.
        :rtype: str
        """
        return self._env_id

    @env_id.setter
    def env_id(self, env_id):
        r"""Sets the env_id of this AclBindApiInfo.

        生效的环境编号

        :param env_id: The env_id of this AclBindApiInfo.
        :type env_id: str
        """
        self._env_id = env_id

    @property
    def env_name(self):
        r"""Gets the env_name of this AclBindApiInfo.

        生效的环境名称

        :return: The env_name of this AclBindApiInfo.
        :rtype: str
        """
        return self._env_name

    @env_name.setter
    def env_name(self, env_name):
        r"""Sets the env_name of this AclBindApiInfo.

        生效的环境名称

        :param env_name: The env_name of this AclBindApiInfo.
        :type env_name: str
        """
        self._env_name = env_name

    @property
    def bind_id(self):
        r"""Gets the bind_id of this AclBindApiInfo.

        绑定关系编号

        :return: The bind_id of this AclBindApiInfo.
        :rtype: str
        """
        return self._bind_id

    @bind_id.setter
    def bind_id(self, bind_id):
        r"""Sets the bind_id of this AclBindApiInfo.

        绑定关系编号

        :param bind_id: The bind_id of this AclBindApiInfo.
        :type bind_id: str
        """
        self._bind_id = bind_id

    @property
    def group_name(self):
        r"""Gets the group_name of this AclBindApiInfo.

        API分组名称

        :return: The group_name of this AclBindApiInfo.
        :rtype: str
        """
        return self._group_name

    @group_name.setter
    def group_name(self, group_name):
        r"""Sets the group_name of this AclBindApiInfo.

        API分组名称

        :param group_name: The group_name of this AclBindApiInfo.
        :type group_name: str
        """
        self._group_name = group_name

    @property
    def bind_time(self):
        r"""Gets the bind_time of this AclBindApiInfo.

        绑定时间

        :return: The bind_time of this AclBindApiInfo.
        :rtype: datetime
        """
        return self._bind_time

    @bind_time.setter
    def bind_time(self, bind_time):
        r"""Sets the bind_time of this AclBindApiInfo.

        绑定时间

        :param bind_time: The bind_time of this AclBindApiInfo.
        :type bind_time: datetime
        """
        self._bind_time = bind_time

    @property
    def publish_id(self):
        r"""Gets the publish_id of this AclBindApiInfo.

        API发布记录编号

        :return: The publish_id of this AclBindApiInfo.
        :rtype: str
        """
        return self._publish_id

    @publish_id.setter
    def publish_id(self, publish_id):
        r"""Sets the publish_id of this AclBindApiInfo.

        API发布记录编号

        :param publish_id: The publish_id of this AclBindApiInfo.
        :type publish_id: str
        """
        self._publish_id = publish_id

    @property
    def req_method(self):
        r"""Gets the req_method of this AclBindApiInfo.

        API请求方法

        :return: The req_method of this AclBindApiInfo.
        :rtype: str
        """
        return self._req_method

    @req_method.setter
    def req_method(self, req_method):
        r"""Sets the req_method of this AclBindApiInfo.

        API请求方法

        :param req_method: The req_method of this AclBindApiInfo.
        :type req_method: str
        """
        self._req_method = req_method

    @property
    def tags(self):
        r"""Gets the tags of this AclBindApiInfo.

        API绑定的标签，标签配额默认10条，可以联系技术调整。

        :return: The tags of this AclBindApiInfo.
        :rtype: list[str]
        """
        return self._tags

    @tags.setter
    def tags(self, tags):
        r"""Sets the tags of this AclBindApiInfo.

        API绑定的标签，标签配额默认10条，可以联系技术调整。

        :param tags: The tags of this AclBindApiInfo.
        :type tags: list[str]
        """
        self._tags = tags

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AclBindApiInfo):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
