# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class MemberGroupCreateBatch:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'member_groups': 'list[MemberGroupCreate]'
    }

    attribute_map = {
        'member_groups': 'member_groups'
    }

    def __init__(self, member_groups=None):
        r"""MemberGroupCreateBatch

        The model defined in huaweicloud sdk

        :param member_groups: 后端服务器组列表
        :type member_groups: list[:class:`huaweicloudsdkapig.v2.MemberGroupCreate`]
        """
        
        

        self._member_groups = None
        self.discriminator = None

        if member_groups is not None:
            self.member_groups = member_groups

    @property
    def member_groups(self):
        r"""Gets the member_groups of this MemberGroupCreateBatch.

        后端服务器组列表

        :return: The member_groups of this MemberGroupCreateBatch.
        :rtype: list[:class:`huaweicloudsdkapig.v2.MemberGroupCreate`]
        """
        return self._member_groups

    @member_groups.setter
    def member_groups(self, member_groups):
        r"""Sets the member_groups of this MemberGroupCreateBatch.

        后端服务器组列表

        :param member_groups: The member_groups of this MemberGroupCreateBatch.
        :type member_groups: list[:class:`huaweicloudsdkapig.v2.MemberGroupCreate`]
        """
        self._member_groups = member_groups

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, MemberGroupCreateBatch):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
