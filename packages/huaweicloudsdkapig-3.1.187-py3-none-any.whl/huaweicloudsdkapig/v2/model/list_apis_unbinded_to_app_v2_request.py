# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListApisUnbindedToAppV2Request:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'instance_id': 'str',
        'offset': 'int',
        'limit': 'int',
        'app_id': 'str',
        'env_id': 'str',
        'group_id': 'str',
        'api_id': 'str',
        'api_name': 'str',
        'tags': 'str'
    }

    attribute_map = {
        'instance_id': 'instance_id',
        'offset': 'offset',
        'limit': 'limit',
        'app_id': 'app_id',
        'env_id': 'env_id',
        'group_id': 'group_id',
        'api_id': 'api_id',
        'api_name': 'api_name',
        'tags': 'tags'
    }

    def __init__(self, instance_id=None, offset=None, limit=None, app_id=None, env_id=None, group_id=None, api_id=None, api_name=None, tags=None):
        r"""ListApisUnbindedToAppV2Request

        The model defined in huaweicloud sdk

        :param instance_id: 实例ID，在API网关控制台的“实例信息”中获取。
        :type instance_id: str
        :param offset: 偏移量，表示从此偏移量开始查询，偏移量小于0时，自动转换为0
        :type offset: int
        :param limit: 每页显示的条目数量，条目数量小于等于0时，自动转换为20，条目数量大于500时，自动转换为500
        :type limit: int
        :param app_id: 应用id
        :type app_id: str
        :param env_id: 环境id
        :type env_id: str
        :param group_id: API分组编号
        :type group_id: str
        :param api_id: API编号
        :type api_id: str
        :param api_name: API名称
        :type api_name: str
        :param tags: API标签，该参数可指定多个，多个不同的参数值为或关系；不指定或为空时，表示不筛选标签；指定为#no_tags#时，表示筛选无标签API。
        :type tags: str
        """
        
        

        self._instance_id = None
        self._offset = None
        self._limit = None
        self._app_id = None
        self._env_id = None
        self._group_id = None
        self._api_id = None
        self._api_name = None
        self._tags = None
        self.discriminator = None

        self.instance_id = instance_id
        if offset is not None:
            self.offset = offset
        if limit is not None:
            self.limit = limit
        self.app_id = app_id
        self.env_id = env_id
        if group_id is not None:
            self.group_id = group_id
        if api_id is not None:
            self.api_id = api_id
        if api_name is not None:
            self.api_name = api_name
        if tags is not None:
            self.tags = tags

    @property
    def instance_id(self):
        r"""Gets the instance_id of this ListApisUnbindedToAppV2Request.

        实例ID，在API网关控制台的“实例信息”中获取。

        :return: The instance_id of this ListApisUnbindedToAppV2Request.
        :rtype: str
        """
        return self._instance_id

    @instance_id.setter
    def instance_id(self, instance_id):
        r"""Sets the instance_id of this ListApisUnbindedToAppV2Request.

        实例ID，在API网关控制台的“实例信息”中获取。

        :param instance_id: The instance_id of this ListApisUnbindedToAppV2Request.
        :type instance_id: str
        """
        self._instance_id = instance_id

    @property
    def offset(self):
        r"""Gets the offset of this ListApisUnbindedToAppV2Request.

        偏移量，表示从此偏移量开始查询，偏移量小于0时，自动转换为0

        :return: The offset of this ListApisUnbindedToAppV2Request.
        :rtype: int
        """
        return self._offset

    @offset.setter
    def offset(self, offset):
        r"""Sets the offset of this ListApisUnbindedToAppV2Request.

        偏移量，表示从此偏移量开始查询，偏移量小于0时，自动转换为0

        :param offset: The offset of this ListApisUnbindedToAppV2Request.
        :type offset: int
        """
        self._offset = offset

    @property
    def limit(self):
        r"""Gets the limit of this ListApisUnbindedToAppV2Request.

        每页显示的条目数量，条目数量小于等于0时，自动转换为20，条目数量大于500时，自动转换为500

        :return: The limit of this ListApisUnbindedToAppV2Request.
        :rtype: int
        """
        return self._limit

    @limit.setter
    def limit(self, limit):
        r"""Sets the limit of this ListApisUnbindedToAppV2Request.

        每页显示的条目数量，条目数量小于等于0时，自动转换为20，条目数量大于500时，自动转换为500

        :param limit: The limit of this ListApisUnbindedToAppV2Request.
        :type limit: int
        """
        self._limit = limit

    @property
    def app_id(self):
        r"""Gets the app_id of this ListApisUnbindedToAppV2Request.

        应用id

        :return: The app_id of this ListApisUnbindedToAppV2Request.
        :rtype: str
        """
        return self._app_id

    @app_id.setter
    def app_id(self, app_id):
        r"""Sets the app_id of this ListApisUnbindedToAppV2Request.

        应用id

        :param app_id: The app_id of this ListApisUnbindedToAppV2Request.
        :type app_id: str
        """
        self._app_id = app_id

    @property
    def env_id(self):
        r"""Gets the env_id of this ListApisUnbindedToAppV2Request.

        环境id

        :return: The env_id of this ListApisUnbindedToAppV2Request.
        :rtype: str
        """
        return self._env_id

    @env_id.setter
    def env_id(self, env_id):
        r"""Sets the env_id of this ListApisUnbindedToAppV2Request.

        环境id

        :param env_id: The env_id of this ListApisUnbindedToAppV2Request.
        :type env_id: str
        """
        self._env_id = env_id

    @property
    def group_id(self):
        r"""Gets the group_id of this ListApisUnbindedToAppV2Request.

        API分组编号

        :return: The group_id of this ListApisUnbindedToAppV2Request.
        :rtype: str
        """
        return self._group_id

    @group_id.setter
    def group_id(self, group_id):
        r"""Sets the group_id of this ListApisUnbindedToAppV2Request.

        API分组编号

        :param group_id: The group_id of this ListApisUnbindedToAppV2Request.
        :type group_id: str
        """
        self._group_id = group_id

    @property
    def api_id(self):
        r"""Gets the api_id of this ListApisUnbindedToAppV2Request.

        API编号

        :return: The api_id of this ListApisUnbindedToAppV2Request.
        :rtype: str
        """
        return self._api_id

    @api_id.setter
    def api_id(self, api_id):
        r"""Sets the api_id of this ListApisUnbindedToAppV2Request.

        API编号

        :param api_id: The api_id of this ListApisUnbindedToAppV2Request.
        :type api_id: str
        """
        self._api_id = api_id

    @property
    def api_name(self):
        r"""Gets the api_name of this ListApisUnbindedToAppV2Request.

        API名称

        :return: The api_name of this ListApisUnbindedToAppV2Request.
        :rtype: str
        """
        return self._api_name

    @api_name.setter
    def api_name(self, api_name):
        r"""Sets the api_name of this ListApisUnbindedToAppV2Request.

        API名称

        :param api_name: The api_name of this ListApisUnbindedToAppV2Request.
        :type api_name: str
        """
        self._api_name = api_name

    @property
    def tags(self):
        r"""Gets the tags of this ListApisUnbindedToAppV2Request.

        API标签，该参数可指定多个，多个不同的参数值为或关系；不指定或为空时，表示不筛选标签；指定为#no_tags#时，表示筛选无标签API。

        :return: The tags of this ListApisUnbindedToAppV2Request.
        :rtype: str
        """
        return self._tags

    @tags.setter
    def tags(self, tags):
        r"""Sets the tags of this ListApisUnbindedToAppV2Request.

        API标签，该参数可指定多个，多个不同的参数值为或关系；不指定或为空时，表示不筛选标签；指定为#no_tags#时，表示筛选无标签API。

        :param tags: The tags of this ListApisUnbindedToAppV2Request.
        :type tags: str
        """
        self._tags = tags

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListApisUnbindedToAppV2Request):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
