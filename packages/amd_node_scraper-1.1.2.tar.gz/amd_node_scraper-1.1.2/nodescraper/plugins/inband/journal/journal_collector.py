###############################################################################
#
# MIT License
#
# Copyright (c) 2025 Advanced Micro Devices, Inc.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.
#
###############################################################################
import json
from typing import Optional

from pydantic import ValidationError

from nodescraper.base import InBandDataCollector
from nodescraper.enums import EventCategory, EventPriority, ExecutionStatus, OSFamily
from nodescraper.models import TaskResult
from nodescraper.utils import get_exception_details

from .collector_args import JournalCollectorArgs
from .journaldata import JournalData, JournalJsonEntry


class JournalCollector(InBandDataCollector[JournalData, JournalCollectorArgs]):
    """Read journal log via journalctl."""

    SUPPORTED_OS_FAMILY = {OSFamily.LINUX}
    DATA_MODEL = JournalData
    CMD = "journalctl --no-pager --system --output=short-iso"
    CMD_JSON = "journalctl --no-pager --system --output=json"

    def _read_with_journalctl(self, args: Optional[JournalCollectorArgs] = None):
        """Read journal logs using journalctl

        Returns:
            str|None: system journal read
        """

        cmd = self.CMD
        try:
            # safe check for args.boot
            if args is not None and getattr(args, "boot", None):
                cmd = f"{self.CMD} -b {args.boot}"

            res = self._run_sut_cmd(cmd, sudo=True, log_artifact=False, strip=False)

        except ValidationError as val_err:
            self._log_event(
                category=EventCategory.OS,
                description="Exception while running journalctl",
                data=get_exception_details(val_err),
                priority=EventPriority.ERROR,
                console_log=True,
            )
            self.result.message = "Could not read journalctl data"
            self.result.status = ExecutionStatus.ERROR
            return None

        if res.exit_code != 0:
            self._log_event(
                category=EventCategory.OS,
                description="Error reading journalctl",
                data={"command": res.command, "exit_code": res.exit_code},
                priority=EventPriority.ERROR,
                console_log=True,
            )
            self.result.message = "Could not read journalctl data"
            self.result.status = ExecutionStatus.ERROR
            return None

        return res.stdout

    def _read_with_journalctl_json(
        self, args: Optional[JournalCollectorArgs] = None
    ) -> Optional[list[JournalJsonEntry]]:
        """Read journal logs in JSON format using journalctl

        Returns:
            list[JournalJsonEntry]|None: system journal read as JSON entries
        """

        cmd = self.CMD_JSON
        try:
            # safe check for args.boot
            if args is not None and getattr(args, "boot", None):
                cmd = f"{self.CMD_JSON} -b {args.boot}"

            res = self._run_sut_cmd(cmd, sudo=True, log_artifact=False, strip=False)

        except ValidationError as val_err:
            self._log_event(
                category=EventCategory.OS,
                description="Exception while running journalctl JSON",
                data=get_exception_details(val_err),
                priority=EventPriority.ERROR,
                console_log=True,
            )
            return None

        if res.exit_code != 0:
            self._log_event(
                category=EventCategory.OS,
                description="Error reading journalctl JSON",
                data={"command": res.command, "exit_code": res.exit_code},
                priority=EventPriority.ERROR,
                console_log=True,
            )
            return None

        # Parse JSON entries
        json_entries: list[JournalJsonEntry] = []
        for line in res.stdout.splitlines():
            if not line.strip():
                continue
            try:
                entry_dict = json.loads(line)
                json_entries.append(JournalJsonEntry(**entry_dict))
            except (json.JSONDecodeError, ValidationError) as e:
                self._log_event(
                    category=EventCategory.OS,
                    description="Failed to parse journal JSON entry",
                    data={"error": str(e), "line": line[:200]},
                    priority=EventPriority.WARNING,
                    console_log=False,
                )
                continue

        return json_entries

    def collect_data(
        self,
        args: Optional[JournalCollectorArgs] = None,
    ) -> tuple[TaskResult, Optional[JournalData]]:
        """Collect journal logs

        Args:
            args (_type_, optional): Collection args. Defaults to None.

        Returns:
            tuple[TaskResult, Optional[JournalData]]: Tuple of results and data model or none.
        """
        if args is None:
            args = JournalCollectorArgs()

        journal_log = self._read_with_journalctl(args)
        journal_json = self._read_with_journalctl_json(args)

        if journal_log:
            data = JournalData(
                journal_log=journal_log,
                journal_content_json=journal_json if journal_json else [],
            )
            self.result.message = self.result.message or "Journal data collected"
            return self.result, data
        return self.result, None
