from __future__ import annotations

import asyncio
import base64
import io
from collections import defaultdict
from pathlib import Path
from typing import Any

from docling.datamodel.base_models import FormatToExtensions, InputFormat
from loguru import logger

from ..static_visual_format.models import LLMUsageMetrics

# Maps item_id -> saved image path (used to pass between _describe_pictures and _docling_to_pages)
_ImagePathsMap = dict[int, str]


# Formats we use from Docling for general document processing.
# Excluded: XML_USPTO, XML_JATS, XML_XBRL (ambiguous .xml mapping),
# METS_GBS (.tar.gz), JSON_DOCLING (docling-specific JSON, not arbitrary JSON),
# AUDIO (not a document format).
_DOCLING_FORMATS: frozenset[InputFormat] = frozenset(
    {
        InputFormat.PDF,
        InputFormat.DOCX,
        InputFormat.PPTX,
        InputFormat.XLSX,
        InputFormat.CSV,
        InputFormat.HTML,
        InputFormat.IMAGE,
        InputFormat.MD,
        InputFormat.ASCIIDOC,
        InputFormat.VTT,
        InputFormat.LATEX,
    }
)

# Build extension -> InputFormat mapping from Docling's own FormatToExtensions
_EXTENSION_TO_FORMAT: dict[str, InputFormat] = {}
for _fmt in _DOCLING_FORMATS:
    for _ext in FormatToExtensions.get(_fmt, []):
        _EXTENSION_TO_FORMAT[f".{_ext}"] = _fmt

# Also map .txt to MD (Docling maps .txt to XML_USPTO which we excluded)
_EXTENSION_TO_FORMAT[".txt"] = InputFormat.MD

SUPPORTED_EXTENSIONS: frozenset[str] = frozenset(_EXTENSION_TO_FORMAT)

_PICTURE_DESCRIBE_CONCURRENCY = 15

_PICTURE_PROMPT = (
    "Look at this image from a document. "
    "If the image contains informational content such as charts, graphs, tables, "
    "diagrams, schemas, flowcharts, maps, screenshots with data, or formulas — "
    "briefly describe the information shown in 1-3 sentences "
    "(use the same language as the surrounding page text). "
    "Focus on the data and facts presented, not visual style.\n\n"
    "If the image is decorative, a logo, an icon, a photo without data, "
    "or does not contain structured information, "
    "respond with the single word: SKIP"
)


class DoclingReader:
    """Document reader powered by Docling with StandardPdfPipeline for PDF formats."""

    def __init__(
        self,
        image_service=None,
        skip_pictures: bool = False,
        progress_callback=None,
    ) -> None:
        self._image_service = image_service
        self._skip_pictures = skip_pictures
        self._progress_callback = progress_callback
        self._converter = self._build_converter(image_service, skip_pictures)

    @staticmethod
    def _build_converter(image_service, skip_pictures: bool = False):
        from docling.datamodel.layout_model_specs import DOCLING_LAYOUT_EGRET_LARGE
        from docling.datamodel.pipeline_options import (
            LayoutOptions,
            ThreadedPdfPipelineOptions,
        )
        from docling.document_converter import (
            DocumentConverter,
            PdfFormatOption,
        )
        from docling.pipeline.standard_pdf_pipeline import StandardPdfPipeline

        if skip_pictures:
            # Pure Docling without any picture processing (cheapest, text-focused)
            generate_pictures = False
            do_picture_desc = False
        elif image_service is not None:
            # LLM will describe pictures — Docling just extracts images
            generate_pictures = True
            do_picture_desc = False
        else:
            # No LLM, use Docling's built-in VLM for picture descriptions
            generate_pictures = True
            do_picture_desc = True

        pipeline_options = ThreadedPdfPipelineOptions(
            generate_picture_images=generate_pictures,
            do_picture_description=do_picture_desc,
            layout_options=LayoutOptions(
                model_spec=DOCLING_LAYOUT_EGRET_LARGE,
            ),
        )

        logger.debug(
            f"Docling: StandardPdfPipeline, "
            f"generate_picture_images={generate_pictures}, "
            f"do_picture_description={do_picture_desc}, "
            f"layout_model=egret_large"
        )

        converter = DocumentConverter(
            format_options={
                InputFormat.PDF: PdfFormatOption(
                    pipeline_cls=StandardPdfPipeline,
                    pipeline_options=pipeline_options,
                ),
            }
        )
        return converter

    @staticmethod
    def supports(file_path: str) -> bool:
        ext = Path(file_path).suffix.lower()
        return ext in SUPPORTED_EXTENSIONS

    def read(self, file_path: str) -> list[dict[str, Any]]:
        ext = Path(file_path).suffix.lower()
        if ext not in SUPPORTED_EXTENSIONS:
            raise ValueError(
                f"Unsupported file extension: {ext}. "
                f"Supported: {sorted(SUPPORTED_EXTENSIONS)}"
            )

        logger.debug(f"Docling: converting {file_path}")
        result = self._converter.convert(file_path)

        from docling.datamodel.document import ConversionStatus

        if result.status == ConversionStatus.FAILURE:
            errors = (
                "; ".join(str(e) for e in result.errors) if result.errors else "unknown"
            )
            raise RuntimeError(f"Docling conversion failed for {file_path}: {errors}")

        return self._docling_to_pages(result)

    async def aread(
        self, file_path: str, images_dir: str | None = None
    ) -> tuple[list[dict[str, Any]], LLMUsageMetrics]:
        ext = Path(file_path).suffix.lower()
        if ext not in SUPPORTED_EXTENSIONS:
            raise ValueError(
                f"Unsupported file extension: {ext}. "
                f"Supported: {sorted(SUPPORTED_EXTENSIONS)}"
            )

        logger.debug(f"Docling: converting {file_path}")
        if self._progress_callback:
            self._progress_callback(0, 0, "Parsing document...")
        result = await asyncio.to_thread(self._converter.convert, file_path)

        from docling.datamodel.document import ConversionStatus

        if result.status == ConversionStatus.FAILURE:
            errors = (
                "; ".join(str(e) for e in result.errors) if result.errors else "unknown"
            )
            raise RuntimeError(f"Docling conversion failed for {file_path}: {errors}")

        if self._progress_callback:
            self._progress_callback(0, 0, "Parsing complete")

        metrics = LLMUsageMetrics()
        descriptions: dict[int, str] = {}
        image_paths: _ImagePathsMap = {}
        if self._image_service is not None:
            descriptions, metrics, image_paths = await self._describe_pictures(
                result, images_dir=images_dir
            )
        elif images_dir is not None:
            # No LLM, but images_dir requested — still save images
            image_paths = await self._save_pictures(result, images_dir)

        if metrics.total_llm_requests > 0:
            logger.info(
                f"Docling LLM usage for {file_path}: "
                f"{metrics.total_llm_requests} requests, "
                f"{metrics.total_prompt_tokens} prompt tokens, "
                f"{metrics.total_completion_tokens} completion tokens"
            )

        return self._docling_to_pages(result, descriptions, image_paths), metrics

    @staticmethod
    def _extract_image(
        item, document
    ) -> tuple[str | None, int, tuple[int, int], bytes | None]:
        """Extract a picture to base64 PNG (CPU-bound).

        Returns (encoded_b64, page_no, image_size, png_bytes).
        """
        pil_image = item.get_image(document)
        if pil_image is None:
            return None, 1, (0, 0), None
        page_no = 1
        if hasattr(item, "prov") and item.prov:
            page_no = item.prov[0].page_no
        buf = io.BytesIO()
        pil_image.save(buf, format="PNG")
        png_bytes = buf.getvalue()
        encoded = base64.b64encode(png_bytes).decode("utf-8")
        return encoded, page_no, pil_image.size, png_bytes

    @staticmethod
    def _save_image(
        png_bytes: bytes, images_dir: str, page_no: int, pic_index: int
    ) -> str:
        """Save PNG bytes to disk. Returns the filename (not full path)."""
        images_path = Path(images_dir)
        images_path.mkdir(parents=True, exist_ok=True)
        filename = f"page{page_no:04d}_img{pic_index:04d}.png"
        (images_path / filename).write_bytes(png_bytes)
        return filename

    async def _save_pictures(self, result, images_dir: str) -> _ImagePathsMap:
        """Save all pictures to images_dir without LLM description."""
        from docling_core.types.doc import PictureItem

        document = result.document
        image_paths: _ImagePathsMap = {}

        pic_items = [
            (pic_idx, item)
            for pic_idx, (item, _level) in enumerate(
                (it, lv)
                for it, lv in document.iterate_items()
                if isinstance(it, PictureItem)
            )
        ]

        async def save_one(pic_index: int, item) -> None:
            _, page_no, _, png_bytes = await asyncio.to_thread(
                self._extract_image, item, document
            )
            if png_bytes is not None:
                filename = await asyncio.to_thread(
                    self._save_image, png_bytes, images_dir, page_no, pic_index
                )
                image_paths[id(item)] = filename

        await asyncio.gather(*[save_one(idx, item) for idx, item in pic_items])
        return image_paths

    async def _describe_pictures(
        self, result, images_dir: str | None = None
    ) -> tuple[dict[int, str], LLMUsageMetrics, _ImagePathsMap]:
        """Describe pictures via LLM with page text as context. Optionally saves images."""
        from docling_core.types.doc import PictureItem, TextItem

        document = result.document
        semaphore = asyncio.Semaphore(_PICTURE_DESCRIBE_CONCURRENCY)
        descriptions: dict[int, str] = {}
        image_paths: _ImagePathsMap = {}
        metrics = LLMUsageMetrics()
        metrics_lock = asyncio.Lock()
        completed_count = 0

        # Collect text per page for context
        page_texts: dict[int, list[str]] = defaultdict(list)
        for item, _level in document.iterate_items():
            if isinstance(item, TextItem) and item.text and item.text.strip():
                pg = 1
                if hasattr(item, "prov") and item.prov:
                    pg = item.prov[0].page_no
                page_texts[pg].append(item.text)

        # Enumerate only PictureItems for stable per-picture indexing
        pic_items = [
            (pic_idx, item)
            for pic_idx, (item, _level) in enumerate(
                (it, lv)
                for it, lv in document.iterate_items()
                if isinstance(it, PictureItem)
            )
        ]

        total_pics = len(pic_items)

        async def describe_one(item_id: int, pic_index: int, item: PictureItem) -> None:
            nonlocal completed_count

            encoded, page_no, image_size, png_bytes = await asyncio.to_thread(
                self._extract_image, item, document
            )
            if encoded is None:
                async with metrics_lock:
                    completed_count += 1
                    if self._progress_callback:
                        self._progress_callback(
                            completed_count,
                            total_pics,
                            f"Describing images: {completed_count}/{total_pics}",
                        )
                return

            page_text = "\n".join(page_texts.get(page_no, []))
            context = (
                f"The following is the text from the document page "
                f"where this image appears:\n{page_text[:2000]}"
                if page_text.strip()
                else None
            )

            try:
                async with semaphore:
                    analysis_result = await self._image_service.aanalyze_image(
                        encoded, prompt=_PICTURE_PROMPT, context=context
                    )
            except Exception as e:
                logger.error(
                    f"Docling: failed to describe picture on page {page_no}: {e}\n"
                    f"  prompt: {_PICTURE_PROMPT}\n"
                    f"  context: {context if context else 'None'}\n"
                    f"  image_size: {image_size}"
                )
                async with metrics_lock:
                    completed_count += 1
                    if self._progress_callback:
                        self._progress_callback(
                            completed_count,
                            total_pics,
                            f"Describing images: {completed_count}/{total_pics}",
                        )
                return

            async with metrics_lock:
                metrics.add_usage(analysis_result.usage)
                completed_count += 1
                if self._progress_callback:
                    self._progress_callback(
                        completed_count,
                        total_pics,
                        f"Describing images: {completed_count}/{total_pics}",
                    )

            description = analysis_result.content
            if description.strip().upper() == "SKIP":
                logger.debug(f"Docling: skipped decorative picture on page {page_no}")
                return

            # Save image only for non-decorative pictures (LLM did not return SKIP)
            if images_dir is not None and png_bytes is not None:
                saved_filename = await asyncio.to_thread(
                    self._save_image, png_bytes, images_dir, page_no, pic_index
                )
                image_paths[item_id] = saved_filename

            logger.debug(
                f"Docling: described picture on page {page_no} "
                f"({len(description)} chars)"
            )
            descriptions[item_id] = description

        tasks = [describe_one(id(item), pic_idx, item) for pic_idx, item in pic_items]

        if tasks:
            logger.debug(f"Docling: describing {len(tasks)} pictures via LLM")
            await asyncio.gather(*tasks)

        return descriptions, metrics, image_paths

    @staticmethod
    def _format_text_item(item, text: str) -> str:
        """Format a TextItem as Markdown based on its label."""
        from docling_core.types.doc import DocItemLabel, SectionHeaderItem

        label = getattr(item, "label", None)

        if isinstance(item, SectionHeaderItem) or label == DocItemLabel.SECTION_HEADER:
            level = getattr(item, "level", 1)
            # Docling level is 1-based; map to markdown ## (level+1 to leave # for TITLE)
            prefix = "#" * min(level + 1, 6)
            return f"{prefix} {text}"

        if label == DocItemLabel.TITLE:
            return f"# {text}"

        if label == DocItemLabel.LIST_ITEM:
            return f"- {text}"

        if label == DocItemLabel.CODE:
            return f"```\n{text}\n```"

        if label == DocItemLabel.FORMULA:
            return f"$$\n{text}\n$$"

        if label == DocItemLabel.CAPTION:
            return f"*{text}*"

        if label == DocItemLabel.FOOTNOTE:
            return f"[^]: {text}"

        if label == DocItemLabel.REFERENCE:
            return f"> {text}"

        if label in (DocItemLabel.PAGE_HEADER, DocItemLabel.PAGE_FOOTER):
            # Skip page headers/footers — they are noise (page numbers, repeating titles)
            return ""

        # PARAGRAPH, TEXT, and everything else — plain text
        return text

    @staticmethod
    def _docling_to_pages(
        result,
        descriptions: dict[int, str] | None = None,
        image_paths: _ImagePathsMap | None = None,
    ) -> list[dict[str, Any]]:
        """Convert Docling result to a list of page dicts.

        image_paths values are **filenames only** (e.g. "page0001_img0000.png").
        They are stored as-is in page["images"]; the caller is responsible for
        prefixing them with the correct directory (local or S3).
        """
        from docling_core.types.doc import PictureItem, TableItem, TextItem

        if descriptions is None:
            descriptions = {}
        if image_paths is None:
            image_paths = {}

        document = result.document
        page_contents: dict[int, list[str]] = defaultdict(list)
        page_images: dict[int, list[dict[str, str]]] = defaultdict(list)

        for item, _level in document.iterate_items():
            page_no = 1
            if hasattr(item, "prov") and item.prov:
                page_no = item.prov[0].page_no

            if isinstance(item, TableItem):
                try:
                    md_table = item.export_to_markdown(doc=document)
                    if md_table and md_table.strip():
                        page_contents[page_no].append(md_table)
                        continue
                except Exception:
                    pass
                text = getattr(item, "text", None)
                if text:
                    page_contents[page_no].append(text)
            elif isinstance(item, PictureItem):
                item_id = id(item)
                if item_id in image_paths:
                    desc = descriptions.get(item_id, "")
                    page_images[page_no].append({
                        "path": image_paths[item_id],
                        "description": desc,
                    })
                desc = descriptions.get(item_id)
                if desc and desc.strip():
                    page_contents[page_no].append(desc)
                elif (
                    item.meta
                    and hasattr(item.meta, "description")
                    and item.meta.description
                    and item.meta.description.text
                ):
                    page_contents[page_no].append(item.meta.description.text)
                caption = item.caption_text(document)
                if caption and caption.strip():
                    page_contents[page_no].append(f"*{caption}*")
            elif isinstance(item, TextItem):
                if item.text and item.text.strip():
                    formatted = DoclingReader._format_text_item(item, item.text)
                    if formatted:
                        page_contents[page_no].append(formatted)
            else:
                text = getattr(item, "text", None)
                if text and text.strip():
                    page_contents[page_no].append(text)

        if not page_contents and not page_images:
            return [{"page": 1, "type": "Text", "content": ""}]

        all_pages = set(page_contents) | set(page_images)
        pages: list[dict[str, Any]] = []
        for page_no in sorted(all_pages):
            content = "\n\n".join(page_contents[page_no])
            page: dict[str, Any] = {"page": page_no, "type": "Text", "content": content}
            if page_no in page_images:
                page["images"] = page_images[page_no]
            pages.append(page)

        return pages
