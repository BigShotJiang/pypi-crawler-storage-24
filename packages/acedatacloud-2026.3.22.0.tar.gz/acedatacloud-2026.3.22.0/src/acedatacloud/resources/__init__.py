"""Resources package."""
