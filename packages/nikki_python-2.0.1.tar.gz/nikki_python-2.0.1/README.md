# nikkiServiceBase for Python

**Easy-to-use Python client** for connecting your service to the **nikki.build playground** using WebSocket.

---

### What this library offers

- Simple async WebSocket connection
- Automatic handling of `serviceDef.json` + `serviceToken.json`
- Strict validation at startup (fail-fast with clear errors)
- Auto-reconnect (optional)
- Clean callbacks: `onConnect`, `onConnect`, `onError`, `onData`
- Two send methods:
  - `await client.send(...)` → normal send (raises on rate limit)
  - `client.send_nowait(...)` → safe for callbacks (never crashes, ignores rate limit)
- Full size & rate-limit protection (exactly matches platform rules)
- Production-ready, defensive, and very easy to use

---

### Installation

1. **Install the only dependency**:

```bash
pip install websockets

```
Copy the library file into your project as nikki_client.py (or keep it as libBase.py).


Quick Start
```py

import asyncio
import time
from nikki_python.nikki_client import nikkiServiceBase



async def main():

    client = nikkiServiceBase(auto_reconnect=True)

    def onConnect(details):   print(f"✅ CONNECTED → {details}")
    def on_disconnect(details): print(f"❌ DISCONNECTED → {details}")
    def on_error(error):       print(f"⚠️  ERROR → {error}")
    def on_message_handler(data: dict):
        print(f"📨 RECEIVED: {data}")


    client.onConnect = onConnect
    client.onDisconnect = on_disconnect
    client.onError = on_error
    client.onData = on_message_handler

    await client.connect()

    print("📤 Sending 100 test messages (every 2 seconds)...")
    for i in range(100):
        test = {"state" : bool(i %2== 0)}
        try:
            await client.send(test)
            print(f"   Sent #{i+1}/100")
        except Exception as e:
            print(f"   Send failed: {e}")
        await asyncio.sleep(2)

    await asyncio.sleep(30)
    await client.disconnect()
    print("🏁 Test completed.")


if __name__ == "__main__":
    asyncio.run(main())

```

## Configuration Files

> Place these two files in the same folder as your script (or pass base_path):

- serviceDef.json
- serviceToken.json





## Official Website
For full documentation, API reference, and more examples visit:
https://nikki.build