from __future__ import annotations
import asyncio
import json
import os
import time
from typing import Any, Callable, Optional, Dict
from urllib.parse import quote
import logging

try:
    import websockets
    from websockets.protocol import State
except Exception as e:
    raise ImportError("pip install websockets") from e


logger = logging.getLogger("nikki")
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter("[%(asctime)s] %(levelname)s: %(message)s"))
    logger.addHandler(handler)
logger.setLevel(logging.INFO)


def safe_call(cb: Optional[Callable], *args, **kwargs):
    if not cb:
        return
    try:
        cb(*args, **kwargs)
    except Exception:
        logger.exception("Callback crashed (ignored)")


class nikkiServiceBase:
    """
    Simple, clean, defensive Nikki Client
    - Pure async
    - Strict validation at startup
    - Raises clear errors (Python style)
    - NEW: send_nowait() → perfect for callbacks (no task warnings, ignores rate limit)
    """

    def __init__(self, base_path: Optional[str] = None, auto_reconnect: bool = True):
        self.base_path = base_path or os.getcwd()
        self.auto_reconnect = auto_reconnect

        self.ws: Optional[websockets.WebSocketClientProtocol] = None
        self.ws_url: Optional[str] = None
        self._stop = False
        self._rate_limit = 0.0
        self._last_send_time = 0.0

        # Callbacks
        self.onConnect: Optional[Callable[[dict], None]] = None
        self.onDisconnect: Optional[Callable[[dict], None]] = None
        self.onError: Optional[Callable[[dict], None]] = None
        self.onData: Optional[Callable[[Any], None]] = None

        self._serv_details: Dict[str, str] = {}
        self._token_details: Dict[str, str] = {}

        self._load_and_validate_config()

    # ... [same _load_and_validate_config, is_connected, connect, _receive_loop, disconnect as before] ...

    def _load_and_validate_config(self):
        def read_json(name: str) -> dict:
            path = os.path.join(self.base_path, name)
            if not os.path.exists(path):
                raise FileNotFoundError(f"Required file not found: {path}")
            try:
                with open(path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except json.JSONDecodeError as e:
                raise ValueError(f"Invalid JSON in {name}: {e}") from e

        token = read_json("serviceToken.json")
        serv = read_json("serviceDef.json")

        ws_addr = token.get("wsAddr") or token.get("ws_url") or token.get("wsUrl") or token.get("ws")
        if not ws_addr or not (str(ws_addr).startswith("ws://") or str(ws_addr).startswith("wss://")):
            raise ValueError("wsAddr must be a valid ws:// or wss:// URL in serviceToken.json")

        for field in ("secrete", "sessionID"):
            if not token.get(field):
                raise ValueError(f"Missing required field '{field}' in serviceToken.json")

        for field in ("GuID", "servID", "name", "instID", "dispName"):
            if not serv.get(field):
                raise ValueError(f"Missing required field '{field}' in serviceDef.json")

        self._rate_limit = float(token.get("rateLimit", 0))

        self._serv_details = {k: serv.get(k, "") for k in ("GuID", "dispName", "servID", "name", "instID")}
        self._token_details = {"secrete": token["secrete"], "sessionID": token["sessionID"]}

        payload = {"token": token, "servDef": serv}
        encoded = quote(json.dumps(payload, separators=(",", ":")), safe=":/")
        self.ws_url = f"{ws_addr}?token={encoded}"

        logger.info("✅ Config loaded OK ")

    @property
    def is_connected(self) -> bool:
        return self.ws is not None and self.ws.state == State.OPEN

    async def connect(self):
        if self.is_connected:
            return
        logger.info("Connecting...")
        try:
            self.ws = await websockets.connect(self.ws_url, ping_interval=20, ping_timeout=10)
            logger.info("✅ Connected")
            safe_call(self.onConnect, {"url": self.ws_url})
            asyncio.create_task(self._receive_loop())
        except Exception as e:
            logger.error("Connect failed: %s", e)
            safe_call(self.onError, {"error": str(e)})
            if self.auto_reconnect and not self._stop:
                await asyncio.sleep(6)
                await self.connect()
            else:
                raise

    async def _receive_loop(self):
        try:
            async for raw in self.ws:
                try:
                    data = json.loads(raw)
                    if (isinstance(data, dict) and data.get("action") == "sendMessage" and
                        isinstance(data.get("data"), dict) and data["data"].get("data") is not None):
                        safe_call(self.onData, data["data"]["data"])
                    else:
                        safe_call(self.onData, data)
                except Exception:
                    safe_call(self.onData, raw)
        except Exception as e:
            logger.warning("Connection lost: %s", e)
            safe_call(self.onDisconnect, {"reason": str(e)})
            if self.auto_reconnect and not self._stop:
                await asyncio.sleep(6)
                await self.connect()

    async def send(self, data: Any):
        """Normal send - raises on rate limit (for explicit use)"""
        if not self.is_connected:
            raise RuntimeError("Not connected")

        if self._rate_limit > 0 and time.time() - self._last_send_time < self._rate_limit:
            raise RuntimeError(f"Rate limit exceeded. Wait {self._rate_limit} seconds.")

        try:
            user_str = json.dumps(data, separators=(",", ":"))
        except Exception:
            raise ValueError("Data is not JSON serializable")

        if len(user_str) > 500:
            raise ValueError(f"Data too large (>500 bytes)")

        payload = {**self._serv_details, **self._token_details, "data": data}
        out = json.dumps(payload, separators=(",", ":"))
        if len(out) > 3000:
            raise ValueError(f"Final payload too large (>3000 bytes)")

        await self.ws.send(out)
        self._last_send_time = time.time()
        logger.debug("Sent %d bytes", len(out))

    def send_nowait(self, data: Any):
        """
        🔥 NEW: Safe fire-and-forget send
        - Call directly from callbacks (on_message, etc.)
        - Never raises
        - Automatically ignores rate limit
        - No asyncio.create_task needed
        """
        asyncio.create_task(self._send_nowait_internal(data))

    async def _send_nowait_internal(self, data: Any):
        try:
            await self.send(data)
            logger.info("✅ send_nowait succeeded")
        except RuntimeError as e:
            if "Rate limit" in str(e):
                logger.info("⏳ Rate limit hit (ignored in send_nowait)")
            else:
                logger.warning("send_nowait failed: %s", e)
        except Exception as e:
            logger.warning("send_nowait unexpected error: %s", e)

    async def disconnect(self):
        self._stop = True
        if self.ws:
            await self.ws.close()
        logger.info("Disconnected")