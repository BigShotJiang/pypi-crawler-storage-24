"""
This is an abstraction module of the “Semantic AI With Pretrained Integration” algorithm,
used to manage the training, tuning, and inference of language models and submodels from Sapiens Technology®️,
making calls to the Entity which in turn makes requests to Frankenstein.

The Sapiens Technology®️ does not allow the copying, sharing, editing, customization,
or manipulation of this and all its other algorithms by third parties without the company's prior authorization.
Reverse engineering, or public posts and comments that in any way reveal the company's technical concepts,
are also strictly prohibited. Failure to comply with these guidelines will result in legal action taken by our team of lawyers.
"""
from setuptools import setup, find_packages
package_name = 'sapiens_sapi'
version = '1.1.0'
setup(
    name=package_name,
    version=version,
    author='SAPIENS TECHNOLOGY',
    packages=find_packages(),
    install_requires=[
        'semantic-ai-with-pretrained-integration',
        'FRANKENSTEIN-MODEL'
    ],
    url='https://github.com/sapiens-technology/sapiens_sapi',
    license='Proprietary Software'
)
"""
This is an abstraction module of the “Semantic AI With Pretrained Integration” algorithm,
used to manage the training, tuning, and inference of language models and submodels from Sapiens Technology®️,
making calls to the Entity which in turn makes requests to Frankenstein.

The Sapiens Technology®️ does not allow the copying, sharing, editing, customization,
or manipulation of this and all its other algorithms by third parties without the company's prior authorization.
Reverse engineering, or public posts and comments that in any way reveal the company's technical concepts,
are also strictly prohibited. Failure to comply with these guidelines will result in legal action taken by our team of lawyers.
"""
