"""Command handlers for Autobots — shared by both CLI and TUI.

Each command function takes an AuthenticatedClient and keyword args,
and returns a list of strings (output lines).
"""

from typing import Optional

from autobots_client import AuthenticatedClient
from autobots_client.api.actions import (
    list_actions_v1_actions_get,
    get_action_v1_actions_id_get,
)
from autobots_client.api.action_results import (
    list_action_result_v1_action_results_get,
    get_action_result_v1_action_results_id_get,
)
from autobots_client.api.action_graphs import (
    list_action_graphs_v1_action_graphs_get,
    get_action_graph_v1_action_graphs_id_get,
)
from autobots_client.api.action_graphs_results import (
    list_action_graph_result_v1_action_graphs_results_get,
    get_action_graph_result_v1_action_graphs_results_id_get,
)
from autobots_client.types import UNSET


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _fmt_date(dt) -> str:
    if dt is None or isinstance(dt, type(UNSET)):
        return "-"
    try:
        return dt.strftime("%Y-%m-%d %H:%M")
    except Exception:
        return str(dt)


def _val(v) -> str:
    if v is None or isinstance(v, type(UNSET)):
        return ""
    return str(v)


# ---------------------------------------------------------------------------
# actions
# ---------------------------------------------------------------------------

def actions_list(client: AuthenticatedClient, *, name: Optional[str] = None, limit: int = 20, offset: int = 0) -> list[str]:
    """List actions. Returns output lines."""
    resp = list_actions_v1_actions_get.sync_detailed(
        client=client,
        name=name if name else UNSET,
        limit=limit,
        offset=offset,
    )
    if resp.status_code != 200:
        return [f"Error: HTTP {resp.status_code}"]

    result = resp.parsed
    lines = [
        f"Actions ({result.total_count} total, showing {result.offset}-{result.offset + len(result.docs)}):",
        "",
        f"{'ID':<28} {'Name':<30} {'Type':<25} {'Ver':<6} {'Created'}",
        "-" * 105,
    ]
    for doc in result.docs:
        lines.append(
            f"{doc.field_id:<28} {_val(doc.name):<30} {_val(doc.type_.value):<25} "
            f"{_val(doc.version):<6} {_fmt_date(doc.created_at)}"
        )
    return lines


def actions_get(client: AuthenticatedClient, *, id: str) -> list[str]:
    """Get action details. Returns output lines."""
    resp = get_action_v1_actions_id_get.sync_detailed(id=id, client=client)
    if resp.status_code != 200:
        return [f"Error: HTTP {resp.status_code}"]

    doc = resp.parsed
    return [
        f"ID:          {doc.field_id}",
        f"Name:        {doc.name}",
        f"Type:        {doc.type_.value}",
        f"Version:     {_val(doc.version)}",
        f"Description: {_val(doc.description)}",
        f"Published:   {_val(doc.is_published)}",
        f"Saved:       {_val(doc.is_saved)}",
        f"Created:     {_fmt_date(doc.created_at)}",
        f"Updated:     {_fmt_date(doc.updated_at)}",
    ]


# ---------------------------------------------------------------------------
# runs (action results)
# ---------------------------------------------------------------------------

def runs_list(client: AuthenticatedClient, *, action_id: Optional[str] = None, action_name: Optional[str] = None,
              status: Optional[str] = None, limit: int = 20, offset: int = 0) -> list[str]:
    """List action runs. Returns output lines."""
    from autobots_client.models.event_result_status import EventResultStatus

    status_enum = UNSET
    if status:
        try:
            status_enum = EventResultStatus(status.lower())
        except ValueError:
            return [f"Invalid status: {status}. Valid: processing, success, error, stuck, waiting"]

    resp = list_action_result_v1_action_results_get.sync_detailed(
        client=client,
        action_id=action_id if action_id else UNSET,
        action_name=action_name if action_name else UNSET,
        status=status_enum,
        limit=limit,
        offset=offset,
    )
    if resp.status_code != 200:
        return [f"Error: HTTP {resp.status_code}"]

    result = resp.parsed
    lines = [
        f"Action Runs ({result.total_count} total, showing {result.offset}-{result.offset + len(result.docs)}):",
        "",
        f"{'ID':<28} {'Status':<12} {'Name':<30} {'Created':<18} {'Updated'}",
        "-" * 105,
    ]
    for doc in result.docs:
        lines.append(
            f"{doc.field_id:<28} {doc.status.value:<12} {_val(doc.name):<30} "
            f"{_fmt_date(doc.created_at):<18} {_fmt_date(doc.updated_at)}"
        )
    return lines


def runs_get(client: AuthenticatedClient, *, id: str) -> list[str]:
    """Get action run details. Returns output lines."""
    resp = get_action_result_v1_action_results_id_get.sync_detailed(id=id, client=client)
    if resp.status_code != 200:
        return [f"Error: HTTP {resp.status_code}"]

    doc = resp.parsed
    lines = [
        f"ID:          {doc.field_id}",
        f"Status:      {doc.status.value}",
        f"Name:        {_val(doc.name)}",
        f"Type:        {doc.type_.value}",
        f"Saved:       {_val(doc.is_saved)}",
        f"Created:     {_fmt_date(doc.created_at)}",
        f"Updated:     {_fmt_date(doc.updated_at)}",
    ]
    if doc.result and not isinstance(doc.result, type(UNSET)):
        lines += [
            "",
            "Action:",
            f"  Name:    {doc.result.name}",
            f"  Type:    {doc.result.type_.value}",
            f"  ID:      {doc.result.field_id}",
        ]
    return lines


# ---------------------------------------------------------------------------
# graphs (action graphs)
# ---------------------------------------------------------------------------

def graphs_list(client: AuthenticatedClient, *, name: Optional[str] = None, limit: int = 20, offset: int = 0) -> list[str]:
    """List action graphs. Returns output lines."""
    resp = list_action_graphs_v1_action_graphs_get.sync_detailed(
        client=client,
        name=name if name else UNSET,
        limit=limit,
        offset=offset,
    )
    if resp.status_code != 200:
        return [f"Error: HTTP {resp.status_code}"]

    result = resp.parsed
    lines = [
        f"Action Graphs ({result.total_count} total, showing {result.offset}-{result.offset + len(result.docs)}):",
        "",
        f"{'ID':<28} {'Name':<30} {'Ver':<6} {'Published':<10} {'Created'}",
        "-" * 105,
    ]
    for doc in result.docs:
        lines.append(
            f"{doc.field_id:<28} {_val(doc.name):<30} {_val(doc.version):<6} "
            f"{_val(doc.is_published):<10} {_fmt_date(doc.created_at)}"
        )
    return lines


def graphs_get(client: AuthenticatedClient, *, id: str) -> list[str]:
    """Get action graph details. Returns output lines."""
    resp = get_action_graph_v1_action_graphs_id_get.sync_detailed(id=id, client=client)
    if resp.status_code != 200:
        return [f"Error: HTTP {resp.status_code}"]

    doc = resp.parsed
    if hasattr(doc, 'field_id'):
        return [
            f"ID:          {doc.field_id}",
            f"Name:        {_val(getattr(doc, 'name', ''))}",
            f"Version:     {_val(getattr(doc, 'version', ''))}",
            f"Description: {_val(getattr(doc, 'description', ''))}",
            f"Published:   {_val(getattr(doc, 'is_published', ''))}",
            f"Created:     {_fmt_date(getattr(doc, 'created_at', None))}",
            f"Updated:     {_fmt_date(getattr(doc, 'updated_at', None))}",
        ]
    import json
    if hasattr(doc, 'to_dict'):
        return [json.dumps(doc.to_dict(), indent=2, default=str)]
    return [str(doc)]


# ---------------------------------------------------------------------------
# graph-runs (action graph results)
# ---------------------------------------------------------------------------

def graph_runs_list(client: AuthenticatedClient, *, action_graph_id: Optional[str] = None,
                    action_graph_name: Optional[str] = None, status: Optional[str] = None,
                    limit: int = 20, offset: int = 0) -> list[str]:
    """List action graph runs. Returns output lines."""
    from autobots_client.models.event_result_status import EventResultStatus

    status_enum = UNSET
    if status:
        try:
            status_enum = EventResultStatus(status.lower())
        except ValueError:
            return [f"Invalid status: {status}. Valid: processing, success, error, stuck, waiting"]

    resp = list_action_graph_result_v1_action_graphs_results_get.sync_detailed(
        client=client,
        action_graph_id=action_graph_id if action_graph_id else UNSET,
        action_graph_name=action_graph_name if action_graph_name else UNSET,
        status=status_enum,
        limit=limit,
        offset=offset,
    )
    if resp.status_code != 200:
        return [f"Error: HTTP {resp.status_code}"]

    result = resp.parsed
    lines = [
        f"Action Graph Runs ({result.total_count} total, showing {result.offset}-{result.offset + len(result.docs)}):",
        "",
        f"{'ID':<28} {'Status':<12} {'Name':<30} {'Created':<18} {'Updated'}",
        "-" * 105,
    ]
    for doc in result.docs:
        lines.append(
            f"{doc.field_id:<28} {doc.status.value:<12} {_val(doc.name):<30} "
            f"{_fmt_date(doc.created_at):<18} {_fmt_date(doc.updated_at)}"
        )
    return lines


def graph_runs_get(client: AuthenticatedClient, *, id: str) -> list[str]:
    """Get action graph run details. Returns output lines."""
    resp = get_action_graph_result_v1_action_graphs_results_id_get.sync_detailed(id=id, client=client)
    if resp.status_code != 200:
        return [f"Error: HTTP {resp.status_code}"]

    doc = resp.parsed
    lines = [
        f"ID:          {doc.field_id}",
        f"Status:      {doc.status.value}",
        f"Name:        {_val(doc.name)}",
        f"Type:        {doc.type_.value}",
        f"Saved:       {_val(doc.is_saved)}",
        f"Created:     {_fmt_date(doc.created_at)}",
        f"Updated:     {_fmt_date(doc.updated_at)}",
    ]
    if doc.result and not isinstance(doc.result, type(UNSET)):
        lines += [
            "",
            "Action Graph:",
            f"  Name:    {doc.result.name}",
            f"  ID:      {doc.result.field_id}",
        ]
    return lines


# ---------------------------------------------------------------------------
# Command dispatcher — parses "/command args" from TUI input
# ---------------------------------------------------------------------------

HELP_TEXT = """\
Session:
  /use <action_id>      Switch to a different action
  /continue <run_id>    Continue an existing run
  /new                  Start new conversation
  /status               Show current action & run
  /cancel               Cancel active request

Files:
  /upload <path> [...]  Upload file(s), attach to next message
  /files                Show pending file uploads
  /clear-files          Clear pending file uploads

Metadata (persistent across runs):
  /metadata             Show current metadata
  /metadata set <k> <v> Set a metadata field
  /metadata remove <k>  Remove a metadata field
  /metadata clear       Clear all metadata

Runtime:
  /runtime status       Show runtime status
  /runtime start        Start runtime
  /runtime stop         Stop runtime
  /runtime restart      Restart runtime
  /runtime list         List all runtimes
  /runtime logs         Show runtime logs

Query:
  /actions list [--name NAME] [--limit N]
  /actions get <id>
  /runs list [--action-id ID] [--status STATUS] [--limit N]
  /runs get <id>
  /graphs list [--name NAME] [--limit N]
  /graphs get <id>
  /graph-runs list [--graph-id ID] [--status STATUS] [--limit N]
  /graph-runs get <id>

  /help                 Show this help"""


def dispatch(command_str: str, client: AuthenticatedClient) -> list[str]:
    """Parse a /command string and execute it. Returns output lines.

    Args:
        command_str: The full input string starting with "/" (e.g. "/actions list --limit 5")
        client: Authenticated API client
    """
    parts = command_str.strip().split()
    if not parts:
        return [HELP_TEXT]

    # Remove leading "/" from first token
    group = parts[0].lstrip("/").lower()
    sub = parts[1].lower() if len(parts) > 1 else ""
    args = parts[2:]

    def _parse_opts(args: list[str]) -> dict[str, str]:
        """Parse --key value pairs from args list."""
        opts: dict[str, str] = {}
        positional: list[str] = []
        i = 0
        while i < len(args):
            if args[i].startswith("--"):
                key = args[i][2:].replace("-", "_")
                if i + 1 < len(args) and not args[i + 1].startswith("--"):
                    opts[key] = args[i + 1]
                    i += 2
                else:
                    opts[key] = "true"
                    i += 1
            else:
                positional.append(args[i])
                i += 1
        if positional:
            opts["_positional"] = positional
        return opts

    opts = _parse_opts(args)

    def _int(val: str, default: int) -> int:
        try:
            return int(val)
        except (ValueError, TypeError):
            return default

    try:
        if group == "help":
            return [HELP_TEXT]

        elif group == "actions":
            if sub == "list":
                return actions_list(
                    client,
                    name=opts.get("name"),
                    limit=_int(opts.get("limit", "20"), 20),
                    offset=_int(opts.get("offset", "0"), 0),
                )
            elif sub == "get":
                pos = opts.get("_positional", [])
                if not pos:
                    return ["Usage: /actions get <id>"]
                return actions_get(client, id=pos[0])
            else:
                return ["Usage: /actions list | /actions get <id>"]

        elif group == "runs":
            if sub == "list":
                return runs_list(
                    client,
                    action_id=opts.get("action_id"),
                    action_name=opts.get("action_name"),
                    status=opts.get("status"),
                    limit=_int(opts.get("limit", "20"), 20),
                    offset=_int(opts.get("offset", "0"), 0),
                )
            elif sub == "get":
                pos = opts.get("_positional", [])
                if not pos:
                    return ["Usage: /runs get <id>"]
                return runs_get(client, id=pos[0])
            else:
                return ["Usage: /runs list | /runs get <id>"]

        elif group == "graphs":
            if sub == "list":
                return graphs_list(
                    client,
                    name=opts.get("name"),
                    limit=_int(opts.get("limit", "20"), 20),
                    offset=_int(opts.get("offset", "0"), 0),
                )
            elif sub == "get":
                pos = opts.get("_positional", [])
                if not pos:
                    return ["Usage: /graphs get <id>"]
                return graphs_get(client, id=pos[0])
            else:
                return ["Usage: /graphs list | /graphs get <id>"]

        elif group in ("graph-runs", "graph_runs"):
            if sub == "list":
                return graph_runs_list(
                    client,
                    action_graph_id=opts.get("graph_id"),
                    action_graph_name=opts.get("graph_name"),
                    status=opts.get("status"),
                    limit=_int(opts.get("limit", "20"), 20),
                    offset=_int(opts.get("offset", "0"), 0),
                )
            elif sub == "get":
                pos = opts.get("_positional", [])
                if not pos:
                    return ["Usage: /graph-runs get <id>"]
                return graph_runs_get(client, id=pos[0])
            else:
                return ["Usage: /graph-runs list | /graph-runs get <id>"]

        else:
            return [f"Unknown command: /{group}", "", HELP_TEXT]

    except Exception as e:
        return [f"Command error: {e}"]
