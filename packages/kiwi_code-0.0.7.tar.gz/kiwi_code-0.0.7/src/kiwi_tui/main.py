"""Main entry point for Autobots TUI application."""

import collections
import os
import subprocess

from textual.app import App
from textual.binding import Binding
from loguru import logger

from kiwi_cli.logger import setup_logging
from kiwi_cli.config import ConfigManager
from kiwi_cli.client import AutobotsClientWrapper
from kiwi_cli.auth import TokenManager
from kiwi_cli import runtime_manager
from .screens import LoginScreen, DashboardScreen, AutobotsScreen, ActionsScreen, RuntimeLogsScreen


class AutobotsTUI(App):
    """A modern Textual app for managing Autobots."""

    CSS = """
    Screen {
        background: $surface;
    }

    Header {
        background: #006666;
        color: #00ffff;
    }

    Footer {
        background: #006666;
    }

    Footer > .footer--key {
        background: #008888;
        color: #00ffff;
    }
    """

    TITLE = "Kiwi Code"
    SUB_TITLE = ""

    SCREENS = {
        "login": LoginScreen,
        "dashboard": DashboardScreen,
        "autobots": AutobotsScreen,
        "actions": ActionsScreen,
        "runtime_logs": RuntimeLogsScreen,
    }

    BINDINGS = [
        Binding("ctrl+c", "quit", "Quit", show=True),
        Binding("ctrl+d", "toggle_dark", "Toggle Dark Mode", show=False),
        Binding("ctrl+r", "runtime_logs", "Runtime Logs", show=True),
        Binding("ctrl+k", "toggle_runtime", "Stop/Start Runtime", show=True),
        Binding("ctrl+l", "logout", "Logout", show=False),
    ]

    # Map backend HTTP URLs to kiwi connect server presets
    _KIWI_SERVER_MAP = {
        "https://api.meetkiwi.ai": "app",
        "https://dev.api.myautobots.com": "dev",
        "http://localhost:8000": "local",
    }

    # Max lines to keep in the runtime log buffer
    _KIWI_LOG_BUFFER_SIZE = 5000

    def __init__(self, config_manager: ConfigManager | None = None, token_manager: TokenManager | None = None):
        """Initialize Autobots TUI app.

        Args:
            config_manager: Configuration manager instance
            token_manager: Token manager instance
        """
        super().__init__()
        self.config_manager = config_manager or ConfigManager()
        self.config = self.config_manager.config

        self._kiwi_token = None  # Set after auth for kiwi CLI session
        self._kiwi_pid = None  # PID of the runtime process
        self._log_fp = None  # File pointer for tailing runtime log
        self._kiwi_log_lines = collections.deque(maxlen=self._KIWI_LOG_BUFFER_SIZE)

        # Initialize token manager
        self.token_manager = token_manager or TokenManager()

        # Check for existing tokens
        tokens = self.token_manager.load_tokens()
        access_token = None

        if tokens:
            # Check if token needs refresh
            if tokens.is_expired():
                logger.info("Access token expired, attempting refresh")
                # Try to refresh token
                temp_client = AutobotsClientWrapper(base_url=self.config.backend_url)
                success, new_tokens, message = temp_client.refresh_token(tokens.refresh_token)

                if success and new_tokens:
                    logger.info("Token refreshed successfully")
                    self.token_manager.save_tokens(new_tokens)
                    access_token = new_tokens.access_token
                else:
                    logger.warning(f"Token refresh failed: {message}")
                    self.token_manager.clear_tokens()
            else:
                logger.info("Valid access token found")
                access_token = tokens.access_token

        # Share token with kiwi CLI session
        self._kiwi_token = access_token

        # Initialize autobots client
        self.autobots_client = AutobotsClientWrapper(
            base_url=self.config.backend_url,
            access_token=access_token,
            api_key=self.config.api_key,
        )

    def on_mount(self) -> None:
        """Called when app is mounted."""
        logger.info("Autobots TUI on_mount called")
        logger.info(f"Backend URL: {self.config.backend_url}")

        # Set theme
        self.dark = self.config.theme == "dark"

        # Check if user is authenticated
        if self.token_manager.is_authenticated():
            logger.info("User is authenticated, showing dashboard")
            self._start_kiwi_session()
            self._start_token_refresh()
            try:
                self.switch_screen("dashboard")
            except IndexError:
                self.push_screen("dashboard")
        else:
            logger.info("User not authenticated, showing login screen")
            try:
                self.switch_screen("login")
            except IndexError:
                self.push_screen("login")

    @property
    def runtime_log_cmd(self) -> str:
        """Derive the kiwi connect command from the configured backend_url."""
        # Allow env var override
        override = os.getenv("KIWI_CODE_RUNTIME_LOG_CMD")
        if override:
            return override

        import sys
        python = sys.executable

        backend_url = self.config.backend_url.rstrip("/")
        server = self._KIWI_SERVER_MAP.get(backend_url)
        if server:
            cmd = f"{python} -m kiwi_runtime connect --server {server}"
        else:
            # Custom URL — convert http(s) to ws(s)
            ws_url = backend_url.replace("https://", "wss://").replace("http://", "ws://")
            cmd = f"{python} -m kiwi_runtime connect --server {ws_url}"

        return cmd

    # ------------------------------------------------------------------
    # Persistent kiwi runtime (per working directory, survives TUI restarts)
    # ------------------------------------------------------------------

    def _start_kiwi_session(self) -> None:
        """Start a new kiwi-runtime for this directory, or attach if already running."""
        existing_pid = runtime_manager.get_running_pid()
        if existing_pid:
            logger.info(f"Kiwi runtime already running (PID {existing_pid})")
            self._kiwi_pid = existing_pid
            self._start_log_tail()
            return

        cmd = self.runtime_log_cmd
        if not cmd:
            return

        logger.info(f"Starting kiwi runtime: {cmd}")
        try:
            env = os.environ.copy()
            env["PYTHONUNBUFFERED"] = "1"

            token = self._kiwi_token
            if token:
                env["KIWI_AUTH_TOKEN"] = token

            rt_log_path = runtime_manager.log_path()
            log_fp = open(rt_log_path, "a")

            proc = subprocess.Popen(
                cmd,
                shell=True,
                stdin=subprocess.DEVNULL,
                stdout=log_fp,
                stderr=subprocess.STDOUT,
                start_new_session=True,
                env=env,
            )
            log_fp.close()  # Child inherited the fd via fork

            runtime_manager.save_pid(proc.pid)
            self._kiwi_pid = proc.pid

            self._start_log_tail()
            logger.info(f"Kiwi runtime started (PID {proc.pid})")
        except Exception as e:
            logger.error(f"Failed to start kiwi runtime: {e}")

    def _start_log_tail(self) -> None:
        """Open the runtime log file for tailing."""
        if self._log_fp is not None:
            return  # Already tailing

        rt_log_path = runtime_manager.log_path()
        if not rt_log_path.exists():
            return

        try:
            self._log_fp = open(rt_log_path, "r", encoding="utf-8", errors="replace")
            # Seek near end so we don't replay the entire history
            size = rt_log_path.stat().st_size
            if size > 65536:
                self._log_fp.seek(size - 65536)
            self.set_interval(0.1, self._drain_kiwi_output)
            logger.info("Started tailing runtime log")
        except OSError as e:
            logger.error(f"Failed to tail runtime log: {e}")

    def _drain_kiwi_output(self) -> None:
        """Read new lines from the runtime log file and buffer them."""
        fp = self._log_fp
        if fp is None:
            return

        chunk = fp.read()
        if not chunk:
            # No new output — check if runtime is still alive
            if self._kiwi_pid:
                try:
                    os.kill(self._kiwi_pid, 0)
                except ProcessLookupError:
                    logger.info("Kiwi runtime exited, restarting...")
                    self._kiwi_pid = None
                    self._close_log_tail()
                    self._start_kiwi_session()
            return

        for line in chunk.splitlines():
            self._kiwi_log_lines.append(line)

    def _close_log_tail(self) -> None:
        """Close the log file we are tailing (does NOT stop the runtime)."""
        fp = self._log_fp
        if fp:
            try:
                fp.close()
            except OSError:
                pass
            self._log_fp = None

    def _stop_runtime(self) -> None:
        """Explicitly stop the kiwi-runtime for the current directory."""
        # Drain any remaining output before closing
        self._drain_kiwi_output()
        runtime_manager.stop_runtime()
        self._kiwi_pid = None
        self._close_log_tail()
        self._kiwi_log_lines.append("--- Runtime disconnected ---")

    # ------------------------------------------------------------------
    # Periodic token refresh
    # ------------------------------------------------------------------

    def _start_token_refresh(self) -> None:
        """Schedule periodic token refresh (every `refresh_interval` minutes)."""
        interval_min = self.config.refresh_interval  # default 5
        logger.info(f"Token refresh scheduled every {interval_min} minutes")
        self.set_interval(interval_min * 60, self._refresh_token_if_needed)
        # Write current tokens to shared files so runtime can read them
        if self._kiwi_token:
            runtime_manager.save_token(self._kiwi_token)
        tokens = self.token_manager.load_tokens()
        if tokens and tokens.refresh_token:
            runtime_manager.save_refresh_token(tokens.refresh_token)

    def _refresh_token_if_needed(self) -> None:
        """Check token expiry and refresh if needed."""
        tokens = self.token_manager.load_tokens()
        if not tokens:
            logger.debug("No tokens to refresh")
            return

        if not tokens.is_expired():
            logger.debug("Token still valid, skipping refresh")
            return

        logger.info("Token expired or near expiry, refreshing...")
        success, new_tokens, message = self.autobots_client.refresh_token(
            tokens.refresh_token
        )

        if success and new_tokens:
            logger.info("Token refreshed successfully")
            # Save to disk
            self.token_manager.save_tokens(new_tokens)
            # Update TUI client
            self.autobots_client.update_token(new_tokens.access_token)
            # Update shared state
            self._kiwi_token = new_tokens.access_token
            # Write to runtime directory so the runtime process can pick it up
            runtime_manager.save_token(new_tokens.access_token)
            if new_tokens.refresh_token:
                runtime_manager.save_refresh_token(new_tokens.refresh_token)
        else:
            logger.error(f"Token refresh failed: {message}")

    # ------------------------------------------------------------------

    def action_toggle_runtime(self) -> None:
        """Toggle the kiwi-runtime: stop if running, start if stopped."""
        if self._kiwi_pid:
            self._stop_runtime()
            logger.info("Runtime stopped by user")
            self.notify("Runtime stopped (Ctrl+K to start)", severity="information")
        else:
            self._start_kiwi_session()
            if self._kiwi_pid:
                logger.info("Runtime started by user")
                self.notify("Runtime started", severity="information")
            else:
                self.notify("Failed to start runtime", severity="error")

    def action_restart_runtime(self) -> None:
        """Restart the kiwi-runtime for the current directory."""
        if self._kiwi_pid:
            self._stop_runtime()
            logger.info("Runtime stopped for restart")
        self._start_kiwi_session()
        if self._kiwi_pid:
            logger.info("Runtime restarted by user")
            self.notify("Runtime restarted", severity="information")
        else:
            self.notify("Failed to restart runtime", severity="error")

    def action_runtime_logs(self) -> None:
        """Show the runtime log stream."""
        self.push_screen("runtime_logs")

    def action_toggle_dark(self) -> None:
        """Toggle dark mode."""
        self.dark = not self.dark
        theme = "dark" if self.dark else "light"
        self.config_manager.update(theme=theme)
        logger.info(f"Theme changed to {theme}")
        self.notify(f"Theme: {theme}", severity="information")

    def action_logout(self) -> None:
        """Logout user and return to login screen."""
        logger.info("User logout requested")

        # Detach from runtime logs — do NOT stop the runtime process
        self._close_log_tail()
        self._kiwi_pid = None

        # Clear tokens
        self.token_manager.clear_tokens()

        # Reset client to unauthenticated
        self.autobots_client = AutobotsClientWrapper(
            base_url=self.config.backend_url,
        )

        # Switch to login screen
        self.switch_screen("login")
        self.notify("Logged out successfully", severity="information")

    def action_quit(self) -> None:
        """Quit the application."""
        logger.info("Autobots TUI shutting down")
        # Detach from runtime logs — do NOT stop the runtime process
        self._close_log_tail()
        # Close autobots client connection
        if hasattr(self, 'autobots_client'):
            self.autobots_client.close()
        self.exit()


def _run_tui():
    """Run the TUI in the terminal."""
    config_manager = ConfigManager()
    config = config_manager.load()
    setup_logging(log_level=config.log_level)

    logger.info("=" * 60)
    logger.info("Starting Autobots TUI")
    logger.info("=" * 60)

    app = AutobotsTUI(config_manager=config_manager)
    app.run()

    logger.info("Autobots TUI terminated")


def _serve_tui(port: int = 8566):
    """Serve the TUI in the browser via textual serve."""
    import sys
    from textual_serve.server import Server

    server = Server(f"{sys.executable} -m kiwi_tui.main", port=port)
    server.serve()


def main():
    """Entry point for the kiwi command."""
    import argparse

    parser = argparse.ArgumentParser(prog="kiwi", description="Kiwi Code TUI")
    subparsers = parser.add_subparsers(dest="command")

    serve_parser = subparsers.add_parser("serve", help="Serve the TUI in the browser")
    serve_parser.add_argument(
        "--port", "-p", type=int, default=8566, help="Port to serve on (default: 8566)"
    )

    args = parser.parse_args()

    if args.command == "serve":
        _serve_tui(port=args.port)
    else:
        _run_tui()


if __name__ == "__main__":
    main()
