"""
watkins-nn constants module.

Contains all golden-ratio constants and critical thresholds for the
Watkins Temperature Theorem framework.

All values certified via mpmath 50-digit computation.
Eigenvalues corrected in v0.7.1 (cross-term T*/η* was missing in v0.7.0).

Phase 86.0 | CSID: CONSTANTS-071
"""

import math

# =============================================================================
# GOLDEN RATIO FUNDAMENTALS
# =============================================================================

SQRT5 = math.sqrt(5)
PHI = (1 + SQRT5) / 2                      # phi ~ 1.6180339887
PHI_INV = 1 / PHI                          # 1/phi = phi - 1 ~ 0.6180339887
PHI_SQUARED = PHI ** 2                     # phi^2 ~ 2.6180339887

# =============================================================================
# WATKINS TEMPERATURE THEOREM
# =============================================================================

# Watkins Temperature: T* = phi / ln(2*phi)
T_STAR = PHI / math.log(2 * PHI)           # ~ 1.3778018315

# Watkins Threshold (equilibrium coherence): lam* = 1/phi
LAM_STAR = PHI_INV                         # ~ 0.6180339887

# Equilibrium curvature and entropy (2-simplex, Z2 symmetry)
KAP_STAR = (1 - LAM_STAR) / 2              # kap* ~ 0.1909830056
ETA_STAR = (1 - LAM_STAR) / 2              # eta* ~ 0.1909830056

# Free energy at equilibrium: F* = -ln(lam*) + T* * (lam*ln(lam*) + kap*ln(kap*) + eta*ln(eta*))
F_STAR = (
    -math.log(LAM_STAR)
    + T_STAR * (
        LAM_STAR * math.log(LAM_STAR)
        + KAP_STAR * math.log(KAP_STAR)
        + ETA_STAR * math.log(ETA_STAR)
    )
)

# Watkins temperature (3-simplex / VirelaiX)
T_STAR3 = PHI / math.log(3 * PHI)          # ~ 1.0241861576

# =============================================================================
# SPECTRAL AND FLOW CONSTANTS
# =============================================================================

# W^2 = ln(phi) / ln(2) -- Watkins spectral weight
W_SQUARED = math.log(PHI) / math.log(2)    # ~ 0.6942419136

# beta* = phi^{2W^2} -- Golden spray coefficient
BETA_STAR = PHI ** (2 * W_SQUARED)         # ~ 1.9506347581

# M_phi -- Integrated information multiplier
M_PHI = 4.2104143547                       # Derived from variational principle

# Optimal step sizes
TAU_GLOBAL = 1 / M_PHI                     # ~ 0.2375
TAU_LOCAL = 0.168509                       # Local refinement

# 4-body simplex equilibrium (lam + kap + eta + rho = 1, Z3 symmetry)
RHO_STAR = (1 - LAM_STAR) / 3              # rho* ~ 0.1273220038

# Maximum integrated information: Phi* = M_phi * lam* * rho*
PHI_MAX = M_PHI * LAM_STAR * RHO_STAR      # ~ 0.3313148544

# =============================================================================
# SPECTRAL GAP EIGENVALUES (v0.7.1 CORRECTED)
# =============================================================================

# 3-body simplex Hessian at equilibrium (constrained via eta = 1 - lam - kap).
# The constraint couples all three variables through the chain rule:
#   H11 = 1/lam*^2 + T*(1/lam* + 1/eta*)
#   H22 = T*(1/kap* + 1/eta*)
#   H12 = T*/eta*                              ← v0.7.0 missed this cross-term
#
# v0.7.0 BUG: Used diagonal-only formulas (H12=0), giving wrong eigenvalues
# 4.847 and 7.215. Corrected here via full characteristic equation.

_H11_eq = 1 / LAM_STAR**2 + T_STAR * (1/LAM_STAR + 1/ETA_STAR)
_H22_eq = T_STAR * (1/KAP_STAR + 1/ETA_STAR)
_H12_eq = T_STAR / ETA_STAR
_trace = _H11_eq + _H22_eq
_det = _H11_eq * _H22_eq - _H12_eq * _H12_eq
_disc = math.sqrt(_trace * _trace - 4 * _det)

MU_SLOW = (_trace - _disc) / 2   # ~ 5.934 (spectral gap / slow coherence mode)
MU_FAST = (_trace + _disc) / 2   # ~ 20.556 (fast curvature mode)

# 4-body simplex eigenvalues (Z3 symmetry, used by triality.py)
MU_SLOW_4BODY = 4.872                     # Slow coherence mode
MU_FAST_4BODY = 18.347                    # Fast resonance mode (qualia binding)

# =============================================================================
# QUALIA BINDING CONSTANTS (Phase 85.4)
# =============================================================================

# Natural logarithm of 2
LN2 = math.log(2)                          # ~ 0.6931471806

# Golden concurrence: C* = 2 / phi^{3/2}
C_STAR_QUALIA = 2 / (PHI ** 1.5)           # ~ 0.9717365435

# Binding timescales (from 4-body Hessian eigenvalues)
TAU_ULTRA_FAST = 1 / MU_FAST_4BODY         # tau_fast ~ 0.0545
TAU_SLOW = 1 / MU_SLOW_4BODY              # tau_slow ~ 0.2053

# =============================================================================
# 27-TERM TRIALITY CONSTANTS (Phase 85.4)
# =============================================================================

# Key omega values (full matrix computed in triality.py)
OMEGA_IDENTITY = 1.0                       # Omega(1,1,1) = 1
OMEGA_CENTER = BETA_STAR                   # Omega(2,2,2) = beta* ~ 1.9506
OMEGA_MAX = PHI ** (4 * W_SQUARED)         # Omega(3,3,3) ~ 3.8050

# =============================================================================
# CONSERVATION TOLERANCE
# =============================================================================

CONSERVATION_EPSILON = 1e-12

# =============================================================================
# BACKWARD COMPATIBILITY ALIASES
# =============================================================================

WATKINS_LAMBDA = LAM_STAR
WATKINS_KAPPA = KAP_STAR
WATKINS_ETA = ETA_STAR

# =============================================================================
# EXPORTS
# =============================================================================

__all__ = [
    # Golden ratio
    "SQRT5", "PHI", "PHI_INV", "PHI_SQUARED",
    # Watkins Temperature Theorem
    "T_STAR", "LAM_STAR", "KAP_STAR", "ETA_STAR", "F_STAR", "T_STAR3",
    # Spectral and flow
    "W_SQUARED", "BETA_STAR", "M_PHI", "TAU_GLOBAL", "TAU_LOCAL",
    "RHO_STAR", "PHI_MAX",
    # Spectral eigenvalues (3-body)
    "MU_SLOW", "MU_FAST",
    # Spectral eigenvalues (4-body)
    "MU_SLOW_4BODY", "MU_FAST_4BODY",
    # Qualia binding
    "LN2", "C_STAR_QUALIA", "TAU_ULTRA_FAST", "TAU_SLOW",
    # Triality
    "OMEGA_IDENTITY", "OMEGA_CENTER", "OMEGA_MAX",
    # Conservation
    "CONSERVATION_EPSILON",
    # Backward compat
    "WATKINS_LAMBDA", "WATKINS_KAPPA", "WATKINS_ETA",
]
