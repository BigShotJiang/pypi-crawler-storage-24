# mcp-zentao

禅道项目管理 MCP Server，支持通过 AI 助手直接管理禅道任务。

## 功能

- 创建任务（支持自动完成）
- 编辑/更新任务
- 删除任务
- 查询任务列表
- 查看任务详情
- 记录工时
- 生成 6R 报表

## 安装使用

### 方式一：uvx 直接运行（推荐）

在 MCP 客户端配置中添加：

```json
{
  "mcpServers": {
    "zentao": {
      "command": "uvx",
      "args": ["mcp-zentao"],
      "env": {
        "ZENTAO_HOST": "https://zentao.example.com",
        "ZENTAO_ACCOUNT": "admin",
        "ZENTAO_PASSWORD": "your-password",
        "ZENTAO_DEFAULT_EXECUTION_NAME": "运维",
        "ZENTAO_DEFAULT_ASSIGNEE": "admin"
      }
    }
  }
}
```

### 方式二：pip 安装

```bash
pip install mcp-zentao
mcp-zentao
```

### 方式三：从源码运行

```bash
git clone <repo-url>
cd mcp-servers/zentao
pip install -e .
mcp-zentao
```

## 环境变量

| 变量 | 必填 | 说明 |
|------|------|------|
| `ZENTAO_HOST` | 是 | 禅道地址，如 `https://zentao.example.com` |
| `ZENTAO_ACCOUNT` | 是 | 登录账号 |
| `ZENTAO_PASSWORD` | 是 | 登录密码 |
| `ZENTAO_DEFAULT_EXECUTION_NAME` | 是 | 默认执行名称 |
| `ZENTAO_DEFAULT_ASSIGNEE` | 否 | 默认指派人，不填则使用登录账号 |
| `ZENTAO_DEFAULT_TASK_TYPE` | 否 | 默认任务类型，默认 `devel` |
