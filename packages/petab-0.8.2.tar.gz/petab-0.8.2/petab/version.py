"""PEtab library version"""

__version__ = "0.8.2"
