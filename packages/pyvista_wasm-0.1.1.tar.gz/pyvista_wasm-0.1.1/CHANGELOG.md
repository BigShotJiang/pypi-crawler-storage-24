# Changelog

## [0.1.1](https://github.com/tkoyama010/pyvista-wasm/compare/pyvista-wasm-v0.1.0...pyvista-wasm-v0.1.1) (2026-03-25)

### Bug Fixes

- render mesh PolyData correctly in VTK.wasm ([#25](https://github.com/tkoyama010/pyvista-wasm/issues/25)) ([14a0ca3](https://github.com/tkoyama010/pyvista-wasm/commit/14a0ca391001a7c34d4a8a8c61165e7319da1c5a))

### Documentation

- add docs folder to satisfy PY004 requirement ([#27](https://github.com/tkoyama010/pyvista-wasm/issues/27)) ([9906767](https://github.com/tkoyama010/pyvista-wasm/commit/99067674fb17fb60b812fb8607ef1bfad26050ef))
- add PyPI badge to Install section ([#24](https://github.com/tkoyama010/pyvista-wasm/issues/24)) ([8e28c82](https://github.com/tkoyama010/pyvista-wasm/commit/8e28c82226ac902a26782744d7b52d8519792fd6))

### Continuous Integration

- add concurrency group to auto-cancel redundant runs (GH102) ([#28](https://github.com/tkoyama010/pyvista-wasm/issues/28)) ([3e82392](https://github.com/tkoyama010/pyvista-wasm/commit/3e82392622e19eca6075a9f515258f1f8000bb59))
- add Renovate for automated VTK.wasm CDN version updates ([#21](https://github.com/tkoyama010/pyvista-wasm/issues/21)) ([a0cec82](https://github.com/tkoyama010/pyvista-wasm/commit/a0cec8244ad6d62cb48db760fd031d920b44f75f))
- add workflow to update uv.lock on release-please PRs ([#30](https://github.com/tkoyama010/pyvista-wasm/issues/30)) ([39af99b](https://github.com/tkoyama010/pyvista-wasm/commit/39af99bcf4fefd8f0b5ba76db303b2604f4da61f))

## 0.1.0 (2026-03-25)

### Documentation

- add contributing guide ([#14](https://github.com/tkoyama010/pyvista-wasm/issues/14)) ([37737f7](https://github.com/tkoyama010/pyvista-wasm/commit/37737f7764eb7e920d201db45b138ba358404dce)), closes [#8](https://github.com/tkoyama010/pyvista-wasm/issues/8)
- add GitHub Sponsors funding configuration ([#22](https://github.com/tkoyama010/pyvista-wasm/issues/22)) ([a4f2fbb](https://github.com/tkoyama010/pyvista-wasm/commit/a4f2fbbb5aaae7c29cc75f62e84508879de8136c))
- add issue templates for bug reports, features, and documentation ([#12](https://github.com/tkoyama010/pyvista-wasm/issues/12)) ([1eab65d](https://github.com/tkoyama010/pyvista-wasm/commit/1eab65d2c07babbf7de3e41bec42efce4a8a43cc)), closes [#6](https://github.com/tkoyama010/pyvista-wasm/issues/6)
- add pull request template and code of conduct ([#13](https://github.com/tkoyama010/pyvista-wasm/issues/13)) ([853757b](https://github.com/tkoyama010/pyvista-wasm/commit/853757b97f94caaefeb4731a1560c46152253ad4)), closes [#7](https://github.com/tkoyama010/pyvista-wasm/issues/7)

### Continuous Integration

- add Dependabot for GitHub Actions and npm dependency updates ([#20](https://github.com/tkoyama010/pyvista-wasm/issues/20)) ([63d43ea](https://github.com/tkoyama010/pyvista-wasm/commit/63d43ea6970290f427435fa9429db69186cdddba))
- add nightly tests workflow (SPEC-0004) ([#11](https://github.com/tkoyama010/pyvista-wasm/issues/11)) ([186ab1e](https://github.com/tkoyama010/pyvista-wasm/commit/186ab1e163e11eabdb3190996b7dccbf2479fe29)), closes [#5](https://github.com/tkoyama010/pyvista-wasm/issues/5)
- add release-please workflow for automated releases ([#10](https://github.com/tkoyama010/pyvista-wasm/issues/10)) ([9fb1600](https://github.com/tkoyama010/pyvista-wasm/commit/9fb160083b0ac21f2d4e53c08fcb25bda30b8718))
