# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class TK_StatusChipToken:
    border_radius: float
    padding_horizontal_sm: float
    padding_vertical_sm: float
    padding_horizontal_md: float
    padding_vertical_md: float
    padding_horizontal_lg: float
    padding_vertical_lg: float
    text_size_sm: float
    text_size_md: float
    text_size_lg: float
    icon_size_sm: float
    icon_size_md: float
    icon_size_lg: float
    dot_size: float
    spacing: float
    running_bgcolor: str
    running_text_color: str
    running_dot_color: str
    done_bgcolor: str
    done_text_color: str
    done_icon_color: str
    failed_bgcolor: str
    failed_text_color: str
    failed_icon_color: str
    pending_bgcolor: str
    pending_text_color: str
    pending_icon_color: str
    warning_bgcolor: str
    warning_text_color: str
    warning_icon_color: str
    info_bgcolor: str
    info_text_color: str
    info_icon_color: str


class TK_StatusChipTokens:
    default = TK_StatusChipToken(
        border_radius=100,
        padding_horizontal_sm=8,
        padding_vertical_sm=3,
        padding_horizontal_md=12,
        padding_vertical_md=5,
        padding_horizontal_lg=16,
        padding_vertical_lg=8,
        text_size_sm=11,
        text_size_md=12,
        text_size_lg=13,
        icon_size_sm=12,
        icon_size_md=14,
        icon_size_lg=16,
        dot_size=8,
        spacing=6,
        running_bgcolor="#E3F2FD",
        running_text_color="#1565C0",
        running_dot_color="#1565C0",
        done_bgcolor="#F6FBF4",
        done_text_color="#386A20",
        done_icon_color="#386A20",
        failed_bgcolor="#FFF8F7",
        failed_text_color="#B3261E",
        failed_icon_color="#B3261E",
        pending_bgcolor="#F7F2FA",
        pending_text_color="#49454F",
        pending_icon_color="#79747E",
        warning_bgcolor="#FFF8E1",
        warning_text_color="#7D5700",
        warning_icon_color="#7D5700",
        info_bgcolor="#E8DEF8",
        info_text_color="#4F378B",
        info_icon_color="#4F378B",
    )

    dark = TK_StatusChipToken(
        border_radius=100,
        padding_horizontal_sm=8,
        padding_vertical_sm=3,
        padding_horizontal_md=12,
        padding_vertical_md=5,
        padding_horizontal_lg=16,
        padding_vertical_lg=8,
        text_size_sm=11,
        text_size_md=12,
        text_size_lg=13,
        icon_size_sm=12,
        icon_size_md=14,
        icon_size_lg=16,
        dot_size=8,
        spacing=6,
        running_bgcolor="#0D2137",
        running_text_color="#64B5F6",
        running_dot_color="#64B5F6",
        done_bgcolor="#0D2016",
        done_text_color="#6DD58C",
        done_icon_color="#6DD58C",
        failed_bgcolor="#2D1210",
        failed_text_color="#F2B8B5",
        failed_icon_color="#F2B8B5",
        pending_bgcolor="#2B2930",
        pending_text_color="#CAC4D0",
        pending_icon_color="#938F99",
        warning_bgcolor="#1E1600",
        warning_text_color="#FFD54F",
        warning_icon_color="#FFD54F",
        info_bgcolor="#2D2248",
        info_text_color="#D0BCFF",
        info_icon_color="#D0BCFF",
    )
