# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class TK_ToastToken:
    border_radius: float
    padding_horizontal: float
    padding_vertical: float
    min_width: float
    shadow_blur: float
    shadow_color: str
    title_size: float
    title_weight: str
    message_size: float
    icon_size: float
    close_icon_size: float
    spacing: float
    info_bgcolor: str
    info_border_color: str
    info_icon_color: str
    info_title_color: str
    info_text_color: str
    success_bgcolor: str
    success_border_color: str
    success_icon_color: str
    success_title_color: str
    success_text_color: str
    warning_bgcolor: str
    warning_border_color: str
    warning_icon_color: str
    warning_title_color: str
    warning_text_color: str
    error_bgcolor: str
    error_border_color: str
    error_icon_color: str
    error_title_color: str
    error_text_color: str


class TK_ToastTokens:
    default = TK_ToastToken(
        border_radius=12,
        padding_horizontal=16,
        padding_vertical=14,
        min_width=300,
        shadow_blur=16,
        shadow_color="#00000033",
        title_size=14,
        title_weight="w600",
        message_size=13,
        icon_size=20,
        close_icon_size=16,
        spacing=10,
        info_bgcolor="#FFFFFF",
        info_border_color="#1565C0",
        info_icon_color="#1565C0",
        info_title_color="#0D47A1",
        info_text_color="#49454F",
        success_bgcolor="#FFFFFF",
        success_border_color="#386A20",
        success_icon_color="#386A20",
        success_title_color="#2D5518",
        success_text_color="#49454F",
        warning_bgcolor="#FFFFFF",
        warning_border_color="#7D5700",
        warning_icon_color="#7D5700",
        warning_title_color="#5D4000",
        warning_text_color="#49454F",
        error_bgcolor="#FFFFFF",
        error_border_color="#B3261E",
        error_icon_color="#B3261E",
        error_title_color="#8C1D18",
        error_text_color="#49454F",
    )

    dark = TK_ToastToken(
        border_radius=12,
        padding_horizontal=16,
        padding_vertical=14,
        min_width=300,
        shadow_blur=20,
        shadow_color="#00000066",
        title_size=14,
        title_weight="w600",
        message_size=13,
        icon_size=20,
        close_icon_size=16,
        spacing=10,
        info_bgcolor="#1C2C3E",
        info_border_color="#64B5F6",
        info_icon_color="#64B5F6",
        info_title_color="#90CAF9",
        info_text_color="#CAC4D0",
        success_bgcolor="#112213",
        success_border_color="#6DD58C",
        success_icon_color="#6DD58C",
        success_title_color="#A8D5B5",
        success_text_color="#CAC4D0",
        warning_bgcolor="#1E1600",
        warning_border_color="#FFD54F",
        warning_icon_color="#FFD54F",
        warning_title_color="#FFE082",
        warning_text_color="#CAC4D0",
        error_bgcolor="#2D1210",
        error_border_color="#F2B8B5",
        error_icon_color="#F2B8B5",
        error_title_color="#F2B8B5",
        error_text_color="#CAC4D0",
    )
