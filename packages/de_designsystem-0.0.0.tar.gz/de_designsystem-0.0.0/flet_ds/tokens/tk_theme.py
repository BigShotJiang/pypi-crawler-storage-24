# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from dataclasses import dataclass

from flet_ds.tokens.tk_app_shell import TK_AppShellToken, TK_AppShellTokens
from flet_ds.tokens.tk_button    import TK_ButtonToken,   TK_ButtonTokens
from flet_ds.tokens.tk_card      import TK_CardToken,     TK_CardTokens
from flet_ds.tokens.tk_input     import TK_TextFieldToken, TK_InputTokens
from flet_ds.tokens.tk_modal     import TK_ModalToken,    TK_ModalTokens
from flet_ds.tokens.tk_table     import TK_TableToken,    TK_TableTokens
from flet_ds.tokens.tk_search    import TK_SearchToken,   TK_SearchTokens


@dataclass(frozen=True)
class TK_Theme:
    """
    Agrupa todos os tokens de componentes para um tema visual completo.

    Campos
    ------
    name                 : Identificador do tema
    page_bgcolor         : Cor de fundo da página
    flet_theme_mode      : "light" | "dark" | "system"
    flet_color_scheme    : Cor semente para o ft.Theme do Flet

    app_shell            : Layout header + sidebar
    button_filled        : Botão primário preenchido
    button_outlined      : Botão com borda
    button_tonal         : Botão tonal (surface variant)
    card                 : Card elevado
    input                : Campo de texto outlined
    modal                : Diálogo/modal padrão
    table                : Tabela de dados
    search               : Campo de busca

    text_primary         : Cor principal de texto
    text_secondary       : Cor secundária de texto
    text_accent          : Cor de destaque (links, ícones ativos)
    """
    name: str
    page_bgcolor: str
    flet_theme_mode: str
    flet_color_scheme: str

    app_shell: TK_AppShellToken
    button_filled: TK_ButtonToken
    button_outlined: TK_ButtonToken
    button_tonal: TK_ButtonToken
    card: TK_CardToken
    input: TK_TextFieldToken
    modal: TK_ModalToken
    table: TK_TableToken
    search: TK_SearchToken

    text_primary: str
    text_secondary: str
    text_accent: str


# ---------------------------------------------------------------------------
# Variantes de tokens adicionais usadas pelos temas dark / demi-dark / light
# (definidas inline para não poluir os arquivos de token individuais)
# ---------------------------------------------------------------------------

_BUTTON_FILLED_DARK = TK_ButtonToken(
    bgcolor="#D0BCFF", color="#381E72",
    border_radius=20, text_size=14,
    padding_horizontal=24, padding_vertical=10,
    icon_size=18, icon_color="#381E72",
    bgcolor_disabled="#E6E1E533", color_disabled="#E6E1E561",
    border_color=None, border_width=0,
)
_BUTTON_OUTLINED_DARK = TK_ButtonToken(
    bgcolor="transparent", color="#D0BCFF",
    border_radius=20, text_size=14,
    padding_horizontal=24, padding_vertical=10,
    icon_size=18, icon_color="#D0BCFF",
    bgcolor_disabled="transparent", color_disabled="#E6E1E561",
    border_color="#938F99", border_width=1,
)
_BUTTON_TONAL_DARK = TK_ButtonToken(
    bgcolor="#4A4458", color="#E8DEF8",
    border_radius=20, text_size=14,
    padding_horizontal=24, padding_vertical=10,
    icon_size=18, icon_color="#E8DEF8",
    bgcolor_disabled="#E6E1E533", color_disabled="#E6E1E561",
    border_color=None, border_width=0,
)

_BUTTON_FILLED_DEMI = TK_ButtonToken(
    bgcolor="#CDB4FF", color="#2D0070",
    border_radius=20, text_size=14,
    padding_horizontal=24, padding_vertical=10,
    icon_size=18, icon_color="#2D0070",
    bgcolor_disabled="#E2DDED33", color_disabled="#E2DDED61",
    border_color=None, border_width=0,
)
_BUTTON_OUTLINED_DEMI = TK_ButtonToken(
    bgcolor="transparent", color="#CDB4FF",
    border_radius=20, text_size=14,
    padding_horizontal=24, padding_vertical=10,
    icon_size=18, icon_color="#CDB4FF",
    bgcolor_disabled="transparent", color_disabled="#E2DDED61",
    border_color="#9C98A8", border_width=1,
)
_BUTTON_TONAL_DEMI = TK_ButtonToken(
    bgcolor="#4F378B", color="#E2DDED",
    border_radius=20, text_size=14,
    padding_horizontal=24, padding_vertical=10,
    icon_size=18, icon_color="#E2DDED",
    bgcolor_disabled="#E2DDED33", color_disabled="#E2DDED61",
    border_color=None, border_width=0,
)

_INPUT_DARK = TK_TextFieldToken(
    border_color="#938F99", focused_border_color="#D0BCFF",
    border_radius=4, border_width=1, focused_border_width=2,
    text_size=16, label_color="#CAC4D0", cursor_color="#D0BCFF",
    bgcolor="transparent", content_padding=16,
    bgcolor_readonly="#2B2930", bgcolor_required="#370B09",
    border_color_readonly="#49454F", border_color_required="#F2B8B5",
    label_color_required="#F2B8B5",
)
_INPUT_DEMI = TK_TextFieldToken(
    border_color="#9C98A8", focused_border_color="#CDB4FF",
    border_radius=4, border_width=1, focused_border_width=2,
    text_size=16, label_color="#C4BDD6", cursor_color="#CDB4FF",
    bgcolor="transparent", content_padding=16,
    bgcolor_readonly="#2D2A3E", bgcolor_required="#3A1414",
    border_color_readonly="#524F63", border_color_required="#F2B8B5",
    label_color_required="#F2B8B5",
)

_MODAL_DEMI = TK_ModalToken(
    bgcolor="#2D2A3E", border_radius=28, padding=24,
    title_size=20, title_weight="w600", title_color="#E2DDED",
    subtitle_size=14, subtitle_weight="w400", subtitle_color="#C4BDD6",
    icon_color="#CDB4FF", icon_size=28,
    divider_color="#524F63", divider_thickness=1,
    shadow_color="#00000066", shadow_blur=20,
    spacing=16, min_width=280,
)

_TABLE_DEMI = TK_TableToken(
    bgcolor="#1E1B2E", border_radius=12,
    border_color="#524F63", border_width=1,
    header_bgcolor="#2D2A3E",
    header_text_color="#E2DDED", header_text_size=13, header_text_weight="w600",
    row_bgcolor="#1E1B2E", row_alt_bgcolor="#26233A",
    row_hover_color="#38354A", row_selected_color="#4F378B",
    cell_text_color="#C4BDD6", cell_text_size=13,
    cell_padding_horizontal=16, cell_padding_vertical=12,
    divider_color="#524F63", divider_thickness=1,
    icon_color="#CDB4FF", icon_size=18, checkbox_color="#CDB4FF",
)

_SEARCH_DEMI = TK_SearchToken(
    bgcolor="#2D2A3E", border_color="#524F63",
    focused_border_color="#CDB4FF",
    border_radius=24, border_width=1, focused_border_width=2,
    text_color="#E2DDED", hint_color="#9C98A8",
    icon_color="#C4BDD6", icon_size=20, text_size=14,
    height=44, width=None,
    content_padding_horizontal=16, content_padding_vertical=10,
    bgcolor_disabled="#1E1B2E", border_color_disabled="#524F63",
)


# ---------------------------------------------------------------------------
# TK_Themes — catálogo de temas
# ---------------------------------------------------------------------------

class TK_Themes:
    """
    Catálogo de temas prontos para uso.

    Variantes
    ---------
    default   : MD3 purple — tema padrão claro com acento roxo
    light     : Branco limpo — máximo de claridade, contrastes sutis
    dark      : Escuro profundo — superfície quase preta (#141218)
    demi_dark : Semi-escuro — slate-purple (#1E1B2E), mais suave que o dark total
    system    : Segue a preferência do SO (light tokens, modo=system no Flet)
    """

    default = TK_Theme(
        name="default",
        page_bgcolor="#F7F2FA",
        flet_theme_mode="light",
        flet_color_scheme="#6750A4",
        app_shell=TK_AppShellTokens.default,
        button_filled=TK_ButtonTokens.filled,
        button_outlined=TK_ButtonTokens.outlined,
        button_tonal=TK_ButtonTokens.tonal,
        card=TK_CardTokens.elevated,
        input=TK_InputTokens.outlined,
        modal=TK_ModalTokens.default,
        table=TK_TableTokens.default,
        search=TK_SearchTokens.outlined,
        text_primary="#1C1B1F",
        text_secondary="#49454F",
        text_accent="#6750A4",
    )

    light = TK_Theme(
        name="light",
        page_bgcolor="#FFFFFF",
        flet_theme_mode="light",
        flet_color_scheme="#6750A4",
        app_shell=TK_AppShellTokens.light,
        button_filled=TK_ButtonTokens.filled,
        button_outlined=TK_ButtonTokens.outlined,
        button_tonal=TK_ButtonTokens.tonal,
        card=TK_CardTokens.outlined,
        input=TK_InputTokens.outlined,
        modal=TK_ModalTokens.default,
        table=TK_TableTokens.minimal,
        search=TK_SearchTokens.outlined,
        text_primary="#1C1B1F",
        text_secondary="#49454F",
        text_accent="#6750A4",
    )

    dark = TK_Theme(
        name="dark",
        page_bgcolor="#141218",
        flet_theme_mode="dark",
        flet_color_scheme="#D0BCFF",
        app_shell=TK_AppShellTokens.dark,
        button_filled=_BUTTON_FILLED_DARK,
        button_outlined=_BUTTON_OUTLINED_DARK,
        button_tonal=_BUTTON_TONAL_DARK,
        card=TK_CardTokens.dark,
        input=_INPUT_DARK,
        modal=TK_ModalTokens.dark,
        table=TK_TableTokens.dark,
        search=TK_SearchTokens.dark,
        text_primary="#E6E1E5",
        text_secondary="#CAC4D0",
        text_accent="#D0BCFF",
    )

    demi_dark = TK_Theme(
        name="demi_dark",
        page_bgcolor="#1E1B2E",
        flet_theme_mode="dark",
        flet_color_scheme="#CDB4FF",
        app_shell=TK_AppShellTokens.demi_dark,
        button_filled=_BUTTON_FILLED_DEMI,
        button_outlined=_BUTTON_OUTLINED_DEMI,
        button_tonal=_BUTTON_TONAL_DEMI,
        card=_TABLE_DEMI,
        input=_INPUT_DEMI,
        modal=_MODAL_DEMI,
        table=_TABLE_DEMI,
        search=_SEARCH_DEMI,
        text_primary="#E2DDED",
        text_secondary="#C4BDD6",
        text_accent="#CDB4FF",
    )

    system = TK_Theme(
        name="system",
        page_bgcolor="#F7F2FA",
        flet_theme_mode="system",
        flet_color_scheme="#6750A4",
        app_shell=TK_AppShellTokens.default,
        button_filled=TK_ButtonTokens.filled,
        button_outlined=TK_ButtonTokens.outlined,
        button_tonal=TK_ButtonTokens.tonal,
        card=TK_CardTokens.elevated,
        input=TK_InputTokens.outlined,
        modal=TK_ModalTokens.default,
        table=TK_TableTokens.default,
        search=TK_SearchTokens.outlined,
        text_primary="#1C1B1F",
        text_secondary="#49454F",
        text_accent="#6750A4",
    )

    _ALL: dict = {}

    @classmethod
    def get(cls, name: str) -> TK_Theme:
        """Retorna o tema pelo nome. Lança KeyError se não encontrado."""
        if not cls._ALL:
            cls._ALL = {
                "default":   cls.default,
                "light":     cls.light,
                "dark":      cls.dark,
                "demi_dark": cls.demi_dark,
                "system":    cls.system,
            }
        if name not in cls._ALL:
            raise KeyError(f"Tema '{name}' não encontrado. Opções: {list(cls._ALL)}")
        return cls._ALL[name]

    @classmethod
    def names(cls) -> list:
        """Retorna a lista de nomes de temas disponíveis."""
        return ["default", "light", "dark", "demi_dark", "system"]
