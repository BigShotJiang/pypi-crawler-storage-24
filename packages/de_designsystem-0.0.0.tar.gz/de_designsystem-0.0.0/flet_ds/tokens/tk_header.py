# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class TK_HeaderToken:
    bgcolor: str
    title_size: float
    title_weight: str
    title_color: str
    subtitle_size: float
    subtitle_weight: str
    subtitle_color: str
    icon_color: str
    icon_size: float
    divider_color: str
    divider_thickness: float
    padding_horizontal: float
    padding_vertical: float
    spacing: float
    search_bgcolor: str
    search_border_color: str
    search_focused_border_color: str
    search_text_color: str
    search_hint_color: str
    action_btn_bgcolor: str
    action_btn_icon_color: str
    action_btn_hover_color: str
    action_btn_size: float
    action_btn_icon_size: float


class TK_HeaderTokens:
    primary = TK_HeaderToken(
        bgcolor="#6750A4",
        title_size=22,
        title_weight="w600",
        title_color="#FFFFFF",
        subtitle_size=14,
        subtitle_weight="w400",
        subtitle_color="#E8DEF8",
        icon_color="#FFFFFF",
        icon_size=28,
        divider_color="#9A82DB",
        divider_thickness=1,
        padding_horizontal=24,
        padding_vertical=16,
        spacing=8,
        search_bgcolor="#7965AF",
        search_border_color="#9A82DB",
        search_focused_border_color="#FFFFFF",
        search_text_color="#FFFFFF",
        search_hint_color="#D0BCFF",
        action_btn_bgcolor="#7965AF",
        action_btn_icon_color="#FFFFFF",
        action_btn_hover_color="#9A82DB",
        action_btn_size=36,
        action_btn_icon_size=20,
    )

    light = TK_HeaderToken(
        bgcolor="#F7F2FA",
        title_size=22,
        title_weight="w600",
        title_color="#1C1B1F",
        subtitle_size=14,
        subtitle_weight="w400",
        subtitle_color="#49454F",
        icon_color="#6750A4",
        icon_size=28,
        divider_color="#CAC4D0",
        divider_thickness=1,
        padding_horizontal=24,
        padding_vertical=16,
        spacing=8,
        search_bgcolor="#FFFFFF",
        search_border_color="#CAC4D0",
        search_focused_border_color="#6750A4",
        search_text_color="#1C1B1F",
        search_hint_color="#79747E",
        action_btn_bgcolor="#E8DEF8",
        action_btn_icon_color="#6750A4",
        action_btn_hover_color="#D0BCFF",
        action_btn_size=36,
        action_btn_icon_size=20,
    )

    dark = TK_HeaderToken(
        bgcolor="#1C1B1F",
        title_size=22,
        title_weight="w600",
        title_color="#E6E1E5",
        subtitle_size=14,
        subtitle_weight="w400",
        subtitle_color="#CAC4D0",
        icon_color="#D0BCFF",
        icon_size=28,
        divider_color="#49454F",
        divider_thickness=1,
        padding_horizontal=24,
        padding_vertical=16,
        spacing=8,
        search_bgcolor="#2B2930",
        search_border_color="#49454F",
        search_focused_border_color="#D0BCFF",
        search_text_color="#E6E1E5",
        search_hint_color="#938F99",
        action_btn_bgcolor="#2B2930",
        action_btn_icon_color="#D0BCFF",
        action_btn_hover_color="#49454F",
        action_btn_size=36,
        action_btn_icon_size=20,
    )

    demi_dark = TK_HeaderToken(
        bgcolor="#2D2A3E",
        title_size=22,
        title_weight="w600",
        title_color="#E2DDED",
        subtitle_size=14,
        subtitle_weight="w400",
        subtitle_color="#C4BDD6",
        icon_color="#CDB4FF",
        icon_size=28,
        divider_color="#524F63",
        divider_thickness=1,
        padding_horizontal=24,
        padding_vertical=16,
        spacing=8,
        search_bgcolor="#38354A",
        search_border_color="#524F63",
        search_focused_border_color="#CDB4FF",
        search_text_color="#E2DDED",
        search_hint_color="#9C98A8",
        action_btn_bgcolor="#38354A",
        action_btn_icon_color="#CDB4FF",
        action_btn_hover_color="#4F4B60",
        action_btn_size=36,
        action_btn_icon_size=20,
    )

    neutral = TK_HeaderToken(
        bgcolor="#FFFFFF",
        title_size=22,
        title_weight="w600",
        title_color="#1C1B1F",
        subtitle_size=14,
        subtitle_weight="w400",
        subtitle_color="#49454F",
        icon_color="#6750A4",
        icon_size=28,
        divider_color="#CAC4D0",
        divider_thickness=1,
        padding_horizontal=24,
        padding_vertical=16,
        spacing=8,
        search_bgcolor="#F7F2FA",
        search_border_color="#CAC4D0",
        search_focused_border_color="#6750A4",
        search_text_color="#1C1B1F",
        search_hint_color="#79747E",
        action_btn_bgcolor="#F7F2FA",
        action_btn_icon_color="#6750A4",
        action_btn_hover_color="#E8DEF8",
        action_btn_size=36,
        action_btn_icon_size=20,
    )
