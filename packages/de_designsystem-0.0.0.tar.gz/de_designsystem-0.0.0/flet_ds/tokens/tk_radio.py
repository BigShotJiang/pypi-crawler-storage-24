# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class TK_RadioToken:
    active_color: str
    border_color: str
    disabled_color: str
    label_color: str
    label_size: float
    splash_radius: float


class TK_RadioTokens:
    primary = TK_RadioToken(
        active_color="#6750A4",
        border_color="#79747E",
        disabled_color="#1C1B1F61",
        label_color="#1C1B1F",
        label_size=14,
        splash_radius=20,
    )

    error = TK_RadioToken(
        active_color="#B3261E",
        border_color="#B3261E",
        disabled_color="#1C1B1F61",
        label_color="#B3261E",
        label_size=14,
        splash_radius=20,
    )

    success = TK_RadioToken(
        active_color="#386A20",
        border_color="#386A20",
        disabled_color="#1C1B1F61",
        label_color="#1C1B1F",
        label_size=14,
        splash_radius=20,
    )
