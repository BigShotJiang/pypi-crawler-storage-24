# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from dataclasses import dataclass
from flet_ds.tokens.tk_header  import TK_HeaderToken,  TK_HeaderTokens
from flet_ds.tokens.tk_sidebar import TK_SidebarToken, TK_SidebarTokens


@dataclass(frozen=True)
class TK_AppShellToken:
    bgcolor: str
    header_token:  TK_HeaderToken
    sidebar_token: TK_SidebarToken


class TK_AppShellTokens:
    default = TK_AppShellToken(
        bgcolor="#F7F2FA",
        header_token=TK_HeaderTokens.primary,
        sidebar_token=TK_SidebarTokens.default,
    )

    light = TK_AppShellToken(
        bgcolor="#FFFFFF",
        header_token=TK_HeaderTokens.light,
        sidebar_token=TK_SidebarTokens.default,
    )

    dark = TK_AppShellToken(
        bgcolor="#141218",
        header_token=TK_HeaderTokens.dark,
        sidebar_token=TK_SidebarTokens.dark,
    )

    demi_dark = TK_AppShellToken(
        bgcolor="#1E1B2E",
        header_token=TK_HeaderTokens.demi_dark,
        sidebar_token=TK_SidebarTokens.demi_dark,
    )

    neutral = TK_AppShellToken(
        bgcolor="#F7F2FA",
        header_token=TK_HeaderTokens.neutral,
        sidebar_token=TK_SidebarTokens.minimal,
    )
