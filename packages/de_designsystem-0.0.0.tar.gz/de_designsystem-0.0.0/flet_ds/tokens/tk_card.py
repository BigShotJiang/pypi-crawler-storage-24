# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class TK_CardToken:
    bgcolor: str
    border_radius: float
    padding: float
    shadow_color: str
    shadow_blur: float
    shadow_offset_y: float
    border_color: Optional[str]
    border_width: float
    title_size: float
    title_weight: str
    title_color: str
    subtitle_size: float
    subtitle_weight: str
    subtitle_color: str
    icon_color: str
    icon_size: float
    spacing: float


class TK_CardTokens:
    elevated = TK_CardToken(
        bgcolor="#FFFBFE",
        border_radius=12,
        padding=16,
        shadow_color="#00000033",
        shadow_blur=8,
        shadow_offset_y=2,
        border_color=None,
        border_width=0,
        title_size=16,
        title_weight="w600",
        title_color="#1C1B1F",
        subtitle_size=13,
        subtitle_weight="w400",
        subtitle_color="#49454F",
        icon_color="#6750A4",
        icon_size=24,
        spacing=8,
    )

    outlined = TK_CardToken(
        bgcolor="#FFFBFE",
        border_radius=12,
        padding=16,
        shadow_color="transparent",
        shadow_blur=0,
        shadow_offset_y=0,
        border_color="#CAC4D0",
        border_width=1,
        title_size=16,
        title_weight="w600",
        title_color="#1C1B1F",
        subtitle_size=13,
        subtitle_weight="w400",
        subtitle_color="#49454F",
        icon_color="#6750A4",
        icon_size=24,
        spacing=8,
    )

    filled = TK_CardToken(
        bgcolor="#E7E0EC",
        border_radius=12,
        padding=16,
        shadow_color="transparent",
        shadow_blur=0,
        shadow_offset_y=0,
        border_color=None,
        border_width=0,
        title_size=16,
        title_weight="w600",
        title_color="#1C1B1F",
        subtitle_size=13,
        subtitle_weight="w400",
        subtitle_color="#49454F",
        icon_color="#6750A4",
        icon_size=24,
        spacing=8,
    )

    dark = TK_CardToken(
        bgcolor="#2B2930",
        border_radius=12,
        padding=16,
        shadow_color="#00000066",
        shadow_blur=10,
        shadow_offset_y=3,
        border_color=None,
        border_width=0,
        title_size=16,
        title_weight="w600",
        title_color="#E6E1E5",
        subtitle_size=13,
        subtitle_weight="w400",
        subtitle_color="#CAC4D0",
        icon_color="#D0BCFF",
        icon_size=24,
        spacing=8,
    )
