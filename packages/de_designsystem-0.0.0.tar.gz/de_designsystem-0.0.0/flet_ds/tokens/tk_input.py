# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class TK_TextFieldToken:
    border_color: str
    focused_border_color: str
    border_radius: float
    border_width: float
    focused_border_width: float
    text_size: float
    label_color: str
    cursor_color: str
    bgcolor: str
    content_padding: float
    bgcolor_readonly: str
    bgcolor_required: str
    border_color_readonly: str
    border_color_required: str
    label_color_required: str


class TK_InputTokens:
    outlined = TK_TextFieldToken(
        border_color="#79747E",
        focused_border_color="#6750A4",
        border_radius=4,
        border_width=1,
        focused_border_width=2,
        text_size=16,
        label_color="#49454F",
        cursor_color="#6750A4",
        bgcolor="transparent",
        content_padding=16,
        bgcolor_readonly="#F4EFF4",
        bgcolor_required="#FFF8F7",
        border_color_readonly="#CAC4D0",
        border_color_required="#B3261E",
        label_color_required="#B3261E",
    )

    filled = TK_TextFieldToken(
        border_color="#79747E",
        focused_border_color="#6750A4",
        border_radius=4,
        border_width=0,
        focused_border_width=2,
        text_size=16,
        label_color="#49454F",
        cursor_color="#6750A4",
        bgcolor="#E7E0EC",
        content_padding=16,
        bgcolor_readonly="#D9D3DE",
        bgcolor_required="#F9DEDC",
        border_color_readonly="#CAC4D0",
        border_color_required="#B3261E",
        label_color_required="#B3261E",
    )

    error = TK_TextFieldToken(
        border_color="#B3261E",
        focused_border_color="#B3261E",
        border_radius=4,
        border_width=1,
        focused_border_width=2,
        text_size=16,
        label_color="#B3261E",
        cursor_color="#B3261E",
        bgcolor="transparent",
        content_padding=16,
        bgcolor_readonly="#F4EFF4",
        bgcolor_required="#FFF8F7",
        border_color_readonly="#CAC4D0",
        border_color_required="#B3261E",
        label_color_required="#B3261E",
    )
