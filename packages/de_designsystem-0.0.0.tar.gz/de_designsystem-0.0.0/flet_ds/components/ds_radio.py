# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
from flet_ds.tokens.tk_radio import TK_RadioToken as RadioToken, TK_RadioTokens as RadioTokens
import flet as ft


@dataclass
class RadioOption:
    label: str
    value: str


class DS_RadioGroup(ft.RadioGroup):
    def __init__(
        self,
        options: list,
        token: RadioToken = RadioTokens.primary,
        value: Optional[str] = None,
        disabled: bool = False,
        on_change=None,
        **kwargs,
    ):
        radios = [
            ft.Radio(
                label=opt.label,
                value=opt.value,
                fill_color=token.disabled_color if disabled else token.active_color,
                label_style=ft.TextStyle(
                    size=token.label_size,
                    color=token.disabled_color if disabled else token.label_color,
                ),
                splash_radius=token.splash_radius,
            )
            for opt in options
        ]

        super().__init__(
            value=value,
            on_change=on_change,
            content=ft.Column(
                controls=radios,
                spacing=4,
                disabled=disabled,
            ),
            **kwargs,
        )
