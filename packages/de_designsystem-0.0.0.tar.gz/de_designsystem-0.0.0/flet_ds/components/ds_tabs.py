# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from typing import Optional, Callable
from dataclasses import dataclass, field
import flet as ft

from flet_ds.tokens.tk_tabs import TK_TabsToken, TK_TabsTokens


@dataclass
class TabItem:
    label: str
    content: ft.Control
    icon: Optional[str] = None


class DS_Tabs(ft.Column):
    """
    Componente de abas com conteudo dinamico por aba.

    Parametros
    ----------
    tabs           : Lista de TabItem(label, content, icon)
    selected_index : Aba ativa inicial (padrao 0)
    token          : TK_TabsToken
    on_change      : Callback(index: int) ao trocar de aba
    expand_content : Se True, a area de conteudo ocupa o espaco disponivel
    """

    def __init__(
        self,
        tabs: list,
        selected_index: int = 0,
        token: TK_TabsToken = TK_TabsTokens.primary,
        on_change: Optional[Callable] = None,
        expand_content: bool = False,
        **kwargs,
    ):
        self._tabs           = tabs
        self._selected       = selected_index
        self._token          = token
        self._on_change      = on_change
        self._expand_content = expand_content

        self._content_area = ft.Container(
            expand=expand_content,
            bgcolor=token.content_bgcolor,
            padding=token.content_padding,
            content=tabs[selected_index].content if tabs else ft.Container(),
        )

        super().__init__(
            spacing=0,
            expand=expand_content,
            controls=[
                self._build_tab_bar(),
                ft.Container(
                    height=token.divider_thickness,
                    bgcolor=token.divider_color,
                ),
                self._content_area,
            ],
            **kwargs,
        )

    def _build_tab_bar(self) -> ft.Row:
        t = self._token
        tab_controls = []
        for i, tab in enumerate(self._tabs):
            is_active = i == self._selected
            tab_controls.append(self._build_tab_item(i, tab, is_active))
        return ft.Container(
            bgcolor=t.bgcolor,
            content=ft.Row(spacing=0, controls=tab_controls),
        )

    def _build_tab_item(self, index: int, tab: TabItem, is_active: bool) -> ft.Container:
        t = self._token
        label_controls = []
        if tab.icon:
            label_controls.append(
                ft.Icon(
                    tab.icon,
                    size=t.icon_size,
                    color=t.active_color if is_active else t.inactive_color,
                )
            )
        label_controls.append(
            ft.Text(
                tab.label,
                size=t.label_size,
                weight=t.label_weight_active if is_active else t.label_weight_inactive,
                color=t.active_color if is_active else t.inactive_color,
            )
        )

        indicator = ft.Container(
            height=t.indicator_thickness,
            bgcolor=t.indicator_color if is_active else "transparent",
            border_radius=ft.border_radius.only(
                top_left=t.indicator_thickness,
                top_right=t.indicator_thickness,
            ),
        )

        def _on_click(e, idx=index):
            self.select(idx)

        return ft.Container(
            bgcolor=t.tab_bgcolor_active if is_active else t.tab_bgcolor_inactive,
            border_radius=ft.border_radius.only(
                top_left=t.border_radius,
                top_right=t.border_radius,
            ) if t.border_radius > 0 else None,
            ink=True,
            on_click=_on_click,
            on_hover=None,
            content=ft.Column(
                spacing=0,
                tight=True,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Container(
                        height=t.tab_height - t.indicator_thickness,
                        padding=ft.padding.symmetric(horizontal=16),
                        alignment=ft.alignment.center,
                        content=ft.Row(
                            spacing=6,
                            tight=True,
                            controls=label_controls,
                        ),
                    ),
                    indicator,
                ],
            ),
        )

    def select(self, index: int):
        self._selected = index
        self.controls[0] = self._build_tab_bar()
        self._content_area.content = self._tabs[index].content
        try:
            self.update()
        except AssertionError:
            pass
        if self._on_change:
            self._on_change(index)

    @property
    def selected_index(self) -> int:
        return self._selected
