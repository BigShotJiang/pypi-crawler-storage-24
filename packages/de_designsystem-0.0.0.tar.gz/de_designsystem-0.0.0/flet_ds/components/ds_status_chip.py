# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from typing import Optional
import flet as ft

from flet_ds.tokens.tk_status_chip import TK_StatusChipToken, TK_StatusChipTokens

_STATUS_ICONS = {
    "running": ft.Icons.SYNC,
    "done":    ft.Icons.CHECK_CIRCLE_OUTLINE,
    "failed":  ft.Icons.ERROR_OUTLINE,
    "pending": ft.Icons.HOURGLASS_EMPTY,
    "warning": ft.Icons.WARNING_AMBER_OUTLINED,
    "info":    ft.Icons.INFO_OUTLINE,
}

_STATUS_USE_DOT = {"running"}


class DS_StatusChip(ft.Container):
    """
    Chip colorido para exibir o status de um job/task/processo.

    Parametros
    ----------
    label   : Texto do chip (ex: "Running", "Concluido")
    status  : "running" | "done" | "failed" | "pending" | "warning" | "info"
    icon    : Icone customizado (usa padrao do status se None)
    size    : "small" | "medium" | "large"
    token   : TK_StatusChipToken
    """

    def __init__(
        self,
        label: str,
        status: str = "pending",
        icon: Optional[str] = None,
        size: str = "medium",
        token: TK_StatusChipToken = TK_StatusChipTokens.default,
        **kwargs,
    ):
        t = token

        bgcolor    = getattr(t, f"{status}_bgcolor",    t.pending_bgcolor)
        text_color = getattr(t, f"{status}_text_color", t.pending_text_color)

        pad_h = getattr(t, f"padding_horizontal_{size}", t.padding_horizontal_md)
        pad_v = getattr(t, f"padding_vertical_{size}",   t.padding_vertical_md)
        tsize = getattr(t, f"text_size_{size}",          t.text_size_md)
        isize = getattr(t, f"icon_size_{size}",          t.icon_size_md)

        use_dot   = status in _STATUS_USE_DOT and icon is None
        icon_name = icon or _STATUS_ICONS.get(status)

        if use_dot:
            dot_color = getattr(t, f"{status}_dot_color", text_color)
            indicator = ft.Container(
                width=t.dot_size,
                height=t.dot_size,
                border_radius=t.dot_size / 2,
                bgcolor=dot_color,
            )
        else:
            icon_color = getattr(t, f"{status}_icon_color", text_color)
            indicator  = ft.Icon(icon_name, size=isize, color=icon_color)

        controls = [indicator, ft.Text(label, size=tsize, color=text_color, weight="w500")]

        super().__init__(
            bgcolor=bgcolor,
            border_radius=t.border_radius,
            padding=ft.padding.symmetric(horizontal=pad_h, vertical=pad_v),
            content=ft.Row(
                spacing=t.spacing,
                tight=True,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=controls,
            ),
            **kwargs,
        )
