# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from typing import Optional
from flet_ds.tokens.tk_typography import TK_TextToken as TextToken, TK_TypographyTokens as TypographyTokens
import flet as ft


class DS_Text(ft.Text):
    def __init__(
        self,
        value: str = "",
        token: TextToken = TypographyTokens.body_medium,
        color: Optional[str] = None,
        **kwargs,
    ):
        super().__init__(
            value=value,
            size=token.size,
            weight=token.weight,
            color=color if color is not None else token.color,
            font_family=token.font_family,
            italic=token.italic,
            **kwargs,
        )
