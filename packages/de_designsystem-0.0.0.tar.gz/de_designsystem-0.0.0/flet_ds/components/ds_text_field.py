# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from typing import Literal, Optional
from flet_ds.tokens.tk_input import TK_TextFieldToken as TextFieldToken, TK_InputTokens as InputTokens
import flet as ft

FieldState = Literal["normal", "readonly", "required"]


class DS_TextField(ft.TextField):
    def __init__(
        self,
        label: str = "",
        token: TextFieldToken = InputTokens.outlined,
        hint_text: Optional[str] = None,
        state: FieldState = "normal",
        multiline: bool = False,
        min_lines: Optional[int] = None,
        max_lines: Optional[int] = None,
        **kwargs,
    ):
        bgcolor, border_color, label_color, read_only = self._resolve_state(token, state)

        super().__init__(
            label=label,
            hint_text=hint_text,
            text_size=token.text_size,
            border_color=border_color,
            focused_border_color=token.focused_border_color,
            border_radius=token.border_radius,
            border_width=token.border_width,
            focused_border_width=token.focused_border_width,
            label_style=ft.TextStyle(color=label_color),
            cursor_color=token.cursor_color,
            bgcolor=bgcolor,
            content_padding=token.content_padding,
            read_only=read_only,
            multiline=multiline,
            min_lines=min_lines if multiline else None,
            max_lines=max_lines if multiline else None,
            **kwargs,
        )

    @staticmethod
    def _resolve_state(token: TextFieldToken, state: FieldState):
        if state == "readonly":
            return (
                token.bgcolor_readonly,
                token.border_color_readonly,
                token.label_color,
                True,
            )
        if state == "required":
            return (
                token.bgcolor_required,
                token.border_color_required,
                token.label_color_required,
                False,
            )
        return token.bgcolor, token.border_color, token.label_color, False
