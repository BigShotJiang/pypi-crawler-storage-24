# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from flet_ds.tokens.tk_checkbox import TK_CheckboxToken as CheckboxToken, TK_CheckboxTokens as CheckboxTokens
import flet as ft


class DS_Checkbox(ft.Checkbox):
    def __init__(
        self,
        label: str = "",
        token: CheckboxToken = CheckboxTokens.primary,
        value: bool = False,
        disabled: bool = False,
        on_change=None,
        **kwargs,
    ):
        super().__init__(
            label=label,
            value=value,
            disabled=disabled,
            on_change=on_change,
            active_color=token.active_color if not disabled else token.disabled_color,
            check_color=token.check_color,
            border_side=ft.BorderSide(
                width=2,
                color=token.disabled_color if disabled else token.border_color,
            ),
            label_style=ft.TextStyle(
                size=token.label_size,
                color=token.disabled_color if disabled else token.label_color,
            ),
            splash_radius=token.splash_radius,
            **kwargs,
        )
