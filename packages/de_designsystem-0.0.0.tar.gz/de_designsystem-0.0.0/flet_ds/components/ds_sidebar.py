# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Callable, Literal, Optional
from flet_ds.tokens.tk_sidebar import TK_SidebarToken, TK_SidebarTokens
import flet as ft

SidebarMode = Literal["expanded", "icons_only", "hidden"]


@dataclass
class SidebarItem:
    label: str
    icon: str
    selected_icon: Optional[str] = None
    on_click: Optional[Callable] = None
    badge: Optional[str] = None


@dataclass
class SidebarAction:
    icon: str
    tooltip: str = ""
    on_click: Optional[Callable] = None


class DS_Sidebar(ft.Container):
    def __init__(
        self,
        items: list,
        token: TK_SidebarToken = TK_SidebarTokens.default,
        bottom_actions: Optional[list] = None,
        mode: SidebarMode = "expanded",
        selected_index: int = 0,
        on_mode_change: Optional[Callable] = None,
        on_item_click: Optional[Callable] = None,
        **kwargs,
    ):
        self._items          = items
        self._token          = token
        self._bottom_actions = bottom_actions or []
        self._mode           = mode
        self._selected       = selected_index
        self._on_mode_change = on_mode_change
        self._on_item_click  = on_item_click

        kwargs.pop("expand", None)
        super().__init__(
            width=self._resolve_width(),
            expand=False,
            bgcolor=token.bgcolor,
            border=ft.border.only(
                right=ft.BorderSide(token.border_right_width, token.border_right_color)
            ),
            animate=ft.Animation(280, ft.AnimationCurve.EASE_IN_OUT),
            clip_behavior=ft.ClipBehavior.HARD_EDGE,
            content=self._build_content(),
            **kwargs,
        )

    def _resolve_width(self) -> float:
        if self._mode == "expanded":
            return self._token.width_expanded
        if self._mode == "icons_only":
            return self._token.width_collapsed
        return 0

    def _cycle_mode(self, e):
        self._mode = "icons_only" if self._mode == "expanded" else "expanded"
        self._refresh()
        if self._on_mode_change:
            self._on_mode_change(self._mode)

    def _handle_item_click(self, idx: int, item_callback: Optional[Callable]):
        self._selected = idx
        self._refresh()
        if item_callback:
            item_callback(idx)
        if self._on_item_click:
            self._on_item_click(idx)

    def set_mode(self, mode: SidebarMode):
        self._mode = mode
        self._refresh()

    def set_selected(self, index: int):
        self._selected = index
        self._refresh()

    def _refresh(self):
        self.width   = self._resolve_width()
        self.content = self._build_content()
        try:
            self.update()
        except AssertionError:
            pass

    def _build_content(self) -> ft.Column:
        token     = self._token
        expanded  = self._mode == "expanded"

        toggle_icon = (
            ft.Icons.MENU_OPEN if expanded else
            ft.Icons.MENU
        )

        header = ft.Container(
            bgcolor=token.header_bgcolor,
            height=token.header_height,
            padding=ft.padding.symmetric(horizontal=token.item_padding_horizontal),
            content=ft.Row(
                alignment=ft.MainAxisAlignment.SPACE_BETWEEN
                          if expanded else ft.MainAxisAlignment.CENTER,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Text(
                        value="Menu",
                        size=18,
                        weight="w700",
                        color=token.item_text_color,
                        visible=expanded,
                    ),
                    ft.IconButton(
                        icon=toggle_icon,
                        icon_color=token.toggle_icon_color,
                        icon_size=token.toggle_icon_size,
                        tooltip="Expandir" if not expanded else "Recolher",
                        on_click=self._cycle_mode,
                        style=ft.ButtonStyle(
                            bgcolor=token.toggle_bgcolor,
                            overlay_color=token.toggle_hover_color,
                            shape=ft.CircleBorder(),
                        ),
                    ),
                ],
            ),
        )

        items_controls = [
            self._build_item(idx, item)
            for idx, item in enumerate(self._items)
        ]

        items_area = ft.Container(
            expand=True,
            padding=ft.padding.symmetric(horizontal=8, vertical=8),
            content=ft.Column(
                spacing=token.item_spacing,
                scroll=ft.ScrollMode.AUTO,
                controls=items_controls,
            ),
        )

        bottom_area = self._build_bottom_actions()

        return ft.Column(
            spacing=0,
            expand=True,
            controls=[
                header,
                ft.Divider(height=1, thickness=token.divider_thickness, color=token.divider_color),
                items_area,
                ft.Divider(height=1, thickness=token.divider_thickness, color=token.divider_color),
                bottom_area,
            ],
        )

    def _build_item(self, idx: int, item: SidebarItem) -> ft.Container:
        token       = self._token
        is_selected = idx == self._selected
        expanded    = self._mode == "expanded"
        icon_name   = (item.selected_icon or item.icon) if is_selected else item.icon

        icon_ctrl = ft.Icon(
            name=icon_name,
            size=token.item_icon_size,
            color=token.item_icon_selected_color if is_selected else token.item_icon_color,
        )

        row_controls: list = [icon_ctrl]

        if expanded:
            row_controls.append(
                ft.Text(
                    value=item.label,
                    size=token.item_text_size,
                    weight=token.item_text_weight,
                    color=token.item_text_selected_color if is_selected else token.item_text_color,
                    expand=True,
                    no_wrap=True,
                    overflow=ft.TextOverflow.ELLIPSIS,
                )
            )
            if item.badge:
                row_controls.append(self._build_badge(item.badge, token))

        container = ft.Container(
            height=token.item_height,
            border_radius=token.item_border_radius,
            bgcolor=token.item_bgcolor_selected if is_selected else "transparent",
            padding=ft.padding.symmetric(horizontal=token.item_padding_horizontal),
            tooltip=item.label if not expanded else None,
            ink=True,
            on_click=lambda e, i=idx, cb=item.on_click: self._handle_item_click(i, cb),
            content=ft.Row(
                spacing=12,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=row_controls,
            ),
        )

        def on_hover(e, c=container, sel=is_selected):
            if not sel:
                c.bgcolor = (
                    token.item_bgcolor_hover if e.data == "true" else "transparent"
                )
                c.update()

        container.on_hover = on_hover
        return container

    @staticmethod
    def _build_badge(text: str, token: TK_SidebarToken) -> ft.Container:
        return ft.Container(
            content=ft.Text(
                value=str(text),
                size=10,
                weight="w600",
                color=token.badge_text_color,
            ),
            bgcolor=token.badge_bgcolor,
            border_radius=10,
            padding=ft.padding.symmetric(horizontal=6, vertical=2),
        )

    def _build_bottom_actions(self) -> ft.Container:
        token    = self._token
        expanded = self._mode == "expanded"

        btns = [
            ft.IconButton(
                icon=action.icon,
                icon_color=token.action_icon_color,
                icon_size=token.action_icon_size,
                tooltip=action.tooltip,
                on_click=action.on_click,
                style=ft.ButtonStyle(
                    bgcolor=token.action_bgcolor,
                    overlay_color=token.action_hover_color,
                    shape=ft.CircleBorder(),
                ),
            )
            for action in self._bottom_actions
        ]

        return ft.Container(
            bgcolor=token.action_area_bgcolor,
            padding=ft.padding.symmetric(horizontal=8, vertical=10),
            content=ft.Row(
                controls=btns,
                alignment=ft.MainAxisAlignment.CENTER
                          if not expanded else ft.MainAxisAlignment.START,
                spacing=4,
            ),
        )
