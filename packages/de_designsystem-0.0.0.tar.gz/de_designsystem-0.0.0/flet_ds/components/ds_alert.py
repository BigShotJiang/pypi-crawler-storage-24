# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from typing import Optional, Callable
import flet as ft

from flet_ds.tokens.tk_alert import TK_AlertToken, TK_AlertTokens

_ICONS = {
    "info":    ft.Icons.INFO_OUTLINE,
    "success": ft.Icons.CHECK_CIRCLE_OUTLINE,
    "warning": ft.Icons.WARNING_AMBER_OUTLINED,
    "error":   ft.Icons.ERROR_OUTLINE,
}


class DS_Alert(ft.Container):
    """
    Faixa de alerta inline com titulo opcional, mensagem e icone automatico.

    Parametros
    ----------
    message      : Mensagem principal
    alert_type   : "info" | "success" | "warning" | "error"
    title        : Titulo em negrito (opcional)
    icon         : Icone customizado (usa padrao do tipo se None)
    dismissible  : Exibe botao X para fechar
    on_dismiss   : Callback disparado ao fechar
    token        : TK_AlertToken
    """

    def __init__(
        self,
        message: str,
        alert_type: str = "info",
        title: Optional[str] = None,
        icon: Optional[str] = None,
        dismissible: bool = False,
        on_dismiss: Optional[Callable] = None,
        token: TK_AlertToken = TK_AlertTokens.default,
        **kwargs,
    ):
        self._token      = token
        self._dismissed  = False
        self._on_dismiss = on_dismiss
        t = token
        tp = alert_type

        bgcolor      = getattr(t, f"{tp}_bgcolor")
        border_color = getattr(t, f"{tp}_border_color")
        icon_color   = getattr(t, f"{tp}_icon_color")
        title_color  = getattr(t, f"{tp}_title_color")
        text_color   = getattr(t, f"{tp}_text_color")

        icon_widget = ft.Icon(
            icon or _ICONS.get(tp, ft.Icons.INFO_OUTLINE),
            size=t.icon_size,
            color=icon_color,
        )

        text_col = ft.Column(
            spacing=2,
            tight=True,
            expand=True,
            controls=[
                *(
                    [ft.Text(title, size=t.title_size, weight=t.title_weight, color=title_color)]
                    if title else []
                ),
                ft.Text(message, size=t.message_size, color=text_color),
            ],
        )

        row_controls: list = [icon_widget, text_col]

        if dismissible:
            row_controls.append(
                ft.IconButton(
                    icon=ft.Icons.CLOSE,
                    icon_size=14,
                    icon_color=icon_color,
                    tooltip="Fechar",
                    on_click=self._handle_dismiss,
                    padding=ft.padding.all(0),
                )
            )

        row = ft.Row(
            spacing=12,
            vertical_alignment=ft.CrossAxisAlignment.START,
            controls=row_controls,
        )

        self._wrapper = ft.Container(
            padding=ft.padding.only(left=t.border_left_width + t.padding_horizontal,
                                    right=t.padding_horizontal,
                                    top=t.padding_vertical,
                                    bottom=t.padding_vertical),
            bgcolor=bgcolor,
            border_radius=t.border_radius,
            border=ft.border.only(left=ft.BorderSide(t.border_left_width, border_color)),
            content=row,
        )

        kwargs.pop("content", None)
        super().__init__(content=self._wrapper, **kwargs)

    def _handle_dismiss(self, e):
        self.visible = False
        try:
            self.update()
        except AssertionError:
            pass
        if self._on_dismiss:
            self._on_dismiss(e)
