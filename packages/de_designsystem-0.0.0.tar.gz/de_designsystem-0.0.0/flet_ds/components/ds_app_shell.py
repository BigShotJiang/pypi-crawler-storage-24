# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from typing import Callable, Optional
import flet as ft

from flet_ds.tokens.tk_app_shell import TK_AppShellToken, TK_AppShellTokens
from flet_ds.components.ds_header  import DS_Header, HeaderAction
from flet_ds.components.ds_sidebar import DS_Sidebar, SidebarItem, SidebarAction


class DS_AppShell(ft.Column):
    """
    Layout reutilizável que combina DS_Header + DS_Sidebar + área de conteúdo.

    Pode ser aninhado: o `content` pode ser outro DS_AppShell com seu próprio
    header/sidebar/tokens, permitindo layouts multi-nível.

    Parâmetros
    ----------
    title          : Título exibido no header
    items          : Lista de SidebarItem para o menu lateral
    subtitle       : Subtítulo do header (opcional)
    icon           : Ícone do header (opcional)
    content        : Controle inicial da área principal (opcional)
    token          : TK_AppShellToken que define header + sidebar + bgcolor
    sidebar_mode   : "expanded" | "icons_only" | "hidden"
    selected_index : Índice do item selecionado no sidebar (padrão 0)
    bottom_actions : Botões de ação no rodapé do sidebar
    header_actions : Botões de ação no header
    show_search    : Exibe campo de busca no header
    on_item_click  : Callback(index: int) disparado ao clicar num item
    on_mode_change : Callback(mode: str) disparado ao alternar o sidebar
    """

    def __init__(
        self,
        title: str,
        items: list,
        subtitle: str = "",
        icon: Optional[str] = None,
        content: Optional[ft.Control] = None,
        token: TK_AppShellToken = TK_AppShellTokens.default,
        sidebar_mode: str = "expanded",
        selected_index: int = 0,
        bottom_actions: Optional[list] = None,
        header_actions: Optional[list] = None,
        show_search: bool = False,
        on_item_click: Optional[Callable] = None,
        on_mode_change: Optional[Callable] = None,
        **kwargs,
    ):
        self._token          = token
        self._on_item_click  = on_item_click

        self._content_area = ft.Container(
            expand=True,
            bgcolor=token.bgcolor,
            content=content or ft.Container(),
        )

        self._sidebar = DS_Sidebar(
            items=items,
            token=token.sidebar_token,
            bottom_actions=bottom_actions or [],
            mode=sidebar_mode,
            selected_index=selected_index,
            on_item_click=self._handle_item_click,
            on_mode_change=on_mode_change,
        )

        header = DS_Header(
            title=title,
            subtitle=subtitle,
            icon=icon,
            token=token.header_token,
            actions=header_actions,
            show_search=show_search,
        )

        body = ft.Row(
            expand=True,
            spacing=0,
            controls=[
                self._sidebar,
                ft.VerticalDivider(width=1, color=token.sidebar_token.divider_color),
                self._content_area,
            ],
        )

        kwargs.pop("expand", None)
        super().__init__(
            expand=True,
            spacing=0,
            controls=[header, body],
            **kwargs,
        )

    def _handle_item_click(self, idx: int):
        if self._on_item_click:
            self._on_item_click(idx)

    def set_content(self, control: ft.Control):
        """Substitui o conteúdo da área principal e atualiza a UI."""
        self._content_area.content = control
        try:
            self._content_area.update()
        except AssertionError:
            pass

    def set_selected(self, index: int):
        """Define o item selecionado no sidebar."""
        self._sidebar.set_selected(index)

    def set_sidebar_mode(self, mode: str):
        """Altera o modo do sidebar: 'expanded' | 'icons_only' | 'hidden'."""
        self._sidebar.set_mode(mode)

    @property
    def sidebar(self) -> DS_Sidebar:
        return self._sidebar

    @property
    def content_area(self) -> ft.Container:
        return self._content_area
