# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from typing import Optional, Callable
from dataclasses import dataclass
import flet as ft

from flet_ds.tokens.tk_stepper import TK_StepperToken, TK_StepperTokens


@dataclass
class StepItem:
    label: str
    subtitle: str = ""
    icon: Optional[str] = None
    state: str = "pending"


class DS_Stepper(ft.Column):
    """
    Wizard de etapas com estados visuais e navegacao entre passos.

    Parametros
    ----------
    steps          : Lista de StepItem(label, subtitle, icon, state)
    current        : Indice do passo atual (0-based)
    orientation    : "horizontal" | "vertical"
    token          : TK_StepperToken
    on_step_click  : Callback(index: int) ao clicar num passo completado
    interactive    : Permite clicar nos passos completados para voltar
    """

    def __init__(
        self,
        steps: list,
        current: int = 0,
        orientation: str = "horizontal",
        token: TK_StepperToken = TK_StepperTokens.default,
        on_step_click: Optional[Callable] = None,
        interactive: bool = True,
        **kwargs,
    ):
        self._steps        = steps
        self._current      = current
        self._orientation  = orientation
        self._token        = token
        self._on_step_click = on_step_click
        self._interactive  = interactive

        super().__init__(
            spacing=0,
            controls=self._build(),
            **kwargs,
        )

    def _build(self) -> list:
        if self._orientation == "horizontal":
            return [self._build_horizontal()]
        return self._build_vertical()

    def _build_horizontal(self) -> ft.Control:
        t = self._token
        items = []
        for i, step in enumerate(self._steps):
            state = self._resolve_state(i)
            items.append(self._build_step_circle(i, step, state))
            if i < len(self._steps) - 1:
                is_passed = self._current > i
                items.append(
                    ft.Container(
                        expand=True,
                        height=t.connector_thickness,
                        bgcolor=t.connector_active_color if is_passed else t.connector_color,
                        margin=ft.margin.only(bottom=18),
                    )
                )
        return ft.Row(
            controls=items,
            alignment=ft.MainAxisAlignment.CENTER,
            vertical_alignment=ft.CrossAxisAlignment.START,
        )

    def _build_vertical(self) -> list:
        t = self._token
        rows = []
        for i, step in enumerate(self._steps):
            state = self._resolve_state(i)
            circle = self._build_step_circle(i, step, state, show_label=False)
            label_col = ft.Column(
                spacing=1,
                tight=True,
                controls=[
                    ft.Text(
                        step.label,
                        size=t.label_size,
                        weight=t.label_weight_active if state == "active" else t.label_weight_default,
                        color=getattr(t, f"label_color_{state}"),
                    ),
                    *(
                        [ft.Text(step.subtitle, size=t.sublabel_size, color=t.sublabel_color)]
                        if step.subtitle else []
                    ),
                ],
            )
            rows.append(
                ft.Row(
                    spacing=12,
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                    controls=[circle, label_col],
                )
            )
            if i < len(self._steps) - 1:
                is_passed = self._current > i
                rows.append(
                    ft.Container(
                        width=t.connector_thickness,
                        height=24,
                        bgcolor=t.connector_active_color if is_passed else t.connector_color,
                        margin=ft.margin.only(left=t.step_size / 2 - t.connector_thickness / 2),
                    )
                )
        return rows

    def _resolve_state(self, index: int) -> str:
        if index < self._current:
            return "completed"
        if index == self._current:
            return "active"
        return "pending"

    def _build_step_circle(self, index: int, step: StepItem, state: str,
                            show_label: bool = True) -> ft.Control:
        t = self._token
        dot_color = (
            t.active_color    if state == "active"    else
            t.completed_color if state == "completed" else
            t.error_color     if state == "error"     else
            t.pending_color
        )
        text_color = (
            t.step_text_color_active    if state == "active"    else
            t.step_text_color_completed if state == "completed" else
            t.step_text_color_pending
        )

        inner = (
            ft.Icon(ft.Icons.CHECK, size=t.step_size * 0.5, color=text_color)
            if state == "completed"
            else ft.Icon(step.icon, size=t.step_size * 0.5, color=text_color)
            if step.icon
            else ft.Text(str(index + 1), size=t.step_number_size, color=text_color, weight="w700")
        )

        def _on_click(e, idx=index):
            if self._interactive and self._current > idx and self._on_step_click:
                self._on_step_click(idx)

        circle = ft.Container(
            width=t.step_size,
            height=t.step_size,
            border_radius=t.step_size / 2,
            bgcolor=dot_color,
            alignment=ft.alignment.center,
            ink=self._interactive and self._current > index,
            on_click=_on_click if self._interactive else None,
            content=inner,
            tooltip=step.label if self._orientation == "horizontal" else None,
        )

        if not show_label or self._orientation == "vertical":
            return circle

        label_col = ft.Column(
            spacing=1,
            tight=True,
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                circle,
                ft.Text(
                    step.label,
                    size=t.label_size,
                    weight=t.label_weight_active if state == "active" else t.label_weight_default,
                    color=getattr(t, f"label_color_{state}"),
                    text_align=ft.TextAlign.CENTER,
                ),
                *(
                    [ft.Text(step.subtitle, size=t.sublabel_size, color=t.sublabel_color,
                             text_align=ft.TextAlign.CENTER)]
                    if step.subtitle else []
                ),
            ],
        )
        return label_col

    def set_current(self, index: int):
        self._current = max(0, min(index, len(self._steps) - 1))
        self.controls = self._build()
        try:
            self.update()
        except AssertionError:
            pass

    def next_step(self):
        self.set_current(self._current + 1)

    def prev_step(self):
        self.set_current(self._current - 1)

    def set_step_state(self, index: int, state: str):
        self._steps[index].state = state
        self.controls = self._build()
        try:
            self.update()
        except AssertionError:
            pass

    @property
    def current(self) -> int:
        return self._current
