# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
from flet_ds.tokens.tk_modal import TK_ModalToken as ModalToken, TK_ModalTokens as ModalTokens
import flet as ft


@dataclass
class ModalAction:
    label: str
    on_click: Optional[object] = None
    icon: Optional[str] = None
    primary: bool = False


class DS_Modal(ft.AlertDialog):
    def __init__(
        self,
        title: str,
        subtitle: Optional[str] = None,
        icon: Optional[str] = None,
        content: Optional[ft.Control] = None,
        actions: Optional[list] = None,
        token: ModalToken = ModalTokens.default,
        modal: bool = True,
        on_dismiss=None,
        **kwargs,
    ):
        built_title   = self._build_title(title, subtitle, icon, token)
        built_actions = self._build_actions(actions or [], token)

        super().__init__(
            modal=modal,
            title=built_title,
            content=ft.Container(
                content=content,
                padding=ft.padding.symmetric(vertical=4),
            ) if content else None,
            actions=built_actions if built_actions else None,
            actions_alignment=ft.MainAxisAlignment.END,
            on_dismiss=on_dismiss,
            shape=ft.RoundedRectangleBorder(radius=token.border_radius),
            bgcolor=token.bgcolor,
            shadow_color=token.shadow_color,
            title_padding=ft.padding.all(token.padding),
            content_padding=ft.padding.symmetric(horizontal=token.padding, vertical=0),
            actions_padding=ft.padding.only(
                left=token.padding,
                right=token.padding,
                bottom=token.padding,
                top=8,
            ),
            **kwargs,
        )

    @staticmethod
    def _build_title(
        title: str,
        subtitle: Optional[str],
        icon: Optional[str],
        token: ModalToken,
    ) -> ft.Control:
        title_text = ft.Text(
            value=title,
            size=token.title_size,
            weight=token.title_weight,
            color=token.title_color,
        )

        if icon:
            title_row = ft.Row(
                spacing=10,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Icon(name=icon, size=token.icon_size, color=token.icon_color),
                    title_text,
                ],
            )
        else:
            title_row = title_text

        if subtitle:
            return ft.Column(
                spacing=4,
                tight=True,
                controls=[
                    title_row,
                    ft.Text(
                        value=subtitle,
                        size=token.subtitle_size,
                        weight=token.subtitle_weight,
                        color=token.subtitle_color,
                    ),
                    ft.Divider(height=token.spacing, thickness=token.divider_thickness, color=token.divider_color),
                ],
            )

        return ft.Column(
            spacing=4,
            tight=True,
            controls=[
                title_row,
                ft.Divider(height=token.spacing, thickness=token.divider_thickness, color=token.divider_color),
            ],
        )

    @staticmethod
    def _build_actions(actions: list, token: ModalToken) -> list:
        accent = token.icon_color
        result = []
        for action in actions:
            if action.primary:
                btn = ft.ElevatedButton(
                    text=action.label,
                    icon=action.icon,
                    on_click=action.on_click,
                    style=ft.ButtonStyle(
                        bgcolor=accent,
                        color="#FFFFFF",
                        shape=ft.RoundedRectangleBorder(radius=20),
                        padding=ft.padding.symmetric(horizontal=24, vertical=10),
                    ),
                )
            else:
                btn = ft.TextButton(
                    text=action.label,
                    icon=action.icon,
                    on_click=action.on_click,
                    style=ft.ButtonStyle(
                        color=accent,
                        shape=ft.RoundedRectangleBorder(radius=20),
                        padding=ft.padding.symmetric(horizontal=16, vertical=10),
                    ),
                )
            result.append(btn)
        return result

    def open_modal(self, page: ft.Page):
        self.open = True
        page.overlay.append(self)
        page.update()

    def close_modal(self, page: ft.Page):
        self.open = False
        page.update()
