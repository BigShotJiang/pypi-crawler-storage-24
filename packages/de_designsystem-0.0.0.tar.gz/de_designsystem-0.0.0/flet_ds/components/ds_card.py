# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from typing import Optional
from flet_ds.tokens.tk_card import TK_CardToken as CardToken, TK_CardTokens as CardTokens
import flet as ft


class DS_Card(ft.Container):
    def __init__(
        self,
        title: str,
        subtitle: Optional[str] = None,
        icon: Optional[str] = None,
        content: Optional[ft.Control] = None,
        footer: Optional[ft.Control] = None,
        token: CardToken = CardTokens.elevated,
        bgcolor: Optional[str] = None,
        width: Optional[float] = None,
        height: Optional[float] = None,
        on_click=None,
        **kwargs,
    ):
        header = self._build_header(title, subtitle, icon, token)

        body_controls = [header]

        if content is not None:
            body_controls.append(ft.Divider(height=1, color=token.border_color or "#00000022"))
            body_controls.append(content)

        if footer is not None:
            body_controls.append(ft.Divider(height=1, color=token.border_color or "#00000022"))
            body_controls.append(footer)

        border = (
            ft.border.all(width=token.border_width, color=token.border_color)
            if token.border_color
            else None
        )

        shadow = (
            [ft.BoxShadow(
                blur_radius=token.shadow_blur,
                offset=ft.Offset(0, token.shadow_offset_y),
                color=token.shadow_color,
                spread_radius=0,
            )]
            if token.shadow_blur > 0
            else None
        )

        super().__init__(
            bgcolor=bgcolor if bgcolor is not None else token.bgcolor,
            border_radius=token.border_radius,
            padding=token.padding,
            border=border,
            shadow=shadow,
            width=width,
            height=height,
            on_click=on_click,
            ink=on_click is not None,
            content=ft.Column(
                spacing=token.spacing,
                controls=body_controls,
            ),
            **kwargs,
        )

    @staticmethod
    def _build_header(
        title: str,
        subtitle: Optional[str],
        icon: Optional[str],
        token: CardToken,
    ) -> ft.Control:
        title_text = ft.Text(
            value=title,
            size=token.title_size,
            weight=token.title_weight,
            color=token.title_color,
        )

        if icon:
            title_row = ft.Row(
                spacing=token.spacing,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Icon(name=icon, size=token.icon_size, color=token.icon_color),
                    title_text,
                ],
            )
        else:
            title_row = title_text

        if subtitle:
            return ft.Column(
                spacing=2,
                controls=[
                    title_row,
                    ft.Text(
                        value=subtitle,
                        size=token.subtitle_size,
                        weight=token.subtitle_weight,
                        color=token.subtitle_color,
                    ),
                ],
            )

        return title_row
