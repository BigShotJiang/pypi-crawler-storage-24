# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from typing import Optional
from flet_ds.tokens.tk_search import TK_SearchToken as SearchToken, TK_SearchTokens as SearchTokens
import flet as ft


class DS_Search(ft.TextField):
    def __init__(
        self,
        hint_text: str = "Pesquisar...",
        token: SearchToken = SearchTokens.outlined,
        width: Optional[float] = None,
        disabled: bool = False,
        on_change=None,
        on_submit=None,
        **kwargs,
    ):
        bgcolor      = token.bgcolor_disabled      if disabled else token.bgcolor
        border_color = token.border_color_disabled if disabled else token.border_color

        super().__init__(
            hint_text=hint_text,
            hint_style=ft.TextStyle(color=token.hint_color),
            text_style=ft.TextStyle(color=token.text_color),
            prefix_icon=ft.Icon(name=ft.Icons.SEARCH, size=token.icon_size, color=token.icon_color),
            border_color=border_color,
            focused_border_color=token.focused_border_color,
            border_width=token.border_width,
            focused_border_width=token.focused_border_width,
            border_radius=token.border_radius,
            bgcolor=bgcolor,
            content_padding=ft.padding.symmetric(
                horizontal=token.content_padding_horizontal,
                vertical=token.content_padding_vertical,
            ),
            text_size=token.text_size,
            cursor_color=token.focused_border_color,
            height=token.height,
            width=width if width is not None else token.width,
            disabled=disabled,
            on_change=on_change,
            on_submit=on_submit,
            **kwargs,
        )
