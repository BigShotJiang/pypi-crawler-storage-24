# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from dataclasses import dataclass
from typing import Literal, Optional
from flet_ds.tokens.tk_dropdown import TK_DropdownToken as DropdownToken, TK_DropdownTokens as DropdownTokens
import flet as ft

FieldState = Literal["normal", "readonly", "required"]


@dataclass
class DropdownOption:
    label: str
    value: str
    icon: Optional[str] = None


class DS_Dropdown(ft.Dropdown):
    def __init__(
        self,
        label: str = "",
        options: Optional[list] = None,
        token: DropdownToken = DropdownTokens.outlined,
        state: FieldState = "normal",
        **kwargs,
    ):
        bgcolor, border_color, label_color, disabled = self._resolve_state(token, state)

        built_options = self._build_options(options or [], token)

        super().__init__(
            label=label,
            options=built_options,
            text_size=token.text_size,
            border_color=border_color,
            focused_border_color=token.focused_border_color,
            border_radius=token.border_radius,
            border_width=token.border_width,
            focused_border_width=token.focused_border_width,
            label_style=ft.TextStyle(color=label_color),
            bgcolor=bgcolor,
            content_padding=token.content_padding,
            disabled=disabled,
            **kwargs,
        )

    @staticmethod
    def _resolve_state(token: DropdownToken, state: FieldState):
        if state == "readonly":
            return token.bgcolor_readonly, token.border_color_readonly, token.label_color, True
        if state == "required":
            return token.bgcolor_required, token.border_color_required, token.label_color_required, False
        return token.bgcolor, token.border_color, token.label_color, False

    @staticmethod
    def _build_options(options: list, token: DropdownToken) -> list:
        result = []
        for opt in options:
            result.append(
                ft.dropdown.Option(
                    key=opt.value,
                    text=opt.label,
                    leading_icon=ft.Icon(
                        name=opt.icon,
                        size=token.icon_size,
                        color=token.icon_color,
                    ) if opt.icon else None,
                )
            )
        return result
