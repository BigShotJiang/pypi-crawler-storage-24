# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from typing import Optional
from flet_ds.tokens.tk_button import TK_ButtonToken as ButtonToken, TK_ButtonTokens as ButtonTokens
import flet as ft


class DS_Button(ft.ElevatedButton):
    def __init__(
        self,
        label: str = "",
        token: ButtonToken = ButtonTokens.filled,
        icon: Optional[str] = None,
        disabled: bool = False,
        on_click=None,
        **kwargs,
    ):
        bgcolor = token.bgcolor_disabled if disabled else token.bgcolor
        color   = token.color_disabled   if disabled else token.color

        border = (
            ft.BorderSide(width=token.border_width, color=token.border_color)
            if token.border_color
            else None
        )

        super().__init__(
            text=label,
            icon=icon,
            icon_color=token.icon_color if not disabled else token.color_disabled,
            disabled=disabled,
            on_click=on_click,
            style=ft.ButtonStyle(
                bgcolor=bgcolor,
                color=color,
                shape=ft.RoundedRectangleBorder(radius=token.border_radius),
                padding=ft.padding.symmetric(
                    horizontal=token.padding_horizontal,
                    vertical=token.padding_vertical,
                ),
                side=border,
                text_style=ft.TextStyle(size=token.text_size),
                icon_size=token.icon_size,
            ),
            **kwargs,
        )
