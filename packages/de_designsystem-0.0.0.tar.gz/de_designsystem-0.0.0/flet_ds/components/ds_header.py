# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
from flet_ds.tokens.tk_header import TK_HeaderToken as HeaderToken, TK_HeaderTokens as HeaderTokens
import flet as ft


@dataclass
class HeaderAction:
    icon: str
    tooltip: str = ""
    on_click: Optional[object] = None


class DS_Header(ft.Column):
    def __init__(
        self,
        title: str,
        subtitle: Optional[str] = None,
        icon: Optional[str] = None,
        token: HeaderToken = HeaderTokens.primary,
        bgcolor: Optional[str] = None,
        title_size: Optional[float] = None,
        title_weight: Optional[str] = None,
        subtitle_size: Optional[float] = None,
        subtitle_weight: Optional[str] = None,
        show_search: bool = False,
        search_hint: str = "Pesquisar...",
        on_search_change=None,
        actions: Optional[list] = None,
        **kwargs,
    ):
        resolved_bgcolor = bgcolor if bgcolor is not None else token.bgcolor

        left = self._build_title_block(
            title=title,
            subtitle=subtitle,
            icon=icon,
            token=token,
            title_size=title_size or token.title_size,
            title_weight=title_weight or token.title_weight,
            subtitle_size=subtitle_size or token.subtitle_size,
            subtitle_weight=subtitle_weight or token.subtitle_weight,
        )

        right_controls = []

        if show_search:
            right_controls.append(self._build_search(token, search_hint, on_search_change))

        if actions:
            for action in actions[:3]:
                right_controls.append(self._build_action_button(action, token))

        header_row = ft.Row(
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.CENTER,
            controls=[
                left,
                ft.Row(spacing=8, vertical_alignment=ft.CrossAxisAlignment.CENTER, controls=right_controls),
            ],
        )

        controls = [
            ft.Container(
                bgcolor=resolved_bgcolor,
                padding=ft.padding.symmetric(
                    horizontal=token.padding_horizontal,
                    vertical=token.padding_vertical,
                ),
                content=header_row,
            ),
            ft.Divider(height=1, thickness=token.divider_thickness, color=token.divider_color),
        ]

        super().__init__(controls=controls, spacing=0, **kwargs)

    @staticmethod
    def _build_title_block(
        title: str,
        subtitle: Optional[str],
        icon: Optional[str],
        token: HeaderToken,
        title_size: float,
        title_weight: str,
        subtitle_size: float,
        subtitle_weight: str,
    ) -> ft.Control:
        title_text = ft.Text(value=title, size=title_size, weight=title_weight, color=token.title_color)

        if icon:
            title_row = ft.Row(
                spacing=token.spacing,
                vertical_alignment=ft.CrossAxisAlignment.CENTER,
                controls=[
                    ft.Icon(name=icon, size=token.icon_size, color=token.icon_color),
                    title_text,
                ],
            )
        else:
            title_row = title_text

        if subtitle:
            return ft.Column(
                spacing=2,
                controls=[
                    title_row,
                    ft.Text(value=subtitle, size=subtitle_size, weight=subtitle_weight, color=token.subtitle_color),
                ],
            )

        return title_row

    @staticmethod
    def _build_search(token: HeaderToken, hint: str, on_change) -> ft.TextField:
        return ft.TextField(
            hint_text=hint,
            hint_style=ft.TextStyle(color=token.search_hint_color),
            text_style=ft.TextStyle(color=token.search_text_color),
            prefix_icon=ft.Icon(name=ft.Icons.SEARCH, color=token.search_hint_color),
            border_color=token.search_border_color,
            focused_border_color=token.search_focused_border_color,
            focused_border_width=2,
            border_width=1,
            border_radius=24,
            bgcolor=token.search_bgcolor,
            content_padding=ft.padding.symmetric(horizontal=16, vertical=8),
            text_size=14,
            cursor_color=token.search_focused_border_color,
            width=220,
            height=40,
            on_change=on_change,
        )

    @staticmethod
    def _build_action_button(action: HeaderAction, token: HeaderToken) -> ft.IconButton:
        return ft.IconButton(
            icon=action.icon,
            icon_color=token.action_btn_icon_color,
            icon_size=token.action_btn_icon_size,
            tooltip=action.tooltip,
            on_click=action.on_click,
            style=ft.ButtonStyle(
                bgcolor=token.action_btn_bgcolor,
                overlay_color=token.action_btn_hover_color,
                shape=ft.CircleBorder(),
                padding=ft.padding.all(8),
            ),
            width=token.action_btn_size,
            height=token.action_btn_size,
        )
