# =============================================================================
# DE-DesignSystem
# Copyright (c) 2026 Almir J Gomes. Todos os direitos reservados.
#
# Autor  : Almir J Gomes <almir.jg@hotmail.com>
# Criado : 03/2026
#
# Este software é propriedade intelectual de Almir J Gomes.
# É permitida a redistribuição e o uso, com ou sem modificação,
# desde que este aviso de copyright seja mantido em todas as cópias.
# Uso comercial sem autorização expressa é proibido.
# =============================================================================

from __future__ import annotations
from typing import Optional
import flet as ft

from flet_ds.tokens.tk_kpi_card import TK_KPICardToken, TK_KPICardTokens


class DS_KPICard(ft.Container):
    """
    Card de indicador KPI com titulo, valor grande, variacao percentual e icone.

    Parametros
    ----------
    title          : Rotulo do indicador (ex: "Total de Pipelines")
    value          : Valor principal a exibir (ex: "1.248" ou "R$ 42.800")
    variation      : Percentual de variacao (ex: 12.5 para +12,5%)
    variation_label: Contexto da variacao (ex: "vs semana anterior")
    icon           : Icone Material representando o KPI
    trend          : "up" | "down" | "neutral" — define a cor da variacao
    token          : TK_KPICardToken
    width          : Largura do card (padrao 220)
    """

    def __init__(
        self,
        title: str,
        value: str,
        variation: Optional[float] = None,
        variation_label: str = "",
        icon: Optional[str] = None,
        trend: str = "neutral",
        token: TK_KPICardToken = TK_KPICardTokens.default,
        width: Optional[float] = 220,
        on_click=None,
        **kwargs,
    ):
        t = token

        variation_color = (
            t.variation_up_color   if trend == "up"   else
            t.variation_down_color if trend == "down" else
            t.variation_neutral_color
        )
        trend_icon = (
            ft.Icons.TRENDING_UP   if trend == "up"   else
            ft.Icons.TRENDING_DOWN if trend == "down" else
            ft.Icons.TRENDING_FLAT
        )

        variation_row = ft.Row(
            spacing=4,
            tight=True,
            controls=[
                ft.Icon(trend_icon, size=t.variation_size + 2, color=variation_color),
                ft.Text(
                    f"{'+' if (variation or 0) >= 0 else ''}{variation:.1f}%"
                    if variation is not None else "",
                    size=t.variation_size,
                    color=variation_color,
                    weight="w600",
                ),
                ft.Text(
                    variation_label,
                    size=t.variation_size,
                    color=t.variation_neutral_color,
                ),
            ],
        ) if variation is not None else ft.Container()

        icon_widget = ft.Container(
            width=t.icon_size + 16,
            height=t.icon_size + 16,
            border_radius=t.icon_border_radius,
            bgcolor=t.icon_bgcolor,
            alignment=ft.alignment.center,
            content=ft.Icon(icon or ft.Icons.SHOW_CHART, size=t.icon_size, color=t.icon_color),
        ) if icon else ft.Container()

        header_row = ft.Row(
            alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
            vertical_alignment=ft.CrossAxisAlignment.START,
            controls=[
                ft.Text(title, size=t.title_size, color=t.title_color, weight="w500"),
                icon_widget,
            ],
        )

        content = ft.Column(
            spacing=6,
            tight=True,
            controls=[
                header_row,
                ft.Text(value, size=t.value_size, color=t.value_color, weight=t.value_weight),
                variation_row,
            ],
        )

        super().__init__(
            width=width,
            padding=t.padding,
            bgcolor=t.bgcolor,
            border_radius=t.border_radius,
            border=ft.border.all(t.border_width, t.border_color),
            shadow=ft.BoxShadow(
                blur_radius=t.shadow_blur,
                color=t.shadow_color,
                offset=ft.Offset(0, 2),
            ),
            ink=on_click is not None,
            on_click=on_click,
            content=content,
            **kwargs,
        )
