"""
Common utilities for DeepDoc independent library.

This module provides common utilities that were previously imported from RAGFlow.
These are simplified versions suitable for an independent library.
"""

from .file_utils import get_project_base_directory, traversal_files
from .token_utils import num_tokens_from_string, total_token_count_from_response, truncate
from .misc_utils import pip_install_torch
from .connection_utils import timeout
from .config_utils import get_base_config, get_config_value
from .settings import PARALLEL_DEVICES, check_and_install_torch
from .model_store import (
    resolve_bundle_dir,
    resolve_tokenizer_dict_prefix,
    resolve_vision_model_dir,
    resolve_xgb_model_dir,
    validate_bundle_dir,
)

__all__ = [
    # file_utils
    "get_project_base_directory",
    "traversal_files",

    # token_utils
    "num_tokens_from_string",
    "total_token_count_from_response",
    "truncate",

    # misc_utils
    "pip_install_torch",

    # connection_utils
    "timeout",

    # config_utils
    "get_base_config",
    "get_config_value",

    # settings
    "PARALLEL_DEVICES",
    "check_and_install_torch",

    # model_store
    "resolve_bundle_dir",
    "resolve_tokenizer_dict_prefix",
    "resolve_vision_model_dir",
    "resolve_xgb_model_dir",
    "validate_bundle_dir",
]
