﻿# -*- coding: utf-8 -*-
import zmq
import json
from rich.console import Console
from rich.table import Table
from rich.live import Live

def launch_ui():
    context = zmq.Context()
    socket = context.socket(zmq.SUB)
    socket.connect("tcp://127.0.0.1:5555")
    socket.setsockopt_string(zmq.SUBSCRIBE, "GORAZD_METRICS")
    
    console = Console()
    console.clear()
    
    def generate_table(data):
        table = Table(title="[bold cyan]GORAZD UHFT TACTICAL TELEMETRY[/bold cyan]", style="cyan", width=75)
        table.add_column("Metric", style="bold yellow", width=25)
        table.add_column("Live State", style="bold white", justify="right")
        
        table.add_row("Mid Price", f"${data.get('price', 0.0):,.2f}")
        table.add_row("Skewed Conviction", f"{data.get('probability', 0.0)*100:.2f}%")
        
        cap = data.get('capital', 250000)
        cap_color = "[bold green]" if cap >= 250000 else "[bold red]"
        table.add_row("Net Capital", f"{cap_color}${cap:,.2f}[/]")
        table.add_row("Maker Rebates Earned", f"[bold green]+${data.get('rebates', 0.0):,.2f}[/]")
        
        sharpe = data.get('sharpe', 0.0)
        sharpe_color = "[bold green]" if sharpe > 1.5 else "[bold yellow]" if sharpe > 0 else "[bold red]"
        table.add_row("Live Sharpe Ratio", f"{sharpe_color}{sharpe:.2f}[/]")
        
        is_bps = data.get("shortfall_bps", 0.0)
        shortfall_color = "[bold red]" if is_bps > 0 else "[bold white]"
        table.add_row("Implementation Shortfall", f"{shortfall_color}{is_bps:.2f} bps[/]")
        
        lat_us = data.get("latency_us", 0.0)
        lat_color = "[bold green]" if lat_us < 500 else "[bold yellow]" if lat_us < 2000 else "[bold red]"
        table.add_row("Internal IPC Latency", f"{lat_color}{lat_us:.2f} us[/]")
        
        table.add_row("Last Action", f"[bold magenta]{data.get('action', 'WAITING')}[/bold magenta]")
        return table

    print("[+] DASHBOARD: Subscribed to ZeroMQ. Awaiting Engine Ignition...")
    try:
        with Live(generate_table({}), refresh_per_second=20) as live:
            while True:
                message = socket.recv_string()
                topic, data_str = message.split(" ", 1)
                live.update(generate_table(json.loads(data_str)))
    except KeyboardInterrupt:
        print("\n[+] DASHBOARD: Connection severed cleanly.")
