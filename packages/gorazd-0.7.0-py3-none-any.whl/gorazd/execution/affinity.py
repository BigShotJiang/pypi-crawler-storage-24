import os
import sys
import ctypes

def lock_hardware_core(core_id: int):
    """
    Absolute Hardware Lock.
    Bypasses high-level OS suggestions and physically binds the process 
    to a specific CPU core using raw C-API kernel commands.
    """
    try:
        if sys.platform == 'win32':
            # Windows: Bitwise mask mapping to logical cores
            mask = 1 << core_id
            handle = ctypes.windll.kernel32.GetCurrentProcess()
            ctypes.windll.kernel32.SetProcessAffinityMask(handle, mask)
        else:
            # Linux: Equinix bare-metal isolcpus strict binding
            os.sched_setaffinity(0, {core_id})
    except Exception as e:
        print(f"[-] AFFINITY LOCK FAILED: {e}")