import polars as pl
from pathlib import Path
import os
import time

class ImmutableLedger:
    """
    Zero-blocking asynchronous trade journal.
    Ensures absolute persistence of Execution PnL and Slippage metrics 
    in the event of catastrophic power failure.
    """
    def __init__(self, ledger_path="institutional_ledger.parquet"):
        self.path = Path(os.getcwd()) / "data_vault" / ledger_path
        self.path.parent.mkdir(exist_ok=True)
        self.buffer = []
        
    def record_clear(self, asset: str, qty: int, entry_px: float, exit_px: float, pnl: float, shortfall_bps: float):
        self.buffer.append({
            "timestamp": time.time(),
            "asset": asset,
            "qty": qty,
            "entry_px": entry_px,
            "exit_px": exit_px,
            "realized_pnl": pnl,
            "shortfall_bps": shortfall_bps
        })
        # Flush to physical disk every 5 trades to minimize I/O blocking
        if len(self.buffer) >= 5:
            self.flush()
            
    def flush(self):
        if not self.buffer: return
        df = pl.DataFrame(self.buffer)
        if self.path.exists():
            existing = pl.read_parquet(self.path)
            df = pl.concat([existing, df])
        df.write_parquet(self.path)
        self.buffer.clear()