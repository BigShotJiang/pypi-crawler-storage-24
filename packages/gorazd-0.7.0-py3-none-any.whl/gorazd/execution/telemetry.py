import zmq
import json

class TelemetryPublisher:
    def __init__(self, port: int = 5555):
        self.context = zmq.Context()
        self.socket = self.context.socket(zmq.PUB)
        self.socket.bind(f"tcp://127.0.0.1:{port}")

    def broadcast_state(self, price: float, prob: float, capital: float, action: str, shortfall: float = 0.0, latency_us: float = 0.0):
        payload = {
            "price": round(price, 2),
            "probability": round(prob, 4),
            "capital": round(capital, 2),
            "action": action,
            "shortfall_bps": round(shortfall, 2),
            "latency_us": round(latency_us, 2)
        }
        self.socket.send_string(f"GORAZD_METRICS {json.dumps(payload)}")
