import numpy as np
import time
from gorazd.execution.binary_encoder import BOEEncoder
from gorazd.execution.telemetry import TelemetryPublisher
from gorazd.execution.ledger import ImmutableLedger

class Router:
    def __init__(self, queue, capital: float = 250000.0, leverage: float = 1.5, shadow: bool = True):
        self.cap = capital
        self.lev = leverage
        self.q = queue
        self.shadow = shadow
        self.prob = 0.5 
        self.qty = 0
        self.price = 0.0
        self.risk_aversion = 0.15 
        
        self.maker_rebate = 0.0020  
        self.taker_fee = -0.0030    
        self.accumulated_rebates = 0.0
        self.pnl_history = []
        
        self.enc_b = BOEEncoder(b'TOK1', b'SPY     ', b'B')
        self.enc_s = BOEEncoder(b'TOK2', b'SPY     ', b'S')
        self.telemetry = TelemetryPublisher()
        self.ledger = ImmutableLedger() # [!] INSTANTIATE PERSISTENCE

    def _skew_probability(self, raw_prob: float, mid_price: float) -> float:
        if self.qty == 0: return raw_prob
        inventory_exposure = (self.qty * mid_price) / self.cap
        skew_penalty = inventory_exposure * self.risk_aversion
        return np.clip(raw_prob - skew_penalty, 0.01, 0.99)

    def _calculate_fractional_kelly(self, prob: float) -> float:
        p_win = prob if prob >= 0.5 else 1.0 - prob
        kelly_pct = p_win - ((1.0 - p_win) / 1.0)
        return max(0.0, kelly_pct * 0.25)

    def step(self, px: float, vol: float = 0.15):
        raw_prob, ts_ns = self.q.pop_lockfree()
        if raw_prob == -1.0: return
        
        latency_us = (time.perf_counter_ns() - ts_ns) / 1000.0
        skewed_prob = self._skew_probability(raw_prob, px)
        conviction_delta = abs(skewed_prob - self.prob)
        
        if conviction_delta > 0.05: 
            action, is_bps = "HOLD", 0.0
            is_aggressive = conviction_delta > 0.15
            exchange_fee = self.taker_fee if is_aggressive else self.maker_rebate
            execution_type = "TAKER" if is_aggressive else "MAKER"
            
            if self.qty != 0:
                sim_slippage = np.random.uniform(0.01, 0.03) if is_aggressive else 0.0
                if self.qty < 0: sim_slippage = -sim_slippage
                
                fill = px - sim_slippage
                gross_pnl = (fill - self.price) * self.qty
                fee_impact = abs(self.qty) * exchange_fee
                net_trade_pnl = gross_pnl + fee_impact
                
                self.accumulated_rebates += fee_impact if not is_aggressive else 0.0
                self.cap += net_trade_pnl
                self.pnl_history.append(net_trade_pnl)
                
                is_bps = (abs(px - fill) / px) * 10000
                action = f"CLEAR ${net_trade_pnl:.0f} ({execution_type})"
                
                # [!] RECORD TO IMMUTABLE DISK
                self.ledger.record_clear("SPY", self.qty, self.price, fill, net_trade_pnl, is_bps)

            k_frac = self._calculate_fractional_kelly(skewed_prob)
            exp = min(k_frac * (0.10 / max(vol, 0.01)) * self.lev, self.lev) 
            target_qty = int((self.cap * exp) / px) * (1 if skewed_prob >= 0.5 else -1)
            
            if abs(target_qty) > 0:
                if action == "HOLD": action = f"EXEC {target_qty} @ ${px:.2f} ({execution_type})"
                self.prob, self.qty, self.price = skewed_prob, target_qty, px
            
            live_sharpe = 0.0
            if len(self.pnl_history) > 5:
                pnl_arr = np.array(self.pnl_history)
                std_dev = np.std(pnl_arr)
                if std_dev > 0: live_sharpe = (np.mean(pnl_arr) / std_dev) * np.sqrt(252 * 390) 

            payload = {
                "price": round(px, 2), "probability": round(skewed_prob, 4), 
                "capital": round(self.cap, 2), "action": action, 
                "shortfall_bps": round(is_bps, 2), "latency_us": round(latency_us, 2),
                "rebates": round(self.accumulated_rebates, 2), "sharpe": round(live_sharpe, 2)
            }
            import json
            self.telemetry.socket.send_string(f"GORAZD_METRICS {json.dumps(payload)}")
            
    def shutdown(self):
        self.ledger.flush()