import ctypes
from multiprocessing import shared_memory
import numpy as np

class SPSCStruct(ctypes.Structure):
    """
    Dual-Vector L1-Padded IPC Struct.
    Passes execution probability and nanosecond hardware timestamps simultaneously.
    """
    _fields_ = [
        ("write_idx", ctypes.c_uint64),
        ("_pad0", ctypes.c_uint8 * 56), # 64-byte L1 Cache Line Padding
        ("read_idx", ctypes.c_uint64),
        ("_pad1", ctypes.c_uint8 * 56), 
        ("data_prob", ctypes.c_float * 1024),
        ("data_ts", ctypes.c_uint64 * 1024) # Hardware Timestamp Vector
    ]

class SPSCRingBuffer:
    def __init__(self, name="gorazd_ipc", create=True):
        self.name = name
        self.size = ctypes.sizeof(SPSCStruct)
        self.capacity = 1024
        self._mask = self.capacity - 1
        
        if create:
            try: self.shm = shared_memory.SharedMemory(name=self.name, create=True, size=self.size)
            except FileExistsError: self.shm = shared_memory.SharedMemory(name=self.name, create=False)
        else:
            self.shm = shared_memory.SharedMemory(name=self.name, create=False)
            
        self.struct = SPSCStruct.from_buffer(self.shm.buf)
        if create:
            self.struct.write_idx = 0
            self.struct.read_idx = 0

    def push_lockfree(self, prob: float, ts_ns: int) -> bool:
        next_write = (self.struct.write_idx + 1) & self._mask
        if next_write == (self.struct.read_idx & self._mask): return False 
            
        idx = self.struct.write_idx & self._mask
        self.struct.data_prob[idx] = prob
        self.struct.data_ts[idx] = ts_ns
        self.struct.write_idx = next_write
        return True

    def pop_lockfree(self) -> tuple:
        if self.struct.read_idx == self.struct.write_idx: return -1.0, 0 
            
        idx = self.struct.read_idx & self._mask
        prob = self.struct.data_prob[idx]
        ts_ns = self.struct.data_ts[idx]
        self.struct.read_idx = (self.struct.read_idx + 1) & self._mask
        return prob, ts_ns
        
    def close(self):
        del self.struct 
        self.shm.close()
        try: self.shm.unlink()
        except FileNotFoundError: pass
