import multiprocessing as mp
import time
import sys
import gc
import numpy as np
import json
import zmq
from gorazd.execution.affinity import lock_hardware_core
from gorazd.execution.memory_pool import StaticMemoryPool
from gorazd.execution.concurrency import SPSCRingBuffer
from gorazd.ml.native_infer import NativeXGBoostEngine
from gorazd.execution.router import Router
from gorazd.data.live_ingress import PhysicalLiveIngress
from gorazd.config import settings

def _ingest(target, model_name):
    lock_hardware_core(1)
    pool = StaticMemoryPool(65536, 9)
    engine = NativeXGBoostEngine(model_name)
    spsc = SPSCRingBuffer("gorazd_ipc", create=False)
    streamer = PhysicalLiveIngress(target_ticker=target)
    streamer.start_stream()
    try:
        while True:
            spy_t0, spy_t1, qqq_t0, qqq_t1, tlt_t0, tlt_t1, gld_t0, gld_t1, vwap, vol, vix_t0, vix_t2 = streamer.get_latest_state()
            from gorazd.math.core import compute_institutional_features_inplace
            view = pool.get_next_view()
            compute_institutional_features_inplace(spy_t0, spy_t1, qqq_t0, qqq_t1, tlt_t0, tlt_t1, gld_t0, gld_t1, vwap, vol, vix_t0, vix_t2, view)
            prob = engine.predict_zero_copy(view)
            dispatch_ts_ns = time.perf_counter_ns()
            while not spsc.push_lockfree(prob, dispatch_ts_ns): pass 
            streamer._lock.acquire()
            streamer.t1_arr[:] = streamer.t0_arr[:]
            streamer._lock.release()
            time.sleep(0.5) 
    except KeyboardInterrupt: pass
    finally: streamer.stop_stream(); pool.close(); sys.exit(0)

def _execute(pnl_array):
    lock_hardware_core(2)
    spsc = SPSCRingBuffer("gorazd_ipc", create=False)
    router = Router(spsc, shadow=True)
    px = 510.0
    try:
        while True:
            px += np.random.choice([-0.5, 0.5])
            router.step(px, 0.20)
            pnl_array[0] = router.cap
            time.sleep(0.001)
    except KeyboardInterrupt: pass
    finally: 
        router.shutdown() # [!] FORCE LEDGER FLUSH ON EXIT
        sys.exit(0)

def _kill(pnl_array):
    lock_hardware_core(3)
    try:
        while True:
            if pnl_array[0] > 0 and (pnl_array[0] - settings.base_capital) / settings.base_capital <= -0.05:
                print("\n[FATAL RISK EXCEPTION] DRAWDOWN LIMIT BREACHED. LIQUIDATING.")
                sys.exit(1) 
            time.sleep(0.1)
    except KeyboardInterrupt: sys.exit(0)

def _drift():
    lock_hardware_core(4)
    context = zmq.Context()
    socket = context.socket(zmq.SUB)
    socket.connect("tcp://127.0.0.1:5555")
    socket.setsockopt_string(zmq.SUBSCRIBE, "GORAZD_METRICS")
    probabilities = []
    try:
        while True:
            msg = socket.recv_string()
            data = json.loads(msg.split(" ", 1)[1])
            probabilities.append(data["probability"])
            if len(probabilities) > 100: probabilities.pop(0)
            if len(probabilities) == 100 and np.std(probabilities) < 0.01:
                print("\n[!] DRIFT DETECTED: Model conviction variance collapsed.")
                probabilities.clear()
    except KeyboardInterrupt: sys.exit(0)

class Engine:
    def __init__(self, target: str = "SPY", model_file: str = "institutional_core.ubj"):
        self.target = target
        self.model_file = model_file

    def ignite(self):
        print("\n" + "="*65)
        print(f"    [⚙️] IGNITING 4-CORE INSTITUTIONAL ENGINE FOR {self.target}")
        print("="*65)
        spsc = SPSCRingBuffer("gorazd_ipc", create=True)
        pnl = mp.Array('d', [0.0]) 
        
        p1 = mp.Process(target=_ingest, args=(self.target, self.model_file))
        p2 = mp.Process(target=_execute, args=(pnl,))
        p3 = mp.Process(target=_kill, args=(pnl,))
        p4 = mp.Process(target=_drift) 
        
        p1.start(); p2.start(); p3.start(); p4.start()
        try:
            p1.join(); p2.join(); p3.join(); p4.join()
        except KeyboardInterrupt: 
            print("\n[+] TACTICAL SHUTDOWN SIGNAL RECEIVED. SEVERING IPC LINKS...")
            p1.terminate(); p2.terminate(); p3.terminate(); p4.terminate()
        finally:
            spsc.close()
            print("[+] ENGINE DETONATED CLEANLY. LEDGER SAVED.")