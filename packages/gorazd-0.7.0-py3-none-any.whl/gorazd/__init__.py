﻿from .config import settings
from .data.compiler import TensorCompiler
from .ml.trainer import Optimizer
from .execution.engine import Engine
from .execution.router import Router
from .execution.memory_pool import StaticMemoryPool as MemoryPool
from .execution.concurrency import SPSCRingBuffer as RingBuffer
from .ml.native_infer import NativeXGBoostEngine as NativeInfer
from .execution.affinity import lock_hardware_core as lock_core

__version__ = "0.5.0"
