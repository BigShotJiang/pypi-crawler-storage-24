﻿import os
import gorazd as gz

def run_compiler():
    gz.TensorCompiler(target="SPY").compile()

def run_trainer():
    target = "SPY_institutional_matrix.parquet"
    if not os.path.exists(os.path.join(os.getcwd(), "data_vault", target)) and not os.path.exists(target):
        print("[-] FATAL: Run gorazd-fetch first.")
        return
    gz.Optimizer().fit(target)

def run_ui():
    from gorazd.ui.dashboard import launch_ui
    launch_ui()

def run_engine():
    # Example script showing how easily a user can now run the daemon
    engine = gz.Engine(target="SPY")
    engine.ignite()
