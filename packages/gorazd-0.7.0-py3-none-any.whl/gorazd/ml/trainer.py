import xgboost as xgb
import optuna
import numpy as np
from pathlib import Path
import os
from gorazd.data.storage import ParquetVault
from gorazd.ml.physics import PurgedKFold, Microstructure

class Optimizer:
    def __init__(self):
        self.vault = ParquetVault()
        self.physics = Microstructure()
        self.cv = PurgedKFold()

    def _obj(self, preds: np.ndarray, dmatrix: xgb.DMatrix) -> tuple:
        target = dmatrix.get_label()
        prev = dmatrix.get_base_margin()
        if prev is None or len(prev) == 0: prev = np.zeros_like(preds) + 0.5 
        prob = 1.0 / (1.0 + np.exp(-preds))
        return self.physics.get_derivatives(prob, target, prob - prev)

    def _opt_loop(self, trial: optuna.Trial, X: np.ndarray, y: np.ndarray, epochs: np.ndarray) -> float:
        params = {
            "tree_method": "hist",
            "learning_rate": trial.suggest_float("lr", 1e-3, 0.1, log=True),
            "max_depth": trial.suggest_int("depth", 3, 7),
            "gamma": trial.suggest_float("gamma", 0.1, 5.0),
            "subsample": trial.suggest_float("sub", 0.5, 0.9),
            "colsample_bytree": trial.suggest_float("col", 0.5, 0.9),
            "disable_default_eval_metric": 1 
        }
        
        scores = []
        for tr_idx, st_idx, ev_idx in self.cv.split(epochs):
            dtr = xgb.DMatrix(X[tr_idx], label=y[tr_idx])
            dev = xgb.DMatrix(X[ev_idx], label=y[ev_idx])
            dtr.set_base_margin(np.zeros(len(tr_idx)) + 0.5)
            dev.set_base_margin(np.zeros(len(ev_idx)) + 0.5)
            
            def eval_pnl(preds, dm):
                prob = 1.0 / (1.0 + np.exp(-preds))
                return 'net_loss', float(-np.mean(1.0 - np.abs(prob - dm.get_label()) - (np.abs(prob - 0.5) * 0.02)))

            bst = xgb.train(params, dtr, evals=[(dev, "eval")], obj=self._obj, custom_metric=eval_pnl, early_stopping_rounds=15, verbose_eval=False)
            scores.append(bst.best_score)
        return float(np.mean(scores)) if scores else 0.0

    def fit(self, parquet_file: str, out_model: str = "core.ubj"):
        print(f"[+] OPTIMIZER: Fitting {parquet_file}")
        df = self.vault.extract_matrix(parquet_file)
        X = df.select(df.columns[:9]).to_numpy().astype(np.float32)
        y = df.select("Label").to_numpy().flatten().astype(np.int32)
        epochs = df.select("Epoch").to_numpy().flatten().astype(np.float64) * 86400.0
        
        study = optuna.create_study(direction="minimize")
        study.optimize(lambda t: self._opt_loop(t, X, y, epochs), n_trials=5)
        
        best = study.best_params
        best["disable_default_eval_metric"] = 1
        
        dm = xgb.DMatrix(X, label=y)
        dm.set_base_margin(np.zeros(len(X)) + 0.5) 
        bst = xgb.train(best, dm, num_boost_round=100, obj=self._obj)
        
        path = Path(os.getcwd()) / out_model
        bst.save_model(str(path))
        print(f"[+] MODEL BAKED: {path.name}")
