﻿import ctypes
import numpy as np
from pathlib import Path
import sys
import os

class NativeXGBoostEngine:
    def __init__(self, model_path: str):
        venv_base = Path(sys.executable).parent.parent
        self.dll_path = venv_base / "Lib" / "site-packages" / "xgboost" / "lib" / "xgboost.dll"
        
        if not self.dll_path.exists():
            self.is_dummy = True; return
            
        self.is_dummy = False
        self.lib = ctypes.cdll.LoadLibrary(str(self.dll_path))
        self.lib.XGBGetLastError.restype = ctypes.c_char_p
        self.lib.XGBoosterCreate.argtypes = [ctypes.c_void_p, ctypes.c_uint64, ctypes.POINTER(ctypes.c_void_p)]
        self.lib.XGBoosterLoadModel.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
        self.lib.XGDMatrixCreateFromMat.argtypes = [ctypes.c_void_p, ctypes.c_uint64, ctypes.c_uint64, ctypes.c_float, ctypes.POINTER(ctypes.c_void_p)]
        self.lib.XGBoosterPredict.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_uint, ctypes.c_int, ctypes.POINTER(ctypes.c_uint64), ctypes.POINTER(ctypes.POINTER(ctypes.c_float))]
        self.lib.XGDMatrixFree.argtypes = [ctypes.c_void_p]

        self.booster = ctypes.c_void_p()
        self._check_call(self.lib.XGBoosterCreate(None, 0, ctypes.byref(self.booster)))
        
        # Robust Path Resolution
        target_path = Path(os.getcwd()) / model_path
        if not target_path.exists(): target_path = Path(model_path) # Fallback to absolute
        
        self._check_call(self.lib.XGBoosterLoadModel(self.booster, str(target_path).encode('utf-8')))
        print(f"[+] NATIVE ENGINE: C-Matrix Locked. Mapped to {self.dll_path.name}")

    def _check_call(self, ret: int):
        if ret != 0: raise RuntimeError(f"[-] C-API EXCEPTION: {self.lib.XGBGetLastError().decode('utf-8')}")

    def predict_zero_copy(self, features: np.ndarray) -> float:
        if self.is_dummy: return 0.99
        if not features.flags['C_CONTIGUOUS'] or features.dtype != np.float32: features = np.ascontiguousarray(features, dtype=np.float32)
            
        dmatrix = ctypes.c_void_p()
        self._check_call(self.lib.XGDMatrixCreateFromMat(features.ctypes.data_as(ctypes.c_void_p), 1, features.shape[0], ctypes.c_float(np.nan), ctypes.byref(dmatrix)))
        
        out_len, out_result = ctypes.c_uint64(), ctypes.POINTER(ctypes.c_float)()
        self._check_call(self.lib.XGBoosterPredict(self.booster, dmatrix, ctypes.c_int(0), ctypes.c_uint(0), ctypes.c_int(0), ctypes.byref(out_len), ctypes.byref(out_result)))
        
        raw_logit = out_result[0]
        self.lib.XGDMatrixFree(dmatrix)
        return 1.0 / (1.0 + np.exp(-raw_logit))
