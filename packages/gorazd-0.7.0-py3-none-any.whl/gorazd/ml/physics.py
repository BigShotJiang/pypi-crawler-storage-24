import numpy as np

class PurgedKFold:
    def __init__(self, n_splits: int = 5, purge_sec: float = 1296000.0, embargo_sec: float = 1296000.0):
        self.n_splits = n_splits
        self.purge_sec = purge_sec
        self.embargo_sec = embargo_sec

    def split(self, epochs: np.ndarray):
        if len(epochs) < 100: return
        deltas = np.zeros_like(epochs)
        if len(epochs) > 1: deltas[1:] = np.minimum(epochs[1:] - epochs[:-1], 3600.0)
        
        cumulative_time = np.cumsum(deltas)
        step = cumulative_time[-1] / float(self.n_splits)
        
        partitions = [np.where((cumulative_time >= i * step) & (cumulative_time < ((i + 1) * step if i < self.n_splits - 1 else cumulative_time[-1] + 1.0)))[0] for i in range(self.n_splits)]

        for i in range(2, self.n_splits):
            stop_idx, eval_idx = partitions[i-1], partitions[i]
            if len(stop_idx) == 0 or len(eval_idx) == 0: continue
            train_raw = np.concatenate(partitions[:i-1])
            if len(train_raw) == 0: continue
                
            purged_train = train_raw[epochs[train_raw] <= (epochs[stop_idx[0]] - self.purge_sec)]
            embargoed_stop = stop_idx[epochs[stop_idx] <= (epochs[eval_idx[0]] - self.embargo_sec)]
            
            if len(purged_train) > 5 and len(embargoed_stop) > 0:
                yield purged_train, embargoed_stop, eval_idx

class Microstructure:
    def __init__(self, alpha_pen: float = 2.0, beta_pen: float = 5.0):
        self.alpha_pen = alpha_pen
        self.beta_pen = beta_pen

    def get_derivatives(self, prob: np.ndarray, target: np.ndarray, delta: np.ndarray, spread: float = 0.002) -> tuple:
        error = prob - target
        ev = (prob * target) - (np.abs(delta) * spread)
        
        clip = np.clip(-self.beta_pen * ev, -700.0, 700.0)
        s_pen = 1.0 / (1.0 + np.exp(clip))
        
        dL_dEV = -1.0 - (self.alpha_pen * self.beta_pen * s_pen)
        grad = error + (dL_dEV * spread * np.sign(delta))
        
        h_diag = self.alpha_pen * (self.beta_pen ** 2) * s_pen * (1.0 - s_pen)
        hess = np.maximum((prob * (1.0 - prob)) + (h_diag * spread), 1e-5)
        return grad, hess
