import polars as pl
import numpy as np
from pathlib import Path
from gorazd.data.gateway import DataGateway
from gorazd.data.storage import ParquetVault

class TensorCompiler:
    def __init__(self, target="SPY"):
        self.gateway = DataGateway()
        self.vault = ParquetVault()
        self.target = target
        self.assets = [target, 'QQQ', 'TLT', 'GLD']
        self.macro = '^VIX'

    def compile(self, start_date="2016-01-01") -> Path:
        print(f"[+] COMPILER: Building Tensors for {self.target}")
        raw_lfs = [self.gateway.fetch_tiingo_daily_lazy(a, start_date) for a in self.assets]
        vix_lf = self.gateway.fetch_fred_vix_lazy()
        vwap_lf = self.gateway.fetch_alpaca_sip_vwap(self.assets, start_date)

        df = raw_lfs[0]
        for i in range(1, len(raw_lfs)): df = df.join(raw_lfs[i], on='Date', how='full', coalesce=True)
        df = df.join(vwap_lf, on='Date', how='left').sort('Date').join_asof(vix_lf, on='Date', strategy='backward')

        adj = []
        for a in self.assets:
            s_mult = pl.col(f'{a}_Split').fill_null(1.0).shift(-1).fill_null(1.0).reverse().cum_prod().reverse()
            d_mult = pl.max_horizontal(1.0 - (pl.col(f'{a}_Div').fill_null(0.0) / (pl.col(a).shift(1) / pl.col(f'{a}_Split').fill_null(1.0))).fill_nan(0.0), 0.0001).shift(-1).fill_null(1.0).reverse().cum_prod().reverse()
            adj.extend([((pl.col(a) / s_mult) * d_mult).alias(a), ((pl.col(f'{a}_VWAP').fill_null(pl.col(a)) / s_mult) * d_mult).alias(f'{a}_VWAP')])
        df = df.with_columns(adj)

        feat = [(pl.col(a).log() - pl.col(a).shift(1).log()).alias(f"{a}_LogRet") for a in self.assets]
        feat.extend([
            (pl.col(f"{self.target}_VWAP") / pl.col(self.target).shift(1)).log().alias("VWAP_LogRet"),
            (pl.col(self.macro) - pl.col(self.macro).shift(2)).alias("VIX_Diff")
        ])
        
        df = df.with_columns(feat).with_columns([
            (pl.col(f'{self.target}_LogRet').rolling_std(14) * np.sqrt(252)).alias('Vol_14d'),
            (pl.col(f'{self.target}_LogRet') - pl.col('QQQ_LogRet')).alias('Spread_QQQ'),
            (pl.col(f'{self.target}_LogRet') - pl.col('TLT_LogRet')).alias('Spread_TLT'),
            (pl.col(f"{self.target}").shift(-1) > pl.col(f"{self.target}")).cast(pl.Int32).alias('Label'),
            pl.col('Date').cast(pl.Date).cast(pl.Int32).alias('Epoch')
        ])
        
        cols = [f"{self.target}_LogRet", "QQQ_LogRet", "TLT_LogRet", "GLD_LogRet", "VWAP_LogRet", "Vol_14d", "Spread_QQQ", "Spread_TLT", "VIX_Diff", "Label", "Epoch"]
        final_df = df.select(cols).drop_nulls().collect()
        
        out_file = f"{self.target}_institutional_matrix.parquet"
        return self.vault.lock_matrix(final_df, out_file)
