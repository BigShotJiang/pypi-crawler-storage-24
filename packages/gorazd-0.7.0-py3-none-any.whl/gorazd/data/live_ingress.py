import threading
import time
import numpy as np
import requests
import pandas as pd
import polars as pl
from gorazd.config import settings

class PhysicalLiveIngress:
    """
    T0 Terminal Parity Engine.
    Polls the live order book, calculates the dimensional parity scalar, 
    and streams the precise execution gaps into the lock-free memory ring.
    """
    def __init__(self, target_ticker: str = "SPY"):
        self.target = target_ticker
        self.is_running = False
        self._thread = None
        self._lock = threading.Lock()
        
        # Current Live State
        self.current_price = 0.0
        self.parity_scalar = 1.0
        
        # Pre-allocated arrays matching the C-Matrix Signature
        self.t0_arr = np.zeros(4, dtype=np.float64) # SPY, QQQ, TLT, GLD
        self.t1_arr = np.zeros(4, dtype=np.float64)
        self.vwap = 0.0
        self.vol_14d = 0.15
        self.vix_t0 = 15.0
        self.vix_t2 = 14.8

        self.headers = {'APCA-API-KEY-ID': settings.alpaca_api_key, 'APCA-API-SECRET-KEY': settings.alpaca_api_secret, 'Accept': 'application/json'}
        self._initialize_historical_baseline()

    def _initialize_historical_baseline(self):
        """Extracts T-1 Adjusted Close to calculate the parity scalar."""
        print(f"[+] INGRESS: Acquiring Physical T0 Parity baseline for {self.target}...")
        # In a fully deployed state, this reads the last row of your local Parquet file.
        # For demonstration of the live gap, we set synthetic baselines.
        self.t1_arr = np.array([510.0, 440.0, 95.0, 210.0])
        self.current_price = 510.0
        self.vwap = 510.0

    def _poll_live_websocket(self):
        """Simulates the network socket polling live Level 1 SIP data."""
        print("[+] INGRESS: Background physical network thread armed.")
        while self.is_running:
            # Simulate real-time SIP packet arrival
            tick_movement = np.random.choice([-0.25, 0.0, 0.25])
            
            with self._lock:
                self.current_price += tick_movement
                self.t0_arr[0] = self.current_price
                self.t0_arr[1] = self.t1_arr[1] + np.random.choice([-0.1, 0.1]) # QQQ
                self.t0_arr[2] = self.t1_arr[2] + np.random.choice([-0.05, 0.05]) # TLT
                self.t0_arr[3] = self.t1_arr[3] + np.random.choice([-0.05, 0.05]) # GLD
                
                # Exponential moving average to simulate live VWAP drift
                self.vwap = (self.vwap * 0.99) + (self.current_price * 0.01)

            time.sleep(0.5) # Throttle for API rate limits / terminal readability

    def start_stream(self):
        self.is_running = True
        self._thread = threading.Thread(target=self._poll_live_websocket, daemon=True)
        self._thread.start()

    def stop_stream(self):
        self.is_running = False
        if self._thread:
            self._thread.join()

    def get_latest_state(self):
        with self._lock:
            return (
                self.t0_arr[0], self.t1_arr[0], # SPY
                self.t0_arr[1], self.t1_arr[1], # QQQ
                self.t0_arr[2], self.t1_arr[2], # TLT
                self.t0_arr[3], self.t1_arr[3], # GLD
                self.vwap, self.vol_14d, self.vix_t0, self.vix_t2
            )
