import os
import io
import time
import requests
import polars as pl
from datetime import datetime, timezone
import pandas as pd
from gorazd.config import settings

class TiingoNode:
    def __init__(self):
        self.headers = {'Content-Type': 'application/json', 'Authorization': f'Token {settings.tiingo_api_key}'}

    def fetch_daily(self, symbol: str, start_date: str) -> pl.LazyFrame:
        print(f"    -> [TIINGO NODE] Extracting EOD Matrix for {symbol}...")
        url = f"https://api.tiingo.com/tiingo/daily/{symbol}/prices"
        res = requests.get(url, headers=self.headers, params={'startDate': start_date, 'format': 'csv'})
        if res.status_code != 200: raise ConnectionError(f"[-] Tiingo Failure [{symbol}]")
        return pl.read_csv(io.StringIO(res.text)).lazy().select([
            pl.col('date').str.slice(0, 10).str.to_date("%Y-%m-%d").alias('Date'),
            pl.col('open').alias(f'{symbol}_Raw_Open'), pl.col('high').alias(f'{symbol}_High'),
            pl.col('low').alias(f'{symbol}_Low'), pl.col('close').alias(f'{symbol}'),
            pl.col('volume').alias(f'{symbol}_Volume'), pl.col('splitFactor').alias(f'{symbol}_Split'),
            pl.col('divCash').alias(f'{symbol}_Div')
        ])

class AlpacaNode:
    def __init__(self):
        self.headers = {'APCA-API-KEY-ID': settings.alpaca_api_key, 'APCA-API-SECRET-KEY': settings.alpaca_api_secret, 'Accept': 'application/json'}

    def fetch_sip_vwap(self, symbols: list, start_date: str) -> pl.LazyFrame:
        print(f"    -> [ALPACA NODE] Compiling Physical 1Min SIP VWAP Tensor...")
        safe_start = max(datetime.strptime(start_date, "%Y-%m-%d"), datetime(2016, 1, 1))
        ny_now = pd.Timestamp.now(tz='UTC').tz_convert('America/New_York')
        url = "https://data.alpaca.markets/v2/stocks/bars"
        params = {'symbols': ",".join(symbols), 'timeframe': '1Min', 'start': safe_start.strftime("%Y-%m-%dT%H:%M:%SZ"), 'end': ny_now.tz_convert('UTC').strftime("%Y-%m-%dT%H:%M:%SZ"), 'limit': 10000, 'feed': 'sip', 'adjustment': 'raw'}
        
        all_bars, page_token = [], None
        with requests.Session() as session:
            session.headers.update(self.headers)
            while True:
                if page_token: params['page_token'] = page_token
                res = session.get(url, params=params)
                if res.status_code == 429: time.sleep(60); continue
                elif res.status_code != 200: break
                for sym, sym_bars in res.json().get('bars', {}).items():
                    for b in sym_bars: b['symbol'] = sym; all_bars.append(b)
                page_token = res.json().get('next_page_token')
                if not page_token: break
                time.sleep(0.3)

        if not all_bars: return pl.DataFrame({'Date': []}, schema={'Date': pl.Date}).lazy()
        df_bars = pl.DataFrame(all_bars).with_columns(pl.col("t").str.strptime(pl.Datetime, "%Y-%m-%dT%H:%M:%SZ").dt.replace_time_zone("UTC")).with_columns(pl.col("t").dt.convert_time_zone("America/New_York").alias("ny_time")).with_columns(pl.col("ny_time").dt.date().alias("Date"))
        df_vwap = df_bars.filter((pl.col("ny_time").dt.hour() >= 4) & ((pl.col("ny_time").dt.hour() < 9) | ((pl.col("ny_time").dt.hour() == 9) & (pl.col("ny_time").dt.minute() < 30)))).with_columns((pl.col("vw") * pl.col("v")).alias("price_volume")).group_by(["Date", "symbol"]).agg((pl.col("price_volume").sum() / pl.col("v").sum()).alias("VWAP"))
        return df_vwap.pivot(index="Date", columns="symbol", values="VWAP").rename({col: f"{col}_VWAP" for col in df_vwap.pivot(index="Date", columns="symbol", values="VWAP").columns if col != "Date"}).lazy()

class FredNode:
    def fetch_vix(self) -> pl.LazyFrame:
        print(f"    -> [FRED NODE] Routing Macro Volatility Structure...")
        res = requests.get("https://fred.stlouisfed.org/graph/fredgraph.csv?id=VIXCLS")
        if res.status_code != 200: raise ConnectionError("FRED API Failure.")
        return pl.read_csv(io.StringIO(res.text), null_values=["."]).lazy().select([(pl.col('observation_date').str.to_date("%Y-%m-%d") + pl.duration(days=1)).alias('Date'), pl.col('VIXCLS').cast(pl.Float64).alias('^VIX')]).drop_nulls().sort('Date')

class BloombergNode:
    """Stubbed B-Pipe connection for Equinix physical deployment."""
    def __init__(self):
        try:
            import blpapi
            self.active = True
            print("    -> [BLOOMBERG NODE] B-Pipe Socket Armed.")
        except ImportError:
            self.active = False
            print("    -> [BLOOMBERG NODE] blpapi not found. Awaiting Equinix installation.")

    def fetch_terminal_matrix(self, symbols: list, start_date: str) -> pl.LazyFrame:
        if not self.active: raise RuntimeError("Bloomberg B-Pipe offline.")
        # Physical C++ Desktop API interaction would execute here.
        return pl.DataFrame({'Date': []}, schema={'Date': pl.Date}).lazy()

class DataGateway:
    """
    The Master Orchestrator. Evaluates config and routes to the correct physical nodes.
    """
    def __init__(self):
        self.mode = settings.data_source
        self.tiingo = TiingoNode()
        self.alpaca = AlpacaNode()
        self.fred = FredNode()
        self.bloomberg = BloombergNode()

    def fetch_tiingo_daily_lazy(self, symbol: str, start_date: str) -> pl.LazyFrame:
        if self.mode == "BLOOMBERG": return self.bloomberg.fetch_terminal_matrix([symbol], start_date)
        return self.tiingo.fetch_daily(symbol, start_date)

    def fetch_alpaca_sip_vwap(self, symbols: list, start_date: str) -> pl.LazyFrame:
        if self.mode == "BLOOMBERG": return self.bloomberg.fetch_terminal_matrix(symbols, start_date)
        return self.alpaca.fetch_sip_vwap(symbols, start_date)

    def fetch_fred_vix_lazy(self) -> pl.LazyFrame:
        return self.fred.fetch_vix()
