from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field

class InstitutionalSettings(BaseSettings):
    """
    Absolute Environment Matrix.
    """
    # Execution Mode
    data_source: str = Field(default="RETAIL", description="Set to 'BLOOMBERG' for physical B-Pipe ingress")
    
    # Retail API Keys
    tiingo_api_key: str = Field(default="UNSET", description="Tiingo Data API Key")
    alpaca_api_key: str = Field(default="UNSET", description="Alpaca Trading Key")
    alpaca_api_secret: str = Field(default="UNSET", description="Alpaca Trading Secret")
    
    # Structural Risk Constraints
    max_leverage: float = Field(default=1.5, le=2.0, description="Absolute Leverage Ceiling")
    base_capital: float = Field(default=250000.0, ge=25000.0, description="Starting Capital")
    
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = InstitutionalSettings()
