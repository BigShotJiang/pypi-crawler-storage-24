"""
HLA-Compass Python SDK

SDK for developing modules on the HLA-Compass platform.
"""

from ._version import __version__

# Authentication
from .auth import Auth, AuthError

# API client
from .client import APIClient, APIError

# Runtime context
from .context import (
    ContextValidationError,
    CreditReservation,
    RuntimeContext,
    WorkflowMetadata,
)

# Data access classes
from .data import DataAccessError, DataClient, HLAData, PeptideData, ProteinData, SampleData

# Core module base class
from .module import ExecutionTimeoutError, Module, ModuleError, ValidationError

# Storage utilities
from .storage import Storage, StorageError

# Types
from .types import (
    ComputeType,
    ExecutionContext,
    JobStatus,
    ModuleInput,
    ModuleOutput,
    ModuleType,
)

__all__ = [
    # Version
    "__version__",
    # Core classes
    "Module",
    "ModuleError",
    "ValidationError",
    "ExecutionTimeoutError",
    # API client
    "APIClient",
    "APIError",
    # Data access
    "DataClient",
    "DataAccessError",
    "PeptideData",
    "ProteinData",
    "SampleData",
    "HLAData",
    # Auth
    "Auth",
    "AuthError",
    # Storage
    "Storage",
    "StorageError",
    # Context
    "RuntimeContext",
    "ContextValidationError",
    "CreditReservation",
    "WorkflowMetadata",
    # Types
    "ExecutionContext",
    "ModuleInput",
    "ModuleOutput",
    "JobStatus",
    "ComputeType",
    "ModuleType",
]
