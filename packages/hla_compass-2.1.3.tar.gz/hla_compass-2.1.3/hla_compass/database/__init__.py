"""
Database access module for HLA-Compass SDK

Provides direct database access for modules running in the Lambda environment
with security constraints and optimized query patterns.
"""

from .scientific_query import ScientificQuery
from .security import (
    ALLOWED_SCIENTIFIC_TABLES,
    SCIENTIFIC_SCHEMA,
    QuerySecurityError,
    enforce_limits,
    validate_readonly_query,
)

__all__ = [
    "ScientificQuery",
    "ALLOWED_SCIENTIFIC_TABLES",
    "SCIENTIFIC_SCHEMA",
    "validate_readonly_query",
    "enforce_limits",
    "QuerySecurityError",
]
