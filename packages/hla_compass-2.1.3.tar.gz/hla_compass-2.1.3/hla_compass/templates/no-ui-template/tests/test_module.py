"""Basic tests for the module."""

from __future__ import annotations

from backend.main import NoUIModule


def test_module_runs_with_sample_input(sample_input, test_context):
    """Module executes successfully with the sample input."""
    module = NoUIModule(manifest_path="manifest.json")
    result = module.run(sample_input, test_context)
    assert result["status"] == "success"


def test_module_has_required_metadata(manifest):
    """Manifest contains required fields."""
    assert manifest["name"]
    assert manifest["version"]
    assert manifest["execution"]["entrypoint"]
