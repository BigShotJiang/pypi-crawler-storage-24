# CLAUDE.md — HLA-Compass MCP Module

## What This Is

An HLA-Compass module scaffold intended to run both on the platform and as a
local MCP server for AI clients.

## Key Commands

```bash
hla-compass validate
hla-compass test --input examples/sample_input.json
pytest
hla-compass mcp schema
hla-compass mcp serve
```

For platform publishing, use the image-first flow documented in `SKILL.md`.

## Architecture

```
Module.__init__  ->  run(input, context)  ->  validate_inputs  ->  execute  ->  success/error
```

- Extend `hla_compass.Module`, implement `execute()`.
- Keep `Input` as a typed Pydantic model.
- Support both normal platform execution and MCP local serving.

## Complete Reference

See **SKILL.md** in this directory for the runtime contract, MCP commands, and publish workflow.
