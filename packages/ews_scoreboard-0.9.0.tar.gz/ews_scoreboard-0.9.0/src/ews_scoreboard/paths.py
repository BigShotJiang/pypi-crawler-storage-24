"""
Path resolution for EWS Scoreboard.

SQL DDL files are bundled inside the package.
Working directories (external_data, db, outputs) are resolved
relative to the current working directory.
"""

from pathlib import Path
import importlib.resources


def get_ddl_path() -> Path:
    """Return the path to bundled SQL DDL files."""
    return Path(importlib.resources.files("ews_scoreboard") / "sql" / "ddl")


def get_data_readme() -> Path:
    """Return the path to bundled VERI_KOPYALA.txt."""
    return Path(importlib.resources.files("ews_scoreboard") / "data" / "VERI_KOPYALA.txt")


def get_notebook_path() -> Path:
    """Return the path to bundled pipeline notebook."""
    return Path(importlib.resources.files("ews_scoreboard") / "data" / "ews_pipeline.ipynb")


def get_notebooks_dir() -> Path:
    """Return the path to directory containing all bundled notebooks."""
    return Path(importlib.resources.files("ews_scoreboard") / "data")


def get_template_path() -> Path:
    """Return the path to bundled Jinja2 HTML template."""
    return Path(importlib.resources.files("ews_scoreboard") / "data" / "yis_skor_tablosu_ccode_v113_html.j2")


def get_work_dir(base: Path = None) -> Path:
    """Return the working directory (default: CWD)."""
    return Path(base) if base else Path.cwd()


def get_source_dir(base: Path = None) -> Path:
    return get_work_dir(base) / "external_data"


def get_db_path(base: Path = None) -> Path:
    return get_work_dir(base) / "db" / "ews.duckdb"


def get_output_dir(base: Path = None) -> Path:
    return get_work_dir(base) / "outputs"
