# tisit-cli

Terminal-native client for the [TISIT](https://tisit.ai) learning platform. If you can do it on the web, you can do it from the shell.

## Install

```bash
pip install tisit-cli
```

## Quick Start

```bash
# Authenticate (get your API token from tisit.ai settings)
tisit login

# Explore your knowledge
tisit note list
tisit search "machine learning"
tisit chat ask "What are transformers?"

# Add content
tisit note add "Neural Networks" "Deep Learning"
tisit paper add https://arxiv.org/pdf/1706.03762
tisit article add https://example.com/article
tisit video add https://youtube.com/watch?v=abc
tisit book search "Deep Learning"

# Intelligence monitoring
tisit radar status
tisit radar topic add "AI Safety" --keywords "alignment,safety"

# Knowledge graph
tisit graph stats
tisit graph neighbors "machine learning"
tisit graph paths "Neural Networks" "NLP"

# Deep dive learning
tisit focus create "Quantum Computing"
tisit focus list
```

## Commands

| Command | Description |
|---------|-------------|
| `tisit login/logout/whoami` | Authentication |
| `tisit status` | System health check |
| `tisit note add/list/view/delete` | Learning notes |
| `tisit paper add/list/view/delete` | Research papers |
| `tisit article add/list/view/delete` | Web articles |
| `tisit video add/list/view/delete` | YouTube videos |
| `tisit tweet add/list/view/delete` | Tweets / X posts |
| `tisit book search/add/list/view/delete` | Books |
| `tisit podcast add/list/view/delete` | Podcast episodes |
| `tisit patent add/list/view/delete` | Patents |
| `tisit search "query"` | Semantic search |
| `tisit browse --type notes` | Unified content browsing |
| `tisit chat` | Interactive RAG chat |
| `tisit chat ask "question"` | One-shot question |
| `tisit radar status/topic/run/source` | Radar sweep monitoring |
| `tisit graph stats/neighbors/paths` | Knowledge graph |
| `tisit focus list/create/view/delete` | Focus mode (deep dive) |

All commands support `--json` for scripted output.

## Configuration

Config is stored at `~/.tisit/config.toml`. Override the server URL:

```bash
tisit login --api-url https://your-server.com
# or
export TISIT_API_URL=https://your-server.com
```

## License

MIT
