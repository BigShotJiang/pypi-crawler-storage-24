"""Token storage — keyring with file fallback."""
import os
import stat
from pathlib import Path

SERVICE_NAME = "tisit-cli"
TOKEN_FILE = Path.home() / ".tisit" / "token"


def store_token(token: str) -> None:
    """Store API token securely."""
    try:
        import keyring
        keyring.set_password(SERVICE_NAME, "api_token", token)
        # Clean up file if migrating to keyring
        if TOKEN_FILE.exists():
            TOKEN_FILE.unlink()
        return
    except Exception:
        pass
    # File fallback
    TOKEN_FILE.parent.mkdir(parents=True, exist_ok=True)
    TOKEN_FILE.write_text(token)
    os.chmod(TOKEN_FILE, stat.S_IRUSR | stat.S_IWUSR)


def get_token() -> str | None:
    """Retrieve stored API token."""
    try:
        import keyring
        token = keyring.get_password(SERVICE_NAME, "api_token")
        if token:
            return token
    except Exception:
        pass
    if TOKEN_FILE.exists():
        return TOKEN_FILE.read_text().strip()
    return None


def delete_token() -> None:
    """Remove stored API token."""
    try:
        import keyring
        keyring.delete_password(SERVICE_NAME, "api_token")
    except Exception:
        pass
    if TOKEN_FILE.exists():
        TOKEN_FILE.unlink()


def validate_token_format(token: str) -> bool:
    """Check that the token has the expected tsk_ prefix and length."""
    return token.startswith("tsk_") and len(token) >= 20
