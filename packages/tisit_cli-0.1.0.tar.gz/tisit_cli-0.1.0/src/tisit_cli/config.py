"""Configuration management — loads/saves ~/.tisit/config.toml."""
import os
import sys
from pathlib import Path

import tomli_w

if sys.version_info >= (3, 11):
    import tomllib
else:
    import tomli as tomllib

from .exceptions import ConfigError

DEFAULT_API_URL = "https://tisit.ai"
CONFIG_DIR = Path.home() / ".tisit"
CONFIG_FILE = CONFIG_DIR / "config.toml"


class Config:
    """TOML-backed configuration with env var overrides."""

    def __init__(self):
        self._data = {"api_url": DEFAULT_API_URL, "format": "table"}
        self.load()

    def load(self):
        if CONFIG_FILE.exists():
            try:
                with open(CONFIG_FILE, "rb") as f:
                    stored = tomllib.load(f)
                self._data.update(stored)
            except Exception as exc:
                raise ConfigError(f"Failed to read config: {exc}")
        # Env var override
        env_url = os.environ.get("TISIT_API_URL")
        if env_url:
            self._data["api_url"] = env_url.rstrip("/")

    def save(self):
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
        with open(CONFIG_FILE, "wb") as f:
            tomli_w.dump(self._data, f)

    def get(self, key, default=None):
        return self._data.get(key, default)

    def set(self, key, value):
        self._data[key] = value

    @property
    def api_url(self):
        return self._data["api_url"].rstrip("/")
