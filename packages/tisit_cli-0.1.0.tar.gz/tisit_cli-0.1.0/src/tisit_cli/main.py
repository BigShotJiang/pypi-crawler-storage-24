"""TISIT CLI entry point."""
import typer

from . import __version__
from .commands.auth_commands import login, logout, whoami
from .commands.note_commands import note_app
from .commands.paper_commands import paper_app
from .commands.article_commands import article_app
from .commands.video_commands import video_app
from .commands.tweet_commands import tweet_app
from .commands.book_commands import book_app
from .commands.podcast_commands import podcast_app
from .commands.patent_commands import patent_app
from .commands.chat_commands import chat_app
from .commands.radar_commands import radar_app
from .commands.graph_commands import graph_app
from .commands.focus_commands import focus_app
from .commands.browse_commands import browse
from .commands.status_commands import status
from .commands.search_commands import search

app = typer.Typer(
    name="tisit",
    help="TISIT CLI - Learn anything, explained intelligently.",
    no_args_is_help=True,
)


def version_callback(value: bool):
    if value:
        typer.echo(f"tisit-cli {__version__}")
        raise typer.Exit()


@app.callback()
def main(
    version: bool = typer.Option(
        None, "--version", "-v",
        callback=version_callback, is_eager=True,
        help="Show version and exit.",
    ),
):
    """TISIT CLI - terminal-native client for the TISIT learning platform."""


# Auth commands at top level
app.command()(login)
app.command()(logout)
app.command()(whoami)

# Sub-command groups
app.add_typer(note_app, name="note")
app.add_typer(paper_app, name="paper")
app.add_typer(article_app, name="article")
app.add_typer(video_app, name="video")
app.add_typer(tweet_app, name="tweet")
app.add_typer(book_app, name="book")
app.add_typer(podcast_app, name="podcast")
app.add_typer(patent_app, name="patent")
app.add_typer(chat_app, name="chat")
app.add_typer(radar_app, name="radar")
app.add_typer(graph_app, name="graph")
app.add_typer(focus_app, name="focus")

# Top-level commands
app.command()(search)
app.command()(browse)
app.command()(status)
