"""HTTP API client — all communication with the TISIT server goes through here."""
import httpx

from . import __version__
from .exceptions import APIError, AuthenticationError, NotFoundError


class TisitClient:
    """Synchronous HTTP client for the TISIT API v1."""

    def __init__(self, base_url: str, token: str):
        self._base = base_url.rstrip("/") + "/api/v1"
        self._http = httpx.Client(
            base_url=self._base,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
                "User-Agent": f"tisit-cli/{__version__}",
            },
            timeout=30.0,
        )

    def close(self):
        self._http.close()

    # ── internal ──────────────────────────────────────────────────────

    @staticmethod
    def _parse_json(resp):
        """Safely parse JSON from response, returning {} on empty/invalid."""
        if not resp.content or not resp.content.strip():
            return {}
        try:
            return resp.json()
        except Exception:
            return {}

    def _request(self, method, path, **kwargs):
        """Issue request and unwrap the API envelope."""
        try:
            resp = self._http.request(method, path, **kwargs)
        except httpx.ConnectError:
            raise APIError(
                "Cannot reach the TISIT server. Is it running?",
                status_code=0,
            )
        except httpx.TimeoutException:
            raise APIError("Request timed out", status_code=0)

        if resp.status_code == 401:
            raise AuthenticationError(
                "Token expired or invalid. Run: tisit login"
            )
        if resp.status_code == 403:
            raise AuthenticationError(
                "Insufficient permissions for this operation"
            )
        if resp.status_code == 404:
            body = self._parse_json(resp)
            msg = body.get("error", {}).get("message", "Resource not found")
            raise NotFoundError(msg)

        body = self._parse_json(resp)

        if not body.get("success", False):
            err = body.get("error", {})
            raise APIError(
                err.get("message", f"API error (HTTP {resp.status_code})"),
                status_code=resp.status_code,
                detail=err.get("errors"),
            )

        return body.get("data"), body.get("meta")

    # ── public methods ────────────────────────────────────────────────

    def status(self):
        data, _ = self._request("GET", "/status")
        return data

    def list_notes(self, *, q=None, category=None, domain=None,
                   sort="created_at", order="desc", page=1, per_page=20):
        params = {"sort": sort, "order": order, "page": page,
                  "per_page": per_page}
        if q:
            params["q"] = q
        if category:
            params["category"] = category
        if domain:
            params["domain"] = domain
        data, meta = self._request("GET", "/notes", params=params)
        return data, meta

    def get_note(self, note_id: int):
        data, _ = self._request("GET", f"/notes/{note_id}")
        return data

    def create_note(self, term: str, context: str):
        data, _ = self._request(
            "POST", "/notes", json={"term": term, "context": context}
        )
        return data

    def delete_note(self, note_id: int):
        data, _ = self._request("DELETE", f"/notes/{note_id}")
        return data

    # ── papers ─────────────────────────────────────────────────────

    def list_papers(self, *, q=None, sort="uploaded_at", order="desc",
                    page=1, per_page=20):
        params = {"sort": sort, "order": order, "page": page,
                  "per_page": per_page}
        if q:
            params["q"] = q
        data, meta = self._request("GET", "/papers", params=params)
        return data, meta

    def get_paper(self, paper_id: int):
        data, _ = self._request("GET", f"/papers/{paper_id}")
        return data

    def add_paper(self, url: str, *, title=None, authors=None):
        payload = {"url": url}
        if title:
            payload["title"] = title
        if authors:
            payload["authors"] = authors
        data, _ = self._request("POST", "/papers", json=payload)
        return data

    def delete_paper(self, paper_id: int):
        data, _ = self._request("DELETE", f"/papers/{paper_id}")
        return data

    # ── articles ───────────────────────────────────────────────────

    def list_articles(self, *, q=None, sort="fetched_at", order="desc",
                      page=1, per_page=20):
        params = {"sort": sort, "order": order, "page": page,
                  "per_page": per_page}
        if q:
            params["q"] = q
        data, meta = self._request("GET", "/articles", params=params)
        return data, meta

    def get_article(self, article_id: int):
        data, _ = self._request("GET", f"/articles/{article_id}")
        return data

    def add_article(self, url: str):
        data, _ = self._request("POST", "/articles", json={"url": url})
        return data

    def delete_article(self, article_id: int):
        data, _ = self._request("DELETE", f"/articles/{article_id}")
        return data

    # ── videos ─────────────────────────────────────────────────────

    def list_videos(self, *, q=None, sort="created_at", order="desc",
                    page=1, per_page=20):
        params = {"sort": sort, "order": order, "page": page,
                  "per_page": per_page}
        if q:
            params["q"] = q
        data, meta = self._request("GET", "/videos", params=params)
        return data, meta

    def get_video(self, video_id: int):
        data, _ = self._request("GET", f"/videos/{video_id}")
        return data

    def add_video(self, url: str):
        data, _ = self._request("POST", "/videos", json={"url": url})
        return data

    def delete_video(self, video_id: int):
        data, _ = self._request("DELETE", f"/videos/{video_id}")
        return data

    # ── tweets ─────────────────────────────────────────────────────

    def list_tweets(self, *, q=None, sort="created_at", order="desc",
                    page=1, per_page=20):
        params = {"sort": sort, "order": order, "page": page,
                  "per_page": per_page}
        if q:
            params["q"] = q
        data, meta = self._request("GET", "/tweets", params=params)
        return data, meta

    def get_tweet(self, tweet_id: int):
        data, _ = self._request("GET", f"/tweets/{tweet_id}")
        return data

    def add_tweet(self, url: str):
        data, _ = self._request("POST", "/tweets", json={"url": url})
        return data

    def delete_tweet(self, tweet_id: int):
        data, _ = self._request("DELETE", f"/tweets/{tweet_id}")
        return data

    # ── books ──────────────────────────────────────────────────────

    def search_books(self, *, title="", author="", limit=10):
        params = {"limit": limit}
        if title:
            params["title"] = title
        if author:
            params["author"] = author
        data, meta = self._request("GET", "/books/search", params=params)
        return data, meta

    def list_books(self, *, q=None, sort="added_at", order="desc",
                   page=1, per_page=20):
        params = {"sort": sort, "order": order, "page": page,
                  "per_page": per_page}
        if q:
            params["q"] = q
        data, meta = self._request("GET", "/books", params=params)
        return data, meta

    def get_book(self, book_id: int):
        data, _ = self._request("GET", f"/books/{book_id}")
        return data

    def add_book(self, title: str, *, authors=None, isbn_13=None,
                 google_books_id=None, description=None):
        payload = {"title": title}
        if authors:
            payload["authors"] = authors
        if isbn_13:
            payload["isbn_13"] = isbn_13
        if google_books_id:
            payload["google_books_id"] = google_books_id
        if description:
            payload["description"] = description
        data, _ = self._request("POST", "/books", json=payload)
        return data

    def delete_book(self, book_id: int):
        data, _ = self._request("DELETE", f"/books/{book_id}")
        return data

    # ── podcasts ───────────────────────────────────────────────────

    def list_podcasts(self, *, q=None, sort="created_at", order="desc",
                      page=1, per_page=20):
        params = {"sort": sort, "order": order, "page": page,
                  "per_page": per_page}
        if q:
            params["q"] = q
        data, meta = self._request("GET", "/podcasts", params=params)
        return data, meta

    def get_podcast(self, podcast_id: int):
        data, _ = self._request("GET", f"/podcasts/{podcast_id}")
        return data

    def add_podcast(self, url: str):
        data, _ = self._request("POST", "/podcasts", json={"url": url})
        return data

    def delete_podcast(self, podcast_id: int):
        data, _ = self._request("DELETE", f"/podcasts/{podcast_id}")
        return data

    # ── patents ────────────────────────────────────────────────────

    def list_patents(self, *, q=None, sort="fetched_at", order="desc",
                     page=1, per_page=20):
        params = {"sort": sort, "order": order, "page": page,
                  "per_page": per_page}
        if q:
            params["q"] = q
        data, meta = self._request("GET", "/patents", params=params)
        return data, meta

    def get_patent(self, patent_id: int):
        data, _ = self._request("GET", f"/patents/{patent_id}")
        return data

    def add_patent(self, *, url=None, patent_number=None):
        payload = {}
        if url:
            payload["url"] = url
        if patent_number:
            payload["patent_number"] = patent_number
        data, _ = self._request("POST", "/patents", json=payload)
        return data

    def delete_patent(self, patent_id: int):
        data, _ = self._request("DELETE", f"/patents/{patent_id}")
        return data

    # ── chat ──────────────────────────────────────────────────────

    def chat_ask(self, question: str, *, session_id=None):
        payload = {"question": question}
        if session_id:
            payload["session_id"] = session_id
        data, _ = self._request("POST", "/chat/ask", json=payload)
        return data

    # ── radar sweep ────────────────────────────────────────────────

    def radar_status(self):
        data, _ = self._request("GET", "/radar/status")
        return data

    def list_watch_topics(self):
        data, _ = self._request("GET", "/radar/topics")
        return data

    def create_watch_topic(self, topic: str, keywords=None):
        payload = {"topic": topic}
        if keywords:
            payload["keywords"] = keywords
        data, _ = self._request("POST", "/radar/topics", json=payload)
        return data

    def delete_watch_topic(self, topic_id: int):
        data, _ = self._request("DELETE", f"/radar/topics/{topic_id}")
        return data

    def get_sweep_run(self, run_id: int):
        data, _ = self._request("GET", f"/radar/runs/{run_id}")
        return data

    def accept_source(self, source_id: int):
        data, _ = self._request("POST", f"/radar/sources/{source_id}/accept")
        return data

    def ignore_source(self, source_id: int):
        data, _ = self._request("POST", f"/radar/sources/{source_id}/ignore")
        return data

    # ── knowledge graph ────────────────────────────────────────────

    def graph_stats(self):
        data, _ = self._request("GET", "/graph/stats")
        return data

    def graph_neighbors(self, term: str, *, limit=10):
        data, meta = self._request(
            "GET", f"/graph/neighbors/{term}", params={"limit": limit}
        )
        return data, meta

    def graph_paths(self, source: str, target: str, *, max_depth=3):
        data, meta = self._request(
            "POST", "/graph/paths",
            json={"source": source, "target": target, "max_depth": max_depth},
        )
        return data, meta

    # ── focus mode ─────────────────────────────────────────────────

    def list_focus_bubbles(self):
        data, _ = self._request("GET", "/focus")
        return data

    def get_focus_bubble(self, bubble_id: int):
        data, _ = self._request("GET", f"/focus/{bubble_id}")
        return data

    def create_focus_bubble(self, topic: str):
        data, _ = self._request("POST", "/focus", json={"topic": topic})
        return data

    def delete_focus_bubble(self, bubble_id: int):
        data, _ = self._request("DELETE", f"/focus/{bubble_id}")
        return data

    def add_focus_concept(self, bubble_id: int, name: str, *,
                          definition=None, category="term"):
        payload = {"name": name, "category": category}
        if definition:
            payload["definition"] = definition
        data, _ = self._request(
            "POST", f"/focus/{bubble_id}/concepts", json=payload
        )
        return data

    # ── search ────────────────────────────────────────────────────

    def search(self, query: str, *, type="all", limit=10):
        params = {"q": query, "type": type, "limit": limit}
        data, meta = self._request("GET", "/search", params=params)
        return data, meta
