"""Custom exception hierarchy for the TISIT CLI."""


class TisitCLIError(Exception):
    """Base exception for all CLI errors."""


class AuthenticationError(TisitCLIError):
    """Raised when authentication fails (401/403)."""


class APIError(TisitCLIError):
    """Raised on non-2xx API responses."""

    def __init__(self, message, status_code=None, detail=None):
        self.status_code = status_code
        self.detail = detail
        super().__init__(message)


class NotFoundError(APIError):
    """Raised when a resource is not found (404)."""

    def __init__(self, message="Resource not found"):
        super().__init__(message, status_code=404)


class ConfigError(TisitCLIError):
    """Raised on configuration problems."""
