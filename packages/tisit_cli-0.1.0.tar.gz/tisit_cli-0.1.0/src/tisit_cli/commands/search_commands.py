"""Search command."""
import json

import typer

from ..auth import get_token
from ..client import TisitClient
from ..config import Config
from ..display import print_error, print_search_results
from ..exceptions import AuthenticationError, APIError


def search(
    query: str = typer.Argument(..., help="Search query"),
    type: str = typer.Option("all", "--type", "-t",
                             help="all, notes, papers, or articles"),
    limit: int = typer.Option(10, "--limit", "-l", help="Max results (1-50)"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Semantic search across your knowledge base."""
    token = get_token()
    if not token:
        print_error("Not logged in. Run: tisit login")
        raise typer.Exit(code=1)

    cfg = Config()
    client = TisitClient(cfg.api_url, token)
    try:
        results, meta = client.search(query, type=type, limit=limit)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps({"data": results, "meta": meta}, indent=2, default=str))
    else:
        if not results:
            print_error("No results found.")
        else:
            print_search_results(results, meta)
