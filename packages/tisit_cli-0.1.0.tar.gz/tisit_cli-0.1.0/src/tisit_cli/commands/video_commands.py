"""Video commands: add, list, view, delete."""
import json
from typing import Optional

import typer

from ..auth import get_token
from ..client import TisitClient
from ..config import Config
from ..display import (
    print_error, print_video_detail, print_video_table,
    print_success,
)
from ..exceptions import AuthenticationError, APIError, NotFoundError

video_app = typer.Typer(help="Manage your YouTube videos")


def _get_client() -> TisitClient:
    token = get_token()
    if not token:
        print_error("Not logged in. Run: tisit login")
        raise typer.Exit(code=1)
    cfg = Config()
    return TisitClient(cfg.api_url, token)


@video_app.command("list")
def video_list(
    query: Optional[str] = typer.Option(None, "--query", "-q", help="Search title or channel"),
    sort: str = typer.Option("created_at", "--sort", "-s", help="Sort by: created_at, title"),
    order: str = typer.Option("desc", "--order", "-o", help="asc or desc"),
    page: int = typer.Option(1, "--page", "-p"),
    per_page: int = typer.Option(20, "--per-page"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """List your YouTube videos."""
    client = _get_client()
    try:
        videos, meta = client.list_videos(
            q=query, sort=sort, order=order, page=page, per_page=per_page,
        )
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps({"data": videos, "meta": meta}, indent=2, default=str))
    else:
        if not videos:
            print_error("No videos found.")
        else:
            print_video_table(videos, meta)


@video_app.command("view")
def video_view(
    video_id: int = typer.Argument(..., help="Video ID"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """View a video in detail."""
    client = _get_client()
    try:
        video = client.get_video(video_id)
    except NotFoundError:
        print_error(f"Video {video_id} not found.")
        raise typer.Exit(code=1)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(video, indent=2, default=str))
    else:
        print_video_detail(video)


@video_app.command("add")
def video_add(
    url: str = typer.Argument(..., help="YouTube video URL"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Add a YouTube video by URL (async — queued for processing)."""
    client = _get_client()
    try:
        data = client.add_video(url)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(data, indent=2, default=str))
    else:
        if data.get("is_duplicate"):
            print_success(f"Video already exists (ID: {data['video_id']}).")
        else:
            print_success(
                f"Video queued for processing (ID: {data['video_id']}).\n"
                f"  Check status with: tisit video view {data['video_id']}"
            )


@video_app.command("delete")
def video_delete(
    video_id: int = typer.Argument(..., help="Video ID to delete"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Delete a video."""
    if not yes:
        confirm = typer.confirm(f"Delete video {video_id}?")
        if not confirm:
            raise typer.Abort()

    client = _get_client()
    try:
        client.delete_video(video_id)
    except NotFoundError:
        print_error(f"Video {video_id} not found.")
        raise typer.Exit(code=1)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    print_success(f"Video {video_id} deleted.")
