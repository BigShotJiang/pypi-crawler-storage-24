"""Podcast commands: add, list, view, delete."""
import json
from typing import Optional

import typer

from ..auth import get_token
from ..client import TisitClient
from ..config import Config
from ..display import (
    print_error, print_podcast_detail, print_podcast_table,
    print_success,
)
from ..exceptions import AuthenticationError, APIError, NotFoundError

podcast_app = typer.Typer(help="Manage your podcast episodes")


def _get_client() -> TisitClient:
    token = get_token()
    if not token:
        print_error("Not logged in. Run: tisit login")
        raise typer.Exit(code=1)
    cfg = Config()
    return TisitClient(cfg.api_url, token)


@podcast_app.command("list")
def podcast_list(
    query: Optional[str] = typer.Option(None, "--query", "-q", help="Search title or podcast name"),
    sort: str = typer.Option("created_at", "--sort", "-s"),
    order: str = typer.Option("desc", "--order", "-o"),
    page: int = typer.Option(1, "--page", "-p"),
    per_page: int = typer.Option(20, "--per-page"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """List your podcast episodes."""
    client = _get_client()
    try:
        podcasts, meta = client.list_podcasts(
            q=query, sort=sort, order=order, page=page, per_page=per_page,
        )
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps({"data": podcasts, "meta": meta}, indent=2, default=str))
    else:
        if not podcasts:
            print_error("No podcast episodes found.")
        else:
            print_podcast_table(podcasts, meta)


@podcast_app.command("view")
def podcast_view(
    podcast_id: int = typer.Argument(..., help="Podcast episode ID"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """View a podcast episode in detail."""
    client = _get_client()
    try:
        podcast = client.get_podcast(podcast_id)
    except NotFoundError:
        print_error(f"Podcast episode {podcast_id} not found.")
        raise typer.Exit(code=1)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(podcast, indent=2, default=str))
    else:
        print_podcast_detail(podcast)


@podcast_app.command("add")
def podcast_add(
    url: str = typer.Argument(..., help="Podcast episode URL (Spotify, Apple, RSS)"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Add a podcast episode by URL (async — queued for processing)."""
    client = _get_client()
    try:
        data = client.add_podcast(url)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(data, indent=2, default=str))
    else:
        if data.get("is_duplicate"):
            print_success(f"Podcast episode already exists (ID: {data['podcast_id']}).")
        else:
            print_success(
                f"Podcast episode queued for processing (ID: {data['podcast_id']}).\n"
                f"  Check status with: tisit podcast view {data['podcast_id']}"
            )


@podcast_app.command("delete")
def podcast_delete(
    podcast_id: int = typer.Argument(..., help="Podcast episode ID to delete"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Delete a podcast episode."""
    if not yes:
        confirm = typer.confirm(f"Delete podcast episode {podcast_id}?")
        if not confirm:
            raise typer.Abort()

    client = _get_client()
    try:
        client.delete_podcast(podcast_id)
    except NotFoundError:
        print_error(f"Podcast episode {podcast_id} not found.")
        raise typer.Exit(code=1)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    print_success(f"Podcast episode {podcast_id} deleted.")
