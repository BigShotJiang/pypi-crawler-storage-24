"""Status command: system health and connection info."""
import json

import typer

from ..auth import get_token
from ..client import TisitClient
from ..config import Config
from ..display import print_error, print_success, print_info
from ..exceptions import APIError


def status(
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Check system health and connection status."""
    token = get_token()
    cfg = Config()

    result = {
        "logged_in": token is not None,
        "api_url": cfg.api_url,
        "server_status": None,
        "database": None,
    }

    if token:
        client = TisitClient(cfg.api_url, token)
        try:
            data = client.status()
            result["server_status"] = data.get("status", "ok")
            result["database"] = data.get("database", "unknown")
        except APIError:
            result["server_status"] = "unreachable"
        except Exception:
            result["server_status"] = "error"
        finally:
            client.close()

    if output_json:
        typer.echo(json.dumps(result, indent=2))
    else:
        print_info(f"  Server: {cfg.api_url}")
        if result["logged_in"]:
            if result["server_status"] == "ok":
                print_success(f"  Status: connected (database: {result['database']})")
            else:
                print_error(f"  Status: {result['server_status']}")
        else:
            print_error("  Not logged in. Run: tisit login")
