"""Paper commands: add, list, view, delete."""
import json
from typing import Optional

import typer

from ..auth import get_token
from ..client import TisitClient
from ..config import Config
from ..display import (
    print_error, print_paper_detail, print_paper_table,
    print_success,
)
from ..exceptions import AuthenticationError, APIError, NotFoundError

paper_app = typer.Typer(help="Manage your research papers")


def _get_client() -> TisitClient:
    token = get_token()
    if not token:
        print_error("Not logged in. Run: tisit login")
        raise typer.Exit(code=1)
    cfg = Config()
    return TisitClient(cfg.api_url, token)


@paper_app.command("list")
def paper_list(
    query: Optional[str] = typer.Option(None, "--query", "-q", help="Search title or authors"),
    sort: str = typer.Option("uploaded_at", "--sort", "-s", help="Sort by: uploaded_at, title"),
    order: str = typer.Option("desc", "--order", "-o", help="asc or desc"),
    page: int = typer.Option(1, "--page", "-p"),
    per_page: int = typer.Option(20, "--per-page"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """List your papers."""
    client = _get_client()
    try:
        papers, meta = client.list_papers(
            q=query, sort=sort, order=order, page=page, per_page=per_page,
        )
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps({"data": papers, "meta": meta}, indent=2, default=str))
    else:
        if not papers:
            print_error("No papers found.")
        else:
            print_paper_table(papers, meta)


@paper_app.command("view")
def paper_view(
    paper_id: int = typer.Argument(..., help="Paper ID"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """View a paper in detail."""
    client = _get_client()
    try:
        paper = client.get_paper(paper_id)
    except NotFoundError:
        print_error(f"Paper {paper_id} not found.")
        raise typer.Exit(code=1)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(paper, indent=2, default=str))
    else:
        print_paper_detail(paper)


@paper_app.command("add")
def paper_add(
    url: str = typer.Argument(..., help="Paper URL (PDF or article page)"),
    title: Optional[str] = typer.Option(None, "--title", "-t", help="Paper title"),
    authors: Optional[str] = typer.Option(None, "--authors", "-a", help="Paper authors"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Add a paper by URL (async — queued for processing)."""
    client = _get_client()
    try:
        data = client.add_paper(url, title=title, authors=authors)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(data, indent=2, default=str))
    else:
        if data.get("is_duplicate"):
            print_success(f"Paper already exists (ID: {data['paper_id']}). You have access.")
        else:
            print_success(
                f"Paper queued for processing (ID: {data['paper_id']}).\n"
                f"  Check status with: tisit paper view {data['paper_id']}"
            )


@paper_app.command("delete")
def paper_delete(
    paper_id: int = typer.Argument(..., help="Paper ID to delete"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Delete a paper."""
    if not yes:
        confirm = typer.confirm(f"Delete paper {paper_id}?")
        if not confirm:
            raise typer.Abort()

    client = _get_client()
    try:
        client.delete_paper(paper_id)
    except NotFoundError:
        print_error(f"Paper {paper_id} not found.")
        raise typer.Exit(code=1)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    print_success(f"Paper {paper_id} deleted.")
