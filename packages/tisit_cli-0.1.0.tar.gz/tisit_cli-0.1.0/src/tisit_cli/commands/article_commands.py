"""Article commands: add, list, view, delete."""
import json
from typing import Optional

import typer

from ..auth import get_token
from ..client import TisitClient
from ..config import Config
from ..display import (
    print_error, print_article_detail, print_article_table,
    print_success,
)
from ..exceptions import AuthenticationError, APIError, NotFoundError

article_app = typer.Typer(help="Manage your web articles")


def _get_client() -> TisitClient:
    token = get_token()
    if not token:
        print_error("Not logged in. Run: tisit login")
        raise typer.Exit(code=1)
    cfg = Config()
    return TisitClient(cfg.api_url, token)


@article_app.command("list")
def article_list(
    query: Optional[str] = typer.Option(None, "--query", "-q", help="Search title or domain"),
    sort: str = typer.Option("fetched_at", "--sort", "-s", help="Sort by: fetched_at, title"),
    order: str = typer.Option("desc", "--order", "-o", help="asc or desc"),
    page: int = typer.Option(1, "--page", "-p"),
    per_page: int = typer.Option(20, "--per-page"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """List your articles."""
    client = _get_client()
    try:
        articles, meta = client.list_articles(
            q=query, sort=sort, order=order, page=page, per_page=per_page,
        )
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps({"data": articles, "meta": meta}, indent=2, default=str))
    else:
        if not articles:
            print_error("No articles found.")
        else:
            print_article_table(articles, meta)


@article_app.command("view")
def article_view(
    article_id: int = typer.Argument(..., help="Article ID"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """View an article in detail."""
    client = _get_client()
    try:
        article = client.get_article(article_id)
    except NotFoundError:
        print_error(f"Article {article_id} not found.")
        raise typer.Exit(code=1)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(article, indent=2, default=str))
    else:
        print_article_detail(article)


@article_app.command("add")
def article_add(
    url: str = typer.Argument(..., help="Article URL"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Add an article by URL (async — queued for processing)."""
    client = _get_client()
    try:
        data = client.add_article(url)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(data, indent=2, default=str))
    else:
        if data.get("is_duplicate"):
            print_success(f"Article already exists (ID: {data['article_id']}).")
        else:
            print_success(
                f"Article queued for processing (ID: {data['article_id']}).\n"
                f"  Check status with: tisit article view {data['article_id']}"
            )


@article_app.command("delete")
def article_delete(
    article_id: int = typer.Argument(..., help="Article ID to delete"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Delete an article."""
    if not yes:
        confirm = typer.confirm(f"Delete article {article_id}?")
        if not confirm:
            raise typer.Abort()

    client = _get_client()
    try:
        client.delete_article(article_id)
    except NotFoundError:
        print_error(f"Article {article_id} not found.")
        raise typer.Exit(code=1)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    print_success(f"Article {article_id} deleted.")
