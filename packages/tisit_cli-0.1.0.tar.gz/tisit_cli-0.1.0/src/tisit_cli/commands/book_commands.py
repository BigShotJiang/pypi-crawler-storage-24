"""Book commands: search, add, list, view, delete."""
import json
from typing import Optional

import typer

from ..auth import get_token
from ..client import TisitClient
from ..config import Config
from ..display import (
    print_error, print_book_detail, print_book_table,
    print_success, print_info,
)
from ..exceptions import AuthenticationError, APIError, NotFoundError

book_app = typer.Typer(help="Manage your book library")


def _get_client() -> TisitClient:
    token = get_token()
    if not token:
        print_error("Not logged in. Run: tisit login")
        raise typer.Exit(code=1)
    cfg = Config()
    return TisitClient(cfg.api_url, token)


@book_app.command("search")
def book_search(
    title: str = typer.Argument("", help="Book title to search"),
    author: Optional[str] = typer.Option(None, "--author", "-a", help="Author name"),
    limit: int = typer.Option(10, "--limit", "-l", help="Max results"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Search for books via Google Books / Open Library."""
    if not title and not author:
        print_error("Provide a title or --author to search.")
        raise typer.Exit(code=1)

    client = _get_client()
    try:
        results, meta = client.search_books(title=title, author=author or "", limit=limit)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps({"data": results, "meta": meta}, indent=2, default=str))
    else:
        if not results:
            print_error("No books found.")
        else:
            from rich.table import Table
            from ..display import console
            table = Table(title="Book Search Results")
            table.add_column("#", justify="right")
            table.add_column("Title", style="bold")
            table.add_column("Authors")
            table.add_column("Published")
            table.add_column("ISBN-13")

            for i, r in enumerate(results, 1):
                t = r.get("title", "")
                if len(t) > 45:
                    t = t[:42] + "..."
                authors = ", ".join(r.get("authors") or []) if r.get("authors") else ""
                table.add_row(
                    str(i), t, authors,
                    r.get("published_date", ""),
                    r.get("isbn_13", "") or "",
                )
            console.print(table)
            print_info(f"  {meta.get('count', len(results))} results. Use 'tisit book add \"Title\"' to add one.")


@book_app.command("list")
def book_list(
    query: Optional[str] = typer.Option(None, "--query", "-q", help="Search title"),
    sort: str = typer.Option("added_at", "--sort", "-s", help="Sort by: added_at, title"),
    order: str = typer.Option("desc", "--order", "-o"),
    page: int = typer.Option(1, "--page", "-p"),
    per_page: int = typer.Option(20, "--per-page"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """List books in your library."""
    client = _get_client()
    try:
        books, meta = client.list_books(
            q=query, sort=sort, order=order, page=page, per_page=per_page,
        )
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps({"data": books, "meta": meta}, indent=2, default=str))
    else:
        if not books:
            print_error("No books found.")
        else:
            print_book_table(books, meta)


@book_app.command("view")
def book_view(
    book_id: int = typer.Argument(..., help="Book ID"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """View a book in detail."""
    client = _get_client()
    try:
        book = client.get_book(book_id)
    except NotFoundError:
        print_error(f"Book {book_id} not found.")
        raise typer.Exit(code=1)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(book, indent=2, default=str))
    else:
        print_book_detail(book)


@book_app.command("add")
def book_add(
    title: str = typer.Argument(..., help="Book title"),
    authors: Optional[str] = typer.Option(None, "--authors", "-a", help="Authors (comma-separated)"),
    isbn: Optional[str] = typer.Option(None, "--isbn", help="ISBN-13"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Add a book to your library (async — queued for processing)."""
    author_list = [a.strip() for a in authors.split(",")] if authors else None

    client = _get_client()
    try:
        data = client.add_book(title, authors=author_list, isbn_13=isbn)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(data, indent=2, default=str))
    else:
        if data.get("is_existing"):
            print_success(f"Book already in library (ID: {data['book_id']}).")
        else:
            print_success(
                f"Book added and queued for processing (ID: {data['book_id']}).\n"
                f"  Check status with: tisit book view {data['book_id']}"
            )


@book_app.command("delete")
def book_delete(
    book_id: int = typer.Argument(..., help="Book ID to remove"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Remove a book from your library."""
    if not yes:
        confirm = typer.confirm(f"Remove book {book_id} from library?")
        if not confirm:
            raise typer.Abort()

    client = _get_client()
    try:
        client.delete_book(book_id)
    except NotFoundError:
        print_error(f"Book {book_id} not found in your library.")
        raise typer.Exit(code=1)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    print_success(f"Book {book_id} removed from library.")
