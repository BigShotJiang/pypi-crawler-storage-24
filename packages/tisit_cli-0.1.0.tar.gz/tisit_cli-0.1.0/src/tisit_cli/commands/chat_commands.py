"""Chat commands: ask (one-shot) and interactive REPL."""
import json
from typing import Optional

import typer

from ..auth import get_token
from ..client import TisitClient
from ..config import Config
from ..display import console, print_error, print_info
from ..exceptions import AuthenticationError, APIError

chat_app = typer.Typer(help="Ask questions about your knowledge base")


def _get_client() -> TisitClient:
    token = get_token()
    if not token:
        print_error("Not logged in. Run: tisit login")
        raise typer.Exit(code=1)
    cfg = Config()
    return TisitClient(cfg.api_url, token)


@chat_app.command("ask")
def chat_ask(
    question: str = typer.Argument(..., help="Question to ask"),
    session_id: Optional[int] = typer.Option(None, "--session", "-s", help="Continue a session"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Ask a single question (one-shot)."""
    client = _get_client()
    try:
        data = client.chat_ask(question, session_id=session_id)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(data, indent=2, default=str))
    else:
        console.print()
        console.print(data.get("answer", ""))
        console.print()
        sources = data.get("sources_used", 0)
        sid = data.get("session_id")
        print_info(f"  Sources: {sources}  Session: {sid}")


@chat_app.callback(invoke_without_command=True)
def chat_repl(ctx: typer.Context):
    """Interactive chat REPL. Type 'exit' or Ctrl+C to quit."""
    if ctx.invoked_subcommand is not None:
        return

    client = _get_client()
    session_id = None

    console.print("[bold]TISIT Chat[/bold] — ask anything about your knowledge base.")
    console.print("[dim]Type 'exit' or press Ctrl+C to quit.[/dim]")
    console.print()

    try:
        while True:
            try:
                question = console.input("[bold cyan]> [/bold cyan]").strip()
            except EOFError:
                break

            if not question:
                continue
            if question.lower() in ("exit", "quit", "q"):
                break

            try:
                data = client.chat_ask(question, session_id=session_id)
                session_id = data.get("session_id")

                console.print()
                console.print(data.get("answer", ""))
                console.print()
                sources = data.get("sources_used", 0)
                console.print(f"[dim]  ({sources} sources)[/dim]")
                console.print()
            except (AuthenticationError, APIError) as exc:
                print_error(str(exc))
    except KeyboardInterrupt:
        console.print()
    finally:
        client.close()

    console.print("[dim]Goodbye.[/dim]")
