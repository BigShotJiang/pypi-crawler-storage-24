"""Focus mode commands: list, create, view, delete, concept add."""
import json
from typing import Optional

import typer
from rich.table import Table
from rich.panel import Panel

from ..auth import get_token
from ..client import TisitClient
from ..config import Config
from ..display import console, print_error, print_success, print_info
from ..exceptions import AuthenticationError, APIError, NotFoundError

focus_app = typer.Typer(help="Focus Mode — deep dive learning")
concept_app = typer.Typer(help="Manage concepts within a bubble")
focus_app.add_typer(concept_app, name="concept")


def _get_client() -> TisitClient:
    token = get_token()
    if not token:
        print_error("Not logged in. Run: tisit login")
        raise typer.Exit(code=1)
    cfg = Config()
    return TisitClient(cfg.api_url, token)


@focus_app.command("list")
def focus_list(
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """List your topic bubbles."""
    client = _get_client()
    try:
        bubbles = client.list_focus_bubbles()
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(bubbles, indent=2, default=str))
    else:
        if not bubbles:
            print_info("No topic bubbles. Create one with: tisit focus create \"topic\"")
        else:
            table = Table(title="Topic Bubbles")
            table.add_column("ID", style="cyan", justify="right")
            table.add_column("Topic", style="bold")
            table.add_column("Status")
            table.add_column("Coverage", justify="right")
            table.add_column("Mastery", justify="right")
            table.add_column("Study Time", justify="right")
            for b in bubbles:
                study = f"{b.get('total_study_time_minutes', 0)}m"
                table.add_row(
                    str(b["id"]),
                    b.get("topic_name", ""),
                    b.get("status", ""),
                    f"{b.get('coverage_score', 0):.0f}%",
                    f"{b.get('mastery_score', 0):.0f}%",
                    study,
                )
            console.print(table)


@focus_app.command("create")
def focus_create(
    topic: str = typer.Argument(..., help="Topic to deep dive into"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Create a new topic bubble."""
    client = _get_client()
    try:
        data = client.create_focus_bubble(topic)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(data, indent=2, default=str))
    else:
        print_success(
            f"Topic bubble created (ID: {data.get('id')}).\n"
            f"  View with: tisit focus view {data.get('id')}"
        )


@focus_app.command("view")
def focus_view(
    bubble_id: int = typer.Argument(..., help="Bubble ID"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """View a topic bubble with its concepts."""
    client = _get_client()
    try:
        data = client.get_focus_bubble(bubble_id)
    except NotFoundError:
        print_error(f"Topic bubble {bubble_id} not found.")
        raise typer.Exit(code=1)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(data, indent=2, default=str))
        return

    bubble = data.get("bubble", {})
    concepts = data.get("concepts", [])

    lines = [
        f"[bold]{bubble.get('topic_name', '')}[/bold]",
        "",
        f"Status: {bubble.get('status', '')}",
        f"Coverage: {bubble.get('coverage_score', 0):.0f}%  Mastery: {bubble.get('mastery_score', 0):.0f}%",
        f"Study Time: {bubble.get('total_study_time_minutes', 0)} minutes",
        f"ID: {bubble.get('id', '')}",
    ]
    console.print(Panel("\n".join(lines), title="Topic Bubble", border_style="cyan"))

    if concepts:
        table = Table(title=f"Concepts ({len(concepts)})")
        table.add_column("ID", style="cyan", justify="right")
        table.add_column("Name", style="bold")
        table.add_column("Category")
        table.add_column("Mastery", justify="right")
        table.add_column("Reviews", justify="right")
        for c in concepts:
            table.add_row(
                str(c["id"]),
                c.get("name", ""),
                c.get("category", ""),
                f"{c.get('mastery_level', 0):.0f}%",
                str(c.get("times_reviewed", 0)),
            )
        console.print(table)
    else:
        print_info("  No concepts yet. Add with: tisit focus concept add <bubble_id> \"name\"")


@focus_app.command("delete")
def focus_delete(
    bubble_id: int = typer.Argument(..., help="Bubble ID to delete"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Delete a topic bubble."""
    if not yes:
        if not typer.confirm(f"Delete topic bubble {bubble_id}?"):
            raise typer.Abort()

    client = _get_client()
    try:
        client.delete_focus_bubble(bubble_id)
    except NotFoundError:
        print_error(f"Topic bubble {bubble_id} not found.")
        raise typer.Exit(code=1)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    print_success(f"Topic bubble {bubble_id} deleted.")


# ── concept subcommands ───────────────────────────────────────────

@concept_app.command("add")
def concept_add(
    bubble_id: int = typer.Argument(..., help="Bubble ID"),
    name: str = typer.Argument(..., help="Concept name"),
    definition: Optional[str] = typer.Option(None, "--definition", "-d"),
    category: str = typer.Option("term", "--category", "-c", help="term, formula, principle, process"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Add a concept to a topic bubble."""
    client = _get_client()
    try:
        data = client.add_focus_concept(
            bubble_id, name, definition=definition, category=category
        )
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(data, indent=2, default=str))
    else:
        print_success(f"Concept added (ID: {data.get('id')}).")
