"""Tweet commands: add, list, view, delete."""
import json
from typing import Optional

import typer

from ..auth import get_token
from ..client import TisitClient
from ..config import Config
from ..display import (
    print_error, print_tweet_detail, print_tweet_table,
    print_success,
)
from ..exceptions import AuthenticationError, APIError, NotFoundError

tweet_app = typer.Typer(help="Manage your tweets / X posts")


def _get_client() -> TisitClient:
    token = get_token()
    if not token:
        print_error("Not logged in. Run: tisit login")
        raise typer.Exit(code=1)
    cfg = Config()
    return TisitClient(cfg.api_url, token)


@tweet_app.command("list")
def tweet_list(
    query: Optional[str] = typer.Option(None, "--query", "-q", help="Search content or author"),
    sort: str = typer.Option("created_at", "--sort", "-s"),
    order: str = typer.Option("desc", "--order", "-o"),
    page: int = typer.Option(1, "--page", "-p"),
    per_page: int = typer.Option(20, "--per-page"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """List your tweets."""
    client = _get_client()
    try:
        tweets, meta = client.list_tweets(
            q=query, sort=sort, order=order, page=page, per_page=per_page,
        )
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps({"data": tweets, "meta": meta}, indent=2, default=str))
    else:
        if not tweets:
            print_error("No tweets found.")
        else:
            print_tweet_table(tweets, meta)


@tweet_app.command("view")
def tweet_view(
    tweet_id: int = typer.Argument(..., help="Tweet ID"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """View a tweet in detail."""
    client = _get_client()
    try:
        tweet = client.get_tweet(tweet_id)
    except NotFoundError:
        print_error(f"Tweet {tweet_id} not found.")
        raise typer.Exit(code=1)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(tweet, indent=2, default=str))
    else:
        print_tweet_detail(tweet)


@tweet_app.command("add")
def tweet_add(
    url: str = typer.Argument(..., help="Tweet/X post URL"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Add a tweet by URL (async — queued for processing)."""
    client = _get_client()
    try:
        data = client.add_tweet(url)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(data, indent=2, default=str))
    else:
        if data.get("is_duplicate"):
            print_success(f"Tweet already exists (ID: {data['tweet_id']}).")
        else:
            print_success(
                f"Tweet queued for processing (ID: {data['tweet_id']}).\n"
                f"  Check status with: tisit tweet view {data['tweet_id']}"
            )


@tweet_app.command("delete")
def tweet_delete(
    tweet_id: int = typer.Argument(..., help="Tweet ID to delete"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Delete a tweet."""
    if not yes:
        confirm = typer.confirm(f"Delete tweet {tweet_id}?")
        if not confirm:
            raise typer.Abort()

    client = _get_client()
    try:
        client.delete_tweet(tweet_id)
    except NotFoundError:
        print_error(f"Tweet {tweet_id} not found.")
        raise typer.Exit(code=1)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    print_success(f"Tweet {tweet_id} deleted.")
