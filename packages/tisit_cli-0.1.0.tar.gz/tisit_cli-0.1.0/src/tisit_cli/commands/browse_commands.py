"""Browse command: unified content browsing across all types."""
import json
from typing import Optional

import typer

from ..auth import get_token
from ..client import TisitClient
from ..config import Config
from ..display import (
    print_error,
    print_note_table, print_paper_table, print_article_table,
    print_video_table, print_tweet_table, print_book_table,
    print_podcast_table, print_patent_table,
)
from ..exceptions import AuthenticationError, APIError

CONTENT_TYPES = ["notes", "papers", "articles", "videos", "tweets", "books", "podcasts", "patents"]


def browse(
    content_type: str = typer.Option("notes", "--type", "-t", help="Content type: " + ", ".join(CONTENT_TYPES)),
    query: Optional[str] = typer.Option(None, "--query", "-q", help="Search filter"),
    sort: Optional[str] = typer.Option(None, "--sort", "-s", help="Sort field"),
    order: str = typer.Option("desc", "--order", "-o", help="asc or desc"),
    page: int = typer.Option(1, "--page", "-p"),
    per_page: int = typer.Option(20, "--per-page"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Browse content across all types."""
    if content_type not in CONTENT_TYPES:
        print_error(f"Invalid type. Choose from: {', '.join(CONTENT_TYPES)}")
        raise typer.Exit(code=1)

    token = get_token()
    if not token:
        print_error("Not logged in. Run: tisit login")
        raise typer.Exit(code=1)

    cfg = Config()
    client = TisitClient(cfg.api_url, token)

    params = {"order": order, "page": page, "per_page": per_page}
    if query:
        params["q"] = query
    if sort:
        params["sort"] = sort

    type_map = {
        "notes": ("/notes", print_note_table),
        "papers": ("/papers", print_paper_table),
        "articles": ("/articles", print_article_table),
        "videos": ("/videos", print_video_table),
        "tweets": ("/tweets", print_tweet_table),
        "books": ("/books", print_book_table),
        "podcasts": ("/podcasts", print_podcast_table),
        "patents": ("/patents", print_patent_table),
    }

    endpoint, display_fn = type_map[content_type]

    try:
        data, meta = client._request("GET", endpoint, params=params)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps({"data": data, "meta": meta}, indent=2, default=str))
    else:
        if not data:
            print_error(f"No {content_type} found.")
        else:
            display_fn(data, meta)
