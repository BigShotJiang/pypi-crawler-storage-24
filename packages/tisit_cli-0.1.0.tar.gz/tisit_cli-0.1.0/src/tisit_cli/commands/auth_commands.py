"""Auth commands: login, logout, whoami."""
import json
import typer

from ..auth import store_token, get_token, delete_token, validate_token_format
from ..client import TisitClient
from ..config import Config
from ..display import print_success, print_error, print_info
from ..exceptions import APIError, AuthenticationError


def login(
    token: str = typer.Option(
        None, "--token", "-t",
        help="API token (prompted securely if omitted)",
    ),
    api_url: str = typer.Option(
        None, "--api-url", "-u",
        help="Server URL (saved to config)",
    ),
):
    """Authenticate with your TISIT API token."""
    if not token:
        token = typer.prompt("API token", hide_input=True)

    token = token.strip()
    if not validate_token_format(token):
        print_error("Invalid token format. Tokens start with 'tsk_'.")
        raise typer.Exit(code=1)

    cfg = Config()
    if api_url:
        cfg.set("api_url", api_url.rstrip("/"))
        cfg.save()

    # Verify token against the server
    client = TisitClient(cfg.api_url, token)
    try:
        client.status()
    except (AuthenticationError, APIError) as exc:
        print_error(f"Token verification failed: {exc}")
        raise typer.Exit(code=1)
    finally:
        client.close()

    store_token(token)
    print_success(f"Logged in to {cfg.api_url}")


def logout():
    """Clear stored credentials."""
    delete_token()
    print_success("Logged out.")


def whoami(
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Show current authentication status."""
    token = get_token()
    if not token:
        print_error("Not logged in. Run: tisit login")
        raise typer.Exit(code=1)

    cfg = Config()
    client = TisitClient(cfg.api_url, token)
    try:
        data = client.status()
        connected = True
    except Exception:
        data = {}
        connected = False
    finally:
        client.close()

    prefix = token[:12] + "..."

    if output_json:
        typer.echo(json.dumps({
            "token_prefix": prefix,
            "api_url": cfg.api_url,
            "connected": connected,
            "server_status": data.get("status") if data else None,
        }, indent=2))
    else:
        print_info(f"Token:  {prefix}")
        print_info(f"Server: {cfg.api_url}")
        if connected:
            print_success(f"Status: connected (server {data.get('status', 'ok')})")
        else:
            print_error("Status: cannot reach server")
