"""Patent commands: add, list, view, delete."""
import json
from typing import Optional

import typer

from ..auth import get_token
from ..client import TisitClient
from ..config import Config
from ..display import (
    print_error, print_patent_detail, print_patent_table,
    print_success,
)
from ..exceptions import AuthenticationError, APIError, NotFoundError

patent_app = typer.Typer(help="Manage your patents")


def _get_client() -> TisitClient:
    token = get_token()
    if not token:
        print_error("Not logged in. Run: tisit login")
        raise typer.Exit(code=1)
    cfg = Config()
    return TisitClient(cfg.api_url, token)


@patent_app.command("list")
def patent_list(
    query: Optional[str] = typer.Option(None, "--query", "-q", help="Search title or patent number"),
    sort: str = typer.Option("fetched_at", "--sort", "-s"),
    order: str = typer.Option("desc", "--order", "-o"),
    page: int = typer.Option(1, "--page", "-p"),
    per_page: int = typer.Option(20, "--per-page"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """List your patents."""
    client = _get_client()
    try:
        patents, meta = client.list_patents(
            q=query, sort=sort, order=order, page=page, per_page=per_page,
        )
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps({"data": patents, "meta": meta}, indent=2, default=str))
    else:
        if not patents:
            print_error("No patents found.")
        else:
            print_patent_table(patents, meta)


@patent_app.command("view")
def patent_view(
    patent_id: int = typer.Argument(..., help="Patent ID"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """View a patent in detail."""
    client = _get_client()
    try:
        patent = client.get_patent(patent_id)
    except NotFoundError:
        print_error(f"Patent {patent_id} not found.")
        raise typer.Exit(code=1)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(patent, indent=2, default=str))
    else:
        print_patent_detail(patent)


@patent_app.command("add")
def patent_add(
    url_or_number: str = typer.Argument(..., help="Patent URL or patent number"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Add a patent by URL or number (async — queued for processing)."""
    # Detect whether input is a URL or patent number
    is_url = url_or_number.startswith("http")

    client = _get_client()
    try:
        if is_url:
            data = client.add_patent(url=url_or_number)
        else:
            data = client.add_patent(patent_number=url_or_number)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(data, indent=2, default=str))
    else:
        if data.get("is_duplicate"):
            print_success(f"Patent already exists (ID: {data['patent_id']}).")
        else:
            print_success(
                f"Patent queued for processing (ID: {data['patent_id']}).\n"
                f"  Check status with: tisit patent view {data['patent_id']}"
            )


@patent_app.command("delete")
def patent_delete(
    patent_id: int = typer.Argument(..., help="Patent ID to delete"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Delete a patent."""
    if not yes:
        confirm = typer.confirm(f"Delete patent {patent_id}?")
        if not confirm:
            raise typer.Abort()

    client = _get_client()
    try:
        client.delete_patent(patent_id)
    except NotFoundError:
        print_error(f"Patent {patent_id} not found.")
        raise typer.Exit(code=1)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    print_success(f"Patent {patent_id} deleted.")
