"""Radar sweep commands: status, topic add/list/delete, run, source accept/ignore."""
import json
from typing import Optional

import typer
from rich.table import Table

from ..auth import get_token
from ..client import TisitClient
from ..config import Config
from ..display import console, print_error, print_success, print_info
from ..exceptions import AuthenticationError, APIError, NotFoundError

radar_app = typer.Typer(help="Radar Sweep — intelligence monitoring")
topic_app = typer.Typer(help="Manage watch topics")
source_app = typer.Typer(help="Triage sweep sources")
radar_app.add_typer(topic_app, name="topic")
radar_app.add_typer(source_app, name="source")


def _get_client() -> TisitClient:
    token = get_token()
    if not token:
        print_error("Not logged in. Run: tisit login")
        raise typer.Exit(code=1)
    cfg = Config()
    return TisitClient(cfg.api_url, token)


@radar_app.command("status")
def radar_status(
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Show watch topics and recent sweep runs."""
    client = _get_client()
    try:
        data = client.radar_status()
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(data, indent=2, default=str))
        return

    topics = data.get("topics", [])
    runs = data.get("recent_runs", [])

    if topics:
        table = Table(title="Watch Topics")
        table.add_column("ID", style="cyan", justify="right")
        table.add_column("Topic", style="bold")
        table.add_column("Keywords")
        for t in topics:
            table.add_row(
                str(t["id"]),
                t["topic"],
                ", ".join(t.get("keywords") or []),
            )
        console.print(table)
    else:
        print_info("No watch topics. Add one with: tisit radar topic add \"topic\"")

    console.print()

    if runs:
        table = Table(title="Recent Sweep Runs")
        table.add_column("ID", style="cyan", justify="right")
        table.add_column("Topic")
        table.add_column("Status")
        table.add_column("Sources")
        table.add_column("Notes")
        table.add_column("When")
        for r in runs:
            table.add_row(
                str(r["id"]),
                r.get("topic_name", ""),
                r.get("status", ""),
                str(r.get("total_sources_fetched", 0)),
                str(r.get("total_notes_generated", 0)),
                (r.get("run_timestamp") or "")[:10],
            )
        console.print(table)
    else:
        print_info("No sweep runs yet.")


@radar_app.command("run")
def radar_run(
    run_id: int = typer.Argument(..., help="Sweep run ID"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """View sweep run details and sources."""
    client = _get_client()
    try:
        data = client.get_sweep_run(run_id)
    except NotFoundError:
        print_error(f"Sweep run {run_id} not found.")
        raise typer.Exit(code=1)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(data, indent=2, default=str))
        return

    run = data.get("run", {})
    sources = data.get("sources", [])

    print_info(
        f"Run #{run.get('id')} — {run.get('topic_name', '')} — "
        f"{run.get('status', '')} — {run.get('total_sources_fetched', 0)} sources"
    )

    if sources:
        table = Table(title="Sources")
        table.add_column("ID", style="cyan", justify="right")
        table.add_column("Type")
        table.add_column("Title", style="bold")
        table.add_column("Triage")
        for s in sources:
            title = s.get("title") or ""
            if len(title) > 50:
                title = title[:47] + "..."
            table.add_row(
                str(s["id"]),
                s.get("source_type", ""),
                title,
                s.get("triage_status", ""),
            )
        console.print(table)


# ── topic subcommands ─────────────────────────────────────────────

@topic_app.command("list")
def topic_list(
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """List your watch topics."""
    client = _get_client()
    try:
        topics = client.list_watch_topics()
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(topics, indent=2, default=str))
    else:
        if not topics:
            print_info("No watch topics.")
        else:
            table = Table(title="Watch Topics")
            table.add_column("ID", style="cyan", justify="right")
            table.add_column("Topic", style="bold")
            table.add_column("Keywords")
            for t in topics:
                table.add_row(str(t["id"]), t["topic"], ", ".join(t.get("keywords") or []))
            console.print(table)


@topic_app.command("add")
def topic_add(
    topic: str = typer.Argument(..., help="Topic name"),
    keywords: Optional[str] = typer.Option(None, "--keywords", "-k", help="Comma-separated keywords"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Add a watch topic."""
    kw_list = [k.strip() for k in keywords.split(",")] if keywords else None

    client = _get_client()
    try:
        data = client.create_watch_topic(topic, keywords=kw_list)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(data, indent=2, default=str))
    else:
        print_success(f"Watch topic created (ID: {data.get('id')}).")


@topic_app.command("delete")
def topic_delete(
    topic_id: int = typer.Argument(..., help="Topic ID"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Delete a watch topic."""
    if not yes:
        if not typer.confirm(f"Delete watch topic {topic_id}?"):
            raise typer.Abort()

    client = _get_client()
    try:
        client.delete_watch_topic(topic_id)
    except NotFoundError:
        print_error(f"Watch topic {topic_id} not found.")
        raise typer.Exit(code=1)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    print_success(f"Watch topic {topic_id} deleted.")


# ── source subcommands ────────────────────────────────────────────

@source_app.command("accept")
def source_accept(source_id: int = typer.Argument(..., help="Source ID")):
    """Accept a sweep source for note generation."""
    client = _get_client()
    try:
        client.accept_source(source_id)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()
    print_success(f"Source {source_id} accepted.")


@source_app.command("ignore")
def source_ignore(source_id: int = typer.Argument(..., help="Source ID")):
    """Ignore/dismiss a sweep source."""
    client = _get_client()
    try:
        client.ignore_source(source_id)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()
    print_success(f"Source {source_id} ignored.")
