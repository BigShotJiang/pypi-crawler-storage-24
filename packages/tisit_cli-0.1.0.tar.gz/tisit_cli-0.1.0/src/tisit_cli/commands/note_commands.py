"""Note commands: add, list, view, delete."""
import json
from typing import Optional

import typer

from ..auth import get_token
from ..client import TisitClient
from ..config import Config
from ..display import (
    print_error, print_note_detail, print_note_table,
    print_queued, print_success,
)
from ..exceptions import AuthenticationError, APIError, NotFoundError

note_app = typer.Typer(help="Manage your learning notes")


def _get_client() -> TisitClient:
    token = get_token()
    if not token:
        print_error("Not logged in. Run: tisit login")
        raise typer.Exit(code=1)
    cfg = Config()
    return TisitClient(cfg.api_url, token)


@note_app.command("list")
def note_list(
    query: Optional[str] = typer.Option(None, "--query", "-q", help="Search term"),
    category: Optional[str] = typer.Option(None, "--category", "-c"),
    domain: Optional[str] = typer.Option(None, "--domain", "-d"),
    sort: str = typer.Option("created_at", "--sort", "-s",
                             help="Sort by: created_at, term, category"),
    order: str = typer.Option("desc", "--order", "-o", help="asc or desc"),
    page: int = typer.Option(1, "--page", "-p"),
    per_page: int = typer.Option(20, "--per-page"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """List your notes."""
    client = _get_client()
    try:
        notes, meta = client.list_notes(
            q=query, category=category, domain=domain,
            sort=sort, order=order, page=page, per_page=per_page,
        )
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps({"data": notes, "meta": meta}, indent=2, default=str))
    else:
        if not notes:
            print_error("No notes found.")
        else:
            print_note_table(notes, meta)


@note_app.command("view")
def note_view(
    note_id: int = typer.Argument(..., help="Note ID"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """View a note in detail."""
    client = _get_client()
    try:
        note = client.get_note(note_id)
    except NotFoundError:
        print_error(f"Note {note_id} not found.")
        raise typer.Exit(code=1)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(note, indent=2, default=str))
    else:
        print_note_detail(note)


@note_app.command("add")
def note_add(
    term: str = typer.Argument(..., help="Term to learn about"),
    context: str = typer.Argument(..., help="Context for the term"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Create a new note (async — queued for processing)."""
    client = _get_client()
    try:
        data = client.create_note(term, context)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(data, indent=2, default=str))
    else:
        print_queued(data)


@note_app.command("delete")
def note_delete(
    note_id: int = typer.Argument(..., help="Note ID to delete"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
):
    """Delete a note."""
    if not yes:
        confirm = typer.confirm(f"Delete note {note_id}?")
        if not confirm:
            raise typer.Abort()

    client = _get_client()
    try:
        client.delete_note(note_id)
    except NotFoundError:
        print_error(f"Note {note_id} not found.")
        raise typer.Exit(code=1)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    print_success(f"Note {note_id} deleted.")
