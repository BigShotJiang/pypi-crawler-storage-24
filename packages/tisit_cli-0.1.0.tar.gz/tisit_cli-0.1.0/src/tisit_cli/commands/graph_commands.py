"""Knowledge graph commands: stats, neighbors, paths."""
import json

import typer
from rich.table import Table

from ..auth import get_token
from ..client import TisitClient
from ..config import Config
from ..display import console, print_error, print_info
from ..exceptions import AuthenticationError, APIError

graph_app = typer.Typer(help="Knowledge graph queries")


def _get_client() -> TisitClient:
    token = get_token()
    if not token:
        print_error("Not logged in. Run: tisit login")
        raise typer.Exit(code=1)
    cfg = Config()
    return TisitClient(cfg.api_url, token)


@graph_app.command("stats")
def graph_stats(
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Show knowledge graph statistics."""
    client = _get_client()
    try:
        data = client.graph_stats()
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps(data, indent=2, default=str))
    else:
        print_info(f"  Nodes: {data.get('total_nodes', 0)}")
        print_info(f"  Edges: {data.get('total_edges', 0)}")
        density = data.get('density', 0)
        print_info(f"  Density: {density:.4f}")
        connected = "yes" if data.get("is_connected") else "no"
        print_info(f"  Connected: {connected}")

        node_types = data.get("node_types", {})
        if node_types:
            console.print()
            table = Table(title="Node Types")
            table.add_column("Type", style="bold")
            table.add_column("Count", justify="right")
            for t, c in sorted(node_types.items(), key=lambda x: -x[1]):
                table.add_row(t, str(c))
            console.print(table)


@graph_app.command("neighbors")
def graph_neighbors(
    term: str = typer.Argument(..., help="Concept to find neighbors for"),
    limit: int = typer.Option(10, "--limit", "-l", help="Max neighbors"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Show connected concepts for a term."""
    client = _get_client()
    try:
        data, meta = client.graph_neighbors(term, limit=limit)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps({"data": data, "meta": meta}, indent=2, default=str))
    else:
        if not data:
            print_error(f"No neighbors found for '{term}'.")
        else:
            table = Table(title=f"Neighbors of '{term}'")
            table.add_column("Concept", style="bold")
            table.add_column("Type")
            table.add_column("Relationship")
            table.add_column("Weight", justify="right")
            for n in data:
                table.add_row(
                    n.get("label", ""),
                    n.get("type", ""),
                    n.get("relationship", ""),
                    f"{n.get('weight', 0):.2f}",
                )
            console.print(table)


@graph_app.command("paths")
def graph_paths(
    source: str = typer.Argument(..., help="Source concept"),
    target: str = typer.Argument(..., help="Target concept"),
    max_depth: int = typer.Option(3, "--depth", "-d", help="Max path depth"),
    output_json: bool = typer.Option(False, "--json", help="JSON output"),
):
    """Find connection paths between two concepts."""
    client = _get_client()
    try:
        data, meta = client.graph_paths(source, target, max_depth=max_depth)
    except (AuthenticationError, APIError) as exc:
        print_error(str(exc))
        raise typer.Exit(code=1)
    finally:
        client.close()

    if output_json:
        typer.echo(json.dumps({"data": data, "meta": meta}, indent=2, default=str))
    else:
        paths_found = meta.get("paths_found", 0)
        if paths_found == 0:
            print_error(f"No paths found between '{source}' and '{target}'.")
        else:
            print_info(f"  {paths_found} path(s) found:")
            console.print()
            for i, p in enumerate(data, 1):
                labels = [n.get("label", "?") for n in p.get("nodes", [])]
                console.print(f"  [bold]{i}.[/bold] {' -> '.join(labels)}")
            console.print()
