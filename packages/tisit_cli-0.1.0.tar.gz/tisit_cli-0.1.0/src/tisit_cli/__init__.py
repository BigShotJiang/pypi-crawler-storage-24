"""TISIT CLI — terminal-native client for the TISIT learning platform."""
__version__ = "0.1.0"
