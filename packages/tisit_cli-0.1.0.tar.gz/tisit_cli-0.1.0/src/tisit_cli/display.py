"""Rich output helpers for terminal display."""
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table

console = Console()


def print_success(message: str):
    console.print(f"[green]{message}[/green]")


def print_error(message: str):
    console.print(f"[red]{message}[/red]")


def print_info(message: str):
    console.print(f"[blue]{message}[/blue]")


def print_note_table(notes: list, meta: dict | None = None):
    table = Table(title="Notes")
    table.add_column("ID", style="cyan", justify="right")
    table.add_column("Term", style="bold")
    table.add_column("Context")
    table.add_column("Category")
    table.add_column("Status")
    table.add_column("Created")

    for n in notes:
        created = (n.get("created_at") or "")[:10]
        table.add_row(
            str(n.get("id", "")),
            n.get("term", ""),
            n.get("context", ""),
            n.get("category", ""),
            n.get("completion_status", ""),
            created,
        )

    console.print(table)
    if meta:
        console.print(
            f"  Page {meta['page']}/{meta['pages']} "
            f"({meta['total']} total)"
        )


def print_note_detail(note: dict):
    term = note.get("term", "Unknown")
    context = note.get("context", "")
    header = f"[bold]{term}[/bold]  ({context})"

    lines = [header, ""]

    if note.get("category"):
        lines.append(f"Category: {note['category']}")
    domains = [note.get(d) for d in
               ("primary_domain", "secondary_domain", "tertiary_domain")
               if note.get(d)]
    if domains:
        lines.append(f"Domains: {' > '.join(domains)}")
    if note.get("completion_status"):
        lines.append(f"Status: {note['completion_status']}")
    if note.get("model_used"):
        lines.append(f"Model: {note['model_used']} ({note.get('provider', '')})")
    lines.append(f"ID: {note.get('id', '')}  Created: {(note.get('created_at') or '')[:10]}")
    lines.append("")

    console.print(Panel("\n".join(lines), title="Note Detail", border_style="cyan"))

    if note.get("description"):
        console.print(Panel(Markdown(note["description"]), title="Description"))

    if note.get("considerations"):
        console.print(Panel(Markdown(note["considerations"]), title="Considerations"))

    if note.get("examples"):
        for ex in note["examples"]:
            console.print(f"  [dim]Example:[/dim] {ex.get('example_text', '')}")

    if note.get("related_terms"):
        terms = [rt["term_text"] for rt in note["related_terms"]]
        console.print(f"  [dim]Related:[/dim] {', '.join(terms)}")

    if note.get("references"):
        for ref in note["references"]:
            console.print(f"  [dim]Ref:[/dim] {ref.get('reference_url', '')}")

    if note.get("question_answers"):
        console.print()
        for qa in note["question_answers"]:
            console.print(f"  [bold]Q:[/bold] {qa.get('question', '')}")
            console.print(f"  [dim]A:[/dim] {qa.get('answer', '')}")
            console.print()


def print_paper_table(papers: list, meta: dict | None = None):
    table = Table(title="Papers")
    table.add_column("ID", style="cyan", justify="right")
    table.add_column("Title", style="bold")
    table.add_column("Authors")
    table.add_column("Status")
    table.add_column("Uploaded")

    for p in papers:
        uploaded = (p.get("uploaded_at") or "")[:10]
        title = p.get("title") or "(untitled)"
        if len(title) > 50:
            title = title[:47] + "..."
        table.add_row(
            str(p.get("id", "")),
            title,
            p.get("authors", "") or "",
            p.get("status", ""),
            uploaded,
        )

    console.print(table)
    if meta:
        console.print(
            f"  Page {meta['page']}/{meta['pages']} "
            f"({meta['total']} total)"
        )


def print_paper_detail(paper: dict):
    title = paper.get("title") or "(untitled)"
    authors = paper.get("authors") or "Unknown"
    header = f"[bold]{title}[/bold]\nby {authors}"

    lines = [header, ""]

    if paper.get("url"):
        lines.append(f"URL: {paper['url']}")
    if paper.get("arxiv_id"):
        lines.append(f"arXiv: {paper['arxiv_id']}")
    lines.append(f"Status: {paper.get('status', '')}")
    lines.append(f"ID: {paper.get('id', '')}  Uploaded: {(paper.get('uploaded_at') or '')[:10]}")
    lines.append("")

    console.print(Panel("\n".join(lines), title="Paper Detail", border_style="cyan"))

    if paper.get("abstract"):
        console.print(Panel(Markdown(paper["abstract"]), title="Abstract"))

    if paper.get("simple_summary"):
        console.print(Panel(Markdown(paper["simple_summary"]), title="Summary"))

    if paper.get("key_findings"):
        console.print(Panel(Markdown(paper["key_findings"]), title="Key Findings"))

    if paper.get("problem_solution_impact"):
        console.print(Panel(Markdown(paper["problem_solution_impact"]), title="Problem / Solution / Impact"))


def print_article_table(articles: list, meta: dict | None = None):
    table = Table(title="Articles")
    table.add_column("ID", style="cyan", justify="right")
    table.add_column("Title", style="bold")
    table.add_column("Domain")
    table.add_column("Credibility")
    table.add_column("Status")
    table.add_column("Fetched")

    for a in articles:
        fetched = (a.get("fetched_at") or "")[:10]
        title = a.get("title") or "(untitled)"
        if len(title) > 45:
            title = title[:42] + "..."
        table.add_row(
            str(a.get("id", "")),
            title,
            a.get("domain", "") or "",
            a.get("credibility_score", "") or "",
            a.get("status", ""),
            fetched,
        )

    console.print(table)
    if meta:
        console.print(
            f"  Page {meta['page']}/{meta['pages']} "
            f"({meta['total']} total)"
        )


def print_article_detail(article: dict):
    title = article.get("title") or "(untitled)"
    author = article.get("author") or "Unknown"
    header = f"[bold]{title}[/bold]\nby {author}"

    lines = [header, ""]

    if article.get("url"):
        lines.append(f"URL: {article['url']}")
    if article.get("domain"):
        lines.append(f"Domain: {article['domain']}")
    if article.get("credibility_score"):
        lines.append(f"Credibility: {article['credibility_score']} ({article.get('bs_issues_count', 0)} issues)")
    lines.append(f"Status: {article.get('status', '')}")
    lines.append(f"ID: {article.get('id', '')}  Fetched: {(article.get('fetched_at') or '')[:10]}")
    lines.append("")

    console.print(Panel("\n".join(lines), title="Article Detail", border_style="cyan"))

    if article.get("excerpt"):
        console.print(Panel(article["excerpt"], title="Excerpt"))

    if article.get("simple_summary"):
        console.print(Panel(Markdown(article["simple_summary"]), title="Summary"))

    if article.get("key_findings"):
        console.print(Panel(Markdown(article["key_findings"]), title="Key Findings"))

    if article.get("problem_solution_impact"):
        console.print(Panel(Markdown(article["problem_solution_impact"]), title="Problem / Solution / Impact"))


def print_video_table(videos: list, meta: dict | None = None):
    table = Table(title="YouTube Videos")
    table.add_column("ID", style="cyan", justify="right")
    table.add_column("Title", style="bold")
    table.add_column("Channel")
    table.add_column("Status")
    table.add_column("Created")

    for v in videos:
        created = (v.get("created_at") or "")[:10]
        title = v.get("title") or "(untitled)"
        if len(title) > 45:
            title = title[:42] + "..."
        table.add_row(
            str(v.get("id", "")),
            title,
            v.get("channel_name", "") or "",
            v.get("status", ""),
            created,
        )

    console.print(table)
    if meta:
        console.print(
            f"  Page {meta['page']}/{meta['pages']} "
            f"({meta['total']} total)"
        )


def print_video_detail(video: dict):
    title = video.get("title") or "(untitled)"
    channel = video.get("channel_name") or "Unknown"
    header = f"[bold]{title}[/bold]\nChannel: {channel}"

    lines = [header, ""]

    if video.get("video_url"):
        lines.append(f"URL: {video['video_url']}")
    dur = video.get("duration_seconds")
    if dur:
        lines.append(f"Duration: {dur // 60}m {dur % 60}s")
    if video.get("view_count"):
        lines.append(f"Views: {video['view_count']:,}")
    if video.get("has_transcript"):
        lines.append("Transcript: available")
    if video.get("inferred_context"):
        lines.append(f"Context: {video['inferred_context']}")
    lines.append(f"Status: {video.get('status', '')}")
    lines.append(f"ID: {video.get('id', '')}  Created: {(video.get('created_at') or '')[:10]}")
    lines.append("")

    console.print(Panel("\n".join(lines), title="Video Detail", border_style="cyan"))

    if video.get("summary"):
        console.print(Panel(Markdown(video["summary"]), title="Summary"))

    if video.get("key_points"):
        points = "\n".join(f"- {p}" for p in video["key_points"])
        console.print(Panel(Markdown(points), title="Key Points"))


def print_tweet_table(tweets: list, meta: dict | None = None):
    table = Table(title="Tweets")
    table.add_column("ID", style="cyan", justify="right")
    table.add_column("Author", style="bold")
    table.add_column("Content")
    table.add_column("Thread")
    table.add_column("Status")
    table.add_column("Created")

    for t in tweets:
        created = (t.get("created_at") or "")[:10]
        content = t.get("content") or ""
        if len(content) > 50:
            content = content[:47] + "..."
        thread = "Yes" if t.get("is_thread") else ""
        table.add_row(
            str(t.get("id", "")),
            t.get("author_handle", "") or "",
            content,
            thread,
            t.get("status", ""),
            created,
        )

    console.print(table)
    if meta:
        console.print(
            f"  Page {meta['page']}/{meta['pages']} "
            f"({meta['total']} total)"
        )


def print_tweet_detail(tweet: dict):
    author = tweet.get("author_handle") or "Unknown"
    name = tweet.get("author_name") or ""
    header = f"[bold]@{author}[/bold]"
    if name:
        header += f" ({name})"

    lines = [header, ""]
    if tweet.get("tweet_url"):
        lines.append(f"URL: {tweet['tweet_url']}")
    if tweet.get("is_thread"):
        lines.append(f"Thread: {tweet.get('thread_count', 1)} tweets")
    if tweet.get("credibility_score"):
        lines.append(f"Credibility: {tweet['credibility_score']}")
    if tweet.get("author_verified"):
        lines.append("Verified: Yes")
    lines.append(f"Status: {tweet.get('status', '')}")
    lines.append(f"ID: {tweet.get('id', '')}  Created: {(tweet.get('created_at') or '')[:10]}")
    lines.append("")

    console.print(Panel("\n".join(lines), title="Tweet Detail", border_style="cyan"))

    content = tweet.get("thread_content") or tweet.get("content")
    if content:
        console.print(Panel(content, title="Content"))

    if tweet.get("summary"):
        console.print(Panel(Markdown(tweet["summary"]), title="Summary"))

    if tweet.get("key_points"):
        points = "\n".join(f"- {p}" for p in tweet["key_points"])
        console.print(Panel(Markdown(points), title="Key Points"))


def print_book_table(books: list, meta: dict | None = None):
    table = Table(title="Books")
    table.add_column("ID", style="cyan", justify="right")
    table.add_column("Title", style="bold")
    table.add_column("Authors")
    table.add_column("Status")
    table.add_column("Added")

    for b in books:
        created = (b.get("created_at") or "")[:10]
        title = b.get("title") or "(untitled)"
        if len(title) > 40:
            title = title[:37] + "..."
        authors = ", ".join(b.get("authors") or []) if b.get("authors") else ""
        table.add_row(
            str(b.get("id", "")),
            title,
            authors,
            b.get("status", ""),
            created,
        )

    console.print(table)
    if meta:
        console.print(
            f"  Page {meta['page']}/{meta['pages']} "
            f"({meta['total']} total)"
        )


def print_book_detail(book: dict):
    title = book.get("title") or "(untitled)"
    authors = ", ".join(book.get("authors") or []) if book.get("authors") else "Unknown"
    header = f"[bold]{title}[/bold]\nby {authors}"

    lines = [header, ""]

    if book.get("publisher"):
        lines.append(f"Publisher: {book['publisher']}")
    if book.get("published_date"):
        lines.append(f"Published: {book['published_date']}")
    if book.get("isbn_13"):
        lines.append(f"ISBN: {book['isbn_13']}")
    if book.get("page_count"):
        lines.append(f"Pages: {book['page_count']}")
    if book.get("categories"):
        lines.append(f"Categories: {', '.join(book['categories'])}")
    if book.get("inferred_context"):
        lines.append(f"Context: {book['inferred_context']}")
    lines.append(f"Status: {book.get('status', '')}")
    lines.append(f"ID: {book.get('id', '')}  Added: {(book.get('created_at') or '')[:10]}")
    lines.append("")

    console.print(Panel("\n".join(lines), title="Book Detail", border_style="cyan"))

    if book.get("description"):
        console.print(Panel(Markdown(book["description"]), title="Description"))

    if book.get("simple_summary"):
        console.print(Panel(Markdown(book["simple_summary"]), title="Summary"))

    if book.get("key_findings"):
        console.print(Panel(Markdown(book["key_findings"]), title="Key Findings"))


def print_podcast_table(podcasts: list, meta: dict | None = None):
    table = Table(title="Podcast Episodes")
    table.add_column("ID", style="cyan", justify="right")
    table.add_column("Title", style="bold")
    table.add_column("Podcast")
    table.add_column("Status")
    table.add_column("Created")

    for p in podcasts:
        created = (p.get("created_at") or "")[:10]
        title = p.get("title") or "(untitled)"
        if len(title) > 40:
            title = title[:37] + "..."
        table.add_row(
            str(p.get("id", "")),
            title,
            p.get("podcast_name", "") or "",
            p.get("status", ""),
            created,
        )

    console.print(table)
    if meta:
        console.print(
            f"  Page {meta['page']}/{meta['pages']} "
            f"({meta['total']} total)"
        )


def print_podcast_detail(podcast: dict):
    title = podcast.get("title") or "(untitled)"
    show = podcast.get("podcast_name") or "Unknown"
    header = f"[bold]{title}[/bold]\nPodcast: {show}"

    lines = [header, ""]

    if podcast.get("podcast_author"):
        lines.append(f"Host: {podcast['podcast_author']}")
    if podcast.get("episode_url"):
        lines.append(f"URL: {podcast['episode_url']}")
    dur = podcast.get("duration_seconds")
    if dur:
        lines.append(f"Duration: {dur // 60}m {dur % 60}s")
    if podcast.get("has_transcript"):
        lines.append("Transcript: available")
    if podcast.get("inferred_context"):
        lines.append(f"Context: {podcast['inferred_context']}")
    lines.append(f"Status: {podcast.get('status', '')}")
    lines.append(f"ID: {podcast.get('id', '')}  Created: {(podcast.get('created_at') or '')[:10]}")
    lines.append("")

    console.print(Panel("\n".join(lines), title="Podcast Detail", border_style="cyan"))

    if podcast.get("description"):
        console.print(Panel(podcast["description"], title="Description"))

    if podcast.get("summary"):
        console.print(Panel(Markdown(podcast["summary"]), title="Summary"))

    if podcast.get("key_points"):
        points = "\n".join(f"- {p}" for p in podcast["key_points"])
        console.print(Panel(Markdown(points), title="Key Points"))


def print_patent_table(patents: list, meta: dict | None = None):
    table = Table(title="Patents")
    table.add_column("ID", style="cyan", justify="right")
    table.add_column("Number", style="bold")
    table.add_column("Title")
    table.add_column("Potential")
    table.add_column("Status")
    table.add_column("Fetched")

    for p in patents:
        fetched = (p.get("fetched_at") or "")[:10]
        title = p.get("title") or "(untitled)"
        if len(title) > 40:
            title = title[:37] + "..."
        table.add_row(
            str(p.get("id", "")),
            p.get("patent_number", "") or "",
            title,
            p.get("commercial_potential", "") or "",
            p.get("status", ""),
            fetched,
        )

    console.print(table)
    if meta:
        console.print(
            f"  Page {meta['page']}/{meta['pages']} "
            f"({meta['total']} total)"
        )


def print_patent_detail(patent: dict):
    title = patent.get("title") or "(untitled)"
    number = patent.get("patent_number") or ""
    header = f"[bold]{title}[/bold]"
    if number:
        header += f"\nPatent: {number}"

    lines = [header, ""]

    if patent.get("url"):
        lines.append(f"URL: {patent['url']}")
    if patent.get("inventors"):
        names = [i.get("name", "") for i in patent["inventors"]]
        lines.append(f"Inventors: {', '.join(names)}")
    if patent.get("assignees"):
        names = [a.get("name", "") for a in patent["assignees"]]
        lines.append(f"Assignees: {', '.join(names)}")
    if patent.get("commercial_potential"):
        lines.append(f"Commercial Potential: {patent['commercial_potential']}")
    lines.append(f"Status: {patent.get('status', '')}")
    lines.append(f"ID: {patent.get('id', '')}  Fetched: {(patent.get('fetched_at') or '')[:10]}")
    lines.append("")

    console.print(Panel("\n".join(lines), title="Patent Detail", border_style="cyan"))

    if patent.get("abstract"):
        console.print(Panel(Markdown(patent["abstract"]), title="Abstract"))

    if patent.get("simple_summary"):
        console.print(Panel(Markdown(patent["simple_summary"]), title="Summary"))

    if patent.get("key_findings"):
        console.print(Panel(Markdown(patent["key_findings"]), title="Key Innovations"))

    if patent.get("claim_analysis"):
        console.print(Panel(Markdown(patent["claim_analysis"]), title="Claim Analysis"))


def print_search_results(results: list, meta: dict | None = None):
    table = Table(title="Search Results")
    table.add_column("Type", style="cyan")
    table.add_column("ID", justify="right")
    table.add_column("Title", style="bold")
    table.add_column("Snippet")
    table.add_column("Score", justify="right")

    for r in results:
        snippet = r.get("snippet", "")
        if len(snippet) > 80:
            snippet = snippet[:77] + "..."
        table.add_row(
            r.get("type", ""),
            str(r.get("id", "")),
            r.get("title", ""),
            snippet,
            f"{r.get('similarity', 0):.3f}",
        )

    console.print(table)
    if meta:
        console.print(f"  Query: \"{meta.get('query', '')}\"  ({meta.get('count', 0)} results)")


def print_queued(data: dict):
    console.print(Panel(
        f"[yellow]Request queued[/yellow]\n\n"
        f"  Term: {data.get('term', '')}\n"
        f"  Context: {data.get('context', '')}\n"
        f"  Request ID: {data.get('request_id', '')}\n"
        f"  Task ID: {data.get('celery_task_id', '')}\n"
        f"  Status: {data.get('status', 'queued')}\n\n"
        f"[dim]Note creation is async. Check with: tisit note list[/dim]",
        title="Note Queued",
        border_style="yellow",
    ))
