"""Tests for knowledge graph CLI commands."""
import httpx
import respx

from tisit_cli.main import app

BASE = "http://localhost:5001/api/v1"


def _patch_auth(cli_runner, tmp_config_dir, mock_token):
    (tmp_config_dir / "token").write_text(mock_token)
    import tomli_w
    with open(tmp_config_dir / "config.toml", "wb") as f:
        tomli_w.dump({"api_url": "http://localhost:5001"}, f)


@respx.mock
def test_graph_stats(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/graph/stats").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {"total_nodes": 150, "total_edges": 420,
                     "density": 0.0189, "is_connected": True,
                     "node_types": {"concept": 100, "domain": 30, "person": 20}},
        })
    )
    result = cli_runner.invoke(app, ["graph", "stats"])
    assert result.exit_code == 0
    assert "150" in result.output
    assert "420" in result.output


@respx.mock
def test_graph_neighbors(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/graph/neighbors/machine%20learning").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [
                {"id": "deep_learning", "label": "Deep Learning",
                 "type": "concept", "relationship": "PART_OF", "weight": 0.9},
                {"id": "neural_networks", "label": "Neural Networks",
                 "type": "concept", "relationship": "REQUIRES", "weight": 0.8},
            ],
            "meta": {"term": "machine learning", "count": 2},
        })
    )
    result = cli_runner.invoke(app, ["graph", "neighbors", "machine learning"])
    assert result.exit_code == 0
    assert "Deep Learning" in result.output


@respx.mock
def test_graph_paths(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.post(f"{BASE}/graph/paths").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [
                {"nodes": [
                    {"id": "ml", "label": "Machine Learning", "type": "concept"},
                    {"id": "ai", "label": "AI", "type": "domain"},
                    {"id": "nlp", "label": "NLP", "type": "concept"},
                ], "length": 3},
            ],
            "meta": {"source": "Machine Learning", "target": "NLP", "paths_found": 1},
        })
    )
    result = cli_runner.invoke(app, ["graph", "paths", "Machine Learning", "NLP"])
    assert result.exit_code == 0
    assert "Machine Learning" in result.output
    assert "NLP" in result.output


@respx.mock
def test_graph_paths_not_found(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.post(f"{BASE}/graph/paths").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [],
            "meta": {"source": "A", "target": "B", "paths_found": 0},
        })
    )
    result = cli_runner.invoke(app, ["graph", "paths", "A", "B"])
    assert result.exit_code == 0
    assert "no paths" in result.output.lower()


def test_graph_stats_not_logged_in(cli_runner, tmp_config_dir):
    result = cli_runner.invoke(app, ["graph", "stats"])
    assert result.exit_code == 1
    assert "login" in result.output.lower()
