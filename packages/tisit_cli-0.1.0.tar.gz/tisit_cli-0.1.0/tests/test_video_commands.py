"""Tests for video CLI commands."""
import httpx
import respx

from tisit_cli.main import app

BASE = "http://localhost:5001/api/v1"


def _patch_auth(cli_runner, tmp_config_dir, mock_token):
    (tmp_config_dir / "token").write_text(mock_token)
    import tomli_w
    with open(tmp_config_dir / "config.toml", "wb") as f:
        tomli_w.dump({"api_url": "http://localhost:5001"}, f)


@respx.mock
def test_video_list(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/videos").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [{"id": 1, "title": "AI Tutorial", "channel_name": "TechCh",
                      "status": "completed", "created_at": "2026-01-01T00:00:00"}],
            "meta": {"page": 1, "per_page": 20, "total": 1, "pages": 1},
        })
    )
    result = cli_runner.invoke(app, ["video", "list"])
    assert result.exit_code == 0
    assert "AI Tutorial" in result.output


@respx.mock
def test_video_view(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/videos/1").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {"id": 1, "title": "AI Tutorial", "channel_name": "TechCh",
                     "video_url": "https://youtube.com/watch?v=abc",
                     "summary": "About AI", "status": "completed",
                     "duration_seconds": 600},
        })
    )
    result = cli_runner.invoke(app, ["video", "view", "1"])
    assert result.exit_code == 0
    assert "AI Tutorial" in result.output


@respx.mock
def test_video_add(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.post(f"{BASE}/videos").mock(
        return_value=httpx.Response(202, json={
            "success": True,
            "data": {"video_id": 42, "is_duplicate": False,
                     "status": "pending", "message": "Video queued."},
        })
    )
    result = cli_runner.invoke(app, ["video", "add", "https://youtube.com/watch?v=test"])
    assert result.exit_code == 0
    assert "42" in result.output


@respx.mock
def test_video_delete_with_yes(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.delete(f"{BASE}/videos/1").mock(
        return_value=httpx.Response(200, json={
            "success": True, "data": {"message": "Video deleted"},
        })
    )
    result = cli_runner.invoke(app, ["video", "delete", "1", "--yes"])
    assert result.exit_code == 0
    assert "deleted" in result.output.lower()


def test_video_list_not_logged_in(cli_runner, tmp_config_dir):
    result = cli_runner.invoke(app, ["video", "list"])
    assert result.exit_code == 1
    assert "login" in result.output.lower()
