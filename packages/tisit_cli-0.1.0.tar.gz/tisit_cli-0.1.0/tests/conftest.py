"""Shared test fixtures for the TISIT CLI test suite."""
import os
from unittest.mock import patch

import pytest
from typer.testing import CliRunner

MOCK_TOKEN = "tsk_" + "a" * 48


@pytest.fixture
def cli_runner():
    return CliRunner()


@pytest.fixture
def mock_token():
    return MOCK_TOKEN


@pytest.fixture
def tmp_config_dir(tmp_path):
    """Redirect ~/.tisit to a temp directory."""
    config_dir = tmp_path / ".tisit"
    config_dir.mkdir()
    with patch("tisit_cli.config.CONFIG_DIR", config_dir), \
         patch("tisit_cli.config.CONFIG_FILE", config_dir / "config.toml"), \
         patch("tisit_cli.auth.TOKEN_FILE", config_dir / "token"):
        yield config_dir


@pytest.fixture
def env_api_url():
    """Set TISIT_API_URL to localhost for testing."""
    with patch.dict(os.environ, {"TISIT_API_URL": "http://localhost:5001"}):
        yield "http://localhost:5001"
