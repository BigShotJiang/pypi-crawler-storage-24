"""Tests for focus mode CLI commands."""
import httpx
import respx

from tisit_cli.main import app

BASE = "http://localhost:5001/api/v1"


def _patch_auth(cli_runner, tmp_config_dir, mock_token):
    (tmp_config_dir / "token").write_text(mock_token)
    import tomli_w
    with open(tmp_config_dir / "config.toml", "wb") as f:
        tomli_w.dump({"api_url": "http://localhost:5001"}, f)


@respx.mock
def test_focus_list(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/focus").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [{"id": 1, "topic_name": "ML Basics", "status": "active",
                      "coverage_score": 45.0, "mastery_score": 30.0,
                      "total_study_time_minutes": 120}],
        })
    )
    result = cli_runner.invoke(app, ["focus", "list"])
    assert result.exit_code == 0
    assert "ML Basics" in result.output


@respx.mock
def test_focus_create(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.post(f"{BASE}/focus").mock(
        return_value=httpx.Response(201, json={
            "success": True,
            "data": {"id": 5, "topic_name": "Quantum", "status": "active"},
        })
    )
    result = cli_runner.invoke(app, ["focus", "create", "Quantum"])
    assert result.exit_code == 0
    assert "5" in result.output


@respx.mock
def test_focus_view(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/focus/1").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {
                "bubble": {"id": 1, "topic_name": "NLP", "status": "active",
                           "coverage_score": 60, "mastery_score": 40,
                           "total_study_time_minutes": 90},
                "concepts": [{"id": 10, "name": "Tokenization", "category": "term",
                              "mastery_level": 80, "times_reviewed": 5}],
            },
        })
    )
    result = cli_runner.invoke(app, ["focus", "view", "1"])
    assert result.exit_code == 0
    assert "NLP" in result.output
    assert "Tokenization" in result.output


@respx.mock
def test_focus_delete(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.delete(f"{BASE}/focus/1").mock(
        return_value=httpx.Response(200, json={
            "success": True, "data": {"message": "Topic bubble deleted"},
        })
    )
    result = cli_runner.invoke(app, ["focus", "delete", "1", "--yes"])
    assert result.exit_code == 0
    assert "deleted" in result.output.lower()


@respx.mock
def test_focus_concept_add(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.post(f"{BASE}/focus/1/concepts").mock(
        return_value=httpx.Response(201, json={
            "success": True,
            "data": {"id": 20, "name": "Attention", "category": "term"},
        })
    )
    result = cli_runner.invoke(app, ["focus", "concept", "add", "1", "Attention"])
    assert result.exit_code == 0
    assert "20" in result.output


def test_focus_list_not_logged_in(cli_runner, tmp_config_dir):
    result = cli_runner.invoke(app, ["focus", "list"])
    assert result.exit_code == 1
    assert "login" in result.output.lower()
