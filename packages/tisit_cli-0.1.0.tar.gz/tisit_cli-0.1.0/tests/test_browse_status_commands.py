"""Tests for browse and status CLI commands."""
import httpx
import respx

from tisit_cli.main import app

BASE = "http://localhost:5001/api/v1"


def _patch_auth(cli_runner, tmp_config_dir, mock_token):
    (tmp_config_dir / "token").write_text(mock_token)
    import tomli_w
    with open(tmp_config_dir / "config.toml", "wb") as f:
        tomli_w.dump({"api_url": "http://localhost:5001"}, f)


@respx.mock
def test_browse_notes(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/notes").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [{"id": 1, "term": "ML", "context": "AI",
                      "category": "Tech", "completion_status": "complete",
                      "created_at": "2026-01-01T00:00:00"}],
            "meta": {"page": 1, "per_page": 20, "total": 1, "pages": 1},
        })
    )
    result = cli_runner.invoke(app, ["browse", "--type", "notes"])
    assert result.exit_code == 0
    assert "ML" in result.output


@respx.mock
def test_browse_papers(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/papers").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [{"id": 1, "title": "Paper", "authors": "X",
                      "status": "processed", "uploaded_at": "2026-01-01T00:00:00"}],
            "meta": {"page": 1, "per_page": 20, "total": 1, "pages": 1},
        })
    )
    result = cli_runner.invoke(app, ["browse", "--type", "papers"])
    assert result.exit_code == 0
    assert "Paper" in result.output


@respx.mock
def test_browse_json(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/articles").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [{"id": 1, "title": "Article"}],
            "meta": {"page": 1, "per_page": 20, "total": 1, "pages": 1},
        })
    )
    result = cli_runner.invoke(app, ["browse", "--type", "articles", "--json"])
    assert result.exit_code == 0
    assert '"title": "Article"' in result.output


def test_browse_invalid_type(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    result = cli_runner.invoke(app, ["browse", "--type", "invalid"])
    assert result.exit_code == 1


@respx.mock
def test_status_connected(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/status").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {"status": "ok", "database": "connected"},
        })
    )
    result = cli_runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "connected" in result.output


def test_status_not_logged_in(cli_runner, tmp_config_dir):
    result = cli_runner.invoke(app, ["status"])
    assert result.exit_code == 0
    assert "not logged in" in result.output.lower()
