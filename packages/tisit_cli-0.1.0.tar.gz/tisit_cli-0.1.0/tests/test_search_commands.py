"""Tests for search CLI command."""
import httpx
import respx

from tisit_cli.main import app

BASE = "http://localhost:5001/api/v1"


def _patch_auth(cli_runner, tmp_config_dir, mock_token):
    (tmp_config_dir / "token").write_text(mock_token)
    import tomli_w
    with open(tmp_config_dir / "config.toml", "wb") as f:
        tomli_w.dump({"api_url": "http://localhost:5001"}, f)


@respx.mock
def test_search(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/search").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [
                {"type": "note", "id": 1, "title": "ML",
                 "snippet": "Machine learning...", "similarity": 0.95},
            ],
            "meta": {"query": "machine learning", "count": 1},
        })
    )
    result = cli_runner.invoke(app, ["search", "machine learning"])
    assert result.exit_code == 0
    assert "ML" in result.output


@respx.mock
def test_search_json(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/search").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [
                {"type": "note", "id": 1, "title": "ML",
                 "snippet": "...", "similarity": 0.95},
            ],
            "meta": {"query": "ML", "count": 1},
        })
    )
    result = cli_runner.invoke(app, ["search", "--json", "ML"])
    assert result.exit_code == 0
    assert '"similarity"' in result.output


@respx.mock
def test_search_no_results(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/search").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [],
            "meta": {"query": "nonexistent", "count": 0},
        })
    )
    result = cli_runner.invoke(app, ["search", "nonexistent"])
    assert result.exit_code == 0
    assert "no results" in result.output.lower()


def test_search_not_logged_in(cli_runner, tmp_config_dir):
    result = cli_runner.invoke(app, ["search", "anything"])
    assert result.exit_code == 1
    assert "login" in result.output.lower()
