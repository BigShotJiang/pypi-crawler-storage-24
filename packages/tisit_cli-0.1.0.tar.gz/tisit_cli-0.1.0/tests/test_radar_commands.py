"""Tests for radar CLI commands."""
import httpx
import respx

from tisit_cli.main import app

BASE = "http://localhost:5001/api/v1"


def _patch_auth(cli_runner, tmp_config_dir, mock_token):
    (tmp_config_dir / "token").write_text(mock_token)
    import tomli_w
    with open(tmp_config_dir / "config.toml", "wb") as f:
        tomli_w.dump({"api_url": "http://localhost:5001"}, f)


@respx.mock
def test_radar_status(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/radar/status").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {
                "topics": [{"id": 1, "topic": "AI Safety", "keywords": ["alignment"]}],
                "recent_runs": [{"id": 10, "topic_name": "AI Safety", "status": "completed",
                                 "total_sources_fetched": 5, "total_notes_generated": 2,
                                 "run_timestamp": "2026-01-01T00:00:00"}],
            },
        })
    )
    result = cli_runner.invoke(app, ["radar", "status"])
    assert result.exit_code == 0
    assert "AI Safety" in result.output


@respx.mock
def test_radar_topic_list(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/radar/topics").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [{"id": 1, "topic": "ML", "keywords": ["deep learning"]}],
        })
    )
    result = cli_runner.invoke(app, ["radar", "topic", "list"])
    assert result.exit_code == 0
    assert "ML" in result.output


@respx.mock
def test_radar_topic_add(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.post(f"{BASE}/radar/topics").mock(
        return_value=httpx.Response(201, json={
            "success": True,
            "data": {"id": 5, "topic": "Quantum", "keywords": ["qubits"]},
        })
    )
    result = cli_runner.invoke(app, ["radar", "topic", "add", "Quantum", "--keywords", "qubits"])
    assert result.exit_code == 0
    assert "5" in result.output


@respx.mock
def test_radar_topic_delete(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.delete(f"{BASE}/radar/topics/1").mock(
        return_value=httpx.Response(200, json={
            "success": True, "data": {"message": "Watch topic deleted"},
        })
    )
    result = cli_runner.invoke(app, ["radar", "topic", "delete", "1", "--yes"])
    assert result.exit_code == 0
    assert "deleted" in result.output.lower()


@respx.mock
def test_radar_run(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/radar/runs/10").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {
                "run": {"id": 10, "topic_name": "AI", "status": "completed",
                        "total_sources_fetched": 3},
                "sources": [{"id": 1, "source_type": "arxiv_paper",
                             "title": "New AI Paper", "triage_status": "pending"}],
            },
        })
    )
    result = cli_runner.invoke(app, ["radar", "run", "10"])
    assert result.exit_code == 0
    assert "New AI Paper" in result.output


@respx.mock
def test_radar_source_accept(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.post(f"{BASE}/radar/sources/1/accept").mock(
        return_value=httpx.Response(200, json={
            "success": True, "data": {"message": "Source accepted"},
        })
    )
    result = cli_runner.invoke(app, ["radar", "source", "accept", "1"])
    assert result.exit_code == 0
    assert "accepted" in result.output.lower()


@respx.mock
def test_radar_source_ignore(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.post(f"{BASE}/radar/sources/1/ignore").mock(
        return_value=httpx.Response(200, json={
            "success": True, "data": {"message": "Source ignored"},
        })
    )
    result = cli_runner.invoke(app, ["radar", "source", "ignore", "1"])
    assert result.exit_code == 0
    assert "ignored" in result.output.lower()
