"""Tests for config module."""
import os
from unittest.mock import patch

from tisit_cli.config import Config


def test_default_values(tmp_config_dir):
    cfg = Config()
    assert cfg.api_url == "https://tisit.ai"
    assert cfg.get("format") == "table"


def test_save_and_load(tmp_config_dir):
    cfg = Config()
    cfg.set("api_url", "http://localhost:5001")
    cfg.save()

    cfg2 = Config()
    assert cfg2.api_url == "http://localhost:5001"


def test_env_var_override(tmp_config_dir):
    with patch.dict(os.environ, {"TISIT_API_URL": "http://test:9999"}):
        cfg = Config()
        assert cfg.api_url == "http://test:9999"


def test_env_var_strips_trailing_slash(tmp_config_dir):
    with patch.dict(os.environ, {"TISIT_API_URL": "http://test:9999/"}):
        cfg = Config()
        assert cfg.api_url == "http://test:9999"


def test_missing_config_dir(tmp_path):
    config_dir = tmp_path / "nonexistent" / ".tisit"
    with patch("tisit_cli.config.CONFIG_DIR", config_dir), \
         patch("tisit_cli.config.CONFIG_FILE", config_dir / "config.toml"):
        cfg = Config()
        cfg.save()
        assert (config_dir / "config.toml").exists()
