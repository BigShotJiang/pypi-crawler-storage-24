"""Tests for chat CLI commands."""
import httpx
import respx

from tisit_cli.main import app

BASE = "http://localhost:5001/api/v1"


def _patch_auth(cli_runner, tmp_config_dir, mock_token):
    (tmp_config_dir / "token").write_text(mock_token)
    import tomli_w
    with open(tmp_config_dir / "config.toml", "wb") as f:
        tomli_w.dump({"api_url": "http://localhost:5001"}, f)


@respx.mock
def test_chat_ask(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.post(f"{BASE}/chat/ask").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {
                "answer": "Machine learning is a subset of AI.",
                "sources_used": 3,
                "session_id": 42,
            },
        })
    )
    result = cli_runner.invoke(app, ["chat", "ask", "What is machine learning?"])
    assert result.exit_code == 0
    assert "Machine learning" in result.output
    assert "3" in result.output


@respx.mock
def test_chat_ask_json(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.post(f"{BASE}/chat/ask").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {
                "answer": "Answer here.",
                "sources_used": 1,
                "session_id": 10,
            },
        })
    )
    result = cli_runner.invoke(app, ["chat", "ask", "--json", "test question"])
    assert result.exit_code == 0
    assert '"answer"' in result.output
    assert '"session_id"' in result.output


@respx.mock
def test_chat_ask_with_session(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.post(f"{BASE}/chat/ask").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {"answer": "Follow-up answer.", "sources_used": 2, "session_id": 42},
        })
    )
    result = cli_runner.invoke(app, ["chat", "ask", "--session", "42", "follow up"])
    assert result.exit_code == 0
    assert "Follow-up" in result.output


def test_chat_ask_not_logged_in(cli_runner, tmp_config_dir):
    result = cli_runner.invoke(app, ["chat", "ask", "anything"])
    assert result.exit_code == 1
    assert "login" in result.output.lower()
