"""Tests for the API client."""
import httpx
import pytest
import respx

from tisit_cli.client import TisitClient
from tisit_cli.exceptions import APIError, AuthenticationError, NotFoundError

BASE = "http://localhost:5001/api/v1"
TOKEN = "tsk_" + "a" * 48


@pytest.fixture
def client():
    c = TisitClient("http://localhost:5001", TOKEN)
    yield c
    c.close()


@respx.mock
def test_status(client):
    respx.get(f"{BASE}/status").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {"status": "ok", "database": "connected"},
        })
    )
    data = client.status()
    assert data["status"] == "ok"


@respx.mock
def test_list_notes(client):
    respx.get(f"{BASE}/notes").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [{"id": 1, "term": "ML", "context": "AI"}],
            "meta": {"page": 1, "per_page": 20, "total": 1, "pages": 1},
        })
    )
    notes, meta = client.list_notes()
    assert len(notes) == 1
    assert notes[0]["term"] == "ML"
    assert meta["total"] == 1


@respx.mock
def test_get_note(client):
    respx.get(f"{BASE}/notes/1").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {"id": 1, "term": "ML", "context": "AI", "description": "..."},
        })
    )
    note = client.get_note(1)
    assert note["id"] == 1


@respx.mock
def test_get_note_not_found(client):
    respx.get(f"{BASE}/notes/999").mock(
        return_value=httpx.Response(404, json={
            "success": False,
            "error": {"message": "Note not found"},
        })
    )
    with pytest.raises(NotFoundError):
        client.get_note(999)


@respx.mock
def test_create_note(client):
    respx.post(f"{BASE}/notes").mock(
        return_value=httpx.Response(202, json={
            "success": True,
            "data": {
                "request_id": 42,
                "celery_task_id": "abc-123",
                "status": "queued",
                "term": "ML",
                "context": "AI",
            },
        })
    )
    data = client.create_note("ML", "AI")
    assert data["request_id"] == 42
    assert data["status"] == "queued"


@respx.mock
def test_delete_note(client):
    respx.delete(f"{BASE}/notes/1").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {"message": "Note deleted"},
        })
    )
    data = client.delete_note(1)
    assert data["message"] == "Note deleted"


@respx.mock
def test_list_papers(client):
    respx.get(f"{BASE}/papers").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [{"id": 1, "title": "Test Paper", "authors": "A"}],
            "meta": {"page": 1, "per_page": 20, "total": 1, "pages": 1},
        })
    )
    papers, meta = client.list_papers()
    assert len(papers) == 1
    assert papers[0]["title"] == "Test Paper"


@respx.mock
def test_get_paper(client):
    respx.get(f"{BASE}/papers/1").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {"id": 1, "title": "Test Paper"},
        })
    )
    paper = client.get_paper(1)
    assert paper["id"] == 1


@respx.mock
def test_add_paper(client):
    respx.post(f"{BASE}/papers").mock(
        return_value=httpx.Response(202, json={
            "success": True,
            "data": {"paper_id": 42, "is_duplicate": False, "status": "pending"},
        })
    )
    data = client.add_paper("https://example.com/paper.pdf")
    assert data["paper_id"] == 42


@respx.mock
def test_delete_paper(client):
    respx.delete(f"{BASE}/papers/1").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {"message": "Paper deleted"},
        })
    )
    data = client.delete_paper(1)
    assert data["message"] == "Paper deleted"


@respx.mock
def test_search(client):
    respx.get(f"{BASE}/search").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [
                {"type": "note", "id": 1, "title": "ML", "snippet": "...", "similarity": 0.95},
            ],
            "meta": {"query": "machine learning", "count": 1},
        })
    )
    results, meta = client.search("machine learning")
    assert len(results) == 1
    assert results[0]["similarity"] == 0.95


@respx.mock
def test_401_raises_auth_error(client):
    respx.get(f"{BASE}/notes").mock(
        return_value=httpx.Response(401, json={
            "success": False,
            "error": {"message": "Authentication required"},
        })
    )
    with pytest.raises(AuthenticationError):
        client.list_notes()


@respx.mock
def test_500_raises_api_error(client):
    respx.get(f"{BASE}/notes").mock(
        return_value=httpx.Response(500, json={
            "success": False,
            "error": {"message": "Internal server error"},
        })
    )
    with pytest.raises(APIError):
        client.list_notes()
