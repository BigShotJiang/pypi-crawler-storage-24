"""Tests for paper CLI commands."""
import httpx
import respx

from tisit_cli.main import app

BASE = "http://localhost:5001/api/v1"


def _patch_auth(cli_runner, tmp_config_dir, mock_token):
    (tmp_config_dir / "token").write_text(mock_token)
    import tomli_w
    with open(tmp_config_dir / "config.toml", "wb") as f:
        tomli_w.dump({"api_url": "http://localhost:5001"}, f)


@respx.mock
def test_paper_list(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/papers").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [{"id": 1, "title": "Attention Is All You Need",
                      "authors": "Vaswani et al.", "status": "processed",
                      "uploaded_at": "2026-01-01T00:00:00"}],
            "meta": {"page": 1, "per_page": 20, "total": 1, "pages": 1},
        })
    )
    result = cli_runner.invoke(app, ["paper", "list"])
    assert result.exit_code == 0
    assert "Attention" in result.output


@respx.mock
def test_paper_list_json(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/papers").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [{"id": 1, "title": "Test Paper"}],
            "meta": {"page": 1, "per_page": 20, "total": 1, "pages": 1},
        })
    )
    result = cli_runner.invoke(app, ["paper", "list", "--json"])
    assert result.exit_code == 0
    assert '"title": "Test Paper"' in result.output


@respx.mock
def test_paper_view(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/papers/1").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {"id": 1, "title": "Test Paper", "authors": "Author A",
                     "abstract": "This paper studies...",
                     "status": "processed"},
        })
    )
    result = cli_runner.invoke(app, ["paper", "view", "1"])
    assert result.exit_code == 0
    assert "Test Paper" in result.output


@respx.mock
def test_paper_add(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.post(f"{BASE}/papers").mock(
        return_value=httpx.Response(202, json={
            "success": True,
            "data": {
                "paper_id": 42, "is_duplicate": False,
                "status": "pending", "message": "Paper queued for processing.",
            },
        })
    )
    result = cli_runner.invoke(app, ["paper", "add", "https://arxiv.org/pdf/1706.03762"])
    assert result.exit_code == 0
    assert "42" in result.output


@respx.mock
def test_paper_add_duplicate(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.post(f"{BASE}/papers").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {
                "paper_id": 10, "is_duplicate": True,
                "status": "processed",
                "message": "Paper already exists — you now have access.",
            },
        })
    )
    result = cli_runner.invoke(app, ["paper", "add", "https://example.com/dup.pdf"])
    assert result.exit_code == 0
    assert "already exists" in result.output


@respx.mock
def test_paper_delete_with_yes(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.delete(f"{BASE}/papers/1").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {"message": "Paper deleted"},
        })
    )
    result = cli_runner.invoke(app, ["paper", "delete", "1", "--yes"])
    assert result.exit_code == 0
    assert "deleted" in result.output.lower()


def test_paper_list_not_logged_in(cli_runner, tmp_config_dir):
    result = cli_runner.invoke(app, ["paper", "list"])
    assert result.exit_code == 1
    assert "login" in result.output.lower()
