"""Tests for podcast CLI commands."""
import httpx
import respx

from tisit_cli.main import app

BASE = "http://localhost:5001/api/v1"


def _patch_auth(cli_runner, tmp_config_dir, mock_token):
    (tmp_config_dir / "token").write_text(mock_token)
    import tomli_w
    with open(tmp_config_dir / "config.toml", "wb") as f:
        tomli_w.dump({"api_url": "http://localhost:5001"}, f)


@respx.mock
def test_podcast_list(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/podcasts").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [{"id": 1, "title": "AI Episode", "podcast_name": "Tech Pod",
                      "status": "completed", "created_at": "2026-01-01T00:00:00"}],
            "meta": {"page": 1, "per_page": 20, "total": 1, "pages": 1},
        })
    )
    result = cli_runner.invoke(app, ["podcast", "list"])
    assert result.exit_code == 0
    assert "AI Episode" in result.output


@respx.mock
def test_podcast_view(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/podcasts/1").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {"id": 1, "title": "AI Episode", "podcast_name": "Tech Pod",
                     "episode_url": "https://spotify.com/ep/1",
                     "summary": "About AI", "status": "completed"},
        })
    )
    result = cli_runner.invoke(app, ["podcast", "view", "1"])
    assert result.exit_code == 0
    assert "AI Episode" in result.output


@respx.mock
def test_podcast_add(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.post(f"{BASE}/podcasts").mock(
        return_value=httpx.Response(202, json={
            "success": True,
            "data": {"podcast_id": 42, "is_duplicate": False,
                     "status": "pending", "message": "Queued."},
        })
    )
    result = cli_runner.invoke(app, ["podcast", "add", "https://spotify.com/ep/new"])
    assert result.exit_code == 0
    assert "42" in result.output


@respx.mock
def test_podcast_delete_with_yes(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.delete(f"{BASE}/podcasts/1").mock(
        return_value=httpx.Response(200, json={
            "success": True, "data": {"message": "Podcast episode deleted"},
        })
    )
    result = cli_runner.invoke(app, ["podcast", "delete", "1", "--yes"])
    assert result.exit_code == 0
    assert "deleted" in result.output.lower()


def test_podcast_list_not_logged_in(cli_runner, tmp_config_dir):
    result = cli_runner.invoke(app, ["podcast", "list"])
    assert result.exit_code == 1
    assert "login" in result.output.lower()
