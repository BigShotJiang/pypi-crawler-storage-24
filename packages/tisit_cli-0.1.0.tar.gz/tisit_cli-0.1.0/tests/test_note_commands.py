"""Tests for note CLI commands."""
import httpx
import respx

from tisit_cli.main import app

BASE = "http://localhost:5001/api/v1"


def _patch_auth(cli_runner, tmp_config_dir, mock_token):
    """Helper: write token and config so commands can authenticate."""
    (tmp_config_dir / "token").write_text(mock_token)
    import tomli_w
    with open(tmp_config_dir / "config.toml", "wb") as f:
        tomli_w.dump({"api_url": "http://localhost:5001"}, f)


@respx.mock
def test_note_list(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/notes").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [{"id": 1, "term": "ML", "context": "AI",
                      "category": "Tech", "completion_status": "complete",
                      "created_at": "2026-01-01T00:00:00"}],
            "meta": {"page": 1, "per_page": 20, "total": 1, "pages": 1},
        })
    )
    result = cli_runner.invoke(app, ["note", "list"])
    assert result.exit_code == 0
    assert "ML" in result.output


@respx.mock
def test_note_list_json(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/notes").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [{"id": 1, "term": "ML", "context": "AI"}],
            "meta": {"page": 1, "per_page": 20, "total": 1, "pages": 1},
        })
    )
    result = cli_runner.invoke(app, ["note", "list", "--json"])
    assert result.exit_code == 0
    assert '"term": "ML"' in result.output


@respx.mock
def test_note_view(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/notes/1").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {"id": 1, "term": "ML", "context": "AI",
                     "description": "Machine learning is...",
                     "category": "Tech"},
        })
    )
    result = cli_runner.invoke(app, ["note", "view", "1"])
    assert result.exit_code == 0
    assert "ML" in result.output


@respx.mock
def test_note_add(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.post(f"{BASE}/notes").mock(
        return_value=httpx.Response(202, json={
            "success": True,
            "data": {
                "request_id": 42, "celery_task_id": "abc-123",
                "status": "queued", "term": "ML", "context": "AI",
            },
        })
    )
    result = cli_runner.invoke(app, ["note", "add", "ML", "AI"])
    assert result.exit_code == 0
    assert "queued" in result.output.lower() or "Queued" in result.output


@respx.mock
def test_note_delete_with_yes(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.delete(f"{BASE}/notes/1").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {"message": "Note deleted"},
        })
    )
    result = cli_runner.invoke(app, ["note", "delete", "1", "--yes"])
    assert result.exit_code == 0
    assert "deleted" in result.output.lower()


def test_note_list_not_logged_in(cli_runner, tmp_config_dir):
    result = cli_runner.invoke(app, ["note", "list"])
    assert result.exit_code == 1
    assert "login" in result.output.lower()
