"""Tests for auth module."""
from unittest.mock import patch, MagicMock

from tisit_cli.auth import (
    store_token, get_token, delete_token, validate_token_format,
)


def test_validate_token_format_valid():
    assert validate_token_format("tsk_" + "a" * 48) is True


def test_validate_token_format_no_prefix():
    assert validate_token_format("invalid_token") is False


def test_validate_token_format_too_short():
    assert validate_token_format("tsk_abc") is False


def test_file_fallback_store_and_get(tmp_config_dir):
    token = "tsk_" + "b" * 48
    mock_keyring = MagicMock()
    mock_keyring.set_password.side_effect = Exception("no keyring")
    mock_keyring.get_password.side_effect = Exception("no keyring")

    with patch.dict("sys.modules", {"keyring": mock_keyring}):
        store_token(token)
        retrieved = get_token()

    assert retrieved == token


def test_file_fallback_delete(tmp_config_dir):
    token = "tsk_" + "c" * 48
    mock_keyring = MagicMock()
    mock_keyring.set_password.side_effect = Exception("no keyring")
    mock_keyring.get_password.side_effect = Exception("no keyring")
    mock_keyring.delete_password.side_effect = Exception("no keyring")

    with patch.dict("sys.modules", {"keyring": mock_keyring}):
        store_token(token)
        delete_token()
        assert get_token() is None


def test_get_token_when_none_stored(tmp_config_dir):
    mock_keyring = MagicMock()
    mock_keyring.get_password.return_value = None

    with patch.dict("sys.modules", {"keyring": mock_keyring}):
        assert get_token() is None
