"""Tests for patent CLI commands."""
import httpx
import respx

from tisit_cli.main import app

BASE = "http://localhost:5001/api/v1"


def _patch_auth(cli_runner, tmp_config_dir, mock_token):
    (tmp_config_dir / "token").write_text(mock_token)
    import tomli_w
    with open(tmp_config_dir / "config.toml", "wb") as f:
        tomli_w.dump({"api_url": "http://localhost:5001"}, f)


@respx.mock
def test_patent_list(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/patents").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [{"id": 1, "patent_number": "US12345678", "title": "AI Method",
                      "status": "completed", "fetched_at": "2026-01-01T00:00:00"}],
            "meta": {"page": 1, "per_page": 20, "total": 1, "pages": 1},
        })
    )
    result = cli_runner.invoke(app, ["patent", "list"])
    assert result.exit_code == 0
    assert "US12345678" in result.output


@respx.mock
def test_patent_view(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/patents/1").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {"id": 1, "patent_number": "US12345678", "title": "AI Method",
                     "abstract": "A method for...", "simple_summary": "This patent...",
                     "status": "completed"},
        })
    )
    result = cli_runner.invoke(app, ["patent", "view", "1"])
    assert result.exit_code == 0
    assert "AI Method" in result.output


@respx.mock
def test_patent_add_by_url(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.post(f"{BASE}/patents").mock(
        return_value=httpx.Response(202, json={
            "success": True,
            "data": {"patent_id": 42, "is_duplicate": False,
                     "status": "pending", "message": "Patent queued."},
        })
    )
    result = cli_runner.invoke(app, ["patent", "add", "https://patents.google.com/patent/US12345678"])
    assert result.exit_code == 0
    assert "42" in result.output


@respx.mock
def test_patent_add_by_number(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.post(f"{BASE}/patents").mock(
        return_value=httpx.Response(202, json={
            "success": True,
            "data": {"patent_id": 43, "is_duplicate": False,
                     "status": "pending", "message": "Patent queued."},
        })
    )
    result = cli_runner.invoke(app, ["patent", "add", "US12345678"])
    assert result.exit_code == 0
    assert "43" in result.output


@respx.mock
def test_patent_delete_with_yes(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.delete(f"{BASE}/patents/1").mock(
        return_value=httpx.Response(200, json={
            "success": True, "data": {"message": "Patent deleted"},
        })
    )
    result = cli_runner.invoke(app, ["patent", "delete", "1", "--yes"])
    assert result.exit_code == 0
    assert "deleted" in result.output.lower()


def test_patent_list_not_logged_in(cli_runner, tmp_config_dir):
    result = cli_runner.invoke(app, ["patent", "list"])
    assert result.exit_code == 1
    assert "login" in result.output.lower()
