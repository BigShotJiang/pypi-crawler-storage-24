"""Tests for tweet CLI commands."""
import httpx
import respx

from tisit_cli.main import app

BASE = "http://localhost:5001/api/v1"


def _patch_auth(cli_runner, tmp_config_dir, mock_token):
    (tmp_config_dir / "token").write_text(mock_token)
    import tomli_w
    with open(tmp_config_dir / "config.toml", "wb") as f:
        tomli_w.dump({"api_url": "http://localhost:5001"}, f)


@respx.mock
def test_tweet_list(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/tweets").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [{"id": 1, "author_handle": "@elonmusk",
                      "content": "Hello world", "status": "completed",
                      "created_at": "2026-01-01T00:00:00"}],
            "meta": {"page": 1, "per_page": 20, "total": 1, "pages": 1},
        })
    )
    result = cli_runner.invoke(app, ["tweet", "list"])
    assert result.exit_code == 0
    assert "@elonmusk" in result.output


@respx.mock
def test_tweet_view(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/tweets/1").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {"id": 1, "author_handle": "@testuser",
                     "content": "Test tweet content",
                     "tweet_url": "https://x.com/testuser/status/123",
                     "status": "completed"},
        })
    )
    result = cli_runner.invoke(app, ["tweet", "view", "1"])
    assert result.exit_code == 0
    assert "@testuser" in result.output


@respx.mock
def test_tweet_add(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.post(f"{BASE}/tweets").mock(
        return_value=httpx.Response(202, json={
            "success": True,
            "data": {"tweet_id": 42, "is_duplicate": False,
                     "status": "pending", "message": "Tweet queued."},
        })
    )
    result = cli_runner.invoke(app, ["tweet", "add", "https://x.com/user/status/123"])
    assert result.exit_code == 0
    assert "42" in result.output


@respx.mock
def test_tweet_delete_with_yes(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.delete(f"{BASE}/tweets/1").mock(
        return_value=httpx.Response(200, json={
            "success": True, "data": {"message": "Tweet deleted"},
        })
    )
    result = cli_runner.invoke(app, ["tweet", "delete", "1", "--yes"])
    assert result.exit_code == 0
    assert "deleted" in result.output.lower()


def test_tweet_list_not_logged_in(cli_runner, tmp_config_dir):
    result = cli_runner.invoke(app, ["tweet", "list"])
    assert result.exit_code == 1
    assert "login" in result.output.lower()
