"""Tests for book CLI commands."""
import httpx
import respx

from tisit_cli.main import app

BASE = "http://localhost:5001/api/v1"


def _patch_auth(cli_runner, tmp_config_dir, mock_token):
    (tmp_config_dir / "token").write_text(mock_token)
    import tomli_w
    with open(tmp_config_dir / "config.toml", "wb") as f:
        tomli_w.dump({"api_url": "http://localhost:5001"}, f)


@respx.mock
def test_book_list(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/books").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [{"id": 1, "title": "Deep Learning", "authors": ["Goodfellow"],
                      "status": "completed", "created_at": "2026-01-01T00:00:00"}],
            "meta": {"page": 1, "per_page": 20, "total": 1, "pages": 1},
        })
    )
    result = cli_runner.invoke(app, ["book", "list"])
    assert result.exit_code == 0
    assert "Deep Learning" in result.output


@respx.mock
def test_book_view(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/books/1").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": {"id": 1, "title": "Deep Learning", "authors": ["Goodfellow"],
                     "publisher": "MIT Press", "page_count": 775,
                     "simple_summary": "Comprehensive ML textbook",
                     "status": "completed"},
        })
    )
    result = cli_runner.invoke(app, ["book", "view", "1"])
    assert result.exit_code == 0
    assert "Deep Learning" in result.output


@respx.mock
def test_book_add(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.post(f"{BASE}/books").mock(
        return_value=httpx.Response(202, json={
            "success": True,
            "data": {"book_id": 42, "is_existing": False,
                     "status": "pending", "message": "Book added."},
        })
    )
    result = cli_runner.invoke(app, ["book", "add", "Deep Learning", "--authors", "Goodfellow"])
    assert result.exit_code == 0
    assert "42" in result.output


@respx.mock
def test_book_search(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.get(f"{BASE}/books/search").mock(
        return_value=httpx.Response(200, json={
            "success": True,
            "data": [{"title": "Deep Learning", "authors": ["Goodfellow"],
                      "published_date": "2016", "isbn_13": "9780262035613"}],
            "meta": {"count": 1},
        })
    )
    result = cli_runner.invoke(app, ["book", "search", "Deep Learning"])
    assert result.exit_code == 0
    assert "Deep Learning" in result.output


@respx.mock
def test_book_delete_with_yes(cli_runner, tmp_config_dir, mock_token):
    _patch_auth(cli_runner, tmp_config_dir, mock_token)
    respx.delete(f"{BASE}/books/1").mock(
        return_value=httpx.Response(200, json={
            "success": True, "data": {"message": "Book removed from library"},
        })
    )
    result = cli_runner.invoke(app, ["book", "delete", "1", "--yes"])
    assert result.exit_code == 0
    assert "removed" in result.output.lower()


def test_book_list_not_logged_in(cli_runner, tmp_config_dir):
    result = cli_runner.invoke(app, ["book", "list"])
    assert result.exit_code == 1
    assert "login" in result.output.lower()
