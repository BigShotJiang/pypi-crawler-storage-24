"""
Matrix Information Functions

Mutual information, transfer entropy, and Granger causality matrices
for analyzing information flow and causal relationships between signals.
"""

import numpy as np
from typing import Tuple

import pmtvs_matrix._rust as _rust


def mutual_information_matrix(
    signals: np.ndarray,
    n_bins: int = 10
) -> np.ndarray:
    """
    Compute mutual information between all signal pairs.

    Parameters
    ----------
    signals : np.ndarray
        2D array of shape (n_samples, n_signals).
    n_bins : int
        Number of bins for histogram estimation.

    Returns
    -------
    np.ndarray
        Mutual information matrix of shape (n_signals, n_signals).
        mi[i, j] = mutual information between signal i and j.
        Units: bits (using log2).
    """
    signals = np.ascontiguousarray(np.asarray(signals, dtype=np.float64))

    if signals.size == 0:
        return np.array([]).reshape(0, 0)

    if signals.ndim == 1:
        signals = signals.reshape(-1, 1)

    return np.asarray(_rust.mutual_information_matrix(signals, n_bins))


def transfer_entropy_matrix(
    signals: np.ndarray,
    lag: int = 1,
    n_bins: int = 8
) -> np.ndarray:
    """
    Compute transfer entropy between all signal pairs.

    Parameters
    ----------
    signals : np.ndarray
        2D array of shape (n_samples, n_signals).
    lag : int
        Time lag for source signal.
    n_bins : int
        Number of bins for histogram estimation.

    Returns
    -------
    np.ndarray
        Transfer entropy matrix of shape (n_signals, n_signals).
        te[i, j] = transfer entropy from signal i TO signal j.
        Note: NOT symmetric; te[i, j] != te[j, i] in general.
    """
    signals = np.ascontiguousarray(np.asarray(signals, dtype=np.float64))

    if signals.ndim == 1:
        signals = signals.reshape(-1, 1)

    return np.asarray(_rust.transfer_entropy_matrix(signals, lag, n_bins))


def granger_matrix(
    signals: np.ndarray,
    max_lag: int = 5
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Compute Granger causality between all signal pairs.

    Parameters
    ----------
    signals : np.ndarray
        2D array of shape (n_samples, n_signals).
    max_lag : int
        Maximum lag to test.

    Returns
    -------
    f_matrix : np.ndarray
        F-statistic matrix of shape (n_signals, n_signals).
    p_matrix : np.ndarray
        p-value matrix of shape (n_signals, n_signals).
    """
    signals = np.ascontiguousarray(np.asarray(signals, dtype=np.float64))

    if signals.ndim == 1:
        signals = signals.reshape(-1, 1)

    f_mat, p_mat = _rust.granger_matrix(signals, max_lag)
    return np.asarray(f_mat), np.asarray(p_mat)
