import os
import sys
import time
import subprocess
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

# ---------------------------------------------------------
# 🔥 1. HOT RELOADING LOGIC (फाइल बदलाव पकड़ने वाला सिस्टम)
# ---------------------------------------------------------
class ReloadHandler(FileSystemEventHandler):
    def __init__(self):
        self.process = None
        self.start_process()

    def start_process(self):
        # ऐप को स्टार्ट करने का कमांड
        self.process = subprocess.Popen([sys.executable, "app.py"])

    def on_modified(self, event):
        # अगर .nsx, .html, .css, .js या .py फाइल सेव होती है
        if event.src_path.endswith((".html", ".css", ".js", ".py", ".nsx")):
            print(f"\n🔄 बदलाव मिला: {os.path.basename(event.src_path)}")
            print("🚀 ऐप को रिफ्रेश किया जा रहा है...")
            if self.process:
                self.process.terminate()  # पुरानी विंडो बंद करो
            self.start_process()          # नई विंडो चालू करो

def start_app_with_reload():
    if not os.path.exists("app.py"):
        print("❌ Error: 'app.py' नहीं मिली! क्या तुम सही फोल्डर में हो?")
        return

    print("🔥 Hot Reloading चालू है! अपनी 'src/App.nsx' फाइल में कोड बदलो और Save करो...")
    
    event_handler = ReloadHandler()
    observer = Observer()
    observer.schedule(event_handler, path='.', recursive=True) # पूरे फोल्डर पर नज़र रखेगा
    observer.start()

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        observer.stop()
        if event_handler.process:
            event_handler.process.terminate()
    observer.join()

# ---------------------------------------------------------
# ⚛️ 2. REACT-LIKE TEMPLATES (NSX और Python Code)
# ---------------------------------------------------------

# यह तुम्हारी App.nsx फाइल का कोड है जो यूज़र को दिखेगा
NSX_TEMPLATE = """def render():
    # 🐍 यहाँ तुम अपना Python लॉजिक लिख सकते हो
    app_name = "NSX Framework"
    version = "2.0"
    developer = "Neelesh Singour"

    # 🌐 नीचे HTML और Python Mix हो रहे हैं (JSX Style)
    return f'''<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>{app_name}</title>
    <style>
        body {{ background: #111122; color: #fff; font-family: sans-serif; text-align: center; margin-top: 10%; }}
        .nsx-text {{ color: #61dafb; font-size: 40px; margin-bottom: 5px; }}
        .btn {{ background: #10b981; color: white; border: none; padding: 10px 20px; font-size: 16px; border-radius: 8px; cursor: pointer; }}
        #output {{ margin-top: 20px; color: #6366f1; font-weight: bold; font-size: 18px; }}
    </style>
</head>
<body>
    <h1 class="nsx-text">⚛️ Welcome to {app_name} v{version}</h1>
    <p>Created with ❤️ by {developer}</p>
    <p>Edit <code>src/App.nsx</code> and save to hot-reload.</p>
    
    <button class="btn" onclick="fetchData()">Python से डेटा मंगाओ</button>
    <p id="output"></p>

    <script>
        async function fetchData() {{
            const result = await window.pywebview.api.say_hello();
            document.getElementById('output').innerText = result;
        }}
    </script>
</body>
</html>'''
"""

# यह app.py का कोड है जो .nsx को HTML में बदलेगा
APP_PY_TEMPLATE = """import webview
import os
import sys

def get_resource_path(relative_path):
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.abspath("."), relative_path)

# API क्लास HTML से डायरेक्ट बात करेगी
class BackendAPI:
    def say_hello(self):
        print("🚀 Button clicked from .nsx UI!")
        return "🔥 Success! Data from Python Backend."

def compile_nsx():
    # App.nsx फाइल को ढूँढना और पढ़ना
    nsx_path = get_resource_path('src/App.nsx')
    with open(nsx_path, "r", encoding="utf-8") as f:
        nsx_code = f.read()
    
    # .nsx फाइल के कोड को रन करना
    env = {}
    exec(nsx_code, env)
    
    # 'render' फंक्शन को कॉल करके HTML निकालना
    if "render" in env:
        return env["render"]()
    return "<h1>Error: render() not found in App.nsx</h1>"

if __name__ == '__main__':
    api = BackendAPI()
    html_ui = compile_nsx() # NSX को HTML में बदला
    
    webview.create_window('NSX App', html=html_ui, js_api=api, width=800, height=600, background_color='#111122')
    webview.start()
"""

# ---------------------------------------------------------
# 🛠️ 3. MAIN CLI COMMANDS (create, start, build)
# ---------------------------------------------------------
def main():
    if len(sys.argv) < 2:
        print("❌ Command missing! Use: nsx create <name>, nsx start, or nsx build")
        sys.exit(1)

    cmd = sys.argv[1].lower()

    if cmd == "create":
        if len(sys.argv) < 3:
            print("❌ Project name missing! Example: nsx create my-app")
            sys.exit(1)
        
        project_name = sys.argv[2]
        # ui की जगह src फोल्डर बनाया जा रहा है
        os.makedirs(f"{project_name}/src", exist_ok=True)
        
        # app.py और App.nsx फाइलें जेनरेट करना
        with open(f"{project_name}/app.py", "w", encoding="utf-8") as f:
            f.write(APP_PY_TEMPLATE)
        with open(f"{project_name}/src/App.nsx", "w", encoding="utf-8") as f:
            f.write(NSX_TEMPLATE)
            
        print(f"✅ Project '{project_name}' created successfully!")
        print(f"👉 Now run:\n   cd {project_name}\n   nsx start")

    elif cmd == "start":
        # अब 'start' करने पर हमारा Hot Reloading वाला फंक्शन चलेगा
        start_app_with_reload()

    elif cmd == "build":
        if not os.path.exists("app.py"):
            print("❌ File 'app.py' not found.")
            sys.exit(1)
        print("📦 Building EXE... Please wait.")
        sep = ';' if os.name == 'nt' else ':'
        
        # Build करते समय src/App.nsx को EXE में जोड़ना
        subprocess.run([
            "pyinstaller", "--noconfirm", "--onefile", "--windowed",
            f"--add-data=src/App.nsx{sep}src",
            "--name=My_NSX_App",
            "--clean", "app.py"
        ])
        print("🎉 Build Complete! Check the 'dist' folder.")
        
    else:
        print(f"❌ Unknown command: {cmd}")

if __name__ == "__main__":
    main()