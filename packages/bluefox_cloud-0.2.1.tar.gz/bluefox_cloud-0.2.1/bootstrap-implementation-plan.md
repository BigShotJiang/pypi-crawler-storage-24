# Bootstrap Implementation Plan

> Fill the gap between bluefox-cloud's primitives (ssh, swarm, traefik, cloudflare) and the orchestration layer that wires them into a working server. Extracted from the POC's `bootstrap.sh` + `bootstrap-server.sh`.

**Existing primitives (v0.1.0):**

- `bluefox_cloud.ssh` — `ssh_run()`, `ssh_upload_and_run()`, `get_bundled_script()`
- `bluefox_cloud.swarm` — `SwarmClient` (create/update/remove services, networks, oneshot containers)
- `bluefox_cloud.traefik` — `TraefikConfig` (write/remove per-app YAML)
- `bluefox_cloud.cloudflare` — `CloudflareClient` (zone lookup, DNS CRUD, upsert)
- `bluefox_cloud.config` — `CloudConfig`, `load_config()`, `save_config()`

**Key design decision:** Remote bootstrap runs everything over SSH. The SwarmClient uses the local Docker daemon, so it's only used by code running _on_ the server (the platform itself, or local dev). Remote provisioning shells out via `ssh_run()` for Docker commands.

Every step is a single, verifiable task. Don't move to the next step until the current one works.

---

## Step 1: `harden.sh` — Server hardening script

Extract Phase 1 from the POC's `bootstrap-server.sh` into a real bundled script.

The script expects env vars: `SSH_PORT` (default 22).

What it does:
1. Create `deploy` user with passwordless sudo
2. Copy root's SSH keys to deploy
3. Harden sshd: `PermitRootLogin no`, `PasswordAuthentication no`, restart ssh
4. Install and configure UFW: deny incoming, allow `SSH_PORT`, 80, 443
5. Set timezone to UTC
6. Install unattended-upgrades
7. Install and configure fail2ban for sshd on `SSH_PORT`

All operations are idempotent (skip if already done).

**Done when:** `ssh_upload_and_run(host, "root", 22, get_bundled_script("harden.sh"))` hardens a fresh Ubuntu 24.04 server. Re-running skips everything.

---

## Step 2: `install_docker.sh` — Docker Engine installation script

Extract Phase 2 from the POC's `bootstrap-server.sh`.

What it does:
1. Install Docker Engine from Docker's official apt repo (skip if already installed)
2. Add `deploy` user to the `docker` group (skip if already in group)

**Done when:** After running, `docker --version` works and `deploy` can use Docker without sudo.

---

## Step 3: `bluefox_cloud.bootstrap.infra` — Infrastructure service definitions

Pure data module. Defines how to create each infrastructure service as a dict/model that `SwarmClient.create_service()` or `ssh_run()` can consume. No orchestration logic — just the service specs.

```
bluefox_cloud/bootstrap/
    __init__.py
    infra.py
```

Functions that return service creation kwargs:

- `traefik_service_spec(domain, cf_token?)` — Traefik v3.4 with file provider, entrypoints 80+443, optional Let's Encrypt DNS-01 via Cloudflare. Mounts: `/etc/traefik/dynamic` (ro), `/etc/traefik/acme.json` (if TLS). Constraint: manager node.
- `registry_service_spec()` — registry:2 on port 5000, volume `registry-data`. Constraint: manager.
- `postgres_service_spec(db_user, db_password, db_name)` — postgres:18-alpine with volume. Constraint: manager.
- `redis_service_spec(name, volume_name)` — redis:7-alpine with appendonly, volume. Constraint: manager. Used for both cache and queue.

Each returns a dict matching `SwarmClient.create_service()` kwargs, plus a `docker_cli_args()` variant that returns a `docker service create` command string (for remote SSH execution).

**Done when:** Unit tests verify the specs produce correct dicts. The Traefik spec has two variants (with/without Let's Encrypt). Registry spec includes insecure-registry daemon.json setup.

---

## Step 4: `bluefox_cloud.bootstrap.remote` — Remote server provisioning

Orchestrates a full remote server setup over SSH.

```
bluefox_cloud/bootstrap/
    remote.py
```

`provision(config: CloudConfig, *, db_password: str, secret_key: str) -> ProvisionResult`

Phases (mirrors the POC):

1. **Connect** — verify SSH connectivity (`ssh_run` echo test), detect user (root or deploy)
2. **Cloudflare DNS** — if cloudflare config present, `upsert_record()` for wildcard `*.domain`
3. **Harden** — `ssh_upload_and_run_bundled("harden.sh")` with `SSH_PORT` env
4. **Install Docker** — `ssh_upload_and_run_bundled("install_docker.sh")`
5. **Swarm init** — `ssh_run("docker swarm init --advertise-addr {ip}")`, skip if already active
6. **Overlay network** — `ssh_run("docker network create --driver overlay --attachable bluefox-net")`, skip if exists
7. **Traefik** — use `infra.traefik_service_spec()` → `ssh_run(docker_cli_args)`, wait for 1/1 replicas
8. **Registry** — use `infra.registry_service_spec()` → `ssh_run(docker_cli_args)`, configure insecure registry in daemon.json, wait for 1/1
9. **Postgres** — use `infra.postgres_service_spec()` → `ssh_run(docker_cli_args)`, wait for `pg_isready`
10. **Redis** — two calls to `infra.redis_service_spec()` (cache + queue) → `ssh_run(docker_cli_args)`, wait for PONG

Each phase checks if the resource already exists and skips if so (idempotent).

`ProvisionResult` is a Pydantic model with: `database_url`, `cache_url`, `queue_url`, `phases_run: list[str]`, `phases_skipped: list[str]`.

**Done when:** Tests verify the orchestration calls the right primitives in order. Integration test against a real server is out of scope (manual verification).

---

## Step 5: `bluefox_cloud.bootstrap.local` — Local dev provisioning

Orchestrates local development setup. Uses `SwarmClient` directly (local Docker daemon).

```
bluefox_cloud/bootstrap/
    local.py
```

`provision(*, domain: str = "localhost", db_password: str, secret_key: str) -> ProvisionResult`

Phases (subset of remote — no hardening, no SSH, no Cloudflare):

1. **Swarm init** — `docker swarm init` via SwarmClient or subprocess, skip if active
2. **Overlay network** — `SwarmClient.create_network("bluefox-net")`, skip if exists
3. **Traefik** — `SwarmClient.create_service()` with `infra.traefik_service_spec()` (no TLS)
4. **Registry** — `SwarmClient.create_service()` with `infra.registry_service_spec()`
5. **Postgres** — `SwarmClient.create_service()` with `infra.postgres_service_spec()`
6. **Redis** — cache + queue via `SwarmClient.create_service()` with `infra.redis_service_spec()`

Returns same `ProvisionResult` as remote.

**Done when:** Tests verify orchestration calls. Can provision a local Docker Swarm (manual test).

---

## Step 6: `bluefox_cloud.bootstrap.platform` — Platform deploy & update

Handles building, pushing, and deploying the platform service (and worker).

```
bluefox_cloud/bootstrap/
    platform.py
```

### For remote (over SSH):

`deploy_remote(config: CloudConfig, *, image_tag: str, env: dict[str, str]) -> None`

1. Write Traefik config for `platform.{domain}` via `ssh_run()` (write YAML to `/etc/traefik/dynamic/platform.yml`)
2. Create or update `bluefox-cloud-web` service with env vars, mounts (docker.sock, traefik dynamic dir, /proc)
3. Create or update `bluefox-cloud-worker` service with same env, command `uv run saq ...`

`run_migrations_remote(config: CloudConfig, *, image_tag: str, database_url: str) -> SSHResult`

1. `ssh_run("docker run --rm --network bluefox-net -e DATABASE_URL=... {image} uv run alembic upgrade head")`

`build_and_push_remote(config: CloudConfig, *, repo_path: str) -> str`

1. Rsync repo to server `/opt/bluefox-cloud`
2. `ssh_run("docker build -t bluefox-cloud-web:latest /opt/bluefox-cloud")`
3. `ssh_run("docker tag ... localhost:5000/bluefox-cloud-web:latest")`
4. `ssh_run("docker push localhost:5000/bluefox-cloud-web:latest")`
5. Returns the image tag

### For local:

`deploy_local(*, domain: str, image_tag: str, env: dict[str, str]) -> None`

1. Write Traefik config for `platform.{domain}` via `TraefikConfig.write_app_config()`
2. Create or update web + worker services via `SwarmClient`

`run_migrations_local(*, image_tag: str, database_url: str) -> str`

1. `SwarmClient.run_oneshot()` with migration command

**Done when:** Tests verify the correct SSH/SwarmClient calls are made. Full integration is manual.

---

## Step 7: Wire `__init__.py` exports and update docs

```python
# bluefox_cloud/bootstrap/__init__.py
from bluefox_cloud.bootstrap.local import provision as local_provision
from bluefox_cloud.bootstrap.remote import provision as remote_provision
from bluefox_cloud.bootstrap.platform import (
    deploy_remote,
    deploy_local,
    run_migrations_remote,
    run_migrations_local,
    build_and_push_remote,
)
```

Update `docs/index.md` modules table with bootstrap. Tag `v0.2.0`.

**Done when:** `from bluefox_cloud.bootstrap.local import provision` works. `from bluefox_cloud.bootstrap.remote import provision` works. Docs updated. All CI passes.
