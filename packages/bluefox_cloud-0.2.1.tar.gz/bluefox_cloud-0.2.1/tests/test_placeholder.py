def test_import():
    import bluefox_cloud  # noqa: F401
