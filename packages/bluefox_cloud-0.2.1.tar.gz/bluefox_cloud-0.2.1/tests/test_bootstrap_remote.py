from unittest.mock import patch

import pytest

from bluefox_cloud.bootstrap.remote import (
    ProvisionError,
    ProvisionResult,
    provision,
)
from bluefox_cloud.config import CloudConfig, CloudflareConfig, ServerConfig
from bluefox_cloud.ssh.client import SSHResult


def _ok(stdout: str = "") -> SSHResult:
    return SSHResult(stdout=stdout, stderr="", returncode=0)


def _fail(stderr: str = "error") -> SSHResult:
    return SSHResult(stdout="", stderr=stderr, returncode=1)


@pytest.fixture
def config():
    return CloudConfig(
        server=ServerConfig(
            ip="10.0.0.1",
            ssh_port=6161,
            domain="example.com",
            user="deploy",
        ),
        cloudflare=CloudflareConfig(
            api_token="cf-token",
            zone_id="zone-123",
        ),
    )


@pytest.fixture
def config_no_cf():
    return CloudConfig(
        server=ServerConfig(
            ip="10.0.0.1",
            ssh_port=22,
            domain="example.com",
            user="deploy",
        ),
    )


def _make_fresh_server_ssh_side_effect():
    """Create an SSH side effect for a fresh server where nothing exists."""
    state = {"swarm_inited": False}

    def side_effect(host, user, port, command, **kwargs):
        if user == "root" and command == "echo ok":
            return _ok("ok")
        # docker access check after install_docker
        if "docker info" in command and ".ID" in command:
            return _ok("abc123")
        if "Swarm.LocalNodeState" in command:
            # Before swarm init: not active. After: active (verification).
            if not state["swarm_inited"]:
                return _fail()
            return _ok("active")
        if "swarm init" in command:
            state["swarm_inited"] = True
            return _ok()
        if "network inspect" in command:
            return _fail()
        if "network create" in command:
            return _ok()
        if "service inspect" in command:
            return _fail()
        if any(x in command for x in ["mkdir", "touch", "chmod"]):
            return _ok()
        if "docker service create" in command:
            return _ok()
        if "service ls" in command:
            return _ok("1/1")
        if "docker ps" in command:
            return _ok("abc123")
        if "pg_isready" in command:
            return _ok()
        if "redis-cli ping" in command:
            return _ok("PONG")
        if "python3" in command or "systemctl restart docker" in command:
            return _ok()
        return _ok()

    return side_effect


def _existing_server_ssh_side_effect(host, user, port, command, **kwargs):
    """SSH side effect for a server where everything already exists."""
    if command == "echo ok" and user == "root":
        return _fail()
    if command == "echo ok":
        return _ok()
    # docker access check
    if "docker info" in command and ".ID" in command:
        return _ok("abc123")
    if "Swarm.LocalNodeState" in command:
        return _ok("active")
    if "network inspect" in command:
        return _ok()
    if "service inspect" in command:
        return _ok()
    if "docker ps" in command:
        return _ok("abc123")
    if "redis-cli ping" in command:
        return _ok("PONG")
    if "pg_isready" in command:
        return _ok()
    return _ok()


@patch("bluefox_cloud.bootstrap.remote.time")
@patch("bluefox_cloud.bootstrap.remote.ssh_upload_and_run_bundled")
@patch("bluefox_cloud.bootstrap.remote.ssh_run")
def test_full_provision_fresh(mock_ssh_run, mock_upload_run, mock_time, config):
    mock_ssh_run.side_effect = _make_fresh_server_ssh_side_effect()
    mock_upload_run.return_value = _ok()

    result = provision(config, db_password="testpass")

    assert isinstance(result, ProvisionResult)
    assert "bluefox_cloud_database:testpass" in result.database_url
    assert result.cache_url == "redis://bluefox-cloud-cache:6379"
    assert result.queue_url == "redis://bluefox-cloud-queue:6379"
    assert "connect" in result.phases_run
    assert "harden" in result.phases_run
    assert "install_docker" in result.phases_run
    assert "swarm_init" in result.phases_run
    assert "network" in result.phases_run
    assert "traefik" in result.phases_run
    assert "registry" in result.phases_run
    assert "postgres" in result.phases_run
    assert "redis_cache" in result.phases_run
    assert "redis_queue" in result.phases_run


@patch("bluefox_cloud.bootstrap.remote.time")
@patch("bluefox_cloud.bootstrap.remote.ssh_upload_and_run_bundled")
@patch("bluefox_cloud.bootstrap.remote.ssh_run")
def test_harden_passes_ssh_port(mock_ssh_run, mock_upload_run, mock_time, config):
    mock_ssh_run.side_effect = _existing_server_ssh_side_effect
    mock_upload_run.return_value = _ok()

    provision(config, db_password="p")

    harden_call = mock_upload_run.call_args_list[0]
    assert harden_call[0][3] == "harden.sh"
    assert harden_call[1]["env"] == {"SSH_PORT": "6161"}


@patch("bluefox_cloud.bootstrap.remote.time")
@patch("bluefox_cloud.bootstrap.remote.ssh_upload_and_run_bundled")
@patch("bluefox_cloud.bootstrap.remote.ssh_run")
def test_skips_existing(mock_ssh_run, mock_upload_run, mock_time, config):
    mock_ssh_run.side_effect = _existing_server_ssh_side_effect
    mock_upload_run.return_value = _ok()

    result = provision(config, db_password="p")

    assert "swarm_init" in result.phases_skipped
    assert "network" in result.phases_skipped
    assert "traefik" in result.phases_skipped
    assert "registry" in result.phases_skipped
    assert "postgres" in result.phases_skipped
    assert "redis_cache" in result.phases_skipped
    assert "redis_queue" in result.phases_skipped
    # Harden and install_docker always run (idempotent scripts)
    assert "harden" in result.phases_run
    assert "install_docker" in result.phases_run


@patch("bluefox_cloud.bootstrap.remote.ssh_upload_and_run_bundled")
@patch("bluefox_cloud.bootstrap.remote.ssh_run")
def test_connect_failure(mock_ssh_run, mock_upload_run, config):
    mock_ssh_run.return_value = _fail("connection refused")

    with pytest.raises(ProvisionError, match="connect"):
        provision(config, db_password="p")


@patch("bluefox_cloud.bootstrap.remote.time")
@patch("bluefox_cloud.bootstrap.remote.ssh_upload_and_run_bundled")
@patch("bluefox_cloud.bootstrap.remote.ssh_run")
def test_swarm_init_not_active_raises(mock_ssh_run, mock_upload_run, mock_time, config):
    """Swarm init returns 0 but node never reaches active state."""

    def ssh_side_effect(host, user, port, command, **kwargs):
        if user == "root" and command == "echo ok":
            return _ok("ok")
        if "docker info" in command and ".ID" in command:
            return _ok("abc123")
        if "Swarm.LocalNodeState" in command:
            return _fail("inactive")
        if "swarm init" in command:
            return _ok()  # init "succeeds" but node stays inactive
        return _ok()

    mock_ssh_run.side_effect = ssh_side_effect
    mock_upload_run.return_value = _ok()

    with pytest.raises(ProvisionError, match="swarm_init"):
        provision(config, db_password="p")


@patch("bluefox_cloud.bootstrap.remote.time")
@patch("bluefox_cloud.bootstrap.remote.ssh_upload_and_run_bundled")
@patch("bluefox_cloud.bootstrap.remote.ssh_run")
def test_docker_access_falls_back_to_sg(mock_ssh_run, mock_upload_run, mock_time, config):
    """Docker access check falls back to 'sg docker' when direct access fails."""
    call_count = {"docker_info_id": 0}

    def ssh_side_effect(host, user, port, command, **kwargs):
        if user == "root" and command == "echo ok":
            return _ok("ok")
        if "docker info" in command and ".ID" in command:
            call_count["docker_info_id"] += 1
            if "sg docker" in command:
                return _ok("abc123")
            return _fail("permission denied")
        return _existing_server_ssh_side_effect(host, user, port, command, **kwargs)

    mock_ssh_run.side_effect = ssh_side_effect
    mock_upload_run.return_value = _ok()

    result = provision(config, db_password="p")

    assert isinstance(result, ProvisionResult)
    # First call failed, second with sg docker succeeded
    assert call_count["docker_info_id"] == 2


@patch("bluefox_cloud.bootstrap.remote.ssh_upload_and_run_bundled")
@patch("bluefox_cloud.bootstrap.remote.ssh_run")
def test_harden_failure(mock_ssh_run, mock_upload_run, config):
    mock_ssh_run.return_value = _ok("ok")
    mock_upload_run.return_value = _fail("harden failed")

    with pytest.raises(ProvisionError, match="harden"):
        provision(config, db_password="p")


@patch("bluefox_cloud.bootstrap.remote.time")
@patch("bluefox_cloud.bootstrap.remote.ssh_upload_and_run_bundled")
@patch("bluefox_cloud.bootstrap.remote.ssh_run")
def test_no_cloudflare(mock_ssh_run, mock_upload_run, mock_time, config_no_cf):
    def ssh_side_effect(host, user, port, command, **kwargs):
        if command == "echo ok":
            return _ok()
        if "docker info" in command and ".ID" in command:
            return _ok("abc123")
        if "Swarm.LocalNodeState" in command:
            return _ok("active")
        if "network inspect" in command:
            return _ok()
        if "service inspect" in command:
            return _ok()
        if "docker ps" in command:
            return _ok("abc123")
        if "redis-cli ping" in command:
            return _ok("PONG")
        return _ok()

    mock_ssh_run.side_effect = ssh_side_effect
    mock_upload_run.return_value = _ok()

    result = provision(config_no_cf, db_password="p")
    assert "cloudflare_dns" in result.phases_skipped
