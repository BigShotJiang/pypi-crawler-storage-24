from pathlib import Path

import yaml

from bluefox_cloud.config import (
    CloudConfig,
    CloudflareConfig,
    ServerConfig,
    load_config,
    save_config,
)


def test_save_and_load_roundtrip(tmp_path: Path):
    config_path = tmp_path / "cloud.yml"
    config = CloudConfig(
        platform_url="https://platform.bluefox.software",
        api_key="bfx_test123",
        local=False,
        server=ServerConfig(
            ip="37.27.83.150", ssh_port=6161, domain="bluefox.software", user="deploy"
        ),
        cloudflare=CloudflareConfig(api_token="cf_token", zone_id="cf_zone"),
    )

    save_config(config, config_path)
    loaded = load_config(config_path)

    assert loaded.platform_url == "https://platform.bluefox.software"
    assert loaded.api_key == "bfx_test123"
    assert loaded.local is False
    assert loaded.server.ip == "37.27.83.150"
    assert loaded.server.ssh_port == 6161
    assert loaded.server.domain == "bluefox.software"
    assert loaded.server.user == "deploy"
    assert loaded.cloudflare.api_token == "cf_token"
    assert loaded.cloudflare.zone_id == "cf_zone"


def test_save_creates_parent_directories(tmp_path: Path):
    config_path = tmp_path / "nested" / "dir" / "cloud.yml"
    save_config(CloudConfig(), config_path)
    assert config_path.exists()


def test_load_missing_file_raises(tmp_path: Path):
    config_path = tmp_path / "nonexistent.yml"
    try:
        load_config(config_path)
        raise AssertionError("Should have raised FileNotFoundError")
    except FileNotFoundError:
        pass


def test_load_empty_file(tmp_path: Path):
    config_path = tmp_path / "cloud.yml"
    config_path.write_text("")
    loaded = load_config(config_path)
    assert loaded == CloudConfig()


def test_load_partial_config(tmp_path: Path):
    config_path = tmp_path / "cloud.yml"
    config_path.write_text(yaml.dump({"platform_url": "http://localhost", "local": True}))
    loaded = load_config(config_path)

    assert loaded.platform_url == "http://localhost"
    assert loaded.local is True
    assert loaded.api_key == ""
    assert loaded.server == ServerConfig()
    assert loaded.cloudflare == CloudflareConfig()


def test_save_produces_valid_yaml(tmp_path: Path):
    config_path = tmp_path / "cloud.yml"
    config = CloudConfig(
        platform_url="http://platform.localhost",
        api_key="bfx_local",
        local=True,
    )
    save_config(config, config_path)

    raw = yaml.safe_load(config_path.read_text())
    assert raw["platform_url"] == "http://platform.localhost"
    assert raw["local"] is True
    assert raw["server"]["user"] == "deploy"


def test_defaults():
    config = CloudConfig()
    assert config.platform_url == ""
    assert config.api_key == ""
    assert config.local is False
    assert config.server.ip == ""
    assert config.server.ssh_port == 22
    assert config.server.user == "deploy"
    assert config.cloudflare.api_token == ""
    assert config.cloudflare.zone_id == ""
