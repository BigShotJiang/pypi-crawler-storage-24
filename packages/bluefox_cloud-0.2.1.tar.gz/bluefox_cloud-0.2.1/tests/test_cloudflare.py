import httpx
import pytest

from bluefox_cloud.cloudflare.client import CloudflareClient, CloudflareError
from bluefox_cloud.cloudflare.dns import DNSRecordType
from bluefox_cloud.cloudflare.domains import setup_subdomain, setup_wildcard, verify_custom_domain


def _cf_response(result: dict | list, *, success: bool = True) -> httpx.Response:
    """Build a fake Cloudflare JSON response."""
    return httpx.Response(
        200 if success else 400,
        json={
            "success": success,
            "errors": [] if success else [{"message": "test error"}],
            "result": result,
        },
    )


def _record_dict(
    *,
    id: str = "rec-1",
    name: str = "test.example.com",
    type: str = "A",
    content: str = "1.2.3.4",
    proxied: bool = False,
    ttl: int = 1,
) -> dict:
    return {
        "id": id,
        "name": name,
        "type": type,
        "content": content,
        "proxied": proxied,
        "ttl": ttl,
    }


def _make_client(transport: httpx.MockTransport) -> CloudflareClient:
    """Create a CloudflareClient with a mock transport."""
    return CloudflareClient(
        "fake-token",
        client=httpx.AsyncClient(transport=transport, base_url="https://test"),
    )


# -- CloudflareClient --


async def test_get_zone():
    transport = httpx.MockTransport(
        lambda req: _cf_response({"id": "z1", "name": "example.com", "status": "active"})
    )
    async with _make_client(transport) as cf:
        zone = await cf.get_zone("z1")
        assert zone.id == "z1"
        assert zone.name == "example.com"
        assert zone.status == "active"


async def test_list_zones():
    transport = httpx.MockTransport(
        lambda req: _cf_response(
            [
                {"id": "z1", "name": "example.com", "status": "active"},
                {"id": "z2", "name": "other.com", "status": "active"},
            ]
        )
    )
    async with _make_client(transport) as cf:
        zones = await cf.list_zones()
        assert len(zones) == 2


async def test_list_records():
    transport = httpx.MockTransport(
        lambda req: _cf_response(
            [
                _record_dict(id="r1", name="a.example.com", content="1.1.1.1"),
                _record_dict(id="r2", name="b.example.com", content="2.2.2.2"),
            ]
        )
    )
    async with _make_client(transport) as cf:
        records = await cf.list_records("z1")
        assert len(records) == 2
        assert records[0].name == "a.example.com"


async def test_create_record():
    transport = httpx.MockTransport(
        lambda req: _cf_response(
            _record_dict(id="new-1", name="app.example.com", content="5.6.7.8")
        )
    )
    async with _make_client(transport) as cf:
        record = await cf.create_record(
            "z1",
            name="app.example.com",
            record_type=DNSRecordType.A,
            content="5.6.7.8",
        )
        assert record.id == "new-1"
        assert record.content == "5.6.7.8"


async def test_update_record():
    transport = httpx.MockTransport(
        lambda req: _cf_response(_record_dict(id="r1", name="app.example.com", content="9.9.9.9"))
    )
    async with _make_client(transport) as cf:
        record = await cf.update_record(
            "z1",
            "r1",
            name="app.example.com",
            record_type=DNSRecordType.A,
            content="9.9.9.9",
        )
        assert record.content == "9.9.9.9"


async def test_delete_record():
    transport = httpx.MockTransport(lambda req: _cf_response({"id": "r1"}))
    async with _make_client(transport) as cf:
        await cf.delete_record("z1", "r1")  # should not raise


async def test_error_response_raises():
    transport = httpx.MockTransport(lambda req: _cf_response({}, success=False))
    async with _make_client(transport) as cf:
        with pytest.raises(CloudflareError, match="test error"):
            await cf.get_zone("z1")


async def test_upsert_creates_when_no_existing():
    call_count = 0

    def handler(req: httpx.Request) -> httpx.Response:
        nonlocal call_count
        call_count += 1
        if req.method == "GET":
            return _cf_response([])
        return _cf_response(_record_dict(id="new-1", name="app.example.com", content="1.2.3.4"))

    transport = httpx.MockTransport(handler)
    async with _make_client(transport) as cf:
        record = await cf.upsert_record(
            "z1",
            name="app.example.com",
            record_type=DNSRecordType.A,
            content="1.2.3.4",
        )
        assert record.id == "new-1"
        assert call_count == 2  # list + create


async def test_upsert_updates_when_existing():
    call_count = 0

    def handler(req: httpx.Request) -> httpx.Response:
        nonlocal call_count
        call_count += 1
        if req.method == "GET":
            return _cf_response(
                [_record_dict(id="existing-1", name="app.example.com", content="old-ip")]
            )
        return _cf_response(
            _record_dict(id="existing-1", name="app.example.com", content="new-ip")
        )

    transport = httpx.MockTransport(handler)
    async with _make_client(transport) as cf:
        record = await cf.upsert_record(
            "z1",
            name="app.example.com",
            record_type=DNSRecordType.A,
            content="new-ip",
        )
        assert record.content == "new-ip"
        assert call_count == 2  # list + update


# -- Domain helpers --


async def test_setup_subdomain():
    def handler(req: httpx.Request) -> httpx.Response:
        if req.method == "GET":
            return _cf_response([])
        return _cf_response(_record_dict(name="app.example.com", content="10.0.0.1"))

    transport = httpx.MockTransport(handler)
    async with _make_client(transport) as cf:
        await setup_subdomain(cf, "z1", subdomain="app", server_ip="10.0.0.1")


async def test_setup_wildcard():
    def handler(req: httpx.Request) -> httpx.Response:
        if req.method == "GET":
            return _cf_response([])
        return _cf_response(_record_dict(name="*.example.com", content="10.0.0.1"))

    transport = httpx.MockTransport(handler)
    async with _make_client(transport) as cf:
        await setup_wildcard(cf, "z1", server_ip="10.0.0.1")


async def test_verify_custom_domain_found():
    transport = httpx.MockTransport(
        lambda req: _cf_response(
            [
                _record_dict(
                    name="custom.app.com",
                    type="CNAME",
                    content="app.bluefox.software",
                )
            ]
        )
    )
    async with _make_client(transport) as cf:
        result = await verify_custom_domain(
            cf, "z1", domain="custom.app.com", expected_cname="app.bluefox.software"
        )
        assert result is True


async def test_verify_custom_domain_not_found():
    transport = httpx.MockTransport(lambda req: _cf_response([]))
    async with _make_client(transport) as cf:
        result = await verify_custom_domain(
            cf, "z1", domain="custom.app.com", expected_cname="app.bluefox.software"
        )
        assert result is False
