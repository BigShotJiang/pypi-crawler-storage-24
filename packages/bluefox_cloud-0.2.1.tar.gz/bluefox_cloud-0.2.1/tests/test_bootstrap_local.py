from unittest.mock import AsyncMock, MagicMock, patch

import docker.errors
import pytest

from bluefox_cloud.bootstrap.local import provision
from bluefox_cloud.bootstrap.remote import ProvisionResult


@pytest.fixture
def mock_swarm():
    swarm = AsyncMock()
    swarm.get_service = AsyncMock()
    swarm.create_service = AsyncMock()
    swarm.get_network = AsyncMock()
    swarm.create_network = AsyncMock()
    return swarm


def _fresh_swarm(mock_swarm):
    """Configure mock_swarm so nothing exists."""
    mock_swarm.get_service.side_effect = docker.errors.NotFound("not found")
    mock_swarm.get_network.side_effect = docker.errors.NotFound("not found")


def _existing_swarm(mock_swarm):
    """Configure mock_swarm so everything exists."""
    mock_swarm.get_service.return_value = MagicMock()
    mock_swarm.get_network.return_value = MagicMock()


@patch("bluefox_cloud.bootstrap.local.subprocess")
@patch("bluefox_cloud.bootstrap.local.SwarmClient")
async def test_full_provision_fresh(mock_swarm_cls, mock_subprocess, mock_swarm):
    mock_swarm_cls.return_value = mock_swarm
    mock_subprocess.run.return_value = MagicMock(returncode=1, stdout="inactive")
    _fresh_swarm(mock_swarm)

    result = await provision(db_password="testpass")

    assert isinstance(result, ProvisionResult)
    assert "bluefox_cloud_database:testpass" in result.database_url
    assert result.cache_url == "redis://bluefox-cloud-cache:6379"
    assert result.queue_url == "redis://bluefox-cloud-queue:6379"

    assert "swarm_init" in result.phases_run
    assert "network" in result.phases_run
    assert "traefik" in result.phases_run
    assert "registry" in result.phases_run
    assert "postgres" in result.phases_run
    assert "redis_cache" in result.phases_run
    assert "redis_queue" in result.phases_run

    # Verify swarm init was called
    assert mock_subprocess.run.call_count == 2  # info check + swarm init

    # Verify services were created (traefik, registry, postgres, cache, queue)
    assert mock_swarm.create_service.call_count == 5
    assert mock_swarm.create_network.call_count == 1


@patch("bluefox_cloud.bootstrap.local.subprocess")
@patch("bluefox_cloud.bootstrap.local.SwarmClient")
async def test_custom_domain(mock_swarm_cls, mock_subprocess, mock_swarm):
    mock_swarm_cls.return_value = mock_swarm
    mock_subprocess.run.return_value = MagicMock(returncode=1, stdout="inactive")
    _fresh_swarm(mock_swarm)

    result = await provision(domain="dev.local", db_password="p")

    traefik_call = mock_swarm.create_service.call_args_list[0]
    assert traefik_call[1]["name"] == "infra_traefik"
    assert isinstance(result, ProvisionResult)


@patch("bluefox_cloud.bootstrap.local.subprocess")
@patch("bluefox_cloud.bootstrap.local.SwarmClient")
async def test_skips_existing(mock_swarm_cls, mock_subprocess, mock_swarm):
    mock_swarm_cls.return_value = mock_swarm
    mock_subprocess.run.return_value = MagicMock(returncode=0, stdout="active")
    _existing_swarm(mock_swarm)

    result = await provision(db_password="p")

    assert "swarm_init" in result.phases_skipped
    assert "network" in result.phases_skipped
    assert "traefik" in result.phases_skipped
    assert "registry" in result.phases_skipped
    assert "postgres" in result.phases_skipped
    assert "redis_cache" in result.phases_skipped
    assert "redis_queue" in result.phases_skipped

    assert mock_swarm.create_service.call_count == 0
    assert mock_swarm.create_network.call_count == 0
    assert mock_subprocess.run.call_count == 1


@patch("bluefox_cloud.bootstrap.local.subprocess")
@patch("bluefox_cloud.bootstrap.local.SwarmClient")
async def test_partial_existing(mock_swarm_cls, mock_subprocess, mock_swarm):
    mock_swarm_cls.return_value = mock_swarm
    mock_subprocess.run.return_value = MagicMock(returncode=0, stdout="active")
    mock_swarm.get_network.return_value = MagicMock()

    def get_service_side_effect(name):
        if name in ("infra_traefik", "registry"):
            return MagicMock()
        raise docker.errors.NotFound("not found")

    mock_swarm.get_service.side_effect = get_service_side_effect

    result = await provision(db_password="p")

    assert "traefik" in result.phases_skipped
    assert "registry" in result.phases_skipped
    assert "postgres" in result.phases_run
    assert "redis_cache" in result.phases_run
    assert "redis_queue" in result.phases_run

    assert mock_swarm.create_service.call_count == 3
