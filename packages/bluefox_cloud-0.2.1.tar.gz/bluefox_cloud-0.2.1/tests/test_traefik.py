from pathlib import Path

import yaml

from bluefox_cloud.traefik.config import TraefikConfig
from bluefox_cloud.traefik.tls import default_tls, letsencrypt_tls


def test_write_single_domain(tmp_path: Path):
    tc = TraefikConfig(tmp_path)
    path = tc.write_app_config(
        app_name="myapp",
        service_url="http://myapp_app:8080",
        hostnames=["myapp.example.com"],
    )

    assert path.exists()
    config = yaml.safe_load(path.read_text())

    routers = config["http"]["routers"]
    assert routers["myapp"]["rule"] == "Host(`myapp.example.com`)"
    assert routers["myapp"]["entryPoints"] == ["web"]
    assert routers["myapp"]["service"] == "myapp"

    assert routers["myapp-secure"]["rule"] == "Host(`myapp.example.com`)"
    assert routers["myapp-secure"]["entryPoints"] == ["websecure"]
    assert routers["myapp-secure"]["tls"] == {}

    services = config["http"]["services"]
    assert services["myapp"]["loadBalancer"]["servers"] == [{"url": "http://myapp_app:8080"}]


def test_write_multi_domain(tmp_path: Path):
    tc = TraefikConfig(tmp_path)
    tc.write_app_config(
        app_name="myapp",
        service_url="http://myapp_app:8080",
        hostnames=["myapp.example.com", "coolapp.com", "www.coolapp.com"],
    )

    config = yaml.safe_load((tmp_path / "myapp.yml").read_text())
    expected_rule = "Host(`myapp.example.com`) || Host(`coolapp.com`) || Host(`www.coolapp.com`)"
    assert config["http"]["routers"]["myapp"]["rule"] == expected_rule
    assert config["http"]["routers"]["myapp-secure"]["rule"] == expected_rule


def test_write_with_letsencrypt_tls(tmp_path: Path):
    tc = TraefikConfig(tmp_path)
    tls = letsencrypt_tls("example.com", sans=["*.example.com"])
    tc.write_app_config(
        app_name="myapp",
        service_url="http://myapp_app:8080",
        hostnames=["myapp.example.com"],
        tls=tls,
    )

    config = yaml.safe_load((tmp_path / "myapp.yml").read_text())
    tls_config = config["http"]["routers"]["myapp-secure"]["tls"]
    assert tls_config["certResolver"] == "letsencrypt"
    assert tls_config["domains"] == [{"main": "example.com", "sans": ["*.example.com"]}]


def test_remove_app_config(tmp_path: Path):
    tc = TraefikConfig(tmp_path)
    tc.write_app_config(
        app_name="myapp",
        service_url="http://myapp_app:8080",
        hostnames=["myapp.example.com"],
    )
    assert (tmp_path / "myapp.yml").exists()

    assert tc.remove_app_config("myapp") is True
    assert not (tmp_path / "myapp.yml").exists()


def test_remove_nonexistent(tmp_path: Path):
    tc = TraefikConfig(tmp_path)
    assert tc.remove_app_config("nope") is False


def test_read_app_config(tmp_path: Path):
    tc = TraefikConfig(tmp_path)
    tc.write_app_config(
        app_name="myapp",
        service_url="http://myapp_app:8080",
        hostnames=["myapp.example.com"],
    )

    config = tc.read_app_config("myapp")
    assert config is not None
    assert "http" in config
    assert "myapp" in config["http"]["routers"]


def test_read_nonexistent(tmp_path: Path):
    tc = TraefikConfig(tmp_path)
    assert tc.read_app_config("nope") is None


def test_write_creates_config_dir(tmp_path: Path):
    nested = tmp_path / "deep" / "nested" / "dir"
    tc = TraefikConfig(nested)
    tc.write_app_config(
        app_name="myapp",
        service_url="http://myapp_app:8080",
        hostnames=["myapp.example.com"],
    )
    assert (nested / "myapp.yml").exists()


def test_default_tls():
    assert default_tls() == {}


def test_letsencrypt_tls_without_sans():
    tls = letsencrypt_tls("example.com")
    assert tls == {
        "certResolver": "letsencrypt",
        "domains": [{"main": "example.com"}],
    }


def test_letsencrypt_tls_with_sans():
    tls = letsencrypt_tls("example.com", sans=["*.example.com", "other.com"])
    assert tls == {
        "certResolver": "letsencrypt",
        "domains": [{"main": "example.com", "sans": ["*.example.com", "other.com"]}],
    }
