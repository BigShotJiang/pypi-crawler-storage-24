import docker
import docker.errors
import pytest

from bluefox_cloud.swarm.client import SwarmClient


def _docker_available() -> bool:
    try:
        client = docker.from_env()
        client.ping()
        return True
    except Exception:
        return False


def _swarm_active() -> bool:
    try:
        client = docker.from_env()
        info = client.info()
        return info.get("Swarm", {}).get("LocalNodeState") == "active"
    except Exception:
        return False


requires_docker = pytest.mark.skipif(not _docker_available(), reason="Docker not available")
requires_swarm = pytest.mark.skipif(not _swarm_active(), reason="Docker Swarm not active")

SERVICE_NAME = "bfc-test-svc"
NETWORK_NAME = "bfc-test-net"


@pytest.fixture
def swarm_client():
    return SwarmClient()


@pytest.fixture(autouse=True)
def _cleanup(swarm_client: SwarmClient):
    """Clean up test services and networks after each test."""
    yield
    if not _swarm_active():
        return
    client = docker.from_env()
    for svc in client.services.list():
        if svc.name and svc.name.startswith("bfc-test-"):
            svc.remove()
    for net in client.networks.list(names=[NETWORK_NAME]):
        net.remove()


@requires_swarm
async def test_create_and_get_service(swarm_client: SwarmClient):
    service = await swarm_client.create_service(
        image="alpine:latest",
        name=SERVICE_NAME,
        command="sleep 3600",
    )
    assert service.name == SERVICE_NAME

    fetched = await swarm_client.get_service(SERVICE_NAME)
    assert fetched.id == service.id


@requires_swarm
async def test_list_services(swarm_client: SwarmClient):
    await swarm_client.create_service(
        image="alpine:latest",
        name=SERVICE_NAME,
        command="sleep 3600",
    )
    services = await swarm_client.list_services()
    names = [s.name for s in services]
    assert SERVICE_NAME in names


@requires_swarm
async def test_update_service(swarm_client: SwarmClient):
    await swarm_client.create_service(
        image="alpine:latest",
        name=SERVICE_NAME,
        command="sleep 3600",
    )
    await swarm_client.update_service(SERVICE_NAME, replicas=0)

    service = await swarm_client.get_service(SERVICE_NAME)
    attrs: dict = service.attrs  # type: ignore[assignment]
    spec = attrs["Spec"]["Mode"]["Replicated"]
    assert spec["Replicas"] == 0


@requires_swarm
async def test_remove_service(swarm_client: SwarmClient):
    await swarm_client.create_service(
        image="alpine:latest",
        name=SERVICE_NAME,
        command="sleep 3600",
    )
    await swarm_client.remove_service(SERVICE_NAME)

    with pytest.raises(docker.errors.NotFound):
        await swarm_client.get_service(SERVICE_NAME)


@requires_swarm
async def test_create_network(swarm_client: SwarmClient):
    network = await swarm_client.create_network(NETWORK_NAME)
    assert network.name == NETWORK_NAME

    fetched = await swarm_client.get_network(NETWORK_NAME)
    assert fetched.id == network.id


@requires_docker
async def test_run_oneshot(swarm_client: SwarmClient):
    output = await swarm_client.run_oneshot(
        image="alpine:latest",
        command=["echo", "hello from oneshot"],
    )
    assert "hello from oneshot" in output


@requires_swarm
async def test_create_service_with_env_and_network(swarm_client: SwarmClient):
    await swarm_client.create_network(NETWORK_NAME)
    service = await swarm_client.create_service(
        image="alpine:latest",
        name=SERVICE_NAME,
        command="sleep 3600",
        env={"FOO": "bar", "BAZ": "qux"},
        networks=[NETWORK_NAME],
    )
    assert service.name == SERVICE_NAME
