from unittest.mock import MagicMock, patch

from bluefox_cloud.ssh.client import (
    SSHResult,
    _scp_args,
    _ssh_base_args,
    get_bundled_script,
    ssh_run,
    ssh_upload_and_run,
)


def test_ssh_result_ok():
    assert SSHResult(stdout="ok", stderr="", returncode=0).ok is True
    assert SSHResult(stdout="", stderr="err", returncode=1).ok is False


def test_ssh_base_args():
    args = _ssh_base_args("1.2.3.4", "deploy", 6161)
    assert args[0] == "ssh"
    assert "-p" in args
    assert "6161" in args
    assert "deploy@1.2.3.4" in args


def test_scp_args():
    args = _scp_args("1.2.3.4", "deploy", 6161, "/tmp/script.sh", "/tmp/remote.sh")
    assert args[0] == "scp"
    assert "-P" in args
    assert "6161" in args
    assert "/tmp/script.sh" in args
    assert "deploy@1.2.3.4:/tmp/remote.sh" in args


def test_get_bundled_script():
    path = get_bundled_script("harden.sh")
    assert path.exists()
    assert path.name == "harden.sh"


def test_get_bundled_script_missing():
    try:
        get_bundled_script("nonexistent.sh")
        raise AssertionError("Should have raised FileNotFoundError")
    except FileNotFoundError:
        pass


@patch("bluefox_cloud.ssh.client.subprocess.run")
def test_ssh_run(mock_run: MagicMock):
    mock_run.return_value = MagicMock(stdout="hello\n", stderr="", returncode=0)
    result = ssh_run("1.2.3.4", "deploy", 22, "echo hello")

    assert result.ok
    assert result.stdout == "hello\n"
    mock_run.assert_called_once()
    args = mock_run.call_args[0][0]
    assert args[0] == "ssh"
    assert "echo hello" in args


@patch("bluefox_cloud.ssh.client.subprocess.run")
def test_ssh_upload_and_run_scp_failure(mock_run: MagicMock):
    mock_run.return_value = MagicMock(stdout="", stderr="connection refused", returncode=1)
    result = ssh_upload_and_run("1.2.3.4", "deploy", 22, "/tmp/test.sh")

    assert not result.ok
    assert "SCP upload failed" in result.stderr


@patch("bluefox_cloud.ssh.client.subprocess.run")
def test_ssh_upload_and_run_success(mock_run: MagicMock):
    # First call: scp (success), second call: ssh (success)
    mock_run.side_effect = [
        MagicMock(stdout="", stderr="", returncode=0),
        MagicMock(stdout="done\n", stderr="", returncode=0),
    ]
    result = ssh_upload_and_run("1.2.3.4", "deploy", 22, "/tmp/test.sh")

    assert result.ok
    assert result.stdout == "done\n"
    assert mock_run.call_count == 2
