from unittest.mock import AsyncMock, MagicMock, patch

import docker.errors
import pytest

from bluefox_cloud.bootstrap.platform import (
    REGISTRY_TAG,
    WEB_SERVICE,
    WORKER_SERVICE,
    build_and_push_remote,
    deploy_local,
    deploy_remote,
    run_migrations_local,
    run_migrations_remote,
)
from bluefox_cloud.config import CloudConfig, CloudflareConfig, ServerConfig
from bluefox_cloud.ssh.client import SSHResult


def _ok(stdout: str = "") -> SSHResult:
    return SSHResult(stdout=stdout, stderr="", returncode=0)


def _fail(stderr: str = "error") -> SSHResult:
    return SSHResult(stdout="", stderr=stderr, returncode=1)


@pytest.fixture
def config():
    return CloudConfig(
        server=ServerConfig(
            ip="10.0.0.1",
            ssh_port=6161,
            domain="example.com",
            user="deploy",
        ),
        cloudflare=CloudflareConfig(
            api_token="cf-token",
            zone_id="zone-123",
        ),
    )


# -- build_and_push_remote --


@patch("bluefox_cloud.bootstrap.platform.subprocess")
@patch("bluefox_cloud.bootstrap.platform.ssh_run")
def test_build_and_push_remote_success(mock_ssh_run, mock_subprocess, config):
    mock_ssh_run.return_value = _ok()
    mock_subprocess.run.return_value = MagicMock(returncode=0, stdout="", stderr="")

    result = build_and_push_remote(config, repo_path="/tmp/myrepo")

    assert result == REGISTRY_TAG

    # Verify rsync was called
    rsync_call = mock_subprocess.run.call_args
    assert "rsync" in rsync_call[0][0][0]

    # Verify docker build, tag, push were called
    ssh_commands = [call[1]["command"] for call in mock_ssh_run.call_args_list]
    assert any("docker build" in cmd for cmd in ssh_commands)
    assert any("docker tag" in cmd for cmd in ssh_commands)
    assert any("docker push" in cmd for cmd in ssh_commands)


@patch("bluefox_cloud.bootstrap.platform.subprocess")
@patch("bluefox_cloud.bootstrap.platform.ssh_run")
def test_build_and_push_remote_rsync_failure(mock_ssh_run, mock_subprocess, config):
    mock_ssh_run.return_value = _ok()
    mock_subprocess.run.return_value = MagicMock(returncode=1, stdout="", stderr="rsync error")

    result = build_and_push_remote(config, repo_path="/tmp/myrepo")

    assert result is None


# -- deploy_remote --


@patch("bluefox_cloud.bootstrap.platform.ssh_run")
def test_deploy_remote_creates_new_services(mock_ssh_run, config):
    def ssh_side_effect(*, host, user, port, command, timeout=300):
        # service inspect returns not found
        if "service inspect" in command:
            return _fail()
        return _ok()

    mock_ssh_run.side_effect = ssh_side_effect

    deploy_remote(config, image_tag="myimage:latest", env={"KEY": "val"})

    commands = [call[1]["command"] for call in mock_ssh_run.call_args_list]
    # Traefik config written
    assert any("platform.yml" in cmd for cmd in commands)
    # Both services created
    create_cmds = [cmd for cmd in commands if "docker service create" in cmd]
    assert len(create_cmds) == 2


@patch("bluefox_cloud.bootstrap.platform.ssh_run")
def test_deploy_remote_updates_existing_services(mock_ssh_run, config):
    def ssh_side_effect(*, host, user, port, command, timeout=300):
        # service inspect returns found
        if "service inspect" in command:
            return _ok()
        return _ok()

    mock_ssh_run.side_effect = ssh_side_effect

    deploy_remote(config, image_tag="myimage:v2", env={"KEY": "val"})

    commands = [call[1]["command"] for call in mock_ssh_run.call_args_list]
    update_cmds = [cmd for cmd in commands if "service update" in cmd]
    assert len(update_cmds) == 2
    # Verify image is in update commands
    assert all("myimage:v2" in cmd for cmd in update_cmds)


# -- run_migrations_remote --


@patch("bluefox_cloud.bootstrap.platform.ssh_run")
def test_run_migrations_remote_success(mock_ssh_run, config):
    mock_ssh_run.return_value = _ok("migration output")

    result = run_migrations_remote(
        config,
        image_tag="myimage:latest",
        database_url="postgresql+asyncpg://u:p@db:5432/d",
    )

    assert result.ok
    cmd = mock_ssh_run.call_args[1]["command"]
    assert "docker run --rm" in cmd
    assert "alembic upgrade head" in cmd
    assert "DATABASE_URL" in cmd


@patch("bluefox_cloud.bootstrap.platform.ssh_run")
def test_run_migrations_remote_failure(mock_ssh_run, config):
    mock_ssh_run.return_value = _fail("migration error")

    result = run_migrations_remote(
        config,
        image_tag="myimage:latest",
        database_url="postgresql+asyncpg://u:p@db:5432/d",
    )

    assert not result.ok


# -- deploy_local --


@patch("bluefox_cloud.bootstrap.platform.TraefikConfig")
@patch("bluefox_cloud.bootstrap.platform.SwarmClient")
async def test_deploy_local_creates_new(mock_swarm_cls, mock_traefik_cls, tmp_path):
    swarm = AsyncMock()
    mock_swarm_cls.return_value = swarm
    swarm.get_service.side_effect = docker.errors.NotFound("not found")

    traefik = MagicMock()
    mock_traefik_cls.return_value = traefik

    await deploy_local(
        domain="localhost",
        image_tag="myimage:latest",
        env={"KEY": "val"},
        traefik_config_dir=tmp_path,
    )

    # Traefik config written
    traefik.write_app_config.assert_called_once()
    call_args = traefik.write_app_config.call_args
    assert call_args[0][0] == "platform"
    assert "platform.localhost" in call_args[0][2]

    # Both services created
    assert swarm.create_service.call_count == 2
    web_call = swarm.create_service.call_args_list[0]
    assert web_call[1]["name"] == WEB_SERVICE
    worker_call = swarm.create_service.call_args_list[1]
    assert worker_call[1]["name"] == WORKER_SERVICE


@patch("bluefox_cloud.bootstrap.platform.TraefikConfig")
@patch("bluefox_cloud.bootstrap.platform.SwarmClient")
async def test_deploy_local_updates_existing(mock_swarm_cls, mock_traefik_cls, tmp_path):
    swarm = AsyncMock()
    mock_swarm_cls.return_value = swarm
    swarm.get_service.return_value = MagicMock()

    traefik = MagicMock()
    mock_traefik_cls.return_value = traefik

    await deploy_local(
        domain="localhost",
        image_tag="myimage:v2",
        env={"KEY": "val"},
        traefik_config_dir=tmp_path,
    )

    # Both services updated (not created)
    assert swarm.create_service.call_count == 0
    assert swarm.update_service.call_count == 2
    for call in swarm.update_service.call_args_list:
        assert call[1]["image"] == "myimage:v2"
        assert call[1]["force_update"] is True


# -- run_migrations_local --


@patch("bluefox_cloud.bootstrap.platform.SwarmClient")
async def test_run_migrations_local(mock_swarm_cls):
    swarm = AsyncMock()
    mock_swarm_cls.return_value = swarm
    swarm.run_oneshot.return_value = "migration output"

    output = await run_migrations_local(
        image_tag="myimage:latest",
        database_url="postgresql+asyncpg://u:p@db:5432/d",
    )

    assert output == "migration output"
    call = swarm.run_oneshot.call_args
    assert call[1]["image"] == "myimage:latest"
    assert "DATABASE_URL" in call[1]["env"]
    assert call[1]["command"] == ["uv", "run", "alembic", "upgrade", "head"]
