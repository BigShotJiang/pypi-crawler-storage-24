from bluefox_cloud.bootstrap.infra import (
    NETWORK_NAME,
    POSTGRES_IMAGE,
    REDIS_IMAGE,
    REGISTRY_IMAGE,
    TRAEFIK_IMAGE,
    insecure_registry_setup_commands,
    postgres_docker_cli,
    postgres_service_spec,
    redis_docker_cli,
    redis_service_spec,
    registry_docker_cli,
    registry_service_spec,
    traefik_docker_cli,
    traefik_service_spec,
)

# -- Traefik --


def test_traefik_basic_spec():
    spec = traefik_service_spec("example.com")
    assert spec["image"] == TRAEFIK_IMAGE
    assert spec["name"] == "infra_traefik"
    assert NETWORK_NAME in spec["networks"]
    assert spec["ports"] == {80: 80, 443: 443}
    assert "node.role == manager" in spec["constraints"]
    assert spec["env"] is None
    assert "--certificatesresolvers" not in " ".join(spec["command"])


def test_traefik_spec_with_letsencrypt():
    spec = traefik_service_spec("example.com", cf_token="my-token")
    assert spec["env"]["CF_DNS_API_TOKEN"] == "my-token"
    cmd = " ".join(spec["command"])
    assert "certificatesresolvers.letsencrypt" in cmd
    assert "ssl@example.com" in cmd
    assert "/etc/traefik/acme.json" in " ".join(spec["mounts"])


def test_traefik_docker_cli_basic():
    cli = traefik_docker_cli("example.com")
    assert "docker service create" in cli
    assert TRAEFIK_IMAGE in cli
    assert "--network bluefox-net" in cli


def test_traefik_docker_cli_with_letsencrypt():
    cli = traefik_docker_cli("example.com", cf_token="tok")
    assert "CF_DNS_API_TOKEN" in cli
    assert "acme.json" in cli


# -- Registry --


def test_registry_spec():
    spec = registry_service_spec()
    assert spec["image"] == REGISTRY_IMAGE
    assert spec["name"] == "registry"
    assert spec["ports"] == {5000: 5000}
    assert "registry-data:/var/lib/registry" in spec["mounts"]


def test_registry_docker_cli():
    cli = registry_docker_cli()
    assert "docker service create" in cli
    assert REGISTRY_IMAGE in cli


def test_insecure_registry_commands():
    cmds = insecure_registry_setup_commands()
    assert len(cmds) == 2
    assert "localhost:5000" in cmds[0]
    assert "systemctl restart docker" in cmds[1]


# -- PostgreSQL --


def test_postgres_spec():
    spec = postgres_service_spec("myuser", "mypass", "mydb")
    assert spec["image"] == POSTGRES_IMAGE
    assert spec["name"] == "bluefox-cloud-database"
    assert spec["env"]["POSTGRES_USER"] == "myuser"
    assert spec["env"]["POSTGRES_PASSWORD"] == "mypass"
    assert spec["env"]["POSTGRES_DB"] == "mydb"
    assert "bluefox-cloud-database-data:/var/lib/postgresql/data" in spec["mounts"]


def test_postgres_custom_names():
    spec = postgres_service_spec("u", "p", "d", service_name="custom-db", volume_name="custom-vol")
    assert spec["name"] == "custom-db"
    assert "custom-vol:/var/lib/postgresql/data" in spec["mounts"]


def test_postgres_docker_cli():
    cli = postgres_docker_cli("u", "p", "d")
    assert "docker service create" in cli
    assert POSTGRES_IMAGE in cli
    assert "POSTGRES_USER" in cli


# -- Redis --


def test_redis_spec():
    spec = redis_service_spec("bluefox-cloud-cache", "cache-data")
    assert spec["image"] == REDIS_IMAGE
    assert spec["name"] == "bluefox-cloud-cache"
    assert spec["command"] == ["redis-server", "--appendonly", "yes"]
    assert "cache-data:/data" in spec["mounts"]


def test_redis_docker_cli():
    cli = redis_docker_cli("bluefox-cloud-queue", "queue-data")
    assert "docker service create" in cli
    assert REDIS_IMAGE in cli
    assert "bluefox-cloud-queue" in cli
