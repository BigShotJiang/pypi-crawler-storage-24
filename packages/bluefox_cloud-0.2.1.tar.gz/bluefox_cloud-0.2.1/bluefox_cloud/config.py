from __future__ import annotations

from pathlib import Path

import yaml
from pydantic import BaseModel

DEFAULT_CONFIG_DIR = Path.home() / ".bluefox"
DEFAULT_CONFIG_PATH = DEFAULT_CONFIG_DIR / "cloud.yml"


class ServerConfig(BaseModel):
    ip: str = ""
    ssh_port: int = 22
    domain: str = ""
    user: str = "deploy"


class CloudflareConfig(BaseModel):
    api_token: str = ""
    zone_id: str = ""


class CloudConfig(BaseModel):
    platform_url: str = ""
    api_key: str = ""
    local: bool = False
    server: ServerConfig = ServerConfig()
    cloudflare: CloudflareConfig = CloudflareConfig()


def load_config(path: Path = DEFAULT_CONFIG_PATH) -> CloudConfig:
    """Load cloud config from YAML file. Raises FileNotFoundError if missing."""
    raw = yaml.safe_load(path.read_text())
    if raw is None:
        return CloudConfig()
    return CloudConfig.model_validate(raw)


def save_config(config: CloudConfig, path: Path = DEFAULT_CONFIG_PATH) -> None:
    """Save cloud config to YAML file. Creates parent directories if needed."""
    path.parent.mkdir(parents=True, exist_ok=True)
    data = config.model_dump()
    path.write_text(yaml.dump(data, default_flow_style=False, sort_keys=False))
