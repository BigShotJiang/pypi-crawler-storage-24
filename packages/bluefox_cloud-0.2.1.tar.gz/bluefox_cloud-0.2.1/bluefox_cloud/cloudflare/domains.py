from __future__ import annotations

from bluefox_cloud.cloudflare.client import CloudflareClient
from bluefox_cloud.cloudflare.dns import DNSRecordType


async def setup_subdomain(
    client: CloudflareClient,
    zone_id: str,
    *,
    subdomain: str,
    server_ip: str,
) -> None:
    """Point a subdomain A record at the server IP."""
    await client.upsert_record(
        zone_id,
        name=subdomain,
        record_type=DNSRecordType.A,
        content=server_ip,
        proxied=False,
    )


async def setup_wildcard(
    client: CloudflareClient,
    zone_id: str,
    *,
    server_ip: str,
) -> None:
    """Create a wildcard A record for *.domain."""
    await client.upsert_record(
        zone_id,
        name="*",
        record_type=DNSRecordType.A,
        content=server_ip,
        proxied=False,
    )


async def verify_custom_domain(
    client: CloudflareClient,
    zone_id: str,
    *,
    domain: str,
    expected_cname: str,
) -> bool:
    """Check if a custom domain has a CNAME pointing to the expected target."""
    records = await client.list_records(zone_id, name=domain, record_type=DNSRecordType.CNAME)
    return any(r.content == expected_cname for r in records)
