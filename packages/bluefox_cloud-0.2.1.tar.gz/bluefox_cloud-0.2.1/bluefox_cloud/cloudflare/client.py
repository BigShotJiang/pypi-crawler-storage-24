from __future__ import annotations

import httpx

from bluefox_cloud.cloudflare.dns import DNSRecord, DNSRecordType, Zone

BASE_URL = "https://api.cloudflare.com/client/v4"


class CloudflareError(Exception):
    """Raised when the Cloudflare API returns an error."""

    def __init__(self, status_code: int, errors: list[dict]) -> None:
        self.status_code = status_code
        self.errors = errors
        messages = "; ".join(e.get("message", str(e)) for e in errors)
        super().__init__(f"Cloudflare API error ({status_code}): {messages}")


class CloudflareClient:
    """Async Cloudflare API client using httpx."""

    def __init__(
        self,
        api_token: str,
        *,
        client: httpx.AsyncClient | None = None,
    ) -> None:
        self._client = client or httpx.AsyncClient(
            base_url=BASE_URL,
            headers={
                "Authorization": f"Bearer {api_token}",
                "Content-Type": "application/json",
            },
            timeout=30.0,
        )
        self._owns_client = client is None

    async def close(self) -> None:
        if self._owns_client:
            await self._client.aclose()

    async def __aenter__(self) -> CloudflareClient:
        return self

    async def __aexit__(self, *args: object) -> None:
        await self.close()

    def _check_response(self, response: httpx.Response) -> dict:
        data = response.json()
        if not data.get("success", False):
            raise CloudflareError(
                status_code=response.status_code,
                errors=data.get("errors", [{"message": "Unknown error"}]),
            )
        return data

    # --- Zones ---

    async def get_zone(self, zone_id: str) -> Zone:
        """Get a zone by ID."""
        resp = await self._client.get(f"/zones/{zone_id}")
        data = self._check_response(resp)
        result = data["result"]
        return Zone(id=result["id"], name=result["name"], status=result["status"])

    async def list_zones(self, *, name: str | None = None) -> list[Zone]:
        """List zones, optionally filtered by name."""
        params: dict[str, str] = {}
        if name:
            params["name"] = name
        resp = await self._client.get("/zones", params=params)
        data = self._check_response(resp)
        return [Zone(id=z["id"], name=z["name"], status=z["status"]) for z in data["result"]]

    # --- DNS Records ---

    async def list_records(
        self,
        zone_id: str,
        *,
        name: str | None = None,
        record_type: DNSRecordType | None = None,
    ) -> list[DNSRecord]:
        """List DNS records in a zone."""
        params: dict[str, str] = {}
        if name:
            params["name"] = name
        if record_type:
            params["type"] = record_type.value
        resp = await self._client.get(f"/zones/{zone_id}/dns_records", params=params)
        data = self._check_response(resp)
        return [
            DNSRecord(
                id=r["id"],
                zone_id=zone_id,
                name=r["name"],
                type=DNSRecordType(r["type"]),
                content=r["content"],
                proxied=r.get("proxied", False),
                ttl=r.get("ttl", 1),
            )
            for r in data["result"]
        ]

    async def create_record(
        self,
        zone_id: str,
        *,
        name: str,
        record_type: DNSRecordType,
        content: str,
        proxied: bool = False,
        ttl: int = 1,
    ) -> DNSRecord:
        """Create a DNS record."""
        payload = {
            "type": record_type.value,
            "name": name,
            "content": content,
            "proxied": proxied,
            "ttl": ttl,
        }
        resp = await self._client.post(f"/zones/{zone_id}/dns_records", json=payload)
        data = self._check_response(resp)
        r = data["result"]
        return DNSRecord(
            id=r["id"],
            zone_id=zone_id,
            name=r["name"],
            type=DNSRecordType(r["type"]),
            content=r["content"],
            proxied=r.get("proxied", False),
            ttl=r.get("ttl", 1),
        )

    async def update_record(
        self,
        zone_id: str,
        record_id: str,
        *,
        name: str,
        record_type: DNSRecordType,
        content: str,
        proxied: bool = False,
        ttl: int = 1,
    ) -> DNSRecord:
        """Update a DNS record (full replace)."""
        payload = {
            "type": record_type.value,
            "name": name,
            "content": content,
            "proxied": proxied,
            "ttl": ttl,
        }
        resp = await self._client.put(f"/zones/{zone_id}/dns_records/{record_id}", json=payload)
        data = self._check_response(resp)
        r = data["result"]
        return DNSRecord(
            id=r["id"],
            zone_id=zone_id,
            name=r["name"],
            type=DNSRecordType(r["type"]),
            content=r["content"],
            proxied=r.get("proxied", False),
            ttl=r.get("ttl", 1),
        )

    async def delete_record(self, zone_id: str, record_id: str) -> None:
        """Delete a DNS record."""
        resp = await self._client.delete(f"/zones/{zone_id}/dns_records/{record_id}")
        self._check_response(resp)

    async def upsert_record(
        self,
        zone_id: str,
        *,
        name: str,
        record_type: DNSRecordType,
        content: str,
        proxied: bool = False,
        ttl: int = 1,
    ) -> DNSRecord:
        """Create or update a DNS record. Matches on name + type."""
        existing = await self.list_records(zone_id, name=name, record_type=record_type)
        if existing:
            return await self.update_record(
                zone_id,
                existing[0].id,
                name=name,
                record_type=record_type,
                content=content,
                proxied=proxied,
                ttl=ttl,
            )
        return await self.create_record(
            zone_id,
            name=name,
            record_type=record_type,
            content=content,
            proxied=proxied,
            ttl=ttl,
        )
