from __future__ import annotations

from enum import StrEnum

from pydantic import BaseModel


class DNSRecordType(StrEnum):
    A = "A"
    AAAA = "AAAA"
    CNAME = "CNAME"
    TXT = "TXT"
    MX = "MX"


class Zone(BaseModel):
    id: str
    name: str
    status: str


class DNSRecord(BaseModel):
    id: str
    zone_id: str
    name: str
    type: DNSRecordType
    content: str
    proxied: bool = False
    ttl: int = 1  # 1 = automatic
