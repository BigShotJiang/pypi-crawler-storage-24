"""Bootstrap — server provisioning and platform deployment.

Provides both remote (SSH-based) and local (SwarmClient-based) workflows
for provisioning infrastructure and deploying the platform services.
"""

from bluefox_cloud.bootstrap.local import provision as local_provision
from bluefox_cloud.bootstrap.platform import (
    build_and_push_remote,
    deploy_local,
    deploy_remote,
    run_migrations_local,
    run_migrations_remote,
)
from bluefox_cloud.bootstrap.remote import provision as remote_provision

__all__ = [
    "build_and_push_remote",
    "deploy_local",
    "deploy_remote",
    "local_provision",
    "remote_provision",
    "run_migrations_local",
    "run_migrations_remote",
]
