"""Remote server provisioning over SSH.

Orchestrates a full remote server setup: hardening, Docker, Swarm,
overlay network, Traefik, registry, Postgres, and Redis.
"""

from __future__ import annotations

import logging
import time

from pydantic import BaseModel

from bluefox_cloud.bootstrap.infra import (
    CACHE_SERVICE,
    DB_NAME,
    DB_SERVICE,
    DB_USER,
    NETWORK_NAME,
    QUEUE_SERVICE,
    insecure_registry_setup_commands,
    postgres_docker_cli,
    redis_docker_cli,
    registry_docker_cli,
    traefik_docker_cli,
)
from bluefox_cloud.config import CloudConfig
from bluefox_cloud.ssh.client import SSHResult, ssh_run, ssh_upload_and_run_bundled

logger = logging.getLogger(__name__)


class ProvisionResult(BaseModel):
    """Result of a remote provisioning run."""

    database_url: str
    cache_url: str
    queue_url: str
    phases_run: list[str] = []
    phases_skipped: list[str] = []


class ProvisionError(Exception):
    """Raised when a provisioning phase fails."""

    def __init__(self, phase: str, result: SSHResult) -> None:
        self.phase = phase
        self.result = result
        super().__init__(
            f"Provisioning failed at phase '{phase}': "
            f"exit={result.returncode}, stderr={result.stderr[:500]}"
        )


def _check(phase: str, result: SSHResult) -> SSHResult:
    """Raise ProvisionError if the SSH command failed."""
    if not result.ok:
        raise ProvisionError(phase, result)
    return result


def _ssh(
    config: CloudConfig,
    command: str,
    *,
    user: str | None = None,
    timeout: int = 300,
    docker_via_sg: bool = False,
) -> SSHResult:
    """Shorthand for ssh_run with config values.

    Args:
        docker_via_sg: If True, wrap docker commands with ``sg docker -c "..."``
            to activate group membership without requiring a new login session.
    """
    if docker_via_sg and command.lstrip().startswith("docker"):
        command = f'sg docker -c "{command}"'
    return ssh_run(
        host=config.server.ip,
        user=user or config.server.user,
        port=config.server.ssh_port,
        command=command,
        timeout=timeout,
    )


def _wait_for_service(
    config: CloudConfig,
    service_name: str,
    *,
    user: str | None = None,
    docker_via_sg: bool = False,
    max_wait: int = 60,
    interval: int = 2,
) -> bool:
    """Wait for a Docker service to reach 1/1 replicas."""
    for _ in range(max_wait // interval):
        result = _ssh(
            config,
            f"docker service ls --filter name={service_name} --format '{{{{.Replicas}}}}'",
            user=user,
            docker_via_sg=docker_via_sg,
        )
        if result.ok and "1/1" in result.stdout:
            return True
        time.sleep(interval)
    return False


def provision(
    config: CloudConfig,
    *,
    db_password: str,
) -> ProvisionResult:
    """Provision a remote server with the full Bluefox Cloud infrastructure.

    Args:
        config: Cloud configuration with server and cloudflare details.
        db_password: Password for the platform database.

    Returns:
        ProvisionResult with connection URLs and phase status.

    Raises:
        ProvisionError: If any phase fails.
    """
    phases_run: list[str] = []
    phases_skipped: list[str] = []
    host = config.server.ip
    port = config.server.ssh_port

    # ---- Phase 0: Detect SSH user ----
    # Try root first, fall back to deploy
    root_test = ssh_run(host, "root", port, "echo ok")
    if root_test.ok:
        ssh_user = "root"
        logger.info("Connected as root (fresh server)")
    else:
        deploy_test = ssh_run(host, config.server.user, port, "echo ok")
        _check("connect", deploy_test)
        ssh_user = config.server.user
        logger.info("Connected as '%s' (re-run detected)", ssh_user)
    phases_run.append("connect")

    # For commands that need root on a non-root connection
    sudo_prefix = "" if ssh_user == "root" else "sudo "

    # ---- Phase 1: Cloudflare DNS ----
    if config.cloudflare.api_token and config.cloudflare.zone_id:
        # DNS is handled by the caller (CLI) using CloudflareClient directly,
        # or can be done here via ssh_run + curl. For now, we skip this and
        # let the caller handle it since we have a proper async client.
        phases_skipped.append("cloudflare_dns")
        logger.info("Cloudflare DNS: skipped (handled by caller)")
    else:
        phases_skipped.append("cloudflare_dns")
        logger.info("Cloudflare DNS: no credentials configured")

    # ---- Phase 2: Server hardening ----
    result = ssh_upload_and_run_bundled(
        host,
        ssh_user,
        port,
        "harden.sh",
        env={"SSH_PORT": str(config.server.ssh_port)},
        timeout=300,
    )
    _check("harden", result)
    phases_run.append("harden")
    logger.info("Server hardened")

    # After hardening, root login is disabled. Switch to deploy user.
    ssh_user = config.server.user
    sudo_prefix = "sudo "

    # ---- Phase 3: Install Docker ----
    result = ssh_upload_and_run_bundled(
        host,
        ssh_user,
        port,
        "install_docker.sh",
        timeout=300,
    )
    # install_docker.sh needs root — if the bundled upload succeeded but
    # execution failed (no root), the script is already at /tmp/install_docker.sh
    # from the SCP step, so we can retry with sudo.
    if not result.ok:
        result = _ssh(
            config,
            f"{sudo_prefix}bash /tmp/install_docker.sh",
            user=ssh_user,
            timeout=300,
        )
    _check("install_docker", result)
    phases_run.append("install_docker")
    logger.info("Docker installed")

    # ---- Phase 3b: Verify Docker access ----
    # Group membership from install_docker.sh may not be effective in cached
    # sessions.  Use `sg docker` as a fallback to activate the group.
    docker_via_sg = False
    docker_ok = _ssh(config, "docker info --format '{{.ID}}'", user=ssh_user)
    if not docker_ok.ok:
        docker_ok = _ssh(
            config, "docker info --format '{{.ID}}'", user=ssh_user, docker_via_sg=True
        )
        if docker_ok.ok:
            docker_via_sg = True
            logger.info("Docker access requires 'sg docker' — will wrap subsequent commands")
        else:
            _check("docker_access", docker_ok)

    # ---- Phase 4: Swarm init ----
    swarm_check = _ssh(
        config,
        "docker info --format '{{.Swarm.LocalNodeState}}'",
        user=ssh_user,
        docker_via_sg=docker_via_sg,
    )
    if swarm_check.ok and "active" in swarm_check.stdout:
        phases_skipped.append("swarm_init")
        logger.info("Swarm already active")
    else:
        result = _ssh(
            config,
            f"docker swarm init --advertise-addr {config.server.ip}",
            user=ssh_user,
            docker_via_sg=docker_via_sg,
        )
        _check("swarm_init", result)

        # Verify the node actually reached active state — Raft consensus
        # may take a moment after the init command returns.
        swarm_active = False
        for _ in range(5):
            verify = _ssh(
                config,
                "docker info --format '{{.Swarm.LocalNodeState}}'",
                user=ssh_user,
                docker_via_sg=docker_via_sg,
            )
            if verify.ok and "active" in verify.stdout:
                swarm_active = True
                break
            time.sleep(2)

        if not swarm_active:
            raise ProvisionError(
                "swarm_init",
                SSHResult(
                    stdout=verify.stdout if verify else "",
                    stderr="Swarm did not reach active state after init",
                    returncode=1,
                ),
            )

        phases_run.append("swarm_init")
        logger.info("Swarm initialized and verified active")

    # ---- Phase 5: Overlay network ----
    net_check = _ssh(
        config,
        f"docker network inspect {NETWORK_NAME}",
        user=ssh_user,
        docker_via_sg=docker_via_sg,
    )
    if net_check.ok:
        phases_skipped.append("network")
        logger.info("Network %s already exists", NETWORK_NAME)
    else:
        result = _ssh(
            config,
            f"docker network create --driver overlay --attachable {NETWORK_NAME}",
            user=ssh_user,
            docker_via_sg=docker_via_sg,
        )
        _check("network", result)
        phases_run.append("network")
        logger.info("Network %s created", NETWORK_NAME)

    # ---- Phase 6: Traefik ----
    traefik_check = _ssh(
        config,
        "docker service inspect infra_traefik",
        user=ssh_user,
        docker_via_sg=docker_via_sg,
    )
    if traefik_check.ok:
        phases_skipped.append("traefik")
        logger.info("Traefik already exists")
    else:
        # Ensure config dirs exist
        _ssh(config, f"{sudo_prefix}mkdir -p /etc/traefik/dynamic", user=ssh_user)
        if config.cloudflare.api_token:
            _ssh(
                config,
                f"{sudo_prefix}touch /etc/traefik/acme.json && "
                f"{sudo_prefix}chmod 600 /etc/traefik/acme.json",
                user=ssh_user,
            )

        cli = traefik_docker_cli(
            config.server.domain,
            cf_token=config.cloudflare.api_token or None,
        )
        result = _ssh(config, cli, user=ssh_user, timeout=120, docker_via_sg=docker_via_sg)
        _check("traefik", result)

        if not _wait_for_service(
            config, "infra_traefik", user=ssh_user, docker_via_sg=docker_via_sg
        ):
            logger.warning("Traefik did not reach 1/1 replicas within timeout")
        phases_run.append("traefik")
        logger.info("Traefik deployed")

    # ---- Phase 7: Docker Registry ----
    reg_check = _ssh(
        config, "docker service inspect registry", user=ssh_user, docker_via_sg=docker_via_sg
    )
    if reg_check.ok:
        phases_skipped.append("registry")
        logger.info("Registry already exists")
    else:
        cli = registry_docker_cli()
        result = _ssh(config, cli, user=ssh_user, timeout=120, docker_via_sg=docker_via_sg)
        _check("registry", result)

        if not _wait_for_service(
            config, "registry", user=ssh_user, docker_via_sg=docker_via_sg
        ):
            logger.warning("Registry did not reach 1/1 replicas within timeout")
        phases_run.append("registry")
        logger.info("Registry deployed")

    # Configure insecure registry in daemon.json
    for cmd in insecure_registry_setup_commands():
        _ssh(config, f"{sudo_prefix}{cmd}", user=ssh_user)

    # ---- Phase 8: PostgreSQL ----
    db_check = _ssh(
        config, f"docker service inspect {DB_SERVICE}", user=ssh_user,
        docker_via_sg=docker_via_sg,
    )
    if db_check.ok:
        phases_skipped.append("postgres")
        logger.info("PostgreSQL already exists")
    else:
        cli = postgres_docker_cli(DB_USER, db_password, DB_NAME)
        result = _ssh(config, cli, user=ssh_user, timeout=120, docker_via_sg=docker_via_sg)
        _check("postgres", result)

        # Wait for pg_isready
        pg_ready = False
        for _ in range(30):
            container = _ssh(
                config,
                f"docker ps --filter name={DB_SERVICE} --format '{{{{.ID}}}}' | head -1",
                user=ssh_user,
                docker_via_sg=docker_via_sg,
            )
            if container.ok and container.stdout.strip():
                ready = _ssh(
                    config,
                    f"docker exec {container.stdout.strip()} pg_isready -U {DB_USER} -d {DB_NAME}",
                    user=ssh_user,
                    docker_via_sg=docker_via_sg,
                )
                if ready.ok:
                    pg_ready = True
                    break
            time.sleep(2)

        if not pg_ready:
            logger.warning("PostgreSQL did not become ready within timeout")
        phases_run.append("postgres")
        logger.info("PostgreSQL deployed")

    # ---- Phase 9: Redis (cache + queue) ----
    for svc_name, vol_name, phase_name in [
        (CACHE_SERVICE, "bluefox-cloud-cache-data", "redis_cache"),
        (QUEUE_SERVICE, "bluefox-cloud-queue-data", "redis_queue"),
    ]:
        svc_check = _ssh(
            config, f"docker service inspect {svc_name}", user=ssh_user,
            docker_via_sg=docker_via_sg,
        )
        if svc_check.ok:
            phases_skipped.append(phase_name)
            logger.info("%s already exists", svc_name)
        else:
            cli = redis_docker_cli(svc_name, vol_name)
            result = _ssh(config, cli, user=ssh_user, timeout=120, docker_via_sg=docker_via_sg)
            _check(phase_name, result)
            phases_run.append(phase_name)
            logger.info("%s deployed", svc_name)

    # Wait for both Redis services
    for svc_name in [CACHE_SERVICE, QUEUE_SERVICE]:
        redis_ready = False
        for _ in range(15):
            container = _ssh(
                config,
                f"docker ps --filter name={svc_name} --format '{{{{.ID}}}}' | head -1",
                user=ssh_user,
                docker_via_sg=docker_via_sg,
            )
            if container.ok and container.stdout.strip():
                ping = _ssh(
                    config,
                    f"docker exec {container.stdout.strip()} redis-cli ping",
                    user=ssh_user,
                    docker_via_sg=docker_via_sg,
                )
                if ping.ok and "PONG" in ping.stdout:
                    redis_ready = True
                    break
            time.sleep(2)
        if not redis_ready:
            logger.warning("%s did not become ready within timeout", svc_name)

    database_url = f"postgresql+asyncpg://{DB_USER}:{db_password}@{DB_SERVICE}:5432/{DB_NAME}"
    cache_url = f"redis://{CACHE_SERVICE}:6379"
    queue_url = f"redis://{QUEUE_SERVICE}:6379"

    return ProvisionResult(
        database_url=database_url,
        cache_url=cache_url,
        queue_url=queue_url,
        phases_run=phases_run,
        phases_skipped=phases_skipped,
    )
