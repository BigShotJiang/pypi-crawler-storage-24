"""Infrastructure service specifications.

Pure data — defines how each infrastructure service should be created.
Each function returns a dict matching SwarmClient.create_service() kwargs,
plus a docker_cli() variant that returns a shell command string for SSH.
"""

from __future__ import annotations

from typing import Any

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
NETWORK_NAME = "bluefox-net"
TRAEFIK_IMAGE = "traefik:v3.4"
REGISTRY_IMAGE = "registry:2"
POSTGRES_IMAGE = "postgres:18-alpine"
REDIS_IMAGE = "redis:7-alpine"

# Service / database naming
DB_USER = "bluefox_cloud_database"
DB_NAME = "bluefox_cloud_database"
DB_SERVICE = "bluefox-cloud-database"
CACHE_SERVICE = "bluefox-cloud-cache"
QUEUE_SERVICE = "bluefox-cloud-queue"


# ---------------------------------------------------------------------------
# Traefik
# ---------------------------------------------------------------------------
def traefik_service_spec(
    domain: str,
    *,
    cf_token: str | None = None,
) -> dict[str, Any]:
    """Return SwarmClient.create_service() kwargs for Traefik."""
    command = [
        "--providers.file.directory=/etc/traefik/dynamic",
        "--providers.file.watch=true",
        "--entryPoints.web.address=:80",
        "--entryPoints.websecure.address=:443",
        "--api.insecure=false",
        "--log.level=WARN",
    ]

    env: dict[str, str] = {}
    mounts = ["/etc/traefik/dynamic:/etc/traefik/dynamic:ro"]

    if cf_token:
        command.extend(
            [
                f"--certificatesresolvers.letsencrypt.acme.email=ssl@{domain}",
                "--certificatesresolvers.letsencrypt.acme.storage=/etc/traefik/acme.json",
                "--certificatesresolvers.letsencrypt.acme.dnschallenge=true",
                "--certificatesresolvers.letsencrypt.acme.dnschallenge.provider=cloudflare",
            ]
        )
        env["CF_DNS_API_TOKEN"] = cf_token
        mounts.append("/etc/traefik/acme.json:/etc/traefik/acme.json")

    return {
        "image": TRAEFIK_IMAGE,
        "name": "infra_traefik",
        "command": command,
        "env": env if env else None,
        "networks": [NETWORK_NAME],
        "ports": {80: 80, 443: 443},
        "mounts": mounts,
        "constraints": ["node.role == manager"],
    }


def traefik_docker_cli(
    domain: str,
    *,
    cf_token: str | None = None,
) -> str:
    """Return a `docker service create` command string for Traefik."""
    spec = traefik_service_spec(domain, cf_token=cf_token)
    return spec_to_cli(spec)


# ---------------------------------------------------------------------------
# Docker Registry
# ---------------------------------------------------------------------------
def registry_service_spec() -> dict[str, Any]:
    """Return SwarmClient.create_service() kwargs for a local Docker registry."""
    return {
        "image": REGISTRY_IMAGE,
        "name": "registry",
        "networks": [NETWORK_NAME],
        "ports": {5000: 5000},
        "mounts": ["registry-data:/var/lib/registry"],
        "constraints": ["node.role == manager"],
    }


def registry_docker_cli() -> str:
    """Return a `docker service create` command string for the registry."""
    return spec_to_cli(registry_service_spec())


def insecure_registry_setup_commands() -> list[str]:
    """Return shell commands to configure Docker daemon for insecure localhost registry."""
    script = (
        "import json, pathlib; "
        "p = pathlib.Path('/etc/docker/daemon.json'); "
        "cfg = json.loads(p.read_text()) if p.exists() else {}; "
        "regs = cfg.get('insecure-registries', []); "
        "changed = 'localhost:5000' not in regs; "
        "regs.append('localhost:5000') if changed else None; "
        "cfg['insecure-registries'] = regs; "
        "p.write_text(json.dumps(cfg, indent=2)) if changed else None"
    )
    return [
        f'python3 -c "{script}"',
        "systemctl restart docker",
    ]


# ---------------------------------------------------------------------------
# PostgreSQL
# ---------------------------------------------------------------------------
def postgres_service_spec(
    db_user: str,
    db_password: str,
    db_name: str,
    *,
    service_name: str = "bluefox-cloud-database",
    volume_name: str = "bluefox-cloud-database-data",
) -> dict[str, Any]:
    """Return SwarmClient.create_service() kwargs for PostgreSQL."""
    return {
        "image": POSTGRES_IMAGE,
        "name": service_name,
        "networks": [NETWORK_NAME],
        "env": {
            "POSTGRES_USER": db_user,
            "POSTGRES_PASSWORD": db_password,
            "POSTGRES_DB": db_name,
        },
        "mounts": [f"{volume_name}:/var/lib/postgresql/data"],
        "constraints": ["node.role == manager"],
    }


def postgres_docker_cli(
    db_user: str,
    db_password: str,
    db_name: str,
    *,
    service_name: str = "bluefox-cloud-database",
    volume_name: str = "bluefox-cloud-database-data",
) -> str:
    """Return a `docker service create` command string for PostgreSQL."""
    return spec_to_cli(
        postgres_service_spec(
            db_user,
            db_password,
            db_name,
            service_name=service_name,
            volume_name=volume_name,
        )
    )


# ---------------------------------------------------------------------------
# Redis
# ---------------------------------------------------------------------------
def redis_service_spec(
    name: str,
    volume_name: str,
) -> dict[str, Any]:
    """Return SwarmClient.create_service() kwargs for Redis."""
    return {
        "image": REDIS_IMAGE,
        "name": name,
        "command": ["redis-server", "--appendonly", "yes"],
        "networks": [NETWORK_NAME],
        "mounts": [f"{volume_name}:/data"],
        "constraints": ["node.role == manager"],
    }


def redis_docker_cli(name: str, volume_name: str) -> str:
    """Return a `docker service create` command string for Redis."""
    return spec_to_cli(redis_service_spec(name, volume_name))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def spec_to_cli(spec: dict[str, Any]) -> str:
    """Convert a service spec dict to a `docker service create` command."""
    parts = ["docker service create --detach"]

    parts.append(f"--name {spec['name']}")

    for network in spec.get("networks") or []:
        parts.append(f"--network {network}")

    for mount in spec.get("mounts") or []:
        if ":" in mount and mount.split(":")[0].startswith("/"):
            converted = mount.replace(":ro", ",readonly").replace(":", ",target=", 1)
            parts.append(f"--mount type=bind,source={converted}")
        else:
            vol_parts = mount.split(":")
            mount_str = f"type=volume,source={vol_parts[0]},target={vol_parts[1]}"
            if len(vol_parts) > 2 and vol_parts[2] == "ro":
                mount_str += ",readonly"
            parts.append(f"--mount {mount_str}")

    for key, value in (spec.get("env") or {}).items():
        parts.append(f'--env "{key}={value}"')

    for port_pub, port_target in (spec.get("ports") or {}).items():
        parts.append(f"--publish published={port_pub},target={port_target},mode=host")

    for constraint in spec.get("constraints") or []:
        parts.append(f"--constraint '{constraint}'")

    parts.append(spec["image"])

    if spec.get("command"):
        cmd = spec["command"]
        if isinstance(cmd, list):
            parts.extend(cmd)
        else:
            parts.append(cmd)

    return " \\\n    ".join(parts)
