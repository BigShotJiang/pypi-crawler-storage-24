"""Platform deploy and update operations.

Handles building, pushing, and deploying the Bluefox Cloud platform
service (web + worker) for both remote (SSH) and local (SwarmClient) environments.
"""

from __future__ import annotations

import logging
import subprocess
from pathlib import Path
from typing import Any

import docker.errors

from bluefox_cloud.bootstrap.infra import NETWORK_NAME, spec_to_cli
from bluefox_cloud.config import CloudConfig
from bluefox_cloud.ssh.client import SSHResult, ssh_run
from bluefox_cloud.swarm.client import SwarmClient
from bluefox_cloud.traefik.config import TraefikConfig

logger = logging.getLogger(__name__)

WEB_SERVICE = "bluefox-cloud-web"
WORKER_SERVICE = "bluefox-cloud-worker"
REGISTRY_TAG = "localhost:5000/bluefox-cloud-web:latest"
TRAEFIK_CONFIG_DIR = "/etc/traefik/dynamic"


# ---------------------------------------------------------------------------
# Platform service specs
# ---------------------------------------------------------------------------
def _web_service_spec(
    image: str,
    env: dict[str, str],
) -> dict[str, Any]:
    """Return service spec for the platform web service."""
    return {
        "image": image,
        "name": WEB_SERVICE,
        "networks": [NETWORK_NAME],
        "env": env,
        "mounts": [
            "/var/run/docker.sock:/var/run/docker.sock:ro",
            f"{TRAEFIK_CONFIG_DIR}:{TRAEFIK_CONFIG_DIR}",
        ],
        "constraints": ["node.role == manager"],
    }


def _worker_service_spec(
    image: str,
    env: dict[str, str],
) -> dict[str, Any]:
    """Return service spec for the platform worker service."""
    return {
        "image": image,
        "name": WORKER_SERVICE,
        "command": ["uv", "run", "saq", "bluefox.worker.settings"],
        "networks": [NETWORK_NAME],
        "env": env,
        "constraints": ["node.role == manager"],
    }


# ---------------------------------------------------------------------------
# Traefik config for platform
# ---------------------------------------------------------------------------
def _platform_traefik_yaml(domain: str) -> str:
    """Generate Traefik dynamic config YAML for the platform.

    Uses TraefikConfig with a temp directory to produce the same YAML
    structure used by deploy_local, ensuring both paths stay in sync.
    """
    import tempfile

    with tempfile.TemporaryDirectory() as tmp:
        traefik = TraefikConfig(Path(tmp))
        path = traefik.write_app_config(
            "platform",
            f"http://{WEB_SERVICE}:8000",
            [f"platform.{domain}"],
        )
        return path.read_text()


# ---------------------------------------------------------------------------
# Remote (SSH) operations
# ---------------------------------------------------------------------------
def _ssh(
    config: CloudConfig,
    command: str,
    *,
    timeout: int = 300,
) -> SSHResult:
    """Shorthand for ssh_run with config values."""
    return ssh_run(
        host=config.server.ip,
        user=config.server.user,
        port=config.server.ssh_port,
        command=command,
        timeout=timeout,
    )


def build_and_push_remote(
    config: CloudConfig,
    *,
    repo_path: str,
) -> str | None:
    """Build the platform Docker image on the remote server and push to local registry.

    Args:
        config: Cloud configuration with server details.
        repo_path: Local path to the repository to sync.

    Returns:
        The registry image tag, or None if any step failed.
    """
    host = config.server.ip
    user = config.server.user
    port = config.server.ssh_port
    remote_dir = "/opt/bluefox-cloud"

    # Rsync repo to server
    result = ssh_run(
        host=host,
        user=user,
        port=port,
        command=f"mkdir -p {remote_dir}",
    )
    if not result.ok:
        logger.warning("Failed to create remote dir: %s", result.stderr)

    # Note: rsync is run locally, not via ssh_run
    rsync_result = subprocess.run(
        [
            "rsync",
            "-az",
            "--delete",
            "--exclude",
            ".git",
            "--exclude",
            "__pycache__",
            "--exclude",
            ".venv",
            "-e",
            f"ssh -o StrictHostKeyChecking=accept-new -p {port}",
            f"{repo_path}/",
            f"{user}@{host}:{remote_dir}/",
        ],
        capture_output=True,
        text=True,
        timeout=120,
    )
    if rsync_result.returncode != 0:
        logger.error("Rsync failed: %s", rsync_result.stderr)
        return None

    # Build
    result = _ssh(
        config,
        f"docker build -t {WEB_SERVICE}:latest {remote_dir}",
        timeout=600,
    )
    if not result.ok:
        logger.error("Docker build failed: %s", result.stderr[:500])
        return None

    # Tag for local registry
    result = _ssh(config, f"docker tag {WEB_SERVICE}:latest {REGISTRY_TAG}")
    if not result.ok:
        logger.error("Docker tag failed: %s", result.stderr[:500])
        return None

    # Push to local registry
    result = _ssh(config, f"docker push {REGISTRY_TAG}", timeout=120)
    if not result.ok:
        logger.error("Docker push failed: %s", result.stderr[:500])
        return None

    logger.info("Built and pushed %s", REGISTRY_TAG)
    return REGISTRY_TAG


def deploy_remote(
    config: CloudConfig,
    *,
    image_tag: str,
    env: dict[str, str],
) -> None:
    """Deploy or update the platform services on a remote server.

    Args:
        config: Cloud configuration with server details.
        image_tag: Docker image tag to deploy.
        env: Environment variables for the platform services.
    """
    domain = config.server.domain

    # Write Traefik config via SSH
    traefik_yaml = _platform_traefik_yaml(domain)
    escaped_yaml = traefik_yaml.replace("'", "'\\''")
    _ssh(
        config,
        f"sudo mkdir -p {TRAEFIK_CONFIG_DIR} && "
        f"echo '{escaped_yaml}' | sudo tee {TRAEFIK_CONFIG_DIR}/platform.yml > /dev/null",
    )
    logger.info("Traefik config written for platform.%s", domain)

    # Deploy web service
    web_spec = _web_service_spec(image_tag, env)
    _deploy_or_update_remote(config, web_spec)

    # Deploy worker service
    worker_spec = _worker_service_spec(image_tag, env)
    _deploy_or_update_remote(config, worker_spec)


def _deploy_or_update_remote(
    config: CloudConfig,
    spec: dict[str, Any],
) -> None:
    """Create or update a service on the remote server via SSH."""
    name = spec["name"]
    check = _ssh(config, f"docker service inspect {name}")
    if check.ok:
        # Update existing service
        update_parts = ["docker service update --detach"]
        update_parts.append(f"--image {spec['image']}")
        for key, value in (spec.get("env") or {}).items():
            update_parts.append(f'--env-add "{key}={value}"')
        update_parts.append("--force")
        update_parts.append(name)
        cmd = " \\\n    ".join(update_parts)
        result = _ssh(config, cmd, timeout=120)
        if result.ok:
            logger.info("Updated service %s", name)
        else:
            logger.error("Failed to update %s: %s", name, result.stderr[:500])
    else:
        # Create new service
        cli = spec_to_cli(spec)
        result = _ssh(config, cli, timeout=120)
        if result.ok:
            logger.info("Created service %s", name)
        else:
            logger.error("Failed to create %s: %s", name, result.stderr[:500])


def run_migrations_remote(
    config: CloudConfig,
    *,
    image_tag: str,
    database_url: str,
) -> SSHResult:
    """Run database migrations on the remote server.

    Args:
        config: Cloud configuration with server details.
        image_tag: Docker image tag containing the migration code.
        database_url: Full database connection URL.

    Returns:
        SSHResult from the migration command.
    """
    result = _ssh(
        config,
        f"docker run --rm --network {NETWORK_NAME} "
        f'-e "DATABASE_URL={database_url}" '
        f"{image_tag} uv run alembic upgrade head",
        timeout=120,
    )
    if result.ok:
        logger.info("Migrations completed successfully")
    else:
        logger.error("Migrations failed: %s", result.stderr[:500])
    return result


# ---------------------------------------------------------------------------
# Local operations
# ---------------------------------------------------------------------------
async def deploy_local(
    *,
    domain: str,
    image_tag: str,
    env: dict[str, str],
    traefik_config_dir: Path = Path(TRAEFIK_CONFIG_DIR),
) -> None:
    """Deploy or update the platform services locally.

    Args:
        domain: Domain for Traefik routing.
        image_tag: Docker image tag to deploy.
        env: Environment variables for the platform services.
        traefik_config_dir: Path to Traefik dynamic config directory.
    """
    swarm = SwarmClient()

    # Write Traefik config
    traefik = TraefikConfig(traefik_config_dir)
    traefik.write_app_config(
        "platform",
        f"http://{WEB_SERVICE}:8000",
        [f"platform.{domain}"],
    )
    logger.info("Traefik config written for platform.%s", domain)

    # Deploy web service
    web_spec = _web_service_spec(image_tag, env)
    await _deploy_or_update_local(swarm, web_spec)

    # Deploy worker service
    worker_spec = _worker_service_spec(image_tag, env)
    await _deploy_or_update_local(swarm, worker_spec)


async def _deploy_or_update_local(
    swarm: SwarmClient,
    spec: dict[str, Any],
) -> None:
    """Create or update a service locally via SwarmClient."""
    name = spec["name"]
    try:
        await swarm.get_service(name)
        # Update existing
        await swarm.update_service(
            name,
            image=spec["image"],
            env=spec.get("env"),
            force_update=True,
        )
        logger.info("Updated service %s", name)
    except docker.errors.NotFound:
        await swarm.create_service(
            image=spec["image"],
            name=name,
            command=spec.get("command"),
            env=spec.get("env"),
            networks=spec.get("networks"),
            mounts=spec.get("mounts"),
            constraints=spec.get("constraints"),
        )
        logger.info("Created service %s", name)


async def run_migrations_local(
    *,
    image_tag: str,
    database_url: str,
) -> str:
    """Run database migrations locally via a one-shot container.

    Args:
        image_tag: Docker image tag containing the migration code.
        database_url: Full database connection URL.

    Returns:
        Output from the migration command.
    """
    swarm = SwarmClient()
    output = await swarm.run_oneshot(
        image=image_tag,
        command=["uv", "run", "alembic", "upgrade", "head"],
        env={"DATABASE_URL": database_url},
        networks=[NETWORK_NAME],
    )
    logger.info("Migrations completed successfully")
    return output
