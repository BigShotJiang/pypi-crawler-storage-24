"""Local development provisioning using Docker Swarm.

Orchestrates local dev setup: Swarm init, overlay network, Traefik,
registry, Postgres, and Redis — all via the local Docker daemon.
"""

from __future__ import annotations

import logging
import subprocess

import docker.errors

from bluefox_cloud.bootstrap.infra import (
    CACHE_SERVICE,
    DB_NAME,
    DB_SERVICE,
    DB_USER,
    NETWORK_NAME,
    QUEUE_SERVICE,
    postgres_service_spec,
    redis_service_spec,
    registry_service_spec,
    traefik_service_spec,
)
from bluefox_cloud.bootstrap.remote import ProvisionResult
from bluefox_cloud.swarm.client import SwarmClient

logger = logging.getLogger(__name__)


async def _create_service_from_spec(
    swarm: SwarmClient,
    spec: dict,
    phase_name: str,
    phases_run: list[str],
    phases_skipped: list[str],
) -> None:
    """Create a service from a spec dict, skipping if it already exists."""
    name = spec["name"]
    try:
        await swarm.get_service(name)
        phases_skipped.append(phase_name)
        logger.info("%s already exists", name)
    except docker.errors.NotFound:
        await swarm.create_service(
            image=spec["image"],
            name=name,
            command=spec.get("command"),
            env=spec.get("env"),
            networks=spec.get("networks"),
            ports=spec.get("ports"),
            mounts=spec.get("mounts"),
            constraints=spec.get("constraints"),
        )
        phases_run.append(phase_name)
        logger.info("%s deployed", name)


async def provision(
    *,
    domain: str = "localhost",
    db_password: str,
) -> ProvisionResult:
    """Provision a local development environment with Docker Swarm infrastructure.

    Args:
        domain: Domain for Traefik routing (default: localhost).
        db_password: Password for the platform database.

    Returns:
        ProvisionResult with connection URLs and phase status.
    """
    phases_run: list[str] = []
    phases_skipped: list[str] = []
    swarm = SwarmClient()

    # ---- Phase 1: Swarm init ----
    result = subprocess.run(
        ["docker", "info", "--format", "{{.Swarm.LocalNodeState}}"],
        capture_output=True,
        text=True,
        timeout=30,
    )
    if result.returncode == 0 and "active" in result.stdout:
        phases_skipped.append("swarm_init")
        logger.info("Swarm already active")
    else:
        subprocess.run(
            ["docker", "swarm", "init"],
            capture_output=True,
            text=True,
            timeout=30,
            check=True,
        )
        phases_run.append("swarm_init")
        logger.info("Swarm initialized")

    # ---- Phase 2: Overlay network ----
    try:
        await swarm.get_network(NETWORK_NAME)
        phases_skipped.append("network")
        logger.info("Network %s already exists", NETWORK_NAME)
    except docker.errors.NotFound:
        await swarm.create_network(NETWORK_NAME)
        phases_run.append("network")
        logger.info("Network %s created", NETWORK_NAME)

    # ---- Phase 3: Traefik ----
    spec = traefik_service_spec(domain)
    await _create_service_from_spec(swarm, spec, "traefik", phases_run, phases_skipped)

    # ---- Phase 4: Registry ----
    spec = registry_service_spec()
    await _create_service_from_spec(swarm, spec, "registry", phases_run, phases_skipped)

    # ---- Phase 5: PostgreSQL ----
    spec = postgres_service_spec(DB_USER, db_password, DB_NAME)
    await _create_service_from_spec(swarm, spec, "postgres", phases_run, phases_skipped)

    # ---- Phase 6: Redis (cache + queue) ----
    for svc_name, vol_name, phase_name in [
        (CACHE_SERVICE, "bluefox-cloud-cache-data", "redis_cache"),
        (QUEUE_SERVICE, "bluefox-cloud-queue-data", "redis_queue"),
    ]:
        spec = redis_service_spec(svc_name, vol_name)
        await _create_service_from_spec(swarm, spec, phase_name, phases_run, phases_skipped)

    database_url = f"postgresql+asyncpg://{DB_USER}:{db_password}@{DB_SERVICE}:5432/{DB_NAME}"
    cache_url = f"redis://{CACHE_SERVICE}:6379"
    queue_url = f"redis://{QUEUE_SERVICE}:6379"

    return ProvisionResult(
        database_url=database_url,
        cache_url=cache_url,
        queue_url=queue_url,
        phases_run=phases_run,
        phases_skipped=phases_skipped,
    )
