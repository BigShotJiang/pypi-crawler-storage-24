#!/usr/bin/env bash
# =============================================================================
# Bluefox Cloud — Docker Engine Installation
#
# Runs as: root
# Idempotent: safe to re-run.
# =============================================================================
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

ok()   { echo -e "${GREEN}[ OK ]${NC}  $*"; }
skip() { echo -e "${YELLOW}[SKIP]${NC}  $*"; }

# ---------------------------------------------------------------------------
# 1. Install Docker Engine
# ---------------------------------------------------------------------------
if command -v docker &>/dev/null; then
    skip "Docker already installed ($(docker --version 2>/dev/null | head -1))"
else
    echo "Installing Docker Engine..."
    apt-get update -qq
    apt-get install -y -qq ca-certificates curl gnupg > /dev/null 2>&1

    install -m 0755 -d /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
    chmod a+r /etc/apt/keyrings/docker.gpg

    echo \
      "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
      https://download.docker.com/linux/ubuntu \
      $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
      tee /etc/apt/sources.list.d/docker.list > /dev/null

    apt-get update -qq
    apt-get install -y -qq docker-ce docker-ce-cli containerd.io docker-compose-plugin > /dev/null 2>&1
    ok "Docker installed"
fi

# ---------------------------------------------------------------------------
# 2. Add deploy to docker group
# ---------------------------------------------------------------------------
if id -nG deploy | grep -qw docker; then
    skip "'deploy' already in docker group"
else
    usermod -aG docker deploy
    ok "Added 'deploy' to docker group"
fi

echo ""
ok "Docker installation complete"
