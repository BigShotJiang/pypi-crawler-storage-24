#!/usr/bin/env bash
# =============================================================================
# Bluefox Cloud — Server Hardening
#
# Expects: SSH_PORT (default 22)
# Runs as: root
# Idempotent: safe to re-run.
# =============================================================================
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive

SSH_PORT="${SSH_PORT:-22}"

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

ok()   { echo -e "${GREEN}[ OK ]${NC}  $*"; }
skip() { echo -e "${YELLOW}[SKIP]${NC}  $*"; }

# ---------------------------------------------------------------------------
# 1. Create deploy user with passwordless sudo
# ---------------------------------------------------------------------------
if id "deploy" &>/dev/null; then
    skip "User 'deploy' already exists"
else
    adduser --disabled-password --gecos "" deploy
    usermod -aG sudo deploy
    echo "deploy ALL=(ALL) NOPASSWD:ALL" > /etc/sudoers.d/deploy
    chmod 440 /etc/sudoers.d/deploy
    ok "User 'deploy' created with sudo"
fi

# ---------------------------------------------------------------------------
# 2. Copy SSH keys to deploy user
# ---------------------------------------------------------------------------
mkdir -p /home/deploy/.ssh

if [[ -f /root/.ssh/authorized_keys ]] && [[ ! -f /home/deploy/.ssh/authorized_keys ]]; then
    cp /root/.ssh/authorized_keys /home/deploy/.ssh/authorized_keys
    chown -R deploy:deploy /home/deploy/.ssh
    chmod 700 /home/deploy/.ssh
    chmod 600 /home/deploy/.ssh/authorized_keys
    ok "SSH keys copied to deploy"
elif [[ -f /home/deploy/.ssh/authorized_keys ]]; then
    skip "deploy SSH keys already exist"
fi

# ---------------------------------------------------------------------------
# 3. Harden sshd
# ---------------------------------------------------------------------------
SSHD_CONFIG="/etc/ssh/sshd_config"
SSHD_CHANGED=false

harden_sshd() {
    local key="$1" value="$2"
    if grep -qE "^\s*${key}\s+${value}\s*$" "$SSHD_CONFIG"; then
        return
    fi
    if grep -qE "^#?\s*${key}\s" "$SSHD_CONFIG"; then
        sed -i "s/^#\?\s*${key}\s.*/${key} ${value}/" "$SSHD_CONFIG"
    else
        echo "${key} ${value}" >> "$SSHD_CONFIG"
    fi
    SSHD_CHANGED=true
}

harden_sshd "PermitRootLogin" "no"
harden_sshd "PasswordAuthentication" "no"

if [[ "$SSHD_CHANGED" == "true" ]]; then
    systemctl restart ssh
    ok "SSH hardened (no root login, no password auth)"
else
    skip "SSH already hardened"
fi

# ---------------------------------------------------------------------------
# 4. UFW firewall
# ---------------------------------------------------------------------------
if ! command -v ufw &>/dev/null; then
    apt-get update -qq && apt-get install -y -qq ufw > /dev/null 2>&1
fi

ufw --force reset > /dev/null 2>&1
ufw default deny incoming > /dev/null 2>&1
ufw default allow outgoing > /dev/null 2>&1
ufw allow "${SSH_PORT}/tcp" > /dev/null 2>&1
ufw allow 80/tcp > /dev/null 2>&1
ufw allow 443/tcp > /dev/null 2>&1
ufw --force enable > /dev/null 2>&1
ok "UFW configured (${SSH_PORT}, 80, 443)"

# ---------------------------------------------------------------------------
# 5. Timezone UTC
# ---------------------------------------------------------------------------
timedatectl set-timezone UTC 2>/dev/null || true
ok "Timezone UTC"

# ---------------------------------------------------------------------------
# 6. Unattended upgrades
# ---------------------------------------------------------------------------
if ! dpkg -l unattended-upgrades &>/dev/null 2>&1; then
    apt-get update -qq && apt-get install -y -qq unattended-upgrades > /dev/null 2>&1
    dpkg-reconfigure -plow unattended-upgrades 2>/dev/null || true
fi
ok "unattended-upgrades"

# ---------------------------------------------------------------------------
# 7. fail2ban
# ---------------------------------------------------------------------------
if ! command -v fail2ban-client &>/dev/null; then
    apt-get update -qq && apt-get install -y -qq fail2ban > /dev/null 2>&1
fi

cat > /etc/fail2ban/jail.local <<F2B
[sshd]
enabled  = true
port     = ${SSH_PORT}
filter   = sshd
logpath  = /var/log/auth.log
maxretry = 5
bantime  = 600
findtime = 600
F2B

systemctl enable fail2ban > /dev/null 2>&1
systemctl restart fail2ban > /dev/null 2>&1
ok "fail2ban (sshd on ${SSH_PORT}, ban after 5 attempts)"

echo ""
ok "Server hardening complete"
