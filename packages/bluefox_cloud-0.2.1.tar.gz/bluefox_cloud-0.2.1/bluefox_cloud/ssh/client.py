from __future__ import annotations

import subprocess
from importlib import resources
from pathlib import Path

from pydantic import BaseModel


class SSHResult(BaseModel):
    stdout: str
    stderr: str
    returncode: int

    @property
    def ok(self) -> bool:
        return self.returncode == 0


def _ssh_base_args(host: str, user: str, port: int) -> list[str]:
    return [
        "ssh",
        "-o",
        "StrictHostKeyChecking=accept-new",
        "-o",
        "ConnectTimeout=10",
        "-p",
        str(port),
        f"{user}@{host}",
    ]


def ssh_run(
    host: str,
    user: str,
    port: int,
    command: str,
    *,
    timeout: int = 300,
) -> SSHResult:
    """Execute a command on a remote host via SSH."""
    args = [*_ssh_base_args(host, user, port), command]
    result = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    return SSHResult(stdout=result.stdout, stderr=result.stderr, returncode=result.returncode)


def _scp_args(host: str, user: str, port: int, local_path: str, remote_path: str) -> list[str]:
    return [
        "scp",
        "-o",
        "StrictHostKeyChecking=accept-new",
        "-o",
        "ConnectTimeout=10",
        "-P",
        str(port),
        local_path,
        f"{user}@{host}:{remote_path}",
    ]


def ssh_upload_and_run(
    host: str,
    user: str,
    port: int,
    script_path: Path | str,
    *,
    env: dict[str, str] | None = None,
    timeout: int = 600,
) -> SSHResult:
    """Upload a script via SCP and execute it on the remote host.

    Args:
        env: Optional environment variables to set before running the script.
    """
    script_path = Path(script_path)
    remote_path = f"/tmp/{script_path.name}"

    # Upload
    scp_args = _scp_args(host, user, port, str(script_path), remote_path)
    scp_result = subprocess.run(scp_args, capture_output=True, text=True, timeout=60)
    if scp_result.returncode != 0:
        return SSHResult(
            stdout=scp_result.stdout,
            stderr=f"SCP upload failed: {scp_result.stderr}",
            returncode=scp_result.returncode,
        )

    # Build command with optional env vars
    env_prefix = ""
    if env:
        env_prefix = " ".join(f"{k}='{v}'" for k, v in env.items()) + " "
    return ssh_run(host, user, port, f"{env_prefix}bash {remote_path}", timeout=timeout)


def get_bundled_script(name: str) -> Path:
    """Get the path to a bundled shell script in the ssh/scripts directory."""
    scripts = resources.files("bluefox_cloud.ssh") / "scripts"
    script = scripts / name
    if not script.is_file():
        raise FileNotFoundError(f"Bundled script not found: {name}")
    return Path(str(script))


def ssh_upload_and_run_bundled(
    host: str,
    user: str,
    port: int,
    script_name: str,
    *,
    env: dict[str, str] | None = None,
    timeout: int = 600,
) -> SSHResult:
    """Upload and run a bundled script from bluefox_cloud/ssh/scripts/."""
    script_path = get_bundled_script(script_name)
    return ssh_upload_and_run(host, user, port, script_path, env=env, timeout=timeout)
