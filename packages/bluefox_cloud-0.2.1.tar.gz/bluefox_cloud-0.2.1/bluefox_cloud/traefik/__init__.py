from bluefox_cloud.traefik.config import TraefikConfig

__all__ = ["TraefikConfig"]
