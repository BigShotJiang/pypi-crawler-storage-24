from __future__ import annotations


def letsencrypt_tls(domain: str, sans: list[str] | None = None) -> dict:
    """Build a TLS config dict for Let's Encrypt cert resolver.

    Args:
        domain: Primary domain for the certificate.
        sans: Optional list of Subject Alternative Names.
    """
    tls: dict = {"certResolver": "letsencrypt"}
    domains_entry: dict = {"main": domain}
    if sans:
        domains_entry["sans"] = sans
    tls["domains"] = [domains_entry]
    return tls


def default_tls() -> dict:
    """Empty TLS config — uses Traefik's default certificate."""
    return {}
