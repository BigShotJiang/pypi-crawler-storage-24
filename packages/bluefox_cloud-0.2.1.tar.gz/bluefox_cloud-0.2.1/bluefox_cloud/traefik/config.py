from __future__ import annotations

from pathlib import Path

import yaml


class TraefikConfig:
    """Manages per-app Traefik dynamic config files.

    Traefik's file provider watches `config_dir` for changes.
    Each app gets one YAML file: `{app_name}.yml`.
    """

    def __init__(self, config_dir: Path) -> None:
        self.config_dir = config_dir

    def write_app_config(
        self,
        app_name: str,
        service_url: str,
        hostnames: list[str],
        *,
        tls: dict | None = None,
    ) -> Path:
        """Write a Traefik dynamic config file for an app.

        Args:
            app_name: App identifier, used as router/service name and filename.
            service_url: Backend URL (e.g. "http://myapp_app:8080").
            hostnames: List of hostnames to route to this app.
            tls: Optional TLS config dict. If None, uses empty `{}` (default cert).
                 Pass `{"certResolver": "letsencrypt"}` for ACME, or include
                 `"domains"` for SANs.
        """
        host_rule = " || ".join(f"Host(`{h}`)" for h in hostnames)
        tls_config = tls if tls is not None else {}

        config = {
            "http": {
                "routers": {
                    app_name: {
                        "rule": host_rule,
                        "entryPoints": ["web"],
                        "service": app_name,
                    },
                    f"{app_name}-secure": {
                        "rule": host_rule,
                        "entryPoints": ["websecure"],
                        "service": app_name,
                        "tls": tls_config,
                    },
                },
                "services": {
                    app_name: {
                        "loadBalancer": {
                            "servers": [{"url": service_url}],
                        },
                    },
                },
            },
        }

        self.config_dir.mkdir(parents=True, exist_ok=True)
        path = self.config_dir / f"{app_name}.yml"
        path.write_text(yaml.dump(config, default_flow_style=False, sort_keys=False))
        return path

    def remove_app_config(self, app_name: str) -> bool:
        """Remove a Traefik dynamic config file for an app.

        Returns True if the file existed and was removed, False otherwise.
        """
        path = self.config_dir / f"{app_name}.yml"
        if path.exists():
            path.unlink()
            return True
        return False

    def read_app_config(self, app_name: str) -> dict | None:
        """Read and parse the Traefik config for an app, or None if missing."""
        path = self.config_dir / f"{app_name}.yml"
        if not path.exists():
            return None
        return yaml.safe_load(path.read_text())
