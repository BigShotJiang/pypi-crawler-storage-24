from __future__ import annotations

from typing import Any

import anyio
import anyio.to_thread
import docker
import docker.errors
from docker.models.services import Service
from docker.types import EndpointSpec, NetworkAttachmentConfig, RestartPolicy, ServiceMode


class SwarmClient:
    def __init__(self, client: docker.DockerClient | None = None) -> None:
        self._client = client or docker.from_env()

    async def _run_sync(self, fn: Any, *args: Any, **kwargs: Any) -> Any:
        return await anyio.to_thread.run_sync(lambda: fn(*args, **kwargs))

    async def create_service(
        self,
        image: str,
        name: str,
        *,
        command: str | list[str] | None = None,
        env: dict[str, str] | None = None,
        networks: list[str] | None = None,
        ports: dict[int, int] | None = None,
        replicas: int = 1,
        restart_policy: dict[str, Any] | None = None,
        mounts: list[str] | None = None,
        constraints: list[str] | None = None,
        labels: dict[str, str] | None = None,
    ) -> Service:
        """Create a Docker Swarm service."""
        kwargs: dict[str, Any] = {
            "image": image,
            "name": name,
        }
        if command is not None:
            kwargs["command"] = command
        if env:
            kwargs["env"] = [f"{k}={v}" for k, v in env.items()]
        if networks:
            kwargs["networks"] = [NetworkAttachmentConfig(n) for n in networks]
        if ports:
            kwargs["endpoint_spec"] = EndpointSpec(ports=ports)
        if mounts:
            kwargs["mounts"] = mounts
        if labels:
            kwargs["labels"] = labels

        kwargs["mode"] = ServiceMode("replicated", replicas=replicas)
        kwargs["restart_policy"] = RestartPolicy(
            **(restart_policy or {"condition": "on-failure", "max_attempts": 3})
        )
        if constraints:
            kwargs["constraints"] = constraints

        return await self._run_sync(self._client.services.create, **kwargs)

    async def get_service(self, name: str) -> Service:
        """Get a service by name. Raises docker.errors.NotFound if missing."""
        return await self._run_sync(self._client.services.get, name)

    async def list_services(self, **filters: Any) -> list[Service]:
        """List services, optionally filtered."""
        return await self._run_sync(self._client.services.list, filters=filters)

    async def update_service(
        self,
        name: str,
        *,
        image: str | None = None,
        env: dict[str, str] | None = None,
        replicas: int | None = None,
        force_update: bool = False,
    ) -> None:
        """Update an existing service."""
        service = await self.get_service(name)
        kwargs: dict[str, Any] = {}
        if image is not None:
            kwargs["image"] = image
        if env is not None:
            kwargs["env"] = [f"{k}={v}" for k, v in env.items()]
        if replicas is not None:
            kwargs["mode"] = ServiceMode("replicated", replicas=replicas)
        if force_update:
            kwargs["force_update"] = True
        await self._run_sync(service.update, **kwargs)

    async def remove_service(self, name: str) -> None:
        """Remove a service by name."""
        service = await self.get_service(name)
        await self._run_sync(service.remove)

    async def create_network(
        self,
        name: str,
        *,
        driver: str = "overlay",
        attachable: bool = True,
    ) -> Any:
        """Create a Docker network."""
        return await self._run_sync(
            self._client.networks.create,
            name,
            driver=driver,
            attachable=attachable,
        )

    async def get_network(self, name: str) -> Any:
        """Get a network by name."""
        return await self._run_sync(self._client.networks.get, name)

    async def run_oneshot(
        self,
        image: str,
        command: str | list[str],
        *,
        name: str | None = None,
        env: dict[str, str] | None = None,
        networks: list[str] | None = None,
        remove: bool = True,
    ) -> str:
        """Run a one-shot container and return its output."""
        kwargs: dict[str, Any] = {
            "image": image,
            "command": command,
            "detach": False,
            "remove": remove,
        }
        if name:
            kwargs["name"] = name
        if env:
            kwargs["environment"] = env
        if networks:
            kwargs["network"] = networks[0]

        output = await self._run_sync(self._client.containers.run, **kwargs)
        if isinstance(output, bytes):
            return output.decode()
        return str(output)

    async def get_service_logs(
        self,
        name: str,
        *,
        tail: int = 100,
        timestamps: bool = False,
    ) -> str:
        """Get logs from a service."""
        service = await self.get_service(name)
        logs = await self._run_sync(
            service.logs,
            tail=tail,
            timestamps=timestamps,
            stdout=True,
            stderr=True,
        )
        if isinstance(logs, bytes):
            return logs.decode()
        return str(logs)
