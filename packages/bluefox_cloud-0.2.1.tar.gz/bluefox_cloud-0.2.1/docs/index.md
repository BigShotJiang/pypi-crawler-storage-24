# bluefox-cloud

PaaS infrastructure management for the Bluefox Stack.

## What it does

- **Docker Swarm orchestration** — create, update, scale, and remove services with an async wrapper
- **Traefik routing** — dynamic YAML config per app with multi-domain and Let's Encrypt TLS support
- **Cloudflare DNS** — async httpx client for zone lookup, record CRUD, upsert, and custom domain verification
- **SSH operations** — remote command execution and bundled server setup scripts
- **Cloud config** — read/write `~/.bluefox/cloud.yml` with Pydantic V2 models
- **Zero-downtime deploys** — rolling updates via Docker Swarm with health checks
- **Server provisioning** — one-command remote (SSH) or local setup: hardening, Docker, Swarm, Traefik, Postgres, Redis
- **Platform deployment** — build, push, deploy web + worker services, and run migrations

## Quick start

```python
from bluefox_cloud.swarm import SwarmClient
from bluefox_cloud.traefik import TraefikConfig
from bluefox_cloud.cloudflare import CloudflareClient

# Deploy a service
swarm = SwarmClient()
await swarm.create_service(image="my-app:latest", name="my-app")

# Configure routing
traefik = TraefikConfig("/etc/traefik/dynamic")
traefik.write_app_config(app_name="my-app", hostnames=["my-app.example.com"])

# Set up DNS
async with CloudflareClient(api_token) as cf:
    await cf.upsert_record(zone_id, name="my-app", record_type=DNSRecordType.A, content="1.2.3.4")
```

## Bootstrap

Provision a server and deploy the platform in two calls:

```python
from bluefox_cloud.bootstrap import remote_provision, deploy_remote, build_and_push_remote
from bluefox_cloud.config import load_config

config = load_config()

# 1. Provision infrastructure (idempotent — safe to re-run)
result = remote_provision(config, db_password="strong-secret")

# 2. Build, push, and deploy the platform
image = build_and_push_remote(config, repo_path="/path/to/repo")
deploy_remote(config, image_tag=image, env=result.env)
```

Local development uses the same pattern with async equivalents:

```python
from bluefox_cloud.bootstrap import local_provision, deploy_local

result = await local_provision(db_password="dev-secret")
await deploy_local(domain="localhost", image_tag="myimage:latest", env=result.env)
```

## Modules

| Module | Description |
|--------|-------------|
| `bluefox_cloud.config` | Cloud config read/write (`~/.bluefox/cloud.yml`) |
| `bluefox_cloud.ssh` | Remote command execution via subprocess SSH |
| `bluefox_cloud.swarm` | Docker Swarm service management |
| `bluefox_cloud.traefik` | Dynamic Traefik config generation |
| `bluefox_cloud.cloudflare` | Cloudflare API client for DNS management |
| `bluefox_cloud.bootstrap` | Server provisioning and platform deployment |

## Requirements

- Python 3.12+
- Docker (with Swarm mode for orchestration)
- Cloudflare account (for DNS management)

## Installation

```bash
uv add bluefox-cloud
```
