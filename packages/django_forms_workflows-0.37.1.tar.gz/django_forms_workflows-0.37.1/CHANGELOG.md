# Changelog

All notable changes to Django Forms Workflows will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.37.1] - 2026-03-26

### Fixed
- **`reviewer_groups` now visible in Approval History** — `completed_approvals` and `completed_approvals_ajax` previously built their base queryset exclusively from `ApprovalTask` records, so reviewer-group members were never shown any submissions (a form with zero approval steps produces no `ApprovalTask` rows). Both views now union the task-based results with all non-draft submissions for forms the user can review, matching the behaviour of My Submissions.

## [0.37.0] - 2026-03-26

### Added
- **`reviewer_groups` permission level on `FormDefinition`** — a new M2M field that grants named groups read-only access to all submissions and their full approval history for a form, without the management capabilities of `admin_groups`.
  - Members of a `reviewer_groups` group will see all submitted/pending/approved/rejected/withdrawn submissions for that form under **My Submissions** (alongside their own), so they can navigate to them without needing a direct URL.
  - The full approval history is always visible to reviewers even when `hide_approval_history` is enabled on the workflow (matching the behaviour for approvers and admins).
  - Access is enforced consistently across `submission_detail`, `sub_workflow_detail`, `submission_pdf`, `bulk_export_submissions`, `bulk_export_submissions_pdf`, and the `user_can_view_submission` utility.
  - The field is exposed in Django Admin under the **Access Control** fieldset with a horizontal filter widget, and is preserved when cloning a form.
  - Migration `0064_add_reviewer_groups` adds the underlying join table.

## [0.36.5] - 2026-03-26

### Fixed
- **`email_to_field` / `email_cc_field` now support comma-separated addresses** — `EmailActionHandler._get_recipients` and `_get_cc_list` previously appended the raw field value as a single address, silently discarding all but the first recipient when multiple addresses were entered. Both methods now split on commas and validate each address individually, so a faculty-emails field with `prof1@sjcme.edu, prof2@sjcme.edu` correctly delivers to all listed recipients.

## [0.36.4] - 2026-03-26

### Added
- **Dynamic dropdown choices from database** — select, multiselect, multiselect_list, radio, and checkboxes fields can now have their options populated live from any SQL query defined in `FORMS_WORKFLOWS_DATABASE_QUERIES`. Mark a query with `"return_choices": True` (and no user parameter) to return multiple rows; each row's first column becomes the option value and the second column (if present) becomes the display label. Wire it up by pointing the field's PrefillSource at the query key — the stored `choices` JSON is used as a fallback if the DB is unavailable.
- `DatabaseDataSource.execute_choices_query(query_key)` — new method that executes a choices query without a user parameter and returns `[(value, label), ...]`.
- `_get_choices_from_prefill_source(field_def)` — new helper on both form classes that detects `return_choices` queries and calls `execute_choices_query`; returns `None` when not applicable so callers fall back to stored choices.
- `execute_custom_query` now warns and returns `None` if called on a `return_choices` query, preventing accidental single-value use.

## [0.36.3] - 2026-03-26

### Fixed
- **Cross-instance sync missing newer fields** — `sync_api.serialize_form` and `_serialize_field` were not including several fields added after the serializer was first written, meaning push/pull/diff silently dropped their values on the receiving instance:
  - `FormDefinition.allow_batch_import` (spreadsheet/Excel batch upload toggle, migration 0062)
  - `FormDefinition.is_listed` (hide-from-list-page flag, migration 0051)
  - `FormDefinition.allow_resubmit` (re-submission from rejected/withdrawn, migration 0024)
  - `FormDefinition.api_enabled` (REST API exposure flag, migration 0063)
  - `FormField.formula` (formula expression for Calculated field types, migration 0056)
  All five fields are now serialized on export and restored on import. The diff summary in `diff_views._build_summary` is also updated to detect changes to all four FormDefinition flags.

## [0.33.1] - 2026-03-23

### Fixed
- **Formula/calculated field causes 500 error** — `DynamicForm.__init__` never stored `initial_data` as `self.initial_data`, but `add_field` referenced `self.initial_data` when building a `calculated` field type, resulting in `AttributeError` and a 500 on any form that contains a calculated field. Fixed by adding `self.initial_data = initial_data or {}` to `__init__`.
- **File upload field type not working in approval step** — `ApprovalStepForm._create_field` had no handler for `field_type = "file"`, so file-upload fields assigned to a workflow stage silently fell through to a plain `CharField`, preventing files from being uploaded during approval. Added a proper `FileField` / `ClearableFileInput` branch (respecting `allowed_extensions`). Also fixed `get_updated_form_data` to serialize uploaded file objects to storage (via `_serialize_single_file`) before merging into the submission's `form_data` JSON, consistent with how `serialize_form_data` handles files on normal form submission.

## [0.33.0] - 2026-03-19

### Added
- **Calculated / Formula field type** (`field_type = "calculated"`) — reads a `formula` template string (e.g. `{dept_code} - {job_type}`) stored on `FormField.formula` and produces a read-only computed value. Live client-side evaluation via injected vanilla JS in `form_submit.html`; authoritative server-side re-evaluation via `_re_evaluate_calculated_fields()` called after `serialize_form_data` at submit time. Formula exposed in both `FormFieldInline` ("Choices & Defaults" fieldset) and standalone `FormFieldAdmin` ("Formula" collapsed fieldset).
- **Spreadsheet Upload field type** (`field_type = "spreadsheet"`) — accepts `.csv`, `.xls`, `.xlsx` uploads. CSV parsed with stdlib `csv`; Excel parsed with `openpyxl` (already in the `excel` optional extra). Stored in `form_data` as `{"headers": [...], "rows": [{...}, ...]}`. Available in both `DynamicForm` and `ApprovalStepForm`.
- **Migration 0056** — adds `FormField.formula` (TextField, blank, default `""`) and extends `FormField.field_type` choices to include the two new types.

### Fixed
- **File upload in approval step** — `ApprovalStepForm` was instantiated without `files=request.FILES` in the POST branch of `approve_submission`, so uploaded files were silently ignored and the field always failed validation. Fixed by passing `files=request.FILES`. Also added `enctype="multipart/form-data"` to the approval step `<form>` tag in `approve.html`.
- **Sub-workflow spawning on parent form submission** — `create_workflow_tasks` was blindly iterating every `WorkflowDefinition` attached to the form, including child/template workflows referenced by `SubWorkflowDefinition.sub_workflow`. Those are now excluded via the existing `used_as_sub_workflow` reverse relation (`not w.used_as_sub_workflow.exists()`), so sub-workflow templates only activate through the controlled `_spawn_sub_workflows_for_trigger` path and never auto-start at submission time. No model or migration change needed.

## [0.32.1] - 2026-03-17

### Fixed
- **`FormFieldAdmin` missing `readonly` field** — the standalone FormField admin page (`/admin/django_forms_workflows/formfield/`) did not expose the `readonly` flag. Added `readonly` alongside `required` in the "Field Configuration" fieldset, added it to `list_display`, and added it to `list_filter`. It was already present in `FormFieldInline` (when editing fields inline from the parent FormDefinition page).

## [0.32.0] - 2026-03-17

### Added
- **Send Back for Correction** — a new third decision path on the approval screen that returns a staged workflow to any prior stage without terminating the submission.
  - `WorkflowStage.allow_send_back` (`BooleanField`, default `False`) — opt-in per stage via Django Admin; only stages with this flag enabled appear as send-back targets for downstream approvers.
  - `ApprovalTask.status` extended with `"returned"` (Returned for Correction) — records the closed task without triggering rejection hooks.
  - `AuditLog.action` extended with `"send_back"` — full audit trail entry written on every send-back with target stage name and reason.
  - `handle_send_back(submission, task, target_stage)` in `workflow_engine.py` — cancels sibling pending tasks at the current stage, re-creates tasks at the target stage via the existing `_create_stage_tasks` helper; `FormSubmission.status` remains `pending_approval` throughout.
  - `handle_sub_workflow_send_back(task, target_stage)` — identical logic scoped to a `SubWorkflowInstance` using `_create_sub_workflow_stage_tasks`.
  - `approve_submission` view updated to accept `decision=send_back`; validates target stage belongs to the same workflow, has a lower `order`, and that a non-empty reason was supplied.
  - `approve.html` — collapsible **Send Back for Correction** card (Bootstrap warning colour, collapsed by default) injected after the main decision buttons in both the step-fields and standard approval forms; hidden when no prior `allow_send_back` stages exist.
  - Migration `0055_add_send_back` covering all model changes above.

## [0.14.12] - 2026-03-06

### Fixed
- **Column picker (cog wheel) completely broken on approval inbox & approval history** — v0.14.9 moved column hiding to `columnDefs` at DataTables init time, but `colIndexMap` was still built AFTER init by querying `$('th.extra-form-col')`. DataTables removes hidden `<th>` elements from the DOM, so the selector found nothing and `colIndexMap` was empty — making select/deselect all and individual checkbox toggles no-ops. Fixed by building `colIndexMap` BEFORE DataTables init.
- **Horizontal scrollbar caused by column picker dropdown** — the `d-none` class was removed from the out-of-grid `#colPickerDropdown` element before it was moved into `#searchContainer`, causing a brief layout overflow. Now `d-none` is removed only after the element is repositioned.
- **XLSX export spinner stays forever (project base.html)** — the project's `templates/base.html` override was missing the `data-no-spinner` check added to the package base in v0.14.9. Added `form.hasAttribute('data-no-spinner')` guard.
- **Package base.html `data-no-spinner` check was ineffective** — `form.dataset.noSpinner` returns `""` (empty string, falsy) for a valueless attribute. Changed to `form.hasAttribute('data-no-spinner')` which correctly returns `true`.

## [0.14.10] - 2026-03-06

### Changed
- **PDF engine switched from xhtml2pdf to WeasyPrint** — WeasyPrint has full CSS3 support (including `table-layout: fixed`, `colgroup` column widths, `:nth-child` selectors, and CSS Paged Media `@page` margin boxes) making multi-column form layouts render correctly without colspan hacks.
  - `pyproject.toml` / `requirements.txt`: `xhtml2pdf>=0.2.11` → `weasyprint>=60.0`
  - `Dockerfile`: added `libpango-1.0-0`, `libpangoft2-1.0-0`, `libgdk-pixbuf2.0-0`, `libffi-dev`, `shared-mime-info` (WeasyPrint OS-level dependencies; `libcairo2-dev` was already present)
  - `views.py`: `pisa.CreatePDF()` replaced with `HTML(string=..., base_url=...).write_pdf()`
  - `submission_pdf.html`: completely rewritten — 4-column `<colgroup>` (`col-label 22%` / `col-value 28%` × 2) with `table-layout: fixed`; all row types (section, full, pair, triple) use the same 4-column grid via `colspan`; alternating row tint via `tr:nth-child(even)`; running page footer (`Page N of M · date`) via `@page @bottom-left/@bottom-right` — no more HTML footer table

## [0.14.9] - 2026-03-06

### Fixed
- **Approval inbox column picker — columns not toggling / table layout broken** — `DataTables.column(jQueryObject)` does not reliably resolve column indices once columns have been hidden or shown. Replaced the jQuery-wrapper approach with a `colIndexMap` dictionary built at DataTable init time using `table.column(rawDOMNode).index()`. All subsequent visibility calls now use the stable integer index, fixing both the picker not working and the resulting spaced-out table.
- **Bulk export spinner never dismissed** — the base template's `form[method="post"]` submit handler unconditionally activated the loading overlay, but file-download responses do not navigate the page so the overlay was never cleared. Added a `data-no-spinner` attribute check: forms that carry this attribute skip the overlay entirely. Both `#bulkExportForm` instances (`completed_approvals.html`, `my_submissions.html`) now include `data-no-spinner`.

### Notes
- Multi-form-type bulk export already produces one Excel sheet per form definition (server-side grouping by `form_definition` was in place from the initial implementation). No change needed.

## [0.14.8] - 2026-03-06

### Added
- **PDF field-width layout** — Generated PDFs now respect the `width` setting configured on each `FormField`:
  - `half` — consecutive half-width fields are grouped into side-by-side pairs within a single table row, matching the two-column layout seen on screen.
  - `third` — consecutive third-width fields (groups of three) are rendered side-by-side in a three-column row.
  - `full` — rendered as a standard single-field row spanning the full table width (unchanged behaviour).
  - Lone half or partial third groups (odd-count sequences) fall back gracefully to full-width rows.
- **PDF section headers** — `section` type fields now appear as bold dark-blue header rows in the PDF (they were previously omitted entirely).

### Changed
- `_build_pdf_rows()` helper added to `views.py` — walks all form fields (including sections) and groups them by width into structured row dicts passed to `submission_pdf.html`.
- `submission_pdf.html` — replaced the flat two-column table with a flexible six-column table that handles `section`, `full`, `pair`, and `triple` row types.

## [0.14.7] - 2026-03-06

### Fixed
- **Approval History — "Awaiting Co-Approver" badge** — submissions that are still `pending_approval` (waiting on a second approver) but where the current user has already completed their step now show a clear yellow "Awaiting Co-Approver" badge instead of falling through to the raw `pending_approval` string.
- **Tab label renamed** — "Completed Forms" tab renamed to "Approval History" in both `approval_inbox.html` and `completed_approvals.html` to accurately reflect that the page shows all forms the user has acted on, including those still awaiting other approvers.

## [0.14.6] - 2026-03-06

### Fixed
- **Approval inbox column picker — columns visible by default** — `DataTables` `columnDefs.targets` does not accept CSS class selectors, so the `{ visible: false, targets: '.extra-form-col' }` entry was silently ignored and all extra columns rendered visible on load. Extra columns are now hidden explicitly via `table.column().visible(false)` immediately after DataTables initialisation, before saved preferences are restored.
- **Column picker — added Select all / Deselect all** — a toggle link in the column-picker dropdown checks or unchecks all field checkboxes at once, shows/hides the corresponding DataTables columns, persists the result to `localStorage`, and updates its own label to reflect the current state.

## [0.14.5] - 2026-03-06

### Fixed
- **Approvals nav link visibility** — the *Approvals* link in the navbar is now only rendered for users who have an approver role (i.e. they or one of their groups has ever been assigned an `ApprovalTask`). Staff and superusers always see it. A new `user_is_approver` boolean is added to the template context via the `forms_workflows` context processor.
- **Completed approvals missing mid-workflow steps** — `completed_approvals` previously filtered on `FormSubmission.status IN ('approved','rejected','withdrawn')`, which hid submissions that were still in progress (e.g. waiting for a later approval stage). The view now filters on `ApprovalTask.status IN ('approved','rejected')` scoped to the requesting user/groups, so an approver can see every submission where they have already taken action — even if subsequent stages are still pending.

## [0.14.4] - 2026-03-06

### Fixed
- **Security: form submission bypassed category permissions** — `user_can_submit_form` now enforces the full category `allowed_groups` ancestor-chain check (matching the `form_list` view logic). Previously, any authenticated user who knew a form's URL slug could submit it even if the form's category restricted access to specific groups. Both `form_submit` and `form_auto_save` benefit automatically since they both call `user_can_submit_form`.
- Added `user_can_access_category` helper to `utils.py` for reusable, hierarchy-aware category access checks.

## [0.14.3] - 2026-03-06

### Added
- **Approval inbox column picker** — when the approvals queue is filtered down to a specific form, a gear icon (⚙) appears next to the search box. Clicking it opens a dropdown listing every field from that form's definition (sections and file-upload fields excluded). Checking a field adds it as a column to the table; unchecking removes it. Selected columns are remembered per-form in `localStorage` (`approvals_col_prefs_<form-slug>`) so preferences survive page reloads.

## [0.13.11] - 2026-02-24

### Fixed
- **Pull from Remote admin UI** — the form-selection table (Step 1) was showing blank Name, Slug, and Category columns for all remote forms. The template was reading `form.slug` / `form.name` / `form.category` directly from the serialized payload dict, but those fields are nested one level deeper at `form.form.slug`, `form.form.name`, and `form.category.name` respectively. The checkbox `value` attribute was also sending an empty string instead of the slug, so confirming the import would have silently imported nothing. All four references corrected in `sync_pull.html`.

### Added
- **Cross-instance form sync (push/pull)** — export and import `FormDefinition` records (including all fields, workflow, prefill sources, and post-submission actions) between multiple Django instances without shell access.
  - `sync_api.py` — serialization/deserialization core; forms are keyed by slug, groups by name for portability across instances.
  - `sync_views.py` — HTTP endpoints `GET /forms-sync/export/` and `POST /forms-sync/import/` protected by a shared `Bearer` token (`FORMS_SYNC_API_TOKEN`).
  - Management commands `pull_forms` and `push_forms` for CLI/scripted sync.
  - **Admin UI — Pull from Remote** (`/admin/.../formdefinition/sync-pull/`) — multi-step page: pick a configured remote from a dropdown (or enter URL + token manually), preview available forms with checkboxes, import selected forms with conflict-mode control.
  - **Admin UI — Push to Remote** (`/admin/.../formdefinition/sync-push/`) — accessible via the *"Push selected forms to a remote instance"* bulk action; shows forms to push, lets you pick the destination remote, and displays per-form results.
  - **Admin UI — Import JSON** (`/admin/.../formdefinition/sync-import/`) — upload a `.json` file or paste raw JSON; supports `update`, `skip`, and `new_slug` conflict modes.
  - **Admin action — Export as JSON** — downloads selected forms as a `.json` file directly from the changelist.
  - **Form Definitions changelist toolbar** now includes *↓ Pull from Remote*, *↑ Push All to Remote*, and *⤴ Import JSON* shortcut buttons.
  - New settings:
    - `FORMS_SYNC_API_TOKEN` — shared secret protecting the sync HTTP endpoints.
    - `FORMS_SYNC_REMOTES` — named list of remote instances with URL and token, enabling dropdown selection in the admin UI (ideal for Kubernetes deployments where kubectl exec is impractical).

## [0.13.4] - 2026-02-21

### Changed
- **Improved table UI layout** — moved search bar inline with filter row on both `completed_approvals.html` and `my_submissions.html` for a cleaner, more compact layout
- **Page length selector relocated** — moved the "Show X entries" dropdown from the top to the bottom of tables, positioned next to pagination controls for better UX
- **Enhanced form element styling** — improved visual design of search inputs (with icon), page length selectors, and pagination controls with better focus states and consistent Bootstrap styling

## [0.13.3] - 2026-02-21

### Added
- **DataTables on all approvals views** — `my_submissions.html`, `approval_inbox.html`, and `completed_approvals.html` now all include DataTables (Bootstrap 5 theme) for instant client-side search and column sorting. The *Actions* column is excluded from sorting; tables default to descending *Submitted* date order.
- **Cross-tab counts** — Both the *Pending* and *Completed Forms* tabs in the Approval Inbox always show a count badge so approvers can see the total in each view without switching tabs.

## [0.13.2] - 2026-02-21

### Added
- **Sortable, searchable table views** — the Submissions (`my_submissions.html`) and Approval Inbox (`approval_inbox.html`) tables now use DataTables (Bootstrap 5 theme) to provide instant client-side search filtering and click-to-sort on every column. Tables default to descending sort by the *Submitted* date; the *Actions* column is excluded from sorting.

## [0.13.1] - 2026-02-20

### Fixed
- **Category hierarchy permission inheritance** — sub-categories with no `allowed_groups` of their own now correctly inherit the restriction of the nearest ancestor that has groups set. Previously, `category_group_count=0` caused child categories (e.g. On-Campus, Online) to bypass the parent's `allowed_groups` restriction entirely. The `form_list` view now uses `_get_accessible_category_pks()` which walks the full ancestor chain.

## [0.13.0] - 2026-02-20

### Added
- **Nested `FormCategory` hierarchy** — `FormCategory` now has a nullable self-referential `parent` FK (`SET_NULL` on delete), enabling arbitrary category nesting for more granular organisation and access control
- **`FormCategory.get_ancestors()`** — returns the ordered list of ancestor categories from root to direct parent; useful for breadcrumbs and permission checks
- **`FormCategory.full_path()`** — returns a `" > "`-separated string of the full category path (e.g. `"HR > Benefits > Leave Requests"`)
- **Migration `0018_add_form_category_parent`** — adds `parent_id` column using the safe `IF NOT EXISTS` SQL pattern; fully backward-compatible, existing flat categories remain top-level
- **Hierarchical form-list UI** — `_build_grouped_forms()` now produces a category-tree structure; sub-categories are rendered as nested Bootstrap accordions inside their parent section using the new `_category_node.html` recursive partial
- **Admin hierarchy support** — `FormCategoryAdmin` now exposes a **Hierarchy** fieldset with `parent` (via `autocomplete_fields`), `parent` in `list_display`, and `list_filter` by parent category

## [0.9.0] - 2026-02-20

### Added
- **Staged / hybrid approval workflows** — `WorkflowDefinition` now supports an ordered set of `WorkflowStage` rows; each stage has its own `approval_logic` (`all` / `any` / `sequence`) and its own set of `approval_groups`, enabling multi-stage pipelines where each stage can use a different parallel or sequential strategy (e.g. Stage 1: any department head, Stage 2: all directors)
- **`WorkflowStage` model** — new model with fields `name`, `order`, `approval_logic`, `approval_groups` (M2M), `requires_manager_approval`; stages are processed strictly in `order` ascending
- **`ApprovalTask.workflow_stage` / `stage_number`** — new FK and denormalised integer on `ApprovalTask` so tasks carry their stage reference even after a stage is later edited
- **Migration 0015** — `add_workflowstage_staged_approvals`; fully backward-compatible, existing workflows without stages continue to use the legacy flat mode
- **Stage-aware approval engine** — `workflow_engine.py` rewritten with helpers `_create_stage_tasks()` and `_advance_to_next_stage()`; when all tasks for a stage satisfy the stage's `approval_logic` the engine automatically creates tasks for the next stage
- **`WorkflowStageInline` in admin** — stages are editable directly on the `WorkflowDefinition` change page with a `filter_horizontal` widget for `approval_groups`
- **Stage context in `approve_submission` view** — `workflow_mode` (`"staged"` / `"sequence"` / `"all"` / `"any"` / `"none"`), `approval_stages`, `current_stage_number`, and `total_stages` are now passed to `approve.html`
- **Stage-grouped approval history in `submission_detail`** — when a submission has staged tasks the Approval History section renders one colour-coded card per stage showing the stage name, approval logic badge, `X/N approved` counter, and a task table; legacy flat-table display is kept for non-staged workflows
- **Site name in all email templates** — all six email templates now use `{{ site_name }}` (sourced from `FORMS_WORKFLOWS['SITE_NAME']` in settings) instead of the hardcoded string "Django Forms Workflows"
- **Stage context in approval-request emails** — `approval_request.html` shows stage name, stage progress (`Stage N of M`), approval logic, and total parallel approver count when the task belongs to a stage
- **Improved email templates** — `approval_reminder.html` and `escalation_notification.html` reworked with structured `<table>` layouts; all templates render URLs as clickable links

### Fixed
- **`"any"`-mode rejection bug** — in `"any"` approval-logic mode a single rejection no longer immediately rejects the whole submission; the submission is only rejected when every task in scope has been acted on and none approved
- **Rejection handling in views** — duplicate inline rejection code in `approve_submission` replaced with a single call to `workflow_engine.handle_rejection()`

## [0.8.5] - 2026-02-19

### Fixed
- **Presigned file URL expiry** — file URLs in submission detail and approval pages were expiring after 1 hour because presigned S3/DigitalOcean Spaces URLs were being generated at upload time and stored permanently in the `form_data` JSON field in the database.  URLs are no longer persisted; instead, a new `_resolve_form_data_urls()` helper generates fresh presigned URLs on every view render so files are always accessible regardless of how long ago they were uploaded.

### Changed
- `serialize_form_data()` no longer stores a `url` key in file-upload entries — only `filename`, `path`, `size`, and `content_type` are persisted.  This is a **data-format change**: existing database records that contain a stale `url` key are handled correctly because the views now always regenerate the URL from the stored `path`.

## [0.8.4] - 2026-02-19

### Added
- **Configurable site name** — deployers can set `FORMS_WORKFLOWS = {'SITE_NAME': 'My Org Workflows'}` in Django settings to replace the default "Django Forms Workflows" brand across all page titles, the navbar brand, and the footer copyright line
- **Context processor** — `django_forms_workflows.context_processors.forms_workflows` injects `site_name` into every template context; add it to `TEMPLATES['OPTIONS']['context_processors']` in your settings to enable custom branding
- **Rich approval inbox template** — the generic `approval_inbox.html` is now feature-complete: category filter bar with counts and icons, form-level drill-down bar (indented, only visible when a category is active), dynamic page header showing task count and `Category › Form` breadcrumb, a Category column in the table (hidden when filtering by category), and context-aware empty-state messages

## [0.8.3] - 2026-02-19

### Added
- **Form name search on the landing page** — `form_list` view accepts `?q=<text>` to filter the visible forms by name (case-insensitive); a search box with a clear button is rendered in the page header alongside the heading; result count is shown when a query is active
- **Form-level drill-down on submissions page** — when a category filter is active on `my_submissions`, a second pill bar appears (indented under the category bar) listing every form the user has submissions for within that category; selecting a pill appends `&form=<slug>` to the URL and narrows the table to that form; the page header shows `Category › Form` breadcrumb text and a targeted clear link
- **Form-level drill-down on approval inbox** — same drill-down behaviour as submissions: after selecting a category, a form pill bar appears so approvers can focus on a single form's queue; context variables `form_counts`, `form_slug`, and `active_form` are passed to the template

## [0.8.2] - 2026-02-19

### Added
- **Category-aware submissions page** — `my_submissions` view now accepts `?category=<slug>` query parameter to filter the submission table to a single form category; template context includes `category_counts`, `active_category`, `category_slug`, and `total_submissions_count` for rendering a filter-pill bar with per-category submission counts
- **Category column in submissions table** — the submissions table now shows the form category (icon + name) for each row; the column is hidden when a category filter is active since it would be redundant

## [0.8.1] - 2026-02-19

### Fixed
- **`form_categories.html`** — replaced multiline `{# ... #}` comment (Django only supports single-line `{#}` comments) with `{% comment %}...{% endcomment %}` tags to prevent the comment block from rendering as raw text on the page

## [0.8.0] - 2026-02-19

### Added
- **FormCategory model** — new `FormCategory` grouping primitive with `name`, `slug`, `description`, `order`, `icon`, `is_collapsed_by_default`, and `allowed_groups` (M2M) fields; migration `0014_add_form_category`
- **Category-grouped form list** — `form_list` view now passes `grouped_forms` (ordered list of `(FormCategory | None, [FormDefinition, ...])` tuples) and enforces category-level `allowed_groups` access control for non-staff users; new `form_categories.html` template
- **Category-aware approval inbox** — `approval_inbox` view accepts `?category=<slug>` query parameter to filter the task table to a single category; template context now includes `category_counts`, `active_category`, `category_slug`, and `total_tasks_count` for rendering a filter-pill bar with per-category pending counts
- **`forms_workflows_tags` templatetag additions** — new tags supporting the grouped form list and category header rendering

### Planned Features
- Form builder UI (drag-and-drop)
- REST API for form submission
- Webhook support
- Custom field types (signature, location, etc.)
- Advanced reporting and analytics
- Multi-tenancy support

## [0.5.5] - 2026-01-18

### Added
- **Multi-Column Database Prefill Templates**
  - Added `db_columns` (JSONField) and `db_template` (CharField) to PrefillSource model
  - Allows combining multiple database columns into a single prefill value
  - Example: `db_columns=["FIRST_NAME", "LAST_NAME"]`, `db_template="{FIRST_NAME} {LAST_NAME}"` produces "John Smith"
  - New `DatabaseDataSource.get_template_value()` method for template-based lookups
  - Migration `0010_add_prefillsource_template_fields`

## [0.5.4] - 2026-01-18

### Fixed
- **Database Prefill User Field Lookup**
  - Fixed `DatabaseDataSource._get_user_id()` to first check direct user attributes (e.g., `username`, `email`) before checking the user profile
  - This allows database prefill to use `user.username` for lookup when `db_user_field` is set to `username`

## [0.5.3] - 2026-01-18

### Added
- **Readonly Form Fields**
  - Added `readonly` boolean field to FormField model
  - Readonly fields are rendered with disabled styling and cannot be modified by users
  - Migration `0009_add_formfield_readonly` adds the new field

## [0.4.1] - 2025-11-11

### Added
- **Configurable LDAP TLS Certificate Verification**
  - Added `configure_ldap_connection()` helper function in `ldap_backend.py`
  - Support for `LDAP_TLS_REQUIRE_CERT` environment variable with options: `never`, `allow`, `try`, `demand` (default)
  - Updated all LDAP connection initialization points to use configurable TLS settings
  - Added `_configure_ldap_connection()` helper in `ldap_handler.py` with fallback implementation

### Changed
- **LDAP Backend Improvements**
  - All LDAP connections now respect the `LDAP_TLS_REQUIRE_CERT` environment variable
  - Updated `get_user_manager()`, `search_ldap_users()`, and `get_ldap_user_attributes()` functions
  - Updated `LDAPUpdateHandler` to use configurable TLS settings

### Documentation
- Added `LDAP_TLS_CONFIGURATION.md` with comprehensive documentation on TLS configuration options
- Documented security considerations for different TLS verification levels
- Added deployment instructions for Kubernetes environments

## [0.4.0] - 2025-11-06

### Added - Enterprise Integration Features
- **Enhanced UserProfile Model**
  - Added `ldap_last_sync` timestamp field for tracking LDAP synchronization
  - Added database indexes to `employee_id` and `external_id` fields for better performance
  - Added `id_number` property as backward-compatible alias for `employee_id`
  - Added `full_name` and `display_name` properties for convenient user display
  - Enhanced help text for LDAP attribute fields

- **LDAP Integration Enhancements**
  - New `signals.py` module with automatic LDAP attribute synchronization
  - `sync_ldap_attributes()` function for syncing LDAP data to UserProfile
  - `get_ldap_attribute()` helper function for retrieving LDAP attributes
  - Auto-sync on user login (configurable via `FORMS_WORKFLOWS['LDAP_SYNC']`)
  - Signal handlers for automatic UserProfile creation on user creation
  - Configurable LDAP attribute mappings in settings

- **Database Introspection Utilities**
  - `DatabaseDataSource.test_connection()` - Test external database connections
  - `DatabaseDataSource.get_available_tables()` - List tables in a schema
  - `DatabaseDataSource.get_table_columns()` - Get column information for a table
  - Support for SQL Server, PostgreSQL, MySQL, and SQLite introspection

- **Utility Functions**
  - `get_user_manager()` - Get user's manager from LDAP or UserProfile
  - `user_can_view_form()` - Check if user can view a form
  - `user_can_view_submission()` - Check if user can view a submission
  - `check_escalation_needed()` - Check if submission needs escalation
  - `sync_ldap_groups()` - Synchronize LDAP groups to Django groups

- **Management Commands**
  - `sync_ldap_profiles` - Bulk sync LDAP attributes for all users
    - Supports `--username` for single user sync
    - Supports `--dry-run` for testing without changes
    - Supports `--verbose` for detailed output
  - `test_db_connection` - Test external database connections
    - Supports `--database` to specify database alias
    - Supports `--verbose` for detailed connection information
    - Works with SQL Server, PostgreSQL, MySQL, and SQLite

### Changed
- Updated version to 0.4.0 to reflect significant new features
- Enhanced UserProfile model with LDAP-specific fields and properties
- Improved database source with introspection capabilities
- Expanded utility functions for better LDAP and permission handling

### Migration Notes
- Run `python manage.py migrate django_forms_workflows` to apply UserProfile enhancements
- Configure LDAP sync in settings:
  ```python
  FORMS_WORKFLOWS = {
      'LDAP_SYNC': {
          'enabled': True,
          'sync_on_login': True,
          'attributes': {
              'employee_id': 'extensionAttribute1',
              'department': 'department',
              'title': 'title',
              'phone': 'telephoneNumber',
              'manager_dn': 'manager',
          }
      }
  }
  ```
- Use `python manage.py sync_ldap_profiles` to bulk sync existing users

## [0.2.2] - 2025-10-31

### Changed
- **Code Quality Improvements**
  - Migrated from Black to Ruff for code formatting and linting
  - Fixed all import ordering and type annotation issues
  - Added comprehensive ruff.toml configuration
  - Updated CI workflow to use Ruff instead of Black/isort/flake8
  - Improved LDAP availability checks using importlib.util.find_spec

### Fixed
- Removed all references to "Campus Cafe" from codebase and documentation
- Updated example database references to use generic "hr_database" naming
- Cleaned up unused imports in LDAP handlers

## [0.2.1] - 2025-10-31

### Fixed
- Corrected author email in package metadata from `opensource@opensensor.ai` to `matt@opensensor.io`

## [0.2.0] - 2025-10-31

### Added - Configurable Prefill Sources
- **PrefillSource Model** - Database-driven prefill source configuration
  - Support for User, LDAP, Database, API, System, and Custom source types
  - Flexible database field mapping with configurable lookup fields
  - Custom user field mapping (employee_id, email, external_id, etc.)
  - Active/inactive toggle and display ordering
  - Backward compatible with legacy text-based prefill_source field
- **Enhanced Database Prefill** - Generic database lookups with custom field mappings
  - Configurable DB lookup field (ID_NUMBER, EMAIL, EMPLOYEE_ID, etc.)
  - Configurable user profile field for matching
  - Makes library truly generic and adaptable to different deployments
- **Admin Interface** - Comprehensive admin for managing prefill sources
  - Dropdown selection of prefill sources in FormField admin
  - Inline editing and filtering
  - Helpful descriptions and examples
- **Demo Integration** - Farm-themed demo showcasing prefill functionality
  - "Farmer Contact Update" form with multiple prefill sources
  - Seed command for creating demo prefill sources
  - Examples of User, System, and Database prefill types

### Added - Post-Submission Actions
- **PostSubmissionAction Model** - Configurable actions to update external systems
  - Support for Database, LDAP, API, and Custom handler action types
  - Four trigger types: on_submit, on_approve, on_reject, on_complete
  - Flexible field mapping for all action types
  - Conditional execution based on form field values
  - Robust error handling with retries and fail-silently options
  - Execution ordering for dependent actions
- **Database Update Handler** - Update external databases after form submission/approval
  - Custom field mappings from form fields to database columns
  - Configurable lookup fields and user fields
  - SQL injection protection with parameterized queries
  - Identifier validation for table and column names
- **LDAP Update Handler** - Update Active Directory attributes
  - DN template support with placeholders
  - Field mapping from form fields to LDAP attributes
  - Service account integration
- **API Call Handler** - Make HTTP API calls to external services
  - Support for GET, POST, PUT, PATCH methods
  - Template-based request bodies with field placeholders
  - Custom headers support
  - Response validation
- **Custom Handler Support** - Execute custom Python code for complex integrations
  - Dynamic handler loading via import_module
  - Configurable handler parameters
  - Standardized return format
- **Action Executor** - Coordinates execution of multiple actions
  - Filters actions by trigger type
  - Implements retry logic with configurable max attempts
  - Comprehensive error handling and logging
  - Conditional execution based on form field values
- **Workflow Integration** - Integrated with all workflow trigger points
  - on_submit trigger in create_workflow_tasks()
  - on_approve trigger in execute_post_approval_updates()
  - on_reject trigger in approve_submission view
  - on_complete trigger in _finalize_submission()
- **Admin Interface** - Comprehensive admin for managing post-submission actions
  - Collapsible fieldsets for each action type
  - List view with filtering and inline editing
  - Helpful descriptions and examples
- **Demo Integration** - Farm demo showcasing post-submission actions
  - API call action logging to httpbin.org
  - Database update action example
  - Both disabled by default for safety

### Enhanced
- **Documentation** - Comprehensive guides for new features
  - `docs/PREFILL_SOURCES.md` - Complete prefill configuration guide
  - `docs/POST_SUBMISSION_ACTIONS.md` - Complete post-submission actions guide
  - `PREFILL_ENHANCEMENTS.md` - Technical summary of prefill enhancements
  - `POST_SUBMISSION_ENHANCEMENTS.md` - Technical summary of post-submission enhancements
  - Updated README.md with new features
- **Farm Demo** - Enhanced example application
  - Showcases both prefill and post-submission actions
  - Multiple demo forms with different workflow types
  - Seed commands for easy setup
  - Farm-themed design for better UX

### Security
- **SQL Injection Protection** - Enhanced database security
  - Parameterized queries for all database operations
  - Identifier validation for table and column names
  - Whitelist-based validation
- **LDAP Security** - Secure LDAP integration
  - DN template validation
  - Service account permissions
  - Connection encryption support
- **API Security** - Secure external API calls
  - HTTPS enforcement
  - API key management
  - Request timeout protection
  - Response validation

### Migration Notes
- Run `python manage.py migrate` to apply new migrations
- Existing forms with text-based `prefill_source` continue to work
- New `prefill_source_config` field takes precedence when set
- Post-submission actions are opt-in and disabled by default
- No breaking changes to existing deployments

## [0.1.0] - 2025-10-31

### Added
- Initial release
- Database-driven form definitions
- 15+ field types (text, select, date, file upload, etc.)
- Dynamic form rendering with Crispy Forms
- Approval workflows with flexible routing
- LDAP/Active Directory integration
- External database prefill support
- Pluggable data source architecture
- Complete audit trail
- Email notifications
- File upload support
- Conditional field visibility
- Form versioning
- Draft save functionality
- Withdrawal support
- Group-based permissions
- Manager approval from LDAP hierarchy
- Conditional escalation
- Post-approval database updates
- Comprehensive documentation
- Example project

### Security
- CSRF protection
- SQL injection prevention
- File upload validation
- Parameterized database queries
- Identifier validation for SQL

### Dependencies
- Django >= 5.1
- django-crispy-forms >= 2.0
- crispy-bootstrap5 >= 2.0
- celery >= 5.3
- python-decouple >= 3.8

### Optional Dependencies
- django-auth-ldap >= 4.6 (for LDAP integration)
- python-ldap >= 3.4 (for LDAP integration)
- mssql-django >= 1.6 (for MS SQL Server)
- pyodbc >= 5.0 (for MS SQL Server)
- psycopg2-binary >= 2.9 (for PostgreSQL)
- mysqlclient >= 2.2 (for MySQL)

[Unreleased]: https://github.com/opensensor/django-forms-workflows/compare/v0.2.2...HEAD
[0.2.2]: https://github.com/opensensor/django-forms-workflows/compare/v0.2.1...v0.2.2
[0.2.1]: https://github.com/opensensor/django-forms-workflows/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/opensensor/django-forms-workflows/compare/v0.1.0...v0.2.0
[0.1.0]: https://github.com/opensensor/django-forms-workflows/releases/tag/v0.1.0

