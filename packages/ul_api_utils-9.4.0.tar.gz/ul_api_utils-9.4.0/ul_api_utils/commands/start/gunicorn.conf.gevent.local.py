from gevent import monkey  # isort: skip  # noqa: E402

monkey.patch_all()

try:
    from psycogreen.gevent import patch_psycopg

    patch_psycopg()
except ImportError:
    pass
