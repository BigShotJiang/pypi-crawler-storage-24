"""
AorusAPI SDK — Drop-in replacement del SDK de SignalWire.

CREDENCIALES (las obtienes del dashboard en https://app.aorusapi.com):
  space_url  = "app.aorusapi.com"
  project_id = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
  api_token  = "PTxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"

USO — idéntico al SDK oficial de SignalWire:

  ANTES (SignalWire original):
    from signalwire.rest import Client
    client = Client(project_id, api_token, signalwire_space_url=space_url)

  AHORA (AorusAPI):
    from aorusapi.rest import Client
    client = Client(project_id, api_token, signalwire_space_url=space_url)

  El resto del código NO cambia.
"""
from __future__ import annotations

import logging
import requests
from typing import Optional

logger = logging.getLogger("aorusapi.http_client")


class _CallsResource:
    """Imita el objeto client.calls del SDK."""

    def __init__(self, base_url: str, auth: tuple):
        self._base = base_url
        self._auth = auth

    def create(
        self,
        to: str,
        from_: str,
        url: str,
        method: str = "POST",
        timeout: int = 28,
        record: bool = False,
        status_callback: Optional[str] = None,
        status_callback_method: str = "POST",
        status_callback_event: Optional[list] = None,
        recording_status_callback: Optional[str] = None,
        recording_status_callback_method: str = "POST",
        machine_detection: Optional[str] = None,
        machine_detection_timeout: int = 30,
        async_amd: bool = False,
        async_amd_status_callback: Optional[str] = None,
    ) -> "_CallInstance":
        """
        Idéntico a signalwire_client.calls.create(...)
        """
        data = {
            "To":     to,
            "From":   from_,
            "Url":    url,
            "Method": method,
            "Timeout": str(timeout),
            "Record": "true" if record else "false",
            "StatusCallbackMethod":          status_callback_method,
            "RecordingStatusCallbackMethod": recording_status_callback_method,
        }

        if status_callback:
            data["StatusCallback"] = status_callback

        if status_callback_event:
            data["StatusCallbackEvent"] = " ".join(status_callback_event)

        if recording_status_callback:
            data["RecordingStatusCallback"] = recording_status_callback

        if machine_detection:
            data["MachineDetection"] = machine_detection
            data["MachineDetectionTimeout"] = str(machine_detection_timeout)

        if async_amd:
            data["AsyncAmd"] = "true"
        if async_amd_status_callback:
            data["AsyncAmdStatusCallback"] = async_amd_status_callback

        endpoint = f"{self._base}/Calls.json"

        logger.info("POST Request: %s", endpoint)
        logger.info("PAYLOAD: %s", data)

        r = requests.post(endpoint, auth=self._auth, data=data, timeout=30)

        r.raise_for_status()

        logger.info("POST Response: %s %s", r.status_code, r.text)

        instance = _CallInstance(r.json())
        return instance

    def list(self, status: Optional[str] = None, limit: int = 50) -> list:
        params = {"PageSize": limit}
        if status:
            params["Status"] = status
        r = requests.get(f"{self._base}/Calls.json", auth=self._auth, params=params, timeout=10)
        r.raise_for_status()
        return [_CallInstance(c) for c in r.json().get("calls", [])]

    def __call__(self, call_sid: str) -> "_CallContext":
        return _CallContext(self._base, self._auth, call_sid)


class _CallContext:
    """Imita client.calls('CAxxxxx')"""

    def __init__(self, base_url: str, auth: tuple, call_sid: str):
        self._base = base_url
        self._auth = auth
        self._sid  = call_sid

    def fetch(self) -> "_CallInstance":
        r = requests.get(f"{self._base}/Calls/{self._sid}.json", auth=self._auth, timeout=10)
        r.raise_for_status()
        return _CallInstance(r.json())

    def update(self, status: Optional[str] = None, url: Optional[str] = None) -> "_CallInstance":
        data = {}
        if status:
            data["Status"] = status
        if url:
            data["Url"] = url
        r = requests.post(f"{self._base}/Calls/{self._sid}.json", auth=self._auth, data=data, timeout=10)
        r.raise_for_status()
        return _CallInstance(r.json())


class _CallInstance:
    """
    Objeto retornado por calls.create() / fetch().
    Imita el objeto del SDK: call.sid, call.status, etc.
    """

    def __init__(self, data: dict):
        self._data        = data
        self.sid          = data.get("sid", "")
        self.status       = data.get("status", "")
        self.to           = data.get("to", "")
        self.from_        = data.get("from", "")
        self.direction    = data.get("direction", "")
        self.duration     = data.get("duration")
        self.answered_by  = data.get("answered_by")
        self.date_created = data.get("date_created")

    def __repr__(self):
        return f"<Call sid={self.sid!r} status={self.status!r}>"


class Client:
    """
    Cliente principal — reemplaza signalwire.rest.Client

    Uso:
        from aorusapi.rest import Client

        client = Client(
            project_id,
            api_token,
            signalwire_space_url="app.aorusapi.com"
        )
        call = client.calls.create(to="+1234567890", from_="+0987654321", url="https://tu-backend.com/voice")
    """

    def __init__(
        self,
        project_id: str,
        api_token: str,
        signalwire_space_url: str = "app.aorusapi.com",
    ):
        self.project_id = project_id
        self.api_token  = api_token

        # Strip protocolo si el cliente lo incluyó (https://apivoice.co → apivoice.co)
        if signalwire_space_url.startswith("https://"):
            signalwire_space_url = signalwire_space_url[len("https://"):]
            explicit_protocol = "https"
        elif signalwire_space_url.startswith("http://"):
            signalwire_space_url = signalwire_space_url[len("http://"):]
            explicit_protocol = "http"
        else:
            explicit_protocol = None

        self.space_url = signalwire_space_url

        # Misma estructura de URL que el SDK original:
        # https://{space_url}/api/laml/2010-04-01/Accounts/{project_id}
        if explicit_protocol:
            protocol = explicit_protocol
        else:
            has_port = ":" in signalwire_space_url.split("/")[-1]
            protocol = "http" if has_port else "https"

        self._base_url = (
            f"{protocol}://{signalwire_space_url}"
            f"/api/laml/2010-04-01/Accounts/{project_id}"
        )

        self._auth = (project_id, api_token)
        self.calls = _CallsResource(self._base_url, self._auth)

    def __repr__(self):
        return f"<AorusAPI project={self.project_id!r} space={self.space_url!r}>"
