from setuptools import setup

setup(
    name="sumedh-ai",
    version="0.1",
    packages=["sumedh_cli"],
    install_requires=[
        "typer",
        "rich",
        "groq"
    ],
    entry_points={
        "console_scripts": [
            "sumedh=sumedh_cli.main:app"
        ]
    }
)