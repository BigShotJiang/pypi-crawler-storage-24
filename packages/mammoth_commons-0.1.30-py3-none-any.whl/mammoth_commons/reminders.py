on_results = """
<p>Fairness does not end after producing AI outputs.</p>
 💡 Continue interacting with stakeholders to assert that their idea of fairness is correctly implemented.<br>
 💡 Monitor the outputs of deployed systems by rerunning the analysis on updated models and datasets.<br>
 💡 Test model and dataset variations for multiple sensitive characteristics and parameters.
<div style='margin-top: 10px;'><p>Keep a balance between justifying outputs as part of a fair process 
and accommodating constructive criticism. Do not over-rely on technical justification, and ensure 
meaningful human oversight whenever AI systems are deployed in decision-making, 
high-stakes, or rights-impacting contexts. Human oversight prevents overreliance on imperfect models, 
catches context-specific errors, and enables ethical judgment, accountability, and recourse for 
affected people.</p></div>
"""

logo_mmm_fair = """<img src="https://github.com/arjunroyihrpa/MMM_fair/blob/main/images/mmm-fair.png?raw=true"
alt="Based on MMM-Fair" style="float: left; margin-right: 5px; height: 36px;"/>"""
logo_aif360 = """<img src="https://avatars.githubusercontent.com/u/56103733?s=48&v=4"
alt="Based on AIF360" style="float: left; margin-right: 5px; margin-bottom: 5px; height: 36px;"/>"""
logo_fairbench = """<img src="https://github.com/mever-team/FairBench/blob/main/docs/fairbench.png?raw=true" 
alt="Based on FairBench" style="float: left; margin-right: 5px; margin-bottom: 5px; height: 36px;"/>"""
logo_vbmitigator = """<img src="https://github.com/mever-team/vb-mitigator/blob/main/assets/vb-mitigator%20logo_250.png?raw=true"
alt="Based on vb-mitigator" style="float: left; margin-right: 5px; height: 36px;"/>"""
logo_mai_bias = """<img src="https://github.com/mammoth-eu/mammoth-commons/blob/dev/mai_bias/logo.png?raw=true"
alt="Produced with MAI‑BIAS"
style="float:left;margin-right:5px;height:32px;background:#fff;border-radius:50%;">
"""
