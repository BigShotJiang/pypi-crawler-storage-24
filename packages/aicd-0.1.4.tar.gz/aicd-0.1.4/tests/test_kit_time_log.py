from __future__ import annotations

from aicd.kit import time_log


def test_elapsed_ms() -> None:
    r = time_log.elapsed_ms("2020-01-01T00:00:00Z", "2020-01-01T00:00:01Z")
    assert r["ok"] is True
    assert r["duration_ms"] == 1000


def test_log_record_has_ts() -> None:
    r = time_log.log_record("info", "hi", x=1)
    assert r["ok"] is True
    assert r["record"]["level"] == "info"
    assert r["record"]["message"] == "hi"
    assert r["record"]["x"] == 1
    assert "ts" in r["record"]
