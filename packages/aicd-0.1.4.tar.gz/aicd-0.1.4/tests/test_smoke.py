from __future__ import annotations

import asyncio
from pathlib import Path


def test_build_runtime(tmp_path: Path) -> None:
    from aicd.runtime import build_runtime

    async def _go() -> None:
        ctx = await build_runtime(home=tmp_path / "h")
        assert ctx.home == (tmp_path / "h").resolve()
        rows = await ctx.tasks.list_tasks(10)
        assert isinstance(rows, list)
        await ctx.conn.close()

    asyncio.run(_go())


def test_fs_list_self(tmp_path: Path) -> None:
    from aicd.config import AppConfig
    from aicd.tools.fs_tool import FSTool
    from aicd.tools.path_policy import PathPolicy

    cfg = AppConfig()
    pol = PathPolicy(cfg.paths)
    fs = FSTool(pol, cwd=tmp_path)
    (tmp_path / "a.txt").write_text("hi", encoding="utf-8")
    r = fs.list_dir(".")
    assert r["ok"] is True


def test_code_outline() -> None:
    from aicd.tools.code_intel import python_outline

    r = python_outline(__file__)
    assert r.get("ok") is True
