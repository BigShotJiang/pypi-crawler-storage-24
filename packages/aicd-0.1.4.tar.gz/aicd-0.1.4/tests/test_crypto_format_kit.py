"""kit crypto_codec / format_data 工具逻辑。"""

from __future__ import annotations

from aicd.kit import crypto_codec, format_data


def test_hash_sha256() -> None:
    r = crypto_codec.run_operation("hash_sha256", {"text": "abc"})
    assert r["ok"]
    assert r["hex"] == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"


def test_base64_roundtrip() -> None:
    e = crypto_codec.run_operation("base64_encode", {"text": "hi"})
    assert e["ok"]
    d = crypto_codec.run_operation("base64_decode", {"base64": e["base64"]})
    assert d["ok"]
    assert d["text"] == "hi"


def test_aes_gcm_roundtrip() -> None:
    key_hex = "00" * 32
    enc = crypto_codec.run_operation(
        "aes_gcm_encrypt",
        {"key_hex": key_hex, "text": "secret", "nonce_hex": "01" * 12},
    )
    assert enc["ok"]
    dec = crypto_codec.run_operation(
        "aes_gcm_decrypt",
        {
            "key_hex": key_hex,
            "nonce_hex": enc["nonce_hex"],
            "ciphertext_hex": enc["ciphertext_hex"],
        },
    )
    assert dec["ok"]
    assert dec["text"] == "secret"


def test_rsa_roundtrip() -> None:
    gen = crypto_codec.run_operation("rsa_generate", {"bits": 2048})
    assert gen["ok"]
    pub = gen["public_pem"]
    priv = gen["private_pem"]
    enc = crypto_codec.run_operation(
        "rsa_encrypt", {"public_pem": pub, "text": "hello-rsa"}
    )
    assert enc["ok"]
    dec = crypto_codec.run_operation(
        "rsa_decrypt",
        {"private_pem": priv, "ciphertext_hex": enc["ciphertext_hex"]},
    )
    assert dec["ok"]
    assert dec["text"] == "hello-rsa"


def test_ecdsa_sign_verify() -> None:
    gen = crypto_codec.run_operation("ecc_generate", {"curve": "secp256r1"})
    assert gen["ok"]
    sig = crypto_codec.run_operation(
        "ecdsa_sign",
        {"private_pem": gen["private_pem"], "message": "payload"},
    )
    assert sig["ok"]
    v = crypto_codec.run_operation(
        "ecdsa_verify",
        {
            "public_pem": gen["public_pem"],
            "message": "payload",
            "signature_hex": sig["signature_hex"],
        },
    )
    assert v["ok"] and v["valid"]


def test_json_path_and_html() -> None:
    j = format_data.run_operation(
        "json_path_get", {"text": '{"a":{"b":[1,{"x":9}]}}', "path": "a.b.1.x"}
    )
    assert j["ok"]
    assert j["value"] == 9
    h = format_data.run_operation(
        "html_to_text", {"html": "<p>Hello &amp; <b>world</b></p>"}
    )
    assert h["ok"]
    assert "Hello" in h["text"] and "world" in h["text"]


def test_xml_find() -> None:
    x = format_data.run_operation(
        "xml_find_tags",
        {"xml": '<r><item id="1">a</item><item>b</item></r>', "tag": "item"},
    )
    assert x["ok"]
    assert x["count"] == 2


def test_structure_transpose() -> None:
    r = format_data.run_operation(
        "structure_convert",
        {
            "mode": "transpose_records",
            "value": [{"a": 1, "b": 2}, {"a": 3, "b": 4}],
        },
    )
    assert r["ok"]
    assert r["series"]["a"] == [1, 3]
