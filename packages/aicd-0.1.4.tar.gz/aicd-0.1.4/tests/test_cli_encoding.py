from __future__ import annotations

import os

from aicd.cli_encoding import configure_cli_utf8, subprocess_env_utf8


def test_subprocess_env_utf8_sets_defaults() -> None:
    e = subprocess_env_utf8({"CUSTOM": "1"})
    assert e.get("PYTHONIOENCODING") == "utf-8"
    assert e.get("PYTHONUTF8") == "1"
    assert e.get("CUSTOM") == "1"


def test_subprocess_env_does_not_override_explicit() -> None:
    e = subprocess_env_utf8({"PYTHONIOENCODING": "latin-1"})
    assert e.get("PYTHONIOENCODING") == "latin-1"


def test_configure_cli_utf8_when_unset(monkeypatch) -> None:
    monkeypatch.delenv("PYTHONIOENCODING", raising=False)
    monkeypatch.delenv("PYTHONUTF8", raising=False)
    configure_cli_utf8()
    configure_cli_utf8()
    assert os.environ.get("PYTHONIOENCODING") == "utf-8"
    assert os.environ.get("PYTHONUTF8") == "1"
