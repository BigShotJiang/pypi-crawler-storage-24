"""image_crop 与 bbox 参考坐标系。"""

from __future__ import annotations

from pathlib import Path

from PIL import Image

from aicd.config import PathPolicyConfig
from aicd.tools.image_crop import crop_raster_image
from aicd.tools.path_policy import PathPolicy


def test_crop_scales_bbox_from_reference_space(tmp_path: Path) -> None:
    pol = PathPolicy(PathPolicyConfig(full_disk=True))
    src = tmp_path / "big.png"
    out = tmp_path / "c.png"
    Image.new("RGB", (800, 600), color=(200, 0, 0)).save(src)
    # bbox in "100x75" vision space: top-left quadrant of that space -> maps to 200x150 on 800x600
    r = crop_raster_image(
        src,
        out,
        left=0,
        top=0,
        width=50,
        height=38,
        policy_check=pol.check_allowed,
        bbox_reference_width=100,
        bbox_reference_height=75,
    )
    assert r["ok"] is True
    with Image.open(out) as im:
        assert im.size == (400, 304)


def test_image_file_to_data_url_with_meta_smaller_sent(tmp_path: Path) -> None:
    from aicd.agent.llm import image_file_to_data_url_with_meta

    img = tmp_path / "huge.png"
    Image.new("RGB", (4000, 2000), color=(1, 2, 3)).save(img)
    _url, meta = image_file_to_data_url_with_meta(img)
    assert meta["source_width"] == 4000
    assert meta["source_height"] == 2000
    assert meta["sent_width"] <= 1920
    assert meta["sent_height"] <= 1920
    assert meta["sent_width"] < meta["source_width"]
