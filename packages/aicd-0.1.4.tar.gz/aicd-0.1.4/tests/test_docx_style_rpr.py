"""段落样式 rPr 缺失时仍能设东亚字体。"""

from __future__ import annotations

from docx import Document

from aicd.tools.docx_compose import (
    ensure_paragraph_style_rPr,
    set_paragraph_style_east_asia_font,
)


def test_ensure_paragraph_style_rpr_creates_when_missing() -> None:
    doc = Document()
    st = doc.styles["Normal"]
    el = st.element
    r0 = getattr(el, "rPr", None)
    if r0 is not None:
        parent = r0.getparent()
        if parent is not None:
            parent.remove(r0)
    assert getattr(st.element, "rPr", None) is None
    rPr = ensure_paragraph_style_rPr(st)
    assert rPr is not None
    assert st.element.rPr is not None


def test_set_paragraph_style_east_asia_font_no_crash() -> None:
    doc = Document()
    st = doc.styles["Normal"]
    set_paragraph_style_east_asia_font(st, "宋体", latin="Times New Roman")
    rPr = ensure_paragraph_style_rPr(st)
    from docx.oxml.ns import qn

    rf = rPr.find(qn("w:rFonts"))
    assert rf is not None
    assert rf.get(qn("w:eastAsia")) == "宋体"
