"""Mermaid → PNG（Playwright）；无浏览器时跳过。"""

from __future__ import annotations

from pathlib import Path

import pytest

from aicd.config import PathPolicyConfig
from aicd.tools.mermaid_png import render_mermaid_to_png
from aicd.tools.path_policy import PathPolicy


def _chromium_available() -> bool:
    try:
        from playwright.sync_api import sync_playwright

        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            browser.close()
        return True
    except Exception:
        return False


@pytest.mark.skipif(not _chromium_available(), reason="Playwright Chromium not installed")
def test_render_mermaid_flowchart_png(tmp_path: Path) -> None:
    pol = PathPolicy(PathPolicyConfig(full_disk=True))
    out = tmp_path / "flow.png"
    r = render_mermaid_to_png(
        "flowchart TB\n  A[分析] --> B[实现]",
        out,
        policy_check=pol.check_allowed,
        theme="neutral",
    )
    assert r["ok"] is True
    assert out.is_file()
    assert out.stat().st_size > 500
