"""docx_compose：表格与东亚字体默认值。"""

from __future__ import annotations

from pathlib import Path

from docx import Document

from aicd.tools.docx_compose import docx_compose


def _policy(p: Path) -> None:
    return None


def test_docx_table_rows_as_json_string(tmp_path: Path) -> None:
    """部分模型把 table.rows 序列化成 JSON 字符串。"""
    p = tmp_path / "out_json_rows.docx"
    r = docx_compose(
        p,
        [
            {
                "type": "table",
                "rows": '[["A","B"],["1","2"]]',
            },
        ],
        policy_check=_policy,
    )
    assert r["ok"] is True
    assert r["tables_added"] == 1


def test_docx_table_and_simsun_defaults(tmp_path: Path) -> None:
    p = tmp_path / "out.docx"
    r = docx_compose(
        p,
        [
            {"type": "heading", "text": "H", "level": 1},
            {"type": "paragraph", "text": "body"},
            {
                "type": "table",
                "rows": [["A", "B"], ["1", "2"]],
                "header_row": True,
            },
        ],
        policy_check=_policy,
        default_east_asia_font="宋体",
        default_color_hex="000000",
        default_body_font_pt=11.0,
    )
    assert r["ok"] is True
    assert r["tables_added"] == 1
    assert r["defaults_applied"] is True
    doc = Document(str(p))
    assert len(doc.tables) == 1
    assert len(doc.paragraphs) >= 2
