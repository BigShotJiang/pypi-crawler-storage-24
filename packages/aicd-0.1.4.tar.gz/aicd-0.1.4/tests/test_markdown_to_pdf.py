"""markdown_to_pdf：默认 CSS 与可选源快照。"""

from __future__ import annotations

from pathlib import Path

import pytest

from aicd.tools import markdown_to_pdf as mtp


def test_story_css_avoids_black_header_defaults() -> None:
    css = mtp.DEFAULT_STORY_CSS
    assert "thead" in css
    assert "border-collapse: separate" in css
    assert "hr" in css
    assert "#e8e8e8" in css or "#eeeeee" in css


def _allow(_p: Path) -> None:
    return None


def test_export_with_source_snapshot(tmp_path: Path) -> None:
    pytest.importorskip("fitz")
    pytest.importorskip("markdown")
    md = "| Col1 | Col2 |\n| --- | --- |\n| a | b |\n"
    pdf = tmp_path / "out.pdf"
    snap = tmp_path / "out_source.md"
    r = mtp.export_markdown_to_pdf(
        output_pdf_path=pdf,
        policy_check=_allow,
        markdown_text=md,
        source_snapshot_path=snap,
    )
    assert r.get("ok"), r
    assert pdf.is_file() and pdf.stat().st_size > 0
    assert snap.is_file()
    assert "Col1" in snap.read_text(encoding="utf-8")
    assert r.get("source_snapshot_path")
