from __future__ import annotations

from pathlib import Path

import pytest

pytest.importorskip("reportlab")

from aicd.tools.pdf_compose_rl import pdf_compose


def test_pdf_compose_minimal(tmp_path: Path) -> None:
    out = tmp_path / "c.pdf"
    r = pdf_compose(
        out,
        [
            {"type": "heading", "level": 1, "text": "Hello"},
            {"type": "paragraph", "text": "Line one.\nLine two."},
        ],
        policy_check=lambda p: None,
    )
    assert r.get("ok") is True
    assert out.is_file() and out.stat().st_size > 80
