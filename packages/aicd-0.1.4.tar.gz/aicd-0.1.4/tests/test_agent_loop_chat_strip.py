"""AgentLoop 新会话后消息链与裁剪逻辑。"""

from __future__ import annotations

from aicd.agent.loop import _trim_chat_messages_to_last_user_turn


def test_trim_keeps_suffix_from_last_user() -> None:
    msgs = [
        {"role": "user", "content": "old"},
        {"role": "assistant", "content": "a"},
        {"role": "user", "content": "新会话"},
        {"role": "assistant", "content": "", "tool_calls": []},
        {"role": "tool", "tool_call_id": "x", "content": "{}"},
    ]
    _trim_chat_messages_to_last_user_turn(msgs)
    assert len(msgs) == 3
    assert msgs[0]["content"] == "新会话"


def test_trim_noop_when_only_one_user_at_start() -> None:
    msgs = [
        {"role": "user", "content": "hi"},
        {"role": "assistant", "content": "", "tool_calls": []},
    ]
    _trim_chat_messages_to_last_user_turn(msgs)
    assert len(msgs) == 2
