"""CLI 行为烟测（不启动 TUI / 不调 LLM）。"""

from typer.testing import CliRunner

from aicd.app import app


def test_tui_noui_requires_ai() -> None:
    runner = CliRunner()
    r = runner.invoke(app, ["tui", "--noui"])
    assert r.exit_code == 2
    assert "--ai" in (r.stdout or "") + (r.stderr or "")
