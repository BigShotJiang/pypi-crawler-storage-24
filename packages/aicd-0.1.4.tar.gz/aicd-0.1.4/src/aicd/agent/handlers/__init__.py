"""Tool handler functions keyed by OpenAI tool name."""

from aicd.agent.handlers.registry import tool_handlers

__all__ = ["tool_handlers"]
