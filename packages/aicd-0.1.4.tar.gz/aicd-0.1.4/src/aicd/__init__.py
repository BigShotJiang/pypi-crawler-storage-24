"""Aicd: CLI AI agent for code and documentation."""

from aicd.version import VERSION as __version__
