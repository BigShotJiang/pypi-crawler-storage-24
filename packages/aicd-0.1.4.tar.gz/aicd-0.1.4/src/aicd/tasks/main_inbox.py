"""主对话虚拟收件箱：顶层子任务完成/失败/取消及上行消息投递到 ``main-inbox-<session_id>``。"""

from __future__ import annotations

MAIN_INBOX_PREFIX = "main-inbox-"


def main_inbox_id(session_id: str) -> str:
    sid = (session_id or "").strip()
    if not sid:
        raise ValueError("session_id required for main inbox")
    return f"{MAIN_INBOX_PREFIX}{sid}"


def is_main_inbox_task_id(task_id: str) -> bool:
    t = (task_id or "").strip()
    return bool(t.startswith(MAIN_INBOX_PREFIX) and len(t) > len(MAIN_INBOX_PREFIX))
