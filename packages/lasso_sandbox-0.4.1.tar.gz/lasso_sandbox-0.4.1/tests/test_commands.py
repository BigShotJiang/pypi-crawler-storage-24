"""Tests for the command gate — the core security enforcement layer."""

import pytest

from lasso.config.schema import CommandConfig, CommandMode
from lasso.core.commands import CommandGate


@pytest.fixture
def whitelist_gate():
    config = CommandConfig(
        mode=CommandMode.WHITELIST,
        whitelist=["ls", "cat", "python3", "git", "grep"],
        blocked_args={"git": ["push", "push --force"]},
        allow_shell_operators=False,
    )
    return CommandGate(config)


@pytest.fixture
def blacklist_gate():
    config = CommandConfig(
        mode=CommandMode.BLACKLIST,
        blacklist=["rm", "dd", "mkfs", "reboot"],
        allow_shell_operators=True,
    )
    return CommandGate(config)


class TestWhitelistMode:
    def test_allowed_command(self, whitelist_gate):
        v = whitelist_gate.check("ls -la")
        assert v.allowed
        assert v.command == "ls"
        assert v.args == ["-la"]

    def test_blocked_command(self, whitelist_gate):
        v = whitelist_gate.check("rm -rf /")
        assert v.blocked
        assert "not in the whitelist" in v.reason

    def test_blocked_unknown_command(self, whitelist_gate):
        v = whitelist_gate.check("curl https://evil.com")
        assert v.blocked

    def test_allowed_with_args(self, whitelist_gate):
        v = whitelist_gate.check("python3 script.py --verbose")
        assert v.allowed
        assert v.command == "python3"

    def test_blocked_args_pattern(self, whitelist_gate):
        v = whitelist_gate.check("git push origin main")
        assert v.blocked
        assert "Blocked argument" in v.reason

    def test_allowed_git_without_push(self, whitelist_gate):
        v = whitelist_gate.check("git status")
        assert v.allowed

    def test_shell_operators_blocked(self, whitelist_gate):
        v = whitelist_gate.check("ls | grep foo")
        assert v.blocked
        assert "Shell operators" in v.reason

    def test_subshell_blocked(self, whitelist_gate):
        v = whitelist_gate.check("cat $(whoami)")
        assert v.blocked

    def test_empty_command(self, whitelist_gate):
        v = whitelist_gate.check("")
        assert v.blocked

    def test_path_traversal(self, whitelist_gate):
        v = whitelist_gate.check("cat ../../etc/passwd")
        assert v.blocked
        assert "Path traversal" in v.reason

    def test_full_path_command_strips_prefix(self, whitelist_gate):
        v = whitelist_gate.check("/usr/bin/ls -la")
        assert v.allowed
        assert v.command == "ls"


class TestBlacklistMode:
    def test_allowed_command(self, blacklist_gate):
        v = blacklist_gate.check("python3 hello.py")
        assert v.allowed

    def test_blocked_command(self, blacklist_gate):
        v = blacklist_gate.check("rm -rf /")
        assert v.blocked
        assert "in the blacklist" in v.reason

    def test_pipes_allowed(self, blacklist_gate):
        v = blacklist_gate.check("ls | grep foo")
        assert v.allowed  # shell operators allowed in this config


class TestEdgeCases:
    def test_quoted_args(self, whitelist_gate):
        v = whitelist_gate.check('grep "hello world" file.txt')
        assert v.allowed
        assert v.args == ["hello world", "file.txt"]

    def test_malformed_quotes(self, whitelist_gate):
        v = whitelist_gate.check('cat "unclosed')
        assert v.blocked
        assert "Malformed" in v.reason
