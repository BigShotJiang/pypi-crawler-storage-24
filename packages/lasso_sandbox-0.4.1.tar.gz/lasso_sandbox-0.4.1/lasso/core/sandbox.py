"""Sandbox — the main orchestrator that ties all isolation layers together.

Lifecycle: create → configure → start → exec → stop → cleanup

Supports two execution modes:
1. Container backend (Docker/Podman) — primary, cross-platform
2. Native backend (Linux namespaces) — fallback for lightweight use
"""

from __future__ import annotations

import logging
import os
import platform
import subprocess
import time
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Optional

logger = logging.getLogger("lasso.sandbox")

from lasso.backends.base import ContainerBackend, ContainerState
from lasso.backends.converter import needs_network_rules, profile_to_container_config
from lasso.config.schema import ProfileMode, SandboxProfile, SandboxState
from lasso.core.audit import AuditLogger
from lasso.core.commands import CommandGate
from lasso.core.network import NetworkPolicy


@dataclass
class ExecResult:
    """Result of a command execution inside the sandbox."""
    command: str
    exit_code: int
    stdout: str
    stderr: str
    duration_ms: int = 0
    blocked: bool = False
    block_reason: str = ""


class Sandbox:
    """A single isolated execution environment.

    Each Sandbox instance represents one agent's sandboxed workspace with
    its own filesystem view, command policy, network rules, resource limits,
    and audit trail.

    When a `backend` is provided, commands execute inside a container.
    When no backend is provided, falls back to direct subprocess execution
    with software-level isolation (command gate + env sanitization).
    """

    def __init__(
        self,
        profile: SandboxProfile,
        backend: Optional[ContainerBackend] = None,
        sandbox_id: Optional[str] = None,
    ):
        self.id = sandbox_id or uuid.uuid4().hex[:12]
        self.profile = profile
        self._mode = profile.mode
        self.state = SandboxState.CREATED
        self.created_at = datetime.now(timezone.utc)

        # Pluggable backend
        self._backend = backend
        self._container_id: Optional[str] = None

        # Core subsystems (always active regardless of backend)
        self.command_gate = CommandGate(profile.commands, mode=self._mode)

        # Set up webhook dispatcher if any webhooks are configured
        webhook_dispatcher = None
        if profile.audit.webhooks:
            from lasso.core.webhooks import WebhookDispatcher
            webhook_dispatcher = WebhookDispatcher(profile.audit.webhooks)

        self.audit = AuditLogger(self.id, profile.audit, webhook_dispatcher=webhook_dispatcher)

        # Warm pool flag — set by SandboxRegistry when a pre-warmed container
        # is attached.  When True, start() skips image build + create + start.
        self._warm_claimed: bool = False

        # Runtime counters
        self._exec_count = 0
        self._blocked_count = 0

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Start the sandbox environment."""
        if self.state not in (SandboxState.CREATED, SandboxState.STOPPED):
            raise RuntimeError(f"Cannot start sandbox in state: {self.state.value}")

        self.state = SandboxState.CONFIGURING
        self.audit.log_lifecycle("start", {
            "profile": self.profile.name,
            "config_hash": self.profile.config_hash(),
            "backend": self._backend.__class__.__name__ if self._backend else "native",
        })

        if self._backend:
            self._start_with_backend()
        else:
            self._start_native()

        self.state = SandboxState.RUNNING
        self.audit.log_lifecycle("running")

    def _start_with_backend(self) -> None:
        """Start using a container backend.

        If ``_warm_claimed`` is True, the container is already created and
        running -- skip image build, create, and start.  Only apply network
        policy rules (defense in depth).
        """
        if not self._backend.is_available():
            self.state = SandboxState.ERROR
            raise RuntimeError(
                f"Container backend {self._backend.__class__.__name__} is not available. "
                "Is the runtime installed and running?"
            )

        if self._warm_claimed and self._container_id:
            # Warm container is already created + started; just apply network rules
            self.audit.log_lifecycle("warm_container_attached", {
                "container_id": self._container_id[:12],
            })
            self._apply_network_policy()
            return

        # Cold path: full image build + create + start
        from lasso.backends.image_builder import ensure_image
        image_tag = ensure_image(self._backend, self.profile)

        container_config = profile_to_container_config(self.profile)
        container_config.name = f"lasso-{self.id}"
        container_config.image = image_tag

        try:
            self._container_id = self._backend.create(container_config)
            self._backend.start(self._container_id)
        except Exception as e:
            self.state = SandboxState.ERROR
            self.audit.log_lifecycle("start_failed", {"error": str(e)})
            raise

        # Apply network policy rules inside the container
        self._apply_network_policy()

    def _apply_network_policy(self) -> None:
        """Generate and apply iptables rules inside the container.

        Creates a NetworkPolicy from the profile's network config, generates
        iptables commands, and executes each one inside the container via the
        backend. Results are logged to the audit trail.
        """
        if not self._backend or not self._container_id:
            return

        if not needs_network_rules(self.profile):
            return

        policy = NetworkPolicy(self.profile.network)
        rules = policy.generate_iptables_rules()

        if not rules:
            return

        applied = 0
        failed = 0

        for rule in rules:
            try:
                result = self._backend.exec(self._container_id, rule, timeout=10)
                if result.exit_code == 0:
                    applied += 1
                else:
                    failed += 1
                    logger.warning(
                        "iptables rule failed (exit %d): %s — %s",
                        result.exit_code, " ".join(rule), result.stderr,
                    )
            except Exception as e:
                failed += 1
                logger.warning("iptables rule exception: %s — %s", " ".join(rule), e)

        self.audit.log_lifecycle("network_policy_applied", {
            "mode": self.profile.network.mode.value,
            "rules_total": len(rules),
            "rules_applied": applied,
            "rules_failed": failed,
        })

        if failed == len(rules) and len(rules) > 0:
            # Every single rule failed — the container is NOT secured.
            # This almost certainly means iptables is not installed in the
            # container image.
            self.state = SandboxState.ERROR
            raise RuntimeError(
                "All network policy rules failed to apply. "
                "Is iptables installed in the container image?"
            )

        if failed > 0:
            logger.warning(
                "Network policy partially applied: %d/%d rules succeeded",
                applied, len(rules),
            )

    def _inject_github_token(self, env: dict[str, str]) -> None:
        """Inject GitHub token into sandbox environment if available.

        Only injects if the profile has agent_auth.github_token_env configured.
        Token is sourced from GitHubAuth (which checks GITHUB_TOKEN env var
        and ~/.lasso/github_token.json).
        """
        if not self.profile.agent_auth:
            return

        token_env_name = self.profile.agent_auth.github_token_env
        if not token_env_name:
            return

        try:
            from lasso.auth.github import GitHubAuth
            auth = GitHubAuth()
            token = auth.get_token()
            if token:
                env[token_env_name] = token
                self.audit.log_lifecycle("github_token_injected", {
                    "env_var": token_env_name,
                })
        except Exception as e:
            logger.debug("Could not inject GitHub token: %s", e)

    def _start_native(self) -> None:
        """Start with native (subprocess) isolation — no container runtime needed."""
        # Native mode just validates the working directory exists
        from pathlib import Path
        workdir = Path(self.profile.filesystem.working_dir)
        if not workdir.exists():
            workdir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Profile mode (gradual authorization)
    # ------------------------------------------------------------------

    @property
    def mode(self) -> ProfileMode:
        """Current profile mode controlling command access level."""
        return self._mode

    def set_mode(self, new_mode: ProfileMode) -> None:
        """Change the sandbox profile mode (gradual authorization).

        Validates the transition, updates the command gate, and logs
        the mode change to the audit trail.

        Raises:
            RuntimeError: If the sandbox is not in RUNNING state.
        """
        if self.state != SandboxState.RUNNING:
            raise RuntimeError(
                f"Cannot change mode on sandbox in state: {self.state.value}. "
                "Sandbox must be running."
            )

        old_mode = self._mode
        if old_mode == new_mode:
            return

        self._mode = new_mode
        self.command_gate.set_mode(new_mode)

        self.audit.log_lifecycle("mode_changed", {
            "old_mode": old_mode.value,
            "new_mode": new_mode.value,
        })

        logger.info(
            "Sandbox %s mode changed: %s -> %s",
            self.id, old_mode.value, new_mode.value,
        )

    def exec(self, raw_command: str) -> ExecResult:
        """Execute a command inside the sandbox with full policy enforcement.

        1. Validate command against the command gate
        2. If allowed, execute via backend or native subprocess
        3. Log everything to audit trail
        4. Return structured result
        """
        if self.state != SandboxState.RUNNING:
            return ExecResult(
                command=raw_command,
                exit_code=-1,
                stdout="",
                stderr=f"Sandbox is not running (state: {self.state.value})",
                duration_ms=0,
                blocked=True,
                block_reason="Sandbox not running",
            )

        self._exec_count += 1

        # --- Step 1: Command validation (always, regardless of backend) ---
        verdict = self.command_gate.check(raw_command)

        if verdict.blocked:
            self._blocked_count += 1
            self.audit.log_command_blocked(raw_command, verdict.reason)
            return ExecResult(
                command=raw_command,
                exit_code=-1,
                stdout="",
                stderr=f"BLOCKED: {verdict.reason}",
                duration_ms=0,
                blocked=True,
                block_reason=verdict.reason,
            )

        # --- Step 2: Execute ---
        start_time = time.monotonic_ns()
        cmd_list = [verdict.command] + verdict.args

        if self._backend and self._container_id:
            result = self._exec_with_backend(cmd_list)
        else:
            result = self._exec_native(cmd_list)

        duration_ms = (time.monotonic_ns() - start_time) // 1_000_000

        # --- Step 3: Audit ---
        detail = {"duration_ms": duration_ms, "exit_code": result.exit_code}
        if self.profile.audit.include_command_output:
            detail["stdout_head"] = result.stdout[:2000]
            detail["stderr_head"] = result.stderr[:2000]

        self.audit.log_command(
            verdict.command,
            verdict.args,
            outcome="success" if result.exit_code == 0 else "error",
            detail=detail,
        )

        return ExecResult(
            command=raw_command,
            exit_code=result.exit_code,
            stdout=result.stdout,
            stderr=result.stderr,
            duration_ms=duration_ms,
        )

    def _exec_with_backend(self, cmd: list[str]) -> ExecResult:
        """Execute a command via the container backend."""
        try:
            backend_result = self._backend.exec(
                self._container_id,
                cmd,
                timeout=self.profile.commands.max_execution_seconds,
            )
            return ExecResult(
                command=" ".join(cmd),
                exit_code=backend_result.exit_code,
                stdout=backend_result.stdout,
                stderr=backend_result.stderr,
                duration_ms=backend_result.duration_ms,
            )
        except Exception as e:
            return ExecResult(
                command=" ".join(cmd),
                exit_code=-1,
                stdout="",
                stderr=str(e),
                duration_ms=0,
            )

    def _exec_native(self, cmd: list[str]) -> ExecResult:
        """Execute a command as a subprocess with env sanitization."""
        if platform.system() == "Windows":
            default_path = r"C:\Windows\system32;C:\Windows;C:\Windows\System32\Wbem"
        else:
            default_path = "/usr/local/bin:/usr/bin:/bin"

        env = {
            "PATH": default_path,
            "HOME": self.profile.filesystem.working_dir,
            "LANG": "C.UTF-8",
            "LC_ALL": "C.UTF-8",
            "TERM": "dumb",
            "LASSO_SANDBOX_ID": self.id,
            "LASSO_SANDBOX_NAME": self.profile.name,
        }

        # Inject GitHub token if available and configured
        self._inject_github_token(env)

        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                timeout=self.profile.commands.max_execution_seconds,
                env=env,
                cwd=self.profile.filesystem.working_dir,
            )
            return ExecResult(
                command=" ".join(cmd),
                exit_code=proc.returncode,
                stdout=proc.stdout.decode(errors="replace"),
                stderr=proc.stderr.decode(errors="replace"),
            )
        except subprocess.TimeoutExpired:
            return ExecResult(
                command=" ".join(cmd),
                exit_code=-1,
                stdout="",
                stderr=f"Command timed out after {self.profile.commands.max_execution_seconds}s",
            )
        except Exception as e:
            return ExecResult(
                command=" ".join(cmd),
                exit_code=-1,
                stdout="",
                stderr=str(e),
            )

    def stop(self) -> None:
        """Stop the sandbox and clean up."""
        if self.state == SandboxState.STOPPED:
            return

        prev_state = self.state
        self.state = SandboxState.STOPPED

        if self._backend and self._container_id:
            try:
                self._backend.stop(self._container_id)
                self._backend.remove(self._container_id)
            except Exception as e:
                logger.warning("Container cleanup failed for %s: %s", self._container_id[:12], e)

        self.audit.log_lifecycle("stopped", {
            "prev_state": prev_state.value,
            "total_execs": self._exec_count,
            "total_blocked": self._blocked_count,
        })

    # ------------------------------------------------------------------
    # Status / introspection
    # ------------------------------------------------------------------

    def status(self) -> dict[str, Any]:
        """Return current sandbox status including full security posture."""
        # Database port human-readable names for dashboard display
        DB_PORT_NAMES = {
            1433: "MSSQL", 1434: "MSSQL Browser",
            3306: "MySQL", 5432: "PostgreSQL", 27017: "MongoDB",
            6379: "Redis", 9042: "Cassandra", 8123: "ClickHouse HTTP",
            9000: "ClickHouse", 1521: "Oracle", 5984: "CouchDB",
        }

        net = self.profile.network
        fs = self.profile.filesystem
        audit_cfg = self.profile.audit

        return {
            "id": self.id,
            "name": self.profile.name,
            "state": self.state.value,
            "mode": self._mode.value,
            "created_at": self.created_at.isoformat(),
            "working_dir": fs.working_dir,
            "exec_count": self._exec_count,
            "blocked_count": self._blocked_count,
            "config_hash": self.profile.config_hash()[:12],
            "audit_log": str(self.audit.log_file) if self.audit.log_file else None,
            "network_mode": net.mode.value,
            "command_mode": self.profile.commands.mode.value,
            "backend": self._backend.__class__.__name__ if self._backend else "native",
            "container_id": self._container_id,
            # Network policy details
            "network": {
                "mode": net.mode.value,
                "allowed_domains": net.allowed_domains,
                "blocked_ports": net.blocked_ports,
                "blocked_ports_named": {
                    port: DB_PORT_NAMES.get(port, f"port {port}")
                    for port in net.blocked_ports
                },
                "blocked_cidrs": net.blocked_cidrs,
                "allowed_ports": net.allowed_ports,
                "dns_servers": net.dns_servers,
            },
            # Filesystem isolation details
            "filesystem": {
                "working_dir": fs.working_dir,
                "read_only_paths": fs.read_only_paths,
                "hidden_paths": fs.hidden_paths,
                "writable_paths": fs.writable_paths,
                "max_disk_mb": fs.max_disk_mb,
                "temp_dir_mb": fs.temp_dir_mb,
            },
            # Audit configuration
            "audit_config": {
                "enabled": audit_cfg.enabled,
                "sign_entries": audit_cfg.sign_entries,
                "log_dir": audit_cfg.log_dir,
                "include_command_output": audit_cfg.include_command_output,
                "include_file_diffs": audit_cfg.include_file_diffs,
                "max_log_size_mb": audit_cfg.max_log_size_mb,
                "webhooks_count": len(audit_cfg.webhooks),
            },
        }

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop()
        return False

    def __repr__(self) -> str:
        return f"<Sandbox id={self.id} name={self.profile.name!r} state={self.state.value}>"


# ---------------------------------------------------------------------------
# Multi-sandbox registry
# ---------------------------------------------------------------------------

class SandboxRegistry:
    """Manages multiple running sandboxes with optional persistent state.

    When a ``state_dir`` is provided (or defaults to ``~/.lasso``),
    sandbox metadata is persisted to disk so that LASSO can recover
    after crashes.  On construction the store is loaded automatically;
    call :meth:`reconcile` after init to prune stale entries.

    Optional ``warm_pool`` support: when provided, :meth:`create` will
    attempt to claim a pre-warmed container before falling back to the
    normal (slower) creation path.
    """

    def __init__(
        self,
        backend: Optional[ContainerBackend] = None,
        state_dir: Optional[str] = None,
        warm_pool: Optional["WarmPool"] = None,
    ):
        self._sandboxes: dict[str, Sandbox] = {}
        self._backend = backend
        self._warm_pool = warm_pool

        # Persistent state
        from lasso.core.state import StateStore
        self._store = StateStore(state_dir=state_dir)
        self._store.load()

    def create(self, profile: SandboxProfile) -> Sandbox:
        """Create and register a new sandbox.

        If a warm pool is available, tries to claim a pre-warmed container
        first.  On a pool hit the sandbox wraps the existing container and
        skips image build + create + start.  On a miss, falls back to the
        normal creation path.

        Returns a Sandbox instance (not yet started -- caller must call
        ``sandbox.start()`` unless a warm container was claimed, in which
        case ``sandbox._warm_claimed`` is ``True``).
        """
        warm_container_id = None

        if self._warm_pool is not None:
            warm_container_id = self._warm_pool.claim(profile.name)

        sb = Sandbox(profile, backend=self._backend)

        if warm_container_id is not None:
            # Attach the pre-warmed container directly
            sb._container_id = warm_container_id
            sb._warm_claimed = True
            logger.info(
                "Sandbox %s using warm container %s",
                sb.id, warm_container_id[:12],
            )
            # Trigger background replenishment
            self._warm_pool.replenish(profile.name)
        else:
            sb._warm_claimed = False

        self._sandboxes[sb.id] = sb
        self._store.record_create(
            sandbox_id=sb.id,
            profile_name=profile.name,
            container_id=sb._container_id,
            mode=profile.mode.value,
        )
        return sb

    def get(self, sandbox_id: str) -> Optional[Sandbox]:
        return self._sandboxes.get(sandbox_id)

    def get_by_name(self, name: str) -> Optional[Sandbox]:
        for sb in self._sandboxes.values():
            if sb.profile.name == name:
                return sb
        return None

    def list_all(self) -> list[dict[str, Any]]:
        return [sb.status() for sb in self._sandboxes.values()]

    def set_mode(self, sandbox_id: str, mode: ProfileMode) -> bool:
        """Change the profile mode for a running sandbox.

        Returns True if the sandbox was found and mode updated.
        """
        sb = self._sandboxes.get(sandbox_id)
        if sb:
            sb.set_mode(mode)
            self._store.record_mode_change(sandbox_id, mode.value)
            return True
        return False

    def stop(self, sandbox_id: str) -> bool:
        sb = self._sandboxes.get(sandbox_id)
        if sb:
            sb.stop()
            self._store.record_stop(sandbox_id)
            return True
        return False

    def stop_all(self) -> int:
        count = 0
        for sb in self._sandboxes.values():
            if sb.state == SandboxState.RUNNING:
                sb.stop()
                self._store.record_stop(sb.id)
                count += 1
        return count

    def remove(self, sandbox_id: str) -> bool:
        sb = self._sandboxes.pop(sandbox_id, None)
        if sb:
            sb.stop()
            self._store.record_remove(sandbox_id)
            return True
        return False

    def reconcile(self) -> dict[str, str]:
        """Reconcile persisted state against actual containers.

        Checks which containers from previous runs still exist and updates
        the state store accordingly.  Returns a dict mapping sandbox_id to
        the action taken (``"alive"``, ``"stopped"``, or ``"gone"``).
        """
        return self._store.reconcile(self._backend)

    def shutdown(self) -> None:
        """Gracefully shut down all sandboxes, save state, and log events.

        Called by signal handlers and atexit hooks to ensure clean teardown.
        Logs lifecycle events for audit trail compliance.
        """
        # Use a dedicated audit logger for registry-level events
        from lasso.config.schema import AuditConfig
        from lasso.core.audit import AuditLogger

        audit = None
        # Borrow an audit logger from any existing sandbox, or create a minimal one
        for sb in self._sandboxes.values():
            if sb.audit and sb.audit.config.enabled:
                audit = sb.audit
                break

        if audit:
            audit.log_lifecycle("shutdown_initiated", {
                "sandbox_count": len(self._sandboxes),
                "running_count": sum(
                    1 for sb in self._sandboxes.values()
                    if sb.state == SandboxState.RUNNING
                ),
            })

        # Shut down warm pool first (stops background replenishment)
        if self._warm_pool is not None:
            try:
                self._warm_pool.shutdown()
            except Exception as e:
                logger.warning("Warm pool shutdown error: %s", e)

        # Stop all running sandboxes
        stopped = self.stop_all()

        # Save state to disk
        self._store.save()

        if audit:
            audit.log_lifecycle("shutdown_complete", {
                "sandboxes_stopped": stopped,
            })

        logger.info("Shutdown complete: %d sandbox(es) stopped, state saved.", stopped)

    @property
    def store(self):
        """Access the underlying StateStore (for inspection / testing)."""
        return self._store

    def __len__(self) -> int:
        return len(self._sandboxes)
