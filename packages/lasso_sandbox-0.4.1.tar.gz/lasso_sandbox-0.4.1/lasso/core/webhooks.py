"""Webhook dispatcher — async delivery of audit events to external systems.

Sends sandbox audit events (violations, lifecycle changes, commands, etc.) to
configured webhook endpoints for SIEM/SOAR, Slack, and monitoring integration.

Design decisions:
- Uses stdlib ``urllib.request`` only (no external HTTP dependencies).
- Dispatches asynchronously via ``threading.Thread`` so webhook latency
  never blocks command execution inside the sandbox.
- Signs payloads with HMAC-SHA256 when a secret is configured, following
  the same pattern as GitHub webhook signatures (X-Hub-Signature-256).
- Retries with exponential backoff on transient failures.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import threading
import time
import urllib.error
import urllib.request
import uuid
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from lasso.config.schema import WebhookConfig
    from lasso.core.audit import AuditEvent

logger = logging.getLogger("lasso.webhooks")

# All event types that LASSO emits.
WEBHOOK_EVENT_TYPES: list[str] = [
    "command",
    "lifecycle",
    "violation",
    "file",
    "network",
]


class WebhookDispatcher:
    """Delivers audit events to one or more webhook endpoints.

    Each webhook is filtered by its ``events`` list — only matching event
    types are dispatched.  Delivery happens on background threads so the
    caller is never blocked.
    """

    def __init__(self, webhooks: list[WebhookConfig]):
        self._webhooks = [wh for wh in webhooks if wh.enabled and wh.url]

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def dispatch(self, event: AuditEvent) -> None:
        """Send *event* to all matching webhooks (non-blocking)."""
        if not self._webhooks:
            return

        payload = json.dumps(event.to_dict(), separators=(",", ":"), sort_keys=True)

        for wh in self._webhooks:
            if event.event_type not in wh.events:
                continue
            t = threading.Thread(
                target=self._deliver,
                args=(wh, payload, event.event_type),
                daemon=True,
            )
            t.start()

    @property
    def active_webhooks(self) -> int:
        """Number of enabled+configured webhooks."""
        return len(self._webhooks)

    # ------------------------------------------------------------------
    # Internal delivery
    # ------------------------------------------------------------------

    def _deliver(
        self,
        wh: WebhookConfig,
        payload: str,
        event_type: str,
    ) -> None:
        """Deliver *payload* to a single webhook with retries."""
        delivery_id = uuid.uuid4().hex[:16]
        timestamp = str(int(time.time()))

        headers = {
            "Content-Type": "application/json",
            "X-Lasso-Event": event_type,
            "X-Lasso-Delivery": delivery_id,
            "X-Lasso-Timestamp": timestamp,
            "User-Agent": "LASSO-Webhook/1.0",
        }

        if wh.secret:
            sig_payload = timestamp + "." + payload
            sig = hmac.new(
                wh.secret.encode(),
                sig_payload.encode(),
                hashlib.sha256,
            ).hexdigest()
            headers["X-Lasso-Signature"] = f"t={timestamp},sha256={sig}"

        last_error: Exception | None = None
        attempts = 1 + wh.retry_count  # first attempt + retries

        for attempt in range(attempts):
            try:
                req = urllib.request.Request(
                    wh.url,
                    data=payload.encode(),
                    headers=headers,
                    method="POST",
                )
                with urllib.request.urlopen(req, timeout=wh.timeout_seconds) as resp:
                    status = resp.status
                    if 200 <= status < 300:
                        logger.debug(
                            "Webhook delivered: %s -> %s (status %d, delivery %s)",
                            event_type, wh.url, status, delivery_id,
                        )
                        return
                    else:
                        last_error = RuntimeError(f"HTTP {status}")
            except (urllib.error.URLError, OSError, RuntimeError) as exc:
                last_error = exc

            # Exponential backoff before retry
            if attempt < attempts - 1:
                backoff = 0.5 * (2 ** attempt)
                time.sleep(backoff)

        logger.warning(
            "Webhook delivery failed after %d attempts: %s -> %s — %s",
            attempts, event_type, wh.url, last_error,
        )
