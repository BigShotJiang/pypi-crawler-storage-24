"""LASSO CLI — the primary interface for managing sandboxes.

Usage:
    lasso quickstart                     # one-command setup and launch
    lasso doctor                         # comprehensive system diagnostics
    lasso check                          # verify system + container runtime
    lasso init [--profile NAME]          # bootstrap project with .lasso/
    lasso run <agent>                    # zero-config agent sandbox
    lasso create <profile> [--dir PATH]  # create and start a sandbox
    lasso exec <id> -- <command>         # run command in sandbox
    lasso interactive <profile>          # REPL mode
    lasso status [id]                    # show sandbox status
    lasso stop <id|all>                  # stop sandbox(es)
    lasso profile list|show|save|delete  # manage profiles
    lasso audit view|verify|export       # audit log tools
    lasso compliance report <framework>  # DORA/EU AI Act evidence reports
    lasso dashboard                      # launch web UI

Aliases:
    lasso ps   → lasso status
    lasso rm   → lasso stop
"""

from __future__ import annotations

import csv
import io
import json
import os
import platform
import signal
import sys
import tempfile
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from lasso import __version__
from lasso.config.defaults import BUILTIN_PROFILES
from lasso.config.profile import (
    delete_profile,
    list_profiles,
    load_profile,
    load_profile_from_path,
    save_profile,
)
from lasso.config.schema import ProfileMode, SandboxProfile
from lasso.core.sandbox import Sandbox, SandboxRegistry

console = Console()
err_console = Console(stderr=True)

app = typer.Typer(
    name="lasso",
    help="LASSO — Layered Agent Sandbox Security Orchestrator",
    no_args_is_help=True,
    rich_markup_mode="rich",
)

profile_app = typer.Typer(help="Manage sandbox profiles.", no_args_is_help=True)
app.add_typer(profile_app, name="profile")

audit_app = typer.Typer(help="View and verify audit logs.", no_args_is_help=True)
app.add_typer(audit_app, name="audit")

agent_app = typer.Typer(help="Manage AI agent configurations.", no_args_is_help=True)
app.add_typer(agent_app, name="agent")

auth_app = typer.Typer(help="GitHub authentication (device flow).", no_args_is_help=True)
app.add_typer(auth_app, name="auth")

checkpoint_app = typer.Typer(help="Manage release checkpoints.", no_args_is_help=True)
app.add_typer(checkpoint_app, name="checkpoint")

compliance_app = typer.Typer(help="Compliance reporting.", no_args_is_help=True)
app.add_typer(compliance_app, name="compliance")

mcp_app = typer.Typer(help="MCP (Model Context Protocol) server.", invoke_without_command=True)
app.add_typer(mcp_app, name="mcp")

# Lazy-initialized registry
_registry: Optional[SandboxRegistry] = None


def _ensure_lasso_dir() -> Path:
    """Ensure ~/.lasso/ and ~/.lasso/profiles/ directories exist.

    Returns the path to ~/.lasso/.
    """
    lasso_home = Path.home() / ".lasso"
    lasso_home.mkdir(parents=True, exist_ok=True)
    (lasso_home / "profiles").mkdir(exist_ok=True)
    return lasso_home


def _get_registry(native: bool = False, quiet: bool = False) -> SandboxRegistry:
    """Get or create the sandbox registry with auto-detected backend."""
    global _registry
    _ensure_lasso_dir()
    if _registry is None:
        backend = None
        if not native:
            from lasso.backends.detect import detect_backend
            backend = detect_backend()
            if backend and not quiet:
                info = backend.get_info()
                runtime = info.get("runtime", "container")
                ver = info.get("version", "")
                console.print(f"[dim]Backend: {runtime} {ver}[/dim]")
        _registry = SandboxRegistry(backend=backend)
    return _registry


def _resolve_profile(
    profile_name: str,
    working_dir: str,
    file: Optional[str] = None,
    quiet: bool = False,
) -> SandboxProfile:
    """Resolve a profile from name, file, or .lasso/ directory."""
    # Check for --file flag
    if file:
        return load_profile_from_path(file)

    # Check for .lasso/profile.toml in working dir
    local_profile = Path(working_dir) / ".lasso" / "profile.toml"
    if profile_name == "auto" and local_profile.exists():
        if not quiet:
            console.print(f"[dim]Using local profile: {local_profile}[/dim]")
        return load_profile_from_path(local_profile)

    # Check builtins
    if profile_name in BUILTIN_PROFILES:
        return BUILTIN_PROFILES[profile_name](working_dir)

    # Check saved profiles
    try:
        return load_profile(profile_name)
    except FileNotFoundError:
        err_console.print(f"[red]Error: Profile '{profile_name}' not found.[/red]")
        err_console.print(f"[dim]Builtins: {', '.join(BUILTIN_PROFILES.keys())}[/dim]")
        err_console.print("[dim]Run 'lasso profile list' to see available profiles.[/dim]")
        raise typer.Exit(1)


def _apply_extra_env(
    profile: SandboxProfile,
    env_vars: Optional[list[str]],
    pass_env: Optional[list[str]],
) -> None:
    """Merge --env and --pass-env values into profile.extra_env."""
    if env_vars:
        for item in env_vars:
            if "=" not in item:
                err_console.print(f"[red]Error: Invalid --env value (expected KEY=VALUE): {item}[/red]")
                raise typer.Exit(1)
            key, _, value = item.partition("=")
            profile.extra_env[key] = value
    if pass_env:
        for name in pass_env:
            value = os.environ.get(name)
            if value is None:
                err_console.print(f"[yellow]Warning: --pass-env '{name}' is not set in host environment, skipping.[/yellow]")
            else:
                profile.extra_env[name] = value


# -----------------------------------------------------------------------
# Doctor (comprehensive diagnostics)
# -----------------------------------------------------------------------

@app.command()
def doctor(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
    fix: bool = typer.Option(False, "--fix", help="Attempt to fix issues automatically."),
):
    """Run comprehensive system diagnostics.

    Checks everything needed for LASSO to function correctly and
    reports issues with remediation hints.

    Checks include: Python version, container runtime, permissions,
    LASSO directory, API keys, signing key location, profile validation,
    network tools, disk space, and state file.

    Use --fix to auto-create ~/.lasso/ and generate an API key if missing.
    Use --json for structured output suitable for scripting.
    """
    from lasso.cli.doctor import run_doctor

    report = run_doctor(output_json=output_json, fix=fix, console=console)
    if report.failed:
        raise typer.Exit(1)


# -----------------------------------------------------------------------
# System check
# -----------------------------------------------------------------------

@app.command()
def check(
    output_json: bool = typer.Option(False, "--json", help="Output results as JSON."),
    security_audit: bool = typer.Option(False, "--security-audit", "-s", help="Run security audit against a profile."),
    profile_name: Optional[str] = typer.Option(None, "--profile", "-p", help="Profile to audit (default: development)."),
    generate_checklist: bool = typer.Option(False, "--generate-checklist", help="Output Markdown checklist for manual review."),
    sign_off: Optional[str] = typer.Option(None, "--sign-off", help="Record a reviewer sign-off (name of reviewer)."),
):
    """Check system capabilities and container runtime.

    Verifies that a container runtime (Docker or Podman) is available,
    lists detected AI agents, and checks platform-specific capabilities.

    With --security-audit, runs security checks against a sandbox profile.
    With --generate-checklist, outputs a Markdown checklist for human review.
    With --sign-off <name>, records a reviewer sign-off in REVIEWERS.md.
    """
    # Security audit mode
    if security_audit or generate_checklist or sign_off:
        _run_security_audit(
            profile_name=profile_name or "development",
            generate_checklist=generate_checklist,
            sign_off_name=sign_off,
            output_json=output_json,
        )
        return

    if output_json:
        _check_json()
        return

    with console.status("[bold blue]Checking system capabilities..."):
        check_data = _collect_check_data()

    console.print(Panel.fit(
        "[bold]LASSO System Capability Check[/bold]",
        border_style="blue",
    ))

    # Platform info
    table = Table(show_header=True, title="System")
    table.add_column("Property", style="bold")
    table.add_column("Value")
    table.add_row("Platform", check_data["platform"]["system"])
    table.add_row("Architecture", check_data["platform"]["architecture"])
    table.add_row("Python", check_data["platform"]["python"])
    table.add_row("LASSO", check_data["platform"]["lasso"])

    # Version / checkpoint row
    ver_info = check_data.get("version", {})
    latest_cp = ver_info.get("latest_checkpoint")
    pinned = ver_info.get("pinned_version")
    if latest_cp:
        version_val = f"{__version__} (latest checkpoint: {latest_cp})"
        if ver_info.get("update_available"):
            version_val += " [yellow]update available[/yellow]"
    else:
        version_val = __version__
    if pinned:
        version_val += f" [cyan](pinned: {pinned})[/cyan]"
    table.add_row("Version", version_val)

    console.print(table)
    console.print()

    # Container runtime
    table = Table(show_header=True, title="Container Runtime")
    table.add_column("Property", style="bold")
    table.add_column("Status")

    rt = check_data["container_runtime"]
    if rt["available"]:
        table.add_row("Runtime", f"[green]{rt.get('runtime', 'unknown')}[/green]")
        table.add_row("Version", rt.get("version", "unknown"))
        table.add_row("OS", rt.get("os", "unknown"))
        table.add_row("Storage", rt.get("storage_driver", "unknown"))
        table.add_row("Status", "[green]Available[/green]")
    else:
        table.add_row("Runtime", "[red]Not found[/red]")
        table.add_row("Status", "[red]Unavailable[/red]")
        table.add_row("Action", "Install Docker or Podman, then run 'lasso check'.")

    console.print(table)

    # AI Agents
    console.print()
    at = Table(show_header=True, title="AI Agent Support")
    at.add_column("Agent", style="bold")
    at.add_column("Status")
    at.add_column("Version")
    at.add_column("Priority")
    for i, a in enumerate(check_data["agents"]):
        installed = "[green]Installed[/green]" if a["installed"] else "[dim]Not found[/dim]"
        ver = a.get("version") or "-"
        priority = "[bold cyan]Default[/bold cyan]" if i == 0 else str(i + 1)
        at.add_row(a["name"], installed, ver, priority)
    console.print(at)

    # Linux namespace capabilities (only on Linux)
    ns = check_data.get("namespaces")
    if ns:
        console.print()
        ns_table = Table(show_header=True, title="Linux Namespaces (bonus)")
        ns_table.add_column("Capability", style="bold")
        ns_table.add_column("Status")

        for key, label in [
            ("user_ns", "User Namespaces"),
            ("mount_ns", "Mount Namespaces"),
            ("pid_ns", "PID Namespaces"),
            ("net_ns", "Network Namespaces"),
            ("cgroups_v2", "Cgroups v2"),
        ]:
            available = ns.get(key, False)
            status = "[green]Available[/green]" if available else "[dim]Unavailable[/dim]"
            ns_table.add_row(label, status)

        console.print(ns_table)


def _collect_check_data() -> dict:
    """Collect all system check data into a dict."""
    data: dict = {
        "platform": {
            "system": platform.system(),
            "architecture": platform.machine(),
            "python": platform.python_version(),
            "lasso": __version__,
        },
    }

    # Container runtime
    from lasso.backends.detect import detect_backend
    backend = detect_backend()
    if backend:
        info = backend.get_info()
        data["container_runtime"] = {
            "available": True,
            **info,
        }
    else:
        data["container_runtime"] = {"available": False}

    # AI Agents
    from lasso.agents.registry import list_agents
    data["agents"] = list_agents()

    # Linux namespaces
    if platform.system() == "Linux":
        from lasso.core.namespace import NamespaceManager
        data["namespaces"] = NamespaceManager.check_capabilities()

    # Checkpoint version info
    from lasso.core.checkpoint import CheckpointStore
    cp_store = CheckpointStore()
    latest = cp_store.latest_checkpoint()
    pinned = cp_store.get_pinned_version()
    update = cp_store.check_for_update(__version__)
    data["version"] = {
        "current": __version__,
        "pinned_version": pinned,
        "latest_checkpoint": latest.version if latest else None,
        "update_available": update.version if update else None,
    }

    return data


def _check_json():
    """Output check results as JSON."""
    data = _collect_check_data()
    console.print_json(json.dumps(data, indent=2))


def _run_security_audit(
    profile_name: str,
    generate_checklist: bool,
    sign_off_name: Optional[str],
    output_json: bool,
) -> None:
    """Run a security audit against a sandbox profile."""
    from datetime import datetime, timezone

    from lasso.core.security_audit import (
        ReviewSignoff,
        SecurityAuditor,
        compute_profile_hash,
        save_signoff,
    )

    # Resolve the profile (builtin or saved)
    if profile_name in BUILTIN_PROFILES:
        profile = BUILTIN_PROFILES[profile_name]("/tmp/lasso-audit")
    else:
        try:
            profile = load_profile(profile_name)
        except FileNotFoundError:
            err_console.print(f"[red]Error: Profile '{profile_name}' not found.[/red]")
            err_console.print(f"[dim]Builtins: {', '.join(BUILTIN_PROFILES.keys())}[/dim]")
            err_console.print("[dim]Run 'lasso profile list' to see available profiles.[/dim]")
            raise typer.Exit(1)

    auditor = SecurityAuditor(profile)

    # Generate checklist mode
    if generate_checklist:
        console.print(auditor.generate_checklist())
        return

    # Run all checks
    results = auditor.run_all_checks()
    summary = auditor.summary()

    # JSON output mode
    if output_json:
        json_data = {
            "profile": profile_name,
            "profile_hash": compute_profile_hash(profile)[:12],
            "summary": summary,
            "checks": [
                {
                    "id": c.id,
                    "name": c.name,
                    "severity": c.severity,
                    "passed": c.passed,
                    "details": c.details,
                }
                for c in results
            ],
        }
        console.print_json(json.dumps(json_data, indent=2))
        return

    # Rich table output
    profile_hash = compute_profile_hash(profile)[:12]
    console.print(Panel.fit(
        f"[bold]Security Audit: {profile_name}[/bold]  (hash: {profile_hash})",
        border_style="blue",
    ))

    severity_colors = {
        "critical": "red",
        "high": "yellow",
        "medium": "cyan",
        "low": "dim",
    }

    table = Table(show_header=True, title="Security Checks")
    table.add_column("Status", width=6, justify="center")
    table.add_column("Severity", width=10)
    table.add_column("Check", min_width=25)
    table.add_column("Details")

    for check in results:
        status = "[green]PASS[/green]" if check.passed else "[red]FAIL[/red]"
        color = severity_colors.get(check.severity, "white")
        severity = f"[{color}]{check.severity.upper()}[/{color}]"
        table.add_row(status, severity, check.name, check.details)

    console.print(table)

    # Summary line
    console.print()
    if summary["failed"] == 0:
        console.print(
            f"[green]All {summary['total']} checks passed.[/green]"
        )
    else:
        console.print(
            f"[red]{summary['failed']} of {summary['total']} checks failed.[/red]"
        )
        if summary.get("critical_failed", 0) > 0:
            console.print(
                f"[bold red]{summary['critical_failed']} CRITICAL failure(s) "
                f"-- profile is not safe for deployment.[/bold red]"
            )

    # Sign-off mode
    if sign_off_name:
        reviewers_path = Path("REVIEWERS.md")
        signoff = ReviewSignoff(
            reviewer=sign_off_name,
            date=datetime.now(timezone.utc).strftime("%Y-%m-%d"),
            profile_hash=compute_profile_hash(profile),
            version=profile.version,
            checks_passed=summary["passed"],
            checks_total=summary["total"],
            approved=summary["failed"] == 0,
        )
        save_signoff(signoff, reviewers_path)
        console.print()
        approved_str = "[green]APPROVED[/green]" if signoff.approved else "[red]NOT APPROVED[/red]"
        console.print(
            f"Sign-off recorded: {sign_off_name} -- {approved_str}"
        )
        console.print(f"Written to: {reviewers_path.resolve()}")


# -----------------------------------------------------------------------
# Init
# -----------------------------------------------------------------------

@app.command()
def init(
    profile_name: str = typer.Option("development", "--profile", "-p", help="Profile template."),
    working_dir: str = typer.Option(".", "--dir", "-d", help="Project directory."),
    agent: Optional[str] = typer.Option(None, "--agent", "-a", help="Agent: opencode, claude-code, copilot, cursor, aider, goose, gemini-cli, codex, or auto."),
):
    """Initialize a project directory with LASSO sandbox config and agent configs.

    Creates a .lasso/ directory with a profile.toml and agent-specific config
    files. If no --agent is specified, auto-detects the best available agent.

    Example:
        lasso init --profile data-analysis --dir ./my-project
    """
    working_dir = str(Path(working_dir).resolve())
    lasso_dir = Path(working_dir) / ".lasso"

    if (lasso_dir / "profile.toml").exists():
        err_console.print(f"[yellow]Already initialized:[/yellow] {lasso_dir}/profile.toml")
        err_console.print("[dim]Edit it directly or delete .lasso/ to reinitialize.[/dim]")
        raise typer.Exit(1)

    if profile_name not in BUILTIN_PROFILES:
        err_console.print(f"[red]Error: Unknown profile '{profile_name}'.[/red]")
        err_console.print(f"[dim]Available: {', '.join(BUILTIN_PROFILES.keys())}[/dim]")
        err_console.print("[dim]Run 'lasso profile list' to see all profiles.[/dim]")
        raise typer.Exit(1)

    with console.status("[bold blue]Initializing project..."):
        lasso_dir.mkdir(parents=True, exist_ok=True)
        (lasso_dir / "audit").mkdir(exist_ok=True)

        profile = BUILTIN_PROFILES[profile_name](working_dir)
        profile.audit.log_dir = str(lasso_dir / "audit")
        save_profile(profile, profile_dir=lasso_dir)

        # Rename to profile.toml
        src = lasso_dir / f"{profile.name}.toml"
        dest = lasso_dir / "profile.toml"
        if src.exists():
            src.rename(dest)

        # Generate agent-specific configs
        from lasso.agents.base import AgentType
        from lasso.agents.registry import detect_agent, get_provider, write_agent_config

        if agent and agent != "auto":
            try:
                provider = get_provider(AgentType(agent))
            except ValueError:
                err_console.print(f"[red]Error: Unknown agent '{agent}'.[/red]")
                err_console.print(
                    "[dim]Supported: opencode, claude-code, copilot, "
                    "cursor, aider, goose, gemini-cli, codex, vscode[/dim]"
                )
                raise typer.Exit(1)
        else:
            provider = detect_agent()

        agent_name = "none"
        written_files: list = []
        if provider:
            agent_config = provider.generate_config(profile)
            written_files = write_agent_config(agent_config, working_dir)
            agent_name = provider.display_name

    for f in written_files:
        console.print(f"  [dim]Agent config: {f}[/dim]")

    console.print(Panel.fit(
        f"[bold green]LASSO initialized[/bold green]\n\n"
        f"  Profile:     {profile_name}\n"
        f"  Agent:       {agent_name}\n"
        f"  Config:      {dest}\n"
        f"  Audit dir:   {lasso_dir / 'audit'}\n"
        f"  Working dir: {working_dir}\n\n"
        f"  Commands:    {profile.commands.mode.value} "
        f"({len(profile.commands.whitelist)} tools)\n"
        f"  Network:     {profile.network.mode.value}\n"
        f"  Memory:      {profile.resources.max_memory_mb}MB\n\n"
        f"Next: [bold]lasso create auto --dir {working_dir}[/bold]",
        border_style="green",
        title="LASSO",
    ))


# -----------------------------------------------------------------------
# Quickstart
# -----------------------------------------------------------------------

@app.command()
def quickstart(
    working_dir: str = typer.Option(".", "--dir", "-d", help="Project directory."),
):
    """One-command setup: detect agent, create profile, start sandbox.

    Equivalent to: lasso init && lasso run auto
    """
    import time as _time

    working_dir = str(Path(working_dir).resolve())
    lasso_dir = Path(working_dir) / ".lasso"
    _ensure_lasso_dir()

    # Step 1: Auto-detect the best available agent
    from lasso.agents.registry import detect_agent, write_agent_config

    provider = detect_agent()
    agent_name = provider.display_name if provider else "none"
    console.print(f"[dim]Detected agent: {agent_name}[/dim]")

    # Step 2: Initialize if not already done
    profile_name = "development"
    if (lasso_dir / "profile.toml").exists():
        console.print(f"[dim]Already initialized: {lasso_dir / 'profile.toml'}[/dim]")
    else:
        with console.status("[bold blue]Initializing project..."):
            lasso_dir.mkdir(parents=True, exist_ok=True)
            (lasso_dir / "audit").mkdir(exist_ok=True)

            profile = BUILTIN_PROFILES[profile_name](working_dir)
            profile.audit.log_dir = str(lasso_dir / "audit")
            save_profile(profile, profile_dir=lasso_dir)

            # Rename to profile.toml
            src = lasso_dir / f"{profile.name}.toml"
            dest = lasso_dir / "profile.toml"
            if src.exists():
                src.rename(dest)

            # Write agent config files
            if provider:
                agent_config = provider.generate_config(profile)
                write_agent_config(agent_config, working_dir)

        console.print(f"[green]Initialized with '{profile_name}' profile.[/green]")

    # Step 3: Create and start sandbox
    profile = _resolve_profile("auto", working_dir, quiet=True)
    registry = _get_registry(quiet=False)

    t0 = _time.monotonic()

    with console.status("[bold blue]Creating sandbox..."):
        sandbox = registry.create(profile)

    with console.status("[bold blue]Starting sandbox..."):
        sandbox.start()

    elapsed_ms = int((_time.monotonic() - t0) * 1000)

    console.print(Panel.fit(
        f"[bold green]Ready to go![/bold green]\n\n"
        f"  Sandbox:     [bold cyan]{sandbox.id}[/bold cyan]\n"
        f"  Agent:       {agent_name}\n"
        f"  Profile:     {profile_name}\n"
        f"  Working dir: {working_dir}\n"
        f"  Started in:  {elapsed_ms}ms\n\n"
        f"[bold]Next steps:[/bold]\n"
        f"  Run a command:    [bold]lasso exec {sandbox.id} -- ls -la[/bold]\n"
        f"  Interactive REPL: [bold]lasso interactive auto --dir {working_dir}[/bold]\n"
        f"  View status:      [bold]lasso status[/bold]\n"
        f"  Stop sandbox:     [bold]lasso stop {sandbox.id}[/bold]",
        border_style="green",
        title="LASSO Quickstart",
    ))


# -----------------------------------------------------------------------
# Sandbox lifecycle
# -----------------------------------------------------------------------

@app.command()
def create(
    profile_name: str = typer.Argument("auto", help="Profile name (builtin, saved, or 'auto' to use .lasso/profile.toml)."),
    working_dir: str = typer.Option(".", "--dir", "-d", help="Working directory."),
    file: Optional[str] = typer.Option(None, "--file", "-f", help="Load profile from TOML file."),
    native: bool = typer.Option(False, "--native", help="Use native mode (no container)."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Print only the sandbox ID."),
    mode_str: Optional[str] = typer.Option(None, "--mode", "-m", help="Profile mode: observe, assist, or autonomous."),
    env_vars: Optional[list[str]] = typer.Option(None, "--env", "-e", help="Pass environment variable (KEY=VALUE). Repeatable."),
    pass_env: Optional[list[str]] = typer.Option(None, "--pass-env", help="Pass host env var into sandbox by name. Repeatable."),
    isolation: Optional[str] = typer.Option(None, "--isolation", "-I", help="Isolation level: container (default), gvisor, or kata."),
):
    """Create a new sandbox from a profile.

    If profile is 'auto' (default), reads from .lasso/profile.toml in the
    working directory. Use 'lasso init' to set up a project first.

    Examples:
        lasso create                       # auto-resolve from .lasso/
        lasso create development --dir .   # use builtin profile
        lasso create --file custom.toml    # use TOML file
        lasso create --quiet               # print only sandbox ID
        lasso create --mode autonomous     # start in autonomous mode
    """
    working_dir = str(Path(working_dir).resolve())
    profile = _resolve_profile(profile_name, working_dir, file, quiet=quiet)

    # Override profile mode if --mode flag was provided
    if mode_str:
        try:
            profile.mode = ProfileMode(mode_str)
        except ValueError:
            err_console.print(f"[red]Error: Invalid mode '{mode_str}'.[/red]")
            err_console.print("[dim]Valid modes: observe, assist, autonomous[/dim]")
            raise typer.Exit(1)

    _apply_extra_env(profile, env_vars, pass_env)

    # Override isolation level if --isolation flag was provided
    if isolation:
        if isolation not in ("container", "gvisor", "kata"):
            err_console.print(f"[red]Error: Invalid isolation level '{isolation}'.[/red]")
            err_console.print("[dim]Valid levels: container, gvisor, kata[/dim]")
            raise typer.Exit(1)
        profile.isolation = isolation

    # Check for newer checkpoint after profile resolution
    if not quiet:
        from lasso.core.checkpoint import CheckpointStore
        _cp_store = CheckpointStore()
        _update = _cp_store.check_for_update(__version__)
        if _update:
            console.print(
                f"[yellow]LASSO v{_update.version} is available "
                f"(current: v{__version__}). "
                f"Run 'lasso checkpoint list' for details.[/yellow]"
            )

    registry = _get_registry(native=native, quiet=quiet)

    import time as _time

    if quiet:
        t0 = _time.monotonic()
        sandbox = registry.create(profile)
        sandbox.start()
        elapsed_ms = int((_time.monotonic() - t0) * 1000)
        if getattr(sandbox, "_warm_claimed", False):
            console.print(f"{sandbox.id}  # warm pool ({elapsed_ms}ms)", highlight=False)
        else:
            console.print(sandbox.id)
        return

    t0 = _time.monotonic()

    with console.status("[bold blue]Creating sandbox..."):
        sandbox = registry.create(profile)

    with console.status("[bold blue]Starting sandbox..."):
        sandbox.start()

    elapsed_ms = int((_time.monotonic() - t0) * 1000)
    warm_note = ""
    if getattr(sandbox, "_warm_claimed", False):
        warm_note = f"\n  [bold yellow]Warm pool hit ({elapsed_ms}ms)[/bold yellow]"

    console.print(Panel.fit(
        f"[bold green]Sandbox created and running[/bold green]\n\n"
        f"  ID:          [bold cyan]{sandbox.id}[/bold cyan]\n"
        f"  Name:        {profile.name}\n"
        f"  Mode:        {sandbox.mode.value}\n"
        f"  Working dir: {working_dir}\n"
        f"  Backend:     {sandbox.status()['backend']}\n"
        f"  Commands:    {profile.commands.mode.value}\n"
        f"  Network:     {profile.network.mode.value}\n"
        f"  Audit log:   {sandbox.audit.log_file}"
        f"{warm_note}\n\n"
        f"Run commands: [bold]lasso exec {sandbox.id} -- ls[/bold]\n"
        f"Set mode:     [bold]lasso mode {sandbox.id} autonomous[/bold]\n"
        f"Interactive:  [bold]lasso interactive {profile_name} --dir {working_dir}[/bold]",
        border_style="green",
        title="LASSO",
    ))


# Smart run: `lasso run <agent>` or `lasso run <profile>`
@app.command(name="run")
def run_cmd(
    target: str = typer.Argument("auto", help="Agent name (claude, cursor, aider, ...) or profile name."),
    working_dir: str = typer.Option(".", "--dir", "-d", help="Working directory."),
    file: Optional[str] = typer.Option(None, "--file", "-f", help="Load profile from TOML file."),
    native: bool = typer.Option(False, "--native", help="Use native mode."),
    quiet: bool = typer.Option(False, "--quiet", "-q", help="Print only the sandbox ID."),
    mode_str: Optional[str] = typer.Option(None, "--mode", "-m", help="Profile mode: observe, assist, or autonomous."),
    agent_override: Optional[str] = typer.Option(None, "--agent", "-a", help="Override agent type."),
    env_vars: Optional[list[str]] = typer.Option(None, "--env", "-e", help="Pass environment variable (KEY=VALUE). Repeatable."),
    pass_env: Optional[list[str]] = typer.Option(None, "--pass-env", help="Pass host env var into sandbox by name. Repeatable."),
    isolation: Optional[str] = typer.Option(None, "--isolation", "-I", help="Isolation level: container (default), gvisor, or kata."),
):
    """Create a sandbox -- accepts agent names or profile names.

    Zero-config agent mode:
        lasso run claude-code         # auto-selects development profile
        lasso run cursor              # auto-selects development profile
        lasso run aider --dir .       # sandbox in current dir
        lasso run codex               # auto-selects development profile

    Profile mode (backward compatible):
        lasso run development --dir . # use builtin profile
        lasso run offline             # use offline profile

    Agents: claude, copilot, cursor, aider, goose, gemini, codex, opencode
    """
    from lasso.agents.registry import (
        AGENT_DEFAULT_PROFILES,
        get_provider,
        resolve_agent_alias,
        write_agent_config,
    )

    working_dir = str(Path(working_dir).resolve())
    resolved_agent_type = resolve_agent_alias(target)

    if resolved_agent_type:
        profile_name = AGENT_DEFAULT_PROFILES.get(resolved_agent_type, "development")
        profile = _resolve_profile(profile_name, working_dir, file, quiet=quiet)

        provider = get_provider(resolved_agent_type)
        if not quiet:
            console.print(f"[dim]Agent: {provider.display_name}[/dim]")

        agent_config = provider.generate_config(profile)
        written_files = write_agent_config(agent_config, working_dir)
        if not quiet:
            for f in written_files:
                console.print(f"  [dim]Agent config: {f}[/dim]")
    else:
        profile_name = target
        profile = _resolve_profile(profile_name, working_dir, file, quiet=quiet)

        if agent_override:
            from lasso.agents.base import AgentType as AT
            try:
                provider = get_provider(AT(agent_override))
                agent_config = provider.generate_config(profile)
                written_files = write_agent_config(agent_config, working_dir)
                if not quiet:
                    for f in written_files:
                        console.print(f"  [dim]Agent config: {f}[/dim]")
            except ValueError:
                err_console.print(f"[red]Error: Unknown agent '{agent_override}'.[/red]")

    # Apply --env and --pass-env
    _apply_extra_env(profile, env_vars, pass_env)

    # Override isolation level
    if isolation:
        if isolation not in ("container", "gvisor", "kata"):
            err_console.print(f"[red]Error: Invalid isolation level '{isolation}'.[/red]")
            err_console.print("[dim]Valid levels: container, gvisor, kata[/dim]")
            raise typer.Exit(1)
        profile.isolation = isolation

    if mode_str:
        try:
            profile.mode = ProfileMode(mode_str)
        except ValueError:
            err_console.print(f"[red]Error: Invalid mode '{mode_str}'.[/red]")
            err_console.print("[dim]Valid modes: observe, assist, autonomous[/dim]")
            raise typer.Exit(1)

    registry = _get_registry(native=native, quiet=quiet)

    import time as _time
    t0 = _time.monotonic()

    if quiet:
        sandbox = registry.create(profile)
        sandbox.start()
        elapsed_ms = int((_time.monotonic() - t0) * 1000)
        if getattr(sandbox, "_warm_claimed", False):
            console.print(f"{sandbox.id}  # warm pool ({elapsed_ms}ms)", highlight=False)
        else:
            console.print(sandbox.id)
        return

    with console.status("[bold blue]Creating sandbox..."):
        sandbox = registry.create(profile)

    with console.status("[bold blue]Starting sandbox..."):
        sandbox.start()

    elapsed_ms = int((_time.monotonic() - t0) * 1000)
    warm_note = ""
    if getattr(sandbox, "_warm_claimed", False):
        warm_note = f"\n  [bold yellow]Warm pool hit ({elapsed_ms}ms)[/bold yellow]"

    agent_display = ""
    if resolved_agent_type:
        agent_display = f"\n  Agent:       {provider.display_name}"

    console.print(Panel.fit(
        f"[bold green]Sandbox created and running[/bold green]\n\n"
        f"  ID:          [bold cyan]{sandbox.id}[/bold cyan]\n"
        f"  Name:        {profile.name}\n"
        f"  Mode:        {sandbox.mode.value}\n"
        f"  Working dir: {working_dir}\n"
        f"  Backend:     {sandbox.status()['backend']}\n"
        f"  Commands:    {profile.commands.mode.value}\n"
        f"  Network:     {profile.network.mode.value}\n"
        f"  Audit log:   {sandbox.audit.log_file}"
        f"{agent_display}"
        f"{warm_note}\n\n"
        f"Run commands: [bold]lasso exec {sandbox.id} -- ls[/bold]\n"
        f"Stop:         [bold]lasso stop {sandbox.id}[/bold]",
        border_style="green",
        title="LASSO",
    ))


@app.command(name="exec")
def exec_cmd(
    sandbox_id: str = typer.Argument(help="Sandbox ID."),
    command: list[str] = typer.Argument(help="Command to execute."),
):
    """Execute a command inside a sandbox.

    Use '--' to separate lasso arguments from the sandbox command.

    Example:
        lasso exec abc123 -- ls -la
        lasso exec abc123 -- python3 script.py
    """
    registry = _get_registry()
    sandbox = registry.get(sandbox_id)
    if not sandbox:
        err_console.print(f"[red]Error: Sandbox '{sandbox_id}' not found.[/red]")
        err_console.print("[dim]Run 'lasso status' to see active sandboxes.[/dim]")
        raise typer.Exit(1)

    raw = " ".join(command)
    result = sandbox.exec(raw)

    if result.blocked:
        console.print(f"[red bold]BLOCKED[/red bold] {result.block_reason}")
        raise typer.Exit(1)

    if result.stdout:
        console.print(result.stdout, end="")
    if result.stderr:
        err_console.print(result.stderr, end="")
    if result.duration_ms > 0:
        console.print(f"[dim]({result.duration_ms}ms)[/dim]")

    raise typer.Exit(result.exit_code)


@app.command()
def status(
    sandbox_id: Optional[str] = typer.Argument(None, help="Sandbox ID (omit for all)."),
    output_json: bool = typer.Option(False, "--json", help="Output raw JSON."),
):
    """Show sandbox status.

    Without arguments, lists all active sandboxes. Pass a sandbox ID to
    see detailed status for a single sandbox.
    """
    registry = _get_registry(quiet=output_json)

    if sandbox_id:
        sandbox = registry.get(sandbox_id)
        if not sandbox:
            err_console.print(f"[red]Error: Sandbox '{sandbox_id}' not found.[/red]")
            err_console.print("[dim]Run 'lasso status' to see active sandboxes.[/dim]")
            raise typer.Exit(1)
        console.print_json(json.dumps(sandbox.status(), indent=2))
    else:
        sandboxes = registry.list_all()

        if output_json:
            console.print_json(json.dumps(sandboxes, indent=2))
            return

        if not sandboxes:
            console.print("[dim]No sandboxes running.[/dim]")
            return

        table = Table(title="LASSO Sandboxes", show_header=True)
        table.add_column("ID", style="bold cyan")
        table.add_column("Name")
        table.add_column("State")
        table.add_column("Mode")
        table.add_column("Backend")
        table.add_column("Cmds")
        table.add_column("Net")
        table.add_column("Execs")
        table.add_column("Blocked")

        for s in sandboxes:
            state_color = {
                "running": "green", "stopped": "dim", "error": "red",
            }.get(s["state"], "yellow")
            mode_color = {
                "observe": "blue", "assist": "yellow", "autonomous": "red",
            }.get(s.get("mode", "observe"), "dim")
            table.add_row(
                s["id"], s["name"],
                f"[{state_color}]{s['state']}[/{state_color}]",
                f"[{mode_color}]{s.get('mode', 'observe')}[/{mode_color}]",
                s.get("backend", "native"),
                s["command_mode"], s["network_mode"],
                str(s["exec_count"]), str(s["blocked_count"]),
            )

        console.print(table)


# Alias: lasso ps → lasso status
@app.command(name="ps", hidden=True)
def ps_alias(
    sandbox_id: Optional[str] = typer.Argument(None, help="Sandbox ID (omit for all)."),
    output_json: bool = typer.Option(False, "--json", help="Output raw JSON."),
):
    """Alias for 'status'. Show sandbox status."""
    status(sandbox_id=sandbox_id, output_json=output_json)


@app.command()
def stop(
    sandbox_id: str = typer.Argument(help="Sandbox ID, or 'all'."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
):
    """Stop a sandbox (or all sandboxes with 'all').

    Use --yes to skip the confirmation prompt for 'stop all'.
    """
    registry = _get_registry()
    if sandbox_id == "all":
        sandboxes = registry.list_all()
        count = len([s for s in sandboxes if s["state"] == "running"])
        if not yes:
            if count == 0:
                console.print("[dim]No running sandboxes to stop.[/dim]")
                return
            typer.confirm(f"Stop all {count} running sandbox(es)?", abort=True)
        stopped = registry.stop_all()
        console.print(f"[green]Stopped {stopped} sandbox(es).[/green]")
    else:
        if registry.stop(sandbox_id):
            console.print(f"[green]Sandbox {sandbox_id} stopped.[/green]")
        else:
            err_console.print(f"[red]Error: Sandbox '{sandbox_id}' not found.[/red]")
            err_console.print("[dim]Run 'lasso status' to see active sandboxes.[/dim]")
            raise typer.Exit(1)


# Alias: lasso rm → lasso stop
@app.command(name="rm", hidden=True)
def rm_alias(
    sandbox_id: str = typer.Argument(help="Sandbox ID, or 'all'."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
):
    """Alias for 'stop'. Stop a sandbox."""
    stop(sandbox_id=sandbox_id, yes=yes)


@app.command(name="mode")
def mode_cmd(
    sandbox_id: str = typer.Argument(help="Sandbox ID."),
    new_mode: str = typer.Argument(help="New mode: observe, assist, or autonomous."),
):
    """Change the profile mode of a running sandbox.

    Controls the level of command access:
      observe    - read-only commands only (ls, cat, grep, etc.)
      assist     - curated development commands (+ python3, git, pip, etc.)
      autonomous - full whitelist from the profile

    Example:
        lasso mode abc123 autonomous
    """
    try:
        target_mode = ProfileMode(new_mode)
    except ValueError:
        err_console.print(f"[red]Error: Invalid mode '{new_mode}'.[/red]")
        err_console.print("[dim]Valid modes: observe, assist, autonomous[/dim]")
        raise typer.Exit(1)

    registry = _get_registry()
    sandbox = registry.get(sandbox_id)
    if not sandbox:
        err_console.print(f"[red]Error: Sandbox '{sandbox_id}' not found.[/red]")
        err_console.print("[dim]Run 'lasso status' to see active sandboxes.[/dim]")
        raise typer.Exit(1)

    old_mode = sandbox.mode.value
    registry.set_mode(sandbox_id, target_mode)
    console.print(
        f"[green]Sandbox {sandbox_id} mode changed:[/green] "
        f"{old_mode} -> [bold]{target_mode.value}[/bold]"
    )


@app.command()
def interactive(
    profile_name: str = typer.Argument("auto", help="Profile to use."),
    working_dir: str = typer.Option(".", "--dir", "-d", help="Working directory."),
    native: bool = typer.Option(False, "--native", help="Use native mode."),
    env_vars: Optional[list[str]] = typer.Option(None, "--env", "-e", help="Pass environment variable (KEY=VALUE). Repeatable."),
    pass_env: Optional[list[str]] = typer.Option(None, "--pass-env", help="Pass host env var into sandbox by name. Repeatable."),
):
    """Start an interactive sandbox session (REPL)."""
    working_dir = str(Path(working_dir).resolve())
    profile = _resolve_profile(profile_name, working_dir)
    _apply_extra_env(profile, env_vars, pass_env)
    registry = _get_registry(native=native)

    with console.status("[bold blue]Creating sandbox..."):
        sandbox = registry.create(profile)

    with console.status("[bold blue]Starting sandbox..."):
        sandbox.start()

    backend_name = sandbox.status().get("backend", "native")
    console.print(Panel.fit(
        f"[bold]LASSO Interactive Sandbox[/bold]\n"
        f"Profile: {profile.name} | ID: {sandbox.id} | Backend: {backend_name}\n"
        f"Commands: {profile.commands.mode.value} | Network: {profile.network.mode.value}\n"
        f"Type [bold]exit[/bold] or Ctrl+D to stop. "
        f"[bold]status[/bold] / [bold]policy[/bold] / [bold]audit[/bold] for info.",
        border_style="blue",
    ))

    try:
        while True:
            try:
                raw = console.input(f"[bold blue]lasso:{sandbox.id[:6]}>[/bold blue] ")
            except EOFError:
                break

            raw = raw.strip()
            if not raw:
                continue
            if raw in ("exit", "quit"):
                break
            if raw == "status":
                console.print_json(json.dumps(sandbox.status(), indent=2))
                continue
            if raw == "policy":
                console.print_json(json.dumps(sandbox.command_gate.explain_policy(), indent=2))
                continue
            if raw == "audit":
                if sandbox.audit.log_file and sandbox.audit.log_file.exists():
                    from lasso.core.audit_verify import read_audit_entries
                    entries = read_audit_entries(sandbox.audit.log_file, tail=10)
                    for e in entries:
                        ts = e.get("ts", "")[:19]
                        action = e.get("action", "")
                        outcome = e.get("outcome", "")
                        oc = {"success": "green", "blocked": "red"}.get(outcome, "yellow")
                        console.print(f"  {ts} [{oc}]{outcome:>8}[/{oc}] {e['type']:>10} {action}")
                continue

            result = sandbox.exec(raw)

            if result.blocked:
                console.print(f"[red bold]BLOCKED[/red bold] {result.block_reason}")
            else:
                if result.stdout:
                    console.print(result.stdout, end="")
                if result.stderr:
                    err_console.print(f"[yellow]{result.stderr}[/yellow]", end="")
                if result.exit_code != 0:
                    console.print(f"[dim](exit code: {result.exit_code})[/dim]")
    finally:
        sandbox.stop()
        console.print(
            f"\n[dim]Sandbox {sandbox.id} stopped. "
            f"{sandbox._exec_count} commands executed, "
            f"{sandbox._blocked_count} blocked.[/dim]"
        )


# -----------------------------------------------------------------------
# Audit commands
# -----------------------------------------------------------------------

@audit_app.command(name="view")
def audit_view(
    log_file: str = typer.Argument(help="Path to audit log (.jsonl)."),
    tail: int = typer.Option(50, "--tail", "-n", help="Show last N entries."),
    event_type: Optional[str] = typer.Option(None, "--type", "-t", help="Filter by event type."),
    raw: bool = typer.Option(False, "--json", help="Output raw JSON."),
):
    """View audit log entries."""
    from lasso.core.audit_verify import read_audit_entries

    entries = read_audit_entries(log_file, tail=tail, event_type=event_type)
    if not entries:
        console.print("[dim]No entries found.[/dim]")
        return

    if raw:
        for e in entries:
            console.print_json(json.dumps(e))
        return

    table = Table(title=f"Audit Log ({len(entries)} entries)", show_header=True)
    table.add_column("Time", style="dim", width=19)
    table.add_column("Type", width=10)
    table.add_column("Action", max_width=30)
    table.add_column("Outcome", width=8)
    table.add_column("Detail", max_width=40)
    table.add_column("Sig", width=8)

    for e in entries:
        ts = e.get("ts", "")[:19]
        etype = e.get("type", "")
        action = e.get("action", "")
        outcome = e.get("outcome", "")
        detail = ""
        if e.get("detail"):
            d = e["detail"]
            if "reason" in d:
                detail = d["reason"][:40]
            elif "exit_code" in d:
                detail = f"exit={d['exit_code']}"
        sig = e.get("sig", "")[:8] if e.get("sig") else "none"

        oc = {"success": "green", "blocked": "red", "error": "yellow"}.get(outcome, "white")
        table.add_row(ts, etype, action, f"[{oc}]{outcome}[/{oc}]", detail, sig)

    console.print(table)


@audit_app.command(name="verify")
def audit_verify_cmd(
    log_file: str = typer.Argument(help="Path to audit log (.jsonl)."),
    key_file: Optional[str] = typer.Option(None, "--key", "-k", help="Path to signing key."),
):
    """Verify audit log integrity (HMAC chain)."""
    from lasso.core.audit_verify import verify_audit_log

    result = verify_audit_log(log_file, key_path=key_file)

    if result.valid:
        console.print(Panel.fit(
            f"[bold green]INTEGRITY VERIFIED[/bold green]\n\n"
            f"  Entries:  {result.total_entries}\n"
            f"  Verified: {result.verified_entries}\n"
            f"  Chain:    Unbroken\n\n"
            f"  All HMAC signatures match. No tampering detected.",
            border_style="green",
            title="Audit Verification",
        ))
    else:
        console.print(Panel.fit(
            f"[bold red]VERIFICATION FAILED[/bold red]\n\n"
            f"  Entries:     {result.total_entries}\n"
            f"  Verified:    {result.verified_entries}\n"
            f"  First break: line {result.first_break_at}\n"
            f"  Errors:      {len(result.errors)}",
            border_style="red",
            title="Audit Verification",
        ))
        for err in result.errors[:10]:
            err_console.print(f"  [red]{err}[/red]")
        if len(result.errors) > 10:
            err_console.print(f"  ... and {len(result.errors) - 10} more")
        raise typer.Exit(1)


@audit_app.command(name="export")
def audit_export(
    log_file: str = typer.Argument(help="Path to audit log (.jsonl)."),
    format: str = typer.Option("json", "--format", "-f", help="Export format: json, csv."),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Output file (stdout if omitted)."),
):
    """Export audit log to JSON or CSV for compliance review."""
    from lasso.core.audit_verify import read_audit_entries

    entries = read_audit_entries(log_file)
    if not entries:
        err_console.print("[dim]No entries to export.[/dim]")
        return

    if format == "json":
        data = json.dumps(entries, indent=2)
        if output:
            Path(output).write_text(data)
            console.print(f"[green]Exported {len(entries)} entries to {output}[/green]")
        else:
            console.print(data)

    elif format == "csv":
        buf = io.StringIO()
        fieldnames = ["event_id", "ts", "sandbox_id", "type", "actor", "action",
                       "target", "outcome", "sig"]
        writer = csv.DictWriter(buf, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for e in entries:
            writer.writerow(e)

        if output:
            Path(output).write_text(buf.getvalue())
            console.print(f"[green]Exported {len(entries)} entries to {output}[/green]")
        else:
            console.print(buf.getvalue())
    else:
        err_console.print(f"[red]Error: Unknown format '{format}'.[/red]")
        err_console.print("[dim]Valid formats: json, csv[/dim]")
        raise typer.Exit(1)


# -----------------------------------------------------------------------
# Profile management
# -----------------------------------------------------------------------

@profile_app.command(name="list")
def profile_list(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON array."),
):
    """List all saved and builtin profiles."""
    if output_json:
        result = []
        for name, factory in BUILTIN_PROFILES.items():
            p = factory(str(Path(tempfile.gettempdir()) / "lasso-example"))
            result.append({
                "name": name,
                "type": "builtin",
                "description": p.description,
                "command_mode": p.commands.mode.value,
                "network_mode": p.network.mode.value,
            })
        for p in list_profiles():
            p["type"] = "saved"
            result.append(p)
        console.print_json(json.dumps(result, indent=2))
        return

    # Builtins
    console.print("[bold]Builtin Profiles:[/bold]")
    bt = Table(show_header=True)
    bt.add_column("Name", style="bold cyan")
    bt.add_column("Description")
    bt.add_column("Commands")
    bt.add_column("Network")
    for name, factory in BUILTIN_PROFILES.items():
        p = factory(str(Path(tempfile.gettempdir()) / "lasso-example"))
        bt.add_row(name, p.description[:60], p.commands.mode.value, p.network.mode.value)
    console.print(bt)

    # Saved
    profiles = list_profiles()
    if profiles:
        console.print("\n[bold]Saved Profiles:[/bold]")
        st = Table(show_header=True)
        st.add_column("Name", style="bold")
        st.add_column("Working Dir")
        st.add_column("Commands")
        st.add_column("Network")
        st.add_column("Hash")
        for p in profiles:
            if "error" in p:
                st.add_row(p["name"], f"[red]{p['error']}[/red]", "", "", "")
            else:
                st.add_row(p["name"], p["working_dir"], p["cmd_mode"], p["net_mode"], p["hash"])
        console.print(st)


@profile_app.command(name="show")
def profile_show(name: str = typer.Argument(help="Profile name.")):
    """Show profile details."""
    if name in BUILTIN_PROFILES:
        profile = BUILTIN_PROFILES[name](str(Path(tempfile.gettempdir()) / "lasso-example"))
    else:
        try:
            profile = load_profile(name)
        except FileNotFoundError:
            err_console.print(f"[red]Error: Profile '{name}' not found.[/red]")
            err_console.print("[dim]Run 'lasso profile list' to see available profiles.[/dim]")
            raise typer.Exit(1)

    console.print_json(profile.model_dump_json(indent=2))


@profile_app.command(name="save")
def profile_save(
    name: str = typer.Argument(help="Name for the profile."),
    template: str = typer.Option("minimal", "--from", "-t", help="Builtin template."),
    working_dir: str = typer.Option(".", "--dir", "-d", help="Working directory."),
):
    """Save a new profile based on a builtin template."""
    if template not in BUILTIN_PROFILES:
        err_console.print(f"[red]Error: Unknown template '{template}'.[/red]")
        err_console.print(f"[dim]Available: {', '.join(BUILTIN_PROFILES.keys())}[/dim]")
        err_console.print("[dim]Run 'lasso profile list' to see available profiles.[/dim]")
        raise typer.Exit(1)

    working_dir = str(Path(working_dir).resolve())
    profile = BUILTIN_PROFILES[template](working_dir, name=name)
    path = save_profile(profile)
    console.print(f"[green]Profile saved:[/green] {path}")


@profile_app.command(name="delete")
def profile_delete(
    name: str = typer.Argument(help="Profile to delete."),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation prompt."),
):
    """Delete a saved profile."""
    if not yes:
        typer.confirm(f"Delete profile '{name}'?", abort=True)

    if delete_profile(name):
        console.print(f"[green]Profile '{name}' deleted.[/green]")
    else:
        err_console.print(f"[red]Error: Profile '{name}' not found.[/red]")
        err_console.print("[dim]Run 'lasso profile list' to see available profiles.[/dim]")
        raise typer.Exit(1)


@profile_app.command(name="install")
def profile_install(
    name: str = typer.Argument(help="Community profile name to install."),
):
    """Install a community profile from the LASSO profile pack.

    Copies a bundled community profile to ~/.lasso/profiles/ so it can be
    used with 'lasso create <name>' or 'lasso interactive <name>'.

    Available profiles: frontend-dev, data-science, ci-runner,
    banking-norway, healthcare.

    Example:
        lasso profile install frontend-dev
        lasso create frontend-dev --dir .
    """
    import importlib.resources
    import shutil

    # Locate the bundled profiles directory
    try:
        profiles_pkg = importlib.resources.files("lasso") / "profiles"
    except (TypeError, AttributeError):
        # Fallback for older Python versions
        profiles_pkg = Path(__file__).resolve().parent.parent / "profiles"

    source = Path(str(profiles_pkg)) / f"{name}.toml"
    if not source.exists():
        # Also check the project-root profiles/ directory (development installs)
        project_root = Path(__file__).resolve().parent.parent.parent / "profiles"
        source = project_root / f"{name}.toml"

    if not source.exists():
        err_console.print(f"[red]Error: Community profile '{name}' not found.[/red]")
        # List available profiles
        available = []
        for search_dir in [
            Path(str(profiles_pkg)),
            Path(__file__).resolve().parent.parent.parent / "profiles",
        ]:
            if search_dir.exists():
                available.extend(p.stem for p in search_dir.glob("*.toml"))
        available = sorted(set(available))
        if available:
            err_console.print(f"[dim]Available: {', '.join(available)}[/dim]")
        raise typer.Exit(1)

    # Validate the profile before copying
    try:
        profile = load_profile_from_path(source)
    except Exception as e:
        err_console.print(f"[red]Error: Profile '{name}' is invalid: {e}[/red]")
        raise typer.Exit(1)

    dest_dir = Path.home() / ".lasso" / "profiles"
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / f"{name}.toml"

    shutil.copy2(str(source), str(dest))

    console.print(
        f"[green]Profile '{name}' installed to:[/green] {dest}\n"
        f"\n"
        f"  Use it:  [bold]lasso create {name} --dir .[/bold]\n"
        f"  Details: [bold]lasso profile show {name}[/bold]\n"
        f"  Edit:    {dest}"
    )


@profile_app.command(name="export")
def profile_export(
    name: str = typer.Argument(help="Profile name to export."),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Output file path (default: <name>.toml)."),
):
    """Export a profile as a standalone TOML file for sharing."""
    from lasso.config.sharing import export_profile as do_export

    if output is None:
        output = f"{name}.toml"

    try:
        path = do_export(name, output)
        console.print(f"[green]Profile '{name}' exported to:[/green] {path}")
    except FileNotFoundError as e:
        err_console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


@profile_app.command(name="import")
def profile_import(
    file: str = typer.Argument(help="Path to TOML profile file."),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Override profile name."),
):
    """Import a profile from a TOML file."""
    from lasso.config.sharing import import_profile as do_import

    try:
        profile = do_import(file, name=name)
        console.print(
            f"[green]Profile '{profile.name}' imported successfully.[/green]\n"
            f"  Version: {profile.profile_version}\n"
            f"  Hash:    {profile.config_hash()[:12]}"
        )
    except FileNotFoundError as e:
        err_console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)
    except ValueError as e:
        err_console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)


@profile_app.command(name="diff")
def profile_diff_cmd(
    name1: str = typer.Argument(help="First profile name."),
    name2: str = typer.Argument(help="Second profile name."),
):
    """Show differences between two profiles."""
    from lasso.config.sharing import diff_profiles

    working_dir = str(Path(".").resolve())

    def _load(name: str) -> SandboxProfile:
        if name in BUILTIN_PROFILES:
            return BUILTIN_PROFILES[name](working_dir)
        try:
            return load_profile(name)
        except FileNotFoundError:
            # Try loading from a file path
            p = Path(name)
            if p.exists():
                return load_profile_from_path(p)
            err_console.print(f"[red]Error: Profile '{name}' not found.[/red]")
            err_console.print("[dim]Run 'lasso profile list' to see available profiles.[/dim]")
            raise typer.Exit(1)

    a = _load(name1)
    b = _load(name2)
    result = diff_profiles(a, b)
    console.print(result)


# -----------------------------------------------------------------------
# Agent management
# -----------------------------------------------------------------------

@agent_app.command(name="list")
def agent_list(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON array."),
):
    """List supported AI agents and their status."""
    from lasso.agents.registry import list_agents
    agents = list_agents()

    if output_json:
        console.print_json(json.dumps(agents, indent=2))
        return

    table = Table(title="AI Agent Providers", show_header=True)
    table.add_column("Agent", style="bold")
    table.add_column("Type")
    table.add_column("Installed")
    table.add_column("Version")
    table.add_column("Priority")

    for i, a in enumerate(agents):
        installed = "[green]Yes[/green]" if a["installed"] else "[dim]No[/dim]"
        ver = a.get("version") or "-"
        priority = "[bold cyan]Default[/bold cyan]" if i == 0 else str(i + 1)
        table.add_row(a["name"], a["type"], installed, ver, priority)

    console.print(table)
    console.print("\n[dim]OpenCode is the default agent. Override with --agent flag.[/dim]")
    console.print("[dim]Supported: opencode, claude-code, copilot, cursor, aider, goose, gemini-cli, codex, vscode[/dim]")


@agent_app.command(name="config")
def agent_config(
    agent_type: str = typer.Argument(help="Agent: opencode, claude-code, copilot, cursor, aider, goose, gemini-cli, codex, or vscode."),
    profile_name: str = typer.Option("development", "--profile", "-p", help="Profile."),
    working_dir: str = typer.Option(".", "--dir", "-d", help="Working directory."),
    write: bool = typer.Option(False, "--write", "-w", help="Write config files to disk."),
):
    """Preview or write agent-specific config from a LASSO profile."""
    from lasso.agents.base import AgentType as AT
    from lasso.agents.registry import get_provider, write_agent_config

    working_dir = str(Path(working_dir).resolve())

    try:
        provider = get_provider(AT(agent_type))
    except ValueError:
        err_console.print(f"[red]Error: Unknown agent '{agent_type}'.[/red]")
        err_console.print(
            "[dim]Supported: opencode, claude-code, copilot, "
            "cursor, aider, goose, gemini-cli, codex, vscode[/dim]"
        )
        raise typer.Exit(1)

    profile = _resolve_profile(profile_name, working_dir)
    config = provider.generate_config(profile)

    if write:
        written = write_agent_config(config, working_dir)
        for f in written:
            console.print(f"[green]Wrote:[/green] {f}")
    else:
        console.print(f"[bold]Agent config preview for {provider.display_name}[/bold]\n")
        for name, content in config.config_files.items():
            console.print(Panel(content, title=name, border_style="blue"))
        for name, content in config.rules_files.items():
            console.print(Panel(content, title=name, border_style="green"))
        console.print(f"\n[dim]Use --write to save these files to {working_dir}[/dim]")


@agent_app.command(name="vscode-setup")
def agent_vscode_setup(
    profile_name: str = typer.Option("development", "--profile", "-p", help="Profile."),
    working_dir: str = typer.Option(".", "--dir", "-d", help="Working directory."),
    write: bool = typer.Option(False, "--write", "-w", help="Write config files to disk."),
):
    """Set up VS Code workspace for LASSO-secured development.

    Detects installed VS Code extensions, identifies AI coding agents,
    and generates workspace-level configuration files.
    """
    from lasso.agents.vscode import VSCodeProvider
    from lasso.agents.registry import write_agent_config

    working_dir = str(Path(working_dir).resolve())
    provider = VSCodeProvider()

    if not provider.is_installed():
        err_console.print("[red]Error: VS Code ('code' command) not found on PATH.[/red]")
        err_console.print("[dim]Install VS Code or ensure 'code' is in your PATH.[/dim]")
        raise typer.Exit(1)

    ver = provider.get_version()
    console.print(f"[bold]VS Code detected[/bold] (version: {ver or 'unknown'})")

    # Detect extensions
    extensions = provider.detect_extensions()
    console.print(f"\nInstalled extensions: [bold]{len(extensions)}[/bold]")

    # Detect AI agent extensions
    agent_exts = provider.detect_agent_extensions()
    if agent_exts:
        console.print("\n[bold]AI coding agent extensions found:[/bold]")
        for ext in agent_exts:
            console.print(f"  [green]*[/green] {ext['name']} ({ext['id']})")
    else:
        console.print("\n[dim]No known AI coding agent extensions detected.[/dim]")

    # Generate and optionally write config
    profile = _resolve_profile(profile_name, working_dir)
    config = provider.generate_config(profile)

    if write:
        import os
        written = write_agent_config(config, working_dir)
        # Make shell wrapper executable
        wrapper_path = Path(working_dir) / ".lasso" / "vscode-shell.sh"
        if wrapper_path.exists():
            os.chmod(wrapper_path, 0o755)
        console.print("")
        for f in written:
            console.print(f"[green]Wrote:[/green] {f}")
        console.print("\n[bold]Setup complete.[/bold] Instructions:")
        console.print("  1. Open this directory in VS Code: [cyan]code .[/cyan]")
        console.print("  2. Start a LASSO sandbox: [cyan]lasso create development --dir .[/cyan]")
        console.print("  3. Terminal commands will be routed through the LASSO command gate.")
    else:
        console.print(f"\n[bold]Config preview for VS Code (profile: {profile_name})[/bold]\n")
        for name, content in config.config_files.items():
            console.print(Panel(content, title=name, border_style="blue"))
        for name, content in config.rules_files.items():
            console.print(Panel(content, title=name, border_style="green"))
        console.print(f"\n[dim]Use --write to save these files to {working_dir}[/dim]")


# -----------------------------------------------------------------------
# Auth commands (GitHub Device Flow)
# -----------------------------------------------------------------------

@auth_app.command(name="login")
def auth_login(
    client_id: Optional[str] = typer.Option(None, "--client-id", help="GitHub OAuth App client ID (overrides LASSO_GITHUB_CLIENT_ID env var)."),
):
    """Authenticate with GitHub via device flow (opens browser).

    Uses the OAuth Device Flow to authenticate with your GitHub account.
    The token is stored at ~/.lasso/github_token.json and used for
    Copilot Enterprise and dashboard access.

    Set LASSO_GITHUB_CLIENT_ID or pass --client-id to configure.
    Set GITHUB_TOKEN to skip the device flow entirely.
    """
    from lasso.auth.github import DeviceFlowError, GitHubAuth

    auth = GitHubAuth(client_id=client_id)

    # Check for GITHUB_TOKEN env override
    import os
    env_token = os.environ.get("GITHUB_TOKEN")
    if env_token:
        console.print("[dim]Using GITHUB_TOKEN from environment (skipping device flow).[/dim]")
        token_info = auth.login()
        user_info = auth.get_user_info()
        if user_info:
            console.print(f"[green]Authenticated as @{user_info.get('login', 'unknown')}[/green]")
        else:
            console.print("[green]Token saved from environment.[/green]")
        console.print(f"Token saved to {auth.token_path}")
        return

    if not auth.has_client_id:
        err_console.print("[red]Error: No GitHub OAuth client ID configured.[/red]")
        err_console.print("[dim]Set LASSO_GITHUB_CLIENT_ID environment variable or pass --client-id.[/dim]")
        err_console.print("[dim]Alternatively, set GITHUB_TOKEN to use an existing token.[/dim]")
        raise typer.Exit(1)

    try:
        device = auth.request_device_code()
    except DeviceFlowError as e:
        err_console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)

    console.print("Opening browser for GitHub authentication...\n")
    console.print(f"  Enter code: [bold cyan]{device.user_code}[/bold cyan]")
    console.print(f"  URL: [bold]{device.verification_uri}[/bold]\n")

    try:
        auth._open_browser(device.verification_uri)
    except Exception:
        console.print("[dim]Could not open browser automatically. Please visit the URL above.[/dim]")

    console.print("Waiting for authorization... (press Ctrl+C to cancel)")

    try:
        token_info = auth.poll_for_token(
            device.device_code,
            interval=device.interval,
            expires_in=device.expires_in,
        )
        auth._save_token(token_info)
    except DeviceFlowError as e:
        err_console.print(f"\n[red]Error: {e}[/red]")
        raise typer.Exit(1)
    except KeyboardInterrupt:
        console.print("\n[yellow]Authentication cancelled.[/yellow]")
        raise typer.Exit(1)

    # Fetch user info
    user_info = auth.get_user_info()
    if user_info:
        login = user_info.get("login", "unknown")
        name = user_info.get("name", "")
        display = f"@{login}"
        if name:
            display = f"{name} ({display})"
        console.print(f"\n[green]Authenticated as {display}[/green]")
    else:
        console.print("\n[green]Authentication successful.[/green]")

    console.print(f"Token saved to {auth.token_path}")


@auth_app.command(name="status")
def auth_status():
    """Show current GitHub authentication status."""
    from lasso.auth.github import GitHubAuth

    auth = GitHubAuth()

    if not auth.is_authenticated():
        console.print("[dim]Not authenticated.[/dim]")
        console.print("Run [bold]lasso auth login[/bold] to authenticate with GitHub.")
        return

    # Check source
    import os
    source = "environment (GITHUB_TOKEN)" if os.environ.get("GITHUB_TOKEN") else f"file ({auth.token_path})"

    table = Table(title="GitHub Authentication", show_header=True)
    table.add_column("Property", style="bold")
    table.add_column("Value")
    table.add_row("Status", "[green]Authenticated[/green]")
    table.add_row("Source", source)

    # Try to fetch user info
    user_info = auth.get_user_info()
    if user_info:
        table.add_row("User", f"@{user_info.get('login', 'unknown')}")
        if user_info.get("name"):
            table.add_row("Name", user_info["name"])
        if user_info.get("email"):
            table.add_row("Email", user_info["email"])

    # Show token info if from file
    token_info = auth._load_token()
    if token_info:
        from datetime import datetime, timezone
        created = datetime.fromtimestamp(token_info.created_at, tz=timezone.utc)
        table.add_row("Created", created.strftime("%Y-%m-%d %H:%M:%S UTC"))
        table.add_row("Scopes", token_info.scope or "(unknown)")

    console.print(table)


@auth_app.command(name="logout")
def auth_logout():
    """Remove stored GitHub token."""
    from lasso.auth.github import GitHubAuth

    auth = GitHubAuth()

    if auth.logout():
        console.print("[green]Logged out. Token removed.[/green]")
    else:
        console.print("[dim]No stored token found.[/dim]")

    import os
    if os.environ.get("GITHUB_TOKEN"):
        console.print("[yellow]Note: GITHUB_TOKEN environment variable is still set.[/yellow]")


@auth_app.command(name="token")
def auth_token():
    """Print the current GitHub token (for piping to other tools).

    Outputs just the raw token string with no formatting, suitable for:
        export GITHUB_TOKEN=$(lasso auth token)
    """
    from lasso.auth.github import GitHubAuth

    auth = GitHubAuth()
    token = auth.get_token()

    if not token:
        err_console.print("[red]Error: Not authenticated.[/red]")
        err_console.print("[dim]Run 'lasso auth login' first.[/dim]")
        raise typer.Exit(1)

    # Print raw token without rich formatting
    print(token, end="")


# -----------------------------------------------------------------------
# Dashboard
# -----------------------------------------------------------------------

@app.command()
def dashboard(
    port: int = typer.Option(8080, "--port", "-p", help="Dashboard port."),
    host: str = typer.Option("127.0.0.1", "--host", help="Dashboard host."),
):
    """Launch the LASSO web dashboard."""
    try:
        from lasso.dashboard.app import create_app
    except ImportError:
        err_console.print("[red]Error: Flask not installed.[/red]")
        err_console.print("[dim]Run: pip install flask[/dim]")
        raise typer.Exit(1)

    registry = _get_registry()
    backend = registry._backend

    web_app = create_app(registry=registry, backend=backend)
    console.print(Panel.fit(
        f"[bold]LASSO Dashboard[/bold]\n"
        f"http://{host}:{port}",
        border_style="blue",
    ))
    web_app.run(host=host, port=port, debug=False)


# -----------------------------------------------------------------------
# MCP server
# -----------------------------------------------------------------------

@mcp_app.callback(invoke_without_command=True)
def mcp_serve(
    ctx: typer.Context,
    profile_name: str = typer.Option("development", "--profile", "-p", help="Default sandbox profile."),
    working_dir: str = typer.Option(".", "--dir", "-d", help="Default working directory."),
):
    """Start the MCP server (stdin/stdout JSON-RPC transport).

    Agents connect to LASSO via MCP and all tool calls are routed through
    sandboxed execution with command gating and audit logging.
    """
    if ctx.invoked_subcommand is not None:
        return

    working_dir = str(Path(working_dir).resolve())

    # Resolve MCP security config from the profile
    from lasso.config.defaults import BUILTIN_PROFILES
    mcp_security = None
    if profile_name in BUILTIN_PROFILES:
        _profile = BUILTIN_PROFILES[profile_name](working_dir)
        mcp_security = _profile.mcp_security
    else:
        try:
            _profile = load_profile(profile_name)
            mcp_security = _profile.mcp_security
        except Exception as exc:
            err_console.print(f"[yellow]Warning: failed to load profile '{profile_name}': {exc}[/yellow]")
            err_console.print("[dim]Falling back to default MCP security config.[/dim]")

    from lasso.mcp.server import MCPServer
    server = MCPServer(
        default_profile=profile_name,
        working_dir=working_dir,
        mcp_security=mcp_security,
    )

    # Log to stderr so stdout stays clean for JSON-RPC
    import logging
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(name)s] %(levelname)s %(message)s",
        stream=sys.stderr,
    )

    server.run()


@mcp_app.command(name="config")
def mcp_config(
    profile_name: str = typer.Option("development", "--profile", "-p", help="Profile to include in config."),
):
    """Output MCP server configuration JSON for client setup.

    Copy this into your MCP client config (Claude Desktop, VS Code, etc.)
    to connect to LASSO as a tool server.
    """
    from lasso.mcp.server import generate_mcp_config
    config = generate_mcp_config(profile=profile_name)
    console.print_json(json.dumps(config, indent=2))


# -----------------------------------------------------------------------
# Compliance reporting
# -----------------------------------------------------------------------

@compliance_app.command(name="report")
def compliance_report(
    framework: str = typer.Argument(help="Framework: dora or eu-ai-act."),
    audit_log: str = typer.Option(
        "./audit/log.jsonl", "--audit-log", "-a", help="Path to audit log.",
    ),
    profile_name: str = typer.Option(
        "development", "--profile", "-p", help="Profile name.",
    ),
    output: Optional[str] = typer.Option(
        None, "--output", "-o", help="Output file (stdout if omitted).",
    ),
    output_format: str = typer.Option(
        "markdown", "--format", "-f", help="Output format: markdown or json.",
    ),
):
    """Generate a compliance evidence report for a regulatory framework.

    Maps audit log evidence to regulatory articles and produces a structured
    report suitable for bank auditors and compliance officers.

    Supported frameworks:
        dora        DORA (EU) 2022/2554 -- Digital Operational Resilience Act
        eu-ai-act   EU AI Act (EU) 2024/1689 -- Artificial Intelligence Act

    Examples:
        lasso compliance report dora
        lasso compliance report eu-ai-act --audit-log ./audit/session.jsonl
        lasso compliance report dora --profile bank-analysis --format json
        lasso compliance report dora -o report.md --profile strict
    """
    from lasso.core.compliance import FRAMEWORKS, ComplianceReporter

    framework_lower = framework.lower()
    if framework_lower not in FRAMEWORKS:
        err_console.print(f"[red]Error: Unknown framework '{framework}'.[/red]")
        err_console.print(f"[dim]Supported: {', '.join(FRAMEWORKS.keys())}[/dim]")
        raise typer.Exit(1)

    if output_format not in ("markdown", "json"):
        err_console.print(f"[red]Error: Unknown format '{output_format}'.[/red]")
        err_console.print("[dim]Valid formats: markdown, json[/dim]")
        raise typer.Exit(1)

    audit_path = Path(audit_log)
    if not audit_path.exists():
        err_console.print(
            f"[yellow]Warning: audit log not found at {audit_log}.[/yellow]"
        )
        err_console.print(
            "[yellow]Report will be generated with empty audit data.[/yellow]"
        )

    try:
        reporter = ComplianceReporter(framework_lower, audit_log, profile_name)
    except ValueError as e:
        err_console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)

    with console.status(
        f"[bold blue]Generating {framework} compliance report..."
    ):
        report = reporter.generate()

    if output_format == "json":
        rendered = reporter.render_json(report)
    else:
        rendered = reporter.render_markdown(report)

    if output:
        Path(output).parent.mkdir(parents=True, exist_ok=True)
        Path(output).write_text(rendered, encoding="utf-8")
        console.print(f"[green]Report written to {output}[/green]")
        console.print(
            f"  Framework:    {report.framework_full_name}\n"
            f"  Profile:      {report.profile_name} (hash: {report.profile_hash})\n"
            f"  Events:       {report.total_events_analyzed:,}\n"
            f"  Integrity:    {'VERIFIED' if report.signing_verified else 'FAILED'}\n"
            f"  Articles:     {len(report.article_evidence)}"
        )
    else:
        console.print(rendered)


@compliance_app.command(name="frameworks")
def compliance_frameworks():
    """List supported compliance frameworks."""
    from lasso.core.compliance import FRAMEWORK_FULL_NAMES, FRAMEWORKS

    table = Table(title="Supported Compliance Frameworks", show_header=True)
    table.add_column("ID", style="bold cyan")
    table.add_column("Full Name")
    table.add_column("Articles")

    for fid, articles in FRAMEWORKS.items():
        full_name = FRAMEWORK_FULL_NAMES.get(fid, fid)
        article_nums = ", ".join(a.number for a in articles)
        table.add_row(fid, full_name, article_nums)

    console.print(table)
    console.print(
        "\n[dim]Usage: lasso compliance report <framework> [options][/dim]"
    )


# -----------------------------------------------------------------------
# Shell completions
# -----------------------------------------------------------------------

@app.command()
def completions():
    """Show how to install shell completions for LASSO.

    Typer provides built-in shell completion support for bash, zsh,
    fish, and PowerShell.
    """
    console.print(Panel.fit(
        "[bold]Shell Completions[/bold]\n\n"
        "Install completions for your shell:\n\n"
        "  [bold cyan]lasso --install-completion[/bold cyan]    Install completion for current shell\n"
        "  [bold cyan]lasso --show-completion[/bold cyan]       Show completion script (for manual install)\n\n"
        "Supported shells: bash, zsh, fish, PowerShell\n\n"
        "After installing, restart your shell or source the config file.",
        border_style="blue",
        title="LASSO Shell Completions",
    ))


# -----------------------------------------------------------------------
# Version
# -----------------------------------------------------------------------

@app.command()
def version(
    output_json: bool = typer.Option(False, "--json", help="Output version info as JSON."),
):
    """Print LASSO version, pinned version, and latest checkpoint."""
    from lasso.core.checkpoint import CheckpointStore

    store = CheckpointStore()
    pinned = store.get_pinned_version()
    latest = store.latest_checkpoint()
    update = store.check_for_update(__version__)

    if output_json:
        data = {
            "current_version": __version__,
            "pinned_version": pinned,
            "latest_checkpoint": latest.to_dict() if latest else None,
            "update_available": update.to_dict() if update else None,
        }
        console.print_json(json.dumps(data, indent=2))
        return

    console.print(f"LASSO v{__version__}")
    if pinned:
        console.print(f"  Pinned to: [bold cyan]{pinned}[/bold cyan]")
    if latest:
        console.print(f"  Latest checkpoint: [bold]{latest.version}[/bold] ({latest.tag})")
    if update:
        console.print(
            f"  [yellow]Update available: v{update.version}[/yellow]"
            f" \u2014 run 'lasso checkpoint list' for details."
        )


# -----------------------------------------------------------------------
# Checkpoint commands
# -----------------------------------------------------------------------

@checkpoint_app.command(name="list")
def checkpoint_list(
    output_json: bool = typer.Option(False, "--json", help="Output as JSON."),
):
    """List all registered checkpoints."""
    from lasso.core.checkpoint import CheckpointStore

    store = CheckpointStore()
    checkpoints = store.load_manifest()

    if output_json:
        console.print_json(json.dumps(
            [c.to_dict() for c in checkpoints], indent=2,
        ))
        return

    if not checkpoints:
        console.print("[dim]No checkpoints registered.[/dim]")
        console.print("Run 'lasso checkpoint create <tag> --notes \"...\"' to register one.")
        return

    table = Table(show_header=True, title="LASSO Checkpoints")
    table.add_column("Tag", style="bold")
    table.add_column("Version")
    table.add_column("Released")
    table.add_column("Notes")
    table.add_column("Reviewers")

    for c in sorted(checkpoints, key=lambda x: x.released_at, reverse=True):
        released = c.released_at[:10] if c.released_at else "-"
        reviewers = ", ".join(c.reviewed_by) if c.reviewed_by else "-"
        table.add_row(c.tag, c.version, released, c.notes or "-", reviewers)

    console.print(table)

    pinned = store.get_pinned_version()
    if pinned:
        console.print(f"\n[bold cyan]Pinned to: {pinned}[/bold cyan]")


@checkpoint_app.command(name="create")
def checkpoint_create(
    tag: str = typer.Argument(help="Checkpoint tag (e.g. 'v0.2.0-rc1')."),
    notes: str = typer.Option("", "--notes", "-n", help="Release notes."),
    reviewer: list[str] = typer.Option([], "--reviewer", "-r", help="Reviewer name (repeatable)."),
):
    """Register a new checkpoint (admin operation).

    Example:
        lasso checkpoint create v0.2.0 --notes "Stable release" --reviewer Alice
    """
    from lasso.core.checkpoint import CheckpointStore

    # Derive version from tag by stripping leading 'v'
    version = tag.lstrip("v")

    store = CheckpointStore()
    cp = store.register_checkpoint(
        tag=tag,
        version=version,
        notes=notes,
        reviewed_by=reviewer,
    )

    console.print(Panel.fit(
        f"[bold green]Checkpoint registered[/bold green]\n\n"
        f"  Tag:       {cp.tag}\n"
        f"  Version:   {cp.version}\n"
        f"  SHA-256:   {cp.sha256[:16]}...\n"
        f"  Released:  {cp.released_at}\n"
        f"  Notes:     {cp.notes or '-'}\n"
        f"  Reviewers: {', '.join(cp.reviewed_by) or '-'}",
        border_style="green",
        title="LASSO Checkpoint",
    ))


@checkpoint_app.command(name="pin")
def checkpoint_pin(
    version_str: str = typer.Argument(help="Version to pin to (e.g. '0.2.0')."),
):
    """Pin LASSO to a specific checkpoint version.

    When pinned, LASSO will warn if the running version does not match
    the pinned version.

    Example:
        lasso checkpoint pin 0.2.0
    """
    from lasso.core.checkpoint import CheckpointStore

    store = CheckpointStore()
    store.pin_version(version_str)
    console.print(f"[bold green]Pinned to version {version_str}[/bold green]")


# -----------------------------------------------------------------------
# Entry point
# -----------------------------------------------------------------------

def _shutdown_handler(signum, frame):
    """Handle SIGINT/SIGTERM by shutting down the registry gracefully."""
    global _registry
    if _registry is not None:
        try:
            _registry.shutdown()
        except Exception:
            pass  # Best-effort during signal handling
    sys.exit(0)


def _register_signal_handlers():
    """Register signal handlers for graceful shutdown.

    Handles SIGINT and SIGTERM on all platforms, plus SIGBREAK on Windows.
    """
    signal.signal(signal.SIGINT, _shutdown_handler)
    signal.signal(signal.SIGTERM, _shutdown_handler)

    # Windows sends SIGBREAK on Ctrl+Break and when the console window is closed
    if hasattr(signal, "SIGBREAK"):
        signal.signal(signal.SIGBREAK, _shutdown_handler)


def main():
    _register_signal_handlers()
    app()
