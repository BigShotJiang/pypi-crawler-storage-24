"""VS Code IDE agent provider — generates workspace config for LASSO-secured development.

VS Code hosts multiple AI coding agents as extensions (Copilot, Continue, Cline,
Supermaven). Unlike standalone agents, VS Code requires workspace-level configuration
to route terminal commands through LASSO's command gate.

LASSO generates:
  - .vscode/settings.json: terminal profile routing commands through LASSO
  - .lasso/vscode-shell.sh: shell wrapper that forwards commands to the sandbox
  - Agent-specific restriction files for detected extensions:
    - .github/copilot-instructions.md (Copilot)
    - .continue/config.json (Continue)
    - .clinerules (Cline)

This is defense-in-depth: terminal commands go through LASSO's command gate,
agent-native guardrails are injected per extension, and the container sandbox
enforces the final policy.
"""

from __future__ import annotations

import json
import shutil
import subprocess
from typing import Any, Optional

from lasso.agents.base import AgentConfig, AgentProvider, AgentType
from lasso.config.schema import CommandMode, NetworkMode, SandboxProfile


# Known AI coding agent extensions for VS Code
KNOWN_AGENT_EXTENSIONS: dict[str, dict[str, str]] = {
    "github.copilot": {
        "name": "GitHub Copilot",
        "agent": "copilot",
    },
    "github.copilot-chat": {
        "name": "GitHub Copilot Chat",
        "agent": "copilot",
    },
    "continue.continue": {
        "name": "Continue",
        "agent": "continue",
    },
    "saoudrizwan.claude-dev": {
        "name": "Cline",
        "agent": "cline",
    },
    "supermaven.supermaven": {
        "name": "Supermaven",
        "agent": "supermaven",
    },
}


class VSCodeProvider(AgentProvider):

    @property
    def agent_type(self) -> AgentType:
        return AgentType.VSCODE

    @property
    def display_name(self) -> str:
        return "VS Code"

    def is_installed(self) -> bool:
        return shutil.which("code") is not None

    def get_version(self) -> Optional[str]:
        try:
            result = subprocess.run(
                ["code", "--version"],
                capture_output=True, timeout=10,
            )
            if result.returncode == 0:
                # code --version returns multi-line: version\ncommit\narch
                lines = result.stdout.decode().strip().splitlines()
                return lines[0] if lines else None
            return None
        except Exception:
            return None

    def detect_extensions(self) -> list[str]:
        """List all installed VS Code extensions.

        Returns extension IDs as lowercase strings, e.g. ['github.copilot', 'ms-python.python'].
        Returns empty list if VS Code is not installed or the command fails.
        """
        try:
            result = subprocess.run(
                ["code", "--list-extensions"],
                capture_output=True, timeout=15,
                stderr=subprocess.DEVNULL,
            )
            if result.returncode == 0:
                return [
                    ext.strip().lower()
                    for ext in result.stdout.decode().strip().splitlines()
                    if ext.strip()
                ]
        except Exception:
            pass
        return []

    def detect_agent_extensions(self) -> list[dict[str, str]]:
        """Detect installed AI coding agent extensions.

        Returns a list of dicts with 'id', 'name', and 'agent' keys for each
        recognized agent extension found in the VS Code installation.
        """
        installed = set(self.detect_extensions())
        found = []
        for ext_id, info in KNOWN_AGENT_EXTENSIONS.items():
            if ext_id in installed:
                found.append({
                    "id": ext_id,
                    "name": info["name"],
                    "agent": info["agent"],
                })
        return found

    def generate_config(self, profile: SandboxProfile) -> AgentConfig:
        config_files: dict[str, str] = {}
        rules_files: dict[str, str] = {}

        # Core: VS Code workspace settings with LASSO terminal profile
        config_files[".vscode/settings.json"] = json.dumps(
            self._build_vscode_settings(profile), indent=2
        )

        # Core: shell wrapper scripts (Unix + Windows)
        config_files[".lasso/vscode-shell.sh"] = self._build_shell_wrapper()
        config_files[".lasso/vscode-shell.cmd"] = self._build_windows_wrapper()

        # Generate agent-specific restriction files for detected extensions
        detected = self.detect_agent_extensions()
        detected_agents = {ext["agent"] for ext in detected}

        if "copilot" in detected_agents:
            rules_files[".github/copilot-instructions.md"] = (
                self._generate_copilot_rules(profile)
            )

        if "continue" in detected_agents:
            config_files[".continue/config.json"] = json.dumps(
                self._build_continue_config(profile), indent=2
            )

        if "cline" in detected_agents:
            rules_files[".clinerules"] = self._generate_cline_rules(profile)

        return AgentConfig(
            agent_type=self.agent_type,
            config_files=config_files,
            rules_files=rules_files,
            env_vars=self._build_env_vars(profile),
            command=self.get_start_command(),
        )

    def generate_rules(self, profile: SandboxProfile) -> str:
        """Generate combined rules string for all detected agent extensions."""
        rules = [
            f"# LASSO Secured VS Code Environment -- {profile.name}",
            "",
            f"This workspace is secured by LASSO (profile: `{profile.name}`).",
            "Terminal commands are routed through the LASSO command gate.",
            "",
        ]

        # Command restrictions
        if profile.commands.mode == CommandMode.WHITELIST:
            rules.append("## Allowed Commands")
            rules.append("ONLY use the following commands:")
            rules.append("")
            for cmd in sorted(profile.commands.whitelist):
                rules.append(f"- `{cmd}`")
            rules.append("")
            rules.append(
                "All other commands will be **blocked by the sandbox**. Do not attempt them."
            )
        else:
            rules.append("## Blocked Commands")
            rules.append("Do NOT use any of these commands:")
            rules.append("")
            for cmd in sorted(profile.commands.blacklist):
                rules.append(f"- `{cmd}`")
        rules.append("")

        # Blocked argument patterns
        if profile.commands.blocked_args:
            rules.append("## Restricted Arguments")
            for cmd, patterns in profile.commands.blocked_args.items():
                for p in patterns:
                    rules.append(f"- `{cmd} {p}` -- blocked")
            rules.append("")

        # Network
        rules.append("## Network Access")
        if profile.network.mode == NetworkMode.NONE:
            rules.append(
                "**No network access.** Do not attempt curl, wget, fetch, or any network operations."
            )
        elif profile.network.mode == NetworkMode.RESTRICTED:
            rules.append("Network is restricted. Only these domains are reachable:")
            for domain in profile.network.allowed_domains:
                rules.append(f"- `{domain}`")
            rules.append("")
            rules.append("All other domains are blocked at the network level.")
        else:
            rules.append("Network access is unrestricted.")
        rules.append("")

        # Filesystem
        rules.append("## Filesystem")
        rules.append(f"- Working directory: `{profile.filesystem.working_dir}`")
        rules.append("- Do NOT read or write files outside the working directory.")
        rules.append("- System paths (`/etc`, `/usr`, etc.) are read-only.")
        if profile.filesystem.hidden_paths:
            rules.append("- The following paths are hidden and inaccessible:")
            for p in profile.filesystem.hidden_paths:
                rules.append(f"  - `{p}`")
        rules.append("")

        # Compliance
        rules.append("## Compliance & Audit")
        rules.append(
            "- Every action is recorded in a tamper-evident, HMAC-signed audit log."
        )
        rules.append(
            "- Do not include personally identifiable information (PII) in outputs."
        )
        rules.append(
            "- Do not attempt to exfiltrate any data outside the sandbox."
        )
        rules.append(
            "- Violations will be logged, flagged, and may terminate the session."
        )
        if profile.tags:
            rules.append(f"- Compliance: {', '.join(profile.tags)}")
        rules.append("")

        # Guardrail rules
        if profile.guardrails.rules:
            rules.append("## Guardrail Rules")
            for rule in profile.guardrails.rules:
                if rule.enabled:
                    marker = {
                        "critical": "CRITICAL",
                        "error": "ERROR",
                        "warning": "WARN",
                        "info": "INFO",
                    }.get(rule.severity, "INFO")
                    rules.append(f"- **[{marker}]** {rule.description}")
            rules.append("")

        return "\n".join(rules)

    def get_start_command(self) -> list[str]:
        return ["code", "."]

    # ------------------------------------------------------------------
    # Internal builders
    # ------------------------------------------------------------------

    def _build_vscode_settings(self, profile: SandboxProfile) -> dict[str, Any]:
        """Build .vscode/settings.json with LASSO terminal profile.

        Linux/macOS use the bash wrapper (``.lasso/vscode-shell.sh``).
        Windows uses the cmd wrapper (``.lasso/vscode-shell.cmd``).
        """
        return {
            "terminal.integrated.defaultProfile.linux": "lasso",
            "terminal.integrated.profiles.linux": {
                "lasso": {
                    "path": ".lasso/vscode-shell.sh",
                    "args": [],
                },
            },
            "terminal.integrated.defaultProfile.osx": "lasso",
            "terminal.integrated.profiles.osx": {
                "lasso": {
                    "path": ".lasso/vscode-shell.sh",
                    "args": [],
                },
            },
            "terminal.integrated.defaultProfile.windows": "lasso",
            "terminal.integrated.profiles.windows": {
                "lasso": {
                    "path": ".lasso/vscode-shell.cmd",
                    "args": [],
                },
            },
            "terminal.integrated.env.linux": {
                "LASSO_ACTIVE": "1",
                "LASSO_PROFILE": profile.name,
            },
            "terminal.integrated.env.osx": {
                "LASSO_ACTIVE": "1",
                "LASSO_PROFILE": profile.name,
            },
            "terminal.integrated.env.windows": {
                "LASSO_ACTIVE": "1",
                "LASSO_PROFILE": profile.name,
            },
        }

    @staticmethod
    def _build_shell_wrapper() -> str:
        """Generate the shell wrapper that routes commands through LASSO.

        VS Code launches the shell as an interactive process and sends keystrokes
        via PTY stdin. A simple ``exec ... "$@"`` does not work because ``$@`` is
        always empty — VS Code passes no arguments.

        Instead we use a read-eval-loop that reads commands from stdin and forwards
        each through ``lasso exec``.

        If LASSO_SANDBOX_ID is not already set, the wrapper tries to detect a
        running sandbox automatically via ``lasso status --json``.
        """
        return (
            '#!/bin/bash\n'
            '# LASSO VS Code Terminal Wrapper\n'
            '# Routes commands through LASSO command gate\n'
            '\n'
            '# Resolve sandbox ID: env var, then auto-detect via lasso status\n'
            'if [ -z "$LASSO_SANDBOX_ID" ]; then\n'
            '    _ids=$(lasso status --json 2>/dev/null | python3 -c "\n'
            'import sys, json\n'
            'try:\n'
            '    data = json.load(sys.stdin)\n'
            '    ids = [s[\'id\'] for s in data if s.get(\'status\') == \'running\']\n'
            '    print(chr(10).join(ids))\n'
            'except Exception:\n'
            '    pass\n'
            '" 2>/dev/null)\n'
            '    _count=$(echo "$_ids" | grep -c .)\n'
            '    if [ "$_count" -eq 1 ]; then\n'
            '        export LASSO_SANDBOX_ID="$_ids"\n'
            '    fi\n'
            'fi\n'
            '\n'
            'if [ -z "$LASSO_SANDBOX_ID" ]; then\n'
            '    echo "LASSO: No active sandbox. Run \'lasso create\' first." >&2\n'
            '    echo "LASSO: Starting a standard shell instead." >&2\n'
            '    exec bash\n'
            'fi\n'
            '\n'
            'echo "LASSO sandbox $LASSO_SANDBOX_ID ($(lasso status --json 2>/dev/null '
            '| python3 -c \'import sys,json\\n'
            'try:\\n'
            ' data=json.load(sys.stdin)\\n'
            ' m=[s for s in data if s[\"id\"]==\"\'\"$LASSO_SANDBOX_ID\"\'\"]\\'
            'n print(m[0][\"status\"] if m else \"active\")\\n'
            'except: print(\"active\")\' 2>/dev/null || echo \'active\'))"\n'
            'echo "Commands are routed through the LASSO command gate."\n'
            'echo ""\n'
            '\n'
            'while IFS= read -r -e -p "lasso> " cmd; do\n'
            '    [ -z "$cmd" ] && continue\n'
            '    [ "$cmd" = "exit" ] && break\n'
            '    history -s "$cmd"\n'
            '    lasso exec "$LASSO_SANDBOX_ID" -- $cmd\n'
            'done\n'
        )

    @staticmethod
    def _build_windows_wrapper() -> str:
        """Generate Windows cmd wrapper that routes commands through LASSO.

        Mirrors the Unix shell wrapper logic for native Windows environments
        where bash is not available.
        """
        return (
            '@echo off\r\n'
            'REM LASSO VS Code Terminal Wrapper (Windows)\r\n'
            'REM Routes commands through LASSO command gate\r\n'
            '\r\n'
            'if not "%LASSO_SANDBOX_ID%"=="" goto :have_id\r\n'
            '\r\n'
            'REM Auto-detect running sandbox\r\n'
            'for /f "usebackq delims=" %%i in (`lasso status --json 2^>nul ^| '
            'python -c "import sys,json;data=json.load(sys.stdin);ids=[s[\'id\'] '
            'for s in data if s.get(\'status\')==\'running\'];print(ids[0] if len(ids)==1 '
            'else \'\')" 2^>nul`) do set LASSO_SANDBOX_ID=%%i\r\n'
            '\r\n'
            ':have_id\r\n'
            'if "%LASSO_SANDBOX_ID%"=="" (\r\n'
            '    echo LASSO: No active sandbox. Run \'lasso create\' first. 1>&2\r\n'
            '    echo LASSO: Starting a standard shell instead. 1>&2\r\n'
            '    cmd /k\r\n'
            '    exit /b\r\n'
            ')\r\n'
            '\r\n'
            'echo LASSO sandbox %LASSO_SANDBOX_ID%\r\n'
            'echo Commands are routed through the LASSO command gate.\r\n'
            'echo.\r\n'
            '\r\n'
            ':loop\r\n'
            'set /p "cmd=lasso> "\r\n'
            'if "%cmd%"=="exit" exit /b\r\n'
            'if "%cmd%"=="" goto loop\r\n'
            'lasso exec %LASSO_SANDBOX_ID% -- %cmd%\r\n'
            'goto loop\r\n'
        )

    def _generate_copilot_rules(self, profile: SandboxProfile) -> str:
        """Generate .github/copilot-instructions.md -- reuses the guardrails pattern."""
        rules = [
            f"# LASSO Secured Environment -- {profile.name}",
            "",
            f"You are operating inside a LASSO sandbox (profile: `{profile.name}`).",
            "The following constraints are enforced at both the agent and container level.",
            "",
        ]

        # Command restrictions
        if profile.commands.mode == CommandMode.WHITELIST:
            rules.append("## Allowed Commands")
            rules.append("ONLY use the following commands:")
            rules.append("")
            for cmd in sorted(profile.commands.whitelist):
                rules.append(f"- `{cmd}`")
            rules.append("")
            rules.append(
                "All other commands will be **blocked by the sandbox**. Do not attempt them."
            )
        else:
            rules.append("## Blocked Commands")
            rules.append("Do NOT use any of these commands:")
            rules.append("")
            for cmd in sorted(profile.commands.blacklist):
                rules.append(f"- `{cmd}`")
        rules.append("")

        # Network
        rules.append("## Network Access")
        if profile.network.mode == NetworkMode.NONE:
            rules.append(
                "**No network access.** Do not attempt curl, wget, fetch, or any network operations."
            )
        elif profile.network.mode == NetworkMode.RESTRICTED:
            rules.append("Network is restricted. Only these domains are reachable:")
            for domain in profile.network.allowed_domains:
                rules.append(f"- `{domain}`")
            rules.append("")
            rules.append("All other domains are blocked at the network level.")
        else:
            rules.append("Network access is unrestricted.")
        rules.append("")

        # Compliance
        rules.append("## Compliance & Audit")
        rules.append(
            "- Every action is recorded in a tamper-evident, HMAC-signed audit log."
        )
        rules.append(
            "- Do not include personally identifiable information (PII) in outputs."
        )
        rules.append(
            "- Do not attempt to exfiltrate any data outside the sandbox."
        )
        if profile.tags:
            rules.append(f"- Compliance: {', '.join(profile.tags)}")
        rules.append("")

        return "\n".join(rules)

    def _build_continue_config(self, profile: SandboxProfile) -> dict[str, Any]:
        """Build .continue/config.json with restricted tool settings."""
        allowed_cmds = []
        blocked_cmds = []

        if profile.commands.mode == CommandMode.WHITELIST:
            allowed_cmds = sorted(profile.commands.whitelist)
        else:
            blocked_cmds = sorted(profile.commands.blacklist)

        config: dict[str, Any] = {
            "lasso": {
                "enabled": True,
                "profile": profile.name,
                "sandbox": True,
            },
            "allowAnonymousTelemetry": False,
            "models": [],
            "customCommands": [],
            "contextProviders": [],
            "slashCommands": [],
        }

        # Add tool restrictions
        config["lasso"]["commands"] = {
            "mode": profile.commands.mode.value,
        }
        if allowed_cmds:
            config["lasso"]["commands"]["allowed"] = allowed_cmds
        if blocked_cmds:
            config["lasso"]["commands"]["blocked"] = blocked_cmds

        # Network restrictions
        config["lasso"]["network"] = {
            "mode": profile.network.mode.value,
        }
        if profile.network.mode == NetworkMode.RESTRICTED:
            config["lasso"]["network"]["allowed_domains"] = (
                profile.network.allowed_domains
            )

        return config

    def _generate_cline_rules(self, profile: SandboxProfile) -> str:
        """Generate .clinerules with LASSO restrictions."""
        rules = [
            f"# LASSO Secured Environment -- {profile.name}",
            "",
            f"You are operating inside a LASSO sandbox (profile: `{profile.name}`).",
            "All terminal commands are routed through LASSO's command gate.",
            "",
        ]

        # Command restrictions
        if profile.commands.mode == CommandMode.WHITELIST:
            rules.append("ALLOWED COMMANDS ONLY:")
            for cmd in sorted(profile.commands.whitelist):
                rules.append(f"  - {cmd}")
            rules.append("")
            rules.append("ALL other commands are BLOCKED. Do not attempt them.")
        else:
            rules.append("BLOCKED COMMANDS:")
            for cmd in sorted(profile.commands.blacklist):
                rules.append(f"  - {cmd}")
        rules.append("")

        # Network
        if profile.network.mode == NetworkMode.NONE:
            rules.append(
                "NO NETWORK ACCESS. Do not attempt any network operations."
            )
        elif profile.network.mode == NetworkMode.RESTRICTED:
            rules.append("RESTRICTED NETWORK. Only these domains are reachable:")
            for domain in profile.network.allowed_domains:
                rules.append(f"  - {domain}")
        rules.append("")

        # Compliance
        rules.append("COMPLIANCE:")
        rules.append(
            "- All actions are recorded in a tamper-evident audit log."
        )
        rules.append("- Do not include PII in outputs.")
        rules.append("- Do not exfiltrate data outside the sandbox.")
        if profile.tags:
            rules.append(f"- Tags: {', '.join(profile.tags)}")
        rules.append("")

        return "\n".join(rules)

    def _build_env_vars(self, profile: SandboxProfile) -> dict[str, str]:
        return {
            "LASSO_SANDBOX": "true",
            "LASSO_PROFILE": profile.name,
            "LASSO_NETWORK_MODE": profile.network.mode.value,
            "LASSO_ACTIVE": "1",
        }
