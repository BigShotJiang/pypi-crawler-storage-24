"""Goose agent provider — generates .goosehints and config from LASSO profiles.

Goose (by Block) uses:
  - .goosehints: project-level instruction file (Markdown)
  - goose config files for provider/model settings

LASSO generates the hints file, translating its universal policy into Goose's
native format for defense-in-depth constraint enforcement.
"""

from __future__ import annotations

import shutil
import subprocess
from typing import Optional

from lasso.agents.base import AgentConfig, AgentProvider, AgentType
from lasso.config.schema import CommandMode, NetworkMode, SandboxProfile


class GooseProvider(AgentProvider):

    @property
    def agent_type(self) -> AgentType:
        return AgentType.GOOSE

    @property
    def display_name(self) -> str:
        return "Goose"

    def is_installed(self) -> bool:
        return shutil.which("goose") is not None

    def get_version(self) -> Optional[str]:
        try:
            result = subprocess.run(
                ["goose", "version"],
                capture_output=True, timeout=5,
            )
            output = result.stdout.decode().strip() or result.stderr.decode().strip()
            return output or None
        except Exception:
            return None

    def generate_config(self, profile: SandboxProfile) -> AgentConfig:
        hints = self.generate_rules(profile)

        return AgentConfig(
            agent_type=self.agent_type,
            config_files={},
            rules_files={
                ".goosehints": hints,
            },
            env_vars=self._build_env_vars(profile),
            command=self.get_start_command(),
        )

    def generate_rules(self, profile: SandboxProfile) -> str:
        rules = [
            f"# LASSO Secured Environment — {profile.name}",
            "",
            f"You are operating inside a LASSO sandbox (profile: `{profile.name}`).",
            "The following constraints are enforced at both the agent and container level.",
            "",
        ]

        if profile.commands.mode == CommandMode.WHITELIST:
            rules.append("## Allowed Commands")
            rules.append("ONLY use the following commands:")
            rules.append("")
            for cmd in sorted(profile.commands.whitelist):
                rules.append(f"- `{cmd}`")
            rules.append("")
            rules.append("All other commands will be **blocked by the sandbox**. Do not attempt them.")
        else:
            rules.append("## Blocked Commands")
            rules.append("Do NOT use any of these commands:")
            rules.append("")
            for cmd in sorted(profile.commands.blacklist):
                rules.append(f"- `{cmd}`")
        rules.append("")

        if profile.commands.blocked_args:
            rules.append("## Restricted Arguments")
            for cmd, patterns in profile.commands.blocked_args.items():
                for p in patterns:
                    rules.append(f"- `{cmd} {p}` — blocked")
            rules.append("")

        rules.append("## Network Access")
        if profile.network.mode == NetworkMode.NONE:
            rules.append("**No network access.** Do not attempt curl, wget, fetch, or any network operations.")
        elif profile.network.mode == NetworkMode.RESTRICTED:
            rules.append("Network is restricted. Only these domains are reachable:")
            for domain in profile.network.allowed_domains:
                rules.append(f"- `{domain}`")
            rules.append("")
            rules.append("All other domains are blocked at the network level.")
        else:
            rules.append("Network access is unrestricted.")
        rules.append("")

        rules.append("## Filesystem")
        rules.append(f"- Working directory: `{profile.filesystem.working_dir}`")
        rules.append("- Do NOT read or write files outside the working directory.")
        rules.append("- System paths (`/etc`, `/usr`, etc.) are read-only.")
        if profile.filesystem.hidden_paths:
            rules.append("- The following paths are hidden and inaccessible:")
            for p in profile.filesystem.hidden_paths:
                rules.append(f"  - `{p}`")
        rules.append("")

        rules.append("## Compliance & Audit")
        rules.append("- Every action is recorded in a tamper-evident, HMAC-signed audit log.")
        rules.append("- Do not include personally identifiable information (PII) in outputs.")
        rules.append("- Do not attempt to exfiltrate any data outside the sandbox.")
        rules.append("- Violations will be logged, flagged, and may terminate the session.")
        if profile.tags:
            rules.append(f"- Compliance: {', '.join(profile.tags)}")
        rules.append("")

        if profile.guardrails.rules:
            rules.append("## Guardrail Rules")
            for rule in profile.guardrails.rules:
                if rule.enabled:
                    marker = {"critical": "CRITICAL", "error": "ERROR",
                              "warning": "WARN", "info": "INFO"}.get(rule.severity, "INFO")
                    rules.append(f"- **[{marker}]** {rule.description}")
            rules.append("")

        return "\n".join(rules)

    def get_start_command(self) -> list[str]:
        return ["goose", "session"]

    def _build_env_vars(self, profile: SandboxProfile) -> dict:
        return {
            "LASSO_SANDBOX": "true",
            "LASSO_PROFILE": profile.name,
            "LASSO_NETWORK_MODE": profile.network.mode.value,
        }
