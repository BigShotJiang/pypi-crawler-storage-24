"""Claude Code agent provider — generates CLAUDE.md and settings from LASSO profiles.

Claude Code's permission model differs from OpenCode:
  - CLAUDE.md: instruction file with behavioral rules
  - .claude/settings.json: tool permissions (allowedTools, blockedCommands)
  - Permission modes: allowAll, askAll, or per-tool

LASSO generates both files, translating its universal policy into
Claude Code's native format.
"""

from __future__ import annotations

import json
import shutil
import subprocess
from typing import Optional

from lasso.agents.base import AgentConfig, AgentProvider, AgentType
from lasso.config.schema import CommandMode, NetworkMode, SandboxProfile


class ClaudeCodeProvider(AgentProvider):

    @property
    def agent_type(self) -> AgentType:
        return AgentType.CLAUDE_CODE

    @property
    def display_name(self) -> str:
        return "Claude Code"

    def is_installed(self) -> bool:
        return shutil.which("claude") is not None

    def get_version(self) -> Optional[str]:
        try:
            result = subprocess.run(
                ["claude", "--version"],
                capture_output=True, timeout=5,
            )
            return result.stdout.decode().strip()
        except Exception:
            return None

    def generate_config(self, profile: SandboxProfile) -> AgentConfig:
        settings = self._build_settings(profile)
        claude_md = self.generate_rules(profile)

        return AgentConfig(
            agent_type=self.agent_type,
            config_files={
                ".claude/settings.json": json.dumps(settings, indent=2),
            },
            rules_files={
                "CLAUDE.md": claude_md,
            },
            env_vars=self._build_env_vars(profile),
            command=self.get_start_command(),
        )

    def generate_rules(self, profile: SandboxProfile) -> str:
        """Generate CLAUDE.md with LASSO guardrails."""
        rules = [
            f"# LASSO Secured Environment — {profile.name}",
            "",
            f"You are operating inside a LASSO sandbox (profile: `{profile.name}`).",
            "The following constraints are enforced at both the agent and container level.",
            "",
        ]

        # Command restrictions
        if profile.commands.mode == CommandMode.WHITELIST:
            rules.append("## Allowed Commands")
            rules.append("ONLY use the following commands:")
            rules.append("")
            for cmd in sorted(profile.commands.whitelist):
                rules.append(f"- `{cmd}`")
            rules.append("")
            rules.append("All other commands will be **blocked by the sandbox**. Do not attempt them.")
        else:
            rules.append("## Blocked Commands")
            rules.append("Do NOT use any of these commands:")
            for cmd in sorted(profile.commands.blacklist):
                rules.append(f"- `{cmd}`")

        rules.append("")

        # Blocked argument patterns
        if profile.commands.blocked_args:
            rules.append("## Restricted Arguments")
            for cmd, patterns in profile.commands.blocked_args.items():
                for p in patterns:
                    rules.append(f"- `{cmd} {p}` — blocked")
            rules.append("")

        # Network
        rules.append("## Network Access")
        if profile.network.mode == NetworkMode.NONE:
            rules.append("**No network access.** Do not attempt curl, wget, fetch, or any network operations.")
            rules.append("Do not use WebFetch or WebSearch tools.")
        elif profile.network.mode == NetworkMode.RESTRICTED:
            rules.append("Network is restricted. Only these domains are reachable:")
            for domain in profile.network.allowed_domains:
                rules.append(f"- `{domain}`")
            rules.append("")
            rules.append("All other domains are blocked at the network level.")
        rules.append("")

        # Filesystem
        rules.append("## Filesystem")
        rules.append(f"- Working directory: `{profile.filesystem.working_dir}`")
        rules.append("- Do NOT read or write files outside the working directory.")
        rules.append("- System paths (`/etc`, `/usr`, etc.) are read-only.")
        if profile.filesystem.hidden_paths:
            rules.append("- The following paths are hidden and inaccessible:")
            for p in profile.filesystem.hidden_paths:
                rules.append(f"  - `{p}`")
        rules.append("")

        # Compliance
        rules.append("## Compliance & Audit")
        rules.append("- Every action is recorded in a tamper-evident, HMAC-signed audit log.")
        rules.append("- Do not include personally identifiable information (PII) in outputs.")
        rules.append("- Do not attempt to exfiltrate any data outside the sandbox.")
        rules.append("- Violations will be logged, flagged, and may terminate the session.")
        if profile.tags:
            rules.append(f"- Compliance: {', '.join(profile.tags)}")
        rules.append("")

        # Guardrail rules
        if profile.guardrails.rules:
            rules.append("## Guardrail Rules")
            for rule in profile.guardrails.rules:
                if rule.enabled:
                    marker = {"critical": "CRITICAL", "error": "ERROR",
                              "warning": "WARN", "info": "INFO"}.get(rule.severity, "INFO")
                    rules.append(f"- **[{marker}]** {rule.description}")
            rules.append("")

        return "\n".join(rules)

    def get_start_command(self) -> list[str]:
        return ["claude"]

    def _build_settings(self, profile: SandboxProfile) -> dict:
        """Build .claude/settings.json from a LASSO profile."""
        settings: dict = {
            "permissions": self._build_permissions(profile),
            "env": self._build_env_vars(profile),
        }

        return settings

    def _build_permissions(self, profile: SandboxProfile) -> dict:
        """Translate LASSO policy to Claude Code permission format."""
        perms: dict = {}

        # Build allowed/denied tool lists
        allowed = []
        denied = []

        # Bash commands
        if profile.commands.mode == CommandMode.WHITELIST:
            for cmd in profile.commands.whitelist:
                allowed.append(f"Bash({cmd} *)")
            # Explicitly deny dangerous commands
            for cmd in ["rm", "dd", "mkfs", "reboot", "shutdown",
                        "mount", "umount", "chroot", "nsenter", "unshare"]:
                denied.append(f"Bash({cmd} *)")

        elif profile.commands.mode == CommandMode.BLACKLIST:
            for cmd in profile.commands.blacklist:
                denied.append(f"Bash({cmd} *)")

        # Network tools
        if profile.network.mode == NetworkMode.NONE:
            denied.extend([
                "WebFetch(*)",
                "WebSearch(*)",
                "Bash(curl *)",
                "Bash(wget *)",
                "Bash(ssh *)",
            ])

        # File tools are generally allowed within workspace
        allowed.extend([
            "Read(*)",
            "Write(*)",
            "Edit(*)",
            "Glob(*)",
            "Grep(*)",
        ])

        perms["allowedTools"] = allowed
        perms["deniedTools"] = denied

        return perms

    def _build_env_vars(self, profile: SandboxProfile) -> dict:
        return {
            "LASSO_SANDBOX": "true",
            "LASSO_PROFILE": profile.name,
            "LASSO_NETWORK_MODE": profile.network.mode.value,
        }
