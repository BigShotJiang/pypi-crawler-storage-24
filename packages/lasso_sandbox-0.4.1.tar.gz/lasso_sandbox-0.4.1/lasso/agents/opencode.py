"""OpenCode agent provider — generates opencode.json and AGENTS.md from LASSO profiles.

OpenCode's permission system maps cleanly to LASSO's:
  - bash permissions: pattern-based ("git *": "allow", "*": "deny")
  - edit permissions: path-based ("*.py": "allow", "*": "deny")
  - external_directory: "deny" (stay in sandbox)
  - tools: enable/disable per tool

LASSO generates both the config and the rules file, injecting guardrails
that the agent must follow. This is defense-in-depth — even if a command
passes OpenCode's permission system, the container still blocks it.
"""

from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from typing import Optional

from lasso.agents.base import AgentConfig, AgentProvider, AgentType
from lasso.config.schema import CommandMode, NetworkMode, SandboxProfile


class OpenCodeProvider(AgentProvider):

    @property
    def agent_type(self) -> AgentType:
        return AgentType.OPENCODE

    @property
    def display_name(self) -> str:
        return "OpenCode"

    def is_installed(self) -> bool:
        return shutil.which("opencode") is not None

    def get_version(self) -> Optional[str]:
        try:
            result = subprocess.run(
                ["opencode", "version"],
                capture_output=True, timeout=5,
            )
            return result.stdout.decode().strip() or result.stderr.decode().strip()
        except Exception:
            return None

    def generate_config(self, profile: SandboxProfile) -> AgentConfig:
        opencode_json = self._build_opencode_json(profile)
        agents_md = self.generate_rules(profile)
        plugin_js = self._get_plugin_source()

        config_files = {
            "opencode.json": json.dumps(opencode_json, indent=2),
        }
        if plugin_js:
            config_files[".opencode/plugins/lasso-security.js"] = plugin_js

        return AgentConfig(
            agent_type=self.agent_type,
            config_files=config_files,
            rules_files={
                "AGENTS.md": agents_md,
            },
            env_vars=self._build_env_vars(profile),
            command=self.get_start_command(),
        )

    def generate_rules(self, profile: SandboxProfile) -> str:
        """Generate AGENTS.md with LASSO guardrails injected."""
        rules = [
            f"# LASSO Secured Environment — {profile.name}",
            "",
            f"You are operating inside a LASSO sandbox (profile: `{profile.name}`).",
            "The following constraints are enforced at both the agent and container level.",
            "",
            "## Security Constraints",
            "",
        ]

        # Command restrictions
        if profile.commands.mode == CommandMode.WHITELIST:
            rules.append("### Allowed Commands")
            rules.append("Only the following commands are available:")
            rules.append("")
            for cmd in sorted(profile.commands.whitelist):
                rules.append(f"- `{cmd}`")
            rules.append("")
            rules.append("All other commands are **blocked and logged**.")
        else:
            rules.append("### Blocked Commands")
            for cmd in sorted(profile.commands.blacklist):
                rules.append(f"- `{cmd}` — blocked")

        rules.append("")

        # Network restrictions
        rules.append("### Network Access")
        if profile.network.mode == NetworkMode.NONE:
            rules.append("**No network access.** All outbound connections are blocked.")
        elif profile.network.mode == NetworkMode.RESTRICTED:
            rules.append("Network is restricted to the following domains:")
            for domain in profile.network.allowed_domains:
                rules.append(f"- `{domain}`")
        else:
            rules.append("Network access is unrestricted.")
        rules.append("")

        # Filesystem
        rules.append("### Filesystem")
        rules.append(f"- Working directory: `{profile.filesystem.working_dir}`")
        rules.append("- Do NOT access files outside the working directory.")
        rules.append("- System paths are read-only.")
        rules.append("")

        # Compliance
        rules.append("### Compliance")
        rules.append("- All actions are recorded in a tamper-evident audit log.")
        rules.append("- Do not include PII in outputs (GDPR/DORA).")
        rules.append("- Do not exfiltrate data outside the sandbox.")
        if profile.tags:
            rules.append(f"- Compliance tags: {', '.join(profile.tags)}")
        rules.append("")

        # Guardrail rules
        if profile.guardrails.rules:
            rules.append("### Guardrail Rules")
            for rule in profile.guardrails.rules:
                if rule.enabled:
                    rules.append(f"- **[{rule.severity.upper()}]** {rule.description}")
            rules.append("")

        return "\n".join(rules)

    def get_start_command(self) -> list[str]:
        return ["opencode"]

    def _build_opencode_json(self, profile: SandboxProfile) -> dict:
        """Build the opencode.json config from a LASSO profile."""
        config: dict = {
            "$schema": "https://opencode.ai/config.json",
            "permission": self._build_permissions(profile),
            "tools": self._build_tools(profile),
        }

        # Disable auto-update in sandbox
        config["autoupdate"] = False

        # Disable sharing
        config["share"] = "disabled"

        # Point instructions at our generated AGENTS.md
        config["instructions"] = ["AGENTS.md"]

        # Register the LASSO security plugin
        config["plugin"] = [".opencode/plugins/lasso-security.js"]

        # Include LLM provider auth settings if configured
        if profile.agent_auth and profile.agent_auth.opencode_provider:
            config["provider"] = profile.agent_auth.opencode_provider
            config["api_key_env"] = profile.agent_auth.opencode_api_key_env

        return config

    def _build_permissions(self, profile: SandboxProfile) -> dict:
        """Translate LASSO command/network/filesystem policy to OpenCode permissions."""
        perms: dict = {}

        # --- Bash permissions ---
        bash_perms: dict = {"*": "deny"}  # default deny

        if profile.commands.mode == CommandMode.WHITELIST:
            for cmd in profile.commands.whitelist:
                bash_perms[f"{cmd} *"] = "allow"
                # Also allow the bare command without args
                bash_perms[cmd] = "allow"

            # Apply blocked_args overrides
            for cmd, blocked_patterns in profile.commands.blocked_args.items():
                for pattern in blocked_patterns:
                    bash_perms[f"{cmd} {pattern}"] = "deny"
                    bash_perms[f"{cmd} {pattern} *"] = "deny"

        elif profile.commands.mode == CommandMode.BLACKLIST:
            bash_perms["*"] = "allow"  # default allow
            for cmd in profile.commands.blacklist:
                bash_perms[f"{cmd} *"] = "deny"
                bash_perms[cmd] = "deny"

        perms["bash"] = bash_perms

        # --- Edit permissions ---
        # Allow editing within workspace, deny everything else
        perms["edit"] = {
            "*": "deny",
            "/workspace/*": "allow",
            "/workspace/**/*": "allow",
        }

        # --- Read permissions ---
        perms["read"] = {
            "*": "allow",  # reading is generally safe
        }

        # --- External directory ---
        perms["external_directory"] = "deny"

        # --- Web fetch ---
        if profile.network.mode == NetworkMode.NONE:
            perms["webfetch"] = "deny"
        elif profile.network.mode == NetworkMode.RESTRICTED:
            perms["webfetch"] = "ask"
        else:
            perms["webfetch"] = "allow"

        # --- Task (subagent) ---
        perms["task"] = "allow"

        return perms

    def _build_tools(self, profile: SandboxProfile) -> dict:
        """Configure which OpenCode tools are enabled."""
        tools = {
            "write": True,
            "edit": True,
            "bash": True,
            "read": True,
            "glob": True,
            "grep": True,
            "list": True,
        }

        # Disable web-related tools if no network
        if profile.network.mode == NetworkMode.NONE:
            tools["webfetch"] = False
            tools["websearch"] = False

        return tools

    def _build_env_vars(self, profile: SandboxProfile) -> dict:
        """Environment variables for the sandbox — also consumed by the LASSO plugin."""
        env = {
            "LASSO_SANDBOX": "true",
            "LASSO_PROFILE": profile.name,
            "LASSO_NETWORK_MODE": profile.network.mode.value,
            "LASSO_COMMAND_MODE": profile.commands.mode.value,
            "LASSO_AUDIT_DIR": profile.audit.log_dir,
        }

        if profile.commands.mode == CommandMode.WHITELIST:
            env["LASSO_WHITELIST"] = ",".join(profile.commands.whitelist)
        else:
            env["LASSO_BLACKLIST"] = ",".join(profile.commands.blacklist)

        # Encode blocked args: "git:push,git:push --force,pip:install --user"
        blocked_parts = []
        for cmd, patterns in profile.commands.blocked_args.items():
            for p in patterns:
                blocked_parts.append(f"{cmd}:{p}")
        if blocked_parts:
            env["LASSO_BLOCKED_ARGS"] = ",".join(blocked_parts)

        return env

    @staticmethod
    def _get_plugin_source() -> Optional[str]:
        """Read the bundled LASSO plugin for OpenCode."""
        plugin_path = Path(__file__).parent / "plugins" / "opencode-lasso-plugin.js"
        if plugin_path.exists():
            return plugin_path.read_text()
        return None
