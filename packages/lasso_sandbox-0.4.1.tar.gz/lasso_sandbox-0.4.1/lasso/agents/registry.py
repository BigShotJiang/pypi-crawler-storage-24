"""Agent registry — discover and manage available agent providers.

Priority: OpenCode first (bank default), Claude Code second.
"""

from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Optional

from lasso.agents.base import AgentConfig, AgentProvider, AgentType
from lasso.config.schema import SandboxProfile


# Ordered by priority — OpenCode first
_PROVIDERS: list[type[AgentProvider]] = []


def _load_providers() -> list[type[AgentProvider]]:
    """Lazy-load provider classes."""
    global _PROVIDERS
    if not _PROVIDERS:
        from lasso.agents.opencode import OpenCodeProvider
        from lasso.agents.claude_code import ClaudeCodeProvider
        from lasso.agents.copilot import CopilotProvider
        from lasso.agents.vscode import VSCodeProvider
        from lasso.agents.cursor import CursorProvider
        from lasso.agents.aider import AiderProvider
        from lasso.agents.goose import GooseProvider
        from lasso.agents.gemini_cli import GeminiCLIProvider
        from lasso.agents.codex import CodexProvider
        _PROVIDERS = [
            OpenCodeProvider, ClaudeCodeProvider, CopilotProvider, VSCodeProvider,
            CursorProvider, AiderProvider, GooseProvider, GeminiCLIProvider, CodexProvider,
        ]
    return _PROVIDERS


def get_provider(agent_type: AgentType) -> AgentProvider:
    """Get a specific provider by type."""
    for cls in _load_providers():
        provider = cls()
        if provider.agent_type == agent_type:
            return provider
    raise ValueError(f"Unknown agent type: {agent_type}")


def detect_agent() -> Optional[AgentProvider]:
    """Auto-detect the best available agent. OpenCode first, then Claude Code."""
    for cls in _load_providers():
        provider = cls()
        if provider.is_installed():
            return provider
    return None


def list_agents() -> list[dict]:
    """List all known agents with their availability status."""
    results = []
    for cls in _load_providers():
        provider = cls()
        results.append(provider.info())
    return results


# Mapping of friendly agent names to AgentType values.
# Allows users to type `lasso run claude` instead of `lasso run claude-code`.
AGENT_ALIASES: dict[str, AgentType] = {
    "opencode": AgentType.OPENCODE,
    "claude": AgentType.CLAUDE_CODE,
    "claude-code": AgentType.CLAUDE_CODE,
    "copilot": AgentType.COPILOT,
    "vscode": AgentType.VSCODE,
    "cursor": AgentType.CURSOR,
    "aider": AgentType.AIDER,
    "goose": AgentType.GOOSE,
    "gemini": AgentType.GEMINI_CLI,
    "gemini-cli": AgentType.GEMINI_CLI,
    "codex": AgentType.CODEX,
}

# Default profile to use for each agent type when running zero-config.
AGENT_DEFAULT_PROFILES: dict[AgentType, str] = {
    AgentType.OPENCODE: "development",
    AgentType.CLAUDE_CODE: "development",
    AgentType.COPILOT: "development",
    AgentType.VSCODE: "development",
    AgentType.CURSOR: "development",
    AgentType.AIDER: "development",
    AgentType.GOOSE: "development",
    AgentType.GEMINI_CLI: "development",
    AgentType.CODEX: "development",
}


def resolve_agent_alias(name: str) -> Optional[AgentType]:
    """Resolve a user-friendly agent name to an AgentType, or None if not an agent."""
    return AGENT_ALIASES.get(name.lower())


def _merge_settings_json(existing_text: str, new_text: str) -> str:
    """Merge LASSO keys into an existing settings.json, preserving user keys.

    If the existing file is not valid JSON, raises ``json.JSONDecodeError``
    so the caller can fall back to backing up and overwriting.
    """
    existing = json.loads(existing_text)
    new = json.loads(new_text)
    existing.update(new)
    return json.dumps(existing, indent=2)


def write_agent_config(
    config: AgentConfig,
    target_dir: str | Path,
) -> list[Path]:
    """Write generated agent config files to a directory.

    For ``.vscode/settings.json``, tries to merge LASSO keys into the
    existing file.  If the merge fails (e.g. invalid JSON), the original
    is backed up as ``settings.json.bak`` before overwriting.

    Returns list of paths written.
    """
    target = Path(target_dir)
    written = []

    for rel_path, content in config.config_files.items():
        dest = target / rel_path
        dest.parent.mkdir(parents=True, exist_ok=True)

        # Merge-or-backup logic for settings.json
        if dest.name == "settings.json" and dest.exists():
            try:
                merged = _merge_settings_json(dest.read_text(), content)
                dest.write_text(merged)
            except (json.JSONDecodeError, ValueError):
                backup = dest.with_suffix(".json.bak")
                shutil.copy2(dest, backup)
                dest.write_text(content)
        else:
            dest.write_text(content)
        written.append(dest)

    for rel_path, content in config.rules_files.items():
        dest = target / rel_path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(content)
        written.append(dest)

    return written
