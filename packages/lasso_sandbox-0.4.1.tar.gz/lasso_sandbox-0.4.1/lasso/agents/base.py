"""Agent provider interface — abstracts how LASSO configures and launches AI coding agents.

Each agent (OpenCode, Claude Code, etc.) has its own config format, permission
model, and rules files. LASSO translates its universal SandboxProfile into
agent-specific configurations, then launches the agent inside a sandboxed container.

Defense-in-depth:
  Layer 1: Container isolation (Docker/Podman)
  Layer 2: Agent-native permissions (generated from LASSO profile)
  Layer 3: LASSO command gate (pre-filters before agent executes)
  Layer 4: Tamper-evident audit logging
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Optional

from lasso.config.schema import SandboxProfile


class AgentType(str, Enum):
    OPENCODE = "opencode"
    CLAUDE_CODE = "claude-code"
    COPILOT = "copilot"
    VSCODE = "vscode"
    CURSOR = "cursor"
    AIDER = "aider"
    GOOSE = "goose"
    GEMINI_CLI = "gemini-cli"
    CODEX = "codex"


@dataclass
class AgentConfig:
    """Generated agent-specific configuration files."""
    agent_type: AgentType
    config_files: dict[str, str]  # relative_path → content
    rules_files: dict[str, str]   # relative_path → content
    env_vars: dict[str, str] = field(default_factory=dict)
    command: list[str] = field(default_factory=list)  # command to start the agent


class AgentProvider(ABC):
    """Abstract interface for AI coding agent providers."""

    @property
    @abstractmethod
    def agent_type(self) -> AgentType:
        """The agent type identifier."""

    @property
    @abstractmethod
    def display_name(self) -> str:
        """Human-readable name for display."""

    @abstractmethod
    def is_installed(self) -> bool:
        """Check if this agent is installed on the system."""

    @abstractmethod
    def get_version(self) -> Optional[str]:
        """Get the installed version, or None if not installed."""

    @abstractmethod
    def generate_config(self, profile: SandboxProfile) -> AgentConfig:
        """Generate agent-specific config from a LASSO SandboxProfile.

        This translates LASSO's universal security policy into the agent's
        native configuration format — permissions, rules, tool access, etc.
        """

    @abstractmethod
    def generate_rules(self, profile: SandboxProfile) -> str:
        """Generate the agent's rules/instructions file content.

        For OpenCode: AGENTS.md
        For Claude Code: CLAUDE.md
        """

    @abstractmethod
    def get_start_command(self) -> list[str]:
        """Command to launch the agent inside the sandbox."""

    def info(self) -> dict[str, Any]:
        """Agent provider summary."""
        return {
            "type": self.agent_type.value,
            "name": self.display_name,
            "installed": self.is_installed(),
            "version": self.get_version(),
        }
