"""Aider agent provider — generates .aider.conf.yml and convention files from LASSO profiles.

Aider uses:
  - .aider.conf.yml: YAML config with model, edit format, and settings
  - CONVENTIONS.md: project-level instructions the agent follows
  - CLI flags for runtime behavior

LASSO generates both files, translating its universal policy into Aider's
native format. This is defense-in-depth — even if Aider allows a command,
the container's command gate still blocks it.
"""

from __future__ import annotations

import shutil
import subprocess
from typing import Optional

from lasso.agents.base import AgentConfig, AgentProvider, AgentType
from lasso.config.schema import CommandMode, NetworkMode, SandboxProfile


class AiderProvider(AgentProvider):

    @property
    def agent_type(self) -> AgentType:
        return AgentType.AIDER

    @property
    def display_name(self) -> str:
        return "Aider"

    def is_installed(self) -> bool:
        return shutil.which("aider") is not None

    def get_version(self) -> Optional[str]:
        try:
            result = subprocess.run(
                ["aider", "--version"],
                capture_output=True, timeout=5,
            )
            return result.stdout.decode().strip() or result.stderr.decode().strip() or None
        except Exception:
            return None

    def generate_config(self, profile: SandboxProfile) -> AgentConfig:
        conventions = self.generate_rules(profile)
        aider_conf = self._build_aider_conf(profile)

        return AgentConfig(
            agent_type=self.agent_type,
            config_files={
                ".aider.conf.yml": aider_conf,
            },
            rules_files={
                "CONVENTIONS.md": conventions,
            },
            env_vars=self._build_env_vars(profile),
            command=self.get_start_command(),
        )

    def generate_rules(self, profile: SandboxProfile) -> str:
        rules = [
            f"# LASSO Secured Environment — {profile.name}",
            "",
            f"You are operating inside a LASSO sandbox (profile: `{profile.name}`).",
            "The following constraints are enforced at both the agent and container level.",
            "",
        ]

        if profile.commands.mode == CommandMode.WHITELIST:
            rules.append("## Allowed Commands")
            rules.append("ONLY use the following commands:")
            rules.append("")
            for cmd in sorted(profile.commands.whitelist):
                rules.append(f"- `{cmd}`")
            rules.append("")
            rules.append("All other commands will be **blocked by the sandbox**. Do not attempt them.")
        else:
            rules.append("## Blocked Commands")
            rules.append("Do NOT use any of these commands:")
            rules.append("")
            for cmd in sorted(profile.commands.blacklist):
                rules.append(f"- `{cmd}`")
        rules.append("")

        if profile.commands.blocked_args:
            rules.append("## Restricted Arguments")
            for cmd, patterns in profile.commands.blocked_args.items():
                for p in patterns:
                    rules.append(f"- `{cmd} {p}` — blocked")
            rules.append("")

        rules.append("## Network Access")
        if profile.network.mode == NetworkMode.NONE:
            rules.append("**No network access.** Do not attempt curl, wget, fetch, or any network operations.")
        elif profile.network.mode == NetworkMode.RESTRICTED:
            rules.append("Network is restricted. Only these domains are reachable:")
            for domain in profile.network.allowed_domains:
                rules.append(f"- `{domain}`")
            rules.append("")
            rules.append("All other domains are blocked at the network level.")
        else:
            rules.append("Network access is unrestricted.")
        rules.append("")

        rules.append("## Filesystem")
        rules.append(f"- Working directory: `{profile.filesystem.working_dir}`")
        rules.append("- Do NOT read or write files outside the working directory.")
        rules.append("- System paths (`/etc`, `/usr`, etc.) are read-only.")
        rules.append("")

        rules.append("## Compliance & Audit")
        rules.append("- Every action is recorded in a tamper-evident, HMAC-signed audit log.")
        rules.append("- Do not include personally identifiable information (PII) in outputs.")
        rules.append("- Do not attempt to exfiltrate any data outside the sandbox.")
        if profile.tags:
            rules.append(f"- Compliance: {', '.join(profile.tags)}")
        rules.append("")

        if profile.guardrails.rules:
            rules.append("## Guardrail Rules")
            for rule in profile.guardrails.rules:
                if rule.enabled:
                    marker = {"critical": "CRITICAL", "error": "ERROR",
                              "warning": "WARN", "info": "INFO"}.get(rule.severity, "INFO")
                    rules.append(f"- **[{marker}]** {rule.description}")
            rules.append("")

        return "\n".join(rules)

    def get_start_command(self) -> list[str]:
        return ["aider"]

    def _build_aider_conf(self, profile: SandboxProfile) -> str:
        """Build .aider.conf.yml content."""
        lines = [
            "# LASSO-generated Aider configuration",
            f"# Profile: {profile.name}",
            "",
            "# Read CONVENTIONS.md for sandbox rules",
            "read: [CONVENTIONS.md]",
            "",
            "# Disable auto-commits in sandbox (audit trail handles tracking)",
            "auto-commits: false",
            "",
            "# Disable linting in sandbox (may invoke disallowed commands)",
            "lint: false",
            "auto-lint: false",
            "",
            "# Disable auto-test (may invoke disallowed commands)",
            "auto-test: false",
            "",
            "# No browser opening in sandbox",
            "no-show-model-warnings: true",
            "",
        ]

        if profile.network.mode == NetworkMode.NONE:
            lines.append("# No network — use local model or pre-configured API")
            lines.append("no-auto-update: true")
            lines.append("")

        return "\n".join(lines)

    def _build_env_vars(self, profile: SandboxProfile) -> dict:
        return {
            "LASSO_SANDBOX": "true",
            "LASSO_PROFILE": profile.name,
            "LASSO_NETWORK_MODE": profile.network.mode.value,
        }
