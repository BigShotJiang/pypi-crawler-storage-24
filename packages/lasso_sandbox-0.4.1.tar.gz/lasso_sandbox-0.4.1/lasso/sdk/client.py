"""LASSO SDK client -- local and remote sandbox management.

This module provides :class:`LassoClient` for creating and managing sandboxes,
and :class:`SandboxHandle` as a uniform interface to a running sandbox
regardless of whether it is backed by a local :class:`Sandbox` object or
a remote REST API.
"""

from __future__ import annotations

import json
import time
import urllib.error
import urllib.request
from contextlib import contextmanager
from dataclasses import asdict
from pathlib import Path
from typing import Any, Optional

from lasso.sdk.exceptions import (
    AuthenticationError,
    CommandBlockedError,
    LassoError,
    ProfileNotFoundError,
    RateLimitError,
    SandboxNotFoundError,
    SandboxNotRunningError,
)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_DEFAULT_MAX_RETRIES = 3
_DEFAULT_RETRY_BASE_DELAY = 0.1  # seconds
_DEFAULT_RETRY_MAX_DELAY = 5.0  # seconds
_DEFAULT_REQUEST_TIMEOUT = 30  # seconds


class SandboxHandle:
    """Uniform handle to a sandbox, wrapping either a local Sandbox or remote API.

    Supports the context manager protocol: entering is a no-op (the sandbox
    is already started), exiting calls :meth:`stop`.

    Args:
        sandbox_obj: A local ``Sandbox`` instance (local mode).
        sandbox_id: Explicit sandbox identifier (remote mode).
        api_url: Base URL of the LASSO REST API (remote mode).
        api_key: API key for remote authentication (remote mode).
        max_retries: Maximum number of retry attempts for transient failures
            in remote mode. Defaults to 3.
    """

    def __init__(
        self,
        *,
        sandbox_obj: Any = None,
        sandbox_id: str | None = None,
        api_url: str | None = None,
        api_key: str | None = None,
        max_retries: int = _DEFAULT_MAX_RETRIES,
    ):
        self._sandbox = sandbox_obj
        self._sandbox_id = sandbox_id or (sandbox_obj.id if sandbox_obj else None)
        self._api_url = api_url
        self._api_key = api_key
        self._stopped = False
        self._max_retries = max_retries

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------

    @property
    def id(self) -> str:
        """Return the sandbox identifier."""
        return self._sandbox_id

    @property
    def name(self) -> str:
        """Return the profile name of the sandbox.

        Returns:
            The profile name string. In local mode this is read directly
            from the sandbox object; in remote mode a status request is made.
        """
        if self._sandbox:
            return self._sandbox.profile.name
        info = self.status()
        return info.get("name", "")

    @property
    def state(self) -> str:
        """Return the current sandbox state as a string.

        Returns:
            One of ``"created"``, ``"configuring"``, ``"running"``,
            ``"stopped"``, ``"paused"``, or ``"error"``.
        """
        if self._sandbox:
            return self._sandbox.state.value
        info = self.status()
        return info.get("state", "unknown")

    @property
    def is_running(self) -> bool:
        """Return True if the sandbox is currently in the running state.

        Returns:
            True when ``state == "running"``, False otherwise.
        """
        return self.state == "running"

    @property
    def is_stopped(self) -> bool:
        """Return True if the sandbox is currently stopped.

        Returns:
            True when ``state == "stopped"``, False otherwise.
        """
        return self.state == "stopped"

    # ------------------------------------------------------------------
    # Operations
    # ------------------------------------------------------------------

    def exec(self, command: str):
        """Execute a command inside the sandbox.

        The command is validated against the sandbox's command gate policy
        before execution. Blocked commands return immediately with
        ``exit_code == -1`` and ``blocked == True``.

        Args:
            command: The shell command string to execute.

        Returns:
            In local mode, an :class:`~lasso.core.sandbox.ExecResult`.
            In remote mode, a dict with keys ``command``, ``exit_code``,
            ``stdout``, ``stderr``, ``duration_ms``, ``blocked``.

        Raises:
            SandboxNotFoundError: If the sandbox no longer exists (remote mode).
            SandboxNotRunningError: If the sandbox is not in running state
                (remote mode, HTTP 409).
        """
        if self._sandbox:
            return self._sandbox.exec(command)
        return self._remote_exec(command)

    def stop(self) -> None:
        """Stop the sandbox.

        This method is idempotent: calling it on an already-stopped sandbox
        is a no-op and does not raise an exception.

        Raises:
            SandboxNotFoundError: If the sandbox no longer exists (remote mode).
        """
        if self._stopped:
            return
        self._stopped = True
        if self._sandbox:
            self._sandbox.stop()
        else:
            self._remote_post(f"/sandboxes/{self._sandbox_id}/stop")

    def status(self) -> dict:
        """Return current sandbox status as a dict.

        Returns:
            A dict containing at minimum ``id``, ``name``, ``state``,
            ``working_dir``, ``exec_count``, ``blocked_count``.

        Raises:
            SandboxNotFoundError: If the sandbox does not exist (remote mode).
        """
        if self._sandbox:
            return self._sandbox.status()
        return self._remote_get(f"/sandboxes/{self._sandbox_id}")

    def audit(self, tail: int = 50, event_type: str | None = None) -> list[dict]:
        """Retrieve audit log entries for this sandbox.

        Args:
            tail: Number of most-recent entries to return. Use ``0`` to
                return all entries.
            event_type: Optional filter by event type (e.g. ``"command"``,
                ``"lifecycle"``, ``"violation"``).

        Returns:
            List of audit entry dicts, ordered chronologically.

        Raises:
            SandboxNotFoundError: If the sandbox does not exist (remote mode).
        """
        if self._sandbox:
            return self._local_audit(tail, event_type)
        params = f"?tail={tail}"
        if event_type:
            params += f"&type={event_type}"
        data = self._remote_get(f"/sandboxes/{self._sandbox_id}/audit{params}")
        return data.get("entries", [])

    def wait_until_running(self, timeout: float = 30, poll_interval: float = 0.5) -> None:
        """Block until the sandbox reaches the ``running`` state.

        Args:
            timeout: Maximum seconds to wait before raising a timeout error.
            poll_interval: Seconds between status polls.

        Raises:
            TimeoutError: If the sandbox does not reach running state within
                the timeout period.
            SandboxNotFoundError: If the sandbox does not exist.
        """
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self.state == "running":
                return
            time.sleep(poll_interval)
        raise TimeoutError(
            f"Sandbox '{self._sandbox_id}' did not reach running state "
            f"within {timeout}s (current state: {self.state})."
        )

    def wait_until_stopped(self, timeout: float = 30, poll_interval: float = 0.5) -> None:
        """Block until the sandbox reaches the ``stopped`` state.

        Args:
            timeout: Maximum seconds to wait before raising a timeout error.
            poll_interval: Seconds between status polls.

        Raises:
            TimeoutError: If the sandbox does not reach stopped state within
                the timeout period.
            SandboxNotFoundError: If the sandbox does not exist.
        """
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if self.state == "stopped":
                return
            time.sleep(poll_interval)
        raise TimeoutError(
            f"Sandbox '{self._sandbox_id}' did not reach stopped state "
            f"within {timeout}s (current state: {self.state})."
        )

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop()
        return False

    def __repr__(self) -> str:
        state = self.state if not self._stopped else "stopped"
        return f"<SandboxHandle id={self._sandbox_id} state={state}>"

    # ------------------------------------------------------------------
    # Internal -- local audit reading
    # ------------------------------------------------------------------

    def _local_audit(self, tail: int, event_type: str | None) -> list[dict]:
        """Read audit entries from the local sandbox's log file."""
        audit_logger = self._sandbox.audit
        log_file = audit_logger.log_file
        if not log_file or not Path(log_file).exists():
            return []

        entries: list[dict] = []
        with open(log_file) as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    entry = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if event_type and entry.get("event_type") != event_type:
                    continue
                entries.append(entry)

        return entries[-tail:] if tail else entries

    # ------------------------------------------------------------------
    # Internal -- remote HTTP helpers with retry
    # ------------------------------------------------------------------

    def _remote_exec(self, command: str) -> dict:
        """Execute a command via the remote REST API."""
        data = self._remote_post(
            f"/sandboxes/{self._sandbox_id}/exec",
            body={"command": command},
        )
        return data

    def _remote_request(
        self,
        method: str,
        path: str,
        body: dict | None = None,
    ) -> dict:
        """Make an HTTP request to the remote API with retry and exponential backoff.

        Retries on transient network errors (ConnectionError, TimeoutError,
        URLError with no HTTP status). Does NOT retry on HTTP 4xx errors
        since those indicate client-side problems.

        Args:
            method: HTTP method (``"GET"`` or ``"POST"``).
            path: API path relative to ``/api/v1`` (e.g. ``"/sandboxes"``).
            body: Optional JSON body for POST requests.

        Returns:
            The ``data`` field from the API response envelope.

        Raises:
            SandboxNotFoundError: On HTTP 404 responses.
            AuthenticationError: On HTTP 401 responses.
            RateLimitError: On HTTP 429 responses.
            SandboxNotRunningError: On HTTP 409 responses.
            LassoError: On other API errors.
        """
        last_error: Exception | None = None

        for attempt in range(self._max_retries):
            try:
                return self._do_request(method, path, body)
            except (ConnectionError, TimeoutError, OSError) as e:
                # Retry on transient network errors
                last_error = e
                if attempt < self._max_retries - 1:
                    delay = min(
                        _DEFAULT_RETRY_BASE_DELAY * (2 ** attempt),
                        _DEFAULT_RETRY_MAX_DELAY,
                    )
                    time.sleep(delay)
            except urllib.error.URLError as e:
                # URLError without an HTTP response is a network error (retry)
                # HTTPError (subclass of URLError) is handled inside _do_request
                last_error = e
                if attempt < self._max_retries - 1:
                    delay = min(
                        _DEFAULT_RETRY_BASE_DELAY * (2 ** attempt),
                        _DEFAULT_RETRY_MAX_DELAY,
                    )
                    time.sleep(delay)

        # All retries exhausted
        raise LassoError(f"Request failed after {self._max_retries} attempts: {last_error}") from last_error

    def _do_request(self, method: str, path: str, body: dict | None = None) -> dict:
        """Execute a single HTTP request (no retry).

        Raises typed exceptions based on HTTP status codes.
        """
        url = f"{self._api_url}/api/v1{path}"
        data = json.dumps(body).encode() if body else None
        req = urllib.request.Request(url, data=data, method=method)
        if body is not None:
            req.add_header("Content-Type", "application/json")
        if self._api_key:
            req.add_header("X-API-Key", self._api_key)

        try:
            with urllib.request.urlopen(req, timeout=_DEFAULT_REQUEST_TIMEOUT) as resp:
                envelope = json.loads(resp.read().decode())
                if envelope.get("success"):
                    return envelope.get("data", {})
                raise LassoError(envelope.get("error", "Unknown API error"))
        except urllib.error.HTTPError as e:
            self._handle_http_error(e)

    def _handle_http_error(self, e: urllib.error.HTTPError) -> None:
        """Convert an HTTPError into the appropriate typed SDK exception."""
        body_text = e.read().decode() if e.fp else ""
        error_msg = f"HTTP {e.code}"
        try:
            envelope = json.loads(body_text)
            error_msg = envelope.get("error", error_msg)
        except json.JSONDecodeError:
            if body_text:
                error_msg = f"HTTP {e.code}: {body_text}"

        if e.code == 401:
            raise AuthenticationError(error_msg, status_code=e.code) from e
        elif e.code == 404:
            raise SandboxNotFoundError("unknown", error_msg) from e
        elif e.code == 409:
            raise SandboxNotRunningError("unknown", error_msg) from e
        elif e.code == 429:
            retry_after = e.headers.get("Retry-After")
            raise RateLimitError(
                error_msg,
                retry_after=int(retry_after) if retry_after else None,
            ) from e
        else:
            raise LassoError(error_msg) from e

    def _remote_get(self, path: str) -> dict:
        """Make a GET request to the remote API with retry."""
        return self._remote_request("GET", path)

    def _remote_post(self, path: str, body: dict | None = None) -> dict:
        """Make a POST request to the remote API with retry."""
        return self._remote_request("POST", path, body)


class LassoClient:
    """Python SDK for LASSO sandbox management.

    Can operate in two modes:

    - **Local mode** (default): directly uses
      :class:`~lasso.core.sandbox.Sandbox` and
      :class:`~lasso.core.sandbox.SandboxRegistry`.
    - **Remote mode**: connects to the LASSO REST API via
      ``urllib.request`` (no external dependencies).

    Usage::

        # Local mode
        client = LassoClient()
        sb = client.create("development", working_dir="/my/project")
        result = sb.exec("python3 script.py")
        print(result.stdout)
        sb.stop()

        # Remote mode
        client = LassoClient(api_url="http://localhost:8080", api_key="lasso_xxx")
        sb = client.create("development", working_dir="/my/project")

        # Context manager
        with LassoClient() as client:
            with client.sandbox("development", "/my/project") as sb:
                result = sb.exec("ls -la")
    """

    def __init__(
        self,
        api_url: str | None = None,
        api_key: str | None = None,
        backend: Any = None,
        state_dir: str | None = None,
        max_retries: int = _DEFAULT_MAX_RETRIES,
    ):
        """Initialize the LASSO client.

        Args:
            api_url: Base URL of the LASSO REST API for remote mode.
                When ``None`` (default), operates in local mode.
            api_key: API key for remote authentication (``X-API-Key`` header).
            backend: Container backend for local mode (optional).
                Defaults to ``None`` (native subprocess execution).
            state_dir: Directory for sandbox state persistence in local mode.
            max_retries: Maximum number of retry attempts for transient
                network failures in remote mode. Defaults to 3.
        """
        self._api_url = api_url.rstrip("/") if api_url else None
        self._api_key = api_key
        self._backend = backend
        self._state_dir = state_dir
        self._registry = None  # Lazy-initialized for local mode
        self._max_retries = max_retries

    def _get_registry(self):
        """Lazy-initialize the local SandboxRegistry."""
        if self._registry is None:
            from lasso.core.sandbox import SandboxRegistry
            self._registry = SandboxRegistry(
                backend=self._backend,
                state_dir=self._state_dir,
            )
        return self._registry

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def create(
        self,
        profile_name: str,
        working_dir: str = ".",
        **kwargs,
    ) -> SandboxHandle:
        """Create a new sandbox from a named profile.

        The sandbox is started immediately after creation.

        Args:
            profile_name: Name of a builtin or saved profile
                (e.g. ``"minimal"``, ``"development"``, ``"offline"``).
            working_dir: Working directory to mount inside the sandbox.
            **kwargs: Additional overrides (reserved for future use).

        Returns:
            A :class:`SandboxHandle` for the newly created sandbox.

        Raises:
            ProfileNotFoundError: If the profile name is not found.
            LassoError: If the sandbox fails to start (remote mode).
            RuntimeError: If the sandbox fails to start (local mode).
        """
        if self._api_url:
            return self._remote_create(profile_name, working_dir)
        return self._local_create(profile_name, working_dir)

    def list(self) -> list[dict]:
        """List all managed sandboxes.

        Returns:
            List of sandbox status dicts, each containing at minimum
            ``id``, ``name``, ``state``, ``working_dir``.

        Raises:
            LassoError: On remote communication failure.
        """
        if self._api_url:
            return self._remote_get("/sandboxes")
        return self._get_registry().list_all()

    def get(self, sandbox_id: str) -> SandboxHandle:
        """Get a handle to an existing sandbox by ID.

        Args:
            sandbox_id: The sandbox identifier.

        Returns:
            A :class:`SandboxHandle` for the existing sandbox.

        Raises:
            SandboxNotFoundError: If no sandbox with that ID exists.
        """
        if self._api_url:
            # Verify it exists by fetching status
            data = self._remote_get(f"/sandboxes/{sandbox_id}")
            return SandboxHandle(
                sandbox_id=sandbox_id,
                api_url=self._api_url,
                api_key=self._api_key,
                max_retries=self._max_retries,
            )

        registry = self._get_registry()
        sb = registry.get(sandbox_id)
        if sb is None:
            raise SandboxNotFoundError(sandbox_id)
        return SandboxHandle(sandbox_obj=sb)

    def profiles(self) -> list[dict]:
        """List available sandbox profiles (builtin + saved).

        Returns:
            List of profile info dicts with keys like ``name``,
            ``description``, ``source``, ``cmd_mode``, ``net_mode``.

        Raises:
            LassoError: On remote communication failure.
        """
        if self._api_url:
            return self._remote_get("/profiles")
        return self._local_profiles()

    def check(self) -> dict:
        """Check system capabilities.

        Returns:
            Dict with boolean flags for Docker, Podman, namespaces,
            cgroups, and platform information.

        Raises:
            LassoError: On remote communication failure.
        """
        if self._api_url:
            return self._remote_get("/system/check")
        return self._local_check()

    @contextmanager
    def sandbox(self, profile: str = "development", working_dir: str = "."):
        """Context manager that creates, starts, yields, and stops a sandbox.

        Usage::

            with client.sandbox("development", "/my/project") as sb:
                result = sb.exec("ls -la")

        Args:
            profile: Profile name.
            working_dir: Working directory path.

        Yields:
            A :class:`SandboxHandle`.

        Raises:
            ProfileNotFoundError: If the profile name is not found.
        """
        handle = self.create(profile, working_dir)
        try:
            yield handle
        finally:
            handle.stop()

    # ------------------------------------------------------------------
    # Context manager for the client itself
    # ------------------------------------------------------------------

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._registry is not None:
            self._registry.shutdown()
        return False

    def __repr__(self) -> str:
        mode = f"remote={self._api_url}" if self._api_url else "local"
        return f"<LassoClient mode={mode}>"

    # ------------------------------------------------------------------
    # Internal -- local mode
    # ------------------------------------------------------------------

    def _local_create(self, profile_name: str, working_dir: str) -> SandboxHandle:
        """Create a sandbox using the local registry."""
        profile = self._resolve_profile(profile_name, working_dir)
        registry = self._get_registry()
        sb = registry.create(profile)
        sb.start()
        return SandboxHandle(sandbox_obj=sb)

    def _resolve_profile(self, name: str, working_dir: str):
        """Resolve a profile name to a SandboxProfile instance.

        Args:
            name: Profile name to look up.
            working_dir: Working directory to set on the profile.

        Returns:
            A :class:`~lasso.config.schema.SandboxProfile` instance.

        Raises:
            ProfileNotFoundError: If the profile name is not found in
                builtins or saved profiles.
        """
        from lasso.config.defaults import BUILTIN_PROFILES

        if name in BUILTIN_PROFILES:
            return BUILTIN_PROFILES[name](working_dir)

        # Try loading a saved profile
        try:
            from lasso.config.profile import load_profile
            profile = load_profile(name)
            profile.filesystem.working_dir = working_dir
            return profile
        except FileNotFoundError:
            raise ProfileNotFoundError(
                name,
                available=list(BUILTIN_PROFILES.keys()),
            )

    def _local_profiles(self) -> list[dict]:
        """List profiles from builtins and saved profiles."""
        import tempfile
        from lasso.config.defaults import BUILTIN_PROFILES

        profiles = []
        default_dir = str(Path(tempfile.gettempdir()) / "lasso-sandbox")

        for name, factory in BUILTIN_PROFILES.items():
            p = factory(default_dir)
            profiles.append({
                "name": name,
                "description": p.description,
                "source": "builtin",
                "cmd_mode": p.commands.mode.value,
                "net_mode": p.network.mode.value,
                "mem_limit": f"{p.resources.max_memory_mb}MB",
                "tags": p.tags,
            })

        try:
            from lasso.config.profile import list_profiles
            for saved in list_profiles():
                if "error" not in saved:
                    saved["source"] = "saved"
                    profiles.append(saved)
        except Exception:
            pass  # Saved profiles may not be available

        return profiles

    def _local_check(self) -> dict:
        """Check local system capabilities."""
        import platform
        import shutil
        from lasso import __version__

        caps: dict[str, Any] = {}
        caps["docker"] = shutil.which("docker") is not None
        caps["podman"] = shutil.which("podman") is not None
        caps["user_ns"] = Path("/proc/self/ns/user").exists()
        caps["mount_ns"] = Path("/proc/self/ns/mnt").exists()
        caps["pid_ns"] = Path("/proc/self/ns/pid").exists()
        caps["net_ns"] = Path("/proc/self/ns/net").exists()
        caps["cgroups_v2"] = Path("/sys/fs/cgroup/cgroup.controllers").exists()
        caps["platform"] = platform.platform()
        caps["python"] = platform.python_version()
        caps["lasso_version"] = __version__
        return caps

    # ------------------------------------------------------------------
    # Internal -- remote mode
    # ------------------------------------------------------------------

    def _remote_create(self, profile_name: str, working_dir: str) -> SandboxHandle:
        """Create a sandbox via the REST API.

        Args:
            profile_name: Profile name to create from.
            working_dir: Working directory path.

        Returns:
            A :class:`SandboxHandle` connected to the remote sandbox.

        Raises:
            ProfileNotFoundError: If the profile is not found (HTTP 404).
            LassoError: On other API errors.
        """
        data = self._remote_post("/sandboxes", {
            "profile": profile_name,
            "working_dir": working_dir,
        })
        sandbox_id = data.get("id")
        return SandboxHandle(
            sandbox_id=sandbox_id,
            api_url=self._api_url,
            api_key=self._api_key,
            max_retries=self._max_retries,
        )

    def _remote_request(
        self,
        method: str,
        path: str,
        body: dict | None = None,
    ) -> Any:
        """Make an HTTP request to the remote API with retry and exponential backoff.

        Args:
            method: HTTP method.
            path: API path relative to ``/api/v1``.
            body: Optional JSON body for POST requests.

        Returns:
            The ``data`` field from the response envelope.

        Raises:
            AuthenticationError: On HTTP 401.
            SandboxNotFoundError: On HTTP 404.
            RateLimitError: On HTTP 429.
            LassoError: On other errors after all retries are exhausted.
        """
        last_error: Exception | None = None

        for attempt in range(self._max_retries):
            try:
                return self._do_request(method, path, body)
            except (ConnectionError, TimeoutError, OSError) as e:
                last_error = e
                if attempt < self._max_retries - 1:
                    delay = min(
                        _DEFAULT_RETRY_BASE_DELAY * (2 ** attempt),
                        _DEFAULT_RETRY_MAX_DELAY,
                    )
                    time.sleep(delay)
            except urllib.error.URLError as e:
                if isinstance(e, urllib.error.HTTPError):
                    raise  # HTTP errors should not be retried
                last_error = e
                if attempt < self._max_retries - 1:
                    delay = min(
                        _DEFAULT_RETRY_BASE_DELAY * (2 ** attempt),
                        _DEFAULT_RETRY_MAX_DELAY,
                    )
                    time.sleep(delay)

        raise LassoError(
            f"Request failed after {self._max_retries} attempts: {last_error}"
        ) from last_error

    def _do_request(self, method: str, path: str, body: dict | None = None) -> Any:
        """Execute a single HTTP request (no retry)."""
        url = f"{self._api_url}/api/v1{path}"
        data = json.dumps(body).encode() if body else None
        req = urllib.request.Request(url, data=data, method=method)
        if body is not None:
            req.add_header("Content-Type", "application/json")
        if self._api_key:
            req.add_header("X-API-Key", self._api_key)

        try:
            with urllib.request.urlopen(req, timeout=_DEFAULT_REQUEST_TIMEOUT) as resp:
                envelope = json.loads(resp.read().decode())
                if envelope.get("success"):
                    return envelope.get("data")
                raise LassoError(envelope.get("error", "Unknown API error"))
        except urllib.error.HTTPError as e:
            _handle_http_error(e)

    def _remote_get(self, path: str) -> Any:
        """Make a GET request to the remote API with retry."""
        return self._remote_request("GET", path)

    def _remote_post(self, path: str, body: dict | None = None) -> Any:
        """Make a POST request to the remote API with retry."""
        return self._remote_request("POST", path, body)


def _handle_http_error(e: urllib.error.HTTPError) -> None:
    """Convert an HTTPError into the appropriate typed SDK exception.

    This is a module-level helper used by both LassoClient and SandboxHandle.
    """
    body_text = e.read().decode() if e.fp else ""
    error_msg = f"HTTP {e.code}"
    try:
        envelope = json.loads(body_text)
        error_msg = envelope.get("error", error_msg)
    except json.JSONDecodeError:
        if body_text:
            error_msg = f"HTTP {e.code}: {body_text}"

    if e.code == 401:
        raise AuthenticationError(error_msg, status_code=e.code) from e
    elif e.code == 404:
        raise SandboxNotFoundError("unknown", error_msg) from e
    elif e.code == 409:
        raise SandboxNotRunningError("unknown", error_msg) from e
    elif e.code == 429:
        retry_after = e.headers.get("Retry-After")
        raise RateLimitError(
            error_msg,
            retry_after=int(retry_after) if retry_after else None,
        ) from e
    else:
        raise LassoError(error_msg) from e
