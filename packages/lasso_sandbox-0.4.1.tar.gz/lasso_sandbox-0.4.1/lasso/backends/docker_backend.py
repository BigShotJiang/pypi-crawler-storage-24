"""Container backend implementation for Podman and Docker.

Uses the Docker SDK which is compatible with both runtimes.
On Windows, Podman Desktop is recommended (free for enterprise).
For Podman: set DOCKER_HOST=unix:///run/user/$UID/podman/podman.sock
"""

from __future__ import annotations

import io
import logging
import time
from typing import Any, Optional

logger = logging.getLogger("lasso.docker")

import docker
from docker.errors import APIError, ContainerError, ImageNotFound, NotFound

from lasso.backends.base import (
    ContainerBackend,
    ContainerConfig,
    ContainerInfo,
    ContainerState,
    ExecResult,
)

LASSO_LABEL = "managed-by=lasso"


def _state_from_docker(status: str) -> ContainerState:
    """Map Docker container status string to ContainerState."""
    mapping = {
        "created": ContainerState.CREATED,
        "running": ContainerState.RUNNING,
        "paused": ContainerState.PAUSED,
        "restarting": ContainerState.RUNNING,
        "removing": ContainerState.STOPPED,
        "exited": ContainerState.STOPPED,
        "dead": ContainerState.ERROR,
    }
    return mapping.get(status, ContainerState.ERROR)


class DockerBackend(ContainerBackend):
    """Docker/Podman backend via the Docker SDK.

    Works with:
    - Docker Engine (Linux/macOS/Windows)
    - Docker Desktop (Windows/macOS)
    - Podman with Docker-compatible socket
    """

    def __init__(self, base_url: Optional[str] = None):
        self._base_url = base_url
        self._client: Optional[docker.DockerClient] = None

    def _get_client(self) -> docker.DockerClient:
        if self._client is None:
            if self._base_url:
                self._client = docker.DockerClient(base_url=self._base_url)
            else:
                self._client = docker.from_env()
        return self._client

    def is_available(self) -> bool:
        try:
            client = self._get_client()
            client.ping()
            return True
        except Exception as e:
            logger.debug("Docker backend not available: %s", e)
            return False

    def get_info(self) -> dict[str, Any]:
        try:
            client = self._get_client()
            info = client.info()
            return {
                "runtime": info.get("Name", "docker"),
                "version": client.version().get("Version", "unknown"),
                "os": info.get("OperatingSystem", "unknown"),
                "arch": info.get("Architecture", "unknown"),
                "storage_driver": info.get("Driver", "unknown"),
                "cgroup_driver": info.get("CgroupDriver", "unknown"),
            }
        except Exception as e:
            return {"error": str(e)}

    def create(self, config: ContainerConfig) -> str:
        client = self._get_client()

        # Ensure image exists
        try:
            client.images.get(config.image)
        except ImageNotFound:
            client.images.pull(config.image)

        # Build mount list
        volumes = {}
        binds = []
        for mount in config.bind_mounts:
            mode = mount.get("mode", "rw")
            source = mount["source"]
            target = mount["target"]
            binds.append(f"{source}:{target}:{mode}")

        # Build tmpfs
        tmpfs = config.tmpfs_mounts if config.tmpfs_mounts else {}

        # Host config
        host_config = {
            "binds": binds,
            "tmpfs": tmpfs,
            "mem_limit": config.mem_limit,
            "cpu_quota": config.cpu_quota,
            "cpu_period": config.cpu_period,
            "pids_limit": config.pids_limit,
            "network_mode": config.network_mode,
            "dns": config.dns if config.dns else None,
            "security_opt": config.security_opt if config.security_opt else None,
            "cap_drop": config.cap_drop,
            "cap_add": config.cap_add if config.cap_add else None,
            "read_only": config.read_only_root,
        }
        if config.runtime:
            host_config["runtime"] = config.runtime

        container = client.api.create_container(
            image=config.image,
            name=config.name,
            hostname=config.hostname,
            working_dir=config.working_dir,
            environment=config.environment,
            user=config.user,
            labels={"managed-by": "lasso", "lasso-profile": config.name},
            stdin_open=True,
            tty=False,
            host_config=client.api.create_host_config(**host_config),
            # Keep the container running with a sleep process
            command=["sleep", "infinity"],
        )

        return container["Id"]

    def start(self, container_id: str) -> None:
        client = self._get_client()
        client.api.start(container_id)

    def stop(self, container_id: str, timeout: int = 10) -> None:
        client = self._get_client()
        try:
            client.api.stop(container_id, timeout=timeout)
        except (NotFound, APIError):
            pass

    def remove(self, container_id: str, force: bool = False) -> None:
        client = self._get_client()
        try:
            client.api.remove_container(container_id, force=force)
        except (NotFound, APIError):
            pass

    def exec(self, container_id: str, command: list[str],
             timeout: int = 300) -> ExecResult:
        client = self._get_client()
        start = time.monotonic_ns()

        try:
            exec_id = client.api.exec_create(
                container_id,
                cmd=command,
                stdout=True,
                stderr=True,
                workdir="/workspace",
            )

            output = client.api.exec_start(exec_id["Id"], demux=True)

            # output is (stdout_bytes, stderr_bytes) when demux=True
            stdout_bytes = output[0] if output[0] else b""
            stderr_bytes = output[1] if output[1] else b""

            inspect = client.api.exec_inspect(exec_id["Id"])
            exit_code = inspect.get("ExitCode", -1)

            duration_ms = (time.monotonic_ns() - start) // 1_000_000

            return ExecResult(
                exit_code=exit_code,
                stdout=stdout_bytes.decode(errors="replace"),
                stderr=stderr_bytes.decode(errors="replace"),
                duration_ms=duration_ms,
            )
        except APIError as e:
            duration_ms = (time.monotonic_ns() - start) // 1_000_000
            return ExecResult(
                exit_code=-1,
                stdout="",
                stderr=f"Docker API error: {e}",
                duration_ms=duration_ms,
            )

    def inspect(self, container_id: str) -> ContainerInfo:
        client = self._get_client()
        data = client.api.inspect_container(container_id)
        state_str = data.get("State", {}).get("Status", "unknown")

        return ContainerInfo(
            container_id=container_id[:12],
            name=data.get("Name", "").lstrip("/"),
            state=_state_from_docker(state_str),
            image=data.get("Config", {}).get("Image", ""),
            created_at=data.get("Created", ""),
            pid=data.get("State", {}).get("Pid", 0),
            network_mode=data.get("HostConfig", {}).get("NetworkMode", ""),
        )

    def logs(self, container_id: str, tail: int = 100) -> str:
        client = self._get_client()
        return client.api.logs(
            container_id, tail=tail, stdout=True, stderr=True
        ).decode(errors="replace")

    def list_containers(self, label_filter: str = "lasso") -> list[ContainerInfo]:
        client = self._get_client()
        containers = client.api.containers(
            all=True,
            filters={"label": f"managed-by={label_filter}"},
        )
        results = []
        for c in containers:
            results.append(ContainerInfo(
                container_id=c["Id"][:12],
                name=c.get("Names", [""])[0].lstrip("/"),
                state=_state_from_docker(c.get("State", "unknown")),
                image=c.get("Image", ""),
                created_at=str(c.get("Created", "")),
            ))
        return results

    def create_network(self, name: str, internal: bool = True,
                       allowed_cidrs: list[str] | None = None) -> str:
        client = self._get_client()
        network = client.api.create_network(
            name=name,
            driver="bridge",
            internal=internal,
            labels={"managed-by": "lasso"},
        )
        return network["Id"]

    def remove_network(self, name: str) -> None:
        client = self._get_client()
        try:
            client.api.remove_network(name)
        except (NotFound, APIError):
            pass

    def build_image(self, dockerfile_content: str, tag: str) -> str:
        client = self._get_client()
        fileobj = io.BytesIO(dockerfile_content.encode())
        image, logs = client.images.build(fileobj=fileobj, tag=tag, rm=True)
        return image.id

    def image_exists(self, tag: str) -> bool:
        client = self._get_client()
        try:
            client.images.get(tag)
            return True
        except ImageNotFound:
            return False
