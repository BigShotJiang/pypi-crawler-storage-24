"""Build custom container images per sandbox profile.

Generates Dockerfiles that install only the whitelisted tools,
creating minimal attack-surface images.
"""

from __future__ import annotations

import logging
from typing import Optional

from lasso.backends.base import ContainerBackend
from lasso.config.schema import CommandMode, SandboxProfile

logger = logging.getLogger("lasso.image_builder")

# Map command names to apt packages
TOOL_TO_PACKAGE: dict[str, str] = {
    "python3": "python3",
    "python": "python3",
    "pip": "python3-pip",
    "pip3": "python3-pip",
    "git": "git",
    "curl": "curl",
    "wget": "wget",
    "node": "nodejs",
    "npm": "nodejs npm",
    "npx": "nodejs npm",
    "Rscript": "r-base",
    "R": "r-base",
    "make": "make",
    "cmake": "cmake",
    "gcc": "gcc",
    "g++": "g++",
    "rustc": "rustc",
    "cargo": "cargo",
    "tar": "tar",
    "gzip": "gzip",
    "gunzip": "gzip",
    "zip": "zip",
    "unzip": "unzip",
    "jq": "jq",
    "ssh": "openssh-client",
    "scp": "openssh-client",
    "rsync": "rsync",
    "sqlite3": "sqlite3",
    "iptables": "iptables",
}

# These are always available in the base image (coreutils/busybox)
BUILTIN_COMMANDS = {
    "ls", "cat", "head", "tail", "grep", "find", "wc", "sort", "uniq",
    "diff", "mkdir", "cp", "mv", "touch", "echo", "printf", "test",
    "env", "basename", "dirname", "pwd", "sleep", "true", "false",
    "sh", "bash", "date", "tee", "xargs", "tr", "cut", "sed", "awk",
}


def generate_dockerfile(profile: SandboxProfile) -> str:
    """Generate a Dockerfile that installs only the whitelisted tools."""
    packages = set()

    if profile.commands.mode == CommandMode.WHITELIST:
        for cmd in profile.commands.whitelist:
            if cmd in BUILTIN_COMMANDS:
                continue
            if cmd in TOOL_TO_PACKAGE:
                for pkg in TOOL_TO_PACKAGE[cmd].split():
                    packages.add(pkg)

    # Always include iptables when the profile requires network policy rules.
    # Without iptables the container cannot enforce firewall restrictions and
    # _apply_network_policy() will fail at startup.
    from lasso.backends.converter import needs_network_rules
    if needs_network_rules(profile):
        packages.add("iptables")

    packages_str = " ".join(sorted(packages)) if packages else ""

    lines = [
        "FROM python:3.12-slim",
        "",
        "LABEL managed-by=lasso",
        f"LABEL lasso-profile={profile.name}",
        "",
        "RUN apt-get update \\",
    ]

    if packages_str:
        lines.append(f"    && apt-get install -y --no-install-recommends {packages_str} \\")

    lines.extend([
        "    && apt-get clean \\",
        "    && rm -rf /var/lib/apt/lists/*",
        "",
        "RUN useradd -m -u 1000 -s /bin/bash sandbox",
        "",
        "WORKDIR /workspace",
        "USER sandbox",
        "",
        'CMD ["sleep", "infinity"]',
    ])

    return "\n".join(lines) + "\n"


def image_tag(profile: SandboxProfile) -> str:
    """Deterministic image tag based on profile config hash."""
    return f"lasso-{profile.config_hash()[:12]}"


def ensure_image(
    backend: ContainerBackend,
    profile: SandboxProfile,
    force_rebuild: bool = False,
) -> str:
    """Ensure a sandbox image exists for this profile. Build if needed.

    Returns the image tag.
    """
    tag = image_tag(profile)

    if not force_rebuild and backend.image_exists(tag):
        logger.debug("Image %s already exists", tag)
        return tag

    logger.info("Building sandbox image %s for profile '%s'", tag, profile.name)
    dockerfile = generate_dockerfile(profile)
    backend.build_image(dockerfile, tag)
    logger.info("Image %s built successfully", tag)
    return tag
