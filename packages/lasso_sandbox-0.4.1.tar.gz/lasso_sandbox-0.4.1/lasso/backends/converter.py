"""Convert SandboxProfile → ContainerConfig.

This is the bridge between LASSO's domain model and the container runtime.
All platform-specific translation happens here.
"""

from __future__ import annotations

import platform
import re
import subprocess

from lasso.backends.base import ContainerConfig
from lasso.config.schema import NetworkMode, SandboxProfile


def _to_docker_mount_path(host_path: str) -> str:
    """Convert a host path to Docker mount format.

    On Windows, Docker Desktop expects Unix-style paths with the drive
    letter lowercased:  C:\\Users\\me\\project  ->  /c/Users/me/project

    On Linux/macOS, paths are returned unchanged.
    """
    if platform.system() != "Windows":
        return host_path

    # Normalise to forward slashes
    path = host_path.replace("\\", "/")

    # Convert drive letter: C:/foo -> /c/foo
    match = re.match(r"^([A-Za-z]):/(.*)$", path)
    if match:
        drive = match.group(1).lower()
        rest = match.group(2)
        return f"/{drive}/{rest}"

    return path


def profile_to_container_config(profile: SandboxProfile) -> ContainerConfig:
    """Translate a SandboxProfile into a platform-agnostic ContainerConfig."""

    bind_mounts = _build_mounts(profile)
    network_mode = _resolve_network_mode(profile)
    tmpfs = _build_tmpfs(profile)
    environment = _build_environment(profile)
    cap_add = _resolve_cap_add(profile)

    runtime = _resolve_runtime(profile)

    return ContainerConfig(
        name=f"lasso-{profile.name}",
        working_dir="/workspace",
        hostname="lasso-sandbox",
        bind_mounts=bind_mounts,
        read_only_root=True,
        tmpfs_mounts=tmpfs,
        mem_limit=f"{profile.resources.max_memory_mb}m",
        cpu_quota=profile.resources.max_cpu_percent * 1000,
        cpu_period=100000,
        pids_limit=profile.resources.max_pids,
        network_mode=network_mode,
        dns=profile.network.dns_servers if profile.network.mode != NetworkMode.NONE else [],
        environment=environment,
        security_opt=["no-new-privileges"],
        cap_drop=["ALL"],
        cap_add=cap_add,
        user="1000:1000",
        runtime=runtime,
    )


def _build_mounts(profile: SandboxProfile) -> list[dict[str, str]]:
    """Build bind mount specs from the profile's filesystem config.

    On Windows, host paths are converted to Docker Desktop mount format
    (e.g. C:\\Users\\me -> /c/Users/me).
    """
    mounts = []

    # Working directory -> /workspace (read-write)
    mounts.append({
        "source": _to_docker_mount_path(profile.filesystem.working_dir),
        "target": "/workspace",
        "mode": "rw",
    })

    # Additional writable paths
    for path in profile.filesystem.writable_paths:
        mounts.append({
            "source": _to_docker_mount_path(path),
            "target": path,
            "mode": "rw",
        })

    return mounts


def _resolve_network_mode(profile: SandboxProfile) -> str:
    """Map LASSO network mode to container network mode."""
    if profile.network.mode == NetworkMode.NONE:
        return "none"
    if profile.network.mode == NetworkMode.FULL:
        return "bridge"
    # RESTRICTED: use a custom LASSO-managed network
    return f"lasso-net-{profile.name}"


def _build_tmpfs(profile: SandboxProfile) -> dict[str, str]:
    """Build tmpfs mount specs."""
    return {
        "/tmp": f"size={profile.filesystem.temp_dir_mb}m,mode=1777",
    }


def _detect_git_identity() -> dict[str, str]:
    """Detect the host git user.name and user.email for commit attribution."""
    env: dict[str, str] = {}
    try:
        name = subprocess.run(
            ["git", "config", "user.name"],
            capture_output=True, text=True, timeout=5,
        )
        email = subprocess.run(
            ["git", "config", "user.email"],
            capture_output=True, text=True, timeout=5,
        )
        if name.returncode == 0 and name.stdout.strip():
            env["GIT_AUTHOR_NAME"] = name.stdout.strip()
            env["GIT_COMMITTER_NAME"] = name.stdout.strip()
        if email.returncode == 0 and email.stdout.strip():
            env["GIT_AUTHOR_EMAIL"] = email.stdout.strip()
            env["GIT_COMMITTER_EMAIL"] = email.stdout.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    return env


def _build_environment(profile: SandboxProfile) -> dict[str, str]:
    """Build environment variables for the container."""
    env = {
        "LASSO_SANDBOX_NAME": profile.name,
        "LANG": "C.UTF-8",
        "LC_ALL": "C.UTF-8",
        "TERM": "dumb",
        "HOME": "/workspace",
    }
    env.update(_detect_git_identity())
    env.update(profile.extra_env)
    return env


def _resolve_cap_add(profile: SandboxProfile) -> list[str]:
    """Determine additional capabilities needed for network policy enforcement.

    When network rules (iptables) need to be applied inside the container,
    the container needs NET_ADMIN capability temporarily during setup.

    Dependency: the container image MUST have iptables installed for these
    rules to work.  image_builder.generate_dockerfile() automatically adds
    the iptables package when needs_network_rules() is True.  If iptables
    is missing, _apply_network_policy() in sandbox.py will raise a
    RuntimeError at startup.
    """
    if needs_network_rules(profile):
        return ["NET_ADMIN"]
    return []


def _resolve_runtime(profile: SandboxProfile) -> str:
    """Map isolation level to OCI runtime name."""
    level = getattr(profile, "isolation", "container")
    if level == "gvisor":
        return "runsc"
    if level == "kata":
        return "io.containerd.kata.v2"
    return ""


def needs_network_rules(profile: SandboxProfile) -> bool:
    """Check whether this profile requires iptables rules applied post-start.

    - NONE mode with container network_mode="none": Docker handles isolation,
      but we still apply iptables for defense-in-depth (loopback only).
    - RESTRICTED mode: iptables rules enforce allow-list inside the container.
    - FULL mode with blocked_cidrs: iptables rules block specific CIDRs.
    - FULL mode without blocked_cidrs: no rules needed.
    """
    mode = profile.network.mode
    if mode == NetworkMode.NONE:
        return True
    if mode == NetworkMode.RESTRICTED:
        return True
    if mode == NetworkMode.FULL and profile.network.blocked_cidrs:
        return True
    return False
