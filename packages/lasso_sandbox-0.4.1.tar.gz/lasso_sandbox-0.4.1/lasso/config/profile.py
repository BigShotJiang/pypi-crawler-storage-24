"""Profile persistence — save / load / list / delete sandbox profiles."""

from __future__ import annotations

import logging
import os
from pathlib import Path

import tomli
import tomli_w

from lasso.config.schema import SandboxProfile

logger = logging.getLogger("lasso.profile")

DEFAULT_PROFILE_DIR = Path.home() / ".lasso" / "profiles"


def _ensure_dir(profile_dir: Path) -> None:
    profile_dir.mkdir(parents=True, exist_ok=True)


def _validate_profile_name(name: str) -> None:
    """Reject profile names that could escape the profile directory."""
    if "/" in name or "\\" in name or ".." in name:
        raise ValueError(
            f"Invalid profile name '{name}': must not contain '/', '\\', or '..'"
        )


def profile_path(name: str, profile_dir: Path = DEFAULT_PROFILE_DIR) -> Path:
    _validate_profile_name(name)
    return profile_dir / f"{name}.toml"


def _strip_none(obj):
    """Recursively remove None values from dicts (TOML can't serialize None)."""
    if isinstance(obj, dict):
        return {k: _strip_none(v) for k, v in obj.items() if v is not None}
    if isinstance(obj, list):
        return [_strip_none(i) for i in obj]
    return obj


def save_profile(profile: SandboxProfile, profile_dir: Path = DEFAULT_PROFILE_DIR) -> Path:
    """Serialize a SandboxProfile to a TOML file. Returns the path written."""
    _validate_profile_name(profile.name)
    _ensure_dir(profile_dir)
    dest = profile_path(profile.name, profile_dir)
    data = _strip_none(profile.model_dump(mode="json"))
    dest.write_bytes(tomli_w.dumps(data).encode())
    return dest


def load_profile(name: str, profile_dir: Path = DEFAULT_PROFILE_DIR) -> SandboxProfile:
    """Load a named profile from disk."""
    path = profile_path(name, profile_dir)
    if not path.exists():
        raise FileNotFoundError(f"Profile '{name}' not found at {path}")
    try:
        with open(path, "rb") as f:
            data = tomli.load(f)
    except tomli.TOMLDecodeError as e:
        logger.error("Failed to parse profile %s: %s", path, e)
        raise ValueError(f"Profile '{name}' has invalid TOML syntax: {e}") from e
    try:
        return SandboxProfile(**data)
    except Exception as e:
        logger.error("Invalid profile data in %s: %s", path, e)
        raise ValueError(f"Profile '{name}' has invalid configuration: {e}") from e


def load_profile_from_path(path: str | Path) -> SandboxProfile:
    """Load a profile from an arbitrary TOML file path."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Profile file not found: {path}")
    try:
        with open(path, "rb") as f:
            data = tomli.load(f)
    except tomli.TOMLDecodeError as e:
        logger.error("Failed to parse profile %s: %s", path, e)
        raise ValueError(f"Profile at '{path}' has invalid TOML syntax: {e}") from e
    try:
        return SandboxProfile(**data)
    except Exception as e:
        logger.error("Invalid profile data in %s: %s", path, e)
        raise ValueError(f"Profile at '{path}' has invalid configuration: {e}") from e


def list_profiles(profile_dir: Path = DEFAULT_PROFILE_DIR) -> list[dict]:
    """Return summary dicts for all saved profiles."""
    _ensure_dir(profile_dir)
    results = []
    for toml_file in sorted(profile_dir.glob("*.toml")):
        try:
            with open(toml_file, "rb") as f:
                data = tomli.load(f)
            p = SandboxProfile(**data)
            summary = p.summary()
            summary["path"] = str(toml_file)
            results.append(summary)
        except Exception as e:
            results.append({"name": toml_file.stem, "error": str(e)})
    return results


def delete_profile(name: str, profile_dir: Path = DEFAULT_PROFILE_DIR) -> bool:
    """Delete a profile. Returns True if it existed."""
    _validate_profile_name(name)
    path = profile_path(name, profile_dir)
    if path.exists():
        path.unlink()
        return True
    return False
