"""LASSO - Layered Agent Sandbox Security Orchestrator."""

__version__ = "0.4.1"

__all__ = ["__version__"]
