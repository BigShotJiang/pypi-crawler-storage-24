"""API key authentication and rate limiting middleware for the LASSO REST API.

API keys are stored in ~/.lasso/api_keys.json with the format:
{
    "keys": {
        "<key-string>": {
            "name": "human label",
            "created_at": "ISO timestamp",
            "scopes": ["read", "write", "admin"]
        }
    }
}

Rate limiting: in-memory sliding window counter, max 100 requests/minute
per API key.
"""

from __future__ import annotations

import functools
import json
import logging
import secrets
import time
from collections import defaultdict
from pathlib import Path
from typing import Any, Optional

from flask import Request, current_app, g, jsonify, request

logger = logging.getLogger("lasso.api.auth")

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_KEY_FILE = Path.home() / ".lasso" / "api_keys.json"
RATE_LIMIT_MAX = 100  # requests per window
RATE_LIMIT_WINDOW = 60  # seconds


# ---------------------------------------------------------------------------
# API key store
# ---------------------------------------------------------------------------

class APIKeyStore:
    """Loads and validates API keys from a JSON file on disk."""

    def __init__(self, key_file: Optional[Path] = None):
        self._key_file = key_file or DEFAULT_KEY_FILE
        self._keys: dict[str, dict[str, Any]] = {}
        self._loaded = False

    def _ensure_loaded(self) -> None:
        """Load keys from disk (lazy, cached per instance)."""
        if self._loaded:
            return
        self._loaded = True
        if not self._key_file.exists():
            logger.debug("No API key file at %s", self._key_file)
            return
        try:
            data = json.loads(self._key_file.read_text())
            self._keys = data.get("keys", {})
            logger.info("Loaded %d API key(s) from %s", len(self._keys), self._key_file)
        except (json.JSONDecodeError, OSError) as exc:
            logger.warning("Failed to load API keys from %s: %s", self._key_file, exc)

    def reload(self) -> None:
        """Force reload keys from disk."""
        self._loaded = False
        self._ensure_loaded()

    def validate(self, key: str) -> Optional[dict[str, Any]]:
        """Return key metadata if valid, None otherwise."""
        self._ensure_loaded()
        return self._keys.get(key)

    def has_scope(self, key: str, scope: str) -> bool:
        """Check if a key has a specific scope."""
        meta = self.validate(key)
        if meta is None:
            return False
        scopes = meta.get("scopes", [])
        # "admin" scope grants everything
        return scope in scopes or "admin" in scopes

    @property
    def is_configured(self) -> bool:
        """True if at least one API key is loaded."""
        self._ensure_loaded()
        return len(self._keys) > 0

    @staticmethod
    def generate_key() -> str:
        """Generate a new random API key."""
        return f"lasso_{secrets.token_urlsafe(32)}"

    def save_key(self, key: str, name: str, scopes: Optional[list[str]] = None) -> None:
        """Persist a new key to the key file."""
        from datetime import datetime, timezone

        self._ensure_loaded()
        self._keys[key] = {
            "name": name,
            "created_at": datetime.now(timezone.utc).isoformat(),
            "scopes": scopes or ["read", "write"],
        }
        self._key_file.parent.mkdir(parents=True, exist_ok=True)
        self._key_file.write_text(json.dumps({"keys": self._keys}, indent=2))
        # Restrict permissions (owner read/write only)
        try:
            self._key_file.chmod(0o600)
        except OSError:
            pass  # Windows may not support chmod


# ---------------------------------------------------------------------------
# Rate limiter (in-memory sliding window)
# ---------------------------------------------------------------------------

class RateLimiter:
    """In-memory per-key sliding window rate limiter."""

    def __init__(self, max_requests: int = RATE_LIMIT_MAX, window_seconds: int = RATE_LIMIT_WINDOW):
        self.max_requests = max_requests
        self.window_seconds = window_seconds
        self._requests: dict[str, list[float]] = defaultdict(list)

    def is_allowed(self, key: str) -> tuple[bool, dict[str, int | str]]:
        """Check if a request is allowed for the given key.

        Returns (allowed, headers_dict) where headers_dict contains
        rate limit info for X-RateLimit-* response headers including:
            - X-RateLimit-Limit: maximum requests per window
            - X-RateLimit-Remaining: remaining requests in current window
            - X-RateLimit-Reset: epoch timestamp when the window resets
            - X-RateLimit-Window: window size in seconds
        """
        now = time.monotonic()
        wall_now = time.time()
        window_start = now - self.window_seconds

        # Prune old entries
        timestamps = self._requests[key]
        self._requests[key] = [t for t in timestamps if t > window_start]
        timestamps = self._requests[key]

        remaining = max(0, self.max_requests - len(timestamps))
        # Calculate the wall-clock reset time: when the oldest request
        # in the window expires, or now + window if there are no requests.
        if timestamps:
            oldest_monotonic = timestamps[0]
            reset_in = self.window_seconds - (now - oldest_monotonic)
            reset_epoch = int(wall_now + max(0, reset_in))
        else:
            reset_epoch = int(wall_now + self.window_seconds)

        headers = {
            "X-RateLimit-Limit": self.max_requests,
            "X-RateLimit-Remaining": remaining,
            "X-RateLimit-Reset": reset_epoch,
            "X-RateLimit-Window": self.window_seconds,
        }

        if len(timestamps) >= self.max_requests:
            return False, headers

        timestamps.append(now)
        headers["X-RateLimit-Remaining"] = max(0, self.max_requests - len(timestamps))
        return True, headers

    def reset(self, key: Optional[str] = None) -> None:
        """Reset rate limit counters. If key is None, reset all."""
        if key:
            self._requests.pop(key, None)
        else:
            self._requests.clear()


# ---------------------------------------------------------------------------
# Singleton instances (attached to Flask app)
# ---------------------------------------------------------------------------

def get_key_store() -> APIKeyStore:
    """Get the API key store from the current Flask app."""
    store = current_app.config.get("API_KEY_STORE")
    if store is None:
        key_file = current_app.config.get("API_KEY_FILE")
        store = APIKeyStore(key_file=Path(key_file) if key_file else None)
        current_app.config["API_KEY_STORE"] = store
    return store


def get_rate_limiter() -> RateLimiter:
    """Get the rate limiter from the current Flask app."""
    limiter = current_app.config.get("API_RATE_LIMITER")
    if limiter is None:
        limiter = RateLimiter()
        current_app.config["API_RATE_LIMITER"] = limiter
    return limiter


# ---------------------------------------------------------------------------
# Decorator / before-request hook
# ---------------------------------------------------------------------------

def _extract_api_key(req: Request) -> Optional[str]:
    """Extract API key from the X-API-Key header."""
    return req.headers.get("X-API-Key")


def require_api_key(f):
    """Decorator that enforces API key authentication and rate limiting.

    Sets g.api_key and g.api_key_meta on success.
    """

    @functools.wraps(f)
    def decorated(*args, **kwargs):
        store = get_key_store()

        # Reject requests when no API keys are configured
        if not store.is_configured:
            return jsonify({
                "success": False,
                "data": None,
                "error": "No API keys configured. Create one with: lasso api-key create",
            }), 401

        key = _extract_api_key(request)
        if not key:
            return jsonify({
                "success": False,
                "data": None,
                "error": "Missing API key. Provide via X-API-Key header.",
            }), 401

        meta = store.validate(key)
        if meta is None:
            return jsonify({
                "success": False,
                "data": None,
                "error": "Invalid API key.",
            }), 401

        # Rate limiting
        limiter = get_rate_limiter()
        allowed, rate_headers = limiter.is_allowed(key)

        if not allowed:
            resp = jsonify({
                "success": False,
                "data": None,
                "error": "Rate limit exceeded. Max {}/{}s.".format(
                    limiter.max_requests, limiter.window_seconds
                ),
            })
            resp.status_code = 429
            for h, v in rate_headers.items():
                resp.headers[h] = str(v)
            return resp

        g.api_key = key
        g.api_key_meta = meta

        response = f(*args, **kwargs)

        # Attach rate limit headers to all responses from the view function.
        # Flask views may return a Response object or a (response, status) tuple.
        if isinstance(response, tuple):
            resp_obj = response[0]
            if hasattr(resp_obj, "headers"):
                for h, v in rate_headers.items():
                    resp_obj.headers[h] = str(v)
        elif hasattr(response, "headers"):
            for h, v in rate_headers.items():
                response.headers[h] = str(v)
        return response

    return decorated
