"""Prometheus metrics collector and endpoint for LASSO.

Provides a thread-safe in-memory metrics collector that renders
Prometheus text exposition format. No external dependencies.

Metrics exposed:
    lasso_info                    — Info metric with version label
    lasso_sandboxes_total         — Gauge: sandbox count by state
    lasso_commands_total          — Counter: commands by outcome
    lasso_api_requests_total      — Counter: API requests by method/status
    lasso_audit_events_total      — Counter: audit events by type
"""

from __future__ import annotations

import threading
import time
from typing import Any, Optional

from lasso import __version__


class MetricsCollector:
    """Thread-safe Prometheus metrics collector.

    Supports counters (monotonically increasing) and gauges (arbitrary values).
    Renders all metrics in Prometheus text exposition format via ``render()``.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._counters: dict[str, dict[str, float]] = {}
        self._gauges: dict[str, dict[str, float]] = {}
        self._help: dict[str, str] = {}
        self._types: dict[str, str] = {}

        # Register built-in metrics
        self._register("lasso_info", "gauge", "LASSO version information")
        self._register("lasso_sandboxes_total", "gauge", "Number of sandboxes by state")
        self._register("lasso_commands_total", "counter", "Total commands executed by outcome")
        self._register("lasso_api_requests_total", "counter", "Total API requests by method and status class")
        self._register("lasso_audit_events_total", "counter", "Total audit events by type")

        # Set the info metric
        self.gauge("lasso_info", 1, {"version": __version__})

    def _register(self, name: str, metric_type: str, help_text: str) -> None:
        """Register a metric name with type and help text."""
        self._help[name] = help_text
        self._types[name] = metric_type
        if metric_type == "counter":
            self._counters.setdefault(name, {})
        elif metric_type == "gauge":
            self._gauges.setdefault(name, {})

    def _labels_key(self, labels: Optional[dict[str, str]] = None) -> str:
        """Convert a labels dict to a Prometheus label string."""
        if not labels:
            return ""
        parts = ",".join(f'{k}="{v}"' for k, v in sorted(labels.items()))
        return "{" + parts + "}"

    def increment(self, name: str, labels: Optional[dict[str, str]] = None, value: float = 1) -> None:
        """Increment a counter metric."""
        key = self._labels_key(labels)
        with self._lock:
            if name not in self._counters:
                self._counters[name] = {}
            self._counters[name][key] = self._counters[name].get(key, 0) + value

    def gauge(self, name: str, value: float, labels: Optional[dict[str, str]] = None) -> None:
        """Set an absolute gauge value."""
        key = self._labels_key(labels)
        with self._lock:
            if name not in self._gauges:
                self._gauges[name] = {}
            self._gauges[name][key] = value

    def render(self) -> str:
        """Render all metrics in Prometheus text exposition format."""
        lines: list[str] = []

        with self._lock:
            # Collect all metric names in registration order
            all_names: list[str] = []
            for name in self._help:
                all_names.append(name)

            for name in all_names:
                help_text = self._help.get(name, "")
                metric_type = self._types.get(name, "untyped")

                lines.append(f"# HELP {name} {help_text}")
                lines.append(f"# TYPE {name} {metric_type}")

                if metric_type == "counter":
                    samples = self._counters.get(name, {})
                elif metric_type == "gauge":
                    samples = self._gauges.get(name, {})
                else:
                    samples = {}

                if not samples:
                    # Emit a zero-value line for counters with no labels
                    if metric_type == "counter":
                        lines.append(f"{name} 0")
                else:
                    for label_str, value in sorted(samples.items()):
                        # Format value: integer if whole number, else float
                        if value == int(value):
                            val_str = str(int(value))
                        else:
                            val_str = str(value)
                        lines.append(f"{name}{label_str} {val_str}")

        lines.append("")  # trailing newline
        return "\n".join(lines)


def _status_class(status_code: int) -> str:
    """Map HTTP status code to class string (2xx, 4xx, 5xx)."""
    if 200 <= status_code < 300:
        return "2xx"
    elif 400 <= status_code < 500:
        return "4xx"
    elif 500 <= status_code < 600:
        return "5xx"
    else:
        return f"{status_code // 100}xx"


def init_metrics(app: Any) -> MetricsCollector:
    """Initialize metrics collection on a Flask app.

    - Stores the MetricsCollector in app.config["METRICS"]
    - Registers an after_request hook to count API requests
    - Registers the /metrics endpoint

    Returns the MetricsCollector instance.
    """
    collector = MetricsCollector()
    app.config["METRICS"] = collector

    @app.after_request
    def _count_api_request(response):
        """Increment API request counter for /api/ routes."""
        from flask import request
        if request.path.startswith("/api/"):
            method = request.method
            status = _status_class(response.status_code)
            collector.increment(
                "lasso_api_requests_total",
                {"method": method, "status": status},
            )
        return response

    @app.route("/metrics")
    def metrics_endpoint():
        """Prometheus metrics endpoint."""
        from flask import Response

        # Update sandbox gauges from registry before rendering
        registry = app.config.get("REGISTRY")
        if registry:
            sandboxes = registry.list_all()
            state_counts = {"running": 0, "stopped": 0, "error": 0}
            for sb in sandboxes:
                state = sb.get("state", "unknown")
                if state in state_counts:
                    state_counts[state] += 1
            for state, count in state_counts.items():
                collector.gauge("lasso_sandboxes_total", count, {"state": state})

        body = collector.render()
        return Response(body, mimetype="text/plain; version=0.0.4; charset=utf-8")

    return collector
