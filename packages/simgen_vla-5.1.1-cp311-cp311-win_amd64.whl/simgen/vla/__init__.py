"""
SimGen VLA - High-Precision GPU Arithmetic
===========================================

Drop-in PyTorch replacement with exact arithmetic.
Native CUDA kernels for 83 operations.
"""

__version__ = "5.1.1"

# Core exports - all torch-compatible API
from .vla import (
    # Core class
    Tensor,

    # Creation functions
    tensor,
    zeros,
    ones,
    randn,
    rand,
    arange,
    linspace,
    eye,

    # Reductions
    sum,
    mean,
    prod,
    min,
    max,
    std,
    var,

    # Linear algebra
    matmul,
    mm,
    mv,
    dot,
    bmm,

    # Math functions
    exp,
    log,
    sqrt,
    abs,
    sin,
    cos,
    tan,
    tanh,
    sigmoid,

    # Activations (Native CUDA)
    relu,
    gelu,
    silu,
    softmax,

    # Shape functions
    reshape,
    transpose,
    squeeze,
    unsqueeze,
    stack,
    cat,

    # World-changing ops (Native CUDA)
    conv2d,
    lu,
    solve,
    inv,
    det,
    qr,
    eig,

    # Device/dtype
    float32,
    float64,
    device,
    cuda,
    cpu,

    # Exact output (NEW in 5.1.1)
    Decimal,  # For to_decimal() results
)

# Direct CUDA kernel access for advanced users
try:
    from . import cuda_kernels
except ImportError:
    cuda_kernels = None

__all__ = [
    '__version__',
    'Tensor',
    'tensor',
    'zeros',
    'ones',
    'randn',
    'rand',
    'arange',
    'linspace',
    'eye',
    'sum',
    'mean',
    'prod',
    'min',
    'max',
    'std',
    'var',
    'matmul',
    'mm',
    'mv',
    'dot',
    'bmm',
    'exp',
    'log',
    'sqrt',
    'abs',
    'sin',
    'cos',
    'tan',
    'tanh',
    'sigmoid',
    'relu',
    'gelu',
    'silu',
    'softmax',
    'reshape',
    'transpose',
    'squeeze',
    'unsqueeze',
    'stack',
    'cat',
    'conv2d',
    'lu',
    'solve',
    'inv',
    'det',
    'qr',
    'eig',
    'float32',
    'float64',
    'device',
    'cuda',
    'cpu',
    'cuda_kernels',
    'Decimal',  # For to_decimal() results
]
