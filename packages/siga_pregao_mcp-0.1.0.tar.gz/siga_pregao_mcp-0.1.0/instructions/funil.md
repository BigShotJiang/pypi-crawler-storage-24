# Instructions — Funil Operacional
## (Siga Pregão MCP)

## O Funil

```
OPORTUNIDADE → QUALIFICAÇÃO → DISPUTA → CLASSIFICAÇÃO → CONTRATO
```

| Etapa | O que acontece | Quem age |
|-------|---------------|----------|
| **Oportunidade** | Licitação identificada, cliente decide SIM/NÃO | Cliente |
| **Qualificação** | Leitura do edital, checklist de habilitação, docs | Agente + Cliente |
| **Disputa** | Cadastro de proposta no portal, lances em tempo real | Cliente + Agente |
| **Classificação** | Órgão analisa habilitação do vencedor | Agente + Cliente |
| **Contrato** | Assinatura, entrega, faturamento | Cliente |

---

## Quando mover de etapa

| De → Para | Gatilho |
|-----------|---------|
| Oportunidade → Qualificação | Cliente confirma participação (SIM) |
| Qualificação → Disputa | Checklist completo + proposta cadastrada no portal |
| Disputa → Classificação | Empresa venceu a sessão de lances |
| Classificação → Contrato | Habilitação aprovada + contrato assinado |

**Nunca pular etapas.** Se o cliente quiser ir direto para Disputa sem Qualificação, alertar sobre o risco.

---

## Checklist por etapa (referência)

### Oportunidade
- [ ] Manifestar interesse (SIM/NÃO)
- [ ] Identificar itens de participação
- [ ] Criar card no Siga

### Qualificação
- [ ] Baixar e ler edital completo
- [ ] Verificar habilitação: CND Federal, FGTS, CNDT, Estadual, Municipal
- [ ] Verificar se exige atestado técnico
- [ ] Identificar requisitos específicos (visita técnica, amostras)
- [ ] Verificar benefício ME/EPP
- [ ] Definir estratégia de itens/lotes

### Disputa
- [ ] Cadastrar proposta no portal antes do prazo (D-1 recomendado)
- [ ] Confirmar credenciais de acesso ao portal
- [ ] Definir preço de entrada e limite mínimo
- [ ] Acompanhar sessão de lances

### Classificação
- [ ] Enviar documentos de habilitação solicitados
- [ ] Monitorar publicação de resultado
- [ ] Verificar prazo de recurso (2 dias úteis após resultado)

### Contrato
- [ ] Assinar contrato no prazo (tipicamente 5 dias úteis)
- [ ] Emitir nota fiscal conforme cronograma
- [ ] Registrar entrega
