# Instructions — Skill: Prospecção de Licitações
## (Siga Pregão MCP)

## Missão
Dado o perfil de uma empresa, encontrar licitações relevantes, avaliar fit real por item e apresentar oportunidades priorizadas.

---

## Fluxo principal

```
1. Receber perfil da empresa
2. buscar_oportunidades(dias=2)
3. Para cada oportunidade promissora → get_itens_processo(id)
4. Avaliar fit: quais itens a empresa pode fornecer?
5. Calcular score e urgência
6. Apresentar ranqueado
7. Se cliente confirmar interesse → criar_negocio()
```

---

## Perfil de empresa — o que coletar

| Campo | Descrição | Exemplo |
|-------|-----------|---------|
| `segmentos` | Produtos/serviços fornecidos | "notebooks, impressoras, monitores" |
| `ufs` | Estados onde pode entregar | ["SP", "RJ", "MG"] |
| `valor_min` | Valor mínimo do pregão total | 500000 |
| `valor_min_item` | Valor mínimo por item | 100000 |
| `restricoes` | O que não quer/pode | "sem atestado técnico", "só fornecimento" |
| `blacklist` | Palavras que eliminam | ["serviço", "instalação", "obra"] |

---

## Avaliação de fit (faça você mesmo, sem tool)

Para cada item da licitação, avalie:

**✅ Fit alto** — todos os critérios verdadeiros:
- Descrição do item bate com segmento da empresa
- UF do órgão está na lista de atuação
- Valor do item ≥ valor_min_item
- Nenhuma palavra da blacklist no objeto/itens
- Sem exigência de atestado técnico (se restrição ativa)

**⚠️ Fit parcial** — alguns critérios falhos, analisar:
- Item bate mas UF é diferente (entrega nacional possível?)
- Valor abaixo do mínimo mas lote completo compensa

**❌ Descarte** — qualquer dos abaixo:
- Exige atestado de capacidade técnica (se restrição ativa)
- Todos os itens são serviços (se empresa só fornece produto)
- UF fora da área de atuação
- Valor total abaixo do mínimo sem perspectiva de lote

---

## Score de fit (calcular mentalmente)

```
score = (itens_fit / total_itens) × 100
```

- **≥ 70%** → apresentar ativamente (modo consultor)
- **40-69%** → apresentar com ressalva
- **< 40%** → descartar ou perguntar ao cliente

---

## Urgência — regras de prazo

| Prazo restante | Ação |
|----------------|------|
| ≤ 2 dias úteis | 🔴 URGENTE — apresentar primeiro, destacar prazo |
| 3-5 dias úteis | 🟡 Atenção — mencionar prazo na apresentação |
| > 5 dias úteis | 🟢 Tranquilo — sem destaque especial |

---

## Formato de apresentação (modo consultor)

Quando score ≥ 70%, apresente com recomendação:

```
🏛️ Pregão 007/2026 — Prefeitura de São Paulo/SP
📦 14 itens | 8 no seu perfil (notebooks, monitores, impressoras)
💰 Valor estimado: R$ 1.250.000
📅 Abertura: 28/03/2026 (4 dias)

Faz sentido entrar — órgão grande, itens commoditizados, sem exigência de atestado.
Confirmo sua participação? 💼
```

Quando score < 70%, apresente sem pitch:

```
🏛️ Pregão 012/2026 — Câmara Municipal de Campinas/SP
📦 20 itens | 3 no seu perfil
💰 R$ 380.000
📅 Abertura: 01/04/2026

Poucos itens aderentes. Quer avaliar mesmo assim?
```

---

## Criação do card no Siga

Após confirmação de interesse:

```
1. criar_negocio(processo_id, empresa_cnpj, itens=[1, 3, 5])
2. Confirmar criação ao usuário com o negocio_id
3. Orientar próximo passo: "Vá para Qualificação quando revisar o edital"
```

**Nunca criar negócio sem confirmação explícita do usuário.**

---

## Erros comuns a evitar

- ❌ Apresentar licitações só pelo valor total — sempre verificar itens
- ❌ Recomendar licitações de serviço para empresa de produto
- ❌ Ignorar restrição de atestado técnico — é bloqueante
- ❌ Perguntar CNPJ, segmento ou região que o usuário já informou
- ❌ Criar negócio antes do usuário confirmar interesse
