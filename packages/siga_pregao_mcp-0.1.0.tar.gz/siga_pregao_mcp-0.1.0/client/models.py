"""
Modelos Pydantic — Siga Pregão
Representam as entidades retornadas pela API do Siga.
"""

from __future__ import annotations
from pydantic import BaseModel, Field
from typing import Optional
from enum import Enum


class Etapa(str, Enum):
    OPORTUNIDADE = "oportunidade"
    QUALIFICACAO = "qualificacao"
    DISPUTA = "disputa"
    CLASSIFICACAO = "classificacao"
    CONTRATO = "contrato"


class Empresa(BaseModel):
    id: int
    cnpj: str
    nome: str
    ativa: bool = True


class Item(BaseModel):
    numero_item: int
    descricao: str
    quantidade: Optional[float] = None
    unidade: Optional[str] = None
    valor_unitario_estimado: Optional[float] = None
    valor_total: Optional[float] = None


class Oportunidade(BaseModel):
    """Licitação retornada pelo feed do Siga Pregão."""
    id: int                              # processo_id no Siga
    numero_controle: str                 # identificador PNCP/portal
    orgao_nome: str
    orgao_cnpj: Optional[str] = None
    objeto: str
    modalidade: Optional[str] = None
    numero_pregao: Optional[str] = None
    data_abertura: Optional[str] = None  # ISO date string
    valor_estimado: Optional[float] = None
    portal: Optional[str] = None
    uf: Optional[str] = None
    municipio: Optional[str] = None
    itens: list[Item] = Field(default_factory=list)

    @classmethod
    def _coerce_str(cls, v):
        return str(v) if v is not None else None


class Processo(BaseModel):
    """Processo completo com itens detalhados."""
    id: int
    numero_controle: str
    orgao_nome: str
    objeto: str
    modalidade: Optional[str] = None
    numero_pregao: Optional[str] = None
    data_abertura: Optional[str] = None
    valor_estimado: Optional[float] = None
    edital_url: Optional[str] = None
    itens: list[Item] = Field(default_factory=list)


class ChecklistItem(BaseModel):
    id: int
    descricao: str
    responsavel: str  # "b2g", "cliente", "adriano"
    concluido: bool = False
    secao: str


class Checklist(BaseModel):
    negocio_id: int
    itens: list[ChecklistItem] = Field(default_factory=list)

    @property
    def percentual_concluido(self) -> float:
        if not self.itens:
            return 0.0
        return round(sum(1 for i in self.itens if i.concluido) / len(self.itens) * 100, 1)


class Negocio(BaseModel):
    """Card no funil do Siga Pregão."""
    id: int
    nome: str
    etapa: Etapa
    empresa_id: int
    processo_id: Optional[int] = None
    numero_controle: Optional[str] = None
    itens_selecionados: list[int] = Field(default_factory=list)
    checklist: Optional[Checklist] = None
