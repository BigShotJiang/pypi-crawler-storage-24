"""
SigaClient — Conector oficial Siga Pregão
Encapsula toda comunicação HTTP com app.sigapregao.com.br

Uso:
    client = SigaClient(email="seu@email.com", password="suasenha")
    ops = client.oportunidades.buscar(dias=2)
    negocio = client.negocios.criar(processo_id=123, empresa_cnpj="06321283000150")
"""

from __future__ import annotations
import requests
from .models import Empresa, Oportunidade, Processo, Item, Negocio, Checklist, ChecklistItem, Etapa

BASE_URL = "https://app.sigapregao.com.br/app/api"

PORTAL_MAP = {
    "pncp": "PNCP",
    "compras.gov": "PCP",
    "comprasnet": "PCP",
    "bll": "BLL",
    "licitanet": "LICITANET",
    "banrisul": "BANRISUL",
    "caixa": "CAIXA",
    "procergs": "PROCERGS",
    "bnc": "BNC",
    "banpara": "BANPARA",
    "comprasgo": "COMPRASGO",
    "comprasrj": "COMPRASRJ",
    "comprasrs": "COMPRASRS",
    "comprasmg": "COMPRASMG",
    "pe integrado": "PEINTEGRADO",
}


class SigaAuth:
    """Gerencia autenticação e session JWT."""

    def __init__(self, email: str, password: str):
        self.email = email
        self.password = password
        self._session: requests.Session | None = None

    def session(self) -> requests.Session:
        if self._session is None:
            self._session = self._login()
        return self._session

    def _login(self) -> requests.Session:
        resp = requests.post(
            f"{BASE_URL}/auth/2/login",
            json={"email": self.email, "senha": self.password},
            timeout=15,
        )
        resp.raise_for_status()
        token = resp.json()["data"]["token"]
        sess = requests.Session()
        sess.headers.update({"Authorization": f"Bearer {token}"})
        return sess

    def reset(self):
        """Força re-login no próximo request."""
        self._session = None


class EmpresasAPI:
    def __init__(self, auth: SigaAuth):
        self._auth = auth

    def listar(self) -> list[Empresa]:
        resp = self._auth.session().get(f"{BASE_URL}/empresa", timeout=15)
        resp.raise_for_status()
        raw = resp.json()
        # API retorna array direto ou {data: [...]}
        data = raw if isinstance(raw, list) else raw.get("data", [])
        return [
            Empresa(
                id=e["id"],
                cnpj=e.get("cnpjSomenteNumeros") or e.get("cnpj", "").replace(".", "").replace("/", "").replace("-", ""),
                nome=e.get("nome", ""),
                ativa=not e.get("arquivado", False),
            )
            for e in data
        ]

    def por_cnpj(self, cnpj: str) -> Empresa | None:
        cnpj_limpo = cnpj.replace(".", "").replace("/", "").replace("-", "")
        for e in self.listar():
            if e.cnpj == cnpj_limpo:
                return e
        return None


class OportunidadesAPI:
    def __init__(self, auth: SigaAuth):
        self._auth = auth

    def buscar(
        self,
        dias: int = 2,
        pagina: int = 0,
        ufs: list[str] | None = None,
        palavras: str = "",
        valor_min: float | None = None,
        valor_min_item: float | None = None,
    ) -> list[Oportunidade]:
        """Busca licitações com abertura nos próximos N dias no Siga Pregão."""
        from datetime import datetime, timedelta
        hoje = datetime.now().strftime("%Y-%m-%d")
        data_fim = (datetime.now() + timedelta(days=dias)).strftime("%Y-%m-%d")

        payload = {
            "tipoPeriodo": "abertura",
            "pesquisa": palavras or "",
            "excluir": "",
            "limitar": "",
            "dataInicial": hoje,
            "dataFinal": data_fim,
            "valorMinimoDaCompra": valor_min or "",
            "valorMaximoDaCompra": "",
            "valorMinimoDoItem": valor_min_item or "",
            "valorMaximoDoItem": "",
            "qtdMaxItens": "",
            "somenteValoresSigilosos": False,
            "itensDesertos": False,
            "ufs": ufs or [],
            "portais": [],
            "modalidades": [],
            "superoportunidades": False,
            "participacaoExclusiva": False,
            "fontePncp": "",
            "excluirRegistroPreco": False,
            "modoDisputa": "",
            "tipoItem": "",
            "pesquisaAmpla": True,
            "page": pagina,
        }

        resp = self._auth.session().post(
            f"{BASE_URL}/oportunidades",
            json=payload,
            timeout=30,
        )
        resp.raise_for_status()
        raw = resp.json()
        # Resposta é Spring Page: {content: [...], totalElements: N}
        items = raw.get("content", raw) if isinstance(raw, dict) else raw
        result = []
        for o in items:
            result.append(Oportunidade(
                id=o.get("id", 0),
                numero_controle=str(o.get("codigo") or o.get("numeroControle") or o.get("id", "")),
                orgao_nome=o.get("orgao") or o.get("orgaoNome") or o.get("nomeOrgao") or "",
                objeto=o.get("descricao") or o.get("objeto") or o.get("titulo") or "",
                modalidade=o.get("nomeModalidade") or str(o.get("modalidade", "")),
                numero_pregao=str(o.get("numero") or o.get("numeroPregao") or ""),
                data_abertura=o.get("aberturaFormatada") or o.get("abertura") or o.get("dataAbertura"),
                valor_estimado=o.get("valorEstimado") or o.get("valor"),
                portal=o.get("nomePortal") or str(o.get("portal")) if o.get("portal") else None,
                uf=o.get("uf"),
                municipio=o.get("municipio"),
            ))
        return result


class ProcessosAPI:
    def __init__(self, auth: SigaAuth):
        self._auth = auth

    def get(self, processo_id: int) -> Processo:
        """Retorna processo completo com itens."""
        resp = self._auth.session().get(
            f"{BASE_URL}/processo/pub/processo",
            params={"id": processo_id},
            timeout=15,
        )
        resp.raise_for_status()
        raw = resp.json()
        # API retorna o processo direto (não envelopado em {data:})
        d = raw if isinstance(raw, dict) and "id" in raw else raw.get("data", {})
        itens = self._parse_itens(d.get("itens", []))
        return Processo(
            id=d.get("id", processo_id),
            numero_controle=str(d.get("codigo") or d.get("numeroControle") or processo_id),
            orgao_nome=d.get("orgao") or d.get("orgaoNome") or d.get("nomeOrgao") or "",
            objeto=d.get("objeto") or d.get("descricao") or d.get("titulo") or "",
            modalidade=d.get("nomeModalidade") or str(d.get("modalidade", "")),
            numero_pregao=str(d.get("numero") or d.get("numeroPregao") or ""),
            data_abertura=d.get("aberturaFormatada") or d.get("abertura") or d.get("dataAbertura"),
            valor_estimado=d.get("valorEstimado") or d.get("valor"),
            edital_url=d.get("urlEdital") or d.get("editalUrl") or d.get("linkEdital"),
            itens=itens,
        )

    def _parse_itens(self, raw) -> list[Item]:
        # API retorna {grupos: [], itens: [...]} ou lista direta
        if isinstance(raw, dict):
            raw = raw.get("itens", [])
        items = []
        for i in raw:
            numero = i.get("numeroItem") or i.get("numero") or 0
            try:
                numero = int(numero)
            except (ValueError, TypeError):
                numero = 0
            items.append(Item(
                numero_item=numero,
                descricao=i.get("descricao") or i.get("nome") or "",
                quantidade=i.get("quantidade"),
                unidade=i.get("unidade") or i.get("unidadeMedida"),
                valor_unitario_estimado=i.get("valorUnitarioEstimado") or i.get("valorUnitario") or i.get("valorReferencia"),
                valor_total=i.get("valorTotal"),
            ))
        return sorted(items, key=lambda x: x.numero_item)

    def buscar_por_numero(self, numero_controle: str, portal: str = "pncp") -> int | None:
        """Retorna processo_id no Siga dado um número de controle."""
        portal_siga = PORTAL_MAP.get(portal.lower(), portal.upper())
        resp = self._auth.session().get(
            f"{BASE_URL}/oportunidades/filtrar-numero",
            params={"numero": numero_controle, "portal": portal_siga},
            timeout=15,
        )
        if resp.status_code != 200:
            return None
        data = resp.json().get("data")
        if isinstance(data, list) and data:
            return data[0].get("id")
        if isinstance(data, dict):
            return data.get("id")
        return None


class NegociosAPI:
    def __init__(self, auth: SigaAuth):
        self._auth = auth

    def criar(
        self,
        processo_id: int,
        nome: str,
        empresa_id: int,
        itens: list[int] | None = None,
    ) -> Negocio:
        """Cria card na etapa Oportunidade."""
        payload = {
            "processoId": processo_id,
            "nome": nome,
            "empresaId": empresa_id,
            "tipoNegocio": "oportunidade",
        }
        if itens:
            payload["itens"] = [{"numeroItem": i} for i in itens]

        resp = self._auth.session().post(
            f"{BASE_URL}/negocio",
            json=payload,
            timeout=15,
        )
        resp.raise_for_status()
        d = resp.json().get("data", {})
        negocio_id = d.get("id") or d if isinstance(d, int) else None
        return Negocio(
            id=negocio_id,
            nome=nome,
            etapa=Etapa.OPORTUNIDADE,
            empresa_id=empresa_id,
            processo_id=processo_id,
            itens_selecionados=itens or [],
        )

    def mover_etapa(self, negocio_id: int, etapa: Etapa | str) -> bool:
        etapa_str = etapa.value if isinstance(etapa, Etapa) else etapa
        resp = self._auth.session().post(
            f"{BASE_URL}/negocio/alterar-tipo",
            json={"negocioId": negocio_id, "tipoNegocio": etapa_str},
            timeout=15,
        )
        return resp.status_code in (200, 201)

    def get(self, negocio_id: int) -> Negocio:
        resp = self._auth.session().get(
            f"{BASE_URL}/negocio/{negocio_id}",
            timeout=15,
        )
        resp.raise_for_status()
        d = resp.json().get("data", {})
        return Negocio(
            id=d.get("id", negocio_id),
            nome=d.get("nome", ""),
            etapa=Etapa(d.get("tipoNegocio", "oportunidade")),
            empresa_id=d.get("empresaId", 0),
            processo_id=d.get("processoId"),
            itens_selecionados=[i.get("numeroItem") for i in d.get("itens", [])],
        )

    def listar(self, etapa: Etapa | str | None = None) -> list[Negocio]:
        params = {}
        if etapa:
            params["tipos"] = etapa.value if isinstance(etapa, Etapa) else etapa
        resp = self._auth.session().get(f"{BASE_URL}/negocio", params=params, timeout=15)
        resp.raise_for_status()
        data = resp.json().get("data", [])
        return [
            Negocio(
                id=d.get("id", 0),
                nome=d.get("nome", ""),
                etapa=Etapa(d.get("tipoNegocio", "oportunidade")),
                empresa_id=d.get("empresaId", 0),
                processo_id=d.get("processoId"),
            )
            for d in data
        ]

    def get_checklist(self, negocio_id: int) -> Checklist:
        resp = self._auth.session().get(
            f"{BASE_URL}/checklist-negocio/{negocio_id}",
            timeout=15,
        )
        resp.raise_for_status()
        data = resp.json().get("data", [])
        itens = []
        for secao in data:
            nome_secao = secao.get("nome", "")
            for item in secao.get("itens", []):
                itens.append(ChecklistItem(
                    id=item.get("id", 0),
                    descricao=item.get("descricao", ""),
                    responsavel=item.get("responsavel", ""),
                    concluido=item.get("concluido", False),
                    secao=nome_secao,
                ))
        return Checklist(negocio_id=negocio_id, itens=itens)

    def marcar_checklist(self, checklist_id: int, concluido: bool = True) -> bool:
        resp = self._auth.session().put(
            f"{BASE_URL}/checklist-negocio/{checklist_id}",
            json={"concluido": concluido},
            timeout=15,
        )
        return resp.status_code in (200, 201)


class DocumentosAPI:
    def __init__(self, auth: SigaAuth):
        self._auth = auth

    def listar(self, negocio_id: int) -> list[dict]:
        resp = self._auth.session().get(
            f"{BASE_URL}/docmanager/documento/negocio/{negocio_id}",
            timeout=15,
        )
        resp.raise_for_status()
        return resp.json().get("data", [])

    def upload(self, filepath: str, nome: str | None = None, negocio_id: int | None = None) -> int | None:
        """Faz upload de um arquivo e opcionalmente associa ao negócio. Retorna doc_id."""
        import os
        nome = nome or os.path.basename(filepath)
        with open(filepath, "rb") as f:
            resp = self._auth.session().post(
                f"{BASE_URL}/docmanager/documento",
                files={"arquivo": (nome, f)},
                data={"nome": nome},
                timeout=30,
            )
        resp.raise_for_status()
        doc_id = resp.json().get("data", {}).get("id")
        if doc_id and negocio_id:
            self.associar(negocio_id, [doc_id])
        return doc_id

    def associar(self, negocio_id: int, doc_ids: list[int]) -> bool:
        resp = self._auth.session().post(
            f"{BASE_URL}/docmanager/associar-docs/{negocio_id}",
            json={"documentos": doc_ids},
            timeout=15,
        )
        return resp.status_code in (200, 201)


class SigaClient:
    """
    Cliente principal do Siga Pregão.

    Uso:
        client = SigaClient(email="x@empresa.com", password="senha")
        empresas = client.empresas.listar()
        ops = client.oportunidades.buscar(dias=2)
        processo = client.processos.get(processo_id=12345)
        negocio = client.negocios.criar(12345, "Nome do Negócio", empresa_id=1)
        client.negocios.mover_etapa(negocio.id, Etapa.QUALIFICACAO)
    """

    def __init__(self, email: str, password: str):
        self._auth = SigaAuth(email, password)
        self.empresas = EmpresasAPI(self._auth)
        self.oportunidades = OportunidadesAPI(self._auth)
        self.processos = ProcessosAPI(self._auth)
        self.negocios = NegociosAPI(self._auth)
        self.documentos = DocumentosAPI(self._auth)
