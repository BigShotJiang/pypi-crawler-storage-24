# siga-pregao-mcp

**MCP Server para Siga Pregão** — prospecção e gestão de licitações públicas brasileiras para o Claude.

Transforma o Claude num operador de licitações: busca oportunidades, avalia fit, gerencia o funil de negócios e acompanha habilitação.

---

## Instalação

### Claude Desktop

Adicione ao `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "siga-pregao": {
      "command": "uvx",
      "args": ["siga-pregao-mcp"],
      "env": {
        "SIGA_EMAIL": "seu@email.com",
        "SIGA_PASSWORD": "suasenha"
      }
    }
  }
}
```

Localização do arquivo:
- **macOS:** `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows:** `%APPDATA%\Claude\claude_desktop_config.json`

### Desenvolvimento local

```bash
git clone https://github.com/b2g-os/siga-pregao-mcp
cd siga-pregao-mcp
pip install -e ".[dev]"

# Rodar o servidor
SIGA_EMAIL=x@email.com SIGA_PASSWORD=senha python -m mcp.server
```

---

## Ferramentas disponíveis

### Empresas
| Tool | Descrição |
|------|-----------|
| `listar_empresas()` | Lista empresas cadastradas na conta Siga |

### Prospecção
| Tool | Descrição |
|------|-----------|
| `buscar_oportunidades(dias, pagina)` | Busca licitações publicadas nos últimos N dias |
| `get_itens_processo(processo_id)` | Retorna itens detalhados de uma licitação |

### Funil de Negócios
| Tool | Descrição |
|------|-----------|
| `criar_negocio(processo_id, empresa_cnpj, itens)` | Cria card na etapa Oportunidade |
| `mover_etapa(negocio_id, etapa)` | Move negócio no funil |
| `listar_pipeline(etapa)` | Lista negócios por etapa |
| `get_checklist(negocio_id)` | Retorna checklist com status |
| `marcar_item_checklist(item_id)` | Marca item como concluído |

### Documentos
| Tool | Descrição |
|------|-----------|
| `listar_documentos(negocio_id)` | Lista docs anexados ao negócio |
| `upload_documento(negocio_id, arquivo_path)` | Faz upload e associa documento |

---

## Exemplo de uso no Claude

> *"Busca licitações de notebooks e monitores em São Paulo nos últimos 2 dias"*

> *"Mostra os itens do processo 12345"*

> *"Cria um card no Siga para o processo 12345 com a empresa CNPJ 12.345.678/0001-99, itens 1 e 3"*

> *"Move o negócio 67890 para Qualificação"*

> *"Como está o checklist do negócio 67890?"*

---

## Funil de licitações

```
OPORTUNIDADE → QUALIFICAÇÃO → DISPUTA → CLASSIFICAÇÃO → CONTRATO
```

---

## Requisitos

- Python 3.10+
- Conta ativa no [Siga Pregão](https://app.sigapregao.com.br)
- [uv](https://docs.astral.sh/uv/) instalado (para `uvx`)

---

## Licença

MIT — desenvolvido por [B2G OS](https://github.com/b2g-os)
