"""
siga-pregao-mcp — MCP Server para Siga Pregão
Expõe ferramentas de prospecção e gestão de licitações para o Claude.

Configuração (claude_desktop_config.json):
{
  "mcpServers": {
    "siga-pregao": {
      "command": "uvx",
      "args": ["siga-pregao-mcp"],
      "env": {
        "SIGA_EMAIL": "seu@email.com",
        "SIGA_PASSWORD": "suasenha"
      }
    }
  }
}
"""

import os
import sys
import json
from mcp.server.fastmcp import FastMCP
from typing import Optional

# Adiciona client ao path quando rodando em desenvolvimento
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from client import SigaClient
from client.models import Etapa

# ── Inicialização ────────────────────────────────────────────────────────────

mcp = FastMCP(
    name="siga-pregao",
    instructions="""
Você tem acesso ao Siga Pregão — plataforma brasileira de gestão de licitações públicas.

Use as ferramentas disponíveis para:
- Buscar oportunidades de licitação aderentes ao perfil do cliente
- Obter detalhes e itens de uma licitação específica
- Gerenciar o funil de negócios (Oportunidade → Qualificação → Disputa → Contrato)
- Fazer upload de documentos de habilitação
- Acompanhar checklists por etapa

Quando buscar oportunidades, sempre traga os itens da licitação para avaliar fit real.
Apresente valores em R$ formatado. Datas no formato DD/MM/AAAA.
Funil: Oportunidade → Qualificação → Disputa → Classificação → Contrato.
""",
)

def _client() -> SigaClient:
    """Instancia cliente com credenciais do ambiente."""
    email = os.environ.get("SIGA_EMAIL")
    password = os.environ.get("SIGA_PASSWORD")
    if not email or not password:
        raise ValueError(
            "Configure SIGA_EMAIL e SIGA_PASSWORD nas variáveis de ambiente. "
            "Veja: claude_desktop_config.json → mcpServers → siga-pregao → env"
        )
    return SigaClient(email=email, password=password)


# ── Tools: Empresas ──────────────────────────────────────────────────────────

@mcp.tool()
def listar_empresas() -> str:
    """
    Lista todas as empresas cadastradas na conta Siga Pregão.
    Retorna id, CNPJ e nome de cada empresa.
    """
    client = _client()
    empresas = client.empresas.listar()
    if not empresas:
        return "Nenhuma empresa cadastrada na conta."
    linhas = [f"**{e.nome}**\n  CNPJ: {e.cnpj}\n  ID: {e.id}" for e in empresas]
    return f"## Empresas cadastradas ({len(empresas)})\n\n" + "\n\n".join(linhas)


# ── Tools: Prospecção ────────────────────────────────────────────────────────

@mcp.tool()
def buscar_oportunidades(
    dias: int = 7,
    pagina: int = 0,
    ufs: Optional[list[str]] = None,
    palavras: str = "",
    valor_min: Optional[float] = None,
    valor_min_item: Optional[float] = None,
) -> str:
    """
    Busca licitações com abertura nos próximos N dias no Siga Pregão.

    Args:
        dias: Janela de abertura em dias a partir de hoje (padrão: 7)
        pagina: Página de resultados (padrão: 0)
        ufs: Lista de UFs para filtrar (ex: ["SP", "RJ"]). Vazio = todo Brasil.
        palavras: Palavras-chave para filtrar objeto da licitação
        valor_min: Valor mínimo total da licitação (ex: 500000)
        valor_min_item: Valor mínimo por item (ex: 100000)

    Returns:
        Lista de oportunidades com id, órgão, objeto, valor e data de abertura.
        Use get_itens_processo(id) para obter os itens detalhados de cada oportunidade.
    """
    client = _client()
    ops = client.oportunidades.buscar(
        dias=dias,
        pagina=pagina,
        ufs=ufs,
        palavras=palavras,
        valor_min=valor_min,
        valor_min_item=valor_min_item,
    )
    if not ops:
        return f"Nenhuma oportunidade encontrada nos últimos {dias} dias."

    linhas = []
    for o in ops:
        valor = f"R$ {o.valor_estimado:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".") if o.valor_estimado else "Não informado"
        linhas.append(
            f"**ID {o.id}** — {o.orgao_nome}\n"
            f"  Objeto: {o.objeto[:120]}{'...' if len(o.objeto) > 120 else ''}\n"
            f"  Valor: {valor} | Abertura: {o.data_abertura or 'A definir'}\n"
            f"  Portal: {o.portal or 'N/D'} | UF: {o.uf or 'N/D'}"
        )

    return (
        f"## Oportunidades — últimos {dias} dias ({len(ops)} encontradas)\n\n"
        + "\n\n".join(linhas)
        + "\n\n💡 Use `get_itens_processo(id)` para ver os itens detalhados de qualquer oportunidade."
    )


@mcp.tool()
def get_itens_processo(processo_id: int) -> str:
    """
    Retorna os itens detalhados de uma licitação pelo ID do processo no Siga.

    Args:
        processo_id: ID do processo no Siga Pregão (obtido em buscar_oportunidades)

    Returns:
        Lista de itens com número, descrição, quantidade, unidade e valor estimado.
    """
    client = _client()
    processo = client.processos.get(processo_id)

    if not processo.itens:
        return f"Processo {processo_id} não possui itens cadastrados."

    linhas = [
        f"## {processo.orgao_nome}",
        f"**Objeto:** {processo.objeto}",
        f"**Pregão:** {processo.numero_pregao or 'N/D'}",
        f"**Abertura:** {processo.data_abertura or 'N/D'}",
        f"**Edital:** {processo.edital_url or 'Não disponível'}",
        f"\n### Itens ({len(processo.itens)} total)\n",
    ]

    for item in processo.itens:
        valor = f"R$ {item.valor_total:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".") if item.valor_total else ""
        unit = f"R$ {item.valor_unitario_estimado:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".") if item.valor_unitario_estimado else ""
        qtd = f"{item.quantidade} {item.unidade}" if item.quantidade else ""
        linha = f"**Item {item.numero_item}:** {item.descricao}"
        detalhes = " | ".join(filter(None, [qtd, unit and f"Unit: {unit}", valor and f"Total: {valor}"]))
        if detalhes:
            linha += f"\n  {detalhes}"
        linhas.append(linha)

    return "\n".join(linhas)


# ── Tools: Funil de Negócios ─────────────────────────────────────────────────

@mcp.tool()
def criar_negocio(
    processo_id: int,
    empresa_cnpj: str,
    nome: Optional[str] = None,
    itens: Optional[list[int]] = None,
) -> str:
    """
    Cria um card no funil do Siga Pregão na etapa Oportunidade.

    Args:
        processo_id: ID do processo no Siga (obtido em buscar_oportunidades ou get_itens_processo)
        empresa_cnpj: CNPJ da empresa participante (com ou sem formatação)
        nome: Nome do negócio no Siga (opcional — gerado automaticamente se omitido)
        itens: Lista de números de itens que a empresa vai participar (ex: [1, 3, 5])

    Returns:
        ID do negócio criado e confirmação.
    """
    client = _client()
    empresa = client.empresas.por_cnpj(empresa_cnpj)
    if not empresa:
        return f"Empresa com CNPJ {empresa_cnpj} não encontrada na conta. Use listar_empresas() para ver as disponíveis."

    processo = client.processos.get(processo_id)
    nome_negocio = nome or f"{empresa.nome[:30]} — {processo.orgao_nome[:30]}"

    negocio = client.negocios.criar(
        processo_id=processo_id,
        nome=nome_negocio,
        empresa_id=empresa.id,
        itens=itens,
    )

    itens_str = f" | Itens: {itens}" if itens else ""
    return (
        f"✅ Negócio criado com sucesso!\n"
        f"  ID: {negocio.id}\n"
        f"  Nome: {nome_negocio}\n"
        f"  Empresa: {empresa.nome}\n"
        f"  Etapa: Oportunidade{itens_str}\n\n"
        f"Use `mover_etapa({negocio.id}, 'qualificacao')` quando o cliente confirmar participação."
    )


@mcp.tool()
def mover_etapa(negocio_id: int, etapa: str) -> str:
    """
    Move um negócio para outra etapa no funil do Siga Pregão.

    Args:
        negocio_id: ID do negócio no Siga
        etapa: Etapa destino. Valores válidos:
               oportunidade | qualificacao | disputa | classificacao | contrato

    Returns:
        Confirmação da mudança de etapa.
    """
    etapas_validas = [e.value for e in Etapa]
    if etapa not in etapas_validas:
        return f"Etapa inválida: '{etapa}'. Valores válidos: {', '.join(etapas_validas)}"

    client = _client()
    ok = client.negocios.mover_etapa(negocio_id, Etapa(etapa))
    if ok:
        etapa_labels = {
            "oportunidade": "Oportunidade",
            "qualificacao": "Qualificação",
            "disputa": "Disputa",
            "classificacao": "Classificação",
            "contrato": "Contrato",
        }
        return f"✅ Negócio {negocio_id} movido para **{etapa_labels[etapa]}**."
    return f"❌ Falha ao mover negócio {negocio_id} para {etapa}. Verifique se o ID existe."


@mcp.tool()
def listar_pipeline(etapa: Optional[str] = None) -> str:
    """
    Lista os negócios no funil do Siga Pregão.

    Args:
        etapa: Filtrar por etapa (opcional). Valores: oportunidade | qualificacao | disputa | classificacao | contrato
               Se omitido, retorna todos.

    Returns:
        Lista de negócios com id, nome, empresa e etapa atual.
    """
    client = _client()
    etapa_enum = Etapa(etapa) if etapa else None
    negocios = client.negocios.listar(etapa=etapa_enum)

    if not negocios:
        filtro = f" em '{etapa}'" if etapa else ""
        return f"Nenhum negócio encontrado{filtro}."

    linhas = []
    for n in negocios:
        linhas.append(f"**ID {n.id}** — {n.nome}\n  Etapa: {n.etapa.value} | Empresa ID: {n.empresa_id}")

    titulo = f"## Pipeline{f' — {etapa}' if etapa else ''} ({len(negocios)} negócios)\n\n"
    return titulo + "\n\n".join(linhas)


@mcp.tool()
def get_checklist(negocio_id: int) -> str:
    """
    Retorna o checklist de um negócio com status de cada item.

    Args:
        negocio_id: ID do negócio no Siga

    Returns:
        Checklist agrupado por seção com status concluído/pendente.
    """
    client = _client()
    checklist = client.negocios.get_checklist(negocio_id)

    if not checklist.itens:
        return f"Checklist do negócio {negocio_id} está vazio."

    # Agrupar por seção
    secoes: dict[str, list] = {}
    for item in checklist.itens:
        secoes.setdefault(item.secao, []).append(item)

    linhas = [f"## Checklist — Negócio {negocio_id}", f"**Progresso: {checklist.percentual_concluido}% concluído**\n"]
    for secao, itens in secoes.items():
        linhas.append(f"### {secao}")
        for item in itens:
            status = "✅" if item.concluido else "⬜"
            linhas.append(f"{status} {item.descricao} _(ID: {item.id})_")
        linhas.append("")

    return "\n".join(linhas)


@mcp.tool()
def marcar_item_checklist(item_id: int, concluido: bool = True) -> str:
    """
    Marca um item do checklist como concluído ou pendente.

    Args:
        item_id: ID do item no checklist (obtido em get_checklist)
        concluido: True para marcar concluído, False para desmarcar (padrão: True)

    Returns:
        Confirmação da operação.
    """
    client = _client()
    ok = client.negocios.marcar_checklist(item_id, concluido)
    status = "concluído ✅" if concluido else "desmarcado ⬜"
    if ok:
        return f"Item {item_id} marcado como {status}."
    return f"❌ Falha ao atualizar item {item_id}."


# ── Tools: Documentos ────────────────────────────────────────────────────────

@mcp.tool()
def listar_documentos(negocio_id: int) -> str:
    """
    Lista os documentos anexados a um negócio.

    Args:
        negocio_id: ID do negócio no Siga

    Returns:
        Lista de documentos com nome, tipo e data de upload.
    """
    client = _client()
    docs = client.documentos.listar(negocio_id)
    if not docs:
        return f"Nenhum documento anexado ao negócio {negocio_id}."

    linhas = [f"## Documentos — Negócio {negocio_id}\n"]
    for d in docs:
        nome = d.get("nome") or d.get("nomeArquivo") or "Sem nome"
        data = d.get("criadoEm") or d.get("dataUpload") or ""
        linhas.append(f"📄 **{nome}** | ID: {d.get('id', 'N/D')} | {data}")

    return "\n".join(linhas)


@mcp.tool()
def upload_documento(negocio_id: int, arquivo_path: str, nome: Optional[str] = None) -> str:
    """
    Faz upload de um documento e associa ao negócio.

    Args:
        negocio_id: ID do negócio no Siga
        arquivo_path: Caminho local do arquivo (PDF, etc.)
        nome: Nome do documento no Siga (opcional — usa nome do arquivo se omitido)

    Returns:
        Confirmação do upload com ID do documento.
    """
    import os
    if not os.path.exists(arquivo_path):
        return f"Arquivo não encontrado: {arquivo_path}"

    client = _client()
    doc_id = client.documentos.upload(arquivo_path, nome=nome, negocio_id=negocio_id)
    if doc_id:
        return f"✅ Documento enviado com sucesso! ID: {doc_id} | Negócio: {negocio_id}"
    return "❌ Falha no upload do documento."


# ── Entry point ──────────────────────────────────────────────────────────────

def main():
    mcp.run()


if __name__ == "__main__":
    main()
