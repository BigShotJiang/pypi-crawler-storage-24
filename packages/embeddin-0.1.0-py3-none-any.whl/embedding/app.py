from __future__ import annotations

import streamlit as st

from embedding.core import build_output_zip_bytes, embed_zip_bytes, supported_models


st.set_page_config(
    page_title="embedding",
    page_icon="🧠",
    layout="wide",
)

st.title("embedding")
st.caption("Turn a zip of .md or .txt chunks into embedding vectors with a local UI.")

with st.sidebar:
    st.header("Settings")
    model_options = supported_models()
    labels = [f"{name} — {desc}" for name, desc in model_options]
    default_index = 0
    selected_label = st.selectbox("Embedding model", labels, index=default_index)
    selected_model = model_options[labels.index(selected_label)][0]

    use_custom = st.checkbox("Use a custom Hugging Face / SentenceTransformers model name", value=False)
    custom_model = st.text_input("Custom model name", value="") if use_custom else ""
    model_name = custom_model.strip() or selected_model

    normalize_embeddings = st.checkbox("Normalize embeddings", value=True)
    batch_size = st.number_input("Batch size", min_value=1, max_value=256, value=16, step=1)
    text_prefix = st.text_input(
        "Optional prefix added to each chunk before embedding",
        value="",
        help="Useful for models that benefit from prefixes like 'passage:' or 'query:'.",
    )

    formats = st.multiselect(
        "Output formats inside export zip",
        options=["jsonl", "csv", "npz"],
        default=["jsonl", "npz"],
        help="jsonl = one record per chunk, csv = spreadsheet-friendly, npz = NumPy compressed arrays.",
    )

uploaded = st.file_uploader("Drag the chunk zip here", type=["zip"])

if uploaded is None:
    st.info("Upload a zip created from your chunking step. The zip should contain .md or .txt files.")
    st.stop()

if not formats:
    st.warning("Select at least one export format.")
    st.stop()

if st.button("Generate embeddings", type="primary"):
    with st.spinner("Loading model and creating embeddings..."):
        try:
            manifest, items, summary = embed_zip_bytes(
                uploaded.read(),
                model_name=model_name,
                normalize_embeddings=normalize_embeddings,
                batch_size=int(batch_size),
                text_prefix=text_prefix,
            )
            export_bytes = build_output_zip_bytes(
                manifest,
                items,
                summary,
                input_zip_name=uploaded.name,
                formats=formats,
            )
        except Exception as exc:
            st.error(str(exc))
            st.stop()

    col1, col2 = st.columns([1, 2])
    with col1:
        st.metric("Input text files", summary["input_text_files"])
        st.metric("Embedding dimension", summary["embedding_dim"])
        st.metric("Total characters", summary["total_characters"])
        st.metric("Total words", summary["total_words"])
        st.download_button(
            label="Download embeddings .zip",
            data=export_bytes,
            file_name=f"{uploaded.name.rsplit('.', 1)[0]}_embeddings.zip",
            mime="application/zip",
        )

    with col2:
        st.subheader("Manifest")
        st.dataframe(manifest, use_container_width=True)

    st.subheader("Preview")
    first = items[0]
    preview = {
        "id": first.item_id,
        "source_file": first.source_file,
        "text_preview": first.text[:600],
        "embedding_dim": first.embedding_dim,
        "embedding_first_12_values": first.embedding[:12],
    }
    st.json(preview)
else:
    st.caption("Choose a model and click Generate embeddings.")
