from __future__ import annotations

from pathlib import Path
import sys


def main() -> None:
    try:
        from streamlit.web import cli as stcli
    except Exception as exc:  # pragma: no cover
        raise SystemExit(
            "Streamlit is required to launch the UI. Install package dependencies first."
        ) from exc

    app_path = Path(__file__).with_name("app.py")
    sys.argv = ["streamlit", "run", str(app_path)]
    raise SystemExit(stcli.main())
