"""CLI for the simstadt library."""

import argparse
import logging
import re
import subprocess
import sys
from pathlib import Path


def cmd_info(args: argparse.Namespace) -> None:
    from .runner import get_simstadt_folder, get_simstadt_output, _simstadt_script

    try:
        folder = get_simstadt_folder()
    except ValueError as e:
        print(f"SimStadt folder : NOT FOUND\n{e}", file=sys.stderr)
        raise SystemExit(1)

    if args.gui:
        print(f"Launching SimStadt GUI from {folder} ...", file=sys.stderr)
        subprocess.Popen([_simstadt_script()], cwd=folder)
        return

    print("simstadt - Python library for SimStadt workflows.")
    print("See https://simstadt.hft-stuttgart.de/ for SimStadt documentation.")
    print()
    print(f"SimStadt folder : {folder}")

    output = get_simstadt_output(folder)
    m = re.search(r"Launching SimStadt (\S+) \((\w+), rev\. (\w+), (\d\d\d\d)(\d\d)(\d\d)\)", output)
    if m:
        version, branch, commit, yyyy, mm, dd = m.groups()
        print(f"SimStadt version: {version} (branch: {branch}, rev: {commit}, date: {yyyy}-{mm}-{dd})")
    else:
        print("SimStadt version: unknown (could not parse version string)")


def cmd_run(args: argparse.Namespace) -> None:
    logging.basicConfig(level=logging.DEBUG if args.verbose else logging.WARNING)

    from .runner import run_workflow_with_citygml

    p = Path(args.template)
    template = p if (p.exists() or p.with_suffix(".flow").exists()) else args.template

    try:
        results = run_workflow_with_citygml(
            template=template,
            citygml_path=args.citygml,
            description=args.description,
            destination=args.destination,
            project_path=args.project_path,
        )
    except (FileNotFoundError, ValueError) as e:
        print(f"Error: {e}", file=sys.stderr)
        raise SystemExit(1)

    print(f"\n{results.description}\n")
    for kpi in results.kpis:
        print(f"  {kpi}")

    if args.files:
        print("\nOutput files:")
        for f in results.output_files:
            print(f"  {f}")

    if args.save:
        if args.save.suffix == ".json":
            results.dataframe.to_json(args.save, orient="records", indent=2)
        else:
            results.dataframe.to_csv(args.save)
        print(f"\nSaved to {args.save}", file=sys.stderr)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="simstadt",
        description="simstadt - Python library for SimStadt workflows.",
    )
    parser.add_argument("--gui", action="store_true", help="Launch the SimStadt GUI.")
    parser.add_argument("template", nargs="?", help="Template name (from SIMSTADT_TEMPLATE_PATH) or path to a .flow directory.")
    parser.add_argument("citygml", nargs="?", type=Path, help="Path to the CityGML input file.")
    parser.add_argument("-d", "--description", help="Human-readable label for the result.")
    parser.add_argument("--destination", help="Workflow folder name (default: timestamped random id).")
    parser.add_argument("-p", "--project-path", dest="project_path", type=Path, help="Directory where the workflow folder is created.")
    parser.add_argument("-f", "--files", action="store_true", help="Show output files after the run.")
    parser.add_argument("-s", "--save", type=Path, metavar="PATH", help="Save result DataFrame to a file (.csv or .json).")
    parser.add_argument("-v", "--verbose", action="store_true", help="Enable debug logging.")
    return parser


def app() -> None:
    parser = build_parser()
    args = parser.parse_args()
    if args.template and args.citygml:
        cmd_run(args)
    else:
        cmd_info(args)
