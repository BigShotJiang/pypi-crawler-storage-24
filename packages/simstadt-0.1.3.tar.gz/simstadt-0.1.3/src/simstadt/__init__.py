from .results import (
    GreenWaterResults,
    HeatDemandResults,
    KPI,
    LoadProfileResults,
    PhotovoltaicResults,
    SimStadtResults,
    SolarPotentialResults,
    create_simstadt_results,
)
from .runner import run_workflow_with_citygml, run_regionchooser, get_version_and_date
from .utils import clean_old_workflows
from .workflows import greenwater_simulation, heatdemand_simulation, photovoltaic_simulation

# TODO: Define Template class, with already defined Workflows?

__all__ = [
    "GreenWaterResults",
    "HeatDemandResults",
    "KPI",
    "LoadProfileResults",
    "PhotovoltaicResults",
    "SimStadtResults",
    "SolarPotentialResults",
    "clean_old_workflows",
    "create_simstadt_results",
    "get_version_and_date",
    "greenwater_simulation",
    "heatdemand_simulation",
    "photovoltaic_simulation",
    "run_regionchooser",
    "run_workflow_with_citygml",
]


def main() -> None:
    from .cli import app
    app()
