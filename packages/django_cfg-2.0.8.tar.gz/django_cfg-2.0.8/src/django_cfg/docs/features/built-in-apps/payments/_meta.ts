export default {
  'overview': 'Payments'
}
