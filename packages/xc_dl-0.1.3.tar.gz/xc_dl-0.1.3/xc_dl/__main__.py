"""Entry point for `python -m xc_dl`."""

from xc_dl.cli import app

app()
