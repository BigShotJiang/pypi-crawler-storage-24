"""XDG base directory helpers."""

from __future__ import annotations

import os
from pathlib import Path


def cache_dir() -> Path:
    """Return the XDG cache directory for xc-dl."""
    return Path(os.environ.get("XDG_CACHE_HOME", "~/.cache")).expanduser() / "xc-dl"


def data_dir() -> Path:
    """Return the XDG data directory for xc-dl."""
    return Path(os.environ.get("XDG_DATA_HOME", "~/.local/share")).expanduser() / "xc-dl"
