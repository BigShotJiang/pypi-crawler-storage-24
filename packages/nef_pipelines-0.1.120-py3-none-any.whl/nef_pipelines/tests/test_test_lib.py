from nef_pipelines.lib.test_lib import select_tagged_lines


def test_select_tagged_lines_basic():
    """Test basic separation of INFO/WARNING lines from NEF content."""

    INPUT = """\
INFO: Processing frame 1
data_test
WARNING: Missing field
save_test_frame
INFO: Completed processing
stop_
"""

    info_lines, nef_output = select_tagged_lines(INPUT)

    assert len(info_lines) == 3
    assert info_lines[0] == "INFO: Processing frame 1"
    assert info_lines[1] == "WARNING: Missing field"
    assert info_lines[2] == "INFO: Completed processing"

    assert "INFO:" not in nef_output
    assert "WARNING:" not in nef_output
    assert "data_test" in nef_output
    assert "save_test_frame" in nef_output
    assert "stop_" in nef_output


def test_select_tagged_lines_no_tags():
    """Test with no INFO/WARNING lines."""

    INPUT = """\
data_test
save_test_frame
stop_
"""

    info_lines, nef_output = select_tagged_lines(INPUT)

    assert len(info_lines) == 0
    assert nef_output == INPUT


def test_select_tagged_lines_only_tags():
    """Test with only INFO/WARNING lines."""

    INPUT = """\
INFO: First message
WARNING: Second message
INFO: Third message
"""

    info_lines, nef_output = select_tagged_lines(INPUT)

    assert len(info_lines) == 3
    assert info_lines[0] == "INFO: First message"
    assert info_lines[1] == "WARNING: Second message"
    assert info_lines[2] == "INFO: Third message"

    # NEF output should be empty lines only
    assert nef_output.strip() == ""


def test_select_tagged_lines_empty():
    """Test with empty input."""

    info_lines, nef_output = select_tagged_lines("")

    assert len(info_lines) == 0
    assert nef_output == ""
