import tempfile
from pathlib import Path
import pytest
import typer
from pynmrstar import Entry

from nef_pipelines.lib.test_lib import (
    assert_lines_match,
    path_in_test_data,
    read_test_data,
    run_and_report,
)
from nef_pipelines.tools.plot.correlations import correlations, pipe, _parse_frame_spec, _extract_frame_data, _align_datasets

# Skip all tests if matplotlib is not available
pytest.importorskip("matplotlib")

app = typer.Typer()
app.command()(correlations)


def test_parse_frame_spec_basic():
    """Test basic frame specification parsing."""
    frame_selector, loop_category, tags = _parse_frame_spec("shifts.nef_chemical_shift:value,uncertainty")

    assert frame_selector == "shifts"
    assert loop_category == "nef_chemical_shift"
    assert tags == ["value", "uncertainty"]


def test_parse_frame_spec_wildcards():
    """Test frame specification with wildcards."""
    frame_selector, loop_category, tags = _parse_frame_spec(".nef_chemical_shift:value")

    assert frame_selector == "*"
    assert loop_category == "nef_chemical_shift"
    assert tags == ["value"]

    frame_selector, loop_category, tags = _parse_frame_spec("shifts.:value")

    assert frame_selector == "shifts"
    assert loop_category == "*"
    assert tags == ["value"]


def test_parse_frame_spec_invalid():
    """Test invalid frame specifications."""
    # Missing colon in full specification 
    with pytest.raises(SystemExit):
        _parse_frame_spec("shifts.chemical_shift")
    
    # Missing tags after colon
    with pytest.raises(SystemExit):
        _parse_frame_spec("shifts.chemical_shift:")
    
    # Empty specification
    with pytest.raises(SystemExit):
        _parse_frame_spec("")


def test_extract_frame_data():
    """Test data extraction from frame specification."""
    path = path_in_test_data(__file__, "chemical_shifts.nef")
    nef_content = read_test_data(path)
    entry = Entry.from_string(nef_content)
    
    # Extract data from first frame
    # Request specific tags that we want to check
    data = _extract_frame_data(
        entry, "nef_chemical_shift_list_1", "nef_chemical_shift", ["chain_code", "atom_name"]
    )
    
    assert len(data) == 6  # Should have 6 rows
    
    # Check first row
    first_row = data[0]
    assert first_row['sequence_code'] == 1
    assert first_row['chain_code'] == 'A'
    assert first_row['atom_name'] == 'CA'
    assert first_row['value'] == 52.5
    assert first_row['uncertainty'] == 0.5


def test_align_datasets():
    """Test dataset alignment by sequence code and identifiers."""
    data1 = [
        {
            'sequence_code': 1,
            'chain_code': 'A', 
            'atom_name': 'CA',
            'value': 52.5,
            'uncertainty': 0.5,
            'frame_name': 'frame1'
        }
    ]
    
    data2 = [
        {
            'sequence_code': 1,
            'chain_code': 'A',
            'atom_name': 'CA', 
            'value': 52.3,
            'uncertainty': 0.4,
            'frame_name': 'frame2'
        }
    ]
    
    aligned = _align_datasets(data1, data2)
    
    assert len(aligned) == 1
    assert aligned[0]['value1'] == 52.5
    assert aligned[0]['value2'] == 52.3
    assert aligned[0]['uncertainty1'] == 0.5
    assert aligned[0]['uncertainty2'] == 0.4


def test_pipe_basic_correlation():
    """Test basic correlation plotting."""
    path = path_in_test_data(__file__, "chemical_shifts.nef")
    nef_content = read_test_data(path)
    entry = Entry.from_string(nef_content)
    
    frame_specs = [
        "nef_chemical_shift_list_1.chemical_shift:value",
        "nef_chemical_shift_list_2.chemical_shift:value"
    ]
    
    with tempfile.TemporaryDirectory() as temp_dir:
        plot_options = {
            'output': f'{temp_dir}/test_correlation_{{count}}.png',
            'rows': 2,
            'cols': 2,
            'orientation': 'portrait',
            'paper_size': 'a4',
            'axis_unit': 'ppm',
            'line_color': 'blue',
            'symbol_color': 'red',
            'line_style': '--',
            'symbol_style': 'o',
            'symbol_fill': True,
        }
        
        # Should not raise any errors
        pipe(entry, frame_specs, plot_options)
        
        # Verify plot files were created
        plot_files = list(Path(temp_dir).glob("test_correlation_*.png"))
        assert len(plot_files) > 0, "No plot files were created"
        
        # Check that files have content (not empty)
        for plot_file in plot_files:
            assert plot_file.stat().st_size > 0, f"Plot file {plot_file} is empty"


def test_correlation_with_missing_data():
    """Test correlation handling when data is missing."""
    # Create entry with only one frame
    nef_content = """\
data_test

save_nef_chemical_shift_list_1
   _nef_chemical_shift_list.sf_category      nef_chemical_shift_list
   _nef_chemical_shift_list.sf_framecode     nef_chemical_shift_list_1

   loop_
      _nef_chemical_shift.index
      _nef_chemical_shift.chain_code
      _nef_chemical_shift.sequence_code
      _nef_chemical_shift.residue_name
      _nef_chemical_shift.atom_name
      _nef_chemical_shift.value

      1   A   1   ALA   CA   52.5

   stop_

save_
"""
    
    entry = Entry.from_string(nef_content)
    
    frame_specs = [
        "nef_chemical_shift_list_1.chemical_shift:value",
        "nonexistent.chemical_shift:value"
    ]
    
    plot_options = {
        'output': 'test_correlation_{count}.png',
        'rows': 1,
        'cols': 1,
        'orientation': 'portrait',
        'paper_size': 'a4',
        'axis_unit': None,
        'line_color': 'blue',
        'symbol_color': 'red',
        'line_style': '--',
        'symbol_style': 'o',
        'symbol_fill': True,
    }
    
    # Should exit with error for no correlation data
    with pytest.raises(SystemExit):
        pipe(entry, frame_specs, plot_options)


def test_invalid_frame_specs():
    """Test validation of frame specifications."""
    path = path_in_test_data(__file__, "chemical_shifts.nef")
    nef_content = read_test_data(path)
    entry = Entry.from_string(nef_content)
    
    # Odd number of specs (not pairs)
    frame_specs = ["frame1.loop1:value"]
    
    plot_options = {
        'output': 'test_{count}.png',
        'rows': 1, 'cols': 1,
        'orientation': 'portrait', 'paper_size': 'a4',
        'axis_unit': None,
        'line_color': 'blue', 'symbol_color': 'red',
        'line_style': '--', 'symbol_style': 'o',
        'symbol_fill': True,
    }
    
    # Should exit with error for odd number
    with pytest.raises(SystemExit):
        pipe(entry, frame_specs, plot_options)


def test_multiple_pairs():
    """Test correlation with multiple frame pairs."""
    path = path_in_test_data(__file__, "chemical_shifts.nef")
    nef_content = read_test_data(path)
    entry = Entry.from_string(nef_content)
    
    frame_specs = [
        "nef_chemical_shift_list_1.chemical_shift:value",
        "nef_chemical_shift_list_2.chemical_shift:value",
        "nef_chemical_shift_list_1.chemical_shift:value", 
        "nef_chemical_shift_list_2.chemical_shift:value"
    ]
    
    with tempfile.TemporaryDirectory() as temp_dir:
        plot_options = {
            'output': f'{temp_dir}/test_multi_{{count}}.png',
            'rows': 2, 'cols': 2,
            'orientation': 'portrait', 'paper_size': 'a4',
            'axis_unit': 'ppm',
            'line_color': 'blue', 'symbol_color': 'red',
            'line_style': '--', 'symbol_style': 'o',
            'symbol_fill': True,
        }
        
        # Should not raise errors
        pipe(entry, frame_specs, plot_options)
        
        # Should have created plots
        plot_files = list(Path(temp_dir).glob("test_multi_*.png"))
        assert len(plot_files) > 0, "No plot files were created"


def test_custom_split_criteria():
    """Test correlation with custom splitting criteria."""
    path = path_in_test_data(__file__, "chemical_shifts.nef")
    nef_content = read_test_data(path)
    entry = Entry.from_string(nef_content)
    
    frame_specs = [
        "nef_chemical_shift_list_1.chemical_shift:value",
        "nef_chemical_shift_list_2.chemical_shift:value"
    ]
    
    with tempfile.TemporaryDirectory() as temp_dir:
        plot_options = {
            'output': f'{temp_dir}/test_custom_{{count}}.png',
            'rows': 1, 'cols': 1,
            'orientation': 'landscape', 'paper_size': 'a4',
            'axis_unit': 'ppm',
            'line_color': 'green', 'symbol_color': 'blue',
            'line_style': ':', 'symbol_style': 's',
            'symbol_fill': False,
        }
        
        pipe(entry, frame_specs, plot_options)
        
        # Verify plots were created
        plot_files = list(Path(temp_dir).glob("test_custom_*.png"))
        assert len(plot_files) > 0, "No plot files were created"


def test_cli_correlation_command():
    """Test CLI correlation command."""
    path = path_in_test_data(__file__, "chemical_shifts.nef")

    with tempfile.TemporaryDirectory() as temp_dir:
        # Test via CLI - should not raise errors
        result = run_and_report(app, [
            "nef_chemical_shift_list_1.chemical_shift:value",
            "nef_chemical_shift_list_2.chemical_shift:value",
            "--out", f"{temp_dir}/test_{{count}}.png",
            "--rows", "1", "--cols", "1",
            "--in", path
        ])

        # Command should succeed (no error output)
        assert "error" not in result.stdout.lower()

        # Plot files should have been created
        plot_files = list(Path(temp_dir).glob("test_*.png"))
        assert len(plot_files) > 0, "No plot files were created by CLI command"


def test_calculate_with_regression():
    """Test correlation with --calculate shows regression line and statistics."""
    path = path_in_test_data(__file__, "chemical_shifts.nef")
    nef_content = read_test_data(path)
    entry = Entry.from_string(nef_content)

    frame_specs = [
        "nef_chemical_shift_list_1.chemical_shift:value",
        "nef_chemical_shift_list_2.chemical_shift:value"
    ]

    with tempfile.TemporaryDirectory() as temp_dir:
        plot_options = {
            'output': f'{temp_dir}/test_calc_{{count}}.png',
            'rows': 1,
            'cols': 1,
            'orientation': 'portrait',
            'paper_size': 'a4',
            'axis_unit': 'ppm',
            'line_color': 'blue',
            'symbol_color': 'red',
            'line_style': '--',
            'symbol_style': 'o',
            'symbol_fill': True,
            'calculate': True,
            'no_regression_line': False,
        }

        result_entry = pipe(entry, frame_specs, plot_options)

        # Should create plot file
        plot_files = list(Path(temp_dir).glob("test_calc_*.png"))
        assert len(plot_files) > 0, "No plot files were created"

        # Files should have content (regression line adds to file size)
        for plot_file in plot_files:
            assert plot_file.stat().st_size > 0, f"Plot file {plot_file} is empty"


def test_calculate_without_regression_line():
    """Test correlation with --calculate --no-regression-line hides regression line but shows statistics."""
    path = path_in_test_data(__file__, "chemical_shifts.nef")
    nef_content = read_test_data(path)
    entry = Entry.from_string(nef_content)

    frame_specs = [
        "nef_chemical_shift_list_1.chemical_shift:value",
        "nef_chemical_shift_list_2.chemical_shift:value"
    ]

    with tempfile.TemporaryDirectory() as temp_dir:
        plot_options = {
            'output': f'{temp_dir}/test_no_reg_{{count}}.png',
            'rows': 1,
            'cols': 1,
            'orientation': 'portrait',
            'paper_size': 'a4',
            'axis_unit': 'ppm',
            'line_color': 'blue',
            'symbol_color': 'red',
            'line_style': '--',
            'symbol_style': 'o',
            'symbol_fill': True,
            'calculate': True,
            'no_regression_line': True,
        }

        result_entry = pipe(entry, frame_specs, plot_options)

        # Should still create plot file
        plot_files = list(Path(temp_dir).glob("test_no_reg_*.png"))
        assert len(plot_files) > 0, "No plot files were created"

        # File should have content (statistics text still shown, just no regression line)
        for plot_file in plot_files:
            assert plot_file.stat().st_size > 0, f"Plot file {plot_file} is empty"


def test_cli_no_regression_line():
    """Test CLI correlation command with --no-regression-line."""
    path = path_in_test_data(__file__, "chemical_shifts.nef")

    with tempfile.TemporaryDirectory() as temp_dir:
        result = run_and_report(app, [
            "nef_chemical_shift_list_1.chemical_shift:value",
            "nef_chemical_shift_list_2.chemical_shift:value",
            "--out", f"{temp_dir}/test_cli_no_reg_{{count}}.png",
            "--rows", "1",
            "--cols", "1",
            "--calculate",
            "--no-regression-line",
            "--in", path
        ])

        # Command should succeed
        assert result.exit_code == 0

        # Plot files should have been created
        plot_files = list(Path(temp_dir).glob("test_cli_no_reg_*.png"))
        assert len(plot_files) > 0, "No plot files were created by CLI command"


# ======================================================================================
# Missing Features Tests - TO BE IMPLEMENTED
# ======================================================================================

def test_no_error_bars_flag():
    """Test --no-error-bars flag hides error bars."""
    # TODO: Implement test
    # 1. Create NEF entry with uncertainty data
    # 2. Plot with --no-error-bars
    # 3. Verify plot created
    # 4. Ideally: verify error bars not drawn (difficult without inspecting plot)
    pass


def test_error_bars_shown_by_default():
    """Test that error bars are shown by default when uncertainty data available."""
    # TODO: Implement test
    # 1. Create NEF entry with uncertainty data
    # 2. Plot without --no-error-bars
    # 3. Verify plot created
    # 4. Compare with --no-error-bars version (different file sizes)
    pass


def test_no_error_bars_with_no_uncertainties():
    """Test --no-error-bars with data that has no uncertainties."""
    # TODO: Implement test
    # 1. Create NEF entry without uncertainties
    # 2. Plot with --no-error-bars
    # 3. Verify no error (graceful handling)
    pass


def test_force_flag_overwrites_existing():
    """Test --force flag overwrites existing output file."""
    # TODO: Implement test
    # 1. Create plot file: correlation_1.pdf
    # 2. Run correlations again with --force
    # 3. Verify file overwritten (check timestamp or content)
    pass


def test_no_force_flag_errors_on_existing():
    """Test error when output file exists without --force flag."""
    # TODO: Implement test
    # 1. Create plot file: correlation_1.pdf
    # 2. Try to run correlations again without --force
    # 3. Verify SystemExit raised
    # 4. Verify error message mentions file existence and --force option
    pass


def test_force_flag_with_new_file():
    """Test --force flag works fine when file doesn't exist yet."""
    # TODO: Implement test
    # 1. Run correlations with --force on non-existent file
    # 2. Verify file created successfully
    pass


def test_default_output_template():
    """Test default output template creates correlation_N.pdf files."""
    # TODO: Implement test
    # 1. Run correlations without --out option
    # 2. Verify files created: correlation_1.pdf, correlation_2.pdf, etc.
    # 3. Verify count increments correctly
    pass


def test_custom_output_template():
    """Test custom output template with {count} placeholder."""
    # TODO: Implement test
    # 1. Run with --out "my_plot_{count}.png"
    # 2. Verify files created: my_plot_1.png, my_plot_2.png, etc.
    pass


def test_output_template_different_format():
    """Test output template with different file extension."""
    # TODO: Implement test
    # 1. Run with --out "plot_{count}.svg"
    # 2. Verify SVG files created
    # 3. Run with --out "plot_{count}.png"
    # 4. Verify PNG files created
    pass


def test_binary_stdout_mode():
    """Test binary stdout mode with --out -."""
    # TODO: Implement test
    # 1. Run with --out -
    # 2. Capture stdout (binary)
    # 3. Verify PDF data written to stdout
    # 4. Verify NEF NOT written to stdout
    pass


def test_binary_stdout_single_plot_only():
    """Test that binary stdout mode errors on multiple plots."""
    # TODO: Implement test
    # 1. Try to create multiple plots with --out -
    # 2. Verify error about multiple pages not supported for stdout
    pass


def test_binary_stdout_tty_error():
    """Test error when outputting binary to TTY."""
    # TODO: Implement test (may be difficult to test TTY detection)
    # 1. Simulate TTY environment
    # 2. Try to run with --out -
    # 3. Verify error about not outputting to terminal
    pass


def test_nef_output_to_stdout():
    """Test that NEF is output to stdout when using file output."""
    # TODO: Implement test
    # 1. Run correlations with --out plot.pdf
    # 2. Verify plot.pdf created
    # 3. Verify stdout contains NEF data
    pass


def test_no_nef_output_with_binary_stdout():
    """Test that NEF is NOT output when using --out -."""
    # TODO: Implement test
    # 1. Run with --out -
    # 2. Verify stdout contains only binary PDF data
    # 3. Verify NEF data not in stdout
    pass


def test_file_existence_detection():
    """Test that file existence is detected before plotting."""
    # TODO: Implement test
    # 1. Create existing file: correlation_1.pdf
    # 2. Run correlations without --force
    # 3. Verify error occurs BEFORE heavy plotting computation
    pass