"""Test that all command modules are properly registered."""

import ast
from pathlib import Path


def _has_command_decorator(file_path: Path) -> bool:
    """Check if a Python file contains a Typer command decorator.

    Uses AST parsing to detect decorators like @app.command(), @export_app.command(), etc.
    This is more robust than string matching as it handles whitespace variations,
    comments, and different formatting styles.
    """
    try:
        content = file_path.read_text()
        tree = ast.parse(content)

        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef):
                for decorator in node.decorator_list:
                    if isinstance(decorator, ast.Call):
                        if isinstance(decorator.func, ast.Attribute):
                            if decorator.func.attr == "command":
                                return True

        return False
    except (SyntaxError, UnicodeDecodeError):
        return False


def _get_imports_from_file(file_path: Path) -> set[str]:
    """Extract all import statements from a Python file using AST parsing.

    Returns:
        Set of full module names imported (e.g., 'nef_pipelines.tools.chains.clone')
    """
    try:
        content = file_path.read_text()
        tree = ast.parse(content)

        imports = set()

        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports.add(alias.name)
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    imports.add(node.module)

        return imports
    except (SyntaxError, UnicodeDecodeError):
        return set()


def test_all_transcoder_commands_are_imported():
    """Verify all transcoder command modules are imported in their __init__.py files.

    This prevents the issue where a command file exists but isn't registered
    because it's not imported in the transcoder's __init__.py.
    """
    transcoders_dir = Path(__file__).parent.parent / "transcoders"

    missing_imports = []

    for transcoder_dir in transcoders_dir.iterdir():
        if not transcoder_dir.is_dir() or transcoder_dir.name.startswith("_"):
            continue

        init_file = transcoder_dir / "__init__.py"
        if not init_file.exists():
            continue

        imported_modules = _get_imports_from_file(init_file)

        for subdir_name in ["importers", "exporters"]:
            subdir = transcoder_dir / subdir_name
            if not subdir.exists() or not subdir.is_dir():
                continue

            for command_file in subdir.glob("*.py"):
                if command_file.name.startswith("_"):
                    continue

                if not _has_command_decorator(command_file):
                    continue

                module_name = command_file.stem
                expected_import = f"nef_pipelines.transcoders.{transcoder_dir.name}.{subdir_name}.{module_name}"

                if expected_import not in imported_modules:
                    missing_imports.append(
                        f"{transcoder_dir.name}/{subdir_name}/{module_name}.py is not imported in {transcoder_dir.name}/__init__.py"
                    )

    if missing_imports:
        error_msg = "The following command modules are not imported:\n  " + "\n  ".join(missing_imports)
        error_msg += "\n\nAdd the missing imports to the respective __init__.py files."
        assert False, error_msg


def test_all_tool_commands_are_imported():
    """Verify all tool command modules are imported in their __init__.py files.

    This prevents the issue where a tool file exists but isn't registered
    because it's not imported in the tool's __init__.py.
    """
    tools_dir = Path(__file__).parent.parent / "tools"

    missing_imports = []

    for tool_dir in tools_dir.iterdir():
        if not tool_dir.is_dir() or tool_dir.name.startswith("_"):
            continue

        init_file = tool_dir / "__init__.py"
        if not init_file.exists():
            continue

        imported_modules = _get_imports_from_file(init_file)

        for command_file in tool_dir.glob("*.py"):
            if command_file.name.startswith("_") or command_file.name == "__init__.py":
                continue

            if not _has_command_decorator(command_file):
                continue

            module_name = command_file.stem
            expected_import = f"nef_pipelines.tools.{tool_dir.name}.{module_name}"

            if expected_import not in imported_modules:
                missing_imports.append(
                    f"{tool_dir.name}/{module_name}.py is not imported in {tool_dir.name}/__init__.py"
                )

    if missing_imports:
        error_msg = "The following tool modules are not imported:\n  " + "\n  ".join(missing_imports)
        error_msg += "\n\nAdd the missing imports to the respective __init__.py files."
        assert False, error_msg


def test_all_modules_with_commands_are_in_main():
    """Verify that all top-level tool and transcoder modules are in main_imports.py.

    This checks that tool/__init__.py and transcoder/__init__.py modules that register
    commands are included in the MODULES list in main_imports.py.
    """
    from nef_pipelines.main_imports import MODULES

    imported_in_main = MODULES

    missing_from_main = []

    for base_package, base_dir_name in [
        ("nef_pipelines.tools", "tools"),
        ("nef_pipelines.transcoders", "transcoders"),
    ]:
        base_dir = Path(__file__).parent.parent / base_dir_name

        for module_dir in base_dir.iterdir():
            if not module_dir.is_dir() or module_dir.name.startswith("_"):
                continue

            init_file = module_dir / "__init__.py"
            if not init_file.exists():
                continue

            imports = _get_imports_from_file(init_file)
            module_base = f"{base_package}.{module_dir.name}"

            if any(imp.startswith(module_base) for imp in imports):
                if module_base not in imported_in_main:
                    missing_from_main.append(module_base)

    if missing_from_main:
        error_msg = "The following modules are not in main_imports.py:\n  " + "\n  ".join(missing_from_main)
        error_msg += "\n\nAdd the missing module names to the MODULES list in main_imports.py"
        assert False, error_msg
