from pathlib import Path

import typer
from typer.testing import CliRunner

from nef_pipelines.lib.test_lib import path_in_test_data, run_and_report
from nef_pipelines.tools.plot.relaxation import relaxation

runner = CliRunner()
app = typer.Typer()
app.command()(relaxation)


def test_relaxation_basic_pdf(tmp_path):
    """Test basic relaxation plotting with PDF output."""

    test_data_file = path_in_test_data(__file__, "GB1_T1_Relaxation_series_fitted_short.nef")
    test_data = Path(test_data_file).read_text()

    output_file = tmp_path / "test_relax_{entry}_{frame}_{page}"

    # Test basic plotting with default settings
    result = run_and_report(
        app,
        ["nefpls_series_list_T1", "-o", str(output_file), "--format", "pdf", "--force"],
        input=test_data,
    )

    # Check that command succeeded
    assert result.exit_code == 0

    # Check that output file was created (PDF is single file without page number)
    assert (tmp_path / "test_relax_GB1_T1_Relaxation_T1.pdf").exists()


def test_relaxation_svg_output(tmp_path):
    """Test relaxation plotting with SVG output."""

    test_data_file = path_in_test_data(__file__, "GB1_T1_Relaxation_series_fitted_short.nef")
    test_data = Path(test_data_file).read_text()

    output_file = tmp_path / "test_relax_{entry}_{frame}_{page}"

    # Test SVG output
    result = run_and_report(
        app,
        ["nefpls_series_list_T1", "-o", str(output_file), "--format", "svg", "--force"],
        input=test_data,
    )

    # Check that command succeeded
    assert result.exit_code == 0

    # Check that output file was created (SVG creates separate files per page)
    assert (tmp_path / "test_relax_GB1_T1_Relaxation_T1_1.svg").exists()


def test_relaxation_custom_grid(tmp_path):
    """Test relaxation plotting with custom grid dimensions."""

    test_data_file = path_in_test_data(__file__, "GB1_T1_Relaxation_series_fitted_short.nef")
    test_data = Path(test_data_file).read_text()

    output_file = tmp_path / "test_relax_{entry}_{frame}_{page}"

    # Test with 3x3 grid
    result = run_and_report(
        app,
        [
            "nefpls_series_list_T1",
            "-o",
            str(output_file),
            "--format",
            "pdf",
            "--rows",
            "3",
            "--cols",
            "3",
            "--force",
        ],
        input=test_data,
    )

    # Check that command succeeded
    assert result.exit_code == 0


def test_relaxation_with_fit(tmp_path):
    """Test relaxation plotting with exponential fit overlay (now default)."""

    test_data_file = path_in_test_data(__file__, "GB1_T1_Relaxation_series_fitted_short.nef")
    test_data = Path(test_data_file).read_text()

    output_file = tmp_path / "test_relax_{entry}_{frame}_{page}"

    # Test with exponential fit (now shown by default, no --fit flag needed)
    result = run_and_report(
        app,
        [
            "nefpls_series_list_T1",
            "-o",
            str(output_file),
            "--format",
            "pdf",
            "--force",
        ],
        input=test_data,
    )

    # Check that command succeeded
    assert result.exit_code == 0


def test_relaxation_wildcard_selector(tmp_path):
    """Test relaxation plotting with wildcard frame selector."""

    test_data_file = path_in_test_data(__file__, "GB1_T1_Relaxation_series_fitted_short.nef")
    test_data = Path(test_data_file).read_text()

    output_file = tmp_path / "test_relax_{entry}_{frame}_{page}"

    # Test with wildcard selector
    result = run_and_report(
        app,
        ["*T1*", "-o", str(output_file), "--format", "pdf", "--force"],
        input=test_data,
    )

    # Check that command succeeded
    assert result.exit_code == 0


def test_relaxation_verbose(tmp_path):
    """Test relaxation plotting with verbose output."""

    test_data_file = path_in_test_data(__file__, "GB1_T1_Relaxation_series_fitted_short.nef")
    test_data = Path(test_data_file).read_text()

    output_file = tmp_path / "test_relax_{entry}_{frame}_{page}"

    # Test with verbose flag
    result = run_and_report(
        app,
        [
            "nefpls_series_list_T1",
            "-o",
            str(output_file),
            "--format",
            "pdf",
            "--verbose",
            "--force",
        ],
        input=test_data,
    )

    # Check that command succeeded
    assert result.exit_code == 0

    # Verbose output should contain progress messages (in stdout)
    assert "Processing frame:" in result.stdout or "Extracted data" in result.stdout
