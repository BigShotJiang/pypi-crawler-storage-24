from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Tuple, Any, Optional
import os
import re
import subprocess
import sys

import typer
from pynmrstar import Entry, Loop

from nef_pipelines.lib.nef_lib import (
    loop_row_dict_iter,
    read_entry_from_file_or_stdin_or_exit_error,
    select_frames,
    select_loops_by_category,
)
from nef_pipelines.lib.util import STDIN, exit_error, parse_comma_separated_options, open_files_in_viewer
from nef_pipelines.tools.plot import plot_app

try:
    import matplotlib
    matplotlib.use('Agg')  # Use non-interactive backend
    import matplotlib.pyplot as plt
    import matplotlib.patches as patches
    from matplotlib.backends.backend_pdf import PdfPages
    import numpy as np

    #TODO: matplotlib will always be available!
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False


@plot_app.command()
def correlations(
    frame_specs: List[str] = typer.Argument(
        ...,
        help="""\
        frame specifications in format:
        - frame_selector.loop_category:tag1,tag2,... (full selection)
        - frame_selector:tag1,tag2,... (auto-detect suitable loop)  
        - frame_selector (smart defaults for single loop with atom/chain/sequence/value)
        Must provide pairs of specifications for correlation (even number required)
        """,
        metavar="<FRAME-SPEC>",
    ),
    input_path: Path = typer.Option(
        STDIN,
        "--in",
        "-i",
        metavar="|INPUT|",
        help="input to read NEF data from [stdin = -]",
    ),
    output: str = typer.Option(
        "correlation_{count}.pdf",
        "--out",
        help="output filename template with {count} placeholder and format extension [default: correlation_{{count}}.pdf], use - for binary stdout",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        help="overwrite existing output files without prompting",
    ),
    rows: int = typer.Option(
        2,
        "--rows",
        help="number of subplot rows per page",
    ),
    cols: int = typer.Option(
        2,
        "--cols", 
        help="number of subplot columns per page",
    ),
    orientation: str = typer.Option(
        "portrait",
        "--orientation",
        help="page orientation: portrait or landscape",
    ),
    paper_size: str = typer.Option(
        "a4",
        "--paper-size",
        help="paper size for matplotlib (a4, letter, etc.)",
    ),
    axis_unit: Optional[str] = typer.Option(
        None,
        "--axis-unit",
        help="unit label for axes",
    ),
    y_scale_factor: float = typer.Option(
        1.0,
        "--y-scale",
        help="scale factor to multiply y-axis values by",
    ),
    line_color: str = typer.Option(
        "blue",
        "--line-color",
        help="matplotlib color for diagonal line",
    ),
    symbol_color: str = typer.Option(
        "red",
        "--symbol-color", 
        help="matplotlib color for data points",
    ),
    line_style: str = typer.Option(
        "--",
        "--line-style",
        help="matplotlib line style for diagonal line",
    ),
    symbol_style: str = typer.Option(
        "o",
        "--symbol-style",
        help="matplotlib marker style for data points",
    ),
    symbol_fill: bool = typer.Option(
        True,
        "--symbol-fill",
        help="fill symbols or not",
    ),
    calculate: bool = typer.Option(
        False,
        "--calculate",
        help="calculate correlation coefficient, standard deviation, and show regression line on plot",
        # TODO: rename this flag to --fit in future version
    ),
    show_residues: bool = typer.Option(
        False,
        "--show-residues",
        help="show sequence codes as labels on data points",
    ),
    verbose: bool = typer.Option(
        False,
        "-v",
        "--verbose",
        help="show detailed information about frame detection, loop compatibility, and plotting process",
    ),
    open_files: bool = typer.Option(
        False,
        "--open",
        help="automatically open generated plot files in the system's default viewer",
    ),
    no_error_bars: bool = typer.Option(
        False,
        "--no-error-bars",
        help="hide error bars on plots (even if uncertainty data is available)",
    ),
    no_regression_line: bool = typer.Option(
        False,
        "--no-regression-line",
        help="hide regression line but still show statistics text (when --calculate is specified)",
    ),
):
    """- create correlation plots between pairs of frame specifications"""
    
    if not MATPLOTLIB_AVAILABLE:
        exit_error("matplotlib is required for plotting but not available. Please install matplotlib.")
    
    # Validate even number of frame specs for pairs
    if len(frame_specs) % 2 != 0:
        exit_error(f"Must provide even number of frame specifications for pairs. Got {len(frame_specs)} specifications.")
    
    if len(frame_specs) < 2:
        exit_error("Must provide at least 2 frame specifications for one correlation pair.")
    
    entry = read_entry_from_file_or_stdin_or_exit_error(input_path)
    
    plot_options = {
        'output': output,
        'force': force,
        'rows': rows,
        'cols': cols,
        'orientation': orientation,
        'paper_size': paper_size,
        'axis_unit': axis_unit,
        'y_scale_factor': y_scale_factor,
        'line_color': line_color,
        'symbol_color': symbol_color,
        'line_style': line_style,
        'symbol_style': symbol_style,
        'symbol_fill': symbol_fill,
        'calculate': calculate,
        'show_residues': show_residues,
        'verbose': verbose,
        'open_files': open_files,
        'no_error_bars': no_error_bars,
        'no_regression_line': no_regression_line,
    }
    
    result_entry = pipe(entry, frame_specs, plot_options)

    # Only output NEF if not in binary stdout mode
    if output != '-':
        print(result_entry)


def _ensure_plot_option_defaults(plot_options: Dict[str, Any]) -> Dict[str, Any]:
    """Ensure all required plot options have default values.
    
    Args:
        plot_options: Dictionary of plotting options (may be incomplete)
        
    Returns:
        Complete plot options dictionary with defaults for missing values
    """
    defaults = {
        'output': 'correlation_{count}.pdf',
        'force': False,
        'rows': 2,
        'cols': 2,
        'orientation': 'portrait',
        'paper_size': 'a4',
        'axis_unit': None,
        'y_scale_factor': 1.0,
        'line_color': 'blue',
        'symbol_color': 'red',
        'line_style': '--',
        'symbol_style': 'o',
        'symbol_fill': True,
        'calculate': False,
        'show_residues': False,
        'verbose': False,
        'open_files': False,
        'no_error_bars': False,
        'no_regression_line': False,
    }
    
    # Create a new dict with defaults, then update with provided options
    complete_options = defaults.copy()
    complete_options.update(plot_options)
    return complete_options


def pipe(entry: Entry, frame_specs: List[str], plot_options: Dict[str, Any]) -> Entry:
    """Create correlation plots between pairs of frame specifications.
    
    Args:
        entry: NEF entry to process
        frame_specs: List of frame specifications (must be even number for pairs)
        plot_options: Dictionary of plotting options
        
    Returns:
        The original NEF entry (unchanged)
    """
    
    # Ensure all plot options have defaults
    plot_options = _ensure_plot_option_defaults(plot_options)
    
    # Validate even number of frame specs
    if len(frame_specs) % 2 != 0:
        exit_error(f"Must provide even number of frame specifications for pairs. Got {len(frame_specs)} specifications.")
    
    if len(frame_specs) < 2:
        exit_error("Must provide at least 2 frame specifications for one correlation pair.")
    
    # Parse frame specification pairs
    frame_pairs = []
    for i in range(0, len(frame_specs), 2):
        if plot_options.get('verbose', False):
            print(f"\n# Processing frame specification pair {i//2 + 1}")
            print(f"#   Frame spec 1: {frame_specs[i]}")
            print(f"#   Frame spec 2: {frame_specs[i + 1]}")
        
        spec1 = _parse_frame_spec(frame_specs[i])
        spec2 = _parse_frame_spec(frame_specs[i + 1])
        
        # Resolve smart defaults for incomplete specs  
        spec1 = _resolve_smart_defaults(entry, spec1, frame_specs[i], plot_options.get('verbose', False))
        spec2 = _resolve_smart_defaults(entry, spec2, frame_specs[i + 1], plot_options.get('verbose', False))
        
        if plot_options.get('verbose', False):
            print(f"#   Resolved spec 1: {spec1[0]}.{spec1[1]}:{','.join(spec1[2])}")
            print(f"#   Resolved spec 2: {spec2[0]}.{spec2[1]}:{','.join(spec2[2])}")
        
        frame_pairs.append((spec1, spec2))

    # Extract correlation data for each pair
    correlation_data = []
    for spec1, spec2 in frame_pairs:
        #TODO: why pass around frame specs and the entry why not pass in the correct frames plus specs
        data = _extract_correlation_data(entry, spec1, spec2, plot_options)
        if data:
            correlation_data.extend(data)
    
    if not correlation_data:
        exit_error("No correlation data found for the specified frame pairs.")
    
    # Group data by splitting criteria automatically derived from data
    grouped_data = _group_correlation_data(correlation_data)
    
    if plot_options.get('verbose', False):
        print(f"\n# Grouping data for plotting")
        print(f"#   Number of groups: {len(grouped_data)}")
        for group_key, group_data in grouped_data.items():
            print(f"#     Group [{group_key}]: {len(group_data)} correlation pairs")
    
    # Generate plots with grid layout
    generated_files = _generate_correlation_plots(grouped_data, plot_options)
    
    # Open files in default viewer if requested
    if plot_options.get('open_files', False):
        if plot_options.get('verbose', False):
            print(f"# Opening generated files: {', '.join(generated_files)}")
        open_files_in_viewer(generated_files)
    
    return entry


def _parse_frame_spec(frame_spec: str) -> Tuple[str, str, List[str]]:
    """Parse a frame specification.
    
    Args:
        frame_spec: Specification in format: 
                   - frame_selector.loop_category:tag1,tag2,... (full selection)
                   - frame_selector:tag1,tag2,... (simplified selection - auto-detect loop)
                   - frame_selector (smart defaults)
    
    Returns:
        Tuple of (frame_selector, loop_category, tags)
    """
    
    # Check for empty frame specification
    if not frame_spec.strip():
        exit_error(f"Invalid frame specification '{frame_spec}'. Cannot be empty")
    
    # Handle simple frame name case - return as incomplete spec for later smart resolution
    if ":" not in frame_spec and "." not in frame_spec:
        return frame_spec, "", []
    
    if ":" not in frame_spec:
        exit_error(f"Invalid frame specification '{frame_spec}'. Expected format: frame_selector.loop_category:tag1,tag2,... or frame_selector:tag1,tag2,... or frame_selector")
    
    frame_loop_part, tags_part = frame_spec.split(":", 1)
    
    # Parse tags
    tags = parse_comma_separated_options([tags_part]) if tags_part.strip() else []
    if not tags:
        exit_error(f"Invalid frame specification '{frame_spec}'. Tags are required after ':'")
    
    # Check if this is simplified format (frame_selector:tags) or full format (frame_selector.loop_category:tags)
    # When a dot is present before the colon, split on the last dot and treat the part after as loop category
    # The loop category will be matched with wildcards by select_loops_by_category
    if "." not in frame_loop_part:
        # Simplified format: frame_selector:tag1,tag2,...
        frame_selector = frame_loop_part
        loop_category = ""  # Will be resolved later
    else:
        # Split on last dot: everything before is frame, everything after is loop category
        last_dot_index = frame_loop_part.rfind(".")
        frame_selector = frame_loop_part[:last_dot_index]
        loop_category = frame_loop_part[last_dot_index + 1:]
        
        # Empty string after dot means wildcard (e.g., "shifts.")
        if loop_category == "":
            loop_category = "*"
    
    # Default missing parts to wildcards
    if not frame_selector:
        frame_selector = "*"
    if not loop_category:
        loop_category = "*"
    
    return frame_selector, loop_category, tags


def _resolve_smart_defaults(entry: Entry, spec: Tuple[str, str, List[str]], original_spec: str, verbose: bool = False) -> Tuple[str, str, List[str]]:
    """Resolve smart defaults for incomplete frame specifications.
    
    Args:
        entry: NEF entry
        spec: Parsed specification (frame_selector, loop_category, tags)
        original_spec: Original specification string for error messages
        verbose: Whether to print verbose information
        
    Returns:
        Resolved specification tuple
    """
    frame_selector, loop_category, tags = spec
    
    if verbose:
        print(f"#     DEBUG _resolve_smart_defaults: frame_selector={frame_selector}, loop_category='{loop_category}', tags={tags}")
    
    # If specification is already complete, return as-is
    if loop_category and loop_category != "*" and tags:
        if verbose:
            print(f"#     DEBUG: Spec already complete, returning as-is")
        return spec
    
    # Get frames matching the selector
    frames = select_frames(entry, [frame_selector])
    if not frames:
        exit_error(f"No frames found matching '{frame_selector}'")
    
    if verbose:
        frame_names = [f.name for f in frames]
        print(f"#     Found {len(frames)} frame(s): {', '.join(frame_names)}")
    
    if len(frames) > 1:
        frame_names = [f.name for f in frames]
        exit_error(f"Frame selector '{frame_selector}' is ambiguous, matches multiple frames: {', '.join(frame_names)}")
    
    frame = frames[0]
    
    # Case 1: Only frame name provided (smart defaults) 
    if not loop_category and not tags:
        if verbose:
            print(f"#     Using smart defaults for frame '{frame.name}'")
            print(f"#     Available loops: {', '.join([loop.category for loop in frame.loops])}")
        selected_loop, selected_tags = _find_suitable_loop_with_defaults(frame, verbose)
        if verbose:
            print(f"#     Selected loop: {selected_loop.category}")
            print(f"#     Selected tags: {', '.join(selected_tags)}")
        # Return loop category without leading underscore for consistency with select_loops_by_category
        loop_category_for_matching = selected_loop.category.lstrip("_")
        return frame_selector, loop_category_for_matching, selected_tags
    
    # Case 2: Simplified format (frame_selector:tags) - need to find suitable loop
    elif not loop_category or loop_category == "*":
        if verbose:
            print(f"#     Finding suitable loop for tags: {', '.join(tags)}")
            print(f"#     Available loops: {', '.join([loop.category for loop in frame.loops])}")
        selected_loop = _find_suitable_loop_for_tags(frame, tags, verbose)
        if verbose:
            print(f"#     Selected loop: {selected_loop.category}")
            print(f"#     DEBUG: Returning ({frame_selector}, {selected_loop.category.lstrip('_')}, {tags})")
        # Return loop category without leading underscore for consistency with select_loops_by_category
        loop_category_for_matching = selected_loop.category.lstrip("_")
        return frame_selector, loop_category_for_matching, tags
    
    return spec


def _find_suitable_loop_with_defaults(frame, verbose: bool = False) -> Tuple[Loop, List[str]]:
    """Find suitable loop with smart defaults for correlation analysis.
    
    Args:
        frame: NEF frame to search
        verbose: Whether to print verbose information
        
    Returns:
        Tuple of (selected_loop, selected_tags)
    """
    if len(frame.loops) == 0:
        exit_error(f"Frame '{frame.name}' contains no loops for correlation analysis")
    
    if len(frame.loops) == 1:
        loop = frame.loops[0]
        if verbose:
            print(f"#     Only one loop available, using: {loop.category}")
    else:
        # Multiple loops - find one that has detectable value fields
        suitable_loops = []
        for loop in frame.loops:
            # Check if this loop has detectable value fields
            value_field, uncertainty_field = _detect_value_fields(loop)
            if value_field:
                suitable_loops.append(loop)
        
        if len(suitable_loops) == 0:
            loop_categories = [loop.category for loop in frame.loops]
            exit_error(f"Frame '{frame.name}' contains no loops with detectable value fields. Available loops: {', '.join(loop_categories)}")
        elif len(suitable_loops) > 1:
            loop_categories = [loop.category for loop in suitable_loops]
            exit_error(f"Frame '{frame.name}' contains multiple suitable loops, please specify which one: {', '.join(loop_categories)}")
        
        loop = suitable_loops[0]
        if verbose:
            print(f"#     Selected loop: {loop.category}")
    
    # Check that the selected loop has value fields
    value_field, uncertainty_field = _detect_value_fields(loop)
    if not value_field:
        exit_error(f"Frame '{frame.name}' loop '{loop.category}' does not contain detectable value field for correlation analysis")
    
    # For smart defaults, return empty tags - alignment will be handled more intelligently
    return loop, []


def _find_suitable_loop_for_tags(frame, tags: List[str], verbose: bool = False) -> Loop:
    """Find suitable loop that contains all specified tags.
    
    Args:
        frame: NEF frame to search
        tags: Required tags
        verbose: Whether to print verbose information
        
    Returns:
        Selected loop
    """
    if len(frame.loops) == 0:
        exit_error(f"Frame '{frame.name}' contains no loops for correlation analysis")
    
    if len(frame.loops) == 1:
        loop = frame.loops[0]
        available_tags = [tag for tag in loop.tags if not tag.startswith('_')]
        missing_tags = [tag for tag in tags if tag not in available_tags]
        if missing_tags:
            exit_error(f"Frame '{frame.name}' loop '{loop.category}' does not contain required tags: {', '.join(missing_tags)}")
        return loop
    
    # Multiple loops - find one that contains all tags
    suitable_loops = []
    for loop in frame.loops:
        available_tags = [tag for tag in loop.tags if not tag.startswith('_')]
        if all(tag in available_tags for tag in tags):
            suitable_loops.append(loop)
    
    if len(suitable_loops) == 0:
        exit_error(f"Frame '{frame.name}' contains no loops with all required tags: {', '.join(tags)}")
    elif len(suitable_loops) > 1:
        loop_categories = [loop.category for loop in suitable_loops]
        exit_error(f"Frame '{frame.name}' contains multiple loops with required tags, please specify which one: {', '.join(loop_categories)}")
    
    return suitable_loops[0]


def _extract_correlation_data(entry: Entry, spec1: Tuple[str, str, List[str]], spec2: Tuple[str, str, List[str]], plot_options: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Extract correlation data from two frame specifications.
    
    Args:
        entry: NEF entry
        spec1: First frame specification (frame_selector, loop_category, tags)
        spec2: Second frame specification  
        plot_options: Plot options including field names
        
    Returns:
        List of correlation data dictionaries
    """
    
    frame_selector1, loop_category1, tags1 = spec1
    frame_selector2, loop_category2, tags2 = spec2
    
    if plot_options.get('verbose', False):
        print(f"\n# Extracting data for correlation")
        print(f"#   Dataset 1: {frame_selector1}.{loop_category1}")
        print(f"#   Dataset 2: {frame_selector2}.{loop_category2}")
    
    # Extract data from first specification
    data1 = _extract_frame_data(entry, frame_selector1, loop_category1, tags1, plot_options.get('verbose', False))
    if not data1:
        if plot_options.get('verbose', False):
            print(f"#   No data found for dataset 1")
        return []
    
    if plot_options.get('verbose', False):
        print(f"#   Dataset 1: Found {len(data1)} rows")
    
    # Extract data from second specification  
    data2 = _extract_frame_data(entry, frame_selector2, loop_category2, tags2, plot_options.get('verbose', False))
    if not data2:
        if plot_options.get('verbose', False):
            print(f"#   No data found for dataset 2")
        return []
    
    if plot_options.get('verbose', False):
        print(f"#   Dataset 2: Found {len(data2)} rows")

    # Align datasets by sequence_code and other identifiers
    aligned_data = _align_datasets(data1, data2)
    
    if plot_options.get('verbose', False):
        print(f"#   Aligned datasets: {len(aligned_data)} correlated pairs")
        if aligned_data:
            print(f"\n# Correlated pairs and values:")
            
            for i, pair in enumerate(aligned_data, 1):
                # Use sequence_code as the only identifier
                seq_code = pair.get('sequence_code', i)
                identifier_str = f"seq:{seq_code}"
                
                value1 = pair['value1']
                value2 = pair['value2']
                unc1_str = f"±{pair['uncertainty1']}" if pair.get('uncertainty1') is not None else ""
                unc2_str = f"±{pair['uncertainty2']}" if pair.get('uncertainty2') is not None else ""
                
                print(f"#   {i:3d}: {identifier_str:20} → {value1:8.3f}{unc1_str:8} vs {value2:8.3f}{unc2_str:8}")
    
    return aligned_data


def _extract_frame_data(entry: Entry, frame_selector: str, loop_category: str, tags: List[str], verbose: bool = False) -> List[Dict[str, Any]]:
    """Extract data from a frame specification with automatic field detection.
    
    Args:
        entry: NEF entry
        frame_selector: Frame selector pattern
        loop_category: Loop category pattern
        tags: List of tags to extract
        verbose: Whether to print verbose information
        
    Returns:
        List of extracted data dictionaries
    """
    
    # Select frames
    selected_frames = select_frames(entry, [frame_selector])
    if not selected_frames:
        return []
    
    all_data = []
    
    for frame in selected_frames:
        if verbose:
            print(f"#   Processing frame: {frame.name}")
            print(f"#     Looking for loop category: {loop_category}")
            print(f"#     Available loops: {[loop.category for loop in frame.loops]}")
        
        # Find matching loops
        target_loops = select_loops_by_category(frame.loops, [loop_category])
        
        if verbose:
            print(f"#     Found {len(target_loops)} matching loops")
        
        for loop in target_loops:
            # Auto-detect value and uncertainty fields
            value_field, uncertainty_field = _detect_value_fields(loop)
            if not value_field:
                if verbose:
                    print(f"#     Skipping loop {loop.category}: no value field detected")
                continue  # Skip loops without detectable value field
            
            if verbose:
                print(f"#     Processing loop {loop.category}")
                print(f"#       Value field: {value_field}")
                if uncertainty_field:
                    print(f"#       Uncertainty field: {uncertainty_field}")
                else:
                    print(f"#       No uncertainty field found")
                print(f"#       Available tags: {', '.join(loop.tags)}")
            
            # Check if required fields exist
            missing_tags = []
            required_fields = tags + [value_field]
            
            if verbose:
                print(f"#       Required tags: {tags}")
                print(f"#       Auto-detected value field: {value_field}")
                print(f"#       Combined required fields: {required_fields}")
            
            for field in required_fields:
                if field not in loop.tags:
                    missing_tags.append(field)
            
            if missing_tags:
                if verbose:
                    print(f"#     Skipping loop {loop.category}: missing required fields {missing_tags}")
                continue  # Skip loops without required fields
            
            # Extract data rows
            for row_dict in loop_row_dict_iter(loop):
                data_row = {
                    'frame_name': frame.name,
                    'loop_category': loop.category,
                }
                
                # Add tag values
                for tag in tags:
                    if tag in row_dict:
                        data_row[tag] = row_dict[tag]
                
                # Always add sequence_code fields for alignment
                for tag in row_dict.keys():
                    if tag.startswith('sequence_code'):
                        data_row[tag] = row_dict[tag]
                
                # Add value and uncertainty
                if value_field in row_dict:
                    try:
                        data_row['value'] = float(row_dict[value_field])
                    except (ValueError, TypeError):
                        continue  # Skip non-numeric values
                        
                if uncertainty_field in row_dict:
                    try:
                        data_row['uncertainty'] = float(row_dict[uncertainty_field])
                    except (ValueError, TypeError):
                        data_row['uncertainty'] = None
                else:
                    data_row['uncertainty'] = None
                
                all_data.append(data_row)
    
    return all_data


#TODO: this is wrong the alignment fields is always  sequence_code  or sequence_code_x there should be no more than one in each set
#NOTE: at a later dat we could provide a parameters for this so things like ids could be used also we should be able to correlata on @numeric values in
# fields as a power feature
def _align_datasets(data1: List[Dict[str, Any]], data2: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Align two datasets for correlation analysis.
    
    For general correlation, if there are no common identification fields,
    align by row index. Otherwise align by common field values.
    
    Args:
        data1: First dataset
        data2: Second dataset
        
    Returns:
        List of aligned correlation data
    """
    #TODO: i prefer data_1 etc
    if not data1 or not data2:
        return []
    
    fields1 = [field for field in data1[0].keys() if field.startswith('sequence_code')]
    fields2 = [field for field in data2[0].keys() if field.startswith('sequence_code')]


    # Use only the first sequence_code field for alignment
    if fields1:
        fields1 = [fields1[0]]  
    if fields2:
        fields2 = [fields2[0]]
        

    # Find common alignment fields between datasets
    # Use the sequence_code fields that exist in both datasets
    common_fields = list(set(fields1) & set(fields2))
    
    aligned_data = []
    
    if common_fields:
        # Create lookup by sequence_code for both datasets
        data1_lookup = {}
        for row in data1:
            seq_code = row.get(common_fields[0])
            if seq_code:
                data1_lookup[seq_code] = row
                
        data2_lookup = {}
        for row in data2:
            seq_code = row.get(common_fields[0])
            if seq_code:
                data2_lookup[seq_code] = row
        
        # Find common sequence codes and create aligned pairs
        common_seq_codes = set(data1_lookup.keys()) & set(data2_lookup.keys())

        
        # Sort sequence codes for consistent output
        for seq_code in sorted(common_seq_codes):
            row1 = data1_lookup[seq_code]
            row2 = data2_lookup[seq_code]
            
            aligned_row = {
                'value1': row1['value'],
                'value2': row2['value'],
                'uncertainty1': row1.get('uncertainty'),
                'uncertainty2': row2.get('uncertainty'),
                'frame1_name': row1['frame_name'],
                'frame2_name': row2['frame_name'],
                'sequence_code': seq_code,  # Only identification field needed
            }
                    
            aligned_data.append(aligned_row)
    else:
        # No common alignment fields found - cannot align datasets
        exit_error(f"""
Cannot align datasets - no common sequence_code fields found.
Dataset 1 has sequence fields: {fields1 if fields1 else 'none'}
Dataset 2 has sequence fields: {fields2 if fields2 else 'none'}

For correlation analysis, both datasets must have matching sequence_code fields for alignment.
""")
    
    return aligned_data


def _group_correlation_data(correlation_data: List[Dict[str, Any]]) -> Dict[Tuple, List[Dict[str, Any]]]:
    """Group correlation data by splitting criteria automatically determined from available fields.
    
    Args:
        correlation_data: List of aligned correlation data
        
    Returns:
        Dictionary mapping group keys to data lists
    """
    
    if not correlation_data:
        return {}
    
    # Determine split fields automatically from available data fields
    # Use common identifier fields like atom_name, chain_code if present
    potential_split_fields = ['atom_name', 'chain_code', 'residue_name']
    available_fields = set(correlation_data[0].keys())
    split_fields = [field for field in potential_split_fields if field in available_fields]
    
    # If no standard split fields found, group all data together
    if not split_fields:
        return {('all',): correlation_data}
    
    grouped_data = defaultdict(list)
    
    for data_row in correlation_data:
        # Create group key from available split fields
        group_key = tuple(data_row.get(field, '') for field in split_fields)
        grouped_data[group_key].append(data_row)
    
    return dict(grouped_data)


def _generate_correlation_plots(grouped_data: Dict[Tuple, List[Dict[str, Any]]], plot_options: Dict[str, Any]) -> List[str]:
    """Generate correlation plots with grid layout.
    
    Args:
        grouped_data: Grouped correlation data
        plot_options: Plot configuration options
        
    Returns:
        List of generated output file paths
    """

    groups = list(grouped_data.items())
    plots_per_page = plot_options['rows'] * plot_options['cols']
    generated_files = []
    
    # Set up matplotlib
    plt.style.use('default')
    
    # Generate pages
    page_count = 1
    total_pages = (len(groups) + plots_per_page - 1) // plots_per_page
    
    if plot_options.get('verbose', False):
        print(f"\n# Generating correlation plots")
        print(f"#   Page layout: {plot_options['rows']} rows × {plot_options['cols']} columns")
        print(f"#   Plots per page: {plots_per_page}")
        print(f"#   Total pages: {total_pages}")
        
    for page_start in range(0, len(groups), plots_per_page):
        page_groups = groups[page_start:page_start + plots_per_page]
        
        if plot_options.get('verbose', False):
            print(f"#   Creating page {page_count}/{total_pages} with {len(page_groups)} plots")
        
        # Create figure with specified layout
        fig_size = _get_figure_size(plot_options['paper_size'], plot_options['orientation'])
        fig, axes = plt.subplots(
            plot_options['rows'], 
            plot_options['cols'],
            figsize=fig_size,
            squeeze=False
        )
        
        # Plot each group
        for i, (group_key, group_data) in enumerate(page_groups):
            row = i // plot_options['cols']
            col = i % plot_options['cols']
            ax = axes[row, col]
            
            correlation_info = _plot_correlation(ax, group_data, group_key, plot_options)

            if plot_options.get('verbose', False) and correlation_info:
                print(f"#   Group correlation: R = {correlation_info['r_value']:.3f}, SD = {correlation_info['stdev']:.3f}")
        
        # Hide unused subplots
        for i in range(len(page_groups), plots_per_page):
            row = i // plot_options['cols']
            col = i % plot_options['cols']
            axes[row, col].set_visible(False)
        
        # Save figure
        output_template = plot_options['output']
        plt.tight_layout()

        if output_template == '-':
            # Binary stdout mode
            from io import BytesIO

            if sys.stdout.isatty():
                plt.close()
                exit_error("Cannot output binary plot data to terminal. Please specify an output file with --out.")

            if total_pages > 1:
                plt.close()
                exit_error("Cannot output multiple plot pages to stdout. Please specify an output file with --out or reduce data to single page.")

            # Write to stdout as binary
            buffer = BytesIO()
            plt.savefig(buffer, format='pdf', dpi=300, bbox_inches='tight')
            buffer.seek(0)
            sys.stdout.buffer.write(buffer.read())
            plt.close()

            if plot_options.get('verbose', False):
                print(f"#   Wrote binary plot to stdout", file=sys.stderr)

            generated_files.append('<stdout>')
        else:
            # File output mode
            output_file = output_template.format(count=page_count)

            # Check if file exists
            if os.path.exists(output_file) and not plot_options.get('force', False):
                plt.close()
                exit_error(f"Output file '{output_file}' already exists. Use --force to overwrite.")

            plt.savefig(output_file, dpi=300, bbox_inches='tight')
            plt.close()
            generated_files.append(output_file)

            if plot_options.get('verbose', False):
                print(f"#   Saved page {page_count} to: {output_file}", file=sys.stderr)

        page_count += 1
    
    return generated_files


def _plot_correlation(ax, group_data: List[Dict[str, Any]], group_key: Tuple, plot_options: Dict[str, Any]) -> Dict[str, Any]:
    """Plot a single correlation.

    Args:
        ax: Matplotlib axis
        group_data: Correlation data for this group
        group_key: Group identifier tuple
        plot_options: Plot options

    Returns:
        Dictionary with correlation information (r_value, stdev) or None
    """
    
    # Extract values
    values1 = [row['value1'] for row in group_data]
    values2 = [row['value2'] * plot_options['y_scale_factor'] for row in group_data]
    uncertainties1 = [row.get('uncertainty1') for row in group_data]
    uncertainties2 = [row.get('uncertainty2') * plot_options['y_scale_factor'] if row.get('uncertainty2') is not None else None for row in group_data]
    
    # Plot data points
    marker_face_color = plot_options['symbol_color'] if plot_options['symbol_fill'] else 'none'
    marker_edge_color = plot_options['symbol_color']
    
    # Add error bars if available and not disabled
    if plot_options.get('no_error_bars', False):
        xerr = None
        yerr = None
    else:
        xerr = [u for u in uncertainties1 if u is not None] if any(u is not None for u in uncertainties1) else None
        yerr = [u for u in uncertainties2 if u is not None] if any(u is not None for u in uncertainties2) else None

    ax.errorbar(
        values1, values2,
        xerr=xerr, yerr=yerr,
        fmt=plot_options['symbol_style'],
        color=marker_edge_color,
        markerfacecolor=marker_face_color,
        markeredgecolor=marker_edge_color,
        ecolor='gray',
        alpha=0.7
    )
    
    # Add sequence code labels if requested
    if plot_options.get('show_residues', False):
        for i, row in enumerate(group_data):
            seq_code = row.get('sequence_code', i+1)
            ax.annotate(
                str(seq_code),
                (values1[i], values2[i]),
                xytext=(5, 5),  # Offset from point
                textcoords='offset points',
                fontsize=8,
                alpha=0.8
            )
    
    # Add diagonal reference line spanning the axis ranges (data ± 10%)
    if values1 and values2:
        xlim = ax.get_xlim()
        ylim = ax.get_ylim()
        min_val = min(xlim[0], ylim[0])
        max_val = max(xlim[1], ylim[1])
        ax.plot(
            [min_val, max_val], [min_val, max_val],
            color=plot_options['line_color'],
            linestyle=plot_options['line_style'],
            alpha=0.8,
            zorder=0
        )
    
    # Calculate and display correlation if requested
    correlation_info = None
    if plot_options.get('calculate', False) and len(values1) > 1:
        # Calculate correlation coefficient
        correlation_matrix = np.corrcoef(values1, values2)
        r_value = correlation_matrix[0, 1]

        # Calculate linear regression
        coeffs = np.polyfit(values1, values2, 1)
        slope, intercept = coeffs

        # Calculate residuals and standard deviation
        predicted_values = np.array([slope * x + intercept for x in values1])
        residuals = np.array(values2) - predicted_values
        stdev = np.std(residuals, ddof=1)

        # Store correlation info for return
        correlation_info = {'r_value': r_value, 'stdev': stdev}

        # Draw regression line unless --no-regression-line is specified
        if not plot_options.get('no_regression_line', False):
            # Draw regression line across the data range
            x_min, x_max = min(values1), max(values1)
            x_line = [x_min, x_max]
            y_line = [slope * x + intercept for x in x_line]

            ax.plot(
                x_line, y_line,
                color='green',  # Different color from diagonal line
                linestyle='-',
                alpha=0.8,
                linewidth=2,
                zorder=1,
                label=f'Regression (R={r_value:.3f})'
            )

        # Add correlation and equation text to the plot (always shown when --calculate is used)
        equation_text = f'y = {slope:.3f}x + {intercept:.3f}'
        correlation_text = f'R = {r_value:.3f}\n{equation_text}\nSD = {stdev:.3f}'

        ax.text(
            0.05, 0.95,
            correlation_text,
            transform=ax.transAxes,
            bbox=dict(boxstyle='round', facecolor='white', alpha=0.8),
            verticalalignment='top',
            fontsize=10
        )
    
    # Set labels and title
    # Use group_key to create title based on available fields
    if group_key != ('all',):
        # Determine what the group key represents based on common split fields
        potential_split_fields = ['atom_name', 'chain_code', 'residue_name']
        title_parts = []
        for i, value in enumerate(group_key):
            if i < len(potential_split_fields) and value:
                title_parts.append(f"{potential_split_fields[i]}: {value}")
        
        ax.set_title(" - ".join(title_parts))
    else:
        ax.set_title("Correlation")
    
    # Set axis labels
    frame1_name = group_data[0]['frame1_name'] if group_data else 'Frame 1'
    frame2_name = group_data[0]['frame2_name'] if group_data else 'Frame 2'
    
    # Clean frame names
    xlabel = _clean_axis_label(frame1_name)
    ylabel = _clean_axis_label(frame2_name)
    
    # Add units if specified
    if plot_options['axis_unit']:
        xlabel += f" ({plot_options['axis_unit']})"
        ylabel += f" ({plot_options['axis_unit']})"
    
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    
    # Equal aspect ratio for correlation plots
    ax.set_aspect('equal', adjustable='box')
    ax.grid(True, alpha=0.3)
    
    return correlation_info


def _clean_axis_label(frame_name: str) -> str:
    """Clean frame name for axis label by removing nef_ prefixes.
    
    Args:
        frame_name: Original frame name
        
    Returns:
        Cleaned frame name
    """
    
    # Remove common NEF prefixes
    cleaned = frame_name
    prefixes_to_remove = ['nef_', 'NEF_']
    
    for prefix in prefixes_to_remove:
        if cleaned.startswith(prefix):
            cleaned = cleaned[len(prefix):]
            break
    
    # Replace underscores with spaces for readability
    cleaned = cleaned.replace('_', ' ')
    
    return cleaned


def _get_figure_size(paper_size: str, orientation: str) -> Tuple[float, float]:
    """Get figure size based on paper size and orientation.
    
    Args:
        paper_size: Paper size name
        orientation: portrait or landscape
        
    Returns:
        Tuple of (width, height) in inches
    """
    
    # Standard paper sizes in inches
    paper_sizes = {
        'a4': (8.27, 11.69),
        'letter': (8.5, 11.0),
        'legal': (8.5, 14.0),
        'a3': (11.69, 16.53),
        'tabloid': (11.0, 17.0),
    }
    
    size = paper_sizes.get(paper_size.lower(), paper_sizes['a4'])
    
    if orientation.lower() == 'landscape':
        return (size[1], size[0])  # Swap width and height
    else:
        return size


def _detect_value_fields(loop: Loop) -> Tuple[Optional[str], Optional[str]]:
    """Detect value and uncertainty fields in a loop with priority search.
    
    Searches for value fields in priority order: 'value' first, then 'target_value'.
    For uncertainty fields, searches for corresponding 'value_uncertainty' or 'target_value_uncertainty'.
    
    Args:
        loop: NEF loop to search
        
    Returns:
        Tuple of (value_field, uncertainty_field) or (None, None) if not found
    """
    
    # Get all tags with and without underscore prefix
    all_tags = set(loop.tags)
    tag_patterns = set()
    for tag in all_tags:
        tag_patterns.add(tag)
        if tag.startswith('_'):
            tag_patterns.add(tag[1:])  # Remove underscore prefix
    
    value_field = None
    uncertainty_field = None
    
    # Priority search: 'value' first, then 'target_value'
    for value_pattern in ['value', 'target_value']:
        # Check for exact match or with underscore prefix
        for candidate in [value_pattern, f'_{value_pattern}']:
            if candidate in all_tags:
                value_field = candidate
                break
        
        if value_field:
            # Found value field, now look for corresponding uncertainty field
            uncertainty_pattern = f'{value_pattern}_uncertainty'
            for candidate in [uncertainty_pattern, f'_{uncertainty_pattern}']:
                if candidate in all_tags:
                    uncertainty_field = candidate
                    break
            break  # Stop at first value field found due to priority
    
    return value_field, uncertainty_field