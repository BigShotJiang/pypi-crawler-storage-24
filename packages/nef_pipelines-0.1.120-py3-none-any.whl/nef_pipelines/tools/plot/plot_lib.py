"""Shared plotting utilities and constants for NEF plot tools."""

FILE_FORMATS = {
    "svgz": "Scalable Vector Graphics (compressed)",
    "ps": "Postscript",
    "emf": "Enhanced Metafile",
    "rgba": "Raw RGBA bitmap",
    "raw": "Raw RGBA bitmap",
    "pdf": "Portable Document Format",
    "svg": "Scalable Vector Graphics",
    "eps": "Encapsulated Postscript",
    "png": "Portable Network Graphics",
}

PAPER_SIZES = {
    "a4": (8.27, 11.69),
    "letter": (8.5, 11),
    "legal": (8.5, 14),
    "a3": (11.69, 16.54),
    "tabloid": (11, 17),
}
