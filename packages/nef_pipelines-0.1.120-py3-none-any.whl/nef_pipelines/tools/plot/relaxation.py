# TODO: we are not using structures for assignments or relaxation rates... use the RelaxationRate structure record
# relaxation rates and assignments

import math
from collections import OrderedDict
from typing import Dict, List, Tuple
from pathlib import Path
import warnings

import matplotlib.pyplot as plt  # noqa: F401
import numpy as np  # noqa: F401
import matplotlib as mpl
import matplotlib.transforms as transforms

mpl.use("Agg")  # Non-interactive backend

# Suppress FutureWarnings from uncertainties library (used by lmfit)
warnings.filterwarnings('ignore', category=FutureWarning, module='uncertainties')

import typer
from pynmrstar import Entry, Saveframe

from nef_pipelines.lib.nef_lib import (
    loop_row_namespace_iter,
    read_entry_from_file_or_stdin_or_exit_error,
    select_frames_by_name,
)
from nef_pipelines.lib.util import STDIN, exit_error, info, parse_comma_separated_options, open_files_in_viewer, STDOUT
from nef_pipelines.tools.fit.fit_lib import (
    calculate_noise_level_from_replicates,
    RelaxationSeriesValues,
)
from nef_pipelines.tools.plot import plot_app
from nef_pipelines.tools.plot.plot_lib import FILE_FORMATS, PAPER_SIZES
from nef_pipelines.lib.structures import FittedRate, SeriesData, PaperType, PlotInfo

SERIES_DATA_CATEGORY = "_{NAMESPACE}_series_data"
SERIES_LIST_CATEGORY = "{NAMESPACE}_series_list"

FRAME_SELECTORS_HELP = """
    frame selectors to plot (e.g., '*T1*', 'nefpls_series_list_T1'), 
    can be comma separated or multiple calls to the option
"""

NAMESPACES_HELP = """
    namespaces to search for series list frames (e.g., 'nefpls', 'nef'),
    can be comma separated or multiple calls to the option [default: nefpls,nef]
"""

OUTPUT_HELP = """
    output filename template with placeholders: {entry}, {frame}, {page}, {ext}
    [default: relaxation_{entry}_{frame}_page_{page}]
"""

FILE_FORMAT_HELP = f"""
    output file format, one of: {', '.join(FILE_FORMATS.keys())}
"""


@plot_app.command()
def relaxation(
        frame_selectors: List[str] = typer.Argument(
            None,
            help=FRAME_SELECTORS_HELP,
        ),
        input_path: Path = typer.Option(
            STDIN,
            "-i",
            "--in",
            metavar="|INPUT|",
            help="input NEF file [stdin = -]",
        ),
        namespaces: List[str] = typer.Option(
            ["nefpls", "nef"],
            "-n",
            "--namespace",
            help=NAMESPACES_HELP,
        ),
        output: str = typer.Option(
            "relaxation_{entry}_{frame}_page_{page}",
            "-o",
            "--out",
            help=OUTPUT_HELP,
        ),
        rows: int = typer.Option(
            None,
            "--rows",
            help="number of subplot rows per page [default: 2 for landscape, 3 for portrait]",
        ),
        cols: int = typer.Option(
            None,
            "--cols",
            help="number of subplot columns per page [default: 3 for landscape, 2 for portrait]",
        ),
        orientation: str = typer.Option(
            "landscape",
            "--orientation",
            help="page orientation: landscape or portrait",
        ),
        paper_size: str = typer.Option(
            "a4",
            "--paper-size",
            help="paper size for plots (a4, letter, legal, a3, tabloid)",
        ),
        title_template: str = typer.Option(
            "#{chain_code}:{sequence_code}[{residue_name}]@{atom_name_1}-{atom_name_2}",
            "--title",
            help="title template for assigned data. Available placeholders: {data_id}, {chain_code}, {sequence_code}, {residue_name}, {atom_name_1}, {atom_name_2}",
        ),
        unassigned_title_template: str = typer.Option(
            "Data ID {data_id}",
            "--unassigned-title",
            help="title template for unassigned data. Available placeholders: {data_id}",
        ),
        plot_format: str = typer.Option(
            "pdf",
            "-f",
            "--format",
            help=FILE_FORMAT_HELP,
        ),
        no_fit: bool = typer.Option(
            False,
            "--no-fit",
            help="disable exponential fit overlay (fits shown by default)",
        ),
        no_residuals: bool = typer.Option(
            False,
            "--no-residuals",
            help="disable residuals plot (residuals shown by default)",
        ),
        force: bool = typer.Option(
            False,
            "--force",
            help="overwrite existing output files without prompting",
        ),
        common_y_scale: bool = typer.Option(
            False,
            "--common-y-scale",
            help="use same y-axis scale for all plots across all pages for easier comparison",
        ),
        verbose: bool = typer.Option(
            False,
            "-v",
            "--verbose",
            help="produce verbose output with progress messages",
        ),
        open_file: bool = typer.Option(
            False,
            "--open",
            help="automatically open generated plot file in the system's default viewer",
        ),
        page_margin: float = typer.Option(
            0.05,
            "--page-margin",
            help="page edge margin as fraction of page width/height, 0-1 (default: 0.05 = 5%%)",
        ),
        spacing: float = typer.Option(
            0.03,
            "--spacing",
            help="spacing between plots as fraction of page width/height, 0-1 (default: 0.03 = 3%%)",
        ),
        debug_grid: bool = typer.Option(
            False,
            "--debug-grid",
            help="show grid structure with colored overlays (red=row margins, blue=col margins, purple=corners, white=plots)",
        ),
):
    """- create relaxation decay plots from series list frames [alpha]"""

    # Validate file format
    _check_plot_format_valid_or_exit(plot_format)

    # Validate stdout compatibility
    _if_plotting_stdout_if_not_streamable_plot_format_exit_error(output, plot_format)

    entry = read_entry_from_file_or_stdin_or_exit_error(input_path)

    # Parse frame selectors
    frame_selectors = parse_comma_separated_options(frame_selectors)
    if not frame_selectors:
        frame_selectors = ["*"]

    series_frames = _get_selected_relxation_frames_or_exit(entry, namespaces, frame_selectors, verbose)

    cols, rows = _get_default_rows_and_colums_if_not_defined(orientation, cols, rows)

    # Convert no_residuals to show_residuals
    show_residuals = not no_residuals
    # Convert no_fit to show_fit
    show_fit = not no_fit

    # Construct plot configuration objects
    paper_type = PaperType(paper_size=paper_size, orientation=orientation)
    plot_info = PlotInfo(
        paper_type=paper_type,
        rows=rows,
        cols=cols,
        output_template=output,
        common_y_scale=common_y_scale,
        page_margin=page_margin,
        spacing=spacing,
        debug_grid=debug_grid,
    )

    generated_files = pipe(
        entry,
        series_frames,
        plot_info,
        title_template,
        unassigned_title_template,
        plot_format,
        show_fit,
        show_residuals,
        force,
        verbose,
    )

    # Handle file opening outside of business logic
    if open_file and generated_files:
        open_files_in_viewer(generated_files)

    print(entry)


def pipe(
        entry: Entry,
        series_frames: List[Saveframe],
        plot_info: PlotInfo,
        title_template: str,
        unassigned_template: str,
        file_format: str,
        show_fit: bool,
        show_residuals: bool,
        force: bool,
        verbose: bool,
) -> List[str]:
    """
    Business logic for relaxation plotting.

    Args:
        entry: NEF Entry object
        series_frames: List of Saveframe objects to plot
        plot_info: Plot layout configuration (paper type, rows, cols, output template, y-scale settings)
        title_template: Title template for assigned plots
        unassigned_template: Title template for unassigned plots
        file_format: Output file format (pdf, svg, etc.)
        show_fit: Whether to overlay exponential fits
        show_residuals: Whether to show residuals subplot
        force: Whether to overwrite existing files
        verbose: Whether to show progress messages

    Returns:
        List of generated output file paths
    """

    generated_files = []

    # Process each frame
    for series_frame in series_frames:
        # Extract namespace from frame name
        namespace = _get_namespace_from_frame(series_frame)

        if verbose:
            info(
                f"Processing frame: {series_frame.name} (namespace: {namespace})"
            )

        # Extract data grouped by data_id
        id_series_data, noise_estimate = _extract_series_data(series_frame, namespace, verbose)

        if not id_series_data:
            if verbose:
                info(f"  No data found in frame {series_frame.name}, skipping")
            continue

        # Extract fitted rates if available
        fitted_rates = _extract_fitted_rates(
            entry, series_frame, id_series_data, namespace, verbose
        )

        # Generate plots
        files = _create_plots(
            entry,
            series_frame,
            id_series_data,
            fitted_rates,
            noise_estimate,
            plot_info,
            title_template,
            unassigned_template,
            file_format,
            show_fit,
            show_residuals,
            force,
            verbose,
        )

        generated_files.extend(files)

    return generated_files


def _get_default_rows_and_colums_if_not_defined(orientation: str, cols: int, rows: int) -> tuple[int, int]:
    # Apply smart defaults for rows/cols based on orientation
    if orientation.lower() not in ["landscape", "portrait"]:
        exit_error(f"Invalid orientation '{orientation}'. Must be 'landscape' or 'portrait'")

    if rows is None or cols is None:
        if orientation.lower() == "landscape":
            rows = rows if rows is not None else 2
            cols = cols if cols is not None else 3
        else:  # portrait
            rows = rows if rows is not None else 3
            cols = cols if cols is not None else 2
    return cols, rows


def _get_selected_relxation_frames_or_exit(entry: Entry, namespaces: list[str], frame_selectors: list[str],
                                           verbose: bool) -> List[Saveframe]:
    # Parse namespaces
    namespaces = parse_comma_separated_options(namespaces)

    # Find series list frames matching selectors
    series_frames = _find_series_frames(entry, frame_selectors, namespaces, verbose)

    if not series_frames:
        namespaces_str = ", ".join(namespaces)
        selectors_str = ", ".join(frame_selectors)

        # Find ALL available relaxation frames across all namespaces to help user
        all_available = []
        for ns in ["nefpls", "nef"]:
            category = SERIES_LIST_CATEGORY.format(NAMESPACE=ns)
            frames = entry.get_saveframes_by_category(category)
            all_available.extend([f.name for f in frames])

        if all_available:
            frames_list = "\n".join(f"  - {name}" for name in all_available)
            msg = f"""\
                No series list frames found matching '{selectors_str}' in namespaces: {namespaces_str}

                Available relaxation frames:
                {frames_list}
            """
        else:
            msg = f"""\
                No relaxation series frames found in entry.
                Expected frames with category: {SERIES_LIST_CATEGORY.format(NAMESPACE='nef[pls]')}
            """
        exit_error(msg)
    return series_frames


def _if_plotting_stdout_if_not_streamable_plot_format_exit_error(output: str, plot_format: str):
    streamable_formats = ["pdf", "ps"]
    if output == str(STDOUT) and plot_format not in streamable_formats:
        exit_error(
            f"""\
                Cannot stream '{plot_format}' format to stdout.
                Only {', '.join(streamable_formats)} formats support stdout streaming.
                Use a file output path or switch to a streamable format.
            """
        )


def _check_plot_format_valid_or_exit(plot_format: str):
    if plot_format not in FILE_FORMATS:
        exit_error(
            f"Invalid file format '{plot_format}'. Must be one of: {', '.join(FILE_FORMATS.keys())}"
        )


def _get_namespace_from_frame(frame: Saveframe) -> str:
    """
    Extract namespace from save frame name.

    Frame names follow pattern: save_{namespace}_series_list_{name}
    Examples:
        save_nefpls_series_list_T1 -> nefpls
        save_nef_series_list_T2 -> nef

    Args:
        frame: Saveframe to extract namespace from

    Returns:
        Namespace string (e.g., 'nefpls', 'nef')
    """
    name = frame.name.replace('save_', '')
    parts = name.split('_')
    return parts[0] if parts else 'nef'


def _find_series_frames(
        entry: Entry,
        frame_selectors: List[str],
        namespaces: List[str],
        verbose: bool,
) -> List[Saveframe]:
    """
    Find series list frames matching selectors across multiple namespaces.

    Returns:
        List of Saveframe objects
    """
    found_frames = []

    for namespace in namespaces:
        category = SERIES_LIST_CATEGORY.format(NAMESPACE=namespace)

        # Get all frames with this category
        category_frames = entry.get_saveframes_by_category(category)

        if not category_frames:
            continue

        # Filter by frame selectors using library function
        selected_frames = select_frames_by_name(category_frames, frame_selectors)

        for frame in selected_frames:
            # Avoid duplicates
            if not any(f.name == frame.name for f in found_frames):
                found_frames.append(frame)
                if verbose:
                    info(f"Found frame: {frame.name} (namespace: {namespace})")

    return found_frames


# TODO this should most probably go in a library....
def _extract_series_data(
        series_frame: Saveframe,
        namespace: str,
        verbose: bool,
) -> Dict[int, SeriesData]:
    """
    Extract series data grouped by data_id.

    Args:
        series_frame: Series list frame
        namespace: Namespace prefix (e.g., 'nefpls', 'nef')
        verbose: Whether to show progress messages

    Returns:
        Dictionary mapping data_id to SeriesData objects
    """
    series_category = SERIES_DATA_CATEGORY.format(NAMESPACE=namespace)

    if series_category not in series_frame:
        if verbose:
            info(
                f"  Warning: No {series_category} loop found in frame {series_frame.name}"
            )
        return {}

    series_data_loop = series_frame.get_loop(series_category)

    # Group data by data_id, preserving order
    id_to_data = OrderedDict()

    for row in loop_row_namespace_iter(series_data_loop):
        data_id = int(row.data_id)

        # Initialize data structure for this data_id
        if data_id not in id_to_data:
            id_to_data[data_id] = {
                "variable_values": [],
                "data_values": [],
                "variable_errors": [],
                "value_errors": [],
            }

        # Extract values
        variable_value = float(row.variable_value)
        data_value = float(row.value)

        # Extract errors if present (might be '.' for missing)
        variable_error = row.variable_error if hasattr(row, "variable_error") else "."
        value_error = row.value_error if hasattr(row, "value_error") else "."

        # Convert errors to float or None
        try:
            variable_error = float(variable_error) if variable_error != "." else None
        except (ValueError, TypeError):
            variable_error = None

        try:
            value_error = float(value_error) if value_error != "." else None
        except (ValueError, TypeError):
            value_error = None

        # Append to lists
        id_to_data[data_id]["variable_values"].append(variable_value)
        id_to_data[data_id]["data_values"].append(data_value)
        id_to_data[data_id]["variable_errors"].append(variable_error)
        id_to_data[data_id]["value_errors"].append(value_error)

    # Convert dicts to SeriesData objects first (without noise_estimate)
    series_data_objects = {}
    for data_id, data_dict in id_to_data.items():
        series_data_objects[data_id] = SeriesData(
            data_id=data_id,
            variable_values=data_dict["variable_values"],
            data_values=data_dict["data_values"],
            variable_errors=data_dict["variable_errors"],
            value_errors=data_dict["value_errors"],
            noise_estimate=None
        )

    # Calculate noise estimate from replicate measurements using fit_lib
    noise_estimate = _calculate_noise_from_replicates(series_data_objects)

    # Update all SeriesData objects with the noise estimate
    if noise_estimate is not None:
        for data in series_data_objects.values():
            data.noise_estimate = noise_estimate

    if verbose:
        info(f"  Extracted data for {len(series_data_objects)} data IDs")
        if noise_estimate is not None:
            info(f"  Estimated noise from replicates: {noise_estimate:.2f}")

    return series_data_objects, noise_estimate


def _calculate_noise_from_replicates(id_series_data: Dict[int, SeriesData]) -> float:
    """
    Calculate noise estimate from replicate measurements using fit_lib function.

    Args:
        id_series_data: Dictionary mapping data_id to series data

    Returns:
        Standard deviation of differences between replicates, or None if no replicates
    """
    # Convert to RelaxationSeriesValues format expected by fit_lib
    relaxation_series = {}

    for data_id, data in id_series_data.items():
        series_values = RelaxationSeriesValues(
            variable_values=data.variable_values,
            values=data.data_values,
        )
        relaxation_series[data_id] = series_values

    # Use the fit_lib function
    noise_level, _fraction_error, _num_replicates = calculate_noise_level_from_replicates(
        relaxation_series
    )

    return noise_level


def _extract_fitted_rates(
        entry: Entry,
        series_frame: Saveframe,
        id_series_data: Dict[int, SeriesData],
        namespace: str,
        verbose: bool,
) -> Dict[int, Tuple[float, float, float]]:
    """
    Extract fitted relaxation rates from relaxation_list frames and fit amplitudes.

    Args:
        entry: NEF Entry object
        series_frame: Series list frame
        id_series_data: Dictionary mapping data_id to series data
        namespace: Namespace prefix (e.g., 'nefpls')
        verbose: Whether to show progress messages

    Returns:
        Dictionary mapping data_id to FittedRate objects containing:
        - amplitude: Fitted amplitude (best fit to data with fixed rate)
        - rate: Relaxation rate constant from fit
        - rate_error: Error on rate constant
        - data_id: Data ID
    """

    # Get relaxation_list_id from series_data loop
    series_category = SERIES_DATA_CATEGORY.format(NAMESPACE=namespace)

    if series_category not in series_frame:
        return {}

    series_data_loop = series_frame.get_loop(series_category)

    # Find the relaxation_list_id (should be same for all rows in a series)
    relaxation_list_id = None
    for row in loop_row_namespace_iter(series_data_loop):
        if hasattr(row, 'relaxation_list_id') and row.relaxation_list_id != '.':
            relaxation_list_id = row.relaxation_list_id
            break

    if not relaxation_list_id:
        if verbose:
            info(f"  No relaxation_list_id found in series data")
        return {}

    # Get the relaxation list frame
    relaxation_frame = None
    for frame in entry:
        if frame.name == relaxation_list_id:
            relaxation_frame = frame
            break

    if not relaxation_frame:
        if verbose:
            info(f"  Relaxation frame '{relaxation_list_id}' not found in entry")
        return {}

    # Extract fitted rates from relaxation loop
    relaxation_category = f"_{namespace}_relaxation"

    if relaxation_category not in relaxation_frame:
        if verbose:
            info(f"  No {relaxation_category} loop found in {relaxation_list_id}")
        return {}

    relaxation_loop = relaxation_frame.get_loop(relaxation_category)

    fitted_rates = {}
    for row in loop_row_namespace_iter(relaxation_loop):
        data_id = int(row.data_id)
        rate = float(row.value)
        rate_error = float(row.value_error) if hasattr(row, 'value_error') and row.value_error != '.' else 0.0

        # Fit I0 amplitude given the fixed rate R
        if data_id in id_series_data:
            variable_values = np.array(id_series_data[data_id].variable_values)
            data_values = np.array(id_series_data[data_id].data_values)

            if len(variable_values) > 0 and len(data_values) > 0:
                # Fit I0 by minimizing sum of squared residuals
                # I(t) = I0 * exp(-R * t)
                # Best I0 = sum(I_obs * exp(-R*t)) / sum(exp(-2*R*t))
                exp_term = np.exp(-rate * variable_values)
                I0_fitted = np.sum(data_values * exp_term) / np.sum(exp_term ** 2)

                fitted_rates[data_id] = FittedRate(
                    amplitude=I0_fitted,
                    rate=rate,
                    rate_error=rate_error,
                    data_id=data_id
                )

    if verbose and fitted_rates:
        info(f"  Extracted fitted rates for {len(fitted_rates)} data IDs from {relaxation_list_id}")

    return fitted_rates


def _get_atom_info_from_data_id(
        entry: Entry,
        data_id: int,
        verbose: bool = False,
) -> Dict[str, str]:
    """
    Extract atom information for two atoms (e.g., HN-N pair) for a given data_id.

    The data_id typically refers to a peak_id in nmr_spectrum frames.
    For relaxation data, extracts information for both atom_1 and atom_2.

    CURRENT IMPLEMENTATION: Assumes exactly 2 atoms per data_id, which is typical for
    most relaxation experiments (e.g., 15N-1H, 13C-1H). The code extracts atom_name_1
    and atom_name_2 fields and uses dimension 1 fields (chain_code_1, sequence_code_1,
    residue_name_1) for the residue information.

    FUTURE ENHANCEMENT: Could be extended to support up to 5 dimensions for more complex
    multi-dimensional experiments, though this is not currently needed.

    Args:
        entry: NEF Entry object
        data_id: Data ID to look up
        verbose: Whether to show debug messages

    Returns:
        Dictionary with keys: chain_code, sequence_code, residue_name, atom_name_1, atom_name_2
        Returns empty strings for missing values
    """
    atom_info = {
        "chain_code": "",
        "sequence_code": "",
        "residue_name": "",
        "atom_name_1": "",
        "atom_name_2": "",
    }

    # Look for peak with matching peak_id in nmr_spectrum frames
    for frame in entry:
        if frame.category in ("nef_nmr_spectrum", "nefpls_nmr_spectrum"):
            # Get the peak list loop
            peak_loop_name = f"_{frame.category.replace('_nmr_spectrum', '')}_peak"
            if peak_loop_name in frame:
                peak_loop = frame[peak_loop_name]

                # Search for peak with matching peak_id
                # TODO: there will always be two chains [chain_code_1, chain_code_2] , atoms [atom_name_1, atom_name_2] etc in a valid file
                # TODO its possible there could be upto 5?
                for row in loop_row_namespace_iter(peak_loop):
                    if hasattr(row, "peak_id") and int(row.peak_id) == data_id:
                        # Extract atom information - prefer dimension-specific fields
                        # Try dimension 1 fields first (chain_code_1, sequence_code_1, etc.)
                        if hasattr(row, "chain_code_1"):
                            atom_info["chain_code"] = str(row.chain_code_1) if row.chain_code_1 != "." else ""
                        elif hasattr(row, "chain_code"):
                            atom_info["chain_code"] = str(row.chain_code) if row.chain_code != "." else ""

                        if hasattr(row, "sequence_code_1"):
                            atom_info["sequence_code"] = str(row.sequence_code_1) if row.sequence_code_1 != "." else ""
                        elif hasattr(row, "sequence_code"):
                            atom_info["sequence_code"] = str(row.sequence_code) if row.sequence_code != "." else ""

                        if hasattr(row, "residue_name_1"):
                            atom_info["residue_name"] = str(row.residue_name_1) if row.residue_name_1 != "." else ""
                        elif hasattr(row, "residue_name"):
                            atom_info["residue_name"] = str(row.residue_name) if row.residue_name != "." else ""

                        # Extract both atom names
                        if hasattr(row, "atom_name_1"):
                            atom_info["atom_name_1"] = str(row.atom_name_1) if row.atom_name_1 != "." else ""
                        elif hasattr(row, "atom_name"):
                            atom_info["atom_name_1"] = str(row.atom_name) if row.atom_name != "." else ""

                        if hasattr(row, "atom_name_2"):
                            atom_info["atom_name_2"] = str(row.atom_name_2) if row.atom_name_2 != "." else ""

                        if verbose:
                            info(f"    Found atom info for data_id {data_id}: {atom_info}")

                        return atom_info

    # If not found, return empty values
    if verbose:
        info(f"    No atom info found for data_id {data_id}")

    return atom_info


def _format_plot_title(
        title_template: str,
        unassigned_template: str,
        data_id: int,
        atom_info: Dict[str, str],
) -> str:
    """
    Format plot title using template and available atom information.

    If no assignment information is available and the template contains atom-related
    placeholders, uses the unassigned_template instead.

    Args:
        title_template: Template string with placeholders for assigned data
        unassigned_template: Template string for unassigned data
        data_id: Data ID value
        atom_info: Dictionary with atom information (may include atom_name_1, atom_name_2)

    Returns:
        Formatted title string
    """
    has_assignments = any(
        atom_info.get(field, "")
        for field in ["chain_code", "sequence_code", "residue_name", "atom_name_1", "atom_name_2"]
    )

    has_atom_placeholders = any(
        placeholder in title_template
        for placeholder in [
            "{chain_code}",
            "{sequence_code}",
            "{residue_name}",
            "{atom_name}",
            "{atom_name_1}",
            "{atom_name_2}",
        ]
    )

    # Use unassigned template if no assignments but template expects them
    if not has_assignments and has_atom_placeholders:
        try:
            return unassigned_template.format(data_id=data_id)
        except KeyError:
            return f"Data ID {data_id}"

    # Use assigned template
    try:
        return title_template.format(
            data_id=data_id,
            chain_code=atom_info.get("chain_code", ""),
            sequence_code=atom_info.get("sequence_code", ""),
            residue_name=atom_info.get("residue_name", ""),
            atom_name=atom_info.get("atom_name_1", ""),  # Fallback for single-atom templates
            atom_name_1=atom_info.get("atom_name_1", ""),
            atom_name_2=atom_info.get("atom_name_2", ""),
        )
    except KeyError:
        return f"Data ID {data_id}"


def _create_plots(
        entry: Entry,
        series_frame: Saveframe,
        id_series_data: Dict[int, SeriesData],
        fitted_rates: Dict[int, FittedRate],
        noise_estimate: float,
        plot_info: PlotInfo,
        title_template: str,
        unassigned_template: str,
        file_format: str,
        show_fit: bool,
        show_residuals: bool,
        force: bool,
        verbose: bool,
) -> List[str]:
    """
    Create multi-page plots with subplots for each data_id.

    Args:
        entry: NEF Entry object (for entry_id)
        series_frame: Series list frame (for frame name)
        id_series_data: Dictionary mapping data_id to data
        fitted_rates: Dictionary mapping data_id to FittedRate objects
        noise_estimate: Estimated noise from replicate measurements
        plot_info: Plot layout configuration (paper type, rows, cols, output template, y-scale settings)
        title_template: Title template for assigned plots
        unassigned_template: Title template for unassigned plots
        file_format: Output file format
        show_fit: Whether to show exponential fits (fallback to scipy if no fitted rates)
        show_residuals: Whether to show residuals subplot
        force: Whether to overwrite existing files
        verbose: Whether to show progress messages

    Returns:
        List of generated output file paths
    """

    # Extract values from plot_info
    rows = plot_info.rows
    cols = plot_info.cols
    output_template = plot_info.output_template
    paper_size = plot_info.paper_type.paper_size
    orientation = plot_info.paper_type.orientation
    common_y_scale = plot_info.common_y_scale
    page_margin = plot_info.page_margin
    spacing = plot_info.spacing
    debug_grid = plot_info.debug_grid

    data_ids = list(id_series_data.keys())
    plots_per_page = rows * cols
    num_pages = math.ceil(len(data_ids) / plots_per_page)

    if verbose:
        info(
            f"  Creating {num_pages} page(s) with {plots_per_page} plot(s) per page"
        )

    # Get series variable info from frame
    series_var_type = series_frame.get_tag("series_variable_type")[0]
    series_var_unit = series_frame.get_tag("series_variable_unit")[0]
    data_value_type = series_frame.get_tag("data_value_type")[0]
    data_value_unit = series_frame.get_tag("data_value_unit")[0]

    # Create axis labels
    x_label = f"{series_var_type}"
    if series_var_unit and series_var_unit != ".":
        x_label += f" ({series_var_unit})"

    y_label = f"{data_value_type}"
    if data_value_unit and data_value_unit != ".":
        y_label += f" ({data_value_unit})"

    # Pre-calculate common y-axis range and scaling across ALL pages if requested
    y_min = None
    y_max = None
    common_y_scale_factor = None  # Single scale factor for all subplots when common scale enabled

    if common_y_scale:
        all_y_values = []
        for data_id in data_ids:
            all_y_values.extend(id_series_data[data_id].data_values)

        if all_y_values:
            # Calculate single scale factor based on global max
            global_max = max(np.abs(all_y_values))
            if global_max > 0:
                exponent = math.floor(math.log10(global_max))
                common_y_scale_factor = 10 ** exponent
                if global_max / common_y_scale_factor < 1.0:
                    common_y_scale_factor = 10 ** (exponent - 1)
            else:
                common_y_scale_factor = 1.0

            # Calculate min/max in SCALED units
            scaled_values = [v / common_y_scale_factor for v in all_y_values]
            y_min = min(scaled_values)
            y_max = max(scaled_values)

            # Add 10% padding
            y_range = y_max - y_min
            y_min -= 0.1 * y_range
            y_max += 0.1 * y_range

    # For PDF, use PdfPages for multi-page single file
    # For other formats, create separate files
    # Strip 'save_' prefix and category from frame name
    frame_name = series_frame.name[5:] if series_frame.name.startswith('save_') else series_frame.name
    # Remove category prefix (e.g., "nefpls_series_list_T1" -> "T1")
    if frame_name.startswith(series_frame.category + '_'):
        frame_name = frame_name[len(series_frame.category) + 1:]
    output_file = _format_output_filename(
        output_template,
        entry.entry_id,
        frame_name,
        1,
        file_format,
    )

    # Check if output file exists and handle force flag
    if output_file != "-" and Path(output_file).exists() and not force:
        exit_error(
            f"""\
                Output file '{output_file}' already exists.
                Use --force to overwrite existing files.
            """
        )

    generated_files = []

    if file_format == "pdf":
        from matplotlib.backends.backend_pdf import PdfPages

        with PdfPages(output_file) as pdf:
            for page_num in range(num_pages):
                _create_single_page(
                    entry,
                    page_num,
                    num_pages,
                    data_ids,
                    plots_per_page,
                    id_series_data,
                    fitted_rates,
                    noise_estimate,
                    rows,
                    cols,
                    paper_size,
                    orientation,
                    title_template,
                    unassigned_template,
                    x_label,
                    y_label,
                    show_fit,
                    show_residuals,
                    y_min,
                    y_max,
                    common_y_scale_factor,
                    page_margin,
                    spacing,
                    debug_grid,
                    verbose,
                )
                pdf.savefig(dpi=300)
                plt.close()

        generated_files.append(output_file)

        if verbose:
            info(f"  Saved: {output_file}")
    else:
        # For non-PDF formats, create separate files per page
        for page_num in range(num_pages):
            page_output_file = _format_output_filename(
                output_template,
                entry.entry_id,
                frame_name,
                page_num + 1,
                file_format,
            )

            # Check if this page file exists and handle force flag
            if page_output_file != "-" and Path(page_output_file).exists() and not force:
                exit_error(
                    f"""\
                        Output file '{page_output_file}' already exists.
                        Use --force to overwrite existing files.
                    """
                )

            _create_single_page(
                entry,
                page_num,
                num_pages,
                data_ids,
                plots_per_page,
                id_series_data,
                fitted_rates,
                noise_estimate,
                rows,
                cols,
                paper_size,
                orientation,
                title_template,
                unassigned_template,
                x_label,
                y_label,
                show_fit,
                show_residuals,
                y_min,
                y_max,
                common_y_scale_factor,
                page_margin,
                spacing,
                debug_grid,
                verbose,
            )

            plt.savefig(page_output_file, dpi=300)
            plt.close()

            generated_files.append(page_output_file)

            if verbose:
                info(f"  Saved: {page_output_file}")

    return generated_files


def _create_single_page(
        entry: Entry,
        page_num: int,
        num_pages: int,
        data_ids: List[int],
        plots_per_page: int,
        id_series_data: Dict[int, SeriesData],
        fitted_rates: Dict[int, FittedRate],
        noise_estimate: float,
        rows: int,
        cols: int,
        paper_size: str,
        orientation: str,
        title_template: str,
        unassigned_template: str,
        x_label: str,
        y_label: str,
        show_fit: bool,
        show_residuals: bool,
        y_min: float,
        y_max: float,
        common_y_scale_factor: float,
        page_margin: float,
        spacing: float,
        debug_grid: bool,
        verbose: bool,
):
    """
    Create a single page of plots.

    Args:
        entry: NEF Entry object
        page_num: Page number (0-indexed)
        num_pages: Total number of pages
        data_ids: List of all data IDs
        plots_per_page: Number of plots per page
        id_series_data: Dictionary mapping data_id to data
        fitted_rates: Dictionary mapping data_id to FittedRate objects
        noise_estimate: Estimated noise from replicate measurements
        rows: Subplot rows per page
        cols: Subplot columns per page
        paper_size: Paper size (a4, letter, etc.)
        orientation: Page orientation (portrait or landscape)
        title_template: Title template for assigned plots
        unassigned_template: Title template for unassigned plots
        x_label: X-axis label
        y_label: Y-axis label
        show_fit: Whether to show exponential fits (fallback to scipy if no fitted rates)
        show_residuals: Whether to show residuals subplot
        y_min: Minimum y-axis value for common scale (None for auto)
        y_max: Maximum y-axis value for common scale (None for auto)
        common_y_scale_factor: Common scaling factor for y-values (None for per-plot scaling)
        page_margin: Page edge margin as fraction of page (0-1)
        spacing: Spacing between plots as fraction of page (0-1)
        debug_grid: Whether to show grid structure with colored backgrounds for debugging
        verbose: Whether to show progress messages
    """
    import matplotlib.pyplot as plt
    import numpy as np

    start_idx = page_num * plots_per_page
    end_idx = min(start_idx + plots_per_page, len(data_ids))
    page_data_ids = data_ids[start_idx:end_idx]

    if verbose:
        info(f"  Generating page {page_num + 1}/{num_pages}")

    # Convert paper size to inches for matplotlib
    # Get paper dimensions
    if paper_size.lower() in PAPER_SIZES:
        width, height = PAPER_SIZES[paper_size.lower()]
    else:
        # Default to A4 if unknown
        width, height = PAPER_SIZES["a4"]

    # Swap dimensions for landscape
    if orientation.lower() == "landscape":
        width, height = height, width

    # Create figure
    fig = plt.figure(figsize=(width, height))

    # Determine if we need residuals - only if fitted rates are available
    has_fitted_rates = len(fitted_rates) > 0
    use_residuals = show_residuals and has_fitted_rates

    # Convert margins and spacing to be equal physical size
    # Use width as reference dimension, then scale for height based on aspect ratio
    # Get paper dimensions
    if paper_size.lower() in PAPER_SIZES:
        page_width_inches, page_height_inches = PAPER_SIZES[paper_size.lower()]
    else:
        page_width_inches, page_height_inches = PAPER_SIZES["a4"]

    # Swap for landscape
    if orientation.lower() == "landscape":
        page_width_inches, page_height_inches = page_height_inches, page_width_inches

    aspect_ratio = page_height_inches / page_width_inches

    # Convert page_margin and spacing from fractions to physical units (relative to width)
    # Then convert back to fractions for each dimension
    # Margins in horizontal direction use the specified fraction
    horizontal_margin_fraction = page_margin
    horizontal_spacing_fraction = spacing

    # Margins in vertical direction scaled to have same physical size
    # physical_margin = page_margin * page_width_inches
    # vertical_fraction = physical_margin / page_height_inches
    #                  = (page_margin * page_width_inches) / page_height_inches
    #                  = page_margin / aspect_ratio
    vertical_margin_fraction = page_margin / aspect_ratio
    vertical_spacing_fraction = spacing / aspect_ratio

    # Calculate usable area (subtract page margins)
    usable_left = horizontal_margin_fraction
    usable_bottom = vertical_margin_fraction
    usable_width = 1.0 - 2 * horizontal_margin_fraction
    usable_height = 1.0 - 2 * vertical_margin_fraction

    # Calculate dimensions for each plot
    # Total spacing between columns/rows
    total_horizontal_spacing = horizontal_spacing_fraction * (cols - 1) if cols > 1 else 0
    total_vertical_spacing = vertical_spacing_fraction * (rows - 1) if rows > 1 else 0

    # Each plot's grid cell dimensions
    grid_cell_width = (usable_width - total_horizontal_spacing) / cols
    grid_cell_height = (usable_height - total_vertical_spacing) / rows

    # Reserve space WITHIN grid cell for decorations (as fractions of grid cell)
    # These reserves shrink the axes to fit decorations inside the cell
    reserve_left = 0.15  # Y-axis label + tick labels
    reserve_right = 0.02  # Small buffer
    reserve_top = 0.08  # Title
    reserve_bottom = 0.12  # X-axis label + tick labels

    # Actual axes dimensions (smaller than grid cell to fit decorations)
    axes_width = grid_cell_width * (1.0 - reserve_left - reserve_right)
    axes_height = grid_cell_height * (1.0 - reserve_top - reserve_bottom)

    # Plot each data_id using direct fig.add_axes() for exact positioning
    if debug_grid:
        print(f"\n=== PLOT PLACEMENT DEBUG (page {page_num + 1}) ===")
        print(f"Page dimensions: {page_width_inches:.2f}\" x {page_height_inches:.2f}\" (aspect={aspect_ratio:.4f})")
        print(f"Margin/spacing specified: {page_margin:.4f} (as fraction of width)")
        print(f"Horizontal margin/spacing: {horizontal_margin_fraction:.4f}")
        print(f"Vertical margin/spacing: {vertical_margin_fraction:.4f} (scaled for equal physical size)")
        print(
            f"Usable area: left={usable_left:.4f}, bottom={usable_bottom:.4f}, width={usable_width:.4f}, height={usable_height:.4f}")
        print(f"Grid cell dimensions: width={grid_cell_width:.4f}, height={grid_cell_height:.4f}")
        print(
            f"Decoration reserves (fraction of cell): left={reserve_left}, right={reserve_right}, top={reserve_top}, bottom={reserve_bottom}")
        print(f"Axes dimensions (inside cell): width={axes_width:.4f}, height={axes_height:.4f}")

    for i, data_id in enumerate(page_data_ids):
        row = i // cols
        col = i % cols

        # Calculate grid cell position
        grid_cell_left = horizontal_margin_fraction + col * (grid_cell_width + horizontal_spacing_fraction)
        grid_cell_bottom = vertical_margin_fraction + (rows - 1 - row) * (grid_cell_height + vertical_spacing_fraction)

        # Position axes INSIDE the grid cell, with reserves for decorations
        # Axes start after the left reserve and bottom reserve
        axes_left = grid_cell_left + reserve_left * grid_cell_width
        axes_bottom = grid_cell_bottom + reserve_bottom * grid_cell_height

        if use_residuals:
            # Split axes_height: 75% main, 25% residuals, no gap
            main_height = axes_height * 0.75
            residual_height = axes_height * 0.25
            gap_height = 0.0

            # Main plot at top of allocated space
            ax_main = fig.add_axes([axes_left, axes_bottom + residual_height + gap_height, axes_width, main_height])
            # Residual plot at bottom of allocated space
            ax_resid = fig.add_axes([axes_left, axes_bottom, axes_width, residual_height], sharex=ax_main)

            if debug_grid:
                print(f"Plot {i} (row={row}, col={col}):")
                print(
                    f"  Grid cell: [{grid_cell_left:.4f}, {grid_cell_bottom:.4f}, {grid_cell_width:.4f}, {grid_cell_height:.4f}]")
                print(
                    f"  Axes (main): [{axes_left:.4f}, {axes_bottom + residual_height + gap_height:.4f}, {axes_width:.4f}, {main_height:.4f}]")
                print(f"  Axes (resid): [{axes_left:.4f}, {axes_bottom:.4f}, {axes_width:.4f}, {residual_height:.4f}]")
        else:
            # Single plot using full height
            ax_main = fig.add_axes([axes_left, axes_bottom, axes_width, axes_height])
            ax_resid = None

            if debug_grid:
                print(f"Plot {i} (row={row}, col={col}):")
                print(
                    f"  Grid cell: [{grid_cell_left:.4f}, {grid_cell_bottom:.4f}, {grid_cell_width:.4f}, {grid_cell_height:.4f}]")
                print(f"  Axes: [{axes_left:.4f}, {axes_bottom:.4f}, {axes_width:.4f}, {axes_height:.4f}]")

        data = id_series_data[data_id]
        x_values = np.array(data.variable_values)
        y_values = np.array(data.data_values)

        # Check if errors are present (not all None)
        has_x_errors = any(e is not None for e in data.variable_errors)
        has_y_errors = any(e is not None for e in data.value_errors)

        x_errors = (
            np.array(
                [e if e is not None else 0 for e in data.variable_errors]
            )
            if has_x_errors
            else None
        )
        y_errors = (
            np.array([e if e is not None else 0 for e in data.value_errors])
            if has_y_errors
            else None
        )

        # Scale y-values to make max close to 1.0 (but > 1.0) for readability
        # Use common scale factor if provided (for --common-y-scale), otherwise calculate per-subplot
        if common_y_scale_factor is not None:
            y_scale = common_y_scale_factor
        else:
            max_y = max(np.abs(y_values)) if len(y_values) > 0 else 1.0
            if max_y > 0:
                # Find power of 10 to divide by: want max_y / divisor to be in range [1, 10)
                exponent = math.floor(math.log10(max_y))
                y_scale = 10 ** exponent
                # If scaled max would be < 1.0, use smaller divisor
                if max_y / y_scale < 1.0:
                    y_scale = 10 ** (exponent - 1)
            else:
                y_scale = 1.0

        # Apply scaling to all y-data
        y_values_scaled = y_values / y_scale
        y_errors_scaled = y_errors / y_scale if y_errors is not None else None

        # Plot data points with error bars
        ax_main.errorbar(
            x_values,
            y_values_scaled,
            xerr=x_errors,
            yerr=y_errors_scaled,
            fmt="o",
            color="blue",
            ecolor="gray",
            alpha=0.7,
            markersize=6,
        )

        # Plot fitted curve if available from relaxation_list
        # Note: For valid relaxation data, fitted rates should always be available
        # from the relaxation_list frame. If not present, the data is incomplete.
        fitted_y = None  # Track fitted values for residuals
        if data_id in fitted_rates:
            # Use fitted rate from relaxation_list frame
            fitted_rate = fitted_rates[data_id]
            I0 = fitted_rate.amplitude
            R = fitted_rate.rate
            R_error = fitted_rate.rate_error
            x_fit = np.linspace(min(x_values), max(x_values), 100)
            y_fit_unscaled = I0 * np.exp(-R * x_fit)

            # Calculate fitted values at measured x points for residuals
            fitted_y = I0 * np.exp(-R * x_values)

            # Plot the SCALED fit curve to match the scaled data display
            ax_main.plot(
                x_fit,
                y_fit_unscaled / y_scale,
                ":",
                color="red",
                alpha=0.6,
                linewidth=2,
            )

            # Format rate with SI prefixes for readability
            R_scaled, R_prefix = _scale_with_si_prefix(R)
            R_error_scaled, _ = _scale_with_si_prefix(R_error, prefix=R_prefix)

            # Add text box with R value and error on right-hand side
            # Note: Units would come from relaxation_list frame if available
            rate_text = f"R = {R_scaled:.2f} ± {R_error_scaled:.2f} {R_prefix}s⁻¹"
            ax_main.text(0.95, 0.95, rate_text,
                         transform=ax_main.transAxes,
                         verticalalignment='top',
                         horizontalalignment='right',
                         fontsize=9,
                         bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
        elif verbose:
            # No fitted rate available - data may be incomplete
            info(f"    No fitted rate available for data_id {data_id}, skipping fit curve")

        # Get atom information for this data_id and format title
        atom_info = _get_atom_info_from_data_id(entry, data_id, verbose=False)
        plot_title = _format_plot_title(title_template, unassigned_template, data_id, atom_info)

        # Formatting main plot
        if ax_resid is not None:
            # If residuals, don't show x-axis labels on main plot
            ax_main.tick_params(labelbottom=False)
        else:
            ax_main.set_xlabel(x_label, fontsize=10)
        ax_main.set_ylabel(y_label, fontsize=10)
        ax_main.set_title(plot_title, fontsize=11, fontweight="bold")
        ax_main.grid(True, alpha=0.3, linestyle="--")
        # Scale y-axis values to sensible range but hide the scale factor text
        ax_main.ticklabel_format(style='plain', axis='y')  # Allow offset scaling
        ax_main.yaxis.get_offset_text().set_visible(False)  # Hide "×10^n" text

        # Apply common y-scale if provided
        if y_min is not None and y_max is not None:
            ax_main.set_ylim(y_min, y_max)

        # Plot residuals if enabled and fitted values are available
        if ax_resid is not None and fitted_y is not None:
            residuals = y_values - fitted_y

            # Set y-axis limits so green area (±3σ) takes up 50% of height
            # with 25% white space above and below
            if noise_estimate is not None:
                three_sigma = 3.0 * noise_estimate
                y_limit = 6.0 * noise_estimate  # Total range is ±6σ
                ax_resid.set_ylim(-y_limit, y_limit)

                # Add gradient background showing 3σ region (centered, 50% of height)
                # Fill 3-sigma region with light background
                ax_resid.axhspan(-three_sigma, three_sigma,
                                 color='lightgreen', alpha=0.2, zorder=0)

                # Classify points: in range (±3σ), out of range but visible (3σ to 6σ), and off-scale (>6σ)
                in_range = np.abs(residuals) <= three_sigma
                out_of_range_up_visible = (residuals > three_sigma) & (residuals <= y_limit)
                out_of_range_down_visible = (residuals < -three_sigma) & (residuals >= -y_limit)
                out_of_range_up_offscale = residuals > y_limit
                out_of_range_down_offscale = residuals < -y_limit

                # Plot points within 3-sigma region in green
                if np.any(in_range):
                    ax_resid.errorbar(
                        x_values[in_range],
                        residuals[in_range],
                        xerr=x_errors[in_range] if x_errors is not None else None,
                        yerr=y_errors[in_range] if y_errors is not None else None,
                        fmt="o",
                        color="green",
                        ecolor="gray",
                        alpha=0.7,
                        markersize=4,
                    )

                # Plot points outside 3σ but still visible (between 3σ and 6σ) in orange
                if np.any(out_of_range_up_visible):
                    ax_resid.errorbar(
                        x_values[out_of_range_up_visible],
                        residuals[out_of_range_up_visible],
                        xerr=x_errors[out_of_range_up_visible] if x_errors is not None else None,
                        yerr=y_errors[out_of_range_up_visible] if y_errors is not None else None,
                        fmt="o",
                        color="orange",
                        ecolor="gray",
                        alpha=0.7,
                        markersize=4,
                    )

                if np.any(out_of_range_down_visible):
                    ax_resid.errorbar(
                        x_values[out_of_range_down_visible],
                        residuals[out_of_range_down_visible],
                        xerr=x_errors[out_of_range_down_visible] if x_errors is not None else None,
                        yerr=y_errors[out_of_range_down_visible] if y_errors is not None else None,
                        fmt="o",
                        color="orange",
                        ecolor="gray",
                        alpha=0.7,
                        markersize=4,
                    )

                # Plot points above range as up-pointing triangles at top edge with sigma labels
                if np.any(out_of_range_up_offscale):
                    # Group by x-coordinate to handle multiple values at same position
                    x_vals_offscale = x_values[out_of_range_up_offscale]
                    resid_vals_offscale = residuals[out_of_range_up_offscale]

                    # Create dictionary mapping x to list of residual values
                    x_to_residuals = {}
                    for x_val, resid_val in zip(x_vals_offscale, resid_vals_offscale):
                        if x_val not in x_to_residuals:
                            x_to_residuals[x_val] = []
                        x_to_residuals[x_val].append(resid_val)

                    # DPI-aware calculations for pixel-accurate positioning
                    dpi = ax_resid.figure.dpi
                    trans = ax_resid.get_xaxis_transform()
                    marker_pts = 5  # Triangle marker size in points (original size)
                    font_sz = 7  # Font size in points

                    # Convert marker size from points to pixels
                    marker_px = (marker_pts * dpi) / 72
                    # Line height in pixels: font_sz in points converted to pixels with 20% leading
                    line_height_px = (font_sz * dpi / 72) * 1.2
                    # Base clearance: marker + 4px buffer
                    base_offset_px = marker_px + 4

                    # Plot one arrow per unique x position, stack labels if multiple values
                    for x_val, resid_list in x_to_residuals.items():
                        # Plot single triangle at top edge (y_spine=1)
                        tri_off = transforms.ScaledTranslation(0, -(marker_px / 2) / dpi,
                                                               ax_resid.figure.dpi_scale_trans)
                        ax_resid.plot(x_val, 1, marker='^', markersize=marker_pts, color='red',
                                      transform=trans + tri_off, clip_on=False, markeredgewidth=0, zorder=10)

                        # Stack sigma labels vertically below the triangle
                        for i, resid_val in enumerate(sorted(resid_list, reverse=True)):  # Sort high to low
                            sigma_value = resid_val / noise_estimate
                            total_shift = base_offset_px + (i * line_height_px)
                            txt_off = transforms.ScaledTranslation(0, -total_shift / dpi,
                                                                   ax_resid.figure.dpi_scale_trans)
                            ax_resid.text(x_val, 1, f'{sigma_value:.1f}σ',
                                          transform=trans + txt_off,
                                          va='top', ha='center', fontsize=font_sz, color='red',
                                          clip_on=False)

                # Plot points below range as down-pointing triangles at bottom edge with sigma labels
                if np.any(out_of_range_down_offscale):
                    # Group by x-coordinate to handle multiple values at same position
                    x_vals_offscale = x_values[out_of_range_down_offscale]
                    resid_vals_offscale = residuals[out_of_range_down_offscale]

                    # Create dictionary mapping x to list of residual values
                    x_to_residuals = {}
                    for x_val, resid_val in zip(x_vals_offscale, resid_vals_offscale):
                        if x_val not in x_to_residuals:
                            x_to_residuals[x_val] = []
                        x_to_residuals[x_val].append(resid_val)

                    # DPI-aware calculations for pixel-accurate positioning
                    dpi = ax_resid.figure.dpi
                    trans = ax_resid.get_xaxis_transform()
                    marker_pts = 5  # Triangle marker size in points (original size)
                    font_sz = 7  # Font size in points

                    # Convert marker size from points to pixels
                    marker_px = (marker_pts * dpi) / 72
                    # Line height in pixels: font_sz in points converted to pixels with 20% leading
                    line_height_px = (font_sz * dpi / 72) * 1.2
                    # Base clearance: marker + 4px buffer
                    base_offset_px = marker_px + 4

                    # Plot one arrow per unique x position, stack labels if multiple values
                    for x_val, resid_list in x_to_residuals.items():
                        # Plot single triangle at bottom edge (y_spine=0)
                        tri_off = transforms.ScaledTranslation(0, (marker_px / 2) / dpi,
                                                               ax_resid.figure.dpi_scale_trans)
                        ax_resid.plot(x_val, 0, marker='v', markersize=marker_pts, color='red',
                                      transform=trans + tri_off, clip_on=False, markeredgewidth=0, zorder=10)

                        # Stack sigma labels vertically above the triangle
                        for i, resid_val in enumerate(sorted(resid_list)):  # Sort low to high (most negative first)
                            sigma_value = resid_val / noise_estimate
                            total_shift = base_offset_px + (i * line_height_px)
                            txt_off = transforms.ScaledTranslation(0, total_shift / dpi,
                                                                   ax_resid.figure.dpi_scale_trans)
                            ax_resid.text(x_val, 0, f'{sigma_value:.1f}σ',
                                          transform=trans + txt_off,
                                          va='bottom', ha='center', fontsize=font_sz, color='red',
                                          clip_on=False)
            else:
                # No noise estimate, plot normally
                ax_resid.errorbar(
                    x_values,
                    residuals,
                    xerr=x_errors,
                    yerr=y_errors,
                    fmt="o",
                    color="green",
                    ecolor="gray",
                    alpha=0.7,
                    markersize=4,
                )

            ax_resid.axhline(y=0, color='black', linestyle='--', linewidth=1, alpha=0.5)
            ax_resid.set_xlabel(x_label, fontsize=10)

            # Set custom y-axis tick marks at ±3σ
            if noise_estimate is not None:
                three_sigma = 3.0 * noise_estimate
                ax_resid.set_yticks([-three_sigma, 0, three_sigma])
                ax_resid.set_yticklabels(['-3σ', '0', '+3σ'], fontsize=8)
            else:
                ax_resid.tick_params(labelleft=False)

            ax_resid.grid(True, alpha=0.3, linestyle="--")

    # Add debug grid visualization showing page margins and plot spacing
    if debug_grid:
        from matplotlib.patches import Rectangle

        print("\n=== DEBUG GRID STRUCTURE ===")
        print(f"Input margin: {page_margin:.4f}, Input spacing: {spacing:.4f}")
        print(f"Aspect ratio correction: {aspect_ratio:.4f}")
        print(f"Horizontal margin/spacing: {horizontal_margin_fraction:.4f} / {horizontal_spacing_fraction:.4f}")
        print(f"Vertical margin/spacing: {vertical_margin_fraction:.4f} / {vertical_spacing_fraction:.4f}")
        print(f"Rows: {rows}, Cols: {cols}, Use residuals: {use_residuals}")
        print(f"Grid cell: width={grid_cell_width:.4f}, height={grid_cell_height:.4f}")
        print(f"Axes (inside cell): width={axes_width:.4f}, height={axes_height:.4f}")
        print(f"Reserves: left={reserve_left}, right={reserve_right}, top={reserve_top}, bottom={reserve_bottom}")
        print("\n=== END DEBUG GRID ===\n")

        # Draw page margins (red)
        # Left margin
        rect = Rectangle((0, 0), horizontal_margin_fraction, 1.0, transform=fig.transFigure,
                         facecolor='red', alpha=0.15, zorder=-100, edgecolor='none')
        fig.patches.append(rect)
        # Right margin
        rect = Rectangle((1.0 - horizontal_margin_fraction, 0), horizontal_margin_fraction, 1.0,
                         transform=fig.transFigure,
                         facecolor='red', alpha=0.15, zorder=-100, edgecolor='none')
        fig.patches.append(rect)
        # Top margin
        rect = Rectangle((0, 1.0 - vertical_margin_fraction), 1.0, vertical_margin_fraction, transform=fig.transFigure,
                         facecolor='red', alpha=0.15, zorder=-100, edgecolor='none')
        fig.patches.append(rect)
        # Bottom margin
        rect = Rectangle((0, 0), 1.0, vertical_margin_fraction, transform=fig.transFigure,
                         facecolor='red', alpha=0.15, zorder=-100, edgecolor='none')
        fig.patches.append(rect)

        # Draw spacing between plots (blue) - between grid cells
        # Vertical spacing (between columns)
        for c in range(cols - 1):
            left = horizontal_margin_fraction + (c + 1) * grid_cell_width + c * horizontal_spacing_fraction
            rect = Rectangle((left, vertical_margin_fraction), horizontal_spacing_fraction, usable_height,
                             transform=fig.transFigure,
                             facecolor='blue', alpha=0.15, zorder=-100, edgecolor='none')
            fig.patches.append(rect)

        # Horizontal spacing (between rows)
        for r in range(rows - 1):
            # Count from bottom up
            bottom = vertical_margin_fraction + (r + 1) * grid_cell_height + r * vertical_spacing_fraction
            rect = Rectangle((horizontal_margin_fraction, bottom), usable_width, vertical_spacing_fraction,
                             transform=fig.transFigure,
                             facecolor='blue', alpha=0.15, zorder=-100, edgecolor='none')
            fig.patches.append(rect)


def _scale_with_si_prefix(value: float, prefix: str = None) -> Tuple[float, str]:
    """
    Scale a value using SI prefixes for readability.

    Args:
        value: Value to scale
        prefix: Force a specific prefix (e.g., 'm' for milli). If None, auto-detect.

    Returns:
        Tuple of (scaled_value, prefix_string)

    Examples:
        0.0123 → (12.3, 'm')  # millis⁻¹
        1234 → (1.234, 'k')   # kilos⁻¹
        0.5 → (0.5, '')       # no prefix
    """
    import math

    # SI prefixes and their powers of 10
    si_prefixes = [
        (1e12, 'T'),  # tera
        (1e9, 'G'),  # giga
        (1e6, 'M'),  # mega
        (1e3, 'k'),  # kilo
        (1, ''),  # no prefix
        (1e-3, 'm'),  # milli
        (1e-6, 'μ'),  # micro
        (1e-9, 'n'),  # nano
        (1e-12, 'p'),  # pico
    ]

    # If prefix is specified, use it
    if prefix is not None:
        for scale, pfx in si_prefixes:
            if pfx == prefix:
                return value / scale, prefix

    # Auto-detect best prefix
    abs_value = abs(value)

    if abs_value == 0:
        return 0.0, ''

    # Find the best prefix (closest to 1-1000 range)
    for scale, pfx in si_prefixes:
        scaled = abs_value / scale
        if 1 <= scaled < 1000:
            return value / scale, pfx

    # Fallback to no prefix
    return value, ''


def _format_output_filename(
        template: str,
        entry_id: str,
        frame_name: str,
        page_num: int,
        file_format: str,
) -> str:
    """
    Format output filename from template.

    Args:
        template: Template string with placeholders
        entry_id: NEF entry ID
        frame_name: Series frame name
        page_num: Page number (1-indexed)
        file_format: File extension

    Returns:
        Formatted filename
    """
    # Replace placeholders
    filename = template.replace("{entry}", entry_id)
    filename = filename.replace("{frame}", frame_name)

    # Only include page number for non-PDF formats (separate files per page)
    if file_format != "pdf":
        filename = filename.replace("{page}", str(page_num))
    else:
        # Remove {page} placeholder for PDFs and clean up any resulting formatting issues
        filename = filename.replace("_page_{page}", "").replace("_{page}", "").replace("{page}", "")

    filename = filename.replace("{ext}", file_format)

    # Add extension if not present
    if not filename.endswith(f".{file_format}"):
        filename = f"{filename}.{file_format}"

    return filename
