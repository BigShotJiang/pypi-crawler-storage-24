import typer

from nef_pipelines import nef_app
from nef_pipelines.lib.typer_lib import FilteredHelpGroup

plot_app = typer.Typer()


if nef_app.app:
    nef_app.app.add_typer(
        plot_app,
        name="plot",
        help="- create plots from nef data [correlations]",
        rich_help_panel="NEF visualization",
        no_args_is_help=True,
        cls=FilteredHelpGroup,
    )

    # import of specific plotters must be after app creation to avoid circular imports
    import nef_pipelines.tools.plot.correlations  # noqa: F401
    import nef_pipelines.tools.plot.relaxation  # noqa: F401