from dataclasses import dataclass, field
from enum import auto
from pathlib import Path
from typing import  List, Optional,  Tuple

import typer
from pynmrstar import Entry, Loop, Saveframe
from strenum import KebabCaseStrEnum

from nef_pipelines.lib.cli_lib import (
    format_residue_range,
    parse_residue_ranges,
    validate_residue_ranges_in_system,
)
from nef_pipelines.lib.nef_lib import (
    NEF_MOLECULAR_SYSTEM,
    find_residue_tag_sets,
    loop_has_residue_columns,
    loop_row_dict_iter,
    read_entry_from_file_or_stdin_or_exit_error,
    row_matches_any_range,
    select_frames,
    select_frames_by_name,
)
from nef_pipelines.lib.structures import ResidueRange
from nef_pipelines.lib.util import (
    STDIN,
    exit_error,
    parse_comma_separated_options,
    warn,
)
from nef_pipelines.tools.filter import filter_app

class ResiduesNotDefinedPolicy(KebabCaseStrEnum):
    """Policy for handling residue ranges not found in molecular system."""

    warn = auto()
    error = auto()
    quiet = auto()


class NoMatchPolicy(KebabCaseStrEnum):
    """Policy for handling residue ranges that match no rows."""

    warn = auto()
    error_immediate = auto()
    error_collect = auto()
    quiet = auto()


def help_residue_ranges_callback(value: bool):
    """Display detailed help for residue range syntax and exit."""
    if value:
        typer.echo(RESIDUE_RANGES_HELP)
        raise typer.Exit()


@dataclass
class FilteringStatus:
    """Tracks filtering operation state across all frames."""

    ranges_not_in_system: List[ResidueRange] = field(default_factory=list)
    ranges_with_no_matches: List[Tuple[str, ResidueRange]] = field(default_factory=list)
    frames_processed: int = 0
    total_rows_removed: int = 0


RESIDUE_RANGES_HELP = """\
Residue range specifications to filter loop rows.

Formats:
    A:1..10       - chain A residues 1 to 10 (inclusive)
    B:5           - chain B residue 5
    :1..20        - residues 1 to 20 across all chains
    A+B:10..20    - chains A and B residues 10 to 20
    A:1..10+20..30- multiple residue ranges in chain A
    A:10..        - chain A from residue 10 to the end
    A:..20        - chain A from the start to residue 20

Multiple ranges can be specified as separate arguments or separated by commas:
    A:1..10 B:20..30
    A:1..10,B:20..30

Note: Use '+' to combine multiple chains or multiple ranges within a single 
specification (e.g., A+B:1..10 or A:1..10+20..30).

Chain codes and residue numbers can be combined with '+' and ranges with '..'.
Negative residue numbers are supported (e.g., A:-10..-5).
String residue codes (e.g., 10A) are supported but cannot be expanded for 
validation against the molecular system.
"""

RESIDUE_RANGES_ARG_HELP = (
    "Residue range specifications to filter (e.g. A:1..10). "
    "Use --help-residue-ranges for detailed syntax."
)

FRAMES_HELP = """\
    frames to process (comma-separated or repeated).
    Wildcards are allowed. Default: all frames with residue data.
"""

EXCLUDE_HELP = """\
    exclude frames matching these selectors from processing.
    Wildcards are allowed. Can be used with --frames to refine selection.
"""

INVERT_HELP = """\
    keep only matching rows instead of removing them
"""

RANGE_POLICY_HELP = """\
    policy for residue ranges not in molecular system [warn, error]
"""

NO_MATCH_POLICY_HELP = """\
    policy for residue ranges that match no rows [warn, error-immediate, error-collect]
"""

EXACT_HELP = """\
    match frame selectors exactly (no wildcards)
"""


@filter_app.command(name="residues")
def residues(
    residue_ranges: List[str] = typer.Argument(
        ...,
        help=RESIDUE_RANGES_ARG_HELP,
        metavar="<RESIDUE-RANGE>",
    ),
    input_path: Path = typer.Option(
        STDIN,
        "--in",
        "-i",
        metavar="|INPUT|",
        help="input to read NEF data from [stdin = -]",
    ),
    frame_selectors: List[str] = typer.Option(
        ["*"],
        "--frames",
        "-f",
        help=FRAMES_HELP,
    ),
    exclude_selectors: List[str] = typer.Option(
        [],
        "--exclude",
        "-x",
        help=EXCLUDE_HELP,
    ),
    invert: bool = typer.Option(
        False,
        "--invert",
        help=INVERT_HELP,
    ),
    residues_not_defined_policy: ResiduesNotDefinedPolicy = typer.Option(
        ResiduesNotDefinedPolicy.warn,
        "--range-policy",
        help=RANGE_POLICY_HELP,
    ),
    no_match_policy: NoMatchPolicy = typer.Option(
        NoMatchPolicy.warn,
        "--no-match-policy",
        help=NO_MATCH_POLICY_HELP,
    ),
    exact: bool = typer.Option(
        False,
        "--exact",
        help=EXACT_HELP,
    ),
    help_residue_ranges: Optional[bool] = typer.Option(
        None,
        "--help-residue-ranges",
        callback=help_residue_ranges_callback,
        is_eager=True,
        help="show detailed residue range help and exit",
    ),
):
    """- filter loop rows by residue ranges

    Remove rows matching specified residue ranges (default) or keep only matching
    rows (--invert). Processes all frames with residue data (chain_code and
    sequence_code columns) except nef_molecular_system frames.
    """

    entry = read_entry_from_file_or_stdin_or_exit_error(input_path)

    frame_selectors = parse_comma_separated_options(frame_selectors)
    exclude_selectors = parse_comma_separated_options(exclude_selectors)
    parsed_ranges = parse_residue_ranges(residue_ranges)

    # Frame selection
    if exact:
        selected_frames = list(select_frames_by_name(entry, frame_selectors, exact=True))
        if exclude_selectors:
            excluded_frames = set(select_frames_by_name(entry, exclude_selectors, exact=True))
            selected_frames = [f for f in selected_frames if f not in excluded_frames]
    else:
        selected_frames = select_frames(entry, frame_selectors)
        if exclude_selectors:
            excluded_frames = set(select_frames(entry, exclude_selectors))
            selected_frames = [f for f in selected_frames if f not in excluded_frames]

    frames_to_process = _filter_processable_frames(selected_frames)

    if not frames_to_process:
        warn("No frames with residue data found matching selectors")

    # Range validation
    if residues_not_defined_policy != ResiduesNotDefinedPolicy.quiet:
        missing_ranges = validate_residue_ranges_in_system(entry, parsed_ranges)
        for rrange in missing_ranges:
            msg = f"Residue range {format_residue_range(rrange)} not found in molecular system"
            if residues_not_defined_policy == ResiduesNotDefinedPolicy.error:
                exit_error(msg)
            else:
                warn(msg)

    # Filtering
    entry, context = pipe(
        entry,
        parsed_ranges,
        frames_to_process,
        invert,
        no_match_policy,
    )

    _report_filtering_results(context, no_match_policy)

    print(entry)


def pipe(
    entry: Entry,
    residue_ranges: List[ResidueRange],
    frames: List[Saveframe],
    invert: bool = False,
    no_match_policy: NoMatchPolicy = NoMatchPolicy.warn,
) -> Tuple[Entry, FilteringStatus]:
    """Filter loop rows by residue ranges.

    Args:
        entry: NEF entry to process
        residue_ranges: Parsed residue ranges to match
        frames: List of frames to process
        invert: If True, keep only matching rows; if False, remove matching rows
        no_match_policy: How to handle ranges matching no rows

    Returns:
        Modified entry and FilteringStatus object
    """

    context = FilteringStatus()

    for frame in frames:
        _filter_frame_loops(
            frame, residue_ranges, invert, no_match_policy, context
        )

    return entry, context

def _filter_processable_frames(frames: List[Saveframe]) -> List[Saveframe]:
    """Filter frames to only those with residue data (excluding molecular_system)."""

    result = []
    for frame in frames:
        if frame.category == NEF_MOLECULAR_SYSTEM:
            continue

        if _frame_has_residue_data(frame):
            result.append(frame)

    return result


def _frame_has_residue_data(frame: Saveframe) -> bool:
    """Check if frame contains loops with chain_code and sequence_code columns."""

    for loop in frame.loops:
        if loop_has_residue_columns(loop):
            return True

    return False


def _filter_frame_loops(
    frame: Saveframe,
    residue_ranges: List[ResidueRange],
    invert: bool,
    no_match_policy: NoMatchPolicy,
    context: FilteringStatus,
) -> None:
    """Filter all loops in a frame by residue ranges."""

    for loop in frame.loops:
        if not loop_has_residue_columns(loop):
            continue

        _filter_loop_rows(
            loop, frame.name, residue_ranges, invert, no_match_policy, context
        )

    context.frames_processed += 1


def _filter_loop_rows(
    loop: Loop,
    frame_name: str,
    residue_ranges: List[ResidueRange],
    invert: bool,
    no_match_policy: NoMatchPolicy,
    context: FilteringStatus,
) -> None:
    """Filter rows in a single loop."""

    tag_sets = find_residue_tag_sets(loop)

    matched_ranges = set()
    rows_to_remove = set()

    for row_index, row_dict in enumerate(loop_row_dict_iter(loop, convert=False)):
        row_matches = row_matches_any_range(
            row_dict, tag_sets, residue_ranges, matched_ranges
        )

        should_remove = row_matches if not invert else not row_matches

        if should_remove:
            rows_to_remove.add(row_index)

    for row_index in reversed(sorted(rows_to_remove)):
        del loop.data[row_index]

    context.total_rows_removed += len(rows_to_remove)

    unmatched = set(range(len(residue_ranges))) - matched_ranges
    for residue_range_index in unmatched:
        residue_range = residue_ranges[residue_range_index]
        context.ranges_with_no_matches.append((frame_name, residue_range))

        if no_match_policy == NoMatchPolicy.error_immediate:
            exit_error(
                f"Residue range {format_residue_range(residue_range)} matched no rows in frame {frame_name}"
            )


def _report_filtering_results(
    context: FilteringStatus,
    no_match_policy: NoMatchPolicy,
) -> None:
    """Report filtering statistics and handle errors."""

    if no_match_policy == NoMatchPolicy.quiet:
        return

    if context.ranges_with_no_matches:
        if no_match_policy == NoMatchPolicy.error_collect:
            msg_lines = ["The following residue ranges matched no rows:"]
            for frame_name, rrange in context.ranges_with_no_matches:
                msg_lines.append(f"  {format_residue_range(rrange)} in frame {frame_name}")
            exit_error("\n".join(msg_lines))
        elif no_match_policy == NoMatchPolicy.warn:
            for frame_name, rrange in context.ranges_with_no_matches:
                warn(
                    f"Residue range {format_residue_range(rrange)} matched no rows in frame {frame_name}"
                )
