import typer

from nef_pipelines import nef_app
from nef_pipelines.lib.typer_lib import FilteredHelpGroup

filter_app = typer.Typer()

if nef_app.app:
    nef_app.app.add_typer(
        filter_app,
        name="filter",
        help="- filter NEF data by various criteria [residues]",
        rich_help_panel="NEF manipulation",
        no_args_is_help=True,
        cls=FilteredHelpGroup,
    )

    import nef_pipelines.tools.filter.residues  # noqa: F401
