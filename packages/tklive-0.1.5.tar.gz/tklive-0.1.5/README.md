# tklive

Live hot-reload for tkinter and customtkinter apps.  
Save your file → UI updates instantly without closing the window.

## Installation

```bash
pip install tklive
```

## Usage

Add **two lines** to your project:

```python
import tkinter as tk
from tklive import live

root = tk.Tk()

# ... your entire code stays exactly as it is ...

live(root, __file__)  # ← one line at the end
root.mainloop()
```

Save the file → UI reloads live. Or press **Ctrl+R** for manual reload.

## Features

- ✅ Window stays open – no restart
- ✅ State preservation (Entry, Text, Tabs, Scroll position, Window size)
- ✅ customtkinter support (CTkEntry, CTkTextbox, CTkSlider, CTkTabview ...)
- ✅ ttk support (Notebook, Treeview, Combobox ...)
- ✅ Multi-file support

## Watch multiple files

```python
live(root, __file__, watch_files=["ui.py", "components.py"])
```

## License

MIT
