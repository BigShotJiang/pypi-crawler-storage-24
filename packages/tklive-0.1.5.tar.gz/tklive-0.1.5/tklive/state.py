"""
Speichert und stellt Widget-Zustände wieder her.
Unterstützt: tkinter, ttk, customtkinter, ttkbootstrap
"""

import tkinter as tk

try:
    from tkinter import ttk
    HAS_TTK = True
except ImportError:
    HAS_TTK = False

try:
    import customtkinter as ctk
    HAS_CTK = True
except ImportError:
    HAS_CTK = False


def save_state(root: tk.Tk) -> dict:
    state = {
        "widgets": {},
        "window": {
            "geometry": root.geometry(),
            "title": root.title(),
        }
    }
    _collect(root, state["widgets"])
    return state


def restore_state(root: tk.Tk, state: dict):
    if not state:
        return

    # Fenstergröße und Position wiederherstellen
    if "window" in state:
        try:
            root.geometry(state["window"]["geometry"])
            root.title(state["window"]["title"])
        except Exception:
            pass

    if "widgets" in state:
        _apply(root, state["widgets"])


def _widget_key(widget) -> str:
    name = str(widget).split(".")[-1]
    return str(widget) if not name else f"{type(widget).__name__}:{str(widget)}"


def _collect(widget, state: dict):
    key = _widget_key(widget)

    try:
        # ── tkinter Standard ──────────────────────────────
        if isinstance(widget, tk.Entry):
            state[key] = ("entry", widget.get())

        elif isinstance(widget, tk.Text):
            state[key] = ("text", widget.get("1.0", tk.END), widget.yview()[0])

        elif isinstance(widget, tk.Scale):
            state[key] = ("scale", widget.get())

        elif isinstance(widget, tk.Spinbox):
            state[key] = ("spinbox", widget.get())

        elif isinstance(widget, tk.Listbox):
            selected = list(widget.curselection())
            scroll = widget.yview()[0]
            state[key] = ("listbox", selected, scroll)

        elif isinstance(widget, tk.BooleanVar):
            state[key] = ("boolvar", widget.get())

        elif isinstance(widget, (tk.Checkbutton, tk.Radiobutton)):
            try:
                var = widget.cget("variable")
                if var:
                    state[key] = ("varname", str(var))
            except Exception:
                pass

        # ── ttk ──────────────────────────────────────────
        if HAS_TTK:
            if isinstance(widget, ttk.Combobox):
                state[key] = ("combobox", widget.get())

            elif isinstance(widget, ttk.Entry):
                state[key] = ("entry", widget.get())

            elif isinstance(widget, ttk.Notebook):
                state[key] = ("notebook", widget.index("current"))

            elif isinstance(widget, ttk.Treeview):
                selected = widget.selection()
                state[key] = ("treeview", selected)

            elif isinstance(widget, ttk.Scale):
                state[key] = ("scale", widget.get())

            elif isinstance(widget, ttk.Spinbox):
                state[key] = ("spinbox", widget.get())

        # ── customtkinter ─────────────────────────────────
        if HAS_CTK:
            if isinstance(widget, ctk.CTkEntry):
                state[key] = ("ctk_entry", widget.get())

            elif isinstance(widget, ctk.CTkTextbox):
                state[key] = ("ctk_text", widget.get("1.0", tk.END))

            elif isinstance(widget, ctk.CTkComboBox):
                state[key] = ("ctk_combo", widget.get())

            elif isinstance(widget, ctk.CTkSlider):
                state[key] = ("ctk_slider", widget.get())

            elif isinstance(widget, ctk.CTkCheckBox):
                state[key] = ("ctk_check", widget.get())

            elif isinstance(widget, ctk.CTkSwitch):
                state[key] = ("ctk_switch", widget.get())

            elif isinstance(widget, ctk.CTkSegmentedButton):
                state[key] = ("ctk_segmented", widget.get())

            elif isinstance(widget, ctk.CTkTabview):
                try:
                    state[key] = ("ctk_tab", widget.get())
                except Exception:
                    pass

    except Exception:
        pass

    # Rekursiv durch alle Kinder
    try:
        children = widget.winfo_children()
    except Exception:
        children = []

    for child in children:
        _collect(child, state)


def _apply(widget, state: dict):
    key = _widget_key(widget)

    try:
        if key in state:
            entry = state[key]
            kind = entry[0]

            # ── tkinter Standard ──────────────────────────
            if kind == "entry" and isinstance(widget, tk.Entry):
                widget.delete(0, tk.END)
                widget.insert(0, entry[1])

            elif kind == "text" and isinstance(widget, tk.Text):
                widget.delete("1.0", tk.END)
                widget.insert("1.0", entry[1].rstrip("\n"))
                widget.yview_moveto(entry[2])

            elif kind == "scale" and isinstance(widget, tk.Scale):
                widget.set(entry[1])

            elif kind == "spinbox" and isinstance(widget, tk.Spinbox):
                widget.delete(0, tk.END)
                widget.insert(0, entry[1])

            elif kind == "listbox" and isinstance(widget, tk.Listbox):
                widget.selection_clear(0, tk.END)
                for i in entry[1]:
                    widget.selection_set(i)
                widget.yview_moveto(entry[2])

            # ── ttk ───────────────────────────────────────
            elif kind == "combobox" and HAS_TTK and isinstance(widget, ttk.Combobox):
                widget.set(entry[1])

            elif kind == "entry" and HAS_TTK and isinstance(widget, ttk.Entry):
                widget.delete(0, tk.END)
                widget.insert(0, entry[1])

            elif kind == "notebook" and HAS_TTK and isinstance(widget, ttk.Notebook):
                try:
                    widget.select(entry[1])
                except Exception:
                    pass

            elif kind == "treeview" and HAS_TTK and isinstance(widget, ttk.Treeview):
                try:
                    widget.selection_set(entry[1])
                except Exception:
                    pass

            elif kind == "scale" and HAS_TTK and isinstance(widget, ttk.Scale):
                widget.set(entry[1])

            elif kind == "spinbox" and HAS_TTK and isinstance(widget, ttk.Spinbox):
                widget.delete(0, tk.END)
                widget.insert(0, entry[1])

            # ── customtkinter ─────────────────────────────
            elif kind == "ctk_entry" and HAS_CTK and isinstance(widget, ctk.CTkEntry):
                widget.delete(0, tk.END)
                widget.insert(0, entry[1])

            elif kind == "ctk_text" and HAS_CTK and isinstance(widget, ctk.CTkTextbox):
                widget.delete("1.0", tk.END)
                widget.insert("1.0", entry[1].rstrip("\n"))

            elif kind == "ctk_combo" and HAS_CTK and isinstance(widget, ctk.CTkComboBox):
                widget.set(entry[1])

            elif kind == "ctk_slider" and HAS_CTK and isinstance(widget, ctk.CTkSlider):
                widget.set(entry[1])

            elif kind == "ctk_check" and HAS_CTK and isinstance(widget, ctk.CTkCheckBox):
                if entry[1]:
                    widget.select()
                else:
                    widget.deselect()

            elif kind == "ctk_switch" and HAS_CTK and isinstance(widget, ctk.CTkSwitch):
                if entry[1]:
                    widget.select()
                else:
                    widget.deselect()

            elif kind == "ctk_segmented" and HAS_CTK and isinstance(widget, ctk.CTkSegmentedButton):
                try:
                    widget.set(entry[1])
                except Exception:
                    pass

            elif kind == "ctk_tab" and HAS_CTK and isinstance(widget, ctk.CTkTabview):
                try:
                    widget.set(entry[1])
                except Exception:
                    pass

    except Exception:
        pass

    # Rekursiv durch alle Kinder
    try:
        children = widget.winfo_children()
    except Exception:
        children = []

    for child in children:
        _apply(child, state)
