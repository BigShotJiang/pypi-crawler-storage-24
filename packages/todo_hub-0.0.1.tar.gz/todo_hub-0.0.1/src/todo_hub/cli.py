def main():
    print("Package name reserved. CLI coming soon.")
