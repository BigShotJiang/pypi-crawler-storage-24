PATH_HEALTH = "/health"
PATH_FAVICON = "/favicon.ico"
PATH_ROBOTS = "/robots.txt"
PATH_OAUTH_AUTHORIZATION_SERVER = "/.well-known/oauth-authorization-server"
PATH_OAUTH_PROTECTED_RESOURCE = "/.well-known/oauth-protected-resource"
PATH_OAUTH_OPENID_CONFIGURATION = "/.well-known/openid-configuration"
PATH_MCP_SERVER_CARD = "/.well-known/mcp/server-card.json"
PATH_OAUTH_REGISTER = "/register"

PUBLIC_PATHS = {
    PATH_OAUTH_AUTHORIZATION_SERVER,
    PATH_OAUTH_PROTECTED_RESOURCE,
    PATH_OAUTH_OPENID_CONFIGURATION,
    PATH_OAUTH_REGISTER,
    PATH_MCP_SERVER_CARD,
    PATH_HEALTH,
    PATH_FAVICON,
    PATH_ROBOTS,
}
