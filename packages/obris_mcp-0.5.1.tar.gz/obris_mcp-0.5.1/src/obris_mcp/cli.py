"""Unified CLI entry point for the Obris MCP server."""

import argparse

TRANSPORT_STDIO = "stdio"
TRANSPORT_HTTP = "streamable-http"


def main():
    parser = argparse.ArgumentParser(
        prog="obris-mcp",
        description="Obris MCP server",
    )
    parser.add_argument(
        "--transport",
        choices=[TRANSPORT_STDIO, TRANSPORT_HTTP],
        default=TRANSPORT_STDIO,
        help=f"Transport mode (default: {TRANSPORT_STDIO})",
    )
    args = parser.parse_args()

    if args.transport == TRANSPORT_STDIO:
        from .local.server import main as run_stdio

        run_stdio()
    else:
        from .remote.run import main as run_remote

        run_remote()


if __name__ == "__main__":
    main()
