from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass


@dataclass
class ApiClient:
    get: Callable
    post: Callable
    patch: Callable
