# Asari utils will be a catchall for reused code that doesn't fit into a specific class
# this should be importable in other code in related tools. This should be cleaner than
# having a dedicated util file in each tool and honeslty, if you have the other tools 
# installed, you probalby have asari too. 

import multiprocessing as mp
import os
import time
import hashlib
import zipfile
from io import BytesIO
from importlib import resources as pkg_resources

import json
import requests
import pandas as pd

# will make matplotlib optional 
import matplotlib.pyplot as plt
# import seaborn as sns
import numpy as np
import pymzml
import tqdm


class NpEncoder(json.JSONEncoder):
    '''
    To handle numpy data types in JSON, using
    Jie Young's solution at StackOverflow:
    https://stackoverflow.com/questions/50916422/python-typeerror-object-of-type-int64-is-not-json-serializable

    Will change to use json_tricks
    '''
    def default(self, obj):
        '''
        This function converts obj into something that can be serialized by JSON, largely for 
        handling numpy datatypes that, despite being largely equivalent to their pure python
        equivalents, cannot be serialized. 

        Parameters
        ----------
        obj: np.integer or np.floating or np.ndarray or other serializable object instance
            for the numpy objects above, they are cast to their python 'equivalents', i.e., 
            np.integer -> int, np.floating -> float, np.ndarray -> list, else, the object
            is converted to its default serialization representation.
        '''
        
        if isinstance(obj, np.integer):
            return int(obj)
        if isinstance(obj, np.floating):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        return super(NpEncoder, self).default(obj)


def download_and_unzip_to_pkg_resources(url, package, subdir="data"):
    """Downloads a ZIP archive from a URL and extracts it into a package's resource directory."""
    print("HERE")
    # Get the package directory
    package_dir = os.path.dirname(pkg_resources.files(package))
    
    # Target extraction directory within the package
    extract_to = os.path.join(package_dir, subdir)
    os.makedirs(extract_to, exist_ok=True)  # Ensure the directory exists

    # Download the ZIP file
    response = requests.get(url, stream=True)
    response.raise_for_status()

    # Extract the ZIP archive to the target directory
    with zipfile.ZipFile(BytesIO(response.content)) as zip_ref:
        zip_ref.extractall(extract_to)

    print(f"Extracted to: {extract_to}")

def download_and_unzip(url, extract_to):
    """Downloads a ZIP archive from a URL and extracts it to the specified directory."""
    response = requests.get(url, stream=True)
    response.raise_for_status()  # Raise an error for bad responses

    with zipfile.ZipFile(BytesIO(response.content)) as zip_ref:
        zip_ref.extractall(extract_to)

    print(f"Extracted to: {extract_to}")

def plot_correlations(feature_table_path):
    ft = pd.read_csv(feature_table_path, sep='\t')
    ft["sum_intensity_max"] = np.log2(ft.iloc[:, 11:]+1).max(axis=1)
    ft["sum_intensity_mean"] = np.log2(ft.iloc[:, 11:]+1).mean(axis=1)
    ft["sum_intensity_median"] = np.log2(ft.iloc[:, 11:]+1).median(axis=1)
    ft["sum_intensity_min"] = np.log2(ft.iloc[:, 11:]+1).min(axis=1)
    ft["peak_area"] = np.log2(ft["peak_area"]+1)

    fig, axs = plt.subplots(2, 2, figsize=(15, 10))

    # Max
    print("max")
    axs[0, 0].scatter(ft["sum_intensity_max"], ft["peak_area"])
    sns.regplot(x=ft["sum_intensity_max"], y=ft["peak_area"], scatter=False, color='blue', robust=True, ax=axs[0, 0])
    r2_value_max = round(np.corrcoef(ft['sum_intensity_max'], ft['peak_area'])[0, 1]**2, 2)
    axs[0, 0].set_title(f"max vs peak_area (R2 = {r2_value_max})")
    axs[0, 0].set_xlabel("max")
    axs[0, 0].set_ylabel("peak_area")

    # Mean
    print("mean")
    axs[0, 1].scatter(ft["sum_intensity_mean"], ft["peak_area"])
    sns.regplot(x=ft["sum_intensity_mean"], y=ft["peak_area"], scatter=False, color='blue', robust=True, ax=axs[0, 1])
    r2_value_mean = round(np.corrcoef(ft['sum_intensity_mean'], ft['peak_area'])[0, 1]**2, 2)
    axs[0, 1].set_title(f"mean vs peak_area (R2 = {r2_value_mean})")
    axs[0, 1].set_xlabel("mean")
    axs[0, 1].set_ylabel("peak_area")

    # Median
    print("median")
    axs[1, 0].scatter(ft["sum_intensity_median"], ft["peak_area"])
    sns.regplot(x=ft["sum_intensity_median"], y=ft["peak_area"], scatter=False, color='blue', robust=True, ax=axs[1, 0])
    r2_value_median = round(np.corrcoef(ft['sum_intensity_median'], ft['peak_area'])[0, 1]**2, 2)
    axs[1, 0].set_title(f"median vs peak_area (R2 = {r2_value_median})")
    axs[1, 0].set_xlabel("median")
    axs[1, 0].set_ylabel("peak_area")

    # Min
    print("min")
    axs[1, 1].scatter(ft["sum_intensity_min"], ft["peak_area"])
    sns.regplot(x=ft["sum_intensity_min"], y=ft["peak_area"], scatter=False, color='blue', robust=True, ax=axs[1, 1])
    r2_value_min = round(np.corrcoef(ft['sum_intensity_min'], ft['peak_area'])[0, 1]**2, 2)
    axs[1, 1].set_title(f"min vs peak_area (R2 = {r2_value_min})")
    axs[1, 1].set_xlabel("min")
    axs[1, 1].set_ylabel("peak_area")

    # Adjust layout
    plt.tight_layout()
    plt.show()

def validate_mzml_file(file):
    try:
        with pymzml.run.Reader(file) as reader:
            for spec in reader:
                pass
    except:
        return False
    return True

def build_boolean_dict():
    return {
        'T': True, 
        'F': False, 
        1: True, 
        0: False, 
        'True': True, 
        'False': False, 
        'TRUE': True, 
        'FALSE': False, 
        'true': True, 
        'false': False
    }

def sizeof_fmt(num, suffix="B"):
    for unit in ("", "Ki", "Mi", "Gi", "Ti", "Pi", "Ei", "Zi"):
        if abs(num) < 1024.0:
            return f"{num:3.1f}{unit}{suffix}"
        num /= 1024.0
    return f"{num:.1f}Yi{suffix}"

def checksum_file(file, chunksize=16384):
    assert os.path.isfile(file)
    hash_md5 = hashlib.md5()
    with open(file, 'rb') as f:
        for chunk in iter(lambda: f.read(chunksize), b''):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()

def wait_with_pbar(wait=5):
    for _ in tqdm.tqdm(range(wait), total=wait, desc="waiting..."):
        time.sleep(1)

def get_ionization_mode_mzml(mzml_file, limit=50):
    ion_modes = set()
    i = 0
    with pymzml.run.Reader(mzml_file.path) as reader:
        for spec in reader:
            i += 1
            assert 'positive scan' in spec or 'negative scan' in spec
            if spec['positive scan']:
                ion_modes.add("pos")
            else:
                ion_modes.add("neg")
            if len(ion_modes) > 1:
                return "mixed"
            if i > limit:
                break
    return list(ion_modes)[0]

def bulk_process(command, arguments, dask_ip=None, jobs_per_worker=False, job_multiplier=1):
    if arguments:
        if dask_ip:
            try:
                from dask.distributed import Client, as_completed, progress
            except:
                raise ImportError("Dask must be installed to use dask_ip=True")
            client = Client(f"tcp://{dask_ip}:8786")
            client.scatter(arguments)
            client.scatter(command)
            results = []
            if jobs_per_worker == 'auto':
                total_thread = sum(worker_info['nthreads'] for worker_info in client.scheduler_info()['workers'].values())
                total_workers = len(client.scheduler_info()['workers'])
                jobs_per_worker = total_thread // total_workers * job_multiplier
            if jobs_per_worker:
                pbar = tqdm.tqdm(total=len(arguments), desc="processing...")

                # Submit initial batch of jobs
                futures = {i: client.submit(command, arg) for i, arg in enumerate(arguments[:len(client.scheduler_info()['workers']) * int(jobs_per_worker)])}
                remaining_args = arguments[len(futures):]

                # Process jobs as they complete and submit new ones
                for _ in range(len(arguments)):
                    completed_future = as_completed(futures.values()).next()
                    completed_index = list(futures.keys())[list(futures.values()).index(completed_future)]
                    pbar.update(1)
                    results.append((completed_index, completed_future.result()))
                    del futures[completed_index]
                    if remaining_args:
                        new_index = len(arguments) - len(remaining_args)
                        new_future = client.submit(command, remaining_args.pop(0))
                        futures[new_index] = new_future

                # Gather any remaining results
                if futures:
                    for future in futures.values():
                        pbar.update(1)
                        results.append((list(futures.keys())[list(futures.values()).index(future)], future.result()))

                # Sort results by original order
                results.sort(key=lambda x: x[0])
                return [result for _, result in results]
            else:
                # Default behavior: Submit all jobs at once
                futures = client.map(command, arguments)
                
                # Optionally show progress
                progress(futures)
                
                # Gather results once all tasks have completed
                return [x for x in client.gather(futures)]
        else:
            if jobs_per_worker and jobs_per_worker != 'auto':
                with mp.Pool(jobs_per_worker) as client:
                    pbar = tqdm.tqdm(client.imap(command, arguments), total=len(arguments), desc="processing...")
                    return [x for x in pbar]
            with mp.Pool(mp.cpu_count()) as client:
                pbar = tqdm.tqdm(client.imap(command, arguments), total=len(arguments), desc="processing...")
                return [x for x in pbar]
    else:
        raise Exception("No Arguments Provided")
    
def pca_ftable(tsv_path):
    import pandas as pd
    from sklearn.decomposition import PCA
    from sklearn.preprocessing import StandardScaler
    import matplotlib.pyplot as plt
    import seaborn as sns
    import numpy as np

    # Load the feature table
    ftable = pd.read_csv(tsv_path, sep='\t')
    pca = PCA(n_components=2)
    results = pca.fit_transform(StandardScaler().fit_transform(ftable.iloc[:, 11:].T))
    for i, (x, y) in enumerate(results):
        plt.scatter(x, y, label=ftable.columns[11:][i])
    plt.xlabel("PC1")
    plt.ylabel("PC2")
    plt.legend()
