# Contributing

Thanks for contributing to `fuggers-py`.

## Development setup

```bash
python -m pip install -e ".[dev,engine]"
pre-commit install
```

The repository uses a `src/` layout. Most day-to-day work should happen against the editable install above.

## Fast local checks

Run these before opening or updating a pull request:

```bash
pre-commit run --all-files
python tools/run_release_ruff.py
mypy
pytest -q
```

`pre-commit` is the fast path for file hygiene and Ruff checks. The explicit Ruff, mypy, and pytest commands remain the canonical CI gates.

## Pull request expectations

- Keep changes focused and explain the user-facing impact.
- Add or update tests when behavior, public surface, packaging, or docs examples change.
- Update `README.md`, `docs/`, and `CHANGELOG.md` when they would otherwise become stale.
- Avoid broad refactors unless they are required for the task at hand.

## Release process

See [RELEASING.md](RELEASING.md) for the exact tag-driven release steps.

## Reporting problems

- Security issues: follow [SECURITY.md](SECURITY.md).
- Community expectations: follow [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md).
