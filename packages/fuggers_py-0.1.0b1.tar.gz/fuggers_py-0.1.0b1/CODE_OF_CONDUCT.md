# Code of Conduct

## Our Pledge

We as maintainers and contributors pledge to make participation in the `fuggers-py` community a harassment-free experience for everyone, regardless of age, body size, disability, ethnicity, gender identity and expression, level of experience, education, socioeconomic status, nationality, personal appearance, race, religion, or sexual identity and orientation.

We pledge to act and interact in ways that contribute to an open, welcoming, diverse, inclusive, and healthy community.

## Our Standards

Examples of behavior that contributes to a positive environment include:

- Being respectful of differing viewpoints and experiences.
- Giving and accepting constructive feedback.
- Taking responsibility for mistakes and learning from them.
- Focusing on what is best for the project and its users.

Examples of unacceptable behavior include:

- Harassment, insults, or discriminatory language.
- Trolling, personal or political attacks, or sustained disruption.
- Publishing private information without explicit permission.
- Any conduct that would be inappropriate in a professional setting.

## Enforcement Responsibilities

Project maintainers are responsible for clarifying and enforcing this Code of Conduct. They may remove, edit, or reject comments, commits, code, wiki edits, issues, and other contributions that are not aligned with this Code of Conduct, and may temporarily or permanently ban contributors for behavior they deem inappropriate, threatening, offensive, or harmful.

## Scope

This Code of Conduct applies within all project spaces and when an individual is officially representing the project in public spaces.

## Enforcement

Instances of abusive, harassing, or otherwise unacceptable behavior may be reported to the maintainer at `skubik234@icloud.com`. Reports will be reviewed and investigated promptly and fairly.

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant](https://www.contributor-covenant.org/), version 2.1.
