# Security Policy

## Supported Versions

Security fixes are applied to the latest released version on PyPI and, when needed, to the current default branch.

## Reporting a Vulnerability

Please do not open public GitHub issues for suspected vulnerabilities.

Report security issues to `skubik234@icloud.com` with:

- a short description of the issue
- affected versions or commit range
- reproduction steps or a proof of concept
- any suggested mitigations if you have them

The maintainer will acknowledge receipt, investigate, and coordinate a fix and disclosure timeline.
