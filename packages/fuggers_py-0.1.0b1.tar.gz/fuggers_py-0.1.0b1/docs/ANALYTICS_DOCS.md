# Analytics Docs

`fuggers_py.analytics` provides bond and curve analytics on top of the core domain layers.

## Main areas

- pricing: price from yield, price from curve, yield from price
- yield analytics: current yield, simple yield, yield conventions, short-date helpers
- risk analytics: duration, convexity, DV01, CS01, key-rate helpers
- spread analytics: z-spread, g-spread, i-spread, OAS, discount margin, asset swap
- YAS-style reporting helpers

## Example

```python
from decimal import Decimal

from fuggers_py.analytics import calculate_modified_duration, yield_to_maturity
from fuggers_py.bonds import FixedBondBuilder
from fuggers_py.core import Currency, Date, Frequency, Price

settlement = Date.from_ymd(2026, 1, 15)
bond = (
    FixedBondBuilder.new()
    .with_issue_date(Date.from_ymd(2024, 1, 15))
    .with_maturity_date(Date.from_ymd(2031, 1, 15))
    .with_coupon_rate(Decimal("0.0450"))
    .with_frequency(Frequency.SEMI_ANNUAL)
    .with_currency(Currency.USD)
    .build()
)
price = Price.new(Decimal("101.25"), Currency.USD)

ytm = yield_to_maturity(bond, price, settlement)
duration = calculate_modified_duration(bond, ytm, settlement)
```

## Guidance

- Prefer one canonical implementation per calculation path.
- Import specialized analytics exceptions from `fuggers_py.analytics.errors`.
- Import specialized spread and yield helpers from their submodules when that makes call sites clearer.
