# Portfolio Docs

`fuggers_py.portfolio` contains aggregate analytics and portfolio workflows.

## Main areas

- aggregate portfolio metrics
- benchmark comparison and active weights
- contribution and attribution analysis
- liquidity and stress testing
- ETF NAV, basket, premium/discount, SEC-yield helpers
- typed public result records for portfolio-level outputs

## Example

```python
from fuggers_py.core import Currency
from fuggers_py.portfolio import Portfolio

portfolio = Portfolio.new([], Currency.USD)
```

## Guidance

- Prefer `fuggers_py.portfolio.risk` for typed risk, yield, spread, and credit summary records.
- Use `fuggers_py.portfolio.analytics.*` for narrow helper functions that intentionally return simple scalar values.
