# IO Docs

`fuggers_py.io` contains adapter code for persisted market and reference data.

## Modules

- `io.file`: file-backed market-data and reference-data loaders
- `io.json_codec`: JSON serialization helpers
- `io.sqlite_storage`: SQLite-backed storage
- `io.portfolio_store`: portfolio persistence helpers
- `io.storage`: storage interfaces
- `io.transport`: transport interfaces

## Example

```python
from decimal import Decimal

from fuggers_py.core import Date
from fuggers_py.data import PortfolioId
from fuggers_py.io import JsonCodec, StoredPortfolio, StoredPosition

portfolio = StoredPortfolio(
    portfolio_id=PortfolioId("demo-portfolio"),
    positions=(StoredPosition("US912797FJ15", quantity=Decimal("100")),),
    as_of=Date.from_ymd(2026, 3, 13),
)

payload = JsonCodec().encode(portfolio)
restored = JsonCodec().decode(payload)

assert restored == portfolio
```

## Guidance

- `io` is the adapter layer for local files and storage systems.
- Build engine workflows on top of `data` plus `io`, not through compatibility namespaces.
