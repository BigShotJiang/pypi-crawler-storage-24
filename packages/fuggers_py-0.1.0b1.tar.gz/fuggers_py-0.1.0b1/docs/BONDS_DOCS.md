# Bonds Docs

`fuggers_py.bonds` contains bond instruments, schedules, conventions, and instrument-level pricing helpers.

## Main areas

- instruments: fixed-rate, zero-coupon, callable, floating-rate, sinking-fund
- cash-flow generation and accrued-interest helpers
- conventions, identifiers, and yield rules
- option models and bond option helpers
- pricing and risk helper objects

## Example

```python
from decimal import Decimal

from fuggers_py.bonds import FixedBondBuilder
from fuggers_py.core import Currency, Date, Frequency

bond = (
    FixedBondBuilder.new()
    .with_issue_date(Date.from_ymd(2024, 1, 15))
    .with_maturity_date(Date.from_ymd(2031, 1, 15))
    .with_coupon_rate(Decimal("0.0450"))
    .with_frequency(Frequency.SEMI_ANNUAL)
    .with_currency(Currency.USD)
    .build()
)
```

## Guidance

- Import instrument types from `fuggers_py.bonds` or `fuggers_py.bonds.instruments`.
- Shared bond-related enums used by higher layers belong in `fuggers_py.bonds.types`.
- Root bond imports expose yield helpers without requiring the analytics layer at import time.
- Keep market/reference inputs outside the bond layer; those belong in `fuggers_py.data`.
