# Data Docs

`fuggers_py.data` contains research-facing identifiers, records, and provider shapes.

## Modules

- `data.ids`: instrument, curve, node, and portfolio identifiers
- `data.market_data`: quotes, curve inputs, fixings, in-memory providers
- `data.reference_data`: bond reference records and reference providers
- `data.pricing_specs`: pricing directives and configuration records
- `data.output`: typed pricing and analytics output records
- `data.errors`: data-layer exceptions

## Example

```python
from decimal import Decimal

from fuggers_py.bonds.types import ASWType
from fuggers_py.core import Date
from fuggers_py.data import CurveInputs, CurvePoint, PricingSpec

curve_inputs = CurveInputs.from_points(
    "usd.discount",
    Date.from_ymd(2026, 1, 15),
    [CurvePoint(Decimal("1.0"), Decimal("0.0350")), CurvePoint(Decimal("5.0"), Decimal("0.0385"))],
)
spec = PricingSpec(include_asset_swap=True, asset_swap_type=ASWType.PROCEEDS)
```

## Guidance

- Use `data` for typed records and providers.
- `PricingSpec` uses lower-layer shared enums such as `fuggers_py.bonds.types.ASWType` rather than importing analytics modules.
- Prefer explicit exception names such as `TraitTimeoutError`, `TraitIOError`, and `PermissionDeniedError`.
- Keep storage and transport concerns in `fuggers_py.io`.
