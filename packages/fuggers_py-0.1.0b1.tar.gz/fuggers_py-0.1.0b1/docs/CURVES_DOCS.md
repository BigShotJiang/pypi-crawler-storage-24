# Curves Docs

`fuggers_py.curves` contains term-structure models and calibration helpers.

## Main areas

- discount and credit curves
- curve builders and interpolation choices
- bumping and scenario utilities
- multicurve environments and rate indexes
- global fitting and parametric calibration

## Example

```python
from decimal import Decimal

from fuggers_py.core import Date
from fuggers_py.curves import DiscountCurveBuilder

curve = (
    DiscountCurveBuilder(reference_date=Date.from_ymd(2026, 1, 15))
    .add_zero_rate(1.0, Decimal("0.0350"))
    .add_zero_rate(5.0, Decimal("0.0385"))
    .build()
)
```

## Guidance

- Keep explicit curve construction in `fuggers_py.curves`.
- Treat conversion, calibration, and bumping as curve-layer concerns rather than generic helpers.
