# Core Docs

`fuggers_py.core` contains the primitive types and conventions used across the library.

## Main modules

- `core.types`: `Date`, `Currency`, `Frequency`, `Compounding`, `Price`, `Yield`, `Spread`, cash-flow primitives
- `core.daycounts`: day-count conventions and implementations
- `core.calendars`: holiday calendars, joint calendars, dynamic calendars
- `core.errors`: `FuggersError` and domain-specific subclasses
- `core.traits`: base interfaces for curves, pricing engines, and related abstractions

## Example

```python
from decimal import Decimal

from fuggers_py.core import Compounding, Currency, Date, Price, Yield

settlement = Date.from_ymd(2026, 1, 15)
clean_price = Price.new(Decimal("99.125"), Currency.USD)
ytm = Yield.new(Decimal("0.045"), Compounding.SEMI_ANNUAL)
```

## Design notes

- Core types are small value objects used throughout bonds, curves, analytics, and portfolio workflows.
- Calendars and day counts live here so pricing code can share the same conventions.
- Exceptions are raised directly; result-wrapper containers are not part of the public API.
