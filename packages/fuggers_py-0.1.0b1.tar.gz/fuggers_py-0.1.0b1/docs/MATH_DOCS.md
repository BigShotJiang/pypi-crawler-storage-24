# Math Docs

`fuggers_py.math` provides the numerical building blocks used by the fixed-income stack.

## Contents

- root finders: bisection, secant, Newton, Brent, hybrid solvers
- interpolation: linear, log-linear, cubic spline, flat-forward, monotone-convex, parametric curves
- extrapolation helpers
- optimization helpers
- small linear-algebra utilities

## Example

```python
from fuggers_py.math import BrentSolver, SolverConfig

solver = BrentSolver(config=SolverConfig(tolerance=1e-10, max_iterations=100))
root = solver.find_root(lambda x: x * x - 2.0, 0.0, 2.0)
```

## Guidance

- Import directly from `fuggers_py.math`.
- Use these utilities from curves and analytics code instead of reaching into lower-level helper modules.
