# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.19.1
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# %% [markdown]
# # Tutorial: fuggers_py.analytics.yas examples
#
# This notebook demonstrates yield-and-spread (YAS) analytics for a Boeing-style
# reference bond.

# %%
# Setup cell
from __future__ import annotations

import sys
from decimal import Decimal
from pathlib import Path

root = Path.cwd()
if (root / "src").exists():
    sys.path.insert(0, str(root / "src"))
elif (root.parent / "src").exists():
    sys.path.insert(0, str(root.parent / "src"))

# %% [markdown]
# ## Imports

# %%
from fuggers_py.analytics.spreads import BenchmarkSpec, GovernmentCurve  # noqa: E402
from fuggers_py.analytics.yas import YASCalculator  # noqa: E402
from fuggers_py.bonds.instruments import FixedBondBuilder  # noqa: E402
from fuggers_py.bonds.types import Tenor, YieldCalculationRules  # noqa: E402
from fuggers_py.curves import DiscountCurveBuilder  # noqa: E402
from fuggers_py.core import Currency, Date, Frequency, Price  # noqa: E402

# %% [markdown]
# ## Boeing 7.5% 06/15/2025 bond

# %%
issue = Date.from_ymd(2015, 6, 15)
maturity = Date.from_ymd(2025, 6, 15)

bond = (
    FixedBondBuilder.new()
    .with_issue_date(issue)
    .with_maturity_date(maturity)
    .with_coupon_rate(Decimal("0.075"))
    .with_frequency(Frequency.SEMI_ANNUAL)
    .with_currency(Currency.USD)
    .with_rules(YieldCalculationRules.us_corporate())
    .build()
)

# %% [markdown]
# ## Build a simple curve

# %%
settlement = Date.from_ymd(2020, 6, 15)
curve_builder = DiscountCurveBuilder(reference_date=settlement)
curve_builder.add_zero_rate(1.0, Decimal("0.03")).add_zero_rate(10.0, Decimal("0.03"))
curve = curve_builder.build()

gov_curve = GovernmentCurve.us_treasury(settlement)
gov_curve.add_benchmark(Tenor.parse("2Y"), Decimal("0.02"))
gov_curve.add_benchmark(Tenor.parse("5Y"), Decimal("0.03"))
gov_curve.add_benchmark(Tenor.parse("10Y"), Decimal("0.04"))

# %% [markdown]
# ## Run YAS

# %%
price = Price.new(Decimal("110.503"), bond.currency())
calc = YASCalculator(curve=curve, government_curve=gov_curve, benchmark=BenchmarkSpec.nearest())
analysis = calc.calculate(bond, price, settlement)
analysis

# %% [markdown]
# ## Yield metrics

# %%
analysis.street_yield, analysis.true_yield, analysis.current_yield, analysis.simple_yield

# %% [markdown]
# ## Spread metrics

# %%
analysis.g_spread_bps, analysis.z_spread_bps, analysis.benchmark_spread_bps, analysis.benchmark_tenor

# %% [markdown]
# ## Risk metrics

# %%
analysis.modified_duration(), analysis.convexity(), analysis.dv01()

# %% [markdown]
# ## Settlement invoice

# %%
analysis.invoice
