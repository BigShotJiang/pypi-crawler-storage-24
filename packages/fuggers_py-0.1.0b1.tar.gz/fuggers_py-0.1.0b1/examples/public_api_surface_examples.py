# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.19.1
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# %% [markdown]
# # Tutorial: public package surface examples
#
# This notebook demonstrates:
#
# - Explicit imports from the canonical package layout
# - A simple deterministic workflow using the Python-native surface
# - Canonical spread analytics imports from `fuggers_py.analytics.spreads`

# %%
from __future__ import annotations

import sys
from decimal import Decimal
from pathlib import Path

root = Path.cwd()
if (root / "src").exists():
    sys.path.insert(0, str(root / "src"))
elif (root.parent / "src").exists():
    sys.path.insert(0, str(root.parent / "src"))

# %% [markdown]
# ## Canonical imports

# %%
from fuggers_py.analytics import yield_to_maturity  # noqa: E402
from fuggers_py.bonds import FixedBondBuilder  # noqa: E402
from fuggers_py.core import Currency, Date, Frequency, Price  # noqa: E402
from fuggers_py.curves import CurveBuilder, RateCurve  # noqa: E402
from fuggers_py.data import InstrumentId  # noqa: E402
from fuggers_py.engine import PricingRouter  # noqa: E402
from fuggers_py.portfolio.portfolio import Portfolio  # noqa: E402

# %% [markdown]
# ## Build a small deterministic workflow

# %%
reference_date = Date.from_ymd(2024, 1, 2)

curve = (
    CurveBuilder.zero(reference_date)
    .add_zero_rate(1.0, Decimal("0.0350"))
    .add_zero_rate(5.0, Decimal("0.0375"))
    .build()
)

assert isinstance(curve, RateCurve)

# %%
bond = (
    FixedBondBuilder.new()
    .with_issue_date(Date.from_ymd(2020, 1, 15))
    .with_maturity_date(Date.from_ymd(2030, 1, 15))
    .with_coupon_rate(Decimal("0.045"))
    .with_frequency(Frequency.SEMI_ANNUAL)
    .with_currency(Currency.USD)
    .build()
)

clean_price = Price(Decimal("101.25"), Currency.USD)
ytm = yield_to_maturity(bond, clean_price, reference_date)

portfolio = Portfolio([], Currency.USD)
instrument_id = InstrumentId("UST-2030")
router = PricingRouter()

summary = {
    "reference_date": str(reference_date),
    "curve_type": type(curve).__name__,
    "yield_to_maturity": ytm.value(),
    "portfolio_currency": portfolio.currency.code(),
    "instrument_id": instrument_id.as_str(),
    "router_type": type(router).__name__,
}
print(summary)

# %% [markdown]
# ## Canonical spread imports from `fuggers_py.analytics.spreads`

# %%
from fuggers_py.analytics.spreads import OASCalculator, ParParAssetSwap, g_spread, z_spread  # noqa: E402

compatibility_summary = {
    "g_spread_bps": g_spread(Decimal("0.0470"), Decimal("0.0350")),
    "z_spread_symbol": z_spread.__name__,
    "asset_swap_symbol": ParParAssetSwap.__name__,
    "oas_calculator": OASCalculator.__name__,
}
print(compatibility_summary)
