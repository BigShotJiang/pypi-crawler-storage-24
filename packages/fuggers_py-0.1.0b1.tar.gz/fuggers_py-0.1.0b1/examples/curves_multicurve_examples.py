# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.19.1
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# %% [markdown]
# # Multi-curve environment
#
# Assemble discount and projection curves into a small research environment and
# query them by currency and index.

# %%
from __future__ import annotations

import sys
from decimal import Decimal
from pathlib import Path

root = Path.cwd()
if (root / "src").exists():
    sys.path.insert(0, str(root / "src"))
elif (root.parent / "src").exists():
    sys.path.insert(0, str(root.parent / "src"))

from fuggers_py.bonds.types import Tenor  # noqa: E402
from fuggers_py.core import Currency, Date  # noqa: E402
from fuggers_py.curves import CurrencyPair, MultiCurveEnvironmentBuilder, RateIndex, ZeroCurveBuilder  # noqa: E402


# %% [markdown]
# ## Build discount and projection curves

# %%
reference_date = Date.from_ymd(2024, 1, 2)
usd_discount = (
    ZeroCurveBuilder(reference_date=reference_date)
    .add_rate(reference_date.add_years(1), Decimal("0.045"))
    .add_rate(reference_date.add_years(5), Decimal("0.040"))
    .build()
)
eur_discount = (
    ZeroCurveBuilder(reference_date=reference_date)
    .add_rate(reference_date.add_years(1), Decimal("0.035"))
    .add_rate(reference_date.add_years(5), Decimal("0.032"))
    .build()
)
sofr_index = RateIndex.new("SOFR", Tenor.parse("3M"), Currency.USD)
euribor_index = RateIndex.new("EURIBOR", Tenor.parse("6M"), Currency.EUR)
sofr_projection = (
    ZeroCurveBuilder(reference_date=reference_date)
    .add_rate(reference_date.add_years(1), Decimal("0.048"))
    .add_rate(reference_date.add_years(5), Decimal("0.043"))
    .build()
)
euribor_projection = (
    ZeroCurveBuilder(reference_date=reference_date)
    .add_rate(reference_date.add_years(1), Decimal("0.038"))
    .add_rate(reference_date.add_years(5), Decimal("0.034"))
    .build()
)


# %% [markdown]
# ## Assemble and query the environment

# %%
environment = (
    MultiCurveEnvironmentBuilder()
    .add_discount_curve(Currency.USD, usd_discount)
    .add_discount_curve(Currency.EUR, eur_discount)
    .add_projection_curve(sofr_index, sofr_projection)
    .add_projection_curve(euribor_index, euribor_projection)
    .build()
)

snapshot = {
    "usd_discount_2y": environment.discount_curve(Currency.USD).discount_factor(reference_date.add_years(2)),
    "eur_discount_2y": environment.discount_curve(Currency.EUR).discount_factor(reference_date.add_years(2)),
    "sofr_forward_3m_6m": environment.projection_curve(sofr_index).forward_rate(
        reference_date.add_months(3),
        reference_date.add_months(6),
    ),
    "euribor_forward_6m_12m": environment.projection_curve(euribor_index).forward_rate(
        reference_date.add_months(6),
        reference_date.add_months(12),
    ),
}
snapshot

# %%
CurrencyPair(base=Currency.USD, quote=Currency.EUR).code()
