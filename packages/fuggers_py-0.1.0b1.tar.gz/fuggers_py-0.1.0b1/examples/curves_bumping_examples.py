# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.19.1
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# %% [markdown]
# # Curve bumping
#
# Compare parallel, key-rate, and scenario bumps on a simple USD discount curve.

# %%
from __future__ import annotations

import sys
from decimal import Decimal
from pathlib import Path

root = Path.cwd()
if (root / "src").exists():
    sys.path.insert(0, str(root / "src"))
elif (root.parent / "src").exists():
    sys.path.insert(0, str(root.parent / "src"))

from fuggers_py.bonds.types import Tenor  # noqa: E402
from fuggers_py.core import Date  # noqa: E402
from fuggers_py.curves import (  # noqa: E402
    DiscountCurveBuilder,
    KeyRateBump,
    ParallelBump,
    key_rate_profile,
    steepener_50bp,
)


# %% [markdown]
# ## Base curve

# %%
reference_date = Date.from_ymd(2024, 1, 2)
base_curve = (
    DiscountCurveBuilder(reference_date=reference_date)
    .add_zero_rate(0.5, Decimal("0.0450"))
    .add_zero_rate(2.0, Decimal("0.0430"))
    .add_zero_rate(5.0, Decimal("0.0410"))
    .add_zero_rate(10.0, Decimal("0.0425"))
    .build()
)

tenor_dates = {
    "2Y": reference_date.add_years(2),
    "5Y": reference_date.add_years(5),
    "10Y": reference_date.add_years(10),
}
{label: base_curve.zero_rate(date).value() for label, date in tenor_dates.items()}


# %% [markdown]
# ## Parallel and key-rate bumps

# %%
parallel_up = ParallelBump(0.0010).apply(base_curve)
key_rate_5y = KeyRateBump([Tenor.parse("2Y"), Tenor.parse("5Y"), Tenor.parse("10Y")], Tenor.parse("5Y"), 0.0010).apply(
    base_curve
)

{
    "base_5y": base_curve.zero_rate(tenor_dates["5Y"]).value(),
    "parallel_up_5y": parallel_up.zero_rate(tenor_dates["5Y"]).value(),
    "key_rate_5y_5y": key_rate_5y.zero_rate(tenor_dates["5Y"]).value(),
}


# %% [markdown]
# ## Scenario bump and standard key-rate profile

# %%
steepener = steepener_50bp().apply(base_curve)
scenario_snapshot = {
    label: {
        "base": base_curve.zero_rate(date).value(),
        "steepener": steepener.zero_rate(date).value(),
    }
    for label, date in tenor_dates.items()
}
scenario_snapshot

# %%
key_rate_profile(Tenor.parse("5Y"))
