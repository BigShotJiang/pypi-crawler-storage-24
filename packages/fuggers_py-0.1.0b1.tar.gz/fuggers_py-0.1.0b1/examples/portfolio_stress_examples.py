# ---
# jupyter:
#   jupytext:
#     formats: ipynb,py:percent
#     text_representation:
#       extension: .py
#       format_name: percent
#       format_version: '1.3'
#       jupytext_version: 1.19.1
#   kernelspec:
#     display_name: Python 3
#     language: python
#     name: python3
# ---

# %% [markdown]
# # Portfolio stress testing

# %%
from __future__ import annotations

import sys
from dataclasses import replace
from decimal import Decimal
from pathlib import Path

root = Path.cwd()
if (root / "src").exists():
    sys.path.insert(0, str(root / "src"))
elif (root.parent / "src").exists():
    sys.path.insert(0, str(root.parent / "src"))

from fuggers_py.bonds.instruments import FixedBond  # noqa: E402
from fuggers_py.bonds.types import CreditRating, Sector, YieldCalculationRules  # noqa: E402
from fuggers_py.core import Currency, Date, Frequency  # noqa: E402
from fuggers_py.curves import DiscountCurveBuilder  # noqa: E402
from fuggers_py.portfolio import (  # noqa: E402
    Classification,
    Holding,
    PortfolioBuilder,
    key_rate_shift_result,
    rate_shock_impact,
    run_stress_scenarios,
    spread_shock_result,
    standard_scenarios,
)


# %%
reference_date = Date.from_ymd(2024, 1, 2)
curve = (
    DiscountCurveBuilder(reference_date=reference_date)
    .add_zero_rate(0.5, Decimal("0.030"))
    .add_zero_rate(2.0, Decimal("0.033"))
    .add_zero_rate(5.0, Decimal("0.038"))
    .add_zero_rate(10.0, Decimal("0.041"))
    .build()
)

def make_holding(label: str, years: int, coupon: str, price: str, sector: Sector, rating: CreditRating) -> Holding:
    bond = FixedBond.new(
        issue_date=reference_date,
        maturity_date=reference_date.add_years(years),
        coupon_rate=Decimal(coupon),
        frequency=Frequency.ANNUAL,
        currency=Currency.USD,
        rules=replace(YieldCalculationRules.us_corporate(), frequency=Frequency.ANNUAL),
    )
    return Holding(
        id=label,
        instrument=bond,
        quantity=Decimal("100"),
        clean_price=Decimal(price),
        label=label,
        classification=Classification(sector=sector, rating=rating, currency=Currency.USD),
    )


portfolio = (
    PortfolioBuilder()
    .with_currency(Currency.USD)
    .add_holding(make_holding("gov_short", 2, "0.0325", "99.5", Sector.GOVERNMENT, CreditRating.AA))
    .add_holding(make_holding("corp_bbb", 5, "0.0500", "101.0", Sector.CORPORATE, CreditRating.BBB))
    .add_holding(make_holding("corp_bb", 8, "0.0625", "98.0", Sector.INDUSTRIALS, CreditRating.BB))
    .build()
)


# %% [markdown]
# ## Single-scenario impacts

# %%
parallel = rate_shock_impact(portfolio, curve=curve, settlement_date=reference_date, bump_bps=Decimal("10"))
spread = spread_shock_result(portfolio, curve=curve, settlement_date=reference_date, bump_bps=Decimal("25"))
key_rate = key_rate_shift_result(
    portfolio,
    curve=curve,
    settlement_date=reference_date,
    tenor_shocks_bps={"2Y": Decimal("10"), "10Y": Decimal("-5")},
)
{
    "parallel_change": parallel.actual_change,
    "spread_change": spread.actual_change,
    "key_rate_change": key_rate.actual_change,
}


# %% [markdown]
# ## Standard scenario runner

# %%
scenario_results = run_stress_scenarios(portfolio, curve=curve, settlement_date=reference_date, scenarios=standard_scenarios())
{name: result.actual_change for name, result in scenario_results.items()}
