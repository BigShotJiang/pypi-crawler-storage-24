"""Settlement helpers (`fuggers_py.bonds.cashflows.settlement`)."""

from __future__ import annotations

from dataclasses import dataclass

from fuggers_py.core.types import Date

from ..types import CalendarId, SettlementRules


@dataclass(frozen=True, slots=True)
class SettlementCalculator:
    calendar: CalendarId
    rules: SettlementRules

    def settlement_date(self, trade_date: Date) -> Date:
        cal = self.calendar.to_calendar()
        return self.rules.settlement_date(trade_date, cal)


__all__ = ["SettlementCalculator"]

