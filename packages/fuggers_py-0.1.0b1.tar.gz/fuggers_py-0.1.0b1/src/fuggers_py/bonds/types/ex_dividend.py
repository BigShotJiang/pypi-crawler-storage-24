"""Ex-dividend rules (`fuggers_py.bonds.types.ex_dividend`)."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ExDividendRules:
    ex_dividend_days: int = 0

    @classmethod
    def none(cls) -> "ExDividendRules":
        return cls(ex_dividend_days=0)

    @classmethod
    def uk_gilt(cls) -> "ExDividendRules":
        return cls(ex_dividend_days=7)


__all__ = ["ExDividendRules"]
