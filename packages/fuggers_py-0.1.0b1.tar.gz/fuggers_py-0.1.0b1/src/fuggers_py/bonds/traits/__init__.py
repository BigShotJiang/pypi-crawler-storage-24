"""Bond traits (`fuggers_py.bonds.traits`)."""

from __future__ import annotations

from .analytics import BondAnalytics
from .bond import Bond
from .cashflow import BondCashFlow, CashFlowType
from .instruments import (
    AmortizingBond,
    EmbeddedOptionBond,
    FixedCouponBond,
    FloatingCouponBond,
    InflationLinkedBond,
)

__all__ = [
    "CashFlowType",
    "BondCashFlow",
    "Bond",
    "BondAnalytics",
    "AmortizingBond",
    "EmbeddedOptionBond",
    "FixedCouponBond",
    "FloatingCouponBond",
    "InflationLinkedBond",
]
