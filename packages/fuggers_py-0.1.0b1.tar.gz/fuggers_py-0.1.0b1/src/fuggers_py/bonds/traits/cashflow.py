"""Bond cashflow primitives (`fuggers_py.bonds.traits.cashflow`)."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from enum import Enum

from fuggers_py.core.types import Date


class CashFlowType(str, Enum):
    COUPON = "COUPON"
    PRINCIPAL = "PRINCIPAL"
    COUPON_AND_PRINCIPAL = "COUPON_AND_PRINCIPAL"
    FEE = "FEE"


@dataclass(frozen=True, slots=True)
class BondCashFlow:
    date: Date
    amount: Decimal
    flow_type: CashFlowType
    accrual_start: Date | None = None
    accrual_end: Date | None = None
    factor: Decimal = Decimal(1)
    reference_rate: Decimal | None = None

    def is_coupon(self) -> bool:
        return self.flow_type in {CashFlowType.COUPON, CashFlowType.COUPON_AND_PRINCIPAL}

    def is_principal(self) -> bool:
        return self.flow_type in {CashFlowType.PRINCIPAL, CashFlowType.COUPON_AND_PRINCIPAL}

    def factored_amount(self) -> Decimal:
        return self.amount * self.factor


__all__ = ["CashFlowType", "BondCashFlow"]

