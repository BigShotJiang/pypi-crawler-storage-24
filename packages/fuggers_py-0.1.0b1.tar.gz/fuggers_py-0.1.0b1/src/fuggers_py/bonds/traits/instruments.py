"""Analytics-layer bond protocols."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from fuggers_py.core.types import Date

from ..types import AmortizationSchedule, InflationIndexType, PutSchedule, RateIndex


@runtime_checkable
class FixedCouponBond(Protocol):
    def coupon_rate(self):
        ...


@runtime_checkable
class FloatingCouponBond(Protocol):
    def index(self) -> RateIndex:
        ...

    def quoted_spread(self):
        ...

    def current_coupon_rate(self):
        ...


@runtime_checkable
class AmortizingBond(Protocol):
    def amortization_schedule(self) -> AmortizationSchedule:
        ...


@runtime_checkable
class EmbeddedOptionBond(Protocol):
    def yield_to_worst(self, clean_price: object, settlement_date: Date):
        ...

    def put_schedule(self) -> PutSchedule | None:
        ...


@runtime_checkable
class InflationLinkedBond(Protocol):
    def inflation_index_type(self) -> InflationIndexType:
        ...


__all__ = [
    "AmortizingBond",
    "EmbeddedOptionBond",
    "FixedCouponBond",
    "FloatingCouponBond",
    "InflationLinkedBond",
]
