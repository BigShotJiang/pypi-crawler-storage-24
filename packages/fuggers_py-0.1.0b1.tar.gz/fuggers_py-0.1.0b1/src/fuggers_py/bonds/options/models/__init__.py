"""Short-rate models for bond options."""

from __future__ import annotations

from .base import ModelError, ShortRateModel
from .hull_white import HullWhiteModel

HullWhite = HullWhiteModel

__all__ = ["HullWhite", "HullWhiteModel", "ModelError", "ShortRateModel"]
