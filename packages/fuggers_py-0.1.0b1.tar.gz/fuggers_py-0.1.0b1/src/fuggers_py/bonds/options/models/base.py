"""Short-rate model protocols and errors."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from fuggers_py.core.traits import YieldCurve
from fuggers_py.core.types import Date


@dataclass(frozen=True, slots=True)
class ModelError(Exception):
    reason: str

    def __str__(self) -> str:  # pragma: no cover - trivial
        return f"Model error: {self.reason}"


@runtime_checkable
class ShortRateModel(Protocol):
    term_structure: YieldCurve

    def base_forward_rate(self, start: Date, end: Date) -> float:
        ...

    def short_rate(self, date: Date) -> float:
        ...

    def node_rate(self, start: Date, end: Date, *, level: int, width: int) -> float:
        ...

    def discount(self, rate: float, dt: float, spread: float = 0.0) -> float:
        ...


__all__ = ["ModelError", "ShortRateModel"]
