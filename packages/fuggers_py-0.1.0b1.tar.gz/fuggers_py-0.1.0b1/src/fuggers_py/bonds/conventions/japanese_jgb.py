"""Japanese JGB conventions."""

from __future__ import annotations

from ..types import YieldCalculationRules


def japanese_jgb_rules() -> YieldCalculationRules:
    return YieldCalculationRules.japanese_jgb()


__all__ = ["japanese_jgb_rules"]
