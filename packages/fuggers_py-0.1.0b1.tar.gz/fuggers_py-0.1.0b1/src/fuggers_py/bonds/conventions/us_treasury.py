"""US Treasury conventions."""

from __future__ import annotations

from ..types import YieldCalculationRules


def us_treasury_rules() -> YieldCalculationRules:
    return YieldCalculationRules.us_treasury()


__all__ = ["us_treasury_rules"]
