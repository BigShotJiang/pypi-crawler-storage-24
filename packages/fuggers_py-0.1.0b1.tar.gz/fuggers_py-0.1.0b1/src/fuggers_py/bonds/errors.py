"""Bond-layer exceptions (`fuggers_py.bonds.errors`).

This module follows the style of `fuggers_py.math.errors`: bond-specific
validation and runtime failures should raise structured exceptions carrying
relevant payload.
"""

from __future__ import annotations

from dataclasses import dataclass

from fuggers_py.core.errors import FuggersError


class BondError(FuggersError):
    """Base exception for all `fuggers_py.bonds` errors."""

    @classmethod
    def invalid_spec(cls, reason: str) -> "InvalidBondSpec":
        return InvalidBondSpec(reason=reason)

    @classmethod
    def missing_field(cls, field: str) -> "MissingRequiredField":
        return MissingRequiredField(field=field)

    @classmethod
    def pricing_failed(cls, reason: str) -> "BondPricingError":
        return BondPricingError(reason=reason)


class IdentifierError(BondError):
    """Raised when an instrument identifier is invalid."""


@dataclass(frozen=True, slots=True)
class InvalidIdentifier(IdentifierError):
    identifier_type: str
    value: str
    reason: str

    def __str__(self) -> str:
        return f"Invalid {self.identifier_type}: {self.value!r} ({self.reason})."


@dataclass(frozen=True, slots=True)
class InvalidBondSpec(BondError):
    reason: str

    def __str__(self) -> str:  # pragma: no cover - trivial
        return f"Invalid bond spec: {self.reason}"


@dataclass(frozen=True, slots=True)
class MissingRequiredField(BondError):
    field: str

    def __str__(self) -> str:  # pragma: no cover - trivial
        return f"Missing required field: {self.field}"


@dataclass(frozen=True, slots=True)
class BondPricingError(BondError):
    reason: str

    def __str__(self) -> str:  # pragma: no cover - trivial
        return f"Bond pricing error: {self.reason}"


@dataclass(frozen=True, slots=True)
class YieldConvergenceFailed(BondError):
    iterations: int
    residual: float

    def __str__(self) -> str:
        return (
            f"Yield solver failed to converge after {self.iterations} iterations "
            f"(residual={self.residual:.6g})."
        )


@dataclass(frozen=True, slots=True)
class ScheduleError(BondError):
    reason: str

    def __str__(self) -> str:  # pragma: no cover - trivial
        return f"Schedule error: {self.reason}"


@dataclass(frozen=True, slots=True)
class SettlementError(BondError):
    reason: str

    def __str__(self) -> str:  # pragma: no cover - trivial
        return f"Settlement error: {self.reason}"


__all__ = [
    "BondError",
    "IdentifierError",
    "InvalidIdentifier",
    "InvalidBondSpec",
    "MissingRequiredField",
    "BondPricingError",
    "YieldConvergenceFailed",
    "ScheduleError",
    "SettlementError",
]

