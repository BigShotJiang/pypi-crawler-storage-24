"""Linear extrapolation."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class LinearExtrapolator:
    x0: float
    y0: float
    slope: float

    def extrapolate(self, x: float) -> float:
        return float(self.y0 + self.slope * (float(x) - self.x0))

    def derivative(self, x: float) -> float:  # pragma: no cover - trivial
        return float(self.slope)

