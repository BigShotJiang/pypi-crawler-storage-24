"""Flat (constant) extrapolation."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class FlatExtrapolator:
    level: float

    def extrapolate(self, x: float) -> float:  # pragma: no cover - trivial
        return float(self.level)

    def derivative(self, x: float) -> float:  # pragma: no cover - trivial
        return 0.0

