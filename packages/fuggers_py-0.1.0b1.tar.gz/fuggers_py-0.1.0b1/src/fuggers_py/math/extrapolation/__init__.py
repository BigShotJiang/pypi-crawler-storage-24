from __future__ import annotations

from .base import ExtrapolationMethod, Extrapolator
from .flat import FlatExtrapolator
from .linear import LinearExtrapolator
from .smith_wilson import SmithWilson

__all__ = [
    "Extrapolator",
    "ExtrapolationMethod",
    "FlatExtrapolator",
    "LinearExtrapolator",
    "SmithWilson",
]

