"""Optimization config/result types."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from numpy.typing import NDArray


@dataclass(frozen=True, slots=True)
class OptimizationConfig:
    tolerance: float = 1e-10
    max_iterations: int = 100
    step_size: float = 1e-8

    # Armijo / backtracking parameters
    armijo_c: float = 0.5
    backtracking_beta: float = 0.5
    min_step: float = 1e-15

    # Levenberg-Marquardt damping parameters (LM-lite)
    lm_initial_damping: float = 1e-3
    lm_damping_increase: float = 10.0
    lm_damping_decrease: float = 0.1


@dataclass(frozen=True, slots=True)
class OptimizationResult:
    parameters: NDArray[np.float64]
    objective_value: float
    iterations: int
    converged: bool
