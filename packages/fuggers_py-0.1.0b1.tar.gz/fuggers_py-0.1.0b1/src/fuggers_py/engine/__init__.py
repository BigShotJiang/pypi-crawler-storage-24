"""Research-facing engine package."""

from __future__ import annotations

from fuggers_py.portfolio import Portfolio, Position

from .builder import PricingEngine, PricingEngineBuilder, ReactiveEngineBuilder
from .calc_graph import CalculationGraph, NodeId, NodeValue, ShardAssignment, ShardConfig, ShardStrategy
from .config import EngineConfig, NodeConfig, UpdateFrequency
from .coordination import (
    InMemoryLeaderElection,
    InMemoryPartitionRegistry,
    InMemoryServiceRegistry,
    LeaderElection,
    PartitionAssignment,
    PartitionRegistry,
    ServiceRegistration,
    ServiceRegistry,
)
from .curve_builder import BuiltCurve, CurveBuilder, ForwardRateCurve
from .errors import CurveNotFoundError, EngineConfigurationError, EngineError, RoutingError, SchedulerError
from .etf_pricing import EtfPricer
from .market_data_listener import (
    CurveInputUpdate,
    CurveUpdate,
    FxRateUpdate,
    IndexFixingUpdate,
    InflationFixingUpdate,
    MarketDataListener,
    MarketDataPublisher,
    MarketDataUpdate,
    QuoteUpdate,
    VolSurfaceUpdate,
)
from .portfolio_analytics import PortfolioAnalyzer, PortfolioPosition
from .pricing_router import BatchPricingResult, PricingFailure, PricingInput, PricingRouter
from .reactive import ReactiveEngine
from .scheduler import CronScheduler, EodScheduler, IntervalScheduler, NodeUpdate, ThrottleManager, UpdateSource

__all__ = [
    "BatchPricingResult",
    "BuiltCurve",
    "CalculationGraph",
    "CronScheduler",
    "CurveBuilder",
    "CurveInputUpdate",
    "CurveUpdate",
    "CurveNotFoundError",
    "EngineConfig",
    "EngineConfigurationError",
    "EngineError",
    "EtfPricer",
    "EodScheduler",
    "ForwardRateCurve",
    "FxRateUpdate",
    "IndexFixingUpdate",
    "InflationFixingUpdate",
    "IntervalScheduler",
    "MarketDataListener",
    "MarketDataPublisher",
    "MarketDataUpdate",
    "NodeConfig",
    "NodeId",
    "NodeUpdate",
    "NodeValue",
    "InMemoryLeaderElection",
    "InMemoryPartitionRegistry",
    "InMemoryServiceRegistry",
    "LeaderElection",
    "PartitionAssignment",
    "PartitionRegistry",
    "PortfolioAnalyzer",
    "Portfolio",
    "PortfolioPosition",
    "Position",
    "PricingEngine",
    "PricingEngineBuilder",
    "PricingFailure",
    "PricingInput",
    "PricingRouter",
    "QuoteUpdate",
    "ReactiveEngine",
    "ReactiveEngineBuilder",
    "RoutingError",
    "SchedulerError",
    "ServiceRegistration",
    "ServiceRegistry",
    "ShardAssignment",
    "ShardConfig",
    "ShardStrategy",
    "ThrottleManager",
    "UpdateFrequency",
    "UpdateSource",
    "VolSurfaceUpdate",
]
