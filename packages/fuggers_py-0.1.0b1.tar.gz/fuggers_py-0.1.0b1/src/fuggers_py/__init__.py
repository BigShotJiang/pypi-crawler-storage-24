"""Top-level package metadata for `fuggers-py`."""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version as _dist_version

try:
    from ._version import version as __version__
except ImportError:
    try:
        __version__ = _dist_version("fuggers-py")
    except PackageNotFoundError:
        __version__ = "0.0.dev0"

__all__ = [
    "__version__",
    "analytics",
    "bonds",
    "core",
    "curves",
    "data",
    "engine",
    "io",
    "math",
    "portfolio",
]
