"""Research-facing pricing specifications."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from enum import Enum

from fuggers_py.bonds.types import ASWType, Tenor

from .ids import CurveId


def _to_decimal(value: object) -> Decimal:
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


class QuoteSide(str, Enum):
    BID = "bid"
    ASK = "ask"
    MID = "mid"


@dataclass(frozen=True, slots=True)
class BenchmarkReference:
    curve_id: CurveId | None = None
    tenor: str | None = None

    @classmethod
    def by_curve(cls, curve_id: CurveId | str) -> "BenchmarkReference":
        return cls(curve_id=curve_id if isinstance(curve_id, CurveId) else CurveId.parse(curve_id))

    @classmethod
    def by_tenor(cls, tenor: str) -> "BenchmarkReference":
        Tenor.parse(tenor)
        return cls(tenor=tenor)

    def tenor_object(self) -> Tenor | None:
        return None if self.tenor is None else Tenor.parse(self.tenor)


@dataclass(frozen=True, slots=True)
class BidAskSpreadConfig:
    bid_adjustment: Decimal = Decimal(0)
    ask_adjustment: Decimal = Decimal(0)

    def __post_init__(self) -> None:
        object.__setattr__(self, "bid_adjustment", _to_decimal(self.bid_adjustment))
        object.__setattr__(self, "ask_adjustment", _to_decimal(self.ask_adjustment))

    @classmethod
    def symmetric(cls, width: object) -> "BidAskSpreadConfig":
        half_width = _to_decimal(width) / Decimal(2)
        return cls(bid_adjustment=-half_width, ask_adjustment=half_width)

    @classmethod
    def asymmetric(cls, *, bid_adjustment: object, ask_adjustment: object) -> "BidAskSpreadConfig":
        return cls(bid_adjustment=_to_decimal(bid_adjustment), ask_adjustment=_to_decimal(ask_adjustment))

    def adjust(self, mid_value: object, side: QuoteSide) -> Decimal:
        mid = _to_decimal(mid_value)
        if side is QuoteSide.BID:
            return mid + self.bid_adjustment
        if side is QuoteSide.ASK:
            return mid + self.ask_adjustment
        return mid


@dataclass(frozen=True, slots=True)
class AnalyticsCurves:
    discount_curve: object | None = None
    forward_curve: object | None = None
    government_curve: object | None = None
    benchmark_curve: object | None = None
    credit_curve: object | None = None

    def get(self, role: str) -> object | None:
        return {
            "discount": self.discount_curve,
            "forward": self.forward_curve,
            "government": self.government_curve,
            "benchmark": self.benchmark_curve,
            "credit": self.credit_curve,
        }.get(role)


@dataclass(frozen=True, slots=True)
class PricingSpec:
    quote_side: QuoteSide = QuoteSide.MID
    market_price_is_dirty: bool | None = None
    compute_spreads: bool = True
    compute_risk: bool = True
    compute_key_rates: bool = False
    compute_current_yield: bool = True
    compute_yield_to_worst: bool = True
    include_asset_swap: bool = False
    asset_swap_type: ASWType = ASWType.PAR_PAR
    route_callable_with_oas: bool = True
    route_floating_with_discount_margin: bool = True
    callable_mean_reversion: Decimal = Decimal("0.03")
    callable_volatility: Decimal = Decimal("0.01")
    benchmark_reference: BenchmarkReference | None = None
    bid_ask: BidAskSpreadConfig | None = None


__all__ = [
    "AnalyticsCurves",
    "BenchmarkReference",
    "BidAskSpreadConfig",
    "PricingSpec",
    "QuoteSide",
]
