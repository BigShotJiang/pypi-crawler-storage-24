"""Market-data traits and in-memory research helpers."""

from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import Protocol, runtime_checkable

from fuggers_py.bonds.indices import IndexFixingStore
from fuggers_py.core.types import Currency, Date

from .ids import CurrencyPair, CurveId, EtfId, InstrumentId, VolSurfaceId, YearMonth
from .pricing_specs import QuoteSide


def _to_decimal(value: object | None) -> Decimal | None:
    if value is None or isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def _coerce_decimal_fields(instance: object, *names: str) -> None:
    for name in names:
        value = getattr(instance, name)
        coerced = _to_decimal(value)
        if coerced is not None:
            object.__setattr__(instance, name, coerced)


class SourceType(str, Enum):
    LIVE = "LIVE"
    CLOSE = "CLOSE"
    REFERENCE = "REFERENCE"
    MODEL = "MODEL"
    MANUAL = "MANUAL"


class CurveInstrumentType(str, Enum):
    CASH = "CASH"
    FUTURE = "FUTURE"
    FRA = "FRA"
    OIS = "OIS"
    IRS = "IRS"
    BOND = "BOND"
    BASIS_SWAP = "BASIS_SWAP"


class VolSurfaceType(str, Enum):
    SWAPTION = "SWAPTION"
    CAP_FLOOR = "CAP_FLOOR"
    FX_OPTION = "FX_OPTION"
    BOND_OPTION = "BOND_OPTION"
    ETF_OPTION = "ETF_OPTION"


class VolQuoteType(str, Enum):
    LOGNORMAL = "LOGNORMAL"
    NORMAL = "NORMAL"
    PRICE = "PRICE"
    SPREAD = "SPREAD"


class InflationInterpolation(str, Enum):
    MONTHLY = "MONTHLY"
    LINEAR = "LINEAR"
    FLAT = "FLAT"


@dataclass(frozen=True, slots=True)
class RawQuote:
    instrument_id: InstrumentId
    value: Decimal
    side: QuoteSide = QuoteSide.MID
    as_of: Date | None = None
    timestamp: datetime | None = None
    currency: Currency | None = None
    source: str | None = None
    source_type: SourceType | None = None
    bid: Decimal | None = None
    ask: Decimal | None = None
    mid: Decimal | None = None
    last: Decimal | None = None
    bid_size: Decimal | None = None
    ask_size: Decimal | None = None
    last_size: Decimal | None = None
    yield_to_maturity: Decimal | None = None
    yield_to_worst: Decimal | None = None
    venue: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "instrument_id", InstrumentId.parse(self.instrument_id))
        _coerce_decimal_fields(
            self,
            "value",
            "bid",
            "ask",
            "mid",
            "last",
            "bid_size",
            "ask_size",
            "last_size",
            "yield_to_maturity",
            "yield_to_worst",
        )
        if self.source is not None:
            object.__setattr__(self, "source", self.source.strip())
        if self.venue is not None:
            object.__setattr__(self, "venue", self.venue.strip())
        side_field = {
            QuoteSide.BID: "bid",
            QuoteSide.ASK: "ask",
            QuoteSide.MID: "mid",
        }[self.side]
        if getattr(self, side_field) is None:
            object.__setattr__(self, side_field, self.value)
        if self.mid is None and self.bid is not None and self.ask is not None:
            object.__setattr__(self, "mid", (self.bid + self.ask) / Decimal(2))

    def quoted_value(self, side: QuoteSide = QuoteSide.MID) -> Decimal | None:
        if side is QuoteSide.BID:
            if self.bid is not None:
                return self.bid
            return self.value if self.side is QuoteSide.BID else None
        if side is QuoteSide.ASK:
            if self.ask is not None:
                return self.ask
            return self.value if self.side is QuoteSide.ASK else None
        if self.mid is not None:
            return self.mid
        return self.value if self.side is QuoteSide.MID else None

    def for_side(self, side: QuoteSide) -> "RawQuote" | None:
        quoted_value = self.quoted_value(side)
        if quoted_value is None:
            return None
        return replace(self, value=quoted_value, side=side)


@dataclass(frozen=True, order=True, slots=True)
class CurvePoint:
    tenor: Decimal
    value: Decimal

    def __post_init__(self) -> None:
        object.__setattr__(self, "tenor", _to_decimal(self.tenor))
        object.__setattr__(self, "value", _to_decimal(self.value))


@dataclass(frozen=True, slots=True)
class CurveInput:
    instrument_type: CurveInstrumentType
    tenor: Decimal | None = None
    rate: Decimal | None = None
    price: Decimal | None = None
    weight: Decimal | None = None
    instrument_id: InstrumentId | None = None
    label: str | None = None
    quote: RawQuote | None = None
    source: str | None = None

    def __post_init__(self) -> None:
        _coerce_decimal_fields(self, "tenor", "rate", "price", "weight")
        if self.instrument_id is not None:
            object.__setattr__(self, "instrument_id", InstrumentId.parse(self.instrument_id))
        if self.label is not None:
            object.__setattr__(self, "label", self.label.strip())
        if self.source is not None:
            object.__setattr__(self, "source", self.source.strip())


@dataclass(frozen=True, slots=True)
class CurveInputs:
    curve_id: CurveId
    reference_date: Date
    points: tuple[CurvePoint, ...]
    interpolation: str = "linear"
    curve_kind: str = "zero"
    instruments: tuple[CurveInput, ...] = ()
    source: str | None = None

    def __post_init__(self) -> None:
        ordered_points = tuple(sorted(self.points, key=lambda point: (point.tenor, point.value)))
        ordered_inputs = tuple(
            sorted(
                self.instruments,
                key=lambda item: (
                    Decimal("-1") if item.tenor is None else item.tenor,
                    "" if item.label is None else item.label,
                ),
            )
        )
        object.__setattr__(self, "curve_id", CurveId.parse(self.curve_id))
        object.__setattr__(self, "points", ordered_points)
        object.__setattr__(self, "instruments", ordered_inputs)
        object.__setattr__(self, "interpolation", self.interpolation.strip().lower())
        object.__setattr__(self, "curve_kind", self.curve_kind.strip().lower())
        if self.source is not None:
            object.__setattr__(self, "source", self.source.strip())

    @classmethod
    def from_points(
        cls,
        curve_id: CurveId | str,
        reference_date: Date,
        points: list[CurvePoint] | tuple[CurvePoint, ...],
        *,
        interpolation: str = "linear",
        curve_kind: str = "zero",
        instruments: list[CurveInput] | tuple[CurveInput, ...] | None = None,
        source: str | None = None,
    ) -> "CurveInputs":
        resolved_id = curve_id if isinstance(curve_id, CurveId) else CurveId.parse(curve_id)
        return cls(
            curve_id=resolved_id,
            reference_date=reference_date,
            points=tuple(points),
            interpolation=interpolation,
            curve_kind=curve_kind,
            instruments=tuple(instruments or ()),
            source=source,
        )

    def tenors(self) -> tuple[Decimal, ...]:
        return tuple(point.tenor for point in self.points)

    def curve_data(self) -> "CurveData":
        return CurveData(
            curve_id=self.curve_id,
            reference_date=self.reference_date,
            points=self.points,
            interpolation=self.interpolation,
            curve_kind=self.curve_kind,
            instruments=self.instruments,
            source=self.source,
        )


@dataclass(frozen=True, slots=True)
class BondQuote:
    instrument_id: InstrumentId
    clean_price: Decimal | None = None
    dirty_price: Decimal | None = None
    accrued_interest: Decimal | None = None
    yield_to_maturity: Decimal | None = None
    yield_to_worst: Decimal | None = None
    side: QuoteSide = QuoteSide.MID
    as_of: Date | None = None
    timestamp: datetime | None = None
    source: str | None = None
    currency: Currency | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "instrument_id", InstrumentId.parse(self.instrument_id))
        _coerce_decimal_fields(
            self,
            "clean_price",
            "dirty_price",
            "accrued_interest",
            "yield_to_maturity",
            "yield_to_worst",
        )
        if self.source is not None:
            object.__setattr__(self, "source", self.source.strip())


@dataclass(frozen=True, slots=True)
class CurveData:
    curve_id: CurveId
    reference_date: Date
    points: tuple[CurvePoint, ...]
    interpolation: str = "linear"
    curve_kind: str = "zero"
    instruments: tuple[CurveInput, ...] = ()
    source: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "curve_id", CurveId.parse(self.curve_id))
        object.__setattr__(self, "points", tuple(sorted(self.points, key=lambda point: (point.tenor, point.value))))
        object.__setattr__(self, "instruments", tuple(self.instruments))
        object.__setattr__(self, "interpolation", self.interpolation.strip().lower())
        object.__setattr__(self, "curve_kind", self.curve_kind.strip().lower())
        if self.source is not None:
            object.__setattr__(self, "source", self.source.strip())

    def as_curve_inputs(self) -> CurveInputs:
        return CurveInputs(
            curve_id=self.curve_id,
            reference_date=self.reference_date,
            points=self.points,
            interpolation=self.interpolation,
            curve_kind=self.curve_kind,
            instruments=self.instruments,
            source=self.source,
        )


@dataclass(frozen=True, slots=True)
class IndexFixing:
    index_name: str
    fixing_date: Date
    value: Decimal

    def __post_init__(self) -> None:
        object.__setattr__(self, "index_name", self.index_name.strip().upper())
        object.__setattr__(self, "value", _to_decimal(self.value))


@dataclass(frozen=True, slots=True)
class VolPoint:
    expiry: YearMonth
    volatility: Decimal
    strike: Decimal | None = None
    tenor: YearMonth | None = None
    delta: Decimal | None = None
    quote_type: VolQuoteType = VolQuoteType.LOGNORMAL

    def __post_init__(self) -> None:
        object.__setattr__(self, "expiry", YearMonth.parse(self.expiry))
        if self.tenor is not None:
            object.__setattr__(self, "tenor", YearMonth.parse(self.tenor))
        _coerce_decimal_fields(self, "volatility", "strike", "delta")


@dataclass(frozen=True, slots=True)
class VolatilitySurface:
    surface_id: VolSurfaceId
    surface_type: VolSurfaceType
    as_of: Date | None = None
    timestamp: datetime | None = None
    points: tuple[VolPoint, ...] = ()
    source: str | None = None
    source_type: SourceType | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "surface_id", VolSurfaceId.parse(self.surface_id))
        object.__setattr__(
            self,
            "points",
            tuple(sorted(self.points, key=lambda point: (point.expiry.year, point.expiry.month, point.volatility))),
        )
        if self.source is not None:
            object.__setattr__(self, "source", self.source.strip())


@dataclass(frozen=True, slots=True)
class FxRate:
    currency_pair: CurrencyPair
    rate: Decimal
    side: QuoteSide = QuoteSide.MID
    as_of: Date | None = None
    timestamp: datetime | None = None
    source: str | None = None
    source_type: SourceType | None = None
    bid: Decimal | None = None
    ask: Decimal | None = None
    mid: Decimal | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "currency_pair", CurrencyPair.parse(self.currency_pair))
        _coerce_decimal_fields(self, "rate", "bid", "ask", "mid")
        if self.source is not None:
            object.__setattr__(self, "source", self.source.strip())
        side_field = {
            QuoteSide.BID: "bid",
            QuoteSide.ASK: "ask",
            QuoteSide.MID: "mid",
        }[self.side]
        if getattr(self, side_field) is None:
            object.__setattr__(self, side_field, self.rate)
        if self.mid is None and self.bid is not None and self.ask is not None:
            object.__setattr__(self, "mid", (self.bid + self.ask) / Decimal(2))

    def quoted_value(self, side: QuoteSide = QuoteSide.MID) -> Decimal | None:
        if side is QuoteSide.BID:
            if self.bid is not None:
                return self.bid
            return self.rate if self.side is QuoteSide.BID else None
        if side is QuoteSide.ASK:
            if self.ask is not None:
                return self.ask
            return self.rate if self.side is QuoteSide.ASK else None
        if self.mid is not None:
            return self.mid
        return self.rate if self.side is QuoteSide.MID else None

    def for_side(self, side: QuoteSide) -> "FxRate" | None:
        quoted_value = self.quoted_value(side)
        if quoted_value is None:
            return None
        return replace(self, rate=quoted_value, side=side)


@dataclass(frozen=True, slots=True)
class InflationFixing:
    index_name: str
    observation_month: YearMonth
    value: Decimal
    publication_date: Date | None = None
    interpolation: InflationInterpolation = InflationInterpolation.MONTHLY
    source: str | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "index_name", self.index_name.strip().upper())
        object.__setattr__(self, "observation_month", YearMonth.parse(self.observation_month))
        object.__setattr__(self, "value", _to_decimal(self.value))
        if self.source is not None:
            object.__setattr__(self, "source", self.source.strip())


@dataclass(frozen=True, slots=True)
class EtfHolding:
    instrument_id: InstrumentId
    quantity: Decimal | None = None
    weight: Decimal | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "instrument_id", InstrumentId.parse(self.instrument_id))
        quantity = _to_decimal(self.quantity)
        weight = _to_decimal(self.weight)
        if quantity is None and weight is None:
            raise ValueError("EtfHolding requires either quantity or weight.")
        object.__setattr__(self, "quantity", quantity)
        object.__setattr__(self, "weight", weight)


@dataclass(frozen=True, slots=True)
class EtfQuote:
    etf_id: EtfId
    market_price: Decimal | None = None
    nav: Decimal | None = None
    i_nav: Decimal | None = None
    shares_outstanding: Decimal | None = None
    as_of: Date | None = None
    timestamp: datetime | None = None
    source: str | None = None
    bid: Decimal | None = None
    ask: Decimal | None = None
    mid: Decimal | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "etf_id", EtfId.parse(self.etf_id))
        _coerce_decimal_fields(self, "market_price", "nav", "i_nav", "shares_outstanding", "bid", "ask", "mid")
        if self.source is not None:
            object.__setattr__(self, "source", self.source.strip())
        if self.mid is None and self.market_price is not None:
            object.__setattr__(self, "mid", self.market_price)
        if self.mid is None and self.bid is not None and self.ask is not None:
            object.__setattr__(self, "mid", (self.bid + self.ask) / Decimal(2))


@dataclass(frozen=True, slots=True)
class MarketDataSnapshot:
    as_of: Date | None = None
    quotes: tuple[RawQuote, ...] = ()
    curves: tuple[CurveInputs, ...] = ()
    fixings: tuple[IndexFixing, ...] = ()
    etf_holdings: tuple[EtfHolding, ...] = ()
    volatility_surfaces: tuple[VolatilitySurface, ...] = ()
    fx_rates: tuple[FxRate, ...] = ()
    inflation_fixings: tuple[InflationFixing, ...] = ()
    etf_quotes: tuple[EtfQuote, ...] = ()

    def quote_source(self) -> "InMemoryQuoteSource":
        return InMemoryQuoteSource(self.quotes)

    def curve_source(self) -> "InMemoryCurveSource":
        return InMemoryCurveSource(self.curves)

    def fixing_source(self) -> "InMemoryFixingSource":
        return InMemoryFixingSource(self.fixings)

    def volatility_source(self) -> "InMemoryVolatilitySource":
        return InMemoryVolatilitySource(self.volatility_surfaces)

    def fx_rate_source(self) -> "InMemoryFxRateSource":
        return InMemoryFxRateSource(self.fx_rates)

    def inflation_fixing_source(self) -> "InMemoryInflationFixingSource":
        return InMemoryInflationFixingSource(self.inflation_fixings)

    def etf_quote_source(self) -> "InMemoryEtfQuoteSource":
        return InMemoryEtfQuoteSource(self.etf_quotes)

    def provider(self) -> "MarketDataProvider":
        return MarketDataProvider.from_snapshot(self)


@runtime_checkable
class QuoteSource(Protocol):
    def get_quote(self, instrument_id: InstrumentId | str, side: QuoteSide = QuoteSide.MID) -> RawQuote | None:
        ...


@runtime_checkable
class CurveInputSource(Protocol):
    def get_curve_inputs(self, curve_id: CurveId | str) -> CurveInputs | None:
        ...


@runtime_checkable
class IndexFixingSource(Protocol):
    def get_fixing(self, index_name: str, fixing_date: Date) -> IndexFixing | None:
        ...


@runtime_checkable
class ReferenceCurveSource(Protocol):
    def get_reference_curve(self, curve_id: CurveId | str) -> CurveInputs | None:
        ...


@runtime_checkable
class VolatilitySource(Protocol):
    def get_volatility_surface(self, surface_id: VolSurfaceId | str) -> VolatilitySurface | None:
        ...


@runtime_checkable
class FxRateSource(Protocol):
    def get_fx_rate(self, currency_pair: CurrencyPair | str, side: QuoteSide = QuoteSide.MID) -> FxRate | None:
        ...


@runtime_checkable
class InflationFixingSource(Protocol):
    def get_inflation_fixing(self, index_name: str, observation_month: YearMonth | str) -> InflationFixing | None:
        ...


@runtime_checkable
class EtfQuoteSource(Protocol):
    def get_etf_quote(self, etf_id: EtfId | str) -> EtfQuote | None:
        ...


@runtime_checkable
class PricingDataProvider(QuoteSource, CurveInputSource, IndexFixingSource, Protocol):
    pass


CurveSource = CurveInputSource
FixingSource = IndexFixingSource


@dataclass(slots=True)
class InMemoryQuoteSource:
    quotes: dict[tuple[InstrumentId, QuoteSide], RawQuote] = field(default_factory=dict)

    def __init__(self, quotes: tuple[RawQuote, ...] | list[RawQuote] | None = None) -> None:
        self.quotes = {}
        for quote in quotes or ():
            self.add_quote(quote)

    def add_quote(self, quote: RawQuote) -> "InMemoryQuoteSource":
        for side in (QuoteSide.BID, QuoteSide.ASK, QuoteSide.MID):
            candidate = quote.for_side(side)
            if candidate is not None:
                self.quotes[(quote.instrument_id, side)] = candidate
        self.quotes[(quote.instrument_id, quote.side)] = quote
        return self

    def get_quote(self, instrument_id: InstrumentId | str, side: QuoteSide = QuoteSide.MID) -> RawQuote | None:
        resolved = instrument_id if isinstance(instrument_id, InstrumentId) else InstrumentId.parse(instrument_id)
        direct = self.quotes.get((resolved, side))
        if direct is not None:
            return direct
        if side is not QuoteSide.MID:
            return self.quotes.get((resolved, QuoteSide.MID))
        return None


@dataclass(slots=True)
class InMemoryCurveSource:
    curves: dict[CurveId, CurveInputs] = field(default_factory=dict)

    def __init__(self, curves: tuple[CurveInputs, ...] | list[CurveInputs] | None = None) -> None:
        self.curves = {}
        for curve in curves or ():
            self.add_curve_inputs(curve)

    def add_curve_inputs(self, curve_inputs: CurveInputs | CurveData) -> "InMemoryCurveSource":
        resolved = curve_inputs.as_curve_inputs() if isinstance(curve_inputs, CurveData) else curve_inputs
        self.curves[resolved.curve_id] = resolved
        return self

    def get_curve_inputs(self, curve_id: CurveId | str) -> CurveInputs | None:
        resolved = curve_id if isinstance(curve_id, CurveId) else CurveId.parse(curve_id)
        return self.curves.get(resolved)

    def get_reference_curve(self, curve_id: CurveId | str) -> CurveInputs | None:
        return self.get_curve_inputs(curve_id)


@dataclass(slots=True)
class InMemoryFixingSource:
    fixings: dict[tuple[str, Date], IndexFixing] = field(default_factory=dict)

    def __init__(self, fixings: tuple[IndexFixing, ...] | list[IndexFixing] | None = None) -> None:
        self.fixings = {}
        for fixing in fixings or ():
            self.add_fixing(fixing)

    def add_fixing(self, fixing: IndexFixing) -> "InMemoryFixingSource":
        self.fixings[(fixing.index_name, fixing.fixing_date)] = fixing
        return self

    def get_fixing(self, index_name: str, fixing_date: Date) -> IndexFixing | None:
        return self.fixings.get((index_name.strip().upper(), fixing_date))

    def get_rate(self, index_name: str, fixing_date: Date) -> Decimal | None:
        fixing = self.get_fixing(index_name, fixing_date)
        return None if fixing is None else fixing.value

    def to_fixing_store(self) -> IndexFixingStore:
        store = IndexFixingStore()
        for fixing in self.fixings.values():
            store.add_fixing(fixing.index_name, fixing.fixing_date, fixing.value)
        return store


@dataclass(slots=True)
class InMemoryVolatilitySource:
    surfaces: dict[VolSurfaceId, VolatilitySurface] = field(default_factory=dict)

    def __init__(self, surfaces: tuple[VolatilitySurface, ...] | list[VolatilitySurface] | None = None) -> None:
        self.surfaces = {}
        for surface in surfaces or ():
            self.add_surface(surface)

    def add_surface(self, surface: VolatilitySurface) -> "InMemoryVolatilitySource":
        self.surfaces[surface.surface_id] = surface
        return self

    def get_volatility_surface(self, surface_id: VolSurfaceId | str) -> VolatilitySurface | None:
        resolved = surface_id if isinstance(surface_id, VolSurfaceId) else VolSurfaceId.parse(surface_id)
        return self.surfaces.get(resolved)


@dataclass(slots=True)
class InMemoryFxRateSource:
    fx_rates: dict[tuple[CurrencyPair, QuoteSide], FxRate] = field(default_factory=dict)

    def __init__(self, fx_rates: tuple[FxRate, ...] | list[FxRate] | None = None) -> None:
        self.fx_rates = {}
        for fx_rate in fx_rates or ():
            self.add_fx_rate(fx_rate)

    def add_fx_rate(self, fx_rate: FxRate) -> "InMemoryFxRateSource":
        for side in (QuoteSide.BID, QuoteSide.ASK, QuoteSide.MID):
            candidate = fx_rate.for_side(side)
            if candidate is not None:
                self.fx_rates[(fx_rate.currency_pair, side)] = candidate
        self.fx_rates[(fx_rate.currency_pair, fx_rate.side)] = fx_rate
        return self

    def get_fx_rate(self, currency_pair: CurrencyPair | str, side: QuoteSide = QuoteSide.MID) -> FxRate | None:
        resolved = currency_pair if isinstance(currency_pair, CurrencyPair) else CurrencyPair.parse(currency_pair)
        direct = self.fx_rates.get((resolved, side))
        if direct is not None:
            return direct
        if side is not QuoteSide.MID:
            return self.fx_rates.get((resolved, QuoteSide.MID))
        return None


@dataclass(slots=True)
class InMemoryInflationFixingSource:
    fixings: dict[tuple[str, YearMonth], InflationFixing] = field(default_factory=dict)

    def __init__(self, fixings: tuple[InflationFixing, ...] | list[InflationFixing] | None = None) -> None:
        self.fixings = {}
        for fixing in fixings or ():
            self.add_inflation_fixing(fixing)

    def add_inflation_fixing(self, fixing: InflationFixing) -> "InMemoryInflationFixingSource":
        self.fixings[(fixing.index_name, fixing.observation_month)] = fixing
        return self

    def get_inflation_fixing(self, index_name: str, observation_month: YearMonth | str) -> InflationFixing | None:
        return self.fixings.get((index_name.strip().upper(), YearMonth.parse(observation_month)))


@dataclass(slots=True)
class InMemoryEtfQuoteSource:
    etf_quotes: dict[EtfId, EtfQuote] = field(default_factory=dict)

    def __init__(self, etf_quotes: tuple[EtfQuote, ...] | list[EtfQuote] | None = None) -> None:
        self.etf_quotes = {}
        for quote in etf_quotes or ():
            self.add_etf_quote(quote)

    def add_etf_quote(self, quote: EtfQuote) -> "InMemoryEtfQuoteSource":
        self.etf_quotes[quote.etf_id] = quote
        return self

    def get_etf_quote(self, etf_id: EtfId | str) -> EtfQuote | None:
        resolved = etf_id if isinstance(etf_id, EtfId) else EtfId.parse(etf_id)
        return self.etf_quotes.get(resolved)


@dataclass(slots=True)
class MarketDataProvider:
    quote_source: QuoteSource | None = None
    curve_input_source: CurveInputSource | None = None
    index_fixing_source: IndexFixingSource | None = None
    volatility_source: VolatilitySource | None = None
    fx_rate_source: FxRateSource | None = None
    inflation_fixing_source: InflationFixingSource | None = None
    etf_quote_source: EtfQuoteSource | None = None

    @classmethod
    def from_snapshot(cls, snapshot: MarketDataSnapshot) -> "MarketDataProvider":
        return cls(
            quote_source=snapshot.quote_source(),
            curve_input_source=snapshot.curve_source(),
            index_fixing_source=snapshot.fixing_source(),
            volatility_source=snapshot.volatility_source(),
            fx_rate_source=snapshot.fx_rate_source(),
            inflation_fixing_source=snapshot.inflation_fixing_source(),
            etf_quote_source=snapshot.etf_quote_source(),
        )

    def get_quote(self, instrument_id: InstrumentId | str, side: QuoteSide = QuoteSide.MID) -> RawQuote | None:
        if self.quote_source is None:
            return None
        return self.quote_source.get_quote(instrument_id, side)

    def get_curve_inputs(self, curve_id: CurveId | str) -> CurveInputs | None:
        if self.curve_input_source is None:
            return None
        return self.curve_input_source.get_curve_inputs(curve_id)

    def get_fixing(self, index_name: str, fixing_date: Date) -> IndexFixing | None:
        if self.index_fixing_source is None:
            return None
        return self.index_fixing_source.get_fixing(index_name, fixing_date)

    def get_volatility_surface(self, surface_id: VolSurfaceId | str) -> VolatilitySurface | None:
        if self.volatility_source is None:
            return None
        return self.volatility_source.get_volatility_surface(surface_id)

    def get_fx_rate(self, currency_pair: CurrencyPair | str, side: QuoteSide = QuoteSide.MID) -> FxRate | None:
        if self.fx_rate_source is None:
            return None
        return self.fx_rate_source.get_fx_rate(currency_pair, side)

    def get_inflation_fixing(self, index_name: str, observation_month: YearMonth | str) -> InflationFixing | None:
        if self.inflation_fixing_source is None:
            return None
        return self.inflation_fixing_source.get_inflation_fixing(index_name, observation_month)

    def get_etf_quote(self, etf_id: EtfId | str) -> EtfQuote | None:
        if self.etf_quote_source is None:
            return None
        return self.etf_quote_source.get_etf_quote(etf_id)


CurveInputSet = CurveInputs


__all__ = [
    "BondQuote",
    "CurveData",
    "CurveInput",
    "CurveInputSource",
    "CurveInputSet",
    "CurveInputs",
    "CurveInstrumentType",
    "CurvePoint",
    "CurveSource",
    "EtfHolding",
    "EtfQuote",
    "EtfQuoteSource",
    "FixingSource",
    "FxRate",
    "FxRateSource",
    "IndexFixing",
    "IndexFixingSource",
    "InflationFixing",
    "InflationFixingSource",
    "InflationInterpolation",
    "InMemoryCurveSource",
    "InMemoryEtfQuoteSource",
    "InMemoryFixingSource",
    "InMemoryFxRateSource",
    "InMemoryInflationFixingSource",
    "InMemoryQuoteSource",
    "InMemoryVolatilitySource",
    "MarketDataProvider",
    "MarketDataSnapshot",
    "PricingDataProvider",
    "QuoteSource",
    "RawQuote",
    "ReferenceCurveSource",
    "SourceType",
    "VolPoint",
    "VolQuoteType",
    "VolSurfaceType",
    "VolatilitySource",
    "VolatilitySurface",
]
