"""Typed identifiers for research-facing traits and engine layers."""

from __future__ import annotations

import re
from dataclasses import dataclass

from fuggers_py.core.types import Currency


def _normalize(value: object) -> str:
    text = str(value).strip()
    if not text:
        raise ValueError("Identifier value must be non-empty.")
    return text


def _normalize_currency(value: Currency | str) -> Currency:
    if isinstance(value, Currency):
        return value
    return Currency.from_code(_normalize(value))


@dataclass(frozen=True, slots=True)
class InstrumentId:
    value: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "value", _normalize(self.value))

    @classmethod
    def parse(cls, value: object) -> "InstrumentId":
        return cls(_normalize(value))

    @classmethod
    def from_string(cls, value: str) -> "InstrumentId":
        return cls.parse(value)

    def as_str(self) -> str:
        return self.value

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.value


@dataclass(frozen=True, slots=True)
class CurveId:
    value: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "value", _normalize(self.value))

    @classmethod
    def parse(cls, value: object) -> "CurveId":
        return cls(_normalize(value))

    @classmethod
    def from_string(cls, value: str) -> "CurveId":
        return cls.parse(value)

    def as_str(self) -> str:
        return self.value

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.value


@dataclass(frozen=True, slots=True)
class PortfolioId:
    value: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "value", _normalize(self.value))

    @classmethod
    def parse(cls, value: object) -> "PortfolioId":
        return cls(_normalize(value))

    @classmethod
    def from_string(cls, value: str) -> "PortfolioId":
        return cls.parse(value)

    def as_str(self) -> str:
        return self.value

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.value


@dataclass(frozen=True, slots=True)
class EtfId:
    value: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "value", _normalize(self.value))

    @classmethod
    def parse(cls, value: object) -> "EtfId":
        return cls(_normalize(value))

    @classmethod
    def from_string(cls, value: str) -> "EtfId":
        return cls.parse(value)

    def as_str(self) -> str:
        return self.value

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.value


@dataclass(frozen=True, slots=True)
class VolSurfaceId:
    value: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "value", _normalize(self.value))

    @classmethod
    def parse(cls, value: object) -> "VolSurfaceId":
        return cls(_normalize(value))

    @classmethod
    def from_string(cls, value: str) -> "VolSurfaceId":
        return cls.parse(value)

    def as_str(self) -> str:
        return self.value

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.value


@dataclass(frozen=True, slots=True)
class CurrencyPair:
    base: Currency
    quote: Currency

    def __post_init__(self) -> None:
        object.__setattr__(self, "base", _normalize_currency(self.base))
        object.__setattr__(self, "quote", _normalize_currency(self.quote))

    @classmethod
    def parse(cls, value: object) -> "CurrencyPair":
        if isinstance(value, cls):
            return value
        text = _normalize(value).upper()
        compact = re.sub(r"[\s:_-]+", "/", text)
        if "/" in compact:
            parts = [part for part in compact.split("/") if part]
        elif len(compact) == 6 and compact.isalpha():
            parts = [compact[:3], compact[3:]]
        else:
            raise ValueError(f"Invalid currency pair: {value!r}")
        if len(parts) != 2:
            raise ValueError(f"Invalid currency pair: {value!r}")
        return cls(_normalize_currency(parts[0]), _normalize_currency(parts[1]))

    @classmethod
    def from_string(cls, value: str) -> "CurrencyPair":
        return cls.parse(value)

    def as_str(self) -> str:
        return f"{self.base.code()}/{self.quote.code()}"

    @property
    def value(self) -> str:
        return self.as_str()

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.as_str()


@dataclass(frozen=True, slots=True)
class YearMonth:
    year: int
    month: int

    def __post_init__(self) -> None:
        if self.year < 1:
            raise ValueError("YearMonth.year must be positive.")
        if not 1 <= self.month <= 12:
            raise ValueError("YearMonth.month must be between 1 and 12.")

    @classmethod
    def parse(cls, value: object) -> "YearMonth":
        if isinstance(value, cls):
            return value
        text = _normalize(value)
        match = re.fullmatch(r"(\d{4})-(\d{2})", text)
        if match is None:
            raise ValueError(f"Invalid year-month value: {value!r}")
        return cls(year=int(match.group(1)), month=int(match.group(2)))

    @classmethod
    def from_string(cls, value: str) -> "YearMonth":
        return cls.parse(value)

    def as_str(self) -> str:
        return f"{self.year:04d}-{self.month:02d}"

    @property
    def value(self) -> str:
        return self.as_str()

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.as_str()


__all__ = [
    "CurrencyPair",
    "CurveId",
    "EtfId",
    "InstrumentId",
    "PortfolioId",
    "VolSurfaceId",
    "YearMonth",
]
