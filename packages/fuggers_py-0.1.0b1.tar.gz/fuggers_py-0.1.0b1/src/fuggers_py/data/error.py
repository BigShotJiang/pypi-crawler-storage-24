"""Compatibility wrapper for `fuggers_py.data.errors`."""

from __future__ import annotations

from . import errors as _errors

AlreadyExistsError = _errors.AlreadyExistsError
AuthenticationError = _errors.AuthenticationError
ConnectionFailureError = _errors.ConnectionFailureError
DatabaseError = _errors.DatabaseError
InternalError = _errors.InternalError
InvalidInputError = _errors.InvalidInputError
NotFoundError = _errors.NotFoundError
ParseError = _errors.ParseError
PermissionDeniedError = _errors.PermissionDeniedError
RateLimitError = _errors.RateLimitError
SerializationError = _errors.SerializationError
SourceUnavailableError = _errors.SourceUnavailableError
SubscriptionFailureError = _errors.SubscriptionFailureError
TraitError = _errors.TraitError
TraitIOError = _errors.TraitIOError
TraitTimeoutError = _errors.TraitTimeoutError


def __getattr__(name: str) -> object:
    return _errors.__getattr__(name)


__all__ = list(_errors.__all__)
