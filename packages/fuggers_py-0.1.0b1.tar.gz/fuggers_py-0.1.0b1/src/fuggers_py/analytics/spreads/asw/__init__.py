"""Asset swap helpers (`fuggers_py.analytics.spreads.asw`)."""

from __future__ import annotations

from typing import TYPE_CHECKING
from warnings import warn

from .par_par import ParParAssetSwap
from .proceeds import ProceedsAssetSwap

if TYPE_CHECKING:
    from fuggers_py.bonds.types import ASWType as ASWType


def __getattr__(name: str) -> object:
    if name == "ASWType":
        from fuggers_py.bonds.types import ASWType

        warn(
            "`fuggers_py.analytics.spreads.asw.ASWType` is deprecated; import `ASWType` from `fuggers_py.bonds.types`.",
            DeprecationWarning,
            stacklevel=2,
        )
        return ASWType
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = ["ASWType", "ParParAssetSwap", "ProceedsAssetSwap"]
