"""Spread analytics for the analytics layer.

`fuggers_py.analytics.spreads` is the canonical public surface for g-spread,
i-spread, z-spread, OAS, discount-margin, and asset-swap analytics.

These symbols intentionally live under `analytics`, not at the package root:
spread analytics are part of the analytics layer and are not duplicated under
`fuggers_py.spreads`.
"""

from __future__ import annotations

from dataclasses import dataclass

from fuggers_py.bonds.types import ASWType, Cusip, Figi, Isin, Sedol

from .asw import ParParAssetSwap, ProceedsAssetSwap
from .benchmark import BenchmarkKind, BenchmarkSpec
from .discount_margin import DiscountMarginCalculator, simple_margin, z_discount_margin
from .government_curve import GovernmentBenchmark, GovernmentCurve
from .gspread import GSpreadCalculator, g_spread, g_spread_with_benchmark
from .ispread import ISpreadCalculator, i_spread
from .oas import OASCalculator
from .sovereign import Sovereign, SupranationalIssuer
from .zspread import ZSpreadCalculator, z_spread, z_spread_from_curve


@dataclass(frozen=True, slots=True)
class SecurityId:
    identifier_type: str
    value: str

    @classmethod
    def cusip(cls, value: str) -> "SecurityId":
        return cls("CUSIP", Cusip.new(value).value)

    @classmethod
    def cusip_unchecked(cls, value: str) -> "SecurityId":
        return cls("CUSIP", value.strip().upper())

    @classmethod
    def isin(cls, value: str) -> "SecurityId":
        return cls("ISIN", Isin.new(value).value)

    @classmethod
    def sedol(cls, value: str) -> "SecurityId":
        return cls("SEDOL", Sedol.new(value).value)

    @classmethod
    def figi(cls, value: str) -> "SecurityId":
        return cls("FIGI", Figi.new(value).value)

    def id_type(self) -> str:
        return self.identifier_type

    def as_str(self) -> str:
        return self.value

    def __str__(self) -> str:  # pragma: no cover - trivial
        return f"{self.identifier_type}:{self.value}"


__all__ = [
    "SecurityId",
    "BenchmarkSpec",
    "BenchmarkKind",
    "Sovereign",
    "SupranationalIssuer",
    "GovernmentBenchmark",
    "GovernmentCurve",
    "GSpreadCalculator",
    "ISpreadCalculator",
    "ZSpreadCalculator",
    "g_spread",
    "g_spread_with_benchmark",
    "i_spread",
    "z_spread",
    "z_spread_from_curve",
    "DiscountMarginCalculator",
    "simple_margin",
    "z_discount_margin",
    "OASCalculator",
    "ASWType",
    "ParParAssetSwap",
    "ProceedsAssetSwap",
]
