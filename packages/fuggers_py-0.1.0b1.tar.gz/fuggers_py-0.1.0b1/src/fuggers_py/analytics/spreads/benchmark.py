"""Benchmark specification (`fuggers_py.analytics.spreads.benchmark`)."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from enum import Enum

from fuggers_py.bonds.types import Tenor


def _to_decimal(value: object) -> Decimal:
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


class BenchmarkKind(str, Enum):
    INTERPOLATED = "INTERPOLATED"
    NEAREST = "NEAREST"
    TENOR = "TENOR"
    EXPLICIT = "EXPLICIT"


@dataclass(frozen=True, slots=True)
class BenchmarkSpec:
    kind: BenchmarkKind
    tenor: Tenor | None = None
    explicit_yield: Decimal | None = None

    @classmethod
    def interpolated(cls) -> "BenchmarkSpec":
        return cls(BenchmarkKind.INTERPOLATED)

    @classmethod
    def nearest(cls) -> "BenchmarkSpec":
        return cls(BenchmarkKind.NEAREST)

    @classmethod
    def ten_year(cls) -> "BenchmarkSpec":
        return cls(BenchmarkKind.TENOR, tenor=Tenor.parse("10Y"))

    @classmethod
    def five_year(cls) -> "BenchmarkSpec":
        return cls(BenchmarkKind.TENOR, tenor=Tenor.parse("5Y"))

    @classmethod
    def explicit(cls, yield_value: object) -> "BenchmarkSpec":
        return cls(BenchmarkKind.EXPLICIT, explicit_yield=_to_decimal(yield_value))

    def description(self) -> str:
        if self.kind is BenchmarkKind.EXPLICIT and self.explicit_yield is not None:
            return f"Explicit benchmark ({self.explicit_yield}%)"
        if self.kind is BenchmarkKind.TENOR and self.tenor is not None:
            return f"Benchmark tenor {self.tenor}"
        return self.kind.value.replace("_", " ").title()

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.description()


__all__ = ["BenchmarkSpec", "BenchmarkKind"]
