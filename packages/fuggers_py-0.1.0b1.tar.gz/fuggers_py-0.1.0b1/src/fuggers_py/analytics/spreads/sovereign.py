"""Sovereign issuers (`fuggers_py.analytics.spreads.sovereign`)."""

from __future__ import annotations

from enum import Enum

from fuggers_py.bonds.types import Tenor
from fuggers_py.core.types import Currency


class Sovereign(str, Enum):
    UNITED_STATES = "UNITED_STATES"
    UNITED_KINGDOM = "UNITED_KINGDOM"
    GERMANY = "GERMANY"
    FRANCE = "FRANCE"
    JAPAN = "JAPAN"

    def currency(self) -> Currency:
        return {
            Sovereign.UNITED_STATES: Currency.USD,
            Sovereign.UNITED_KINGDOM: Currency.GBP,
            Sovereign.GERMANY: Currency.EUR,
            Sovereign.FRANCE: Currency.EUR,
            Sovereign.JAPAN: Currency.JPY,
        }[self]

    def bond_name(self) -> str:
        return {
            Sovereign.UNITED_STATES: "Treasury",
            Sovereign.UNITED_KINGDOM: "Gilt",
            Sovereign.GERMANY: "Bund",
            Sovereign.FRANCE: "OAT",
            Sovereign.JAPAN: "JGB",
        }[self]

    def standard_tenors(self) -> list[Tenor]:
        return [Tenor.parse("2Y"), Tenor.parse("5Y"), Tenor.parse("10Y"), Tenor.parse("30Y")]

    @classmethod
    def us_treasury(cls) -> "Sovereign":
        return cls.UNITED_STATES

    @classmethod
    def uk_gilt(cls) -> "Sovereign":
        return cls.UNITED_KINGDOM

    @classmethod
    def german_bund(cls) -> "Sovereign":
        return cls.GERMANY


class SupranationalIssuer(str, Enum):
    WORLD_BANK = "WORLD_BANK"
    IMF = "IMF"
    EIB = "EIB"


__all__ = ["Sovereign", "SupranationalIssuer"]
