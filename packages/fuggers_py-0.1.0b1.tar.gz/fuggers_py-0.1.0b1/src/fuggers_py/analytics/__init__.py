"""Analytics layer (`fuggers_py.analytics`)."""

from __future__ import annotations

import warnings

from fuggers_py.bonds.types import YieldConvention

from . import cashflows, errors, functions, options, pricing, risk, spreads, yas, yields
from .cashflows import accrued as accrued
from .errors import AnalyticsError
from .functions import (
    calculate_accrued_interest,
    calculate_macaulay_duration,
    calculate_modified_duration,
    calculate_yield_to_maturity,
    calculate_z_spread,
    macaulay_duration,
    modified_duration,
    yield_to_maturity,
)
from .pricing import BondPricer, PriceResult
from .risk import DurationType
from .risk import duration as duration
from .spreads import z_spread
from .yields import (
    YieldEngine,
    YieldEngineResult,
    YieldResult,
    YieldSolver,
    current_yield,
    engine as engine,
    simple_yield,
    StandardYieldEngine,
)

yield_metric = yields
_DEPRECATED_ROOT_ERROR_NAMES = frozenset(name for name in errors.__all__ if name != "AnalyticsError")


def __getattr__(name: str) -> object:
    if name in _DEPRECATED_ROOT_ERROR_NAMES:
        warnings.warn(
            f"`fuggers_py.analytics.{name}` is deprecated; import it from `fuggers_py.analytics.errors`.",
            DeprecationWarning,
            stacklevel=2,
        )
        return getattr(errors, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = [
    "cashflows",
    "accrued",
    "errors",
    "options",
    "yields",
    "yield_metric",
    "pricing",
    "risk",
    "duration",
    "spreads",
    "engine",
    "yas",
    "functions",
    "YieldConvention",
    "BondPricer",
    "PriceResult",
    "AnalyticsError",
    "YieldResult",
    "YieldSolver",
    "YieldEngine",
    "YieldEngineResult",
    "StandardYieldEngine",
    "DurationType",
    "current_yield",
    "simple_yield",
    "yield_to_maturity",
    "macaulay_duration",
    "modified_duration",
    "z_spread",
    "calculate_accrued_interest",
    "calculate_macaulay_duration",
    "calculate_modified_duration",
    "calculate_yield_to_maturity",
    "calculate_z_spread",
]
