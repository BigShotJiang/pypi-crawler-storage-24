"""Cashflow generation (`fuggers_py.analytics.cashflows.generator`)."""

from __future__ import annotations

from fuggers_py.bonds.cashflows.generator import CashFlowGenerator

__all__ = ["CashFlowGenerator"]
