"""Irregular-period helpers (`fuggers_py.analytics.cashflows.irregular`)."""

from __future__ import annotations

from dataclasses import dataclass

from fuggers_py.core.daycounts import DayCountConvention
from fuggers_py.core.types import Date

from ..error import AnalyticsError


@dataclass(frozen=True, slots=True)
class IrregularPeriodHandler:
    day_count: DayCountConvention = DayCountConvention.ACT_360

    @classmethod
    def new(cls, day_count: DayCountConvention) -> IrregularPeriodHandler:
        return cls(day_count=day_count)

    def days_between(self, start: Date, end: Date) -> int:
        return int(self.day_count.to_day_count().day_count(start, end))

    def year_fraction(self, start: Date, end: Date) -> float:
        return float(self.day_count.to_day_count().year_fraction(start, end))

    def annual_factor(self, start: Date, end: Date) -> float:
        frac = self.year_fraction(start, end)
        if frac <= 0.0:
            raise AnalyticsError.invalid_input("Irregular period year fraction must be positive.")
        return 1.0 / float(frac)


__all__ = ["IrregularPeriodHandler"]
