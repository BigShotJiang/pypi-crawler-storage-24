"""Accrued interest helpers (`fuggers_py.analytics.cashflows.accrued`)."""

from __future__ import annotations

from fuggers_py.bonds.cashflows.accrued import AccruedInterestCalculator

__all__ = ["AccruedInterestCalculator"]
