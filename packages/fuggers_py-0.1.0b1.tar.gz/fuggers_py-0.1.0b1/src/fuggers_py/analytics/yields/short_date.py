"""Short-dated yield helpers (`fuggers_py.analytics.yields.short_date`)."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum


class RollForwardMethod(str, Enum):
    NONE = "NONE"
    MONOTONE = "MONOTONE"
    USE_MONEY_MARKET = "USE_MONEY_MARKET"


@dataclass(frozen=True, slots=True)
class ShortDateCalculator:
    money_market_threshold: float = 1.0 / 12.0
    short_date_threshold: float = 1.0

    @classmethod
    def new(
        cls,
        money_market_threshold: float | None = None,
        short_date_threshold: float | None = None,
    ) -> "ShortDateCalculator":
        return cls(
            money_market_threshold=float(money_market_threshold)
            if money_market_threshold is not None
            else 1.0 / 12.0,
            short_date_threshold=float(short_date_threshold) if short_date_threshold is not None else 1.0,
        )

    @classmethod
    def bloomberg(cls) -> "ShortDateCalculator":
        return cls.new()

    def is_short_dated(self, years_to_maturity: float) -> bool:
        return float(years_to_maturity) <= float(self.short_date_threshold)

    def use_money_market_below(self, years_to_maturity: float) -> bool:
        return float(years_to_maturity) <= float(self.money_market_threshold)

    def roll_forward_method(self, years_to_maturity: float) -> RollForwardMethod:
        if self.use_money_market_below(years_to_maturity):
            return RollForwardMethod.USE_MONEY_MARKET
        if self.is_short_dated(years_to_maturity):
            return RollForwardMethod.MONOTONE
        return RollForwardMethod.NONE


__all__ = ["RollForwardMethod", "ShortDateCalculator"]
