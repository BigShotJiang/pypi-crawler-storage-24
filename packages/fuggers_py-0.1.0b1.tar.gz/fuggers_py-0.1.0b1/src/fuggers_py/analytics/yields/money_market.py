"""Money-market yield helpers (`fuggers_py.analytics.yields.money_market`)."""

from __future__ import annotations

from decimal import Decimal

from ..error import AnalyticsError


def _to_decimal(value: object) -> Decimal:
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


def discount_yield(face_value: object, price: object, days_to_maturity: object) -> Decimal:
    face = _to_decimal(face_value)
    px = _to_decimal(price)
    days = _to_decimal(days_to_maturity)
    if face <= 0 or px <= 0 or days <= 0:
        raise AnalyticsError.invalid_input("face, price, and days must be positive for discount yield.")
    return (face - px) / face * (Decimal(360) / days) * Decimal(100)


def bond_equivalent_yield(face_value: object, price: object, days_to_maturity: object) -> Decimal:
    days = _to_decimal(days_to_maturity)
    if days <= 0:
        raise AnalyticsError.invalid_input("days_to_maturity must be positive for BEY.")
    disc = discount_yield(face_value, price, days)
    d = disc / Decimal(100)
    denom = Decimal(360) - d * days
    if denom == 0:
        raise AnalyticsError.invalid_input("Invalid BEY denominator (discount too large).")
    bey = (d * Decimal(365)) / denom
    return bey * Decimal(100)


def cd_equivalent_yield(face_value: object, price: object, days_to_maturity: object) -> Decimal:
    face = _to_decimal(face_value)
    px = _to_decimal(price)
    days = _to_decimal(days_to_maturity)
    if face <= 0 or px <= 0 or days <= 0:
        raise AnalyticsError.invalid_input("face, price, and days must be positive for CD yield.")
    return (face - px) / px * (Decimal(360) / days) * Decimal(100)


def money_market_yield(face_value: object, price: object, days_to_maturity: object) -> Decimal:
    """Convenience wrapper returning a money-market yield.

    We default to the bond-equivalent conversion for fixed-income cash products.
    """

    return bond_equivalent_yield(face_value, price, days_to_maturity)


def money_market_yield_with_horizon(
    face_value: object,
    price: object,
    days_to_maturity: object,
    horizon_days: object,
) -> Decimal:
    """Money-market yield over a shorter investment horizon.

    This is a simplified wrapper that assumes a single holding period.
    """

    _ = _to_decimal(horizon_days)
    return money_market_yield(face_value, price, days_to_maturity)


__all__ = [
    "discount_yield",
    "bond_equivalent_yield",
    "cd_equivalent_yield",
    "money_market_yield",
    "money_market_yield_with_horizon",
]
