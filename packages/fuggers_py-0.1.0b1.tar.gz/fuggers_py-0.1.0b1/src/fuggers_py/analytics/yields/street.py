"""Street-convention yield (`fuggers_py.analytics.yields.street`)."""

from __future__ import annotations

from fuggers_py.bonds.types import YieldConvention

from .solver import YieldSolver


def street_convention_yield(
    dirty_price: float,
    cashflows: list[float],
    times: list[float],
    *,
    frequency: int,
    initial_guess: float | None = None,
) -> float:
    solver = YieldSolver()
    result = solver.solve(
        dirty_price=float(dirty_price),
        cashflows=[float(cf) for cf in cashflows],
        times=[float(t) for t in times],
        frequency=int(frequency),
        convention=YieldConvention.STREET_CONVENTION,
        initial_guess=initial_guess,
    )
    return float(result.yield_value)


__all__ = ["street_convention_yield"]
