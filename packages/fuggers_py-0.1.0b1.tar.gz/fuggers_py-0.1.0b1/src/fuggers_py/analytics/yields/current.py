"""Current yield helpers (`fuggers_py.analytics.yields.current`)."""

from __future__ import annotations

from decimal import Decimal
from typing import NoReturn

from fuggers_py.bonds.errors import BondPricingError
from fuggers_py.bonds.yields import (
    current_yield as _current_yield,
    current_yield_from_amount as _current_yield_from_amount,
    current_yield_from_bond as _current_yield_from_bond,
    current_yield_simple as _current_yield_simple,
)
from ..error import AnalyticsError


def _raise_invalid_input(exc: BondPricingError) -> NoReturn:
    raise AnalyticsError.invalid_input(exc.reason) from exc


def current_yield(coupon_rate: object, clean_price: object) -> Decimal:
    """Current yield from a coupon *rate* and clean price."""

    try:
        return _current_yield(coupon_rate, clean_price)
    except BondPricingError as exc:
        _raise_invalid_input(exc)


def current_yield_from_amount(coupon_amount: object, clean_price: object) -> Decimal:
    """Current yield from a coupon *amount* and clean price."""

    try:
        return _current_yield_from_amount(coupon_amount, clean_price)
    except BondPricingError as exc:
        _raise_invalid_input(exc)


def current_yield_from_bond(bond: object, clean_price: object) -> Decimal:
    """Current yield from a bond instance that exposes `coupon_rate` and `notional`."""

    try:
        return _current_yield_from_bond(bond, clean_price)
    except BondPricingError as exc:
        _raise_invalid_input(exc)


def current_yield_simple(coupon_rate: float, clean_price: float) -> float:
    try:
        return _current_yield_simple(coupon_rate, clean_price)
    except BondPricingError as exc:
        _raise_invalid_input(exc)


__all__ = [
    "current_yield",
    "current_yield_from_amount",
    "current_yield_from_bond",
    "current_yield_simple",
]
