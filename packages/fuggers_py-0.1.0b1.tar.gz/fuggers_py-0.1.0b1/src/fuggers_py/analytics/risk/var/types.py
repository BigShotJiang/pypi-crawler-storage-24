"""VaR result types (`fuggers_py.analytics.risk.var.types`)."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from enum import Enum


class VaRMethod(str, Enum):
    HISTORICAL = "HISTORICAL"
    PARAMETRIC = "PARAMETRIC"


@dataclass(frozen=True, slots=True)
class VaRResult:
    value: Decimal
    confidence: Decimal
    method: VaRMethod


__all__ = ["VaRMethod", "VaRResult"]
