"""Modified duration (`fuggers_py.analytics.risk.duration.modified`)."""

from __future__ import annotations

from decimal import Decimal

from fuggers_py.bonds.risk import RiskMetrics
from fuggers_py.bonds.traits import Bond
from fuggers_py.core.types import Date, Yield


def modified_duration(bond: Bond, ytm: Yield, settlement_date: Date) -> Decimal:
    metrics = RiskMetrics.from_bond(bond, ytm, settlement_date)
    return metrics.modified_duration


def modified_from_macaulay(macaulay: Decimal, ytm: Yield, *, frequency: int | None = None) -> Decimal:
    if frequency is None:
        frequency = ytm.compounding().periods_per_year() if hasattr(ytm, "compounding") else 2
    freq = int(frequency) if frequency else 1
    return macaulay / (Decimal(1) + (ytm.value() / Decimal(freq)))


__all__ = ["modified_duration", "modified_from_macaulay"]
