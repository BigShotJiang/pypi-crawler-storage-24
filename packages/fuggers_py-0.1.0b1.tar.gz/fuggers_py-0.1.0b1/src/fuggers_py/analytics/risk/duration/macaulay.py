"""Macaulay duration (`fuggers_py.analytics.risk.duration.macaulay`)."""

from __future__ import annotations

from decimal import Decimal

from fuggers_py.bonds.risk import RiskMetrics
from fuggers_py.bonds.traits import Bond
from fuggers_py.core.types import Date, Yield


def macaulay_duration(bond: Bond, ytm: Yield, settlement_date: Date) -> Decimal:
    metrics = RiskMetrics.from_bond(bond, ytm, settlement_date)
    return metrics.macaulay_duration


__all__ = ["macaulay_duration"]
