"""Compatibility comparison surface for portfolio benchmark analytics."""

from __future__ import annotations

from ..benchmark.comparison import (
    ActiveWeight,
    ActiveWeights,
    BenchmarkComparison,
    BenchmarkMetrics,
    DurationComparison,
    PortfolioBenchmark,
    RatingComparison,
    RiskComparison,
    SectorComparison,
    SpreadComparison,
    YieldComparison,
    active_weights,
    benchmark_comparison,
    compare_portfolios,
)
from ..benchmark.tracking import TrackingErrorEstimate, estimate_tracking_error

__all__ = [
    "ActiveWeight",
    "ActiveWeights",
    "BenchmarkComparison",
    "BenchmarkMetrics",
    "DurationComparison",
    "PortfolioBenchmark",
    "RatingComparison",
    "RiskComparison",
    "SectorComparison",
    "SpreadComparison",
    "TrackingErrorEstimate",
    "YieldComparison",
    "active_weights",
    "benchmark_comparison",
    "compare_portfolios",
    "estimate_tracking_error",
]
