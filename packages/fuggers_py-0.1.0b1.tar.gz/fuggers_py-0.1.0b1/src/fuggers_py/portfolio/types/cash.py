"""Cash position types."""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal

from fuggers_py.core.types import Currency


def _to_decimal(value: object) -> Decimal:
    if isinstance(value, Decimal):
        return value
    return Decimal(str(value))


@dataclass(frozen=True, slots=True)
class CashPosition:
    amount: Decimal
    currency: Currency
    label: str = "cash"
    fx_rate: Decimal = Decimal(1)

    def __post_init__(self) -> None:
        object.__setattr__(self, "amount", _to_decimal(self.amount))
        object.__setattr__(self, "fx_rate", _to_decimal(self.fx_rate))

    def market_value(self) -> Decimal:
        return self.amount

    @property
    def base_currency_value(self) -> Decimal:
        return self.amount * self.fx_rate


__all__ = ["CashPosition"]
