"""Classification types used by research portfolio analytics."""

from __future__ import annotations

from dataclasses import dataclass, field

from fuggers_py.bonds.types import CreditRating, RatingInfo, Sector, SectorInfo, Seniority, SeniorityInfo
from fuggers_py.core.types import Currency


@dataclass(frozen=True, slots=True)
class Classification:
    sector: Sector | None = None
    rating: CreditRating | None = None
    seniority: Seniority | None = None
    country: str | None = None
    currency: Currency | None = None
    issuer: str | None = None
    region: str | None = None
    custom_fields: dict[str, str] = field(default_factory=dict)


__all__ = [
    "Classification",
    "CreditRating",
    "RatingInfo",
    "Sector",
    "SectorInfo",
    "Seniority",
    "SeniorityInfo",
]
