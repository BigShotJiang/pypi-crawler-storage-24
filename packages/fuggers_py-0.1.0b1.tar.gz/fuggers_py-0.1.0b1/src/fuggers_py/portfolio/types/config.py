"""Analytics configuration objects."""

from __future__ import annotations

from dataclasses import dataclass

from fuggers_py.bonds.types import Tenor
from fuggers_py.core.types import Currency, Date
from fuggers_py.curves.bumping import STANDARD_KEY_TENORS

from .weighting import WeightingMethod


@dataclass(frozen=True, slots=True)
class AnalyticsConfig:
    settlement_date: Date | None = None
    weighting_method: WeightingMethod = WeightingMethod.DIRTY_VALUE
    key_rate_tenors: tuple[Tenor, ...] = STANDARD_KEY_TENORS
    default_currency: Currency = Currency.USD


__all__ = ["AnalyticsConfig"]
