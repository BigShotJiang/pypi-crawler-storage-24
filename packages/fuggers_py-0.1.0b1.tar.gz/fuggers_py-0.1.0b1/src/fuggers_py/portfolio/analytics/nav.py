"""NAV breakdown helpers."""

from __future__ import annotations

from ..portfolio import Portfolio
from ..results import NavBreakdown
from .base import PortfolioAnalytics


def calculate_nav_breakdown(portfolio: Portfolio, *, curve, settlement_date) -> NavBreakdown:
    metrics = PortfolioAnalytics(portfolio).metrics(curve, settlement_date)
    return NavBreakdown(
        clean_pv=metrics.clean_pv,
        dirty_pv=metrics.dirty_pv,
        accrued=metrics.accrued,
        market_value=metrics.total_market_value,
        dirty_market_value=metrics.total_dirty_market_value,
        cash_value=metrics.cash_value,
    )


__all__ = ["calculate_nav_breakdown"]
