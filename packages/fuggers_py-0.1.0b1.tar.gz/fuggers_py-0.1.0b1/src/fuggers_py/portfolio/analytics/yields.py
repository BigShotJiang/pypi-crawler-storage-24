"""Yield-focused portfolio analytics."""

from __future__ import annotations

from decimal import Decimal

from ..portfolio import Portfolio
from .base import PortfolioAnalytics


def weighted_ytm(portfolio: Portfolio, *, curve, settlement_date) -> Decimal:
    return PortfolioAnalytics(portfolio).metrics(curve, settlement_date).ytm


def weighted_ytw(portfolio: Portfolio, *, curve, settlement_date) -> Decimal:
    return PortfolioAnalytics(portfolio).metrics(curve, settlement_date).ytw


def weighted_ytc(portfolio: Portfolio, *, curve, settlement_date) -> Decimal:
    return PortfolioAnalytics(portfolio).metrics(curve, settlement_date).ytc


def weighted_current_yield(portfolio: Portfolio, *, curve, settlement_date) -> Decimal:
    return PortfolioAnalytics(portfolio).metrics(curve, settlement_date).current_yield


def calculate_yield_metrics(portfolio: Portfolio, *, curve, settlement_date) -> dict[str, Decimal]:
    metrics = PortfolioAnalytics(portfolio).metrics(curve, settlement_date)
    return {
        "ytm": metrics.ytm,
        "ytw": metrics.ytw,
        "ytc": metrics.ytc,
        "current_yield": metrics.current_yield,
        "best_yield": metrics.best_yield,
    }

__all__ = ["calculate_yield_metrics", "weighted_current_yield", "weighted_ytc", "weighted_ytm", "weighted_ytw"]
