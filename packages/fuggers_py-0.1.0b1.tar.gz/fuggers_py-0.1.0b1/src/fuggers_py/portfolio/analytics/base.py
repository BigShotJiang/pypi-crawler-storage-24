"""Base portfolio analytics class."""

from __future__ import annotations

from dataclasses import dataclass

from fuggers_py.analytics.spreads import OASCalculator
from fuggers_py.core.traits import YieldCurve
from fuggers_py.core.types import Date

from .._analytics_utils import aggregate_metrics, position_analytics
from ..portfolio import Portfolio
from ..types import AnalyticsConfig, PortfolioMetrics, PositionAnalytics


@dataclass(frozen=True, slots=True)
class PortfolioAnalytics:
    portfolio: Portfolio

    def position_metrics(
        self,
        curve: YieldCurve | None,
        settlement_date: Date,
        *,
        config: AnalyticsConfig | None = None,
        spread_curve: YieldCurve | None = None,
        oas_calculator: OASCalculator | None = None,
    ) -> list[PositionAnalytics]:
        active_config = config or AnalyticsConfig(settlement_date=settlement_date, default_currency=self.portfolio.currency)
        return [
            position_analytics(
                position,
                curve=curve,
                settlement_date=settlement_date,
                config=active_config,
                spread_curve=spread_curve,
                oas_calculator=oas_calculator,
            )
            for position in self.portfolio.positions
        ]

    def metrics(
        self,
        curve: YieldCurve | None,
        settlement_date: Date,
        *,
        config: AnalyticsConfig | None = None,
        spread_curve: YieldCurve | None = None,
        oas_calculator: OASCalculator | None = None,
    ) -> PortfolioMetrics:
        active_config = config or AnalyticsConfig(settlement_date=settlement_date, default_currency=self.portfolio.currency)
        analytics_list = self.position_metrics(
            curve,
            settlement_date,
            config=active_config,
            spread_curve=spread_curve,
            oas_calculator=oas_calculator,
        )
        return aggregate_metrics(
            analytics_list,
            currency=self.portfolio.currency,
            weighting_method=active_config.weighting_method,
        )


__all__ = ["PortfolioAnalytics"]
