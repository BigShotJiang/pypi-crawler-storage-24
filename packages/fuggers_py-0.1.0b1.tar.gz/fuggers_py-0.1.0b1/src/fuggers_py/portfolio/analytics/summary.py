"""High-level portfolio summary helpers."""

from __future__ import annotations

from ..portfolio import Portfolio
from ..types import AnalyticsConfig
from .base import PortfolioAnalytics


def calculate_portfolio_analytics(
    portfolio: Portfolio,
    *,
    curve,
    settlement_date,
    config: AnalyticsConfig | None = None,
):
    return PortfolioAnalytics(portfolio).metrics(curve, settlement_date, config=config)


__all__ = ["calculate_portfolio_analytics"]
