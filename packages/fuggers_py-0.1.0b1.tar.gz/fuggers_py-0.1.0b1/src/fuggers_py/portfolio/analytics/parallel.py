"""Parallel-shift helpers."""

from __future__ import annotations

from decimal import Decimal

from ..portfolio import Portfolio
from ..stress import parallel_shift_impact
from ..types import StressResult


def parallel_rate_impact(portfolio: Portfolio, *, curve, settlement_date, bump_bps: Decimal) -> StressResult:
    return parallel_shift_impact(portfolio, curve=curve, settlement_date=settlement_date, bump_bps=bump_bps)


__all__ = ["parallel_rate_impact", "parallel_shift_impact"]
