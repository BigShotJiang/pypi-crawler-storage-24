"""Portfolio analytics package."""

from __future__ import annotations

from .base import PortfolioAnalytics
from .credit import calculate_credit_quality
from .key_rates import aggregate_key_rate_profile, partial_dv01s
from .liquidity import calculate_liquidity_metrics, estimate_days_to_liquidate
from .nav import calculate_nav_breakdown
from ..results import KeyRateProfile, NavBreakdown
from .risk import calculate_risk_metrics, total_cs01, total_dv01, weighted_convexity, weighted_duration, weighted_spread_duration
from .spreads import calculate_spread_metrics, weighted_asw, weighted_oas, weighted_spreads
from .summary import calculate_portfolio_analytics
from .yields import calculate_yield_metrics, weighted_current_yield, weighted_ytc, weighted_ytm, weighted_ytw


__all__ = [
    "KeyRateProfile",
    "NavBreakdown",
    "PortfolioAnalytics",
    "aggregate_key_rate_profile",
    "calculate_credit_quality",
    "calculate_liquidity_metrics",
    "calculate_nav_breakdown",
    "calculate_portfolio_analytics",
    "calculate_risk_metrics",
    "calculate_spread_metrics",
    "calculate_yield_metrics",
    "estimate_days_to_liquidate",
    "partial_dv01s",
    "total_cs01",
    "total_dv01",
    "weighted_asw",
    "weighted_convexity",
    "weighted_current_yield",
    "weighted_duration",
    "weighted_oas",
    "weighted_spread_duration",
    "weighted_spreads",
    "weighted_ytc",
    "weighted_ytm",
    "weighted_ytw",
]
