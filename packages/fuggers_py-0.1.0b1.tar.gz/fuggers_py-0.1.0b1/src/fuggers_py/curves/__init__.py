"""Curve layer (`fuggers_py.curves`).

This package provides term-structure primitives and simple builders on top of
the `core` and `math` layers.
"""

from __future__ import annotations

from fuggers_py.bonds.types import Tenor
from fuggers_py.core.types import Compounding, Currency
from fuggers_py.math import (
    CubicSpline,
    Interpolator,
    LinearInterpolator,
    LogLinearInterpolator,
    MonotoneConvex,
    NelsonSiegel,
    Svensson,
)

from .builder import CurveBuilder, CurveFamily, CurveInstrument, InstrumentType, SegmentBuilder
from .builders import DiscountCurveBuilder, ZeroCurveBuilder
from .bumping import (
    ArcBumpedCurve,
    ArcKeyRateBumpedCurve,
    ArcScenarioCurve,
    BumpedCurve,
    KeyRateBump,
    KeyRateBumpedCurve,
    ParallelBump,
    Scenario,
    ScenarioBump,
    ScenarioCurve,
    STANDARD_KEY_TENORS,
    flattener_50bp,
    key_rate_profile,
    parallel_down_50bp,
    parallel_up_50bp,
    steepener_50bp,
)
from .calibration import (
    CalibrationInstrumentResult,
    CalibrationResult,
    BasisSwap,
    CalibrationInstrument,
    Deposit,
    FitterConfig,
    Fra,
    Future,
    GlobalFitResult,
    GlobalFitter,
    InstrumentSet,
    Ois,
    ParametricModel,
    PiecewiseBootstrapper,
    SequentialBootstrapper,
    Swap,
)
from .conversion import ValueConverter
from .curves import (
    CurveTransform,
    DelegatedCurve,
    DelegationFallback,
    DerivedCurve,
    DiscreteCurve,
    ExtrapolationMethod,
    ForwardCurve,
    InterpolationMethod,
    SegmentSource,
    SegmentedCurve,
)
from .errors import *  # noqa: F403
from .multicurve import CurrencyPair, MissingCurveError, MultiCurveEnvironment, MultiCurveEnvironmentBuilder, RateIndex
from .term_structure import TermStructure
from .value_type import ValueType, ValueTypeKind
from .wrappers import CreditCurve, CurveRef, DiscountCurve, RateCurve

# Backwards-compatible aliases for analytics layer expectations.
Curve = TermStructure
CurveError = CurvesError
RateCurveDyn = RateCurve
ZeroCurve = RateCurve

__all__ = [
    # Types
    "Compounding",
    "Currency",
    "Tenor",
    "ValueTypeKind",
    "ValueType",
    "ValueConverter",
    # Term structures / curves
    "Curve",
    "CurveRef",
    "CurveError",
    "TermStructure",
    "InterpolationMethod",
    "ExtrapolationMethod",
    "DiscreteCurve",
    "ForwardCurve",
    # Wrappers
    "DiscountCurve",
    "RateCurve",
    "CreditCurve",
    "RateCurveDyn",
    "ZeroCurve",
    # Interpolation / models
    "Interpolator",
    "LinearInterpolator",
    "LogLinearInterpolator",
    "CubicSpline",
    "MonotoneConvex",
    "NelsonSiegel",
    "Svensson",
    # Builders
    "DiscountCurveBuilder",
    "ZeroCurveBuilder",
    "CurveBuilder",
    "CurveFamily",
    "SegmentBuilder",
    "CurveInstrument",
    "InstrumentType",
    # Calibration
    "CalibrationInstrument",
    "Deposit",
    "Fra",
    "Future",
    "Ois",
    "Swap",
    "BasisSwap",
    "InstrumentSet",
    "CalibrationInstrumentResult",
    "CalibrationResult",
    "SequentialBootstrapper",
    "PiecewiseBootstrapper",
    "ParametricModel",
    "FitterConfig",
    "GlobalFitResult",
    "GlobalFitter",
    # Bumping
    "ParallelBump",
    "KeyRateBump",
    "Scenario",
    "ScenarioBump",
    "BumpedCurve",
    "KeyRateBumpedCurve",
    "ScenarioCurve",
    "ArcBumpedCurve",
    "ArcKeyRateBumpedCurve",
    "ArcScenarioCurve",
    "STANDARD_KEY_TENORS",
    "key_rate_profile",
    "parallel_up_50bp",
    "parallel_down_50bp",
    "steepener_50bp",
    "flattener_50bp",
    # Composed curves
    "CurveTransform",
    "DelegationFallback",
    "DelegatedCurve",
    "DerivedCurve",
    "SegmentSource",
    "SegmentedCurve",
    # Multicurve
    "CurrencyPair",
    "RateIndex",
    "MultiCurveEnvironment",
    "MultiCurveEnvironmentBuilder",
    "MissingCurveError",
]
