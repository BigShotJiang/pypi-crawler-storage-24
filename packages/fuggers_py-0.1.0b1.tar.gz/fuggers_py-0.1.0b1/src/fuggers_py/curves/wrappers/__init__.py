"""Convenience wrappers for curve primitives."""

from __future__ import annotations

from .credit_curve import CreditCurve
from .curve_ref import CurveRef
from .rate_curve import RateCurve

DiscountCurve = RateCurve

__all__ = ["RateCurve", "DiscountCurve", "CreditCurve", "CurveRef"]
