"""Lightweight wrapper for curve references."""

from __future__ import annotations

from dataclasses import dataclass

from ..term_structure import TermStructure
from .rate_curve import RateCurve


CurveLike = TermStructure | RateCurve


@dataclass(frozen=True, slots=True)
class CurveRef:
    curve: CurveLike

    @classmethod
    def of(cls, curve: CurveLike | "CurveRef") -> "CurveRef":
        if isinstance(curve, cls):
            return curve
        return cls(curve=curve)

    def unwrap(self) -> CurveLike:
        return self.curve

    def as_curve(self) -> TermStructure:
        if isinstance(self.curve, RateCurve):
            return self.curve.curve
        return self.curve

    def as_discount_curve(self) -> RateCurve:
        if isinstance(self.curve, RateCurve):
            return self.curve
        return RateCurve(self.curve)

    def reference_date(self):
        return self.curve.reference_date()

    def max_date(self):
        return self.curve.max_date()

    def __getattr__(self, name: str):
        return getattr(self.curve, name)


__all__ = ["CurveRef", "CurveLike"]
