"""Exception hierarchy for `fuggers_py.curves`."""

from __future__ import annotations

from dataclasses import dataclass

from fuggers_py.core.errors import FuggersError


class CurvesError(FuggersError):
    """Base exception for all curve-layer failures."""


class CurveConstructionError(CurvesError):
    """Raised when building a curve fails."""


class InvalidCurveInput(CurvesError):
    """Raised when curve inputs are invalid or inconsistent."""


@dataclass(frozen=True, slots=True)
class TenorOutOfBounds(CurvesError):
    t: float
    min: float
    max: float

    def __str__(self) -> str:
        return f"Tenor {self.t:.6g} out of bounds (range=[{self.min:.6g}, {self.max:.6g}])."


class UnsupportedValueType(CurvesError):
    """Raised when a curve value type is not supported for an operation."""


class UnsupportedConversion(CurvesError):
    """Raised when a conversion between curve value types is not supported."""


class BuilderError(CurveConstructionError):
    """Raised when a builder is misused (e.g., mixing pillar types)."""


class MixedPillarTypes(BuilderError):
    """Raised when mixing discount-factor and zero-rate pillars in a single builder."""


__all__ = [
    "CurvesError",
    "CurveConstructionError",
    "InvalidCurveInput",
    "TenorOutOfBounds",
    "UnsupportedValueType",
    "UnsupportedConversion",
    "BuilderError",
    "MixedPillarTypes",
]
