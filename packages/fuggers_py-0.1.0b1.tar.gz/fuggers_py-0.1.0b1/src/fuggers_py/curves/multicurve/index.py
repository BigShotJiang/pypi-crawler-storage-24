"""Index identifiers for multi-curve environments (`fuggers_py.curves.multicurve.index`)."""

from __future__ import annotations

from dataclasses import dataclass

from fuggers_py.bonds.types import Tenor
from fuggers_py.core.types import Currency


@dataclass(frozen=True, slots=True)
class CurrencyPair:
    base: Currency
    quote: Currency

    def code(self) -> str:
        return f"{self.base.code()}/{self.quote.code()}"

    def inverse(self) -> "CurrencyPair":
        return CurrencyPair(base=self.quote, quote=self.base)

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.code()


@dataclass(frozen=True, slots=True)
class RateIndex:
    name: str
    tenor: Tenor
    currency: Currency

    @classmethod
    def new(cls, name: str, tenor: Tenor, currency: Currency) -> "RateIndex":
        if not isinstance(name, str) or not name.strip():
            raise ValueError("RateIndex name must be a non-empty string.")
        return cls(name=name.strip().upper(), tenor=tenor, currency=currency)

    def key(self) -> str:
        return f"{self.currency.code()}-{self.name}-{self.tenor}"

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.key()


__all__ = ["CurrencyPair", "RateIndex"]
