"""Simple builders for common rate curves."""

from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal

from fuggers_py.core.daycounts import DayCountConvention
from fuggers_py.core.types import Compounding, Date

from .builder import CurveBuilder, CurveFamily, SegmentBuilder
from .curves.discrete import DiscreteCurve, ExtrapolationMethod, InterpolationMethod
from .errors import BuilderError, MixedPillarTypes
from .value_type import ValueType
from .wrappers import RateCurve


def _float(x: object) -> float:
    if isinstance(x, Decimal):
        return float(x)
    return float(x)


@dataclass(slots=True)
class DiscountCurveBuilder:
    reference_date: Date
    interpolation_method: InterpolationMethod | None = None
    extrapolation_method: ExtrapolationMethod = ExtrapolationMethod.FLAT
    zero_compounding: Compounding = Compounding.CONTINUOUS
    zero_day_count: DayCountConvention = DayCountConvention.ACT_365_FIXED
    _tenors: list[float] = field(default_factory=list)
    _values: list[float] = field(default_factory=list)
    _pillar_kind: str | None = None  # "df" or "zero"

    def add_pillar(self, tenor: float, discount_factor: object) -> "DiscountCurveBuilder":
        if self._pillar_kind not in (None, "df"):
            raise MixedPillarTypes("Cannot mix discount-factor and zero-rate pillars.")
        self._pillar_kind = "df"
        self._tenors.append(float(tenor))
        self._values.append(_float(discount_factor))
        return self

    def add_zero_rate(self, tenor: float, rate: object) -> "DiscountCurveBuilder":
        if self._pillar_kind not in (None, "zero"):
            raise MixedPillarTypes("Cannot mix discount-factor and zero-rate pillars.")
        self._pillar_kind = "zero"
        self._tenors.append(float(tenor))
        self._values.append(_float(rate))
        return self

    def with_interpolation(self, method: InterpolationMethod) -> "DiscountCurveBuilder":
        self.interpolation_method = method
        return self

    def with_extrapolation(
        self, method: ExtrapolationMethod = ExtrapolationMethod.FLAT
    ) -> "DiscountCurveBuilder":
        self.extrapolation_method = method
        return self

    def build(self) -> RateCurve:
        if not self._tenors:
            raise BuilderError("No pillars added.")
        if self._pillar_kind is None:
            raise BuilderError("Pillar type is unknown; add pillars before building.")

        if self._pillar_kind == "df":
            value_type = ValueType.discount_factor()
            interp_default = InterpolationMethod.LOG_LINEAR
        else:
            value_type = ValueType.zero_rate(self.zero_compounding, self.zero_day_count)
            interp_default = InterpolationMethod.LINEAR

        interpolation = self.interpolation_method or interp_default

        curve = DiscreteCurve(
            self.reference_date,
            self._tenors,
            self._values,
            value_type=value_type,
            interpolation_method=interpolation,
            extrapolation_method=self.extrapolation_method,
        )
        return RateCurve(curve)


@dataclass(slots=True)
class ZeroCurveBuilder:
    reference_date: Date
    day_count: DayCountConvention = DayCountConvention.ACT_365_FIXED
    compounding: Compounding = Compounding.CONTINUOUS
    interpolation_method: InterpolationMethod = InterpolationMethod.LINEAR
    extrapolation_method: ExtrapolationMethod = ExtrapolationMethod.FLAT
    _dates: list[Date] = field(default_factory=list)
    _rates: list[float] = field(default_factory=list)

    def add_rate(self, date: Date, rate: object) -> "ZeroCurveBuilder":
        if date < self.reference_date:
            raise BuilderError("ZeroCurveBuilder requires dates on/after the reference date.")
        self._dates.append(date)
        self._rates.append(_float(rate))
        return self

    def with_interpolation(self, method: InterpolationMethod) -> "ZeroCurveBuilder":
        self.interpolation_method = method
        return self

    def with_extrapolation(self, method: ExtrapolationMethod = ExtrapolationMethod.FLAT) -> "ZeroCurveBuilder":
        self.extrapolation_method = method
        return self

    def build(self) -> RateCurve:
        if not self._dates:
            raise BuilderError("No rates added.")

        dc = self.day_count.to_day_count()
        tenors = [float(dc.year_fraction(self.reference_date, d)) for d in self._dates]
        value_type = ValueType.zero_rate(self.compounding, self.day_count)

        curve = DiscreteCurve(
            self.reference_date,
            tenors,
            self._rates,
            value_type=value_type,
            interpolation_method=self.interpolation_method,
            extrapolation_method=self.extrapolation_method,
        )
        return RateCurve(curve)


__all__ = [
    "CurveBuilder",
    "CurveFamily",
    "DiscountCurveBuilder",
    "SegmentBuilder",
    "ZeroCurveBuilder",
]
