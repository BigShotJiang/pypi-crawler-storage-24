"""Curve bumping helpers (`fuggers_py.curves.bumping`)."""

from __future__ import annotations

from fuggers_py.bonds.types import Tenor

from .key_rate import KeyRateBump, KeyRateBumpedCurve
from .parallel import BumpedCurve, ParallelBump
from .scenario import (
    Scenario,
    ScenarioCurve,
    flattener_50bp,
    parallel_down_50bp,
    parallel_up_50bp,
    steepener_50bp,
)

ScenarioBump = Scenario
ArcBumpedCurve = BumpedCurve
ArcKeyRateBumpedCurve = KeyRateBumpedCurve
ArcScenarioCurve = ScenarioCurve
STANDARD_KEY_TENORS = (
    Tenor.parse("3M"),
    Tenor.parse("6M"),
    Tenor.parse("1Y"),
    Tenor.parse("2Y"),
    Tenor.parse("3Y"),
    Tenor.parse("5Y"),
    Tenor.parse("7Y"),
    Tenor.parse("10Y"),
    Tenor.parse("20Y"),
    Tenor.parse("30Y"),
)


def key_rate_profile(
    key_tenor: Tenor,
    *,
    tenors: tuple[Tenor, ...] = STANDARD_KEY_TENORS,
    bump: float = 1e-4,
) -> dict[Tenor, float]:
    scenario = KeyRateBump(list(tenors), key_tenor, bump)
    return {tenor: float(scenario.bump_at(tenor)) for tenor in tenors}

__all__ = [
    "ParallelBump",
    "KeyRateBump",
    "Scenario",
    "ScenarioBump",
    "BumpedCurve",
    "KeyRateBumpedCurve",
    "ScenarioCurve",
    "ArcBumpedCurve",
    "ArcKeyRateBumpedCurve",
    "ArcScenarioCurve",
    "STANDARD_KEY_TENORS",
    "key_rate_profile",
    "parallel_up_50bp",
    "parallel_down_50bp",
    "steepener_50bp",
    "flattener_50bp",
]
