"""Core exception hierarchy for `fuggers_py`."""

from __future__ import annotations


class FuggersError(Exception):
    """Base exception for all `fuggers_py.core` domain errors."""


class InvalidDateError(FuggersError):
    """Raised when a `Date` cannot be constructed or parsed."""


class PricingError(FuggersError):
    """Raised when pricing logic fails in a domain-specific way."""


class ConvergenceFailedError(FuggersError):
    """Raised when an iterative numerical method fails to converge."""


class InvalidYieldError(FuggersError):
    """Raised when a `Yield` is invalid or out of supported bounds."""


class InvalidPriceError(FuggersError):
    """Raised when a `Price` is invalid (e.g., non-positive)."""


class InvalidSpreadError(FuggersError):
    """Raised when a `Spread` is invalid or misused (e.g., type mismatch)."""


class CurveNotFoundError(FuggersError):
    """Raised when a required curve cannot be found by identifier."""


class CurveConstructionFailedError(FuggersError):
    """Raised when building / bootstrapping a curve fails."""


class InterpolationError(FuggersError):
    """Raised when interpolation fails or is misconfigured."""


class InvalidCashFlowError(FuggersError):
    """Raised when a `CashFlow` is invalid (e.g., missing required metadata)."""


class InvalidBondSpecError(FuggersError):
    """Raised when a bond specification is invalid or inconsistent."""


class DayCountError(FuggersError):
    """Raised when a day-count calculation fails."""


class CalendarError(FuggersError):
    """Raised when a calendar operation fails."""


class MathError(FuggersError):
    """Raised when a mathematical operation fails unexpectedly."""


class ConfigError(FuggersError):
    """Raised when configuration is invalid or missing."""


__all__ = [
    "FuggersError",
    "InvalidDateError",
    "PricingError",
    "ConvergenceFailedError",
    "InvalidYieldError",
    "InvalidPriceError",
    "InvalidSpreadError",
    "CurveNotFoundError",
    "CurveConstructionFailedError",
    "InterpolationError",
    "InvalidCashFlowError",
    "InvalidBondSpecError",
    "DayCountError",
    "CalendarError",
    "MathError",
    "ConfigError",
]
