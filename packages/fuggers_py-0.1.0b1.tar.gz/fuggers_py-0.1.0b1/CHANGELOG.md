# Changelog

## 0.1.0

Initial release-focused cut of the Python analytics port.

### Added

- `core`: dates, prices, yields, spreads, calendars, day counts, and abstract curve/pricing/risk traits
- `math`: solvers, interpolation, extrapolation, optimization, and linear algebra helpers
- `curves`: discrete/wrapped curves, builders, calibration helpers, bumping, and multi-curve support
- `bonds`: fixed-rate, zero-coupon, callable/putable, floating-rate, sinking-fund, index/fixing, and option-model workflows
- `analytics`: yield, risk, spread, OAS, discount-margin, asset-swap, and YAS calculations
- `portfolio`: holdings, ETF helpers, aggregation, stress, benchmark, credit, and key-rate tooling
- `data`: typed ids, market/reference data, pricing specs, outputs, and in-memory research providers
- `io`: file-backed providers, JSON codecs, SQLite-backed embedded storage, and storage/transport interfaces
- `engine`: sync pricing router, batch pricing, curve builder, calculation graph, schedulers, market-data listener, builder, and reactive orchestration
- deterministic examples, golden validations, benchmark harness, and release smoke coverage

### Scope

- This package targets Python analytics and research orchestration workflows.
- Deterministic local adapters and notebook-friendly APIs are first-class.
- Server runtimes, WASM, FFI bindings, MCP surfaces, and distributed service infrastructure remain out of scope for this release.

### Changed

- historical compatibility namespaces such as `fuggers_py.prelude`, `fuggers_py.traits`, and `fuggers_py.ext` are removed from the current public surface
- removed the redundant top-level `fuggers_py.spreads` namespace
- `fuggers_py.analytics.spreads` is the canonical spread namespace
