from __future__ import annotations

import pytest

import fuggers_py.engine as engine
import fuggers_py.engine.scheduler as scheduler_module

from fuggers_py.engine.calc_graph import NodeId
from fuggers_py.engine.errors import SchedulerError


def test_engine_public_api_stays_importable_without_engine_extra(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setattr(scheduler_module, "croniter", None)

    interval = engine.IntervalScheduler([NodeId("price:ABC")], interval_seconds=60.0)

    assert interval.interval_seconds == 60.0
    with pytest.raises(SchedulerError, match="croniter"):
        engine.CronScheduler([NodeId("curve:usd")], expression="0 * * * *")
