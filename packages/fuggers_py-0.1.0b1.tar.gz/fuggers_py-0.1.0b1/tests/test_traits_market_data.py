from __future__ import annotations

from datetime import datetime
from decimal import Decimal

from fuggers_py.core import Currency, Date
from fuggers_py.data import (
    CurveId,
    CurveInputs,
    CurvePoint,
    InMemoryFixingSource,
    InMemoryQuoteSource,
    IndexFixing,
    InstrumentId,
    QuoteSide,
    RawQuote,
)


def test_raw_quote_curve_inputs_and_fixing_sources() -> None:
    instrument_id = InstrumentId("US0000000001")
    quote = RawQuote(
        instrument_id=instrument_id,
        value=Decimal("101.25"),
        side=QuoteSide.MID,
        as_of=Date.from_ymd(2026, 1, 15),
        timestamp=datetime(2026, 1, 15, 9, 30),
        currency=Currency.USD,
    )
    assert quote.side is QuoteSide.MID
    assert quote.as_of == Date.from_ymd(2026, 1, 15)
    assert quote.timestamp == datetime(2026, 1, 15, 9, 30)

    inputs = CurveInputs.from_points(
        CurveId("usd.discount"),
        Date.from_ymd(2026, 1, 15),
        [
            CurvePoint(Decimal("5.0"), Decimal("0.04")),
            CurvePoint(Decimal("1.0"), Decimal("0.045")),
            CurvePoint(Decimal("2.0"), Decimal("0.043")),
        ],
    )
    assert list(inputs.tenors()) == [Decimal("1.0"), Decimal("2.0"), Decimal("5.0")]

    quote_source = InMemoryQuoteSource([quote])
    assert quote_source.get_quote(instrument_id, QuoteSide.MID) == quote

    fixing = IndexFixing("SOFR", Date.from_ymd(2026, 1, 14), Decimal("0.0410"))
    fixing_source = InMemoryFixingSource([fixing])
    assert fixing_source.get_fixing("SOFR", Date.from_ymd(2026, 1, 14)) == fixing
    assert fixing_source.get_rate("SOFR", Date.from_ymd(2026, 1, 14)) == Decimal("0.0410")
