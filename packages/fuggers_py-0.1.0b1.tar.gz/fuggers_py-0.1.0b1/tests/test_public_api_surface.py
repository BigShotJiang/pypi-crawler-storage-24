from __future__ import annotations

import importlib
from importlib import metadata

import fuggers_py
import pytest

from fuggers_py.analytics.functions import yield_to_maturity as analytics_yield_to_maturity
from fuggers_py.bonds import FixedBondBuilder as bonds_fixed_bond_builder
from fuggers_py.core import Date as core_date
from fuggers_py.core import Price as core_price
from fuggers_py.curves import RateCurve as curves_rate_curve
from fuggers_py.data import InstrumentId as data_instrument_id
from fuggers_py.engine import PricingRouter as engine_pricing_router
from fuggers_py.portfolio import Portfolio as portfolio_portfolio


def test_explicit_submodule_imports_match_expected_public_symbols() -> None:
    from fuggers_py.analytics.functions import yield_to_maturity
    from fuggers_py.bonds import FixedBondBuilder
    from fuggers_py.core import Date, Price
    from fuggers_py.curves import RateCurve
    from fuggers_py.data import InstrumentId
    from fuggers_py.engine import PricingRouter
    from fuggers_py.portfolio import Portfolio

    assert Date is core_date
    assert Price is core_price
    assert RateCurve is curves_rate_curve
    assert FixedBondBuilder is bonds_fixed_bond_builder
    assert yield_to_maturity is analytics_yield_to_maturity
    assert Portfolio is portfolio_portfolio
    assert InstrumentId is data_instrument_id
    assert PricingRouter is engine_pricing_router


def test_top_level_package_exports_match_current_surface() -> None:
    assert "data" in fuggers_py.__all__
    assert "io" in fuggers_py.__all__
    assert "prelude" not in fuggers_py.__all__
    assert "traits" not in fuggers_py.__all__


def test_top_level_package_version_is_available_and_matches_distribution_metadata() -> None:
    assert fuggers_py.__version__
    assert any(char.isdigit() for char in fuggers_py.__version__)
    assert metadata.version("fuggers-py") == fuggers_py.__version__


@pytest.mark.parametrize(
    "module_name",
    [
        "fuggers_py.prelude",
        "fuggers_py.traits",
        "fuggers_py.ext",
    ],
)
def test_removed_compatibility_namespaces_are_not_importable(module_name: str) -> None:
    with pytest.raises(ModuleNotFoundError):
        importlib.import_module(module_name)
