from __future__ import annotations


def test_analytics_imports() -> None:
    import fuggers_py.analytics as analytics  # noqa: F401

    from fuggers_py.analytics import (  # noqa: F401
        DurationType,
        YieldConvention,
        calculate_modified_duration,
        calculate_yield_to_maturity,
        calculate_z_spread,
    )
    from fuggers_py.analytics.yields import current_yield, simple_yield  # noqa: F401
    from fuggers_py.analytics.pricing import BondPricer, PriceResult  # noqa: F401
