"""Dedicated validation harness package."""
