# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListQuotaResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'ddos_quota': 'QuotaResponseDdosQuota'
    }

    attribute_map = {
        'ddos_quota': 'ddos_quota'
    }

    def __init__(self, ddos_quota=None):
        r"""ListQuotaResponse

        The model defined in huaweicloud sdk

        :param ddos_quota: 
        :type ddos_quota: :class:`huaweicloudsdkantiddos.v1.QuotaResponseDdosQuota`
        """
        
        super().__init__()

        self._ddos_quota = None
        self.discriminator = None

        if ddos_quota is not None:
            self.ddos_quota = ddos_quota

    @property
    def ddos_quota(self):
        r"""Gets the ddos_quota of this ListQuotaResponse.

        :return: The ddos_quota of this ListQuotaResponse.
        :rtype: :class:`huaweicloudsdkantiddos.v1.QuotaResponseDdosQuota`
        """
        return self._ddos_quota

    @ddos_quota.setter
    def ddos_quota(self, ddos_quota):
        r"""Sets the ddos_quota of this ListQuotaResponse.

        :param ddos_quota: The ddos_quota of this ListQuotaResponse.
        :type ddos_quota: :class:`huaweicloudsdkantiddos.v1.QuotaResponseDdosQuota`
        """
        self._ddos_quota = ddos_quota

    def to_dict(self):
        import warnings
        warnings.warn("ListQuotaResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListQuotaResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
