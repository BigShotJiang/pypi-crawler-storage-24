import json
from pathlib import Path

from pymultirole_plugins.v1.schema import Annotation, Document, DocumentList

from pyprocessors_pseudonimizer.pseudonimizer import (
    OPERATOR_IDENTITY_STR,
    PseudonimizerParameters,
    PseudonimizerProcessor,
)


def test_pseudo1():
    testdir = Path(__file__).parent
    source = Path(
        testdir,
        "data/afp_ner_fr-document-test.json",
    )
    with source.open("r") as fin:
        jdoc = json.load(fin)
        doc = Document(**jdoc)
        formatter = PseudonimizerProcessor()
        options = PseudonimizerParameters()
        options.mapping = {
            "wikidata": OPERATOR_IDENTITY_STR,
            "organization": json.dumps(
                {
                    "type": "mask",
                    "masking_char": "X",
                    "chars_to_mask": 3,
                    "from_end": False,
                }
            ),
            "afporganization": json.dumps({"type": "faker", "provider": "company", "locale": "en_US"}),
            "person": json.dumps({"type": "faker", "provider": "name", "locale": "fr_FR"}),
            "afpperson": json.dumps({"type": "faker", "provider": "name", "locale": "fr_FR"}),
        }
        anonymizeds = formatter.process([doc], options)
        norm_file = testdir / "data/afp_ner_fr-document-test-anon.json"
        dl = DocumentList(root=anonymizeds)
        with norm_file.open("w") as fout:
            print(dl.model_dump_json(exclude_none=True, exclude_unset=True, indent=2), file=fout)


def test_pseudo2():
    testdir = Path(__file__).parent
    source = Path(
        testdir,
        "data/terrorisme_ner_v2-document-test.json",
    )
    with source.open("r") as fin:
        jdoc = json.load(fin)
        doc = Document(**jdoc)
        formatter = PseudonimizerProcessor()
        options = PseudonimizerParameters()
        options.mapping = {
            "victimes": json.dumps({"type": "replace", "new_value": "_ANONYMIZED_NB_"}),
            "date": json.dumps({"type": "faker", "provider": "date_between", "locale": "fr_FR"}),
            "organisation": json.dumps(
                {
                    "type": "faker",
                    "provider": "random_element",
                    "elements": ["Al-Qaïda", "FARC", "Boko Haram", "Organisation État islamique"],
                }
            ),
        }
        anonymizeds = formatter.process([doc], options)
        norm_file = testdir / "data/terrorisme_ner_v2-document-test-anon.json"
        dl = DocumentList(root=anonymizeds)
        with norm_file.open("w") as fout:
            print(dl.model_dump_json(exclude_none=True, exclude_unset=True, indent=2), file=fout)


def test_pseudo3():
    testdir = Path(__file__).parent
    source = Path(
        testdir,
        "data/mindspeak_demo-document-test.json",
    )
    with source.open("r") as fin:
        jdoc = json.load(fin)
        doc = Document(**jdoc)
        formatter = PseudonimizerProcessor()
        options = PseudonimizerParameters(default_operator=json.dumps({"type": "redact"}))
        options.mapping = {"person": json.dumps({"type": "replace", "new_value": "_ANONYMIZED_"})}
        anonymizeds = formatter.process([doc], options)
        norm_file = testdir / "data/mindspeak_demo-document-test-anon.json"
        dl = DocumentList(root=anonymizeds)
        with norm_file.open("w") as fout:
            print(dl.model_dump_json(exclude_none=True, exclude_unset=True, indent=2), file=fout)


def _make_doc(text, annotations):
    """Build a Document with inline annotations."""
    return Document(
        text=text,
        annotations=[Annotation(**a) for a in annotations],
    )


def test_get_model():
    assert PseudonimizerProcessor.get_model() is PseudonimizerParameters


def test_no_annotations():
    """Document with no annotations is returned unchanged."""
    doc = Document(text="Nothing to anonymize here.")
    processor = PseudonimizerProcessor()
    options = PseudonimizerParameters()
    result = processor.process([doc], options)
    assert result[0].text == "Nothing to anonymize here."


def test_label_operator():
    """'label' operator replaces entity text with <LabelName>."""
    doc = _make_doc(
        "John Smith works at Acme.",
        [{"start": 0, "end": 10, "label": "person", "labelName": "person", "score": 1.0}],
    )
    processor = PseudonimizerProcessor()
    options = PseudonimizerParameters(as_altText="")
    options.mapping = {"person": json.dumps({"type": "label"})}
    result = processor.process([doc], options)
    assert "<person>" in result[0].text


def test_in_place_replacement():
    """When as_altText is empty the document text is replaced in place."""
    doc = _make_doc(
        "Call me on 0600000000.",
        [{"start": 11, "end": 21, "label": "phone", "labelName": "phone", "score": 1.0}],
    )
    processor = PseudonimizerProcessor()
    options = PseudonimizerParameters(as_altText="")
    options.mapping = {"phone": json.dumps({"type": "replace", "new_value": "XXXXXXXXXX"})}
    result = processor.process([doc], options)
    assert result[0].text == "Call me on XXXXXXXXXX."
    assert result[0].annotations is None


def test_ko_annotations_skipped():
    """Annotations with status='KO' must not be anonymized."""
    doc = _make_doc(
        "Alice and Bob met.",
        [
            {"start": 0, "end": 5, "label": "person", "labelName": "person", "score": 1.0, "status": "KO"},
            {"start": 10, "end": 13, "label": "person", "labelName": "person", "score": 1.0},
        ],
    )
    processor = PseudonimizerProcessor()
    options = PseudonimizerParameters(as_altText="")
    options.mapping = {"person": json.dumps({"type": "replace", "new_value": "_PERSON_"})}
    result = processor.process([doc], options)
    # "Alice" (KO) is kept; "Bob" is replaced
    assert "Alice" in result[0].text
    assert "_PERSON_" in result[0].text


def test_multiple_documents():
    """Multiple documents are each processed independently."""
    docs = [
        _make_doc(
            "Alice is here.",
            [{"start": 0, "end": 5, "label": "person", "labelName": "person", "score": 1.0}],
        ),
        _make_doc(
            "Bob is there.",
            [{"start": 0, "end": 3, "label": "person", "labelName": "person", "score": 1.0}],
        ),
    ]
    processor = PseudonimizerProcessor()
    options = PseudonimizerParameters(as_altText="")
    options.mapping = {"person": json.dumps({"type": "redact"})}
    results = processor.process(docs, options)
    assert len(results) == 2
    assert "Alice" not in results[0].text
    assert "Bob" not in results[1].text


def test_as_alt_text_stored():
    """Result is stored as AltText when as_altText is set."""
    doc = _make_doc(
        "Marie Curie discovered radium.",
        [{"start": 0, "end": 11, "label": "person", "labelName": "person", "score": 1.0}],
    )
    processor = PseudonimizerProcessor()
    options = PseudonimizerParameters(as_altText="anon")
    options.mapping = {"person": json.dumps({"type": "replace", "new_value": "_NAME_"})}
    result = processor.process([doc], options)
    # original text unchanged
    assert result[0].text == "Marie Curie discovered radium."
    alt = next(a for a in result[0].altTexts if a.name == "anon")
    assert "_NAME_" in alt.text
