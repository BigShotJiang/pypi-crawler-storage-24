"""Sample app with known bugs for integration testing."""
import random
from concurrent.futures import ThreadPoolExecutor

# SEC001: Hardcoded secret
API_KEY = "sk-proj-abc123secretkey456"

# SEC002: SQL injection
def get_user(db, user_id):
    return db.execute(f"SELECT * FROM users WHERE id = {user_id}")

# SEC003: eval
def run(user_input):
    return eval(user_input)

# SEC004: Insecure random
def make_token():
    return random.randint(100000, 999999)

# SESS002: Thread session safety
class Processor:
    def run(self):
        with ThreadPoolExecutor() as ex:
            ex.submit(self._work, "x")

    def _work(self, x):
        self.db_session.commit()
