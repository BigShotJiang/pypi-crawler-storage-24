"""Test file with various issues for vibecheck to detect."""

# DET001: Unsorted dict iteration
config = {"z": 1, "a": 2, "m": 3}
for key, value in config.items():
    print(key, value)

# DET002: Unsorted set iteration
items = {3, 1, 4, 1, 5}
for item in set(items):
    print(item)

# DET003: Missing sort tiebreaker
scores = [("alice", 100), ("bob", 100), ("charlie", 90)]
sorted_scores = sorted(scores, key=lambda x: x[1])

# DET004: list(set()) scrambling
names = ["alice", "bob", "alice", "charlie"]
unique_names = list(set(names))

# PERF001: N+1 query pattern
class db:
    @staticmethod
    def get(id):
        return {"id": id}

users = [1, 2, 3, 4, 5]
for user_id in users:
    user = db.get(user_id)
    print(user)

# QUAL001: Swallowed exception
try:
    risky_operation()
except:
    pass

# QUAL002: Unnamed thread
import threading
worker = threading.Thread(target=lambda: print("working"))

# QUAL003: Complex tuple
from typing import Tuple
def process_data() -> Tuple[str, int, float, bool, str]:
    return ("name", 42, 3.14, True, "extra")
