"""Tests for QUAL010: url-state-not-persisted checker."""

import pytest
from pathlib import Path

from stablestack.checkers.quality.url_state_not_persisted import UrlStateNotPersistedChecker


class TestUrlStateNotPersistedChecker:
    """Tests for QUAL010: url-state-not-persisted."""

    @pytest.fixture
    def checker(self):
        return UrlStateNotPersistedChecker()

    def test_detects_active_tab_ref(self, checker, temp_vue_file):
        """Should detect activeTab stored in ref() without URL state."""
        code = '''
<template>
  <div>{{ activeTab }}</div>
</template>

<script setup lang="ts">
import { ref } from 'vue'

const activeTab = ref('overview')
</script>
'''
        path = temp_vue_file(code)
        findings = checker.check_file(path, code)
        assert len(findings) == 1
        assert findings[0].rule_id == "QUAL010"
        assert "activeTab" in findings[0].message

    def test_detects_selected_id_ref(self, checker, temp_vue_file):
        """Should detect selectedId stored in ref() without URL state."""
        code = '''
<template>
  <div>{{ selectedId }}</div>
</template>

<script setup lang="ts">
import { ref } from 'vue'

const selectedId = ref(null)
</script>
'''
        path = temp_vue_file(code)
        findings = checker.check_file(path, code)
        assert len(findings) == 1
        assert "selectedId" in findings[0].message

    def test_detects_multiple_violations(self, checker, temp_vue_file):
        """Should detect multiple state refs that need URL persistence."""
        code = '''
<template>
  <div>{{ activeTab }} - {{ selectedId }}</div>
</template>

<script setup lang="ts">
import { ref } from 'vue'

const activeTab = ref('overview')
const selectedId = ref(null)
const currentPage = ref(1)
</script>
'''
        path = temp_vue_file(code)
        findings = checker.check_file(path, code)
        assert len(findings) == 3

    def test_allows_with_use_route(self, checker, temp_vue_file):
        """Should not flag when useRoute is used."""
        code = '''
<template>
  <div>{{ activeTab }}</div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from 'vue-router'

const route = useRoute()
const activeTab = computed(() => route.params.tab || 'overview')
</script>
'''
        path = temp_vue_file(code)
        findings = checker.check_file(path, code)
        assert len(findings) == 0

    def test_allows_with_use_router(self, checker, temp_vue_file):
        """Should not flag when useRouter is used."""
        code = '''
<template>
  <div>{{ selectedId }}</div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useRouter } from 'vue-router'

const router = useRouter()
const selectedId = ref(null)

function selectItem(id) {
  router.push(`/items/${id}`)
}
</script>
'''
        path = temp_vue_file(code)
        findings = checker.check_file(path, code)
        assert len(findings) == 0

    def test_allows_with_route_params(self, checker, temp_vue_file):
        """Should not flag when route.params is used."""
        code = '''
<template>
  <div>{{ activeTab }}</div>
</template>

<script setup lang="ts">
import { computed } from 'vue'

const activeTab = computed(() => route.params.tab)
</script>
'''
        path = temp_vue_file(code)
        findings = checker.check_file(path, code)
        assert len(findings) == 0

    def test_allows_with_route_query(self, checker, temp_vue_file):
        """Should not flag when route.query is used."""
        code = '''
<template>
  <div>{{ currentPage }}</div>
</template>

<script setup lang="ts">
import { computed } from 'vue'

const currentPage = computed(() => Number(route.query.page) || 1)
</script>
'''
        path = temp_vue_file(code)
        findings = checker.check_file(path, code)
        assert len(findings) == 0

    def test_allows_options_api_route(self, checker, temp_vue_file):
        """Should not flag Options API with $route."""
        code = '''
<template>
  <div>{{ activeTab }}</div>
</template>

<script>
export default {
  computed: {
    activeTab() {
      return this.$route.params.tab
    }
  }
}
</script>
'''
        path = temp_vue_file(code)
        findings = checker.check_file(path, code)
        assert len(findings) == 0

    def test_ignores_non_state_refs(self, checker, temp_vue_file):
        """Should not flag refs that aren't URL-worthy state."""
        code = '''
<template>
  <div>{{ count }}</div>
</template>

<script setup lang="ts">
import { ref } from 'vue'

const count = ref(0)
const isLoading = ref(false)
const userName = ref('')
</script>
'''
        path = temp_vue_file(code)
        findings = checker.check_file(path, code)
        assert len(findings) == 0

    def test_ignores_non_vue_files(self, checker, temp_py_file):
        """Should not check Python files."""
        code = '''
activeTab = ref('overview')
'''
        path = temp_py_file(code)
        # Checker should return empty since it doesn't support .py
        assert not checker.supports_file(path)

    def test_fix_hint_for_tab(self, checker, temp_vue_file):
        """Should provide tab-specific fix hint."""
        code = '''
<script setup>
const activeTab = ref('overview')
</script>
'''
        path = temp_vue_file(code)
        findings = checker.check_file(path, code)
        assert len(findings) == 1
        assert "route.params.tab" in findings[0].fix_hint

    def test_fix_hint_for_id(self, checker, temp_vue_file):
        """Should provide id-specific fix hint."""
        code = '''
<script setup>
const selectedId = ref(null)
</script>
'''
        path = temp_vue_file(code)
        findings = checker.check_file(path, code)
        assert len(findings) == 1
        assert "route.params.itemId" in findings[0].fix_hint

    def test_fix_hint_for_page(self, checker, temp_vue_file):
        """Should provide page-specific fix hint."""
        code = '''
<script setup>
const currentPage = ref(1)
</script>
'''
        path = temp_vue_file(code)
        findings = checker.check_file(path, code)
        assert len(findings) == 1
        assert "route.query.page" in findings[0].fix_hint
