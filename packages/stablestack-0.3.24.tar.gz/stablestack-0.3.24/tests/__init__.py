"""vibecheck test suite."""
