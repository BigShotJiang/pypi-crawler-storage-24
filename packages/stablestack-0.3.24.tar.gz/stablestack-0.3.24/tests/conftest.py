"""Pytest configuration and fixtures for vibecheck tests."""

import pytest
from pathlib import Path


@pytest.fixture
def temp_py_file(tmp_path: Path):
    """Create a temporary Python file for testing."""
    def _create(content: str, name: str = "test_file.py") -> Path:
        file_path = tmp_path / name
        file_path.write_text(content)
        return file_path
    return _create


@pytest.fixture
def temp_ts_file(tmp_path: Path):
    """Create a temporary TypeScript file for testing."""
    def _create(content: str, name: str = "test_file.ts") -> Path:
        file_path = tmp_path / name
        file_path.write_text(content)
        return file_path
    return _create


@pytest.fixture
def temp_js_file(tmp_path: Path):
    """Create a temporary JavaScript file for testing."""
    def _create(content: str, name: str = "test_file.js") -> Path:
        file_path = tmp_path / name
        file_path.write_text(content)
        return file_path
    return _create


@pytest.fixture
def temp_go_file(tmp_path: Path):
    """Create a temporary Go file for testing."""
    def _create(content: str, name: str = "test_file.go") -> Path:
        file_path = tmp_path / name
        file_path.write_text(content)
        return file_path
    return _create


@pytest.fixture
def temp_vue_file(tmp_path: Path):
    """Create a temporary Vue file for testing."""
    def _create(content: str, name: str = "TestComponent.vue") -> Path:
        file_path = tmp_path / name
        file_path.write_text(content)
        return file_path
    return _create
