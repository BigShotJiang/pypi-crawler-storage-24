---
description: "Add deterministic caching to LLM API calls in your project"
version: 1.0.0
---

# /deterministic-ai - Cache LLM API Calls

<objective>
Find all uncached LLM API calls in the project and wrap them with the @cache decorator from stablestack_cache. This eliminates redundant API calls — same prompt, same result, served from disk.
</objective>

<steps>
1. **Verify cache module is installed**
   - Check that `stablestack_cache.py` exists in the project root
   - If not, run `stablestack deterministic-ai` to install it

2. **Find uncached LLM calls**
   - Search for patterns: `.chat.completions.create(`, `.messages.create(`, `.completions.create(`
   - Identify which calls are NOT wrapped with `@cache`

3. **Add caching**
   - For each uncached LLM call, extract it into a cached function if inline
   - Add `from stablestack_cache import cache` to the file's imports
   - Add `@cache` decorator to the function containing the LLM call
   - If the function does more than just the LLM call, extract the LLM call into its own cached helper

4. **Verify**
   - Run `stablestack .` to confirm DET009 findings are resolved
   - Test that cached functions work: first call hits API, second call returns from cache
</steps>

<example>
Before:
```python
def get_summary(text: str) -> str:
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": f"Summarize: {text}"}]
    )
    return response.choices[0].message.content
```

After:
```python
from stablestack_cache import cache

@cache
def get_summary(text: str) -> str:
    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": f"Summarize: {text}"}]
    )
    return response.choices[0].message.content
```
</example>

<rules>
- Only cache pure LLM calls where the same input should give the same output
- Don't cache calls that intentionally need different results (e.g., creative generation with temperature > 0)
- Don't cache streaming responses — only cache calls that return complete responses
- Always add `@cache` to the innermost function that wraps the LLM call
</rules>
