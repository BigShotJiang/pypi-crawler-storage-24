---
description: "Run StableStack code quality checks on the project"
version: 1.0.0
---

# /check - Run StableStack Checks

<objective>
Run StableStack code quality checkers on the current project and fix the issues found.
</objective>

<usage>
- `/check` — Run all checks
- `/check security` — Run only security checkers (SEC*)
- `/check quality` — Run only quality checkers (QUAL*)
- `/check types` — Run only type safety checkers (TYPE*)
- `/check [rule-id]` — Run a specific checker (e.g., `/check SEC001`)
</usage>

<steps>
1. **Run checks**
   - Execute `stablestack .` (or with category filter if specified)
   - If stablestack is not installed, run `pip install stablestack` first

2. **Review findings**
   - Group by severity: errors first, then warnings, then info
   - Identify patterns (same rule across multiple files)

3. **Fix issues**
   - Start with errors — these are the most impactful
   - For each fix, explain what you changed and why
   - Run `stablestack .` again to verify fixes

4. **Report results**
   - Show summary: how many issues found, how many fixed
   - List any remaining issues that need manual review
</steps>

<common-fixes>
- **DET001**: Add `sorted()` around dict iteration
- **SEC001**: Replace hardcoded secrets with `os.environ.get()`
- **SEC002**: Use parameterized queries instead of string concatenation
- **QUAL001**: Add logging to empty except blocks
- **QUAL004**: Use `None` as default, create mutable inside function body
</common-fixes>
