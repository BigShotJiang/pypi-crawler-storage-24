"""Scaffold generators for StableStack add-* commands.

Provides multi-language scaffold generation with automatic language detection.
Each scaffold module exposes get_files(language) -> dict[str, str] and
get_slash_command() -> str.
"""

from pathlib import Path
from typing import Literal

Language = Literal["python", "typescript"]


def detect_language(project_dir: Path) -> Language | None:
    """Auto-detect project language from config files.

    Returns:
        "python" or "typescript" if unambiguous, None if both or neither detected.
    """
    has_ts = (project_dir / "tsconfig.json").exists() or (project_dir / "package.json").exists()
    has_py = any(
        (project_dir / f).exists()
        for f in ("pyproject.toml", "requirements.txt", "setup.py", "setup.cfg")
    )

    if has_ts and not has_py:
        return "typescript"
    if has_py and not has_ts:
        return "python"
    # Both or neither — caller must ask user or default
    return None


def write_scaffold_files(
    project_dir: Path,
    files: dict[str, str],
    force: bool = False,
) -> list[str]:
    """Write scaffold files to disk.

    Args:
        project_dir: Root directory of the user's project.
        files: Mapping of relative path -> file content.
        force: Overwrite existing files.

    Returns:
        List of relative paths that were created/overwritten.
    """
    created: list[str] = []
    for rel_path, content in sorted(files.items()):
        full_path = project_dir / rel_path
        if full_path.exists() and not force:
            continue
        full_path.parent.mkdir(parents=True, exist_ok=True)
        full_path.write_text(content)
        created.append(rel_path)
    return created
