"""Async checkers - catch common async/await issues."""

from stablestack.checkers.async_checks.missing_await import MissingAwaitChecker

# Paid-tier checkers — import optionally so the free wheel doesn't break
# if the .py files are excluded from the build.
_paid_names = [
    ("blocking_in_async", "BlockingInAsyncChecker"),
    ("fire_and_forget", "FireAndForgetChecker"),
    ("silent_catch", "SilentCatchChecker"),
]

__all__ = ["MissingAwaitChecker"]

for _module_name, _class_name in _paid_names:
    try:
        _mod = __import__(
            f"stablestack.checkers.async_checks.{_module_name}", fromlist=[_class_name]
        )
        globals()[_class_name] = getattr(_mod, _class_name)
        __all__.append(_class_name)
    except ImportError:
        pass
