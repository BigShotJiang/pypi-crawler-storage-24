"""Session management checkers - database session issues (free tier: CRITICAL only)."""

from stablestack.checkers.session.thread_session_safety import ThreadSessionSafetyChecker

# SESS001 (BackgroundTaskSessionChecker) is non-CRITICAL and loaded
# dynamically from compiled bundles via stablestack.checkers.loader.

__all__ = [
    "ThreadSessionSafetyChecker",
]
