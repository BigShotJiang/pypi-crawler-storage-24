"""Checker for claude.md file existence."""

from pathlib import Path
from typing import List

from stablestack.checkers.base import BaseChecker
from stablestack.models import Finding, Severity


class ClaudeMdChecker(BaseChecker):
    """Checks that a claude.md file exists at the project root."""

    rule_id = "PROJ001"
    rule_name = "missing-claude-md"
    description = "Projects should have a CLAUDE.md file for AI assistant context"
    why = (
        "A CLAUDE.md file helps AI assistants like Claude understand your project's "
        "architecture, conventions, and important context. This leads to better code "
        "suggestions and fewer mistakes. It's like onboarding documentation for AI."
    )
    severity = Severity.INFO

    # This is a project-level checker, not a file-level checker
    is_project_checker = True

    def check_file(self, path: Path, content: str) -> List[Finding]:
        """Not used for project-level checks."""
        return []

    def _find_repo_root(self, start: Path) -> Path:
        """Walk up to find the git repo root (or filesystem root)."""
        current = start.resolve()
        while current != current.parent:
            if (current / ".git").exists():
                return current
            current = current.parent
        return start  # fallback to the given directory

    def check_project(self, project_root: Path) -> List[Finding]:
        """Check if claude.md exists at the project root."""
        findings = []

        # Always check the repo root, not a subdirectory
        project_root = self._find_repo_root(project_root)

        # Check for various common names
        claude_md_names = [
            "CLAUDE.md",
            "claude.md",
            "Claude.md",
            ".claude.md",
            "CLAUDE.MD",
        ]

        found = False
        for name in claude_md_names:
            if (project_root / name).exists():
                found = True
                break

        if not found:
            findings.append(
                Finding(
                    file=str(project_root),
                    line=0,
                    column=0,
                    code="",
                    rule_id=self.rule_id,
                    rule_name=self.rule_name,
                    message=(
                        "No CLAUDE.md file found at project root. "
                        "This file helps AI assistants understand your project."
                    ),
                    severity=self.severity,
                    fix_hint=(
                        "Create a CLAUDE.md file at the project root with:\n\n"
                        "# Project Name\n\n"
                        "## Overview\n"
                        "Brief description of what this project does.\n\n"
                        "## Architecture\n"
                        "Key components and how they interact.\n\n"
                        "## Conventions\n"
                        "- Coding style preferences\n"
                        "- Naming conventions\n"
                        "- File organization\n\n"
                        "## Important Files\n"
                        "- `src/main.py` - Entry point\n"
                        "- `src/config.py` - Configuration\n\n"
                        "## Common Tasks\n"
                        "How to run, test, and deploy."
                    ),
                    why=self.why,
                )
            )

        return findings
