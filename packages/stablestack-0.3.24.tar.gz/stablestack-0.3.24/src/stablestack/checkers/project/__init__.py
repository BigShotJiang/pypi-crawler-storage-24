"""Project-level checkers - verify project configuration and setup (free tier: CRITICAL only)."""

from stablestack.checkers.project.claude_md import ClaudeMdChecker
from stablestack.checkers.project.gitignored_claude_md import GitignoredClaudeMdChecker

# PROJ002-PROJ004 (GitUsage, PyrightConfig, BetaDependencies) are non-CRITICAL
# and loaded dynamically from compiled bundles via stablestack.checkers.loader.

__all__ = [
    "ClaudeMdChecker",
    "GitignoredClaudeMdChecker",
]
