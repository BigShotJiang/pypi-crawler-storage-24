"""Manifest of all paid (non-CRITICAL) checkers.

Maps rule_id -> (module_path_relative_to_checkers_dir, class_name).
Used by the build script to know what to compile, and by the bundle
manifest to list which classes to load at runtime.
"""

from __future__ import annotations

# (rule_id, module_path, class_name)
# module_path is relative to checkers/, e.g. "determinism/dict_iteration"
PAID_CHECKERS: list[tuple[str, str, str]] = [
    # Determinism (DET001-DET008)
    ("DET001", "determinism/dict_iteration", "DictIterationChecker"),
    ("DET002", "determinism/set_iteration", "SetIterationChecker"),
    ("DET003", "determinism/sorting_tiebreaker", "SortingTiebreakerChecker"),
    ("DET004", "determinism/list_set_dedup", "ListSetDedupChecker"),
    ("DET005", "determinism/random_without_seed", "RandomWithoutSeedChecker"),
    ("DET006", "determinism/datetime_now", "DatetimeNowChecker"),
    ("DET007", "determinism/os_listdir", "OsListdirChecker"),
    ("DET008", "determinism/hashlib_without_sort", "HashlibWithoutSortChecker"),
    ("DET009", "determinism/uncached_llm_call", "UncachedLlmCallChecker"),
    # Performance (PERF001-PERF004)
    ("PERF001", "performance/n_plus_one", "NPlusOneChecker"),
    ("PERF002", "performance/uninstrumented_llm_call", "UninstrumentedLlmCallChecker"),
    ("PERF003", "performance/redundant_trpc_calls", "RedundantTrpcCallsChecker"),
    ("PERF004", "performance/subscription_waterfall", "SubscriptionWaterfallChecker"),
    # Quality (QUAL002-QUAL018) — QUAL001 moved to free tier
    ("QUAL002", "quality/thread_naming", "ThreadNamingChecker"),
    ("QUAL003", "quality/complex_tuples", "ComplexTuplesChecker"),
    ("QUAL004", "quality/mutable_default", "MutableDefaultChecker"),
    ("QUAL005", "quality/print_statements", "PrintStatementsChecker"),
    ("QUAL006", "quality/todo_comments", "TodoCommentsChecker"),
    ("QUAL007", "quality/broad_exception", "BroadExceptionChecker"),
    ("QUAL008", "quality/magic_numbers", "MagicNumbersChecker"),
    # QUAL009 (file_length) moved to free tier
    ("QUAL010", "quality/url_state_not_persisted", "UrlStateNotPersistedChecker"),
    ("QUAL011", "quality/code_complexity", "CodeComplexityChecker"),
    ("QUAL012", "quality/background_task_tracing", "BackgroundTaskTracingChecker"),
    ("QUAL013", "quality/mixed_boolean_operators", "MixedBooleanOperatorsChecker"),
    ("QUAL014", "quality/case_insensitive_email", "CaseInsensitiveEmailChecker"),
    ("QUAL015", "quality/double_wrapped_email", "DoubleWrappedEmailChecker"),
    ("QUAL016", "quality/duplicate_external_creation", "DuplicateExternalCreationChecker"),
    ("QUAL017", "quality/hardcoded_model_id", "HardcodedModelIdChecker"),
    ("QUAL018", "quality/bash_syntax_in_sh", "BashSyntaxInShChecker"),
    # API (API001-API006)
    ("API001", "api/unhandled_fetch", "UnhandledFetchChecker"),
    ("API002", "api/inconsistent_naming", "InconsistentNamingChecker"),
    ("API003", "api/missing_content_type", "MissingContentTypeChecker"),
    ("API004", "api/hardcoded_urls", "HardcodedUrlsChecker"),
    ("API005", "api/type_alignment", "ApiTypeAlignmentChecker"),
    ("API006", "api/cross_file_type_mismatch", "CrossFileTypeMismatchChecker"),
    # tRPC (TRPC001-TRPC004)
    ("TRPC001", "trpc/procedure_no_input", "TrpcProcedureNoInputChecker"),
    ("TRPC002", "trpc/inline_zod_schema", "TrpcInlineZodSchemaChecker"),
    ("TRPC003", "trpc/result_type_bypass", "TrpcResultTypeBypassChecker"),
    ("TRPC004", "trpc/missing_error_handling", "TrpcMissingErrorHandlingChecker"),
    # Security — non-CRITICAL (SEC007-SEC011, SEC013-SEC017)
    ("SEC007", "security/oauth_state_validation", "OAuthStateValidationChecker"),
    ("SEC008", "security/plaintext_secrets", "PlaintextSecretsChecker"),
    ("SEC009", "security/email_header_injection", "EmailHeaderInjectionChecker"),
    ("SEC010", "security/csv_formula_injection", "CsvFormulaInjectionChecker"),
    ("SEC011", "security/unsanitized_html", "UnsanitizedHtmlChecker"),
    ("SEC013", "security/missing_security_headers", "MissingSecurityHeadersChecker"),
    ("SEC014", "security/error_detail_leakage", "ErrorDetailLeakageChecker"),
    ("SEC015", "security/fail_open_security", "FailOpenSecurityChecker"),
    # ("SEC016", "security/overly_broad_query", "OverlyBroadQueryChecker"),  # Deprecated: too noisy for tRPC/Prisma — select-gating is overkill when you control both sides
    ("SEC017", "security/regex_html_sanitizer", "RegexHtmlSanitizerChecker"),
    # Async (ASYNC001-ASYNC004)
    ("ASYNC001", "async_checks/missing_await", "MissingAwaitChecker"),
    ("ASYNC002", "async_checks/blocking_in_async", "BlockingInAsyncChecker"),
    ("ASYNC003", "async_checks/fire_and_forget", "FireAndForgetChecker"),
    ("ASYNC004", "async_checks/silent_catch", "SilentCatchChecker"),
    # Project (PROJ002-PROJ004) — PROJ001, PROJ005 moved to free tier
    ("PROJ002", "project/git_usage", "GitUsageChecker"),
    ("PROJ003", "project/pyright_config", "PyrightConfigChecker"),
    ("PROJ004", "project/beta_dependencies", "BetaDependenciesChecker"),
    # Concurrency (CONC001-CONC002)
    ("CONC001", "concurrency/check_then_act", "CheckThenActChecker"),
    ("CONC002", "concurrency/non_atomic_read_write", "NonAtomicReadWriteChecker"),
    # Structure (STRUCT003-STRUCT012) — STRUCT001 moved to free tier
    ("STRUCT003", "structure/imports_in_function", "ImportsInFunctionChecker"),
    ("STRUCT004", "structure/sys_path_manipulation", "SysPathManipulationChecker"),
    ("STRUCT005", "structure/relative_imports", "RelativeImportsChecker"),
    ("STRUCT006", "structure/hasattr_dataclass", "HasattrDataclassChecker"),
    ("STRUCT009", "structure/class_filename_mismatch", "ClassFilenameMismatchChecker"),
    ("STRUCT010", "structure/mixed_frontend_backend", "MixedFrontendBackendChecker"),
    ("STRUCT011", "structure/duplicate_modules", "DuplicateModulesChecker"),
    ("STRUCT012", "structure/naked_functions", "NakedFunctionsChecker"),
    # Type safety (TYPE001-TYPE013)
    ("TYPE001", "types/weak_typing", "WeakTypingChecker"),
    ("TYPE002", "types/naked_dict", "NakedDictChecker"),
    ("TYPE004", "types/missing_type_hints", "MissingTypeHintsChecker"),
    ("TYPE005", "types/inline_type_definition", "InlineTypeDefinitionChecker"),
    ("TYPE006", "types/dict_type_consistency", "DictTypeConsistencyChecker"),
    ("TYPE007", "types/duplicate_type_definition", "DuplicateTypeDefinitionChecker"),
    ("TYPE008", "types/typescript_any", "TypeScriptAnyChecker"),
    ("TYPE009", "types/env_non_null_assertion", "EnvNonNullAssertionChecker"),
    ("TYPE010", "types/unsafe_json_parse", "UnsafeJsonParseChecker"),
    ("TYPE011", "types/inline_enum_duplication", "InlineEnumDuplicationChecker"),
    ("TYPE012", "types/dom_selection_null", "DomSelectionNullChecker"),
    ("TYPE013", "types/unvalidated_json_parse", "UnvalidatedJsonParseChecker"),
    # Testing (TEST001-TEST008)
    ("TEST001", "testing/skipped_tests", "SkippedTestsChecker"),
    ("TEST003", "testing/async_mock_issues", "AsyncMockIssuesChecker"),
    ("TEST004", "testing/duplicate_test_helpers", "DuplicateTestHelpersChecker"),
    ("TEST005", "testing/e2e_duplication", "E2EDuplicationChecker"),
    ("TEST006", "testing/e2e_console_capture", "E2EConsoleCaptureChecker"),
    ("TEST007", "testing/missing_e2e_tests", "MissingE2ETestsChecker"),
    ("TEST008", "testing/playwright_test_slow", "PlaywrightTestSlowChecker"),
    ("TEST009", "testing/playwright_wait_for_timeout2", "PlaywrightWaitForTimeoutChecker"),
    # Session — non-CRITICAL (SESS001)
    ("SESS001", "session/background_task_session", "BackgroundTaskSessionChecker"),
    # Datetime (DATE002-DATE004)
    ("DATE002", "datetime_checks/naive_datetime", "NaiveDatetimeChecker"),
    ("DATE003", "datetime_checks/db_datetime_awareness", "DbDatetimeAwarenessChecker"),
    ("DATE004", "datetime_checks/getday_utc_mismatch", "GetDayUtcMismatchChecker"),
    # Kubernetes (KUBE001-KUBE002)
    ("KUBE001", "kubernetes/local_filesystem", "LocalFilesystemChecker"),
    ("KUBE002", "kubernetes/ingress_ssl_redirect", "IngressSslRedirectChecker"),
    # Import (IMPORT001)
    ("IMPORT001", "imports/reserved_keywords", "ReservedKeywordImportChecker"),
    # Rate limiting (RATE001-RATE002)
    ("RATE001", "rate_limiting/missing_rate_limit", "MissingRateLimitChecker"),
    ("RATE002", "rate_limiting/in_memory_rate_limiter", "InMemoryRateLimiterChecker"),
    # Frontend (FRONT001-FRONT009)
    ("FRONT001", "frontend/tab_url_routing", "TabUrlRoutingChecker"),
    ("FRONT002", "frontend/window_ssr_unsafe", "WindowSsrUnsafeChecker"),
    ("FRONT003", "frontend/inline_jsx_handler", "InlineJsxHandlerChecker"),
    ("FRONT004", "frontend/nextjs_redirect_url", "NextjsRedirectUrlChecker"),
    ("FRONT005", "frontend/useeffect_side_effect", "UseEffectSideEffectChecker"),
    ("FRONT006", "frontend/stale_time_ui", "StaleTimeUiChecker"),
    ("FRONT007", "frontend/unbounded_ai_output", "UnboundedAiOutputChecker"),
    ("FRONT008", "frontend/loading_returns_null", "LoadingReturnsNullChecker"),
    ("FRONT009", "frontend/eager_queries_no_defer", "EagerQueriesNoDeferChecker"),
    # Accessibility (A11Y001)
    ("A11Y001", "accessibility/button_contrast", "ButtonContrastChecker"),
    # Memory safety (MEM001-MEM004)
    ("MEM001", "memory/unbounded_query", "UnboundedQueryChecker"),
    ("MEM002", "memory/unbounded_eager_load", "UnboundedEagerLoadChecker"),
    ("MEM003", "memory/in_process_accumulator", "InProcessAccumulatorChecker"),
    ("MEM004", "memory/global_state_singleton", "GlobalStateSingletonChecker"),
]
