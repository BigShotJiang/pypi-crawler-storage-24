"""Security checkers - catch common security vulnerabilities (free tier: CRITICAL only)."""

from stablestack.checkers.security.hardcoded_secrets import HardcodedSecretsChecker
from stablestack.checkers.security.sql_injection import SqlInjectionChecker
from stablestack.checkers.security.eval_usage import EvalUsageChecker
from stablestack.checkers.security.insecure_random import InsecureRandomChecker
from stablestack.checkers.security.inner_html_xss import InnerHtmlXssChecker
from stablestack.checkers.security.webhook_security_bypass import WebhookSecurityBypassChecker
from stablestack.checkers.security.node_env_security_gate import NodeEnvSecurityGateChecker

# Non-CRITICAL security checkers (SEC007-SEC011, SEC013-SEC017) are paid-only
# and loaded dynamically from compiled bundles via stablestack.checkers.loader.

__all__ = [
    "HardcodedSecretsChecker",
    "SqlInjectionChecker",
    "EvalUsageChecker",
    "InsecureRandomChecker",
    "InnerHtmlXssChecker",
    "WebhookSecurityBypassChecker",
    "NodeEnvSecurityGateChecker",
]
