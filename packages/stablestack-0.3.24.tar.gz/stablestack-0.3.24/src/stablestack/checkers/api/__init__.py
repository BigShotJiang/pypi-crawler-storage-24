"""API contract checkers - catch frontend/backend mismatches and API issues."""

# All API checkers are paid tier — import them optionally so the free
# wheel doesn't break if the .py files are excluded from the build.
_all_names = [
    ("unhandled_fetch", "UnhandledFetchChecker"),
    ("inconsistent_naming", "InconsistentNamingChecker"),
    ("missing_content_type", "MissingContentTypeChecker"),
    ("hardcoded_urls", "HardcodedUrlsChecker"),
    ("type_alignment", "ApiTypeAlignmentChecker"),
    ("cross_file_type_mismatch", "CrossFileTypeMismatchChecker"),
    ("untyped_response", "UntypedResponseChecker"),
]

__all__: list[str] = []

for _module_name, _class_name in _all_names:
    try:
        _mod = __import__(
            f"stablestack.checkers.api.{_module_name}", fromlist=[_class_name]
        )
        globals()[_class_name] = getattr(_mod, _class_name)
        __all__.append(_class_name)
    except ImportError:
        pass
