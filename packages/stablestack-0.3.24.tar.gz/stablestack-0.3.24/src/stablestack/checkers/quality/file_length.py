"""Checker for maximum file length."""

from pathlib import Path
from typing import List

from stablestack.checkers.base import BaseChecker
from stablestack.models import Finding, Severity, Tier


class FileLengthChecker(BaseChecker):
    """Detects files that are too long and should be split."""

    rule_id = "QUAL009"
    rule_name = "file-too-long"
    description = "File exceeds recommended maximum length."
    why = (
        "Long files are hard to navigate, understand, and maintain. "
        "They often indicate that a file has too many responsibilities. "
        "Consider splitting into smaller, focused modules."
    )
    severity = Severity.INFO
    tier = Tier.RECOMMENDED
    file_extensions = {
        ".py", ".ts", ".tsx", ".js", ".jsx",
        ".go", ".rs", ".rb", ".java",
        ".c", ".cpp", ".h", ".hpp", ".cs",
        ".swift", ".kt", ".scala",
    }

    # Default thresholds (can be configured)
    WARNING_THRESHOLD = 500  # Lines - suggest splitting
    ERROR_THRESHOLD = 1000  # Lines - strongly recommend splitting

    def check_file(self, path: Path, content: str) -> List[Finding]:
        findings = []

        lines = content.split("\n")
        line_count = len(lines)

        if line_count > self.ERROR_THRESHOLD:
            findings.append(
                Finding(
                    file=str(path),
                    line=1,
                    column=1,
                    code=f"File has {line_count} lines",
                    rule_id=self.rule_id,
                    rule_name=self.rule_name,
                    message=f"File has {line_count} lines (exceeds {self.ERROR_THRESHOLD}). Consider splitting into smaller modules.",
                    severity=Severity.WARNING,
                    fix_hint="Extract related functions/classes into separate files based on responsibility.",
                    why=self.why,
                )
            )
        elif line_count > self.WARNING_THRESHOLD:
            findings.append(
                Finding(
                    file=str(path),
                    line=1,
                    column=1,
                    code=f"File has {line_count} lines",
                    rule_id=self.rule_id,
                    rule_name=self.rule_name,
                    message=f"File has {line_count} lines (approaching {self.ERROR_THRESHOLD} limit). Consider splitting.",
                    severity=Severity.INFO,
                    fix_hint="Plan to split this file before it grows further.",
                    why=self.why,
                )
            )

        return findings
