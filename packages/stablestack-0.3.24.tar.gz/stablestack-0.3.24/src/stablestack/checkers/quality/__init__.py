"""Quality checkers - catch code quality issues (free tier: CRITICAL only)."""

from stablestack.checkers.quality.exception_swallowing import ExceptionSwallowingChecker
from stablestack.checkers.quality.file_length import FileLengthChecker

# QUAL002-QUAL008, QUAL010-QUAL018 are non-CRITICAL and loaded dynamically
# from compiled bundles via stablestack.checkers.loader.

__all__ = [
    "ExceptionSwallowingChecker",
    "FileLengthChecker",
]
