"""Structure checkers - code organization issues (free tier: CRITICAL only)."""

from stablestack.checkers.structure.multiple_classes import MultipleClassesChecker

# STRUCT003-STRUCT012 are non-CRITICAL and loaded dynamically from compiled
# bundles via stablestack.checkers.loader.

__all__ = [
    "MultipleClassesChecker",
]
