"""Core data models for stablestack findings."""

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class Severity(Enum):
    """Severity levels for findings."""

    ERROR = "error"  # Fails CI
    WARNING = "warning"  # Reports but doesn't fail
    INFO = "info"  # Informational only

    def __str__(self) -> str:
        return self.value


class Tier(Enum):
    """
    Adoption tiers for checkers - helps new users onboard gradually.

    Tier 1 (CRITICAL): Always run. Catches bugs that cause production outages.
    Tier 2 (RECOMMENDED): Default enabled. Catches common issues most teams care about.
    Tier 3 (OPTIONAL): Opt-in. Nice-to-have checks that may be noisy for some projects.
    Tier 4 (PREFERENCE): Opinionated style preferences. Not everyone agrees on these.
    """

    CRITICAL = 1  # Production bugs, security issues - always enabled
    RECOMMENDED = 2  # Common issues - enabled by default
    OPTIONAL = 3  # Nice-to-have - disabled by default for new users
    PREFERENCE = 4  # Opinionated style choices - explicitly opt-in

    def __str__(self) -> str:
        return self.name.lower()


@dataclass
class Finding:
    """Represents a single issue found by a checker."""

    file: str
    line: int
    column: int
    code: str  # The actual line content
    rule_id: str  # e.g., "DET001" for determinism
    rule_name: str  # e.g., "unsorted-dict-iteration"
    message: str  # Human-readable explanation
    severity: Severity
    fix_hint: str  # How to fix it
    why: str = ""  # Why this matters (for beginners)
    end_line: Optional[int] = None
    end_column: Optional[int] = None

    def to_dict(self) -> dict:
        """Convert finding to dictionary for JSON serialization."""
        return {
            "file": self.file,
            "line": self.line,
            "column": self.column,
            "end_line": self.end_line,
            "end_column": self.end_column,
            "code": self.code,
            "rule_id": self.rule_id,
            "rule_name": self.rule_name,
            "message": self.message,
            "severity": str(self.severity),
            "fix_hint": self.fix_hint,
            "why": self.why,
        }
