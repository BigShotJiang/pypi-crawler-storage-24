"""Allow running stablestack as `python -m stablestack`."""

from stablestack.cli import main

if __name__ == "__main__":
    main()
