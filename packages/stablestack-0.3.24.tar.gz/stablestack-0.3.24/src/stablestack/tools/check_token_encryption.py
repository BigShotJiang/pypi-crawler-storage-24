#!/usr/bin/env python3
"""
Tool to verify encrypted token storage implementation.

Checks that OAuth tokens and other sensitive credentials are properly
encrypted before database storage.

Usage:
    python -m stablestack.tools.check_token_encryption /path/to/project
    python -m stablestack.tools.check_token_encryption --verbose
    python -m stablestack.tools.check_token_encryption --checklist
"""

import argparse
import re
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Set, Tuple


@dataclass
class CheckResult:
    """Result of a single check."""

    name: str
    passed: bool
    message: str
    file: str = ""
    line: int = 0
    severity: str = "warning"  # info, warning, error


@dataclass
class EncryptionAudit:
    """Complete encryption audit results."""

    project_path: Path
    results: List[CheckResult] = field(default_factory=list)
    encryption_lib_found: bool = False
    encrypted_columns_found: bool = False
    plaintext_tokens_found: List[Tuple[str, int, str]] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        """Check if audit passed (no errors)."""
        return not any(r.severity == "error" for r in self.results)

    @property
    def score(self) -> int:
        """Calculate implementation score (0-100)."""
        if not self.results:
            return 0
        passed = sum(1 for r in self.results if r.passed)
        return int((passed / len(self.results)) * 100)


class TokenEncryptionChecker:
    """Checks for proper token encryption implementation."""

    # Sensitive field names that should be encrypted
    SENSITIVE_FIELDS = {
        "access_token",
        "accesstoken",
        "refresh_token",
        "refreshtoken",
        "api_key",
        "apikey",
        "secret_key",
        "secretkey",
        "auth_token",
        "authtoken",
        "bearer_token",
        "bearertoken",
        "client_secret",
        "clientsecret",
        "private_key",
        "privatekey",
    }

    # ...existing code...
