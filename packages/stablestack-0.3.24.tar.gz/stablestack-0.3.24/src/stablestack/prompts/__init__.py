"""Prompt templates for common tasks.

These are curated prompts that encode domain expertise about what to ask
an AI coding assistant to accomplish specific goals. They help beginners
ask the right questions.

Usage:
    from stablestack.prompts import get_prompt, list_prompts

    # List available prompts
    prompts = list_prompts()

    # Get a specific prompt
    prompt = get_prompt("deploy-aws")
    print(prompt.content)
"""

from pathlib import Path
from typing import List, Optional
from dataclasses import dataclass
import yaml


@dataclass
class Prompt:
    """A prompt template."""
    id: str
    title: str
    category: str
    description: str
    content: str
    tags: List[str]
    difficulty: str  # beginner, intermediate, advanced
    prerequisites: List[str]


PROMPTS_DIR = Path(__file__).parent


def list_prompts(category: Optional[str] = None) -> List[Prompt]:
    """List all available prompts, optionally filtered by category."""
    prompts = []
    for yaml_file in PROMPTS_DIR.glob("**/*.yaml"):
        try:
            data = yaml.safe_load(yaml_file.read_text())
            prompt = Prompt(
                id=data.get("id", yaml_file.stem),
                title=data.get("title", ""),
                category=data.get("category", ""),
                description=data.get("description", ""),
                content=data.get("prompt", ""),
                tags=data.get("tags", []),
                difficulty=data.get("difficulty", "intermediate"),
                prerequisites=data.get("prerequisites", []),
            )
            if category is None or prompt.category == category:
                prompts.append(prompt)
        except Exception:
            continue
    return sorted(prompts, key=lambda p: (p.category, p.title))


def get_prompt(prompt_id: str) -> Optional[Prompt]:
    """Get a prompt by ID."""
    for prompt in list_prompts():
        if prompt.id == prompt_id:
            return prompt
    return None


def list_categories() -> List[str]:
    """List all prompt categories."""
    categories = set()
    for prompt in list_prompts():
        categories.add(prompt.category)
    return sorted(categories)
