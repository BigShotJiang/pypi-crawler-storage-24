import oersted
from time import perf_counter

size = 15.0
theta = 0.5
nthreads = 0
centroids, vol, jdensity = oersted.testing.make_helmholtz(size)

# centroids = np.vstack((centroids, centroids))
# vol = np.hstack((vol, vol))
# jdensity = np.vstack((jdensity, jdensity))

print("Oersted Example - Helmholtz Problem")
n = centroids.shape[0]
print(f"n = {n:.3e} ({n * n:.3e} interactions)")


start = perf_counter()
b = oersted.bfield_octree(centroids, vol, jdensity, centroids, theta=theta, nthreads=nthreads)
end = perf_counter()
elapsed = end - start

print(f"Elapsed time: {elapsed:.3f} s")
