"""Prescriptive reasoning: define and solve decision problems.

Provides a declarative Python API for formulating decision problems — optimization,
constraint satisfaction, or feasibility — and solving them with external solvers
(HiGHS, Gurobi, Ipopt, MiniZinc, etc.).

## Quick Start

```python
from relationalai.semantics import Model, Float, Integer
from relationalai.semantics.reasoners.prescriptive import Problem

model = Model("my_problem")
p = Problem(model, Float)  # Float for HiGHS/Gurobi/Ipopt, Integer for MiniZinc

x = model.Relationship(f"{Float:x}")
y = model.Relationship(f"{Float:y}")
p.solve_for(x, name="x", lower=0, upper=10)
p.solve_for(y, name="y", lower=0, upper=10)

p.minimize(x**2 + y**2)
p.satisfy(model.require(x + y >= 5))
p.solve("highs")
```
"""

from __future__ import annotations

from .problem import (
    Problem,
    all_different,
    implies,
    special_ordered_set_type_1,
    special_ordered_set_type_2,
)

# Include this package in the docs
__include_in_docs__ = True

# Package version.
__version__ = "0.0.0"

__all__ = [
    "Problem",
    "all_different",
    "implies",
    "special_ordered_set_type_1",
    "special_ordered_set_type_2",
]
