"""Synchronous Reasoners service client.

This module provides the blocking (sync) API used by `relationalai.client.connect_sync()`.
The client delegates backend-specific behavior to a `ReasonersGatewaySync`.
"""

from __future__ import annotations

import re
from typing import Any, TYPE_CHECKING

from relationalai.util.docutils import include_in_docs
from relationalai.util.polling import poll_until_sync

from . import constants as c
from .errors import (
    ReasonerConflictError,
    ReasonerInvalidRequestError,
    ReasonerNotFoundError,
    ReasonerNotReadyError,
    ReasonerTimeoutError,
)
from .models import Operation, Reasoner, ReasonerType
from .operations import ReasonerOperationSync, _EnsureRequested, _op_id
from .protocol import ReasonersGatewaySync
from .util import _pick_reasoner_match, sanitize_user_name

if TYPE_CHECKING:
    from relationalai.config.config import Config

__include_in_docs__ = True


@include_in_docs
class ReasonersClientSync:
    """Synchronous reasoners client (public API for `connect_sync()`)."""

    def __init__(
        self,
        gateway: ReasonersGatewaySync,
        *,
        config: "Config | None" = None,
    ):
        """Create a synchronous reasoners client.

        Args:
            gateway: Backend adapter implementing `ReasonersGatewaySync`.
            config: Optional config used for defaults (name/size/settings) and polling knobs.
        """
        self._gateway = gateway
        self._config = config

    @include_in_docs
    def close(self) -> None:
        """Close the client (no-op).

        Note: gateways do not own shared transports; the root platform client is
        responsible for closing transports/sessions.

        Returns
        -------
        None
            Always returns `None`.
        """
        # Gateways do not own shared transports; the root client closes them.
        return None

    # ---- shared helpers ----
    def _normalize_reasoner_type(self, reasoner_type: str) -> str:
        """Validate and normalize a reasoner type string."""
        if not isinstance(reasoner_type, str) or not reasoner_type.strip():
            raise ReasonerInvalidRequestError(
                "Reasoner `reasoner_type` is required (Logic, Prescriptive, or Predictive)."
            )
        try:
            return ReasonerType.normalize(reasoner_type)
        except ValueError as e:
            raise ReasonerInvalidRequestError(str(e)) from e

    _NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]*$")

    def _normalize_name_optional(self, name: str | None) -> str | None:
        """Normalize a reasoner name, allowing `None` (meaning: use defaults)."""
        if name is None:
            return None
        if not isinstance(name, str):
            raise ReasonerInvalidRequestError("Reasoner `reasoner_name` must be a string.")
        s = name.strip()
        if not s:
            return None
        if not self._NAME_RE.match(s):
            raise ReasonerInvalidRequestError(
                "Invalid reasoner `name`. Use letters/digits plus '_' or '-', "
                "starting with a letter or digit (e.g. 'my_solver', 'user-1')."
            )
        return s

    def _normalize_reasoner_type_optional(self, reasoner_type: str | None) -> str | None:
        """Normalize a reasoner type string, allowing `None`."""
        if reasoner_type is None:
            return None
        return self._normalize_reasoner_type(reasoner_type)
    def _check_reasoner_ready(
        self, r: Reasoner | None, reasoner_name: str, reasoner_type: str, context: str
    ) -> Reasoner:
        """Validate a reasoner exists and is READY; raise otherwise."""
        if r is None:
            raise ReasonerNotFoundError(
                f"Reasoner not found {context}: reasoner_name={reasoner_name} reasoner_type={reasoner_type}"
            )
        if (r.state or "").upper() != c.REASONER_STATE_READY:
            raise ReasonerNotReadyError(f"Reasoner is not READY {context}: state={r.state}")
        return r

    def _mismatch_message(
        self,
        *,
        reasoner_name: str,
        reasoner_type: str,
        requested: _EnsureRequested,
        existing: Reasoner,
    ) -> str | None:
        diffs: list[str] = []
        if requested.size is not None and existing.size != requested.size:
            diffs.append(f"size (requested={requested.size!r}, existing={existing.size!r})")
        if requested.auto_suspend_mins is not None and existing.auto_suspend_mins != requested.auto_suspend_mins:
            diffs.append(
                f"auto_suspend_mins (requested={requested.auto_suspend_mins!r}, existing={existing.auto_suspend_mins!r})"
            )
        existing_await_storage_vacuum = None
        if isinstance(existing.settings, dict) and "await_storage_vacuum" in existing.settings:
            existing_await_storage_vacuum = existing.settings.get("await_storage_vacuum")
        if (
            requested.await_storage_vacuum is not None
            and isinstance(existing.settings, dict)
            and "await_storage_vacuum" in existing.settings
            and existing_await_storage_vacuum != requested.await_storage_vacuum
        ):
            diffs.append(
                "await_storage_vacuum "
                f"(requested={requested.await_storage_vacuum!r}, existing={existing_await_storage_vacuum!r})"
            )
        if requested.settings is not None and existing.settings != requested.settings:
            diffs.append(f"settings (requested={requested.settings!r}, existing={existing.settings!r})")
        if not diffs:
            return None
        return (
            "Reasoner already exists but does not match requested configuration: "
            f"name={reasoner_name!r} type={reasoner_type!r}. Mismatches: " + ", ".join(diffs)
        )

    def _raise_on_mismatch(
        self,
        *,
        reasoner_name: str,
        reasoner_type: str,
        requested: _EnsureRequested,
        existing: Reasoner,
    ) -> None:
        msg = self._mismatch_message(
            reasoner_name=reasoner_name,
            reasoner_type=reasoner_type,
            requested=requested,
            existing=existing,
        )
        if msg is not None:
            raise ReasonerConflictError(msg)

    def _default_username(self) -> str:
        """Best-effort default reasoner name when not provided."""
        cfg = self._config
        if cfg is None:
            return "default"
        try:
            conn = cfg.get_default_connection()
        except Exception:
            return "default"
        user = getattr(conn, "user", None)
        if isinstance(user, str) and user.strip():
            sanitized = sanitize_user_name(user)
            return sanitized or "default"
        return "default"

    def _reasoner_defaults(
        self, t: str
    ) -> tuple[str | None, str | None, int | None, bool | None, dict[str, Any] | None]:
        """Return config defaults for the given reasoner type."""
        cfg = self._config
        if cfg is None:
            return None, None, None, None, None

        if t == c.REASONER_TYPE_LOGIC:
            section = cfg.reasoners.logic
        elif t == c.REASONER_TYPE_PREDICTIVE:
            section = cfg.reasoners.predictive
        elif t == c.REASONER_TYPE_PRESCRIPTIVE:
            section = cfg.reasoners.prescriptive
        else:
            section = cfg.reasoners.logic

        return (
            section.name,
            section.size,
            section.auto_suspend_mins,
            section.await_storage_vacuum,
            section.settings,
        )

    def _resolve_identity_and_defaults(
        self,
        reasoner_type: str,
        reasoner_name: str | None,
        *,
        size: str | None,
        auto_suspend_mins: int | None,
        await_storage_vacuum: bool | None,
        settings: dict[str, Any] | None,
    ) -> tuple[str, str | None, int | None, bool | None, dict[str, Any] | None]:
        """Resolve name/create options using explicit args then config defaults."""
        t = self._normalize_reasoner_type(reasoner_type)
        cfg_name, cfg_size, cfg_auto, cfg_await_storage_vacuum, cfg_settings = self._reasoner_defaults(t)
        norm_name = self._normalize_name_optional(reasoner_name)
        norm_cfg_name = self._normalize_name_optional(cfg_name)
        norm_default = self._normalize_name_optional(self._default_username())
        resolved_name = norm_name or norm_cfg_name or (norm_default or "default")
        resolved_size = size if size is not None else cfg_size
        resolved_auto = auto_suspend_mins if auto_suspend_mins is not None else cfg_auto
        resolved_await_storage_vacuum = (
            await_storage_vacuum if await_storage_vacuum is not None else cfg_await_storage_vacuum
        )
        resolved_settings = settings if settings is not None else cfg_settings
        return resolved_name, resolved_size, resolved_auto, resolved_await_storage_vacuum, resolved_settings

    def _polling_cfg(self) -> tuple[float, float, float]:
        """Return `(initial_delay, overhead_rate, max_delay)` for polling."""
        cfg = self._config
        if cfg is None:
            return 0.01, 0.1, 0.5
        r = cfg.reasoners
        return float(r.poll_initial_delay_s), float(r.poll_overhead_rate), float(r.poll_max_delay_s)

    def _lookup_existing_reasoner(self, reasoner_type: str, reasoner_name: str) -> Reasoner | None:
        """Resolve a reasoner even when backend get/list filters are case-sensitive."""
        direct = self._gateway.get(reasoner_type, reasoner_name)
        if direct is not None:
            return direct

        attempts: list[tuple[str | None, str | None]] = [
            (reasoner_type, reasoner_name),
            (reasoner_type, None),
            (None, None),
        ]
        seen: set[tuple[str | None, str | None]] = set()
        for list_type, list_name in attempts:
            if (list_type, list_name) in seen:
                continue
            seen.add((list_type, list_name))
            candidates = self._gateway.list(reasoner_type=list_type, reasoner_name=list_name)
            matched = _pick_reasoner_match(candidates, reasoner_type, reasoner_name)
            if matched is not None:
                return matched
        return None

    # --- lifecycle (sync) ---
    @include_in_docs
    def list(
        self,
        *,
        state: str | None = None,
        reasoner_name: str | None = None,
        reasoner_type: str | None = None,
        reasoner_size: str | None = None,
        created_by: str | None = None,
    ) -> list[Reasoner]:
        """List reasoners, optionally filtering by attributes.

        Returns
        -------
        list[Reasoner]
            Matching reasoners.
        """
        t = self._normalize_reasoner_type_optional(reasoner_type)
        return self._gateway.list(
            state=state,
            reasoner_name=reasoner_name,
            reasoner_type=t,
            reasoner_size=reasoner_size,
            created_by=created_by,
        )

    @include_in_docs
    def get(self, reasoner_type: str, reasoner_name: str) -> Reasoner | None:
        """Get a reasoner by `(type, name)`, returning `None` if not found.

        Returns
        -------
        Reasoner | None
            The reasoner, or `None` if not found.
        """
        t = self._normalize_reasoner_type(reasoner_type)
        return self._lookup_existing_reasoner(t, reasoner_name)

    @include_in_docs
    def create(
        self,
        reasoner_type: str,
        reasoner_name: str | None = None,
        *,
        reasoner_size: str | None = None,
        auto_suspend_mins: int | None = None,
        await_storage_vacuum: bool | None = None,
        settings: dict[str, Any] | None = None,
    ) -> ReasonerOperationSync:
        """Create a reasoner and return an operation handle (non-blocking).

        Returns
        -------
        ReasonerOperationSync
            An operation handle; call `op.wait(...)` to block for readiness.
        """

        t = self._normalize_reasoner_type(reasoner_type)
        resolved_name, resolved_size, resolved_auto, resolved_await_storage_vacuum, resolved_settings = (
            self._resolve_identity_and_defaults(
                t,
                reasoner_name,
                size=reasoner_size,
                auto_suspend_mins=auto_suspend_mins,
                await_storage_vacuum=await_storage_vacuum,
                settings=settings,
            )
        )
        existing = self._lookup_existing_reasoner(t, resolved_name)
        if existing is not None:
            raise ReasonerConflictError(
                f"Reasoner already exists: name={resolved_name} type={t} state={existing.state}"
            )

        op = self._gateway.create(
            t,
            resolved_name,
            reasoner_size=resolved_size,
            auto_suspend_mins=resolved_auto,
            await_storage_vacuum=resolved_await_storage_vacuum,
            settings=resolved_settings,
        )
        return ReasonerOperationSync(
            client=self, id=op.id, metadata={"reasoner_name": resolved_name, "reasoner_type": t}
        )

    @include_in_docs
    def delete(self, reasoner_type: str, reasoner_name: str | None = None) -> None:
        """Delete a reasoner.

        Args:
            reasoner_type: Reasoner type (Logic, Prescriptive, Predictive).
            reasoner_name: Optional name (defaults to config/user-derived).
        Returns
        -------
        None
            Always returns `None`.
        """
        t = self._normalize_reasoner_type(reasoner_type)
        resolved_name, _size, _auto, _await_storage_vacuum, _settings = self._resolve_identity_and_defaults(
            t, reasoner_name, size=None, auto_suspend_mins=None, await_storage_vacuum=None, settings=None
        )
        existing = self._lookup_existing_reasoner(t, resolved_name)
        return self._gateway.delete(t, existing.name if existing is not None else resolved_name)

    @include_in_docs
    def suspend(self, reasoner_type: str, reasoner_name: str | None = None) -> None:
        """Suspend a reasoner.

        Returns
        -------
        None
            Always returns `None`.
        """
        t = self._normalize_reasoner_type(reasoner_type)
        resolved_name, _size, _auto, _await_storage_vacuum, _settings = self._resolve_identity_and_defaults(
            t, reasoner_name, size=None, auto_suspend_mins=None, await_storage_vacuum=None, settings=None
        )
        existing = self._lookup_existing_reasoner(t, resolved_name)
        return self._gateway.suspend(t, existing.name if existing is not None else resolved_name)

    @include_in_docs
    def resume(self, reasoner_type: str, reasoner_name: str | None = None) -> ReasonerOperationSync:
        """Resume a reasoner and return an operation handle (non-blocking).

        Returns
        -------
        ReasonerOperationSync
            An operation handle; call `op.wait(...)` to block for readiness.
        """
        t = self._normalize_reasoner_type(reasoner_type)
        resolved_name, _size, _auto, _await_storage_vacuum, _settings = self._resolve_identity_and_defaults(
            t, reasoner_name, size=None, auto_suspend_mins=None, await_storage_vacuum=None, settings=None
        )
        existing = self._lookup_existing_reasoner(t, resolved_name)
        actual_name = existing.name if existing is not None else resolved_name
        op = self._gateway.resume(t, actual_name)
        return ReasonerOperationSync(
            client=self, id=op.id, metadata={"reasoner_name": actual_name, "reasoner_type": t}
        )

    @include_in_docs
    def ensure(
        self,
        reasoner_type: str,
        reasoner_name: str | None = None,
        *,
        reasoner_size: str | None = None,
        auto_suspend_mins: int | None = None,
        await_storage_vacuum: bool | None = None,
        settings: dict[str, Any] | None = None,
        create: bool = True,
        resume: bool = True,
    ) -> ReasonerOperationSync:
        """Ensure a reasoner exists and is READY, returning an operation handle (non-blocking).

        - If missing and `create=True`, creates it.
        - If SUSPENDED and `resume=True`, resumes it.
        - Otherwise returns an operation handle derived from reasoner state.
        Returns
        -------
        ReasonerOperationSync
            An operation handle representing the ensure workflow.
        """
        t = self._normalize_reasoner_type(reasoner_type)
        resolved_name, resolved_size, resolved_auto, resolved_await_storage_vacuum, resolved_settings = (
            self._resolve_identity_and_defaults(
                t,
                reasoner_name,
                size=reasoner_size,
                auto_suspend_mins=auto_suspend_mins,
                await_storage_vacuum=await_storage_vacuum,
                settings=settings,
            )
        )

        existing = self._lookup_existing_reasoner(t, resolved_name)
        if existing is None:
            if not create:
                raise ReasonerNotFoundError(f"Reasoner not found: name={resolved_name} type={t}")
            try:
                op = self._gateway.create(
                    t,
                    resolved_name,
                    reasoner_size=resolved_size,
                    auto_suspend_mins=resolved_auto,
                    await_storage_vacuum=resolved_await_storage_vacuum,
                    settings=resolved_settings,
                )
            except ReasonerConflictError as e:
                # Another caller created the engine between our get() and create().
                # Re-fetch and fall through to the existing-engine path.
                existing = self._lookup_existing_reasoner(t, resolved_name)
                if existing is None:
                    raise ReasonerNotFoundError(
                        f"Reasoner not found after create conflict: name={resolved_name} type={t}"
                    ) from e
            else:
                return ReasonerOperationSync(
                    client=self,
                    id=op.id,
                    metadata={"reasoner_name": resolved_name, "reasoner_type": t},
                    _ensure_requested=_EnsureRequested(
                        size=reasoner_size,
                        auto_suspend_mins=auto_suspend_mins,
                        await_storage_vacuum=await_storage_vacuum,
                        settings=settings,
                    ),
                )
        if existing is not None:
            # Existing reasoner: validate explicitly requested details before proceeding.
            self._raise_on_mismatch(
                reasoner_name=resolved_name,
                reasoner_type=t,
                requested=_EnsureRequested(
                    size=reasoner_size,
                    auto_suspend_mins=auto_suspend_mins,
                    await_storage_vacuum=await_storage_vacuum,
                    settings=settings,
                ),
                existing=existing,
            )
            state = (existing.state or "").upper()
            if state == c.REASONER_STATE_READY:
                return ReasonerOperationSync(
                    client=self,
                    id=_op_id("ensure", reasoner_type=t, reasoner_name=resolved_name),
                    metadata={"reasoner_name": resolved_name, "reasoner_type": t},
                    _result=existing,
                    _ensure_requested=_EnsureRequested(
                        size=reasoner_size,
                        auto_suspend_mins=auto_suspend_mins,
                        await_storage_vacuum=await_storage_vacuum,
                        settings=settings,
                    ),
                )
            if state in c.REASONER_FAILED_STATES:
                raise ReasonerNotReadyError(f"Reasoner exists but is not READY: state={existing.state}")
            if state == c.REASONER_STATE_SUSPENDED:
                if not resume:
                    raise ReasonerNotReadyError(f"Reasoner is SUSPENDED: name={resolved_name} type={t}")
                try:
                    op = self._gateway.resume(t, resolved_name)
                except ReasonerConflictError:
                    # Another caller already started the resume — fall through to polling.
                    pass
                else:
                    return ReasonerOperationSync(
                        client=self,
                        id=op.id,
                        metadata={"reasoner_name": resolved_name, "reasoner_type": t},
                        _ensure_requested=_EnsureRequested(
                            size=reasoner_size,
                            auto_suspend_mins=auto_suspend_mins,
                            await_storage_vacuum=await_storage_vacuum,
                            settings=settings,
                        ),
                    )

        # Provisioning/pending/etc: represent as a derived operation from reasoner state.
        return ReasonerOperationSync(
            client=self,
            id=_op_id("ensure", reasoner_type=t, reasoner_name=resolved_name),
            metadata={"reasoner_name": resolved_name, "reasoner_type": t},
            _ensure_requested=_EnsureRequested(
                size=reasoner_size,
                auto_suspend_mins=auto_suspend_mins,
                await_storage_vacuum=await_storage_vacuum,
                settings=settings,
            ),
        )

    @include_in_docs
    def create_ready(
        self,
        reasoner_type: str,
        reasoner_name: str | None = None,
        *,
        reasoner_size: str | None = None,
        auto_suspend_mins: int | None = None,
        await_storage_vacuum: bool | None = None,
        settings: dict[str, Any] | None = None,
        timeout_s: int = 900,
    ) -> Reasoner:
        """Create a reasoner and block until it is READY.

        Returns
        -------
        Reasoner
            The created reasoner in READY state.
        """
        op = self.create(
            reasoner_type,
            reasoner_name,
            reasoner_size=reasoner_size,
            auto_suspend_mins=auto_suspend_mins,
            await_storage_vacuum=await_storage_vacuum,
            settings=settings,
        )
        return op.wait(timeout_s=timeout_s)

    @include_in_docs
    def resume_ready(
        self, reasoner_type: str, reasoner_name: str | None = None, *, timeout_s: int = 900
    ) -> Reasoner:
        """Resume a reasoner and block until it is READY.

        Returns
        -------
        Reasoner
            The reasoner in READY state.
        """
        op = self.resume(reasoner_type, reasoner_name)
        return op.wait(timeout_s=timeout_s)

    @include_in_docs
    def ensure_ready(
        self,
        reasoner_type: str,
        reasoner_name: str | None = None,
        *,
        reasoner_size: str | None = None,
        auto_suspend_mins: int | None = None,
        await_storage_vacuum: bool | None = None,
        settings: dict[str, Any] | None = None,
        create: bool = True,
        resume: bool = True,
        timeout_s: int = 900,
    ) -> Reasoner:
        """Ensure a reasoner exists and is READY, blocking until completion.

        Returns
        -------
        Reasoner
            The reasoner in READY state.
        """
        op = self.ensure(
            reasoner_type,
            reasoner_name,
            reasoner_size=reasoner_size,
            auto_suspend_mins=auto_suspend_mins,
            await_storage_vacuum=await_storage_vacuum,
            settings=settings,
            create=create,
            resume=resume,
        )
        return op.wait(timeout_s=timeout_s)

    @include_in_docs
    def wait_until_ready(self, reasoner_type: str, reasoner_name: str, *, timeout_s: float = 900) -> Reasoner:
        """Poll until the reasoner is READY (or raise on timeout/not-found).

        Returns
        -------
        Reasoner
            The reasoner in READY state.
        """
        t = self._normalize_reasoner_type(reasoner_type)

        def ready() -> bool:
            """Return True when the reasoner reaches READY state."""
            r = self._lookup_existing_reasoner(t, reasoner_name)
            return (r or Reasoner(name=reasoner_name, type=t)).state == c.REASONER_STATE_READY

        initial_delay, overhead_rate, max_delay = self._polling_cfg()
        poll_until_sync(
            ready,
            timeout_s=float(timeout_s),
            initial_delay=initial_delay,
            overhead_rate=overhead_rate,
            max_delay=max_delay,
            timeout_error=lambda secs: ReasonerTimeoutError(f"Timed out after {secs}s waiting for completion"),
        )
        r = self._lookup_existing_reasoner(t, reasoner_name)
        return self._check_reasoner_ready(r, reasoner_name, t, "after wait")

    @include_in_docs
    def sizes(self) -> list[str]:
        """Return supported reasoner sizes for the configured backend.

        Returns
        -------
        list[str]
            Allowed size identifiers.
        """
        return self._gateway.sizes()

    @include_in_docs
    def validate_size(self, size: str | None) -> tuple[bool, list[str]]:
        """Validate a size, returning `(is_valid, allowed_sizes)`.

        Returns
        -------
        tuple[bool, list[str]]
            A `(is_valid, allowed_sizes)` pair.
        """
        return self._gateway.validate_size(size)

    # --- operations (sync) ---
    @include_in_docs
    def get_operation(self, operation_id: str) -> Operation:
        """Fetch an operation by id.

        Returns
        -------
        Operation
            The operation status.
        """
        return self._gateway.get_operation(operation_id)

    @include_in_docs
    def wait_for_operation(self, operation_id: str, *, timeout_s: int = 900) -> Operation:
        """Block until an operation completes (or fails on timeout).

        Returns
        -------
        Operation
            The final operation status.
        """
        return self._gateway.wait_for_operation(operation_id, timeout_s=timeout_s)

