"""Reasoners gateway protocols.

These protocols define the backend adapter surface used by `ReasonersClient` /
`ReasonersClientSync`. Implementations live in `reasoners/gateways.py`.
"""

from __future__ import annotations

from typing import Any, Protocol

from relationalai.client.transports.types import SnowparkDataFrameLike, SnowparkSessionLike

from .models import Operation, Reasoner


class ReasonersGateway(Protocol):
    """Async Reasoners gateway protocol.

    Sync gateways should be adapted via `SyncToAsyncGatewayAdapter`.
    """

    async def list(
        self,
        *,
        state: str | None = None,
        reasoner_name: str | None = None,
        reasoner_type: str | None = None,
        reasoner_size: str | None = None,
        created_by: str | None = None,
    ) -> list[Reasoner]: ...

    async def get(self, reasoner_type: str, reasoner_name: str) -> Reasoner | None: ...

    async def create(
        self,
        reasoner_type: str,
        reasoner_name: str,
        *,
        reasoner_size: str | None = None,
        auto_suspend_mins: int | None = None,
        await_storage_vacuum: bool | None = None,
        settings: dict[str, Any] | None = None,
    ) -> Operation: ...

    async def delete(self, reasoner_type: str, reasoner_name: str) -> None: ...

    async def suspend(self, reasoner_type: str, reasoner_name: str) -> None: ...

    async def resume(self, reasoner_type: str, reasoner_name: str) -> Operation: ...

    async def sizes(self) -> list[str]: ...

    async def validate_size(self, size: str | None) -> tuple[bool, list[str]]: ...

    async def get_operation(self, operation_id: str) -> Operation: ...
    async def wait_for_operation(self, operation_id: str, *, timeout_s: int = 900) -> Operation: ...

    async def aclose(self) -> None: ...


class ReasonersGatewaySync(Protocol):
    """Synchronous gateway protocol for the reasoners service."""

    # --- lifecycle ---
    def list(
        self,
        *,
        state: str | None = None,
        reasoner_name: str | None = None,
        reasoner_type: str | None = None,
        reasoner_size: str | None = None,
        created_by: str | None = None,
    ) -> list[Reasoner]: ...

    def get(self, reasoner_type: str, reasoner_name: str) -> Reasoner | None: ...

    def create(
        self,
        reasoner_type: str,
        reasoner_name: str,
        *,
        reasoner_size: str | None = None,
        auto_suspend_mins: int | None = None,
        await_storage_vacuum: bool | None = None,
        settings: dict[str, Any] | None = None,
    ) -> Operation: ...

    def delete(self, reasoner_type: str, reasoner_name: str) -> None: ...

    def suspend(self, reasoner_type: str, reasoner_name: str) -> None: ...

    def resume(self, reasoner_type: str, reasoner_name: str) -> Operation: ...

    def sizes(self) -> list[str]: ...

    def validate_size(self, size: str | None) -> tuple[bool, list[str]]: ...

    # --- operations ---
    def get_operation(self, operation_id: str) -> Operation: ...

    def wait_for_operation(self, operation_id: str, *, timeout_s: int = 900) -> Operation: ...


__all__ = [
    "ReasonersGateway",
    "ReasonersGatewaySync",
    "SnowparkDataFrameLike",
    "SnowparkSessionLike",
]

