use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use super::test_support::helpers::*;
use super::test_support::*;

// =========================================================
// 007: Cantilever with end moment
// =========================================================

fn test_007_cantilever_end_moment_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx("test_007_cantilever_end_moment", strategy, lu, fu, pu);
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    // Physical (SI)
    let l_si = 5.0_f64;
    let m_si = 500.0_f64;
    let e_si = 210.0e9_f64;
    let i_zz = 13.21e-6_f64;

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();

    let x1 = 0.0;
    let x2 = l_si / l;

    // Nodal moment unit conversion:
    // M_user * f * l = M_si  =>  M_user = M_si / (f * l)
    let m_user = m_si / (f * l);

    let mat_id = add_material_s235(&mut model, 1);
    let sec_id = add_section_ipe180_like(&mut model, 1, mat_id, i_zz);

    model.nodal_supports.push(make_fixed_support(1));
    let n1 = make_node(1, x1, 0.0, 0.0, Some(1));
    let n2 = make_node(2, x2, 0.0, 0.0, None);
    let m = make_beam_member(1, &n1, &n2, sec_id);
    add_member_set(&mut model, 1, vec![m]);

    let lc_id = add_load_case(&mut model, 1, "End Moment");

    add_nodal_moment(&mut model, 1, lc_id, 2, m_user, (0.0, 0.0, -1.0));
    model.normalize_units();
    model.solve_for_load_case(lc_id).expect("Analysis failed");
    denorm_results_in_place(&mut model);

    let res = &model.results.as_ref().unwrap().loadcases["End Moment"];

    let dy_end = res.displacement_nodes[&2].dy;
    let mz_fixed = res.reaction_nodes[&1].nodal_forces.mz;

    // Analytical:
    // δ(L) = -M L^2 / (2 E I)
    // M_fixed = M
    let dy_si = -m_si * l_si.powi(2) / (2.0 * e_si * i_zz);

    let dy_exp = dy_si / l;
    let mz_exp = m_si / (f * l);

    let tol_d = tol_disp_user(TOL_ABSOLUTE_DISPLACEMENT_IN_METER, l);
    let tol_m = tol_moment_user(TOL_ABSOLUTE_MOMENT_IN_NEWTON_METER, f, l);

    assert_close_ctx(&ctx, dy_end, dy_exp, tol_d, "deflection at free end");
    assert_close_ctx(&ctx, mz_fixed, mz_exp, tol_m, "moment at fixed support");
}

#[test]
fn test_007_cantilever_end_moment() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_007_cantilever_end_moment_case(strategy, lu, fu, pu);
        }
    }
}
