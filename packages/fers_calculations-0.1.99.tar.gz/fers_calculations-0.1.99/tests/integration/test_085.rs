use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use super::test_support::helpers::*;
use super::test_support::*;

// ─────────────────────────────────────────────────────────────────────────────
//  085 — Triple cantilever 3D, geometry rotated −45° around Y
//
//  Same topology as 084, but coordinates rotated.  Same global load
//  (−1000 N in Y) at the tip.  Validates orientation-invariant equilibrium.
//
//  Rotated coordinates:
//    N1(0, 0, 0)          N2(√½, 0, √½)
//    N3(√½, 1, √½)        N4(0, 1, √2)
// ─────────────────────────────────────────────────────────────────────────────

fn test_085_case(strategy: RigidStrategy, lu: LengthUnit, fu: ForceUnit, pu: PressureUnit) {
    let ctx = make_ctx("085_3d_rotated", strategy, lu, fu, pu);
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    let force_si = 1000.0_f64;
    let sqrt_half = 0.5_f64.sqrt();
    let sqrt_two = 2.0_f64.sqrt();

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();
    let fl = f * l;
    let force_u = force_si / f;

    let mat = add_material_s235(&mut model, 1);
    let sec = add_section_ipe180_like(&mut model, 1, mat, SECOND_MOMENT_STRONG_AXIS_IN_M4);

    model.nodal_supports.push(make_fixed_support(1));

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, sqrt_half / l, 0.0, sqrt_half / l, None);
    let n3 = make_node(3, sqrt_half / l, 1.0 / l, sqrt_half / l, None);
    let n4 = make_node(4, 0.0, 1.0 / l, sqrt_two / l, None);
    add_member_set(
        &mut model,
        1,
        vec![
            make_beam_member(1, &n1, &n2, sec),
            make_beam_member(2, &n2, &n3, sec),
            make_beam_member(3, &n3, &n4, sec),
        ],
    );

    let lc = add_load_case(&mut model, 1, "End Load");
    add_nodal_load(&mut model, 1, lc, 4, force_u, (0.0, -1.0, 0.0));

    model.normalize_units();
    model
        .solve_for_load_case(lc)
        .unwrap_or_else(|e| panic!("{ctx}: {e}"));
    denorm_results_in_place(&mut model);

    let r = &model.results.as_ref().unwrap().loadcases["End Load"];
    let rx = r.reaction_nodes.get(&1).unwrap().nodal_forces;

    let tol_f = tol_force_user(TOL_ABSOLUTE_FORCE_IN_NEWTON, f);
    let tol_m = tol_moment_user(TOL_ABSOLUTE_MOMENT_IN_NEWTON_METER, f, l);

    // Force equilibrium
    assert_close_ctx(&ctx, 0.0, rx.fx, tol_f, "Rx.fx");
    assert_close_ctx(&ctx, force_u, rx.fy, tol_f, "Rx.fy");
    assert_close_ctx(&ctx, 0.0, rx.fz, tol_f, "Rx.fz");

    // Moment equilibrium: r × F = (0, 1, √2) × (0, −1000, 0) = (1000√2, 0, 0)
    // → reaction = (−1000√2, 0, 0)
    assert_close_ctx(
        &ctx,
        -force_si * sqrt_two / fl,
        rx.mx,
        tol_m,
        "Rx.mx",
    );
    assert_close_ctx(&ctx, 0.0, rx.my, tol_m, "Rx.my");
    assert_close_ctx(&ctx, 0.0, rx.mz, tol_m, "Rx.mz");
}

#[test]
fn test_085_triple_cantilever_3d_rotated_equilibrium() {
    for s in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_085_case(s, lu, fu, pu);
        }
    }
}
