use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use super::test_support::helpers::*;
use super::test_support::*;

// ============================================================================
// TEST 105: Timoshenko + Warping combined — verify both effects apply
//
// A cantilever with BOTH shear area AND warping constant should show:
//   - Larger transverse deflection than EB (due to shear)
//   - Smaller twist than SV (due to warping restraint)
//
// Uses multi-element mesh for warping convergence.
// ============================================================================
fn test_105_combined_shear_and_warping_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx("test_105_combined_shear_warping", strategy, lu, fu, pu);

    let l_si = 3.0_f64;
    let p_si = 5000.0_f64;
    let t_si = 2000.0_f64;
    let e_si = 210.0e9_f64;
    let g_si = 81.0e9_f64;
    let area_si = 53.8e-4_f64;
    let i_y_si = 604.0e-8_f64;
    let i_z_si = 8356.0e-8_f64;
    let j_si = 20.1e-8_f64;
    let i_w_si = 126.0e-9_f64;
    let a_sz_si = 25.68e-4_f64;

    let n_elem = 10_u32;

    // Analytical
    let dy_eb = -p_si * l_si.powi(3) / (3.0 * e_si * i_z_si);
    let dy_shear = -p_si * l_si / (g_si * a_sz_si);
    let dy_total = dy_eb + dy_shear;

    let theta_sv = t_si * l_si / (g_si * j_si);
    let k = (g_si * j_si / (e_si * i_w_si)).sqrt();
    let kl = k * l_si;
    let theta_vlasov = (t_si * l_si) / (g_si * j_si) * (1.0 - kl.tanh() / kl);

    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);
    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();

    let p_user = p_si / f;
    let t_user = t_si / (f * l);
    let tip_node_id = n_elem + 1;

    let mat_id = add_material_s235(&mut model, 1);
    let sec_id = add_section_with_warping(
        &mut model, 1, "IPE300_FULL", mat_id,
        area_si, i_y_si, i_z_si, j_si,
        Some(i_w_si), None, Some(a_sz_si),
    );

    model.nodal_supports.push(make_fixed_support(1));
    let mut members = Vec::new();
    for i in 0..=n_elem {
        let x = (i as f64) * l_si / (n_elem as f64) / l;
        let sup = if i == 0 { Some(1) } else { None };
        let node = make_node(i + 1, x, 0.0, 0.0, sup);
        if i > 0 {
            let prev = make_node(i, ((i - 1) as f64) * l_si / (n_elem as f64) / l, 0.0, 0.0,
                if i == 1 { Some(1) } else { None });
            members.push(make_beam_member(i, &prev, &node, sec_id));
        }
    }
    add_member_set(&mut model, 1, members);

    let lc_id = add_load_case(&mut model, 1, "Combined");
    add_nodal_load(&mut model, 1, lc_id, tip_node_id, p_user, (0.0, -1.0, 0.0));
    add_nodal_moment(&mut model, 2, lc_id, tip_node_id, t_user, (1.0, 0.0, 0.0));

    model.normalize_units();
    model.solve_for_load_case(lc_id).unwrap_or_else(|e| panic!("[{ctx}] solve failed: {e}"));
    denorm_results_in_place(&mut model);

    let res = &model.results.as_ref().unwrap().loadcases["Combined"];
    let dy_end = res.displacement_nodes[&tip_node_id].dy;
    let rx_end = res.displacement_nodes[&tip_node_id].rx;
    let warp_tip = res.displacement_nodes[&tip_node_id].warp;

    let tol_d = tol_disp_user(TOL_ABSOLUTE_DISPLACEMENT_IN_METER, l);
    let tol_r = TOL_ABSOLUTE_ROTATION_IN_RADIAN;

    // Deflection = bending + shear (Timoshenko)
    assert_close_ctx(&ctx, dy_total / l, dy_end, tol_d, "Timoshenko deflection (combined)");

    // Twist should match Vlasov solution (warping restraint)
    assert_close_ctx(&ctx, theta_vlasov, rx_end, tol_r, "Vlasov twist (combined)");

    // Twist less than St. Venant
    assert!(
        rx_end < theta_sv,
        "[{ctx}] Combined twist ({rx_end}) should be less than SV ({theta_sv})"
    );

    // Warping DOF nonzero
    assert!(
        warp_tip.abs() > 1e-12,
        "[{ctx}] Warping DOF should be nonzero with I_w, got {warp_tip}"
    );
}

#[test]
fn test_105_combined_shear_and_warping() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_105_combined_shear_and_warping_case(strategy, lu, fu, pu);
        }
    }
}
