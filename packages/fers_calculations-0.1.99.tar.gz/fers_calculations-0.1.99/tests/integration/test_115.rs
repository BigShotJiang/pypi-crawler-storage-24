use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use super::test_support::helpers::*;
use super::test_support::*;

// ============================================================================
// TEST 115: Reaction equilibrium under combined bending + torsion
//
// Cantilever with both a transverse load (Y) and a torque (X) at the tip.
// Verifies:  ΣFy = 0,  ΣMz = 0,  ΣMx = 0,  bimoment ≠ 0 at root.
// ============================================================================
fn test_115_reaction_equilibrium_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx("test_115_equilibrium", strategy, lu, fu, pu);

    let l_si = 4.0_f64;
    let p_si = 5000.0_f64;
    let t_si = 2000.0_f64;
    let area_si = 53.8e-4_f64;
    let i_z_si = 8356.0e-8_f64;
    let i_y_si = 604.0e-8_f64;
    let j_si = 20.1e-8_f64;
    let i_w_si = 126.0e-9_f64;
    let a_sz_si = 25.68e-4_f64;

    let n_elem: u32 = 10;
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);
    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();

    let p_user = p_si / f;
    let t_user = t_si / (f * l);

    let mat_id = add_material_s235(&mut model, 1);
    let sec_id = add_section_with_warping(
        &mut model, 1, "IPE300_full", mat_id,
        area_si, i_y_si, i_z_si, j_si,
        Some(i_w_si), None, Some(a_sz_si),
    );

    model.nodal_supports.push(make_fixed_support(1));

    let mut nodes = Vec::new();
    let mut members = Vec::new();
    let tip_node_id = n_elem + 1;

    for i in 0..=n_elem {
        let x = (i as f64) * l_si / (n_elem as f64) / l;
        let sup_id = if i == 0 { Some(1) } else { None };
        nodes.push(make_node(i + 1, x, 0.0, 0.0, sup_id));
    }
    for i in 0..n_elem {
        members.push(make_beam_member(i + 1, &nodes[i as usize], &nodes[(i + 1) as usize], sec_id));
    }
    add_member_set(&mut model, 1, members);

    let lc_id = add_load_case(&mut model, 1, "Combined");
    add_nodal_load(&mut model, 1, lc_id, tip_node_id, p_user, (0.0, -1.0, 0.0));
    add_nodal_moment(&mut model, 2, lc_id, tip_node_id, t_user, (1.0, 0.0, 0.0));

    model.normalize_units();
    model.solve_for_load_case(lc_id).unwrap_or_else(|e| panic!("[{ctx}] solve failed: {e}"));
    denorm_results_in_place(&mut model);

    let res = &model.results.as_ref().unwrap().loadcases["Combined"];
    let fy_react = res.reaction_nodes[&1].nodal_forces.fy;
    let mx_react = res.reaction_nodes[&1].nodal_forces.mx;
    let mz_react = res.reaction_nodes[&1].nodal_forces.mz;

    let tol_f = tol_force_user(TOL_ABSOLUTE_FORCE_IN_NEWTON, f);
    let tol_m = tol_moment_user(TOL_ABSOLUTE_MOMENT_IN_NEWTON_METER, f, l);

    // Reaction Fy = +P (upward to balance downward load)
    assert_close_ctx(&ctx, p_si / f, fy_react, tol_f, "ΣFy = 0");

    // Reaction Mz = P*L (cantilever moment at root)
    let mz_expected = (p_si * l_si) / (f * l);
    assert_close_ctx(&ctx, mz_expected, mz_react, tol_m, "ΣMz = 0");

    // Reaction Mx = -T (balances applied torque)
    let mx_expected = -(t_si) / (f * l);
    assert_close_ctx(&ctx, mx_expected, mx_react, tol_m, "ΣMx = 0");

    // Bimoment at root should be nonzero (warping restrained)
    let bw_root = res.member_results[&1].local_start_forces.bw;
    assert!(
        bw_root.abs() > 1e-6,
        "[{ctx}] Expected nonzero bimoment at root, got {bw_root}"
    );
}

#[test]
fn test_115_reaction_equilibrium() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_115_reaction_equilibrium_case(strategy, lu, fu, pu);
        }
    }
}
