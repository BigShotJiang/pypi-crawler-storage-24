use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};
use fers_calculations::models::supports::supportconditiontype::SupportConditionType;

use super::test_support::formulas::*;
use super::test_support::helpers::*;
use super::test_support::*;

// =========================================================
// 021: Simply Supported Beam with Moment at each Support
// =========================================================
//
// Geometry:
//   node1 (0,0,0) ---- node2 (L/2,0,0) ---- node3 (L,0,0)
//   Simply supported at node1 and node3 (pin supports).
//
// Loading:
//   Nodal moment at node1: Mz = -M0  (direction (0,0,-1))
//   Nodal moment at node3: Mz = +M0  (direction (0,0,+1))
//
// Analytical:
//   - Reaction forces Fy at both supports = 0  (pure bending, no shear)
//   - Deflection at midspan: δ = -M0·L² / (8·E·I)
//   - Internal moment along beam = M0 (constant)
//   - Reaction moments Mz at supports = 0 (pin supports, rz free)

fn test_021_simply_supported_moment_at_each_support_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx(
        "test_021_simply_supported_moment_at_each_support",
        strategy,
        lu,
        fu,
        pu,
    );

    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    // Physical (SI)
    let l_si = 6.0_f64;
    let m0_si = 1000.0_f64;
    let e_si = 210.0e9_f64;
    let i_zz = SECOND_MOMENT_STRONG_AXIS_IN_M4; // 13.21e-6 m^4

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();

    // Node coordinates in user units
    let x1 = 0.0;
    let x2 = (l_si / 2.0) / l; // midspan
    let x3 = l_si / l;

    // Nodal moment in user units: M_user * f * l = M_si => M_user = M_si / (f * l)
    let m0_user = m0_si / (f * l);

    // Material and section
    let mat_id = add_material_s235(&mut model, 1);
    let sec_id = add_section_ipe180_like(&mut model, 1, mat_id, i_zz);

    // Simply supported (pin) support: all translations fixed, rx fixed, ry & rz free
    model.nodal_supports.push(make_support_custom(
        1,
        SupportConditionType::Fixed, // dx
        SupportConditionType::Fixed, // dy
        SupportConditionType::Fixed, // dz
        SupportConditionType::Fixed, // rx
        SupportConditionType::Free,  // ry
        SupportConditionType::Free,  // rz
    ));

    // Nodes
    let n1 = make_node(1, x1, 0.0, 0.0, Some(1)); // left support
    let n2 = make_node(2, x2, 0.0, 0.0, None); // midspan (free)
    let n3 = make_node(3, x3, 0.0, 0.0, Some(1)); // right support (same support type)

    // Members
    let beam1 = make_beam_member(1, &n1, &n2, sec_id);
    let beam2 = make_beam_member(2, &n2, &n3, sec_id);
    add_member_set(&mut model, 1, vec![beam1, beam2]);

    // Load case
    let lc_id = add_load_case(&mut model, 1, "End moments");

    // Applied moments: -M0 at node1, +M0 at node3
    add_nodal_moment(&mut model, 1, lc_id, 1, m0_user, (0.0, 0.0, -1.0));
    add_nodal_moment(&mut model, 2, lc_id, 3, m0_user, (0.0, 0.0, 1.0));

    // Solve
    model.normalize_units();
    model.solve_for_load_case(lc_id).expect("Analysis failed");
    denorm_results_in_place(&mut model);

    let res = model
        .results
        .as_ref()
        .unwrap()
        .loadcases
        .get("End moments")
        .unwrap();

    // Extract results
    let dy_mid = res.displacement_nodes[&2].dy;
    let fy_node1 = res.reaction_nodes[&1].nodal_forces.fy;
    let fy_node3 = res.reaction_nodes[&3].nodal_forces.fy;
    let mz_reaction_node1 = res.reaction_nodes[&1].nodal_forces.mz;
    let mz_reaction_node3 = res.reaction_nodes[&3].nodal_forces.mz;
    let mz_member1_end = res.member_results[&1].end_node_forces.mz;

    // Analytical expectations (in SI, then converted to user units)
    let dy_si = simply_supported_end_moments_deflection_at_midspan(m0_si, l_si, e_si, i_zz);
    let dy_exp = dy_si / l;

    let fy_exp = 0.0; // no vertical reaction (pure bending)
    let mz_reaction_exp = 0.0; // pin support, rz free
    let mz_member1_end_exp = m0_si / (f * l); // internal moment = M0

    // Tolerances
    let tol_d = tol_disp_user(TOL_ABSOLUTE_DISPLACEMENT_IN_METER, l);
    let tol_f = tol_force_user(TOL_ABSOLUTE_FORCE_IN_NEWTON, f);
    let tol_m = tol_moment_user(TOL_ABSOLUTE_MOMENT_IN_NEWTON_METER, f, l);

    // Assertions
    assert_close_ctx(&ctx, dy_mid, dy_exp, tol_d, "deflection at midspan");
    assert_close_ctx(
        &ctx,
        fy_node1,
        fy_exp,
        tol_f,
        "reaction force Fy at left support",
    );
    assert_close_ctx(
        &ctx,
        fy_node3,
        fy_exp,
        tol_f,
        "reaction force Fy at right support",
    );
    assert_close_ctx(
        &ctx,
        mz_reaction_node1,
        mz_reaction_exp,
        tol_m,
        "reaction moment Mz at left support",
    );
    assert_close_ctx(
        &ctx,
        mz_reaction_node3,
        mz_reaction_exp,
        tol_m,
        "reaction moment Mz at right support",
    );
    assert_close_ctx(
        &ctx,
        mz_member1_end,
        mz_member1_end_exp,
        tol_m,
        "internal moment Mz at end of member 1 (midspan)",
    );
}

#[test]
fn test_021_simply_supported_moment_at_each_support() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_021_simply_supported_moment_at_each_support_case(strategy, lu, fu, pu);
        }
    }
}
