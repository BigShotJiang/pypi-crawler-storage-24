use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};

use super::test_support::helpers::*;
use super::test_support::*;

// ============================================================================
// TEST 106: Timoshenko cantilever with UDL
//
// Analytical:
//   δ_EB = wL⁴/(8EI)
//   δ_T  = wL⁴/(8EI) + wL²/(2GA_s)
// ============================================================================
fn test_106_timoshenko_cantilever_udl_case(
    strategy: RigidStrategy,
    lu: LengthUnit,
    fu: ForceUnit,
    pu: PressureUnit,
) {
    let ctx = make_ctx("test_106_timoshenko_cantilever_udl", strategy, lu, fu, pu);

    let l_si = 4.0_f64;
    let w_si = 2000.0_f64;           // 2 kN/m UDL (negative Y)
    let e_si = 210.0e9_f64;
    let g_si = 81.0e9_f64;
    let area_si = 53.8e-4_f64;
    let i_z_si = 8356.0e-8_f64;
    let i_y_si = 604.0e-8_f64;
    let j_si = 20.1e-8_f64;
    let a_sz_si = 25.68e-4_f64;

    let delta_bending = w_si * l_si.powi(4) / (8.0 * e_si * i_z_si);
    let delta_shear = w_si * l_si.powi(2) / (2.0 * g_si * a_sz_si);
    let delta_total = delta_bending + delta_shear;

    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);
    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();

    let x2 = l_si / l;
    let w_user = -w_si / (f / l);  // N/m → user force/user length

    let mat_id = add_material_s235(&mut model, 1);
    let sec_id = add_section_with_warping(
        &mut model, 1, "IPE300_T", mat_id,
        area_si, i_y_si, i_z_si, j_si,
        None, None, Some(a_sz_si),
    );

    model.nodal_supports.push(make_fixed_support(1));
    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, x2, 0.0, 0.0, None);
    let m1 = make_beam_member(1, &n1, &n2, sec_id);
    add_member_set(&mut model, 1, vec![m1]);

    let lc_id = add_load_case(&mut model, 1, "UDL");
    add_member_distributed_load_global_y(&mut model, 1, lc_id, 1, w_user, w_user, 0.0, 1.0);

    model.normalize_units();
    model.solve_for_load_case(lc_id).unwrap_or_else(|e| panic!("[{ctx}] solve failed: {e}"));
    denorm_results_in_place(&mut model);

    let res = &model.results.as_ref().unwrap().loadcases["UDL"];
    let dy_end = res.displacement_nodes[&2].dy;

    let expected = -delta_total / l;
    let tol_d = tol_disp_user(TOL_ABSOLUTE_DISPLACEMENT_IN_METER, l);
    assert_close_ctx(&ctx, expected, dy_end, tol_d, "Timoshenko UDL deflection");
}

#[test]
fn test_106_timoshenko_cantilever_udl() {
    for strategy in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_106_timoshenko_cantilever_udl_case(strategy, lu, fu, pu);
        }
    }
}
