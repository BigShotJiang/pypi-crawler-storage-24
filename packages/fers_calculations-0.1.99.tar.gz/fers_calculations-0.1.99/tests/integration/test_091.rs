use fers_calculations::models::settings::analysissettings::RigidStrategy;
use fers_calculations::models::settings::unitenums::{ForceUnit, LengthUnit, PressureUnit};
use fers_calculations::models::supports::supportconditiontype::SupportConditionType;
use fers_calculations::models::loads::loadcombination::LoadCombination;
use std::collections::HashMap;

use super::test_support::helpers::*;
use super::test_support::*;

// ─────────────────────────────────────────────────────────────────────────────
//  091 — Load combination superposition on L-frame
//
//  Same geometry as 081 (L-frame: N1–N2–N3).
//  Two identical load cases: LC1 = −100 N in X at N3, LC2 = −100 N in X at N3.
//  Combination: 1×LC1 + 2×LC2.
//
//  Because both load cases apply the same load and the system is linear,
//  the combination result must equal 3× the individual LC result.
// ─────────────────────────────────────────────────────────────────────────────

fn test_091_case(strategy: RigidStrategy, lu: LengthUnit, fu: ForceUnit, pu: PressureUnit) {
    let ctx = make_ctx("091_combo_superposition", strategy, lu, fu, pu);
    let mut model = make_fers_with_strategy_and_units(strategy, lu, fu, pu);

    let length_si = 5.0_f64;
    let force_si = 100.0_f64;

    let u = &model.settings.unit_settings;
    let l = u.length_to_m();
    let f = u.force_to_n();
    let fl = f * l;
    let len = length_si / l;
    let force_u = force_si / f;

    let mat = add_material_s235(&mut model, 1);
    let sec = add_section_ipe180_like(&mut model, 1, mat, SECOND_MOMENT_STRONG_AXIS_IN_M4);

    // Supports (same as 081)
    model.nodal_supports.push(make_fixed_support(1));
    model.nodal_supports.push(make_support_custom(
        2,
        SupportConditionType::Free,
        SupportConditionType::Free,
        SupportConditionType::Fixed,
        SupportConditionType::Free,
        SupportConditionType::Free,
        SupportConditionType::Free,
    ));

    let n1 = make_node(1, 0.0, 0.0, 0.0, Some(1));
    let n2 = make_node(2, len, 0.0, 0.0, Some(2));
    let n3 = make_node(3, len, len, 0.0, Some(2));
    add_member_set(
        &mut model,
        1,
        vec![
            make_beam_member(1, &n1, &n2, sec),
            make_beam_member(2, &n2, &n3, sec),
        ],
    );

    // Two identical load cases
    let lc1 = add_load_case(&mut model, 1, "End Load 1");
    add_nodal_load(&mut model, 1, lc1, 3, force_u, (-1.0, 0.0, 0.0));

    let lc2 = add_load_case(&mut model, 2, "End Load 2");
    add_nodal_load(&mut model, 2, lc2, 3, force_u, (-1.0, 0.0, 0.0));

    // Combination: 1×LC1 + 2×LC2
    model.load_combinations.push(LoadCombination {
        id: 1,
        name: "Combo".to_string(),
        load_cases_factors: HashMap::from([(1, 1.0), (2, 2.0)]),
        situation: Some("SLS".to_string()),
        check: "ALL".to_string(),
        limit_state: None,
    });

    model.normalize_units();
    model
        .solve_for_load_case(lc1)
        .unwrap_or_else(|e| panic!("{ctx}: LC1 {e}"));
    model
        .solve_for_load_case(lc2)
        .unwrap_or_else(|e| panic!("{ctx}: LC2 {e}"));
    model
        .solve_for_load_combination(1)
        .unwrap_or_else(|e| panic!("{ctx}: combo {e}"));
    denorm_results_in_place(&mut model);

    let results = model.results.as_ref().unwrap();

    // Individual LC1 results at node 3
    let d1 = results.loadcases["End Load 1"]
        .displacement_nodes
        .get(&3)
        .unwrap();
    let r1 = results.loadcases["End Load 1"]
        .reaction_nodes
        .get(&1)
        .unwrap()
        .nodal_forces;

    // Combination results
    let dc = results.loadcombinations["Combo"]
        .displacement_nodes
        .get(&3)
        .unwrap();
    let rc = results.loadcombinations["Combo"]
        .reaction_nodes
        .get(&1)
        .unwrap()
        .nodal_forces;

    let tol_d = tol_disp_user(TOL_ABSOLUTE_DISPLACEMENT_IN_METER, l);
    let tol_f = tol_force_user(TOL_ABSOLUTE_FORCE_IN_NEWTON, f);
    let tol_m = tol_moment_user(TOL_ABSOLUTE_MOMENT_IN_NEWTON_METER, f, l);

    // Superposition: combo = 1×LC1 + 2×LC2 = 3×LC1 (same load)
    assert_close_ctx(&ctx, 3.0 * d1.dx, dc.dx, tol_d, "combo.dx");
    assert_close_ctx(&ctx, 3.0 * d1.dy, dc.dy, tol_d, "combo.dy");
    assert_close_ctx(&ctx, 3.0 * d1.dz, dc.dz, tol_d, "combo.dz");

    // Reaction superposition
    assert_close_ctx(&ctx, 3.0 * r1.fx, rc.fx, tol_f, "combo_R1.fx");
    assert_close_ctx(&ctx, 3.0 * r1.mz, rc.mz, tol_m, "combo_R1.mz");

    // Absolute equilibrium of combo: applied = 3×(−100) = −300 N in X → Rx = 300
    let total_force_u = 3.0 * force_u;
    assert_close_ctx(&ctx, total_force_u, rc.fx, tol_f, "combo_R1.fx_abs");
    assert_close_ctx(
        &ctx,
        -3.0 * force_si * length_si / fl,
        rc.mz,
        tol_m,
        "combo_R1.mz_abs",
    );
}

#[test]
fn test_091_load_combination_superposition() {
    for s in all_strategies() {
        for (lu, fu, pu) in unit_scenarios() {
            test_091_case(s, lu, fu, pu);
        }
    }
}
