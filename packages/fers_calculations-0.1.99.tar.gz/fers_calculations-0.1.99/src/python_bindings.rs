// Only compiled when you do `--features python`
use crate::analysis::{
    calculate_from_file_internal, calculate_from_json_internal,
    calculate_from_json_internal_with_tier,
    load_fers_from_file as load_fers_from_file_internal,
};
use crate::limits::LicenseTier;
use pyo3::exceptions::PyRuntimeError;
use pyo3::prelude::*;
use pyo3::wrap_pyfunction;
use std::panic;

/// Convert a panic payload into a human-readable error string.
fn panic_to_string(payload: Box<dyn std::any::Any + Send>) -> String {
    if let Some(s) = payload.downcast_ref::<&str>() {
        format!("Internal solver panic: {}", s)
    } else if let Some(s) = payload.downcast_ref::<String>() {
        format!("Internal solver panic: {}", s)
    } else {
        "Internal solver panic (unknown cause)".to_string()
    }
}

/// Verify a premium license by calling the ferscloud.com API.
///
/// Sends `GET {base_url}/api/sdk/me` with the user's API key.
/// Returns `Ok(())` if the user has a valid premium subscription,
/// or `Err(message)` with a human-readable reason.
fn verify_premium_license(api_key: &str) -> Result<(), String> {
    let base_url = std::env::var("FERS_CLOUD_URL")
        .unwrap_or_else(|_| "https://ferscloud.com".to_string());

    let url = format!("{}/api/sdk/me", base_url.trim_end_matches('/'));

    let agent = ureq::AgentBuilder::new()
        .tls_connector(std::sync::Arc::new(
            native_tls::TlsConnector::new()
                .map_err(|e| format!("TLS initialization failed: {}", e))?,
        ))
        .build();

    let response = agent
        .get(&url)
        .set("X-API-Key", api_key)
        .call()
        .map_err(|e| match e {
            ureq::Error::Status(401, _) => {
                "Invalid or expired API key. Create one at https://ferscloud.com/profile".to_string()
            }
            ureq::Error::Status(code, _) => {
                format!("License server returned HTTP {}", code)
            }
            ureq::Error::Transport(t) => {
                format!("Could not reach license server ({}): check your internet connection", t)
            }
        })?;

    let body: serde_json::Value = response.into_json().map_err(|e| {
        format!("Unexpected response from license server: {}", e)
    })?;

    match body.get("is_premium").and_then(|v| v.as_bool()) {
        Some(true) => Ok(()),
        Some(false) => Err(
            "Your account does not have a premium license. Upgrade at https://ferscloud.com/upgrade"
                .to_string(),
        ),
        None => Err("Unexpected response from license server".to_string()),
    }
}

#[pyfunction]
#[pyo3(signature = (json_data, api_key=None))]
pub fn calculate_from_json(py: Python, json_data: &str, api_key: Option<&str>) -> PyResult<String> {
    match api_key {
        Some(key) => {
            let key_owned = key.to_string();
            let json_owned = json_data.to_string();
            py.allow_threads(|| {
                panic::catch_unwind(panic::AssertUnwindSafe(|| {
                    verify_premium_license(&key_owned)?;
                    calculate_from_json_internal_with_tier(&json_owned, LicenseTier::Premium)
                }))
                .unwrap_or_else(|e| Err(panic_to_string(e)))
            })
            .map_err(PyRuntimeError::new_err)
        }
        None => {
            let json_owned = json_data.to_string();
            py.allow_threads(|| {
                panic::catch_unwind(panic::AssertUnwindSafe(|| {
                    calculate_from_json_internal(&json_owned)
                }))
                .unwrap_or_else(|e| Err(panic_to_string(e)))
            })
            .map_err(PyRuntimeError::new_err)
        }
    }
}

#[pyfunction]
pub fn calculate_from_file(path: &str) -> PyResult<String> {
    let path_owned = path.to_string();
    panic::catch_unwind(panic::AssertUnwindSafe(|| {
        calculate_from_file_internal(&path_owned)
    }))
    .unwrap_or_else(|e| Err(panic_to_string(e)))
    .map_err(PyRuntimeError::new_err)
}

#[pyfunction]
pub fn load_fers_from_file(path: &str) -> PyResult<String> {
    let path_owned = path.to_string();
    panic::catch_unwind(panic::AssertUnwindSafe(|| {
        let fers = load_fers_from_file_internal(&path_owned)
            .map_err(|error| error.to_string())?;
        serde_json::to_string(&fers).map_err(|error| error.to_string())
    }))
    .unwrap_or_else(|e| Err(panic_to_string(e)))
    .map_err(PyRuntimeError::new_err)
}

#[pymodule]
fn fers_calculations(_py: Python, m: &PyModule) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(calculate_from_json, m)?)?;
    m.add_function(wrap_pyfunction!(calculate_from_file, m)?)?;
    m.add_function(wrap_pyfunction!(load_fers_from_file, m)?)?;
    Ok(())
}
