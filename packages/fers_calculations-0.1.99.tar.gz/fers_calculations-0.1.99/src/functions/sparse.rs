// src/functions/sparse.rs
//!
//! Sparse assembly helpers for the FEM global stiffness matrix.
//!
//! Element-level matrices (14×14) stay dense. This module collects COO
//! (coordinate / triplet) entries during assembly and converts them into
//! a `faer::sparse::SparseColMat` (CSC) for efficient sparse solving.

use faer::sparse::SparseColMat;
use faer::prelude::SpSolver;
use faer::Mat;

use crate::functions::geometry::DOFS_PER_NODE;

/// Re-usable sparse triplet (COO) assembler.
///
/// Usage:
///   1. `let mut asm = SparseAssembler::new(n_dofs);`
///   2. For each element: `asm.assemble_element(i0, j0, &ke_14x14);`
///   3. After all elements: `let csc = asm.to_csc();`
pub struct SparseAssembler {
    n: usize,
    triplets: Vec<(usize, usize, f64)>,
}

impl SparseAssembler {
    /// Create a new assembler for a system with `n` degrees of freedom.
    pub fn new(n: usize) -> Self {
        Self {
            n,
            triplets: Vec::new(),
        }
    }

    /// Pre-allocate capacity for the expected number of elements.
    /// Each beam element contributes 4 × 7×7 = 196 triplets.
    pub fn with_capacity(n: usize, n_elements: usize) -> Self {
        Self {
            n,
            triplets: Vec::with_capacity(n_elements * 196),
        }
    }

    /// Scatter a 14×14 element stiffness matrix (2 nodes × 7 DOFs) into the
    /// global assembler. `i0` and `j0` are the base DOF indices for the start
    /// and end nodes respectively.
    pub fn assemble_element(
        &mut self,
        i0: usize,
        j0: usize,
        ke: &nalgebra::DMatrix<f64>,
    ) {
        debug_assert_eq!(ke.nrows(), DOFS_PER_NODE * 2);
        debug_assert_eq!(ke.ncols(), DOFS_PER_NODE * 2);

        for i in 0..DOFS_PER_NODE {
            for j in 0..DOFS_PER_NODE {
                // Upper-left block: start–start
                let v = ke[(i, j)];
                if v != 0.0 {
                    self.triplets.push((i0 + i, i0 + j, v));
                }
                // Upper-right block: start–end
                let v = ke[(i, j + DOFS_PER_NODE)];
                if v != 0.0 {
                    self.triplets.push((i0 + i, j0 + j, v));
                }
                // Lower-left block: end–start
                let v = ke[(i + DOFS_PER_NODE, j)];
                if v != 0.0 {
                    self.triplets.push((j0 + i, i0 + j, v));
                }
                // Lower-right block: end–end
                let v = ke[(i + DOFS_PER_NODE, j + DOFS_PER_NODE)];
                if v != 0.0 {
                    self.triplets.push((j0 + i, j0 + j, v));
                }
            }
        }
    }

    /// Add a single triplet entry (row, col, value).
    /// Duplicate (row, col) entries are summed during CSC conversion.
    #[inline]
    pub fn add(&mut self, row: usize, col: usize, value: f64) {
        if value != 0.0 {
            self.triplets.push((row, col, value));
        }
    }

    /// Number of triplets currently stored.
    pub fn nnz(&self) -> usize {
        self.triplets.len()
    }

    /// Convert accumulated triplets to a faer CSC matrix.
    /// Duplicate entries at the same (row, col) are summed.
    pub fn to_csc(&self) -> SparseColMat<usize, f64> {
        SparseColMat::<usize, f64>::try_new_from_triplets(self.n, self.n, &self.triplets)
            .expect("SparseAssembler: failed to build CSC matrix from triplets")
    }

    /// Convert to a dense `nalgebra::DMatrix` (useful for debugging / testing).
    #[allow(dead_code)]
    pub fn to_dense(&self) -> nalgebra::DMatrix<f64> {
        let mut m = nalgebra::DMatrix::<f64>::zeros(self.n, self.n);
        for &(r, c, v) in &self.triplets {
            m[(r, c)] += v;
        }
        m
    }

    /// Clear all triplets, keeping allocated capacity.
    pub fn clear(&mut self) {
        self.triplets.clear();
    }
}

/// Convert a faer sparse CSC matrix to a dense nalgebra DMatrix.
/// Useful for the `reduce_system` path where the reduced matrix is small.
pub fn sparse_to_dense(sparse: &SparseColMat<usize, f64>) -> nalgebra::DMatrix<f64> {
    let nrows = sparse.nrows();
    let ncols = sparse.ncols();
    let mut dense = nalgebra::DMatrix::<f64>::zeros(nrows, ncols);
    // Iterate over columns
    let symbolic = sparse.symbolic();
    let col_ptrs = symbolic.col_ptrs();
    let row_indices = symbolic.row_indices();
    let values = sparse.values();
    for col in 0..ncols {
        let start = col_ptrs[col];
        let end = col_ptrs[col + 1];
        for idx in start..end {
            let row = row_indices[idx];
            dense[(row, col)] += values[idx];
        }
    }
    dense
}

/// Sparse matrix–dense matrix product: A_sparse * B_dense → C_dense.
/// Used for `K_full_sparse * S_dense` in `reduce_system`.
/// Column-oriented for cache-friendly access with column-major storage,
/// and parallelised across output columns with rayon.
pub fn spmm_sparse_dense(
    sparse: &SparseColMat<usize, f64>,
    dense: &nalgebra::DMatrix<f64>,
) -> nalgebra::DMatrix<f64> {
    use rayon::prelude::*;

    let m = sparse.nrows();
    let n = dense.ncols();
    debug_assert_eq!(sparse.ncols(), dense.nrows());

    let symbolic = sparse.symbolic();
    let col_ptrs = symbolic.col_ptrs();
    let row_indices = symbolic.row_indices();
    let values = sparse.values();

    // Compute each output column in parallel.
    // For column j: result[:,j] = A_sparse * dense[:,j]
    let columns: Vec<Vec<f64>> = (0..n)
        .into_par_iter()
        .map(|j| {
            let mut col = vec![0.0_f64; m];
            for k in 0..sparse.ncols() {
                let d_kj = dense[(k, j)];
                if d_kj == 0.0 {
                    continue;
                }
                let start = col_ptrs[k];
                let end = col_ptrs[k + 1];
                for idx in start..end {
                    col[row_indices[idx]] += values[idx] * d_kj;
                }
            }
            col
        })
        .collect();

    nalgebra::DMatrix::from_fn(m, n, |i, j| columns[j][i])
}

/// Compute S^T * K_sparse * S where K is sparse and S is dense.
/// Returns a dense reduced matrix.
/// Uses faer's optimized matmul for the S^T * KS step.
pub fn reduce_with_sparse_k(
    k_sparse: &SparseColMat<usize, f64>,
    s: &nalgebra::DMatrix<f64>,
) -> nalgebra::DMatrix<f64> {
    // KS = K_sparse * S  (sparse × dense → dense)
    let ks = spmm_sparse_dense(k_sparse, s);

    // S^T * KS using faer's optimized matmul (BLAS-like performance).
    // Zero-copy views: nalgebra and faer both use contiguous column-major storage.
    let n_red = s.ncols();
    let n_full = s.nrows();
    let s_faer = faer::mat::from_column_major_slice(s.as_slice(), n_full, n_red);
    let ks_faer = faer::mat::from_column_major_slice(ks.as_slice(), n_full, n_red);
    let mut result = Mat::<f64>::zeros(n_red, n_red);
    faer::linalg::matmul::matmul(
        result.as_mut(),
        s_faer.transpose(),
        ks_faer,
        None,
        1.0,
        faer::Parallelism::Rayon(0),
    );
    nalgebra::DMatrix::from_fn(n_red, n_red, |i, j| result.read(i, j))
}

/// Solve a dense linear system K * x = f using faer's optimized LU factorization.
/// Returns None if the system is singular.
///
/// Uses zero-copy views via `from_column_major_slice` to avoid copying the
/// stiffness matrix from nalgebra to faer.  Both libraries use column-major
/// layout so the raw storage is directly reinterpretable.
pub fn solve_dense_lu(
    k: &nalgebra::DMatrix<f64>,
    f: &nalgebra::DMatrix<f64>,
) -> Option<nalgebra::DMatrix<f64>> {
    let n = k.nrows();
    // Zero-copy views: nalgebra and faer both use contiguous column-major storage.
    // This avoids an O(n²) element-by-element copy for the stiffness matrix.
    let k_faer = faer::mat::from_column_major_slice(k.as_slice(), n, n);
    let f_faer = faer::mat::from_column_major_slice(f.as_slice(), f.nrows(), f.ncols());
    let lu = k_faer.partial_piv_lu();
    let x_faer = lu.solve(f_faer);
    Some(nalgebra::DMatrix::from_fn(n, 1, |i, _| x_faer.read(i, 0)))
}

/// Opaque wrapper around a cached LU factorisation.
/// Keeps the factorisation alive so it can solve multiple right-hand sides
/// without re-factorising. Reserved for future Modified Newton-Raphson.
#[allow(dead_code)]
pub struct CachedLu {
    lu: nalgebra::linalg::LU<f64, nalgebra::Dyn, nalgebra::Dyn>,
}

impl CachedLu {
    /// Factorise a dense nalgebra matrix.  Returns `None` when the matrix is
    /// empty (zero dimension).
    pub fn new(k: &nalgebra::DMatrix<f64>) -> Option<Self> {
        if k.nrows() == 0 {
            return None;
        }
        Some(Self { lu: k.clone().lu() })
    }

    /// Solve K x = rhs using the cached factorisation.
    /// Returns `None` if the original matrix was singular.
    pub fn solve(&self, rhs: &nalgebra::DMatrix<f64>) -> Option<nalgebra::DMatrix<f64>> {
        self.lu.solve(rhs)
    }
}

/// Compute S^T * f_full where S is dense and f_full is a dense column vector.
pub fn reduce_force(
    s: &nalgebra::DMatrix<f64>,
    f_full: &nalgebra::DMatrix<f64>,
) -> nalgebra::DMatrix<f64> {
    s.transpose() * f_full
}

/// Add two sparse CSC matrices with the same dimensions.
/// Returns a new sparse matrix with all entries summed.
pub fn sparse_add(
    a: &SparseColMat<usize, f64>,
    b: &SparseColMat<usize, f64>,
) -> SparseColMat<usize, f64> {
    debug_assert_eq!(a.nrows(), b.nrows());
    debug_assert_eq!(a.ncols(), b.ncols());

    let n = a.nrows();
    let mut asm = SparseAssembler::new(n);

    // Add all entries from a
    let sym_a = a.symbolic();
    let col_ptrs_a = sym_a.col_ptrs();
    let row_indices_a = sym_a.row_indices();
    let values_a = a.values();
    for col in 0..a.ncols() {
        for idx in col_ptrs_a[col]..col_ptrs_a[col + 1] {
            asm.add(row_indices_a[idx], col, values_a[idx]);
        }
    }

    // Add all entries from b
    let sym_b = b.symbolic();
    let col_ptrs_b = sym_b.col_ptrs();
    let row_indices_b = sym_b.row_indices();
    let values_b = b.values();
    for col in 0..b.ncols() {
        for idx in col_ptrs_b[col]..col_ptrs_b[col + 1] {
            asm.add(row_indices_b[idx], col, values_b[idx]);
        }
    }

    asm.to_csc()
}

/// Add support springs (diagonal entries) to an existing sparse matrix.
/// Returns a new sparse matrix.
pub fn sparse_add_diagonal(
    matrix: &SparseColMat<usize, f64>,
    entries: &[(usize, f64)],
) -> SparseColMat<usize, f64> {
    let n = matrix.nrows();
    let mut asm = SparseAssembler::new(n);

    // Copy existing entries
    let sym = matrix.symbolic();
    let col_ptrs = sym.col_ptrs();
    let row_indices = sym.row_indices();
    let values = matrix.values();
    for col in 0..matrix.ncols() {
        for idx in col_ptrs[col]..col_ptrs[col + 1] {
            asm.add(row_indices[idx], col, values[idx]);
        }
    }

    // Add diagonal entries
    for &(dof, value) in entries {
        asm.add(dof, dof, value);
    }

    asm.to_csc()
}

#[cfg(test)]
mod tests {
    use super::*;
    use nalgebra::DMatrix;

    #[test]
    fn test_assembler_single_element() {
        // 2-node element with 7 DOFs per node = 14×14 element matrix
        let n_dofs = 14; // 2 nodes
        let mut asm = SparseAssembler::new(n_dofs);

        let mut ke = DMatrix::<f64>::zeros(14, 14);
        ke[(0, 0)] = 100.0;
        ke[(0, 7)] = -100.0;
        ke[(7, 0)] = -100.0;
        ke[(7, 7)] = 100.0;

        asm.assemble_element(0, 7, &ke);

        let dense = asm.to_dense();
        assert_eq!(dense[(0, 0)], 100.0);
        assert_eq!(dense[(0, 7)], -100.0);
        assert_eq!(dense[(7, 0)], -100.0);
        assert_eq!(dense[(7, 7)], 100.0);

        let csc = asm.to_csc();
        let csc_dense = sparse_to_dense(&csc);
        assert!((dense - csc_dense).norm() < 1e-12);
    }

    #[test]
    fn test_sparse_add() {
        let n = 4;
        let mut asm_a = SparseAssembler::new(n);
        asm_a.add(0, 0, 1.0);
        asm_a.add(1, 1, 2.0);
        let a = asm_a.to_csc();

        let mut asm_b = SparseAssembler::new(n);
        asm_b.add(0, 0, 3.0);
        asm_b.add(2, 2, 4.0);
        let b = asm_b.to_csc();

        let c = sparse_add(&a, &b);
        let dense_c = sparse_to_dense(&c);

        assert_eq!(dense_c[(0, 0)], 4.0);
        assert_eq!(dense_c[(1, 1)], 2.0);
        assert_eq!(dense_c[(2, 2)], 4.0);
    }

    #[test]
    fn test_reduce_with_sparse_k() {
        // Simple 4×4 K, reduce to 2×2 via S
        let mut asm = SparseAssembler::new(4);
        asm.add(0, 0, 10.0);
        asm.add(1, 1, 20.0);
        asm.add(2, 2, 30.0);
        asm.add(3, 3, 40.0);
        let k = asm.to_csc();

        // S selects DOFs 0 and 2 (identity columns)
        let mut s = DMatrix::<f64>::zeros(4, 2);
        s[(0, 0)] = 1.0;
        s[(2, 1)] = 1.0;

        let k_red = reduce_with_sparse_k(&k, &s);
        assert_eq!(k_red.nrows(), 2);
        assert_eq!(k_red.ncols(), 2);
        assert!((k_red[(0, 0)] - 10.0).abs() < 1e-12);
        assert!((k_red[(1, 1)] - 30.0).abs() < 1e-12);
        assert!((k_red[(0, 1)]).abs() < 1e-12);
    }

    #[test]
    fn test_spmm_sparse_dense() {
        let mut asm = SparseAssembler::new(3);
        asm.add(0, 0, 2.0);
        asm.add(0, 1, 1.0);
        asm.add(1, 1, 3.0);
        asm.add(2, 2, 4.0);
        let sparse = asm.to_csc();

        let dense = DMatrix::from_row_slice(3, 2, &[1.0, 0.0, 0.0, 1.0, 1.0, 1.0]);

        let result = spmm_sparse_dense(&sparse, &dense);

        // row 0: 2*1 + 1*0 = 2, 2*0 + 1*1 = 1
        // row 1: 0*1 + 3*0 = 0, 0*0 + 3*1 = 3
        // row 2: 0*1 + 0*0 + 4*1 = 4, 0*0 + 0*1 + 4*1 = 4
        assert!((result[(0, 0)] - 2.0).abs() < 1e-12);
        assert!((result[(0, 1)] - 1.0).abs() < 1e-12);
        assert!((result[(1, 0)] - 0.0).abs() < 1e-12);
        assert!((result[(1, 1)] - 3.0).abs() < 1e-12);
        assert!((result[(2, 0)] - 4.0).abs() < 1e-12);
        assert!((result[(2, 1)] - 4.0).abs() < 1e-12);
    }
}
