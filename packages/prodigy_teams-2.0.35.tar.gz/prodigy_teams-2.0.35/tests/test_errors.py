"""Tests for prodigy_teams.errors — custom exception classes."""

from __future__ import annotations

from pathlib import Path

from prodigy_teams.errors import (
    CLIError,
    ProdigyTeamsError,
    ProdigyTeamsIDTokenError,
    ProdigyTeamsParseSecretsError,
    RecipeBuildMetaFailed,
)


class TestProdigyTeamsError:
    def test_basic(self):
        e = ProdigyTeamsError("something broke")
        assert e.message == "something broke"
        assert str(e) == "something broke"

    def test_empty_message(self):
        e = ProdigyTeamsError()
        assert e.message == ""


class TestProdigyTeamsIDTokenError:
    def test_inherits(self):
        e = ProdigyTeamsIDTokenError("token bad")
        assert isinstance(e, ProdigyTeamsError)
        assert e.message == "token bad"


class TestCLIError:
    def test_title_only(self):
        e = CLIError("Title")
        assert e.title == "Title"
        assert e.text is None
        assert e.message == "Title"

    def test_title_and_text(self):
        e = CLIError("Title", "detail text")
        assert e.title == "Title"
        assert e.text == "detail text"
        assert "Title" in e.message
        assert "detail text" in e.message


class TestProdigyTeamsParseSecretsError:
    def test_with_path_and_error(self):
        path = Path("/tmp/secrets.json")
        inner = ValueError("bad json")
        e = ProdigyTeamsParseSecretsError(path, inner)
        assert "/tmp/secrets.json" in str(e)
        assert "bad json" in str(e)

    def test_with_none_path(self):
        e = ProdigyTeamsParseSecretsError(None)
        assert str(e)  # Should not crash

    def test_with_no_inner_error(self):
        path = Path("/tmp/secrets.json")
        e = ProdigyTeamsParseSecretsError(path)
        assert "/tmp/secrets.json" in str(e)


class TestRecipeBuildMetaFailed:
    def test_attributes(self):
        e = RecipeBuildMetaFailed("my-package", "stdout text", "stderr text")
        assert e.package_name == "my-package"
        assert e.stdout == "stdout text"
        assert e.stderr == "stderr text"
        assert "my-package" in str(e)
