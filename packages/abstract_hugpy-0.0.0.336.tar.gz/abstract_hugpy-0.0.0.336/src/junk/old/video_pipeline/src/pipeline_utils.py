# src/pipeline_ur.py
from .imports import *

def get_thumbnails(video_id: str, video_path: str, thumbnails_path: str):
    """
    Extract thumbnails + OCR → persist into DB JSON.
    """
##    print(f"video_id=={video_id}\nvideo_path=={video_path}\nthumbnails_path={thumbnails_path}")
    paths = extract_video_frames_unique(video_path, thumbnails_path, video_id=video_id)
    texts = [ocr_image(p) for p in paths]
    thumbnails = {"paths": paths, "texts": texts}
    upsert_video(video_id, thumbnails=thumbnails)
    return thumbnails

def get_all_metadata(video_id,data):
    base_url = "https://clownworld.biz"
    record = get_video_record(video_id=video_id)
    video_info = record.get("info") or {}
    directory = video_info.get("directory")
    meta_file_path = os.path.join(directory, "meta.json")
    metadict = build_seo_meta_from_result(data, base_url=base_url)
    # Make sure all paths inside metadict are URL-style before saving
    metadict_public = convert_paths_to_urls(metadict, base_url=base_url)
    upsert_video(video_id, metatags=metadict_public)
    safe_dump_to_json(data=metadict_public, file_path=meta_file_path)
    return metadict_public

            
def get_pipeline_key(key):
    pipeline_key_map = {
     'all': ['all', 'all_data', 'data', 'get_all', 'get'],
     'info': ['info', 'video_info', 'video'],
     'id': ['id', 'video_id'],
     'url': ['url', 'video_url'],
     'path': ['path', 'video_path'],
     'record': ['record','video_record'],
     'dir': ['directory', 'video_directory','video_dir','dir'],
     'raw': ['raw', 'raw_data'],
     'extract': ['extract', 'extract_fields', 'fields'],
     'download': ['download', 'download_video'],
     'audio': ['audio', 'extract_audio'],
     'whisper': ['whisper'],
     'captions': ['captions'],
     'metadata': ['metadata', 'meta_data', 'meta'],
     'thumbnails': ['thumbnails'],
     'seodata': ['seodata', 'seo_data', 'seo'],
     'metatags': ['metatags', 'meta_tags', 'tags'],
     'pagedata': ['pagedata', 'page_data', 'page']
     }
    if key:
        if pipeline_key_map.get(key):
            return key
        for pipe_key,pipe_values in pipeline_key_map.items():
            if key in pipe_values:
                return pipe_key
    return "all"
