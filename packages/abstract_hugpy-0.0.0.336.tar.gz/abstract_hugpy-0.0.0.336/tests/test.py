
from hugging_face_models import * #ModelManager

output = refine_with_gpt('hihihihi')
input(output)
output = get_summary('hihihihi')
input(output)
