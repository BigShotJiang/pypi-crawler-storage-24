# Project Description
Duple will find duplicates, enable the user to disposition duplicate groups, and then resolve the duplicate groups.

# Finding Duplicates
Duple will scan the directory or directories added to the list for duplicates.  It will determine duplicate files by evaluating the contents of the file and comparing to all other files.  The evaluation consists of ignoring files with unique file sizes (files can't be duplicates if no other file has the same size) then calculating the hash of the file contents.  Calculating the hash (sha256) of unique information guarantees (to a very high degree) results in a unique hash value.

Once the hashes have been calculated, the files can be grouped on their hash values, these groups are called duplicate groups and the files are identical to each other, regardless of file name or file location (path).

# Dispositioning Duplicate Groups
The user can disposition (meaning to determine which files to keep and which to delete) by applying filters or manually marking files.  There are two options for handling duplicate files: deletion or creating a shortcut.  Deletion means deleting the file(s), without sending to the trash bin or recycle bin (meaning the deletion is unrecoverable).  Creating a shortcut means replacing the duplicate file with a short cut (symlink) that points at the original (KEEP) file.

Disposition Codes:
-KEEP: the file will be kept, unchanged
-DELETE: the file will be deleted, this is not recoverable, the file does not go to the recycle bin or trash
-CREATE_LINK: the file will be replaced with a short cut or symlink that points to the original file
-DUPLICATE: no action, duple will ignore these files because this code means it has not been dispositioned yet

# Resolving Duplicates
Once the user has dispositioned at some of the duplicate groups, they can click the 'Resolve Dispositioned Duplicates' button.  Duple will then resolve each duplicate group by taking the action dictated by the disposition.

# Installation

Download the Latest Version:
| Windows| Linux | MacOS |
| :---: | :---: | :---: |
|[Windows](./releases/windows/0.2.0)|[Linux](./releases/linux/0.2.0)|[MacOS](./releases/macos/0.2.0)|
## Set the Target Directories to Scan
![Add Paths to Scan](./images/add_path.png)

## Scan Results
![Results](./images/results.png)
![Results with Filter](./images/results_filtered.png)

