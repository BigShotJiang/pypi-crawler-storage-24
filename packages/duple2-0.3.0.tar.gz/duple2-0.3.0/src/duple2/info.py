import os
import platform
import sysconfig
import tomllib
from pathlib import Path
from typing import Literal


def find(
    name: str,
    return_path_not_found: Path,
    return_parent: bool = True,
) -> Path:
    current: Path = Path(__file__).parent

    while current != current.parent:
        if current.joinpath(name).exists():
            if return_parent:
                return current
            return current.joinpath(name)

        current = current.parent

    return return_path_not_found


def get_os_platform() -> Literal["windows", "linux", "macos", "other"]:
    if "linux" in platform.system().lower():
        return "linux"

    if "windows" in platform.system().lower():
        return "windows"

    if "darwin" in platform.system().lower():
        return "macos"

    return "other"


def get_log_file_dir() -> Path:
    match get_os_platform():
        case "macos" | "linux":
            path = Path("~/.local/state/duple/logs/")
        case "windows":
            path = Path("~/AppData/Local/duple/logs/")
        case _:
            path = Path("~/.duple/logs/")

    return path.expanduser().resolve()


thispath = Path(__file__).parent

PROJECT_ROOT = find("pyproject.toml", return_parent=True, return_path_not_found=thispath)
PROJECT_TOML = find("pyproject.toml", return_parent=False, return_path_not_found=PROJECT_ROOT)
VERSION_PATH = find("__version__.py", return_parent=False, return_path_not_found=PROJECT_ROOT)
CONFIG_PATH = find("settings.toml", return_parent=False, return_path_not_found=PROJECT_ROOT)
APP_NAME_PATH = find("__app_name__.py", return_parent=False, return_path_not_found=PROJECT_ROOT)
LOGGING_CONFIGURATION_PATH = find(
    "logging_configuration.json",
    return_parent=False,
    return_path_not_found=PROJECT_ROOT,
)
# LOGS_PATH = find("logs", return_parent=False, return_path_not_found=PROJECT_ROOT)

LOGS_PATH = get_log_file_dir()
if not LOGS_PATH.exists():
    LOGS_PATH.mkdir(parents=True, exist_ok=True)

USER_SCRIPTS_PATH = sysconfig.get_path("scripts", f"{os.name}_user")

if PROJECT_ROOT is None:
    exit

assert PROJECT_TOML

if Path(PROJECT_TOML).exists():
    with PROJECT_TOML.open("rb") as toml_file:
        PYPROJECT = tomllib.load(toml_file)
