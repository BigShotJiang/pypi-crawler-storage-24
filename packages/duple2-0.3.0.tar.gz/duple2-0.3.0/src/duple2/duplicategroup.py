from dataclasses import dataclass, field
from typing import TypeAlias

from humanize import naturalsize

from duple2.app_types import Callback, Disposition, DispositionReason
from duple2.file import File, FileDict
from duple2.filters import AppliedFilters


@dataclass
class DuplicateGroup:
    id: int = field(init=False, default_factory=int)
    files: list[File] = field(init=True, default_factory=list)

    def get_files_by_dispositions(self) -> dict:
        result: dict[Disposition, list[File]] = dict()

        for file in self.files:
            if file.disposition not in result.keys():
                result[file.disposition] = list()

            result[file.disposition].append(file)

        return result

    @property
    def undispositioned(self) -> int:
        groups = self.get_files_by_dispositions()
        if Disposition.DUPLICATE in groups:
            return len(groups[Disposition.DUPLICATE])
        return 0

    @property
    def status(self) -> str:
        if self.undispositioned:
            return "bad"
        return "good"

    @property
    def get_original(self) -> File | None:
        if Disposition.KEEP in self.get_files_by_dispositions():
            return self.get_files_by_dispositions()[Disposition.KEEP][0]
        return None

    @property
    def count(self):
        return len(self.files)

    @property
    def total_size(self) -> int:
        total_size: int = 0
        for file in self.files:
            total_size += file.size
        return total_size

    @property
    def duplicate_size(self) -> int:
        return self.total_size - self.files[0].size

    def apply_filters(self, filters: AppliedFilters, duplicate_disposition: Disposition) -> FileDict:
        results: FileDict = {file.strpath: file for file in self.files}
        for _filter in filters.values():
            if _filter.filter_string:
                results = _filter.func.from_file_dict(
                    file_dict=results, filter_string=_filter.filter_string
                ).output_dict()
            else:
                results = _filter.func.from_file_dict(file_dict=results).output_dict()

        count_of_results = len(results)

        if not results or not filters:
            for file in self.files:
                if file.disposition_reason is DispositionReason.USER_OVERRIDE:
                    continue

                file.disposition = Disposition.DUPLICATE
                file.disposition_reason = DispositionReason.NOT_SET
            return {file.strpath: file for file in self.files}

        for file in self.files:
            if file.disposition_reason is DispositionReason.USER_OVERRIDE:
                continue

            if file not in results.values():
                file.disposition = duplicate_disposition
                file.disposition_reason = DispositionReason.FAILED_FILTER
                continue

            match count_of_results:
                case 1:
                    file.disposition = Disposition.KEEP
                    file.disposition_reason = DispositionReason.PASSED_FILTER
                case _:
                    file.disposition = Disposition.DUPLICATE
                    file.disposition_reason = DispositionReason.TOO_MANY_FILTER_RESULTS

        return {file.strpath: file for file in self.files}

    def resolve(self, callback: Callback = None) -> None:
        # if Disposition.KEEP not in self.get_files_by_dispositions():
        # return "Not Successful: No file is set to KEEP in the group"

        if self.undispositioned:
            return

        if not self.get_original:
            return

        length = len(self.files)
        for i, file in enumerate(self.files):
            match file.disposition:
                case Disposition.KEEP:
                    pass
                case Disposition.DELETE:
                    file.path.unlink()
                case Disposition.CREATE_LINK:
                    file.path.unlink()
                    file.path.symlink_to(self.get_original.path)

            if callback:
                callback(i, length, "resolving files")

        if callback:
            callback(length, length, "finished resolving files")

    def treeview_values(self) -> tuple[int, int, str, int]:
        return (
            self.count,
            self.total_size,
            naturalsize(self.total_size),
            self.undispositioned,
        )


DuplicateGroups: TypeAlias = dict[int, DuplicateGroup]
