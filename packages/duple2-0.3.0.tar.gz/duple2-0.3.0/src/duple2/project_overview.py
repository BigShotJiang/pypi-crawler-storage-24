from pathlib import Path
from tkinter.ttk import Frame
from typing import Callable, Protocol

from gui_library.StatusBar import StatusBar

from duple2.duplicategroup import DuplicateGroups
from duple2.file import FileDict


class DupleModel(Protocol):
    file_dict: FileDict
    scanpaths: list[Path]
    duplelicate_group: DuplicateGroups


class DupleView(Protocol):
    scan: Frame
    analysis: Frame
    status_bar: StatusBar


class DupleController(Protocol):
    model: DupleModel
    viewer: DupleView
    callback: Callable

    # def __post_init__(self):
    #     self.callback = self.viewer.status_bar.update_progress

    def load_viewer(self) -> None: ...
    def scan(self) -> None: ...
    def preprocess(self) -> None: ...
    def find_duplicate_groups(self) -> None: ...

    # The following methods will be bound to the appropriate DupleView object
    def user_selected_filter(self) -> None: ...
    def user_selected_group(self) -> None: ...
    def user_unselected_filter(self) -> None: ...
    def user_clicked_add_path(self) -> None: ...
    def user_clicked_scan(self) -> None: ...
    def user_clicked_execute(self) -> None: ...
    def user_changed_default_disposition(self) -> None: ...
    def user_dispositioned_duplicate(self) -> None: ...  # return object, tkinter.event
