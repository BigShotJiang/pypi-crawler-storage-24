from enum import Enum, auto
from typing import Callable, TypeAlias

Callback: TypeAlias = Callable[[int, int, str], None] | None


class Disposition(Enum):
    IGNORE = auto()
    ORIGINAL = auto()
    DUPLICATE = auto()
    KEEP = auto()
    DELETE = auto()
    CREATE_LINK = auto()  # create symlink or shortcut from duplicate to the original
    NOT_ANALYZED = auto()

    @property
    def longest_name(self):
        statuses = [value.name for value in Disposition]

        result = max([len(str(value)) for value in statuses])
        return result


class DispositionReason(Enum):
    USER_OVERRIDE = auto()
    UNIQUE_FILE_SIZE = auto()
    UNIQUE_HASH = auto()
    PERMISSION_DENIED = auto()
    DOES_NOT_EXISTS = auto()
    NOT_SET = auto()
    SYMLINK = auto()
    FAILED_FILTER = auto()
    PASSED_FILTER = auto()
    TOO_MANY_FILTER_RESULTS = auto()

    @property
    def longest_name(self):
        codes = [value.name for value in DispositionReason]

        result = max([len(str(value)) for value in codes])
        return result
