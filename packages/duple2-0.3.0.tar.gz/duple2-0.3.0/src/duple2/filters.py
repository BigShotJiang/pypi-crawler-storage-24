import re
from collections.abc import Iterable
from copy import deepcopy
from dataclasses import dataclass, field
from functools import wraps
from typing import Any, Callable
from uuid import uuid4

import polars

from duple2.file import FileDict, FileList


@dataclass
class FileFilter:
    regex_compiled: re.Pattern = field(init=False)
    attr: str = field(init=False, default_factory=str, repr=True)
    operator: Callable = field(init=False, default=min, repr=True)
    _file_list: FileList = field(init=True, repr=False, default_factory=list)
    _file_dict: FileDict = field(init=False, repr=False, default_factory=dict)
    _keys: list[Any] = field(init=False, repr=False, default_factory=list)
    filter_string: str = field(init=False, repr=True, default_factory=str)

    def __post_init__(self):
        # class needs a post init to let the initialization finish for the super class and subclass
        pass

    @classmethod
    def from_file_dict(cls, file_dict: FileDict, filter_string: str = str()):
        ffilter = cls(_file_list=list(file_dict.values()))
        ffilter._file_dict = file_dict
        ffilter.filter_string = filter_string
        ffilter.regex_compiled = re.compile(pattern=str(filter_string), flags=re.IGNORECASE)
        return ffilter

    @classmethod
    def from_file_list(cls, file_list: FileList, filter_string: str = str()):
        ffilter = cls(_file_list=file_list)
        ffilter._file_dict = {file.strpath: file for file in file_list}
        ffilter.filter_string = filter_string
        ffilter.regex_compiled = re.compile(pattern=str(filter_string), flags=re.IGNORECASE)
        return ffilter

    def set_attrs(self, attr: str, operator: Callable, include: bool = True):
        self.attr = attr
        self.operator = operator
        self.include = include

    def process(self):
        if not self._file_dict:
            self._keys = []
            return

        def regex_check(in_string: str, included: bool) -> bool:
            match_result = self.regex_compiled.search(in_string)

            if included:
                return bool(match_result)
            return not bool(match_result)

        if self.filter_string:
            target = self.operator(
                [
                    getattr(file, self.attr)
                    for file in self._file_dict.values()
                    if regex_check(getattr(file, self.attr), self.include)
                ]
            )
        else:
            target = self.operator([getattr(file, self.attr) for file in self._file_dict.values()])

        targets: list = list()
        if isinstance(target, Iterable):
            targets.extend(target)
        else:
            targets.append(target)

        targets_set = set(targets)

        self._keys = [key for key, file in self._file_dict.items() if getattr(file, self.attr) in targets_set]

    def output_dict(self) -> FileDict:
        self.process()
        if self._keys:
            return dict(filter(lambda item: item[0] in self._keys, self._file_dict.items()))
        return dict()

    def output(self) -> FileList:
        return list(self.output_dict().values())


@dataclass
class RegistryEntry:
    iid: str = field(init=True, repr=True)
    name: str = field(init=True, repr=True)
    description: str = field(init=True, repr=True)
    has_args: bool = field(init=True, repr=True)
    func: FileFilter = field(init=True, repr=True)
    filter_string: str = field(init=False, repr=True, default_factory=str)

    @property
    def all_fields(self) -> dict[str, Any]:
        return self.__dict__

    @property
    def to_tuple(self):
        return (self.iid, self.name, self.description)

    @classmethod
    def columns(cls) -> list[str]:
        return ["iid", "Name", "Description"]


FILTER_REGISTRY: dict[str, RegistryEntry] = dict()


@dataclass
class AppliedFilters(dict[str, RegistryEntry]):
    def to_dataframe(self) -> polars.DataFrame:
        data: list = list()
        for key, value in self.items():
            data.append(
                {
                    "iid": key,
                    "Name": value.name,
                    # "Description": value.description,
                    "Search String": value.filter_string,
                }
            )

        return polars.DataFrame(data)

    def add(self, regentry: RegistryEntry) -> str:
        key = uuid4().hex
        self[key] = deepcopy(regentry)
        return key


def register_filter(func):
    has_args: bool = False
    if "Include" in func.__qualname__ or "Exclude" in func.__qualname__:
        has_args = True

    registry_entry = RegistryEntry(
        iid=uuid4().hex,
        name=func.__qualname__,
        description=func.__doc__.replace("\n", ""),
        has_args=has_args,
        func=func,
    )

    FILTER_REGISTRY[registry_entry.iid] = registry_entry

    @wraps(func)
    def wrapper(*args, **kwargs):
        result = func(*args, **kwargs)
        return result

    return func


def registry_to_dataframe() -> polars.DataFrame:
    values = [value.to_tuple for value in FILTER_REGISTRY.values()]
    columns = RegistryEntry.columns()
    return polars.DataFrame(values, schema=columns, orient="row")


@register_filter
class PathDepthMax(FileFilter):
    """
    Deepest pathways
    """

    def __post_init__(self):
        super().set_attrs("depth", max)


@register_filter
class PathDepthMin(FileFilter):
    """
    Shallowest pathways
    """

    def __post_init__(self):
        super().set_attrs("depth", min)


@register_filter
class NameLengthMax(FileFilter):
    """
    Longest file names
    """

    def __post_init__(self):
        super().set_attrs("namelength", max)


@register_filter
class NameLengthMin(FileFilter):
    """
    Shortest file names
    """

    def __post_init__(self):
        super().set_attrs("namelength", min)


@register_filter
class CreatedEarliest(FileFilter):
    """
    Oldest created files
    """

    def __post_init__(self):
        super().set_attrs("ctime", min)


@register_filter
class CreatedLatest(FileFilter):
    """
    Newest created files
    """

    def __post_init__(self):
        super().set_attrs("ctime", max)


@register_filter
class ModifiedEarliest(FileFilter):
    """
    Oldest modified files
    """

    def __post_init__(self):
        super().set_attrs("mtime", min)


@register_filter
class ModifiedLatest(FileFilter):
    """
    Newest modified files
    """

    def __post_init__(self):
        super().set_attrs("mtime", max)


@register_filter
class PathInclude(FileFilter):
    """
    Paths includes string (regex)
    """

    def __post_init__(self):
        super().set_attrs(attr="strpath", operator=list)


@register_filter
class PathExclude(FileFilter):
    """
    Paths excludes string (!regex)
    """

    def __post_init__(self):
        super().set_attrs(attr="strpath", operator=list, include=False)


@register_filter
class NameInclude(FileFilter):
    """
    Name includes string (regex)
    """

    def __post_init__(self):
        super().set_attrs(attr="strpath", operator=list)


@register_filter
class NameExclude(FileFilter):
    """
    Name excludes string (!regex)
    """

    def __post_init__(self):
        super().set_attrs(attr="strpath", operator=list, include=False)
