from collections import Counter
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from itertools import repeat
from pathlib import Path
from time import perf_counter
from types import NoneType
from typing import Literal

import polars
from gui_library.StatusBar import StatusBar
from humanize import naturalsize

from duple2.app_types import Callback, Disposition
from duple2.duplicategroup import DuplicateGroup, DuplicateGroups
from duple2.file import File, FileDict
from duple2.filters import AppliedFilters


@dataclass
class DupleModel:
    file_dict: dict[str, File] = field(init=False, default_factory=dict, repr=False)
    duplicate_groups: DuplicateGroups = field(init=False, default_factory=dict, repr=False)
    paths: set[Path] = field(init=False, default_factory=set, repr=False)
    times: dict[str, float] = field(init=False, default_factory=dict, repr=False)
    status_bar: StatusBar | None = field(init=False, default_factory=NoneType, repr=False)
    _unique_file_sizes: set = field(init=False, default_factory=set, repr=False)
    applied_filters: AppliedFilters = field(init=False, default_factory=AppliedFilters, repr=False)
    duplicate_disposition: Disposition = field(init=True, default=Disposition.DELETE)
    duplicate_group_filter: set = field(init=True, default_factory=set, repr=False)

    def reset(self):
        self.file_dict = dict()
        self.times = dict()
        self.duplicate_groups = dict()
        self.applied_filters = AppliedFilters()

    @property
    def file_count(self):
        return len(self.file_dict)

    @property
    def total_size(self):
        return sum([file.size for file in self.file_dict.values()])

    @property
    def total_duplicate_size(self):
        return sum([dgroup.total_size for dgroup in self.duplicate_groups.values()])

    @property
    def total_duplicate_size_reduction(self):
        return sum([dgroup.duplicate_size for dgroup in self.duplicate_groups.values()])

    def get_file_dict_disposition(self, disposition: Disposition) -> FileDict:
        return {key: file for key, file in self.file_dict.items() if file.disposition == disposition}

    def report_resolution_stats(self) -> None:
        stats: dict = dict()

        deleted = self.get_file_dict_disposition(Disposition.DELETE)
        shortcut = self.get_file_dict_disposition(Disposition.CREATE_LINK)

        deleted_sizes = [file.size for file in deleted.values()]
        shortcut_sizes = [file.size for file in shortcut.values()]

        total_sizes = sum(deleted_sizes) + sum(shortcut_sizes)

        stats["saved space"] = naturalsize(total_sizes)
        stats["deleted files"] = len(deleted) + len(shortcut)
        stats["shortcuts"] = len(shortcut)

        if self.status_bar:
            self.status_bar.clear_progress()
            self.status_bar.update_status(repr(stats).replace("{", "").replace("}", "").replace("'", ""), side="right")

    @property
    def unique_file_sizes(self):
        if not self._unique_file_sizes:
            sizes = [file.size for file in self.file_dict.values()]
            self._unique_file_sizes = {key for key, value in Counter(sizes).items() if value == 1}

        return self._unique_file_sizes

    def _apply_filters_helper(
        self,
        duplicate_group: DuplicateGroup,
        filters: AppliedFilters,
        duplicate_disposition: Disposition,
    ) -> FileDict:
        return duplicate_group.apply_filters(filters, duplicate_disposition)

    def apply_filters(
        self,
        callback: Callback = None,
    ) -> None:
        denominator = len(self.duplicate_groups)

        with ThreadPoolExecutor() as executor:
            results = executor.map(
                self._apply_filters_helper,
                self.duplicate_groups.values(),
                repeat(self.applied_filters),
                repeat(self.duplicate_disposition),
            )

            for i, result in enumerate(results):
                for file in result.values():
                    self.file_dict[file.id] = file
                # if callback:
                # callback(i, denominator, "Processing Duplicate Groups")

        if callback:
            callback(denominator, denominator, "Finished Applying Filters")

    def paths_to_dataframe(self):
        return polars.DataFrame({"iid": list(self.paths), "path": list(self.paths)})

    def duplicate_groups_to_dataframe(self, callback: Callback = None):
        data: list = list()
        dgroup: DuplicateGroup
        length = len(self.duplicate_groups)
        for i, dgroup in self.duplicate_groups.items():
            row = {
                "iid": i,
                "ID": i,
                "Count": dgroup.count,
                "Total Size (Bytes)": dgroup.total_size,
                # "Duplicate Size (Bytes)": dgroup.duplicate_size,
                "Total Size": naturalsize(dgroup.total_size),
                # "Duplicate Size": naturalsize(dgroup.duplicate_size),
                "Undispositioned": dgroup.undispositioned,
                "tag": dgroup.status,
            }

            data.append(row)

            if callback:
                callback(i, length, "creating duplicate group dataframe")

        if callback:
            callback(length, length, "finished creating duplicate group dataframe")

        if len(data) == 0:
            data.append(
                {
                    "iid": 0,
                    "ID": "No Duplicates",
                    "Count": 0,
                    "Total Size": 0,
                    "Duplicate Size": 0,
                }
            )

        return polars.DataFrame(data)

    def calculate_summary_statistics(self) -> polars.DataFrame:
        data: list = list()

        data.append({"Statistic": "Total Files", "Value": f"{self.file_count}"})
        data.append(
            {"Statistic": "Ignored Files", "Value": f"{len(self.get_file_dict_disposition(Disposition.IGNORE))}"}
        )
        data.append(
            {"Statistic": "Duplicate Files", "Value": f"{len(self.get_file_dict_disposition(Disposition.DUPLICATE))}"}
        )
        data.append({"Statistic": "Duplicate Groups", "Value": f"{len(self.duplicate_groups)}"})
        data.append({"Statistic": "Total Size", "Value": f"{naturalsize(self.total_size)}"})
        data.append(
            {"Statistic": "Total Size of Duplicates", "Value": f"{naturalsize(self.total_duplicate_size_reduction)}"}
        )

        for key, value in self.times.items():
            data.append({"Statistic": f"{key.replace('_', ' ').title()} Time (seconds)", "Value": f"{value:0.4f}"})

        max_len = max([len(str(statistic["Value"])) for statistic in data])

        for statistic in data:
            statistic["Value"] = str(statistic["Value"]).rjust(max_len + 5)

        return polars.DataFrame(data)

    def get_file_dict(self) -> FileDict:
        if not self.duplicate_group_filter:
            return {key: file for key, file in self.file_dict.items() if file.duplicate_group != 0}

        return {
            key: file for key, file in self.file_dict.items() if file.duplicate_group in self.duplicate_group_filter
        }

    def file_dict_to_dataframe(
        self,
        callback: Callback = None,
    ) -> polars.DataFrame:
        data: list = list()
        # file_dict = self.get_file_dict()
        # file_dict_only_duplicates: dict = {key: file for key, file in file_dict.items() if file.duplicate_group != 0}
        file_dict_only_duplicates = self.get_file_dict()

        length = len(file_dict_only_duplicates)
        for i, (key, file) in enumerate(file_dict_only_duplicates.items()):
            row = {
                "iid": key,
                "ID": i + 1,
                "Duplicate Group": file.duplicate_group,
                "Disposition": file.disposition.name,
                "Reason": file.disposition_reason.name,
                "Size (Bytes)": naturalsize(file.size),
                "Size": file.size,
                "Path": str(file.path.resolve()),
                "tag": file.disposition.name,
            }

            if callback:
                callback(i, length, "creating dataframe")

            data.append(row)

        if callback:
            callback(length, length, "finished creating datframe")

        if len(data) == 0:
            data.append(
                {
                    "iid": 0,
                    "ID": "No Duplicates",
                    "Duplicate Group": 0,
                    "Disposition": None,
                    "Reason": None,
                    "Size (Bytes)": 0,
                    "Size": naturalsize(0),
                    "Path": None,
                }
            )

        df = polars.DataFrame(data).sort("Size (Bytes)", descending=True)
        return df

    def generate_ids_for_file_dict(self, path_or_count: Literal["path", "count"]) -> None:
        result: FileDict = dict()

        if path_or_count == "path":
            for file in self.file_dict.values():
                file.id = file.strpath
                result[file.strpath] = file

        if path_or_count == "count":
            for i, file in enumerate(self.file_dict.values()):
                file.id = str(i + 1)
                result[file.id] = file

        self.file_dict = result

    def tick(self, key: str, update_status_bar: bool = True) -> None:
        self.times[key] = perf_counter()
        if self.status_bar and update_status_bar:
            self.status_bar.start_task()

    def tock(self, key: str, update_status_bar: bool = True) -> None:
        self.times[key] = perf_counter() - self.times[key]
        if self.status_bar and update_status_bar:
            self.status_bar.finish_task(key)
