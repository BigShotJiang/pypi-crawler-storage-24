import cProfile
import tkinter
from pathlib import Path
from threading import Thread
from tkinter import Event, Radiobutton, StringVar, simpledialog
from tkinter.filedialog import askdirectory
from tkinter.ttk import Button, Frame, Label, Notebook, PanedWindow, Panedwindow, Style
from typing import Callable

import polars
from gui_library.DataFrameViewer import DataFrameViewer, show_dataframeviewer
from gui_library.StatusBar import StatusBar

from duple2.app_types import Disposition, DispositionReason
from duple2.duplemodel import DupleModel
from duple2.filters import FILTER_REGISTRY, AppliedFilters, registry_to_dataframe
from duple2.info import PROJECT_ROOT
from duple2.library import (
    calculate_hash,
    calculate_summary_statistics,
    duplicate_groups_to_dataframe,
    file_dict_to_dataframe,
    find_duplicate_groups,
    preprocess,
    scan,
)


class Console(tkinter.Tk):
    def __init__(self):
        super().__init__()
        self.title("Duple2 - Find and Resolve Duplicate Files")

        style = Style()
        style.configure("Treeview", font=("Courier New", 10))
        style.configure("TNotebook", padding=0)

        self.status_bar: StatusBar = StatusBar(self)
        self.model: DupleModel = DupleModel()
        self.model.status_bar = self.status_bar
        self.monitor_frequency = 1 / 1  # 1 / self.settings.gui.monitor_frequency
        self.threads: list = list()

        self.make_menu()
        self.make_widgets()
        self.show_scan_frame()
        self.make_bindings()

        targets = [
            # self.update_idletasks,
        ]

        for target in targets:
            self.kick_thread(target)

    def kick_thread(self, target: Callable, args: tuple | None = None) -> None:
        if args:
            t = Thread(target=target, args=(args,), daemon=True)
        else:
            t = Thread(target=target, daemon=True)

        t.start()
        self.threads.append(t)

    # def change_monitor(self):
    #     try:
    #         while self.winfo_exists():
    #             sleep(self.monitor_frequency)
    #
    #             # self.monitor_dirties()
    #             # self.monitor_validations()
    #     except tkinter.TclError as e:
    #         print(e)
    #     finally:
    #         pass

    def make_widgets(self):
        self.status_bar = StatusBar(self)

        self.scanframe = ScanFrame(self)
        self.resultframe = ResultsFrame(self)

        self.status_bar.grid(row=1, column=0, rowspan=1, columnspan=1, sticky="nsew", padx=5, pady=2)

        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)

    def show_scan_frame(self):
        self.scanframe.grid(row=0, column=0, rowspan=1, columnspan=1, sticky="nsew", padx=5, pady=2)
        self.resultframe.grid_forget()

    def show_result_frame(self):
        self.resultframe.report.update_summary_report()
        self.resultframe.report.update_duplicate_report()
        self.resultframe.update_duplicate_manager()
        self.resultframe.grid(row=0, column=0, rowspan=1, columnspan=1, sticky="nsew", padx=5, pady=2)
        self.scanframe.grid_forget()

    def make_menu(self):
        pass

    def make_bindings(self):
        self.bind("<<StatusBar.DoubleClick.Left>>", self.show_status_log)
        self.bind("<<StatusBar.DoubleClick.Right>>", self.show_status_log)

    def show_about(self):
        pass

    def show_settings(self):
        pass

    def show_status_log(self, event: Event):
        df = polars.DataFrame(self.status_bar.status_log)
        show_dataframeviewer(title="Log", df=df)

    def load_results(self):
        self.model = preprocess(model=self.model, callback=self.status_bar.update_progress)
        self.status_bar.clear_progress()

        self.model = calculate_hash(model=self.model, callback=self.status_bar.update_progress)
        self.status_bar.clear_progress()

        self.model = find_duplicate_groups(model=self.model, callback=self.status_bar.update_progress)
        self.status_bar.clear_progress()

        self.model.tock("Overall Processing Time")
        overall = self.model.times.pop("Overall Processing Time")
        self.model.times["Overall Processing Time"] = overall

        self.show_result_frame()


class ScanFrame(Frame):
    def __init__(self, console: Console):
        super().__init__(console)

        self.console: Console = console
        self.callback = self.console.status_bar.update_progress
        self.model = console.model

        self.make_widgets()

    def make_widgets(self):
        self.selectpath: Button = Button(self, text="Add Path to Scan", command=self.askpath)
        self.paths_to_scan: DataFrameViewer = DataFrameViewer(self)
        self.scan: Button = Button(self, text="Scan", command=self.scan_directories)

        self.selectpath.grid(row=0, column=0, rowspan=1, columnspan=1, sticky="nsew", padx=5, pady=2)
        self.paths_to_scan.grid(row=1, column=0, rowspan=1, columnspan=1, sticky="nsew", padx=5, pady=2)
        self.scan.grid(row=2, column=0, rowspan=1, columnspan=1, sticky="nsew", padx=5, pady=2)

        self.rowconfigure(0, weight=0)
        self.rowconfigure(1, weight=1)
        self.rowconfigure(2, weight=0)
        self.columnconfigure(0, weight=1)

    def askpath(self) -> None:
        path = Path(
            askdirectory(
                initialdir=str(Path("~").expanduser().absolute()),
                mustexist=True,
                title="Choose Path to Scan",
            )
        )

        if path != Path("."):
            self.model.paths.append(path)

        self.update_paths_list()

    def scan_directories(self) -> None:
        self.console.status_bar.start_task()

        self.model.tick("Overall Processing Time")
        self.model = scan(
            model=self.model,
            callback=self.callback(
                numerator=len(self.model.paths), denominator=len(self.model.paths), message="scanning paths..."
            ),
        )

        self.console.status_bar.clear_progress()
        self.console.load_results()

    def update_paths_list(self) -> None:
        self.paths_to_scan.update_data(df=polars.DataFrame({"paths": self.model.paths}))


class ResultsFrame(Frame):
    def __init__(self, console: Console):
        super().__init__(console)

        self.console = console
        self.model = self.console.model

        self.make_widgets()

    def make_widgets(self):
        self.pwV: Panedwindow = Panedwindow(master=self, orient=tkinter.VERTICAL)
        self.pwV.grid(row=0, column=0, rowspan=1, columnspan=1, sticky="nsew", padx=5, pady=2)

        self.pwH: PanedWindow = PanedWindow(master=self.pwV, orient=tkinter.HORIZONTAL)
        self.pwH.grid(row=0, column=0, rowspan=1, columnspan=1, sticky="nsew", padx=5, pady=2)

        self.duplicates: DuplicatesManager = DuplicatesManager(
            parent=self.pwV,
            model=self.model,
            results_frame=self,
        )
        self.available_filters: RulesManager = RulesManager(
            parent=self.pwH,
            model=self.model,
            result_frame=self,
        )
        self.report: ResultsReport = ResultsReport(
            parent=self.pwH,
            model=self.model,
            result_frame=self,
        )

        self.pwV.add(self.pwH)
        self.pwH.add(self.report)
        self.pwH.add(self.available_filters)
        self.pwV.add(self.duplicates)

        self.execute_button: Button = Button(master=self, text="Execute", command=self.execute)
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)

    def update_duplicate_manager(self):
        self.duplicates.update_data()

    def update_duplicate_report(self):
        self.report.update_duplicate_report()

    def update_duplicate_filter(self, selection: tuple):
        self.duplicates.filter_duplicate_group(selection)

    def execute(self):
        pass


class DuplicatesManager(Frame):
    def __init__(
        self,
        parent: Panedwindow,
        model: DupleModel,
        results_frame: ResultsFrame,
    ):
        super().__init__(parent)

        self.parent = parent
        self.model = model
        self.duplicate_groups = None
        self.results_frame = results_frame

        self.df = file_dict_to_dataframe(file_dict=self.model.file_dict)

        self.make_widgets()
        self.make_bindings()

    def make_widgets(self):
        self.label_duplicates: Label = Label(self, text="Duplicates")
        self.label_instructions: Label = Label(
            self, text="Keyboard Shortcuts: 'c' = SHORTCUT; 'd' = DELETE, 'k' = KEEP; r = DUPLICATE"
        )

        self.label_duplicates.grid(row=0, column=0, rowspan=1, columnspan=1, sticky="nsw", padx=5, pady=2)
        self.label_instructions.grid(row=0, column=1, rowspan=1, columnspan=1, sticky="nse", padx=5, pady=2)

        self.duplicates: DataFrameViewer = DataFrameViewer(self)

        self.duplicates.update_data(df=self.df)
        self.duplicates.grid(row=1, column=0, rowspan=1, columnspan=2, sticky="nsew", padx=5, pady=2)

        self.rowconfigure(0, weight=0)
        self.rowconfigure(1, weight=1)
        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, weight=1)

    def update_data(self, selection: tuple[str] | None = None, update_duplicate_report: bool = True):
        self.df = file_dict_to_dataframe(file_dict=self.model.file_dict)
        if update_duplicate_report:
            self.results_frame.update_duplicate_report()

        if self.duplicate_groups:
            self.df = self.df.filter(polars.col("Duplicate Group").is_in(self.duplicate_groups))
            self.duplicates.update_data(df=self.df)

        if selection is None:
            self.duplicates.update_data(df=self.df)
            return

        for id in selection:
            selected = self.df.filter(polars.col("ID") == id)
            tag = selected["tag"][0]
            values = selected.drop(["iid", "ID", "tag"]).row()

            self.duplicates.treeview.item(id, values=values, tags=tag)

    def make_bindings(self) -> None:
        self.duplicates.treeview.bind("<KeyRelease>", self.keyrelease)
        self.duplicates.treeview.tag_configure(Disposition.DELETE.name, background="indian red", foreground="Black")
        self.duplicates.treeview.tag_configure(Disposition.KEEP.name, background="PaleGreen2", foreground="Black")
        self.duplicates.treeview.tag_configure(
            Disposition.CREATE_LINK.name, background="SteelBlue1", foreground="Black"
        )

        # self.duplicates.treeview.tag_configure(Disposition.DUPLICATE.name, background="White", foreground="Black")

    def filter_duplicate_group(self, duplicate_groups: tuple) -> None:
        self.duplicate_groups = [int(item) for item in duplicate_groups]
        self.update_data(update_duplicate_report=False)

    def keyrelease(self, event: Event):
        if event.keysym == "c":
            self.user_mark(self.duplicates.selection(), Disposition.CREATE_LINK)
        if event.keysym == "d":
            self.user_mark(self.duplicates.selection(), Disposition.DELETE)
        if event.keysym == "k":
            self.user_mark(self.duplicates.selection(), Disposition.KEEP)
        if event.keysym == "r":
            self.user_mark(self.duplicates.selection(), Disposition.DUPLICATE)

    def user_mark(self, ids: tuple, disposition: Disposition):
        disposition_reason = DispositionReason.USER_OVERRIDE
        if disposition == Disposition.DUPLICATE:
            disposition_reason = DispositionReason.NOT_SET

        for id in ids:
            self.model.file_dict[id].disposition = disposition
            self.model.file_dict[id].disposition_reason = disposition_reason
        self.update_data(selection=ids)


# TODO: add method for clearing selections in the list box to eliminate the filtering, for the user
class ResultsReport(Frame):
    def __init__(
        self,
        parent: Panedwindow,
        model: DupleModel,
        result_frame: ResultsFrame,
    ):
        super().__init__(parent)

        self.parent = parent
        self.model = model
        self.result_frame = result_frame

        self.make_widgets()

    def make_widgets(self):
        self.notebook: Notebook = Notebook(self)
        self.notebook.grid(row=0, column=0, rowspan=1, columnspan=1, sticky="nsew", padx=0, pady=0)

        self.duplicate_report: DataFrameViewer = DataFrameViewer(self)
        self.duplicate_report.treeview.bind("<<TreeviewSelect>>", self.treeview_select)
        self.duplicate_report.treeview.tag_configure("bad", background="indian red", foreground="Black")
        self.duplicate_report.treeview.tag_configure("good", background="PaleGreen2", foreground="Black")
        # self.update_duplicate_report()

        # TODO: This is not working, the summary report is blank
        self.summary_report: DataFrameViewer = DataFrameViewer(self)

        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)

        self.notebook.add(self.duplicate_report, text="Duplicate Groups")
        self.notebook.add(self.summary_report, text="Summary Report")

    def treeview_select(self, event: Event):
        self.result_frame.update_duplicate_filter(self.duplicate_report.selection())

    def update_duplicate_report(self):
        self.duplicate_report.update_data(df=duplicate_groups_to_dataframe(self.model.duplicate_groups))

    def update_summary_report(self):
        self.summary_report.update_data(df=calculate_summary_statistics(self.model))


class RulesManager(Frame):
    def __init__(
        self,
        parent: Panedwindow,
        model: DupleModel,
        result_frame: ResultsFrame,
    ):
        super().__init__(parent)

        self.parent = parent
        self.model = model
        self.applied_filters: AppliedFilters = AppliedFilters()
        self.result_frame = result_frame
        self.callback = self.result_frame.console.status_bar.update_progress
        self.callback = None

        self.make_widgets()
        self.make_bindings()

    def make_widgets(self):
        self.pw = PanedWindow(master=self, orient="horizontal")
        self.pw.grid(row=1, column=0, rowspan=1, columnspan=3, sticky="nsew", padx=5, pady=2)

        self.label_rules: Label = Label(self, text="Filters to Determine the Original File")
        self.label_directions: Label = Label(
            self,
            text="Double click 'Available Filter' to add to the 'Applied Filter' list, double click 'Applied Filter' to remove",
        )

        self.label_rules.grid(row=0, column=0, rowspan=1, columnspan=1, sticky="nsw", padx=5, pady=2)
        self.label_directions.grid(row=0, column=1, rowspan=1, columnspan=2, sticky="nse", padx=5, pady=2)

        self.available_filters: DataFrameViewer = DataFrameViewer(self)
        self.available_filters.update_data(df=registry_to_dataframe())

        self.applied_filters_viewer_frame: Frame = Frame(self)
        self.applied_filters_viewer_frame.rowconfigure(0, weight=1)
        self.applied_filters_viewer_frame.rowconfigure(0, weight=2)
        self.applied_filters_viewer_frame.columnconfigure(0, weight=1)

        self.applied_filters_viewer: DataFrameViewer = DataFrameViewer(self.applied_filters_viewer_frame)
        self.applied_filters_viewer.grid(row=0, column=0, padx=5, pady=5, sticky="nsew")

        self.radio_button_frame = self.make_radio_button_frame(self.applied_filters_viewer_frame)
        self.radio_button_frame.grid(row=1, column=0, rowspan=1, columnspan=1, sticky="nsew", padx=5, pady=2)

        self.pw.add(self.available_filters)
        self.pw.add(self.applied_filters_viewer_frame)

        # # TODO: As rules are selected or delselcted update statistics in another datframe
        # # TODO: need way to give input to the include/exclude filters that need a string
        # # TODO: resume working here
        #
        # self.pw.add(self.applied_filters_viewer)
        # self.pw.add(self.available_filters)

        self.rowconfigure(0, weight=0)
        self.rowconfigure(1, weight=1)
        # self.rowconfigure(2, weight=1)
        self.columnconfigure(0, weight=2)
        self.columnconfigure(1, weight=1)
        self.columnconfigure(2, weight=1)

    def make_radio_button_frame(self, master: Frame):
        radio_button_options: list = ["Delete", "Shortcut"]
        frame: Frame = Frame(master)
        self.radio_button_label: Label = Label(
            frame,
            text="How to disposition DUPLICATE files:",
        )
        self.radio_button_label.grid(
            row=0, column=0, sticky="nsew", padx=5, pady=2, rowspan=1, columnspan=len(radio_button_options)
        )
        self.radio_button_list: list = list()
        self.radio_value = StringVar(self, value=radio_button_options[0])
        for i, button in enumerate(radio_button_options):
            rb = Radiobutton(
                frame,
                text=button,
                variable=self.radio_value,
                value=button,
                command=self.update_statistics,
            )
            rb.grid(row=0, column=i + 2, sticky="nsw", padx=5, pady=0)
            frame.columnconfigure(i + 2, weight=0)
            self.radio_button_list.append(rb)

        # Frame(self.radio_button_frame).grid(row=0, column=len(radio_button_options) + 1, sticky="nsew")

        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        frame.columnconfigure(len(radio_button_options) + 2, weight=2)

        return frame

    def make_bindings(self) -> None:
        self.available_filters.treeview.bind("<Double-Button-1>", self.apply_filter)
        self.applied_filters_viewer.treeview.bind("<Double-Button-1>", self.unapply_filter)

    def apply_filter(self, event: Event | None = None) -> None:
        self.result_frame.console.status_bar.start_task()
        selected_rule = FILTER_REGISTRY[self.available_filters.selection()[0]]

        filter_string = str()
        if selected_rule.has_args:
            filter_string = simpledialog.askstring(
                title=f"What is the Seach String for {selected_rule.name}", prompt="What is the search string:"
            )

        key = self.applied_filters.add(selected_rule)
        self.applied_filters[key].filter_string = str(filter_string)
        self.update_statistics()
        self.result_frame.console.status_bar.finish_task("Applied Filters")

    def unapply_filter(self, event: Event) -> None:
        if not self.applied_filters_viewer.selection():
            return

        selected_rule = self.applied_filters_viewer.selection()[0]

        self.applied_filters.pop(selected_rule)

        self.update_statistics()

    def get_selected_filters(self):
        return self.applied_filters

    def get_disposition_option(self) -> Disposition:
        match self.radio_value.get():
            case "Delete":
                return Disposition.DELETE
            case "Shortcut":
                return Disposition.CREATE_LINK
            case _:
                return Disposition.DUPLICATE

    def update_statistics(self):
        self.applied_filters_viewer.update_data(df=self.applied_filters.to_dataframe())
        self.model.apply_filters(
            self.applied_filters,
            self.get_disposition_option(),
            callback=self.callback,
        )
        self.result_frame.update_duplicate_manager()


def load_gui():
    # setup_logging()
    app = Console()
    app.mainloop()


def load_gui_w_tracer():
    with cProfile.Profile() as tracer:
        app = Console()
        app.mainloop()

        tracer.dump_stats(PROJECT_ROOT.joinpath("results.prof"))


if __name__ == "__main__":
    load_gui()
