import concurrent.futures
import hashlib
import os
from functools import wraps
from itertools import count
from pathlib import Path
from random import choice, choices, randint
from string import ascii_letters
from typing import Any, Callable

import polars
from humanize import naturalsize

from duple2.__app_name__ import APP_NAME
from duple2.__version__ import __version__
from duple2.app_logging import logger
from duple2.app_types import Callback, Disposition, DispositionReason
from duple2.decorators import log_func_start_finish_flags
from duple2.duplemodel import DupleModel
from duple2.duplicategroup import DuplicateGroup, DuplicateGroups
from duple2.file import File

BYTES_TO_MEGABYTES = 1 / 1e6


def gen_test_files(
    test_path_root: Path,
    numdirs: int,
    numfiles: int,
    max_file_size: int,
    callback: Callable[[int, int, str], None] | None = None,
):
    if not Path(test_path_root).exists():
        os.mkdir(test_path_root)

    file_sizes = [x for x in range(max_file_size)]
    # data = [os.urandom(file_size) for _ in range(int(numfiles/2))]
    data = [os.urandom(choice(file_sizes)) for _ in range(int((numfiles * numdirs) / 2))]

    for _ in range(numdirs):
        dir_path = test_path_root.joinpath("".join(choices(ascii_letters, k=randint(3, 30))))
        dir_path2 = dir_path.joinpath("".join(choices(ascii_letters, k=randint(3, 30))))

        if not Path(dir_path).exists():
            os.mkdir(dir_path)

        if not Path(dir_path2).exists():
            os.mkdir(dir_path2)

        for _ in range(numfiles):
            file_name = "".join(choices(ascii_letters, k=randint(3, 30)))
            file_path = Path(choice([dir_path, dir_path2])).joinpath(file_name + ".txt")

            if file_path.exists():
                continue

            with open(file_path, "wb") as f:
                f.write(choice(data))


def stat_dict(path: Path):
    stat_result = os.stat(path)
    keys = [key for key in dir(stat_result) if "st_" in key]
    return {key: stat_result.__getattribute__(key) for key in keys}


def tick_tock(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        model: DupleModel | None = None
        for arg in args:
            if type(arg) is DupleModel:
                model = arg
        for arg in kwargs.values():
            if type(arg) is DupleModel:
                model = arg

        if model:
            model.tick(func.__qualname__)
            result = func(*args, **kwargs)
            model.tock(func.__qualname__)
        else:
            result = func(*args, **kwargs)

        return result

    return wrapper


@tick_tock
@log_func_start_finish_flags
def scan(model: DupleModel, callback: Callback = None) -> DupleModel:
    result: dict = dict()
    count: int = int()
    for path in model.paths:
        for root, _, files in Path(path).walk():
            for file in files:
                file_path: Path = Path(Path(root).joinpath(file).resolve())
                model.file_dict[str(file_path)] = File(file_path)
                count += 1

                if callback:
                    callback(count, count, f"scanning directories...{result[-1]}")

    return model


# TODO: add feature to find and delete files with the same name but different file extension (IMG_0001.NEF and IMG_0001.JPG)


def is_symlink(file: File) -> bool:
    try:
        if file.path.is_symlink():
            return True
        return False
    except OSError:
        return True


def is_unique_file_size(file: File, unique_sizes: set) -> bool:
    if file.size in unique_sizes:
        return True
    return False


def is_excluded(file: File, model: DupleModel) -> bool:
    return False


@tick_tock
@log_func_start_finish_flags
def preprocess(model: DupleModel, callback: Callback = None) -> DupleModel:
    dispositions = model.get_file_dict_disposition(Disposition.NOT_ANALYZED).values()

    for i, file in enumerate(dispositions):
        if is_unique_file_size(file=file, unique_sizes=model.unique_file_sizes):
            file.disposition = Disposition.IGNORE
            file.disposition_reason = DispositionReason.UNIQUE_FILE_SIZE

        if is_symlink(file):
            file.disposition = Disposition.IGNORE
            file.disposition_reason = DispositionReason.SYMLINK

        if callback and i % len(dispositions) == 0:
            callback(i, len(dispositions), "Preprocessing")

    if callback:
        callback(100, 100, "Preprocessing")

    return model


def calculate_file_hash(file: File) -> File:
    with open(file.path, "rb") as f:
        digest = hashlib.file_digest(f, "sha256")

    file.file_hash = int(digest.hexdigest(), 16)

    return file


@tick_tock
@log_func_start_finish_flags
def calculate_hash(model: DupleModel, callback: Callback = None) -> DupleModel:
    files = model.get_file_dict_disposition(disposition=Disposition.NOT_ANALYZED).values()
    file_count = len(files)
    logger.debug("starting multithreading")
    with concurrent.futures.ThreadPoolExecutor() as executor:
        results = executor.map(calculate_file_hash, files)

        for i, result in enumerate(iter(results)):
            model.file_dict[str(result.path)].file_hash = result.file_hash
            if callback:
                callback(i, file_count, "Hashing File Contents")

    if callback:
        callback(file_count, file_count, "Hashing File Contents")

    # model.generate_ids_for_file_dict(path_or_count="count")
    return model


@tick_tock
@log_func_start_finish_flags
def find_duplicate_groups(model: DupleModel, callback: Callback = None) -> DupleModel:
    not_analyzed = model.get_file_dict_disposition(Disposition.NOT_ANALYZED).values()
    count_not_analyzed = len(not_analyzed)

    dgroups: DuplicateGroups = DuplicateGroups()
    for i, file in enumerate(not_analyzed):
        if file.file_hash not in dgroups:
            dgroups[file.file_hash] = DuplicateGroup()

        file.disposition = Disposition.DUPLICATE
        dgroups[file.file_hash].files.append(file)

        if callback:
            callback(i, count_not_analyzed, "Finding Duplicate Groups")

    if callback:
        callback(100, 100, "Finding Duplicate Groups")

    # remove duplicate groups with a count of 1
    popkeys: list = list()
    for key, dgroup in dgroups.items():
        if dgroup.count == 1:
            popkeys.append(key)
            for file in dgroup.files:
                file.disposition = Disposition.IGNORE
                file.disposition_reason = DispositionReason.UNIQUE_HASH

    for popkey in popkeys:
        dgroups.pop(popkey)

    counter = count(start=1)
    model.duplicate_groups = {
        next(counter): value for value in sorted(dgroups.values(), key=lambda value: value.total_size, reverse=True)
    }

    for key, dgroup in model.duplicate_groups.items():
        dgroup.id = key
        for file in dgroup.files:
            file.duplicate_group = key

    return model


def duplicate_groups_to_dataframe(duplicate_groups: DuplicateGroups) -> polars.DataFrame:
    data: list = list()
    dgroup: DuplicateGroup
    for i, dgroup in duplicate_groups.items():
        row = {
            "iid": i,
            "ID": i,
            "Count": dgroup.count,
            "Total Size (Bytes)": dgroup.total_size,
            # "Duplicate Size (Bytes)": dgroup.duplicate_size,
            "Total Size": naturalsize(dgroup.total_size),
            # "Duplicate Size": naturalsize(dgroup.duplicate_size),
            "Undispositioned": dgroup.undispositioned,
            "tag": dgroup.status,
        }

        data.append(row)

    if len(data) == 0:
        data.append(
            {
                "iid": 0,
                "ID": "No Duplicates",
                "Count": 0,
                "Total Size": 0,
                "Duplicate Size": 0,
            }
        )

    return polars.DataFrame(data)


def file_dict_to_dataframe(file_dict: dict[str, File]) -> polars.DataFrame:
    data: list = list()
    file_dict_only_duplicates: dict = {key: file for key, file in file_dict.items() if file.duplicate_group != 0}

    for key, file in file_dict_only_duplicates.items():
        row = {
            "iid": key,
            "ID": key,
            "Duplicate Group": file.duplicate_group,
            "Disposition": file.disposition.name,
            "Reason": file.disposition_reason.name,
            "Size (Bytes)": file.size,
            "Size": naturalsize(file.size),
            "Path": str(file.path.resolve()),
            "tag": file.disposition.name,
        }

        data.append(row)

    if len(data) == 0:
        data.append(
            {
                "iid": 0,
                "ID": "No Duplicates",
                "Duplicate Group": 0,
                "Disposition": None,
                "Reason": None,
                "Size (Bytes)": 0,
                "Size": naturalsize(0),
                "Path": None,
            }
        )

    df = polars.DataFrame(data).sort("Size (Bytes)", descending=True)
    print(df)
    return df


def calculate_summary_statistics(model: DupleModel) -> polars.DataFrame:
    data: list = list()

    data.append({"Statistic": "Total Files", "Value": f"{model.file_count}"})
    data.append({"Statistic": "Ignored Files", "Value": f"{len(model.get_file_dict_disposition(Disposition.IGNORE))}"})
    data.append(
        {"Statistic": "Duplicate Files", "Value": f"{len(model.get_file_dict_disposition(Disposition.DUPLICATE))}"}
    )
    data.append({"Statistic": "Duplicate Groups", "Value": f"{len(model.duplicate_groups)}"})
    data.append({"Statistic": "Total Size", "Value": f"{naturalsize(model.total_size)}"})
    data.append(
        {"Statistic": "Total Size of Duplicates", "Value": f"{naturalsize(model.total_duplicate_size_reduction)}"}
    )

    for key, value in model.times.items():
        data.append({"Statistic": f"{key.replace('_', ' ').title()} Time (seconds)", "Value": f"{value:0.4f}"})

    max_len = max([len(str(statistic["Value"])) for statistic in data])

    for statistic in data:
        statistic["Value"] = str(statistic["Value"]).rjust(max_len + 5)

    return polars.DataFrame(data)


def create_about() -> polars.DataFrame:
    data: list[tuple[str, Any]] = list()

    data.append(("App Name", APP_NAME))
    data.append(("Version", __version__))

    return polars.DataFrame(data, schema=["Parameter", "Value"])
