APP_NAME = "duple2"
