import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import TypeAlias

from humanize import naturalsize

from duple2.app_types import Disposition, DispositionReason


@dataclass
class File:
    id: str = field(init=False, default_factory=str)
    path: Path = field(init=True, default_factory=Path, repr=False)
    strpath: str = field(init=True, default_factory=str, repr=True)
    disposition: Disposition = field(init=False, default=Disposition.NOT_ANALYZED)
    disposition_reason: DispositionReason = field(init=False, default=DispositionReason.NOT_SET, repr=False)
    duplicate_group: int = field(init=False, default_factory=int, repr=False)
    twins: list = field(init=False, default_factory=list, repr=False)
    message: str = field(init=False, default="", repr=False)
    file_hash: int = field(init=False, default_factory=int, repr=False)
    _size: int = field(init=False, default=0, repr=False)
    _atime: float = field(init=False, default=0, repr=False)
    _ctime: float = field(init=False, default=0, repr=False)
    _mtime: float = field(init=False, default=0, repr=False)

    def __post_init__(self):
        if isinstance(self.path, str):
            self.path: Path = Path(self.path)
            self.strpath = str(self.path.resolve())
            self.id = self.strpath

        if isinstance(self.path, Path):
            self.strpath = str(self.path.resolve())
            self.id = self.strpath

        if self.path.is_file():
            self._size = self.path.stat().st_size
            self._atime = self.path.stat().st_atime
            self._ctime = self.path.stat().st_ctime
            self._mtime = self.path.stat().st_mtime
        else:
            self.disposition = Disposition.IGNORE
            self.disposition_reason = DispositionReason.DOES_NOT_EXISTS
            self.message = "File Path Does Not Exist or Unrecognized Characters in File Path/Name"

    @property
    def depth(self) -> int:
        return len(self.path.resolve().absolute().parents)

    @property
    def treeview_values(self) -> tuple:
        # iid, ID, duplicate group, disposition, reason, size (bytes), size, path, tag
        return (
            # self.id,
            self.duplicate_group,
            self.disposition.name,
            self.disposition_reason.name,
            naturalsize(self._size),
            self._size,
            self.strpath,
        )

    @property
    def name(self) -> str:
        return self.path.name

    @property
    def namelength(self) -> int:
        return len(self.path.name)

    @property
    def size(self) -> int:
        return self._size

    @property
    def atime(self) -> float:
        return self._atime

    @property
    def ctime(self) -> float:
        return self._ctime

    @property
    def mtime(self) -> float:
        return self._mtime

    # @property
    # def strpath(self) -> str:
    #     return str(self.path.resolve().absolute())

    def name_includes(self, search_string: str) -> bool:
        return bool(re.search(search_string, self.name))

    def name_excludes(self, search_string: str) -> bool:
        return not bool(re.search(search_string, self.name))

    def path_includes(self, search_string: str) -> bool:
        return bool(re.search(search_string, self.strpath))

    def path_excludes(self, search_string: str) -> bool:
        return not bool(re.search(search_string, self.strpath))

    @classmethod
    def get_available_option_attributes(cls) -> list[str]:
        result = ["depth", "namelength", "atime", "ctime", "mtime"]
        return result


FileDict: TypeAlias = dict[str, File]
FileList: TypeAlias = list[File]
