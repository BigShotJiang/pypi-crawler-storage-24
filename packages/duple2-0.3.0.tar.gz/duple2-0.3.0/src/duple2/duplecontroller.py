import tkinter
from pathlib import Path
from threading import Thread
from tkinter import simpledialog
from tkinter.filedialog import askdirectory
from typing import Callable

import polars
from gui_library.DataFrameViewer import show_dataframeviewer

from duple2.app_logging import logger, setup_logging
from duple2.app_types import Disposition, DispositionReason
from duple2.decorators import log_func_start_finish_flags
from duple2.duplemodel import DupleModel
from duple2.dupleviewer import DupleViewer
from duple2.filters import FILTER_REGISTRY, registry_to_dataframe
from duple2.library import calculate_hash, find_duplicate_groups, gen_test_files, preprocess, scan


class DupleController:
    model: DupleModel
    viewer: DupleViewer
    threads: list
    root: tkinter.Tk

    @log_func_start_finish_flags
    def __init__(self):
        setup_logging()
        self.model = DupleModel()
        self.viewer = DupleViewer()
        self.model.status_bar = self.viewer.status_bar
        self.callback = self.viewer.status_bar.update_progress
        self.clear_progress = self.viewer.status_bar.clear_progress
        self.update_status = self.viewer.status_bar.update_status

        self.viewer.show_scan_frame()
        self.make_bindings()

    @log_func_start_finish_flags
    def make_bindings(self):
        self.viewer.bind("<<AddPath>>", self.add_path)
        self.viewer.bind("<<MakeTestFiles>>", self.make_test_files)

        self.viewer.status_bar.left.bind("<Double-Button-1>", self.show_status_log)
        self.viewer.status_bar.right.bind("<Double-Button-1>", self.show_status_log)

        self.viewer.scan.selectpath.bind("<ButtonRelease-1>", self.askpath)
        self.viewer.scan.paths_to_scan.treeview.bind("<Double-Button-1>", self.removescanpath)
        self.viewer.scan.scan.bind("<ButtonRelease-1>", self.scan_directories)

        self.viewer.analysis.duplicategroups_report.duplicate_groups.treeview.bind(
            "<<TreeviewSelect>>", self.filter_for_selected_duplicate_group
        )
        self.viewer.analysis.duplicates_list.duplicates.treeview.bind("<KeyRelease>", self.user_mark_handler)
        self.viewer.analysis.filters_manager.available_filters.treeview.bind("<Double-Button-1>", self.add_filter)
        self.viewer.analysis.filters_manager.applied_filters_viewer.treeview.bind(
            "<Double-Button-1>", self.remove_filter
        )
        self.viewer.analysis.filters_manager.radio_value.trace_add(
            mode="write", callback=self.default_filter_disposition_change
        )
        self.viewer.analysis.execute_button.bind("<ButtonRelease-1>", self.resolve_duplicates)

    @log_func_start_finish_flags
    def add_path(self, event: tkinter.Event):
        self.askpath(tkinter.Event())
        self.model.reset()
        self.clear_viewer()
        self.scan_directories()

    def clear_viewer(self):
        self.viewer.analysis.duplicategroups_report.duplicate_groups.update_data(df=polars.DataFrame())
        self.viewer.analysis.duplicategroups_report.duplicate_groups.df = polars.DataFrame()
        logger.debug("cleared duplicated groups")
        self.viewer.analysis.duplicategroups_report.summary_report.update_data(df=polars.DataFrame())
        logger.debug("cleared summary report")
        self.viewer.analysis.duplicates_list.duplicates.update_data(df=polars.DataFrame())
        logger.debug("cleared duplicate lists")

    @log_func_start_finish_flags
    def make_test_files(self, event: tkinter.Event):
        path = Path(
            askdirectory(
                initialdir=str(Path("~").expanduser().absolute()),
                mustexist=True,
                title="Choose Path for Test Files",
            )
        )

        path = path.joinpath("duple_test_files")
        gen_test_files(path, numdirs=5, numfiles=5, max_file_size=1000)

        self.model.reset()
        logger.debug("reset model")
        self.model.paths = set()
        self.model.paths.add(path)
        logger.debug(f"adding path {str(path)}")

        self.clear_viewer()

        if self.viewer.analysis.duplicategroups_report.duplicate_groups.df.is_empty():
            logger.debug("duplicate groups dataframe is empty")
        else:
            logger.debug("duplicate groups dataframe is not empty")
            logger.debug(self.viewer.analysis.duplicategroups_report.duplicate_groups.df)

        self.scan_directories()

    @log_func_start_finish_flags
    def askpath(self, event: tkinter.Event):
        path = Path(
            askdirectory(
                initialdir=str(Path("~").expanduser().absolute()),
                mustexist=True,
                title="Choose Path to Scan",
            )
        )

        if path != Path("."):
            self.model.paths.add(path)

        self.update_scan_paths()

    @log_func_start_finish_flags
    def show_status_log(self, event: tkinter.Event):
        df = polars.DataFrame(self.viewer.status_bar.status_log)
        show_dataframeviewer(title="Log", df=df)

    @log_func_start_finish_flags
    def update_scan_paths(self):
        self.viewer.scan.paths_to_scan.update_data(df=self.model.paths_to_dataframe())

    @log_func_start_finish_flags
    def removescanpath(self, event: tkinter.Event):
        path = Path(self.viewer.scan.paths_to_scan.selection()[0])
        self.model.paths.remove(path)

        self.update_scan_paths()

    @log_func_start_finish_flags
    def scan_directories(self, event: tkinter.Event = tkinter.Event()):
        self.model.tick("Overall", update_status_bar=False)
        self.model = scan(model=self.model, callback=self.callback(1, 1, message="scanning paths"))
        logger.debug("completed scan")
        self.model = preprocess(model=self.model, callback=self.callback)
        logger.debug("completed preprocess")
        self.model = calculate_hash(model=self.model, callback=self.callback)
        logger.debug("completed hashing")
        self.model = find_duplicate_groups(model=self.model, callback=self.callback)
        logger.debug("completed finding duplicates")
        self.model.tock("Overall", update_status_bar=False)

        overall_time = self.model.times.pop("Overall")
        self.model.times["Overall"] = overall_time

        logger.debug("clearing status bar progress")
        self.clear_progress()
        logger.debug("showing analysis frame")
        self.viewer.show_analysis_frame()
        logger.debug("updating viewer analysis")
        self.update_viewer_analysis()

    @log_func_start_finish_flags
    def update_viewer_analysis(self):
        self.update_viewer_duplicate_groups()
        self.update_viewer_summary_report()
        self.update_viewer_duplicate_list()
        self.update_viewer_available_filters()
        self.update_viewer_applied_filters()

    @log_func_start_finish_flags
    def default_filter_disposition_change(self, *args):
        radio_value = self.viewer.analysis.filters_manager.radio_value.get()
        match radio_value:
            case "Delete":
                self.model.duplicate_disposition = Disposition.DELETE
            case "Shortcut":
                self.model.duplicate_disposition = Disposition.CREATE_LINK

        self.model.apply_filters(callback=self.callback)
        self.update_viewer_duplicate_list()
        self.model.report_resolution_stats()

    @log_func_start_finish_flags
    def update_viewer_available_filters(self):
        self.viewer.analysis.filters_manager.available_filters.update_data(df=registry_to_dataframe())

    @log_func_start_finish_flags
    def update_viewer_summary_report(self):
        self.viewer.analysis.duplicategroups_report.summary_report.update_data(
            df=self.model.calculate_summary_statistics()
        )

    @log_func_start_finish_flags
    def update_viewer_duplicate_groups(self):
        if self.viewer.analysis.duplicategroups_report.duplicate_groups.df.is_empty():
            self.viewer.analysis.duplicategroups_report.duplicate_groups.update_data(
                df=self.model.duplicate_groups_to_dataframe(callback=self.callback)
            )
            return

        treeview = self.viewer.analysis.duplicategroups_report.duplicate_groups.treeview
        self.viewer.analysis.duplicategroups_report.duplicate_groups.df = self.model.duplicate_groups_to_dataframe(
            callback=self.callback
        )
        for key, dgroup in self.model.duplicate_groups.items():
            if key == 0:
                continue

            treeview.item(key, values=dgroup.treeview_values(), tags=dgroup.status)

    @log_func_start_finish_flags
    def update_viewer_duplicate_list(self):
        self.viewer.analysis.duplicates_list.duplicates.update_data(
            df=self.model.file_dict_to_dataframe(callback=self.callback)
        )

    @log_func_start_finish_flags
    def update_viewer_applied_filters(self):
        self.viewer.analysis.filters_manager.applied_filters_viewer.update_data(
            df=self.model.applied_filters.to_dataframe()
        )

    @log_func_start_finish_flags
    def resolve_duplicates(self, event: tkinter.Event):
        # TODO: resolve the duplicates, but first confirm the action with the user

        length = len(self.model.duplicate_groups)
        for i, dgroup in enumerate(self.model.duplicate_groups.values()):
            dgroup.resolve()
            self.callback(i, length, "resolving duplicate groups")

        self.model.reset()
        self.scan_directories()

        self.viewer.analysis.filters_manager.applied_filters_viewer.clear()
        self.viewer.analysis.duplicategroups_report.duplicate_groups.update_data(
            df=self.model.duplicate_groups_to_dataframe(callback=self.callback)
        )

    @log_func_start_finish_flags
    def get_duplicate_group_filter(self) -> set[int]:
        selections = self.viewer.analysis.duplicategroups_report.duplicate_groups.treeview.selection()
        selections = {int(selection) for selection in selections}
        return selections

    @log_func_start_finish_flags
    def filter_for_selected_duplicate_group(self, event: tkinter.Event):
        self.model.duplicate_group_filter = self.get_duplicate_group_filter()
        self.update_viewer_duplicate_list()

    @log_func_start_finish_flags
    def user_mark_handler(self, event: tkinter.Event):
        selection = self.viewer.analysis.duplicates_list.duplicates.treeview.selection()
        if event.keysym == "c":
            self.user_mark(selection, Disposition.CREATE_LINK)
        if event.keysym == "d":
            self.user_mark(selection, Disposition.DELETE)
        if event.keysym == "k":
            self.user_mark(selection, Disposition.KEEP)
        if event.keysym == "r":
            self.user_mark(selection, Disposition.DUPLICATE)

    @log_func_start_finish_flags
    def user_mark(self, ids: tuple, disposition: Disposition):
        disposition_reason = DispositionReason.USER_OVERRIDE
        if disposition == Disposition.DUPLICATE:
            disposition_reason = DispositionReason.NOT_SET

        for id in ids:
            self.model.file_dict[id].disposition = disposition
            self.model.file_dict[id].disposition_reason = disposition_reason
            self.update_viewer_duplicate_entry(id)

        self.update_viewer_duplicate_groups()
        self.model.report_resolution_stats()

    @log_func_start_finish_flags
    def update_viewer_duplicate_entry(self, id: str):
        file = self.model.file_dict[id]
        treeview = self.viewer.analysis.duplicates_list.duplicates.treeview
        treeview.item(id, values=file.treeview_values, tags=file.disposition.name)

    @log_func_start_finish_flags
    def add_filter(self, event: tkinter.Event):
        selected_filter = FILTER_REGISTRY[self.viewer.analysis.filters_manager.available_filters.selection()[0]]

        filter_string = str()
        if selected_filter.has_args:
            filter_string = simpledialog.askstring(
                title=f"What is the Filter String for {selected_filter.name}",
                prompt="What is the filter string:",
            )

        key = self.model.applied_filters.add(selected_filter)
        self.model.applied_filters[key].filter_string = str(filter_string)

        self.model.apply_filters(callback=self.callback)

        self.update_viewer_applied_filters()
        self.update_viewer_duplicate_list()
        self.update_viewer_duplicate_groups()
        self.model.report_resolution_stats()

    @log_func_start_finish_flags
    def remove_filter(self, event: tkinter.Event):
        selections = self.viewer.analysis.filters_manager.applied_filters_viewer.selection()
        if not selections:
            return

        for selection in selections:
            self.model.applied_filters.pop(selection)

        self.model.apply_filters(callback=self.callback)

        self.update_viewer_applied_filters()
        self.update_viewer_duplicate_list()
        self.update_viewer_duplicate_groups()
        self.model.report_resolution_stats()

    @log_func_start_finish_flags
    def kick_thread(self, target: Callable, args: tuple | None = None) -> None:
        if args:
            t = Thread(target=target, args=(args,), daemon=True)
        else:
            t = Thread(target=target, daemon=True)
        t.start()
        self.threads.append(t)

    @log_func_start_finish_flags
    def run(self):
        self.viewer.mainloop()


@log_func_start_finish_flags
def main():
    DupleController().run()


if __name__ == "__main__":
    main()
