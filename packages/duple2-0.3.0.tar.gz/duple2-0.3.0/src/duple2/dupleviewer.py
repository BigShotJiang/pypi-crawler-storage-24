import cProfile
import tkinter
from tkinter import Radiobutton, StringVar
from tkinter.ttk import Button, Frame, Label, Notebook, PanedWindow, Panedwindow, Style

from gui_library.DataFrameViewer import DataFrameViewer
from gui_library.StatusBar import StatusBar

from duple2.app_types import Disposition
from duple2.info import PROJECT_ROOT


class Scan(Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.make_widgets()

    def make_widgets(self):
        self.selectpath: Button = Button(self, text="Add Path to Scan")
        self.paths_to_scan: DataFrameViewer = DataFrameViewer(self)
        self.scan: Button = Button(self, text="Scan")

        self.selectpath.grid(row=0, column=0, rowspan=1, columnspan=1, sticky="nsew", padx=5, pady=2)
        self.paths_to_scan.grid(row=1, column=0, rowspan=1, columnspan=1, sticky="nsew", padx=5, pady=2)
        self.scan.grid(row=2, column=0, rowspan=1, columnspan=1, sticky="nsew", padx=5, pady=2)

        self.rowconfigure(0, weight=0)
        self.rowconfigure(1, weight=1)
        self.rowconfigure(2, weight=0)
        self.columnconfigure(0, weight=1)


class Analysis(Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.make_widgets()

    def make_widgets(self):
        self.pwV: Panedwindow = Panedwindow(master=self, orient=tkinter.VERTICAL)
        self.pwV.grid(row=0, column=0, rowspan=1, columnspan=1, sticky="nsew", padx=5, pady=2)

        self.pwH: PanedWindow = PanedWindow(master=self.pwV, orient=tkinter.HORIZONTAL)
        self.pwH.grid(row=0, column=0, rowspan=1, columnspan=1, sticky="nsew", padx=5, pady=2)

        self.duplicategroups_report = DuplicateGroups_Report(self)
        self.filters_manager = FiltersManager(self)
        self.duplicates_list = DuplicatesManager(self)

        self.pwV.add(self.pwH, weight=1)
        self.pwV.add(self.duplicates_list, weight=3)

        self.pwH.add(self.duplicategroups_report, weight=3)
        self.pwH.add(self.filters_manager, weight=2)

        self.execute_button: Button = Button(master=self, text="Resolve Dispositioned Duplicates")
        self.execute_button.grid(row=1, column=0, rowspan=1, columnspan=1, sticky="nsew", padx=5, pady=2)
        self.rowconfigure(0, weight=1)
        self.rowconfigure(1, weight=0)
        self.columnconfigure(0, weight=1)


class DuplicateGroups_Report(Frame):
    def __init__(self, analysis: Analysis):
        super().__init__(analysis)
        self.analysis = analysis
        self.make_widgets()

    def make_widgets(self):
        self.notebook: Notebook = Notebook(self)
        self.notebook.grid(row=0, column=0, rowspan=1, columnspan=1, sticky="nsew", padx=0, pady=0)

        self.duplicate_groups: DataFrameViewer = DataFrameViewer(self)
        self.duplicate_groups.treeview.tag_configure("bad", background="indian red", foreground="Black")
        self.duplicate_groups.treeview.tag_configure("good", background="PaleGreen2", foreground="Black")

        self.summary_report: DataFrameViewer = DataFrameViewer(self)

        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)

        self.notebook.add(self.duplicate_groups, text="Duplicate Groups")
        self.notebook.add(self.summary_report, text="Summary Report")


class FiltersManager(Frame):
    def __init__(self, analysis: Analysis):
        super().__init__(analysis)
        self.analysis = analysis
        self.make_widgets()

    def make_widgets(self):
        self.pw = PanedWindow(master=self, orient="horizontal")
        self.pw.grid(row=1, column=0, rowspan=1, columnspan=3, sticky="nsew", padx=5, pady=2)

        self.label_filters: Label = Label(self, text="Filters to Determine the Original File")
        self.label_directions: Label = Label(
            self,
            text="Double click 'Available Filter' to add to the 'Applied Filter' list, double click 'Applied Filter' to remove",
        )

        self.label_filters.grid(row=0, column=0, rowspan=1, columnspan=1, sticky="nsw", padx=5, pady=2)
        self.label_directions.grid(row=0, column=1, rowspan=1, columnspan=2, sticky="nse", padx=5, pady=2)

        self.available_filters: DataFrameViewer = DataFrameViewer(self)

        self.applied_filters_viewer_frame: Frame = Frame(self)
        self.applied_filters_viewer_frame.rowconfigure(0, weight=1)
        self.applied_filters_viewer_frame.rowconfigure(0, weight=2)
        self.applied_filters_viewer_frame.columnconfigure(0, weight=1)

        self.applied_filters_viewer: DataFrameViewer = DataFrameViewer(self.applied_filters_viewer_frame)
        self.applied_filters_viewer.grid(row=0, column=0, padx=5, pady=5, sticky="nsew")

        self.radio_button_frame = self.make_radio_button_frame(self.applied_filters_viewer_frame)
        self.radio_button_frame.grid(row=1, column=0, rowspan=1, columnspan=1, sticky="nsew", padx=5, pady=2)

        self.pw.add(self.available_filters, weight=4)
        self.pw.add(self.applied_filters_viewer_frame, weight=1)

        self.rowconfigure(0, weight=0)
        self.rowconfigure(1, weight=1)
        self.columnconfigure(0, weight=2)
        self.columnconfigure(1, weight=1)
        self.columnconfigure(2, weight=1)

    def make_radio_button_frame(self, master: Frame) -> Frame:
        radio_button_options: list = ["Delete", "Shortcut"]
        frame: Frame = Frame(master)
        self.radio_button_label: Label = Label(
            frame,
            text="How to disposition DUPLICATE files:",
        )
        self.radio_button_label.grid(
            row=0, column=0, sticky="nsew", padx=5, pady=2, rowspan=1, columnspan=len(radio_button_options)
        )
        self.radio_button_list: list = list()
        self.radio_value = StringVar(self, value=radio_button_options[0])
        for i, button in enumerate(radio_button_options):
            rb = Radiobutton(
                frame,
                text=button,
                variable=self.radio_value,
                value=button,
            )
            rb.grid(row=0, column=i + 2, sticky="nsw", padx=5, pady=0)
            frame.columnconfigure(i + 2, weight=0)
            self.radio_button_list.append(rb)

        # Frame(self.radio_button_frame).grid(row=0, column=len(radio_button_options) + 1, sticky="nsew")

        frame.rowconfigure(0, weight=1)
        frame.columnconfigure(0, weight=1)
        frame.columnconfigure(len(radio_button_options) + 2, weight=2)

        return frame


class DuplicatesManager(Frame):
    def __init__(self, analysis: Analysis):
        super().__init__(analysis)
        self.analysis = analysis
        self.make_widgets()

        self.make_widgets()

    def make_widgets(self):
        self.label_duplicates: Label = Label(self, text="Duplicates")
        self.label_instructions: Label = Label(
            self, text="Keyboard Shortcuts: 'c' = SHORTCUT; 'd' = DELETE, 'k' = KEEP; r = DUPLICATE"
        )

        self.label_duplicates.grid(row=0, column=0, rowspan=1, columnspan=1, sticky="nsw", padx=5, pady=2)
        self.label_instructions.grid(row=0, column=1, rowspan=1, columnspan=1, sticky="nse", padx=5, pady=2)

        self.duplicates: DataFrameViewer = DataFrameViewer(self)
        self.duplicates.grid(row=1, column=0, rowspan=1, columnspan=2, sticky="nsew", padx=5, pady=2)
        self.duplicates.treeview.tag_configure(Disposition.DELETE.name, background="indian red", foreground="Black")
        self.duplicates.treeview.tag_configure(Disposition.KEEP.name, background="PaleGreen2", foreground="Black")
        self.duplicates.treeview.tag_configure(
            Disposition.CREATE_LINK.name, background="SteelBlue1", foreground="Black"
        )

        self.rowconfigure(0, weight=0)
        self.rowconfigure(1, weight=1)
        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, weight=1)


class DupleViewer(tkinter.Tk):
    scan: Scan
    analysis: Analysis
    status_bar: StatusBar

    def __init__(self):
        super().__init__()
        self.scan = Scan(self)
        self.analysis = Analysis(self)
        self.status_bar = StatusBar(self, progress_step_size=10)

        self.title("Duple2 - Find and Resolve Duplicate Files")

        style = Style()
        style.configure("Treeview", font=("Courier New", 10))
        style.configure("TNotebook", padding=0)

        self.make_menu()
        self.make_widgets()

        self.show_scan_frame()

    def make_menu(self):
        menubar = tkinter.Menu(self, tearoff=0)

        file_menu = tkinter.Menu(menubar, tearoff=0)
        file_menu.add_command(label="Add Path", command=self.add_path)
        file_menu.add_command(label="Make Test Files", command=self.make_test_files)

        menubar.add_cascade(label="File", menu=file_menu)
        self.config(menu=menubar)

    def make_widgets(self):
        self.status_bar.grid(row=1, column=0, rowspan=1, columnspan=1, sticky="nsew", padx=5, pady=2)
        self.rowconfigure(0, weight=1)
        self.columnconfigure(0, weight=1)

    def add_path(self):
        self.event_generate("<<AddPath>>")

    def make_test_files(self):
        self.event_generate("<<MakeTestFiles>>")

    def show_scan_frame(self):
        self.scan.grid(row=0, column=0, rowspan=1, columnspan=1, sticky="nsew", padx=5, pady=2)
        self.analysis.grid_forget()

    def show_analysis_frame(self):
        self.analysis.grid(row=0, column=0, rowspan=1, columnspan=1, sticky="nsew", padx=5, pady=2)
        self.scan.grid_forget()


def load_gui():
    # setup_logging()
    app = DupleViewer()
    app.mainloop()


def load_gui_w_tracer():
    with cProfile.Profile() as tracer:
        app = DupleViewer()
        app.mainloop()

        tracer.dump_stats(PROJECT_ROOT.joinpath("results.prof"))


if __name__ == "__main__":
    load_gui()
