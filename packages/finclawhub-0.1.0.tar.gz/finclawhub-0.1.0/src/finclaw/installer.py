"""
Installer — downloads SKILL.md, runs pip install, updates local store.
"""
import subprocess
import sys
from typing import List, Optional, Tuple

from rich.console import Console

from . import registry, store

console = Console()


def _pip_install(packages: List[str]) -> bool:
    """Run pip install for the given package list. Returns True on success."""
    if not packages:
        return True
    cmd = [sys.executable, "-m", "pip", "install", "--quiet"] + packages
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        console.print(f"[red]pip install 失败:[/red]\n{result.stderr.strip()}")
        return False
    return True


def install_skill(
    skill_id: str,
    skill_meta: Optional[dict] = None,
    force: bool = False,
) -> Tuple[bool, str]:
    """
    Install a single skill.

    Returns (success, message).
    """
    if store.is_installed(skill_id) and not force:
        return False, f"已安装（使用 --force 重新安装）"

    # 1. Download SKILL.md
    skill_md = registry.fetch_skill_md(skill_id)

    # 2. Extract pip packages from SKILL.md (if available)
    packages: List[str] = []
    if skill_md:
        packages = registry.parse_skill_md_packages(skill_md)

    # 3. Install pip packages
    if packages:
        console.print(f"  [dim]pip install {' '.join(packages)}[/dim]")
        if not _pip_install(packages):
            return False, "依赖安装失败"

    # 4. Save to local store
    name = skill_id
    version = "1.0.0"
    if skill_meta:
        name = skill_meta.get("name", skill_id)
        version = skill_meta.get("version", "1.0.0")

    store.register(
        skill_id=skill_id,
        name=name,
        version=version,
        packages=packages,
        skill_md_content=skill_md,
    )

    pkg_note = f" (+{len(packages)} packages)" if packages else ""
    return True, f"安装成功{pkg_note}"


def uninstall_skill(skill_id: str) -> Tuple[bool, str]:
    """Remove a skill from local store (does NOT uninstall pip packages)."""
    if not store.is_installed(skill_id):
        return False, "未安装"
    store.unregister(skill_id)
    return True, "已卸载（Python 包保留，如需删除请手动 pip uninstall）"
