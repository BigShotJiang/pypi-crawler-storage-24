"""
Local store — manages ~/.finclaw/
  ~/.finclaw/installed.json   dict of installed skills
  ~/.finclaw/skills/<id>/SKILL.md
"""
import json
import os
import shutil
from datetime import date
from pathlib import Path
from typing import Dict, Optional

FINCLAW_DIR = Path.home() / ".finclaw"
INSTALLED_FILE = FINCLAW_DIR / "installed.json"
SKILLS_DIR = FINCLAW_DIR / "skills"


def _ensure_dirs():
    FINCLAW_DIR.mkdir(parents=True, exist_ok=True)
    SKILLS_DIR.mkdir(parents=True, exist_ok=True)


def load_installed() -> Dict[str, dict]:
    _ensure_dirs()
    if not INSTALLED_FILE.exists():
        return {}
    return json.loads(INSTALLED_FILE.read_text(encoding="utf-8"))


def _save_installed(data: Dict[str, dict]):
    _ensure_dirs()
    INSTALLED_FILE.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def is_installed(skill_id: str) -> bool:
    return skill_id in load_installed()


def register(skill_id: str, name: str, version: str, packages: list[str], skill_md_content: Optional[str] = None):
    """Record a skill as installed and optionally save its SKILL.md."""
    data = load_installed()
    data[skill_id] = {
        "name": name,
        "version": version,
        "installed_at": str(date.today()),
        "packages": packages,
    }
    _save_installed(data)

    if skill_md_content:
        skill_dir = SKILLS_DIR / skill_id
        skill_dir.mkdir(parents=True, exist_ok=True)
        (skill_dir / "SKILL.md").write_text(skill_md_content, encoding="utf-8")


def unregister(skill_id: str):
    data = load_installed()
    data.pop(skill_id, None)
    _save_installed(data)
    skill_dir = SKILLS_DIR / skill_id
    if skill_dir.exists():
        shutil.rmtree(skill_dir)


def get_skill_md_path(skill_id: str) -> Optional[Path]:
    p = SKILLS_DIR / skill_id / "SKILL.md"
    return p if p.exists() else None


def skills_path() -> Path:
    return SKILLS_DIR
