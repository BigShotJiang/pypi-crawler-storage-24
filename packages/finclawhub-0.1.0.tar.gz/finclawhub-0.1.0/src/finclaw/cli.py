"""
finclaw CLI — entry point for all commands.

  finclaw install akshare-stock
  finclaw install akshare-stock backtrader-skill factor-analysis
  finclaw uninstall akshare-stock
  finclaw list
  finclaw list --installed
  finclaw search "股票"
  finclaw info akshare-stock
  finclaw update
  finclaw path
"""
import sys
from typing import List

import click
from rich.console import Console
from rich.table import Table
from rich import box
from rich.panel import Panel
from rich.text import Text

from . import registry, store
from .installer import install_skill, uninstall_skill

console = Console()
err_console = Console(stderr=True)

BANNER = "[bold #1A3A5C]Fin[/][bold #2563EB]Skills[/][bold #F59E0B]Hub[/] [dim]Skills CLI[/dim]"


# ── Helpers ───────────────────────────────────────────────────────────────────

def _score_color(score) -> str:
    if score is None:
        return "dim"
    if score >= 9:
        return "green"
    if score >= 7.5:
        return "yellow"
    return "red"


def _status_style(status: str) -> str:
    return {"stable": "green", "beta": "yellow", "experimental": "magenta"}.get(status, "dim")


def _category_color(cat: str) -> str:
    palette = {
        "股票": "red", "基金": "blue", "债券": "magenta", "期货": "orange3",
        "宏观": "cyan", "量化": "green", "另类数据": "bright_magenta",
        "保险": "bright_cyan", "AI助手": "bright_blue",
        "原子工具": "bright_black", "数据工具": "dark_cyan",
        "财富管理": "yellow", "投资银行": "bold blue", "其他": "dim",
    }
    return palette.get(cat, "dim")


# ── Main group ────────────────────────────────────────────────────────────────

@click.group()
@click.version_option(package_name="finclaw")
def main():
    """FinClaw Skills CLI — install and manage financial AI skills."""


# ── install ───────────────────────────────────────────────────────────────────

@main.command()
@click.argument("skill_ids", nargs=-1, required=True)
@click.option("--force", "-f", is_flag=True, help="强制重新安装（即使已存在）")
def install(skill_ids: tuple, force: bool):
    """安装一个或多个 skills。

    \b
    示例：
      finclaw install akshare-stock
      finclaw install akshare-stock backtrader-skill factor-analysis
    """
    console.print(BANNER)
    console.print()

    # Fetch remote index once for metadata
    with console.status("[dim]获取 Skills 索引…[/dim]"):
        all_skills = registry.fetch_index()
    index_map = {s["id"]: s for s in all_skills}

    total = len(skill_ids)
    ok = 0

    for i, sid in enumerate(skill_ids, 1):
        prefix = f"[dim]({i}/{total})[/dim] " if total > 1 else ""
        meta = index_map.get(sid)

        if meta is None and not all_skills:
            # No network — install blindly
            console.print(f"{prefix}[bold]{sid}[/bold]  [dim]（离线模式，跳过元数据验证）[/dim]")
        elif meta is None:
            console.print(f"{prefix}[bold]{sid}[/bold]  [red]✗ 未找到该 Skill[/red]")
            console.print(f"  [dim]提示：运行 [cyan]finclaw search {sid}[/cyan] 查看相似项[/dim]")
            continue

        display_name = meta["name"] if meta else sid
        console.print(f"{prefix}[bold]{display_name}[/bold]  [dim]{sid}[/dim]")

        with console.status(f"  [dim]下载 SKILL.md…[/dim]"):
            success, msg = install_skill(sid, skill_meta=meta, force=force)

        if success:
            console.print(f"  [green]✓ {msg}[/green]")
            ok += 1
        else:
            console.print(f"  [yellow]⚠ {msg}[/yellow]")

    console.print()
    if total > 1:
        console.print(f"[bold]完成：[green]{ok}[/green] / {total} 安装成功[/bold]")
    console.print(
        f"[dim]Skills 存储位置: {store.skills_path()}[/dim]"
    )


# ── uninstall ─────────────────────────────────────────────────────────────────

@main.command()
@click.argument("skill_ids", nargs=-1, required=True)
def uninstall(skill_ids: tuple):
    """卸载 skills（保留已安装的 Python 包）。

    \b
    示例：
      finclaw uninstall akshare-stock
    """
    for sid in skill_ids:
        success, msg = uninstall_skill(sid)
        icon = "[green]✓[/green]" if success else "[red]✗[/red]"
        console.print(f"{icon} [bold]{sid}[/bold]  {msg}")


# ── list ──────────────────────────────────────────────────────────────────────

@main.command("list")
@click.option("--installed", "-i", is_flag=True, help="只显示本地已安装的 Skills")
@click.option("--category", "-c", default="", help="按分类筛选，如 股票")
def list_skills(installed: bool, category: str):
    """列出 skills 目录。

    \b
    示例：
      finclaw list
      finclaw list --installed
      finclaw list --category 量化
    """
    console.print(BANNER)
    console.print()

    installed_map = store.load_installed()

    if installed:
        if not installed_map:
            console.print("[dim]尚未安装任何 Skills。运行 [cyan]finclaw install <id>[/cyan] 开始。[/dim]")
            return
        rows = [{"id": sid, **meta} for sid, meta in installed_map.items()]
        title = f"已安装 Skills（{len(rows)} 个）"
        show_installed_col = False
    else:
        with console.status("[dim]获取 Skills 索引…[/dim]"):
            rows = registry.fetch_index()
        if not rows:
            console.print("[red]无法获取索引，请检查网络连接。[/red]")
            return
        if category:
            rows = [r for r in rows if r.get("category") == category]
        title = f"FinClaw Skills 目录（{len(rows)} 个）"
        show_installed_col = True

    table = Table(
        title=title,
        box=box.ROUNDED,
        header_style="bold",
        show_lines=False,
        expand=True,
    )
    table.add_column("ID", style="cyan", no_wrap=True, max_width=35)
    table.add_column("中文说明", max_width=30)
    table.add_column("分类", max_width=8, justify="center")
    if not installed:
        table.add_column("评分", max_width=5, justify="right")
    if show_installed_col:
        table.add_column("状态", max_width=6, justify="center")

    for s in rows:
        sid = s.get("id", s.get("name", "?"))
        zh = s.get("description_zh") or s.get("description", "")
        if len(zh) > 28:
            zh = zh[:27] + "…"
        cat = s.get("category", "")
        cat_text = Text(cat, style=_category_color(cat))

        if installed:
            table.add_row(sid, zh, cat_text)
        else:
            overall = s.get("evaluation", {}).get("overall") if s.get("evaluation") else None
            score_str = str(overall) if overall else "—"
            score_text = Text(score_str, style=_score_color(overall))

            is_inst = sid in installed_map
            status_text = Text("✓ 已装", style="green") if is_inst else Text("", style="dim")
            table.add_row(sid, zh, cat_text, score_text, status_text)

    console.print(table)
    if not installed:
        console.print(
            f"\n[dim]运行 [cyan]finclaw install <id>[/cyan] 安装  ·  "
            f"[cyan]finclaw search <关键词>[/cyan] 搜索  ·  "
            f"[cyan]finclaw list --installed[/cyan] 查看已安装[/dim]"
        )


# ── search ────────────────────────────────────────────────────────────────────

@main.command()
@click.argument("query")
def search(query: str):
    """按关键词搜索 Skills（支持中文）。

    \b
    示例：
      finclaw search 股票
      finclaw search backtest
      finclaw search "宏观经济"
    """
    with console.status("[dim]搜索中…[/dim]"):
        all_skills = registry.fetch_index()

    if not all_skills:
        console.print("[red]无法获取索引。[/red]")
        return

    results = registry.search(query, all_skills)
    installed_map = store.load_installed()

    if not results:
        console.print(f"[yellow]未找到匹配 \"{query}\" 的 Skills。[/yellow]")
        return

    table = Table(
        title=f'搜索 "{query}" — {len(results)} 条结果',
        box=box.ROUNDED,
        header_style="bold",
        expand=True,
    )
    table.add_column("ID", style="cyan", no_wrap=True, max_width=35)
    table.add_column("中文说明", max_width=32)
    table.add_column("分类", max_width=8, justify="center")
    table.add_column("评分", max_width=5, justify="right")
    table.add_column("", max_width=5, justify="center")

    for s in results:
        sid = s["id"]
        zh = s.get("description_zh") or s.get("description", "")
        if len(zh) > 30:
            zh = zh[:29] + "…"
        cat = s.get("category", "")
        overall = s.get("evaluation", {}).get("overall") if s.get("evaluation") else None
        score_str = str(overall) if overall else "—"
        is_inst = Text("✓", style="green") if sid in installed_map else Text("")
        table.add_row(
            sid, zh,
            Text(cat, style=_category_color(cat)),
            Text(score_str, style=_score_color(overall)),
            is_inst,
        )

    console.print(table)
    console.print(f"\n[dim]运行 [cyan]finclaw install <id>[/cyan] 安装，[cyan]finclaw info <id>[/cyan] 查看详情[/dim]")


# ── info ──────────────────────────────────────────────────────────────────────

@main.command()
@click.argument("skill_id")
def info(skill_id: str):
    """查看某个 Skill 的详细信息。

    \b
    示例：
      finclaw info akshare-stock
    """
    with console.status("[dim]获取信息…[/dim]"):
        all_skills = registry.fetch_index()

    s = registry.get_by_id(skill_id, all_skills)
    installed_map = store.load_installed()
    local = installed_map.get(skill_id)

    if not s and not local:
        console.print(f"[red]未找到 Skill: {skill_id}[/red]")
        sys.exit(1)

    data = s or {}
    name = data.get("name") or (local or {}).get("name") or skill_id

    # Header
    console.print()
    console.print(Panel(
        f"[bold]{name}[/bold]\n[dim]{skill_id}[/dim]",
        border_style="blue",
        expand=False,
    ))

    # Fields
    def row(label: str, value: str, style: str = ""):
        console.print(f"  [dim]{label:<14}[/dim] [{style}]{value}[/{style}]" if style else f"  [dim]{label:<14}[/dim] {value}")

    row("分类", data.get("category", "—"))
    row("版本", data.get("version", "1.0.0"))
    status = data.get("status", "stable")
    row("状态", status, _status_style(status))

    zh = data.get("description_zh") or data.get("description", "—")
    row("中文说明", zh)

    # Evaluation
    ev = data.get("evaluation")
    if ev:
        console.print(f"  [dim]{'评分':<14}[/dim] ", end="")
        console.print(
            f"综合 [bold {_score_color(ev.get('overall'))}]{ev.get('overall', '—')}[/bold {_score_color(ev.get('overall'))}]"
            f"  安全 {ev.get('safety','—')}  完整度 {ev.get('completeness','—')}"
            f"  执行 {ev.get('executability','—')}  维护 {ev.get('maintainability','—')}"
            f"  成本 {ev.get('cost_awareness','—')}"
        )

    # Features
    features = data.get("features", [])
    if features:
        console.print(f"  [dim]{'功能':<14}[/dim] {' · '.join(features[:5])}")

    # Tags
    tags = data.get("tags", [])
    if tags:
        console.print(f"  [dim]{'标签':<14}[/dim] {', '.join(tags)}")

    # Install cmd
    install_cmd = data.get("install_cmd")
    if install_cmd:
        console.print(f"  [dim]{'安装命令':<14}[/dim] [cyan]{install_cmd}[/cyan]")

    github_url = data.get("github_url")
    if github_url:
        console.print(f"  [dim]{'GitHub':<14}[/dim] [link={github_url}]{github_url}[/link]")

    # Local install status
    console.print()
    if local:
        console.print(f"  [green]✓ 已安装[/green]  {local.get('installed_at', '')}  packages: {', '.join(local.get('packages', [])) or '无'}")
    else:
        console.print(f"  [dim]未安装  →  运行 [cyan]finclaw install {skill_id}[/cyan][/dim]")
    console.print()


# ── update ────────────────────────────────────────────────────────────────────

@main.command()
@click.argument("skill_ids", nargs=-1)
def update(skill_ids: tuple):
    """重新安装 skills 以获取最新版本。

    不指定 ID 时更新所有已安装的 Skills。

    \b
    示例：
      finclaw update
      finclaw update akshare-stock
    """
    installed_map = store.load_installed()

    if not installed_map:
        console.print("[dim]尚未安装任何 Skills。[/dim]")
        return

    targets = list(skill_ids) if skill_ids else list(installed_map.keys())

    with console.status("[dim]获取 Skills 索引…[/dim]"):
        all_skills = registry.fetch_index()
    index_map = {s["id"]: s for s in all_skills}

    console.print(BANNER)
    console.print(f"\n更新 {len(targets)} 个 Skills…\n")

    ok = 0
    for sid in targets:
        meta = index_map.get(sid)
        console.print(f"[bold]{sid}[/bold]")
        success, msg = install_skill(sid, skill_meta=meta, force=True)
        if success:
            console.print(f"  [green]✓ {msg}[/green]")
            ok += 1
        else:
            console.print(f"  [red]✗ {msg}[/red]")

    console.print(f"\n[bold]更新完成：{ok} / {len(targets)}[/bold]")


# ── path ──────────────────────────────────────────────────────────────────────

@main.command()
def path():
    """显示本地 Skills 存储路径。

    可将此路径配置到 AI Agent（如 Claude Code）以加载 SKILL.md。
    """
    p = store.skills_path()
    console.print(f"[cyan]{p}[/cyan]")
    console.print(f"\n[dim]在 Claude Code 中使用：[/dim]")
    console.print(f"[dim]将下方路径添加到 CLAUDE.md 或 .mcp.json 的 skill_path 字段：[/dim]")
    console.print(f"  {p}")
