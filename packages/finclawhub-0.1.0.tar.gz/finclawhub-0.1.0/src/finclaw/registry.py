"""
Remote registry — fetches skill metadata from:
  Primary:  FinSkillsHub skills.json  (full metadata: category, description_zh, evaluation…)
  Fallback: embedded minimal list (in case of no network)

Skill SKILL.md is fetched on-demand during install from:
  https://raw.githubusercontent.com/aifinlab/finclaw-skills/main/<id>/SKILL.md
"""
import json
import sys
from typing import Dict, List, Optional

import requests

# ── URLs ─────────────────────────────────────────────────────────────────────
_INDEX_URL = (
    "https://raw.githubusercontent.com/aifinlab/FinSkillsHub/main/src/data/skills.json"
)
_SKILL_MD_BASE = (
    "https://raw.githubusercontent.com/aifinlab/finclaw-skills/main"
)

_TIMEOUT = 10  # seconds


def fetch_index(silent: bool = False) -> List[dict]:
    """Return the list of all available skills from FinSkillsHub."""
    try:
        r = requests.get(_INDEX_URL, timeout=_TIMEOUT)
        r.raise_for_status()
        data = r.json()
        return data.get("skills", [])
    except Exception as exc:
        if not silent:
            from rich.console import Console
            Console(stderr=True).print(
                f"[yellow]⚠ 无法获取远程索引 ({exc})[/yellow]"
            )
        return []


def fetch_skill_md(skill_id: str) -> Optional[str]:
    """Download raw SKILL.md content for a skill. Returns None if not found."""
    url = f"{_SKILL_MD_BASE}/{skill_id}/SKILL.md"
    try:
        r = requests.get(url, timeout=_TIMEOUT)
        if r.status_code == 404:
            return None
        r.raise_for_status()
        return r.text
    except Exception:
        return None


def parse_skill_md_packages(skill_md: str) -> List[str]:
    """Extract pip package list from SKILL.md YAML frontmatter."""
    try:
        import yaml

        # Extract frontmatter block between --- delimiters
        lines = skill_md.splitlines()
        if not lines or lines[0].strip() != "---":
            return []
        end = next((i for i, l in enumerate(lines[1:], 1) if l.strip() == "---"), None)
        if end is None:
            return []
        frontmatter = yaml.safe_load("\n".join(lines[1:end]))
        install_steps = (
            frontmatter.get("metadata", {})
            .get("openclaw", {})
            .get("install", [])
        )
        packages: List[str] = []
        for step in install_steps:
            if step.get("kind") == "pip":
                packages.extend(step.get("packages", []))
        return packages
    except Exception:
        return []


def search(query: str, skills: List[dict]) -> List[dict]:
    """Simple substring search across id, name, description_zh, tags, category."""
    q = query.lower()
    results = []
    for s in skills:
        haystack = " ".join([
            s.get("id", ""),
            s.get("name", ""),
            s.get("description_zh", ""),
            s.get("description", ""),
            s.get("category", ""),
            " ".join(s.get("tags", [])),
        ]).lower()
        if q in haystack:
            results.append(s)
    return results


def get_by_id(skill_id: str, skills: List[dict]) -> Optional[dict]:
    return next((s for s in skills if s["id"] == skill_id), None)
