# finclaw — FinClaw Skills CLI

金融 AI Skills 安装器，配套 [FinSkillsHub](https://aifinlab.github.io/FinSkillsHub/) 使用。

## 安装

```bash
pip install finclaw
```

## 快速开始

```bash
# 安装一个 Skill
finclaw install akshare-stock

# 安装多个
finclaw install akshare-stock akshare-fund backtrader-skill factor-analysis

# 搜索 Skills
finclaw search 股票
finclaw search backtest

# 查看所有可用 Skills
finclaw list

# 查看已安装
finclaw list --installed

# 某个 Skill 的详细信息
finclaw info akshare-stock

# 更新所有已安装 Skills
finclaw update

# 卸载
finclaw uninstall akshare-stock

# 查看本地存储路径
finclaw path
```

## install 做了什么

以 `finclaw install akshare-stock` 为例：

1. 从 GitHub 下载 `akshare-stock/SKILL.md`
2. 解析 YAML frontmatter，提取 pip 依赖：`["akshare", "pandas", "requests"]`
3. 自动运行 `pip install akshare pandas requests`
4. 将 SKILL.md 存储到 `~/.finclaw/skills/akshare-stock/SKILL.md`
5. 更新 `~/.finclaw/installed.json` 注册表

## 与 AI Agent 集成

```bash
finclaw path
# 输出：/Users/你的用户名/.finclaw/skills
```

将该路径加入 AI Agent 配置（如 Claude Code 的 `CLAUDE.md`），Agent 即可读取已安装 Skills 的 SKILL.md。

## Skills 来源

| 来源 | 说明 |
|------|------|
| [finclaw-skills](https://github.com/aifinlab/finclaw-skills) | Skills 源码（SKILL.md + 脚本） |
| [FinSkillsHub](https://aifinlab.github.io/FinSkillsHub/) | Web 目录，可视化浏览所有 Skills |

## 许可证

Apache License 2.0 · © 上海财经大学张立文课题组
