from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *


@jsii.enum(jsii_type="@cdklabs/generative-ai-cdk-constructs.kendra.Kendra.Edition")
class Edition(enum.Enum):
    '''
    :deprecated: Use KendraEdition instead

    :stability: deprecated
    '''

    DEVELOPER_EDITION = "DEVELOPER_EDITION"
    '''
    :stability: deprecated
    '''
    ENTERPRISE_EDITION = "ENTERPRISE_EDITION"
    '''
    :stability: deprecated
    '''
    GEN_AI_ENTERPRISE_EDITION = "GEN_AI_ENTERPRISE_EDITION"
    '''
    :stability: deprecated
    '''


@jsii.enum(
    jsii_type="@cdklabs/generative-ai-cdk-constructs.kendra.Kendra.IndexFieldTypes"
)
class IndexFieldTypes(enum.Enum):
    '''
    :deprecated: Use KendraIndexFieldTypes instead

    :stability: deprecated
    '''

    STRING = "STRING"
    '''
    :stability: deprecated
    '''
    STRING_LIST = "STRING_LIST"
    '''
    :stability: deprecated
    '''
    LONG = "LONG"
    '''
    :stability: deprecated
    '''
    DATE = "DATE"
    '''
    :stability: deprecated
    '''


@jsii.enum(
    jsii_type="@cdklabs/generative-ai-cdk-constructs.kendra.Kendra.UserContextPolicy"
)
class UserContextPolicy(enum.Enum):
    '''
    :deprecated: Use KendraUserContextPolicy instead

    :stability: deprecated
    '''

    ATTRIBUTE_FILTER = "ATTRIBUTE_FILTER"
    '''
    :stability: deprecated
    '''
    USER_TOKEN = "USER_TOKEN"
    '''
    :stability: deprecated
    '''


__all__ = [
    "Edition",
    "IndexFieldTypes",
    "UserContextPolicy",
]

publication.publish()
