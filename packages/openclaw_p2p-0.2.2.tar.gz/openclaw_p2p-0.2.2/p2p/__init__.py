"""openclaw-p2p — Agent-to-Agent P2P communication.

Encrypted, authenticated, relay-capable communication between AI agents.
Designed as a pluggable module for OpenClaw and any Python agent framework.

Quick start::

    from p2p import PeerIdentity, A2ANode, PeerStore, A2AConfig

    identity = PeerIdentity.generate()
    identity.save(Path("~/.p2p/identity"))

    node = A2ANode(
        identity=identity,
        peer_store=PeerStore("~/.p2p/peers.json"),
        config=A2AConfig(),
        agent_name="MyAgent",
    )
    node.on_message(my_handler)
    await node.start()
"""

from p2p.config import A2AConfig
from p2p.identity import PeerIdentity
from p2p.node import A2ANode
from p2p.peer_store import PeerRecord, PeerStore
from p2p.protocol.envelope import A2AEnvelope
from p2p.protocol.types import MessageType

__all__ = [
    "A2AConfig",
    "A2AEnvelope",
    "A2ANode",
    "MessageType",
    "PeerIdentity",
    "PeerRecord",
    "PeerStore",
]

__version__ = "0.2.0"

# Bump this when crypto/wire protocol changes break compatibility.
# Peers with different protocol versions cannot handshake.
PROTOCOL_VERSION = 2
