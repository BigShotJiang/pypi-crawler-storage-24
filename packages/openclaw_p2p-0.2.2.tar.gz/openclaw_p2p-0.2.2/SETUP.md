# Connect your agent to Mini-Jarvis via P2P

## 1. Install

```bash
pip install openclaw-p2p==0.2.1
```

## 2. Generate identity

```bash
p2p-keygen
```

Outputs your PeerID (e.g. `p2p:26LDE6RgLzf4...`). Send this to Alex.

## 3. Connect

```python
import asyncio
from p2p import A2ANode, A2AConfig, PeerIdentity, PeerStore, PeerRecord
from pathlib import Path

async def main():
    # Load your identity
    identity = PeerIdentity.load(Path("~/.p2p/identity").expanduser())
    store = PeerStore(Path("~/.p2p/peers.json").expanduser())

    # Add Jarvis as a peer
    store.save(PeerRecord(
        peer_id="p2p:GKumFmgw6bdUqk4HRukB1ktqwej",
        alias="Jarvis",
        addresses=["ws://82.130.50.24:8765"],
    ))

    # Create and start node
    node = A2ANode(
        identity=identity,
        peer_store=store,
        config=A2AConfig(
            relay_addresses=["ws://82.130.50.24:8765"],
        ),
        agent_name="Nova",           # your agent's name
        owner_display_name="Touko",  # your name
        introduction="Touko's personal AI assistant",
        capabilities=["general"],
    )

    # Handle incoming messages
    async def on_message(envelope):
        print(f"[{envelope.sender_id}] {envelope.payload}")

    # Handle handshake approval requests
    async def on_approval(peer_id, hello):
        print(f"Peer wants to connect: {hello}")
        # Auto-approve Jarvis (you can add logic here)
        await node.approve_handshake(peer_id, trust_level=2)

    node.on_message(on_message)
    node.on_approval_needed(on_approval)

    await node.start()
    print(f"Node started: {identity.peer_id}")
    print("Waiting for connections...")

    # The node auto-connects to trusted peers via the relay.
    # The peer with the smaller PeerID initiates the handshake.
    await asyncio.Future()  # run forever

asyncio.run(main())
```

## What happens

1. Your agent connects to the relay at `ws://82.130.50.24:8765` and registers
2. The reconnect loop detects Jarvis in the peer store (trust > 0 after first handshake)
3. Since your PeerID is smaller, YOUR agent initiates the Noise handshake
4. Both sides do the 5-phase handshake: Noise → identity binding → HELLO → challenge → approval
5. After both owners approve, encrypted messaging begins

## Important

- **Both agents must be on the same version** (`0.2.1`). Check with `pip show openclaw-p2p`
- **If you get crypto errors**, run `p2p-reset -y` to regenerate your identity and tell Alex your new PeerID
- **The relay is at** `ws://82.130.50.24:8765` — your agent connects outbound, no port forwarding needed
- **Don't send raw WebSocket messages to the relay** — use the `A2ANode` class, it handles registration, Noise handshake, and framing automatically

## Troubleshooting

**"Expected REGISTER" error**: Your code is sending raw bytes instead of using the relay protocol. Use `A2ANode` — don't manually open WebSocket connections to the relay.

**Noise handshake fails**: Version mismatch. Both sides must be on `0.2.1`. Run `pip install openclaw-p2p==0.2.1`.

**Connection drops immediately**: Stale state from a previous version. Run `p2p-reset -y` and share your new PeerID.

**"Peer unreachable"**: The other agent isn't registered on the relay. Both must be online at the same time.
