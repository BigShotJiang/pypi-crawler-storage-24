"""
简易基准：大图 validate、批量 get_ready/mark_done 的耗时。
运行: python -m benchmarks.bench_scheduler
编译为 Cython 扩展后，热点路径（validate、mark_done 后继更新、stats）应有明显加速。
"""
import time
from topoqueue import DAGData, DAGQueue, Node


def make_chain(n: int):
    """链式 DAG: 0 -> 1 -> ... -> n-1"""
    nodes = [Node("0", deps=[])]
    for i in range(1, n):
        nodes.append(Node(str(i), deps=[str(i - 1)]))
    return {nd.node_id: nd for nd in nodes}


def main():
    n = 800
    print(f"节点数: {n} (链式 DAG)")

    # 构建 + validate
    data = DAGData(nodes=make_chain(n), metadata={})
    t0 = time.perf_counter()
    s = DAGQueue(data=data)
    s.validate()
    t1 = time.perf_counter()
    print(f"  构造 + validate: {t1 - t0:.3f}s")

    # 消费整图：get_ready + mark_done
    t0 = time.perf_counter()
    done = 0
    while not s.is_finished():
        try:
            node = s.get_ready(block=False)
            s.mark_done(node.node_id)
            done += 1
        except Exception:
            break
    t1 = time.perf_counter()
    print(f"  整图 get_ready+mark_done: {t1 - t0:.3f}s ({done} 节点)")

    # stats 多次
    s2 = DAGQueue(data=DAGData(nodes=make_chain(n), metadata={}))
    s2.validate()
    iters = 50
    t0 = time.perf_counter()
    for _ in range(iters):
        s2.stats()
    t1 = time.perf_counter()
    print(f"  stats() x{iters}: {t1 - t0:.3f}s")

    # invalidate 传播：整图 DONE 后 invalidate 根
    s3 = DAGQueue(data=DAGData(nodes=make_chain(n), metadata={}))
    s3.validate()
    while not s3.is_finished():
        try:
            node = s3.get_ready(block=False)
            s3.mark_done(node.node_id)
        except Exception:
            break
    t0 = time.perf_counter()
    s3.invalidate("0")
    t1 = time.perf_counter()
    print(f"  invalidate(根) 传播: {t1 - t0:.3f}s (期望 O(n))")


if __name__ == "__main__":
    main()
