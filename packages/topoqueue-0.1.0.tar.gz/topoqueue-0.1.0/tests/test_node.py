import pytest
from topoqueue.node import Node
from topoqueue.state import State


def test_node_required_fields():
    n = Node(node_id="a", deps=[])
    assert n.node_id == "a"
    assert n.deps == ()
    assert n.priority == 0
    assert n.state == State.PENDING


def test_node_with_deps_and_priority():
    n = Node(node_id="b", deps=["a"], priority=1)
    assert n.deps == ("a",)
    assert n.priority == 1


def test_node_deps_frozen_as_tuple():
    n = Node(node_id="x", deps=["a", "b"])
    assert isinstance(n.deps, tuple)
    assert n.deps == ("a", "b")


def test_node_kwargs_stored():
    n = Node(node_id="c", deps=[], payload="work", worker_tag="w1")
    assert getattr(n, "payload") == "work"
    assert getattr(n, "worker_tag") == "w1"


def test_node_to_dict_contains_metadata():
    n = Node(node_id="x", deps=["y"], priority=2)
    d = n.to_dict()
    assert d["node_id"] == "x"
    assert d["deps"] == ["y"]
    assert d["priority"] == 2
    assert "state" in d
    assert d["max_retries"] == 0
    assert d["attempts"] == 0


def test_node_max_retries_and_attempts():
    n = Node("a", deps=[], max_retries=2)
    assert n.max_retries == 2
    assert n.attempts == 0
    assert n.payload is None
