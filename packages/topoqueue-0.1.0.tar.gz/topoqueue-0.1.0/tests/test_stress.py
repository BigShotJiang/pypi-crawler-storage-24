"""压力测试：大图、深 DAG、多线程并发跑满直到结束。"""
import queue
import threading
import time
import pytest
from topoqueue import DAGData, DAGQueue, Node, State


def _make_chain(n: int) -> list[Node]:
    nodes = [Node("0", deps=[])]
    for i in range(1, n):
        nodes.append(Node(str(i), deps=[str(i - 1)]))
    return nodes


def _make_fanout_fanin(width: int, depth: int) -> list[Node]:
    """width 个链，每条 depth 层，最后汇到一个 sink。"""
    nodes = []
    for w in range(width):
        nodes.append(Node(f"w{w}_0", deps=[]))
        for d in range(1, depth):
            nodes.append(Node(f"w{w}_{d}", deps=[f"w{w}_{d-1}"]))
    # sink 依赖所有链的最后一层
    last_layer = [f"w{w}_{depth-1}" for w in range(width)]
    nodes.append(Node("sink", deps=last_layer))
    return nodes


def test_stress_large_chain_add_nodes_validate():
    """大链：200 节点，add_nodes 后一次 validate，跑完。"""
    n = 200
    nodes = _make_chain(n)
    s = DAGQueue()
    s.add_nodes(nodes)
    assert s.validate() is True
    done = 0
    while not s.is_finished():
        try:
            node = s.get_ready(block=False)
            s.mark_done(node.node_id)
            done += 1
        except queue.Empty:
            break
    assert done == n
    assert s.is_finished()


def test_stress_deep_chain_from_data():
    """深链：150 节点从 DAGData 初始化，跑完。"""
    n = 150
    nodes_list = _make_chain(n)
    data = DAGData(nodes={nd.node_id: nd for nd in nodes_list}, metadata={})
    s = DAGQueue(data=data)
    assert s.validate() is True
    done = 0
    while not s.is_finished():
        try:
            node = s.get_ready(block=False)
            s.mark_done(node.node_id)
            done += 1
        except queue.Empty:
            break
    assert done == n


def test_stress_fanout_fanin():
    """扇出扇入：多条链汇到 sink，add_nodes + 跑完。"""
    nodes_list = _make_fanout_fanin(width=10, depth=8)  # 10*8 + 1 = 81
    s = DAGQueue()
    s.add_nodes(nodes_list)
    assert s.validate() is True
    done = 0
    while not s.is_finished():
        try:
            node = s.get_ready(block=False)
            s.mark_done(node.node_id)
            done += 1
        except queue.Empty:
            break
    assert done == len(nodes_list)
    assert s.is_finished()


def test_stress_concurrent_workers():
    """多线程并发：较大 DAG，多 worker 同时 get_ready/mark_done 直到结束。"""
    n = 300
    nodes_list = _make_chain(n)
    data = DAGData(nodes={nd.node_id: nd for nd in nodes_list}, metadata={})
    s = DAGQueue(data=data)
    done_list = []

    def worker():
        local = 0
        while True:
            try:
                node = s.get_ready(block=True, timeout=2.0)
                s.mark_done(node.node_id)
                local += 1
            except queue.Empty:
                break
        done_list.append(local)

    threads = [threading.Thread(target=worker) for _ in range(4)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=15.0)
        assert not t.is_alive(), "worker did not finish in time"
    assert sum(done_list) == n
    assert s.is_finished()


def test_stress_join_wakes_quickly():
    """join 在完成后应被 Condition 快速唤醒（非轮询）。"""
    nodes_list = _make_chain(50)
    data = DAGData(nodes={nd.node_id: nd for nd in nodes_list}, metadata={})
    s = DAGQueue(data=data)
    result = [None]

    def runner():
        while not s.is_finished():
            try:
                node = s.get_ready(block=False)
                s.mark_done(node.node_id)
            except queue.Empty:
                time.sleep(0.001)
        result[0] = s.join(timeout=1.0)

    t = threading.Thread(target=runner)
    t.start()
    t.join(timeout=10.0)
    assert t.is_alive() is False, "runner did not finish in time"
    assert result[0] is True
