import pytest
from topoqueue.snapshot import SnapshotData


def test_snapshot_data_has_metadata_and_nodes():
    data = SnapshotData(metadata={"v": 1}, nodes={})
    assert data.metadata == {"v": 1}
    assert data.nodes == {}


def test_dag_queue_snapshot_returns_snapshot_data():
    from topoqueue import DAGData, DAGQueue, Node, State, SnapshotData
    data = DAGData(nodes={"a": Node("a", deps=[])}, metadata={"k": "v"})
    q = DAGQueue(data=data)
    snap = q.snapshot()
    assert isinstance(snap, SnapshotData)
    assert snap.metadata == {"k": "v"}
    assert "a" in snap.nodes
    assert snap.nodes["a"]["state"] == State.READY.value


def test_restore_after_snapshot_preserves_state():
    from topoqueue import DAGData, DAGQueue, Node, State, SnapshotData
    data = DAGData(nodes={"a": Node("a", deps=[]), "b": Node("b", deps=["a"])}, metadata={})
    q = DAGQueue(data=data)
    q.get_ready(block=False)
    q.mark_done("a")
    snap = q.snapshot()
    q2 = DAGQueue()
    q2.restore(snap)
    assert q2._nodes["a"].state == State.DONE
    assert q2._nodes["b"].state == State.PENDING


def test_restore_raises_on_missing_deps():
    from topoqueue import DAGQueue, SnapshotData
    q = DAGQueue()
    data = SnapshotData(metadata={}, nodes={"a": {"node_id": "a", "state": "pending"}})
    with pytest.raises(ValueError) as exc_info:
        q.restore(data)
    assert "deps" in str(exc_info.value).lower()


def test_restore_raises_on_invalid_state():
    from topoqueue import DAGQueue, SnapshotData
    q = DAGQueue()
    data = SnapshotData(metadata={}, nodes={"a": {"node_id": "a", "deps": [], "state": "invalid"}})
    with pytest.raises(ValueError) as exc_info:
        q.restore(data)
    assert "state" in str(exc_info.value).lower()


def test_restore_running_node_can_be_marked_done():
    from topoqueue import DAGQueue, SnapshotData, State

    q = DAGQueue()
    snap = SnapshotData(
        metadata={},
        nodes={"a": {"node_id": "a", "deps": [], "state": State.RUNNING.value}},
    )
    q.restore(snap)
    q.mark_done("a")
    assert q._nodes["a"].state == State.DONE
