import queue
import pytest
from topoqueue import DAGData, DAGQueue, Node, State


def test_mark_done_rejected_after_generation_bump():
    """After invalidate or cancel, mark_done for that node must raise."""
    data = DAGData(nodes={"a": Node("a", deps=[]), "b": Node("b", deps=[])}, metadata={})
    q = DAGQueue(data=data)
    node = q.get_ready(block=False)
    assert node.node_id == "a"
    q.invalidate("b")  # bump generation (b was READY -> PENDING)
    with pytest.raises(ValueError) as exc_info:
        q.mark_done("a")
    assert "invalidated" in str(exc_info.value).lower() or "canceled" in str(exc_info.value).lower()


def test_invalidate_running_raises():
    data = DAGData(nodes={"a": Node("a", deps=[])}, metadata={})
    q = DAGQueue(data=data)
    q.get_ready(block=False)
    with pytest.raises(ValueError) as exc_info:
        q.invalidate("a")
    assert "running" in str(exc_info.value).lower()


def test_invalidate_propagates_downstream():
    data = DAGData(nodes={
        "a": Node("a", deps=[]),
        "b": Node("b", deps=["a"]),
        "c": Node("c", deps=["b"]),
    }, metadata={})
    q = DAGQueue(data=data)
    q.get_ready(block=False)
    q.mark_done("a")
    q.get_ready(block=False)
    q.mark_done("b")
    q.get_ready(block=False)
    q.mark_done("c")
    assert q.stats()["done"] == 3
    q.invalidate("a")
    assert q._nodes["a"].state == State.READY
    assert q._nodes["b"].state == State.DIRTY
    assert q._nodes["c"].state == State.DIRTY


def test_get_ready_skips_invalidated_ready_node():
    data = DAGData(nodes={"a": Node("a", deps=[]), "b": Node("b", deps=[])}, metadata={})
    q = DAGQueue(data=data)
    n = q.get_ready(block=False)
    other = "b" if n.node_id == "a" else "a"
    q.mark_done(n.node_id)
    q.invalidate(other)
    with pytest.raises(queue.Empty):
        q.get_ready(block=False)


def test_cancel_running_sets_canceled():
    data = DAGData(nodes={"a": Node("a", deps=[])}, metadata={})
    q = DAGQueue(data=data)
    q.get_ready(block=False)
    q.cancel("a")
    assert q._nodes["a"].state == State.CANCELED
    with pytest.raises(ValueError):
        q.mark_done("a")


def test_cancel_cascade_downstream():
    data = DAGData(nodes={"a": Node("a", deps=[]), "b": Node("b", deps=["a"])}, metadata={})
    q = DAGQueue(data=data)
    q.get_ready(block=False)
    q.mark_done("a")
    q.get_ready(block=False)
    q.cancel("b", cascade=True)
    assert q._nodes["b"].state == State.CANCELED


def test_mark_failed_rejected_after_cancel():
    data = DAGData(nodes={"a": Node("a", deps=[])}, metadata={})
    q = DAGQueue(data=data)
    q.get_ready(block=False)
    q.cancel("a")
    with pytest.raises(ValueError):
        q.mark_failed("a")


def test_invalidate_dirty_root_becomes_ready():
    data = DAGData(nodes={"a": Node("a", deps=[])}, metadata={})
    q = DAGQueue(data=data)
    q.get_ready(block=False)
    q.mark_done("a")
    q.invalidate("a")
    assert q._nodes["a"].state == State.READY
    node = q.get_ready(block=False)
    assert node.node_id == "a"
    assert node.state == State.RUNNING


def test_invalidate_leaf_only_affects_leaf():
    """Invalidate leaf only: leaf becomes DIRTY, upstream stay DONE."""
    data = DAGData(nodes={
        "a": Node("a", deps=[]),
        "b": Node("b", deps=["a"]),
        "c": Node("c", deps=["b"]),
    }, metadata={})
    q = DAGQueue(data=data)
    for _ in range(3):
        n = q.get_ready(block=False)
        q.mark_done(n.node_id)
    assert q.stats()["done"] == 3
    q.invalidate("c")
    assert q._nodes["a"].state == State.DONE
    assert q._nodes["b"].state == State.DONE
    assert q._nodes["c"].state == State.READY


def test_retry_with_invalidation():
    """After invalidation, invalidated subgraph can be re-run to completion."""
    data = DAGData(nodes={
        "a": Node("a", deps=[]),
        "b": Node("b", deps=["a"]),
    }, metadata={})
    q = DAGQueue(data=data)
    q.get_ready(block=False)
    q.mark_done("a")
    q.get_ready(block=False)
    q.mark_done("b")
    assert q.stats()["done"] == 2
    q.invalidate("a")
    assert q._nodes["a"].state == State.READY
    assert q._nodes["b"].state == State.DIRTY
    q.get_ready(block=False)
    q.mark_done("a")
    q.get_ready(block=False)
    q.mark_done("b")
    assert q.stats()["done"] == 2
