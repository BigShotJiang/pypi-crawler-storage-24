import pytest
from topoqueue.state import State


def test_state_has_required_values():
    assert State.PENDING is not None
    assert State.READY is not None
    assert State.RUNNING is not None
    assert State.DONE is not None
    assert State.FAILED is not None
    assert State.CANCELED is not None


def test_state_has_dirty():
    assert State.DIRTY is not None
    assert State.DIRTY.value == "dirty"


def test_state_ordering_or_names():
    names = [s.name for s in State]
    assert "PENDING" in names
    assert "DONE" in names
