"""Tests for execution log events and DAGQueue event_sink."""
import pytest
from topoqueue import DAGQueue, DAGData, Node
from topoqueue.events import node_started, node_done, node_failed, node_invalidated, dag_merged


def test_event_sink_node_started_and_done():
    events = []
    data = DAGData(nodes={"a": Node("a", deps=[])}, metadata={})
    q = DAGQueue(data=data, event_sink=events.append)
    n = q.get_ready(block=False)
    assert events[-1] == node_started("a")
    q.mark_done("a", result="ok")
    assert events[-1] == node_done("a")


def test_event_sink_node_failed():
    events = []
    data = DAGData(nodes={"a": Node("a", deps=[], max_retries=0)}, metadata={})
    q = DAGQueue(data=data, event_sink=events.append)
    q.get_ready(block=False)
    q.mark_failed("a")
    assert any(e == node_failed("a") for e in events)


def test_event_sink_node_invalidated():
    events = []
    data = DAGData(nodes={"a": Node("a", deps=[]), "b": Node("b", deps=["a"])}, metadata={})
    q = DAGQueue(data=data, event_sink=events.append)
    q.get_ready(block=False)
    q.mark_done("a", result=1)
    q.get_ready(block=False)
    q.mark_done("b", result=2)
    q.invalidate("a")
    inv_events = [e for e in events if getattr(e, "kind", None) == "node_invalidated"]
    assert set(e.node_id for e in inv_events) == {"a", "b"}
