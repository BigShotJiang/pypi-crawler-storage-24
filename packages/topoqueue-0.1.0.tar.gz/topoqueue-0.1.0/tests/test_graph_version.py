"""Tests for graph_version and dag_merged event."""
import pytest
from topoqueue import DAGQueue, DAGData, Node
from topoqueue.events import dag_merged


def test_graph_version_starts_zero():
    q = DAGQueue(data=DAGData(nodes={"a": Node("a", deps=[])}, metadata={}))
    assert q.graph_version == 0


def test_graph_version_increments_on_merge():
    q = DAGQueue(data=DAGData(nodes={"a": Node("a", deps=[])}, metadata={}))
    assert q.graph_version == 0
    q.merge_dag(
        DAGData(nodes={"a": Node("a", deps=[]), "b": Node("b", deps=["a"])}, metadata={}),
        overwrite=True,
    )
    assert q.graph_version == 1


def test_dag_merged_event():
    events = []
    q = DAGQueue(
        data=DAGData(nodes={"a": Node("a", deps=[])}, metadata={}),
        event_sink=events.append,
    )
    q.merge_dag(
        DAGData(nodes={"a": Node("a", deps=[]), "b": Node("b", deps=["a"])}, metadata={}),
        overwrite=True,
    )
    assert any(
        getattr(e, "kind", None) == "dag_merged" and getattr(e, "graph_version", None) == 1
        for e in events
    )


def test_created_in_version_set_on_add():
    q = DAGQueue()
    n = Node("x", deps=[])
    q.add_node(n)
    assert getattr(n, "created_in_version", None) == 0


def test_created_in_version_restored_from_snapshot():
    q = DAGQueue(data=DAGData(nodes={"a": Node("a", deps=[])}, metadata={}))
    snap = q.snapshot()
    q2 = DAGQueue()
    q2.restore(snap)
    assert getattr(q2._nodes["a"], "created_in_version", None) == 0
