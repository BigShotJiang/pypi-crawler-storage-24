import pytest
from topoqueue.node import Node
from topoqueue.policy import DefaultQueuePolicy, QueueContext, QueuePolicy


def test_default_policy_priority_then_out_degree():
    nodes = {
        "a": Node("a", deps=[]),
        "b": Node("b", deps=[]),
        "c": Node("c", deps=["b"]),
    }
    out_edges = {"a": [], "b": ["c"], "c": []}
    ctx = QueueContext(nodes, out_edges)
    policy = DefaultQueuePolicy()
    # a out_degree 0, b out_degree 1 -> b should have smaller score (higher priority)
    sa = policy.score(nodes["a"], ctx)
    sb = policy.score(nodes["b"], ctx)
    assert sa == (0, 0)
    assert sb == (0, -1)
    assert sb < sa


def test_default_policy_higher_priority_first():
    nodes = {"a": Node("a", deps=[], priority=1), "b": Node("b", deps=[], priority=0)}
    out_edges = {"a": [], "b": []}
    ctx = QueueContext(nodes, out_edges)
    policy = DefaultQueuePolicy()
    assert policy.score(nodes["a"], ctx) < policy.score(nodes["b"], ctx)


def test_custom_policy_fifo():
    """FIFO 可用固定 score，出队顺序依赖入队顺序（同 score 时 nid 作为 tie-break）。"""

    class FIFOPolicy(QueuePolicy):
        def score(self, node: Node, context: QueueContext) -> int:
            return 0

    nodes = {"a": Node("a", deps=[]), "b": Node("b", deps=[])}
    ctx = QueueContext(nodes, {})
    policy = FIFOPolicy()
    assert policy.score(nodes["a"], ctx) == policy.score(nodes["b"], ctx) == 0
