"""Phase 2: merge_dag diff and invalidate affected nodes."""
import pytest
from topoqueue import DAGData, DAGQueue, Node, State


def test_merge_insert_node_between_invalidates_downstream():
    """Case A: old A->B, new A->C->B; B should be invalidated."""
    data = DAGData(
        nodes={
            "a": Node("a", deps=[]),
            "b": Node("b", deps=["a"]),
        },
        metadata={},
    )
    q = DAGQueue(data=data)
    q.get_ready(block=False)
    q.mark_done("a")
    q.get_ready(block=False)
    q.mark_done("b")
    assert q._nodes["b"].state == State.DONE
    new_data = DAGData(
        nodes={
            "a": Node("a", deps=[]),
            "c": Node("c", deps=["a"]),
            "b": Node("b", deps=["c"]),
        },
        metadata={},
    )
    q.merge_dag(new_data, overwrite=True)
    assert q._nodes["b"].state in (State.DIRTY, State.PENDING)
    assert "c" in q._nodes


def test_merge_replace_dep_invalidates_node():
    """Case B: old A->B, new C->B; B should be invalidated."""
    data = DAGData(
        nodes={
            "a": Node("a", deps=[]),
            "b": Node("b", deps=["a"]),
        },
        metadata={},
    )
    q = DAGQueue(data=data)
    q.get_ready(block=False)
    q.mark_done("a")
    q.get_ready(block=False)
    q.mark_done("b")
    new_data = DAGData(
        nodes={
            "c": Node("c", deps=[]),
            "b": Node("b", deps=["c"]),
        },
        metadata={},
    )
    q.merge_dag(new_data, overwrite=True)
    assert q._nodes["b"].state in (State.DIRTY, State.PENDING)


def test_merge_removed_node_kept_as_orphan():
    """Case C: old has A,B; new has only B; A kept in _nodes but not in active graph."""
    data = DAGData(
        nodes={
            "a": Node("a", deps=[]),
            "b": Node("b", deps=["a"]),
        },
        metadata={},
    )
    q = DAGQueue(data=data)
    new_data = DAGData(nodes={"b": Node("b", deps=[])}, metadata={})
    q.merge_dag(new_data, overwrite=True)
    assert "a" in q._nodes
    assert "b" in q._nodes
    assert q._nodes["b"].deps == ()
    q.validate(strict=False)


def test_merge_priority_change_invalidates_node():
    """Structural detection: same deps but priority changed -> node invalidated."""
    data = DAGData(
        nodes={"a": Node("a", deps=[], priority=0), "b": Node("b", deps=["a"], priority=0)},
        metadata={},
    )
    q = DAGQueue(data=data)
    q.get_ready(block=False)
    q.mark_done("a")
    q.get_ready(block=False)
    q.mark_done("b")
    assert q._nodes["b"].state == State.DONE
    new_data = DAGData(
        nodes={"a": Node("a", deps=[], priority=0), "b": Node("b", deps=["a"], priority=10)},
        metadata={},
    )
    q.merge_dag(new_data, overwrite=True)
    assert q._nodes["b"].state in (State.DIRTY, State.PENDING)
