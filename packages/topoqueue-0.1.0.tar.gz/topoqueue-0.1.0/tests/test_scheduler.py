import queue
import warnings
import pytest
from topoqueue import DAGData, DAGQueue, Node, State


def test_scheduler_init_empty():
    s = DAGQueue()
    assert s is not None
    # 空图无节点，validate 通过
    assert s.validate() is True


def test_scheduler_init_with_data_ready_enqueued():
    a = Node(node_id="a", deps=[])
    b = Node(node_id="b", deps=["a"])
    data = DAGData(nodes={"a": a, "b": b}, metadata={})
    s = DAGQueue(data=data)
    assert a.state == State.READY
    assert b.state == State.PENDING


def test_scheduler_validate_acyclic_returns_true():
    data = DAGData(nodes={
        "a": Node("a", deps=[]),
        "b": Node("b", deps=["a"]),
    }, metadata={})
    s = DAGQueue(data=data)
    assert s.validate() is True


def test_scheduler_validate_cycle_raises():
    # a -> b -> a
    data = DAGData(nodes={
        "a": Node("a", deps=["b"]),
        "b": Node("b", deps=["a"]),
    }, metadata={})
    s = DAGQueue(data=data)
    with pytest.raises(Exception):  # ValueError or similar
        s.validate()


def test_scheduler_validate_orphan_raises_by_default():
    # b 依赖 c，但 c 不在 nodes 里；strict=True 时应抛 ValueError
    data = DAGData(nodes={
        "a": Node("a", deps=[]),
        "b": Node("b", deps=["c"]),  # c 不存在
    }, metadata={})
    s = DAGQueue(data=data)
    with pytest.raises(ValueError) as exc_info:
        s.validate()
    assert "orphan" in str(exc_info.value).lower() or "c" in str(exc_info.value).lower()


def test_scheduler_validate_orphan_warns_when_strict_false():
    # strict=False 时孤儿依赖仅发警告
    data = DAGData(nodes={
        "a": Node("a", deps=[]),
        "b": Node("b", deps=["c"]),
    }, metadata={})
    s = DAGQueue(data=data)
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        result = s.validate(strict=False)
        assert result is True
        assert len(w) >= 1
        assert "orphan" in str(w[0].message).lower() or "c" in str(w[0].message).lower()


# --- Task 5: add_node, merge_dag ---


def test_add_node_no_deps_becomes_ready():
    s = DAGQueue()
    n = Node("a", deps=[])
    s.add_node(n)
    assert n.state == State.READY


def test_add_node_with_existing_deps_stays_pending():
    s = DAGQueue()
    a = Node("a", deps=[])
    s.add_node(a)
    b = Node("b", deps=["a"])
    s.add_node(b)
    assert a.state == State.READY
    assert b.state == State.PENDING


def test_add_node_missing_dep_raises():
    s = DAGQueue()
    n = Node("b", deps=["a"])  # a 不存在
    with pytest.raises(ValueError):
        s.add_node(n)


def test_add_node_duplicate_id_raises():
    s = DAGQueue()
    s.add_node(Node("a", deps=[]))
    with pytest.raises(ValueError) as exc_info:
        s.add_node(Node("a", deps=[]))
    assert "already exists" in str(exc_info.value)


def test_add_node_overwrite_true_replaces():
    s = DAGQueue()
    s.add_node(Node("a", deps=[]))
    s.add_node(Node("a", deps=[]), overwrite=True)
    assert s.validate() is True
    node = s.get_ready(block=False)
    assert node.node_id == "a"
    s.mark_done("a")
    assert s.is_finished()


def test_add_nodes_batch_single_validate():
    s = DAGQueue()
    a = Node("a", deps=[])
    b = Node("b", deps=["a"])
    c = Node("c", deps=["b"])
    s.add_nodes([a, b, c])
    assert s.validate() is True
    assert a.state == State.READY
    assert b.state == State.PENDING
    assert c.state == State.PENDING
    node = s.get_ready(block=False)
    assert node.node_id == "a"
    s.mark_done("a")
    node = s.get_ready(block=False)
    assert node.node_id == "b"


def test_merge_dag_id_conflict_no_overwrite_raises():
    data = DAGData(nodes={"a": Node("a", deps=[])}, metadata={})
    s = DAGQueue(data=data)
    new_data = DAGData(nodes={"a": Node("a", deps=[])}, metadata={})
    with pytest.raises(ValueError):
        s.merge_dag(new_data, overwrite=False)


def test_merge_dag_overwrite_true_and_validate():
    data = DAGData(nodes={"a": Node("a", deps=[])}, metadata={})
    s = DAGQueue(data=data)
    new_data = DAGData(nodes={"a": Node("a", deps=[]), "b": Node("b", deps=["a"])}, metadata={})
    s.merge_dag(new_data, overwrite=True)
    assert s.validate() is True


# --- Task 6: get_ready ---


def test_get_ready_returns_node_and_marks_running():
    data = DAGData(nodes={"a": Node("a", deps=[])}, metadata={})
    s = DAGQueue(data=data)
    node = s.get_ready(block=False)
    assert node is not None
    assert node.node_id == "a"
    assert node.state == State.RUNNING


def test_get_ready_empty_raises():
    s = DAGQueue()
    with pytest.raises(queue.Empty):
        s.get_ready(block=False)


def test_get_ready_priority_then_out_degree():
    # a(priority=0) 和 b(priority=0)，b 出度更大则 b 先出队（DefaultQueuePolicy）
    data = DAGData(nodes={
        "a": Node("a", deps=[]),
        "b": Node("b", deps=[]),
        "c": Node("c", deps=["b"]),  # b 出度 1，a 出度 0
    }, metadata={})
    s = DAGQueue(data=data)
    first = s.get_ready(block=False)
    # 同 priority 时出度大者优先 -> b 先
    assert first.node_id == "b"


def test_get_ready_same_priority_same_out_degree_deterministic_no_crash():
    """默认策略下，优先级与出度均相同时：不崩溃，且按 node_id 确定顺序（key 为 (score, nid)）。"""
    data = DAGData(nodes={
        "a": Node("a", deps=[], priority=0),
        "b": Node("b", deps=[], priority=0),
    }, metadata={})
    s = DAGQueue(data=data)
    out = []
    out.append(s.get_ready(block=False).node_id)
    out.append(s.get_ready(block=False).node_id)
    assert set(out) == {"a", "b"}
    # 入队 key 为 (score, nid)，score 相同则按 nid 比较，故先 "a" 后 "b"
    assert out[0] == "a" and out[1] == "b"


def test_scheduler_with_custom_policy():
    from topoqueue.policy import QueuePolicy, QueueContext

    class LowPriorityFirst(QueuePolicy):
        """priority 小者先出队（与默认相反）。"""
        def score(self, node, context):
            return (node.priority, 0)  # 小 priority 先

    data = DAGData(nodes={
        "a": Node("a", deps=[], priority=2),
        "b": Node("b", deps=[], priority=0),
    }, metadata={})
    s = DAGQueue(data=data, policy=LowPriorityFirst())
    first = s.get_ready(block=False)
    assert first.node_id == "b"


# --- Task 7: mark_done ---


def test_mark_done_sets_done_and_enqueues_successors():
    data = DAGData(nodes={
        "a": Node("a", deps=[]),
        "b": Node("b", deps=["a"]),
    }, metadata={})
    s = DAGQueue(data=data)
    node_a = s.get_ready(block=False)
    assert node_a.node_id == "a"
    s.mark_done("a")
    assert data.nodes["a"].state == State.DONE
    node_b = s.get_ready(block=False)
    assert node_b.node_id == "b"


def test_mark_done_stores_result_kwargs():
    data = DAGData(nodes={"a": Node("a", deps=[])}, metadata={})
    s = DAGQueue(data=data)
    s.get_ready(block=False)
    s.mark_done("a", result=42, status="ok")
    assert getattr(data.nodes["a"], "result") == 42
    assert getattr(data.nodes["a"], "status") == "ok"


# --- Task 8: mark_failed + cascade ---


def test_mark_failed_sets_failed():
    data = DAGData(nodes={"a": Node("a", deps=[]), "b": Node("b", deps=["a"])}, metadata={})
    s = DAGQueue(data=data)
    s.get_ready(block=False)
    s.mark_failed("a")
    assert data.nodes["a"].state == State.FAILED
    assert data.nodes["b"].state == State.PENDING


def test_mark_failed_cascade_cancels_downstream():
    data = DAGData(nodes={
        "a": Node("a", deps=[]),
        "b": Node("b", deps=["a"]),
        "c": Node("c", deps=["b"]),
    }, metadata={})
    s = DAGQueue(data=data)
    s.get_ready(block=False)
    s.mark_failed("a", cascade=True)
    assert data.nodes["a"].state == State.FAILED
    assert data.nodes["b"].state == State.CANCELED
    assert data.nodes["c"].state == State.CANCELED


def test_mark_failed_retry_re_enqueues_when_attempts_lt_max_retries():
    data = DAGData(nodes={"a": Node("a", deps=[], max_retries=2)}, metadata={})
    s = DAGQueue(data=data)
    node = s.get_ready(block=False)
    s.mark_failed("a")  # attempts 0 -> 1, re-enqueue READY
    assert data.nodes["a"].state == State.READY
    assert data.nodes["a"].attempts == 1
    node2 = s.get_ready(block=False)
    assert node2.node_id == "a"
    s.mark_failed("a")  # attempts 1 -> 2, re-enqueue
    assert data.nodes["a"].attempts == 2
    node3 = s.get_ready(block=False)
    s.mark_failed("a")  # attempts 2 >= max_retries 2 -> FAILED
    assert data.nodes["a"].state == State.FAILED
    assert data.nodes["a"].attempts == 2


def test_mark_failed_no_retry_when_max_retries_zero():
    data = DAGData(nodes={"a": Node("a", deps=[], max_retries=0)}, metadata={})
    s = DAGQueue(data=data)
    s.get_ready(block=False)
    s.mark_failed("a")
    assert data.nodes["a"].state == State.FAILED
    assert data.nodes["a"].attempts == 0


# --- Task 9: is_finished, join ---


def test_is_finished_when_all_done():
    data = DAGData(nodes={"a": Node("a", deps=[])}, metadata={})
    s = DAGQueue(data=data)
    assert s.is_finished() is False
    s.get_ready(block=False)
    s.mark_done("a")
    assert s.is_finished() is True


def test_join_returns_when_finished():
    data = DAGData(nodes={"a": Node("a", deps=[])}, metadata={})
    s = DAGQueue(data=data)
    s.get_ready(block=False)
    s.mark_done("a")
    result = s.join(timeout=1.0)
    assert result is True


def test_is_finished_true_when_deadlock_dag():
    # a FAILED 未 cascade，b 永远 PENDING，应视为结束
    data = DAGData(nodes={
        "a": Node("a", deps=[]),
        "b": Node("b", deps=["a"]),
    }, metadata={})
    s = DAGQueue(data=data)
    s.get_ready(block=False)
    s.mark_failed("a")  # 不 cascade
    assert data.nodes["a"].state == State.FAILED
    assert data.nodes["b"].state == State.PENDING
    assert s.is_finished() is True


def test_stats_counts_and_blocked():
    data = DAGData(nodes={
        "a": Node("a", deps=[]),
        "b": Node("b", deps=["a"]),
        "c": Node("c", deps=["b"]),
    }, metadata={})
    s = DAGQueue(data=data)
    st = s.stats()
    assert st["ready"] == 1
    assert st["pending"] == 2
    assert st["blocked"] == 0
    s.get_ready(block=False)
    s.mark_failed("a")  # b,c 永远 PENDING，b 依赖 a(FAILED) 故 blocked
    st = s.stats()
    assert st["failed"] == 1
    assert st["pending"] == 2
    assert st["blocked"] == 2  # b 和 c 都有 FAILED 祖先 a


# --- Task 10: concurrency ---


def test_concurrent_get_ready_mark_done_no_deadlock():
    data = DAGData(nodes={
        "a": Node("a", deps=[]),
        "b": Node("b", deps=[]),
        "c": Node("c", deps=["a", "b"]),
    }, metadata={})
    s = DAGQueue(data=data)
    done = []

    def worker():
        while True:
            try:
                node = s.get_ready(block=False)
                done.append(node.node_id)
                s.mark_done(node.node_id)
            except queue.Empty:
                break

    import threading
    t1 = threading.Thread(target=worker)
    t2 = threading.Thread(target=worker)
    t1.start()
    t2.start()
    t1.join(timeout=2.0)
    t2.join(timeout=2.0)
    assert t1.is_alive() is False and t2.is_alive() is False
    assert s.is_finished()
    assert set(done) == {"a", "b", "c"}
