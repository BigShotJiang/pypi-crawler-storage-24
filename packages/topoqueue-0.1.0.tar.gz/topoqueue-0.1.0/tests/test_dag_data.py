import pytest
from topoqueue.dag_data import DAGData
from topoqueue.node import Node
from topoqueue.state import State


def test_dag_data_empty():
    d = DAGData(nodes={}, metadata={})
    assert d.nodes == {}
    assert d.metadata == {}


def test_dag_data_with_nodes():
    n = Node(node_id="a", deps=[])
    d = DAGData(nodes={"a": n}, metadata={"version": 1})
    assert d.nodes["a"] is n
    assert d.metadata["version"] == 1


def test_dag_data_to_json_roundtrip():
    n = Node(node_id="x", deps=["y"], priority=1)
    n.state = State.READY
    data = DAGData(nodes={"x": n, "y": Node(node_id="y", deps=[])}, metadata={"v": 1})
    s = data.to_json()
    assert isinstance(s, str)
    restored = DAGData.from_json(s)
    assert list(restored.nodes.keys()) == ["x", "y"]
    assert restored.nodes["x"].node_id == "x"
    assert restored.nodes["x"].deps == ("y",)
    assert restored.nodes["x"].priority == 1
    assert restored.nodes["x"].state == State.READY
    assert restored.metadata == {"v": 1}


def test_dag_data_roundtrip_includes_dirty_state():
    from topoqueue import DAGData, Node, State
    a = Node("a", deps=[], state=State.DIRTY)
    data = DAGData(nodes={"a": a}, metadata={})
    j = data.to_json()
    data2 = DAGData.from_json(j)
    assert data2.nodes["a"].state == State.DIRTY
