"""Tests for ResultStore protocol and DAGQueue integration."""
import pytest
from topoqueue import DAGQueue, DAGData, Node, State
from topoqueue.result_store import ResultStore


class RecordingResultStore:
    def __init__(self):
        self.saves = []
        self.invalidates = []

    def load(self, node_id: str):
        return None

    def save(self, node_id: str, result) -> None:
        self.saves.append((node_id, result))

    def invalidate(self, node_id: str) -> None:
        self.invalidates.append(node_id)


def test_result_store_save_called_on_mark_done():
    store = RecordingResultStore()
    data = DAGData(nodes={"a": Node("a", deps=[])}, metadata={})
    q = DAGQueue(data=data, result_store=store)
    n = q.get_ready(block=False)
    assert n.node_id == "a"
    q.mark_done("a", result="ok")
    assert store.saves == [("a", "ok")]


def test_result_store_invalidate_called_on_invalidate():
    store = RecordingResultStore()
    data = DAGData(nodes={
        "a": Node("a", deps=[]),
        "b": Node("b", deps=["a"]),
    }, metadata={})
    q = DAGQueue(data=data, result_store=store)
    q.get_ready(block=False)
    q.mark_done("a", result="a_done")
    q.get_ready(block=False)
    q.mark_done("b", result="b_done")
    assert store.invalidates == []
    q.invalidate("a")
    assert "a" in store.invalidates
    assert "b" in store.invalidates


def test_result_store_save_not_called_without_result_kwarg():
    store = RecordingResultStore()
    data = DAGData(nodes={"a": Node("a", deps=[])}, metadata={})
    q = DAGQueue(data=data, result_store=store)
    q.get_ready(block=False)
    q.mark_done("a")
    assert store.saves == []
