"""Tests for DAGQueue.visualization_snapshot() and VisualizationSnapshot."""
import pytest
from topoqueue import DAGQueue, DAGData, Node, State, VisualizationSnapshot


def test_visualization_snapshot_chain():
    """Chain a->b->c: edges, states, ready_ids."""
    data = DAGData(nodes={
        "a": Node("a", deps=[]),
        "b": Node("b", deps=["a"]),
        "c": Node("c", deps=["b"]),
    }, metadata={})
    q = DAGQueue(data=data)
    snap = q.visualization_snapshot()
    assert isinstance(snap, VisualizationSnapshot)
    assert set(snap.node_ids) == {"a", "b", "c"}
    assert set(snap.edges) == {("a", "b"), ("b", "c")}
    assert snap.node_states["a"] == State.READY.value
    assert snap.node_states["b"] == State.PENDING.value
    assert snap.node_states["c"] == State.PENDING.value
    assert "a" in snap.ready_ids
    assert snap.running_ids == []
    assert "b" in snap.dirty_or_pending_ids and "c" in snap.dirty_or_pending_ids


def test_visualization_snapshot_to_dict_serializable():
    data = DAGData(nodes={"a": Node("a", deps=[])}, metadata={})
    q = DAGQueue(data=data)
    snap = q.visualization_snapshot()
    d = snap.to_dict()
    assert "node_ids" in d and "edges" in d and "node_states" in d
    assert "ready_ids" in d and "running_ids" in d and "dirty_or_pending_ids" in d
    assert "graph_version" in d
    import json
    json.dumps(d)


def test_visualization_snapshot_after_done():
    """After a done, ready_ids and dirty set change."""
    data = DAGData(nodes={"a": Node("a", deps=[]), "b": Node("b", deps=["a"])}, metadata={})
    q = DAGQueue(data=data)
    q.get_ready(block=False)
    q.mark_done("a")
    snap = q.visualization_snapshot()
    assert snap.node_states["a"] == State.DONE.value
    assert "b" in snap.ready_ids
    q.invalidate("a")
    snap2 = q.visualization_snapshot()
    assert "a" in snap2.dirty_or_pending_ids or "a" in snap2.ready_ids
    assert "b" in snap2.dirty_or_pending_ids
