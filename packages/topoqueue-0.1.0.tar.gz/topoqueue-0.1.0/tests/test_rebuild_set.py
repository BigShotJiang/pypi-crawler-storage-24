"""Tests for DAGQueue.rebuild_set (minimal rebuild set: changed + downstream)."""
import pytest
from topoqueue import DAGQueue, DAGData, Node


def test_rebuild_set_chain_changed_root():
    """Chain a->b->c, changed={a} -> {a,b,c}."""
    data = DAGData(nodes={
        "a": Node("a", deps=[]),
        "b": Node("b", deps=["a"]),
        "c": Node("c", deps=["b"]),
    }, metadata={})
    q = DAGQueue(data=data)
    got = q.rebuild_set({"a"})
    assert got == {"a", "b", "c"}


def test_rebuild_set_chain_changed_mid():
    """Chain a->b->c, changed={b} -> {b,c}."""
    data = DAGData(nodes={
        "a": Node("a", deps=[]),
        "b": Node("b", deps=["a"]),
        "c": Node("c", deps=["b"]),
    }, metadata={})
    q = DAGQueue(data=data)
    assert q.rebuild_set({"b"}) == {"b", "c"}


def test_rebuild_set_fork():
    """a->b, a->c, changed={a} -> {a,b,c}."""
    data = DAGData(nodes={
        "a": Node("a", deps=[]),
        "b": Node("b", deps=["a"]),
        "c": Node("c", deps=["a"]),
    }, metadata={})
    q = DAGQueue(data=data)
    assert q.rebuild_set({"a"}) == {"a", "b", "c"}


def test_rebuild_set_empty_changed():
    data = DAGData(nodes={"a": Node("a", deps=[])}, metadata={})
    q = DAGQueue(data=data)
    assert q.rebuild_set(set()) == set()


def test_rebuild_set_unknown_id_ignored():
    data = DAGData(nodes={"a": Node("a", deps=[])}, metadata={})
    q = DAGQueue(data=data)
    assert q.rebuild_set({"x", "a"}) == {"a"}
