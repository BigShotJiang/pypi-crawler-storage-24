"""
Snapshot data for graph state: round-trip serialization for persistence and restore.

Contains metadata and per-node dicts (no payload or execution results). Used by
DAGQueue.snapshot() and restore(). Persistence (save/load) is the caller's responsibility.
"""
from dataclasses import dataclass, field
from typing import Any


@dataclass
class SnapshotData:
    """
    Immutable snapshot of graph state at a point in time.

    Attributes:
        metadata: Graph-level key-value dict (same shape as DAGData.metadata).
        nodes: Dict mapping node_id to a dict of node fields (deps, priority, state, attempts, etc.).
              Payload and execution results are not included; use payload=None when building from Node.to_dict().
    """

    metadata: dict = field(default_factory=dict)
    nodes: dict[str, dict[str, Any]] = field(default_factory=dict)

    def to_dict(self) -> dict:
        """Return a plain dict suitable for JSON or other serialization."""
        return {"metadata": self.metadata, "nodes": self.nodes}

    @classmethod
    def from_dict(cls, data: dict) -> "SnapshotData":
        """Build a SnapshotData from a dict (e.g. loaded from JSON)."""
        return cls(
            metadata=data.get("metadata", {}),
            nodes=data.get("nodes", {}),
        )
