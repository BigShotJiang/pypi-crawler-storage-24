"""
Result cache interface: protocol for external storage of node results.

The core never implements storage; it only calls these methods when a result_store
is supplied to DAGQueue. Implement this protocol to plug in a cache (e.g. disk, Redis).
"""
from typing import Any, Protocol


class ResultStore(Protocol):
    """
    Protocol for loading, saving, and invalidating node results.

    Implementations must be thread-safe if the queue is used from multiple threads.
    Exceptions propagate to the caller; avoid long-running or blocking work in these methods.
    """

    def load(self, node_id: str) -> Any:
        """Return the cached result for node_id, or a sentinel (e.g. None) if missing. Core does not call this; callers may use it to skip execution."""
        ...

    def save(self, node_id: str, result: Any) -> None:
        """Store the result for node_id. Called by core after mark_done(node_id, result=...)."""
        ...

    def invalidate(self, node_id: str) -> None:
        """Invalidate the cache entry for node_id. Called by core when the node (or its upstream) is invalidated."""
        ...
