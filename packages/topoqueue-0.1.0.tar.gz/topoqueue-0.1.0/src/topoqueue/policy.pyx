# cython: language_level=3
"""
Ready-queue ordering policy: context and strategy for scoring nodes.

The policy's score() is used to order the priority queue: lower score is
dequeued first. DefaultQueuePolicy orders by (higher priority first, then
higher out-degree first).
"""
from topoqueue.node import Node


cdef class QueueContext:
    """
    Read-only context passed to QueuePolicy.score().

    Provides access to the current graph (nodes, out_edges) so the policy
    can compute a score (e.g. based on fan-out).
    """

    cdef readonly dict _nodes
    cdef readonly dict _out_edges

    def __init__(self, dict nodes, dict out_edges):
        self._nodes = nodes
        self._out_edges = out_edges

    def out_degree(self, str nid):
        """Return the number of successors of node nid in the graph."""
        return len(self._out_edges.get(nid, []))


class QueuePolicy:
    """
    Abstract policy for ordering the ready queue.

    Implement score(node, context) to return a comparable value (e.g. tuple);
    lower values are dequeued first by get_ready().
    """

    def score(self, node: Node, context: QueueContext):
        """Return a comparable score; lower score means higher priority for dequeue."""
        raise NotImplementedError


class DefaultQueuePolicy(QueuePolicy):
    """
    Default policy: higher priority first, then higher out-degree first.

    Score is (-node.priority, -out_degree(node_id)) so that larger priority
    and larger fan-out are dequeued earlier.
    """

    def score(self, node, context):
        return (-node.priority, -context.out_degree(node.node_id))
