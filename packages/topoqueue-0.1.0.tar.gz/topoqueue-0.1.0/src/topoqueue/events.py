"""
Execution log event types: immutable events emitted by the queue for debugging and tooling.

Pass an event_sink callable to DAGQueue to receive these events (node_started, node_done,
node_failed, node_invalidated, dag_merged). Events are emitted under the queue lock; keep
the sink fast and non-blocking.
"""
from dataclasses import dataclass
from typing import Literal, Optional

EventKind = Literal["node_started", "node_done", "node_failed", "node_invalidated", "dag_merged"]


@dataclass(frozen=True)
class NodeEvent:
    """Event that refers to a single node (e.g. started, done, failed, invalidated)."""

    kind: EventKind
    node_id: str


@dataclass(frozen=True)
class DagMergedEvent:
    """Emitted after merge_dag() when graph structure changed."""

    kind: Literal["dag_merged"] = "dag_merged"
    graph_version: Optional[int] = None


def node_started(node_id: str) -> NodeEvent:
    """Build event: node was dequeued and marked RUNNING."""
    return NodeEvent("node_started", node_id)


def node_done(node_id: str) -> NodeEvent:
    """Build event: node was marked DONE."""
    return NodeEvent("node_done", node_id)


def node_failed(node_id: str) -> NodeEvent:
    """Build event: node was marked FAILED (no retry left)."""
    return NodeEvent("node_failed", node_id)


def node_invalidated(node_id: str) -> NodeEvent:
    """Build event: node was marked DIRTY/PENDING by invalidation."""
    return NodeEvent("node_invalidated", node_id)


def dag_merged(graph_version: Optional[int] = None) -> DagMergedEvent:
    """Build event: merge_dag completed and structure changed; graph_version is the new version."""
    return DagMergedEvent(graph_version=graph_version)
