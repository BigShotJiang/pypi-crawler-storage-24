# cython: language_level=3
"""
DAG graph data: nodes and metadata for construction or serialization.

Used to build a DAGQueue or to serialize/deserialize a graph (e.g. for persistence).
Does not perform validation; use DAGQueue.validate() after construction.
"""
import json
from topoqueue.node import Node
from topoqueue.state import State


class DAGData:
    """
    Container for a DAG's nodes and graph-level metadata.

    Attributes:
        nodes: Dict mapping node_id (str) to Node instances.
        metadata: Dict of graph-level key-value data (caller-defined).
    """

    def __init__(
        self,
        dict nodes = None,
        dict metadata = None,
    ):
        self.nodes = nodes if nodes is not None else {}
        self.metadata = metadata if metadata is not None else {}

    def to_json(self):
        """Serialize nodes and metadata to a JSON string. Node payloads must be JSON-serializable."""

        payload = {
            "nodes": {nid: node.to_dict() for nid, node in self.nodes.items()},
            "metadata": self.metadata,
        }
        return json.dumps(payload)

    @classmethod
    def from_json(cls, str s):
        """Deserialize a JSON string produced by to_json() into a new DAGData instance."""

        data = json.loads(s)
        nodes = {}
        for nid, d in data.get("nodes", {}).items():
            state_val = d.get("state", State.PENDING.value)
            if isinstance(state_val, str) and not hasattr(State, state_val):
                state = State(state_val)
            else:
                state = State(state_val) if isinstance(state_val, str) else State.PENDING
            node = Node(
                node_id=d.get("node_id", nid),
                deps=d.get("deps", []),
                priority=d.get("priority", 0),
                max_retries=d.get("max_retries", 0),
                payload=d.get("payload"),
                state=state,
            )
            node.attempts = d.get("attempts", 0)
            for k, v in d.items():
                if k not in ("node_id", "deps", "priority", "state", "max_retries", "payload", "attempts"):
                    setattr(node, k, v)
            nodes[nid] = node
        return cls(nodes=nodes, metadata=data.get("metadata", {}))
