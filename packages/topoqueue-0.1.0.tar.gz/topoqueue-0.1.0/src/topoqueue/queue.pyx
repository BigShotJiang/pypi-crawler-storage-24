# cython: language_level=3
"""
Thread-safe DAG ready-queue engine.

Nodes are released (get_ready) only when all dependencies are DONE. Supports
invalidation, cancellation, snapshot/restore, merge_dag, optional result_store
and event_sink hooks, rebuild_set, and visualization_snapshot. Hot paths are
type-annotated for Cython optimization.
"""
import queue
import threading
import time
import warnings
from collections import deque

from topoqueue.dag_data import DAGData
from topoqueue.node import Node
from topoqueue.policy import DefaultQueuePolicy, QueueContext, QueuePolicy
from topoqueue.snapshot import SnapshotData
from topoqueue.state import State
from topoqueue.events import node_started, node_done, node_failed, node_invalidated, dag_merged
from topoqueue.viz import VisualizationSnapshot


class CycleError(ValueError):
    """Raised by validate() when the graph contains a cycle."""

    pass


class DAGQueue:
    """
    Thread-safe DAG ready queue: nodes are dispatched only when dependencies are satisfied.

    Construction:
        data: DAGData (or None for empty graph). policy: QueuePolicy for ordering (default DefaultQueuePolicy).
        result_store: Optional protocol with load/save/invalidate; called on mark_done and invalidate.
        event_sink: Optional callable(event); invoked for node_started, node_done, node_failed, node_invalidated, dag_merged.

    All public methods that mutate state or read shared state are thread-safe under an internal RLock.
    """

    def __init__(self, data=None, policy=None, result_store=None, event_sink=None):
        if data is None:
            data = DAGData()
        self._policy = policy if policy is not None else DefaultQueuePolicy()
        self._nodes = data.nodes
        self._metadata = data.metadata
        self._result_store = result_store
        self._event_sink = event_sink
        self._graph_version = 0
        self._lock = threading.RLock()
        self._cond = threading.Condition(self._lock)
        self._out_edges = {nid: [] for nid in self._nodes}
        self._in_degree = {}
        for nid, node in self._nodes.items():
            in_d = len(node.deps)
            self._in_degree[nid] = in_d
            for dep in node.deps:
                if dep in self._out_edges:
                    self._out_edges[dep].append(nid)
        self._ready_queue = queue.PriorityQueue()
        self._running_count = 0
        self._generation = 0
        self._run_generation = {}
        for nid, node in self._nodes.items():
            if self._in_degree[nid] == 0:
                node.state = State.READY
                self._enqueue_ready(nid)
            if getattr(node, "created_in_version", None) is None:
                setattr(node, "created_in_version", self._graph_version)

    def _context(self):
        """Build read-only context for the policy scorer."""
        return QueueContext(self._nodes, self._out_edges)

    def _enqueue_ready(self, str nid):
        node = self._nodes[nid]
        ctx = self._context()
        score = self._policy.score(node, ctx)
        self._ready_queue.put((score, nid))

    def validate(self, strict=True):
        """
        Verify the graph is acyclic and optionally that all deps exist.

        Returns:
            True if the graph has no cycle.
        Raises:
            CycleError: If a cycle is detected.
            ValueError: If strict=True and any node has a dependency not in the graph (orphan dep).
        """
        with self._lock:
            for nid, node in self._nodes.items():
                for dep in node.deps:
                    if dep not in self._nodes:
                        if strict:
                            raise ValueError(
                                f"Orphan dependency: node {nid!r} depends on {dep!r} which is not in the graph."
                            )
                        warnings.warn(
                            f"Orphan dependency: node {nid!r} depends on {dep!r} which is not in the graph.",
                            UserWarning,
                            stacklevel=2,
                        )
            # Cycle detection uses in-degree over existing deps only, so orphan deps are not misreported as cycles.
            deg = {nid: len([d for d in node.deps if d in self._nodes]) for nid, node in self._nodes.items()}
            q = deque(nid for nid, d in deg.items() if d == 0)
            count = 0
            while q:
                nid = q.popleft()
                count += 1
                for succ in self._out_edges.get(nid, []):
                    deg[succ] -= 1
                    if deg[succ] == 0:
                        q.append(succ)
            if count != len(self._nodes):
                raise CycleError("Cycle detected in DAG")
            return True

    def _add_node_unsafe(self, node, overwrite=False):
        """Add or replace a node and update edges/degrees/ready queue. Caller must hold _lock. Used by add_node, add_nodes, merge_dag."""
        if node.node_id in self._nodes and not overwrite:
            raise ValueError(f"Node {node.node_id!r} already exists; use overwrite=True to replace.")
        if node.node_id in self._nodes and overwrite:
            old = self._nodes[node.node_id]
            for dep in old.deps:
                if dep in self._out_edges:
                    self._out_edges[dep] = [x for x in self._out_edges[dep] if x != node.node_id]
            self._out_edges[node.node_id] = []
        for dep in node.deps:
            if dep not in self._nodes:
                raise ValueError(f"Node {node.node_id!r} depends on missing node {dep!r}")
        self._nodes[node.node_id] = node
        if getattr(node, "created_in_version", None) is None:
            setattr(node, "created_in_version", self._graph_version)
        in_d = len(node.deps)
        self._in_degree[node.node_id] = in_d
        if node.node_id not in self._out_edges:
            self._out_edges[node.node_id] = []
        for dep in node.deps:
            self._out_edges[dep].append(node.node_id)
        if in_d == 0:
            node.state = State.READY
            self._enqueue_ready(node.node_id)

    def add_node(self, node, overwrite=False):
        """Add a single node; validate() is called after. Raises ValueError if dep missing or duplicate (when overwrite=False)."""
        with self._lock:
            self._add_node_unsafe(node, overwrite=overwrite)
        self.validate()

    def add_nodes(self, nodes, overwrite=False):
        """Add multiple nodes in one go; validate() is called once after all are added."""
        with self._lock:
            for node in nodes:
                self._add_node_unsafe(node, overwrite=overwrite)
        self.validate()

    def merge_dag(self, new_data, overwrite=False):
        """
        Merge a new DAG definition into the current graph.

        Nodes whose deps or priority changed are invalidated. Graph structure
        (nodes and edges) is rebuilt from new_data; nodes only in the old graph
        are kept as orphans. If structure changes, graph_version is incremented
        and dag_merged event is emitted.
        Raises:
            ValueError: If a node exists and overwrite=False.
        """
        with self._lock:
            old_node_ids = set(self._nodes.keys())
            old_edges = set(
                (dep, nid) for nid, node in self._nodes.items() for dep in node.deps if dep in self._nodes
            )
            invalidate_set = set()
            for nid, new_node in new_data.nodes.items():
                if nid in self._nodes:
                    if not overwrite:
                        raise ValueError(f"Node {nid!r} already exists and overwrite=False")
                    old = self._nodes[nid]
                    if old.deps != new_node.deps or old.priority != new_node.priority:
                        invalidate_set.add(nid)
            for nid in invalidate_set:
                node = self._nodes.get(nid)
                if node is not None and node.state != State.RUNNING:
                    self.invalidate(nid)
            for nid, new_node in new_data.nodes.items():
                if nid in self._nodes:
                    old = self._nodes[nid]
                    if old.state in (State.RUNNING, State.DONE, State.FAILED):
                        continue
                self._nodes[nid] = new_node
            self._out_edges = {nid: [] for nid in new_data.nodes}
            self._in_degree = {nid: len(node.deps) for nid, node in new_data.nodes.items()}
            for nid, node in new_data.nodes.items():
                for dep in node.deps:
                    if dep in self._out_edges:
                        self._out_edges[dep].append(nid)
            self._ready_queue = queue.PriorityQueue()
            for nid in new_data.nodes:
                node = self._nodes[nid]
                if node.state in (State.DONE, State.FAILED, State.CANCELED, State.RUNNING):
                    continue
                if self._in_degree[nid] == 0:
                    node.state = State.READY
                    self._enqueue_ready(nid)
                else:
                    node.state = State.PENDING
            self._running_count = sum(1 for n in self._nodes.values() if n.state == State.RUNNING)
            new_node_ids = set(new_data.nodes.keys())
            new_edges = set(
                (dep, nid) for nid, node in new_data.nodes.items() for dep in node.deps if dep in new_data.nodes
            )
            structure_changed = old_node_ids != new_node_ids or old_edges != new_edges
            if structure_changed:
                self._graph_version += 1
            for nid, node in self._nodes.items():
                if getattr(node, "created_in_version", None) is None:
                    setattr(node, "created_in_version", self._graph_version)
            if structure_changed and self._event_sink is not None:
                self._event_sink(dag_merged(self._graph_version))
        self.validate()

    def get_ready(self, block=True, timeout=None):
        """
        Dequeue a node that is READY (all deps DONE). Marks it RUNNING and records generation.

        Returns the Node. If block=False and no node is ready, raises queue.Empty.
        If block=True, waits until a node is ready or timeout expires.
        """
        while True:
            if block:
                item = self._ready_queue.get(block=True, timeout=timeout)
            else:
                item = self._ready_queue.get_nowait()
            _, nid = item
            with self._lock:
                node = self._nodes[nid]
                if node.state != State.READY:
                    continue
                node.state = State.RUNNING
                self._running_count += 1
                self._run_generation[nid] = self._generation
                if self._event_sink is not None:
                    self._event_sink(node_started(nid))
                return node

    def mark_done(self, node_id, **result_kwargs):
        """
        Mark a RUNNING node as DONE and update successors.

        result_kwargs are stored on the node; if result_store is set and 'result'
        is in result_kwargs, result_store.save(node_id, result) is called.
        Raises ValueError if the node was invalidated/canceled (generation mismatch) or not RUNNING.
        """
        with self._lock:
            node = self._nodes[node_id]
            if self._run_generation.get(node_id) != self._generation:
                raise ValueError("node was invalidated or canceled")
            if node.state != State.RUNNING:
                raise ValueError(
                    f"mark_done: node {node_id!r} is {node.state.value}, expected RUNNING."
                )
            node.state = State.DONE
            self._run_generation.pop(node_id, None)
            self._running_count -= 1
            assert self._running_count >= 0, "_running_count must not go negative"
            for k, v in result_kwargs.items():
                setattr(node, k, v)
            if self._result_store is not None and "result" in result_kwargs:
                self._result_store.save(node_id, result_kwargs["result"])
            if self._event_sink is not None:
                self._event_sink(node_done(node_id))
            for succ in self._out_edges.get(node_id, []):
                self._in_degree[succ] -= 1
                if self._in_degree[succ] == 0:
                    n = self._nodes[succ]
                    n.state = State.READY
                    self._enqueue_ready(succ)
            self._cond.notify_all()

    def snapshot(self):
        """
        Return current graph state as SnapshotData (no payload or execution results).

        Caller is responsible for persistence. Use restore(snapshot) to rebuild the queue from it.
        """
        with self._lock:
            nodes = {}
            for nid, node in self._nodes.items():
                d = node.to_dict()
                d["payload"] = None
                nodes[nid] = d
            return SnapshotData(metadata=dict(self._metadata), nodes=nodes)

    def restore(self, data):
        """
        Restore graph state from a SnapshotData. Does not restore payload or execution results.

        Rebuilds _nodes, _out_edges, _in_degree, ready queue, and running count from data.
        Raises ValueError if data is missing required fields or has invalid state/deps.
        """
        with self._lock:
            if not hasattr(data, "metadata") or not hasattr(data, "nodes"):
                raise ValueError("SnapshotData must have 'metadata' and 'nodes'")
            if not isinstance(data.metadata, dict):
                raise ValueError("SnapshotData.metadata must be a dict")
            if not isinstance(data.nodes, dict):
                raise ValueError("SnapshotData.nodes must be a dict")
            _valid_states = {s.value for s in State}
            for nid, d in data.nodes.items():
                if not isinstance(d, dict):
                    raise ValueError(f"SnapshotData.nodes[{nid!r}] must be a dict")
                if "deps" not in d:
                    raise ValueError(f"SnapshotData.nodes[{nid!r}] missing required key 'deps'")
                if not isinstance(d["deps"], (list, tuple)):
                    raise ValueError(f"SnapshotData.nodes[{nid!r}]['deps'] must be a list or tuple")
                if "state" in d:
                    sv = d["state"]
                    if sv not in _valid_states:
                        raise ValueError(f"SnapshotData.nodes[{nid!r}]['state'] invalid: {sv!r}")
            nodes = {}
            for nid, d in data.nodes.items():
                state_val = d.get("state", State.PENDING.value)
                if isinstance(state_val, str):
                    state = State(state_val)
                else:
                    state = State.PENDING
                node = Node(
                    node_id=d.get("node_id", nid),
                    deps=d.get("deps", []),
                    priority=d.get("priority", 0),
                    max_retries=d.get("max_retries", 0),
                    payload=d.get("payload"),
                    state=state,
                )
                node.attempts = d.get("attempts", 0)
                for k, v in d.items():
                    if k not in ("node_id", "deps", "priority", "state", "max_retries", "payload", "attempts"):
                        setattr(node, k, v)
                nodes[nid] = node
            self._nodes = nodes
            self._metadata = dict(data.metadata)
            self._run_generation.clear()
            self._out_edges = {nid: [] for nid in self._nodes}
            self._in_degree = {}
            for nid, node in self._nodes.items():
                in_d = len(node.deps)
                self._in_degree[nid] = in_d
                for dep in node.deps:
                    if dep in self._out_edges:
                        self._out_edges[dep].append(nid)
            self._ready_queue = queue.PriorityQueue()
            self._running_count = 0
            for nid, node in self._nodes.items():
                if node.state == State.RUNNING:
                    self._running_count += 1
                    self._run_generation[nid] = self._generation
            for nid, node in self._nodes.items():
                if node.state in (State.DONE, State.FAILED, State.CANCELED, State.RUNNING):
                    continue
                if self._in_degree[nid] == 0:
                    node.state = State.READY
                    self._enqueue_ready(nid)
                else:
                    node.state = State.PENDING
            self._cond.notify_all()

    def invalidate(self, node_id):
        """
        Mark the node and all its downstream nodes as needing recomputation.

        DONE -> DIRTY, READY -> PENDING; RUNNING nodes are skipped (caller must cancel first).
        Propagation is BFS along _out_edges. result_store.invalidate and event_sink(node_invalidated) are called for each affected node.
        Raises ValueError if node_id not in graph or node is RUNNING.
        """
        with self._lock:
            node = self._nodes.get(node_id)
            if node is None:
                raise ValueError(f"Node {node_id!r} not in graph.")
            if node.state == State.RUNNING:
                raise ValueError("node is RUNNING; cancel or wait before invalidating")
            if node.state == State.DONE:
                node.state = State.DIRTY
            elif node.state == State.READY:
                node.state = State.PENDING
            seen = {node_id}
            q_bfs = deque(self._out_edges.get(node_id, []))
            while q_bfs:
                nid = q_bfs.popleft()
                if nid in seen or nid not in self._nodes:
                    continue
                seen.add(nid)
                n = self._nodes[nid]
                if n.state == State.RUNNING:
                    continue
                if n.state == State.DONE:
                    n.state = State.DIRTY
                elif n.state == State.READY:
                    n.state = State.PENDING
                q_bfs.extend(self._out_edges.get(nid, []))
            for nid in seen:
                n = self._nodes.get(nid)
                if n is None:
                    continue
                if n.state == State.DIRTY:
                    # Recompute unresolved deps by current dependency states instead of
                    # blindly using len(deps), so leaf invalidation can become READY immediately.
                    unresolved = 0
                    for dep in n.deps:
                        dn = self._nodes.get(dep)
                        if dn is None or dn.state != State.DONE:
                            unresolved += 1
                    self._in_degree[nid] = unresolved
                    if unresolved == 0:
                        n.state = State.READY
                        self._enqueue_ready(nid)
            self._generation += 1
            if self._result_store is not None:
                for nid in seen:
                    self._result_store.invalidate(nid)
            if self._event_sink is not None:
                for nid in seen:
                    self._event_sink(node_invalidated(nid))

    def cancel(self, node_id, cascade=False):
        """
        Cancel a RUNNING node (set to CANCELED and bump generation).

        If cascade=True, all downstream nodes are set to CANCELED. Non-RUNNING nodes are unchanged (no-op).
        """
        with self._lock:
            node = self._nodes.get(node_id)
            if node is None or node.state != State.RUNNING:
                return
            node.state = State.CANCELED
            self._running_count -= 1
            assert self._running_count >= 0, "_running_count must not go negative"
            self._run_generation.pop(node_id, None)
            self._generation += 1
            if cascade:
                q_bfs = deque(self._out_edges.get(node_id, []))
                while q_bfs:
                    nid = q_bfs.popleft()
                    if nid not in self._nodes:
                        continue
                    self._nodes[nid].state = State.CANCELED
                    q_bfs.extend(self._out_edges.get(nid, []))
            self._cond.notify_all()

    def mark_failed(self, node_id, cascade=False, **error_kwargs):
        """
        Mark a RUNNING node as FAILED (or re-queue if attempts < max_retries).

        If attempts < max_retries, node is put back to READY and re-enqueued. Otherwise
        node becomes FAILED; error_kwargs are stored on the node. If cascade=True,
        downstream nodes are set to CANCELED. Raises ValueError if generation mismatch or not RUNNING.
        """
        with self._lock:
            node = self._nodes[node_id]
            if self._run_generation.get(node_id) != self._generation:
                raise ValueError("node was invalidated or canceled")
            if node.state != State.RUNNING:
                raise ValueError(
                    f"mark_failed: node {node_id!r} is {node.state.value}, expected RUNNING."
                )
            if node.attempts < node.max_retries:
                node.attempts += 1
                node.state = State.READY
                self._running_count -= 1
                assert self._running_count >= 0, "_running_count must not go negative"
                self._run_generation.pop(node_id, None)
                self._enqueue_ready(node_id)
                self._cond.notify_all()
                return
            self._running_count -= 1
            assert self._running_count >= 0, "_running_count must not go negative"
            node.state = State.FAILED
            self._run_generation.pop(node_id, None)
            if self._event_sink is not None:
                self._event_sink(node_failed(node_id))
            for k, v in error_kwargs.items():
                setattr(node, k, v)
            if cascade:
                q = deque(self._out_edges.get(node_id, []))
                while q:
                    nid = q.popleft()
                    if nid not in self._nodes:
                        continue
                    self._nodes[nid].state = State.CANCELED
                    q.extend(self._out_edges.get(nid, []))
            self._cond.notify_all()

    def stats(self):
        """Return counts per state (pending, ready, running, done, failed, canceled, dirty) and blocked (PENDING with failed ancestor)."""
        with self._lock:
            counts = {"pending": 0, "ready": 0, "running": 0, "done": 0, "failed": 0, "canceled": 0, "dirty": 0}
            for node in self._nodes.values():
                key = node.state.value
                if key in counts:
                    counts[key] += 1

            def has_failed_ancestor(nid, seen):
                if nid in seen:
                    return False
                seen.add(nid)
                node = self._nodes.get(nid)
                if not node:
                    return False
                if node.state == State.FAILED:
                    return True
                for dep in node.deps:
                    if has_failed_ancestor(dep, seen):
                        return True
                return False

            blocked = sum(
                1 for nid, node in self._nodes.items()
                if node.state == State.PENDING and has_failed_ancestor(nid, set())
            )
            counts["blocked"] = blocked
            return counts

    def is_finished(self):
        """Return True if all nodes are terminal (DONE/FAILED/CANCELED) or there are no RUNNING/READY nodes (e.g. deadlock)."""
        with self._lock:
            terminal = (State.DONE, State.FAILED, State.CANCELED)
            n_terminal = sum(1 for node in self._nodes.values() if node.state in terminal)
            if n_terminal == len(self._nodes):
                return True
            if self._running_count == 0 and not any(n.state == State.READY for n in self._nodes.values()):
                return True
            return False

    def join(self, timeout=None):
        """Block until is_finished() is True, or until timeout (seconds). Returns True if finished, False if timeout."""
        deadline = (time.monotonic() + timeout) if timeout is not None else None
        with self._cond:
            while not self.is_finished():
                if deadline is not None:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        return False
                    self._cond.wait(timeout=remaining)
                else:
                    self._cond.wait()
        return True

    @property
    def graph_version(self):
        """Current graph structure version; incremented when merge_dag changes structure. For debugging/audit."""
        return self._graph_version

    def rebuild_set(self, changed):
        """
        Return the minimal set of node_ids that need to be re-run: changed union all downstream.

        Read-only; does not modify queue state. Used by callers to plan partial rebuilds.
        """
        with self._lock:
            result = set()
            for nid in changed:
                if nid in self._nodes:
                    result.add(nid)
            q_bfs = deque(result)
            while q_bfs:
                nid = q_bfs.popleft()
                for succ in self._out_edges.get(nid, []):
                    if succ in self._nodes and succ not in result:
                        result.add(succ)
                        q_bfs.append(succ)
            return result

    def visualization_snapshot(self):
        """
        Return a read-only snapshot of graph structure and node states for debugging/visualization.

        Includes node_ids, edges, node_states, ready_ids, running_ids, dirty_or_pending_ids, graph_version.
        Not suitable for restore(); use snapshot()/restore() for that.
        """
        with self._lock:
            node_ids = list(self._nodes.keys())
            edges = []
            for nid, succs in self._out_edges.items():
                for s in succs:
                    if s in self._nodes:
                        edges.append((nid, s))
            node_states = {nid: node.state.value for nid, node in self._nodes.items()}
            ready_ids = [nid for nid, node in self._nodes.items() if node.state == State.READY]
            running_ids = [nid for nid, node in self._nodes.items() if node.state == State.RUNNING]
            dirty_or_pending_ids = [
                nid for nid, node in self._nodes.items()
                if node.state == State.DIRTY or node.state == State.PENDING
            ]
            return VisualizationSnapshot(
                node_ids=node_ids,
                edges=edges,
                node_states=node_states,
                ready_ids=ready_ids,
                running_ids=running_ids,
                dirty_or_pending_ids=dirty_or_pending_ids,
                graph_version=self._graph_version,
            )
