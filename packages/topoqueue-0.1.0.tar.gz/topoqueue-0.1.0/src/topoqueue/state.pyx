# cython: language_level=3
"""
Node lifecycle states for the DAG queue.

Compiled with Cython for fast attribute access and comparison on hot paths.
"""
from enum import Enum


class State(Enum):
    """
    Enumeration of possible states for a node in the DAG.

    - PENDING: Dependencies not yet satisfied.
    - READY: Dependencies satisfied; node is in the ready queue.
    - RUNNING: Node has been handed to a worker (get_ready returned it).
    - DONE: Node completed successfully.
    - FAILED: Node execution failed (no retry left or max_retries reached).
    - CANCELED: Node was canceled (e.g. cancel() or upstream cascade).
    - DIRTY: Node was DONE/READY but invalidated; must be recomputed.
    """

    PENDING = "pending"
    READY = "ready"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"
    CANCELED = "canceled"
    DIRTY = "dirty"
