"""
Visualization export: read-only snapshot of graph and state for debugging and tooling.

Returned by DAGQueue.visualization_snapshot(). Not suitable for restore(); use
SnapshotData and snapshot()/restore() for persistence.
"""
from dataclasses import dataclass, field


@dataclass
class VisualizationSnapshot:
    """
    Read-only snapshot of graph structure and node states for visualization or monitoring.

    Attributes:
        node_ids: List of all node IDs in the graph.
        edges: List of (from_id, to_id) dependency edges.
        node_states: Dict mapping node_id to state.value (e.g. "done", "ready").
        ready_ids: Node IDs currently READY (execution frontier, can be dequeued).
        running_ids: Node IDs currently RUNNING.
        dirty_or_pending_ids: Node IDs in DIRTY or PENDING (invalidated or waiting on deps).
        graph_version: Current graph structure version (from DAGQueue.graph_version).
    """

    node_ids: list = field(default_factory=list)
    edges: list = field(default_factory=list)
    node_states: dict = field(default_factory=dict)
    ready_ids: list = field(default_factory=list)
    running_ids: list = field(default_factory=list)
    dirty_or_pending_ids: list = field(default_factory=list)
    graph_version: int = 0

    def to_dict(self) -> dict:
        """Return a dict suitable for JSON serialization or passing to external tools."""
        return {
            "node_ids": self.node_ids,
            "edges": self.edges,
            "node_states": self.node_states,
            "ready_ids": self.ready_ids,
            "running_ids": self.running_ids,
            "dirty_or_pending_ids": self.dirty_or_pending_ids,
            "graph_version": self.graph_version,
        }
