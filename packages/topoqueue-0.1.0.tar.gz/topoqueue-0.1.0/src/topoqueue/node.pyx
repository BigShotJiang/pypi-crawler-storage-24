# cython: language_level=3
"""
DAG node: a single work unit with dependencies and state.

Compiled with Cython for fast attribute access and construction. Nodes are
identified by node_id; deps are stored as an immutable tuple. Extra kwargs
are stored on the node (e.g. for payload or caller-defined fields) and must
be JSON-serializable if used with DAGData.to_json/from_json.
"""
import json
from topoqueue.state import State


def _json_serializable(v):
    """Return True if v is JSON-serializable (used when exporting node to dict)."""
    try:
        json.dumps(v)
        return True
    except (TypeError, ValueError):
        return False


class Node:
    """
    A single node in the DAG.

    Attributes:
        node_id: Unique identifier (required).
        deps: Tuple of node_id strings; dependencies that must be DONE before this node becomes READY.
        priority: Integer; higher value means higher priority when scheduling (default 0).
        state: Current State (default PENDING).
        max_retries: Number of retries allowed on failure (default 0).
        payload: Optional user payload (not used by core; must be JSON-serializable if serialized).
        attempts: Current attempt count (updated by core on mark_failed retry).

    Additional keyword arguments are stored as attributes (e.g. created_in_version).
    """

    __slots__ = ("node_id", "deps", "priority", "state", "max_retries", "payload", "attempts", "__dict__")

    def __init__(
        self,
        str node_id,
        object deps = None,
        int priority = 0,
        int max_retries = 0,
        object payload = None,
        object state = None,
        **kwargs,
    ):
        self.node_id = node_id
        self.deps = tuple(deps) if deps is not None else ()
        self.priority = priority
        self.max_retries = max_retries
        self.payload = payload
        self.attempts = 0
        self.state = state if state is not None else State.PENDING
        for k, v in kwargs.items():
            setattr(self, k, v)

    def to_dict(self):
        """Return a dict of all JSON-serializable attributes for serialization/snapshot."""

        d = {
            "node_id": self.node_id,
            "deps": list(self.deps),
            "priority": self.priority,
            "state": self.state.value,
            "max_retries": self.max_retries,
            "payload": self.payload,
            "attempts": self.attempts,
        }
        for k, v in self.__dict__.items():
            if _json_serializable(v):
                d[k] = v
        return d
