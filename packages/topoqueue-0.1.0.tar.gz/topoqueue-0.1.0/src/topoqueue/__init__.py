"""
TopoQueue: A dependency-aware ready queue for DAG tasks.

This package provides a thread-safe scheduling primitive that releases nodes
only when their dependencies are satisfied. It supports invalidation, cancellation,
snapshot/restore, merge, optional result-store and event-sink hooks, and
visualization/debug exports. See README for usage and API overview.
"""
from topoqueue.state import State
from topoqueue.node import Node
from topoqueue.dag_data import DAGData
from topoqueue.queue import DAGQueue, CycleError
from topoqueue.policy import QueuePolicy, QueueContext, DefaultQueuePolicy
from topoqueue.snapshot import SnapshotData
from topoqueue.result_store import ResultStore
from topoqueue.events import (
    node_started,
    node_done,
    node_failed,
    node_invalidated,
    dag_merged,
    NodeEvent,
    DagMergedEvent,
)
from topoqueue.viz import VisualizationSnapshot

__version__ = "0.1.0"

__all__ = [
    "State", "Node", "DAGData", "DAGQueue", "CycleError",
    "QueuePolicy", "QueueContext", "DefaultQueuePolicy",
    "SnapshotData", "ResultStore", "VisualizationSnapshot",
    "node_started", "node_done", "node_failed", "node_invalidated", "dag_merged",
    "NodeEvent", "DagMergedEvent",
    "__version__",
]
