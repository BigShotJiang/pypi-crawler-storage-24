"""Cython 扩展构建：将 TopoQueue 核心模块编译为 C 扩展以提升性能。"""
from setuptools import setup, Extension
import Cython.Build

def ext_modules():
    root = "src/topoqueue"
    return Cython.Build.cythonize(
        [
            Extension("topoqueue.state", [f"{root}/state.pyx"]),
            Extension("topoqueue.node", [f"{root}/node.pyx"]),
            Extension("topoqueue.policy", [f"{root}/policy.pyx"]),
            Extension("topoqueue.dag_data", [f"{root}/dag_data.pyx"]),
            Extension("topoqueue.queue", [f"{root}/queue.pyx"]),
        ],
        compiler_directives={
            "language_level": "3",
            "boundscheck": False,
            "wraparound": False,
            "initializedcheck": False,
            "nonecheck": False,
            "cdivision": True,
        },
    )

setup(ext_modules=ext_modules())
