# examples.wish_engine: 许愿机调度器示例
