# examples/wish_engine/dag_loader.py
"""
从 CSV 邻接表加载 DAG。
CSV 格式：task_id, priority, dep1, dep2, ...
- 第一行可为表头（可选）：task_id,priority,deps 或 task_id,priority,dep1,dep2,...
- 依赖列：从第 3 列起为依赖的 task_id，空表示无依赖；或第三列为分号分隔的 deps（如 T1;T2）
"""
import csv
from pathlib import Path

from topoqueue import Node, DAGData


def load_tasks_from_csv(csv_path: str | Path) -> list[dict]:
    """从 CSV 读取任务列表。每行：task_id, priority, [deps...]。返回 [{"task_id", "priority", "depends_on"}, ...]。"""
    path = Path(csv_path)
    rows = []
    with path.open(newline="", encoding="utf-8") as f:
        reader = csv.reader(f)
        for row in reader:
            if not row:
                continue
            task_id = row[0].strip()
            if not task_id:
                continue
            # 跳过表头
            if task_id.lower() in ("task_id", "node_id", "id"):
                continue
            try:
                priority = int(row[1].strip()) if len(row) > 1 else 0
            except ValueError:
                priority = 0
            depends_on = []
            if len(row) > 2:
                third = row[2].strip()
                if ";" in third:
                    depends_on = [x.strip() for x in third.split(";") if x.strip()]
                else:
                    for i in range(2, len(row)):
                        dep = row[i].strip()
                        if dep:
                            depends_on.append(dep)
            rows.append({
                "task_id": task_id,
                "priority": priority,
                "depends_on": depends_on,
            })
    return rows


def tasks_to_dag(tasks: list[dict], max_retries: int = 3) -> DAGData:
    """将任务列表转为 TopoQueue 的 DAGData（Node 使用 max_retries）。"""
    nodes = {}
    for t in tasks:
        n = Node(
            node_id=t["task_id"],
            deps=tuple(t["depends_on"]),
            priority=t.get("priority", 0),
            max_retries=max_retries,
            payload=None,
        )
        nodes[n.node_id] = n
    return DAGData(nodes=nodes, metadata={"max_retries": max_retries})
