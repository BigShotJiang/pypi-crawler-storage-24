# examples/wish_engine/verdict.py
"""
判决器：根据调度结果与输入 DAG 对比，判断是否为「正确的失败」。
"""
from topoqueue import State


def has_failed_ancestor(nodes: dict, out_edges: dict, nid: str, seen: set = None) -> bool:
    """从 nid 沿 deps 向上是否存在 FAILED 祖先。"""
    if seen is None:
        seen = set()
    if nid in seen:
        return False
    seen.add(nid)
    node = nodes.get(nid)
    if not node:
        return False
    if node.state == State.FAILED:
        return True
    for dep in node.deps:
        if has_failed_ancestor(nodes, out_edges, dep, seen):
            return True
    return False


def get_out_edges(nodes: dict) -> dict:
    """从 nodes 构建 node_id -> list[后继] 的邻接表。"""
    out = {nid: [] for nid in nodes}
    for nid, node in nodes.items():
        for dep in node.deps:
            if dep in out:
                out[dep].append(nid)
    return out


def run_verdict(nodes: dict) -> tuple[str, list[str]]:
    """
    对调度完成后的 nodes 做一致性检查，返回 (verdict, messages)。
    verdict 取值：
      - "success": 所有节点均为 DONE（最终愿望达成）
      - "correct_failure": 存在 FAILED，且无 DONE 节点拥有 FAILED 祖先，下游正确 CANCELED
      - "incorrect": 存在 DONE 节点但其某依赖为 FAILED/CANCELED（不应出现）
    """
    out_edges = get_out_edges(nodes)
    messages = []

    # 检查：任何 DONE 节点的依赖必须均为 DONE
    for nid, node in nodes.items():
        if node.state != State.DONE:
            continue
        for dep in node.deps:
            if dep not in nodes:
                continue
            d = nodes[dep]
            if d.state != State.DONE:
                return "incorrect", messages + [
                    f"节点 {nid} 为 DONE，但依赖 {dep} 状态为 {d.state.value}，违反一致性。"
                ]

    # 检查：任何 CANCELED 节点应存在 FAILED 祖先
    for nid, node in nodes.items():
        if node.state != State.CANCELED:
            continue
        if not has_failed_ancestor(nodes, out_edges, nid):
            messages.append(f"节点 {nid} 为 CANCELED 但无 FAILED 祖先（可能为孤立取消）。")

    done_count = sum(1 for n in nodes.values() if n.state == State.DONE)
    failed_count = sum(1 for n in nodes.values() if n.state == State.FAILED)
    canceled_count = sum(1 for n in nodes.values() if n.state == State.CANCELED)

    if failed_count == 0 and canceled_count == 0:
        return "success", messages + [f"全部 {len(nodes)} 个任务完成，最终愿望达成。"]
    if failed_count > 0:
        return "correct_failure", messages + [
            f"存在 {failed_count} 个失败、{canceled_count} 个因上游失败而取消；状态一致，为正确的失败。"
        ]
    return "correct_failure", messages
