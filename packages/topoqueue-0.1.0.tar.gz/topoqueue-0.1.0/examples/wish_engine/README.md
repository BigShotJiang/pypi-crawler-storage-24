# 许愿机示例（Wish Engine）

基于 **TopoQueue** 的练习题实现：用 DAG 就绪队列驱动多个「打工人」在许愿机窗口前许愿，完成带依赖的小愿望任务，并输出带时间戳的许愿记录与判决结果（成功 / 正确的失败）。

## 规则摘要

- **许愿机**：每次只能实现一个小愿望；成功概率 50%；失败可重试；每次耗时 0.5s～1.5s 随机。
- **依赖**：任务构成 DAG；某任务失败且达最大重试后，其下游由队列引擎级联取消（正确的失败）。
- **打工人**：严格按队列引擎 `get_ready()` 取任务、许愿后 `mark_done` / `mark_failed(cascade=True)`。

## 输入

CSV 邻接表，例如：

```csv
task_id,priority,deps
T1,0,
T2,0,
T3,1,T1
T4,1,T2
T5,0,T3;T4
```

- `task_id`：唯一 ID。
- `priority`：数字，越大越优先。
- `deps`：依赖的 `task_id`，多个用分号分隔，空表示无依赖。

## 输出

- **许愿记录**：每条包含 `task_id`、开始时间（start_ts）、结束时间（end_ts）、是否成功、worker_id。
- **节点状态**：每个任务的最终状态（done/failed/canceled）及尝试次数。
- **判决**：`success`（全部完成）、`correct_failure`（存在失败且依赖与级联一致）、`incorrect`（状态不一致）。

## 运行

在仓库根目录下（已安装 TopoQueue，如 `pip install -e .`）：

```bash
# 使用示例 DAG，2 个 worker，结果打印到控制台
python -m examples.wish_engine.run_scheduler examples/wish_engine/sample_dag.csv

# 指定 worker 数并输出到 CSV
python -m examples.wish_engine.run_scheduler examples/wish_engine/sample_dag.csv -n 3 -o wish_log.csv
```

或进入示例目录后（需保证能 import topoqueue）：

```bash
cd examples/wish_engine
python run_scheduler.py sample_dag.csv -n 2 -o out.csv
```

## 文件说明

| 文件 | 说明 |
|------|------|
| `dag_loader.py` | 从 CSV 加载邻接表并转为 TopoQueue 的 `DAGData` |
| `wish_machine.py` | 许愿机模拟（概率、耗时） |
| `run_scheduler.py` | 主流程：队列引擎 + 多 worker + 记录与判决 |
| `verdict.py` | 判决器：与输入 DAG 对比，判断是否为正确的失败 |
| `sample_dag.csv` | 示例 DAG 输入 |
