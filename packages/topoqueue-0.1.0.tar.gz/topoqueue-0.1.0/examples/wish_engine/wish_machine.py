# examples/wish_engine/wish_machine.py
"""
许愿机模拟：每次许愿成功概率 0.5，耗时 0.5s~1.5s 随机。
"""
import random
import time
from dataclasses import dataclass


@dataclass
class WishResult:
    """单次许愿结果。"""
    task_id: str
    start_ts: float   # 开始许愿时间（monotonic）
    end_ts: float     # 得知结果的时刻
    success: bool     # 是否成功


def wish(task_id: str, success_prob: float = 0.5, min_duration: float = 0.5, max_duration: float = 1.5) -> WishResult:
    """
    模拟一次许愿：阻塞随机时间后按概率返回成功/失败。
    """
    start_ts = time.monotonic()
    duration = random.uniform(min_duration, max_duration)
    time.sleep(duration)
    end_ts = time.monotonic()
    success = random.random() < success_prob
    return WishResult(task_id=task_id, start_ts=start_ts, end_ts=end_ts, success=success)
