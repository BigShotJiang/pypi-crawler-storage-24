# examples/wish_engine/run_scheduler.py
"""
许愿机主流程：使用 TopoQueue (DAGQueue) 驱动任务，n 个 worker 按就绪队列依次许愿，
产出带时间戳的许愿记录，并由判决器判断是否为「正确的失败」。
"""
import csv
import queue
import threading
from pathlib import Path

from topoqueue import DAGQueue, State

from .dag_loader import load_tasks_from_csv, tasks_to_dag
from .wish_machine import wish
from .verdict import run_verdict


def worker(
    worker_id: int,
    queue_engine: DAGQueue,
    records: list,
    records_lock: threading.Lock,
) -> None:
    """单个打工人：循环从队列引擎取 READY 任务，许愿后 mark_done 或 mark_failed(cascade=True)。"""
    while not queue_engine.is_finished():
        try:
            node = queue_engine.get_ready(block=True, timeout=0.2)
        except queue.Empty:
            continue
        if node.state == State.CANCELED:
            continue
        result = wish(node.node_id, success_prob=0.5, min_duration=0.5, max_duration=1.5)
        with records_lock:
            records.append({
                "task_id": result.task_id,
                "start_ts": result.start_ts,
                "end_ts": result.end_ts,
                "success": result.success,
                "worker_id": worker_id,
            })
        if result.success:
            queue_engine.mark_done(node.node_id)
        else:
            queue_engine.mark_failed(node.node_id, cascade=True)


def run(
    csv_path: str | Path,
    num_workers: int = 4,
    max_retries: int = 20,
) -> tuple[list[dict], list[dict], str, list[str]]:
    """
    加载 CSV DAG，运行许愿调度，返回 (许愿记录列表, 节点状态摘要, verdict, messages)。
    """
    tasks = load_tasks_from_csv(csv_path)
    data = tasks_to_dag(tasks, max_retries=max_retries)
    engine = DAGQueue(data=data)
    engine.validate()

    records = []
    records_lock = threading.Lock()
    workers = [
        threading.Thread(target=worker, args=(i, engine, records, records_lock))
        for i in range(num_workers)
    ]
    for t in workers:
        t.start()
    engine.join()
    for t in workers:
        t.join()

    # 按 start_ts 排序输出
    records.sort(key=lambda r: (r["start_ts"], r["task_id"]))

    # 节点状态摘要（队列引擎与 data 共享同一批 Node 引用，状态已更新）
    nodes = data.nodes
    summary = []
    for nid, node in nodes.items():
        summary.append({
            "task_id": nid,
            "state": node.state.value,
            "attempts": node.attempts,
        })

    verdict, messages = run_verdict(nodes)
    return records, summary, verdict, messages


def write_output_csv(records: list[dict], summary: list[dict], output_path: str | Path) -> None:
    """将许愿记录与状态摘要写入 CSV（带时间戳：开始时间、成功/结束时间）。"""
    path = Path(output_path)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["task_id", "start_ts", "end_ts", "success", "worker_id"])
        for r in records:
            w.writerow([r["task_id"], f"{r['start_ts']:.6f}", f"{r['end_ts']:.6f}", r["success"], r["worker_id"]])
        w.writerow([])
        w.writerow(["task_id", "state", "attempts"])
        for s in summary:
            w.writerow([s["task_id"], s["state"], s["attempts"]])


def main():
    import argparse
    p = argparse.ArgumentParser(description="许愿机示例：从 CSV 加载 DAG，多 worker 许愿并输出带时间戳记录与判决。")
    p.add_argument("input_csv", type=str, help="输入 CSV 邻接表路径")
    p.add_argument("-n", "--workers", type=int, default=2, help="打工人数量（许愿机窗口数）")
    p.add_argument("--max-retries", type=int, default=3, help="每任务最大重试次数")
    p.add_argument("-o", "--output", type=str, default="", help="输出 CSV 路径（不指定则只打印）")
    args = p.parse_args()

    records, summary, verdict, messages = run(args.input_csv, num_workers=args.workers, max_retries=args.max_retries)

    print("=== 许愿记录（开始时间、结束时间）===")
    for r in records:
        print(f"  {r['task_id']}: start={r['start_ts']:.3f}, end={r['end_ts']:.3f}, success={r['success']}")
    print("\n=== 节点状态 ===")
    for s in summary:
        print(f"  {s['task_id']}: {s['state']}, attempts={s['attempts']}")
    print("\n=== 判决 ===")
    print(f"  结果: {verdict}")
    for m in messages:
        print(f"  {m}")

    if args.output:
        write_output_csv(records, summary, args.output)
        print(f"\n已写入: {args.output}")


if __name__ == "__main__":
    main()
