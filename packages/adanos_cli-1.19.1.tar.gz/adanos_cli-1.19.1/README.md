# adanos-cli

Comprehensive CLI for the Finance Sentiment API at `https://api.adanos.org`.

The CLI is designed as a reliable workflow tool to retrieve social sentiment for stocks and crypto assets, with machine-readable output for automation.

## Data Coverage

The API/CLI currently covers:
- Reddit Stocks
- X/Twitter Stocks
- Polymarket Stocks
- Reddit Crypto

What this means in practice:
- Stock reports aggregate multiple social sources (Reddit + X + Polymarket where available).
- Crypto reports currently use Reddit Crypto endpoints.
- If there are no mentions in the selected window, you can receive a valid response with no rows/no data.

## Install

### Recommended (PyPI)

```bash
python3 -m pip install adanos-cli
```

If you use `pipx`:

```bash
pipx install adanos-cli
```

If this returns `No matching distribution found`, the first PyPI release is not published yet.

### Until first public release is available

```bash
# requires GitHub access + SSH key to this private repository
python3 -m pip install "git+ssh://git@github.com/alexander-schneider/api.adanos.org.git@main#subdirectory=sdk/cli"
```

### Developer install (local clone)

```bash
python3 -m pip install -e sdk/cli
```

### If `adanos` is not found in your shell

```bash
python3 -m adanos_cli --version
python3 -m adanos_cli
```

### Maintainer: Publish to PyPI

Publishing is automated in `.github/workflows/publish-sdk.yml` (Trusted Publishing):
- triggers on `VERSION` change (or manual dispatch)
- syncs versions into SDK + CLI metadata
- tests and builds `sdk/python` and `sdk/cli`
- validates package metadata with `twine check`
- publishes both Python packages to PyPI

Typical release flow:
1. bump `VERSION`
2. update `CHANGELOG.md`
3. merge to `main` (or trigger workflow manually)

One-time PyPI setup (required before first publish):
1. Create `adanos-cli` on PyPI (or use the existing project if already created).
2. In PyPI: `Project settings -> Publishing -> Add a new pending publisher`.
3. Set publisher values:
   - Owner: `alexander-schneider`
   - Repository: `api.adanos.org`
   - Workflow name: `publish-sdk.yml`
   - Environment name: `pypi`

## Start Modes

```bash
# interactive shell (recommended for humans)
adanos

# force shell mode explicitly
adanos shell

# one-shot command mode
adanos stock TSLA --days 7
```

## Quickstart By Perspective

### 1) First-time user (no API key yet)

```bash
# guided setup
adanos onboard wizard

# or manual setup
adanos onboard register --name "Your Name" --email "you@example.com" --purpose "CLI usage"
adanos onboard redeem --token kt_xxx --save

# first request
adanos ask "How does TSLA look?"
```

### 2) Existing user (already has key)

```bash
adanos config set --api-key sk_live_xxx
adanos config show
adanos account
adanos ask "How many users mention Microsoft?"
```

### 3) Stock sentiment workflow

```bash
# deep report for one ticker
adanos stock TSLA --days 7

# compare tickers
adanos ask "TSLA vs NVDA"
# or
adanos compare --platform x-stocks TSLA,NVDA --days 7

# top lists
adanos trending --platform reddit-stocks --dimension main --days 1 --limit 10
```

### 4) Crypto sentiment workflow

```bash
# single token
adanos crypto BTC --days 7

# pair comparison
adanos crypto BTC/ETH --days 7

# discovery
adanos scan --asset crypto --style daytrader
```

### 5) Portfolio/watchlist workflow

```bash
adanos watchlist add core --asset stocks --symbols MSFT,AAPL,NVDA
adanos watchlist add core --asset crypto --symbols BTC,ETH
adanos watchlist show core
adanos watchlist report core --asset all --days 7
```

### 6) Automation / agent workflow (JSON)

```bash
adanos --output json capabilities
adanos --output json endpoint list
adanos --output json ask "How does TSLA look?"
adanos --output json scan --asset stocks --style daytrader
```

Note: global flags are recommended before subcommands. The CLI also tolerates `capabilities --output json` style input.

## Interactive Shell

Start:

```bash
adanos
```

Behavior:
- Plain text is interpreted as `ask`.
- Slash-prefixed commands run CLI commands directly.
- `scan` shorthand works:
  - `/scan` -> defaults to stocks starter scan
  - `/scan crypto` -> crypto scan
- `/help`, `/clear`, `/exit` are built-in shell controls.

Fullscreen and scrollback:
- Default keeps terminal scrollback usable.
- Optional fullscreen mode:

```bash
adanos shell --fullscreen
# or via env
ADANOS_CLI_FULLSCREEN=1 adanos shell
```

## Global Flags

Available for all commands:

```bash
adanos [--api-key KEY] [--base-url URL] [--output text|json] [--version] <command> ...
```

- `--api-key`: override configured key for this call
- `--base-url`: override API base URL
- `--output`: choose `text` or `json`
- `--version`: print version and exit

## Complete Command Reference

### `onboard`

```bash
adanos onboard
adanos onboard guide
adanos onboard wizard [--json]
adanos onboard register --name NAME --email EMAIL --purpose PURPOSE [--company-name NAME] [--json]
adanos onboard redeem --token kt_xxx [--save] [--json]
```

### `config`

```bash
adanos config set --api-key sk_live_xxx [--base-url URL]
adanos config show
adanos config clear
```

### `capabilities`

```bash
adanos capabilities
adanos --output json capabilities
```

### `account`

```bash
adanos account
adanos account --json
```

Shows:
- current account plan (`free`, `hobby`, `professional`)
- monthly credits used/remaining (or `unlimited` for paid plans)
- out-of-credits state on free tier
- upgrade options + contact

### `shell`

```bash
adanos shell [--fullscreen | --no-fullscreen]
```

### `stock`

```bash
adanos stock TICKER [--days 7] [--json]
```

### `crypto`

```bash
adanos crypto SYMBOL_OR_PAIR [--days 7] [--json]
# examples: BTC, ETH, BTC/ETH
```

### `ask`

```bash
adanos ask "free text question" [--days 7] [--json]
```

### `scan`

```bash
adanos scan --asset {stocks|crypto}
            [--style {starter|daytrader|swing|investor}]
            [--days N] [--limit N] [--top N]
            [--min-buzz X] [--min-volume N] [--min-platforms N]
            [--min-sentiment X] [--max-sentiment X]
            [--json]
```

### `briefing`

```bash
adanos briefing [--profile {starter|daytrader|swing|investor|crypto|research|portfolio}]
                [--days N] [--limit N]
                [--stocks CSV] [--crypto CSV]
                [--from-watchlist NAME]
                [--json]
```

### `watchlist`

```bash
adanos watchlist list [--json]
adanos watchlist show NAME [--json]
adanos watchlist add NAME --asset {stocks|crypto} --symbols CSV [--json]
adanos watchlist remove NAME --asset {stocks|crypto} --symbols CSV [--json]
adanos watchlist delete NAME [--json]
adanos watchlist report NAME [--asset {stocks|crypto|all}] [--days N] [--json]
```

### `endpoint`

```bash
adanos endpoint list [--json]
adanos endpoint call ENDPOINT_ID
                     [--ticker T] [--symbol S] [--q Q] [--query Q]
                     [--tickers CSV] [--symbols CSV] [--assets CSV]
                     [--days N] [--limit N] [--offset N] [--type stock|etf|all]
                     [--source SOURCE]
                     [--json]
```

### `trending`

```bash
adanos trending --platform {news-stocks|reddit-stocks|reddit-crypto|x-stocks|polymarket-stocks}
                [--dimension {main|sectors|countries|tokens}]
                [--days N] [--limit N] [--offset N]
                [--type {stock|etf|all}]
                [--source SOURCE]
                [--json]
```

### `search`

```bash
adanos search --platform {news-stocks|reddit-stocks|reddit-crypto|x-stocks|polymarket-stocks} QUERY [--json]
```

### `compare`

```bash
adanos compare --platform {news-stocks|reddit-stocks|reddit-crypto|x-stocks|polymarket-stocks} ASSETS_CSV [--days N] [--json]
```

### `stats`

```bash
adanos stats --platform {news-stocks|reddit-stocks|reddit-crypto|x-stocks|polymarket-stocks} [--json]
```

### `health`

```bash
adanos health [--platform {all|news-stocks|reddit-stocks|reddit-crypto|x-stocks|polymarket-stocks}] [--json]
```

## Endpoint Coverage Guarantee

`adanos endpoint list` exposes one CLI endpoint ID per OpenAPI path.

`adanos endpoint call <endpoint-id> ...` allows direct invocation of every supported OpenAPI endpoint.

## Config Resolution Order

1. CLI flags (`--api-key`, `--base-url`)
2. Environment (`ADANOS_API_KEY`, `ADANOS_BASE_URL`)
3. Local config file (`~/.config/adanos-cli/config.json`)

## Reliability Recommendations

For the most stable sentiment snapshots:
- Use direct symbols/tickers (`stock`, `crypto`, `compare`) when possible.
- Use broader windows for less-liquid assets (`--days 7` or `--days 30`).
- Check service health first if results look stale:

```bash
adanos health --platform all
```

If you hit rate/credit limits:

```bash
adanos account
```
