"""Watchlist command tests."""

from __future__ import annotations

import json
import sys
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[3]
SDK_PYTHON_SRC = REPO_ROOT / "sdk" / "python" / "src"
SDK_CLI_SRC = REPO_ROOT / "sdk" / "cli" / "src"

for path in (REPO_ROOT, SDK_CLI_SRC, SDK_PYTHON_SRC):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

import adanos_cli.config as cli_config
import adanos_cli.main as cli_main


def _isolate_config(tmp_path: Path, monkeypatch) -> None:
    cfg_dir = tmp_path / ".config" / "adanos-cli"
    cfg_path = cfg_dir / "config.json"
    monkeypatch.setattr(cli_config, "CONFIG_DIR", cfg_dir)
    monkeypatch.setattr(cli_config, "CONFIG_PATH", cfg_path)
    monkeypatch.setattr(cli_main, "CONFIG_PATH", cfg_path)


def test_watchlist_crud_flow(tmp_path, monkeypatch, capsys) -> None:
    _isolate_config(tmp_path, monkeypatch)

    assert cli_main.main(["watchlist", "add", "core", "--asset", "stocks", "--symbols", "MSFT,AAPL", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["core"]["stocks"] == ["MSFT", "AAPL"]

    assert cli_main.main(["watchlist", "add", "core", "--asset", "crypto", "--symbols", "BTC,ETH", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["core"]["crypto"] == ["BTC", "ETH"]

    assert cli_main.main(["watchlist", "show", "core", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["core"]["stocks"] == ["MSFT", "AAPL"]
    assert payload["core"]["crypto"] == ["BTC", "ETH"]

    assert cli_main.main(["watchlist", "remove", "core", "--asset", "stocks", "--symbols", "AAPL", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["core"]["stocks"] == ["MSFT"]

    assert cli_main.main(["watchlist", "list", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert "core" in payload

    assert cli_main.main(["watchlist", "delete", "core", "--json"]) == 0
    payload = json.loads(capsys.readouterr().out)
    assert payload["deleted"] is True
