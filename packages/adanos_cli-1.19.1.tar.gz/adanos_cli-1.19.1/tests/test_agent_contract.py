"""Agent-friendly CLI contract tests."""

from __future__ import annotations

import json
import sys
from pathlib import Path


REPO_ROOT = Path(__file__).resolve().parents[3]
SDK_PYTHON_SRC = REPO_ROOT / "sdk" / "python" / "src"
SDK_CLI_SRC = REPO_ROOT / "sdk" / "cli" / "src"

for path in (REPO_ROOT, SDK_CLI_SRC, SDK_PYTHON_SRC):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

import adanos_cli.config as cli_config  # noqa: E402
import adanos_cli.main as cli_main  # noqa: E402
from adanos_cli import __version__  # noqa: E402
from adanos_cli.endpoints import ENDPOINTS  # noqa: E402


def _isolate_config(tmp_path: Path, monkeypatch) -> None:
    cfg_dir = tmp_path / ".config" / "adanos-cli"
    cfg_path = cfg_dir / "config.json"
    monkeypatch.setattr(cli_config, "CONFIG_DIR", cfg_dir)
    monkeypatch.setattr(cli_config, "CONFIG_PATH", cfg_path)
    monkeypatch.setattr(cli_main, "CONFIG_PATH", cfg_path)


def test_version_json(capsys) -> None:
    rc = cli_main.main(["--output", "json", "--version"])
    out = capsys.readouterr().out
    assert rc == 0
    payload = json.loads(out)
    assert payload["name"] == "adanos-cli"
    assert payload["version"] == __version__


def test_capabilities_json(tmp_path, monkeypatch, capsys) -> None:
    _isolate_config(tmp_path, monkeypatch)
    monkeypatch.delenv("ADANOS_API_KEY", raising=False)
    rc = cli_main.main(["--output", "json", "capabilities"])
    out = capsys.readouterr().out
    assert rc == 0
    payload = json.loads(out)
    assert payload["name"] == "adanos-cli"
    assert payload["endpoint_count"] == len(ENDPOINTS)
    assert payload["error_channel"] == "stderr"
    assert payload["output_modes"] == ["text", "json"]
    assert "shell" in payload["commands"]


def test_missing_api_key_emits_json_error_on_stderr(tmp_path, monkeypatch, capsys) -> None:
    _isolate_config(tmp_path, monkeypatch)
    monkeypatch.delenv("ADANOS_API_KEY", raising=False)
    monkeypatch.delenv("ADANOS_BASE_URL", raising=False)
    rc = cli_main.main(["--output", "json", "ask", "stock", "TSLA"])
    captured = capsys.readouterr()
    assert rc == 2
    assert captured.out == ""
    payload = json.loads(captured.err)
    assert payload["ok"] is False
    assert payload["error"]["code"] == "api_key_missing"


def test_global_output_json_applies_to_endpoint_list(capsys) -> None:
    rc = cli_main.main(["--output", "json", "endpoint", "list"])
    out = capsys.readouterr().out
    assert rc == 0
    payload = json.loads(out)
    assert isinstance(payload, list)
    assert any(row["id"] == "reddit-stocks.trending" for row in payload)


def test_global_output_json_after_subcommand_is_accepted(capsys) -> None:
    rc = cli_main.main(["capabilities", "--output", "json"])
    out = capsys.readouterr().out
    assert rc == 0
    payload = json.loads(out)
    assert payload["name"] == "adanos-cli"


def test_endpoint_list_output_json_after_subcommand_is_accepted(capsys) -> None:
    rc = cli_main.main(["endpoint", "list", "--output", "json"])
    out = capsys.readouterr().out
    assert rc == 0
    payload = json.loads(out)
    assert isinstance(payload, list)
    assert any(row["id"] == "reddit-stocks.trending" for row in payload)


class _SearchNamespace:
    def __init__(self, rows: list[dict]):
        self._rows = rows

    def search(self, query: str):
        query_upper = query.upper()
        matched = []
        for row in self._rows:
            name = str(row.get("name") or "").upper()
            aliases = [str(alias).upper() for alias in row.get("aliases", [])]
            ticker = str(row.get("ticker") or "").upper()
            if query_upper in name or query_upper in ticker or any(query_upper in alias for alias in aliases):
                matched.append(row)
        return {"query": query, "count": len(matched), "results": matched}


class _AliasClient:
    def __init__(self):
        rows = [{"ticker": "MSFT", "name": "Microsoft Corporation"}]
        self.reddit = _SearchNamespace(rows)
        self.x = _SearchNamespace(rows)
        self.polymarket = _SearchNamespace(rows)


def test_alias_resolution_resolves_company_name_to_ticker() -> None:
    client = _AliasClient()
    ticker, query, source = cli_main._resolve_stock_ticker(
        client,
        "wie viele user reden über Microsoft?",
        "MICROSOFT",
    )
    assert ticker == "MSFT"
    assert query == "MICROSOFT"
    assert source in {"reddit", "x", "polymarket"}
