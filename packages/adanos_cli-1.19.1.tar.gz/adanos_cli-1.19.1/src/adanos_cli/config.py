"""CLI configuration handling."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path

DEFAULT_BASE_URL = "https://api.adanos.org"
CONFIG_DIR = Path.home() / ".config" / "adanos-cli"
CONFIG_PATH = CONFIG_DIR / "config.json"


@dataclass(frozen=True)
class RuntimeConfig:
    api_key: str
    base_url: str


def load_config_file() -> dict:
    if not CONFIG_PATH.exists():
        return {}
    try:
        return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except Exception:
        return {}


def save_config_file(*, api_key: str | None = None, base_url: str | None = None) -> None:
    current = load_config_file()
    if api_key is not None:
        current["api_key"] = api_key
    if base_url is not None:
        current["base_url"] = base_url

    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_PATH.write_text(json.dumps(current, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def clear_config_file() -> None:
    if CONFIG_PATH.exists():
        CONFIG_PATH.unlink()


def resolve_runtime_config(*, api_key_override: str | None = None, base_url_override: str | None = None) -> RuntimeConfig:
    file_cfg = load_config_file()
    api_key = (
        api_key_override
        or os.getenv("ADANOS_API_KEY")
        or str(file_cfg.get("api_key") or "")
    ).strip()
    base_url = (
        base_url_override
        or os.getenv("ADANOS_BASE_URL")
        or str(file_cfg.get("base_url") or DEFAULT_BASE_URL)
    ).strip()

    if not base_url:
        base_url = DEFAULT_BASE_URL

    return RuntimeConfig(api_key=api_key, base_url=base_url.rstrip("/"))


def masked_key(api_key: str) -> str:
    key = (api_key or "").strip()
    if len(key) < 10:
        return "(not set)"
    return f"{key[:10]}...{key[-4:]}"
