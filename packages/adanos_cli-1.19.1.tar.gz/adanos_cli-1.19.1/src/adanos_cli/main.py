"""Adanos CLI entrypoint."""

from __future__ import annotations

import argparse
import json
import os
import re
import shlex
import sys
from argparse import Namespace
from pathlib import Path
from typing import Any

import httpx

from . import __version__
from .config import (
    CONFIG_PATH,
    DEFAULT_BASE_URL,
    clear_config_file,
    load_config_file,
    masked_key,
    resolve_runtime_config,
    save_config_file,
)
from .endpoints import ENDPOINTS, invoke_endpoint, is_health_endpoint, list_endpoints
from .nlp import extract_terms, parse_ask_intent
from .summaries import (
    build_stock_compare_report,
    build_stock_scan_report,
    build_crypto_scan_report,
    build_market_briefing_report,
    build_trending_report,
    build_crypto_compare_report,
    build_crypto_report,
    build_search_fallback_report,
    build_stock_report,
    format_stock_scan_report,
    format_crypto_scan_report,
    format_market_briefing_report,
    format_stock_compare_report,
    format_trending_report,
    format_crypto_compare_report,
    format_crypto_report,
    format_search_fallback_report,
    format_stock_report,
)
from .utils import CliUsageError, csv_to_list, print_err, print_json, to_plain
from .watchlists import (
    delete_watchlist,
    get_watchlist,
    list_watchlists,
    remove_watchlist_symbols,
    upsert_watchlist_symbols,
)

SUPPORT_CONTACT_EMAIL = "support@adanos.org"
PAID_ACCOUNT_TYPES = {"hobby", "professional"}


def _load_sdk_client_class() -> Any:
    try:
        from stocksentiment import StockSentimentClient
        return StockSentimentClient
    except ImportError:
        sdk_python_src = Path(__file__).resolve().parents[3] / "python" / "src"
        if sdk_python_src.exists() and str(sdk_python_src) not in sys.path:
            sys.path.insert(0, str(sdk_python_src))
        from stocksentiment import StockSentimentClient
        return StockSentimentClient


def _print_onboarding_guide(base_url: str, *, has_api_key: bool = False) -> None:
    if has_api_key:
        print("API key is already configured.")
        print("Use onboarding only if you want to replace your key.")
    else:
        print("API key is not configured.")

    print("Guided setup (no curl):")
    print("1) Recommended: run the interactive wizard")
    print("   adanos onboard wizard")
    print("2) Manual alternative:")
    print('   adanos onboard register --name "Your Name" --email "you@example.com" --purpose "CLI usage for stocks and crypto"')
    print("   adanos onboard redeem --token <delivery_token> --save")
    print("3) Start using the API:")
    print('   adanos ask "How does TSLA look?"')
    print(f"API base URL: {base_url}")


def _supports_color() -> bool:
    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        return False
    if os.getenv("NO_COLOR") is not None:
        return False
    term = (os.getenv("TERM") or "").lower()
    if not term or term == "dumb":
        return False
    return True


def _style(text: str, *, fg: str | None = None, bold: bool = False, dim: bool = False) -> str:
    if not _supports_color():
        return text
    colors = {
        "red": "31",
        "green": "32",
        "yellow": "33",
        "blue": "34",
        "magenta": "35",
        "cyan": "36",
        "white": "37",
        "orange": "38;5;209",
    }
    codes: list[str] = []
    if bold:
        codes.append("1")
    if dim:
        codes.append("2")
    if fg and fg in colors:
        codes.append(colors[fg])
    if not codes:
        return text
    return f"\033[{';'.join(codes)}m{text}\033[0m"


def _print_welcome_screen(base_url: str, *, has_api_key: bool) -> None:
    print(_style("ADANOS CLI", fg="cyan", bold=True))
    print(_style("Stocks + Crypto sentiment for api.adanos.org", dim=True))
    print("")
    key_label = _style("configured", fg="green", bold=True) if has_api_key else _style("not configured", fg="red", bold=True)
    print(f"API base URL: {_style(base_url, fg='blue')}")
    print(f"API key: {key_label}")
    print("")
    print(_style("Examples:", fg="yellow", bold=True))
    print('  adanos ask "How does stock TSLA look?"')
    print('  adanos ask "How many users mention Microsoft?"')
    print('  adanos ask "crypto btc/eth"')
    print("")
    if has_api_key:
        print(_style("Quick start:", fg="green", bold=True))
        print('  adanos ask "stock AAPL"')
        print("  adanos scan --asset stocks --style daytrader")
        print("  adanos endpoint list")
    else:
        print(_style("Setup in 2 steps:", fg="yellow", bold=True))
        print("  1) adanos onboard wizard")
        print("  2) or manual: adanos onboard register ... + adanos onboard redeem --token ... --save")
    print("")
    print(_style("Core commands:", fg="cyan", bold=True))
    print("  adanos stock <TICKER> --days 7")
    print("  adanos crypto <SYMBOL|SYMBOL/SYMBOL> --days 7")
    print("  adanos account")
    print("  adanos briefing --profile investor --days 30")
    print("  adanos watchlist report core --asset all")
    print("")
    print(f"More help: {_style('adanos --help', fg='magenta', bold=True)}")


def _print_shell_header(base_url: str, *, has_api_key: bool, api_key_status: str | None = None) -> None:
    logo_lines = [
        "      /\\      ",
        "     /  \\     ",
        "    / /\\ \\    ",
        "   / ____ \\   ",
        "  /_/    \\_\\  ",
    ]
    key_status = api_key_status if api_key_status is not None else (
        _style("configured", fg="green", bold=True) if has_api_key else _style("not configured", fg="red", bold=True)
    )
    details = [
        f"{_style('Adanos Finance Sentiment CLI', fg='cyan', bold=True)} {_style(f'v{__version__}', fg='magenta', bold=True)}",
        f"cwd: {_style(str(Path.cwd()), fg='white')}",
        f"api: {_style(base_url, fg='blue')}",
        f"api_key: {key_status}",
    ]

    logo_width = max(len(line) for line in logo_lines)
    row_count = max(len(logo_lines), len(details))
    for idx in range(row_count):
        left_raw = logo_lines[idx] if idx < len(logo_lines) else " " * logo_width
        left = _style(left_raw, fg="orange", bold=True)
        right = details[idx] if idx < len(details) else ""
        print(f"{left}  {right}")

    print(_style("-" * 68, dim=True))


def _print_shell_quickstart(*, has_api_key: bool) -> None:
    print(_style("Quick Start", fg="cyan", bold=True))
    if has_api_key:
        print('  Ask in plain text: "How does TSLA look this week?"')
        print("  Stock report: /stock TSLA --days 7")
        print("  Crypto report: /crypto BTC/ETH --days 7")
        print("  Screener: /scan --asset stocks --style starter")
        print("  Plan/Credits: /account")
    else:
        print("  1) Configure API key: /onboard wizard")
        print("  2) Or set existing key: /config set --api-key sk_live_xxx")
        print('  3) First query: /ask "How does TSLA look?"')
    print(_style("Type /help for full command catalog.", dim=True))
    print("")


def _print_shell_help(*, has_api_key: bool) -> None:
    print(_style("Guided Help", fg="cyan", bold=True))
    print("  The shell accepts both slash commands and plain text questions.")
    print("")
    print(_style("First Steps", fg="cyan", bold=True))
    if has_api_key:
        print("  1) Ask directly in plain text:")
        print('     How does TSLA look this week?')
        print("  2) Run a sentiment screen:")
        print("     /scan --asset stocks --style daytrader")
        print("  3) Check key plan and monthly credits:")
        print("     /account")
    else:
        print("  1) Configure your API key:")
        print("     /onboard wizard")
        print("  2) Alternative if key already exists:")
        print("     /config set --api-key sk_live_xxx")
        print("  3) Run your first query:")
        print('     /ask "How does TSLA look?"')
    print("")
    print(_style("Command Catalog", fg="cyan", bold=True))
    print("  Setup + Config")
    print("    /onboard guide|wizard|register|redeem")
    print("    /config show|set|clear")
    print("    /account")
    print("")
    print("  Analysis")
    print('    /ask "free text question"')
    print("    /stock TICKER --days 7")
    print("    /crypto SYMBOL or /crypto BTC/ETH --days 7")
    print("    /scan --asset stocks|crypto --style starter|daytrader|swing|investor")
    print("    /briefing --profile starter|daytrader|swing|investor|crypto|research|portfolio")
    print("")
    print("  Lists + Platform Queries")
    print("    /watchlist list|show|add|remove|report|delete")
    print("    /trending --platform ... --dimension ...")
    print("    /search --platform ... QUERY")
    print("    /compare --platform ... ASSETS_CSV")
    print("    /stats --platform ...")
    print("    /health --platform all|news-stocks|reddit-stocks|reddit-crypto|x-stocks|polymarket-stocks")
    print("")
    print("  Power / API Coverage")
    print("    /endpoint list")
    print("    /endpoint call <endpoint-id> [params]")
    print("    /capabilities --output json")
    print("    Tip: run /endpoint list to see every supported endpoint id.")
    print("")
    print(_style("Shell Controls", fg="cyan", bold=True))
    print("  /help           show this guide")
    print("  /clear          clear screen and redraw header")
    print("  /exit           exit shell")
    print("  /<command> ...  run any CLI command")


def _shell_enter_fullscreen() -> None:
    # Use alternate screen buffer to provide a clean fullscreen-like shell UI.
    if sys.stdin.isatty() and sys.stdout.isatty():
        print("\033[?1049h\033[2J\033[H", end="", flush=True)


def _shell_exit_fullscreen() -> None:
    if sys.stdin.isatty() and sys.stdout.isatty():
        print("\033[?1049l", end="", flush=True)


def _shell_clear_start_screen() -> None:
    # Clear current screen and scrollback so CLI starts with a clean terminal.
    if sys.stdin.isatty() and sys.stdout.isatty():
        print("\033[3J\033[2J\033[H", end="", flush=True)


def _shell_fullscreen_default() -> bool:
    value = str(os.getenv("ADANOS_CLI_FULLSCREEN", "")).strip().lower()
    return value in {"1", "true", "yes", "on"}


def _resolve_shell_fullscreen(flag_value: bool | None) -> bool:
    if flag_value is not None:
        return bool(flag_value)
    return _shell_fullscreen_default()


def _is_shell_meta_command(token: str) -> bool:
    return token in {"help", "exit", "quit", "clear"}


def _is_cli_command(token: str) -> bool:
    return token in {
        "onboard",
        "config",
        "capabilities",
        "shell",
        "scan",
        "briefing",
        "watchlist",
        "endpoint",
        "stock",
        "crypto",
        "ask",
        "trending",
        "search",
        "compare",
        "stats",
        "health",
        "account",
    }


def _shell_line_to_argv(raw: str) -> list[str] | None:
    line = raw.strip()
    if not line:
        return None

    for prefix in ("adanos-cli ", "adanos "):
        if line.startswith(prefix):
            line = line[len(prefix) :].strip()
            if not line:
                return None
            return shlex.split(line)

    if line.startswith("/"):
        line = line[1:].strip()
        if not line:
            return None
        return shlex.split(line)

    tokens = shlex.split(line)
    if not tokens:
        return None
    head = tokens[0].lower()
    if _is_cli_command(head) or _is_shell_meta_command(head) or head.startswith("--"):
        return tokens

    # Default behavior: treat free text as ask intent.
    return ["ask", raw]


def _normalize_shell_argv(argv: list[str]) -> list[str]:
    if not argv:
        return argv

    command = argv[0].lower()
    if command != "scan":
        return argv

    # If --asset is already provided, keep command unchanged.
    if any(token == "--asset" for token in argv[1:]):
        return argv

    # Shorthand: `/scan crypto` or `/scan stocks`
    if len(argv) >= 2 and not argv[1].startswith("--"):
        asset_token = argv[1].lower()
        if asset_token in {"stock", "stocks"}:
            return ["scan", "--asset", "stocks", *argv[2:]]
        if asset_token in {"crypto", "coin", "coins"}:
            return ["scan", "--asset", "crypto", *argv[2:]]

    # Sensible default for `/scan` and `/scan --style ...`
    if len(argv) == 1:
        return ["scan", "--asset", "stocks", "--style", "starter"]
    return ["scan", "--asset", "stocks", *argv[1:]]


def _run_shell(base_url: str, *, has_api_key: bool, use_fullscreen: bool, api_key: str | None = None) -> int:
    account_status = _resolve_shell_account_status(base_url, api_key or "") if has_api_key and api_key else None
    api_key_status = _format_shell_api_key_status(has_api_key=has_api_key, account_status=account_status)
    if use_fullscreen:
        _shell_enter_fullscreen()
    else:
        _shell_clear_start_screen()
    try:
        _print_shell_header(base_url, has_api_key=has_api_key, api_key_status=api_key_status)
        _print_shell_quickstart(has_api_key=has_api_key)

        while True:
            try:
                raw = input("adanos-cli> ").strip()
            except EOFError:
                print("\nExiting ADANOS CLI.")
                return 0
            except KeyboardInterrupt:
                print("\nInterrupted. Type /exit to quit.")
                continue

            argv = _shell_line_to_argv(raw)
            if not argv:
                continue
            argv = _normalize_shell_argv(argv)

            command = argv[0].lower()
            if command in {"exit", "quit"}:
                print("Bye.")
                return 0
            if command == "help":
                _print_shell_help(has_api_key=has_api_key)
                continue
            if command == "clear":
                print("\033[2J\033[H", end="")
                _print_shell_header(base_url, has_api_key=has_api_key, api_key_status=api_key_status)
                continue
            if command == "shell":
                print_err("usage_error: already running inside shell")
                continue

            rc = main(argv)
            if rc != 0:
                print_err(f"command_failed: exit code {rc}")
    finally:
        if use_fullscreen:
            _shell_exit_fullscreen()


def _wants_json(args: Namespace) -> bool:
    if getattr(args, "output", "text") == "json":
        return True
    return bool(getattr(args, "json", False))


def _normalize_global_cli_flags(argv: list[str]) -> list[str]:
    """Allow global flags to appear after subcommands by hoisting them to the front."""
    value_flags = {"--api-key", "--base-url", "--output"}
    bare_flags = {"--version"}

    moved: list[str] = []
    rest: list[str] = []
    idx = 0
    while idx < len(argv):
        token = argv[idx]
        if token in bare_flags:
            moved.append(token)
            idx += 1
            continue
        if token in value_flags:
            if idx + 1 < len(argv):
                moved.extend([token, argv[idx + 1]])
                idx += 2
                continue
            # Keep invalid trailing flag in place so argparse can raise a proper error.
            rest.append(token)
            idx += 1
            continue
        if any(token.startswith(prefix + "=") for prefix in value_flags):
            moved.append(token)
            idx += 1
            continue

        rest.append(token)
        idx += 1

    return moved + rest


def _emit_error(
    *,
    json_mode: bool,
    code: str,
    message: str,
    hint: str | None = None,
    status_code: int | None = None,
) -> None:
    if json_mode:
        payload: dict[str, Any] = {
            "ok": False,
            "error": {
                "code": code,
                "message": message,
            },
        }
        if hint:
            payload["error"]["hint"] = hint
        if status_code is not None:
            payload["error"]["status_code"] = status_code
        print_json(payload, file=sys.stderr)
        return

    line = f"{code}: {message}"
    if hint:
        line += f" | hint: {hint}"
    print_err(line)


def _capabilities_payload(base_url: str, *, has_api_key: bool) -> dict[str, Any]:
    commands = [
        "onboard",
        "config",
        "capabilities",
        "shell",
        "scan",
        "briefing",
        "watchlist",
        "endpoint",
        "stock",
        "crypto",
        "ask",
        "trending",
        "search",
        "compare",
        "stats",
        "health",
        "account",
    ]
    return {
        "name": "adanos-cli",
        "version": __version__,
        "api_base_url": base_url,
        "api_key_configured": has_api_key,
        "output_modes": ["text", "json"],
        "error_channel": "stderr",
        "exit_codes": {
            "0": "success",
            "1": "runtime_error",
            "2": "usage_or_auth_error",
        },
        "commands": commands,
        "endpoint_count": len(ENDPOINTS),
        "auth": {
            "header": "X-API-Key",
            "setup": [
                "adanos onboard wizard",
                "adanos onboard register --name ... --email ... --purpose ...",
                "adanos onboard redeem --token <delivery_token> --save",
            ],
            "alternatives": [
                "adanos config set --api-key sk_live_xxx",
                "ADANOS_API_KEY env var",
                "--api-key flag",
            ],
        },
        "discovery_commands": [
            "adanos --output json capabilities",
            "adanos --output json endpoint list",
            "adanos --help",
        ],
    }


def _print_capabilities_text(payload: dict[str, Any]) -> None:
    print("CLI capabilities")
    print(f"- name: {payload['name']}")
    print(f"- version: {payload['version']}")
    print(f"- endpoint_count: {payload['endpoint_count']}")
    print(f"- output_modes: {', '.join(payload['output_modes'])}")
    print(f"- error_channel: {payload['error_channel']}")
    print(f"- api_key_configured: {payload['api_key_configured']}")
    print("- discovery:")
    for cmd in payload["discovery_commands"]:
        print(f"  {cmd}")


def _extract_error_message(response: httpx.Response) -> str:
    try:
        payload = response.json()
    except Exception:
        payload = None

    if isinstance(payload, dict):
        detail = payload.get("detail")
        if isinstance(detail, str) and detail.strip():
            return detail.strip()
        if isinstance(detail, dict):
            message = detail.get("message")
            if isinstance(message, str) and message.strip():
                return message.strip()
            error = detail.get("error")
            if isinstance(error, str) and error.strip():
                return error.strip()
        message = payload.get("message")
        if isinstance(message, str) and message.strip():
            return message.strip()
        error = payload.get("error")
        if isinstance(error, str) and error.strip():
            return error.strip()

    text = (response.text or "").strip()
    return text if text else f"HTTP {response.status_code}"


def _decode_json_dict(response: httpx.Response) -> dict[str, Any] | None:
    try:
        payload = response.json()
    except Exception:
        return None
    return payload if isinstance(payload, dict) else None


def _to_optional_int(value: Any) -> int | None:
    if value is None:
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        value = value.strip()
        if not value:
            return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _coerce_account_type(value: Any) -> str:
    raw = str(value or "").strip().lower()
    if raw == "premium":
        return "professional"
    return raw if raw else "unknown"


def _extract_error_detail(data: dict[str, Any] | None) -> dict[str, Any] | None:
    if not isinstance(data, dict):
        return None
    detail = data.get("detail")
    return detail if isinstance(detail, dict) else None


def _extract_status_code_from_exception(exc: Exception) -> int | None:
    status_code = getattr(exc, "status_code", None)
    if isinstance(status_code, int):
        return status_code

    response = getattr(exc, "response", None)
    if response is not None and isinstance(getattr(response, "status_code", None), int):
        return int(response.status_code)

    match = re.search(r"Unexpected status code:\s*(\d{3})", str(exc))
    if match:
        try:
            return int(match.group(1))
        except ValueError:
            return None
    return None


def _extract_runtime_error_message(exc: Exception) -> str:
    response = getattr(exc, "response", None)
    if isinstance(response, httpx.Response):
        return _extract_error_message(response)

    content = getattr(exc, "content", None)
    if isinstance(content, (bytes, bytearray)):
        decoded = content.decode(errors="ignore").strip()
        if decoded:
            try:
                payload = json.loads(decoded)
                if isinstance(payload, dict):
                    detail = payload.get("detail")
                    if isinstance(detail, str) and detail.strip():
                        return detail.strip()
                    if isinstance(detail, dict):
                        detail_message = detail.get("message") or detail.get("error")
                        if isinstance(detail_message, str) and detail_message.strip():
                            return detail_message.strip()
            except Exception:
                pass
            return decoded.replace("\n", " ")

    text = str(exc).strip().replace("\n", " ")
    return text if text else "Unexpected runtime error"


def _classify_runtime_error(exc: Exception) -> tuple[str, str, str | None, int | None]:
    status_code = _extract_status_code_from_exception(exc)
    message = _extract_runtime_error_message(exc)
    lowered = message.lower()

    if status_code == 401:
        return (
            "auth_failed",
            "Invalid or revoked API key.",
            "Update your key with `adanos config set --api-key sk_live_xxx`.",
            401,
        )

    if status_code == 429:
        is_monthly_quota = any(
            token in lowered
            for token in (
                "monthly api limit exceeded",
                "free tier limit",
                "requests per month",
                "1st of next month",
                "out of api credits",
            )
        )
        if is_monthly_quota:
            return (
                "out_of_api_credits",
                "Out of API credits for the current monthly quota.",
                (
                    "Run `adanos account` for quota status. "
                    f"Upgrade options are hobby/professional via {SUPPORT_CONTACT_EMAIL}."
                ),
                429,
            )
        return (
            "rate_limited",
            "Rate limit exceeded. Retry shortly.",
            "If this persists, run `adanos account` to inspect your plan and quota.",
            429,
        )

    return ("runtime_error", message, None, status_code)


def _request_onboard_register(base_url: str, payload: dict[str, str]) -> tuple[int, dict[str, Any] | None, str]:
    with httpx.Client(base_url=base_url, timeout=30.0) as http:
        response = http.post("/auth/v1/register", json=payload)
    data = _decode_json_dict(response)
    message = _extract_error_message(response)
    return response.status_code, data, message


def _request_onboard_redeem(base_url: str, token: str) -> tuple[int, dict[str, Any] | None, str]:
    with httpx.Client(base_url=base_url, timeout=30.0) as http:
        response = http.get(f"/auth/v1/key/{token}")
    data = _decode_json_dict(response)
    message = _extract_error_message(response)
    return response.status_code, data, message


def _request_account_status(
    base_url: str, api_key: str, *, timeout_s: float = 30.0
) -> tuple[int, dict[str, Any] | None, str, dict[str, str]]:
    headers = {"X-API-Key": api_key}
    with httpx.Client(base_url=base_url, timeout=timeout_s) as http:
        response = http.get("/reddit/stocks/v1/stats", headers=headers)
    data = _decode_json_dict(response)
    message = _extract_error_message(response)
    header_map = {str(key).lower(): value for key, value in response.headers.items()}
    return response.status_code, data, message, header_map


def _header_get(headers: dict[str, str], name: str) -> str | None:
    return headers.get(name.lower())


def _build_account_status_payload(
    *,
    base_url: str,
    status_code: int,
    headers: dict[str, str],
    data: dict[str, Any] | None,
    message: str,
) -> dict[str, Any]:
    detail = _extract_error_detail(data)

    account_type = _coerce_account_type(
        _header_get(headers, "X-Account-Type")
        or (detail or {}).get("account_type")
        or (data or {}).get("plan")
    )

    limit_raw = _header_get(headers, "X-RateLimit-Limit-Monthly") or _header_get(headers, "X-RateLimit-Limit")
    remaining_raw = _header_get(headers, "X-RateLimit-Remaining-Monthly") or _header_get(headers, "X-RateLimit-Remaining")
    used_raw = _header_get(headers, "X-RateLimit-Used-Monthly")

    limit = None if str(limit_raw or "").strip().lower() == "unlimited" else _to_optional_int(limit_raw)
    remaining = None if str(remaining_raw or "").strip().lower() == "unlimited" else _to_optional_int(remaining_raw)
    used = _to_optional_int(used_raw)

    if isinstance(detail, dict):
        if limit is None:
            limit = _to_optional_int(detail.get("limit"))
        if used is None:
            used = _to_optional_int(detail.get("used"))
        if account_type == "unknown":
            account_type = _coerce_account_type(detail.get("account_type"))

    if used is None and limit is not None and remaining is not None:
        used = max(0, limit - remaining)
    if remaining is None and limit is not None and used is not None:
        remaining = max(0, limit - used)

    lowered_message = (message or "").lower()
    out_of_credits = status_code == 429 and (
        "monthly api limit exceeded" in lowered_message
        or "free tier limit" in lowered_message
        or "requests per month" in lowered_message
    )

    paid_active = account_type in PAID_ACCOUNT_TYPES
    upgrade_options: list[str]
    if account_type == "free" or out_of_credits:
        upgrade_options = ["hobby", "professional"]
    elif account_type == "hobby":
        upgrade_options = ["professional"]
    else:
        upgrade_options = []

    status_label = "active"
    if out_of_credits:
        status_label = "out_of_credits"
    elif paid_active:
        status_label = "paid_active"

    return {
        "kind": "account_status",
        "api_base_url": base_url,
        "status": status_label,
        "status_code": status_code,
        "account_type": account_type,
        "paid_active": paid_active,
        "out_of_credits": out_of_credits,
        "monthly_limit": limit,
        "monthly_used": used,
        "monthly_remaining": remaining,
        "upgrade_options": upgrade_options,
        "upgrade_contact": SUPPORT_CONTACT_EMAIL if upgrade_options else None,
        "message": message,
    }


def _print_account_status(payload: dict[str, Any]) -> None:
    print("Account status")
    print(f"- API: {payload.get('api_base_url')}")
    print(f"- Plan: {payload.get('account_type', 'unknown')}")

    if payload.get("paid_active"):
        print("- Status: paid plan active")
    elif payload.get("out_of_credits"):
        print("- Status: out of API credits")
    else:
        print("- Status: active")

    monthly_limit = payload.get("monthly_limit")
    monthly_used = payload.get("monthly_used")
    monthly_remaining = payload.get("monthly_remaining")
    if monthly_limit is None:
        print("- Monthly credits: unlimited")
        if monthly_used is not None:
            print(f"- Monthly used: {monthly_used}")
    else:
        used_label = monthly_used if monthly_used is not None else "unknown"
        remaining_label = monthly_remaining if monthly_remaining is not None else "unknown"
        print(f"- Monthly credits: {used_label}/{monthly_limit} used ({remaining_label} remaining)")

    upgrade_options = payload.get("upgrade_options") or []
    if upgrade_options:
        options = ", ".join(str(option) for option in upgrade_options)
        print(f"- Upgrade options: {options} ({SUPPORT_CONTACT_EMAIL})")

    note = str(payload.get("message") or "").strip()
    if note:
        print(f"- Note: {note}")


def _run_account_status(args: Namespace, base_url: str, api_key: str, *, json_mode: bool) -> int:
    status_code, data, message, headers = _request_account_status(base_url, api_key)

    if status_code not in {200, 401, 429}:
        _emit_error(
            json_mode=json_mode,
            code="account_status_failed",
            message=message,
            status_code=status_code,
        )
        return 1

    if status_code == 401:
        _emit_error(
            json_mode=json_mode,
            code="auth_failed",
            message="Invalid or revoked API key.",
            hint="Update your key with `adanos config set --api-key sk_live_xxx`.",
            status_code=401,
        )
        return 2

    payload = _build_account_status_payload(
        base_url=base_url,
        status_code=status_code,
        headers=headers,
        data=data,
        message="" if status_code == 200 else message,
    )
    if json_mode:
        print_json(payload)
    else:
        _print_account_status(payload)
    return 0


def _resolve_shell_account_status(base_url: str, api_key: str) -> dict[str, Any] | None:
    """Best-effort account lookup for shell header context (non-fatal)."""
    try:
        status_code, data, message, headers = _request_account_status(base_url, api_key, timeout_s=2.0)
    except Exception:
        return None

    if status_code not in {200, 429}:
        return None

    return _build_account_status_payload(
        base_url=base_url,
        status_code=status_code,
        headers=headers,
        data=data,
        message=message,
    )


def _format_shell_api_key_status(*, has_api_key: bool, account_status: dict[str, Any] | None) -> str:
    if not has_api_key:
        return _style("not configured", fg="red", bold=True)
    if not account_status:
        return _style("configured", fg="green", bold=True)

    account_type = str(account_status.get("account_type") or "unknown").lower()
    monthly_limit = account_status.get("monthly_limit")
    monthly_remaining = account_status.get("monthly_remaining")

    if account_type == "free":
        if isinstance(monthly_limit, int) and isinstance(monthly_remaining, int):
            label = f"free ({monthly_remaining}/{monthly_limit} left)"
        elif isinstance(monthly_limit, int):
            label = f"free (limit {monthly_limit}/month)"
        else:
            label = "free"

        if account_status.get("out_of_credits"):
            return _style(label, fg="red", bold=True)
        return _style(label, fg="yellow", bold=True)

    if account_type in PAID_ACCOUNT_TYPES:
        return _style(f"{account_type} (paid)", fg="green", bold=True)

    if account_type not in {"unknown", "configured"}:
        return _style(f"configured ({account_type})", fg="green", bold=True)
    return _style("configured", fg="green", bold=True)


def _prompt_non_empty(label: str, *, default: str | None = None) -> str:
    while True:
        suffix = f" [{default}]" if default else ""
        value = input(f"{label}{suffix}: ").strip()
        if value:
            return value
        if default:
            return default
        print("Please provide a value.")


def _prompt_yes_no(label: str, *, default_yes: bool = True) -> bool:
    default_hint = "Y/n" if default_yes else "y/N"
    raw = input(f"{label} ({default_hint}): ").strip().lower()
    if not raw:
        return default_yes
    if raw in {"y", "yes", "j", "ja"}:
        return True
    if raw in {"n", "no", "nein"}:
        return False
    return default_yes


def _run_onboard_register(args: Namespace, base_url: str, *, json_mode: bool) -> int:
    payload: dict[str, str] = {
        "name": args.name,
        "email": args.email,
        "purpose": args.purpose,
    }
    if args.company_name:
        payload["company_name"] = args.company_name

    status_code, data, message = _request_onboard_register(base_url, payload)
    if status_code != 201:
        _emit_error(
            json_mode=json_mode,
            code="onboard_register_failed",
            message=message,
            hint="If you already registered, use your existing key or contact support@adanos.org",
            status_code=status_code,
        )
        return 1

    if not isinstance(data, dict):
        _emit_error(
            json_mode=json_mode,
            code="onboard_register_failed",
            message="Response did not include structured registration data",
            status_code=status_code,
        )
        return 1

    token = str(data.get("delivery_token") or "")
    token_expires_at = str(data.get("token_expires_at") or "")
    plan = str(data.get("plan") or "free")
    email = str(data.get("email") or args.email)

    if json_mode:
        print_json(data)
    else:
        print("Registration completed.")
        print(f"Email: {email}")
        print(f"Plan: {plan}")
        print(f"Token expires at: {token_expires_at}")
        print("Delivery token:")
        print(token)
        print("Next command:")
        print(f"adanos onboard redeem --token {token} --save")

    return 0


def _run_onboard_redeem(args: Namespace, base_url: str, *, json_mode: bool) -> int:
    token = args.token.strip()
    status_code, data, message = _request_onboard_redeem(base_url, token)
    if status_code != 200:
        _emit_error(
            json_mode=json_mode,
            code="onboard_redeem_failed",
            message=message,
            hint="Ensure token format is kt_... and token is unused",
            status_code=status_code,
        )
        return 1

    if not isinstance(data, dict):
        _emit_error(
            json_mode=json_mode,
            code="onboard_redeem_failed",
            message="Response did not include structured key data",
            status_code=status_code,
        )
        return 1

    api_key = str(data.get("api_key") or "")
    if not api_key:
        _emit_error(
            json_mode=json_mode,
            code="onboard_redeem_failed",
            message="Response did not include an API key",
        )
        return 1

    if args.save:
        save_config_file(api_key=api_key, base_url=base_url)

    if json_mode:
        print_json(data)
    else:
        print("API key retrieved.")
        print(f"Plan: {data.get('plan', 'unknown')}")
        print(f"Email: {data.get('email', 'unknown')}")
        print(f"Retrieved at: {data.get('retrieved_at', 'unknown')}")
        print(f"API key: {masked_key(api_key)}")
        if args.save:
            print(f"Saved to: {CONFIG_PATH}")
            print('Try now: adanos ask "crypto btc/eth"')
        else:
            print(f"Save now: adanos config set --api-key {api_key}")

    return 0


def _run_onboard_wizard(args: Namespace, base_url: str, *, json_mode: bool, runtime_has_key: bool) -> int:
    if json_mode:
        _emit_error(
            json_mode=True,
            code="onboard_wizard_unsupported",
            message="Interactive wizard is only available in text mode",
            hint="Use `adanos onboard register ...` + `adanos onboard redeem ... --save` in JSON workflows",
        )
        return 2

    if not (sys.stdin.isatty() and sys.stdout.isatty()):
        _emit_error(
            json_mode=False,
            code="onboard_wizard_unsupported",
            message="Interactive wizard requires a TTY terminal",
            hint="Use explicit commands: onboard register / onboard redeem",
        )
        return 2

    print("Adanos onboarding wizard")
    print(f"API base URL: {base_url}")
    if runtime_has_key:
        print("An API key is already configured.")
        if not _prompt_yes_no("Do you want to replace it?", default_yes=False):
            print("Keeping existing key. Setup finished.")
            return 0

    name = _prompt_non_empty("Your name")
    email = _prompt_non_empty("Your email")
    purpose = _prompt_non_empty("Usage purpose", default="CLI usage for stocks and crypto")
    company_name = input("Company (optional): ").strip()

    payload: dict[str, str] = {"name": name, "email": email, "purpose": purpose}
    if company_name:
        payload["company_name"] = company_name

    print("")
    print("Registering your account...")
    status_code, data, message = _request_onboard_register(base_url, payload)
    if status_code != 201 or not isinstance(data, dict):
        _emit_error(
            json_mode=False,
            code="onboard_register_failed",
            message=message if message else "Registration failed",
            hint="You can retry with `adanos onboard register ...`",
            status_code=status_code,
        )
        return 1

    delivery_token = str(data.get("delivery_token") or "").strip()
    token_expires = str(data.get("token_expires_at") or "unknown")
    print("Registration completed.")
    print(f"Token expires at: {token_expires}")
    if delivery_token:
        print("Delivery token received.")
    else:
        print("No delivery token in response. Use token from email.")

    print("")
    if not _prompt_yes_no("Redeem API key now?", default_yes=True):
        print("Next step:")
        print("  adanos onboard redeem --token <delivery_token> --save")
        return 0

    token = _prompt_non_empty("Delivery token", default=delivery_token if delivery_token else None)
    print("Redeeming token...")
    redeem_status, redeem_data, redeem_message = _request_onboard_redeem(base_url, token)
    if redeem_status != 200 or not isinstance(redeem_data, dict):
        _emit_error(
            json_mode=False,
            code="onboard_redeem_failed",
            message=redeem_message if redeem_message else "Token redemption failed",
            hint="Retry with `adanos onboard redeem --token <delivery_token> --save`",
            status_code=redeem_status,
        )
        return 1

    api_key = str(redeem_data.get("api_key") or "").strip()
    if not api_key:
        _emit_error(
            json_mode=False,
            code="onboard_redeem_failed",
            message="Response did not include an API key",
        )
        return 1

    save_config_file(api_key=api_key, base_url=base_url)
    print("API key retrieved and stored.")
    print(f"Saved to: {CONFIG_PATH}")
    print('Next: adanos ask "How does TSLA look?"')
    return 0


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="adanos",
        description=(
            "Comprehensive CLI for api.adanos.org. Supports all OpenAPI endpoints for "
            "Reddit Stocks, Reddit Crypto, X/Twitter Stocks, and Polymarket Stocks."
        ),
        formatter_class=argparse.RawTextHelpFormatter,
        epilog=(
            "Guided quickstart:\n"
            "  adanos onboard wizard\n"
            "  adanos ask 'How does TSLA look?'\n"
            "\n"
            "Common workflows:\n"
            "  adanos scan --asset stocks --style daytrader\n"
            "  adanos briefing --profile investor --days 30\n"
            "  adanos watchlist report core --asset all\n"
            "\n"
            "OpenAPI power usage:\n"
            "  adanos endpoint list\n"
            "  adanos endpoint call reddit-stocks.trending --days 7 --limit 10\n"
            "\n"
            "Interactive mode:\n"
            "  adanos\n"
            "  /help"
        ),
    )
    parser.add_argument("--api-key", help="Override API key for this call")
    parser.add_argument("--base-url", help=f"Override base URL (default: {DEFAULT_BASE_URL})")
    parser.add_argument("--output", choices=["text", "json"], default="text", help="Output mode for agent/human consumption")
    parser.add_argument("--version", action="store_true", help="Print CLI version and exit")

    subs = parser.add_subparsers(dest="command")

    p_onboard = subs.add_parser("onboard", help="Guided API key onboarding without curl")
    onboard_subs = p_onboard.add_subparsers(dest="onboard_cmd")

    p_onboard_guide = onboard_subs.add_parser("guide", help="Show guided onboarding steps")
    p_onboard_guide.set_defaults(_handler="onboard_guide")

    p_onboard_wizard = onboard_subs.add_parser("wizard", help="Interactive guided setup with prompts")
    p_onboard_wizard.add_argument("--json", action="store_true")
    p_onboard_wizard.set_defaults(_handler="onboard_wizard")

    p_onboard_register = onboard_subs.add_parser("register", help="Register and get a delivery token")
    p_onboard_register.add_argument("--name", required=True, help="Your full name")
    p_onboard_register.add_argument("--email", required=True, help="Your email address")
    p_onboard_register.add_argument("--purpose", required=True, help="How you will use the API")
    p_onboard_register.add_argument("--company-name", help="Optional company/organization")
    p_onboard_register.add_argument("--json", action="store_true")
    p_onboard_register.set_defaults(_handler="onboard_register")

    p_onboard_redeem = onboard_subs.add_parser("redeem", help="Redeem delivery token to get API key")
    p_onboard_redeem.add_argument("--token", required=True, help="One-time delivery token (kt_...)")
    p_onboard_redeem.add_argument("--save", action="store_true", help="Save API key directly into local config")
    p_onboard_redeem.add_argument("--json", action="store_true")
    p_onboard_redeem.set_defaults(_handler="onboard_redeem")

    p_onboard.set_defaults(_handler="onboard_guide")

    p_config = subs.add_parser("config", help="Manage local CLI config")
    cfg_subs = p_config.add_subparsers(dest="config_cmd", required=True)
    p_cfg_set = cfg_subs.add_parser("set", help="Set API key and optional base URL")
    p_cfg_set.add_argument("--api-key", required=True)
    p_cfg_set.add_argument("--base-url")
    p_cfg_set.set_defaults(_handler="config_set")

    p_cfg_show = cfg_subs.add_parser("show", help="Show current config")
    p_cfg_show.set_defaults(_handler="config_show")

    p_cfg_clear = cfg_subs.add_parser("clear", help="Delete local config file")
    p_cfg_clear.set_defaults(_handler="config_clear")

    p_account = subs.add_parser(
        "account",
        help="Show API credit usage, upgrade options, and current plan status",
    )
    p_account.add_argument("--json", action="store_true")
    p_account.set_defaults(_handler="account_status")

    p_capabilities = subs.add_parser("capabilities", help="Print machine-readable CLI capabilities")
    p_capabilities.set_defaults(_handler="capabilities")

    p_shell = subs.add_parser("shell", help="Interactive shell with banner and command input field")
    p_shell.add_argument(
        "--fullscreen",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Enable/disable alternate-screen fullscreen mode (default: off, keeps scrollback).",
    )
    p_shell.set_defaults(_handler="shell")

    p_scan = subs.add_parser("scan", help="Run fast sentiment screeners for stocks or crypto")
    p_scan.add_argument("--asset", choices=["stocks", "crypto"], required=True)
    p_scan.add_argument("--style", choices=["starter", "daytrader", "swing", "investor"], help="Apply preset filters for your trading style")
    p_scan.add_argument("--days", type=int, default=7)
    p_scan.add_argument("--limit", type=int, default=25, help="Source fetch limit per platform")
    p_scan.add_argument("--top", type=int, default=10, help="Rows to print in text mode")
    p_scan.add_argument("--min-buzz", type=float)
    p_scan.add_argument("--min-volume", type=int, help="Mentions for stocks/crypto, trade_count for polymarket")
    p_scan.add_argument("--min-platforms", type=int, help="Stocks only: minimum platform confirmations")
    p_scan.add_argument("--min-sentiment", type=float, help="Minimum sentiment filter (-1..1)")
    p_scan.add_argument("--max-sentiment", type=float, help="Maximum sentiment filter (-1..1)")
    p_scan.add_argument("--json", action="store_true")
    p_scan.set_defaults(_handler="scan")

    p_briefing = subs.add_parser("briefing", help="Profile-based market briefing for different investor styles")
    p_briefing.add_argument("--profile", choices=["starter", "daytrader", "swing", "investor", "crypto", "research", "portfolio"], default="starter")
    p_briefing.add_argument("--days", type=int, default=7)
    p_briefing.add_argument("--limit", type=int, default=10)
    p_briefing.add_argument("--stocks", help="Optional focus watchlist tickers (comma-separated)")
    p_briefing.add_argument("--crypto", help="Optional focus crypto symbols (comma-separated)")
    p_briefing.add_argument("--from-watchlist", help="Merge symbols from local watchlist into focus sets")
    p_briefing.add_argument("--json", action="store_true")
    p_briefing.set_defaults(_handler="briefing")

    p_watchlist = subs.add_parser("watchlist", help="Manage local watchlists and run reports")
    wl_subs = p_watchlist.add_subparsers(dest="watchlist_cmd", required=True)

    p_wl_list = wl_subs.add_parser("list", help="List all watchlists")
    p_wl_list.add_argument("--json", action="store_true")
    p_wl_list.set_defaults(_handler="watchlist_list")

    p_wl_show = wl_subs.add_parser("show", help="Show one watchlist")
    p_wl_show.add_argument("name")
    p_wl_show.add_argument("--json", action="store_true")
    p_wl_show.set_defaults(_handler="watchlist_show")

    p_wl_add = wl_subs.add_parser("add", help="Add symbols to watchlist")
    p_wl_add.add_argument("name")
    p_wl_add.add_argument("--asset", choices=["stocks", "crypto"], required=True)
    p_wl_add.add_argument("--symbols", required=True, help="Comma-separated symbols")
    p_wl_add.add_argument("--json", action="store_true")
    p_wl_add.set_defaults(_handler="watchlist_add")

    p_wl_remove = wl_subs.add_parser("remove", help="Remove symbols from watchlist")
    p_wl_remove.add_argument("name")
    p_wl_remove.add_argument("--asset", choices=["stocks", "crypto"], required=True)
    p_wl_remove.add_argument("--symbols", required=True, help="Comma-separated symbols")
    p_wl_remove.add_argument("--json", action="store_true")
    p_wl_remove.set_defaults(_handler="watchlist_remove")

    p_wl_delete = wl_subs.add_parser("delete", help="Delete watchlist")
    p_wl_delete.add_argument("name")
    p_wl_delete.add_argument("--json", action="store_true")
    p_wl_delete.set_defaults(_handler="watchlist_delete")

    p_wl_report = wl_subs.add_parser("report", help="Run report for watchlist symbols")
    p_wl_report.add_argument("name")
    p_wl_report.add_argument("--asset", choices=["stocks", "crypto", "all"], default="stocks")
    p_wl_report.add_argument("--days", type=int, default=7)
    p_wl_report.add_argument("--json", action="store_true")
    p_wl_report.set_defaults(_handler="watchlist_report")

    p_endpoint = subs.add_parser("endpoint", help="List/call every supported OpenAPI endpoint")
    ep_subs = p_endpoint.add_subparsers(dest="endpoint_cmd", required=True)

    p_ep_list = ep_subs.add_parser("list", help="List all endpoint IDs")
    p_ep_list.add_argument("--json", action="store_true")
    p_ep_list.set_defaults(_handler="endpoint_list")

    p_ep_call = ep_subs.add_parser("call", help="Call one endpoint by ID")
    p_ep_call.add_argument("endpoint_id", choices=sorted(ENDPOINTS.keys()))
    p_ep_call.add_argument("--ticker")
    p_ep_call.add_argument("--symbol")
    p_ep_call.add_argument("--q")
    p_ep_call.add_argument("--query")
    p_ep_call.add_argument("--tickers", help="Comma-separated tickers")
    p_ep_call.add_argument("--symbols", help="Comma-separated symbols")
    p_ep_call.add_argument("--assets", help="Generic comma-separated assets (for compare)")
    p_ep_call.add_argument("--days", type=int)
    p_ep_call.add_argument("--limit", type=int)
    p_ep_call.add_argument("--offset", type=int)
    p_ep_call.add_argument("--type", choices=["stock", "etf", "all"])
    p_ep_call.add_argument("--source", help="Optional canonical/alias news source filter for supported news endpoints")
    p_ep_call.add_argument("--json", action="store_true")
    p_ep_call.set_defaults(_handler="endpoint_call")

    p_stock = subs.add_parser("stock", help="Comprehensive stock report across News, Reddit, X, and Polymarket")
    p_stock.add_argument("ticker")
    p_stock.add_argument("--days", type=int, default=7)
    p_stock.add_argument("--json", action="store_true")
    p_stock.set_defaults(_handler="stock_report")

    p_crypto = subs.add_parser("crypto", help="Comprehensive crypto report or pair comparison")
    p_crypto.add_argument("symbol_or_pair", help="Single symbol (BTC) or pair (BTC/ETH)")
    p_crypto.add_argument("--days", type=int, default=7)
    p_crypto.add_argument("--json", action="store_true")
    p_crypto.set_defaults(_handler="crypto_report")

    p_ask = subs.add_parser("ask", help="Natural-language assistant mode")
    p_ask.add_argument("text", nargs="+")
    p_ask.add_argument("--days", type=int, default=7)
    p_ask.add_argument("--json", action="store_true")
    p_ask.set_defaults(_handler="ask")

    p_trending = subs.add_parser("trending", help="Fetch trending lists")
    p_trending.add_argument("--platform", choices=["news-stocks", "reddit-stocks", "reddit-crypto", "x-stocks", "polymarket-stocks"], required=True)
    p_trending.add_argument("--dimension", choices=["main", "sectors", "countries", "tokens"], default="main")
    p_trending.add_argument("--days", type=int, default=1)
    p_trending.add_argument("--limit", type=int, default=20)
    p_trending.add_argument("--offset", type=int, default=0)
    p_trending.add_argument("--type", choices=["stock", "etf", "all"])
    p_trending.add_argument("--source", help="Optional canonical/alias news source filter")
    p_trending.add_argument("--json", action="store_true")
    p_trending.set_defaults(_handler="trending")

    p_search = subs.add_parser("search", help="Search assets by platform")
    p_search.add_argument("--platform", choices=["news-stocks", "reddit-stocks", "reddit-crypto", "x-stocks", "polymarket-stocks"], required=True)
    p_search.add_argument("query")
    p_search.add_argument("--json", action="store_true")
    p_search.set_defaults(_handler="search")

    p_compare = subs.add_parser("compare", help="Compare multiple assets")
    p_compare.add_argument("--platform", choices=["news-stocks", "reddit-stocks", "reddit-crypto", "x-stocks", "polymarket-stocks"], required=True)
    p_compare.add_argument("assets", help="Comma-separated assets")
    p_compare.add_argument("--days", type=int, default=7)
    p_compare.add_argument("--json", action="store_true")
    p_compare.set_defaults(_handler="compare")

    p_stats = subs.add_parser("stats", help="Get stats endpoint by platform")
    p_stats.add_argument("--platform", choices=["news-stocks", "reddit-stocks", "reddit-crypto", "x-stocks", "polymarket-stocks"], required=True)
    p_stats.add_argument("--json", action="store_true")
    p_stats.set_defaults(_handler="stats")

    p_health = subs.add_parser("health", help="Get health endpoint by platform or all")
    p_health.add_argument("--platform", choices=["all", "news-stocks", "reddit-stocks", "reddit-crypto", "x-stocks", "polymarket-stocks"], default="all")
    p_health.add_argument("--json", action="store_true")
    p_health.set_defaults(_handler="health")

    return parser


def _requires_api_key(args: Namespace) -> bool:
    handler = getattr(args, "_handler", "")
    if handler in {
        "onboard_guide",
        "onboard_wizard",
        "onboard_register",
        "onboard_redeem",
        "config_set",
        "config_show",
        "config_clear",
        "capabilities",
        "shell",
        "watchlist_list",
        "watchlist_show",
        "watchlist_add",
        "watchlist_remove",
        "watchlist_delete",
        "endpoint_list",
        "health",
    }:
        return False
    if handler == "endpoint_call":
        return not is_health_endpoint(args.endpoint_id)
    return True


def _call_and_emit_endpoint(client: Any, endpoint_id: str, args: Namespace, *, json_mode: bool) -> None:
    data = invoke_endpoint(client, endpoint_id, args)
    payload = {"endpoint": endpoint_id, "path": ENDPOINTS[endpoint_id].path, "data": to_plain(data)}
    if json_mode:
        print_json(payload)
        return

    print(f"Endpoint: {endpoint_id}")
    print(f"Path: {ENDPOINTS[endpoint_id].path}")
    print_json(payload["data"])


def _run_health(client: Any, args: Namespace) -> None:
    if args.platform == "all":
        report = {}
        for endpoint_id in (
            "news-stocks.health",
            "reddit-stocks.health",
            "reddit-crypto.health",
            "x-stocks.health",
            "polymarket-stocks.health",
        ):
            try:
                report[endpoint_id] = to_plain(invoke_endpoint(client, endpoint_id, args))
            except Exception as exc:  # pragma: no cover - defensive
                report[endpoint_id] = {"error": str(exc)}
        if args.json:
            print_json(report)
        else:
            print_json(report)
        return

    endpoint_id = f"{args.platform}.health"
    _call_and_emit_endpoint(client, endpoint_id, args, json_mode=args.json)


def _run_trending(client: Any, args: Namespace) -> None:
    mapping = {
        ("news-stocks", "main"): "news-stocks.trending",
        ("news-stocks", "sectors"): "news-stocks.trending.sectors",
        ("news-stocks", "countries"): "news-stocks.trending.countries",
        ("reddit-stocks", "main"): "reddit-stocks.trending",
        ("reddit-stocks", "sectors"): "reddit-stocks.trending.sectors",
        ("reddit-stocks", "countries"): "reddit-stocks.trending.countries",
        ("reddit-crypto", "main"): "reddit-crypto.trending",
        ("reddit-crypto", "tokens"): "reddit-crypto.trending",
        ("x-stocks", "main"): "x-stocks.trending",
        ("x-stocks", "sectors"): "x-stocks.trending.sectors",
        ("x-stocks", "countries"): "x-stocks.trending.countries",
        ("polymarket-stocks", "main"): "polymarket-stocks.trending",
        ("polymarket-stocks", "sectors"): "polymarket-stocks.trending.sectors",
        ("polymarket-stocks", "countries"): "polymarket-stocks.trending.countries",
    }
    endpoint_id = mapping.get((args.platform, args.dimension))
    if endpoint_id is None:
        raise CliUsageError(f"Unsupported platform/dimension combination: {args.platform} + {args.dimension}")
    _call_and_emit_endpoint(client, endpoint_id, args, json_mode=args.json)


def _run_search(client: Any, args: Namespace) -> None:
    endpoint_id = f"{args.platform}.search"
    call_args = Namespace(**vars(args))
    call_args.q = args.query
    _call_and_emit_endpoint(client, endpoint_id, call_args, json_mode=args.json)


def _run_compare(client: Any, args: Namespace) -> None:
    endpoint_id = f"{args.platform}.compare"
    call_args = Namespace(**vars(args))
    if args.platform == "reddit-crypto":
        call_args.symbols = args.assets
    else:
        call_args.tickers = args.assets
    _call_and_emit_endpoint(client, endpoint_id, call_args, json_mode=args.json)


def _run_stats(client: Any, args: Namespace) -> None:
    endpoint_id = f"{args.platform}.stats"
    _call_and_emit_endpoint(client, endpoint_id, args, json_mode=args.json)


def _scan_thresholds(args: Namespace) -> dict[str, Any]:
    thresholds: dict[str, Any] = {
        "min_buzz": args.min_buzz,
        "min_volume": args.min_volume,
        "min_platforms": args.min_platforms,
        "min_sentiment": args.min_sentiment,
        "max_sentiment": args.max_sentiment,
    }
    style = str(getattr(args, "style", "") or "").lower().strip()
    if not style:
        return thresholds

    if args.asset == "stocks":
        presets = {
            "starter": {"min_buzz": 55.0, "min_platforms": 1},
            "daytrader": {"min_buzz": 70.0, "min_volume": 150, "min_platforms": 2},
            "swing": {"min_buzz": 65.0, "min_volume": 90, "min_platforms": 2},
            "investor": {"min_buzz": 60.0, "min_volume": 250, "min_platforms": 2},
        }
    else:
        presets = {
            "starter": {"min_buzz": 55.0, "min_volume": 30},
            "daytrader": {"min_buzz": 65.0, "min_volume": 100},
            "swing": {"min_buzz": 60.0, "min_volume": 60},
            "investor": {"min_buzz": 58.0, "min_volume": 80},
        }

    preset = presets.get(style, {})
    for key, value in preset.items():
        if thresholds.get(key) is None:
            thresholds[key] = value
    return thresholds


def _run_scan(client: Any, args: Namespace) -> None:
    thresholds = _scan_thresholds(args)
    if args.asset == "stocks":
        report = build_stock_scan_report(client, days=args.days, limit=args.limit)
        rows = [row for row in report.get("rows", []) if isinstance(row, dict)]
        if thresholds.get("min_buzz") is not None:
            rows = [row for row in rows if (row.get("consensus_buzz") or 0) >= thresholds["min_buzz"]]
        if thresholds.get("min_volume") is not None:
            rows = [row for row in rows if (row.get("total_volume") or 0) >= thresholds["min_volume"]]
        if thresholds.get("min_platforms") is not None:
            rows = [row for row in rows if (row.get("platforms") or 0) >= thresholds["min_platforms"]]
        if thresholds.get("min_sentiment") is not None:
            rows = [row for row in rows if (row.get("consensus_sentiment") or 0) >= thresholds["min_sentiment"]]
        if thresholds.get("max_sentiment") is not None:
            rows = [row for row in rows if (row.get("consensus_sentiment") or 0) <= thresholds["max_sentiment"]]
        report["rows"] = rows
        if args.style:
            report["style"] = args.style
            report["applied_filters"] = thresholds
        if args.json:
            print_json(report)
            return
        print(format_stock_scan_report(report, top=args.top))
        return

    report = build_crypto_scan_report(client, days=args.days, limit=args.limit)
    rows = [row for row in report.get("rows", []) if isinstance(row, dict)]
    if thresholds.get("min_buzz") is not None:
        rows = [row for row in rows if (row.get("buzz_score") or 0) >= thresholds["min_buzz"]]
    if thresholds.get("min_volume") is not None:
        rows = [row for row in rows if (row.get("mentions") or 0) >= thresholds["min_volume"]]
    if thresholds.get("min_sentiment") is not None:
        rows = [row for row in rows if (row.get("sentiment") or 0) >= thresholds["min_sentiment"]]
    if thresholds.get("max_sentiment") is not None:
        rows = [row for row in rows if (row.get("sentiment") or 0) <= thresholds["max_sentiment"]]
    report["rows"] = rows
    if args.style:
        report["style"] = args.style
        report["applied_filters"] = thresholds
    if args.json:
        print_json(report)
        return
    print(format_crypto_scan_report(report, top=args.top))


def _run_briefing(client: Any, args: Namespace) -> None:
    stock_focus = csv_to_list(args.stocks) if args.stocks else []
    crypto_focus = csv_to_list(args.crypto) if args.crypto else []
    if getattr(args, "from_watchlist", None):
        watchlist = get_watchlist(args.from_watchlist)
        if watchlist is None:
            raise CliUsageError(f"Watchlist '{args.from_watchlist}' not found")
        for symbol in watchlist.get("stocks", []):
            if symbol not in stock_focus:
                stock_focus.append(symbol)
        for symbol in watchlist.get("crypto", []):
            if symbol not in crypto_focus:
                crypto_focus.append(symbol)

    report = build_market_briefing_report(
        client,
        profile=args.profile,
        days=args.days,
        limit=args.limit,
        stock_focus=stock_focus,
        crypto_focus=crypto_focus,
    )
    if args.json:
        print_json(report)
        return
    print(format_market_briefing_report(report))


def _handle_watchlist_without_api(args: Namespace) -> int:
    if args._handler == "watchlist_list":
        payload = list_watchlists()
        if args.json:
            print_json(payload)
        else:
            if not payload:
                print("No watchlists configured.")
            for name, data in payload.items():
                stocks = ", ".join(data.get("stocks", [])) or "-"
                crypto = ", ".join(data.get("crypto", [])) or "-"
                print(f"- {name}: stocks=[{stocks}] crypto=[{crypto}]")
        return 0

    if args._handler == "watchlist_show":
        payload = get_watchlist(args.name)
        if payload is None:
            raise CliUsageError(f"Watchlist '{args.name}' not found")
        if args.json:
            print_json({args.name: payload})
        else:
            stocks = ", ".join(payload.get("stocks", [])) or "-"
            crypto = ", ".join(payload.get("crypto", [])) or "-"
            print(f"{args.name}:")
            print(f"  stocks: {stocks}")
            print(f"  crypto: {crypto}")
        return 0

    if args._handler == "watchlist_add":
        payload = upsert_watchlist_symbols(args.name, args.asset, args.symbols)
        if args.json:
            print_json({args.name: payload})
        else:
            print(f"Updated watchlist '{args.name}' ({args.asset}).")
        return 0

    if args._handler == "watchlist_remove":
        payload = remove_watchlist_symbols(args.name, args.asset, args.symbols)
        if args.json:
            print_json({args.name: payload})
        else:
            print(f"Updated watchlist '{args.name}' ({args.asset}).")
        return 0

    if args._handler == "watchlist_delete":
        deleted = delete_watchlist(args.name)
        if args.json:
            print_json({"name": args.name, "deleted": deleted})
        else:
            print(f"Deleted watchlist '{args.name}'." if deleted else f"Watchlist '{args.name}' not found.")
        return 0

    raise CliUsageError("Unknown watchlist command")


def _run_watchlist_report(client: Any, args: Namespace) -> None:
    payload = get_watchlist(args.name)
    if payload is None:
        raise CliUsageError(f"Watchlist '{args.name}' not found")

    if args.asset == "all":
        stocks_symbols = payload.get("stocks", [])
        crypto_symbols = payload.get("crypto", [])
        if not stocks_symbols and not crypto_symbols:
            raise CliUsageError(f"Watchlist '{args.name}' has no symbols")
        report: dict[str, Any] = {
            "kind": "watchlist_report",
            "name": args.name,
            "days": args.days,
        }
        if stocks_symbols:
            if len(stocks_symbols) == 1:
                report["stocks"] = build_stock_report(client, stocks_symbols[0], days=args.days)
            else:
                report["stocks"] = build_stock_compare_report(client, stocks_symbols[:10], days=args.days)
        if crypto_symbols:
            if len(crypto_symbols) == 1:
                report["crypto"] = build_crypto_report(client, crypto_symbols[0], days=args.days)
            else:
                report["crypto"] = build_crypto_compare_report(client, crypto_symbols[:10], days=args.days)
        if args.json:
            print_json(report)
            return
        lines = [f"Watchlist report: {args.name} ({args.days}d)"]
        stocks_report = report.get("stocks")
        if isinstance(stocks_report, dict):
            lines.append("")
            if stocks_report.get("kind") == "stock_report":
                lines.append(format_stock_report(stocks_report))
            else:
                lines.append(format_stock_compare_report(stocks_report))
        crypto_report = report.get("crypto")
        if isinstance(crypto_report, dict):
            lines.append("")
            if crypto_report.get("kind") == "crypto_report":
                lines.append(format_crypto_report(crypto_report))
            else:
                lines.append(format_crypto_compare_report(crypto_report))
        print("\n".join(lines))
        return

    symbols = payload.get(args.asset, [])
    if not symbols:
        raise CliUsageError(f"Watchlist '{args.name}' has no symbols in asset '{args.asset}'")

    if args.asset == "stocks":
        if len(symbols) == 1:
            report = build_stock_report(client, symbols[0], days=args.days)
            if args.json:
                print_json(report)
            else:
                print(format_stock_report(report))
            return
        report = build_stock_compare_report(client, symbols[:10], days=args.days)
        if args.json:
            print_json(report)
        else:
            print(format_stock_compare_report(report))
        return

    if len(symbols) == 1:
        report = build_crypto_report(client, symbols[0], days=args.days)
        if args.json:
            print_json(report)
        else:
            print(format_crypto_report(report))
        return
    report = build_crypto_compare_report(client, symbols[:10], days=args.days)
    if args.json:
        print_json(report)
    else:
        print(format_crypto_compare_report(report))


def _run_stock_report(client: Any, args: Namespace) -> None:
    report = build_stock_report(client, args.ticker, days=args.days)
    if args.json:
        print_json(report)
        return
    print(format_stock_report(report))


def _run_crypto_report(client: Any, args: Namespace) -> None:
    raw = args.symbol_or_pair.strip().upper().replace("/", ",")
    symbols = csv_to_list(raw)

    if len(symbols) >= 2:
        report = build_crypto_compare_report(client, symbols[:10], days=args.days)
        if args.json:
            print_json(report)
            return
        print(format_crypto_compare_report(report))
        return

    if not symbols:
        raise CliUsageError("Provide a crypto symbol like BTC or a pair like BTC/ETH")

    report = build_crypto_report(client, symbols[0], days=args.days)
    if args.json:
        print_json(report)
        return
    print(format_crypto_report(report))


def _iter_stock_search_hits(client: Any, query: str):
    for source, fn in (
        ("reddit", client.reddit.search),
        ("x", client.x.search),
        ("polymarket", client.polymarket.search),
    ):
        try:
            payload = to_plain(fn(query))
        except Exception:
            continue
        if not isinstance(payload, dict):
            continue
        results = payload.get("results")
        if not isinstance(results, list):
            continue
        for row in results:
            if not isinstance(row, dict):
                continue
            ticker = str(row.get("ticker") or "").strip().upper()
            if not ticker:
                continue
            yield source, row


def _score_stock_hit(query: str, row: dict[str, Any]) -> int:
    q = query.strip().upper()
    ticker = str(row.get("ticker") or "").strip().upper()
    name = str(row.get("name") or "").strip().upper()
    aliases_raw = row.get("aliases") or []
    aliases = [str(alias).strip().upper() for alias in aliases_raw if str(alias).strip()]

    if ticker == q:
        return 140
    if name and name == q:
        return 130
    if any(alias == q for alias in aliases):
        return 130
    if name and q in name:
        return 115
    if any(q in alias for alias in aliases):
        return 115
    if ticker.startswith(q) and len(q) >= 2:
        return 70
    return 0


def _resolve_stock_ticker(client: Any, text: str, primary: str | None) -> tuple[str | None, str | None, str | None]:
    candidates: list[str] = []
    if primary:
        candidates.append(primary.upper().replace("$", ""))
    candidates.extend(extract_terms(text))

    seen: set[str] = set()
    queries: list[str] = []
    for token in candidates:
        normalized = token.strip().upper().replace("$", "")
        if not normalized or normalized in seen:
            continue
        seen.add(normalized)
        queries.append(normalized)

    best: tuple[int, str, str, str] | None = None
    for query in queries[:8]:
        for source, row in _iter_stock_search_hits(client, query):
            score = _score_stock_hit(query, row)
            ticker = str(row.get("ticker") or "").strip().upper()
            if not ticker:
                continue
            if best is None or score > best[0]:
                best = (score, ticker, query, source)

    if best and best[0] >= 110:
        return best[1], best[2], best[3]

    if primary:
        fallback = primary.upper().replace("$", "").strip()
        if fallback and fallback.isalnum() and len(fallback) <= 10:
            return fallback, None, None

    return None, None, None


def _run_ask(client: Any, args: Namespace) -> None:
    text = " ".join(args.text).strip()
    intent = parse_ask_intent(text)

    if intent.kind == "briefing_report":
        brief_args = Namespace(
            profile=(intent.primary or "starter"),
            days=args.days,
            limit=10,
            stocks=None,
            crypto=None,
            from_watchlist=None,
            json=args.json,
        )
        _run_briefing(client, brief_args)
        return

    if intent.kind == "scan_report":
        asset = (intent.primary or "stocks").lower()
        if asset == "all":
            payload = {
                "kind": "scan_bundle",
                "days": args.days,
                "stocks": build_stock_scan_report(client, days=args.days, limit=25),
                "crypto": build_crypto_scan_report(client, days=args.days, limit=25),
            }
            if args.json:
                print_json(payload)
                return
            print("Combined scan report")
            print("")
            print(format_stock_scan_report(payload["stocks"], top=8))
            print("")
            print(format_crypto_scan_report(payload["crypto"], top=8))
            return

        scan_args = Namespace(
            asset=asset,
            style=None,
            days=args.days,
            limit=25,
            top=10,
            min_buzz=None,
            min_volume=None,
            min_platforms=None,
            min_sentiment=None,
            max_sentiment=None,
            json=args.json,
        )
        _run_scan(client, scan_args)
        return

    if intent.kind == "watchlist_report":
        watchlist_args = Namespace(
            name=(intent.primary or "core"),
            asset=(intent.secondary or "all").lower(),
            days=args.days,
            json=args.json,
        )
        _run_watchlist_report(client, watchlist_args)
        return

    if intent.kind == "trending_report":
        asset = "crypto" if (intent.primary or "").lower() == "crypto" else "stocks"
        report = build_trending_report(client, asset=asset, days=args.days, limit=5)
        if args.json:
            print_json(report)
            return
        print(format_trending_report(report))
        return

    if intent.kind == "stock_compare" and intent.primary and intent.secondary:
        first, first_from, _ = _resolve_stock_ticker(client, intent.primary, intent.primary)
        second, second_from, _ = _resolve_stock_ticker(client, intent.secondary, intent.secondary)
        tickers = [first or intent.primary, second or intent.secondary]
        report = build_stock_compare_report(client, tickers, days=args.days)
        if args.json:
            report["resolution"] = {
                "first": {"input": intent.primary, "query": first_from or intent.primary, "ticker": tickers[0]},
                "second": {"input": intent.secondary, "query": second_from or intent.secondary, "ticker": tickers[1]},
            }
            print_json(report)
            return
        if tickers[0] != intent.primary.upper():
            print(f"Resolved '{intent.primary.upper()}' -> {tickers[0]}")
        if tickers[1] != intent.secondary.upper():
            print(f"Resolved '{intent.secondary.upper()}' -> {tickers[1]}")
        print(format_stock_compare_report(report))
        return

    if intent.kind == "stock_report" and intent.primary:
        resolved_ticker, resolved_from, resolved_source = _resolve_stock_ticker(client, text, intent.primary)
        ticker = resolved_ticker or intent.primary
        report = build_stock_report(client, ticker, days=args.days)
        if args.json:
            if resolved_from and resolved_source:
                report["resolution"] = {
                    "input": intent.primary,
                    "query": resolved_from,
                    "ticker": ticker,
                    "source": resolved_source,
                }
            print_json(report)
            return
        if resolved_from and resolved_source and ticker != intent.primary:
            print(f"Resolved '{resolved_from}' -> {ticker} via {resolved_source} search")
        print(format_stock_report(report))
        return

    if intent.kind == "crypto_report" and intent.primary:
        report = build_crypto_report(client, intent.primary, days=args.days)
        if args.json:
            print_json(report)
            return
        print(format_crypto_report(report))
        return

    if intent.kind == "crypto_compare" and intent.primary and intent.secondary:
        report = build_crypto_compare_report(client, [intent.primary, intent.secondary], days=args.days)
        if args.json:
            print_json(report)
            return
        print(format_crypto_compare_report(report))
        return

    report = build_search_fallback_report(client, text)
    if args.json:
        print_json(report)
        return
    print(format_search_fallback_report(report))


def _handle_config(args: Namespace) -> int:
    if args._handler == "config_set":
        save_config_file(api_key=args.api_key, base_url=args.base_url)
        if args.json:
            print_json({"ok": True, "action": "config_set", "config_path": str(CONFIG_PATH)})
        else:
            print(f"Config saved: {CONFIG_PATH}")
        return 0

    if args._handler == "config_show":
        cfg = load_config_file()
        payload = {
            "ok": True,
            "action": "config_show",
            "config_path": str(CONFIG_PATH),
            "api_key": masked_key(str(cfg.get("api_key") or "")),
            "base_url": cfg.get("base_url") or DEFAULT_BASE_URL,
        }
        if args.json:
            print_json(payload)
        else:
            print(f"Config file: {CONFIG_PATH}")
            print(f"API key: {payload['api_key']}")
            print(f"Base URL: {payload['base_url']}")
        return 0

    if args._handler == "config_clear":
        clear_config_file()
        if args.json:
            print_json({"ok": True, "action": "config_clear", "config_path": str(CONFIG_PATH)})
        else:
            print(f"Config removed: {CONFIG_PATH}")
        return 0

    raise CliUsageError("Unknown config command")


def main(argv: list[str] | None = None) -> int:
    parser = _build_parser()
    raw_argv = list(argv) if argv is not None else sys.argv[1:]
    normalized_argv = _normalize_global_cli_flags(raw_argv)
    args = parser.parse_args(normalized_argv)
    setattr(args, "json", _wants_json(args))

    if args.version:
        if args.json:
            print_json({"name": "adanos-cli", "version": __version__})
        else:
            print(f"adanos-cli {__version__}")
        return 0

    runtime_cfg = resolve_runtime_config(
        api_key_override=getattr(args, "api_key", None),
        base_url_override=getattr(args, "base_url", None),
    )

    if not getattr(args, "command", None):
        is_tty = bool(sys.stdin.isatty() and sys.stdout.isatty())
        if args.json:
            payload = _capabilities_payload(runtime_cfg.base_url, has_api_key=bool(runtime_cfg.api_key))
            payload["mode"] = "welcome"
            print_json(payload)
        elif is_tty:
            return _run_shell(
                runtime_cfg.base_url,
                has_api_key=bool(runtime_cfg.api_key),
                use_fullscreen=_resolve_shell_fullscreen(None),
                api_key=runtime_cfg.api_key,
            )
        else:
            _print_welcome_screen(runtime_cfg.base_url, has_api_key=bool(runtime_cfg.api_key))
        return 0

    if getattr(args, "command", "") == "config":
        try:
            return _handle_config(args)
        except CliUsageError as exc:
            _emit_error(
                json_mode=args.json,
                code="config_error",
                message=str(exc),
            )
            return 2

    if getattr(args, "command", "") == "watchlist" and getattr(args, "_handler", "") in {
        "watchlist_list",
        "watchlist_show",
        "watchlist_add",
        "watchlist_remove",
        "watchlist_delete",
    }:
        try:
            return _handle_watchlist_without_api(args)
        except (CliUsageError, ValueError) as exc:
            _emit_error(
                json_mode=args.json,
                code="watchlist_error",
                message=str(exc),
            )
            return 2

    handler = getattr(args, "_handler", "")
    if handler == "capabilities":
        payload = _capabilities_payload(runtime_cfg.base_url, has_api_key=bool(runtime_cfg.api_key))
        if args.json:
            print_json(payload)
        else:
            _print_capabilities_text(payload)
        return 0

    if handler == "shell":
        return _run_shell(
            runtime_cfg.base_url,
            has_api_key=bool(runtime_cfg.api_key),
            use_fullscreen=_resolve_shell_fullscreen(getattr(args, "fullscreen", None)),
            api_key=runtime_cfg.api_key,
        )

    if handler == "onboard_guide":
        if args.json:
            print_json(
                {
                    "ok": True,
                    "onboarding": {
                        "base_url": runtime_cfg.base_url,
                        "steps": [
                            "adanos onboard wizard",
                            'adanos onboard register --name "Your Name" --email "you@example.com" --purpose "CLI usage for stocks and crypto"',
                            "adanos onboard redeem --token <delivery_token> --save",
                        ],
                    },
                }
            )
        else:
            _print_onboarding_guide(runtime_cfg.base_url, has_api_key=bool(runtime_cfg.api_key))
        return 0

    if handler == "onboard_wizard":
        return _run_onboard_wizard(
            args,
            runtime_cfg.base_url,
            json_mode=args.json,
            runtime_has_key=bool(runtime_cfg.api_key),
        )

    if handler == "onboard_register":
        return _run_onboard_register(args, runtime_cfg.base_url, json_mode=args.json)

    if handler == "onboard_redeem":
        return _run_onboard_redeem(args, runtime_cfg.base_url, json_mode=args.json)

    if _requires_api_key(args) and not runtime_cfg.api_key:
        if args.json:
            _emit_error(
                json_mode=True,
                code="api_key_missing",
                message="API key is not configured",
                hint="Run `adanos onboard` or `adanos config set --api-key sk_live_xxx`",
            )
        else:
            _print_onboarding_guide(runtime_cfg.base_url)
        return 2

    if handler == "account_status":
        return _run_account_status(
            args,
            runtime_cfg.base_url,
            runtime_cfg.api_key or "",
            json_mode=args.json,
        )

    if handler == "endpoint_list":
        endpoints = [
            {
                "id": spec.endpoint_id,
                "path": spec.path,
                "description": spec.description,
                "required": list(spec.required_params),
                "optional": list(spec.optional_params),
            }
            for spec in list_endpoints()
        ]
        if args.json:
            print_json(endpoints)
        else:
            print(f"Supported OpenAPI endpoints: {len(endpoints)}")
            for spec in endpoints:
                req = f" required={','.join(spec['required'])}" if spec["required"] else ""
                opt = f" optional={','.join(spec['optional'])}" if spec["optional"] else ""
                print(f"- {spec['id']}: {spec['path']}{req}{opt}")
        return 0

    client = None

    try:
        StockSentimentClient = _load_sdk_client_class()
        client = StockSentimentClient(api_key=runtime_cfg.api_key or "", base_url=runtime_cfg.base_url)

        if handler == "endpoint_call":
            _call_and_emit_endpoint(client, args.endpoint_id, args, json_mode=args.json)
            return 0

        if handler == "stock_report":
            _run_stock_report(client, args)
            return 0

        if handler == "crypto_report":
            _run_crypto_report(client, args)
            return 0

        if handler == "ask":
            _run_ask(client, args)
            return 0

        if handler == "trending":
            _run_trending(client, args)
            return 0

        if handler == "search":
            _run_search(client, args)
            return 0

        if handler == "compare":
            _run_compare(client, args)
            return 0

        if handler == "stats":
            _run_stats(client, args)
            return 0

        if handler == "scan":
            _run_scan(client, args)
            return 0

        if handler == "briefing":
            _run_briefing(client, args)
            return 0

        if handler == "watchlist_report":
            _run_watchlist_report(client, args)
            return 0

        if handler == "health":
            _run_health(client, args)
            return 0

        raise CliUsageError("Unsupported command")

    except CliUsageError as exc:
        _emit_error(
            json_mode=args.json,
            code="usage_error",
            message=str(exc),
            hint="Run `adanos --help` or `adanos --output json capabilities`",
        )
        return 2
    except Exception as exc:  # pragma: no cover - top-level safeguard
        code, message, hint, status_code = _classify_runtime_error(exc)
        _emit_error(
            json_mode=args.json,
            code=code,
            message=message,
            hint=hint,
            status_code=status_code,
        )
        return 1
    finally:
        if client is not None:
            try:
                client.close()
            except Exception:
                pass


if __name__ == "__main__":
    raise SystemExit(main())
