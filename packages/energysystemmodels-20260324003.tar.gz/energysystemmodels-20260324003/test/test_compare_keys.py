"""
Test rapide de comparaison entre l'ancienne et la nouvelle clé API
"""

import requests

def test_both_keys():
    print("=" * 80)
    print("COMPARAISON DES CLÉS API")
    print("=" * 80)
    
    # Clés à tester
    old_key = "7b18d48745ae006628ff1ee161be2b69"
    new_key = "13d2b194c9f103cfdd70bde5b6244649"
    
    # Coordonnées de Paris
    lat, lon = 48.8566, 2.3522
    
    # Test de l'ancienne clé
    print("\n1️⃣  TEST DE L'ANCIENNE CLÉ")
    print("-" * 80)
    print(f"Clé : {old_key}")
    url_old = f"http://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={old_key}"
    
    try:
        response_old = requests.get(url_old, timeout=10)
        print(f"Code HTTP : {response_old.status_code}")
        
        if response_old.status_code == 200:
            print("✅ L'ancienne clé FONCTIONNE !")
            data = response_old.json()
            print(f"Température à Paris : {data.get('main', {}).get('temp', 0) - 273.15:.1f} °C")
        else:
            print(f"❌ L'ancienne clé ne fonctionne pas : {response_old.status_code}")
            try:
                print(f"Message : {response_old.json().get('message', 'N/A')}")
            except:
                pass
    except Exception as e:
        print(f"❌ Erreur : {e}")
    
    # Test de la nouvelle clé
    print("\n2️⃣  TEST DE LA NOUVELLE CLÉ")
    print("-" * 80)
    print(f"Clé : {new_key}")
    url_new = f"http://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&appid={new_key}"
    
    try:
        response_new = requests.get(url_new, timeout=10)
        print(f"Code HTTP : {response_new.status_code}")
        
        if response_new.status_code == 200:
            print("✅ La nouvelle clé FONCTIONNE !")
            data = response_new.json()
            print(f"Température à Paris : {data.get('main', {}).get('temp', 0) - 273.15:.1f} °C")
        else:
            print(f"❌ La nouvelle clé ne fonctionne pas : {response_new.status_code}")
            try:
                print(f"Message : {response_new.json().get('message', 'N/A')}")
            except:
                pass
    except Exception as e:
        print(f"❌ Erreur : {e}")
    
    # Recommandation
    print("\n" + "=" * 80)
    print("📋 RECOMMANDATION")
    print("=" * 80)
    
    if response_old.status_code == 200 and response_new.status_code != 200:
        print("\n⚠️  L'ancienne clé fonctionne mais pas la nouvelle.")
        print("\n💡 Actions recommandées :")
        print("   1. Vérifiez que la nouvelle clé a été copiée correctement")
        print("   2. Vérifiez sur https://home.openweathermap.org/api_keys que la clé est active")
        print("   3. Si la clé vient d'être créée, attendez 1-2 heures pour l'activation")
        print("   4. En attendant, vous pouvez continuer à utiliser l'ancienne clé")
        print("\n   Pour revenir à l'ancienne clé, modifiez config.ini avec :")
        print(f"   api={old_key}")
    elif response_old.status_code == 200 and response_new.status_code == 200:
        print("\n✅ Les deux clés fonctionnent ! Vous pouvez utiliser la nouvelle.")
    elif response_old.status_code != 200 and response_new.status_code == 200:
        print("\n✅ La nouvelle clé fonctionne ! L'ancienne clé ne fonctionne plus.")
    else:
        print("\n❌ Aucune des deux clés ne fonctionne.")
        print("   Vérifiez votre connexion Internet et votre compte OpenWeatherMap.")
    
    print("=" * 80)

if __name__ == "__main__":
    test_both_keys()
