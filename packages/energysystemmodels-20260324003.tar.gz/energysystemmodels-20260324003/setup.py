from setuptools import setup, find_packages, find_namespace_packages


# Add the documentation URL to the long description
with open("README.md","r") as fh:
    long_description=fh.read()



setup(
    name='energysystemmodels',


    version='20260324003',

    description='Energy systems models are the mathematical models that are developed in order to represent as reliably as possible various energy-related problems.',

    
    classifiers =[   'Programming Language :: Python :: 3',
    'Programming Language :: Python :: 3.6',
    'Programming Language :: Python :: 3.7',
    'Programming Language :: Python :: 3.8',
    'Programming Language :: Python :: 3.9',
    'Programming Language :: Python :: 3.10', "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",],
    package_dir = {"":"src"},
    packages=find_packages(where="src"),
    package_data={"": ["*.ini", "*.json"], },
   
    #py_modules=['AHU.HeatingCoil'],
    #packages=['ahu', 'ahu.Coil'],
    python_requires=">=3.7",
    

    long_description=long_description,
    long_description_content_type="text/markdown",
    install_requires=["pandas","pyfluids","pylab-sdk~=1.3.2","matplotlib","tkintertable~=1.3.3","numpy","pyqtgraph","thermochem","sip", "PyQt-builder","PyQt5","scikit-learn","beautifulsoup4","tqdm","statsmodels","python-docx","pvlib","gekko","networkx",],
    extra_require={"dev":["pytest>=3.7",],},
    #url="https://github.com/ZoheirHADID/EnergySystemModels",
    author="Zoheir HADID",
    author_email="zoheir.hadid@gmail.com",
    project_urls={
        'Documentation': 'https://energysystemmodels-tutorial.readthedocs.io/en/latest/',
    },
    )