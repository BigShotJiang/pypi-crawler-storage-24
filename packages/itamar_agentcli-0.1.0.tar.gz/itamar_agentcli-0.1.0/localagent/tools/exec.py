from __future__ import annotations

import os
import shlex
import subprocess
from dataclasses import dataclass
from typing import Dict, List, Optional

from rich.console import Console
from rich.panel import Panel
from rich.prompt import Confirm

from localagent.safety.approval import ApprovalPolicy


@dataclass
class CommandResult:
    command: str
    cwd: str
    exit_code: int
    stdout: str
    stderr: str


class CommandExecutor:
    """
    Executes shell commands with human-in-the-loop approval for risky commands.
    If auto_yes=True, will auto-approve ONLY whitelisted risky commands.
    """

    def __init__(
        self,
        approval: Optional[ApprovalPolicy] = None,
        console: Optional[Console] = None,
        default_cwd: Optional[str] = None,
        env_overrides: Optional[Dict[str, str]] = None,
        auto_yes: bool = False,
    ) -> None:
        self.approval = approval or ApprovalPolicy()
        self.console = console or Console()
        self.default_cwd = default_cwd or os.getcwd()
        self.env_overrides = env_overrides or {}
        self.auto_yes = auto_yes

    def run(
        self,
        command: str,
        cwd: Optional[str] = None,
        timeout_s: int = 600,
        check: bool = False,
        require_approval: bool = True,
        stream: bool = False,
    ) -> CommandResult:
        cwd_final = cwd or self.default_cwd

        # Approval step
        if require_approval:
            reason = self.approval.requires_approval(command)
            if reason:
                self.console.print(
                    Panel.fit(
                        f"[bold yellow]Approval required[/bold yellow]\n"
                        f"[bold]Reason:[/bold] {reason}\n\n"
                        f"[bold]Command:[/bold]\n{command}\n\n"
                        f"[dim]CWD:[/dim] {cwd_final}",
                        title="Dangerous Command Detected",
                    )
                )

                # Auto-approve only whitelisted commands when --yes is enabled
                if self.auto_yes and self.approval.is_autoapprove_whitelisted(command):
                    self.console.print(
                        "[bold yellow]Auto-approval enabled (--yes + whitelist). Proceeding...[/bold yellow]"
                    )
                else:
                    if not Confirm.ask("Execute this command?", default=False):
                        return CommandResult(
                            command=command,
                            cwd=cwd_final,
                            exit_code=130,
                            stdout="",
                            stderr="User rejected command execution.",
                        )

        env = os.environ.copy()
        env.update(self.env_overrides)

        self.console.print(
            Panel.fit(
                f"[bold cyan]$[/bold cyan] {command}\n[dim]cwd:[/dim] {cwd_final}",
                title="Executing",
            )
        )

        args: List[str] = shlex.split(command)

        if stream:
            proc = subprocess.Popen(
                args,
                cwd=cwd_final,
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1,
            )
            out_lines: List[str] = []
            err_lines: List[str] = []

            assert proc.stdout is not None
            assert proc.stderr is not None

            for line in proc.stdout:
                out_lines.append(line)
                self.console.print(line.rstrip("\n"))

            err_text = proc.stderr.read()
            if err_text:
                err_lines.append(err_text)
                self.console.print(err_text, style="bold red")

            exit_code = proc.wait(timeout=timeout_s)
            stdout = "".join(out_lines)
            stderr = "".join(err_lines)
        else:
            completed = subprocess.run(
                args,
                cwd=cwd_final,
                env=env,
                capture_output=True,
                text=True,
                timeout=timeout_s,
            )
            exit_code = completed.returncode
            stdout = completed.stdout or ""
            stderr = completed.stderr or ""

            if stdout.strip():
                self.console.print(Panel.fit(stdout.rstrip(), title="stdout"))
            if stderr.strip():
                self.console.print(Panel.fit(stderr.rstrip(), title="stderr", style="red"))

        if check and exit_code != 0:
            raise subprocess.CalledProcessError(exit_code, args, stdout, stderr)

        return CommandResult(
            command=command,
            cwd=cwd_final,
            exit_code=exit_code,
            stdout=stdout,
            stderr=stderr,
        )
