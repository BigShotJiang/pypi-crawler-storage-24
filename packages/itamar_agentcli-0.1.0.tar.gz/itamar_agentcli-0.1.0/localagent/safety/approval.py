from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional, Sequence


@dataclass(frozen=True)
class ApprovalDecision:
    approved: bool
    reason: str


class ApprovalPolicy:
    """
    Heuristic-based approval for shell commands + a small whitelist mechanism
    for auto-approval (e.g., dnf installs) when --yes is used.
    """

    DEFAULT_DANGEROUS_PATTERNS: Sequence[str] = (
        r"\brm\b.*\s-rf\b",
        r"\brm\b.*\s--no-preserve-root\b",
        r"\bdd\b",
        r"\bmkfs\.",
        r"\bchmod\b\s+777\b",
        r"\bchown\b.*\s-R\b",
        r"\bshutdown\b|\breboot\b",
        r"\bsystemctl\b\s+(stop|disable|mask)\b",
        r"\bdnf\b\s+(install|remove|upgrade|update)\b",
        r"\byum\b\s+(install|remove|update|upgrade)\b",
        r"\bpip\b\s+install\b",
        r"\bcurl\b.*\|\s*(sh|bash)\b",
        r"\bwget\b.*\|\s*(sh|bash)\b",
        r"\bchmod\b.*\+x\b.*\.\w+",
        r"\bsudo\b",
    )

    def __init__(self, extra_patterns: Optional[Sequence[str]] = None) -> None:
        patterns = list(self.DEFAULT_DANGEROUS_PATTERNS)
        if extra_patterns:
            patterns.extend(extra_patterns)
        self._compiled = [re.compile(p, re.IGNORECASE) for p in patterns]

    def requires_approval(self, command: str) -> Optional[str]:
        cmd = command.strip()
        for rx in self._compiled:
            if rx.search(cmd):
                return f"Matched risky pattern: {rx.pattern}"
        return None

    def is_autoapprove_whitelisted(self, command: str) -> bool:
        """
        Commands allowed for auto-approval when --yes is used.
        Keep this list tight and explicit.
        """
        cmd = command.strip().lower()

        # Allow these admin package operations to auto-approve
        whitelist_prefixes = (
            "sudo dnf install",
            "sudo dnf update",
            "sudo dnf upgrade",
            "sudo dnf remove",
            "dnf install",
            "dnf update",
            "dnf upgrade",
            "dnf remove",
            "sudo dnf autoremove",
            "dnf autoremove",
            "sudo dnf clean",
            "dnf clean",
            "sudo dnf makecache",
            "dnf makecache",
        )
        return cmd.startswith(whitelist_prefixes)
