import re

def parse_command(text: str) -> str | None:
    text = text.lower()

    # install packages
    if "nmap" in text:
        return "sudo dnf install -y nmap"

    if "ffmpeg" in text:
        return "sudo dnf install -y ffmpeg --allowerasing"

    if "yt-dlp" in text or "youtube" in text:
        return "sudo dnf install -y yt-dlp"

    if "update" in text or "עדכן" in text:
        return "sudo dnf update -y"

    if "נקה" in text or "clean" in text:
        return "sudo dnf autoremove -y"

    return None
