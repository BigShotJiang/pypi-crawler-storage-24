from __future__ import annotations

import typer
from rich.console import Console

from localagent.tools.exec import CommandExecutor

console = Console()
app = typer.Typer(add_completion=False)


@app.command()
def main(
    command: str = typer.Argument(
        ...,
        help='Command to run. Quote it if it contains spaces, e.g. "ls -la"',
    ),
    yes: bool = typer.Option(
        False,
        "--yes",
        help="Auto-approve ONLY whitelisted dangerous commands (dnf install/update/upgrade/remove).",
    ),
    stream: bool = typer.Option(
        False,
        "--stream",
        help="Stream stdout live while running.",
    ),
):
    """LocalAgent command runner (with approvals)."""
    executor = CommandExecutor(console=console, auto_yes=yes)
    result = executor.run(command=command, require_approval=True, stream=stream)
    raise typer.Exit(code=result.exit_code)


if __name__ == "__main__":
    app()
