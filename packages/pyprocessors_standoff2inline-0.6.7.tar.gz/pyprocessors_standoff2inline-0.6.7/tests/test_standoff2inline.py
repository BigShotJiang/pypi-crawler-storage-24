import json
from pathlib import Path

import jinja2
import pytest
from pymultirole_plugins.v1.schema import Annotation, Document, Sentence

from pyprocessors_standoff2inline.standoff2inline import (
    StandoffToInlineParameters,
    StandoffToInlineProcessor,
    get_template,
    group_annotations_by_sentences,
    render_template,
)
from pyprocessors_standoff2inline.standoff2inline_processor import Highlighter, Standoff2Inline, highlight_characters


def test_model():
    model = StandoffToInlineProcessor.get_model()
    model_class = model.model_construct().__class__
    assert model_class == StandoffToInlineParameters


def test_standoff2inline():
    testdir = Path(__file__).parent
    source = Path(testdir, "data/evalLLM1.json")

    with source.open("r") as fin:
        jdoc = json.load(fin)
    docs = [Document(**jdoc)]
    processor = StandoffToInlineProcessor()
    parameters = StandoffToInlineParameters()
    docs = processor.process(docs, parameters)
    doc0 = docs[0]
    assert "<p>" in doc0.text
    assert "<non_inf_disease>" in doc0.text

    docs = [Document(**jdoc)]
    parameters.as_altText = "Inlined"
    parameters.s_open = " "
    parameters.s_close = " "
    parameters.a_open = '<{{a.labelName}} id="{{d.identifier}}-{{a.start}}:{{a.end}}">'
    docs = processor.process(docs, parameters)
    doc0 = docs[0]
    assert len(doc0.altTexts) == 1

    docs = [Document(**jdoc)]
    parameters.as_altText = "Inlined"
    parameters.d_open = '<segments>{{"\n\n"}}'
    parameters.d_close = '{{"\n\n"}}</segments>{{"\n\n"}}'
    parameters.s_open = '<segment "id"="{{s.start}}:{{s.end}}">{{"\n\n"}}'
    parameters.s_close = '{{"\n\n"}}</segment">{{"\n\n"}}'
    parameters.a_open = ""
    parameters.a_close = ""
    docs = processor.process(docs, parameters)
    doc0 = docs[0]
    assert len(doc0.altTexts) == 1


def test_standoff2inline_archer():
    testdir = Path(__file__).parent
    source = Path(testdir, "data/archer_ner2_en-export-search.json")
    if not source.exists():
        pytest.skip("archer data file not available")

    with source.open("r") as fin:
        jdocs = json.load(fin)
    docs = [Document(**jdoc) for jdoc in jdocs]
    processor = StandoffToInlineProcessor()
    parameters = StandoffToInlineParameters(as_altText="Archer")
    parameters.d_open = ""
    parameters.d_close = ""
    parameters.s_open = ""
    parameters.s_close = ""
    parameters.a_open = "<{{a.label}}>"
    parameters.a_close = "</{{a.label}}>"
    docs = processor.process(docs, parameters)
    archerdir = Path(__file__).parent / "data/archer"
    archerdir.mkdir(exist_ok=True)
    for doc in docs:
        filename = doc.title.replace(".txt", ".ne")
        outputfile = Path(archerdir, filename)
        with outputfile.open("w") as fout:
            alttexts = {alt.name: alt.text for alt in doc.altTexts}
            print(alttexts["Archer"], file=fout)


# --- get_template tests ---


def test_get_template_none_returns_none():
    assert get_template(None) is None


def test_get_template_empty_returns_none():
    assert get_template("") is None
    assert get_template("   ") is None


def test_get_template_valid_returns_template():
    tmpl = get_template("<{{a.labelName}}>")
    assert tmpl is not None
    assert isinstance(tmpl, jinja2.Template)


# --- render_template tests ---


def test_render_template_none_returns_empty():
    assert render_template(None) == ""


def test_render_template_renders_variables():
    tmpl = get_template("{{x}}-{{y}}")
    assert render_template(tmpl, x="hello", y="world") == "hello-world"


# --- group_annotations_by_sentences tests ---


def test_group_annotations_no_annotations():
    doc = Document(identifier="t", text="hello world")
    groups = group_annotations_by_sentences(doc)
    assert len(groups) == 0


def test_group_annotations_by_sentences_distributes_correctly():
    doc = Document(
        identifier="t",
        text="hello world foo",
        sentences=[Sentence(start=0, end=11), Sentence(start=12, end=15)],
        annotations=[
            Annotation(start=0, end=5, label="A", labelName="A"),
            Annotation(start=6, end=11, label="B", labelName="B"),
            Annotation(start=12, end=15, label="C", labelName="C"),
        ],
    )
    groups = group_annotations_by_sentences(doc)
    assert len(groups[0]) == 2
    assert len(groups[1]) == 1


# --- processor: document without pre-existing sentences ---


def test_process_no_sentences_auto_creates_span():
    doc = Document(identifier="t", text="hello world")
    processor = StandoffToInlineProcessor()
    params = StandoffToInlineParameters(s_open="[", s_close="]")
    result = processor.process([doc], params)
    assert "[" in result[0].text
    assert "]" in result[0].text


# --- processor: result replaces text and clears sentences/annotations ---


def test_process_replaces_text_and_clears_fields():
    doc = Document(
        identifier="t",
        text="hello",
        sentences=[Sentence(start=0, end=5)],
        annotations=[Annotation(start=0, end=5, label="X", labelName="X")],
    )
    processor = StandoffToInlineProcessor()
    params = StandoffToInlineParameters()
    result = processor.process([doc], params)
    assert result[0].sentences == []
    assert result[0].annotations == []
    assert result[0].categories == []


# --- processor: as_altText appends to altTexts without clearing fields ---


def test_process_as_alttext_does_not_replace_text():
    original_text = "hello"
    doc = Document(
        identifier="t",
        text=original_text,
        sentences=[Sentence(start=0, end=5)],
    )
    processor = StandoffToInlineProcessor()
    params = StandoffToInlineParameters(as_altText="MyAlt")
    result = processor.process([doc], params)
    assert result[0].text == original_text
    assert len(result[0].altTexts) == 1
    assert result[0].altTexts[0].name == "MyAlt"


# --- Standoff2Inline low-level tests ---


def test_standoff2inline_basic():
    # "cat" occupies positions 11-13; with end_is_stop=False, end tag is placed after position 13
    s = "The little cat drinks milk."
    inliner = Standoff2Inline()
    inliner.add((11, "<noun>"), (13, "</noun>"))
    result = inliner.apply(s)
    assert "<noun>cat</noun>" in result


def test_standoff2inline_end_is_stop():
    s = "abcdef"
    inliner = Standoff2Inline(end_is_stop=True)
    inliner.add((0, "["), (3, "]"))
    result = inliner.apply(s)
    assert result == "[abc]def"


def test_standoff2inline_xml_kind():
    s = "hello world"
    inliner = Standoff2Inline(kind="xml")
    inliner.add((0, ("noun", {})), (5, None))
    result = inliner.apply(s)
    assert "<noun>" in result
    assert "</noun>" in result


def test_standoff2inline_xml_kind_with_attrs():
    s = "hello world"
    inliner = Standoff2Inline(kind="xml")
    inliner.add((0, ("noun", {"id": "1"})), (5, None))
    result = inliner.apply(s)
    assert '<noun id="1">' in result


def test_standoff2inline_sacr_kind():
    s = "hello world"
    inliner = Standoff2Inline(kind="sacr")
    inliner.add((0, ("np", {})), (5, None))
    result = inliner.apply(s)
    assert "{np " in result
    assert "}" in result


def test_standoff2inline_invalid_kind():
    inliner = Standoff2Inline(kind="unknown")
    inliner.add((0, ("x", {})), (5, None))
    with pytest.raises(AssertionError):
        inliner.apply("hello world")


def test_standoff2inline_tokens():
    tokens = ["The", "little", "cat", "drinks", "milk", "."]
    inliner = Standoff2Inline()
    inliner.add((2, "<noun>"), (2, "</noun>"))
    result = inliner.apply(tokens=tokens)
    assert "<noun>cat</noun>" in result


# --- Highlighter tests ---


def test_highlighter_basic():
    # "hello" occupies positions 0-4; with end_is_stop=False, end tag is placed after position 4
    hl = Highlighter()
    hl.add_mark(0, 4, prefix="[", suffix="]")
    result = highlight_characters("hello world", hl)
    assert result.startswith("[hello]")


def test_highlighter_add_marks():
    hl = Highlighter(prefix="*", suffix="*")
    hl.add_marks([(0, 5), (6, 11)])
    result = highlight_characters("hello world", hl)
    assert "*" in result


def test_highlighter_set_style():
    hl = Highlighter()
    hl.set_style(bold=True, color="red")
    hl.add_mark(0, 5)
    result = highlight_characters("hello world", hl)
    assert "font-weight: bold" in result
    assert "color: red" in result
    assert "<span" in result
    assert "</span>" in result
