"""Pytest plugin entry point with HTTP monkeypatching."""

from __future__ import annotations

import logging
from collections.abc import Generator
from pathlib import Path
from typing import TYPE_CHECKING, Any

import pytest

from pytest_api_coverage.adapters import ADAPTER_REGISTRY
from pytest_api_coverage.collector import CoverageCollector
from pytest_api_coverage.config.settings import CoverageSettings
from pytest_api_coverage.orchestrator import MultiSpecOrchestrator
from pytest_api_coverage.reporter import CoverageReporter
from pytest_api_coverage.schemas import SwaggerParser, SwaggerSpec
from pytest_api_coverage.terminal import print_multi_spec_summary, print_terminal_summary
from pytest_api_coverage.writers import write_reports

if TYPE_CHECKING:
    from pytest import Config, Item, Parser, Session, TerminalReporter

logger = logging.getLogger("pytest_api_coverage")


def pytest_addoption(parser: Parser) -> None:
    """Add CLI options for API coverage."""
    group = parser.getgroup("api-coverage")
    group.addoption(
        "--coverage-spec",
        dest="coverage_spec",
        type=str,
        default=None,
        help="Path to a local OpenAPI/Swagger spec file (JSON/YAML) or a remote URL. Enables API coverage tracking for the given specification.",
    )
    group.addoption(
        "--coverage-output",
        dest="coverage_output",
        type=str,
        default="api-coverage-report",
        help="Directory where coverage report files will be saved. Default: ./api-coverage-report",
    )
    group.addoption(
        "--coverage-format",
        dest="coverage_format",
        type=str,
        default="html",
        help="Comma-separated list of report formats to generate. Supported formats: json, csv, html, all. 'all' expands to all supported formats. Default: html",
    )
    group.addoption(
        "--coverage-strip-prefix",
        dest="coverage_strip_prefix",
        type=str,
        default=None,
        help="Comma-separated path prefixes to strip from request URLs before matching against the spec. Useful when the API is served under a base path not present in the spec. Example: /v1,/api/v2",
    )
    group.addoption(
        "--coverage-split-by-origin",
        dest="coverage_split_by_origin",
        action="store_true",
        default=False,
        help="When enabled, coverage statistics are grouped separately for each unique API origin (host:port) found in recorded requests.",
    )
    group.addoption(
        "--coverage-config",
        dest="coverage_config",
        type=str,
        default=None,
        help="Path to an api-coverage configuration file (YAML or JSON) that defines multiple specs, their API URLs, and shared settings. See documentation for the config file format.",
    )
    group.addoption(
        "--coverage-spec-name",
        dest="coverage_spec_name",
        type=str,
        default=None,
        help="Label for a single CLI spec, or filter name to select a spec from the config file.",
    )
    group.addoption(
        "--coverage-url-filter",
        dest="coverage_url_filter",
        action="append",
        default=None,
        help="Filter string to match request URLs against (substring match). Can be specified multiple times. Requires --coverage-spec. Example: --coverage-url-filter api.example.com",
    )


def pytest_configure(config: Config) -> None:
    """Register the appropriate plugin based on execution mode."""
    if not CoverageSettings.from_pytest_config(config).is_enabled():
        return  # Coverage not enabled

    # Determine execution mode
    if hasattr(config, "workerinput"):
        # Worker node in xdist
        plugin_class = CoverageWorkerPlugin
    elif _is_xdist_master(config):
        # Master node with active xdist workers
        plugin_class = CoverageMasterPlugin
    else:
        # Single process mode
        plugin_class = CoverageSinglePlugin

    if config.pluginmanager.has_plugin("api_coverage_plugin"):
        return
    logger.debug("Registering %s", plugin_class.__name__)
    plugin = plugin_class(config)
    config.pluginmanager.register(plugin, "api_coverage_plugin")


def _build_activity_line(settings: CoverageSettings) -> str | None:
    """Build the startup activity indicator line for the terminal.

    Returns a formatted string describing the active plugin mode, or None
    if neither swagger nor specs are configured (should not happen after
    is_enabled() check, but guard anyway).
    """
    if settings.specs:
        spec_names = ", ".join(s.name for s in settings.specs)
        return f"[api-coverage] Active | mode: multi-spec | specs: {spec_names} | output: {settings.output_dir}/"
    if settings.spec:
        stem = Path(str(settings.spec)).stem
        return f"[api-coverage] Active | mode: single-spec | spec: {stem} | output: {settings.output_dir}/"
    return None


def _is_xdist_master(config: pytest.Config) -> bool:
    """Check if we're running as xdist master with active workers.

    Returns True only if:
    - xdist plugin is available
    - -n option was specified with value > 0, or set to "auto"
    """
    if not config.pluginmanager.hasplugin("xdist"):
        return False
    numprocesses = getattr(config.option, "numprocesses", None)
    if numprocesses is None:
        return False
    if isinstance(numprocesses, str):  # e.g. "auto"
        return True
    return numprocesses > 0


class _InterceptionMixin:
    """Shared HTTP interception logic for single-process and worker plugins.

    Requires subclass to set:
        self.collector: CoverageCollector
        self._adapters: list[HttpAdapter]
    """

    collector: CoverageCollector
    _adapters: list[Any]

    @pytest.hookimpl(tryfirst=True)
    def pytest_runtest_setup(self, item: Item) -> None:
        """Set current test name before any other plugin's setup runs."""
        self.collector.set_current_test(item.nodeid)

    @pytest.hookimpl(trylast=True)
    def pytest_runtest_teardown(self, item: Item) -> None:
        """Clear current test name after all other plugins' teardown completes."""
        self.collector.set_current_test(None)

    @pytest.hookimpl(hookwrapper=True, trylast=True)
    def pytest_runtest_protocol(self, item: Item, nextitem: Item | None) -> Generator[None, None, None]:
        """Safety net: ensure _current_test is always cleared after each test."""
        yield
        self.collector.set_current_test(None)

    def _setup_http_interception(self) -> None:
        """Install HTTP adapters for requests and httpx."""
        for adapter in self._adapters:
            adapter.install()

    def _teardown_http_interception(self) -> None:
        """Uninstall HTTP adapters to prevent memory leaks."""
        for adapter in self._adapters:
            adapter.uninstall()


class _SwaggerLoadMixin:
    """Shared swagger loading logic for single-process and master plugins.

    Requires subclass to set:
        self.settings: CoverageSettings
    Sets:
        self.swagger_spec: SwaggerSpec | None
        self._swagger_load_error: str | None
    """

    settings: CoverageSettings
    swagger_spec: SwaggerSpec | None
    _swagger_load_error: str | None

    def _load_swagger(self) -> None:
        """Load and parse swagger specification."""
        if not self.settings.spec:
            return
        try:
            self.swagger_spec = SwaggerParser.parse(self.settings.spec)
        except Exception as e:
            self._swagger_load_error = str(e)
            logger.warning("Failed to load swagger: %s", e, exc_info=True)


class CoverageSinglePlugin(_InterceptionMixin, _SwaggerLoadMixin):
    """Coverage plugin for single-process test execution."""

    def __init__(self, config: Config) -> None:
        self.config = config
        self.settings = CoverageSettings.from_pytest_config(config)
        self.collector = CoverageCollector()
        self._adapters = [cls(self.collector) for cls in ADAPTER_REGISTRY]
        self.swagger_spec: SwaggerSpec | None = None
        self._swagger_load_error: str | None = None
        self._no_requests_captured: bool = False
        self.report_data: dict[str, Any] | None = None
        self.orchestrator: MultiSpecOrchestrator | None = None
        self._all_reports: dict[str, Any] = {}

    @pytest.hookimpl
    def pytest_sessionstart(self, session: Session) -> None:
        """Setup HTTP interception at session start."""
        self.settings.raise_if_error()  # raise deferred config errors here
        # Load all specs BEFORE installing HTTP adapters so that any remote spec
        # fetches (httpx.Client) are not intercepted and recorded as coverage data.
        self._load_swagger()
        if self.settings.specs:
            self.orchestrator = MultiSpecOrchestrator(self.settings)
        self._setup_http_interception()
        tr: TerminalReporter | None = session.config.pluginmanager.get_plugin("terminalreporter")
        if tr is not None:
            line = _build_activity_line(self.settings)
            if line is not None:
                tr.write_line(line)

    @pytest.hookimpl(trylast=True)
    def pytest_sessionfinish(self, session: Session, exitstatus: int) -> None:
        """Generate coverage reports at session end."""
        if self.settings.specs and self.orchestrator:
            self.orchestrator.process_interactions(self.collector.get_data())
            self._all_reports = self.orchestrator.generate_all_reports()
        elif self.swagger_spec:
            if self.collector.has_data():
                self._generate_report()
            else:
                self._no_requests_captured = True

    @pytest.hookimpl(trylast=True)
    def pytest_terminal_summary(self, terminalreporter: TerminalReporter) -> None:
        """Print coverage summary to terminal."""
        if self.orchestrator:
            print_multi_spec_summary(
                terminalreporter,
                self.orchestrator,
                reports=self._all_reports,
                record_errors=self.collector.record_error_count,
                failed_specs=self.orchestrator.failed_specs,
            )
        elif self.report_data:
            print_terminal_summary(
                terminalreporter,
                self.report_data,
                self.settings,
                record_errors=self.collector.record_error_count,
            )
        elif self._swagger_load_error:
            terminalreporter.write_sep("=", "API Coverage Summary")
            terminalreporter.write_line(
                f"[api-coverage] No report generated — spec failed to load: {self._swagger_load_error}"
            )
        elif self._no_requests_captured:
            terminalreporter.write_sep("=", "API Coverage Summary")
            terminalreporter.write_line(
                "[api-coverage] 0 HTTP requests captured. "
                "Check that tests use 'requests' or 'httpx' directly and that "
                "mocking libraries are not intercepting at the socket level."
            )

    @pytest.hookimpl
    def pytest_unconfigure(self, config: Config) -> None:
        """Clean up adapters when pytest finishes."""
        self._teardown_http_interception()

    def _generate_report(self) -> None:
        """Generate coverage report using reporter."""
        if not self.swagger_spec:
            return

        reporter = CoverageReporter(
            self.swagger_spec,
            strip_prefixes=self.settings.strip_prefixes or None,
            split_by_origin=self.settings.split_by_origin,
        )
        reporter.process_interactions(self.collector.get_data())
        self.report_data = reporter.generate_report()

        # Write reports to files
        written = write_reports(self.report_data, self.settings.output_dir, self.settings.formats)
        if written:
            logger.info("Reports written to: %s", self.settings.output_dir)


class CoverageMasterPlugin(_SwaggerLoadMixin):
    """Coverage plugin for xdist master node."""

    def __init__(self, config: Config) -> None:
        self.config = config
        self.settings = CoverageSettings.from_pytest_config(config)
        self.worker_data: dict[str, Any] = {}
        self.swagger_spec: SwaggerSpec | None = None
        self._swagger_load_error: str | None = None
        self.report_data: dict[str, Any] | None = None
        self.orchestrator: MultiSpecOrchestrator | None = None
        self._all_reports: dict[str, Any] = {}

    @pytest.hookimpl
    def pytest_sessionstart(self, session: Session) -> None:
        """Load swagger and log plugin activity at session start."""
        self.settings.raise_if_error()  # raise deferred config errors here
        # Initialize orchestrator here (not in __init__) to ensure spec fetches
        # happen before HTTP adapters are installed.
        self._load_swagger()
        if self.settings.specs:
            self.orchestrator = MultiSpecOrchestrator(self.settings)
        tr: TerminalReporter | None = session.config.pluginmanager.get_plugin("terminalreporter")
        if tr is None:
            return
        line = _build_activity_line(self.settings)
        if line is not None:
            tr.write_line(line)

    @pytest.hookimpl
    def pytest_configure_node(self, node: object) -> None:
        """Send configuration to worker nodes."""
        node.workerinput["coverage_settings"] = self.settings.to_dict()  # type: ignore[attr-defined]

    @pytest.hookimpl
    def pytest_testnodedown(self, node: object, error: object) -> None:
        """Collect coverage data from finished worker."""
        if hasattr(node, "gateway") and node.gateway:
            worker_id = node.gateway.id  # type: ignore[attr-defined]
        else:
            worker_id = str(node)
        if hasattr(node, "workeroutput") and "coverage_data" in node.workeroutput:  # type: ignore[attr-defined]
            self.worker_data[worker_id] = node.workeroutput["coverage_data"]  # type: ignore[attr-defined]
        else:
            if error:
                logger.warning("Worker %s finished with error and no coverage_data: %s", worker_id, error)
            else:
                logger.warning("Worker %s finished without coverage_data — coverage may be incomplete", worker_id)

    @pytest.hookimpl(trylast=True)
    def pytest_sessionfinish(self, session: Session, exitstatus: int) -> None:
        """Aggregate worker data and generate reports."""
        if self.settings.specs and self.orchestrator:
            # Multi-spec mode: merge per_spec dicts from each worker
            merged: dict[str, list[dict[str, Any]]] = {s.name: [] for s in self.settings.specs}
            for _worker_id, data in self.worker_data.items():
                if isinstance(data, dict) and "per_spec" in data:
                    for spec_name, interactions in data["per_spec"].items():
                        if spec_name in merged:
                            merged[spec_name].extend(interactions)
                    self.orchestrator.unmatched_count += data.get("unmatched_count", 0)

            # Feed merged per-spec interactions directly to reporters
            for spec_name, interactions in merged.items():
                reporter = self.orchestrator.reporters.get(spec_name)
                if reporter:
                    reporter.process_interactions(interactions)
            self._all_reports = self.orchestrator.generate_all_reports()
        else:
            # Legacy path
            all_data: list[dict[str, Any]] = []
            for _worker_id, data in self.worker_data.items():
                if isinstance(data, list):
                    all_data.extend(data)
            if all_data and self.swagger_spec:
                self._generate_report(all_data)

    @pytest.hookimpl(trylast=True)
    def pytest_terminal_summary(self, terminalreporter: TerminalReporter) -> None:
        """Print coverage summary to terminal."""
        if self.orchestrator:
            print_multi_spec_summary(
                terminalreporter,
                self.orchestrator,
                reports=self._all_reports,
                failed_specs=self.orchestrator.failed_specs,
            )
        elif self.report_data:
            print_terminal_summary(terminalreporter, self.report_data, self.settings)
        elif self._swagger_load_error:
            terminalreporter.write_sep("=", "API Coverage Summary")
            terminalreporter.write_line(
                f"[api-coverage] No report generated — spec failed to load: {self._swagger_load_error}"
            )
        elif self.swagger_spec and not self.worker_data:
            terminalreporter.write_sep("=", "API Coverage Summary")
            terminalreporter.write_line(
                "[api-coverage] 0 HTTP requests captured from workers. "
                "Check that workers are sending coverage data and that "
                "mocking libraries are not intercepting at the socket level."
            )

    @pytest.hookimpl
    def pytest_unconfigure(self, config: Config) -> None:
        """Unregister master plugin on teardown."""
        config.pluginmanager.unregister(self)

    def _generate_report(self, data: list[dict[str, Any]]) -> None:
        """Generate coverage report from aggregated worker data."""
        if not self.swagger_spec:
            return

        reporter = CoverageReporter(
            self.swagger_spec,
            strip_prefixes=self.settings.strip_prefixes or None,
            split_by_origin=self.settings.split_by_origin,
        )
        reporter.process_interactions(data)
        self.report_data = reporter.generate_report()

        # Write reports to files
        written = write_reports(self.report_data, self.settings.output_dir, self.settings.formats)
        if written:
            logger.info("Reports written to: %s", self.settings.output_dir)


def _route_interaction_for_worker(interaction: dict[str, Any], specs: list[Any]) -> str | None:
    """Minimal routing for worker pre-filtering.

    Avoids importing MultiSpecOrchestrator on workers to keep them lightweight.
    """
    from pytest_api_coverage.utils import matches_filter_value  # noqa: PLC0415

    url = interaction.get("request", {}).get("url", "")

    for spec in specs:
        for filter_value in spec.api_filters:
            if matches_filter_value(url, filter_value):
                return spec.name
    return None


class CoverageWorkerPlugin(_InterceptionMixin):
    """Coverage plugin for xdist worker nodes."""

    def __init__(self, config: Config) -> None:
        self.config = config
        self.collector = CoverageCollector()
        self.settings = CoverageSettings.from_dict(config.workerinput.get("coverage_settings", {}))  # type: ignore[attr-defined]
        self._adapters = [cls(self.collector) for cls in ADAPTER_REGISTRY]

    @pytest.hookimpl
    def pytest_sessionstart(self, session: Session) -> None:
        """Setup HTTP interception on worker."""
        self.settings.raise_if_error()  # raise deferred config errors here
        self._setup_http_interception()

    @pytest.hookimpl(trylast=True)
    def pytest_sessionfinish(self, session: Session, exitstatus: int) -> None:
        """Send collected data back to master."""
        if self.settings.specs:
            per_spec: dict[str, list[dict[str, Any]]] = {s.name: [] for s in self.settings.specs}
            unmatched_count = 0
            for interaction in self.collector.get_data():
                spec_name = _route_interaction_for_worker(interaction, self.settings.specs)
                if spec_name and spec_name in per_spec:
                    per_spec[spec_name].append(interaction)
                else:
                    unmatched_count += 1
            session.config.workeroutput["coverage_data"] = {  # type: ignore[attr-defined]
                "per_spec": per_spec,
                "unmatched_count": unmatched_count,
            }
        else:
            session.config.workeroutput["coverage_data"] = self.collector.get_data()  # type: ignore[attr-defined]

    @pytest.hookimpl
    def pytest_unconfigure(self, config: Config) -> None:
        """Clean up adapters when worker finishes."""
        self._teardown_http_interception()
