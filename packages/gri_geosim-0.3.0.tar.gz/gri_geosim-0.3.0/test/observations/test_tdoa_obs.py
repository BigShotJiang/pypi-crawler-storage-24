"""Tests for TdoaObservation.

Tests verify TDOA observation structure, validation, and properties.
"""

from __future__ import annotations

import numpy as np
import pytest
from gri_nsepoch import Time
from gri_pos import Pos

from gri_geosim.observations import TdoaObservation

_TIME = Time(s=0.0)
_COLLECTOR1 = Pos.XYZ(1e6, 2e6, 3e6)
_COLLECTOR2 = Pos.XYZ(1.1e6, 2.1e6, 3.1e6)


def _make_obs(
    value: float = 1.5e-6,
    std_dev: float = 1e-9,
) -> TdoaObservation:
    """Create a TDOA observation with defaults."""
    return TdoaObservation(
        time=_TIME,
        value=value,
        std_dev=std_dev,
        collector1=_COLLECTOR1,
        collector2=_COLLECTOR2,
        sensor_id="test",
    )


# Initialization


@pytest.mark.parametrize(
    ("value", "std_dev"),
    [
        (0.0, 1e-9),  # Zero TDOA
        (1e-6, 1e-9),  # Positive TDOA (1 microsecond)
        (-1e-6, 1e-9),  # Negative TDOA
        (1e-9, 1e-10),  # Small TDOA (1 nanosecond)
    ],
    ids=["zero", "positive", "negative", "nanosecond"],
)
def test_valid_values(value: float, std_dev: float) -> None:
    """Verify observation accepts valid TDOA values."""
    obs = _make_obs(value=value, std_dev=std_dev)

    assert obs.value == value
    assert obs.std_dev == std_dev


def test_variance_property() -> None:
    """Verify variance property computes from std_dev."""
    std_dev = 1e-9
    obs = _make_obs(std_dev=std_dev)

    assert np.isclose(obs.variance, std_dev**2)


# Metadata


def test_obs_type() -> None:
    """Verify observation type is TDOA."""
    obs = _make_obs()

    assert obs.obs_type == "TDOA"


def test_sensor_id() -> None:
    """Verify sensor ID is stored."""
    obs = TdoaObservation(
        time=_TIME,
        value=1e-6,
        std_dev=1e-9,
        collector1=_COLLECTOR1,
        collector2=_COLLECTOR2,
        sensor_id="my_sensor",
    )

    assert obs.sensor_id == "my_sensor"


def test_emitter_id() -> None:
    """Verify emitter ID is stored when provided."""
    obs = TdoaObservation(
        time=_TIME,
        value=1e-6,
        std_dev=1e-9,
        collector1=_COLLECTOR1,
        collector2=_COLLECTOR2,
        sensor_id="test",
        emitter_id="target1",
    )

    assert obs.emitter_id == "target1"


def test_emitter_id_optional() -> None:
    """Verify emitter ID defaults to None."""
    obs = _make_obs()

    assert obs.emitter_id is None


# Time property


def test_time_property() -> None:
    """Verify time property returns observation time."""
    obs = _make_obs()

    assert obs.time == _TIME


# Collector positions


def test_collector_positions() -> None:
    """Verify collector positions are stored correctly."""
    obs = _make_obs()

    assert np.allclose(obs.collector1.xyz, _COLLECTOR1.xyz)
    assert np.allclose(obs.collector2.xyz, _COLLECTOR2.xyz)


# Validity check


def test_is_valid_with_finite_values() -> None:
    """Verify is_valid returns True for finite values."""
    obs = _make_obs()

    assert obs.is_valid()


def test_is_valid_with_nan() -> None:
    """Verify is_valid returns False for NaN values."""
    obs = TdoaObservation(
        time=_TIME,
        value=float("nan"),
        std_dev=1e-9,
        collector1=_COLLECTOR1,
        collector2=_COLLECTOR2,
        sensor_id="test",
    )

    assert not obs.is_valid()


# String representations


def test_repr() -> None:
    """Verify string representation."""
    obs = _make_obs()

    repr_str = repr(obs)
    assert "TdoaObservation" in repr_str
    assert "test" in repr_str


def test_str() -> None:
    """Verify human-readable string."""
    obs = _make_obs()

    str_repr = str(obs)
    assert "TDOA" in str_repr


# Equality and hashing


def test_equality() -> None:
    """Verify equality comparison."""
    obs1 = _make_obs()
    obs2 = _make_obs()

    assert obs1 == obs2


def test_inequality_different_value() -> None:
    """Verify inequality for different values."""
    obs1 = _make_obs(value=1e-6)
    obs2 = _make_obs(value=2e-6)

    assert obs1 != obs2


def test_hash() -> None:
    """Verify observations are hashable."""
    obs1 = _make_obs()
    obs2 = _make_obs()

    assert hash(obs1) == hash(obs2)

    # Can be used in sets
    obs_set = {obs1, obs2}
    assert len(obs_set) == 1
