"""Tests for AoaObservation.

Tests verify AOA observation structure, validation, and immutability.
"""

from __future__ import annotations

import math

import numpy as np
import pytest
from gri_nsepoch import Time
from gri_pos import Pos
from scipy.spatial.transform import Rotation

from gri_geosim.observations import AoaObservation

_TIME = Time(s=0.0)
_COLLECTOR = Pos.XYZ(1e6, 2e6, 3e6)
_ROTATION = Rotation.identity()
_COVARIANCE = np.array([[1e-6, 0], [0, 1e-6]])


def _make_obs(
    u: float = 0.1,
    v: float = 0.2,
    covariance: np.ndarray | None = None,
) -> AoaObservation:
    """Create an AOA observation with defaults."""
    return AoaObservation(
        time=_TIME,
        u=u,
        v=v,
        covariance=covariance if covariance is not None else _COVARIANCE.copy(),
        collector=_COLLECTOR,
        collector_rotation=_ROTATION,
        sensor_id="test",
    )


# Initialization


@pytest.mark.parametrize(
    ("u", "v"),
    [
        (0.0, 0.0),  # Boresight
        (0.5, 0.5),  # Off-axis
        (-0.3, 0.4),  # Negative u
        (0.0, -0.7),  # Negative v
    ],
    ids=["boresight", "off_axis", "neg_u", "neg_v"],
)
def test_valid_direction_cosines(u: float, v: float) -> None:
    """Verify observation accepts valid direction cosines."""
    obs = _make_obs(u=u, v=v)

    assert obs.u == u
    assert obs.v == v


def test_value_property() -> None:
    """Verify value property returns direction cosines as array."""
    obs = _make_obs(u=0.1, v=0.2)

    assert obs.value.shape == (2,)
    assert obs.value[0] == 0.1
    assert obs.value[1] == 0.2


def test_direction_cosines_property() -> None:
    """Verify direction_cosines property matches value."""
    obs = _make_obs(u=0.1, v=0.2)

    assert np.array_equal(obs.direction_cosines, obs.value)


# Shape validation


def test_rejects_wrong_covariance_shape() -> None:
    """Verify observation rejects wrong covariance shape."""
    with pytest.raises(ValueError, match="covariance shape"):
        AoaObservation(
            time=_TIME,
            u=0.1,
            v=0.2,
            covariance=np.array([1e-6]),  # Wrong shape
            collector=_COLLECTOR,
            collector_rotation=_ROTATION,
            sensor_id="test",
        )


# Immutability


def test_covariance_immutable() -> None:
    """Verify covariance array is immutable."""
    obs = _make_obs()

    with pytest.raises((TypeError, ValueError)):
        obs.covariance[0, 0] = 999.0


# Computed properties


def test_azimuth_elevation_computed() -> None:
    """Verify azimuth and elevation are computed from direction cosines."""
    obs = _make_obs(u=0.0, v=0.5)  # Looking north

    # Azimuth should be near 0 (north)
    assert 0 <= obs.azimuth < 2 * math.pi
    # Elevation should be positive
    assert -math.pi / 2 <= obs.elevation <= math.pi / 2


def test_azimuth_elevation_consistency() -> None:
    """Verify azimuth/elevation are consistent with direction cosines."""
    obs = _make_obs(u=0.3, v=0.4)

    # Reconstruct direction cosines from az/el
    # This depends on the convention used
    assert obs.azimuth is not None
    assert obs.elevation is not None


# Metadata


def test_obs_type() -> None:
    """Verify observation type is AOA."""
    obs = _make_obs()

    assert obs.obs_type == "AOA"


def test_sensor_id() -> None:
    """Verify sensor ID is stored."""
    obs = AoaObservation(
        time=_TIME,
        u=0.1,
        v=0.2,
        covariance=_COVARIANCE,
        collector=_COLLECTOR,
        collector_rotation=_ROTATION,
        sensor_id="my_sensor",
    )

    assert obs.sensor_id == "my_sensor"


def test_emitter_id() -> None:
    """Verify emitter ID is stored when provided."""
    obs = AoaObservation(
        time=_TIME,
        u=0.1,
        v=0.2,
        covariance=_COVARIANCE,
        collector=_COLLECTOR,
        collector_rotation=_ROTATION,
        sensor_id="test",
        emitter_id="target1",
    )

    assert obs.emitter_id == "target1"


def test_emitter_id_optional() -> None:
    """Verify emitter ID defaults to None."""
    obs = _make_obs()

    assert obs.emitter_id is None


# Time and collector state


def test_time_property() -> None:
    """Verify time property returns observation time."""
    obs = _make_obs()

    assert obs.time == _TIME


def test_collector_rotation_property() -> None:
    """Verify collector_rotation returns rotation object."""
    custom_rot = Rotation.from_euler("z", 45, degrees=True)
    obs = AoaObservation(
        time=_TIME,
        u=0.1,
        v=0.2,
        covariance=_COVARIANCE,
        collector=_COLLECTOR,
        collector_rotation=custom_rot,
        sensor_id="test",
    )

    assert np.allclose(obs.collector_rotation.as_quat(), custom_rot.as_quat())


# String representations


def test_repr() -> None:
    """Verify string representation."""
    obs = _make_obs()

    repr_str = repr(obs)
    assert "AoaObservation" in repr_str
    assert "test" in repr_str


def test_str() -> None:
    """Verify human-readable string."""
    obs = _make_obs()

    str_repr = str(obs)
    assert "AOA" in str_repr
