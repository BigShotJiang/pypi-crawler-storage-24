"""Tests for FdoaObservation.

Tests verify FDOA observation structure, validation, and immutability.
"""

from __future__ import annotations

import numpy as np
import pytest
from gri_nsepoch import Time
from gri_pos import Pos

from gri_geosim.observations import FdoaObservation

_TIME = Time(s=0.0)
_COLLECTOR1 = Pos.XYZ(1e6, 2e6, 3e6)
_COLLECTOR2 = Pos.XYZ(1.1e6, 2.1e6, 3.1e6)
_COLLECTOR1_VEL = np.array([100.0, 200.0, 50.0])
_COLLECTOR2_VEL = np.array([150.0, 180.0, 60.0])
_FREQUENCY_HZ = 1e9


def _make_obs(
    value: float = 0.5,
    std_dev: float = 0.1,
    frequency_hz: float = _FREQUENCY_HZ,
) -> FdoaObservation:
    """Create an FDOA observation with defaults."""
    return FdoaObservation(
        time=_TIME,
        value=value,
        std_dev=std_dev,
        collector1=_COLLECTOR1,
        collector2=_COLLECTOR2,
        collector1_vel=_COLLECTOR1_VEL.copy(),
        collector2_vel=_COLLECTOR2_VEL.copy(),
        frequency_hz=frequency_hz,
        sensor_id="test",
    )


# Initialization


@pytest.mark.parametrize(
    ("value", "std_dev"),
    [
        (0.0, 0.1),  # Zero FDOA
        (1.0, 0.1),  # Positive FDOA (1 Hz)
        (-0.5, 0.1),  # Negative FDOA
        (100.0, 1.0),  # Large FDOA
    ],
    ids=["zero", "positive", "negative", "large"],
)
def test_valid_values(value: float, std_dev: float) -> None:
    """Verify observation accepts valid FDOA values."""
    obs = _make_obs(value=value, std_dev=std_dev)

    assert obs.value == value
    assert obs.std_dev == std_dev


def test_variance_property() -> None:
    """Verify variance property computes from std_dev."""
    std_dev = 0.2
    obs = _make_obs(std_dev=std_dev)

    assert np.isclose(obs.variance, std_dev**2)


# Shape validation (velocities only - positions use Pos now)


@pytest.mark.parametrize(
    "field_name",
    ["collector1_vel", "collector2_vel"],
)
def test_rejects_wrong_velocity_shape(field_name: str) -> None:
    """Verify observation rejects wrong velocity array shapes."""
    kwargs: dict = {
        "time": _TIME,
        "value": 0.5,
        "std_dev": 0.1,
        "collector1": _COLLECTOR1,
        "collector2": _COLLECTOR2,
        "collector1_vel": _COLLECTOR1_VEL.copy(),
        "collector2_vel": _COLLECTOR2_VEL.copy(),
        "frequency_hz": _FREQUENCY_HZ,
        "sensor_id": "test",
    }
    kwargs[field_name] = np.array([1.0, 2.0])  # Wrong shape

    with pytest.raises(ValueError, match=f"{field_name} shape"):
        FdoaObservation(**kwargs)


# Immutability (velocities only)


@pytest.mark.parametrize(
    "array_name",
    ["collector1_vel", "collector2_vel"],
)
def test_velocity_arrays_immutable(array_name: str) -> None:
    """Verify velocity arrays are immutable."""
    obs = _make_obs()
    arr = getattr(obs, array_name)

    with pytest.raises((TypeError, ValueError)):
        arr[0] = 999.0


# Metadata


def test_obs_type() -> None:
    """Verify observation type is FDOA."""
    obs = _make_obs()

    assert obs.obs_type == "FDOA"


def test_sensor_id() -> None:
    """Verify sensor ID is stored."""
    obs = FdoaObservation(
        time=_TIME,
        value=0.5,
        std_dev=0.1,
        collector1=_COLLECTOR1,
        collector2=_COLLECTOR2,
        collector1_vel=_COLLECTOR1_VEL,
        collector2_vel=_COLLECTOR2_VEL,
        frequency_hz=_FREQUENCY_HZ,
        sensor_id="my_sensor",
    )

    assert obs.sensor_id == "my_sensor"


def test_emitter_id() -> None:
    """Verify emitter ID is stored when provided."""
    obs = FdoaObservation(
        time=_TIME,
        value=0.5,
        std_dev=0.1,
        collector1=_COLLECTOR1,
        collector2=_COLLECTOR2,
        collector1_vel=_COLLECTOR1_VEL,
        collector2_vel=_COLLECTOR2_VEL,
        frequency_hz=_FREQUENCY_HZ,
        sensor_id="test",
        emitter_id="target1",
    )

    assert obs.emitter_id == "target1"


def test_emitter_id_optional() -> None:
    """Verify emitter ID defaults to None."""
    obs = _make_obs()

    assert obs.emitter_id is None


# Frequency


def test_frequency_property() -> None:
    """Verify frequency_hz property returns carrier frequency."""
    freq = 2.5e9
    obs = _make_obs(frequency_hz=freq)

    assert obs.frequency_hz == freq


# Time property


def test_time_property() -> None:
    """Verify time property returns observation time."""
    obs = _make_obs()

    assert obs.time == _TIME


# Collector state


def test_collector_positions() -> None:
    """Verify collector positions are stored correctly."""
    obs = _make_obs()

    assert np.allclose(obs.collector1.xyz, _COLLECTOR1.xyz)
    assert np.allclose(obs.collector2.xyz, _COLLECTOR2.xyz)


def test_collector_velocities() -> None:
    """Verify collector velocities are stored correctly."""
    obs = _make_obs()

    assert np.allclose(obs.collector1_vel, _COLLECTOR1_VEL)
    assert np.allclose(obs.collector2_vel, _COLLECTOR2_VEL)


# Validity check


def test_is_valid_with_finite_values() -> None:
    """Verify is_valid returns True for finite values."""
    obs = _make_obs()

    assert obs.is_valid()


def test_is_valid_with_nan_value() -> None:
    """Verify is_valid returns False for NaN value."""
    obs = FdoaObservation(
        time=_TIME,
        value=float("nan"),
        std_dev=0.1,
        collector1=_COLLECTOR1,
        collector2=_COLLECTOR2,
        collector1_vel=_COLLECTOR1_VEL,
        collector2_vel=_COLLECTOR2_VEL,
        frequency_hz=_FREQUENCY_HZ,
        sensor_id="test",
    )

    assert not obs.is_valid()


def test_is_valid_with_inf_frequency() -> None:
    """Verify is_valid returns False for infinite frequency."""
    obs = FdoaObservation(
        time=_TIME,
        value=0.5,
        std_dev=0.1,
        collector1=_COLLECTOR1,
        collector2=_COLLECTOR2,
        collector1_vel=_COLLECTOR1_VEL,
        collector2_vel=_COLLECTOR2_VEL,
        frequency_hz=float("inf"),
        sensor_id="test",
    )

    assert not obs.is_valid()


# String representations


def test_repr() -> None:
    """Verify string representation."""
    obs = _make_obs()

    repr_str = repr(obs)
    assert "FdoaObservation" in repr_str
    assert "test" in repr_str


def test_str_auto_scaling() -> None:
    """Verify human-readable string auto-scales units."""
    # Small value - Hz
    obs_hz = _make_obs(value=0.5)
    assert "Hz" in str(obs_hz)

    # Large value - kHz
    obs_khz = _make_obs(value=1500.0)
    assert "kHz" in str(obs_khz)


# Equality and hashing


def test_equality() -> None:
    """Verify equality comparison."""
    obs1 = _make_obs()
    obs2 = _make_obs()

    assert obs1 == obs2


def test_inequality_different_value() -> None:
    """Verify inequality for different values."""
    obs1 = _make_obs(value=0.5)
    obs2 = _make_obs(value=1.0)

    assert obs1 != obs2


def test_hash() -> None:
    """Verify observations are hashable."""
    obs1 = _make_obs()
    obs2 = _make_obs()

    assert hash(obs1) == hash(obs2)

    # Can be used in sets
    obs_set = {obs1, obs2}
    assert len(obs_set) == 1
