"""Tests for AOA geolocation solver."""

from __future__ import annotations

import numpy as np
import pytest
from gri_utils.observables import get_aoa_quat
from scipy.spatial.transform import Rotation

from gri_geosim.geolocation import aoa_locator

# Test geometry: LEO collectors with true 3D diversity
EARTH_RADIUS = 6378137.0
LEO_ALT_LOW = 400_000.0  # 400 km altitude
LEO_ALT_MID = 800_000.0  # 800 km altitude
LEO_ALT_HIGH = 1200_000.0  # 1200 km altitude


def _create_test_geometry(
    n_collectors: int = 3,
) -> tuple[np.ndarray, Rotation, np.ndarray]:
    """Create a test geometry with LEO collectors and Earth-surface target.

    LEO collectors at different altitudes provide true 3D diversity for
    robust AOA geolocation.

    Args:
        n_collectors: Number of collectors to create (3, 4, or 5 supported).

    Returns:
        Tuple of (collector_xyz, rotations, target_xyz).
    """
    # LEO collectors at different altitudes and angular positions
    if n_collectors == 4:
        # 4 collectors in tetrahedron-like arrangement
        collector_xyz = np.array(
            [
                [(EARTH_RADIUS + LEO_ALT_LOW), 0.0, 0.0],
                [
                    (EARTH_RADIUS + LEO_ALT_LOW) * np.cos(np.radians(60)),
                    (EARTH_RADIUS + LEO_ALT_LOW) * np.sin(np.radians(60)),
                    0.0,
                ],
                [
                    (EARTH_RADIUS + LEO_ALT_MID) * np.cos(np.radians(45)),
                    0.0,
                    (EARTH_RADIUS + LEO_ALT_MID) * np.sin(np.radians(45)),
                ],
                [
                    (EARTH_RADIUS + LEO_ALT_HIGH) * np.cos(np.radians(30)),
                    -(EARTH_RADIUS + LEO_ALT_HIGH) * np.sin(np.radians(30)),
                    0.0,
                ],
            ],
        )
    elif n_collectors >= 5:
        collector_xyz = np.array(
            [
                # Low altitude ring (400 km)
                [(EARTH_RADIUS + LEO_ALT_LOW), 0.0, 0.0],
                [
                    (EARTH_RADIUS + LEO_ALT_LOW) * np.cos(np.radians(60)),
                    (EARTH_RADIUS + LEO_ALT_LOW) * np.sin(np.radians(60)),
                    0.0,
                ],
                [
                    (EARTH_RADIUS + LEO_ALT_LOW) * np.cos(np.radians(60)),
                    0.0,
                    (EARTH_RADIUS + LEO_ALT_LOW) * np.sin(np.radians(60)),
                ],
                # Mid altitude (800 km)
                [
                    (EARTH_RADIUS + LEO_ALT_MID) * np.cos(np.radians(45)),
                    (EARTH_RADIUS + LEO_ALT_MID) * np.sin(np.radians(45)),
                    0.0,
                ],
                # High altitude (1200 km)
                [
                    (EARTH_RADIUS + LEO_ALT_HIGH) * np.cos(np.radians(30)),
                    -(EARTH_RADIUS + LEO_ALT_HIGH) * np.sin(np.radians(30)),
                    0.0,
                ],
            ],
        )
    else:
        # 3 collectors in diverse arrangement
        collector_xyz = np.array(
            [
                [(EARTH_RADIUS + LEO_ALT_LOW), 0.0, 0.0],
                [
                    (EARTH_RADIUS + LEO_ALT_MID) * np.cos(np.radians(45)),
                    (EARTH_RADIUS + LEO_ALT_MID) * np.sin(np.radians(45)),
                    0.0,
                ],
                [
                    (EARTH_RADIUS + LEO_ALT_HIGH) * np.cos(np.radians(30)),
                    0.0,
                    (EARTH_RADIUS + LEO_ALT_HIGH) * np.sin(np.radians(30)),
                ],
            ],
        )

    # Identity rotations (local frame = ECEF)
    rotations = Rotation.identity(n_collectors)

    # Target on Earth's surface, offset from nadir of collector constellation
    target_xyz = np.array([EARTH_RADIUS * 0.95, EARTH_RADIUS * 0.2, EARTH_RADIUS * 0.1])
    target_xyz = target_xyz / np.linalg.norm(target_xyz) * EARTH_RADIUS

    return collector_xyz, rotations, target_xyz


def test_perfect_measurements_recovery() -> None:
    """Verify exact target recovery with perfect (noiseless) measurements."""
    collector_xyz, rotations, target_true = _create_test_geometry(n_collectors=3)

    # Compute true AOA measurements
    aoa_measurements = get_aoa_quat(collector_xyz, target_true, rotations)

    # Small covariance (measurements are perfect)
    aoa_cov = np.eye(2) * 1e-6
    aoa_covariances = np.tile(aoa_cov, (3, 1, 1))

    result = aoa_locator(
        collector_xyz,
        rotations,
        aoa_measurements,
        aoa_covariances,
    )

    # Should recover target within sub-meter accuracy
    error_m = np.linalg.norm(result.position - target_true)
    assert error_m < 1.0, f"Position error {error_m:.6f}m exceeds 1m"


def test_five_collectors_overdetermined() -> None:
    """Verify sub-meter accuracy with overdetermined system (5 collectors)."""
    collector_xyz, rotations, target_true = _create_test_geometry(n_collectors=5)

    aoa_measurements = get_aoa_quat(collector_xyz, target_true, rotations)
    aoa_cov = np.eye(2) * 1e-6
    aoa_covariances = np.tile(aoa_cov, (5, 1, 1))

    result = aoa_locator(
        collector_xyz,
        rotations,
        aoa_measurements,
        aoa_covariances,
    )

    error_m = np.linalg.norm(result.position - target_true)
    assert error_m < 1.0, f"Position error {error_m:.6f}m exceeds 1m"

    # More collectors should give smaller covariance
    assert np.trace(result.covariance) > 0  # Positive definite check


def test_covariance_positive_definite() -> None:
    """Verify output covariance is positive definite."""
    collector_xyz, rotations, target_true = _create_test_geometry(n_collectors=4)

    aoa_measurements = get_aoa_quat(collector_xyz, target_true, rotations)
    aoa_cov = np.eye(2) * 0.001**2  # 1 mrad noise
    aoa_covariances = np.tile(aoa_cov, (4, 1, 1))

    result = aoa_locator(
        collector_xyz,
        rotations,
        aoa_measurements,
        aoa_covariances,
    )

    eigvals = np.linalg.eigvalsh(result.covariance)
    assert np.all(eigvals > 0), f"Covariance not positive definite: eigvals={eigvals}"


def test_initial_guess_from_arrays() -> None:
    """Verify custom initial guess is accepted."""
    collector_xyz, rotations, target_true = _create_test_geometry(n_collectors=3)

    aoa_measurements = get_aoa_quat(collector_xyz, target_true, rotations)
    aoa_cov = np.eye(2) * 1e-6
    aoa_covariances = np.tile(aoa_cov, (3, 1, 1))

    # Provide initial guess close to truth
    xyz0 = target_true + np.array([100.0, 100.0, 100.0])

    result = aoa_locator(
        collector_xyz,
        rotations,
        aoa_measurements,
        aoa_covariances,
        xyz0=xyz0,
    )

    error_m = np.linalg.norm(result.position - target_true)
    assert error_m < 1.0


def test_quaternion_array_input() -> None:
    """Verify quaternion arrays work (not just Rotation objects)."""
    collector_xyz, rotations, target_true = _create_test_geometry(n_collectors=3)

    # Convert to quaternion array
    quats = rotations.as_quat()

    aoa_measurements = get_aoa_quat(collector_xyz, target_true, quats)
    aoa_cov = np.eye(2) * 1e-6
    aoa_covariances = np.tile(aoa_cov, (3, 1, 1))

    result = aoa_locator(
        collector_xyz,
        quats,
        aoa_measurements,
        aoa_covariances,
    )

    error_m = np.linalg.norm(result.position - target_true)
    assert error_m < 1.0


def test_single_collector_raises() -> None:
    """Verify error with fewer than 2 collectors."""
    collector_xyz = np.array([[EARTH_RADIUS, 0.0, 0.0]])
    rotations = Rotation.identity(1)
    aoa_measurements = np.array([[0.1, 0.1]])
    aoa_covariances = np.array([np.eye(2) * 0.001])

    with pytest.raises(ValueError, match="At least 2 collectors"):
        aoa_locator(collector_xyz, rotations, aoa_measurements, aoa_covariances)


def test_mismatched_shapes_raise() -> None:
    """Verify error on mismatched input shapes."""
    collector_xyz = np.array(
        [
            [EARTH_RADIUS, 0.0, 0.0],
            [EARTH_RADIUS, 1000.0, 0.0],
        ],
    )
    rotations = Rotation.identity(2)

    # Wrong number of measurements
    aoa_measurements = np.array([[0.1, 0.1]])  # Only 1, need 2
    aoa_covariances = np.array([np.eye(2), np.eye(2)])

    with pytest.raises(ValueError, match="aoa_measurements shape"):
        aoa_locator(collector_xyz, rotations, aoa_measurements, aoa_covariances)


def test_rotated_collectors() -> None:
    """Verify correct handling of non-identity rotations."""
    n_collectors = 3
    collector_xyz, _, target_true = _create_test_geometry(n_collectors=n_collectors)

    # Create random rotations for each collector
    rng = np.random.default_rng(42)
    random_quats = rng.standard_normal((n_collectors, 4))
    random_quats /= np.linalg.norm(random_quats, axis=1, keepdims=True)
    rotations = Rotation.from_quat(random_quats)

    # Compute true AOA in each collector's rotated frame
    aoa_measurements = get_aoa_quat(collector_xyz, target_true, rotations)
    aoa_cov = np.eye(2) * 1e-6
    aoa_covariances = np.tile(aoa_cov, (n_collectors, 1, 1))

    result = aoa_locator(
        collector_xyz,
        rotations,
        aoa_measurements,
        aoa_covariances,
    )

    error_m = np.linalg.norm(result.position - target_true)
    assert error_m < 1.0, f"Position error {error_m:.6f}m exceeds 1m"


def test_varying_measurement_covariances() -> None:
    """Verify handling of different covariances per collector."""
    collector_xyz, rotations, target_true = _create_test_geometry(n_collectors=3)

    aoa_measurements = get_aoa_quat(collector_xyz, target_true, rotations)

    # Different noise levels per collector
    aoa_covariances = np.array(
        [
            np.eye(2) * 0.001**2,  # 1 mrad
            np.eye(2) * 0.005**2,  # 5 mrad
            np.eye(2) * 0.002**2,  # 2 mrad
        ],
    )

    result = aoa_locator(
        collector_xyz,
        rotations,
        aoa_measurements,
        aoa_covariances,
    )

    error_m = np.linalg.norm(result.position - target_true)
    assert error_m < 1.0

    # Covariance should still be valid
    eigvals = np.linalg.eigvalsh(result.covariance)
    assert np.all(eigvals > 0)
