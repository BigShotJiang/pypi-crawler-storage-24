"""Tests for TDOA geolocation solver."""

from __future__ import annotations

import numpy as np
import pytest
from gri_utils.observables import get_tdoa

from gri_geosim.geolocation import tdoa_locator

# Test geometry: HEO collectors with 3D diversity at varying latitudes
# HEO is realistic for TDOA - timing measurements work well from high altitude
EARTH_RADIUS = 6378137.0
GEO_ALT = 35_786_000.0  # GEO altitude ~35,786 km


def _create_test_geometry(
    n_collectors: int = 4,
) -> tuple[np.ndarray, np.ndarray]:
    """Create a test geometry with HEO collectors and Earth-surface target.

    HEO collectors at GEO-like altitude with varying latitudes provide
    3D diversity for robust TDOA geolocation. This is realistic for
    timing-based measurements which work well from high altitude.

    Args:
        n_collectors: Number of collectors to create (4 or 5 supported).

    Returns:
        Tuple of (collector_xyz, target_xyz).
    """
    r_geo = EARTH_RADIUS + GEO_ALT

    # HEO collectors at GEO altitude with varying latitudes for 3D diversity
    if n_collectors >= 5:
        collector_xyz = np.array(
            [
                # Equatorial positions at different longitudes
                [r_geo, 0.0, 0.0],
                [
                    r_geo * np.cos(np.radians(72)),
                    r_geo * np.sin(np.radians(72)),
                    0.0,
                ],
                [
                    r_geo * np.cos(np.radians(144)),
                    r_geo * np.sin(np.radians(144)),
                    0.0,
                ],
                # Inclined positions for latitude diversity
                [
                    r_geo * np.cos(np.radians(45)) * np.cos(np.radians(30)),
                    r_geo * np.cos(np.radians(45)) * np.sin(np.radians(30)),
                    r_geo * np.sin(np.radians(45)),
                ],
                [
                    r_geo * np.cos(np.radians(-30)) * np.cos(np.radians(-60)),
                    r_geo * np.cos(np.radians(-30)) * np.sin(np.radians(-60)),
                    r_geo * np.sin(np.radians(-30)),
                ],
            ],
        )
    else:
        # 4 collectors in tetrahedron-like arrangement at GEO altitude
        collector_xyz = np.array(
            [
                # Equatorial
                [r_geo, 0.0, 0.0],
                [
                    r_geo * np.cos(np.radians(120)),
                    r_geo * np.sin(np.radians(120)),
                    0.0,
                ],
                # Northern latitude
                [
                    r_geo * np.cos(np.radians(45)) * np.cos(np.radians(-60)),
                    r_geo * np.cos(np.radians(45)) * np.sin(np.radians(-60)),
                    r_geo * np.sin(np.radians(45)),
                ],
                # Southern latitude
                [
                    r_geo * np.cos(np.radians(-45)) * np.cos(np.radians(60)),
                    r_geo * np.cos(np.radians(-45)) * np.sin(np.radians(60)),
                    r_geo * np.sin(np.radians(-45)),
                ],
            ],
        )

    # Target on Earth's surface, offset from nadir of collector constellation
    target_xyz = np.array([EARTH_RADIUS * 0.95, EARTH_RADIUS * 0.2, EARTH_RADIUS * 0.1])
    target_xyz = target_xyz / np.linalg.norm(target_xyz) * EARTH_RADIUS

    return collector_xyz, target_xyz


def _create_all_pairs(
    collector_xyz: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, list[tuple[int, int]]]:
    """Create all unique collector pairs.

    For N collectors, creates N*(N-1)/2 pairs.

    Args:
        collector_xyz: Collector positions, shape (N, 3).

    Returns:
        Tuple of (collector1_xyz, collector2_xyz, pair_indices).
    """
    n = len(collector_xyz)
    pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]

    collector1 = np.array([collector_xyz[i] for i, _ in pairs])
    collector2 = np.array([collector_xyz[j] for _, j in pairs])

    return collector1, collector2, pairs


def test_perfect_measurements_recovery() -> None:
    """Verify exact target recovery with perfect (noiseless) measurements."""
    collector_xyz, target_true = _create_test_geometry(n_collectors=4)
    collector1, collector2, _ = _create_all_pairs(collector_xyz)

    # Compute true TDOA measurements
    n_pairs = len(collector1)
    tdoa_measurements = np.array(
        [get_tdoa(target_true, collector1[i], collector2[i]) for i in range(n_pairs)],
    )

    # Small variance (measurements are perfect)
    tdoa_variances = np.full(n_pairs, (1e-12) ** 2)

    result = tdoa_locator(
        collector1,
        collector2,
        tdoa_measurements,
        tdoa_variances,
    )

    # Should recover target within sub-meter accuracy
    error_m = np.linalg.norm(result.position - target_true)
    assert error_m < 1.0, f"Position error {error_m:.6f}m exceeds 1m"


def test_three_measurements_minimum() -> None:
    """Verify solver works with minimum 3 TDOA measurements, sub-meter accuracy."""
    collector_xyz, target_true = _create_test_geometry(n_collectors=4)

    # Use only 3 pairs (minimum for 3D)
    pairs = [(0, 1), (0, 2), (0, 3)]
    collector1 = np.array([collector_xyz[i] for i, _ in pairs])
    collector2 = np.array([collector_xyz[j] for _, j in pairs])

    tdoa_measurements = np.array(
        [get_tdoa(target_true, collector1[i], collector2[i]) for i in range(3)],
    )
    tdoa_variances = np.full(3, (1e-12) ** 2)

    result = tdoa_locator(
        collector1,
        collector2,
        tdoa_measurements,
        tdoa_variances,
    )

    assert result.position.shape == (3,)
    assert result.covariance.shape == (3, 3)

    error_m = np.linalg.norm(result.position - target_true)
    assert error_m < 1.0, f"Position error {error_m:.6f}m exceeds 1m"


def test_overdetermined_system() -> None:
    """Verify sub-meter accuracy with overdetermined system (6 pairs)."""
    collector_xyz, target_true = _create_test_geometry(n_collectors=4)
    collector1, collector2, _ = _create_all_pairs(collector_xyz)

    # 4 collectors = 6 pairs (overdetermined)
    assert len(collector1) == 6

    tdoa_measurements = np.array(
        [
            get_tdoa(target_true, collector1[i], collector2[i])
            for i in range(len(collector1))
        ],
    )
    tdoa_variances = np.full(len(collector1), (1e-12) ** 2)

    result = tdoa_locator(
        collector1,
        collector2,
        tdoa_measurements,
        tdoa_variances,
    )

    error_m = np.linalg.norm(result.position - target_true)
    assert error_m < 1.0, f"Position error {error_m:.6f}m exceeds 1m"

    # Covariance should be positive definite
    eigvals = np.linalg.eigvalsh(result.covariance)
    assert np.all(eigvals > 0)


def test_covariance_positive_definite() -> None:
    """Verify output covariance is positive definite."""
    collector_xyz, target_true = _create_test_geometry(n_collectors=4)
    collector1, collector2, _ = _create_all_pairs(collector_xyz)

    n_pairs = len(collector1)
    tdoa_measurements = np.array(
        [get_tdoa(target_true, collector1[i], collector2[i]) for i in range(n_pairs)],
    )
    # 10 ns timing uncertainty
    tdoa_variances = np.full(n_pairs, (10e-9) ** 2)

    result = tdoa_locator(
        collector1,
        collector2,
        tdoa_measurements,
        tdoa_variances,
    )

    eigvals = np.linalg.eigvalsh(result.covariance)
    assert np.all(eigvals > 0), f"Covariance not positive definite: eigvals={eigvals}"


def test_initial_guess_provided() -> None:
    """Verify custom initial guess is accepted and achieves sub-meter accuracy."""
    collector_xyz, target_true = _create_test_geometry(n_collectors=4)
    collector1, collector2, _ = _create_all_pairs(collector_xyz)

    n_pairs = len(collector1)
    tdoa_measurements = np.array(
        [get_tdoa(target_true, collector1[i], collector2[i]) for i in range(n_pairs)],
    )
    tdoa_variances = np.full(n_pairs, (1e-12) ** 2)

    # Provide initial guess close to truth
    xyz0 = target_true + np.array([100.0, 100.0, 100.0])

    result = tdoa_locator(
        collector1,
        collector2,
        tdoa_measurements,
        tdoa_variances,
        xyz0=xyz0,
    )

    error_m = np.linalg.norm(result.position - target_true)
    assert error_m < 1.0, f"Position error {error_m:.6f}m exceeds 1m"


def test_two_measurements_raises() -> None:
    """Verify error with fewer than 3 TDOA measurements."""
    collector1 = np.array(
        [
            [EARTH_RADIUS, 0.0, 0.0],
            [EARTH_RADIUS, 1000.0, 0.0],
        ],
    )
    collector2 = np.array(
        [
            [EARTH_RADIUS, 1000.0, 0.0],
            [EARTH_RADIUS, 0.0, 1000.0],
        ],
    )
    tdoa_measurements = np.array([1e-6, 2e-6])
    tdoa_variances = np.array([1e-18, 1e-18])

    with pytest.raises(ValueError, match="3 TDOA measurements required"):
        tdoa_locator(collector1, collector2, tdoa_measurements, tdoa_variances)


def test_mismatched_shapes_raise() -> None:
    """Verify error on mismatched input shapes."""
    collector1 = np.array(
        [
            [EARTH_RADIUS, 0.0, 0.0],
            [EARTH_RADIUS, 1000.0, 0.0],
            [EARTH_RADIUS, 0.0, 1000.0],
        ],
    )
    collector2 = np.array(
        [
            [EARTH_RADIUS, 1000.0, 0.0],
            [EARTH_RADIUS, 0.0, 1000.0],
            [EARTH_RADIUS, 1000.0, 1000.0],
        ],
    )

    # 3 measurements but mismatched collector2 shape
    tdoa_measurements = np.array([1e-6, 2e-6, 3e-6])
    tdoa_variances = np.array([1e-18, 1e-18, 1e-18])

    with pytest.raises(ValueError, match="collector2_xyz shape"):
        tdoa_locator(
            collector1,
            collector2[:2],  # Only 2 rows, need 3
            tdoa_measurements,
            tdoa_variances,
        )


def test_varying_measurement_variances() -> None:
    """Verify handling of different variances per measurement, sub-meter accuracy."""
    collector_xyz, target_true = _create_test_geometry(n_collectors=4)
    collector1, collector2, _ = _create_all_pairs(collector_xyz)

    n_pairs = len(collector1)
    tdoa_measurements = np.array(
        [get_tdoa(target_true, collector1[i], collector2[i]) for i in range(n_pairs)],
    )

    # Different noise levels per measurement (but no actual noise added)
    tdoa_variances = np.array(
        [
            (5e-9) ** 2,  # 5 ns
            (10e-9) ** 2,  # 10 ns
            (20e-9) ** 2,  # 20 ns
            (5e-9) ** 2,
            (10e-9) ** 2,
            (15e-9) ** 2,
        ],
    )

    result = tdoa_locator(
        collector1,
        collector2,
        tdoa_measurements,
        tdoa_variances,
    )

    error_m = np.linalg.norm(result.position - target_true)
    assert error_m < 1.0, f"Position error {error_m:.6f}m exceeds 1m"

    # Covariance should still be valid
    eigvals = np.linalg.eigvalsh(result.covariance)
    assert np.all(eigvals > 0)


def test_sparse_pairs() -> None:
    """Verify solver works with non-consecutive collector pairs, sub-meter accuracy."""
    # 5 collectors but only 4 pairs (not all 10 possible pairs)
    collector_xyz, target_true = _create_test_geometry(n_collectors=5)

    # Sparse pairs: 01, 12, 23, 34 (chain, not all combinations)
    pairs = [(0, 1), (1, 2), (2, 3), (3, 4)]
    collector1 = np.array([collector_xyz[i] for i, _ in pairs])
    collector2 = np.array([collector_xyz[j] for _, j in pairs])

    tdoa_measurements = np.array(
        [get_tdoa(target_true, collector1[i], collector2[i]) for i in range(4)],
    )
    tdoa_variances = np.full(4, (1e-12) ** 2)

    result = tdoa_locator(
        collector1,
        collector2,
        tdoa_measurements,
        tdoa_variances,
    )

    error_m = np.linalg.norm(result.position - target_true)
    assert error_m < 1.0, f"Position error {error_m:.6f}m exceeds 1m"


def test_noisy_measurements() -> None:
    """Verify reasonable solution with realistic noisy measurements.

    With 10 ns timing noise (~3m range error), expect position error in tens of meters.
    """
    rng = np.random.default_rng(42)

    collector_xyz, target_true = _create_test_geometry(n_collectors=4)
    collector1, collector2, _ = _create_all_pairs(collector_xyz)

    n_pairs = len(collector1)

    # True TDOAs
    tdoa_true = np.array(
        [get_tdoa(target_true, collector1[i], collector2[i]) for i in range(n_pairs)],
    )

    # Add 10 ns noise (~3m range equivalent)
    noise_std = 10e-9
    tdoa_measurements = tdoa_true + rng.normal(0, noise_std, n_pairs)
    tdoa_variances = np.full(n_pairs, noise_std**2)

    result = tdoa_locator(
        collector1,
        collector2,
        tdoa_measurements,
        tdoa_variances,
    )

    # With 10 ns noise, expect position error in tens of meters
    error_m = np.linalg.norm(result.position - target_true)
    assert error_m < 100.0, f"Position error {error_m:.1f}m exceeds 100m"

    # Covariance should reflect uncertainty (positive semi-definite)
    eigvals = np.linalg.eigvalsh(result.covariance)
    assert np.all(eigvals > 0)
