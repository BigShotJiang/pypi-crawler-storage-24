"""Tests for TDOA+AOA+FDOA geolocation solver.

Tests tdoa_aoa_fdoa_locator for position estimation from TDOA/AOA/FDOA
combinations with a known velocity constraint.
"""

from __future__ import annotations

import numpy as np
import pytest
from gri_utils.observables import get_aoa_quat, get_fdoa, get_tdoa
from scipy.spatial.transform import Rotation

from gri_geosim.geolocation import tdoa_aoa_fdoa_locator

# Test geometry constants
EARTH_RADIUS = 6378137.0
LEO_ALT = 600_000.0
LEO_VELOCITY = 7500.0


def _leo_velocity(position: np.ndarray, inclination_deg: float) -> np.ndarray:
    """Compute LEO orbital velocity perpendicular to position vector."""
    r_hat = position / np.linalg.norm(position)
    incl = np.radians(inclination_deg)
    if abs(r_hat[2]) < 0.9:
        perp = np.cross(r_hat, np.array([0.0, 0.0, 1.0]))
    else:
        perp = np.cross(r_hat, np.array([1.0, 0.0, 0.0]))
    perp = perp / np.linalg.norm(perp)
    v_hat = perp * np.cos(incl) + np.cross(r_hat, perp) * np.sin(incl)
    return v_hat * LEO_VELOCITY


def _create_geometry(
    n_collectors: int = 6,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Create LEO collector geometry with ground target.

    Uses 3D distributed positions for good observability.

    Returns:
        Tuple of (collector_xyz, collector_vel, target_xyz, target_vel).
    """
    r = EARTH_RADIUS + LEO_ALT
    inclinations = [0.0, 30.0, 45.0, 60.0, 75.0, 90.0][:n_collectors]

    # 3D distributed collectors (not coplanar)
    positions = [
        [r, 0.0, 0.0],
        [r * 0.866, r * 0.5, 0.0],
        [r * 0.866, 0.0, r * 0.5],
        [r * 0.707, r * 0.5, r * 0.5],
        [r * 0.707, -r * 0.5, r * 0.5],
        [r * 0.5, r * 0.707, r * 0.5],
    ][:n_collectors]

    collector_xyz = np.array(positions)
    collector_vel = np.array(
        [
            _leo_velocity(pos, incl)
            for pos, incl in zip(collector_xyz, inclinations, strict=True)
        ],
    )

    # Stationary ground target
    target_xyz = np.array([EARTH_RADIUS, 0.0, 0.0])
    target_vel = np.zeros(3)

    return collector_xyz, collector_vel, target_xyz, target_vel


def _make_pairs(
    collector_xyz: np.ndarray,
    collector_vel: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Create all unique collector pairs."""
    n = len(collector_xyz)
    pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]
    c1 = np.array([collector_xyz[i] for i, _ in pairs])
    c2 = np.array([collector_xyz[j] for _, j in pairs])
    v1 = np.array([collector_vel[i] for i, _ in pairs])
    v2 = np.array([collector_vel[j] for _, j in pairs])
    return c1, c2, v1, v2


def _compute_fdoas(
    target_xyz: np.ndarray,
    target_vel: np.ndarray,
    c1: np.ndarray,
    c2: np.ndarray,
    v1: np.ndarray,
    v2: np.ndarray,
    freq_hz: float,
) -> np.ndarray:
    """Compute FDOA measurements for all pairs."""
    return np.array(
        [
            get_fdoa(
                target_xyz,
                target_vel,
                c1[i],
                c2[i],
                freq_hz,
                collector1_vel=v1[i],
                collector2_vel=v2[i],
            )
            for i in range(len(c1))
        ],
    )


def _compute_tdoas(
    target_xyz: np.ndarray,
    c1: np.ndarray,
    c2: np.ndarray,
) -> np.ndarray:
    """Compute TDOA measurements for all pairs."""
    return np.array([get_tdoa(target_xyz, c1[i], c2[i]) for i in range(len(c1))])


# =============================================================================
# Fixed Velocity Mode (position estimation) - FDOA only
# =============================================================================


def test_fixed_velocity_stationary_target() -> None:
    """Position estimation with known zero velocity achieves sub-meter accuracy."""
    collector_xyz, collector_vel, target_true, vel_true = _create_geometry()
    c1, c2, v1, v2 = _make_pairs(collector_xyz, collector_vel)
    freq_hz = 1e9

    fdoas = _compute_fdoas(target_true, vel_true, c1, c2, v1, v2, freq_hz)
    variances = np.full(len(fdoas), 0.1**2)

    result = tdoa_aoa_fdoa_locator(
        fdoa_collector1_xyz=c1,
        fdoa_collector2_xyz=c2,
        fdoa_measurements=fdoas,
        fdoa_variances=variances,
        freq_hz=freq_hz,
        fdoa_collector1_vel=v1,
        fdoa_collector2_vel=v2,
        fix_velocity=np.zeros(3),
    )

    pos_error = np.linalg.norm(result.position - target_true)
    assert pos_error < 1.0, f"Position error {pos_error:.6f}m exceeds 1m"
    assert np.allclose(result.velocity, vel_true)
    assert result.covariance.shape == (3, 3)


def test_fixed_velocity_moving_target() -> None:
    """Position estimation with known non-zero velocity achieves sub-meter accuracy."""
    collector_xyz, collector_vel, target_true, _ = _create_geometry()
    vel_true = np.array([100.0, 50.0, 0.0])  # Aircraft velocity
    c1, c2, v1, v2 = _make_pairs(collector_xyz, collector_vel)
    freq_hz = 1e9

    fdoas = _compute_fdoas(target_true, vel_true, c1, c2, v1, v2, freq_hz)
    variances = np.full(len(fdoas), 0.1**2)

    result = tdoa_aoa_fdoa_locator(
        fdoa_collector1_xyz=c1,
        fdoa_collector2_xyz=c2,
        fdoa_measurements=fdoas,
        fdoa_variances=variances,
        freq_hz=freq_hz,
        fdoa_collector1_vel=v1,
        fdoa_collector2_vel=v2,
        fix_velocity=vel_true,
    )

    pos_error = np.linalg.norm(result.position - target_true)
    assert pos_error < 1.0, f"Position error {pos_error:.6f}m exceeds 1m"
    assert np.allclose(result.velocity, vel_true)
    assert result.covariance.shape == (3, 3)


def test_fixed_velocity_minimum_measurements() -> None:
    """Position-only mode works with 3 measurements, sub-meter accuracy."""
    collector_xyz, collector_vel, target_true, vel_true = _create_geometry(4)
    c1, c2, v1, v2 = _make_pairs(collector_xyz, collector_vel)
    c1, c2, v1, v2 = c1[:3], c2[:3], v1[:3], v2[:3]
    freq_hz = 1e9

    fdoas = _compute_fdoas(target_true, vel_true, c1, c2, v1, v2, freq_hz)
    variances = np.full(3, 0.1**2)

    result = tdoa_aoa_fdoa_locator(
        fdoa_collector1_xyz=c1,
        fdoa_collector2_xyz=c2,
        fdoa_measurements=fdoas,
        fdoa_variances=variances,
        freq_hz=freq_hz,
        fdoa_collector1_vel=v1,
        fdoa_collector2_vel=v2,
        fix_velocity=vel_true,
    )

    pos_error = np.linalg.norm(result.position - target_true)
    assert pos_error < 1.0, f"Position error {pos_error:.6f}m exceeds 1m"
    assert np.allclose(result.velocity, vel_true)
    assert result.covariance.shape == (3, 3)


def test_fixed_velocity_with_initial_guess() -> None:
    """Initial position guess is accepted in fixed velocity mode."""
    collector_xyz, collector_vel, target_true, vel_true = _create_geometry()
    c1, c2, v1, v2 = _make_pairs(collector_xyz, collector_vel)
    freq_hz = 1e9

    fdoas = _compute_fdoas(target_true, vel_true, c1, c2, v1, v2, freq_hz)
    variances = np.full(len(fdoas), 0.1**2)

    # Provide a position initial guess
    result = tdoa_aoa_fdoa_locator(
        fdoa_collector1_xyz=c1,
        fdoa_collector2_xyz=c2,
        fdoa_measurements=fdoas,
        fdoa_variances=variances,
        freq_hz=freq_hz,
        fdoa_collector1_vel=v1,
        fdoa_collector2_vel=v2,
        fix_velocity=vel_true,
        xyz0=target_true + np.array([1000.0, 500.0, 0.0]),
    )

    pos_error = np.linalg.norm(result.position - target_true)
    assert pos_error < 1.0, f"Position error {pos_error:.6f}m exceeds 1m"
    assert result.covariance.shape == (3, 3)


# =============================================================================
# Combined TDOA + FDOA (fix_velocity mode)
# =============================================================================


def test_tdoa_fdoa_combined() -> None:
    """Combined TDOA+FDOA improves position accuracy for stationary target."""
    collector_xyz, collector_vel, target_true, vel_true = _create_geometry()
    c1, c2, v1, v2 = _make_pairs(collector_xyz, collector_vel)
    freq_hz = 1e9

    fdoas = _compute_fdoas(target_true, vel_true, c1, c2, v1, v2, freq_hz)
    tdoas = _compute_tdoas(target_true, c1, c2)

    fdoa_variances = np.full(len(fdoas), 0.1**2)
    tdoa_variances = np.full(len(tdoas), (10e-9) ** 2)

    result = tdoa_aoa_fdoa_locator(
        fdoa_collector1_xyz=c1,
        fdoa_collector2_xyz=c2,
        fdoa_measurements=fdoas,
        fdoa_variances=fdoa_variances,
        freq_hz=freq_hz,
        fdoa_collector1_vel=v1,
        fdoa_collector2_vel=v2,
        tdoa_collector1_xyz=c1,
        tdoa_collector2_xyz=c2,
        tdoa_measurements=tdoas,
        tdoa_variances=tdoa_variances,
        fix_velocity=np.zeros(3),
    )

    pos_error = np.linalg.norm(result.position - target_true)
    assert pos_error < 1.0, f"Position error {pos_error:.6f}m exceeds 1m"
    assert np.allclose(result.velocity, vel_true)
    assert result.covariance.shape == (3, 3)


def test_tdoa_only_delegates() -> None:
    """TDOA-only input delegates to tdoa_locator."""
    collector_xyz, collector_vel, target_true, vel_true = _create_geometry()
    c1, c2, _, _ = _make_pairs(collector_xyz, collector_vel)

    tdoas = _compute_tdoas(target_true, c1, c2)
    tdoa_variances = np.full(len(tdoas), (10e-9) ** 2)

    result = tdoa_aoa_fdoa_locator(
        tdoa_collector1_xyz=c1,
        tdoa_collector2_xyz=c2,
        tdoa_measurements=tdoas,
        tdoa_variances=tdoa_variances,
        fix_velocity=np.zeros(3),
    )

    pos_error = np.linalg.norm(result.position - target_true)
    assert pos_error < 1.0, f"Position error {pos_error:.6f}m exceeds 1m"
    assert np.allclose(result.velocity, vel_true)
    assert result.covariance.shape == (3, 3)


# =============================================================================
# Combined AOA + FDOA (fix_velocity mode)
# =============================================================================


def test_aoa_fdoa_combined() -> None:
    """Combined AOA+FDOA estimates position for stationary target."""
    collector_xyz, collector_vel, target_true, vel_true = _create_geometry()
    c1, c2, v1, v2 = _make_pairs(collector_xyz, collector_vel)
    freq_hz = 1e9

    fdoas = _compute_fdoas(target_true, vel_true, c1, c2, v1, v2, freq_hz)
    fdoa_variances = np.full(len(fdoas), 0.1**2)

    # AOA from first 3 collectors
    aoa_xyz = collector_xyz[:3]
    aoa_rot = Rotation.identity(3)
    aoa_meas = get_aoa_quat(aoa_xyz, target_true, aoa_rot)
    aoa_cov = np.tile(np.eye(2) * 0.001**2, (3, 1, 1))

    result = tdoa_aoa_fdoa_locator(
        fdoa_collector1_xyz=c1,
        fdoa_collector2_xyz=c2,
        fdoa_measurements=fdoas,
        fdoa_variances=fdoa_variances,
        freq_hz=freq_hz,
        fdoa_collector1_vel=v1,
        fdoa_collector2_vel=v2,
        aoa_collector_xyz=aoa_xyz,
        aoa_rotations=aoa_rot,
        aoa_measurements=aoa_meas,
        aoa_covariances=aoa_cov,
        fix_velocity=np.zeros(3),
    )

    pos_error = np.linalg.norm(result.position - target_true)
    assert pos_error < 1.0, f"Position error {pos_error:.6f}m exceeds 1m"
    assert np.allclose(result.velocity, vel_true)
    assert result.covariance.shape == (3, 3)


def test_aoa_only_delegates() -> None:
    """AOA-only input delegates to aoa_locator."""
    collector_xyz, _, target_true, vel_true = _create_geometry()

    # AOA from first 3 collectors
    aoa_xyz = collector_xyz[:3]
    aoa_rot = Rotation.identity(3)
    aoa_meas = get_aoa_quat(aoa_xyz, target_true, aoa_rot)
    aoa_cov = np.tile(np.eye(2) * 0.001**2, (3, 1, 1))

    result = tdoa_aoa_fdoa_locator(
        aoa_collector_xyz=aoa_xyz,
        aoa_rotations=aoa_rot,
        aoa_measurements=aoa_meas,
        aoa_covariances=aoa_cov,
        fix_velocity=np.zeros(3),
    )

    pos_error = np.linalg.norm(result.position - target_true)
    assert pos_error < 1.0, f"Position error {pos_error:.6f}m exceeds 1m"
    assert np.allclose(result.velocity, vel_true)
    assert result.covariance.shape == (3, 3)


# =============================================================================
# Combined TDOA + FDOA + AOA (fix_velocity mode)
# =============================================================================


def test_tdoa_fdoa_aoa_combined() -> None:
    """Combined TDOA+FDOA+AOA provides best position estimate."""
    collector_xyz, collector_vel, target_true, vel_true = _create_geometry()
    c1, c2, v1, v2 = _make_pairs(collector_xyz, collector_vel)
    freq_hz = 1e9

    fdoas = _compute_fdoas(target_true, vel_true, c1, c2, v1, v2, freq_hz)
    tdoas = _compute_tdoas(target_true, c1, c2)

    fdoa_variances = np.full(len(fdoas), 0.1**2)
    tdoa_variances = np.full(len(tdoas), (10e-9) ** 2)

    # AOA from first 3 collectors
    aoa_xyz = collector_xyz[:3]
    aoa_rot = Rotation.identity(3)
    aoa_meas = get_aoa_quat(aoa_xyz, target_true, aoa_rot)
    aoa_cov = np.tile(np.eye(2) * 0.001**2, (3, 1, 1))

    result = tdoa_aoa_fdoa_locator(
        fdoa_collector1_xyz=c1,
        fdoa_collector2_xyz=c2,
        fdoa_measurements=fdoas,
        fdoa_variances=fdoa_variances,
        freq_hz=freq_hz,
        fdoa_collector1_vel=v1,
        fdoa_collector2_vel=v2,
        tdoa_collector1_xyz=c1,
        tdoa_collector2_xyz=c2,
        tdoa_measurements=tdoas,
        tdoa_variances=tdoa_variances,
        aoa_collector_xyz=aoa_xyz,
        aoa_rotations=aoa_rot,
        aoa_measurements=aoa_meas,
        aoa_covariances=aoa_cov,
        fix_velocity=np.zeros(3),
    )

    pos_error = np.linalg.norm(result.position - target_true)
    assert pos_error < 1.0, f"Position error {pos_error:.6f}m exceeds 1m"
    assert np.allclose(result.velocity, vel_true)
    assert result.covariance.shape == (3, 3)


# =============================================================================
# Error Cases
# =============================================================================


def test_no_measurements_raises() -> None:
    """Must provide at least one measurement type."""
    with pytest.raises(ValueError, match="At least one of FDOA, TDOA, or AOA"):
        tdoa_aoa_fdoa_locator(fix_velocity=np.zeros(3))


def test_mismatched_fdoa_collector_shapes() -> None:
    """FDOA collector arrays must have consistent shapes."""
    c1 = np.zeros((3, 3))
    c2 = np.ones((4, 3)) * 1000  # Wrong size
    fdoas = np.zeros(3)
    variances = np.ones(3)

    with pytest.raises(ValueError, match="fdoa_collector2_xyz shape"):
        tdoa_aoa_fdoa_locator(
            fdoa_collector1_xyz=c1,
            fdoa_collector2_xyz=c2,
            fdoa_measurements=fdoas,
            fdoa_variances=variances,
            fix_velocity=np.zeros(3),
        )


def test_mismatched_fdoa_variance_shape() -> None:
    """FDOA variance array must match measurement count."""
    c1 = np.zeros((3, 3))
    c2 = np.ones((3, 3)) * 1000
    fdoas = np.zeros(3)
    variances = np.ones(4)  # Wrong size

    with pytest.raises(ValueError, match="fdoa_variances shape"):
        tdoa_aoa_fdoa_locator(
            fdoa_collector1_xyz=c1,
            fdoa_collector2_xyz=c2,
            fdoa_measurements=fdoas,
            fdoa_variances=variances,
            fix_velocity=np.zeros(3),
        )


def test_mismatched_fdoa_collector_vel_shape() -> None:
    """FDOA collector velocity arrays must match collector positions."""
    c1 = np.zeros((3, 3))
    c2 = np.ones((3, 3)) * 1000
    fdoas = np.zeros(3)
    variances = np.ones(3)
    v1 = np.zeros((4, 3))  # Wrong size

    with pytest.raises(ValueError, match="fdoa_collector1_vel shape"):
        tdoa_aoa_fdoa_locator(
            fdoa_collector1_xyz=c1,
            fdoa_collector2_xyz=c2,
            fdoa_measurements=fdoas,
            fdoa_variances=variances,
            fdoa_collector1_vel=v1,
            fix_velocity=np.zeros(3),
        )


def test_partial_fdoa_inputs_raises() -> None:
    """FDOA inputs must be all provided or all None."""
    c1 = np.zeros((3, 3))

    with pytest.raises(ValueError, match="FDOA inputs must be all provided"):
        tdoa_aoa_fdoa_locator(
            fdoa_collector1_xyz=c1,
            fix_velocity=np.zeros(3),
        )


def test_partial_tdoa_inputs_raises() -> None:
    """TDOA inputs must be all provided or all None."""
    c1 = np.zeros((3, 3))

    with pytest.raises(ValueError, match="TDOA inputs must be all provided"):
        tdoa_aoa_fdoa_locator(
            tdoa_collector1_xyz=c1,
            fix_velocity=np.zeros(3),
        )


def test_partial_aoa_inputs_raises() -> None:
    """AOA inputs must be all provided or all None."""
    aoa_xyz = np.zeros((3, 3))

    with pytest.raises(ValueError, match="AOA inputs must be all provided"):
        tdoa_aoa_fdoa_locator(
            aoa_collector_xyz=aoa_xyz,
            fix_velocity=np.zeros(3),
        )
