"""Functional tests for TDOA+AOA geolocation solver.

Tests tdoa_aoa_locator for position estimation from combined TDOA and AOA
measurements, covering the main use cases without exhaustive unit testing.
"""

from __future__ import annotations

import numpy as np
import pytest
from gri_utils.observables import get_aoa_quat, get_tdoa
from scipy.spatial.transform import Rotation

from gri_geosim.geolocation import tdoa_aoa_locator

# Test geometry constants
EARTH_RADIUS = 6378137.0
LEO_ALT = 600_000.0


def _create_geometry(
    n_collectors: int = 4,
) -> tuple[np.ndarray, np.ndarray]:
    """Create LEO collector geometry with ground target.

    Returns:
        Tuple of (collector_xyz, target_xyz).
    """
    r = EARTH_RADIUS + LEO_ALT

    # 3D distributed collectors (not coplanar)
    positions = [
        [r, 0.0, 0.0],
        [r * 0.866, r * 0.5, 0.0],
        [r * 0.866, 0.0, r * 0.5],
        [r * 0.707, r * 0.5, r * 0.5],
        [r * 0.707, -r * 0.5, r * 0.5],
    ][:n_collectors]

    collector_xyz = np.array(positions)
    target_xyz = np.array([EARTH_RADIUS, 0.0, 0.0])

    return collector_xyz, target_xyz


def _make_tdoa_pairs(
    collector_xyz: np.ndarray,
) -> tuple[np.ndarray, np.ndarray]:
    """Create all unique collector pairs for TDOA."""
    n = len(collector_xyz)
    pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]
    c1 = np.array([collector_xyz[i] for i, _ in pairs])
    c2 = np.array([collector_xyz[j] for _, j in pairs])
    return c1, c2


def _compute_tdoas(
    target_xyz: np.ndarray,
    c1: np.ndarray,
    c2: np.ndarray,
) -> np.ndarray:
    """Compute TDOA measurements for all pairs."""
    return np.array([get_tdoa(target_xyz, c1[i], c2[i]) for i in range(len(c1))])


# =============================================================================
# Combined TDOA + AOA (the main use case for this solver)
# =============================================================================


def test_tdoa_aoa_combined_basic() -> None:
    """Combined TDOA+AOA achieves sub-meter accuracy."""
    collector_xyz, target_true = _create_geometry()
    c1, c2 = _make_tdoa_pairs(collector_xyz)

    # TDOA measurements
    tdoas = _compute_tdoas(target_true, c1, c2)
    tdoa_variances = np.full(len(tdoas), (10e-9) ** 2)

    # AOA measurements from first 2 collectors
    aoa_xyz = collector_xyz[:2]
    aoa_rot = Rotation.identity(2)
    aoa_meas = get_aoa_quat(aoa_xyz, target_true, aoa_rot)
    aoa_cov = np.tile(np.eye(2) * 0.001**2, (2, 1, 1))

    result = tdoa_aoa_locator(
        tdoa_collector1_xyz=c1,
        tdoa_collector2_xyz=c2,
        tdoa_measurements=tdoas,
        tdoa_variances=tdoa_variances,
        aoa_collector_xyz=aoa_xyz,
        aoa_rotations=aoa_rot,
        aoa_measurements=aoa_meas,
        aoa_covariances=aoa_cov,
    )

    pos_error = np.linalg.norm(result.position - target_true)
    assert pos_error < 1.0, f"Position error {pos_error:.6f}m exceeds 1m"
    assert result.covariance.shape == (3, 3)
    assert np.all(np.isnan(result.velocity))  # Velocity not estimated


def test_tdoa_aoa_minimum_observations() -> None:
    """Combined TDOA+AOA works with minimum 3 total observations."""
    collector_xyz, target_true = _create_geometry()

    # 1 TDOA pair (1 observation)
    c1 = collector_xyz[:1]
    c2 = collector_xyz[1:2]
    tdoas = _compute_tdoas(target_true, c1, c2)
    tdoa_variances = np.full(1, (10e-9) ** 2)

    # 1 AOA collector (2 observations) -> total 3 observations
    aoa_xyz = collector_xyz[2:3]
    aoa_rot = Rotation.identity(1)
    aoa_meas = get_aoa_quat(aoa_xyz, target_true, aoa_rot)
    aoa_cov = np.tile(np.eye(2) * 0.001**2, (1, 1, 1))

    result = tdoa_aoa_locator(
        tdoa_collector1_xyz=c1,
        tdoa_collector2_xyz=c2,
        tdoa_measurements=tdoas,
        tdoa_variances=tdoa_variances,
        aoa_collector_xyz=aoa_xyz,
        aoa_rotations=aoa_rot,
        aoa_measurements=aoa_meas,
        aoa_covariances=aoa_cov,
    )

    assert result.position.shape == (3,)
    assert result.covariance.shape == (3, 3)


def test_tdoa_aoa_insufficient_observations_raises() -> None:
    """Fewer than 3 total observations in hybrid mode raises ValueError."""
    collector_xyz, target_true = _create_geometry()

    # 1 TDOA pair (1 observation) + 0 AOA -> delegates to tdoa_locator which requires 3
    # To test the hybrid path's observation check, we need both AOA and TDOA with
    # insufficient total: 1 TDOA + 0.5 AOA = can't happen (AOA gives 2 per collector)

    # Instead, test with 2 TDOA + 0 AOA in hybrid path - but this delegates to
    # tdoa_locator The hybrid check only triggers when both AOA AND TDOA are present
    # Let's verify the delegated check still works
    c1 = collector_xyz[:1]
    c2 = collector_xyz[1:2]
    tdoas = _compute_tdoas(target_true, c1, c2)
    tdoa_variances = np.full(1, (10e-9) ** 2)

    with pytest.raises(ValueError, match="TDOA measurements required"):
        tdoa_aoa_locator(
            tdoa_collector1_xyz=c1,
            tdoa_collector2_xyz=c2,
            tdoa_measurements=tdoas,
            tdoa_variances=tdoa_variances,
        )


# =============================================================================
# Delegation to single-observable locators
# =============================================================================


def test_tdoa_only_delegates() -> None:
    """TDOA-only input delegates to tdoa_locator."""
    collector_xyz, target_true = _create_geometry()
    c1, c2 = _make_tdoa_pairs(collector_xyz)

    tdoas = _compute_tdoas(target_true, c1, c2)
    tdoa_variances = np.full(len(tdoas), (10e-9) ** 2)

    result = tdoa_aoa_locator(
        tdoa_collector1_xyz=c1,
        tdoa_collector2_xyz=c2,
        tdoa_measurements=tdoas,
        tdoa_variances=tdoa_variances,
    )

    pos_error = np.linalg.norm(result.position - target_true)
    assert pos_error < 1.0, f"Position error {pos_error:.6f}m exceeds 1m"


def test_aoa_only_delegates() -> None:
    """AOA-only input delegates to aoa_locator."""
    collector_xyz, target_true = _create_geometry()

    aoa_xyz = collector_xyz[:3]
    aoa_rot = Rotation.identity(3)
    aoa_meas = get_aoa_quat(aoa_xyz, target_true, aoa_rot)
    aoa_cov = np.tile(np.eye(2) * 0.001**2, (3, 1, 1))

    result = tdoa_aoa_locator(
        aoa_collector_xyz=aoa_xyz,
        aoa_rotations=aoa_rot,
        aoa_measurements=aoa_meas,
        aoa_covariances=aoa_cov,
    )

    pos_error = np.linalg.norm(result.position - target_true)
    assert pos_error < 1.0, f"Position error {pos_error:.6f}m exceeds 1m"


# =============================================================================
# Error Cases
# =============================================================================


def test_no_measurements_raises() -> None:
    """Must provide at least one measurement type."""
    with pytest.raises(ValueError, match="At least one of AOA or TDOA"):
        tdoa_aoa_locator()


def test_partial_tdoa_inputs_raises() -> None:
    """TDOA inputs must be all provided or all None."""
    c1 = np.zeros((3, 3))

    with pytest.raises(ValueError, match="TDOA inputs must be all provided"):
        tdoa_aoa_locator(tdoa_collector1_xyz=c1)


def test_partial_aoa_inputs_raises() -> None:
    """AOA inputs must be all provided or all None."""
    aoa_xyz = np.zeros((3, 3))

    with pytest.raises(ValueError, match="AOA inputs must be all provided"):
        tdoa_aoa_locator(aoa_collector_xyz=aoa_xyz)
