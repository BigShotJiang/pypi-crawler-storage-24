"""Tests for KeplerianTrajectory.

Tests verify Keplerian orbit propagation using two-body mechanics.
"""

from __future__ import annotations

import math

import numpy as np
import pytest
from gri_nsepoch import Delta, Time

from gri_geosim.trajectories import KeplerianTrajectory

# Orbital parameters for testing
_LEO_ALTITUDE_M = 400_000.0
_LEO_SMA = 6_378_137.0 + _LEO_ALTITUDE_M  # ~6.778e6 m
_ISS_INCLINATION_RAD = math.radians(51.6)

_EPOCH = Time(s=0.0)


# Orbital element validation


def test_rejects_negative_sma() -> None:
    """Verify trajectory rejects negative semi-major axis."""
    with pytest.raises(ValueError, match="positive"):
        KeplerianTrajectory(
            semi_major_axis_m=-1_000_000,
            eccentricity=0.0,
            inclination_rad=0.0,
            raan_rad=0.0,
            arg_periapsis_rad=0.0,
            mean_anomaly_rad=0.0,
            epoch=_EPOCH,
        )


@pytest.mark.parametrize(
    "eccentricity",
    [-0.1, 1.0, 1.5],
    ids=["negative", "parabolic", "hyperbolic"],
)
def test_rejects_invalid_eccentricity(eccentricity: float) -> None:
    """Verify trajectory rejects non-elliptical eccentricities."""
    with pytest.raises(ValueError, match=r"(?i)eccentricity"):  # Case-insensitive
        KeplerianTrajectory(
            semi_major_axis_m=_LEO_SMA,
            eccentricity=eccentricity,
            inclination_rad=0.0,
            raan_rad=0.0,
            arg_periapsis_rad=0.0,
            mean_anomaly_rad=0.0,
            epoch=_EPOCH,
        )


# Position propagation


@pytest.mark.parametrize(
    ("inclination_deg", "expected_z_nonzero"),
    [
        (0.0, False),  # Equatorial orbit
        (51.6, True),  # ISS-like inclination
        (90.0, True),  # Polar orbit
    ],
    ids=["equatorial", "inclined", "polar"],
)
def test_inclination_affects_z_component(
    inclination_deg: float,
    *,
    expected_z_nonzero: bool,
) -> None:
    """Verify orbital inclination affects Z component of position."""
    traj = KeplerianTrajectory(
        semi_major_axis_m=_LEO_SMA,
        eccentricity=0.0001,
        inclination_rad=math.radians(inclination_deg),
        raan_rad=0.0,
        arg_periapsis_rad=0.0,
        mean_anomaly_rad=math.pi / 4,  # 45 degrees around orbit
        epoch=_EPOCH,
    )

    pos = traj.position_at(_EPOCH)

    if expected_z_nonzero:
        assert abs(pos.xyz[2]) > 1000  # Significant Z component
    else:
        assert abs(pos.xyz[2]) < 1000  # Near-zero Z component


def test_position_changes_over_time() -> None:
    """Verify position propagates over time."""
    traj = KeplerianTrajectory(
        semi_major_axis_m=_LEO_SMA,
        eccentricity=0.0001,
        inclination_rad=_ISS_INCLINATION_RAD,
        raan_rad=0.0,
        arg_periapsis_rad=0.0,
        mean_anomaly_rad=0.0,
        epoch=_EPOCH,
    )

    pos0 = traj.position_at(_EPOCH)
    pos1 = traj.position_at(_EPOCH + Delta(s=600.0))  # 10 minutes later

    assert not np.allclose(pos0.xyz, pos1.xyz)


def test_altitude_reasonable_for_leo() -> None:
    """Verify altitude is reasonable for LEO orbit."""
    traj = KeplerianTrajectory(
        semi_major_axis_m=_LEO_SMA,
        eccentricity=0.0001,
        inclination_rad=_ISS_INCLINATION_RAD,
        raan_rad=0.0,
        arg_periapsis_rad=0.0,
        mean_anomaly_rad=0.0,
        epoch=_EPOCH,
    )

    pos = traj.position_at(_EPOCH)
    altitude = pos.lla.alt_m

    # Should be within 10 km of target altitude
    assert abs(altitude - _LEO_ALTITUDE_M) < 10_000


# Velocity


def test_velocity_magnitude_leo() -> None:
    """Verify LEO velocity is approximately 7.5 km/s."""
    traj = KeplerianTrajectory(
        semi_major_axis_m=_LEO_SMA,
        eccentricity=0.0001,
        inclination_rad=_ISS_INCLINATION_RAD,
        raan_rad=0.0,
        arg_periapsis_rad=0.0,
        mean_anomaly_rad=0.0,
        epoch=_EPOCH,
    )

    vel = traj.velocity_at(_EPOCH)
    speed = float(np.linalg.norm(vel))

    # LEO velocity should be ~7.5 km/s
    assert 7000 < speed < 8000


def test_velocity_perpendicular_to_position_circular() -> None:
    """Verify velocity is perpendicular to position for circular orbit."""
    traj = KeplerianTrajectory(
        semi_major_axis_m=_LEO_SMA,
        eccentricity=0.0,  # Exactly circular
        inclination_rad=_ISS_INCLINATION_RAD,
        raan_rad=0.0,
        arg_periapsis_rad=0.0,
        mean_anomaly_rad=0.0,
        epoch=_EPOCH,
    )

    pos = traj.position_at(_EPOCH)
    vel = traj.velocity_at(_EPOCH)

    # Dot product should be near zero for circular orbit
    dot = np.dot(pos.xyz, vel)
    assert abs(dot) < 1e6  # Small relative to |pos|*|vel| ~ 5e10


# State


def test_state_at() -> None:
    """Verify state_at returns both position and velocity."""
    traj = KeplerianTrajectory(
        semi_major_axis_m=_LEO_SMA,
        eccentricity=0.0001,
        inclination_rad=_ISS_INCLINATION_RAD,
        raan_rad=0.0,
        arg_periapsis_rad=0.0,
        mean_anomaly_rad=0.0,
        epoch=_EPOCH,
    )

    pos, vel = traj.state_at(_EPOCH)

    assert pos is not None
    assert vel.shape == (3,)


# Elements property


def test_elements_property() -> None:
    """Verify elements property returns orbital elements."""
    traj = KeplerianTrajectory(
        semi_major_axis_m=_LEO_SMA,
        eccentricity=0.001,
        inclination_rad=_ISS_INCLINATION_RAD,
        raan_rad=0.5,
        arg_periapsis_rad=0.3,
        mean_anomaly_rad=0.1,
        epoch=_EPOCH,
    )

    elements = traj.elements

    assert abs(elements.semi_major_axis_m - _LEO_SMA) < 1
    assert abs(elements.eccentricity - 0.001) < 1e-10
    assert abs(elements.inclination_rad - _ISS_INCLINATION_RAD) < 1e-10


# Factory methods


def test_from_elements() -> None:
    """Verify from_elements creates equivalent trajectory."""
    traj1 = KeplerianTrajectory(
        semi_major_axis_m=_LEO_SMA,
        eccentricity=0.001,
        inclination_rad=_ISS_INCLINATION_RAD,
        raan_rad=0.0,
        arg_periapsis_rad=0.0,
        mean_anomaly_rad=0.0,
        epoch=_EPOCH,
    )

    traj2 = KeplerianTrajectory.from_elements(traj1.elements, _EPOCH)

    pos1 = traj1.position_at(_EPOCH)
    pos2 = traj2.position_at(_EPOCH)

    assert np.allclose(pos1.xyz, pos2.xyz, rtol=1e-10)


def test_repr() -> None:
    """Verify string representation."""
    traj = KeplerianTrajectory(
        semi_major_axis_m=_LEO_SMA,
        eccentricity=0.001,
        inclination_rad=_ISS_INCLINATION_RAD,
        raan_rad=0.0,
        arg_periapsis_rad=0.0,
        mean_anomaly_rad=0.0,
        epoch=_EPOCH,
    )

    assert "KeplerianTrajectory" in repr(traj)
