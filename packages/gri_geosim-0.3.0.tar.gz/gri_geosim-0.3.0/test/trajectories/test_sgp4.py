"""Tests for Sgp4Trajectory.

Tests verify SGP4/SDP4 orbit propagation from TLE data.
"""

from __future__ import annotations

import numpy as np
import pytest
from gri_nsepoch import Delta, Time

from gri_geosim.trajectories import Sgp4Trajectory

# ISS TLE (epoch 2024-01-15)
_ISS_TLE_LINE1 = "1 25544U 98067A   24015.50000000  .00016717  00000-0  10270-3 0  9994"
_ISS_TLE_LINE2 = "2 25544  51.6400  10.5000 0005000  90.0000 270.0000 15.50000000000000"

# GPS satellite TLE (higher altitude)
_GPS_TLE_LINE1 = "1 28474U 04045A   24015.50000000 -.00000045  00000-0  00000+0 0  9991"
_GPS_TLE_LINE2 = "2 28474  54.5420 240.1730 0096380 202.6090 156.8830  2.00553550000000"

# Query time near TLE epoch
_EPOCH = Time(s=1705312800.0)  # 2024-01-15 10:00:00 UTC


# TLE parsing


def test_parses_valid_tle() -> None:
    """Verify trajectory parses valid TLE data."""
    traj = Sgp4Trajectory(_ISS_TLE_LINE1, _ISS_TLE_LINE2)

    assert traj.satellite_number == 25544


def test_rejects_invalid_tle() -> None:
    """Verify trajectory rejects malformed TLE data."""
    invalid_line1 = "1 XXXXX invalid data"
    invalid_line2 = "2 XXXXX more invalid"

    with pytest.raises(ValueError, match="Invalid TLE"):
        Sgp4Trajectory(invalid_line1, invalid_line2)


def test_strips_whitespace() -> None:
    """Verify trajectory strips leading/trailing whitespace."""
    traj = Sgp4Trajectory(
        f"  {_ISS_TLE_LINE1}  \n",
        f"\t{_ISS_TLE_LINE2}\t",
    )

    assert traj.satellite_number == 25544


# Properties


def test_line_properties() -> None:
    """Verify line1 and line2 properties return TLE data."""
    traj = Sgp4Trajectory(_ISS_TLE_LINE1, _ISS_TLE_LINE2)

    assert "25544" in traj.line1
    assert "51.6400" in traj.line2


def test_satrec_property() -> None:
    """Verify satrec property returns SGP4 satellite record."""
    traj = Sgp4Trajectory(_ISS_TLE_LINE1, _ISS_TLE_LINE2)

    satrec = traj.satrec

    assert satrec is not None
    assert satrec.satnum == 25544  # satnum is an int


# Position propagation


@pytest.mark.parametrize(
    ("tle1", "tle2", "expected_alt_km"),
    [
        (_ISS_TLE_LINE1, _ISS_TLE_LINE2, 420),  # ISS ~420 km
        (_GPS_TLE_LINE1, _GPS_TLE_LINE2, 20200),  # GPS ~20,200 km
    ],
    ids=["LEO", "MEO"],
)
def test_altitude_reasonable(tle1: str, tle2: str, expected_alt_km: float) -> None:
    """Verify position altitude is reasonable for orbit type."""
    traj = Sgp4Trajectory(tle1, tle2)

    pos = traj.position_at(_EPOCH)
    altitude_km = pos.lla.alt_m / 1000.0

    # Allow 20% tolerance for orbit variation
    assert abs(altitude_km - expected_alt_km) < expected_alt_km * 0.2


def test_position_changes_over_time() -> None:
    """Verify position propagates over time."""
    traj = Sgp4Trajectory(_ISS_TLE_LINE1, _ISS_TLE_LINE2)

    pos0 = traj.position_at(_EPOCH)
    pos1 = traj.position_at(_EPOCH + Delta(s=600.0))  # 10 minutes later

    assert not np.allclose(pos0.xyz, pos1.xyz)


def test_position_is_pos_object() -> None:
    """Verify position returns Pos object."""
    traj = Sgp4Trajectory(_ISS_TLE_LINE1, _ISS_TLE_LINE2)

    pos = traj.position_at(_EPOCH)

    assert hasattr(pos, "xyz")
    assert hasattr(pos, "lla")


# Velocity


@pytest.mark.parametrize(
    ("tle1", "tle2", "expected_speed_kms"),
    [
        (_ISS_TLE_LINE1, _ISS_TLE_LINE2, 7.7),  # ISS ~7.7 km/s
        (_GPS_TLE_LINE1, _GPS_TLE_LINE2, 2.9),  # GPS ~2.9 km/s
    ],
    ids=["LEO", "MEO"],
)
def test_velocity_magnitude(tle1: str, tle2: str, expected_speed_kms: float) -> None:
    """Verify velocity magnitude is reasonable for orbit type."""
    traj = Sgp4Trajectory(tle1, tle2)

    vel = traj.velocity_at(_EPOCH)
    speed_kms = float(np.linalg.norm(vel)) / 1000.0

    # Allow 10% tolerance
    assert abs(speed_kms - expected_speed_kms) < expected_speed_kms * 0.1


def test_velocity_shape() -> None:
    """Verify velocity returns 3-element array."""
    traj = Sgp4Trajectory(_ISS_TLE_LINE1, _ISS_TLE_LINE2)

    vel = traj.velocity_at(_EPOCH)

    assert vel.shape == (3,)


# State


def test_state_at() -> None:
    """Verify state_at returns both position and velocity."""
    traj = Sgp4Trajectory(_ISS_TLE_LINE1, _ISS_TLE_LINE2)

    pos, vel = traj.state_at(_EPOCH)

    assert pos is not None
    assert vel.shape == (3,)


def test_state_at_matches_separate_calls() -> None:
    """Verify state_at matches position_at and velocity_at."""
    traj = Sgp4Trajectory(_ISS_TLE_LINE1, _ISS_TLE_LINE2)

    pos1 = traj.position_at(_EPOCH)
    vel1 = traj.velocity_at(_EPOCH)
    pos2, vel2 = traj.state_at(_EPOCH)

    assert np.allclose(pos1.xyz, pos2.xyz, rtol=1e-10)
    assert np.allclose(vel1, vel2, rtol=1e-10)


def test_repr() -> None:
    """Verify string representation."""
    traj = Sgp4Trajectory(_ISS_TLE_LINE1, _ISS_TLE_LINE2)

    assert "Sgp4Trajectory" in repr(traj)
    assert "25544" in repr(traj)
