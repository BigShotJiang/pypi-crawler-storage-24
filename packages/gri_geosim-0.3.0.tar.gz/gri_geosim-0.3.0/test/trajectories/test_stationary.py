"""Tests for StationaryTrajectory.

Tests verify that stationary trajectories return constant position and zero
velocity regardless of time.
"""

from __future__ import annotations

import numpy as np
import pytest
from gri_nsepoch import Time
from gri_pos import LLA, XYZ, Pos

from gri_geosim.trajectories import StationaryTrajectory

# Test positions
_POS_MUNICH = Pos.LLA(48.13743, 11.57549, 550)
_POS_EQUATOR = Pos.LLA(0.0, 0.0, 0.0)
_POS_HIGH_ALT = Pos.LLA(38.0, -77.0, 400_000.0)  # 400 km

# Time instants for testing
_T0 = Time(s=0.0)
_T1 = Time(s=3600.0)
_T2 = Time(s=86400.0)


# Position input formats


@pytest.mark.parametrize(
    "position",
    [
        _POS_MUNICH,
        LLA(48.13743, 11.57549, 550),
        XYZ(*_POS_MUNICH.xyz),
        _POS_MUNICH.xyz,
        list(_POS_MUNICH.xyz),
    ],
    ids=["Pos", "LLA", "XYZ", "ndarray", "list"],
)
def test_accepts_position_formats(
    position: Pos | LLA | XYZ | np.ndarray | list,
) -> None:
    """Verify trajectory accepts various position input formats."""
    traj = StationaryTrajectory(position)
    pos = traj.position_at(_T0)

    assert np.allclose(pos.xyz, _POS_MUNICH.xyz, rtol=1e-10)


def test_rejects_invalid_position() -> None:
    """Verify trajectory rejects unsupported position types."""
    with pytest.raises(TypeError, match="Unsupported position type"):
        StationaryTrajectory("invalid")  # type: ignore[arg-type]


# Position constancy


@pytest.mark.parametrize(
    "time",
    [_T0, _T1, _T2],
    ids=["t=0", "t=1h", "t=24h"],
)
def test_position_constant_over_time(time: Time) -> None:
    """Verify position remains constant regardless of query time."""
    traj = StationaryTrajectory(_POS_MUNICH)

    pos = traj.position_at(time)

    assert np.allclose(pos.xyz, _POS_MUNICH.xyz, rtol=1e-10)


# Velocity


@pytest.mark.parametrize(
    "time",
    [_T0, _T1, _T2],
    ids=["t=0", "t=1h", "t=24h"],
)
def test_velocity_always_zero(time: Time) -> None:
    """Verify velocity is zero at all times."""
    traj = StationaryTrajectory(_POS_MUNICH)

    vel = traj.velocity_at(time)

    assert vel.shape == (3,)
    assert np.allclose(vel, [0.0, 0.0, 0.0])


def test_velocity_immutable() -> None:
    """Verify velocity array cannot be modified."""
    traj = StationaryTrajectory(_POS_MUNICH)
    vel = traj.velocity_at(_T0)

    with pytest.raises((TypeError, ValueError)):
        vel[0] = 999.0


# State (position + velocity)


def test_state_at() -> None:
    """Verify state_at returns both position and velocity."""
    traj = StationaryTrajectory(_POS_MUNICH)

    pos, vel = traj.state_at(_T0)

    assert np.allclose(pos.xyz, _POS_MUNICH.xyz, rtol=1e-10)
    assert np.allclose(vel, [0.0, 0.0, 0.0])


# Properties


def test_position_property() -> None:
    """Verify position property returns the fixed position."""
    traj = StationaryTrajectory(_POS_MUNICH)

    assert np.allclose(traj.position.xyz, _POS_MUNICH.xyz, rtol=1e-10)


def test_repr() -> None:
    """Verify string representation."""
    traj = StationaryTrajectory(_POS_MUNICH)

    assert "StationaryTrajectory" in repr(traj)
