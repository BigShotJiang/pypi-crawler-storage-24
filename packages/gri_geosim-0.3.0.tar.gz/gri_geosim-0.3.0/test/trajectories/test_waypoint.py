"""Tests for WaypointTrajectory.

Tests verify interpolation between waypoints using linear and cubic methods.
"""

from __future__ import annotations

import numpy as np
import pytest
from gri_nsepoch import Delta, Time
from gri_pos import LLA, XYZ, Pos

from gri_geosim.trajectories import WaypointTrajectory

# Base time and waypoint positions
_T0 = Time(s=0.0)
_T1 = Time(s=3600.0)  # 1 hour
_T2 = Time(s=7200.0)  # 2 hours

_POS_START = Pos.LLA(38.0, -77.0, 1000.0)
_POS_END = Pos.LLA(39.0, -76.0, 1000.0)
_POS_MID = Pos.LLA(40.0, -75.0, 1000.0)


# Validation


def test_requires_two_waypoints() -> None:
    """Verify trajectory requires at least two waypoints."""
    with pytest.raises(ValueError, match="At least 2 waypoints"):
        WaypointTrajectory([(_T0, _POS_START)])


def test_requires_increasing_times() -> None:
    """Verify waypoint times must be strictly increasing."""
    with pytest.raises(ValueError, match="strictly increasing"):
        WaypointTrajectory(
            [
                (_T1, _POS_START),  # Later time first
                (_T0, _POS_END),
            ],
        )


def test_rejects_invalid_interpolation() -> None:
    """Verify trajectory rejects unknown interpolation method."""
    with pytest.raises(ValueError, match="Unknown interpolation"):
        WaypointTrajectory(
            [(_T0, _POS_START), (_T1, _POS_END)],
            interpolation="spline",  # type: ignore[arg-type]
        )


# Position input formats


@pytest.mark.parametrize(
    "position_type",
    ["Pos", "LLA", "XYZ", "ndarray", "list"],
)
def test_accepts_position_formats(position_type: str) -> None:
    """Verify trajectory accepts various position input formats."""
    if position_type == "Pos":
        pos = _POS_START
    elif position_type == "LLA":
        pos = LLA(38.0, -77.0, 1000.0)
    elif position_type == "XYZ":
        pos = XYZ(*_POS_START.xyz)
    elif position_type == "ndarray":
        pos = _POS_START.xyz
    else:  # list
        pos = list(_POS_START.xyz)

    traj = WaypointTrajectory([(_T0, pos), (_T1, _POS_END)])
    result = traj.position_at(_T0)

    assert np.allclose(result.xyz, _POS_START.xyz, rtol=1e-6)


# Linear interpolation


@pytest.mark.parametrize(
    ("query_fraction", "expected_lat"),
    [
        (0.0, 38.0),  # Start
        (0.5, 38.5),  # Middle
        (1.0, 39.0),  # End
    ],
    ids=["start", "middle", "end"],
)
def test_linear_interpolation_position(
    query_fraction: float,
    expected_lat: float,
) -> None:
    """Verify linear interpolation produces expected positions."""
    waypoints = [
        (_T0, Pos.LLA(38.0, -77.0, 1000.0)),
        (_T1, Pos.LLA(39.0, -77.0, 1000.0)),  # Same lon for simpler test
    ]
    traj = WaypointTrajectory(waypoints, interpolation="linear")

    query_time = _T0 + Delta(s=query_fraction * 3600.0)
    pos = traj.position_at(query_time)

    assert abs(pos.lla.lat_deg - expected_lat) < 0.1


def test_linear_extrapolation() -> None:
    """Verify linear interpolation extrapolates beyond waypoints."""
    waypoints = [(_T0, _POS_START), (_T1, _POS_END)]
    traj = WaypointTrajectory(waypoints, interpolation="linear")

    # Query before first waypoint
    pos_before = traj.position_at(_T0 + Delta(s=-1800.0))  # 30 min before

    # Should extrapolate (not clamp)
    assert pos_before is not None


# Cubic interpolation


def test_cubic_interpolation() -> None:
    """Verify cubic interpolation produces smooth results."""
    waypoints = [
        (_T0, _POS_START),
        (_T1, _POS_END),
        (_T2, _POS_MID),
    ]
    traj = WaypointTrajectory(waypoints, interpolation="cubic")

    # Query at middle of first segment
    pos = traj.position_at(_T0 + Delta(s=1800.0))

    assert pos is not None
    # Cubic may differ from linear midpoint due to smoothing


def test_cubic_velocity() -> None:
    """Verify cubic interpolation provides smooth velocity."""
    waypoints = [
        (_T0, _POS_START),
        (_T1, _POS_END),
        (_T2, _POS_MID),
    ]
    traj = WaypointTrajectory(waypoints, interpolation="cubic")

    vel = traj.velocity_at(_T0 + Delta(s=1800.0))

    assert vel.shape == (3,)
    # Velocity should be nonzero for moving trajectory
    assert np.linalg.norm(vel) > 0


# Velocity


def test_linear_velocity_consistent() -> None:
    """Verify linear interpolation gives consistent velocity within segment."""
    waypoints = [(_T0, _POS_START), (_T1, _POS_END)]
    traj = WaypointTrajectory(waypoints, interpolation="linear")

    vel1 = traj.velocity_at(_T0 + Delta(s=100.0))
    vel2 = traj.velocity_at(_T0 + Delta(s=3500.0))

    # Should be very similar for linear interpolation
    assert np.allclose(vel1, vel2, rtol=0.01)


# State


def test_state_at() -> None:
    """Verify state_at returns both position and velocity."""
    waypoints = [(_T0, _POS_START), (_T1, _POS_END)]
    traj = WaypointTrajectory(waypoints)

    pos, vel = traj.state_at(_T0 + Delta(s=1800.0))

    assert pos is not None
    assert vel.shape == (3,)


# Properties


def test_interpolation_property() -> None:
    """Verify interpolation property returns correct method."""
    traj_linear = WaypointTrajectory(
        [(_T0, _POS_START), (_T1, _POS_END)],
        interpolation="linear",
    )
    traj_cubic = WaypointTrajectory(
        [(_T0, _POS_START), (_T1, _POS_END)],
        interpolation="cubic",
    )

    assert traj_linear.interpolation == "linear"
    assert traj_cubic.interpolation == "cubic"


def test_num_waypoints_property() -> None:
    """Verify num_waypoints returns correct count."""
    traj = WaypointTrajectory(
        [
            (_T0, _POS_START),
            (_T1, _POS_END),
            (_T2, _POS_MID),
        ],
    )

    assert traj.num_waypoints == 3


def test_time_properties() -> None:
    """Verify start and end time properties."""
    traj = WaypointTrajectory([(_T0, _POS_START), (_T1, _POS_END)])

    assert traj.start_time_unix == _T0.secs
    assert traj.end_time_unix == _T1.secs


def test_repr() -> None:
    """Verify string representation."""
    traj = WaypointTrajectory([(_T0, _POS_START), (_T1, _POS_END)])

    assert "WaypointTrajectory" in repr(traj)
    assert "2 waypoints" in repr(traj)
